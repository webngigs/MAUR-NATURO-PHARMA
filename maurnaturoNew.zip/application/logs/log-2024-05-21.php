<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2024-05-21 01:31:30 --> $config['composer_autoload'] is set to TRUE but /home/u241458058/domains/technoprimex.com/public_html/maurnaturo/application/vendor/autoload.php was not found.
INFO - 2024-05-21 01:31:30 --> Config Class Initialized
INFO - 2024-05-21 01:31:30 --> Hooks Class Initialized
DEBUG - 2024-05-21 01:31:30 --> UTF-8 Support Enabled
INFO - 2024-05-21 01:31:30 --> Utf8 Class Initialized
INFO - 2024-05-21 01:31:30 --> URI Class Initialized
DEBUG - 2024-05-21 01:31:30 --> No URI present. Default controller set.
INFO - 2024-05-21 01:31:30 --> Router Class Initialized
INFO - 2024-05-21 01:31:30 --> Output Class Initialized
INFO - 2024-05-21 01:31:30 --> Security Class Initialized
DEBUG - 2024-05-21 01:31:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-21 01:31:30 --> Input Class Initialized
INFO - 2024-05-21 01:31:30 --> Language Class Initialized
INFO - 2024-05-21 01:31:30 --> Loader Class Initialized
INFO - 2024-05-21 01:31:30 --> Helper loaded: url_helper
INFO - 2024-05-21 01:31:30 --> Helper loaded: file_helper
INFO - 2024-05-21 01:31:30 --> Helper loaded: html_helper
INFO - 2024-05-21 01:31:30 --> Helper loaded: text_helper
INFO - 2024-05-21 01:31:30 --> Helper loaded: form_helper
INFO - 2024-05-21 01:31:30 --> Helper loaded: lang_helper
INFO - 2024-05-21 01:31:30 --> Helper loaded: security_helper
INFO - 2024-05-21 01:31:30 --> Helper loaded: cookie_helper
INFO - 2024-05-21 01:31:30 --> Database Driver Class Initialized
INFO - 2024-05-21 01:31:30 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-21 01:31:30 --> Parser Class Initialized
INFO - 2024-05-21 01:31:30 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-05-21 01:31:30 --> Pagination Class Initialized
INFO - 2024-05-21 01:31:30 --> Form Validation Class Initialized
INFO - 2024-05-21 01:31:30 --> Controller Class Initialized
INFO - 2024-05-21 01:31:30 --> Model Class Initialized
DEBUG - 2024-05-21 01:31:30 --> Session class already loaded. Second attempt ignored.
ERROR - 2024-05-21 01:37:28 --> $config['composer_autoload'] is set to TRUE but /home/u241458058/domains/technoprimex.com/public_html/maurnaturo/application/vendor/autoload.php was not found.
INFO - 2024-05-21 01:37:28 --> Config Class Initialized
INFO - 2024-05-21 01:37:28 --> Hooks Class Initialized
DEBUG - 2024-05-21 01:37:28 --> UTF-8 Support Enabled
INFO - 2024-05-21 01:37:28 --> Utf8 Class Initialized
INFO - 2024-05-21 01:37:28 --> URI Class Initialized
DEBUG - 2024-05-21 01:37:28 --> No URI present. Default controller set.
INFO - 2024-05-21 01:37:28 --> Router Class Initialized
INFO - 2024-05-21 01:37:28 --> Output Class Initialized
INFO - 2024-05-21 01:37:28 --> Security Class Initialized
DEBUG - 2024-05-21 01:37:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-21 01:37:28 --> Input Class Initialized
INFO - 2024-05-21 01:37:28 --> Language Class Initialized
INFO - 2024-05-21 01:37:28 --> Loader Class Initialized
INFO - 2024-05-21 01:37:28 --> Helper loaded: url_helper
INFO - 2024-05-21 01:37:28 --> Helper loaded: file_helper
INFO - 2024-05-21 01:37:28 --> Helper loaded: html_helper
INFO - 2024-05-21 01:37:28 --> Helper loaded: text_helper
INFO - 2024-05-21 01:37:28 --> Helper loaded: form_helper
INFO - 2024-05-21 01:37:28 --> Helper loaded: lang_helper
INFO - 2024-05-21 01:37:28 --> Helper loaded: security_helper
INFO - 2024-05-21 01:37:28 --> Helper loaded: cookie_helper
INFO - 2024-05-21 01:37:28 --> Database Driver Class Initialized
INFO - 2024-05-21 01:37:28 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-21 01:37:28 --> Parser Class Initialized
INFO - 2024-05-21 01:37:28 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-05-21 01:37:28 --> Pagination Class Initialized
INFO - 2024-05-21 01:37:28 --> Form Validation Class Initialized
INFO - 2024-05-21 01:37:28 --> Controller Class Initialized
INFO - 2024-05-21 01:37:28 --> Model Class Initialized
DEBUG - 2024-05-21 01:37:28 --> Session class already loaded. Second attempt ignored.
ERROR - 2024-05-21 05:09:50 --> $config['composer_autoload'] is set to TRUE but /home/u241458058/domains/technoprimex.com/public_html/maurnaturo/application/vendor/autoload.php was not found.
INFO - 2024-05-21 05:09:50 --> Config Class Initialized
INFO - 2024-05-21 05:09:50 --> Hooks Class Initialized
DEBUG - 2024-05-21 05:09:50 --> UTF-8 Support Enabled
INFO - 2024-05-21 05:09:50 --> Utf8 Class Initialized
INFO - 2024-05-21 05:09:50 --> URI Class Initialized
DEBUG - 2024-05-21 05:09:50 --> No URI present. Default controller set.
INFO - 2024-05-21 05:09:50 --> Router Class Initialized
INFO - 2024-05-21 05:09:50 --> Output Class Initialized
INFO - 2024-05-21 05:09:50 --> Security Class Initialized
DEBUG - 2024-05-21 05:09:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-21 05:09:50 --> Input Class Initialized
INFO - 2024-05-21 05:09:50 --> Language Class Initialized
INFO - 2024-05-21 05:09:50 --> Loader Class Initialized
INFO - 2024-05-21 05:09:50 --> Helper loaded: url_helper
INFO - 2024-05-21 05:09:50 --> Helper loaded: file_helper
INFO - 2024-05-21 05:09:50 --> Helper loaded: html_helper
INFO - 2024-05-21 05:09:50 --> Helper loaded: text_helper
INFO - 2024-05-21 05:09:50 --> Helper loaded: form_helper
INFO - 2024-05-21 05:09:50 --> Helper loaded: lang_helper
INFO - 2024-05-21 05:09:50 --> Helper loaded: security_helper
INFO - 2024-05-21 05:09:50 --> Helper loaded: cookie_helper
INFO - 2024-05-21 05:09:50 --> Database Driver Class Initialized
INFO - 2024-05-21 05:09:50 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-21 05:09:50 --> Parser Class Initialized
INFO - 2024-05-21 05:09:50 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-05-21 05:09:50 --> Pagination Class Initialized
INFO - 2024-05-21 05:09:50 --> Form Validation Class Initialized
INFO - 2024-05-21 05:09:50 --> Controller Class Initialized
INFO - 2024-05-21 05:09:50 --> Model Class Initialized
DEBUG - 2024-05-21 05:09:50 --> Session class already loaded. Second attempt ignored.
ERROR - 2024-05-21 05:32:46 --> $config['composer_autoload'] is set to TRUE but /home/u241458058/domains/technoprimex.com/public_html/maurnaturo/application/vendor/autoload.php was not found.
ERROR - 2024-05-21 05:32:46 --> $config['composer_autoload'] is set to TRUE but /home/u241458058/domains/technoprimex.com/public_html/maurnaturo/application/vendor/autoload.php was not found.
INFO - 2024-05-21 05:32:46 --> Config Class Initialized
INFO - 2024-05-21 05:32:46 --> Hooks Class Initialized
INFO - 2024-05-21 05:32:46 --> Config Class Initialized
INFO - 2024-05-21 05:32:46 --> Hooks Class Initialized
DEBUG - 2024-05-21 05:32:46 --> UTF-8 Support Enabled
DEBUG - 2024-05-21 05:32:46 --> UTF-8 Support Enabled
INFO - 2024-05-21 05:32:46 --> Utf8 Class Initialized
INFO - 2024-05-21 05:32:46 --> Utf8 Class Initialized
INFO - 2024-05-21 05:32:46 --> URI Class Initialized
INFO - 2024-05-21 05:32:46 --> URI Class Initialized
DEBUG - 2024-05-21 05:32:46 --> No URI present. Default controller set.
INFO - 2024-05-21 05:32:46 --> Router Class Initialized
DEBUG - 2024-05-21 05:32:46 --> No URI present. Default controller set.
INFO - 2024-05-21 05:32:46 --> Router Class Initialized
INFO - 2024-05-21 05:32:46 --> Output Class Initialized
INFO - 2024-05-21 05:32:46 --> Output Class Initialized
INFO - 2024-05-21 05:32:46 --> Security Class Initialized
DEBUG - 2024-05-21 05:32:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-21 05:32:46 --> Input Class Initialized
INFO - 2024-05-21 05:32:46 --> Security Class Initialized
DEBUG - 2024-05-21 05:32:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-21 05:32:46 --> Input Class Initialized
INFO - 2024-05-21 05:32:46 --> Language Class Initialized
INFO - 2024-05-21 05:32:46 --> Language Class Initialized
INFO - 2024-05-21 05:32:46 --> Loader Class Initialized
INFO - 2024-05-21 05:32:46 --> Loader Class Initialized
INFO - 2024-05-21 05:32:46 --> Helper loaded: url_helper
INFO - 2024-05-21 05:32:46 --> Helper loaded: file_helper
INFO - 2024-05-21 05:32:46 --> Helper loaded: url_helper
INFO - 2024-05-21 05:32:46 --> Helper loaded: file_helper
INFO - 2024-05-21 05:32:46 --> Helper loaded: html_helper
INFO - 2024-05-21 05:32:46 --> Helper loaded: html_helper
INFO - 2024-05-21 05:32:46 --> Helper loaded: text_helper
INFO - 2024-05-21 05:32:46 --> Helper loaded: text_helper
INFO - 2024-05-21 05:32:46 --> Helper loaded: form_helper
INFO - 2024-05-21 05:32:46 --> Helper loaded: lang_helper
INFO - 2024-05-21 05:32:46 --> Helper loaded: security_helper
INFO - 2024-05-21 05:32:46 --> Helper loaded: form_helper
INFO - 2024-05-21 05:32:46 --> Helper loaded: cookie_helper
INFO - 2024-05-21 05:32:46 --> Helper loaded: lang_helper
INFO - 2024-05-21 05:32:46 --> Helper loaded: security_helper
INFO - 2024-05-21 05:32:46 --> Helper loaded: cookie_helper
INFO - 2024-05-21 05:32:46 --> Database Driver Class Initialized
INFO - 2024-05-21 05:32:46 --> Database Driver Class Initialized
INFO - 2024-05-21 05:32:46 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-21 05:32:46 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-21 05:32:46 --> Parser Class Initialized
INFO - 2024-05-21 05:32:46 --> Parser Class Initialized
INFO - 2024-05-21 05:32:46 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-05-21 05:32:46 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-05-21 05:32:46 --> Pagination Class Initialized
INFO - 2024-05-21 05:32:46 --> Pagination Class Initialized
INFO - 2024-05-21 05:32:46 --> Form Validation Class Initialized
INFO - 2024-05-21 05:32:46 --> Form Validation Class Initialized
INFO - 2024-05-21 05:32:46 --> Controller Class Initialized
INFO - 2024-05-21 05:32:46 --> Controller Class Initialized
INFO - 2024-05-21 05:32:46 --> Model Class Initialized
INFO - 2024-05-21 05:32:46 --> Model Class Initialized
DEBUG - 2024-05-21 05:32:46 --> Session class already loaded. Second attempt ignored.
DEBUG - 2024-05-21 05:32:46 --> Session class already loaded. Second attempt ignored.
ERROR - 2024-05-21 05:32:51 --> $config['composer_autoload'] is set to TRUE but /home/u241458058/domains/technoprimex.com/public_html/maurnaturo/application/vendor/autoload.php was not found.
INFO - 2024-05-21 05:32:51 --> Config Class Initialized
INFO - 2024-05-21 05:32:51 --> Hooks Class Initialized
DEBUG - 2024-05-21 05:32:51 --> UTF-8 Support Enabled
INFO - 2024-05-21 05:32:51 --> Utf8 Class Initialized
INFO - 2024-05-21 05:32:51 --> URI Class Initialized
DEBUG - 2024-05-21 05:32:51 --> No URI present. Default controller set.
INFO - 2024-05-21 05:32:51 --> Router Class Initialized
INFO - 2024-05-21 05:32:51 --> Output Class Initialized
INFO - 2024-05-21 05:32:51 --> Security Class Initialized
DEBUG - 2024-05-21 05:32:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-21 05:32:51 --> Input Class Initialized
INFO - 2024-05-21 05:32:51 --> Language Class Initialized
INFO - 2024-05-21 05:32:51 --> Loader Class Initialized
INFO - 2024-05-21 05:32:51 --> Helper loaded: url_helper
INFO - 2024-05-21 05:32:51 --> Helper loaded: file_helper
INFO - 2024-05-21 05:32:51 --> Helper loaded: html_helper
INFO - 2024-05-21 05:32:51 --> Helper loaded: text_helper
INFO - 2024-05-21 05:32:51 --> Helper loaded: form_helper
INFO - 2024-05-21 05:32:51 --> Helper loaded: lang_helper
INFO - 2024-05-21 05:32:51 --> Helper loaded: security_helper
INFO - 2024-05-21 05:32:51 --> Helper loaded: cookie_helper
INFO - 2024-05-21 05:32:51 --> Database Driver Class Initialized
INFO - 2024-05-21 05:32:51 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-21 05:32:51 --> Parser Class Initialized
INFO - 2024-05-21 05:32:51 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-05-21 05:32:51 --> Pagination Class Initialized
INFO - 2024-05-21 05:32:51 --> Form Validation Class Initialized
INFO - 2024-05-21 05:32:51 --> Controller Class Initialized
INFO - 2024-05-21 05:32:51 --> Model Class Initialized
DEBUG - 2024-05-21 05:32:51 --> Session class already loaded. Second attempt ignored.
ERROR - 2024-05-21 05:33:38 --> $config['composer_autoload'] is set to TRUE but /home/u241458058/domains/technoprimex.com/public_html/maurnaturo/application/vendor/autoload.php was not found.
INFO - 2024-05-21 05:33:38 --> Config Class Initialized
INFO - 2024-05-21 05:33:38 --> Hooks Class Initialized
DEBUG - 2024-05-21 05:33:38 --> UTF-8 Support Enabled
INFO - 2024-05-21 05:33:38 --> Utf8 Class Initialized
INFO - 2024-05-21 05:33:38 --> URI Class Initialized
DEBUG - 2024-05-21 05:33:38 --> No URI present. Default controller set.
INFO - 2024-05-21 05:33:38 --> Router Class Initialized
ERROR - 2024-05-21 05:33:38 --> $config['composer_autoload'] is set to TRUE but /home/u241458058/domains/technoprimex.com/public_html/maurnaturo/application/vendor/autoload.php was not found.
INFO - 2024-05-21 05:33:38 --> Output Class Initialized
INFO - 2024-05-21 05:33:38 --> Config Class Initialized
INFO - 2024-05-21 05:33:38 --> Security Class Initialized
INFO - 2024-05-21 05:33:38 --> Hooks Class Initialized
DEBUG - 2024-05-21 05:33:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-21 05:33:38 --> Input Class Initialized
DEBUG - 2024-05-21 05:33:38 --> UTF-8 Support Enabled
INFO - 2024-05-21 05:33:38 --> Language Class Initialized
INFO - 2024-05-21 05:33:38 --> Utf8 Class Initialized
INFO - 2024-05-21 05:33:38 --> Loader Class Initialized
INFO - 2024-05-21 05:33:38 --> URI Class Initialized
INFO - 2024-05-21 05:33:38 --> Helper loaded: url_helper
DEBUG - 2024-05-21 05:33:38 --> No URI present. Default controller set.
INFO - 2024-05-21 05:33:38 --> Helper loaded: file_helper
INFO - 2024-05-21 05:33:38 --> Router Class Initialized
INFO - 2024-05-21 05:33:38 --> Helper loaded: html_helper
INFO - 2024-05-21 05:33:38 --> Output Class Initialized
INFO - 2024-05-21 05:33:38 --> Helper loaded: text_helper
INFO - 2024-05-21 05:33:38 --> Security Class Initialized
INFO - 2024-05-21 05:33:38 --> Helper loaded: form_helper
DEBUG - 2024-05-21 05:33:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-21 05:33:38 --> Helper loaded: lang_helper
INFO - 2024-05-21 05:33:38 --> Input Class Initialized
INFO - 2024-05-21 05:33:38 --> Helper loaded: security_helper
INFO - 2024-05-21 05:33:38 --> Language Class Initialized
INFO - 2024-05-21 05:33:38 --> Helper loaded: cookie_helper
INFO - 2024-05-21 05:33:38 --> Loader Class Initialized
INFO - 2024-05-21 05:33:38 --> Helper loaded: url_helper
INFO - 2024-05-21 05:33:38 --> Database Driver Class Initialized
INFO - 2024-05-21 05:33:38 --> Helper loaded: file_helper
INFO - 2024-05-21 05:33:38 --> Helper loaded: html_helper
INFO - 2024-05-21 05:33:38 --> Helper loaded: text_helper
INFO - 2024-05-21 05:33:38 --> Helper loaded: form_helper
INFO - 2024-05-21 05:33:38 --> Helper loaded: lang_helper
INFO - 2024-05-21 05:33:38 --> Helper loaded: security_helper
INFO - 2024-05-21 05:33:38 --> Helper loaded: cookie_helper
INFO - 2024-05-21 05:33:38 --> Database Driver Class Initialized
INFO - 2024-05-21 05:33:38 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-21 05:33:38 --> Parser Class Initialized
INFO - 2024-05-21 05:33:38 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-05-21 05:33:38 --> Pagination Class Initialized
INFO - 2024-05-21 05:33:38 --> Form Validation Class Initialized
INFO - 2024-05-21 05:33:38 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-21 05:33:38 --> Controller Class Initialized
INFO - 2024-05-21 05:33:38 --> Parser Class Initialized
INFO - 2024-05-21 05:33:38 --> Model Class Initialized
DEBUG - 2024-05-21 05:33:38 --> Session class already loaded. Second attempt ignored.
INFO - 2024-05-21 05:33:38 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-05-21 05:33:38 --> Pagination Class Initialized
INFO - 2024-05-21 05:33:38 --> Form Validation Class Initialized
INFO - 2024-05-21 05:33:38 --> Controller Class Initialized
INFO - 2024-05-21 05:33:38 --> Model Class Initialized
DEBUG - 2024-05-21 05:33:38 --> Session class already loaded. Second attempt ignored.
ERROR - 2024-05-21 05:33:43 --> $config['composer_autoload'] is set to TRUE but /home/u241458058/domains/technoprimex.com/public_html/maurnaturo/application/vendor/autoload.php was not found.
INFO - 2024-05-21 05:33:43 --> Config Class Initialized
INFO - 2024-05-21 05:33:43 --> Hooks Class Initialized
DEBUG - 2024-05-21 05:33:43 --> UTF-8 Support Enabled
INFO - 2024-05-21 05:33:43 --> Utf8 Class Initialized
INFO - 2024-05-21 05:33:43 --> URI Class Initialized
DEBUG - 2024-05-21 05:33:43 --> No URI present. Default controller set.
INFO - 2024-05-21 05:33:43 --> Router Class Initialized
INFO - 2024-05-21 05:33:43 --> Output Class Initialized
INFO - 2024-05-21 05:33:43 --> Security Class Initialized
DEBUG - 2024-05-21 05:33:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-21 05:33:43 --> Input Class Initialized
INFO - 2024-05-21 05:33:43 --> Language Class Initialized
INFO - 2024-05-21 05:33:43 --> Loader Class Initialized
INFO - 2024-05-21 05:33:43 --> Helper loaded: url_helper
INFO - 2024-05-21 05:33:43 --> Helper loaded: file_helper
INFO - 2024-05-21 05:33:43 --> Helper loaded: html_helper
INFO - 2024-05-21 05:33:43 --> Helper loaded: text_helper
INFO - 2024-05-21 05:33:43 --> Helper loaded: form_helper
INFO - 2024-05-21 05:33:43 --> Helper loaded: lang_helper
INFO - 2024-05-21 05:33:43 --> Helper loaded: security_helper
INFO - 2024-05-21 05:33:43 --> Helper loaded: cookie_helper
INFO - 2024-05-21 05:33:43 --> Database Driver Class Initialized
INFO - 2024-05-21 05:33:43 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-21 05:33:43 --> Parser Class Initialized
INFO - 2024-05-21 05:33:43 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-05-21 05:33:43 --> Pagination Class Initialized
INFO - 2024-05-21 05:33:43 --> Form Validation Class Initialized
INFO - 2024-05-21 05:33:43 --> Controller Class Initialized
INFO - 2024-05-21 05:33:43 --> Model Class Initialized
DEBUG - 2024-05-21 05:33:43 --> Session class already loaded. Second attempt ignored.
ERROR - 2024-05-21 05:36:42 --> $config['composer_autoload'] is set to TRUE but /home/u241458058/domains/technoprimex.com/public_html/maurnaturo/application/vendor/autoload.php was not found.
INFO - 2024-05-21 05:36:42 --> Config Class Initialized
INFO - 2024-05-21 05:36:42 --> Hooks Class Initialized
DEBUG - 2024-05-21 05:36:42 --> UTF-8 Support Enabled
INFO - 2024-05-21 05:36:42 --> Utf8 Class Initialized
INFO - 2024-05-21 05:36:42 --> URI Class Initialized
DEBUG - 2024-05-21 05:36:42 --> No URI present. Default controller set.
INFO - 2024-05-21 05:36:42 --> Router Class Initialized
INFO - 2024-05-21 05:36:42 --> Output Class Initialized
INFO - 2024-05-21 05:36:42 --> Security Class Initialized
DEBUG - 2024-05-21 05:36:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-21 05:36:42 --> Input Class Initialized
INFO - 2024-05-21 05:36:42 --> Language Class Initialized
INFO - 2024-05-21 05:36:42 --> Loader Class Initialized
INFO - 2024-05-21 05:36:42 --> Helper loaded: url_helper
INFO - 2024-05-21 05:36:42 --> Helper loaded: file_helper
INFO - 2024-05-21 05:36:42 --> Helper loaded: html_helper
INFO - 2024-05-21 05:36:42 --> Helper loaded: text_helper
INFO - 2024-05-21 05:36:42 --> Helper loaded: form_helper
INFO - 2024-05-21 05:36:42 --> Helper loaded: lang_helper
INFO - 2024-05-21 05:36:42 --> Helper loaded: security_helper
INFO - 2024-05-21 05:36:42 --> Helper loaded: cookie_helper
INFO - 2024-05-21 05:36:42 --> Database Driver Class Initialized
INFO - 2024-05-21 05:36:42 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-21 05:36:42 --> Parser Class Initialized
INFO - 2024-05-21 05:36:42 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-05-21 05:36:42 --> Pagination Class Initialized
INFO - 2024-05-21 05:36:42 --> Form Validation Class Initialized
INFO - 2024-05-21 05:36:42 --> Controller Class Initialized
INFO - 2024-05-21 05:36:42 --> Model Class Initialized
DEBUG - 2024-05-21 05:36:42 --> Session class already loaded. Second attempt ignored.
ERROR - 2024-05-21 05:36:42 --> $config['composer_autoload'] is set to TRUE but /home/u241458058/domains/technoprimex.com/public_html/maurnaturo/application/vendor/autoload.php was not found.
INFO - 2024-05-21 05:36:42 --> Config Class Initialized
INFO - 2024-05-21 05:36:42 --> Hooks Class Initialized
DEBUG - 2024-05-21 05:36:42 --> UTF-8 Support Enabled
INFO - 2024-05-21 05:36:42 --> Utf8 Class Initialized
INFO - 2024-05-21 05:36:42 --> URI Class Initialized
DEBUG - 2024-05-21 05:36:42 --> No URI present. Default controller set.
INFO - 2024-05-21 05:36:42 --> Router Class Initialized
INFO - 2024-05-21 05:36:42 --> Output Class Initialized
INFO - 2024-05-21 05:36:42 --> Security Class Initialized
DEBUG - 2024-05-21 05:36:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-21 05:36:42 --> Input Class Initialized
INFO - 2024-05-21 05:36:42 --> Language Class Initialized
INFO - 2024-05-21 05:36:42 --> Loader Class Initialized
INFO - 2024-05-21 05:36:42 --> Helper loaded: url_helper
INFO - 2024-05-21 05:36:42 --> Helper loaded: file_helper
INFO - 2024-05-21 05:36:42 --> Helper loaded: html_helper
INFO - 2024-05-21 05:36:42 --> Helper loaded: text_helper
INFO - 2024-05-21 05:36:42 --> Helper loaded: form_helper
INFO - 2024-05-21 05:36:42 --> Helper loaded: lang_helper
INFO - 2024-05-21 05:36:42 --> Helper loaded: security_helper
INFO - 2024-05-21 05:36:42 --> Helper loaded: cookie_helper
INFO - 2024-05-21 05:36:42 --> Database Driver Class Initialized
INFO - 2024-05-21 05:36:42 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-21 05:36:42 --> Parser Class Initialized
INFO - 2024-05-21 05:36:42 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-05-21 05:36:42 --> Pagination Class Initialized
INFO - 2024-05-21 05:36:42 --> Form Validation Class Initialized
INFO - 2024-05-21 05:36:42 --> Controller Class Initialized
INFO - 2024-05-21 05:36:42 --> Model Class Initialized
DEBUG - 2024-05-21 05:36:42 --> Session class already loaded. Second attempt ignored.
ERROR - 2024-05-21 05:36:45 --> $config['composer_autoload'] is set to TRUE but /home/u241458058/domains/technoprimex.com/public_html/maurnaturo/application/vendor/autoload.php was not found.
INFO - 2024-05-21 05:36:45 --> Config Class Initialized
INFO - 2024-05-21 05:36:45 --> Hooks Class Initialized
DEBUG - 2024-05-21 05:36:45 --> UTF-8 Support Enabled
INFO - 2024-05-21 05:36:45 --> Utf8 Class Initialized
INFO - 2024-05-21 05:36:45 --> URI Class Initialized
DEBUG - 2024-05-21 05:36:45 --> No URI present. Default controller set.
INFO - 2024-05-21 05:36:45 --> Router Class Initialized
INFO - 2024-05-21 05:36:45 --> Output Class Initialized
INFO - 2024-05-21 05:36:45 --> Security Class Initialized
DEBUG - 2024-05-21 05:36:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-21 05:36:45 --> Input Class Initialized
INFO - 2024-05-21 05:36:45 --> Language Class Initialized
INFO - 2024-05-21 05:36:45 --> Loader Class Initialized
INFO - 2024-05-21 05:36:45 --> Helper loaded: url_helper
INFO - 2024-05-21 05:36:45 --> Helper loaded: file_helper
INFO - 2024-05-21 05:36:45 --> Helper loaded: html_helper
INFO - 2024-05-21 05:36:45 --> Helper loaded: text_helper
INFO - 2024-05-21 05:36:45 --> Helper loaded: form_helper
INFO - 2024-05-21 05:36:45 --> Helper loaded: lang_helper
INFO - 2024-05-21 05:36:45 --> Helper loaded: security_helper
INFO - 2024-05-21 05:36:45 --> Helper loaded: cookie_helper
INFO - 2024-05-21 05:36:45 --> Database Driver Class Initialized
INFO - 2024-05-21 05:36:45 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-21 05:36:45 --> Parser Class Initialized
INFO - 2024-05-21 05:36:45 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-05-21 05:36:45 --> Pagination Class Initialized
INFO - 2024-05-21 05:36:45 --> Form Validation Class Initialized
INFO - 2024-05-21 05:36:45 --> Controller Class Initialized
INFO - 2024-05-21 05:36:45 --> Model Class Initialized
DEBUG - 2024-05-21 05:36:45 --> Session class already loaded. Second attempt ignored.
ERROR - 2024-05-21 05:37:26 --> $config['composer_autoload'] is set to TRUE but /home/u241458058/domains/technoprimex.com/public_html/maurnaturo/application/vendor/autoload.php was not found.
INFO - 2024-05-21 05:37:26 --> Config Class Initialized
INFO - 2024-05-21 05:37:26 --> Hooks Class Initialized
DEBUG - 2024-05-21 05:37:26 --> UTF-8 Support Enabled
INFO - 2024-05-21 05:37:26 --> Utf8 Class Initialized
INFO - 2024-05-21 05:37:26 --> URI Class Initialized
DEBUG - 2024-05-21 05:37:26 --> No URI present. Default controller set.
INFO - 2024-05-21 05:37:26 --> Router Class Initialized
INFO - 2024-05-21 05:37:26 --> Output Class Initialized
ERROR - 2024-05-21 05:37:26 --> $config['composer_autoload'] is set to TRUE but /home/u241458058/domains/technoprimex.com/public_html/maurnaturo/application/vendor/autoload.php was not found.
INFO - 2024-05-21 05:37:26 --> Security Class Initialized
DEBUG - 2024-05-21 05:37:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-21 05:37:26 --> Config Class Initialized
INFO - 2024-05-21 05:37:26 --> Input Class Initialized
INFO - 2024-05-21 05:37:26 --> Hooks Class Initialized
INFO - 2024-05-21 05:37:26 --> Language Class Initialized
DEBUG - 2024-05-21 05:37:26 --> UTF-8 Support Enabled
INFO - 2024-05-21 05:37:26 --> Loader Class Initialized
INFO - 2024-05-21 05:37:26 --> Utf8 Class Initialized
INFO - 2024-05-21 05:37:26 --> Helper loaded: url_helper
INFO - 2024-05-21 05:37:26 --> Helper loaded: file_helper
INFO - 2024-05-21 05:37:26 --> URI Class Initialized
INFO - 2024-05-21 05:37:26 --> Helper loaded: html_helper
INFO - 2024-05-21 05:37:26 --> Helper loaded: text_helper
DEBUG - 2024-05-21 05:37:26 --> No URI present. Default controller set.
INFO - 2024-05-21 05:37:26 --> Router Class Initialized
INFO - 2024-05-21 05:37:26 --> Helper loaded: form_helper
INFO - 2024-05-21 05:37:26 --> Helper loaded: lang_helper
INFO - 2024-05-21 05:37:26 --> Output Class Initialized
INFO - 2024-05-21 05:37:26 --> Helper loaded: security_helper
INFO - 2024-05-21 05:37:26 --> Security Class Initialized
INFO - 2024-05-21 05:37:26 --> Helper loaded: cookie_helper
DEBUG - 2024-05-21 05:37:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-21 05:37:26 --> Input Class Initialized
INFO - 2024-05-21 05:37:26 --> Database Driver Class Initialized
INFO - 2024-05-21 05:37:26 --> Language Class Initialized
INFO - 2024-05-21 05:37:26 --> Loader Class Initialized
INFO - 2024-05-21 05:37:26 --> Helper loaded: url_helper
INFO - 2024-05-21 05:37:26 --> Helper loaded: file_helper
INFO - 2024-05-21 05:37:26 --> Helper loaded: html_helper
INFO - 2024-05-21 05:37:26 --> Helper loaded: text_helper
INFO - 2024-05-21 05:37:26 --> Helper loaded: form_helper
INFO - 2024-05-21 05:37:26 --> Helper loaded: lang_helper
INFO - 2024-05-21 05:37:26 --> Helper loaded: security_helper
INFO - 2024-05-21 05:37:26 --> Helper loaded: cookie_helper
INFO - 2024-05-21 05:37:26 --> Database Driver Class Initialized
INFO - 2024-05-21 05:37:26 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-21 05:37:26 --> Parser Class Initialized
INFO - 2024-05-21 05:37:26 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-05-21 05:37:26 --> Pagination Class Initialized
INFO - 2024-05-21 05:37:26 --> Form Validation Class Initialized
INFO - 2024-05-21 05:37:26 --> Controller Class Initialized
INFO - 2024-05-21 05:37:26 --> Model Class Initialized
DEBUG - 2024-05-21 05:37:26 --> Session class already loaded. Second attempt ignored.
INFO - 2024-05-21 05:37:26 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-21 05:37:26 --> Parser Class Initialized
INFO - 2024-05-21 05:37:26 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-05-21 05:37:26 --> Pagination Class Initialized
INFO - 2024-05-21 05:37:26 --> Form Validation Class Initialized
INFO - 2024-05-21 05:37:26 --> Controller Class Initialized
INFO - 2024-05-21 05:37:26 --> Model Class Initialized
DEBUG - 2024-05-21 05:37:26 --> Session class already loaded. Second attempt ignored.
ERROR - 2024-05-21 05:37:30 --> $config['composer_autoload'] is set to TRUE but /home/u241458058/domains/technoprimex.com/public_html/maurnaturo/application/vendor/autoload.php was not found.
INFO - 2024-05-21 05:37:30 --> Config Class Initialized
INFO - 2024-05-21 05:37:30 --> Hooks Class Initialized
DEBUG - 2024-05-21 05:37:30 --> UTF-8 Support Enabled
INFO - 2024-05-21 05:37:30 --> Utf8 Class Initialized
INFO - 2024-05-21 05:37:30 --> URI Class Initialized
DEBUG - 2024-05-21 05:37:30 --> No URI present. Default controller set.
INFO - 2024-05-21 05:37:30 --> Router Class Initialized
INFO - 2024-05-21 05:37:30 --> Output Class Initialized
INFO - 2024-05-21 05:37:30 --> Security Class Initialized
DEBUG - 2024-05-21 05:37:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-21 05:37:30 --> Input Class Initialized
INFO - 2024-05-21 05:37:30 --> Language Class Initialized
INFO - 2024-05-21 05:37:30 --> Loader Class Initialized
INFO - 2024-05-21 05:37:30 --> Helper loaded: url_helper
INFO - 2024-05-21 05:37:30 --> Helper loaded: file_helper
INFO - 2024-05-21 05:37:30 --> Helper loaded: html_helper
INFO - 2024-05-21 05:37:30 --> Helper loaded: text_helper
INFO - 2024-05-21 05:37:30 --> Helper loaded: form_helper
INFO - 2024-05-21 05:37:30 --> Helper loaded: lang_helper
INFO - 2024-05-21 05:37:30 --> Helper loaded: security_helper
INFO - 2024-05-21 05:37:30 --> Helper loaded: cookie_helper
INFO - 2024-05-21 05:37:30 --> Database Driver Class Initialized
INFO - 2024-05-21 05:37:30 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-21 05:37:30 --> Parser Class Initialized
INFO - 2024-05-21 05:37:30 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-05-21 05:37:30 --> Pagination Class Initialized
INFO - 2024-05-21 05:37:30 --> Form Validation Class Initialized
INFO - 2024-05-21 05:37:30 --> Controller Class Initialized
INFO - 2024-05-21 05:37:30 --> Model Class Initialized
DEBUG - 2024-05-21 05:37:30 --> Session class already loaded. Second attempt ignored.
ERROR - 2024-05-21 06:18:41 --> $config['composer_autoload'] is set to TRUE but /home/u241458058/domains/technoprimex.com/public_html/maurnaturo/application/vendor/autoload.php was not found.
INFO - 2024-05-21 06:18:41 --> Config Class Initialized
INFO - 2024-05-21 06:18:41 --> Hooks Class Initialized
DEBUG - 2024-05-21 06:18:41 --> UTF-8 Support Enabled
INFO - 2024-05-21 06:18:41 --> Utf8 Class Initialized
INFO - 2024-05-21 06:18:41 --> URI Class Initialized
DEBUG - 2024-05-21 06:18:41 --> No URI present. Default controller set.
INFO - 2024-05-21 06:18:41 --> Router Class Initialized
INFO - 2024-05-21 06:18:41 --> Output Class Initialized
INFO - 2024-05-21 06:18:41 --> Security Class Initialized
DEBUG - 2024-05-21 06:18:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-21 06:18:41 --> Input Class Initialized
INFO - 2024-05-21 06:18:41 --> Language Class Initialized
INFO - 2024-05-21 06:18:41 --> Loader Class Initialized
INFO - 2024-05-21 06:18:41 --> Helper loaded: url_helper
INFO - 2024-05-21 06:18:41 --> Helper loaded: file_helper
INFO - 2024-05-21 06:18:41 --> Helper loaded: html_helper
INFO - 2024-05-21 06:18:41 --> Helper loaded: text_helper
INFO - 2024-05-21 06:18:41 --> Helper loaded: form_helper
INFO - 2024-05-21 06:18:41 --> Helper loaded: lang_helper
INFO - 2024-05-21 06:18:41 --> Helper loaded: security_helper
INFO - 2024-05-21 06:18:41 --> Helper loaded: cookie_helper
INFO - 2024-05-21 06:18:41 --> Database Driver Class Initialized
INFO - 2024-05-21 06:18:41 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-21 06:18:41 --> Parser Class Initialized
INFO - 2024-05-21 06:18:41 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-05-21 06:18:41 --> Pagination Class Initialized
INFO - 2024-05-21 06:18:41 --> Form Validation Class Initialized
INFO - 2024-05-21 06:18:41 --> Controller Class Initialized
INFO - 2024-05-21 06:18:41 --> Model Class Initialized
DEBUG - 2024-05-21 06:18:41 --> Session class already loaded. Second attempt ignored.
ERROR - 2024-05-21 06:42:42 --> $config['composer_autoload'] is set to TRUE but /home/u241458058/domains/technoprimex.com/public_html/maurnaturo/application/vendor/autoload.php was not found.
INFO - 2024-05-21 06:42:42 --> Config Class Initialized
INFO - 2024-05-21 06:42:42 --> Hooks Class Initialized
DEBUG - 2024-05-21 06:42:42 --> UTF-8 Support Enabled
INFO - 2024-05-21 06:42:42 --> Utf8 Class Initialized
INFO - 2024-05-21 06:42:42 --> URI Class Initialized
DEBUG - 2024-05-21 06:42:42 --> No URI present. Default controller set.
INFO - 2024-05-21 06:42:42 --> Router Class Initialized
INFO - 2024-05-21 06:42:42 --> Output Class Initialized
INFO - 2024-05-21 06:42:42 --> Security Class Initialized
DEBUG - 2024-05-21 06:42:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-21 06:42:42 --> Input Class Initialized
INFO - 2024-05-21 06:42:42 --> Language Class Initialized
INFO - 2024-05-21 06:42:42 --> Loader Class Initialized
INFO - 2024-05-21 06:42:42 --> Helper loaded: url_helper
INFO - 2024-05-21 06:42:42 --> Helper loaded: file_helper
INFO - 2024-05-21 06:42:42 --> Helper loaded: html_helper
INFO - 2024-05-21 06:42:42 --> Helper loaded: text_helper
INFO - 2024-05-21 06:42:42 --> Helper loaded: form_helper
INFO - 2024-05-21 06:42:42 --> Helper loaded: lang_helper
INFO - 2024-05-21 06:42:42 --> Helper loaded: security_helper
INFO - 2024-05-21 06:42:42 --> Helper loaded: cookie_helper
INFO - 2024-05-21 06:42:42 --> Database Driver Class Initialized
INFO - 2024-05-21 06:42:42 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-21 06:42:42 --> Parser Class Initialized
INFO - 2024-05-21 06:42:42 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-05-21 06:42:42 --> Pagination Class Initialized
INFO - 2024-05-21 06:42:42 --> Form Validation Class Initialized
INFO - 2024-05-21 06:42:42 --> Controller Class Initialized
INFO - 2024-05-21 06:42:42 --> Model Class Initialized
DEBUG - 2024-05-21 06:42:42 --> Session class already loaded. Second attempt ignored.
ERROR - 2024-05-21 07:39:23 --> $config['composer_autoload'] is set to TRUE but /home/u241458058/domains/technoprimex.com/public_html/maurnaturo/application/vendor/autoload.php was not found.
INFO - 2024-05-21 07:39:23 --> Config Class Initialized
INFO - 2024-05-21 07:39:23 --> Hooks Class Initialized
DEBUG - 2024-05-21 07:39:23 --> UTF-8 Support Enabled
INFO - 2024-05-21 07:39:23 --> Utf8 Class Initialized
INFO - 2024-05-21 07:39:23 --> URI Class Initialized
INFO - 2024-05-21 07:39:23 --> Router Class Initialized
INFO - 2024-05-21 07:39:23 --> Output Class Initialized
INFO - 2024-05-21 07:39:23 --> Security Class Initialized
DEBUG - 2024-05-21 07:39:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-21 07:39:23 --> Input Class Initialized
INFO - 2024-05-21 07:39:23 --> Language Class Initialized
INFO - 2024-05-21 07:39:23 --> Loader Class Initialized
INFO - 2024-05-21 07:39:23 --> Helper loaded: url_helper
INFO - 2024-05-21 07:39:23 --> Helper loaded: file_helper
INFO - 2024-05-21 07:39:23 --> Helper loaded: html_helper
INFO - 2024-05-21 07:39:23 --> Helper loaded: text_helper
INFO - 2024-05-21 07:39:23 --> Helper loaded: form_helper
INFO - 2024-05-21 07:39:23 --> Helper loaded: lang_helper
INFO - 2024-05-21 07:39:23 --> Helper loaded: security_helper
INFO - 2024-05-21 07:39:23 --> Helper loaded: cookie_helper
INFO - 2024-05-21 07:39:23 --> Database Driver Class Initialized
INFO - 2024-05-21 07:39:23 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-21 07:39:23 --> Parser Class Initialized
INFO - 2024-05-21 07:39:23 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-05-21 07:39:23 --> Pagination Class Initialized
INFO - 2024-05-21 07:39:23 --> Form Validation Class Initialized
INFO - 2024-05-21 07:39:23 --> Controller Class Initialized
INFO - 2024-05-21 07:39:23 --> Model Class Initialized
DEBUG - 2024-05-21 07:39:23 --> Session class already loaded. Second attempt ignored.
INFO - 2024-05-21 07:39:23 --> File loaded: /home/u241458058/domains/technoprimex.com/public_html/maurnaturo/application/views/user/admin_login_form.php
DEBUG - 2024-05-21 07:39:23 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-05-21 07:39:23 --> File loaded: /home/u241458058/domains/technoprimex.com/public_html/maurnaturo/application/views/include/top_menu.php
INFO - 2024-05-21 07:39:23 --> File loaded: /home/u241458058/domains/technoprimex.com/public_html/maurnaturo/application/views/include/admin_loggedin_info.php
INFO - 2024-05-21 07:39:23 --> Model Class Initialized
INFO - 2024-05-21 07:39:23 --> File loaded: /home/u241458058/domains/technoprimex.com/public_html/maurnaturo/application/views/admin_html_template.php
INFO - 2024-05-21 07:39:23 --> Final output sent to browser
DEBUG - 2024-05-21 07:39:23 --> Total execution time: 0.0627
ERROR - 2024-05-21 07:41:32 --> $config['composer_autoload'] is set to TRUE but /home/u241458058/domains/technoprimex.com/public_html/maurnaturo/application/vendor/autoload.php was not found.
INFO - 2024-05-21 07:41:32 --> Config Class Initialized
INFO - 2024-05-21 07:41:32 --> Hooks Class Initialized
DEBUG - 2024-05-21 07:41:32 --> UTF-8 Support Enabled
INFO - 2024-05-21 07:41:32 --> Utf8 Class Initialized
INFO - 2024-05-21 07:41:32 --> URI Class Initialized
INFO - 2024-05-21 07:41:32 --> Router Class Initialized
INFO - 2024-05-21 07:41:32 --> Output Class Initialized
INFO - 2024-05-21 07:41:32 --> Security Class Initialized
DEBUG - 2024-05-21 07:41:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-21 07:41:32 --> Input Class Initialized
INFO - 2024-05-21 07:41:32 --> Language Class Initialized
INFO - 2024-05-21 07:41:32 --> Loader Class Initialized
INFO - 2024-05-21 07:41:32 --> Helper loaded: url_helper
INFO - 2024-05-21 07:41:32 --> Helper loaded: file_helper
INFO - 2024-05-21 07:41:32 --> Helper loaded: html_helper
INFO - 2024-05-21 07:41:32 --> Helper loaded: text_helper
INFO - 2024-05-21 07:41:32 --> Helper loaded: form_helper
INFO - 2024-05-21 07:41:32 --> Helper loaded: lang_helper
INFO - 2024-05-21 07:41:32 --> Helper loaded: security_helper
INFO - 2024-05-21 07:41:32 --> Helper loaded: cookie_helper
INFO - 2024-05-21 07:41:32 --> Database Driver Class Initialized
INFO - 2024-05-21 07:41:32 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-21 07:41:32 --> Parser Class Initialized
INFO - 2024-05-21 07:41:32 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-05-21 07:41:32 --> Pagination Class Initialized
INFO - 2024-05-21 07:41:32 --> Form Validation Class Initialized
INFO - 2024-05-21 07:41:32 --> Controller Class Initialized
INFO - 2024-05-21 07:41:32 --> Model Class Initialized
DEBUG - 2024-05-21 07:41:32 --> Session class already loaded. Second attempt ignored.
INFO - 2024-05-21 07:41:32 --> Model Class Initialized
INFO - 2024-05-21 07:41:32 --> Final output sent to browser
DEBUG - 2024-05-21 07:41:32 --> Total execution time: 0.0124
ERROR - 2024-05-21 07:41:32 --> $config['composer_autoload'] is set to TRUE but /home/u241458058/domains/technoprimex.com/public_html/maurnaturo/application/vendor/autoload.php was not found.
INFO - 2024-05-21 07:41:32 --> Config Class Initialized
INFO - 2024-05-21 07:41:32 --> Hooks Class Initialized
DEBUG - 2024-05-21 07:41:32 --> UTF-8 Support Enabled
INFO - 2024-05-21 07:41:32 --> Utf8 Class Initialized
INFO - 2024-05-21 07:41:32 --> URI Class Initialized
INFO - 2024-05-21 07:41:32 --> Router Class Initialized
INFO - 2024-05-21 07:41:32 --> Output Class Initialized
INFO - 2024-05-21 07:41:32 --> Security Class Initialized
DEBUG - 2024-05-21 07:41:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-21 07:41:32 --> Input Class Initialized
INFO - 2024-05-21 07:41:32 --> Language Class Initialized
INFO - 2024-05-21 07:41:32 --> Loader Class Initialized
INFO - 2024-05-21 07:41:32 --> Helper loaded: url_helper
INFO - 2024-05-21 07:41:32 --> Helper loaded: file_helper
INFO - 2024-05-21 07:41:32 --> Helper loaded: html_helper
INFO - 2024-05-21 07:41:32 --> Helper loaded: text_helper
INFO - 2024-05-21 07:41:32 --> Helper loaded: form_helper
INFO - 2024-05-21 07:41:32 --> Helper loaded: lang_helper
INFO - 2024-05-21 07:41:32 --> Helper loaded: security_helper
INFO - 2024-05-21 07:41:32 --> Helper loaded: cookie_helper
INFO - 2024-05-21 07:41:32 --> Database Driver Class Initialized
INFO - 2024-05-21 07:41:32 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-21 07:41:32 --> Parser Class Initialized
INFO - 2024-05-21 07:41:32 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-05-21 07:41:32 --> Pagination Class Initialized
INFO - 2024-05-21 07:41:32 --> Form Validation Class Initialized
INFO - 2024-05-21 07:41:32 --> Controller Class Initialized
INFO - 2024-05-21 07:41:32 --> Model Class Initialized
DEBUG - 2024-05-21 07:41:32 --> Session class already loaded. Second attempt ignored.
INFO - 2024-05-21 07:41:32 --> File loaded: /home/u241458058/domains/technoprimex.com/public_html/maurnaturo/application/views/user/admin_login_form.php
DEBUG - 2024-05-21 07:41:32 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-05-21 07:41:32 --> File loaded: /home/u241458058/domains/technoprimex.com/public_html/maurnaturo/application/views/include/top_menu.php
INFO - 2024-05-21 07:41:32 --> File loaded: /home/u241458058/domains/technoprimex.com/public_html/maurnaturo/application/views/include/admin_loggedin_info.php
INFO - 2024-05-21 07:41:32 --> Model Class Initialized
INFO - 2024-05-21 07:41:32 --> File loaded: /home/u241458058/domains/technoprimex.com/public_html/maurnaturo/application/views/admin_html_template.php
INFO - 2024-05-21 07:41:32 --> Final output sent to browser
DEBUG - 2024-05-21 07:41:32 --> Total execution time: 0.0175
ERROR - 2024-05-21 07:52:27 --> $config['composer_autoload'] is set to TRUE but /home/u241458058/domains/technoprimex.com/public_html/maurnaturo/application/vendor/autoload.php was not found.
INFO - 2024-05-21 07:52:27 --> Config Class Initialized
INFO - 2024-05-21 07:52:27 --> Hooks Class Initialized
DEBUG - 2024-05-21 07:52:27 --> UTF-8 Support Enabled
INFO - 2024-05-21 07:52:27 --> Utf8 Class Initialized
INFO - 2024-05-21 07:52:27 --> URI Class Initialized
INFO - 2024-05-21 07:52:27 --> Router Class Initialized
INFO - 2024-05-21 07:52:27 --> Output Class Initialized
INFO - 2024-05-21 07:52:27 --> Security Class Initialized
DEBUG - 2024-05-21 07:52:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-21 07:52:27 --> Input Class Initialized
INFO - 2024-05-21 07:52:27 --> Language Class Initialized
INFO - 2024-05-21 07:52:27 --> Loader Class Initialized
INFO - 2024-05-21 07:52:27 --> Helper loaded: url_helper
INFO - 2024-05-21 07:52:27 --> Helper loaded: file_helper
INFO - 2024-05-21 07:52:27 --> Helper loaded: html_helper
INFO - 2024-05-21 07:52:27 --> Helper loaded: text_helper
INFO - 2024-05-21 07:52:27 --> Helper loaded: form_helper
INFO - 2024-05-21 07:52:27 --> Helper loaded: lang_helper
INFO - 2024-05-21 07:52:27 --> Helper loaded: security_helper
INFO - 2024-05-21 07:52:27 --> Helper loaded: cookie_helper
INFO - 2024-05-21 07:52:27 --> Database Driver Class Initialized
INFO - 2024-05-21 07:52:27 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-21 07:52:27 --> Parser Class Initialized
INFO - 2024-05-21 07:52:27 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-05-21 07:52:27 --> Pagination Class Initialized
INFO - 2024-05-21 07:52:27 --> Form Validation Class Initialized
INFO - 2024-05-21 07:52:27 --> Controller Class Initialized
INFO - 2024-05-21 07:52:27 --> Model Class Initialized
DEBUG - 2024-05-21 07:52:27 --> Session class already loaded. Second attempt ignored.
INFO - 2024-05-21 07:52:27 --> File loaded: /home/u241458058/domains/technoprimex.com/public_html/maurnaturo/application/views/user/admin_login_form.php
DEBUG - 2024-05-21 07:52:27 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-05-21 07:52:27 --> File loaded: /home/u241458058/domains/technoprimex.com/public_html/maurnaturo/application/views/include/top_menu.php
INFO - 2024-05-21 07:52:27 --> File loaded: /home/u241458058/domains/technoprimex.com/public_html/maurnaturo/application/views/include/admin_loggedin_info.php
INFO - 2024-05-21 07:52:27 --> Model Class Initialized
INFO - 2024-05-21 07:52:27 --> File loaded: /home/u241458058/domains/technoprimex.com/public_html/maurnaturo/application/views/admin_html_template.php
INFO - 2024-05-21 07:52:27 --> Final output sent to browser
DEBUG - 2024-05-21 07:52:27 --> Total execution time: 0.0500
ERROR - 2024-05-21 07:52:44 --> $config['composer_autoload'] is set to TRUE but /home/u241458058/domains/technoprimex.com/public_html/maurnaturo/application/vendor/autoload.php was not found.
INFO - 2024-05-21 07:52:44 --> Config Class Initialized
INFO - 2024-05-21 07:52:44 --> Hooks Class Initialized
DEBUG - 2024-05-21 07:52:44 --> UTF-8 Support Enabled
INFO - 2024-05-21 07:52:44 --> Utf8 Class Initialized
INFO - 2024-05-21 07:52:44 --> URI Class Initialized
INFO - 2024-05-21 07:52:44 --> Router Class Initialized
INFO - 2024-05-21 07:52:44 --> Output Class Initialized
INFO - 2024-05-21 07:52:44 --> Security Class Initialized
DEBUG - 2024-05-21 07:52:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-21 07:52:44 --> Input Class Initialized
INFO - 2024-05-21 07:52:44 --> Language Class Initialized
INFO - 2024-05-21 07:52:44 --> Loader Class Initialized
INFO - 2024-05-21 07:52:44 --> Helper loaded: url_helper
INFO - 2024-05-21 07:52:44 --> Helper loaded: file_helper
INFO - 2024-05-21 07:52:44 --> Helper loaded: html_helper
INFO - 2024-05-21 07:52:44 --> Helper loaded: text_helper
INFO - 2024-05-21 07:52:44 --> Helper loaded: form_helper
INFO - 2024-05-21 07:52:44 --> Helper loaded: lang_helper
INFO - 2024-05-21 07:52:44 --> Helper loaded: security_helper
INFO - 2024-05-21 07:52:44 --> Helper loaded: cookie_helper
INFO - 2024-05-21 07:52:44 --> Database Driver Class Initialized
INFO - 2024-05-21 07:52:44 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-21 07:52:44 --> Parser Class Initialized
INFO - 2024-05-21 07:52:44 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-05-21 07:52:44 --> Pagination Class Initialized
INFO - 2024-05-21 07:52:44 --> Form Validation Class Initialized
INFO - 2024-05-21 07:52:44 --> Controller Class Initialized
INFO - 2024-05-21 07:52:44 --> Model Class Initialized
DEBUG - 2024-05-21 07:52:44 --> Session class already loaded. Second attempt ignored.
INFO - 2024-05-21 07:52:44 --> Model Class Initialized
INFO - 2024-05-21 07:52:44 --> Final output sent to browser
DEBUG - 2024-05-21 07:52:44 --> Total execution time: 0.0108
ERROR - 2024-05-21 07:52:44 --> $config['composer_autoload'] is set to TRUE but /home/u241458058/domains/technoprimex.com/public_html/maurnaturo/application/vendor/autoload.php was not found.
INFO - 2024-05-21 07:52:44 --> Config Class Initialized
INFO - 2024-05-21 07:52:44 --> Hooks Class Initialized
DEBUG - 2024-05-21 07:52:44 --> UTF-8 Support Enabled
INFO - 2024-05-21 07:52:44 --> Utf8 Class Initialized
INFO - 2024-05-21 07:52:44 --> URI Class Initialized
INFO - 2024-05-21 07:52:44 --> Router Class Initialized
INFO - 2024-05-21 07:52:44 --> Output Class Initialized
INFO - 2024-05-21 07:52:44 --> Security Class Initialized
DEBUG - 2024-05-21 07:52:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-21 07:52:44 --> Input Class Initialized
INFO - 2024-05-21 07:52:44 --> Language Class Initialized
INFO - 2024-05-21 07:52:44 --> Loader Class Initialized
INFO - 2024-05-21 07:52:44 --> Helper loaded: url_helper
INFO - 2024-05-21 07:52:44 --> Helper loaded: file_helper
INFO - 2024-05-21 07:52:44 --> Helper loaded: html_helper
INFO - 2024-05-21 07:52:44 --> Helper loaded: text_helper
INFO - 2024-05-21 07:52:44 --> Helper loaded: form_helper
INFO - 2024-05-21 07:52:44 --> Helper loaded: lang_helper
INFO - 2024-05-21 07:52:44 --> Helper loaded: security_helper
INFO - 2024-05-21 07:52:44 --> Helper loaded: cookie_helper
INFO - 2024-05-21 07:52:44 --> Database Driver Class Initialized
INFO - 2024-05-21 07:52:44 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-21 07:52:44 --> Parser Class Initialized
INFO - 2024-05-21 07:52:44 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-05-21 07:52:44 --> Pagination Class Initialized
INFO - 2024-05-21 07:52:44 --> Form Validation Class Initialized
INFO - 2024-05-21 07:52:44 --> Controller Class Initialized
INFO - 2024-05-21 07:52:44 --> Model Class Initialized
DEBUG - 2024-05-21 07:52:44 --> Session class already loaded. Second attempt ignored.
INFO - 2024-05-21 07:52:44 --> File loaded: /home/u241458058/domains/technoprimex.com/public_html/maurnaturo/application/views/user/admin_login_form.php
DEBUG - 2024-05-21 07:52:44 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-05-21 07:52:44 --> File loaded: /home/u241458058/domains/technoprimex.com/public_html/maurnaturo/application/views/include/top_menu.php
INFO - 2024-05-21 07:52:44 --> File loaded: /home/u241458058/domains/technoprimex.com/public_html/maurnaturo/application/views/include/admin_loggedin_info.php
INFO - 2024-05-21 07:52:44 --> Model Class Initialized
INFO - 2024-05-21 07:52:44 --> File loaded: /home/u241458058/domains/technoprimex.com/public_html/maurnaturo/application/views/admin_html_template.php
INFO - 2024-05-21 07:52:44 --> Final output sent to browser
DEBUG - 2024-05-21 07:52:44 --> Total execution time: 0.0168
ERROR - 2024-05-21 07:53:01 --> $config['composer_autoload'] is set to TRUE but /home/u241458058/domains/technoprimex.com/public_html/maurnaturo/application/vendor/autoload.php was not found.
INFO - 2024-05-21 07:53:01 --> Config Class Initialized
INFO - 2024-05-21 07:53:01 --> Hooks Class Initialized
DEBUG - 2024-05-21 07:53:01 --> UTF-8 Support Enabled
INFO - 2024-05-21 07:53:01 --> Utf8 Class Initialized
INFO - 2024-05-21 07:53:01 --> URI Class Initialized
INFO - 2024-05-21 07:53:01 --> Router Class Initialized
INFO - 2024-05-21 07:53:01 --> Output Class Initialized
INFO - 2024-05-21 07:53:01 --> Security Class Initialized
DEBUG - 2024-05-21 07:53:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-21 07:53:01 --> Input Class Initialized
INFO - 2024-05-21 07:53:01 --> Language Class Initialized
INFO - 2024-05-21 07:53:01 --> Loader Class Initialized
INFO - 2024-05-21 07:53:01 --> Helper loaded: url_helper
INFO - 2024-05-21 07:53:01 --> Helper loaded: file_helper
INFO - 2024-05-21 07:53:01 --> Helper loaded: html_helper
INFO - 2024-05-21 07:53:01 --> Helper loaded: text_helper
INFO - 2024-05-21 07:53:01 --> Helper loaded: form_helper
INFO - 2024-05-21 07:53:01 --> Helper loaded: lang_helper
INFO - 2024-05-21 07:53:01 --> Helper loaded: security_helper
INFO - 2024-05-21 07:53:01 --> Helper loaded: cookie_helper
INFO - 2024-05-21 07:53:01 --> Database Driver Class Initialized
INFO - 2024-05-21 07:53:01 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-21 07:53:01 --> Parser Class Initialized
INFO - 2024-05-21 07:53:01 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-05-21 07:53:01 --> Pagination Class Initialized
INFO - 2024-05-21 07:53:01 --> Form Validation Class Initialized
INFO - 2024-05-21 07:53:01 --> Controller Class Initialized
INFO - 2024-05-21 07:53:01 --> Model Class Initialized
DEBUG - 2024-05-21 07:53:01 --> Session class already loaded. Second attempt ignored.
INFO - 2024-05-21 07:53:01 --> Model Class Initialized
INFO - 2024-05-21 07:53:01 --> Final output sent to browser
DEBUG - 2024-05-21 07:53:01 --> Total execution time: 0.0080
ERROR - 2024-05-21 07:53:01 --> $config['composer_autoload'] is set to TRUE but /home/u241458058/domains/technoprimex.com/public_html/maurnaturo/application/vendor/autoload.php was not found.
INFO - 2024-05-21 07:53:01 --> Config Class Initialized
INFO - 2024-05-21 07:53:01 --> Hooks Class Initialized
DEBUG - 2024-05-21 07:53:01 --> UTF-8 Support Enabled
INFO - 2024-05-21 07:53:01 --> Utf8 Class Initialized
INFO - 2024-05-21 07:53:01 --> URI Class Initialized
DEBUG - 2024-05-21 07:53:01 --> No URI present. Default controller set.
INFO - 2024-05-21 07:53:01 --> Router Class Initialized
INFO - 2024-05-21 07:53:01 --> Output Class Initialized
INFO - 2024-05-21 07:53:01 --> Security Class Initialized
DEBUG - 2024-05-21 07:53:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-21 07:53:01 --> Input Class Initialized
INFO - 2024-05-21 07:53:01 --> Language Class Initialized
INFO - 2024-05-21 07:53:01 --> Loader Class Initialized
INFO - 2024-05-21 07:53:01 --> Helper loaded: url_helper
INFO - 2024-05-21 07:53:01 --> Helper loaded: file_helper
INFO - 2024-05-21 07:53:01 --> Helper loaded: html_helper
INFO - 2024-05-21 07:53:01 --> Helper loaded: text_helper
INFO - 2024-05-21 07:53:01 --> Helper loaded: form_helper
INFO - 2024-05-21 07:53:01 --> Helper loaded: lang_helper
INFO - 2024-05-21 07:53:01 --> Helper loaded: security_helper
INFO - 2024-05-21 07:53:01 --> Helper loaded: cookie_helper
INFO - 2024-05-21 07:53:01 --> Database Driver Class Initialized
INFO - 2024-05-21 07:53:01 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-21 07:53:01 --> Parser Class Initialized
INFO - 2024-05-21 07:53:01 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-05-21 07:53:01 --> Pagination Class Initialized
INFO - 2024-05-21 07:53:01 --> Form Validation Class Initialized
INFO - 2024-05-21 07:53:01 --> Controller Class Initialized
INFO - 2024-05-21 07:53:01 --> Model Class Initialized
DEBUG - 2024-05-21 07:53:01 --> Session class already loaded. Second attempt ignored.
INFO - 2024-05-21 07:53:01 --> Model Class Initialized
DEBUG - 2024-05-21 07:53:01 --> Session class already loaded. Second attempt ignored.
INFO - 2024-05-21 07:53:01 --> Model Class Initialized
INFO - 2024-05-21 07:53:01 --> Model Class Initialized
INFO - 2024-05-21 07:53:01 --> Model Class Initialized
INFO - 2024-05-21 07:53:01 --> Model Class Initialized
DEBUG - 2024-05-21 07:53:01 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-05-21 07:53:01 --> Session class already loaded. Second attempt ignored.
INFO - 2024-05-21 07:53:01 --> Model Class Initialized
INFO - 2024-05-21 07:53:01 --> Model Class Initialized
INFO - 2024-05-21 07:53:01 --> File loaded: /home/u241458058/domains/technoprimex.com/public_html/maurnaturo/application/views/include/admin_home.php
DEBUG - 2024-05-21 07:53:01 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-05-21 07:53:01 --> File loaded: /home/u241458058/domains/technoprimex.com/public_html/maurnaturo/application/views/include/top_menu.php
INFO - 2024-05-21 07:53:01 --> File loaded: /home/u241458058/domains/technoprimex.com/public_html/maurnaturo/application/views/include/admin_loggedin_info.php
INFO - 2024-05-21 07:53:01 --> Model Class Initialized
INFO - 2024-05-21 07:53:01 --> File loaded: /home/u241458058/domains/technoprimex.com/public_html/maurnaturo/application/views/include/admin_header.php
INFO - 2024-05-21 07:53:01 --> File loaded: /home/u241458058/domains/technoprimex.com/public_html/maurnaturo/application/views/include/admin_footer.php
INFO - 2024-05-21 07:53:01 --> File loaded: /home/u241458058/domains/technoprimex.com/public_html/maurnaturo/application/views/admin_html_template.php
INFO - 2024-05-21 07:53:01 --> Final output sent to browser
DEBUG - 2024-05-21 07:53:01 --> Total execution time: 0.2608
ERROR - 2024-05-21 07:53:03 --> $config['composer_autoload'] is set to TRUE but /home/u241458058/domains/technoprimex.com/public_html/maurnaturo/application/vendor/autoload.php was not found.
INFO - 2024-05-21 07:53:03 --> Config Class Initialized
INFO - 2024-05-21 07:53:03 --> Hooks Class Initialized
DEBUG - 2024-05-21 07:53:03 --> UTF-8 Support Enabled
INFO - 2024-05-21 07:53:03 --> Utf8 Class Initialized
INFO - 2024-05-21 07:53:03 --> URI Class Initialized
INFO - 2024-05-21 07:53:03 --> Router Class Initialized
INFO - 2024-05-21 07:53:03 --> Output Class Initialized
INFO - 2024-05-21 07:53:03 --> Security Class Initialized
DEBUG - 2024-05-21 07:53:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-21 07:53:03 --> Input Class Initialized
INFO - 2024-05-21 07:53:03 --> Language Class Initialized
INFO - 2024-05-21 07:53:03 --> Loader Class Initialized
INFO - 2024-05-21 07:53:03 --> Helper loaded: url_helper
INFO - 2024-05-21 07:53:03 --> Helper loaded: file_helper
INFO - 2024-05-21 07:53:03 --> Helper loaded: html_helper
INFO - 2024-05-21 07:53:03 --> Helper loaded: text_helper
INFO - 2024-05-21 07:53:03 --> Helper loaded: form_helper
INFO - 2024-05-21 07:53:03 --> Helper loaded: lang_helper
INFO - 2024-05-21 07:53:03 --> Helper loaded: security_helper
INFO - 2024-05-21 07:53:03 --> Helper loaded: cookie_helper
INFO - 2024-05-21 07:53:03 --> Database Driver Class Initialized
INFO - 2024-05-21 07:53:03 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-21 07:53:03 --> Parser Class Initialized
INFO - 2024-05-21 07:53:03 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-05-21 07:53:03 --> Pagination Class Initialized
INFO - 2024-05-21 07:53:03 --> Form Validation Class Initialized
INFO - 2024-05-21 07:53:03 --> Controller Class Initialized
DEBUG - 2024-05-21 07:53:03 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-05-21 07:53:03 --> Session class already loaded. Second attempt ignored.
INFO - 2024-05-21 07:53:03 --> Model Class Initialized
INFO - 2024-05-21 07:53:03 --> Final output sent to browser
DEBUG - 2024-05-21 07:53:03 --> Total execution time: 0.0074
ERROR - 2024-05-21 07:53:33 --> $config['composer_autoload'] is set to TRUE but /home/u241458058/domains/technoprimex.com/public_html/maurnaturo/application/vendor/autoload.php was not found.
INFO - 2024-05-21 07:53:33 --> Config Class Initialized
INFO - 2024-05-21 07:53:33 --> Hooks Class Initialized
DEBUG - 2024-05-21 07:53:33 --> UTF-8 Support Enabled
INFO - 2024-05-21 07:53:33 --> Utf8 Class Initialized
INFO - 2024-05-21 07:53:33 --> URI Class Initialized
INFO - 2024-05-21 07:53:33 --> Router Class Initialized
INFO - 2024-05-21 07:53:33 --> Output Class Initialized
INFO - 2024-05-21 07:53:33 --> Security Class Initialized
DEBUG - 2024-05-21 07:53:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-21 07:53:33 --> Input Class Initialized
INFO - 2024-05-21 07:53:33 --> Language Class Initialized
INFO - 2024-05-21 07:53:33 --> Loader Class Initialized
INFO - 2024-05-21 07:53:33 --> Helper loaded: url_helper
INFO - 2024-05-21 07:53:33 --> Helper loaded: file_helper
INFO - 2024-05-21 07:53:33 --> Helper loaded: html_helper
INFO - 2024-05-21 07:53:33 --> Helper loaded: text_helper
INFO - 2024-05-21 07:53:33 --> Helper loaded: form_helper
INFO - 2024-05-21 07:53:33 --> Helper loaded: lang_helper
INFO - 2024-05-21 07:53:33 --> Helper loaded: security_helper
INFO - 2024-05-21 07:53:33 --> Helper loaded: cookie_helper
INFO - 2024-05-21 07:53:33 --> Database Driver Class Initialized
INFO - 2024-05-21 07:53:33 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-21 07:53:33 --> Parser Class Initialized
INFO - 2024-05-21 07:53:33 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-05-21 07:53:33 --> Pagination Class Initialized
INFO - 2024-05-21 07:53:33 --> Form Validation Class Initialized
INFO - 2024-05-21 07:53:33 --> Controller Class Initialized
DEBUG - 2024-05-21 07:53:33 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-05-21 07:53:33 --> Session class already loaded. Second attempt ignored.
INFO - 2024-05-21 07:53:33 --> Model Class Initialized
INFO - 2024-05-21 07:53:33 --> Model Class Initialized
DEBUG - 2024-05-21 07:53:33 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-05-21 07:53:33 --> Session class already loaded. Second attempt ignored.
INFO - 2024-05-21 07:53:33 --> Model Class Initialized
DEBUG - 2024-05-21 07:53:33 --> Session class already loaded. Second attempt ignored.
INFO - 2024-05-21 07:53:33 --> File loaded: /home/u241458058/domains/technoprimex.com/public_html/maurnaturo/application/views/gst/list.php
DEBUG - 2024-05-21 07:53:33 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-05-21 07:53:33 --> File loaded: /home/u241458058/domains/technoprimex.com/public_html/maurnaturo/application/views/include/top_menu.php
INFO - 2024-05-21 07:53:33 --> File loaded: /home/u241458058/domains/technoprimex.com/public_html/maurnaturo/application/views/include/admin_loggedin_info.php
INFO - 2024-05-21 07:53:33 --> Model Class Initialized
INFO - 2024-05-21 07:53:33 --> Model Class Initialized
INFO - 2024-05-21 07:53:33 --> Model Class Initialized
INFO - 2024-05-21 07:53:33 --> File loaded: /home/u241458058/domains/technoprimex.com/public_html/maurnaturo/application/views/include/admin_header.php
INFO - 2024-05-21 07:53:33 --> File loaded: /home/u241458058/domains/technoprimex.com/public_html/maurnaturo/application/views/include/admin_footer.php
INFO - 2024-05-21 07:53:33 --> File loaded: /home/u241458058/domains/technoprimex.com/public_html/maurnaturo/application/views/admin_html_template.php
INFO - 2024-05-21 07:53:33 --> Final output sent to browser
DEBUG - 2024-05-21 07:53:33 --> Total execution time: 0.1433
ERROR - 2024-05-21 07:54:07 --> $config['composer_autoload'] is set to TRUE but /home/u241458058/domains/technoprimex.com/public_html/maurnaturo/application/vendor/autoload.php was not found.
INFO - 2024-05-21 07:54:07 --> Config Class Initialized
INFO - 2024-05-21 07:54:07 --> Hooks Class Initialized
DEBUG - 2024-05-21 07:54:07 --> UTF-8 Support Enabled
INFO - 2024-05-21 07:54:07 --> Utf8 Class Initialized
INFO - 2024-05-21 07:54:07 --> URI Class Initialized
INFO - 2024-05-21 07:54:07 --> Router Class Initialized
INFO - 2024-05-21 07:54:07 --> Output Class Initialized
INFO - 2024-05-21 07:54:07 --> Security Class Initialized
DEBUG - 2024-05-21 07:54:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-21 07:54:07 --> Input Class Initialized
INFO - 2024-05-21 07:54:07 --> Language Class Initialized
INFO - 2024-05-21 07:54:07 --> Loader Class Initialized
INFO - 2024-05-21 07:54:07 --> Helper loaded: url_helper
INFO - 2024-05-21 07:54:07 --> Helper loaded: file_helper
INFO - 2024-05-21 07:54:07 --> Helper loaded: html_helper
INFO - 2024-05-21 07:54:07 --> Helper loaded: text_helper
INFO - 2024-05-21 07:54:07 --> Helper loaded: form_helper
INFO - 2024-05-21 07:54:07 --> Helper loaded: lang_helper
INFO - 2024-05-21 07:54:07 --> Helper loaded: security_helper
INFO - 2024-05-21 07:54:07 --> Helper loaded: cookie_helper
INFO - 2024-05-21 07:54:07 --> Database Driver Class Initialized
INFO - 2024-05-21 07:54:07 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-21 07:54:07 --> Parser Class Initialized
INFO - 2024-05-21 07:54:07 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-05-21 07:54:07 --> Pagination Class Initialized
INFO - 2024-05-21 07:54:07 --> Form Validation Class Initialized
INFO - 2024-05-21 07:54:07 --> Controller Class Initialized
INFO - 2024-05-21 07:54:07 --> Model Class Initialized
DEBUG - 2024-05-21 07:54:07 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-05-21 07:54:07 --> Session class already loaded. Second attempt ignored.
INFO - 2024-05-21 07:54:07 --> Model Class Initialized
DEBUG - 2024-05-21 07:54:07 --> Session class already loaded. Second attempt ignored.
INFO - 2024-05-21 07:54:07 --> Model Class Initialized
INFO - 2024-05-21 07:54:07 --> File loaded: /home/u241458058/domains/technoprimex.com/public_html/maurnaturo/application/views/invoice/invoice.php
DEBUG - 2024-05-21 07:54:07 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-05-21 07:54:07 --> File loaded: /home/u241458058/domains/technoprimex.com/public_html/maurnaturo/application/views/include/top_menu.php
INFO - 2024-05-21 07:54:07 --> File loaded: /home/u241458058/domains/technoprimex.com/public_html/maurnaturo/application/views/include/admin_loggedin_info.php
INFO - 2024-05-21 07:54:07 --> Model Class Initialized
INFO - 2024-05-21 07:54:07 --> Model Class Initialized
INFO - 2024-05-21 07:54:07 --> Model Class Initialized
INFO - 2024-05-21 07:54:07 --> File loaded: /home/u241458058/domains/technoprimex.com/public_html/maurnaturo/application/views/include/admin_header.php
INFO - 2024-05-21 07:54:07 --> File loaded: /home/u241458058/domains/technoprimex.com/public_html/maurnaturo/application/views/include/admin_footer.php
INFO - 2024-05-21 07:54:07 --> File loaded: /home/u241458058/domains/technoprimex.com/public_html/maurnaturo/application/views/admin_html_template.php
INFO - 2024-05-21 07:54:07 --> Final output sent to browser
DEBUG - 2024-05-21 07:54:07 --> Total execution time: 0.1426
ERROR - 2024-05-21 07:54:08 --> $config['composer_autoload'] is set to TRUE but /home/u241458058/domains/technoprimex.com/public_html/maurnaturo/application/vendor/autoload.php was not found.
INFO - 2024-05-21 07:54:08 --> Config Class Initialized
INFO - 2024-05-21 07:54:08 --> Hooks Class Initialized
DEBUG - 2024-05-21 07:54:08 --> UTF-8 Support Enabled
INFO - 2024-05-21 07:54:08 --> Utf8 Class Initialized
INFO - 2024-05-21 07:54:08 --> URI Class Initialized
INFO - 2024-05-21 07:54:08 --> Router Class Initialized
INFO - 2024-05-21 07:54:08 --> Output Class Initialized
INFO - 2024-05-21 07:54:08 --> Security Class Initialized
DEBUG - 2024-05-21 07:54:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-21 07:54:08 --> Input Class Initialized
INFO - 2024-05-21 07:54:08 --> Language Class Initialized
INFO - 2024-05-21 07:54:08 --> Loader Class Initialized
INFO - 2024-05-21 07:54:08 --> Helper loaded: url_helper
INFO - 2024-05-21 07:54:08 --> Helper loaded: file_helper
INFO - 2024-05-21 07:54:08 --> Helper loaded: html_helper
INFO - 2024-05-21 07:54:08 --> Helper loaded: text_helper
INFO - 2024-05-21 07:54:08 --> Helper loaded: form_helper
INFO - 2024-05-21 07:54:08 --> Helper loaded: lang_helper
INFO - 2024-05-21 07:54:08 --> Helper loaded: security_helper
INFO - 2024-05-21 07:54:08 --> Helper loaded: cookie_helper
INFO - 2024-05-21 07:54:08 --> Database Driver Class Initialized
INFO - 2024-05-21 07:54:08 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-21 07:54:08 --> Parser Class Initialized
INFO - 2024-05-21 07:54:08 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-05-21 07:54:08 --> Pagination Class Initialized
INFO - 2024-05-21 07:54:08 --> Form Validation Class Initialized
INFO - 2024-05-21 07:54:08 --> Controller Class Initialized
INFO - 2024-05-21 07:54:08 --> Model Class Initialized
DEBUG - 2024-05-21 07:54:08 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-05-21 07:54:08 --> Session class already loaded. Second attempt ignored.
INFO - 2024-05-21 07:54:08 --> Model Class Initialized
DEBUG - 2024-05-21 07:54:08 --> Session class already loaded. Second attempt ignored.
INFO - 2024-05-21 07:54:08 --> Model Class Initialized
INFO - 2024-05-21 07:54:08 --> Final output sent to browser
DEBUG - 2024-05-21 07:54:08 --> Total execution time: 0.0377
ERROR - 2024-05-21 07:54:12 --> $config['composer_autoload'] is set to TRUE but /home/u241458058/domains/technoprimex.com/public_html/maurnaturo/application/vendor/autoload.php was not found.
INFO - 2024-05-21 07:54:12 --> Config Class Initialized
INFO - 2024-05-21 07:54:12 --> Hooks Class Initialized
DEBUG - 2024-05-21 07:54:12 --> UTF-8 Support Enabled
INFO - 2024-05-21 07:54:12 --> Utf8 Class Initialized
INFO - 2024-05-21 07:54:12 --> URI Class Initialized
INFO - 2024-05-21 07:54:12 --> Router Class Initialized
INFO - 2024-05-21 07:54:12 --> Output Class Initialized
INFO - 2024-05-21 07:54:12 --> Security Class Initialized
DEBUG - 2024-05-21 07:54:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-21 07:54:12 --> Input Class Initialized
INFO - 2024-05-21 07:54:12 --> Language Class Initialized
INFO - 2024-05-21 07:54:12 --> Loader Class Initialized
INFO - 2024-05-21 07:54:12 --> Helper loaded: url_helper
INFO - 2024-05-21 07:54:12 --> Helper loaded: file_helper
INFO - 2024-05-21 07:54:12 --> Helper loaded: html_helper
INFO - 2024-05-21 07:54:12 --> Helper loaded: text_helper
INFO - 2024-05-21 07:54:12 --> Helper loaded: form_helper
INFO - 2024-05-21 07:54:12 --> Helper loaded: lang_helper
INFO - 2024-05-21 07:54:12 --> Helper loaded: security_helper
INFO - 2024-05-21 07:54:12 --> Helper loaded: cookie_helper
INFO - 2024-05-21 07:54:12 --> Database Driver Class Initialized
INFO - 2024-05-21 07:54:12 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-21 07:54:12 --> Parser Class Initialized
INFO - 2024-05-21 07:54:12 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-05-21 07:54:12 --> Pagination Class Initialized
INFO - 2024-05-21 07:54:12 --> Form Validation Class Initialized
INFO - 2024-05-21 07:54:12 --> Controller Class Initialized
INFO - 2024-05-21 07:54:12 --> Model Class Initialized
DEBUG - 2024-05-21 07:54:12 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-05-21 07:54:12 --> Session class already loaded. Second attempt ignored.
INFO - 2024-05-21 07:54:12 --> Model Class Initialized
DEBUG - 2024-05-21 07:54:12 --> Session class already loaded. Second attempt ignored.
INFO - 2024-05-21 07:54:12 --> Model Class Initialized
INFO - 2024-05-21 07:54:12 --> File loaded: /home/u241458058/domains/technoprimex.com/public_html/maurnaturo/application/views/proformainvoice/add_invoice_form.php
DEBUG - 2024-05-21 07:54:12 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-05-21 07:54:12 --> File loaded: /home/u241458058/domains/technoprimex.com/public_html/maurnaturo/application/views/include/top_menu.php
INFO - 2024-05-21 07:54:12 --> File loaded: /home/u241458058/domains/technoprimex.com/public_html/maurnaturo/application/views/include/admin_loggedin_info.php
INFO - 2024-05-21 07:54:12 --> Model Class Initialized
INFO - 2024-05-21 07:54:12 --> Model Class Initialized
INFO - 2024-05-21 07:54:12 --> Model Class Initialized
INFO - 2024-05-21 07:54:12 --> File loaded: /home/u241458058/domains/technoprimex.com/public_html/maurnaturo/application/views/include/admin_header.php
INFO - 2024-05-21 07:54:12 --> File loaded: /home/u241458058/domains/technoprimex.com/public_html/maurnaturo/application/views/include/admin_footer.php
INFO - 2024-05-21 07:54:12 --> File loaded: /home/u241458058/domains/technoprimex.com/public_html/maurnaturo/application/views/admin_html_template.php
INFO - 2024-05-21 07:54:12 --> Final output sent to browser
DEBUG - 2024-05-21 07:54:12 --> Total execution time: 0.1662
ERROR - 2024-05-21 07:56:15 --> $config['composer_autoload'] is set to TRUE but /home/u241458058/domains/technoprimex.com/public_html/maurnaturo/application/vendor/autoload.php was not found.
INFO - 2024-05-21 07:56:15 --> Config Class Initialized
INFO - 2024-05-21 07:56:15 --> Hooks Class Initialized
DEBUG - 2024-05-21 07:56:15 --> UTF-8 Support Enabled
INFO - 2024-05-21 07:56:15 --> Utf8 Class Initialized
INFO - 2024-05-21 07:56:15 --> URI Class Initialized
INFO - 2024-05-21 07:56:15 --> Router Class Initialized
INFO - 2024-05-21 07:56:15 --> Output Class Initialized
INFO - 2024-05-21 07:56:15 --> Security Class Initialized
DEBUG - 2024-05-21 07:56:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-21 07:56:15 --> Input Class Initialized
INFO - 2024-05-21 07:56:15 --> Language Class Initialized
INFO - 2024-05-21 07:56:15 --> Loader Class Initialized
INFO - 2024-05-21 07:56:15 --> Helper loaded: url_helper
INFO - 2024-05-21 07:56:15 --> Helper loaded: file_helper
INFO - 2024-05-21 07:56:15 --> Helper loaded: html_helper
INFO - 2024-05-21 07:56:15 --> Helper loaded: text_helper
INFO - 2024-05-21 07:56:15 --> Helper loaded: form_helper
INFO - 2024-05-21 07:56:15 --> Helper loaded: lang_helper
INFO - 2024-05-21 07:56:15 --> Helper loaded: security_helper
INFO - 2024-05-21 07:56:15 --> Helper loaded: cookie_helper
INFO - 2024-05-21 07:56:15 --> Database Driver Class Initialized
INFO - 2024-05-21 07:56:15 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-21 07:56:15 --> Parser Class Initialized
INFO - 2024-05-21 07:56:15 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-05-21 07:56:15 --> Pagination Class Initialized
INFO - 2024-05-21 07:56:15 --> Form Validation Class Initialized
INFO - 2024-05-21 07:56:15 --> Controller Class Initialized
DEBUG - 2024-05-21 07:56:15 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-05-21 07:56:15 --> Session class already loaded. Second attempt ignored.
INFO - 2024-05-21 07:56:15 --> Model Class Initialized
DEBUG - 2024-05-21 07:56:15 --> Lpayments class already loaded. Second attempt ignored.
INFO - 2024-05-21 07:56:15 --> Model Class Initialized
INFO - 2024-05-21 07:56:15 --> File loaded: /home/u241458058/domains/technoprimex.com/public_html/maurnaturo/application/views/payments/payment.php
DEBUG - 2024-05-21 07:56:15 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-05-21 07:56:15 --> File loaded: /home/u241458058/domains/technoprimex.com/public_html/maurnaturo/application/views/include/top_menu.php
INFO - 2024-05-21 07:56:15 --> File loaded: /home/u241458058/domains/technoprimex.com/public_html/maurnaturo/application/views/include/admin_loggedin_info.php
INFO - 2024-05-21 07:56:15 --> Model Class Initialized
INFO - 2024-05-21 07:56:15 --> Model Class Initialized
INFO - 2024-05-21 07:56:15 --> Model Class Initialized
INFO - 2024-05-21 07:56:15 --> File loaded: /home/u241458058/domains/technoprimex.com/public_html/maurnaturo/application/views/include/admin_header.php
INFO - 2024-05-21 07:56:15 --> File loaded: /home/u241458058/domains/technoprimex.com/public_html/maurnaturo/application/views/include/admin_footer.php
INFO - 2024-05-21 07:56:15 --> File loaded: /home/u241458058/domains/technoprimex.com/public_html/maurnaturo/application/views/admin_html_template.php
INFO - 2024-05-21 07:56:15 --> Final output sent to browser
DEBUG - 2024-05-21 07:56:15 --> Total execution time: 0.1327
ERROR - 2024-05-21 07:56:16 --> $config['composer_autoload'] is set to TRUE but /home/u241458058/domains/technoprimex.com/public_html/maurnaturo/application/vendor/autoload.php was not found.
INFO - 2024-05-21 07:56:16 --> Config Class Initialized
INFO - 2024-05-21 07:56:16 --> Hooks Class Initialized
DEBUG - 2024-05-21 07:56:16 --> UTF-8 Support Enabled
INFO - 2024-05-21 07:56:16 --> Utf8 Class Initialized
INFO - 2024-05-21 07:56:16 --> URI Class Initialized
INFO - 2024-05-21 07:56:16 --> Router Class Initialized
INFO - 2024-05-21 07:56:16 --> Output Class Initialized
INFO - 2024-05-21 07:56:16 --> Security Class Initialized
DEBUG - 2024-05-21 07:56:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-21 07:56:16 --> Input Class Initialized
INFO - 2024-05-21 07:56:16 --> Language Class Initialized
INFO - 2024-05-21 07:56:16 --> Loader Class Initialized
INFO - 2024-05-21 07:56:16 --> Helper loaded: url_helper
INFO - 2024-05-21 07:56:16 --> Helper loaded: file_helper
INFO - 2024-05-21 07:56:16 --> Helper loaded: html_helper
INFO - 2024-05-21 07:56:16 --> Helper loaded: text_helper
INFO - 2024-05-21 07:56:16 --> Helper loaded: form_helper
INFO - 2024-05-21 07:56:16 --> Helper loaded: lang_helper
INFO - 2024-05-21 07:56:16 --> Helper loaded: security_helper
INFO - 2024-05-21 07:56:16 --> Helper loaded: cookie_helper
INFO - 2024-05-21 07:56:16 --> Database Driver Class Initialized
INFO - 2024-05-21 07:56:16 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-21 07:56:16 --> Parser Class Initialized
INFO - 2024-05-21 07:56:16 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-05-21 07:56:16 --> Pagination Class Initialized
INFO - 2024-05-21 07:56:16 --> Form Validation Class Initialized
INFO - 2024-05-21 07:56:16 --> Controller Class Initialized
DEBUG - 2024-05-21 07:56:16 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-05-21 07:56:16 --> Session class already loaded. Second attempt ignored.
INFO - 2024-05-21 07:56:16 --> Model Class Initialized
INFO - 2024-05-21 07:56:16 --> Final output sent to browser
DEBUG - 2024-05-21 07:56:16 --> Total execution time: 0.0068
ERROR - 2024-05-21 07:56:17 --> $config['composer_autoload'] is set to TRUE but /home/u241458058/domains/technoprimex.com/public_html/maurnaturo/application/vendor/autoload.php was not found.
INFO - 2024-05-21 07:56:17 --> Config Class Initialized
INFO - 2024-05-21 07:56:17 --> Hooks Class Initialized
DEBUG - 2024-05-21 07:56:17 --> UTF-8 Support Enabled
INFO - 2024-05-21 07:56:17 --> Utf8 Class Initialized
INFO - 2024-05-21 07:56:17 --> URI Class Initialized
INFO - 2024-05-21 07:56:17 --> Router Class Initialized
INFO - 2024-05-21 07:56:17 --> Output Class Initialized
INFO - 2024-05-21 07:56:17 --> Security Class Initialized
DEBUG - 2024-05-21 07:56:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-21 07:56:17 --> Input Class Initialized
INFO - 2024-05-21 07:56:17 --> Language Class Initialized
INFO - 2024-05-21 07:56:17 --> Loader Class Initialized
INFO - 2024-05-21 07:56:17 --> Helper loaded: url_helper
INFO - 2024-05-21 07:56:17 --> Helper loaded: file_helper
INFO - 2024-05-21 07:56:17 --> Helper loaded: html_helper
INFO - 2024-05-21 07:56:17 --> Helper loaded: text_helper
INFO - 2024-05-21 07:56:17 --> Helper loaded: form_helper
INFO - 2024-05-21 07:56:17 --> Helper loaded: lang_helper
INFO - 2024-05-21 07:56:17 --> Helper loaded: security_helper
INFO - 2024-05-21 07:56:17 --> Helper loaded: cookie_helper
INFO - 2024-05-21 07:56:17 --> Database Driver Class Initialized
INFO - 2024-05-21 07:56:17 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-21 07:56:17 --> Parser Class Initialized
INFO - 2024-05-21 07:56:17 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-05-21 07:56:17 --> Pagination Class Initialized
INFO - 2024-05-21 07:56:17 --> Form Validation Class Initialized
INFO - 2024-05-21 07:56:17 --> Controller Class Initialized
DEBUG - 2024-05-21 07:56:17 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-05-21 07:56:17 --> Session class already loaded. Second attempt ignored.
INFO - 2024-05-21 07:56:17 --> Model Class Initialized
INFO - 2024-05-21 07:56:17 --> Model Class Initialized
DEBUG - 2024-05-21 07:56:17 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-05-21 07:56:17 --> Session class already loaded. Second attempt ignored.
INFO - 2024-05-21 07:56:17 --> File loaded: /home/u241458058/domains/technoprimex.com/public_html/maurnaturo/application/views/payments/add_payment_form.php
DEBUG - 2024-05-21 07:56:17 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-05-21 07:56:17 --> File loaded: /home/u241458058/domains/technoprimex.com/public_html/maurnaturo/application/views/include/top_menu.php
INFO - 2024-05-21 07:56:17 --> File loaded: /home/u241458058/domains/technoprimex.com/public_html/maurnaturo/application/views/include/admin_loggedin_info.php
INFO - 2024-05-21 07:56:17 --> Model Class Initialized
INFO - 2024-05-21 07:56:18 --> Model Class Initialized
INFO - 2024-05-21 07:56:18 --> Model Class Initialized
INFO - 2024-05-21 07:56:18 --> Model Class Initialized
INFO - 2024-05-21 07:56:18 --> File loaded: /home/u241458058/domains/technoprimex.com/public_html/maurnaturo/application/views/include/admin_header.php
INFO - 2024-05-21 07:56:18 --> File loaded: /home/u241458058/domains/technoprimex.com/public_html/maurnaturo/application/views/include/admin_footer.php
INFO - 2024-05-21 07:56:18 --> File loaded: /home/u241458058/domains/technoprimex.com/public_html/maurnaturo/application/views/admin_html_template.php
INFO - 2024-05-21 07:56:18 --> Final output sent to browser
DEBUG - 2024-05-21 07:56:18 --> Total execution time: 0.1392
ERROR - 2024-05-21 07:56:31 --> $config['composer_autoload'] is set to TRUE but /home/u241458058/domains/technoprimex.com/public_html/maurnaturo/application/vendor/autoload.php was not found.
INFO - 2024-05-21 07:56:31 --> Config Class Initialized
INFO - 2024-05-21 07:56:31 --> Hooks Class Initialized
DEBUG - 2024-05-21 07:56:31 --> UTF-8 Support Enabled
INFO - 2024-05-21 07:56:31 --> Utf8 Class Initialized
INFO - 2024-05-21 07:56:31 --> URI Class Initialized
INFO - 2024-05-21 07:56:31 --> Router Class Initialized
INFO - 2024-05-21 07:56:31 --> Output Class Initialized
INFO - 2024-05-21 07:56:31 --> Security Class Initialized
DEBUG - 2024-05-21 07:56:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-21 07:56:31 --> Input Class Initialized
INFO - 2024-05-21 07:56:31 --> Language Class Initialized
INFO - 2024-05-21 07:56:31 --> Loader Class Initialized
INFO - 2024-05-21 07:56:31 --> Helper loaded: url_helper
INFO - 2024-05-21 07:56:31 --> Helper loaded: file_helper
INFO - 2024-05-21 07:56:31 --> Helper loaded: html_helper
INFO - 2024-05-21 07:56:31 --> Helper loaded: text_helper
INFO - 2024-05-21 07:56:31 --> Helper loaded: form_helper
INFO - 2024-05-21 07:56:31 --> Helper loaded: lang_helper
INFO - 2024-05-21 07:56:31 --> Helper loaded: security_helper
INFO - 2024-05-21 07:56:31 --> Helper loaded: cookie_helper
INFO - 2024-05-21 07:56:31 --> Database Driver Class Initialized
INFO - 2024-05-21 07:56:31 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-21 07:56:31 --> Parser Class Initialized
INFO - 2024-05-21 07:56:31 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-05-21 07:56:31 --> Pagination Class Initialized
INFO - 2024-05-21 07:56:31 --> Form Validation Class Initialized
INFO - 2024-05-21 07:56:31 --> Controller Class Initialized
INFO - 2024-05-21 07:56:31 --> Model Class Initialized
DEBUG - 2024-05-21 07:56:31 --> Session class already loaded. Second attempt ignored.
INFO - 2024-05-21 07:56:31 --> Final output sent to browser
DEBUG - 2024-05-21 07:56:31 --> Total execution time: 0.0095
ERROR - 2024-05-21 07:56:58 --> $config['composer_autoload'] is set to TRUE but /home/u241458058/domains/technoprimex.com/public_html/maurnaturo/application/vendor/autoload.php was not found.
INFO - 2024-05-21 07:56:58 --> Config Class Initialized
INFO - 2024-05-21 07:56:58 --> Hooks Class Initialized
DEBUG - 2024-05-21 07:56:58 --> UTF-8 Support Enabled
INFO - 2024-05-21 07:56:58 --> Utf8 Class Initialized
INFO - 2024-05-21 07:56:58 --> URI Class Initialized
INFO - 2024-05-21 07:56:58 --> Router Class Initialized
INFO - 2024-05-21 07:56:58 --> Output Class Initialized
INFO - 2024-05-21 07:56:58 --> Security Class Initialized
DEBUG - 2024-05-21 07:56:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-21 07:56:58 --> Input Class Initialized
INFO - 2024-05-21 07:56:58 --> Language Class Initialized
INFO - 2024-05-21 07:56:58 --> Loader Class Initialized
INFO - 2024-05-21 07:56:58 --> Helper loaded: url_helper
INFO - 2024-05-21 07:56:58 --> Helper loaded: file_helper
INFO - 2024-05-21 07:56:58 --> Helper loaded: html_helper
INFO - 2024-05-21 07:56:58 --> Helper loaded: text_helper
INFO - 2024-05-21 07:56:58 --> Helper loaded: form_helper
INFO - 2024-05-21 07:56:58 --> Helper loaded: lang_helper
INFO - 2024-05-21 07:56:58 --> Helper loaded: security_helper
INFO - 2024-05-21 07:56:58 --> Helper loaded: cookie_helper
INFO - 2024-05-21 07:56:58 --> Database Driver Class Initialized
INFO - 2024-05-21 07:56:58 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-21 07:56:58 --> Parser Class Initialized
INFO - 2024-05-21 07:56:58 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-05-21 07:56:58 --> Pagination Class Initialized
INFO - 2024-05-21 07:56:58 --> Form Validation Class Initialized
INFO - 2024-05-21 07:56:58 --> Controller Class Initialized
DEBUG - 2024-05-21 07:56:58 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-05-21 07:56:58 --> Session class already loaded. Second attempt ignored.
INFO - 2024-05-21 07:56:58 --> Model Class Initialized
INFO - 2024-05-21 07:56:58 --> Model Class Initialized
DEBUG - 2024-05-21 07:56:58 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-05-21 07:56:58 --> Session class already loaded. Second attempt ignored.
INFO - 2024-05-21 07:56:58 --> File loaded: /home/u241458058/domains/technoprimex.com/public_html/maurnaturo/application/views/expenses/add_expenses_form.php
DEBUG - 2024-05-21 07:56:58 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-05-21 07:56:58 --> File loaded: /home/u241458058/domains/technoprimex.com/public_html/maurnaturo/application/views/include/top_menu.php
INFO - 2024-05-21 07:56:58 --> File loaded: /home/u241458058/domains/technoprimex.com/public_html/maurnaturo/application/views/include/admin_loggedin_info.php
INFO - 2024-05-21 07:56:58 --> Model Class Initialized
INFO - 2024-05-21 07:56:58 --> Model Class Initialized
INFO - 2024-05-21 07:56:58 --> Model Class Initialized
INFO - 2024-05-21 07:56:58 --> Model Class Initialized
INFO - 2024-05-21 07:56:58 --> File loaded: /home/u241458058/domains/technoprimex.com/public_html/maurnaturo/application/views/include/admin_header.php
INFO - 2024-05-21 07:56:58 --> File loaded: /home/u241458058/domains/technoprimex.com/public_html/maurnaturo/application/views/include/admin_footer.php
INFO - 2024-05-21 07:56:58 --> File loaded: /home/u241458058/domains/technoprimex.com/public_html/maurnaturo/application/views/admin_html_template.php
INFO - 2024-05-21 07:56:58 --> Final output sent to browser
DEBUG - 2024-05-21 07:56:58 --> Total execution time: 0.1569
ERROR - 2024-05-21 07:57:04 --> $config['composer_autoload'] is set to TRUE but /home/u241458058/domains/technoprimex.com/public_html/maurnaturo/application/vendor/autoload.php was not found.
INFO - 2024-05-21 07:57:04 --> Config Class Initialized
INFO - 2024-05-21 07:57:04 --> Hooks Class Initialized
DEBUG - 2024-05-21 07:57:04 --> UTF-8 Support Enabled
INFO - 2024-05-21 07:57:04 --> Utf8 Class Initialized
INFO - 2024-05-21 07:57:04 --> URI Class Initialized
INFO - 2024-05-21 07:57:04 --> Router Class Initialized
INFO - 2024-05-21 07:57:04 --> Output Class Initialized
INFO - 2024-05-21 07:57:04 --> Security Class Initialized
DEBUG - 2024-05-21 07:57:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-21 07:57:04 --> Input Class Initialized
INFO - 2024-05-21 07:57:04 --> Language Class Initialized
INFO - 2024-05-21 07:57:04 --> Loader Class Initialized
INFO - 2024-05-21 07:57:04 --> Helper loaded: url_helper
INFO - 2024-05-21 07:57:04 --> Helper loaded: file_helper
INFO - 2024-05-21 07:57:04 --> Helper loaded: html_helper
INFO - 2024-05-21 07:57:04 --> Helper loaded: text_helper
INFO - 2024-05-21 07:57:04 --> Helper loaded: form_helper
INFO - 2024-05-21 07:57:04 --> Helper loaded: lang_helper
INFO - 2024-05-21 07:57:04 --> Helper loaded: security_helper
INFO - 2024-05-21 07:57:04 --> Helper loaded: cookie_helper
INFO - 2024-05-21 07:57:04 --> Database Driver Class Initialized
INFO - 2024-05-21 07:57:04 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-21 07:57:04 --> Parser Class Initialized
INFO - 2024-05-21 07:57:04 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-05-21 07:57:04 --> Pagination Class Initialized
INFO - 2024-05-21 07:57:04 --> Form Validation Class Initialized
INFO - 2024-05-21 07:57:04 --> Controller Class Initialized
DEBUG - 2024-05-21 07:57:04 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-05-21 07:57:04 --> Session class already loaded. Second attempt ignored.
INFO - 2024-05-21 07:57:04 --> Model Class Initialized
DEBUG - 2024-05-21 07:57:04 --> Lexpenses class already loaded. Second attempt ignored.
INFO - 2024-05-21 07:57:04 --> Model Class Initialized
INFO - 2024-05-21 07:57:04 --> File loaded: /home/u241458058/domains/technoprimex.com/public_html/maurnaturo/application/views/expenses/expenses.php
DEBUG - 2024-05-21 07:57:04 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-05-21 07:57:04 --> File loaded: /home/u241458058/domains/technoprimex.com/public_html/maurnaturo/application/views/include/top_menu.php
INFO - 2024-05-21 07:57:04 --> File loaded: /home/u241458058/domains/technoprimex.com/public_html/maurnaturo/application/views/include/admin_loggedin_info.php
INFO - 2024-05-21 07:57:04 --> Model Class Initialized
INFO - 2024-05-21 07:57:04 --> Model Class Initialized
INFO - 2024-05-21 07:57:04 --> Model Class Initialized
INFO - 2024-05-21 07:57:04 --> File loaded: /home/u241458058/domains/technoprimex.com/public_html/maurnaturo/application/views/include/admin_header.php
INFO - 2024-05-21 07:57:04 --> File loaded: /home/u241458058/domains/technoprimex.com/public_html/maurnaturo/application/views/include/admin_footer.php
INFO - 2024-05-21 07:57:04 --> File loaded: /home/u241458058/domains/technoprimex.com/public_html/maurnaturo/application/views/admin_html_template.php
INFO - 2024-05-21 07:57:04 --> Final output sent to browser
DEBUG - 2024-05-21 07:57:04 --> Total execution time: 0.1424
ERROR - 2024-05-21 07:57:05 --> $config['composer_autoload'] is set to TRUE but /home/u241458058/domains/technoprimex.com/public_html/maurnaturo/application/vendor/autoload.php was not found.
INFO - 2024-05-21 07:57:05 --> Config Class Initialized
INFO - 2024-05-21 07:57:05 --> Hooks Class Initialized
DEBUG - 2024-05-21 07:57:05 --> UTF-8 Support Enabled
INFO - 2024-05-21 07:57:05 --> Utf8 Class Initialized
INFO - 2024-05-21 07:57:05 --> URI Class Initialized
INFO - 2024-05-21 07:57:05 --> Router Class Initialized
INFO - 2024-05-21 07:57:05 --> Output Class Initialized
INFO - 2024-05-21 07:57:05 --> Security Class Initialized
DEBUG - 2024-05-21 07:57:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-21 07:57:05 --> Input Class Initialized
INFO - 2024-05-21 07:57:05 --> Language Class Initialized
INFO - 2024-05-21 07:57:05 --> Loader Class Initialized
INFO - 2024-05-21 07:57:05 --> Helper loaded: url_helper
INFO - 2024-05-21 07:57:05 --> Helper loaded: file_helper
INFO - 2024-05-21 07:57:05 --> Helper loaded: html_helper
INFO - 2024-05-21 07:57:05 --> Helper loaded: text_helper
INFO - 2024-05-21 07:57:05 --> Helper loaded: form_helper
INFO - 2024-05-21 07:57:05 --> Helper loaded: lang_helper
INFO - 2024-05-21 07:57:05 --> Helper loaded: security_helper
INFO - 2024-05-21 07:57:05 --> Helper loaded: cookie_helper
INFO - 2024-05-21 07:57:05 --> Database Driver Class Initialized
INFO - 2024-05-21 07:57:05 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-21 07:57:05 --> Parser Class Initialized
INFO - 2024-05-21 07:57:05 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-05-21 07:57:05 --> Pagination Class Initialized
INFO - 2024-05-21 07:57:05 --> Form Validation Class Initialized
INFO - 2024-05-21 07:57:05 --> Controller Class Initialized
DEBUG - 2024-05-21 07:57:05 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-05-21 07:57:05 --> Session class already loaded. Second attempt ignored.
INFO - 2024-05-21 07:57:05 --> Model Class Initialized
INFO - 2024-05-21 07:57:05 --> Final output sent to browser
DEBUG - 2024-05-21 07:57:05 --> Total execution time: 0.0073
ERROR - 2024-05-21 07:57:08 --> $config['composer_autoload'] is set to TRUE but /home/u241458058/domains/technoprimex.com/public_html/maurnaturo/application/vendor/autoload.php was not found.
INFO - 2024-05-21 07:57:08 --> Config Class Initialized
INFO - 2024-05-21 07:57:08 --> Hooks Class Initialized
DEBUG - 2024-05-21 07:57:08 --> UTF-8 Support Enabled
INFO - 2024-05-21 07:57:08 --> Utf8 Class Initialized
INFO - 2024-05-21 07:57:08 --> URI Class Initialized
INFO - 2024-05-21 07:57:08 --> Router Class Initialized
INFO - 2024-05-21 07:57:08 --> Output Class Initialized
INFO - 2024-05-21 07:57:08 --> Security Class Initialized
DEBUG - 2024-05-21 07:57:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-21 07:57:08 --> Input Class Initialized
INFO - 2024-05-21 07:57:08 --> Language Class Initialized
ERROR - 2024-05-21 07:57:08 --> 404 Page Not Found: Cexpenses/expenses_view_form
ERROR - 2024-05-21 07:57:10 --> $config['composer_autoload'] is set to TRUE but /home/u241458058/domains/technoprimex.com/public_html/maurnaturo/application/vendor/autoload.php was not found.
INFO - 2024-05-21 07:57:10 --> Config Class Initialized
INFO - 2024-05-21 07:57:10 --> Hooks Class Initialized
DEBUG - 2024-05-21 07:57:10 --> UTF-8 Support Enabled
INFO - 2024-05-21 07:57:10 --> Utf8 Class Initialized
INFO - 2024-05-21 07:57:10 --> URI Class Initialized
INFO - 2024-05-21 07:57:10 --> Router Class Initialized
INFO - 2024-05-21 07:57:10 --> Output Class Initialized
INFO - 2024-05-21 07:57:10 --> Security Class Initialized
DEBUG - 2024-05-21 07:57:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-21 07:57:10 --> Input Class Initialized
INFO - 2024-05-21 07:57:10 --> Language Class Initialized
INFO - 2024-05-21 07:57:10 --> Loader Class Initialized
INFO - 2024-05-21 07:57:10 --> Helper loaded: url_helper
INFO - 2024-05-21 07:57:10 --> Helper loaded: file_helper
INFO - 2024-05-21 07:57:10 --> Helper loaded: html_helper
INFO - 2024-05-21 07:57:10 --> Helper loaded: text_helper
INFO - 2024-05-21 07:57:10 --> Helper loaded: form_helper
INFO - 2024-05-21 07:57:10 --> Helper loaded: lang_helper
INFO - 2024-05-21 07:57:10 --> Helper loaded: security_helper
INFO - 2024-05-21 07:57:10 --> Helper loaded: cookie_helper
INFO - 2024-05-21 07:57:10 --> Database Driver Class Initialized
INFO - 2024-05-21 07:57:10 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-21 07:57:10 --> Parser Class Initialized
INFO - 2024-05-21 07:57:10 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-05-21 07:57:10 --> Pagination Class Initialized
INFO - 2024-05-21 07:57:10 --> Form Validation Class Initialized
INFO - 2024-05-21 07:57:10 --> Controller Class Initialized
DEBUG - 2024-05-21 07:57:10 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-05-21 07:57:10 --> Session class already loaded. Second attempt ignored.
INFO - 2024-05-21 07:57:10 --> Model Class Initialized
DEBUG - 2024-05-21 07:57:10 --> Lexpenses class already loaded. Second attempt ignored.
INFO - 2024-05-21 07:57:10 --> Model Class Initialized
INFO - 2024-05-21 07:57:10 --> File loaded: /home/u241458058/domains/technoprimex.com/public_html/maurnaturo/application/views/expenses/expenses.php
DEBUG - 2024-05-21 07:57:10 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-05-21 07:57:10 --> File loaded: /home/u241458058/domains/technoprimex.com/public_html/maurnaturo/application/views/include/top_menu.php
INFO - 2024-05-21 07:57:10 --> File loaded: /home/u241458058/domains/technoprimex.com/public_html/maurnaturo/application/views/include/admin_loggedin_info.php
INFO - 2024-05-21 07:57:10 --> Model Class Initialized
INFO - 2024-05-21 07:57:10 --> Model Class Initialized
INFO - 2024-05-21 07:57:10 --> Model Class Initialized
INFO - 2024-05-21 07:57:10 --> File loaded: /home/u241458058/domains/technoprimex.com/public_html/maurnaturo/application/views/include/admin_header.php
INFO - 2024-05-21 07:57:10 --> File loaded: /home/u241458058/domains/technoprimex.com/public_html/maurnaturo/application/views/include/admin_footer.php
INFO - 2024-05-21 07:57:10 --> File loaded: /home/u241458058/domains/technoprimex.com/public_html/maurnaturo/application/views/admin_html_template.php
INFO - 2024-05-21 07:57:10 --> Final output sent to browser
DEBUG - 2024-05-21 07:57:10 --> Total execution time: 0.1493
ERROR - 2024-05-21 07:57:11 --> $config['composer_autoload'] is set to TRUE but /home/u241458058/domains/technoprimex.com/public_html/maurnaturo/application/vendor/autoload.php was not found.
INFO - 2024-05-21 07:57:11 --> Config Class Initialized
INFO - 2024-05-21 07:57:11 --> Hooks Class Initialized
DEBUG - 2024-05-21 07:57:11 --> UTF-8 Support Enabled
INFO - 2024-05-21 07:57:11 --> Utf8 Class Initialized
INFO - 2024-05-21 07:57:11 --> URI Class Initialized
INFO - 2024-05-21 07:57:11 --> Router Class Initialized
INFO - 2024-05-21 07:57:11 --> Output Class Initialized
INFO - 2024-05-21 07:57:11 --> Security Class Initialized
DEBUG - 2024-05-21 07:57:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-21 07:57:11 --> Input Class Initialized
INFO - 2024-05-21 07:57:11 --> Language Class Initialized
INFO - 2024-05-21 07:57:11 --> Loader Class Initialized
INFO - 2024-05-21 07:57:11 --> Helper loaded: url_helper
INFO - 2024-05-21 07:57:11 --> Helper loaded: file_helper
INFO - 2024-05-21 07:57:11 --> Helper loaded: html_helper
INFO - 2024-05-21 07:57:11 --> Helper loaded: text_helper
INFO - 2024-05-21 07:57:11 --> Helper loaded: form_helper
INFO - 2024-05-21 07:57:11 --> Helper loaded: lang_helper
INFO - 2024-05-21 07:57:11 --> Helper loaded: security_helper
INFO - 2024-05-21 07:57:11 --> Helper loaded: cookie_helper
INFO - 2024-05-21 07:57:11 --> Database Driver Class Initialized
INFO - 2024-05-21 07:57:11 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-21 07:57:11 --> Parser Class Initialized
INFO - 2024-05-21 07:57:11 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-05-21 07:57:11 --> Pagination Class Initialized
INFO - 2024-05-21 07:57:11 --> Form Validation Class Initialized
INFO - 2024-05-21 07:57:11 --> Controller Class Initialized
DEBUG - 2024-05-21 07:57:11 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-05-21 07:57:11 --> Session class already loaded. Second attempt ignored.
INFO - 2024-05-21 07:57:11 --> Model Class Initialized
INFO - 2024-05-21 07:57:11 --> Final output sent to browser
DEBUG - 2024-05-21 07:57:11 --> Total execution time: 0.0091
ERROR - 2024-05-21 07:57:13 --> $config['composer_autoload'] is set to TRUE but /home/u241458058/domains/technoprimex.com/public_html/maurnaturo/application/vendor/autoload.php was not found.
INFO - 2024-05-21 07:57:13 --> Config Class Initialized
INFO - 2024-05-21 07:57:13 --> Hooks Class Initialized
DEBUG - 2024-05-21 07:57:13 --> UTF-8 Support Enabled
INFO - 2024-05-21 07:57:13 --> Utf8 Class Initialized
INFO - 2024-05-21 07:57:13 --> URI Class Initialized
INFO - 2024-05-21 07:57:13 --> Router Class Initialized
INFO - 2024-05-21 07:57:13 --> Output Class Initialized
INFO - 2024-05-21 07:57:13 --> Security Class Initialized
DEBUG - 2024-05-21 07:57:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-21 07:57:13 --> Input Class Initialized
INFO - 2024-05-21 07:57:13 --> Language Class Initialized
ERROR - 2024-05-21 07:57:13 --> 404 Page Not Found: Cexpenses/expenses_view_form
ERROR - 2024-05-21 07:57:16 --> $config['composer_autoload'] is set to TRUE but /home/u241458058/domains/technoprimex.com/public_html/maurnaturo/application/vendor/autoload.php was not found.
INFO - 2024-05-21 07:57:16 --> Config Class Initialized
INFO - 2024-05-21 07:57:16 --> Hooks Class Initialized
DEBUG - 2024-05-21 07:57:16 --> UTF-8 Support Enabled
INFO - 2024-05-21 07:57:16 --> Utf8 Class Initialized
INFO - 2024-05-21 07:57:16 --> URI Class Initialized
INFO - 2024-05-21 07:57:16 --> Router Class Initialized
INFO - 2024-05-21 07:57:16 --> Output Class Initialized
INFO - 2024-05-21 07:57:16 --> Security Class Initialized
DEBUG - 2024-05-21 07:57:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-21 07:57:16 --> Input Class Initialized
INFO - 2024-05-21 07:57:16 --> Language Class Initialized
INFO - 2024-05-21 07:57:16 --> Loader Class Initialized
INFO - 2024-05-21 07:57:16 --> Helper loaded: url_helper
INFO - 2024-05-21 07:57:16 --> Helper loaded: file_helper
INFO - 2024-05-21 07:57:16 --> Helper loaded: html_helper
INFO - 2024-05-21 07:57:16 --> Helper loaded: text_helper
INFO - 2024-05-21 07:57:16 --> Helper loaded: form_helper
INFO - 2024-05-21 07:57:16 --> Helper loaded: lang_helper
INFO - 2024-05-21 07:57:16 --> Helper loaded: security_helper
INFO - 2024-05-21 07:57:16 --> Helper loaded: cookie_helper
INFO - 2024-05-21 07:57:16 --> Database Driver Class Initialized
INFO - 2024-05-21 07:57:16 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-21 07:57:16 --> Parser Class Initialized
INFO - 2024-05-21 07:57:16 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-05-21 07:57:16 --> Pagination Class Initialized
INFO - 2024-05-21 07:57:16 --> Form Validation Class Initialized
INFO - 2024-05-21 07:57:16 --> Controller Class Initialized
DEBUG - 2024-05-21 07:57:16 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-05-21 07:57:16 --> Session class already loaded. Second attempt ignored.
INFO - 2024-05-21 07:57:16 --> Model Class Initialized
DEBUG - 2024-05-21 07:57:16 --> Lexpenses class already loaded. Second attempt ignored.
INFO - 2024-05-21 07:57:16 --> Model Class Initialized
INFO - 2024-05-21 07:57:16 --> File loaded: /home/u241458058/domains/technoprimex.com/public_html/maurnaturo/application/views/expenses/expenses.php
DEBUG - 2024-05-21 07:57:16 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-05-21 07:57:16 --> File loaded: /home/u241458058/domains/technoprimex.com/public_html/maurnaturo/application/views/include/top_menu.php
INFO - 2024-05-21 07:57:16 --> File loaded: /home/u241458058/domains/technoprimex.com/public_html/maurnaturo/application/views/include/admin_loggedin_info.php
INFO - 2024-05-21 07:57:16 --> Model Class Initialized
INFO - 2024-05-21 07:57:16 --> Model Class Initialized
INFO - 2024-05-21 07:57:16 --> Model Class Initialized
INFO - 2024-05-21 07:57:16 --> File loaded: /home/u241458058/domains/technoprimex.com/public_html/maurnaturo/application/views/include/admin_header.php
INFO - 2024-05-21 07:57:16 --> File loaded: /home/u241458058/domains/technoprimex.com/public_html/maurnaturo/application/views/include/admin_footer.php
INFO - 2024-05-21 07:57:16 --> File loaded: /home/u241458058/domains/technoprimex.com/public_html/maurnaturo/application/views/admin_html_template.php
INFO - 2024-05-21 07:57:16 --> Final output sent to browser
DEBUG - 2024-05-21 07:57:16 --> Total execution time: 0.1824
ERROR - 2024-05-21 07:57:17 --> $config['composer_autoload'] is set to TRUE but /home/u241458058/domains/technoprimex.com/public_html/maurnaturo/application/vendor/autoload.php was not found.
INFO - 2024-05-21 07:57:17 --> Config Class Initialized
INFO - 2024-05-21 07:57:17 --> Hooks Class Initialized
DEBUG - 2024-05-21 07:57:17 --> UTF-8 Support Enabled
INFO - 2024-05-21 07:57:17 --> Utf8 Class Initialized
INFO - 2024-05-21 07:57:17 --> URI Class Initialized
INFO - 2024-05-21 07:57:17 --> Router Class Initialized
INFO - 2024-05-21 07:57:17 --> Output Class Initialized
INFO - 2024-05-21 07:57:17 --> Security Class Initialized
DEBUG - 2024-05-21 07:57:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-21 07:57:17 --> Input Class Initialized
INFO - 2024-05-21 07:57:17 --> Language Class Initialized
INFO - 2024-05-21 07:57:17 --> Loader Class Initialized
INFO - 2024-05-21 07:57:17 --> Helper loaded: url_helper
INFO - 2024-05-21 07:57:17 --> Helper loaded: file_helper
INFO - 2024-05-21 07:57:17 --> Helper loaded: html_helper
INFO - 2024-05-21 07:57:17 --> Helper loaded: text_helper
INFO - 2024-05-21 07:57:17 --> Helper loaded: form_helper
INFO - 2024-05-21 07:57:17 --> Helper loaded: lang_helper
INFO - 2024-05-21 07:57:17 --> Helper loaded: security_helper
INFO - 2024-05-21 07:57:17 --> Helper loaded: cookie_helper
INFO - 2024-05-21 07:57:17 --> Database Driver Class Initialized
INFO - 2024-05-21 07:57:17 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-21 07:57:17 --> Parser Class Initialized
INFO - 2024-05-21 07:57:17 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-05-21 07:57:17 --> Pagination Class Initialized
INFO - 2024-05-21 07:57:17 --> Form Validation Class Initialized
INFO - 2024-05-21 07:57:17 --> Controller Class Initialized
DEBUG - 2024-05-21 07:57:17 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-05-21 07:57:17 --> Session class already loaded. Second attempt ignored.
INFO - 2024-05-21 07:57:17 --> Model Class Initialized
INFO - 2024-05-21 07:57:17 --> Final output sent to browser
DEBUG - 2024-05-21 07:57:17 --> Total execution time: 0.0080
ERROR - 2024-05-21 07:57:34 --> $config['composer_autoload'] is set to TRUE but /home/u241458058/domains/technoprimex.com/public_html/maurnaturo/application/vendor/autoload.php was not found.
INFO - 2024-05-21 07:57:34 --> Config Class Initialized
INFO - 2024-05-21 07:57:34 --> Hooks Class Initialized
DEBUG - 2024-05-21 07:57:34 --> UTF-8 Support Enabled
INFO - 2024-05-21 07:57:34 --> Utf8 Class Initialized
INFO - 2024-05-21 07:57:34 --> URI Class Initialized
INFO - 2024-05-21 07:57:34 --> Router Class Initialized
INFO - 2024-05-21 07:57:34 --> Output Class Initialized
INFO - 2024-05-21 07:57:34 --> Security Class Initialized
DEBUG - 2024-05-21 07:57:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-21 07:57:34 --> Input Class Initialized
INFO - 2024-05-21 07:57:34 --> Language Class Initialized
INFO - 2024-05-21 07:57:34 --> Loader Class Initialized
INFO - 2024-05-21 07:57:34 --> Helper loaded: url_helper
INFO - 2024-05-21 07:57:34 --> Helper loaded: file_helper
INFO - 2024-05-21 07:57:34 --> Helper loaded: html_helper
INFO - 2024-05-21 07:57:34 --> Helper loaded: text_helper
INFO - 2024-05-21 07:57:34 --> Helper loaded: form_helper
INFO - 2024-05-21 07:57:34 --> Helper loaded: lang_helper
INFO - 2024-05-21 07:57:34 --> Helper loaded: security_helper
INFO - 2024-05-21 07:57:34 --> Helper loaded: cookie_helper
INFO - 2024-05-21 07:57:34 --> Database Driver Class Initialized
INFO - 2024-05-21 07:57:34 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-21 07:57:34 --> Parser Class Initialized
INFO - 2024-05-21 07:57:34 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-05-21 07:57:34 --> Pagination Class Initialized
INFO - 2024-05-21 07:57:34 --> Form Validation Class Initialized
INFO - 2024-05-21 07:57:34 --> Controller Class Initialized
DEBUG - 2024-05-21 07:57:34 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-05-21 07:57:34 --> Session class already loaded. Second attempt ignored.
INFO - 2024-05-21 07:57:34 --> Model Class Initialized
DEBUG - 2024-05-21 07:57:34 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-05-21 07:57:34 --> Session class already loaded. Second attempt ignored.
DEBUG - 2024-05-21 07:57:34 --> Ltarget class already loaded. Second attempt ignored.
INFO - 2024-05-21 07:57:34 --> Model Class Initialized
DEBUG - 2024-05-21 07:57:34 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-05-21 07:57:34 --> Session class already loaded. Second attempt ignored.
INFO - 2024-05-21 07:57:34 --> Model Class Initialized
DEBUG - 2024-05-21 07:57:34 --> Session class already loaded. Second attempt ignored.
INFO - 2024-05-21 07:57:34 --> Model Class Initialized
INFO - 2024-05-21 07:57:34 --> File loaded: /home/u241458058/domains/technoprimex.com/public_html/maurnaturo/application/views/target/target.php
DEBUG - 2024-05-21 07:57:34 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-05-21 07:57:34 --> File loaded: /home/u241458058/domains/technoprimex.com/public_html/maurnaturo/application/views/include/top_menu.php
INFO - 2024-05-21 07:57:34 --> File loaded: /home/u241458058/domains/technoprimex.com/public_html/maurnaturo/application/views/include/admin_loggedin_info.php
INFO - 2024-05-21 07:57:34 --> Model Class Initialized
INFO - 2024-05-21 07:57:34 --> Model Class Initialized
INFO - 2024-05-21 07:57:34 --> Model Class Initialized
INFO - 2024-05-21 07:57:34 --> File loaded: /home/u241458058/domains/technoprimex.com/public_html/maurnaturo/application/views/include/admin_header.php
INFO - 2024-05-21 07:57:34 --> File loaded: /home/u241458058/domains/technoprimex.com/public_html/maurnaturo/application/views/include/admin_footer.php
INFO - 2024-05-21 07:57:34 --> File loaded: /home/u241458058/domains/technoprimex.com/public_html/maurnaturo/application/views/admin_html_template.php
INFO - 2024-05-21 07:57:34 --> Final output sent to browser
DEBUG - 2024-05-21 07:57:34 --> Total execution time: 0.1467
ERROR - 2024-05-21 07:57:34 --> $config['composer_autoload'] is set to TRUE but /home/u241458058/domains/technoprimex.com/public_html/maurnaturo/application/vendor/autoload.php was not found.
INFO - 2024-05-21 07:57:34 --> Config Class Initialized
INFO - 2024-05-21 07:57:34 --> Hooks Class Initialized
DEBUG - 2024-05-21 07:57:34 --> UTF-8 Support Enabled
INFO - 2024-05-21 07:57:34 --> Utf8 Class Initialized
INFO - 2024-05-21 07:57:34 --> URI Class Initialized
INFO - 2024-05-21 07:57:34 --> Router Class Initialized
INFO - 2024-05-21 07:57:34 --> Output Class Initialized
INFO - 2024-05-21 07:57:34 --> Security Class Initialized
DEBUG - 2024-05-21 07:57:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-21 07:57:34 --> Input Class Initialized
INFO - 2024-05-21 07:57:34 --> Language Class Initialized
INFO - 2024-05-21 07:57:34 --> Loader Class Initialized
INFO - 2024-05-21 07:57:34 --> Helper loaded: url_helper
INFO - 2024-05-21 07:57:34 --> Helper loaded: file_helper
INFO - 2024-05-21 07:57:34 --> Helper loaded: html_helper
INFO - 2024-05-21 07:57:34 --> Helper loaded: text_helper
INFO - 2024-05-21 07:57:34 --> Helper loaded: form_helper
INFO - 2024-05-21 07:57:34 --> Helper loaded: lang_helper
INFO - 2024-05-21 07:57:34 --> Helper loaded: security_helper
INFO - 2024-05-21 07:57:34 --> Helper loaded: cookie_helper
INFO - 2024-05-21 07:57:34 --> Database Driver Class Initialized
INFO - 2024-05-21 07:57:34 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-21 07:57:34 --> Parser Class Initialized
INFO - 2024-05-21 07:57:34 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-05-21 07:57:34 --> Pagination Class Initialized
INFO - 2024-05-21 07:57:34 --> Form Validation Class Initialized
INFO - 2024-05-21 07:57:34 --> Controller Class Initialized
DEBUG - 2024-05-21 07:57:34 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-05-21 07:57:34 --> Session class already loaded. Second attempt ignored.
INFO - 2024-05-21 07:57:34 --> Model Class Initialized
DEBUG - 2024-05-21 07:57:34 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-05-21 07:57:34 --> Session class already loaded. Second attempt ignored.
INFO - 2024-05-21 07:57:34 --> Model Class Initialized
DEBUG - 2024-05-21 07:57:34 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-05-21 07:57:34 --> Session class already loaded. Second attempt ignored.
INFO - 2024-05-21 07:57:34 --> Model Class Initialized
DEBUG - 2024-05-21 07:57:34 --> Session class already loaded. Second attempt ignored.
INFO - 2024-05-21 07:57:34 --> Model Class Initialized
INFO - 2024-05-21 07:57:34 --> Final output sent to browser
DEBUG - 2024-05-21 07:57:34 --> Total execution time: 0.0127
ERROR - 2024-05-21 07:59:49 --> $config['composer_autoload'] is set to TRUE but /home/u241458058/domains/technoprimex.com/public_html/maurnaturo/application/vendor/autoload.php was not found.
INFO - 2024-05-21 07:59:49 --> Config Class Initialized
INFO - 2024-05-21 07:59:49 --> Hooks Class Initialized
DEBUG - 2024-05-21 07:59:49 --> UTF-8 Support Enabled
INFO - 2024-05-21 07:59:49 --> Utf8 Class Initialized
INFO - 2024-05-21 07:59:49 --> URI Class Initialized
INFO - 2024-05-21 07:59:49 --> Router Class Initialized
INFO - 2024-05-21 07:59:49 --> Output Class Initialized
INFO - 2024-05-21 07:59:49 --> Security Class Initialized
DEBUG - 2024-05-21 07:59:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-21 07:59:49 --> Input Class Initialized
INFO - 2024-05-21 07:59:49 --> Language Class Initialized
INFO - 2024-05-21 07:59:49 --> Loader Class Initialized
INFO - 2024-05-21 07:59:49 --> Helper loaded: url_helper
INFO - 2024-05-21 07:59:49 --> Helper loaded: file_helper
INFO - 2024-05-21 07:59:49 --> Helper loaded: html_helper
INFO - 2024-05-21 07:59:49 --> Helper loaded: text_helper
INFO - 2024-05-21 07:59:49 --> Helper loaded: form_helper
INFO - 2024-05-21 07:59:49 --> Helper loaded: lang_helper
INFO - 2024-05-21 07:59:49 --> Helper loaded: security_helper
INFO - 2024-05-21 07:59:49 --> Helper loaded: cookie_helper
INFO - 2024-05-21 07:59:49 --> Database Driver Class Initialized
INFO - 2024-05-21 07:59:49 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-21 07:59:49 --> Parser Class Initialized
INFO - 2024-05-21 07:59:49 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-05-21 07:59:49 --> Pagination Class Initialized
INFO - 2024-05-21 07:59:49 --> Form Validation Class Initialized
INFO - 2024-05-21 07:59:49 --> Controller Class Initialized
INFO - 2024-05-21 07:59:49 --> Model Class Initialized
INFO - 2024-05-21 07:59:49 --> Model Class Initialized
INFO - 2024-05-21 07:59:49 --> File loaded: /home/u241458058/domains/technoprimex.com/public_html/maurnaturo/application/views/report/out_of_date.php
DEBUG - 2024-05-21 07:59:49 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-05-21 07:59:49 --> File loaded: /home/u241458058/domains/technoprimex.com/public_html/maurnaturo/application/views/include/top_menu.php
INFO - 2024-05-21 07:59:49 --> File loaded: /home/u241458058/domains/technoprimex.com/public_html/maurnaturo/application/views/include/admin_loggedin_info.php
INFO - 2024-05-21 07:59:49 --> Model Class Initialized
INFO - 2024-05-21 07:59:49 --> Model Class Initialized
INFO - 2024-05-21 07:59:50 --> File loaded: /home/u241458058/domains/technoprimex.com/public_html/maurnaturo/application/views/include/admin_header.php
INFO - 2024-05-21 07:59:50 --> File loaded: /home/u241458058/domains/technoprimex.com/public_html/maurnaturo/application/views/include/admin_footer.php
INFO - 2024-05-21 07:59:50 --> File loaded: /home/u241458058/domains/technoprimex.com/public_html/maurnaturo/application/views/admin_html_template.php
INFO - 2024-05-21 07:59:50 --> Final output sent to browser
DEBUG - 2024-05-21 07:59:50 --> Total execution time: 0.1594
ERROR - 2024-05-21 07:59:50 --> $config['composer_autoload'] is set to TRUE but /home/u241458058/domains/technoprimex.com/public_html/maurnaturo/application/vendor/autoload.php was not found.
INFO - 2024-05-21 07:59:50 --> Config Class Initialized
INFO - 2024-05-21 07:59:50 --> Hooks Class Initialized
DEBUG - 2024-05-21 07:59:50 --> UTF-8 Support Enabled
INFO - 2024-05-21 07:59:50 --> Utf8 Class Initialized
INFO - 2024-05-21 07:59:50 --> URI Class Initialized
INFO - 2024-05-21 07:59:50 --> Router Class Initialized
INFO - 2024-05-21 07:59:50 --> Output Class Initialized
INFO - 2024-05-21 07:59:50 --> Security Class Initialized
DEBUG - 2024-05-21 07:59:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-21 07:59:50 --> Input Class Initialized
INFO - 2024-05-21 07:59:50 --> Language Class Initialized
INFO - 2024-05-21 07:59:50 --> Loader Class Initialized
INFO - 2024-05-21 07:59:50 --> Helper loaded: url_helper
INFO - 2024-05-21 07:59:50 --> Helper loaded: file_helper
INFO - 2024-05-21 07:59:50 --> Helper loaded: html_helper
INFO - 2024-05-21 07:59:50 --> Helper loaded: text_helper
INFO - 2024-05-21 07:59:50 --> Helper loaded: form_helper
INFO - 2024-05-21 07:59:50 --> Helper loaded: lang_helper
INFO - 2024-05-21 07:59:50 --> Helper loaded: security_helper
INFO - 2024-05-21 07:59:50 --> Helper loaded: cookie_helper
INFO - 2024-05-21 07:59:50 --> Database Driver Class Initialized
INFO - 2024-05-21 07:59:50 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-21 07:59:50 --> Parser Class Initialized
INFO - 2024-05-21 07:59:50 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-05-21 07:59:50 --> Pagination Class Initialized
INFO - 2024-05-21 07:59:50 --> Form Validation Class Initialized
INFO - 2024-05-21 07:59:50 --> Controller Class Initialized
INFO - 2024-05-21 07:59:50 --> Model Class Initialized
INFO - 2024-05-21 07:59:50 --> Model Class Initialized
INFO - 2024-05-21 07:59:50 --> Final output sent to browser
DEBUG - 2024-05-21 07:59:50 --> Total execution time: 0.0295
ERROR - 2024-05-21 07:59:54 --> $config['composer_autoload'] is set to TRUE but /home/u241458058/domains/technoprimex.com/public_html/maurnaturo/application/vendor/autoload.php was not found.
INFO - 2024-05-21 07:59:54 --> Config Class Initialized
INFO - 2024-05-21 07:59:54 --> Hooks Class Initialized
DEBUG - 2024-05-21 07:59:54 --> UTF-8 Support Enabled
INFO - 2024-05-21 07:59:54 --> Utf8 Class Initialized
INFO - 2024-05-21 07:59:54 --> URI Class Initialized
DEBUG - 2024-05-21 07:59:54 --> No URI present. Default controller set.
INFO - 2024-05-21 07:59:54 --> Router Class Initialized
INFO - 2024-05-21 07:59:54 --> Output Class Initialized
INFO - 2024-05-21 07:59:54 --> Security Class Initialized
DEBUG - 2024-05-21 07:59:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-21 07:59:54 --> Input Class Initialized
INFO - 2024-05-21 07:59:54 --> Language Class Initialized
INFO - 2024-05-21 07:59:54 --> Loader Class Initialized
INFO - 2024-05-21 07:59:54 --> Helper loaded: url_helper
INFO - 2024-05-21 07:59:54 --> Helper loaded: file_helper
INFO - 2024-05-21 07:59:54 --> Helper loaded: html_helper
INFO - 2024-05-21 07:59:54 --> Helper loaded: text_helper
INFO - 2024-05-21 07:59:54 --> Helper loaded: form_helper
INFO - 2024-05-21 07:59:54 --> Helper loaded: lang_helper
INFO - 2024-05-21 07:59:54 --> Helper loaded: security_helper
INFO - 2024-05-21 07:59:54 --> Helper loaded: cookie_helper
INFO - 2024-05-21 07:59:54 --> Database Driver Class Initialized
INFO - 2024-05-21 07:59:54 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-21 07:59:54 --> Parser Class Initialized
INFO - 2024-05-21 07:59:54 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-05-21 07:59:54 --> Pagination Class Initialized
INFO - 2024-05-21 07:59:54 --> Form Validation Class Initialized
INFO - 2024-05-21 07:59:54 --> Controller Class Initialized
INFO - 2024-05-21 07:59:54 --> Model Class Initialized
DEBUG - 2024-05-21 07:59:54 --> Session class already loaded. Second attempt ignored.
INFO - 2024-05-21 07:59:54 --> Model Class Initialized
DEBUG - 2024-05-21 07:59:54 --> Session class already loaded. Second attempt ignored.
INFO - 2024-05-21 07:59:54 --> Model Class Initialized
INFO - 2024-05-21 07:59:54 --> Model Class Initialized
INFO - 2024-05-21 07:59:54 --> Model Class Initialized
INFO - 2024-05-21 07:59:54 --> Model Class Initialized
DEBUG - 2024-05-21 07:59:54 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-05-21 07:59:54 --> Session class already loaded. Second attempt ignored.
INFO - 2024-05-21 07:59:54 --> Model Class Initialized
INFO - 2024-05-21 07:59:54 --> Model Class Initialized
INFO - 2024-05-21 07:59:54 --> File loaded: /home/u241458058/domains/technoprimex.com/public_html/maurnaturo/application/views/include/admin_home.php
DEBUG - 2024-05-21 07:59:54 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-05-21 07:59:54 --> File loaded: /home/u241458058/domains/technoprimex.com/public_html/maurnaturo/application/views/include/top_menu.php
INFO - 2024-05-21 07:59:54 --> File loaded: /home/u241458058/domains/technoprimex.com/public_html/maurnaturo/application/views/include/admin_loggedin_info.php
INFO - 2024-05-21 07:59:54 --> Model Class Initialized
INFO - 2024-05-21 07:59:54 --> File loaded: /home/u241458058/domains/technoprimex.com/public_html/maurnaturo/application/views/include/admin_header.php
INFO - 2024-05-21 07:59:54 --> File loaded: /home/u241458058/domains/technoprimex.com/public_html/maurnaturo/application/views/include/admin_footer.php
INFO - 2024-05-21 07:59:54 --> File loaded: /home/u241458058/domains/technoprimex.com/public_html/maurnaturo/application/views/admin_html_template.php
INFO - 2024-05-21 07:59:54 --> Final output sent to browser
DEBUG - 2024-05-21 07:59:54 --> Total execution time: 0.2310
ERROR - 2024-05-21 08:01:37 --> $config['composer_autoload'] is set to TRUE but /home/u241458058/domains/technoprimex.com/public_html/maurnaturo/application/vendor/autoload.php was not found.
INFO - 2024-05-21 08:01:37 --> Config Class Initialized
INFO - 2024-05-21 08:01:37 --> Hooks Class Initialized
DEBUG - 2024-05-21 08:01:37 --> UTF-8 Support Enabled
INFO - 2024-05-21 08:01:37 --> Utf8 Class Initialized
INFO - 2024-05-21 08:01:37 --> URI Class Initialized
INFO - 2024-05-21 08:01:37 --> Router Class Initialized
INFO - 2024-05-21 08:01:37 --> Output Class Initialized
INFO - 2024-05-21 08:01:37 --> Security Class Initialized
DEBUG - 2024-05-21 08:01:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-21 08:01:37 --> Input Class Initialized
INFO - 2024-05-21 08:01:37 --> Language Class Initialized
INFO - 2024-05-21 08:01:37 --> Loader Class Initialized
INFO - 2024-05-21 08:01:37 --> Helper loaded: url_helper
INFO - 2024-05-21 08:01:37 --> Helper loaded: file_helper
INFO - 2024-05-21 08:01:37 --> Helper loaded: html_helper
INFO - 2024-05-21 08:01:37 --> Helper loaded: text_helper
INFO - 2024-05-21 08:01:37 --> Helper loaded: form_helper
INFO - 2024-05-21 08:01:37 --> Helper loaded: lang_helper
INFO - 2024-05-21 08:01:37 --> Helper loaded: security_helper
INFO - 2024-05-21 08:01:37 --> Helper loaded: cookie_helper
INFO - 2024-05-21 08:01:37 --> Database Driver Class Initialized
INFO - 2024-05-21 08:01:37 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-21 08:01:37 --> Parser Class Initialized
INFO - 2024-05-21 08:01:37 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-05-21 08:01:37 --> Pagination Class Initialized
INFO - 2024-05-21 08:01:37 --> Form Validation Class Initialized
INFO - 2024-05-21 08:01:37 --> Controller Class Initialized
INFO - 2024-05-21 08:01:37 --> Model Class Initialized
DEBUG - 2024-05-21 08:01:37 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-05-21 08:01:37 --> Session class already loaded. Second attempt ignored.
INFO - 2024-05-21 08:01:37 --> Model Class Initialized
DEBUG - 2024-05-21 08:01:37 --> Session class already loaded. Second attempt ignored.
INFO - 2024-05-21 08:01:37 --> Model Class Initialized
INFO - 2024-05-21 08:01:37 --> File loaded: /home/u241458058/domains/technoprimex.com/public_html/maurnaturo/application/views/invoice/invoice.php
DEBUG - 2024-05-21 08:01:37 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-05-21 08:01:37 --> File loaded: /home/u241458058/domains/technoprimex.com/public_html/maurnaturo/application/views/include/top_menu.php
INFO - 2024-05-21 08:01:37 --> File loaded: /home/u241458058/domains/technoprimex.com/public_html/maurnaturo/application/views/include/admin_loggedin_info.php
INFO - 2024-05-21 08:01:37 --> Model Class Initialized
INFO - 2024-05-21 08:01:37 --> Model Class Initialized
INFO - 2024-05-21 08:01:37 --> Model Class Initialized
INFO - 2024-05-21 08:01:38 --> File loaded: /home/u241458058/domains/technoprimex.com/public_html/maurnaturo/application/views/include/admin_header.php
INFO - 2024-05-21 08:01:38 --> File loaded: /home/u241458058/domains/technoprimex.com/public_html/maurnaturo/application/views/include/admin_footer.php
INFO - 2024-05-21 08:01:38 --> File loaded: /home/u241458058/domains/technoprimex.com/public_html/maurnaturo/application/views/admin_html_template.php
INFO - 2024-05-21 08:01:38 --> Final output sent to browser
DEBUG - 2024-05-21 08:01:38 --> Total execution time: 0.1638
ERROR - 2024-05-21 08:01:38 --> $config['composer_autoload'] is set to TRUE but /home/u241458058/domains/technoprimex.com/public_html/maurnaturo/application/vendor/autoload.php was not found.
INFO - 2024-05-21 08:01:38 --> Config Class Initialized
INFO - 2024-05-21 08:01:38 --> Hooks Class Initialized
DEBUG - 2024-05-21 08:01:38 --> UTF-8 Support Enabled
INFO - 2024-05-21 08:01:38 --> Utf8 Class Initialized
INFO - 2024-05-21 08:01:38 --> URI Class Initialized
INFO - 2024-05-21 08:01:38 --> Router Class Initialized
INFO - 2024-05-21 08:01:38 --> Output Class Initialized
INFO - 2024-05-21 08:01:38 --> Security Class Initialized
DEBUG - 2024-05-21 08:01:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-21 08:01:38 --> Input Class Initialized
INFO - 2024-05-21 08:01:38 --> Language Class Initialized
INFO - 2024-05-21 08:01:38 --> Loader Class Initialized
INFO - 2024-05-21 08:01:38 --> Helper loaded: url_helper
INFO - 2024-05-21 08:01:38 --> Helper loaded: file_helper
INFO - 2024-05-21 08:01:38 --> Helper loaded: html_helper
INFO - 2024-05-21 08:01:38 --> Helper loaded: text_helper
INFO - 2024-05-21 08:01:38 --> Helper loaded: form_helper
INFO - 2024-05-21 08:01:38 --> Helper loaded: lang_helper
INFO - 2024-05-21 08:01:38 --> Helper loaded: security_helper
INFO - 2024-05-21 08:01:38 --> Helper loaded: cookie_helper
INFO - 2024-05-21 08:01:38 --> Database Driver Class Initialized
INFO - 2024-05-21 08:01:38 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-21 08:01:38 --> Parser Class Initialized
INFO - 2024-05-21 08:01:38 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-05-21 08:01:38 --> Pagination Class Initialized
INFO - 2024-05-21 08:01:38 --> Form Validation Class Initialized
INFO - 2024-05-21 08:01:38 --> Controller Class Initialized
INFO - 2024-05-21 08:01:38 --> Model Class Initialized
DEBUG - 2024-05-21 08:01:38 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-05-21 08:01:38 --> Session class already loaded. Second attempt ignored.
INFO - 2024-05-21 08:01:38 --> Model Class Initialized
DEBUG - 2024-05-21 08:01:38 --> Session class already loaded. Second attempt ignored.
INFO - 2024-05-21 08:01:38 --> Model Class Initialized
INFO - 2024-05-21 08:01:38 --> Final output sent to browser
DEBUG - 2024-05-21 08:01:38 --> Total execution time: 0.0366
ERROR - 2024-05-21 08:02:20 --> $config['composer_autoload'] is set to TRUE but /home/u241458058/domains/technoprimex.com/public_html/maurnaturo/application/vendor/autoload.php was not found.
INFO - 2024-05-21 08:02:20 --> Config Class Initialized
INFO - 2024-05-21 08:02:20 --> Hooks Class Initialized
DEBUG - 2024-05-21 08:02:20 --> UTF-8 Support Enabled
INFO - 2024-05-21 08:02:20 --> Utf8 Class Initialized
INFO - 2024-05-21 08:02:20 --> URI Class Initialized
INFO - 2024-05-21 08:02:20 --> Router Class Initialized
INFO - 2024-05-21 08:02:20 --> Output Class Initialized
INFO - 2024-05-21 08:02:20 --> Security Class Initialized
DEBUG - 2024-05-21 08:02:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-21 08:02:20 --> Input Class Initialized
INFO - 2024-05-21 08:02:20 --> Language Class Initialized
INFO - 2024-05-21 08:02:20 --> Loader Class Initialized
INFO - 2024-05-21 08:02:20 --> Helper loaded: url_helper
INFO - 2024-05-21 08:02:20 --> Helper loaded: file_helper
INFO - 2024-05-21 08:02:20 --> Helper loaded: html_helper
INFO - 2024-05-21 08:02:20 --> Helper loaded: text_helper
INFO - 2024-05-21 08:02:20 --> Helper loaded: form_helper
INFO - 2024-05-21 08:02:20 --> Helper loaded: lang_helper
INFO - 2024-05-21 08:02:20 --> Helper loaded: security_helper
INFO - 2024-05-21 08:02:20 --> Helper loaded: cookie_helper
INFO - 2024-05-21 08:02:20 --> Database Driver Class Initialized
INFO - 2024-05-21 08:02:20 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-21 08:02:20 --> Parser Class Initialized
INFO - 2024-05-21 08:02:20 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-05-21 08:02:20 --> Pagination Class Initialized
INFO - 2024-05-21 08:02:20 --> Form Validation Class Initialized
INFO - 2024-05-21 08:02:20 --> Controller Class Initialized
DEBUG - 2024-05-21 08:02:20 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-05-21 08:02:20 --> Session class already loaded. Second attempt ignored.
INFO - 2024-05-21 08:02:20 --> Model Class Initialized
DEBUG - 2024-05-21 08:02:20 --> Session class already loaded. Second attempt ignored.
INFO - 2024-05-21 08:02:20 --> Model Class Initialized
DEBUG - 2024-05-21 08:02:20 --> Lcustomer class already loaded. Second attempt ignored.
INFO - 2024-05-21 08:02:20 --> Model Class Initialized
INFO - 2024-05-21 08:02:20 --> File loaded: /home/u241458058/domains/technoprimex.com/public_html/maurnaturo/application/views/customer/customer.php
DEBUG - 2024-05-21 08:02:20 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-05-21 08:02:20 --> File loaded: /home/u241458058/domains/technoprimex.com/public_html/maurnaturo/application/views/include/top_menu.php
INFO - 2024-05-21 08:02:20 --> File loaded: /home/u241458058/domains/technoprimex.com/public_html/maurnaturo/application/views/include/admin_loggedin_info.php
INFO - 2024-05-21 08:02:20 --> Model Class Initialized
INFO - 2024-05-21 08:02:20 --> Model Class Initialized
INFO - 2024-05-21 08:02:20 --> Model Class Initialized
INFO - 2024-05-21 08:02:20 --> File loaded: /home/u241458058/domains/technoprimex.com/public_html/maurnaturo/application/views/include/admin_header.php
INFO - 2024-05-21 08:02:20 --> File loaded: /home/u241458058/domains/technoprimex.com/public_html/maurnaturo/application/views/include/admin_footer.php
INFO - 2024-05-21 08:02:20 --> File loaded: /home/u241458058/domains/technoprimex.com/public_html/maurnaturo/application/views/admin_html_template.php
INFO - 2024-05-21 08:02:20 --> Final output sent to browser
DEBUG - 2024-05-21 08:02:20 --> Total execution time: 0.1352
ERROR - 2024-05-21 08:02:20 --> $config['composer_autoload'] is set to TRUE but /home/u241458058/domains/technoprimex.com/public_html/maurnaturo/application/vendor/autoload.php was not found.
INFO - 2024-05-21 08:02:20 --> Config Class Initialized
INFO - 2024-05-21 08:02:20 --> Hooks Class Initialized
DEBUG - 2024-05-21 08:02:20 --> UTF-8 Support Enabled
INFO - 2024-05-21 08:02:20 --> Utf8 Class Initialized
INFO - 2024-05-21 08:02:20 --> URI Class Initialized
INFO - 2024-05-21 08:02:20 --> Router Class Initialized
INFO - 2024-05-21 08:02:20 --> Output Class Initialized
INFO - 2024-05-21 08:02:20 --> Security Class Initialized
DEBUG - 2024-05-21 08:02:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-21 08:02:20 --> Input Class Initialized
INFO - 2024-05-21 08:02:20 --> Language Class Initialized
INFO - 2024-05-21 08:02:20 --> Loader Class Initialized
INFO - 2024-05-21 08:02:20 --> Helper loaded: url_helper
INFO - 2024-05-21 08:02:20 --> Helper loaded: file_helper
INFO - 2024-05-21 08:02:20 --> Helper loaded: html_helper
INFO - 2024-05-21 08:02:20 --> Helper loaded: text_helper
INFO - 2024-05-21 08:02:20 --> Helper loaded: form_helper
INFO - 2024-05-21 08:02:20 --> Helper loaded: lang_helper
INFO - 2024-05-21 08:02:20 --> Helper loaded: security_helper
INFO - 2024-05-21 08:02:20 --> Helper loaded: cookie_helper
INFO - 2024-05-21 08:02:20 --> Database Driver Class Initialized
INFO - 2024-05-21 08:02:20 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-21 08:02:20 --> Parser Class Initialized
INFO - 2024-05-21 08:02:20 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-05-21 08:02:20 --> Pagination Class Initialized
INFO - 2024-05-21 08:02:20 --> Form Validation Class Initialized
INFO - 2024-05-21 08:02:20 --> Controller Class Initialized
DEBUG - 2024-05-21 08:02:20 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-05-21 08:02:20 --> Session class already loaded. Second attempt ignored.
INFO - 2024-05-21 08:02:20 --> Model Class Initialized
DEBUG - 2024-05-21 08:02:20 --> Session class already loaded. Second attempt ignored.
INFO - 2024-05-21 08:02:20 --> Model Class Initialized
INFO - 2024-05-21 08:02:21 --> Final output sent to browser
DEBUG - 2024-05-21 08:02:21 --> Total execution time: 0.0264
ERROR - 2024-05-21 08:02:26 --> $config['composer_autoload'] is set to TRUE but /home/u241458058/domains/technoprimex.com/public_html/maurnaturo/application/vendor/autoload.php was not found.
INFO - 2024-05-21 08:02:26 --> Config Class Initialized
INFO - 2024-05-21 08:02:26 --> Hooks Class Initialized
DEBUG - 2024-05-21 08:02:26 --> UTF-8 Support Enabled
INFO - 2024-05-21 08:02:26 --> Utf8 Class Initialized
INFO - 2024-05-21 08:02:26 --> URI Class Initialized
INFO - 2024-05-21 08:02:26 --> Router Class Initialized
INFO - 2024-05-21 08:02:26 --> Output Class Initialized
INFO - 2024-05-21 08:02:26 --> Security Class Initialized
DEBUG - 2024-05-21 08:02:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-21 08:02:26 --> Input Class Initialized
INFO - 2024-05-21 08:02:26 --> Language Class Initialized
INFO - 2024-05-21 08:02:26 --> Loader Class Initialized
INFO - 2024-05-21 08:02:26 --> Helper loaded: url_helper
INFO - 2024-05-21 08:02:26 --> Helper loaded: file_helper
INFO - 2024-05-21 08:02:26 --> Helper loaded: html_helper
INFO - 2024-05-21 08:02:26 --> Helper loaded: text_helper
INFO - 2024-05-21 08:02:26 --> Helper loaded: form_helper
INFO - 2024-05-21 08:02:26 --> Helper loaded: lang_helper
INFO - 2024-05-21 08:02:26 --> Helper loaded: security_helper
INFO - 2024-05-21 08:02:26 --> Helper loaded: cookie_helper
INFO - 2024-05-21 08:02:26 --> Database Driver Class Initialized
INFO - 2024-05-21 08:02:26 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-21 08:02:26 --> Parser Class Initialized
INFO - 2024-05-21 08:02:26 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-05-21 08:02:26 --> Pagination Class Initialized
INFO - 2024-05-21 08:02:26 --> Form Validation Class Initialized
INFO - 2024-05-21 08:02:26 --> Controller Class Initialized
DEBUG - 2024-05-21 08:02:26 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-05-21 08:02:26 --> Session class already loaded. Second attempt ignored.
INFO - 2024-05-21 08:02:26 --> Model Class Initialized
DEBUG - 2024-05-21 08:02:26 --> Session class already loaded. Second attempt ignored.
INFO - 2024-05-21 08:02:26 --> Model Class Initialized
INFO - 2024-05-21 08:02:26 --> Final output sent to browser
DEBUG - 2024-05-21 08:02:26 --> Total execution time: 0.0262
ERROR - 2024-05-21 08:02:29 --> $config['composer_autoload'] is set to TRUE but /home/u241458058/domains/technoprimex.com/public_html/maurnaturo/application/vendor/autoload.php was not found.
INFO - 2024-05-21 08:02:29 --> Config Class Initialized
INFO - 2024-05-21 08:02:29 --> Hooks Class Initialized
DEBUG - 2024-05-21 08:02:29 --> UTF-8 Support Enabled
INFO - 2024-05-21 08:02:29 --> Utf8 Class Initialized
INFO - 2024-05-21 08:02:29 --> URI Class Initialized
INFO - 2024-05-21 08:02:29 --> Router Class Initialized
INFO - 2024-05-21 08:02:29 --> Output Class Initialized
INFO - 2024-05-21 08:02:29 --> Security Class Initialized
DEBUG - 2024-05-21 08:02:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-21 08:02:29 --> Input Class Initialized
INFO - 2024-05-21 08:02:29 --> Language Class Initialized
INFO - 2024-05-21 08:02:29 --> Loader Class Initialized
INFO - 2024-05-21 08:02:29 --> Helper loaded: url_helper
INFO - 2024-05-21 08:02:29 --> Helper loaded: file_helper
INFO - 2024-05-21 08:02:29 --> Helper loaded: html_helper
INFO - 2024-05-21 08:02:29 --> Helper loaded: text_helper
INFO - 2024-05-21 08:02:29 --> Helper loaded: form_helper
INFO - 2024-05-21 08:02:29 --> Helper loaded: lang_helper
INFO - 2024-05-21 08:02:29 --> Helper loaded: security_helper
INFO - 2024-05-21 08:02:29 --> Helper loaded: cookie_helper
INFO - 2024-05-21 08:02:29 --> Database Driver Class Initialized
INFO - 2024-05-21 08:02:29 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-21 08:02:29 --> Parser Class Initialized
INFO - 2024-05-21 08:02:29 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-05-21 08:02:29 --> Pagination Class Initialized
INFO - 2024-05-21 08:02:29 --> Form Validation Class Initialized
INFO - 2024-05-21 08:02:29 --> Controller Class Initialized
DEBUG - 2024-05-21 08:02:29 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-05-21 08:02:29 --> Session class already loaded. Second attempt ignored.
INFO - 2024-05-21 08:02:29 --> Model Class Initialized
DEBUG - 2024-05-21 08:02:29 --> Session class already loaded. Second attempt ignored.
INFO - 2024-05-21 08:02:29 --> Model Class Initialized
INFO - 2024-05-21 08:02:29 --> Final output sent to browser
DEBUG - 2024-05-21 08:02:29 --> Total execution time: 0.0132
ERROR - 2024-05-21 08:02:34 --> $config['composer_autoload'] is set to TRUE but /home/u241458058/domains/technoprimex.com/public_html/maurnaturo/application/vendor/autoload.php was not found.
INFO - 2024-05-21 08:02:34 --> Config Class Initialized
INFO - 2024-05-21 08:02:34 --> Hooks Class Initialized
DEBUG - 2024-05-21 08:02:34 --> UTF-8 Support Enabled
INFO - 2024-05-21 08:02:34 --> Utf8 Class Initialized
INFO - 2024-05-21 08:02:34 --> URI Class Initialized
INFO - 2024-05-21 08:02:34 --> Router Class Initialized
INFO - 2024-05-21 08:02:34 --> Output Class Initialized
INFO - 2024-05-21 08:02:34 --> Security Class Initialized
DEBUG - 2024-05-21 08:02:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-21 08:02:34 --> Input Class Initialized
INFO - 2024-05-21 08:02:34 --> Language Class Initialized
INFO - 2024-05-21 08:02:34 --> Loader Class Initialized
INFO - 2024-05-21 08:02:34 --> Helper loaded: url_helper
INFO - 2024-05-21 08:02:34 --> Helper loaded: file_helper
INFO - 2024-05-21 08:02:34 --> Helper loaded: html_helper
INFO - 2024-05-21 08:02:34 --> Helper loaded: text_helper
INFO - 2024-05-21 08:02:34 --> Helper loaded: form_helper
INFO - 2024-05-21 08:02:34 --> Helper loaded: lang_helper
INFO - 2024-05-21 08:02:34 --> Helper loaded: security_helper
INFO - 2024-05-21 08:02:34 --> Helper loaded: cookie_helper
INFO - 2024-05-21 08:02:34 --> Database Driver Class Initialized
INFO - 2024-05-21 08:02:34 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-21 08:02:34 --> Parser Class Initialized
INFO - 2024-05-21 08:02:34 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-05-21 08:02:34 --> Pagination Class Initialized
INFO - 2024-05-21 08:02:34 --> Form Validation Class Initialized
INFO - 2024-05-21 08:02:34 --> Controller Class Initialized
DEBUG - 2024-05-21 08:02:34 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-05-21 08:02:34 --> Session class already loaded. Second attempt ignored.
INFO - 2024-05-21 08:02:34 --> Model Class Initialized
DEBUG - 2024-05-21 08:02:34 --> Session class already loaded. Second attempt ignored.
INFO - 2024-05-21 08:02:34 --> Model Class Initialized
INFO - 2024-05-21 08:02:34 --> File loaded: /home/u241458058/domains/technoprimex.com/public_html/maurnaturo/application/views/customer/edit_customer_form.php
DEBUG - 2024-05-21 08:02:34 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-05-21 08:02:34 --> File loaded: /home/u241458058/domains/technoprimex.com/public_html/maurnaturo/application/views/include/top_menu.php
INFO - 2024-05-21 08:02:34 --> File loaded: /home/u241458058/domains/technoprimex.com/public_html/maurnaturo/application/views/include/admin_loggedin_info.php
INFO - 2024-05-21 08:02:34 --> Model Class Initialized
INFO - 2024-05-21 08:02:34 --> Model Class Initialized
INFO - 2024-05-21 08:02:34 --> Model Class Initialized
INFO - 2024-05-21 08:02:34 --> Model Class Initialized
INFO - 2024-05-21 08:02:34 --> File loaded: /home/u241458058/domains/technoprimex.com/public_html/maurnaturo/application/views/include/admin_header.php
INFO - 2024-05-21 08:02:34 --> File loaded: /home/u241458058/domains/technoprimex.com/public_html/maurnaturo/application/views/include/admin_footer.php
INFO - 2024-05-21 08:02:34 --> File loaded: /home/u241458058/domains/technoprimex.com/public_html/maurnaturo/application/views/admin_html_template.php
INFO - 2024-05-21 08:02:34 --> Final output sent to browser
DEBUG - 2024-05-21 08:02:34 --> Total execution time: 0.1560
ERROR - 2024-05-21 08:02:48 --> $config['composer_autoload'] is set to TRUE but /home/u241458058/domains/technoprimex.com/public_html/maurnaturo/application/vendor/autoload.php was not found.
INFO - 2024-05-21 08:02:48 --> Config Class Initialized
INFO - 2024-05-21 08:02:48 --> Hooks Class Initialized
DEBUG - 2024-05-21 08:02:48 --> UTF-8 Support Enabled
INFO - 2024-05-21 08:02:48 --> Utf8 Class Initialized
INFO - 2024-05-21 08:02:48 --> URI Class Initialized
DEBUG - 2024-05-21 08:02:48 --> No URI present. Default controller set.
INFO - 2024-05-21 08:02:48 --> Router Class Initialized
INFO - 2024-05-21 08:02:48 --> Output Class Initialized
INFO - 2024-05-21 08:02:48 --> Security Class Initialized
DEBUG - 2024-05-21 08:02:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-21 08:02:48 --> Input Class Initialized
INFO - 2024-05-21 08:02:48 --> Language Class Initialized
INFO - 2024-05-21 08:02:48 --> Loader Class Initialized
INFO - 2024-05-21 08:02:48 --> Helper loaded: url_helper
INFO - 2024-05-21 08:02:48 --> Helper loaded: file_helper
INFO - 2024-05-21 08:02:48 --> Helper loaded: html_helper
INFO - 2024-05-21 08:02:48 --> Helper loaded: text_helper
INFO - 2024-05-21 08:02:48 --> Helper loaded: form_helper
INFO - 2024-05-21 08:02:48 --> Helper loaded: lang_helper
INFO - 2024-05-21 08:02:48 --> Helper loaded: security_helper
INFO - 2024-05-21 08:02:48 --> Helper loaded: cookie_helper
INFO - 2024-05-21 08:02:48 --> Database Driver Class Initialized
INFO - 2024-05-21 08:02:48 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-21 08:02:48 --> Parser Class Initialized
INFO - 2024-05-21 08:02:48 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-05-21 08:02:48 --> Pagination Class Initialized
INFO - 2024-05-21 08:02:48 --> Form Validation Class Initialized
INFO - 2024-05-21 08:02:48 --> Controller Class Initialized
INFO - 2024-05-21 08:02:48 --> Model Class Initialized
DEBUG - 2024-05-21 08:02:48 --> Session class already loaded. Second attempt ignored.
ERROR - 2024-05-21 08:02:48 --> $config['composer_autoload'] is set to TRUE but /home/u241458058/domains/technoprimex.com/public_html/maurnaturo/application/vendor/autoload.php was not found.
INFO - 2024-05-21 08:02:48 --> Config Class Initialized
INFO - 2024-05-21 08:02:48 --> Hooks Class Initialized
DEBUG - 2024-05-21 08:02:48 --> UTF-8 Support Enabled
INFO - 2024-05-21 08:02:48 --> Utf8 Class Initialized
INFO - 2024-05-21 08:02:48 --> URI Class Initialized
INFO - 2024-05-21 08:02:48 --> Router Class Initialized
INFO - 2024-05-21 08:02:48 --> Output Class Initialized
INFO - 2024-05-21 08:02:48 --> Security Class Initialized
DEBUG - 2024-05-21 08:02:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-21 08:02:48 --> Input Class Initialized
INFO - 2024-05-21 08:02:48 --> Language Class Initialized
INFO - 2024-05-21 08:02:48 --> Loader Class Initialized
INFO - 2024-05-21 08:02:48 --> Helper loaded: url_helper
INFO - 2024-05-21 08:02:48 --> Helper loaded: file_helper
INFO - 2024-05-21 08:02:48 --> Helper loaded: html_helper
INFO - 2024-05-21 08:02:48 --> Helper loaded: text_helper
INFO - 2024-05-21 08:02:48 --> Helper loaded: form_helper
INFO - 2024-05-21 08:02:48 --> Helper loaded: lang_helper
INFO - 2024-05-21 08:02:48 --> Helper loaded: security_helper
INFO - 2024-05-21 08:02:48 --> Helper loaded: cookie_helper
INFO - 2024-05-21 08:02:48 --> Database Driver Class Initialized
INFO - 2024-05-21 08:02:48 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-21 08:02:48 --> Parser Class Initialized
INFO - 2024-05-21 08:02:48 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-05-21 08:02:48 --> Pagination Class Initialized
INFO - 2024-05-21 08:02:48 --> Form Validation Class Initialized
INFO - 2024-05-21 08:02:48 --> Controller Class Initialized
INFO - 2024-05-21 08:02:48 --> Model Class Initialized
DEBUG - 2024-05-21 08:02:48 --> Session class already loaded. Second attempt ignored.
INFO - 2024-05-21 08:02:48 --> File loaded: /home/u241458058/domains/technoprimex.com/public_html/maurnaturo/application/views/user/admin_login_form.php
DEBUG - 2024-05-21 08:02:48 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-05-21 08:02:48 --> File loaded: /home/u241458058/domains/technoprimex.com/public_html/maurnaturo/application/views/include/top_menu.php
INFO - 2024-05-21 08:02:48 --> File loaded: /home/u241458058/domains/technoprimex.com/public_html/maurnaturo/application/views/include/admin_loggedin_info.php
INFO - 2024-05-21 08:02:48 --> Model Class Initialized
INFO - 2024-05-21 08:02:48 --> File loaded: /home/u241458058/domains/technoprimex.com/public_html/maurnaturo/application/views/admin_html_template.php
INFO - 2024-05-21 08:02:48 --> Final output sent to browser
DEBUG - 2024-05-21 08:02:48 --> Total execution time: 0.0176
ERROR - 2024-05-21 08:03:07 --> $config['composer_autoload'] is set to TRUE but /home/u241458058/domains/technoprimex.com/public_html/maurnaturo/application/vendor/autoload.php was not found.
INFO - 2024-05-21 08:03:07 --> Config Class Initialized
INFO - 2024-05-21 08:03:07 --> Hooks Class Initialized
DEBUG - 2024-05-21 08:03:07 --> UTF-8 Support Enabled
INFO - 2024-05-21 08:03:07 --> Utf8 Class Initialized
INFO - 2024-05-21 08:03:07 --> URI Class Initialized
INFO - 2024-05-21 08:03:07 --> Router Class Initialized
INFO - 2024-05-21 08:03:07 --> Output Class Initialized
INFO - 2024-05-21 08:03:07 --> Security Class Initialized
DEBUG - 2024-05-21 08:03:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-21 08:03:07 --> Input Class Initialized
INFO - 2024-05-21 08:03:07 --> Language Class Initialized
INFO - 2024-05-21 08:03:07 --> Loader Class Initialized
INFO - 2024-05-21 08:03:07 --> Helper loaded: url_helper
INFO - 2024-05-21 08:03:07 --> Helper loaded: file_helper
INFO - 2024-05-21 08:03:07 --> Helper loaded: html_helper
INFO - 2024-05-21 08:03:07 --> Helper loaded: text_helper
INFO - 2024-05-21 08:03:07 --> Helper loaded: form_helper
INFO - 2024-05-21 08:03:07 --> Helper loaded: lang_helper
INFO - 2024-05-21 08:03:07 --> Helper loaded: security_helper
INFO - 2024-05-21 08:03:07 --> Helper loaded: cookie_helper
INFO - 2024-05-21 08:03:07 --> Database Driver Class Initialized
INFO - 2024-05-21 08:03:07 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-21 08:03:07 --> Parser Class Initialized
INFO - 2024-05-21 08:03:07 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-05-21 08:03:07 --> Pagination Class Initialized
INFO - 2024-05-21 08:03:07 --> Form Validation Class Initialized
INFO - 2024-05-21 08:03:07 --> Controller Class Initialized
INFO - 2024-05-21 08:03:07 --> Model Class Initialized
DEBUG - 2024-05-21 08:03:07 --> Session class already loaded. Second attempt ignored.
INFO - 2024-05-21 08:03:07 --> Model Class Initialized
INFO - 2024-05-21 08:03:07 --> Final output sent to browser
DEBUG - 2024-05-21 08:03:07 --> Total execution time: 0.0085
ERROR - 2024-05-21 08:03:07 --> $config['composer_autoload'] is set to TRUE but /home/u241458058/domains/technoprimex.com/public_html/maurnaturo/application/vendor/autoload.php was not found.
INFO - 2024-05-21 08:03:07 --> Config Class Initialized
INFO - 2024-05-21 08:03:07 --> Hooks Class Initialized
DEBUG - 2024-05-21 08:03:07 --> UTF-8 Support Enabled
INFO - 2024-05-21 08:03:07 --> Utf8 Class Initialized
INFO - 2024-05-21 08:03:07 --> URI Class Initialized
DEBUG - 2024-05-21 08:03:07 --> No URI present. Default controller set.
INFO - 2024-05-21 08:03:07 --> Router Class Initialized
INFO - 2024-05-21 08:03:07 --> Output Class Initialized
INFO - 2024-05-21 08:03:07 --> Security Class Initialized
DEBUG - 2024-05-21 08:03:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-21 08:03:07 --> Input Class Initialized
INFO - 2024-05-21 08:03:07 --> Language Class Initialized
INFO - 2024-05-21 08:03:07 --> Loader Class Initialized
INFO - 2024-05-21 08:03:07 --> Helper loaded: url_helper
INFO - 2024-05-21 08:03:07 --> Helper loaded: file_helper
INFO - 2024-05-21 08:03:07 --> Helper loaded: html_helper
INFO - 2024-05-21 08:03:07 --> Helper loaded: text_helper
INFO - 2024-05-21 08:03:07 --> Helper loaded: form_helper
INFO - 2024-05-21 08:03:07 --> Helper loaded: lang_helper
INFO - 2024-05-21 08:03:07 --> Helper loaded: security_helper
INFO - 2024-05-21 08:03:07 --> Helper loaded: cookie_helper
INFO - 2024-05-21 08:03:07 --> Database Driver Class Initialized
INFO - 2024-05-21 08:03:07 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-21 08:03:07 --> Parser Class Initialized
INFO - 2024-05-21 08:03:07 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-05-21 08:03:07 --> Pagination Class Initialized
INFO - 2024-05-21 08:03:07 --> Form Validation Class Initialized
INFO - 2024-05-21 08:03:07 --> Controller Class Initialized
INFO - 2024-05-21 08:03:07 --> Model Class Initialized
DEBUG - 2024-05-21 08:03:07 --> Session class already loaded. Second attempt ignored.
INFO - 2024-05-21 08:03:07 --> Model Class Initialized
DEBUG - 2024-05-21 08:03:07 --> Session class already loaded. Second attempt ignored.
INFO - 2024-05-21 08:03:07 --> Model Class Initialized
INFO - 2024-05-21 08:03:07 --> Model Class Initialized
INFO - 2024-05-21 08:03:07 --> Model Class Initialized
INFO - 2024-05-21 08:03:07 --> Model Class Initialized
DEBUG - 2024-05-21 08:03:07 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-05-21 08:03:07 --> Session class already loaded. Second attempt ignored.
INFO - 2024-05-21 08:03:07 --> Model Class Initialized
INFO - 2024-05-21 08:03:07 --> Model Class Initialized
INFO - 2024-05-21 08:03:07 --> File loaded: /home/u241458058/domains/technoprimex.com/public_html/maurnaturo/application/views/include/admin_home.php
DEBUG - 2024-05-21 08:03:07 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-05-21 08:03:07 --> File loaded: /home/u241458058/domains/technoprimex.com/public_html/maurnaturo/application/views/include/top_menu.php
INFO - 2024-05-21 08:03:07 --> File loaded: /home/u241458058/domains/technoprimex.com/public_html/maurnaturo/application/views/include/admin_loggedin_info.php
INFO - 2024-05-21 08:03:07 --> Model Class Initialized
INFO - 2024-05-21 08:03:07 --> File loaded: /home/u241458058/domains/technoprimex.com/public_html/maurnaturo/application/views/include/admin_header.php
INFO - 2024-05-21 08:03:07 --> File loaded: /home/u241458058/domains/technoprimex.com/public_html/maurnaturo/application/views/include/admin_footer.php
INFO - 2024-05-21 08:03:07 --> File loaded: /home/u241458058/domains/technoprimex.com/public_html/maurnaturo/application/views/admin_html_template.php
INFO - 2024-05-21 08:03:07 --> Final output sent to browser
DEBUG - 2024-05-21 08:03:07 --> Total execution time: 0.1160
ERROR - 2024-05-21 08:03:19 --> $config['composer_autoload'] is set to TRUE but /home/u241458058/domains/technoprimex.com/public_html/maurnaturo/application/vendor/autoload.php was not found.
INFO - 2024-05-21 08:03:19 --> Config Class Initialized
INFO - 2024-05-21 08:03:19 --> Hooks Class Initialized
DEBUG - 2024-05-21 08:03:19 --> UTF-8 Support Enabled
INFO - 2024-05-21 08:03:19 --> Utf8 Class Initialized
INFO - 2024-05-21 08:03:19 --> URI Class Initialized
DEBUG - 2024-05-21 08:03:19 --> No URI present. Default controller set.
INFO - 2024-05-21 08:03:19 --> Router Class Initialized
INFO - 2024-05-21 08:03:19 --> Output Class Initialized
INFO - 2024-05-21 08:03:19 --> Security Class Initialized
DEBUG - 2024-05-21 08:03:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-21 08:03:19 --> Input Class Initialized
INFO - 2024-05-21 08:03:19 --> Language Class Initialized
INFO - 2024-05-21 08:03:19 --> Loader Class Initialized
INFO - 2024-05-21 08:03:19 --> Helper loaded: url_helper
INFO - 2024-05-21 08:03:19 --> Helper loaded: file_helper
INFO - 2024-05-21 08:03:19 --> Helper loaded: html_helper
INFO - 2024-05-21 08:03:19 --> Helper loaded: text_helper
INFO - 2024-05-21 08:03:19 --> Helper loaded: form_helper
INFO - 2024-05-21 08:03:19 --> Helper loaded: lang_helper
INFO - 2024-05-21 08:03:19 --> Helper loaded: security_helper
INFO - 2024-05-21 08:03:19 --> Helper loaded: cookie_helper
INFO - 2024-05-21 08:03:19 --> Database Driver Class Initialized
INFO - 2024-05-21 08:03:19 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-21 08:03:19 --> Parser Class Initialized
INFO - 2024-05-21 08:03:19 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-05-21 08:03:19 --> Pagination Class Initialized
INFO - 2024-05-21 08:03:19 --> Form Validation Class Initialized
INFO - 2024-05-21 08:03:19 --> Controller Class Initialized
INFO - 2024-05-21 08:03:19 --> Model Class Initialized
DEBUG - 2024-05-21 08:03:19 --> Session class already loaded. Second attempt ignored.
INFO - 2024-05-21 08:03:19 --> Model Class Initialized
DEBUG - 2024-05-21 08:03:19 --> Session class already loaded. Second attempt ignored.
INFO - 2024-05-21 08:03:19 --> Model Class Initialized
INFO - 2024-05-21 08:03:19 --> Model Class Initialized
INFO - 2024-05-21 08:03:19 --> Model Class Initialized
INFO - 2024-05-21 08:03:19 --> Model Class Initialized
DEBUG - 2024-05-21 08:03:19 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-05-21 08:03:19 --> Session class already loaded. Second attempt ignored.
INFO - 2024-05-21 08:03:19 --> Model Class Initialized
INFO - 2024-05-21 08:03:19 --> Model Class Initialized
INFO - 2024-05-21 08:03:19 --> File loaded: /home/u241458058/domains/technoprimex.com/public_html/maurnaturo/application/views/include/admin_home.php
DEBUG - 2024-05-21 08:03:19 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-05-21 08:03:19 --> File loaded: /home/u241458058/domains/technoprimex.com/public_html/maurnaturo/application/views/include/top_menu.php
INFO - 2024-05-21 08:03:19 --> File loaded: /home/u241458058/domains/technoprimex.com/public_html/maurnaturo/application/views/include/admin_loggedin_info.php
INFO - 2024-05-21 08:03:19 --> Model Class Initialized
INFO - 2024-05-21 08:03:19 --> File loaded: /home/u241458058/domains/technoprimex.com/public_html/maurnaturo/application/views/include/admin_header.php
INFO - 2024-05-21 08:03:19 --> File loaded: /home/u241458058/domains/technoprimex.com/public_html/maurnaturo/application/views/include/admin_footer.php
INFO - 2024-05-21 08:03:19 --> File loaded: /home/u241458058/domains/technoprimex.com/public_html/maurnaturo/application/views/admin_html_template.php
INFO - 2024-05-21 08:03:19 --> Final output sent to browser
DEBUG - 2024-05-21 08:03:19 --> Total execution time: 0.1146
ERROR - 2024-05-21 08:03:24 --> $config['composer_autoload'] is set to TRUE but /home/u241458058/domains/technoprimex.com/public_html/maurnaturo/application/vendor/autoload.php was not found.
INFO - 2024-05-21 08:03:24 --> Config Class Initialized
INFO - 2024-05-21 08:03:24 --> Hooks Class Initialized
DEBUG - 2024-05-21 08:03:24 --> UTF-8 Support Enabled
INFO - 2024-05-21 08:03:24 --> Utf8 Class Initialized
INFO - 2024-05-21 08:03:24 --> URI Class Initialized
INFO - 2024-05-21 08:03:24 --> Router Class Initialized
INFO - 2024-05-21 08:03:24 --> Output Class Initialized
INFO - 2024-05-21 08:03:24 --> Security Class Initialized
DEBUG - 2024-05-21 08:03:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-21 08:03:24 --> Input Class Initialized
INFO - 2024-05-21 08:03:24 --> Language Class Initialized
INFO - 2024-05-21 08:03:24 --> Loader Class Initialized
INFO - 2024-05-21 08:03:24 --> Helper loaded: url_helper
INFO - 2024-05-21 08:03:24 --> Helper loaded: file_helper
INFO - 2024-05-21 08:03:24 --> Helper loaded: html_helper
INFO - 2024-05-21 08:03:24 --> Helper loaded: text_helper
INFO - 2024-05-21 08:03:24 --> Helper loaded: form_helper
INFO - 2024-05-21 08:03:24 --> Helper loaded: lang_helper
INFO - 2024-05-21 08:03:24 --> Helper loaded: security_helper
INFO - 2024-05-21 08:03:24 --> Helper loaded: cookie_helper
INFO - 2024-05-21 08:03:24 --> Database Driver Class Initialized
INFO - 2024-05-21 08:03:24 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-21 08:03:24 --> Parser Class Initialized
INFO - 2024-05-21 08:03:24 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-05-21 08:03:24 --> Pagination Class Initialized
INFO - 2024-05-21 08:03:24 --> Form Validation Class Initialized
INFO - 2024-05-21 08:03:24 --> Controller Class Initialized
INFO - 2024-05-21 08:03:24 --> Model Class Initialized
DEBUG - 2024-05-21 08:03:24 --> Session class already loaded. Second attempt ignored.
INFO - 2024-05-21 08:03:24 --> Final output sent to browser
DEBUG - 2024-05-21 08:03:24 --> Total execution time: 0.0045
ERROR - 2024-05-21 08:03:24 --> $config['composer_autoload'] is set to TRUE but /home/u241458058/domains/technoprimex.com/public_html/maurnaturo/application/vendor/autoload.php was not found.
INFO - 2024-05-21 08:03:24 --> Config Class Initialized
INFO - 2024-05-21 08:03:24 --> Hooks Class Initialized
DEBUG - 2024-05-21 08:03:24 --> UTF-8 Support Enabled
INFO - 2024-05-21 08:03:24 --> Utf8 Class Initialized
INFO - 2024-05-21 08:03:24 --> URI Class Initialized
INFO - 2024-05-21 08:03:24 --> Router Class Initialized
INFO - 2024-05-21 08:03:24 --> Output Class Initialized
INFO - 2024-05-21 08:03:24 --> Security Class Initialized
DEBUG - 2024-05-21 08:03:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-21 08:03:24 --> Input Class Initialized
INFO - 2024-05-21 08:03:24 --> Language Class Initialized
INFO - 2024-05-21 08:03:24 --> Loader Class Initialized
INFO - 2024-05-21 08:03:24 --> Helper loaded: url_helper
INFO - 2024-05-21 08:03:24 --> Helper loaded: file_helper
INFO - 2024-05-21 08:03:24 --> Helper loaded: html_helper
INFO - 2024-05-21 08:03:24 --> Helper loaded: text_helper
INFO - 2024-05-21 08:03:24 --> Helper loaded: form_helper
INFO - 2024-05-21 08:03:24 --> Helper loaded: lang_helper
INFO - 2024-05-21 08:03:24 --> Helper loaded: security_helper
INFO - 2024-05-21 08:03:24 --> Helper loaded: cookie_helper
INFO - 2024-05-21 08:03:24 --> Database Driver Class Initialized
INFO - 2024-05-21 08:03:24 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-21 08:03:24 --> Parser Class Initialized
INFO - 2024-05-21 08:03:24 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-05-21 08:03:24 --> Pagination Class Initialized
INFO - 2024-05-21 08:03:24 --> Form Validation Class Initialized
INFO - 2024-05-21 08:03:24 --> Controller Class Initialized
INFO - 2024-05-21 08:03:24 --> Model Class Initialized
DEBUG - 2024-05-21 08:03:24 --> Session class already loaded. Second attempt ignored.
INFO - 2024-05-21 08:03:24 --> File loaded: /home/u241458058/domains/technoprimex.com/public_html/maurnaturo/application/views/user/admin_login_form.php
DEBUG - 2024-05-21 08:03:24 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-05-21 08:03:24 --> File loaded: /home/u241458058/domains/technoprimex.com/public_html/maurnaturo/application/views/include/top_menu.php
INFO - 2024-05-21 08:03:24 --> File loaded: /home/u241458058/domains/technoprimex.com/public_html/maurnaturo/application/views/include/admin_loggedin_info.php
INFO - 2024-05-21 08:03:24 --> Model Class Initialized
INFO - 2024-05-21 08:03:24 --> File loaded: /home/u241458058/domains/technoprimex.com/public_html/maurnaturo/application/views/admin_html_template.php
INFO - 2024-05-21 08:03:24 --> Final output sent to browser
DEBUG - 2024-05-21 08:03:24 --> Total execution time: 0.0225
ERROR - 2024-05-21 08:05:51 --> $config['composer_autoload'] is set to TRUE but /home/u241458058/domains/technoprimex.com/public_html/maurnaturo/application/vendor/autoload.php was not found.
INFO - 2024-05-21 08:05:51 --> Config Class Initialized
INFO - 2024-05-21 08:05:51 --> Hooks Class Initialized
DEBUG - 2024-05-21 08:05:51 --> UTF-8 Support Enabled
INFO - 2024-05-21 08:05:51 --> Utf8 Class Initialized
INFO - 2024-05-21 08:05:51 --> URI Class Initialized
INFO - 2024-05-21 08:05:51 --> Router Class Initialized
INFO - 2024-05-21 08:05:51 --> Output Class Initialized
INFO - 2024-05-21 08:05:51 --> Security Class Initialized
DEBUG - 2024-05-21 08:05:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-21 08:05:51 --> Input Class Initialized
INFO - 2024-05-21 08:05:51 --> Language Class Initialized
INFO - 2024-05-21 08:05:51 --> Loader Class Initialized
INFO - 2024-05-21 08:05:51 --> Helper loaded: url_helper
INFO - 2024-05-21 08:05:51 --> Helper loaded: file_helper
INFO - 2024-05-21 08:05:51 --> Helper loaded: html_helper
INFO - 2024-05-21 08:05:51 --> Helper loaded: text_helper
INFO - 2024-05-21 08:05:51 --> Helper loaded: form_helper
INFO - 2024-05-21 08:05:51 --> Helper loaded: lang_helper
INFO - 2024-05-21 08:05:51 --> Helper loaded: security_helper
INFO - 2024-05-21 08:05:51 --> Helper loaded: cookie_helper
INFO - 2024-05-21 08:05:51 --> Database Driver Class Initialized
INFO - 2024-05-21 08:05:51 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-21 08:05:51 --> Parser Class Initialized
INFO - 2024-05-21 08:05:51 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-05-21 08:05:51 --> Pagination Class Initialized
INFO - 2024-05-21 08:05:51 --> Form Validation Class Initialized
INFO - 2024-05-21 08:05:51 --> Controller Class Initialized
DEBUG - 2024-05-21 08:05:51 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-05-21 08:05:51 --> Session class already loaded. Second attempt ignored.
INFO - 2024-05-21 08:05:51 --> Model Class Initialized
DEBUG - 2024-05-21 08:05:51 --> Session class already loaded. Second attempt ignored.
INFO - 2024-05-21 08:05:51 --> Model Class Initialized
DEBUG - 2024-05-21 08:05:51 --> Lcustomer class already loaded. Second attempt ignored.
INFO - 2024-05-21 08:05:51 --> Model Class Initialized
INFO - 2024-05-21 08:05:51 --> File loaded: /home/u241458058/domains/technoprimex.com/public_html/maurnaturo/application/views/customer/customer.php
DEBUG - 2024-05-21 08:05:51 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-05-21 08:05:51 --> File loaded: /home/u241458058/domains/technoprimex.com/public_html/maurnaturo/application/views/include/top_menu.php
INFO - 2024-05-21 08:05:51 --> File loaded: /home/u241458058/domains/technoprimex.com/public_html/maurnaturo/application/views/include/admin_loggedin_info.php
INFO - 2024-05-21 08:05:51 --> Model Class Initialized
INFO - 2024-05-21 08:05:51 --> Model Class Initialized
INFO - 2024-05-21 08:05:51 --> Model Class Initialized
INFO - 2024-05-21 08:05:51 --> File loaded: /home/u241458058/domains/technoprimex.com/public_html/maurnaturo/application/views/include/admin_header.php
INFO - 2024-05-21 08:05:51 --> File loaded: /home/u241458058/domains/technoprimex.com/public_html/maurnaturo/application/views/include/admin_footer.php
INFO - 2024-05-21 08:05:51 --> File loaded: /home/u241458058/domains/technoprimex.com/public_html/maurnaturo/application/views/admin_html_template.php
INFO - 2024-05-21 08:05:51 --> Final output sent to browser
DEBUG - 2024-05-21 08:05:51 --> Total execution time: 0.1401
ERROR - 2024-05-21 08:05:52 --> $config['composer_autoload'] is set to TRUE but /home/u241458058/domains/technoprimex.com/public_html/maurnaturo/application/vendor/autoload.php was not found.
INFO - 2024-05-21 08:05:52 --> Config Class Initialized
INFO - 2024-05-21 08:05:52 --> Hooks Class Initialized
DEBUG - 2024-05-21 08:05:52 --> UTF-8 Support Enabled
INFO - 2024-05-21 08:05:52 --> Utf8 Class Initialized
INFO - 2024-05-21 08:05:52 --> URI Class Initialized
INFO - 2024-05-21 08:05:52 --> Router Class Initialized
INFO - 2024-05-21 08:05:52 --> Output Class Initialized
INFO - 2024-05-21 08:05:52 --> Security Class Initialized
DEBUG - 2024-05-21 08:05:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-21 08:05:52 --> Input Class Initialized
INFO - 2024-05-21 08:05:52 --> Language Class Initialized
INFO - 2024-05-21 08:05:52 --> Loader Class Initialized
INFO - 2024-05-21 08:05:52 --> Helper loaded: url_helper
INFO - 2024-05-21 08:05:52 --> Helper loaded: file_helper
INFO - 2024-05-21 08:05:52 --> Helper loaded: html_helper
INFO - 2024-05-21 08:05:52 --> Helper loaded: text_helper
INFO - 2024-05-21 08:05:52 --> Helper loaded: form_helper
INFO - 2024-05-21 08:05:52 --> Helper loaded: lang_helper
INFO - 2024-05-21 08:05:52 --> Helper loaded: security_helper
INFO - 2024-05-21 08:05:52 --> Helper loaded: cookie_helper
INFO - 2024-05-21 08:05:52 --> Database Driver Class Initialized
INFO - 2024-05-21 08:05:52 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-21 08:05:52 --> Parser Class Initialized
INFO - 2024-05-21 08:05:52 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-05-21 08:05:52 --> Pagination Class Initialized
INFO - 2024-05-21 08:05:52 --> Form Validation Class Initialized
INFO - 2024-05-21 08:05:52 --> Controller Class Initialized
DEBUG - 2024-05-21 08:05:52 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-05-21 08:05:52 --> Session class already loaded. Second attempt ignored.
INFO - 2024-05-21 08:05:52 --> Model Class Initialized
DEBUG - 2024-05-21 08:05:52 --> Session class already loaded. Second attempt ignored.
INFO - 2024-05-21 08:05:52 --> Model Class Initialized
INFO - 2024-05-21 08:05:52 --> Final output sent to browser
DEBUG - 2024-05-21 08:05:52 --> Total execution time: 0.0246
ERROR - 2024-05-21 08:05:55 --> $config['composer_autoload'] is set to TRUE but /home/u241458058/domains/technoprimex.com/public_html/maurnaturo/application/vendor/autoload.php was not found.
INFO - 2024-05-21 08:05:55 --> Config Class Initialized
INFO - 2024-05-21 08:05:55 --> Hooks Class Initialized
DEBUG - 2024-05-21 08:05:55 --> UTF-8 Support Enabled
INFO - 2024-05-21 08:05:55 --> Utf8 Class Initialized
INFO - 2024-05-21 08:05:55 --> URI Class Initialized
INFO - 2024-05-21 08:05:55 --> Router Class Initialized
INFO - 2024-05-21 08:05:55 --> Output Class Initialized
INFO - 2024-05-21 08:05:55 --> Security Class Initialized
DEBUG - 2024-05-21 08:05:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-21 08:05:55 --> Input Class Initialized
INFO - 2024-05-21 08:05:55 --> Language Class Initialized
INFO - 2024-05-21 08:05:55 --> Loader Class Initialized
INFO - 2024-05-21 08:05:55 --> Helper loaded: url_helper
INFO - 2024-05-21 08:05:55 --> Helper loaded: file_helper
INFO - 2024-05-21 08:05:55 --> Helper loaded: html_helper
INFO - 2024-05-21 08:05:55 --> Helper loaded: text_helper
INFO - 2024-05-21 08:05:55 --> Helper loaded: form_helper
INFO - 2024-05-21 08:05:55 --> Helper loaded: lang_helper
INFO - 2024-05-21 08:05:55 --> Helper loaded: security_helper
INFO - 2024-05-21 08:05:55 --> Helper loaded: cookie_helper
INFO - 2024-05-21 08:05:55 --> Database Driver Class Initialized
INFO - 2024-05-21 08:05:55 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-21 08:05:55 --> Parser Class Initialized
INFO - 2024-05-21 08:05:55 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-05-21 08:05:55 --> Pagination Class Initialized
INFO - 2024-05-21 08:05:55 --> Form Validation Class Initialized
INFO - 2024-05-21 08:05:55 --> Controller Class Initialized
DEBUG - 2024-05-21 08:05:55 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-05-21 08:05:55 --> Session class already loaded. Second attempt ignored.
INFO - 2024-05-21 08:05:55 --> Model Class Initialized
DEBUG - 2024-05-21 08:05:55 --> Session class already loaded. Second attempt ignored.
INFO - 2024-05-21 08:05:55 --> Model Class Initialized
INFO - 2024-05-21 08:05:55 --> File loaded: /home/u241458058/domains/technoprimex.com/public_html/maurnaturo/application/views/customer/customer_change_password_form.php
DEBUG - 2024-05-21 08:05:55 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-05-21 08:05:55 --> File loaded: /home/u241458058/domains/technoprimex.com/public_html/maurnaturo/application/views/include/top_menu.php
INFO - 2024-05-21 08:05:55 --> File loaded: /home/u241458058/domains/technoprimex.com/public_html/maurnaturo/application/views/include/admin_loggedin_info.php
INFO - 2024-05-21 08:05:55 --> Model Class Initialized
INFO - 2024-05-21 08:05:55 --> Model Class Initialized
INFO - 2024-05-21 08:05:55 --> Model Class Initialized
INFO - 2024-05-21 08:05:55 --> Model Class Initialized
INFO - 2024-05-21 08:05:55 --> File loaded: /home/u241458058/domains/technoprimex.com/public_html/maurnaturo/application/views/include/admin_header.php
INFO - 2024-05-21 08:05:55 --> File loaded: /home/u241458058/domains/technoprimex.com/public_html/maurnaturo/application/views/include/admin_footer.php
INFO - 2024-05-21 08:05:55 --> File loaded: /home/u241458058/domains/technoprimex.com/public_html/maurnaturo/application/views/admin_html_template.php
INFO - 2024-05-21 08:05:55 --> Final output sent to browser
DEBUG - 2024-05-21 08:05:55 --> Total execution time: 0.1345
ERROR - 2024-05-21 08:06:16 --> $config['composer_autoload'] is set to TRUE but /home/u241458058/domains/technoprimex.com/public_html/maurnaturo/application/vendor/autoload.php was not found.
INFO - 2024-05-21 08:06:16 --> Config Class Initialized
INFO - 2024-05-21 08:06:16 --> Hooks Class Initialized
DEBUG - 2024-05-21 08:06:16 --> UTF-8 Support Enabled
INFO - 2024-05-21 08:06:16 --> Utf8 Class Initialized
INFO - 2024-05-21 08:06:16 --> URI Class Initialized
INFO - 2024-05-21 08:06:16 --> Router Class Initialized
INFO - 2024-05-21 08:06:16 --> Output Class Initialized
INFO - 2024-05-21 08:06:16 --> Security Class Initialized
DEBUG - 2024-05-21 08:06:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-21 08:06:16 --> Input Class Initialized
INFO - 2024-05-21 08:06:16 --> Language Class Initialized
INFO - 2024-05-21 08:06:16 --> Loader Class Initialized
INFO - 2024-05-21 08:06:16 --> Helper loaded: url_helper
INFO - 2024-05-21 08:06:16 --> Helper loaded: file_helper
INFO - 2024-05-21 08:06:16 --> Helper loaded: html_helper
INFO - 2024-05-21 08:06:16 --> Helper loaded: text_helper
INFO - 2024-05-21 08:06:16 --> Helper loaded: form_helper
INFO - 2024-05-21 08:06:16 --> Helper loaded: lang_helper
INFO - 2024-05-21 08:06:16 --> Helper loaded: security_helper
INFO - 2024-05-21 08:06:16 --> Helper loaded: cookie_helper
INFO - 2024-05-21 08:06:16 --> Database Driver Class Initialized
INFO - 2024-05-21 08:06:16 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-21 08:06:16 --> Parser Class Initialized
INFO - 2024-05-21 08:06:16 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-05-21 08:06:16 --> Pagination Class Initialized
INFO - 2024-05-21 08:06:16 --> Form Validation Class Initialized
INFO - 2024-05-21 08:06:16 --> Controller Class Initialized
INFO - 2024-05-21 08:06:16 --> Model Class Initialized
DEBUG - 2024-05-21 08:06:16 --> Session class already loaded. Second attempt ignored.
INFO - 2024-05-21 08:06:16 --> Model Class Initialized
INFO - 2024-05-21 08:06:16 --> Final output sent to browser
DEBUG - 2024-05-21 08:06:16 --> Total execution time: 0.0101
ERROR - 2024-05-21 08:06:17 --> $config['composer_autoload'] is set to TRUE but /home/u241458058/domains/technoprimex.com/public_html/maurnaturo/application/vendor/autoload.php was not found.
INFO - 2024-05-21 08:06:17 --> Config Class Initialized
INFO - 2024-05-21 08:06:17 --> Hooks Class Initialized
DEBUG - 2024-05-21 08:06:17 --> UTF-8 Support Enabled
INFO - 2024-05-21 08:06:17 --> Utf8 Class Initialized
INFO - 2024-05-21 08:06:17 --> URI Class Initialized
DEBUG - 2024-05-21 08:06:17 --> No URI present. Default controller set.
INFO - 2024-05-21 08:06:17 --> Router Class Initialized
INFO - 2024-05-21 08:06:17 --> Output Class Initialized
INFO - 2024-05-21 08:06:17 --> Security Class Initialized
DEBUG - 2024-05-21 08:06:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-21 08:06:17 --> Input Class Initialized
INFO - 2024-05-21 08:06:17 --> Language Class Initialized
INFO - 2024-05-21 08:06:17 --> Loader Class Initialized
INFO - 2024-05-21 08:06:17 --> Helper loaded: url_helper
INFO - 2024-05-21 08:06:17 --> Helper loaded: file_helper
INFO - 2024-05-21 08:06:17 --> Helper loaded: html_helper
INFO - 2024-05-21 08:06:17 --> Helper loaded: text_helper
INFO - 2024-05-21 08:06:17 --> Helper loaded: form_helper
INFO - 2024-05-21 08:06:17 --> Helper loaded: lang_helper
INFO - 2024-05-21 08:06:17 --> Helper loaded: security_helper
INFO - 2024-05-21 08:06:17 --> Helper loaded: cookie_helper
INFO - 2024-05-21 08:06:17 --> Database Driver Class Initialized
INFO - 2024-05-21 08:06:17 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-21 08:06:17 --> Parser Class Initialized
INFO - 2024-05-21 08:06:17 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-05-21 08:06:17 --> Pagination Class Initialized
INFO - 2024-05-21 08:06:17 --> Form Validation Class Initialized
INFO - 2024-05-21 08:06:17 --> Controller Class Initialized
INFO - 2024-05-21 08:06:17 --> Model Class Initialized
DEBUG - 2024-05-21 08:06:17 --> Session class already loaded. Second attempt ignored.
INFO - 2024-05-21 08:06:17 --> Model Class Initialized
DEBUG - 2024-05-21 08:06:17 --> Session class already loaded. Second attempt ignored.
INFO - 2024-05-21 08:06:17 --> Model Class Initialized
INFO - 2024-05-21 08:06:17 --> Model Class Initialized
INFO - 2024-05-21 08:06:17 --> Model Class Initialized
INFO - 2024-05-21 08:06:17 --> Model Class Initialized
DEBUG - 2024-05-21 08:06:17 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-05-21 08:06:17 --> Session class already loaded. Second attempt ignored.
INFO - 2024-05-21 08:06:17 --> Model Class Initialized
INFO - 2024-05-21 08:06:17 --> Model Class Initialized
INFO - 2024-05-21 08:06:17 --> File loaded: /home/u241458058/domains/technoprimex.com/public_html/maurnaturo/application/views/include/admin_home.php
DEBUG - 2024-05-21 08:06:17 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-05-21 08:06:17 --> File loaded: /home/u241458058/domains/technoprimex.com/public_html/maurnaturo/application/views/include/top_menu.php
INFO - 2024-05-21 08:06:17 --> File loaded: /home/u241458058/domains/technoprimex.com/public_html/maurnaturo/application/views/include/admin_loggedin_info.php
INFO - 2024-05-21 08:06:17 --> Model Class Initialized
INFO - 2024-05-21 08:06:17 --> File loaded: /home/u241458058/domains/technoprimex.com/public_html/maurnaturo/application/views/include/admin_header.php
INFO - 2024-05-21 08:06:17 --> File loaded: /home/u241458058/domains/technoprimex.com/public_html/maurnaturo/application/views/include/admin_footer.php
INFO - 2024-05-21 08:06:17 --> File loaded: /home/u241458058/domains/technoprimex.com/public_html/maurnaturo/application/views/admin_html_template.php
INFO - 2024-05-21 08:06:17 --> Final output sent to browser
DEBUG - 2024-05-21 08:06:17 --> Total execution time: 0.1289
ERROR - 2024-05-21 08:06:26 --> $config['composer_autoload'] is set to TRUE but /home/u241458058/domains/technoprimex.com/public_html/maurnaturo/application/vendor/autoload.php was not found.
INFO - 2024-05-21 08:06:26 --> Config Class Initialized
INFO - 2024-05-21 08:06:26 --> Hooks Class Initialized
DEBUG - 2024-05-21 08:06:26 --> UTF-8 Support Enabled
INFO - 2024-05-21 08:06:26 --> Utf8 Class Initialized
INFO - 2024-05-21 08:06:26 --> URI Class Initialized
INFO - 2024-05-21 08:06:26 --> Router Class Initialized
INFO - 2024-05-21 08:06:26 --> Output Class Initialized
INFO - 2024-05-21 08:06:26 --> Security Class Initialized
DEBUG - 2024-05-21 08:06:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-21 08:06:26 --> Input Class Initialized
INFO - 2024-05-21 08:06:26 --> Language Class Initialized
INFO - 2024-05-21 08:06:26 --> Loader Class Initialized
INFO - 2024-05-21 08:06:26 --> Helper loaded: url_helper
INFO - 2024-05-21 08:06:26 --> Helper loaded: file_helper
INFO - 2024-05-21 08:06:26 --> Helper loaded: html_helper
INFO - 2024-05-21 08:06:26 --> Helper loaded: text_helper
INFO - 2024-05-21 08:06:26 --> Helper loaded: form_helper
INFO - 2024-05-21 08:06:26 --> Helper loaded: lang_helper
INFO - 2024-05-21 08:06:26 --> Helper loaded: security_helper
INFO - 2024-05-21 08:06:26 --> Helper loaded: cookie_helper
INFO - 2024-05-21 08:06:26 --> Database Driver Class Initialized
INFO - 2024-05-21 08:06:26 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-21 08:06:26 --> Parser Class Initialized
INFO - 2024-05-21 08:06:26 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-05-21 08:06:26 --> Pagination Class Initialized
INFO - 2024-05-21 08:06:26 --> Form Validation Class Initialized
INFO - 2024-05-21 08:06:26 --> Controller Class Initialized
INFO - 2024-05-21 08:06:26 --> Model Class Initialized
DEBUG - 2024-05-21 08:06:26 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-05-21 08:06:26 --> Session class already loaded. Second attempt ignored.
INFO - 2024-05-21 08:06:26 --> Model Class Initialized
DEBUG - 2024-05-21 08:06:26 --> Session class already loaded. Second attempt ignored.
INFO - 2024-05-21 08:06:26 --> Model Class Initialized
INFO - 2024-05-21 08:06:26 --> File loaded: /home/u241458058/domains/technoprimex.com/public_html/maurnaturo/application/views/invoice/invoice.php
DEBUG - 2024-05-21 08:06:26 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-05-21 08:06:26 --> File loaded: /home/u241458058/domains/technoprimex.com/public_html/maurnaturo/application/views/include/top_menu.php
INFO - 2024-05-21 08:06:26 --> File loaded: /home/u241458058/domains/technoprimex.com/public_html/maurnaturo/application/views/include/admin_loggedin_info.php
INFO - 2024-05-21 08:06:26 --> Model Class Initialized
INFO - 2024-05-21 08:06:26 --> Model Class Initialized
INFO - 2024-05-21 08:06:26 --> Model Class Initialized
INFO - 2024-05-21 08:06:26 --> File loaded: /home/u241458058/domains/technoprimex.com/public_html/maurnaturo/application/views/include/admin_header.php
INFO - 2024-05-21 08:06:26 --> File loaded: /home/u241458058/domains/technoprimex.com/public_html/maurnaturo/application/views/include/admin_footer.php
INFO - 2024-05-21 08:06:26 --> File loaded: /home/u241458058/domains/technoprimex.com/public_html/maurnaturo/application/views/admin_html_template.php
INFO - 2024-05-21 08:06:26 --> Final output sent to browser
DEBUG - 2024-05-21 08:06:26 --> Total execution time: 0.0800
ERROR - 2024-05-21 08:06:27 --> $config['composer_autoload'] is set to TRUE but /home/u241458058/domains/technoprimex.com/public_html/maurnaturo/application/vendor/autoload.php was not found.
INFO - 2024-05-21 08:06:27 --> Config Class Initialized
INFO - 2024-05-21 08:06:27 --> Hooks Class Initialized
DEBUG - 2024-05-21 08:06:27 --> UTF-8 Support Enabled
INFO - 2024-05-21 08:06:27 --> Utf8 Class Initialized
INFO - 2024-05-21 08:06:27 --> URI Class Initialized
INFO - 2024-05-21 08:06:27 --> Router Class Initialized
INFO - 2024-05-21 08:06:27 --> Output Class Initialized
INFO - 2024-05-21 08:06:27 --> Security Class Initialized
DEBUG - 2024-05-21 08:06:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-21 08:06:27 --> Input Class Initialized
INFO - 2024-05-21 08:06:27 --> Language Class Initialized
INFO - 2024-05-21 08:06:27 --> Loader Class Initialized
INFO - 2024-05-21 08:06:27 --> Helper loaded: url_helper
INFO - 2024-05-21 08:06:27 --> Helper loaded: file_helper
INFO - 2024-05-21 08:06:27 --> Helper loaded: html_helper
INFO - 2024-05-21 08:06:27 --> Helper loaded: text_helper
INFO - 2024-05-21 08:06:27 --> Helper loaded: form_helper
INFO - 2024-05-21 08:06:27 --> Helper loaded: lang_helper
INFO - 2024-05-21 08:06:27 --> Helper loaded: security_helper
INFO - 2024-05-21 08:06:27 --> Helper loaded: cookie_helper
INFO - 2024-05-21 08:06:27 --> Database Driver Class Initialized
INFO - 2024-05-21 08:06:27 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-21 08:06:27 --> Parser Class Initialized
INFO - 2024-05-21 08:06:27 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-05-21 08:06:27 --> Pagination Class Initialized
INFO - 2024-05-21 08:06:27 --> Form Validation Class Initialized
INFO - 2024-05-21 08:06:27 --> Controller Class Initialized
INFO - 2024-05-21 08:06:27 --> Model Class Initialized
DEBUG - 2024-05-21 08:06:27 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-05-21 08:06:27 --> Session class already loaded. Second attempt ignored.
INFO - 2024-05-21 08:06:27 --> Model Class Initialized
DEBUG - 2024-05-21 08:06:27 --> Session class already loaded. Second attempt ignored.
INFO - 2024-05-21 08:06:27 --> Model Class Initialized
INFO - 2024-05-21 08:06:27 --> Final output sent to browser
DEBUG - 2024-05-21 08:06:27 --> Total execution time: 0.0076
ERROR - 2024-05-21 08:06:30 --> $config['composer_autoload'] is set to TRUE but /home/u241458058/domains/technoprimex.com/public_html/maurnaturo/application/vendor/autoload.php was not found.
INFO - 2024-05-21 08:06:30 --> Config Class Initialized
INFO - 2024-05-21 08:06:30 --> Hooks Class Initialized
DEBUG - 2024-05-21 08:06:30 --> UTF-8 Support Enabled
INFO - 2024-05-21 08:06:30 --> Utf8 Class Initialized
INFO - 2024-05-21 08:06:30 --> URI Class Initialized
INFO - 2024-05-21 08:06:30 --> Router Class Initialized
INFO - 2024-05-21 08:06:30 --> Output Class Initialized
INFO - 2024-05-21 08:06:30 --> Security Class Initialized
DEBUG - 2024-05-21 08:06:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-21 08:06:30 --> Input Class Initialized
INFO - 2024-05-21 08:06:30 --> Language Class Initialized
INFO - 2024-05-21 08:06:30 --> Loader Class Initialized
INFO - 2024-05-21 08:06:30 --> Helper loaded: url_helper
INFO - 2024-05-21 08:06:30 --> Helper loaded: file_helper
INFO - 2024-05-21 08:06:30 --> Helper loaded: html_helper
INFO - 2024-05-21 08:06:30 --> Helper loaded: text_helper
INFO - 2024-05-21 08:06:30 --> Helper loaded: form_helper
INFO - 2024-05-21 08:06:30 --> Helper loaded: lang_helper
INFO - 2024-05-21 08:06:30 --> Helper loaded: security_helper
INFO - 2024-05-21 08:06:30 --> Helper loaded: cookie_helper
INFO - 2024-05-21 08:06:30 --> Database Driver Class Initialized
INFO - 2024-05-21 08:06:30 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-21 08:06:30 --> Parser Class Initialized
INFO - 2024-05-21 08:06:30 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-05-21 08:06:30 --> Pagination Class Initialized
INFO - 2024-05-21 08:06:30 --> Form Validation Class Initialized
INFO - 2024-05-21 08:06:30 --> Controller Class Initialized
INFO - 2024-05-21 08:06:30 --> Model Class Initialized
DEBUG - 2024-05-21 08:06:30 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-05-21 08:06:30 --> Session class already loaded. Second attempt ignored.
INFO - 2024-05-21 08:06:30 --> Model Class Initialized
DEBUG - 2024-05-21 08:06:30 --> Session class already loaded. Second attempt ignored.
INFO - 2024-05-21 08:06:30 --> Model Class Initialized
INFO - 2024-05-21 08:06:30 --> File loaded: /home/u241458058/domains/technoprimex.com/public_html/maurnaturo/application/views/proformainvoice/invoice.php
DEBUG - 2024-05-21 08:06:30 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-05-21 08:06:30 --> File loaded: /home/u241458058/domains/technoprimex.com/public_html/maurnaturo/application/views/include/top_menu.php
INFO - 2024-05-21 08:06:30 --> File loaded: /home/u241458058/domains/technoprimex.com/public_html/maurnaturo/application/views/include/admin_loggedin_info.php
INFO - 2024-05-21 08:06:30 --> Model Class Initialized
INFO - 2024-05-21 08:06:30 --> Model Class Initialized
INFO - 2024-05-21 08:06:30 --> Model Class Initialized
INFO - 2024-05-21 08:06:30 --> File loaded: /home/u241458058/domains/technoprimex.com/public_html/maurnaturo/application/views/include/admin_header.php
INFO - 2024-05-21 08:06:30 --> File loaded: /home/u241458058/domains/technoprimex.com/public_html/maurnaturo/application/views/include/admin_footer.php
INFO - 2024-05-21 08:06:30 --> File loaded: /home/u241458058/domains/technoprimex.com/public_html/maurnaturo/application/views/admin_html_template.php
INFO - 2024-05-21 08:06:30 --> Final output sent to browser
DEBUG - 2024-05-21 08:06:30 --> Total execution time: 0.0813
ERROR - 2024-05-21 08:06:31 --> $config['composer_autoload'] is set to TRUE but /home/u241458058/domains/technoprimex.com/public_html/maurnaturo/application/vendor/autoload.php was not found.
INFO - 2024-05-21 08:06:31 --> Config Class Initialized
INFO - 2024-05-21 08:06:31 --> Hooks Class Initialized
DEBUG - 2024-05-21 08:06:31 --> UTF-8 Support Enabled
INFO - 2024-05-21 08:06:31 --> Utf8 Class Initialized
INFO - 2024-05-21 08:06:31 --> URI Class Initialized
INFO - 2024-05-21 08:06:31 --> Router Class Initialized
INFO - 2024-05-21 08:06:31 --> Output Class Initialized
INFO - 2024-05-21 08:06:31 --> Security Class Initialized
DEBUG - 2024-05-21 08:06:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-21 08:06:31 --> Input Class Initialized
INFO - 2024-05-21 08:06:31 --> Language Class Initialized
INFO - 2024-05-21 08:06:31 --> Loader Class Initialized
INFO - 2024-05-21 08:06:31 --> Helper loaded: url_helper
INFO - 2024-05-21 08:06:31 --> Helper loaded: file_helper
INFO - 2024-05-21 08:06:31 --> Helper loaded: html_helper
INFO - 2024-05-21 08:06:31 --> Helper loaded: text_helper
INFO - 2024-05-21 08:06:31 --> Helper loaded: form_helper
INFO - 2024-05-21 08:06:31 --> Helper loaded: lang_helper
INFO - 2024-05-21 08:06:31 --> Helper loaded: security_helper
INFO - 2024-05-21 08:06:31 --> Helper loaded: cookie_helper
INFO - 2024-05-21 08:06:31 --> Database Driver Class Initialized
INFO - 2024-05-21 08:06:31 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-21 08:06:31 --> Parser Class Initialized
INFO - 2024-05-21 08:06:31 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-05-21 08:06:31 --> Pagination Class Initialized
INFO - 2024-05-21 08:06:31 --> Form Validation Class Initialized
INFO - 2024-05-21 08:06:31 --> Controller Class Initialized
INFO - 2024-05-21 08:06:31 --> Model Class Initialized
DEBUG - 2024-05-21 08:06:31 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-05-21 08:06:31 --> Session class already loaded. Second attempt ignored.
INFO - 2024-05-21 08:06:31 --> Model Class Initialized
DEBUG - 2024-05-21 08:06:31 --> Session class already loaded. Second attempt ignored.
INFO - 2024-05-21 08:06:31 --> Model Class Initialized
INFO - 2024-05-21 08:06:31 --> Final output sent to browser
DEBUG - 2024-05-21 08:06:31 --> Total execution time: 0.0095
ERROR - 2024-05-21 08:07:28 --> $config['composer_autoload'] is set to TRUE but /home/u241458058/domains/technoprimex.com/public_html/maurnaturo/application/vendor/autoload.php was not found.
INFO - 2024-05-21 08:07:28 --> Config Class Initialized
INFO - 2024-05-21 08:07:28 --> Hooks Class Initialized
DEBUG - 2024-05-21 08:07:28 --> UTF-8 Support Enabled
INFO - 2024-05-21 08:07:28 --> Utf8 Class Initialized
INFO - 2024-05-21 08:07:28 --> URI Class Initialized
INFO - 2024-05-21 08:07:28 --> Router Class Initialized
INFO - 2024-05-21 08:07:28 --> Output Class Initialized
INFO - 2024-05-21 08:07:28 --> Security Class Initialized
DEBUG - 2024-05-21 08:07:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-21 08:07:28 --> Input Class Initialized
INFO - 2024-05-21 08:07:28 --> Language Class Initialized
INFO - 2024-05-21 08:07:28 --> Loader Class Initialized
INFO - 2024-05-21 08:07:28 --> Helper loaded: url_helper
INFO - 2024-05-21 08:07:28 --> Helper loaded: file_helper
INFO - 2024-05-21 08:07:28 --> Helper loaded: html_helper
INFO - 2024-05-21 08:07:28 --> Helper loaded: text_helper
INFO - 2024-05-21 08:07:28 --> Helper loaded: form_helper
INFO - 2024-05-21 08:07:28 --> Helper loaded: lang_helper
INFO - 2024-05-21 08:07:28 --> Helper loaded: security_helper
INFO - 2024-05-21 08:07:28 --> Helper loaded: cookie_helper
INFO - 2024-05-21 08:07:28 --> Database Driver Class Initialized
INFO - 2024-05-21 08:07:28 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-21 08:07:28 --> Parser Class Initialized
INFO - 2024-05-21 08:07:28 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-05-21 08:07:28 --> Pagination Class Initialized
INFO - 2024-05-21 08:07:28 --> Form Validation Class Initialized
INFO - 2024-05-21 08:07:28 --> Controller Class Initialized
INFO - 2024-05-21 08:07:28 --> Model Class Initialized
DEBUG - 2024-05-21 08:07:28 --> Session class already loaded. Second attempt ignored.
INFO - 2024-05-21 08:07:28 --> Final output sent to browser
DEBUG - 2024-05-21 08:07:28 --> Total execution time: 0.0054
ERROR - 2024-05-21 08:07:28 --> $config['composer_autoload'] is set to TRUE but /home/u241458058/domains/technoprimex.com/public_html/maurnaturo/application/vendor/autoload.php was not found.
INFO - 2024-05-21 08:07:28 --> Config Class Initialized
INFO - 2024-05-21 08:07:28 --> Hooks Class Initialized
DEBUG - 2024-05-21 08:07:28 --> UTF-8 Support Enabled
INFO - 2024-05-21 08:07:28 --> Utf8 Class Initialized
INFO - 2024-05-21 08:07:28 --> URI Class Initialized
INFO - 2024-05-21 08:07:28 --> Router Class Initialized
INFO - 2024-05-21 08:07:28 --> Output Class Initialized
INFO - 2024-05-21 08:07:28 --> Security Class Initialized
DEBUG - 2024-05-21 08:07:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-21 08:07:28 --> Input Class Initialized
INFO - 2024-05-21 08:07:28 --> Language Class Initialized
INFO - 2024-05-21 08:07:28 --> Loader Class Initialized
INFO - 2024-05-21 08:07:28 --> Helper loaded: url_helper
INFO - 2024-05-21 08:07:28 --> Helper loaded: file_helper
INFO - 2024-05-21 08:07:28 --> Helper loaded: html_helper
INFO - 2024-05-21 08:07:28 --> Helper loaded: text_helper
INFO - 2024-05-21 08:07:28 --> Helper loaded: form_helper
INFO - 2024-05-21 08:07:28 --> Helper loaded: lang_helper
INFO - 2024-05-21 08:07:28 --> Helper loaded: security_helper
INFO - 2024-05-21 08:07:28 --> Helper loaded: cookie_helper
INFO - 2024-05-21 08:07:28 --> Database Driver Class Initialized
INFO - 2024-05-21 08:07:28 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-21 08:07:28 --> Parser Class Initialized
INFO - 2024-05-21 08:07:28 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-05-21 08:07:28 --> Pagination Class Initialized
INFO - 2024-05-21 08:07:28 --> Form Validation Class Initialized
INFO - 2024-05-21 08:07:28 --> Controller Class Initialized
INFO - 2024-05-21 08:07:28 --> Model Class Initialized
DEBUG - 2024-05-21 08:07:28 --> Session class already loaded. Second attempt ignored.
INFO - 2024-05-21 08:07:28 --> File loaded: /home/u241458058/domains/technoprimex.com/public_html/maurnaturo/application/views/user/admin_login_form.php
DEBUG - 2024-05-21 08:07:28 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-05-21 08:07:28 --> File loaded: /home/u241458058/domains/technoprimex.com/public_html/maurnaturo/application/views/include/top_menu.php
INFO - 2024-05-21 08:07:28 --> File loaded: /home/u241458058/domains/technoprimex.com/public_html/maurnaturo/application/views/include/admin_loggedin_info.php
INFO - 2024-05-21 08:07:28 --> Model Class Initialized
INFO - 2024-05-21 08:07:28 --> File loaded: /home/u241458058/domains/technoprimex.com/public_html/maurnaturo/application/views/admin_html_template.php
INFO - 2024-05-21 08:07:28 --> Final output sent to browser
DEBUG - 2024-05-21 08:07:28 --> Total execution time: 0.0182
ERROR - 2024-05-21 08:07:36 --> $config['composer_autoload'] is set to TRUE but /home/u241458058/domains/technoprimex.com/public_html/maurnaturo/application/vendor/autoload.php was not found.
INFO - 2024-05-21 08:07:36 --> Config Class Initialized
INFO - 2024-05-21 08:07:36 --> Hooks Class Initialized
DEBUG - 2024-05-21 08:07:36 --> UTF-8 Support Enabled
INFO - 2024-05-21 08:07:36 --> Utf8 Class Initialized
INFO - 2024-05-21 08:07:36 --> URI Class Initialized
INFO - 2024-05-21 08:07:36 --> Router Class Initialized
INFO - 2024-05-21 08:07:36 --> Output Class Initialized
INFO - 2024-05-21 08:07:36 --> Security Class Initialized
DEBUG - 2024-05-21 08:07:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-21 08:07:36 --> Input Class Initialized
INFO - 2024-05-21 08:07:36 --> Language Class Initialized
INFO - 2024-05-21 08:07:36 --> Loader Class Initialized
INFO - 2024-05-21 08:07:36 --> Helper loaded: url_helper
INFO - 2024-05-21 08:07:36 --> Helper loaded: file_helper
INFO - 2024-05-21 08:07:36 --> Helper loaded: html_helper
INFO - 2024-05-21 08:07:36 --> Helper loaded: text_helper
INFO - 2024-05-21 08:07:36 --> Helper loaded: form_helper
INFO - 2024-05-21 08:07:36 --> Helper loaded: lang_helper
INFO - 2024-05-21 08:07:36 --> Helper loaded: security_helper
INFO - 2024-05-21 08:07:36 --> Helper loaded: cookie_helper
INFO - 2024-05-21 08:07:36 --> Database Driver Class Initialized
INFO - 2024-05-21 08:07:36 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-21 08:07:36 --> Parser Class Initialized
INFO - 2024-05-21 08:07:36 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-05-21 08:07:36 --> Pagination Class Initialized
INFO - 2024-05-21 08:07:36 --> Form Validation Class Initialized
INFO - 2024-05-21 08:07:36 --> Controller Class Initialized
DEBUG - 2024-05-21 08:07:36 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-05-21 08:07:36 --> Session class already loaded. Second attempt ignored.
INFO - 2024-05-21 08:07:36 --> Model Class Initialized
INFO - 2024-05-21 08:07:36 --> Model Class Initialized
DEBUG - 2024-05-21 08:07:36 --> Lmr class already loaded. Second attempt ignored.
INFO - 2024-05-21 08:07:36 --> Model Class Initialized
INFO - 2024-05-21 08:07:36 --> File loaded: /home/u241458058/domains/technoprimex.com/public_html/maurnaturo/application/views/mr/mr.php
DEBUG - 2024-05-21 08:07:36 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-05-21 08:07:36 --> File loaded: /home/u241458058/domains/technoprimex.com/public_html/maurnaturo/application/views/include/top_menu.php
INFO - 2024-05-21 08:07:36 --> File loaded: /home/u241458058/domains/technoprimex.com/public_html/maurnaturo/application/views/include/admin_loggedin_info.php
INFO - 2024-05-21 08:07:36 --> Model Class Initialized
INFO - 2024-05-21 08:07:36 --> Model Class Initialized
INFO - 2024-05-21 08:07:36 --> Model Class Initialized
INFO - 2024-05-21 08:07:36 --> File loaded: /home/u241458058/domains/technoprimex.com/public_html/maurnaturo/application/views/include/admin_header.php
INFO - 2024-05-21 08:07:36 --> File loaded: /home/u241458058/domains/technoprimex.com/public_html/maurnaturo/application/views/include/admin_footer.php
INFO - 2024-05-21 08:07:36 --> File loaded: /home/u241458058/domains/technoprimex.com/public_html/maurnaturo/application/views/admin_html_template.php
INFO - 2024-05-21 08:07:36 --> Final output sent to browser
DEBUG - 2024-05-21 08:07:36 --> Total execution time: 0.1335
ERROR - 2024-05-21 08:07:37 --> $config['composer_autoload'] is set to TRUE but /home/u241458058/domains/technoprimex.com/public_html/maurnaturo/application/vendor/autoload.php was not found.
INFO - 2024-05-21 08:07:37 --> Config Class Initialized
INFO - 2024-05-21 08:07:37 --> Hooks Class Initialized
DEBUG - 2024-05-21 08:07:37 --> UTF-8 Support Enabled
INFO - 2024-05-21 08:07:37 --> Utf8 Class Initialized
INFO - 2024-05-21 08:07:37 --> URI Class Initialized
INFO - 2024-05-21 08:07:37 --> Router Class Initialized
INFO - 2024-05-21 08:07:37 --> Output Class Initialized
INFO - 2024-05-21 08:07:37 --> Security Class Initialized
DEBUG - 2024-05-21 08:07:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-21 08:07:37 --> Input Class Initialized
INFO - 2024-05-21 08:07:37 --> Language Class Initialized
INFO - 2024-05-21 08:07:37 --> Loader Class Initialized
INFO - 2024-05-21 08:07:37 --> Helper loaded: url_helper
INFO - 2024-05-21 08:07:37 --> Helper loaded: file_helper
INFO - 2024-05-21 08:07:37 --> Helper loaded: html_helper
INFO - 2024-05-21 08:07:37 --> Helper loaded: text_helper
INFO - 2024-05-21 08:07:37 --> Helper loaded: form_helper
INFO - 2024-05-21 08:07:37 --> Helper loaded: lang_helper
INFO - 2024-05-21 08:07:37 --> Helper loaded: security_helper
INFO - 2024-05-21 08:07:37 --> Helper loaded: cookie_helper
INFO - 2024-05-21 08:07:37 --> Database Driver Class Initialized
INFO - 2024-05-21 08:07:37 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-21 08:07:37 --> Parser Class Initialized
INFO - 2024-05-21 08:07:37 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-05-21 08:07:37 --> Pagination Class Initialized
INFO - 2024-05-21 08:07:37 --> Form Validation Class Initialized
INFO - 2024-05-21 08:07:37 --> Controller Class Initialized
DEBUG - 2024-05-21 08:07:37 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-05-21 08:07:37 --> Session class already loaded. Second attempt ignored.
INFO - 2024-05-21 08:07:37 --> Model Class Initialized
INFO - 2024-05-21 08:07:37 --> Model Class Initialized
INFO - 2024-05-21 08:07:37 --> Final output sent to browser
DEBUG - 2024-05-21 08:07:37 --> Total execution time: 0.0128
ERROR - 2024-05-21 08:07:53 --> $config['composer_autoload'] is set to TRUE but /home/u241458058/domains/technoprimex.com/public_html/maurnaturo/application/vendor/autoload.php was not found.
INFO - 2024-05-21 08:07:53 --> Config Class Initialized
INFO - 2024-05-21 08:07:53 --> Hooks Class Initialized
DEBUG - 2024-05-21 08:07:53 --> UTF-8 Support Enabled
INFO - 2024-05-21 08:07:53 --> Utf8 Class Initialized
INFO - 2024-05-21 08:07:53 --> URI Class Initialized
INFO - 2024-05-21 08:07:53 --> Router Class Initialized
INFO - 2024-05-21 08:07:53 --> Output Class Initialized
INFO - 2024-05-21 08:07:53 --> Security Class Initialized
DEBUG - 2024-05-21 08:07:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-21 08:07:53 --> Input Class Initialized
INFO - 2024-05-21 08:07:53 --> Language Class Initialized
INFO - 2024-05-21 08:07:53 --> Loader Class Initialized
INFO - 2024-05-21 08:07:53 --> Helper loaded: url_helper
INFO - 2024-05-21 08:07:53 --> Helper loaded: file_helper
INFO - 2024-05-21 08:07:53 --> Helper loaded: html_helper
INFO - 2024-05-21 08:07:53 --> Helper loaded: text_helper
INFO - 2024-05-21 08:07:53 --> Helper loaded: form_helper
INFO - 2024-05-21 08:07:53 --> Helper loaded: lang_helper
INFO - 2024-05-21 08:07:53 --> Helper loaded: security_helper
INFO - 2024-05-21 08:07:53 --> Helper loaded: cookie_helper
INFO - 2024-05-21 08:07:53 --> Database Driver Class Initialized
INFO - 2024-05-21 08:07:53 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-21 08:07:53 --> Parser Class Initialized
INFO - 2024-05-21 08:07:53 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-05-21 08:07:53 --> Pagination Class Initialized
INFO - 2024-05-21 08:07:53 --> Form Validation Class Initialized
INFO - 2024-05-21 08:07:53 --> Controller Class Initialized
INFO - 2024-05-21 08:07:53 --> Model Class Initialized
DEBUG - 2024-05-21 08:07:53 --> Session class already loaded. Second attempt ignored.
INFO - 2024-05-21 08:07:53 --> Model Class Initialized
INFO - 2024-05-21 08:07:53 --> Final output sent to browser
DEBUG - 2024-05-21 08:07:53 --> Total execution time: 0.0103
ERROR - 2024-05-21 08:07:53 --> $config['composer_autoload'] is set to TRUE but /home/u241458058/domains/technoprimex.com/public_html/maurnaturo/application/vendor/autoload.php was not found.
INFO - 2024-05-21 08:07:53 --> Config Class Initialized
INFO - 2024-05-21 08:07:53 --> Hooks Class Initialized
DEBUG - 2024-05-21 08:07:53 --> UTF-8 Support Enabled
INFO - 2024-05-21 08:07:53 --> Utf8 Class Initialized
INFO - 2024-05-21 08:07:53 --> URI Class Initialized
INFO - 2024-05-21 08:07:53 --> Router Class Initialized
INFO - 2024-05-21 08:07:53 --> Output Class Initialized
INFO - 2024-05-21 08:07:53 --> Security Class Initialized
DEBUG - 2024-05-21 08:07:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-21 08:07:53 --> Input Class Initialized
INFO - 2024-05-21 08:07:53 --> Language Class Initialized
INFO - 2024-05-21 08:07:53 --> Loader Class Initialized
INFO - 2024-05-21 08:07:53 --> Helper loaded: url_helper
INFO - 2024-05-21 08:07:53 --> Helper loaded: file_helper
INFO - 2024-05-21 08:07:53 --> Helper loaded: html_helper
INFO - 2024-05-21 08:07:53 --> Helper loaded: text_helper
INFO - 2024-05-21 08:07:53 --> Helper loaded: form_helper
INFO - 2024-05-21 08:07:53 --> Helper loaded: lang_helper
INFO - 2024-05-21 08:07:53 --> Helper loaded: security_helper
INFO - 2024-05-21 08:07:53 --> Helper loaded: cookie_helper
INFO - 2024-05-21 08:07:53 --> Database Driver Class Initialized
INFO - 2024-05-21 08:07:53 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-21 08:07:53 --> Parser Class Initialized
INFO - 2024-05-21 08:07:53 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-05-21 08:07:53 --> Pagination Class Initialized
INFO - 2024-05-21 08:07:53 --> Form Validation Class Initialized
INFO - 2024-05-21 08:07:53 --> Controller Class Initialized
INFO - 2024-05-21 08:07:53 --> Model Class Initialized
DEBUG - 2024-05-21 08:07:53 --> Session class already loaded. Second attempt ignored.
INFO - 2024-05-21 08:07:53 --> File loaded: /home/u241458058/domains/technoprimex.com/public_html/maurnaturo/application/views/user/admin_login_form.php
DEBUG - 2024-05-21 08:07:53 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-05-21 08:07:53 --> File loaded: /home/u241458058/domains/technoprimex.com/public_html/maurnaturo/application/views/include/top_menu.php
INFO - 2024-05-21 08:07:53 --> File loaded: /home/u241458058/domains/technoprimex.com/public_html/maurnaturo/application/views/include/admin_loggedin_info.php
INFO - 2024-05-21 08:07:53 --> Model Class Initialized
INFO - 2024-05-21 08:07:53 --> File loaded: /home/u241458058/domains/technoprimex.com/public_html/maurnaturo/application/views/admin_html_template.php
INFO - 2024-05-21 08:07:53 --> Final output sent to browser
DEBUG - 2024-05-21 08:07:53 --> Total execution time: 0.0175
ERROR - 2024-05-21 08:17:43 --> $config['composer_autoload'] is set to TRUE but /home/u241458058/domains/technoprimex.com/public_html/maurnaturo/application/vendor/autoload.php was not found.
INFO - 2024-05-21 08:17:43 --> Config Class Initialized
INFO - 2024-05-21 08:17:43 --> Hooks Class Initialized
DEBUG - 2024-05-21 08:17:43 --> UTF-8 Support Enabled
INFO - 2024-05-21 08:17:43 --> Utf8 Class Initialized
INFO - 2024-05-21 08:17:43 --> URI Class Initialized
DEBUG - 2024-05-21 08:17:43 --> No URI present. Default controller set.
INFO - 2024-05-21 08:17:43 --> Router Class Initialized
INFO - 2024-05-21 08:17:43 --> Output Class Initialized
INFO - 2024-05-21 08:17:43 --> Security Class Initialized
DEBUG - 2024-05-21 08:17:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-21 08:17:43 --> Input Class Initialized
INFO - 2024-05-21 08:17:43 --> Language Class Initialized
INFO - 2024-05-21 08:17:43 --> Loader Class Initialized
INFO - 2024-05-21 08:17:43 --> Helper loaded: url_helper
INFO - 2024-05-21 08:17:43 --> Helper loaded: file_helper
INFO - 2024-05-21 08:17:43 --> Helper loaded: html_helper
INFO - 2024-05-21 08:17:43 --> Helper loaded: text_helper
INFO - 2024-05-21 08:17:43 --> Helper loaded: form_helper
INFO - 2024-05-21 08:17:43 --> Helper loaded: lang_helper
INFO - 2024-05-21 08:17:43 --> Helper loaded: security_helper
INFO - 2024-05-21 08:17:43 --> Helper loaded: cookie_helper
INFO - 2024-05-21 08:17:43 --> Database Driver Class Initialized
INFO - 2024-05-21 08:17:43 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-21 08:17:43 --> Parser Class Initialized
INFO - 2024-05-21 08:17:43 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-05-21 08:17:43 --> Pagination Class Initialized
INFO - 2024-05-21 08:17:43 --> Form Validation Class Initialized
INFO - 2024-05-21 08:17:43 --> Controller Class Initialized
INFO - 2024-05-21 08:17:43 --> Model Class Initialized
DEBUG - 2024-05-21 08:17:43 --> Session class already loaded. Second attempt ignored.
ERROR - 2024-05-21 08:34:07 --> $config['composer_autoload'] is set to TRUE but /home/u241458058/domains/technoprimex.com/public_html/maurnaturo/application/vendor/autoload.php was not found.
INFO - 2024-05-21 08:34:07 --> Config Class Initialized
INFO - 2024-05-21 08:34:07 --> Hooks Class Initialized
DEBUG - 2024-05-21 08:34:07 --> UTF-8 Support Enabled
INFO - 2024-05-21 08:34:07 --> Utf8 Class Initialized
INFO - 2024-05-21 08:34:07 --> URI Class Initialized
INFO - 2024-05-21 08:34:07 --> Router Class Initialized
INFO - 2024-05-21 08:34:07 --> Output Class Initialized
INFO - 2024-05-21 08:34:07 --> Security Class Initialized
DEBUG - 2024-05-21 08:34:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-21 08:34:07 --> Input Class Initialized
INFO - 2024-05-21 08:34:07 --> Language Class Initialized
INFO - 2024-05-21 08:34:07 --> Loader Class Initialized
INFO - 2024-05-21 08:34:07 --> Helper loaded: url_helper
INFO - 2024-05-21 08:34:07 --> Helper loaded: file_helper
INFO - 2024-05-21 08:34:07 --> Helper loaded: html_helper
INFO - 2024-05-21 08:34:07 --> Helper loaded: text_helper
INFO - 2024-05-21 08:34:07 --> Helper loaded: form_helper
INFO - 2024-05-21 08:34:07 --> Helper loaded: lang_helper
INFO - 2024-05-21 08:34:07 --> Helper loaded: security_helper
INFO - 2024-05-21 08:34:07 --> Helper loaded: cookie_helper
INFO - 2024-05-21 08:34:07 --> Database Driver Class Initialized
INFO - 2024-05-21 08:34:07 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-21 08:34:07 --> Parser Class Initialized
INFO - 2024-05-21 08:34:07 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-05-21 08:34:07 --> Pagination Class Initialized
INFO - 2024-05-21 08:34:07 --> Form Validation Class Initialized
INFO - 2024-05-21 08:34:07 --> Controller Class Initialized
DEBUG - 2024-05-21 08:34:07 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-05-21 08:34:07 --> Session class already loaded. Second attempt ignored.
INFO - 2024-05-21 08:34:07 --> Model Class Initialized
INFO - 2024-05-21 08:34:07 --> Model Class Initialized
DEBUG - 2024-05-21 08:34:07 --> Lmr class already loaded. Second attempt ignored.
INFO - 2024-05-21 08:34:07 --> Model Class Initialized
INFO - 2024-05-21 08:34:07 --> File loaded: /home/u241458058/domains/technoprimex.com/public_html/maurnaturo/application/views/mr/mr.php
DEBUG - 2024-05-21 08:34:07 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-05-21 08:34:07 --> File loaded: /home/u241458058/domains/technoprimex.com/public_html/maurnaturo/application/views/include/top_menu.php
INFO - 2024-05-21 08:34:07 --> File loaded: /home/u241458058/domains/technoprimex.com/public_html/maurnaturo/application/views/include/admin_loggedin_info.php
INFO - 2024-05-21 08:34:07 --> Model Class Initialized
INFO - 2024-05-21 08:34:07 --> Model Class Initialized
INFO - 2024-05-21 08:34:07 --> Model Class Initialized
INFO - 2024-05-21 08:34:07 --> File loaded: /home/u241458058/domains/technoprimex.com/public_html/maurnaturo/application/views/include/admin_header.php
INFO - 2024-05-21 08:34:07 --> File loaded: /home/u241458058/domains/technoprimex.com/public_html/maurnaturo/application/views/include/admin_footer.php
INFO - 2024-05-21 08:34:07 --> File loaded: /home/u241458058/domains/technoprimex.com/public_html/maurnaturo/application/views/admin_html_template.php
INFO - 2024-05-21 08:34:07 --> Final output sent to browser
DEBUG - 2024-05-21 08:34:07 --> Total execution time: 0.1816
ERROR - 2024-05-21 08:34:08 --> $config['composer_autoload'] is set to TRUE but /home/u241458058/domains/technoprimex.com/public_html/maurnaturo/application/vendor/autoload.php was not found.
INFO - 2024-05-21 08:34:08 --> Config Class Initialized
INFO - 2024-05-21 08:34:08 --> Hooks Class Initialized
DEBUG - 2024-05-21 08:34:08 --> UTF-8 Support Enabled
INFO - 2024-05-21 08:34:08 --> Utf8 Class Initialized
INFO - 2024-05-21 08:34:08 --> URI Class Initialized
INFO - 2024-05-21 08:34:08 --> Router Class Initialized
INFO - 2024-05-21 08:34:08 --> Output Class Initialized
INFO - 2024-05-21 08:34:08 --> Security Class Initialized
DEBUG - 2024-05-21 08:34:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-21 08:34:08 --> Input Class Initialized
INFO - 2024-05-21 08:34:08 --> Language Class Initialized
INFO - 2024-05-21 08:34:08 --> Loader Class Initialized
INFO - 2024-05-21 08:34:08 --> Helper loaded: url_helper
INFO - 2024-05-21 08:34:08 --> Helper loaded: file_helper
INFO - 2024-05-21 08:34:08 --> Helper loaded: html_helper
INFO - 2024-05-21 08:34:08 --> Helper loaded: text_helper
INFO - 2024-05-21 08:34:08 --> Helper loaded: form_helper
INFO - 2024-05-21 08:34:08 --> Helper loaded: lang_helper
INFO - 2024-05-21 08:34:08 --> Helper loaded: security_helper
INFO - 2024-05-21 08:34:08 --> Helper loaded: cookie_helper
INFO - 2024-05-21 08:34:08 --> Database Driver Class Initialized
INFO - 2024-05-21 08:34:08 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-21 08:34:08 --> Parser Class Initialized
INFO - 2024-05-21 08:34:08 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-05-21 08:34:08 --> Pagination Class Initialized
INFO - 2024-05-21 08:34:08 --> Form Validation Class Initialized
INFO - 2024-05-21 08:34:08 --> Controller Class Initialized
DEBUG - 2024-05-21 08:34:08 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-05-21 08:34:08 --> Session class already loaded. Second attempt ignored.
INFO - 2024-05-21 08:34:08 --> Model Class Initialized
INFO - 2024-05-21 08:34:08 --> Model Class Initialized
INFO - 2024-05-21 08:34:08 --> Final output sent to browser
DEBUG - 2024-05-21 08:34:08 --> Total execution time: 0.0118
ERROR - 2024-05-21 08:34:25 --> $config['composer_autoload'] is set to TRUE but /home/u241458058/domains/technoprimex.com/public_html/maurnaturo/application/vendor/autoload.php was not found.
INFO - 2024-05-21 08:34:25 --> Config Class Initialized
INFO - 2024-05-21 08:34:25 --> Hooks Class Initialized
DEBUG - 2024-05-21 08:34:25 --> UTF-8 Support Enabled
INFO - 2024-05-21 08:34:25 --> Utf8 Class Initialized
INFO - 2024-05-21 08:34:25 --> URI Class Initialized
INFO - 2024-05-21 08:34:25 --> Router Class Initialized
INFO - 2024-05-21 08:34:25 --> Output Class Initialized
INFO - 2024-05-21 08:34:25 --> Security Class Initialized
DEBUG - 2024-05-21 08:34:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-21 08:34:25 --> Input Class Initialized
INFO - 2024-05-21 08:34:25 --> Language Class Initialized
INFO - 2024-05-21 08:34:25 --> Loader Class Initialized
INFO - 2024-05-21 08:34:25 --> Helper loaded: url_helper
INFO - 2024-05-21 08:34:25 --> Helper loaded: file_helper
INFO - 2024-05-21 08:34:25 --> Helper loaded: html_helper
INFO - 2024-05-21 08:34:25 --> Helper loaded: text_helper
INFO - 2024-05-21 08:34:25 --> Helper loaded: form_helper
INFO - 2024-05-21 08:34:25 --> Helper loaded: lang_helper
INFO - 2024-05-21 08:34:25 --> Helper loaded: security_helper
INFO - 2024-05-21 08:34:25 --> Helper loaded: cookie_helper
INFO - 2024-05-21 08:34:25 --> Database Driver Class Initialized
INFO - 2024-05-21 08:34:25 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-21 08:34:25 --> Parser Class Initialized
INFO - 2024-05-21 08:34:25 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-05-21 08:34:25 --> Pagination Class Initialized
INFO - 2024-05-21 08:34:25 --> Form Validation Class Initialized
INFO - 2024-05-21 08:34:25 --> Controller Class Initialized
INFO - 2024-05-21 08:34:25 --> Model Class Initialized
INFO - 2024-05-21 08:34:25 --> Model Class Initialized
INFO - 2024-05-21 08:34:25 --> File loaded: /home/u241458058/domains/technoprimex.com/public_html/maurnaturo/application/views/report/out_of_date.php
DEBUG - 2024-05-21 08:34:25 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-05-21 08:34:25 --> File loaded: /home/u241458058/domains/technoprimex.com/public_html/maurnaturo/application/views/include/top_menu.php
INFO - 2024-05-21 08:34:25 --> File loaded: /home/u241458058/domains/technoprimex.com/public_html/maurnaturo/application/views/include/admin_loggedin_info.php
INFO - 2024-05-21 08:34:25 --> Model Class Initialized
INFO - 2024-05-21 08:34:25 --> Model Class Initialized
INFO - 2024-05-21 08:34:25 --> File loaded: /home/u241458058/domains/technoprimex.com/public_html/maurnaturo/application/views/include/admin_header.php
INFO - 2024-05-21 08:34:25 --> File loaded: /home/u241458058/domains/technoprimex.com/public_html/maurnaturo/application/views/include/admin_footer.php
INFO - 2024-05-21 08:34:25 --> File loaded: /home/u241458058/domains/technoprimex.com/public_html/maurnaturo/application/views/admin_html_template.php
INFO - 2024-05-21 08:34:25 --> Final output sent to browser
DEBUG - 2024-05-21 08:34:25 --> Total execution time: 0.1362
ERROR - 2024-05-21 08:34:26 --> $config['composer_autoload'] is set to TRUE but /home/u241458058/domains/technoprimex.com/public_html/maurnaturo/application/vendor/autoload.php was not found.
INFO - 2024-05-21 08:34:26 --> Config Class Initialized
INFO - 2024-05-21 08:34:26 --> Hooks Class Initialized
DEBUG - 2024-05-21 08:34:26 --> UTF-8 Support Enabled
INFO - 2024-05-21 08:34:26 --> Utf8 Class Initialized
INFO - 2024-05-21 08:34:26 --> URI Class Initialized
INFO - 2024-05-21 08:34:26 --> Router Class Initialized
INFO - 2024-05-21 08:34:26 --> Output Class Initialized
INFO - 2024-05-21 08:34:26 --> Security Class Initialized
DEBUG - 2024-05-21 08:34:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-21 08:34:26 --> Input Class Initialized
INFO - 2024-05-21 08:34:26 --> Language Class Initialized
INFO - 2024-05-21 08:34:26 --> Loader Class Initialized
INFO - 2024-05-21 08:34:26 --> Helper loaded: url_helper
INFO - 2024-05-21 08:34:26 --> Helper loaded: file_helper
INFO - 2024-05-21 08:34:26 --> Helper loaded: html_helper
INFO - 2024-05-21 08:34:26 --> Helper loaded: text_helper
INFO - 2024-05-21 08:34:26 --> Helper loaded: form_helper
INFO - 2024-05-21 08:34:26 --> Helper loaded: lang_helper
INFO - 2024-05-21 08:34:26 --> Helper loaded: security_helper
INFO - 2024-05-21 08:34:26 --> Helper loaded: cookie_helper
INFO - 2024-05-21 08:34:26 --> Database Driver Class Initialized
INFO - 2024-05-21 08:34:26 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-21 08:34:26 --> Parser Class Initialized
INFO - 2024-05-21 08:34:26 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-05-21 08:34:26 --> Pagination Class Initialized
INFO - 2024-05-21 08:34:26 --> Form Validation Class Initialized
INFO - 2024-05-21 08:34:26 --> Controller Class Initialized
INFO - 2024-05-21 08:34:26 --> Model Class Initialized
INFO - 2024-05-21 08:34:26 --> Model Class Initialized
INFO - 2024-05-21 08:34:26 --> Final output sent to browser
DEBUG - 2024-05-21 08:34:26 --> Total execution time: 0.0308
ERROR - 2024-05-21 08:34:31 --> $config['composer_autoload'] is set to TRUE but /home/u241458058/domains/technoprimex.com/public_html/maurnaturo/application/vendor/autoload.php was not found.
INFO - 2024-05-21 08:34:31 --> Config Class Initialized
INFO - 2024-05-21 08:34:31 --> Hooks Class Initialized
DEBUG - 2024-05-21 08:34:31 --> UTF-8 Support Enabled
INFO - 2024-05-21 08:34:31 --> Utf8 Class Initialized
INFO - 2024-05-21 08:34:31 --> URI Class Initialized
INFO - 2024-05-21 08:34:31 --> Router Class Initialized
INFO - 2024-05-21 08:34:31 --> Output Class Initialized
INFO - 2024-05-21 08:34:31 --> Security Class Initialized
DEBUG - 2024-05-21 08:34:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-21 08:34:31 --> Input Class Initialized
INFO - 2024-05-21 08:34:31 --> Language Class Initialized
INFO - 2024-05-21 08:34:31 --> Loader Class Initialized
INFO - 2024-05-21 08:34:31 --> Helper loaded: url_helper
INFO - 2024-05-21 08:34:31 --> Helper loaded: file_helper
INFO - 2024-05-21 08:34:31 --> Helper loaded: html_helper
INFO - 2024-05-21 08:34:31 --> Helper loaded: text_helper
INFO - 2024-05-21 08:34:31 --> Helper loaded: form_helper
INFO - 2024-05-21 08:34:31 --> Helper loaded: lang_helper
INFO - 2024-05-21 08:34:31 --> Helper loaded: security_helper
INFO - 2024-05-21 08:34:31 --> Helper loaded: cookie_helper
INFO - 2024-05-21 08:34:31 --> Database Driver Class Initialized
INFO - 2024-05-21 08:34:31 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-21 08:34:31 --> Parser Class Initialized
INFO - 2024-05-21 08:34:31 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-05-21 08:34:31 --> Pagination Class Initialized
INFO - 2024-05-21 08:34:31 --> Form Validation Class Initialized
INFO - 2024-05-21 08:34:31 --> Controller Class Initialized
INFO - 2024-05-21 08:34:31 --> Model Class Initialized
INFO - 2024-05-21 08:34:31 --> Model Class Initialized
INFO - 2024-05-21 08:34:31 --> File loaded: /home/u241458058/domains/technoprimex.com/public_html/maurnaturo/application/views/report/out_of_stock.php
DEBUG - 2024-05-21 08:34:31 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-05-21 08:34:31 --> File loaded: /home/u241458058/domains/technoprimex.com/public_html/maurnaturo/application/views/include/top_menu.php
INFO - 2024-05-21 08:34:31 --> File loaded: /home/u241458058/domains/technoprimex.com/public_html/maurnaturo/application/views/include/admin_loggedin_info.php
INFO - 2024-05-21 08:34:31 --> Model Class Initialized
INFO - 2024-05-21 08:34:31 --> Model Class Initialized
INFO - 2024-05-21 08:34:31 --> File loaded: /home/u241458058/domains/technoprimex.com/public_html/maurnaturo/application/views/include/admin_header.php
INFO - 2024-05-21 08:34:31 --> File loaded: /home/u241458058/domains/technoprimex.com/public_html/maurnaturo/application/views/include/admin_footer.php
INFO - 2024-05-21 08:34:31 --> File loaded: /home/u241458058/domains/technoprimex.com/public_html/maurnaturo/application/views/admin_html_template.php
INFO - 2024-05-21 08:34:31 --> Final output sent to browser
DEBUG - 2024-05-21 08:34:31 --> Total execution time: 0.1510
ERROR - 2024-05-21 08:34:31 --> $config['composer_autoload'] is set to TRUE but /home/u241458058/domains/technoprimex.com/public_html/maurnaturo/application/vendor/autoload.php was not found.
INFO - 2024-05-21 08:34:31 --> Config Class Initialized
INFO - 2024-05-21 08:34:31 --> Hooks Class Initialized
DEBUG - 2024-05-21 08:34:31 --> UTF-8 Support Enabled
INFO - 2024-05-21 08:34:31 --> Utf8 Class Initialized
INFO - 2024-05-21 08:34:31 --> URI Class Initialized
INFO - 2024-05-21 08:34:31 --> Router Class Initialized
INFO - 2024-05-21 08:34:31 --> Output Class Initialized
INFO - 2024-05-21 08:34:31 --> Security Class Initialized
DEBUG - 2024-05-21 08:34:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-21 08:34:31 --> Input Class Initialized
INFO - 2024-05-21 08:34:31 --> Language Class Initialized
INFO - 2024-05-21 08:34:31 --> Loader Class Initialized
INFO - 2024-05-21 08:34:31 --> Helper loaded: url_helper
INFO - 2024-05-21 08:34:31 --> Helper loaded: file_helper
INFO - 2024-05-21 08:34:31 --> Helper loaded: html_helper
INFO - 2024-05-21 08:34:31 --> Helper loaded: text_helper
INFO - 2024-05-21 08:34:31 --> Helper loaded: form_helper
INFO - 2024-05-21 08:34:31 --> Helper loaded: lang_helper
INFO - 2024-05-21 08:34:31 --> Helper loaded: security_helper
INFO - 2024-05-21 08:34:31 --> Helper loaded: cookie_helper
INFO - 2024-05-21 08:34:31 --> Database Driver Class Initialized
INFO - 2024-05-21 08:34:31 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-21 08:34:31 --> Parser Class Initialized
INFO - 2024-05-21 08:34:31 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-05-21 08:34:31 --> Pagination Class Initialized
INFO - 2024-05-21 08:34:31 --> Form Validation Class Initialized
INFO - 2024-05-21 08:34:31 --> Controller Class Initialized
INFO - 2024-05-21 08:34:31 --> Model Class Initialized
INFO - 2024-05-21 08:34:31 --> Model Class Initialized
INFO - 2024-05-21 08:34:31 --> Final output sent to browser
DEBUG - 2024-05-21 08:34:31 --> Total execution time: 0.0885
ERROR - 2024-05-21 09:31:10 --> $config['composer_autoload'] is set to TRUE but /home/u241458058/domains/technoprimex.com/public_html/maurnaturo/application/vendor/autoload.php was not found.
INFO - 2024-05-21 09:31:10 --> Config Class Initialized
INFO - 2024-05-21 09:31:10 --> Hooks Class Initialized
DEBUG - 2024-05-21 09:31:10 --> UTF-8 Support Enabled
INFO - 2024-05-21 09:31:10 --> Utf8 Class Initialized
INFO - 2024-05-21 09:31:10 --> URI Class Initialized
DEBUG - 2024-05-21 09:31:10 --> No URI present. Default controller set.
INFO - 2024-05-21 09:31:10 --> Router Class Initialized
INFO - 2024-05-21 09:31:10 --> Output Class Initialized
INFO - 2024-05-21 09:31:10 --> Security Class Initialized
DEBUG - 2024-05-21 09:31:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-21 09:31:10 --> Input Class Initialized
INFO - 2024-05-21 09:31:10 --> Language Class Initialized
INFO - 2024-05-21 09:31:10 --> Loader Class Initialized
INFO - 2024-05-21 09:31:10 --> Helper loaded: url_helper
INFO - 2024-05-21 09:31:10 --> Helper loaded: file_helper
INFO - 2024-05-21 09:31:10 --> Helper loaded: html_helper
INFO - 2024-05-21 09:31:10 --> Helper loaded: text_helper
INFO - 2024-05-21 09:31:10 --> Helper loaded: form_helper
INFO - 2024-05-21 09:31:10 --> Helper loaded: lang_helper
INFO - 2024-05-21 09:31:10 --> Helper loaded: security_helper
INFO - 2024-05-21 09:31:10 --> Helper loaded: cookie_helper
INFO - 2024-05-21 09:31:10 --> Database Driver Class Initialized
INFO - 2024-05-21 09:31:10 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-21 09:31:10 --> Parser Class Initialized
INFO - 2024-05-21 09:31:10 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-05-21 09:31:10 --> Pagination Class Initialized
INFO - 2024-05-21 09:31:10 --> Form Validation Class Initialized
INFO - 2024-05-21 09:31:10 --> Controller Class Initialized
INFO - 2024-05-21 09:31:10 --> Model Class Initialized
DEBUG - 2024-05-21 09:31:10 --> Session class already loaded. Second attempt ignored.
ERROR - 2024-05-21 11:12:49 --> $config['composer_autoload'] is set to TRUE but /home/u241458058/domains/technoprimex.com/public_html/maurnaturo/application/vendor/autoload.php was not found.
INFO - 2024-05-21 11:12:49 --> Config Class Initialized
INFO - 2024-05-21 11:12:49 --> Hooks Class Initialized
DEBUG - 2024-05-21 11:12:49 --> UTF-8 Support Enabled
INFO - 2024-05-21 11:12:49 --> Utf8 Class Initialized
INFO - 2024-05-21 11:12:49 --> URI Class Initialized
DEBUG - 2024-05-21 11:12:49 --> No URI present. Default controller set.
INFO - 2024-05-21 11:12:49 --> Router Class Initialized
INFO - 2024-05-21 11:12:49 --> Output Class Initialized
INFO - 2024-05-21 11:12:49 --> Security Class Initialized
DEBUG - 2024-05-21 11:12:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-21 11:12:49 --> Input Class Initialized
INFO - 2024-05-21 11:12:49 --> Language Class Initialized
INFO - 2024-05-21 11:12:49 --> Loader Class Initialized
INFO - 2024-05-21 11:12:49 --> Helper loaded: url_helper
INFO - 2024-05-21 11:12:49 --> Helper loaded: file_helper
INFO - 2024-05-21 11:12:49 --> Helper loaded: html_helper
INFO - 2024-05-21 11:12:49 --> Helper loaded: text_helper
INFO - 2024-05-21 11:12:49 --> Helper loaded: form_helper
INFO - 2024-05-21 11:12:49 --> Helper loaded: lang_helper
INFO - 2024-05-21 11:12:49 --> Helper loaded: security_helper
INFO - 2024-05-21 11:12:49 --> Helper loaded: cookie_helper
INFO - 2024-05-21 11:12:49 --> Database Driver Class Initialized
INFO - 2024-05-21 11:12:49 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-21 11:12:49 --> Parser Class Initialized
INFO - 2024-05-21 11:12:49 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-05-21 11:12:49 --> Pagination Class Initialized
INFO - 2024-05-21 11:12:49 --> Form Validation Class Initialized
INFO - 2024-05-21 11:12:49 --> Controller Class Initialized
INFO - 2024-05-21 11:12:49 --> Model Class Initialized
DEBUG - 2024-05-21 11:12:49 --> Session class already loaded. Second attempt ignored.
ERROR - 2024-05-21 13:19:42 --> $config['composer_autoload'] is set to TRUE but /home/u241458058/domains/technoprimex.com/public_html/maurnaturo/application/vendor/autoload.php was not found.
INFO - 2024-05-21 13:19:42 --> Config Class Initialized
INFO - 2024-05-21 13:19:42 --> Hooks Class Initialized
DEBUG - 2024-05-21 13:19:42 --> UTF-8 Support Enabled
INFO - 2024-05-21 13:19:42 --> Utf8 Class Initialized
INFO - 2024-05-21 13:19:42 --> URI Class Initialized
DEBUG - 2024-05-21 13:19:42 --> No URI present. Default controller set.
INFO - 2024-05-21 13:19:42 --> Router Class Initialized
INFO - 2024-05-21 13:19:42 --> Output Class Initialized
INFO - 2024-05-21 13:19:42 --> Security Class Initialized
DEBUG - 2024-05-21 13:19:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-21 13:19:42 --> Input Class Initialized
INFO - 2024-05-21 13:19:42 --> Language Class Initialized
INFO - 2024-05-21 13:19:42 --> Loader Class Initialized
INFO - 2024-05-21 13:19:42 --> Helper loaded: url_helper
INFO - 2024-05-21 13:19:42 --> Helper loaded: file_helper
INFO - 2024-05-21 13:19:42 --> Helper loaded: html_helper
INFO - 2024-05-21 13:19:42 --> Helper loaded: text_helper
INFO - 2024-05-21 13:19:42 --> Helper loaded: form_helper
INFO - 2024-05-21 13:19:42 --> Helper loaded: lang_helper
INFO - 2024-05-21 13:19:42 --> Helper loaded: security_helper
INFO - 2024-05-21 13:19:42 --> Helper loaded: cookie_helper
INFO - 2024-05-21 13:19:42 --> Database Driver Class Initialized
INFO - 2024-05-21 13:19:42 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-21 13:19:42 --> Parser Class Initialized
INFO - 2024-05-21 13:19:42 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-05-21 13:19:42 --> Pagination Class Initialized
INFO - 2024-05-21 13:19:42 --> Form Validation Class Initialized
INFO - 2024-05-21 13:19:42 --> Controller Class Initialized
INFO - 2024-05-21 13:19:42 --> Model Class Initialized
DEBUG - 2024-05-21 13:19:42 --> Session class already loaded. Second attempt ignored.
ERROR - 2024-05-21 15:48:58 --> $config['composer_autoload'] is set to TRUE but /home/u241458058/domains/technoprimex.com/public_html/maurnaturo/application/vendor/autoload.php was not found.
INFO - 2024-05-21 15:48:58 --> Config Class Initialized
INFO - 2024-05-21 15:48:58 --> Hooks Class Initialized
DEBUG - 2024-05-21 15:48:58 --> UTF-8 Support Enabled
INFO - 2024-05-21 15:48:58 --> Utf8 Class Initialized
INFO - 2024-05-21 15:48:58 --> URI Class Initialized
DEBUG - 2024-05-21 15:48:58 --> No URI present. Default controller set.
INFO - 2024-05-21 15:48:58 --> Router Class Initialized
INFO - 2024-05-21 15:48:58 --> Output Class Initialized
INFO - 2024-05-21 15:48:58 --> Security Class Initialized
DEBUG - 2024-05-21 15:48:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-21 15:48:58 --> Input Class Initialized
INFO - 2024-05-21 15:48:58 --> Language Class Initialized
INFO - 2024-05-21 15:48:58 --> Loader Class Initialized
INFO - 2024-05-21 15:48:58 --> Helper loaded: url_helper
INFO - 2024-05-21 15:48:58 --> Helper loaded: file_helper
INFO - 2024-05-21 15:48:58 --> Helper loaded: html_helper
INFO - 2024-05-21 15:48:58 --> Helper loaded: text_helper
INFO - 2024-05-21 15:48:58 --> Helper loaded: form_helper
INFO - 2024-05-21 15:48:58 --> Helper loaded: lang_helper
INFO - 2024-05-21 15:48:58 --> Helper loaded: security_helper
INFO - 2024-05-21 15:48:58 --> Helper loaded: cookie_helper
INFO - 2024-05-21 15:48:58 --> Database Driver Class Initialized
INFO - 2024-05-21 15:48:58 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-21 15:48:58 --> Parser Class Initialized
INFO - 2024-05-21 15:48:58 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-05-21 15:48:58 --> Pagination Class Initialized
INFO - 2024-05-21 15:48:58 --> Form Validation Class Initialized
INFO - 2024-05-21 15:48:58 --> Controller Class Initialized
INFO - 2024-05-21 15:48:58 --> Model Class Initialized
DEBUG - 2024-05-21 15:48:58 --> Session class already loaded. Second attempt ignored.
ERROR - 2024-05-21 18:05:39 --> $config['composer_autoload'] is set to TRUE but /home/u241458058/domains/technoprimex.com/public_html/maurnaturo/application/vendor/autoload.php was not found.
INFO - 2024-05-21 18:05:39 --> Config Class Initialized
INFO - 2024-05-21 18:05:39 --> Hooks Class Initialized
DEBUG - 2024-05-21 18:05:39 --> UTF-8 Support Enabled
INFO - 2024-05-21 18:05:39 --> Utf8 Class Initialized
INFO - 2024-05-21 18:05:39 --> URI Class Initialized
DEBUG - 2024-05-21 18:05:39 --> No URI present. Default controller set.
INFO - 2024-05-21 18:05:39 --> Router Class Initialized
INFO - 2024-05-21 18:05:39 --> Output Class Initialized
INFO - 2024-05-21 18:05:39 --> Security Class Initialized
DEBUG - 2024-05-21 18:05:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-21 18:05:39 --> Input Class Initialized
INFO - 2024-05-21 18:05:39 --> Language Class Initialized
INFO - 2024-05-21 18:05:39 --> Loader Class Initialized
INFO - 2024-05-21 18:05:39 --> Helper loaded: url_helper
INFO - 2024-05-21 18:05:39 --> Helper loaded: file_helper
INFO - 2024-05-21 18:05:39 --> Helper loaded: html_helper
INFO - 2024-05-21 18:05:39 --> Helper loaded: text_helper
INFO - 2024-05-21 18:05:39 --> Helper loaded: form_helper
INFO - 2024-05-21 18:05:39 --> Helper loaded: lang_helper
INFO - 2024-05-21 18:05:39 --> Helper loaded: security_helper
INFO - 2024-05-21 18:05:39 --> Helper loaded: cookie_helper
INFO - 2024-05-21 18:05:39 --> Database Driver Class Initialized
INFO - 2024-05-21 18:05:39 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-21 18:05:39 --> Parser Class Initialized
INFO - 2024-05-21 18:05:39 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-05-21 18:05:39 --> Pagination Class Initialized
INFO - 2024-05-21 18:05:39 --> Form Validation Class Initialized
INFO - 2024-05-21 18:05:39 --> Controller Class Initialized
INFO - 2024-05-21 18:05:39 --> Model Class Initialized
DEBUG - 2024-05-21 18:05:39 --> Session class already loaded. Second attempt ignored.
ERROR - 2024-05-21 18:10:41 --> $config['composer_autoload'] is set to TRUE but /home/u241458058/domains/technoprimex.com/public_html/maurnaturo/application/vendor/autoload.php was not found.
INFO - 2024-05-21 18:10:41 --> Config Class Initialized
INFO - 2024-05-21 18:10:41 --> Hooks Class Initialized
DEBUG - 2024-05-21 18:10:41 --> UTF-8 Support Enabled
INFO - 2024-05-21 18:10:41 --> Utf8 Class Initialized
INFO - 2024-05-21 18:10:41 --> URI Class Initialized
DEBUG - 2024-05-21 18:10:41 --> No URI present. Default controller set.
INFO - 2024-05-21 18:10:41 --> Router Class Initialized
INFO - 2024-05-21 18:10:41 --> Output Class Initialized
INFO - 2024-05-21 18:10:41 --> Security Class Initialized
DEBUG - 2024-05-21 18:10:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-21 18:10:41 --> Input Class Initialized
INFO - 2024-05-21 18:10:41 --> Language Class Initialized
INFO - 2024-05-21 18:10:41 --> Loader Class Initialized
INFO - 2024-05-21 18:10:41 --> Helper loaded: url_helper
INFO - 2024-05-21 18:10:41 --> Helper loaded: file_helper
INFO - 2024-05-21 18:10:41 --> Helper loaded: html_helper
INFO - 2024-05-21 18:10:41 --> Helper loaded: text_helper
INFO - 2024-05-21 18:10:41 --> Helper loaded: form_helper
INFO - 2024-05-21 18:10:41 --> Helper loaded: lang_helper
INFO - 2024-05-21 18:10:41 --> Helper loaded: security_helper
INFO - 2024-05-21 18:10:41 --> Helper loaded: cookie_helper
INFO - 2024-05-21 18:10:41 --> Database Driver Class Initialized
INFO - 2024-05-21 18:10:41 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-21 18:10:41 --> Parser Class Initialized
INFO - 2024-05-21 18:10:41 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-05-21 18:10:41 --> Pagination Class Initialized
INFO - 2024-05-21 18:10:41 --> Form Validation Class Initialized
INFO - 2024-05-21 18:10:41 --> Controller Class Initialized
INFO - 2024-05-21 18:10:41 --> Model Class Initialized
DEBUG - 2024-05-21 18:10:41 --> Session class already loaded. Second attempt ignored.
ERROR - 2024-05-21 18:10:41 --> $config['composer_autoload'] is set to TRUE but /home/u241458058/domains/technoprimex.com/public_html/maurnaturo/application/vendor/autoload.php was not found.
INFO - 2024-05-21 18:10:41 --> Config Class Initialized
INFO - 2024-05-21 18:10:41 --> Hooks Class Initialized
DEBUG - 2024-05-21 18:10:41 --> UTF-8 Support Enabled
INFO - 2024-05-21 18:10:41 --> Utf8 Class Initialized
INFO - 2024-05-21 18:10:41 --> URI Class Initialized
DEBUG - 2024-05-21 18:10:41 --> No URI present. Default controller set.
INFO - 2024-05-21 18:10:41 --> Router Class Initialized
INFO - 2024-05-21 18:10:41 --> Output Class Initialized
INFO - 2024-05-21 18:10:41 --> Security Class Initialized
DEBUG - 2024-05-21 18:10:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-21 18:10:41 --> Input Class Initialized
INFO - 2024-05-21 18:10:41 --> Language Class Initialized
INFO - 2024-05-21 18:10:41 --> Loader Class Initialized
INFO - 2024-05-21 18:10:41 --> Helper loaded: url_helper
INFO - 2024-05-21 18:10:41 --> Helper loaded: file_helper
INFO - 2024-05-21 18:10:41 --> Helper loaded: html_helper
INFO - 2024-05-21 18:10:41 --> Helper loaded: text_helper
INFO - 2024-05-21 18:10:41 --> Helper loaded: form_helper
INFO - 2024-05-21 18:10:41 --> Helper loaded: lang_helper
INFO - 2024-05-21 18:10:41 --> Helper loaded: security_helper
INFO - 2024-05-21 18:10:41 --> Helper loaded: cookie_helper
INFO - 2024-05-21 18:10:41 --> Database Driver Class Initialized
INFO - 2024-05-21 18:10:41 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-21 18:10:41 --> Parser Class Initialized
INFO - 2024-05-21 18:10:41 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-05-21 18:10:41 --> Pagination Class Initialized
INFO - 2024-05-21 18:10:41 --> Form Validation Class Initialized
INFO - 2024-05-21 18:10:41 --> Controller Class Initialized
INFO - 2024-05-21 18:10:41 --> Model Class Initialized
DEBUG - 2024-05-21 18:10:41 --> Session class already loaded. Second attempt ignored.
ERROR - 2024-05-21 18:10:41 --> $config['composer_autoload'] is set to TRUE but /home/u241458058/domains/technoprimex.com/public_html/maurnaturo/application/vendor/autoload.php was not found.
INFO - 2024-05-21 18:10:41 --> Config Class Initialized
INFO - 2024-05-21 18:10:41 --> Hooks Class Initialized
DEBUG - 2024-05-21 18:10:41 --> UTF-8 Support Enabled
INFO - 2024-05-21 18:10:41 --> Utf8 Class Initialized
INFO - 2024-05-21 18:10:41 --> URI Class Initialized
DEBUG - 2024-05-21 18:10:41 --> No URI present. Default controller set.
INFO - 2024-05-21 18:10:41 --> Router Class Initialized
INFO - 2024-05-21 18:10:41 --> Output Class Initialized
INFO - 2024-05-21 18:10:41 --> Security Class Initialized
DEBUG - 2024-05-21 18:10:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-21 18:10:41 --> Input Class Initialized
INFO - 2024-05-21 18:10:41 --> Language Class Initialized
INFO - 2024-05-21 18:10:41 --> Loader Class Initialized
INFO - 2024-05-21 18:10:41 --> Helper loaded: url_helper
INFO - 2024-05-21 18:10:41 --> Helper loaded: file_helper
INFO - 2024-05-21 18:10:41 --> Helper loaded: html_helper
INFO - 2024-05-21 18:10:41 --> Helper loaded: text_helper
INFO - 2024-05-21 18:10:41 --> Helper loaded: form_helper
INFO - 2024-05-21 18:10:41 --> Helper loaded: lang_helper
INFO - 2024-05-21 18:10:41 --> Helper loaded: security_helper
INFO - 2024-05-21 18:10:41 --> Helper loaded: cookie_helper
INFO - 2024-05-21 18:10:41 --> Database Driver Class Initialized
INFO - 2024-05-21 18:10:41 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-21 18:10:41 --> Parser Class Initialized
INFO - 2024-05-21 18:10:41 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-05-21 18:10:41 --> Pagination Class Initialized
INFO - 2024-05-21 18:10:41 --> Form Validation Class Initialized
INFO - 2024-05-21 18:10:41 --> Controller Class Initialized
INFO - 2024-05-21 18:10:41 --> Model Class Initialized
DEBUG - 2024-05-21 18:10:41 --> Session class already loaded. Second attempt ignored.
ERROR - 2024-05-21 18:10:42 --> $config['composer_autoload'] is set to TRUE but /home/u241458058/domains/technoprimex.com/public_html/maurnaturo/application/vendor/autoload.php was not found.
INFO - 2024-05-21 18:10:42 --> Config Class Initialized
INFO - 2024-05-21 18:10:42 --> Hooks Class Initialized
DEBUG - 2024-05-21 18:10:42 --> UTF-8 Support Enabled
INFO - 2024-05-21 18:10:42 --> Utf8 Class Initialized
INFO - 2024-05-21 18:10:42 --> URI Class Initialized
DEBUG - 2024-05-21 18:10:42 --> No URI present. Default controller set.
INFO - 2024-05-21 18:10:42 --> Router Class Initialized
INFO - 2024-05-21 18:10:42 --> Output Class Initialized
INFO - 2024-05-21 18:10:42 --> Security Class Initialized
DEBUG - 2024-05-21 18:10:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-21 18:10:42 --> Input Class Initialized
INFO - 2024-05-21 18:10:42 --> Language Class Initialized
INFO - 2024-05-21 18:10:42 --> Loader Class Initialized
INFO - 2024-05-21 18:10:42 --> Helper loaded: url_helper
INFO - 2024-05-21 18:10:42 --> Helper loaded: file_helper
INFO - 2024-05-21 18:10:42 --> Helper loaded: html_helper
INFO - 2024-05-21 18:10:42 --> Helper loaded: text_helper
INFO - 2024-05-21 18:10:42 --> Helper loaded: form_helper
INFO - 2024-05-21 18:10:42 --> Helper loaded: lang_helper
INFO - 2024-05-21 18:10:42 --> Helper loaded: security_helper
INFO - 2024-05-21 18:10:42 --> Helper loaded: cookie_helper
INFO - 2024-05-21 18:10:42 --> Database Driver Class Initialized
INFO - 2024-05-21 18:10:42 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-21 18:10:42 --> Parser Class Initialized
INFO - 2024-05-21 18:10:42 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-05-21 18:10:42 --> Pagination Class Initialized
INFO - 2024-05-21 18:10:42 --> Form Validation Class Initialized
INFO - 2024-05-21 18:10:42 --> Controller Class Initialized
INFO - 2024-05-21 18:10:42 --> Model Class Initialized
DEBUG - 2024-05-21 18:10:42 --> Session class already loaded. Second attempt ignored.
ERROR - 2024-05-21 18:10:48 --> $config['composer_autoload'] is set to TRUE but /home/u241458058/domains/technoprimex.com/public_html/maurnaturo/application/vendor/autoload.php was not found.
INFO - 2024-05-21 18:10:48 --> Config Class Initialized
INFO - 2024-05-21 18:10:48 --> Hooks Class Initialized
DEBUG - 2024-05-21 18:10:48 --> UTF-8 Support Enabled
INFO - 2024-05-21 18:10:48 --> Utf8 Class Initialized
INFO - 2024-05-21 18:10:48 --> URI Class Initialized
DEBUG - 2024-05-21 18:10:48 --> No URI present. Default controller set.
INFO - 2024-05-21 18:10:48 --> Router Class Initialized
INFO - 2024-05-21 18:10:48 --> Output Class Initialized
INFO - 2024-05-21 18:10:48 --> Security Class Initialized
DEBUG - 2024-05-21 18:10:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-21 18:10:48 --> Input Class Initialized
INFO - 2024-05-21 18:10:48 --> Language Class Initialized
INFO - 2024-05-21 18:10:48 --> Loader Class Initialized
INFO - 2024-05-21 18:10:48 --> Helper loaded: url_helper
INFO - 2024-05-21 18:10:48 --> Helper loaded: file_helper
INFO - 2024-05-21 18:10:48 --> Helper loaded: html_helper
INFO - 2024-05-21 18:10:48 --> Helper loaded: text_helper
INFO - 2024-05-21 18:10:48 --> Helper loaded: form_helper
INFO - 2024-05-21 18:10:48 --> Helper loaded: lang_helper
INFO - 2024-05-21 18:10:48 --> Helper loaded: security_helper
INFO - 2024-05-21 18:10:48 --> Helper loaded: cookie_helper
INFO - 2024-05-21 18:10:48 --> Database Driver Class Initialized
INFO - 2024-05-21 18:10:48 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-21 18:10:48 --> Parser Class Initialized
INFO - 2024-05-21 18:10:48 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-05-21 18:10:48 --> Pagination Class Initialized
INFO - 2024-05-21 18:10:48 --> Form Validation Class Initialized
INFO - 2024-05-21 18:10:48 --> Controller Class Initialized
INFO - 2024-05-21 18:10:48 --> Model Class Initialized
DEBUG - 2024-05-21 18:10:48 --> Session class already loaded. Second attempt ignored.
ERROR - 2024-05-21 20:36:36 --> $config['composer_autoload'] is set to TRUE but /home/u241458058/domains/technoprimex.com/public_html/maurnaturo/application/vendor/autoload.php was not found.
INFO - 2024-05-21 20:36:36 --> Config Class Initialized
INFO - 2024-05-21 20:36:36 --> Hooks Class Initialized
DEBUG - 2024-05-21 20:36:36 --> UTF-8 Support Enabled
INFO - 2024-05-21 20:36:36 --> Utf8 Class Initialized
INFO - 2024-05-21 20:36:36 --> URI Class Initialized
DEBUG - 2024-05-21 20:36:36 --> No URI present. Default controller set.
INFO - 2024-05-21 20:36:36 --> Router Class Initialized
INFO - 2024-05-21 20:36:36 --> Output Class Initialized
INFO - 2024-05-21 20:36:36 --> Security Class Initialized
DEBUG - 2024-05-21 20:36:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-21 20:36:36 --> Input Class Initialized
INFO - 2024-05-21 20:36:36 --> Language Class Initialized
INFO - 2024-05-21 20:36:36 --> Loader Class Initialized
INFO - 2024-05-21 20:36:36 --> Helper loaded: url_helper
INFO - 2024-05-21 20:36:36 --> Helper loaded: file_helper
INFO - 2024-05-21 20:36:36 --> Helper loaded: html_helper
INFO - 2024-05-21 20:36:36 --> Helper loaded: text_helper
INFO - 2024-05-21 20:36:36 --> Helper loaded: form_helper
INFO - 2024-05-21 20:36:36 --> Helper loaded: lang_helper
INFO - 2024-05-21 20:36:36 --> Helper loaded: security_helper
INFO - 2024-05-21 20:36:36 --> Helper loaded: cookie_helper
INFO - 2024-05-21 20:36:36 --> Database Driver Class Initialized
INFO - 2024-05-21 20:36:36 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-21 20:36:36 --> Parser Class Initialized
INFO - 2024-05-21 20:36:36 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-05-21 20:36:36 --> Pagination Class Initialized
INFO - 2024-05-21 20:36:36 --> Form Validation Class Initialized
INFO - 2024-05-21 20:36:36 --> Controller Class Initialized
INFO - 2024-05-21 20:36:36 --> Model Class Initialized
DEBUG - 2024-05-21 20:36:36 --> Session class already loaded. Second attempt ignored.
