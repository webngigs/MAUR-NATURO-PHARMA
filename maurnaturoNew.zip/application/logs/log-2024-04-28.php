ERROR - 2024-04-28 18:22:05 --> $config['composer_autoload'] is set to TRUE but E:\xampp\htdocs\maurnaturo\application\vendor/autoload.php was not found.
INFO - 2024-04-28 18:22:05 --> Config Class Initialized
INFO - 2024-04-28 18:22:05 --> Hooks Class Initialized
DEBUG - 2024-04-28 18:22:05 --> UTF-8 Support Enabled
INFO - 2024-04-28 18:22:05 --> Utf8 Class Initialized
INFO - 2024-04-28 18:22:05 --> URI Class Initialized
INFO - 2024-04-28 18:22:05 --> Router Class Initialized
INFO - 2024-04-28 18:22:05 --> Output Class Initialized
INFO - 2024-04-28 18:22:05 --> Security Class Initialized
DEBUG - 2024-04-28 18:22:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-04-28 18:22:05 --> Input Class Initialized
INFO - 2024-04-28 18:22:05 --> Language Class Initialized
INFO - 2024-04-28 18:22:05 --> Loader Class Initialized
INFO - 2024-04-28 18:22:05 --> Helper loaded: url_helper
INFO - 2024-04-28 18:22:05 --> Helper loaded: file_helper
INFO - 2024-04-28 18:22:05 --> Helper loaded: html_helper
INFO - 2024-04-28 18:22:05 --> Helper loaded: text_helper
INFO - 2024-04-28 18:22:05 --> Helper loaded: form_helper
INFO - 2024-04-28 18:22:05 --> Helper loaded: lang_helper
INFO - 2024-04-28 18:22:05 --> Helper loaded: security_helper
INFO - 2024-04-28 18:22:05 --> Helper loaded: cookie_helper
INFO - 2024-04-28 18:22:05 --> Database Driver Class Initialized
INFO - 2024-04-28 18:22:05 --> Session: Class initialized using 'files' driver.
INFO - 2024-04-28 18:22:05 --> Parser Class Initialized
INFO - 2024-04-28 18:22:05 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-04-28 18:22:05 --> Pagination Class Initialized
INFO - 2024-04-28 18:22:05 --> Form Validation Class Initialized
INFO - 2024-04-28 18:22:05 --> Controller Class Initialized
DEBUG - 2024-04-28 18:22:05 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-04-28 18:22:05 --> Session class already loaded. Second attempt ignored.
INFO - 2024-04-28 18:22:05 --> Model Class Initialized
DEBUG - 2024-04-28 18:22:05 --> Lpayments class already loaded. Second attempt ignored.
INFO - 2024-04-28 18:22:05 --> Model Class Initialized
INFO - 2024-04-28 18:22:05 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\payments/payment.php
DEBUG - 2024-04-28 18:22:05 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-04-28 18:22:05 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\include/top_menu.php
INFO - 2024-04-28 18:22:05 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\include/admin_loggedin_info.php
INFO - 2024-04-28 18:22:05 --> Model Class Initialized
INFO - 2024-04-28 18:22:05 --> Model Class Initialized
INFO - 2024-04-28 18:22:05 --> Model Class Initialized
INFO - 2024-04-28 18:22:06 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\include/admin_header.php
INFO - 2024-04-28 18:22:06 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\include/admin_footer.php
INFO - 2024-04-28 18:22:06 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\admin_html_template.php
INFO - 2024-04-28 18:22:06 --> Final output sent to browser
DEBUG - 2024-04-28 18:22:06 --> Total execution time: 1.5177
ERROR - 2024-04-28 18:22:07 --> $config['composer_autoload'] is set to TRUE but E:\xampp\htdocs\maurnaturo\application\vendor/autoload.php was not found.
INFO - 2024-04-28 18:22:07 --> Config Class Initialized
INFO - 2024-04-28 18:22:07 --> Hooks Class Initialized
DEBUG - 2024-04-28 18:22:07 --> UTF-8 Support Enabled
INFO - 2024-04-28 18:22:07 --> Utf8 Class Initialized
INFO - 2024-04-28 18:22:07 --> URI Class Initialized
INFO - 2024-04-28 18:22:07 --> Router Class Initialized
INFO - 2024-04-28 18:22:07 --> Output Class Initialized
INFO - 2024-04-28 18:22:07 --> Security Class Initialized
DEBUG - 2024-04-28 18:22:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-04-28 18:22:07 --> Input Class Initialized
INFO - 2024-04-28 18:22:07 --> Language Class Initialized
ERROR - 2024-04-28 18:22:07 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2024-04-28 18:22:07 --> $config['composer_autoload'] is set to TRUE but E:\xampp\htdocs\maurnaturo\application\vendor/autoload.php was not found.
INFO - 2024-04-28 18:22:07 --> Config Class Initialized
INFO - 2024-04-28 18:22:07 --> Hooks Class Initialized
DEBUG - 2024-04-28 18:22:07 --> UTF-8 Support Enabled
INFO - 2024-04-28 18:22:07 --> Utf8 Class Initialized
INFO - 2024-04-28 18:22:07 --> URI Class Initialized
INFO - 2024-04-28 18:22:07 --> Router Class Initialized
INFO - 2024-04-28 18:22:07 --> Output Class Initialized
INFO - 2024-04-28 18:22:07 --> Security Class Initialized
DEBUG - 2024-04-28 18:22:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-04-28 18:22:07 --> Input Class Initialized
INFO - 2024-04-28 18:22:07 --> Language Class Initialized
ERROR - 2024-04-28 18:22:07 --> 404 Page Not Found: Assets/plugins
ERROR - 2024-04-28 18:26:50 --> $config['composer_autoload'] is set to TRUE but E:\xampp\htdocs\maurnaturo\application\vendor/autoload.php was not found.
INFO - 2024-04-28 18:26:50 --> Config Class Initialized
INFO - 2024-04-28 18:26:50 --> Hooks Class Initialized
DEBUG - 2024-04-28 18:26:50 --> UTF-8 Support Enabled
INFO - 2024-04-28 18:26:50 --> Utf8 Class Initialized
INFO - 2024-04-28 18:26:50 --> URI Class Initialized
INFO - 2024-04-28 18:26:50 --> Router Class Initialized
INFO - 2024-04-28 18:26:50 --> Output Class Initialized
INFO - 2024-04-28 18:26:50 --> Security Class Initialized
DEBUG - 2024-04-28 18:26:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-04-28 18:26:50 --> Input Class Initialized
INFO - 2024-04-28 18:26:50 --> Language Class Initialized
INFO - 2024-04-28 18:26:50 --> Loader Class Initialized
INFO - 2024-04-28 18:26:50 --> Helper loaded: url_helper
INFO - 2024-04-28 18:26:50 --> Helper loaded: file_helper
INFO - 2024-04-28 18:26:50 --> Helper loaded: html_helper
INFO - 2024-04-28 18:26:50 --> Helper loaded: text_helper
INFO - 2024-04-28 18:26:50 --> Helper loaded: form_helper
INFO - 2024-04-28 18:26:50 --> Helper loaded: lang_helper
INFO - 2024-04-28 18:26:50 --> Helper loaded: security_helper
INFO - 2024-04-28 18:26:50 --> Helper loaded: cookie_helper
INFO - 2024-04-28 18:26:50 --> Database Driver Class Initialized
INFO - 2024-04-28 18:26:50 --> Session: Class initialized using 'files' driver.
INFO - 2024-04-28 18:26:50 --> Parser Class Initialized
INFO - 2024-04-28 18:26:50 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-04-28 18:26:50 --> Pagination Class Initialized
INFO - 2024-04-28 18:26:50 --> Form Validation Class Initialized
INFO - 2024-04-28 18:26:50 --> Controller Class Initialized
DEBUG - 2024-04-28 18:26:50 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-04-28 18:26:50 --> Session class already loaded. Second attempt ignored.
INFO - 2024-04-28 18:26:50 --> Model Class Initialized
DEBUG - 2024-04-28 18:26:50 --> Lpayments class already loaded. Second attempt ignored.
INFO - 2024-04-28 18:26:50 --> Model Class Initialized
INFO - 2024-04-28 18:26:50 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\payments/payment.php
DEBUG - 2024-04-28 18:26:50 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-04-28 18:26:50 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\include/top_menu.php
INFO - 2024-04-28 18:26:50 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\include/admin_loggedin_info.php
INFO - 2024-04-28 18:26:50 --> Model Class Initialized
INFO - 2024-04-28 18:26:50 --> Model Class Initialized
INFO - 2024-04-28 18:26:50 --> Model Class Initialized
INFO - 2024-04-28 18:26:52 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\include/admin_header.php
INFO - 2024-04-28 18:26:52 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\include/admin_footer.php
INFO - 2024-04-28 18:26:52 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\admin_html_template.php
INFO - 2024-04-28 18:26:52 --> Final output sent to browser
DEBUG - 2024-04-28 18:26:52 --> Total execution time: 1.4565
ERROR - 2024-04-28 18:26:52 --> $config['composer_autoload'] is set to TRUE but E:\xampp\htdocs\maurnaturo\application\vendor/autoload.php was not found.
INFO - 2024-04-28 18:26:52 --> Config Class Initialized
INFO - 2024-04-28 18:26:52 --> Hooks Class Initialized
DEBUG - 2024-04-28 18:26:52 --> UTF-8 Support Enabled
INFO - 2024-04-28 18:26:52 --> Utf8 Class Initialized
INFO - 2024-04-28 18:26:52 --> URI Class Initialized
INFO - 2024-04-28 18:26:52 --> Router Class Initialized
INFO - 2024-04-28 18:26:52 --> Output Class Initialized
INFO - 2024-04-28 18:26:52 --> Security Class Initialized
DEBUG - 2024-04-28 18:26:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-04-28 18:26:52 --> Input Class Initialized
INFO - 2024-04-28 18:26:52 --> Language Class Initialized
ERROR - 2024-04-28 18:26:52 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2024-04-28 18:26:53 --> $config['composer_autoload'] is set to TRUE but E:\xampp\htdocs\maurnaturo\application\vendor/autoload.php was not found.
INFO - 2024-04-28 18:26:53 --> Config Class Initialized
INFO - 2024-04-28 18:26:53 --> Hooks Class Initialized
DEBUG - 2024-04-28 18:26:53 --> UTF-8 Support Enabled
INFO - 2024-04-28 18:26:53 --> Utf8 Class Initialized
INFO - 2024-04-28 18:26:53 --> URI Class Initialized
INFO - 2024-04-28 18:26:53 --> Router Class Initialized
INFO - 2024-04-28 18:26:53 --> Output Class Initialized
INFO - 2024-04-28 18:26:53 --> Security Class Initialized
DEBUG - 2024-04-28 18:26:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-04-28 18:26:53 --> Input Class Initialized
INFO - 2024-04-28 18:26:53 --> Language Class Initialized
ERROR - 2024-04-28 18:26:53 --> 404 Page Not Found: Assets/plugins
ERROR - 2024-04-28 18:27:15 --> $config['composer_autoload'] is set to TRUE but E:\xampp\htdocs\maurnaturo\application\vendor/autoload.php was not found.
INFO - 2024-04-28 18:27:15 --> Config Class Initialized
INFO - 2024-04-28 18:27:15 --> Hooks Class Initialized
DEBUG - 2024-04-28 18:27:15 --> UTF-8 Support Enabled
INFO - 2024-04-28 18:27:15 --> Utf8 Class Initialized
INFO - 2024-04-28 18:27:15 --> URI Class Initialized
INFO - 2024-04-28 18:27:15 --> Router Class Initialized
INFO - 2024-04-28 18:27:15 --> Output Class Initialized
INFO - 2024-04-28 18:27:15 --> Security Class Initialized
DEBUG - 2024-04-28 18:27:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-04-28 18:27:15 --> Input Class Initialized
INFO - 2024-04-28 18:27:15 --> Language Class Initialized
INFO - 2024-04-28 18:27:15 --> Loader Class Initialized
INFO - 2024-04-28 18:27:15 --> Helper loaded: url_helper
INFO - 2024-04-28 18:27:15 --> Helper loaded: file_helper
INFO - 2024-04-28 18:27:15 --> Helper loaded: html_helper
INFO - 2024-04-28 18:27:15 --> Helper loaded: text_helper
INFO - 2024-04-28 18:27:15 --> Helper loaded: form_helper
INFO - 2024-04-28 18:27:15 --> Helper loaded: lang_helper
INFO - 2024-04-28 18:27:15 --> Helper loaded: security_helper
INFO - 2024-04-28 18:27:15 --> Helper loaded: cookie_helper
INFO - 2024-04-28 18:27:15 --> Database Driver Class Initialized
INFO - 2024-04-28 18:27:15 --> Session: Class initialized using 'files' driver.
INFO - 2024-04-28 18:27:15 --> Parser Class Initialized
INFO - 2024-04-28 18:27:15 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-04-28 18:27:15 --> Pagination Class Initialized
INFO - 2024-04-28 18:27:15 --> Form Validation Class Initialized
INFO - 2024-04-28 18:27:15 --> Controller Class Initialized
DEBUG - 2024-04-28 18:27:15 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-04-28 18:27:15 --> Session class already loaded. Second attempt ignored.
INFO - 2024-04-28 18:27:15 --> Model Class Initialized
INFO - 2024-04-28 18:27:15 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\payments/add_payment_form.php
DEBUG - 2024-04-28 18:27:15 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-04-28 18:27:15 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\include/top_menu.php
INFO - 2024-04-28 18:27:15 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\include/admin_loggedin_info.php
INFO - 2024-04-28 18:27:15 --> Model Class Initialized
INFO - 2024-04-28 18:27:15 --> Model Class Initialized
INFO - 2024-04-28 18:27:15 --> Model Class Initialized
INFO - 2024-04-28 18:27:15 --> Model Class Initialized
INFO - 2024-04-28 18:27:16 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\include/admin_header.php
INFO - 2024-04-28 18:27:16 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\include/admin_footer.php
INFO - 2024-04-28 18:27:16 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\admin_html_template.php
INFO - 2024-04-28 18:27:16 --> Final output sent to browser
DEBUG - 2024-04-28 18:27:16 --> Total execution time: 1.2436
ERROR - 2024-04-28 18:27:16 --> $config['composer_autoload'] is set to TRUE but E:\xampp\htdocs\maurnaturo\application\vendor/autoload.php was not found.
INFO - 2024-04-28 18:27:16 --> Config Class Initialized
INFO - 2024-04-28 18:27:16 --> Hooks Class Initialized
DEBUG - 2024-04-28 18:27:16 --> UTF-8 Support Enabled
INFO - 2024-04-28 18:27:16 --> Utf8 Class Initialized
INFO - 2024-04-28 18:27:16 --> URI Class Initialized
INFO - 2024-04-28 18:27:16 --> Router Class Initialized
INFO - 2024-04-28 18:27:16 --> Output Class Initialized
INFO - 2024-04-28 18:27:16 --> Security Class Initialized
DEBUG - 2024-04-28 18:27:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-04-28 18:27:16 --> Input Class Initialized
INFO - 2024-04-28 18:27:16 --> Language Class Initialized
ERROR - 2024-04-28 18:27:16 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2024-04-28 18:27:17 --> $config['composer_autoload'] is set to TRUE but E:\xampp\htdocs\maurnaturo\application\vendor/autoload.php was not found.
INFO - 2024-04-28 18:27:17 --> Config Class Initialized
INFO - 2024-04-28 18:27:17 --> Hooks Class Initialized
DEBUG - 2024-04-28 18:27:17 --> UTF-8 Support Enabled
INFO - 2024-04-28 18:27:17 --> Utf8 Class Initialized
INFO - 2024-04-28 18:27:17 --> URI Class Initialized
INFO - 2024-04-28 18:27:17 --> Router Class Initialized
INFO - 2024-04-28 18:27:17 --> Output Class Initialized
INFO - 2024-04-28 18:27:17 --> Security Class Initialized
DEBUG - 2024-04-28 18:27:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-04-28 18:27:17 --> Input Class Initialized
INFO - 2024-04-28 18:27:17 --> Language Class Initialized
ERROR - 2024-04-28 18:27:17 --> 404 Page Not Found: Assets/plugins
ERROR - 2024-04-28 18:27:22 --> $config['composer_autoload'] is set to TRUE but E:\xampp\htdocs\maurnaturo\application\vendor/autoload.php was not found.
INFO - 2024-04-28 18:27:22 --> Config Class Initialized
INFO - 2024-04-28 18:27:22 --> Hooks Class Initialized
DEBUG - 2024-04-28 18:27:22 --> UTF-8 Support Enabled
INFO - 2024-04-28 18:27:22 --> Utf8 Class Initialized
INFO - 2024-04-28 18:27:22 --> URI Class Initialized
INFO - 2024-04-28 18:27:22 --> Router Class Initialized
INFO - 2024-04-28 18:27:22 --> Output Class Initialized
INFO - 2024-04-28 18:27:22 --> Security Class Initialized
DEBUG - 2024-04-28 18:27:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-04-28 18:27:22 --> Input Class Initialized
INFO - 2024-04-28 18:27:22 --> Language Class Initialized
INFO - 2024-04-28 18:27:22 --> Loader Class Initialized
INFO - 2024-04-28 18:27:22 --> Helper loaded: url_helper
INFO - 2024-04-28 18:27:22 --> Helper loaded: file_helper
INFO - 2024-04-28 18:27:22 --> Helper loaded: html_helper
INFO - 2024-04-28 18:27:22 --> Helper loaded: text_helper
INFO - 2024-04-28 18:27:22 --> Helper loaded: form_helper
INFO - 2024-04-28 18:27:22 --> Helper loaded: lang_helper
INFO - 2024-04-28 18:27:22 --> Helper loaded: security_helper
INFO - 2024-04-28 18:27:22 --> Helper loaded: cookie_helper
INFO - 2024-04-28 18:27:22 --> Database Driver Class Initialized
INFO - 2024-04-28 18:27:22 --> Session: Class initialized using 'files' driver.
INFO - 2024-04-28 18:27:22 --> Parser Class Initialized
INFO - 2024-04-28 18:27:22 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-04-28 18:27:22 --> Pagination Class Initialized
INFO - 2024-04-28 18:27:22 --> Form Validation Class Initialized
INFO - 2024-04-28 18:27:22 --> Controller Class Initialized
DEBUG - 2024-04-28 18:27:22 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-04-28 18:27:22 --> Session class already loaded. Second attempt ignored.
INFO - 2024-04-28 18:27:22 --> Model Class Initialized
DEBUG - 2024-04-28 18:27:22 --> Lpayments class already loaded. Second attempt ignored.
INFO - 2024-04-28 18:27:22 --> Model Class Initialized
INFO - 2024-04-28 18:27:22 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\payments/payment.php
DEBUG - 2024-04-28 18:27:22 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-04-28 18:27:22 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\include/top_menu.php
INFO - 2024-04-28 18:27:22 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\include/admin_loggedin_info.php
INFO - 2024-04-28 18:27:22 --> Model Class Initialized
INFO - 2024-04-28 18:27:22 --> Model Class Initialized
INFO - 2024-04-28 18:27:22 --> Model Class Initialized
INFO - 2024-04-28 18:27:24 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\include/admin_header.php
INFO - 2024-04-28 18:27:24 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\include/admin_footer.php
INFO - 2024-04-28 18:27:24 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\admin_html_template.php
INFO - 2024-04-28 18:27:24 --> Final output sent to browser
DEBUG - 2024-04-28 18:27:24 --> Total execution time: 1.2829
ERROR - 2024-04-28 18:27:30 --> $config['composer_autoload'] is set to TRUE but E:\xampp\htdocs\maurnaturo\application\vendor/autoload.php was not found.
INFO - 2024-04-28 18:27:30 --> Config Class Initialized
INFO - 2024-04-28 18:27:30 --> Hooks Class Initialized
DEBUG - 2024-04-28 18:27:30 --> UTF-8 Support Enabled
INFO - 2024-04-28 18:27:30 --> Utf8 Class Initialized
INFO - 2024-04-28 18:27:30 --> URI Class Initialized
INFO - 2024-04-28 18:27:30 --> Router Class Initialized
INFO - 2024-04-28 18:27:30 --> Output Class Initialized
INFO - 2024-04-28 18:27:30 --> Security Class Initialized
DEBUG - 2024-04-28 18:27:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-04-28 18:27:30 --> Input Class Initialized
INFO - 2024-04-28 18:27:30 --> Language Class Initialized
INFO - 2024-04-28 18:27:30 --> Loader Class Initialized
INFO - 2024-04-28 18:27:30 --> Helper loaded: url_helper
INFO - 2024-04-28 18:27:30 --> Helper loaded: file_helper
INFO - 2024-04-28 18:27:30 --> Helper loaded: html_helper
INFO - 2024-04-28 18:27:30 --> Helper loaded: text_helper
INFO - 2024-04-28 18:27:30 --> Helper loaded: form_helper
INFO - 2024-04-28 18:27:30 --> Helper loaded: lang_helper
INFO - 2024-04-28 18:27:30 --> Helper loaded: security_helper
INFO - 2024-04-28 18:27:30 --> Helper loaded: cookie_helper
INFO - 2024-04-28 18:27:30 --> Database Driver Class Initialized
INFO - 2024-04-28 18:27:30 --> Session: Class initialized using 'files' driver.
INFO - 2024-04-28 18:27:30 --> Parser Class Initialized
INFO - 2024-04-28 18:27:30 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-04-28 18:27:30 --> Pagination Class Initialized
INFO - 2024-04-28 18:27:30 --> Form Validation Class Initialized
INFO - 2024-04-28 18:27:30 --> Controller Class Initialized
DEBUG - 2024-04-28 18:27:30 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-04-28 18:27:30 --> Session class already loaded. Second attempt ignored.
INFO - 2024-04-28 18:27:30 --> Model Class Initialized
DEBUG - 2024-04-28 18:27:30 --> Lpayments class already loaded. Second attempt ignored.
INFO - 2024-04-28 18:27:30 --> Model Class Initialized
INFO - 2024-04-28 18:27:31 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\payments/payment.php
DEBUG - 2024-04-28 18:27:31 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-04-28 18:27:31 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\include/top_menu.php
INFO - 2024-04-28 18:27:31 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\include/admin_loggedin_info.php
INFO - 2024-04-28 18:27:31 --> Model Class Initialized
INFO - 2024-04-28 18:27:31 --> Model Class Initialized
INFO - 2024-04-28 18:27:31 --> Model Class Initialized
INFO - 2024-04-28 18:27:32 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\include/admin_header.php
INFO - 2024-04-28 18:27:32 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\include/admin_footer.php
INFO - 2024-04-28 18:27:32 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\admin_html_template.php
INFO - 2024-04-28 18:27:32 --> Final output sent to browser
DEBUG - 2024-04-28 18:27:32 --> Total execution time: 1.5272
ERROR - 2024-04-28 18:27:40 --> $config['composer_autoload'] is set to TRUE but E:\xampp\htdocs\maurnaturo\application\vendor/autoload.php was not found.
INFO - 2024-04-28 18:27:40 --> Config Class Initialized
INFO - 2024-04-28 18:27:40 --> Hooks Class Initialized
DEBUG - 2024-04-28 18:27:40 --> UTF-8 Support Enabled
INFO - 2024-04-28 18:27:40 --> Utf8 Class Initialized
INFO - 2024-04-28 18:27:40 --> URI Class Initialized
INFO - 2024-04-28 18:27:40 --> Router Class Initialized
INFO - 2024-04-28 18:27:40 --> Output Class Initialized
INFO - 2024-04-28 18:27:40 --> Security Class Initialized
DEBUG - 2024-04-28 18:27:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-04-28 18:27:40 --> Input Class Initialized
INFO - 2024-04-28 18:27:40 --> Language Class Initialized
ERROR - 2024-04-28 18:27:40 --> 404 Page Not Found: Assets/plugins
ERROR - 2024-04-28 18:27:40 --> $config['composer_autoload'] is set to TRUE but E:\xampp\htdocs\maurnaturo\application\vendor/autoload.php was not found.
INFO - 2024-04-28 18:27:40 --> Config Class Initialized
INFO - 2024-04-28 18:27:40 --> Hooks Class Initialized
DEBUG - 2024-04-28 18:27:40 --> UTF-8 Support Enabled
INFO - 2024-04-28 18:27:40 --> Utf8 Class Initialized
INFO - 2024-04-28 18:27:40 --> URI Class Initialized
INFO - 2024-04-28 18:27:40 --> Router Class Initialized
INFO - 2024-04-28 18:27:40 --> Output Class Initialized
INFO - 2024-04-28 18:27:40 --> Security Class Initialized
DEBUG - 2024-04-28 18:27:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-04-28 18:27:40 --> Input Class Initialized
INFO - 2024-04-28 18:27:40 --> Language Class Initialized
ERROR - 2024-04-28 18:27:40 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2024-04-28 18:27:59 --> $config['composer_autoload'] is set to TRUE but E:\xampp\htdocs\maurnaturo\application\vendor/autoload.php was not found.
INFO - 2024-04-28 18:27:59 --> Config Class Initialized
INFO - 2024-04-28 18:27:59 --> Hooks Class Initialized
DEBUG - 2024-04-28 18:27:59 --> UTF-8 Support Enabled
INFO - 2024-04-28 18:27:59 --> Utf8 Class Initialized
INFO - 2024-04-28 18:27:59 --> URI Class Initialized
INFO - 2024-04-28 18:27:59 --> Router Class Initialized
INFO - 2024-04-28 18:27:59 --> Output Class Initialized
INFO - 2024-04-28 18:27:59 --> Security Class Initialized
DEBUG - 2024-04-28 18:27:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-04-28 18:27:59 --> Input Class Initialized
INFO - 2024-04-28 18:27:59 --> Language Class Initialized
INFO - 2024-04-28 18:27:59 --> Loader Class Initialized
INFO - 2024-04-28 18:27:59 --> Helper loaded: url_helper
INFO - 2024-04-28 18:27:59 --> Helper loaded: file_helper
INFO - 2024-04-28 18:27:59 --> Helper loaded: html_helper
INFO - 2024-04-28 18:27:59 --> Helper loaded: text_helper
INFO - 2024-04-28 18:27:59 --> Helper loaded: form_helper
INFO - 2024-04-28 18:27:59 --> Helper loaded: lang_helper
INFO - 2024-04-28 18:27:59 --> Helper loaded: security_helper
INFO - 2024-04-28 18:27:59 --> Helper loaded: cookie_helper
INFO - 2024-04-28 18:27:59 --> Database Driver Class Initialized
INFO - 2024-04-28 18:27:59 --> Session: Class initialized using 'files' driver.
INFO - 2024-04-28 18:27:59 --> Parser Class Initialized
INFO - 2024-04-28 18:27:59 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-04-28 18:27:59 --> Pagination Class Initialized
INFO - 2024-04-28 18:27:59 --> Form Validation Class Initialized
INFO - 2024-04-28 18:27:59 --> Controller Class Initialized
DEBUG - 2024-04-28 18:27:59 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-04-28 18:27:59 --> Session class already loaded. Second attempt ignored.
INFO - 2024-04-28 18:27:59 --> Model Class Initialized
DEBUG - 2024-04-28 18:27:59 --> Lpayments class already loaded. Second attempt ignored.
INFO - 2024-04-28 18:27:59 --> Model Class Initialized
INFO - 2024-04-28 18:27:59 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\payments/payment.php
DEBUG - 2024-04-28 18:27:59 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-04-28 18:27:59 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\include/top_menu.php
INFO - 2024-04-28 18:27:59 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\include/admin_loggedin_info.php
INFO - 2024-04-28 18:27:59 --> Model Class Initialized
INFO - 2024-04-28 18:27:59 --> Model Class Initialized
INFO - 2024-04-28 18:27:59 --> Model Class Initialized
INFO - 2024-04-28 18:28:00 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\include/admin_header.php
INFO - 2024-04-28 18:28:00 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\include/admin_footer.php
INFO - 2024-04-28 18:28:00 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\admin_html_template.php
INFO - 2024-04-28 18:28:00 --> Final output sent to browser
DEBUG - 2024-04-28 18:28:00 --> Total execution time: 1.5494
ERROR - 2024-04-28 18:28:01 --> $config['composer_autoload'] is set to TRUE but E:\xampp\htdocs\maurnaturo\application\vendor/autoload.php was not found.
INFO - 2024-04-28 18:28:01 --> Config Class Initialized
INFO - 2024-04-28 18:28:01 --> Hooks Class Initialized
DEBUG - 2024-04-28 18:28:01 --> UTF-8 Support Enabled
INFO - 2024-04-28 18:28:01 --> Utf8 Class Initialized
INFO - 2024-04-28 18:28:01 --> URI Class Initialized
INFO - 2024-04-28 18:28:01 --> Router Class Initialized
INFO - 2024-04-28 18:28:01 --> Output Class Initialized
INFO - 2024-04-28 18:28:01 --> Security Class Initialized
DEBUG - 2024-04-28 18:28:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-04-28 18:28:01 --> Input Class Initialized
INFO - 2024-04-28 18:28:01 --> Language Class Initialized
ERROR - 2024-04-28 18:28:01 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2024-04-28 18:28:01 --> $config['composer_autoload'] is set to TRUE but E:\xampp\htdocs\maurnaturo\application\vendor/autoload.php was not found.
INFO - 2024-04-28 18:28:01 --> Config Class Initialized
INFO - 2024-04-28 18:28:01 --> Hooks Class Initialized
DEBUG - 2024-04-28 18:28:01 --> UTF-8 Support Enabled
INFO - 2024-04-28 18:28:01 --> Utf8 Class Initialized
INFO - 2024-04-28 18:28:01 --> URI Class Initialized
INFO - 2024-04-28 18:28:01 --> Router Class Initialized
INFO - 2024-04-28 18:28:01 --> Output Class Initialized
INFO - 2024-04-28 18:28:01 --> Security Class Initialized
DEBUG - 2024-04-28 18:28:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-04-28 18:28:01 --> Input Class Initialized
INFO - 2024-04-28 18:28:01 --> Language Class Initialized
ERROR - 2024-04-28 18:28:01 --> 404 Page Not Found: Assets/plugins
ERROR - 2024-04-28 18:29:27 --> $config['composer_autoload'] is set to TRUE but E:\xampp\htdocs\maurnaturo\application\vendor/autoload.php was not found.
INFO - 2024-04-28 18:29:27 --> Config Class Initialized
INFO - 2024-04-28 18:29:27 --> Hooks Class Initialized
DEBUG - 2024-04-28 18:29:27 --> UTF-8 Support Enabled
INFO - 2024-04-28 18:29:27 --> Utf8 Class Initialized
INFO - 2024-04-28 18:29:27 --> URI Class Initialized
INFO - 2024-04-28 18:29:27 --> Router Class Initialized
INFO - 2024-04-28 18:29:27 --> Output Class Initialized
INFO - 2024-04-28 18:29:27 --> Security Class Initialized
DEBUG - 2024-04-28 18:29:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-04-28 18:29:27 --> Input Class Initialized
INFO - 2024-04-28 18:29:27 --> Language Class Initialized
INFO - 2024-04-28 18:29:27 --> Loader Class Initialized
INFO - 2024-04-28 18:29:27 --> Helper loaded: url_helper
INFO - 2024-04-28 18:29:27 --> Helper loaded: file_helper
INFO - 2024-04-28 18:29:27 --> Helper loaded: html_helper
INFO - 2024-04-28 18:29:27 --> Helper loaded: text_helper
INFO - 2024-04-28 18:29:27 --> Helper loaded: form_helper
INFO - 2024-04-28 18:29:27 --> Helper loaded: lang_helper
INFO - 2024-04-28 18:29:27 --> Helper loaded: security_helper
INFO - 2024-04-28 18:29:27 --> Helper loaded: cookie_helper
INFO - 2024-04-28 18:29:27 --> Database Driver Class Initialized
INFO - 2024-04-28 18:29:27 --> Session: Class initialized using 'files' driver.
INFO - 2024-04-28 18:29:27 --> Parser Class Initialized
INFO - 2024-04-28 18:29:27 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-04-28 18:29:27 --> Pagination Class Initialized
INFO - 2024-04-28 18:29:27 --> Form Validation Class Initialized
INFO - 2024-04-28 18:29:27 --> Controller Class Initialized
DEBUG - 2024-04-28 18:29:27 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-04-28 18:29:27 --> Session class already loaded. Second attempt ignored.
INFO - 2024-04-28 18:29:27 --> Model Class Initialized
DEBUG - 2024-04-28 18:29:27 --> Lpayments class already loaded. Second attempt ignored.
INFO - 2024-04-28 18:29:27 --> Model Class Initialized
INFO - 2024-04-28 18:29:27 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\payments/payment.php
DEBUG - 2024-04-28 18:29:27 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-04-28 18:29:27 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\include/top_menu.php
INFO - 2024-04-28 18:29:27 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\include/admin_loggedin_info.php
INFO - 2024-04-28 18:29:27 --> Model Class Initialized
INFO - 2024-04-28 18:29:27 --> Model Class Initialized
INFO - 2024-04-28 18:29:27 --> Model Class Initialized
INFO - 2024-04-28 18:29:28 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\include/admin_header.php
INFO - 2024-04-28 18:29:28 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\include/admin_footer.php
INFO - 2024-04-28 18:29:28 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\admin_html_template.php
INFO - 2024-04-28 18:29:28 --> Final output sent to browser
DEBUG - 2024-04-28 18:29:28 --> Total execution time: 1.4804
ERROR - 2024-04-28 18:29:28 --> $config['composer_autoload'] is set to TRUE but E:\xampp\htdocs\maurnaturo\application\vendor/autoload.php was not found.
INFO - 2024-04-28 18:29:28 --> Config Class Initialized
INFO - 2024-04-28 18:29:28 --> Hooks Class Initialized
DEBUG - 2024-04-28 18:29:28 --> UTF-8 Support Enabled
INFO - 2024-04-28 18:29:28 --> Utf8 Class Initialized
INFO - 2024-04-28 18:29:28 --> URI Class Initialized
INFO - 2024-04-28 18:29:29 --> Router Class Initialized
INFO - 2024-04-28 18:29:29 --> Output Class Initialized
INFO - 2024-04-28 18:29:29 --> Security Class Initialized
DEBUG - 2024-04-28 18:29:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-04-28 18:29:29 --> Input Class Initialized
INFO - 2024-04-28 18:29:29 --> Language Class Initialized
ERROR - 2024-04-28 18:29:29 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2024-04-28 18:29:30 --> $config['composer_autoload'] is set to TRUE but E:\xampp\htdocs\maurnaturo\application\vendor/autoload.php was not found.
INFO - 2024-04-28 18:29:30 --> Config Class Initialized
INFO - 2024-04-28 18:29:30 --> Hooks Class Initialized
DEBUG - 2024-04-28 18:29:30 --> UTF-8 Support Enabled
INFO - 2024-04-28 18:29:30 --> Utf8 Class Initialized
INFO - 2024-04-28 18:29:30 --> URI Class Initialized
INFO - 2024-04-28 18:29:30 --> Router Class Initialized
INFO - 2024-04-28 18:29:30 --> Output Class Initialized
INFO - 2024-04-28 18:29:30 --> Security Class Initialized
DEBUG - 2024-04-28 18:29:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-04-28 18:29:30 --> Input Class Initialized
INFO - 2024-04-28 18:29:30 --> Language Class Initialized
ERROR - 2024-04-28 18:29:30 --> 404 Page Not Found: Assets/plugins
ERROR - 2024-04-28 18:32:32 --> $config['composer_autoload'] is set to TRUE but E:\xampp\htdocs\maurnaturo\application\vendor/autoload.php was not found.
INFO - 2024-04-28 18:32:32 --> Config Class Initialized
INFO - 2024-04-28 18:32:32 --> Hooks Class Initialized
DEBUG - 2024-04-28 18:32:32 --> UTF-8 Support Enabled
INFO - 2024-04-28 18:32:32 --> Utf8 Class Initialized
INFO - 2024-04-28 18:32:32 --> URI Class Initialized
INFO - 2024-04-28 18:32:32 --> Router Class Initialized
INFO - 2024-04-28 18:32:32 --> Output Class Initialized
INFO - 2024-04-28 18:32:32 --> Security Class Initialized
DEBUG - 2024-04-28 18:32:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-04-28 18:32:32 --> Input Class Initialized
INFO - 2024-04-28 18:32:32 --> Language Class Initialized
INFO - 2024-04-28 18:32:32 --> Loader Class Initialized
INFO - 2024-04-28 18:32:32 --> Helper loaded: url_helper
INFO - 2024-04-28 18:32:32 --> Helper loaded: file_helper
INFO - 2024-04-28 18:32:32 --> Helper loaded: html_helper
INFO - 2024-04-28 18:32:32 --> Helper loaded: text_helper
INFO - 2024-04-28 18:32:32 --> Helper loaded: form_helper
INFO - 2024-04-28 18:32:32 --> Helper loaded: lang_helper
INFO - 2024-04-28 18:32:32 --> Helper loaded: security_helper
INFO - 2024-04-28 18:32:32 --> Helper loaded: cookie_helper
INFO - 2024-04-28 18:32:32 --> Database Driver Class Initialized
INFO - 2024-04-28 18:32:32 --> Session: Class initialized using 'files' driver.
INFO - 2024-04-28 18:32:32 --> Parser Class Initialized
INFO - 2024-04-28 18:32:32 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-04-28 18:32:32 --> Pagination Class Initialized
INFO - 2024-04-28 18:32:32 --> Form Validation Class Initialized
INFO - 2024-04-28 18:32:32 --> Controller Class Initialized
DEBUG - 2024-04-28 18:32:32 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-04-28 18:32:32 --> Session class already loaded. Second attempt ignored.
INFO - 2024-04-28 18:32:32 --> Model Class Initialized
DEBUG - 2024-04-28 18:32:32 --> Lpayments class already loaded. Second attempt ignored.
INFO - 2024-04-28 18:32:32 --> Model Class Initialized
INFO - 2024-04-28 18:32:32 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\payments/payment.php
DEBUG - 2024-04-28 18:32:32 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-04-28 18:32:32 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\include/top_menu.php
INFO - 2024-04-28 18:32:32 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\include/admin_loggedin_info.php
INFO - 2024-04-28 18:32:32 --> Model Class Initialized
INFO - 2024-04-28 18:32:32 --> Model Class Initialized
INFO - 2024-04-28 18:32:32 --> Model Class Initialized
INFO - 2024-04-28 18:32:33 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\include/admin_header.php
INFO - 2024-04-28 18:32:33 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\include/admin_footer.php
INFO - 2024-04-28 18:32:33 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\admin_html_template.php
INFO - 2024-04-28 18:32:33 --> Final output sent to browser
DEBUG - 2024-04-28 18:32:33 --> Total execution time: 1.6669
ERROR - 2024-04-28 18:32:34 --> $config['composer_autoload'] is set to TRUE but E:\xampp\htdocs\maurnaturo\application\vendor/autoload.php was not found.
INFO - 2024-04-28 18:32:34 --> Config Class Initialized
INFO - 2024-04-28 18:32:34 --> Hooks Class Initialized
DEBUG - 2024-04-28 18:32:34 --> UTF-8 Support Enabled
INFO - 2024-04-28 18:32:34 --> Utf8 Class Initialized
INFO - 2024-04-28 18:32:34 --> URI Class Initialized
INFO - 2024-04-28 18:32:34 --> Router Class Initialized
INFO - 2024-04-28 18:32:34 --> Output Class Initialized
INFO - 2024-04-28 18:32:34 --> Security Class Initialized
DEBUG - 2024-04-28 18:32:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-04-28 18:32:34 --> Input Class Initialized
INFO - 2024-04-28 18:32:34 --> Language Class Initialized
ERROR - 2024-04-28 18:32:34 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2024-04-28 18:32:35 --> $config['composer_autoload'] is set to TRUE but E:\xampp\htdocs\maurnaturo\application\vendor/autoload.php was not found.
INFO - 2024-04-28 18:32:35 --> Config Class Initialized
INFO - 2024-04-28 18:32:35 --> Hooks Class Initialized
DEBUG - 2024-04-28 18:32:35 --> UTF-8 Support Enabled
INFO - 2024-04-28 18:32:35 --> Utf8 Class Initialized
INFO - 2024-04-28 18:32:35 --> URI Class Initialized
INFO - 2024-04-28 18:32:35 --> Router Class Initialized
INFO - 2024-04-28 18:32:35 --> Output Class Initialized
INFO - 2024-04-28 18:32:35 --> Security Class Initialized
DEBUG - 2024-04-28 18:32:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-04-28 18:32:35 --> Input Class Initialized
INFO - 2024-04-28 18:32:35 --> Language Class Initialized
ERROR - 2024-04-28 18:32:35 --> 404 Page Not Found: Assets/plugins
ERROR - 2024-04-28 18:33:24 --> $config['composer_autoload'] is set to TRUE but E:\xampp\htdocs\maurnaturo\application\vendor/autoload.php was not found.
INFO - 2024-04-28 18:33:24 --> Config Class Initialized
INFO - 2024-04-28 18:33:24 --> Hooks Class Initialized
DEBUG - 2024-04-28 18:33:24 --> UTF-8 Support Enabled
INFO - 2024-04-28 18:33:24 --> Utf8 Class Initialized
INFO - 2024-04-28 18:33:24 --> URI Class Initialized
INFO - 2024-04-28 18:33:24 --> Router Class Initialized
INFO - 2024-04-28 18:33:24 --> Output Class Initialized
INFO - 2024-04-28 18:33:24 --> Security Class Initialized
DEBUG - 2024-04-28 18:33:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-04-28 18:33:24 --> Input Class Initialized
INFO - 2024-04-28 18:33:24 --> Language Class Initialized
INFO - 2024-04-28 18:33:24 --> Loader Class Initialized
INFO - 2024-04-28 18:33:24 --> Helper loaded: url_helper
INFO - 2024-04-28 18:33:24 --> Helper loaded: file_helper
INFO - 2024-04-28 18:33:24 --> Helper loaded: html_helper
INFO - 2024-04-28 18:33:24 --> Helper loaded: text_helper
INFO - 2024-04-28 18:33:24 --> Helper loaded: form_helper
INFO - 2024-04-28 18:33:24 --> Helper loaded: lang_helper
INFO - 2024-04-28 18:33:24 --> Helper loaded: security_helper
INFO - 2024-04-28 18:33:24 --> Helper loaded: cookie_helper
INFO - 2024-04-28 18:33:24 --> Database Driver Class Initialized
INFO - 2024-04-28 18:33:24 --> Session: Class initialized using 'files' driver.
INFO - 2024-04-28 18:33:24 --> Parser Class Initialized
INFO - 2024-04-28 18:33:24 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-04-28 18:33:24 --> Pagination Class Initialized
INFO - 2024-04-28 18:33:24 --> Form Validation Class Initialized
INFO - 2024-04-28 18:33:24 --> Controller Class Initialized
DEBUG - 2024-04-28 18:33:24 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-04-28 18:33:24 --> Session class already loaded. Second attempt ignored.
INFO - 2024-04-28 18:33:24 --> Model Class Initialized
DEBUG - 2024-04-28 18:33:24 --> Lpayments class already loaded. Second attempt ignored.
INFO - 2024-04-28 18:33:24 --> Model Class Initialized
INFO - 2024-04-28 18:33:24 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\payments/payment.php
DEBUG - 2024-04-28 18:33:25 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-04-28 18:33:25 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\include/top_menu.php
INFO - 2024-04-28 18:33:25 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\include/admin_loggedin_info.php
INFO - 2024-04-28 18:33:25 --> Model Class Initialized
INFO - 2024-04-28 18:33:25 --> Model Class Initialized
INFO - 2024-04-28 18:33:25 --> Model Class Initialized
INFO - 2024-04-28 18:33:26 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\include/admin_header.php
INFO - 2024-04-28 18:33:26 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\include/admin_footer.php
INFO - 2024-04-28 18:33:26 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\admin_html_template.php
INFO - 2024-04-28 18:33:26 --> Final output sent to browser
DEBUG - 2024-04-28 18:33:26 --> Total execution time: 1.9054
ERROR - 2024-04-28 18:33:27 --> $config['composer_autoload'] is set to TRUE but E:\xampp\htdocs\maurnaturo\application\vendor/autoload.php was not found.
INFO - 2024-04-28 18:33:27 --> Config Class Initialized
INFO - 2024-04-28 18:33:27 --> Hooks Class Initialized
DEBUG - 2024-04-28 18:33:27 --> UTF-8 Support Enabled
INFO - 2024-04-28 18:33:27 --> Utf8 Class Initialized
INFO - 2024-04-28 18:33:27 --> URI Class Initialized
INFO - 2024-04-28 18:33:27 --> Router Class Initialized
INFO - 2024-04-28 18:33:27 --> Output Class Initialized
INFO - 2024-04-28 18:33:27 --> Security Class Initialized
DEBUG - 2024-04-28 18:33:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-04-28 18:33:27 --> Input Class Initialized
INFO - 2024-04-28 18:33:27 --> Language Class Initialized
ERROR - 2024-04-28 18:33:27 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2024-04-28 18:33:27 --> $config['composer_autoload'] is set to TRUE but E:\xampp\htdocs\maurnaturo\application\vendor/autoload.php was not found.
INFO - 2024-04-28 18:33:27 --> Config Class Initialized
INFO - 2024-04-28 18:33:27 --> Hooks Class Initialized
DEBUG - 2024-04-28 18:33:27 --> UTF-8 Support Enabled
INFO - 2024-04-28 18:33:27 --> Utf8 Class Initialized
INFO - 2024-04-28 18:33:27 --> URI Class Initialized
INFO - 2024-04-28 18:33:27 --> Router Class Initialized
INFO - 2024-04-28 18:33:27 --> Output Class Initialized
INFO - 2024-04-28 18:33:27 --> Security Class Initialized
DEBUG - 2024-04-28 18:33:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-04-28 18:33:27 --> Input Class Initialized
INFO - 2024-04-28 18:33:27 --> Language Class Initialized
ERROR - 2024-04-28 18:33:27 --> 404 Page Not Found: Assets/plugins
ERROR - 2024-04-28 18:33:27 --> $config['composer_autoload'] is set to TRUE but E:\xampp\htdocs\maurnaturo\application\vendor/autoload.php was not found.
INFO - 2024-04-28 18:33:27 --> Config Class Initialized
INFO - 2024-04-28 18:33:27 --> Hooks Class Initialized
DEBUG - 2024-04-28 18:33:27 --> UTF-8 Support Enabled
INFO - 2024-04-28 18:33:27 --> Utf8 Class Initialized
INFO - 2024-04-28 18:33:27 --> URI Class Initialized
INFO - 2024-04-28 18:33:27 --> Router Class Initialized
INFO - 2024-04-28 18:33:27 --> Output Class Initialized
INFO - 2024-04-28 18:33:27 --> Security Class Initialized
DEBUG - 2024-04-28 18:33:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-04-28 18:33:27 --> Input Class Initialized
INFO - 2024-04-28 18:33:27 --> Language Class Initialized
INFO - 2024-04-28 18:33:27 --> Loader Class Initialized
INFO - 2024-04-28 18:33:27 --> Helper loaded: url_helper
INFO - 2024-04-28 18:33:27 --> Helper loaded: file_helper
INFO - 2024-04-28 18:33:27 --> Helper loaded: html_helper
INFO - 2024-04-28 18:33:27 --> Helper loaded: text_helper
INFO - 2024-04-28 18:33:27 --> Helper loaded: form_helper
INFO - 2024-04-28 18:33:27 --> Helper loaded: lang_helper
INFO - 2024-04-28 18:33:27 --> Helper loaded: security_helper
INFO - 2024-04-28 18:33:27 --> Helper loaded: cookie_helper
INFO - 2024-04-28 18:33:28 --> Database Driver Class Initialized
INFO - 2024-04-28 18:33:28 --> Session: Class initialized using 'files' driver.
INFO - 2024-04-28 18:33:28 --> Parser Class Initialized
INFO - 2024-04-28 18:33:28 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-04-28 18:33:28 --> Pagination Class Initialized
INFO - 2024-04-28 18:33:28 --> Form Validation Class Initialized
INFO - 2024-04-28 18:33:28 --> Controller Class Initialized
DEBUG - 2024-04-28 18:33:28 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-04-28 18:33:28 --> Session class already loaded. Second attempt ignored.
INFO - 2024-04-28 18:33:28 --> Model Class Initialized
INFO - 2024-04-28 18:33:28 --> Final output sent to browser
DEBUG - 2024-04-28 18:33:28 --> Total execution time: 0.1068
ERROR - 2024-04-28 18:33:59 --> $config['composer_autoload'] is set to TRUE but E:\xampp\htdocs\maurnaturo\application\vendor/autoload.php was not found.
INFO - 2024-04-28 18:33:59 --> Config Class Initialized
INFO - 2024-04-28 18:33:59 --> Hooks Class Initialized
DEBUG - 2024-04-28 18:33:59 --> UTF-8 Support Enabled
INFO - 2024-04-28 18:33:59 --> Utf8 Class Initialized
INFO - 2024-04-28 18:33:59 --> URI Class Initialized
INFO - 2024-04-28 18:33:59 --> Router Class Initialized
INFO - 2024-04-28 18:33:59 --> Output Class Initialized
INFO - 2024-04-28 18:33:59 --> Security Class Initialized
DEBUG - 2024-04-28 18:33:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-04-28 18:33:59 --> Input Class Initialized
INFO - 2024-04-28 18:33:59 --> Language Class Initialized
INFO - 2024-04-28 18:33:59 --> Loader Class Initialized
INFO - 2024-04-28 18:33:59 --> Helper loaded: url_helper
INFO - 2024-04-28 18:33:59 --> Helper loaded: file_helper
INFO - 2024-04-28 18:33:59 --> Helper loaded: html_helper
INFO - 2024-04-28 18:33:59 --> Helper loaded: text_helper
INFO - 2024-04-28 18:33:59 --> Helper loaded: form_helper
INFO - 2024-04-28 18:33:59 --> Helper loaded: lang_helper
INFO - 2024-04-28 18:33:59 --> Helper loaded: security_helper
INFO - 2024-04-28 18:33:59 --> Helper loaded: cookie_helper
INFO - 2024-04-28 18:33:59 --> Database Driver Class Initialized
INFO - 2024-04-28 18:33:59 --> Session: Class initialized using 'files' driver.
INFO - 2024-04-28 18:33:59 --> Parser Class Initialized
INFO - 2024-04-28 18:33:59 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-04-28 18:33:59 --> Pagination Class Initialized
INFO - 2024-04-28 18:33:59 --> Form Validation Class Initialized
INFO - 2024-04-28 18:33:59 --> Controller Class Initialized
DEBUG - 2024-04-28 18:33:59 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-04-28 18:33:59 --> Session class already loaded. Second attempt ignored.
INFO - 2024-04-28 18:33:59 --> Model Class Initialized
DEBUG - 2024-04-28 18:33:59 --> Lpayments class already loaded. Second attempt ignored.
INFO - 2024-04-28 18:33:59 --> Model Class Initialized
INFO - 2024-04-28 18:33:59 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\payments/payment.php
DEBUG - 2024-04-28 18:33:59 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-04-28 18:33:59 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\include/top_menu.php
INFO - 2024-04-28 18:33:59 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\include/admin_loggedin_info.php
INFO - 2024-04-28 18:33:59 --> Model Class Initialized
INFO - 2024-04-28 18:33:59 --> Model Class Initialized
INFO - 2024-04-28 18:33:59 --> Model Class Initialized
INFO - 2024-04-28 18:34:01 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\include/admin_header.php
INFO - 2024-04-28 18:34:01 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\include/admin_footer.php
INFO - 2024-04-28 18:34:01 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\admin_html_template.php
INFO - 2024-04-28 18:34:01 --> Final output sent to browser
DEBUG - 2024-04-28 18:34:01 --> Total execution time: 2.3187
ERROR - 2024-04-28 18:34:02 --> $config['composer_autoload'] is set to TRUE but E:\xampp\htdocs\maurnaturo\application\vendor/autoload.php was not found.
INFO - 2024-04-28 18:34:02 --> Config Class Initialized
INFO - 2024-04-28 18:34:02 --> Hooks Class Initialized
DEBUG - 2024-04-28 18:34:02 --> UTF-8 Support Enabled
INFO - 2024-04-28 18:34:02 --> Utf8 Class Initialized
INFO - 2024-04-28 18:34:02 --> URI Class Initialized
INFO - 2024-04-28 18:34:02 --> Router Class Initialized
INFO - 2024-04-28 18:34:02 --> Output Class Initialized
INFO - 2024-04-28 18:34:02 --> Security Class Initialized
DEBUG - 2024-04-28 18:34:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-04-28 18:34:02 --> Input Class Initialized
INFO - 2024-04-28 18:34:02 --> Language Class Initialized
INFO - 2024-04-28 18:34:02 --> Loader Class Initialized
INFO - 2024-04-28 18:34:02 --> Helper loaded: url_helper
INFO - 2024-04-28 18:34:02 --> Helper loaded: file_helper
INFO - 2024-04-28 18:34:02 --> Helper loaded: html_helper
INFO - 2024-04-28 18:34:02 --> Helper loaded: text_helper
INFO - 2024-04-28 18:34:02 --> Helper loaded: form_helper
INFO - 2024-04-28 18:34:02 --> Helper loaded: lang_helper
INFO - 2024-04-28 18:34:02 --> Helper loaded: security_helper
INFO - 2024-04-28 18:34:02 --> Helper loaded: cookie_helper
INFO - 2024-04-28 18:34:02 --> Database Driver Class Initialized
INFO - 2024-04-28 18:34:02 --> Session: Class initialized using 'files' driver.
INFO - 2024-04-28 18:34:02 --> Parser Class Initialized
INFO - 2024-04-28 18:34:02 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-04-28 18:34:02 --> Pagination Class Initialized
INFO - 2024-04-28 18:34:02 --> Form Validation Class Initialized
INFO - 2024-04-28 18:34:02 --> Controller Class Initialized
DEBUG - 2024-04-28 18:34:02 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-04-28 18:34:02 --> Session class already loaded. Second attempt ignored.
INFO - 2024-04-28 18:34:02 --> Model Class Initialized
INFO - 2024-04-28 18:34:02 --> Final output sent to browser
DEBUG - 2024-04-28 18:34:02 --> Total execution time: 0.1196
ERROR - 2024-04-28 18:35:30 --> $config['composer_autoload'] is set to TRUE but E:\xampp\htdocs\maurnaturo\application\vendor/autoload.php was not found.
INFO - 2024-04-28 18:35:30 --> Config Class Initialized
INFO - 2024-04-28 18:35:30 --> Hooks Class Initialized
DEBUG - 2024-04-28 18:35:30 --> UTF-8 Support Enabled
INFO - 2024-04-28 18:35:30 --> Utf8 Class Initialized
INFO - 2024-04-28 18:35:30 --> URI Class Initialized
INFO - 2024-04-28 18:35:30 --> Router Class Initialized
INFO - 2024-04-28 18:35:30 --> Output Class Initialized
INFO - 2024-04-28 18:35:30 --> Security Class Initialized
DEBUG - 2024-04-28 18:35:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-04-28 18:35:30 --> Input Class Initialized
INFO - 2024-04-28 18:35:30 --> Language Class Initialized
INFO - 2024-04-28 18:35:30 --> Loader Class Initialized
INFO - 2024-04-28 18:35:30 --> Helper loaded: url_helper
INFO - 2024-04-28 18:35:30 --> Helper loaded: file_helper
INFO - 2024-04-28 18:35:30 --> Helper loaded: html_helper
INFO - 2024-04-28 18:35:30 --> Helper loaded: text_helper
INFO - 2024-04-28 18:35:30 --> Helper loaded: form_helper
INFO - 2024-04-28 18:35:30 --> Helper loaded: lang_helper
INFO - 2024-04-28 18:35:30 --> Helper loaded: security_helper
INFO - 2024-04-28 18:35:30 --> Helper loaded: cookie_helper
INFO - 2024-04-28 18:35:30 --> Database Driver Class Initialized
INFO - 2024-04-28 18:35:30 --> Session: Class initialized using 'files' driver.
INFO - 2024-04-28 18:35:30 --> Parser Class Initialized
INFO - 2024-04-28 18:35:30 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-04-28 18:35:30 --> Pagination Class Initialized
INFO - 2024-04-28 18:35:30 --> Form Validation Class Initialized
INFO - 2024-04-28 18:35:30 --> Controller Class Initialized
DEBUG - 2024-04-28 18:35:30 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-04-28 18:35:30 --> Session class already loaded. Second attempt ignored.
INFO - 2024-04-28 18:35:30 --> Model Class Initialized
DEBUG - 2024-04-28 18:35:30 --> Lpayments class already loaded. Second attempt ignored.
INFO - 2024-04-28 18:35:30 --> Model Class Initialized
INFO - 2024-04-28 18:35:30 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\payments/payment.php
DEBUG - 2024-04-28 18:35:30 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-04-28 18:35:30 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\include/top_menu.php
INFO - 2024-04-28 18:35:30 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\include/admin_loggedin_info.php
INFO - 2024-04-28 18:35:30 --> Model Class Initialized
INFO - 2024-04-28 18:35:31 --> Model Class Initialized
INFO - 2024-04-28 18:35:31 --> Model Class Initialized
INFO - 2024-04-28 18:35:32 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\include/admin_header.php
INFO - 2024-04-28 18:35:32 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\include/admin_footer.php
INFO - 2024-04-28 18:35:32 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\admin_html_template.php
INFO - 2024-04-28 18:35:32 --> Final output sent to browser
DEBUG - 2024-04-28 18:35:32 --> Total execution time: 1.4752
ERROR - 2024-04-28 18:35:32 --> $config['composer_autoload'] is set to TRUE but E:\xampp\htdocs\maurnaturo\application\vendor/autoload.php was not found.
INFO - 2024-04-28 18:35:32 --> Config Class Initialized
INFO - 2024-04-28 18:35:32 --> Hooks Class Initialized
DEBUG - 2024-04-28 18:35:32 --> UTF-8 Support Enabled
INFO - 2024-04-28 18:35:32 --> Utf8 Class Initialized
INFO - 2024-04-28 18:35:32 --> URI Class Initialized
INFO - 2024-04-28 18:35:32 --> Router Class Initialized
INFO - 2024-04-28 18:35:32 --> Output Class Initialized
INFO - 2024-04-28 18:35:32 --> Security Class Initialized
DEBUG - 2024-04-28 18:35:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-04-28 18:35:32 --> Input Class Initialized
INFO - 2024-04-28 18:35:32 --> Language Class Initialized
INFO - 2024-04-28 18:35:32 --> Loader Class Initialized
INFO - 2024-04-28 18:35:32 --> Helper loaded: url_helper
INFO - 2024-04-28 18:35:32 --> Helper loaded: file_helper
INFO - 2024-04-28 18:35:32 --> Helper loaded: html_helper
INFO - 2024-04-28 18:35:32 --> Helper loaded: text_helper
INFO - 2024-04-28 18:35:32 --> Helper loaded: form_helper
INFO - 2024-04-28 18:35:32 --> Helper loaded: lang_helper
INFO - 2024-04-28 18:35:32 --> Helper loaded: security_helper
INFO - 2024-04-28 18:35:32 --> Helper loaded: cookie_helper
INFO - 2024-04-28 18:35:32 --> Database Driver Class Initialized
INFO - 2024-04-28 18:35:32 --> Session: Class initialized using 'files' driver.
INFO - 2024-04-28 18:35:32 --> Parser Class Initialized
INFO - 2024-04-28 18:35:32 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-04-28 18:35:32 --> Pagination Class Initialized
INFO - 2024-04-28 18:35:32 --> Form Validation Class Initialized
INFO - 2024-04-28 18:35:32 --> Controller Class Initialized
DEBUG - 2024-04-28 18:35:32 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-04-28 18:35:32 --> Session class already loaded. Second attempt ignored.
INFO - 2024-04-28 18:35:32 --> Model Class Initialized
INFO - 2024-04-28 18:35:33 --> Final output sent to browser
DEBUG - 2024-04-28 18:35:33 --> Total execution time: 0.1378
ERROR - 2024-04-28 18:41:19 --> $config['composer_autoload'] is set to TRUE but E:\xampp\htdocs\maurnaturo\application\vendor/autoload.php was not found.
INFO - 2024-04-28 18:41:19 --> Config Class Initialized
INFO - 2024-04-28 18:41:19 --> Hooks Class Initialized
DEBUG - 2024-04-28 18:41:19 --> UTF-8 Support Enabled
INFO - 2024-04-28 18:41:19 --> Utf8 Class Initialized
INFO - 2024-04-28 18:41:19 --> URI Class Initialized
INFO - 2024-04-28 18:41:19 --> Router Class Initialized
INFO - 2024-04-28 18:41:19 --> Output Class Initialized
INFO - 2024-04-28 18:41:19 --> Security Class Initialized
DEBUG - 2024-04-28 18:41:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-04-28 18:41:19 --> Input Class Initialized
INFO - 2024-04-28 18:41:19 --> Language Class Initialized
INFO - 2024-04-28 18:41:19 --> Loader Class Initialized
INFO - 2024-04-28 18:41:19 --> Helper loaded: url_helper
INFO - 2024-04-28 18:41:19 --> Helper loaded: file_helper
INFO - 2024-04-28 18:41:19 --> Helper loaded: html_helper
INFO - 2024-04-28 18:41:19 --> Helper loaded: text_helper
INFO - 2024-04-28 18:41:19 --> Helper loaded: form_helper
INFO - 2024-04-28 18:41:19 --> Helper loaded: lang_helper
INFO - 2024-04-28 18:41:19 --> Helper loaded: security_helper
INFO - 2024-04-28 18:41:19 --> Helper loaded: cookie_helper
INFO - 2024-04-28 18:41:19 --> Database Driver Class Initialized
INFO - 2024-04-28 18:41:19 --> Session: Class initialized using 'files' driver.
INFO - 2024-04-28 18:41:19 --> Parser Class Initialized
INFO - 2024-04-28 18:41:19 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-04-28 18:41:19 --> Pagination Class Initialized
INFO - 2024-04-28 18:41:19 --> Form Validation Class Initialized
INFO - 2024-04-28 18:41:19 --> Controller Class Initialized
DEBUG - 2024-04-28 18:41:19 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-04-28 18:41:19 --> Session class already loaded. Second attempt ignored.
INFO - 2024-04-28 18:41:19 --> Model Class Initialized
INFO - 2024-04-28 18:41:19 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\permission/role_view_form.php
DEBUG - 2024-04-28 18:41:19 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-04-28 18:41:19 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\include/top_menu.php
INFO - 2024-04-28 18:41:19 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\include/admin_loggedin_info.php
INFO - 2024-04-28 18:41:19 --> Model Class Initialized
INFO - 2024-04-28 18:41:19 --> Model Class Initialized
INFO - 2024-04-28 18:41:19 --> Model Class Initialized
INFO - 2024-04-28 18:41:19 --> Model Class Initialized
INFO - 2024-04-28 18:41:21 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\include/admin_header.php
INFO - 2024-04-28 18:41:21 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\include/admin_footer.php
INFO - 2024-04-28 18:41:21 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\admin_html_template.php
INFO - 2024-04-28 18:41:21 --> Final output sent to browser
DEBUG - 2024-04-28 18:41:21 --> Total execution time: 1.8995
ERROR - 2024-04-28 18:41:23 --> $config['composer_autoload'] is set to TRUE but E:\xampp\htdocs\maurnaturo\application\vendor/autoload.php was not found.
INFO - 2024-04-28 18:41:23 --> Config Class Initialized
INFO - 2024-04-28 18:41:23 --> Hooks Class Initialized
DEBUG - 2024-04-28 18:41:23 --> UTF-8 Support Enabled
INFO - 2024-04-28 18:41:23 --> Utf8 Class Initialized
INFO - 2024-04-28 18:41:23 --> URI Class Initialized
INFO - 2024-04-28 18:41:23 --> Router Class Initialized
INFO - 2024-04-28 18:41:23 --> Output Class Initialized
INFO - 2024-04-28 18:41:23 --> Security Class Initialized
DEBUG - 2024-04-28 18:41:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-04-28 18:41:24 --> Input Class Initialized
INFO - 2024-04-28 18:41:24 --> Language Class Initialized
INFO - 2024-04-28 18:41:24 --> Loader Class Initialized
INFO - 2024-04-28 18:41:24 --> Helper loaded: url_helper
INFO - 2024-04-28 18:41:24 --> Helper loaded: file_helper
INFO - 2024-04-28 18:41:24 --> Helper loaded: html_helper
INFO - 2024-04-28 18:41:24 --> Helper loaded: text_helper
INFO - 2024-04-28 18:41:24 --> Helper loaded: form_helper
INFO - 2024-04-28 18:41:24 --> Helper loaded: lang_helper
INFO - 2024-04-28 18:41:24 --> Helper loaded: security_helper
INFO - 2024-04-28 18:41:24 --> Helper loaded: cookie_helper
INFO - 2024-04-28 18:41:24 --> Database Driver Class Initialized
INFO - 2024-04-28 18:41:24 --> Session: Class initialized using 'files' driver.
INFO - 2024-04-28 18:41:24 --> Parser Class Initialized
INFO - 2024-04-28 18:41:24 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-04-28 18:41:24 --> Pagination Class Initialized
INFO - 2024-04-28 18:41:24 --> Form Validation Class Initialized
INFO - 2024-04-28 18:41:24 --> Controller Class Initialized
DEBUG - 2024-04-28 18:41:24 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-04-28 18:41:24 --> Session class already loaded. Second attempt ignored.
INFO - 2024-04-28 18:41:24 --> Model Class Initialized
INFO - 2024-04-28 18:41:25 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\permission/editroleform.php
DEBUG - 2024-04-28 18:41:25 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-04-28 18:41:25 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\include/top_menu.php
INFO - 2024-04-28 18:41:25 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\include/admin_loggedin_info.php
INFO - 2024-04-28 18:41:25 --> Model Class Initialized
INFO - 2024-04-28 18:41:25 --> Model Class Initialized
INFO - 2024-04-28 18:41:25 --> Model Class Initialized
INFO - 2024-04-28 18:41:25 --> Model Class Initialized
INFO - 2024-04-28 18:41:26 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\include/admin_header.php
INFO - 2024-04-28 18:41:26 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\include/admin_footer.php
INFO - 2024-04-28 18:41:26 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\admin_html_template.php
INFO - 2024-04-28 18:41:26 --> Final output sent to browser
DEBUG - 2024-04-28 18:41:26 --> Total execution time: 2.5374
ERROR - 2024-04-28 18:41:37 --> $config['composer_autoload'] is set to TRUE but E:\xampp\htdocs\maurnaturo\application\vendor/autoload.php was not found.
INFO - 2024-04-28 18:41:37 --> Config Class Initialized
INFO - 2024-04-28 18:41:37 --> Hooks Class Initialized
DEBUG - 2024-04-28 18:41:37 --> UTF-8 Support Enabled
INFO - 2024-04-28 18:41:37 --> Utf8 Class Initialized
INFO - 2024-04-28 18:41:37 --> URI Class Initialized
INFO - 2024-04-28 18:41:37 --> Router Class Initialized
INFO - 2024-04-28 18:41:37 --> Output Class Initialized
INFO - 2024-04-28 18:41:37 --> Security Class Initialized
DEBUG - 2024-04-28 18:41:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-04-28 18:41:37 --> Input Class Initialized
INFO - 2024-04-28 18:41:37 --> Language Class Initialized
INFO - 2024-04-28 18:41:37 --> Loader Class Initialized
INFO - 2024-04-28 18:41:37 --> Helper loaded: url_helper
INFO - 2024-04-28 18:41:37 --> Helper loaded: file_helper
INFO - 2024-04-28 18:41:37 --> Helper loaded: html_helper
INFO - 2024-04-28 18:41:37 --> Helper loaded: text_helper
INFO - 2024-04-28 18:41:37 --> Helper loaded: form_helper
INFO - 2024-04-28 18:41:37 --> Helper loaded: lang_helper
INFO - 2024-04-28 18:41:37 --> Helper loaded: security_helper
INFO - 2024-04-28 18:41:37 --> Helper loaded: cookie_helper
INFO - 2024-04-28 18:41:37 --> Database Driver Class Initialized
INFO - 2024-04-28 18:41:37 --> Session: Class initialized using 'files' driver.
INFO - 2024-04-28 18:41:37 --> Parser Class Initialized
INFO - 2024-04-28 18:41:37 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-04-28 18:41:37 --> Pagination Class Initialized
INFO - 2024-04-28 18:41:37 --> Form Validation Class Initialized
INFO - 2024-04-28 18:41:37 --> Controller Class Initialized
DEBUG - 2024-04-28 18:41:37 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-04-28 18:41:37 --> Session class already loaded. Second attempt ignored.
INFO - 2024-04-28 18:41:37 --> Model Class Initialized
ERROR - 2024-04-28 18:41:37 --> $config['composer_autoload'] is set to TRUE but E:\xampp\htdocs\maurnaturo\application\vendor/autoload.php was not found.
INFO - 2024-04-28 18:41:37 --> Config Class Initialized
INFO - 2024-04-28 18:41:37 --> Hooks Class Initialized
DEBUG - 2024-04-28 18:41:37 --> UTF-8 Support Enabled
INFO - 2024-04-28 18:41:37 --> Utf8 Class Initialized
INFO - 2024-04-28 18:41:37 --> URI Class Initialized
INFO - 2024-04-28 18:41:37 --> Router Class Initialized
INFO - 2024-04-28 18:41:37 --> Output Class Initialized
INFO - 2024-04-28 18:41:37 --> Security Class Initialized
DEBUG - 2024-04-28 18:41:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-04-28 18:41:37 --> Input Class Initialized
INFO - 2024-04-28 18:41:37 --> Language Class Initialized
INFO - 2024-04-28 18:41:37 --> Loader Class Initialized
INFO - 2024-04-28 18:41:37 --> Helper loaded: url_helper
INFO - 2024-04-28 18:41:37 --> Helper loaded: file_helper
INFO - 2024-04-28 18:41:37 --> Helper loaded: html_helper
INFO - 2024-04-28 18:41:37 --> Helper loaded: text_helper
INFO - 2024-04-28 18:41:37 --> Helper loaded: form_helper
INFO - 2024-04-28 18:41:37 --> Helper loaded: lang_helper
INFO - 2024-04-28 18:41:37 --> Helper loaded: security_helper
INFO - 2024-04-28 18:41:37 --> Helper loaded: cookie_helper
INFO - 2024-04-28 18:41:37 --> Database Driver Class Initialized
INFO - 2024-04-28 18:41:37 --> Session: Class initialized using 'files' driver.
INFO - 2024-04-28 18:41:37 --> Parser Class Initialized
INFO - 2024-04-28 18:41:37 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-04-28 18:41:37 --> Pagination Class Initialized
INFO - 2024-04-28 18:41:37 --> Form Validation Class Initialized
INFO - 2024-04-28 18:41:37 --> Controller Class Initialized
DEBUG - 2024-04-28 18:41:37 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-04-28 18:41:37 --> Session class already loaded. Second attempt ignored.
INFO - 2024-04-28 18:41:37 --> Model Class Initialized
INFO - 2024-04-28 18:41:37 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\permission/role_view_form.php
DEBUG - 2024-04-28 18:41:37 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-04-28 18:41:37 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\include/top_menu.php
INFO - 2024-04-28 18:41:37 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\include/admin_loggedin_info.php
INFO - 2024-04-28 18:41:37 --> Model Class Initialized
INFO - 2024-04-28 18:41:37 --> Model Class Initialized
INFO - 2024-04-28 18:41:37 --> Model Class Initialized
INFO - 2024-04-28 18:41:37 --> Model Class Initialized
INFO - 2024-04-28 18:41:39 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\include/admin_header.php
INFO - 2024-04-28 18:41:39 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\include/admin_footer.php
INFO - 2024-04-28 18:41:39 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\admin_html_template.php
INFO - 2024-04-28 18:41:39 --> Final output sent to browser
DEBUG - 2024-04-28 18:41:39 --> Total execution time: 1.4418
ERROR - 2024-04-28 18:41:42 --> $config['composer_autoload'] is set to TRUE but E:\xampp\htdocs\maurnaturo\application\vendor/autoload.php was not found.
INFO - 2024-04-28 18:41:42 --> Config Class Initialized
INFO - 2024-04-28 18:41:42 --> Hooks Class Initialized
DEBUG - 2024-04-28 18:41:42 --> UTF-8 Support Enabled
INFO - 2024-04-28 18:41:42 --> Utf8 Class Initialized
INFO - 2024-04-28 18:41:42 --> URI Class Initialized
INFO - 2024-04-28 18:41:42 --> Router Class Initialized
INFO - 2024-04-28 18:41:42 --> Output Class Initialized
INFO - 2024-04-28 18:41:42 --> Security Class Initialized
DEBUG - 2024-04-28 18:41:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-04-28 18:41:42 --> Input Class Initialized
INFO - 2024-04-28 18:41:42 --> Language Class Initialized
INFO - 2024-04-28 18:41:42 --> Loader Class Initialized
INFO - 2024-04-28 18:41:42 --> Helper loaded: url_helper
INFO - 2024-04-28 18:41:42 --> Helper loaded: file_helper
INFO - 2024-04-28 18:41:42 --> Helper loaded: html_helper
INFO - 2024-04-28 18:41:42 --> Helper loaded: text_helper
INFO - 2024-04-28 18:41:42 --> Helper loaded: form_helper
INFO - 2024-04-28 18:41:42 --> Helper loaded: lang_helper
INFO - 2024-04-28 18:41:42 --> Helper loaded: security_helper
INFO - 2024-04-28 18:41:42 --> Helper loaded: cookie_helper
INFO - 2024-04-28 18:41:42 --> Database Driver Class Initialized
INFO - 2024-04-28 18:41:42 --> Session: Class initialized using 'files' driver.
INFO - 2024-04-28 18:41:42 --> Parser Class Initialized
INFO - 2024-04-28 18:41:42 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-04-28 18:41:42 --> Pagination Class Initialized
INFO - 2024-04-28 18:41:42 --> Form Validation Class Initialized
INFO - 2024-04-28 18:41:42 --> Controller Class Initialized
DEBUG - 2024-04-28 18:41:42 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-04-28 18:41:42 --> Session class already loaded. Second attempt ignored.
INFO - 2024-04-28 18:41:42 --> Model Class Initialized
DEBUG - 2024-04-28 18:41:42 --> Lpermission class already loaded. Second attempt ignored.
INFO - 2024-04-28 18:41:42 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\permission/assign_form.php
DEBUG - 2024-04-28 18:41:42 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-04-28 18:41:42 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\include/top_menu.php
INFO - 2024-04-28 18:41:42 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\include/admin_loggedin_info.php
INFO - 2024-04-28 18:41:42 --> Model Class Initialized
INFO - 2024-04-28 18:41:42 --> Model Class Initialized
INFO - 2024-04-28 18:41:42 --> Model Class Initialized
INFO - 2024-04-28 18:41:42 --> Model Class Initialized
INFO - 2024-04-28 18:41:44 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\include/admin_header.php
INFO - 2024-04-28 18:41:44 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\include/admin_footer.php
INFO - 2024-04-28 18:41:44 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\admin_html_template.php
INFO - 2024-04-28 18:41:44 --> Final output sent to browser
DEBUG - 2024-04-28 18:41:44 --> Total execution time: 2.5340
ERROR - 2024-04-28 18:42:00 --> $config['composer_autoload'] is set to TRUE but E:\xampp\htdocs\maurnaturo\application\vendor/autoload.php was not found.
INFO - 2024-04-28 18:42:00 --> Config Class Initialized
INFO - 2024-04-28 18:42:00 --> Hooks Class Initialized
DEBUG - 2024-04-28 18:42:00 --> UTF-8 Support Enabled
INFO - 2024-04-28 18:42:00 --> Utf8 Class Initialized
INFO - 2024-04-28 18:42:00 --> URI Class Initialized
INFO - 2024-04-28 18:42:00 --> Router Class Initialized
INFO - 2024-04-28 18:42:00 --> Output Class Initialized
INFO - 2024-04-28 18:42:00 --> Security Class Initialized
DEBUG - 2024-04-28 18:42:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-04-28 18:42:00 --> Input Class Initialized
INFO - 2024-04-28 18:42:00 --> Language Class Initialized
INFO - 2024-04-28 18:42:00 --> Loader Class Initialized
INFO - 2024-04-28 18:42:00 --> Helper loaded: url_helper
INFO - 2024-04-28 18:42:00 --> Helper loaded: file_helper
INFO - 2024-04-28 18:42:00 --> Helper loaded: html_helper
INFO - 2024-04-28 18:42:00 --> Helper loaded: text_helper
INFO - 2024-04-28 18:42:00 --> Helper loaded: form_helper
INFO - 2024-04-28 18:42:00 --> Helper loaded: lang_helper
INFO - 2024-04-28 18:42:00 --> Helper loaded: security_helper
INFO - 2024-04-28 18:42:00 --> Helper loaded: cookie_helper
INFO - 2024-04-28 18:42:00 --> Database Driver Class Initialized
INFO - 2024-04-28 18:42:00 --> Session: Class initialized using 'files' driver.
INFO - 2024-04-28 18:42:00 --> Parser Class Initialized
INFO - 2024-04-28 18:42:00 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-04-28 18:42:00 --> Pagination Class Initialized
INFO - 2024-04-28 18:42:00 --> Form Validation Class Initialized
INFO - 2024-04-28 18:42:00 --> Controller Class Initialized
DEBUG - 2024-04-28 18:42:00 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-04-28 18:42:00 --> Session class already loaded. Second attempt ignored.
INFO - 2024-04-28 18:42:00 --> Model Class Initialized
INFO - 2024-04-28 18:42:00 --> Final output sent to browser
DEBUG - 2024-04-28 18:42:00 --> Total execution time: 0.0627
ERROR - 2024-04-28 18:42:03 --> $config['composer_autoload'] is set to TRUE but E:\xampp\htdocs\maurnaturo\application\vendor/autoload.php was not found.
INFO - 2024-04-28 18:42:03 --> Config Class Initialized
INFO - 2024-04-28 18:42:03 --> Hooks Class Initialized
DEBUG - 2024-04-28 18:42:03 --> UTF-8 Support Enabled
INFO - 2024-04-28 18:42:03 --> Utf8 Class Initialized
INFO - 2024-04-28 18:42:03 --> URI Class Initialized
INFO - 2024-04-28 18:42:03 --> Router Class Initialized
INFO - 2024-04-28 18:42:03 --> Output Class Initialized
INFO - 2024-04-28 18:42:03 --> Security Class Initialized
DEBUG - 2024-04-28 18:42:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-04-28 18:42:03 --> Input Class Initialized
INFO - 2024-04-28 18:42:03 --> Language Class Initialized
INFO - 2024-04-28 18:42:03 --> Loader Class Initialized
INFO - 2024-04-28 18:42:03 --> Helper loaded: url_helper
INFO - 2024-04-28 18:42:03 --> Helper loaded: file_helper
INFO - 2024-04-28 18:42:03 --> Helper loaded: html_helper
INFO - 2024-04-28 18:42:03 --> Helper loaded: text_helper
INFO - 2024-04-28 18:42:03 --> Helper loaded: form_helper
INFO - 2024-04-28 18:42:03 --> Helper loaded: lang_helper
INFO - 2024-04-28 18:42:03 --> Helper loaded: security_helper
INFO - 2024-04-28 18:42:03 --> Helper loaded: cookie_helper
INFO - 2024-04-28 18:42:03 --> Database Driver Class Initialized
INFO - 2024-04-28 18:42:03 --> Session: Class initialized using 'files' driver.
INFO - 2024-04-28 18:42:03 --> Parser Class Initialized
INFO - 2024-04-28 18:42:03 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-04-28 18:42:03 --> Pagination Class Initialized
INFO - 2024-04-28 18:42:03 --> Form Validation Class Initialized
INFO - 2024-04-28 18:42:03 --> Controller Class Initialized
DEBUG - 2024-04-28 18:42:03 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-04-28 18:42:03 --> Session class already loaded. Second attempt ignored.
INFO - 2024-04-28 18:42:03 --> Model Class Initialized
INFO - 2024-04-28 18:42:03 --> Language file loaded: language/english/form_validation_lang.php
ERROR - 2024-04-28 18:42:03 --> $config['composer_autoload'] is set to TRUE but E:\xampp\htdocs\maurnaturo\application\vendor/autoload.php was not found.
INFO - 2024-04-28 18:42:03 --> Config Class Initialized
INFO - 2024-04-28 18:42:03 --> Hooks Class Initialized
DEBUG - 2024-04-28 18:42:03 --> UTF-8 Support Enabled
INFO - 2024-04-28 18:42:03 --> Utf8 Class Initialized
INFO - 2024-04-28 18:42:03 --> URI Class Initialized
INFO - 2024-04-28 18:42:03 --> Router Class Initialized
INFO - 2024-04-28 18:42:03 --> Output Class Initialized
INFO - 2024-04-28 18:42:03 --> Security Class Initialized
DEBUG - 2024-04-28 18:42:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-04-28 18:42:03 --> Input Class Initialized
INFO - 2024-04-28 18:42:03 --> Language Class Initialized
INFO - 2024-04-28 18:42:03 --> Loader Class Initialized
INFO - 2024-04-28 18:42:03 --> Helper loaded: url_helper
INFO - 2024-04-28 18:42:03 --> Helper loaded: file_helper
INFO - 2024-04-28 18:42:03 --> Helper loaded: html_helper
INFO - 2024-04-28 18:42:03 --> Helper loaded: text_helper
INFO - 2024-04-28 18:42:03 --> Helper loaded: form_helper
INFO - 2024-04-28 18:42:03 --> Helper loaded: lang_helper
INFO - 2024-04-28 18:42:03 --> Helper loaded: security_helper
INFO - 2024-04-28 18:42:03 --> Helper loaded: cookie_helper
INFO - 2024-04-28 18:42:03 --> Database Driver Class Initialized
INFO - 2024-04-28 18:42:03 --> Session: Class initialized using 'files' driver.
INFO - 2024-04-28 18:42:03 --> Parser Class Initialized
INFO - 2024-04-28 18:42:03 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-04-28 18:42:03 --> Pagination Class Initialized
INFO - 2024-04-28 18:42:03 --> Form Validation Class Initialized
INFO - 2024-04-28 18:42:03 --> Controller Class Initialized
DEBUG - 2024-04-28 18:42:03 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-04-28 18:42:03 --> Session class already loaded. Second attempt ignored.
INFO - 2024-04-28 18:42:03 --> Model Class Initialized
DEBUG - 2024-04-28 18:42:03 --> Lpermission class already loaded. Second attempt ignored.
INFO - 2024-04-28 18:42:03 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\permission/assign_form.php
DEBUG - 2024-04-28 18:42:03 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-04-28 18:42:03 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\include/top_menu.php
INFO - 2024-04-28 18:42:03 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\include/admin_loggedin_info.php
INFO - 2024-04-28 18:42:03 --> Model Class Initialized
INFO - 2024-04-28 18:42:03 --> Model Class Initialized
INFO - 2024-04-28 18:42:03 --> Model Class Initialized
INFO - 2024-04-28 18:42:03 --> Model Class Initialized
INFO - 2024-04-28 18:42:04 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\include/admin_header.php
INFO - 2024-04-28 18:42:04 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\include/admin_footer.php
INFO - 2024-04-28 18:42:04 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\admin_html_template.php
INFO - 2024-04-28 18:42:04 --> Final output sent to browser
DEBUG - 2024-04-28 18:42:04 --> Total execution time: 1.3860
ERROR - 2024-04-28 18:42:07 --> $config['composer_autoload'] is set to TRUE but E:\xampp\htdocs\maurnaturo\application\vendor/autoload.php was not found.
INFO - 2024-04-28 18:42:07 --> Config Class Initialized
INFO - 2024-04-28 18:42:07 --> Hooks Class Initialized
DEBUG - 2024-04-28 18:42:07 --> UTF-8 Support Enabled
INFO - 2024-04-28 18:42:07 --> Utf8 Class Initialized
INFO - 2024-04-28 18:42:07 --> URI Class Initialized
INFO - 2024-04-28 18:42:07 --> Router Class Initialized
INFO - 2024-04-28 18:42:07 --> Output Class Initialized
INFO - 2024-04-28 18:42:07 --> Security Class Initialized
DEBUG - 2024-04-28 18:42:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-04-28 18:42:07 --> Input Class Initialized
INFO - 2024-04-28 18:42:07 --> Language Class Initialized
INFO - 2024-04-28 18:42:07 --> Loader Class Initialized
INFO - 2024-04-28 18:42:07 --> Helper loaded: url_helper
INFO - 2024-04-28 18:42:07 --> Helper loaded: file_helper
INFO - 2024-04-28 18:42:07 --> Helper loaded: html_helper
INFO - 2024-04-28 18:42:07 --> Helper loaded: text_helper
INFO - 2024-04-28 18:42:07 --> Helper loaded: form_helper
INFO - 2024-04-28 18:42:07 --> Helper loaded: lang_helper
INFO - 2024-04-28 18:42:07 --> Helper loaded: security_helper
INFO - 2024-04-28 18:42:07 --> Helper loaded: cookie_helper
INFO - 2024-04-28 18:42:07 --> Database Driver Class Initialized
INFO - 2024-04-28 18:42:08 --> Session: Class initialized using 'files' driver.
INFO - 2024-04-28 18:42:08 --> Parser Class Initialized
INFO - 2024-04-28 18:42:08 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-04-28 18:42:08 --> Pagination Class Initialized
INFO - 2024-04-28 18:42:08 --> Form Validation Class Initialized
INFO - 2024-04-28 18:42:08 --> Controller Class Initialized
DEBUG - 2024-04-28 18:42:08 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-04-28 18:42:08 --> Session class already loaded. Second attempt ignored.
INFO - 2024-04-28 18:42:08 --> Model Class Initialized
INFO - 2024-04-28 18:42:08 --> Model Class Initialized
DEBUG - 2024-04-28 18:42:08 --> Lmr class already loaded. Second attempt ignored.
INFO - 2024-04-28 18:42:08 --> Model Class Initialized
INFO - 2024-04-28 18:42:08 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\mr/mr.php
DEBUG - 2024-04-28 18:42:08 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-04-28 18:42:08 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\include/top_menu.php
INFO - 2024-04-28 18:42:08 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\include/admin_loggedin_info.php
INFO - 2024-04-28 18:42:08 --> Model Class Initialized
INFO - 2024-04-28 18:42:08 --> Model Class Initialized
INFO - 2024-04-28 18:42:08 --> Model Class Initialized
INFO - 2024-04-28 18:42:09 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\include/admin_header.php
INFO - 2024-04-28 18:42:09 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\include/admin_footer.php
INFO - 2024-04-28 18:42:09 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\admin_html_template.php
INFO - 2024-04-28 18:42:09 --> Final output sent to browser
DEBUG - 2024-04-28 18:42:09 --> Total execution time: 1.5650
ERROR - 2024-04-28 18:42:09 --> $config['composer_autoload'] is set to TRUE but E:\xampp\htdocs\maurnaturo\application\vendor/autoload.php was not found.
INFO - 2024-04-28 18:42:09 --> Config Class Initialized
INFO - 2024-04-28 18:42:09 --> Hooks Class Initialized
DEBUG - 2024-04-28 18:42:09 --> UTF-8 Support Enabled
INFO - 2024-04-28 18:42:09 --> Utf8 Class Initialized
INFO - 2024-04-28 18:42:09 --> URI Class Initialized
INFO - 2024-04-28 18:42:09 --> Router Class Initialized
INFO - 2024-04-28 18:42:09 --> Output Class Initialized
INFO - 2024-04-28 18:42:09 --> Security Class Initialized
DEBUG - 2024-04-28 18:42:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-04-28 18:42:09 --> Input Class Initialized
INFO - 2024-04-28 18:42:09 --> Language Class Initialized
INFO - 2024-04-28 18:42:09 --> Loader Class Initialized
INFO - 2024-04-28 18:42:09 --> Helper loaded: url_helper
INFO - 2024-04-28 18:42:09 --> Helper loaded: file_helper
INFO - 2024-04-28 18:42:09 --> Helper loaded: html_helper
INFO - 2024-04-28 18:42:09 --> Helper loaded: text_helper
INFO - 2024-04-28 18:42:09 --> Helper loaded: form_helper
INFO - 2024-04-28 18:42:09 --> Helper loaded: lang_helper
INFO - 2024-04-28 18:42:09 --> Helper loaded: security_helper
INFO - 2024-04-28 18:42:09 --> Helper loaded: cookie_helper
INFO - 2024-04-28 18:42:09 --> Database Driver Class Initialized
INFO - 2024-04-28 18:42:09 --> Session: Class initialized using 'files' driver.
INFO - 2024-04-28 18:42:09 --> Parser Class Initialized
INFO - 2024-04-28 18:42:09 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-04-28 18:42:09 --> Pagination Class Initialized
INFO - 2024-04-28 18:42:10 --> Form Validation Class Initialized
INFO - 2024-04-28 18:42:10 --> Controller Class Initialized
DEBUG - 2024-04-28 18:42:10 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-04-28 18:42:10 --> Session class already loaded. Second attempt ignored.
INFO - 2024-04-28 18:42:10 --> Model Class Initialized
INFO - 2024-04-28 18:42:10 --> Model Class Initialized
INFO - 2024-04-28 18:42:10 --> Final output sent to browser
DEBUG - 2024-04-28 18:42:10 --> Total execution time: 0.2833
ERROR - 2024-04-28 18:42:13 --> $config['composer_autoload'] is set to TRUE but E:\xampp\htdocs\maurnaturo\application\vendor/autoload.php was not found.
INFO - 2024-04-28 18:42:13 --> Config Class Initialized
INFO - 2024-04-28 18:42:13 --> Hooks Class Initialized
DEBUG - 2024-04-28 18:42:13 --> UTF-8 Support Enabled
INFO - 2024-04-28 18:42:13 --> Utf8 Class Initialized
INFO - 2024-04-28 18:42:13 --> URI Class Initialized
INFO - 2024-04-28 18:42:13 --> Router Class Initialized
INFO - 2024-04-28 18:42:13 --> Output Class Initialized
INFO - 2024-04-28 18:42:13 --> Security Class Initialized
DEBUG - 2024-04-28 18:42:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-04-28 18:42:13 --> Input Class Initialized
INFO - 2024-04-28 18:42:13 --> Language Class Initialized
INFO - 2024-04-28 18:42:13 --> Loader Class Initialized
INFO - 2024-04-28 18:42:13 --> Helper loaded: url_helper
INFO - 2024-04-28 18:42:13 --> Helper loaded: file_helper
INFO - 2024-04-28 18:42:13 --> Helper loaded: html_helper
INFO - 2024-04-28 18:42:13 --> Helper loaded: text_helper
INFO - 2024-04-28 18:42:13 --> Helper loaded: form_helper
INFO - 2024-04-28 18:42:13 --> Helper loaded: lang_helper
INFO - 2024-04-28 18:42:13 --> Helper loaded: security_helper
INFO - 2024-04-28 18:42:13 --> Helper loaded: cookie_helper
INFO - 2024-04-28 18:42:13 --> Database Driver Class Initialized
INFO - 2024-04-28 18:42:13 --> Session: Class initialized using 'files' driver.
INFO - 2024-04-28 18:42:13 --> Parser Class Initialized
INFO - 2024-04-28 18:42:13 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-04-28 18:42:13 --> Pagination Class Initialized
INFO - 2024-04-28 18:42:13 --> Form Validation Class Initialized
INFO - 2024-04-28 18:42:13 --> Controller Class Initialized
DEBUG - 2024-04-28 18:42:13 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-04-28 18:42:13 --> Session class already loaded. Second attempt ignored.
INFO - 2024-04-28 18:42:13 --> Model Class Initialized
DEBUG - 2024-04-28 18:42:13 --> Lpayments class already loaded. Second attempt ignored.
INFO - 2024-04-28 18:42:13 --> Model Class Initialized
INFO - 2024-04-28 18:42:13 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\payments/payment.php
DEBUG - 2024-04-28 18:42:13 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-04-28 18:42:13 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\include/top_menu.php
INFO - 2024-04-28 18:42:13 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\include/admin_loggedin_info.php
INFO - 2024-04-28 18:42:13 --> Model Class Initialized
INFO - 2024-04-28 18:42:13 --> Model Class Initialized
INFO - 2024-04-28 18:42:13 --> Model Class Initialized
INFO - 2024-04-28 18:42:14 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\include/admin_header.php
INFO - 2024-04-28 18:42:14 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\include/admin_footer.php
INFO - 2024-04-28 18:42:14 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\admin_html_template.php
INFO - 2024-04-28 18:42:14 --> Final output sent to browser
DEBUG - 2024-04-28 18:42:14 --> Total execution time: 1.3055
ERROR - 2024-04-28 18:42:15 --> $config['composer_autoload'] is set to TRUE but E:\xampp\htdocs\maurnaturo\application\vendor/autoload.php was not found.
INFO - 2024-04-28 18:42:15 --> Config Class Initialized
INFO - 2024-04-28 18:42:15 --> Hooks Class Initialized
DEBUG - 2024-04-28 18:42:15 --> UTF-8 Support Enabled
INFO - 2024-04-28 18:42:15 --> Utf8 Class Initialized
INFO - 2024-04-28 18:42:15 --> URI Class Initialized
INFO - 2024-04-28 18:42:15 --> Router Class Initialized
INFO - 2024-04-28 18:42:15 --> Output Class Initialized
INFO - 2024-04-28 18:42:15 --> Security Class Initialized
DEBUG - 2024-04-28 18:42:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-04-28 18:42:15 --> Input Class Initialized
INFO - 2024-04-28 18:42:15 --> Language Class Initialized
INFO - 2024-04-28 18:42:15 --> Loader Class Initialized
INFO - 2024-04-28 18:42:15 --> Helper loaded: url_helper
INFO - 2024-04-28 18:42:15 --> Helper loaded: file_helper
INFO - 2024-04-28 18:42:15 --> Helper loaded: html_helper
INFO - 2024-04-28 18:42:15 --> Helper loaded: text_helper
INFO - 2024-04-28 18:42:15 --> Helper loaded: form_helper
INFO - 2024-04-28 18:42:15 --> Helper loaded: lang_helper
INFO - 2024-04-28 18:42:15 --> Helper loaded: security_helper
INFO - 2024-04-28 18:42:15 --> Helper loaded: cookie_helper
INFO - 2024-04-28 18:42:15 --> Database Driver Class Initialized
INFO - 2024-04-28 18:42:15 --> Session: Class initialized using 'files' driver.
INFO - 2024-04-28 18:42:15 --> Parser Class Initialized
INFO - 2024-04-28 18:42:15 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-04-28 18:42:15 --> Pagination Class Initialized
INFO - 2024-04-28 18:42:15 --> Form Validation Class Initialized
INFO - 2024-04-28 18:42:15 --> Controller Class Initialized
DEBUG - 2024-04-28 18:42:15 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-04-28 18:42:15 --> Session class already loaded. Second attempt ignored.
INFO - 2024-04-28 18:42:15 --> Model Class Initialized
INFO - 2024-04-28 18:42:15 --> Final output sent to browser
DEBUG - 2024-04-28 18:42:15 --> Total execution time: 0.1296
ERROR - 2024-04-28 18:42:18 --> $config['composer_autoload'] is set to TRUE but E:\xampp\htdocs\maurnaturo\application\vendor/autoload.php was not found.
INFO - 2024-04-28 18:42:18 --> Config Class Initialized
INFO - 2024-04-28 18:42:18 --> Hooks Class Initialized
DEBUG - 2024-04-28 18:42:18 --> UTF-8 Support Enabled
INFO - 2024-04-28 18:42:18 --> Utf8 Class Initialized
INFO - 2024-04-28 18:42:18 --> URI Class Initialized
INFO - 2024-04-28 18:42:18 --> Router Class Initialized
INFO - 2024-04-28 18:42:18 --> Output Class Initialized
INFO - 2024-04-28 18:42:18 --> Security Class Initialized
DEBUG - 2024-04-28 18:42:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-04-28 18:42:18 --> Input Class Initialized
INFO - 2024-04-28 18:42:18 --> Language Class Initialized
INFO - 2024-04-28 18:42:18 --> Loader Class Initialized
INFO - 2024-04-28 18:42:18 --> Helper loaded: url_helper
INFO - 2024-04-28 18:42:18 --> Helper loaded: file_helper
INFO - 2024-04-28 18:42:18 --> Helper loaded: html_helper
INFO - 2024-04-28 18:42:18 --> Helper loaded: text_helper
INFO - 2024-04-28 18:42:18 --> Helper loaded: form_helper
INFO - 2024-04-28 18:42:18 --> Helper loaded: lang_helper
INFO - 2024-04-28 18:42:18 --> Helper loaded: security_helper
INFO - 2024-04-28 18:42:18 --> Helper loaded: cookie_helper
INFO - 2024-04-28 18:42:18 --> Database Driver Class Initialized
INFO - 2024-04-28 18:42:18 --> Session: Class initialized using 'files' driver.
INFO - 2024-04-28 18:42:18 --> Parser Class Initialized
INFO - 2024-04-28 18:42:18 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-04-28 18:42:18 --> Pagination Class Initialized
INFO - 2024-04-28 18:42:18 --> Form Validation Class Initialized
INFO - 2024-04-28 18:42:18 --> Controller Class Initialized
INFO - 2024-04-28 18:42:18 --> Model Class Initialized
DEBUG - 2024-04-28 18:42:18 --> Session class already loaded. Second attempt ignored.
INFO - 2024-04-28 18:42:18 --> Final output sent to browser
DEBUG - 2024-04-28 18:42:18 --> Total execution time: 0.0743
ERROR - 2024-04-28 18:42:18 --> $config['composer_autoload'] is set to TRUE but E:\xampp\htdocs\maurnaturo\application\vendor/autoload.php was not found.
INFO - 2024-04-28 18:42:18 --> Config Class Initialized
INFO - 2024-04-28 18:42:18 --> Hooks Class Initialized
DEBUG - 2024-04-28 18:42:18 --> UTF-8 Support Enabled
INFO - 2024-04-28 18:42:18 --> Utf8 Class Initialized
INFO - 2024-04-28 18:42:18 --> URI Class Initialized
INFO - 2024-04-28 18:42:18 --> Router Class Initialized
INFO - 2024-04-28 18:42:18 --> Output Class Initialized
INFO - 2024-04-28 18:42:18 --> Security Class Initialized
DEBUG - 2024-04-28 18:42:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-04-28 18:42:18 --> Input Class Initialized
INFO - 2024-04-28 18:42:18 --> Language Class Initialized
INFO - 2024-04-28 18:42:18 --> Loader Class Initialized
INFO - 2024-04-28 18:42:18 --> Helper loaded: url_helper
INFO - 2024-04-28 18:42:18 --> Helper loaded: file_helper
INFO - 2024-04-28 18:42:18 --> Helper loaded: html_helper
INFO - 2024-04-28 18:42:18 --> Helper loaded: text_helper
INFO - 2024-04-28 18:42:18 --> Helper loaded: form_helper
INFO - 2024-04-28 18:42:18 --> Helper loaded: lang_helper
INFO - 2024-04-28 18:42:18 --> Helper loaded: security_helper
INFO - 2024-04-28 18:42:18 --> Helper loaded: cookie_helper
INFO - 2024-04-28 18:42:18 --> Database Driver Class Initialized
INFO - 2024-04-28 18:42:18 --> Session: Class initialized using 'files' driver.
INFO - 2024-04-28 18:42:18 --> Parser Class Initialized
INFO - 2024-04-28 18:42:18 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-04-28 18:42:18 --> Pagination Class Initialized
INFO - 2024-04-28 18:42:18 --> Form Validation Class Initialized
INFO - 2024-04-28 18:42:18 --> Controller Class Initialized
INFO - 2024-04-28 18:42:18 --> Model Class Initialized
DEBUG - 2024-04-28 18:42:18 --> Session class already loaded. Second attempt ignored.
INFO - 2024-04-28 18:42:18 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\user/admin_login_form.php
DEBUG - 2024-04-28 18:42:18 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-04-28 18:42:18 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\include/top_menu.php
INFO - 2024-04-28 18:42:18 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\include/admin_loggedin_info.php
INFO - 2024-04-28 18:42:18 --> Model Class Initialized
INFO - 2024-04-28 18:42:18 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\admin_html_template.php
INFO - 2024-04-28 18:42:18 --> Final output sent to browser
DEBUG - 2024-04-28 18:42:18 --> Total execution time: 0.1305
ERROR - 2024-04-28 18:42:28 --> $config['composer_autoload'] is set to TRUE but E:\xampp\htdocs\maurnaturo\application\vendor/autoload.php was not found.
INFO - 2024-04-28 18:42:28 --> Config Class Initialized
INFO - 2024-04-28 18:42:28 --> Hooks Class Initialized
DEBUG - 2024-04-28 18:42:28 --> UTF-8 Support Enabled
INFO - 2024-04-28 18:42:28 --> Utf8 Class Initialized
INFO - 2024-04-28 18:42:28 --> URI Class Initialized
INFO - 2024-04-28 18:42:28 --> Router Class Initialized
INFO - 2024-04-28 18:42:28 --> Output Class Initialized
INFO - 2024-04-28 18:42:28 --> Security Class Initialized
DEBUG - 2024-04-28 18:42:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-04-28 18:42:28 --> Input Class Initialized
INFO - 2024-04-28 18:42:28 --> Language Class Initialized
INFO - 2024-04-28 18:42:28 --> Loader Class Initialized
INFO - 2024-04-28 18:42:28 --> Helper loaded: url_helper
INFO - 2024-04-28 18:42:28 --> Helper loaded: file_helper
INFO - 2024-04-28 18:42:28 --> Helper loaded: html_helper
INFO - 2024-04-28 18:42:28 --> Helper loaded: text_helper
INFO - 2024-04-28 18:42:28 --> Helper loaded: form_helper
INFO - 2024-04-28 18:42:28 --> Helper loaded: lang_helper
INFO - 2024-04-28 18:42:28 --> Helper loaded: security_helper
INFO - 2024-04-28 18:42:28 --> Helper loaded: cookie_helper
INFO - 2024-04-28 18:42:28 --> Database Driver Class Initialized
INFO - 2024-04-28 18:42:28 --> Session: Class initialized using 'files' driver.
INFO - 2024-04-28 18:42:28 --> Parser Class Initialized
INFO - 2024-04-28 18:42:28 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-04-28 18:42:28 --> Pagination Class Initialized
INFO - 2024-04-28 18:42:28 --> Form Validation Class Initialized
INFO - 2024-04-28 18:42:28 --> Controller Class Initialized
INFO - 2024-04-28 18:42:28 --> Model Class Initialized
DEBUG - 2024-04-28 18:42:28 --> Session class already loaded. Second attempt ignored.
INFO - 2024-04-28 18:42:28 --> Model Class Initialized
INFO - 2024-04-28 18:42:28 --> Final output sent to browser
DEBUG - 2024-04-28 18:42:28 --> Total execution time: 0.0767
ERROR - 2024-04-28 18:42:28 --> $config['composer_autoload'] is set to TRUE but E:\xampp\htdocs\maurnaturo\application\vendor/autoload.php was not found.
INFO - 2024-04-28 18:42:28 --> Config Class Initialized
INFO - 2024-04-28 18:42:28 --> Hooks Class Initialized
DEBUG - 2024-04-28 18:42:28 --> UTF-8 Support Enabled
INFO - 2024-04-28 18:42:28 --> Utf8 Class Initialized
INFO - 2024-04-28 18:42:28 --> URI Class Initialized
DEBUG - 2024-04-28 18:42:28 --> No URI present. Default controller set.
INFO - 2024-04-28 18:42:28 --> Router Class Initialized
INFO - 2024-04-28 18:42:28 --> Output Class Initialized
INFO - 2024-04-28 18:42:28 --> Security Class Initialized
DEBUG - 2024-04-28 18:42:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-04-28 18:42:28 --> Input Class Initialized
INFO - 2024-04-28 18:42:28 --> Language Class Initialized
INFO - 2024-04-28 18:42:28 --> Loader Class Initialized
INFO - 2024-04-28 18:42:28 --> Helper loaded: url_helper
INFO - 2024-04-28 18:42:28 --> Helper loaded: file_helper
INFO - 2024-04-28 18:42:28 --> Helper loaded: html_helper
INFO - 2024-04-28 18:42:28 --> Helper loaded: text_helper
INFO - 2024-04-28 18:42:28 --> Helper loaded: form_helper
INFO - 2024-04-28 18:42:28 --> Helper loaded: lang_helper
INFO - 2024-04-28 18:42:28 --> Helper loaded: security_helper
INFO - 2024-04-28 18:42:28 --> Helper loaded: cookie_helper
INFO - 2024-04-28 18:42:28 --> Database Driver Class Initialized
INFO - 2024-04-28 18:42:28 --> Session: Class initialized using 'files' driver.
INFO - 2024-04-28 18:42:28 --> Parser Class Initialized
INFO - 2024-04-28 18:42:28 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-04-28 18:42:28 --> Pagination Class Initialized
INFO - 2024-04-28 18:42:28 --> Form Validation Class Initialized
INFO - 2024-04-28 18:42:28 --> Controller Class Initialized
INFO - 2024-04-28 18:42:28 --> Model Class Initialized
DEBUG - 2024-04-28 18:42:28 --> Session class already loaded. Second attempt ignored.
INFO - 2024-04-28 18:42:28 --> Model Class Initialized
DEBUG - 2024-04-28 18:42:28 --> Session class already loaded. Second attempt ignored.
INFO - 2024-04-28 18:42:28 --> Model Class Initialized
INFO - 2024-04-28 18:42:28 --> Model Class Initialized
INFO - 2024-04-28 18:42:28 --> Model Class Initialized
INFO - 2024-04-28 18:42:28 --> Model Class Initialized
DEBUG - 2024-04-28 18:42:28 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-04-28 18:42:28 --> Session class already loaded. Second attempt ignored.
INFO - 2024-04-28 18:42:28 --> Model Class Initialized
INFO - 2024-04-28 18:42:28 --> Model Class Initialized
INFO - 2024-04-28 18:42:29 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\include/admin_home.php
DEBUG - 2024-04-28 18:42:29 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-04-28 18:42:29 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\include/top_menu.php
INFO - 2024-04-28 18:42:29 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\include/admin_loggedin_info.php
INFO - 2024-04-28 18:42:29 --> Model Class Initialized
INFO - 2024-04-28 18:42:30 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\include/admin_header.php
INFO - 2024-04-28 18:42:30 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\include/admin_footer.php
INFO - 2024-04-28 18:42:30 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\admin_html_template.php
INFO - 2024-04-28 18:42:30 --> Final output sent to browser
DEBUG - 2024-04-28 18:42:30 --> Total execution time: 2.2316
ERROR - 2024-04-28 18:43:26 --> $config['composer_autoload'] is set to TRUE but E:\xampp\htdocs\maurnaturo\application\vendor/autoload.php was not found.
INFO - 2024-04-28 18:43:26 --> Config Class Initialized
INFO - 2024-04-28 18:43:26 --> Hooks Class Initialized
DEBUG - 2024-04-28 18:43:26 --> UTF-8 Support Enabled
INFO - 2024-04-28 18:43:26 --> Utf8 Class Initialized
INFO - 2024-04-28 18:43:26 --> URI Class Initialized
DEBUG - 2024-04-28 18:43:26 --> No URI present. Default controller set.
INFO - 2024-04-28 18:43:26 --> Router Class Initialized
INFO - 2024-04-28 18:43:26 --> Output Class Initialized
INFO - 2024-04-28 18:43:26 --> Security Class Initialized
DEBUG - 2024-04-28 18:43:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-04-28 18:43:26 --> Input Class Initialized
INFO - 2024-04-28 18:43:26 --> Language Class Initialized
INFO - 2024-04-28 18:43:26 --> Loader Class Initialized
INFO - 2024-04-28 18:43:26 --> Helper loaded: url_helper
INFO - 2024-04-28 18:43:26 --> Helper loaded: file_helper
INFO - 2024-04-28 18:43:26 --> Helper loaded: html_helper
INFO - 2024-04-28 18:43:26 --> Helper loaded: text_helper
INFO - 2024-04-28 18:43:26 --> Helper loaded: form_helper
INFO - 2024-04-28 18:43:26 --> Helper loaded: lang_helper
INFO - 2024-04-28 18:43:26 --> Helper loaded: security_helper
INFO - 2024-04-28 18:43:26 --> Helper loaded: cookie_helper
INFO - 2024-04-28 18:43:26 --> Database Driver Class Initialized
INFO - 2024-04-28 18:43:26 --> Session: Class initialized using 'files' driver.
INFO - 2024-04-28 18:43:26 --> Parser Class Initialized
INFO - 2024-04-28 18:43:26 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-04-28 18:43:26 --> Pagination Class Initialized
INFO - 2024-04-28 18:43:26 --> Form Validation Class Initialized
INFO - 2024-04-28 18:43:26 --> Controller Class Initialized
INFO - 2024-04-28 18:43:26 --> Model Class Initialized
DEBUG - 2024-04-28 18:43:26 --> Session class already loaded. Second attempt ignored.
INFO - 2024-04-28 18:43:26 --> Model Class Initialized
DEBUG - 2024-04-28 18:43:26 --> Session class already loaded. Second attempt ignored.
INFO - 2024-04-28 18:43:26 --> Model Class Initialized
INFO - 2024-04-28 18:43:26 --> Model Class Initialized
INFO - 2024-04-28 18:43:26 --> Model Class Initialized
INFO - 2024-04-28 18:43:26 --> Model Class Initialized
DEBUG - 2024-04-28 18:43:26 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-04-28 18:43:26 --> Session class already loaded. Second attempt ignored.
INFO - 2024-04-28 18:43:26 --> Model Class Initialized
INFO - 2024-04-28 18:43:26 --> Model Class Initialized
INFO - 2024-04-28 18:43:28 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\include/admin_home.php
DEBUG - 2024-04-28 18:43:28 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-04-28 18:43:28 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\include/top_menu.php
INFO - 2024-04-28 18:43:28 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\include/admin_loggedin_info.php
INFO - 2024-04-28 18:43:28 --> Model Class Initialized
INFO - 2024-04-28 18:43:29 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\include/admin_header.php
INFO - 2024-04-28 18:43:29 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\include/admin_footer.php
INFO - 2024-04-28 18:43:29 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\admin_html_template.php
INFO - 2024-04-28 18:43:29 --> Final output sent to browser
DEBUG - 2024-04-28 18:43:29 --> Total execution time: 2.6747
ERROR - 2024-04-28 18:43:30 --> $config['composer_autoload'] is set to TRUE but E:\xampp\htdocs\maurnaturo\application\vendor/autoload.php was not found.
INFO - 2024-04-28 18:43:30 --> Config Class Initialized
INFO - 2024-04-28 18:43:30 --> Hooks Class Initialized
DEBUG - 2024-04-28 18:43:30 --> UTF-8 Support Enabled
INFO - 2024-04-28 18:43:30 --> Utf8 Class Initialized
INFO - 2024-04-28 18:43:30 --> URI Class Initialized
DEBUG - 2024-04-28 18:43:30 --> No URI present. Default controller set.
INFO - 2024-04-28 18:43:30 --> Router Class Initialized
INFO - 2024-04-28 18:43:30 --> Output Class Initialized
INFO - 2024-04-28 18:43:30 --> Security Class Initialized
DEBUG - 2024-04-28 18:43:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-04-28 18:43:30 --> Input Class Initialized
INFO - 2024-04-28 18:43:30 --> Language Class Initialized
INFO - 2024-04-28 18:43:30 --> Loader Class Initialized
INFO - 2024-04-28 18:43:30 --> Helper loaded: url_helper
INFO - 2024-04-28 18:43:30 --> Helper loaded: file_helper
INFO - 2024-04-28 18:43:30 --> Helper loaded: html_helper
INFO - 2024-04-28 18:43:30 --> Helper loaded: text_helper
INFO - 2024-04-28 18:43:30 --> Helper loaded: form_helper
INFO - 2024-04-28 18:43:30 --> Helper loaded: lang_helper
INFO - 2024-04-28 18:43:30 --> Helper loaded: security_helper
INFO - 2024-04-28 18:43:30 --> Helper loaded: cookie_helper
INFO - 2024-04-28 18:43:30 --> Database Driver Class Initialized
INFO - 2024-04-28 18:43:30 --> Session: Class initialized using 'files' driver.
INFO - 2024-04-28 18:43:30 --> Parser Class Initialized
INFO - 2024-04-28 18:43:30 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-04-28 18:43:30 --> Pagination Class Initialized
INFO - 2024-04-28 18:43:30 --> Form Validation Class Initialized
INFO - 2024-04-28 18:43:30 --> Controller Class Initialized
INFO - 2024-04-28 18:43:30 --> Model Class Initialized
DEBUG - 2024-04-28 18:43:30 --> Session class already loaded. Second attempt ignored.
INFO - 2024-04-28 18:43:30 --> Model Class Initialized
DEBUG - 2024-04-28 18:43:30 --> Session class already loaded. Second attempt ignored.
INFO - 2024-04-28 18:43:30 --> Model Class Initialized
INFO - 2024-04-28 18:43:30 --> Model Class Initialized
INFO - 2024-04-28 18:43:30 --> Model Class Initialized
INFO - 2024-04-28 18:43:30 --> Model Class Initialized
DEBUG - 2024-04-28 18:43:30 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-04-28 18:43:30 --> Session class already loaded. Second attempt ignored.
INFO - 2024-04-28 18:43:30 --> Model Class Initialized
INFO - 2024-04-28 18:43:30 --> Model Class Initialized
INFO - 2024-04-28 18:43:32 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\include/admin_home.php
DEBUG - 2024-04-28 18:43:32 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-04-28 18:43:32 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\include/top_menu.php
INFO - 2024-04-28 18:43:32 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\include/admin_loggedin_info.php
INFO - 2024-04-28 18:43:32 --> Model Class Initialized
INFO - 2024-04-28 18:43:33 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\include/admin_header.php
INFO - 2024-04-28 18:43:33 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\include/admin_footer.php
INFO - 2024-04-28 18:43:33 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\admin_html_template.php
INFO - 2024-04-28 18:43:33 --> Final output sent to browser
DEBUG - 2024-04-28 18:43:33 --> Total execution time: 3.2448
ERROR - 2024-04-28 18:44:19 --> $config['composer_autoload'] is set to TRUE but E:\xampp\htdocs\maurnaturo\application\vendor/autoload.php was not found.
INFO - 2024-04-28 18:44:19 --> Config Class Initialized
INFO - 2024-04-28 18:44:19 --> Hooks Class Initialized
DEBUG - 2024-04-28 18:44:19 --> UTF-8 Support Enabled
INFO - 2024-04-28 18:44:19 --> Utf8 Class Initialized
INFO - 2024-04-28 18:44:19 --> URI Class Initialized
DEBUG - 2024-04-28 18:44:19 --> No URI present. Default controller set.
INFO - 2024-04-28 18:44:19 --> Router Class Initialized
INFO - 2024-04-28 18:44:19 --> Output Class Initialized
INFO - 2024-04-28 18:44:19 --> Security Class Initialized
DEBUG - 2024-04-28 18:44:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-04-28 18:44:19 --> Input Class Initialized
INFO - 2024-04-28 18:44:19 --> Language Class Initialized
INFO - 2024-04-28 18:44:19 --> Loader Class Initialized
INFO - 2024-04-28 18:44:19 --> Helper loaded: url_helper
INFO - 2024-04-28 18:44:19 --> Helper loaded: file_helper
INFO - 2024-04-28 18:44:19 --> Helper loaded: html_helper
INFO - 2024-04-28 18:44:19 --> Helper loaded: text_helper
INFO - 2024-04-28 18:44:19 --> Helper loaded: form_helper
INFO - 2024-04-28 18:44:19 --> Helper loaded: lang_helper
INFO - 2024-04-28 18:44:19 --> Helper loaded: security_helper
INFO - 2024-04-28 18:44:19 --> Helper loaded: cookie_helper
INFO - 2024-04-28 18:44:20 --> Database Driver Class Initialized
INFO - 2024-04-28 18:44:20 --> Session: Class initialized using 'files' driver.
INFO - 2024-04-28 18:44:20 --> Parser Class Initialized
INFO - 2024-04-28 18:44:20 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-04-28 18:44:20 --> Pagination Class Initialized
INFO - 2024-04-28 18:44:20 --> Form Validation Class Initialized
INFO - 2024-04-28 18:44:20 --> Controller Class Initialized
INFO - 2024-04-28 18:44:20 --> Model Class Initialized
DEBUG - 2024-04-28 18:44:20 --> Session class already loaded. Second attempt ignored.
INFO - 2024-04-28 18:44:20 --> Model Class Initialized
DEBUG - 2024-04-28 18:44:20 --> Session class already loaded. Second attempt ignored.
INFO - 2024-04-28 18:44:20 --> Model Class Initialized
INFO - 2024-04-28 18:44:20 --> Model Class Initialized
INFO - 2024-04-28 18:44:20 --> Model Class Initialized
INFO - 2024-04-28 18:44:20 --> Model Class Initialized
DEBUG - 2024-04-28 18:44:20 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-04-28 18:44:20 --> Session class already loaded. Second attempt ignored.
INFO - 2024-04-28 18:44:20 --> Model Class Initialized
INFO - 2024-04-28 18:44:20 --> Model Class Initialized
INFO - 2024-04-28 18:44:21 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\include/admin_home.php
DEBUG - 2024-04-28 18:44:21 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-04-28 18:44:21 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\include/top_menu.php
INFO - 2024-04-28 18:44:21 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\include/admin_loggedin_info.php
INFO - 2024-04-28 18:44:21 --> Model Class Initialized
INFO - 2024-04-28 18:44:22 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\include/admin_header.php
INFO - 2024-04-28 18:44:22 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\include/admin_footer.php
INFO - 2024-04-28 18:44:22 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\admin_html_template.php
INFO - 2024-04-28 18:44:22 --> Final output sent to browser
DEBUG - 2024-04-28 18:44:22 --> Total execution time: 2.3031
ERROR - 2024-04-28 18:44:27 --> $config['composer_autoload'] is set to TRUE but E:\xampp\htdocs\maurnaturo\application\vendor/autoload.php was not found.
INFO - 2024-04-28 18:44:27 --> Config Class Initialized
INFO - 2024-04-28 18:44:27 --> Hooks Class Initialized
DEBUG - 2024-04-28 18:44:27 --> UTF-8 Support Enabled
INFO - 2024-04-28 18:44:27 --> Utf8 Class Initialized
INFO - 2024-04-28 18:44:27 --> URI Class Initialized
INFO - 2024-04-28 18:44:27 --> Router Class Initialized
INFO - 2024-04-28 18:44:27 --> Output Class Initialized
INFO - 2024-04-28 18:44:27 --> Security Class Initialized
DEBUG - 2024-04-28 18:44:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-04-28 18:44:27 --> Input Class Initialized
INFO - 2024-04-28 18:44:27 --> Language Class Initialized
ERROR - 2024-04-28 18:44:27 --> 404 Page Not Found: Cexpenses/index
ERROR - 2024-04-28 19:53:14 --> $config['composer_autoload'] is set to TRUE but E:\xampp\htdocs\maurnaturo\application\vendor/autoload.php was not found.
INFO - 2024-04-28 19:53:14 --> Config Class Initialized
INFO - 2024-04-28 19:53:14 --> Hooks Class Initialized
DEBUG - 2024-04-28 19:53:14 --> UTF-8 Support Enabled
INFO - 2024-04-28 19:53:14 --> Utf8 Class Initialized
INFO - 2024-04-28 19:53:14 --> URI Class Initialized
INFO - 2024-04-28 19:53:14 --> Router Class Initialized
INFO - 2024-04-28 19:53:14 --> Output Class Initialized
INFO - 2024-04-28 19:53:14 --> Security Class Initialized
DEBUG - 2024-04-28 19:53:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-04-28 19:53:14 --> Input Class Initialized
INFO - 2024-04-28 19:53:14 --> Language Class Initialized
INFO - 2024-04-28 19:53:14 --> Loader Class Initialized
INFO - 2024-04-28 19:53:14 --> Helper loaded: url_helper
INFO - 2024-04-28 19:53:14 --> Helper loaded: file_helper
INFO - 2024-04-28 19:53:14 --> Helper loaded: html_helper
INFO - 2024-04-28 19:53:14 --> Helper loaded: text_helper
INFO - 2024-04-28 19:53:14 --> Helper loaded: form_helper
INFO - 2024-04-28 19:53:14 --> Helper loaded: lang_helper
INFO - 2024-04-28 19:53:14 --> Helper loaded: security_helper
INFO - 2024-04-28 19:53:14 --> Helper loaded: cookie_helper
INFO - 2024-04-28 19:53:14 --> Database Driver Class Initialized
INFO - 2024-04-28 19:53:14 --> Session: Class initialized using 'files' driver.
INFO - 2024-04-28 19:53:14 --> Parser Class Initialized
INFO - 2024-04-28 19:53:14 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-04-28 19:53:14 --> Pagination Class Initialized
INFO - 2024-04-28 19:53:14 --> Form Validation Class Initialized
INFO - 2024-04-28 19:53:14 --> Controller Class Initialized
DEBUG - 2024-04-28 19:53:14 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-04-28 19:53:14 --> Session class already loaded. Second attempt ignored.
INFO - 2024-04-28 19:53:14 --> Model Class Initialized
ERROR - 2024-04-28 19:53:15 --> $config['composer_autoload'] is set to TRUE but E:\xampp\htdocs\maurnaturo\application\vendor/autoload.php was not found.
INFO - 2024-04-28 19:53:15 --> Config Class Initialized
INFO - 2024-04-28 19:53:15 --> Hooks Class Initialized
DEBUG - 2024-04-28 19:53:15 --> UTF-8 Support Enabled
INFO - 2024-04-28 19:53:15 --> Utf8 Class Initialized
INFO - 2024-04-28 19:53:15 --> URI Class Initialized
INFO - 2024-04-28 19:53:15 --> Router Class Initialized
INFO - 2024-04-28 19:53:15 --> Output Class Initialized
INFO - 2024-04-28 19:53:15 --> Security Class Initialized
DEBUG - 2024-04-28 19:53:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-04-28 19:53:15 --> Input Class Initialized
INFO - 2024-04-28 19:53:15 --> Language Class Initialized
INFO - 2024-04-28 19:53:15 --> Loader Class Initialized
INFO - 2024-04-28 19:53:15 --> Helper loaded: url_helper
INFO - 2024-04-28 19:53:15 --> Helper loaded: file_helper
INFO - 2024-04-28 19:53:15 --> Helper loaded: html_helper
INFO - 2024-04-28 19:53:15 --> Helper loaded: text_helper
INFO - 2024-04-28 19:53:15 --> Helper loaded: form_helper
INFO - 2024-04-28 19:53:15 --> Helper loaded: lang_helper
INFO - 2024-04-28 19:53:15 --> Helper loaded: security_helper
INFO - 2024-04-28 19:53:15 --> Helper loaded: cookie_helper
INFO - 2024-04-28 19:53:15 --> Database Driver Class Initialized
INFO - 2024-04-28 19:53:15 --> Session: Class initialized using 'files' driver.
INFO - 2024-04-28 19:53:15 --> Parser Class Initialized
INFO - 2024-04-28 19:53:15 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-04-28 19:53:15 --> Pagination Class Initialized
INFO - 2024-04-28 19:53:15 --> Form Validation Class Initialized
INFO - 2024-04-28 19:53:15 --> Controller Class Initialized
DEBUG - 2024-04-28 19:53:15 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-04-28 19:53:15 --> Session class already loaded. Second attempt ignored.
INFO - 2024-04-28 19:53:15 --> Model Class Initialized
ERROR - 2024-04-28 19:53:28 --> $config['composer_autoload'] is set to TRUE but E:\xampp\htdocs\maurnaturo\application\vendor/autoload.php was not found.
INFO - 2024-04-28 19:53:28 --> Config Class Initialized
INFO - 2024-04-28 19:53:28 --> Hooks Class Initialized
DEBUG - 2024-04-28 19:53:28 --> UTF-8 Support Enabled
INFO - 2024-04-28 19:53:28 --> Utf8 Class Initialized
INFO - 2024-04-28 19:53:28 --> URI Class Initialized
INFO - 2024-04-28 19:53:28 --> Router Class Initialized
INFO - 2024-04-28 19:53:28 --> Output Class Initialized
INFO - 2024-04-28 19:53:28 --> Security Class Initialized
DEBUG - 2024-04-28 19:53:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-04-28 19:53:28 --> Input Class Initialized
INFO - 2024-04-28 19:53:28 --> Language Class Initialized
INFO - 2024-04-28 19:53:28 --> Loader Class Initialized
INFO - 2024-04-28 19:53:28 --> Helper loaded: url_helper
INFO - 2024-04-28 19:53:28 --> Helper loaded: file_helper
INFO - 2024-04-28 19:53:28 --> Helper loaded: html_helper
INFO - 2024-04-28 19:53:28 --> Helper loaded: text_helper
INFO - 2024-04-28 19:53:28 --> Helper loaded: form_helper
INFO - 2024-04-28 19:53:28 --> Helper loaded: lang_helper
INFO - 2024-04-28 19:53:28 --> Helper loaded: security_helper
INFO - 2024-04-28 19:53:28 --> Helper loaded: cookie_helper
INFO - 2024-04-28 19:53:28 --> Database Driver Class Initialized
INFO - 2024-04-28 19:53:28 --> Session: Class initialized using 'files' driver.
INFO - 2024-04-28 19:53:28 --> Parser Class Initialized
INFO - 2024-04-28 19:53:28 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-04-28 19:53:28 --> Pagination Class Initialized
INFO - 2024-04-28 19:53:28 --> Form Validation Class Initialized
INFO - 2024-04-28 19:53:28 --> Controller Class Initialized
DEBUG - 2024-04-28 19:53:28 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-04-28 19:53:28 --> Session class already loaded. Second attempt ignored.
INFO - 2024-04-28 19:53:28 --> Model Class Initialized
ERROR - 2024-04-28 19:53:59 --> $config['composer_autoload'] is set to TRUE but E:\xampp\htdocs\maurnaturo\application\vendor/autoload.php was not found.
INFO - 2024-04-28 19:53:59 --> Config Class Initialized
INFO - 2024-04-28 19:53:59 --> Hooks Class Initialized
DEBUG - 2024-04-28 19:53:59 --> UTF-8 Support Enabled
INFO - 2024-04-28 19:53:59 --> Utf8 Class Initialized
INFO - 2024-04-28 19:53:59 --> URI Class Initialized
INFO - 2024-04-28 19:53:59 --> Router Class Initialized
INFO - 2024-04-28 19:53:59 --> Output Class Initialized
INFO - 2024-04-28 19:53:59 --> Security Class Initialized
DEBUG - 2024-04-28 19:53:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-04-28 19:53:59 --> Input Class Initialized
INFO - 2024-04-28 19:53:59 --> Language Class Initialized
INFO - 2024-04-28 19:53:59 --> Loader Class Initialized
INFO - 2024-04-28 19:53:59 --> Helper loaded: url_helper
INFO - 2024-04-28 19:53:59 --> Helper loaded: file_helper
INFO - 2024-04-28 19:53:59 --> Helper loaded: html_helper
INFO - 2024-04-28 19:53:59 --> Helper loaded: text_helper
INFO - 2024-04-28 19:53:59 --> Helper loaded: form_helper
INFO - 2024-04-28 19:53:59 --> Helper loaded: lang_helper
INFO - 2024-04-28 19:53:59 --> Helper loaded: security_helper
INFO - 2024-04-28 19:53:59 --> Helper loaded: cookie_helper
INFO - 2024-04-28 19:53:59 --> Database Driver Class Initialized
INFO - 2024-04-28 19:53:59 --> Session: Class initialized using 'files' driver.
INFO - 2024-04-28 19:53:59 --> Parser Class Initialized
INFO - 2024-04-28 19:53:59 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-04-28 19:53:59 --> Pagination Class Initialized
INFO - 2024-04-28 19:53:59 --> Form Validation Class Initialized
INFO - 2024-04-28 19:53:59 --> Controller Class Initialized
DEBUG - 2024-04-28 19:53:59 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-04-28 19:53:59 --> Session class already loaded. Second attempt ignored.
INFO - 2024-04-28 19:53:59 --> Model Class Initialized
INFO - 2024-04-28 19:53:59 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\expenses/add_expenses_form.php
DEBUG - 2024-04-28 19:53:59 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-04-28 19:53:59 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\include/top_menu.php
INFO - 2024-04-28 19:53:59 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\include/admin_loggedin_info.php
INFO - 2024-04-28 19:53:59 --> Model Class Initialized
INFO - 2024-04-28 19:53:59 --> Model Class Initialized
INFO - 2024-04-28 19:53:59 --> Model Class Initialized
INFO - 2024-04-28 19:53:59 --> Model Class Initialized
INFO - 2024-04-28 19:54:01 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\include/admin_header.php
INFO - 2024-04-28 19:54:01 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\include/admin_footer.php
INFO - 2024-04-28 19:54:01 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\admin_html_template.php
INFO - 2024-04-28 19:54:01 --> Final output sent to browser
DEBUG - 2024-04-28 19:54:01 --> Total execution time: 1.7919
ERROR - 2024-04-28 19:54:17 --> $config['composer_autoload'] is set to TRUE but E:\xampp\htdocs\maurnaturo\application\vendor/autoload.php was not found.
INFO - 2024-04-28 19:54:17 --> Config Class Initialized
INFO - 2024-04-28 19:54:17 --> Hooks Class Initialized
DEBUG - 2024-04-28 19:54:17 --> UTF-8 Support Enabled
INFO - 2024-04-28 19:54:17 --> Utf8 Class Initialized
INFO - 2024-04-28 19:54:17 --> URI Class Initialized
INFO - 2024-04-28 19:54:17 --> Router Class Initialized
INFO - 2024-04-28 19:54:17 --> Output Class Initialized
INFO - 2024-04-28 19:54:17 --> Security Class Initialized
DEBUG - 2024-04-28 19:54:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-04-28 19:54:17 --> Input Class Initialized
INFO - 2024-04-28 19:54:17 --> Language Class Initialized
INFO - 2024-04-28 19:54:17 --> Loader Class Initialized
INFO - 2024-04-28 19:54:17 --> Helper loaded: url_helper
INFO - 2024-04-28 19:54:17 --> Helper loaded: file_helper
INFO - 2024-04-28 19:54:17 --> Helper loaded: html_helper
INFO - 2024-04-28 19:54:17 --> Helper loaded: text_helper
INFO - 2024-04-28 19:54:17 --> Helper loaded: form_helper
INFO - 2024-04-28 19:54:17 --> Helper loaded: lang_helper
INFO - 2024-04-28 19:54:17 --> Helper loaded: security_helper
INFO - 2024-04-28 19:54:17 --> Helper loaded: cookie_helper
INFO - 2024-04-28 19:54:17 --> Database Driver Class Initialized
INFO - 2024-04-28 19:54:17 --> Session: Class initialized using 'files' driver.
INFO - 2024-04-28 19:54:17 --> Parser Class Initialized
INFO - 2024-04-28 19:54:17 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-04-28 19:54:17 --> Pagination Class Initialized
INFO - 2024-04-28 19:54:17 --> Form Validation Class Initialized
INFO - 2024-04-28 19:54:17 --> Controller Class Initialized
DEBUG - 2024-04-28 19:54:17 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-04-28 19:54:17 --> Session class already loaded. Second attempt ignored.
INFO - 2024-04-28 19:54:17 --> Model Class Initialized
DEBUG - 2024-04-28 19:54:17 --> Lexpenses class already loaded. Second attempt ignored.
INFO - 2024-04-28 19:54:17 --> Model Class Initialized
INFO - 2024-04-28 19:54:17 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\expenses/expenses.php
DEBUG - 2024-04-28 19:54:17 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-04-28 19:54:17 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\include/top_menu.php
INFO - 2024-04-28 19:54:17 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\include/admin_loggedin_info.php
INFO - 2024-04-28 19:54:17 --> Model Class Initialized
INFO - 2024-04-28 19:54:17 --> Model Class Initialized
INFO - 2024-04-28 19:54:17 --> Model Class Initialized
INFO - 2024-04-28 19:54:19 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\include/admin_header.php
INFO - 2024-04-28 19:54:19 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\include/admin_footer.php
INFO - 2024-04-28 19:54:19 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\admin_html_template.php
INFO - 2024-04-28 19:54:19 --> Final output sent to browser
DEBUG - 2024-04-28 19:54:19 --> Total execution time: 1.9478
ERROR - 2024-04-28 19:54:19 --> $config['composer_autoload'] is set to TRUE but E:\xampp\htdocs\maurnaturo\application\vendor/autoload.php was not found.
INFO - 2024-04-28 19:54:19 --> Config Class Initialized
INFO - 2024-04-28 19:54:19 --> Hooks Class Initialized
DEBUG - 2024-04-28 19:54:19 --> UTF-8 Support Enabled
INFO - 2024-04-28 19:54:19 --> Utf8 Class Initialized
INFO - 2024-04-28 19:54:19 --> URI Class Initialized
INFO - 2024-04-28 19:54:19 --> Router Class Initialized
INFO - 2024-04-28 19:54:19 --> Output Class Initialized
INFO - 2024-04-28 19:54:19 --> Security Class Initialized
DEBUG - 2024-04-28 19:54:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-04-28 19:54:19 --> Input Class Initialized
INFO - 2024-04-28 19:54:19 --> Language Class Initialized
INFO - 2024-04-28 19:54:19 --> Loader Class Initialized
INFO - 2024-04-28 19:54:19 --> Helper loaded: url_helper
INFO - 2024-04-28 19:54:19 --> Helper loaded: file_helper
INFO - 2024-04-28 19:54:19 --> Helper loaded: html_helper
INFO - 2024-04-28 19:54:19 --> Helper loaded: text_helper
INFO - 2024-04-28 19:54:19 --> Helper loaded: form_helper
INFO - 2024-04-28 19:54:19 --> Helper loaded: lang_helper
INFO - 2024-04-28 19:54:19 --> Helper loaded: security_helper
INFO - 2024-04-28 19:54:19 --> Helper loaded: cookie_helper
INFO - 2024-04-28 19:54:19 --> Database Driver Class Initialized
INFO - 2024-04-28 19:54:19 --> Session: Class initialized using 'files' driver.
INFO - 2024-04-28 19:54:19 --> Parser Class Initialized
INFO - 2024-04-28 19:54:19 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-04-28 19:54:19 --> Pagination Class Initialized
INFO - 2024-04-28 19:54:19 --> Form Validation Class Initialized
INFO - 2024-04-28 19:54:19 --> Controller Class Initialized
DEBUG - 2024-04-28 19:54:19 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-04-28 19:54:19 --> Session class already loaded. Second attempt ignored.
INFO - 2024-04-28 19:54:19 --> Model Class Initialized
INFO - 2024-04-28 19:54:19 --> Final output sent to browser
DEBUG - 2024-04-28 19:54:19 --> Total execution time: 0.1193
ERROR - 2024-04-28 19:56:39 --> $config['composer_autoload'] is set to TRUE but E:\xampp\htdocs\maurnaturo\application\vendor/autoload.php was not found.
INFO - 2024-04-28 19:56:39 --> Config Class Initialized
INFO - 2024-04-28 19:56:39 --> Hooks Class Initialized
DEBUG - 2024-04-28 19:56:39 --> UTF-8 Support Enabled
INFO - 2024-04-28 19:56:39 --> Utf8 Class Initialized
INFO - 2024-04-28 19:56:39 --> URI Class Initialized
INFO - 2024-04-28 19:56:39 --> Router Class Initialized
INFO - 2024-04-28 19:56:40 --> Output Class Initialized
INFO - 2024-04-28 19:56:40 --> Security Class Initialized
DEBUG - 2024-04-28 19:56:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-04-28 19:56:40 --> Input Class Initialized
INFO - 2024-04-28 19:56:40 --> Language Class Initialized
INFO - 2024-04-28 19:56:40 --> Loader Class Initialized
INFO - 2024-04-28 19:56:40 --> Helper loaded: url_helper
INFO - 2024-04-28 19:56:40 --> Helper loaded: file_helper
INFO - 2024-04-28 19:56:40 --> Helper loaded: html_helper
INFO - 2024-04-28 19:56:40 --> Helper loaded: text_helper
INFO - 2024-04-28 19:56:40 --> Helper loaded: form_helper
INFO - 2024-04-28 19:56:40 --> Helper loaded: lang_helper
INFO - 2024-04-28 19:56:40 --> Helper loaded: security_helper
INFO - 2024-04-28 19:56:40 --> Helper loaded: cookie_helper
INFO - 2024-04-28 19:56:40 --> Database Driver Class Initialized
INFO - 2024-04-28 19:56:40 --> Session: Class initialized using 'files' driver.
INFO - 2024-04-28 19:56:40 --> Parser Class Initialized
INFO - 2024-04-28 19:56:40 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-04-28 19:56:40 --> Pagination Class Initialized
INFO - 2024-04-28 19:56:40 --> Form Validation Class Initialized
INFO - 2024-04-28 19:56:40 --> Controller Class Initialized
DEBUG - 2024-04-28 19:56:40 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-04-28 19:56:40 --> Session class already loaded. Second attempt ignored.
INFO - 2024-04-28 19:56:40 --> Model Class Initialized
INFO - 2024-04-28 19:56:40 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\payments/add_payment_form.php
DEBUG - 2024-04-28 19:56:40 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-04-28 19:56:40 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\include/top_menu.php
INFO - 2024-04-28 19:56:40 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\include/admin_loggedin_info.php
INFO - 2024-04-28 19:56:40 --> Model Class Initialized
INFO - 2024-04-28 19:56:40 --> Model Class Initialized
INFO - 2024-04-28 19:56:40 --> Model Class Initialized
INFO - 2024-04-28 19:56:40 --> Model Class Initialized
INFO - 2024-04-28 19:56:41 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\include/admin_header.php
INFO - 2024-04-28 19:56:41 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\include/admin_footer.php
INFO - 2024-04-28 19:56:41 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\admin_html_template.php
INFO - 2024-04-28 19:56:41 --> Final output sent to browser
DEBUG - 2024-04-28 19:56:41 --> Total execution time: 1.4053
ERROR - 2024-04-28 19:56:52 --> $config['composer_autoload'] is set to TRUE but E:\xampp\htdocs\maurnaturo\application\vendor/autoload.php was not found.
INFO - 2024-04-28 19:56:52 --> Config Class Initialized
INFO - 2024-04-28 19:56:52 --> Hooks Class Initialized
DEBUG - 2024-04-28 19:56:52 --> UTF-8 Support Enabled
INFO - 2024-04-28 19:56:52 --> Utf8 Class Initialized
INFO - 2024-04-28 19:56:52 --> URI Class Initialized
INFO - 2024-04-28 19:56:52 --> Router Class Initialized
INFO - 2024-04-28 19:56:52 --> Output Class Initialized
INFO - 2024-04-28 19:56:52 --> Security Class Initialized
DEBUG - 2024-04-28 19:56:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-04-28 19:56:52 --> Input Class Initialized
INFO - 2024-04-28 19:56:52 --> Language Class Initialized
INFO - 2024-04-28 19:56:52 --> Loader Class Initialized
INFO - 2024-04-28 19:56:52 --> Helper loaded: url_helper
INFO - 2024-04-28 19:56:52 --> Helper loaded: file_helper
INFO - 2024-04-28 19:56:52 --> Helper loaded: html_helper
INFO - 2024-04-28 19:56:52 --> Helper loaded: text_helper
INFO - 2024-04-28 19:56:52 --> Helper loaded: form_helper
INFO - 2024-04-28 19:56:52 --> Helper loaded: lang_helper
INFO - 2024-04-28 19:56:52 --> Helper loaded: security_helper
INFO - 2024-04-28 19:56:52 --> Helper loaded: cookie_helper
INFO - 2024-04-28 19:56:52 --> Database Driver Class Initialized
INFO - 2024-04-28 19:56:52 --> Session: Class initialized using 'files' driver.
INFO - 2024-04-28 19:56:52 --> Parser Class Initialized
INFO - 2024-04-28 19:56:52 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-04-28 19:56:52 --> Pagination Class Initialized
INFO - 2024-04-28 19:56:52 --> Form Validation Class Initialized
INFO - 2024-04-28 19:56:52 --> Controller Class Initialized
DEBUG - 2024-04-28 19:56:52 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-04-28 19:56:52 --> Session class already loaded. Second attempt ignored.
INFO - 2024-04-28 19:56:52 --> Model Class Initialized
DEBUG - 2024-04-28 19:56:52 --> Lpayments class already loaded. Second attempt ignored.
INFO - 2024-04-28 19:56:52 --> Model Class Initialized
INFO - 2024-04-28 19:56:52 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\payments/payment.php
DEBUG - 2024-04-28 19:56:52 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-04-28 19:56:52 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\include/top_menu.php
INFO - 2024-04-28 19:56:52 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\include/admin_loggedin_info.php
INFO - 2024-04-28 19:56:52 --> Model Class Initialized
INFO - 2024-04-28 19:56:52 --> Model Class Initialized
INFO - 2024-04-28 19:56:52 --> Model Class Initialized
INFO - 2024-04-28 19:56:54 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\include/admin_header.php
INFO - 2024-04-28 19:56:54 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\include/admin_footer.php
INFO - 2024-04-28 19:56:54 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\admin_html_template.php
INFO - 2024-04-28 19:56:54 --> Final output sent to browser
DEBUG - 2024-04-28 19:56:54 --> Total execution time: 1.6505
ERROR - 2024-04-28 19:56:54 --> $config['composer_autoload'] is set to TRUE but E:\xampp\htdocs\maurnaturo\application\vendor/autoload.php was not found.
INFO - 2024-04-28 19:56:54 --> Config Class Initialized
INFO - 2024-04-28 19:56:54 --> Hooks Class Initialized
DEBUG - 2024-04-28 19:56:54 --> UTF-8 Support Enabled
INFO - 2024-04-28 19:56:54 --> Utf8 Class Initialized
INFO - 2024-04-28 19:56:54 --> URI Class Initialized
INFO - 2024-04-28 19:56:54 --> Router Class Initialized
INFO - 2024-04-28 19:56:54 --> Output Class Initialized
INFO - 2024-04-28 19:56:54 --> Security Class Initialized
DEBUG - 2024-04-28 19:56:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-04-28 19:56:54 --> Input Class Initialized
INFO - 2024-04-28 19:56:54 --> Language Class Initialized
INFO - 2024-04-28 19:56:54 --> Loader Class Initialized
INFO - 2024-04-28 19:56:54 --> Helper loaded: url_helper
INFO - 2024-04-28 19:56:54 --> Helper loaded: file_helper
INFO - 2024-04-28 19:56:54 --> Helper loaded: html_helper
INFO - 2024-04-28 19:56:54 --> Helper loaded: text_helper
INFO - 2024-04-28 19:56:54 --> Helper loaded: form_helper
INFO - 2024-04-28 19:56:54 --> Helper loaded: lang_helper
INFO - 2024-04-28 19:56:54 --> Helper loaded: security_helper
INFO - 2024-04-28 19:56:54 --> Helper loaded: cookie_helper
INFO - 2024-04-28 19:56:54 --> Database Driver Class Initialized
INFO - 2024-04-28 19:56:54 --> Session: Class initialized using 'files' driver.
INFO - 2024-04-28 19:56:54 --> Parser Class Initialized
INFO - 2024-04-28 19:56:54 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-04-28 19:56:54 --> Pagination Class Initialized
INFO - 2024-04-28 19:56:54 --> Form Validation Class Initialized
INFO - 2024-04-28 19:56:54 --> Controller Class Initialized
DEBUG - 2024-04-28 19:56:54 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-04-28 19:56:54 --> Session class already loaded. Second attempt ignored.
INFO - 2024-04-28 19:56:54 --> Model Class Initialized
INFO - 2024-04-28 19:56:54 --> Final output sent to browser
DEBUG - 2024-04-28 19:56:54 --> Total execution time: 0.1990
ERROR - 2024-04-28 19:57:06 --> $config['composer_autoload'] is set to TRUE but E:\xampp\htdocs\maurnaturo\application\vendor/autoload.php was not found.
INFO - 2024-04-28 19:57:06 --> Config Class Initialized
INFO - 2024-04-28 19:57:06 --> Hooks Class Initialized
DEBUG - 2024-04-28 19:57:06 --> UTF-8 Support Enabled
INFO - 2024-04-28 19:57:06 --> Utf8 Class Initialized
INFO - 2024-04-28 19:57:06 --> URI Class Initialized
INFO - 2024-04-28 19:57:06 --> Router Class Initialized
INFO - 2024-04-28 19:57:06 --> Output Class Initialized
INFO - 2024-04-28 19:57:06 --> Security Class Initialized
DEBUG - 2024-04-28 19:57:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-04-28 19:57:06 --> Input Class Initialized
INFO - 2024-04-28 19:57:06 --> Language Class Initialized
INFO - 2024-04-28 19:57:06 --> Loader Class Initialized
INFO - 2024-04-28 19:57:06 --> Helper loaded: url_helper
INFO - 2024-04-28 19:57:06 --> Helper loaded: file_helper
INFO - 2024-04-28 19:57:06 --> Helper loaded: html_helper
INFO - 2024-04-28 19:57:07 --> Helper loaded: text_helper
INFO - 2024-04-28 19:57:07 --> Helper loaded: form_helper
INFO - 2024-04-28 19:57:07 --> Helper loaded: lang_helper
INFO - 2024-04-28 19:57:07 --> Helper loaded: security_helper
INFO - 2024-04-28 19:57:07 --> Helper loaded: cookie_helper
INFO - 2024-04-28 19:57:07 --> Database Driver Class Initialized
INFO - 2024-04-28 19:57:07 --> Session: Class initialized using 'files' driver.
INFO - 2024-04-28 19:57:07 --> Parser Class Initialized
INFO - 2024-04-28 19:57:07 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-04-28 19:57:07 --> Pagination Class Initialized
INFO - 2024-04-28 19:57:07 --> Form Validation Class Initialized
INFO - 2024-04-28 19:57:07 --> Controller Class Initialized
DEBUG - 2024-04-28 19:57:07 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-04-28 19:57:07 --> Session class already loaded. Second attempt ignored.
INFO - 2024-04-28 19:57:07 --> Model Class Initialized
INFO - 2024-04-28 19:57:07 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\expenses/add_expenses_form.php
DEBUG - 2024-04-28 19:57:07 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-04-28 19:57:07 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\include/top_menu.php
INFO - 2024-04-28 19:57:07 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\include/admin_loggedin_info.php
INFO - 2024-04-28 19:57:07 --> Model Class Initialized
INFO - 2024-04-28 19:57:07 --> Model Class Initialized
INFO - 2024-04-28 19:57:07 --> Model Class Initialized
INFO - 2024-04-28 19:57:07 --> Model Class Initialized
INFO - 2024-04-28 19:57:08 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\include/admin_header.php
INFO - 2024-04-28 19:57:08 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\include/admin_footer.php
INFO - 2024-04-28 19:57:08 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\admin_html_template.php
INFO - 2024-04-28 19:57:08 --> Final output sent to browser
DEBUG - 2024-04-28 19:57:08 --> Total execution time: 1.4171
ERROR - 2024-04-28 19:57:23 --> $config['composer_autoload'] is set to TRUE but E:\xampp\htdocs\maurnaturo\application\vendor/autoload.php was not found.
INFO - 2024-04-28 19:57:23 --> Config Class Initialized
INFO - 2024-04-28 19:57:23 --> Hooks Class Initialized
DEBUG - 2024-04-28 19:57:23 --> UTF-8 Support Enabled
INFO - 2024-04-28 19:57:23 --> Utf8 Class Initialized
INFO - 2024-04-28 19:57:23 --> URI Class Initialized
INFO - 2024-04-28 19:57:23 --> Router Class Initialized
INFO - 2024-04-28 19:57:23 --> Output Class Initialized
INFO - 2024-04-28 19:57:23 --> Security Class Initialized
DEBUG - 2024-04-28 19:57:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-04-28 19:57:23 --> Input Class Initialized
INFO - 2024-04-28 19:57:23 --> Language Class Initialized
INFO - 2024-04-28 19:57:23 --> Loader Class Initialized
INFO - 2024-04-28 19:57:23 --> Helper loaded: url_helper
INFO - 2024-04-28 19:57:23 --> Helper loaded: file_helper
INFO - 2024-04-28 19:57:23 --> Helper loaded: html_helper
INFO - 2024-04-28 19:57:23 --> Helper loaded: text_helper
INFO - 2024-04-28 19:57:23 --> Helper loaded: form_helper
INFO - 2024-04-28 19:57:23 --> Helper loaded: lang_helper
INFO - 2024-04-28 19:57:23 --> Helper loaded: security_helper
INFO - 2024-04-28 19:57:23 --> Helper loaded: cookie_helper
INFO - 2024-04-28 19:57:23 --> Database Driver Class Initialized
INFO - 2024-04-28 19:57:23 --> Session: Class initialized using 'files' driver.
INFO - 2024-04-28 19:57:23 --> Parser Class Initialized
INFO - 2024-04-28 19:57:23 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-04-28 19:57:23 --> Pagination Class Initialized
INFO - 2024-04-28 19:57:23 --> Form Validation Class Initialized
INFO - 2024-04-28 19:57:23 --> Controller Class Initialized
DEBUG - 2024-04-28 19:57:23 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-04-28 19:57:23 --> Session class already loaded. Second attempt ignored.
INFO - 2024-04-28 19:57:23 --> Model Class Initialized
DEBUG - 2024-04-28 19:57:23 --> Lexpenses class already loaded. Second attempt ignored.
INFO - 2024-04-28 19:57:23 --> Model Class Initialized
INFO - 2024-04-28 19:57:23 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\expenses/expenses.php
DEBUG - 2024-04-28 19:57:23 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-04-28 19:57:23 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\include/top_menu.php
INFO - 2024-04-28 19:57:23 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\include/admin_loggedin_info.php
INFO - 2024-04-28 19:57:23 --> Model Class Initialized
INFO - 2024-04-28 19:57:23 --> Model Class Initialized
INFO - 2024-04-28 19:57:23 --> Model Class Initialized
INFO - 2024-04-28 19:57:25 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\include/admin_header.php
INFO - 2024-04-28 19:57:25 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\include/admin_footer.php
INFO - 2024-04-28 19:57:25 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\admin_html_template.php
INFO - 2024-04-28 19:57:25 --> Final output sent to browser
DEBUG - 2024-04-28 19:57:25 --> Total execution time: 1.8675
ERROR - 2024-04-28 19:57:25 --> $config['composer_autoload'] is set to TRUE but E:\xampp\htdocs\maurnaturo\application\vendor/autoload.php was not found.
INFO - 2024-04-28 19:57:25 --> Config Class Initialized
INFO - 2024-04-28 19:57:25 --> Hooks Class Initialized
DEBUG - 2024-04-28 19:57:25 --> UTF-8 Support Enabled
INFO - 2024-04-28 19:57:25 --> Utf8 Class Initialized
INFO - 2024-04-28 19:57:25 --> URI Class Initialized
INFO - 2024-04-28 19:57:25 --> Router Class Initialized
INFO - 2024-04-28 19:57:25 --> Output Class Initialized
INFO - 2024-04-28 19:57:25 --> Security Class Initialized
DEBUG - 2024-04-28 19:57:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-04-28 19:57:25 --> Input Class Initialized
INFO - 2024-04-28 19:57:25 --> Language Class Initialized
INFO - 2024-04-28 19:57:25 --> Loader Class Initialized
INFO - 2024-04-28 19:57:25 --> Helper loaded: url_helper
INFO - 2024-04-28 19:57:25 --> Helper loaded: file_helper
INFO - 2024-04-28 19:57:25 --> Helper loaded: html_helper
INFO - 2024-04-28 19:57:25 --> Helper loaded: text_helper
INFO - 2024-04-28 19:57:25 --> Helper loaded: form_helper
INFO - 2024-04-28 19:57:25 --> Helper loaded: lang_helper
INFO - 2024-04-28 19:57:25 --> Helper loaded: security_helper
INFO - 2024-04-28 19:57:25 --> Helper loaded: cookie_helper
INFO - 2024-04-28 19:57:25 --> Database Driver Class Initialized
INFO - 2024-04-28 19:57:25 --> Session: Class initialized using 'files' driver.
INFO - 2024-04-28 19:57:25 --> Parser Class Initialized
INFO - 2024-04-28 19:57:25 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-04-28 19:57:25 --> Pagination Class Initialized
INFO - 2024-04-28 19:57:25 --> Form Validation Class Initialized
INFO - 2024-04-28 19:57:25 --> Controller Class Initialized
DEBUG - 2024-04-28 19:57:25 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-04-28 19:57:25 --> Session class already loaded. Second attempt ignored.
INFO - 2024-04-28 19:57:25 --> Model Class Initialized
INFO - 2024-04-28 19:57:25 --> Final output sent to browser
DEBUG - 2024-04-28 19:57:25 --> Total execution time: 0.1404
ERROR - 2024-04-28 19:57:46 --> $config['composer_autoload'] is set to TRUE but E:\xampp\htdocs\maurnaturo\application\vendor/autoload.php was not found.
INFO - 2024-04-28 19:57:46 --> Config Class Initialized
INFO - 2024-04-28 19:57:46 --> Hooks Class Initialized
DEBUG - 2024-04-28 19:57:46 --> UTF-8 Support Enabled
INFO - 2024-04-28 19:57:46 --> Utf8 Class Initialized
INFO - 2024-04-28 19:57:46 --> URI Class Initialized
INFO - 2024-04-28 19:57:46 --> Router Class Initialized
INFO - 2024-04-28 19:57:46 --> Output Class Initialized
INFO - 2024-04-28 19:57:46 --> Security Class Initialized
DEBUG - 2024-04-28 19:57:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-04-28 19:57:46 --> Input Class Initialized
INFO - 2024-04-28 19:57:46 --> Language Class Initialized
INFO - 2024-04-28 19:57:46 --> Loader Class Initialized
INFO - 2024-04-28 19:57:46 --> Helper loaded: url_helper
INFO - 2024-04-28 19:57:46 --> Helper loaded: file_helper
INFO - 2024-04-28 19:57:46 --> Helper loaded: html_helper
INFO - 2024-04-28 19:57:46 --> Helper loaded: text_helper
INFO - 2024-04-28 19:57:46 --> Helper loaded: form_helper
INFO - 2024-04-28 19:57:46 --> Helper loaded: lang_helper
INFO - 2024-04-28 19:57:46 --> Helper loaded: security_helper
INFO - 2024-04-28 19:57:46 --> Helper loaded: cookie_helper
INFO - 2024-04-28 19:57:46 --> Database Driver Class Initialized
INFO - 2024-04-28 19:57:46 --> Session: Class initialized using 'files' driver.
INFO - 2024-04-28 19:57:46 --> Parser Class Initialized
INFO - 2024-04-28 19:57:46 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-04-28 19:57:46 --> Pagination Class Initialized
INFO - 2024-04-28 19:57:46 --> Form Validation Class Initialized
INFO - 2024-04-28 19:57:46 --> Controller Class Initialized
DEBUG - 2024-04-28 19:57:46 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-04-28 19:57:46 --> Session class already loaded. Second attempt ignored.
INFO - 2024-04-28 19:57:46 --> Model Class Initialized
DEBUG - 2024-04-28 19:57:46 --> Lpayments class already loaded. Second attempt ignored.
INFO - 2024-04-28 19:57:46 --> Model Class Initialized
INFO - 2024-04-28 19:57:46 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\payments/payment.php
DEBUG - 2024-04-28 19:57:46 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-04-28 19:57:46 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\include/top_menu.php
INFO - 2024-04-28 19:57:46 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\include/admin_loggedin_info.php
INFO - 2024-04-28 19:57:46 --> Model Class Initialized
INFO - 2024-04-28 19:57:46 --> Model Class Initialized
INFO - 2024-04-28 19:57:46 --> Model Class Initialized
INFO - 2024-04-28 19:57:47 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\include/admin_header.php
INFO - 2024-04-28 19:57:47 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\include/admin_footer.php
INFO - 2024-04-28 19:57:47 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\admin_html_template.php
INFO - 2024-04-28 19:57:47 --> Final output sent to browser
DEBUG - 2024-04-28 19:57:47 --> Total execution time: 1.3538
ERROR - 2024-04-28 19:57:47 --> $config['composer_autoload'] is set to TRUE but E:\xampp\htdocs\maurnaturo\application\vendor/autoload.php was not found.
INFO - 2024-04-28 19:57:47 --> Config Class Initialized
INFO - 2024-04-28 19:57:47 --> Hooks Class Initialized
DEBUG - 2024-04-28 19:57:47 --> UTF-8 Support Enabled
INFO - 2024-04-28 19:57:47 --> Utf8 Class Initialized
INFO - 2024-04-28 19:57:47 --> URI Class Initialized
INFO - 2024-04-28 19:57:47 --> Router Class Initialized
INFO - 2024-04-28 19:57:47 --> Output Class Initialized
INFO - 2024-04-28 19:57:47 --> Security Class Initialized
DEBUG - 2024-04-28 19:57:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-04-28 19:57:47 --> Input Class Initialized
INFO - 2024-04-28 19:57:47 --> Language Class Initialized
INFO - 2024-04-28 19:57:47 --> Loader Class Initialized
INFO - 2024-04-28 19:57:47 --> Helper loaded: url_helper
INFO - 2024-04-28 19:57:47 --> Helper loaded: file_helper
INFO - 2024-04-28 19:57:47 --> Helper loaded: html_helper
INFO - 2024-04-28 19:57:47 --> Helper loaded: text_helper
INFO - 2024-04-28 19:57:47 --> Helper loaded: form_helper
INFO - 2024-04-28 19:57:47 --> Helper loaded: lang_helper
INFO - 2024-04-28 19:57:47 --> Helper loaded: security_helper
INFO - 2024-04-28 19:57:47 --> Helper loaded: cookie_helper
INFO - 2024-04-28 19:57:47 --> Database Driver Class Initialized
INFO - 2024-04-28 19:57:47 --> Session: Class initialized using 'files' driver.
INFO - 2024-04-28 19:57:47 --> Parser Class Initialized
INFO - 2024-04-28 19:57:47 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-04-28 19:57:47 --> Pagination Class Initialized
INFO - 2024-04-28 19:57:47 --> Form Validation Class Initialized
INFO - 2024-04-28 19:57:47 --> Controller Class Initialized
DEBUG - 2024-04-28 19:57:47 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-04-28 19:57:47 --> Session class already loaded. Second attempt ignored.
INFO - 2024-04-28 19:57:47 --> Model Class Initialized
INFO - 2024-04-28 19:57:47 --> Final output sent to browser
DEBUG - 2024-04-28 19:57:47 --> Total execution time: 0.1289
