<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2024-05-04 09:49:30 --> $config['composer_autoload'] is set to TRUE but E:\xampp\htdocs\maurnaturo\application\vendor/autoload.php was not found.
INFO - 2024-05-04 09:49:30 --> Config Class Initialized
INFO - 2024-05-04 09:49:30 --> Hooks Class Initialized
DEBUG - 2024-05-04 09:49:30 --> UTF-8 Support Enabled
INFO - 2024-05-04 09:49:30 --> Utf8 Class Initialized
INFO - 2024-05-04 09:49:30 --> URI Class Initialized
DEBUG - 2024-05-04 09:49:30 --> No URI present. Default controller set.
INFO - 2024-05-04 09:49:30 --> Router Class Initialized
INFO - 2024-05-04 09:49:30 --> Output Class Initialized
INFO - 2024-05-04 09:49:30 --> Security Class Initialized
DEBUG - 2024-05-04 09:49:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-04 09:49:30 --> Input Class Initialized
INFO - 2024-05-04 09:49:30 --> Language Class Initialized
INFO - 2024-05-04 09:49:30 --> Loader Class Initialized
INFO - 2024-05-04 09:49:30 --> Helper loaded: url_helper
INFO - 2024-05-04 09:49:30 --> Helper loaded: file_helper
INFO - 2024-05-04 09:49:30 --> Helper loaded: html_helper
INFO - 2024-05-04 09:49:30 --> Helper loaded: text_helper
INFO - 2024-05-04 09:49:30 --> Helper loaded: form_helper
INFO - 2024-05-04 09:49:30 --> Helper loaded: lang_helper
INFO - 2024-05-04 09:49:30 --> Helper loaded: security_helper
INFO - 2024-05-04 09:49:30 --> Helper loaded: cookie_helper
INFO - 2024-05-04 09:49:30 --> Database Driver Class Initialized
INFO - 2024-05-04 09:49:30 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-04 09:49:30 --> Parser Class Initialized
INFO - 2024-05-04 09:49:30 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-05-04 09:49:30 --> Pagination Class Initialized
INFO - 2024-05-04 09:49:30 --> Form Validation Class Initialized
INFO - 2024-05-04 09:49:30 --> Controller Class Initialized
INFO - 2024-05-04 09:49:30 --> Model Class Initialized
DEBUG - 2024-05-04 09:49:30 --> Session class already loaded. Second attempt ignored.
ERROR - 2024-05-04 09:49:30 --> $config['composer_autoload'] is set to TRUE but E:\xampp\htdocs\maurnaturo\application\vendor/autoload.php was not found.
INFO - 2024-05-04 09:49:30 --> Config Class Initialized
INFO - 2024-05-04 09:49:30 --> Hooks Class Initialized
DEBUG - 2024-05-04 09:49:30 --> UTF-8 Support Enabled
INFO - 2024-05-04 09:49:30 --> Utf8 Class Initialized
INFO - 2024-05-04 09:49:30 --> URI Class Initialized
INFO - 2024-05-04 09:49:30 --> Router Class Initialized
INFO - 2024-05-04 09:49:30 --> Output Class Initialized
INFO - 2024-05-04 09:49:30 --> Security Class Initialized
DEBUG - 2024-05-04 09:49:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-04 09:49:30 --> Input Class Initialized
INFO - 2024-05-04 09:49:30 --> Language Class Initialized
INFO - 2024-05-04 09:49:30 --> Loader Class Initialized
INFO - 2024-05-04 09:49:30 --> Helper loaded: url_helper
INFO - 2024-05-04 09:49:30 --> Helper loaded: file_helper
INFO - 2024-05-04 09:49:30 --> Helper loaded: html_helper
INFO - 2024-05-04 09:49:30 --> Helper loaded: text_helper
INFO - 2024-05-04 09:49:30 --> Helper loaded: form_helper
INFO - 2024-05-04 09:49:30 --> Helper loaded: lang_helper
INFO - 2024-05-04 09:49:30 --> Helper loaded: security_helper
INFO - 2024-05-04 09:49:30 --> Helper loaded: cookie_helper
INFO - 2024-05-04 09:49:30 --> Database Driver Class Initialized
INFO - 2024-05-04 09:49:30 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-04 09:49:30 --> Parser Class Initialized
INFO - 2024-05-04 09:49:30 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-05-04 09:49:30 --> Pagination Class Initialized
INFO - 2024-05-04 09:49:30 --> Form Validation Class Initialized
INFO - 2024-05-04 09:49:30 --> Controller Class Initialized
INFO - 2024-05-04 09:49:30 --> Model Class Initialized
DEBUG - 2024-05-04 09:49:30 --> Session class already loaded. Second attempt ignored.
INFO - 2024-05-04 09:49:31 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\user/admin_login_form.php
DEBUG - 2024-05-04 09:49:31 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-05-04 09:49:31 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\include/top_menu.php
INFO - 2024-05-04 09:49:31 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\include/admin_loggedin_info.php
INFO - 2024-05-04 09:49:31 --> Model Class Initialized
INFO - 2024-05-04 09:49:31 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\admin_html_template.php
INFO - 2024-05-04 09:49:31 --> Final output sent to browser
DEBUG - 2024-05-04 09:49:31 --> Total execution time: 0.6586
ERROR - 2024-05-04 09:49:36 --> $config['composer_autoload'] is set to TRUE but E:\xampp\htdocs\maurnaturo\application\vendor/autoload.php was not found.
INFO - 2024-05-04 09:49:36 --> Config Class Initialized
INFO - 2024-05-04 09:49:36 --> Hooks Class Initialized
DEBUG - 2024-05-04 09:49:36 --> UTF-8 Support Enabled
INFO - 2024-05-04 09:49:36 --> Utf8 Class Initialized
INFO - 2024-05-04 09:49:36 --> URI Class Initialized
INFO - 2024-05-04 09:49:36 --> Router Class Initialized
INFO - 2024-05-04 09:49:36 --> Output Class Initialized
INFO - 2024-05-04 09:49:36 --> Security Class Initialized
DEBUG - 2024-05-04 09:49:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-04 09:49:36 --> Input Class Initialized
INFO - 2024-05-04 09:49:36 --> Language Class Initialized
INFO - 2024-05-04 09:49:36 --> Loader Class Initialized
INFO - 2024-05-04 09:49:36 --> Helper loaded: url_helper
INFO - 2024-05-04 09:49:36 --> Helper loaded: file_helper
INFO - 2024-05-04 09:49:36 --> Helper loaded: html_helper
INFO - 2024-05-04 09:49:36 --> Helper loaded: text_helper
INFO - 2024-05-04 09:49:36 --> Helper loaded: form_helper
INFO - 2024-05-04 09:49:36 --> Helper loaded: lang_helper
INFO - 2024-05-04 09:49:36 --> Helper loaded: security_helper
INFO - 2024-05-04 09:49:36 --> Helper loaded: cookie_helper
INFO - 2024-05-04 09:49:36 --> Database Driver Class Initialized
INFO - 2024-05-04 09:49:36 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-04 09:49:36 --> Parser Class Initialized
INFO - 2024-05-04 09:49:36 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-05-04 09:49:36 --> Pagination Class Initialized
INFO - 2024-05-04 09:49:36 --> Form Validation Class Initialized
INFO - 2024-05-04 09:49:36 --> Controller Class Initialized
INFO - 2024-05-04 09:49:36 --> Model Class Initialized
DEBUG - 2024-05-04 09:49:36 --> Session class already loaded. Second attempt ignored.
INFO - 2024-05-04 09:49:36 --> Model Class Initialized
INFO - 2024-05-04 09:49:37 --> Final output sent to browser
DEBUG - 2024-05-04 09:49:37 --> Total execution time: 0.3399
ERROR - 2024-05-04 09:49:37 --> $config['composer_autoload'] is set to TRUE but E:\xampp\htdocs\maurnaturo\application\vendor/autoload.php was not found.
INFO - 2024-05-04 09:49:37 --> Config Class Initialized
INFO - 2024-05-04 09:49:37 --> Hooks Class Initialized
DEBUG - 2024-05-04 09:49:37 --> UTF-8 Support Enabled
INFO - 2024-05-04 09:49:37 --> Utf8 Class Initialized
INFO - 2024-05-04 09:49:37 --> URI Class Initialized
INFO - 2024-05-04 09:49:37 --> Router Class Initialized
INFO - 2024-05-04 09:49:37 --> Output Class Initialized
INFO - 2024-05-04 09:49:37 --> Security Class Initialized
DEBUG - 2024-05-04 09:49:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-04 09:49:37 --> Input Class Initialized
INFO - 2024-05-04 09:49:37 --> Language Class Initialized
INFO - 2024-05-04 09:49:37 --> Loader Class Initialized
INFO - 2024-05-04 09:49:37 --> Helper loaded: url_helper
INFO - 2024-05-04 09:49:37 --> Helper loaded: file_helper
INFO - 2024-05-04 09:49:37 --> Helper loaded: html_helper
INFO - 2024-05-04 09:49:37 --> Helper loaded: text_helper
INFO - 2024-05-04 09:49:37 --> Helper loaded: form_helper
INFO - 2024-05-04 09:49:37 --> Helper loaded: lang_helper
INFO - 2024-05-04 09:49:37 --> Helper loaded: security_helper
INFO - 2024-05-04 09:49:37 --> Helper loaded: cookie_helper
INFO - 2024-05-04 09:49:37 --> Database Driver Class Initialized
INFO - 2024-05-04 09:49:37 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-04 09:49:37 --> Parser Class Initialized
INFO - 2024-05-04 09:49:37 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-05-04 09:49:37 --> Pagination Class Initialized
INFO - 2024-05-04 09:49:37 --> Form Validation Class Initialized
INFO - 2024-05-04 09:49:37 --> Controller Class Initialized
INFO - 2024-05-04 09:49:37 --> Model Class Initialized
DEBUG - 2024-05-04 09:49:37 --> Session class already loaded. Second attempt ignored.
INFO - 2024-05-04 09:49:37 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\user/admin_login_form.php
DEBUG - 2024-05-04 09:49:37 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-05-04 09:49:37 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\include/top_menu.php
INFO - 2024-05-04 09:49:37 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\include/admin_loggedin_info.php
INFO - 2024-05-04 09:49:37 --> Model Class Initialized
INFO - 2024-05-04 09:49:37 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\admin_html_template.php
INFO - 2024-05-04 09:49:37 --> Final output sent to browser
DEBUG - 2024-05-04 09:49:37 --> Total execution time: 0.1175
ERROR - 2024-05-04 09:49:47 --> $config['composer_autoload'] is set to TRUE but E:\xampp\htdocs\maurnaturo\application\vendor/autoload.php was not found.
INFO - 2024-05-04 09:49:47 --> Config Class Initialized
INFO - 2024-05-04 09:49:47 --> Hooks Class Initialized
DEBUG - 2024-05-04 09:49:47 --> UTF-8 Support Enabled
INFO - 2024-05-04 09:49:47 --> Utf8 Class Initialized
INFO - 2024-05-04 09:49:47 --> URI Class Initialized
INFO - 2024-05-04 09:49:47 --> Router Class Initialized
INFO - 2024-05-04 09:49:47 --> Output Class Initialized
INFO - 2024-05-04 09:49:47 --> Security Class Initialized
DEBUG - 2024-05-04 09:49:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-04 09:49:47 --> Input Class Initialized
INFO - 2024-05-04 09:49:47 --> Language Class Initialized
INFO - 2024-05-04 09:49:47 --> Loader Class Initialized
INFO - 2024-05-04 09:49:47 --> Helper loaded: url_helper
INFO - 2024-05-04 09:49:47 --> Helper loaded: file_helper
INFO - 2024-05-04 09:49:47 --> Helper loaded: html_helper
INFO - 2024-05-04 09:49:47 --> Helper loaded: text_helper
INFO - 2024-05-04 09:49:47 --> Helper loaded: form_helper
INFO - 2024-05-04 09:49:47 --> Helper loaded: lang_helper
INFO - 2024-05-04 09:49:47 --> Helper loaded: security_helper
INFO - 2024-05-04 09:49:47 --> Helper loaded: cookie_helper
INFO - 2024-05-04 09:49:47 --> Database Driver Class Initialized
INFO - 2024-05-04 09:49:47 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-04 09:49:47 --> Parser Class Initialized
INFO - 2024-05-04 09:49:47 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-05-04 09:49:47 --> Pagination Class Initialized
INFO - 2024-05-04 09:49:47 --> Form Validation Class Initialized
INFO - 2024-05-04 09:49:47 --> Controller Class Initialized
INFO - 2024-05-04 09:49:47 --> Model Class Initialized
DEBUG - 2024-05-04 09:49:47 --> Session class already loaded. Second attempt ignored.
INFO - 2024-05-04 09:49:47 --> Model Class Initialized
INFO - 2024-05-04 09:49:48 --> Final output sent to browser
DEBUG - 2024-05-04 09:49:48 --> Total execution time: 0.9704
ERROR - 2024-05-04 09:49:48 --> $config['composer_autoload'] is set to TRUE but E:\xampp\htdocs\maurnaturo\application\vendor/autoload.php was not found.
INFO - 2024-05-04 09:49:48 --> Config Class Initialized
INFO - 2024-05-04 09:49:48 --> Hooks Class Initialized
DEBUG - 2024-05-04 09:49:48 --> UTF-8 Support Enabled
INFO - 2024-05-04 09:49:48 --> Utf8 Class Initialized
INFO - 2024-05-04 09:49:48 --> URI Class Initialized
DEBUG - 2024-05-04 09:49:48 --> No URI present. Default controller set.
INFO - 2024-05-04 09:49:48 --> Router Class Initialized
INFO - 2024-05-04 09:49:48 --> Output Class Initialized
INFO - 2024-05-04 09:49:48 --> Security Class Initialized
DEBUG - 2024-05-04 09:49:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-04 09:49:48 --> Input Class Initialized
INFO - 2024-05-04 09:49:48 --> Language Class Initialized
INFO - 2024-05-04 09:49:48 --> Loader Class Initialized
INFO - 2024-05-04 09:49:48 --> Helper loaded: url_helper
INFO - 2024-05-04 09:49:48 --> Helper loaded: file_helper
INFO - 2024-05-04 09:49:48 --> Helper loaded: html_helper
INFO - 2024-05-04 09:49:48 --> Helper loaded: text_helper
INFO - 2024-05-04 09:49:48 --> Helper loaded: form_helper
INFO - 2024-05-04 09:49:48 --> Helper loaded: lang_helper
INFO - 2024-05-04 09:49:48 --> Helper loaded: security_helper
INFO - 2024-05-04 09:49:48 --> Helper loaded: cookie_helper
INFO - 2024-05-04 09:49:48 --> Database Driver Class Initialized
ERROR - 2024-05-04 09:49:48 --> $config['composer_autoload'] is set to TRUE but E:\xampp\htdocs\maurnaturo\application\vendor/autoload.php was not found.
INFO - 2024-05-04 09:49:48 --> Config Class Initialized
INFO - 2024-05-04 09:49:48 --> Hooks Class Initialized
INFO - 2024-05-04 09:49:48 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-04 09:49:48 --> Parser Class Initialized
DEBUG - 2024-05-04 09:49:48 --> UTF-8 Support Enabled
INFO - 2024-05-04 09:49:48 --> Utf8 Class Initialized
INFO - 2024-05-04 09:49:48 --> URI Class Initialized
INFO - 2024-05-04 09:49:48 --> Router Class Initialized
INFO - 2024-05-04 09:49:48 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-05-04 09:49:48 --> Pagination Class Initialized
INFO - 2024-05-04 09:49:48 --> Output Class Initialized
INFO - 2024-05-04 09:49:48 --> Form Validation Class Initialized
INFO - 2024-05-04 09:49:48 --> Controller Class Initialized
INFO - 2024-05-04 09:49:48 --> Security Class Initialized
INFO - 2024-05-04 09:49:48 --> Model Class Initialized
DEBUG - 2024-05-04 09:49:48 --> Session class already loaded. Second attempt ignored.
DEBUG - 2024-05-04 09:49:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-04 09:49:48 --> Input Class Initialized
INFO - 2024-05-04 09:49:48 --> Language Class Initialized
INFO - 2024-05-04 09:49:48 --> Loader Class Initialized
INFO - 2024-05-04 09:49:48 --> Model Class Initialized
DEBUG - 2024-05-04 09:49:48 --> Session class already loaded. Second attempt ignored.
INFO - 2024-05-04 09:49:48 --> Helper loaded: url_helper
INFO - 2024-05-04 09:49:48 --> Model Class Initialized
INFO - 2024-05-04 09:49:48 --> Helper loaded: file_helper
INFO - 2024-05-04 09:49:48 --> Helper loaded: html_helper
INFO - 2024-05-04 09:49:48 --> Model Class Initialized
INFO - 2024-05-04 09:49:48 --> Helper loaded: text_helper
INFO - 2024-05-04 09:49:48 --> Model Class Initialized
INFO - 2024-05-04 09:49:48 --> Helper loaded: form_helper
INFO - 2024-05-04 09:49:48 --> Helper loaded: lang_helper
INFO - 2024-05-04 09:49:48 --> Helper loaded: security_helper
INFO - 2024-05-04 09:49:48 --> Helper loaded: cookie_helper
INFO - 2024-05-04 09:49:48 --> Model Class Initialized
DEBUG - 2024-05-04 09:49:48 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-05-04 09:49:48 --> Session class already loaded. Second attempt ignored.
INFO - 2024-05-04 09:49:48 --> Database Driver Class Initialized
INFO - 2024-05-04 09:49:48 --> Model Class Initialized
INFO - 2024-05-04 09:49:48 --> Model Class Initialized
ERROR - 2024-05-04 09:49:56 --> $config['composer_autoload'] is set to TRUE but E:\xampp\htdocs\maurnaturo\application\vendor/autoload.php was not found.
INFO - 2024-05-04 09:49:56 --> Config Class Initialized
INFO - 2024-05-04 09:49:56 --> Hooks Class Initialized
DEBUG - 2024-05-04 09:49:56 --> UTF-8 Support Enabled
INFO - 2024-05-04 09:49:56 --> Utf8 Class Initialized
INFO - 2024-05-04 09:49:56 --> URI Class Initialized
INFO - 2024-05-04 09:49:56 --> Router Class Initialized
INFO - 2024-05-04 09:49:56 --> Output Class Initialized
INFO - 2024-05-04 09:49:56 --> Security Class Initialized
DEBUG - 2024-05-04 09:49:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-04 09:49:56 --> Input Class Initialized
INFO - 2024-05-04 09:49:56 --> Language Class Initialized
INFO - 2024-05-04 09:49:56 --> Loader Class Initialized
INFO - 2024-05-04 09:49:56 --> Helper loaded: url_helper
INFO - 2024-05-04 09:49:56 --> Helper loaded: file_helper
INFO - 2024-05-04 09:49:56 --> Helper loaded: html_helper
INFO - 2024-05-04 09:49:56 --> Helper loaded: text_helper
INFO - 2024-05-04 09:49:56 --> Helper loaded: form_helper
INFO - 2024-05-04 09:49:56 --> Helper loaded: lang_helper
INFO - 2024-05-04 09:49:56 --> Helper loaded: security_helper
INFO - 2024-05-04 09:49:56 --> Helper loaded: cookie_helper
INFO - 2024-05-04 09:49:56 --> Database Driver Class Initialized
INFO - 2024-05-04 09:49:58 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\include/admin_home.php
DEBUG - 2024-05-04 09:49:58 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-05-04 09:49:58 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\include/top_menu.php
INFO - 2024-05-04 09:49:58 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\include/admin_loggedin_info.php
INFO - 2024-05-04 09:49:58 --> Model Class Initialized
INFO - 2024-05-04 09:49:59 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\include/admin_header.php
INFO - 2024-05-04 09:49:59 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\include/admin_footer.php
INFO - 2024-05-04 09:49:59 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\admin_html_template.php
INFO - 2024-05-04 09:49:59 --> Final output sent to browser
DEBUG - 2024-05-04 09:49:59 --> Total execution time: 10.6006
INFO - 2024-05-04 09:49:59 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-04 09:49:59 --> Parser Class Initialized
INFO - 2024-05-04 09:49:59 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-05-04 09:49:59 --> Pagination Class Initialized
INFO - 2024-05-04 09:49:59 --> Form Validation Class Initialized
INFO - 2024-05-04 09:49:59 --> Controller Class Initialized
INFO - 2024-05-04 09:49:59 --> Model Class Initialized
DEBUG - 2024-05-04 09:49:59 --> Session class already loaded. Second attempt ignored.
INFO - 2024-05-04 09:49:59 --> Model Class Initialized
INFO - 2024-05-04 09:49:59 --> Final output sent to browser
DEBUG - 2024-05-04 09:49:59 --> Total execution time: 10.5631
INFO - 2024-05-04 09:49:59 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-04 09:49:59 --> Parser Class Initialized
INFO - 2024-05-04 09:49:59 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-05-04 09:49:59 --> Pagination Class Initialized
INFO - 2024-05-04 09:49:59 --> Form Validation Class Initialized
INFO - 2024-05-04 09:49:59 --> Controller Class Initialized
INFO - 2024-05-04 09:49:59 --> Model Class Initialized
DEBUG - 2024-05-04 09:49:59 --> Session class already loaded. Second attempt ignored.
INFO - 2024-05-04 09:49:59 --> Model Class Initialized
INFO - 2024-05-04 09:49:59 --> Final output sent to browser
DEBUG - 2024-05-04 09:49:59 --> Total execution time: 2.4752
ERROR - 2024-05-04 09:49:59 --> $config['composer_autoload'] is set to TRUE but E:\xampp\htdocs\maurnaturo\application\vendor/autoload.php was not found.
INFO - 2024-05-04 09:49:59 --> Config Class Initialized
INFO - 2024-05-04 09:49:59 --> Hooks Class Initialized
DEBUG - 2024-05-04 09:49:59 --> UTF-8 Support Enabled
INFO - 2024-05-04 09:49:59 --> Utf8 Class Initialized
INFO - 2024-05-04 09:49:59 --> URI Class Initialized
DEBUG - 2024-05-04 09:49:59 --> No URI present. Default controller set.
INFO - 2024-05-04 09:49:59 --> Router Class Initialized
INFO - 2024-05-04 09:49:59 --> Output Class Initialized
INFO - 2024-05-04 09:49:59 --> Security Class Initialized
DEBUG - 2024-05-04 09:49:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-04 09:49:59 --> Input Class Initialized
INFO - 2024-05-04 09:49:59 --> Language Class Initialized
INFO - 2024-05-04 09:49:59 --> Loader Class Initialized
INFO - 2024-05-04 09:49:59 --> Helper loaded: url_helper
INFO - 2024-05-04 09:49:59 --> Helper loaded: file_helper
INFO - 2024-05-04 09:49:59 --> Helper loaded: html_helper
INFO - 2024-05-04 09:49:59 --> Helper loaded: text_helper
INFO - 2024-05-04 09:49:59 --> Helper loaded: form_helper
INFO - 2024-05-04 09:49:59 --> Helper loaded: lang_helper
INFO - 2024-05-04 09:49:59 --> Helper loaded: security_helper
INFO - 2024-05-04 09:49:59 --> Helper loaded: cookie_helper
INFO - 2024-05-04 09:49:59 --> Database Driver Class Initialized
INFO - 2024-05-04 09:49:59 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-04 09:49:59 --> Parser Class Initialized
INFO - 2024-05-04 09:49:59 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-05-04 09:49:59 --> Pagination Class Initialized
INFO - 2024-05-04 09:49:59 --> Form Validation Class Initialized
INFO - 2024-05-04 09:49:59 --> Controller Class Initialized
INFO - 2024-05-04 09:49:59 --> Model Class Initialized
DEBUG - 2024-05-04 09:49:59 --> Session class already loaded. Second attempt ignored.
INFO - 2024-05-04 09:49:59 --> Model Class Initialized
DEBUG - 2024-05-04 09:49:59 --> Session class already loaded. Second attempt ignored.
INFO - 2024-05-04 09:49:59 --> Model Class Initialized
INFO - 2024-05-04 09:49:59 --> Model Class Initialized
INFO - 2024-05-04 09:49:59 --> Model Class Initialized
INFO - 2024-05-04 09:49:59 --> Model Class Initialized
DEBUG - 2024-05-04 09:49:59 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-05-04 09:49:59 --> Session class already loaded. Second attempt ignored.
INFO - 2024-05-04 09:49:59 --> Model Class Initialized
INFO - 2024-05-04 09:49:59 --> Model Class Initialized
INFO - 2024-05-04 09:50:00 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\include/admin_home.php
DEBUG - 2024-05-04 09:50:00 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-05-04 09:50:00 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\include/top_menu.php
INFO - 2024-05-04 09:50:00 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\include/admin_loggedin_info.php
INFO - 2024-05-04 09:50:00 --> Model Class Initialized
INFO - 2024-05-04 09:50:01 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\include/admin_header.php
INFO - 2024-05-04 09:50:01 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\include/admin_footer.php
INFO - 2024-05-04 09:50:01 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\admin_html_template.php
INFO - 2024-05-04 09:50:01 --> Final output sent to browser
DEBUG - 2024-05-04 09:50:01 --> Total execution time: 2.4467
ERROR - 2024-05-04 09:50:02 --> $config['composer_autoload'] is set to TRUE but E:\xampp\htdocs\maurnaturo\application\vendor/autoload.php was not found.
INFO - 2024-05-04 09:50:02 --> Config Class Initialized
INFO - 2024-05-04 09:50:02 --> Hooks Class Initialized
DEBUG - 2024-05-04 09:50:02 --> UTF-8 Support Enabled
INFO - 2024-05-04 09:50:02 --> Utf8 Class Initialized
INFO - 2024-05-04 09:50:02 --> URI Class Initialized
INFO - 2024-05-04 09:50:02 --> Router Class Initialized
INFO - 2024-05-04 09:50:02 --> Output Class Initialized
INFO - 2024-05-04 09:50:02 --> Security Class Initialized
DEBUG - 2024-05-04 09:50:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-04 09:50:02 --> Input Class Initialized
INFO - 2024-05-04 09:50:02 --> Language Class Initialized
INFO - 2024-05-04 09:50:02 --> Loader Class Initialized
INFO - 2024-05-04 09:50:02 --> Helper loaded: url_helper
INFO - 2024-05-04 09:50:02 --> Helper loaded: file_helper
INFO - 2024-05-04 09:50:02 --> Helper loaded: html_helper
INFO - 2024-05-04 09:50:02 --> Helper loaded: text_helper
INFO - 2024-05-04 09:50:02 --> Helper loaded: form_helper
INFO - 2024-05-04 09:50:02 --> Helper loaded: lang_helper
INFO - 2024-05-04 09:50:02 --> Helper loaded: security_helper
INFO - 2024-05-04 09:50:02 --> Helper loaded: cookie_helper
INFO - 2024-05-04 09:50:02 --> Database Driver Class Initialized
INFO - 2024-05-04 09:50:02 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-04 09:50:02 --> Parser Class Initialized
INFO - 2024-05-04 09:50:02 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-05-04 09:50:02 --> Pagination Class Initialized
INFO - 2024-05-04 09:50:02 --> Form Validation Class Initialized
INFO - 2024-05-04 09:50:02 --> Controller Class Initialized
DEBUG - 2024-05-04 09:50:02 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-05-04 09:50:02 --> Session class already loaded. Second attempt ignored.
INFO - 2024-05-04 09:50:02 --> Model Class Initialized
INFO - 2024-05-04 09:50:02 --> Final output sent to browser
DEBUG - 2024-05-04 09:50:02 --> Total execution time: 0.0825
ERROR - 2024-05-04 09:50:11 --> $config['composer_autoload'] is set to TRUE but E:\xampp\htdocs\maurnaturo\application\vendor/autoload.php was not found.
INFO - 2024-05-04 09:50:11 --> Config Class Initialized
INFO - 2024-05-04 09:50:11 --> Hooks Class Initialized
DEBUG - 2024-05-04 09:50:11 --> UTF-8 Support Enabled
INFO - 2024-05-04 09:50:11 --> Utf8 Class Initialized
INFO - 2024-05-04 09:50:11 --> URI Class Initialized
INFO - 2024-05-04 09:50:11 --> Router Class Initialized
INFO - 2024-05-04 09:50:11 --> Output Class Initialized
INFO - 2024-05-04 09:50:11 --> Security Class Initialized
DEBUG - 2024-05-04 09:50:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-04 09:50:11 --> Input Class Initialized
INFO - 2024-05-04 09:50:11 --> Language Class Initialized
INFO - 2024-05-04 09:50:11 --> Loader Class Initialized
INFO - 2024-05-04 09:50:11 --> Helper loaded: url_helper
INFO - 2024-05-04 09:50:11 --> Helper loaded: file_helper
INFO - 2024-05-04 09:50:11 --> Helper loaded: html_helper
INFO - 2024-05-04 09:50:11 --> Helper loaded: text_helper
INFO - 2024-05-04 09:50:11 --> Helper loaded: form_helper
INFO - 2024-05-04 09:50:11 --> Helper loaded: lang_helper
INFO - 2024-05-04 09:50:11 --> Helper loaded: security_helper
INFO - 2024-05-04 09:50:11 --> Helper loaded: cookie_helper
INFO - 2024-05-04 09:50:11 --> Database Driver Class Initialized
INFO - 2024-05-04 09:50:11 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-04 09:50:11 --> Parser Class Initialized
INFO - 2024-05-04 09:50:11 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-05-04 09:50:11 --> Pagination Class Initialized
INFO - 2024-05-04 09:50:11 --> Form Validation Class Initialized
INFO - 2024-05-04 09:50:11 --> Controller Class Initialized
DEBUG - 2024-05-04 09:50:11 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-05-04 09:50:11 --> Session class already loaded. Second attempt ignored.
INFO - 2024-05-04 09:50:11 --> Model Class Initialized
INFO - 2024-05-04 09:50:11 --> Model Class Initialized
DEBUG - 2024-05-04 09:50:11 --> Lmr class already loaded. Second attempt ignored.
INFO - 2024-05-04 09:50:11 --> Model Class Initialized
INFO - 2024-05-04 09:50:11 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\mr/mr.php
DEBUG - 2024-05-04 09:50:11 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-05-04 09:50:11 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\include/top_menu.php
INFO - 2024-05-04 09:50:11 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\include/admin_loggedin_info.php
INFO - 2024-05-04 09:50:11 --> Model Class Initialized
INFO - 2024-05-04 09:50:11 --> Model Class Initialized
INFO - 2024-05-04 09:50:11 --> Model Class Initialized
INFO - 2024-05-04 09:50:12 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\include/admin_header.php
INFO - 2024-05-04 09:50:12 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\include/admin_footer.php
INFO - 2024-05-04 09:50:12 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\admin_html_template.php
INFO - 2024-05-04 09:50:12 --> Final output sent to browser
DEBUG - 2024-05-04 09:50:12 --> Total execution time: 1.2004
ERROR - 2024-05-04 09:50:12 --> $config['composer_autoload'] is set to TRUE but E:\xampp\htdocs\maurnaturo\application\vendor/autoload.php was not found.
INFO - 2024-05-04 09:50:12 --> Config Class Initialized
INFO - 2024-05-04 09:50:12 --> Hooks Class Initialized
DEBUG - 2024-05-04 09:50:12 --> UTF-8 Support Enabled
INFO - 2024-05-04 09:50:12 --> Utf8 Class Initialized
INFO - 2024-05-04 09:50:12 --> URI Class Initialized
INFO - 2024-05-04 09:50:12 --> Router Class Initialized
INFO - 2024-05-04 09:50:12 --> Output Class Initialized
INFO - 2024-05-04 09:50:12 --> Security Class Initialized
DEBUG - 2024-05-04 09:50:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-04 09:50:12 --> Input Class Initialized
INFO - 2024-05-04 09:50:12 --> Language Class Initialized
INFO - 2024-05-04 09:50:12 --> Loader Class Initialized
INFO - 2024-05-04 09:50:12 --> Helper loaded: url_helper
INFO - 2024-05-04 09:50:12 --> Helper loaded: file_helper
INFO - 2024-05-04 09:50:12 --> Helper loaded: html_helper
INFO - 2024-05-04 09:50:12 --> Helper loaded: text_helper
INFO - 2024-05-04 09:50:12 --> Helper loaded: form_helper
INFO - 2024-05-04 09:50:12 --> Helper loaded: lang_helper
INFO - 2024-05-04 09:50:12 --> Helper loaded: security_helper
INFO - 2024-05-04 09:50:12 --> Helper loaded: cookie_helper
INFO - 2024-05-04 09:50:12 --> Database Driver Class Initialized
INFO - 2024-05-04 09:50:12 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-04 09:50:12 --> Parser Class Initialized
INFO - 2024-05-04 09:50:12 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-05-04 09:50:12 --> Pagination Class Initialized
INFO - 2024-05-04 09:50:12 --> Form Validation Class Initialized
INFO - 2024-05-04 09:50:12 --> Controller Class Initialized
DEBUG - 2024-05-04 09:50:12 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-05-04 09:50:12 --> Session class already loaded. Second attempt ignored.
INFO - 2024-05-04 09:50:12 --> Model Class Initialized
INFO - 2024-05-04 09:50:12 --> Model Class Initialized
INFO - 2024-05-04 09:50:12 --> Final output sent to browser
DEBUG - 2024-05-04 09:50:12 --> Total execution time: 0.1568
ERROR - 2024-05-04 09:50:36 --> $config['composer_autoload'] is set to TRUE but E:\xampp\htdocs\maurnaturo\application\vendor/autoload.php was not found.
INFO - 2024-05-04 09:50:36 --> Config Class Initialized
INFO - 2024-05-04 09:50:36 --> Hooks Class Initialized
DEBUG - 2024-05-04 09:50:36 --> UTF-8 Support Enabled
INFO - 2024-05-04 09:50:36 --> Utf8 Class Initialized
INFO - 2024-05-04 09:50:36 --> URI Class Initialized
DEBUG - 2024-05-04 09:50:36 --> No URI present. Default controller set.
INFO - 2024-05-04 09:50:36 --> Router Class Initialized
INFO - 2024-05-04 09:50:36 --> Output Class Initialized
INFO - 2024-05-04 09:50:36 --> Security Class Initialized
DEBUG - 2024-05-04 09:50:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-04 09:50:36 --> Input Class Initialized
INFO - 2024-05-04 09:50:36 --> Language Class Initialized
INFO - 2024-05-04 09:50:36 --> Loader Class Initialized
INFO - 2024-05-04 09:50:36 --> Helper loaded: url_helper
INFO - 2024-05-04 09:50:36 --> Helper loaded: file_helper
INFO - 2024-05-04 09:50:36 --> Helper loaded: html_helper
INFO - 2024-05-04 09:50:36 --> Helper loaded: text_helper
INFO - 2024-05-04 09:50:36 --> Helper loaded: form_helper
INFO - 2024-05-04 09:50:36 --> Helper loaded: lang_helper
INFO - 2024-05-04 09:50:36 --> Helper loaded: security_helper
INFO - 2024-05-04 09:50:37 --> Helper loaded: cookie_helper
INFO - 2024-05-04 09:50:37 --> Database Driver Class Initialized
INFO - 2024-05-04 09:50:37 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-04 09:50:37 --> Parser Class Initialized
INFO - 2024-05-04 09:50:37 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-05-04 09:50:37 --> Pagination Class Initialized
INFO - 2024-05-04 09:50:37 --> Form Validation Class Initialized
INFO - 2024-05-04 09:50:37 --> Controller Class Initialized
INFO - 2024-05-04 09:50:37 --> Model Class Initialized
DEBUG - 2024-05-04 09:50:37 --> Session class already loaded. Second attempt ignored.
ERROR - 2024-05-04 09:50:37 --> $config['composer_autoload'] is set to TRUE but E:\xampp\htdocs\maurnaturo\application\vendor/autoload.php was not found.
INFO - 2024-05-04 09:50:37 --> Config Class Initialized
INFO - 2024-05-04 09:50:37 --> Hooks Class Initialized
DEBUG - 2024-05-04 09:50:37 --> UTF-8 Support Enabled
INFO - 2024-05-04 09:50:37 --> Utf8 Class Initialized
INFO - 2024-05-04 09:50:37 --> URI Class Initialized
INFO - 2024-05-04 09:50:37 --> Router Class Initialized
INFO - 2024-05-04 09:50:37 --> Output Class Initialized
INFO - 2024-05-04 09:50:37 --> Security Class Initialized
DEBUG - 2024-05-04 09:50:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-04 09:50:37 --> Input Class Initialized
INFO - 2024-05-04 09:50:37 --> Language Class Initialized
INFO - 2024-05-04 09:50:37 --> Loader Class Initialized
INFO - 2024-05-04 09:50:37 --> Helper loaded: url_helper
INFO - 2024-05-04 09:50:37 --> Helper loaded: file_helper
INFO - 2024-05-04 09:50:37 --> Helper loaded: html_helper
INFO - 2024-05-04 09:50:37 --> Helper loaded: text_helper
INFO - 2024-05-04 09:50:37 --> Helper loaded: form_helper
INFO - 2024-05-04 09:50:37 --> Helper loaded: lang_helper
INFO - 2024-05-04 09:50:37 --> Helper loaded: security_helper
INFO - 2024-05-04 09:50:37 --> Helper loaded: cookie_helper
INFO - 2024-05-04 09:50:37 --> Database Driver Class Initialized
INFO - 2024-05-04 09:50:37 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-04 09:50:37 --> Parser Class Initialized
INFO - 2024-05-04 09:50:37 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-05-04 09:50:37 --> Pagination Class Initialized
INFO - 2024-05-04 09:50:37 --> Form Validation Class Initialized
INFO - 2024-05-04 09:50:37 --> Controller Class Initialized
INFO - 2024-05-04 09:50:37 --> Model Class Initialized
DEBUG - 2024-05-04 09:50:37 --> Session class already loaded. Second attempt ignored.
INFO - 2024-05-04 09:50:37 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\user/admin_login_form.php
DEBUG - 2024-05-04 09:50:37 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-05-04 09:50:37 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\include/top_menu.php
INFO - 2024-05-04 09:50:37 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\include/admin_loggedin_info.php
INFO - 2024-05-04 09:50:37 --> Model Class Initialized
INFO - 2024-05-04 09:50:37 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\admin_html_template.php
INFO - 2024-05-04 09:50:37 --> Final output sent to browser
DEBUG - 2024-05-04 09:50:37 --> Total execution time: 0.1373
ERROR - 2024-05-04 09:50:47 --> $config['composer_autoload'] is set to TRUE but E:\xampp\htdocs\maurnaturo\application\vendor/autoload.php was not found.
INFO - 2024-05-04 09:50:47 --> Config Class Initialized
INFO - 2024-05-04 09:50:47 --> Hooks Class Initialized
DEBUG - 2024-05-04 09:50:47 --> UTF-8 Support Enabled
INFO - 2024-05-04 09:50:47 --> Utf8 Class Initialized
INFO - 2024-05-04 09:50:47 --> URI Class Initialized
INFO - 2024-05-04 09:50:47 --> Router Class Initialized
INFO - 2024-05-04 09:50:47 --> Output Class Initialized
INFO - 2024-05-04 09:50:47 --> Security Class Initialized
DEBUG - 2024-05-04 09:50:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-04 09:50:47 --> Input Class Initialized
INFO - 2024-05-04 09:50:47 --> Language Class Initialized
INFO - 2024-05-04 09:50:47 --> Loader Class Initialized
INFO - 2024-05-04 09:50:47 --> Helper loaded: url_helper
INFO - 2024-05-04 09:50:47 --> Helper loaded: file_helper
INFO - 2024-05-04 09:50:47 --> Helper loaded: html_helper
INFO - 2024-05-04 09:50:47 --> Helper loaded: text_helper
INFO - 2024-05-04 09:50:47 --> Helper loaded: form_helper
INFO - 2024-05-04 09:50:47 --> Helper loaded: lang_helper
INFO - 2024-05-04 09:50:47 --> Helper loaded: security_helper
INFO - 2024-05-04 09:50:47 --> Helper loaded: cookie_helper
INFO - 2024-05-04 09:50:47 --> Database Driver Class Initialized
INFO - 2024-05-04 09:50:47 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-04 09:50:47 --> Parser Class Initialized
INFO - 2024-05-04 09:50:47 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-05-04 09:50:47 --> Pagination Class Initialized
INFO - 2024-05-04 09:50:47 --> Form Validation Class Initialized
INFO - 2024-05-04 09:50:47 --> Controller Class Initialized
INFO - 2024-05-04 09:50:47 --> Model Class Initialized
DEBUG - 2024-05-04 09:50:47 --> Session class already loaded. Second attempt ignored.
INFO - 2024-05-04 09:50:47 --> Model Class Initialized
INFO - 2024-05-04 09:50:47 --> Final output sent to browser
DEBUG - 2024-05-04 09:50:47 --> Total execution time: 0.0993
ERROR - 2024-05-04 09:50:47 --> $config['composer_autoload'] is set to TRUE but E:\xampp\htdocs\maurnaturo\application\vendor/autoload.php was not found.
INFO - 2024-05-04 09:50:47 --> Config Class Initialized
INFO - 2024-05-04 09:50:47 --> Hooks Class Initialized
DEBUG - 2024-05-04 09:50:47 --> UTF-8 Support Enabled
INFO - 2024-05-04 09:50:47 --> Utf8 Class Initialized
INFO - 2024-05-04 09:50:47 --> URI Class Initialized
DEBUG - 2024-05-04 09:50:47 --> No URI present. Default controller set.
INFO - 2024-05-04 09:50:47 --> Router Class Initialized
INFO - 2024-05-04 09:50:47 --> Output Class Initialized
INFO - 2024-05-04 09:50:47 --> Security Class Initialized
DEBUG - 2024-05-04 09:50:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-04 09:50:47 --> Input Class Initialized
INFO - 2024-05-04 09:50:47 --> Language Class Initialized
INFO - 2024-05-04 09:50:47 --> Loader Class Initialized
INFO - 2024-05-04 09:50:47 --> Helper loaded: url_helper
INFO - 2024-05-04 09:50:47 --> Helper loaded: file_helper
INFO - 2024-05-04 09:50:47 --> Helper loaded: html_helper
INFO - 2024-05-04 09:50:47 --> Helper loaded: text_helper
INFO - 2024-05-04 09:50:47 --> Helper loaded: form_helper
INFO - 2024-05-04 09:50:47 --> Helper loaded: lang_helper
INFO - 2024-05-04 09:50:47 --> Helper loaded: security_helper
INFO - 2024-05-04 09:50:47 --> Helper loaded: cookie_helper
INFO - 2024-05-04 09:50:47 --> Database Driver Class Initialized
INFO - 2024-05-04 09:50:47 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-04 09:50:47 --> Parser Class Initialized
INFO - 2024-05-04 09:50:47 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-05-04 09:50:47 --> Pagination Class Initialized
INFO - 2024-05-04 09:50:47 --> Form Validation Class Initialized
INFO - 2024-05-04 09:50:47 --> Controller Class Initialized
INFO - 2024-05-04 09:50:47 --> Model Class Initialized
DEBUG - 2024-05-04 09:50:47 --> Session class already loaded. Second attempt ignored.
INFO - 2024-05-04 09:50:47 --> Model Class Initialized
DEBUG - 2024-05-04 09:50:47 --> Session class already loaded. Second attempt ignored.
INFO - 2024-05-04 09:50:47 --> Model Class Initialized
INFO - 2024-05-04 09:50:47 --> Model Class Initialized
INFO - 2024-05-04 09:50:47 --> Model Class Initialized
INFO - 2024-05-04 09:50:47 --> Model Class Initialized
DEBUG - 2024-05-04 09:50:47 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-05-04 09:50:47 --> Session class already loaded. Second attempt ignored.
INFO - 2024-05-04 09:50:47 --> Model Class Initialized
INFO - 2024-05-04 09:50:47 --> Model Class Initialized
INFO - 2024-05-04 09:50:48 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\include/admin_home.php
DEBUG - 2024-05-04 09:50:48 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-05-04 09:50:48 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\include/top_menu.php
INFO - 2024-05-04 09:50:48 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\include/admin_loggedin_info.php
INFO - 2024-05-04 09:50:48 --> Model Class Initialized
INFO - 2024-05-04 09:50:49 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\include/admin_header.php
INFO - 2024-05-04 09:50:49 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\include/admin_footer.php
INFO - 2024-05-04 09:50:49 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\admin_html_template.php
INFO - 2024-05-04 09:50:49 --> Final output sent to browser
DEBUG - 2024-05-04 09:50:49 --> Total execution time: 1.7111
ERROR - 2024-05-04 09:55:44 --> $config['composer_autoload'] is set to TRUE but E:\xampp\htdocs\maurnaturo\application\vendor/autoload.php was not found.
INFO - 2024-05-04 09:55:44 --> Config Class Initialized
INFO - 2024-05-04 09:55:44 --> Hooks Class Initialized
DEBUG - 2024-05-04 09:55:44 --> UTF-8 Support Enabled
INFO - 2024-05-04 09:55:44 --> Utf8 Class Initialized
INFO - 2024-05-04 09:55:44 --> URI Class Initialized
INFO - 2024-05-04 09:55:44 --> Router Class Initialized
INFO - 2024-05-04 09:55:44 --> Output Class Initialized
INFO - 2024-05-04 09:55:44 --> Security Class Initialized
DEBUG - 2024-05-04 09:55:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-04 09:55:44 --> Input Class Initialized
INFO - 2024-05-04 09:55:44 --> Language Class Initialized
INFO - 2024-05-04 09:55:44 --> Loader Class Initialized
INFO - 2024-05-04 09:55:44 --> Helper loaded: url_helper
INFO - 2024-05-04 09:55:44 --> Helper loaded: file_helper
INFO - 2024-05-04 09:55:44 --> Helper loaded: html_helper
INFO - 2024-05-04 09:55:44 --> Helper loaded: text_helper
INFO - 2024-05-04 09:55:44 --> Helper loaded: form_helper
INFO - 2024-05-04 09:55:44 --> Helper loaded: lang_helper
INFO - 2024-05-04 09:55:44 --> Helper loaded: security_helper
INFO - 2024-05-04 09:55:44 --> Helper loaded: cookie_helper
INFO - 2024-05-04 09:55:44 --> Database Driver Class Initialized
INFO - 2024-05-04 09:55:44 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-04 09:55:44 --> Parser Class Initialized
INFO - 2024-05-04 09:55:44 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-05-04 09:55:44 --> Pagination Class Initialized
INFO - 2024-05-04 09:55:44 --> Form Validation Class Initialized
INFO - 2024-05-04 09:55:44 --> Controller Class Initialized
DEBUG - 2024-05-04 09:55:44 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-05-04 09:55:44 --> Session class already loaded. Second attempt ignored.
INFO - 2024-05-04 09:55:44 --> Model Class Initialized
INFO - 2024-05-04 09:55:44 --> Model Class Initialized
DEBUG - 2024-05-04 09:55:44 --> Lmr class already loaded. Second attempt ignored.
INFO - 2024-05-04 09:55:44 --> Model Class Initialized
INFO - 2024-05-04 09:55:44 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\mr/mr.php
DEBUG - 2024-05-04 09:55:44 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-05-04 09:55:44 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\include/top_menu.php
INFO - 2024-05-04 09:55:44 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\include/admin_loggedin_info.php
INFO - 2024-05-04 09:55:44 --> Model Class Initialized
INFO - 2024-05-04 09:55:44 --> Model Class Initialized
INFO - 2024-05-04 09:55:44 --> Model Class Initialized
INFO - 2024-05-04 09:55:45 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\include/admin_header.php
INFO - 2024-05-04 09:55:45 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\include/admin_footer.php
INFO - 2024-05-04 09:55:45 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\admin_html_template.php
INFO - 2024-05-04 09:55:45 --> Final output sent to browser
DEBUG - 2024-05-04 09:55:45 --> Total execution time: 1.1760
ERROR - 2024-05-04 09:55:46 --> $config['composer_autoload'] is set to TRUE but E:\xampp\htdocs\maurnaturo\application\vendor/autoload.php was not found.
INFO - 2024-05-04 09:55:46 --> Config Class Initialized
INFO - 2024-05-04 09:55:46 --> Hooks Class Initialized
DEBUG - 2024-05-04 09:55:46 --> UTF-8 Support Enabled
INFO - 2024-05-04 09:55:46 --> Utf8 Class Initialized
INFO - 2024-05-04 09:55:46 --> URI Class Initialized
INFO - 2024-05-04 09:55:46 --> Router Class Initialized
INFO - 2024-05-04 09:55:46 --> Output Class Initialized
INFO - 2024-05-04 09:55:46 --> Security Class Initialized
DEBUG - 2024-05-04 09:55:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-04 09:55:46 --> Input Class Initialized
INFO - 2024-05-04 09:55:46 --> Language Class Initialized
INFO - 2024-05-04 09:55:46 --> Loader Class Initialized
INFO - 2024-05-04 09:55:46 --> Helper loaded: url_helper
INFO - 2024-05-04 09:55:46 --> Helper loaded: file_helper
INFO - 2024-05-04 09:55:46 --> Helper loaded: html_helper
INFO - 2024-05-04 09:55:46 --> Helper loaded: text_helper
INFO - 2024-05-04 09:55:46 --> Helper loaded: form_helper
INFO - 2024-05-04 09:55:46 --> Helper loaded: lang_helper
INFO - 2024-05-04 09:55:46 --> Helper loaded: security_helper
INFO - 2024-05-04 09:55:46 --> Helper loaded: cookie_helper
INFO - 2024-05-04 09:55:46 --> Database Driver Class Initialized
INFO - 2024-05-04 09:55:46 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-04 09:55:46 --> Parser Class Initialized
INFO - 2024-05-04 09:55:46 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-05-04 09:55:46 --> Pagination Class Initialized
INFO - 2024-05-04 09:55:46 --> Form Validation Class Initialized
INFO - 2024-05-04 09:55:46 --> Controller Class Initialized
DEBUG - 2024-05-04 09:55:46 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-05-04 09:55:46 --> Session class already loaded. Second attempt ignored.
INFO - 2024-05-04 09:55:46 --> Model Class Initialized
INFO - 2024-05-04 09:55:46 --> Model Class Initialized
INFO - 2024-05-04 09:55:46 --> Final output sent to browser
DEBUG - 2024-05-04 09:55:46 --> Total execution time: 0.1055
ERROR - 2024-05-04 09:56:07 --> $config['composer_autoload'] is set to TRUE but E:\xampp\htdocs\maurnaturo\application\vendor/autoload.php was not found.
INFO - 2024-05-04 09:56:07 --> Config Class Initialized
INFO - 2024-05-04 09:56:07 --> Hooks Class Initialized
DEBUG - 2024-05-04 09:56:07 --> UTF-8 Support Enabled
INFO - 2024-05-04 09:56:07 --> Utf8 Class Initialized
INFO - 2024-05-04 09:56:07 --> URI Class Initialized
INFO - 2024-05-04 09:56:07 --> Router Class Initialized
INFO - 2024-05-04 09:56:07 --> Output Class Initialized
INFO - 2024-05-04 09:56:07 --> Security Class Initialized
DEBUG - 2024-05-04 09:56:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-04 09:56:07 --> Input Class Initialized
INFO - 2024-05-04 09:56:07 --> Language Class Initialized
INFO - 2024-05-04 09:56:07 --> Loader Class Initialized
INFO - 2024-05-04 09:56:07 --> Helper loaded: url_helper
INFO - 2024-05-04 09:56:07 --> Helper loaded: file_helper
INFO - 2024-05-04 09:56:07 --> Helper loaded: html_helper
INFO - 2024-05-04 09:56:07 --> Helper loaded: text_helper
INFO - 2024-05-04 09:56:07 --> Helper loaded: form_helper
INFO - 2024-05-04 09:56:07 --> Helper loaded: lang_helper
INFO - 2024-05-04 09:56:07 --> Helper loaded: security_helper
INFO - 2024-05-04 09:56:07 --> Helper loaded: cookie_helper
INFO - 2024-05-04 09:56:07 --> Database Driver Class Initialized
INFO - 2024-05-04 09:56:07 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-04 09:56:07 --> Parser Class Initialized
INFO - 2024-05-04 09:56:07 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-05-04 09:56:07 --> Pagination Class Initialized
INFO - 2024-05-04 09:56:07 --> Form Validation Class Initialized
INFO - 2024-05-04 09:56:07 --> Controller Class Initialized
DEBUG - 2024-05-04 09:56:07 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-05-04 09:56:07 --> Session class already loaded. Second attempt ignored.
INFO - 2024-05-04 09:56:07 --> Model Class Initialized
INFO - 2024-05-04 09:56:07 --> Model Class Initialized
DEBUG - 2024-05-04 09:56:07 --> Lmr class already loaded. Second attempt ignored.
INFO - 2024-05-04 09:56:07 --> Model Class Initialized
INFO - 2024-05-04 09:56:07 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\mr/mr.php
DEBUG - 2024-05-04 09:56:07 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-05-04 09:56:07 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\include/top_menu.php
INFO - 2024-05-04 09:56:07 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\include/admin_loggedin_info.php
INFO - 2024-05-04 09:56:07 --> Model Class Initialized
INFO - 2024-05-04 09:56:07 --> Model Class Initialized
INFO - 2024-05-04 09:56:07 --> Model Class Initialized
INFO - 2024-05-04 09:56:08 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\include/admin_header.php
INFO - 2024-05-04 09:56:08 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\include/admin_footer.php
INFO - 2024-05-04 09:56:08 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\admin_html_template.php
INFO - 2024-05-04 09:56:08 --> Final output sent to browser
DEBUG - 2024-05-04 09:56:08 --> Total execution time: 1.0318
ERROR - 2024-05-04 09:56:09 --> $config['composer_autoload'] is set to TRUE but E:\xampp\htdocs\maurnaturo\application\vendor/autoload.php was not found.
INFO - 2024-05-04 09:56:09 --> Config Class Initialized
INFO - 2024-05-04 09:56:09 --> Hooks Class Initialized
DEBUG - 2024-05-04 09:56:09 --> UTF-8 Support Enabled
INFO - 2024-05-04 09:56:09 --> Utf8 Class Initialized
INFO - 2024-05-04 09:56:09 --> URI Class Initialized
INFO - 2024-05-04 09:56:09 --> Router Class Initialized
INFO - 2024-05-04 09:56:09 --> Output Class Initialized
INFO - 2024-05-04 09:56:09 --> Security Class Initialized
DEBUG - 2024-05-04 09:56:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-04 09:56:09 --> Input Class Initialized
INFO - 2024-05-04 09:56:09 --> Language Class Initialized
INFO - 2024-05-04 09:56:09 --> Loader Class Initialized
INFO - 2024-05-04 09:56:09 --> Helper loaded: url_helper
INFO - 2024-05-04 09:56:09 --> Helper loaded: file_helper
INFO - 2024-05-04 09:56:09 --> Helper loaded: html_helper
INFO - 2024-05-04 09:56:09 --> Helper loaded: text_helper
INFO - 2024-05-04 09:56:09 --> Helper loaded: form_helper
INFO - 2024-05-04 09:56:09 --> Helper loaded: lang_helper
INFO - 2024-05-04 09:56:09 --> Helper loaded: security_helper
INFO - 2024-05-04 09:56:09 --> Helper loaded: cookie_helper
INFO - 2024-05-04 09:56:09 --> Database Driver Class Initialized
INFO - 2024-05-04 09:56:09 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-04 09:56:09 --> Parser Class Initialized
INFO - 2024-05-04 09:56:09 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-05-04 09:56:09 --> Pagination Class Initialized
INFO - 2024-05-04 09:56:09 --> Form Validation Class Initialized
INFO - 2024-05-04 09:56:09 --> Controller Class Initialized
DEBUG - 2024-05-04 09:56:09 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-05-04 09:56:09 --> Session class already loaded. Second attempt ignored.
INFO - 2024-05-04 09:56:09 --> Model Class Initialized
INFO - 2024-05-04 09:56:09 --> Model Class Initialized
INFO - 2024-05-04 09:56:09 --> Final output sent to browser
DEBUG - 2024-05-04 09:56:09 --> Total execution time: 0.1305
ERROR - 2024-05-04 09:56:28 --> $config['composer_autoload'] is set to TRUE but E:\xampp\htdocs\maurnaturo\application\vendor/autoload.php was not found.
INFO - 2024-05-04 09:56:28 --> Config Class Initialized
INFO - 2024-05-04 09:56:28 --> Hooks Class Initialized
DEBUG - 2024-05-04 09:56:28 --> UTF-8 Support Enabled
INFO - 2024-05-04 09:56:28 --> Utf8 Class Initialized
INFO - 2024-05-04 09:56:28 --> URI Class Initialized
INFO - 2024-05-04 09:56:28 --> Router Class Initialized
INFO - 2024-05-04 09:56:28 --> Output Class Initialized
INFO - 2024-05-04 09:56:28 --> Security Class Initialized
DEBUG - 2024-05-04 09:56:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-04 09:56:28 --> Input Class Initialized
INFO - 2024-05-04 09:56:28 --> Language Class Initialized
INFO - 2024-05-04 09:56:28 --> Loader Class Initialized
INFO - 2024-05-04 09:56:28 --> Helper loaded: url_helper
INFO - 2024-05-04 09:56:28 --> Helper loaded: file_helper
INFO - 2024-05-04 09:56:28 --> Helper loaded: html_helper
INFO - 2024-05-04 09:56:28 --> Helper loaded: text_helper
INFO - 2024-05-04 09:56:28 --> Helper loaded: form_helper
INFO - 2024-05-04 09:56:28 --> Helper loaded: lang_helper
INFO - 2024-05-04 09:56:28 --> Helper loaded: security_helper
INFO - 2024-05-04 09:56:28 --> Helper loaded: cookie_helper
INFO - 2024-05-04 09:56:28 --> Database Driver Class Initialized
INFO - 2024-05-04 09:56:28 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-04 09:56:28 --> Parser Class Initialized
INFO - 2024-05-04 09:56:28 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-05-04 09:56:28 --> Pagination Class Initialized
INFO - 2024-05-04 09:56:28 --> Form Validation Class Initialized
INFO - 2024-05-04 09:56:28 --> Controller Class Initialized
DEBUG - 2024-05-04 09:56:28 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-05-04 09:56:28 --> Session class already loaded. Second attempt ignored.
INFO - 2024-05-04 09:56:28 --> Model Class Initialized
INFO - 2024-05-04 09:56:28 --> Model Class Initialized
DEBUG - 2024-05-04 09:56:28 --> Lmr class already loaded. Second attempt ignored.
INFO - 2024-05-04 09:56:28 --> Model Class Initialized
INFO - 2024-05-04 09:56:28 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\mr/mr.php
DEBUG - 2024-05-04 09:56:28 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-05-04 09:56:28 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\include/top_menu.php
INFO - 2024-05-04 09:56:28 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\include/admin_loggedin_info.php
INFO - 2024-05-04 09:56:28 --> Model Class Initialized
INFO - 2024-05-04 09:56:28 --> Model Class Initialized
INFO - 2024-05-04 09:56:28 --> Model Class Initialized
INFO - 2024-05-04 09:56:29 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\include/admin_header.php
INFO - 2024-05-04 09:56:29 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\include/admin_footer.php
INFO - 2024-05-04 09:56:29 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\admin_html_template.php
INFO - 2024-05-04 09:56:29 --> Final output sent to browser
DEBUG - 2024-05-04 09:56:29 --> Total execution time: 1.1247
ERROR - 2024-05-04 09:56:30 --> $config['composer_autoload'] is set to TRUE but E:\xampp\htdocs\maurnaturo\application\vendor/autoload.php was not found.
INFO - 2024-05-04 09:56:30 --> Config Class Initialized
INFO - 2024-05-04 09:56:30 --> Hooks Class Initialized
DEBUG - 2024-05-04 09:56:30 --> UTF-8 Support Enabled
INFO - 2024-05-04 09:56:30 --> Utf8 Class Initialized
INFO - 2024-05-04 09:56:30 --> URI Class Initialized
INFO - 2024-05-04 09:56:30 --> Router Class Initialized
INFO - 2024-05-04 09:56:30 --> Output Class Initialized
INFO - 2024-05-04 09:56:30 --> Security Class Initialized
DEBUG - 2024-05-04 09:56:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-04 09:56:30 --> Input Class Initialized
INFO - 2024-05-04 09:56:30 --> Language Class Initialized
INFO - 2024-05-04 09:56:30 --> Loader Class Initialized
INFO - 2024-05-04 09:56:30 --> Helper loaded: url_helper
INFO - 2024-05-04 09:56:30 --> Helper loaded: file_helper
INFO - 2024-05-04 09:56:30 --> Helper loaded: html_helper
INFO - 2024-05-04 09:56:30 --> Helper loaded: text_helper
INFO - 2024-05-04 09:56:30 --> Helper loaded: form_helper
INFO - 2024-05-04 09:56:30 --> Helper loaded: lang_helper
INFO - 2024-05-04 09:56:30 --> Helper loaded: security_helper
INFO - 2024-05-04 09:56:30 --> Helper loaded: cookie_helper
INFO - 2024-05-04 09:56:30 --> Database Driver Class Initialized
INFO - 2024-05-04 09:56:30 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-04 09:56:30 --> Parser Class Initialized
INFO - 2024-05-04 09:56:30 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-05-04 09:56:30 --> Pagination Class Initialized
INFO - 2024-05-04 09:56:30 --> Form Validation Class Initialized
INFO - 2024-05-04 09:56:30 --> Controller Class Initialized
DEBUG - 2024-05-04 09:56:30 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-05-04 09:56:30 --> Session class already loaded. Second attempt ignored.
INFO - 2024-05-04 09:56:30 --> Model Class Initialized
INFO - 2024-05-04 09:56:30 --> Model Class Initialized
INFO - 2024-05-04 09:56:30 --> Final output sent to browser
DEBUG - 2024-05-04 09:56:30 --> Total execution time: 0.1156
ERROR - 2024-05-04 09:58:00 --> $config['composer_autoload'] is set to TRUE but E:\xampp\htdocs\maurnaturo\application\vendor/autoload.php was not found.
INFO - 2024-05-04 09:58:00 --> Config Class Initialized
INFO - 2024-05-04 09:58:00 --> Hooks Class Initialized
DEBUG - 2024-05-04 09:58:00 --> UTF-8 Support Enabled
INFO - 2024-05-04 09:58:00 --> Utf8 Class Initialized
INFO - 2024-05-04 09:58:00 --> URI Class Initialized
INFO - 2024-05-04 09:58:00 --> Router Class Initialized
INFO - 2024-05-04 09:58:00 --> Output Class Initialized
INFO - 2024-05-04 09:58:00 --> Security Class Initialized
DEBUG - 2024-05-04 09:58:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-04 09:58:00 --> Input Class Initialized
INFO - 2024-05-04 09:58:00 --> Language Class Initialized
INFO - 2024-05-04 09:58:00 --> Loader Class Initialized
INFO - 2024-05-04 09:58:00 --> Helper loaded: url_helper
INFO - 2024-05-04 09:58:00 --> Helper loaded: file_helper
INFO - 2024-05-04 09:58:00 --> Helper loaded: html_helper
INFO - 2024-05-04 09:58:00 --> Helper loaded: text_helper
INFO - 2024-05-04 09:58:00 --> Helper loaded: form_helper
INFO - 2024-05-04 09:58:00 --> Helper loaded: lang_helper
INFO - 2024-05-04 09:58:00 --> Helper loaded: security_helper
INFO - 2024-05-04 09:58:00 --> Helper loaded: cookie_helper
INFO - 2024-05-04 09:58:00 --> Database Driver Class Initialized
INFO - 2024-05-04 09:58:00 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-04 09:58:00 --> Parser Class Initialized
INFO - 2024-05-04 09:58:00 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-05-04 09:58:00 --> Pagination Class Initialized
INFO - 2024-05-04 09:58:00 --> Form Validation Class Initialized
INFO - 2024-05-04 09:58:00 --> Controller Class Initialized
DEBUG - 2024-05-04 09:58:00 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-05-04 09:58:00 --> Session class already loaded. Second attempt ignored.
INFO - 2024-05-04 09:58:00 --> Model Class Initialized
INFO - 2024-05-04 09:58:00 --> Model Class Initialized
DEBUG - 2024-05-04 09:58:00 --> Lmr class already loaded. Second attempt ignored.
INFO - 2024-05-04 09:58:00 --> Model Class Initialized
INFO - 2024-05-04 09:58:00 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\mr/mr.php
DEBUG - 2024-05-04 09:58:00 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-05-04 09:58:00 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\include/top_menu.php
INFO - 2024-05-04 09:58:00 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\include/admin_loggedin_info.php
INFO - 2024-05-04 09:58:00 --> Model Class Initialized
INFO - 2024-05-04 09:58:00 --> Model Class Initialized
INFO - 2024-05-04 09:58:00 --> Model Class Initialized
INFO - 2024-05-04 09:58:01 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\include/admin_header.php
INFO - 2024-05-04 09:58:01 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\include/admin_footer.php
INFO - 2024-05-04 09:58:01 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\admin_html_template.php
INFO - 2024-05-04 09:58:01 --> Final output sent to browser
DEBUG - 2024-05-04 09:58:01 --> Total execution time: 1.1928
ERROR - 2024-05-04 09:58:02 --> $config['composer_autoload'] is set to TRUE but E:\xampp\htdocs\maurnaturo\application\vendor/autoload.php was not found.
INFO - 2024-05-04 09:58:02 --> Config Class Initialized
INFO - 2024-05-04 09:58:02 --> Hooks Class Initialized
DEBUG - 2024-05-04 09:58:02 --> UTF-8 Support Enabled
INFO - 2024-05-04 09:58:02 --> Utf8 Class Initialized
INFO - 2024-05-04 09:58:02 --> URI Class Initialized
INFO - 2024-05-04 09:58:02 --> Router Class Initialized
INFO - 2024-05-04 09:58:02 --> Output Class Initialized
INFO - 2024-05-04 09:58:02 --> Security Class Initialized
DEBUG - 2024-05-04 09:58:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-04 09:58:02 --> Input Class Initialized
INFO - 2024-05-04 09:58:02 --> Language Class Initialized
INFO - 2024-05-04 09:58:02 --> Loader Class Initialized
INFO - 2024-05-04 09:58:02 --> Helper loaded: url_helper
INFO - 2024-05-04 09:58:02 --> Helper loaded: file_helper
INFO - 2024-05-04 09:58:02 --> Helper loaded: html_helper
INFO - 2024-05-04 09:58:02 --> Helper loaded: text_helper
INFO - 2024-05-04 09:58:02 --> Helper loaded: form_helper
INFO - 2024-05-04 09:58:02 --> Helper loaded: lang_helper
INFO - 2024-05-04 09:58:02 --> Helper loaded: security_helper
INFO - 2024-05-04 09:58:02 --> Helper loaded: cookie_helper
INFO - 2024-05-04 09:58:02 --> Database Driver Class Initialized
INFO - 2024-05-04 09:58:02 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-04 09:58:02 --> Parser Class Initialized
INFO - 2024-05-04 09:58:02 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-05-04 09:58:02 --> Pagination Class Initialized
INFO - 2024-05-04 09:58:02 --> Form Validation Class Initialized
INFO - 2024-05-04 09:58:02 --> Controller Class Initialized
DEBUG - 2024-05-04 09:58:02 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-05-04 09:58:02 --> Session class already loaded. Second attempt ignored.
INFO - 2024-05-04 09:58:02 --> Model Class Initialized
INFO - 2024-05-04 09:58:02 --> Model Class Initialized
INFO - 2024-05-04 09:58:02 --> Final output sent to browser
DEBUG - 2024-05-04 09:58:02 --> Total execution time: 0.1131
ERROR - 2024-05-04 09:59:11 --> $config['composer_autoload'] is set to TRUE but E:\xampp\htdocs\maurnaturo\application\vendor/autoload.php was not found.
INFO - 2024-05-04 09:59:11 --> Config Class Initialized
INFO - 2024-05-04 09:59:11 --> Hooks Class Initialized
DEBUG - 2024-05-04 09:59:11 --> UTF-8 Support Enabled
INFO - 2024-05-04 09:59:11 --> Utf8 Class Initialized
INFO - 2024-05-04 09:59:11 --> URI Class Initialized
INFO - 2024-05-04 09:59:11 --> Router Class Initialized
INFO - 2024-05-04 09:59:11 --> Output Class Initialized
INFO - 2024-05-04 09:59:11 --> Security Class Initialized
DEBUG - 2024-05-04 09:59:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-04 09:59:11 --> Input Class Initialized
INFO - 2024-05-04 09:59:11 --> Language Class Initialized
INFO - 2024-05-04 09:59:11 --> Loader Class Initialized
INFO - 2024-05-04 09:59:11 --> Helper loaded: url_helper
INFO - 2024-05-04 09:59:11 --> Helper loaded: file_helper
INFO - 2024-05-04 09:59:11 --> Helper loaded: html_helper
INFO - 2024-05-04 09:59:11 --> Helper loaded: text_helper
INFO - 2024-05-04 09:59:11 --> Helper loaded: form_helper
INFO - 2024-05-04 09:59:11 --> Helper loaded: lang_helper
INFO - 2024-05-04 09:59:11 --> Helper loaded: security_helper
INFO - 2024-05-04 09:59:11 --> Helper loaded: cookie_helper
INFO - 2024-05-04 09:59:11 --> Database Driver Class Initialized
INFO - 2024-05-04 09:59:11 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-04 09:59:11 --> Parser Class Initialized
INFO - 2024-05-04 09:59:11 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-05-04 09:59:11 --> Pagination Class Initialized
INFO - 2024-05-04 09:59:11 --> Form Validation Class Initialized
INFO - 2024-05-04 09:59:11 --> Controller Class Initialized
DEBUG - 2024-05-04 09:59:11 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-05-04 09:59:11 --> Session class already loaded. Second attempt ignored.
INFO - 2024-05-04 09:59:11 --> Model Class Initialized
INFO - 2024-05-04 09:59:11 --> Model Class Initialized
DEBUG - 2024-05-04 09:59:11 --> Lmr class already loaded. Second attempt ignored.
INFO - 2024-05-04 09:59:11 --> Model Class Initialized
INFO - 2024-05-04 09:59:11 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\mr/mr.php
DEBUG - 2024-05-04 09:59:11 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-05-04 09:59:11 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\include/top_menu.php
INFO - 2024-05-04 09:59:11 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\include/admin_loggedin_info.php
INFO - 2024-05-04 09:59:11 --> Model Class Initialized
INFO - 2024-05-04 09:59:11 --> Model Class Initialized
INFO - 2024-05-04 09:59:11 --> Model Class Initialized
INFO - 2024-05-04 09:59:12 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\include/admin_header.php
INFO - 2024-05-04 09:59:12 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\include/admin_footer.php
INFO - 2024-05-04 09:59:12 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\admin_html_template.php
INFO - 2024-05-04 09:59:12 --> Final output sent to browser
DEBUG - 2024-05-04 09:59:12 --> Total execution time: 1.1192
ERROR - 2024-05-04 09:59:12 --> $config['composer_autoload'] is set to TRUE but E:\xampp\htdocs\maurnaturo\application\vendor/autoload.php was not found.
INFO - 2024-05-04 09:59:12 --> Config Class Initialized
INFO - 2024-05-04 09:59:12 --> Hooks Class Initialized
DEBUG - 2024-05-04 09:59:12 --> UTF-8 Support Enabled
INFO - 2024-05-04 09:59:12 --> Utf8 Class Initialized
INFO - 2024-05-04 09:59:12 --> URI Class Initialized
INFO - 2024-05-04 09:59:12 --> Router Class Initialized
INFO - 2024-05-04 09:59:12 --> Output Class Initialized
INFO - 2024-05-04 09:59:12 --> Security Class Initialized
DEBUG - 2024-05-04 09:59:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-04 09:59:12 --> Input Class Initialized
INFO - 2024-05-04 09:59:12 --> Language Class Initialized
INFO - 2024-05-04 09:59:12 --> Loader Class Initialized
INFO - 2024-05-04 09:59:12 --> Helper loaded: url_helper
INFO - 2024-05-04 09:59:12 --> Helper loaded: file_helper
INFO - 2024-05-04 09:59:12 --> Helper loaded: html_helper
INFO - 2024-05-04 09:59:12 --> Helper loaded: text_helper
INFO - 2024-05-04 09:59:12 --> Helper loaded: form_helper
INFO - 2024-05-04 09:59:12 --> Helper loaded: lang_helper
INFO - 2024-05-04 09:59:12 --> Helper loaded: security_helper
INFO - 2024-05-04 09:59:12 --> Helper loaded: cookie_helper
INFO - 2024-05-04 09:59:12 --> Database Driver Class Initialized
INFO - 2024-05-04 09:59:12 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-04 09:59:12 --> Parser Class Initialized
INFO - 2024-05-04 09:59:12 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-05-04 09:59:12 --> Pagination Class Initialized
INFO - 2024-05-04 09:59:12 --> Form Validation Class Initialized
INFO - 2024-05-04 09:59:12 --> Controller Class Initialized
DEBUG - 2024-05-04 09:59:12 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-05-04 09:59:12 --> Session class already loaded. Second attempt ignored.
INFO - 2024-05-04 09:59:12 --> Model Class Initialized
INFO - 2024-05-04 09:59:12 --> Model Class Initialized
INFO - 2024-05-04 09:59:12 --> Final output sent to browser
DEBUG - 2024-05-04 09:59:12 --> Total execution time: 0.1384
ERROR - 2024-05-04 10:11:14 --> $config['composer_autoload'] is set to TRUE but E:\xampp\htdocs\maurnaturo\application\vendor/autoload.php was not found.
INFO - 2024-05-04 10:11:14 --> Config Class Initialized
INFO - 2024-05-04 10:11:14 --> Hooks Class Initialized
DEBUG - 2024-05-04 10:11:14 --> UTF-8 Support Enabled
INFO - 2024-05-04 10:11:14 --> Utf8 Class Initialized
INFO - 2024-05-04 10:11:14 --> URI Class Initialized
INFO - 2024-05-04 10:11:14 --> Router Class Initialized
INFO - 2024-05-04 10:11:14 --> Output Class Initialized
INFO - 2024-05-04 10:11:14 --> Security Class Initialized
DEBUG - 2024-05-04 10:11:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-04 10:11:14 --> Input Class Initialized
INFO - 2024-05-04 10:11:14 --> Language Class Initialized
INFO - 2024-05-04 10:11:14 --> Loader Class Initialized
INFO - 2024-05-04 10:11:14 --> Helper loaded: url_helper
INFO - 2024-05-04 10:11:14 --> Helper loaded: file_helper
INFO - 2024-05-04 10:11:14 --> Helper loaded: html_helper
INFO - 2024-05-04 10:11:14 --> Helper loaded: text_helper
INFO - 2024-05-04 10:11:14 --> Helper loaded: form_helper
INFO - 2024-05-04 10:11:14 --> Helper loaded: lang_helper
INFO - 2024-05-04 10:11:14 --> Helper loaded: security_helper
INFO - 2024-05-04 10:11:14 --> Helper loaded: cookie_helper
INFO - 2024-05-04 10:11:14 --> Database Driver Class Initialized
INFO - 2024-05-04 10:11:14 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-04 10:11:14 --> Parser Class Initialized
INFO - 2024-05-04 10:11:14 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-05-04 10:11:14 --> Pagination Class Initialized
INFO - 2024-05-04 10:11:14 --> Form Validation Class Initialized
INFO - 2024-05-04 10:11:14 --> Controller Class Initialized
DEBUG - 2024-05-04 10:11:14 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-05-04 10:11:14 --> Session class already loaded. Second attempt ignored.
INFO - 2024-05-04 10:11:14 --> Model Class Initialized
INFO - 2024-05-04 10:11:14 --> Model Class Initialized
DEBUG - 2024-05-04 10:11:14 --> Lmr class already loaded. Second attempt ignored.
INFO - 2024-05-04 10:11:14 --> Model Class Initialized
INFO - 2024-05-04 10:11:14 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\mr/mr.php
DEBUG - 2024-05-04 10:11:14 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-05-04 10:11:14 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\include/top_menu.php
INFO - 2024-05-04 10:11:14 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\include/admin_loggedin_info.php
INFO - 2024-05-04 10:11:14 --> Model Class Initialized
INFO - 2024-05-04 10:11:14 --> Model Class Initialized
INFO - 2024-05-04 10:11:14 --> Model Class Initialized
INFO - 2024-05-04 10:11:15 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\include/admin_header.php
INFO - 2024-05-04 10:11:15 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\include/admin_footer.php
INFO - 2024-05-04 10:11:15 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\admin_html_template.php
INFO - 2024-05-04 10:11:15 --> Final output sent to browser
DEBUG - 2024-05-04 10:11:15 --> Total execution time: 1.2600
ERROR - 2024-05-04 10:11:16 --> $config['composer_autoload'] is set to TRUE but E:\xampp\htdocs\maurnaturo\application\vendor/autoload.php was not found.
INFO - 2024-05-04 10:11:16 --> Config Class Initialized
INFO - 2024-05-04 10:11:16 --> Hooks Class Initialized
DEBUG - 2024-05-04 10:11:16 --> UTF-8 Support Enabled
INFO - 2024-05-04 10:11:16 --> Utf8 Class Initialized
INFO - 2024-05-04 10:11:16 --> URI Class Initialized
INFO - 2024-05-04 10:11:16 --> Router Class Initialized
INFO - 2024-05-04 10:11:16 --> Output Class Initialized
INFO - 2024-05-04 10:11:16 --> Security Class Initialized
DEBUG - 2024-05-04 10:11:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-04 10:11:16 --> Input Class Initialized
INFO - 2024-05-04 10:11:16 --> Language Class Initialized
INFO - 2024-05-04 10:11:16 --> Loader Class Initialized
INFO - 2024-05-04 10:11:16 --> Helper loaded: url_helper
INFO - 2024-05-04 10:11:16 --> Helper loaded: file_helper
INFO - 2024-05-04 10:11:16 --> Helper loaded: html_helper
INFO - 2024-05-04 10:11:16 --> Helper loaded: text_helper
INFO - 2024-05-04 10:11:16 --> Helper loaded: form_helper
INFO - 2024-05-04 10:11:16 --> Helper loaded: lang_helper
INFO - 2024-05-04 10:11:16 --> Helper loaded: security_helper
INFO - 2024-05-04 10:11:16 --> Helper loaded: cookie_helper
INFO - 2024-05-04 10:11:16 --> Database Driver Class Initialized
INFO - 2024-05-04 10:11:16 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-04 10:11:16 --> Parser Class Initialized
INFO - 2024-05-04 10:11:16 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-05-04 10:11:16 --> Pagination Class Initialized
INFO - 2024-05-04 10:11:16 --> Form Validation Class Initialized
INFO - 2024-05-04 10:11:16 --> Controller Class Initialized
DEBUG - 2024-05-04 10:11:16 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-05-04 10:11:16 --> Session class already loaded. Second attempt ignored.
INFO - 2024-05-04 10:11:16 --> Model Class Initialized
INFO - 2024-05-04 10:11:16 --> Model Class Initialized
INFO - 2024-05-04 10:11:16 --> Final output sent to browser
DEBUG - 2024-05-04 10:11:16 --> Total execution time: 0.1147
ERROR - 2024-05-04 10:12:53 --> $config['composer_autoload'] is set to TRUE but E:\xampp\htdocs\maurnaturo\application\vendor/autoload.php was not found.
INFO - 2024-05-04 10:12:53 --> Config Class Initialized
INFO - 2024-05-04 10:12:53 --> Hooks Class Initialized
DEBUG - 2024-05-04 10:12:53 --> UTF-8 Support Enabled
INFO - 2024-05-04 10:12:53 --> Utf8 Class Initialized
INFO - 2024-05-04 10:12:53 --> URI Class Initialized
INFO - 2024-05-04 10:12:53 --> Router Class Initialized
INFO - 2024-05-04 10:12:53 --> Output Class Initialized
INFO - 2024-05-04 10:12:53 --> Security Class Initialized
DEBUG - 2024-05-04 10:12:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-04 10:12:53 --> Input Class Initialized
INFO - 2024-05-04 10:12:53 --> Language Class Initialized
INFO - 2024-05-04 10:12:53 --> Loader Class Initialized
INFO - 2024-05-04 10:12:53 --> Helper loaded: url_helper
INFO - 2024-05-04 10:12:53 --> Helper loaded: file_helper
INFO - 2024-05-04 10:12:53 --> Helper loaded: html_helper
INFO - 2024-05-04 10:12:53 --> Helper loaded: text_helper
INFO - 2024-05-04 10:12:53 --> Helper loaded: form_helper
INFO - 2024-05-04 10:12:53 --> Helper loaded: lang_helper
INFO - 2024-05-04 10:12:53 --> Helper loaded: security_helper
INFO - 2024-05-04 10:12:53 --> Helper loaded: cookie_helper
INFO - 2024-05-04 10:12:53 --> Database Driver Class Initialized
INFO - 2024-05-04 10:12:53 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-04 10:12:53 --> Parser Class Initialized
INFO - 2024-05-04 10:12:53 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-05-04 10:12:53 --> Pagination Class Initialized
INFO - 2024-05-04 10:12:53 --> Form Validation Class Initialized
INFO - 2024-05-04 10:12:53 --> Controller Class Initialized
DEBUG - 2024-05-04 10:12:53 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-05-04 10:12:53 --> Session class already loaded. Second attempt ignored.
INFO - 2024-05-04 10:12:53 --> Model Class Initialized
INFO - 2024-05-04 10:12:53 --> Model Class Initialized
DEBUG - 2024-05-04 10:12:53 --> Lmr class already loaded. Second attempt ignored.
INFO - 2024-05-04 10:12:53 --> Model Class Initialized
INFO - 2024-05-04 10:12:53 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\mr/mr.php
DEBUG - 2024-05-04 10:12:53 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-05-04 10:12:53 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\include/top_menu.php
INFO - 2024-05-04 10:12:53 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\include/admin_loggedin_info.php
INFO - 2024-05-04 10:12:53 --> Model Class Initialized
INFO - 2024-05-04 10:12:53 --> Model Class Initialized
INFO - 2024-05-04 10:12:53 --> Model Class Initialized
INFO - 2024-05-04 10:12:54 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\include/admin_header.php
INFO - 2024-05-04 10:12:54 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\include/admin_footer.php
INFO - 2024-05-04 10:12:54 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\admin_html_template.php
INFO - 2024-05-04 10:12:54 --> Final output sent to browser
DEBUG - 2024-05-04 10:12:54 --> Total execution time: 1.1096
ERROR - 2024-05-04 10:12:55 --> $config['composer_autoload'] is set to TRUE but E:\xampp\htdocs\maurnaturo\application\vendor/autoload.php was not found.
INFO - 2024-05-04 10:12:55 --> Config Class Initialized
INFO - 2024-05-04 10:12:55 --> Hooks Class Initialized
DEBUG - 2024-05-04 10:12:55 --> UTF-8 Support Enabled
INFO - 2024-05-04 10:12:55 --> Utf8 Class Initialized
INFO - 2024-05-04 10:12:55 --> URI Class Initialized
INFO - 2024-05-04 10:12:55 --> Router Class Initialized
INFO - 2024-05-04 10:12:55 --> Output Class Initialized
INFO - 2024-05-04 10:12:55 --> Security Class Initialized
DEBUG - 2024-05-04 10:12:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-04 10:12:55 --> Input Class Initialized
INFO - 2024-05-04 10:12:55 --> Language Class Initialized
INFO - 2024-05-04 10:12:55 --> Loader Class Initialized
INFO - 2024-05-04 10:12:55 --> Helper loaded: url_helper
INFO - 2024-05-04 10:12:55 --> Helper loaded: file_helper
INFO - 2024-05-04 10:12:55 --> Helper loaded: html_helper
INFO - 2024-05-04 10:12:55 --> Helper loaded: text_helper
INFO - 2024-05-04 10:12:55 --> Helper loaded: form_helper
INFO - 2024-05-04 10:12:55 --> Helper loaded: lang_helper
INFO - 2024-05-04 10:12:55 --> Helper loaded: security_helper
INFO - 2024-05-04 10:12:55 --> Helper loaded: cookie_helper
INFO - 2024-05-04 10:12:55 --> Database Driver Class Initialized
INFO - 2024-05-04 10:12:55 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-04 10:12:55 --> Parser Class Initialized
INFO - 2024-05-04 10:12:55 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-05-04 10:12:55 --> Pagination Class Initialized
INFO - 2024-05-04 10:12:55 --> Form Validation Class Initialized
INFO - 2024-05-04 10:12:55 --> Controller Class Initialized
DEBUG - 2024-05-04 10:12:55 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-05-04 10:12:55 --> Session class already loaded. Second attempt ignored.
INFO - 2024-05-04 10:12:55 --> Model Class Initialized
INFO - 2024-05-04 10:12:55 --> Model Class Initialized
INFO - 2024-05-04 10:12:55 --> Final output sent to browser
DEBUG - 2024-05-04 10:12:55 --> Total execution time: 0.1303
ERROR - 2024-05-04 10:13:24 --> $config['composer_autoload'] is set to TRUE but E:\xampp\htdocs\maurnaturo\application\vendor/autoload.php was not found.
INFO - 2024-05-04 10:13:24 --> Config Class Initialized
INFO - 2024-05-04 10:13:24 --> Hooks Class Initialized
DEBUG - 2024-05-04 10:13:24 --> UTF-8 Support Enabled
INFO - 2024-05-04 10:13:24 --> Utf8 Class Initialized
INFO - 2024-05-04 10:13:24 --> URI Class Initialized
INFO - 2024-05-04 10:13:24 --> Router Class Initialized
INFO - 2024-05-04 10:13:24 --> Output Class Initialized
INFO - 2024-05-04 10:13:24 --> Security Class Initialized
DEBUG - 2024-05-04 10:13:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-04 10:13:24 --> Input Class Initialized
INFO - 2024-05-04 10:13:24 --> Language Class Initialized
INFO - 2024-05-04 10:13:24 --> Loader Class Initialized
INFO - 2024-05-04 10:13:24 --> Helper loaded: url_helper
INFO - 2024-05-04 10:13:24 --> Helper loaded: file_helper
INFO - 2024-05-04 10:13:24 --> Helper loaded: html_helper
INFO - 2024-05-04 10:13:24 --> Helper loaded: text_helper
INFO - 2024-05-04 10:13:24 --> Helper loaded: form_helper
INFO - 2024-05-04 10:13:24 --> Helper loaded: lang_helper
INFO - 2024-05-04 10:13:24 --> Helper loaded: security_helper
INFO - 2024-05-04 10:13:24 --> Helper loaded: cookie_helper
INFO - 2024-05-04 10:13:24 --> Database Driver Class Initialized
INFO - 2024-05-04 10:13:24 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-04 10:13:24 --> Parser Class Initialized
INFO - 2024-05-04 10:13:24 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-05-04 10:13:24 --> Pagination Class Initialized
INFO - 2024-05-04 10:13:24 --> Form Validation Class Initialized
INFO - 2024-05-04 10:13:24 --> Controller Class Initialized
DEBUG - 2024-05-04 10:13:24 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-05-04 10:13:24 --> Session class already loaded. Second attempt ignored.
INFO - 2024-05-04 10:13:24 --> Model Class Initialized
INFO - 2024-05-04 10:13:24 --> Model Class Initialized
DEBUG - 2024-05-04 10:13:24 --> Lmr class already loaded. Second attempt ignored.
INFO - 2024-05-04 10:13:24 --> Model Class Initialized
INFO - 2024-05-04 10:13:24 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\mr/mr.php
DEBUG - 2024-05-04 10:13:24 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-05-04 10:13:24 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\include/top_menu.php
INFO - 2024-05-04 10:13:24 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\include/admin_loggedin_info.php
INFO - 2024-05-04 10:13:24 --> Model Class Initialized
INFO - 2024-05-04 10:13:24 --> Model Class Initialized
INFO - 2024-05-04 10:13:24 --> Model Class Initialized
INFO - 2024-05-04 10:13:25 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\include/admin_header.php
INFO - 2024-05-04 10:13:25 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\include/admin_footer.php
INFO - 2024-05-04 10:13:25 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\admin_html_template.php
INFO - 2024-05-04 10:13:25 --> Final output sent to browser
DEBUG - 2024-05-04 10:13:25 --> Total execution time: 1.2285
ERROR - 2024-05-04 10:13:26 --> $config['composer_autoload'] is set to TRUE but E:\xampp\htdocs\maurnaturo\application\vendor/autoload.php was not found.
INFO - 2024-05-04 10:13:26 --> Config Class Initialized
INFO - 2024-05-04 10:13:26 --> Hooks Class Initialized
DEBUG - 2024-05-04 10:13:26 --> UTF-8 Support Enabled
INFO - 2024-05-04 10:13:26 --> Utf8 Class Initialized
INFO - 2024-05-04 10:13:26 --> URI Class Initialized
INFO - 2024-05-04 10:13:26 --> Router Class Initialized
INFO - 2024-05-04 10:13:26 --> Output Class Initialized
INFO - 2024-05-04 10:13:26 --> Security Class Initialized
DEBUG - 2024-05-04 10:13:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-04 10:13:26 --> Input Class Initialized
INFO - 2024-05-04 10:13:26 --> Language Class Initialized
INFO - 2024-05-04 10:13:26 --> Loader Class Initialized
INFO - 2024-05-04 10:13:26 --> Helper loaded: url_helper
INFO - 2024-05-04 10:13:26 --> Helper loaded: file_helper
INFO - 2024-05-04 10:13:26 --> Helper loaded: html_helper
INFO - 2024-05-04 10:13:26 --> Helper loaded: text_helper
INFO - 2024-05-04 10:13:26 --> Helper loaded: form_helper
INFO - 2024-05-04 10:13:26 --> Helper loaded: lang_helper
INFO - 2024-05-04 10:13:26 --> Helper loaded: security_helper
INFO - 2024-05-04 10:13:26 --> Helper loaded: cookie_helper
INFO - 2024-05-04 10:13:26 --> Database Driver Class Initialized
INFO - 2024-05-04 10:13:26 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-04 10:13:26 --> Parser Class Initialized
INFO - 2024-05-04 10:13:26 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-05-04 10:13:26 --> Pagination Class Initialized
INFO - 2024-05-04 10:13:26 --> Form Validation Class Initialized
INFO - 2024-05-04 10:13:26 --> Controller Class Initialized
DEBUG - 2024-05-04 10:13:26 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-05-04 10:13:26 --> Session class already loaded. Second attempt ignored.
INFO - 2024-05-04 10:13:26 --> Model Class Initialized
INFO - 2024-05-04 10:13:26 --> Model Class Initialized
INFO - 2024-05-04 10:13:26 --> Final output sent to browser
DEBUG - 2024-05-04 10:13:26 --> Total execution time: 0.1274
ERROR - 2024-05-04 10:13:31 --> $config['composer_autoload'] is set to TRUE but E:\xampp\htdocs\maurnaturo\application\vendor/autoload.php was not found.
INFO - 2024-05-04 10:13:31 --> Config Class Initialized
INFO - 2024-05-04 10:13:31 --> Hooks Class Initialized
DEBUG - 2024-05-04 10:13:31 --> UTF-8 Support Enabled
INFO - 2024-05-04 10:13:31 --> Utf8 Class Initialized
INFO - 2024-05-04 10:13:31 --> URI Class Initialized
INFO - 2024-05-04 10:13:31 --> Router Class Initialized
INFO - 2024-05-04 10:13:31 --> Output Class Initialized
INFO - 2024-05-04 10:13:31 --> Security Class Initialized
DEBUG - 2024-05-04 10:13:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-04 10:13:31 --> Input Class Initialized
INFO - 2024-05-04 10:13:31 --> Language Class Initialized
INFO - 2024-05-04 10:13:31 --> Loader Class Initialized
INFO - 2024-05-04 10:13:31 --> Helper loaded: url_helper
INFO - 2024-05-04 10:13:31 --> Helper loaded: file_helper
INFO - 2024-05-04 10:13:31 --> Helper loaded: html_helper
INFO - 2024-05-04 10:13:31 --> Helper loaded: text_helper
INFO - 2024-05-04 10:13:31 --> Helper loaded: form_helper
INFO - 2024-05-04 10:13:31 --> Helper loaded: lang_helper
INFO - 2024-05-04 10:13:31 --> Helper loaded: security_helper
INFO - 2024-05-04 10:13:31 --> Helper loaded: cookie_helper
INFO - 2024-05-04 10:13:31 --> Database Driver Class Initialized
INFO - 2024-05-04 10:13:31 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-04 10:13:31 --> Parser Class Initialized
INFO - 2024-05-04 10:13:31 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-05-04 10:13:31 --> Pagination Class Initialized
INFO - 2024-05-04 10:13:31 --> Form Validation Class Initialized
INFO - 2024-05-04 10:13:31 --> Controller Class Initialized
DEBUG - 2024-05-04 10:13:31 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-05-04 10:13:31 --> Session class already loaded. Second attempt ignored.
INFO - 2024-05-04 10:13:31 --> Model Class Initialized
INFO - 2024-05-04 10:13:31 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\mr_payments/add_payment_form.php
DEBUG - 2024-05-04 10:13:31 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-05-04 10:13:31 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\include/top_menu.php
INFO - 2024-05-04 10:13:31 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\include/admin_loggedin_info.php
INFO - 2024-05-04 10:13:31 --> Model Class Initialized
INFO - 2024-05-04 10:13:31 --> Model Class Initialized
INFO - 2024-05-04 10:13:31 --> Model Class Initialized
INFO - 2024-05-04 10:13:31 --> Model Class Initialized
INFO - 2024-05-04 10:13:32 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\include/admin_header.php
INFO - 2024-05-04 10:13:32 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\include/admin_footer.php
INFO - 2024-05-04 10:13:32 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\admin_html_template.php
INFO - 2024-05-04 10:13:32 --> Final output sent to browser
DEBUG - 2024-05-04 10:13:32 --> Total execution time: 1.5289
ERROR - 2024-05-04 10:13:57 --> $config['composer_autoload'] is set to TRUE but E:\xampp\htdocs\maurnaturo\application\vendor/autoload.php was not found.
INFO - 2024-05-04 10:13:57 --> Config Class Initialized
INFO - 2024-05-04 10:13:57 --> Hooks Class Initialized
DEBUG - 2024-05-04 10:13:57 --> UTF-8 Support Enabled
INFO - 2024-05-04 10:13:57 --> Utf8 Class Initialized
INFO - 2024-05-04 10:13:57 --> URI Class Initialized
INFO - 2024-05-04 10:13:57 --> Router Class Initialized
INFO - 2024-05-04 10:13:57 --> Output Class Initialized
INFO - 2024-05-04 10:13:57 --> Security Class Initialized
DEBUG - 2024-05-04 10:13:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-04 10:13:57 --> Input Class Initialized
INFO - 2024-05-04 10:13:57 --> Language Class Initialized
INFO - 2024-05-04 10:13:57 --> Loader Class Initialized
INFO - 2024-05-04 10:13:57 --> Helper loaded: url_helper
INFO - 2024-05-04 10:13:57 --> Helper loaded: file_helper
INFO - 2024-05-04 10:13:57 --> Helper loaded: html_helper
INFO - 2024-05-04 10:13:57 --> Helper loaded: text_helper
INFO - 2024-05-04 10:13:57 --> Helper loaded: form_helper
INFO - 2024-05-04 10:13:57 --> Helper loaded: lang_helper
INFO - 2024-05-04 10:13:57 --> Helper loaded: security_helper
INFO - 2024-05-04 10:13:57 --> Helper loaded: cookie_helper
INFO - 2024-05-04 10:13:57 --> Database Driver Class Initialized
INFO - 2024-05-04 10:13:57 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-04 10:13:57 --> Parser Class Initialized
INFO - 2024-05-04 10:13:57 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-05-04 10:13:57 --> Pagination Class Initialized
INFO - 2024-05-04 10:13:57 --> Form Validation Class Initialized
INFO - 2024-05-04 10:13:57 --> Controller Class Initialized
DEBUG - 2024-05-04 10:13:57 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-05-04 10:13:57 --> Session class already loaded. Second attempt ignored.
INFO - 2024-05-04 10:13:57 --> Model Class Initialized
INFO - 2024-05-04 10:13:57 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\mr_payments/add_payment_form.php
DEBUG - 2024-05-04 10:13:57 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-05-04 10:13:57 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\include/top_menu.php
INFO - 2024-05-04 10:13:57 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\include/admin_loggedin_info.php
INFO - 2024-05-04 10:13:57 --> Model Class Initialized
INFO - 2024-05-04 10:13:57 --> Model Class Initialized
INFO - 2024-05-04 10:13:57 --> Model Class Initialized
INFO - 2024-05-04 10:13:57 --> Model Class Initialized
INFO - 2024-05-04 10:13:58 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\include/admin_header.php
INFO - 2024-05-04 10:13:58 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\include/admin_footer.php
INFO - 2024-05-04 10:13:58 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\admin_html_template.php
INFO - 2024-05-04 10:13:58 --> Final output sent to browser
DEBUG - 2024-05-04 10:13:58 --> Total execution time: 1.0456
ERROR - 2024-05-04 10:14:13 --> $config['composer_autoload'] is set to TRUE but E:\xampp\htdocs\maurnaturo\application\vendor/autoload.php was not found.
INFO - 2024-05-04 10:14:13 --> Config Class Initialized
INFO - 2024-05-04 10:14:13 --> Hooks Class Initialized
DEBUG - 2024-05-04 10:14:13 --> UTF-8 Support Enabled
INFO - 2024-05-04 10:14:13 --> Utf8 Class Initialized
INFO - 2024-05-04 10:14:13 --> URI Class Initialized
INFO - 2024-05-04 10:14:13 --> Router Class Initialized
INFO - 2024-05-04 10:14:13 --> Output Class Initialized
INFO - 2024-05-04 10:14:13 --> Security Class Initialized
DEBUG - 2024-05-04 10:14:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-04 10:14:13 --> Input Class Initialized
INFO - 2024-05-04 10:14:13 --> Language Class Initialized
INFO - 2024-05-04 10:14:13 --> Loader Class Initialized
INFO - 2024-05-04 10:14:13 --> Helper loaded: url_helper
INFO - 2024-05-04 10:14:13 --> Helper loaded: file_helper
INFO - 2024-05-04 10:14:13 --> Helper loaded: html_helper
INFO - 2024-05-04 10:14:13 --> Helper loaded: text_helper
INFO - 2024-05-04 10:14:13 --> Helper loaded: form_helper
INFO - 2024-05-04 10:14:13 --> Helper loaded: lang_helper
INFO - 2024-05-04 10:14:13 --> Helper loaded: security_helper
INFO - 2024-05-04 10:14:13 --> Helper loaded: cookie_helper
INFO - 2024-05-04 10:14:13 --> Database Driver Class Initialized
INFO - 2024-05-04 10:14:13 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-04 10:14:13 --> Parser Class Initialized
INFO - 2024-05-04 10:14:13 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-05-04 10:14:13 --> Pagination Class Initialized
INFO - 2024-05-04 10:14:13 --> Form Validation Class Initialized
INFO - 2024-05-04 10:14:13 --> Controller Class Initialized
DEBUG - 2024-05-04 10:14:13 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-05-04 10:14:13 --> Session class already loaded. Second attempt ignored.
INFO - 2024-05-04 10:14:13 --> Model Class Initialized
INFO - 2024-05-04 10:14:13 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\mr_payments/add_payment_form.php
DEBUG - 2024-05-04 10:14:13 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-05-04 10:14:13 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\include/top_menu.php
INFO - 2024-05-04 10:14:13 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\include/admin_loggedin_info.php
INFO - 2024-05-04 10:14:13 --> Model Class Initialized
INFO - 2024-05-04 10:14:13 --> Model Class Initialized
INFO - 2024-05-04 10:14:13 --> Model Class Initialized
INFO - 2024-05-04 10:14:13 --> Model Class Initialized
INFO - 2024-05-04 10:14:14 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\include/admin_header.php
INFO - 2024-05-04 10:14:14 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\include/admin_footer.php
INFO - 2024-05-04 10:14:14 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\admin_html_template.php
INFO - 2024-05-04 10:14:14 --> Final output sent to browser
DEBUG - 2024-05-04 10:14:14 --> Total execution time: 1.1754
ERROR - 2024-05-04 10:14:41 --> $config['composer_autoload'] is set to TRUE but E:\xampp\htdocs\maurnaturo\application\vendor/autoload.php was not found.
INFO - 2024-05-04 10:14:41 --> Config Class Initialized
INFO - 2024-05-04 10:14:41 --> Hooks Class Initialized
DEBUG - 2024-05-04 10:14:41 --> UTF-8 Support Enabled
INFO - 2024-05-04 10:14:41 --> Utf8 Class Initialized
INFO - 2024-05-04 10:14:41 --> URI Class Initialized
INFO - 2024-05-04 10:14:41 --> Router Class Initialized
INFO - 2024-05-04 10:14:41 --> Output Class Initialized
INFO - 2024-05-04 10:14:41 --> Security Class Initialized
DEBUG - 2024-05-04 10:14:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-04 10:14:41 --> Input Class Initialized
INFO - 2024-05-04 10:14:41 --> Language Class Initialized
ERROR - 2024-05-04 10:14:41 --> 404 Page Not Found: Assets/plugins
ERROR - 2024-05-04 10:14:41 --> $config['composer_autoload'] is set to TRUE but E:\xampp\htdocs\maurnaturo\application\vendor/autoload.php was not found.
INFO - 2024-05-04 10:14:41 --> Config Class Initialized
INFO - 2024-05-04 10:14:41 --> Hooks Class Initialized
DEBUG - 2024-05-04 10:14:41 --> UTF-8 Support Enabled
INFO - 2024-05-04 10:14:41 --> Utf8 Class Initialized
INFO - 2024-05-04 10:14:41 --> URI Class Initialized
INFO - 2024-05-04 10:14:41 --> Router Class Initialized
INFO - 2024-05-04 10:14:41 --> Output Class Initialized
INFO - 2024-05-04 10:14:41 --> Security Class Initialized
DEBUG - 2024-05-04 10:14:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-04 10:14:41 --> Input Class Initialized
INFO - 2024-05-04 10:14:41 --> Language Class Initialized
ERROR - 2024-05-04 10:14:41 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2024-05-04 10:14:57 --> $config['composer_autoload'] is set to TRUE but E:\xampp\htdocs\maurnaturo\application\vendor/autoload.php was not found.
INFO - 2024-05-04 10:14:57 --> Config Class Initialized
INFO - 2024-05-04 10:14:57 --> Hooks Class Initialized
DEBUG - 2024-05-04 10:14:57 --> UTF-8 Support Enabled
INFO - 2024-05-04 10:14:57 --> Utf8 Class Initialized
INFO - 2024-05-04 10:14:57 --> URI Class Initialized
INFO - 2024-05-04 10:14:57 --> Router Class Initialized
INFO - 2024-05-04 10:14:57 --> Output Class Initialized
INFO - 2024-05-04 10:14:57 --> Security Class Initialized
DEBUG - 2024-05-04 10:14:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-04 10:14:57 --> Input Class Initialized
INFO - 2024-05-04 10:14:57 --> Language Class Initialized
INFO - 2024-05-04 10:14:57 --> Loader Class Initialized
INFO - 2024-05-04 10:14:57 --> Helper loaded: url_helper
INFO - 2024-05-04 10:14:57 --> Helper loaded: file_helper
INFO - 2024-05-04 10:14:57 --> Helper loaded: html_helper
INFO - 2024-05-04 10:14:57 --> Helper loaded: text_helper
INFO - 2024-05-04 10:14:57 --> Helper loaded: form_helper
INFO - 2024-05-04 10:14:57 --> Helper loaded: lang_helper
INFO - 2024-05-04 10:14:57 --> Helper loaded: security_helper
INFO - 2024-05-04 10:14:57 --> Helper loaded: cookie_helper
INFO - 2024-05-04 10:14:57 --> Database Driver Class Initialized
INFO - 2024-05-04 10:14:57 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-04 10:14:57 --> Parser Class Initialized
INFO - 2024-05-04 10:14:57 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-05-04 10:14:57 --> Pagination Class Initialized
INFO - 2024-05-04 10:14:57 --> Form Validation Class Initialized
INFO - 2024-05-04 10:14:57 --> Controller Class Initialized
DEBUG - 2024-05-04 10:14:57 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-05-04 10:14:57 --> Session class already loaded. Second attempt ignored.
INFO - 2024-05-04 10:14:57 --> Model Class Initialized
INFO - 2024-05-04 10:14:57 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\mr_payments/add_payment_form.php
DEBUG - 2024-05-04 10:14:57 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-05-04 10:14:57 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\include/top_menu.php
INFO - 2024-05-04 10:14:57 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\include/admin_loggedin_info.php
INFO - 2024-05-04 10:14:57 --> Model Class Initialized
INFO - 2024-05-04 10:14:57 --> Model Class Initialized
INFO - 2024-05-04 10:14:57 --> Model Class Initialized
INFO - 2024-05-04 10:14:57 --> Model Class Initialized
INFO - 2024-05-04 10:14:58 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\include/admin_header.php
INFO - 2024-05-04 10:14:58 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\include/admin_footer.php
INFO - 2024-05-04 10:14:58 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\admin_html_template.php
INFO - 2024-05-04 10:14:58 --> Final output sent to browser
DEBUG - 2024-05-04 10:14:58 --> Total execution time: 1.1906
ERROR - 2024-05-04 10:14:58 --> $config['composer_autoload'] is set to TRUE but E:\xampp\htdocs\maurnaturo\application\vendor/autoload.php was not found.
INFO - 2024-05-04 10:14:58 --> Config Class Initialized
INFO - 2024-05-04 10:14:58 --> Hooks Class Initialized
DEBUG - 2024-05-04 10:14:58 --> UTF-8 Support Enabled
INFO - 2024-05-04 10:14:58 --> Utf8 Class Initialized
INFO - 2024-05-04 10:14:58 --> URI Class Initialized
INFO - 2024-05-04 10:14:58 --> Router Class Initialized
INFO - 2024-05-04 10:14:58 --> Output Class Initialized
INFO - 2024-05-04 10:14:58 --> Security Class Initialized
DEBUG - 2024-05-04 10:14:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-04 10:14:58 --> Input Class Initialized
INFO - 2024-05-04 10:14:58 --> Language Class Initialized
ERROR - 2024-05-04 10:14:58 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2024-05-04 10:14:59 --> $config['composer_autoload'] is set to TRUE but E:\xampp\htdocs\maurnaturo\application\vendor/autoload.php was not found.
INFO - 2024-05-04 10:14:59 --> Config Class Initialized
INFO - 2024-05-04 10:14:59 --> Hooks Class Initialized
DEBUG - 2024-05-04 10:14:59 --> UTF-8 Support Enabled
INFO - 2024-05-04 10:14:59 --> Utf8 Class Initialized
INFO - 2024-05-04 10:14:59 --> URI Class Initialized
INFO - 2024-05-04 10:14:59 --> Router Class Initialized
INFO - 2024-05-04 10:14:59 --> Output Class Initialized
INFO - 2024-05-04 10:14:59 --> Security Class Initialized
DEBUG - 2024-05-04 10:14:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-04 10:14:59 --> Input Class Initialized
INFO - 2024-05-04 10:14:59 --> Language Class Initialized
ERROR - 2024-05-04 10:14:59 --> 404 Page Not Found: Assets/plugins
ERROR - 2024-05-04 10:15:16 --> $config['composer_autoload'] is set to TRUE but E:\xampp\htdocs\maurnaturo\application\vendor/autoload.php was not found.
INFO - 2024-05-04 10:15:16 --> Config Class Initialized
INFO - 2024-05-04 10:15:16 --> Hooks Class Initialized
DEBUG - 2024-05-04 10:15:16 --> UTF-8 Support Enabled
INFO - 2024-05-04 10:15:16 --> Utf8 Class Initialized
INFO - 2024-05-04 10:15:16 --> URI Class Initialized
INFO - 2024-05-04 10:15:16 --> Router Class Initialized
INFO - 2024-05-04 10:15:16 --> Output Class Initialized
INFO - 2024-05-04 10:15:16 --> Security Class Initialized
DEBUG - 2024-05-04 10:15:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-04 10:15:16 --> Input Class Initialized
INFO - 2024-05-04 10:15:16 --> Language Class Initialized
INFO - 2024-05-04 10:15:16 --> Loader Class Initialized
INFO - 2024-05-04 10:15:16 --> Helper loaded: url_helper
INFO - 2024-05-04 10:15:16 --> Helper loaded: file_helper
INFO - 2024-05-04 10:15:16 --> Helper loaded: html_helper
INFO - 2024-05-04 10:15:16 --> Helper loaded: text_helper
INFO - 2024-05-04 10:15:16 --> Helper loaded: form_helper
INFO - 2024-05-04 10:15:16 --> Helper loaded: lang_helper
INFO - 2024-05-04 10:15:16 --> Helper loaded: security_helper
INFO - 2024-05-04 10:15:16 --> Helper loaded: cookie_helper
INFO - 2024-05-04 10:15:16 --> Database Driver Class Initialized
INFO - 2024-05-04 10:15:16 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-04 10:15:16 --> Parser Class Initialized
INFO - 2024-05-04 10:15:16 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-05-04 10:15:16 --> Pagination Class Initialized
INFO - 2024-05-04 10:15:16 --> Form Validation Class Initialized
INFO - 2024-05-04 10:15:16 --> Controller Class Initialized
DEBUG - 2024-05-04 10:15:16 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-05-04 10:15:16 --> Session class already loaded. Second attempt ignored.
INFO - 2024-05-04 10:15:16 --> Model Class Initialized
INFO - 2024-05-04 10:15:16 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\mr_payments/add_payment_form.php
DEBUG - 2024-05-04 10:15:16 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-05-04 10:15:16 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\include/top_menu.php
INFO - 2024-05-04 10:15:16 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\include/admin_loggedin_info.php
INFO - 2024-05-04 10:15:16 --> Model Class Initialized
INFO - 2024-05-04 10:15:16 --> Model Class Initialized
INFO - 2024-05-04 10:15:16 --> Model Class Initialized
INFO - 2024-05-04 10:15:16 --> Model Class Initialized
INFO - 2024-05-04 10:15:17 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\include/admin_header.php
INFO - 2024-05-04 10:15:17 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\include/admin_footer.php
INFO - 2024-05-04 10:15:17 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\admin_html_template.php
INFO - 2024-05-04 10:15:17 --> Final output sent to browser
DEBUG - 2024-05-04 10:15:17 --> Total execution time: 1.2165
ERROR - 2024-05-04 10:15:17 --> $config['composer_autoload'] is set to TRUE but E:\xampp\htdocs\maurnaturo\application\vendor/autoload.php was not found.
INFO - 2024-05-04 10:15:17 --> Config Class Initialized
INFO - 2024-05-04 10:15:17 --> Hooks Class Initialized
DEBUG - 2024-05-04 10:15:17 --> UTF-8 Support Enabled
INFO - 2024-05-04 10:15:17 --> Utf8 Class Initialized
INFO - 2024-05-04 10:15:17 --> URI Class Initialized
INFO - 2024-05-04 10:15:17 --> Router Class Initialized
INFO - 2024-05-04 10:15:17 --> Output Class Initialized
INFO - 2024-05-04 10:15:17 --> Security Class Initialized
DEBUG - 2024-05-04 10:15:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-04 10:15:17 --> Input Class Initialized
INFO - 2024-05-04 10:15:17 --> Language Class Initialized
ERROR - 2024-05-04 10:15:17 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2024-05-04 10:15:18 --> $config['composer_autoload'] is set to TRUE but E:\xampp\htdocs\maurnaturo\application\vendor/autoload.php was not found.
INFO - 2024-05-04 10:15:18 --> Config Class Initialized
INFO - 2024-05-04 10:15:18 --> Hooks Class Initialized
DEBUG - 2024-05-04 10:15:18 --> UTF-8 Support Enabled
INFO - 2024-05-04 10:15:18 --> Utf8 Class Initialized
INFO - 2024-05-04 10:15:18 --> URI Class Initialized
INFO - 2024-05-04 10:15:18 --> Router Class Initialized
INFO - 2024-05-04 10:15:18 --> Output Class Initialized
INFO - 2024-05-04 10:15:18 --> Security Class Initialized
DEBUG - 2024-05-04 10:15:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-04 10:15:18 --> Input Class Initialized
INFO - 2024-05-04 10:15:18 --> Language Class Initialized
ERROR - 2024-05-04 10:15:18 --> 404 Page Not Found: Assets/plugins
ERROR - 2024-05-04 10:16:08 --> $config['composer_autoload'] is set to TRUE but E:\xampp\htdocs\maurnaturo\application\vendor/autoload.php was not found.
INFO - 2024-05-04 10:16:08 --> Config Class Initialized
INFO - 2024-05-04 10:16:08 --> Hooks Class Initialized
DEBUG - 2024-05-04 10:16:08 --> UTF-8 Support Enabled
INFO - 2024-05-04 10:16:08 --> Utf8 Class Initialized
INFO - 2024-05-04 10:16:08 --> URI Class Initialized
INFO - 2024-05-04 10:16:08 --> Router Class Initialized
INFO - 2024-05-04 10:16:08 --> Output Class Initialized
INFO - 2024-05-04 10:16:08 --> Security Class Initialized
DEBUG - 2024-05-04 10:16:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-04 10:16:08 --> Input Class Initialized
INFO - 2024-05-04 10:16:08 --> Language Class Initialized
INFO - 2024-05-04 10:16:08 --> Loader Class Initialized
INFO - 2024-05-04 10:16:08 --> Helper loaded: url_helper
INFO - 2024-05-04 10:16:08 --> Helper loaded: file_helper
INFO - 2024-05-04 10:16:08 --> Helper loaded: html_helper
INFO - 2024-05-04 10:16:08 --> Helper loaded: text_helper
INFO - 2024-05-04 10:16:08 --> Helper loaded: form_helper
INFO - 2024-05-04 10:16:08 --> Helper loaded: lang_helper
INFO - 2024-05-04 10:16:08 --> Helper loaded: security_helper
INFO - 2024-05-04 10:16:08 --> Helper loaded: cookie_helper
INFO - 2024-05-04 10:16:08 --> Database Driver Class Initialized
INFO - 2024-05-04 10:16:08 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-04 10:16:08 --> Parser Class Initialized
INFO - 2024-05-04 10:16:08 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-05-04 10:16:08 --> Pagination Class Initialized
INFO - 2024-05-04 10:16:08 --> Form Validation Class Initialized
INFO - 2024-05-04 10:16:08 --> Controller Class Initialized
DEBUG - 2024-05-04 10:16:08 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-05-04 10:16:08 --> Session class already loaded. Second attempt ignored.
INFO - 2024-05-04 10:16:08 --> Model Class Initialized
INFO - 2024-05-04 10:16:08 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\mr_payments/add_payment_form.php
DEBUG - 2024-05-04 10:16:08 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-05-04 10:16:08 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\include/top_menu.php
INFO - 2024-05-04 10:16:08 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\include/admin_loggedin_info.php
INFO - 2024-05-04 10:16:08 --> Model Class Initialized
INFO - 2024-05-04 10:16:08 --> Model Class Initialized
INFO - 2024-05-04 10:16:08 --> Model Class Initialized
INFO - 2024-05-04 10:16:08 --> Model Class Initialized
INFO - 2024-05-04 10:16:09 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\include/admin_header.php
INFO - 2024-05-04 10:16:09 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\include/admin_footer.php
INFO - 2024-05-04 10:16:09 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\admin_html_template.php
INFO - 2024-05-04 10:16:09 --> Final output sent to browser
DEBUG - 2024-05-04 10:16:09 --> Total execution time: 1.1915
ERROR - 2024-05-04 10:16:09 --> $config['composer_autoload'] is set to TRUE but E:\xampp\htdocs\maurnaturo\application\vendor/autoload.php was not found.
INFO - 2024-05-04 10:16:09 --> Config Class Initialized
INFO - 2024-05-04 10:16:09 --> Hooks Class Initialized
DEBUG - 2024-05-04 10:16:09 --> UTF-8 Support Enabled
INFO - 2024-05-04 10:16:09 --> Utf8 Class Initialized
INFO - 2024-05-04 10:16:09 --> URI Class Initialized
INFO - 2024-05-04 10:16:09 --> Router Class Initialized
INFO - 2024-05-04 10:16:09 --> Output Class Initialized
INFO - 2024-05-04 10:16:09 --> Security Class Initialized
DEBUG - 2024-05-04 10:16:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-04 10:16:09 --> Input Class Initialized
INFO - 2024-05-04 10:16:09 --> Language Class Initialized
ERROR - 2024-05-04 10:16:09 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2024-05-04 10:16:10 --> $config['composer_autoload'] is set to TRUE but E:\xampp\htdocs\maurnaturo\application\vendor/autoload.php was not found.
INFO - 2024-05-04 10:16:10 --> Config Class Initialized
INFO - 2024-05-04 10:16:10 --> Hooks Class Initialized
DEBUG - 2024-05-04 10:16:10 --> UTF-8 Support Enabled
INFO - 2024-05-04 10:16:10 --> Utf8 Class Initialized
INFO - 2024-05-04 10:16:10 --> URI Class Initialized
INFO - 2024-05-04 10:16:10 --> Router Class Initialized
INFO - 2024-05-04 10:16:10 --> Output Class Initialized
INFO - 2024-05-04 10:16:10 --> Security Class Initialized
DEBUG - 2024-05-04 10:16:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-04 10:16:10 --> Input Class Initialized
INFO - 2024-05-04 10:16:10 --> Language Class Initialized
ERROR - 2024-05-04 10:16:10 --> 404 Page Not Found: Assets/plugins
ERROR - 2024-05-04 10:16:30 --> $config['composer_autoload'] is set to TRUE but E:\xampp\htdocs\maurnaturo\application\vendor/autoload.php was not found.
INFO - 2024-05-04 10:16:30 --> Config Class Initialized
INFO - 2024-05-04 10:16:30 --> Hooks Class Initialized
DEBUG - 2024-05-04 10:16:30 --> UTF-8 Support Enabled
INFO - 2024-05-04 10:16:30 --> Utf8 Class Initialized
INFO - 2024-05-04 10:16:30 --> URI Class Initialized
INFO - 2024-05-04 10:16:30 --> Router Class Initialized
INFO - 2024-05-04 10:16:30 --> Output Class Initialized
INFO - 2024-05-04 10:16:30 --> Security Class Initialized
DEBUG - 2024-05-04 10:16:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-04 10:16:30 --> Input Class Initialized
INFO - 2024-05-04 10:16:30 --> Language Class Initialized
INFO - 2024-05-04 10:16:30 --> Loader Class Initialized
INFO - 2024-05-04 10:16:30 --> Helper loaded: url_helper
INFO - 2024-05-04 10:16:30 --> Helper loaded: file_helper
INFO - 2024-05-04 10:16:30 --> Helper loaded: html_helper
INFO - 2024-05-04 10:16:30 --> Helper loaded: text_helper
INFO - 2024-05-04 10:16:30 --> Helper loaded: form_helper
INFO - 2024-05-04 10:16:30 --> Helper loaded: lang_helper
INFO - 2024-05-04 10:16:30 --> Helper loaded: security_helper
INFO - 2024-05-04 10:16:30 --> Helper loaded: cookie_helper
INFO - 2024-05-04 10:16:30 --> Database Driver Class Initialized
INFO - 2024-05-04 10:16:30 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-04 10:16:30 --> Parser Class Initialized
INFO - 2024-05-04 10:16:30 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-05-04 10:16:30 --> Pagination Class Initialized
INFO - 2024-05-04 10:16:30 --> Form Validation Class Initialized
INFO - 2024-05-04 10:16:30 --> Controller Class Initialized
DEBUG - 2024-05-04 10:16:30 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-05-04 10:16:30 --> Session class already loaded. Second attempt ignored.
INFO - 2024-05-04 10:16:30 --> Model Class Initialized
INFO - 2024-05-04 10:16:30 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\mr_payments/add_payment_form.php
DEBUG - 2024-05-04 10:16:30 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-05-04 10:16:30 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\include/top_menu.php
INFO - 2024-05-04 10:16:30 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\include/admin_loggedin_info.php
INFO - 2024-05-04 10:16:30 --> Model Class Initialized
INFO - 2024-05-04 10:16:30 --> Model Class Initialized
INFO - 2024-05-04 10:16:30 --> Model Class Initialized
INFO - 2024-05-04 10:16:30 --> Model Class Initialized
INFO - 2024-05-04 10:16:31 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\include/admin_header.php
INFO - 2024-05-04 10:16:31 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\include/admin_footer.php
INFO - 2024-05-04 10:16:31 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\admin_html_template.php
INFO - 2024-05-04 10:16:31 --> Final output sent to browser
DEBUG - 2024-05-04 10:16:31 --> Total execution time: 1.1749
ERROR - 2024-05-04 10:16:40 --> $config['composer_autoload'] is set to TRUE but E:\xampp\htdocs\maurnaturo\application\vendor/autoload.php was not found.
INFO - 2024-05-04 10:16:40 --> Config Class Initialized
INFO - 2024-05-04 10:16:40 --> Hooks Class Initialized
DEBUG - 2024-05-04 10:16:40 --> UTF-8 Support Enabled
INFO - 2024-05-04 10:16:40 --> Utf8 Class Initialized
INFO - 2024-05-04 10:16:40 --> URI Class Initialized
INFO - 2024-05-04 10:16:40 --> Router Class Initialized
INFO - 2024-05-04 10:16:40 --> Output Class Initialized
INFO - 2024-05-04 10:16:40 --> Security Class Initialized
DEBUG - 2024-05-04 10:16:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-04 10:16:40 --> Input Class Initialized
INFO - 2024-05-04 10:16:40 --> Language Class Initialized
INFO - 2024-05-04 10:16:40 --> Loader Class Initialized
INFO - 2024-05-04 10:16:40 --> Helper loaded: url_helper
INFO - 2024-05-04 10:16:40 --> Helper loaded: file_helper
INFO - 2024-05-04 10:16:40 --> Helper loaded: html_helper
INFO - 2024-05-04 10:16:40 --> Helper loaded: text_helper
INFO - 2024-05-04 10:16:40 --> Helper loaded: form_helper
INFO - 2024-05-04 10:16:40 --> Helper loaded: lang_helper
INFO - 2024-05-04 10:16:40 --> Helper loaded: security_helper
INFO - 2024-05-04 10:16:40 --> Helper loaded: cookie_helper
INFO - 2024-05-04 10:16:40 --> Database Driver Class Initialized
INFO - 2024-05-04 10:16:40 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-04 10:16:40 --> Parser Class Initialized
INFO - 2024-05-04 10:16:40 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-05-04 10:16:40 --> Pagination Class Initialized
INFO - 2024-05-04 10:16:40 --> Form Validation Class Initialized
INFO - 2024-05-04 10:16:40 --> Controller Class Initialized
DEBUG - 2024-05-04 10:16:40 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-05-04 10:16:40 --> Session class already loaded. Second attempt ignored.
INFO - 2024-05-04 10:16:40 --> Model Class Initialized
INFO - 2024-05-04 10:16:40 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\mr_payments/add_payment_form.php
DEBUG - 2024-05-04 10:16:40 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-05-04 10:16:40 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\include/top_menu.php
INFO - 2024-05-04 10:16:40 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\include/admin_loggedin_info.php
INFO - 2024-05-04 10:16:40 --> Model Class Initialized
INFO - 2024-05-04 10:16:40 --> Model Class Initialized
INFO - 2024-05-04 10:16:40 --> Model Class Initialized
INFO - 2024-05-04 10:16:40 --> Model Class Initialized
INFO - 2024-05-04 10:16:41 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\include/admin_header.php
INFO - 2024-05-04 10:16:41 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\include/admin_footer.php
INFO - 2024-05-04 10:16:41 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\admin_html_template.php
INFO - 2024-05-04 10:16:41 --> Final output sent to browser
DEBUG - 2024-05-04 10:16:41 --> Total execution time: 1.2600
ERROR - 2024-05-04 10:17:13 --> $config['composer_autoload'] is set to TRUE but E:\xampp\htdocs\maurnaturo\application\vendor/autoload.php was not found.
INFO - 2024-05-04 10:17:13 --> Config Class Initialized
INFO - 2024-05-04 10:17:13 --> Hooks Class Initialized
DEBUG - 2024-05-04 10:17:13 --> UTF-8 Support Enabled
INFO - 2024-05-04 10:17:13 --> Utf8 Class Initialized
INFO - 2024-05-04 10:17:13 --> URI Class Initialized
INFO - 2024-05-04 10:17:13 --> Router Class Initialized
INFO - 2024-05-04 10:17:13 --> Output Class Initialized
INFO - 2024-05-04 10:17:13 --> Security Class Initialized
DEBUG - 2024-05-04 10:17:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-04 10:17:13 --> Input Class Initialized
INFO - 2024-05-04 10:17:13 --> Language Class Initialized
INFO - 2024-05-04 10:17:13 --> Loader Class Initialized
INFO - 2024-05-04 10:17:13 --> Helper loaded: url_helper
INFO - 2024-05-04 10:17:13 --> Helper loaded: file_helper
INFO - 2024-05-04 10:17:13 --> Helper loaded: html_helper
INFO - 2024-05-04 10:17:13 --> Helper loaded: text_helper
INFO - 2024-05-04 10:17:13 --> Helper loaded: form_helper
INFO - 2024-05-04 10:17:13 --> Helper loaded: lang_helper
INFO - 2024-05-04 10:17:13 --> Helper loaded: security_helper
INFO - 2024-05-04 10:17:13 --> Helper loaded: cookie_helper
INFO - 2024-05-04 10:17:13 --> Database Driver Class Initialized
INFO - 2024-05-04 10:17:13 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-04 10:17:13 --> Parser Class Initialized
INFO - 2024-05-04 10:17:13 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-05-04 10:17:13 --> Pagination Class Initialized
INFO - 2024-05-04 10:17:13 --> Form Validation Class Initialized
INFO - 2024-05-04 10:17:13 --> Controller Class Initialized
DEBUG - 2024-05-04 10:17:13 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-05-04 10:17:13 --> Session class already loaded. Second attempt ignored.
INFO - 2024-05-04 10:17:13 --> Model Class Initialized
INFO - 2024-05-04 10:17:13 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\mr_payments/add_payment_form.php
DEBUG - 2024-05-04 10:17:13 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-05-04 10:17:13 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\include/top_menu.php
INFO - 2024-05-04 10:17:13 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\include/admin_loggedin_info.php
INFO - 2024-05-04 10:17:13 --> Model Class Initialized
INFO - 2024-05-04 10:17:13 --> Model Class Initialized
INFO - 2024-05-04 10:17:13 --> Model Class Initialized
INFO - 2024-05-04 10:17:13 --> Model Class Initialized
INFO - 2024-05-04 10:17:14 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\include/admin_header.php
INFO - 2024-05-04 10:17:14 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\include/admin_footer.php
INFO - 2024-05-04 10:17:14 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\admin_html_template.php
INFO - 2024-05-04 10:17:14 --> Final output sent to browser
DEBUG - 2024-05-04 10:17:14 --> Total execution time: 1.1090
ERROR - 2024-05-04 10:18:05 --> $config['composer_autoload'] is set to TRUE but E:\xampp\htdocs\maurnaturo\application\vendor/autoload.php was not found.
INFO - 2024-05-04 10:18:05 --> Config Class Initialized
INFO - 2024-05-04 10:18:05 --> Hooks Class Initialized
DEBUG - 2024-05-04 10:18:05 --> UTF-8 Support Enabled
INFO - 2024-05-04 10:18:05 --> Utf8 Class Initialized
INFO - 2024-05-04 10:18:05 --> URI Class Initialized
INFO - 2024-05-04 10:18:05 --> Router Class Initialized
INFO - 2024-05-04 10:18:05 --> Output Class Initialized
INFO - 2024-05-04 10:18:05 --> Security Class Initialized
DEBUG - 2024-05-04 10:18:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-04 10:18:05 --> Input Class Initialized
INFO - 2024-05-04 10:18:05 --> Language Class Initialized
INFO - 2024-05-04 10:18:05 --> Loader Class Initialized
INFO - 2024-05-04 10:18:05 --> Helper loaded: url_helper
INFO - 2024-05-04 10:18:05 --> Helper loaded: file_helper
INFO - 2024-05-04 10:18:05 --> Helper loaded: html_helper
INFO - 2024-05-04 10:18:05 --> Helper loaded: text_helper
INFO - 2024-05-04 10:18:05 --> Helper loaded: form_helper
INFO - 2024-05-04 10:18:05 --> Helper loaded: lang_helper
INFO - 2024-05-04 10:18:05 --> Helper loaded: security_helper
INFO - 2024-05-04 10:18:05 --> Helper loaded: cookie_helper
INFO - 2024-05-04 10:18:05 --> Database Driver Class Initialized
INFO - 2024-05-04 10:18:05 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-04 10:18:05 --> Parser Class Initialized
INFO - 2024-05-04 10:18:05 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-05-04 10:18:05 --> Pagination Class Initialized
INFO - 2024-05-04 10:18:05 --> Form Validation Class Initialized
INFO - 2024-05-04 10:18:05 --> Controller Class Initialized
DEBUG - 2024-05-04 10:18:05 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-05-04 10:18:05 --> Session class already loaded. Second attempt ignored.
INFO - 2024-05-04 10:18:05 --> Model Class Initialized
INFO - 2024-05-04 10:18:05 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\mr_payments/add_payment_form.php
DEBUG - 2024-05-04 10:18:05 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-05-04 10:18:05 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\include/top_menu.php
INFO - 2024-05-04 10:18:05 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\include/admin_loggedin_info.php
INFO - 2024-05-04 10:18:05 --> Model Class Initialized
INFO - 2024-05-04 10:18:05 --> Model Class Initialized
INFO - 2024-05-04 10:18:05 --> Model Class Initialized
INFO - 2024-05-04 10:18:05 --> Model Class Initialized
INFO - 2024-05-04 10:18:06 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\include/admin_header.php
INFO - 2024-05-04 10:18:06 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\include/admin_footer.php
INFO - 2024-05-04 10:18:06 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\admin_html_template.php
INFO - 2024-05-04 10:18:06 --> Final output sent to browser
DEBUG - 2024-05-04 10:18:06 --> Total execution time: 1.1797
ERROR - 2024-05-04 10:18:08 --> $config['composer_autoload'] is set to TRUE but E:\xampp\htdocs\maurnaturo\application\vendor/autoload.php was not found.
INFO - 2024-05-04 10:18:08 --> Config Class Initialized
INFO - 2024-05-04 10:18:08 --> Hooks Class Initialized
DEBUG - 2024-05-04 10:18:08 --> UTF-8 Support Enabled
INFO - 2024-05-04 10:18:08 --> Utf8 Class Initialized
INFO - 2024-05-04 10:18:08 --> URI Class Initialized
INFO - 2024-05-04 10:18:08 --> Router Class Initialized
INFO - 2024-05-04 10:18:08 --> Output Class Initialized
INFO - 2024-05-04 10:18:08 --> Security Class Initialized
DEBUG - 2024-05-04 10:18:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-04 10:18:08 --> Input Class Initialized
INFO - 2024-05-04 10:18:08 --> Language Class Initialized
ERROR - 2024-05-04 10:18:08 --> 404 Page Not Found: Cmr_payments/manage_mr_payment
ERROR - 2024-05-04 10:18:11 --> $config['composer_autoload'] is set to TRUE but E:\xampp\htdocs\maurnaturo\application\vendor/autoload.php was not found.
INFO - 2024-05-04 10:18:11 --> Config Class Initialized
INFO - 2024-05-04 10:18:11 --> Hooks Class Initialized
DEBUG - 2024-05-04 10:18:11 --> UTF-8 Support Enabled
INFO - 2024-05-04 10:18:11 --> Utf8 Class Initialized
INFO - 2024-05-04 10:18:11 --> URI Class Initialized
INFO - 2024-05-04 10:18:11 --> Router Class Initialized
INFO - 2024-05-04 10:18:11 --> Output Class Initialized
INFO - 2024-05-04 10:18:11 --> Security Class Initialized
DEBUG - 2024-05-04 10:18:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-04 10:18:11 --> Input Class Initialized
INFO - 2024-05-04 10:18:11 --> Language Class Initialized
INFO - 2024-05-04 10:18:11 --> Loader Class Initialized
INFO - 2024-05-04 10:18:11 --> Helper loaded: url_helper
INFO - 2024-05-04 10:18:11 --> Helper loaded: file_helper
INFO - 2024-05-04 10:18:11 --> Helper loaded: html_helper
INFO - 2024-05-04 10:18:11 --> Helper loaded: text_helper
INFO - 2024-05-04 10:18:11 --> Helper loaded: form_helper
INFO - 2024-05-04 10:18:11 --> Helper loaded: lang_helper
INFO - 2024-05-04 10:18:11 --> Helper loaded: security_helper
INFO - 2024-05-04 10:18:11 --> Helper loaded: cookie_helper
INFO - 2024-05-04 10:18:11 --> Database Driver Class Initialized
INFO - 2024-05-04 10:18:11 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-04 10:18:11 --> Parser Class Initialized
INFO - 2024-05-04 10:18:11 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-05-04 10:18:11 --> Pagination Class Initialized
INFO - 2024-05-04 10:18:11 --> Form Validation Class Initialized
INFO - 2024-05-04 10:18:11 --> Controller Class Initialized
DEBUG - 2024-05-04 10:18:11 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-05-04 10:18:11 --> Session class already loaded. Second attempt ignored.
INFO - 2024-05-04 10:18:11 --> Model Class Initialized
INFO - 2024-05-04 10:18:11 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\mr_payments/add_payment_form.php
DEBUG - 2024-05-04 10:18:11 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-05-04 10:18:11 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\include/top_menu.php
INFO - 2024-05-04 10:18:11 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\include/admin_loggedin_info.php
INFO - 2024-05-04 10:18:11 --> Model Class Initialized
INFO - 2024-05-04 10:18:11 --> Model Class Initialized
INFO - 2024-05-04 10:18:11 --> Model Class Initialized
INFO - 2024-05-04 10:18:11 --> Model Class Initialized
INFO - 2024-05-04 10:18:12 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\include/admin_header.php
INFO - 2024-05-04 10:18:12 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\include/admin_footer.php
INFO - 2024-05-04 10:18:12 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\admin_html_template.php
INFO - 2024-05-04 10:18:12 --> Final output sent to browser
DEBUG - 2024-05-04 10:18:12 --> Total execution time: 1.1531
ERROR - 2024-05-04 10:18:41 --> $config['composer_autoload'] is set to TRUE but E:\xampp\htdocs\maurnaturo\application\vendor/autoload.php was not found.
INFO - 2024-05-04 10:18:41 --> Config Class Initialized
INFO - 2024-05-04 10:18:41 --> Hooks Class Initialized
DEBUG - 2024-05-04 10:18:41 --> UTF-8 Support Enabled
INFO - 2024-05-04 10:18:41 --> Utf8 Class Initialized
INFO - 2024-05-04 10:18:41 --> URI Class Initialized
INFO - 2024-05-04 10:18:41 --> Router Class Initialized
INFO - 2024-05-04 10:18:41 --> Output Class Initialized
INFO - 2024-05-04 10:18:41 --> Security Class Initialized
DEBUG - 2024-05-04 10:18:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-04 10:18:41 --> Input Class Initialized
INFO - 2024-05-04 10:18:41 --> Language Class Initialized
INFO - 2024-05-04 10:18:41 --> Loader Class Initialized
INFO - 2024-05-04 10:18:41 --> Helper loaded: url_helper
INFO - 2024-05-04 10:18:41 --> Helper loaded: file_helper
INFO - 2024-05-04 10:18:41 --> Helper loaded: html_helper
INFO - 2024-05-04 10:18:41 --> Helper loaded: text_helper
INFO - 2024-05-04 10:18:41 --> Helper loaded: form_helper
INFO - 2024-05-04 10:18:41 --> Helper loaded: lang_helper
INFO - 2024-05-04 10:18:41 --> Helper loaded: security_helper
INFO - 2024-05-04 10:18:41 --> Helper loaded: cookie_helper
INFO - 2024-05-04 10:18:41 --> Database Driver Class Initialized
INFO - 2024-05-04 10:18:41 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-04 10:18:41 --> Parser Class Initialized
INFO - 2024-05-04 10:18:41 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-05-04 10:18:41 --> Pagination Class Initialized
INFO - 2024-05-04 10:18:41 --> Form Validation Class Initialized
INFO - 2024-05-04 10:18:41 --> Controller Class Initialized
DEBUG - 2024-05-04 10:18:41 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-05-04 10:18:41 --> Session class already loaded. Second attempt ignored.
INFO - 2024-05-04 10:18:41 --> Model Class Initialized
INFO - 2024-05-04 10:18:41 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\mr_payments/add_payment_form.php
DEBUG - 2024-05-04 10:18:41 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-05-04 10:18:41 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\include/top_menu.php
INFO - 2024-05-04 10:18:41 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\include/admin_loggedin_info.php
INFO - 2024-05-04 10:18:41 --> Model Class Initialized
INFO - 2024-05-04 10:18:41 --> Model Class Initialized
INFO - 2024-05-04 10:18:41 --> Model Class Initialized
INFO - 2024-05-04 10:18:41 --> Model Class Initialized
INFO - 2024-05-04 10:18:42 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\include/admin_header.php
INFO - 2024-05-04 10:18:42 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\include/admin_footer.php
INFO - 2024-05-04 10:18:42 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\admin_html_template.php
INFO - 2024-05-04 10:18:42 --> Final output sent to browser
DEBUG - 2024-05-04 10:18:42 --> Total execution time: 1.1847
ERROR - 2024-05-04 10:18:44 --> $config['composer_autoload'] is set to TRUE but E:\xampp\htdocs\maurnaturo\application\vendor/autoload.php was not found.
INFO - 2024-05-04 10:18:44 --> Config Class Initialized
INFO - 2024-05-04 10:18:44 --> Hooks Class Initialized
DEBUG - 2024-05-04 10:18:44 --> UTF-8 Support Enabled
INFO - 2024-05-04 10:18:44 --> Utf8 Class Initialized
INFO - 2024-05-04 10:18:44 --> URI Class Initialized
INFO - 2024-05-04 10:18:44 --> Router Class Initialized
INFO - 2024-05-04 10:18:44 --> Output Class Initialized
INFO - 2024-05-04 10:18:44 --> Security Class Initialized
DEBUG - 2024-05-04 10:18:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-04 10:18:44 --> Input Class Initialized
INFO - 2024-05-04 10:18:44 --> Language Class Initialized
ERROR - 2024-05-04 10:18:44 --> 404 Page Not Found: Cmrpayments/manage_mr_payment
ERROR - 2024-05-04 10:18:45 --> $config['composer_autoload'] is set to TRUE but E:\xampp\htdocs\maurnaturo\application\vendor/autoload.php was not found.
INFO - 2024-05-04 10:18:45 --> Config Class Initialized
INFO - 2024-05-04 10:18:45 --> Hooks Class Initialized
DEBUG - 2024-05-04 10:18:45 --> UTF-8 Support Enabled
INFO - 2024-05-04 10:18:45 --> Utf8 Class Initialized
INFO - 2024-05-04 10:18:45 --> URI Class Initialized
INFO - 2024-05-04 10:18:45 --> Router Class Initialized
INFO - 2024-05-04 10:18:45 --> Output Class Initialized
INFO - 2024-05-04 10:18:45 --> Security Class Initialized
DEBUG - 2024-05-04 10:18:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-04 10:18:45 --> Input Class Initialized
INFO - 2024-05-04 10:18:45 --> Language Class Initialized
INFO - 2024-05-04 10:18:45 --> Loader Class Initialized
INFO - 2024-05-04 10:18:45 --> Helper loaded: url_helper
INFO - 2024-05-04 10:18:45 --> Helper loaded: file_helper
INFO - 2024-05-04 10:18:45 --> Helper loaded: html_helper
INFO - 2024-05-04 10:18:45 --> Helper loaded: text_helper
INFO - 2024-05-04 10:18:45 --> Helper loaded: form_helper
INFO - 2024-05-04 10:18:45 --> Helper loaded: lang_helper
INFO - 2024-05-04 10:18:45 --> Helper loaded: security_helper
INFO - 2024-05-04 10:18:45 --> Helper loaded: cookie_helper
INFO - 2024-05-04 10:18:45 --> Database Driver Class Initialized
INFO - 2024-05-04 10:18:45 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-04 10:18:45 --> Parser Class Initialized
INFO - 2024-05-04 10:18:45 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-05-04 10:18:45 --> Pagination Class Initialized
INFO - 2024-05-04 10:18:45 --> Form Validation Class Initialized
INFO - 2024-05-04 10:18:45 --> Controller Class Initialized
DEBUG - 2024-05-04 10:18:45 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-05-04 10:18:45 --> Session class already loaded. Second attempt ignored.
INFO - 2024-05-04 10:18:45 --> Model Class Initialized
INFO - 2024-05-04 10:18:45 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\mr_payments/add_payment_form.php
DEBUG - 2024-05-04 10:18:45 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-05-04 10:18:45 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\include/top_menu.php
INFO - 2024-05-04 10:18:45 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\include/admin_loggedin_info.php
INFO - 2024-05-04 10:18:46 --> Model Class Initialized
INFO - 2024-05-04 10:18:46 --> Model Class Initialized
INFO - 2024-05-04 10:18:46 --> Model Class Initialized
INFO - 2024-05-04 10:18:46 --> Model Class Initialized
INFO - 2024-05-04 10:18:47 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\include/admin_header.php
INFO - 2024-05-04 10:18:47 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\include/admin_footer.php
INFO - 2024-05-04 10:18:47 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\admin_html_template.php
INFO - 2024-05-04 10:18:47 --> Final output sent to browser
DEBUG - 2024-05-04 10:18:47 --> Total execution time: 1.1949
ERROR - 2024-05-04 10:19:26 --> $config['composer_autoload'] is set to TRUE but E:\xampp\htdocs\maurnaturo\application\vendor/autoload.php was not found.
INFO - 2024-05-04 10:19:26 --> Config Class Initialized
INFO - 2024-05-04 10:19:26 --> Hooks Class Initialized
DEBUG - 2024-05-04 10:19:26 --> UTF-8 Support Enabled
INFO - 2024-05-04 10:19:26 --> Utf8 Class Initialized
INFO - 2024-05-04 10:19:26 --> URI Class Initialized
INFO - 2024-05-04 10:19:26 --> Router Class Initialized
INFO - 2024-05-04 10:19:26 --> Output Class Initialized
INFO - 2024-05-04 10:19:26 --> Security Class Initialized
DEBUG - 2024-05-04 10:19:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-04 10:19:26 --> Input Class Initialized
INFO - 2024-05-04 10:19:26 --> Language Class Initialized
INFO - 2024-05-04 10:19:26 --> Loader Class Initialized
INFO - 2024-05-04 10:19:26 --> Helper loaded: url_helper
INFO - 2024-05-04 10:19:26 --> Helper loaded: file_helper
INFO - 2024-05-04 10:19:26 --> Helper loaded: html_helper
INFO - 2024-05-04 10:19:26 --> Helper loaded: text_helper
INFO - 2024-05-04 10:19:26 --> Helper loaded: form_helper
INFO - 2024-05-04 10:19:26 --> Helper loaded: lang_helper
INFO - 2024-05-04 10:19:26 --> Helper loaded: security_helper
INFO - 2024-05-04 10:19:26 --> Helper loaded: cookie_helper
INFO - 2024-05-04 10:19:26 --> Database Driver Class Initialized
INFO - 2024-05-04 10:19:26 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-04 10:19:26 --> Parser Class Initialized
INFO - 2024-05-04 10:19:26 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-05-04 10:19:26 --> Pagination Class Initialized
INFO - 2024-05-04 10:19:26 --> Form Validation Class Initialized
INFO - 2024-05-04 10:19:26 --> Controller Class Initialized
DEBUG - 2024-05-04 10:19:26 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-05-04 10:19:26 --> Session class already loaded. Second attempt ignored.
INFO - 2024-05-04 10:19:26 --> Model Class Initialized
INFO - 2024-05-04 10:19:26 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\mr_payments/add_payment_form.php
DEBUG - 2024-05-04 10:19:26 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-05-04 10:19:26 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\include/top_menu.php
INFO - 2024-05-04 10:19:26 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\include/admin_loggedin_info.php
INFO - 2024-05-04 10:19:26 --> Model Class Initialized
INFO - 2024-05-04 10:19:26 --> Model Class Initialized
INFO - 2024-05-04 10:19:26 --> Model Class Initialized
INFO - 2024-05-04 10:19:26 --> Model Class Initialized
INFO - 2024-05-04 10:19:27 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\include/admin_header.php
INFO - 2024-05-04 10:19:27 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\include/admin_footer.php
INFO - 2024-05-04 10:19:27 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\admin_html_template.php
INFO - 2024-05-04 10:19:27 --> Final output sent to browser
DEBUG - 2024-05-04 10:19:27 --> Total execution time: 1.2229
ERROR - 2024-05-04 10:19:30 --> $config['composer_autoload'] is set to TRUE but E:\xampp\htdocs\maurnaturo\application\vendor/autoload.php was not found.
INFO - 2024-05-04 10:19:30 --> Config Class Initialized
INFO - 2024-05-04 10:19:30 --> Hooks Class Initialized
DEBUG - 2024-05-04 10:19:30 --> UTF-8 Support Enabled
INFO - 2024-05-04 10:19:30 --> Utf8 Class Initialized
INFO - 2024-05-04 10:19:30 --> URI Class Initialized
INFO - 2024-05-04 10:19:30 --> Router Class Initialized
INFO - 2024-05-04 10:19:30 --> Output Class Initialized
INFO - 2024-05-04 10:19:30 --> Security Class Initialized
DEBUG - 2024-05-04 10:19:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-04 10:19:30 --> Input Class Initialized
INFO - 2024-05-04 10:19:30 --> Language Class Initialized
INFO - 2024-05-04 10:19:30 --> Loader Class Initialized
INFO - 2024-05-04 10:19:30 --> Helper loaded: url_helper
INFO - 2024-05-04 10:19:30 --> Helper loaded: file_helper
INFO - 2024-05-04 10:19:30 --> Helper loaded: html_helper
INFO - 2024-05-04 10:19:30 --> Helper loaded: text_helper
INFO - 2024-05-04 10:19:30 --> Helper loaded: form_helper
INFO - 2024-05-04 10:19:30 --> Helper loaded: lang_helper
INFO - 2024-05-04 10:19:30 --> Helper loaded: security_helper
INFO - 2024-05-04 10:19:30 --> Helper loaded: cookie_helper
INFO - 2024-05-04 10:19:30 --> Database Driver Class Initialized
INFO - 2024-05-04 10:19:30 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-04 10:19:30 --> Parser Class Initialized
INFO - 2024-05-04 10:19:30 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-05-04 10:19:30 --> Pagination Class Initialized
INFO - 2024-05-04 10:19:30 --> Form Validation Class Initialized
INFO - 2024-05-04 10:19:30 --> Controller Class Initialized
DEBUG - 2024-05-04 10:19:30 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-05-04 10:19:30 --> Session class already loaded. Second attempt ignored.
INFO - 2024-05-04 10:19:30 --> Model Class Initialized
DEBUG - 2024-05-04 10:19:30 --> Lmrpayments class already loaded. Second attempt ignored.
INFO - 2024-05-04 10:19:30 --> Model Class Initialized
ERROR - 2024-05-04 10:19:30 --> Query error: Table 'db_maurnaturo.mrpaymments' doesn't exist - Invalid query: SELECT *
FROM `mrpaymments`
 LIMIT 1
ERROR - 2024-05-04 10:19:30 --> Severity: error --> Exception: Call to a member function num_rows() on bool E:\xampp\htdocs\maurnaturo\application\models\Mrpaymment.php 33
ERROR - 2024-05-04 10:19:32 --> $config['composer_autoload'] is set to TRUE but E:\xampp\htdocs\maurnaturo\application\vendor/autoload.php was not found.
INFO - 2024-05-04 10:19:32 --> Config Class Initialized
INFO - 2024-05-04 10:19:32 --> Hooks Class Initialized
DEBUG - 2024-05-04 10:19:32 --> UTF-8 Support Enabled
INFO - 2024-05-04 10:19:32 --> Utf8 Class Initialized
INFO - 2024-05-04 10:19:32 --> URI Class Initialized
INFO - 2024-05-04 10:19:32 --> Router Class Initialized
INFO - 2024-05-04 10:19:32 --> Output Class Initialized
INFO - 2024-05-04 10:19:32 --> Security Class Initialized
DEBUG - 2024-05-04 10:19:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-04 10:19:32 --> Input Class Initialized
INFO - 2024-05-04 10:19:32 --> Language Class Initialized
INFO - 2024-05-04 10:19:32 --> Loader Class Initialized
INFO - 2024-05-04 10:19:32 --> Helper loaded: url_helper
INFO - 2024-05-04 10:19:32 --> Helper loaded: file_helper
INFO - 2024-05-04 10:19:32 --> Helper loaded: html_helper
INFO - 2024-05-04 10:19:32 --> Helper loaded: text_helper
INFO - 2024-05-04 10:19:32 --> Helper loaded: form_helper
INFO - 2024-05-04 10:19:32 --> Helper loaded: lang_helper
INFO - 2024-05-04 10:19:32 --> Helper loaded: security_helper
INFO - 2024-05-04 10:19:32 --> Helper loaded: cookie_helper
INFO - 2024-05-04 10:19:32 --> Database Driver Class Initialized
INFO - 2024-05-04 10:19:32 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-04 10:19:32 --> Parser Class Initialized
INFO - 2024-05-04 10:19:32 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-05-04 10:19:32 --> Pagination Class Initialized
INFO - 2024-05-04 10:19:32 --> Form Validation Class Initialized
INFO - 2024-05-04 10:19:32 --> Controller Class Initialized
DEBUG - 2024-05-04 10:19:32 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-05-04 10:19:32 --> Session class already loaded. Second attempt ignored.
INFO - 2024-05-04 10:19:32 --> Model Class Initialized
INFO - 2024-05-04 10:19:32 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\mr_payments/add_payment_form.php
DEBUG - 2024-05-04 10:19:32 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-05-04 10:19:32 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\include/top_menu.php
INFO - 2024-05-04 10:19:32 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\include/admin_loggedin_info.php
INFO - 2024-05-04 10:19:32 --> Model Class Initialized
INFO - 2024-05-04 10:19:32 --> Model Class Initialized
INFO - 2024-05-04 10:19:32 --> Model Class Initialized
INFO - 2024-05-04 10:19:32 --> Model Class Initialized
INFO - 2024-05-04 10:19:33 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\include/admin_header.php
INFO - 2024-05-04 10:19:33 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\include/admin_footer.php
INFO - 2024-05-04 10:19:33 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\admin_html_template.php
INFO - 2024-05-04 10:19:33 --> Final output sent to browser
DEBUG - 2024-05-04 10:19:33 --> Total execution time: 1.1999
ERROR - 2024-05-04 10:20:12 --> $config['composer_autoload'] is set to TRUE but E:\xampp\htdocs\maurnaturo\application\vendor/autoload.php was not found.
INFO - 2024-05-04 10:20:12 --> Config Class Initialized
INFO - 2024-05-04 10:20:12 --> Hooks Class Initialized
DEBUG - 2024-05-04 10:20:12 --> UTF-8 Support Enabled
INFO - 2024-05-04 10:20:12 --> Utf8 Class Initialized
INFO - 2024-05-04 10:20:12 --> URI Class Initialized
INFO - 2024-05-04 10:20:12 --> Router Class Initialized
INFO - 2024-05-04 10:20:12 --> Output Class Initialized
INFO - 2024-05-04 10:20:12 --> Security Class Initialized
DEBUG - 2024-05-04 10:20:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-04 10:20:12 --> Input Class Initialized
INFO - 2024-05-04 10:20:12 --> Language Class Initialized
INFO - 2024-05-04 10:20:12 --> Loader Class Initialized
INFO - 2024-05-04 10:20:12 --> Helper loaded: url_helper
INFO - 2024-05-04 10:20:12 --> Helper loaded: file_helper
INFO - 2024-05-04 10:20:12 --> Helper loaded: html_helper
INFO - 2024-05-04 10:20:12 --> Helper loaded: text_helper
INFO - 2024-05-04 10:20:12 --> Helper loaded: form_helper
INFO - 2024-05-04 10:20:12 --> Helper loaded: lang_helper
INFO - 2024-05-04 10:20:12 --> Helper loaded: security_helper
INFO - 2024-05-04 10:20:12 --> Helper loaded: cookie_helper
INFO - 2024-05-04 10:20:12 --> Database Driver Class Initialized
INFO - 2024-05-04 10:20:12 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-04 10:20:12 --> Parser Class Initialized
INFO - 2024-05-04 10:20:12 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-05-04 10:20:12 --> Pagination Class Initialized
INFO - 2024-05-04 10:20:12 --> Form Validation Class Initialized
INFO - 2024-05-04 10:20:12 --> Controller Class Initialized
DEBUG - 2024-05-04 10:20:12 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-05-04 10:20:12 --> Session class already loaded. Second attempt ignored.
INFO - 2024-05-04 10:20:12 --> Model Class Initialized
INFO - 2024-05-04 10:20:12 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\mr_payments/add_payment_form.php
DEBUG - 2024-05-04 10:20:12 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-05-04 10:20:12 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\include/top_menu.php
INFO - 2024-05-04 10:20:12 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\include/admin_loggedin_info.php
INFO - 2024-05-04 10:20:12 --> Model Class Initialized
INFO - 2024-05-04 10:20:12 --> Model Class Initialized
INFO - 2024-05-04 10:20:12 --> Model Class Initialized
INFO - 2024-05-04 10:20:12 --> Model Class Initialized
INFO - 2024-05-04 10:20:13 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\include/admin_header.php
INFO - 2024-05-04 10:20:13 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\include/admin_footer.php
INFO - 2024-05-04 10:20:13 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\admin_html_template.php
INFO - 2024-05-04 10:20:13 --> Final output sent to browser
DEBUG - 2024-05-04 10:20:13 --> Total execution time: 1.1647
ERROR - 2024-05-04 10:20:56 --> $config['composer_autoload'] is set to TRUE but E:\xampp\htdocs\maurnaturo\application\vendor/autoload.php was not found.
INFO - 2024-05-04 10:20:56 --> Config Class Initialized
INFO - 2024-05-04 10:20:56 --> Hooks Class Initialized
DEBUG - 2024-05-04 10:20:56 --> UTF-8 Support Enabled
INFO - 2024-05-04 10:20:56 --> Utf8 Class Initialized
INFO - 2024-05-04 10:20:56 --> URI Class Initialized
INFO - 2024-05-04 10:20:56 --> Router Class Initialized
INFO - 2024-05-04 10:20:56 --> Output Class Initialized
INFO - 2024-05-04 10:20:56 --> Security Class Initialized
DEBUG - 2024-05-04 10:20:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-04 10:20:56 --> Input Class Initialized
INFO - 2024-05-04 10:20:56 --> Language Class Initialized
INFO - 2024-05-04 10:20:56 --> Loader Class Initialized
INFO - 2024-05-04 10:20:56 --> Helper loaded: url_helper
INFO - 2024-05-04 10:20:56 --> Helper loaded: file_helper
INFO - 2024-05-04 10:20:56 --> Helper loaded: html_helper
INFO - 2024-05-04 10:20:56 --> Helper loaded: text_helper
INFO - 2024-05-04 10:20:56 --> Helper loaded: form_helper
INFO - 2024-05-04 10:20:56 --> Helper loaded: lang_helper
INFO - 2024-05-04 10:20:56 --> Helper loaded: security_helper
INFO - 2024-05-04 10:20:56 --> Helper loaded: cookie_helper
INFO - 2024-05-04 10:20:56 --> Database Driver Class Initialized
INFO - 2024-05-04 10:20:56 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-04 10:20:56 --> Parser Class Initialized
INFO - 2024-05-04 10:20:56 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-05-04 10:20:56 --> Pagination Class Initialized
INFO - 2024-05-04 10:20:56 --> Form Validation Class Initialized
INFO - 2024-05-04 10:20:56 --> Controller Class Initialized
DEBUG - 2024-05-04 10:20:56 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-05-04 10:20:56 --> Session class already loaded. Second attempt ignored.
INFO - 2024-05-04 10:20:56 --> Model Class Initialized
INFO - 2024-05-04 10:20:56 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\mr_payments/add_payment_form.php
DEBUG - 2024-05-04 10:20:56 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-05-04 10:20:56 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\include/top_menu.php
INFO - 2024-05-04 10:20:56 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\include/admin_loggedin_info.php
INFO - 2024-05-04 10:20:56 --> Model Class Initialized
INFO - 2024-05-04 10:20:56 --> Model Class Initialized
INFO - 2024-05-04 10:20:56 --> Model Class Initialized
INFO - 2024-05-04 10:20:56 --> Model Class Initialized
INFO - 2024-05-04 10:20:57 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\include/admin_header.php
INFO - 2024-05-04 10:20:57 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\include/admin_footer.php
INFO - 2024-05-04 10:20:57 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\admin_html_template.php
INFO - 2024-05-04 10:20:57 --> Final output sent to browser
DEBUG - 2024-05-04 10:20:57 --> Total execution time: 1.1278
ERROR - 2024-05-04 10:20:59 --> $config['composer_autoload'] is set to TRUE but E:\xampp\htdocs\maurnaturo\application\vendor/autoload.php was not found.
INFO - 2024-05-04 10:20:59 --> Config Class Initialized
INFO - 2024-05-04 10:20:59 --> Hooks Class Initialized
DEBUG - 2024-05-04 10:20:59 --> UTF-8 Support Enabled
INFO - 2024-05-04 10:20:59 --> Utf8 Class Initialized
INFO - 2024-05-04 10:20:59 --> URI Class Initialized
INFO - 2024-05-04 10:20:59 --> Router Class Initialized
INFO - 2024-05-04 10:20:59 --> Output Class Initialized
INFO - 2024-05-04 10:20:59 --> Security Class Initialized
DEBUG - 2024-05-04 10:20:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-04 10:20:59 --> Input Class Initialized
INFO - 2024-05-04 10:20:59 --> Language Class Initialized
INFO - 2024-05-04 10:20:59 --> Loader Class Initialized
INFO - 2024-05-04 10:20:59 --> Helper loaded: url_helper
INFO - 2024-05-04 10:20:59 --> Helper loaded: file_helper
INFO - 2024-05-04 10:20:59 --> Helper loaded: html_helper
INFO - 2024-05-04 10:20:59 --> Helper loaded: text_helper
INFO - 2024-05-04 10:20:59 --> Helper loaded: form_helper
INFO - 2024-05-04 10:20:59 --> Helper loaded: lang_helper
INFO - 2024-05-04 10:20:59 --> Helper loaded: security_helper
INFO - 2024-05-04 10:20:59 --> Helper loaded: cookie_helper
INFO - 2024-05-04 10:20:59 --> Database Driver Class Initialized
INFO - 2024-05-04 10:20:59 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-04 10:20:59 --> Parser Class Initialized
INFO - 2024-05-04 10:20:59 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-05-04 10:20:59 --> Pagination Class Initialized
INFO - 2024-05-04 10:20:59 --> Form Validation Class Initialized
INFO - 2024-05-04 10:20:59 --> Controller Class Initialized
DEBUG - 2024-05-04 10:20:59 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-05-04 10:20:59 --> Session class already loaded. Second attempt ignored.
INFO - 2024-05-04 10:20:59 --> Model Class Initialized
DEBUG - 2024-05-04 10:20:59 --> Lmrpayments class already loaded. Second attempt ignored.
INFO - 2024-05-04 10:20:59 --> Model Class Initialized
INFO - 2024-05-04 10:20:59 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\mr_payments/payment.php
DEBUG - 2024-05-04 10:20:59 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-05-04 10:20:59 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\include/top_menu.php
INFO - 2024-05-04 10:20:59 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\include/admin_loggedin_info.php
INFO - 2024-05-04 10:20:59 --> Model Class Initialized
INFO - 2024-05-04 10:20:59 --> Model Class Initialized
INFO - 2024-05-04 10:20:59 --> Model Class Initialized
INFO - 2024-05-04 10:21:00 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\include/admin_header.php
INFO - 2024-05-04 10:21:00 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\include/admin_footer.php
INFO - 2024-05-04 10:21:00 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\admin_html_template.php
INFO - 2024-05-04 10:21:00 --> Final output sent to browser
DEBUG - 2024-05-04 10:21:00 --> Total execution time: 1.1310
ERROR - 2024-05-04 10:21:00 --> $config['composer_autoload'] is set to TRUE but E:\xampp\htdocs\maurnaturo\application\vendor/autoload.php was not found.
INFO - 2024-05-04 10:21:00 --> Config Class Initialized
INFO - 2024-05-04 10:21:00 --> Hooks Class Initialized
DEBUG - 2024-05-04 10:21:00 --> UTF-8 Support Enabled
INFO - 2024-05-04 10:21:00 --> Utf8 Class Initialized
INFO - 2024-05-04 10:21:00 --> URI Class Initialized
INFO - 2024-05-04 10:21:00 --> Router Class Initialized
INFO - 2024-05-04 10:21:00 --> Output Class Initialized
INFO - 2024-05-04 10:21:00 --> Security Class Initialized
DEBUG - 2024-05-04 10:21:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-04 10:21:00 --> Input Class Initialized
INFO - 2024-05-04 10:21:00 --> Language Class Initialized
INFO - 2024-05-04 10:21:00 --> Loader Class Initialized
INFO - 2024-05-04 10:21:00 --> Helper loaded: url_helper
INFO - 2024-05-04 10:21:00 --> Helper loaded: file_helper
INFO - 2024-05-04 10:21:00 --> Helper loaded: html_helper
INFO - 2024-05-04 10:21:00 --> Helper loaded: text_helper
INFO - 2024-05-04 10:21:00 --> Helper loaded: form_helper
INFO - 2024-05-04 10:21:00 --> Helper loaded: lang_helper
INFO - 2024-05-04 10:21:00 --> Helper loaded: security_helper
INFO - 2024-05-04 10:21:00 --> Helper loaded: cookie_helper
INFO - 2024-05-04 10:21:00 --> Database Driver Class Initialized
INFO - 2024-05-04 10:21:00 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-04 10:21:00 --> Parser Class Initialized
INFO - 2024-05-04 10:21:00 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-05-04 10:21:00 --> Pagination Class Initialized
INFO - 2024-05-04 10:21:00 --> Form Validation Class Initialized
INFO - 2024-05-04 10:21:00 --> Controller Class Initialized
DEBUG - 2024-05-04 10:21:00 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-05-04 10:21:00 --> Session class already loaded. Second attempt ignored.
INFO - 2024-05-04 10:21:00 --> Model Class Initialized
INFO - 2024-05-04 10:21:00 --> Final output sent to browser
DEBUG - 2024-05-04 10:21:00 --> Total execution time: 0.1134
ERROR - 2024-05-04 10:36:09 --> $config['composer_autoload'] is set to TRUE but E:\xampp\htdocs\maurnaturo\application\vendor/autoload.php was not found.
INFO - 2024-05-04 10:36:09 --> Config Class Initialized
INFO - 2024-05-04 10:36:09 --> Hooks Class Initialized
DEBUG - 2024-05-04 10:36:09 --> UTF-8 Support Enabled
INFO - 2024-05-04 10:36:09 --> Utf8 Class Initialized
INFO - 2024-05-04 10:36:09 --> URI Class Initialized
INFO - 2024-05-04 10:36:09 --> Router Class Initialized
INFO - 2024-05-04 10:36:09 --> Output Class Initialized
INFO - 2024-05-04 10:36:09 --> Security Class Initialized
DEBUG - 2024-05-04 10:36:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-04 10:36:09 --> Input Class Initialized
INFO - 2024-05-04 10:36:09 --> Language Class Initialized
INFO - 2024-05-04 10:36:09 --> Loader Class Initialized
INFO - 2024-05-04 10:36:09 --> Helper loaded: url_helper
INFO - 2024-05-04 10:36:09 --> Helper loaded: file_helper
INFO - 2024-05-04 10:36:09 --> Helper loaded: html_helper
INFO - 2024-05-04 10:36:09 --> Helper loaded: text_helper
INFO - 2024-05-04 10:36:09 --> Helper loaded: form_helper
INFO - 2024-05-04 10:36:09 --> Helper loaded: lang_helper
INFO - 2024-05-04 10:36:09 --> Helper loaded: security_helper
INFO - 2024-05-04 10:36:09 --> Helper loaded: cookie_helper
INFO - 2024-05-04 10:36:09 --> Database Driver Class Initialized
INFO - 2024-05-04 10:36:09 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-04 10:36:09 --> Parser Class Initialized
INFO - 2024-05-04 10:36:09 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-05-04 10:36:09 --> Pagination Class Initialized
INFO - 2024-05-04 10:36:09 --> Form Validation Class Initialized
INFO - 2024-05-04 10:36:09 --> Controller Class Initialized
DEBUG - 2024-05-04 10:36:09 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-05-04 10:36:09 --> Session class already loaded. Second attempt ignored.
INFO - 2024-05-04 10:36:09 --> Model Class Initialized
DEBUG - 2024-05-04 10:36:09 --> Lmrpayments class already loaded. Second attempt ignored.
INFO - 2024-05-04 10:36:09 --> Model Class Initialized
INFO - 2024-05-04 10:36:09 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\mr_payments/payment.php
DEBUG - 2024-05-04 10:36:09 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-05-04 10:36:09 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\include/top_menu.php
INFO - 2024-05-04 10:36:09 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\include/admin_loggedin_info.php
INFO - 2024-05-04 10:36:09 --> Model Class Initialized
INFO - 2024-05-04 10:36:09 --> Model Class Initialized
INFO - 2024-05-04 10:36:09 --> Model Class Initialized
INFO - 2024-05-04 10:36:10 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\include/admin_header.php
INFO - 2024-05-04 10:36:10 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\include/admin_footer.php
INFO - 2024-05-04 10:36:10 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\admin_html_template.php
INFO - 2024-05-04 10:36:10 --> Final output sent to browser
DEBUG - 2024-05-04 10:36:10 --> Total execution time: 1.2045
ERROR - 2024-05-04 10:36:10 --> $config['composer_autoload'] is set to TRUE but E:\xampp\htdocs\maurnaturo\application\vendor/autoload.php was not found.
INFO - 2024-05-04 10:36:10 --> Config Class Initialized
INFO - 2024-05-04 10:36:10 --> Hooks Class Initialized
DEBUG - 2024-05-04 10:36:10 --> UTF-8 Support Enabled
INFO - 2024-05-04 10:36:10 --> Utf8 Class Initialized
INFO - 2024-05-04 10:36:10 --> URI Class Initialized
INFO - 2024-05-04 10:36:10 --> Router Class Initialized
INFO - 2024-05-04 10:36:10 --> Output Class Initialized
INFO - 2024-05-04 10:36:10 --> Security Class Initialized
DEBUG - 2024-05-04 10:36:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-04 10:36:10 --> Input Class Initialized
INFO - 2024-05-04 10:36:10 --> Language Class Initialized
INFO - 2024-05-04 10:36:10 --> Loader Class Initialized
INFO - 2024-05-04 10:36:10 --> Helper loaded: url_helper
INFO - 2024-05-04 10:36:10 --> Helper loaded: file_helper
INFO - 2024-05-04 10:36:10 --> Helper loaded: html_helper
INFO - 2024-05-04 10:36:10 --> Helper loaded: text_helper
INFO - 2024-05-04 10:36:10 --> Helper loaded: form_helper
INFO - 2024-05-04 10:36:10 --> Helper loaded: lang_helper
INFO - 2024-05-04 10:36:10 --> Helper loaded: security_helper
INFO - 2024-05-04 10:36:10 --> Helper loaded: cookie_helper
INFO - 2024-05-04 10:36:10 --> Database Driver Class Initialized
INFO - 2024-05-04 10:36:10 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-04 10:36:10 --> Parser Class Initialized
INFO - 2024-05-04 10:36:10 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-05-04 10:36:10 --> Pagination Class Initialized
INFO - 2024-05-04 10:36:10 --> Form Validation Class Initialized
INFO - 2024-05-04 10:36:10 --> Controller Class Initialized
DEBUG - 2024-05-04 10:36:10 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-05-04 10:36:10 --> Session class already loaded. Second attempt ignored.
INFO - 2024-05-04 10:36:10 --> Model Class Initialized
INFO - 2024-05-04 10:36:10 --> Final output sent to browser
DEBUG - 2024-05-04 10:36:10 --> Total execution time: 0.0950
ERROR - 2024-05-04 10:39:02 --> $config['composer_autoload'] is set to TRUE but E:\xampp\htdocs\maurnaturo\application\vendor/autoload.php was not found.
INFO - 2024-05-04 10:39:02 --> Config Class Initialized
INFO - 2024-05-04 10:39:02 --> Hooks Class Initialized
DEBUG - 2024-05-04 10:39:02 --> UTF-8 Support Enabled
INFO - 2024-05-04 10:39:02 --> Utf8 Class Initialized
INFO - 2024-05-04 10:39:02 --> URI Class Initialized
INFO - 2024-05-04 10:39:02 --> Router Class Initialized
INFO - 2024-05-04 10:39:02 --> Output Class Initialized
INFO - 2024-05-04 10:39:02 --> Security Class Initialized
DEBUG - 2024-05-04 10:39:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-04 10:39:02 --> Input Class Initialized
INFO - 2024-05-04 10:39:02 --> Language Class Initialized
INFO - 2024-05-04 10:39:02 --> Loader Class Initialized
INFO - 2024-05-04 10:39:02 --> Helper loaded: url_helper
INFO - 2024-05-04 10:39:02 --> Helper loaded: file_helper
INFO - 2024-05-04 10:39:02 --> Helper loaded: html_helper
INFO - 2024-05-04 10:39:02 --> Helper loaded: text_helper
INFO - 2024-05-04 10:39:02 --> Helper loaded: form_helper
INFO - 2024-05-04 10:39:02 --> Helper loaded: lang_helper
INFO - 2024-05-04 10:39:02 --> Helper loaded: security_helper
INFO - 2024-05-04 10:39:02 --> Helper loaded: cookie_helper
INFO - 2024-05-04 10:39:02 --> Database Driver Class Initialized
INFO - 2024-05-04 10:39:02 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-04 10:39:02 --> Parser Class Initialized
INFO - 2024-05-04 10:39:02 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-05-04 10:39:02 --> Pagination Class Initialized
INFO - 2024-05-04 10:39:02 --> Form Validation Class Initialized
INFO - 2024-05-04 10:39:02 --> Controller Class Initialized
DEBUG - 2024-05-04 10:39:02 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-05-04 10:39:02 --> Session class already loaded. Second attempt ignored.
INFO - 2024-05-04 10:39:02 --> Model Class Initialized
DEBUG - 2024-05-04 10:39:02 --> Lmrpayments class already loaded. Second attempt ignored.
INFO - 2024-05-04 10:39:02 --> Model Class Initialized
INFO - 2024-05-04 10:39:02 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\mr_payments/payment.php
DEBUG - 2024-05-04 10:39:02 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-05-04 10:39:02 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\include/top_menu.php
INFO - 2024-05-04 10:39:02 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\include/admin_loggedin_info.php
INFO - 2024-05-04 10:39:02 --> Model Class Initialized
INFO - 2024-05-04 10:39:02 --> Model Class Initialized
INFO - 2024-05-04 10:39:02 --> Model Class Initialized
INFO - 2024-05-04 10:39:03 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\include/admin_header.php
INFO - 2024-05-04 10:39:03 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\include/admin_footer.php
INFO - 2024-05-04 10:39:03 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\admin_html_template.php
INFO - 2024-05-04 10:39:03 --> Final output sent to browser
DEBUG - 2024-05-04 10:39:03 --> Total execution time: 1.1595
ERROR - 2024-05-04 10:39:04 --> $config['composer_autoload'] is set to TRUE but E:\xampp\htdocs\maurnaturo\application\vendor/autoload.php was not found.
INFO - 2024-05-04 10:39:04 --> Config Class Initialized
INFO - 2024-05-04 10:39:04 --> Hooks Class Initialized
DEBUG - 2024-05-04 10:39:04 --> UTF-8 Support Enabled
INFO - 2024-05-04 10:39:04 --> Utf8 Class Initialized
INFO - 2024-05-04 10:39:04 --> URI Class Initialized
INFO - 2024-05-04 10:39:04 --> Router Class Initialized
INFO - 2024-05-04 10:39:04 --> Output Class Initialized
INFO - 2024-05-04 10:39:04 --> Security Class Initialized
DEBUG - 2024-05-04 10:39:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-04 10:39:04 --> Input Class Initialized
INFO - 2024-05-04 10:39:04 --> Language Class Initialized
INFO - 2024-05-04 10:39:04 --> Loader Class Initialized
INFO - 2024-05-04 10:39:04 --> Helper loaded: url_helper
INFO - 2024-05-04 10:39:04 --> Helper loaded: file_helper
INFO - 2024-05-04 10:39:04 --> Helper loaded: html_helper
INFO - 2024-05-04 10:39:04 --> Helper loaded: text_helper
INFO - 2024-05-04 10:39:04 --> Helper loaded: form_helper
INFO - 2024-05-04 10:39:04 --> Helper loaded: lang_helper
INFO - 2024-05-04 10:39:04 --> Helper loaded: security_helper
INFO - 2024-05-04 10:39:04 --> Helper loaded: cookie_helper
INFO - 2024-05-04 10:39:04 --> Database Driver Class Initialized
INFO - 2024-05-04 10:39:04 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-04 10:39:04 --> Parser Class Initialized
INFO - 2024-05-04 10:39:04 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-05-04 10:39:04 --> Pagination Class Initialized
INFO - 2024-05-04 10:39:04 --> Form Validation Class Initialized
INFO - 2024-05-04 10:39:04 --> Controller Class Initialized
DEBUG - 2024-05-04 10:39:04 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-05-04 10:39:04 --> Session class already loaded. Second attempt ignored.
INFO - 2024-05-04 10:39:04 --> Model Class Initialized
INFO - 2024-05-04 10:39:04 --> Final output sent to browser
DEBUG - 2024-05-04 10:39:04 --> Total execution time: 0.1015
ERROR - 2024-05-04 10:54:15 --> $config['composer_autoload'] is set to TRUE but E:\xampp\htdocs\maurnaturo\application\vendor/autoload.php was not found.
INFO - 2024-05-04 10:54:15 --> Config Class Initialized
INFO - 2024-05-04 10:54:15 --> Hooks Class Initialized
DEBUG - 2024-05-04 10:54:15 --> UTF-8 Support Enabled
INFO - 2024-05-04 10:54:15 --> Utf8 Class Initialized
INFO - 2024-05-04 10:54:15 --> URI Class Initialized
INFO - 2024-05-04 10:54:15 --> Router Class Initialized
INFO - 2024-05-04 10:54:15 --> Output Class Initialized
INFO - 2024-05-04 10:54:15 --> Security Class Initialized
DEBUG - 2024-05-04 10:54:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-04 10:54:15 --> Input Class Initialized
INFO - 2024-05-04 10:54:15 --> Language Class Initialized
INFO - 2024-05-04 10:54:15 --> Loader Class Initialized
INFO - 2024-05-04 10:54:15 --> Helper loaded: url_helper
INFO - 2024-05-04 10:54:15 --> Helper loaded: file_helper
INFO - 2024-05-04 10:54:15 --> Helper loaded: html_helper
INFO - 2024-05-04 10:54:15 --> Helper loaded: text_helper
INFO - 2024-05-04 10:54:15 --> Helper loaded: form_helper
INFO - 2024-05-04 10:54:15 --> Helper loaded: lang_helper
INFO - 2024-05-04 10:54:15 --> Helper loaded: security_helper
INFO - 2024-05-04 10:54:15 --> Helper loaded: cookie_helper
INFO - 2024-05-04 10:54:15 --> Database Driver Class Initialized
INFO - 2024-05-04 10:54:15 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-04 10:54:15 --> Parser Class Initialized
INFO - 2024-05-04 10:54:15 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-05-04 10:54:15 --> Pagination Class Initialized
INFO - 2024-05-04 10:54:15 --> Form Validation Class Initialized
INFO - 2024-05-04 10:54:15 --> Controller Class Initialized
DEBUG - 2024-05-04 10:54:15 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-05-04 10:54:15 --> Session class already loaded. Second attempt ignored.
INFO - 2024-05-04 10:54:15 --> Model Class Initialized
DEBUG - 2024-05-04 10:54:15 --> Lmrpayments class already loaded. Second attempt ignored.
INFO - 2024-05-04 10:54:15 --> Model Class Initialized
INFO - 2024-05-04 10:54:15 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\mr_payments/payment.php
DEBUG - 2024-05-04 10:54:15 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-05-04 10:54:15 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\include/top_menu.php
INFO - 2024-05-04 10:54:15 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\include/admin_loggedin_info.php
INFO - 2024-05-04 10:54:15 --> Model Class Initialized
INFO - 2024-05-04 10:54:15 --> Model Class Initialized
INFO - 2024-05-04 10:54:15 --> Model Class Initialized
INFO - 2024-05-04 10:54:16 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\include/admin_header.php
INFO - 2024-05-04 10:54:16 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\include/admin_footer.php
INFO - 2024-05-04 10:54:16 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\admin_html_template.php
INFO - 2024-05-04 10:54:16 --> Final output sent to browser
DEBUG - 2024-05-04 10:54:16 --> Total execution time: 1.1856
ERROR - 2024-05-04 10:54:16 --> $config['composer_autoload'] is set to TRUE but E:\xampp\htdocs\maurnaturo\application\vendor/autoload.php was not found.
INFO - 2024-05-04 10:54:16 --> Config Class Initialized
INFO - 2024-05-04 10:54:16 --> Hooks Class Initialized
DEBUG - 2024-05-04 10:54:16 --> UTF-8 Support Enabled
INFO - 2024-05-04 10:54:16 --> Utf8 Class Initialized
INFO - 2024-05-04 10:54:16 --> URI Class Initialized
INFO - 2024-05-04 10:54:16 --> Router Class Initialized
INFO - 2024-05-04 10:54:16 --> Output Class Initialized
INFO - 2024-05-04 10:54:16 --> Security Class Initialized
DEBUG - 2024-05-04 10:54:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-04 10:54:16 --> Input Class Initialized
INFO - 2024-05-04 10:54:16 --> Language Class Initialized
INFO - 2024-05-04 10:54:16 --> Loader Class Initialized
INFO - 2024-05-04 10:54:16 --> Helper loaded: url_helper
INFO - 2024-05-04 10:54:16 --> Helper loaded: file_helper
INFO - 2024-05-04 10:54:16 --> Helper loaded: html_helper
INFO - 2024-05-04 10:54:16 --> Helper loaded: text_helper
INFO - 2024-05-04 10:54:16 --> Helper loaded: form_helper
INFO - 2024-05-04 10:54:16 --> Helper loaded: lang_helper
INFO - 2024-05-04 10:54:16 --> Helper loaded: security_helper
INFO - 2024-05-04 10:54:16 --> Helper loaded: cookie_helper
INFO - 2024-05-04 10:54:16 --> Database Driver Class Initialized
INFO - 2024-05-04 10:54:16 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-04 10:54:16 --> Parser Class Initialized
INFO - 2024-05-04 10:54:16 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-05-04 10:54:16 --> Pagination Class Initialized
INFO - 2024-05-04 10:54:16 --> Form Validation Class Initialized
INFO - 2024-05-04 10:54:16 --> Controller Class Initialized
DEBUG - 2024-05-04 10:54:16 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-05-04 10:54:16 --> Session class already loaded. Second attempt ignored.
INFO - 2024-05-04 10:54:16 --> Model Class Initialized
INFO - 2024-05-04 10:54:16 --> Final output sent to browser
DEBUG - 2024-05-04 10:54:16 --> Total execution time: 0.1151
ERROR - 2024-05-04 10:54:21 --> $config['composer_autoload'] is set to TRUE but E:\xampp\htdocs\maurnaturo\application\vendor/autoload.php was not found.
INFO - 2024-05-04 10:54:21 --> Config Class Initialized
INFO - 2024-05-04 10:54:21 --> Hooks Class Initialized
DEBUG - 2024-05-04 10:54:21 --> UTF-8 Support Enabled
INFO - 2024-05-04 10:54:21 --> Utf8 Class Initialized
INFO - 2024-05-04 10:54:21 --> URI Class Initialized
INFO - 2024-05-04 10:54:21 --> Router Class Initialized
INFO - 2024-05-04 10:54:21 --> Output Class Initialized
INFO - 2024-05-04 10:54:21 --> Security Class Initialized
DEBUG - 2024-05-04 10:54:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-04 10:54:21 --> Input Class Initialized
INFO - 2024-05-04 10:54:21 --> Language Class Initialized
INFO - 2024-05-04 10:54:21 --> Loader Class Initialized
INFO - 2024-05-04 10:54:21 --> Helper loaded: url_helper
INFO - 2024-05-04 10:54:21 --> Helper loaded: file_helper
INFO - 2024-05-04 10:54:21 --> Helper loaded: html_helper
INFO - 2024-05-04 10:54:21 --> Helper loaded: text_helper
INFO - 2024-05-04 10:54:21 --> Helper loaded: form_helper
INFO - 2024-05-04 10:54:21 --> Helper loaded: lang_helper
INFO - 2024-05-04 10:54:21 --> Helper loaded: security_helper
INFO - 2024-05-04 10:54:21 --> Helper loaded: cookie_helper
INFO - 2024-05-04 10:54:21 --> Database Driver Class Initialized
INFO - 2024-05-04 10:54:21 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-04 10:54:21 --> Parser Class Initialized
INFO - 2024-05-04 10:54:21 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-05-04 10:54:21 --> Pagination Class Initialized
INFO - 2024-05-04 10:54:21 --> Form Validation Class Initialized
INFO - 2024-05-04 10:54:21 --> Controller Class Initialized
DEBUG - 2024-05-04 10:54:21 --> Auth class already loaded. Second attempt ignored.
ERROR - 2024-05-04 10:54:21 --> Unable to load the requested class: Lsalary
ERROR - 2024-05-04 10:54:23 --> $config['composer_autoload'] is set to TRUE but E:\xampp\htdocs\maurnaturo\application\vendor/autoload.php was not found.
INFO - 2024-05-04 10:54:23 --> Config Class Initialized
INFO - 2024-05-04 10:54:23 --> Hooks Class Initialized
DEBUG - 2024-05-04 10:54:23 --> UTF-8 Support Enabled
INFO - 2024-05-04 10:54:23 --> Utf8 Class Initialized
INFO - 2024-05-04 10:54:23 --> URI Class Initialized
INFO - 2024-05-04 10:54:23 --> Router Class Initialized
INFO - 2024-05-04 10:54:23 --> Output Class Initialized
INFO - 2024-05-04 10:54:23 --> Security Class Initialized
DEBUG - 2024-05-04 10:54:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-04 10:54:23 --> Input Class Initialized
INFO - 2024-05-04 10:54:23 --> Language Class Initialized
INFO - 2024-05-04 10:54:23 --> Loader Class Initialized
INFO - 2024-05-04 10:54:23 --> Helper loaded: url_helper
INFO - 2024-05-04 10:54:23 --> Helper loaded: file_helper
INFO - 2024-05-04 10:54:23 --> Helper loaded: html_helper
INFO - 2024-05-04 10:54:23 --> Helper loaded: text_helper
INFO - 2024-05-04 10:54:23 --> Helper loaded: form_helper
INFO - 2024-05-04 10:54:23 --> Helper loaded: lang_helper
INFO - 2024-05-04 10:54:23 --> Helper loaded: security_helper
INFO - 2024-05-04 10:54:23 --> Helper loaded: cookie_helper
INFO - 2024-05-04 10:54:23 --> Database Driver Class Initialized
INFO - 2024-05-04 10:54:23 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-04 10:54:23 --> Parser Class Initialized
INFO - 2024-05-04 10:54:23 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-05-04 10:54:23 --> Pagination Class Initialized
INFO - 2024-05-04 10:54:23 --> Form Validation Class Initialized
INFO - 2024-05-04 10:54:23 --> Controller Class Initialized
DEBUG - 2024-05-04 10:54:23 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-05-04 10:54:23 --> Session class already loaded. Second attempt ignored.
INFO - 2024-05-04 10:54:23 --> Model Class Initialized
DEBUG - 2024-05-04 10:54:23 --> Lmrpayments class already loaded. Second attempt ignored.
INFO - 2024-05-04 10:54:23 --> Model Class Initialized
INFO - 2024-05-04 10:54:23 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\mr_payments/payment.php
DEBUG - 2024-05-04 10:54:23 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-05-04 10:54:23 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\include/top_menu.php
INFO - 2024-05-04 10:54:23 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\include/admin_loggedin_info.php
INFO - 2024-05-04 10:54:23 --> Model Class Initialized
INFO - 2024-05-04 10:54:23 --> Model Class Initialized
INFO - 2024-05-04 10:54:23 --> Model Class Initialized
INFO - 2024-05-04 10:54:24 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\include/admin_header.php
INFO - 2024-05-04 10:54:24 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\include/admin_footer.php
INFO - 2024-05-04 10:54:24 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\admin_html_template.php
INFO - 2024-05-04 10:54:24 --> Final output sent to browser
DEBUG - 2024-05-04 10:54:24 --> Total execution time: 1.0658
ERROR - 2024-05-04 10:54:24 --> $config['composer_autoload'] is set to TRUE but E:\xampp\htdocs\maurnaturo\application\vendor/autoload.php was not found.
INFO - 2024-05-04 10:54:24 --> Config Class Initialized
INFO - 2024-05-04 10:54:24 --> Hooks Class Initialized
DEBUG - 2024-05-04 10:54:24 --> UTF-8 Support Enabled
INFO - 2024-05-04 10:54:24 --> Utf8 Class Initialized
INFO - 2024-05-04 10:54:24 --> URI Class Initialized
INFO - 2024-05-04 10:54:24 --> Router Class Initialized
INFO - 2024-05-04 10:54:24 --> Output Class Initialized
INFO - 2024-05-04 10:54:24 --> Security Class Initialized
DEBUG - 2024-05-04 10:54:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-04 10:54:24 --> Input Class Initialized
INFO - 2024-05-04 10:54:24 --> Language Class Initialized
INFO - 2024-05-04 10:54:24 --> Loader Class Initialized
INFO - 2024-05-04 10:54:24 --> Helper loaded: url_helper
INFO - 2024-05-04 10:54:24 --> Helper loaded: file_helper
INFO - 2024-05-04 10:54:24 --> Helper loaded: html_helper
INFO - 2024-05-04 10:54:24 --> Helper loaded: text_helper
INFO - 2024-05-04 10:54:24 --> Helper loaded: form_helper
INFO - 2024-05-04 10:54:24 --> Helper loaded: lang_helper
INFO - 2024-05-04 10:54:24 --> Helper loaded: security_helper
INFO - 2024-05-04 10:54:24 --> Helper loaded: cookie_helper
INFO - 2024-05-04 10:54:24 --> Database Driver Class Initialized
INFO - 2024-05-04 10:54:24 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-04 10:54:24 --> Parser Class Initialized
INFO - 2024-05-04 10:54:24 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-05-04 10:54:24 --> Pagination Class Initialized
INFO - 2024-05-04 10:54:24 --> Form Validation Class Initialized
INFO - 2024-05-04 10:54:24 --> Controller Class Initialized
DEBUG - 2024-05-04 10:54:24 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-05-04 10:54:24 --> Session class already loaded. Second attempt ignored.
INFO - 2024-05-04 10:54:24 --> Model Class Initialized
INFO - 2024-05-04 10:54:24 --> Final output sent to browser
DEBUG - 2024-05-04 10:54:24 --> Total execution time: 0.1270
ERROR - 2024-05-04 10:55:27 --> $config['composer_autoload'] is set to TRUE but E:\xampp\htdocs\maurnaturo\application\vendor/autoload.php was not found.
INFO - 2024-05-04 10:55:27 --> Config Class Initialized
INFO - 2024-05-04 10:55:27 --> Hooks Class Initialized
DEBUG - 2024-05-04 10:55:27 --> UTF-8 Support Enabled
INFO - 2024-05-04 10:55:27 --> Utf8 Class Initialized
INFO - 2024-05-04 10:55:27 --> URI Class Initialized
INFO - 2024-05-04 10:55:27 --> Router Class Initialized
INFO - 2024-05-04 10:55:27 --> Output Class Initialized
INFO - 2024-05-04 10:55:27 --> Security Class Initialized
DEBUG - 2024-05-04 10:55:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-04 10:55:27 --> Input Class Initialized
INFO - 2024-05-04 10:55:27 --> Language Class Initialized
INFO - 2024-05-04 10:55:27 --> Loader Class Initialized
INFO - 2024-05-04 10:55:27 --> Helper loaded: url_helper
INFO - 2024-05-04 10:55:27 --> Helper loaded: file_helper
INFO - 2024-05-04 10:55:27 --> Helper loaded: html_helper
INFO - 2024-05-04 10:55:27 --> Helper loaded: text_helper
INFO - 2024-05-04 10:55:27 --> Helper loaded: form_helper
INFO - 2024-05-04 10:55:27 --> Helper loaded: lang_helper
INFO - 2024-05-04 10:55:27 --> Helper loaded: security_helper
INFO - 2024-05-04 10:55:27 --> Helper loaded: cookie_helper
INFO - 2024-05-04 10:55:27 --> Database Driver Class Initialized
INFO - 2024-05-04 10:55:27 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-04 10:55:27 --> Parser Class Initialized
INFO - 2024-05-04 10:55:27 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-05-04 10:55:27 --> Pagination Class Initialized
INFO - 2024-05-04 10:55:27 --> Form Validation Class Initialized
INFO - 2024-05-04 10:55:27 --> Controller Class Initialized
DEBUG - 2024-05-04 10:55:27 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-05-04 10:55:27 --> Session class already loaded. Second attempt ignored.
INFO - 2024-05-04 10:55:27 --> Model Class Initialized
DEBUG - 2024-05-04 10:55:27 --> Lmrpayments class already loaded. Second attempt ignored.
INFO - 2024-05-04 10:55:27 --> Model Class Initialized
INFO - 2024-05-04 10:55:27 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\mr_payments/payment.php
DEBUG - 2024-05-04 10:55:27 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-05-04 10:55:27 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\include/top_menu.php
INFO - 2024-05-04 10:55:27 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\include/admin_loggedin_info.php
INFO - 2024-05-04 10:55:27 --> Model Class Initialized
INFO - 2024-05-04 10:55:27 --> Model Class Initialized
INFO - 2024-05-04 10:55:27 --> Model Class Initialized
INFO - 2024-05-04 10:55:28 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\include/admin_header.php
INFO - 2024-05-04 10:55:28 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\include/admin_footer.php
INFO - 2024-05-04 10:55:28 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\admin_html_template.php
INFO - 2024-05-04 10:55:28 --> Final output sent to browser
DEBUG - 2024-05-04 10:55:28 --> Total execution time: 1.3644
ERROR - 2024-05-04 10:55:29 --> $config['composer_autoload'] is set to TRUE but E:\xampp\htdocs\maurnaturo\application\vendor/autoload.php was not found.
INFO - 2024-05-04 10:55:29 --> Config Class Initialized
INFO - 2024-05-04 10:55:29 --> Hooks Class Initialized
DEBUG - 2024-05-04 10:55:29 --> UTF-8 Support Enabled
INFO - 2024-05-04 10:55:29 --> Utf8 Class Initialized
INFO - 2024-05-04 10:55:29 --> URI Class Initialized
INFO - 2024-05-04 10:55:29 --> Router Class Initialized
INFO - 2024-05-04 10:55:29 --> Output Class Initialized
INFO - 2024-05-04 10:55:29 --> Security Class Initialized
DEBUG - 2024-05-04 10:55:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-04 10:55:29 --> Input Class Initialized
INFO - 2024-05-04 10:55:29 --> Language Class Initialized
INFO - 2024-05-04 10:55:29 --> Loader Class Initialized
INFO - 2024-05-04 10:55:29 --> Helper loaded: url_helper
INFO - 2024-05-04 10:55:29 --> Helper loaded: file_helper
INFO - 2024-05-04 10:55:29 --> Helper loaded: html_helper
INFO - 2024-05-04 10:55:29 --> Helper loaded: text_helper
INFO - 2024-05-04 10:55:29 --> Helper loaded: form_helper
INFO - 2024-05-04 10:55:29 --> Helper loaded: lang_helper
INFO - 2024-05-04 10:55:29 --> Helper loaded: security_helper
INFO - 2024-05-04 10:55:29 --> Helper loaded: cookie_helper
INFO - 2024-05-04 10:55:29 --> Database Driver Class Initialized
INFO - 2024-05-04 10:55:29 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-04 10:55:29 --> Parser Class Initialized
INFO - 2024-05-04 10:55:29 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-05-04 10:55:29 --> Pagination Class Initialized
INFO - 2024-05-04 10:55:29 --> Form Validation Class Initialized
INFO - 2024-05-04 10:55:29 --> Controller Class Initialized
DEBUG - 2024-05-04 10:55:29 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-05-04 10:55:29 --> Session class already loaded. Second attempt ignored.
INFO - 2024-05-04 10:55:29 --> Model Class Initialized
INFO - 2024-05-04 10:55:29 --> Final output sent to browser
DEBUG - 2024-05-04 10:55:29 --> Total execution time: 0.1086
ERROR - 2024-05-04 10:55:32 --> $config['composer_autoload'] is set to TRUE but E:\xampp\htdocs\maurnaturo\application\vendor/autoload.php was not found.
INFO - 2024-05-04 10:55:32 --> Config Class Initialized
INFO - 2024-05-04 10:55:32 --> Hooks Class Initialized
DEBUG - 2024-05-04 10:55:32 --> UTF-8 Support Enabled
INFO - 2024-05-04 10:55:32 --> Utf8 Class Initialized
INFO - 2024-05-04 10:55:32 --> URI Class Initialized
INFO - 2024-05-04 10:55:32 --> Router Class Initialized
INFO - 2024-05-04 10:55:32 --> Output Class Initialized
INFO - 2024-05-04 10:55:32 --> Security Class Initialized
DEBUG - 2024-05-04 10:55:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-04 10:55:32 --> Input Class Initialized
INFO - 2024-05-04 10:55:32 --> Language Class Initialized
INFO - 2024-05-04 10:55:32 --> Loader Class Initialized
INFO - 2024-05-04 10:55:32 --> Helper loaded: url_helper
INFO - 2024-05-04 10:55:32 --> Helper loaded: file_helper
INFO - 2024-05-04 10:55:32 --> Helper loaded: html_helper
INFO - 2024-05-04 10:55:32 --> Helper loaded: text_helper
INFO - 2024-05-04 10:55:32 --> Helper loaded: form_helper
INFO - 2024-05-04 10:55:32 --> Helper loaded: lang_helper
INFO - 2024-05-04 10:55:32 --> Helper loaded: security_helper
INFO - 2024-05-04 10:55:32 --> Helper loaded: cookie_helper
INFO - 2024-05-04 10:55:32 --> Database Driver Class Initialized
INFO - 2024-05-04 10:55:32 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-04 10:55:32 --> Parser Class Initialized
INFO - 2024-05-04 10:55:32 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-05-04 10:55:32 --> Pagination Class Initialized
INFO - 2024-05-04 10:55:32 --> Form Validation Class Initialized
INFO - 2024-05-04 10:55:32 --> Controller Class Initialized
DEBUG - 2024-05-04 10:55:32 --> Auth class already loaded. Second attempt ignored.
ERROR - 2024-05-04 10:55:32 --> Unable to load the requested class: Lsalary
ERROR - 2024-05-04 10:55:34 --> $config['composer_autoload'] is set to TRUE but E:\xampp\htdocs\maurnaturo\application\vendor/autoload.php was not found.
INFO - 2024-05-04 10:55:34 --> Config Class Initialized
INFO - 2024-05-04 10:55:34 --> Hooks Class Initialized
DEBUG - 2024-05-04 10:55:34 --> UTF-8 Support Enabled
INFO - 2024-05-04 10:55:34 --> Utf8 Class Initialized
INFO - 2024-05-04 10:55:34 --> URI Class Initialized
INFO - 2024-05-04 10:55:34 --> Router Class Initialized
INFO - 2024-05-04 10:55:34 --> Output Class Initialized
INFO - 2024-05-04 10:55:34 --> Security Class Initialized
DEBUG - 2024-05-04 10:55:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-04 10:55:34 --> Input Class Initialized
INFO - 2024-05-04 10:55:34 --> Language Class Initialized
INFO - 2024-05-04 10:55:34 --> Loader Class Initialized
INFO - 2024-05-04 10:55:34 --> Helper loaded: url_helper
INFO - 2024-05-04 10:55:34 --> Helper loaded: file_helper
INFO - 2024-05-04 10:55:34 --> Helper loaded: html_helper
INFO - 2024-05-04 10:55:34 --> Helper loaded: text_helper
INFO - 2024-05-04 10:55:34 --> Helper loaded: form_helper
INFO - 2024-05-04 10:55:34 --> Helper loaded: lang_helper
INFO - 2024-05-04 10:55:34 --> Helper loaded: security_helper
INFO - 2024-05-04 10:55:34 --> Helper loaded: cookie_helper
INFO - 2024-05-04 10:55:34 --> Database Driver Class Initialized
INFO - 2024-05-04 10:55:34 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-04 10:55:34 --> Parser Class Initialized
INFO - 2024-05-04 10:55:34 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-05-04 10:55:34 --> Pagination Class Initialized
INFO - 2024-05-04 10:55:34 --> Form Validation Class Initialized
INFO - 2024-05-04 10:55:34 --> Controller Class Initialized
DEBUG - 2024-05-04 10:55:34 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-05-04 10:55:34 --> Session class already loaded. Second attempt ignored.
INFO - 2024-05-04 10:55:34 --> Model Class Initialized
DEBUG - 2024-05-04 10:55:34 --> Lmrpayments class already loaded. Second attempt ignored.
INFO - 2024-05-04 10:55:34 --> Model Class Initialized
INFO - 2024-05-04 10:55:34 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\mr_payments/payment.php
DEBUG - 2024-05-04 10:55:34 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-05-04 10:55:34 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\include/top_menu.php
INFO - 2024-05-04 10:55:34 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\include/admin_loggedin_info.php
INFO - 2024-05-04 10:55:34 --> Model Class Initialized
INFO - 2024-05-04 10:55:34 --> Model Class Initialized
INFO - 2024-05-04 10:55:34 --> Model Class Initialized
INFO - 2024-05-04 10:55:35 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\include/admin_header.php
INFO - 2024-05-04 10:55:35 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\include/admin_footer.php
INFO - 2024-05-04 10:55:35 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\admin_html_template.php
INFO - 2024-05-04 10:55:35 --> Final output sent to browser
DEBUG - 2024-05-04 10:55:35 --> Total execution time: 1.1039
ERROR - 2024-05-04 10:55:35 --> $config['composer_autoload'] is set to TRUE but E:\xampp\htdocs\maurnaturo\application\vendor/autoload.php was not found.
INFO - 2024-05-04 10:55:35 --> Config Class Initialized
INFO - 2024-05-04 10:55:35 --> Hooks Class Initialized
DEBUG - 2024-05-04 10:55:35 --> UTF-8 Support Enabled
INFO - 2024-05-04 10:55:35 --> Utf8 Class Initialized
INFO - 2024-05-04 10:55:35 --> URI Class Initialized
INFO - 2024-05-04 10:55:35 --> Router Class Initialized
INFO - 2024-05-04 10:55:35 --> Output Class Initialized
INFO - 2024-05-04 10:55:35 --> Security Class Initialized
DEBUG - 2024-05-04 10:55:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-04 10:55:35 --> Input Class Initialized
INFO - 2024-05-04 10:55:35 --> Language Class Initialized
INFO - 2024-05-04 10:55:35 --> Loader Class Initialized
INFO - 2024-05-04 10:55:35 --> Helper loaded: url_helper
INFO - 2024-05-04 10:55:35 --> Helper loaded: file_helper
INFO - 2024-05-04 10:55:35 --> Helper loaded: html_helper
INFO - 2024-05-04 10:55:35 --> Helper loaded: text_helper
INFO - 2024-05-04 10:55:35 --> Helper loaded: form_helper
INFO - 2024-05-04 10:55:35 --> Helper loaded: lang_helper
INFO - 2024-05-04 10:55:35 --> Helper loaded: security_helper
INFO - 2024-05-04 10:55:35 --> Helper loaded: cookie_helper
INFO - 2024-05-04 10:55:35 --> Database Driver Class Initialized
INFO - 2024-05-04 10:55:35 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-04 10:55:35 --> Parser Class Initialized
INFO - 2024-05-04 10:55:35 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-05-04 10:55:35 --> Pagination Class Initialized
INFO - 2024-05-04 10:55:35 --> Form Validation Class Initialized
INFO - 2024-05-04 10:55:35 --> Controller Class Initialized
DEBUG - 2024-05-04 10:55:35 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-05-04 10:55:35 --> Session class already loaded. Second attempt ignored.
INFO - 2024-05-04 10:55:35 --> Model Class Initialized
INFO - 2024-05-04 10:55:36 --> Final output sent to browser
DEBUG - 2024-05-04 10:55:36 --> Total execution time: 0.0964
ERROR - 2024-05-04 10:55:40 --> $config['composer_autoload'] is set to TRUE but E:\xampp\htdocs\maurnaturo\application\vendor/autoload.php was not found.
INFO - 2024-05-04 10:55:40 --> Config Class Initialized
INFO - 2024-05-04 10:55:40 --> Hooks Class Initialized
DEBUG - 2024-05-04 10:55:40 --> UTF-8 Support Enabled
INFO - 2024-05-04 10:55:40 --> Utf8 Class Initialized
INFO - 2024-05-04 10:55:40 --> URI Class Initialized
INFO - 2024-05-04 10:55:40 --> Router Class Initialized
INFO - 2024-05-04 10:55:40 --> Output Class Initialized
INFO - 2024-05-04 10:55:40 --> Security Class Initialized
DEBUG - 2024-05-04 10:55:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-04 10:55:40 --> Input Class Initialized
INFO - 2024-05-04 10:55:40 --> Language Class Initialized
INFO - 2024-05-04 10:55:40 --> Loader Class Initialized
INFO - 2024-05-04 10:55:40 --> Helper loaded: url_helper
INFO - 2024-05-04 10:55:40 --> Helper loaded: file_helper
INFO - 2024-05-04 10:55:40 --> Helper loaded: html_helper
INFO - 2024-05-04 10:55:40 --> Helper loaded: text_helper
INFO - 2024-05-04 10:55:40 --> Helper loaded: form_helper
INFO - 2024-05-04 10:55:40 --> Helper loaded: lang_helper
INFO - 2024-05-04 10:55:40 --> Helper loaded: security_helper
INFO - 2024-05-04 10:55:40 --> Helper loaded: cookie_helper
INFO - 2024-05-04 10:55:40 --> Database Driver Class Initialized
INFO - 2024-05-04 10:55:40 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-04 10:55:40 --> Parser Class Initialized
INFO - 2024-05-04 10:55:40 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-05-04 10:55:40 --> Pagination Class Initialized
INFO - 2024-05-04 10:55:40 --> Form Validation Class Initialized
INFO - 2024-05-04 10:55:40 --> Controller Class Initialized
DEBUG - 2024-05-04 10:55:40 --> Auth class already loaded. Second attempt ignored.
ERROR - 2024-05-04 10:55:40 --> Unable to load the requested class: Lsalary
ERROR - 2024-05-04 11:03:33 --> $config['composer_autoload'] is set to TRUE but E:\xampp\htdocs\maurnaturo\application\vendor/autoload.php was not found.
INFO - 2024-05-04 11:03:33 --> Config Class Initialized
INFO - 2024-05-04 11:03:33 --> Hooks Class Initialized
DEBUG - 2024-05-04 11:03:33 --> UTF-8 Support Enabled
INFO - 2024-05-04 11:03:33 --> Utf8 Class Initialized
INFO - 2024-05-04 11:03:33 --> URI Class Initialized
INFO - 2024-05-04 11:03:33 --> Router Class Initialized
INFO - 2024-05-04 11:03:33 --> Output Class Initialized
INFO - 2024-05-04 11:03:33 --> Security Class Initialized
DEBUG - 2024-05-04 11:03:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-04 11:03:33 --> Input Class Initialized
INFO - 2024-05-04 11:03:33 --> Language Class Initialized
INFO - 2024-05-04 11:03:33 --> Loader Class Initialized
INFO - 2024-05-04 11:03:33 --> Helper loaded: url_helper
INFO - 2024-05-04 11:03:33 --> Helper loaded: file_helper
INFO - 2024-05-04 11:03:33 --> Helper loaded: html_helper
INFO - 2024-05-04 11:03:33 --> Helper loaded: text_helper
INFO - 2024-05-04 11:03:33 --> Helper loaded: form_helper
INFO - 2024-05-04 11:03:33 --> Helper loaded: lang_helper
INFO - 2024-05-04 11:03:33 --> Helper loaded: security_helper
INFO - 2024-05-04 11:03:33 --> Helper loaded: cookie_helper
INFO - 2024-05-04 11:03:33 --> Database Driver Class Initialized
INFO - 2024-05-04 11:03:33 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-04 11:03:33 --> Parser Class Initialized
INFO - 2024-05-04 11:03:33 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-05-04 11:03:33 --> Pagination Class Initialized
INFO - 2024-05-04 11:03:33 --> Form Validation Class Initialized
INFO - 2024-05-04 11:03:33 --> Controller Class Initialized
DEBUG - 2024-05-04 11:03:33 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-05-04 11:03:33 --> Session class already loaded. Second attempt ignored.
INFO - 2024-05-04 11:03:33 --> Model Class Initialized
INFO - 2024-05-04 11:03:33 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\salary/add_salary_form.php
DEBUG - 2024-05-04 11:03:33 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-05-04 11:03:33 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\include/top_menu.php
INFO - 2024-05-04 11:03:33 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\include/admin_loggedin_info.php
INFO - 2024-05-04 11:03:33 --> Model Class Initialized
INFO - 2024-05-04 11:03:33 --> Model Class Initialized
INFO - 2024-05-04 11:03:33 --> Model Class Initialized
INFO - 2024-05-04 11:03:33 --> Model Class Initialized
INFO - 2024-05-04 11:03:34 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\include/admin_header.php
INFO - 2024-05-04 11:03:34 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\include/admin_footer.php
INFO - 2024-05-04 11:03:34 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\admin_html_template.php
INFO - 2024-05-04 11:03:34 --> Final output sent to browser
DEBUG - 2024-05-04 11:03:34 --> Total execution time: 1.2043
ERROR - 2024-05-04 14:04:46 --> $config['composer_autoload'] is set to TRUE but E:\xampp\htdocs\maurnaturo\application\vendor/autoload.php was not found.
INFO - 2024-05-04 14:04:46 --> Config Class Initialized
INFO - 2024-05-04 14:04:46 --> Hooks Class Initialized
DEBUG - 2024-05-04 14:04:46 --> UTF-8 Support Enabled
INFO - 2024-05-04 14:04:46 --> Utf8 Class Initialized
INFO - 2024-05-04 14:04:46 --> URI Class Initialized
INFO - 2024-05-04 14:04:46 --> Router Class Initialized
INFO - 2024-05-04 14:04:46 --> Output Class Initialized
INFO - 2024-05-04 14:04:46 --> Security Class Initialized
DEBUG - 2024-05-04 14:04:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-04 14:04:46 --> Input Class Initialized
INFO - 2024-05-04 14:04:46 --> Language Class Initialized
INFO - 2024-05-04 14:04:46 --> Loader Class Initialized
INFO - 2024-05-04 14:04:46 --> Helper loaded: url_helper
INFO - 2024-05-04 14:04:46 --> Helper loaded: file_helper
INFO - 2024-05-04 14:04:46 --> Helper loaded: html_helper
INFO - 2024-05-04 14:04:46 --> Helper loaded: text_helper
INFO - 2024-05-04 14:04:46 --> Helper loaded: form_helper
INFO - 2024-05-04 14:04:46 --> Helper loaded: lang_helper
INFO - 2024-05-04 14:04:46 --> Helper loaded: security_helper
INFO - 2024-05-04 14:04:46 --> Helper loaded: cookie_helper
INFO - 2024-05-04 14:04:46 --> Database Driver Class Initialized
INFO - 2024-05-04 14:04:46 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-04 14:04:46 --> Parser Class Initialized
INFO - 2024-05-04 14:04:46 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-05-04 14:04:46 --> Pagination Class Initialized
INFO - 2024-05-04 14:04:46 --> Form Validation Class Initialized
INFO - 2024-05-04 14:04:46 --> Controller Class Initialized
DEBUG - 2024-05-04 14:04:46 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-05-04 14:04:46 --> Session class already loaded. Second attempt ignored.
INFO - 2024-05-04 14:04:46 --> Model Class Initialized
ERROR - 2024-05-04 14:04:46 --> $config['composer_autoload'] is set to TRUE but E:\xampp\htdocs\maurnaturo\application\vendor/autoload.php was not found.
INFO - 2024-05-04 14:04:46 --> Config Class Initialized
INFO - 2024-05-04 14:04:46 --> Hooks Class Initialized
DEBUG - 2024-05-04 14:04:46 --> UTF-8 Support Enabled
INFO - 2024-05-04 14:04:46 --> Utf8 Class Initialized
INFO - 2024-05-04 14:04:46 --> URI Class Initialized
INFO - 2024-05-04 14:04:46 --> Router Class Initialized
INFO - 2024-05-04 14:04:46 --> Output Class Initialized
INFO - 2024-05-04 14:04:46 --> Security Class Initialized
DEBUG - 2024-05-04 14:04:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-04 14:04:46 --> Input Class Initialized
INFO - 2024-05-04 14:04:46 --> Language Class Initialized
INFO - 2024-05-04 14:04:46 --> Loader Class Initialized
INFO - 2024-05-04 14:04:46 --> Helper loaded: url_helper
INFO - 2024-05-04 14:04:46 --> Helper loaded: file_helper
INFO - 2024-05-04 14:04:46 --> Helper loaded: html_helper
INFO - 2024-05-04 14:04:46 --> Helper loaded: text_helper
INFO - 2024-05-04 14:04:46 --> Helper loaded: form_helper
INFO - 2024-05-04 14:04:46 --> Helper loaded: lang_helper
INFO - 2024-05-04 14:04:46 --> Helper loaded: security_helper
INFO - 2024-05-04 14:04:46 --> Helper loaded: cookie_helper
INFO - 2024-05-04 14:04:46 --> Database Driver Class Initialized
INFO - 2024-05-04 14:04:46 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-04 14:04:46 --> Parser Class Initialized
INFO - 2024-05-04 14:04:46 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-05-04 14:04:46 --> Pagination Class Initialized
INFO - 2024-05-04 14:04:46 --> Form Validation Class Initialized
INFO - 2024-05-04 14:04:46 --> Controller Class Initialized
INFO - 2024-05-04 14:04:46 --> Model Class Initialized
DEBUG - 2024-05-04 14:04:46 --> Session class already loaded. Second attempt ignored.
INFO - 2024-05-04 14:04:46 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\user/admin_login_form.php
DEBUG - 2024-05-04 14:04:46 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-05-04 14:04:46 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\include/top_menu.php
INFO - 2024-05-04 14:04:46 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\include/admin_loggedin_info.php
INFO - 2024-05-04 14:04:46 --> Model Class Initialized
INFO - 2024-05-04 14:04:46 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\admin_html_template.php
INFO - 2024-05-04 14:04:46 --> Final output sent to browser
DEBUG - 2024-05-04 14:04:46 --> Total execution time: 0.1536
ERROR - 2024-05-04 14:04:52 --> $config['composer_autoload'] is set to TRUE but E:\xampp\htdocs\maurnaturo\application\vendor/autoload.php was not found.
INFO - 2024-05-04 14:04:52 --> Config Class Initialized
INFO - 2024-05-04 14:04:52 --> Hooks Class Initialized
DEBUG - 2024-05-04 14:04:52 --> UTF-8 Support Enabled
INFO - 2024-05-04 14:04:52 --> Utf8 Class Initialized
INFO - 2024-05-04 14:04:52 --> URI Class Initialized
INFO - 2024-05-04 14:04:52 --> Router Class Initialized
INFO - 2024-05-04 14:04:52 --> Output Class Initialized
INFO - 2024-05-04 14:04:52 --> Security Class Initialized
DEBUG - 2024-05-04 14:04:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-04 14:04:52 --> Input Class Initialized
INFO - 2024-05-04 14:04:52 --> Language Class Initialized
INFO - 2024-05-04 14:04:52 --> Loader Class Initialized
INFO - 2024-05-04 14:04:52 --> Helper loaded: url_helper
INFO - 2024-05-04 14:04:52 --> Helper loaded: file_helper
INFO - 2024-05-04 14:04:52 --> Helper loaded: html_helper
INFO - 2024-05-04 14:04:52 --> Helper loaded: text_helper
INFO - 2024-05-04 14:04:52 --> Helper loaded: form_helper
INFO - 2024-05-04 14:04:52 --> Helper loaded: lang_helper
INFO - 2024-05-04 14:04:52 --> Helper loaded: security_helper
INFO - 2024-05-04 14:04:52 --> Helper loaded: cookie_helper
INFO - 2024-05-04 14:04:52 --> Database Driver Class Initialized
INFO - 2024-05-04 14:04:52 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-04 14:04:52 --> Parser Class Initialized
INFO - 2024-05-04 14:04:52 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-05-04 14:04:52 --> Pagination Class Initialized
INFO - 2024-05-04 14:04:52 --> Form Validation Class Initialized
INFO - 2024-05-04 14:04:52 --> Controller Class Initialized
INFO - 2024-05-04 14:04:52 --> Model Class Initialized
DEBUG - 2024-05-04 14:04:52 --> Session class already loaded. Second attempt ignored.
INFO - 2024-05-04 14:04:52 --> Model Class Initialized
INFO - 2024-05-04 14:04:52 --> Final output sent to browser
DEBUG - 2024-05-04 14:04:52 --> Total execution time: 0.2744
ERROR - 2024-05-04 14:04:52 --> $config['composer_autoload'] is set to TRUE but E:\xampp\htdocs\maurnaturo\application\vendor/autoload.php was not found.
INFO - 2024-05-04 14:04:52 --> Config Class Initialized
INFO - 2024-05-04 14:04:52 --> Hooks Class Initialized
DEBUG - 2024-05-04 14:04:52 --> UTF-8 Support Enabled
INFO - 2024-05-04 14:04:52 --> Utf8 Class Initialized
INFO - 2024-05-04 14:04:52 --> URI Class Initialized
INFO - 2024-05-04 14:04:52 --> Router Class Initialized
INFO - 2024-05-04 14:04:52 --> Output Class Initialized
INFO - 2024-05-04 14:04:52 --> Security Class Initialized
DEBUG - 2024-05-04 14:04:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-04 14:04:52 --> Input Class Initialized
INFO - 2024-05-04 14:04:52 --> Language Class Initialized
INFO - 2024-05-04 14:04:52 --> Loader Class Initialized
INFO - 2024-05-04 14:04:52 --> Helper loaded: url_helper
INFO - 2024-05-04 14:04:52 --> Helper loaded: file_helper
INFO - 2024-05-04 14:04:52 --> Helper loaded: html_helper
INFO - 2024-05-04 14:04:52 --> Helper loaded: text_helper
INFO - 2024-05-04 14:04:52 --> Helper loaded: form_helper
INFO - 2024-05-04 14:04:52 --> Helper loaded: lang_helper
INFO - 2024-05-04 14:04:52 --> Helper loaded: security_helper
INFO - 2024-05-04 14:04:52 --> Helper loaded: cookie_helper
INFO - 2024-05-04 14:04:52 --> Database Driver Class Initialized
INFO - 2024-05-04 14:04:52 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-04 14:04:52 --> Parser Class Initialized
INFO - 2024-05-04 14:04:52 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-05-04 14:04:52 --> Pagination Class Initialized
INFO - 2024-05-04 14:04:52 --> Form Validation Class Initialized
INFO - 2024-05-04 14:04:52 --> Controller Class Initialized
INFO - 2024-05-04 14:04:52 --> Model Class Initialized
DEBUG - 2024-05-04 14:04:52 --> Session class already loaded. Second attempt ignored.
INFO - 2024-05-04 14:04:52 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\user/admin_login_form.php
DEBUG - 2024-05-04 14:04:52 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-05-04 14:04:52 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\include/top_menu.php
INFO - 2024-05-04 14:04:52 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\include/admin_loggedin_info.php
INFO - 2024-05-04 14:04:52 --> Model Class Initialized
INFO - 2024-05-04 14:04:52 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\admin_html_template.php
INFO - 2024-05-04 14:04:52 --> Final output sent to browser
DEBUG - 2024-05-04 14:04:52 --> Total execution time: 0.2078
ERROR - 2024-05-04 14:04:57 --> $config['composer_autoload'] is set to TRUE but E:\xampp\htdocs\maurnaturo\application\vendor/autoload.php was not found.
INFO - 2024-05-04 14:04:57 --> Config Class Initialized
INFO - 2024-05-04 14:04:57 --> Hooks Class Initialized
DEBUG - 2024-05-04 14:04:57 --> UTF-8 Support Enabled
INFO - 2024-05-04 14:04:57 --> Utf8 Class Initialized
INFO - 2024-05-04 14:04:57 --> URI Class Initialized
INFO - 2024-05-04 14:04:57 --> Router Class Initialized
INFO - 2024-05-04 14:04:57 --> Output Class Initialized
INFO - 2024-05-04 14:04:57 --> Security Class Initialized
DEBUG - 2024-05-04 14:04:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-04 14:04:57 --> Input Class Initialized
INFO - 2024-05-04 14:04:57 --> Language Class Initialized
INFO - 2024-05-04 14:04:57 --> Loader Class Initialized
INFO - 2024-05-04 14:04:57 --> Helper loaded: url_helper
INFO - 2024-05-04 14:04:57 --> Helper loaded: file_helper
INFO - 2024-05-04 14:04:57 --> Helper loaded: html_helper
INFO - 2024-05-04 14:04:57 --> Helper loaded: text_helper
INFO - 2024-05-04 14:04:57 --> Helper loaded: form_helper
INFO - 2024-05-04 14:04:57 --> Helper loaded: lang_helper
INFO - 2024-05-04 14:04:57 --> Helper loaded: security_helper
INFO - 2024-05-04 14:04:57 --> Helper loaded: cookie_helper
INFO - 2024-05-04 14:04:57 --> Database Driver Class Initialized
INFO - 2024-05-04 14:04:58 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-04 14:04:58 --> Parser Class Initialized
INFO - 2024-05-04 14:04:58 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-05-04 14:04:58 --> Pagination Class Initialized
INFO - 2024-05-04 14:04:58 --> Form Validation Class Initialized
INFO - 2024-05-04 14:04:58 --> Controller Class Initialized
INFO - 2024-05-04 14:04:58 --> Model Class Initialized
DEBUG - 2024-05-04 14:04:58 --> Session class already loaded. Second attempt ignored.
INFO - 2024-05-04 14:04:58 --> Model Class Initialized
INFO - 2024-05-04 14:04:58 --> Final output sent to browser
DEBUG - 2024-05-04 14:04:58 --> Total execution time: 0.1679
ERROR - 2024-05-04 14:04:58 --> $config['composer_autoload'] is set to TRUE but E:\xampp\htdocs\maurnaturo\application\vendor/autoload.php was not found.
INFO - 2024-05-04 14:04:58 --> Config Class Initialized
INFO - 2024-05-04 14:04:58 --> Hooks Class Initialized
DEBUG - 2024-05-04 14:04:58 --> UTF-8 Support Enabled
INFO - 2024-05-04 14:04:58 --> Utf8 Class Initialized
INFO - 2024-05-04 14:04:58 --> URI Class Initialized
DEBUG - 2024-05-04 14:04:58 --> No URI present. Default controller set.
INFO - 2024-05-04 14:04:58 --> Router Class Initialized
INFO - 2024-05-04 14:04:58 --> Output Class Initialized
INFO - 2024-05-04 14:04:58 --> Security Class Initialized
DEBUG - 2024-05-04 14:04:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-04 14:04:58 --> Input Class Initialized
INFO - 2024-05-04 14:04:58 --> Language Class Initialized
INFO - 2024-05-04 14:04:58 --> Loader Class Initialized
INFO - 2024-05-04 14:04:58 --> Helper loaded: url_helper
INFO - 2024-05-04 14:04:58 --> Helper loaded: file_helper
INFO - 2024-05-04 14:04:58 --> Helper loaded: html_helper
INFO - 2024-05-04 14:04:58 --> Helper loaded: text_helper
INFO - 2024-05-04 14:04:58 --> Helper loaded: form_helper
INFO - 2024-05-04 14:04:58 --> Helper loaded: lang_helper
INFO - 2024-05-04 14:04:58 --> Helper loaded: security_helper
INFO - 2024-05-04 14:04:58 --> Helper loaded: cookie_helper
INFO - 2024-05-04 14:04:58 --> Database Driver Class Initialized
INFO - 2024-05-04 14:04:58 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-04 14:04:58 --> Parser Class Initialized
INFO - 2024-05-04 14:04:58 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-05-04 14:04:58 --> Pagination Class Initialized
INFO - 2024-05-04 14:04:58 --> Form Validation Class Initialized
INFO - 2024-05-04 14:04:58 --> Controller Class Initialized
INFO - 2024-05-04 14:04:58 --> Model Class Initialized
DEBUG - 2024-05-04 14:04:58 --> Session class already loaded. Second attempt ignored.
INFO - 2024-05-04 14:04:58 --> Model Class Initialized
DEBUG - 2024-05-04 14:04:58 --> Session class already loaded. Second attempt ignored.
INFO - 2024-05-04 14:04:58 --> Model Class Initialized
INFO - 2024-05-04 14:04:58 --> Model Class Initialized
INFO - 2024-05-04 14:04:58 --> Model Class Initialized
INFO - 2024-05-04 14:04:58 --> Model Class Initialized
DEBUG - 2024-05-04 14:04:58 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-05-04 14:04:58 --> Session class already loaded. Second attempt ignored.
INFO - 2024-05-04 14:04:58 --> Model Class Initialized
INFO - 2024-05-04 14:04:58 --> Model Class Initialized
INFO - 2024-05-04 14:04:59 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\include/admin_home.php
DEBUG - 2024-05-04 14:04:59 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-05-04 14:04:59 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\include/top_menu.php
INFO - 2024-05-04 14:05:00 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\include/admin_loggedin_info.php
INFO - 2024-05-04 14:05:00 --> Model Class Initialized
INFO - 2024-05-04 14:05:01 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\include/admin_header.php
INFO - 2024-05-04 14:05:01 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\include/admin_footer.php
INFO - 2024-05-04 14:05:01 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\admin_html_template.php
INFO - 2024-05-04 14:05:01 --> Final output sent to browser
DEBUG - 2024-05-04 14:05:01 --> Total execution time: 2.8883
ERROR - 2024-05-04 14:05:01 --> $config['composer_autoload'] is set to TRUE but E:\xampp\htdocs\maurnaturo\application\vendor/autoload.php was not found.
INFO - 2024-05-04 14:05:01 --> Config Class Initialized
INFO - 2024-05-04 14:05:01 --> Hooks Class Initialized
DEBUG - 2024-05-04 14:05:01 --> UTF-8 Support Enabled
INFO - 2024-05-04 14:05:01 --> Utf8 Class Initialized
INFO - 2024-05-04 14:05:01 --> URI Class Initialized
INFO - 2024-05-04 14:05:01 --> Router Class Initialized
INFO - 2024-05-04 14:05:01 --> Output Class Initialized
INFO - 2024-05-04 14:05:01 --> Security Class Initialized
DEBUG - 2024-05-04 14:05:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-04 14:05:01 --> Input Class Initialized
INFO - 2024-05-04 14:05:01 --> Language Class Initialized
INFO - 2024-05-04 14:05:01 --> Loader Class Initialized
INFO - 2024-05-04 14:05:01 --> Helper loaded: url_helper
INFO - 2024-05-04 14:05:01 --> Helper loaded: file_helper
INFO - 2024-05-04 14:05:01 --> Helper loaded: html_helper
INFO - 2024-05-04 14:05:01 --> Helper loaded: text_helper
INFO - 2024-05-04 14:05:01 --> Helper loaded: form_helper
INFO - 2024-05-04 14:05:01 --> Helper loaded: lang_helper
INFO - 2024-05-04 14:05:01 --> Helper loaded: security_helper
INFO - 2024-05-04 14:05:01 --> Helper loaded: cookie_helper
INFO - 2024-05-04 14:05:01 --> Database Driver Class Initialized
INFO - 2024-05-04 14:05:01 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-04 14:05:01 --> Parser Class Initialized
INFO - 2024-05-04 14:05:01 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-05-04 14:05:01 --> Pagination Class Initialized
INFO - 2024-05-04 14:05:01 --> Form Validation Class Initialized
INFO - 2024-05-04 14:05:01 --> Controller Class Initialized
DEBUG - 2024-05-04 14:05:01 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-05-04 14:05:01 --> Session class already loaded. Second attempt ignored.
INFO - 2024-05-04 14:05:01 --> Model Class Initialized
INFO - 2024-05-04 14:05:01 --> Final output sent to browser
DEBUG - 2024-05-04 14:05:01 --> Total execution time: 0.2089
ERROR - 2024-05-04 14:05:14 --> $config['composer_autoload'] is set to TRUE but E:\xampp\htdocs\maurnaturo\application\vendor/autoload.php was not found.
INFO - 2024-05-04 14:05:14 --> Config Class Initialized
INFO - 2024-05-04 14:05:14 --> Hooks Class Initialized
DEBUG - 2024-05-04 14:05:14 --> UTF-8 Support Enabled
INFO - 2024-05-04 14:05:14 --> Utf8 Class Initialized
INFO - 2024-05-04 14:05:14 --> URI Class Initialized
INFO - 2024-05-04 14:05:14 --> Router Class Initialized
INFO - 2024-05-04 14:05:14 --> Output Class Initialized
INFO - 2024-05-04 14:05:14 --> Security Class Initialized
DEBUG - 2024-05-04 14:05:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-04 14:05:14 --> Input Class Initialized
INFO - 2024-05-04 14:05:14 --> Language Class Initialized
INFO - 2024-05-04 14:05:14 --> Loader Class Initialized
INFO - 2024-05-04 14:05:14 --> Helper loaded: url_helper
INFO - 2024-05-04 14:05:14 --> Helper loaded: file_helper
INFO - 2024-05-04 14:05:14 --> Helper loaded: html_helper
INFO - 2024-05-04 14:05:14 --> Helper loaded: text_helper
INFO - 2024-05-04 14:05:14 --> Helper loaded: form_helper
INFO - 2024-05-04 14:05:14 --> Helper loaded: lang_helper
INFO - 2024-05-04 14:05:14 --> Helper loaded: security_helper
INFO - 2024-05-04 14:05:14 --> Helper loaded: cookie_helper
INFO - 2024-05-04 14:05:14 --> Database Driver Class Initialized
INFO - 2024-05-04 14:05:14 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-04 14:05:14 --> Parser Class Initialized
INFO - 2024-05-04 14:05:14 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-05-04 14:05:14 --> Pagination Class Initialized
INFO - 2024-05-04 14:05:14 --> Form Validation Class Initialized
INFO - 2024-05-04 14:05:14 --> Controller Class Initialized
DEBUG - 2024-05-04 14:05:14 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-05-04 14:05:14 --> Session class already loaded. Second attempt ignored.
INFO - 2024-05-04 14:05:14 --> Model Class Initialized
INFO - 2024-05-04 14:05:14 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\salary/add_salary_form.php
DEBUG - 2024-05-04 14:05:14 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-05-04 14:05:14 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\include/top_menu.php
INFO - 2024-05-04 14:05:14 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\include/admin_loggedin_info.php
INFO - 2024-05-04 14:05:14 --> Model Class Initialized
INFO - 2024-05-04 14:05:14 --> Model Class Initialized
INFO - 2024-05-04 14:05:14 --> Model Class Initialized
INFO - 2024-05-04 14:05:14 --> Model Class Initialized
INFO - 2024-05-04 14:05:15 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\include/admin_header.php
INFO - 2024-05-04 14:05:15 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\include/admin_footer.php
INFO - 2024-05-04 14:05:15 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\admin_html_template.php
INFO - 2024-05-04 14:05:15 --> Final output sent to browser
DEBUG - 2024-05-04 14:05:15 --> Total execution time: 1.3306
ERROR - 2024-05-04 14:10:14 --> $config['composer_autoload'] is set to TRUE but E:\xampp\htdocs\maurnaturo\application\vendor/autoload.php was not found.
INFO - 2024-05-04 14:10:14 --> Config Class Initialized
INFO - 2024-05-04 14:10:14 --> Hooks Class Initialized
DEBUG - 2024-05-04 14:10:14 --> UTF-8 Support Enabled
INFO - 2024-05-04 14:10:14 --> Utf8 Class Initialized
INFO - 2024-05-04 14:10:14 --> URI Class Initialized
INFO - 2024-05-04 14:10:14 --> Router Class Initialized
INFO - 2024-05-04 14:10:14 --> Output Class Initialized
INFO - 2024-05-04 14:10:14 --> Security Class Initialized
DEBUG - 2024-05-04 14:10:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-04 14:10:14 --> Input Class Initialized
INFO - 2024-05-04 14:10:14 --> Language Class Initialized
INFO - 2024-05-04 14:10:14 --> Loader Class Initialized
INFO - 2024-05-04 14:10:14 --> Helper loaded: url_helper
INFO - 2024-05-04 14:10:14 --> Helper loaded: file_helper
INFO - 2024-05-04 14:10:14 --> Helper loaded: html_helper
INFO - 2024-05-04 14:10:14 --> Helper loaded: text_helper
INFO - 2024-05-04 14:10:14 --> Helper loaded: form_helper
INFO - 2024-05-04 14:10:14 --> Helper loaded: lang_helper
INFO - 2024-05-04 14:10:14 --> Helper loaded: security_helper
INFO - 2024-05-04 14:10:14 --> Helper loaded: cookie_helper
INFO - 2024-05-04 14:10:14 --> Database Driver Class Initialized
INFO - 2024-05-04 14:10:14 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-04 14:10:14 --> Parser Class Initialized
INFO - 2024-05-04 14:10:14 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-05-04 14:10:14 --> Pagination Class Initialized
INFO - 2024-05-04 14:10:14 --> Form Validation Class Initialized
INFO - 2024-05-04 14:10:14 --> Controller Class Initialized
DEBUG - 2024-05-04 14:10:14 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-05-04 14:10:14 --> Session class already loaded. Second attempt ignored.
INFO - 2024-05-04 14:10:14 --> Model Class Initialized
INFO - 2024-05-04 14:10:14 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\salary/add_salary_form.php
DEBUG - 2024-05-04 14:10:14 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-05-04 14:10:14 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\include/top_menu.php
INFO - 2024-05-04 14:10:14 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\include/admin_loggedin_info.php
INFO - 2024-05-04 14:10:14 --> Model Class Initialized
INFO - 2024-05-04 14:10:14 --> Model Class Initialized
INFO - 2024-05-04 14:10:14 --> Model Class Initialized
INFO - 2024-05-04 14:10:14 --> Model Class Initialized
INFO - 2024-05-04 14:10:15 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\include/admin_header.php
INFO - 2024-05-04 14:10:15 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\include/admin_footer.php
INFO - 2024-05-04 14:10:15 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\admin_html_template.php
INFO - 2024-05-04 14:10:15 --> Final output sent to browser
DEBUG - 2024-05-04 14:10:15 --> Total execution time: 1.2818
ERROR - 2024-05-04 14:10:43 --> $config['composer_autoload'] is set to TRUE but E:\xampp\htdocs\maurnaturo\application\vendor/autoload.php was not found.
INFO - 2024-05-04 14:10:43 --> Config Class Initialized
INFO - 2024-05-04 14:10:43 --> Hooks Class Initialized
DEBUG - 2024-05-04 14:10:43 --> UTF-8 Support Enabled
INFO - 2024-05-04 14:10:43 --> Utf8 Class Initialized
INFO - 2024-05-04 14:10:43 --> URI Class Initialized
INFO - 2024-05-04 14:10:43 --> Router Class Initialized
INFO - 2024-05-04 14:10:43 --> Output Class Initialized
INFO - 2024-05-04 14:10:43 --> Security Class Initialized
DEBUG - 2024-05-04 14:10:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-04 14:10:43 --> Input Class Initialized
INFO - 2024-05-04 14:10:43 --> Language Class Initialized
INFO - 2024-05-04 14:10:43 --> Loader Class Initialized
INFO - 2024-05-04 14:10:43 --> Helper loaded: url_helper
INFO - 2024-05-04 14:10:43 --> Helper loaded: file_helper
INFO - 2024-05-04 14:10:43 --> Helper loaded: html_helper
INFO - 2024-05-04 14:10:43 --> Helper loaded: text_helper
INFO - 2024-05-04 14:10:43 --> Helper loaded: form_helper
INFO - 2024-05-04 14:10:43 --> Helper loaded: lang_helper
INFO - 2024-05-04 14:10:43 --> Helper loaded: security_helper
INFO - 2024-05-04 14:10:43 --> Helper loaded: cookie_helper
INFO - 2024-05-04 14:10:43 --> Database Driver Class Initialized
INFO - 2024-05-04 14:10:43 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-04 14:10:43 --> Parser Class Initialized
INFO - 2024-05-04 14:10:43 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-05-04 14:10:43 --> Pagination Class Initialized
INFO - 2024-05-04 14:10:43 --> Form Validation Class Initialized
INFO - 2024-05-04 14:10:43 --> Controller Class Initialized
DEBUG - 2024-05-04 14:10:43 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-05-04 14:10:43 --> Session class already loaded. Second attempt ignored.
INFO - 2024-05-04 14:10:43 --> Model Class Initialized
INFO - 2024-05-04 14:10:43 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\salary/add_salary_form.php
DEBUG - 2024-05-04 14:10:43 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-05-04 14:10:43 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\include/top_menu.php
INFO - 2024-05-04 14:10:43 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\include/admin_loggedin_info.php
INFO - 2024-05-04 14:10:43 --> Model Class Initialized
INFO - 2024-05-04 14:10:43 --> Model Class Initialized
INFO - 2024-05-04 14:10:43 --> Model Class Initialized
INFO - 2024-05-04 14:10:43 --> Model Class Initialized
INFO - 2024-05-04 14:10:44 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\include/admin_header.php
INFO - 2024-05-04 14:10:44 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\include/admin_footer.php
INFO - 2024-05-04 14:10:44 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\admin_html_template.php
INFO - 2024-05-04 14:10:44 --> Final output sent to browser
DEBUG - 2024-05-04 14:10:44 --> Total execution time: 1.0875
ERROR - 2024-05-04 14:11:41 --> $config['composer_autoload'] is set to TRUE but E:\xampp\htdocs\maurnaturo\application\vendor/autoload.php was not found.
INFO - 2024-05-04 14:11:41 --> Config Class Initialized
INFO - 2024-05-04 14:11:41 --> Hooks Class Initialized
DEBUG - 2024-05-04 14:11:41 --> UTF-8 Support Enabled
INFO - 2024-05-04 14:11:41 --> Utf8 Class Initialized
INFO - 2024-05-04 14:11:41 --> URI Class Initialized
INFO - 2024-05-04 14:11:41 --> Router Class Initialized
INFO - 2024-05-04 14:11:41 --> Output Class Initialized
INFO - 2024-05-04 14:11:41 --> Security Class Initialized
DEBUG - 2024-05-04 14:11:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-04 14:11:41 --> Input Class Initialized
INFO - 2024-05-04 14:11:41 --> Language Class Initialized
INFO - 2024-05-04 14:11:41 --> Loader Class Initialized
INFO - 2024-05-04 14:11:41 --> Helper loaded: url_helper
INFO - 2024-05-04 14:11:41 --> Helper loaded: file_helper
INFO - 2024-05-04 14:11:41 --> Helper loaded: html_helper
INFO - 2024-05-04 14:11:41 --> Helper loaded: text_helper
INFO - 2024-05-04 14:11:41 --> Helper loaded: form_helper
INFO - 2024-05-04 14:11:41 --> Helper loaded: lang_helper
INFO - 2024-05-04 14:11:41 --> Helper loaded: security_helper
INFO - 2024-05-04 14:11:41 --> Helper loaded: cookie_helper
INFO - 2024-05-04 14:11:41 --> Database Driver Class Initialized
INFO - 2024-05-04 14:11:41 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-04 14:11:41 --> Parser Class Initialized
INFO - 2024-05-04 14:11:41 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-05-04 14:11:41 --> Pagination Class Initialized
INFO - 2024-05-04 14:11:41 --> Form Validation Class Initialized
INFO - 2024-05-04 14:11:41 --> Controller Class Initialized
DEBUG - 2024-05-04 14:11:41 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-05-04 14:11:41 --> Session class already loaded. Second attempt ignored.
INFO - 2024-05-04 14:11:41 --> Model Class Initialized
INFO - 2024-05-04 14:11:42 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\salary/add_salary_form.php
DEBUG - 2024-05-04 14:11:42 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-05-04 14:11:42 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\include/top_menu.php
INFO - 2024-05-04 14:11:42 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\include/admin_loggedin_info.php
INFO - 2024-05-04 14:11:42 --> Model Class Initialized
INFO - 2024-05-04 14:11:42 --> Model Class Initialized
INFO - 2024-05-04 14:11:42 --> Model Class Initialized
INFO - 2024-05-04 14:11:42 --> Model Class Initialized
INFO - 2024-05-04 14:11:43 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\include/admin_header.php
INFO - 2024-05-04 14:11:43 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\include/admin_footer.php
INFO - 2024-05-04 14:11:43 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\admin_html_template.php
INFO - 2024-05-04 14:11:43 --> Final output sent to browser
DEBUG - 2024-05-04 14:11:43 --> Total execution time: 1.1630
ERROR - 2024-05-04 14:11:48 --> $config['composer_autoload'] is set to TRUE but E:\xampp\htdocs\maurnaturo\application\vendor/autoload.php was not found.
INFO - 2024-05-04 14:11:48 --> Config Class Initialized
INFO - 2024-05-04 14:11:48 --> Hooks Class Initialized
DEBUG - 2024-05-04 14:11:48 --> UTF-8 Support Enabled
INFO - 2024-05-04 14:11:48 --> Utf8 Class Initialized
INFO - 2024-05-04 14:11:48 --> URI Class Initialized
INFO - 2024-05-04 14:11:48 --> Router Class Initialized
INFO - 2024-05-04 14:11:48 --> Output Class Initialized
INFO - 2024-05-04 14:11:48 --> Security Class Initialized
DEBUG - 2024-05-04 14:11:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-04 14:11:48 --> Input Class Initialized
INFO - 2024-05-04 14:11:48 --> Language Class Initialized
INFO - 2024-05-04 14:11:48 --> Loader Class Initialized
INFO - 2024-05-04 14:11:48 --> Helper loaded: url_helper
INFO - 2024-05-04 14:11:48 --> Helper loaded: file_helper
INFO - 2024-05-04 14:11:48 --> Helper loaded: html_helper
INFO - 2024-05-04 14:11:48 --> Helper loaded: text_helper
INFO - 2024-05-04 14:11:48 --> Helper loaded: form_helper
INFO - 2024-05-04 14:11:48 --> Helper loaded: lang_helper
INFO - 2024-05-04 14:11:48 --> Helper loaded: security_helper
INFO - 2024-05-04 14:11:48 --> Helper loaded: cookie_helper
INFO - 2024-05-04 14:11:48 --> Database Driver Class Initialized
INFO - 2024-05-04 14:11:48 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-04 14:11:48 --> Parser Class Initialized
INFO - 2024-05-04 14:11:48 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-05-04 14:11:48 --> Pagination Class Initialized
INFO - 2024-05-04 14:11:48 --> Form Validation Class Initialized
INFO - 2024-05-04 14:11:48 --> Controller Class Initialized
DEBUG - 2024-05-04 14:11:48 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-05-04 14:11:48 --> Session class already loaded. Second attempt ignored.
INFO - 2024-05-04 14:11:48 --> Model Class Initialized
DEBUG - 2024-05-04 14:11:48 --> Lsalary class already loaded. Second attempt ignored.
INFO - 2024-05-04 14:11:48 --> Model Class Initialized
INFO - 2024-05-04 14:11:48 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\salary/salary.php
DEBUG - 2024-05-04 14:11:48 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-05-04 14:11:48 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\include/top_menu.php
INFO - 2024-05-04 14:11:48 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\include/admin_loggedin_info.php
INFO - 2024-05-04 14:11:48 --> Model Class Initialized
INFO - 2024-05-04 14:11:48 --> Model Class Initialized
INFO - 2024-05-04 14:11:48 --> Model Class Initialized
INFO - 2024-05-04 14:11:49 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\include/admin_header.php
INFO - 2024-05-04 14:11:49 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\include/admin_footer.php
INFO - 2024-05-04 14:11:49 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\admin_html_template.php
INFO - 2024-05-04 14:11:49 --> Final output sent to browser
DEBUG - 2024-05-04 14:11:49 --> Total execution time: 1.1644
ERROR - 2024-05-04 14:11:49 --> $config['composer_autoload'] is set to TRUE but E:\xampp\htdocs\maurnaturo\application\vendor/autoload.php was not found.
INFO - 2024-05-04 14:11:49 --> Config Class Initialized
INFO - 2024-05-04 14:11:49 --> Hooks Class Initialized
DEBUG - 2024-05-04 14:11:49 --> UTF-8 Support Enabled
INFO - 2024-05-04 14:11:49 --> Utf8 Class Initialized
INFO - 2024-05-04 14:11:49 --> URI Class Initialized
INFO - 2024-05-04 14:11:49 --> Router Class Initialized
INFO - 2024-05-04 14:11:49 --> Output Class Initialized
INFO - 2024-05-04 14:11:49 --> Security Class Initialized
DEBUG - 2024-05-04 14:11:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-04 14:11:49 --> Input Class Initialized
INFO - 2024-05-04 14:11:49 --> Language Class Initialized
ERROR - 2024-05-04 14:11:49 --> 404 Page Not Found: Csalary/CheckSalaryList
ERROR - 2024-05-04 14:14:11 --> $config['composer_autoload'] is set to TRUE but E:\xampp\htdocs\maurnaturo\application\vendor/autoload.php was not found.
INFO - 2024-05-04 14:14:11 --> Config Class Initialized
INFO - 2024-05-04 14:14:11 --> Hooks Class Initialized
DEBUG - 2024-05-04 14:14:11 --> UTF-8 Support Enabled
INFO - 2024-05-04 14:14:11 --> Utf8 Class Initialized
INFO - 2024-05-04 14:14:11 --> URI Class Initialized
INFO - 2024-05-04 14:14:11 --> Router Class Initialized
INFO - 2024-05-04 14:14:11 --> Output Class Initialized
INFO - 2024-05-04 14:14:11 --> Security Class Initialized
DEBUG - 2024-05-04 14:14:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-04 14:14:11 --> Input Class Initialized
INFO - 2024-05-04 14:14:11 --> Language Class Initialized
INFO - 2024-05-04 14:14:11 --> Loader Class Initialized
INFO - 2024-05-04 14:14:11 --> Helper loaded: url_helper
INFO - 2024-05-04 14:14:11 --> Helper loaded: file_helper
INFO - 2024-05-04 14:14:11 --> Helper loaded: html_helper
INFO - 2024-05-04 14:14:11 --> Helper loaded: text_helper
INFO - 2024-05-04 14:14:11 --> Helper loaded: form_helper
INFO - 2024-05-04 14:14:11 --> Helper loaded: lang_helper
INFO - 2024-05-04 14:14:11 --> Helper loaded: security_helper
INFO - 2024-05-04 14:14:11 --> Helper loaded: cookie_helper
INFO - 2024-05-04 14:14:11 --> Database Driver Class Initialized
INFO - 2024-05-04 14:14:11 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-04 14:14:11 --> Parser Class Initialized
INFO - 2024-05-04 14:14:11 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-05-04 14:14:11 --> Pagination Class Initialized
INFO - 2024-05-04 14:14:11 --> Form Validation Class Initialized
INFO - 2024-05-04 14:14:11 --> Controller Class Initialized
DEBUG - 2024-05-04 14:14:11 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-05-04 14:14:11 --> Session class already loaded. Second attempt ignored.
INFO - 2024-05-04 14:14:11 --> Model Class Initialized
DEBUG - 2024-05-04 14:14:11 --> Lsalary class already loaded. Second attempt ignored.
INFO - 2024-05-04 14:14:11 --> Model Class Initialized
INFO - 2024-05-04 14:14:11 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\salary/salary.php
DEBUG - 2024-05-04 14:14:11 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-05-04 14:14:11 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\include/top_menu.php
INFO - 2024-05-04 14:14:11 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\include/admin_loggedin_info.php
INFO - 2024-05-04 14:14:11 --> Model Class Initialized
INFO - 2024-05-04 14:14:11 --> Model Class Initialized
INFO - 2024-05-04 14:14:11 --> Model Class Initialized
INFO - 2024-05-04 14:14:12 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\include/admin_header.php
INFO - 2024-05-04 14:14:12 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\include/admin_footer.php
INFO - 2024-05-04 14:14:12 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\admin_html_template.php
INFO - 2024-05-04 14:14:12 --> Final output sent to browser
DEBUG - 2024-05-04 14:14:12 --> Total execution time: 1.1595
ERROR - 2024-05-04 14:14:13 --> $config['composer_autoload'] is set to TRUE but E:\xampp\htdocs\maurnaturo\application\vendor/autoload.php was not found.
INFO - 2024-05-04 14:14:13 --> Config Class Initialized
INFO - 2024-05-04 14:14:13 --> Hooks Class Initialized
DEBUG - 2024-05-04 14:14:13 --> UTF-8 Support Enabled
INFO - 2024-05-04 14:14:13 --> Utf8 Class Initialized
INFO - 2024-05-04 14:14:13 --> URI Class Initialized
INFO - 2024-05-04 14:14:13 --> Router Class Initialized
INFO - 2024-05-04 14:14:13 --> Output Class Initialized
INFO - 2024-05-04 14:14:13 --> Security Class Initialized
DEBUG - 2024-05-04 14:14:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-04 14:14:13 --> Input Class Initialized
INFO - 2024-05-04 14:14:13 --> Language Class Initialized
INFO - 2024-05-04 14:14:13 --> Loader Class Initialized
INFO - 2024-05-04 14:14:13 --> Helper loaded: url_helper
INFO - 2024-05-04 14:14:13 --> Helper loaded: file_helper
INFO - 2024-05-04 14:14:13 --> Helper loaded: html_helper
INFO - 2024-05-04 14:14:13 --> Helper loaded: text_helper
INFO - 2024-05-04 14:14:13 --> Helper loaded: form_helper
INFO - 2024-05-04 14:14:13 --> Helper loaded: lang_helper
INFO - 2024-05-04 14:14:13 --> Helper loaded: security_helper
INFO - 2024-05-04 14:14:13 --> Helper loaded: cookie_helper
INFO - 2024-05-04 14:14:13 --> Database Driver Class Initialized
INFO - 2024-05-04 14:14:13 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-04 14:14:13 --> Parser Class Initialized
INFO - 2024-05-04 14:14:13 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-05-04 14:14:13 --> Pagination Class Initialized
INFO - 2024-05-04 14:14:13 --> Form Validation Class Initialized
INFO - 2024-05-04 14:14:13 --> Controller Class Initialized
DEBUG - 2024-05-04 14:14:13 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-05-04 14:14:13 --> Session class already loaded. Second attempt ignored.
INFO - 2024-05-04 14:14:13 --> Model Class Initialized
INFO - 2024-05-04 14:14:13 --> Final output sent to browser
DEBUG - 2024-05-04 14:14:13 --> Total execution time: 0.0945
ERROR - 2024-05-04 14:14:48 --> $config['composer_autoload'] is set to TRUE but E:\xampp\htdocs\maurnaturo\application\vendor/autoload.php was not found.
INFO - 2024-05-04 14:14:48 --> Config Class Initialized
INFO - 2024-05-04 14:14:48 --> Hooks Class Initialized
DEBUG - 2024-05-04 14:14:48 --> UTF-8 Support Enabled
INFO - 2024-05-04 14:14:48 --> Utf8 Class Initialized
INFO - 2024-05-04 14:14:48 --> URI Class Initialized
DEBUG - 2024-05-04 14:14:48 --> No URI present. Default controller set.
INFO - 2024-05-04 14:14:48 --> Router Class Initialized
INFO - 2024-05-04 14:14:48 --> Output Class Initialized
INFO - 2024-05-04 14:14:48 --> Security Class Initialized
DEBUG - 2024-05-04 14:14:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-04 14:14:48 --> Input Class Initialized
INFO - 2024-05-04 14:14:48 --> Language Class Initialized
INFO - 2024-05-04 14:14:48 --> Loader Class Initialized
INFO - 2024-05-04 14:14:48 --> Helper loaded: url_helper
INFO - 2024-05-04 14:14:48 --> Helper loaded: file_helper
INFO - 2024-05-04 14:14:48 --> Helper loaded: html_helper
INFO - 2024-05-04 14:14:48 --> Helper loaded: text_helper
INFO - 2024-05-04 14:14:48 --> Helper loaded: form_helper
INFO - 2024-05-04 14:14:48 --> Helper loaded: lang_helper
INFO - 2024-05-04 14:14:48 --> Helper loaded: security_helper
INFO - 2024-05-04 14:14:48 --> Helper loaded: cookie_helper
INFO - 2024-05-04 14:14:48 --> Database Driver Class Initialized
INFO - 2024-05-04 14:14:48 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-04 14:14:48 --> Parser Class Initialized
INFO - 2024-05-04 14:14:48 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-05-04 14:14:48 --> Pagination Class Initialized
INFO - 2024-05-04 14:14:48 --> Form Validation Class Initialized
INFO - 2024-05-04 14:14:48 --> Controller Class Initialized
INFO - 2024-05-04 14:14:48 --> Model Class Initialized
DEBUG - 2024-05-04 14:14:48 --> Session class already loaded. Second attempt ignored.
INFO - 2024-05-04 14:14:48 --> Model Class Initialized
DEBUG - 2024-05-04 14:14:48 --> Session class already loaded. Second attempt ignored.
INFO - 2024-05-04 14:14:48 --> Model Class Initialized
INFO - 2024-05-04 14:14:48 --> Model Class Initialized
INFO - 2024-05-04 14:14:48 --> Model Class Initialized
INFO - 2024-05-04 14:14:48 --> Model Class Initialized
DEBUG - 2024-05-04 14:14:48 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-05-04 14:14:48 --> Session class already loaded. Second attempt ignored.
INFO - 2024-05-04 14:14:48 --> Model Class Initialized
INFO - 2024-05-04 14:14:48 --> Model Class Initialized
INFO - 2024-05-04 14:14:50 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\include/admin_home.php
DEBUG - 2024-05-04 14:14:50 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-05-04 14:14:50 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\include/top_menu.php
INFO - 2024-05-04 14:14:50 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\include/admin_loggedin_info.php
INFO - 2024-05-04 14:14:50 --> Model Class Initialized
INFO - 2024-05-04 14:14:50 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\include/admin_header.php
INFO - 2024-05-04 14:14:50 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\include/admin_footer.php
INFO - 2024-05-04 14:14:50 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\admin_html_template.php
INFO - 2024-05-04 14:14:50 --> Final output sent to browser
DEBUG - 2024-05-04 14:14:50 --> Total execution time: 2.6054
ERROR - 2024-05-04 14:29:12 --> $config['composer_autoload'] is set to TRUE but E:\xampp\htdocs\maurnaturo\application\vendor/autoload.php was not found.
INFO - 2024-05-04 14:29:12 --> Config Class Initialized
INFO - 2024-05-04 14:29:12 --> Hooks Class Initialized
DEBUG - 2024-05-04 14:29:12 --> UTF-8 Support Enabled
INFO - 2024-05-04 14:29:12 --> Utf8 Class Initialized
INFO - 2024-05-04 14:29:12 --> URI Class Initialized
INFO - 2024-05-04 14:29:12 --> Router Class Initialized
INFO - 2024-05-04 14:29:12 --> Output Class Initialized
INFO - 2024-05-04 14:29:12 --> Security Class Initialized
DEBUG - 2024-05-04 14:29:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-04 14:29:12 --> Input Class Initialized
INFO - 2024-05-04 14:29:12 --> Language Class Initialized
ERROR - 2024-05-04 14:29:12 --> 404 Page Not Found: Cmr_payments/manage_mr_payment
ERROR - 2024-05-04 14:29:21 --> $config['composer_autoload'] is set to TRUE but E:\xampp\htdocs\maurnaturo\application\vendor/autoload.php was not found.
INFO - 2024-05-04 14:29:21 --> Config Class Initialized
INFO - 2024-05-04 14:29:21 --> Hooks Class Initialized
DEBUG - 2024-05-04 14:29:21 --> UTF-8 Support Enabled
INFO - 2024-05-04 14:29:21 --> Utf8 Class Initialized
INFO - 2024-05-04 14:29:21 --> URI Class Initialized
INFO - 2024-05-04 14:29:21 --> Router Class Initialized
INFO - 2024-05-04 14:29:21 --> Output Class Initialized
INFO - 2024-05-04 14:29:21 --> Security Class Initialized
DEBUG - 2024-05-04 14:29:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-04 14:29:21 --> Input Class Initialized
INFO - 2024-05-04 14:29:21 --> Language Class Initialized
INFO - 2024-05-04 14:29:21 --> Loader Class Initialized
INFO - 2024-05-04 14:29:21 --> Helper loaded: url_helper
INFO - 2024-05-04 14:29:21 --> Helper loaded: file_helper
INFO - 2024-05-04 14:29:21 --> Helper loaded: html_helper
INFO - 2024-05-04 14:29:21 --> Helper loaded: text_helper
INFO - 2024-05-04 14:29:21 --> Helper loaded: form_helper
INFO - 2024-05-04 14:29:21 --> Helper loaded: lang_helper
INFO - 2024-05-04 14:29:21 --> Helper loaded: security_helper
INFO - 2024-05-04 14:29:21 --> Helper loaded: cookie_helper
INFO - 2024-05-04 14:29:21 --> Database Driver Class Initialized
INFO - 2024-05-04 14:29:21 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-04 14:29:21 --> Parser Class Initialized
INFO - 2024-05-04 14:29:21 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-05-04 14:29:21 --> Pagination Class Initialized
INFO - 2024-05-04 14:29:21 --> Form Validation Class Initialized
INFO - 2024-05-04 14:29:21 --> Controller Class Initialized
DEBUG - 2024-05-04 14:29:21 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-05-04 14:29:21 --> Session class already loaded. Second attempt ignored.
INFO - 2024-05-04 14:29:21 --> Model Class Initialized
DEBUG - 2024-05-04 14:29:21 --> Lpayments class already loaded. Second attempt ignored.
INFO - 2024-05-04 14:29:21 --> Model Class Initialized
INFO - 2024-05-04 14:29:21 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\payments/payment.php
DEBUG - 2024-05-04 14:29:21 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-05-04 14:29:21 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\include/top_menu.php
INFO - 2024-05-04 14:29:21 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\include/admin_loggedin_info.php
INFO - 2024-05-04 14:29:21 --> Model Class Initialized
INFO - 2024-05-04 14:29:21 --> Model Class Initialized
INFO - 2024-05-04 14:29:21 --> Model Class Initialized
INFO - 2024-05-04 14:29:22 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\include/admin_header.php
INFO - 2024-05-04 14:29:22 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\include/admin_footer.php
INFO - 2024-05-04 14:29:22 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\admin_html_template.php
INFO - 2024-05-04 14:29:22 --> Final output sent to browser
DEBUG - 2024-05-04 14:29:22 --> Total execution time: 1.2176
ERROR - 2024-05-04 14:29:23 --> $config['composer_autoload'] is set to TRUE but E:\xampp\htdocs\maurnaturo\application\vendor/autoload.php was not found.
INFO - 2024-05-04 14:29:23 --> Config Class Initialized
INFO - 2024-05-04 14:29:23 --> Hooks Class Initialized
DEBUG - 2024-05-04 14:29:23 --> UTF-8 Support Enabled
INFO - 2024-05-04 14:29:23 --> Utf8 Class Initialized
INFO - 2024-05-04 14:29:23 --> URI Class Initialized
INFO - 2024-05-04 14:29:23 --> Router Class Initialized
INFO - 2024-05-04 14:29:23 --> Output Class Initialized
INFO - 2024-05-04 14:29:23 --> Security Class Initialized
DEBUG - 2024-05-04 14:29:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-04 14:29:23 --> Input Class Initialized
INFO - 2024-05-04 14:29:23 --> Language Class Initialized
INFO - 2024-05-04 14:29:23 --> Loader Class Initialized
INFO - 2024-05-04 14:29:23 --> Helper loaded: url_helper
INFO - 2024-05-04 14:29:23 --> Helper loaded: file_helper
INFO - 2024-05-04 14:29:23 --> Helper loaded: html_helper
INFO - 2024-05-04 14:29:23 --> Helper loaded: text_helper
INFO - 2024-05-04 14:29:23 --> Helper loaded: form_helper
INFO - 2024-05-04 14:29:23 --> Helper loaded: lang_helper
INFO - 2024-05-04 14:29:23 --> Helper loaded: security_helper
INFO - 2024-05-04 14:29:23 --> Helper loaded: cookie_helper
INFO - 2024-05-04 14:29:23 --> Database Driver Class Initialized
INFO - 2024-05-04 14:29:23 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-04 14:29:23 --> Parser Class Initialized
INFO - 2024-05-04 14:29:23 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-05-04 14:29:23 --> Pagination Class Initialized
INFO - 2024-05-04 14:29:23 --> Form Validation Class Initialized
INFO - 2024-05-04 14:29:23 --> Controller Class Initialized
DEBUG - 2024-05-04 14:29:23 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-05-04 14:29:23 --> Session class already loaded. Second attempt ignored.
INFO - 2024-05-04 14:29:23 --> Model Class Initialized
INFO - 2024-05-04 14:29:23 --> Final output sent to browser
DEBUG - 2024-05-04 14:29:23 --> Total execution time: 0.1111
ERROR - 2024-05-04 14:29:37 --> $config['composer_autoload'] is set to TRUE but E:\xampp\htdocs\maurnaturo\application\vendor/autoload.php was not found.
INFO - 2024-05-04 14:29:37 --> Config Class Initialized
INFO - 2024-05-04 14:29:37 --> Hooks Class Initialized
DEBUG - 2024-05-04 14:29:37 --> UTF-8 Support Enabled
INFO - 2024-05-04 14:29:37 --> Utf8 Class Initialized
INFO - 2024-05-04 14:29:37 --> URI Class Initialized
INFO - 2024-05-04 14:29:37 --> Router Class Initialized
INFO - 2024-05-04 14:29:37 --> Output Class Initialized
INFO - 2024-05-04 14:29:37 --> Security Class Initialized
DEBUG - 2024-05-04 14:29:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-04 14:29:37 --> Input Class Initialized
INFO - 2024-05-04 14:29:37 --> Language Class Initialized
INFO - 2024-05-04 14:29:37 --> Loader Class Initialized
INFO - 2024-05-04 14:29:37 --> Helper loaded: url_helper
INFO - 2024-05-04 14:29:37 --> Helper loaded: file_helper
INFO - 2024-05-04 14:29:37 --> Helper loaded: html_helper
INFO - 2024-05-04 14:29:37 --> Helper loaded: text_helper
INFO - 2024-05-04 14:29:37 --> Helper loaded: form_helper
INFO - 2024-05-04 14:29:37 --> Helper loaded: lang_helper
INFO - 2024-05-04 14:29:37 --> Helper loaded: security_helper
INFO - 2024-05-04 14:29:37 --> Helper loaded: cookie_helper
INFO - 2024-05-04 14:29:37 --> Database Driver Class Initialized
INFO - 2024-05-04 14:29:37 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-04 14:29:37 --> Parser Class Initialized
INFO - 2024-05-04 14:29:37 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-05-04 14:29:37 --> Pagination Class Initialized
INFO - 2024-05-04 14:29:37 --> Form Validation Class Initialized
INFO - 2024-05-04 14:29:37 --> Controller Class Initialized
DEBUG - 2024-05-04 14:29:37 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-05-04 14:29:37 --> Session class already loaded. Second attempt ignored.
INFO - 2024-05-04 14:29:37 --> Model Class Initialized
INFO - 2024-05-04 14:29:37 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\mr_payments/add_payment_form.php
DEBUG - 2024-05-04 14:29:37 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-05-04 14:29:37 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\include/top_menu.php
INFO - 2024-05-04 14:29:37 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\include/admin_loggedin_info.php
INFO - 2024-05-04 14:29:37 --> Model Class Initialized
INFO - 2024-05-04 14:29:37 --> Model Class Initialized
INFO - 2024-05-04 14:29:37 --> Model Class Initialized
INFO - 2024-05-04 14:29:37 --> Model Class Initialized
INFO - 2024-05-04 14:29:38 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\include/admin_header.php
INFO - 2024-05-04 14:29:38 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\include/admin_footer.php
INFO - 2024-05-04 14:29:38 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\admin_html_template.php
INFO - 2024-05-04 14:29:38 --> Final output sent to browser
DEBUG - 2024-05-04 14:29:38 --> Total execution time: 1.3678
ERROR - 2024-05-04 14:29:40 --> $config['composer_autoload'] is set to TRUE but E:\xampp\htdocs\maurnaturo\application\vendor/autoload.php was not found.
INFO - 2024-05-04 14:29:40 --> Config Class Initialized
INFO - 2024-05-04 14:29:40 --> Hooks Class Initialized
DEBUG - 2024-05-04 14:29:40 --> UTF-8 Support Enabled
INFO - 2024-05-04 14:29:40 --> Utf8 Class Initialized
INFO - 2024-05-04 14:29:40 --> URI Class Initialized
INFO - 2024-05-04 14:29:40 --> Router Class Initialized
INFO - 2024-05-04 14:29:40 --> Output Class Initialized
INFO - 2024-05-04 14:29:40 --> Security Class Initialized
DEBUG - 2024-05-04 14:29:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-04 14:29:40 --> Input Class Initialized
INFO - 2024-05-04 14:29:40 --> Language Class Initialized
INFO - 2024-05-04 14:29:40 --> Loader Class Initialized
INFO - 2024-05-04 14:29:40 --> Helper loaded: url_helper
INFO - 2024-05-04 14:29:40 --> Helper loaded: file_helper
INFO - 2024-05-04 14:29:40 --> Helper loaded: html_helper
INFO - 2024-05-04 14:29:40 --> Helper loaded: text_helper
INFO - 2024-05-04 14:29:40 --> Helper loaded: form_helper
INFO - 2024-05-04 14:29:40 --> Helper loaded: lang_helper
INFO - 2024-05-04 14:29:40 --> Helper loaded: security_helper
INFO - 2024-05-04 14:29:40 --> Helper loaded: cookie_helper
INFO - 2024-05-04 14:29:40 --> Database Driver Class Initialized
INFO - 2024-05-04 14:29:40 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-04 14:29:40 --> Parser Class Initialized
INFO - 2024-05-04 14:29:40 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-05-04 14:29:40 --> Pagination Class Initialized
INFO - 2024-05-04 14:29:40 --> Form Validation Class Initialized
INFO - 2024-05-04 14:29:40 --> Controller Class Initialized
DEBUG - 2024-05-04 14:29:40 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-05-04 14:29:40 --> Session class already loaded. Second attempt ignored.
INFO - 2024-05-04 14:29:40 --> Model Class Initialized
DEBUG - 2024-05-04 14:29:40 --> Lmrpayments class already loaded. Second attempt ignored.
INFO - 2024-05-04 14:29:40 --> Model Class Initialized
INFO - 2024-05-04 14:29:40 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\mr_payments/payment.php
DEBUG - 2024-05-04 14:29:40 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-05-04 14:29:40 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\include/top_menu.php
INFO - 2024-05-04 14:29:40 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\include/admin_loggedin_info.php
INFO - 2024-05-04 14:29:40 --> Model Class Initialized
INFO - 2024-05-04 14:29:40 --> Model Class Initialized
INFO - 2024-05-04 14:29:40 --> Model Class Initialized
INFO - 2024-05-04 14:29:41 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\include/admin_header.php
INFO - 2024-05-04 14:29:41 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\include/admin_footer.php
INFO - 2024-05-04 14:29:41 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\admin_html_template.php
INFO - 2024-05-04 14:29:41 --> Final output sent to browser
DEBUG - 2024-05-04 14:29:41 --> Total execution time: 1.3177
ERROR - 2024-05-04 14:29:41 --> $config['composer_autoload'] is set to TRUE but E:\xampp\htdocs\maurnaturo\application\vendor/autoload.php was not found.
INFO - 2024-05-04 14:29:42 --> Config Class Initialized
INFO - 2024-05-04 14:29:42 --> Hooks Class Initialized
DEBUG - 2024-05-04 14:29:42 --> UTF-8 Support Enabled
INFO - 2024-05-04 14:29:42 --> Utf8 Class Initialized
INFO - 2024-05-04 14:29:42 --> URI Class Initialized
INFO - 2024-05-04 14:29:42 --> Router Class Initialized
INFO - 2024-05-04 14:29:42 --> Output Class Initialized
INFO - 2024-05-04 14:29:42 --> Security Class Initialized
DEBUG - 2024-05-04 14:29:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-04 14:29:42 --> Input Class Initialized
INFO - 2024-05-04 14:29:42 --> Language Class Initialized
INFO - 2024-05-04 14:29:42 --> Loader Class Initialized
INFO - 2024-05-04 14:29:42 --> Helper loaded: url_helper
INFO - 2024-05-04 14:29:42 --> Helper loaded: file_helper
INFO - 2024-05-04 14:29:42 --> Helper loaded: html_helper
INFO - 2024-05-04 14:29:42 --> Helper loaded: text_helper
INFO - 2024-05-04 14:29:42 --> Helper loaded: form_helper
INFO - 2024-05-04 14:29:42 --> Helper loaded: lang_helper
INFO - 2024-05-04 14:29:42 --> Helper loaded: security_helper
INFO - 2024-05-04 14:29:42 --> Helper loaded: cookie_helper
INFO - 2024-05-04 14:29:42 --> Database Driver Class Initialized
INFO - 2024-05-04 14:29:42 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-04 14:29:42 --> Parser Class Initialized
INFO - 2024-05-04 14:29:42 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-05-04 14:29:42 --> Pagination Class Initialized
INFO - 2024-05-04 14:29:42 --> Form Validation Class Initialized
INFO - 2024-05-04 14:29:42 --> Controller Class Initialized
DEBUG - 2024-05-04 14:29:42 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-05-04 14:29:42 --> Session class already loaded. Second attempt ignored.
INFO - 2024-05-04 14:29:42 --> Model Class Initialized
INFO - 2024-05-04 14:29:42 --> Final output sent to browser
DEBUG - 2024-05-04 14:29:42 --> Total execution time: 0.1092
ERROR - 2024-05-04 14:29:55 --> $config['composer_autoload'] is set to TRUE but E:\xampp\htdocs\maurnaturo\application\vendor/autoload.php was not found.
INFO - 2024-05-04 14:29:55 --> Config Class Initialized
INFO - 2024-05-04 14:29:55 --> Hooks Class Initialized
DEBUG - 2024-05-04 14:29:55 --> UTF-8 Support Enabled
INFO - 2024-05-04 14:29:55 --> Utf8 Class Initialized
INFO - 2024-05-04 14:29:55 --> URI Class Initialized
INFO - 2024-05-04 14:29:55 --> Router Class Initialized
INFO - 2024-05-04 14:29:55 --> Output Class Initialized
INFO - 2024-05-04 14:29:55 --> Security Class Initialized
DEBUG - 2024-05-04 14:29:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-04 14:29:55 --> Input Class Initialized
INFO - 2024-05-04 14:29:55 --> Language Class Initialized
INFO - 2024-05-04 14:29:55 --> Loader Class Initialized
INFO - 2024-05-04 14:29:55 --> Helper loaded: url_helper
INFO - 2024-05-04 14:29:55 --> Helper loaded: file_helper
INFO - 2024-05-04 14:29:55 --> Helper loaded: html_helper
INFO - 2024-05-04 14:29:55 --> Helper loaded: text_helper
INFO - 2024-05-04 14:29:55 --> Helper loaded: form_helper
INFO - 2024-05-04 14:29:55 --> Helper loaded: lang_helper
INFO - 2024-05-04 14:29:55 --> Helper loaded: security_helper
INFO - 2024-05-04 14:29:55 --> Helper loaded: cookie_helper
INFO - 2024-05-04 14:29:55 --> Database Driver Class Initialized
INFO - 2024-05-04 14:29:55 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-04 14:29:55 --> Parser Class Initialized
INFO - 2024-05-04 14:29:55 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-05-04 14:29:55 --> Pagination Class Initialized
INFO - 2024-05-04 14:29:55 --> Form Validation Class Initialized
INFO - 2024-05-04 14:29:55 --> Controller Class Initialized
DEBUG - 2024-05-04 14:29:55 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-05-04 14:29:55 --> Session class already loaded. Second attempt ignored.
INFO - 2024-05-04 14:29:55 --> Model Class Initialized
DEBUG - 2024-05-04 14:29:55 --> Lsalary class already loaded. Second attempt ignored.
INFO - 2024-05-04 14:29:55 --> Model Class Initialized
INFO - 2024-05-04 14:29:55 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\salary/salary.php
DEBUG - 2024-05-04 14:29:55 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-05-04 14:29:55 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\include/top_menu.php
INFO - 2024-05-04 14:29:55 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\include/admin_loggedin_info.php
INFO - 2024-05-04 14:29:55 --> Model Class Initialized
INFO - 2024-05-04 14:29:56 --> Model Class Initialized
INFO - 2024-05-04 14:29:56 --> Model Class Initialized
INFO - 2024-05-04 14:29:57 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\include/admin_header.php
INFO - 2024-05-04 14:29:57 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\include/admin_footer.php
INFO - 2024-05-04 14:29:57 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\admin_html_template.php
INFO - 2024-05-04 14:29:57 --> Final output sent to browser
DEBUG - 2024-05-04 14:29:57 --> Total execution time: 1.2616
ERROR - 2024-05-04 14:29:57 --> $config['composer_autoload'] is set to TRUE but E:\xampp\htdocs\maurnaturo\application\vendor/autoload.php was not found.
INFO - 2024-05-04 14:29:57 --> Config Class Initialized
INFO - 2024-05-04 14:29:57 --> Hooks Class Initialized
DEBUG - 2024-05-04 14:29:57 --> UTF-8 Support Enabled
INFO - 2024-05-04 14:29:57 --> Utf8 Class Initialized
INFO - 2024-05-04 14:29:57 --> URI Class Initialized
INFO - 2024-05-04 14:29:57 --> Router Class Initialized
INFO - 2024-05-04 14:29:57 --> Output Class Initialized
INFO - 2024-05-04 14:29:57 --> Security Class Initialized
DEBUG - 2024-05-04 14:29:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-04 14:29:57 --> Input Class Initialized
INFO - 2024-05-04 14:29:57 --> Language Class Initialized
INFO - 2024-05-04 14:29:57 --> Loader Class Initialized
INFO - 2024-05-04 14:29:57 --> Helper loaded: url_helper
INFO - 2024-05-04 14:29:57 --> Helper loaded: file_helper
INFO - 2024-05-04 14:29:57 --> Helper loaded: html_helper
INFO - 2024-05-04 14:29:57 --> Helper loaded: text_helper
INFO - 2024-05-04 14:29:57 --> Helper loaded: form_helper
INFO - 2024-05-04 14:29:57 --> Helper loaded: lang_helper
INFO - 2024-05-04 14:29:57 --> Helper loaded: security_helper
INFO - 2024-05-04 14:29:57 --> Helper loaded: cookie_helper
INFO - 2024-05-04 14:29:57 --> Database Driver Class Initialized
INFO - 2024-05-04 14:29:57 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-04 14:29:57 --> Parser Class Initialized
INFO - 2024-05-04 14:29:57 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-05-04 14:29:57 --> Pagination Class Initialized
INFO - 2024-05-04 14:29:57 --> Form Validation Class Initialized
INFO - 2024-05-04 14:29:57 --> Controller Class Initialized
DEBUG - 2024-05-04 14:29:57 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-05-04 14:29:57 --> Session class already loaded. Second attempt ignored.
INFO - 2024-05-04 14:29:57 --> Model Class Initialized
INFO - 2024-05-04 14:29:57 --> Final output sent to browser
DEBUG - 2024-05-04 14:29:57 --> Total execution time: 0.1037
ERROR - 2024-05-04 14:30:08 --> $config['composer_autoload'] is set to TRUE but E:\xampp\htdocs\maurnaturo\application\vendor/autoload.php was not found.
INFO - 2024-05-04 14:30:08 --> Config Class Initialized
INFO - 2024-05-04 14:30:08 --> Hooks Class Initialized
DEBUG - 2024-05-04 14:30:08 --> UTF-8 Support Enabled
INFO - 2024-05-04 14:30:08 --> Utf8 Class Initialized
INFO - 2024-05-04 14:30:08 --> URI Class Initialized
INFO - 2024-05-04 14:30:08 --> Router Class Initialized
INFO - 2024-05-04 14:30:08 --> Output Class Initialized
INFO - 2024-05-04 14:30:08 --> Security Class Initialized
DEBUG - 2024-05-04 14:30:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-04 14:30:08 --> Input Class Initialized
INFO - 2024-05-04 14:30:08 --> Language Class Initialized
INFO - 2024-05-04 14:30:08 --> Loader Class Initialized
INFO - 2024-05-04 14:30:08 --> Helper loaded: url_helper
INFO - 2024-05-04 14:30:08 --> Helper loaded: file_helper
INFO - 2024-05-04 14:30:08 --> Helper loaded: html_helper
INFO - 2024-05-04 14:30:08 --> Helper loaded: text_helper
INFO - 2024-05-04 14:30:08 --> Helper loaded: form_helper
INFO - 2024-05-04 14:30:08 --> Helper loaded: lang_helper
INFO - 2024-05-04 14:30:08 --> Helper loaded: security_helper
INFO - 2024-05-04 14:30:08 --> Helper loaded: cookie_helper
INFO - 2024-05-04 14:30:08 --> Database Driver Class Initialized
INFO - 2024-05-04 14:30:08 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-04 14:30:08 --> Parser Class Initialized
INFO - 2024-05-04 14:30:08 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-05-04 14:30:08 --> Pagination Class Initialized
INFO - 2024-05-04 14:30:08 --> Form Validation Class Initialized
INFO - 2024-05-04 14:30:08 --> Controller Class Initialized
DEBUG - 2024-05-04 14:30:08 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-05-04 14:30:08 --> Session class already loaded. Second attempt ignored.
INFO - 2024-05-04 14:30:08 --> Model Class Initialized
DEBUG - 2024-05-04 14:30:08 --> Lexpenses class already loaded. Second attempt ignored.
INFO - 2024-05-04 14:30:08 --> Model Class Initialized
INFO - 2024-05-04 14:30:08 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\expenses/expenses.php
DEBUG - 2024-05-04 14:30:08 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-05-04 14:30:08 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\include/top_menu.php
INFO - 2024-05-04 14:30:08 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\include/admin_loggedin_info.php
INFO - 2024-05-04 14:30:08 --> Model Class Initialized
INFO - 2024-05-04 14:30:08 --> Model Class Initialized
INFO - 2024-05-04 14:30:08 --> Model Class Initialized
INFO - 2024-05-04 14:30:09 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\include/admin_header.php
INFO - 2024-05-04 14:30:09 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\include/admin_footer.php
INFO - 2024-05-04 14:30:09 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\admin_html_template.php
INFO - 2024-05-04 14:30:09 --> Final output sent to browser
DEBUG - 2024-05-04 14:30:09 --> Total execution time: 1.1759
ERROR - 2024-05-04 14:30:10 --> $config['composer_autoload'] is set to TRUE but E:\xampp\htdocs\maurnaturo\application\vendor/autoload.php was not found.
INFO - 2024-05-04 14:30:10 --> Config Class Initialized
INFO - 2024-05-04 14:30:10 --> Hooks Class Initialized
DEBUG - 2024-05-04 14:30:10 --> UTF-8 Support Enabled
INFO - 2024-05-04 14:30:10 --> Utf8 Class Initialized
INFO - 2024-05-04 14:30:10 --> URI Class Initialized
INFO - 2024-05-04 14:30:10 --> Router Class Initialized
INFO - 2024-05-04 14:30:10 --> Output Class Initialized
INFO - 2024-05-04 14:30:10 --> Security Class Initialized
DEBUG - 2024-05-04 14:30:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-04 14:30:10 --> Input Class Initialized
INFO - 2024-05-04 14:30:10 --> Language Class Initialized
INFO - 2024-05-04 14:30:10 --> Loader Class Initialized
INFO - 2024-05-04 14:30:10 --> Helper loaded: url_helper
INFO - 2024-05-04 14:30:10 --> Helper loaded: file_helper
INFO - 2024-05-04 14:30:10 --> Helper loaded: html_helper
INFO - 2024-05-04 14:30:10 --> Helper loaded: text_helper
INFO - 2024-05-04 14:30:10 --> Helper loaded: form_helper
INFO - 2024-05-04 14:30:10 --> Helper loaded: lang_helper
INFO - 2024-05-04 14:30:10 --> Helper loaded: security_helper
INFO - 2024-05-04 14:30:10 --> Helper loaded: cookie_helper
INFO - 2024-05-04 14:30:10 --> Database Driver Class Initialized
INFO - 2024-05-04 14:30:10 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-04 14:30:10 --> Parser Class Initialized
INFO - 2024-05-04 14:30:10 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-05-04 14:30:10 --> Pagination Class Initialized
INFO - 2024-05-04 14:30:10 --> Form Validation Class Initialized
INFO - 2024-05-04 14:30:10 --> Controller Class Initialized
DEBUG - 2024-05-04 14:30:10 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-05-04 14:30:10 --> Session class already loaded. Second attempt ignored.
INFO - 2024-05-04 14:30:10 --> Model Class Initialized
INFO - 2024-05-04 14:30:10 --> Final output sent to browser
DEBUG - 2024-05-04 14:30:10 --> Total execution time: 0.1133
ERROR - 2024-05-04 14:30:34 --> $config['composer_autoload'] is set to TRUE but E:\xampp\htdocs\maurnaturo\application\vendor/autoload.php was not found.
INFO - 2024-05-04 14:30:34 --> Config Class Initialized
INFO - 2024-05-04 14:30:34 --> Hooks Class Initialized
DEBUG - 2024-05-04 14:30:34 --> UTF-8 Support Enabled
INFO - 2024-05-04 14:30:34 --> Utf8 Class Initialized
INFO - 2024-05-04 14:30:34 --> URI Class Initialized
DEBUG - 2024-05-04 14:30:34 --> No URI present. Default controller set.
INFO - 2024-05-04 14:30:34 --> Router Class Initialized
INFO - 2024-05-04 14:30:34 --> Output Class Initialized
INFO - 2024-05-04 14:30:34 --> Security Class Initialized
DEBUG - 2024-05-04 14:30:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-04 14:30:34 --> Input Class Initialized
INFO - 2024-05-04 14:30:34 --> Language Class Initialized
INFO - 2024-05-04 14:30:34 --> Loader Class Initialized
INFO - 2024-05-04 14:30:34 --> Helper loaded: url_helper
INFO - 2024-05-04 14:30:34 --> Helper loaded: file_helper
INFO - 2024-05-04 14:30:34 --> Helper loaded: html_helper
INFO - 2024-05-04 14:30:34 --> Helper loaded: text_helper
INFO - 2024-05-04 14:30:34 --> Helper loaded: form_helper
INFO - 2024-05-04 14:30:34 --> Helper loaded: lang_helper
INFO - 2024-05-04 14:30:34 --> Helper loaded: security_helper
INFO - 2024-05-04 14:30:34 --> Helper loaded: cookie_helper
INFO - 2024-05-04 14:30:34 --> Database Driver Class Initialized
INFO - 2024-05-04 14:30:34 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-04 14:30:34 --> Parser Class Initialized
INFO - 2024-05-04 14:30:34 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-05-04 14:30:34 --> Pagination Class Initialized
INFO - 2024-05-04 14:30:34 --> Form Validation Class Initialized
INFO - 2024-05-04 14:30:34 --> Controller Class Initialized
INFO - 2024-05-04 14:30:34 --> Model Class Initialized
DEBUG - 2024-05-04 14:30:34 --> Session class already loaded. Second attempt ignored.
INFO - 2024-05-04 14:30:34 --> Model Class Initialized
DEBUG - 2024-05-04 14:30:34 --> Session class already loaded. Second attempt ignored.
INFO - 2024-05-04 14:30:34 --> Model Class Initialized
INFO - 2024-05-04 14:30:34 --> Model Class Initialized
INFO - 2024-05-04 14:30:34 --> Model Class Initialized
INFO - 2024-05-04 14:30:34 --> Model Class Initialized
DEBUG - 2024-05-04 14:30:34 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-05-04 14:30:34 --> Session class already loaded. Second attempt ignored.
INFO - 2024-05-04 14:30:34 --> Model Class Initialized
INFO - 2024-05-04 14:30:34 --> Model Class Initialized
INFO - 2024-05-04 14:30:35 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\include/admin_home.php
DEBUG - 2024-05-04 14:30:35 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-05-04 14:30:35 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\include/top_menu.php
INFO - 2024-05-04 14:30:35 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\include/admin_loggedin_info.php
INFO - 2024-05-04 14:30:35 --> Model Class Initialized
INFO - 2024-05-04 14:30:36 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\include/admin_header.php
INFO - 2024-05-04 14:30:36 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\include/admin_footer.php
INFO - 2024-05-04 14:30:36 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\admin_html_template.php
INFO - 2024-05-04 14:30:36 --> Final output sent to browser
DEBUG - 2024-05-04 14:30:36 --> Total execution time: 2.5199
ERROR - 2024-05-04 15:55:36 --> $config['composer_autoload'] is set to TRUE but E:\xampp\htdocs\maurnaturo\application\vendor/autoload.php was not found.
INFO - 2024-05-04 15:55:36 --> Config Class Initialized
INFO - 2024-05-04 15:55:36 --> Hooks Class Initialized
DEBUG - 2024-05-04 15:55:36 --> UTF-8 Support Enabled
INFO - 2024-05-04 15:55:36 --> Utf8 Class Initialized
INFO - 2024-05-04 15:55:36 --> URI Class Initialized
DEBUG - 2024-05-04 15:55:36 --> No URI present. Default controller set.
INFO - 2024-05-04 15:55:36 --> Router Class Initialized
INFO - 2024-05-04 15:55:36 --> Output Class Initialized
INFO - 2024-05-04 15:55:36 --> Security Class Initialized
DEBUG - 2024-05-04 15:55:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-04 15:55:36 --> Input Class Initialized
INFO - 2024-05-04 15:55:36 --> Language Class Initialized
INFO - 2024-05-04 15:55:36 --> Loader Class Initialized
INFO - 2024-05-04 15:55:36 --> Helper loaded: url_helper
INFO - 2024-05-04 15:55:36 --> Helper loaded: file_helper
INFO - 2024-05-04 15:55:36 --> Helper loaded: html_helper
INFO - 2024-05-04 15:55:36 --> Helper loaded: text_helper
INFO - 2024-05-04 15:55:36 --> Helper loaded: form_helper
INFO - 2024-05-04 15:55:36 --> Helper loaded: lang_helper
INFO - 2024-05-04 15:55:36 --> Helper loaded: security_helper
INFO - 2024-05-04 15:55:36 --> Helper loaded: cookie_helper
INFO - 2024-05-04 15:55:36 --> Database Driver Class Initialized
INFO - 2024-05-04 15:55:36 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-04 15:55:36 --> Parser Class Initialized
INFO - 2024-05-04 15:55:36 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-05-04 15:55:36 --> Pagination Class Initialized
INFO - 2024-05-04 15:55:36 --> Form Validation Class Initialized
INFO - 2024-05-04 15:55:36 --> Controller Class Initialized
INFO - 2024-05-04 15:55:36 --> Model Class Initialized
DEBUG - 2024-05-04 15:55:36 --> Session class already loaded. Second attempt ignored.
INFO - 2024-05-04 15:55:36 --> Model Class Initialized
DEBUG - 2024-05-04 15:55:36 --> Session class already loaded. Second attempt ignored.
INFO - 2024-05-04 15:55:36 --> Model Class Initialized
INFO - 2024-05-04 15:55:36 --> Model Class Initialized
INFO - 2024-05-04 15:55:36 --> Model Class Initialized
INFO - 2024-05-04 15:55:36 --> Model Class Initialized
DEBUG - 2024-05-04 15:55:36 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-05-04 15:55:36 --> Session class already loaded. Second attempt ignored.
INFO - 2024-05-04 15:55:36 --> Model Class Initialized
INFO - 2024-05-04 15:55:36 --> Model Class Initialized
INFO - 2024-05-04 15:55:38 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\include/admin_home.php
DEBUG - 2024-05-04 15:55:38 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-05-04 15:55:38 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\include/top_menu.php
INFO - 2024-05-04 15:55:38 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\include/admin_loggedin_info.php
INFO - 2024-05-04 15:55:38 --> Model Class Initialized
INFO - 2024-05-04 15:55:39 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\include/admin_header.php
INFO - 2024-05-04 15:55:39 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\include/admin_footer.php
INFO - 2024-05-04 15:55:39 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\admin_html_template.php
INFO - 2024-05-04 15:55:39 --> Final output sent to browser
DEBUG - 2024-05-04 15:55:39 --> Total execution time: 2.8773
ERROR - 2024-05-04 16:04:38 --> $config['composer_autoload'] is set to TRUE but E:\xampp\htdocs\maurnaturo\application\vendor/autoload.php was not found.
INFO - 2024-05-04 16:04:38 --> Config Class Initialized
INFO - 2024-05-04 16:04:38 --> Hooks Class Initialized
DEBUG - 2024-05-04 16:04:38 --> UTF-8 Support Enabled
INFO - 2024-05-04 16:04:38 --> Utf8 Class Initialized
INFO - 2024-05-04 16:04:38 --> URI Class Initialized
DEBUG - 2024-05-04 16:04:38 --> No URI present. Default controller set.
INFO - 2024-05-04 16:04:38 --> Router Class Initialized
INFO - 2024-05-04 16:04:38 --> Output Class Initialized
INFO - 2024-05-04 16:04:38 --> Security Class Initialized
DEBUG - 2024-05-04 16:04:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-04 16:04:38 --> Input Class Initialized
INFO - 2024-05-04 16:04:38 --> Language Class Initialized
INFO - 2024-05-04 16:04:38 --> Loader Class Initialized
INFO - 2024-05-04 16:04:38 --> Helper loaded: url_helper
INFO - 2024-05-04 16:04:38 --> Helper loaded: file_helper
INFO - 2024-05-04 16:04:38 --> Helper loaded: html_helper
INFO - 2024-05-04 16:04:38 --> Helper loaded: text_helper
INFO - 2024-05-04 16:04:38 --> Helper loaded: form_helper
INFO - 2024-05-04 16:04:38 --> Helper loaded: lang_helper
INFO - 2024-05-04 16:04:38 --> Helper loaded: security_helper
INFO - 2024-05-04 16:04:38 --> Helper loaded: cookie_helper
INFO - 2024-05-04 16:04:38 --> Database Driver Class Initialized
INFO - 2024-05-04 16:04:38 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-04 16:04:38 --> Parser Class Initialized
INFO - 2024-05-04 16:04:38 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-05-04 16:04:38 --> Pagination Class Initialized
INFO - 2024-05-04 16:04:38 --> Form Validation Class Initialized
INFO - 2024-05-04 16:04:38 --> Controller Class Initialized
INFO - 2024-05-04 16:04:38 --> Model Class Initialized
DEBUG - 2024-05-04 16:04:38 --> Session class already loaded. Second attempt ignored.
ERROR - 2024-05-04 16:04:38 --> $config['composer_autoload'] is set to TRUE but E:\xampp\htdocs\maurnaturo\application\vendor/autoload.php was not found.
INFO - 2024-05-04 16:04:38 --> Config Class Initialized
INFO - 2024-05-04 16:04:38 --> Hooks Class Initialized
DEBUG - 2024-05-04 16:04:38 --> UTF-8 Support Enabled
INFO - 2024-05-04 16:04:38 --> Utf8 Class Initialized
INFO - 2024-05-04 16:04:38 --> URI Class Initialized
INFO - 2024-05-04 16:04:38 --> Router Class Initialized
INFO - 2024-05-04 16:04:38 --> Output Class Initialized
INFO - 2024-05-04 16:04:38 --> Security Class Initialized
DEBUG - 2024-05-04 16:04:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-04 16:04:38 --> Input Class Initialized
INFO - 2024-05-04 16:04:38 --> Language Class Initialized
INFO - 2024-05-04 16:04:38 --> Loader Class Initialized
INFO - 2024-05-04 16:04:38 --> Helper loaded: url_helper
INFO - 2024-05-04 16:04:38 --> Helper loaded: file_helper
INFO - 2024-05-04 16:04:38 --> Helper loaded: html_helper
INFO - 2024-05-04 16:04:38 --> Helper loaded: text_helper
INFO - 2024-05-04 16:04:38 --> Helper loaded: form_helper
INFO - 2024-05-04 16:04:38 --> Helper loaded: lang_helper
INFO - 2024-05-04 16:04:38 --> Helper loaded: security_helper
INFO - 2024-05-04 16:04:38 --> Helper loaded: cookie_helper
INFO - 2024-05-04 16:04:38 --> Database Driver Class Initialized
INFO - 2024-05-04 16:04:38 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-04 16:04:38 --> Parser Class Initialized
INFO - 2024-05-04 16:04:38 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-05-04 16:04:38 --> Pagination Class Initialized
INFO - 2024-05-04 16:04:38 --> Form Validation Class Initialized
INFO - 2024-05-04 16:04:38 --> Controller Class Initialized
INFO - 2024-05-04 16:04:38 --> Model Class Initialized
DEBUG - 2024-05-04 16:04:38 --> Session class already loaded. Second attempt ignored.
INFO - 2024-05-04 16:04:38 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\user/admin_login_form.php
DEBUG - 2024-05-04 16:04:38 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-05-04 16:04:38 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\include/top_menu.php
INFO - 2024-05-04 16:04:38 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\include/admin_loggedin_info.php
INFO - 2024-05-04 16:04:38 --> Model Class Initialized
INFO - 2024-05-04 16:04:38 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\admin_html_template.php
INFO - 2024-05-04 16:04:38 --> Final output sent to browser
DEBUG - 2024-05-04 16:04:38 --> Total execution time: 0.1983
ERROR - 2024-05-04 16:07:09 --> $config['composer_autoload'] is set to TRUE but E:\xampp\htdocs\maurnaturo\application\vendor/autoload.php was not found.
INFO - 2024-05-04 16:07:09 --> Config Class Initialized
INFO - 2024-05-04 16:07:09 --> Hooks Class Initialized
DEBUG - 2024-05-04 16:07:09 --> UTF-8 Support Enabled
INFO - 2024-05-04 16:07:09 --> Utf8 Class Initialized
INFO - 2024-05-04 16:07:09 --> URI Class Initialized
DEBUG - 2024-05-04 16:07:09 --> No URI present. Default controller set.
INFO - 2024-05-04 16:07:09 --> Router Class Initialized
INFO - 2024-05-04 16:07:09 --> Output Class Initialized
INFO - 2024-05-04 16:07:09 --> Security Class Initialized
DEBUG - 2024-05-04 16:07:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-04 16:07:09 --> Input Class Initialized
INFO - 2024-05-04 16:07:09 --> Language Class Initialized
INFO - 2024-05-04 16:07:09 --> Loader Class Initialized
INFO - 2024-05-04 16:07:09 --> Helper loaded: url_helper
INFO - 2024-05-04 16:07:09 --> Helper loaded: file_helper
INFO - 2024-05-04 16:07:09 --> Helper loaded: html_helper
INFO - 2024-05-04 16:07:09 --> Helper loaded: text_helper
INFO - 2024-05-04 16:07:09 --> Helper loaded: form_helper
INFO - 2024-05-04 16:07:09 --> Helper loaded: lang_helper
INFO - 2024-05-04 16:07:09 --> Helper loaded: security_helper
INFO - 2024-05-04 16:07:09 --> Helper loaded: cookie_helper
INFO - 2024-05-04 16:07:09 --> Database Driver Class Initialized
INFO - 2024-05-04 16:07:09 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-04 16:07:09 --> Parser Class Initialized
INFO - 2024-05-04 16:07:09 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-05-04 16:07:09 --> Pagination Class Initialized
INFO - 2024-05-04 16:07:09 --> Form Validation Class Initialized
INFO - 2024-05-04 16:07:09 --> Controller Class Initialized
INFO - 2024-05-04 16:07:09 --> Model Class Initialized
DEBUG - 2024-05-04 16:07:09 --> Session class already loaded. Second attempt ignored.
INFO - 2024-05-04 16:07:09 --> Model Class Initialized
DEBUG - 2024-05-04 16:07:09 --> Session class already loaded. Second attempt ignored.
INFO - 2024-05-04 16:07:09 --> Model Class Initialized
INFO - 2024-05-04 16:07:09 --> Model Class Initialized
INFO - 2024-05-04 16:07:09 --> Model Class Initialized
INFO - 2024-05-04 16:07:09 --> Model Class Initialized
DEBUG - 2024-05-04 16:07:09 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-05-04 16:07:09 --> Session class already loaded. Second attempt ignored.
INFO - 2024-05-04 16:07:09 --> Model Class Initialized
INFO - 2024-05-04 16:07:09 --> Model Class Initialized
INFO - 2024-05-04 16:07:11 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\include/admin_home.php
DEBUG - 2024-05-04 16:07:11 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-05-04 16:07:11 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\include/top_menu.php
INFO - 2024-05-04 16:07:11 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\include/admin_loggedin_info.php
INFO - 2024-05-04 16:07:11 --> Model Class Initialized
INFO - 2024-05-04 16:07:13 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\include/admin_header.php
INFO - 2024-05-04 16:07:13 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\include/admin_footer.php
INFO - 2024-05-04 16:07:13 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\admin_html_template.php
INFO - 2024-05-04 16:07:13 --> Final output sent to browser
DEBUG - 2024-05-04 16:07:13 --> Total execution time: 4.0929
ERROR - 2024-05-04 16:07:24 --> $config['composer_autoload'] is set to TRUE but E:\xampp\htdocs\maurnaturo\application\vendor/autoload.php was not found.
INFO - 2024-05-04 16:07:24 --> Config Class Initialized
INFO - 2024-05-04 16:07:24 --> Hooks Class Initialized
DEBUG - 2024-05-04 16:07:24 --> UTF-8 Support Enabled
INFO - 2024-05-04 16:07:24 --> Utf8 Class Initialized
INFO - 2024-05-04 16:07:24 --> URI Class Initialized
INFO - 2024-05-04 16:07:24 --> Router Class Initialized
INFO - 2024-05-04 16:07:24 --> Output Class Initialized
INFO - 2024-05-04 16:07:24 --> Security Class Initialized
DEBUG - 2024-05-04 16:07:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-04 16:07:24 --> Input Class Initialized
INFO - 2024-05-04 16:07:24 --> Language Class Initialized
INFO - 2024-05-04 16:07:24 --> Loader Class Initialized
INFO - 2024-05-04 16:07:24 --> Helper loaded: url_helper
INFO - 2024-05-04 16:07:24 --> Helper loaded: file_helper
INFO - 2024-05-04 16:07:24 --> Helper loaded: html_helper
INFO - 2024-05-04 16:07:24 --> Helper loaded: text_helper
INFO - 2024-05-04 16:07:24 --> Helper loaded: form_helper
INFO - 2024-05-04 16:07:24 --> Helper loaded: lang_helper
INFO - 2024-05-04 16:07:24 --> Helper loaded: security_helper
INFO - 2024-05-04 16:07:24 --> Helper loaded: cookie_helper
INFO - 2024-05-04 16:07:24 --> Database Driver Class Initialized
INFO - 2024-05-04 16:07:24 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-04 16:07:24 --> Parser Class Initialized
INFO - 2024-05-04 16:07:24 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-05-04 16:07:24 --> Pagination Class Initialized
INFO - 2024-05-04 16:07:24 --> Form Validation Class Initialized
INFO - 2024-05-04 16:07:24 --> Controller Class Initialized
DEBUG - 2024-05-04 16:07:24 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-05-04 16:07:24 --> Session class already loaded. Second attempt ignored.
INFO - 2024-05-04 16:07:24 --> Model Class Initialized
INFO - 2024-05-04 16:07:24 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\salary/add_salary_form.php
DEBUG - 2024-05-04 16:07:24 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-05-04 16:07:24 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\include/top_menu.php
INFO - 2024-05-04 16:07:24 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\include/admin_loggedin_info.php
INFO - 2024-05-04 16:07:24 --> Model Class Initialized
INFO - 2024-05-04 16:07:24 --> Model Class Initialized
INFO - 2024-05-04 16:07:24 --> Model Class Initialized
INFO - 2024-05-04 16:07:24 --> Model Class Initialized
INFO - 2024-05-04 16:07:26 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\include/admin_header.php
INFO - 2024-05-04 16:07:26 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\include/admin_footer.php
INFO - 2024-05-04 16:07:26 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\admin_html_template.php
INFO - 2024-05-04 16:07:26 --> Final output sent to browser
DEBUG - 2024-05-04 16:07:26 --> Total execution time: 2.0503
ERROR - 2024-05-04 16:07:43 --> $config['composer_autoload'] is set to TRUE but E:\xampp\htdocs\maurnaturo\application\vendor/autoload.php was not found.
INFO - 2024-05-04 16:07:43 --> Config Class Initialized
INFO - 2024-05-04 16:07:43 --> Hooks Class Initialized
DEBUG - 2024-05-04 16:07:43 --> UTF-8 Support Enabled
INFO - 2024-05-04 16:07:43 --> Utf8 Class Initialized
INFO - 2024-05-04 16:07:43 --> URI Class Initialized
INFO - 2024-05-04 16:07:43 --> Router Class Initialized
INFO - 2024-05-04 16:07:43 --> Output Class Initialized
INFO - 2024-05-04 16:07:43 --> Security Class Initialized
DEBUG - 2024-05-04 16:07:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-04 16:07:43 --> Input Class Initialized
INFO - 2024-05-04 16:07:43 --> Language Class Initialized
INFO - 2024-05-04 16:07:43 --> Loader Class Initialized
INFO - 2024-05-04 16:07:43 --> Helper loaded: url_helper
INFO - 2024-05-04 16:07:43 --> Helper loaded: file_helper
INFO - 2024-05-04 16:07:43 --> Helper loaded: html_helper
INFO - 2024-05-04 16:07:43 --> Helper loaded: text_helper
INFO - 2024-05-04 16:07:43 --> Helper loaded: form_helper
INFO - 2024-05-04 16:07:43 --> Helper loaded: lang_helper
INFO - 2024-05-04 16:07:43 --> Helper loaded: security_helper
INFO - 2024-05-04 16:07:43 --> Helper loaded: cookie_helper
INFO - 2024-05-04 16:07:43 --> Database Driver Class Initialized
INFO - 2024-05-04 16:07:43 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-04 16:07:43 --> Parser Class Initialized
INFO - 2024-05-04 16:07:43 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-05-04 16:07:43 --> Pagination Class Initialized
INFO - 2024-05-04 16:07:43 --> Form Validation Class Initialized
INFO - 2024-05-04 16:07:43 --> Controller Class Initialized
DEBUG - 2024-05-04 16:07:43 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-05-04 16:07:43 --> Session class already loaded. Second attempt ignored.
INFO - 2024-05-04 16:07:43 --> Model Class Initialized
INFO - 2024-05-04 16:07:43 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\gift/add_gift_form.php
DEBUG - 2024-05-04 16:07:43 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-05-04 16:07:43 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\include/top_menu.php
INFO - 2024-05-04 16:07:43 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\include/admin_loggedin_info.php
INFO - 2024-05-04 16:07:43 --> Model Class Initialized
INFO - 2024-05-04 16:07:43 --> Model Class Initialized
INFO - 2024-05-04 16:07:43 --> Model Class Initialized
INFO - 2024-05-04 16:07:43 --> Model Class Initialized
INFO - 2024-05-04 16:07:45 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\include/admin_header.php
INFO - 2024-05-04 16:07:45 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\include/admin_footer.php
INFO - 2024-05-04 16:07:45 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\admin_html_template.php
INFO - 2024-05-04 16:07:45 --> Final output sent to browser
DEBUG - 2024-05-04 16:07:45 --> Total execution time: 1.7729
ERROR - 2024-05-04 16:07:50 --> $config['composer_autoload'] is set to TRUE but E:\xampp\htdocs\maurnaturo\application\vendor/autoload.php was not found.
INFO - 2024-05-04 16:07:50 --> Config Class Initialized
INFO - 2024-05-04 16:07:50 --> Hooks Class Initialized
DEBUG - 2024-05-04 16:07:50 --> UTF-8 Support Enabled
INFO - 2024-05-04 16:07:50 --> Utf8 Class Initialized
INFO - 2024-05-04 16:07:50 --> URI Class Initialized
INFO - 2024-05-04 16:07:50 --> Router Class Initialized
INFO - 2024-05-04 16:07:50 --> Output Class Initialized
INFO - 2024-05-04 16:07:50 --> Security Class Initialized
DEBUG - 2024-05-04 16:07:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-04 16:07:50 --> Input Class Initialized
INFO - 2024-05-04 16:07:50 --> Language Class Initialized
INFO - 2024-05-04 16:07:50 --> Loader Class Initialized
INFO - 2024-05-04 16:07:50 --> Helper loaded: url_helper
INFO - 2024-05-04 16:07:50 --> Helper loaded: file_helper
INFO - 2024-05-04 16:07:50 --> Helper loaded: html_helper
INFO - 2024-05-04 16:07:50 --> Helper loaded: text_helper
INFO - 2024-05-04 16:07:50 --> Helper loaded: form_helper
INFO - 2024-05-04 16:07:50 --> Helper loaded: lang_helper
INFO - 2024-05-04 16:07:50 --> Helper loaded: security_helper
INFO - 2024-05-04 16:07:50 --> Helper loaded: cookie_helper
INFO - 2024-05-04 16:07:50 --> Database Driver Class Initialized
INFO - 2024-05-04 16:07:50 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-04 16:07:50 --> Parser Class Initialized
INFO - 2024-05-04 16:07:50 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-05-04 16:07:50 --> Pagination Class Initialized
INFO - 2024-05-04 16:07:50 --> Form Validation Class Initialized
INFO - 2024-05-04 16:07:50 --> Controller Class Initialized
DEBUG - 2024-05-04 16:07:50 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-05-04 16:07:50 --> Session class already loaded. Second attempt ignored.
INFO - 2024-05-04 16:07:50 --> Model Class Initialized
DEBUG - 2024-05-04 16:07:50 --> Lgift class already loaded. Second attempt ignored.
INFO - 2024-05-04 16:07:50 --> Model Class Initialized
DEBUG - 2024-05-04 16:07:50 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-05-04 16:07:50 --> Session class already loaded. Second attempt ignored.
INFO - 2024-05-04 16:07:50 --> Model Class Initialized
DEBUG - 2024-05-04 16:07:50 --> Session class already loaded. Second attempt ignored.
INFO - 2024-05-04 16:07:50 --> Model Class Initialized
INFO - 2024-05-04 16:07:50 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\gift/gift_request.php
DEBUG - 2024-05-04 16:07:50 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-05-04 16:07:50 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\include/top_menu.php
INFO - 2024-05-04 16:07:50 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\include/admin_loggedin_info.php
INFO - 2024-05-04 16:07:50 --> Model Class Initialized
INFO - 2024-05-04 16:07:51 --> Model Class Initialized
INFO - 2024-05-04 16:07:51 --> Model Class Initialized
INFO - 2024-05-04 16:07:52 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\include/admin_header.php
INFO - 2024-05-04 16:07:52 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\include/admin_footer.php
INFO - 2024-05-04 16:07:52 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\admin_html_template.php
INFO - 2024-05-04 16:07:52 --> Final output sent to browser
DEBUG - 2024-05-04 16:07:52 --> Total execution time: 1.6439
ERROR - 2024-05-04 16:07:52 --> $config['composer_autoload'] is set to TRUE but E:\xampp\htdocs\maurnaturo\application\vendor/autoload.php was not found.
INFO - 2024-05-04 16:07:52 --> Config Class Initialized
INFO - 2024-05-04 16:07:52 --> Hooks Class Initialized
DEBUG - 2024-05-04 16:07:52 --> UTF-8 Support Enabled
INFO - 2024-05-04 16:07:52 --> Utf8 Class Initialized
INFO - 2024-05-04 16:07:52 --> URI Class Initialized
INFO - 2024-05-04 16:07:52 --> Router Class Initialized
INFO - 2024-05-04 16:07:52 --> Output Class Initialized
INFO - 2024-05-04 16:07:52 --> Security Class Initialized
DEBUG - 2024-05-04 16:07:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-04 16:07:52 --> Input Class Initialized
INFO - 2024-05-04 16:07:52 --> Language Class Initialized
INFO - 2024-05-04 16:07:52 --> Loader Class Initialized
INFO - 2024-05-04 16:07:52 --> Helper loaded: url_helper
INFO - 2024-05-04 16:07:52 --> Helper loaded: file_helper
INFO - 2024-05-04 16:07:52 --> Helper loaded: html_helper
INFO - 2024-05-04 16:07:52 --> Helper loaded: text_helper
INFO - 2024-05-04 16:07:52 --> Helper loaded: form_helper
INFO - 2024-05-04 16:07:52 --> Helper loaded: lang_helper
INFO - 2024-05-04 16:07:52 --> Helper loaded: security_helper
INFO - 2024-05-04 16:07:52 --> Helper loaded: cookie_helper
INFO - 2024-05-04 16:07:52 --> Database Driver Class Initialized
INFO - 2024-05-04 16:07:52 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-04 16:07:52 --> Parser Class Initialized
INFO - 2024-05-04 16:07:52 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-05-04 16:07:52 --> Pagination Class Initialized
INFO - 2024-05-04 16:07:52 --> Form Validation Class Initialized
INFO - 2024-05-04 16:07:52 --> Controller Class Initialized
DEBUG - 2024-05-04 16:07:52 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-05-04 16:07:52 --> Session class already loaded. Second attempt ignored.
INFO - 2024-05-04 16:07:52 --> Model Class Initialized
INFO - 2024-05-04 16:07:52 --> Final output sent to browser
DEBUG - 2024-05-04 16:07:52 --> Total execution time: 0.1725
ERROR - 2024-05-04 16:07:59 --> $config['composer_autoload'] is set to TRUE but E:\xampp\htdocs\maurnaturo\application\vendor/autoload.php was not found.
INFO - 2024-05-04 16:07:59 --> Config Class Initialized
INFO - 2024-05-04 16:07:59 --> Hooks Class Initialized
DEBUG - 2024-05-04 16:07:59 --> UTF-8 Support Enabled
INFO - 2024-05-04 16:07:59 --> Utf8 Class Initialized
INFO - 2024-05-04 16:07:59 --> URI Class Initialized
INFO - 2024-05-04 16:07:59 --> Router Class Initialized
INFO - 2024-05-04 16:08:00 --> Output Class Initialized
INFO - 2024-05-04 16:08:00 --> Security Class Initialized
DEBUG - 2024-05-04 16:08:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-04 16:08:00 --> Input Class Initialized
INFO - 2024-05-04 16:08:00 --> Language Class Initialized
INFO - 2024-05-04 16:08:00 --> Loader Class Initialized
INFO - 2024-05-04 16:08:00 --> Helper loaded: url_helper
INFO - 2024-05-04 16:08:00 --> Helper loaded: file_helper
INFO - 2024-05-04 16:08:00 --> Helper loaded: html_helper
INFO - 2024-05-04 16:08:00 --> Helper loaded: text_helper
INFO - 2024-05-04 16:08:00 --> Helper loaded: form_helper
INFO - 2024-05-04 16:08:00 --> Helper loaded: lang_helper
INFO - 2024-05-04 16:08:00 --> Helper loaded: security_helper
INFO - 2024-05-04 16:08:00 --> Helper loaded: cookie_helper
INFO - 2024-05-04 16:08:00 --> Database Driver Class Initialized
INFO - 2024-05-04 16:08:00 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-04 16:08:00 --> Parser Class Initialized
INFO - 2024-05-04 16:08:00 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-05-04 16:08:00 --> Pagination Class Initialized
INFO - 2024-05-04 16:08:00 --> Form Validation Class Initialized
INFO - 2024-05-04 16:08:00 --> Controller Class Initialized
DEBUG - 2024-05-04 16:08:00 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-05-04 16:08:00 --> Session class already loaded. Second attempt ignored.
INFO - 2024-05-04 16:08:00 --> Model Class Initialized
INFO - 2024-05-04 16:08:00 --> Model Class Initialized
DEBUG - 2024-05-04 16:08:00 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-05-04 16:08:00 --> Session class already loaded. Second attempt ignored.
INFO - 2024-05-04 16:08:00 --> Model Class Initialized
DEBUG - 2024-05-04 16:08:00 --> Session class already loaded. Second attempt ignored.
INFO - 2024-05-04 16:08:00 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\gst/list.php
DEBUG - 2024-05-04 16:08:00 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-05-04 16:08:00 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\include/top_menu.php
INFO - 2024-05-04 16:08:00 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\include/admin_loggedin_info.php
INFO - 2024-05-04 16:08:00 --> Model Class Initialized
INFO - 2024-05-04 16:08:00 --> Model Class Initialized
INFO - 2024-05-04 16:08:00 --> Model Class Initialized
INFO - 2024-05-04 16:08:01 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\include/admin_header.php
INFO - 2024-05-04 16:08:01 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\include/admin_footer.php
INFO - 2024-05-04 16:08:01 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\admin_html_template.php
INFO - 2024-05-04 16:08:01 --> Final output sent to browser
DEBUG - 2024-05-04 16:08:01 --> Total execution time: 1.6056
ERROR - 2024-05-04 16:08:19 --> $config['composer_autoload'] is set to TRUE but E:\xampp\htdocs\maurnaturo\application\vendor/autoload.php was not found.
INFO - 2024-05-04 16:08:19 --> Config Class Initialized
INFO - 2024-05-04 16:08:19 --> Hooks Class Initialized
DEBUG - 2024-05-04 16:08:19 --> UTF-8 Support Enabled
INFO - 2024-05-04 16:08:19 --> Utf8 Class Initialized
INFO - 2024-05-04 16:08:19 --> URI Class Initialized
INFO - 2024-05-04 16:08:19 --> Router Class Initialized
INFO - 2024-05-04 16:08:19 --> Output Class Initialized
INFO - 2024-05-04 16:08:19 --> Security Class Initialized
DEBUG - 2024-05-04 16:08:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-04 16:08:19 --> Input Class Initialized
INFO - 2024-05-04 16:08:19 --> Language Class Initialized
INFO - 2024-05-04 16:08:19 --> Loader Class Initialized
INFO - 2024-05-04 16:08:19 --> Helper loaded: url_helper
INFO - 2024-05-04 16:08:19 --> Helper loaded: file_helper
INFO - 2024-05-04 16:08:19 --> Helper loaded: html_helper
INFO - 2024-05-04 16:08:19 --> Helper loaded: text_helper
INFO - 2024-05-04 16:08:19 --> Helper loaded: form_helper
INFO - 2024-05-04 16:08:19 --> Helper loaded: lang_helper
INFO - 2024-05-04 16:08:19 --> Helper loaded: security_helper
INFO - 2024-05-04 16:08:19 --> Helper loaded: cookie_helper
INFO - 2024-05-04 16:08:19 --> Database Driver Class Initialized
INFO - 2024-05-04 16:08:19 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-04 16:08:19 --> Parser Class Initialized
INFO - 2024-05-04 16:08:19 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-05-04 16:08:19 --> Pagination Class Initialized
INFO - 2024-05-04 16:08:19 --> Form Validation Class Initialized
INFO - 2024-05-04 16:08:19 --> Controller Class Initialized
DEBUG - 2024-05-04 16:08:19 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-05-04 16:08:19 --> Session class already loaded. Second attempt ignored.
INFO - 2024-05-04 16:08:19 --> Model Class Initialized
INFO - 2024-05-04 16:08:19 --> Model Class Initialized
INFO - 2024-05-04 16:08:19 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\manufacturer/add_manufacturer_form.php
DEBUG - 2024-05-04 16:08:19 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-05-04 16:08:19 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\include/top_menu.php
INFO - 2024-05-04 16:08:19 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\include/admin_loggedin_info.php
INFO - 2024-05-04 16:08:19 --> Model Class Initialized
INFO - 2024-05-04 16:08:19 --> Model Class Initialized
INFO - 2024-05-04 16:08:19 --> Model Class Initialized
INFO - 2024-05-04 16:08:19 --> Model Class Initialized
INFO - 2024-05-04 16:08:21 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\include/admin_header.php
INFO - 2024-05-04 16:08:21 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\include/admin_footer.php
INFO - 2024-05-04 16:08:21 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\admin_html_template.php
INFO - 2024-05-04 16:08:21 --> Final output sent to browser
DEBUG - 2024-05-04 16:08:21 --> Total execution time: 1.7473
ERROR - 2024-05-04 16:08:36 --> $config['composer_autoload'] is set to TRUE but E:\xampp\htdocs\maurnaturo\application\vendor/autoload.php was not found.
INFO - 2024-05-04 16:08:36 --> Config Class Initialized
INFO - 2024-05-04 16:08:36 --> Hooks Class Initialized
DEBUG - 2024-05-04 16:08:36 --> UTF-8 Support Enabled
INFO - 2024-05-04 16:08:36 --> Utf8 Class Initialized
INFO - 2024-05-04 16:08:36 --> URI Class Initialized
INFO - 2024-05-04 16:08:36 --> Router Class Initialized
INFO - 2024-05-04 16:08:36 --> Output Class Initialized
INFO - 2024-05-04 16:08:36 --> Security Class Initialized
DEBUG - 2024-05-04 16:08:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-04 16:08:36 --> Input Class Initialized
INFO - 2024-05-04 16:08:36 --> Language Class Initialized
INFO - 2024-05-04 16:08:36 --> Loader Class Initialized
INFO - 2024-05-04 16:08:36 --> Helper loaded: url_helper
INFO - 2024-05-04 16:08:36 --> Helper loaded: file_helper
INFO - 2024-05-04 16:08:36 --> Helper loaded: html_helper
INFO - 2024-05-04 16:08:36 --> Helper loaded: text_helper
INFO - 2024-05-04 16:08:36 --> Helper loaded: form_helper
INFO - 2024-05-04 16:08:36 --> Helper loaded: lang_helper
INFO - 2024-05-04 16:08:36 --> Helper loaded: security_helper
INFO - 2024-05-04 16:08:36 --> Helper loaded: cookie_helper
INFO - 2024-05-04 16:08:36 --> Database Driver Class Initialized
INFO - 2024-05-04 16:08:36 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-04 16:08:36 --> Parser Class Initialized
INFO - 2024-05-04 16:08:36 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-05-04 16:08:36 --> Pagination Class Initialized
INFO - 2024-05-04 16:08:36 --> Form Validation Class Initialized
INFO - 2024-05-04 16:08:36 --> Controller Class Initialized
DEBUG - 2024-05-04 16:08:36 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-05-04 16:08:36 --> Session class already loaded. Second attempt ignored.
INFO - 2024-05-04 16:08:36 --> Model Class Initialized
DEBUG - 2024-05-04 16:08:36 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-05-04 16:08:36 --> Session class already loaded. Second attempt ignored.
INFO - 2024-05-04 16:08:37 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\target/add_form.php
DEBUG - 2024-05-04 16:08:37 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-05-04 16:08:37 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\include/top_menu.php
INFO - 2024-05-04 16:08:37 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\include/admin_loggedin_info.php
INFO - 2024-05-04 16:08:37 --> Model Class Initialized
INFO - 2024-05-04 16:08:37 --> Model Class Initialized
INFO - 2024-05-04 16:08:37 --> Model Class Initialized
INFO - 2024-05-04 16:08:37 --> Model Class Initialized
INFO - 2024-05-04 16:08:38 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\include/admin_header.php
INFO - 2024-05-04 16:08:38 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\include/admin_footer.php
INFO - 2024-05-04 16:08:38 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\admin_html_template.php
INFO - 2024-05-04 16:08:38 --> Final output sent to browser
DEBUG - 2024-05-04 16:08:38 --> Total execution time: 1.8060
ERROR - 2024-05-04 16:15:53 --> $config['composer_autoload'] is set to TRUE but E:\xampp\htdocs\maurnaturo\application\vendor/autoload.php was not found.
INFO - 2024-05-04 16:15:53 --> Config Class Initialized
INFO - 2024-05-04 16:15:53 --> Hooks Class Initialized
DEBUG - 2024-05-04 16:15:53 --> UTF-8 Support Enabled
INFO - 2024-05-04 16:15:53 --> Utf8 Class Initialized
INFO - 2024-05-04 16:15:53 --> URI Class Initialized
INFO - 2024-05-04 16:15:53 --> Router Class Initialized
INFO - 2024-05-04 16:15:53 --> Output Class Initialized
INFO - 2024-05-04 16:15:53 --> Security Class Initialized
DEBUG - 2024-05-04 16:15:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-04 16:15:53 --> Input Class Initialized
INFO - 2024-05-04 16:15:53 --> Language Class Initialized
INFO - 2024-05-04 16:15:53 --> Loader Class Initialized
INFO - 2024-05-04 16:15:53 --> Helper loaded: url_helper
INFO - 2024-05-04 16:15:53 --> Helper loaded: file_helper
INFO - 2024-05-04 16:15:53 --> Helper loaded: html_helper
INFO - 2024-05-04 16:15:53 --> Helper loaded: text_helper
INFO - 2024-05-04 16:15:53 --> Helper loaded: form_helper
INFO - 2024-05-04 16:15:53 --> Helper loaded: lang_helper
INFO - 2024-05-04 16:15:53 --> Helper loaded: security_helper
INFO - 2024-05-04 16:15:53 --> Helper loaded: cookie_helper
INFO - 2024-05-04 16:15:53 --> Database Driver Class Initialized
INFO - 2024-05-04 16:15:53 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-04 16:15:53 --> Parser Class Initialized
INFO - 2024-05-04 16:15:53 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-05-04 16:15:53 --> Pagination Class Initialized
INFO - 2024-05-04 16:15:53 --> Form Validation Class Initialized
INFO - 2024-05-04 16:15:53 --> Controller Class Initialized
DEBUG - 2024-05-04 16:15:53 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-05-04 16:15:53 --> Session class already loaded. Second attempt ignored.
INFO - 2024-05-04 16:15:53 --> Model Class Initialized
INFO - 2024-05-04 16:15:53 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\salary/add_salary_form.php
DEBUG - 2024-05-04 16:15:53 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-05-04 16:15:53 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\include/top_menu.php
INFO - 2024-05-04 16:15:53 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\include/admin_loggedin_info.php
INFO - 2024-05-04 16:15:53 --> Model Class Initialized
INFO - 2024-05-04 16:15:53 --> Model Class Initialized
INFO - 2024-05-04 16:15:53 --> Model Class Initialized
INFO - 2024-05-04 16:15:53 --> Model Class Initialized
INFO - 2024-05-04 16:15:55 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\include/admin_header.php
INFO - 2024-05-04 16:15:55 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\include/admin_footer.php
INFO - 2024-05-04 16:15:55 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\admin_html_template.php
INFO - 2024-05-04 16:15:55 --> Final output sent to browser
DEBUG - 2024-05-04 16:15:55 --> Total execution time: 1.9139
ERROR - 2024-05-04 16:16:25 --> $config['composer_autoload'] is set to TRUE but E:\xampp\htdocs\maurnaturo\application\vendor/autoload.php was not found.
INFO - 2024-05-04 16:16:25 --> Config Class Initialized
INFO - 2024-05-04 16:16:25 --> Hooks Class Initialized
DEBUG - 2024-05-04 16:16:25 --> UTF-8 Support Enabled
INFO - 2024-05-04 16:16:25 --> Utf8 Class Initialized
INFO - 2024-05-04 16:16:25 --> URI Class Initialized
INFO - 2024-05-04 16:16:25 --> Router Class Initialized
INFO - 2024-05-04 16:16:25 --> Output Class Initialized
INFO - 2024-05-04 16:16:25 --> Security Class Initialized
DEBUG - 2024-05-04 16:16:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-04 16:16:25 --> Input Class Initialized
INFO - 2024-05-04 16:16:25 --> Language Class Initialized
INFO - 2024-05-04 16:16:25 --> Loader Class Initialized
INFO - 2024-05-04 16:16:25 --> Helper loaded: url_helper
INFO - 2024-05-04 16:16:25 --> Helper loaded: file_helper
INFO - 2024-05-04 16:16:25 --> Helper loaded: html_helper
INFO - 2024-05-04 16:16:25 --> Helper loaded: text_helper
INFO - 2024-05-04 16:16:25 --> Helper loaded: form_helper
INFO - 2024-05-04 16:16:25 --> Helper loaded: lang_helper
INFO - 2024-05-04 16:16:25 --> Helper loaded: security_helper
INFO - 2024-05-04 16:16:25 --> Helper loaded: cookie_helper
INFO - 2024-05-04 16:16:25 --> Database Driver Class Initialized
INFO - 2024-05-04 16:16:25 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-04 16:16:25 --> Parser Class Initialized
INFO - 2024-05-04 16:16:25 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-05-04 16:16:25 --> Pagination Class Initialized
INFO - 2024-05-04 16:16:25 --> Form Validation Class Initialized
INFO - 2024-05-04 16:16:25 --> Controller Class Initialized
DEBUG - 2024-05-04 16:16:25 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-05-04 16:16:25 --> Session class already loaded. Second attempt ignored.
INFO - 2024-05-04 16:16:25 --> Model Class Initialized
INFO - 2024-05-04 16:16:25 --> Final output sent to browser
DEBUG - 2024-05-04 16:16:25 --> Total execution time: 0.1000
ERROR - 2024-05-04 16:17:07 --> $config['composer_autoload'] is set to TRUE but E:\xampp\htdocs\maurnaturo\application\vendor/autoload.php was not found.
INFO - 2024-05-04 16:17:07 --> Config Class Initialized
INFO - 2024-05-04 16:17:07 --> Hooks Class Initialized
DEBUG - 2024-05-04 16:17:07 --> UTF-8 Support Enabled
INFO - 2024-05-04 16:17:07 --> Utf8 Class Initialized
INFO - 2024-05-04 16:17:07 --> URI Class Initialized
INFO - 2024-05-04 16:17:07 --> Router Class Initialized
INFO - 2024-05-04 16:17:07 --> Output Class Initialized
INFO - 2024-05-04 16:17:07 --> Security Class Initialized
DEBUG - 2024-05-04 16:17:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-04 16:17:07 --> Input Class Initialized
INFO - 2024-05-04 16:17:07 --> Language Class Initialized
INFO - 2024-05-04 16:17:07 --> Loader Class Initialized
INFO - 2024-05-04 16:17:07 --> Helper loaded: url_helper
INFO - 2024-05-04 16:17:07 --> Helper loaded: file_helper
INFO - 2024-05-04 16:17:07 --> Helper loaded: html_helper
INFO - 2024-05-04 16:17:07 --> Helper loaded: text_helper
INFO - 2024-05-04 16:17:07 --> Helper loaded: form_helper
INFO - 2024-05-04 16:17:07 --> Helper loaded: lang_helper
INFO - 2024-05-04 16:17:07 --> Helper loaded: security_helper
INFO - 2024-05-04 16:17:07 --> Helper loaded: cookie_helper
INFO - 2024-05-04 16:17:07 --> Database Driver Class Initialized
INFO - 2024-05-04 16:17:07 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-04 16:17:07 --> Parser Class Initialized
INFO - 2024-05-04 16:17:07 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-05-04 16:17:07 --> Pagination Class Initialized
INFO - 2024-05-04 16:17:07 --> Form Validation Class Initialized
INFO - 2024-05-04 16:17:07 --> Controller Class Initialized
DEBUG - 2024-05-04 16:17:07 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-05-04 16:17:07 --> Session class already loaded. Second attempt ignored.
INFO - 2024-05-04 16:17:07 --> Model Class Initialized
INFO - 2024-05-04 16:17:07 --> Final output sent to browser
DEBUG - 2024-05-04 16:17:07 --> Total execution time: 0.1138
ERROR - 2024-05-04 16:17:40 --> $config['composer_autoload'] is set to TRUE but E:\xampp\htdocs\maurnaturo\application\vendor/autoload.php was not found.
INFO - 2024-05-04 16:17:40 --> Config Class Initialized
INFO - 2024-05-04 16:17:40 --> Hooks Class Initialized
DEBUG - 2024-05-04 16:17:40 --> UTF-8 Support Enabled
INFO - 2024-05-04 16:17:40 --> Utf8 Class Initialized
INFO - 2024-05-04 16:17:40 --> URI Class Initialized
INFO - 2024-05-04 16:17:40 --> Router Class Initialized
INFO - 2024-05-04 16:17:40 --> Output Class Initialized
INFO - 2024-05-04 16:17:40 --> Security Class Initialized
DEBUG - 2024-05-04 16:17:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-04 16:17:40 --> Input Class Initialized
INFO - 2024-05-04 16:17:40 --> Language Class Initialized
INFO - 2024-05-04 16:17:40 --> Loader Class Initialized
INFO - 2024-05-04 16:17:40 --> Helper loaded: url_helper
INFO - 2024-05-04 16:17:40 --> Helper loaded: file_helper
INFO - 2024-05-04 16:17:40 --> Helper loaded: html_helper
INFO - 2024-05-04 16:17:40 --> Helper loaded: text_helper
INFO - 2024-05-04 16:17:40 --> Helper loaded: form_helper
INFO - 2024-05-04 16:17:40 --> Helper loaded: lang_helper
INFO - 2024-05-04 16:17:40 --> Helper loaded: security_helper
INFO - 2024-05-04 16:17:40 --> Helper loaded: cookie_helper
INFO - 2024-05-04 16:17:40 --> Database Driver Class Initialized
INFO - 2024-05-04 16:17:40 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-04 16:17:40 --> Parser Class Initialized
INFO - 2024-05-04 16:17:40 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-05-04 16:17:40 --> Pagination Class Initialized
INFO - 2024-05-04 16:17:40 --> Form Validation Class Initialized
INFO - 2024-05-04 16:17:40 --> Controller Class Initialized
DEBUG - 2024-05-04 16:17:40 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-05-04 16:17:40 --> Session class already loaded. Second attempt ignored.
INFO - 2024-05-04 16:17:40 --> Model Class Initialized
INFO - 2024-05-04 16:17:40 --> Final output sent to browser
DEBUG - 2024-05-04 16:17:40 --> Total execution time: 0.1078
