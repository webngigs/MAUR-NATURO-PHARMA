<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2024-05-18 15:57:26 --> $config['composer_autoload'] is set to TRUE but E:\xampp\htdocs\maurnaturo\application\vendor/autoload.php was not found.
INFO - 2024-05-18 15:57:26 --> Config Class Initialized
INFO - 2024-05-18 15:57:26 --> Hooks Class Initialized
DEBUG - 2024-05-18 15:57:26 --> UTF-8 Support Enabled
INFO - 2024-05-18 15:57:26 --> Utf8 Class Initialized
INFO - 2024-05-18 15:57:26 --> URI Class Initialized
DEBUG - 2024-05-18 15:57:26 --> No URI present. Default controller set.
INFO - 2024-05-18 15:57:26 --> Router Class Initialized
INFO - 2024-05-18 15:57:26 --> Output Class Initialized
INFO - 2024-05-18 15:57:26 --> Security Class Initialized
DEBUG - 2024-05-18 15:57:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-18 15:57:26 --> Input Class Initialized
INFO - 2024-05-18 15:57:26 --> Language Class Initialized
INFO - 2024-05-18 15:57:26 --> Loader Class Initialized
INFO - 2024-05-18 15:57:26 --> Helper loaded: url_helper
INFO - 2024-05-18 15:57:26 --> Helper loaded: file_helper
INFO - 2024-05-18 15:57:26 --> Helper loaded: html_helper
INFO - 2024-05-18 15:57:26 --> Helper loaded: text_helper
INFO - 2024-05-18 15:57:26 --> Helper loaded: form_helper
INFO - 2024-05-18 15:57:26 --> Helper loaded: lang_helper
INFO - 2024-05-18 15:57:26 --> Helper loaded: security_helper
INFO - 2024-05-18 15:57:26 --> Helper loaded: cookie_helper
INFO - 2024-05-18 15:57:26 --> Database Driver Class Initialized
INFO - 2024-05-18 15:57:26 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-18 15:57:26 --> Parser Class Initialized
INFO - 2024-05-18 15:57:26 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-05-18 15:57:26 --> Pagination Class Initialized
INFO - 2024-05-18 15:57:26 --> Form Validation Class Initialized
INFO - 2024-05-18 15:57:26 --> Controller Class Initialized
INFO - 2024-05-18 15:57:26 --> Model Class Initialized
DEBUG - 2024-05-18 15:57:26 --> Session class already loaded. Second attempt ignored.
ERROR - 2024-05-18 15:57:26 --> $config['composer_autoload'] is set to TRUE but E:\xampp\htdocs\maurnaturo\application\vendor/autoload.php was not found.
INFO - 2024-05-18 15:57:26 --> Config Class Initialized
INFO - 2024-05-18 15:57:26 --> Hooks Class Initialized
DEBUG - 2024-05-18 15:57:26 --> UTF-8 Support Enabled
INFO - 2024-05-18 15:57:26 --> Utf8 Class Initialized
INFO - 2024-05-18 15:57:26 --> URI Class Initialized
INFO - 2024-05-18 15:57:26 --> Router Class Initialized
INFO - 2024-05-18 15:57:26 --> Output Class Initialized
INFO - 2024-05-18 15:57:26 --> Security Class Initialized
DEBUG - 2024-05-18 15:57:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-18 15:57:26 --> Input Class Initialized
INFO - 2024-05-18 15:57:26 --> Language Class Initialized
INFO - 2024-05-18 15:57:26 --> Loader Class Initialized
INFO - 2024-05-18 15:57:26 --> Helper loaded: url_helper
INFO - 2024-05-18 15:57:26 --> Helper loaded: file_helper
INFO - 2024-05-18 15:57:26 --> Helper loaded: html_helper
INFO - 2024-05-18 15:57:26 --> Helper loaded: text_helper
INFO - 2024-05-18 15:57:26 --> Helper loaded: form_helper
INFO - 2024-05-18 15:57:26 --> Helper loaded: lang_helper
INFO - 2024-05-18 15:57:26 --> Helper loaded: security_helper
INFO - 2024-05-18 15:57:26 --> Helper loaded: cookie_helper
INFO - 2024-05-18 15:57:26 --> Database Driver Class Initialized
INFO - 2024-05-18 15:57:26 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-18 15:57:26 --> Parser Class Initialized
INFO - 2024-05-18 15:57:26 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-05-18 15:57:26 --> Pagination Class Initialized
INFO - 2024-05-18 15:57:26 --> Form Validation Class Initialized
INFO - 2024-05-18 15:57:26 --> Controller Class Initialized
INFO - 2024-05-18 15:57:26 --> Model Class Initialized
DEBUG - 2024-05-18 15:57:26 --> Session class already loaded. Second attempt ignored.
INFO - 2024-05-18 15:57:26 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\user/admin_login_form.php
DEBUG - 2024-05-18 15:57:26 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-05-18 15:57:26 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\include/top_menu.php
INFO - 2024-05-18 15:57:26 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\include/admin_loggedin_info.php
INFO - 2024-05-18 15:57:26 --> Model Class Initialized
INFO - 2024-05-18 15:57:26 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\admin_html_template.php
INFO - 2024-05-18 15:57:26 --> Final output sent to browser
DEBUG - 2024-05-18 15:57:26 --> Total execution time: 0.1060
ERROR - 2024-05-18 15:57:29 --> $config['composer_autoload'] is set to TRUE but E:\xampp\htdocs\maurnaturo\application\vendor/autoload.php was not found.
INFO - 2024-05-18 15:57:29 --> Config Class Initialized
INFO - 2024-05-18 15:57:29 --> Hooks Class Initialized
DEBUG - 2024-05-18 15:57:29 --> UTF-8 Support Enabled
INFO - 2024-05-18 15:57:29 --> Utf8 Class Initialized
INFO - 2024-05-18 15:57:29 --> URI Class Initialized
INFO - 2024-05-18 15:57:29 --> Router Class Initialized
INFO - 2024-05-18 15:57:29 --> Output Class Initialized
INFO - 2024-05-18 15:57:29 --> Security Class Initialized
DEBUG - 2024-05-18 15:57:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-18 15:57:29 --> Input Class Initialized
INFO - 2024-05-18 15:57:29 --> Language Class Initialized
INFO - 2024-05-18 15:57:29 --> Loader Class Initialized
INFO - 2024-05-18 15:57:29 --> Helper loaded: url_helper
INFO - 2024-05-18 15:57:29 --> Helper loaded: file_helper
INFO - 2024-05-18 15:57:29 --> Helper loaded: html_helper
INFO - 2024-05-18 15:57:29 --> Helper loaded: text_helper
INFO - 2024-05-18 15:57:29 --> Helper loaded: form_helper
INFO - 2024-05-18 15:57:29 --> Helper loaded: lang_helper
INFO - 2024-05-18 15:57:29 --> Helper loaded: security_helper
INFO - 2024-05-18 15:57:29 --> Helper loaded: cookie_helper
INFO - 2024-05-18 15:57:29 --> Database Driver Class Initialized
INFO - 2024-05-18 15:57:29 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-18 15:57:29 --> Parser Class Initialized
INFO - 2024-05-18 15:57:30 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-05-18 15:57:30 --> Pagination Class Initialized
INFO - 2024-05-18 15:57:30 --> Form Validation Class Initialized
INFO - 2024-05-18 15:57:30 --> Controller Class Initialized
INFO - 2024-05-18 15:57:30 --> Model Class Initialized
DEBUG - 2024-05-18 15:57:30 --> Session class already loaded. Second attempt ignored.
INFO - 2024-05-18 15:57:30 --> Model Class Initialized
INFO - 2024-05-18 15:57:30 --> Final output sent to browser
DEBUG - 2024-05-18 15:57:30 --> Total execution time: 0.0881
ERROR - 2024-05-18 15:57:30 --> $config['composer_autoload'] is set to TRUE but E:\xampp\htdocs\maurnaturo\application\vendor/autoload.php was not found.
INFO - 2024-05-18 15:57:30 --> Config Class Initialized
INFO - 2024-05-18 15:57:30 --> Hooks Class Initialized
DEBUG - 2024-05-18 15:57:30 --> UTF-8 Support Enabled
INFO - 2024-05-18 15:57:30 --> Utf8 Class Initialized
INFO - 2024-05-18 15:57:30 --> URI Class Initialized
INFO - 2024-05-18 15:57:30 --> Router Class Initialized
INFO - 2024-05-18 15:57:30 --> Output Class Initialized
INFO - 2024-05-18 15:57:30 --> Security Class Initialized
DEBUG - 2024-05-18 15:57:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-18 15:57:30 --> Input Class Initialized
INFO - 2024-05-18 15:57:30 --> Language Class Initialized
INFO - 2024-05-18 15:57:30 --> Loader Class Initialized
INFO - 2024-05-18 15:57:30 --> Helper loaded: url_helper
INFO - 2024-05-18 15:57:30 --> Helper loaded: file_helper
INFO - 2024-05-18 15:57:30 --> Helper loaded: html_helper
INFO - 2024-05-18 15:57:30 --> Helper loaded: text_helper
INFO - 2024-05-18 15:57:30 --> Helper loaded: form_helper
INFO - 2024-05-18 15:57:30 --> Helper loaded: lang_helper
INFO - 2024-05-18 15:57:30 --> Helper loaded: security_helper
INFO - 2024-05-18 15:57:30 --> Helper loaded: cookie_helper
INFO - 2024-05-18 15:57:30 --> Database Driver Class Initialized
INFO - 2024-05-18 15:57:30 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-18 15:57:30 --> Parser Class Initialized
INFO - 2024-05-18 15:57:30 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-05-18 15:57:30 --> Pagination Class Initialized
INFO - 2024-05-18 15:57:30 --> Form Validation Class Initialized
INFO - 2024-05-18 15:57:30 --> Controller Class Initialized
INFO - 2024-05-18 15:57:30 --> Model Class Initialized
DEBUG - 2024-05-18 15:57:30 --> Session class already loaded. Second attempt ignored.
INFO - 2024-05-18 15:57:30 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\user/admin_login_form.php
DEBUG - 2024-05-18 15:57:30 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-05-18 15:57:30 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\include/top_menu.php
INFO - 2024-05-18 15:57:30 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\include/admin_loggedin_info.php
INFO - 2024-05-18 15:57:30 --> Model Class Initialized
INFO - 2024-05-18 15:57:30 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\admin_html_template.php
INFO - 2024-05-18 15:57:30 --> Final output sent to browser
DEBUG - 2024-05-18 15:57:30 --> Total execution time: 0.1010
ERROR - 2024-05-18 15:57:36 --> $config['composer_autoload'] is set to TRUE but E:\xampp\htdocs\maurnaturo\application\vendor/autoload.php was not found.
INFO - 2024-05-18 15:57:36 --> Config Class Initialized
INFO - 2024-05-18 15:57:36 --> Hooks Class Initialized
DEBUG - 2024-05-18 15:57:36 --> UTF-8 Support Enabled
INFO - 2024-05-18 15:57:36 --> Utf8 Class Initialized
INFO - 2024-05-18 15:57:36 --> URI Class Initialized
INFO - 2024-05-18 15:57:36 --> Router Class Initialized
INFO - 2024-05-18 15:57:36 --> Output Class Initialized
INFO - 2024-05-18 15:57:36 --> Security Class Initialized
DEBUG - 2024-05-18 15:57:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-18 15:57:36 --> Input Class Initialized
INFO - 2024-05-18 15:57:36 --> Language Class Initialized
INFO - 2024-05-18 15:57:36 --> Loader Class Initialized
INFO - 2024-05-18 15:57:36 --> Helper loaded: url_helper
INFO - 2024-05-18 15:57:36 --> Helper loaded: file_helper
INFO - 2024-05-18 15:57:36 --> Helper loaded: html_helper
INFO - 2024-05-18 15:57:36 --> Helper loaded: text_helper
INFO - 2024-05-18 15:57:36 --> Helper loaded: form_helper
INFO - 2024-05-18 15:57:36 --> Helper loaded: lang_helper
INFO - 2024-05-18 15:57:36 --> Helper loaded: security_helper
INFO - 2024-05-18 15:57:36 --> Helper loaded: cookie_helper
INFO - 2024-05-18 15:57:36 --> Database Driver Class Initialized
INFO - 2024-05-18 15:57:36 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-18 15:57:36 --> Parser Class Initialized
INFO - 2024-05-18 15:57:36 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-05-18 15:57:36 --> Pagination Class Initialized
INFO - 2024-05-18 15:57:36 --> Form Validation Class Initialized
INFO - 2024-05-18 15:57:36 --> Controller Class Initialized
INFO - 2024-05-18 15:57:36 --> Model Class Initialized
DEBUG - 2024-05-18 15:57:36 --> Session class already loaded. Second attempt ignored.
INFO - 2024-05-18 15:57:36 --> Model Class Initialized
INFO - 2024-05-18 15:57:36 --> Final output sent to browser
DEBUG - 2024-05-18 15:57:36 --> Total execution time: 0.0892
ERROR - 2024-05-18 15:57:36 --> $config['composer_autoload'] is set to TRUE but E:\xampp\htdocs\maurnaturo\application\vendor/autoload.php was not found.
INFO - 2024-05-18 15:57:36 --> Config Class Initialized
INFO - 2024-05-18 15:57:36 --> Hooks Class Initialized
DEBUG - 2024-05-18 15:57:36 --> UTF-8 Support Enabled
INFO - 2024-05-18 15:57:36 --> Utf8 Class Initialized
INFO - 2024-05-18 15:57:36 --> URI Class Initialized
DEBUG - 2024-05-18 15:57:36 --> No URI present. Default controller set.
INFO - 2024-05-18 15:57:36 --> Router Class Initialized
INFO - 2024-05-18 15:57:36 --> Output Class Initialized
INFO - 2024-05-18 15:57:36 --> Security Class Initialized
DEBUG - 2024-05-18 15:57:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-18 15:57:36 --> Input Class Initialized
INFO - 2024-05-18 15:57:36 --> Language Class Initialized
INFO - 2024-05-18 15:57:36 --> Loader Class Initialized
INFO - 2024-05-18 15:57:36 --> Helper loaded: url_helper
INFO - 2024-05-18 15:57:36 --> Helper loaded: file_helper
INFO - 2024-05-18 15:57:36 --> Helper loaded: html_helper
INFO - 2024-05-18 15:57:36 --> Helper loaded: text_helper
INFO - 2024-05-18 15:57:36 --> Helper loaded: form_helper
INFO - 2024-05-18 15:57:36 --> Helper loaded: lang_helper
INFO - 2024-05-18 15:57:36 --> Helper loaded: security_helper
INFO - 2024-05-18 15:57:36 --> Helper loaded: cookie_helper
INFO - 2024-05-18 15:57:36 --> Database Driver Class Initialized
INFO - 2024-05-18 15:57:36 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-18 15:57:36 --> Parser Class Initialized
INFO - 2024-05-18 15:57:36 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-05-18 15:57:36 --> Pagination Class Initialized
INFO - 2024-05-18 15:57:36 --> Form Validation Class Initialized
INFO - 2024-05-18 15:57:36 --> Controller Class Initialized
INFO - 2024-05-18 15:57:36 --> Model Class Initialized
DEBUG - 2024-05-18 15:57:36 --> Session class already loaded. Second attempt ignored.
INFO - 2024-05-18 15:57:36 --> Model Class Initialized
DEBUG - 2024-05-18 15:57:36 --> Session class already loaded. Second attempt ignored.
INFO - 2024-05-18 15:57:36 --> Model Class Initialized
INFO - 2024-05-18 15:57:36 --> Model Class Initialized
INFO - 2024-05-18 15:57:36 --> Model Class Initialized
INFO - 2024-05-18 15:57:36 --> Model Class Initialized
DEBUG - 2024-05-18 15:57:36 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-05-18 15:57:36 --> Session class already loaded. Second attempt ignored.
INFO - 2024-05-18 15:57:36 --> Model Class Initialized
INFO - 2024-05-18 15:57:36 --> Model Class Initialized
INFO - 2024-05-18 15:57:38 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\include/admin_home.php
DEBUG - 2024-05-18 15:57:38 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-05-18 15:57:38 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\include/top_menu.php
INFO - 2024-05-18 15:57:38 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\include/admin_loggedin_info.php
INFO - 2024-05-18 15:57:38 --> Model Class Initialized
INFO - 2024-05-18 15:57:39 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\include/admin_header.php
INFO - 2024-05-18 15:57:39 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\include/admin_footer.php
INFO - 2024-05-18 15:57:39 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\admin_html_template.php
INFO - 2024-05-18 15:57:39 --> Final output sent to browser
DEBUG - 2024-05-18 15:57:39 --> Total execution time: 2.9943
ERROR - 2024-05-18 15:57:39 --> $config['composer_autoload'] is set to TRUE but E:\xampp\htdocs\maurnaturo\application\vendor/autoload.php was not found.
INFO - 2024-05-18 15:57:39 --> Config Class Initialized
INFO - 2024-05-18 15:57:39 --> Hooks Class Initialized
DEBUG - 2024-05-18 15:57:39 --> UTF-8 Support Enabled
INFO - 2024-05-18 15:57:39 --> Utf8 Class Initialized
INFO - 2024-05-18 15:57:39 --> URI Class Initialized
INFO - 2024-05-18 15:57:39 --> Router Class Initialized
INFO - 2024-05-18 15:57:39 --> Output Class Initialized
INFO - 2024-05-18 15:57:39 --> Security Class Initialized
DEBUG - 2024-05-18 15:57:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-18 15:57:39 --> Input Class Initialized
INFO - 2024-05-18 15:57:39 --> Language Class Initialized
INFO - 2024-05-18 15:57:39 --> Loader Class Initialized
INFO - 2024-05-18 15:57:39 --> Helper loaded: url_helper
INFO - 2024-05-18 15:57:39 --> Helper loaded: file_helper
INFO - 2024-05-18 15:57:39 --> Helper loaded: html_helper
INFO - 2024-05-18 15:57:40 --> Helper loaded: text_helper
INFO - 2024-05-18 15:57:40 --> Helper loaded: form_helper
INFO - 2024-05-18 15:57:40 --> Helper loaded: lang_helper
INFO - 2024-05-18 15:57:40 --> Helper loaded: security_helper
INFO - 2024-05-18 15:57:40 --> Helper loaded: cookie_helper
INFO - 2024-05-18 15:57:40 --> Database Driver Class Initialized
INFO - 2024-05-18 15:57:40 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-18 15:57:40 --> Parser Class Initialized
INFO - 2024-05-18 15:57:40 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-05-18 15:57:40 --> Pagination Class Initialized
INFO - 2024-05-18 15:57:40 --> Form Validation Class Initialized
INFO - 2024-05-18 15:57:40 --> Controller Class Initialized
DEBUG - 2024-05-18 15:57:40 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-05-18 15:57:40 --> Session class already loaded. Second attempt ignored.
INFO - 2024-05-18 15:57:40 --> Model Class Initialized
INFO - 2024-05-18 15:57:40 --> Final output sent to browser
DEBUG - 2024-05-18 15:57:40 --> Total execution time: 0.0827
ERROR - 2024-05-18 16:09:26 --> $config['composer_autoload'] is set to TRUE but E:\xampp\htdocs\maurnaturo\application\vendor/autoload.php was not found.
INFO - 2024-05-18 16:09:26 --> Config Class Initialized
INFO - 2024-05-18 16:09:26 --> Hooks Class Initialized
DEBUG - 2024-05-18 16:09:26 --> UTF-8 Support Enabled
INFO - 2024-05-18 16:09:26 --> Utf8 Class Initialized
INFO - 2024-05-18 16:09:26 --> URI Class Initialized
INFO - 2024-05-18 16:09:26 --> Router Class Initialized
INFO - 2024-05-18 16:09:26 --> Output Class Initialized
INFO - 2024-05-18 16:09:26 --> Security Class Initialized
DEBUG - 2024-05-18 16:09:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-18 16:09:26 --> Input Class Initialized
INFO - 2024-05-18 16:09:26 --> Language Class Initialized
INFO - 2024-05-18 16:09:26 --> Loader Class Initialized
INFO - 2024-05-18 16:09:26 --> Helper loaded: url_helper
INFO - 2024-05-18 16:09:26 --> Helper loaded: file_helper
INFO - 2024-05-18 16:09:26 --> Helper loaded: html_helper
INFO - 2024-05-18 16:09:26 --> Helper loaded: text_helper
INFO - 2024-05-18 16:09:26 --> Helper loaded: form_helper
INFO - 2024-05-18 16:09:26 --> Helper loaded: lang_helper
INFO - 2024-05-18 16:09:26 --> Helper loaded: security_helper
INFO - 2024-05-18 16:09:26 --> Helper loaded: cookie_helper
INFO - 2024-05-18 16:09:26 --> Database Driver Class Initialized
INFO - 2024-05-18 16:09:26 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-18 16:09:26 --> Parser Class Initialized
INFO - 2024-05-18 16:09:26 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-05-18 16:09:26 --> Pagination Class Initialized
INFO - 2024-05-18 16:09:26 --> Form Validation Class Initialized
INFO - 2024-05-18 16:09:26 --> Controller Class Initialized
DEBUG - 2024-05-18 16:09:26 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-05-18 16:09:26 --> Session class already loaded. Second attempt ignored.
INFO - 2024-05-18 16:09:26 --> Model Class Initialized
INFO - 2024-05-18 16:09:26 --> Model Class Initialized
DEBUG - 2024-05-18 16:09:26 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-05-18 16:09:26 --> Session class already loaded. Second attempt ignored.
INFO - 2024-05-18 16:09:26 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\expenses/add_expenses_form.php
DEBUG - 2024-05-18 16:09:26 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-05-18 16:09:26 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\include/top_menu.php
INFO - 2024-05-18 16:09:26 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\include/admin_loggedin_info.php
INFO - 2024-05-18 16:09:26 --> Model Class Initialized
INFO - 2024-05-18 16:09:26 --> Model Class Initialized
INFO - 2024-05-18 16:09:26 --> Model Class Initialized
INFO - 2024-05-18 16:09:26 --> Model Class Initialized
INFO - 2024-05-18 16:09:28 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\include/admin_header.php
INFO - 2024-05-18 16:09:28 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\include/admin_footer.php
INFO - 2024-05-18 16:09:28 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\admin_html_template.php
INFO - 2024-05-18 16:09:28 --> Final output sent to browser
DEBUG - 2024-05-18 16:09:28 --> Total execution time: 1.4734
