<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2024-05-24 00:23:10 --> $config['composer_autoload'] is set to TRUE but /home/u241458058/domains/technoprimex.com/public_html/maurnaturo/application/vendor/autoload.php was not found.
INFO - 2024-05-24 00:23:10 --> Config Class Initialized
INFO - 2024-05-24 00:23:10 --> Hooks Class Initialized
DEBUG - 2024-05-24 00:23:10 --> UTF-8 Support Enabled
INFO - 2024-05-24 00:23:10 --> Utf8 Class Initialized
INFO - 2024-05-24 00:23:10 --> URI Class Initialized
DEBUG - 2024-05-24 00:23:10 --> No URI present. Default controller set.
INFO - 2024-05-24 00:23:10 --> Router Class Initialized
INFO - 2024-05-24 00:23:10 --> Output Class Initialized
INFO - 2024-05-24 00:23:10 --> Security Class Initialized
DEBUG - 2024-05-24 00:23:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-24 00:23:10 --> Input Class Initialized
INFO - 2024-05-24 00:23:10 --> Language Class Initialized
INFO - 2024-05-24 00:23:10 --> Loader Class Initialized
INFO - 2024-05-24 00:23:10 --> Helper loaded: url_helper
INFO - 2024-05-24 00:23:10 --> Helper loaded: file_helper
INFO - 2024-05-24 00:23:10 --> Helper loaded: html_helper
INFO - 2024-05-24 00:23:10 --> Helper loaded: text_helper
INFO - 2024-05-24 00:23:10 --> Helper loaded: form_helper
INFO - 2024-05-24 00:23:10 --> Helper loaded: lang_helper
INFO - 2024-05-24 00:23:10 --> Helper loaded: security_helper
INFO - 2024-05-24 00:23:10 --> Helper loaded: cookie_helper
INFO - 2024-05-24 00:23:10 --> Database Driver Class Initialized
INFO - 2024-05-24 00:23:10 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-24 00:23:10 --> Parser Class Initialized
INFO - 2024-05-24 00:23:10 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-05-24 00:23:10 --> Pagination Class Initialized
INFO - 2024-05-24 00:23:10 --> Form Validation Class Initialized
INFO - 2024-05-24 00:23:10 --> Controller Class Initialized
INFO - 2024-05-24 00:23:10 --> Model Class Initialized
DEBUG - 2024-05-24 00:23:10 --> Session class already loaded. Second attempt ignored.
ERROR - 2024-05-24 01:14:38 --> $config['composer_autoload'] is set to TRUE but /home/u241458058/domains/technoprimex.com/public_html/maurnaturo/application/vendor/autoload.php was not found.
INFO - 2024-05-24 01:14:38 --> Config Class Initialized
INFO - 2024-05-24 01:14:38 --> Hooks Class Initialized
DEBUG - 2024-05-24 01:14:38 --> UTF-8 Support Enabled
INFO - 2024-05-24 01:14:38 --> Utf8 Class Initialized
INFO - 2024-05-24 01:14:38 --> URI Class Initialized
DEBUG - 2024-05-24 01:14:38 --> No URI present. Default controller set.
INFO - 2024-05-24 01:14:38 --> Router Class Initialized
INFO - 2024-05-24 01:14:38 --> Output Class Initialized
INFO - 2024-05-24 01:14:38 --> Security Class Initialized
DEBUG - 2024-05-24 01:14:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-24 01:14:38 --> Input Class Initialized
INFO - 2024-05-24 01:14:38 --> Language Class Initialized
INFO - 2024-05-24 01:14:38 --> Loader Class Initialized
INFO - 2024-05-24 01:14:38 --> Helper loaded: url_helper
INFO - 2024-05-24 01:14:38 --> Helper loaded: file_helper
INFO - 2024-05-24 01:14:38 --> Helper loaded: html_helper
INFO - 2024-05-24 01:14:38 --> Helper loaded: text_helper
INFO - 2024-05-24 01:14:38 --> Helper loaded: form_helper
INFO - 2024-05-24 01:14:38 --> Helper loaded: lang_helper
INFO - 2024-05-24 01:14:38 --> Helper loaded: security_helper
INFO - 2024-05-24 01:14:38 --> Helper loaded: cookie_helper
INFO - 2024-05-24 01:14:38 --> Database Driver Class Initialized
INFO - 2024-05-24 01:14:38 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-24 01:14:38 --> Parser Class Initialized
INFO - 2024-05-24 01:14:38 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-05-24 01:14:38 --> Pagination Class Initialized
INFO - 2024-05-24 01:14:38 --> Form Validation Class Initialized
INFO - 2024-05-24 01:14:38 --> Controller Class Initialized
INFO - 2024-05-24 01:14:38 --> Model Class Initialized
DEBUG - 2024-05-24 01:14:38 --> Session class already loaded. Second attempt ignored.
ERROR - 2024-05-24 05:26:50 --> $config['composer_autoload'] is set to TRUE but /home/u241458058/domains/technoprimex.com/public_html/maurnaturo/application/vendor/autoload.php was not found.
INFO - 2024-05-24 05:26:50 --> Config Class Initialized
INFO - 2024-05-24 05:26:50 --> Hooks Class Initialized
DEBUG - 2024-05-24 05:26:50 --> UTF-8 Support Enabled
INFO - 2024-05-24 05:26:50 --> Utf8 Class Initialized
INFO - 2024-05-24 05:26:50 --> URI Class Initialized
INFO - 2024-05-24 05:26:50 --> Router Class Initialized
INFO - 2024-05-24 05:26:50 --> Output Class Initialized
INFO - 2024-05-24 05:26:50 --> Security Class Initialized
DEBUG - 2024-05-24 05:26:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-24 05:26:50 --> Input Class Initialized
INFO - 2024-05-24 05:26:50 --> Language Class Initialized
INFO - 2024-05-24 05:26:50 --> Loader Class Initialized
INFO - 2024-05-24 05:26:50 --> Helper loaded: url_helper
INFO - 2024-05-24 05:26:50 --> Helper loaded: file_helper
INFO - 2024-05-24 05:26:50 --> Helper loaded: html_helper
INFO - 2024-05-24 05:26:50 --> Helper loaded: text_helper
INFO - 2024-05-24 05:26:50 --> Helper loaded: form_helper
INFO - 2024-05-24 05:26:50 --> Helper loaded: lang_helper
INFO - 2024-05-24 05:26:50 --> Helper loaded: security_helper
INFO - 2024-05-24 05:26:50 --> Helper loaded: cookie_helper
INFO - 2024-05-24 05:26:50 --> Database Driver Class Initialized
INFO - 2024-05-24 05:26:50 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-24 05:26:50 --> Parser Class Initialized
INFO - 2024-05-24 05:26:50 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-05-24 05:26:50 --> Pagination Class Initialized
INFO - 2024-05-24 05:26:50 --> Form Validation Class Initialized
INFO - 2024-05-24 05:26:50 --> Controller Class Initialized
INFO - 2024-05-24 05:26:50 --> Model Class Initialized
DEBUG - 2024-05-24 05:26:50 --> Session class already loaded. Second attempt ignored.
INFO - 2024-05-24 05:26:50 --> File loaded: /home/u241458058/domains/technoprimex.com/public_html/maurnaturo/application/views/user/admin_login_form.php
DEBUG - 2024-05-24 05:26:50 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-05-24 05:26:50 --> File loaded: /home/u241458058/domains/technoprimex.com/public_html/maurnaturo/application/views/include/top_menu.php
INFO - 2024-05-24 05:26:50 --> File loaded: /home/u241458058/domains/technoprimex.com/public_html/maurnaturo/application/views/include/admin_loggedin_info.php
INFO - 2024-05-24 05:26:50 --> Model Class Initialized
INFO - 2024-05-24 05:26:50 --> File loaded: /home/u241458058/domains/technoprimex.com/public_html/maurnaturo/application/views/admin_html_template.php
INFO - 2024-05-24 05:26:50 --> Final output sent to browser
DEBUG - 2024-05-24 05:26:50 --> Total execution time: 0.0571
ERROR - 2024-05-24 15:06:42 --> $config['composer_autoload'] is set to TRUE but /home/u241458058/domains/technoprimex.com/public_html/maurnaturo/application/vendor/autoload.php was not found.
INFO - 2024-05-24 15:06:42 --> Config Class Initialized
INFO - 2024-05-24 15:06:42 --> Hooks Class Initialized
DEBUG - 2024-05-24 15:06:42 --> UTF-8 Support Enabled
INFO - 2024-05-24 15:06:42 --> Utf8 Class Initialized
INFO - 2024-05-24 15:06:42 --> URI Class Initialized
DEBUG - 2024-05-24 15:06:42 --> No URI present. Default controller set.
INFO - 2024-05-24 15:06:42 --> Router Class Initialized
INFO - 2024-05-24 15:06:42 --> Output Class Initialized
INFO - 2024-05-24 15:06:42 --> Security Class Initialized
DEBUG - 2024-05-24 15:06:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-24 15:06:42 --> Input Class Initialized
INFO - 2024-05-24 15:06:42 --> Language Class Initialized
INFO - 2024-05-24 15:06:42 --> Loader Class Initialized
INFO - 2024-05-24 15:06:42 --> Helper loaded: url_helper
INFO - 2024-05-24 15:06:42 --> Helper loaded: file_helper
INFO - 2024-05-24 15:06:42 --> Helper loaded: html_helper
INFO - 2024-05-24 15:06:42 --> Helper loaded: text_helper
INFO - 2024-05-24 15:06:42 --> Helper loaded: form_helper
INFO - 2024-05-24 15:06:42 --> Helper loaded: lang_helper
INFO - 2024-05-24 15:06:42 --> Helper loaded: security_helper
INFO - 2024-05-24 15:06:42 --> Helper loaded: cookie_helper
INFO - 2024-05-24 15:06:42 --> Database Driver Class Initialized
INFO - 2024-05-24 15:06:42 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-24 15:06:42 --> Parser Class Initialized
INFO - 2024-05-24 15:06:42 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-05-24 15:06:42 --> Pagination Class Initialized
INFO - 2024-05-24 15:06:42 --> Form Validation Class Initialized
INFO - 2024-05-24 15:06:42 --> Controller Class Initialized
INFO - 2024-05-24 15:06:42 --> Model Class Initialized
DEBUG - 2024-05-24 15:06:42 --> Session class already loaded. Second attempt ignored.
ERROR - 2024-05-24 17:22:26 --> $config['composer_autoload'] is set to TRUE but /home/u241458058/domains/technoprimex.com/public_html/maurnaturo/application/vendor/autoload.php was not found.
INFO - 2024-05-24 17:22:26 --> Config Class Initialized
INFO - 2024-05-24 17:22:26 --> Hooks Class Initialized
DEBUG - 2024-05-24 17:22:26 --> UTF-8 Support Enabled
INFO - 2024-05-24 17:22:26 --> Utf8 Class Initialized
INFO - 2024-05-24 17:22:26 --> URI Class Initialized
DEBUG - 2024-05-24 17:22:26 --> No URI present. Default controller set.
INFO - 2024-05-24 17:22:26 --> Router Class Initialized
INFO - 2024-05-24 17:22:26 --> Output Class Initialized
INFO - 2024-05-24 17:22:26 --> Security Class Initialized
DEBUG - 2024-05-24 17:22:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-24 17:22:26 --> Input Class Initialized
INFO - 2024-05-24 17:22:26 --> Language Class Initialized
INFO - 2024-05-24 17:22:26 --> Loader Class Initialized
INFO - 2024-05-24 17:22:26 --> Helper loaded: url_helper
INFO - 2024-05-24 17:22:26 --> Helper loaded: file_helper
INFO - 2024-05-24 17:22:26 --> Helper loaded: html_helper
INFO - 2024-05-24 17:22:26 --> Helper loaded: text_helper
INFO - 2024-05-24 17:22:26 --> Helper loaded: form_helper
INFO - 2024-05-24 17:22:26 --> Helper loaded: lang_helper
INFO - 2024-05-24 17:22:26 --> Helper loaded: security_helper
INFO - 2024-05-24 17:22:26 --> Helper loaded: cookie_helper
INFO - 2024-05-24 17:22:26 --> Database Driver Class Initialized
INFO - 2024-05-24 17:22:26 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-24 17:22:26 --> Parser Class Initialized
INFO - 2024-05-24 17:22:26 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-05-24 17:22:26 --> Pagination Class Initialized
INFO - 2024-05-24 17:22:26 --> Form Validation Class Initialized
INFO - 2024-05-24 17:22:26 --> Controller Class Initialized
INFO - 2024-05-24 17:22:26 --> Model Class Initialized
DEBUG - 2024-05-24 17:22:26 --> Session class already loaded. Second attempt ignored.
ERROR - 2024-05-24 20:29:34 --> $config['composer_autoload'] is set to TRUE but /home/u241458058/domains/technoprimex.com/public_html/maurnaturo/application/vendor/autoload.php was not found.
INFO - 2024-05-24 20:29:34 --> Config Class Initialized
INFO - 2024-05-24 20:29:34 --> Hooks Class Initialized
DEBUG - 2024-05-24 20:29:34 --> UTF-8 Support Enabled
INFO - 2024-05-24 20:29:34 --> Utf8 Class Initialized
INFO - 2024-05-24 20:29:34 --> URI Class Initialized
DEBUG - 2024-05-24 20:29:34 --> No URI present. Default controller set.
INFO - 2024-05-24 20:29:34 --> Router Class Initialized
INFO - 2024-05-24 20:29:34 --> Output Class Initialized
INFO - 2024-05-24 20:29:34 --> Security Class Initialized
DEBUG - 2024-05-24 20:29:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-24 20:29:34 --> Input Class Initialized
INFO - 2024-05-24 20:29:34 --> Language Class Initialized
INFO - 2024-05-24 20:29:34 --> Loader Class Initialized
INFO - 2024-05-24 20:29:34 --> Helper loaded: url_helper
INFO - 2024-05-24 20:29:34 --> Helper loaded: file_helper
INFO - 2024-05-24 20:29:34 --> Helper loaded: html_helper
INFO - 2024-05-24 20:29:34 --> Helper loaded: text_helper
INFO - 2024-05-24 20:29:34 --> Helper loaded: form_helper
INFO - 2024-05-24 20:29:34 --> Helper loaded: lang_helper
INFO - 2024-05-24 20:29:34 --> Helper loaded: security_helper
INFO - 2024-05-24 20:29:34 --> Helper loaded: cookie_helper
INFO - 2024-05-24 20:29:34 --> Database Driver Class Initialized
INFO - 2024-05-24 20:29:34 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-24 20:29:34 --> Parser Class Initialized
INFO - 2024-05-24 20:29:34 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-05-24 20:29:34 --> Pagination Class Initialized
INFO - 2024-05-24 20:29:34 --> Form Validation Class Initialized
INFO - 2024-05-24 20:29:34 --> Controller Class Initialized
INFO - 2024-05-24 20:29:34 --> Model Class Initialized
DEBUG - 2024-05-24 20:29:34 --> Session class already loaded. Second attempt ignored.
