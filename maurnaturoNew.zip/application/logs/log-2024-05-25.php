<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2024-05-25 02:26:26 --> $config['composer_autoload'] is set to TRUE but /home/u241458058/domains/technoprimex.com/public_html/maurnaturo/application/vendor/autoload.php was not found.
INFO - 2024-05-25 02:26:26 --> Config Class Initialized
INFO - 2024-05-25 02:26:26 --> Hooks Class Initialized
DEBUG - 2024-05-25 02:26:26 --> UTF-8 Support Enabled
INFO - 2024-05-25 02:26:26 --> Utf8 Class Initialized
INFO - 2024-05-25 02:26:26 --> URI Class Initialized
INFO - 2024-05-25 02:26:26 --> Router Class Initialized
INFO - 2024-05-25 02:26:26 --> Output Class Initialized
INFO - 2024-05-25 02:26:26 --> Security Class Initialized
DEBUG - 2024-05-25 02:26:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-25 02:26:26 --> Input Class Initialized
INFO - 2024-05-25 02:26:26 --> Language Class Initialized
INFO - 2024-05-25 02:26:26 --> Loader Class Initialized
INFO - 2024-05-25 02:26:26 --> Helper loaded: url_helper
INFO - 2024-05-25 02:26:26 --> Helper loaded: file_helper
INFO - 2024-05-25 02:26:26 --> Helper loaded: html_helper
INFO - 2024-05-25 02:26:26 --> Helper loaded: text_helper
INFO - 2024-05-25 02:26:26 --> Helper loaded: form_helper
INFO - 2024-05-25 02:26:26 --> Helper loaded: lang_helper
INFO - 2024-05-25 02:26:26 --> Helper loaded: security_helper
INFO - 2024-05-25 02:26:26 --> Helper loaded: cookie_helper
INFO - 2024-05-25 02:26:26 --> Database Driver Class Initialized
INFO - 2024-05-25 02:26:26 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-25 02:26:26 --> Parser Class Initialized
INFO - 2024-05-25 02:26:26 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-05-25 02:26:26 --> Pagination Class Initialized
INFO - 2024-05-25 02:26:26 --> Form Validation Class Initialized
INFO - 2024-05-25 02:26:26 --> Controller Class Initialized
INFO - 2024-05-25 02:26:26 --> Model Class Initialized
DEBUG - 2024-05-25 02:26:26 --> Session class already loaded. Second attempt ignored.
INFO - 2024-05-25 02:26:26 --> File loaded: /home/u241458058/domains/technoprimex.com/public_html/maurnaturo/application/views/user/admin_login_form.php
DEBUG - 2024-05-25 02:26:26 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-05-25 02:26:26 --> File loaded: /home/u241458058/domains/technoprimex.com/public_html/maurnaturo/application/views/include/top_menu.php
INFO - 2024-05-25 02:26:26 --> File loaded: /home/u241458058/domains/technoprimex.com/public_html/maurnaturo/application/views/include/admin_loggedin_info.php
INFO - 2024-05-25 02:26:26 --> Model Class Initialized
INFO - 2024-05-25 02:26:26 --> File loaded: /home/u241458058/domains/technoprimex.com/public_html/maurnaturo/application/views/admin_html_template.php
INFO - 2024-05-25 02:26:26 --> Final output sent to browser
DEBUG - 2024-05-25 02:26:26 --> Total execution time: 0.0491
ERROR - 2024-05-25 02:26:30 --> $config['composer_autoload'] is set to TRUE but /home/u241458058/domains/technoprimex.com/public_html/maurnaturo/application/vendor/autoload.php was not found.
INFO - 2024-05-25 02:26:30 --> Config Class Initialized
INFO - 2024-05-25 02:26:30 --> Hooks Class Initialized
DEBUG - 2024-05-25 02:26:30 --> UTF-8 Support Enabled
INFO - 2024-05-25 02:26:30 --> Utf8 Class Initialized
INFO - 2024-05-25 02:26:30 --> URI Class Initialized
INFO - 2024-05-25 02:26:30 --> Router Class Initialized
INFO - 2024-05-25 02:26:30 --> Output Class Initialized
INFO - 2024-05-25 02:26:30 --> Security Class Initialized
DEBUG - 2024-05-25 02:26:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-25 02:26:30 --> Input Class Initialized
INFO - 2024-05-25 02:26:30 --> Language Class Initialized
INFO - 2024-05-25 02:26:30 --> Loader Class Initialized
INFO - 2024-05-25 02:26:30 --> Helper loaded: url_helper
INFO - 2024-05-25 02:26:30 --> Helper loaded: file_helper
INFO - 2024-05-25 02:26:30 --> Helper loaded: html_helper
INFO - 2024-05-25 02:26:30 --> Helper loaded: text_helper
INFO - 2024-05-25 02:26:30 --> Helper loaded: form_helper
INFO - 2024-05-25 02:26:30 --> Helper loaded: lang_helper
INFO - 2024-05-25 02:26:30 --> Helper loaded: security_helper
INFO - 2024-05-25 02:26:30 --> Helper loaded: cookie_helper
INFO - 2024-05-25 02:26:30 --> Database Driver Class Initialized
INFO - 2024-05-25 02:26:30 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-25 02:26:30 --> Parser Class Initialized
INFO - 2024-05-25 02:26:30 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-05-25 02:26:30 --> Pagination Class Initialized
INFO - 2024-05-25 02:26:30 --> Form Validation Class Initialized
INFO - 2024-05-25 02:26:30 --> Controller Class Initialized
INFO - 2024-05-25 02:26:30 --> Model Class Initialized
DEBUG - 2024-05-25 02:26:30 --> Session class already loaded. Second attempt ignored.
INFO - 2024-05-25 02:26:30 --> Model Class Initialized
INFO - 2024-05-25 02:26:30 --> Final output sent to browser
DEBUG - 2024-05-25 02:26:30 --> Total execution time: 0.0083
ERROR - 2024-05-25 02:26:30 --> $config['composer_autoload'] is set to TRUE but /home/u241458058/domains/technoprimex.com/public_html/maurnaturo/application/vendor/autoload.php was not found.
INFO - 2024-05-25 02:26:30 --> Config Class Initialized
INFO - 2024-05-25 02:26:30 --> Hooks Class Initialized
DEBUG - 2024-05-25 02:26:30 --> UTF-8 Support Enabled
INFO - 2024-05-25 02:26:30 --> Utf8 Class Initialized
INFO - 2024-05-25 02:26:30 --> URI Class Initialized
DEBUG - 2024-05-25 02:26:30 --> No URI present. Default controller set.
INFO - 2024-05-25 02:26:30 --> Router Class Initialized
INFO - 2024-05-25 02:26:30 --> Output Class Initialized
INFO - 2024-05-25 02:26:30 --> Security Class Initialized
DEBUG - 2024-05-25 02:26:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-25 02:26:30 --> Input Class Initialized
INFO - 2024-05-25 02:26:30 --> Language Class Initialized
INFO - 2024-05-25 02:26:30 --> Loader Class Initialized
INFO - 2024-05-25 02:26:30 --> Helper loaded: url_helper
INFO - 2024-05-25 02:26:30 --> Helper loaded: file_helper
INFO - 2024-05-25 02:26:30 --> Helper loaded: html_helper
INFO - 2024-05-25 02:26:30 --> Helper loaded: text_helper
INFO - 2024-05-25 02:26:30 --> Helper loaded: form_helper
INFO - 2024-05-25 02:26:30 --> Helper loaded: lang_helper
INFO - 2024-05-25 02:26:30 --> Helper loaded: security_helper
INFO - 2024-05-25 02:26:30 --> Helper loaded: cookie_helper
INFO - 2024-05-25 02:26:30 --> Database Driver Class Initialized
INFO - 2024-05-25 02:26:30 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-25 02:26:30 --> Parser Class Initialized
INFO - 2024-05-25 02:26:30 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-05-25 02:26:30 --> Pagination Class Initialized
INFO - 2024-05-25 02:26:30 --> Form Validation Class Initialized
INFO - 2024-05-25 02:26:30 --> Controller Class Initialized
INFO - 2024-05-25 02:26:30 --> Model Class Initialized
DEBUG - 2024-05-25 02:26:30 --> Session class already loaded. Second attempt ignored.
INFO - 2024-05-25 02:26:30 --> Model Class Initialized
DEBUG - 2024-05-25 02:26:30 --> Session class already loaded. Second attempt ignored.
INFO - 2024-05-25 02:26:30 --> Model Class Initialized
INFO - 2024-05-25 02:26:30 --> Model Class Initialized
INFO - 2024-05-25 02:26:30 --> Model Class Initialized
INFO - 2024-05-25 02:26:30 --> Model Class Initialized
DEBUG - 2024-05-25 02:26:30 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-05-25 02:26:30 --> Session class already loaded. Second attempt ignored.
INFO - 2024-05-25 02:26:30 --> Model Class Initialized
INFO - 2024-05-25 02:26:30 --> Model Class Initialized
INFO - 2024-05-25 02:26:30 --> File loaded: /home/u241458058/domains/technoprimex.com/public_html/maurnaturo/application/views/include/admin_home.php
DEBUG - 2024-05-25 02:26:30 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-05-25 02:26:30 --> File loaded: /home/u241458058/domains/technoprimex.com/public_html/maurnaturo/application/views/include/top_menu.php
INFO - 2024-05-25 02:26:30 --> File loaded: /home/u241458058/domains/technoprimex.com/public_html/maurnaturo/application/views/include/admin_loggedin_info.php
INFO - 2024-05-25 02:26:30 --> Model Class Initialized
INFO - 2024-05-25 02:26:31 --> File loaded: /home/u241458058/domains/technoprimex.com/public_html/maurnaturo/application/views/include/admin_header.php
INFO - 2024-05-25 02:26:31 --> File loaded: /home/u241458058/domains/technoprimex.com/public_html/maurnaturo/application/views/include/admin_footer.php
INFO - 2024-05-25 02:26:31 --> File loaded: /home/u241458058/domains/technoprimex.com/public_html/maurnaturo/application/views/admin_html_template.php
INFO - 2024-05-25 02:26:31 --> Final output sent to browser
DEBUG - 2024-05-25 02:26:31 --> Total execution time: 0.2495
ERROR - 2024-05-25 02:26:32 --> $config['composer_autoload'] is set to TRUE but /home/u241458058/domains/technoprimex.com/public_html/maurnaturo/application/vendor/autoload.php was not found.
INFO - 2024-05-25 02:26:32 --> Config Class Initialized
INFO - 2024-05-25 02:26:32 --> Hooks Class Initialized
DEBUG - 2024-05-25 02:26:32 --> UTF-8 Support Enabled
INFO - 2024-05-25 02:26:32 --> Utf8 Class Initialized
INFO - 2024-05-25 02:26:32 --> URI Class Initialized
INFO - 2024-05-25 02:26:32 --> Router Class Initialized
INFO - 2024-05-25 02:26:32 --> Output Class Initialized
INFO - 2024-05-25 02:26:32 --> Security Class Initialized
DEBUG - 2024-05-25 02:26:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-25 02:26:32 --> Input Class Initialized
INFO - 2024-05-25 02:26:32 --> Language Class Initialized
INFO - 2024-05-25 02:26:32 --> Loader Class Initialized
INFO - 2024-05-25 02:26:32 --> Helper loaded: url_helper
INFO - 2024-05-25 02:26:32 --> Helper loaded: file_helper
INFO - 2024-05-25 02:26:32 --> Helper loaded: html_helper
INFO - 2024-05-25 02:26:32 --> Helper loaded: text_helper
INFO - 2024-05-25 02:26:32 --> Helper loaded: form_helper
INFO - 2024-05-25 02:26:32 --> Helper loaded: lang_helper
INFO - 2024-05-25 02:26:32 --> Helper loaded: security_helper
INFO - 2024-05-25 02:26:32 --> Helper loaded: cookie_helper
INFO - 2024-05-25 02:26:32 --> Database Driver Class Initialized
INFO - 2024-05-25 02:26:32 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-25 02:26:32 --> Parser Class Initialized
INFO - 2024-05-25 02:26:32 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-05-25 02:26:32 --> Pagination Class Initialized
INFO - 2024-05-25 02:26:32 --> Form Validation Class Initialized
INFO - 2024-05-25 02:26:32 --> Controller Class Initialized
DEBUG - 2024-05-25 02:26:32 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-05-25 02:26:32 --> Session class already loaded. Second attempt ignored.
INFO - 2024-05-25 02:26:32 --> Model Class Initialized
INFO - 2024-05-25 02:26:32 --> Final output sent to browser
DEBUG - 2024-05-25 02:26:32 --> Total execution time: 0.0061
ERROR - 2024-05-25 02:26:44 --> $config['composer_autoload'] is set to TRUE but /home/u241458058/domains/technoprimex.com/public_html/maurnaturo/application/vendor/autoload.php was not found.
INFO - 2024-05-25 02:26:44 --> Config Class Initialized
INFO - 2024-05-25 02:26:44 --> Hooks Class Initialized
DEBUG - 2024-05-25 02:26:44 --> UTF-8 Support Enabled
INFO - 2024-05-25 02:26:44 --> Utf8 Class Initialized
INFO - 2024-05-25 02:26:44 --> URI Class Initialized
INFO - 2024-05-25 02:26:44 --> Router Class Initialized
INFO - 2024-05-25 02:26:44 --> Output Class Initialized
INFO - 2024-05-25 02:26:44 --> Security Class Initialized
DEBUG - 2024-05-25 02:26:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-25 02:26:44 --> Input Class Initialized
INFO - 2024-05-25 02:26:44 --> Language Class Initialized
INFO - 2024-05-25 02:26:44 --> Loader Class Initialized
INFO - 2024-05-25 02:26:44 --> Helper loaded: url_helper
INFO - 2024-05-25 02:26:44 --> Helper loaded: file_helper
INFO - 2024-05-25 02:26:44 --> Helper loaded: html_helper
INFO - 2024-05-25 02:26:44 --> Helper loaded: text_helper
INFO - 2024-05-25 02:26:44 --> Helper loaded: form_helper
INFO - 2024-05-25 02:26:44 --> Helper loaded: lang_helper
INFO - 2024-05-25 02:26:44 --> Helper loaded: security_helper
INFO - 2024-05-25 02:26:44 --> Helper loaded: cookie_helper
INFO - 2024-05-25 02:26:44 --> Database Driver Class Initialized
INFO - 2024-05-25 02:26:44 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-25 02:26:44 --> Parser Class Initialized
INFO - 2024-05-25 02:26:44 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-05-25 02:26:44 --> Pagination Class Initialized
INFO - 2024-05-25 02:26:44 --> Form Validation Class Initialized
INFO - 2024-05-25 02:26:44 --> Controller Class Initialized
DEBUG - 2024-05-25 02:26:44 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-05-25 02:26:44 --> Session class already loaded. Second attempt ignored.
INFO - 2024-05-25 02:26:44 --> Model Class Initialized
DEBUG - 2024-05-25 02:26:44 --> Lexpenses class already loaded. Second attempt ignored.
INFO - 2024-05-25 02:26:44 --> Model Class Initialized
INFO - 2024-05-25 02:26:44 --> File loaded: /home/u241458058/domains/technoprimex.com/public_html/maurnaturo/application/views/expenses/expenses.php
DEBUG - 2024-05-25 02:26:44 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-05-25 02:26:44 --> File loaded: /home/u241458058/domains/technoprimex.com/public_html/maurnaturo/application/views/include/top_menu.php
INFO - 2024-05-25 02:26:44 --> File loaded: /home/u241458058/domains/technoprimex.com/public_html/maurnaturo/application/views/include/admin_loggedin_info.php
INFO - 2024-05-25 02:26:44 --> Model Class Initialized
INFO - 2024-05-25 02:26:44 --> Model Class Initialized
INFO - 2024-05-25 02:26:44 --> Model Class Initialized
INFO - 2024-05-25 02:26:44 --> File loaded: /home/u241458058/domains/technoprimex.com/public_html/maurnaturo/application/views/include/admin_header.php
INFO - 2024-05-25 02:26:44 --> File loaded: /home/u241458058/domains/technoprimex.com/public_html/maurnaturo/application/views/include/admin_footer.php
INFO - 2024-05-25 02:26:44 --> File loaded: /home/u241458058/domains/technoprimex.com/public_html/maurnaturo/application/views/admin_html_template.php
INFO - 2024-05-25 02:26:44 --> Final output sent to browser
DEBUG - 2024-05-25 02:26:44 --> Total execution time: 0.1560
ERROR - 2024-05-25 02:26:44 --> $config['composer_autoload'] is set to TRUE but /home/u241458058/domains/technoprimex.com/public_html/maurnaturo/application/vendor/autoload.php was not found.
INFO - 2024-05-25 02:26:44 --> Config Class Initialized
INFO - 2024-05-25 02:26:44 --> Hooks Class Initialized
DEBUG - 2024-05-25 02:26:44 --> UTF-8 Support Enabled
INFO - 2024-05-25 02:26:44 --> Utf8 Class Initialized
INFO - 2024-05-25 02:26:44 --> URI Class Initialized
INFO - 2024-05-25 02:26:44 --> Router Class Initialized
INFO - 2024-05-25 02:26:44 --> Output Class Initialized
INFO - 2024-05-25 02:26:44 --> Security Class Initialized
DEBUG - 2024-05-25 02:26:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-25 02:26:44 --> Input Class Initialized
INFO - 2024-05-25 02:26:44 --> Language Class Initialized
INFO - 2024-05-25 02:26:44 --> Loader Class Initialized
INFO - 2024-05-25 02:26:44 --> Helper loaded: url_helper
INFO - 2024-05-25 02:26:44 --> Helper loaded: file_helper
INFO - 2024-05-25 02:26:44 --> Helper loaded: html_helper
INFO - 2024-05-25 02:26:44 --> Helper loaded: text_helper
INFO - 2024-05-25 02:26:44 --> Helper loaded: form_helper
INFO - 2024-05-25 02:26:44 --> Helper loaded: lang_helper
INFO - 2024-05-25 02:26:44 --> Helper loaded: security_helper
INFO - 2024-05-25 02:26:44 --> Helper loaded: cookie_helper
INFO - 2024-05-25 02:26:44 --> Database Driver Class Initialized
INFO - 2024-05-25 02:26:44 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-25 02:26:44 --> Parser Class Initialized
INFO - 2024-05-25 02:26:44 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-05-25 02:26:44 --> Pagination Class Initialized
INFO - 2024-05-25 02:26:44 --> Form Validation Class Initialized
INFO - 2024-05-25 02:26:44 --> Controller Class Initialized
DEBUG - 2024-05-25 02:26:44 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-05-25 02:26:44 --> Session class already loaded. Second attempt ignored.
INFO - 2024-05-25 02:26:44 --> Model Class Initialized
INFO - 2024-05-25 02:26:44 --> Final output sent to browser
DEBUG - 2024-05-25 02:26:44 --> Total execution time: 0.0091
ERROR - 2024-05-25 02:26:48 --> $config['composer_autoload'] is set to TRUE but /home/u241458058/domains/technoprimex.com/public_html/maurnaturo/application/vendor/autoload.php was not found.
INFO - 2024-05-25 02:26:48 --> Config Class Initialized
INFO - 2024-05-25 02:26:48 --> Hooks Class Initialized
DEBUG - 2024-05-25 02:26:48 --> UTF-8 Support Enabled
INFO - 2024-05-25 02:26:48 --> Utf8 Class Initialized
INFO - 2024-05-25 02:26:48 --> URI Class Initialized
INFO - 2024-05-25 02:26:48 --> Router Class Initialized
INFO - 2024-05-25 02:26:48 --> Output Class Initialized
INFO - 2024-05-25 02:26:48 --> Security Class Initialized
DEBUG - 2024-05-25 02:26:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-25 02:26:48 --> Input Class Initialized
INFO - 2024-05-25 02:26:48 --> Language Class Initialized
INFO - 2024-05-25 02:26:48 --> Loader Class Initialized
INFO - 2024-05-25 02:26:48 --> Helper loaded: url_helper
INFO - 2024-05-25 02:26:48 --> Helper loaded: file_helper
INFO - 2024-05-25 02:26:48 --> Helper loaded: html_helper
INFO - 2024-05-25 02:26:48 --> Helper loaded: text_helper
INFO - 2024-05-25 02:26:48 --> Helper loaded: form_helper
INFO - 2024-05-25 02:26:48 --> Helper loaded: lang_helper
INFO - 2024-05-25 02:26:48 --> Helper loaded: security_helper
INFO - 2024-05-25 02:26:48 --> Helper loaded: cookie_helper
INFO - 2024-05-25 02:26:48 --> Database Driver Class Initialized
INFO - 2024-05-25 02:26:48 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-25 02:26:48 --> Parser Class Initialized
INFO - 2024-05-25 02:26:48 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-05-25 02:26:48 --> Pagination Class Initialized
INFO - 2024-05-25 02:26:48 --> Form Validation Class Initialized
INFO - 2024-05-25 02:26:48 --> Controller Class Initialized
DEBUG - 2024-05-25 02:26:48 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-05-25 02:26:48 --> Session class already loaded. Second attempt ignored.
INFO - 2024-05-25 02:26:48 --> Model Class Initialized
INFO - 2024-05-25 02:26:48 --> Model Class Initialized
DEBUG - 2024-05-25 02:26:48 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-05-25 02:26:48 --> Session class already loaded. Second attempt ignored.
INFO - 2024-05-25 02:26:48 --> File loaded: /home/u241458058/domains/technoprimex.com/public_html/maurnaturo/application/views/expenses/add_expenses_form.php
DEBUG - 2024-05-25 02:26:48 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-05-25 02:26:48 --> File loaded: /home/u241458058/domains/technoprimex.com/public_html/maurnaturo/application/views/include/top_menu.php
INFO - 2024-05-25 02:26:48 --> File loaded: /home/u241458058/domains/technoprimex.com/public_html/maurnaturo/application/views/include/admin_loggedin_info.php
INFO - 2024-05-25 02:26:48 --> Model Class Initialized
INFO - 2024-05-25 02:26:48 --> Model Class Initialized
INFO - 2024-05-25 02:26:48 --> Model Class Initialized
INFO - 2024-05-25 02:26:48 --> Model Class Initialized
INFO - 2024-05-25 02:26:48 --> File loaded: /home/u241458058/domains/technoprimex.com/public_html/maurnaturo/application/views/include/admin_header.php
INFO - 2024-05-25 02:26:48 --> File loaded: /home/u241458058/domains/technoprimex.com/public_html/maurnaturo/application/views/include/admin_footer.php
INFO - 2024-05-25 02:26:48 --> File loaded: /home/u241458058/domains/technoprimex.com/public_html/maurnaturo/application/views/admin_html_template.php
INFO - 2024-05-25 02:26:48 --> Final output sent to browser
DEBUG - 2024-05-25 02:26:48 --> Total execution time: 0.1482
ERROR - 2024-05-25 02:26:53 --> $config['composer_autoload'] is set to TRUE but /home/u241458058/domains/technoprimex.com/public_html/maurnaturo/application/vendor/autoload.php was not found.
INFO - 2024-05-25 02:26:53 --> Config Class Initialized
INFO - 2024-05-25 02:26:53 --> Hooks Class Initialized
DEBUG - 2024-05-25 02:26:53 --> UTF-8 Support Enabled
INFO - 2024-05-25 02:26:53 --> Utf8 Class Initialized
INFO - 2024-05-25 02:26:53 --> URI Class Initialized
INFO - 2024-05-25 02:26:53 --> Router Class Initialized
INFO - 2024-05-25 02:26:53 --> Output Class Initialized
INFO - 2024-05-25 02:26:53 --> Security Class Initialized
DEBUG - 2024-05-25 02:26:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-25 02:26:53 --> Input Class Initialized
INFO - 2024-05-25 02:26:53 --> Language Class Initialized
INFO - 2024-05-25 02:26:53 --> Loader Class Initialized
INFO - 2024-05-25 02:26:53 --> Helper loaded: url_helper
INFO - 2024-05-25 02:26:53 --> Helper loaded: file_helper
INFO - 2024-05-25 02:26:53 --> Helper loaded: html_helper
INFO - 2024-05-25 02:26:53 --> Helper loaded: text_helper
INFO - 2024-05-25 02:26:53 --> Helper loaded: form_helper
INFO - 2024-05-25 02:26:53 --> Helper loaded: lang_helper
INFO - 2024-05-25 02:26:53 --> Helper loaded: security_helper
INFO - 2024-05-25 02:26:53 --> Helper loaded: cookie_helper
INFO - 2024-05-25 02:26:53 --> Database Driver Class Initialized
INFO - 2024-05-25 02:26:53 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-25 02:26:53 --> Parser Class Initialized
INFO - 2024-05-25 02:26:53 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-05-25 02:26:53 --> Pagination Class Initialized
INFO - 2024-05-25 02:26:53 --> Form Validation Class Initialized
INFO - 2024-05-25 02:26:53 --> Controller Class Initialized
DEBUG - 2024-05-25 02:26:53 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-05-25 02:26:53 --> Session class already loaded. Second attempt ignored.
INFO - 2024-05-25 02:26:53 --> Model Class Initialized
DEBUG - 2024-05-25 02:26:53 --> Lexpenses class already loaded. Second attempt ignored.
INFO - 2024-05-25 02:26:53 --> Model Class Initialized
INFO - 2024-05-25 02:26:53 --> File loaded: /home/u241458058/domains/technoprimex.com/public_html/maurnaturo/application/views/expenses/expenses.php
DEBUG - 2024-05-25 02:26:53 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-05-25 02:26:53 --> File loaded: /home/u241458058/domains/technoprimex.com/public_html/maurnaturo/application/views/include/top_menu.php
INFO - 2024-05-25 02:26:53 --> File loaded: /home/u241458058/domains/technoprimex.com/public_html/maurnaturo/application/views/include/admin_loggedin_info.php
INFO - 2024-05-25 02:26:53 --> Model Class Initialized
INFO - 2024-05-25 02:26:53 --> Model Class Initialized
INFO - 2024-05-25 02:26:53 --> Model Class Initialized
INFO - 2024-05-25 02:26:53 --> File loaded: /home/u241458058/domains/technoprimex.com/public_html/maurnaturo/application/views/include/admin_header.php
INFO - 2024-05-25 02:26:53 --> File loaded: /home/u241458058/domains/technoprimex.com/public_html/maurnaturo/application/views/include/admin_footer.php
INFO - 2024-05-25 02:26:53 --> File loaded: /home/u241458058/domains/technoprimex.com/public_html/maurnaturo/application/views/admin_html_template.php
INFO - 2024-05-25 02:26:53 --> Final output sent to browser
DEBUG - 2024-05-25 02:26:53 --> Total execution time: 0.1306
ERROR - 2024-05-25 02:26:53 --> $config['composer_autoload'] is set to TRUE but /home/u241458058/domains/technoprimex.com/public_html/maurnaturo/application/vendor/autoload.php was not found.
INFO - 2024-05-25 02:26:53 --> Config Class Initialized
INFO - 2024-05-25 02:26:53 --> Hooks Class Initialized
DEBUG - 2024-05-25 02:26:53 --> UTF-8 Support Enabled
INFO - 2024-05-25 02:26:53 --> Utf8 Class Initialized
INFO - 2024-05-25 02:26:53 --> URI Class Initialized
INFO - 2024-05-25 02:26:53 --> Router Class Initialized
INFO - 2024-05-25 02:26:53 --> Output Class Initialized
INFO - 2024-05-25 02:26:53 --> Security Class Initialized
DEBUG - 2024-05-25 02:26:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-25 02:26:53 --> Input Class Initialized
INFO - 2024-05-25 02:26:53 --> Language Class Initialized
INFO - 2024-05-25 02:26:53 --> Loader Class Initialized
INFO - 2024-05-25 02:26:53 --> Helper loaded: url_helper
INFO - 2024-05-25 02:26:53 --> Helper loaded: file_helper
INFO - 2024-05-25 02:26:53 --> Helper loaded: html_helper
INFO - 2024-05-25 02:26:53 --> Helper loaded: text_helper
INFO - 2024-05-25 02:26:53 --> Helper loaded: form_helper
INFO - 2024-05-25 02:26:53 --> Helper loaded: lang_helper
INFO - 2024-05-25 02:26:53 --> Helper loaded: security_helper
INFO - 2024-05-25 02:26:53 --> Helper loaded: cookie_helper
INFO - 2024-05-25 02:26:53 --> Database Driver Class Initialized
INFO - 2024-05-25 02:26:53 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-25 02:26:53 --> Parser Class Initialized
INFO - 2024-05-25 02:26:53 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-05-25 02:26:53 --> Pagination Class Initialized
INFO - 2024-05-25 02:26:53 --> Form Validation Class Initialized
INFO - 2024-05-25 02:26:53 --> Controller Class Initialized
DEBUG - 2024-05-25 02:26:53 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-05-25 02:26:53 --> Session class already loaded. Second attempt ignored.
INFO - 2024-05-25 02:26:53 --> Model Class Initialized
INFO - 2024-05-25 02:26:53 --> Final output sent to browser
DEBUG - 2024-05-25 02:26:53 --> Total execution time: 0.0063
ERROR - 2024-05-25 02:26:56 --> $config['composer_autoload'] is set to TRUE but /home/u241458058/domains/technoprimex.com/public_html/maurnaturo/application/vendor/autoload.php was not found.
INFO - 2024-05-25 02:26:56 --> Config Class Initialized
INFO - 2024-05-25 02:26:56 --> Hooks Class Initialized
DEBUG - 2024-05-25 02:26:56 --> UTF-8 Support Enabled
INFO - 2024-05-25 02:26:56 --> Utf8 Class Initialized
INFO - 2024-05-25 02:26:56 --> URI Class Initialized
INFO - 2024-05-25 02:26:56 --> Router Class Initialized
INFO - 2024-05-25 02:26:56 --> Output Class Initialized
INFO - 2024-05-25 02:26:56 --> Security Class Initialized
DEBUG - 2024-05-25 02:26:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-25 02:26:56 --> Input Class Initialized
INFO - 2024-05-25 02:26:56 --> Language Class Initialized
ERROR - 2024-05-25 02:26:56 --> 404 Page Not Found: Cexpenses/expenses_view_form
ERROR - 2024-05-25 02:26:59 --> $config['composer_autoload'] is set to TRUE but /home/u241458058/domains/technoprimex.com/public_html/maurnaturo/application/vendor/autoload.php was not found.
INFO - 2024-05-25 02:26:59 --> Config Class Initialized
INFO - 2024-05-25 02:26:59 --> Hooks Class Initialized
DEBUG - 2024-05-25 02:26:59 --> UTF-8 Support Enabled
INFO - 2024-05-25 02:26:59 --> Utf8 Class Initialized
INFO - 2024-05-25 02:26:59 --> URI Class Initialized
INFO - 2024-05-25 02:26:59 --> Router Class Initialized
INFO - 2024-05-25 02:26:59 --> Output Class Initialized
INFO - 2024-05-25 02:26:59 --> Security Class Initialized
DEBUG - 2024-05-25 02:26:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-25 02:26:59 --> Input Class Initialized
INFO - 2024-05-25 02:26:59 --> Language Class Initialized
INFO - 2024-05-25 02:26:59 --> Loader Class Initialized
INFO - 2024-05-25 02:26:59 --> Helper loaded: url_helper
INFO - 2024-05-25 02:26:59 --> Helper loaded: file_helper
INFO - 2024-05-25 02:26:59 --> Helper loaded: html_helper
INFO - 2024-05-25 02:26:59 --> Helper loaded: text_helper
INFO - 2024-05-25 02:26:59 --> Helper loaded: form_helper
INFO - 2024-05-25 02:26:59 --> Helper loaded: lang_helper
INFO - 2024-05-25 02:26:59 --> Helper loaded: security_helper
INFO - 2024-05-25 02:26:59 --> Helper loaded: cookie_helper
INFO - 2024-05-25 02:26:59 --> Database Driver Class Initialized
INFO - 2024-05-25 02:26:59 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-25 02:26:59 --> Parser Class Initialized
INFO - 2024-05-25 02:26:59 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-05-25 02:26:59 --> Pagination Class Initialized
INFO - 2024-05-25 02:26:59 --> Form Validation Class Initialized
INFO - 2024-05-25 02:26:59 --> Controller Class Initialized
DEBUG - 2024-05-25 02:26:59 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-05-25 02:26:59 --> Session class already loaded. Second attempt ignored.
INFO - 2024-05-25 02:26:59 --> Model Class Initialized
DEBUG - 2024-05-25 02:26:59 --> Lexpenses class already loaded. Second attempt ignored.
INFO - 2024-05-25 02:26:59 --> Model Class Initialized
INFO - 2024-05-25 02:26:59 --> File loaded: /home/u241458058/domains/technoprimex.com/public_html/maurnaturo/application/views/expenses/expenses.php
DEBUG - 2024-05-25 02:26:59 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-05-25 02:26:59 --> File loaded: /home/u241458058/domains/technoprimex.com/public_html/maurnaturo/application/views/include/top_menu.php
INFO - 2024-05-25 02:26:59 --> File loaded: /home/u241458058/domains/technoprimex.com/public_html/maurnaturo/application/views/include/admin_loggedin_info.php
INFO - 2024-05-25 02:26:59 --> Model Class Initialized
INFO - 2024-05-25 02:26:59 --> Model Class Initialized
INFO - 2024-05-25 02:26:59 --> Model Class Initialized
INFO - 2024-05-25 02:26:59 --> File loaded: /home/u241458058/domains/technoprimex.com/public_html/maurnaturo/application/views/include/admin_header.php
INFO - 2024-05-25 02:26:59 --> File loaded: /home/u241458058/domains/technoprimex.com/public_html/maurnaturo/application/views/include/admin_footer.php
INFO - 2024-05-25 02:26:59 --> File loaded: /home/u241458058/domains/technoprimex.com/public_html/maurnaturo/application/views/admin_html_template.php
INFO - 2024-05-25 02:26:59 --> Final output sent to browser
DEBUG - 2024-05-25 02:26:59 --> Total execution time: 0.1467
ERROR - 2024-05-25 02:27:00 --> $config['composer_autoload'] is set to TRUE but /home/u241458058/domains/technoprimex.com/public_html/maurnaturo/application/vendor/autoload.php was not found.
INFO - 2024-05-25 02:27:00 --> Config Class Initialized
INFO - 2024-05-25 02:27:00 --> Hooks Class Initialized
DEBUG - 2024-05-25 02:27:00 --> UTF-8 Support Enabled
INFO - 2024-05-25 02:27:00 --> Utf8 Class Initialized
INFO - 2024-05-25 02:27:00 --> URI Class Initialized
INFO - 2024-05-25 02:27:00 --> Router Class Initialized
INFO - 2024-05-25 02:27:00 --> Output Class Initialized
INFO - 2024-05-25 02:27:00 --> Security Class Initialized
DEBUG - 2024-05-25 02:27:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-25 02:27:00 --> Input Class Initialized
INFO - 2024-05-25 02:27:00 --> Language Class Initialized
INFO - 2024-05-25 02:27:00 --> Loader Class Initialized
INFO - 2024-05-25 02:27:00 --> Helper loaded: url_helper
INFO - 2024-05-25 02:27:00 --> Helper loaded: file_helper
INFO - 2024-05-25 02:27:00 --> Helper loaded: html_helper
INFO - 2024-05-25 02:27:00 --> Helper loaded: text_helper
INFO - 2024-05-25 02:27:00 --> Helper loaded: form_helper
INFO - 2024-05-25 02:27:00 --> Helper loaded: lang_helper
INFO - 2024-05-25 02:27:00 --> Helper loaded: security_helper
INFO - 2024-05-25 02:27:00 --> Helper loaded: cookie_helper
INFO - 2024-05-25 02:27:00 --> Database Driver Class Initialized
INFO - 2024-05-25 02:27:00 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-25 02:27:00 --> Parser Class Initialized
INFO - 2024-05-25 02:27:00 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-05-25 02:27:00 --> Pagination Class Initialized
INFO - 2024-05-25 02:27:00 --> Form Validation Class Initialized
INFO - 2024-05-25 02:27:00 --> Controller Class Initialized
DEBUG - 2024-05-25 02:27:00 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-05-25 02:27:00 --> Session class already loaded. Second attempt ignored.
INFO - 2024-05-25 02:27:00 --> Model Class Initialized
INFO - 2024-05-25 02:27:00 --> Final output sent to browser
DEBUG - 2024-05-25 02:27:00 --> Total execution time: 0.0074
ERROR - 2024-05-25 02:27:02 --> $config['composer_autoload'] is set to TRUE but /home/u241458058/domains/technoprimex.com/public_html/maurnaturo/application/vendor/autoload.php was not found.
INFO - 2024-05-25 02:27:02 --> Config Class Initialized
INFO - 2024-05-25 02:27:02 --> Hooks Class Initialized
DEBUG - 2024-05-25 02:27:02 --> UTF-8 Support Enabled
INFO - 2024-05-25 02:27:02 --> Utf8 Class Initialized
INFO - 2024-05-25 02:27:02 --> URI Class Initialized
INFO - 2024-05-25 02:27:02 --> Router Class Initialized
INFO - 2024-05-25 02:27:02 --> Output Class Initialized
INFO - 2024-05-25 02:27:02 --> Security Class Initialized
DEBUG - 2024-05-25 02:27:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-25 02:27:02 --> Input Class Initialized
INFO - 2024-05-25 02:27:02 --> Language Class Initialized
ERROR - 2024-05-25 02:27:02 --> 404 Page Not Found: Cexpenses/expenses_view_form
ERROR - 2024-05-25 02:27:05 --> $config['composer_autoload'] is set to TRUE but /home/u241458058/domains/technoprimex.com/public_html/maurnaturo/application/vendor/autoload.php was not found.
INFO - 2024-05-25 02:27:05 --> Config Class Initialized
INFO - 2024-05-25 02:27:05 --> Hooks Class Initialized
DEBUG - 2024-05-25 02:27:05 --> UTF-8 Support Enabled
INFO - 2024-05-25 02:27:05 --> Utf8 Class Initialized
INFO - 2024-05-25 02:27:05 --> URI Class Initialized
INFO - 2024-05-25 02:27:05 --> Router Class Initialized
INFO - 2024-05-25 02:27:05 --> Output Class Initialized
INFO - 2024-05-25 02:27:05 --> Security Class Initialized
DEBUG - 2024-05-25 02:27:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-25 02:27:05 --> Input Class Initialized
INFO - 2024-05-25 02:27:05 --> Language Class Initialized
INFO - 2024-05-25 02:27:05 --> Loader Class Initialized
INFO - 2024-05-25 02:27:05 --> Helper loaded: url_helper
INFO - 2024-05-25 02:27:05 --> Helper loaded: file_helper
INFO - 2024-05-25 02:27:05 --> Helper loaded: html_helper
INFO - 2024-05-25 02:27:05 --> Helper loaded: text_helper
INFO - 2024-05-25 02:27:05 --> Helper loaded: form_helper
INFO - 2024-05-25 02:27:05 --> Helper loaded: lang_helper
INFO - 2024-05-25 02:27:05 --> Helper loaded: security_helper
INFO - 2024-05-25 02:27:05 --> Helper loaded: cookie_helper
INFO - 2024-05-25 02:27:05 --> Database Driver Class Initialized
INFO - 2024-05-25 02:27:05 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-25 02:27:05 --> Parser Class Initialized
INFO - 2024-05-25 02:27:05 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-05-25 02:27:05 --> Pagination Class Initialized
INFO - 2024-05-25 02:27:05 --> Form Validation Class Initialized
INFO - 2024-05-25 02:27:05 --> Controller Class Initialized
DEBUG - 2024-05-25 02:27:05 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-05-25 02:27:05 --> Session class already loaded. Second attempt ignored.
INFO - 2024-05-25 02:27:05 --> Model Class Initialized
DEBUG - 2024-05-25 02:27:05 --> Lexpenses class already loaded. Second attempt ignored.
INFO - 2024-05-25 02:27:05 --> Model Class Initialized
INFO - 2024-05-25 02:27:05 --> File loaded: /home/u241458058/domains/technoprimex.com/public_html/maurnaturo/application/views/expenses/expenses.php
DEBUG - 2024-05-25 02:27:05 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-05-25 02:27:05 --> File loaded: /home/u241458058/domains/technoprimex.com/public_html/maurnaturo/application/views/include/top_menu.php
INFO - 2024-05-25 02:27:05 --> File loaded: /home/u241458058/domains/technoprimex.com/public_html/maurnaturo/application/views/include/admin_loggedin_info.php
INFO - 2024-05-25 02:27:05 --> Model Class Initialized
INFO - 2024-05-25 02:27:05 --> Model Class Initialized
INFO - 2024-05-25 02:27:05 --> Model Class Initialized
INFO - 2024-05-25 02:27:05 --> File loaded: /home/u241458058/domains/technoprimex.com/public_html/maurnaturo/application/views/include/admin_header.php
INFO - 2024-05-25 02:27:05 --> File loaded: /home/u241458058/domains/technoprimex.com/public_html/maurnaturo/application/views/include/admin_footer.php
INFO - 2024-05-25 02:27:05 --> File loaded: /home/u241458058/domains/technoprimex.com/public_html/maurnaturo/application/views/admin_html_template.php
INFO - 2024-05-25 02:27:05 --> Final output sent to browser
DEBUG - 2024-05-25 02:27:05 --> Total execution time: 0.1343
ERROR - 2024-05-25 02:27:05 --> $config['composer_autoload'] is set to TRUE but /home/u241458058/domains/technoprimex.com/public_html/maurnaturo/application/vendor/autoload.php was not found.
INFO - 2024-05-25 02:27:05 --> Config Class Initialized
INFO - 2024-05-25 02:27:05 --> Hooks Class Initialized
DEBUG - 2024-05-25 02:27:05 --> UTF-8 Support Enabled
INFO - 2024-05-25 02:27:05 --> Utf8 Class Initialized
INFO - 2024-05-25 02:27:05 --> URI Class Initialized
INFO - 2024-05-25 02:27:05 --> Router Class Initialized
INFO - 2024-05-25 02:27:05 --> Output Class Initialized
INFO - 2024-05-25 02:27:05 --> Security Class Initialized
DEBUG - 2024-05-25 02:27:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-25 02:27:05 --> Input Class Initialized
INFO - 2024-05-25 02:27:05 --> Language Class Initialized
INFO - 2024-05-25 02:27:05 --> Loader Class Initialized
INFO - 2024-05-25 02:27:05 --> Helper loaded: url_helper
INFO - 2024-05-25 02:27:05 --> Helper loaded: file_helper
INFO - 2024-05-25 02:27:05 --> Helper loaded: html_helper
INFO - 2024-05-25 02:27:05 --> Helper loaded: text_helper
INFO - 2024-05-25 02:27:05 --> Helper loaded: form_helper
INFO - 2024-05-25 02:27:05 --> Helper loaded: lang_helper
INFO - 2024-05-25 02:27:05 --> Helper loaded: security_helper
INFO - 2024-05-25 02:27:05 --> Helper loaded: cookie_helper
INFO - 2024-05-25 02:27:05 --> Database Driver Class Initialized
INFO - 2024-05-25 02:27:05 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-25 02:27:05 --> Parser Class Initialized
INFO - 2024-05-25 02:27:05 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-05-25 02:27:05 --> Pagination Class Initialized
INFO - 2024-05-25 02:27:05 --> Form Validation Class Initialized
INFO - 2024-05-25 02:27:05 --> Controller Class Initialized
DEBUG - 2024-05-25 02:27:05 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-05-25 02:27:05 --> Session class already loaded. Second attempt ignored.
INFO - 2024-05-25 02:27:05 --> Model Class Initialized
INFO - 2024-05-25 02:27:05 --> Final output sent to browser
DEBUG - 2024-05-25 02:27:05 --> Total execution time: 0.0083
ERROR - 2024-05-25 02:27:11 --> $config['composer_autoload'] is set to TRUE but /home/u241458058/domains/technoprimex.com/public_html/maurnaturo/application/vendor/autoload.php was not found.
INFO - 2024-05-25 02:27:11 --> Config Class Initialized
INFO - 2024-05-25 02:27:11 --> Hooks Class Initialized
DEBUG - 2024-05-25 02:27:11 --> UTF-8 Support Enabled
INFO - 2024-05-25 02:27:11 --> Utf8 Class Initialized
INFO - 2024-05-25 02:27:11 --> URI Class Initialized
INFO - 2024-05-25 02:27:11 --> Router Class Initialized
INFO - 2024-05-25 02:27:11 --> Output Class Initialized
INFO - 2024-05-25 02:27:11 --> Security Class Initialized
DEBUG - 2024-05-25 02:27:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-25 02:27:11 --> Input Class Initialized
INFO - 2024-05-25 02:27:11 --> Language Class Initialized
INFO - 2024-05-25 02:27:11 --> Loader Class Initialized
INFO - 2024-05-25 02:27:11 --> Helper loaded: url_helper
INFO - 2024-05-25 02:27:11 --> Helper loaded: file_helper
INFO - 2024-05-25 02:27:11 --> Helper loaded: html_helper
INFO - 2024-05-25 02:27:11 --> Helper loaded: text_helper
INFO - 2024-05-25 02:27:11 --> Helper loaded: form_helper
INFO - 2024-05-25 02:27:11 --> Helper loaded: lang_helper
INFO - 2024-05-25 02:27:11 --> Helper loaded: security_helper
INFO - 2024-05-25 02:27:11 --> Helper loaded: cookie_helper
INFO - 2024-05-25 02:27:11 --> Database Driver Class Initialized
INFO - 2024-05-25 02:27:11 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-25 02:27:11 --> Parser Class Initialized
INFO - 2024-05-25 02:27:11 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-05-25 02:27:11 --> Pagination Class Initialized
INFO - 2024-05-25 02:27:11 --> Form Validation Class Initialized
INFO - 2024-05-25 02:27:11 --> Controller Class Initialized
DEBUG - 2024-05-25 02:27:11 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-05-25 02:27:11 --> Session class already loaded. Second attempt ignored.
INFO - 2024-05-25 02:27:11 --> Model Class Initialized
INFO - 2024-05-25 02:27:11 --> Model Class Initialized
DEBUG - 2024-05-25 02:27:11 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-05-25 02:27:11 --> Session class already loaded. Second attempt ignored.
INFO - 2024-05-25 02:27:11 --> File loaded: /home/u241458058/domains/technoprimex.com/public_html/maurnaturo/application/views/payments/add_payment_form.php
DEBUG - 2024-05-25 02:27:11 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-05-25 02:27:11 --> File loaded: /home/u241458058/domains/technoprimex.com/public_html/maurnaturo/application/views/include/top_menu.php
INFO - 2024-05-25 02:27:11 --> File loaded: /home/u241458058/domains/technoprimex.com/public_html/maurnaturo/application/views/include/admin_loggedin_info.php
INFO - 2024-05-25 02:27:11 --> Model Class Initialized
INFO - 2024-05-25 02:27:11 --> Model Class Initialized
INFO - 2024-05-25 02:27:11 --> Model Class Initialized
INFO - 2024-05-25 02:27:11 --> Model Class Initialized
INFO - 2024-05-25 02:27:11 --> File loaded: /home/u241458058/domains/technoprimex.com/public_html/maurnaturo/application/views/include/admin_header.php
INFO - 2024-05-25 02:27:11 --> File loaded: /home/u241458058/domains/technoprimex.com/public_html/maurnaturo/application/views/include/admin_footer.php
INFO - 2024-05-25 02:27:11 --> File loaded: /home/u241458058/domains/technoprimex.com/public_html/maurnaturo/application/views/admin_html_template.php
INFO - 2024-05-25 02:27:11 --> Final output sent to browser
DEBUG - 2024-05-25 02:27:11 --> Total execution time: 0.1415
ERROR - 2024-05-25 02:27:15 --> $config['composer_autoload'] is set to TRUE but /home/u241458058/domains/technoprimex.com/public_html/maurnaturo/application/vendor/autoload.php was not found.
INFO - 2024-05-25 02:27:15 --> Config Class Initialized
INFO - 2024-05-25 02:27:15 --> Hooks Class Initialized
DEBUG - 2024-05-25 02:27:15 --> UTF-8 Support Enabled
INFO - 2024-05-25 02:27:15 --> Utf8 Class Initialized
INFO - 2024-05-25 02:27:15 --> URI Class Initialized
INFO - 2024-05-25 02:27:15 --> Router Class Initialized
INFO - 2024-05-25 02:27:15 --> Output Class Initialized
INFO - 2024-05-25 02:27:15 --> Security Class Initialized
DEBUG - 2024-05-25 02:27:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-25 02:27:15 --> Input Class Initialized
INFO - 2024-05-25 02:27:15 --> Language Class Initialized
INFO - 2024-05-25 02:27:15 --> Loader Class Initialized
INFO - 2024-05-25 02:27:15 --> Helper loaded: url_helper
INFO - 2024-05-25 02:27:15 --> Helper loaded: file_helper
INFO - 2024-05-25 02:27:15 --> Helper loaded: html_helper
INFO - 2024-05-25 02:27:15 --> Helper loaded: text_helper
INFO - 2024-05-25 02:27:15 --> Helper loaded: form_helper
INFO - 2024-05-25 02:27:15 --> Helper loaded: lang_helper
INFO - 2024-05-25 02:27:15 --> Helper loaded: security_helper
INFO - 2024-05-25 02:27:15 --> Helper loaded: cookie_helper
INFO - 2024-05-25 02:27:15 --> Database Driver Class Initialized
INFO - 2024-05-25 02:27:15 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-25 02:27:15 --> Parser Class Initialized
INFO - 2024-05-25 02:27:15 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-05-25 02:27:15 --> Pagination Class Initialized
INFO - 2024-05-25 02:27:15 --> Form Validation Class Initialized
INFO - 2024-05-25 02:27:15 --> Controller Class Initialized
DEBUG - 2024-05-25 02:27:15 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-05-25 02:27:15 --> Session class already loaded. Second attempt ignored.
INFO - 2024-05-25 02:27:15 --> Model Class Initialized
DEBUG - 2024-05-25 02:27:15 --> Lpayments class already loaded. Second attempt ignored.
INFO - 2024-05-25 02:27:15 --> Model Class Initialized
INFO - 2024-05-25 02:27:15 --> File loaded: /home/u241458058/domains/technoprimex.com/public_html/maurnaturo/application/views/payments/payment.php
DEBUG - 2024-05-25 02:27:15 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-05-25 02:27:15 --> File loaded: /home/u241458058/domains/technoprimex.com/public_html/maurnaturo/application/views/include/top_menu.php
INFO - 2024-05-25 02:27:15 --> File loaded: /home/u241458058/domains/technoprimex.com/public_html/maurnaturo/application/views/include/admin_loggedin_info.php
INFO - 2024-05-25 02:27:15 --> Model Class Initialized
INFO - 2024-05-25 02:27:15 --> Model Class Initialized
INFO - 2024-05-25 02:27:15 --> Model Class Initialized
INFO - 2024-05-25 02:27:15 --> File loaded: /home/u241458058/domains/technoprimex.com/public_html/maurnaturo/application/views/include/admin_header.php
INFO - 2024-05-25 02:27:15 --> File loaded: /home/u241458058/domains/technoprimex.com/public_html/maurnaturo/application/views/include/admin_footer.php
INFO - 2024-05-25 02:27:15 --> File loaded: /home/u241458058/domains/technoprimex.com/public_html/maurnaturo/application/views/admin_html_template.php
INFO - 2024-05-25 02:27:15 --> Final output sent to browser
DEBUG - 2024-05-25 02:27:15 --> Total execution time: 0.1494
ERROR - 2024-05-25 02:27:15 --> $config['composer_autoload'] is set to TRUE but /home/u241458058/domains/technoprimex.com/public_html/maurnaturo/application/vendor/autoload.php was not found.
INFO - 2024-05-25 02:27:15 --> Config Class Initialized
INFO - 2024-05-25 02:27:15 --> Hooks Class Initialized
DEBUG - 2024-05-25 02:27:15 --> UTF-8 Support Enabled
INFO - 2024-05-25 02:27:15 --> Utf8 Class Initialized
INFO - 2024-05-25 02:27:15 --> URI Class Initialized
INFO - 2024-05-25 02:27:15 --> Router Class Initialized
INFO - 2024-05-25 02:27:15 --> Output Class Initialized
INFO - 2024-05-25 02:27:15 --> Security Class Initialized
DEBUG - 2024-05-25 02:27:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-25 02:27:15 --> Input Class Initialized
INFO - 2024-05-25 02:27:15 --> Language Class Initialized
INFO - 2024-05-25 02:27:15 --> Loader Class Initialized
INFO - 2024-05-25 02:27:15 --> Helper loaded: url_helper
INFO - 2024-05-25 02:27:15 --> Helper loaded: file_helper
INFO - 2024-05-25 02:27:15 --> Helper loaded: html_helper
INFO - 2024-05-25 02:27:15 --> Helper loaded: text_helper
INFO - 2024-05-25 02:27:15 --> Helper loaded: form_helper
INFO - 2024-05-25 02:27:15 --> Helper loaded: lang_helper
INFO - 2024-05-25 02:27:15 --> Helper loaded: security_helper
INFO - 2024-05-25 02:27:15 --> Helper loaded: cookie_helper
INFO - 2024-05-25 02:27:15 --> Database Driver Class Initialized
INFO - 2024-05-25 02:27:15 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-25 02:27:15 --> Parser Class Initialized
INFO - 2024-05-25 02:27:15 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-05-25 02:27:15 --> Pagination Class Initialized
INFO - 2024-05-25 02:27:15 --> Form Validation Class Initialized
INFO - 2024-05-25 02:27:15 --> Controller Class Initialized
DEBUG - 2024-05-25 02:27:15 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-05-25 02:27:15 --> Session class already loaded. Second attempt ignored.
INFO - 2024-05-25 02:27:15 --> Model Class Initialized
INFO - 2024-05-25 02:27:15 --> Final output sent to browser
DEBUG - 2024-05-25 02:27:15 --> Total execution time: 0.0060
ERROR - 2024-05-25 02:27:20 --> $config['composer_autoload'] is set to TRUE but /home/u241458058/domains/technoprimex.com/public_html/maurnaturo/application/vendor/autoload.php was not found.
INFO - 2024-05-25 02:27:20 --> Config Class Initialized
INFO - 2024-05-25 02:27:20 --> Hooks Class Initialized
DEBUG - 2024-05-25 02:27:20 --> UTF-8 Support Enabled
INFO - 2024-05-25 02:27:20 --> Utf8 Class Initialized
INFO - 2024-05-25 02:27:20 --> URI Class Initialized
INFO - 2024-05-25 02:27:20 --> Router Class Initialized
INFO - 2024-05-25 02:27:20 --> Output Class Initialized
INFO - 2024-05-25 02:27:20 --> Security Class Initialized
DEBUG - 2024-05-25 02:27:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-25 02:27:20 --> Input Class Initialized
INFO - 2024-05-25 02:27:20 --> Language Class Initialized
INFO - 2024-05-25 02:27:20 --> Loader Class Initialized
INFO - 2024-05-25 02:27:20 --> Helper loaded: url_helper
INFO - 2024-05-25 02:27:20 --> Helper loaded: file_helper
INFO - 2024-05-25 02:27:20 --> Helper loaded: html_helper
INFO - 2024-05-25 02:27:20 --> Helper loaded: text_helper
INFO - 2024-05-25 02:27:20 --> Helper loaded: form_helper
INFO - 2024-05-25 02:27:20 --> Helper loaded: lang_helper
INFO - 2024-05-25 02:27:20 --> Helper loaded: security_helper
INFO - 2024-05-25 02:27:20 --> Helper loaded: cookie_helper
INFO - 2024-05-25 02:27:20 --> Database Driver Class Initialized
INFO - 2024-05-25 02:27:20 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-25 02:27:20 --> Parser Class Initialized
INFO - 2024-05-25 02:27:20 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-05-25 02:27:20 --> Pagination Class Initialized
INFO - 2024-05-25 02:27:20 --> Form Validation Class Initialized
INFO - 2024-05-25 02:27:20 --> Controller Class Initialized
DEBUG - 2024-05-25 02:27:20 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-05-25 02:27:20 --> Session class already loaded. Second attempt ignored.
INFO - 2024-05-25 02:27:20 --> Model Class Initialized
DEBUG - 2024-05-25 02:27:20 --> Lmrpayments class already loaded. Second attempt ignored.
INFO - 2024-05-25 02:27:20 --> Model Class Initialized
INFO - 2024-05-25 02:27:20 --> File loaded: /home/u241458058/domains/technoprimex.com/public_html/maurnaturo/application/views/mr_payments/payment.php
DEBUG - 2024-05-25 02:27:20 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-05-25 02:27:20 --> File loaded: /home/u241458058/domains/technoprimex.com/public_html/maurnaturo/application/views/include/top_menu.php
INFO - 2024-05-25 02:27:20 --> File loaded: /home/u241458058/domains/technoprimex.com/public_html/maurnaturo/application/views/include/admin_loggedin_info.php
INFO - 2024-05-25 02:27:20 --> Model Class Initialized
INFO - 2024-05-25 02:27:20 --> Model Class Initialized
INFO - 2024-05-25 02:27:20 --> Model Class Initialized
INFO - 2024-05-25 02:27:20 --> File loaded: /home/u241458058/domains/technoprimex.com/public_html/maurnaturo/application/views/include/admin_header.php
INFO - 2024-05-25 02:27:20 --> File loaded: /home/u241458058/domains/technoprimex.com/public_html/maurnaturo/application/views/include/admin_footer.php
INFO - 2024-05-25 02:27:20 --> File loaded: /home/u241458058/domains/technoprimex.com/public_html/maurnaturo/application/views/admin_html_template.php
INFO - 2024-05-25 02:27:20 --> Final output sent to browser
DEBUG - 2024-05-25 02:27:20 --> Total execution time: 0.1709
ERROR - 2024-05-25 02:27:21 --> $config['composer_autoload'] is set to TRUE but /home/u241458058/domains/technoprimex.com/public_html/maurnaturo/application/vendor/autoload.php was not found.
INFO - 2024-05-25 02:27:21 --> Config Class Initialized
INFO - 2024-05-25 02:27:21 --> Hooks Class Initialized
DEBUG - 2024-05-25 02:27:21 --> UTF-8 Support Enabled
INFO - 2024-05-25 02:27:21 --> Utf8 Class Initialized
INFO - 2024-05-25 02:27:21 --> URI Class Initialized
INFO - 2024-05-25 02:27:21 --> Router Class Initialized
INFO - 2024-05-25 02:27:21 --> Output Class Initialized
INFO - 2024-05-25 02:27:21 --> Security Class Initialized
DEBUG - 2024-05-25 02:27:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-25 02:27:21 --> Input Class Initialized
INFO - 2024-05-25 02:27:21 --> Language Class Initialized
INFO - 2024-05-25 02:27:21 --> Loader Class Initialized
INFO - 2024-05-25 02:27:21 --> Helper loaded: url_helper
INFO - 2024-05-25 02:27:21 --> Helper loaded: file_helper
INFO - 2024-05-25 02:27:21 --> Helper loaded: html_helper
INFO - 2024-05-25 02:27:21 --> Helper loaded: text_helper
INFO - 2024-05-25 02:27:21 --> Helper loaded: form_helper
INFO - 2024-05-25 02:27:21 --> Helper loaded: lang_helper
INFO - 2024-05-25 02:27:21 --> Helper loaded: security_helper
INFO - 2024-05-25 02:27:21 --> Helper loaded: cookie_helper
INFO - 2024-05-25 02:27:21 --> Database Driver Class Initialized
INFO - 2024-05-25 02:27:21 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-25 02:27:21 --> Parser Class Initialized
INFO - 2024-05-25 02:27:21 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-05-25 02:27:21 --> Pagination Class Initialized
INFO - 2024-05-25 02:27:21 --> Form Validation Class Initialized
INFO - 2024-05-25 02:27:21 --> Controller Class Initialized
DEBUG - 2024-05-25 02:27:21 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-05-25 02:27:21 --> Session class already loaded. Second attempt ignored.
INFO - 2024-05-25 02:27:21 --> Model Class Initialized
INFO - 2024-05-25 02:27:21 --> Final output sent to browser
DEBUG - 2024-05-25 02:27:21 --> Total execution time: 0.0065
ERROR - 2024-05-25 02:27:23 --> $config['composer_autoload'] is set to TRUE but /home/u241458058/domains/technoprimex.com/public_html/maurnaturo/application/vendor/autoload.php was not found.
INFO - 2024-05-25 02:27:23 --> Config Class Initialized
INFO - 2024-05-25 02:27:23 --> Hooks Class Initialized
DEBUG - 2024-05-25 02:27:23 --> UTF-8 Support Enabled
INFO - 2024-05-25 02:27:23 --> Utf8 Class Initialized
INFO - 2024-05-25 02:27:23 --> URI Class Initialized
INFO - 2024-05-25 02:27:23 --> Router Class Initialized
INFO - 2024-05-25 02:27:23 --> Output Class Initialized
INFO - 2024-05-25 02:27:23 --> Security Class Initialized
DEBUG - 2024-05-25 02:27:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-25 02:27:23 --> Input Class Initialized
INFO - 2024-05-25 02:27:23 --> Language Class Initialized
INFO - 2024-05-25 02:27:23 --> Loader Class Initialized
INFO - 2024-05-25 02:27:23 --> Helper loaded: url_helper
INFO - 2024-05-25 02:27:23 --> Helper loaded: file_helper
INFO - 2024-05-25 02:27:23 --> Helper loaded: html_helper
INFO - 2024-05-25 02:27:23 --> Helper loaded: text_helper
INFO - 2024-05-25 02:27:23 --> Helper loaded: form_helper
INFO - 2024-05-25 02:27:23 --> Helper loaded: lang_helper
INFO - 2024-05-25 02:27:23 --> Helper loaded: security_helper
INFO - 2024-05-25 02:27:23 --> Helper loaded: cookie_helper
INFO - 2024-05-25 02:27:23 --> Database Driver Class Initialized
INFO - 2024-05-25 02:27:23 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-25 02:27:23 --> Parser Class Initialized
INFO - 2024-05-25 02:27:23 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-05-25 02:27:23 --> Pagination Class Initialized
INFO - 2024-05-25 02:27:23 --> Form Validation Class Initialized
INFO - 2024-05-25 02:27:23 --> Controller Class Initialized
DEBUG - 2024-05-25 02:27:23 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-05-25 02:27:23 --> Session class already loaded. Second attempt ignored.
INFO - 2024-05-25 02:27:23 --> Model Class Initialized
INFO - 2024-05-25 02:27:23 --> Model Class Initialized
DEBUG - 2024-05-25 02:27:23 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-05-25 02:27:23 --> Session class already loaded. Second attempt ignored.
INFO - 2024-05-25 02:27:23 --> File loaded: /home/u241458058/domains/technoprimex.com/public_html/maurnaturo/application/views/mr_payments/add_payment_form.php
DEBUG - 2024-05-25 02:27:23 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-05-25 02:27:23 --> File loaded: /home/u241458058/domains/technoprimex.com/public_html/maurnaturo/application/views/include/top_menu.php
INFO - 2024-05-25 02:27:23 --> File loaded: /home/u241458058/domains/technoprimex.com/public_html/maurnaturo/application/views/include/admin_loggedin_info.php
INFO - 2024-05-25 02:27:23 --> Model Class Initialized
INFO - 2024-05-25 02:27:23 --> Model Class Initialized
INFO - 2024-05-25 02:27:23 --> Model Class Initialized
INFO - 2024-05-25 02:27:23 --> Model Class Initialized
INFO - 2024-05-25 02:27:23 --> File loaded: /home/u241458058/domains/technoprimex.com/public_html/maurnaturo/application/views/include/admin_header.php
INFO - 2024-05-25 02:27:23 --> File loaded: /home/u241458058/domains/technoprimex.com/public_html/maurnaturo/application/views/include/admin_footer.php
INFO - 2024-05-25 02:27:23 --> File loaded: /home/u241458058/domains/technoprimex.com/public_html/maurnaturo/application/views/admin_html_template.php
INFO - 2024-05-25 02:27:23 --> Final output sent to browser
DEBUG - 2024-05-25 02:27:23 --> Total execution time: 0.1413
ERROR - 2024-05-25 02:27:54 --> $config['composer_autoload'] is set to TRUE but /home/u241458058/domains/technoprimex.com/public_html/maurnaturo/application/vendor/autoload.php was not found.
INFO - 2024-05-25 02:27:54 --> Config Class Initialized
INFO - 2024-05-25 02:27:54 --> Hooks Class Initialized
DEBUG - 2024-05-25 02:27:54 --> UTF-8 Support Enabled
INFO - 2024-05-25 02:27:54 --> Utf8 Class Initialized
INFO - 2024-05-25 02:27:54 --> URI Class Initialized
INFO - 2024-05-25 02:27:54 --> Router Class Initialized
INFO - 2024-05-25 02:27:54 --> Output Class Initialized
INFO - 2024-05-25 02:27:54 --> Security Class Initialized
DEBUG - 2024-05-25 02:27:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-25 02:27:54 --> Input Class Initialized
INFO - 2024-05-25 02:27:54 --> Language Class Initialized
INFO - 2024-05-25 02:27:54 --> Loader Class Initialized
INFO - 2024-05-25 02:27:54 --> Helper loaded: url_helper
INFO - 2024-05-25 02:27:54 --> Helper loaded: file_helper
INFO - 2024-05-25 02:27:54 --> Helper loaded: html_helper
INFO - 2024-05-25 02:27:54 --> Helper loaded: text_helper
INFO - 2024-05-25 02:27:54 --> Helper loaded: form_helper
INFO - 2024-05-25 02:27:54 --> Helper loaded: lang_helper
INFO - 2024-05-25 02:27:54 --> Helper loaded: security_helper
INFO - 2024-05-25 02:27:54 --> Helper loaded: cookie_helper
INFO - 2024-05-25 02:27:54 --> Database Driver Class Initialized
INFO - 2024-05-25 02:27:54 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-25 02:27:54 --> Parser Class Initialized
INFO - 2024-05-25 02:27:54 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-05-25 02:27:54 --> Pagination Class Initialized
INFO - 2024-05-25 02:27:54 --> Form Validation Class Initialized
INFO - 2024-05-25 02:27:54 --> Controller Class Initialized
DEBUG - 2024-05-25 02:27:54 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-05-25 02:27:54 --> Session class already loaded. Second attempt ignored.
INFO - 2024-05-25 02:27:54 --> Model Class Initialized
INFO - 2024-05-25 02:27:54 --> Model Class Initialized
DEBUG - 2024-05-25 02:27:54 --> Lmr class already loaded. Second attempt ignored.
INFO - 2024-05-25 02:27:54 --> Model Class Initialized
INFO - 2024-05-25 02:27:54 --> File loaded: /home/u241458058/domains/technoprimex.com/public_html/maurnaturo/application/views/mr/mr.php
DEBUG - 2024-05-25 02:27:54 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-05-25 02:27:54 --> File loaded: /home/u241458058/domains/technoprimex.com/public_html/maurnaturo/application/views/include/top_menu.php
INFO - 2024-05-25 02:27:54 --> File loaded: /home/u241458058/domains/technoprimex.com/public_html/maurnaturo/application/views/include/admin_loggedin_info.php
INFO - 2024-05-25 02:27:54 --> Model Class Initialized
INFO - 2024-05-25 02:27:54 --> Model Class Initialized
INFO - 2024-05-25 02:27:54 --> Model Class Initialized
INFO - 2024-05-25 02:27:55 --> File loaded: /home/u241458058/domains/technoprimex.com/public_html/maurnaturo/application/views/include/admin_header.php
INFO - 2024-05-25 02:27:55 --> File loaded: /home/u241458058/domains/technoprimex.com/public_html/maurnaturo/application/views/include/admin_footer.php
INFO - 2024-05-25 02:27:55 --> File loaded: /home/u241458058/domains/technoprimex.com/public_html/maurnaturo/application/views/admin_html_template.php
INFO - 2024-05-25 02:27:55 --> Final output sent to browser
DEBUG - 2024-05-25 02:27:55 --> Total execution time: 0.1406
ERROR - 2024-05-25 02:27:55 --> $config['composer_autoload'] is set to TRUE but /home/u241458058/domains/technoprimex.com/public_html/maurnaturo/application/vendor/autoload.php was not found.
INFO - 2024-05-25 02:27:55 --> Config Class Initialized
INFO - 2024-05-25 02:27:55 --> Hooks Class Initialized
DEBUG - 2024-05-25 02:27:55 --> UTF-8 Support Enabled
INFO - 2024-05-25 02:27:55 --> Utf8 Class Initialized
INFO - 2024-05-25 02:27:55 --> URI Class Initialized
INFO - 2024-05-25 02:27:55 --> Router Class Initialized
INFO - 2024-05-25 02:27:55 --> Output Class Initialized
INFO - 2024-05-25 02:27:55 --> Security Class Initialized
DEBUG - 2024-05-25 02:27:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-25 02:27:55 --> Input Class Initialized
INFO - 2024-05-25 02:27:55 --> Language Class Initialized
INFO - 2024-05-25 02:27:55 --> Loader Class Initialized
INFO - 2024-05-25 02:27:55 --> Helper loaded: url_helper
INFO - 2024-05-25 02:27:55 --> Helper loaded: file_helper
INFO - 2024-05-25 02:27:55 --> Helper loaded: html_helper
INFO - 2024-05-25 02:27:55 --> Helper loaded: text_helper
INFO - 2024-05-25 02:27:55 --> Helper loaded: form_helper
INFO - 2024-05-25 02:27:55 --> Helper loaded: lang_helper
INFO - 2024-05-25 02:27:55 --> Helper loaded: security_helper
INFO - 2024-05-25 02:27:55 --> Helper loaded: cookie_helper
INFO - 2024-05-25 02:27:55 --> Database Driver Class Initialized
INFO - 2024-05-25 02:27:55 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-25 02:27:55 --> Parser Class Initialized
INFO - 2024-05-25 02:27:55 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-05-25 02:27:55 --> Pagination Class Initialized
INFO - 2024-05-25 02:27:55 --> Form Validation Class Initialized
INFO - 2024-05-25 02:27:55 --> Controller Class Initialized
DEBUG - 2024-05-25 02:27:55 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-05-25 02:27:55 --> Session class already loaded. Second attempt ignored.
INFO - 2024-05-25 02:27:55 --> Model Class Initialized
INFO - 2024-05-25 02:27:55 --> Model Class Initialized
INFO - 2024-05-25 02:27:55 --> Final output sent to browser
DEBUG - 2024-05-25 02:27:55 --> Total execution time: 0.0122
ERROR - 2024-05-25 02:28:01 --> $config['composer_autoload'] is set to TRUE but /home/u241458058/domains/technoprimex.com/public_html/maurnaturo/application/vendor/autoload.php was not found.
INFO - 2024-05-25 02:28:01 --> Config Class Initialized
INFO - 2024-05-25 02:28:01 --> Hooks Class Initialized
DEBUG - 2024-05-25 02:28:01 --> UTF-8 Support Enabled
INFO - 2024-05-25 02:28:01 --> Utf8 Class Initialized
INFO - 2024-05-25 02:28:01 --> URI Class Initialized
INFO - 2024-05-25 02:28:01 --> Router Class Initialized
INFO - 2024-05-25 02:28:01 --> Output Class Initialized
INFO - 2024-05-25 02:28:01 --> Security Class Initialized
DEBUG - 2024-05-25 02:28:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-25 02:28:01 --> Input Class Initialized
INFO - 2024-05-25 02:28:01 --> Language Class Initialized
INFO - 2024-05-25 02:28:01 --> Loader Class Initialized
INFO - 2024-05-25 02:28:01 --> Helper loaded: url_helper
INFO - 2024-05-25 02:28:01 --> Helper loaded: file_helper
INFO - 2024-05-25 02:28:01 --> Helper loaded: html_helper
INFO - 2024-05-25 02:28:01 --> Helper loaded: text_helper
INFO - 2024-05-25 02:28:01 --> Helper loaded: form_helper
INFO - 2024-05-25 02:28:01 --> Helper loaded: lang_helper
INFO - 2024-05-25 02:28:01 --> Helper loaded: security_helper
INFO - 2024-05-25 02:28:01 --> Helper loaded: cookie_helper
INFO - 2024-05-25 02:28:01 --> Database Driver Class Initialized
INFO - 2024-05-25 02:28:01 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-25 02:28:01 --> Parser Class Initialized
INFO - 2024-05-25 02:28:01 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-05-25 02:28:01 --> Pagination Class Initialized
INFO - 2024-05-25 02:28:01 --> Form Validation Class Initialized
INFO - 2024-05-25 02:28:01 --> Controller Class Initialized
INFO - 2024-05-25 02:28:01 --> Model Class Initialized
DEBUG - 2024-05-25 02:28:01 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-05-25 02:28:01 --> Session class already loaded. Second attempt ignored.
INFO - 2024-05-25 02:28:01 --> Model Class Initialized
DEBUG - 2024-05-25 02:28:01 --> Session class already loaded. Second attempt ignored.
INFO - 2024-05-25 02:28:01 --> Model Class Initialized
INFO - 2024-05-25 02:28:01 --> File loaded: /home/u241458058/domains/technoprimex.com/public_html/maurnaturo/application/views/invoice/invoice.php
DEBUG - 2024-05-25 02:28:01 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-05-25 02:28:01 --> File loaded: /home/u241458058/domains/technoprimex.com/public_html/maurnaturo/application/views/include/top_menu.php
INFO - 2024-05-25 02:28:01 --> File loaded: /home/u241458058/domains/technoprimex.com/public_html/maurnaturo/application/views/include/admin_loggedin_info.php
INFO - 2024-05-25 02:28:01 --> Model Class Initialized
INFO - 2024-05-25 02:28:01 --> Model Class Initialized
INFO - 2024-05-25 02:28:01 --> Model Class Initialized
INFO - 2024-05-25 02:28:01 --> File loaded: /home/u241458058/domains/technoprimex.com/public_html/maurnaturo/application/views/include/admin_header.php
INFO - 2024-05-25 02:28:01 --> File loaded: /home/u241458058/domains/technoprimex.com/public_html/maurnaturo/application/views/include/admin_footer.php
INFO - 2024-05-25 02:28:01 --> File loaded: /home/u241458058/domains/technoprimex.com/public_html/maurnaturo/application/views/admin_html_template.php
INFO - 2024-05-25 02:28:01 --> Final output sent to browser
DEBUG - 2024-05-25 02:28:01 --> Total execution time: 0.1742
ERROR - 2024-05-25 02:28:02 --> $config['composer_autoload'] is set to TRUE but /home/u241458058/domains/technoprimex.com/public_html/maurnaturo/application/vendor/autoload.php was not found.
INFO - 2024-05-25 02:28:02 --> Config Class Initialized
INFO - 2024-05-25 02:28:02 --> Hooks Class Initialized
DEBUG - 2024-05-25 02:28:02 --> UTF-8 Support Enabled
INFO - 2024-05-25 02:28:02 --> Utf8 Class Initialized
INFO - 2024-05-25 02:28:02 --> URI Class Initialized
INFO - 2024-05-25 02:28:02 --> Router Class Initialized
INFO - 2024-05-25 02:28:02 --> Output Class Initialized
INFO - 2024-05-25 02:28:02 --> Security Class Initialized
DEBUG - 2024-05-25 02:28:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-25 02:28:02 --> Input Class Initialized
INFO - 2024-05-25 02:28:02 --> Language Class Initialized
INFO - 2024-05-25 02:28:02 --> Loader Class Initialized
INFO - 2024-05-25 02:28:02 --> Helper loaded: url_helper
INFO - 2024-05-25 02:28:02 --> Helper loaded: file_helper
INFO - 2024-05-25 02:28:02 --> Helper loaded: html_helper
INFO - 2024-05-25 02:28:02 --> Helper loaded: text_helper
INFO - 2024-05-25 02:28:02 --> Helper loaded: form_helper
INFO - 2024-05-25 02:28:02 --> Helper loaded: lang_helper
INFO - 2024-05-25 02:28:02 --> Helper loaded: security_helper
INFO - 2024-05-25 02:28:02 --> Helper loaded: cookie_helper
INFO - 2024-05-25 02:28:02 --> Database Driver Class Initialized
INFO - 2024-05-25 02:28:02 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-25 02:28:02 --> Parser Class Initialized
INFO - 2024-05-25 02:28:02 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-05-25 02:28:02 --> Pagination Class Initialized
INFO - 2024-05-25 02:28:02 --> Form Validation Class Initialized
INFO - 2024-05-25 02:28:02 --> Controller Class Initialized
INFO - 2024-05-25 02:28:02 --> Model Class Initialized
DEBUG - 2024-05-25 02:28:02 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-05-25 02:28:02 --> Session class already loaded. Second attempt ignored.
INFO - 2024-05-25 02:28:02 --> Model Class Initialized
DEBUG - 2024-05-25 02:28:02 --> Session class already loaded. Second attempt ignored.
INFO - 2024-05-25 02:28:02 --> Model Class Initialized
INFO - 2024-05-25 02:28:02 --> Final output sent to browser
DEBUG - 2024-05-25 02:28:02 --> Total execution time: 0.0421
ERROR - 2024-05-25 02:28:05 --> $config['composer_autoload'] is set to TRUE but /home/u241458058/domains/technoprimex.com/public_html/maurnaturo/application/vendor/autoload.php was not found.
INFO - 2024-05-25 02:28:05 --> Config Class Initialized
INFO - 2024-05-25 02:28:05 --> Hooks Class Initialized
DEBUG - 2024-05-25 02:28:05 --> UTF-8 Support Enabled
INFO - 2024-05-25 02:28:05 --> Utf8 Class Initialized
INFO - 2024-05-25 02:28:05 --> URI Class Initialized
INFO - 2024-05-25 02:28:05 --> Router Class Initialized
INFO - 2024-05-25 02:28:05 --> Output Class Initialized
INFO - 2024-05-25 02:28:05 --> Security Class Initialized
DEBUG - 2024-05-25 02:28:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-25 02:28:05 --> Input Class Initialized
INFO - 2024-05-25 02:28:05 --> Language Class Initialized
INFO - 2024-05-25 02:28:05 --> Loader Class Initialized
INFO - 2024-05-25 02:28:05 --> Helper loaded: url_helper
INFO - 2024-05-25 02:28:05 --> Helper loaded: file_helper
INFO - 2024-05-25 02:28:05 --> Helper loaded: html_helper
INFO - 2024-05-25 02:28:05 --> Helper loaded: text_helper
INFO - 2024-05-25 02:28:05 --> Helper loaded: form_helper
INFO - 2024-05-25 02:28:05 --> Helper loaded: lang_helper
INFO - 2024-05-25 02:28:05 --> Helper loaded: security_helper
INFO - 2024-05-25 02:28:05 --> Helper loaded: cookie_helper
INFO - 2024-05-25 02:28:05 --> Database Driver Class Initialized
INFO - 2024-05-25 02:28:05 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-25 02:28:05 --> Parser Class Initialized
INFO - 2024-05-25 02:28:05 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-05-25 02:28:05 --> Pagination Class Initialized
INFO - 2024-05-25 02:28:05 --> Form Validation Class Initialized
INFO - 2024-05-25 02:28:05 --> Controller Class Initialized
INFO - 2024-05-25 02:28:05 --> Model Class Initialized
DEBUG - 2024-05-25 02:28:05 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-05-25 02:28:05 --> Session class already loaded. Second attempt ignored.
INFO - 2024-05-25 02:28:05 --> Model Class Initialized
DEBUG - 2024-05-25 02:28:05 --> Session class already loaded. Second attempt ignored.
INFO - 2024-05-25 02:28:05 --> Model Class Initialized
INFO - 2024-05-25 02:28:05 --> File loaded: /home/u241458058/domains/technoprimex.com/public_html/maurnaturo/application/views/proformainvoice/invoice.php
DEBUG - 2024-05-25 02:28:05 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-05-25 02:28:05 --> File loaded: /home/u241458058/domains/technoprimex.com/public_html/maurnaturo/application/views/include/top_menu.php
INFO - 2024-05-25 02:28:05 --> File loaded: /home/u241458058/domains/technoprimex.com/public_html/maurnaturo/application/views/include/admin_loggedin_info.php
INFO - 2024-05-25 02:28:05 --> Model Class Initialized
INFO - 2024-05-25 02:28:05 --> Model Class Initialized
INFO - 2024-05-25 02:28:05 --> Model Class Initialized
INFO - 2024-05-25 02:28:05 --> File loaded: /home/u241458058/domains/technoprimex.com/public_html/maurnaturo/application/views/include/admin_header.php
INFO - 2024-05-25 02:28:05 --> File loaded: /home/u241458058/domains/technoprimex.com/public_html/maurnaturo/application/views/include/admin_footer.php
INFO - 2024-05-25 02:28:05 --> File loaded: /home/u241458058/domains/technoprimex.com/public_html/maurnaturo/application/views/admin_html_template.php
INFO - 2024-05-25 02:28:05 --> Final output sent to browser
DEBUG - 2024-05-25 02:28:05 --> Total execution time: 0.1543
ERROR - 2024-05-25 02:28:06 --> $config['composer_autoload'] is set to TRUE but /home/u241458058/domains/technoprimex.com/public_html/maurnaturo/application/vendor/autoload.php was not found.
INFO - 2024-05-25 02:28:06 --> Config Class Initialized
INFO - 2024-05-25 02:28:06 --> Hooks Class Initialized
DEBUG - 2024-05-25 02:28:06 --> UTF-8 Support Enabled
INFO - 2024-05-25 02:28:06 --> Utf8 Class Initialized
INFO - 2024-05-25 02:28:06 --> URI Class Initialized
INFO - 2024-05-25 02:28:06 --> Router Class Initialized
INFO - 2024-05-25 02:28:06 --> Output Class Initialized
INFO - 2024-05-25 02:28:06 --> Security Class Initialized
DEBUG - 2024-05-25 02:28:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-25 02:28:06 --> Input Class Initialized
INFO - 2024-05-25 02:28:06 --> Language Class Initialized
INFO - 2024-05-25 02:28:06 --> Loader Class Initialized
INFO - 2024-05-25 02:28:06 --> Helper loaded: url_helper
INFO - 2024-05-25 02:28:06 --> Helper loaded: file_helper
INFO - 2024-05-25 02:28:06 --> Helper loaded: html_helper
INFO - 2024-05-25 02:28:06 --> Helper loaded: text_helper
INFO - 2024-05-25 02:28:06 --> Helper loaded: form_helper
INFO - 2024-05-25 02:28:06 --> Helper loaded: lang_helper
INFO - 2024-05-25 02:28:06 --> Helper loaded: security_helper
INFO - 2024-05-25 02:28:06 --> Helper loaded: cookie_helper
INFO - 2024-05-25 02:28:06 --> Database Driver Class Initialized
INFO - 2024-05-25 02:28:06 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-25 02:28:06 --> Parser Class Initialized
INFO - 2024-05-25 02:28:06 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-05-25 02:28:06 --> Pagination Class Initialized
INFO - 2024-05-25 02:28:06 --> Form Validation Class Initialized
INFO - 2024-05-25 02:28:06 --> Controller Class Initialized
INFO - 2024-05-25 02:28:06 --> Model Class Initialized
DEBUG - 2024-05-25 02:28:06 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-05-25 02:28:06 --> Session class already loaded. Second attempt ignored.
INFO - 2024-05-25 02:28:06 --> Model Class Initialized
DEBUG - 2024-05-25 02:28:06 --> Session class already loaded. Second attempt ignored.
INFO - 2024-05-25 02:28:06 --> Model Class Initialized
INFO - 2024-05-25 02:28:06 --> Final output sent to browser
DEBUG - 2024-05-25 02:28:06 --> Total execution time: 0.0299
ERROR - 2024-05-25 02:56:38 --> $config['composer_autoload'] is set to TRUE but /home/u241458058/domains/technoprimex.com/public_html/maurnaturo/application/vendor/autoload.php was not found.
INFO - 2024-05-25 02:56:38 --> Config Class Initialized
INFO - 2024-05-25 02:56:38 --> Hooks Class Initialized
DEBUG - 2024-05-25 02:56:38 --> UTF-8 Support Enabled
INFO - 2024-05-25 02:56:38 --> Utf8 Class Initialized
INFO - 2024-05-25 02:56:38 --> URI Class Initialized
INFO - 2024-05-25 02:56:38 --> Router Class Initialized
INFO - 2024-05-25 02:56:38 --> Output Class Initialized
INFO - 2024-05-25 02:56:38 --> Security Class Initialized
DEBUG - 2024-05-25 02:56:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-25 02:56:38 --> Input Class Initialized
INFO - 2024-05-25 02:56:38 --> Language Class Initialized
INFO - 2024-05-25 02:56:38 --> Loader Class Initialized
INFO - 2024-05-25 02:56:38 --> Helper loaded: url_helper
INFO - 2024-05-25 02:56:38 --> Helper loaded: file_helper
INFO - 2024-05-25 02:56:38 --> Helper loaded: html_helper
INFO - 2024-05-25 02:56:38 --> Helper loaded: text_helper
INFO - 2024-05-25 02:56:38 --> Helper loaded: form_helper
INFO - 2024-05-25 02:56:38 --> Helper loaded: lang_helper
INFO - 2024-05-25 02:56:38 --> Helper loaded: security_helper
INFO - 2024-05-25 02:56:38 --> Helper loaded: cookie_helper
INFO - 2024-05-25 02:56:38 --> Database Driver Class Initialized
INFO - 2024-05-25 02:56:38 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-25 02:56:38 --> Parser Class Initialized
INFO - 2024-05-25 02:56:38 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-05-25 02:56:38 --> Pagination Class Initialized
INFO - 2024-05-25 02:56:38 --> Form Validation Class Initialized
INFO - 2024-05-25 02:56:38 --> Controller Class Initialized
INFO - 2024-05-25 02:56:38 --> Model Class Initialized
DEBUG - 2024-05-25 02:56:38 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-05-25 02:56:38 --> Session class already loaded. Second attempt ignored.
INFO - 2024-05-25 02:56:38 --> Model Class Initialized
DEBUG - 2024-05-25 02:56:38 --> Session class already loaded. Second attempt ignored.
INFO - 2024-05-25 02:56:38 --> Model Class Initialized
INFO - 2024-05-25 02:56:38 --> File loaded: /home/u241458058/domains/technoprimex.com/public_html/maurnaturo/application/views/proformainvoice/invoice.php
DEBUG - 2024-05-25 02:56:38 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-05-25 02:56:38 --> File loaded: /home/u241458058/domains/technoprimex.com/public_html/maurnaturo/application/views/include/top_menu.php
INFO - 2024-05-25 02:56:38 --> File loaded: /home/u241458058/domains/technoprimex.com/public_html/maurnaturo/application/views/include/admin_loggedin_info.php
INFO - 2024-05-25 02:56:38 --> Model Class Initialized
INFO - 2024-05-25 02:56:38 --> Model Class Initialized
INFO - 2024-05-25 02:56:38 --> Model Class Initialized
INFO - 2024-05-25 02:56:39 --> File loaded: /home/u241458058/domains/technoprimex.com/public_html/maurnaturo/application/views/include/admin_header.php
INFO - 2024-05-25 02:56:39 --> File loaded: /home/u241458058/domains/technoprimex.com/public_html/maurnaturo/application/views/include/admin_footer.php
INFO - 2024-05-25 02:56:39 --> File loaded: /home/u241458058/domains/technoprimex.com/public_html/maurnaturo/application/views/admin_html_template.php
INFO - 2024-05-25 02:56:39 --> Final output sent to browser
DEBUG - 2024-05-25 02:56:39 --> Total execution time: 0.2029
ERROR - 2024-05-25 02:56:39 --> $config['composer_autoload'] is set to TRUE but /home/u241458058/domains/technoprimex.com/public_html/maurnaturo/application/vendor/autoload.php was not found.
INFO - 2024-05-25 02:56:39 --> Config Class Initialized
INFO - 2024-05-25 02:56:39 --> Hooks Class Initialized
DEBUG - 2024-05-25 02:56:39 --> UTF-8 Support Enabled
INFO - 2024-05-25 02:56:39 --> Utf8 Class Initialized
INFO - 2024-05-25 02:56:39 --> URI Class Initialized
INFO - 2024-05-25 02:56:39 --> Router Class Initialized
INFO - 2024-05-25 02:56:39 --> Output Class Initialized
INFO - 2024-05-25 02:56:39 --> Security Class Initialized
DEBUG - 2024-05-25 02:56:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-25 02:56:39 --> Input Class Initialized
INFO - 2024-05-25 02:56:39 --> Language Class Initialized
INFO - 2024-05-25 02:56:39 --> Loader Class Initialized
INFO - 2024-05-25 02:56:39 --> Helper loaded: url_helper
INFO - 2024-05-25 02:56:39 --> Helper loaded: file_helper
INFO - 2024-05-25 02:56:39 --> Helper loaded: html_helper
INFO - 2024-05-25 02:56:39 --> Helper loaded: text_helper
INFO - 2024-05-25 02:56:39 --> Helper loaded: form_helper
INFO - 2024-05-25 02:56:39 --> Helper loaded: lang_helper
INFO - 2024-05-25 02:56:39 --> Helper loaded: security_helper
INFO - 2024-05-25 02:56:39 --> Helper loaded: cookie_helper
INFO - 2024-05-25 02:56:39 --> Database Driver Class Initialized
INFO - 2024-05-25 02:56:39 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-25 02:56:39 --> Parser Class Initialized
INFO - 2024-05-25 02:56:39 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-05-25 02:56:39 --> Pagination Class Initialized
INFO - 2024-05-25 02:56:39 --> Form Validation Class Initialized
INFO - 2024-05-25 02:56:39 --> Controller Class Initialized
INFO - 2024-05-25 02:56:39 --> Model Class Initialized
DEBUG - 2024-05-25 02:56:39 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-05-25 02:56:39 --> Session class already loaded. Second attempt ignored.
INFO - 2024-05-25 02:56:39 --> Model Class Initialized
DEBUG - 2024-05-25 02:56:39 --> Session class already loaded. Second attempt ignored.
INFO - 2024-05-25 02:56:39 --> Model Class Initialized
INFO - 2024-05-25 02:56:39 --> Final output sent to browser
DEBUG - 2024-05-25 02:56:39 --> Total execution time: 0.0305
