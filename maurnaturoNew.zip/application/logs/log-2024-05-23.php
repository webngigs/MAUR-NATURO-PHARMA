<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2024-05-23 06:38:58 --> $config['composer_autoload'] is set to TRUE but /home/u241458058/domains/technoprimex.com/public_html/maurnaturo/application/vendor/autoload.php was not found.
INFO - 2024-05-23 06:38:58 --> Config Class Initialized
INFO - 2024-05-23 06:38:58 --> Hooks Class Initialized
DEBUG - 2024-05-23 06:38:58 --> UTF-8 Support Enabled
INFO - 2024-05-23 06:38:58 --> Utf8 Class Initialized
INFO - 2024-05-23 06:38:58 --> URI Class Initialized
INFO - 2024-05-23 06:38:58 --> Router Class Initialized
INFO - 2024-05-23 06:38:58 --> Output Class Initialized
INFO - 2024-05-23 06:38:58 --> Security Class Initialized
DEBUG - 2024-05-23 06:38:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-23 06:38:58 --> Input Class Initialized
INFO - 2024-05-23 06:38:58 --> Language Class Initialized
ERROR - 2024-05-23 06:38:58 --> 404 Page Not Found: Env/index
ERROR - 2024-05-23 10:07:29 --> $config['composer_autoload'] is set to TRUE but /home/u241458058/domains/technoprimex.com/public_html/maurnaturo/application/vendor/autoload.php was not found.
INFO - 2024-05-23 10:07:29 --> Config Class Initialized
INFO - 2024-05-23 10:07:29 --> Hooks Class Initialized
DEBUG - 2024-05-23 10:07:29 --> UTF-8 Support Enabled
INFO - 2024-05-23 10:07:29 --> Utf8 Class Initialized
INFO - 2024-05-23 10:07:29 --> URI Class Initialized
DEBUG - 2024-05-23 10:07:29 --> No URI present. Default controller set.
INFO - 2024-05-23 10:07:29 --> Router Class Initialized
INFO - 2024-05-23 10:07:29 --> Output Class Initialized
INFO - 2024-05-23 10:07:29 --> Security Class Initialized
DEBUG - 2024-05-23 10:07:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-23 10:07:29 --> Input Class Initialized
INFO - 2024-05-23 10:07:29 --> Language Class Initialized
INFO - 2024-05-23 10:07:29 --> Loader Class Initialized
INFO - 2024-05-23 10:07:29 --> Helper loaded: url_helper
INFO - 2024-05-23 10:07:29 --> Helper loaded: file_helper
INFO - 2024-05-23 10:07:29 --> Helper loaded: html_helper
INFO - 2024-05-23 10:07:29 --> Helper loaded: text_helper
INFO - 2024-05-23 10:07:29 --> Helper loaded: form_helper
INFO - 2024-05-23 10:07:29 --> Helper loaded: lang_helper
INFO - 2024-05-23 10:07:29 --> Helper loaded: security_helper
INFO - 2024-05-23 10:07:29 --> Helper loaded: cookie_helper
INFO - 2024-05-23 10:07:29 --> Database Driver Class Initialized
INFO - 2024-05-23 10:07:29 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-23 10:07:29 --> Parser Class Initialized
INFO - 2024-05-23 10:07:29 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-05-23 10:07:29 --> Pagination Class Initialized
INFO - 2024-05-23 10:07:29 --> Form Validation Class Initialized
INFO - 2024-05-23 10:07:29 --> Controller Class Initialized
INFO - 2024-05-23 10:07:29 --> Model Class Initialized
DEBUG - 2024-05-23 10:07:29 --> Session class already loaded. Second attempt ignored.
ERROR - 2024-05-23 20:34:47 --> $config['composer_autoload'] is set to TRUE but /home/u241458058/domains/technoprimex.com/public_html/maurnaturo/application/vendor/autoload.php was not found.
INFO - 2024-05-23 20:34:47 --> Config Class Initialized
INFO - 2024-05-23 20:34:47 --> Hooks Class Initialized
DEBUG - 2024-05-23 20:34:47 --> UTF-8 Support Enabled
INFO - 2024-05-23 20:34:47 --> Utf8 Class Initialized
INFO - 2024-05-23 20:34:47 --> URI Class Initialized
DEBUG - 2024-05-23 20:34:47 --> No URI present. Default controller set.
INFO - 2024-05-23 20:34:47 --> Router Class Initialized
INFO - 2024-05-23 20:34:47 --> Output Class Initialized
INFO - 2024-05-23 20:34:47 --> Security Class Initialized
DEBUG - 2024-05-23 20:34:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-23 20:34:47 --> Input Class Initialized
INFO - 2024-05-23 20:34:47 --> Language Class Initialized
INFO - 2024-05-23 20:34:47 --> Loader Class Initialized
INFO - 2024-05-23 20:34:47 --> Helper loaded: url_helper
INFO - 2024-05-23 20:34:47 --> Helper loaded: file_helper
INFO - 2024-05-23 20:34:47 --> Helper loaded: html_helper
INFO - 2024-05-23 20:34:47 --> Helper loaded: text_helper
INFO - 2024-05-23 20:34:47 --> Helper loaded: form_helper
INFO - 2024-05-23 20:34:47 --> Helper loaded: lang_helper
INFO - 2024-05-23 20:34:47 --> Helper loaded: security_helper
INFO - 2024-05-23 20:34:47 --> Helper loaded: cookie_helper
INFO - 2024-05-23 20:34:47 --> Database Driver Class Initialized
INFO - 2024-05-23 20:34:47 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-23 20:34:47 --> Parser Class Initialized
INFO - 2024-05-23 20:34:47 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-05-23 20:34:47 --> Pagination Class Initialized
INFO - 2024-05-23 20:34:47 --> Form Validation Class Initialized
INFO - 2024-05-23 20:34:47 --> Controller Class Initialized
INFO - 2024-05-23 20:34:47 --> Model Class Initialized
DEBUG - 2024-05-23 20:34:47 --> Session class already loaded. Second attempt ignored.
