ERROR - 2024-05-12 14:33:49 --> $config['composer_autoload'] is set to TRUE but E:\xampp\htdocs\maurnaturo\application\vendor/autoload.php was not found.
INFO - 2024-05-12 14:33:49 --> Config Class Initialized
INFO - 2024-05-12 14:33:49 --> Hooks Class Initialized
DEBUG - 2024-05-12 14:33:49 --> UTF-8 Support Enabled
INFO - 2024-05-12 14:33:49 --> Utf8 Class Initialized
INFO - 2024-05-12 14:33:49 --> URI Class Initialized
INFO - 2024-05-12 14:33:49 --> Router Class Initialized
INFO - 2024-05-12 14:33:49 --> Output Class Initialized
INFO - 2024-05-12 14:33:49 --> Security Class Initialized
DEBUG - 2024-05-12 14:33:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-12 14:33:49 --> Input Class Initialized
INFO - 2024-05-12 14:33:49 --> Language Class Initialized
INFO - 2024-05-12 14:33:49 --> Loader Class Initialized
INFO - 2024-05-12 14:33:49 --> Helper loaded: url_helper
INFO - 2024-05-12 14:33:49 --> Helper loaded: file_helper
INFO - 2024-05-12 14:33:49 --> Helper loaded: html_helper
INFO - 2024-05-12 14:33:49 --> Helper loaded: text_helper
INFO - 2024-05-12 14:33:49 --> Helper loaded: form_helper
INFO - 2024-05-12 14:33:49 --> Helper loaded: lang_helper
INFO - 2024-05-12 14:33:49 --> Helper loaded: security_helper
INFO - 2024-05-12 14:33:49 --> Helper loaded: cookie_helper
INFO - 2024-05-12 14:33:49 --> Database Driver Class Initialized
INFO - 2024-05-12 14:33:49 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-12 14:33:49 --> Parser Class Initialized
INFO - 2024-05-12 14:33:49 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-05-12 14:33:49 --> Pagination Class Initialized
INFO - 2024-05-12 14:33:49 --> Form Validation Class Initialized
INFO - 2024-05-12 14:33:49 --> Controller Class Initialized
DEBUG - 2024-05-12 14:33:49 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-05-12 14:33:49 --> Session class already loaded. Second attempt ignored.
INFO - 2024-05-12 14:33:49 --> Model Class Initialized
ERROR - 2024-05-12 14:33:49 --> Severity: error --> Exception: Call to a member function select_all_mr() on null E:\xampp\htdocs\maurnaturo\application\libraries\Lpayments.php 7
ERROR - 2024-05-12 14:34:13 --> $config['composer_autoload'] is set to TRUE but E:\xampp\htdocs\maurnaturo\application\vendor/autoload.php was not found.
INFO - 2024-05-12 14:34:13 --> Config Class Initialized
INFO - 2024-05-12 14:34:13 --> Hooks Class Initialized
DEBUG - 2024-05-12 14:34:13 --> UTF-8 Support Enabled
INFO - 2024-05-12 14:34:13 --> Utf8 Class Initialized
INFO - 2024-05-12 14:34:13 --> URI Class Initialized
INFO - 2024-05-12 14:34:13 --> Router Class Initialized
INFO - 2024-05-12 14:34:13 --> Output Class Initialized
INFO - 2024-05-12 14:34:13 --> Security Class Initialized
DEBUG - 2024-05-12 14:34:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-12 14:34:13 --> Input Class Initialized
INFO - 2024-05-12 14:34:13 --> Language Class Initialized
INFO - 2024-05-12 14:34:13 --> Loader Class Initialized
INFO - 2024-05-12 14:34:13 --> Helper loaded: url_helper
INFO - 2024-05-12 14:34:13 --> Helper loaded: file_helper
INFO - 2024-05-12 14:34:13 --> Helper loaded: html_helper
INFO - 2024-05-12 14:34:13 --> Helper loaded: text_helper
INFO - 2024-05-12 14:34:13 --> Helper loaded: form_helper
INFO - 2024-05-12 14:34:13 --> Helper loaded: lang_helper
INFO - 2024-05-12 14:34:13 --> Helper loaded: security_helper
INFO - 2024-05-12 14:34:13 --> Helper loaded: cookie_helper
INFO - 2024-05-12 14:34:13 --> Database Driver Class Initialized
INFO - 2024-05-12 14:34:13 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-12 14:34:13 --> Parser Class Initialized
INFO - 2024-05-12 14:34:13 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-05-12 14:34:13 --> Pagination Class Initialized
INFO - 2024-05-12 14:34:13 --> Form Validation Class Initialized
INFO - 2024-05-12 14:34:13 --> Controller Class Initialized
DEBUG - 2024-05-12 14:34:13 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-05-12 14:34:13 --> Session class already loaded. Second attempt ignored.
INFO - 2024-05-12 14:34:13 --> Model Class Initialized
ERROR - 2024-05-12 14:34:13 --> Severity: error --> Exception: Call to a member function select_all_mr() on null E:\xampp\htdocs\maurnaturo\application\libraries\Lpayments.php 7
ERROR - 2024-05-12 14:34:13 --> $config['composer_autoload'] is set to TRUE but E:\xampp\htdocs\maurnaturo\application\vendor/autoload.php was not found.
INFO - 2024-05-12 14:34:14 --> Config Class Initialized
INFO - 2024-05-12 14:34:14 --> Hooks Class Initialized
DEBUG - 2024-05-12 14:34:14 --> UTF-8 Support Enabled
INFO - 2024-05-12 14:34:14 --> Utf8 Class Initialized
INFO - 2024-05-12 14:34:14 --> URI Class Initialized
INFO - 2024-05-12 14:34:14 --> Router Class Initialized
INFO - 2024-05-12 14:34:14 --> Output Class Initialized
INFO - 2024-05-12 14:34:14 --> Security Class Initialized
DEBUG - 2024-05-12 14:34:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-12 14:34:14 --> Input Class Initialized
INFO - 2024-05-12 14:34:14 --> Language Class Initialized
INFO - 2024-05-12 14:34:14 --> Loader Class Initialized
INFO - 2024-05-12 14:34:14 --> Helper loaded: url_helper
INFO - 2024-05-12 14:34:14 --> Helper loaded: file_helper
INFO - 2024-05-12 14:34:14 --> Helper loaded: html_helper
INFO - 2024-05-12 14:34:14 --> Helper loaded: text_helper
INFO - 2024-05-12 14:34:14 --> Helper loaded: form_helper
INFO - 2024-05-12 14:34:14 --> Helper loaded: lang_helper
INFO - 2024-05-12 14:34:14 --> Helper loaded: security_helper
INFO - 2024-05-12 14:34:14 --> Helper loaded: cookie_helper
INFO - 2024-05-12 14:34:14 --> Database Driver Class Initialized
INFO - 2024-05-12 14:34:14 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-12 14:34:14 --> Parser Class Initialized
INFO - 2024-05-12 14:34:14 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-05-12 14:34:14 --> Pagination Class Initialized
INFO - 2024-05-12 14:34:14 --> Form Validation Class Initialized
INFO - 2024-05-12 14:34:14 --> Controller Class Initialized
DEBUG - 2024-05-12 14:34:14 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-05-12 14:34:14 --> Session class already loaded. Second attempt ignored.
INFO - 2024-05-12 14:34:14 --> Model Class Initialized
ERROR - 2024-05-12 14:34:14 --> Severity: error --> Exception: Call to a member function select_all_mr() on null E:\xampp\htdocs\maurnaturo\application\libraries\Lpayments.php 7
ERROR - 2024-05-12 14:34:36 --> $config['composer_autoload'] is set to TRUE but E:\xampp\htdocs\maurnaturo\application\vendor/autoload.php was not found.
INFO - 2024-05-12 14:34:36 --> Config Class Initialized
INFO - 2024-05-12 14:34:36 --> Hooks Class Initialized
DEBUG - 2024-05-12 14:34:36 --> UTF-8 Support Enabled
INFO - 2024-05-12 14:34:36 --> Utf8 Class Initialized
INFO - 2024-05-12 14:34:36 --> URI Class Initialized
INFO - 2024-05-12 14:34:36 --> Router Class Initialized
INFO - 2024-05-12 14:34:36 --> Output Class Initialized
INFO - 2024-05-12 14:34:36 --> Security Class Initialized
DEBUG - 2024-05-12 14:34:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-12 14:34:36 --> Input Class Initialized
INFO - 2024-05-12 14:34:36 --> Language Class Initialized
INFO - 2024-05-12 14:34:36 --> Loader Class Initialized
INFO - 2024-05-12 14:34:36 --> Helper loaded: url_helper
INFO - 2024-05-12 14:34:36 --> Helper loaded: file_helper
INFO - 2024-05-12 14:34:36 --> Helper loaded: html_helper
INFO - 2024-05-12 14:34:36 --> Helper loaded: text_helper
INFO - 2024-05-12 14:34:36 --> Helper loaded: form_helper
INFO - 2024-05-12 14:34:36 --> Helper loaded: lang_helper
INFO - 2024-05-12 14:34:36 --> Helper loaded: security_helper
INFO - 2024-05-12 14:34:36 --> Helper loaded: cookie_helper
INFO - 2024-05-12 14:34:36 --> Database Driver Class Initialized
INFO - 2024-05-12 14:34:36 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-12 14:34:36 --> Parser Class Initialized
INFO - 2024-05-12 14:34:36 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-05-12 14:34:36 --> Pagination Class Initialized
INFO - 2024-05-12 14:34:36 --> Form Validation Class Initialized
INFO - 2024-05-12 14:34:36 --> Controller Class Initialized
DEBUG - 2024-05-12 14:34:36 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-05-12 14:34:36 --> Session class already loaded. Second attempt ignored.
INFO - 2024-05-12 14:34:36 --> Model Class Initialized
INFO - 2024-05-12 14:34:36 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\payments/add_payment_form.php
DEBUG - 2024-05-12 14:34:36 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-05-12 14:34:36 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\include/top_menu.php
INFO - 2024-05-12 14:34:36 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\include/admin_loggedin_info.php
INFO - 2024-05-12 14:34:36 --> Model Class Initialized
INFO - 2024-05-12 14:34:36 --> Model Class Initialized
INFO - 2024-05-12 14:34:36 --> Model Class Initialized
INFO - 2024-05-12 14:34:36 --> Model Class Initialized
INFO - 2024-05-12 14:34:38 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\include/admin_header.php
INFO - 2024-05-12 14:34:38 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\include/admin_footer.php
INFO - 2024-05-12 14:34:38 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\admin_html_template.php
INFO - 2024-05-12 14:34:38 --> Final output sent to browser
DEBUG - 2024-05-12 14:34:38 --> Total execution time: 1.4639
ERROR - 2024-05-12 14:34:44 --> $config['composer_autoload'] is set to TRUE but E:\xampp\htdocs\maurnaturo\application\vendor/autoload.php was not found.
INFO - 2024-05-12 14:34:44 --> Config Class Initialized
INFO - 2024-05-12 14:34:44 --> Hooks Class Initialized
DEBUG - 2024-05-12 14:34:44 --> UTF-8 Support Enabled
INFO - 2024-05-12 14:34:44 --> Utf8 Class Initialized
INFO - 2024-05-12 14:34:44 --> URI Class Initialized
INFO - 2024-05-12 14:34:44 --> Router Class Initialized
INFO - 2024-05-12 14:34:44 --> Output Class Initialized
INFO - 2024-05-12 14:34:44 --> Security Class Initialized
DEBUG - 2024-05-12 14:34:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-12 14:34:44 --> Input Class Initialized
INFO - 2024-05-12 14:34:44 --> Language Class Initialized
INFO - 2024-05-12 14:34:44 --> Loader Class Initialized
INFO - 2024-05-12 14:34:44 --> Helper loaded: url_helper
INFO - 2024-05-12 14:34:44 --> Helper loaded: file_helper
INFO - 2024-05-12 14:34:44 --> Helper loaded: html_helper
INFO - 2024-05-12 14:34:44 --> Helper loaded: text_helper
INFO - 2024-05-12 14:34:44 --> Helper loaded: form_helper
INFO - 2024-05-12 14:34:44 --> Helper loaded: lang_helper
INFO - 2024-05-12 14:34:44 --> Helper loaded: security_helper
INFO - 2024-05-12 14:34:44 --> Helper loaded: cookie_helper
INFO - 2024-05-12 14:34:44 --> Database Driver Class Initialized
INFO - 2024-05-12 14:34:44 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-12 14:34:44 --> Parser Class Initialized
INFO - 2024-05-12 14:34:44 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-05-12 14:34:44 --> Pagination Class Initialized
INFO - 2024-05-12 14:34:44 --> Form Validation Class Initialized
INFO - 2024-05-12 14:34:44 --> Controller Class Initialized
DEBUG - 2024-05-12 14:34:44 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-05-12 14:34:44 --> Session class already loaded. Second attempt ignored.
INFO - 2024-05-12 14:34:44 --> Model Class Initialized
INFO - 2024-05-12 14:34:44 --> Model Class Initialized
DEBUG - 2024-05-12 14:34:44 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-05-12 14:34:44 --> Session class already loaded. Second attempt ignored.
INFO - 2024-05-12 14:34:44 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\mr_payments/add_payment_form.php
DEBUG - 2024-05-12 14:34:44 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-05-12 14:34:44 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\include/top_menu.php
INFO - 2024-05-12 14:34:44 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\include/admin_loggedin_info.php
INFO - 2024-05-12 14:34:44 --> Model Class Initialized
INFO - 2024-05-12 14:34:44 --> Model Class Initialized
INFO - 2024-05-12 14:34:44 --> Model Class Initialized
INFO - 2024-05-12 14:34:44 --> Model Class Initialized
INFO - 2024-05-12 14:34:45 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\include/admin_header.php
INFO - 2024-05-12 14:34:45 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\include/admin_footer.php
INFO - 2024-05-12 14:34:45 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\admin_html_template.php
INFO - 2024-05-12 14:34:45 --> Final output sent to browser
DEBUG - 2024-05-12 14:34:45 --> Total execution time: 1.4573
ERROR - 2024-05-12 15:02:34 --> $config['composer_autoload'] is set to TRUE but E:\xampp\htdocs\maurnaturo\application\vendor/autoload.php was not found.
INFO - 2024-05-12 15:02:34 --> Config Class Initialized
INFO - 2024-05-12 15:02:34 --> Hooks Class Initialized
DEBUG - 2024-05-12 15:02:34 --> UTF-8 Support Enabled
INFO - 2024-05-12 15:02:34 --> Utf8 Class Initialized
INFO - 2024-05-12 15:02:34 --> URI Class Initialized
INFO - 2024-05-12 15:02:34 --> Router Class Initialized
INFO - 2024-05-12 15:02:34 --> Output Class Initialized
INFO - 2024-05-12 15:02:34 --> Security Class Initialized
DEBUG - 2024-05-12 15:02:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-12 15:02:34 --> Input Class Initialized
INFO - 2024-05-12 15:02:34 --> Language Class Initialized
INFO - 2024-05-12 15:02:34 --> Loader Class Initialized
INFO - 2024-05-12 15:02:34 --> Helper loaded: url_helper
INFO - 2024-05-12 15:02:34 --> Helper loaded: file_helper
INFO - 2024-05-12 15:02:34 --> Helper loaded: html_helper
INFO - 2024-05-12 15:02:34 --> Helper loaded: text_helper
INFO - 2024-05-12 15:02:34 --> Helper loaded: form_helper
INFO - 2024-05-12 15:02:34 --> Helper loaded: lang_helper
INFO - 2024-05-12 15:02:34 --> Helper loaded: security_helper
INFO - 2024-05-12 15:02:34 --> Helper loaded: cookie_helper
INFO - 2024-05-12 15:02:34 --> Database Driver Class Initialized
INFO - 2024-05-12 15:02:34 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-12 15:02:34 --> Parser Class Initialized
INFO - 2024-05-12 15:02:34 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-05-12 15:02:34 --> Pagination Class Initialized
INFO - 2024-05-12 15:02:34 --> Form Validation Class Initialized
INFO - 2024-05-12 15:02:34 --> Controller Class Initialized
DEBUG - 2024-05-12 15:02:34 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-05-12 15:02:34 --> Session class already loaded. Second attempt ignored.
INFO - 2024-05-12 15:02:34 --> Model Class Initialized
INFO - 2024-05-12 15:02:34 --> Model Class Initialized
DEBUG - 2024-05-12 15:02:34 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-05-12 15:02:34 --> Session class already loaded. Second attempt ignored.
INFO - 2024-05-12 15:02:34 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\mr_payments/add_payment_form.php
DEBUG - 2024-05-12 15:02:34 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-05-12 15:02:34 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\include/top_menu.php
INFO - 2024-05-12 15:02:34 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\include/admin_loggedin_info.php
INFO - 2024-05-12 15:02:34 --> Model Class Initialized
INFO - 2024-05-12 15:02:34 --> Model Class Initialized
INFO - 2024-05-12 15:02:34 --> Model Class Initialized
INFO - 2024-05-12 15:02:34 --> Model Class Initialized
INFO - 2024-05-12 15:02:36 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\include/admin_header.php
INFO - 2024-05-12 15:02:36 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\include/admin_footer.php
INFO - 2024-05-12 15:02:36 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\admin_html_template.php
INFO - 2024-05-12 15:02:36 --> Final output sent to browser
DEBUG - 2024-05-12 15:02:36 --> Total execution time: 1.7554
ERROR - 2024-05-12 15:02:50 --> $config['composer_autoload'] is set to TRUE but E:\xampp\htdocs\maurnaturo\application\vendor/autoload.php was not found.
INFO - 2024-05-12 15:02:50 --> Config Class Initialized
INFO - 2024-05-12 15:02:50 --> Hooks Class Initialized
DEBUG - 2024-05-12 15:02:50 --> UTF-8 Support Enabled
INFO - 2024-05-12 15:02:50 --> Utf8 Class Initialized
INFO - 2024-05-12 15:02:50 --> URI Class Initialized
INFO - 2024-05-12 15:02:50 --> Router Class Initialized
INFO - 2024-05-12 15:02:50 --> Output Class Initialized
INFO - 2024-05-12 15:02:50 --> Security Class Initialized
DEBUG - 2024-05-12 15:02:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-12 15:02:50 --> Input Class Initialized
INFO - 2024-05-12 15:02:50 --> Language Class Initialized
INFO - 2024-05-12 15:02:50 --> Loader Class Initialized
INFO - 2024-05-12 15:02:50 --> Helper loaded: url_helper
INFO - 2024-05-12 15:02:50 --> Helper loaded: file_helper
INFO - 2024-05-12 15:02:50 --> Helper loaded: html_helper
INFO - 2024-05-12 15:02:50 --> Helper loaded: text_helper
INFO - 2024-05-12 15:02:50 --> Helper loaded: form_helper
INFO - 2024-05-12 15:02:50 --> Helper loaded: lang_helper
INFO - 2024-05-12 15:02:50 --> Helper loaded: security_helper
INFO - 2024-05-12 15:02:50 --> Helper loaded: cookie_helper
INFO - 2024-05-12 15:02:50 --> Database Driver Class Initialized
INFO - 2024-05-12 15:02:50 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-12 15:02:50 --> Parser Class Initialized
INFO - 2024-05-12 15:02:50 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-05-12 15:02:50 --> Pagination Class Initialized
INFO - 2024-05-12 15:02:50 --> Form Validation Class Initialized
INFO - 2024-05-12 15:02:50 --> Controller Class Initialized
DEBUG - 2024-05-12 15:02:50 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-05-12 15:02:50 --> Session class already loaded. Second attempt ignored.
INFO - 2024-05-12 15:02:50 --> Model Class Initialized
INFO - 2024-05-12 15:02:50 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\payments/add_payment_form.php
DEBUG - 2024-05-12 15:02:50 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-05-12 15:02:50 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\include/top_menu.php
INFO - 2024-05-12 15:02:50 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\include/admin_loggedin_info.php
INFO - 2024-05-12 15:02:50 --> Model Class Initialized
INFO - 2024-05-12 15:02:50 --> Model Class Initialized
INFO - 2024-05-12 15:02:50 --> Model Class Initialized
INFO - 2024-05-12 15:02:50 --> Model Class Initialized
INFO - 2024-05-12 15:02:52 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\include/admin_header.php
INFO - 2024-05-12 15:02:52 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\include/admin_footer.php
INFO - 2024-05-12 15:02:52 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\admin_html_template.php
INFO - 2024-05-12 15:02:52 --> Final output sent to browser
DEBUG - 2024-05-12 15:02:52 --> Total execution time: 1.6668
ERROR - 2024-05-12 15:02:57 --> $config['composer_autoload'] is set to TRUE but E:\xampp\htdocs\maurnaturo\application\vendor/autoload.php was not found.
INFO - 2024-05-12 15:02:57 --> Config Class Initialized
INFO - 2024-05-12 15:02:57 --> Hooks Class Initialized
DEBUG - 2024-05-12 15:02:57 --> UTF-8 Support Enabled
INFO - 2024-05-12 15:02:57 --> Utf8 Class Initialized
INFO - 2024-05-12 15:02:57 --> URI Class Initialized
INFO - 2024-05-12 15:02:57 --> Router Class Initialized
INFO - 2024-05-12 15:02:57 --> Output Class Initialized
INFO - 2024-05-12 15:02:57 --> Security Class Initialized
DEBUG - 2024-05-12 15:02:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-12 15:02:57 --> Input Class Initialized
INFO - 2024-05-12 15:02:57 --> Language Class Initialized
INFO - 2024-05-12 15:02:57 --> Loader Class Initialized
INFO - 2024-05-12 15:02:57 --> Helper loaded: url_helper
INFO - 2024-05-12 15:02:57 --> Helper loaded: file_helper
INFO - 2024-05-12 15:02:57 --> Helper loaded: html_helper
INFO - 2024-05-12 15:02:57 --> Helper loaded: text_helper
INFO - 2024-05-12 15:02:57 --> Helper loaded: form_helper
INFO - 2024-05-12 15:02:57 --> Helper loaded: lang_helper
INFO - 2024-05-12 15:02:57 --> Helper loaded: security_helper
INFO - 2024-05-12 15:02:57 --> Helper loaded: cookie_helper
INFO - 2024-05-12 15:02:57 --> Database Driver Class Initialized
INFO - 2024-05-12 15:02:57 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-12 15:02:57 --> Parser Class Initialized
INFO - 2024-05-12 15:02:57 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-05-12 15:02:57 --> Pagination Class Initialized
INFO - 2024-05-12 15:02:57 --> Form Validation Class Initialized
INFO - 2024-05-12 15:02:57 --> Controller Class Initialized
DEBUG - 2024-05-12 15:02:57 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-05-12 15:02:57 --> Session class already loaded. Second attempt ignored.
INFO - 2024-05-12 15:02:57 --> Model Class Initialized
DEBUG - 2024-05-12 15:02:57 --> Lpayments class already loaded. Second attempt ignored.
INFO - 2024-05-12 15:02:57 --> Model Class Initialized
INFO - 2024-05-12 15:02:57 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\payments/payment.php
DEBUG - 2024-05-12 15:02:57 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-05-12 15:02:57 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\include/top_menu.php
INFO - 2024-05-12 15:02:57 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\include/admin_loggedin_info.php
INFO - 2024-05-12 15:02:57 --> Model Class Initialized
INFO - 2024-05-12 15:02:57 --> Model Class Initialized
INFO - 2024-05-12 15:02:57 --> Model Class Initialized
INFO - 2024-05-12 15:02:58 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\include/admin_header.php
INFO - 2024-05-12 15:02:58 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\include/admin_footer.php
INFO - 2024-05-12 15:02:58 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\admin_html_template.php
INFO - 2024-05-12 15:02:58 --> Final output sent to browser
DEBUG - 2024-05-12 15:02:58 --> Total execution time: 1.5315
ERROR - 2024-05-12 15:02:58 --> $config['composer_autoload'] is set to TRUE but E:\xampp\htdocs\maurnaturo\application\vendor/autoload.php was not found.
INFO - 2024-05-12 15:02:58 --> Config Class Initialized
INFO - 2024-05-12 15:02:58 --> Hooks Class Initialized
DEBUG - 2024-05-12 15:02:58 --> UTF-8 Support Enabled
INFO - 2024-05-12 15:02:58 --> Utf8 Class Initialized
INFO - 2024-05-12 15:02:58 --> URI Class Initialized
INFO - 2024-05-12 15:02:58 --> Router Class Initialized
INFO - 2024-05-12 15:02:58 --> Output Class Initialized
INFO - 2024-05-12 15:02:58 --> Security Class Initialized
DEBUG - 2024-05-12 15:02:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-12 15:02:58 --> Input Class Initialized
INFO - 2024-05-12 15:02:58 --> Language Class Initialized
INFO - 2024-05-12 15:02:58 --> Loader Class Initialized
INFO - 2024-05-12 15:02:58 --> Helper loaded: url_helper
INFO - 2024-05-12 15:02:58 --> Helper loaded: file_helper
INFO - 2024-05-12 15:02:58 --> Helper loaded: html_helper
INFO - 2024-05-12 15:02:58 --> Helper loaded: text_helper
INFO - 2024-05-12 15:02:58 --> Helper loaded: form_helper
INFO - 2024-05-12 15:02:58 --> Helper loaded: lang_helper
INFO - 2024-05-12 15:02:58 --> Helper loaded: security_helper
INFO - 2024-05-12 15:02:58 --> Helper loaded: cookie_helper
INFO - 2024-05-12 15:02:58 --> Database Driver Class Initialized
INFO - 2024-05-12 15:02:58 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-12 15:02:58 --> Parser Class Initialized
INFO - 2024-05-12 15:02:58 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-05-12 15:02:58 --> Pagination Class Initialized
INFO - 2024-05-12 15:02:58 --> Form Validation Class Initialized
INFO - 2024-05-12 15:02:58 --> Controller Class Initialized
DEBUG - 2024-05-12 15:02:58 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-05-12 15:02:58 --> Session class already loaded. Second attempt ignored.
INFO - 2024-05-12 15:02:58 --> Model Class Initialized
INFO - 2024-05-12 15:02:58 --> Final output sent to browser
DEBUG - 2024-05-12 15:02:58 --> Total execution time: 0.1235
ERROR - 2024-05-12 15:03:03 --> $config['composer_autoload'] is set to TRUE but E:\xampp\htdocs\maurnaturo\application\vendor/autoload.php was not found.
INFO - 2024-05-12 15:03:03 --> Config Class Initialized
INFO - 2024-05-12 15:03:03 --> Hooks Class Initialized
DEBUG - 2024-05-12 15:03:03 --> UTF-8 Support Enabled
INFO - 2024-05-12 15:03:03 --> Utf8 Class Initialized
INFO - 2024-05-12 15:03:03 --> URI Class Initialized
INFO - 2024-05-12 15:03:03 --> Router Class Initialized
INFO - 2024-05-12 15:03:03 --> Output Class Initialized
INFO - 2024-05-12 15:03:03 --> Security Class Initialized
DEBUG - 2024-05-12 15:03:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-12 15:03:03 --> Input Class Initialized
INFO - 2024-05-12 15:03:03 --> Language Class Initialized
INFO - 2024-05-12 15:03:03 --> Loader Class Initialized
INFO - 2024-05-12 15:03:03 --> Helper loaded: url_helper
INFO - 2024-05-12 15:03:03 --> Helper loaded: file_helper
INFO - 2024-05-12 15:03:03 --> Helper loaded: html_helper
INFO - 2024-05-12 15:03:03 --> Helper loaded: text_helper
INFO - 2024-05-12 15:03:03 --> Helper loaded: form_helper
INFO - 2024-05-12 15:03:03 --> Helper loaded: lang_helper
INFO - 2024-05-12 15:03:03 --> Helper loaded: security_helper
INFO - 2024-05-12 15:03:03 --> Helper loaded: cookie_helper
INFO - 2024-05-12 15:03:03 --> Database Driver Class Initialized
INFO - 2024-05-12 15:03:03 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-12 15:03:03 --> Parser Class Initialized
INFO - 2024-05-12 15:03:03 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-05-12 15:03:03 --> Pagination Class Initialized
INFO - 2024-05-12 15:03:03 --> Form Validation Class Initialized
INFO - 2024-05-12 15:03:03 --> Controller Class Initialized
DEBUG - 2024-05-12 15:03:03 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-05-12 15:03:03 --> Session class already loaded. Second attempt ignored.
INFO - 2024-05-12 15:03:03 --> Model Class Initialized
INFO - 2024-05-12 15:03:03 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\payments/add_payment_form.php
DEBUG - 2024-05-12 15:03:03 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-05-12 15:03:03 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\include/top_menu.php
INFO - 2024-05-12 15:03:03 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\include/admin_loggedin_info.php
INFO - 2024-05-12 15:03:03 --> Model Class Initialized
INFO - 2024-05-12 15:03:03 --> Model Class Initialized
INFO - 2024-05-12 15:03:03 --> Model Class Initialized
INFO - 2024-05-12 15:03:03 --> Model Class Initialized
INFO - 2024-05-12 15:03:04 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\include/admin_header.php
INFO - 2024-05-12 15:03:04 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\include/admin_footer.php
INFO - 2024-05-12 15:03:04 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\admin_html_template.php
INFO - 2024-05-12 15:03:04 --> Final output sent to browser
DEBUG - 2024-05-12 15:03:04 --> Total execution time: 1.5199
ERROR - 2024-05-12 15:03:41 --> $config['composer_autoload'] is set to TRUE but E:\xampp\htdocs\maurnaturo\application\vendor/autoload.php was not found.
INFO - 2024-05-12 15:03:41 --> Config Class Initialized
INFO - 2024-05-12 15:03:41 --> Hooks Class Initialized
DEBUG - 2024-05-12 15:03:41 --> UTF-8 Support Enabled
INFO - 2024-05-12 15:03:41 --> Utf8 Class Initialized
INFO - 2024-05-12 15:03:41 --> URI Class Initialized
INFO - 2024-05-12 15:03:41 --> Router Class Initialized
INFO - 2024-05-12 15:03:41 --> Output Class Initialized
INFO - 2024-05-12 15:03:41 --> Security Class Initialized
DEBUG - 2024-05-12 15:03:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-12 15:03:41 --> Input Class Initialized
INFO - 2024-05-12 15:03:41 --> Language Class Initialized
INFO - 2024-05-12 15:03:41 --> Loader Class Initialized
INFO - 2024-05-12 15:03:41 --> Helper loaded: url_helper
INFO - 2024-05-12 15:03:41 --> Helper loaded: file_helper
INFO - 2024-05-12 15:03:41 --> Helper loaded: html_helper
INFO - 2024-05-12 15:03:41 --> Helper loaded: text_helper
INFO - 2024-05-12 15:03:41 --> Helper loaded: form_helper
INFO - 2024-05-12 15:03:41 --> Helper loaded: lang_helper
INFO - 2024-05-12 15:03:41 --> Helper loaded: security_helper
INFO - 2024-05-12 15:03:41 --> Helper loaded: cookie_helper
INFO - 2024-05-12 15:03:41 --> Database Driver Class Initialized
INFO - 2024-05-12 15:03:41 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-12 15:03:41 --> Parser Class Initialized
INFO - 2024-05-12 15:03:41 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-05-12 15:03:41 --> Pagination Class Initialized
INFO - 2024-05-12 15:03:41 --> Form Validation Class Initialized
INFO - 2024-05-12 15:03:41 --> Controller Class Initialized
INFO - 2024-05-12 15:03:41 --> Model Class Initialized
DEBUG - 2024-05-12 15:03:41 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-05-12 15:03:41 --> Session class already loaded. Second attempt ignored.
INFO - 2024-05-12 15:03:41 --> Model Class Initialized
DEBUG - 2024-05-12 15:03:41 --> Session class already loaded. Second attempt ignored.
INFO - 2024-05-12 15:03:41 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\demandrequest/add_demandrequest_form.php
DEBUG - 2024-05-12 15:03:41 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-05-12 15:03:41 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\include/top_menu.php
INFO - 2024-05-12 15:03:41 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\include/admin_loggedin_info.php
INFO - 2024-05-12 15:03:41 --> Model Class Initialized
INFO - 2024-05-12 15:03:41 --> Model Class Initialized
INFO - 2024-05-12 15:03:41 --> Model Class Initialized
INFO - 2024-05-12 15:03:42 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\include/admin_header.php
INFO - 2024-05-12 15:03:42 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\include/admin_footer.php
INFO - 2024-05-12 15:03:42 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\admin_html_template.php
INFO - 2024-05-12 15:03:42 --> Final output sent to browser
DEBUG - 2024-05-12 15:03:42 --> Total execution time: 1.6825
ERROR - 2024-05-12 15:03:54 --> $config['composer_autoload'] is set to TRUE but E:\xampp\htdocs\maurnaturo\application\vendor/autoload.php was not found.
INFO - 2024-05-12 15:03:54 --> Config Class Initialized
INFO - 2024-05-12 15:03:54 --> Hooks Class Initialized
DEBUG - 2024-05-12 15:03:54 --> UTF-8 Support Enabled
INFO - 2024-05-12 15:03:54 --> Utf8 Class Initialized
INFO - 2024-05-12 15:03:54 --> URI Class Initialized
INFO - 2024-05-12 15:03:55 --> Router Class Initialized
INFO - 2024-05-12 15:03:55 --> Output Class Initialized
INFO - 2024-05-12 15:03:55 --> Security Class Initialized
DEBUG - 2024-05-12 15:03:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-12 15:03:55 --> Input Class Initialized
INFO - 2024-05-12 15:03:55 --> Language Class Initialized
INFO - 2024-05-12 15:03:55 --> Loader Class Initialized
INFO - 2024-05-12 15:03:55 --> Helper loaded: url_helper
INFO - 2024-05-12 15:03:55 --> Helper loaded: file_helper
INFO - 2024-05-12 15:03:55 --> Helper loaded: html_helper
INFO - 2024-05-12 15:03:55 --> Helper loaded: text_helper
INFO - 2024-05-12 15:03:55 --> Helper loaded: form_helper
INFO - 2024-05-12 15:03:55 --> Helper loaded: lang_helper
INFO - 2024-05-12 15:03:55 --> Helper loaded: security_helper
INFO - 2024-05-12 15:03:55 --> Helper loaded: cookie_helper
INFO - 2024-05-12 15:03:55 --> Database Driver Class Initialized
INFO - 2024-05-12 15:03:55 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-12 15:03:55 --> Parser Class Initialized
INFO - 2024-05-12 15:03:55 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-05-12 15:03:55 --> Pagination Class Initialized
INFO - 2024-05-12 15:03:55 --> Form Validation Class Initialized
INFO - 2024-05-12 15:03:55 --> Controller Class Initialized
INFO - 2024-05-12 15:03:55 --> Model Class Initialized
DEBUG - 2024-05-12 15:03:55 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-05-12 15:03:55 --> Session class already loaded. Second attempt ignored.
INFO - 2024-05-12 15:03:55 --> Model Class Initialized
DEBUG - 2024-05-12 15:03:55 --> Session class already loaded. Second attempt ignored.
INFO - 2024-05-12 15:03:55 --> Model Class Initialized
INFO - 2024-05-12 15:03:55 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\invoice/invoice.php
DEBUG - 2024-05-12 15:03:55 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-05-12 15:03:55 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\include/top_menu.php
INFO - 2024-05-12 15:03:55 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\include/admin_loggedin_info.php
INFO - 2024-05-12 15:03:55 --> Model Class Initialized
INFO - 2024-05-12 15:03:55 --> Model Class Initialized
INFO - 2024-05-12 15:03:55 --> Model Class Initialized
INFO - 2024-05-12 15:03:56 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\include/admin_header.php
INFO - 2024-05-12 15:03:56 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\include/admin_footer.php
INFO - 2024-05-12 15:03:56 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\admin_html_template.php
INFO - 2024-05-12 15:03:56 --> Final output sent to browser
DEBUG - 2024-05-12 15:03:56 --> Total execution time: 1.5320
ERROR - 2024-05-12 15:03:56 --> $config['composer_autoload'] is set to TRUE but E:\xampp\htdocs\maurnaturo\application\vendor/autoload.php was not found.
INFO - 2024-05-12 15:03:56 --> Config Class Initialized
INFO - 2024-05-12 15:03:56 --> Hooks Class Initialized
DEBUG - 2024-05-12 15:03:56 --> UTF-8 Support Enabled
INFO - 2024-05-12 15:03:56 --> Utf8 Class Initialized
INFO - 2024-05-12 15:03:56 --> URI Class Initialized
INFO - 2024-05-12 15:03:56 --> Router Class Initialized
INFO - 2024-05-12 15:03:56 --> Output Class Initialized
INFO - 2024-05-12 15:03:56 --> Security Class Initialized
DEBUG - 2024-05-12 15:03:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-12 15:03:56 --> Input Class Initialized
INFO - 2024-05-12 15:03:56 --> Language Class Initialized
INFO - 2024-05-12 15:03:56 --> Loader Class Initialized
INFO - 2024-05-12 15:03:56 --> Helper loaded: url_helper
INFO - 2024-05-12 15:03:56 --> Helper loaded: file_helper
INFO - 2024-05-12 15:03:56 --> Helper loaded: html_helper
INFO - 2024-05-12 15:03:56 --> Helper loaded: text_helper
INFO - 2024-05-12 15:03:56 --> Helper loaded: form_helper
INFO - 2024-05-12 15:03:56 --> Helper loaded: lang_helper
INFO - 2024-05-12 15:03:56 --> Helper loaded: security_helper
INFO - 2024-05-12 15:03:56 --> Helper loaded: cookie_helper
INFO - 2024-05-12 15:03:56 --> Database Driver Class Initialized
INFO - 2024-05-12 15:03:56 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-12 15:03:56 --> Parser Class Initialized
INFO - 2024-05-12 15:03:56 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-05-12 15:03:56 --> Pagination Class Initialized
INFO - 2024-05-12 15:03:56 --> Form Validation Class Initialized
INFO - 2024-05-12 15:03:56 --> Controller Class Initialized
INFO - 2024-05-12 15:03:56 --> Model Class Initialized
DEBUG - 2024-05-12 15:03:56 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-05-12 15:03:56 --> Session class already loaded. Second attempt ignored.
INFO - 2024-05-12 15:03:56 --> Model Class Initialized
DEBUG - 2024-05-12 15:03:56 --> Session class already loaded. Second attempt ignored.
INFO - 2024-05-12 15:03:56 --> Model Class Initialized
INFO - 2024-05-12 15:03:57 --> Final output sent to browser
DEBUG - 2024-05-12 15:03:57 --> Total execution time: 0.3144
ERROR - 2024-05-12 15:04:00 --> $config['composer_autoload'] is set to TRUE but E:\xampp\htdocs\maurnaturo\application\vendor/autoload.php was not found.
INFO - 2024-05-12 15:04:00 --> Config Class Initialized
INFO - 2024-05-12 15:04:00 --> Hooks Class Initialized
DEBUG - 2024-05-12 15:04:00 --> UTF-8 Support Enabled
INFO - 2024-05-12 15:04:00 --> Utf8 Class Initialized
INFO - 2024-05-12 15:04:00 --> URI Class Initialized
INFO - 2024-05-12 15:04:00 --> Router Class Initialized
INFO - 2024-05-12 15:04:00 --> Output Class Initialized
INFO - 2024-05-12 15:04:00 --> Security Class Initialized
DEBUG - 2024-05-12 15:04:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-12 15:04:00 --> Input Class Initialized
INFO - 2024-05-12 15:04:00 --> Language Class Initialized
INFO - 2024-05-12 15:04:00 --> Loader Class Initialized
INFO - 2024-05-12 15:04:00 --> Helper loaded: url_helper
INFO - 2024-05-12 15:04:00 --> Helper loaded: file_helper
INFO - 2024-05-12 15:04:00 --> Helper loaded: html_helper
INFO - 2024-05-12 15:04:00 --> Helper loaded: text_helper
INFO - 2024-05-12 15:04:00 --> Helper loaded: form_helper
INFO - 2024-05-12 15:04:00 --> Helper loaded: lang_helper
INFO - 2024-05-12 15:04:00 --> Helper loaded: security_helper
INFO - 2024-05-12 15:04:00 --> Helper loaded: cookie_helper
INFO - 2024-05-12 15:04:00 --> Database Driver Class Initialized
INFO - 2024-05-12 15:04:00 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-12 15:04:00 --> Parser Class Initialized
INFO - 2024-05-12 15:04:00 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-05-12 15:04:00 --> Pagination Class Initialized
INFO - 2024-05-12 15:04:00 --> Form Validation Class Initialized
INFO - 2024-05-12 15:04:00 --> Controller Class Initialized
INFO - 2024-05-12 15:04:00 --> Model Class Initialized
DEBUG - 2024-05-12 15:04:00 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-05-12 15:04:00 --> Session class already loaded. Second attempt ignored.
INFO - 2024-05-12 15:04:00 --> Model Class Initialized
DEBUG - 2024-05-12 15:04:00 --> Session class already loaded. Second attempt ignored.
INFO - 2024-05-12 15:04:00 --> Model Class Initialized
ERROR - 2024-05-12 15:04:00 --> Severity: Warning --> Invalid argument supplied for foreach() E:\xampp\htdocs\maurnaturo\application\views\invoice\add_invoice_form.php 195
INFO - 2024-05-12 15:04:00 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\invoice/add_invoice_form.php
DEBUG - 2024-05-12 15:04:00 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-05-12 15:04:00 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\include/top_menu.php
INFO - 2024-05-12 15:04:00 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\include/admin_loggedin_info.php
INFO - 2024-05-12 15:04:00 --> Model Class Initialized
INFO - 2024-05-12 15:04:00 --> Model Class Initialized
INFO - 2024-05-12 15:04:00 --> Model Class Initialized
INFO - 2024-05-12 15:04:02 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\include/admin_header.php
INFO - 2024-05-12 15:04:02 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\include/admin_footer.php
INFO - 2024-05-12 15:04:02 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\admin_html_template.php
INFO - 2024-05-12 15:04:02 --> Final output sent to browser
DEBUG - 2024-05-12 15:04:02 --> Total execution time: 2.0532
ERROR - 2024-05-12 15:04:26 --> $config['composer_autoload'] is set to TRUE but E:\xampp\htdocs\maurnaturo\application\vendor/autoload.php was not found.
INFO - 2024-05-12 15:04:26 --> Config Class Initialized
INFO - 2024-05-12 15:04:26 --> Hooks Class Initialized
DEBUG - 2024-05-12 15:04:26 --> UTF-8 Support Enabled
INFO - 2024-05-12 15:04:26 --> Utf8 Class Initialized
INFO - 2024-05-12 15:04:26 --> URI Class Initialized
INFO - 2024-05-12 15:04:26 --> Router Class Initialized
INFO - 2024-05-12 15:04:26 --> Output Class Initialized
INFO - 2024-05-12 15:04:26 --> Security Class Initialized
DEBUG - 2024-05-12 15:04:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-12 15:04:26 --> Input Class Initialized
INFO - 2024-05-12 15:04:26 --> Language Class Initialized
INFO - 2024-05-12 15:04:26 --> Loader Class Initialized
INFO - 2024-05-12 15:04:26 --> Helper loaded: url_helper
INFO - 2024-05-12 15:04:26 --> Helper loaded: file_helper
INFO - 2024-05-12 15:04:26 --> Helper loaded: html_helper
INFO - 2024-05-12 15:04:26 --> Helper loaded: text_helper
INFO - 2024-05-12 15:04:26 --> Helper loaded: form_helper
INFO - 2024-05-12 15:04:26 --> Helper loaded: lang_helper
INFO - 2024-05-12 15:04:26 --> Helper loaded: security_helper
INFO - 2024-05-12 15:04:26 --> Helper loaded: cookie_helper
INFO - 2024-05-12 15:04:26 --> Database Driver Class Initialized
INFO - 2024-05-12 15:04:26 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-12 15:04:26 --> Parser Class Initialized
INFO - 2024-05-12 15:04:26 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-05-12 15:04:26 --> Pagination Class Initialized
INFO - 2024-05-12 15:04:26 --> Form Validation Class Initialized
INFO - 2024-05-12 15:04:26 --> Controller Class Initialized
INFO - 2024-05-12 15:04:26 --> Model Class Initialized
DEBUG - 2024-05-12 15:04:26 --> Session class already loaded. Second attempt ignored.
INFO - 2024-05-12 15:04:26 --> Final output sent to browser
DEBUG - 2024-05-12 15:04:26 --> Total execution time: 0.0826
ERROR - 2024-05-12 15:04:28 --> $config['composer_autoload'] is set to TRUE but E:\xampp\htdocs\maurnaturo\application\vendor/autoload.php was not found.
INFO - 2024-05-12 15:04:28 --> Config Class Initialized
INFO - 2024-05-12 15:04:28 --> Hooks Class Initialized
DEBUG - 2024-05-12 15:04:28 --> UTF-8 Support Enabled
INFO - 2024-05-12 15:04:28 --> Utf8 Class Initialized
INFO - 2024-05-12 15:04:28 --> URI Class Initialized
INFO - 2024-05-12 15:04:28 --> Router Class Initialized
INFO - 2024-05-12 15:04:28 --> Output Class Initialized
INFO - 2024-05-12 15:04:28 --> Security Class Initialized
DEBUG - 2024-05-12 15:04:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-12 15:04:28 --> Input Class Initialized
INFO - 2024-05-12 15:04:28 --> Language Class Initialized
INFO - 2024-05-12 15:04:28 --> Loader Class Initialized
INFO - 2024-05-12 15:04:28 --> Helper loaded: url_helper
INFO - 2024-05-12 15:04:28 --> Helper loaded: file_helper
INFO - 2024-05-12 15:04:28 --> Helper loaded: html_helper
INFO - 2024-05-12 15:04:28 --> Helper loaded: text_helper
INFO - 2024-05-12 15:04:28 --> Helper loaded: form_helper
INFO - 2024-05-12 15:04:28 --> Helper loaded: lang_helper
INFO - 2024-05-12 15:04:28 --> Helper loaded: security_helper
INFO - 2024-05-12 15:04:28 --> Helper loaded: cookie_helper
INFO - 2024-05-12 15:04:28 --> Database Driver Class Initialized
INFO - 2024-05-12 15:04:28 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-12 15:04:28 --> Parser Class Initialized
INFO - 2024-05-12 15:04:28 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-05-12 15:04:28 --> Pagination Class Initialized
INFO - 2024-05-12 15:04:28 --> Form Validation Class Initialized
INFO - 2024-05-12 15:04:28 --> Controller Class Initialized
INFO - 2024-05-12 15:04:28 --> Model Class Initialized
DEBUG - 2024-05-12 15:04:28 --> Session class already loaded. Second attempt ignored.
INFO - 2024-05-12 15:04:28 --> Final output sent to browser
DEBUG - 2024-05-12 15:04:28 --> Total execution time: 0.0806
ERROR - 2024-05-12 15:56:06 --> $config['composer_autoload'] is set to TRUE but E:\xampp\htdocs\maurnaturo\application\vendor/autoload.php was not found.
INFO - 2024-05-12 15:56:06 --> Config Class Initialized
INFO - 2024-05-12 15:56:06 --> Hooks Class Initialized
DEBUG - 2024-05-12 15:56:06 --> UTF-8 Support Enabled
INFO - 2024-05-12 15:56:06 --> Utf8 Class Initialized
INFO - 2024-05-12 15:56:06 --> URI Class Initialized
INFO - 2024-05-12 15:56:06 --> Router Class Initialized
INFO - 2024-05-12 15:56:06 --> Output Class Initialized
INFO - 2024-05-12 15:56:06 --> Security Class Initialized
DEBUG - 2024-05-12 15:56:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-12 15:56:06 --> Input Class Initialized
INFO - 2024-05-12 15:56:06 --> Language Class Initialized
INFO - 2024-05-12 15:56:06 --> Loader Class Initialized
INFO - 2024-05-12 15:56:06 --> Helper loaded: url_helper
INFO - 2024-05-12 15:56:06 --> Helper loaded: file_helper
INFO - 2024-05-12 15:56:06 --> Helper loaded: html_helper
INFO - 2024-05-12 15:56:06 --> Helper loaded: text_helper
INFO - 2024-05-12 15:56:06 --> Helper loaded: form_helper
INFO - 2024-05-12 15:56:06 --> Helper loaded: lang_helper
INFO - 2024-05-12 15:56:06 --> Helper loaded: security_helper
INFO - 2024-05-12 15:56:06 --> Helper loaded: cookie_helper
INFO - 2024-05-12 15:56:06 --> Database Driver Class Initialized
INFO - 2024-05-12 15:56:06 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-12 15:56:06 --> Parser Class Initialized
INFO - 2024-05-12 15:56:06 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-05-12 15:56:06 --> Pagination Class Initialized
INFO - 2024-05-12 15:56:06 --> Form Validation Class Initialized
INFO - 2024-05-12 15:56:06 --> Controller Class Initialized
DEBUG - 2024-05-12 15:56:06 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-05-12 15:56:06 --> Session class already loaded. Second attempt ignored.
INFO - 2024-05-12 15:56:06 --> Model Class Initialized
INFO - 2024-05-12 15:56:06 --> Model Class Initialized
DEBUG - 2024-05-12 15:56:06 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-05-12 15:56:06 --> Session class already loaded. Second attempt ignored.
INFO - 2024-05-12 15:56:06 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\mr_payments/add_payment_form.php
DEBUG - 2024-05-12 15:56:06 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-05-12 15:56:06 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\include/top_menu.php
INFO - 2024-05-12 15:56:06 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\include/admin_loggedin_info.php
INFO - 2024-05-12 15:56:06 --> Model Class Initialized
INFO - 2024-05-12 15:56:06 --> Model Class Initialized
INFO - 2024-05-12 15:56:06 --> Model Class Initialized
INFO - 2024-05-12 15:56:06 --> Model Class Initialized
INFO - 2024-05-12 15:56:08 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\include/admin_header.php
INFO - 2024-05-12 15:56:08 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\include/admin_footer.php
INFO - 2024-05-12 15:56:08 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\admin_html_template.php
INFO - 2024-05-12 15:56:08 --> Final output sent to browser
DEBUG - 2024-05-12 15:56:08 --> Total execution time: 1.9076
ERROR - 2024-05-12 15:56:16 --> $config['composer_autoload'] is set to TRUE but E:\xampp\htdocs\maurnaturo\application\vendor/autoload.php was not found.
INFO - 2024-05-12 15:56:16 --> Config Class Initialized
INFO - 2024-05-12 15:56:16 --> Hooks Class Initialized
DEBUG - 2024-05-12 15:56:16 --> UTF-8 Support Enabled
INFO - 2024-05-12 15:56:16 --> Utf8 Class Initialized
INFO - 2024-05-12 15:56:16 --> URI Class Initialized
INFO - 2024-05-12 15:56:16 --> Router Class Initialized
INFO - 2024-05-12 15:56:16 --> Output Class Initialized
INFO - 2024-05-12 15:56:16 --> Security Class Initialized
DEBUG - 2024-05-12 15:56:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-12 15:56:16 --> Input Class Initialized
INFO - 2024-05-12 15:56:16 --> Language Class Initialized
INFO - 2024-05-12 15:56:16 --> Loader Class Initialized
INFO - 2024-05-12 15:56:16 --> Helper loaded: url_helper
INFO - 2024-05-12 15:56:16 --> Helper loaded: file_helper
INFO - 2024-05-12 15:56:16 --> Helper loaded: html_helper
INFO - 2024-05-12 15:56:16 --> Helper loaded: text_helper
INFO - 2024-05-12 15:56:16 --> Helper loaded: form_helper
INFO - 2024-05-12 15:56:16 --> Helper loaded: lang_helper
INFO - 2024-05-12 15:56:16 --> Helper loaded: security_helper
INFO - 2024-05-12 15:56:16 --> Helper loaded: cookie_helper
INFO - 2024-05-12 15:56:16 --> Database Driver Class Initialized
INFO - 2024-05-12 15:56:16 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-12 15:56:16 --> Parser Class Initialized
INFO - 2024-05-12 15:56:16 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-05-12 15:56:16 --> Pagination Class Initialized
INFO - 2024-05-12 15:56:16 --> Form Validation Class Initialized
INFO - 2024-05-12 15:56:16 --> Controller Class Initialized
DEBUG - 2024-05-12 15:56:16 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-05-12 15:56:16 --> Session class already loaded. Second attempt ignored.
INFO - 2024-05-12 15:56:16 --> Model Class Initialized
INFO - 2024-05-12 15:56:16 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\payments/add_payment_form.php
DEBUG - 2024-05-12 15:56:16 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-05-12 15:56:16 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\include/top_menu.php
INFO - 2024-05-12 15:56:16 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\include/admin_loggedin_info.php
INFO - 2024-05-12 15:56:16 --> Model Class Initialized
INFO - 2024-05-12 15:56:16 --> Model Class Initialized
INFO - 2024-05-12 15:56:16 --> Model Class Initialized
INFO - 2024-05-12 15:56:16 --> Model Class Initialized
INFO - 2024-05-12 15:56:18 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\include/admin_header.php
INFO - 2024-05-12 15:56:18 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\include/admin_footer.php
INFO - 2024-05-12 15:56:18 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\admin_html_template.php
INFO - 2024-05-12 15:56:18 --> Final output sent to browser
DEBUG - 2024-05-12 15:56:18 --> Total execution time: 1.7585
ERROR - 2024-05-12 15:56:31 --> $config['composer_autoload'] is set to TRUE but E:\xampp\htdocs\maurnaturo\application\vendor/autoload.php was not found.
INFO - 2024-05-12 15:56:31 --> Config Class Initialized
INFO - 2024-05-12 15:56:31 --> Hooks Class Initialized
DEBUG - 2024-05-12 15:56:31 --> UTF-8 Support Enabled
INFO - 2024-05-12 15:56:31 --> Utf8 Class Initialized
INFO - 2024-05-12 15:56:31 --> URI Class Initialized
INFO - 2024-05-12 15:56:31 --> Router Class Initialized
INFO - 2024-05-12 15:56:31 --> Output Class Initialized
INFO - 2024-05-12 15:56:31 --> Security Class Initialized
DEBUG - 2024-05-12 15:56:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-12 15:56:31 --> Input Class Initialized
INFO - 2024-05-12 15:56:31 --> Language Class Initialized
INFO - 2024-05-12 15:56:31 --> Loader Class Initialized
INFO - 2024-05-12 15:56:31 --> Helper loaded: url_helper
INFO - 2024-05-12 15:56:31 --> Helper loaded: file_helper
INFO - 2024-05-12 15:56:31 --> Helper loaded: html_helper
INFO - 2024-05-12 15:56:31 --> Helper loaded: text_helper
INFO - 2024-05-12 15:56:31 --> Helper loaded: form_helper
INFO - 2024-05-12 15:56:31 --> Helper loaded: lang_helper
INFO - 2024-05-12 15:56:31 --> Helper loaded: security_helper
INFO - 2024-05-12 15:56:31 --> Helper loaded: cookie_helper
INFO - 2024-05-12 15:56:31 --> Database Driver Class Initialized
INFO - 2024-05-12 15:56:31 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-12 15:56:31 --> Parser Class Initialized
INFO - 2024-05-12 15:56:31 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-05-12 15:56:31 --> Pagination Class Initialized
INFO - 2024-05-12 15:56:31 --> Form Validation Class Initialized
INFO - 2024-05-12 15:56:31 --> Controller Class Initialized
INFO - 2024-05-12 15:56:31 --> Model Class Initialized
DEBUG - 2024-05-12 15:56:31 --> Session class already loaded. Second attempt ignored.
INFO - 2024-05-12 15:56:31 --> Final output sent to browser
DEBUG - 2024-05-12 15:56:31 --> Total execution time: 0.0746
ERROR - 2024-05-12 15:56:32 --> $config['composer_autoload'] is set to TRUE but E:\xampp\htdocs\maurnaturo\application\vendor/autoload.php was not found.
INFO - 2024-05-12 15:56:32 --> Config Class Initialized
INFO - 2024-05-12 15:56:32 --> Hooks Class Initialized
DEBUG - 2024-05-12 15:56:32 --> UTF-8 Support Enabled
INFO - 2024-05-12 15:56:32 --> Utf8 Class Initialized
INFO - 2024-05-12 15:56:32 --> URI Class Initialized
INFO - 2024-05-12 15:56:32 --> Router Class Initialized
INFO - 2024-05-12 15:56:32 --> Output Class Initialized
INFO - 2024-05-12 15:56:32 --> Security Class Initialized
DEBUG - 2024-05-12 15:56:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-12 15:56:32 --> Input Class Initialized
INFO - 2024-05-12 15:56:32 --> Language Class Initialized
INFO - 2024-05-12 15:56:32 --> Loader Class Initialized
INFO - 2024-05-12 15:56:32 --> Helper loaded: url_helper
INFO - 2024-05-12 15:56:32 --> Helper loaded: file_helper
INFO - 2024-05-12 15:56:32 --> Helper loaded: html_helper
INFO - 2024-05-12 15:56:32 --> Helper loaded: text_helper
INFO - 2024-05-12 15:56:32 --> Helper loaded: form_helper
INFO - 2024-05-12 15:56:32 --> Helper loaded: lang_helper
INFO - 2024-05-12 15:56:32 --> Helper loaded: security_helper
INFO - 2024-05-12 15:56:32 --> Helper loaded: cookie_helper
INFO - 2024-05-12 15:56:32 --> Database Driver Class Initialized
INFO - 2024-05-12 15:56:32 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-12 15:56:32 --> Parser Class Initialized
INFO - 2024-05-12 15:56:32 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-05-12 15:56:32 --> Pagination Class Initialized
INFO - 2024-05-12 15:56:32 --> Form Validation Class Initialized
INFO - 2024-05-12 15:56:32 --> Controller Class Initialized
INFO - 2024-05-12 15:56:32 --> Model Class Initialized
DEBUG - 2024-05-12 15:56:32 --> Session class already loaded. Second attempt ignored.
INFO - 2024-05-12 15:56:32 --> Final output sent to browser
DEBUG - 2024-05-12 15:56:32 --> Total execution time: 0.0784
ERROR - 2024-05-12 15:57:42 --> $config['composer_autoload'] is set to TRUE but E:\xampp\htdocs\maurnaturo\application\vendor/autoload.php was not found.
INFO - 2024-05-12 15:57:42 --> Config Class Initialized
INFO - 2024-05-12 15:57:42 --> Hooks Class Initialized
DEBUG - 2024-05-12 15:57:42 --> UTF-8 Support Enabled
INFO - 2024-05-12 15:57:42 --> Utf8 Class Initialized
INFO - 2024-05-12 15:57:42 --> URI Class Initialized
INFO - 2024-05-12 15:57:42 --> Router Class Initialized
INFO - 2024-05-12 15:57:42 --> Output Class Initialized
INFO - 2024-05-12 15:57:42 --> Security Class Initialized
DEBUG - 2024-05-12 15:57:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-12 15:57:42 --> Input Class Initialized
INFO - 2024-05-12 15:57:42 --> Language Class Initialized
INFO - 2024-05-12 15:57:42 --> Loader Class Initialized
INFO - 2024-05-12 15:57:42 --> Helper loaded: url_helper
INFO - 2024-05-12 15:57:42 --> Helper loaded: file_helper
INFO - 2024-05-12 15:57:42 --> Helper loaded: html_helper
INFO - 2024-05-12 15:57:42 --> Helper loaded: text_helper
INFO - 2024-05-12 15:57:42 --> Helper loaded: form_helper
INFO - 2024-05-12 15:57:42 --> Helper loaded: lang_helper
INFO - 2024-05-12 15:57:42 --> Helper loaded: security_helper
INFO - 2024-05-12 15:57:42 --> Helper loaded: cookie_helper
INFO - 2024-05-12 15:57:42 --> Database Driver Class Initialized
INFO - 2024-05-12 15:57:42 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-12 15:57:42 --> Parser Class Initialized
INFO - 2024-05-12 15:57:42 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-05-12 15:57:42 --> Pagination Class Initialized
INFO - 2024-05-12 15:57:42 --> Form Validation Class Initialized
INFO - 2024-05-12 15:57:42 --> Controller Class Initialized
DEBUG - 2024-05-12 15:57:42 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-05-12 15:57:42 --> Session class already loaded. Second attempt ignored.
INFO - 2024-05-12 15:57:42 --> Model Class Initialized
INFO - 2024-05-12 15:57:42 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\payments/add_payment_form.php
DEBUG - 2024-05-12 15:57:42 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-05-12 15:57:42 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\include/top_menu.php
INFO - 2024-05-12 15:57:42 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\include/admin_loggedin_info.php
INFO - 2024-05-12 15:57:42 --> Model Class Initialized
INFO - 2024-05-12 15:57:42 --> Model Class Initialized
INFO - 2024-05-12 15:57:42 --> Model Class Initialized
INFO - 2024-05-12 15:57:42 --> Model Class Initialized
INFO - 2024-05-12 15:57:44 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\include/admin_header.php
INFO - 2024-05-12 15:57:44 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\include/admin_footer.php
INFO - 2024-05-12 15:57:44 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\admin_html_template.php
INFO - 2024-05-12 15:57:44 --> Final output sent to browser
DEBUG - 2024-05-12 15:57:44 --> Total execution time: 1.7779
ERROR - 2024-05-12 15:59:12 --> $config['composer_autoload'] is set to TRUE but E:\xampp\htdocs\maurnaturo\application\vendor/autoload.php was not found.
INFO - 2024-05-12 15:59:12 --> Config Class Initialized
INFO - 2024-05-12 15:59:12 --> Hooks Class Initialized
DEBUG - 2024-05-12 15:59:12 --> UTF-8 Support Enabled
INFO - 2024-05-12 15:59:12 --> Utf8 Class Initialized
INFO - 2024-05-12 15:59:12 --> URI Class Initialized
INFO - 2024-05-12 15:59:12 --> Router Class Initialized
INFO - 2024-05-12 15:59:12 --> Output Class Initialized
INFO - 2024-05-12 15:59:12 --> Security Class Initialized
DEBUG - 2024-05-12 15:59:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-12 15:59:12 --> Input Class Initialized
INFO - 2024-05-12 15:59:12 --> Language Class Initialized
INFO - 2024-05-12 15:59:12 --> Loader Class Initialized
INFO - 2024-05-12 15:59:12 --> Helper loaded: url_helper
INFO - 2024-05-12 15:59:12 --> Helper loaded: file_helper
INFO - 2024-05-12 15:59:12 --> Helper loaded: html_helper
INFO - 2024-05-12 15:59:12 --> Helper loaded: text_helper
INFO - 2024-05-12 15:59:12 --> Helper loaded: form_helper
INFO - 2024-05-12 15:59:12 --> Helper loaded: lang_helper
INFO - 2024-05-12 15:59:12 --> Helper loaded: security_helper
INFO - 2024-05-12 15:59:12 --> Helper loaded: cookie_helper
INFO - 2024-05-12 15:59:12 --> Database Driver Class Initialized
INFO - 2024-05-12 15:59:12 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-12 15:59:12 --> Parser Class Initialized
INFO - 2024-05-12 15:59:12 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-05-12 15:59:12 --> Pagination Class Initialized
INFO - 2024-05-12 15:59:12 --> Form Validation Class Initialized
INFO - 2024-05-12 15:59:12 --> Controller Class Initialized
DEBUG - 2024-05-12 15:59:12 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-05-12 15:59:12 --> Session class already loaded. Second attempt ignored.
INFO - 2024-05-12 15:59:12 --> Model Class Initialized
INFO - 2024-05-12 15:59:12 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\payments/add_payment_form.php
DEBUG - 2024-05-12 15:59:12 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-05-12 15:59:12 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\include/top_menu.php
INFO - 2024-05-12 15:59:12 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\include/admin_loggedin_info.php
INFO - 2024-05-12 15:59:12 --> Model Class Initialized
INFO - 2024-05-12 15:59:12 --> Model Class Initialized
INFO - 2024-05-12 15:59:12 --> Model Class Initialized
INFO - 2024-05-12 15:59:12 --> Model Class Initialized
INFO - 2024-05-12 15:59:14 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\include/admin_header.php
INFO - 2024-05-12 15:59:14 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\include/admin_footer.php
INFO - 2024-05-12 15:59:14 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\admin_html_template.php
INFO - 2024-05-12 15:59:14 --> Final output sent to browser
DEBUG - 2024-05-12 15:59:14 --> Total execution time: 1.5650
ERROR - 2024-05-12 15:59:24 --> $config['composer_autoload'] is set to TRUE but E:\xampp\htdocs\maurnaturo\application\vendor/autoload.php was not found.
INFO - 2024-05-12 15:59:24 --> Config Class Initialized
INFO - 2024-05-12 15:59:24 --> Hooks Class Initialized
DEBUG - 2024-05-12 15:59:24 --> UTF-8 Support Enabled
INFO - 2024-05-12 15:59:24 --> Utf8 Class Initialized
INFO - 2024-05-12 15:59:24 --> URI Class Initialized
INFO - 2024-05-12 15:59:24 --> Router Class Initialized
INFO - 2024-05-12 15:59:24 --> Output Class Initialized
INFO - 2024-05-12 15:59:24 --> Security Class Initialized
DEBUG - 2024-05-12 15:59:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-12 15:59:24 --> Input Class Initialized
INFO - 2024-05-12 15:59:24 --> Language Class Initialized
INFO - 2024-05-12 15:59:24 --> Loader Class Initialized
INFO - 2024-05-12 15:59:24 --> Helper loaded: url_helper
INFO - 2024-05-12 15:59:24 --> Helper loaded: file_helper
INFO - 2024-05-12 15:59:24 --> Helper loaded: html_helper
INFO - 2024-05-12 15:59:24 --> Helper loaded: text_helper
INFO - 2024-05-12 15:59:24 --> Helper loaded: form_helper
INFO - 2024-05-12 15:59:24 --> Helper loaded: lang_helper
INFO - 2024-05-12 15:59:24 --> Helper loaded: security_helper
INFO - 2024-05-12 15:59:24 --> Helper loaded: cookie_helper
INFO - 2024-05-12 15:59:24 --> Database Driver Class Initialized
INFO - 2024-05-12 15:59:24 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-12 15:59:24 --> Parser Class Initialized
INFO - 2024-05-12 15:59:24 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-05-12 15:59:24 --> Pagination Class Initialized
INFO - 2024-05-12 15:59:24 --> Form Validation Class Initialized
INFO - 2024-05-12 15:59:24 --> Controller Class Initialized
INFO - 2024-05-12 15:59:24 --> Model Class Initialized
DEBUG - 2024-05-12 15:59:24 --> Session class already loaded. Second attempt ignored.
ERROR - 2024-05-12 15:59:24 --> Severity: Warning --> Invalid argument supplied for foreach() E:\xampp\htdocs\maurnaturo\application\controllers\Cinvoice.php 616
INFO - 2024-05-12 15:59:24 --> Final output sent to browser
DEBUG - 2024-05-12 15:59:24 --> Total execution time: 0.0763
ERROR - 2024-05-12 15:59:25 --> $config['composer_autoload'] is set to TRUE but E:\xampp\htdocs\maurnaturo\application\vendor/autoload.php was not found.
INFO - 2024-05-12 15:59:25 --> Config Class Initialized
INFO - 2024-05-12 15:59:25 --> Hooks Class Initialized
DEBUG - 2024-05-12 15:59:25 --> UTF-8 Support Enabled
INFO - 2024-05-12 15:59:25 --> Utf8 Class Initialized
INFO - 2024-05-12 15:59:25 --> URI Class Initialized
INFO - 2024-05-12 15:59:25 --> Router Class Initialized
INFO - 2024-05-12 15:59:25 --> Output Class Initialized
INFO - 2024-05-12 15:59:25 --> Security Class Initialized
DEBUG - 2024-05-12 15:59:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-12 15:59:25 --> Input Class Initialized
INFO - 2024-05-12 15:59:25 --> Language Class Initialized
INFO - 2024-05-12 15:59:25 --> Loader Class Initialized
INFO - 2024-05-12 15:59:25 --> Helper loaded: url_helper
INFO - 2024-05-12 15:59:25 --> Helper loaded: file_helper
INFO - 2024-05-12 15:59:25 --> Helper loaded: html_helper
INFO - 2024-05-12 15:59:25 --> Helper loaded: text_helper
INFO - 2024-05-12 15:59:25 --> Helper loaded: form_helper
INFO - 2024-05-12 15:59:25 --> Helper loaded: lang_helper
INFO - 2024-05-12 15:59:25 --> Helper loaded: security_helper
INFO - 2024-05-12 15:59:25 --> Helper loaded: cookie_helper
INFO - 2024-05-12 15:59:25 --> Database Driver Class Initialized
INFO - 2024-05-12 15:59:25 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-12 15:59:25 --> Parser Class Initialized
INFO - 2024-05-12 15:59:25 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-05-12 15:59:25 --> Pagination Class Initialized
INFO - 2024-05-12 15:59:25 --> Form Validation Class Initialized
INFO - 2024-05-12 15:59:25 --> Controller Class Initialized
INFO - 2024-05-12 15:59:25 --> Model Class Initialized
DEBUG - 2024-05-12 15:59:25 --> Session class already loaded. Second attempt ignored.
ERROR - 2024-05-12 15:59:25 --> Severity: Warning --> Invalid argument supplied for foreach() E:\xampp\htdocs\maurnaturo\application\controllers\Cinvoice.php 616
INFO - 2024-05-12 15:59:25 --> Final output sent to browser
DEBUG - 2024-05-12 15:59:25 --> Total execution time: 0.0756
ERROR - 2024-05-12 15:59:25 --> $config['composer_autoload'] is set to TRUE but E:\xampp\htdocs\maurnaturo\application\vendor/autoload.php was not found.
INFO - 2024-05-12 15:59:25 --> Config Class Initialized
INFO - 2024-05-12 15:59:25 --> Hooks Class Initialized
DEBUG - 2024-05-12 15:59:25 --> UTF-8 Support Enabled
INFO - 2024-05-12 15:59:25 --> Utf8 Class Initialized
INFO - 2024-05-12 15:59:25 --> URI Class Initialized
INFO - 2024-05-12 15:59:25 --> Router Class Initialized
INFO - 2024-05-12 15:59:25 --> Output Class Initialized
INFO - 2024-05-12 15:59:25 --> Security Class Initialized
DEBUG - 2024-05-12 15:59:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-12 15:59:25 --> Input Class Initialized
INFO - 2024-05-12 15:59:25 --> Language Class Initialized
INFO - 2024-05-12 15:59:25 --> Loader Class Initialized
INFO - 2024-05-12 15:59:25 --> Helper loaded: url_helper
INFO - 2024-05-12 15:59:25 --> Helper loaded: file_helper
INFO - 2024-05-12 15:59:25 --> Helper loaded: html_helper
INFO - 2024-05-12 15:59:25 --> Helper loaded: text_helper
INFO - 2024-05-12 15:59:25 --> Helper loaded: form_helper
INFO - 2024-05-12 15:59:25 --> Helper loaded: lang_helper
INFO - 2024-05-12 15:59:25 --> Helper loaded: security_helper
INFO - 2024-05-12 15:59:25 --> Helper loaded: cookie_helper
INFO - 2024-05-12 15:59:25 --> Database Driver Class Initialized
INFO - 2024-05-12 15:59:25 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-12 15:59:26 --> Parser Class Initialized
INFO - 2024-05-12 15:59:26 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-05-12 15:59:26 --> Pagination Class Initialized
INFO - 2024-05-12 15:59:26 --> Form Validation Class Initialized
INFO - 2024-05-12 15:59:26 --> Controller Class Initialized
INFO - 2024-05-12 15:59:26 --> Model Class Initialized
DEBUG - 2024-05-12 15:59:26 --> Session class already loaded. Second attempt ignored.
ERROR - 2024-05-12 15:59:26 --> Severity: Warning --> Invalid argument supplied for foreach() E:\xampp\htdocs\maurnaturo\application\controllers\Cinvoice.php 616
INFO - 2024-05-12 15:59:26 --> Final output sent to browser
DEBUG - 2024-05-12 15:59:26 --> Total execution time: 0.0726
ERROR - 2024-05-12 15:59:26 --> $config['composer_autoload'] is set to TRUE but E:\xampp\htdocs\maurnaturo\application\vendor/autoload.php was not found.
INFO - 2024-05-12 15:59:26 --> Config Class Initialized
INFO - 2024-05-12 15:59:26 --> Hooks Class Initialized
DEBUG - 2024-05-12 15:59:26 --> UTF-8 Support Enabled
INFO - 2024-05-12 15:59:26 --> Utf8 Class Initialized
INFO - 2024-05-12 15:59:26 --> URI Class Initialized
INFO - 2024-05-12 15:59:26 --> Router Class Initialized
INFO - 2024-05-12 15:59:26 --> Output Class Initialized
INFO - 2024-05-12 15:59:26 --> Security Class Initialized
DEBUG - 2024-05-12 15:59:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-12 15:59:26 --> Input Class Initialized
INFO - 2024-05-12 15:59:26 --> Language Class Initialized
INFO - 2024-05-12 15:59:26 --> Loader Class Initialized
INFO - 2024-05-12 15:59:26 --> Helper loaded: url_helper
INFO - 2024-05-12 15:59:26 --> Helper loaded: file_helper
INFO - 2024-05-12 15:59:26 --> Helper loaded: html_helper
INFO - 2024-05-12 15:59:26 --> Helper loaded: text_helper
INFO - 2024-05-12 15:59:26 --> Helper loaded: form_helper
INFO - 2024-05-12 15:59:26 --> Helper loaded: lang_helper
INFO - 2024-05-12 15:59:26 --> Helper loaded: security_helper
INFO - 2024-05-12 15:59:26 --> Helper loaded: cookie_helper
INFO - 2024-05-12 15:59:26 --> Database Driver Class Initialized
INFO - 2024-05-12 15:59:26 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-12 15:59:26 --> Parser Class Initialized
INFO - 2024-05-12 15:59:26 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-05-12 15:59:26 --> Pagination Class Initialized
INFO - 2024-05-12 15:59:26 --> Form Validation Class Initialized
INFO - 2024-05-12 15:59:26 --> Controller Class Initialized
INFO - 2024-05-12 15:59:26 --> Model Class Initialized
DEBUG - 2024-05-12 15:59:26 --> Session class already loaded. Second attempt ignored.
ERROR - 2024-05-12 15:59:26 --> Severity: Warning --> Invalid argument supplied for foreach() E:\xampp\htdocs\maurnaturo\application\controllers\Cinvoice.php 616
INFO - 2024-05-12 15:59:26 --> Final output sent to browser
DEBUG - 2024-05-12 15:59:26 --> Total execution time: 0.0806
ERROR - 2024-05-12 15:59:27 --> $config['composer_autoload'] is set to TRUE but E:\xampp\htdocs\maurnaturo\application\vendor/autoload.php was not found.
INFO - 2024-05-12 15:59:27 --> Config Class Initialized
INFO - 2024-05-12 15:59:27 --> Hooks Class Initialized
DEBUG - 2024-05-12 15:59:27 --> UTF-8 Support Enabled
INFO - 2024-05-12 15:59:27 --> Utf8 Class Initialized
INFO - 2024-05-12 15:59:27 --> URI Class Initialized
INFO - 2024-05-12 15:59:27 --> Router Class Initialized
INFO - 2024-05-12 15:59:27 --> Output Class Initialized
INFO - 2024-05-12 15:59:27 --> Security Class Initialized
DEBUG - 2024-05-12 15:59:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-12 15:59:27 --> Input Class Initialized
INFO - 2024-05-12 15:59:27 --> Language Class Initialized
INFO - 2024-05-12 15:59:27 --> Loader Class Initialized
INFO - 2024-05-12 15:59:27 --> Helper loaded: url_helper
INFO - 2024-05-12 15:59:27 --> Helper loaded: file_helper
INFO - 2024-05-12 15:59:27 --> Helper loaded: html_helper
INFO - 2024-05-12 15:59:27 --> Helper loaded: text_helper
INFO - 2024-05-12 15:59:27 --> Helper loaded: form_helper
INFO - 2024-05-12 15:59:27 --> Helper loaded: lang_helper
INFO - 2024-05-12 15:59:27 --> Helper loaded: security_helper
INFO - 2024-05-12 15:59:27 --> Helper loaded: cookie_helper
INFO - 2024-05-12 15:59:27 --> Database Driver Class Initialized
INFO - 2024-05-12 15:59:27 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-12 15:59:27 --> Parser Class Initialized
INFO - 2024-05-12 15:59:27 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-05-12 15:59:27 --> Pagination Class Initialized
INFO - 2024-05-12 15:59:27 --> Form Validation Class Initialized
INFO - 2024-05-12 15:59:27 --> Controller Class Initialized
INFO - 2024-05-12 15:59:27 --> Model Class Initialized
DEBUG - 2024-05-12 15:59:27 --> Session class already loaded. Second attempt ignored.
ERROR - 2024-05-12 15:59:27 --> Severity: Warning --> Invalid argument supplied for foreach() E:\xampp\htdocs\maurnaturo\application\controllers\Cinvoice.php 616
INFO - 2024-05-12 15:59:27 --> Final output sent to browser
DEBUG - 2024-05-12 15:59:27 --> Total execution time: 0.0760
ERROR - 2024-05-12 15:59:28 --> $config['composer_autoload'] is set to TRUE but E:\xampp\htdocs\maurnaturo\application\vendor/autoload.php was not found.
INFO - 2024-05-12 15:59:28 --> Config Class Initialized
INFO - 2024-05-12 15:59:28 --> Hooks Class Initialized
DEBUG - 2024-05-12 15:59:28 --> UTF-8 Support Enabled
INFO - 2024-05-12 15:59:28 --> Utf8 Class Initialized
INFO - 2024-05-12 15:59:28 --> URI Class Initialized
INFO - 2024-05-12 15:59:28 --> Router Class Initialized
INFO - 2024-05-12 15:59:28 --> Output Class Initialized
INFO - 2024-05-12 15:59:28 --> Security Class Initialized
DEBUG - 2024-05-12 15:59:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-12 15:59:28 --> Input Class Initialized
INFO - 2024-05-12 15:59:28 --> Language Class Initialized
INFO - 2024-05-12 15:59:28 --> Loader Class Initialized
INFO - 2024-05-12 15:59:28 --> Helper loaded: url_helper
INFO - 2024-05-12 15:59:28 --> Helper loaded: file_helper
INFO - 2024-05-12 15:59:28 --> Helper loaded: html_helper
INFO - 2024-05-12 15:59:28 --> Helper loaded: text_helper
INFO - 2024-05-12 15:59:28 --> Helper loaded: form_helper
INFO - 2024-05-12 15:59:28 --> Helper loaded: lang_helper
INFO - 2024-05-12 15:59:28 --> Helper loaded: security_helper
INFO - 2024-05-12 15:59:28 --> Helper loaded: cookie_helper
INFO - 2024-05-12 15:59:28 --> Database Driver Class Initialized
INFO - 2024-05-12 15:59:28 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-12 15:59:28 --> Parser Class Initialized
INFO - 2024-05-12 15:59:28 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-05-12 15:59:28 --> Pagination Class Initialized
INFO - 2024-05-12 15:59:28 --> Form Validation Class Initialized
INFO - 2024-05-12 15:59:28 --> Controller Class Initialized
INFO - 2024-05-12 15:59:28 --> Model Class Initialized
DEBUG - 2024-05-12 15:59:28 --> Session class already loaded. Second attempt ignored.
ERROR - 2024-05-12 15:59:28 --> Severity: Warning --> Invalid argument supplied for foreach() E:\xampp\htdocs\maurnaturo\application\controllers\Cinvoice.php 616
INFO - 2024-05-12 15:59:28 --> Final output sent to browser
DEBUG - 2024-05-12 15:59:28 --> Total execution time: 0.1058
ERROR - 2024-05-12 16:47:38 --> $config['composer_autoload'] is set to TRUE but E:\xampp\htdocs\maurnaturo\application\vendor/autoload.php was not found.
INFO - 2024-05-12 16:47:38 --> Config Class Initialized
INFO - 2024-05-12 16:47:38 --> Hooks Class Initialized
DEBUG - 2024-05-12 16:47:38 --> UTF-8 Support Enabled
INFO - 2024-05-12 16:47:38 --> Utf8 Class Initialized
INFO - 2024-05-12 16:47:38 --> URI Class Initialized
INFO - 2024-05-12 16:47:38 --> Router Class Initialized
INFO - 2024-05-12 16:47:38 --> Output Class Initialized
INFO - 2024-05-12 16:47:38 --> Security Class Initialized
DEBUG - 2024-05-12 16:47:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-12 16:47:38 --> Input Class Initialized
INFO - 2024-05-12 16:47:38 --> Language Class Initialized
INFO - 2024-05-12 16:47:38 --> Loader Class Initialized
INFO - 2024-05-12 16:47:38 --> Helper loaded: url_helper
INFO - 2024-05-12 16:47:38 --> Helper loaded: file_helper
INFO - 2024-05-12 16:47:38 --> Helper loaded: html_helper
INFO - 2024-05-12 16:47:38 --> Helper loaded: text_helper
INFO - 2024-05-12 16:47:38 --> Helper loaded: form_helper
INFO - 2024-05-12 16:47:38 --> Helper loaded: lang_helper
INFO - 2024-05-12 16:47:38 --> Helper loaded: security_helper
INFO - 2024-05-12 16:47:38 --> Helper loaded: cookie_helper
INFO - 2024-05-12 16:47:38 --> Database Driver Class Initialized
INFO - 2024-05-12 16:47:38 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-12 16:47:38 --> Parser Class Initialized
INFO - 2024-05-12 16:47:38 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-05-12 16:47:38 --> Pagination Class Initialized
INFO - 2024-05-12 16:47:38 --> Form Validation Class Initialized
INFO - 2024-05-12 16:47:38 --> Controller Class Initialized
INFO - 2024-05-12 16:47:38 --> Model Class Initialized
DEBUG - 2024-05-12 16:47:38 --> Session class already loaded. Second attempt ignored.
INFO - 2024-05-12 16:47:38 --> Final output sent to browser
DEBUG - 2024-05-12 16:47:38 --> Total execution time: 0.0765
ERROR - 2024-05-12 16:47:45 --> $config['composer_autoload'] is set to TRUE but E:\xampp\htdocs\maurnaturo\application\vendor/autoload.php was not found.
INFO - 2024-05-12 16:47:45 --> Config Class Initialized
INFO - 2024-05-12 16:47:45 --> Hooks Class Initialized
DEBUG - 2024-05-12 16:47:45 --> UTF-8 Support Enabled
INFO - 2024-05-12 16:47:45 --> Utf8 Class Initialized
INFO - 2024-05-12 16:47:45 --> URI Class Initialized
INFO - 2024-05-12 16:47:45 --> Router Class Initialized
INFO - 2024-05-12 16:47:45 --> Output Class Initialized
INFO - 2024-05-12 16:47:45 --> Security Class Initialized
DEBUG - 2024-05-12 16:47:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-12 16:47:45 --> Input Class Initialized
INFO - 2024-05-12 16:47:45 --> Language Class Initialized
ERROR - 2024-05-12 16:47:45 --> 404 Page Not Found: Assets/plugins
ERROR - 2024-05-12 16:47:45 --> $config['composer_autoload'] is set to TRUE but E:\xampp\htdocs\maurnaturo\application\vendor/autoload.php was not found.
INFO - 2024-05-12 16:47:45 --> Config Class Initialized
INFO - 2024-05-12 16:47:45 --> Hooks Class Initialized
DEBUG - 2024-05-12 16:47:45 --> UTF-8 Support Enabled
INFO - 2024-05-12 16:47:45 --> Utf8 Class Initialized
INFO - 2024-05-12 16:47:45 --> URI Class Initialized
INFO - 2024-05-12 16:47:45 --> Router Class Initialized
INFO - 2024-05-12 16:47:45 --> Output Class Initialized
INFO - 2024-05-12 16:47:45 --> Security Class Initialized
DEBUG - 2024-05-12 16:47:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-12 16:47:45 --> Input Class Initialized
INFO - 2024-05-12 16:47:45 --> Language Class Initialized
ERROR - 2024-05-12 16:47:45 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2024-05-12 17:00:23 --> $config['composer_autoload'] is set to TRUE but E:\xampp\htdocs\maurnaturo\application\vendor/autoload.php was not found.
INFO - 2024-05-12 17:00:23 --> Config Class Initialized
INFO - 2024-05-12 17:00:23 --> Hooks Class Initialized
DEBUG - 2024-05-12 17:00:23 --> UTF-8 Support Enabled
INFO - 2024-05-12 17:00:23 --> Utf8 Class Initialized
INFO - 2024-05-12 17:00:23 --> URI Class Initialized
INFO - 2024-05-12 17:00:23 --> Router Class Initialized
INFO - 2024-05-12 17:00:23 --> Output Class Initialized
INFO - 2024-05-12 17:00:23 --> Security Class Initialized
DEBUG - 2024-05-12 17:00:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-12 17:00:23 --> Input Class Initialized
INFO - 2024-05-12 17:00:23 --> Language Class Initialized
INFO - 2024-05-12 17:00:23 --> Loader Class Initialized
INFO - 2024-05-12 17:00:23 --> Helper loaded: url_helper
INFO - 2024-05-12 17:00:23 --> Helper loaded: file_helper
INFO - 2024-05-12 17:00:23 --> Helper loaded: html_helper
INFO - 2024-05-12 17:00:23 --> Helper loaded: text_helper
INFO - 2024-05-12 17:00:23 --> Helper loaded: form_helper
INFO - 2024-05-12 17:00:23 --> Helper loaded: lang_helper
INFO - 2024-05-12 17:00:23 --> Helper loaded: security_helper
INFO - 2024-05-12 17:00:23 --> Helper loaded: cookie_helper
INFO - 2024-05-12 17:00:23 --> Database Driver Class Initialized
INFO - 2024-05-12 17:00:23 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-12 17:00:23 --> Parser Class Initialized
INFO - 2024-05-12 17:00:23 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-05-12 17:00:23 --> Pagination Class Initialized
INFO - 2024-05-12 17:00:23 --> Form Validation Class Initialized
INFO - 2024-05-12 17:00:23 --> Controller Class Initialized
DEBUG - 2024-05-12 17:00:23 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-05-12 17:00:23 --> Session class already loaded. Second attempt ignored.
INFO - 2024-05-12 17:00:23 --> Model Class Initialized
DEBUG - 2024-05-12 17:00:23 --> Lpayments class already loaded. Second attempt ignored.
INFO - 2024-05-12 17:00:23 --> Model Class Initialized
INFO - 2024-05-12 17:00:23 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\payments/payment.php
DEBUG - 2024-05-12 17:00:23 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-05-12 17:00:23 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\include/top_menu.php
INFO - 2024-05-12 17:00:23 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\include/admin_loggedin_info.php
INFO - 2024-05-12 17:00:23 --> Model Class Initialized
INFO - 2024-05-12 17:00:23 --> Model Class Initialized
INFO - 2024-05-12 17:00:23 --> Model Class Initialized
INFO - 2024-05-12 17:00:24 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\include/admin_header.php
INFO - 2024-05-12 17:00:24 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\include/admin_footer.php
INFO - 2024-05-12 17:00:24 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\admin_html_template.php
INFO - 2024-05-12 17:00:24 --> Final output sent to browser
DEBUG - 2024-05-12 17:00:24 --> Total execution time: 1.6513
ERROR - 2024-05-12 17:00:25 --> $config['composer_autoload'] is set to TRUE but E:\xampp\htdocs\maurnaturo\application\vendor/autoload.php was not found.
INFO - 2024-05-12 17:00:25 --> Config Class Initialized
INFO - 2024-05-12 17:00:25 --> Hooks Class Initialized
DEBUG - 2024-05-12 17:00:25 --> UTF-8 Support Enabled
INFO - 2024-05-12 17:00:25 --> Utf8 Class Initialized
INFO - 2024-05-12 17:00:25 --> URI Class Initialized
INFO - 2024-05-12 17:00:25 --> Router Class Initialized
INFO - 2024-05-12 17:00:25 --> Output Class Initialized
INFO - 2024-05-12 17:00:25 --> Security Class Initialized
DEBUG - 2024-05-12 17:00:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-12 17:00:25 --> Input Class Initialized
INFO - 2024-05-12 17:00:25 --> Language Class Initialized
INFO - 2024-05-12 17:00:25 --> Loader Class Initialized
INFO - 2024-05-12 17:00:25 --> Helper loaded: url_helper
INFO - 2024-05-12 17:00:25 --> Helper loaded: file_helper
INFO - 2024-05-12 17:00:25 --> Helper loaded: html_helper
INFO - 2024-05-12 17:00:25 --> Helper loaded: text_helper
INFO - 2024-05-12 17:00:25 --> Helper loaded: form_helper
INFO - 2024-05-12 17:00:25 --> Helper loaded: lang_helper
INFO - 2024-05-12 17:00:25 --> Helper loaded: security_helper
INFO - 2024-05-12 17:00:25 --> Helper loaded: cookie_helper
INFO - 2024-05-12 17:00:25 --> Database Driver Class Initialized
INFO - 2024-05-12 17:00:25 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-12 17:00:25 --> Parser Class Initialized
INFO - 2024-05-12 17:00:25 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-05-12 17:00:25 --> Pagination Class Initialized
INFO - 2024-05-12 17:00:25 --> Form Validation Class Initialized
INFO - 2024-05-12 17:00:25 --> Controller Class Initialized
DEBUG - 2024-05-12 17:00:25 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-05-12 17:00:25 --> Session class already loaded. Second attempt ignored.
INFO - 2024-05-12 17:00:25 --> Model Class Initialized
INFO - 2024-05-12 17:00:25 --> Final output sent to browser
DEBUG - 2024-05-12 17:00:25 --> Total execution time: 0.1060
ERROR - 2024-05-12 17:04:03 --> $config['composer_autoload'] is set to TRUE but E:\xampp\htdocs\maurnaturo\application\vendor/autoload.php was not found.
INFO - 2024-05-12 17:04:03 --> Config Class Initialized
INFO - 2024-05-12 17:04:03 --> Hooks Class Initialized
DEBUG - 2024-05-12 17:04:03 --> UTF-8 Support Enabled
INFO - 2024-05-12 17:04:03 --> Utf8 Class Initialized
INFO - 2024-05-12 17:04:03 --> URI Class Initialized
INFO - 2024-05-12 17:04:03 --> Router Class Initialized
INFO - 2024-05-12 17:04:03 --> Output Class Initialized
INFO - 2024-05-12 17:04:03 --> Security Class Initialized
DEBUG - 2024-05-12 17:04:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-12 17:04:03 --> Input Class Initialized
INFO - 2024-05-12 17:04:03 --> Language Class Initialized
INFO - 2024-05-12 17:04:03 --> Loader Class Initialized
INFO - 2024-05-12 17:04:03 --> Helper loaded: url_helper
INFO - 2024-05-12 17:04:03 --> Helper loaded: file_helper
INFO - 2024-05-12 17:04:03 --> Helper loaded: html_helper
INFO - 2024-05-12 17:04:03 --> Helper loaded: text_helper
INFO - 2024-05-12 17:04:03 --> Helper loaded: form_helper
INFO - 2024-05-12 17:04:03 --> Helper loaded: lang_helper
INFO - 2024-05-12 17:04:03 --> Helper loaded: security_helper
INFO - 2024-05-12 17:04:03 --> Helper loaded: cookie_helper
INFO - 2024-05-12 17:04:03 --> Database Driver Class Initialized
INFO - 2024-05-12 17:04:03 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-12 17:04:03 --> Parser Class Initialized
INFO - 2024-05-12 17:04:03 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-05-12 17:04:03 --> Pagination Class Initialized
INFO - 2024-05-12 17:04:03 --> Form Validation Class Initialized
INFO - 2024-05-12 17:04:03 --> Controller Class Initialized
DEBUG - 2024-05-12 17:04:03 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-05-12 17:04:03 --> Session class already loaded. Second attempt ignored.
INFO - 2024-05-12 17:04:03 --> Model Class Initialized
DEBUG - 2024-05-12 17:04:03 --> Lpayments class already loaded. Second attempt ignored.
INFO - 2024-05-12 17:04:03 --> Model Class Initialized
INFO - 2024-05-12 17:04:03 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\payments/payment.php
DEBUG - 2024-05-12 17:04:03 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-05-12 17:04:03 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\include/top_menu.php
INFO - 2024-05-12 17:04:03 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\include/admin_loggedin_info.php
INFO - 2024-05-12 17:04:03 --> Model Class Initialized
INFO - 2024-05-12 17:04:03 --> Model Class Initialized
INFO - 2024-05-12 17:04:03 --> Model Class Initialized
INFO - 2024-05-12 17:04:05 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\include/admin_header.php
INFO - 2024-05-12 17:04:05 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\include/admin_footer.php
INFO - 2024-05-12 17:04:05 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\admin_html_template.php
INFO - 2024-05-12 17:04:05 --> Final output sent to browser
DEBUG - 2024-05-12 17:04:05 --> Total execution time: 1.9820
ERROR - 2024-05-12 17:04:05 --> $config['composer_autoload'] is set to TRUE but E:\xampp\htdocs\maurnaturo\application\vendor/autoload.php was not found.
INFO - 2024-05-12 17:04:05 --> Config Class Initialized
INFO - 2024-05-12 17:04:05 --> Hooks Class Initialized
DEBUG - 2024-05-12 17:04:05 --> UTF-8 Support Enabled
INFO - 2024-05-12 17:04:05 --> Utf8 Class Initialized
INFO - 2024-05-12 17:04:05 --> URI Class Initialized
INFO - 2024-05-12 17:04:05 --> Router Class Initialized
INFO - 2024-05-12 17:04:05 --> Output Class Initialized
INFO - 2024-05-12 17:04:05 --> Security Class Initialized
DEBUG - 2024-05-12 17:04:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-12 17:04:05 --> Input Class Initialized
INFO - 2024-05-12 17:04:05 --> Language Class Initialized
INFO - 2024-05-12 17:04:05 --> Loader Class Initialized
INFO - 2024-05-12 17:04:05 --> Helper loaded: url_helper
INFO - 2024-05-12 17:04:05 --> Helper loaded: file_helper
INFO - 2024-05-12 17:04:05 --> Helper loaded: html_helper
INFO - 2024-05-12 17:04:05 --> Helper loaded: text_helper
INFO - 2024-05-12 17:04:05 --> Helper loaded: form_helper
INFO - 2024-05-12 17:04:05 --> Helper loaded: lang_helper
INFO - 2024-05-12 17:04:05 --> Helper loaded: security_helper
INFO - 2024-05-12 17:04:05 --> Helper loaded: cookie_helper
INFO - 2024-05-12 17:04:05 --> Database Driver Class Initialized
INFO - 2024-05-12 17:04:05 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-12 17:04:05 --> Parser Class Initialized
INFO - 2024-05-12 17:04:05 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-05-12 17:04:05 --> Pagination Class Initialized
INFO - 2024-05-12 17:04:05 --> Form Validation Class Initialized
INFO - 2024-05-12 17:04:05 --> Controller Class Initialized
DEBUG - 2024-05-12 17:04:05 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-05-12 17:04:05 --> Session class already loaded. Second attempt ignored.
INFO - 2024-05-12 17:04:05 --> Model Class Initialized
INFO - 2024-05-12 17:04:05 --> Final output sent to browser
DEBUG - 2024-05-12 17:04:05 --> Total execution time: 0.1063
ERROR - 2024-05-12 17:04:08 --> $config['composer_autoload'] is set to TRUE but E:\xampp\htdocs\maurnaturo\application\vendor/autoload.php was not found.
INFO - 2024-05-12 17:04:08 --> Config Class Initialized
INFO - 2024-05-12 17:04:08 --> Hooks Class Initialized
DEBUG - 2024-05-12 17:04:08 --> UTF-8 Support Enabled
INFO - 2024-05-12 17:04:08 --> Utf8 Class Initialized
INFO - 2024-05-12 17:04:08 --> URI Class Initialized
INFO - 2024-05-12 17:04:08 --> Router Class Initialized
INFO - 2024-05-12 17:04:08 --> Output Class Initialized
INFO - 2024-05-12 17:04:08 --> Security Class Initialized
DEBUG - 2024-05-12 17:04:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-12 17:04:08 --> Input Class Initialized
INFO - 2024-05-12 17:04:08 --> Language Class Initialized
INFO - 2024-05-12 17:04:08 --> Loader Class Initialized
INFO - 2024-05-12 17:04:08 --> Helper loaded: url_helper
INFO - 2024-05-12 17:04:08 --> Helper loaded: file_helper
INFO - 2024-05-12 17:04:08 --> Helper loaded: html_helper
INFO - 2024-05-12 17:04:08 --> Helper loaded: text_helper
INFO - 2024-05-12 17:04:08 --> Helper loaded: form_helper
INFO - 2024-05-12 17:04:08 --> Helper loaded: lang_helper
INFO - 2024-05-12 17:04:08 --> Helper loaded: security_helper
INFO - 2024-05-12 17:04:08 --> Helper loaded: cookie_helper
INFO - 2024-05-12 17:04:08 --> Database Driver Class Initialized
INFO - 2024-05-12 17:04:08 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-12 17:04:08 --> Parser Class Initialized
INFO - 2024-05-12 17:04:08 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-05-12 17:04:08 --> Pagination Class Initialized
INFO - 2024-05-12 17:04:09 --> Form Validation Class Initialized
INFO - 2024-05-12 17:04:09 --> Controller Class Initialized
DEBUG - 2024-05-12 17:04:09 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-05-12 17:04:09 --> Session class already loaded. Second attempt ignored.
INFO - 2024-05-12 17:04:09 --> Model Class Initialized
INFO - 2024-05-12 17:04:09 --> Model Class Initialized
DEBUG - 2024-05-12 17:04:09 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-05-12 17:04:09 --> Session class already loaded. Second attempt ignored.
INFO - 2024-05-12 17:04:09 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\payments/add_payment_form.php
DEBUG - 2024-05-12 17:04:09 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-05-12 17:04:09 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\include/top_menu.php
INFO - 2024-05-12 17:04:09 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\include/admin_loggedin_info.php
INFO - 2024-05-12 17:04:09 --> Model Class Initialized
INFO - 2024-05-12 17:04:09 --> Model Class Initialized
INFO - 2024-05-12 17:04:09 --> Model Class Initialized
INFO - 2024-05-12 17:04:09 --> Model Class Initialized
INFO - 2024-05-12 17:04:10 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\include/admin_header.php
INFO - 2024-05-12 17:04:10 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\include/admin_footer.php
INFO - 2024-05-12 17:04:10 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\admin_html_template.php
INFO - 2024-05-12 17:04:10 --> Final output sent to browser
DEBUG - 2024-05-12 17:04:10 --> Total execution time: 1.5109
ERROR - 2024-05-12 17:05:27 --> $config['composer_autoload'] is set to TRUE but E:\xampp\htdocs\maurnaturo\application\vendor/autoload.php was not found.
INFO - 2024-05-12 17:05:27 --> Config Class Initialized
INFO - 2024-05-12 17:05:27 --> Hooks Class Initialized
DEBUG - 2024-05-12 17:05:27 --> UTF-8 Support Enabled
INFO - 2024-05-12 17:05:27 --> Utf8 Class Initialized
INFO - 2024-05-12 17:05:27 --> URI Class Initialized
INFO - 2024-05-12 17:05:27 --> Router Class Initialized
INFO - 2024-05-12 17:05:27 --> Output Class Initialized
INFO - 2024-05-12 17:05:27 --> Security Class Initialized
DEBUG - 2024-05-12 17:05:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-12 17:05:27 --> Input Class Initialized
INFO - 2024-05-12 17:05:27 --> Language Class Initialized
INFO - 2024-05-12 17:05:27 --> Loader Class Initialized
INFO - 2024-05-12 17:05:27 --> Helper loaded: url_helper
INFO - 2024-05-12 17:05:27 --> Helper loaded: file_helper
INFO - 2024-05-12 17:05:27 --> Helper loaded: html_helper
INFO - 2024-05-12 17:05:27 --> Helper loaded: text_helper
INFO - 2024-05-12 17:05:27 --> Helper loaded: form_helper
INFO - 2024-05-12 17:05:27 --> Helper loaded: lang_helper
INFO - 2024-05-12 17:05:27 --> Helper loaded: security_helper
INFO - 2024-05-12 17:05:27 --> Helper loaded: cookie_helper
INFO - 2024-05-12 17:05:27 --> Database Driver Class Initialized
INFO - 2024-05-12 17:05:27 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-12 17:05:27 --> Parser Class Initialized
INFO - 2024-05-12 17:05:27 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-05-12 17:05:27 --> Pagination Class Initialized
INFO - 2024-05-12 17:05:27 --> Form Validation Class Initialized
INFO - 2024-05-12 17:05:27 --> Controller Class Initialized
DEBUG - 2024-05-12 17:05:27 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-05-12 17:05:27 --> Session class already loaded. Second attempt ignored.
INFO - 2024-05-12 17:05:27 --> Model Class Initialized
INFO - 2024-05-12 17:05:27 --> Model Class Initialized
DEBUG - 2024-05-12 17:05:27 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-05-12 17:05:27 --> Session class already loaded. Second attempt ignored.
INFO - 2024-05-12 17:05:27 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\payments/add_payment_form.php
DEBUG - 2024-05-12 17:05:27 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-05-12 17:05:27 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\include/top_menu.php
INFO - 2024-05-12 17:05:27 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\include/admin_loggedin_info.php
INFO - 2024-05-12 17:05:27 --> Model Class Initialized
INFO - 2024-05-12 17:05:27 --> Model Class Initialized
INFO - 2024-05-12 17:05:27 --> Model Class Initialized
INFO - 2024-05-12 17:05:27 --> Model Class Initialized
INFO - 2024-05-12 17:05:28 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\include/admin_header.php
INFO - 2024-05-12 17:05:28 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\include/admin_footer.php
INFO - 2024-05-12 17:05:28 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\admin_html_template.php
INFO - 2024-05-12 17:05:28 --> Final output sent to browser
DEBUG - 2024-05-12 17:05:28 --> Total execution time: 1.8979
ERROR - 2024-05-12 17:05:38 --> $config['composer_autoload'] is set to TRUE but E:\xampp\htdocs\maurnaturo\application\vendor/autoload.php was not found.
INFO - 2024-05-12 17:05:38 --> Config Class Initialized
INFO - 2024-05-12 17:05:38 --> Hooks Class Initialized
DEBUG - 2024-05-12 17:05:38 --> UTF-8 Support Enabled
INFO - 2024-05-12 17:05:38 --> Utf8 Class Initialized
INFO - 2024-05-12 17:05:38 --> URI Class Initialized
INFO - 2024-05-12 17:05:38 --> Router Class Initialized
INFO - 2024-05-12 17:05:38 --> Output Class Initialized
INFO - 2024-05-12 17:05:38 --> Security Class Initialized
DEBUG - 2024-05-12 17:05:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-12 17:05:38 --> Input Class Initialized
INFO - 2024-05-12 17:05:38 --> Language Class Initialized
INFO - 2024-05-12 17:05:39 --> Loader Class Initialized
INFO - 2024-05-12 17:05:39 --> Helper loaded: url_helper
INFO - 2024-05-12 17:05:39 --> Helper loaded: file_helper
INFO - 2024-05-12 17:05:39 --> Helper loaded: html_helper
INFO - 2024-05-12 17:05:39 --> Helper loaded: text_helper
INFO - 2024-05-12 17:05:39 --> Helper loaded: form_helper
INFO - 2024-05-12 17:05:39 --> Helper loaded: lang_helper
INFO - 2024-05-12 17:05:39 --> Helper loaded: security_helper
INFO - 2024-05-12 17:05:39 --> Helper loaded: cookie_helper
INFO - 2024-05-12 17:05:39 --> Database Driver Class Initialized
INFO - 2024-05-12 17:05:39 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-12 17:05:39 --> Parser Class Initialized
INFO - 2024-05-12 17:05:39 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-05-12 17:05:39 --> Pagination Class Initialized
INFO - 2024-05-12 17:05:39 --> Form Validation Class Initialized
INFO - 2024-05-12 17:05:39 --> Controller Class Initialized
INFO - 2024-05-12 17:05:39 --> Model Class Initialized
DEBUG - 2024-05-12 17:05:39 --> Session class already loaded. Second attempt ignored.
INFO - 2024-05-12 17:05:39 --> Final output sent to browser
DEBUG - 2024-05-12 17:05:39 --> Total execution time: 0.1036
ERROR - 2024-05-12 17:06:03 --> $config['composer_autoload'] is set to TRUE but E:\xampp\htdocs\maurnaturo\application\vendor/autoload.php was not found.
INFO - 2024-05-12 17:06:03 --> Config Class Initialized
INFO - 2024-05-12 17:06:03 --> Hooks Class Initialized
DEBUG - 2024-05-12 17:06:03 --> UTF-8 Support Enabled
INFO - 2024-05-12 17:06:03 --> Utf8 Class Initialized
INFO - 2024-05-12 17:06:03 --> URI Class Initialized
INFO - 2024-05-12 17:06:03 --> Router Class Initialized
INFO - 2024-05-12 17:06:03 --> Output Class Initialized
INFO - 2024-05-12 17:06:03 --> Security Class Initialized
DEBUG - 2024-05-12 17:06:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-12 17:06:03 --> Input Class Initialized
INFO - 2024-05-12 17:06:03 --> Language Class Initialized
INFO - 2024-05-12 17:06:03 --> Loader Class Initialized
INFO - 2024-05-12 17:06:03 --> Helper loaded: url_helper
INFO - 2024-05-12 17:06:03 --> Helper loaded: file_helper
INFO - 2024-05-12 17:06:03 --> Helper loaded: html_helper
INFO - 2024-05-12 17:06:03 --> Helper loaded: text_helper
INFO - 2024-05-12 17:06:03 --> Helper loaded: form_helper
INFO - 2024-05-12 17:06:03 --> Helper loaded: lang_helper
INFO - 2024-05-12 17:06:03 --> Helper loaded: security_helper
INFO - 2024-05-12 17:06:03 --> Helper loaded: cookie_helper
INFO - 2024-05-12 17:06:03 --> Database Driver Class Initialized
INFO - 2024-05-12 17:06:03 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-12 17:06:03 --> Parser Class Initialized
INFO - 2024-05-12 17:06:03 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-05-12 17:06:03 --> Pagination Class Initialized
INFO - 2024-05-12 17:06:03 --> Form Validation Class Initialized
INFO - 2024-05-12 17:06:03 --> Controller Class Initialized
DEBUG - 2024-05-12 17:06:03 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-05-12 17:06:03 --> Session class already loaded. Second attempt ignored.
INFO - 2024-05-12 17:06:03 --> Model Class Initialized
INFO - 2024-05-12 17:06:03 --> Final output sent to browser
DEBUG - 2024-05-12 17:06:03 --> Total execution time: 0.1132
ERROR - 2024-05-12 17:11:10 --> $config['composer_autoload'] is set to TRUE but E:\xampp\htdocs\maurnaturo\application\vendor/autoload.php was not found.
INFO - 2024-05-12 17:11:10 --> Config Class Initialized
INFO - 2024-05-12 17:11:10 --> Hooks Class Initialized
DEBUG - 2024-05-12 17:11:10 --> UTF-8 Support Enabled
INFO - 2024-05-12 17:11:10 --> Utf8 Class Initialized
INFO - 2024-05-12 17:11:10 --> URI Class Initialized
INFO - 2024-05-12 17:11:10 --> Router Class Initialized
INFO - 2024-05-12 17:11:10 --> Output Class Initialized
INFO - 2024-05-12 17:11:10 --> Security Class Initialized
DEBUG - 2024-05-12 17:11:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-12 17:11:10 --> Input Class Initialized
INFO - 2024-05-12 17:11:10 --> Language Class Initialized
INFO - 2024-05-12 17:11:10 --> Loader Class Initialized
INFO - 2024-05-12 17:11:10 --> Helper loaded: url_helper
INFO - 2024-05-12 17:11:10 --> Helper loaded: file_helper
INFO - 2024-05-12 17:11:10 --> Helper loaded: html_helper
INFO - 2024-05-12 17:11:10 --> Helper loaded: text_helper
INFO - 2024-05-12 17:11:10 --> Helper loaded: form_helper
INFO - 2024-05-12 17:11:10 --> Helper loaded: lang_helper
INFO - 2024-05-12 17:11:10 --> Helper loaded: security_helper
INFO - 2024-05-12 17:11:10 --> Helper loaded: cookie_helper
INFO - 2024-05-12 17:11:10 --> Database Driver Class Initialized
INFO - 2024-05-12 17:11:10 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-12 17:11:10 --> Parser Class Initialized
INFO - 2024-05-12 17:11:10 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-05-12 17:11:10 --> Pagination Class Initialized
INFO - 2024-05-12 17:11:10 --> Form Validation Class Initialized
INFO - 2024-05-12 17:11:10 --> Controller Class Initialized
DEBUG - 2024-05-12 17:11:10 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-05-12 17:11:10 --> Session class already loaded. Second attempt ignored.
INFO - 2024-05-12 17:11:10 --> Model Class Initialized
INFO - 2024-05-12 17:11:10 --> Final output sent to browser
DEBUG - 2024-05-12 17:11:10 --> Total execution time: 0.1101
ERROR - 2024-05-12 17:14:31 --> $config['composer_autoload'] is set to TRUE but E:\xampp\htdocs\maurnaturo\application\vendor/autoload.php was not found.
INFO - 2024-05-12 17:14:31 --> Config Class Initialized
INFO - 2024-05-12 17:14:31 --> Hooks Class Initialized
DEBUG - 2024-05-12 17:14:31 --> UTF-8 Support Enabled
INFO - 2024-05-12 17:14:31 --> Utf8 Class Initialized
INFO - 2024-05-12 17:14:31 --> URI Class Initialized
INFO - 2024-05-12 17:14:31 --> Router Class Initialized
INFO - 2024-05-12 17:14:31 --> Output Class Initialized
INFO - 2024-05-12 17:14:31 --> Security Class Initialized
DEBUG - 2024-05-12 17:14:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-12 17:14:31 --> Input Class Initialized
INFO - 2024-05-12 17:14:31 --> Language Class Initialized
INFO - 2024-05-12 17:14:31 --> Loader Class Initialized
INFO - 2024-05-12 17:14:31 --> Helper loaded: url_helper
INFO - 2024-05-12 17:14:31 --> Helper loaded: file_helper
INFO - 2024-05-12 17:14:31 --> Helper loaded: html_helper
INFO - 2024-05-12 17:14:31 --> Helper loaded: text_helper
INFO - 2024-05-12 17:14:31 --> Helper loaded: form_helper
INFO - 2024-05-12 17:14:31 --> Helper loaded: lang_helper
INFO - 2024-05-12 17:14:31 --> Helper loaded: security_helper
INFO - 2024-05-12 17:14:31 --> Helper loaded: cookie_helper
INFO - 2024-05-12 17:14:31 --> Database Driver Class Initialized
INFO - 2024-05-12 17:14:31 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-12 17:14:31 --> Parser Class Initialized
INFO - 2024-05-12 17:14:31 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-05-12 17:14:31 --> Pagination Class Initialized
INFO - 2024-05-12 17:14:31 --> Form Validation Class Initialized
INFO - 2024-05-12 17:14:31 --> Controller Class Initialized
DEBUG - 2024-05-12 17:14:31 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-05-12 17:14:31 --> Session class already loaded. Second attempt ignored.
INFO - 2024-05-12 17:14:31 --> Model Class Initialized
INFO - 2024-05-12 17:14:31 --> Model Class Initialized
DEBUG - 2024-05-12 17:14:31 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-05-12 17:14:31 --> Session class already loaded. Second attempt ignored.
INFO - 2024-05-12 17:14:31 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\payments/add_payment_form.php
DEBUG - 2024-05-12 17:14:31 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-05-12 17:14:31 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\include/top_menu.php
INFO - 2024-05-12 17:14:31 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\include/admin_loggedin_info.php
INFO - 2024-05-12 17:14:31 --> Model Class Initialized
INFO - 2024-05-12 17:14:31 --> Model Class Initialized
INFO - 2024-05-12 17:14:31 --> Model Class Initialized
INFO - 2024-05-12 17:14:31 --> Model Class Initialized
INFO - 2024-05-12 17:14:33 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\include/admin_header.php
INFO - 2024-05-12 17:14:33 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\include/admin_footer.php
INFO - 2024-05-12 17:14:33 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\admin_html_template.php
INFO - 2024-05-12 17:14:33 --> Final output sent to browser
DEBUG - 2024-05-12 17:14:33 --> Total execution time: 1.5884
ERROR - 2024-05-12 17:14:39 --> $config['composer_autoload'] is set to TRUE but E:\xampp\htdocs\maurnaturo\application\vendor/autoload.php was not found.
INFO - 2024-05-12 17:14:39 --> Config Class Initialized
INFO - 2024-05-12 17:14:39 --> Hooks Class Initialized
DEBUG - 2024-05-12 17:14:39 --> UTF-8 Support Enabled
INFO - 2024-05-12 17:14:39 --> Utf8 Class Initialized
INFO - 2024-05-12 17:14:39 --> URI Class Initialized
INFO - 2024-05-12 17:14:39 --> Router Class Initialized
INFO - 2024-05-12 17:14:39 --> Output Class Initialized
INFO - 2024-05-12 17:14:39 --> Security Class Initialized
DEBUG - 2024-05-12 17:14:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-12 17:14:39 --> Input Class Initialized
INFO - 2024-05-12 17:14:39 --> Language Class Initialized
INFO - 2024-05-12 17:14:39 --> Loader Class Initialized
INFO - 2024-05-12 17:14:39 --> Helper loaded: url_helper
INFO - 2024-05-12 17:14:39 --> Helper loaded: file_helper
INFO - 2024-05-12 17:14:39 --> Helper loaded: html_helper
INFO - 2024-05-12 17:14:39 --> Helper loaded: text_helper
INFO - 2024-05-12 17:14:39 --> Helper loaded: form_helper
INFO - 2024-05-12 17:14:39 --> Helper loaded: lang_helper
INFO - 2024-05-12 17:14:39 --> Helper loaded: security_helper
INFO - 2024-05-12 17:14:39 --> Helper loaded: cookie_helper
INFO - 2024-05-12 17:14:39 --> Database Driver Class Initialized
INFO - 2024-05-12 17:14:39 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-12 17:14:39 --> Parser Class Initialized
INFO - 2024-05-12 17:14:39 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-05-12 17:14:39 --> Pagination Class Initialized
INFO - 2024-05-12 17:14:39 --> Form Validation Class Initialized
INFO - 2024-05-12 17:14:39 --> Controller Class Initialized
INFO - 2024-05-12 17:14:39 --> Model Class Initialized
DEBUG - 2024-05-12 17:14:39 --> Session class already loaded. Second attempt ignored.
ERROR - 2024-05-12 17:14:39 --> Severity: Warning --> Invalid argument supplied for foreach() E:\xampp\htdocs\maurnaturo\application\controllers\Cinvoice.php 616
INFO - 2024-05-12 17:14:39 --> Final output sent to browser
DEBUG - 2024-05-12 17:14:39 --> Total execution time: 0.0729
ERROR - 2024-05-12 17:14:40 --> $config['composer_autoload'] is set to TRUE but E:\xampp\htdocs\maurnaturo\application\vendor/autoload.php was not found.
INFO - 2024-05-12 17:14:40 --> Config Class Initialized
INFO - 2024-05-12 17:14:40 --> Hooks Class Initialized
DEBUG - 2024-05-12 17:14:40 --> UTF-8 Support Enabled
INFO - 2024-05-12 17:14:40 --> Utf8 Class Initialized
INFO - 2024-05-12 17:14:40 --> URI Class Initialized
INFO - 2024-05-12 17:14:40 --> Router Class Initialized
INFO - 2024-05-12 17:14:40 --> Output Class Initialized
INFO - 2024-05-12 17:14:40 --> Security Class Initialized
DEBUG - 2024-05-12 17:14:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-12 17:14:40 --> Input Class Initialized
INFO - 2024-05-12 17:14:40 --> Language Class Initialized
INFO - 2024-05-12 17:14:40 --> Loader Class Initialized
INFO - 2024-05-12 17:14:40 --> Helper loaded: url_helper
INFO - 2024-05-12 17:14:40 --> Helper loaded: file_helper
INFO - 2024-05-12 17:14:40 --> Helper loaded: html_helper
INFO - 2024-05-12 17:14:40 --> Helper loaded: text_helper
INFO - 2024-05-12 17:14:40 --> Helper loaded: form_helper
INFO - 2024-05-12 17:14:40 --> Helper loaded: lang_helper
INFO - 2024-05-12 17:14:40 --> Helper loaded: security_helper
INFO - 2024-05-12 17:14:40 --> Helper loaded: cookie_helper
INFO - 2024-05-12 17:14:40 --> Database Driver Class Initialized
INFO - 2024-05-12 17:14:40 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-12 17:14:40 --> Parser Class Initialized
INFO - 2024-05-12 17:14:40 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-05-12 17:14:40 --> Pagination Class Initialized
INFO - 2024-05-12 17:14:40 --> Form Validation Class Initialized
INFO - 2024-05-12 17:14:40 --> Controller Class Initialized
INFO - 2024-05-12 17:14:40 --> Model Class Initialized
DEBUG - 2024-05-12 17:14:40 --> Session class already loaded. Second attempt ignored.
INFO - 2024-05-12 17:14:40 --> Final output sent to browser
DEBUG - 2024-05-12 17:14:40 --> Total execution time: 0.0697
ERROR - 2024-05-12 17:16:13 --> $config['composer_autoload'] is set to TRUE but E:\xampp\htdocs\maurnaturo\application\vendor/autoload.php was not found.
INFO - 2024-05-12 17:16:13 --> Config Class Initialized
INFO - 2024-05-12 17:16:13 --> Hooks Class Initialized
DEBUG - 2024-05-12 17:16:13 --> UTF-8 Support Enabled
INFO - 2024-05-12 17:16:13 --> Utf8 Class Initialized
INFO - 2024-05-12 17:16:13 --> URI Class Initialized
INFO - 2024-05-12 17:16:13 --> Router Class Initialized
INFO - 2024-05-12 17:16:13 --> Output Class Initialized
INFO - 2024-05-12 17:16:13 --> Security Class Initialized
DEBUG - 2024-05-12 17:16:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-12 17:16:13 --> Input Class Initialized
INFO - 2024-05-12 17:16:13 --> Language Class Initialized
INFO - 2024-05-12 17:16:13 --> Loader Class Initialized
INFO - 2024-05-12 17:16:13 --> Helper loaded: url_helper
INFO - 2024-05-12 17:16:13 --> Helper loaded: file_helper
INFO - 2024-05-12 17:16:13 --> Helper loaded: html_helper
INFO - 2024-05-12 17:16:13 --> Helper loaded: text_helper
INFO - 2024-05-12 17:16:13 --> Helper loaded: form_helper
INFO - 2024-05-12 17:16:13 --> Helper loaded: lang_helper
INFO - 2024-05-12 17:16:13 --> Helper loaded: security_helper
INFO - 2024-05-12 17:16:13 --> Helper loaded: cookie_helper
INFO - 2024-05-12 17:16:13 --> Database Driver Class Initialized
INFO - 2024-05-12 17:16:13 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-12 17:16:13 --> Parser Class Initialized
INFO - 2024-05-12 17:16:13 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-05-12 17:16:13 --> Pagination Class Initialized
INFO - 2024-05-12 17:16:13 --> Form Validation Class Initialized
INFO - 2024-05-12 17:16:13 --> Controller Class Initialized
DEBUG - 2024-05-12 17:16:13 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-05-12 17:16:13 --> Session class already loaded. Second attempt ignored.
INFO - 2024-05-12 17:16:13 --> Model Class Initialized
INFO - 2024-05-12 17:16:13 --> Model Class Initialized
DEBUG - 2024-05-12 17:16:13 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-05-12 17:16:13 --> Session class already loaded. Second attempt ignored.
INFO - 2024-05-12 17:16:13 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\payments/add_payment_form.php
DEBUG - 2024-05-12 17:16:13 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-05-12 17:16:13 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\include/top_menu.php
INFO - 2024-05-12 17:16:13 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\include/admin_loggedin_info.php
INFO - 2024-05-12 17:16:13 --> Model Class Initialized
INFO - 2024-05-12 17:16:13 --> Model Class Initialized
INFO - 2024-05-12 17:16:13 --> Model Class Initialized
INFO - 2024-05-12 17:16:13 --> Model Class Initialized
INFO - 2024-05-12 17:16:15 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\include/admin_header.php
INFO - 2024-05-12 17:16:15 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\include/admin_footer.php
INFO - 2024-05-12 17:16:15 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\admin_html_template.php
INFO - 2024-05-12 17:16:15 --> Final output sent to browser
DEBUG - 2024-05-12 17:16:15 --> Total execution time: 1.6140
ERROR - 2024-05-12 17:25:01 --> $config['composer_autoload'] is set to TRUE but E:\xampp\htdocs\maurnaturo\application\vendor/autoload.php was not found.
INFO - 2024-05-12 17:25:01 --> Config Class Initialized
INFO - 2024-05-12 17:25:01 --> Hooks Class Initialized
DEBUG - 2024-05-12 17:25:01 --> UTF-8 Support Enabled
INFO - 2024-05-12 17:25:01 --> Utf8 Class Initialized
INFO - 2024-05-12 17:25:01 --> URI Class Initialized
INFO - 2024-05-12 17:25:01 --> Router Class Initialized
INFO - 2024-05-12 17:25:01 --> Output Class Initialized
INFO - 2024-05-12 17:25:01 --> Security Class Initialized
DEBUG - 2024-05-12 17:25:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-12 17:25:01 --> Input Class Initialized
INFO - 2024-05-12 17:25:01 --> Language Class Initialized
INFO - 2024-05-12 17:25:01 --> Loader Class Initialized
INFO - 2024-05-12 17:25:01 --> Helper loaded: url_helper
INFO - 2024-05-12 17:25:01 --> Helper loaded: file_helper
INFO - 2024-05-12 17:25:01 --> Helper loaded: html_helper
INFO - 2024-05-12 17:25:01 --> Helper loaded: text_helper
INFO - 2024-05-12 17:25:01 --> Helper loaded: form_helper
INFO - 2024-05-12 17:25:01 --> Helper loaded: lang_helper
INFO - 2024-05-12 17:25:01 --> Helper loaded: security_helper
INFO - 2024-05-12 17:25:01 --> Helper loaded: cookie_helper
INFO - 2024-05-12 17:25:01 --> Database Driver Class Initialized
INFO - 2024-05-12 17:25:01 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-12 17:25:01 --> Parser Class Initialized
INFO - 2024-05-12 17:25:01 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-05-12 17:25:01 --> Pagination Class Initialized
INFO - 2024-05-12 17:25:01 --> Form Validation Class Initialized
INFO - 2024-05-12 17:25:01 --> Controller Class Initialized
DEBUG - 2024-05-12 17:25:01 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-05-12 17:25:01 --> Session class already loaded. Second attempt ignored.
INFO - 2024-05-12 17:25:01 --> Model Class Initialized
INFO - 2024-05-12 17:25:01 --> Model Class Initialized
DEBUG - 2024-05-12 17:25:01 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-05-12 17:25:01 --> Session class already loaded. Second attempt ignored.
INFO - 2024-05-12 17:25:01 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\payments/add_payment_form.php
DEBUG - 2024-05-12 17:25:01 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-05-12 17:25:01 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\include/top_menu.php
INFO - 2024-05-12 17:25:01 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\include/admin_loggedin_info.php
INFO - 2024-05-12 17:25:01 --> Model Class Initialized
INFO - 2024-05-12 17:25:01 --> Model Class Initialized
INFO - 2024-05-12 17:25:01 --> Model Class Initialized
INFO - 2024-05-12 17:25:01 --> Model Class Initialized
ERROR - 2024-05-12 17:25:01 --> $config['composer_autoload'] is set to TRUE but E:\xampp\htdocs\maurnaturo\application\vendor/autoload.php was not found.
INFO - 2024-05-12 17:25:01 --> Config Class Initialized
INFO - 2024-05-12 17:25:01 --> Hooks Class Initialized
DEBUG - 2024-05-12 17:25:01 --> UTF-8 Support Enabled
INFO - 2024-05-12 17:25:01 --> Utf8 Class Initialized
INFO - 2024-05-12 17:25:01 --> URI Class Initialized
INFO - 2024-05-12 17:25:01 --> Router Class Initialized
INFO - 2024-05-12 17:25:01 --> Output Class Initialized
INFO - 2024-05-12 17:25:01 --> Security Class Initialized
DEBUG - 2024-05-12 17:25:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-12 17:25:01 --> Input Class Initialized
INFO - 2024-05-12 17:25:01 --> Language Class Initialized
INFO - 2024-05-12 17:25:01 --> Loader Class Initialized
INFO - 2024-05-12 17:25:01 --> Helper loaded: url_helper
INFO - 2024-05-12 17:25:01 --> Helper loaded: file_helper
INFO - 2024-05-12 17:25:01 --> Helper loaded: html_helper
INFO - 2024-05-12 17:25:01 --> Helper loaded: text_helper
INFO - 2024-05-12 17:25:01 --> Helper loaded: form_helper
INFO - 2024-05-12 17:25:01 --> Helper loaded: lang_helper
INFO - 2024-05-12 17:25:01 --> Helper loaded: security_helper
INFO - 2024-05-12 17:25:01 --> Helper loaded: cookie_helper
INFO - 2024-05-12 17:25:01 --> Database Driver Class Initialized
INFO - 2024-05-12 17:25:01 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-12 17:25:01 --> Parser Class Initialized
INFO - 2024-05-12 17:25:01 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-05-12 17:25:01 --> Pagination Class Initialized
INFO - 2024-05-12 17:25:01 --> Form Validation Class Initialized
INFO - 2024-05-12 17:25:01 --> Controller Class Initialized
DEBUG - 2024-05-12 17:25:01 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-05-12 17:25:01 --> Session class already loaded. Second attempt ignored.
INFO - 2024-05-12 17:25:01 --> Model Class Initialized
INFO - 2024-05-12 17:25:01 --> Model Class Initialized
DEBUG - 2024-05-12 17:25:01 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-05-12 17:25:01 --> Session class already loaded. Second attempt ignored.
INFO - 2024-05-12 17:25:01 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\payments/add_payment_form.php
DEBUG - 2024-05-12 17:25:01 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-05-12 17:25:01 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\include/top_menu.php
INFO - 2024-05-12 17:25:01 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\include/admin_loggedin_info.php
INFO - 2024-05-12 17:25:01 --> Model Class Initialized
INFO - 2024-05-12 17:25:01 --> Model Class Initialized
INFO - 2024-05-12 17:25:01 --> Model Class Initialized
INFO - 2024-05-12 17:25:01 --> Model Class Initialized
INFO - 2024-05-12 17:25:03 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\include/admin_header.php
INFO - 2024-05-12 17:25:03 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\include/admin_footer.php
INFO - 2024-05-12 17:25:03 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\admin_html_template.php
INFO - 2024-05-12 17:25:03 --> Final output sent to browser
DEBUG - 2024-05-12 17:25:03 --> Total execution time: 1.8878
INFO - 2024-05-12 17:25:03 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\include/admin_header.php
INFO - 2024-05-12 17:25:03 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\include/admin_footer.php
INFO - 2024-05-12 17:25:03 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\admin_html_template.php
INFO - 2024-05-12 17:25:03 --> Final output sent to browser
DEBUG - 2024-05-12 17:25:03 --> Total execution time: 1.8033
ERROR - 2024-05-12 17:25:31 --> $config['composer_autoload'] is set to TRUE but E:\xampp\htdocs\maurnaturo\application\vendor/autoload.php was not found.
INFO - 2024-05-12 17:25:31 --> Config Class Initialized
INFO - 2024-05-12 17:25:31 --> Hooks Class Initialized
DEBUG - 2024-05-12 17:25:31 --> UTF-8 Support Enabled
INFO - 2024-05-12 17:25:31 --> Utf8 Class Initialized
INFO - 2024-05-12 17:25:31 --> URI Class Initialized
INFO - 2024-05-12 17:25:31 --> Router Class Initialized
INFO - 2024-05-12 17:25:31 --> Output Class Initialized
INFO - 2024-05-12 17:25:31 --> Security Class Initialized
DEBUG - 2024-05-12 17:25:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-12 17:25:31 --> Input Class Initialized
INFO - 2024-05-12 17:25:31 --> Language Class Initialized
INFO - 2024-05-12 17:25:31 --> Loader Class Initialized
INFO - 2024-05-12 17:25:31 --> Helper loaded: url_helper
INFO - 2024-05-12 17:25:31 --> Helper loaded: file_helper
INFO - 2024-05-12 17:25:31 --> Helper loaded: html_helper
INFO - 2024-05-12 17:25:31 --> Helper loaded: text_helper
INFO - 2024-05-12 17:25:31 --> Helper loaded: form_helper
INFO - 2024-05-12 17:25:31 --> Helper loaded: lang_helper
INFO - 2024-05-12 17:25:31 --> Helper loaded: security_helper
INFO - 2024-05-12 17:25:31 --> Helper loaded: cookie_helper
INFO - 2024-05-12 17:25:31 --> Database Driver Class Initialized
INFO - 2024-05-12 17:25:31 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-12 17:25:31 --> Parser Class Initialized
INFO - 2024-05-12 17:25:31 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-05-12 17:25:31 --> Pagination Class Initialized
INFO - 2024-05-12 17:25:32 --> Form Validation Class Initialized
INFO - 2024-05-12 17:25:32 --> Controller Class Initialized
INFO - 2024-05-12 17:25:32 --> Model Class Initialized
DEBUG - 2024-05-12 17:25:32 --> Session class already loaded. Second attempt ignored.
ERROR - 2024-05-12 17:25:32 --> Severity: Warning --> Invalid argument supplied for foreach() E:\xampp\htdocs\maurnaturo\application\controllers\Cinvoice.php 616
INFO - 2024-05-12 17:25:32 --> Final output sent to browser
DEBUG - 2024-05-12 17:25:32 --> Total execution time: 0.0737
ERROR - 2024-05-12 17:25:33 --> $config['composer_autoload'] is set to TRUE but E:\xampp\htdocs\maurnaturo\application\vendor/autoload.php was not found.
INFO - 2024-05-12 17:25:33 --> Config Class Initialized
INFO - 2024-05-12 17:25:33 --> Hooks Class Initialized
DEBUG - 2024-05-12 17:25:33 --> UTF-8 Support Enabled
INFO - 2024-05-12 17:25:33 --> Utf8 Class Initialized
INFO - 2024-05-12 17:25:33 --> URI Class Initialized
INFO - 2024-05-12 17:25:33 --> Router Class Initialized
INFO - 2024-05-12 17:25:33 --> Output Class Initialized
INFO - 2024-05-12 17:25:33 --> Security Class Initialized
DEBUG - 2024-05-12 17:25:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-12 17:25:33 --> Input Class Initialized
INFO - 2024-05-12 17:25:33 --> Language Class Initialized
INFO - 2024-05-12 17:25:33 --> Loader Class Initialized
INFO - 2024-05-12 17:25:33 --> Helper loaded: url_helper
INFO - 2024-05-12 17:25:33 --> Helper loaded: file_helper
INFO - 2024-05-12 17:25:33 --> Helper loaded: html_helper
INFO - 2024-05-12 17:25:33 --> Helper loaded: text_helper
INFO - 2024-05-12 17:25:33 --> Helper loaded: form_helper
INFO - 2024-05-12 17:25:33 --> Helper loaded: lang_helper
INFO - 2024-05-12 17:25:33 --> Helper loaded: security_helper
INFO - 2024-05-12 17:25:33 --> Helper loaded: cookie_helper
INFO - 2024-05-12 17:25:33 --> Database Driver Class Initialized
INFO - 2024-05-12 17:25:33 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-12 17:25:33 --> Parser Class Initialized
INFO - 2024-05-12 17:25:33 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-05-12 17:25:33 --> Pagination Class Initialized
INFO - 2024-05-12 17:25:33 --> Form Validation Class Initialized
INFO - 2024-05-12 17:25:33 --> Controller Class Initialized
INFO - 2024-05-12 17:25:33 --> Model Class Initialized
DEBUG - 2024-05-12 17:25:33 --> Session class already loaded. Second attempt ignored.
ERROR - 2024-05-12 17:25:33 --> Severity: Warning --> Invalid argument supplied for foreach() E:\xampp\htdocs\maurnaturo\application\controllers\Cinvoice.php 616
INFO - 2024-05-12 17:25:33 --> Final output sent to browser
DEBUG - 2024-05-12 17:25:33 --> Total execution time: 0.0720
ERROR - 2024-05-12 17:25:33 --> $config['composer_autoload'] is set to TRUE but E:\xampp\htdocs\maurnaturo\application\vendor/autoload.php was not found.
INFO - 2024-05-12 17:25:33 --> Config Class Initialized
INFO - 2024-05-12 17:25:33 --> Hooks Class Initialized
DEBUG - 2024-05-12 17:25:33 --> UTF-8 Support Enabled
INFO - 2024-05-12 17:25:33 --> Utf8 Class Initialized
INFO - 2024-05-12 17:25:33 --> URI Class Initialized
INFO - 2024-05-12 17:25:33 --> Router Class Initialized
INFO - 2024-05-12 17:25:33 --> Output Class Initialized
INFO - 2024-05-12 17:25:33 --> Security Class Initialized
DEBUG - 2024-05-12 17:25:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-12 17:25:33 --> Input Class Initialized
INFO - 2024-05-12 17:25:33 --> Language Class Initialized
INFO - 2024-05-12 17:25:33 --> Loader Class Initialized
INFO - 2024-05-12 17:25:33 --> Helper loaded: url_helper
INFO - 2024-05-12 17:25:33 --> Helper loaded: file_helper
INFO - 2024-05-12 17:25:33 --> Helper loaded: html_helper
INFO - 2024-05-12 17:25:33 --> Helper loaded: text_helper
INFO - 2024-05-12 17:25:33 --> Helper loaded: form_helper
INFO - 2024-05-12 17:25:33 --> Helper loaded: lang_helper
INFO - 2024-05-12 17:25:33 --> Helper loaded: security_helper
INFO - 2024-05-12 17:25:33 --> Helper loaded: cookie_helper
INFO - 2024-05-12 17:25:33 --> Database Driver Class Initialized
INFO - 2024-05-12 17:25:33 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-12 17:25:33 --> Parser Class Initialized
INFO - 2024-05-12 17:25:33 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-05-12 17:25:33 --> Pagination Class Initialized
INFO - 2024-05-12 17:25:34 --> Form Validation Class Initialized
INFO - 2024-05-12 17:25:34 --> Controller Class Initialized
INFO - 2024-05-12 17:25:34 --> Model Class Initialized
DEBUG - 2024-05-12 17:25:34 --> Session class already loaded. Second attempt ignored.
INFO - 2024-05-12 17:25:34 --> Final output sent to browser
DEBUG - 2024-05-12 17:25:34 --> Total execution time: 0.0831
ERROR - 2024-05-12 17:25:34 --> $config['composer_autoload'] is set to TRUE but E:\xampp\htdocs\maurnaturo\application\vendor/autoload.php was not found.
INFO - 2024-05-12 17:25:34 --> Config Class Initialized
INFO - 2024-05-12 17:25:34 --> Hooks Class Initialized
DEBUG - 2024-05-12 17:25:34 --> UTF-8 Support Enabled
INFO - 2024-05-12 17:25:34 --> Utf8 Class Initialized
INFO - 2024-05-12 17:25:34 --> URI Class Initialized
INFO - 2024-05-12 17:25:34 --> Router Class Initialized
INFO - 2024-05-12 17:25:34 --> Output Class Initialized
INFO - 2024-05-12 17:25:34 --> Security Class Initialized
DEBUG - 2024-05-12 17:25:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-12 17:25:34 --> Input Class Initialized
INFO - 2024-05-12 17:25:34 --> Language Class Initialized
INFO - 2024-05-12 17:25:34 --> Loader Class Initialized
INFO - 2024-05-12 17:25:34 --> Helper loaded: url_helper
INFO - 2024-05-12 17:25:34 --> Helper loaded: file_helper
INFO - 2024-05-12 17:25:34 --> Helper loaded: html_helper
INFO - 2024-05-12 17:25:34 --> Helper loaded: text_helper
INFO - 2024-05-12 17:25:34 --> Helper loaded: form_helper
INFO - 2024-05-12 17:25:34 --> Helper loaded: lang_helper
INFO - 2024-05-12 17:25:34 --> Helper loaded: security_helper
INFO - 2024-05-12 17:25:34 --> Helper loaded: cookie_helper
INFO - 2024-05-12 17:25:34 --> Database Driver Class Initialized
INFO - 2024-05-12 17:25:34 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-12 17:25:34 --> Parser Class Initialized
INFO - 2024-05-12 17:25:34 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-05-12 17:25:34 --> Pagination Class Initialized
INFO - 2024-05-12 17:25:34 --> Form Validation Class Initialized
INFO - 2024-05-12 17:25:34 --> Controller Class Initialized
INFO - 2024-05-12 17:25:34 --> Model Class Initialized
DEBUG - 2024-05-12 17:25:34 --> Session class already loaded. Second attempt ignored.
INFO - 2024-05-12 17:25:34 --> Final output sent to browser
DEBUG - 2024-05-12 17:25:34 --> Total execution time: 0.0757
ERROR - 2024-05-12 17:25:34 --> $config['composer_autoload'] is set to TRUE but E:\xampp\htdocs\maurnaturo\application\vendor/autoload.php was not found.
INFO - 2024-05-12 17:25:34 --> Config Class Initialized
INFO - 2024-05-12 17:25:34 --> Hooks Class Initialized
DEBUG - 2024-05-12 17:25:34 --> UTF-8 Support Enabled
INFO - 2024-05-12 17:25:34 --> Utf8 Class Initialized
INFO - 2024-05-12 17:25:34 --> URI Class Initialized
INFO - 2024-05-12 17:25:34 --> Router Class Initialized
INFO - 2024-05-12 17:25:34 --> Output Class Initialized
INFO - 2024-05-12 17:25:34 --> Security Class Initialized
DEBUG - 2024-05-12 17:25:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-12 17:25:34 --> Input Class Initialized
INFO - 2024-05-12 17:25:34 --> Language Class Initialized
INFO - 2024-05-12 17:25:34 --> Loader Class Initialized
INFO - 2024-05-12 17:25:34 --> Helper loaded: url_helper
INFO - 2024-05-12 17:25:34 --> Helper loaded: file_helper
INFO - 2024-05-12 17:25:34 --> Helper loaded: html_helper
INFO - 2024-05-12 17:25:34 --> Helper loaded: text_helper
INFO - 2024-05-12 17:25:34 --> Helper loaded: form_helper
INFO - 2024-05-12 17:25:34 --> Helper loaded: lang_helper
INFO - 2024-05-12 17:25:34 --> Helper loaded: security_helper
INFO - 2024-05-12 17:25:34 --> Helper loaded: cookie_helper
INFO - 2024-05-12 17:25:34 --> Database Driver Class Initialized
INFO - 2024-05-12 17:25:34 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-12 17:25:34 --> Parser Class Initialized
INFO - 2024-05-12 17:25:34 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-05-12 17:25:34 --> Pagination Class Initialized
INFO - 2024-05-12 17:25:34 --> Form Validation Class Initialized
INFO - 2024-05-12 17:25:34 --> Controller Class Initialized
INFO - 2024-05-12 17:25:34 --> Model Class Initialized
DEBUG - 2024-05-12 17:25:34 --> Session class already loaded. Second attempt ignored.
INFO - 2024-05-12 17:25:34 --> Final output sent to browser
DEBUG - 2024-05-12 17:25:34 --> Total execution time: 0.0711
ERROR - 2024-05-12 17:25:37 --> $config['composer_autoload'] is set to TRUE but E:\xampp\htdocs\maurnaturo\application\vendor/autoload.php was not found.
INFO - 2024-05-12 17:25:37 --> Config Class Initialized
INFO - 2024-05-12 17:25:37 --> Hooks Class Initialized
DEBUG - 2024-05-12 17:25:37 --> UTF-8 Support Enabled
INFO - 2024-05-12 17:25:37 --> Utf8 Class Initialized
INFO - 2024-05-12 17:25:37 --> URI Class Initialized
INFO - 2024-05-12 17:25:37 --> Router Class Initialized
INFO - 2024-05-12 17:25:37 --> Output Class Initialized
INFO - 2024-05-12 17:25:37 --> Security Class Initialized
DEBUG - 2024-05-12 17:25:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-12 17:25:37 --> Input Class Initialized
INFO - 2024-05-12 17:25:37 --> Language Class Initialized
INFO - 2024-05-12 17:25:37 --> Loader Class Initialized
INFO - 2024-05-12 17:25:37 --> Helper loaded: url_helper
INFO - 2024-05-12 17:25:37 --> Helper loaded: file_helper
INFO - 2024-05-12 17:25:37 --> Helper loaded: html_helper
INFO - 2024-05-12 17:25:37 --> Helper loaded: text_helper
INFO - 2024-05-12 17:25:37 --> Helper loaded: form_helper
INFO - 2024-05-12 17:25:37 --> Helper loaded: lang_helper
INFO - 2024-05-12 17:25:37 --> Helper loaded: security_helper
INFO - 2024-05-12 17:25:37 --> Helper loaded: cookie_helper
INFO - 2024-05-12 17:25:37 --> Database Driver Class Initialized
INFO - 2024-05-12 17:25:37 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-12 17:25:37 --> Parser Class Initialized
INFO - 2024-05-12 17:25:37 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-05-12 17:25:37 --> Pagination Class Initialized
INFO - 2024-05-12 17:25:37 --> Form Validation Class Initialized
INFO - 2024-05-12 17:25:37 --> Controller Class Initialized
INFO - 2024-05-12 17:25:37 --> Model Class Initialized
DEBUG - 2024-05-12 17:25:37 --> Session class already loaded. Second attempt ignored.
INFO - 2024-05-12 17:25:37 --> Final output sent to browser
DEBUG - 2024-05-12 17:25:37 --> Total execution time: 0.0810
ERROR - 2024-05-12 17:25:53 --> $config['composer_autoload'] is set to TRUE but E:\xampp\htdocs\maurnaturo\application\vendor/autoload.php was not found.
INFO - 2024-05-12 17:25:53 --> Config Class Initialized
INFO - 2024-05-12 17:25:53 --> Hooks Class Initialized
DEBUG - 2024-05-12 17:25:53 --> UTF-8 Support Enabled
INFO - 2024-05-12 17:25:53 --> Utf8 Class Initialized
INFO - 2024-05-12 17:25:53 --> URI Class Initialized
INFO - 2024-05-12 17:25:53 --> Router Class Initialized
INFO - 2024-05-12 17:25:53 --> Output Class Initialized
INFO - 2024-05-12 17:25:53 --> Security Class Initialized
DEBUG - 2024-05-12 17:25:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-12 17:25:53 --> Input Class Initialized
INFO - 2024-05-12 17:25:53 --> Language Class Initialized
INFO - 2024-05-12 17:25:53 --> Loader Class Initialized
INFO - 2024-05-12 17:25:53 --> Helper loaded: url_helper
INFO - 2024-05-12 17:25:53 --> Helper loaded: file_helper
INFO - 2024-05-12 17:25:53 --> Helper loaded: html_helper
INFO - 2024-05-12 17:25:53 --> Helper loaded: text_helper
INFO - 2024-05-12 17:25:53 --> Helper loaded: form_helper
INFO - 2024-05-12 17:25:53 --> Helper loaded: lang_helper
INFO - 2024-05-12 17:25:53 --> Helper loaded: security_helper
INFO - 2024-05-12 17:25:53 --> Helper loaded: cookie_helper
INFO - 2024-05-12 17:25:53 --> Database Driver Class Initialized
INFO - 2024-05-12 17:25:53 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-12 17:25:53 --> Parser Class Initialized
INFO - 2024-05-12 17:25:53 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-05-12 17:25:53 --> Pagination Class Initialized
INFO - 2024-05-12 17:25:53 --> Form Validation Class Initialized
INFO - 2024-05-12 17:25:53 --> Controller Class Initialized
DEBUG - 2024-05-12 17:25:53 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-05-12 17:25:53 --> Session class already loaded. Second attempt ignored.
INFO - 2024-05-12 17:25:53 --> Model Class Initialized
ERROR - 2024-05-12 17:25:53 --> $config['composer_autoload'] is set to TRUE but E:\xampp\htdocs\maurnaturo\application\vendor/autoload.php was not found.
INFO - 2024-05-12 17:25:53 --> Config Class Initialized
INFO - 2024-05-12 17:25:53 --> Hooks Class Initialized
DEBUG - 2024-05-12 17:25:53 --> UTF-8 Support Enabled
INFO - 2024-05-12 17:25:53 --> Utf8 Class Initialized
INFO - 2024-05-12 17:25:53 --> URI Class Initialized
INFO - 2024-05-12 17:25:53 --> Router Class Initialized
INFO - 2024-05-12 17:25:53 --> Output Class Initialized
INFO - 2024-05-12 17:25:53 --> Security Class Initialized
DEBUG - 2024-05-12 17:25:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-12 17:25:53 --> Input Class Initialized
INFO - 2024-05-12 17:25:53 --> Language Class Initialized
INFO - 2024-05-12 17:25:53 --> Loader Class Initialized
INFO - 2024-05-12 17:25:53 --> Helper loaded: url_helper
INFO - 2024-05-12 17:25:53 --> Helper loaded: file_helper
INFO - 2024-05-12 17:25:53 --> Helper loaded: html_helper
INFO - 2024-05-12 17:25:53 --> Helper loaded: text_helper
INFO - 2024-05-12 17:25:53 --> Helper loaded: form_helper
INFO - 2024-05-12 17:25:53 --> Helper loaded: lang_helper
INFO - 2024-05-12 17:25:53 --> Helper loaded: security_helper
INFO - 2024-05-12 17:25:53 --> Helper loaded: cookie_helper
INFO - 2024-05-12 17:25:54 --> Database Driver Class Initialized
INFO - 2024-05-12 17:25:54 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-12 17:25:54 --> Parser Class Initialized
INFO - 2024-05-12 17:25:54 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-05-12 17:25:54 --> Pagination Class Initialized
INFO - 2024-05-12 17:25:54 --> Form Validation Class Initialized
INFO - 2024-05-12 17:25:54 --> Controller Class Initialized
DEBUG - 2024-05-12 17:25:54 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-05-12 17:25:54 --> Session class already loaded. Second attempt ignored.
INFO - 2024-05-12 17:25:54 --> Model Class Initialized
INFO - 2024-05-12 17:25:54 --> Model Class Initialized
DEBUG - 2024-05-12 17:25:54 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-05-12 17:25:54 --> Session class already loaded. Second attempt ignored.
INFO - 2024-05-12 17:25:54 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\payments/add_payment_form.php
DEBUG - 2024-05-12 17:25:54 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-05-12 17:25:54 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\include/top_menu.php
INFO - 2024-05-12 17:25:54 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\include/admin_loggedin_info.php
INFO - 2024-05-12 17:25:54 --> Model Class Initialized
INFO - 2024-05-12 17:25:54 --> Model Class Initialized
INFO - 2024-05-12 17:25:54 --> Model Class Initialized
INFO - 2024-05-12 17:25:54 --> Model Class Initialized
INFO - 2024-05-12 17:25:55 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\include/admin_header.php
INFO - 2024-05-12 17:25:55 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\include/admin_footer.php
INFO - 2024-05-12 17:25:55 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\admin_html_template.php
INFO - 2024-05-12 17:25:55 --> Final output sent to browser
DEBUG - 2024-05-12 17:25:55 --> Total execution time: 1.5903
ERROR - 2024-05-12 17:25:59 --> $config['composer_autoload'] is set to TRUE but E:\xampp\htdocs\maurnaturo\application\vendor/autoload.php was not found.
INFO - 2024-05-12 17:25:59 --> Config Class Initialized
INFO - 2024-05-12 17:25:59 --> Hooks Class Initialized
DEBUG - 2024-05-12 17:25:59 --> UTF-8 Support Enabled
INFO - 2024-05-12 17:25:59 --> Utf8 Class Initialized
INFO - 2024-05-12 17:25:59 --> URI Class Initialized
INFO - 2024-05-12 17:25:59 --> Router Class Initialized
INFO - 2024-05-12 17:25:59 --> Output Class Initialized
INFO - 2024-05-12 17:25:59 --> Security Class Initialized
DEBUG - 2024-05-12 17:25:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-12 17:25:59 --> Input Class Initialized
INFO - 2024-05-12 17:25:59 --> Language Class Initialized
INFO - 2024-05-12 17:25:59 --> Loader Class Initialized
INFO - 2024-05-12 17:25:59 --> Helper loaded: url_helper
INFO - 2024-05-12 17:25:59 --> Helper loaded: file_helper
INFO - 2024-05-12 17:25:59 --> Helper loaded: html_helper
INFO - 2024-05-12 17:25:59 --> Helper loaded: text_helper
INFO - 2024-05-12 17:25:59 --> Helper loaded: form_helper
INFO - 2024-05-12 17:25:59 --> Helper loaded: lang_helper
INFO - 2024-05-12 17:25:59 --> Helper loaded: security_helper
INFO - 2024-05-12 17:25:59 --> Helper loaded: cookie_helper
INFO - 2024-05-12 17:25:59 --> Database Driver Class Initialized
INFO - 2024-05-12 17:25:59 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-12 17:25:59 --> Parser Class Initialized
INFO - 2024-05-12 17:25:59 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-05-12 17:25:59 --> Pagination Class Initialized
INFO - 2024-05-12 17:25:59 --> Form Validation Class Initialized
INFO - 2024-05-12 17:25:59 --> Controller Class Initialized
DEBUG - 2024-05-12 17:25:59 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-05-12 17:25:59 --> Session class already loaded. Second attempt ignored.
INFO - 2024-05-12 17:25:59 --> Model Class Initialized
DEBUG - 2024-05-12 17:25:59 --> Lpayments class already loaded. Second attempt ignored.
INFO - 2024-05-12 17:25:59 --> Model Class Initialized
INFO - 2024-05-12 17:25:59 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\payments/payment.php
DEBUG - 2024-05-12 17:25:59 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-05-12 17:25:59 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\include/top_menu.php
INFO - 2024-05-12 17:25:59 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\include/admin_loggedin_info.php
INFO - 2024-05-12 17:25:59 --> Model Class Initialized
INFO - 2024-05-12 17:25:59 --> Model Class Initialized
INFO - 2024-05-12 17:25:59 --> Model Class Initialized
INFO - 2024-05-12 17:26:00 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\include/admin_header.php
INFO - 2024-05-12 17:26:00 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\include/admin_footer.php
INFO - 2024-05-12 17:26:00 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\admin_html_template.php
INFO - 2024-05-12 17:26:00 --> Final output sent to browser
DEBUG - 2024-05-12 17:26:00 --> Total execution time: 1.7859
ERROR - 2024-05-12 17:26:01 --> $config['composer_autoload'] is set to TRUE but E:\xampp\htdocs\maurnaturo\application\vendor/autoload.php was not found.
INFO - 2024-05-12 17:26:01 --> Config Class Initialized
INFO - 2024-05-12 17:26:01 --> Hooks Class Initialized
DEBUG - 2024-05-12 17:26:01 --> UTF-8 Support Enabled
INFO - 2024-05-12 17:26:01 --> Utf8 Class Initialized
INFO - 2024-05-12 17:26:01 --> URI Class Initialized
INFO - 2024-05-12 17:26:01 --> Router Class Initialized
INFO - 2024-05-12 17:26:01 --> Output Class Initialized
INFO - 2024-05-12 17:26:01 --> Security Class Initialized
DEBUG - 2024-05-12 17:26:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-12 17:26:01 --> Input Class Initialized
INFO - 2024-05-12 17:26:01 --> Language Class Initialized
INFO - 2024-05-12 17:26:01 --> Loader Class Initialized
INFO - 2024-05-12 17:26:01 --> Helper loaded: url_helper
INFO - 2024-05-12 17:26:01 --> Helper loaded: file_helper
INFO - 2024-05-12 17:26:01 --> Helper loaded: html_helper
INFO - 2024-05-12 17:26:01 --> Helper loaded: text_helper
INFO - 2024-05-12 17:26:01 --> Helper loaded: form_helper
INFO - 2024-05-12 17:26:01 --> Helper loaded: lang_helper
INFO - 2024-05-12 17:26:01 --> Helper loaded: security_helper
INFO - 2024-05-12 17:26:01 --> Helper loaded: cookie_helper
INFO - 2024-05-12 17:26:01 --> Database Driver Class Initialized
INFO - 2024-05-12 17:26:01 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-12 17:26:01 --> Parser Class Initialized
INFO - 2024-05-12 17:26:01 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-05-12 17:26:01 --> Pagination Class Initialized
INFO - 2024-05-12 17:26:01 --> Form Validation Class Initialized
INFO - 2024-05-12 17:26:01 --> Controller Class Initialized
DEBUG - 2024-05-12 17:26:01 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-05-12 17:26:01 --> Session class already loaded. Second attempt ignored.
INFO - 2024-05-12 17:26:01 --> Model Class Initialized
INFO - 2024-05-12 17:26:01 --> Final output sent to browser
DEBUG - 2024-05-12 17:26:01 --> Total execution time: 0.1443
ERROR - 2024-05-12 18:50:23 --> $config['composer_autoload'] is set to TRUE but E:\xampp\htdocs\maurnaturo\application\vendor/autoload.php was not found.
INFO - 2024-05-12 18:50:23 --> Config Class Initialized
INFO - 2024-05-12 18:50:23 --> Hooks Class Initialized
DEBUG - 2024-05-12 18:50:23 --> UTF-8 Support Enabled
INFO - 2024-05-12 18:50:23 --> Utf8 Class Initialized
INFO - 2024-05-12 18:50:23 --> URI Class Initialized
INFO - 2024-05-12 18:50:23 --> Router Class Initialized
INFO - 2024-05-12 18:50:23 --> Output Class Initialized
INFO - 2024-05-12 18:50:23 --> Security Class Initialized
DEBUG - 2024-05-12 18:50:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-12 18:50:23 --> Input Class Initialized
INFO - 2024-05-12 18:50:23 --> Language Class Initialized
INFO - 2024-05-12 18:50:23 --> Loader Class Initialized
INFO - 2024-05-12 18:50:23 --> Helper loaded: url_helper
INFO - 2024-05-12 18:50:23 --> Helper loaded: file_helper
INFO - 2024-05-12 18:50:23 --> Helper loaded: html_helper
INFO - 2024-05-12 18:50:23 --> Helper loaded: text_helper
INFO - 2024-05-12 18:50:23 --> Helper loaded: form_helper
INFO - 2024-05-12 18:50:23 --> Helper loaded: lang_helper
INFO - 2024-05-12 18:50:23 --> Helper loaded: security_helper
INFO - 2024-05-12 18:50:23 --> Helper loaded: cookie_helper
INFO - 2024-05-12 18:50:23 --> Database Driver Class Initialized
INFO - 2024-05-12 18:50:23 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-12 18:50:23 --> Parser Class Initialized
INFO - 2024-05-12 18:50:23 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-05-12 18:50:23 --> Pagination Class Initialized
INFO - 2024-05-12 18:50:23 --> Form Validation Class Initialized
INFO - 2024-05-12 18:50:23 --> Controller Class Initialized
DEBUG - 2024-05-12 18:50:23 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-05-12 18:50:23 --> Session class already loaded. Second attempt ignored.
INFO - 2024-05-12 18:50:23 --> Model Class Initialized
DEBUG - 2024-05-12 18:50:23 --> Lexpenses class already loaded. Second attempt ignored.
INFO - 2024-05-12 18:50:23 --> Model Class Initialized
INFO - 2024-05-12 18:50:23 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\expenses/expenses.php
DEBUG - 2024-05-12 18:50:23 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-05-12 18:50:23 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\include/top_menu.php
INFO - 2024-05-12 18:50:23 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\include/admin_loggedin_info.php
INFO - 2024-05-12 18:50:23 --> Model Class Initialized
INFO - 2024-05-12 18:50:23 --> Model Class Initialized
INFO - 2024-05-12 18:50:23 --> Model Class Initialized
INFO - 2024-05-12 18:50:24 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\include/admin_header.php
INFO - 2024-05-12 18:50:24 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\include/admin_footer.php
INFO - 2024-05-12 18:50:24 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\admin_html_template.php
INFO - 2024-05-12 18:50:24 --> Final output sent to browser
DEBUG - 2024-05-12 18:50:24 --> Total execution time: 1.6104
ERROR - 2024-05-12 18:50:25 --> $config['composer_autoload'] is set to TRUE but E:\xampp\htdocs\maurnaturo\application\vendor/autoload.php was not found.
INFO - 2024-05-12 18:50:25 --> Config Class Initialized
INFO - 2024-05-12 18:50:25 --> Hooks Class Initialized
DEBUG - 2024-05-12 18:50:25 --> UTF-8 Support Enabled
INFO - 2024-05-12 18:50:25 --> Utf8 Class Initialized
INFO - 2024-05-12 18:50:25 --> URI Class Initialized
INFO - 2024-05-12 18:50:25 --> Router Class Initialized
INFO - 2024-05-12 18:50:25 --> Output Class Initialized
INFO - 2024-05-12 18:50:25 --> Security Class Initialized
DEBUG - 2024-05-12 18:50:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-12 18:50:25 --> Input Class Initialized
INFO - 2024-05-12 18:50:25 --> Language Class Initialized
INFO - 2024-05-12 18:50:25 --> Loader Class Initialized
INFO - 2024-05-12 18:50:25 --> Helper loaded: url_helper
INFO - 2024-05-12 18:50:25 --> Helper loaded: file_helper
INFO - 2024-05-12 18:50:25 --> Helper loaded: html_helper
INFO - 2024-05-12 18:50:25 --> Helper loaded: text_helper
INFO - 2024-05-12 18:50:25 --> Helper loaded: form_helper
INFO - 2024-05-12 18:50:25 --> Helper loaded: lang_helper
INFO - 2024-05-12 18:50:25 --> Helper loaded: security_helper
INFO - 2024-05-12 18:50:25 --> Helper loaded: cookie_helper
INFO - 2024-05-12 18:50:25 --> Database Driver Class Initialized
INFO - 2024-05-12 18:50:25 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-12 18:50:25 --> Parser Class Initialized
INFO - 2024-05-12 18:50:25 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-05-12 18:50:25 --> Pagination Class Initialized
INFO - 2024-05-12 18:50:25 --> Form Validation Class Initialized
INFO - 2024-05-12 18:50:25 --> Controller Class Initialized
DEBUG - 2024-05-12 18:50:25 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-05-12 18:50:25 --> Session class already loaded. Second attempt ignored.
INFO - 2024-05-12 18:50:25 --> Model Class Initialized
INFO - 2024-05-12 18:50:25 --> Final output sent to browser
DEBUG - 2024-05-12 18:50:25 --> Total execution time: 0.2188
ERROR - 2024-05-12 18:58:46 --> $config['composer_autoload'] is set to TRUE but E:\xampp\htdocs\maurnaturo\application\vendor/autoload.php was not found.
INFO - 2024-05-12 18:58:46 --> Config Class Initialized
INFO - 2024-05-12 18:58:46 --> Hooks Class Initialized
DEBUG - 2024-05-12 18:58:46 --> UTF-8 Support Enabled
INFO - 2024-05-12 18:58:46 --> Utf8 Class Initialized
INFO - 2024-05-12 18:58:46 --> URI Class Initialized
INFO - 2024-05-12 18:58:46 --> Router Class Initialized
INFO - 2024-05-12 18:58:46 --> Output Class Initialized
INFO - 2024-05-12 18:58:46 --> Security Class Initialized
DEBUG - 2024-05-12 18:58:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-12 18:58:46 --> Input Class Initialized
INFO - 2024-05-12 18:58:46 --> Language Class Initialized
INFO - 2024-05-12 18:58:46 --> Loader Class Initialized
INFO - 2024-05-12 18:58:46 --> Helper loaded: url_helper
INFO - 2024-05-12 18:58:46 --> Helper loaded: file_helper
INFO - 2024-05-12 18:58:46 --> Helper loaded: html_helper
INFO - 2024-05-12 18:58:46 --> Helper loaded: text_helper
INFO - 2024-05-12 18:58:46 --> Helper loaded: form_helper
INFO - 2024-05-12 18:58:46 --> Helper loaded: lang_helper
INFO - 2024-05-12 18:58:46 --> Helper loaded: security_helper
INFO - 2024-05-12 18:58:46 --> Helper loaded: cookie_helper
INFO - 2024-05-12 18:58:46 --> Database Driver Class Initialized
INFO - 2024-05-12 18:58:46 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-12 18:58:46 --> Parser Class Initialized
INFO - 2024-05-12 18:58:46 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-05-12 18:58:46 --> Pagination Class Initialized
INFO - 2024-05-12 18:58:46 --> Form Validation Class Initialized
INFO - 2024-05-12 18:58:46 --> Controller Class Initialized
DEBUG - 2024-05-12 18:58:46 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-05-12 18:58:46 --> Session class already loaded. Second attempt ignored.
INFO - 2024-05-12 18:58:46 --> Model Class Initialized
DEBUG - 2024-05-12 18:58:46 --> Lexpenses class already loaded. Second attempt ignored.
INFO - 2024-05-12 18:58:46 --> Model Class Initialized
INFO - 2024-05-12 18:58:47 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\expenses/expenses.php
DEBUG - 2024-05-12 18:58:47 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-05-12 18:58:47 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\include/top_menu.php
INFO - 2024-05-12 18:58:47 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\include/admin_loggedin_info.php
INFO - 2024-05-12 18:58:47 --> Model Class Initialized
INFO - 2024-05-12 18:58:47 --> Model Class Initialized
INFO - 2024-05-12 18:58:47 --> Model Class Initialized
INFO - 2024-05-12 18:58:48 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\include/admin_header.php
INFO - 2024-05-12 18:58:48 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\include/admin_footer.php
INFO - 2024-05-12 18:58:48 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\admin_html_template.php
INFO - 2024-05-12 18:58:48 --> Final output sent to browser
DEBUG - 2024-05-12 18:58:48 --> Total execution time: 1.9236
ERROR - 2024-05-12 18:59:03 --> $config['composer_autoload'] is set to TRUE but E:\xampp\htdocs\maurnaturo\application\vendor/autoload.php was not found.
INFO - 2024-05-12 18:59:03 --> Config Class Initialized
INFO - 2024-05-12 18:59:03 --> Hooks Class Initialized
DEBUG - 2024-05-12 18:59:03 --> UTF-8 Support Enabled
INFO - 2024-05-12 18:59:03 --> Utf8 Class Initialized
INFO - 2024-05-12 18:59:03 --> URI Class Initialized
INFO - 2024-05-12 18:59:03 --> Router Class Initialized
INFO - 2024-05-12 18:59:03 --> Output Class Initialized
INFO - 2024-05-12 18:59:03 --> Security Class Initialized
DEBUG - 2024-05-12 18:59:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-12 18:59:03 --> Input Class Initialized
INFO - 2024-05-12 18:59:03 --> Language Class Initialized
ERROR - 2024-05-12 18:59:03 --> 404 Page Not Found: Assets/plugins
ERROR - 2024-05-12 18:59:03 --> $config['composer_autoload'] is set to TRUE but E:\xampp\htdocs\maurnaturo\application\vendor/autoload.php was not found.
INFO - 2024-05-12 18:59:03 --> Config Class Initialized
INFO - 2024-05-12 18:59:03 --> Hooks Class Initialized
DEBUG - 2024-05-12 18:59:03 --> UTF-8 Support Enabled
INFO - 2024-05-12 18:59:03 --> Utf8 Class Initialized
INFO - 2024-05-12 18:59:03 --> URI Class Initialized
INFO - 2024-05-12 18:59:03 --> Router Class Initialized
INFO - 2024-05-12 18:59:03 --> Output Class Initialized
INFO - 2024-05-12 18:59:03 --> Security Class Initialized
DEBUG - 2024-05-12 18:59:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-12 18:59:03 --> Input Class Initialized
INFO - 2024-05-12 18:59:03 --> Language Class Initialized
ERROR - 2024-05-12 18:59:03 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2024-05-12 18:59:22 --> $config['composer_autoload'] is set to TRUE but E:\xampp\htdocs\maurnaturo\application\vendor/autoload.php was not found.
INFO - 2024-05-12 18:59:22 --> Config Class Initialized
INFO - 2024-05-12 18:59:22 --> Hooks Class Initialized
DEBUG - 2024-05-12 18:59:22 --> UTF-8 Support Enabled
INFO - 2024-05-12 18:59:22 --> Utf8 Class Initialized
INFO - 2024-05-12 18:59:22 --> URI Class Initialized
INFO - 2024-05-12 18:59:22 --> Router Class Initialized
INFO - 2024-05-12 18:59:22 --> Output Class Initialized
INFO - 2024-05-12 18:59:22 --> Security Class Initialized
DEBUG - 2024-05-12 18:59:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-12 18:59:22 --> Input Class Initialized
INFO - 2024-05-12 18:59:22 --> Language Class Initialized
INFO - 2024-05-12 18:59:22 --> Loader Class Initialized
INFO - 2024-05-12 18:59:22 --> Helper loaded: url_helper
INFO - 2024-05-12 18:59:22 --> Helper loaded: file_helper
INFO - 2024-05-12 18:59:22 --> Helper loaded: html_helper
INFO - 2024-05-12 18:59:22 --> Helper loaded: text_helper
INFO - 2024-05-12 18:59:22 --> Helper loaded: form_helper
INFO - 2024-05-12 18:59:22 --> Helper loaded: lang_helper
INFO - 2024-05-12 18:59:22 --> Helper loaded: security_helper
INFO - 2024-05-12 18:59:22 --> Helper loaded: cookie_helper
INFO - 2024-05-12 18:59:22 --> Database Driver Class Initialized
INFO - 2024-05-12 18:59:22 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-12 18:59:22 --> Parser Class Initialized
INFO - 2024-05-12 18:59:22 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-05-12 18:59:22 --> Pagination Class Initialized
INFO - 2024-05-12 18:59:22 --> Form Validation Class Initialized
INFO - 2024-05-12 18:59:22 --> Controller Class Initialized
DEBUG - 2024-05-12 18:59:22 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-05-12 18:59:22 --> Session class already loaded. Second attempt ignored.
INFO - 2024-05-12 18:59:22 --> Model Class Initialized
DEBUG - 2024-05-12 18:59:22 --> Lexpenses class already loaded. Second attempt ignored.
INFO - 2024-05-12 18:59:22 --> Model Class Initialized
INFO - 2024-05-12 18:59:22 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\expenses/expenses.php
DEBUG - 2024-05-12 18:59:22 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-05-12 18:59:22 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\include/top_menu.php
INFO - 2024-05-12 18:59:22 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\include/admin_loggedin_info.php
INFO - 2024-05-12 18:59:22 --> Model Class Initialized
INFO - 2024-05-12 18:59:22 --> Model Class Initialized
INFO - 2024-05-12 18:59:22 --> Model Class Initialized
INFO - 2024-05-12 18:59:23 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\include/admin_header.php
INFO - 2024-05-12 18:59:23 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\include/admin_footer.php
INFO - 2024-05-12 18:59:23 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\admin_html_template.php
INFO - 2024-05-12 18:59:23 --> Final output sent to browser
DEBUG - 2024-05-12 18:59:23 --> Total execution time: 1.7627
ERROR - 2024-05-12 18:59:24 --> $config['composer_autoload'] is set to TRUE but E:\xampp\htdocs\maurnaturo\application\vendor/autoload.php was not found.
INFO - 2024-05-12 18:59:24 --> Config Class Initialized
INFO - 2024-05-12 18:59:24 --> Hooks Class Initialized
DEBUG - 2024-05-12 18:59:24 --> UTF-8 Support Enabled
INFO - 2024-05-12 18:59:24 --> Utf8 Class Initialized
INFO - 2024-05-12 18:59:24 --> URI Class Initialized
INFO - 2024-05-12 18:59:24 --> Router Class Initialized
INFO - 2024-05-12 18:59:24 --> Output Class Initialized
INFO - 2024-05-12 18:59:24 --> Security Class Initialized
DEBUG - 2024-05-12 18:59:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-12 18:59:24 --> Input Class Initialized
INFO - 2024-05-12 18:59:24 --> Language Class Initialized
ERROR - 2024-05-12 18:59:24 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2024-05-12 18:59:24 --> $config['composer_autoload'] is set to TRUE but E:\xampp\htdocs\maurnaturo\application\vendor/autoload.php was not found.
INFO - 2024-05-12 18:59:24 --> Config Class Initialized
INFO - 2024-05-12 18:59:24 --> Hooks Class Initialized
DEBUG - 2024-05-12 18:59:24 --> UTF-8 Support Enabled
INFO - 2024-05-12 18:59:24 --> Utf8 Class Initialized
INFO - 2024-05-12 18:59:24 --> URI Class Initialized
INFO - 2024-05-12 18:59:24 --> Router Class Initialized
INFO - 2024-05-12 18:59:24 --> Output Class Initialized
INFO - 2024-05-12 18:59:24 --> Security Class Initialized
DEBUG - 2024-05-12 18:59:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-12 18:59:24 --> Input Class Initialized
INFO - 2024-05-12 18:59:24 --> Language Class Initialized
ERROR - 2024-05-12 18:59:24 --> 404 Page Not Found: Assets/plugins
ERROR - 2024-05-12 18:59:50 --> $config['composer_autoload'] is set to TRUE but E:\xampp\htdocs\maurnaturo\application\vendor/autoload.php was not found.
INFO - 2024-05-12 18:59:50 --> Config Class Initialized
INFO - 2024-05-12 18:59:50 --> Hooks Class Initialized
DEBUG - 2024-05-12 18:59:50 --> UTF-8 Support Enabled
INFO - 2024-05-12 18:59:50 --> Utf8 Class Initialized
INFO - 2024-05-12 18:59:50 --> URI Class Initialized
INFO - 2024-05-12 18:59:50 --> Router Class Initialized
INFO - 2024-05-12 18:59:50 --> Output Class Initialized
INFO - 2024-05-12 18:59:50 --> Security Class Initialized
DEBUG - 2024-05-12 18:59:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-12 18:59:50 --> Input Class Initialized
INFO - 2024-05-12 18:59:50 --> Language Class Initialized
INFO - 2024-05-12 18:59:50 --> Loader Class Initialized
INFO - 2024-05-12 18:59:50 --> Helper loaded: url_helper
INFO - 2024-05-12 18:59:50 --> Helper loaded: file_helper
INFO - 2024-05-12 18:59:50 --> Helper loaded: html_helper
INFO - 2024-05-12 18:59:50 --> Helper loaded: text_helper
INFO - 2024-05-12 18:59:50 --> Helper loaded: form_helper
INFO - 2024-05-12 18:59:50 --> Helper loaded: lang_helper
INFO - 2024-05-12 18:59:50 --> Helper loaded: security_helper
INFO - 2024-05-12 18:59:50 --> Helper loaded: cookie_helper
INFO - 2024-05-12 18:59:50 --> Database Driver Class Initialized
INFO - 2024-05-12 18:59:50 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-12 18:59:50 --> Parser Class Initialized
INFO - 2024-05-12 18:59:50 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-05-12 18:59:50 --> Pagination Class Initialized
INFO - 2024-05-12 18:59:50 --> Form Validation Class Initialized
INFO - 2024-05-12 18:59:50 --> Controller Class Initialized
DEBUG - 2024-05-12 18:59:50 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-05-12 18:59:50 --> Session class already loaded. Second attempt ignored.
INFO - 2024-05-12 18:59:50 --> Model Class Initialized
DEBUG - 2024-05-12 18:59:50 --> Lexpenses class already loaded. Second attempt ignored.
INFO - 2024-05-12 18:59:50 --> Model Class Initialized
INFO - 2024-05-12 18:59:50 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\expenses/expenses.php
DEBUG - 2024-05-12 18:59:50 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-05-12 18:59:50 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\include/top_menu.php
INFO - 2024-05-12 18:59:50 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\include/admin_loggedin_info.php
INFO - 2024-05-12 18:59:50 --> Model Class Initialized
INFO - 2024-05-12 18:59:50 --> Model Class Initialized
INFO - 2024-05-12 18:59:50 --> Model Class Initialized
INFO - 2024-05-12 18:59:51 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\include/admin_header.php
INFO - 2024-05-12 18:59:51 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\include/admin_footer.php
INFO - 2024-05-12 18:59:51 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\admin_html_template.php
INFO - 2024-05-12 18:59:51 --> Final output sent to browser
DEBUG - 2024-05-12 18:59:51 --> Total execution time: 1.4024
ERROR - 2024-05-12 18:59:52 --> $config['composer_autoload'] is set to TRUE but E:\xampp\htdocs\maurnaturo\application\vendor/autoload.php was not found.
INFO - 2024-05-12 18:59:52 --> Config Class Initialized
INFO - 2024-05-12 18:59:52 --> Hooks Class Initialized
DEBUG - 2024-05-12 18:59:52 --> UTF-8 Support Enabled
INFO - 2024-05-12 18:59:52 --> Utf8 Class Initialized
INFO - 2024-05-12 18:59:52 --> URI Class Initialized
INFO - 2024-05-12 18:59:52 --> Router Class Initialized
INFO - 2024-05-12 18:59:52 --> Output Class Initialized
INFO - 2024-05-12 18:59:52 --> Security Class Initialized
DEBUG - 2024-05-12 18:59:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-12 18:59:52 --> Input Class Initialized
INFO - 2024-05-12 18:59:52 --> Language Class Initialized
ERROR - 2024-05-12 18:59:52 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2024-05-12 18:59:52 --> $config['composer_autoload'] is set to TRUE but E:\xampp\htdocs\maurnaturo\application\vendor/autoload.php was not found.
INFO - 2024-05-12 18:59:52 --> Config Class Initialized
INFO - 2024-05-12 18:59:52 --> Hooks Class Initialized
DEBUG - 2024-05-12 18:59:52 --> UTF-8 Support Enabled
INFO - 2024-05-12 18:59:52 --> Utf8 Class Initialized
INFO - 2024-05-12 18:59:52 --> URI Class Initialized
INFO - 2024-05-12 18:59:52 --> Router Class Initialized
INFO - 2024-05-12 18:59:52 --> Output Class Initialized
INFO - 2024-05-12 18:59:52 --> Security Class Initialized
DEBUG - 2024-05-12 18:59:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-12 18:59:52 --> Input Class Initialized
INFO - 2024-05-12 18:59:52 --> Language Class Initialized
ERROR - 2024-05-12 18:59:52 --> $config['composer_autoload'] is set to TRUE but E:\xampp\htdocs\maurnaturo\application\vendor/autoload.php was not found.
INFO - 2024-05-12 18:59:52 --> Config Class Initialized
INFO - 2024-05-12 18:59:52 --> Hooks Class Initialized
INFO - 2024-05-12 18:59:52 --> Loader Class Initialized
DEBUG - 2024-05-12 18:59:52 --> UTF-8 Support Enabled
INFO - 2024-05-12 18:59:52 --> Utf8 Class Initialized
INFO - 2024-05-12 18:59:52 --> Helper loaded: url_helper
INFO - 2024-05-12 18:59:52 --> URI Class Initialized
INFO - 2024-05-12 18:59:52 --> Helper loaded: file_helper
INFO - 2024-05-12 18:59:52 --> Router Class Initialized
INFO - 2024-05-12 18:59:52 --> Helper loaded: html_helper
INFO - 2024-05-12 18:59:52 --> Output Class Initialized
INFO - 2024-05-12 18:59:52 --> Helper loaded: text_helper
INFO - 2024-05-12 18:59:52 --> Security Class Initialized
INFO - 2024-05-12 18:59:52 --> Helper loaded: form_helper
INFO - 2024-05-12 18:59:52 --> Helper loaded: lang_helper
INFO - 2024-05-12 18:59:52 --> Helper loaded: security_helper
INFO - 2024-05-12 18:59:52 --> Helper loaded: cookie_helper
DEBUG - 2024-05-12 18:59:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-12 18:59:52 --> Input Class Initialized
INFO - 2024-05-12 18:59:52 --> Language Class Initialized
ERROR - 2024-05-12 18:59:52 --> 404 Page Not Found: Assets/plugins
INFO - 2024-05-12 18:59:52 --> Database Driver Class Initialized
INFO - 2024-05-12 18:59:52 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-12 18:59:52 --> Parser Class Initialized
INFO - 2024-05-12 18:59:52 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-05-12 18:59:52 --> Pagination Class Initialized
INFO - 2024-05-12 18:59:52 --> Form Validation Class Initialized
INFO - 2024-05-12 18:59:52 --> Controller Class Initialized
DEBUG - 2024-05-12 18:59:52 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-05-12 18:59:52 --> Session class already loaded. Second attempt ignored.
INFO - 2024-05-12 18:59:52 --> Model Class Initialized
INFO - 2024-05-12 18:59:52 --> Final output sent to browser
DEBUG - 2024-05-12 18:59:52 --> Total execution time: 0.3211
ERROR - 2024-05-12 19:00:38 --> $config['composer_autoload'] is set to TRUE but E:\xampp\htdocs\maurnaturo\application\vendor/autoload.php was not found.
INFO - 2024-05-12 19:00:38 --> Config Class Initialized
INFO - 2024-05-12 19:00:38 --> Hooks Class Initialized
DEBUG - 2024-05-12 19:00:38 --> UTF-8 Support Enabled
INFO - 2024-05-12 19:00:38 --> Utf8 Class Initialized
INFO - 2024-05-12 19:00:38 --> URI Class Initialized
INFO - 2024-05-12 19:00:38 --> Router Class Initialized
INFO - 2024-05-12 19:00:38 --> Output Class Initialized
INFO - 2024-05-12 19:00:38 --> Security Class Initialized
DEBUG - 2024-05-12 19:00:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-12 19:00:38 --> Input Class Initialized
INFO - 2024-05-12 19:00:38 --> Language Class Initialized
INFO - 2024-05-12 19:00:38 --> Loader Class Initialized
INFO - 2024-05-12 19:00:38 --> Helper loaded: url_helper
INFO - 2024-05-12 19:00:38 --> Helper loaded: file_helper
INFO - 2024-05-12 19:00:38 --> Helper loaded: html_helper
INFO - 2024-05-12 19:00:38 --> Helper loaded: text_helper
INFO - 2024-05-12 19:00:38 --> Helper loaded: form_helper
INFO - 2024-05-12 19:00:38 --> Helper loaded: lang_helper
INFO - 2024-05-12 19:00:38 --> Helper loaded: security_helper
INFO - 2024-05-12 19:00:38 --> Helper loaded: cookie_helper
INFO - 2024-05-12 19:00:38 --> Database Driver Class Initialized
INFO - 2024-05-12 19:00:38 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-12 19:00:38 --> Parser Class Initialized
INFO - 2024-05-12 19:00:38 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-05-12 19:00:38 --> Pagination Class Initialized
INFO - 2024-05-12 19:00:38 --> Form Validation Class Initialized
INFO - 2024-05-12 19:00:38 --> Controller Class Initialized
DEBUG - 2024-05-12 19:00:38 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-05-12 19:00:38 --> Session class already loaded. Second attempt ignored.
INFO - 2024-05-12 19:00:38 --> Model Class Initialized
DEBUG - 2024-05-12 19:00:38 --> Lexpenses class already loaded. Second attempt ignored.
INFO - 2024-05-12 19:00:38 --> Model Class Initialized
INFO - 2024-05-12 19:00:38 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\expenses/expenses.php
DEBUG - 2024-05-12 19:00:38 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-05-12 19:00:38 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\include/top_menu.php
INFO - 2024-05-12 19:00:38 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\include/admin_loggedin_info.php
INFO - 2024-05-12 19:00:38 --> Model Class Initialized
INFO - 2024-05-12 19:00:38 --> Model Class Initialized
INFO - 2024-05-12 19:00:38 --> Model Class Initialized
INFO - 2024-05-12 19:00:39 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\include/admin_header.php
INFO - 2024-05-12 19:00:39 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\include/admin_footer.php
INFO - 2024-05-12 19:00:39 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\admin_html_template.php
INFO - 2024-05-12 19:00:39 --> Final output sent to browser
DEBUG - 2024-05-12 19:00:39 --> Total execution time: 1.7227
ERROR - 2024-05-12 19:00:40 --> $config['composer_autoload'] is set to TRUE but E:\xampp\htdocs\maurnaturo\application\vendor/autoload.php was not found.
INFO - 2024-05-12 19:00:40 --> Config Class Initialized
INFO - 2024-05-12 19:00:40 --> Hooks Class Initialized
DEBUG - 2024-05-12 19:00:40 --> UTF-8 Support Enabled
INFO - 2024-05-12 19:00:40 --> Utf8 Class Initialized
INFO - 2024-05-12 19:00:40 --> URI Class Initialized
INFO - 2024-05-12 19:00:40 --> Router Class Initialized
INFO - 2024-05-12 19:00:40 --> Output Class Initialized
INFO - 2024-05-12 19:00:40 --> Security Class Initialized
DEBUG - 2024-05-12 19:00:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-12 19:00:40 --> Input Class Initialized
INFO - 2024-05-12 19:00:40 --> Language Class Initialized
INFO - 2024-05-12 19:00:40 --> Loader Class Initialized
INFO - 2024-05-12 19:00:40 --> Helper loaded: url_helper
INFO - 2024-05-12 19:00:40 --> Helper loaded: file_helper
INFO - 2024-05-12 19:00:40 --> Helper loaded: html_helper
INFO - 2024-05-12 19:00:40 --> Helper loaded: text_helper
INFO - 2024-05-12 19:00:40 --> Helper loaded: form_helper
INFO - 2024-05-12 19:00:40 --> Helper loaded: lang_helper
INFO - 2024-05-12 19:00:40 --> Helper loaded: security_helper
INFO - 2024-05-12 19:00:40 --> Helper loaded: cookie_helper
INFO - 2024-05-12 19:00:40 --> Database Driver Class Initialized
INFO - 2024-05-12 19:00:40 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-12 19:00:40 --> Parser Class Initialized
INFO - 2024-05-12 19:00:40 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-05-12 19:00:40 --> Pagination Class Initialized
INFO - 2024-05-12 19:00:40 --> Form Validation Class Initialized
INFO - 2024-05-12 19:00:40 --> Controller Class Initialized
DEBUG - 2024-05-12 19:00:40 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-05-12 19:00:40 --> Session class already loaded. Second attempt ignored.
INFO - 2024-05-12 19:00:40 --> Model Class Initialized
INFO - 2024-05-12 19:00:40 --> Final output sent to browser
DEBUG - 2024-05-12 19:00:40 --> Total execution time: 0.1024
ERROR - 2024-05-12 19:01:12 --> $config['composer_autoload'] is set to TRUE but E:\xampp\htdocs\maurnaturo\application\vendor/autoload.php was not found.
INFO - 2024-05-12 19:01:12 --> Config Class Initialized
INFO - 2024-05-12 19:01:12 --> Hooks Class Initialized
DEBUG - 2024-05-12 19:01:12 --> UTF-8 Support Enabled
INFO - 2024-05-12 19:01:12 --> Utf8 Class Initialized
INFO - 2024-05-12 19:01:12 --> URI Class Initialized
INFO - 2024-05-12 19:01:12 --> Router Class Initialized
INFO - 2024-05-12 19:01:12 --> Output Class Initialized
INFO - 2024-05-12 19:01:12 --> Security Class Initialized
DEBUG - 2024-05-12 19:01:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-12 19:01:12 --> Input Class Initialized
INFO - 2024-05-12 19:01:12 --> Language Class Initialized
ERROR - 2024-05-12 19:01:12 --> 404 Page Not Found: Cexpenses/expenses_approve
ERROR - 2024-05-12 19:01:51 --> $config['composer_autoload'] is set to TRUE but E:\xampp\htdocs\maurnaturo\application\vendor/autoload.php was not found.
INFO - 2024-05-12 19:01:51 --> Config Class Initialized
INFO - 2024-05-12 19:01:51 --> Hooks Class Initialized
DEBUG - 2024-05-12 19:01:51 --> UTF-8 Support Enabled
INFO - 2024-05-12 19:01:51 --> Utf8 Class Initialized
INFO - 2024-05-12 19:01:51 --> URI Class Initialized
INFO - 2024-05-12 19:01:51 --> Router Class Initialized
INFO - 2024-05-12 19:01:51 --> Output Class Initialized
INFO - 2024-05-12 19:01:51 --> Security Class Initialized
DEBUG - 2024-05-12 19:01:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-12 19:01:51 --> Input Class Initialized
INFO - 2024-05-12 19:01:51 --> Language Class Initialized
INFO - 2024-05-12 19:01:51 --> Loader Class Initialized
INFO - 2024-05-12 19:01:51 --> Helper loaded: url_helper
INFO - 2024-05-12 19:01:51 --> Helper loaded: file_helper
INFO - 2024-05-12 19:01:51 --> Helper loaded: html_helper
INFO - 2024-05-12 19:01:51 --> Helper loaded: text_helper
INFO - 2024-05-12 19:01:51 --> Helper loaded: form_helper
INFO - 2024-05-12 19:01:51 --> Helper loaded: lang_helper
INFO - 2024-05-12 19:01:51 --> Helper loaded: security_helper
INFO - 2024-05-12 19:01:51 --> Helper loaded: cookie_helper
INFO - 2024-05-12 19:01:51 --> Database Driver Class Initialized
INFO - 2024-05-12 19:01:51 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-12 19:01:51 --> Parser Class Initialized
INFO - 2024-05-12 19:01:51 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-05-12 19:01:51 --> Pagination Class Initialized
INFO - 2024-05-12 19:01:51 --> Form Validation Class Initialized
INFO - 2024-05-12 19:01:51 --> Controller Class Initialized
DEBUG - 2024-05-12 19:01:51 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-05-12 19:01:51 --> Session class already loaded. Second attempt ignored.
INFO - 2024-05-12 19:01:51 --> Model Class Initialized
INFO - 2024-05-12 19:01:51 --> Final output sent to browser
DEBUG - 2024-05-12 19:01:51 --> Total execution time: 0.0822
ERROR - 2024-05-12 19:03:58 --> $config['composer_autoload'] is set to TRUE but E:\xampp\htdocs\maurnaturo\application\vendor/autoload.php was not found.
INFO - 2024-05-12 19:03:58 --> Config Class Initialized
INFO - 2024-05-12 19:03:58 --> Hooks Class Initialized
DEBUG - 2024-05-12 19:03:58 --> UTF-8 Support Enabled
INFO - 2024-05-12 19:03:58 --> Utf8 Class Initialized
INFO - 2024-05-12 19:03:58 --> URI Class Initialized
INFO - 2024-05-12 19:03:58 --> Router Class Initialized
INFO - 2024-05-12 19:03:58 --> Output Class Initialized
INFO - 2024-05-12 19:03:58 --> Security Class Initialized
DEBUG - 2024-05-12 19:03:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-12 19:03:58 --> Input Class Initialized
INFO - 2024-05-12 19:03:58 --> Language Class Initialized
INFO - 2024-05-12 19:03:58 --> Loader Class Initialized
INFO - 2024-05-12 19:03:58 --> Helper loaded: url_helper
INFO - 2024-05-12 19:03:58 --> Helper loaded: file_helper
INFO - 2024-05-12 19:03:58 --> Helper loaded: html_helper
INFO - 2024-05-12 19:03:58 --> Helper loaded: text_helper
INFO - 2024-05-12 19:03:58 --> Helper loaded: form_helper
INFO - 2024-05-12 19:03:58 --> Helper loaded: lang_helper
INFO - 2024-05-12 19:03:58 --> Helper loaded: security_helper
INFO - 2024-05-12 19:03:58 --> Helper loaded: cookie_helper
INFO - 2024-05-12 19:03:58 --> Database Driver Class Initialized
INFO - 2024-05-12 19:03:58 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-12 19:03:58 --> Parser Class Initialized
INFO - 2024-05-12 19:03:58 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-05-12 19:03:58 --> Pagination Class Initialized
INFO - 2024-05-12 19:03:58 --> Form Validation Class Initialized
INFO - 2024-05-12 19:03:58 --> Controller Class Initialized
INFO - 2024-05-12 19:03:58 --> Model Class Initialized
DEBUG - 2024-05-12 19:03:58 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-05-12 19:03:58 --> Session class already loaded. Second attempt ignored.
INFO - 2024-05-12 19:03:58 --> Model Class Initialized
DEBUG - 2024-05-12 19:03:58 --> Session class already loaded. Second attempt ignored.
INFO - 2024-05-12 19:03:58 --> Model Class Initialized
ERROR - 2024-05-12 19:03:58 --> Severity: Warning --> Invalid argument supplied for foreach() E:\xampp\htdocs\maurnaturo\application\views\invoice\add_invoice_form.php 195
INFO - 2024-05-12 19:03:58 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\invoice/add_invoice_form.php
DEBUG - 2024-05-12 19:03:58 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-05-12 19:03:58 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\include/top_menu.php
INFO - 2024-05-12 19:03:58 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\include/admin_loggedin_info.php
INFO - 2024-05-12 19:03:58 --> Model Class Initialized
INFO - 2024-05-12 19:03:58 --> Model Class Initialized
INFO - 2024-05-12 19:03:58 --> Model Class Initialized
INFO - 2024-05-12 19:04:00 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\include/admin_header.php
INFO - 2024-05-12 19:04:00 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\include/admin_footer.php
INFO - 2024-05-12 19:04:00 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\admin_html_template.php
INFO - 2024-05-12 19:04:00 --> Final output sent to browser
DEBUG - 2024-05-12 19:04:00 --> Total execution time: 1.8032
ERROR - 2024-05-12 19:04:06 --> $config['composer_autoload'] is set to TRUE but E:\xampp\htdocs\maurnaturo\application\vendor/autoload.php was not found.
INFO - 2024-05-12 19:04:06 --> Config Class Initialized
INFO - 2024-05-12 19:04:06 --> Hooks Class Initialized
DEBUG - 2024-05-12 19:04:06 --> UTF-8 Support Enabled
INFO - 2024-05-12 19:04:06 --> Utf8 Class Initialized
INFO - 2024-05-12 19:04:06 --> URI Class Initialized
INFO - 2024-05-12 19:04:06 --> Router Class Initialized
INFO - 2024-05-12 19:04:06 --> Output Class Initialized
INFO - 2024-05-12 19:04:06 --> Security Class Initialized
DEBUG - 2024-05-12 19:04:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-12 19:04:06 --> Input Class Initialized
INFO - 2024-05-12 19:04:06 --> Language Class Initialized
INFO - 2024-05-12 19:04:06 --> Loader Class Initialized
INFO - 2024-05-12 19:04:06 --> Helper loaded: url_helper
INFO - 2024-05-12 19:04:06 --> Helper loaded: file_helper
INFO - 2024-05-12 19:04:06 --> Helper loaded: html_helper
INFO - 2024-05-12 19:04:06 --> Helper loaded: text_helper
INFO - 2024-05-12 19:04:06 --> Helper loaded: form_helper
INFO - 2024-05-12 19:04:06 --> Helper loaded: lang_helper
INFO - 2024-05-12 19:04:06 --> Helper loaded: security_helper
INFO - 2024-05-12 19:04:06 --> Helper loaded: cookie_helper
INFO - 2024-05-12 19:04:06 --> Database Driver Class Initialized
INFO - 2024-05-12 19:04:06 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-12 19:04:06 --> Parser Class Initialized
INFO - 2024-05-12 19:04:06 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-05-12 19:04:06 --> Pagination Class Initialized
INFO - 2024-05-12 19:04:06 --> Form Validation Class Initialized
INFO - 2024-05-12 19:04:06 --> Controller Class Initialized
DEBUG - 2024-05-12 19:04:06 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-05-12 19:04:06 --> Session class already loaded. Second attempt ignored.
INFO - 2024-05-12 19:04:06 --> Model Class Initialized
DEBUG - 2024-05-12 19:04:06 --> Lexpenses class already loaded. Second attempt ignored.
INFO - 2024-05-12 19:04:06 --> Model Class Initialized
INFO - 2024-05-12 19:04:06 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\expenses/expenses.php
DEBUG - 2024-05-12 19:04:06 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-05-12 19:04:06 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\include/top_menu.php
INFO - 2024-05-12 19:04:06 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\include/admin_loggedin_info.php
INFO - 2024-05-12 19:04:06 --> Model Class Initialized
INFO - 2024-05-12 19:04:06 --> Model Class Initialized
INFO - 2024-05-12 19:04:06 --> Model Class Initialized
INFO - 2024-05-12 19:04:07 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\include/admin_header.php
INFO - 2024-05-12 19:04:07 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\include/admin_footer.php
INFO - 2024-05-12 19:04:07 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\admin_html_template.php
INFO - 2024-05-12 19:04:07 --> Final output sent to browser
DEBUG - 2024-05-12 19:04:07 --> Total execution time: 1.5734
ERROR - 2024-05-12 19:04:08 --> $config['composer_autoload'] is set to TRUE but E:\xampp\htdocs\maurnaturo\application\vendor/autoload.php was not found.
INFO - 2024-05-12 19:04:08 --> Config Class Initialized
INFO - 2024-05-12 19:04:08 --> Hooks Class Initialized
DEBUG - 2024-05-12 19:04:08 --> UTF-8 Support Enabled
INFO - 2024-05-12 19:04:08 --> Utf8 Class Initialized
INFO - 2024-05-12 19:04:08 --> URI Class Initialized
INFO - 2024-05-12 19:04:08 --> Router Class Initialized
INFO - 2024-05-12 19:04:08 --> Output Class Initialized
INFO - 2024-05-12 19:04:08 --> Security Class Initialized
DEBUG - 2024-05-12 19:04:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-12 19:04:08 --> Input Class Initialized
INFO - 2024-05-12 19:04:08 --> Language Class Initialized
INFO - 2024-05-12 19:04:08 --> Loader Class Initialized
INFO - 2024-05-12 19:04:08 --> Helper loaded: url_helper
INFO - 2024-05-12 19:04:08 --> Helper loaded: file_helper
INFO - 2024-05-12 19:04:08 --> Helper loaded: html_helper
INFO - 2024-05-12 19:04:08 --> Helper loaded: text_helper
INFO - 2024-05-12 19:04:08 --> Helper loaded: form_helper
INFO - 2024-05-12 19:04:08 --> Helper loaded: lang_helper
INFO - 2024-05-12 19:04:08 --> Helper loaded: security_helper
INFO - 2024-05-12 19:04:08 --> Helper loaded: cookie_helper
INFO - 2024-05-12 19:04:08 --> Database Driver Class Initialized
INFO - 2024-05-12 19:04:08 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-12 19:04:08 --> Parser Class Initialized
INFO - 2024-05-12 19:04:08 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-05-12 19:04:08 --> Pagination Class Initialized
INFO - 2024-05-12 19:04:08 --> Form Validation Class Initialized
INFO - 2024-05-12 19:04:08 --> Controller Class Initialized
DEBUG - 2024-05-12 19:04:08 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-05-12 19:04:08 --> Session class already loaded. Second attempt ignored.
INFO - 2024-05-12 19:04:08 --> Model Class Initialized
INFO - 2024-05-12 19:04:08 --> Final output sent to browser
DEBUG - 2024-05-12 19:04:08 --> Total execution time: 0.1020
ERROR - 2024-05-12 19:04:10 --> $config['composer_autoload'] is set to TRUE but E:\xampp\htdocs\maurnaturo\application\vendor/autoload.php was not found.
INFO - 2024-05-12 19:04:10 --> Config Class Initialized
INFO - 2024-05-12 19:04:10 --> Hooks Class Initialized
DEBUG - 2024-05-12 19:04:10 --> UTF-8 Support Enabled
INFO - 2024-05-12 19:04:10 --> Utf8 Class Initialized
INFO - 2024-05-12 19:04:10 --> URI Class Initialized
INFO - 2024-05-12 19:04:10 --> Router Class Initialized
INFO - 2024-05-12 19:04:10 --> Output Class Initialized
INFO - 2024-05-12 19:04:10 --> Security Class Initialized
DEBUG - 2024-05-12 19:04:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-12 19:04:10 --> Input Class Initialized
INFO - 2024-05-12 19:04:10 --> Language Class Initialized
INFO - 2024-05-12 19:04:10 --> Loader Class Initialized
INFO - 2024-05-12 19:04:10 --> Helper loaded: url_helper
INFO - 2024-05-12 19:04:10 --> Helper loaded: file_helper
INFO - 2024-05-12 19:04:10 --> Helper loaded: html_helper
INFO - 2024-05-12 19:04:10 --> Helper loaded: text_helper
INFO - 2024-05-12 19:04:10 --> Helper loaded: form_helper
INFO - 2024-05-12 19:04:10 --> Helper loaded: lang_helper
INFO - 2024-05-12 19:04:10 --> Helper loaded: security_helper
INFO - 2024-05-12 19:04:10 --> Helper loaded: cookie_helper
INFO - 2024-05-12 19:04:10 --> Database Driver Class Initialized
INFO - 2024-05-12 19:04:10 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-12 19:04:10 --> Parser Class Initialized
INFO - 2024-05-12 19:04:10 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-05-12 19:04:10 --> Pagination Class Initialized
INFO - 2024-05-12 19:04:10 --> Form Validation Class Initialized
INFO - 2024-05-12 19:04:10 --> Controller Class Initialized
DEBUG - 2024-05-12 19:04:10 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-05-12 19:04:10 --> Session class already loaded. Second attempt ignored.
INFO - 2024-05-12 19:04:10 --> Model Class Initialized
DEBUG - 2024-05-12 19:04:10 --> Lexpenses class already loaded. Second attempt ignored.
INFO - 2024-05-12 19:04:10 --> Model Class Initialized
INFO - 2024-05-12 19:04:10 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\expenses/expenses.php
DEBUG - 2024-05-12 19:04:10 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-05-12 19:04:10 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\include/top_menu.php
INFO - 2024-05-12 19:04:10 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\include/admin_loggedin_info.php
INFO - 2024-05-12 19:04:10 --> Model Class Initialized
INFO - 2024-05-12 19:04:10 --> Model Class Initialized
INFO - 2024-05-12 19:04:10 --> Model Class Initialized
INFO - 2024-05-12 19:04:11 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\include/admin_header.php
INFO - 2024-05-12 19:04:11 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\include/admin_footer.php
INFO - 2024-05-12 19:04:11 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\admin_html_template.php
INFO - 2024-05-12 19:04:11 --> Final output sent to browser
DEBUG - 2024-05-12 19:04:11 --> Total execution time: 1.4570
ERROR - 2024-05-12 19:04:11 --> $config['composer_autoload'] is set to TRUE but E:\xampp\htdocs\maurnaturo\application\vendor/autoload.php was not found.
INFO - 2024-05-12 19:04:11 --> Config Class Initialized
INFO - 2024-05-12 19:04:11 --> Hooks Class Initialized
DEBUG - 2024-05-12 19:04:11 --> UTF-8 Support Enabled
INFO - 2024-05-12 19:04:11 --> Utf8 Class Initialized
INFO - 2024-05-12 19:04:11 --> URI Class Initialized
INFO - 2024-05-12 19:04:11 --> Router Class Initialized
INFO - 2024-05-12 19:04:11 --> Output Class Initialized
INFO - 2024-05-12 19:04:11 --> Security Class Initialized
DEBUG - 2024-05-12 19:04:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-12 19:04:11 --> Input Class Initialized
INFO - 2024-05-12 19:04:11 --> Language Class Initialized
INFO - 2024-05-12 19:04:11 --> Loader Class Initialized
INFO - 2024-05-12 19:04:11 --> Helper loaded: url_helper
INFO - 2024-05-12 19:04:11 --> Helper loaded: file_helper
INFO - 2024-05-12 19:04:11 --> Helper loaded: html_helper
INFO - 2024-05-12 19:04:11 --> Helper loaded: text_helper
INFO - 2024-05-12 19:04:11 --> Helper loaded: form_helper
INFO - 2024-05-12 19:04:11 --> Helper loaded: lang_helper
INFO - 2024-05-12 19:04:11 --> Helper loaded: security_helper
INFO - 2024-05-12 19:04:11 --> Helper loaded: cookie_helper
INFO - 2024-05-12 19:04:11 --> Database Driver Class Initialized
INFO - 2024-05-12 19:04:11 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-12 19:04:11 --> Parser Class Initialized
INFO - 2024-05-12 19:04:11 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-05-12 19:04:11 --> Pagination Class Initialized
INFO - 2024-05-12 19:04:11 --> Form Validation Class Initialized
INFO - 2024-05-12 19:04:11 --> Controller Class Initialized
DEBUG - 2024-05-12 19:04:11 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-05-12 19:04:11 --> Session class already loaded. Second attempt ignored.
INFO - 2024-05-12 19:04:11 --> Model Class Initialized
INFO - 2024-05-12 19:04:11 --> Final output sent to browser
DEBUG - 2024-05-12 19:04:11 --> Total execution time: 0.1064
ERROR - 2024-05-12 19:08:29 --> $config['composer_autoload'] is set to TRUE but E:\xampp\htdocs\maurnaturo\application\vendor/autoload.php was not found.
INFO - 2024-05-12 19:08:29 --> Config Class Initialized
INFO - 2024-05-12 19:08:29 --> Hooks Class Initialized
DEBUG - 2024-05-12 19:08:29 --> UTF-8 Support Enabled
INFO - 2024-05-12 19:08:29 --> Utf8 Class Initialized
INFO - 2024-05-12 19:08:29 --> URI Class Initialized
INFO - 2024-05-12 19:08:29 --> Router Class Initialized
INFO - 2024-05-12 19:08:29 --> Output Class Initialized
INFO - 2024-05-12 19:08:29 --> Security Class Initialized
DEBUG - 2024-05-12 19:08:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-12 19:08:29 --> Input Class Initialized
INFO - 2024-05-12 19:08:29 --> Language Class Initialized
INFO - 2024-05-12 19:08:29 --> Loader Class Initialized
INFO - 2024-05-12 19:08:29 --> Helper loaded: url_helper
INFO - 2024-05-12 19:08:29 --> Helper loaded: file_helper
INFO - 2024-05-12 19:08:29 --> Helper loaded: html_helper
INFO - 2024-05-12 19:08:29 --> Helper loaded: text_helper
INFO - 2024-05-12 19:08:29 --> Helper loaded: form_helper
INFO - 2024-05-12 19:08:29 --> Helper loaded: lang_helper
INFO - 2024-05-12 19:08:29 --> Helper loaded: security_helper
INFO - 2024-05-12 19:08:29 --> Helper loaded: cookie_helper
INFO - 2024-05-12 19:08:29 --> Database Driver Class Initialized
INFO - 2024-05-12 19:08:29 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-12 19:08:29 --> Parser Class Initialized
INFO - 2024-05-12 19:08:29 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-05-12 19:08:29 --> Pagination Class Initialized
INFO - 2024-05-12 19:08:29 --> Form Validation Class Initialized
INFO - 2024-05-12 19:08:29 --> Controller Class Initialized
DEBUG - 2024-05-12 19:08:29 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-05-12 19:08:29 --> Session class already loaded. Second attempt ignored.
INFO - 2024-05-12 19:08:29 --> Model Class Initialized
DEBUG - 2024-05-12 19:08:29 --> Lexpenses class already loaded. Second attempt ignored.
INFO - 2024-05-12 19:08:29 --> Model Class Initialized
INFO - 2024-05-12 19:08:29 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\expenses/expenses.php
DEBUG - 2024-05-12 19:08:29 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-05-12 19:08:29 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\include/top_menu.php
INFO - 2024-05-12 19:08:29 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\include/admin_loggedin_info.php
INFO - 2024-05-12 19:08:29 --> Model Class Initialized
INFO - 2024-05-12 19:08:29 --> Model Class Initialized
INFO - 2024-05-12 19:08:29 --> Model Class Initialized
INFO - 2024-05-12 19:08:31 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\include/admin_header.php
INFO - 2024-05-12 19:08:31 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\include/admin_footer.php
INFO - 2024-05-12 19:08:31 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\admin_html_template.php
INFO - 2024-05-12 19:08:31 --> Final output sent to browser
DEBUG - 2024-05-12 19:08:31 --> Total execution time: 1.6557
ERROR - 2024-05-12 19:08:31 --> $config['composer_autoload'] is set to TRUE but E:\xampp\htdocs\maurnaturo\application\vendor/autoload.php was not found.
INFO - 2024-05-12 19:08:31 --> Config Class Initialized
INFO - 2024-05-12 19:08:31 --> Hooks Class Initialized
DEBUG - 2024-05-12 19:08:31 --> UTF-8 Support Enabled
INFO - 2024-05-12 19:08:31 --> Utf8 Class Initialized
INFO - 2024-05-12 19:08:31 --> URI Class Initialized
INFO - 2024-05-12 19:08:31 --> Router Class Initialized
INFO - 2024-05-12 19:08:31 --> Output Class Initialized
INFO - 2024-05-12 19:08:31 --> Security Class Initialized
DEBUG - 2024-05-12 19:08:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-12 19:08:31 --> Input Class Initialized
INFO - 2024-05-12 19:08:31 --> Language Class Initialized
INFO - 2024-05-12 19:08:31 --> Loader Class Initialized
INFO - 2024-05-12 19:08:31 --> Helper loaded: url_helper
INFO - 2024-05-12 19:08:31 --> Helper loaded: file_helper
INFO - 2024-05-12 19:08:31 --> Helper loaded: html_helper
INFO - 2024-05-12 19:08:31 --> Helper loaded: text_helper
INFO - 2024-05-12 19:08:31 --> Helper loaded: form_helper
INFO - 2024-05-12 19:08:31 --> Helper loaded: lang_helper
INFO - 2024-05-12 19:08:31 --> Helper loaded: security_helper
INFO - 2024-05-12 19:08:31 --> Helper loaded: cookie_helper
INFO - 2024-05-12 19:08:31 --> Database Driver Class Initialized
INFO - 2024-05-12 19:08:31 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-12 19:08:31 --> Parser Class Initialized
INFO - 2024-05-12 19:08:31 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-05-12 19:08:31 --> Pagination Class Initialized
INFO - 2024-05-12 19:08:31 --> Form Validation Class Initialized
INFO - 2024-05-12 19:08:31 --> Controller Class Initialized
DEBUG - 2024-05-12 19:08:31 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-05-12 19:08:31 --> Session class already loaded. Second attempt ignored.
INFO - 2024-05-12 19:08:31 --> Model Class Initialized
INFO - 2024-05-12 19:08:31 --> Final output sent to browser
DEBUG - 2024-05-12 19:08:31 --> Total execution time: 0.0866
ERROR - 2024-05-12 19:08:39 --> $config['composer_autoload'] is set to TRUE but E:\xampp\htdocs\maurnaturo\application\vendor/autoload.php was not found.
INFO - 2024-05-12 19:08:39 --> Config Class Initialized
INFO - 2024-05-12 19:08:39 --> Hooks Class Initialized
DEBUG - 2024-05-12 19:08:39 --> UTF-8 Support Enabled
INFO - 2024-05-12 19:08:39 --> Utf8 Class Initialized
INFO - 2024-05-12 19:08:39 --> URI Class Initialized
INFO - 2024-05-12 19:08:39 --> Router Class Initialized
INFO - 2024-05-12 19:08:39 --> Output Class Initialized
INFO - 2024-05-12 19:08:39 --> Security Class Initialized
DEBUG - 2024-05-12 19:08:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-12 19:08:39 --> Input Class Initialized
INFO - 2024-05-12 19:08:39 --> Language Class Initialized
INFO - 2024-05-12 19:08:39 --> Loader Class Initialized
INFO - 2024-05-12 19:08:39 --> Helper loaded: url_helper
INFO - 2024-05-12 19:08:39 --> Helper loaded: file_helper
INFO - 2024-05-12 19:08:39 --> Helper loaded: html_helper
INFO - 2024-05-12 19:08:39 --> Helper loaded: text_helper
INFO - 2024-05-12 19:08:39 --> Helper loaded: form_helper
INFO - 2024-05-12 19:08:39 --> Helper loaded: lang_helper
INFO - 2024-05-12 19:08:39 --> Helper loaded: security_helper
INFO - 2024-05-12 19:08:39 --> Helper loaded: cookie_helper
INFO - 2024-05-12 19:08:39 --> Database Driver Class Initialized
INFO - 2024-05-12 19:08:39 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-12 19:08:39 --> Parser Class Initialized
INFO - 2024-05-12 19:08:39 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-05-12 19:08:39 --> Pagination Class Initialized
INFO - 2024-05-12 19:08:39 --> Form Validation Class Initialized
INFO - 2024-05-12 19:08:39 --> Controller Class Initialized
DEBUG - 2024-05-12 19:08:39 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-05-12 19:08:39 --> Session class already loaded. Second attempt ignored.
INFO - 2024-05-12 19:08:39 --> Model Class Initialized
ERROR - 2024-05-12 19:08:39 --> $config['composer_autoload'] is set to TRUE but E:\xampp\htdocs\maurnaturo\application\vendor/autoload.php was not found.
INFO - 2024-05-12 19:08:39 --> Config Class Initialized
INFO - 2024-05-12 19:08:39 --> Hooks Class Initialized
DEBUG - 2024-05-12 19:08:39 --> UTF-8 Support Enabled
INFO - 2024-05-12 19:08:39 --> Utf8 Class Initialized
INFO - 2024-05-12 19:08:39 --> URI Class Initialized
INFO - 2024-05-12 19:08:39 --> Router Class Initialized
INFO - 2024-05-12 19:08:39 --> Output Class Initialized
INFO - 2024-05-12 19:08:39 --> Security Class Initialized
DEBUG - 2024-05-12 19:08:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-12 19:08:39 --> Input Class Initialized
INFO - 2024-05-12 19:08:39 --> Language Class Initialized
INFO - 2024-05-12 19:08:39 --> Loader Class Initialized
INFO - 2024-05-12 19:08:39 --> Helper loaded: url_helper
INFO - 2024-05-12 19:08:39 --> Helper loaded: file_helper
INFO - 2024-05-12 19:08:39 --> Helper loaded: html_helper
INFO - 2024-05-12 19:08:39 --> Helper loaded: text_helper
INFO - 2024-05-12 19:08:39 --> Helper loaded: form_helper
INFO - 2024-05-12 19:08:39 --> Helper loaded: lang_helper
INFO - 2024-05-12 19:08:39 --> Helper loaded: security_helper
INFO - 2024-05-12 19:08:39 --> Helper loaded: cookie_helper
INFO - 2024-05-12 19:08:39 --> Database Driver Class Initialized
INFO - 2024-05-12 19:08:39 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-12 19:08:39 --> Parser Class Initialized
INFO - 2024-05-12 19:08:39 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-05-12 19:08:39 --> Pagination Class Initialized
INFO - 2024-05-12 19:08:39 --> Form Validation Class Initialized
INFO - 2024-05-12 19:08:39 --> Controller Class Initialized
DEBUG - 2024-05-12 19:08:39 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-05-12 19:08:39 --> Session class already loaded. Second attempt ignored.
INFO - 2024-05-12 19:08:39 --> Model Class Initialized
DEBUG - 2024-05-12 19:08:39 --> Lexpenses class already loaded. Second attempt ignored.
INFO - 2024-05-12 19:08:39 --> Model Class Initialized
INFO - 2024-05-12 19:08:39 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\expenses/expenses.php
DEBUG - 2024-05-12 19:08:39 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-05-12 19:08:39 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\include/top_menu.php
INFO - 2024-05-12 19:08:39 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\include/admin_loggedin_info.php
INFO - 2024-05-12 19:08:39 --> Model Class Initialized
INFO - 2024-05-12 19:08:39 --> Model Class Initialized
INFO - 2024-05-12 19:08:39 --> Model Class Initialized
INFO - 2024-05-12 19:08:40 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\include/admin_header.php
INFO - 2024-05-12 19:08:40 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\include/admin_footer.php
INFO - 2024-05-12 19:08:40 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\admin_html_template.php
INFO - 2024-05-12 19:08:40 --> Final output sent to browser
DEBUG - 2024-05-12 19:08:40 --> Total execution time: 1.6762
ERROR - 2024-05-12 19:08:41 --> $config['composer_autoload'] is set to TRUE but E:\xampp\htdocs\maurnaturo\application\vendor/autoload.php was not found.
INFO - 2024-05-12 19:08:41 --> Config Class Initialized
INFO - 2024-05-12 19:08:41 --> Hooks Class Initialized
DEBUG - 2024-05-12 19:08:41 --> UTF-8 Support Enabled
INFO - 2024-05-12 19:08:41 --> Utf8 Class Initialized
INFO - 2024-05-12 19:08:41 --> URI Class Initialized
INFO - 2024-05-12 19:08:41 --> Router Class Initialized
INFO - 2024-05-12 19:08:41 --> Output Class Initialized
INFO - 2024-05-12 19:08:41 --> Security Class Initialized
DEBUG - 2024-05-12 19:08:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-12 19:08:41 --> Input Class Initialized
INFO - 2024-05-12 19:08:41 --> Language Class Initialized
INFO - 2024-05-12 19:08:41 --> Loader Class Initialized
INFO - 2024-05-12 19:08:41 --> Helper loaded: url_helper
INFO - 2024-05-12 19:08:41 --> Helper loaded: file_helper
INFO - 2024-05-12 19:08:41 --> Helper loaded: html_helper
INFO - 2024-05-12 19:08:41 --> Helper loaded: text_helper
INFO - 2024-05-12 19:08:41 --> Helper loaded: form_helper
INFO - 2024-05-12 19:08:41 --> Helper loaded: lang_helper
INFO - 2024-05-12 19:08:41 --> Helper loaded: security_helper
INFO - 2024-05-12 19:08:41 --> Helper loaded: cookie_helper
INFO - 2024-05-12 19:08:41 --> Database Driver Class Initialized
INFO - 2024-05-12 19:08:41 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-12 19:08:41 --> Parser Class Initialized
INFO - 2024-05-12 19:08:41 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-05-12 19:08:41 --> Pagination Class Initialized
INFO - 2024-05-12 19:08:41 --> Form Validation Class Initialized
INFO - 2024-05-12 19:08:41 --> Controller Class Initialized
DEBUG - 2024-05-12 19:08:41 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-05-12 19:08:41 --> Session class already loaded. Second attempt ignored.
INFO - 2024-05-12 19:08:41 --> Model Class Initialized
INFO - 2024-05-12 19:08:41 --> Final output sent to browser
DEBUG - 2024-05-12 19:08:41 --> Total execution time: 0.1216
ERROR - 2024-05-12 19:10:42 --> $config['composer_autoload'] is set to TRUE but E:\xampp\htdocs\maurnaturo\application\vendor/autoload.php was not found.
INFO - 2024-05-12 19:10:42 --> Config Class Initialized
INFO - 2024-05-12 19:10:42 --> Hooks Class Initialized
DEBUG - 2024-05-12 19:10:42 --> UTF-8 Support Enabled
INFO - 2024-05-12 19:10:42 --> Utf8 Class Initialized
INFO - 2024-05-12 19:10:42 --> URI Class Initialized
INFO - 2024-05-12 19:10:42 --> Router Class Initialized
INFO - 2024-05-12 19:10:42 --> Output Class Initialized
INFO - 2024-05-12 19:10:42 --> Security Class Initialized
DEBUG - 2024-05-12 19:10:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-12 19:10:42 --> Input Class Initialized
INFO - 2024-05-12 19:10:42 --> Language Class Initialized
INFO - 2024-05-12 19:10:42 --> Loader Class Initialized
INFO - 2024-05-12 19:10:42 --> Helper loaded: url_helper
INFO - 2024-05-12 19:10:42 --> Helper loaded: file_helper
INFO - 2024-05-12 19:10:42 --> Helper loaded: html_helper
INFO - 2024-05-12 19:10:42 --> Helper loaded: text_helper
INFO - 2024-05-12 19:10:42 --> Helper loaded: form_helper
INFO - 2024-05-12 19:10:42 --> Helper loaded: lang_helper
INFO - 2024-05-12 19:10:42 --> Helper loaded: security_helper
INFO - 2024-05-12 19:10:42 --> Helper loaded: cookie_helper
INFO - 2024-05-12 19:10:42 --> Database Driver Class Initialized
INFO - 2024-05-12 19:10:42 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-12 19:10:42 --> Parser Class Initialized
INFO - 2024-05-12 19:10:42 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-05-12 19:10:42 --> Pagination Class Initialized
INFO - 2024-05-12 19:10:42 --> Form Validation Class Initialized
INFO - 2024-05-12 19:10:42 --> Controller Class Initialized
DEBUG - 2024-05-12 19:10:42 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-05-12 19:10:42 --> Session class already loaded. Second attempt ignored.
INFO - 2024-05-12 19:10:42 --> Model Class Initialized
DEBUG - 2024-05-12 19:10:42 --> Lexpenses class already loaded. Second attempt ignored.
INFO - 2024-05-12 19:10:42 --> Model Class Initialized
INFO - 2024-05-12 19:10:42 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\expenses/expenses.php
DEBUG - 2024-05-12 19:10:42 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-05-12 19:10:42 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\include/top_menu.php
INFO - 2024-05-12 19:10:42 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\include/admin_loggedin_info.php
INFO - 2024-05-12 19:10:42 --> Model Class Initialized
INFO - 2024-05-12 19:10:42 --> Model Class Initialized
INFO - 2024-05-12 19:10:42 --> Model Class Initialized
INFO - 2024-05-12 19:10:44 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\include/admin_header.php
INFO - 2024-05-12 19:10:44 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\include/admin_footer.php
INFO - 2024-05-12 19:10:44 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\admin_html_template.php
INFO - 2024-05-12 19:10:44 --> Final output sent to browser
DEBUG - 2024-05-12 19:10:44 --> Total execution time: 1.6615
ERROR - 2024-05-12 19:10:44 --> $config['composer_autoload'] is set to TRUE but E:\xampp\htdocs\maurnaturo\application\vendor/autoload.php was not found.
INFO - 2024-05-12 19:10:44 --> Config Class Initialized
INFO - 2024-05-12 19:10:44 --> Hooks Class Initialized
DEBUG - 2024-05-12 19:10:44 --> UTF-8 Support Enabled
INFO - 2024-05-12 19:10:44 --> Utf8 Class Initialized
INFO - 2024-05-12 19:10:44 --> URI Class Initialized
INFO - 2024-05-12 19:10:44 --> Router Class Initialized
INFO - 2024-05-12 19:10:44 --> Output Class Initialized
INFO - 2024-05-12 19:10:44 --> Security Class Initialized
DEBUG - 2024-05-12 19:10:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-12 19:10:44 --> Input Class Initialized
INFO - 2024-05-12 19:10:44 --> Language Class Initialized
INFO - 2024-05-12 19:10:44 --> Loader Class Initialized
INFO - 2024-05-12 19:10:44 --> Helper loaded: url_helper
INFO - 2024-05-12 19:10:44 --> Helper loaded: file_helper
INFO - 2024-05-12 19:10:44 --> Helper loaded: html_helper
INFO - 2024-05-12 19:10:44 --> Helper loaded: text_helper
INFO - 2024-05-12 19:10:44 --> Helper loaded: form_helper
INFO - 2024-05-12 19:10:44 --> Helper loaded: lang_helper
INFO - 2024-05-12 19:10:44 --> Helper loaded: security_helper
INFO - 2024-05-12 19:10:44 --> Helper loaded: cookie_helper
INFO - 2024-05-12 19:10:44 --> Database Driver Class Initialized
INFO - 2024-05-12 19:10:44 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-12 19:10:44 --> Parser Class Initialized
INFO - 2024-05-12 19:10:44 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-05-12 19:10:44 --> Pagination Class Initialized
INFO - 2024-05-12 19:10:44 --> Form Validation Class Initialized
INFO - 2024-05-12 19:10:44 --> Controller Class Initialized
DEBUG - 2024-05-12 19:10:44 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-05-12 19:10:44 --> Session class already loaded. Second attempt ignored.
INFO - 2024-05-12 19:10:44 --> Model Class Initialized
INFO - 2024-05-12 19:10:44 --> Final output sent to browser
DEBUG - 2024-05-12 19:10:44 --> Total execution time: 0.1583
ERROR - 2024-05-12 19:10:52 --> $config['composer_autoload'] is set to TRUE but E:\xampp\htdocs\maurnaturo\application\vendor/autoload.php was not found.
INFO - 2024-05-12 19:10:52 --> Config Class Initialized
INFO - 2024-05-12 19:10:52 --> Hooks Class Initialized
DEBUG - 2024-05-12 19:10:52 --> UTF-8 Support Enabled
INFO - 2024-05-12 19:10:52 --> Utf8 Class Initialized
INFO - 2024-05-12 19:10:52 --> URI Class Initialized
INFO - 2024-05-12 19:10:52 --> Router Class Initialized
INFO - 2024-05-12 19:10:52 --> Output Class Initialized
INFO - 2024-05-12 19:10:52 --> Security Class Initialized
DEBUG - 2024-05-12 19:10:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-12 19:10:52 --> Input Class Initialized
INFO - 2024-05-12 19:10:52 --> Language Class Initialized
INFO - 2024-05-12 19:10:52 --> Loader Class Initialized
INFO - 2024-05-12 19:10:52 --> Helper loaded: url_helper
INFO - 2024-05-12 19:10:52 --> Helper loaded: file_helper
INFO - 2024-05-12 19:10:52 --> Helper loaded: html_helper
INFO - 2024-05-12 19:10:52 --> Helper loaded: text_helper
INFO - 2024-05-12 19:10:52 --> Helper loaded: form_helper
INFO - 2024-05-12 19:10:52 --> Helper loaded: lang_helper
INFO - 2024-05-12 19:10:52 --> Helper loaded: security_helper
INFO - 2024-05-12 19:10:52 --> Helper loaded: cookie_helper
INFO - 2024-05-12 19:10:52 --> Database Driver Class Initialized
INFO - 2024-05-12 19:10:52 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-12 19:10:52 --> Parser Class Initialized
INFO - 2024-05-12 19:10:52 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-05-12 19:10:52 --> Pagination Class Initialized
INFO - 2024-05-12 19:10:52 --> Form Validation Class Initialized
INFO - 2024-05-12 19:10:52 --> Controller Class Initialized
DEBUG - 2024-05-12 19:10:52 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-05-12 19:10:52 --> Session class already loaded. Second attempt ignored.
INFO - 2024-05-12 19:10:52 --> Model Class Initialized
ERROR - 2024-05-12 19:10:52 --> $config['composer_autoload'] is set to TRUE but E:\xampp\htdocs\maurnaturo\application\vendor/autoload.php was not found.
INFO - 2024-05-12 19:10:52 --> Config Class Initialized
INFO - 2024-05-12 19:10:52 --> Hooks Class Initialized
DEBUG - 2024-05-12 19:10:52 --> UTF-8 Support Enabled
INFO - 2024-05-12 19:10:52 --> Utf8 Class Initialized
INFO - 2024-05-12 19:10:52 --> URI Class Initialized
INFO - 2024-05-12 19:10:52 --> Router Class Initialized
INFO - 2024-05-12 19:10:52 --> Output Class Initialized
INFO - 2024-05-12 19:10:52 --> Security Class Initialized
DEBUG - 2024-05-12 19:10:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-12 19:10:52 --> Input Class Initialized
INFO - 2024-05-12 19:10:52 --> Language Class Initialized
INFO - 2024-05-12 19:10:52 --> Loader Class Initialized
INFO - 2024-05-12 19:10:52 --> Helper loaded: url_helper
INFO - 2024-05-12 19:10:52 --> Helper loaded: file_helper
INFO - 2024-05-12 19:10:52 --> Helper loaded: html_helper
INFO - 2024-05-12 19:10:52 --> Helper loaded: text_helper
INFO - 2024-05-12 19:10:52 --> Helper loaded: form_helper
INFO - 2024-05-12 19:10:52 --> Helper loaded: lang_helper
INFO - 2024-05-12 19:10:52 --> Helper loaded: security_helper
INFO - 2024-05-12 19:10:52 --> Helper loaded: cookie_helper
INFO - 2024-05-12 19:10:52 --> Database Driver Class Initialized
INFO - 2024-05-12 19:10:52 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-12 19:10:52 --> Parser Class Initialized
INFO - 2024-05-12 19:10:52 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-05-12 19:10:52 --> Pagination Class Initialized
INFO - 2024-05-12 19:10:52 --> Form Validation Class Initialized
INFO - 2024-05-12 19:10:52 --> Controller Class Initialized
DEBUG - 2024-05-12 19:10:52 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-05-12 19:10:52 --> Session class already loaded. Second attempt ignored.
INFO - 2024-05-12 19:10:52 --> Model Class Initialized
DEBUG - 2024-05-12 19:10:52 --> Lexpenses class already loaded. Second attempt ignored.
INFO - 2024-05-12 19:10:52 --> Model Class Initialized
INFO - 2024-05-12 19:10:53 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\expenses/expenses.php
DEBUG - 2024-05-12 19:10:53 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-05-12 19:10:53 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\include/top_menu.php
INFO - 2024-05-12 19:10:53 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\include/admin_loggedin_info.php
INFO - 2024-05-12 19:10:53 --> Model Class Initialized
INFO - 2024-05-12 19:10:53 --> Model Class Initialized
INFO - 2024-05-12 19:10:53 --> Model Class Initialized
INFO - 2024-05-12 19:10:54 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\include/admin_header.php
INFO - 2024-05-12 19:10:54 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\include/admin_footer.php
INFO - 2024-05-12 19:10:54 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\admin_html_template.php
INFO - 2024-05-12 19:10:54 --> Final output sent to browser
DEBUG - 2024-05-12 19:10:54 --> Total execution time: 1.6481
ERROR - 2024-05-12 19:10:54 --> $config['composer_autoload'] is set to TRUE but E:\xampp\htdocs\maurnaturo\application\vendor/autoload.php was not found.
INFO - 2024-05-12 19:10:54 --> Config Class Initialized
INFO - 2024-05-12 19:10:54 --> Hooks Class Initialized
DEBUG - 2024-05-12 19:10:54 --> UTF-8 Support Enabled
INFO - 2024-05-12 19:10:54 --> Utf8 Class Initialized
INFO - 2024-05-12 19:10:54 --> URI Class Initialized
INFO - 2024-05-12 19:10:54 --> Router Class Initialized
INFO - 2024-05-12 19:10:54 --> Output Class Initialized
INFO - 2024-05-12 19:10:54 --> Security Class Initialized
DEBUG - 2024-05-12 19:10:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-12 19:10:54 --> Input Class Initialized
INFO - 2024-05-12 19:10:54 --> Language Class Initialized
INFO - 2024-05-12 19:10:54 --> Loader Class Initialized
INFO - 2024-05-12 19:10:54 --> Helper loaded: url_helper
INFO - 2024-05-12 19:10:54 --> Helper loaded: file_helper
INFO - 2024-05-12 19:10:54 --> Helper loaded: html_helper
INFO - 2024-05-12 19:10:54 --> Helper loaded: text_helper
INFO - 2024-05-12 19:10:54 --> Helper loaded: form_helper
INFO - 2024-05-12 19:10:54 --> Helper loaded: lang_helper
INFO - 2024-05-12 19:10:54 --> Helper loaded: security_helper
INFO - 2024-05-12 19:10:54 --> Helper loaded: cookie_helper
INFO - 2024-05-12 19:10:54 --> Database Driver Class Initialized
INFO - 2024-05-12 19:10:54 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-12 19:10:54 --> Parser Class Initialized
INFO - 2024-05-12 19:10:54 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-05-12 19:10:54 --> Pagination Class Initialized
INFO - 2024-05-12 19:10:54 --> Form Validation Class Initialized
INFO - 2024-05-12 19:10:54 --> Controller Class Initialized
DEBUG - 2024-05-12 19:10:54 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-05-12 19:10:54 --> Session class already loaded. Second attempt ignored.
INFO - 2024-05-12 19:10:54 --> Model Class Initialized
INFO - 2024-05-12 19:10:54 --> Final output sent to browser
DEBUG - 2024-05-12 19:10:54 --> Total execution time: 0.1163
ERROR - 2024-05-12 19:11:24 --> $config['composer_autoload'] is set to TRUE but E:\xampp\htdocs\maurnaturo\application\vendor/autoload.php was not found.
INFO - 2024-05-12 19:11:24 --> Config Class Initialized
INFO - 2024-05-12 19:11:24 --> Hooks Class Initialized
DEBUG - 2024-05-12 19:11:24 --> UTF-8 Support Enabled
INFO - 2024-05-12 19:11:24 --> Utf8 Class Initialized
INFO - 2024-05-12 19:11:24 --> URI Class Initialized
INFO - 2024-05-12 19:11:24 --> Router Class Initialized
INFO - 2024-05-12 19:11:24 --> Output Class Initialized
INFO - 2024-05-12 19:11:24 --> Security Class Initialized
DEBUG - 2024-05-12 19:11:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-12 19:11:24 --> Input Class Initialized
INFO - 2024-05-12 19:11:24 --> Language Class Initialized
INFO - 2024-05-12 19:11:24 --> Loader Class Initialized
INFO - 2024-05-12 19:11:24 --> Helper loaded: url_helper
INFO - 2024-05-12 19:11:24 --> Helper loaded: file_helper
INFO - 2024-05-12 19:11:24 --> Helper loaded: html_helper
INFO - 2024-05-12 19:11:24 --> Helper loaded: text_helper
INFO - 2024-05-12 19:11:24 --> Helper loaded: form_helper
INFO - 2024-05-12 19:11:24 --> Helper loaded: lang_helper
INFO - 2024-05-12 19:11:24 --> Helper loaded: security_helper
INFO - 2024-05-12 19:11:24 --> Helper loaded: cookie_helper
INFO - 2024-05-12 19:11:24 --> Database Driver Class Initialized
INFO - 2024-05-12 19:11:24 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-12 19:11:24 --> Parser Class Initialized
INFO - 2024-05-12 19:11:24 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-05-12 19:11:24 --> Pagination Class Initialized
INFO - 2024-05-12 19:11:24 --> Form Validation Class Initialized
INFO - 2024-05-12 19:11:24 --> Controller Class Initialized
DEBUG - 2024-05-12 19:11:24 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-05-12 19:11:24 --> Session class already loaded. Second attempt ignored.
INFO - 2024-05-12 19:11:24 --> Model Class Initialized
DEBUG - 2024-05-12 19:11:24 --> Lexpenses class already loaded. Second attempt ignored.
INFO - 2024-05-12 19:11:24 --> Model Class Initialized
INFO - 2024-05-12 19:11:24 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\expenses/expenses.php
DEBUG - 2024-05-12 19:11:24 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-05-12 19:11:24 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\include/top_menu.php
INFO - 2024-05-12 19:11:24 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\include/admin_loggedin_info.php
INFO - 2024-05-12 19:11:24 --> Model Class Initialized
INFO - 2024-05-12 19:11:24 --> Model Class Initialized
INFO - 2024-05-12 19:11:24 --> Model Class Initialized
INFO - 2024-05-12 19:11:25 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\include/admin_header.php
INFO - 2024-05-12 19:11:25 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\include/admin_footer.php
INFO - 2024-05-12 19:11:25 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\admin_html_template.php
INFO - 2024-05-12 19:11:25 --> Final output sent to browser
DEBUG - 2024-05-12 19:11:25 --> Total execution time: 1.4908
ERROR - 2024-05-12 19:11:26 --> $config['composer_autoload'] is set to TRUE but E:\xampp\htdocs\maurnaturo\application\vendor/autoload.php was not found.
INFO - 2024-05-12 19:11:26 --> Config Class Initialized
INFO - 2024-05-12 19:11:26 --> Hooks Class Initialized
DEBUG - 2024-05-12 19:11:26 --> UTF-8 Support Enabled
INFO - 2024-05-12 19:11:26 --> Utf8 Class Initialized
INFO - 2024-05-12 19:11:26 --> URI Class Initialized
INFO - 2024-05-12 19:11:26 --> Router Class Initialized
INFO - 2024-05-12 19:11:26 --> Output Class Initialized
INFO - 2024-05-12 19:11:26 --> Security Class Initialized
DEBUG - 2024-05-12 19:11:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-12 19:11:26 --> Input Class Initialized
INFO - 2024-05-12 19:11:26 --> Language Class Initialized
INFO - 2024-05-12 19:11:26 --> Loader Class Initialized
INFO - 2024-05-12 19:11:26 --> Helper loaded: url_helper
INFO - 2024-05-12 19:11:26 --> Helper loaded: file_helper
INFO - 2024-05-12 19:11:26 --> Helper loaded: html_helper
INFO - 2024-05-12 19:11:26 --> Helper loaded: text_helper
INFO - 2024-05-12 19:11:26 --> Helper loaded: form_helper
INFO - 2024-05-12 19:11:26 --> Helper loaded: lang_helper
INFO - 2024-05-12 19:11:26 --> Helper loaded: security_helper
INFO - 2024-05-12 19:11:26 --> Helper loaded: cookie_helper
INFO - 2024-05-12 19:11:26 --> Database Driver Class Initialized
INFO - 2024-05-12 19:11:26 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-12 19:11:26 --> Parser Class Initialized
INFO - 2024-05-12 19:11:26 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-05-12 19:11:26 --> Pagination Class Initialized
INFO - 2024-05-12 19:11:26 --> Form Validation Class Initialized
INFO - 2024-05-12 19:11:26 --> Controller Class Initialized
DEBUG - 2024-05-12 19:11:26 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-05-12 19:11:26 --> Session class already loaded. Second attempt ignored.
INFO - 2024-05-12 19:11:26 --> Model Class Initialized
INFO - 2024-05-12 19:11:26 --> Final output sent to browser
DEBUG - 2024-05-12 19:11:26 --> Total execution time: 0.0914
ERROR - 2024-05-12 19:11:50 --> $config['composer_autoload'] is set to TRUE but E:\xampp\htdocs\maurnaturo\application\vendor/autoload.php was not found.
INFO - 2024-05-12 19:11:50 --> Config Class Initialized
INFO - 2024-05-12 19:11:50 --> Hooks Class Initialized
DEBUG - 2024-05-12 19:11:50 --> UTF-8 Support Enabled
INFO - 2024-05-12 19:11:50 --> Utf8 Class Initialized
INFO - 2024-05-12 19:11:50 --> URI Class Initialized
INFO - 2024-05-12 19:11:50 --> Router Class Initialized
INFO - 2024-05-12 19:11:50 --> Output Class Initialized
INFO - 2024-05-12 19:11:50 --> Security Class Initialized
DEBUG - 2024-05-12 19:11:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-12 19:11:50 --> Input Class Initialized
INFO - 2024-05-12 19:11:50 --> Language Class Initialized
INFO - 2024-05-12 19:11:50 --> Loader Class Initialized
INFO - 2024-05-12 19:11:50 --> Helper loaded: url_helper
INFO - 2024-05-12 19:11:50 --> Helper loaded: file_helper
INFO - 2024-05-12 19:11:50 --> Helper loaded: html_helper
INFO - 2024-05-12 19:11:50 --> Helper loaded: text_helper
INFO - 2024-05-12 19:11:50 --> Helper loaded: form_helper
INFO - 2024-05-12 19:11:50 --> Helper loaded: lang_helper
INFO - 2024-05-12 19:11:50 --> Helper loaded: security_helper
INFO - 2024-05-12 19:11:50 --> Helper loaded: cookie_helper
INFO - 2024-05-12 19:11:50 --> Database Driver Class Initialized
INFO - 2024-05-12 19:11:50 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-12 19:11:50 --> Parser Class Initialized
INFO - 2024-05-12 19:11:50 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-05-12 19:11:50 --> Pagination Class Initialized
INFO - 2024-05-12 19:11:50 --> Form Validation Class Initialized
INFO - 2024-05-12 19:11:50 --> Controller Class Initialized
DEBUG - 2024-05-12 19:11:50 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-05-12 19:11:50 --> Session class already loaded. Second attempt ignored.
INFO - 2024-05-12 19:11:50 --> Model Class Initialized
DEBUG - 2024-05-12 19:11:50 --> Lexpenses class already loaded. Second attempt ignored.
INFO - 2024-05-12 19:11:50 --> Model Class Initialized
INFO - 2024-05-12 19:11:50 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\expenses/expenses.php
DEBUG - 2024-05-12 19:11:50 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-05-12 19:11:50 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\include/top_menu.php
INFO - 2024-05-12 19:11:50 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\include/admin_loggedin_info.php
INFO - 2024-05-12 19:11:50 --> Model Class Initialized
INFO - 2024-05-12 19:11:50 --> Model Class Initialized
INFO - 2024-05-12 19:11:50 --> Model Class Initialized
INFO - 2024-05-12 19:11:52 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\include/admin_header.php
INFO - 2024-05-12 19:11:52 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\include/admin_footer.php
INFO - 2024-05-12 19:11:52 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\admin_html_template.php
INFO - 2024-05-12 19:11:52 --> Final output sent to browser
DEBUG - 2024-05-12 19:11:52 --> Total execution time: 1.6722
ERROR - 2024-05-12 19:11:53 --> $config['composer_autoload'] is set to TRUE but E:\xampp\htdocs\maurnaturo\application\vendor/autoload.php was not found.
INFO - 2024-05-12 19:11:53 --> Config Class Initialized
INFO - 2024-05-12 19:11:53 --> Hooks Class Initialized
DEBUG - 2024-05-12 19:11:53 --> UTF-8 Support Enabled
INFO - 2024-05-12 19:11:53 --> Utf8 Class Initialized
INFO - 2024-05-12 19:11:53 --> URI Class Initialized
INFO - 2024-05-12 19:11:53 --> Router Class Initialized
INFO - 2024-05-12 19:11:53 --> Output Class Initialized
INFO - 2024-05-12 19:11:53 --> Security Class Initialized
DEBUG - 2024-05-12 19:11:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-12 19:11:53 --> Input Class Initialized
INFO - 2024-05-12 19:11:53 --> Language Class Initialized
INFO - 2024-05-12 19:11:53 --> Loader Class Initialized
INFO - 2024-05-12 19:11:53 --> Helper loaded: url_helper
INFO - 2024-05-12 19:11:53 --> Helper loaded: file_helper
INFO - 2024-05-12 19:11:53 --> Helper loaded: html_helper
INFO - 2024-05-12 19:11:53 --> Helper loaded: text_helper
INFO - 2024-05-12 19:11:53 --> Helper loaded: form_helper
INFO - 2024-05-12 19:11:53 --> Helper loaded: lang_helper
INFO - 2024-05-12 19:11:53 --> Helper loaded: security_helper
INFO - 2024-05-12 19:11:53 --> Helper loaded: cookie_helper
INFO - 2024-05-12 19:11:53 --> Database Driver Class Initialized
INFO - 2024-05-12 19:11:53 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-12 19:11:53 --> Parser Class Initialized
INFO - 2024-05-12 19:11:53 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-05-12 19:11:53 --> Pagination Class Initialized
INFO - 2024-05-12 19:11:53 --> Form Validation Class Initialized
INFO - 2024-05-12 19:11:53 --> Controller Class Initialized
DEBUG - 2024-05-12 19:11:53 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-05-12 19:11:53 --> Session class already loaded. Second attempt ignored.
INFO - 2024-05-12 19:11:53 --> Model Class Initialized
INFO - 2024-05-12 19:11:53 --> Final output sent to browser
DEBUG - 2024-05-12 19:11:53 --> Total execution time: 0.2821
ERROR - 2024-05-12 19:12:14 --> $config['composer_autoload'] is set to TRUE but E:\xampp\htdocs\maurnaturo\application\vendor/autoload.php was not found.
INFO - 2024-05-12 19:12:14 --> Config Class Initialized
INFO - 2024-05-12 19:12:14 --> Hooks Class Initialized
DEBUG - 2024-05-12 19:12:14 --> UTF-8 Support Enabled
INFO - 2024-05-12 19:12:14 --> Utf8 Class Initialized
INFO - 2024-05-12 19:12:14 --> URI Class Initialized
INFO - 2024-05-12 19:12:14 --> Router Class Initialized
INFO - 2024-05-12 19:12:14 --> Output Class Initialized
INFO - 2024-05-12 19:12:14 --> Security Class Initialized
DEBUG - 2024-05-12 19:12:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-12 19:12:14 --> Input Class Initialized
INFO - 2024-05-12 19:12:14 --> Language Class Initialized
INFO - 2024-05-12 19:12:14 --> Loader Class Initialized
INFO - 2024-05-12 19:12:14 --> Helper loaded: url_helper
INFO - 2024-05-12 19:12:14 --> Helper loaded: file_helper
INFO - 2024-05-12 19:12:14 --> Helper loaded: html_helper
INFO - 2024-05-12 19:12:14 --> Helper loaded: text_helper
INFO - 2024-05-12 19:12:14 --> Helper loaded: form_helper
INFO - 2024-05-12 19:12:14 --> Helper loaded: lang_helper
INFO - 2024-05-12 19:12:14 --> Helper loaded: security_helper
INFO - 2024-05-12 19:12:14 --> Helper loaded: cookie_helper
INFO - 2024-05-12 19:12:14 --> Database Driver Class Initialized
INFO - 2024-05-12 19:12:14 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-12 19:12:14 --> Parser Class Initialized
INFO - 2024-05-12 19:12:14 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-05-12 19:12:14 --> Pagination Class Initialized
INFO - 2024-05-12 19:12:14 --> Form Validation Class Initialized
INFO - 2024-05-12 19:12:14 --> Controller Class Initialized
DEBUG - 2024-05-12 19:12:14 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-05-12 19:12:14 --> Session class already loaded. Second attempt ignored.
INFO - 2024-05-12 19:12:14 --> Model Class Initialized
DEBUG - 2024-05-12 19:12:14 --> Lexpenses class already loaded. Second attempt ignored.
INFO - 2024-05-12 19:12:14 --> Model Class Initialized
INFO - 2024-05-12 19:12:14 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\expenses/expenses.php
DEBUG - 2024-05-12 19:12:14 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-05-12 19:12:14 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\include/top_menu.php
INFO - 2024-05-12 19:12:15 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\include/admin_loggedin_info.php
INFO - 2024-05-12 19:12:15 --> Model Class Initialized
INFO - 2024-05-12 19:12:15 --> Model Class Initialized
INFO - 2024-05-12 19:12:15 --> Model Class Initialized
INFO - 2024-05-12 19:12:16 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\include/admin_header.php
INFO - 2024-05-12 19:12:16 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\include/admin_footer.php
INFO - 2024-05-12 19:12:16 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\admin_html_template.php
INFO - 2024-05-12 19:12:16 --> Final output sent to browser
DEBUG - 2024-05-12 19:12:16 --> Total execution time: 1.5758
ERROR - 2024-05-12 19:12:17 --> $config['composer_autoload'] is set to TRUE but E:\xampp\htdocs\maurnaturo\application\vendor/autoload.php was not found.
INFO - 2024-05-12 19:12:17 --> Config Class Initialized
INFO - 2024-05-12 19:12:17 --> Hooks Class Initialized
DEBUG - 2024-05-12 19:12:17 --> UTF-8 Support Enabled
INFO - 2024-05-12 19:12:17 --> Utf8 Class Initialized
INFO - 2024-05-12 19:12:17 --> URI Class Initialized
INFO - 2024-05-12 19:12:17 --> Router Class Initialized
INFO - 2024-05-12 19:12:17 --> Output Class Initialized
INFO - 2024-05-12 19:12:17 --> Security Class Initialized
DEBUG - 2024-05-12 19:12:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-12 19:12:17 --> Input Class Initialized
INFO - 2024-05-12 19:12:17 --> Language Class Initialized
INFO - 2024-05-12 19:12:17 --> Loader Class Initialized
INFO - 2024-05-12 19:12:17 --> Helper loaded: url_helper
INFO - 2024-05-12 19:12:17 --> Helper loaded: file_helper
INFO - 2024-05-12 19:12:17 --> Helper loaded: html_helper
INFO - 2024-05-12 19:12:17 --> Helper loaded: text_helper
INFO - 2024-05-12 19:12:17 --> Helper loaded: form_helper
INFO - 2024-05-12 19:12:17 --> Helper loaded: lang_helper
INFO - 2024-05-12 19:12:17 --> Helper loaded: security_helper
INFO - 2024-05-12 19:12:17 --> Helper loaded: cookie_helper
INFO - 2024-05-12 19:12:17 --> Database Driver Class Initialized
INFO - 2024-05-12 19:12:17 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-12 19:12:17 --> Parser Class Initialized
INFO - 2024-05-12 19:12:17 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-05-12 19:12:17 --> Pagination Class Initialized
INFO - 2024-05-12 19:12:17 --> Form Validation Class Initialized
INFO - 2024-05-12 19:12:17 --> Controller Class Initialized
DEBUG - 2024-05-12 19:12:17 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-05-12 19:12:17 --> Session class already loaded. Second attempt ignored.
INFO - 2024-05-12 19:12:17 --> Model Class Initialized
INFO - 2024-05-12 19:12:17 --> Final output sent to browser
DEBUG - 2024-05-12 19:12:17 --> Total execution time: 0.1120
ERROR - 2024-05-12 19:12:24 --> $config['composer_autoload'] is set to TRUE but E:\xampp\htdocs\maurnaturo\application\vendor/autoload.php was not found.
INFO - 2024-05-12 19:12:24 --> Config Class Initialized
INFO - 2024-05-12 19:12:24 --> Hooks Class Initialized
DEBUG - 2024-05-12 19:12:24 --> UTF-8 Support Enabled
INFO - 2024-05-12 19:12:24 --> Utf8 Class Initialized
INFO - 2024-05-12 19:12:24 --> URI Class Initialized
INFO - 2024-05-12 19:12:24 --> Router Class Initialized
INFO - 2024-05-12 19:12:24 --> Output Class Initialized
INFO - 2024-05-12 19:12:24 --> Security Class Initialized
ERROR - 2024-05-12 19:12:24 --> $config['composer_autoload'] is set to TRUE but E:\xampp\htdocs\maurnaturo\application\vendor/autoload.php was not found.
INFO - 2024-05-12 19:12:24 --> Config Class Initialized
INFO - 2024-05-12 19:12:24 --> Hooks Class Initialized
DEBUG - 2024-05-12 19:12:24 --> UTF-8 Support Enabled
INFO - 2024-05-12 19:12:24 --> Utf8 Class Initialized
INFO - 2024-05-12 19:12:24 --> URI Class Initialized
INFO - 2024-05-12 19:12:24 --> Router Class Initialized
INFO - 2024-05-12 19:12:24 --> Output Class Initialized
INFO - 2024-05-12 19:12:24 --> Security Class Initialized
DEBUG - 2024-05-12 19:12:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-12 19:12:24 --> Input Class Initialized
INFO - 2024-05-12 19:12:24 --> Language Class Initialized
ERROR - 2024-05-12 19:12:24 --> 404 Page Not Found: Assets/bootstrap
DEBUG - 2024-05-12 19:12:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-12 19:12:24 --> Input Class Initialized
INFO - 2024-05-12 19:12:24 --> Language Class Initialized
ERROR - 2024-05-12 19:12:24 --> 404 Page Not Found: Assets/plugins
ERROR - 2024-05-12 19:13:29 --> $config['composer_autoload'] is set to TRUE but E:\xampp\htdocs\maurnaturo\application\vendor/autoload.php was not found.
INFO - 2024-05-12 19:13:29 --> Config Class Initialized
INFO - 2024-05-12 19:13:29 --> Hooks Class Initialized
DEBUG - 2024-05-12 19:13:29 --> UTF-8 Support Enabled
INFO - 2024-05-12 19:13:29 --> Utf8 Class Initialized
INFO - 2024-05-12 19:13:29 --> URI Class Initialized
INFO - 2024-05-12 19:13:29 --> Router Class Initialized
INFO - 2024-05-12 19:13:29 --> Output Class Initialized
INFO - 2024-05-12 19:13:29 --> Security Class Initialized
DEBUG - 2024-05-12 19:13:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-12 19:13:29 --> Input Class Initialized
INFO - 2024-05-12 19:13:29 --> Language Class Initialized
INFO - 2024-05-12 19:13:29 --> Loader Class Initialized
INFO - 2024-05-12 19:13:29 --> Helper loaded: url_helper
INFO - 2024-05-12 19:13:29 --> Helper loaded: file_helper
INFO - 2024-05-12 19:13:29 --> Helper loaded: html_helper
INFO - 2024-05-12 19:13:29 --> Helper loaded: text_helper
INFO - 2024-05-12 19:13:29 --> Helper loaded: form_helper
INFO - 2024-05-12 19:13:29 --> Helper loaded: lang_helper
INFO - 2024-05-12 19:13:29 --> Helper loaded: security_helper
INFO - 2024-05-12 19:13:29 --> Helper loaded: cookie_helper
INFO - 2024-05-12 19:13:29 --> Database Driver Class Initialized
INFO - 2024-05-12 19:13:29 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-12 19:13:29 --> Parser Class Initialized
INFO - 2024-05-12 19:13:29 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-05-12 19:13:29 --> Pagination Class Initialized
INFO - 2024-05-12 19:13:29 --> Form Validation Class Initialized
INFO - 2024-05-12 19:13:29 --> Controller Class Initialized
DEBUG - 2024-05-12 19:13:29 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-05-12 19:13:29 --> Session class already loaded. Second attempt ignored.
INFO - 2024-05-12 19:13:29 --> Model Class Initialized
DEBUG - 2024-05-12 19:13:29 --> Lexpenses class already loaded. Second attempt ignored.
INFO - 2024-05-12 19:13:29 --> Model Class Initialized
INFO - 2024-05-12 19:13:29 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\expenses/expenses.php
DEBUG - 2024-05-12 19:13:29 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-05-12 19:13:29 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\include/top_menu.php
INFO - 2024-05-12 19:13:29 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\include/admin_loggedin_info.php
INFO - 2024-05-12 19:13:29 --> Model Class Initialized
INFO - 2024-05-12 19:13:29 --> Model Class Initialized
INFO - 2024-05-12 19:13:29 --> Model Class Initialized
INFO - 2024-05-12 19:13:31 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\include/admin_header.php
INFO - 2024-05-12 19:13:31 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\include/admin_footer.php
INFO - 2024-05-12 19:13:31 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\admin_html_template.php
INFO - 2024-05-12 19:13:31 --> Final output sent to browser
DEBUG - 2024-05-12 19:13:31 --> Total execution time: 2.0275
ERROR - 2024-05-12 19:13:31 --> $config['composer_autoload'] is set to TRUE but E:\xampp\htdocs\maurnaturo\application\vendor/autoload.php was not found.
INFO - 2024-05-12 19:13:31 --> Config Class Initialized
INFO - 2024-05-12 19:13:31 --> Hooks Class Initialized
DEBUG - 2024-05-12 19:13:31 --> UTF-8 Support Enabled
INFO - 2024-05-12 19:13:31 --> Utf8 Class Initialized
INFO - 2024-05-12 19:13:31 --> URI Class Initialized
INFO - 2024-05-12 19:13:31 --> Router Class Initialized
INFO - 2024-05-12 19:13:32 --> Output Class Initialized
INFO - 2024-05-12 19:13:32 --> Security Class Initialized
DEBUG - 2024-05-12 19:13:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-12 19:13:32 --> Input Class Initialized
INFO - 2024-05-12 19:13:32 --> Language Class Initialized
ERROR - 2024-05-12 19:13:32 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2024-05-12 19:13:32 --> $config['composer_autoload'] is set to TRUE but E:\xampp\htdocs\maurnaturo\application\vendor/autoload.php was not found.
INFO - 2024-05-12 19:13:32 --> Config Class Initialized
INFO - 2024-05-12 19:13:32 --> Hooks Class Initialized
DEBUG - 2024-05-12 19:13:32 --> UTF-8 Support Enabled
INFO - 2024-05-12 19:13:32 --> Utf8 Class Initialized
INFO - 2024-05-12 19:13:32 --> URI Class Initialized
INFO - 2024-05-12 19:13:32 --> Router Class Initialized
INFO - 2024-05-12 19:13:32 --> Output Class Initialized
INFO - 2024-05-12 19:13:32 --> Security Class Initialized
DEBUG - 2024-05-12 19:13:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-12 19:13:32 --> Input Class Initialized
INFO - 2024-05-12 19:13:32 --> Language Class Initialized
INFO - 2024-05-12 19:13:32 --> Loader Class Initialized
INFO - 2024-05-12 19:13:32 --> Helper loaded: url_helper
INFO - 2024-05-12 19:13:32 --> Helper loaded: file_helper
INFO - 2024-05-12 19:13:32 --> Helper loaded: html_helper
INFO - 2024-05-12 19:13:32 --> Helper loaded: text_helper
INFO - 2024-05-12 19:13:32 --> Helper loaded: form_helper
INFO - 2024-05-12 19:13:32 --> Helper loaded: lang_helper
INFO - 2024-05-12 19:13:32 --> Helper loaded: security_helper
INFO - 2024-05-12 19:13:32 --> Helper loaded: cookie_helper
INFO - 2024-05-12 19:13:32 --> Database Driver Class Initialized
INFO - 2024-05-12 19:13:32 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-12 19:13:32 --> Parser Class Initialized
INFO - 2024-05-12 19:13:32 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-05-12 19:13:32 --> Pagination Class Initialized
INFO - 2024-05-12 19:13:32 --> Form Validation Class Initialized
INFO - 2024-05-12 19:13:32 --> Controller Class Initialized
DEBUG - 2024-05-12 19:13:32 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-05-12 19:13:32 --> Session class already loaded. Second attempt ignored.
INFO - 2024-05-12 19:13:32 --> Model Class Initialized
INFO - 2024-05-12 19:13:32 --> Final output sent to browser
DEBUG - 2024-05-12 19:13:32 --> Total execution time: 0.1139
ERROR - 2024-05-12 19:13:37 --> $config['composer_autoload'] is set to TRUE but E:\xampp\htdocs\maurnaturo\application\vendor/autoload.php was not found.
INFO - 2024-05-12 19:13:37 --> Config Class Initialized
INFO - 2024-05-12 19:13:37 --> Hooks Class Initialized
DEBUG - 2024-05-12 19:13:37 --> UTF-8 Support Enabled
INFO - 2024-05-12 19:13:37 --> Utf8 Class Initialized
INFO - 2024-05-12 19:13:37 --> URI Class Initialized
INFO - 2024-05-12 19:13:37 --> Router Class Initialized
INFO - 2024-05-12 19:13:37 --> Output Class Initialized
INFO - 2024-05-12 19:13:37 --> Security Class Initialized
DEBUG - 2024-05-12 19:13:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-12 19:13:37 --> Input Class Initialized
INFO - 2024-05-12 19:13:37 --> Language Class Initialized
INFO - 2024-05-12 19:13:37 --> Loader Class Initialized
INFO - 2024-05-12 19:13:37 --> Helper loaded: url_helper
INFO - 2024-05-12 19:13:37 --> Helper loaded: file_helper
INFO - 2024-05-12 19:13:37 --> Helper loaded: html_helper
INFO - 2024-05-12 19:13:37 --> Helper loaded: text_helper
INFO - 2024-05-12 19:13:37 --> Helper loaded: form_helper
INFO - 2024-05-12 19:13:37 --> Helper loaded: lang_helper
INFO - 2024-05-12 19:13:37 --> Helper loaded: security_helper
INFO - 2024-05-12 19:13:37 --> Helper loaded: cookie_helper
INFO - 2024-05-12 19:13:37 --> Database Driver Class Initialized
INFO - 2024-05-12 19:13:37 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-12 19:13:37 --> Parser Class Initialized
INFO - 2024-05-12 19:13:37 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-05-12 19:13:37 --> Pagination Class Initialized
INFO - 2024-05-12 19:13:37 --> Form Validation Class Initialized
INFO - 2024-05-12 19:13:37 --> Controller Class Initialized
DEBUG - 2024-05-12 19:13:37 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-05-12 19:13:37 --> Session class already loaded. Second attempt ignored.
INFO - 2024-05-12 19:13:37 --> Model Class Initialized
INFO - 2024-05-12 19:13:37 --> Model Class Initialized
DEBUG - 2024-05-12 19:13:37 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-05-12 19:13:37 --> Session class already loaded. Second attempt ignored.
INFO - 2024-05-12 19:13:38 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\expenses/add_expenses_form.php
DEBUG - 2024-05-12 19:13:38 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-05-12 19:13:38 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\include/top_menu.php
INFO - 2024-05-12 19:13:38 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\include/admin_loggedin_info.php
INFO - 2024-05-12 19:13:38 --> Model Class Initialized
INFO - 2024-05-12 19:13:38 --> Model Class Initialized
INFO - 2024-05-12 19:13:38 --> Model Class Initialized
INFO - 2024-05-12 19:13:38 --> Model Class Initialized
INFO - 2024-05-12 19:13:39 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\include/admin_header.php
INFO - 2024-05-12 19:13:39 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\include/admin_footer.php
INFO - 2024-05-12 19:13:39 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\admin_html_template.php
INFO - 2024-05-12 19:13:39 --> Final output sent to browser
DEBUG - 2024-05-12 19:13:39 --> Total execution time: 1.5890
ERROR - 2024-05-12 19:13:52 --> $config['composer_autoload'] is set to TRUE but E:\xampp\htdocs\maurnaturo\application\vendor/autoload.php was not found.
INFO - 2024-05-12 19:13:52 --> Config Class Initialized
INFO - 2024-05-12 19:13:52 --> Hooks Class Initialized
DEBUG - 2024-05-12 19:13:52 --> UTF-8 Support Enabled
INFO - 2024-05-12 19:13:52 --> Utf8 Class Initialized
INFO - 2024-05-12 19:13:52 --> URI Class Initialized
INFO - 2024-05-12 19:13:52 --> Router Class Initialized
INFO - 2024-05-12 19:13:52 --> Output Class Initialized
INFO - 2024-05-12 19:13:52 --> Security Class Initialized
DEBUG - 2024-05-12 19:13:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-12 19:13:52 --> Input Class Initialized
INFO - 2024-05-12 19:13:52 --> Language Class Initialized
INFO - 2024-05-12 19:13:52 --> Loader Class Initialized
INFO - 2024-05-12 19:13:52 --> Helper loaded: url_helper
INFO - 2024-05-12 19:13:52 --> Helper loaded: file_helper
INFO - 2024-05-12 19:13:52 --> Helper loaded: html_helper
INFO - 2024-05-12 19:13:52 --> Helper loaded: text_helper
INFO - 2024-05-12 19:13:52 --> Helper loaded: form_helper
INFO - 2024-05-12 19:13:52 --> Helper loaded: lang_helper
INFO - 2024-05-12 19:13:52 --> Helper loaded: security_helper
INFO - 2024-05-12 19:13:52 --> Helper loaded: cookie_helper
INFO - 2024-05-12 19:13:52 --> Database Driver Class Initialized
INFO - 2024-05-12 19:13:52 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-12 19:13:52 --> Parser Class Initialized
INFO - 2024-05-12 19:13:52 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-05-12 19:13:52 --> Pagination Class Initialized
INFO - 2024-05-12 19:13:52 --> Form Validation Class Initialized
INFO - 2024-05-12 19:13:52 --> Controller Class Initialized
DEBUG - 2024-05-12 19:13:52 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-05-12 19:13:52 --> Session class already loaded. Second attempt ignored.
INFO - 2024-05-12 19:13:52 --> Model Class Initialized
ERROR - 2024-05-12 19:13:52 --> $config['composer_autoload'] is set to TRUE but E:\xampp\htdocs\maurnaturo\application\vendor/autoload.php was not found.
INFO - 2024-05-12 19:13:52 --> Config Class Initialized
INFO - 2024-05-12 19:13:52 --> Hooks Class Initialized
DEBUG - 2024-05-12 19:13:52 --> UTF-8 Support Enabled
INFO - 2024-05-12 19:13:52 --> Utf8 Class Initialized
INFO - 2024-05-12 19:13:52 --> URI Class Initialized
INFO - 2024-05-12 19:13:52 --> Router Class Initialized
INFO - 2024-05-12 19:13:52 --> Output Class Initialized
INFO - 2024-05-12 19:13:52 --> Security Class Initialized
DEBUG - 2024-05-12 19:13:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-12 19:13:52 --> Input Class Initialized
INFO - 2024-05-12 19:13:52 --> Language Class Initialized
INFO - 2024-05-12 19:13:52 --> Loader Class Initialized
INFO - 2024-05-12 19:13:52 --> Helper loaded: url_helper
INFO - 2024-05-12 19:13:52 --> Helper loaded: file_helper
INFO - 2024-05-12 19:13:52 --> Helper loaded: html_helper
INFO - 2024-05-12 19:13:52 --> Helper loaded: text_helper
INFO - 2024-05-12 19:13:52 --> Helper loaded: form_helper
INFO - 2024-05-12 19:13:52 --> Helper loaded: lang_helper
INFO - 2024-05-12 19:13:52 --> Helper loaded: security_helper
INFO - 2024-05-12 19:13:52 --> Helper loaded: cookie_helper
INFO - 2024-05-12 19:13:52 --> Database Driver Class Initialized
INFO - 2024-05-12 19:13:52 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-12 19:13:53 --> Parser Class Initialized
INFO - 2024-05-12 19:13:53 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-05-12 19:13:53 --> Pagination Class Initialized
INFO - 2024-05-12 19:13:53 --> Form Validation Class Initialized
INFO - 2024-05-12 19:13:53 --> Controller Class Initialized
DEBUG - 2024-05-12 19:13:53 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-05-12 19:13:53 --> Session class already loaded. Second attempt ignored.
INFO - 2024-05-12 19:13:53 --> Model Class Initialized
INFO - 2024-05-12 19:13:53 --> Model Class Initialized
DEBUG - 2024-05-12 19:13:53 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-05-12 19:13:53 --> Session class already loaded. Second attempt ignored.
INFO - 2024-05-12 19:13:53 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\expenses/add_expenses_form.php
DEBUG - 2024-05-12 19:13:53 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-05-12 19:13:53 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\include/top_menu.php
INFO - 2024-05-12 19:13:53 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\include/admin_loggedin_info.php
INFO - 2024-05-12 19:13:53 --> Model Class Initialized
INFO - 2024-05-12 19:13:53 --> Model Class Initialized
INFO - 2024-05-12 19:13:53 --> Model Class Initialized
INFO - 2024-05-12 19:13:53 --> Model Class Initialized
INFO - 2024-05-12 19:13:54 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\include/admin_header.php
INFO - 2024-05-12 19:13:54 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\include/admin_footer.php
INFO - 2024-05-12 19:13:54 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\admin_html_template.php
INFO - 2024-05-12 19:13:54 --> Final output sent to browser
DEBUG - 2024-05-12 19:13:54 --> Total execution time: 1.4771
ERROR - 2024-05-12 19:13:55 --> $config['composer_autoload'] is set to TRUE but E:\xampp\htdocs\maurnaturo\application\vendor/autoload.php was not found.
INFO - 2024-05-12 19:13:55 --> Config Class Initialized
INFO - 2024-05-12 19:13:55 --> Hooks Class Initialized
DEBUG - 2024-05-12 19:13:55 --> UTF-8 Support Enabled
INFO - 2024-05-12 19:13:55 --> Utf8 Class Initialized
INFO - 2024-05-12 19:13:55 --> URI Class Initialized
INFO - 2024-05-12 19:13:55 --> Router Class Initialized
INFO - 2024-05-12 19:13:55 --> Output Class Initialized
INFO - 2024-05-12 19:13:55 --> Security Class Initialized
DEBUG - 2024-05-12 19:13:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-12 19:13:55 --> Input Class Initialized
INFO - 2024-05-12 19:13:55 --> Language Class Initialized
INFO - 2024-05-12 19:13:55 --> Loader Class Initialized
INFO - 2024-05-12 19:13:55 --> Helper loaded: url_helper
INFO - 2024-05-12 19:13:55 --> Helper loaded: file_helper
INFO - 2024-05-12 19:13:55 --> Helper loaded: html_helper
INFO - 2024-05-12 19:13:55 --> Helper loaded: text_helper
INFO - 2024-05-12 19:13:55 --> Helper loaded: form_helper
INFO - 2024-05-12 19:13:55 --> Helper loaded: lang_helper
INFO - 2024-05-12 19:13:55 --> Helper loaded: security_helper
INFO - 2024-05-12 19:13:55 --> Helper loaded: cookie_helper
INFO - 2024-05-12 19:13:55 --> Database Driver Class Initialized
INFO - 2024-05-12 19:13:55 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-12 19:13:55 --> Parser Class Initialized
INFO - 2024-05-12 19:13:55 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-05-12 19:13:55 --> Pagination Class Initialized
INFO - 2024-05-12 19:13:55 --> Form Validation Class Initialized
INFO - 2024-05-12 19:13:55 --> Controller Class Initialized
DEBUG - 2024-05-12 19:13:55 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-05-12 19:13:55 --> Session class already loaded. Second attempt ignored.
INFO - 2024-05-12 19:13:55 --> Model Class Initialized
DEBUG - 2024-05-12 19:13:55 --> Lexpenses class already loaded. Second attempt ignored.
INFO - 2024-05-12 19:13:55 --> Model Class Initialized
INFO - 2024-05-12 19:13:56 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\expenses/expenses.php
DEBUG - 2024-05-12 19:13:56 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-05-12 19:13:56 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\include/top_menu.php
INFO - 2024-05-12 19:13:56 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\include/admin_loggedin_info.php
INFO - 2024-05-12 19:13:56 --> Model Class Initialized
INFO - 2024-05-12 19:13:56 --> Model Class Initialized
INFO - 2024-05-12 19:13:56 --> Model Class Initialized
INFO - 2024-05-12 19:13:57 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\include/admin_header.php
INFO - 2024-05-12 19:13:57 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\include/admin_footer.php
INFO - 2024-05-12 19:13:57 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\admin_html_template.php
INFO - 2024-05-12 19:13:57 --> Final output sent to browser
DEBUG - 2024-05-12 19:13:57 --> Total execution time: 1.6848
ERROR - 2024-05-12 19:13:57 --> $config['composer_autoload'] is set to TRUE but E:\xampp\htdocs\maurnaturo\application\vendor/autoload.php was not found.
INFO - 2024-05-12 19:13:57 --> Config Class Initialized
INFO - 2024-05-12 19:13:57 --> Hooks Class Initialized
DEBUG - 2024-05-12 19:13:57 --> UTF-8 Support Enabled
INFO - 2024-05-12 19:13:57 --> Utf8 Class Initialized
INFO - 2024-05-12 19:13:57 --> URI Class Initialized
INFO - 2024-05-12 19:13:57 --> Router Class Initialized
INFO - 2024-05-12 19:13:57 --> Output Class Initialized
INFO - 2024-05-12 19:13:57 --> Security Class Initialized
DEBUG - 2024-05-12 19:13:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-12 19:13:57 --> Input Class Initialized
INFO - 2024-05-12 19:13:57 --> Language Class Initialized
INFO - 2024-05-12 19:13:57 --> Loader Class Initialized
INFO - 2024-05-12 19:13:57 --> Helper loaded: url_helper
INFO - 2024-05-12 19:13:57 --> Helper loaded: file_helper
INFO - 2024-05-12 19:13:57 --> Helper loaded: html_helper
INFO - 2024-05-12 19:13:57 --> Helper loaded: text_helper
INFO - 2024-05-12 19:13:57 --> Helper loaded: form_helper
INFO - 2024-05-12 19:13:57 --> Helper loaded: lang_helper
INFO - 2024-05-12 19:13:57 --> Helper loaded: security_helper
INFO - 2024-05-12 19:13:57 --> Helper loaded: cookie_helper
INFO - 2024-05-12 19:13:57 --> Database Driver Class Initialized
INFO - 2024-05-12 19:13:57 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-12 19:13:57 --> Parser Class Initialized
INFO - 2024-05-12 19:13:57 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-05-12 19:13:57 --> Pagination Class Initialized
INFO - 2024-05-12 19:13:57 --> Form Validation Class Initialized
INFO - 2024-05-12 19:13:57 --> Controller Class Initialized
DEBUG - 2024-05-12 19:13:57 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-05-12 19:13:57 --> Session class already loaded. Second attempt ignored.
INFO - 2024-05-12 19:13:57 --> Model Class Initialized
INFO - 2024-05-12 19:13:57 --> Final output sent to browser
DEBUG - 2024-05-12 19:13:57 --> Total execution time: 0.1024
ERROR - 2024-05-12 19:14:25 --> $config['composer_autoload'] is set to TRUE but E:\xampp\htdocs\maurnaturo\application\vendor/autoload.php was not found.
INFO - 2024-05-12 19:14:25 --> Config Class Initialized
INFO - 2024-05-12 19:14:25 --> Hooks Class Initialized
DEBUG - 2024-05-12 19:14:25 --> UTF-8 Support Enabled
INFO - 2024-05-12 19:14:25 --> Utf8 Class Initialized
INFO - 2024-05-12 19:14:25 --> URI Class Initialized
INFO - 2024-05-12 19:14:25 --> Router Class Initialized
INFO - 2024-05-12 19:14:25 --> Output Class Initialized
INFO - 2024-05-12 19:14:25 --> Security Class Initialized
DEBUG - 2024-05-12 19:14:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-12 19:14:25 --> Input Class Initialized
INFO - 2024-05-12 19:14:25 --> Language Class Initialized
INFO - 2024-05-12 19:14:25 --> Loader Class Initialized
INFO - 2024-05-12 19:14:25 --> Helper loaded: url_helper
INFO - 2024-05-12 19:14:25 --> Helper loaded: file_helper
INFO - 2024-05-12 19:14:25 --> Helper loaded: html_helper
INFO - 2024-05-12 19:14:25 --> Helper loaded: text_helper
INFO - 2024-05-12 19:14:25 --> Helper loaded: form_helper
INFO - 2024-05-12 19:14:25 --> Helper loaded: lang_helper
INFO - 2024-05-12 19:14:25 --> Helper loaded: security_helper
INFO - 2024-05-12 19:14:25 --> Helper loaded: cookie_helper
INFO - 2024-05-12 19:14:25 --> Database Driver Class Initialized
INFO - 2024-05-12 19:14:25 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-12 19:14:25 --> Parser Class Initialized
INFO - 2024-05-12 19:14:25 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-05-12 19:14:25 --> Pagination Class Initialized
INFO - 2024-05-12 19:14:25 --> Form Validation Class Initialized
INFO - 2024-05-12 19:14:25 --> Controller Class Initialized
DEBUG - 2024-05-12 19:14:25 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-05-12 19:14:25 --> Session class already loaded. Second attempt ignored.
INFO - 2024-05-12 19:14:25 --> Model Class Initialized
ERROR - 2024-05-12 19:14:25 --> $config['composer_autoload'] is set to TRUE but E:\xampp\htdocs\maurnaturo\application\vendor/autoload.php was not found.
INFO - 2024-05-12 19:14:25 --> Config Class Initialized
INFO - 2024-05-12 19:14:25 --> Hooks Class Initialized
DEBUG - 2024-05-12 19:14:25 --> UTF-8 Support Enabled
INFO - 2024-05-12 19:14:25 --> Utf8 Class Initialized
INFO - 2024-05-12 19:14:25 --> URI Class Initialized
INFO - 2024-05-12 19:14:25 --> Router Class Initialized
INFO - 2024-05-12 19:14:25 --> Output Class Initialized
INFO - 2024-05-12 19:14:25 --> Security Class Initialized
DEBUG - 2024-05-12 19:14:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-12 19:14:25 --> Input Class Initialized
INFO - 2024-05-12 19:14:25 --> Language Class Initialized
INFO - 2024-05-12 19:14:25 --> Loader Class Initialized
INFO - 2024-05-12 19:14:25 --> Helper loaded: url_helper
INFO - 2024-05-12 19:14:25 --> Helper loaded: file_helper
INFO - 2024-05-12 19:14:25 --> Helper loaded: html_helper
INFO - 2024-05-12 19:14:25 --> Helper loaded: text_helper
INFO - 2024-05-12 19:14:25 --> Helper loaded: form_helper
INFO - 2024-05-12 19:14:25 --> Helper loaded: lang_helper
INFO - 2024-05-12 19:14:25 --> Helper loaded: security_helper
INFO - 2024-05-12 19:14:25 --> Helper loaded: cookie_helper
INFO - 2024-05-12 19:14:25 --> Database Driver Class Initialized
INFO - 2024-05-12 19:14:25 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-12 19:14:25 --> Parser Class Initialized
INFO - 2024-05-12 19:14:25 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-05-12 19:14:25 --> Pagination Class Initialized
INFO - 2024-05-12 19:14:25 --> Form Validation Class Initialized
INFO - 2024-05-12 19:14:25 --> Controller Class Initialized
DEBUG - 2024-05-12 19:14:25 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-05-12 19:14:25 --> Session class already loaded. Second attempt ignored.
INFO - 2024-05-12 19:14:25 --> Model Class Initialized
DEBUG - 2024-05-12 19:14:25 --> Lexpenses class already loaded. Second attempt ignored.
INFO - 2024-05-12 19:14:25 --> Model Class Initialized
INFO - 2024-05-12 19:14:25 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\expenses/expenses.php
DEBUG - 2024-05-12 19:14:25 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-05-12 19:14:25 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\include/top_menu.php
INFO - 2024-05-12 19:14:25 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\include/admin_loggedin_info.php
INFO - 2024-05-12 19:14:25 --> Model Class Initialized
INFO - 2024-05-12 19:14:25 --> Model Class Initialized
INFO - 2024-05-12 19:14:25 --> Model Class Initialized
INFO - 2024-05-12 19:14:27 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\include/admin_header.php
INFO - 2024-05-12 19:14:27 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\include/admin_footer.php
INFO - 2024-05-12 19:14:27 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\admin_html_template.php
INFO - 2024-05-12 19:14:27 --> Final output sent to browser
DEBUG - 2024-05-12 19:14:27 --> Total execution time: 1.4556
ERROR - 2024-05-12 19:14:27 --> $config['composer_autoload'] is set to TRUE but E:\xampp\htdocs\maurnaturo\application\vendor/autoload.php was not found.
INFO - 2024-05-12 19:14:27 --> Config Class Initialized
INFO - 2024-05-12 19:14:27 --> Hooks Class Initialized
DEBUG - 2024-05-12 19:14:27 --> UTF-8 Support Enabled
INFO - 2024-05-12 19:14:27 --> Utf8 Class Initialized
INFO - 2024-05-12 19:14:27 --> URI Class Initialized
INFO - 2024-05-12 19:14:27 --> Router Class Initialized
INFO - 2024-05-12 19:14:27 --> Output Class Initialized
INFO - 2024-05-12 19:14:27 --> Security Class Initialized
DEBUG - 2024-05-12 19:14:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-12 19:14:27 --> Input Class Initialized
INFO - 2024-05-12 19:14:27 --> Language Class Initialized
INFO - 2024-05-12 19:14:27 --> Loader Class Initialized
INFO - 2024-05-12 19:14:27 --> Helper loaded: url_helper
INFO - 2024-05-12 19:14:27 --> Helper loaded: file_helper
INFO - 2024-05-12 19:14:27 --> Helper loaded: html_helper
INFO - 2024-05-12 19:14:27 --> Helper loaded: text_helper
INFO - 2024-05-12 19:14:27 --> Helper loaded: form_helper
INFO - 2024-05-12 19:14:27 --> Helper loaded: lang_helper
INFO - 2024-05-12 19:14:27 --> Helper loaded: security_helper
INFO - 2024-05-12 19:14:27 --> Helper loaded: cookie_helper
INFO - 2024-05-12 19:14:27 --> Database Driver Class Initialized
INFO - 2024-05-12 19:14:27 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-12 19:14:27 --> Parser Class Initialized
INFO - 2024-05-12 19:14:27 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-05-12 19:14:27 --> Pagination Class Initialized
INFO - 2024-05-12 19:14:27 --> Form Validation Class Initialized
INFO - 2024-05-12 19:14:27 --> Controller Class Initialized
DEBUG - 2024-05-12 19:14:27 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-05-12 19:14:27 --> Session class already loaded. Second attempt ignored.
INFO - 2024-05-12 19:14:27 --> Model Class Initialized
INFO - 2024-05-12 19:14:27 --> Final output sent to browser
DEBUG - 2024-05-12 19:14:27 --> Total execution time: 0.1070
