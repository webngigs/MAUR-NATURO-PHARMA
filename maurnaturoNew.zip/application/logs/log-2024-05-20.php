<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2024-05-20 18:05:08 --> $config['composer_autoload'] is set to TRUE but /home/u241458058/domains/technoprimex.com/public_html/maurnaturo/application/vendor/autoload.php was not found.
INFO - 2024-05-20 18:05:08 --> Config Class Initialized
INFO - 2024-05-20 18:05:08 --> Hooks Class Initialized
DEBUG - 2024-05-20 18:05:08 --> UTF-8 Support Enabled
INFO - 2024-05-20 18:05:08 --> Utf8 Class Initialized
INFO - 2024-05-20 18:05:08 --> URI Class Initialized
DEBUG - 2024-05-20 18:05:08 --> No URI present. Default controller set.
INFO - 2024-05-20 18:05:08 --> Router Class Initialized
INFO - 2024-05-20 18:05:08 --> Output Class Initialized
INFO - 2024-05-20 18:05:08 --> Security Class Initialized
DEBUG - 2024-05-20 18:05:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-20 18:05:08 --> Input Class Initialized
INFO - 2024-05-20 18:05:08 --> Language Class Initialized
INFO - 2024-05-20 18:05:08 --> Loader Class Initialized
INFO - 2024-05-20 18:05:08 --> Helper loaded: url_helper
INFO - 2024-05-20 18:05:08 --> Helper loaded: file_helper
INFO - 2024-05-20 18:05:08 --> Helper loaded: html_helper
INFO - 2024-05-20 18:05:08 --> Helper loaded: text_helper
INFO - 2024-05-20 18:05:08 --> Helper loaded: form_helper
INFO - 2024-05-20 18:05:08 --> Helper loaded: lang_helper
INFO - 2024-05-20 18:05:08 --> Helper loaded: security_helper
INFO - 2024-05-20 18:05:08 --> Helper loaded: cookie_helper
INFO - 2024-05-20 18:05:08 --> Database Driver Class Initialized
INFO - 2024-05-20 18:05:08 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-20 18:05:08 --> Parser Class Initialized
INFO - 2024-05-20 18:05:08 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-05-20 18:05:08 --> Pagination Class Initialized
INFO - 2024-05-20 18:05:08 --> Form Validation Class Initialized
INFO - 2024-05-20 18:05:08 --> Controller Class Initialized
INFO - 2024-05-20 18:05:08 --> Model Class Initialized
DEBUG - 2024-05-20 18:05:08 --> Session class already loaded. Second attempt ignored.
ERROR - 2024-05-20 18:05:08 --> $config['composer_autoload'] is set to TRUE but /home/u241458058/domains/technoprimex.com/public_html/maurnaturo/application/vendor/autoload.php was not found.
INFO - 2024-05-20 18:05:08 --> Config Class Initialized
INFO - 2024-05-20 18:05:08 --> Hooks Class Initialized
DEBUG - 2024-05-20 18:05:08 --> UTF-8 Support Enabled
INFO - 2024-05-20 18:05:08 --> Utf8 Class Initialized
INFO - 2024-05-20 18:05:08 --> URI Class Initialized
INFO - 2024-05-20 18:05:08 --> Router Class Initialized
INFO - 2024-05-20 18:05:08 --> Output Class Initialized
INFO - 2024-05-20 18:05:08 --> Security Class Initialized
DEBUG - 2024-05-20 18:05:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-20 18:05:08 --> Input Class Initialized
INFO - 2024-05-20 18:05:08 --> Language Class Initialized
INFO - 2024-05-20 18:05:08 --> Loader Class Initialized
INFO - 2024-05-20 18:05:08 --> Helper loaded: url_helper
INFO - 2024-05-20 18:05:08 --> Helper loaded: file_helper
INFO - 2024-05-20 18:05:08 --> Helper loaded: html_helper
INFO - 2024-05-20 18:05:08 --> Helper loaded: text_helper
INFO - 2024-05-20 18:05:08 --> Helper loaded: form_helper
INFO - 2024-05-20 18:05:08 --> Helper loaded: lang_helper
INFO - 2024-05-20 18:05:08 --> Helper loaded: security_helper
INFO - 2024-05-20 18:05:08 --> Helper loaded: cookie_helper
INFO - 2024-05-20 18:05:08 --> Database Driver Class Initialized
INFO - 2024-05-20 18:05:08 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-20 18:05:08 --> Parser Class Initialized
INFO - 2024-05-20 18:05:08 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-05-20 18:05:08 --> Pagination Class Initialized
INFO - 2024-05-20 18:05:08 --> Form Validation Class Initialized
INFO - 2024-05-20 18:05:08 --> Controller Class Initialized
INFO - 2024-05-20 18:05:08 --> Model Class Initialized
DEBUG - 2024-05-20 18:05:08 --> Session class already loaded. Second attempt ignored.
INFO - 2024-05-20 18:05:08 --> File loaded: /home/u241458058/domains/technoprimex.com/public_html/maurnaturo/application/views/user/admin_login_form.php
DEBUG - 2024-05-20 18:05:08 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-05-20 18:05:08 --> File loaded: /home/u241458058/domains/technoprimex.com/public_html/maurnaturo/application/views/include/top_menu.php
INFO - 2024-05-20 18:05:08 --> File loaded: /home/u241458058/domains/technoprimex.com/public_html/maurnaturo/application/views/include/admin_loggedin_info.php
INFO - 2024-05-20 18:05:08 --> Model Class Initialized
INFO - 2024-05-20 18:05:08 --> File loaded: /home/u241458058/domains/technoprimex.com/public_html/maurnaturo/application/views/admin_html_template.php
INFO - 2024-05-20 18:05:08 --> Final output sent to browser
DEBUG - 2024-05-20 18:05:08 --> Total execution time: 0.0213
ERROR - 2024-05-20 18:05:23 --> $config['composer_autoload'] is set to TRUE but /home/u241458058/domains/technoprimex.com/public_html/maurnaturo/application/vendor/autoload.php was not found.
INFO - 2024-05-20 18:05:23 --> Config Class Initialized
INFO - 2024-05-20 18:05:23 --> Hooks Class Initialized
DEBUG - 2024-05-20 18:05:23 --> UTF-8 Support Enabled
INFO - 2024-05-20 18:05:23 --> Utf8 Class Initialized
INFO - 2024-05-20 18:05:23 --> URI Class Initialized
INFO - 2024-05-20 18:05:23 --> Router Class Initialized
INFO - 2024-05-20 18:05:23 --> Output Class Initialized
INFO - 2024-05-20 18:05:23 --> Security Class Initialized
DEBUG - 2024-05-20 18:05:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-20 18:05:23 --> Input Class Initialized
INFO - 2024-05-20 18:05:23 --> Language Class Initialized
INFO - 2024-05-20 18:05:23 --> Loader Class Initialized
INFO - 2024-05-20 18:05:23 --> Helper loaded: url_helper
INFO - 2024-05-20 18:05:23 --> Helper loaded: file_helper
INFO - 2024-05-20 18:05:23 --> Helper loaded: html_helper
INFO - 2024-05-20 18:05:23 --> Helper loaded: text_helper
INFO - 2024-05-20 18:05:23 --> Helper loaded: form_helper
INFO - 2024-05-20 18:05:23 --> Helper loaded: lang_helper
INFO - 2024-05-20 18:05:23 --> Helper loaded: security_helper
INFO - 2024-05-20 18:05:23 --> Helper loaded: cookie_helper
INFO - 2024-05-20 18:05:23 --> Database Driver Class Initialized
INFO - 2024-05-20 18:05:23 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-20 18:05:23 --> Parser Class Initialized
INFO - 2024-05-20 18:05:23 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-05-20 18:05:23 --> Pagination Class Initialized
INFO - 2024-05-20 18:05:23 --> Form Validation Class Initialized
INFO - 2024-05-20 18:05:23 --> Controller Class Initialized
INFO - 2024-05-20 18:05:23 --> Model Class Initialized
DEBUG - 2024-05-20 18:05:23 --> Session class already loaded. Second attempt ignored.
INFO - 2024-05-20 18:05:23 --> File loaded: /home/u241458058/domains/technoprimex.com/public_html/maurnaturo/application/views/user/admin_login_form.php
DEBUG - 2024-05-20 18:05:23 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-05-20 18:05:23 --> File loaded: /home/u241458058/domains/technoprimex.com/public_html/maurnaturo/application/views/include/top_menu.php
INFO - 2024-05-20 18:05:23 --> File loaded: /home/u241458058/domains/technoprimex.com/public_html/maurnaturo/application/views/include/admin_loggedin_info.php
INFO - 2024-05-20 18:05:23 --> Model Class Initialized
INFO - 2024-05-20 18:05:23 --> File loaded: /home/u241458058/domains/technoprimex.com/public_html/maurnaturo/application/views/admin_html_template.php
INFO - 2024-05-20 18:05:23 --> Final output sent to browser
DEBUG - 2024-05-20 18:05:23 --> Total execution time: 0.0211
ERROR - 2024-05-20 18:09:54 --> $config['composer_autoload'] is set to TRUE but /home/u241458058/domains/technoprimex.com/public_html/maurnaturo/application/vendor/autoload.php was not found.
INFO - 2024-05-20 18:09:54 --> Config Class Initialized
INFO - 2024-05-20 18:09:54 --> Hooks Class Initialized
DEBUG - 2024-05-20 18:09:54 --> UTF-8 Support Enabled
INFO - 2024-05-20 18:09:54 --> Utf8 Class Initialized
INFO - 2024-05-20 18:09:54 --> URI Class Initialized
DEBUG - 2024-05-20 18:09:54 --> No URI present. Default controller set.
INFO - 2024-05-20 18:09:54 --> Router Class Initialized
INFO - 2024-05-20 18:09:54 --> Output Class Initialized
INFO - 2024-05-20 18:09:54 --> Security Class Initialized
DEBUG - 2024-05-20 18:09:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-20 18:09:54 --> Input Class Initialized
INFO - 2024-05-20 18:09:54 --> Language Class Initialized
INFO - 2024-05-20 18:09:54 --> Loader Class Initialized
INFO - 2024-05-20 18:09:54 --> Helper loaded: url_helper
INFO - 2024-05-20 18:09:54 --> Helper loaded: file_helper
INFO - 2024-05-20 18:09:54 --> Helper loaded: html_helper
INFO - 2024-05-20 18:09:54 --> Helper loaded: text_helper
INFO - 2024-05-20 18:09:54 --> Helper loaded: form_helper
INFO - 2024-05-20 18:09:54 --> Helper loaded: lang_helper
INFO - 2024-05-20 18:09:54 --> Helper loaded: security_helper
INFO - 2024-05-20 18:09:54 --> Helper loaded: cookie_helper
INFO - 2024-05-20 18:09:54 --> Database Driver Class Initialized
INFO - 2024-05-20 18:09:54 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-20 18:09:54 --> Parser Class Initialized
INFO - 2024-05-20 18:09:54 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-05-20 18:09:54 --> Pagination Class Initialized
INFO - 2024-05-20 18:09:54 --> Form Validation Class Initialized
INFO - 2024-05-20 18:09:54 --> Controller Class Initialized
INFO - 2024-05-20 18:09:54 --> Model Class Initialized
DEBUG - 2024-05-20 18:09:54 --> Session class already loaded. Second attempt ignored.
ERROR - 2024-05-20 18:20:13 --> $config['composer_autoload'] is set to TRUE but /home/u241458058/domains/technoprimex.com/public_html/maurnaturo/application/vendor/autoload.php was not found.
INFO - 2024-05-20 18:20:13 --> Config Class Initialized
INFO - 2024-05-20 18:20:13 --> Hooks Class Initialized
DEBUG - 2024-05-20 18:20:13 --> UTF-8 Support Enabled
INFO - 2024-05-20 18:20:13 --> Utf8 Class Initialized
INFO - 2024-05-20 18:20:13 --> URI Class Initialized
DEBUG - 2024-05-20 18:20:13 --> No URI present. Default controller set.
INFO - 2024-05-20 18:20:13 --> Router Class Initialized
INFO - 2024-05-20 18:20:13 --> Output Class Initialized
INFO - 2024-05-20 18:20:13 --> Security Class Initialized
DEBUG - 2024-05-20 18:20:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-20 18:20:13 --> Input Class Initialized
INFO - 2024-05-20 18:20:13 --> Language Class Initialized
INFO - 2024-05-20 18:20:13 --> Loader Class Initialized
INFO - 2024-05-20 18:20:13 --> Helper loaded: url_helper
INFO - 2024-05-20 18:20:13 --> Helper loaded: file_helper
INFO - 2024-05-20 18:20:13 --> Helper loaded: html_helper
INFO - 2024-05-20 18:20:13 --> Helper loaded: text_helper
INFO - 2024-05-20 18:20:13 --> Helper loaded: form_helper
INFO - 2024-05-20 18:20:13 --> Helper loaded: lang_helper
INFO - 2024-05-20 18:20:13 --> Helper loaded: security_helper
INFO - 2024-05-20 18:20:13 --> Helper loaded: cookie_helper
INFO - 2024-05-20 18:20:13 --> Database Driver Class Initialized
INFO - 2024-05-20 18:20:13 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-20 18:20:13 --> Parser Class Initialized
INFO - 2024-05-20 18:20:13 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-05-20 18:20:13 --> Pagination Class Initialized
INFO - 2024-05-20 18:20:13 --> Form Validation Class Initialized
INFO - 2024-05-20 18:20:13 --> Controller Class Initialized
INFO - 2024-05-20 18:20:13 --> Model Class Initialized
DEBUG - 2024-05-20 18:20:13 --> Session class already loaded. Second attempt ignored.
ERROR - 2024-05-20 18:20:15 --> $config['composer_autoload'] is set to TRUE but /home/u241458058/domains/technoprimex.com/public_html/maurnaturo/application/vendor/autoload.php was not found.
INFO - 2024-05-20 18:20:15 --> Config Class Initialized
INFO - 2024-05-20 18:20:15 --> Hooks Class Initialized
DEBUG - 2024-05-20 18:20:15 --> UTF-8 Support Enabled
INFO - 2024-05-20 18:20:15 --> Utf8 Class Initialized
INFO - 2024-05-20 18:20:15 --> URI Class Initialized
DEBUG - 2024-05-20 18:20:15 --> No URI present. Default controller set.
INFO - 2024-05-20 18:20:15 --> Router Class Initialized
INFO - 2024-05-20 18:20:15 --> Output Class Initialized
INFO - 2024-05-20 18:20:15 --> Security Class Initialized
DEBUG - 2024-05-20 18:20:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-20 18:20:15 --> Input Class Initialized
INFO - 2024-05-20 18:20:15 --> Language Class Initialized
INFO - 2024-05-20 18:20:15 --> Loader Class Initialized
INFO - 2024-05-20 18:20:15 --> Helper loaded: url_helper
INFO - 2024-05-20 18:20:15 --> Helper loaded: file_helper
INFO - 2024-05-20 18:20:15 --> Helper loaded: html_helper
INFO - 2024-05-20 18:20:15 --> Helper loaded: text_helper
INFO - 2024-05-20 18:20:15 --> Helper loaded: form_helper
INFO - 2024-05-20 18:20:15 --> Helper loaded: lang_helper
INFO - 2024-05-20 18:20:15 --> Helper loaded: security_helper
INFO - 2024-05-20 18:20:15 --> Helper loaded: cookie_helper
INFO - 2024-05-20 18:20:15 --> Database Driver Class Initialized
INFO - 2024-05-20 18:20:15 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-20 18:20:15 --> Parser Class Initialized
INFO - 2024-05-20 18:20:15 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-05-20 18:20:15 --> Pagination Class Initialized
INFO - 2024-05-20 18:20:15 --> Form Validation Class Initialized
INFO - 2024-05-20 18:20:15 --> Controller Class Initialized
INFO - 2024-05-20 18:20:15 --> Model Class Initialized
DEBUG - 2024-05-20 18:20:15 --> Session class already loaded. Second attempt ignored.
ERROR - 2024-05-20 18:20:15 --> $config['composer_autoload'] is set to TRUE but /home/u241458058/domains/technoprimex.com/public_html/maurnaturo/application/vendor/autoload.php was not found.
INFO - 2024-05-20 18:20:15 --> Config Class Initialized
INFO - 2024-05-20 18:20:15 --> Hooks Class Initialized
DEBUG - 2024-05-20 18:20:15 --> UTF-8 Support Enabled
INFO - 2024-05-20 18:20:15 --> Utf8 Class Initialized
INFO - 2024-05-20 18:20:15 --> URI Class Initialized
DEBUG - 2024-05-20 18:20:15 --> No URI present. Default controller set.
INFO - 2024-05-20 18:20:15 --> Router Class Initialized
INFO - 2024-05-20 18:20:15 --> Output Class Initialized
INFO - 2024-05-20 18:20:15 --> Security Class Initialized
DEBUG - 2024-05-20 18:20:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-20 18:20:15 --> Input Class Initialized
INFO - 2024-05-20 18:20:15 --> Language Class Initialized
INFO - 2024-05-20 18:20:15 --> Loader Class Initialized
INFO - 2024-05-20 18:20:15 --> Helper loaded: url_helper
INFO - 2024-05-20 18:20:15 --> Helper loaded: file_helper
INFO - 2024-05-20 18:20:15 --> Helper loaded: html_helper
INFO - 2024-05-20 18:20:15 --> Helper loaded: text_helper
INFO - 2024-05-20 18:20:15 --> Helper loaded: form_helper
INFO - 2024-05-20 18:20:15 --> Helper loaded: lang_helper
INFO - 2024-05-20 18:20:15 --> Helper loaded: security_helper
INFO - 2024-05-20 18:20:15 --> Helper loaded: cookie_helper
INFO - 2024-05-20 18:20:15 --> Database Driver Class Initialized
INFO - 2024-05-20 18:20:15 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-20 18:20:15 --> Parser Class Initialized
INFO - 2024-05-20 18:20:15 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-05-20 18:20:15 --> Pagination Class Initialized
INFO - 2024-05-20 18:20:15 --> Form Validation Class Initialized
INFO - 2024-05-20 18:20:15 --> Controller Class Initialized
INFO - 2024-05-20 18:20:15 --> Model Class Initialized
DEBUG - 2024-05-20 18:20:15 --> Session class already loaded. Second attempt ignored.
ERROR - 2024-05-20 18:20:17 --> $config['composer_autoload'] is set to TRUE but /home/u241458058/domains/technoprimex.com/public_html/maurnaturo/application/vendor/autoload.php was not found.
INFO - 2024-05-20 18:20:17 --> Config Class Initialized
INFO - 2024-05-20 18:20:17 --> Hooks Class Initialized
DEBUG - 2024-05-20 18:20:17 --> UTF-8 Support Enabled
INFO - 2024-05-20 18:20:17 --> Utf8 Class Initialized
INFO - 2024-05-20 18:20:17 --> URI Class Initialized
DEBUG - 2024-05-20 18:20:17 --> No URI present. Default controller set.
INFO - 2024-05-20 18:20:17 --> Router Class Initialized
INFO - 2024-05-20 18:20:17 --> Output Class Initialized
INFO - 2024-05-20 18:20:17 --> Security Class Initialized
DEBUG - 2024-05-20 18:20:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-20 18:20:17 --> Input Class Initialized
INFO - 2024-05-20 18:20:17 --> Language Class Initialized
INFO - 2024-05-20 18:20:17 --> Loader Class Initialized
INFO - 2024-05-20 18:20:17 --> Helper loaded: url_helper
INFO - 2024-05-20 18:20:17 --> Helper loaded: file_helper
INFO - 2024-05-20 18:20:17 --> Helper loaded: html_helper
INFO - 2024-05-20 18:20:17 --> Helper loaded: text_helper
INFO - 2024-05-20 18:20:17 --> Helper loaded: form_helper
INFO - 2024-05-20 18:20:17 --> Helper loaded: lang_helper
INFO - 2024-05-20 18:20:17 --> Helper loaded: security_helper
INFO - 2024-05-20 18:20:17 --> Helper loaded: cookie_helper
INFO - 2024-05-20 18:20:17 --> Database Driver Class Initialized
INFO - 2024-05-20 18:20:17 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-20 18:20:17 --> Parser Class Initialized
INFO - 2024-05-20 18:20:17 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-05-20 18:20:17 --> Pagination Class Initialized
INFO - 2024-05-20 18:20:17 --> Form Validation Class Initialized
INFO - 2024-05-20 18:20:17 --> Controller Class Initialized
INFO - 2024-05-20 18:20:17 --> Model Class Initialized
DEBUG - 2024-05-20 18:20:17 --> Session class already loaded. Second attempt ignored.
ERROR - 2024-05-20 18:20:19 --> $config['composer_autoload'] is set to TRUE but /home/u241458058/domains/technoprimex.com/public_html/maurnaturo/application/vendor/autoload.php was not found.
INFO - 2024-05-20 18:20:19 --> Config Class Initialized
INFO - 2024-05-20 18:20:19 --> Hooks Class Initialized
DEBUG - 2024-05-20 18:20:19 --> UTF-8 Support Enabled
INFO - 2024-05-20 18:20:19 --> Utf8 Class Initialized
INFO - 2024-05-20 18:20:19 --> URI Class Initialized
DEBUG - 2024-05-20 18:20:19 --> No URI present. Default controller set.
INFO - 2024-05-20 18:20:19 --> Router Class Initialized
INFO - 2024-05-20 18:20:19 --> Output Class Initialized
INFO - 2024-05-20 18:20:19 --> Security Class Initialized
DEBUG - 2024-05-20 18:20:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-20 18:20:19 --> Input Class Initialized
INFO - 2024-05-20 18:20:19 --> Language Class Initialized
INFO - 2024-05-20 18:20:19 --> Loader Class Initialized
INFO - 2024-05-20 18:20:19 --> Helper loaded: url_helper
INFO - 2024-05-20 18:20:19 --> Helper loaded: file_helper
INFO - 2024-05-20 18:20:19 --> Helper loaded: html_helper
INFO - 2024-05-20 18:20:19 --> Helper loaded: text_helper
INFO - 2024-05-20 18:20:19 --> Helper loaded: form_helper
INFO - 2024-05-20 18:20:19 --> Helper loaded: lang_helper
INFO - 2024-05-20 18:20:19 --> Helper loaded: security_helper
INFO - 2024-05-20 18:20:19 --> Helper loaded: cookie_helper
INFO - 2024-05-20 18:20:19 --> Database Driver Class Initialized
INFO - 2024-05-20 18:20:19 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-20 18:20:19 --> Parser Class Initialized
INFO - 2024-05-20 18:20:19 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-05-20 18:20:19 --> Pagination Class Initialized
INFO - 2024-05-20 18:20:19 --> Form Validation Class Initialized
INFO - 2024-05-20 18:20:19 --> Controller Class Initialized
INFO - 2024-05-20 18:20:19 --> Model Class Initialized
DEBUG - 2024-05-20 18:20:19 --> Session class already loaded. Second attempt ignored.
ERROR - 2024-05-20 18:20:19 --> $config['composer_autoload'] is set to TRUE but /home/u241458058/domains/technoprimex.com/public_html/maurnaturo/application/vendor/autoload.php was not found.
INFO - 2024-05-20 18:20:19 --> Config Class Initialized
INFO - 2024-05-20 18:20:19 --> Hooks Class Initialized
DEBUG - 2024-05-20 18:20:19 --> UTF-8 Support Enabled
INFO - 2024-05-20 18:20:19 --> Utf8 Class Initialized
INFO - 2024-05-20 18:20:19 --> URI Class Initialized
INFO - 2024-05-20 18:20:19 --> Router Class Initialized
INFO - 2024-05-20 18:20:19 --> Output Class Initialized
INFO - 2024-05-20 18:20:19 --> Security Class Initialized
DEBUG - 2024-05-20 18:20:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-20 18:20:19 --> Input Class Initialized
INFO - 2024-05-20 18:20:19 --> Language Class Initialized
INFO - 2024-05-20 18:20:19 --> Loader Class Initialized
INFO - 2024-05-20 18:20:19 --> Helper loaded: url_helper
INFO - 2024-05-20 18:20:19 --> Helper loaded: file_helper
INFO - 2024-05-20 18:20:19 --> Helper loaded: html_helper
INFO - 2024-05-20 18:20:19 --> Helper loaded: text_helper
INFO - 2024-05-20 18:20:19 --> Helper loaded: form_helper
INFO - 2024-05-20 18:20:19 --> Helper loaded: lang_helper
INFO - 2024-05-20 18:20:19 --> Helper loaded: security_helper
INFO - 2024-05-20 18:20:19 --> Helper loaded: cookie_helper
INFO - 2024-05-20 18:20:19 --> Database Driver Class Initialized
INFO - 2024-05-20 18:20:19 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-20 18:20:19 --> Parser Class Initialized
INFO - 2024-05-20 18:20:19 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-05-20 18:20:19 --> Pagination Class Initialized
INFO - 2024-05-20 18:20:19 --> Form Validation Class Initialized
INFO - 2024-05-20 18:20:19 --> Controller Class Initialized
INFO - 2024-05-20 18:20:19 --> Model Class Initialized
DEBUG - 2024-05-20 18:20:19 --> Session class already loaded. Second attempt ignored.
INFO - 2024-05-20 18:20:19 --> File loaded: /home/u241458058/domains/technoprimex.com/public_html/maurnaturo/application/views/user/admin_login_form.php
DEBUG - 2024-05-20 18:20:19 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-05-20 18:20:19 --> File loaded: /home/u241458058/domains/technoprimex.com/public_html/maurnaturo/application/views/include/top_menu.php
INFO - 2024-05-20 18:20:19 --> File loaded: /home/u241458058/domains/technoprimex.com/public_html/maurnaturo/application/views/include/admin_loggedin_info.php
INFO - 2024-05-20 18:20:19 --> Model Class Initialized
INFO - 2024-05-20 18:20:19 --> File loaded: /home/u241458058/domains/technoprimex.com/public_html/maurnaturo/application/views/admin_html_template.php
INFO - 2024-05-20 18:20:19 --> Final output sent to browser
DEBUG - 2024-05-20 18:20:19 --> Total execution time: 0.0219
ERROR - 2024-05-20 18:20:21 --> $config['composer_autoload'] is set to TRUE but /home/u241458058/domains/technoprimex.com/public_html/maurnaturo/application/vendor/autoload.php was not found.
INFO - 2024-05-20 18:20:21 --> Config Class Initialized
INFO - 2024-05-20 18:20:21 --> Hooks Class Initialized
DEBUG - 2024-05-20 18:20:21 --> UTF-8 Support Enabled
INFO - 2024-05-20 18:20:21 --> Utf8 Class Initialized
INFO - 2024-05-20 18:20:21 --> URI Class Initialized
DEBUG - 2024-05-20 18:20:21 --> No URI present. Default controller set.
INFO - 2024-05-20 18:20:21 --> Router Class Initialized
INFO - 2024-05-20 18:20:21 --> Output Class Initialized
INFO - 2024-05-20 18:20:21 --> Security Class Initialized
DEBUG - 2024-05-20 18:20:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-20 18:20:21 --> Input Class Initialized
INFO - 2024-05-20 18:20:21 --> Language Class Initialized
INFO - 2024-05-20 18:20:21 --> Loader Class Initialized
INFO - 2024-05-20 18:20:21 --> Helper loaded: url_helper
INFO - 2024-05-20 18:20:21 --> Helper loaded: file_helper
INFO - 2024-05-20 18:20:21 --> Helper loaded: html_helper
INFO - 2024-05-20 18:20:21 --> Helper loaded: text_helper
INFO - 2024-05-20 18:20:21 --> Helper loaded: form_helper
INFO - 2024-05-20 18:20:21 --> Helper loaded: lang_helper
INFO - 2024-05-20 18:20:21 --> Helper loaded: security_helper
INFO - 2024-05-20 18:20:21 --> Helper loaded: cookie_helper
INFO - 2024-05-20 18:20:21 --> Database Driver Class Initialized
INFO - 2024-05-20 18:20:21 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-20 18:20:21 --> Parser Class Initialized
INFO - 2024-05-20 18:20:21 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-05-20 18:20:21 --> Pagination Class Initialized
INFO - 2024-05-20 18:20:21 --> Form Validation Class Initialized
INFO - 2024-05-20 18:20:21 --> Controller Class Initialized
INFO - 2024-05-20 18:20:21 --> Model Class Initialized
DEBUG - 2024-05-20 18:20:21 --> Session class already loaded. Second attempt ignored.
ERROR - 2024-05-20 18:20:21 --> $config['composer_autoload'] is set to TRUE but /home/u241458058/domains/technoprimex.com/public_html/maurnaturo/application/vendor/autoload.php was not found.
INFO - 2024-05-20 18:20:21 --> Config Class Initialized
INFO - 2024-05-20 18:20:21 --> Hooks Class Initialized
DEBUG - 2024-05-20 18:20:21 --> UTF-8 Support Enabled
INFO - 2024-05-20 18:20:21 --> Utf8 Class Initialized
INFO - 2024-05-20 18:20:21 --> URI Class Initialized
INFO - 2024-05-20 18:20:21 --> Router Class Initialized
INFO - 2024-05-20 18:20:21 --> Output Class Initialized
INFO - 2024-05-20 18:20:21 --> Security Class Initialized
DEBUG - 2024-05-20 18:20:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-20 18:20:21 --> Input Class Initialized
INFO - 2024-05-20 18:20:21 --> Language Class Initialized
INFO - 2024-05-20 18:20:21 --> Loader Class Initialized
INFO - 2024-05-20 18:20:21 --> Helper loaded: url_helper
INFO - 2024-05-20 18:20:21 --> Helper loaded: file_helper
INFO - 2024-05-20 18:20:21 --> Helper loaded: html_helper
INFO - 2024-05-20 18:20:21 --> Helper loaded: text_helper
INFO - 2024-05-20 18:20:21 --> Helper loaded: form_helper
INFO - 2024-05-20 18:20:21 --> Helper loaded: lang_helper
INFO - 2024-05-20 18:20:21 --> Helper loaded: security_helper
INFO - 2024-05-20 18:20:21 --> Helper loaded: cookie_helper
INFO - 2024-05-20 18:20:21 --> Database Driver Class Initialized
INFO - 2024-05-20 18:20:21 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-20 18:20:21 --> Parser Class Initialized
INFO - 2024-05-20 18:20:21 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-05-20 18:20:21 --> Pagination Class Initialized
INFO - 2024-05-20 18:20:21 --> Form Validation Class Initialized
INFO - 2024-05-20 18:20:21 --> Controller Class Initialized
INFO - 2024-05-20 18:20:21 --> Model Class Initialized
DEBUG - 2024-05-20 18:20:21 --> Session class already loaded. Second attempt ignored.
INFO - 2024-05-20 18:20:21 --> File loaded: /home/u241458058/domains/technoprimex.com/public_html/maurnaturo/application/views/user/admin_login_form.php
DEBUG - 2024-05-20 18:20:21 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-05-20 18:20:21 --> File loaded: /home/u241458058/domains/technoprimex.com/public_html/maurnaturo/application/views/include/top_menu.php
INFO - 2024-05-20 18:20:21 --> File loaded: /home/u241458058/domains/technoprimex.com/public_html/maurnaturo/application/views/include/admin_loggedin_info.php
INFO - 2024-05-20 18:20:21 --> Model Class Initialized
INFO - 2024-05-20 18:20:21 --> File loaded: /home/u241458058/domains/technoprimex.com/public_html/maurnaturo/application/views/admin_html_template.php
INFO - 2024-05-20 18:20:21 --> Final output sent to browser
DEBUG - 2024-05-20 18:20:21 --> Total execution time: 0.0210
ERROR - 2024-05-20 18:21:02 --> $config['composer_autoload'] is set to TRUE but /home/u241458058/domains/technoprimex.com/public_html/maurnaturo/application/vendor/autoload.php was not found.
INFO - 2024-05-20 18:21:02 --> Config Class Initialized
INFO - 2024-05-20 18:21:02 --> Hooks Class Initialized
DEBUG - 2024-05-20 18:21:02 --> UTF-8 Support Enabled
INFO - 2024-05-20 18:21:02 --> Utf8 Class Initialized
INFO - 2024-05-20 18:21:02 --> URI Class Initialized
DEBUG - 2024-05-20 18:21:02 --> No URI present. Default controller set.
INFO - 2024-05-20 18:21:02 --> Router Class Initialized
INFO - 2024-05-20 18:21:02 --> Output Class Initialized
INFO - 2024-05-20 18:21:02 --> Security Class Initialized
DEBUG - 2024-05-20 18:21:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-20 18:21:02 --> Input Class Initialized
INFO - 2024-05-20 18:21:02 --> Language Class Initialized
INFO - 2024-05-20 18:21:02 --> Loader Class Initialized
INFO - 2024-05-20 18:21:02 --> Helper loaded: url_helper
INFO - 2024-05-20 18:21:02 --> Helper loaded: file_helper
INFO - 2024-05-20 18:21:02 --> Helper loaded: html_helper
INFO - 2024-05-20 18:21:02 --> Helper loaded: text_helper
INFO - 2024-05-20 18:21:02 --> Helper loaded: form_helper
INFO - 2024-05-20 18:21:02 --> Helper loaded: lang_helper
INFO - 2024-05-20 18:21:02 --> Helper loaded: security_helper
INFO - 2024-05-20 18:21:02 --> Helper loaded: cookie_helper
INFO - 2024-05-20 18:21:02 --> Database Driver Class Initialized
INFO - 2024-05-20 18:21:02 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-20 18:21:02 --> Parser Class Initialized
INFO - 2024-05-20 18:21:02 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-05-20 18:21:02 --> Pagination Class Initialized
INFO - 2024-05-20 18:21:02 --> Form Validation Class Initialized
INFO - 2024-05-20 18:21:02 --> Controller Class Initialized
INFO - 2024-05-20 18:21:02 --> Model Class Initialized
DEBUG - 2024-05-20 18:21:02 --> Session class already loaded. Second attempt ignored.
ERROR - 2024-05-20 18:21:03 --> $config['composer_autoload'] is set to TRUE but /home/u241458058/domains/technoprimex.com/public_html/maurnaturo/application/vendor/autoload.php was not found.
INFO - 2024-05-20 18:21:03 --> Config Class Initialized
INFO - 2024-05-20 18:21:03 --> Hooks Class Initialized
DEBUG - 2024-05-20 18:21:03 --> UTF-8 Support Enabled
INFO - 2024-05-20 18:21:03 --> Utf8 Class Initialized
INFO - 2024-05-20 18:21:03 --> URI Class Initialized
INFO - 2024-05-20 18:21:03 --> Router Class Initialized
INFO - 2024-05-20 18:21:03 --> Output Class Initialized
INFO - 2024-05-20 18:21:03 --> Security Class Initialized
DEBUG - 2024-05-20 18:21:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-20 18:21:03 --> Input Class Initialized
INFO - 2024-05-20 18:21:03 --> Language Class Initialized
INFO - 2024-05-20 18:21:03 --> Loader Class Initialized
INFO - 2024-05-20 18:21:03 --> Helper loaded: url_helper
INFO - 2024-05-20 18:21:03 --> Helper loaded: file_helper
INFO - 2024-05-20 18:21:03 --> Helper loaded: html_helper
INFO - 2024-05-20 18:21:03 --> Helper loaded: text_helper
INFO - 2024-05-20 18:21:03 --> Helper loaded: form_helper
INFO - 2024-05-20 18:21:03 --> Helper loaded: lang_helper
INFO - 2024-05-20 18:21:03 --> Helper loaded: security_helper
INFO - 2024-05-20 18:21:03 --> Helper loaded: cookie_helper
INFO - 2024-05-20 18:21:03 --> Database Driver Class Initialized
INFO - 2024-05-20 18:21:03 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-20 18:21:03 --> Parser Class Initialized
INFO - 2024-05-20 18:21:03 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-05-20 18:21:03 --> Pagination Class Initialized
INFO - 2024-05-20 18:21:03 --> Form Validation Class Initialized
INFO - 2024-05-20 18:21:03 --> Controller Class Initialized
INFO - 2024-05-20 18:21:03 --> Model Class Initialized
DEBUG - 2024-05-20 18:21:03 --> Session class already loaded. Second attempt ignored.
INFO - 2024-05-20 18:21:03 --> File loaded: /home/u241458058/domains/technoprimex.com/public_html/maurnaturo/application/views/user/admin_login_form.php
DEBUG - 2024-05-20 18:21:03 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-05-20 18:21:03 --> File loaded: /home/u241458058/domains/technoprimex.com/public_html/maurnaturo/application/views/include/top_menu.php
INFO - 2024-05-20 18:21:03 --> File loaded: /home/u241458058/domains/technoprimex.com/public_html/maurnaturo/application/views/include/admin_loggedin_info.php
INFO - 2024-05-20 18:21:03 --> Model Class Initialized
INFO - 2024-05-20 18:21:03 --> File loaded: /home/u241458058/domains/technoprimex.com/public_html/maurnaturo/application/views/admin_html_template.php
INFO - 2024-05-20 18:21:03 --> Final output sent to browser
DEBUG - 2024-05-20 18:21:03 --> Total execution time: 0.0237
ERROR - 2024-05-20 18:27:05 --> $config['composer_autoload'] is set to TRUE but /home/u241458058/domains/technoprimex.com/public_html/maurnaturo/application/vendor/autoload.php was not found.
INFO - 2024-05-20 18:27:05 --> Config Class Initialized
INFO - 2024-05-20 18:27:05 --> Hooks Class Initialized
DEBUG - 2024-05-20 18:27:05 --> UTF-8 Support Enabled
INFO - 2024-05-20 18:27:05 --> Utf8 Class Initialized
INFO - 2024-05-20 18:27:05 --> URI Class Initialized
DEBUG - 2024-05-20 18:27:05 --> No URI present. Default controller set.
INFO - 2024-05-20 18:27:05 --> Router Class Initialized
INFO - 2024-05-20 18:27:05 --> Output Class Initialized
INFO - 2024-05-20 18:27:05 --> Security Class Initialized
DEBUG - 2024-05-20 18:27:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-20 18:27:05 --> Input Class Initialized
INFO - 2024-05-20 18:27:05 --> Language Class Initialized
INFO - 2024-05-20 18:27:05 --> Loader Class Initialized
INFO - 2024-05-20 18:27:05 --> Helper loaded: url_helper
INFO - 2024-05-20 18:27:05 --> Helper loaded: file_helper
INFO - 2024-05-20 18:27:05 --> Helper loaded: html_helper
INFO - 2024-05-20 18:27:05 --> Helper loaded: text_helper
INFO - 2024-05-20 18:27:05 --> Helper loaded: form_helper
INFO - 2024-05-20 18:27:05 --> Helper loaded: lang_helper
INFO - 2024-05-20 18:27:05 --> Helper loaded: security_helper
INFO - 2024-05-20 18:27:05 --> Helper loaded: cookie_helper
INFO - 2024-05-20 18:27:05 --> Database Driver Class Initialized
INFO - 2024-05-20 18:27:05 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-20 18:27:05 --> Parser Class Initialized
INFO - 2024-05-20 18:27:05 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-05-20 18:27:05 --> Pagination Class Initialized
INFO - 2024-05-20 18:27:05 --> Form Validation Class Initialized
INFO - 2024-05-20 18:27:05 --> Controller Class Initialized
INFO - 2024-05-20 18:27:05 --> Model Class Initialized
DEBUG - 2024-05-20 18:27:05 --> Session class already loaded. Second attempt ignored.
ERROR - 2024-05-20 19:20:14 --> $config['composer_autoload'] is set to TRUE but /home/u241458058/domains/technoprimex.com/public_html/maurnaturo/application/vendor/autoload.php was not found.
INFO - 2024-05-20 19:20:14 --> Config Class Initialized
INFO - 2024-05-20 19:20:14 --> Hooks Class Initialized
DEBUG - 2024-05-20 19:20:14 --> UTF-8 Support Enabled
INFO - 2024-05-20 19:20:14 --> Utf8 Class Initialized
INFO - 2024-05-20 19:20:14 --> URI Class Initialized
DEBUG - 2024-05-20 19:20:14 --> No URI present. Default controller set.
INFO - 2024-05-20 19:20:14 --> Router Class Initialized
INFO - 2024-05-20 19:20:14 --> Output Class Initialized
INFO - 2024-05-20 19:20:14 --> Security Class Initialized
DEBUG - 2024-05-20 19:20:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-20 19:20:14 --> Input Class Initialized
INFO - 2024-05-20 19:20:14 --> Language Class Initialized
INFO - 2024-05-20 19:20:14 --> Loader Class Initialized
INFO - 2024-05-20 19:20:14 --> Helper loaded: url_helper
INFO - 2024-05-20 19:20:14 --> Helper loaded: file_helper
INFO - 2024-05-20 19:20:14 --> Helper loaded: html_helper
INFO - 2024-05-20 19:20:14 --> Helper loaded: text_helper
INFO - 2024-05-20 19:20:14 --> Helper loaded: form_helper
INFO - 2024-05-20 19:20:14 --> Helper loaded: lang_helper
INFO - 2024-05-20 19:20:14 --> Helper loaded: security_helper
INFO - 2024-05-20 19:20:14 --> Helper loaded: cookie_helper
INFO - 2024-05-20 19:20:14 --> Database Driver Class Initialized
INFO - 2024-05-20 19:20:14 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-20 19:20:14 --> Parser Class Initialized
INFO - 2024-05-20 19:20:14 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-05-20 19:20:14 --> Pagination Class Initialized
INFO - 2024-05-20 19:20:14 --> Form Validation Class Initialized
INFO - 2024-05-20 19:20:14 --> Controller Class Initialized
INFO - 2024-05-20 19:20:14 --> Model Class Initialized
DEBUG - 2024-05-20 19:20:14 --> Session class already loaded. Second attempt ignored.
ERROR - 2024-05-20 19:20:14 --> $config['composer_autoload'] is set to TRUE but /home/u241458058/domains/technoprimex.com/public_html/maurnaturo/application/vendor/autoload.php was not found.
INFO - 2024-05-20 19:20:14 --> Config Class Initialized
INFO - 2024-05-20 19:20:14 --> Hooks Class Initialized
DEBUG - 2024-05-20 19:20:14 --> UTF-8 Support Enabled
INFO - 2024-05-20 19:20:14 --> Utf8 Class Initialized
INFO - 2024-05-20 19:20:14 --> URI Class Initialized
INFO - 2024-05-20 19:20:14 --> Router Class Initialized
INFO - 2024-05-20 19:20:14 --> Output Class Initialized
INFO - 2024-05-20 19:20:14 --> Security Class Initialized
DEBUG - 2024-05-20 19:20:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-20 19:20:14 --> Input Class Initialized
INFO - 2024-05-20 19:20:14 --> Language Class Initialized
INFO - 2024-05-20 19:20:14 --> Loader Class Initialized
INFO - 2024-05-20 19:20:14 --> Helper loaded: url_helper
INFO - 2024-05-20 19:20:14 --> Helper loaded: file_helper
INFO - 2024-05-20 19:20:14 --> Helper loaded: html_helper
INFO - 2024-05-20 19:20:14 --> Helper loaded: text_helper
INFO - 2024-05-20 19:20:14 --> Helper loaded: form_helper
INFO - 2024-05-20 19:20:14 --> Helper loaded: lang_helper
INFO - 2024-05-20 19:20:14 --> Helper loaded: security_helper
INFO - 2024-05-20 19:20:14 --> Helper loaded: cookie_helper
INFO - 2024-05-20 19:20:14 --> Database Driver Class Initialized
INFO - 2024-05-20 19:20:14 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-20 19:20:14 --> Parser Class Initialized
INFO - 2024-05-20 19:20:14 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-05-20 19:20:14 --> Pagination Class Initialized
INFO - 2024-05-20 19:20:14 --> Form Validation Class Initialized
INFO - 2024-05-20 19:20:14 --> Controller Class Initialized
INFO - 2024-05-20 19:20:14 --> Model Class Initialized
DEBUG - 2024-05-20 19:20:14 --> Session class already loaded. Second attempt ignored.
INFO - 2024-05-20 19:20:14 --> File loaded: /home/u241458058/domains/technoprimex.com/public_html/maurnaturo/application/views/user/admin_login_form.php
DEBUG - 2024-05-20 19:20:14 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-05-20 19:20:14 --> File loaded: /home/u241458058/domains/technoprimex.com/public_html/maurnaturo/application/views/include/top_menu.php
INFO - 2024-05-20 19:20:14 --> File loaded: /home/u241458058/domains/technoprimex.com/public_html/maurnaturo/application/views/include/admin_loggedin_info.php
INFO - 2024-05-20 19:20:14 --> Model Class Initialized
INFO - 2024-05-20 19:20:14 --> File loaded: /home/u241458058/domains/technoprimex.com/public_html/maurnaturo/application/views/admin_html_template.php
INFO - 2024-05-20 19:20:14 --> Final output sent to browser
DEBUG - 2024-05-20 19:20:14 --> Total execution time: 0.0270
ERROR - 2024-05-20 19:20:15 --> $config['composer_autoload'] is set to TRUE but /home/u241458058/domains/technoprimex.com/public_html/maurnaturo/application/vendor/autoload.php was not found.
INFO - 2024-05-20 19:20:15 --> Config Class Initialized
INFO - 2024-05-20 19:20:15 --> Hooks Class Initialized
DEBUG - 2024-05-20 19:20:15 --> UTF-8 Support Enabled
INFO - 2024-05-20 19:20:15 --> Utf8 Class Initialized
INFO - 2024-05-20 19:20:15 --> URI Class Initialized
DEBUG - 2024-05-20 19:20:15 --> No URI present. Default controller set.
INFO - 2024-05-20 19:20:15 --> Router Class Initialized
INFO - 2024-05-20 19:20:15 --> Output Class Initialized
INFO - 2024-05-20 19:20:15 --> Security Class Initialized
DEBUG - 2024-05-20 19:20:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-20 19:20:15 --> Input Class Initialized
INFO - 2024-05-20 19:20:15 --> Language Class Initialized
INFO - 2024-05-20 19:20:15 --> Loader Class Initialized
INFO - 2024-05-20 19:20:15 --> Helper loaded: url_helper
INFO - 2024-05-20 19:20:15 --> Helper loaded: file_helper
INFO - 2024-05-20 19:20:15 --> Helper loaded: html_helper
INFO - 2024-05-20 19:20:15 --> Helper loaded: text_helper
INFO - 2024-05-20 19:20:15 --> Helper loaded: form_helper
INFO - 2024-05-20 19:20:15 --> Helper loaded: lang_helper
INFO - 2024-05-20 19:20:15 --> Helper loaded: security_helper
INFO - 2024-05-20 19:20:15 --> Helper loaded: cookie_helper
INFO - 2024-05-20 19:20:15 --> Database Driver Class Initialized
INFO - 2024-05-20 19:20:15 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-20 19:20:15 --> Parser Class Initialized
INFO - 2024-05-20 19:20:15 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-05-20 19:20:15 --> Pagination Class Initialized
INFO - 2024-05-20 19:20:15 --> Form Validation Class Initialized
INFO - 2024-05-20 19:20:15 --> Controller Class Initialized
INFO - 2024-05-20 19:20:15 --> Model Class Initialized
DEBUG - 2024-05-20 19:20:15 --> Session class already loaded. Second attempt ignored.
ERROR - 2024-05-20 19:20:15 --> $config['composer_autoload'] is set to TRUE but /home/u241458058/domains/technoprimex.com/public_html/maurnaturo/application/vendor/autoload.php was not found.
INFO - 2024-05-20 19:20:15 --> Config Class Initialized
INFO - 2024-05-20 19:20:15 --> Hooks Class Initialized
DEBUG - 2024-05-20 19:20:15 --> UTF-8 Support Enabled
INFO - 2024-05-20 19:20:15 --> Utf8 Class Initialized
INFO - 2024-05-20 19:20:15 --> URI Class Initialized
INFO - 2024-05-20 19:20:15 --> Router Class Initialized
INFO - 2024-05-20 19:20:15 --> Output Class Initialized
INFO - 2024-05-20 19:20:15 --> Security Class Initialized
DEBUG - 2024-05-20 19:20:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-20 19:20:15 --> Input Class Initialized
INFO - 2024-05-20 19:20:15 --> Language Class Initialized
INFO - 2024-05-20 19:20:15 --> Loader Class Initialized
INFO - 2024-05-20 19:20:15 --> Helper loaded: url_helper
INFO - 2024-05-20 19:20:15 --> Helper loaded: file_helper
INFO - 2024-05-20 19:20:15 --> Helper loaded: html_helper
INFO - 2024-05-20 19:20:15 --> Helper loaded: text_helper
INFO - 2024-05-20 19:20:15 --> Helper loaded: form_helper
INFO - 2024-05-20 19:20:15 --> Helper loaded: lang_helper
INFO - 2024-05-20 19:20:15 --> Helper loaded: security_helper
INFO - 2024-05-20 19:20:15 --> Helper loaded: cookie_helper
INFO - 2024-05-20 19:20:15 --> Database Driver Class Initialized
INFO - 2024-05-20 19:20:15 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-20 19:20:15 --> Parser Class Initialized
INFO - 2024-05-20 19:20:15 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-05-20 19:20:15 --> Pagination Class Initialized
INFO - 2024-05-20 19:20:15 --> Form Validation Class Initialized
INFO - 2024-05-20 19:20:15 --> Controller Class Initialized
INFO - 2024-05-20 19:20:15 --> Model Class Initialized
DEBUG - 2024-05-20 19:20:15 --> Session class already loaded. Second attempt ignored.
INFO - 2024-05-20 19:20:15 --> File loaded: /home/u241458058/domains/technoprimex.com/public_html/maurnaturo/application/views/user/admin_login_form.php
DEBUG - 2024-05-20 19:20:15 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-05-20 19:20:15 --> File loaded: /home/u241458058/domains/technoprimex.com/public_html/maurnaturo/application/views/include/top_menu.php
INFO - 2024-05-20 19:20:15 --> File loaded: /home/u241458058/domains/technoprimex.com/public_html/maurnaturo/application/views/include/admin_loggedin_info.php
INFO - 2024-05-20 19:20:15 --> Model Class Initialized
INFO - 2024-05-20 19:20:15 --> File loaded: /home/u241458058/domains/technoprimex.com/public_html/maurnaturo/application/views/admin_html_template.php
INFO - 2024-05-20 19:20:15 --> Final output sent to browser
DEBUG - 2024-05-20 19:20:15 --> Total execution time: 0.0190
ERROR - 2024-05-20 19:46:58 --> $config['composer_autoload'] is set to TRUE but /home/u241458058/domains/technoprimex.com/public_html/maurnaturo/application/vendor/autoload.php was not found.
INFO - 2024-05-20 19:46:58 --> Config Class Initialized
INFO - 2024-05-20 19:46:58 --> Hooks Class Initialized
DEBUG - 2024-05-20 19:46:58 --> UTF-8 Support Enabled
INFO - 2024-05-20 19:46:58 --> Utf8 Class Initialized
INFO - 2024-05-20 19:46:58 --> URI Class Initialized
DEBUG - 2024-05-20 19:46:58 --> No URI present. Default controller set.
INFO - 2024-05-20 19:46:58 --> Router Class Initialized
INFO - 2024-05-20 19:46:58 --> Output Class Initialized
INFO - 2024-05-20 19:46:58 --> Security Class Initialized
DEBUG - 2024-05-20 19:46:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-20 19:46:58 --> Input Class Initialized
INFO - 2024-05-20 19:46:58 --> Language Class Initialized
INFO - 2024-05-20 19:46:58 --> Loader Class Initialized
INFO - 2024-05-20 19:46:58 --> Helper loaded: url_helper
INFO - 2024-05-20 19:46:58 --> Helper loaded: file_helper
INFO - 2024-05-20 19:46:58 --> Helper loaded: html_helper
INFO - 2024-05-20 19:46:58 --> Helper loaded: text_helper
INFO - 2024-05-20 19:46:58 --> Helper loaded: form_helper
INFO - 2024-05-20 19:46:58 --> Helper loaded: lang_helper
INFO - 2024-05-20 19:46:58 --> Helper loaded: security_helper
INFO - 2024-05-20 19:46:58 --> Helper loaded: cookie_helper
INFO - 2024-05-20 19:46:58 --> Database Driver Class Initialized
INFO - 2024-05-20 19:46:58 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-20 19:46:58 --> Parser Class Initialized
INFO - 2024-05-20 19:46:58 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-05-20 19:46:58 --> Pagination Class Initialized
INFO - 2024-05-20 19:46:58 --> Form Validation Class Initialized
INFO - 2024-05-20 19:46:58 --> Controller Class Initialized
INFO - 2024-05-20 19:46:58 --> Model Class Initialized
DEBUG - 2024-05-20 19:46:58 --> Session class already loaded. Second attempt ignored.
ERROR - 2024-05-20 19:46:58 --> $config['composer_autoload'] is set to TRUE but /home/u241458058/domains/technoprimex.com/public_html/maurnaturo/application/vendor/autoload.php was not found.
INFO - 2024-05-20 19:46:58 --> Config Class Initialized
INFO - 2024-05-20 19:46:58 --> Hooks Class Initialized
DEBUG - 2024-05-20 19:46:58 --> UTF-8 Support Enabled
INFO - 2024-05-20 19:46:58 --> Utf8 Class Initialized
INFO - 2024-05-20 19:46:58 --> URI Class Initialized
DEBUG - 2024-05-20 19:46:58 --> No URI present. Default controller set.
INFO - 2024-05-20 19:46:58 --> Router Class Initialized
INFO - 2024-05-20 19:46:58 --> Output Class Initialized
INFO - 2024-05-20 19:46:58 --> Security Class Initialized
DEBUG - 2024-05-20 19:46:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-20 19:46:58 --> Input Class Initialized
INFO - 2024-05-20 19:46:58 --> Language Class Initialized
INFO - 2024-05-20 19:46:58 --> Loader Class Initialized
INFO - 2024-05-20 19:46:58 --> Helper loaded: url_helper
INFO - 2024-05-20 19:46:58 --> Helper loaded: file_helper
INFO - 2024-05-20 19:46:58 --> Helper loaded: html_helper
INFO - 2024-05-20 19:46:58 --> Helper loaded: text_helper
INFO - 2024-05-20 19:46:58 --> Helper loaded: form_helper
INFO - 2024-05-20 19:46:58 --> Helper loaded: lang_helper
INFO - 2024-05-20 19:46:58 --> Helper loaded: security_helper
INFO - 2024-05-20 19:46:58 --> Helper loaded: cookie_helper
INFO - 2024-05-20 19:46:58 --> Database Driver Class Initialized
INFO - 2024-05-20 19:46:58 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-20 19:46:58 --> Parser Class Initialized
INFO - 2024-05-20 19:46:58 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-05-20 19:46:58 --> Pagination Class Initialized
INFO - 2024-05-20 19:46:58 --> Form Validation Class Initialized
INFO - 2024-05-20 19:46:58 --> Controller Class Initialized
INFO - 2024-05-20 19:46:58 --> Model Class Initialized
DEBUG - 2024-05-20 19:46:58 --> Session class already loaded. Second attempt ignored.
ERROR - 2024-05-20 19:46:59 --> $config['composer_autoload'] is set to TRUE but /home/u241458058/domains/technoprimex.com/public_html/maurnaturo/application/vendor/autoload.php was not found.
INFO - 2024-05-20 19:46:59 --> Config Class Initialized
INFO - 2024-05-20 19:46:59 --> Hooks Class Initialized
DEBUG - 2024-05-20 19:46:59 --> UTF-8 Support Enabled
INFO - 2024-05-20 19:46:59 --> Utf8 Class Initialized
INFO - 2024-05-20 19:46:59 --> URI Class Initialized
DEBUG - 2024-05-20 19:46:59 --> No URI present. Default controller set.
INFO - 2024-05-20 19:46:59 --> Router Class Initialized
INFO - 2024-05-20 19:46:59 --> Output Class Initialized
INFO - 2024-05-20 19:46:59 --> Security Class Initialized
DEBUG - 2024-05-20 19:46:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-20 19:46:59 --> Input Class Initialized
INFO - 2024-05-20 19:46:59 --> Language Class Initialized
INFO - 2024-05-20 19:46:59 --> Loader Class Initialized
INFO - 2024-05-20 19:46:59 --> Helper loaded: url_helper
INFO - 2024-05-20 19:46:59 --> Helper loaded: file_helper
INFO - 2024-05-20 19:46:59 --> Helper loaded: html_helper
INFO - 2024-05-20 19:46:59 --> Helper loaded: text_helper
INFO - 2024-05-20 19:46:59 --> Helper loaded: form_helper
INFO - 2024-05-20 19:46:59 --> Helper loaded: lang_helper
INFO - 2024-05-20 19:46:59 --> Helper loaded: security_helper
INFO - 2024-05-20 19:46:59 --> Helper loaded: cookie_helper
INFO - 2024-05-20 19:46:59 --> Database Driver Class Initialized
INFO - 2024-05-20 19:46:59 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-20 19:46:59 --> Parser Class Initialized
INFO - 2024-05-20 19:46:59 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-05-20 19:46:59 --> Pagination Class Initialized
INFO - 2024-05-20 19:46:59 --> Form Validation Class Initialized
INFO - 2024-05-20 19:46:59 --> Controller Class Initialized
INFO - 2024-05-20 19:46:59 --> Model Class Initialized
DEBUG - 2024-05-20 19:46:59 --> Session class already loaded. Second attempt ignored.
ERROR - 2024-05-20 19:47:13 --> $config['composer_autoload'] is set to TRUE but /home/u241458058/domains/technoprimex.com/public_html/maurnaturo/application/vendor/autoload.php was not found.
INFO - 2024-05-20 19:47:13 --> Config Class Initialized
INFO - 2024-05-20 19:47:13 --> Hooks Class Initialized
DEBUG - 2024-05-20 19:47:13 --> UTF-8 Support Enabled
INFO - 2024-05-20 19:47:13 --> Utf8 Class Initialized
INFO - 2024-05-20 19:47:13 --> URI Class Initialized
DEBUG - 2024-05-20 19:47:13 --> No URI present. Default controller set.
INFO - 2024-05-20 19:47:13 --> Router Class Initialized
INFO - 2024-05-20 19:47:13 --> Output Class Initialized
INFO - 2024-05-20 19:47:13 --> Security Class Initialized
DEBUG - 2024-05-20 19:47:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-20 19:47:13 --> Input Class Initialized
INFO - 2024-05-20 19:47:13 --> Language Class Initialized
INFO - 2024-05-20 19:47:13 --> Loader Class Initialized
INFO - 2024-05-20 19:47:13 --> Helper loaded: url_helper
INFO - 2024-05-20 19:47:13 --> Helper loaded: file_helper
INFO - 2024-05-20 19:47:13 --> Helper loaded: html_helper
INFO - 2024-05-20 19:47:13 --> Helper loaded: text_helper
INFO - 2024-05-20 19:47:13 --> Helper loaded: form_helper
INFO - 2024-05-20 19:47:13 --> Helper loaded: lang_helper
INFO - 2024-05-20 19:47:13 --> Helper loaded: security_helper
INFO - 2024-05-20 19:47:13 --> Helper loaded: cookie_helper
INFO - 2024-05-20 19:47:13 --> Database Driver Class Initialized
INFO - 2024-05-20 19:47:13 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-20 19:47:13 --> Parser Class Initialized
INFO - 2024-05-20 19:47:13 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-05-20 19:47:13 --> Pagination Class Initialized
INFO - 2024-05-20 19:47:13 --> Form Validation Class Initialized
INFO - 2024-05-20 19:47:13 --> Controller Class Initialized
INFO - 2024-05-20 19:47:13 --> Model Class Initialized
DEBUG - 2024-05-20 19:47:13 --> Session class already loaded. Second attempt ignored.
ERROR - 2024-05-20 19:49:31 --> $config['composer_autoload'] is set to TRUE but /home/u241458058/domains/technoprimex.com/public_html/maurnaturo/application/vendor/autoload.php was not found.
INFO - 2024-05-20 19:49:31 --> Config Class Initialized
INFO - 2024-05-20 19:49:31 --> Hooks Class Initialized
DEBUG - 2024-05-20 19:49:31 --> UTF-8 Support Enabled
INFO - 2024-05-20 19:49:31 --> Utf8 Class Initialized
INFO - 2024-05-20 19:49:31 --> URI Class Initialized
INFO - 2024-05-20 19:49:31 --> Router Class Initialized
INFO - 2024-05-20 19:49:31 --> Output Class Initialized
INFO - 2024-05-20 19:49:31 --> Security Class Initialized
DEBUG - 2024-05-20 19:49:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-20 19:49:31 --> Input Class Initialized
INFO - 2024-05-20 19:49:31 --> Language Class Initialized
INFO - 2024-05-20 19:49:31 --> Loader Class Initialized
INFO - 2024-05-20 19:49:31 --> Helper loaded: url_helper
INFO - 2024-05-20 19:49:31 --> Helper loaded: file_helper
INFO - 2024-05-20 19:49:31 --> Helper loaded: html_helper
INFO - 2024-05-20 19:49:31 --> Helper loaded: text_helper
INFO - 2024-05-20 19:49:31 --> Helper loaded: form_helper
INFO - 2024-05-20 19:49:31 --> Helper loaded: lang_helper
INFO - 2024-05-20 19:49:31 --> Helper loaded: security_helper
INFO - 2024-05-20 19:49:31 --> Helper loaded: cookie_helper
INFO - 2024-05-20 19:49:31 --> Database Driver Class Initialized
INFO - 2024-05-20 19:49:31 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-20 19:49:31 --> Parser Class Initialized
INFO - 2024-05-20 19:49:31 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-05-20 19:49:31 --> Pagination Class Initialized
INFO - 2024-05-20 19:49:31 --> Form Validation Class Initialized
INFO - 2024-05-20 19:49:31 --> Controller Class Initialized
INFO - 2024-05-20 19:49:31 --> Model Class Initialized
DEBUG - 2024-05-20 19:49:31 --> Session class already loaded. Second attempt ignored.
INFO - 2024-05-20 19:49:31 --> File loaded: /home/u241458058/domains/technoprimex.com/public_html/maurnaturo/application/views/user/admin_login_form.php
DEBUG - 2024-05-20 19:49:31 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-05-20 19:49:31 --> File loaded: /home/u241458058/domains/technoprimex.com/public_html/maurnaturo/application/views/include/top_menu.php
INFO - 2024-05-20 19:49:31 --> File loaded: /home/u241458058/domains/technoprimex.com/public_html/maurnaturo/application/views/include/admin_loggedin_info.php
INFO - 2024-05-20 19:49:31 --> Model Class Initialized
INFO - 2024-05-20 19:49:31 --> File loaded: /home/u241458058/domains/technoprimex.com/public_html/maurnaturo/application/views/admin_html_template.php
INFO - 2024-05-20 19:49:31 --> Final output sent to browser
DEBUG - 2024-05-20 19:49:31 --> Total execution time: 0.0232
ERROR - 2024-05-20 20:33:03 --> $config['composer_autoload'] is set to TRUE but /home/u241458058/domains/technoprimex.com/public_html/maurnaturo/application/vendor/autoload.php was not found.
INFO - 2024-05-20 20:33:03 --> Config Class Initialized
INFO - 2024-05-20 20:33:03 --> Hooks Class Initialized
DEBUG - 2024-05-20 20:33:03 --> UTF-8 Support Enabled
INFO - 2024-05-20 20:33:03 --> Utf8 Class Initialized
INFO - 2024-05-20 20:33:03 --> URI Class Initialized
DEBUG - 2024-05-20 20:33:03 --> No URI present. Default controller set.
INFO - 2024-05-20 20:33:03 --> Router Class Initialized
INFO - 2024-05-20 20:33:03 --> Output Class Initialized
INFO - 2024-05-20 20:33:03 --> Security Class Initialized
DEBUG - 2024-05-20 20:33:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-20 20:33:03 --> Input Class Initialized
INFO - 2024-05-20 20:33:03 --> Language Class Initialized
INFO - 2024-05-20 20:33:03 --> Loader Class Initialized
INFO - 2024-05-20 20:33:03 --> Helper loaded: url_helper
INFO - 2024-05-20 20:33:03 --> Helper loaded: file_helper
INFO - 2024-05-20 20:33:03 --> Helper loaded: html_helper
INFO - 2024-05-20 20:33:03 --> Helper loaded: text_helper
INFO - 2024-05-20 20:33:03 --> Helper loaded: form_helper
INFO - 2024-05-20 20:33:03 --> Helper loaded: lang_helper
INFO - 2024-05-20 20:33:03 --> Helper loaded: security_helper
INFO - 2024-05-20 20:33:03 --> Helper loaded: cookie_helper
INFO - 2024-05-20 20:33:03 --> Database Driver Class Initialized
INFO - 2024-05-20 20:33:03 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-20 20:33:03 --> Parser Class Initialized
INFO - 2024-05-20 20:33:03 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-05-20 20:33:03 --> Pagination Class Initialized
INFO - 2024-05-20 20:33:03 --> Form Validation Class Initialized
INFO - 2024-05-20 20:33:03 --> Controller Class Initialized
INFO - 2024-05-20 20:33:03 --> Model Class Initialized
DEBUG - 2024-05-20 20:33:03 --> Session class already loaded. Second attempt ignored.
ERROR - 2024-05-20 20:33:43 --> $config['composer_autoload'] is set to TRUE but /home/u241458058/domains/technoprimex.com/public_html/maurnaturo/application/vendor/autoload.php was not found.
INFO - 2024-05-20 20:33:43 --> Config Class Initialized
INFO - 2024-05-20 20:33:43 --> Hooks Class Initialized
DEBUG - 2024-05-20 20:33:43 --> UTF-8 Support Enabled
INFO - 2024-05-20 20:33:43 --> Utf8 Class Initialized
INFO - 2024-05-20 20:33:43 --> URI Class Initialized
DEBUG - 2024-05-20 20:33:43 --> No URI present. Default controller set.
INFO - 2024-05-20 20:33:43 --> Router Class Initialized
INFO - 2024-05-20 20:33:43 --> Output Class Initialized
INFO - 2024-05-20 20:33:43 --> Security Class Initialized
DEBUG - 2024-05-20 20:33:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-20 20:33:43 --> Input Class Initialized
INFO - 2024-05-20 20:33:43 --> Language Class Initialized
INFO - 2024-05-20 20:33:43 --> Loader Class Initialized
INFO - 2024-05-20 20:33:43 --> Helper loaded: url_helper
INFO - 2024-05-20 20:33:43 --> Helper loaded: file_helper
INFO - 2024-05-20 20:33:43 --> Helper loaded: html_helper
INFO - 2024-05-20 20:33:43 --> Helper loaded: text_helper
INFO - 2024-05-20 20:33:43 --> Helper loaded: form_helper
INFO - 2024-05-20 20:33:43 --> Helper loaded: lang_helper
INFO - 2024-05-20 20:33:43 --> Helper loaded: security_helper
INFO - 2024-05-20 20:33:43 --> Helper loaded: cookie_helper
INFO - 2024-05-20 20:33:43 --> Database Driver Class Initialized
INFO - 2024-05-20 20:33:43 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-20 20:33:43 --> Parser Class Initialized
INFO - 2024-05-20 20:33:43 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-05-20 20:33:43 --> Pagination Class Initialized
INFO - 2024-05-20 20:33:43 --> Form Validation Class Initialized
INFO - 2024-05-20 20:33:43 --> Controller Class Initialized
INFO - 2024-05-20 20:33:43 --> Model Class Initialized
DEBUG - 2024-05-20 20:33:43 --> Session class already loaded. Second attempt ignored.
ERROR - 2024-05-20 20:33:45 --> $config['composer_autoload'] is set to TRUE but /home/u241458058/domains/technoprimex.com/public_html/maurnaturo/application/vendor/autoload.php was not found.
INFO - 2024-05-20 20:33:45 --> Config Class Initialized
INFO - 2024-05-20 20:33:45 --> Hooks Class Initialized
DEBUG - 2024-05-20 20:33:45 --> UTF-8 Support Enabled
INFO - 2024-05-20 20:33:45 --> Utf8 Class Initialized
INFO - 2024-05-20 20:33:45 --> URI Class Initialized
DEBUG - 2024-05-20 20:33:45 --> No URI present. Default controller set.
INFO - 2024-05-20 20:33:45 --> Router Class Initialized
INFO - 2024-05-20 20:33:45 --> Output Class Initialized
INFO - 2024-05-20 20:33:45 --> Security Class Initialized
DEBUG - 2024-05-20 20:33:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-20 20:33:45 --> Input Class Initialized
INFO - 2024-05-20 20:33:45 --> Language Class Initialized
INFO - 2024-05-20 20:33:45 --> Loader Class Initialized
INFO - 2024-05-20 20:33:45 --> Helper loaded: url_helper
INFO - 2024-05-20 20:33:45 --> Helper loaded: file_helper
INFO - 2024-05-20 20:33:45 --> Helper loaded: html_helper
INFO - 2024-05-20 20:33:45 --> Helper loaded: text_helper
INFO - 2024-05-20 20:33:45 --> Helper loaded: form_helper
INFO - 2024-05-20 20:33:45 --> Helper loaded: lang_helper
INFO - 2024-05-20 20:33:45 --> Helper loaded: security_helper
INFO - 2024-05-20 20:33:45 --> Helper loaded: cookie_helper
INFO - 2024-05-20 20:33:45 --> Database Driver Class Initialized
INFO - 2024-05-20 20:33:45 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-20 20:33:45 --> Parser Class Initialized
INFO - 2024-05-20 20:33:45 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-05-20 20:33:45 --> Pagination Class Initialized
INFO - 2024-05-20 20:33:45 --> Form Validation Class Initialized
INFO - 2024-05-20 20:33:45 --> Controller Class Initialized
INFO - 2024-05-20 20:33:45 --> Model Class Initialized
DEBUG - 2024-05-20 20:33:45 --> Session class already loaded. Second attempt ignored.
