<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2024-05-22 01:31:01 --> $config['composer_autoload'] is set to TRUE but /home/u241458058/domains/technoprimex.com/public_html/maurnaturo/application/vendor/autoload.php was not found.
INFO - 2024-05-22 01:31:01 --> Config Class Initialized
INFO - 2024-05-22 01:31:01 --> Hooks Class Initialized
DEBUG - 2024-05-22 01:31:01 --> UTF-8 Support Enabled
INFO - 2024-05-22 01:31:01 --> Utf8 Class Initialized
INFO - 2024-05-22 01:31:01 --> URI Class Initialized
DEBUG - 2024-05-22 01:31:01 --> No URI present. Default controller set.
INFO - 2024-05-22 01:31:01 --> Router Class Initialized
INFO - 2024-05-22 01:31:01 --> Output Class Initialized
INFO - 2024-05-22 01:31:01 --> Security Class Initialized
DEBUG - 2024-05-22 01:31:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-22 01:31:01 --> Input Class Initialized
INFO - 2024-05-22 01:31:01 --> Language Class Initialized
INFO - 2024-05-22 01:31:01 --> Loader Class Initialized
INFO - 2024-05-22 01:31:01 --> Helper loaded: url_helper
INFO - 2024-05-22 01:31:01 --> Helper loaded: file_helper
INFO - 2024-05-22 01:31:01 --> Helper loaded: html_helper
INFO - 2024-05-22 01:31:01 --> Helper loaded: text_helper
INFO - 2024-05-22 01:31:01 --> Helper loaded: form_helper
INFO - 2024-05-22 01:31:01 --> Helper loaded: lang_helper
INFO - 2024-05-22 01:31:01 --> Helper loaded: security_helper
INFO - 2024-05-22 01:31:01 --> Helper loaded: cookie_helper
INFO - 2024-05-22 01:31:01 --> Database Driver Class Initialized
INFO - 2024-05-22 01:31:01 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-22 01:31:01 --> Parser Class Initialized
INFO - 2024-05-22 01:31:01 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-05-22 01:31:01 --> Pagination Class Initialized
INFO - 2024-05-22 01:31:01 --> Form Validation Class Initialized
INFO - 2024-05-22 01:31:01 --> Controller Class Initialized
INFO - 2024-05-22 01:31:01 --> Model Class Initialized
DEBUG - 2024-05-22 01:31:01 --> Session class already loaded. Second attempt ignored.
ERROR - 2024-05-22 02:13:10 --> $config['composer_autoload'] is set to TRUE but /home/u241458058/domains/technoprimex.com/public_html/maurnaturo/application/vendor/autoload.php was not found.
INFO - 2024-05-22 02:13:10 --> Config Class Initialized
INFO - 2024-05-22 02:13:10 --> Hooks Class Initialized
DEBUG - 2024-05-22 02:13:10 --> UTF-8 Support Enabled
INFO - 2024-05-22 02:13:10 --> Utf8 Class Initialized
INFO - 2024-05-22 02:13:10 --> URI Class Initialized
DEBUG - 2024-05-22 02:13:10 --> No URI present. Default controller set.
INFO - 2024-05-22 02:13:10 --> Router Class Initialized
INFO - 2024-05-22 02:13:10 --> Output Class Initialized
INFO - 2024-05-22 02:13:10 --> Security Class Initialized
DEBUG - 2024-05-22 02:13:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-22 02:13:10 --> Input Class Initialized
INFO - 2024-05-22 02:13:10 --> Language Class Initialized
INFO - 2024-05-22 02:13:10 --> Loader Class Initialized
INFO - 2024-05-22 02:13:10 --> Helper loaded: url_helper
INFO - 2024-05-22 02:13:10 --> Helper loaded: file_helper
INFO - 2024-05-22 02:13:10 --> Helper loaded: html_helper
INFO - 2024-05-22 02:13:10 --> Helper loaded: text_helper
INFO - 2024-05-22 02:13:10 --> Helper loaded: form_helper
INFO - 2024-05-22 02:13:10 --> Helper loaded: lang_helper
INFO - 2024-05-22 02:13:10 --> Helper loaded: security_helper
INFO - 2024-05-22 02:13:10 --> Helper loaded: cookie_helper
INFO - 2024-05-22 02:13:10 --> Database Driver Class Initialized
INFO - 2024-05-22 02:13:10 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-22 02:13:10 --> Parser Class Initialized
INFO - 2024-05-22 02:13:10 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-05-22 02:13:10 --> Pagination Class Initialized
INFO - 2024-05-22 02:13:10 --> Form Validation Class Initialized
INFO - 2024-05-22 02:13:10 --> Controller Class Initialized
INFO - 2024-05-22 02:13:10 --> Model Class Initialized
DEBUG - 2024-05-22 02:13:10 --> Session class already loaded. Second attempt ignored.
ERROR - 2024-05-22 04:32:41 --> $config['composer_autoload'] is set to TRUE but /home/u241458058/domains/technoprimex.com/public_html/maurnaturo/application/vendor/autoload.php was not found.
INFO - 2024-05-22 04:32:41 --> Config Class Initialized
INFO - 2024-05-22 04:32:41 --> Hooks Class Initialized
DEBUG - 2024-05-22 04:32:41 --> UTF-8 Support Enabled
INFO - 2024-05-22 04:32:41 --> Utf8 Class Initialized
INFO - 2024-05-22 04:32:41 --> URI Class Initialized
DEBUG - 2024-05-22 04:32:41 --> No URI present. Default controller set.
INFO - 2024-05-22 04:32:41 --> Router Class Initialized
INFO - 2024-05-22 04:32:41 --> Output Class Initialized
INFO - 2024-05-22 04:32:41 --> Security Class Initialized
DEBUG - 2024-05-22 04:32:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-22 04:32:41 --> Input Class Initialized
INFO - 2024-05-22 04:32:41 --> Language Class Initialized
INFO - 2024-05-22 04:32:41 --> Loader Class Initialized
INFO - 2024-05-22 04:32:41 --> Helper loaded: url_helper
INFO - 2024-05-22 04:32:41 --> Helper loaded: file_helper
INFO - 2024-05-22 04:32:41 --> Helper loaded: html_helper
INFO - 2024-05-22 04:32:41 --> Helper loaded: text_helper
INFO - 2024-05-22 04:32:41 --> Helper loaded: form_helper
INFO - 2024-05-22 04:32:41 --> Helper loaded: lang_helper
INFO - 2024-05-22 04:32:41 --> Helper loaded: security_helper
INFO - 2024-05-22 04:32:41 --> Helper loaded: cookie_helper
INFO - 2024-05-22 04:32:41 --> Database Driver Class Initialized
INFO - 2024-05-22 04:32:41 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-22 04:32:41 --> Parser Class Initialized
INFO - 2024-05-22 04:32:41 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-05-22 04:32:41 --> Pagination Class Initialized
INFO - 2024-05-22 04:32:41 --> Form Validation Class Initialized
INFO - 2024-05-22 04:32:41 --> Controller Class Initialized
INFO - 2024-05-22 04:32:41 --> Model Class Initialized
DEBUG - 2024-05-22 04:32:41 --> Session class already loaded. Second attempt ignored.
ERROR - 2024-05-22 05:13:27 --> $config['composer_autoload'] is set to TRUE but /home/u241458058/domains/technoprimex.com/public_html/maurnaturo/application/vendor/autoload.php was not found.
INFO - 2024-05-22 05:13:27 --> Config Class Initialized
INFO - 2024-05-22 05:13:27 --> Hooks Class Initialized
DEBUG - 2024-05-22 05:13:27 --> UTF-8 Support Enabled
INFO - 2024-05-22 05:13:27 --> Utf8 Class Initialized
INFO - 2024-05-22 05:13:27 --> URI Class Initialized
DEBUG - 2024-05-22 05:13:27 --> No URI present. Default controller set.
INFO - 2024-05-22 05:13:27 --> Router Class Initialized
INFO - 2024-05-22 05:13:27 --> Output Class Initialized
INFO - 2024-05-22 05:13:27 --> Security Class Initialized
DEBUG - 2024-05-22 05:13:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-22 05:13:27 --> Input Class Initialized
INFO - 2024-05-22 05:13:27 --> Language Class Initialized
INFO - 2024-05-22 05:13:27 --> Loader Class Initialized
INFO - 2024-05-22 05:13:27 --> Helper loaded: url_helper
INFO - 2024-05-22 05:13:27 --> Helper loaded: file_helper
INFO - 2024-05-22 05:13:27 --> Helper loaded: html_helper
INFO - 2024-05-22 05:13:27 --> Helper loaded: text_helper
INFO - 2024-05-22 05:13:27 --> Helper loaded: form_helper
INFO - 2024-05-22 05:13:27 --> Helper loaded: lang_helper
INFO - 2024-05-22 05:13:27 --> Helper loaded: security_helper
INFO - 2024-05-22 05:13:27 --> Helper loaded: cookie_helper
INFO - 2024-05-22 05:13:27 --> Database Driver Class Initialized
INFO - 2024-05-22 05:13:27 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-22 05:13:27 --> Parser Class Initialized
INFO - 2024-05-22 05:13:27 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-05-22 05:13:27 --> Pagination Class Initialized
INFO - 2024-05-22 05:13:27 --> Form Validation Class Initialized
INFO - 2024-05-22 05:13:27 --> Controller Class Initialized
INFO - 2024-05-22 05:13:27 --> Model Class Initialized
DEBUG - 2024-05-22 05:13:27 --> Session class already loaded. Second attempt ignored.
ERROR - 2024-05-22 05:17:11 --> $config['composer_autoload'] is set to TRUE but /home/u241458058/domains/technoprimex.com/public_html/maurnaturo/application/vendor/autoload.php was not found.
INFO - 2024-05-22 05:17:11 --> Config Class Initialized
INFO - 2024-05-22 05:17:11 --> Hooks Class Initialized
DEBUG - 2024-05-22 05:17:11 --> UTF-8 Support Enabled
INFO - 2024-05-22 05:17:11 --> Utf8 Class Initialized
INFO - 2024-05-22 05:17:11 --> URI Class Initialized
DEBUG - 2024-05-22 05:17:11 --> No URI present. Default controller set.
INFO - 2024-05-22 05:17:11 --> Router Class Initialized
INFO - 2024-05-22 05:17:11 --> Output Class Initialized
INFO - 2024-05-22 05:17:11 --> Security Class Initialized
DEBUG - 2024-05-22 05:17:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-22 05:17:11 --> Input Class Initialized
INFO - 2024-05-22 05:17:11 --> Language Class Initialized
INFO - 2024-05-22 05:17:11 --> Loader Class Initialized
INFO - 2024-05-22 05:17:11 --> Helper loaded: url_helper
INFO - 2024-05-22 05:17:11 --> Helper loaded: file_helper
INFO - 2024-05-22 05:17:11 --> Helper loaded: html_helper
INFO - 2024-05-22 05:17:11 --> Helper loaded: text_helper
INFO - 2024-05-22 05:17:11 --> Helper loaded: form_helper
INFO - 2024-05-22 05:17:11 --> Helper loaded: lang_helper
INFO - 2024-05-22 05:17:11 --> Helper loaded: security_helper
INFO - 2024-05-22 05:17:11 --> Helper loaded: cookie_helper
INFO - 2024-05-22 05:17:11 --> Database Driver Class Initialized
INFO - 2024-05-22 05:17:11 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-22 05:17:11 --> Parser Class Initialized
INFO - 2024-05-22 05:17:11 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-05-22 05:17:11 --> Pagination Class Initialized
INFO - 2024-05-22 05:17:11 --> Form Validation Class Initialized
INFO - 2024-05-22 05:17:11 --> Controller Class Initialized
INFO - 2024-05-22 05:17:11 --> Model Class Initialized
DEBUG - 2024-05-22 05:17:11 --> Session class already loaded. Second attempt ignored.
ERROR - 2024-05-22 10:41:53 --> $config['composer_autoload'] is set to TRUE but /home/u241458058/domains/technoprimex.com/public_html/maurnaturo/application/vendor/autoload.php was not found.
INFO - 2024-05-22 10:41:53 --> Config Class Initialized
INFO - 2024-05-22 10:41:53 --> Hooks Class Initialized
DEBUG - 2024-05-22 10:41:53 --> UTF-8 Support Enabled
INFO - 2024-05-22 10:41:53 --> Utf8 Class Initialized
INFO - 2024-05-22 10:41:53 --> URI Class Initialized
DEBUG - 2024-05-22 10:41:53 --> No URI present. Default controller set.
INFO - 2024-05-22 10:41:53 --> Router Class Initialized
INFO - 2024-05-22 10:41:53 --> Output Class Initialized
INFO - 2024-05-22 10:41:53 --> Security Class Initialized
DEBUG - 2024-05-22 10:41:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-22 10:41:53 --> Input Class Initialized
INFO - 2024-05-22 10:41:53 --> Language Class Initialized
INFO - 2024-05-22 10:41:53 --> Loader Class Initialized
INFO - 2024-05-22 10:41:53 --> Helper loaded: url_helper
INFO - 2024-05-22 10:41:53 --> Helper loaded: file_helper
INFO - 2024-05-22 10:41:53 --> Helper loaded: html_helper
INFO - 2024-05-22 10:41:53 --> Helper loaded: text_helper
INFO - 2024-05-22 10:41:53 --> Helper loaded: form_helper
INFO - 2024-05-22 10:41:53 --> Helper loaded: lang_helper
INFO - 2024-05-22 10:41:53 --> Helper loaded: security_helper
INFO - 2024-05-22 10:41:53 --> Helper loaded: cookie_helper
INFO - 2024-05-22 10:41:53 --> Database Driver Class Initialized
INFO - 2024-05-22 10:41:53 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-22 10:41:53 --> Parser Class Initialized
INFO - 2024-05-22 10:41:53 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-05-22 10:41:53 --> Pagination Class Initialized
INFO - 2024-05-22 10:41:53 --> Form Validation Class Initialized
INFO - 2024-05-22 10:41:53 --> Controller Class Initialized
INFO - 2024-05-22 10:41:53 --> Model Class Initialized
DEBUG - 2024-05-22 10:41:53 --> Session class already loaded. Second attempt ignored.
ERROR - 2024-05-22 20:07:41 --> $config['composer_autoload'] is set to TRUE but /home/u241458058/domains/technoprimex.com/public_html/maurnaturo/application/vendor/autoload.php was not found.
INFO - 2024-05-22 20:07:41 --> Config Class Initialized
INFO - 2024-05-22 20:07:41 --> Hooks Class Initialized
DEBUG - 2024-05-22 20:07:41 --> UTF-8 Support Enabled
INFO - 2024-05-22 20:07:41 --> Utf8 Class Initialized
INFO - 2024-05-22 20:07:41 --> URI Class Initialized
DEBUG - 2024-05-22 20:07:41 --> No URI present. Default controller set.
INFO - 2024-05-22 20:07:41 --> Router Class Initialized
INFO - 2024-05-22 20:07:41 --> Output Class Initialized
INFO - 2024-05-22 20:07:41 --> Security Class Initialized
DEBUG - 2024-05-22 20:07:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-22 20:07:41 --> Input Class Initialized
INFO - 2024-05-22 20:07:41 --> Language Class Initialized
INFO - 2024-05-22 20:07:41 --> Loader Class Initialized
INFO - 2024-05-22 20:07:41 --> Helper loaded: url_helper
INFO - 2024-05-22 20:07:41 --> Helper loaded: file_helper
INFO - 2024-05-22 20:07:41 --> Helper loaded: html_helper
INFO - 2024-05-22 20:07:41 --> Helper loaded: text_helper
INFO - 2024-05-22 20:07:41 --> Helper loaded: form_helper
INFO - 2024-05-22 20:07:41 --> Helper loaded: lang_helper
INFO - 2024-05-22 20:07:41 --> Helper loaded: security_helper
INFO - 2024-05-22 20:07:41 --> Helper loaded: cookie_helper
INFO - 2024-05-22 20:07:41 --> Database Driver Class Initialized
INFO - 2024-05-22 20:07:41 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-22 20:07:41 --> Parser Class Initialized
INFO - 2024-05-22 20:07:41 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-05-22 20:07:41 --> Pagination Class Initialized
INFO - 2024-05-22 20:07:41 --> Form Validation Class Initialized
INFO - 2024-05-22 20:07:41 --> Controller Class Initialized
INFO - 2024-05-22 20:07:41 --> Model Class Initialized
DEBUG - 2024-05-22 20:07:41 --> Session class already loaded. Second attempt ignored.
ERROR - 2024-05-22 20:43:21 --> $config['composer_autoload'] is set to TRUE but /home/u241458058/domains/technoprimex.com/public_html/maurnaturo/application/vendor/autoload.php was not found.
INFO - 2024-05-22 20:43:21 --> Config Class Initialized
INFO - 2024-05-22 20:43:21 --> Hooks Class Initialized
DEBUG - 2024-05-22 20:43:21 --> UTF-8 Support Enabled
INFO - 2024-05-22 20:43:21 --> Utf8 Class Initialized
INFO - 2024-05-22 20:43:21 --> URI Class Initialized
DEBUG - 2024-05-22 20:43:21 --> No URI present. Default controller set.
INFO - 2024-05-22 20:43:21 --> Router Class Initialized
INFO - 2024-05-22 20:43:21 --> Output Class Initialized
INFO - 2024-05-22 20:43:21 --> Security Class Initialized
DEBUG - 2024-05-22 20:43:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-22 20:43:21 --> Input Class Initialized
INFO - 2024-05-22 20:43:21 --> Language Class Initialized
INFO - 2024-05-22 20:43:21 --> Loader Class Initialized
INFO - 2024-05-22 20:43:21 --> Helper loaded: url_helper
INFO - 2024-05-22 20:43:21 --> Helper loaded: file_helper
INFO - 2024-05-22 20:43:21 --> Helper loaded: html_helper
INFO - 2024-05-22 20:43:21 --> Helper loaded: text_helper
INFO - 2024-05-22 20:43:21 --> Helper loaded: form_helper
INFO - 2024-05-22 20:43:21 --> Helper loaded: lang_helper
INFO - 2024-05-22 20:43:21 --> Helper loaded: security_helper
INFO - 2024-05-22 20:43:21 --> Helper loaded: cookie_helper
INFO - 2024-05-22 20:43:21 --> Database Driver Class Initialized
INFO - 2024-05-22 20:43:21 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-22 20:43:21 --> Parser Class Initialized
INFO - 2024-05-22 20:43:21 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-05-22 20:43:21 --> Pagination Class Initialized
INFO - 2024-05-22 20:43:21 --> Form Validation Class Initialized
INFO - 2024-05-22 20:43:21 --> Controller Class Initialized
INFO - 2024-05-22 20:43:21 --> Model Class Initialized
DEBUG - 2024-05-22 20:43:21 --> Session class already loaded. Second attempt ignored.
