<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2024-05-19 13:11:27 --> $config['composer_autoload'] is set to TRUE but E:\xampp\htdocs\maurnaturo\application\vendor/autoload.php was not found.
INFO - 2024-05-19 13:11:27 --> Config Class Initialized
INFO - 2024-05-19 13:11:27 --> Hooks Class Initialized
DEBUG - 2024-05-19 13:11:27 --> UTF-8 Support Enabled
INFO - 2024-05-19 13:11:27 --> Utf8 Class Initialized
INFO - 2024-05-19 13:11:27 --> URI Class Initialized
INFO - 2024-05-19 13:11:27 --> Router Class Initialized
INFO - 2024-05-19 13:11:27 --> Output Class Initialized
INFO - 2024-05-19 13:11:27 --> Security Class Initialized
DEBUG - 2024-05-19 13:11:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-19 13:11:27 --> Input Class Initialized
INFO - 2024-05-19 13:11:27 --> Language Class Initialized
INFO - 2024-05-19 13:11:27 --> Loader Class Initialized
INFO - 2024-05-19 13:11:27 --> Helper loaded: url_helper
INFO - 2024-05-19 13:11:27 --> Helper loaded: file_helper
INFO - 2024-05-19 13:11:27 --> Helper loaded: html_helper
INFO - 2024-05-19 13:11:27 --> Helper loaded: text_helper
INFO - 2024-05-19 13:11:27 --> Helper loaded: form_helper
INFO - 2024-05-19 13:11:27 --> Helper loaded: lang_helper
INFO - 2024-05-19 13:11:27 --> Helper loaded: security_helper
INFO - 2024-05-19 13:11:27 --> Helper loaded: cookie_helper
INFO - 2024-05-19 13:11:27 --> Database Driver Class Initialized
INFO - 2024-05-19 13:11:27 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-19 13:11:27 --> Parser Class Initialized
INFO - 2024-05-19 13:11:27 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-05-19 13:11:27 --> Pagination Class Initialized
INFO - 2024-05-19 13:11:27 --> Form Validation Class Initialized
INFO - 2024-05-19 13:11:27 --> Controller Class Initialized
DEBUG - 2024-05-19 13:11:27 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-05-19 13:11:27 --> Session class already loaded. Second attempt ignored.
INFO - 2024-05-19 13:11:27 --> Model Class Initialized
ERROR - 2024-05-19 13:11:28 --> $config['composer_autoload'] is set to TRUE but E:\xampp\htdocs\maurnaturo\application\vendor/autoload.php was not found.
INFO - 2024-05-19 13:11:28 --> Config Class Initialized
INFO - 2024-05-19 13:11:28 --> Hooks Class Initialized
DEBUG - 2024-05-19 13:11:28 --> UTF-8 Support Enabled
INFO - 2024-05-19 13:11:28 --> Utf8 Class Initialized
INFO - 2024-05-19 13:11:28 --> URI Class Initialized
INFO - 2024-05-19 13:11:28 --> Router Class Initialized
INFO - 2024-05-19 13:11:28 --> Output Class Initialized
INFO - 2024-05-19 13:11:28 --> Security Class Initialized
DEBUG - 2024-05-19 13:11:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-19 13:11:28 --> Input Class Initialized
INFO - 2024-05-19 13:11:28 --> Language Class Initialized
INFO - 2024-05-19 13:11:28 --> Loader Class Initialized
INFO - 2024-05-19 13:11:28 --> Helper loaded: url_helper
INFO - 2024-05-19 13:11:28 --> Helper loaded: file_helper
INFO - 2024-05-19 13:11:28 --> Helper loaded: html_helper
INFO - 2024-05-19 13:11:28 --> Helper loaded: text_helper
INFO - 2024-05-19 13:11:28 --> Helper loaded: form_helper
INFO - 2024-05-19 13:11:28 --> Helper loaded: lang_helper
INFO - 2024-05-19 13:11:28 --> Helper loaded: security_helper
INFO - 2024-05-19 13:11:28 --> Helper loaded: cookie_helper
INFO - 2024-05-19 13:11:28 --> Database Driver Class Initialized
INFO - 2024-05-19 13:11:28 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-19 13:11:28 --> Parser Class Initialized
INFO - 2024-05-19 13:11:28 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-05-19 13:11:28 --> Pagination Class Initialized
INFO - 2024-05-19 13:11:28 --> Form Validation Class Initialized
INFO - 2024-05-19 13:11:28 --> Controller Class Initialized
INFO - 2024-05-19 13:11:28 --> Model Class Initialized
DEBUG - 2024-05-19 13:11:28 --> Session class already loaded. Second attempt ignored.
INFO - 2024-05-19 13:11:28 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\user/admin_login_form.php
DEBUG - 2024-05-19 13:11:28 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-05-19 13:11:28 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\include/top_menu.php
INFO - 2024-05-19 13:11:28 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\include/admin_loggedin_info.php
INFO - 2024-05-19 13:11:28 --> Model Class Initialized
INFO - 2024-05-19 13:11:28 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\admin_html_template.php
INFO - 2024-05-19 13:11:28 --> Final output sent to browser
DEBUG - 2024-05-19 13:11:28 --> Total execution time: 0.2074
ERROR - 2024-05-19 13:11:32 --> $config['composer_autoload'] is set to TRUE but E:\xampp\htdocs\maurnaturo\application\vendor/autoload.php was not found.
INFO - 2024-05-19 13:11:32 --> Config Class Initialized
INFO - 2024-05-19 13:11:32 --> Hooks Class Initialized
DEBUG - 2024-05-19 13:11:32 --> UTF-8 Support Enabled
INFO - 2024-05-19 13:11:32 --> Utf8 Class Initialized
INFO - 2024-05-19 13:11:32 --> URI Class Initialized
INFO - 2024-05-19 13:11:32 --> Router Class Initialized
INFO - 2024-05-19 13:11:32 --> Output Class Initialized
INFO - 2024-05-19 13:11:32 --> Security Class Initialized
DEBUG - 2024-05-19 13:11:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-19 13:11:32 --> Input Class Initialized
INFO - 2024-05-19 13:11:32 --> Language Class Initialized
INFO - 2024-05-19 13:11:32 --> Loader Class Initialized
INFO - 2024-05-19 13:11:32 --> Helper loaded: url_helper
INFO - 2024-05-19 13:11:32 --> Helper loaded: file_helper
INFO - 2024-05-19 13:11:32 --> Helper loaded: html_helper
INFO - 2024-05-19 13:11:32 --> Helper loaded: text_helper
INFO - 2024-05-19 13:11:32 --> Helper loaded: form_helper
INFO - 2024-05-19 13:11:32 --> Helper loaded: lang_helper
INFO - 2024-05-19 13:11:32 --> Helper loaded: security_helper
INFO - 2024-05-19 13:11:32 --> Helper loaded: cookie_helper
INFO - 2024-05-19 13:11:32 --> Database Driver Class Initialized
INFO - 2024-05-19 13:11:32 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-19 13:11:32 --> Parser Class Initialized
INFO - 2024-05-19 13:11:32 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-05-19 13:11:32 --> Pagination Class Initialized
INFO - 2024-05-19 13:11:32 --> Form Validation Class Initialized
INFO - 2024-05-19 13:11:32 --> Controller Class Initialized
INFO - 2024-05-19 13:11:32 --> Model Class Initialized
DEBUG - 2024-05-19 13:11:32 --> Session class already loaded. Second attempt ignored.
INFO - 2024-05-19 13:11:32 --> Model Class Initialized
INFO - 2024-05-19 13:11:32 --> Final output sent to browser
DEBUG - 2024-05-19 13:11:32 --> Total execution time: 0.1499
ERROR - 2024-05-19 13:11:32 --> $config['composer_autoload'] is set to TRUE but E:\xampp\htdocs\maurnaturo\application\vendor/autoload.php was not found.
INFO - 2024-05-19 13:11:32 --> Config Class Initialized
INFO - 2024-05-19 13:11:32 --> Hooks Class Initialized
DEBUG - 2024-05-19 13:11:32 --> UTF-8 Support Enabled
INFO - 2024-05-19 13:11:32 --> Utf8 Class Initialized
INFO - 2024-05-19 13:11:32 --> URI Class Initialized
INFO - 2024-05-19 13:11:32 --> Router Class Initialized
INFO - 2024-05-19 13:11:32 --> Output Class Initialized
INFO - 2024-05-19 13:11:32 --> Security Class Initialized
DEBUG - 2024-05-19 13:11:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-19 13:11:32 --> Input Class Initialized
INFO - 2024-05-19 13:11:32 --> Language Class Initialized
INFO - 2024-05-19 13:11:32 --> Loader Class Initialized
INFO - 2024-05-19 13:11:32 --> Helper loaded: url_helper
INFO - 2024-05-19 13:11:32 --> Helper loaded: file_helper
INFO - 2024-05-19 13:11:32 --> Helper loaded: html_helper
INFO - 2024-05-19 13:11:32 --> Helper loaded: text_helper
INFO - 2024-05-19 13:11:32 --> Helper loaded: form_helper
INFO - 2024-05-19 13:11:32 --> Helper loaded: lang_helper
INFO - 2024-05-19 13:11:32 --> Helper loaded: security_helper
INFO - 2024-05-19 13:11:32 --> Helper loaded: cookie_helper
INFO - 2024-05-19 13:11:32 --> Database Driver Class Initialized
INFO - 2024-05-19 13:11:32 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-19 13:11:32 --> Parser Class Initialized
INFO - 2024-05-19 13:11:32 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-05-19 13:11:32 --> Pagination Class Initialized
INFO - 2024-05-19 13:11:32 --> Form Validation Class Initialized
INFO - 2024-05-19 13:11:32 --> Controller Class Initialized
INFO - 2024-05-19 13:11:32 --> Model Class Initialized
DEBUG - 2024-05-19 13:11:32 --> Session class already loaded. Second attempt ignored.
INFO - 2024-05-19 13:11:32 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\user/admin_login_form.php
DEBUG - 2024-05-19 13:11:32 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-05-19 13:11:32 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\include/top_menu.php
INFO - 2024-05-19 13:11:33 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\include/admin_loggedin_info.php
INFO - 2024-05-19 13:11:33 --> Model Class Initialized
INFO - 2024-05-19 13:11:33 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\admin_html_template.php
INFO - 2024-05-19 13:11:33 --> Final output sent to browser
DEBUG - 2024-05-19 13:11:33 --> Total execution time: 0.1402
ERROR - 2024-05-19 13:11:37 --> $config['composer_autoload'] is set to TRUE but E:\xampp\htdocs\maurnaturo\application\vendor/autoload.php was not found.
INFO - 2024-05-19 13:11:37 --> Config Class Initialized
INFO - 2024-05-19 13:11:37 --> Hooks Class Initialized
DEBUG - 2024-05-19 13:11:37 --> UTF-8 Support Enabled
INFO - 2024-05-19 13:11:37 --> Utf8 Class Initialized
INFO - 2024-05-19 13:11:37 --> URI Class Initialized
INFO - 2024-05-19 13:11:37 --> Router Class Initialized
INFO - 2024-05-19 13:11:37 --> Output Class Initialized
INFO - 2024-05-19 13:11:37 --> Security Class Initialized
DEBUG - 2024-05-19 13:11:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-19 13:11:37 --> Input Class Initialized
INFO - 2024-05-19 13:11:37 --> Language Class Initialized
INFO - 2024-05-19 13:11:37 --> Loader Class Initialized
INFO - 2024-05-19 13:11:37 --> Helper loaded: url_helper
INFO - 2024-05-19 13:11:37 --> Helper loaded: file_helper
INFO - 2024-05-19 13:11:37 --> Helper loaded: html_helper
INFO - 2024-05-19 13:11:37 --> Helper loaded: text_helper
INFO - 2024-05-19 13:11:37 --> Helper loaded: form_helper
INFO - 2024-05-19 13:11:37 --> Helper loaded: lang_helper
INFO - 2024-05-19 13:11:37 --> Helper loaded: security_helper
INFO - 2024-05-19 13:11:37 --> Helper loaded: cookie_helper
INFO - 2024-05-19 13:11:37 --> Database Driver Class Initialized
INFO - 2024-05-19 13:11:37 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-19 13:11:37 --> Parser Class Initialized
INFO - 2024-05-19 13:11:37 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-05-19 13:11:37 --> Pagination Class Initialized
INFO - 2024-05-19 13:11:37 --> Form Validation Class Initialized
INFO - 2024-05-19 13:11:37 --> Controller Class Initialized
INFO - 2024-05-19 13:11:37 --> Model Class Initialized
DEBUG - 2024-05-19 13:11:37 --> Session class already loaded. Second attempt ignored.
INFO - 2024-05-19 13:11:37 --> Model Class Initialized
INFO - 2024-05-19 13:11:37 --> Final output sent to browser
DEBUG - 2024-05-19 13:11:37 --> Total execution time: 0.0891
ERROR - 2024-05-19 13:11:37 --> $config['composer_autoload'] is set to TRUE but E:\xampp\htdocs\maurnaturo\application\vendor/autoload.php was not found.
INFO - 2024-05-19 13:11:37 --> Config Class Initialized
INFO - 2024-05-19 13:11:37 --> Hooks Class Initialized
DEBUG - 2024-05-19 13:11:37 --> UTF-8 Support Enabled
INFO - 2024-05-19 13:11:37 --> Utf8 Class Initialized
INFO - 2024-05-19 13:11:37 --> URI Class Initialized
DEBUG - 2024-05-19 13:11:37 --> No URI present. Default controller set.
INFO - 2024-05-19 13:11:37 --> Router Class Initialized
INFO - 2024-05-19 13:11:37 --> Output Class Initialized
INFO - 2024-05-19 13:11:37 --> Security Class Initialized
DEBUG - 2024-05-19 13:11:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-19 13:11:37 --> Input Class Initialized
INFO - 2024-05-19 13:11:37 --> Language Class Initialized
INFO - 2024-05-19 13:11:37 --> Loader Class Initialized
INFO - 2024-05-19 13:11:37 --> Helper loaded: url_helper
INFO - 2024-05-19 13:11:37 --> Helper loaded: file_helper
INFO - 2024-05-19 13:11:37 --> Helper loaded: html_helper
INFO - 2024-05-19 13:11:37 --> Helper loaded: text_helper
INFO - 2024-05-19 13:11:37 --> Helper loaded: form_helper
INFO - 2024-05-19 13:11:37 --> Helper loaded: lang_helper
INFO - 2024-05-19 13:11:37 --> Helper loaded: security_helper
INFO - 2024-05-19 13:11:37 --> Helper loaded: cookie_helper
INFO - 2024-05-19 13:11:37 --> Database Driver Class Initialized
INFO - 2024-05-19 13:11:37 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-19 13:11:37 --> Parser Class Initialized
INFO - 2024-05-19 13:11:37 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-05-19 13:11:37 --> Pagination Class Initialized
INFO - 2024-05-19 13:11:37 --> Form Validation Class Initialized
INFO - 2024-05-19 13:11:37 --> Controller Class Initialized
INFO - 2024-05-19 13:11:37 --> Model Class Initialized
DEBUG - 2024-05-19 13:11:37 --> Session class already loaded. Second attempt ignored.
INFO - 2024-05-19 13:11:37 --> Model Class Initialized
DEBUG - 2024-05-19 13:11:37 --> Session class already loaded. Second attempt ignored.
INFO - 2024-05-19 13:11:37 --> Model Class Initialized
INFO - 2024-05-19 13:11:37 --> Model Class Initialized
INFO - 2024-05-19 13:11:37 --> Model Class Initialized
INFO - 2024-05-19 13:11:37 --> Model Class Initialized
DEBUG - 2024-05-19 13:11:37 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-05-19 13:11:37 --> Session class already loaded. Second attempt ignored.
INFO - 2024-05-19 13:11:37 --> Model Class Initialized
INFO - 2024-05-19 13:11:37 --> Model Class Initialized
INFO - 2024-05-19 13:11:39 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\include/admin_home.php
DEBUG - 2024-05-19 13:11:39 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-05-19 13:11:39 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\include/top_menu.php
INFO - 2024-05-19 13:11:39 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\include/admin_loggedin_info.php
INFO - 2024-05-19 13:11:39 --> Model Class Initialized
INFO - 2024-05-19 13:11:40 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\include/admin_header.php
INFO - 2024-05-19 13:11:40 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\include/admin_footer.php
INFO - 2024-05-19 13:11:40 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\admin_html_template.php
INFO - 2024-05-19 13:11:40 --> Final output sent to browser
DEBUG - 2024-05-19 13:11:40 --> Total execution time: 2.9920
ERROR - 2024-05-19 13:11:41 --> $config['composer_autoload'] is set to TRUE but E:\xampp\htdocs\maurnaturo\application\vendor/autoload.php was not found.
INFO - 2024-05-19 13:11:41 --> Config Class Initialized
INFO - 2024-05-19 13:11:41 --> Hooks Class Initialized
DEBUG - 2024-05-19 13:11:41 --> UTF-8 Support Enabled
INFO - 2024-05-19 13:11:41 --> Utf8 Class Initialized
INFO - 2024-05-19 13:11:41 --> URI Class Initialized
INFO - 2024-05-19 13:11:41 --> Router Class Initialized
INFO - 2024-05-19 13:11:41 --> Output Class Initialized
INFO - 2024-05-19 13:11:41 --> Security Class Initialized
DEBUG - 2024-05-19 13:11:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-19 13:11:41 --> Input Class Initialized
INFO - 2024-05-19 13:11:41 --> Language Class Initialized
INFO - 2024-05-19 13:11:41 --> Loader Class Initialized
INFO - 2024-05-19 13:11:41 --> Helper loaded: url_helper
INFO - 2024-05-19 13:11:41 --> Helper loaded: file_helper
INFO - 2024-05-19 13:11:41 --> Helper loaded: html_helper
INFO - 2024-05-19 13:11:41 --> Helper loaded: text_helper
INFO - 2024-05-19 13:11:41 --> Helper loaded: form_helper
INFO - 2024-05-19 13:11:41 --> Helper loaded: lang_helper
INFO - 2024-05-19 13:11:41 --> Helper loaded: security_helper
INFO - 2024-05-19 13:11:41 --> Helper loaded: cookie_helper
INFO - 2024-05-19 13:11:41 --> Database Driver Class Initialized
INFO - 2024-05-19 13:11:41 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-19 13:11:41 --> Parser Class Initialized
INFO - 2024-05-19 13:11:41 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-05-19 13:11:41 --> Pagination Class Initialized
INFO - 2024-05-19 13:11:41 --> Form Validation Class Initialized
INFO - 2024-05-19 13:11:41 --> Controller Class Initialized
DEBUG - 2024-05-19 13:11:41 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-05-19 13:11:41 --> Session class already loaded. Second attempt ignored.
INFO - 2024-05-19 13:11:41 --> Model Class Initialized
INFO - 2024-05-19 13:11:41 --> Final output sent to browser
DEBUG - 2024-05-19 13:11:41 --> Total execution time: 0.1307
ERROR - 2024-05-19 13:12:06 --> $config['composer_autoload'] is set to TRUE but E:\xampp\htdocs\maurnaturo\application\vendor/autoload.php was not found.
INFO - 2024-05-19 13:12:06 --> Config Class Initialized
INFO - 2024-05-19 13:12:06 --> Hooks Class Initialized
DEBUG - 2024-05-19 13:12:06 --> UTF-8 Support Enabled
INFO - 2024-05-19 13:12:06 --> Utf8 Class Initialized
INFO - 2024-05-19 13:12:06 --> URI Class Initialized
DEBUG - 2024-05-19 13:12:06 --> No URI present. Default controller set.
INFO - 2024-05-19 13:12:06 --> Router Class Initialized
INFO - 2024-05-19 13:12:06 --> Output Class Initialized
INFO - 2024-05-19 13:12:06 --> Security Class Initialized
DEBUG - 2024-05-19 13:12:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-19 13:12:06 --> Input Class Initialized
INFO - 2024-05-19 13:12:06 --> Language Class Initialized
INFO - 2024-05-19 13:12:06 --> Loader Class Initialized
INFO - 2024-05-19 13:12:06 --> Helper loaded: url_helper
INFO - 2024-05-19 13:12:06 --> Helper loaded: file_helper
INFO - 2024-05-19 13:12:06 --> Helper loaded: html_helper
INFO - 2024-05-19 13:12:06 --> Helper loaded: text_helper
INFO - 2024-05-19 13:12:06 --> Helper loaded: form_helper
INFO - 2024-05-19 13:12:06 --> Helper loaded: lang_helper
INFO - 2024-05-19 13:12:06 --> Helper loaded: security_helper
INFO - 2024-05-19 13:12:06 --> Helper loaded: cookie_helper
INFO - 2024-05-19 13:12:06 --> Database Driver Class Initialized
INFO - 2024-05-19 13:12:06 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-19 13:12:06 --> Parser Class Initialized
INFO - 2024-05-19 13:12:06 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-05-19 13:12:06 --> Pagination Class Initialized
INFO - 2024-05-19 13:12:06 --> Form Validation Class Initialized
INFO - 2024-05-19 13:12:06 --> Controller Class Initialized
INFO - 2024-05-19 13:12:06 --> Model Class Initialized
DEBUG - 2024-05-19 13:12:06 --> Session class already loaded. Second attempt ignored.
ERROR - 2024-05-19 13:12:06 --> $config['composer_autoload'] is set to TRUE but E:\xampp\htdocs\maurnaturo\application\vendor/autoload.php was not found.
INFO - 2024-05-19 13:12:06 --> Config Class Initialized
INFO - 2024-05-19 13:12:06 --> Hooks Class Initialized
DEBUG - 2024-05-19 13:12:06 --> UTF-8 Support Enabled
INFO - 2024-05-19 13:12:06 --> Utf8 Class Initialized
INFO - 2024-05-19 13:12:06 --> URI Class Initialized
INFO - 2024-05-19 13:12:06 --> Router Class Initialized
INFO - 2024-05-19 13:12:06 --> Output Class Initialized
INFO - 2024-05-19 13:12:06 --> Security Class Initialized
DEBUG - 2024-05-19 13:12:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-19 13:12:06 --> Input Class Initialized
INFO - 2024-05-19 13:12:06 --> Language Class Initialized
INFO - 2024-05-19 13:12:06 --> Loader Class Initialized
INFO - 2024-05-19 13:12:06 --> Helper loaded: url_helper
INFO - 2024-05-19 13:12:06 --> Helper loaded: file_helper
INFO - 2024-05-19 13:12:06 --> Helper loaded: html_helper
INFO - 2024-05-19 13:12:06 --> Helper loaded: text_helper
INFO - 2024-05-19 13:12:06 --> Helper loaded: form_helper
INFO - 2024-05-19 13:12:06 --> Helper loaded: lang_helper
INFO - 2024-05-19 13:12:06 --> Helper loaded: security_helper
INFO - 2024-05-19 13:12:06 --> Helper loaded: cookie_helper
INFO - 2024-05-19 13:12:06 --> Database Driver Class Initialized
INFO - 2024-05-19 13:12:06 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-19 13:12:06 --> Parser Class Initialized
INFO - 2024-05-19 13:12:06 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-05-19 13:12:06 --> Pagination Class Initialized
INFO - 2024-05-19 13:12:06 --> Form Validation Class Initialized
INFO - 2024-05-19 13:12:06 --> Controller Class Initialized
INFO - 2024-05-19 13:12:06 --> Model Class Initialized
DEBUG - 2024-05-19 13:12:06 --> Session class already loaded. Second attempt ignored.
INFO - 2024-05-19 13:12:06 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\user/admin_login_form.php
DEBUG - 2024-05-19 13:12:06 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-05-19 13:12:06 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\include/top_menu.php
INFO - 2024-05-19 13:12:06 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\include/admin_loggedin_info.php
INFO - 2024-05-19 13:12:06 --> Model Class Initialized
INFO - 2024-05-19 13:12:06 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\admin_html_template.php
INFO - 2024-05-19 13:12:06 --> Final output sent to browser
DEBUG - 2024-05-19 13:12:06 --> Total execution time: 0.3461
ERROR - 2024-05-19 13:12:13 --> $config['composer_autoload'] is set to TRUE but E:\xampp\htdocs\maurnaturo\application\vendor/autoload.php was not found.
INFO - 2024-05-19 13:12:13 --> Config Class Initialized
INFO - 2024-05-19 13:12:13 --> Hooks Class Initialized
DEBUG - 2024-05-19 13:12:13 --> UTF-8 Support Enabled
INFO - 2024-05-19 13:12:13 --> Utf8 Class Initialized
INFO - 2024-05-19 13:12:13 --> URI Class Initialized
INFO - 2024-05-19 13:12:13 --> Router Class Initialized
INFO - 2024-05-19 13:12:13 --> Output Class Initialized
INFO - 2024-05-19 13:12:13 --> Security Class Initialized
DEBUG - 2024-05-19 13:12:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-19 13:12:13 --> Input Class Initialized
INFO - 2024-05-19 13:12:13 --> Language Class Initialized
INFO - 2024-05-19 13:12:13 --> Loader Class Initialized
INFO - 2024-05-19 13:12:13 --> Helper loaded: url_helper
INFO - 2024-05-19 13:12:13 --> Helper loaded: file_helper
INFO - 2024-05-19 13:12:13 --> Helper loaded: html_helper
INFO - 2024-05-19 13:12:13 --> Helper loaded: text_helper
INFO - 2024-05-19 13:12:13 --> Helper loaded: form_helper
INFO - 2024-05-19 13:12:13 --> Helper loaded: lang_helper
INFO - 2024-05-19 13:12:13 --> Helper loaded: security_helper
INFO - 2024-05-19 13:12:13 --> Helper loaded: cookie_helper
INFO - 2024-05-19 13:12:13 --> Database Driver Class Initialized
INFO - 2024-05-19 13:12:13 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-19 13:12:13 --> Parser Class Initialized
INFO - 2024-05-19 13:12:13 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-05-19 13:12:13 --> Pagination Class Initialized
INFO - 2024-05-19 13:12:13 --> Form Validation Class Initialized
INFO - 2024-05-19 13:12:13 --> Controller Class Initialized
DEBUG - 2024-05-19 13:12:13 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-05-19 13:12:13 --> Session class already loaded. Second attempt ignored.
INFO - 2024-05-19 13:12:13 --> Model Class Initialized
INFO - 2024-05-19 13:12:13 --> Model Class Initialized
DEBUG - 2024-05-19 13:12:13 --> Lmr class already loaded. Second attempt ignored.
INFO - 2024-05-19 13:12:13 --> Model Class Initialized
INFO - 2024-05-19 13:12:13 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\mr/mr.php
DEBUG - 2024-05-19 13:12:13 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-05-19 13:12:13 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\include/top_menu.php
INFO - 2024-05-19 13:12:13 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\include/admin_loggedin_info.php
INFO - 2024-05-19 13:12:13 --> Model Class Initialized
INFO - 2024-05-19 13:12:13 --> Model Class Initialized
INFO - 2024-05-19 13:12:13 --> Model Class Initialized
INFO - 2024-05-19 13:12:14 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\include/admin_header.php
INFO - 2024-05-19 13:12:14 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\include/admin_footer.php
INFO - 2024-05-19 13:12:14 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\admin_html_template.php
INFO - 2024-05-19 13:12:14 --> Final output sent to browser
DEBUG - 2024-05-19 13:12:14 --> Total execution time: 1.6280
ERROR - 2024-05-19 13:12:15 --> $config['composer_autoload'] is set to TRUE but E:\xampp\htdocs\maurnaturo\application\vendor/autoload.php was not found.
INFO - 2024-05-19 13:12:15 --> Config Class Initialized
INFO - 2024-05-19 13:12:15 --> Hooks Class Initialized
DEBUG - 2024-05-19 13:12:15 --> UTF-8 Support Enabled
INFO - 2024-05-19 13:12:15 --> Utf8 Class Initialized
INFO - 2024-05-19 13:12:15 --> URI Class Initialized
INFO - 2024-05-19 13:12:15 --> Router Class Initialized
INFO - 2024-05-19 13:12:15 --> Output Class Initialized
INFO - 2024-05-19 13:12:15 --> Security Class Initialized
DEBUG - 2024-05-19 13:12:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-19 13:12:15 --> Input Class Initialized
INFO - 2024-05-19 13:12:15 --> Language Class Initialized
INFO - 2024-05-19 13:12:15 --> Loader Class Initialized
INFO - 2024-05-19 13:12:15 --> Helper loaded: url_helper
INFO - 2024-05-19 13:12:15 --> Helper loaded: file_helper
INFO - 2024-05-19 13:12:15 --> Helper loaded: html_helper
INFO - 2024-05-19 13:12:15 --> Helper loaded: text_helper
INFO - 2024-05-19 13:12:15 --> Helper loaded: form_helper
INFO - 2024-05-19 13:12:15 --> Helper loaded: lang_helper
INFO - 2024-05-19 13:12:15 --> Helper loaded: security_helper
INFO - 2024-05-19 13:12:15 --> Helper loaded: cookie_helper
INFO - 2024-05-19 13:12:15 --> Database Driver Class Initialized
INFO - 2024-05-19 13:12:15 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-19 13:12:15 --> Parser Class Initialized
INFO - 2024-05-19 13:12:15 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-05-19 13:12:15 --> Pagination Class Initialized
INFO - 2024-05-19 13:12:15 --> Form Validation Class Initialized
INFO - 2024-05-19 13:12:15 --> Controller Class Initialized
DEBUG - 2024-05-19 13:12:15 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-05-19 13:12:15 --> Session class already loaded. Second attempt ignored.
INFO - 2024-05-19 13:12:15 --> Model Class Initialized
INFO - 2024-05-19 13:12:15 --> Model Class Initialized
INFO - 2024-05-19 13:12:15 --> Final output sent to browser
DEBUG - 2024-05-19 13:12:15 --> Total execution time: 0.2653
ERROR - 2024-05-19 13:12:25 --> $config['composer_autoload'] is set to TRUE but E:\xampp\htdocs\maurnaturo\application\vendor/autoload.php was not found.
INFO - 2024-05-19 13:12:25 --> Config Class Initialized
INFO - 2024-05-19 13:12:25 --> Hooks Class Initialized
DEBUG - 2024-05-19 13:12:25 --> UTF-8 Support Enabled
INFO - 2024-05-19 13:12:25 --> Utf8 Class Initialized
INFO - 2024-05-19 13:12:25 --> URI Class Initialized
INFO - 2024-05-19 13:12:25 --> Router Class Initialized
INFO - 2024-05-19 13:12:25 --> Output Class Initialized
INFO - 2024-05-19 13:12:25 --> Security Class Initialized
DEBUG - 2024-05-19 13:12:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-19 13:12:25 --> Input Class Initialized
INFO - 2024-05-19 13:12:25 --> Language Class Initialized
INFO - 2024-05-19 13:12:25 --> Loader Class Initialized
INFO - 2024-05-19 13:12:25 --> Helper loaded: url_helper
INFO - 2024-05-19 13:12:25 --> Helper loaded: file_helper
INFO - 2024-05-19 13:12:25 --> Helper loaded: html_helper
INFO - 2024-05-19 13:12:25 --> Helper loaded: text_helper
INFO - 2024-05-19 13:12:25 --> Helper loaded: form_helper
INFO - 2024-05-19 13:12:25 --> Helper loaded: lang_helper
INFO - 2024-05-19 13:12:25 --> Helper loaded: security_helper
INFO - 2024-05-19 13:12:25 --> Helper loaded: cookie_helper
INFO - 2024-05-19 13:12:25 --> Database Driver Class Initialized
INFO - 2024-05-19 13:12:25 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-19 13:12:25 --> Parser Class Initialized
INFO - 2024-05-19 13:12:25 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-05-19 13:12:25 --> Pagination Class Initialized
INFO - 2024-05-19 13:12:25 --> Form Validation Class Initialized
INFO - 2024-05-19 13:12:25 --> Controller Class Initialized
INFO - 2024-05-19 13:12:25 --> Model Class Initialized
DEBUG - 2024-05-19 13:12:25 --> Session class already loaded. Second attempt ignored.
INFO - 2024-05-19 13:12:25 --> Model Class Initialized
INFO - 2024-05-19 13:12:25 --> Final output sent to browser
DEBUG - 2024-05-19 13:12:25 --> Total execution time: 0.0905
ERROR - 2024-05-19 13:12:25 --> $config['composer_autoload'] is set to TRUE but E:\xampp\htdocs\maurnaturo\application\vendor/autoload.php was not found.
INFO - 2024-05-19 13:12:25 --> Config Class Initialized
INFO - 2024-05-19 13:12:25 --> Hooks Class Initialized
DEBUG - 2024-05-19 13:12:25 --> UTF-8 Support Enabled
INFO - 2024-05-19 13:12:25 --> Utf8 Class Initialized
INFO - 2024-05-19 13:12:25 --> URI Class Initialized
DEBUG - 2024-05-19 13:12:25 --> No URI present. Default controller set.
INFO - 2024-05-19 13:12:25 --> Router Class Initialized
INFO - 2024-05-19 13:12:25 --> Output Class Initialized
INFO - 2024-05-19 13:12:25 --> Security Class Initialized
DEBUG - 2024-05-19 13:12:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-19 13:12:25 --> Input Class Initialized
INFO - 2024-05-19 13:12:25 --> Language Class Initialized
INFO - 2024-05-19 13:12:25 --> Loader Class Initialized
INFO - 2024-05-19 13:12:25 --> Helper loaded: url_helper
INFO - 2024-05-19 13:12:25 --> Helper loaded: file_helper
INFO - 2024-05-19 13:12:25 --> Helper loaded: html_helper
INFO - 2024-05-19 13:12:25 --> Helper loaded: text_helper
INFO - 2024-05-19 13:12:25 --> Helper loaded: form_helper
INFO - 2024-05-19 13:12:25 --> Helper loaded: lang_helper
INFO - 2024-05-19 13:12:25 --> Helper loaded: security_helper
INFO - 2024-05-19 13:12:25 --> Helper loaded: cookie_helper
INFO - 2024-05-19 13:12:25 --> Database Driver Class Initialized
INFO - 2024-05-19 13:12:25 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-19 13:12:25 --> Parser Class Initialized
INFO - 2024-05-19 13:12:25 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-05-19 13:12:25 --> Pagination Class Initialized
INFO - 2024-05-19 13:12:25 --> Form Validation Class Initialized
INFO - 2024-05-19 13:12:25 --> Controller Class Initialized
INFO - 2024-05-19 13:12:25 --> Model Class Initialized
DEBUG - 2024-05-19 13:12:25 --> Session class already loaded. Second attempt ignored.
INFO - 2024-05-19 13:12:25 --> Model Class Initialized
DEBUG - 2024-05-19 13:12:25 --> Session class already loaded. Second attempt ignored.
INFO - 2024-05-19 13:12:25 --> Model Class Initialized
INFO - 2024-05-19 13:12:25 --> Model Class Initialized
INFO - 2024-05-19 13:12:25 --> Model Class Initialized
INFO - 2024-05-19 13:12:25 --> Model Class Initialized
DEBUG - 2024-05-19 13:12:25 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-05-19 13:12:25 --> Session class already loaded. Second attempt ignored.
INFO - 2024-05-19 13:12:25 --> Model Class Initialized
INFO - 2024-05-19 13:12:25 --> Model Class Initialized
INFO - 2024-05-19 13:12:26 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\include/admin_home.php
DEBUG - 2024-05-19 13:12:26 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-05-19 13:12:26 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\include/top_menu.php
INFO - 2024-05-19 13:12:26 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\include/admin_loggedin_info.php
INFO - 2024-05-19 13:12:26 --> Model Class Initialized
INFO - 2024-05-19 13:12:27 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\include/admin_header.php
INFO - 2024-05-19 13:12:27 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\include/admin_footer.php
INFO - 2024-05-19 13:12:27 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\admin_html_template.php
INFO - 2024-05-19 13:12:27 --> Final output sent to browser
DEBUG - 2024-05-19 13:12:27 --> Total execution time: 1.9736
ERROR - 2024-05-19 13:15:47 --> $config['composer_autoload'] is set to TRUE but E:\xampp\htdocs\maurnaturo\application\vendor/autoload.php was not found.
INFO - 2024-05-19 13:15:47 --> Config Class Initialized
INFO - 2024-05-19 13:15:47 --> Hooks Class Initialized
DEBUG - 2024-05-19 13:15:47 --> UTF-8 Support Enabled
INFO - 2024-05-19 13:15:47 --> Utf8 Class Initialized
INFO - 2024-05-19 13:15:47 --> URI Class Initialized
DEBUG - 2024-05-19 13:15:47 --> No URI present. Default controller set.
INFO - 2024-05-19 13:15:47 --> Router Class Initialized
INFO - 2024-05-19 13:15:47 --> Output Class Initialized
INFO - 2024-05-19 13:15:47 --> Security Class Initialized
DEBUG - 2024-05-19 13:15:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-19 13:15:47 --> Input Class Initialized
INFO - 2024-05-19 13:15:47 --> Language Class Initialized
INFO - 2024-05-19 13:15:47 --> Loader Class Initialized
INFO - 2024-05-19 13:15:47 --> Helper loaded: url_helper
INFO - 2024-05-19 13:15:47 --> Helper loaded: file_helper
INFO - 2024-05-19 13:15:47 --> Helper loaded: html_helper
INFO - 2024-05-19 13:15:47 --> Helper loaded: text_helper
INFO - 2024-05-19 13:15:47 --> Helper loaded: form_helper
INFO - 2024-05-19 13:15:47 --> Helper loaded: lang_helper
INFO - 2024-05-19 13:15:47 --> Helper loaded: security_helper
INFO - 2024-05-19 13:15:47 --> Helper loaded: cookie_helper
INFO - 2024-05-19 13:15:48 --> Database Driver Class Initialized
INFO - 2024-05-19 13:15:48 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-19 13:15:48 --> Parser Class Initialized
INFO - 2024-05-19 13:15:48 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-05-19 13:15:48 --> Pagination Class Initialized
INFO - 2024-05-19 13:15:48 --> Form Validation Class Initialized
INFO - 2024-05-19 13:15:48 --> Controller Class Initialized
INFO - 2024-05-19 13:15:48 --> Model Class Initialized
DEBUG - 2024-05-19 13:15:48 --> Session class already loaded. Second attempt ignored.
INFO - 2024-05-19 13:15:48 --> Model Class Initialized
DEBUG - 2024-05-19 13:15:48 --> Session class already loaded. Second attempt ignored.
INFO - 2024-05-19 13:15:48 --> Model Class Initialized
INFO - 2024-05-19 13:15:48 --> Model Class Initialized
INFO - 2024-05-19 13:15:48 --> Model Class Initialized
INFO - 2024-05-19 13:15:48 --> Model Class Initialized
DEBUG - 2024-05-19 13:15:48 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-05-19 13:15:48 --> Session class already loaded. Second attempt ignored.
INFO - 2024-05-19 13:15:48 --> Model Class Initialized
INFO - 2024-05-19 13:15:48 --> Model Class Initialized
INFO - 2024-05-19 13:15:49 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\include/admin_home.php
DEBUG - 2024-05-19 13:15:49 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-05-19 13:15:49 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\include/top_menu.php
INFO - 2024-05-19 13:15:49 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\include/admin_loggedin_info.php
INFO - 2024-05-19 13:15:49 --> Model Class Initialized
INFO - 2024-05-19 13:15:50 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\include/admin_header.php
INFO - 2024-05-19 13:15:50 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\include/admin_footer.php
INFO - 2024-05-19 13:15:50 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\admin_html_template.php
INFO - 2024-05-19 13:15:50 --> Final output sent to browser
DEBUG - 2024-05-19 13:15:50 --> Total execution time: 2.2484
ERROR - 2024-05-19 13:15:59 --> $config['composer_autoload'] is set to TRUE but E:\xampp\htdocs\maurnaturo\application\vendor/autoload.php was not found.
INFO - 2024-05-19 13:15:59 --> Config Class Initialized
INFO - 2024-05-19 13:15:59 --> Hooks Class Initialized
DEBUG - 2024-05-19 13:15:59 --> UTF-8 Support Enabled
INFO - 2024-05-19 13:15:59 --> Utf8 Class Initialized
INFO - 2024-05-19 13:15:59 --> URI Class Initialized
DEBUG - 2024-05-19 13:15:59 --> No URI present. Default controller set.
INFO - 2024-05-19 13:15:59 --> Router Class Initialized
INFO - 2024-05-19 13:15:59 --> Output Class Initialized
INFO - 2024-05-19 13:15:59 --> Security Class Initialized
DEBUG - 2024-05-19 13:15:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-19 13:15:59 --> Input Class Initialized
INFO - 2024-05-19 13:15:59 --> Language Class Initialized
INFO - 2024-05-19 13:15:59 --> Loader Class Initialized
INFO - 2024-05-19 13:15:59 --> Helper loaded: url_helper
INFO - 2024-05-19 13:15:59 --> Helper loaded: file_helper
INFO - 2024-05-19 13:15:59 --> Helper loaded: html_helper
INFO - 2024-05-19 13:15:59 --> Helper loaded: text_helper
INFO - 2024-05-19 13:15:59 --> Helper loaded: form_helper
INFO - 2024-05-19 13:15:59 --> Helper loaded: lang_helper
INFO - 2024-05-19 13:15:59 --> Helper loaded: security_helper
INFO - 2024-05-19 13:15:59 --> Helper loaded: cookie_helper
INFO - 2024-05-19 13:15:59 --> Database Driver Class Initialized
INFO - 2024-05-19 13:15:59 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-19 13:15:59 --> Parser Class Initialized
INFO - 2024-05-19 13:15:59 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-05-19 13:15:59 --> Pagination Class Initialized
INFO - 2024-05-19 13:15:59 --> Form Validation Class Initialized
INFO - 2024-05-19 13:15:59 --> Controller Class Initialized
INFO - 2024-05-19 13:15:59 --> Model Class Initialized
DEBUG - 2024-05-19 13:15:59 --> Session class already loaded. Second attempt ignored.
INFO - 2024-05-19 13:15:59 --> Model Class Initialized
DEBUG - 2024-05-19 13:15:59 --> Session class already loaded. Second attempt ignored.
INFO - 2024-05-19 13:15:59 --> Model Class Initialized
INFO - 2024-05-19 13:15:59 --> Model Class Initialized
INFO - 2024-05-19 13:15:59 --> Model Class Initialized
INFO - 2024-05-19 13:15:59 --> Model Class Initialized
DEBUG - 2024-05-19 13:15:59 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-05-19 13:15:59 --> Session class already loaded. Second attempt ignored.
INFO - 2024-05-19 13:15:59 --> Model Class Initialized
INFO - 2024-05-19 13:15:59 --> Model Class Initialized
INFO - 2024-05-19 13:16:00 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\include/admin_home.php
DEBUG - 2024-05-19 13:16:00 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-05-19 13:16:00 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\include/top_menu.php
INFO - 2024-05-19 13:16:00 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\include/admin_loggedin_info.php
INFO - 2024-05-19 13:16:00 --> Model Class Initialized
INFO - 2024-05-19 13:16:02 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\include/admin_header.php
INFO - 2024-05-19 13:16:02 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\include/admin_footer.php
INFO - 2024-05-19 13:16:02 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\admin_html_template.php
INFO - 2024-05-19 13:16:02 --> Final output sent to browser
DEBUG - 2024-05-19 13:16:02 --> Total execution time: 2.8121
ERROR - 2024-05-19 13:16:57 --> $config['composer_autoload'] is set to TRUE but E:\xampp\htdocs\maurnaturo\application\vendor/autoload.php was not found.
INFO - 2024-05-19 13:16:57 --> Config Class Initialized
INFO - 2024-05-19 13:16:57 --> Hooks Class Initialized
DEBUG - 2024-05-19 13:16:57 --> UTF-8 Support Enabled
INFO - 2024-05-19 13:16:57 --> Utf8 Class Initialized
INFO - 2024-05-19 13:16:57 --> URI Class Initialized
DEBUG - 2024-05-19 13:16:57 --> No URI present. Default controller set.
INFO - 2024-05-19 13:16:57 --> Router Class Initialized
INFO - 2024-05-19 13:16:57 --> Output Class Initialized
INFO - 2024-05-19 13:16:57 --> Security Class Initialized
DEBUG - 2024-05-19 13:16:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-19 13:16:57 --> Input Class Initialized
INFO - 2024-05-19 13:16:57 --> Language Class Initialized
INFO - 2024-05-19 13:16:57 --> Loader Class Initialized
INFO - 2024-05-19 13:16:57 --> Helper loaded: url_helper
INFO - 2024-05-19 13:16:57 --> Helper loaded: file_helper
INFO - 2024-05-19 13:16:57 --> Helper loaded: html_helper
INFO - 2024-05-19 13:16:57 --> Helper loaded: text_helper
INFO - 2024-05-19 13:16:57 --> Helper loaded: form_helper
INFO - 2024-05-19 13:16:57 --> Helper loaded: lang_helper
INFO - 2024-05-19 13:16:57 --> Helper loaded: security_helper
INFO - 2024-05-19 13:16:57 --> Helper loaded: cookie_helper
INFO - 2024-05-19 13:16:57 --> Database Driver Class Initialized
INFO - 2024-05-19 13:16:57 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-19 13:16:57 --> Parser Class Initialized
INFO - 2024-05-19 13:16:57 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-05-19 13:16:57 --> Pagination Class Initialized
INFO - 2024-05-19 13:16:57 --> Form Validation Class Initialized
INFO - 2024-05-19 13:16:57 --> Controller Class Initialized
INFO - 2024-05-19 13:16:57 --> Model Class Initialized
DEBUG - 2024-05-19 13:16:57 --> Session class already loaded. Second attempt ignored.
INFO - 2024-05-19 13:16:57 --> Model Class Initialized
DEBUG - 2024-05-19 13:16:57 --> Session class already loaded. Second attempt ignored.
INFO - 2024-05-19 13:16:57 --> Model Class Initialized
INFO - 2024-05-19 13:16:57 --> Model Class Initialized
INFO - 2024-05-19 13:16:57 --> Model Class Initialized
INFO - 2024-05-19 13:16:57 --> Model Class Initialized
DEBUG - 2024-05-19 13:16:57 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-05-19 13:16:57 --> Session class already loaded. Second attempt ignored.
INFO - 2024-05-19 13:16:57 --> Model Class Initialized
INFO - 2024-05-19 13:16:57 --> Model Class Initialized
INFO - 2024-05-19 13:16:58 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\include/admin_home.php
DEBUG - 2024-05-19 13:16:58 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-05-19 13:16:58 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\include/top_menu.php
INFO - 2024-05-19 13:16:58 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\include/admin_loggedin_info.php
INFO - 2024-05-19 13:16:58 --> Model Class Initialized
INFO - 2024-05-19 13:17:00 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\include/admin_header.php
INFO - 2024-05-19 13:17:00 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\include/admin_footer.php
INFO - 2024-05-19 13:17:00 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\admin_html_template.php
INFO - 2024-05-19 13:17:00 --> Final output sent to browser
DEBUG - 2024-05-19 13:17:00 --> Total execution time: 2.5002
ERROR - 2024-05-19 13:18:26 --> $config['composer_autoload'] is set to TRUE but E:\xampp\htdocs\maurnaturo\application\vendor/autoload.php was not found.
INFO - 2024-05-19 13:18:26 --> Config Class Initialized
INFO - 2024-05-19 13:18:26 --> Hooks Class Initialized
DEBUG - 2024-05-19 13:18:26 --> UTF-8 Support Enabled
INFO - 2024-05-19 13:18:26 --> Utf8 Class Initialized
INFO - 2024-05-19 13:18:26 --> URI Class Initialized
DEBUG - 2024-05-19 13:18:26 --> No URI present. Default controller set.
INFO - 2024-05-19 13:18:26 --> Router Class Initialized
INFO - 2024-05-19 13:18:26 --> Output Class Initialized
INFO - 2024-05-19 13:18:26 --> Security Class Initialized
DEBUG - 2024-05-19 13:18:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-19 13:18:26 --> Input Class Initialized
INFO - 2024-05-19 13:18:26 --> Language Class Initialized
INFO - 2024-05-19 13:18:26 --> Loader Class Initialized
INFO - 2024-05-19 13:18:26 --> Helper loaded: url_helper
INFO - 2024-05-19 13:18:26 --> Helper loaded: file_helper
INFO - 2024-05-19 13:18:26 --> Helper loaded: html_helper
INFO - 2024-05-19 13:18:26 --> Helper loaded: text_helper
INFO - 2024-05-19 13:18:26 --> Helper loaded: form_helper
INFO - 2024-05-19 13:18:26 --> Helper loaded: lang_helper
INFO - 2024-05-19 13:18:26 --> Helper loaded: security_helper
INFO - 2024-05-19 13:18:26 --> Helper loaded: cookie_helper
INFO - 2024-05-19 13:18:26 --> Database Driver Class Initialized
INFO - 2024-05-19 13:18:26 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-19 13:18:26 --> Parser Class Initialized
INFO - 2024-05-19 13:18:26 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-05-19 13:18:26 --> Pagination Class Initialized
INFO - 2024-05-19 13:18:26 --> Form Validation Class Initialized
INFO - 2024-05-19 13:18:26 --> Controller Class Initialized
INFO - 2024-05-19 13:18:26 --> Model Class Initialized
DEBUG - 2024-05-19 13:18:26 --> Session class already loaded. Second attempt ignored.
INFO - 2024-05-19 13:18:26 --> Model Class Initialized
DEBUG - 2024-05-19 13:18:26 --> Session class already loaded. Second attempt ignored.
INFO - 2024-05-19 13:18:26 --> Model Class Initialized
INFO - 2024-05-19 13:18:26 --> Model Class Initialized
INFO - 2024-05-19 13:18:26 --> Model Class Initialized
INFO - 2024-05-19 13:18:26 --> Model Class Initialized
DEBUG - 2024-05-19 13:18:26 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-05-19 13:18:26 --> Session class already loaded. Second attempt ignored.
INFO - 2024-05-19 13:18:26 --> Model Class Initialized
INFO - 2024-05-19 13:18:26 --> Model Class Initialized
INFO - 2024-05-19 13:18:28 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\include/admin_home.php
DEBUG - 2024-05-19 13:18:28 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-05-19 13:18:28 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\include/top_menu.php
INFO - 2024-05-19 13:18:28 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\include/admin_loggedin_info.php
INFO - 2024-05-19 13:18:28 --> Model Class Initialized
INFO - 2024-05-19 13:18:29 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\include/admin_header.php
INFO - 2024-05-19 13:18:29 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\include/admin_footer.php
INFO - 2024-05-19 13:18:29 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\admin_html_template.php
INFO - 2024-05-19 13:18:29 --> Final output sent to browser
DEBUG - 2024-05-19 13:18:29 --> Total execution time: 2.5390
ERROR - 2024-05-19 13:19:32 --> $config['composer_autoload'] is set to TRUE but E:\xampp\htdocs\maurnaturo\application\vendor/autoload.php was not found.
INFO - 2024-05-19 13:19:32 --> Config Class Initialized
INFO - 2024-05-19 13:19:32 --> Hooks Class Initialized
DEBUG - 2024-05-19 13:19:32 --> UTF-8 Support Enabled
INFO - 2024-05-19 13:19:32 --> Utf8 Class Initialized
INFO - 2024-05-19 13:19:32 --> URI Class Initialized
DEBUG - 2024-05-19 13:19:32 --> No URI present. Default controller set.
INFO - 2024-05-19 13:19:32 --> Router Class Initialized
INFO - 2024-05-19 13:19:32 --> Output Class Initialized
INFO - 2024-05-19 13:19:32 --> Security Class Initialized
DEBUG - 2024-05-19 13:19:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-19 13:19:32 --> Input Class Initialized
INFO - 2024-05-19 13:19:32 --> Language Class Initialized
INFO - 2024-05-19 13:19:32 --> Loader Class Initialized
INFO - 2024-05-19 13:19:32 --> Helper loaded: url_helper
INFO - 2024-05-19 13:19:32 --> Helper loaded: file_helper
INFO - 2024-05-19 13:19:32 --> Helper loaded: html_helper
INFO - 2024-05-19 13:19:32 --> Helper loaded: text_helper
INFO - 2024-05-19 13:19:32 --> Helper loaded: form_helper
INFO - 2024-05-19 13:19:32 --> Helper loaded: lang_helper
INFO - 2024-05-19 13:19:32 --> Helper loaded: security_helper
INFO - 2024-05-19 13:19:32 --> Helper loaded: cookie_helper
INFO - 2024-05-19 13:19:32 --> Database Driver Class Initialized
INFO - 2024-05-19 13:19:32 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-19 13:19:32 --> Parser Class Initialized
INFO - 2024-05-19 13:19:32 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-05-19 13:19:32 --> Pagination Class Initialized
INFO - 2024-05-19 13:19:32 --> Form Validation Class Initialized
INFO - 2024-05-19 13:19:32 --> Controller Class Initialized
INFO - 2024-05-19 13:19:32 --> Model Class Initialized
DEBUG - 2024-05-19 13:19:32 --> Session class already loaded. Second attempt ignored.
INFO - 2024-05-19 13:19:32 --> Model Class Initialized
DEBUG - 2024-05-19 13:19:32 --> Session class already loaded. Second attempt ignored.
INFO - 2024-05-19 13:19:32 --> Model Class Initialized
INFO - 2024-05-19 13:19:32 --> Model Class Initialized
INFO - 2024-05-19 13:19:32 --> Model Class Initialized
INFO - 2024-05-19 13:19:32 --> Model Class Initialized
DEBUG - 2024-05-19 13:19:32 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-05-19 13:19:32 --> Session class already loaded. Second attempt ignored.
INFO - 2024-05-19 13:19:32 --> Model Class Initialized
INFO - 2024-05-19 13:19:32 --> Model Class Initialized
INFO - 2024-05-19 13:19:33 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\include/admin_home.php
DEBUG - 2024-05-19 13:19:33 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-05-19 13:19:33 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\include/top_menu.php
INFO - 2024-05-19 13:19:33 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\include/admin_loggedin_info.php
INFO - 2024-05-19 13:19:33 --> Model Class Initialized
INFO - 2024-05-19 13:19:34 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\include/admin_header.php
INFO - 2024-05-19 13:19:34 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\include/admin_footer.php
INFO - 2024-05-19 13:19:34 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\admin_html_template.php
INFO - 2024-05-19 13:19:34 --> Final output sent to browser
DEBUG - 2024-05-19 13:19:34 --> Total execution time: 2.2764
ERROR - 2024-05-19 13:20:07 --> $config['composer_autoload'] is set to TRUE but E:\xampp\htdocs\maurnaturo\application\vendor/autoload.php was not found.
INFO - 2024-05-19 13:20:07 --> Config Class Initialized
INFO - 2024-05-19 13:20:07 --> Hooks Class Initialized
DEBUG - 2024-05-19 13:20:07 --> UTF-8 Support Enabled
INFO - 2024-05-19 13:20:07 --> Utf8 Class Initialized
INFO - 2024-05-19 13:20:07 --> URI Class Initialized
DEBUG - 2024-05-19 13:20:07 --> No URI present. Default controller set.
INFO - 2024-05-19 13:20:07 --> Router Class Initialized
INFO - 2024-05-19 13:20:07 --> Output Class Initialized
INFO - 2024-05-19 13:20:07 --> Security Class Initialized
DEBUG - 2024-05-19 13:20:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-19 13:20:07 --> Input Class Initialized
INFO - 2024-05-19 13:20:07 --> Language Class Initialized
INFO - 2024-05-19 13:20:07 --> Loader Class Initialized
INFO - 2024-05-19 13:20:07 --> Helper loaded: url_helper
INFO - 2024-05-19 13:20:07 --> Helper loaded: file_helper
INFO - 2024-05-19 13:20:07 --> Helper loaded: html_helper
INFO - 2024-05-19 13:20:07 --> Helper loaded: text_helper
INFO - 2024-05-19 13:20:07 --> Helper loaded: form_helper
INFO - 2024-05-19 13:20:07 --> Helper loaded: lang_helper
INFO - 2024-05-19 13:20:07 --> Helper loaded: security_helper
INFO - 2024-05-19 13:20:07 --> Helper loaded: cookie_helper
INFO - 2024-05-19 13:20:07 --> Database Driver Class Initialized
INFO - 2024-05-19 13:20:07 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-19 13:20:07 --> Parser Class Initialized
INFO - 2024-05-19 13:20:07 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-05-19 13:20:07 --> Pagination Class Initialized
INFO - 2024-05-19 13:20:07 --> Form Validation Class Initialized
INFO - 2024-05-19 13:20:07 --> Controller Class Initialized
INFO - 2024-05-19 13:20:07 --> Model Class Initialized
DEBUG - 2024-05-19 13:20:07 --> Session class already loaded. Second attempt ignored.
INFO - 2024-05-19 13:20:07 --> Model Class Initialized
DEBUG - 2024-05-19 13:20:07 --> Session class already loaded. Second attempt ignored.
INFO - 2024-05-19 13:20:07 --> Model Class Initialized
INFO - 2024-05-19 13:20:07 --> Model Class Initialized
INFO - 2024-05-19 13:20:07 --> Model Class Initialized
INFO - 2024-05-19 13:20:07 --> Model Class Initialized
DEBUG - 2024-05-19 13:20:07 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-05-19 13:20:07 --> Session class already loaded. Second attempt ignored.
INFO - 2024-05-19 13:20:07 --> Model Class Initialized
INFO - 2024-05-19 13:20:07 --> Model Class Initialized
INFO - 2024-05-19 13:20:09 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\include/admin_home.php
DEBUG - 2024-05-19 13:20:09 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-05-19 13:20:09 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\include/top_menu.php
INFO - 2024-05-19 13:20:09 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\include/admin_loggedin_info.php
INFO - 2024-05-19 13:20:09 --> Model Class Initialized
INFO - 2024-05-19 13:20:11 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\include/admin_header.php
INFO - 2024-05-19 13:20:11 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\include/admin_footer.php
INFO - 2024-05-19 13:20:11 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\admin_html_template.php
INFO - 2024-05-19 13:20:11 --> Final output sent to browser
DEBUG - 2024-05-19 13:20:11 --> Total execution time: 3.6007
ERROR - 2024-05-19 13:20:45 --> $config['composer_autoload'] is set to TRUE but E:\xampp\htdocs\maurnaturo\application\vendor/autoload.php was not found.
INFO - 2024-05-19 13:20:45 --> Config Class Initialized
INFO - 2024-05-19 13:20:45 --> Hooks Class Initialized
DEBUG - 2024-05-19 13:20:45 --> UTF-8 Support Enabled
INFO - 2024-05-19 13:20:45 --> Utf8 Class Initialized
INFO - 2024-05-19 13:20:45 --> URI Class Initialized
DEBUG - 2024-05-19 13:20:45 --> No URI present. Default controller set.
INFO - 2024-05-19 13:20:45 --> Router Class Initialized
INFO - 2024-05-19 13:20:45 --> Output Class Initialized
INFO - 2024-05-19 13:20:45 --> Security Class Initialized
DEBUG - 2024-05-19 13:20:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-19 13:20:45 --> Input Class Initialized
INFO - 2024-05-19 13:20:45 --> Language Class Initialized
INFO - 2024-05-19 13:20:45 --> Loader Class Initialized
INFO - 2024-05-19 13:20:45 --> Helper loaded: url_helper
INFO - 2024-05-19 13:20:45 --> Helper loaded: file_helper
INFO - 2024-05-19 13:20:45 --> Helper loaded: html_helper
INFO - 2024-05-19 13:20:45 --> Helper loaded: text_helper
INFO - 2024-05-19 13:20:45 --> Helper loaded: form_helper
INFO - 2024-05-19 13:20:45 --> Helper loaded: lang_helper
INFO - 2024-05-19 13:20:45 --> Helper loaded: security_helper
INFO - 2024-05-19 13:20:45 --> Helper loaded: cookie_helper
INFO - 2024-05-19 13:20:45 --> Database Driver Class Initialized
INFO - 2024-05-19 13:20:45 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-19 13:20:45 --> Parser Class Initialized
INFO - 2024-05-19 13:20:45 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-05-19 13:20:45 --> Pagination Class Initialized
INFO - 2024-05-19 13:20:45 --> Form Validation Class Initialized
INFO - 2024-05-19 13:20:45 --> Controller Class Initialized
INFO - 2024-05-19 13:20:45 --> Model Class Initialized
DEBUG - 2024-05-19 13:20:45 --> Session class already loaded. Second attempt ignored.
INFO - 2024-05-19 13:20:45 --> Model Class Initialized
DEBUG - 2024-05-19 13:20:45 --> Session class already loaded. Second attempt ignored.
INFO - 2024-05-19 13:20:45 --> Model Class Initialized
INFO - 2024-05-19 13:20:45 --> Model Class Initialized
INFO - 2024-05-19 13:20:45 --> Model Class Initialized
INFO - 2024-05-19 13:20:45 --> Model Class Initialized
DEBUG - 2024-05-19 13:20:45 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-05-19 13:20:45 --> Session class already loaded. Second attempt ignored.
INFO - 2024-05-19 13:20:45 --> Model Class Initialized
INFO - 2024-05-19 13:20:45 --> Model Class Initialized
INFO - 2024-05-19 13:20:46 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\include/admin_home.php
DEBUG - 2024-05-19 13:20:46 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-05-19 13:20:46 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\include/top_menu.php
INFO - 2024-05-19 13:20:46 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\include/admin_loggedin_info.php
INFO - 2024-05-19 13:20:46 --> Model Class Initialized
INFO - 2024-05-19 13:20:47 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\include/admin_header.php
INFO - 2024-05-19 13:20:47 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\include/admin_footer.php
INFO - 2024-05-19 13:20:47 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\admin_html_template.php
INFO - 2024-05-19 13:20:47 --> Final output sent to browser
DEBUG - 2024-05-19 13:20:47 --> Total execution time: 2.4064
ERROR - 2024-05-19 13:21:03 --> $config['composer_autoload'] is set to TRUE but E:\xampp\htdocs\maurnaturo\application\vendor/autoload.php was not found.
INFO - 2024-05-19 13:21:03 --> Config Class Initialized
INFO - 2024-05-19 13:21:03 --> Hooks Class Initialized
DEBUG - 2024-05-19 13:21:03 --> UTF-8 Support Enabled
INFO - 2024-05-19 13:21:03 --> Utf8 Class Initialized
INFO - 2024-05-19 13:21:03 --> URI Class Initialized
INFO - 2024-05-19 13:21:03 --> Router Class Initialized
INFO - 2024-05-19 13:21:03 --> Output Class Initialized
INFO - 2024-05-19 13:21:03 --> Security Class Initialized
DEBUG - 2024-05-19 13:21:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-19 13:21:03 --> Input Class Initialized
INFO - 2024-05-19 13:21:03 --> Language Class Initialized
INFO - 2024-05-19 13:21:03 --> Loader Class Initialized
INFO - 2024-05-19 13:21:03 --> Helper loaded: url_helper
INFO - 2024-05-19 13:21:03 --> Helper loaded: file_helper
INFO - 2024-05-19 13:21:03 --> Helper loaded: html_helper
INFO - 2024-05-19 13:21:03 --> Helper loaded: text_helper
INFO - 2024-05-19 13:21:03 --> Helper loaded: form_helper
INFO - 2024-05-19 13:21:03 --> Helper loaded: lang_helper
INFO - 2024-05-19 13:21:03 --> Helper loaded: security_helper
INFO - 2024-05-19 13:21:03 --> Helper loaded: cookie_helper
INFO - 2024-05-19 13:21:03 --> Database Driver Class Initialized
INFO - 2024-05-19 13:21:03 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-19 13:21:03 --> Parser Class Initialized
INFO - 2024-05-19 13:21:03 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-05-19 13:21:03 --> Pagination Class Initialized
INFO - 2024-05-19 13:21:03 --> Form Validation Class Initialized
INFO - 2024-05-19 13:21:03 --> Controller Class Initialized
DEBUG - 2024-05-19 13:21:03 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-05-19 13:21:03 --> Session class already loaded. Second attempt ignored.
INFO - 2024-05-19 13:21:03 --> Model Class Initialized
INFO - 2024-05-19 13:21:03 --> Model Class Initialized
DEBUG - 2024-05-19 13:21:03 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-05-19 13:21:03 --> Session class already loaded. Second attempt ignored.
INFO - 2024-05-19 13:21:03 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\payments/add_payment_form.php
DEBUG - 2024-05-19 13:21:03 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-05-19 13:21:03 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\include/top_menu.php
INFO - 2024-05-19 13:21:03 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\include/admin_loggedin_info.php
INFO - 2024-05-19 13:21:03 --> Model Class Initialized
INFO - 2024-05-19 13:21:03 --> Model Class Initialized
INFO - 2024-05-19 13:21:03 --> Model Class Initialized
INFO - 2024-05-19 13:21:03 --> Model Class Initialized
INFO - 2024-05-19 13:21:04 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\include/admin_header.php
INFO - 2024-05-19 13:21:04 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\include/admin_footer.php
INFO - 2024-05-19 13:21:04 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\admin_html_template.php
INFO - 2024-05-19 13:21:04 --> Final output sent to browser
DEBUG - 2024-05-19 13:21:04 --> Total execution time: 1.1704
ERROR - 2024-05-19 13:21:16 --> $config['composer_autoload'] is set to TRUE but E:\xampp\htdocs\maurnaturo\application\vendor/autoload.php was not found.
INFO - 2024-05-19 13:21:16 --> Config Class Initialized
INFO - 2024-05-19 13:21:16 --> Hooks Class Initialized
DEBUG - 2024-05-19 13:21:16 --> UTF-8 Support Enabled
INFO - 2024-05-19 13:21:16 --> Utf8 Class Initialized
INFO - 2024-05-19 13:21:16 --> URI Class Initialized
INFO - 2024-05-19 13:21:16 --> Router Class Initialized
INFO - 2024-05-19 13:21:16 --> Output Class Initialized
INFO - 2024-05-19 13:21:16 --> Security Class Initialized
DEBUG - 2024-05-19 13:21:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-19 13:21:16 --> Input Class Initialized
INFO - 2024-05-19 13:21:16 --> Language Class Initialized
INFO - 2024-05-19 13:21:16 --> Loader Class Initialized
INFO - 2024-05-19 13:21:16 --> Helper loaded: url_helper
INFO - 2024-05-19 13:21:16 --> Helper loaded: file_helper
INFO - 2024-05-19 13:21:16 --> Helper loaded: html_helper
INFO - 2024-05-19 13:21:16 --> Helper loaded: text_helper
INFO - 2024-05-19 13:21:16 --> Helper loaded: form_helper
INFO - 2024-05-19 13:21:16 --> Helper loaded: lang_helper
INFO - 2024-05-19 13:21:16 --> Helper loaded: security_helper
INFO - 2024-05-19 13:21:16 --> Helper loaded: cookie_helper
INFO - 2024-05-19 13:21:16 --> Database Driver Class Initialized
INFO - 2024-05-19 13:21:16 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-19 13:21:16 --> Parser Class Initialized
INFO - 2024-05-19 13:21:16 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-05-19 13:21:16 --> Pagination Class Initialized
INFO - 2024-05-19 13:21:16 --> Form Validation Class Initialized
INFO - 2024-05-19 13:21:16 --> Controller Class Initialized
DEBUG - 2024-05-19 13:21:16 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-05-19 13:21:16 --> Session class already loaded. Second attempt ignored.
INFO - 2024-05-19 13:21:16 --> Model Class Initialized
DEBUG - 2024-05-19 13:21:16 --> Session class already loaded. Second attempt ignored.
INFO - 2024-05-19 13:21:16 --> Model Class Initialized
DEBUG - 2024-05-19 13:21:16 --> Lcustomer class already loaded. Second attempt ignored.
INFO - 2024-05-19 13:21:16 --> Model Class Initialized
INFO - 2024-05-19 13:21:16 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\customer/customer.php
DEBUG - 2024-05-19 13:21:16 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-05-19 13:21:16 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\include/top_menu.php
INFO - 2024-05-19 13:21:16 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\include/admin_loggedin_info.php
INFO - 2024-05-19 13:21:16 --> Model Class Initialized
INFO - 2024-05-19 13:21:16 --> Model Class Initialized
INFO - 2024-05-19 13:21:16 --> Model Class Initialized
INFO - 2024-05-19 13:21:18 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\include/admin_header.php
INFO - 2024-05-19 13:21:18 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\include/admin_footer.php
INFO - 2024-05-19 13:21:18 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\admin_html_template.php
INFO - 2024-05-19 13:21:18 --> Final output sent to browser
DEBUG - 2024-05-19 13:21:18 --> Total execution time: 1.2765
ERROR - 2024-05-19 13:21:18 --> $config['composer_autoload'] is set to TRUE but E:\xampp\htdocs\maurnaturo\application\vendor/autoload.php was not found.
INFO - 2024-05-19 13:21:18 --> Config Class Initialized
INFO - 2024-05-19 13:21:18 --> Hooks Class Initialized
DEBUG - 2024-05-19 13:21:18 --> UTF-8 Support Enabled
INFO - 2024-05-19 13:21:18 --> Utf8 Class Initialized
INFO - 2024-05-19 13:21:18 --> URI Class Initialized
INFO - 2024-05-19 13:21:18 --> Router Class Initialized
INFO - 2024-05-19 13:21:18 --> Output Class Initialized
INFO - 2024-05-19 13:21:18 --> Security Class Initialized
DEBUG - 2024-05-19 13:21:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-19 13:21:18 --> Input Class Initialized
INFO - 2024-05-19 13:21:18 --> Language Class Initialized
INFO - 2024-05-19 13:21:18 --> Loader Class Initialized
INFO - 2024-05-19 13:21:18 --> Helper loaded: url_helper
INFO - 2024-05-19 13:21:18 --> Helper loaded: file_helper
INFO - 2024-05-19 13:21:18 --> Helper loaded: html_helper
INFO - 2024-05-19 13:21:18 --> Helper loaded: text_helper
INFO - 2024-05-19 13:21:18 --> Helper loaded: form_helper
INFO - 2024-05-19 13:21:18 --> Helper loaded: lang_helper
INFO - 2024-05-19 13:21:18 --> Helper loaded: security_helper
INFO - 2024-05-19 13:21:18 --> Helper loaded: cookie_helper
INFO - 2024-05-19 13:21:18 --> Database Driver Class Initialized
INFO - 2024-05-19 13:21:18 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-19 13:21:18 --> Parser Class Initialized
INFO - 2024-05-19 13:21:18 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-05-19 13:21:18 --> Pagination Class Initialized
INFO - 2024-05-19 13:21:18 --> Form Validation Class Initialized
INFO - 2024-05-19 13:21:18 --> Controller Class Initialized
DEBUG - 2024-05-19 13:21:18 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-05-19 13:21:18 --> Session class already loaded. Second attempt ignored.
INFO - 2024-05-19 13:21:18 --> Model Class Initialized
DEBUG - 2024-05-19 13:21:18 --> Session class already loaded. Second attempt ignored.
INFO - 2024-05-19 13:21:18 --> Model Class Initialized
INFO - 2024-05-19 13:21:18 --> Final output sent to browser
DEBUG - 2024-05-19 13:21:18 --> Total execution time: 0.1704
ERROR - 2024-05-19 13:21:30 --> $config['composer_autoload'] is set to TRUE but E:\xampp\htdocs\maurnaturo\application\vendor/autoload.php was not found.
INFO - 2024-05-19 13:21:30 --> Config Class Initialized
INFO - 2024-05-19 13:21:30 --> Hooks Class Initialized
DEBUG - 2024-05-19 13:21:30 --> UTF-8 Support Enabled
INFO - 2024-05-19 13:21:30 --> Utf8 Class Initialized
INFO - 2024-05-19 13:21:30 --> URI Class Initialized
INFO - 2024-05-19 13:21:30 --> Router Class Initialized
INFO - 2024-05-19 13:21:30 --> Output Class Initialized
INFO - 2024-05-19 13:21:30 --> Security Class Initialized
DEBUG - 2024-05-19 13:21:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-19 13:21:30 --> Input Class Initialized
INFO - 2024-05-19 13:21:30 --> Language Class Initialized
INFO - 2024-05-19 13:21:30 --> Loader Class Initialized
INFO - 2024-05-19 13:21:30 --> Helper loaded: url_helper
INFO - 2024-05-19 13:21:30 --> Helper loaded: file_helper
INFO - 2024-05-19 13:21:30 --> Helper loaded: html_helper
INFO - 2024-05-19 13:21:30 --> Helper loaded: text_helper
INFO - 2024-05-19 13:21:30 --> Helper loaded: form_helper
INFO - 2024-05-19 13:21:30 --> Helper loaded: lang_helper
INFO - 2024-05-19 13:21:30 --> Helper loaded: security_helper
INFO - 2024-05-19 13:21:30 --> Helper loaded: cookie_helper
INFO - 2024-05-19 13:21:30 --> Database Driver Class Initialized
INFO - 2024-05-19 13:21:30 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-19 13:21:30 --> Parser Class Initialized
INFO - 2024-05-19 13:21:30 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-05-19 13:21:30 --> Pagination Class Initialized
INFO - 2024-05-19 13:21:30 --> Form Validation Class Initialized
INFO - 2024-05-19 13:21:30 --> Controller Class Initialized
DEBUG - 2024-05-19 13:21:30 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-05-19 13:21:30 --> Session class already loaded. Second attempt ignored.
INFO - 2024-05-19 13:21:30 --> Model Class Initialized
DEBUG - 2024-05-19 13:21:30 --> Lpayments class already loaded. Second attempt ignored.
INFO - 2024-05-19 13:21:30 --> Model Class Initialized
INFO - 2024-05-19 13:21:30 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\payments/payment.php
DEBUG - 2024-05-19 13:21:30 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-05-19 13:21:30 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\include/top_menu.php
INFO - 2024-05-19 13:21:30 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\include/admin_loggedin_info.php
INFO - 2024-05-19 13:21:30 --> Model Class Initialized
INFO - 2024-05-19 13:21:30 --> Model Class Initialized
INFO - 2024-05-19 13:21:30 --> Model Class Initialized
INFO - 2024-05-19 13:21:31 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\include/admin_header.php
INFO - 2024-05-19 13:21:31 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\include/admin_footer.php
INFO - 2024-05-19 13:21:31 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\admin_html_template.php
INFO - 2024-05-19 13:21:31 --> Final output sent to browser
DEBUG - 2024-05-19 13:21:31 --> Total execution time: 1.3072
ERROR - 2024-05-19 13:21:31 --> $config['composer_autoload'] is set to TRUE but E:\xampp\htdocs\maurnaturo\application\vendor/autoload.php was not found.
INFO - 2024-05-19 13:21:31 --> Config Class Initialized
INFO - 2024-05-19 13:21:31 --> Hooks Class Initialized
DEBUG - 2024-05-19 13:21:31 --> UTF-8 Support Enabled
INFO - 2024-05-19 13:21:31 --> Utf8 Class Initialized
INFO - 2024-05-19 13:21:31 --> URI Class Initialized
INFO - 2024-05-19 13:21:31 --> Router Class Initialized
INFO - 2024-05-19 13:21:31 --> Output Class Initialized
INFO - 2024-05-19 13:21:31 --> Security Class Initialized
DEBUG - 2024-05-19 13:21:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-19 13:21:31 --> Input Class Initialized
INFO - 2024-05-19 13:21:31 --> Language Class Initialized
INFO - 2024-05-19 13:21:31 --> Loader Class Initialized
INFO - 2024-05-19 13:21:31 --> Helper loaded: url_helper
INFO - 2024-05-19 13:21:31 --> Helper loaded: file_helper
INFO - 2024-05-19 13:21:31 --> Helper loaded: html_helper
INFO - 2024-05-19 13:21:31 --> Helper loaded: text_helper
INFO - 2024-05-19 13:21:31 --> Helper loaded: form_helper
INFO - 2024-05-19 13:21:31 --> Helper loaded: lang_helper
INFO - 2024-05-19 13:21:31 --> Helper loaded: security_helper
INFO - 2024-05-19 13:21:31 --> Helper loaded: cookie_helper
INFO - 2024-05-19 13:21:31 --> Database Driver Class Initialized
INFO - 2024-05-19 13:21:31 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-19 13:21:31 --> Parser Class Initialized
INFO - 2024-05-19 13:21:31 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-05-19 13:21:31 --> Pagination Class Initialized
INFO - 2024-05-19 13:21:31 --> Form Validation Class Initialized
INFO - 2024-05-19 13:21:31 --> Controller Class Initialized
DEBUG - 2024-05-19 13:21:31 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-05-19 13:21:31 --> Session class already loaded. Second attempt ignored.
INFO - 2024-05-19 13:21:31 --> Model Class Initialized
INFO - 2024-05-19 13:21:31 --> Final output sent to browser
DEBUG - 2024-05-19 13:21:31 --> Total execution time: 0.1637
ERROR - 2024-05-19 13:21:33 --> $config['composer_autoload'] is set to TRUE but E:\xampp\htdocs\maurnaturo\application\vendor/autoload.php was not found.
INFO - 2024-05-19 13:21:33 --> Config Class Initialized
INFO - 2024-05-19 13:21:33 --> Hooks Class Initialized
DEBUG - 2024-05-19 13:21:33 --> UTF-8 Support Enabled
INFO - 2024-05-19 13:21:33 --> Utf8 Class Initialized
INFO - 2024-05-19 13:21:33 --> URI Class Initialized
INFO - 2024-05-19 13:21:33 --> Router Class Initialized
INFO - 2024-05-19 13:21:33 --> Output Class Initialized
INFO - 2024-05-19 13:21:33 --> Security Class Initialized
DEBUG - 2024-05-19 13:21:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-19 13:21:33 --> Input Class Initialized
INFO - 2024-05-19 13:21:33 --> Language Class Initialized
INFO - 2024-05-19 13:21:33 --> Loader Class Initialized
INFO - 2024-05-19 13:21:33 --> Helper loaded: url_helper
INFO - 2024-05-19 13:21:33 --> Helper loaded: file_helper
INFO - 2024-05-19 13:21:33 --> Helper loaded: html_helper
INFO - 2024-05-19 13:21:33 --> Helper loaded: text_helper
INFO - 2024-05-19 13:21:33 --> Helper loaded: form_helper
INFO - 2024-05-19 13:21:33 --> Helper loaded: lang_helper
INFO - 2024-05-19 13:21:33 --> Helper loaded: security_helper
INFO - 2024-05-19 13:21:33 --> Helper loaded: cookie_helper
INFO - 2024-05-19 13:21:33 --> Database Driver Class Initialized
INFO - 2024-05-19 13:21:33 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-19 13:21:33 --> Parser Class Initialized
INFO - 2024-05-19 13:21:33 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-05-19 13:21:33 --> Pagination Class Initialized
INFO - 2024-05-19 13:21:33 --> Form Validation Class Initialized
INFO - 2024-05-19 13:21:33 --> Controller Class Initialized
DEBUG - 2024-05-19 13:21:33 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-05-19 13:21:33 --> Session class already loaded. Second attempt ignored.
INFO - 2024-05-19 13:21:33 --> Model Class Initialized
INFO - 2024-05-19 13:21:33 --> Model Class Initialized
DEBUG - 2024-05-19 13:21:33 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-05-19 13:21:33 --> Session class already loaded. Second attempt ignored.
INFO - 2024-05-19 13:21:33 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\payments/add_payment_form.php
DEBUG - 2024-05-19 13:21:33 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-05-19 13:21:33 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\include/top_menu.php
INFO - 2024-05-19 13:21:33 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\include/admin_loggedin_info.php
INFO - 2024-05-19 13:21:33 --> Model Class Initialized
INFO - 2024-05-19 13:21:33 --> Model Class Initialized
INFO - 2024-05-19 13:21:33 --> Model Class Initialized
INFO - 2024-05-19 13:21:33 --> Model Class Initialized
INFO - 2024-05-19 13:21:34 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\include/admin_header.php
INFO - 2024-05-19 13:21:34 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\include/admin_footer.php
INFO - 2024-05-19 13:21:34 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\admin_html_template.php
INFO - 2024-05-19 13:21:34 --> Final output sent to browser
DEBUG - 2024-05-19 13:21:34 --> Total execution time: 1.1204
ERROR - 2024-05-19 13:21:37 --> $config['composer_autoload'] is set to TRUE but E:\xampp\htdocs\maurnaturo\application\vendor/autoload.php was not found.
INFO - 2024-05-19 13:21:37 --> Config Class Initialized
INFO - 2024-05-19 13:21:37 --> Hooks Class Initialized
DEBUG - 2024-05-19 13:21:37 --> UTF-8 Support Enabled
INFO - 2024-05-19 13:21:37 --> Utf8 Class Initialized
INFO - 2024-05-19 13:21:37 --> URI Class Initialized
INFO - 2024-05-19 13:21:37 --> Router Class Initialized
INFO - 2024-05-19 13:21:37 --> Output Class Initialized
INFO - 2024-05-19 13:21:37 --> Security Class Initialized
DEBUG - 2024-05-19 13:21:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-19 13:21:37 --> Input Class Initialized
INFO - 2024-05-19 13:21:37 --> Language Class Initialized
INFO - 2024-05-19 13:21:37 --> Loader Class Initialized
INFO - 2024-05-19 13:21:37 --> Helper loaded: url_helper
INFO - 2024-05-19 13:21:37 --> Helper loaded: file_helper
INFO - 2024-05-19 13:21:37 --> Helper loaded: html_helper
INFO - 2024-05-19 13:21:37 --> Helper loaded: text_helper
INFO - 2024-05-19 13:21:37 --> Helper loaded: form_helper
INFO - 2024-05-19 13:21:37 --> Helper loaded: lang_helper
INFO - 2024-05-19 13:21:37 --> Helper loaded: security_helper
INFO - 2024-05-19 13:21:37 --> Helper loaded: cookie_helper
INFO - 2024-05-19 13:21:37 --> Database Driver Class Initialized
INFO - 2024-05-19 13:21:37 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-19 13:21:37 --> Parser Class Initialized
INFO - 2024-05-19 13:21:37 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-05-19 13:21:37 --> Pagination Class Initialized
INFO - 2024-05-19 13:21:37 --> Form Validation Class Initialized
INFO - 2024-05-19 13:21:37 --> Controller Class Initialized
INFO - 2024-05-19 13:21:37 --> Model Class Initialized
DEBUG - 2024-05-19 13:21:37 --> Session class already loaded. Second attempt ignored.
INFO - 2024-05-19 13:21:37 --> Final output sent to browser
DEBUG - 2024-05-19 13:21:37 --> Total execution time: 0.0694
ERROR - 2024-05-19 13:21:38 --> $config['composer_autoload'] is set to TRUE but E:\xampp\htdocs\maurnaturo\application\vendor/autoload.php was not found.
INFO - 2024-05-19 13:21:38 --> Config Class Initialized
INFO - 2024-05-19 13:21:38 --> Hooks Class Initialized
DEBUG - 2024-05-19 13:21:38 --> UTF-8 Support Enabled
INFO - 2024-05-19 13:21:38 --> Utf8 Class Initialized
INFO - 2024-05-19 13:21:39 --> URI Class Initialized
INFO - 2024-05-19 13:21:39 --> Router Class Initialized
INFO - 2024-05-19 13:21:39 --> Output Class Initialized
INFO - 2024-05-19 13:21:39 --> Security Class Initialized
DEBUG - 2024-05-19 13:21:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-19 13:21:39 --> Input Class Initialized
INFO - 2024-05-19 13:21:39 --> Language Class Initialized
INFO - 2024-05-19 13:21:39 --> Loader Class Initialized
INFO - 2024-05-19 13:21:39 --> Helper loaded: url_helper
INFO - 2024-05-19 13:21:39 --> Helper loaded: file_helper
INFO - 2024-05-19 13:21:39 --> Helper loaded: html_helper
INFO - 2024-05-19 13:21:39 --> Helper loaded: text_helper
INFO - 2024-05-19 13:21:39 --> Helper loaded: form_helper
INFO - 2024-05-19 13:21:39 --> Helper loaded: lang_helper
INFO - 2024-05-19 13:21:39 --> Helper loaded: security_helper
INFO - 2024-05-19 13:21:39 --> Helper loaded: cookie_helper
INFO - 2024-05-19 13:21:39 --> Database Driver Class Initialized
INFO - 2024-05-19 13:21:39 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-19 13:21:39 --> Parser Class Initialized
INFO - 2024-05-19 13:21:39 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-05-19 13:21:39 --> Pagination Class Initialized
INFO - 2024-05-19 13:21:39 --> Form Validation Class Initialized
INFO - 2024-05-19 13:21:39 --> Controller Class Initialized
INFO - 2024-05-19 13:21:39 --> Model Class Initialized
DEBUG - 2024-05-19 13:21:39 --> Session class already loaded. Second attempt ignored.
INFO - 2024-05-19 13:21:39 --> Final output sent to browser
DEBUG - 2024-05-19 13:21:39 --> Total execution time: 0.0642
ERROR - 2024-05-19 13:21:55 --> $config['composer_autoload'] is set to TRUE but E:\xampp\htdocs\maurnaturo\application\vendor/autoload.php was not found.
INFO - 2024-05-19 13:21:55 --> Config Class Initialized
INFO - 2024-05-19 13:21:55 --> Hooks Class Initialized
DEBUG - 2024-05-19 13:21:55 --> UTF-8 Support Enabled
INFO - 2024-05-19 13:21:55 --> Utf8 Class Initialized
INFO - 2024-05-19 13:21:55 --> URI Class Initialized
INFO - 2024-05-19 13:21:55 --> Router Class Initialized
INFO - 2024-05-19 13:21:55 --> Output Class Initialized
INFO - 2024-05-19 13:21:55 --> Security Class Initialized
DEBUG - 2024-05-19 13:21:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-19 13:21:55 --> Input Class Initialized
INFO - 2024-05-19 13:21:55 --> Language Class Initialized
INFO - 2024-05-19 13:21:55 --> Loader Class Initialized
INFO - 2024-05-19 13:21:55 --> Helper loaded: url_helper
INFO - 2024-05-19 13:21:55 --> Helper loaded: file_helper
INFO - 2024-05-19 13:21:55 --> Helper loaded: html_helper
INFO - 2024-05-19 13:21:55 --> Helper loaded: text_helper
INFO - 2024-05-19 13:21:55 --> Helper loaded: form_helper
INFO - 2024-05-19 13:21:55 --> Helper loaded: lang_helper
INFO - 2024-05-19 13:21:55 --> Helper loaded: security_helper
INFO - 2024-05-19 13:21:55 --> Helper loaded: cookie_helper
INFO - 2024-05-19 13:21:55 --> Database Driver Class Initialized
INFO - 2024-05-19 13:21:55 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-19 13:21:55 --> Parser Class Initialized
INFO - 2024-05-19 13:21:55 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-05-19 13:21:55 --> Pagination Class Initialized
INFO - 2024-05-19 13:21:55 --> Form Validation Class Initialized
INFO - 2024-05-19 13:21:55 --> Controller Class Initialized
DEBUG - 2024-05-19 13:21:55 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-05-19 13:21:55 --> Session class already loaded. Second attempt ignored.
INFO - 2024-05-19 13:21:55 --> Model Class Initialized
INFO - 2024-05-19 13:21:55 --> Final output sent to browser
DEBUG - 2024-05-19 13:21:55 --> Total execution time: 0.0952
ERROR - 2024-05-19 13:21:59 --> $config['composer_autoload'] is set to TRUE but E:\xampp\htdocs\maurnaturo\application\vendor/autoload.php was not found.
INFO - 2024-05-19 13:21:59 --> Config Class Initialized
INFO - 2024-05-19 13:21:59 --> Hooks Class Initialized
DEBUG - 2024-05-19 13:21:59 --> UTF-8 Support Enabled
INFO - 2024-05-19 13:21:59 --> Utf8 Class Initialized
INFO - 2024-05-19 13:21:59 --> URI Class Initialized
INFO - 2024-05-19 13:22:00 --> Router Class Initialized
INFO - 2024-05-19 13:22:00 --> Output Class Initialized
INFO - 2024-05-19 13:22:00 --> Security Class Initialized
DEBUG - 2024-05-19 13:22:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-19 13:22:00 --> Input Class Initialized
INFO - 2024-05-19 13:22:00 --> Language Class Initialized
INFO - 2024-05-19 13:22:00 --> Loader Class Initialized
INFO - 2024-05-19 13:22:00 --> Helper loaded: url_helper
INFO - 2024-05-19 13:22:00 --> Helper loaded: file_helper
INFO - 2024-05-19 13:22:00 --> Helper loaded: html_helper
INFO - 2024-05-19 13:22:00 --> Helper loaded: text_helper
INFO - 2024-05-19 13:22:00 --> Helper loaded: form_helper
INFO - 2024-05-19 13:22:00 --> Helper loaded: lang_helper
INFO - 2024-05-19 13:22:00 --> Helper loaded: security_helper
INFO - 2024-05-19 13:22:00 --> Helper loaded: cookie_helper
INFO - 2024-05-19 13:22:00 --> Database Driver Class Initialized
INFO - 2024-05-19 13:22:00 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-19 13:22:00 --> Parser Class Initialized
INFO - 2024-05-19 13:22:00 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-05-19 13:22:00 --> Pagination Class Initialized
INFO - 2024-05-19 13:22:00 --> Form Validation Class Initialized
INFO - 2024-05-19 13:22:00 --> Controller Class Initialized
DEBUG - 2024-05-19 13:22:00 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-05-19 13:22:00 --> Session class already loaded. Second attempt ignored.
INFO - 2024-05-19 13:22:00 --> Model Class Initialized
INFO - 2024-05-19 13:22:00 --> Model Class Initialized
DEBUG - 2024-05-19 13:22:00 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-05-19 13:22:00 --> Session class already loaded. Second attempt ignored.
INFO - 2024-05-19 13:22:00 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\payments/add_payment_form.php
DEBUG - 2024-05-19 13:22:00 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-05-19 13:22:00 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\include/top_menu.php
INFO - 2024-05-19 13:22:00 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\include/admin_loggedin_info.php
INFO - 2024-05-19 13:22:00 --> Model Class Initialized
INFO - 2024-05-19 13:22:00 --> Model Class Initialized
INFO - 2024-05-19 13:22:00 --> Model Class Initialized
INFO - 2024-05-19 13:22:00 --> Model Class Initialized
INFO - 2024-05-19 13:22:01 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\include/admin_header.php
INFO - 2024-05-19 13:22:01 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\include/admin_footer.php
INFO - 2024-05-19 13:22:01 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\admin_html_template.php
INFO - 2024-05-19 13:22:01 --> Final output sent to browser
DEBUG - 2024-05-19 13:22:01 --> Total execution time: 1.2213
ERROR - 2024-05-19 13:22:03 --> $config['composer_autoload'] is set to TRUE but E:\xampp\htdocs\maurnaturo\application\vendor/autoload.php was not found.
INFO - 2024-05-19 13:22:03 --> Config Class Initialized
INFO - 2024-05-19 13:22:03 --> Hooks Class Initialized
DEBUG - 2024-05-19 13:22:03 --> UTF-8 Support Enabled
INFO - 2024-05-19 13:22:03 --> Utf8 Class Initialized
INFO - 2024-05-19 13:22:03 --> URI Class Initialized
INFO - 2024-05-19 13:22:03 --> Router Class Initialized
INFO - 2024-05-19 13:22:03 --> Output Class Initialized
INFO - 2024-05-19 13:22:03 --> Security Class Initialized
DEBUG - 2024-05-19 13:22:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-19 13:22:03 --> Input Class Initialized
INFO - 2024-05-19 13:22:03 --> Language Class Initialized
INFO - 2024-05-19 13:22:03 --> Loader Class Initialized
INFO - 2024-05-19 13:22:03 --> Helper loaded: url_helper
INFO - 2024-05-19 13:22:03 --> Helper loaded: file_helper
INFO - 2024-05-19 13:22:03 --> Helper loaded: html_helper
INFO - 2024-05-19 13:22:03 --> Helper loaded: text_helper
INFO - 2024-05-19 13:22:03 --> Helper loaded: form_helper
INFO - 2024-05-19 13:22:03 --> Helper loaded: lang_helper
INFO - 2024-05-19 13:22:03 --> Helper loaded: security_helper
INFO - 2024-05-19 13:22:03 --> Helper loaded: cookie_helper
INFO - 2024-05-19 13:22:03 --> Database Driver Class Initialized
INFO - 2024-05-19 13:22:03 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-19 13:22:03 --> Parser Class Initialized
INFO - 2024-05-19 13:22:03 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-05-19 13:22:03 --> Pagination Class Initialized
INFO - 2024-05-19 13:22:03 --> Form Validation Class Initialized
INFO - 2024-05-19 13:22:03 --> Controller Class Initialized
DEBUG - 2024-05-19 13:22:03 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-05-19 13:22:03 --> Session class already loaded. Second attempt ignored.
INFO - 2024-05-19 13:22:03 --> Model Class Initialized
DEBUG - 2024-05-19 13:22:03 --> Lpayments class already loaded. Second attempt ignored.
INFO - 2024-05-19 13:22:03 --> Model Class Initialized
INFO - 2024-05-19 13:22:03 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\payments/payment.php
DEBUG - 2024-05-19 13:22:03 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-05-19 13:22:03 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\include/top_menu.php
INFO - 2024-05-19 13:22:03 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\include/admin_loggedin_info.php
INFO - 2024-05-19 13:22:03 --> Model Class Initialized
INFO - 2024-05-19 13:22:03 --> Model Class Initialized
INFO - 2024-05-19 13:22:03 --> Model Class Initialized
INFO - 2024-05-19 13:22:04 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\include/admin_header.php
INFO - 2024-05-19 13:22:04 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\include/admin_footer.php
INFO - 2024-05-19 13:22:04 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\admin_html_template.php
INFO - 2024-05-19 13:22:04 --> Final output sent to browser
DEBUG - 2024-05-19 13:22:04 --> Total execution time: 1.1809
ERROR - 2024-05-19 13:22:04 --> $config['composer_autoload'] is set to TRUE but E:\xampp\htdocs\maurnaturo\application\vendor/autoload.php was not found.
INFO - 2024-05-19 13:22:04 --> Config Class Initialized
INFO - 2024-05-19 13:22:04 --> Hooks Class Initialized
DEBUG - 2024-05-19 13:22:04 --> UTF-8 Support Enabled
INFO - 2024-05-19 13:22:04 --> Utf8 Class Initialized
INFO - 2024-05-19 13:22:04 --> URI Class Initialized
INFO - 2024-05-19 13:22:04 --> Router Class Initialized
INFO - 2024-05-19 13:22:04 --> Output Class Initialized
INFO - 2024-05-19 13:22:04 --> Security Class Initialized
DEBUG - 2024-05-19 13:22:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-19 13:22:04 --> Input Class Initialized
INFO - 2024-05-19 13:22:04 --> Language Class Initialized
INFO - 2024-05-19 13:22:04 --> Loader Class Initialized
INFO - 2024-05-19 13:22:04 --> Helper loaded: url_helper
INFO - 2024-05-19 13:22:04 --> Helper loaded: file_helper
INFO - 2024-05-19 13:22:04 --> Helper loaded: html_helper
INFO - 2024-05-19 13:22:04 --> Helper loaded: text_helper
INFO - 2024-05-19 13:22:04 --> Helper loaded: form_helper
INFO - 2024-05-19 13:22:04 --> Helper loaded: lang_helper
INFO - 2024-05-19 13:22:04 --> Helper loaded: security_helper
INFO - 2024-05-19 13:22:04 --> Helper loaded: cookie_helper
INFO - 2024-05-19 13:22:04 --> Database Driver Class Initialized
INFO - 2024-05-19 13:22:04 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-19 13:22:04 --> Parser Class Initialized
INFO - 2024-05-19 13:22:04 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-05-19 13:22:04 --> Pagination Class Initialized
INFO - 2024-05-19 13:22:04 --> Form Validation Class Initialized
INFO - 2024-05-19 13:22:04 --> Controller Class Initialized
DEBUG - 2024-05-19 13:22:04 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-05-19 13:22:04 --> Session class already loaded. Second attempt ignored.
INFO - 2024-05-19 13:22:04 --> Model Class Initialized
INFO - 2024-05-19 13:22:04 --> Final output sent to browser
DEBUG - 2024-05-19 13:22:04 --> Total execution time: 0.1168
ERROR - 2024-05-19 13:25:49 --> $config['composer_autoload'] is set to TRUE but E:\xampp\htdocs\maurnaturo\application\vendor/autoload.php was not found.
INFO - 2024-05-19 13:25:49 --> Config Class Initialized
INFO - 2024-05-19 13:25:49 --> Hooks Class Initialized
DEBUG - 2024-05-19 13:25:49 --> UTF-8 Support Enabled
INFO - 2024-05-19 13:25:49 --> Utf8 Class Initialized
INFO - 2024-05-19 13:25:49 --> URI Class Initialized
INFO - 2024-05-19 13:25:49 --> Router Class Initialized
INFO - 2024-05-19 13:25:49 --> Output Class Initialized
INFO - 2024-05-19 13:25:49 --> Security Class Initialized
DEBUG - 2024-05-19 13:25:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-19 13:25:49 --> Input Class Initialized
INFO - 2024-05-19 13:25:49 --> Language Class Initialized
INFO - 2024-05-19 13:25:49 --> Loader Class Initialized
INFO - 2024-05-19 13:25:49 --> Helper loaded: url_helper
INFO - 2024-05-19 13:25:49 --> Helper loaded: file_helper
INFO - 2024-05-19 13:25:49 --> Helper loaded: html_helper
INFO - 2024-05-19 13:25:49 --> Helper loaded: text_helper
INFO - 2024-05-19 13:25:49 --> Helper loaded: form_helper
INFO - 2024-05-19 13:25:49 --> Helper loaded: lang_helper
INFO - 2024-05-19 13:25:49 --> Helper loaded: security_helper
INFO - 2024-05-19 13:25:49 --> Helper loaded: cookie_helper
INFO - 2024-05-19 13:25:49 --> Database Driver Class Initialized
INFO - 2024-05-19 13:25:49 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-19 13:25:49 --> Parser Class Initialized
INFO - 2024-05-19 13:25:49 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-05-19 13:25:49 --> Pagination Class Initialized
INFO - 2024-05-19 13:25:49 --> Form Validation Class Initialized
INFO - 2024-05-19 13:25:49 --> Controller Class Initialized
DEBUG - 2024-05-19 13:25:49 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-05-19 13:25:49 --> Session class already loaded. Second attempt ignored.
INFO - 2024-05-19 13:25:49 --> Model Class Initialized
DEBUG - 2024-05-19 13:25:49 --> Lpayments class already loaded. Second attempt ignored.
INFO - 2024-05-19 13:25:49 --> Model Class Initialized
INFO - 2024-05-19 13:25:49 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\payments/payment.php
DEBUG - 2024-05-19 13:25:49 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-05-19 13:25:49 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\include/top_menu.php
INFO - 2024-05-19 13:25:49 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\include/admin_loggedin_info.php
INFO - 2024-05-19 13:25:49 --> Model Class Initialized
INFO - 2024-05-19 13:25:49 --> Model Class Initialized
INFO - 2024-05-19 13:25:49 --> Model Class Initialized
INFO - 2024-05-19 13:25:50 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\include/admin_header.php
INFO - 2024-05-19 13:25:50 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\include/admin_footer.php
INFO - 2024-05-19 13:25:50 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\admin_html_template.php
INFO - 2024-05-19 13:25:50 --> Final output sent to browser
DEBUG - 2024-05-19 13:25:50 --> Total execution time: 1.1939
ERROR - 2024-05-19 13:25:50 --> $config['composer_autoload'] is set to TRUE but E:\xampp\htdocs\maurnaturo\application\vendor/autoload.php was not found.
INFO - 2024-05-19 13:25:51 --> Config Class Initialized
INFO - 2024-05-19 13:25:51 --> Hooks Class Initialized
DEBUG - 2024-05-19 13:25:51 --> UTF-8 Support Enabled
INFO - 2024-05-19 13:25:51 --> Utf8 Class Initialized
INFO - 2024-05-19 13:25:51 --> URI Class Initialized
INFO - 2024-05-19 13:25:51 --> Router Class Initialized
INFO - 2024-05-19 13:25:51 --> Output Class Initialized
INFO - 2024-05-19 13:25:51 --> Security Class Initialized
DEBUG - 2024-05-19 13:25:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-19 13:25:51 --> Input Class Initialized
INFO - 2024-05-19 13:25:51 --> Language Class Initialized
INFO - 2024-05-19 13:25:51 --> Loader Class Initialized
INFO - 2024-05-19 13:25:51 --> Helper loaded: url_helper
INFO - 2024-05-19 13:25:51 --> Helper loaded: file_helper
INFO - 2024-05-19 13:25:51 --> Helper loaded: html_helper
INFO - 2024-05-19 13:25:51 --> Helper loaded: text_helper
INFO - 2024-05-19 13:25:51 --> Helper loaded: form_helper
INFO - 2024-05-19 13:25:51 --> Helper loaded: lang_helper
INFO - 2024-05-19 13:25:51 --> Helper loaded: security_helper
INFO - 2024-05-19 13:25:51 --> Helper loaded: cookie_helper
INFO - 2024-05-19 13:25:51 --> Database Driver Class Initialized
INFO - 2024-05-19 13:25:51 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-19 13:25:51 --> Parser Class Initialized
INFO - 2024-05-19 13:25:51 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-05-19 13:25:51 --> Pagination Class Initialized
INFO - 2024-05-19 13:25:51 --> Form Validation Class Initialized
INFO - 2024-05-19 13:25:51 --> Controller Class Initialized
DEBUG - 2024-05-19 13:25:51 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-05-19 13:25:51 --> Session class already loaded. Second attempt ignored.
INFO - 2024-05-19 13:25:51 --> Model Class Initialized
INFO - 2024-05-19 13:25:51 --> Final output sent to browser
DEBUG - 2024-05-19 13:25:51 --> Total execution time: 0.0991
ERROR - 2024-05-19 13:26:08 --> $config['composer_autoload'] is set to TRUE but E:\xampp\htdocs\maurnaturo\application\vendor/autoload.php was not found.
INFO - 2024-05-19 13:26:08 --> Config Class Initialized
INFO - 2024-05-19 13:26:08 --> Hooks Class Initialized
DEBUG - 2024-05-19 13:26:08 --> UTF-8 Support Enabled
INFO - 2024-05-19 13:26:08 --> Utf8 Class Initialized
INFO - 2024-05-19 13:26:08 --> URI Class Initialized
INFO - 2024-05-19 13:26:08 --> Router Class Initialized
INFO - 2024-05-19 13:26:08 --> Output Class Initialized
INFO - 2024-05-19 13:26:08 --> Security Class Initialized
DEBUG - 2024-05-19 13:26:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-19 13:26:08 --> Input Class Initialized
INFO - 2024-05-19 13:26:08 --> Language Class Initialized
INFO - 2024-05-19 13:26:08 --> Loader Class Initialized
INFO - 2024-05-19 13:26:08 --> Helper loaded: url_helper
INFO - 2024-05-19 13:26:08 --> Helper loaded: file_helper
INFO - 2024-05-19 13:26:08 --> Helper loaded: html_helper
INFO - 2024-05-19 13:26:08 --> Helper loaded: text_helper
INFO - 2024-05-19 13:26:08 --> Helper loaded: form_helper
INFO - 2024-05-19 13:26:08 --> Helper loaded: lang_helper
INFO - 2024-05-19 13:26:08 --> Helper loaded: security_helper
INFO - 2024-05-19 13:26:08 --> Helper loaded: cookie_helper
INFO - 2024-05-19 13:26:08 --> Database Driver Class Initialized
INFO - 2024-05-19 13:26:08 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-19 13:26:08 --> Parser Class Initialized
INFO - 2024-05-19 13:26:08 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-05-19 13:26:08 --> Pagination Class Initialized
INFO - 2024-05-19 13:26:08 --> Form Validation Class Initialized
INFO - 2024-05-19 13:26:08 --> Controller Class Initialized
DEBUG - 2024-05-19 13:26:08 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-05-19 13:26:08 --> Session class already loaded. Second attempt ignored.
INFO - 2024-05-19 13:26:08 --> Model Class Initialized
DEBUG - 2024-05-19 13:26:08 --> Lpayments class already loaded. Second attempt ignored.
INFO - 2024-05-19 13:26:08 --> Model Class Initialized
INFO - 2024-05-19 13:26:09 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\payments/payment.php
DEBUG - 2024-05-19 13:26:09 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-05-19 13:26:09 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\include/top_menu.php
INFO - 2024-05-19 13:26:09 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\include/admin_loggedin_info.php
INFO - 2024-05-19 13:26:09 --> Model Class Initialized
INFO - 2024-05-19 13:26:09 --> Model Class Initialized
INFO - 2024-05-19 13:26:09 --> Model Class Initialized
INFO - 2024-05-19 13:26:10 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\include/admin_header.php
INFO - 2024-05-19 13:26:10 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\include/admin_footer.php
INFO - 2024-05-19 13:26:10 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\admin_html_template.php
INFO - 2024-05-19 13:26:10 --> Final output sent to browser
DEBUG - 2024-05-19 13:26:10 --> Total execution time: 1.1416
ERROR - 2024-05-19 13:26:10 --> $config['composer_autoload'] is set to TRUE but E:\xampp\htdocs\maurnaturo\application\vendor/autoload.php was not found.
INFO - 2024-05-19 13:26:10 --> Config Class Initialized
INFO - 2024-05-19 13:26:10 --> Hooks Class Initialized
DEBUG - 2024-05-19 13:26:10 --> UTF-8 Support Enabled
INFO - 2024-05-19 13:26:10 --> Utf8 Class Initialized
INFO - 2024-05-19 13:26:10 --> URI Class Initialized
INFO - 2024-05-19 13:26:10 --> Router Class Initialized
INFO - 2024-05-19 13:26:10 --> Output Class Initialized
INFO - 2024-05-19 13:26:10 --> Security Class Initialized
DEBUG - 2024-05-19 13:26:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-19 13:26:10 --> Input Class Initialized
INFO - 2024-05-19 13:26:10 --> Language Class Initialized
INFO - 2024-05-19 13:26:10 --> Loader Class Initialized
INFO - 2024-05-19 13:26:10 --> Helper loaded: url_helper
INFO - 2024-05-19 13:26:10 --> Helper loaded: file_helper
INFO - 2024-05-19 13:26:10 --> Helper loaded: html_helper
INFO - 2024-05-19 13:26:10 --> Helper loaded: text_helper
INFO - 2024-05-19 13:26:10 --> Helper loaded: form_helper
INFO - 2024-05-19 13:26:10 --> Helper loaded: lang_helper
INFO - 2024-05-19 13:26:10 --> Helper loaded: security_helper
INFO - 2024-05-19 13:26:10 --> Helper loaded: cookie_helper
INFO - 2024-05-19 13:26:10 --> Database Driver Class Initialized
INFO - 2024-05-19 13:26:10 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-19 13:26:10 --> Parser Class Initialized
INFO - 2024-05-19 13:26:10 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-05-19 13:26:10 --> Pagination Class Initialized
INFO - 2024-05-19 13:26:10 --> Form Validation Class Initialized
INFO - 2024-05-19 13:26:10 --> Controller Class Initialized
DEBUG - 2024-05-19 13:26:10 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-05-19 13:26:10 --> Session class already loaded. Second attempt ignored.
INFO - 2024-05-19 13:26:10 --> Model Class Initialized
INFO - 2024-05-19 13:26:10 --> Final output sent to browser
DEBUG - 2024-05-19 13:26:10 --> Total execution time: 0.1311
ERROR - 2024-05-19 13:26:12 --> $config['composer_autoload'] is set to TRUE but E:\xampp\htdocs\maurnaturo\application\vendor/autoload.php was not found.
INFO - 2024-05-19 13:26:12 --> Config Class Initialized
INFO - 2024-05-19 13:26:12 --> Hooks Class Initialized
DEBUG - 2024-05-19 13:26:12 --> UTF-8 Support Enabled
INFO - 2024-05-19 13:26:12 --> Utf8 Class Initialized
INFO - 2024-05-19 13:26:12 --> URI Class Initialized
INFO - 2024-05-19 13:26:12 --> Router Class Initialized
INFO - 2024-05-19 13:26:12 --> Output Class Initialized
INFO - 2024-05-19 13:26:12 --> Security Class Initialized
DEBUG - 2024-05-19 13:26:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-19 13:26:12 --> Input Class Initialized
INFO - 2024-05-19 13:26:12 --> Language Class Initialized
INFO - 2024-05-19 13:26:12 --> Loader Class Initialized
INFO - 2024-05-19 13:26:12 --> Helper loaded: url_helper
INFO - 2024-05-19 13:26:12 --> Helper loaded: file_helper
INFO - 2024-05-19 13:26:12 --> Helper loaded: html_helper
INFO - 2024-05-19 13:26:12 --> Helper loaded: text_helper
INFO - 2024-05-19 13:26:12 --> Helper loaded: form_helper
INFO - 2024-05-19 13:26:12 --> Helper loaded: lang_helper
INFO - 2024-05-19 13:26:12 --> Helper loaded: security_helper
INFO - 2024-05-19 13:26:12 --> Helper loaded: cookie_helper
INFO - 2024-05-19 13:26:12 --> Database Driver Class Initialized
INFO - 2024-05-19 13:26:12 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-19 13:26:12 --> Parser Class Initialized
INFO - 2024-05-19 13:26:12 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-05-19 13:26:12 --> Pagination Class Initialized
INFO - 2024-05-19 13:26:12 --> Form Validation Class Initialized
INFO - 2024-05-19 13:26:12 --> Controller Class Initialized
DEBUG - 2024-05-19 13:26:12 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-05-19 13:26:12 --> Session class already loaded. Second attempt ignored.
INFO - 2024-05-19 13:26:12 --> Model Class Initialized
INFO - 2024-05-19 13:26:12 --> Model Class Initialized
DEBUG - 2024-05-19 13:26:12 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-05-19 13:26:12 --> Session class already loaded. Second attempt ignored.
INFO - 2024-05-19 13:26:12 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\payments/add_payment_form.php
DEBUG - 2024-05-19 13:26:12 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-05-19 13:26:12 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\include/top_menu.php
INFO - 2024-05-19 13:26:12 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\include/admin_loggedin_info.php
INFO - 2024-05-19 13:26:12 --> Model Class Initialized
INFO - 2024-05-19 13:26:12 --> Model Class Initialized
INFO - 2024-05-19 13:26:12 --> Model Class Initialized
INFO - 2024-05-19 13:26:12 --> Model Class Initialized
INFO - 2024-05-19 13:26:13 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\include/admin_header.php
INFO - 2024-05-19 13:26:13 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\include/admin_footer.php
INFO - 2024-05-19 13:26:13 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\admin_html_template.php
INFO - 2024-05-19 13:26:13 --> Final output sent to browser
DEBUG - 2024-05-19 13:26:13 --> Total execution time: 1.4190
ERROR - 2024-05-19 13:26:16 --> $config['composer_autoload'] is set to TRUE but E:\xampp\htdocs\maurnaturo\application\vendor/autoload.php was not found.
INFO - 2024-05-19 13:26:16 --> Config Class Initialized
INFO - 2024-05-19 13:26:16 --> Hooks Class Initialized
DEBUG - 2024-05-19 13:26:16 --> UTF-8 Support Enabled
INFO - 2024-05-19 13:26:16 --> Utf8 Class Initialized
INFO - 2024-05-19 13:26:16 --> URI Class Initialized
INFO - 2024-05-19 13:26:16 --> Router Class Initialized
INFO - 2024-05-19 13:26:16 --> Output Class Initialized
INFO - 2024-05-19 13:26:16 --> Security Class Initialized
DEBUG - 2024-05-19 13:26:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-19 13:26:16 --> Input Class Initialized
INFO - 2024-05-19 13:26:16 --> Language Class Initialized
INFO - 2024-05-19 13:26:16 --> Loader Class Initialized
INFO - 2024-05-19 13:26:16 --> Helper loaded: url_helper
INFO - 2024-05-19 13:26:16 --> Helper loaded: file_helper
INFO - 2024-05-19 13:26:16 --> Helper loaded: html_helper
INFO - 2024-05-19 13:26:16 --> Helper loaded: text_helper
INFO - 2024-05-19 13:26:16 --> Helper loaded: form_helper
INFO - 2024-05-19 13:26:16 --> Helper loaded: lang_helper
INFO - 2024-05-19 13:26:16 --> Helper loaded: security_helper
INFO - 2024-05-19 13:26:16 --> Helper loaded: cookie_helper
INFO - 2024-05-19 13:26:16 --> Database Driver Class Initialized
INFO - 2024-05-19 13:26:16 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-19 13:26:16 --> Parser Class Initialized
INFO - 2024-05-19 13:26:16 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-05-19 13:26:16 --> Pagination Class Initialized
INFO - 2024-05-19 13:26:16 --> Form Validation Class Initialized
INFO - 2024-05-19 13:26:16 --> Controller Class Initialized
INFO - 2024-05-19 13:26:16 --> Model Class Initialized
DEBUG - 2024-05-19 13:26:16 --> Session class already loaded. Second attempt ignored.
INFO - 2024-05-19 13:26:16 --> Final output sent to browser
DEBUG - 2024-05-19 13:26:16 --> Total execution time: 0.0790
ERROR - 2024-05-19 13:26:17 --> $config['composer_autoload'] is set to TRUE but E:\xampp\htdocs\maurnaturo\application\vendor/autoload.php was not found.
INFO - 2024-05-19 13:26:17 --> Config Class Initialized
INFO - 2024-05-19 13:26:17 --> Hooks Class Initialized
DEBUG - 2024-05-19 13:26:17 --> UTF-8 Support Enabled
INFO - 2024-05-19 13:26:17 --> Utf8 Class Initialized
INFO - 2024-05-19 13:26:17 --> URI Class Initialized
INFO - 2024-05-19 13:26:17 --> Router Class Initialized
INFO - 2024-05-19 13:26:17 --> Output Class Initialized
INFO - 2024-05-19 13:26:17 --> Security Class Initialized
DEBUG - 2024-05-19 13:26:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-19 13:26:17 --> Input Class Initialized
INFO - 2024-05-19 13:26:17 --> Language Class Initialized
INFO - 2024-05-19 13:26:17 --> Loader Class Initialized
INFO - 2024-05-19 13:26:17 --> Helper loaded: url_helper
INFO - 2024-05-19 13:26:17 --> Helper loaded: file_helper
INFO - 2024-05-19 13:26:17 --> Helper loaded: html_helper
INFO - 2024-05-19 13:26:17 --> Helper loaded: text_helper
INFO - 2024-05-19 13:26:17 --> Helper loaded: form_helper
INFO - 2024-05-19 13:26:17 --> Helper loaded: lang_helper
INFO - 2024-05-19 13:26:17 --> Helper loaded: security_helper
INFO - 2024-05-19 13:26:17 --> Helper loaded: cookie_helper
INFO - 2024-05-19 13:26:17 --> Database Driver Class Initialized
INFO - 2024-05-19 13:26:17 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-19 13:26:17 --> Parser Class Initialized
INFO - 2024-05-19 13:26:17 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-05-19 13:26:17 --> Pagination Class Initialized
INFO - 2024-05-19 13:26:17 --> Form Validation Class Initialized
INFO - 2024-05-19 13:26:17 --> Controller Class Initialized
INFO - 2024-05-19 13:26:17 --> Model Class Initialized
DEBUG - 2024-05-19 13:26:17 --> Session class already loaded. Second attempt ignored.
INFO - 2024-05-19 13:26:17 --> Final output sent to browser
DEBUG - 2024-05-19 13:26:17 --> Total execution time: 0.0719
ERROR - 2024-05-19 13:26:18 --> $config['composer_autoload'] is set to TRUE but E:\xampp\htdocs\maurnaturo\application\vendor/autoload.php was not found.
INFO - 2024-05-19 13:26:18 --> Config Class Initialized
INFO - 2024-05-19 13:26:18 --> Hooks Class Initialized
DEBUG - 2024-05-19 13:26:18 --> UTF-8 Support Enabled
INFO - 2024-05-19 13:26:18 --> Utf8 Class Initialized
INFO - 2024-05-19 13:26:18 --> URI Class Initialized
INFO - 2024-05-19 13:26:18 --> Router Class Initialized
INFO - 2024-05-19 13:26:18 --> Output Class Initialized
INFO - 2024-05-19 13:26:18 --> Security Class Initialized
DEBUG - 2024-05-19 13:26:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-19 13:26:18 --> Input Class Initialized
INFO - 2024-05-19 13:26:18 --> Language Class Initialized
INFO - 2024-05-19 13:26:18 --> Loader Class Initialized
INFO - 2024-05-19 13:26:18 --> Helper loaded: url_helper
INFO - 2024-05-19 13:26:18 --> Helper loaded: file_helper
INFO - 2024-05-19 13:26:18 --> Helper loaded: html_helper
INFO - 2024-05-19 13:26:18 --> Helper loaded: text_helper
INFO - 2024-05-19 13:26:18 --> Helper loaded: form_helper
INFO - 2024-05-19 13:26:18 --> Helper loaded: lang_helper
INFO - 2024-05-19 13:26:18 --> Helper loaded: security_helper
INFO - 2024-05-19 13:26:18 --> Helper loaded: cookie_helper
INFO - 2024-05-19 13:26:18 --> Database Driver Class Initialized
INFO - 2024-05-19 13:26:18 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-19 13:26:18 --> Parser Class Initialized
INFO - 2024-05-19 13:26:18 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-05-19 13:26:18 --> Pagination Class Initialized
INFO - 2024-05-19 13:26:18 --> Form Validation Class Initialized
INFO - 2024-05-19 13:26:18 --> Controller Class Initialized
INFO - 2024-05-19 13:26:18 --> Model Class Initialized
DEBUG - 2024-05-19 13:26:18 --> Session class already loaded. Second attempt ignored.
ERROR - 2024-05-19 13:26:18 --> Severity: Warning --> Invalid argument supplied for foreach() E:\xampp\htdocs\maurnaturo\application\controllers\Cinvoice.php 616
INFO - 2024-05-19 13:26:18 --> Final output sent to browser
DEBUG - 2024-05-19 13:26:18 --> Total execution time: 0.0997
ERROR - 2024-05-19 13:26:18 --> $config['composer_autoload'] is set to TRUE but E:\xampp\htdocs\maurnaturo\application\vendor/autoload.php was not found.
INFO - 2024-05-19 13:26:18 --> Config Class Initialized
INFO - 2024-05-19 13:26:18 --> Hooks Class Initialized
DEBUG - 2024-05-19 13:26:18 --> UTF-8 Support Enabled
INFO - 2024-05-19 13:26:18 --> Utf8 Class Initialized
INFO - 2024-05-19 13:26:18 --> URI Class Initialized
INFO - 2024-05-19 13:26:18 --> Router Class Initialized
INFO - 2024-05-19 13:26:18 --> Output Class Initialized
INFO - 2024-05-19 13:26:18 --> Security Class Initialized
DEBUG - 2024-05-19 13:26:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-19 13:26:18 --> Input Class Initialized
INFO - 2024-05-19 13:26:18 --> Language Class Initialized
INFO - 2024-05-19 13:26:18 --> Loader Class Initialized
INFO - 2024-05-19 13:26:18 --> Helper loaded: url_helper
INFO - 2024-05-19 13:26:18 --> Helper loaded: file_helper
INFO - 2024-05-19 13:26:18 --> Helper loaded: html_helper
INFO - 2024-05-19 13:26:18 --> Helper loaded: text_helper
INFO - 2024-05-19 13:26:18 --> Helper loaded: form_helper
INFO - 2024-05-19 13:26:18 --> Helper loaded: lang_helper
INFO - 2024-05-19 13:26:18 --> Helper loaded: security_helper
INFO - 2024-05-19 13:26:18 --> Helper loaded: cookie_helper
INFO - 2024-05-19 13:26:18 --> Database Driver Class Initialized
INFO - 2024-05-19 13:26:18 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-19 13:26:18 --> Parser Class Initialized
INFO - 2024-05-19 13:26:18 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-05-19 13:26:18 --> Pagination Class Initialized
INFO - 2024-05-19 13:26:18 --> Form Validation Class Initialized
INFO - 2024-05-19 13:26:18 --> Controller Class Initialized
INFO - 2024-05-19 13:26:18 --> Model Class Initialized
DEBUG - 2024-05-19 13:26:18 --> Session class already loaded. Second attempt ignored.
INFO - 2024-05-19 13:26:18 --> Final output sent to browser
DEBUG - 2024-05-19 13:26:18 --> Total execution time: 0.0921
ERROR - 2024-05-19 13:26:19 --> $config['composer_autoload'] is set to TRUE but E:\xampp\htdocs\maurnaturo\application\vendor/autoload.php was not found.
INFO - 2024-05-19 13:26:19 --> Config Class Initialized
INFO - 2024-05-19 13:26:19 --> Hooks Class Initialized
DEBUG - 2024-05-19 13:26:19 --> UTF-8 Support Enabled
INFO - 2024-05-19 13:26:19 --> Utf8 Class Initialized
INFO - 2024-05-19 13:26:19 --> URI Class Initialized
INFO - 2024-05-19 13:26:19 --> Router Class Initialized
INFO - 2024-05-19 13:26:19 --> Output Class Initialized
INFO - 2024-05-19 13:26:19 --> Security Class Initialized
DEBUG - 2024-05-19 13:26:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-19 13:26:19 --> Input Class Initialized
INFO - 2024-05-19 13:26:19 --> Language Class Initialized
INFO - 2024-05-19 13:26:19 --> Loader Class Initialized
INFO - 2024-05-19 13:26:19 --> Helper loaded: url_helper
INFO - 2024-05-19 13:26:19 --> Helper loaded: file_helper
INFO - 2024-05-19 13:26:19 --> Helper loaded: html_helper
INFO - 2024-05-19 13:26:19 --> Helper loaded: text_helper
INFO - 2024-05-19 13:26:19 --> Helper loaded: form_helper
INFO - 2024-05-19 13:26:19 --> Helper loaded: lang_helper
INFO - 2024-05-19 13:26:19 --> Helper loaded: security_helper
INFO - 2024-05-19 13:26:19 --> Helper loaded: cookie_helper
INFO - 2024-05-19 13:26:19 --> Database Driver Class Initialized
INFO - 2024-05-19 13:26:19 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-19 13:26:19 --> Parser Class Initialized
INFO - 2024-05-19 13:26:19 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-05-19 13:26:19 --> Pagination Class Initialized
INFO - 2024-05-19 13:26:19 --> Form Validation Class Initialized
INFO - 2024-05-19 13:26:19 --> Controller Class Initialized
INFO - 2024-05-19 13:26:19 --> Model Class Initialized
DEBUG - 2024-05-19 13:26:19 --> Session class already loaded. Second attempt ignored.
INFO - 2024-05-19 13:26:19 --> Final output sent to browser
DEBUG - 2024-05-19 13:26:19 --> Total execution time: 0.0738
ERROR - 2024-05-19 13:26:38 --> $config['composer_autoload'] is set to TRUE but E:\xampp\htdocs\maurnaturo\application\vendor/autoload.php was not found.
INFO - 2024-05-19 13:26:38 --> Config Class Initialized
INFO - 2024-05-19 13:26:38 --> Hooks Class Initialized
DEBUG - 2024-05-19 13:26:38 --> UTF-8 Support Enabled
INFO - 2024-05-19 13:26:38 --> Utf8 Class Initialized
INFO - 2024-05-19 13:26:38 --> URI Class Initialized
INFO - 2024-05-19 13:26:38 --> Router Class Initialized
INFO - 2024-05-19 13:26:38 --> Output Class Initialized
INFO - 2024-05-19 13:26:38 --> Security Class Initialized
DEBUG - 2024-05-19 13:26:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-19 13:26:38 --> Input Class Initialized
INFO - 2024-05-19 13:26:38 --> Language Class Initialized
INFO - 2024-05-19 13:26:38 --> Loader Class Initialized
INFO - 2024-05-19 13:26:38 --> Helper loaded: url_helper
INFO - 2024-05-19 13:26:38 --> Helper loaded: file_helper
INFO - 2024-05-19 13:26:38 --> Helper loaded: html_helper
INFO - 2024-05-19 13:26:38 --> Helper loaded: text_helper
INFO - 2024-05-19 13:26:38 --> Helper loaded: form_helper
INFO - 2024-05-19 13:26:38 --> Helper loaded: lang_helper
INFO - 2024-05-19 13:26:38 --> Helper loaded: security_helper
INFO - 2024-05-19 13:26:38 --> Helper loaded: cookie_helper
INFO - 2024-05-19 13:26:38 --> Database Driver Class Initialized
INFO - 2024-05-19 13:26:38 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-19 13:26:38 --> Parser Class Initialized
INFO - 2024-05-19 13:26:38 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-05-19 13:26:38 --> Pagination Class Initialized
INFO - 2024-05-19 13:26:38 --> Form Validation Class Initialized
INFO - 2024-05-19 13:26:38 --> Controller Class Initialized
INFO - 2024-05-19 13:26:38 --> Model Class Initialized
DEBUG - 2024-05-19 13:26:38 --> Session class already loaded. Second attempt ignored.
INFO - 2024-05-19 13:26:38 --> Final output sent to browser
DEBUG - 2024-05-19 13:26:38 --> Total execution time: 0.0639
ERROR - 2024-05-19 13:26:40 --> $config['composer_autoload'] is set to TRUE but E:\xampp\htdocs\maurnaturo\application\vendor/autoload.php was not found.
INFO - 2024-05-19 13:26:40 --> Config Class Initialized
INFO - 2024-05-19 13:26:40 --> Hooks Class Initialized
DEBUG - 2024-05-19 13:26:40 --> UTF-8 Support Enabled
INFO - 2024-05-19 13:26:40 --> Utf8 Class Initialized
INFO - 2024-05-19 13:26:40 --> URI Class Initialized
INFO - 2024-05-19 13:26:40 --> Router Class Initialized
INFO - 2024-05-19 13:26:40 --> Output Class Initialized
INFO - 2024-05-19 13:26:40 --> Security Class Initialized
DEBUG - 2024-05-19 13:26:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-19 13:26:40 --> Input Class Initialized
INFO - 2024-05-19 13:26:40 --> Language Class Initialized
INFO - 2024-05-19 13:26:40 --> Loader Class Initialized
INFO - 2024-05-19 13:26:40 --> Helper loaded: url_helper
INFO - 2024-05-19 13:26:40 --> Helper loaded: file_helper
INFO - 2024-05-19 13:26:40 --> Helper loaded: html_helper
INFO - 2024-05-19 13:26:40 --> Helper loaded: text_helper
INFO - 2024-05-19 13:26:40 --> Helper loaded: form_helper
INFO - 2024-05-19 13:26:40 --> Helper loaded: lang_helper
INFO - 2024-05-19 13:26:40 --> Helper loaded: security_helper
INFO - 2024-05-19 13:26:40 --> Helper loaded: cookie_helper
INFO - 2024-05-19 13:26:40 --> Database Driver Class Initialized
INFO - 2024-05-19 13:26:40 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-19 13:26:40 --> Parser Class Initialized
INFO - 2024-05-19 13:26:40 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-05-19 13:26:40 --> Pagination Class Initialized
INFO - 2024-05-19 13:26:40 --> Form Validation Class Initialized
INFO - 2024-05-19 13:26:40 --> Controller Class Initialized
INFO - 2024-05-19 13:26:40 --> Model Class Initialized
DEBUG - 2024-05-19 13:26:40 --> Session class already loaded. Second attempt ignored.
INFO - 2024-05-19 13:26:40 --> Final output sent to browser
DEBUG - 2024-05-19 13:26:40 --> Total execution time: 0.0889
ERROR - 2024-05-19 13:26:41 --> $config['composer_autoload'] is set to TRUE but E:\xampp\htdocs\maurnaturo\application\vendor/autoload.php was not found.
INFO - 2024-05-19 13:26:41 --> Config Class Initialized
INFO - 2024-05-19 13:26:41 --> Hooks Class Initialized
DEBUG - 2024-05-19 13:26:41 --> UTF-8 Support Enabled
INFO - 2024-05-19 13:26:41 --> Utf8 Class Initialized
INFO - 2024-05-19 13:26:41 --> URI Class Initialized
INFO - 2024-05-19 13:26:41 --> Router Class Initialized
INFO - 2024-05-19 13:26:41 --> Output Class Initialized
INFO - 2024-05-19 13:26:41 --> Security Class Initialized
DEBUG - 2024-05-19 13:26:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-19 13:26:41 --> Input Class Initialized
INFO - 2024-05-19 13:26:41 --> Language Class Initialized
INFO - 2024-05-19 13:26:41 --> Loader Class Initialized
INFO - 2024-05-19 13:26:41 --> Helper loaded: url_helper
INFO - 2024-05-19 13:26:41 --> Helper loaded: file_helper
INFO - 2024-05-19 13:26:41 --> Helper loaded: html_helper
INFO - 2024-05-19 13:26:41 --> Helper loaded: text_helper
INFO - 2024-05-19 13:26:41 --> Helper loaded: form_helper
INFO - 2024-05-19 13:26:41 --> Helper loaded: lang_helper
INFO - 2024-05-19 13:26:41 --> Helper loaded: security_helper
INFO - 2024-05-19 13:26:41 --> Helper loaded: cookie_helper
INFO - 2024-05-19 13:26:41 --> Database Driver Class Initialized
INFO - 2024-05-19 13:26:41 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-19 13:26:41 --> Parser Class Initialized
INFO - 2024-05-19 13:26:41 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-05-19 13:26:41 --> Pagination Class Initialized
INFO - 2024-05-19 13:26:41 --> Form Validation Class Initialized
INFO - 2024-05-19 13:26:41 --> Controller Class Initialized
INFO - 2024-05-19 13:26:41 --> Model Class Initialized
DEBUG - 2024-05-19 13:26:41 --> Session class already loaded. Second attempt ignored.
ERROR - 2024-05-19 13:26:41 --> Severity: Warning --> Invalid argument supplied for foreach() E:\xampp\htdocs\maurnaturo\application\controllers\Cinvoice.php 616
INFO - 2024-05-19 13:26:41 --> Final output sent to browser
DEBUG - 2024-05-19 13:26:41 --> Total execution time: 0.1150
ERROR - 2024-05-19 13:26:42 --> $config['composer_autoload'] is set to TRUE but E:\xampp\htdocs\maurnaturo\application\vendor/autoload.php was not found.
INFO - 2024-05-19 13:26:42 --> Config Class Initialized
INFO - 2024-05-19 13:26:42 --> Hooks Class Initialized
DEBUG - 2024-05-19 13:26:42 --> UTF-8 Support Enabled
INFO - 2024-05-19 13:26:42 --> Utf8 Class Initialized
INFO - 2024-05-19 13:26:42 --> URI Class Initialized
INFO - 2024-05-19 13:26:42 --> Router Class Initialized
INFO - 2024-05-19 13:26:42 --> Output Class Initialized
INFO - 2024-05-19 13:26:42 --> Security Class Initialized
DEBUG - 2024-05-19 13:26:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-19 13:26:42 --> Input Class Initialized
INFO - 2024-05-19 13:26:42 --> Language Class Initialized
INFO - 2024-05-19 13:26:42 --> Loader Class Initialized
INFO - 2024-05-19 13:26:42 --> Helper loaded: url_helper
INFO - 2024-05-19 13:26:42 --> Helper loaded: file_helper
INFO - 2024-05-19 13:26:42 --> Helper loaded: html_helper
INFO - 2024-05-19 13:26:42 --> Helper loaded: text_helper
INFO - 2024-05-19 13:26:42 --> Helper loaded: form_helper
INFO - 2024-05-19 13:26:42 --> Helper loaded: lang_helper
INFO - 2024-05-19 13:26:42 --> Helper loaded: security_helper
INFO - 2024-05-19 13:26:42 --> Helper loaded: cookie_helper
INFO - 2024-05-19 13:26:42 --> Database Driver Class Initialized
INFO - 2024-05-19 13:26:42 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-19 13:26:42 --> Parser Class Initialized
INFO - 2024-05-19 13:26:42 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-05-19 13:26:42 --> Pagination Class Initialized
INFO - 2024-05-19 13:26:42 --> Form Validation Class Initialized
INFO - 2024-05-19 13:26:42 --> Controller Class Initialized
INFO - 2024-05-19 13:26:42 --> Model Class Initialized
DEBUG - 2024-05-19 13:26:42 --> Session class already loaded. Second attempt ignored.
ERROR - 2024-05-19 13:26:42 --> Severity: Warning --> Invalid argument supplied for foreach() E:\xampp\htdocs\maurnaturo\application\controllers\Cinvoice.php 616
INFO - 2024-05-19 13:26:42 --> Final output sent to browser
DEBUG - 2024-05-19 13:26:42 --> Total execution time: 0.0654
ERROR - 2024-05-19 13:26:43 --> $config['composer_autoload'] is set to TRUE but E:\xampp\htdocs\maurnaturo\application\vendor/autoload.php was not found.
INFO - 2024-05-19 13:26:43 --> Config Class Initialized
INFO - 2024-05-19 13:26:43 --> Hooks Class Initialized
DEBUG - 2024-05-19 13:26:43 --> UTF-8 Support Enabled
INFO - 2024-05-19 13:26:43 --> Utf8 Class Initialized
INFO - 2024-05-19 13:26:43 --> URI Class Initialized
INFO - 2024-05-19 13:26:43 --> Router Class Initialized
INFO - 2024-05-19 13:26:43 --> Output Class Initialized
INFO - 2024-05-19 13:26:43 --> Security Class Initialized
DEBUG - 2024-05-19 13:26:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-19 13:26:43 --> Input Class Initialized
INFO - 2024-05-19 13:26:43 --> Language Class Initialized
INFO - 2024-05-19 13:26:43 --> Loader Class Initialized
INFO - 2024-05-19 13:26:43 --> Helper loaded: url_helper
INFO - 2024-05-19 13:26:43 --> Helper loaded: file_helper
INFO - 2024-05-19 13:26:43 --> Helper loaded: html_helper
INFO - 2024-05-19 13:26:43 --> Helper loaded: text_helper
INFO - 2024-05-19 13:26:43 --> Helper loaded: form_helper
INFO - 2024-05-19 13:26:43 --> Helper loaded: lang_helper
INFO - 2024-05-19 13:26:43 --> Helper loaded: security_helper
INFO - 2024-05-19 13:26:43 --> Helper loaded: cookie_helper
INFO - 2024-05-19 13:26:43 --> Database Driver Class Initialized
INFO - 2024-05-19 13:26:43 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-19 13:26:43 --> Parser Class Initialized
INFO - 2024-05-19 13:26:43 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-05-19 13:26:43 --> Pagination Class Initialized
INFO - 2024-05-19 13:26:43 --> Form Validation Class Initialized
INFO - 2024-05-19 13:26:43 --> Controller Class Initialized
INFO - 2024-05-19 13:26:43 --> Model Class Initialized
DEBUG - 2024-05-19 13:26:43 --> Session class already loaded. Second attempt ignored.
INFO - 2024-05-19 13:26:43 --> Final output sent to browser
DEBUG - 2024-05-19 13:26:43 --> Total execution time: 0.0628
ERROR - 2024-05-19 13:26:45 --> $config['composer_autoload'] is set to TRUE but E:\xampp\htdocs\maurnaturo\application\vendor/autoload.php was not found.
INFO - 2024-05-19 13:26:45 --> Config Class Initialized
INFO - 2024-05-19 13:26:45 --> Hooks Class Initialized
DEBUG - 2024-05-19 13:26:45 --> UTF-8 Support Enabled
INFO - 2024-05-19 13:26:45 --> Utf8 Class Initialized
INFO - 2024-05-19 13:26:45 --> URI Class Initialized
INFO - 2024-05-19 13:26:45 --> Router Class Initialized
INFO - 2024-05-19 13:26:45 --> Output Class Initialized
INFO - 2024-05-19 13:26:45 --> Security Class Initialized
DEBUG - 2024-05-19 13:26:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-19 13:26:45 --> Input Class Initialized
INFO - 2024-05-19 13:26:45 --> Language Class Initialized
INFO - 2024-05-19 13:26:45 --> Loader Class Initialized
INFO - 2024-05-19 13:26:45 --> Helper loaded: url_helper
INFO - 2024-05-19 13:26:45 --> Helper loaded: file_helper
INFO - 2024-05-19 13:26:45 --> Helper loaded: html_helper
INFO - 2024-05-19 13:26:45 --> Helper loaded: text_helper
INFO - 2024-05-19 13:26:45 --> Helper loaded: form_helper
INFO - 2024-05-19 13:26:45 --> Helper loaded: lang_helper
INFO - 2024-05-19 13:26:45 --> Helper loaded: security_helper
INFO - 2024-05-19 13:26:45 --> Helper loaded: cookie_helper
INFO - 2024-05-19 13:26:45 --> Database Driver Class Initialized
INFO - 2024-05-19 13:26:45 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-19 13:26:45 --> Parser Class Initialized
INFO - 2024-05-19 13:26:45 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-05-19 13:26:45 --> Pagination Class Initialized
INFO - 2024-05-19 13:26:45 --> Form Validation Class Initialized
INFO - 2024-05-19 13:26:45 --> Controller Class Initialized
INFO - 2024-05-19 13:26:45 --> Model Class Initialized
DEBUG - 2024-05-19 13:26:45 --> Session class already loaded. Second attempt ignored.
INFO - 2024-05-19 13:26:45 --> Final output sent to browser
DEBUG - 2024-05-19 13:26:45 --> Total execution time: 0.0680
ERROR - 2024-05-19 13:26:45 --> $config['composer_autoload'] is set to TRUE but E:\xampp\htdocs\maurnaturo\application\vendor/autoload.php was not found.
INFO - 2024-05-19 13:26:45 --> Config Class Initialized
INFO - 2024-05-19 13:26:45 --> Hooks Class Initialized
DEBUG - 2024-05-19 13:26:45 --> UTF-8 Support Enabled
INFO - 2024-05-19 13:26:45 --> Utf8 Class Initialized
INFO - 2024-05-19 13:26:45 --> URI Class Initialized
INFO - 2024-05-19 13:26:45 --> Router Class Initialized
INFO - 2024-05-19 13:26:45 --> Output Class Initialized
INFO - 2024-05-19 13:26:45 --> Security Class Initialized
DEBUG - 2024-05-19 13:26:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-19 13:26:45 --> Input Class Initialized
INFO - 2024-05-19 13:26:45 --> Language Class Initialized
INFO - 2024-05-19 13:26:45 --> Loader Class Initialized
INFO - 2024-05-19 13:26:45 --> Helper loaded: url_helper
INFO - 2024-05-19 13:26:45 --> Helper loaded: file_helper
INFO - 2024-05-19 13:26:45 --> Helper loaded: html_helper
INFO - 2024-05-19 13:26:45 --> Helper loaded: text_helper
INFO - 2024-05-19 13:26:45 --> Helper loaded: form_helper
INFO - 2024-05-19 13:26:45 --> Helper loaded: lang_helper
INFO - 2024-05-19 13:26:45 --> Helper loaded: security_helper
INFO - 2024-05-19 13:26:45 --> Helper loaded: cookie_helper
INFO - 2024-05-19 13:26:45 --> Database Driver Class Initialized
INFO - 2024-05-19 13:26:45 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-19 13:26:45 --> Parser Class Initialized
INFO - 2024-05-19 13:26:45 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-05-19 13:26:45 --> Pagination Class Initialized
INFO - 2024-05-19 13:26:45 --> Form Validation Class Initialized
INFO - 2024-05-19 13:26:45 --> Controller Class Initialized
INFO - 2024-05-19 13:26:45 --> Model Class Initialized
DEBUG - 2024-05-19 13:26:45 --> Session class already loaded. Second attempt ignored.
INFO - 2024-05-19 13:26:45 --> Final output sent to browser
DEBUG - 2024-05-19 13:26:45 --> Total execution time: 0.0905
ERROR - 2024-05-19 13:26:46 --> $config['composer_autoload'] is set to TRUE but E:\xampp\htdocs\maurnaturo\application\vendor/autoload.php was not found.
INFO - 2024-05-19 13:26:46 --> Config Class Initialized
INFO - 2024-05-19 13:26:46 --> Hooks Class Initialized
DEBUG - 2024-05-19 13:26:46 --> UTF-8 Support Enabled
INFO - 2024-05-19 13:26:46 --> Utf8 Class Initialized
INFO - 2024-05-19 13:26:46 --> URI Class Initialized
INFO - 2024-05-19 13:26:46 --> Router Class Initialized
INFO - 2024-05-19 13:26:46 --> Output Class Initialized
INFO - 2024-05-19 13:26:46 --> Security Class Initialized
DEBUG - 2024-05-19 13:26:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-19 13:26:46 --> Input Class Initialized
INFO - 2024-05-19 13:26:46 --> Language Class Initialized
INFO - 2024-05-19 13:26:46 --> Loader Class Initialized
INFO - 2024-05-19 13:26:46 --> Helper loaded: url_helper
INFO - 2024-05-19 13:26:46 --> Helper loaded: file_helper
INFO - 2024-05-19 13:26:46 --> Helper loaded: html_helper
INFO - 2024-05-19 13:26:46 --> Helper loaded: text_helper
INFO - 2024-05-19 13:26:46 --> Helper loaded: form_helper
INFO - 2024-05-19 13:26:46 --> Helper loaded: lang_helper
INFO - 2024-05-19 13:26:46 --> Helper loaded: security_helper
INFO - 2024-05-19 13:26:46 --> Helper loaded: cookie_helper
INFO - 2024-05-19 13:26:46 --> Database Driver Class Initialized
INFO - 2024-05-19 13:26:46 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-19 13:26:46 --> Parser Class Initialized
INFO - 2024-05-19 13:26:46 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-05-19 13:26:46 --> Pagination Class Initialized
INFO - 2024-05-19 13:26:46 --> Form Validation Class Initialized
INFO - 2024-05-19 13:26:46 --> Controller Class Initialized
INFO - 2024-05-19 13:26:46 --> Model Class Initialized
DEBUG - 2024-05-19 13:26:46 --> Session class already loaded. Second attempt ignored.
INFO - 2024-05-19 13:26:46 --> Final output sent to browser
DEBUG - 2024-05-19 13:26:46 --> Total execution time: 0.0607
ERROR - 2024-05-19 13:26:48 --> $config['composer_autoload'] is set to TRUE but E:\xampp\htdocs\maurnaturo\application\vendor/autoload.php was not found.
INFO - 2024-05-19 13:26:48 --> Config Class Initialized
INFO - 2024-05-19 13:26:48 --> Hooks Class Initialized
DEBUG - 2024-05-19 13:26:48 --> UTF-8 Support Enabled
INFO - 2024-05-19 13:26:48 --> Utf8 Class Initialized
INFO - 2024-05-19 13:26:48 --> URI Class Initialized
INFO - 2024-05-19 13:26:48 --> Router Class Initialized
INFO - 2024-05-19 13:26:48 --> Output Class Initialized
INFO - 2024-05-19 13:26:48 --> Security Class Initialized
DEBUG - 2024-05-19 13:26:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-19 13:26:48 --> Input Class Initialized
INFO - 2024-05-19 13:26:48 --> Language Class Initialized
INFO - 2024-05-19 13:26:48 --> Loader Class Initialized
INFO - 2024-05-19 13:26:48 --> Helper loaded: url_helper
INFO - 2024-05-19 13:26:48 --> Helper loaded: file_helper
INFO - 2024-05-19 13:26:48 --> Helper loaded: html_helper
INFO - 2024-05-19 13:26:48 --> Helper loaded: text_helper
INFO - 2024-05-19 13:26:48 --> Helper loaded: form_helper
INFO - 2024-05-19 13:26:48 --> Helper loaded: lang_helper
INFO - 2024-05-19 13:26:48 --> Helper loaded: security_helper
INFO - 2024-05-19 13:26:48 --> Helper loaded: cookie_helper
INFO - 2024-05-19 13:26:48 --> Database Driver Class Initialized
INFO - 2024-05-19 13:26:48 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-19 13:26:48 --> Parser Class Initialized
INFO - 2024-05-19 13:26:48 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-05-19 13:26:48 --> Pagination Class Initialized
INFO - 2024-05-19 13:26:48 --> Form Validation Class Initialized
INFO - 2024-05-19 13:26:48 --> Controller Class Initialized
INFO - 2024-05-19 13:26:48 --> Model Class Initialized
DEBUG - 2024-05-19 13:26:48 --> Session class already loaded. Second attempt ignored.
INFO - 2024-05-19 13:26:48 --> Final output sent to browser
DEBUG - 2024-05-19 13:26:48 --> Total execution time: 0.0704
ERROR - 2024-05-19 13:26:48 --> $config['composer_autoload'] is set to TRUE but E:\xampp\htdocs\maurnaturo\application\vendor/autoload.php was not found.
INFO - 2024-05-19 13:26:48 --> Config Class Initialized
INFO - 2024-05-19 13:26:48 --> Hooks Class Initialized
DEBUG - 2024-05-19 13:26:48 --> UTF-8 Support Enabled
INFO - 2024-05-19 13:26:48 --> Utf8 Class Initialized
INFO - 2024-05-19 13:26:48 --> URI Class Initialized
INFO - 2024-05-19 13:26:48 --> Router Class Initialized
INFO - 2024-05-19 13:26:48 --> Output Class Initialized
INFO - 2024-05-19 13:26:48 --> Security Class Initialized
DEBUG - 2024-05-19 13:26:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-19 13:26:48 --> Input Class Initialized
INFO - 2024-05-19 13:26:48 --> Language Class Initialized
INFO - 2024-05-19 13:26:48 --> Loader Class Initialized
INFO - 2024-05-19 13:26:48 --> Helper loaded: url_helper
INFO - 2024-05-19 13:26:48 --> Helper loaded: file_helper
INFO - 2024-05-19 13:26:48 --> Helper loaded: html_helper
INFO - 2024-05-19 13:26:48 --> Helper loaded: text_helper
INFO - 2024-05-19 13:26:48 --> Helper loaded: form_helper
INFO - 2024-05-19 13:26:48 --> Helper loaded: lang_helper
INFO - 2024-05-19 13:26:48 --> Helper loaded: security_helper
INFO - 2024-05-19 13:26:48 --> Helper loaded: cookie_helper
INFO - 2024-05-19 13:26:48 --> Database Driver Class Initialized
INFO - 2024-05-19 13:26:48 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-19 13:26:48 --> Parser Class Initialized
INFO - 2024-05-19 13:26:49 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-05-19 13:26:49 --> Pagination Class Initialized
INFO - 2024-05-19 13:26:49 --> Form Validation Class Initialized
INFO - 2024-05-19 13:26:49 --> Controller Class Initialized
INFO - 2024-05-19 13:26:49 --> Model Class Initialized
DEBUG - 2024-05-19 13:26:49 --> Session class already loaded. Second attempt ignored.
INFO - 2024-05-19 13:26:49 --> Final output sent to browser
DEBUG - 2024-05-19 13:26:49 --> Total execution time: 0.1146
ERROR - 2024-05-19 13:26:49 --> $config['composer_autoload'] is set to TRUE but E:\xampp\htdocs\maurnaturo\application\vendor/autoload.php was not found.
INFO - 2024-05-19 13:26:49 --> Config Class Initialized
INFO - 2024-05-19 13:26:49 --> Hooks Class Initialized
DEBUG - 2024-05-19 13:26:49 --> UTF-8 Support Enabled
INFO - 2024-05-19 13:26:49 --> Utf8 Class Initialized
INFO - 2024-05-19 13:26:49 --> URI Class Initialized
INFO - 2024-05-19 13:26:49 --> Router Class Initialized
INFO - 2024-05-19 13:26:49 --> Output Class Initialized
INFO - 2024-05-19 13:26:49 --> Security Class Initialized
DEBUG - 2024-05-19 13:26:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-19 13:26:49 --> Input Class Initialized
INFO - 2024-05-19 13:26:49 --> Language Class Initialized
INFO - 2024-05-19 13:26:49 --> Loader Class Initialized
INFO - 2024-05-19 13:26:49 --> Helper loaded: url_helper
INFO - 2024-05-19 13:26:49 --> Helper loaded: file_helper
INFO - 2024-05-19 13:26:49 --> Helper loaded: html_helper
INFO - 2024-05-19 13:26:49 --> Helper loaded: text_helper
INFO - 2024-05-19 13:26:49 --> Helper loaded: form_helper
INFO - 2024-05-19 13:26:49 --> Helper loaded: lang_helper
INFO - 2024-05-19 13:26:49 --> Helper loaded: security_helper
INFO - 2024-05-19 13:26:49 --> Helper loaded: cookie_helper
INFO - 2024-05-19 13:26:49 --> Database Driver Class Initialized
INFO - 2024-05-19 13:26:49 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-19 13:26:49 --> Parser Class Initialized
INFO - 2024-05-19 13:26:49 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-05-19 13:26:49 --> Pagination Class Initialized
INFO - 2024-05-19 13:26:49 --> Form Validation Class Initialized
INFO - 2024-05-19 13:26:49 --> Controller Class Initialized
INFO - 2024-05-19 13:26:49 --> Model Class Initialized
DEBUG - 2024-05-19 13:26:49 --> Session class already loaded. Second attempt ignored.
INFO - 2024-05-19 13:26:49 --> Final output sent to browser
DEBUG - 2024-05-19 13:26:49 --> Total execution time: 0.0885
ERROR - 2024-05-19 13:27:09 --> $config['composer_autoload'] is set to TRUE but E:\xampp\htdocs\maurnaturo\application\vendor/autoload.php was not found.
INFO - 2024-05-19 13:27:09 --> Config Class Initialized
INFO - 2024-05-19 13:27:09 --> Hooks Class Initialized
DEBUG - 2024-05-19 13:27:09 --> UTF-8 Support Enabled
INFO - 2024-05-19 13:27:09 --> Utf8 Class Initialized
INFO - 2024-05-19 13:27:09 --> URI Class Initialized
INFO - 2024-05-19 13:27:09 --> Router Class Initialized
INFO - 2024-05-19 13:27:09 --> Output Class Initialized
INFO - 2024-05-19 13:27:09 --> Security Class Initialized
DEBUG - 2024-05-19 13:27:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-19 13:27:09 --> Input Class Initialized
INFO - 2024-05-19 13:27:09 --> Language Class Initialized
INFO - 2024-05-19 13:27:10 --> Loader Class Initialized
INFO - 2024-05-19 13:27:10 --> Helper loaded: url_helper
INFO - 2024-05-19 13:27:10 --> Helper loaded: file_helper
INFO - 2024-05-19 13:27:10 --> Helper loaded: html_helper
INFO - 2024-05-19 13:27:10 --> Helper loaded: text_helper
INFO - 2024-05-19 13:27:10 --> Helper loaded: form_helper
INFO - 2024-05-19 13:27:10 --> Helper loaded: lang_helper
INFO - 2024-05-19 13:27:10 --> Helper loaded: security_helper
INFO - 2024-05-19 13:27:10 --> Helper loaded: cookie_helper
INFO - 2024-05-19 13:27:10 --> Database Driver Class Initialized
INFO - 2024-05-19 13:27:10 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-19 13:27:10 --> Parser Class Initialized
INFO - 2024-05-19 13:27:10 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-05-19 13:27:10 --> Pagination Class Initialized
INFO - 2024-05-19 13:27:10 --> Form Validation Class Initialized
INFO - 2024-05-19 13:27:10 --> Controller Class Initialized
DEBUG - 2024-05-19 13:27:10 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-05-19 13:27:10 --> Session class already loaded. Second attempt ignored.
INFO - 2024-05-19 13:27:10 --> Model Class Initialized
INFO - 2024-05-19 13:27:10 --> Model Class Initialized
DEBUG - 2024-05-19 13:27:10 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-05-19 13:27:10 --> Session class already loaded. Second attempt ignored.
INFO - 2024-05-19 13:27:10 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\payments/add_payment_form.php
DEBUG - 2024-05-19 13:27:10 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-05-19 13:27:10 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\include/top_menu.php
INFO - 2024-05-19 13:27:10 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\include/admin_loggedin_info.php
INFO - 2024-05-19 13:27:10 --> Model Class Initialized
INFO - 2024-05-19 13:27:10 --> Model Class Initialized
INFO - 2024-05-19 13:27:10 --> Model Class Initialized
INFO - 2024-05-19 13:27:10 --> Model Class Initialized
INFO - 2024-05-19 13:27:11 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\include/admin_header.php
INFO - 2024-05-19 13:27:11 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\include/admin_footer.php
INFO - 2024-05-19 13:27:11 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\admin_html_template.php
INFO - 2024-05-19 13:27:11 --> Final output sent to browser
DEBUG - 2024-05-19 13:27:11 --> Total execution time: 1.5991
ERROR - 2024-05-19 13:27:23 --> $config['composer_autoload'] is set to TRUE but E:\xampp\htdocs\maurnaturo\application\vendor/autoload.php was not found.
INFO - 2024-05-19 13:27:23 --> Config Class Initialized
INFO - 2024-05-19 13:27:23 --> Hooks Class Initialized
DEBUG - 2024-05-19 13:27:23 --> UTF-8 Support Enabled
INFO - 2024-05-19 13:27:23 --> Utf8 Class Initialized
INFO - 2024-05-19 13:27:23 --> URI Class Initialized
INFO - 2024-05-19 13:27:23 --> Router Class Initialized
INFO - 2024-05-19 13:27:23 --> Output Class Initialized
INFO - 2024-05-19 13:27:23 --> Security Class Initialized
DEBUG - 2024-05-19 13:27:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-19 13:27:23 --> Input Class Initialized
INFO - 2024-05-19 13:27:23 --> Language Class Initialized
INFO - 2024-05-19 13:27:23 --> Loader Class Initialized
INFO - 2024-05-19 13:27:23 --> Helper loaded: url_helper
INFO - 2024-05-19 13:27:23 --> Helper loaded: file_helper
INFO - 2024-05-19 13:27:23 --> Helper loaded: html_helper
INFO - 2024-05-19 13:27:23 --> Helper loaded: text_helper
INFO - 2024-05-19 13:27:23 --> Helper loaded: form_helper
INFO - 2024-05-19 13:27:23 --> Helper loaded: lang_helper
INFO - 2024-05-19 13:27:23 --> Helper loaded: security_helper
INFO - 2024-05-19 13:27:23 --> Helper loaded: cookie_helper
INFO - 2024-05-19 13:27:23 --> Database Driver Class Initialized
INFO - 2024-05-19 13:27:23 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-19 13:27:23 --> Parser Class Initialized
INFO - 2024-05-19 13:27:23 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-05-19 13:27:23 --> Pagination Class Initialized
INFO - 2024-05-19 13:27:23 --> Form Validation Class Initialized
INFO - 2024-05-19 13:27:23 --> Controller Class Initialized
INFO - 2024-05-19 13:27:23 --> Model Class Initialized
DEBUG - 2024-05-19 13:27:23 --> Session class already loaded. Second attempt ignored.
INFO - 2024-05-19 13:27:23 --> Final output sent to browser
DEBUG - 2024-05-19 13:27:23 --> Total execution time: 0.0646
ERROR - 2024-05-19 13:27:36 --> $config['composer_autoload'] is set to TRUE but E:\xampp\htdocs\maurnaturo\application\vendor/autoload.php was not found.
INFO - 2024-05-19 13:27:36 --> Config Class Initialized
INFO - 2024-05-19 13:27:36 --> Hooks Class Initialized
DEBUG - 2024-05-19 13:27:36 --> UTF-8 Support Enabled
INFO - 2024-05-19 13:27:36 --> Utf8 Class Initialized
INFO - 2024-05-19 13:27:36 --> URI Class Initialized
INFO - 2024-05-19 13:27:36 --> Router Class Initialized
INFO - 2024-05-19 13:27:36 --> Output Class Initialized
INFO - 2024-05-19 13:27:36 --> Security Class Initialized
DEBUG - 2024-05-19 13:27:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-19 13:27:36 --> Input Class Initialized
INFO - 2024-05-19 13:27:36 --> Language Class Initialized
INFO - 2024-05-19 13:27:36 --> Loader Class Initialized
INFO - 2024-05-19 13:27:36 --> Helper loaded: url_helper
INFO - 2024-05-19 13:27:36 --> Helper loaded: file_helper
INFO - 2024-05-19 13:27:36 --> Helper loaded: html_helper
INFO - 2024-05-19 13:27:36 --> Helper loaded: text_helper
INFO - 2024-05-19 13:27:36 --> Helper loaded: form_helper
INFO - 2024-05-19 13:27:36 --> Helper loaded: lang_helper
INFO - 2024-05-19 13:27:36 --> Helper loaded: security_helper
INFO - 2024-05-19 13:27:36 --> Helper loaded: cookie_helper
INFO - 2024-05-19 13:27:36 --> Database Driver Class Initialized
INFO - 2024-05-19 13:27:36 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-19 13:27:36 --> Parser Class Initialized
INFO - 2024-05-19 13:27:36 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-05-19 13:27:36 --> Pagination Class Initialized
INFO - 2024-05-19 13:27:36 --> Form Validation Class Initialized
INFO - 2024-05-19 13:27:36 --> Controller Class Initialized
DEBUG - 2024-05-19 13:27:36 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-05-19 13:27:36 --> Session class already loaded. Second attempt ignored.
INFO - 2024-05-19 13:27:36 --> Model Class Initialized
ERROR - 2024-05-19 13:27:46 --> $config['composer_autoload'] is set to TRUE but E:\xampp\htdocs\maurnaturo\application\vendor/autoload.php was not found.
INFO - 2024-05-19 13:27:46 --> Config Class Initialized
INFO - 2024-05-19 13:27:46 --> Hooks Class Initialized
DEBUG - 2024-05-19 13:27:46 --> UTF-8 Support Enabled
INFO - 2024-05-19 13:27:46 --> Utf8 Class Initialized
INFO - 2024-05-19 13:27:46 --> URI Class Initialized
INFO - 2024-05-19 13:27:46 --> Router Class Initialized
INFO - 2024-05-19 13:27:46 --> Output Class Initialized
INFO - 2024-05-19 13:27:46 --> Security Class Initialized
DEBUG - 2024-05-19 13:27:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-19 13:27:46 --> Input Class Initialized
INFO - 2024-05-19 13:27:46 --> Language Class Initialized
INFO - 2024-05-19 13:27:46 --> Loader Class Initialized
INFO - 2024-05-19 13:27:46 --> Helper loaded: url_helper
INFO - 2024-05-19 13:27:46 --> Helper loaded: file_helper
INFO - 2024-05-19 13:27:46 --> Helper loaded: html_helper
INFO - 2024-05-19 13:27:46 --> Helper loaded: text_helper
INFO - 2024-05-19 13:27:46 --> Helper loaded: form_helper
INFO - 2024-05-19 13:27:46 --> Helper loaded: lang_helper
INFO - 2024-05-19 13:27:46 --> Helper loaded: security_helper
INFO - 2024-05-19 13:27:46 --> Helper loaded: cookie_helper
INFO - 2024-05-19 13:27:46 --> Database Driver Class Initialized
INFO - 2024-05-19 13:27:46 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-19 13:27:46 --> Parser Class Initialized
INFO - 2024-05-19 13:27:46 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-05-19 13:27:46 --> Pagination Class Initialized
INFO - 2024-05-19 13:27:46 --> Form Validation Class Initialized
INFO - 2024-05-19 13:27:46 --> Controller Class Initialized
DEBUG - 2024-05-19 13:27:46 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-05-19 13:27:46 --> Session class already loaded. Second attempt ignored.
INFO - 2024-05-19 13:27:46 --> Model Class Initialized
INFO - 2024-05-19 13:27:46 --> Final output sent to browser
DEBUG - 2024-05-19 13:27:46 --> Total execution time: 0.0995
ERROR - 2024-05-19 13:27:53 --> $config['composer_autoload'] is set to TRUE but E:\xampp\htdocs\maurnaturo\application\vendor/autoload.php was not found.
INFO - 2024-05-19 13:27:53 --> Config Class Initialized
INFO - 2024-05-19 13:27:53 --> Hooks Class Initialized
DEBUG - 2024-05-19 13:27:53 --> UTF-8 Support Enabled
INFO - 2024-05-19 13:27:53 --> Utf8 Class Initialized
INFO - 2024-05-19 13:27:53 --> URI Class Initialized
DEBUG - 2024-05-19 13:27:53 --> No URI present. Default controller set.
INFO - 2024-05-19 13:27:53 --> Router Class Initialized
INFO - 2024-05-19 13:27:53 --> Output Class Initialized
INFO - 2024-05-19 13:27:53 --> Security Class Initialized
DEBUG - 2024-05-19 13:27:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-19 13:27:53 --> Input Class Initialized
INFO - 2024-05-19 13:27:53 --> Language Class Initialized
INFO - 2024-05-19 13:27:53 --> Loader Class Initialized
INFO - 2024-05-19 13:27:53 --> Helper loaded: url_helper
INFO - 2024-05-19 13:27:53 --> Helper loaded: file_helper
INFO - 2024-05-19 13:27:53 --> Helper loaded: html_helper
INFO - 2024-05-19 13:27:53 --> Helper loaded: text_helper
INFO - 2024-05-19 13:27:53 --> Helper loaded: form_helper
INFO - 2024-05-19 13:27:53 --> Helper loaded: lang_helper
INFO - 2024-05-19 13:27:53 --> Helper loaded: security_helper
INFO - 2024-05-19 13:27:53 --> Helper loaded: cookie_helper
INFO - 2024-05-19 13:27:53 --> Database Driver Class Initialized
INFO - 2024-05-19 13:27:53 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-19 13:27:53 --> Parser Class Initialized
INFO - 2024-05-19 13:27:53 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-05-19 13:27:53 --> Pagination Class Initialized
INFO - 2024-05-19 13:27:53 --> Form Validation Class Initialized
INFO - 2024-05-19 13:27:53 --> Controller Class Initialized
INFO - 2024-05-19 13:27:53 --> Model Class Initialized
DEBUG - 2024-05-19 13:27:53 --> Session class already loaded. Second attempt ignored.
INFO - 2024-05-19 13:27:53 --> Model Class Initialized
DEBUG - 2024-05-19 13:27:53 --> Session class already loaded. Second attempt ignored.
INFO - 2024-05-19 13:27:53 --> Model Class Initialized
INFO - 2024-05-19 13:27:53 --> Model Class Initialized
INFO - 2024-05-19 13:27:53 --> Model Class Initialized
INFO - 2024-05-19 13:27:53 --> Model Class Initialized
DEBUG - 2024-05-19 13:27:53 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-05-19 13:27:53 --> Session class already loaded. Second attempt ignored.
INFO - 2024-05-19 13:27:53 --> Model Class Initialized
INFO - 2024-05-19 13:27:53 --> Model Class Initialized
INFO - 2024-05-19 13:27:54 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\include/admin_home.php
DEBUG - 2024-05-19 13:27:54 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-05-19 13:27:54 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\include/top_menu.php
INFO - 2024-05-19 13:27:54 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\include/admin_loggedin_info.php
INFO - 2024-05-19 13:27:54 --> Model Class Initialized
INFO - 2024-05-19 13:27:56 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\include/admin_header.php
INFO - 2024-05-19 13:27:56 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\include/admin_footer.php
INFO - 2024-05-19 13:27:56 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\admin_html_template.php
INFO - 2024-05-19 13:27:56 --> Final output sent to browser
DEBUG - 2024-05-19 13:27:56 --> Total execution time: 2.7925
ERROR - 2024-05-19 13:28:12 --> $config['composer_autoload'] is set to TRUE but E:\xampp\htdocs\maurnaturo\application\vendor/autoload.php was not found.
INFO - 2024-05-19 13:28:12 --> Config Class Initialized
INFO - 2024-05-19 13:28:12 --> Hooks Class Initialized
DEBUG - 2024-05-19 13:28:12 --> UTF-8 Support Enabled
INFO - 2024-05-19 13:28:12 --> Utf8 Class Initialized
INFO - 2024-05-19 13:28:12 --> URI Class Initialized
INFO - 2024-05-19 13:28:12 --> Router Class Initialized
INFO - 2024-05-19 13:28:12 --> Output Class Initialized
INFO - 2024-05-19 13:28:12 --> Security Class Initialized
DEBUG - 2024-05-19 13:28:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-19 13:28:12 --> Input Class Initialized
INFO - 2024-05-19 13:28:12 --> Language Class Initialized
INFO - 2024-05-19 13:28:12 --> Loader Class Initialized
INFO - 2024-05-19 13:28:12 --> Helper loaded: url_helper
INFO - 2024-05-19 13:28:12 --> Helper loaded: file_helper
INFO - 2024-05-19 13:28:12 --> Helper loaded: html_helper
INFO - 2024-05-19 13:28:12 --> Helper loaded: text_helper
INFO - 2024-05-19 13:28:12 --> Helper loaded: form_helper
INFO - 2024-05-19 13:28:12 --> Helper loaded: lang_helper
INFO - 2024-05-19 13:28:12 --> Helper loaded: security_helper
INFO - 2024-05-19 13:28:12 --> Helper loaded: cookie_helper
INFO - 2024-05-19 13:28:12 --> Database Driver Class Initialized
INFO - 2024-05-19 13:28:12 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-19 13:28:12 --> Parser Class Initialized
INFO - 2024-05-19 13:28:12 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-05-19 13:28:12 --> Pagination Class Initialized
INFO - 2024-05-19 13:28:12 --> Form Validation Class Initialized
INFO - 2024-05-19 13:28:12 --> Controller Class Initialized
DEBUG - 2024-05-19 13:28:12 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-05-19 13:28:12 --> Session class already loaded. Second attempt ignored.
INFO - 2024-05-19 13:28:12 --> Model Class Initialized
INFO - 2024-05-19 13:28:12 --> Final output sent to browser
DEBUG - 2024-05-19 13:28:12 --> Total execution time: 0.0996
ERROR - 2024-05-19 13:28:13 --> $config['composer_autoload'] is set to TRUE but E:\xampp\htdocs\maurnaturo\application\vendor/autoload.php was not found.
INFO - 2024-05-19 13:28:13 --> Config Class Initialized
INFO - 2024-05-19 13:28:13 --> Hooks Class Initialized
DEBUG - 2024-05-19 13:28:13 --> UTF-8 Support Enabled
INFO - 2024-05-19 13:28:13 --> Utf8 Class Initialized
INFO - 2024-05-19 13:28:13 --> URI Class Initialized
DEBUG - 2024-05-19 13:28:13 --> No URI present. Default controller set.
INFO - 2024-05-19 13:28:13 --> Router Class Initialized
INFO - 2024-05-19 13:28:13 --> Output Class Initialized
INFO - 2024-05-19 13:28:13 --> Security Class Initialized
DEBUG - 2024-05-19 13:28:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-19 13:28:13 --> Input Class Initialized
INFO - 2024-05-19 13:28:13 --> Language Class Initialized
INFO - 2024-05-19 13:28:13 --> Loader Class Initialized
INFO - 2024-05-19 13:28:13 --> Helper loaded: url_helper
INFO - 2024-05-19 13:28:13 --> Helper loaded: file_helper
INFO - 2024-05-19 13:28:13 --> Helper loaded: html_helper
INFO - 2024-05-19 13:28:13 --> Helper loaded: text_helper
INFO - 2024-05-19 13:28:13 --> Helper loaded: form_helper
INFO - 2024-05-19 13:28:13 --> Helper loaded: lang_helper
INFO - 2024-05-19 13:28:13 --> Helper loaded: security_helper
INFO - 2024-05-19 13:28:13 --> Helper loaded: cookie_helper
INFO - 2024-05-19 13:28:13 --> Database Driver Class Initialized
INFO - 2024-05-19 13:28:13 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-19 13:28:13 --> Parser Class Initialized
INFO - 2024-05-19 13:28:13 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-05-19 13:28:13 --> Pagination Class Initialized
INFO - 2024-05-19 13:28:13 --> Form Validation Class Initialized
INFO - 2024-05-19 13:28:13 --> Controller Class Initialized
INFO - 2024-05-19 13:28:13 --> Model Class Initialized
DEBUG - 2024-05-19 13:28:13 --> Session class already loaded. Second attempt ignored.
INFO - 2024-05-19 13:28:13 --> Model Class Initialized
DEBUG - 2024-05-19 13:28:13 --> Session class already loaded. Second attempt ignored.
INFO - 2024-05-19 13:28:13 --> Model Class Initialized
INFO - 2024-05-19 13:28:13 --> Model Class Initialized
INFO - 2024-05-19 13:28:13 --> Model Class Initialized
INFO - 2024-05-19 13:28:13 --> Model Class Initialized
DEBUG - 2024-05-19 13:28:13 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-05-19 13:28:13 --> Session class already loaded. Second attempt ignored.
INFO - 2024-05-19 13:28:13 --> Model Class Initialized
INFO - 2024-05-19 13:28:13 --> Model Class Initialized
INFO - 2024-05-19 13:28:14 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\include/admin_home.php
DEBUG - 2024-05-19 13:28:14 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-05-19 13:28:14 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\include/top_menu.php
INFO - 2024-05-19 13:28:14 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\include/admin_loggedin_info.php
INFO - 2024-05-19 13:28:14 --> Model Class Initialized
INFO - 2024-05-19 13:28:15 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\include/admin_header.php
INFO - 2024-05-19 13:28:15 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\include/admin_footer.php
INFO - 2024-05-19 13:28:15 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\admin_html_template.php
INFO - 2024-05-19 13:28:15 --> Final output sent to browser
DEBUG - 2024-05-19 13:28:15 --> Total execution time: 1.9324
ERROR - 2024-05-19 13:28:27 --> $config['composer_autoload'] is set to TRUE but E:\xampp\htdocs\maurnaturo\application\vendor/autoload.php was not found.
INFO - 2024-05-19 13:28:27 --> Config Class Initialized
INFO - 2024-05-19 13:28:27 --> Hooks Class Initialized
DEBUG - 2024-05-19 13:28:27 --> UTF-8 Support Enabled
INFO - 2024-05-19 13:28:27 --> Utf8 Class Initialized
INFO - 2024-05-19 13:28:27 --> URI Class Initialized
INFO - 2024-05-19 13:28:27 --> Router Class Initialized
INFO - 2024-05-19 13:28:27 --> Output Class Initialized
INFO - 2024-05-19 13:28:27 --> Security Class Initialized
DEBUG - 2024-05-19 13:28:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-19 13:28:27 --> Input Class Initialized
INFO - 2024-05-19 13:28:27 --> Language Class Initialized
INFO - 2024-05-19 13:28:27 --> Loader Class Initialized
INFO - 2024-05-19 13:28:27 --> Helper loaded: url_helper
INFO - 2024-05-19 13:28:27 --> Helper loaded: file_helper
INFO - 2024-05-19 13:28:27 --> Helper loaded: html_helper
INFO - 2024-05-19 13:28:27 --> Helper loaded: text_helper
INFO - 2024-05-19 13:28:27 --> Helper loaded: form_helper
INFO - 2024-05-19 13:28:27 --> Helper loaded: lang_helper
INFO - 2024-05-19 13:28:27 --> Helper loaded: security_helper
INFO - 2024-05-19 13:28:27 --> Helper loaded: cookie_helper
INFO - 2024-05-19 13:28:27 --> Database Driver Class Initialized
INFO - 2024-05-19 13:28:27 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-19 13:28:27 --> Parser Class Initialized
INFO - 2024-05-19 13:28:27 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-05-19 13:28:27 --> Pagination Class Initialized
INFO - 2024-05-19 13:28:27 --> Form Validation Class Initialized
INFO - 2024-05-19 13:28:27 --> Controller Class Initialized
DEBUG - 2024-05-19 13:28:27 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-05-19 13:28:27 --> Session class already loaded. Second attempt ignored.
INFO - 2024-05-19 13:28:27 --> Model Class Initialized
INFO - 2024-05-19 13:28:27 --> Final output sent to browser
DEBUG - 2024-05-19 13:28:27 --> Total execution time: 0.1138
ERROR - 2024-05-19 13:28:30 --> $config['composer_autoload'] is set to TRUE but E:\xampp\htdocs\maurnaturo\application\vendor/autoload.php was not found.
INFO - 2024-05-19 13:28:30 --> Config Class Initialized
INFO - 2024-05-19 13:28:30 --> Hooks Class Initialized
DEBUG - 2024-05-19 13:28:30 --> UTF-8 Support Enabled
INFO - 2024-05-19 13:28:30 --> Utf8 Class Initialized
INFO - 2024-05-19 13:28:30 --> URI Class Initialized
DEBUG - 2024-05-19 13:28:30 --> No URI present. Default controller set.
INFO - 2024-05-19 13:28:30 --> Router Class Initialized
INFO - 2024-05-19 13:28:30 --> Output Class Initialized
INFO - 2024-05-19 13:28:30 --> Security Class Initialized
DEBUG - 2024-05-19 13:28:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-19 13:28:30 --> Input Class Initialized
INFO - 2024-05-19 13:28:30 --> Language Class Initialized
INFO - 2024-05-19 13:28:30 --> Loader Class Initialized
INFO - 2024-05-19 13:28:30 --> Helper loaded: url_helper
INFO - 2024-05-19 13:28:30 --> Helper loaded: file_helper
INFO - 2024-05-19 13:28:30 --> Helper loaded: html_helper
INFO - 2024-05-19 13:28:30 --> Helper loaded: text_helper
INFO - 2024-05-19 13:28:30 --> Helper loaded: form_helper
INFO - 2024-05-19 13:28:30 --> Helper loaded: lang_helper
INFO - 2024-05-19 13:28:30 --> Helper loaded: security_helper
INFO - 2024-05-19 13:28:30 --> Helper loaded: cookie_helper
INFO - 2024-05-19 13:28:30 --> Database Driver Class Initialized
INFO - 2024-05-19 13:28:30 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-19 13:28:30 --> Parser Class Initialized
INFO - 2024-05-19 13:28:30 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-05-19 13:28:30 --> Pagination Class Initialized
INFO - 2024-05-19 13:28:30 --> Form Validation Class Initialized
INFO - 2024-05-19 13:28:30 --> Controller Class Initialized
INFO - 2024-05-19 13:28:30 --> Model Class Initialized
DEBUG - 2024-05-19 13:28:30 --> Session class already loaded. Second attempt ignored.
INFO - 2024-05-19 13:28:30 --> Model Class Initialized
DEBUG - 2024-05-19 13:28:30 --> Session class already loaded. Second attempt ignored.
INFO - 2024-05-19 13:28:30 --> Model Class Initialized
INFO - 2024-05-19 13:28:30 --> Model Class Initialized
INFO - 2024-05-19 13:28:30 --> Model Class Initialized
INFO - 2024-05-19 13:28:30 --> Model Class Initialized
DEBUG - 2024-05-19 13:28:30 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-05-19 13:28:30 --> Session class already loaded. Second attempt ignored.
INFO - 2024-05-19 13:28:30 --> Model Class Initialized
INFO - 2024-05-19 13:28:30 --> Model Class Initialized
INFO - 2024-05-19 13:28:31 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\include/admin_home.php
DEBUG - 2024-05-19 13:28:31 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-05-19 13:28:31 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\include/top_menu.php
INFO - 2024-05-19 13:28:31 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\include/admin_loggedin_info.php
INFO - 2024-05-19 13:28:31 --> Model Class Initialized
INFO - 2024-05-19 13:28:31 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\include/admin_header.php
INFO - 2024-05-19 13:28:31 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\include/admin_footer.php
INFO - 2024-05-19 13:28:31 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\admin_html_template.php
INFO - 2024-05-19 13:28:31 --> Final output sent to browser
DEBUG - 2024-05-19 13:28:31 --> Total execution time: 1.9206
ERROR - 2024-05-19 13:28:45 --> $config['composer_autoload'] is set to TRUE but E:\xampp\htdocs\maurnaturo\application\vendor/autoload.php was not found.
INFO - 2024-05-19 13:28:45 --> Config Class Initialized
INFO - 2024-05-19 13:28:45 --> Hooks Class Initialized
DEBUG - 2024-05-19 13:28:45 --> UTF-8 Support Enabled
INFO - 2024-05-19 13:28:45 --> Utf8 Class Initialized
INFO - 2024-05-19 13:28:45 --> URI Class Initialized
INFO - 2024-05-19 13:28:45 --> Router Class Initialized
INFO - 2024-05-19 13:28:45 --> Output Class Initialized
INFO - 2024-05-19 13:28:45 --> Security Class Initialized
DEBUG - 2024-05-19 13:28:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-19 13:28:45 --> Input Class Initialized
INFO - 2024-05-19 13:28:45 --> Language Class Initialized
INFO - 2024-05-19 13:28:45 --> Loader Class Initialized
INFO - 2024-05-19 13:28:45 --> Helper loaded: url_helper
INFO - 2024-05-19 13:28:45 --> Helper loaded: file_helper
INFO - 2024-05-19 13:28:45 --> Helper loaded: html_helper
INFO - 2024-05-19 13:28:45 --> Helper loaded: text_helper
INFO - 2024-05-19 13:28:45 --> Helper loaded: form_helper
INFO - 2024-05-19 13:28:45 --> Helper loaded: lang_helper
INFO - 2024-05-19 13:28:45 --> Helper loaded: security_helper
INFO - 2024-05-19 13:28:45 --> Helper loaded: cookie_helper
INFO - 2024-05-19 13:28:45 --> Database Driver Class Initialized
INFO - 2024-05-19 13:28:45 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-19 13:28:45 --> Parser Class Initialized
INFO - 2024-05-19 13:28:45 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-05-19 13:28:45 --> Pagination Class Initialized
INFO - 2024-05-19 13:28:45 --> Form Validation Class Initialized
INFO - 2024-05-19 13:28:45 --> Controller Class Initialized
DEBUG - 2024-05-19 13:28:45 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-05-19 13:28:45 --> Session class already loaded. Second attempt ignored.
INFO - 2024-05-19 13:28:45 --> Model Class Initialized
INFO - 2024-05-19 13:28:45 --> Model Class Initialized
DEBUG - 2024-05-19 13:28:45 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-05-19 13:28:45 --> Session class already loaded. Second attempt ignored.
INFO - 2024-05-19 13:28:45 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\payments/add_payment_form.php
DEBUG - 2024-05-19 13:28:45 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-05-19 13:28:45 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\include/top_menu.php
INFO - 2024-05-19 13:28:45 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\include/admin_loggedin_info.php
INFO - 2024-05-19 13:28:45 --> Model Class Initialized
INFO - 2024-05-19 13:28:45 --> Model Class Initialized
INFO - 2024-05-19 13:28:45 --> Model Class Initialized
INFO - 2024-05-19 13:28:45 --> Model Class Initialized
INFO - 2024-05-19 13:28:46 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\include/admin_header.php
INFO - 2024-05-19 13:28:46 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\include/admin_footer.php
INFO - 2024-05-19 13:28:46 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\admin_html_template.php
INFO - 2024-05-19 13:28:46 --> Final output sent to browser
DEBUG - 2024-05-19 13:28:46 --> Total execution time: 1.5255
ERROR - 2024-05-19 13:28:52 --> $config['composer_autoload'] is set to TRUE but E:\xampp\htdocs\maurnaturo\application\vendor/autoload.php was not found.
INFO - 2024-05-19 13:28:52 --> Config Class Initialized
INFO - 2024-05-19 13:28:52 --> Hooks Class Initialized
DEBUG - 2024-05-19 13:28:52 --> UTF-8 Support Enabled
INFO - 2024-05-19 13:28:52 --> Utf8 Class Initialized
INFO - 2024-05-19 13:28:52 --> URI Class Initialized
INFO - 2024-05-19 13:28:52 --> Router Class Initialized
INFO - 2024-05-19 13:28:52 --> Output Class Initialized
INFO - 2024-05-19 13:28:52 --> Security Class Initialized
DEBUG - 2024-05-19 13:28:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-19 13:28:52 --> Input Class Initialized
INFO - 2024-05-19 13:28:52 --> Language Class Initialized
INFO - 2024-05-19 13:28:52 --> Loader Class Initialized
INFO - 2024-05-19 13:28:52 --> Helper loaded: url_helper
INFO - 2024-05-19 13:28:52 --> Helper loaded: file_helper
INFO - 2024-05-19 13:28:52 --> Helper loaded: html_helper
INFO - 2024-05-19 13:28:52 --> Helper loaded: text_helper
INFO - 2024-05-19 13:28:52 --> Helper loaded: form_helper
INFO - 2024-05-19 13:28:52 --> Helper loaded: lang_helper
INFO - 2024-05-19 13:28:52 --> Helper loaded: security_helper
INFO - 2024-05-19 13:28:52 --> Helper loaded: cookie_helper
INFO - 2024-05-19 13:28:52 --> Database Driver Class Initialized
INFO - 2024-05-19 13:28:52 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-19 13:28:52 --> Parser Class Initialized
INFO - 2024-05-19 13:28:52 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-05-19 13:28:52 --> Pagination Class Initialized
INFO - 2024-05-19 13:28:52 --> Form Validation Class Initialized
INFO - 2024-05-19 13:28:52 --> Controller Class Initialized
DEBUG - 2024-05-19 13:28:52 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-05-19 13:28:52 --> Session class already loaded. Second attempt ignored.
INFO - 2024-05-19 13:28:52 --> Model Class Initialized
INFO - 2024-05-19 13:28:52 --> Model Class Initialized
DEBUG - 2024-05-19 13:28:52 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-05-19 13:28:52 --> Session class already loaded. Second attempt ignored.
INFO - 2024-05-19 13:28:52 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\mr_payments/add_payment_form.php
DEBUG - 2024-05-19 13:28:52 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-05-19 13:28:52 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\include/top_menu.php
INFO - 2024-05-19 13:28:52 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\include/admin_loggedin_info.php
INFO - 2024-05-19 13:28:52 --> Model Class Initialized
INFO - 2024-05-19 13:28:52 --> Model Class Initialized
INFO - 2024-05-19 13:28:52 --> Model Class Initialized
INFO - 2024-05-19 13:28:52 --> Model Class Initialized
INFO - 2024-05-19 13:28:53 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\include/admin_header.php
INFO - 2024-05-19 13:28:53 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\include/admin_footer.php
INFO - 2024-05-19 13:28:53 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\admin_html_template.php
INFO - 2024-05-19 13:28:53 --> Final output sent to browser
DEBUG - 2024-05-19 13:28:53 --> Total execution time: 1.5274
ERROR - 2024-05-19 13:29:04 --> $config['composer_autoload'] is set to TRUE but E:\xampp\htdocs\maurnaturo\application\vendor/autoload.php was not found.
INFO - 2024-05-19 13:29:04 --> Config Class Initialized
INFO - 2024-05-19 13:29:04 --> Hooks Class Initialized
DEBUG - 2024-05-19 13:29:04 --> UTF-8 Support Enabled
INFO - 2024-05-19 13:29:04 --> Utf8 Class Initialized
INFO - 2024-05-19 13:29:04 --> URI Class Initialized
INFO - 2024-05-19 13:29:04 --> Router Class Initialized
INFO - 2024-05-19 13:29:04 --> Output Class Initialized
INFO - 2024-05-19 13:29:04 --> Security Class Initialized
DEBUG - 2024-05-19 13:29:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-19 13:29:04 --> Input Class Initialized
INFO - 2024-05-19 13:29:04 --> Language Class Initialized
INFO - 2024-05-19 13:29:04 --> Loader Class Initialized
INFO - 2024-05-19 13:29:04 --> Helper loaded: url_helper
INFO - 2024-05-19 13:29:04 --> Helper loaded: file_helper
INFO - 2024-05-19 13:29:04 --> Helper loaded: html_helper
INFO - 2024-05-19 13:29:04 --> Helper loaded: text_helper
INFO - 2024-05-19 13:29:04 --> Helper loaded: form_helper
INFO - 2024-05-19 13:29:04 --> Helper loaded: lang_helper
INFO - 2024-05-19 13:29:04 --> Helper loaded: security_helper
INFO - 2024-05-19 13:29:04 --> Helper loaded: cookie_helper
INFO - 2024-05-19 13:29:04 --> Database Driver Class Initialized
INFO - 2024-05-19 13:29:04 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-19 13:29:04 --> Parser Class Initialized
INFO - 2024-05-19 13:29:04 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-05-19 13:29:04 --> Pagination Class Initialized
INFO - 2024-05-19 13:29:04 --> Form Validation Class Initialized
INFO - 2024-05-19 13:29:04 --> Controller Class Initialized
DEBUG - 2024-05-19 13:29:04 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-05-19 13:29:04 --> Session class already loaded. Second attempt ignored.
INFO - 2024-05-19 13:29:04 --> Model Class Initialized
DEBUG - 2024-05-19 13:29:04 --> Lpayments class already loaded. Second attempt ignored.
INFO - 2024-05-19 13:29:04 --> Model Class Initialized
INFO - 2024-05-19 13:29:04 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\payments/payment.php
DEBUG - 2024-05-19 13:29:04 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-05-19 13:29:04 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\include/top_menu.php
INFO - 2024-05-19 13:29:04 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\include/admin_loggedin_info.php
INFO - 2024-05-19 13:29:04 --> Model Class Initialized
INFO - 2024-05-19 13:29:04 --> Model Class Initialized
INFO - 2024-05-19 13:29:04 --> Model Class Initialized
INFO - 2024-05-19 13:29:05 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\include/admin_header.php
INFO - 2024-05-19 13:29:05 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\include/admin_footer.php
INFO - 2024-05-19 13:29:05 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\admin_html_template.php
INFO - 2024-05-19 13:29:05 --> Final output sent to browser
DEBUG - 2024-05-19 13:29:05 --> Total execution time: 1.4843
ERROR - 2024-05-19 13:29:06 --> $config['composer_autoload'] is set to TRUE but E:\xampp\htdocs\maurnaturo\application\vendor/autoload.php was not found.
INFO - 2024-05-19 13:29:06 --> Config Class Initialized
INFO - 2024-05-19 13:29:06 --> Hooks Class Initialized
DEBUG - 2024-05-19 13:29:06 --> UTF-8 Support Enabled
INFO - 2024-05-19 13:29:06 --> Utf8 Class Initialized
INFO - 2024-05-19 13:29:06 --> URI Class Initialized
INFO - 2024-05-19 13:29:06 --> Router Class Initialized
INFO - 2024-05-19 13:29:06 --> Output Class Initialized
INFO - 2024-05-19 13:29:06 --> Security Class Initialized
DEBUG - 2024-05-19 13:29:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-19 13:29:06 --> Input Class Initialized
INFO - 2024-05-19 13:29:06 --> Language Class Initialized
INFO - 2024-05-19 13:29:06 --> Loader Class Initialized
INFO - 2024-05-19 13:29:06 --> Helper loaded: url_helper
INFO - 2024-05-19 13:29:06 --> Helper loaded: file_helper
INFO - 2024-05-19 13:29:06 --> Helper loaded: html_helper
INFO - 2024-05-19 13:29:06 --> Helper loaded: text_helper
INFO - 2024-05-19 13:29:06 --> Helper loaded: form_helper
INFO - 2024-05-19 13:29:06 --> Helper loaded: lang_helper
INFO - 2024-05-19 13:29:06 --> Helper loaded: security_helper
INFO - 2024-05-19 13:29:06 --> Helper loaded: cookie_helper
INFO - 2024-05-19 13:29:06 --> Database Driver Class Initialized
INFO - 2024-05-19 13:29:06 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-19 13:29:06 --> Parser Class Initialized
INFO - 2024-05-19 13:29:06 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-05-19 13:29:06 --> Pagination Class Initialized
INFO - 2024-05-19 13:29:06 --> Form Validation Class Initialized
INFO - 2024-05-19 13:29:06 --> Controller Class Initialized
DEBUG - 2024-05-19 13:29:06 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-05-19 13:29:06 --> Session class already loaded. Second attempt ignored.
INFO - 2024-05-19 13:29:06 --> Model Class Initialized
INFO - 2024-05-19 13:29:06 --> Final output sent to browser
DEBUG - 2024-05-19 13:29:06 --> Total execution time: 0.2400
ERROR - 2024-05-19 13:30:02 --> $config['composer_autoload'] is set to TRUE but E:\xampp\htdocs\maurnaturo\application\vendor/autoload.php was not found.
INFO - 2024-05-19 13:30:02 --> Config Class Initialized
INFO - 2024-05-19 13:30:02 --> Hooks Class Initialized
DEBUG - 2024-05-19 13:30:02 --> UTF-8 Support Enabled
INFO - 2024-05-19 13:30:02 --> Utf8 Class Initialized
INFO - 2024-05-19 13:30:02 --> URI Class Initialized
INFO - 2024-05-19 13:30:02 --> Router Class Initialized
INFO - 2024-05-19 13:30:02 --> Output Class Initialized
INFO - 2024-05-19 13:30:02 --> Security Class Initialized
DEBUG - 2024-05-19 13:30:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-19 13:30:02 --> Input Class Initialized
INFO - 2024-05-19 13:30:02 --> Language Class Initialized
INFO - 2024-05-19 13:30:02 --> Loader Class Initialized
INFO - 2024-05-19 13:30:02 --> Helper loaded: url_helper
INFO - 2024-05-19 13:30:02 --> Helper loaded: file_helper
INFO - 2024-05-19 13:30:02 --> Helper loaded: html_helper
INFO - 2024-05-19 13:30:02 --> Helper loaded: text_helper
INFO - 2024-05-19 13:30:02 --> Helper loaded: form_helper
INFO - 2024-05-19 13:30:02 --> Helper loaded: lang_helper
INFO - 2024-05-19 13:30:02 --> Helper loaded: security_helper
INFO - 2024-05-19 13:30:02 --> Helper loaded: cookie_helper
INFO - 2024-05-19 13:30:02 --> Database Driver Class Initialized
INFO - 2024-05-19 13:30:02 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-19 13:30:02 --> Parser Class Initialized
INFO - 2024-05-19 13:30:02 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-05-19 13:30:02 --> Pagination Class Initialized
INFO - 2024-05-19 13:30:02 --> Form Validation Class Initialized
INFO - 2024-05-19 13:30:02 --> Controller Class Initialized
DEBUG - 2024-05-19 13:30:02 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-05-19 13:30:02 --> Session class already loaded. Second attempt ignored.
INFO - 2024-05-19 13:30:02 --> Model Class Initialized
INFO - 2024-05-19 13:30:02 --> Final output sent to browser
DEBUG - 2024-05-19 13:30:02 --> Total execution time: 0.1015
ERROR - 2024-05-19 13:30:09 --> $config['composer_autoload'] is set to TRUE but E:\xampp\htdocs\maurnaturo\application\vendor/autoload.php was not found.
INFO - 2024-05-19 13:30:09 --> Config Class Initialized
INFO - 2024-05-19 13:30:09 --> Hooks Class Initialized
DEBUG - 2024-05-19 13:30:09 --> UTF-8 Support Enabled
INFO - 2024-05-19 13:30:09 --> Utf8 Class Initialized
INFO - 2024-05-19 13:30:09 --> URI Class Initialized
DEBUG - 2024-05-19 13:30:09 --> No URI present. Default controller set.
INFO - 2024-05-19 13:30:09 --> Router Class Initialized
INFO - 2024-05-19 13:30:09 --> Output Class Initialized
INFO - 2024-05-19 13:30:09 --> Security Class Initialized
DEBUG - 2024-05-19 13:30:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-19 13:30:09 --> Input Class Initialized
INFO - 2024-05-19 13:30:09 --> Language Class Initialized
INFO - 2024-05-19 13:30:09 --> Loader Class Initialized
INFO - 2024-05-19 13:30:09 --> Helper loaded: url_helper
INFO - 2024-05-19 13:30:09 --> Helper loaded: file_helper
INFO - 2024-05-19 13:30:09 --> Helper loaded: html_helper
INFO - 2024-05-19 13:30:09 --> Helper loaded: text_helper
INFO - 2024-05-19 13:30:09 --> Helper loaded: form_helper
INFO - 2024-05-19 13:30:09 --> Helper loaded: lang_helper
INFO - 2024-05-19 13:30:09 --> Helper loaded: security_helper
INFO - 2024-05-19 13:30:09 --> Helper loaded: cookie_helper
INFO - 2024-05-19 13:30:09 --> Database Driver Class Initialized
INFO - 2024-05-19 13:30:09 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-19 13:30:09 --> Parser Class Initialized
INFO - 2024-05-19 13:30:09 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-05-19 13:30:09 --> Pagination Class Initialized
INFO - 2024-05-19 13:30:09 --> Form Validation Class Initialized
INFO - 2024-05-19 13:30:09 --> Controller Class Initialized
INFO - 2024-05-19 13:30:09 --> Model Class Initialized
DEBUG - 2024-05-19 13:30:09 --> Session class already loaded. Second attempt ignored.
INFO - 2024-05-19 13:30:09 --> Model Class Initialized
DEBUG - 2024-05-19 13:30:09 --> Session class already loaded. Second attempt ignored.
INFO - 2024-05-19 13:30:09 --> Model Class Initialized
INFO - 2024-05-19 13:30:09 --> Model Class Initialized
INFO - 2024-05-19 13:30:09 --> Model Class Initialized
INFO - 2024-05-19 13:30:09 --> Model Class Initialized
DEBUG - 2024-05-19 13:30:09 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-05-19 13:30:09 --> Session class already loaded. Second attempt ignored.
INFO - 2024-05-19 13:30:09 --> Model Class Initialized
INFO - 2024-05-19 13:30:09 --> Model Class Initialized
INFO - 2024-05-19 13:30:10 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\include/admin_home.php
DEBUG - 2024-05-19 13:30:10 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-05-19 13:30:10 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\include/top_menu.php
INFO - 2024-05-19 13:30:10 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\include/admin_loggedin_info.php
INFO - 2024-05-19 13:30:10 --> Model Class Initialized
INFO - 2024-05-19 13:30:11 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\include/admin_header.php
INFO - 2024-05-19 13:30:11 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\include/admin_footer.php
INFO - 2024-05-19 13:30:11 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\admin_html_template.php
INFO - 2024-05-19 13:30:11 --> Final output sent to browser
DEBUG - 2024-05-19 13:30:11 --> Total execution time: 2.3102
ERROR - 2024-05-19 13:30:17 --> $config['composer_autoload'] is set to TRUE but E:\xampp\htdocs\maurnaturo\application\vendor/autoload.php was not found.
INFO - 2024-05-19 13:30:17 --> Config Class Initialized
INFO - 2024-05-19 13:30:17 --> Hooks Class Initialized
DEBUG - 2024-05-19 13:30:17 --> UTF-8 Support Enabled
INFO - 2024-05-19 13:30:17 --> Utf8 Class Initialized
INFO - 2024-05-19 13:30:17 --> URI Class Initialized
INFO - 2024-05-19 13:30:17 --> Router Class Initialized
INFO - 2024-05-19 13:30:17 --> Output Class Initialized
INFO - 2024-05-19 13:30:17 --> Security Class Initialized
DEBUG - 2024-05-19 13:30:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-19 13:30:17 --> Input Class Initialized
INFO - 2024-05-19 13:30:17 --> Language Class Initialized
INFO - 2024-05-19 13:30:17 --> Loader Class Initialized
INFO - 2024-05-19 13:30:17 --> Helper loaded: url_helper
INFO - 2024-05-19 13:30:17 --> Helper loaded: file_helper
INFO - 2024-05-19 13:30:17 --> Helper loaded: html_helper
INFO - 2024-05-19 13:30:17 --> Helper loaded: text_helper
INFO - 2024-05-19 13:30:17 --> Helper loaded: form_helper
INFO - 2024-05-19 13:30:17 --> Helper loaded: lang_helper
INFO - 2024-05-19 13:30:17 --> Helper loaded: security_helper
INFO - 2024-05-19 13:30:17 --> Helper loaded: cookie_helper
INFO - 2024-05-19 13:30:17 --> Database Driver Class Initialized
INFO - 2024-05-19 13:30:17 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-19 13:30:17 --> Parser Class Initialized
INFO - 2024-05-19 13:30:17 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-05-19 13:30:17 --> Pagination Class Initialized
INFO - 2024-05-19 13:30:17 --> Form Validation Class Initialized
INFO - 2024-05-19 13:30:17 --> Controller Class Initialized
DEBUG - 2024-05-19 13:30:17 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-05-19 13:30:17 --> Session class already loaded. Second attempt ignored.
INFO - 2024-05-19 13:30:17 --> Model Class Initialized
INFO - 2024-05-19 13:30:17 --> Model Class Initialized
DEBUG - 2024-05-19 13:30:17 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-05-19 13:30:17 --> Session class already loaded. Second attempt ignored.
INFO - 2024-05-19 13:30:17 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\mr_payments/add_payment_form.php
DEBUG - 2024-05-19 13:30:17 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-05-19 13:30:17 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\include/top_menu.php
INFO - 2024-05-19 13:30:17 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\include/admin_loggedin_info.php
INFO - 2024-05-19 13:30:17 --> Model Class Initialized
INFO - 2024-05-19 13:30:17 --> Model Class Initialized
INFO - 2024-05-19 13:30:17 --> Model Class Initialized
INFO - 2024-05-19 13:30:17 --> Model Class Initialized
INFO - 2024-05-19 13:30:19 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\include/admin_header.php
INFO - 2024-05-19 13:30:19 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\include/admin_footer.php
INFO - 2024-05-19 13:30:19 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\admin_html_template.php
INFO - 2024-05-19 13:30:19 --> Final output sent to browser
DEBUG - 2024-05-19 13:30:19 --> Total execution time: 1.6767
ERROR - 2024-05-19 13:30:29 --> $config['composer_autoload'] is set to TRUE but E:\xampp\htdocs\maurnaturo\application\vendor/autoload.php was not found.
INFO - 2024-05-19 13:30:29 --> Config Class Initialized
INFO - 2024-05-19 13:30:29 --> Hooks Class Initialized
DEBUG - 2024-05-19 13:30:29 --> UTF-8 Support Enabled
INFO - 2024-05-19 13:30:29 --> Utf8 Class Initialized
INFO - 2024-05-19 13:30:29 --> URI Class Initialized
INFO - 2024-05-19 13:30:29 --> Router Class Initialized
INFO - 2024-05-19 13:30:29 --> Output Class Initialized
INFO - 2024-05-19 13:30:29 --> Security Class Initialized
DEBUG - 2024-05-19 13:30:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-19 13:30:29 --> Input Class Initialized
INFO - 2024-05-19 13:30:29 --> Language Class Initialized
ERROR - 2024-05-19 13:30:29 --> 404 Page Not Found: Cmr_payments/manage_mr_payment
ERROR - 2024-05-19 13:30:31 --> $config['composer_autoload'] is set to TRUE but E:\xampp\htdocs\maurnaturo\application\vendor/autoload.php was not found.
INFO - 2024-05-19 13:30:31 --> Config Class Initialized
INFO - 2024-05-19 13:30:31 --> Hooks Class Initialized
DEBUG - 2024-05-19 13:30:31 --> UTF-8 Support Enabled
INFO - 2024-05-19 13:30:31 --> Utf8 Class Initialized
INFO - 2024-05-19 13:30:31 --> URI Class Initialized
INFO - 2024-05-19 13:30:31 --> Router Class Initialized
INFO - 2024-05-19 13:30:31 --> Output Class Initialized
INFO - 2024-05-19 13:30:31 --> Security Class Initialized
DEBUG - 2024-05-19 13:30:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-19 13:30:31 --> Input Class Initialized
INFO - 2024-05-19 13:30:31 --> Language Class Initialized
ERROR - 2024-05-19 13:30:31 --> 404 Page Not Found: Cmr_payments/manage_mr_payment
ERROR - 2024-05-19 13:30:33 --> $config['composer_autoload'] is set to TRUE but E:\xampp\htdocs\maurnaturo\application\vendor/autoload.php was not found.
INFO - 2024-05-19 13:30:33 --> Config Class Initialized
INFO - 2024-05-19 13:30:33 --> Hooks Class Initialized
DEBUG - 2024-05-19 13:30:33 --> UTF-8 Support Enabled
INFO - 2024-05-19 13:30:33 --> Utf8 Class Initialized
INFO - 2024-05-19 13:30:33 --> URI Class Initialized
INFO - 2024-05-19 13:30:33 --> Router Class Initialized
INFO - 2024-05-19 13:30:33 --> Output Class Initialized
INFO - 2024-05-19 13:30:33 --> Security Class Initialized
DEBUG - 2024-05-19 13:30:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-19 13:30:33 --> Input Class Initialized
INFO - 2024-05-19 13:30:33 --> Language Class Initialized
ERROR - 2024-05-19 13:30:33 --> 404 Page Not Found: Cmr_payments/manage_mr_payment
ERROR - 2024-05-19 13:30:33 --> $config['composer_autoload'] is set to TRUE but E:\xampp\htdocs\maurnaturo\application\vendor/autoload.php was not found.
INFO - 2024-05-19 13:30:33 --> Config Class Initialized
INFO - 2024-05-19 13:30:33 --> Hooks Class Initialized
DEBUG - 2024-05-19 13:30:33 --> UTF-8 Support Enabled
INFO - 2024-05-19 13:30:33 --> Utf8 Class Initialized
INFO - 2024-05-19 13:30:33 --> URI Class Initialized
INFO - 2024-05-19 13:30:33 --> Router Class Initialized
INFO - 2024-05-19 13:30:33 --> Output Class Initialized
INFO - 2024-05-19 13:30:33 --> Security Class Initialized
DEBUG - 2024-05-19 13:30:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-19 13:30:33 --> Input Class Initialized
INFO - 2024-05-19 13:30:34 --> Language Class Initialized
ERROR - 2024-05-19 13:30:34 --> 404 Page Not Found: Cmr_payments/manage_mr_payment
ERROR - 2024-05-19 13:30:47 --> $config['composer_autoload'] is set to TRUE but E:\xampp\htdocs\maurnaturo\application\vendor/autoload.php was not found.
INFO - 2024-05-19 13:30:47 --> Config Class Initialized
INFO - 2024-05-19 13:30:47 --> Hooks Class Initialized
DEBUG - 2024-05-19 13:30:47 --> UTF-8 Support Enabled
INFO - 2024-05-19 13:30:47 --> Utf8 Class Initialized
INFO - 2024-05-19 13:30:47 --> URI Class Initialized
INFO - 2024-05-19 13:30:47 --> Router Class Initialized
INFO - 2024-05-19 13:30:47 --> Output Class Initialized
INFO - 2024-05-19 13:30:47 --> Security Class Initialized
DEBUG - 2024-05-19 13:30:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-19 13:30:47 --> Input Class Initialized
INFO - 2024-05-19 13:30:47 --> Language Class Initialized
INFO - 2024-05-19 13:30:47 --> Loader Class Initialized
INFO - 2024-05-19 13:30:47 --> Helper loaded: url_helper
INFO - 2024-05-19 13:30:47 --> Helper loaded: file_helper
INFO - 2024-05-19 13:30:47 --> Helper loaded: html_helper
INFO - 2024-05-19 13:30:47 --> Helper loaded: text_helper
INFO - 2024-05-19 13:30:47 --> Helper loaded: form_helper
INFO - 2024-05-19 13:30:47 --> Helper loaded: lang_helper
INFO - 2024-05-19 13:30:47 --> Helper loaded: security_helper
INFO - 2024-05-19 13:30:47 --> Helper loaded: cookie_helper
INFO - 2024-05-19 13:30:47 --> Database Driver Class Initialized
INFO - 2024-05-19 13:30:47 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-19 13:30:47 --> Parser Class Initialized
INFO - 2024-05-19 13:30:47 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-05-19 13:30:47 --> Pagination Class Initialized
INFO - 2024-05-19 13:30:47 --> Form Validation Class Initialized
INFO - 2024-05-19 13:30:47 --> Controller Class Initialized
DEBUG - 2024-05-19 13:30:47 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-05-19 13:30:47 --> Session class already loaded. Second attempt ignored.
INFO - 2024-05-19 13:30:47 --> Model Class Initialized
DEBUG - 2024-05-19 13:30:47 --> Lmrpayments class already loaded. Second attempt ignored.
INFO - 2024-05-19 13:30:47 --> Model Class Initialized
INFO - 2024-05-19 13:30:47 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\mr_payments/payment.php
DEBUG - 2024-05-19 13:30:47 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-05-19 13:30:47 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\include/top_menu.php
INFO - 2024-05-19 13:30:47 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\include/admin_loggedin_info.php
INFO - 2024-05-19 13:30:47 --> Model Class Initialized
INFO - 2024-05-19 13:30:47 --> Model Class Initialized
INFO - 2024-05-19 13:30:47 --> Model Class Initialized
INFO - 2024-05-19 13:30:48 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\include/admin_header.php
INFO - 2024-05-19 13:30:48 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\include/admin_footer.php
INFO - 2024-05-19 13:30:48 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\admin_html_template.php
INFO - 2024-05-19 13:30:48 --> Final output sent to browser
DEBUG - 2024-05-19 13:30:48 --> Total execution time: 1.2311
ERROR - 2024-05-19 13:30:49 --> $config['composer_autoload'] is set to TRUE but E:\xampp\htdocs\maurnaturo\application\vendor/autoload.php was not found.
INFO - 2024-05-19 13:30:49 --> Config Class Initialized
INFO - 2024-05-19 13:30:49 --> Hooks Class Initialized
DEBUG - 2024-05-19 13:30:49 --> UTF-8 Support Enabled
INFO - 2024-05-19 13:30:49 --> Utf8 Class Initialized
INFO - 2024-05-19 13:30:49 --> URI Class Initialized
INFO - 2024-05-19 13:30:49 --> Router Class Initialized
INFO - 2024-05-19 13:30:49 --> Output Class Initialized
INFO - 2024-05-19 13:30:49 --> Security Class Initialized
DEBUG - 2024-05-19 13:30:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-19 13:30:49 --> Input Class Initialized
INFO - 2024-05-19 13:30:49 --> Language Class Initialized
INFO - 2024-05-19 13:30:49 --> Loader Class Initialized
INFO - 2024-05-19 13:30:49 --> Helper loaded: url_helper
INFO - 2024-05-19 13:30:49 --> Helper loaded: file_helper
INFO - 2024-05-19 13:30:49 --> Helper loaded: html_helper
INFO - 2024-05-19 13:30:49 --> Helper loaded: text_helper
INFO - 2024-05-19 13:30:49 --> Helper loaded: form_helper
INFO - 2024-05-19 13:30:49 --> Helper loaded: lang_helper
INFO - 2024-05-19 13:30:49 --> Helper loaded: security_helper
INFO - 2024-05-19 13:30:49 --> Helper loaded: cookie_helper
INFO - 2024-05-19 13:30:49 --> Database Driver Class Initialized
INFO - 2024-05-19 13:30:49 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-19 13:30:49 --> Parser Class Initialized
INFO - 2024-05-19 13:30:49 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-05-19 13:30:49 --> Pagination Class Initialized
INFO - 2024-05-19 13:30:49 --> Form Validation Class Initialized
INFO - 2024-05-19 13:30:49 --> Controller Class Initialized
DEBUG - 2024-05-19 13:30:49 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-05-19 13:30:49 --> Session class already loaded. Second attempt ignored.
INFO - 2024-05-19 13:30:49 --> Model Class Initialized
INFO - 2024-05-19 13:30:49 --> Final output sent to browser
DEBUG - 2024-05-19 13:30:49 --> Total execution time: 0.1813
ERROR - 2024-05-19 13:31:06 --> $config['composer_autoload'] is set to TRUE but E:\xampp\htdocs\maurnaturo\application\vendor/autoload.php was not found.
INFO - 2024-05-19 13:31:06 --> Config Class Initialized
INFO - 2024-05-19 13:31:06 --> Hooks Class Initialized
DEBUG - 2024-05-19 13:31:06 --> UTF-8 Support Enabled
INFO - 2024-05-19 13:31:06 --> Utf8 Class Initialized
INFO - 2024-05-19 13:31:06 --> URI Class Initialized
INFO - 2024-05-19 13:31:06 --> Router Class Initialized
INFO - 2024-05-19 13:31:06 --> Output Class Initialized
INFO - 2024-05-19 13:31:06 --> Security Class Initialized
DEBUG - 2024-05-19 13:31:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-19 13:31:06 --> Input Class Initialized
INFO - 2024-05-19 13:31:06 --> Language Class Initialized
INFO - 2024-05-19 13:31:06 --> Loader Class Initialized
INFO - 2024-05-19 13:31:06 --> Helper loaded: url_helper
INFO - 2024-05-19 13:31:06 --> Helper loaded: file_helper
INFO - 2024-05-19 13:31:06 --> Helper loaded: html_helper
INFO - 2024-05-19 13:31:06 --> Helper loaded: text_helper
INFO - 2024-05-19 13:31:06 --> Helper loaded: form_helper
INFO - 2024-05-19 13:31:06 --> Helper loaded: lang_helper
INFO - 2024-05-19 13:31:06 --> Helper loaded: security_helper
INFO - 2024-05-19 13:31:06 --> Helper loaded: cookie_helper
INFO - 2024-05-19 13:31:06 --> Database Driver Class Initialized
INFO - 2024-05-19 13:31:06 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-19 13:31:06 --> Parser Class Initialized
INFO - 2024-05-19 13:31:06 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-05-19 13:31:06 --> Pagination Class Initialized
INFO - 2024-05-19 13:31:06 --> Form Validation Class Initialized
INFO - 2024-05-19 13:31:06 --> Controller Class Initialized
DEBUG - 2024-05-19 13:31:06 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-05-19 13:31:06 --> Session class already loaded. Second attempt ignored.
INFO - 2024-05-19 13:31:06 --> Model Class Initialized
DEBUG - 2024-05-19 13:31:06 --> Lpayments class already loaded. Second attempt ignored.
INFO - 2024-05-19 13:31:06 --> Model Class Initialized
INFO - 2024-05-19 13:31:06 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\payments/payment.php
DEBUG - 2024-05-19 13:31:06 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-05-19 13:31:06 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\include/top_menu.php
INFO - 2024-05-19 13:31:06 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\include/admin_loggedin_info.php
INFO - 2024-05-19 13:31:06 --> Model Class Initialized
INFO - 2024-05-19 13:31:06 --> Model Class Initialized
INFO - 2024-05-19 13:31:06 --> Model Class Initialized
INFO - 2024-05-19 13:31:07 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\include/admin_header.php
INFO - 2024-05-19 13:31:07 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\include/admin_footer.php
INFO - 2024-05-19 13:31:07 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\admin_html_template.php
INFO - 2024-05-19 13:31:07 --> Final output sent to browser
DEBUG - 2024-05-19 13:31:07 --> Total execution time: 1.5308
ERROR - 2024-05-19 13:31:08 --> $config['composer_autoload'] is set to TRUE but E:\xampp\htdocs\maurnaturo\application\vendor/autoload.php was not found.
INFO - 2024-05-19 13:31:08 --> Config Class Initialized
INFO - 2024-05-19 13:31:08 --> Hooks Class Initialized
DEBUG - 2024-05-19 13:31:08 --> UTF-8 Support Enabled
INFO - 2024-05-19 13:31:08 --> Utf8 Class Initialized
INFO - 2024-05-19 13:31:08 --> URI Class Initialized
INFO - 2024-05-19 13:31:08 --> Router Class Initialized
INFO - 2024-05-19 13:31:08 --> Output Class Initialized
INFO - 2024-05-19 13:31:08 --> Security Class Initialized
DEBUG - 2024-05-19 13:31:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-19 13:31:08 --> Input Class Initialized
INFO - 2024-05-19 13:31:08 --> Language Class Initialized
INFO - 2024-05-19 13:31:08 --> Loader Class Initialized
INFO - 2024-05-19 13:31:08 --> Helper loaded: url_helper
INFO - 2024-05-19 13:31:08 --> Helper loaded: file_helper
INFO - 2024-05-19 13:31:08 --> Helper loaded: html_helper
INFO - 2024-05-19 13:31:08 --> Helper loaded: text_helper
INFO - 2024-05-19 13:31:08 --> Helper loaded: form_helper
INFO - 2024-05-19 13:31:08 --> Helper loaded: lang_helper
INFO - 2024-05-19 13:31:08 --> Helper loaded: security_helper
INFO - 2024-05-19 13:31:08 --> Helper loaded: cookie_helper
INFO - 2024-05-19 13:31:08 --> Database Driver Class Initialized
INFO - 2024-05-19 13:31:08 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-19 13:31:08 --> Parser Class Initialized
INFO - 2024-05-19 13:31:08 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-05-19 13:31:08 --> Pagination Class Initialized
INFO - 2024-05-19 13:31:08 --> Form Validation Class Initialized
INFO - 2024-05-19 13:31:08 --> Controller Class Initialized
DEBUG - 2024-05-19 13:31:08 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-05-19 13:31:08 --> Session class already loaded. Second attempt ignored.
INFO - 2024-05-19 13:31:08 --> Model Class Initialized
INFO - 2024-05-19 13:31:08 --> Final output sent to browser
DEBUG - 2024-05-19 13:31:08 --> Total execution time: 0.1791
ERROR - 2024-05-19 13:35:51 --> $config['composer_autoload'] is set to TRUE but E:\xampp\htdocs\maurnaturo\application\vendor/autoload.php was not found.
INFO - 2024-05-19 13:35:51 --> Config Class Initialized
INFO - 2024-05-19 13:35:51 --> Hooks Class Initialized
DEBUG - 2024-05-19 13:35:51 --> UTF-8 Support Enabled
INFO - 2024-05-19 13:35:51 --> Utf8 Class Initialized
INFO - 2024-05-19 13:35:51 --> URI Class Initialized
INFO - 2024-05-19 13:35:51 --> Router Class Initialized
INFO - 2024-05-19 13:35:51 --> Output Class Initialized
INFO - 2024-05-19 13:35:51 --> Security Class Initialized
DEBUG - 2024-05-19 13:35:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-19 13:35:51 --> Input Class Initialized
INFO - 2024-05-19 13:35:51 --> Language Class Initialized
INFO - 2024-05-19 13:35:51 --> Loader Class Initialized
INFO - 2024-05-19 13:35:51 --> Helper loaded: url_helper
INFO - 2024-05-19 13:35:51 --> Helper loaded: file_helper
INFO - 2024-05-19 13:35:51 --> Helper loaded: html_helper
INFO - 2024-05-19 13:35:51 --> Helper loaded: text_helper
INFO - 2024-05-19 13:35:51 --> Helper loaded: form_helper
INFO - 2024-05-19 13:35:51 --> Helper loaded: lang_helper
INFO - 2024-05-19 13:35:51 --> Helper loaded: security_helper
INFO - 2024-05-19 13:35:51 --> Helper loaded: cookie_helper
INFO - 2024-05-19 13:35:51 --> Database Driver Class Initialized
INFO - 2024-05-19 13:35:51 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-19 13:35:51 --> Parser Class Initialized
INFO - 2024-05-19 13:35:51 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-05-19 13:35:51 --> Pagination Class Initialized
INFO - 2024-05-19 13:35:51 --> Form Validation Class Initialized
INFO - 2024-05-19 13:35:51 --> Controller Class Initialized
DEBUG - 2024-05-19 13:35:51 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-05-19 13:35:51 --> Session class already loaded. Second attempt ignored.
INFO - 2024-05-19 13:35:51 --> Model Class Initialized
DEBUG - 2024-05-19 13:35:51 --> Lpayments class already loaded. Second attempt ignored.
INFO - 2024-05-19 13:35:51 --> Model Class Initialized
INFO - 2024-05-19 13:35:52 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\payments/payment.php
DEBUG - 2024-05-19 13:35:52 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-05-19 13:35:52 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\include/top_menu.php
INFO - 2024-05-19 13:35:52 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\include/admin_loggedin_info.php
INFO - 2024-05-19 13:35:52 --> Model Class Initialized
INFO - 2024-05-19 13:35:52 --> Model Class Initialized
INFO - 2024-05-19 13:35:52 --> Model Class Initialized
INFO - 2024-05-19 13:35:53 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\include/admin_header.php
INFO - 2024-05-19 13:35:53 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\include/admin_footer.php
INFO - 2024-05-19 13:35:53 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\admin_html_template.php
INFO - 2024-05-19 13:35:53 --> Final output sent to browser
DEBUG - 2024-05-19 13:35:53 --> Total execution time: 1.7332
ERROR - 2024-05-19 13:35:54 --> $config['composer_autoload'] is set to TRUE but E:\xampp\htdocs\maurnaturo\application\vendor/autoload.php was not found.
INFO - 2024-05-19 13:35:54 --> Config Class Initialized
INFO - 2024-05-19 13:35:54 --> Hooks Class Initialized
DEBUG - 2024-05-19 13:35:54 --> UTF-8 Support Enabled
INFO - 2024-05-19 13:35:54 --> Utf8 Class Initialized
INFO - 2024-05-19 13:35:54 --> URI Class Initialized
INFO - 2024-05-19 13:35:54 --> Router Class Initialized
INFO - 2024-05-19 13:35:54 --> Output Class Initialized
INFO - 2024-05-19 13:35:54 --> Security Class Initialized
DEBUG - 2024-05-19 13:35:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-19 13:35:54 --> Input Class Initialized
INFO - 2024-05-19 13:35:54 --> Language Class Initialized
INFO - 2024-05-19 13:35:54 --> Loader Class Initialized
INFO - 2024-05-19 13:35:54 --> Helper loaded: url_helper
INFO - 2024-05-19 13:35:54 --> Helper loaded: file_helper
INFO - 2024-05-19 13:35:54 --> Helper loaded: html_helper
INFO - 2024-05-19 13:35:54 --> Helper loaded: text_helper
INFO - 2024-05-19 13:35:54 --> Helper loaded: form_helper
INFO - 2024-05-19 13:35:54 --> Helper loaded: lang_helper
INFO - 2024-05-19 13:35:54 --> Helper loaded: security_helper
INFO - 2024-05-19 13:35:54 --> Helper loaded: cookie_helper
INFO - 2024-05-19 13:35:54 --> Database Driver Class Initialized
INFO - 2024-05-19 13:35:54 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-19 13:35:54 --> Parser Class Initialized
INFO - 2024-05-19 13:35:54 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-05-19 13:35:54 --> Pagination Class Initialized
INFO - 2024-05-19 13:35:54 --> Form Validation Class Initialized
INFO - 2024-05-19 13:35:54 --> Controller Class Initialized
DEBUG - 2024-05-19 13:35:54 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-05-19 13:35:54 --> Session class already loaded. Second attempt ignored.
INFO - 2024-05-19 13:35:54 --> Model Class Initialized
INFO - 2024-05-19 13:35:54 --> Final output sent to browser
DEBUG - 2024-05-19 13:35:54 --> Total execution time: 0.1796
ERROR - 2024-05-19 13:36:08 --> $config['composer_autoload'] is set to TRUE but E:\xampp\htdocs\maurnaturo\application\vendor/autoload.php was not found.
INFO - 2024-05-19 13:36:08 --> Config Class Initialized
INFO - 2024-05-19 13:36:08 --> Hooks Class Initialized
DEBUG - 2024-05-19 13:36:08 --> UTF-8 Support Enabled
INFO - 2024-05-19 13:36:08 --> Utf8 Class Initialized
INFO - 2024-05-19 13:36:08 --> URI Class Initialized
INFO - 2024-05-19 13:36:08 --> Router Class Initialized
INFO - 2024-05-19 13:36:08 --> Output Class Initialized
INFO - 2024-05-19 13:36:08 --> Security Class Initialized
DEBUG - 2024-05-19 13:36:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-19 13:36:08 --> Input Class Initialized
INFO - 2024-05-19 13:36:08 --> Language Class Initialized
ERROR - 2024-05-19 13:36:08 --> 404 Page Not Found: Cmr_payments/manage_mr_payment
ERROR - 2024-05-19 13:38:00 --> $config['composer_autoload'] is set to TRUE but E:\xampp\htdocs\maurnaturo\application\vendor/autoload.php was not found.
INFO - 2024-05-19 13:38:00 --> Config Class Initialized
INFO - 2024-05-19 13:38:00 --> Hooks Class Initialized
DEBUG - 2024-05-19 13:38:00 --> UTF-8 Support Enabled
INFO - 2024-05-19 13:38:00 --> Utf8 Class Initialized
INFO - 2024-05-19 13:38:00 --> URI Class Initialized
INFO - 2024-05-19 13:38:00 --> Router Class Initialized
INFO - 2024-05-19 13:38:00 --> Output Class Initialized
INFO - 2024-05-19 13:38:00 --> Security Class Initialized
DEBUG - 2024-05-19 13:38:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-19 13:38:00 --> Input Class Initialized
INFO - 2024-05-19 13:38:00 --> Language Class Initialized
ERROR - 2024-05-19 13:38:00 --> 404 Page Not Found: Cmr_payments/manage_mr_payment
ERROR - 2024-05-19 13:38:02 --> $config['composer_autoload'] is set to TRUE but E:\xampp\htdocs\maurnaturo\application\vendor/autoload.php was not found.
INFO - 2024-05-19 13:38:02 --> Config Class Initialized
INFO - 2024-05-19 13:38:02 --> Hooks Class Initialized
DEBUG - 2024-05-19 13:38:02 --> UTF-8 Support Enabled
INFO - 2024-05-19 13:38:02 --> Utf8 Class Initialized
INFO - 2024-05-19 13:38:02 --> URI Class Initialized
INFO - 2024-05-19 13:38:02 --> Router Class Initialized
INFO - 2024-05-19 13:38:02 --> Output Class Initialized
INFO - 2024-05-19 13:38:02 --> Security Class Initialized
DEBUG - 2024-05-19 13:38:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-19 13:38:02 --> Input Class Initialized
INFO - 2024-05-19 13:38:02 --> Language Class Initialized
INFO - 2024-05-19 13:38:02 --> Loader Class Initialized
INFO - 2024-05-19 13:38:02 --> Helper loaded: url_helper
INFO - 2024-05-19 13:38:02 --> Helper loaded: file_helper
INFO - 2024-05-19 13:38:02 --> Helper loaded: html_helper
INFO - 2024-05-19 13:38:02 --> Helper loaded: text_helper
INFO - 2024-05-19 13:38:02 --> Helper loaded: form_helper
INFO - 2024-05-19 13:38:02 --> Helper loaded: lang_helper
INFO - 2024-05-19 13:38:02 --> Helper loaded: security_helper
INFO - 2024-05-19 13:38:02 --> Helper loaded: cookie_helper
INFO - 2024-05-19 13:38:02 --> Database Driver Class Initialized
INFO - 2024-05-19 13:38:02 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-19 13:38:02 --> Parser Class Initialized
INFO - 2024-05-19 13:38:02 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-05-19 13:38:02 --> Pagination Class Initialized
INFO - 2024-05-19 13:38:02 --> Form Validation Class Initialized
INFO - 2024-05-19 13:38:02 --> Controller Class Initialized
DEBUG - 2024-05-19 13:38:02 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-05-19 13:38:02 --> Session class already loaded. Second attempt ignored.
INFO - 2024-05-19 13:38:02 --> Model Class Initialized
DEBUG - 2024-05-19 13:38:02 --> Lpayments class already loaded. Second attempt ignored.
INFO - 2024-05-19 13:38:02 --> Model Class Initialized
INFO - 2024-05-19 13:38:02 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\payments/payment.php
DEBUG - 2024-05-19 13:38:02 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-05-19 13:38:02 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\include/top_menu.php
INFO - 2024-05-19 13:38:02 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\include/admin_loggedin_info.php
INFO - 2024-05-19 13:38:02 --> Model Class Initialized
INFO - 2024-05-19 13:38:02 --> Model Class Initialized
INFO - 2024-05-19 13:38:02 --> Model Class Initialized
ERROR - 2024-05-19 13:38:02 --> $config['composer_autoload'] is set to TRUE but E:\xampp\htdocs\maurnaturo\application\vendor/autoload.php was not found.
INFO - 2024-05-19 13:38:02 --> Config Class Initialized
INFO - 2024-05-19 13:38:02 --> Hooks Class Initialized
DEBUG - 2024-05-19 13:38:03 --> UTF-8 Support Enabled
INFO - 2024-05-19 13:38:03 --> Utf8 Class Initialized
INFO - 2024-05-19 13:38:03 --> URI Class Initialized
INFO - 2024-05-19 13:38:03 --> Router Class Initialized
INFO - 2024-05-19 13:38:03 --> Output Class Initialized
INFO - 2024-05-19 13:38:03 --> Security Class Initialized
DEBUG - 2024-05-19 13:38:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-19 13:38:03 --> Input Class Initialized
INFO - 2024-05-19 13:38:03 --> Language Class Initialized
ERROR - 2024-05-19 13:38:03 --> 404 Page Not Found: Cmr_payments/manage_mr_payment
INFO - 2024-05-19 13:38:03 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\include/admin_header.php
INFO - 2024-05-19 13:38:03 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\include/admin_footer.php
INFO - 2024-05-19 13:38:03 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\admin_html_template.php
INFO - 2024-05-19 13:38:03 --> Final output sent to browser
DEBUG - 2024-05-19 13:38:03 --> Total execution time: 1.5494
ERROR - 2024-05-19 13:38:04 --> $config['composer_autoload'] is set to TRUE but E:\xampp\htdocs\maurnaturo\application\vendor/autoload.php was not found.
INFO - 2024-05-19 13:38:04 --> Config Class Initialized
INFO - 2024-05-19 13:38:04 --> Hooks Class Initialized
DEBUG - 2024-05-19 13:38:04 --> UTF-8 Support Enabled
INFO - 2024-05-19 13:38:04 --> Utf8 Class Initialized
INFO - 2024-05-19 13:38:04 --> URI Class Initialized
INFO - 2024-05-19 13:38:04 --> Router Class Initialized
INFO - 2024-05-19 13:38:04 --> Output Class Initialized
INFO - 2024-05-19 13:38:04 --> Security Class Initialized
DEBUG - 2024-05-19 13:38:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-19 13:38:04 --> Input Class Initialized
INFO - 2024-05-19 13:38:04 --> Language Class Initialized
INFO - 2024-05-19 13:38:04 --> Loader Class Initialized
INFO - 2024-05-19 13:38:04 --> Helper loaded: url_helper
INFO - 2024-05-19 13:38:04 --> Helper loaded: file_helper
INFO - 2024-05-19 13:38:04 --> Helper loaded: html_helper
INFO - 2024-05-19 13:38:04 --> Helper loaded: text_helper
INFO - 2024-05-19 13:38:04 --> Helper loaded: form_helper
INFO - 2024-05-19 13:38:04 --> Helper loaded: lang_helper
INFO - 2024-05-19 13:38:04 --> Helper loaded: security_helper
INFO - 2024-05-19 13:38:04 --> Helper loaded: cookie_helper
INFO - 2024-05-19 13:38:04 --> Database Driver Class Initialized
INFO - 2024-05-19 13:38:04 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-19 13:38:04 --> Parser Class Initialized
INFO - 2024-05-19 13:38:04 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-05-19 13:38:04 --> Pagination Class Initialized
INFO - 2024-05-19 13:38:04 --> Form Validation Class Initialized
INFO - 2024-05-19 13:38:04 --> Controller Class Initialized
DEBUG - 2024-05-19 13:38:04 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-05-19 13:38:04 --> Session class already loaded. Second attempt ignored.
INFO - 2024-05-19 13:38:04 --> Model Class Initialized
DEBUG - 2024-05-19 13:38:04 --> Lpayments class already loaded. Second attempt ignored.
INFO - 2024-05-19 13:38:04 --> Model Class Initialized
INFO - 2024-05-19 13:38:04 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\payments/payment.php
DEBUG - 2024-05-19 13:38:04 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-05-19 13:38:04 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\include/top_menu.php
INFO - 2024-05-19 13:38:04 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\include/admin_loggedin_info.php
INFO - 2024-05-19 13:38:04 --> Model Class Initialized
INFO - 2024-05-19 13:38:04 --> Model Class Initialized
INFO - 2024-05-19 13:38:04 --> Model Class Initialized
INFO - 2024-05-19 13:38:06 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\include/admin_header.php
INFO - 2024-05-19 13:38:06 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\include/admin_footer.php
INFO - 2024-05-19 13:38:06 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\admin_html_template.php
INFO - 2024-05-19 13:38:06 --> Final output sent to browser
DEBUG - 2024-05-19 13:38:06 --> Total execution time: 1.5052
ERROR - 2024-05-19 13:38:06 --> $config['composer_autoload'] is set to TRUE but E:\xampp\htdocs\maurnaturo\application\vendor/autoload.php was not found.
INFO - 2024-05-19 13:38:06 --> Config Class Initialized
INFO - 2024-05-19 13:38:06 --> Hooks Class Initialized
DEBUG - 2024-05-19 13:38:06 --> UTF-8 Support Enabled
INFO - 2024-05-19 13:38:06 --> Utf8 Class Initialized
INFO - 2024-05-19 13:38:06 --> URI Class Initialized
INFO - 2024-05-19 13:38:06 --> Router Class Initialized
INFO - 2024-05-19 13:38:06 --> Output Class Initialized
INFO - 2024-05-19 13:38:06 --> Security Class Initialized
DEBUG - 2024-05-19 13:38:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-19 13:38:06 --> Input Class Initialized
INFO - 2024-05-19 13:38:06 --> Language Class Initialized
INFO - 2024-05-19 13:38:06 --> Loader Class Initialized
INFO - 2024-05-19 13:38:06 --> Helper loaded: url_helper
INFO - 2024-05-19 13:38:06 --> Helper loaded: file_helper
INFO - 2024-05-19 13:38:06 --> Helper loaded: html_helper
INFO - 2024-05-19 13:38:06 --> Helper loaded: text_helper
INFO - 2024-05-19 13:38:06 --> Helper loaded: form_helper
INFO - 2024-05-19 13:38:06 --> Helper loaded: lang_helper
INFO - 2024-05-19 13:38:06 --> Helper loaded: security_helper
INFO - 2024-05-19 13:38:06 --> Helper loaded: cookie_helper
INFO - 2024-05-19 13:38:06 --> Database Driver Class Initialized
INFO - 2024-05-19 13:38:06 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-19 13:38:06 --> Parser Class Initialized
INFO - 2024-05-19 13:38:06 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-05-19 13:38:06 --> Pagination Class Initialized
INFO - 2024-05-19 13:38:06 --> Form Validation Class Initialized
INFO - 2024-05-19 13:38:06 --> Controller Class Initialized
DEBUG - 2024-05-19 13:38:06 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-05-19 13:38:06 --> Session class already loaded. Second attempt ignored.
INFO - 2024-05-19 13:38:06 --> Model Class Initialized
INFO - 2024-05-19 13:38:06 --> Final output sent to browser
DEBUG - 2024-05-19 13:38:06 --> Total execution time: 0.1922
ERROR - 2024-05-19 13:38:07 --> $config['composer_autoload'] is set to TRUE but E:\xampp\htdocs\maurnaturo\application\vendor/autoload.php was not found.
INFO - 2024-05-19 13:38:07 --> Config Class Initialized
INFO - 2024-05-19 13:38:07 --> Hooks Class Initialized
DEBUG - 2024-05-19 13:38:07 --> UTF-8 Support Enabled
INFO - 2024-05-19 13:38:07 --> Utf8 Class Initialized
INFO - 2024-05-19 13:38:07 --> URI Class Initialized
INFO - 2024-05-19 13:38:07 --> Router Class Initialized
INFO - 2024-05-19 13:38:07 --> Output Class Initialized
INFO - 2024-05-19 13:38:07 --> Security Class Initialized
DEBUG - 2024-05-19 13:38:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-19 13:38:07 --> Input Class Initialized
INFO - 2024-05-19 13:38:07 --> Language Class Initialized
INFO - 2024-05-19 13:38:07 --> Loader Class Initialized
INFO - 2024-05-19 13:38:07 --> Helper loaded: url_helper
INFO - 2024-05-19 13:38:07 --> Helper loaded: file_helper
INFO - 2024-05-19 13:38:07 --> Helper loaded: html_helper
INFO - 2024-05-19 13:38:07 --> Helper loaded: text_helper
INFO - 2024-05-19 13:38:07 --> Helper loaded: form_helper
INFO - 2024-05-19 13:38:07 --> Helper loaded: lang_helper
INFO - 2024-05-19 13:38:07 --> Helper loaded: security_helper
INFO - 2024-05-19 13:38:07 --> Helper loaded: cookie_helper
INFO - 2024-05-19 13:38:07 --> Database Driver Class Initialized
INFO - 2024-05-19 13:38:07 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-19 13:38:07 --> Parser Class Initialized
INFO - 2024-05-19 13:38:07 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-05-19 13:38:07 --> Pagination Class Initialized
INFO - 2024-05-19 13:38:07 --> Form Validation Class Initialized
INFO - 2024-05-19 13:38:07 --> Controller Class Initialized
DEBUG - 2024-05-19 13:38:07 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-05-19 13:38:07 --> Session class already loaded. Second attempt ignored.
INFO - 2024-05-19 13:38:07 --> Model Class Initialized
DEBUG - 2024-05-19 13:38:07 --> Lpayments class already loaded. Second attempt ignored.
INFO - 2024-05-19 13:38:07 --> Model Class Initialized
INFO - 2024-05-19 13:38:07 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\payments/payment.php
DEBUG - 2024-05-19 13:38:07 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-05-19 13:38:07 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\include/top_menu.php
INFO - 2024-05-19 13:38:07 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\include/admin_loggedin_info.php
INFO - 2024-05-19 13:38:07 --> Model Class Initialized
INFO - 2024-05-19 13:38:07 --> Model Class Initialized
INFO - 2024-05-19 13:38:07 --> Model Class Initialized
INFO - 2024-05-19 13:38:09 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\include/admin_header.php
INFO - 2024-05-19 13:38:09 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\include/admin_footer.php
INFO - 2024-05-19 13:38:09 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\admin_html_template.php
INFO - 2024-05-19 13:38:09 --> Final output sent to browser
DEBUG - 2024-05-19 13:38:09 --> Total execution time: 1.2951
ERROR - 2024-05-19 13:38:09 --> $config['composer_autoload'] is set to TRUE but E:\xampp\htdocs\maurnaturo\application\vendor/autoload.php was not found.
INFO - 2024-05-19 13:38:09 --> Config Class Initialized
INFO - 2024-05-19 13:38:09 --> Hooks Class Initialized
DEBUG - 2024-05-19 13:38:09 --> UTF-8 Support Enabled
INFO - 2024-05-19 13:38:09 --> Utf8 Class Initialized
INFO - 2024-05-19 13:38:09 --> URI Class Initialized
INFO - 2024-05-19 13:38:09 --> Router Class Initialized
INFO - 2024-05-19 13:38:09 --> Output Class Initialized
INFO - 2024-05-19 13:38:09 --> Security Class Initialized
DEBUG - 2024-05-19 13:38:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-19 13:38:09 --> Input Class Initialized
INFO - 2024-05-19 13:38:09 --> Language Class Initialized
INFO - 2024-05-19 13:38:09 --> Loader Class Initialized
INFO - 2024-05-19 13:38:09 --> Helper loaded: url_helper
INFO - 2024-05-19 13:38:09 --> Helper loaded: file_helper
INFO - 2024-05-19 13:38:09 --> Helper loaded: html_helper
INFO - 2024-05-19 13:38:09 --> Helper loaded: text_helper
INFO - 2024-05-19 13:38:09 --> Helper loaded: form_helper
INFO - 2024-05-19 13:38:09 --> Helper loaded: lang_helper
INFO - 2024-05-19 13:38:09 --> Helper loaded: security_helper
INFO - 2024-05-19 13:38:09 --> Helper loaded: cookie_helper
INFO - 2024-05-19 13:38:09 --> Database Driver Class Initialized
INFO - 2024-05-19 13:38:09 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-19 13:38:09 --> Parser Class Initialized
INFO - 2024-05-19 13:38:09 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-05-19 13:38:09 --> Pagination Class Initialized
INFO - 2024-05-19 13:38:09 --> Form Validation Class Initialized
INFO - 2024-05-19 13:38:09 --> Controller Class Initialized
DEBUG - 2024-05-19 13:38:09 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-05-19 13:38:09 --> Session class already loaded. Second attempt ignored.
INFO - 2024-05-19 13:38:09 --> Model Class Initialized
INFO - 2024-05-19 13:38:09 --> Final output sent to browser
DEBUG - 2024-05-19 13:38:09 --> Total execution time: 0.1355
ERROR - 2024-05-19 13:38:18 --> $config['composer_autoload'] is set to TRUE but E:\xampp\htdocs\maurnaturo\application\vendor/autoload.php was not found.
INFO - 2024-05-19 13:38:18 --> Config Class Initialized
INFO - 2024-05-19 13:38:18 --> Hooks Class Initialized
DEBUG - 2024-05-19 13:38:18 --> UTF-8 Support Enabled
INFO - 2024-05-19 13:38:18 --> Utf8 Class Initialized
INFO - 2024-05-19 13:38:18 --> URI Class Initialized
INFO - 2024-05-19 13:38:18 --> Router Class Initialized
INFO - 2024-05-19 13:38:18 --> Output Class Initialized
INFO - 2024-05-19 13:38:18 --> Security Class Initialized
DEBUG - 2024-05-19 13:38:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-19 13:38:18 --> Input Class Initialized
INFO - 2024-05-19 13:38:18 --> Language Class Initialized
INFO - 2024-05-19 13:38:18 --> Loader Class Initialized
INFO - 2024-05-19 13:38:18 --> Helper loaded: url_helper
INFO - 2024-05-19 13:38:18 --> Helper loaded: file_helper
INFO - 2024-05-19 13:38:18 --> Helper loaded: html_helper
INFO - 2024-05-19 13:38:18 --> Helper loaded: text_helper
INFO - 2024-05-19 13:38:18 --> Helper loaded: form_helper
INFO - 2024-05-19 13:38:18 --> Helper loaded: lang_helper
INFO - 2024-05-19 13:38:18 --> Helper loaded: security_helper
INFO - 2024-05-19 13:38:18 --> Helper loaded: cookie_helper
INFO - 2024-05-19 13:38:18 --> Database Driver Class Initialized
INFO - 2024-05-19 13:38:18 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-19 13:38:18 --> Parser Class Initialized
INFO - 2024-05-19 13:38:18 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-05-19 13:38:18 --> Pagination Class Initialized
INFO - 2024-05-19 13:38:18 --> Form Validation Class Initialized
INFO - 2024-05-19 13:38:18 --> Controller Class Initialized
DEBUG - 2024-05-19 13:38:18 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-05-19 13:38:18 --> Session class already loaded. Second attempt ignored.
INFO - 2024-05-19 13:38:18 --> Model Class Initialized
DEBUG - 2024-05-19 13:38:18 --> Lmrpayments class already loaded. Second attempt ignored.
INFO - 2024-05-19 13:38:18 --> Model Class Initialized
INFO - 2024-05-19 13:38:18 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\mr_payments/payment.php
DEBUG - 2024-05-19 13:38:18 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-05-19 13:38:18 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\include/top_menu.php
INFO - 2024-05-19 13:38:18 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\include/admin_loggedin_info.php
INFO - 2024-05-19 13:38:18 --> Model Class Initialized
INFO - 2024-05-19 13:38:18 --> Model Class Initialized
INFO - 2024-05-19 13:38:18 --> Model Class Initialized
INFO - 2024-05-19 13:38:19 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\include/admin_header.php
INFO - 2024-05-19 13:38:19 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\include/admin_footer.php
INFO - 2024-05-19 13:38:19 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\admin_html_template.php
INFO - 2024-05-19 13:38:19 --> Final output sent to browser
DEBUG - 2024-05-19 13:38:19 --> Total execution time: 1.3383
ERROR - 2024-05-19 13:38:20 --> $config['composer_autoload'] is set to TRUE but E:\xampp\htdocs\maurnaturo\application\vendor/autoload.php was not found.
INFO - 2024-05-19 13:38:20 --> Config Class Initialized
INFO - 2024-05-19 13:38:20 --> Hooks Class Initialized
DEBUG - 2024-05-19 13:38:20 --> UTF-8 Support Enabled
INFO - 2024-05-19 13:38:20 --> Utf8 Class Initialized
INFO - 2024-05-19 13:38:20 --> URI Class Initialized
INFO - 2024-05-19 13:38:20 --> Router Class Initialized
INFO - 2024-05-19 13:38:20 --> Output Class Initialized
INFO - 2024-05-19 13:38:20 --> Security Class Initialized
DEBUG - 2024-05-19 13:38:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-19 13:38:20 --> Input Class Initialized
INFO - 2024-05-19 13:38:20 --> Language Class Initialized
INFO - 2024-05-19 13:38:20 --> Loader Class Initialized
INFO - 2024-05-19 13:38:20 --> Helper loaded: url_helper
INFO - 2024-05-19 13:38:20 --> Helper loaded: file_helper
INFO - 2024-05-19 13:38:20 --> Helper loaded: html_helper
INFO - 2024-05-19 13:38:20 --> Helper loaded: text_helper
INFO - 2024-05-19 13:38:20 --> Helper loaded: form_helper
INFO - 2024-05-19 13:38:20 --> Helper loaded: lang_helper
INFO - 2024-05-19 13:38:20 --> Helper loaded: security_helper
INFO - 2024-05-19 13:38:20 --> Helper loaded: cookie_helper
INFO - 2024-05-19 13:38:20 --> Database Driver Class Initialized
INFO - 2024-05-19 13:38:20 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-19 13:38:20 --> Parser Class Initialized
INFO - 2024-05-19 13:38:20 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-05-19 13:38:20 --> Pagination Class Initialized
INFO - 2024-05-19 13:38:20 --> Form Validation Class Initialized
INFO - 2024-05-19 13:38:20 --> Controller Class Initialized
DEBUG - 2024-05-19 13:38:20 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-05-19 13:38:20 --> Session class already loaded. Second attempt ignored.
INFO - 2024-05-19 13:38:20 --> Model Class Initialized
INFO - 2024-05-19 13:38:20 --> Final output sent to browser
DEBUG - 2024-05-19 13:38:20 --> Total execution time: 0.1434
ERROR - 2024-05-19 13:38:26 --> $config['composer_autoload'] is set to TRUE but E:\xampp\htdocs\maurnaturo\application\vendor/autoload.php was not found.
INFO - 2024-05-19 13:38:26 --> Config Class Initialized
INFO - 2024-05-19 13:38:26 --> Hooks Class Initialized
DEBUG - 2024-05-19 13:38:26 --> UTF-8 Support Enabled
INFO - 2024-05-19 13:38:26 --> Utf8 Class Initialized
INFO - 2024-05-19 13:38:26 --> URI Class Initialized
INFO - 2024-05-19 13:38:26 --> Router Class Initialized
INFO - 2024-05-19 13:38:26 --> Output Class Initialized
INFO - 2024-05-19 13:38:26 --> Security Class Initialized
DEBUG - 2024-05-19 13:38:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-19 13:38:26 --> Input Class Initialized
INFO - 2024-05-19 13:38:26 --> Language Class Initialized
INFO - 2024-05-19 13:38:27 --> Loader Class Initialized
INFO - 2024-05-19 13:38:27 --> Helper loaded: url_helper
INFO - 2024-05-19 13:38:27 --> Helper loaded: file_helper
INFO - 2024-05-19 13:38:27 --> Helper loaded: html_helper
INFO - 2024-05-19 13:38:27 --> Helper loaded: text_helper
INFO - 2024-05-19 13:38:27 --> Helper loaded: form_helper
INFO - 2024-05-19 13:38:27 --> Helper loaded: lang_helper
INFO - 2024-05-19 13:38:27 --> Helper loaded: security_helper
INFO - 2024-05-19 13:38:27 --> Helper loaded: cookie_helper
INFO - 2024-05-19 13:38:27 --> Database Driver Class Initialized
INFO - 2024-05-19 13:38:27 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-19 13:38:27 --> Parser Class Initialized
INFO - 2024-05-19 13:38:27 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-05-19 13:38:27 --> Pagination Class Initialized
INFO - 2024-05-19 13:38:27 --> Form Validation Class Initialized
INFO - 2024-05-19 13:38:27 --> Controller Class Initialized
DEBUG - 2024-05-19 13:38:27 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-05-19 13:38:27 --> Session class already loaded. Second attempt ignored.
INFO - 2024-05-19 13:38:27 --> Model Class Initialized
DEBUG - 2024-05-19 13:38:27 --> Lpayments class already loaded. Second attempt ignored.
INFO - 2024-05-19 13:38:27 --> Model Class Initialized
INFO - 2024-05-19 13:38:27 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\payments/payment.php
DEBUG - 2024-05-19 13:38:27 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-05-19 13:38:27 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\include/top_menu.php
INFO - 2024-05-19 13:38:27 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\include/admin_loggedin_info.php
INFO - 2024-05-19 13:38:27 --> Model Class Initialized
INFO - 2024-05-19 13:38:27 --> Model Class Initialized
INFO - 2024-05-19 13:38:27 --> Model Class Initialized
INFO - 2024-05-19 13:38:28 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\include/admin_header.php
INFO - 2024-05-19 13:38:28 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\include/admin_footer.php
INFO - 2024-05-19 13:38:28 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\admin_html_template.php
INFO - 2024-05-19 13:38:28 --> Final output sent to browser
DEBUG - 2024-05-19 13:38:28 --> Total execution time: 1.7642
ERROR - 2024-05-19 13:38:29 --> $config['composer_autoload'] is set to TRUE but E:\xampp\htdocs\maurnaturo\application\vendor/autoload.php was not found.
INFO - 2024-05-19 13:38:29 --> Config Class Initialized
INFO - 2024-05-19 13:38:29 --> Hooks Class Initialized
DEBUG - 2024-05-19 13:38:29 --> UTF-8 Support Enabled
INFO - 2024-05-19 13:38:29 --> Utf8 Class Initialized
INFO - 2024-05-19 13:38:29 --> URI Class Initialized
INFO - 2024-05-19 13:38:29 --> Router Class Initialized
INFO - 2024-05-19 13:38:29 --> Output Class Initialized
INFO - 2024-05-19 13:38:29 --> Security Class Initialized
DEBUG - 2024-05-19 13:38:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-19 13:38:29 --> Input Class Initialized
INFO - 2024-05-19 13:38:29 --> Language Class Initialized
INFO - 2024-05-19 13:38:29 --> Loader Class Initialized
INFO - 2024-05-19 13:38:29 --> Helper loaded: url_helper
INFO - 2024-05-19 13:38:29 --> Helper loaded: file_helper
INFO - 2024-05-19 13:38:29 --> Helper loaded: html_helper
INFO - 2024-05-19 13:38:29 --> Helper loaded: text_helper
INFO - 2024-05-19 13:38:29 --> Helper loaded: form_helper
INFO - 2024-05-19 13:38:29 --> Helper loaded: lang_helper
INFO - 2024-05-19 13:38:29 --> Helper loaded: security_helper
INFO - 2024-05-19 13:38:29 --> Helper loaded: cookie_helper
INFO - 2024-05-19 13:38:29 --> Database Driver Class Initialized
INFO - 2024-05-19 13:38:29 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-19 13:38:29 --> Parser Class Initialized
INFO - 2024-05-19 13:38:29 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-05-19 13:38:29 --> Pagination Class Initialized
INFO - 2024-05-19 13:38:29 --> Form Validation Class Initialized
INFO - 2024-05-19 13:38:29 --> Controller Class Initialized
DEBUG - 2024-05-19 13:38:29 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-05-19 13:38:29 --> Session class already loaded. Second attempt ignored.
INFO - 2024-05-19 13:38:29 --> Model Class Initialized
INFO - 2024-05-19 13:38:29 --> Final output sent to browser
DEBUG - 2024-05-19 13:38:29 --> Total execution time: 0.2456
ERROR - 2024-05-19 15:07:25 --> $config['composer_autoload'] is set to TRUE but E:\xampp\htdocs\maurnaturo\application\vendor/autoload.php was not found.
INFO - 2024-05-19 15:07:25 --> Config Class Initialized
INFO - 2024-05-19 15:07:25 --> Hooks Class Initialized
DEBUG - 2024-05-19 15:07:25 --> UTF-8 Support Enabled
INFO - 2024-05-19 15:07:25 --> Utf8 Class Initialized
INFO - 2024-05-19 15:07:25 --> URI Class Initialized
DEBUG - 2024-05-19 15:07:25 --> No URI present. Default controller set.
INFO - 2024-05-19 15:07:25 --> Router Class Initialized
INFO - 2024-05-19 15:07:25 --> Output Class Initialized
INFO - 2024-05-19 15:07:25 --> Security Class Initialized
DEBUG - 2024-05-19 15:07:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-19 15:07:25 --> Input Class Initialized
INFO - 2024-05-19 15:07:25 --> Language Class Initialized
INFO - 2024-05-19 15:07:25 --> Loader Class Initialized
INFO - 2024-05-19 15:07:25 --> Helper loaded: url_helper
INFO - 2024-05-19 15:07:25 --> Helper loaded: file_helper
INFO - 2024-05-19 15:07:25 --> Helper loaded: html_helper
INFO - 2024-05-19 15:07:25 --> Helper loaded: text_helper
INFO - 2024-05-19 15:07:25 --> Helper loaded: form_helper
INFO - 2024-05-19 15:07:25 --> Helper loaded: lang_helper
INFO - 2024-05-19 15:07:25 --> Helper loaded: security_helper
INFO - 2024-05-19 15:07:25 --> Helper loaded: cookie_helper
INFO - 2024-05-19 15:07:25 --> Database Driver Class Initialized
INFO - 2024-05-19 15:07:25 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-19 15:07:25 --> Parser Class Initialized
INFO - 2024-05-19 15:07:25 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-05-19 15:07:25 --> Pagination Class Initialized
INFO - 2024-05-19 15:07:25 --> Form Validation Class Initialized
INFO - 2024-05-19 15:07:25 --> Controller Class Initialized
INFO - 2024-05-19 15:07:25 --> Model Class Initialized
DEBUG - 2024-05-19 15:07:25 --> Session class already loaded. Second attempt ignored.
INFO - 2024-05-19 15:07:25 --> Model Class Initialized
DEBUG - 2024-05-19 15:07:25 --> Session class already loaded. Second attempt ignored.
INFO - 2024-05-19 15:07:25 --> Model Class Initialized
INFO - 2024-05-19 15:07:25 --> Model Class Initialized
INFO - 2024-05-19 15:07:25 --> Model Class Initialized
INFO - 2024-05-19 15:07:25 --> Model Class Initialized
DEBUG - 2024-05-19 15:07:25 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-05-19 15:07:25 --> Session class already loaded. Second attempt ignored.
INFO - 2024-05-19 15:07:25 --> Model Class Initialized
INFO - 2024-05-19 15:07:25 --> Model Class Initialized
INFO - 2024-05-19 15:07:27 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\include/admin_home.php
DEBUG - 2024-05-19 15:07:27 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-05-19 15:07:27 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\include/top_menu.php
INFO - 2024-05-19 15:07:27 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\include/admin_loggedin_info.php
INFO - 2024-05-19 15:07:27 --> Model Class Initialized
INFO - 2024-05-19 15:07:29 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\include/admin_header.php
INFO - 2024-05-19 15:07:29 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\include/admin_footer.php
INFO - 2024-05-19 15:07:29 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\admin_html_template.php
INFO - 2024-05-19 15:07:29 --> Final output sent to browser
DEBUG - 2024-05-19 15:07:29 --> Total execution time: 3.7816
ERROR - 2024-05-19 15:08:35 --> $config['composer_autoload'] is set to TRUE but E:\xampp\htdocs\maurnaturo\application\vendor/autoload.php was not found.
INFO - 2024-05-19 15:08:35 --> Config Class Initialized
INFO - 2024-05-19 15:08:35 --> Hooks Class Initialized
DEBUG - 2024-05-19 15:08:35 --> UTF-8 Support Enabled
INFO - 2024-05-19 15:08:35 --> Utf8 Class Initialized
INFO - 2024-05-19 15:08:35 --> URI Class Initialized
INFO - 2024-05-19 15:08:35 --> Router Class Initialized
INFO - 2024-05-19 15:08:35 --> Output Class Initialized
INFO - 2024-05-19 15:08:35 --> Security Class Initialized
DEBUG - 2024-05-19 15:08:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-19 15:08:35 --> Input Class Initialized
INFO - 2024-05-19 15:08:35 --> Language Class Initialized
INFO - 2024-05-19 15:08:35 --> Loader Class Initialized
INFO - 2024-05-19 15:08:35 --> Helper loaded: url_helper
INFO - 2024-05-19 15:08:35 --> Helper loaded: file_helper
INFO - 2024-05-19 15:08:35 --> Helper loaded: html_helper
INFO - 2024-05-19 15:08:35 --> Helper loaded: text_helper
INFO - 2024-05-19 15:08:35 --> Helper loaded: form_helper
INFO - 2024-05-19 15:08:35 --> Helper loaded: lang_helper
INFO - 2024-05-19 15:08:35 --> Helper loaded: security_helper
INFO - 2024-05-19 15:08:35 --> Helper loaded: cookie_helper
INFO - 2024-05-19 15:08:35 --> Database Driver Class Initialized
INFO - 2024-05-19 15:08:35 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-19 15:08:35 --> Parser Class Initialized
INFO - 2024-05-19 15:08:35 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-05-19 15:08:35 --> Pagination Class Initialized
INFO - 2024-05-19 15:08:35 --> Form Validation Class Initialized
INFO - 2024-05-19 15:08:35 --> Controller Class Initialized
DEBUG - 2024-05-19 15:08:35 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-05-19 15:08:35 --> Session class already loaded. Second attempt ignored.
INFO - 2024-05-19 15:08:35 --> Model Class Initialized
INFO - 2024-05-19 15:08:35 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\salary/add_salary_form.php
DEBUG - 2024-05-19 15:08:35 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-05-19 15:08:35 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\include/top_menu.php
INFO - 2024-05-19 15:08:35 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\include/admin_loggedin_info.php
INFO - 2024-05-19 15:08:35 --> Model Class Initialized
INFO - 2024-05-19 15:08:36 --> Model Class Initialized
INFO - 2024-05-19 15:08:36 --> Model Class Initialized
INFO - 2024-05-19 15:08:36 --> Model Class Initialized
INFO - 2024-05-19 15:08:37 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\include/admin_header.php
INFO - 2024-05-19 15:08:37 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\include/admin_footer.php
INFO - 2024-05-19 15:08:37 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\admin_html_template.php
INFO - 2024-05-19 15:08:37 --> Final output sent to browser
DEBUG - 2024-05-19 15:08:37 --> Total execution time: 1.9385
ERROR - 2024-05-19 15:08:42 --> $config['composer_autoload'] is set to TRUE but E:\xampp\htdocs\maurnaturo\application\vendor/autoload.php was not found.
INFO - 2024-05-19 15:08:42 --> Config Class Initialized
INFO - 2024-05-19 15:08:42 --> Hooks Class Initialized
DEBUG - 2024-05-19 15:08:42 --> UTF-8 Support Enabled
INFO - 2024-05-19 15:08:42 --> Utf8 Class Initialized
INFO - 2024-05-19 15:08:42 --> URI Class Initialized
INFO - 2024-05-19 15:08:42 --> Router Class Initialized
INFO - 2024-05-19 15:08:42 --> Output Class Initialized
INFO - 2024-05-19 15:08:42 --> Security Class Initialized
DEBUG - 2024-05-19 15:08:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-19 15:08:42 --> Input Class Initialized
INFO - 2024-05-19 15:08:42 --> Language Class Initialized
INFO - 2024-05-19 15:08:42 --> Loader Class Initialized
INFO - 2024-05-19 15:08:42 --> Helper loaded: url_helper
INFO - 2024-05-19 15:08:42 --> Helper loaded: file_helper
INFO - 2024-05-19 15:08:42 --> Helper loaded: html_helper
INFO - 2024-05-19 15:08:42 --> Helper loaded: text_helper
INFO - 2024-05-19 15:08:42 --> Helper loaded: form_helper
INFO - 2024-05-19 15:08:42 --> Helper loaded: lang_helper
INFO - 2024-05-19 15:08:42 --> Helper loaded: security_helper
INFO - 2024-05-19 15:08:42 --> Helper loaded: cookie_helper
INFO - 2024-05-19 15:08:42 --> Database Driver Class Initialized
INFO - 2024-05-19 15:08:42 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-19 15:08:42 --> Parser Class Initialized
INFO - 2024-05-19 15:08:42 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-05-19 15:08:42 --> Pagination Class Initialized
INFO - 2024-05-19 15:08:42 --> Form Validation Class Initialized
INFO - 2024-05-19 15:08:42 --> Controller Class Initialized
DEBUG - 2024-05-19 15:08:42 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-05-19 15:08:42 --> Session class already loaded. Second attempt ignored.
INFO - 2024-05-19 15:08:42 --> Model Class Initialized
DEBUG - 2024-05-19 15:08:42 --> Lsalary class already loaded. Second attempt ignored.
INFO - 2024-05-19 15:08:42 --> Model Class Initialized
INFO - 2024-05-19 15:08:42 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\salary/salary.php
DEBUG - 2024-05-19 15:08:42 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-05-19 15:08:42 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\include/top_menu.php
INFO - 2024-05-19 15:08:42 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\include/admin_loggedin_info.php
INFO - 2024-05-19 15:08:42 --> Model Class Initialized
INFO - 2024-05-19 15:08:42 --> Model Class Initialized
INFO - 2024-05-19 15:08:42 --> Model Class Initialized
INFO - 2024-05-19 15:08:44 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\include/admin_header.php
INFO - 2024-05-19 15:08:44 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\include/admin_footer.php
INFO - 2024-05-19 15:08:44 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\admin_html_template.php
INFO - 2024-05-19 15:08:44 --> Final output sent to browser
DEBUG - 2024-05-19 15:08:44 --> Total execution time: 1.5694
ERROR - 2024-05-19 15:08:44 --> $config['composer_autoload'] is set to TRUE but E:\xampp\htdocs\maurnaturo\application\vendor/autoload.php was not found.
INFO - 2024-05-19 15:08:44 --> Config Class Initialized
INFO - 2024-05-19 15:08:44 --> Hooks Class Initialized
DEBUG - 2024-05-19 15:08:44 --> UTF-8 Support Enabled
INFO - 2024-05-19 15:08:44 --> Utf8 Class Initialized
INFO - 2024-05-19 15:08:44 --> URI Class Initialized
INFO - 2024-05-19 15:08:44 --> Router Class Initialized
INFO - 2024-05-19 15:08:44 --> Output Class Initialized
INFO - 2024-05-19 15:08:44 --> Security Class Initialized
DEBUG - 2024-05-19 15:08:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-19 15:08:44 --> Input Class Initialized
INFO - 2024-05-19 15:08:44 --> Language Class Initialized
INFO - 2024-05-19 15:08:44 --> Loader Class Initialized
INFO - 2024-05-19 15:08:44 --> Helper loaded: url_helper
INFO - 2024-05-19 15:08:44 --> Helper loaded: file_helper
INFO - 2024-05-19 15:08:44 --> Helper loaded: html_helper
INFO - 2024-05-19 15:08:44 --> Helper loaded: text_helper
INFO - 2024-05-19 15:08:44 --> Helper loaded: form_helper
INFO - 2024-05-19 15:08:44 --> Helper loaded: lang_helper
INFO - 2024-05-19 15:08:44 --> Helper loaded: security_helper
INFO - 2024-05-19 15:08:44 --> Helper loaded: cookie_helper
INFO - 2024-05-19 15:08:44 --> Database Driver Class Initialized
INFO - 2024-05-19 15:08:44 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-19 15:08:44 --> Parser Class Initialized
INFO - 2024-05-19 15:08:44 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-05-19 15:08:44 --> Pagination Class Initialized
INFO - 2024-05-19 15:08:44 --> Form Validation Class Initialized
INFO - 2024-05-19 15:08:44 --> Controller Class Initialized
DEBUG - 2024-05-19 15:08:44 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-05-19 15:08:44 --> Session class already loaded. Second attempt ignored.
INFO - 2024-05-19 15:08:44 --> Model Class Initialized
INFO - 2024-05-19 15:08:44 --> Final output sent to browser
DEBUG - 2024-05-19 15:08:44 --> Total execution time: 0.1571
ERROR - 2024-05-19 15:11:13 --> $config['composer_autoload'] is set to TRUE but E:\xampp\htdocs\maurnaturo\application\vendor/autoload.php was not found.
INFO - 2024-05-19 15:11:13 --> Config Class Initialized
INFO - 2024-05-19 15:11:13 --> Hooks Class Initialized
DEBUG - 2024-05-19 15:11:13 --> UTF-8 Support Enabled
INFO - 2024-05-19 15:11:13 --> Utf8 Class Initialized
INFO - 2024-05-19 15:11:13 --> URI Class Initialized
DEBUG - 2024-05-19 15:11:13 --> No URI present. Default controller set.
INFO - 2024-05-19 15:11:13 --> Router Class Initialized
INFO - 2024-05-19 15:11:13 --> Output Class Initialized
INFO - 2024-05-19 15:11:13 --> Security Class Initialized
DEBUG - 2024-05-19 15:11:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-19 15:11:13 --> Input Class Initialized
INFO - 2024-05-19 15:11:13 --> Language Class Initialized
INFO - 2024-05-19 15:11:13 --> Loader Class Initialized
INFO - 2024-05-19 15:11:13 --> Helper loaded: url_helper
INFO - 2024-05-19 15:11:13 --> Helper loaded: file_helper
INFO - 2024-05-19 15:11:13 --> Helper loaded: html_helper
INFO - 2024-05-19 15:11:13 --> Helper loaded: text_helper
INFO - 2024-05-19 15:11:13 --> Helper loaded: form_helper
INFO - 2024-05-19 15:11:13 --> Helper loaded: lang_helper
INFO - 2024-05-19 15:11:13 --> Helper loaded: security_helper
INFO - 2024-05-19 15:11:13 --> Helper loaded: cookie_helper
INFO - 2024-05-19 15:11:13 --> Database Driver Class Initialized
INFO - 2024-05-19 15:11:13 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-19 15:11:13 --> Parser Class Initialized
INFO - 2024-05-19 15:11:13 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-05-19 15:11:13 --> Pagination Class Initialized
INFO - 2024-05-19 15:11:13 --> Form Validation Class Initialized
INFO - 2024-05-19 15:11:13 --> Controller Class Initialized
INFO - 2024-05-19 15:11:13 --> Model Class Initialized
DEBUG - 2024-05-19 15:11:13 --> Session class already loaded. Second attempt ignored.
INFO - 2024-05-19 15:11:13 --> Model Class Initialized
DEBUG - 2024-05-19 15:11:13 --> Session class already loaded. Second attempt ignored.
INFO - 2024-05-19 15:11:13 --> Model Class Initialized
INFO - 2024-05-19 15:11:13 --> Model Class Initialized
INFO - 2024-05-19 15:11:13 --> Model Class Initialized
INFO - 2024-05-19 15:11:13 --> Model Class Initialized
DEBUG - 2024-05-19 15:11:13 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-05-19 15:11:13 --> Session class already loaded. Second attempt ignored.
INFO - 2024-05-19 15:11:13 --> Model Class Initialized
INFO - 2024-05-19 15:11:13 --> Model Class Initialized
INFO - 2024-05-19 15:11:14 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\include/admin_home.php
DEBUG - 2024-05-19 15:11:14 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-05-19 15:11:14 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\include/top_menu.php
INFO - 2024-05-19 15:11:14 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\include/admin_loggedin_info.php
INFO - 2024-05-19 15:11:14 --> Model Class Initialized
INFO - 2024-05-19 15:11:15 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\include/admin_header.php
INFO - 2024-05-19 15:11:15 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\include/admin_footer.php
INFO - 2024-05-19 15:11:15 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\admin_html_template.php
INFO - 2024-05-19 15:11:15 --> Final output sent to browser
DEBUG - 2024-05-19 15:11:15 --> Total execution time: 2.1183
ERROR - 2024-05-19 15:11:33 --> $config['composer_autoload'] is set to TRUE but E:\xampp\htdocs\maurnaturo\application\vendor/autoload.php was not found.
INFO - 2024-05-19 15:11:33 --> Config Class Initialized
INFO - 2024-05-19 15:11:33 --> Hooks Class Initialized
DEBUG - 2024-05-19 15:11:33 --> UTF-8 Support Enabled
INFO - 2024-05-19 15:11:33 --> Utf8 Class Initialized
INFO - 2024-05-19 15:11:33 --> URI Class Initialized
INFO - 2024-05-19 15:11:33 --> Router Class Initialized
INFO - 2024-05-19 15:11:33 --> Output Class Initialized
INFO - 2024-05-19 15:11:33 --> Security Class Initialized
DEBUG - 2024-05-19 15:11:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-19 15:11:33 --> Input Class Initialized
INFO - 2024-05-19 15:11:33 --> Language Class Initialized
INFO - 2024-05-19 15:11:33 --> Loader Class Initialized
INFO - 2024-05-19 15:11:33 --> Helper loaded: url_helper
INFO - 2024-05-19 15:11:33 --> Helper loaded: file_helper
INFO - 2024-05-19 15:11:33 --> Helper loaded: html_helper
INFO - 2024-05-19 15:11:33 --> Helper loaded: text_helper
INFO - 2024-05-19 15:11:33 --> Helper loaded: form_helper
INFO - 2024-05-19 15:11:33 --> Helper loaded: lang_helper
INFO - 2024-05-19 15:11:33 --> Helper loaded: security_helper
INFO - 2024-05-19 15:11:33 --> Helper loaded: cookie_helper
INFO - 2024-05-19 15:11:33 --> Database Driver Class Initialized
INFO - 2024-05-19 15:11:33 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-19 15:11:33 --> Parser Class Initialized
INFO - 2024-05-19 15:11:33 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-05-19 15:11:33 --> Pagination Class Initialized
INFO - 2024-05-19 15:11:33 --> Form Validation Class Initialized
INFO - 2024-05-19 15:11:33 --> Controller Class Initialized
DEBUG - 2024-05-19 15:11:33 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-05-19 15:11:33 --> Session class already loaded. Second attempt ignored.
INFO - 2024-05-19 15:11:33 --> Model Class Initialized
INFO - 2024-05-19 15:11:33 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\salary/add_salary_form.php
DEBUG - 2024-05-19 15:11:33 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-05-19 15:11:33 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\include/top_menu.php
INFO - 2024-05-19 15:11:33 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\include/admin_loggedin_info.php
INFO - 2024-05-19 15:11:33 --> Model Class Initialized
INFO - 2024-05-19 15:11:33 --> Model Class Initialized
INFO - 2024-05-19 15:11:33 --> Model Class Initialized
INFO - 2024-05-19 15:11:33 --> Model Class Initialized
INFO - 2024-05-19 15:11:34 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\include/admin_header.php
INFO - 2024-05-19 15:11:34 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\include/admin_footer.php
INFO - 2024-05-19 15:11:34 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\admin_html_template.php
INFO - 2024-05-19 15:11:34 --> Final output sent to browser
DEBUG - 2024-05-19 15:11:34 --> Total execution time: 1.4306
ERROR - 2024-05-19 15:11:42 --> $config['composer_autoload'] is set to TRUE but E:\xampp\htdocs\maurnaturo\application\vendor/autoload.php was not found.
INFO - 2024-05-19 15:11:42 --> Config Class Initialized
INFO - 2024-05-19 15:11:42 --> Hooks Class Initialized
DEBUG - 2024-05-19 15:11:42 --> UTF-8 Support Enabled
INFO - 2024-05-19 15:11:42 --> Utf8 Class Initialized
INFO - 2024-05-19 15:11:42 --> URI Class Initialized
INFO - 2024-05-19 15:11:42 --> Router Class Initialized
INFO - 2024-05-19 15:11:42 --> Output Class Initialized
INFO - 2024-05-19 15:11:42 --> Security Class Initialized
DEBUG - 2024-05-19 15:11:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-19 15:11:42 --> Input Class Initialized
INFO - 2024-05-19 15:11:42 --> Language Class Initialized
ERROR - 2024-05-19 15:11:42 --> 404 Page Not Found: Assets/plugins
ERROR - 2024-05-19 15:11:42 --> $config['composer_autoload'] is set to TRUE but E:\xampp\htdocs\maurnaturo\application\vendor/autoload.php was not found.
INFO - 2024-05-19 15:11:42 --> Config Class Initialized
INFO - 2024-05-19 15:11:42 --> Hooks Class Initialized
DEBUG - 2024-05-19 15:11:42 --> UTF-8 Support Enabled
INFO - 2024-05-19 15:11:42 --> Utf8 Class Initialized
INFO - 2024-05-19 15:11:42 --> URI Class Initialized
INFO - 2024-05-19 15:11:42 --> Router Class Initialized
INFO - 2024-05-19 15:11:42 --> Output Class Initialized
INFO - 2024-05-19 15:11:42 --> Security Class Initialized
DEBUG - 2024-05-19 15:11:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-19 15:11:42 --> Input Class Initialized
INFO - 2024-05-19 15:11:42 --> Language Class Initialized
ERROR - 2024-05-19 15:11:42 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2024-05-19 15:20:48 --> $config['composer_autoload'] is set to TRUE but E:\xampp\htdocs\maurnaturo\application\vendor/autoload.php was not found.
INFO - 2024-05-19 15:20:48 --> Config Class Initialized
INFO - 2024-05-19 15:20:48 --> Hooks Class Initialized
DEBUG - 2024-05-19 15:20:48 --> UTF-8 Support Enabled
INFO - 2024-05-19 15:20:48 --> Utf8 Class Initialized
INFO - 2024-05-19 15:20:48 --> URI Class Initialized
DEBUG - 2024-05-19 15:20:48 --> No URI present. Default controller set.
INFO - 2024-05-19 15:20:48 --> Router Class Initialized
INFO - 2024-05-19 15:20:48 --> Output Class Initialized
INFO - 2024-05-19 15:20:48 --> Security Class Initialized
DEBUG - 2024-05-19 15:20:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-19 15:20:48 --> Input Class Initialized
INFO - 2024-05-19 15:20:48 --> Language Class Initialized
INFO - 2024-05-19 15:20:48 --> Loader Class Initialized
INFO - 2024-05-19 15:20:48 --> Helper loaded: url_helper
INFO - 2024-05-19 15:20:48 --> Helper loaded: file_helper
INFO - 2024-05-19 15:20:48 --> Helper loaded: html_helper
INFO - 2024-05-19 15:20:48 --> Helper loaded: text_helper
INFO - 2024-05-19 15:20:48 --> Helper loaded: form_helper
INFO - 2024-05-19 15:20:48 --> Helper loaded: lang_helper
INFO - 2024-05-19 15:20:48 --> Helper loaded: security_helper
INFO - 2024-05-19 15:20:48 --> Helper loaded: cookie_helper
INFO - 2024-05-19 15:20:48 --> Database Driver Class Initialized
INFO - 2024-05-19 15:20:48 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-19 15:20:48 --> Parser Class Initialized
INFO - 2024-05-19 15:20:48 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-05-19 15:20:48 --> Pagination Class Initialized
INFO - 2024-05-19 15:20:48 --> Form Validation Class Initialized
INFO - 2024-05-19 15:20:48 --> Controller Class Initialized
INFO - 2024-05-19 15:20:48 --> Model Class Initialized
DEBUG - 2024-05-19 15:20:48 --> Session class already loaded. Second attempt ignored.
INFO - 2024-05-19 15:20:48 --> Model Class Initialized
DEBUG - 2024-05-19 15:20:48 --> Session class already loaded. Second attempt ignored.
INFO - 2024-05-19 15:20:48 --> Model Class Initialized
INFO - 2024-05-19 15:20:48 --> Model Class Initialized
INFO - 2024-05-19 15:20:48 --> Model Class Initialized
INFO - 2024-05-19 15:20:48 --> Model Class Initialized
DEBUG - 2024-05-19 15:20:48 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-05-19 15:20:48 --> Session class already loaded. Second attempt ignored.
INFO - 2024-05-19 15:20:48 --> Model Class Initialized
INFO - 2024-05-19 15:20:48 --> Model Class Initialized
INFO - 2024-05-19 15:20:50 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\include/admin_home.php
DEBUG - 2024-05-19 15:20:50 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-05-19 15:20:50 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\include/top_menu.php
INFO - 2024-05-19 15:20:50 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\include/admin_loggedin_info.php
INFO - 2024-05-19 15:20:50 --> Model Class Initialized
INFO - 2024-05-19 15:20:51 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\include/admin_header.php
INFO - 2024-05-19 15:20:51 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\include/admin_footer.php
INFO - 2024-05-19 15:20:51 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\admin_html_template.php
INFO - 2024-05-19 15:20:51 --> Final output sent to browser
DEBUG - 2024-05-19 15:20:51 --> Total execution time: 2.5970
ERROR - 2024-05-19 15:20:59 --> $config['composer_autoload'] is set to TRUE but E:\xampp\htdocs\maurnaturo\application\vendor/autoload.php was not found.
INFO - 2024-05-19 15:20:59 --> Config Class Initialized
INFO - 2024-05-19 15:20:59 --> Hooks Class Initialized
DEBUG - 2024-05-19 15:20:59 --> UTF-8 Support Enabled
INFO - 2024-05-19 15:20:59 --> Utf8 Class Initialized
INFO - 2024-05-19 15:20:59 --> URI Class Initialized
INFO - 2024-05-19 15:20:59 --> Router Class Initialized
INFO - 2024-05-19 15:20:59 --> Output Class Initialized
INFO - 2024-05-19 15:20:59 --> Security Class Initialized
DEBUG - 2024-05-19 15:20:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-19 15:20:59 --> Input Class Initialized
INFO - 2024-05-19 15:20:59 --> Language Class Initialized
ERROR - 2024-05-19 15:20:59 --> 404 Page Not Found: Assets/plugins
ERROR - 2024-05-19 15:20:59 --> $config['composer_autoload'] is set to TRUE but E:\xampp\htdocs\maurnaturo\application\vendor/autoload.php was not found.
INFO - 2024-05-19 15:20:59 --> Config Class Initialized
INFO - 2024-05-19 15:20:59 --> Hooks Class Initialized
DEBUG - 2024-05-19 15:20:59 --> UTF-8 Support Enabled
INFO - 2024-05-19 15:20:59 --> Utf8 Class Initialized
INFO - 2024-05-19 15:20:59 --> URI Class Initialized
INFO - 2024-05-19 15:20:59 --> Router Class Initialized
INFO - 2024-05-19 15:20:59 --> Output Class Initialized
INFO - 2024-05-19 15:20:59 --> Security Class Initialized
DEBUG - 2024-05-19 15:20:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-19 15:20:59 --> Input Class Initialized
INFO - 2024-05-19 15:20:59 --> Language Class Initialized
ERROR - 2024-05-19 15:20:59 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2024-05-19 15:21:27 --> $config['composer_autoload'] is set to TRUE but E:\xampp\htdocs\maurnaturo\application\vendor/autoload.php was not found.
INFO - 2024-05-19 15:21:27 --> Config Class Initialized
INFO - 2024-05-19 15:21:27 --> Hooks Class Initialized
DEBUG - 2024-05-19 15:21:27 --> UTF-8 Support Enabled
INFO - 2024-05-19 15:21:27 --> Utf8 Class Initialized
INFO - 2024-05-19 15:21:27 --> URI Class Initialized
DEBUG - 2024-05-19 15:21:27 --> No URI present. Default controller set.
INFO - 2024-05-19 15:21:27 --> Router Class Initialized
INFO - 2024-05-19 15:21:27 --> Output Class Initialized
INFO - 2024-05-19 15:21:27 --> Security Class Initialized
DEBUG - 2024-05-19 15:21:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-19 15:21:27 --> Input Class Initialized
INFO - 2024-05-19 15:21:27 --> Language Class Initialized
INFO - 2024-05-19 15:21:27 --> Loader Class Initialized
INFO - 2024-05-19 15:21:27 --> Helper loaded: url_helper
INFO - 2024-05-19 15:21:27 --> Helper loaded: file_helper
INFO - 2024-05-19 15:21:27 --> Helper loaded: html_helper
INFO - 2024-05-19 15:21:27 --> Helper loaded: text_helper
INFO - 2024-05-19 15:21:27 --> Helper loaded: form_helper
INFO - 2024-05-19 15:21:27 --> Helper loaded: lang_helper
INFO - 2024-05-19 15:21:27 --> Helper loaded: security_helper
INFO - 2024-05-19 15:21:27 --> Helper loaded: cookie_helper
INFO - 2024-05-19 15:21:27 --> Database Driver Class Initialized
INFO - 2024-05-19 15:21:27 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-19 15:21:27 --> Parser Class Initialized
INFO - 2024-05-19 15:21:27 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-05-19 15:21:27 --> Pagination Class Initialized
INFO - 2024-05-19 15:21:27 --> Form Validation Class Initialized
INFO - 2024-05-19 15:21:27 --> Controller Class Initialized
INFO - 2024-05-19 15:21:27 --> Model Class Initialized
DEBUG - 2024-05-19 15:21:27 --> Session class already loaded. Second attempt ignored.
INFO - 2024-05-19 15:21:27 --> Model Class Initialized
DEBUG - 2024-05-19 15:21:27 --> Session class already loaded. Second attempt ignored.
INFO - 2024-05-19 15:21:27 --> Model Class Initialized
INFO - 2024-05-19 15:21:27 --> Model Class Initialized
INFO - 2024-05-19 15:21:27 --> Model Class Initialized
INFO - 2024-05-19 15:21:27 --> Model Class Initialized
DEBUG - 2024-05-19 15:21:27 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-05-19 15:21:27 --> Session class already loaded. Second attempt ignored.
INFO - 2024-05-19 15:21:27 --> Model Class Initialized
INFO - 2024-05-19 15:21:27 --> Model Class Initialized
INFO - 2024-05-19 15:21:28 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\include/admin_home.php
DEBUG - 2024-05-19 15:21:28 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-05-19 15:21:28 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\include/top_menu.php
INFO - 2024-05-19 15:21:28 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\include/admin_loggedin_info.php
INFO - 2024-05-19 15:21:28 --> Model Class Initialized
INFO - 2024-05-19 15:21:29 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\include/admin_header.php
INFO - 2024-05-19 15:21:29 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\include/admin_footer.php
INFO - 2024-05-19 15:21:29 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\admin_html_template.php
INFO - 2024-05-19 15:21:29 --> Final output sent to browser
DEBUG - 2024-05-19 15:21:29 --> Total execution time: 2.2428
ERROR - 2024-05-19 15:21:30 --> $config['composer_autoload'] is set to TRUE but E:\xampp\htdocs\maurnaturo\application\vendor/autoload.php was not found.
INFO - 2024-05-19 15:21:30 --> Config Class Initialized
INFO - 2024-05-19 15:21:30 --> Hooks Class Initialized
DEBUG - 2024-05-19 15:21:30 --> UTF-8 Support Enabled
INFO - 2024-05-19 15:21:30 --> Utf8 Class Initialized
INFO - 2024-05-19 15:21:30 --> URI Class Initialized
INFO - 2024-05-19 15:21:30 --> Router Class Initialized
INFO - 2024-05-19 15:21:30 --> Output Class Initialized
INFO - 2024-05-19 15:21:30 --> Security Class Initialized
DEBUG - 2024-05-19 15:21:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-19 15:21:30 --> Input Class Initialized
INFO - 2024-05-19 15:21:30 --> Language Class Initialized
ERROR - 2024-05-19 15:21:30 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2024-05-19 15:21:30 --> $config['composer_autoload'] is set to TRUE but E:\xampp\htdocs\maurnaturo\application\vendor/autoload.php was not found.
INFO - 2024-05-19 15:21:30 --> Config Class Initialized
INFO - 2024-05-19 15:21:30 --> Hooks Class Initialized
DEBUG - 2024-05-19 15:21:30 --> UTF-8 Support Enabled
INFO - 2024-05-19 15:21:30 --> Utf8 Class Initialized
INFO - 2024-05-19 15:21:30 --> URI Class Initialized
INFO - 2024-05-19 15:21:30 --> Router Class Initialized
INFO - 2024-05-19 15:21:30 --> Output Class Initialized
INFO - 2024-05-19 15:21:30 --> Security Class Initialized
DEBUG - 2024-05-19 15:21:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-19 15:21:30 --> Input Class Initialized
INFO - 2024-05-19 15:21:30 --> Language Class Initialized
ERROR - 2024-05-19 15:21:30 --> 404 Page Not Found: Assets/plugins
ERROR - 2024-05-19 15:21:42 --> $config['composer_autoload'] is set to TRUE but E:\xampp\htdocs\maurnaturo\application\vendor/autoload.php was not found.
INFO - 2024-05-19 15:21:42 --> Config Class Initialized
INFO - 2024-05-19 15:21:42 --> Hooks Class Initialized
DEBUG - 2024-05-19 15:21:42 --> UTF-8 Support Enabled
INFO - 2024-05-19 15:21:42 --> Utf8 Class Initialized
INFO - 2024-05-19 15:21:42 --> URI Class Initialized
DEBUG - 2024-05-19 15:21:42 --> No URI present. Default controller set.
INFO - 2024-05-19 15:21:42 --> Router Class Initialized
INFO - 2024-05-19 15:21:42 --> Output Class Initialized
INFO - 2024-05-19 15:21:42 --> Security Class Initialized
DEBUG - 2024-05-19 15:21:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-19 15:21:42 --> Input Class Initialized
INFO - 2024-05-19 15:21:42 --> Language Class Initialized
INFO - 2024-05-19 15:21:42 --> Loader Class Initialized
INFO - 2024-05-19 15:21:42 --> Helper loaded: url_helper
INFO - 2024-05-19 15:21:42 --> Helper loaded: file_helper
INFO - 2024-05-19 15:21:42 --> Helper loaded: html_helper
INFO - 2024-05-19 15:21:42 --> Helper loaded: text_helper
INFO - 2024-05-19 15:21:42 --> Helper loaded: form_helper
INFO - 2024-05-19 15:21:42 --> Helper loaded: lang_helper
INFO - 2024-05-19 15:21:42 --> Helper loaded: security_helper
INFO - 2024-05-19 15:21:42 --> Helper loaded: cookie_helper
INFO - 2024-05-19 15:21:42 --> Database Driver Class Initialized
INFO - 2024-05-19 15:21:42 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-19 15:21:42 --> Parser Class Initialized
INFO - 2024-05-19 15:21:43 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-05-19 15:21:43 --> Pagination Class Initialized
INFO - 2024-05-19 15:21:43 --> Form Validation Class Initialized
INFO - 2024-05-19 15:21:43 --> Controller Class Initialized
INFO - 2024-05-19 15:21:43 --> Model Class Initialized
DEBUG - 2024-05-19 15:21:43 --> Session class already loaded. Second attempt ignored.
INFO - 2024-05-19 15:21:43 --> Model Class Initialized
DEBUG - 2024-05-19 15:21:43 --> Session class already loaded. Second attempt ignored.
INFO - 2024-05-19 15:21:43 --> Model Class Initialized
INFO - 2024-05-19 15:21:43 --> Model Class Initialized
INFO - 2024-05-19 15:21:43 --> Model Class Initialized
INFO - 2024-05-19 15:21:43 --> Model Class Initialized
DEBUG - 2024-05-19 15:21:43 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-05-19 15:21:43 --> Session class already loaded. Second attempt ignored.
INFO - 2024-05-19 15:21:43 --> Model Class Initialized
INFO - 2024-05-19 15:21:43 --> Model Class Initialized
INFO - 2024-05-19 15:21:44 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\include/admin_home.php
DEBUG - 2024-05-19 15:21:44 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-05-19 15:21:44 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\include/top_menu.php
INFO - 2024-05-19 15:21:44 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\include/admin_loggedin_info.php
INFO - 2024-05-19 15:21:44 --> Model Class Initialized
INFO - 2024-05-19 15:21:45 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\include/admin_header.php
INFO - 2024-05-19 15:21:45 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\include/admin_footer.php
INFO - 2024-05-19 15:21:45 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\admin_html_template.php
INFO - 2024-05-19 15:21:45 --> Final output sent to browser
DEBUG - 2024-05-19 15:21:45 --> Total execution time: 2.3583
ERROR - 2024-05-19 15:21:45 --> $config['composer_autoload'] is set to TRUE but E:\xampp\htdocs\maurnaturo\application\vendor/autoload.php was not found.
INFO - 2024-05-19 15:21:45 --> Config Class Initialized
INFO - 2024-05-19 15:21:45 --> Hooks Class Initialized
DEBUG - 2024-05-19 15:21:45 --> UTF-8 Support Enabled
INFO - 2024-05-19 15:21:45 --> Utf8 Class Initialized
INFO - 2024-05-19 15:21:45 --> URI Class Initialized
INFO - 2024-05-19 15:21:45 --> Router Class Initialized
INFO - 2024-05-19 15:21:45 --> Output Class Initialized
INFO - 2024-05-19 15:21:45 --> Security Class Initialized
DEBUG - 2024-05-19 15:21:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-19 15:21:45 --> Input Class Initialized
INFO - 2024-05-19 15:21:45 --> Language Class Initialized
ERROR - 2024-05-19 15:21:45 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2024-05-19 15:21:45 --> $config['composer_autoload'] is set to TRUE but E:\xampp\htdocs\maurnaturo\application\vendor/autoload.php was not found.
INFO - 2024-05-19 15:21:45 --> Config Class Initialized
INFO - 2024-05-19 15:21:45 --> Hooks Class Initialized
DEBUG - 2024-05-19 15:21:45 --> UTF-8 Support Enabled
INFO - 2024-05-19 15:21:45 --> Utf8 Class Initialized
INFO - 2024-05-19 15:21:45 --> URI Class Initialized
INFO - 2024-05-19 15:21:45 --> Router Class Initialized
INFO - 2024-05-19 15:21:45 --> Output Class Initialized
INFO - 2024-05-19 15:21:45 --> Security Class Initialized
DEBUG - 2024-05-19 15:21:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-19 15:21:45 --> Input Class Initialized
INFO - 2024-05-19 15:21:45 --> Language Class Initialized
ERROR - 2024-05-19 15:21:45 --> 404 Page Not Found: Assets/plugins
ERROR - 2024-05-19 15:23:15 --> $config['composer_autoload'] is set to TRUE but E:\xampp\htdocs\maurnaturo\application\vendor/autoload.php was not found.
INFO - 2024-05-19 15:23:15 --> Config Class Initialized
INFO - 2024-05-19 15:23:15 --> Hooks Class Initialized
DEBUG - 2024-05-19 15:23:15 --> UTF-8 Support Enabled
INFO - 2024-05-19 15:23:15 --> Utf8 Class Initialized
INFO - 2024-05-19 15:23:15 --> URI Class Initialized
DEBUG - 2024-05-19 15:23:15 --> No URI present. Default controller set.
INFO - 2024-05-19 15:23:15 --> Router Class Initialized
INFO - 2024-05-19 15:23:15 --> Output Class Initialized
INFO - 2024-05-19 15:23:15 --> Security Class Initialized
DEBUG - 2024-05-19 15:23:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-19 15:23:15 --> Input Class Initialized
INFO - 2024-05-19 15:23:15 --> Language Class Initialized
INFO - 2024-05-19 15:23:15 --> Loader Class Initialized
INFO - 2024-05-19 15:23:15 --> Helper loaded: url_helper
INFO - 2024-05-19 15:23:15 --> Helper loaded: file_helper
INFO - 2024-05-19 15:23:15 --> Helper loaded: html_helper
INFO - 2024-05-19 15:23:15 --> Helper loaded: text_helper
INFO - 2024-05-19 15:23:15 --> Helper loaded: form_helper
INFO - 2024-05-19 15:23:15 --> Helper loaded: lang_helper
INFO - 2024-05-19 15:23:15 --> Helper loaded: security_helper
INFO - 2024-05-19 15:23:15 --> Helper loaded: cookie_helper
INFO - 2024-05-19 15:23:15 --> Database Driver Class Initialized
INFO - 2024-05-19 15:23:15 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-19 15:23:15 --> Parser Class Initialized
INFO - 2024-05-19 15:23:15 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-05-19 15:23:15 --> Pagination Class Initialized
INFO - 2024-05-19 15:23:15 --> Form Validation Class Initialized
INFO - 2024-05-19 15:23:15 --> Controller Class Initialized
INFO - 2024-05-19 15:23:15 --> Model Class Initialized
DEBUG - 2024-05-19 15:23:15 --> Session class already loaded. Second attempt ignored.
INFO - 2024-05-19 15:23:15 --> Model Class Initialized
DEBUG - 2024-05-19 15:23:15 --> Session class already loaded. Second attempt ignored.
INFO - 2024-05-19 15:23:15 --> Model Class Initialized
INFO - 2024-05-19 15:23:15 --> Model Class Initialized
INFO - 2024-05-19 15:23:15 --> Model Class Initialized
INFO - 2024-05-19 15:23:15 --> Model Class Initialized
DEBUG - 2024-05-19 15:23:15 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-05-19 15:23:15 --> Session class already loaded. Second attempt ignored.
INFO - 2024-05-19 15:23:15 --> Model Class Initialized
INFO - 2024-05-19 15:23:15 --> Model Class Initialized
INFO - 2024-05-19 15:23:16 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\include/admin_home.php
DEBUG - 2024-05-19 15:23:16 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-05-19 15:23:16 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\include/top_menu.php
INFO - 2024-05-19 15:23:16 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\include/admin_loggedin_info.php
INFO - 2024-05-19 15:23:16 --> Model Class Initialized
INFO - 2024-05-19 15:23:17 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\include/admin_header.php
INFO - 2024-05-19 15:23:17 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\include/admin_footer.php
INFO - 2024-05-19 15:23:17 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\admin_html_template.php
INFO - 2024-05-19 15:23:17 --> Final output sent to browser
DEBUG - 2024-05-19 15:23:17 --> Total execution time: 2.5977
ERROR - 2024-05-19 15:26:57 --> $config['composer_autoload'] is set to TRUE but E:\xampp\htdocs\maurnaturo\application\vendor/autoload.php was not found.
INFO - 2024-05-19 15:26:57 --> Config Class Initialized
INFO - 2024-05-19 15:26:57 --> Hooks Class Initialized
DEBUG - 2024-05-19 15:26:57 --> UTF-8 Support Enabled
INFO - 2024-05-19 15:26:57 --> Utf8 Class Initialized
INFO - 2024-05-19 15:26:57 --> URI Class Initialized
INFO - 2024-05-19 15:26:57 --> Router Class Initialized
INFO - 2024-05-19 15:26:57 --> Output Class Initialized
INFO - 2024-05-19 15:26:57 --> Security Class Initialized
DEBUG - 2024-05-19 15:26:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-19 15:26:57 --> Input Class Initialized
INFO - 2024-05-19 15:26:57 --> Language Class Initialized
INFO - 2024-05-19 15:26:57 --> Loader Class Initialized
INFO - 2024-05-19 15:26:57 --> Helper loaded: url_helper
INFO - 2024-05-19 15:26:57 --> Helper loaded: file_helper
INFO - 2024-05-19 15:26:57 --> Helper loaded: html_helper
INFO - 2024-05-19 15:26:57 --> Helper loaded: text_helper
INFO - 2024-05-19 15:26:57 --> Helper loaded: form_helper
INFO - 2024-05-19 15:26:57 --> Helper loaded: lang_helper
INFO - 2024-05-19 15:26:57 --> Helper loaded: security_helper
INFO - 2024-05-19 15:26:57 --> Helper loaded: cookie_helper
INFO - 2024-05-19 15:26:57 --> Database Driver Class Initialized
INFO - 2024-05-19 15:26:57 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-19 15:26:57 --> Parser Class Initialized
INFO - 2024-05-19 15:26:57 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-05-19 15:26:57 --> Pagination Class Initialized
INFO - 2024-05-19 15:26:57 --> Form Validation Class Initialized
INFO - 2024-05-19 15:26:57 --> Controller Class Initialized
DEBUG - 2024-05-19 15:26:57 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-05-19 15:26:57 --> Session class already loaded. Second attempt ignored.
INFO - 2024-05-19 15:26:57 --> Model Class Initialized
DEBUG - 2024-05-19 15:26:57 --> Lexpenses class already loaded. Second attempt ignored.
INFO - 2024-05-19 15:26:57 --> Model Class Initialized
INFO - 2024-05-19 15:26:57 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\expenses/expenses.php
DEBUG - 2024-05-19 15:26:57 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-05-19 15:26:57 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\include/top_menu.php
INFO - 2024-05-19 15:26:57 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\include/admin_loggedin_info.php
INFO - 2024-05-19 15:26:57 --> Model Class Initialized
INFO - 2024-05-19 15:26:57 --> Model Class Initialized
INFO - 2024-05-19 15:26:57 --> Model Class Initialized
INFO - 2024-05-19 15:26:58 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\include/admin_header.php
INFO - 2024-05-19 15:26:58 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\include/admin_footer.php
INFO - 2024-05-19 15:26:58 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\admin_html_template.php
INFO - 2024-05-19 15:26:58 --> Final output sent to browser
DEBUG - 2024-05-19 15:26:58 --> Total execution time: 1.3847
ERROR - 2024-05-19 15:26:59 --> $config['composer_autoload'] is set to TRUE but E:\xampp\htdocs\maurnaturo\application\vendor/autoload.php was not found.
INFO - 2024-05-19 15:26:59 --> Config Class Initialized
INFO - 2024-05-19 15:26:59 --> Hooks Class Initialized
DEBUG - 2024-05-19 15:26:59 --> UTF-8 Support Enabled
INFO - 2024-05-19 15:26:59 --> Utf8 Class Initialized
INFO - 2024-05-19 15:26:59 --> URI Class Initialized
INFO - 2024-05-19 15:26:59 --> Router Class Initialized
INFO - 2024-05-19 15:26:59 --> Output Class Initialized
INFO - 2024-05-19 15:26:59 --> Security Class Initialized
DEBUG - 2024-05-19 15:26:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-19 15:26:59 --> Input Class Initialized
INFO - 2024-05-19 15:26:59 --> Language Class Initialized
INFO - 2024-05-19 15:26:59 --> Loader Class Initialized
INFO - 2024-05-19 15:26:59 --> Helper loaded: url_helper
INFO - 2024-05-19 15:26:59 --> Helper loaded: file_helper
INFO - 2024-05-19 15:26:59 --> Helper loaded: html_helper
INFO - 2024-05-19 15:26:59 --> Helper loaded: text_helper
INFO - 2024-05-19 15:26:59 --> Helper loaded: form_helper
INFO - 2024-05-19 15:26:59 --> Helper loaded: lang_helper
INFO - 2024-05-19 15:26:59 --> Helper loaded: security_helper
INFO - 2024-05-19 15:26:59 --> Helper loaded: cookie_helper
INFO - 2024-05-19 15:26:59 --> Database Driver Class Initialized
INFO - 2024-05-19 15:26:59 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-19 15:26:59 --> Parser Class Initialized
INFO - 2024-05-19 15:26:59 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-05-19 15:26:59 --> Pagination Class Initialized
INFO - 2024-05-19 15:26:59 --> Form Validation Class Initialized
INFO - 2024-05-19 15:26:59 --> Controller Class Initialized
DEBUG - 2024-05-19 15:26:59 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-05-19 15:26:59 --> Session class already loaded. Second attempt ignored.
INFO - 2024-05-19 15:26:59 --> Model Class Initialized
INFO - 2024-05-19 15:26:59 --> Final output sent to browser
DEBUG - 2024-05-19 15:26:59 --> Total execution time: 0.2082
ERROR - 2024-05-19 15:27:05 --> $config['composer_autoload'] is set to TRUE but E:\xampp\htdocs\maurnaturo\application\vendor/autoload.php was not found.
INFO - 2024-05-19 15:27:05 --> Config Class Initialized
INFO - 2024-05-19 15:27:05 --> Hooks Class Initialized
DEBUG - 2024-05-19 15:27:05 --> UTF-8 Support Enabled
INFO - 2024-05-19 15:27:05 --> Utf8 Class Initialized
INFO - 2024-05-19 15:27:05 --> URI Class Initialized
INFO - 2024-05-19 15:27:05 --> Router Class Initialized
INFO - 2024-05-19 15:27:05 --> Output Class Initialized
INFO - 2024-05-19 15:27:05 --> Security Class Initialized
DEBUG - 2024-05-19 15:27:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-19 15:27:05 --> Input Class Initialized
INFO - 2024-05-19 15:27:05 --> Language Class Initialized
INFO - 2024-05-19 15:27:05 --> Loader Class Initialized
INFO - 2024-05-19 15:27:05 --> Helper loaded: url_helper
INFO - 2024-05-19 15:27:05 --> Helper loaded: file_helper
INFO - 2024-05-19 15:27:05 --> Helper loaded: html_helper
INFO - 2024-05-19 15:27:05 --> Helper loaded: text_helper
INFO - 2024-05-19 15:27:05 --> Helper loaded: form_helper
INFO - 2024-05-19 15:27:05 --> Helper loaded: lang_helper
INFO - 2024-05-19 15:27:05 --> Helper loaded: security_helper
INFO - 2024-05-19 15:27:05 --> Helper loaded: cookie_helper
INFO - 2024-05-19 15:27:05 --> Database Driver Class Initialized
INFO - 2024-05-19 15:27:05 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-19 15:27:05 --> Parser Class Initialized
INFO - 2024-05-19 15:27:05 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-05-19 15:27:05 --> Pagination Class Initialized
INFO - 2024-05-19 15:27:05 --> Form Validation Class Initialized
INFO - 2024-05-19 15:27:05 --> Controller Class Initialized
DEBUG - 2024-05-19 15:27:05 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-05-19 15:27:05 --> Session class already loaded. Second attempt ignored.
INFO - 2024-05-19 15:27:05 --> Model Class Initialized
INFO - 2024-05-19 15:27:05 --> Model Class Initialized
DEBUG - 2024-05-19 15:27:05 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-05-19 15:27:05 --> Session class already loaded. Second attempt ignored.
INFO - 2024-05-19 15:27:05 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\expenses/add_expenses_form.php
DEBUG - 2024-05-19 15:27:05 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-05-19 15:27:05 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\include/top_menu.php
INFO - 2024-05-19 15:27:05 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\include/admin_loggedin_info.php
INFO - 2024-05-19 15:27:05 --> Model Class Initialized
INFO - 2024-05-19 15:27:05 --> Model Class Initialized
INFO - 2024-05-19 15:27:05 --> Model Class Initialized
INFO - 2024-05-19 15:27:05 --> Model Class Initialized
INFO - 2024-05-19 15:27:06 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\include/admin_header.php
INFO - 2024-05-19 15:27:06 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\include/admin_footer.php
INFO - 2024-05-19 15:27:06 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\admin_html_template.php
INFO - 2024-05-19 15:27:06 --> Final output sent to browser
DEBUG - 2024-05-19 15:27:06 --> Total execution time: 1.1797
ERROR - 2024-05-19 15:27:23 --> $config['composer_autoload'] is set to TRUE but E:\xampp\htdocs\maurnaturo\application\vendor/autoload.php was not found.
INFO - 2024-05-19 15:27:23 --> Config Class Initialized
INFO - 2024-05-19 15:27:23 --> Hooks Class Initialized
DEBUG - 2024-05-19 15:27:23 --> UTF-8 Support Enabled
INFO - 2024-05-19 15:27:23 --> Utf8 Class Initialized
INFO - 2024-05-19 15:27:23 --> URI Class Initialized
INFO - 2024-05-19 15:27:23 --> Router Class Initialized
INFO - 2024-05-19 15:27:23 --> Output Class Initialized
INFO - 2024-05-19 15:27:23 --> Security Class Initialized
DEBUG - 2024-05-19 15:27:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-19 15:27:23 --> Input Class Initialized
INFO - 2024-05-19 15:27:23 --> Language Class Initialized
INFO - 2024-05-19 15:27:23 --> Loader Class Initialized
INFO - 2024-05-19 15:27:23 --> Helper loaded: url_helper
INFO - 2024-05-19 15:27:23 --> Helper loaded: file_helper
INFO - 2024-05-19 15:27:23 --> Helper loaded: html_helper
INFO - 2024-05-19 15:27:23 --> Helper loaded: text_helper
INFO - 2024-05-19 15:27:23 --> Helper loaded: form_helper
INFO - 2024-05-19 15:27:23 --> Helper loaded: lang_helper
INFO - 2024-05-19 15:27:23 --> Helper loaded: security_helper
INFO - 2024-05-19 15:27:23 --> Helper loaded: cookie_helper
INFO - 2024-05-19 15:27:23 --> Database Driver Class Initialized
INFO - 2024-05-19 15:27:23 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-19 15:27:23 --> Parser Class Initialized
INFO - 2024-05-19 15:27:23 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-05-19 15:27:23 --> Pagination Class Initialized
INFO - 2024-05-19 15:27:23 --> Form Validation Class Initialized
INFO - 2024-05-19 15:27:23 --> Controller Class Initialized
DEBUG - 2024-05-19 15:27:23 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-05-19 15:27:23 --> Session class already loaded. Second attempt ignored.
INFO - 2024-05-19 15:27:23 --> Model Class Initialized
INFO - 2024-05-19 15:27:23 --> Final output sent to browser
DEBUG - 2024-05-19 15:27:23 --> Total execution time: 0.1013
ERROR - 2024-05-19 15:27:26 --> $config['composer_autoload'] is set to TRUE but E:\xampp\htdocs\maurnaturo\application\vendor/autoload.php was not found.
INFO - 2024-05-19 15:27:26 --> Config Class Initialized
INFO - 2024-05-19 15:27:26 --> Hooks Class Initialized
DEBUG - 2024-05-19 15:27:26 --> UTF-8 Support Enabled
INFO - 2024-05-19 15:27:26 --> Utf8 Class Initialized
INFO - 2024-05-19 15:27:26 --> URI Class Initialized
INFO - 2024-05-19 15:27:26 --> Router Class Initialized
INFO - 2024-05-19 15:27:26 --> Output Class Initialized
INFO - 2024-05-19 15:27:26 --> Security Class Initialized
DEBUG - 2024-05-19 15:27:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-19 15:27:26 --> Input Class Initialized
INFO - 2024-05-19 15:27:26 --> Language Class Initialized
INFO - 2024-05-19 15:27:26 --> Loader Class Initialized
INFO - 2024-05-19 15:27:26 --> Helper loaded: url_helper
INFO - 2024-05-19 15:27:26 --> Helper loaded: file_helper
INFO - 2024-05-19 15:27:26 --> Helper loaded: html_helper
INFO - 2024-05-19 15:27:26 --> Helper loaded: text_helper
INFO - 2024-05-19 15:27:26 --> Helper loaded: form_helper
INFO - 2024-05-19 15:27:26 --> Helper loaded: lang_helper
INFO - 2024-05-19 15:27:26 --> Helper loaded: security_helper
INFO - 2024-05-19 15:27:26 --> Helper loaded: cookie_helper
INFO - 2024-05-19 15:27:26 --> Database Driver Class Initialized
INFO - 2024-05-19 15:27:26 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-19 15:27:26 --> Parser Class Initialized
INFO - 2024-05-19 15:27:26 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-05-19 15:27:26 --> Pagination Class Initialized
INFO - 2024-05-19 15:27:26 --> Form Validation Class Initialized
INFO - 2024-05-19 15:27:26 --> Controller Class Initialized
DEBUG - 2024-05-19 15:27:26 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-05-19 15:27:26 --> Session class already loaded. Second attempt ignored.
INFO - 2024-05-19 15:27:26 --> Model Class Initialized
INFO - 2024-05-19 15:27:26 --> Model Class Initialized
DEBUG - 2024-05-19 15:27:26 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-05-19 15:27:26 --> Session class already loaded. Second attempt ignored.
INFO - 2024-05-19 15:27:26 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\expenses/add_expenses_form.php
DEBUG - 2024-05-19 15:27:26 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-05-19 15:27:26 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\include/top_menu.php
INFO - 2024-05-19 15:27:26 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\include/admin_loggedin_info.php
INFO - 2024-05-19 15:27:26 --> Model Class Initialized
INFO - 2024-05-19 15:27:26 --> Model Class Initialized
INFO - 2024-05-19 15:27:27 --> Model Class Initialized
INFO - 2024-05-19 15:27:27 --> Model Class Initialized
INFO - 2024-05-19 15:27:28 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\include/admin_header.php
INFO - 2024-05-19 15:27:28 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\include/admin_footer.php
INFO - 2024-05-19 15:27:28 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\admin_html_template.php
INFO - 2024-05-19 15:27:28 --> Final output sent to browser
DEBUG - 2024-05-19 15:27:28 --> Total execution time: 1.1944
ERROR - 2024-05-19 15:27:29 --> $config['composer_autoload'] is set to TRUE but E:\xampp\htdocs\maurnaturo\application\vendor/autoload.php was not found.
INFO - 2024-05-19 15:27:29 --> Config Class Initialized
INFO - 2024-05-19 15:27:29 --> Hooks Class Initialized
DEBUG - 2024-05-19 15:27:29 --> UTF-8 Support Enabled
INFO - 2024-05-19 15:27:29 --> Utf8 Class Initialized
INFO - 2024-05-19 15:27:29 --> URI Class Initialized
INFO - 2024-05-19 15:27:29 --> Router Class Initialized
INFO - 2024-05-19 15:27:29 --> Output Class Initialized
INFO - 2024-05-19 15:27:29 --> Security Class Initialized
DEBUG - 2024-05-19 15:27:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-19 15:27:29 --> Input Class Initialized
INFO - 2024-05-19 15:27:29 --> Language Class Initialized
INFO - 2024-05-19 15:27:29 --> Loader Class Initialized
INFO - 2024-05-19 15:27:30 --> Helper loaded: url_helper
INFO - 2024-05-19 15:27:30 --> Helper loaded: file_helper
INFO - 2024-05-19 15:27:30 --> Helper loaded: html_helper
INFO - 2024-05-19 15:27:30 --> Helper loaded: text_helper
INFO - 2024-05-19 15:27:30 --> Helper loaded: form_helper
INFO - 2024-05-19 15:27:30 --> Helper loaded: lang_helper
INFO - 2024-05-19 15:27:30 --> Helper loaded: security_helper
INFO - 2024-05-19 15:27:30 --> Helper loaded: cookie_helper
INFO - 2024-05-19 15:27:30 --> Database Driver Class Initialized
INFO - 2024-05-19 15:27:30 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-19 15:27:30 --> Parser Class Initialized
INFO - 2024-05-19 15:27:30 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-05-19 15:27:30 --> Pagination Class Initialized
INFO - 2024-05-19 15:27:30 --> Form Validation Class Initialized
INFO - 2024-05-19 15:27:30 --> Controller Class Initialized
DEBUG - 2024-05-19 15:27:30 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-05-19 15:27:30 --> Session class already loaded. Second attempt ignored.
INFO - 2024-05-19 15:27:30 --> Model Class Initialized
DEBUG - 2024-05-19 15:27:30 --> Lexpenses class already loaded. Second attempt ignored.
INFO - 2024-05-19 15:27:30 --> Model Class Initialized
INFO - 2024-05-19 15:27:30 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\expenses/expenses.php
DEBUG - 2024-05-19 15:27:30 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-05-19 15:27:30 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\include/top_menu.php
INFO - 2024-05-19 15:27:30 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\include/admin_loggedin_info.php
INFO - 2024-05-19 15:27:30 --> Model Class Initialized
INFO - 2024-05-19 15:27:30 --> Model Class Initialized
INFO - 2024-05-19 15:27:30 --> Model Class Initialized
INFO - 2024-05-19 15:27:31 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\include/admin_header.php
INFO - 2024-05-19 15:27:31 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\include/admin_footer.php
INFO - 2024-05-19 15:27:31 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\admin_html_template.php
INFO - 2024-05-19 15:27:31 --> Final output sent to browser
DEBUG - 2024-05-19 15:27:31 --> Total execution time: 1.5414
ERROR - 2024-05-19 15:27:31 --> $config['composer_autoload'] is set to TRUE but E:\xampp\htdocs\maurnaturo\application\vendor/autoload.php was not found.
INFO - 2024-05-19 15:27:31 --> Config Class Initialized
INFO - 2024-05-19 15:27:31 --> Hooks Class Initialized
DEBUG - 2024-05-19 15:27:31 --> UTF-8 Support Enabled
INFO - 2024-05-19 15:27:31 --> Utf8 Class Initialized
INFO - 2024-05-19 15:27:31 --> URI Class Initialized
INFO - 2024-05-19 15:27:31 --> Router Class Initialized
INFO - 2024-05-19 15:27:31 --> Output Class Initialized
INFO - 2024-05-19 15:27:31 --> Security Class Initialized
DEBUG - 2024-05-19 15:27:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-19 15:27:31 --> Input Class Initialized
INFO - 2024-05-19 15:27:31 --> Language Class Initialized
INFO - 2024-05-19 15:27:31 --> Loader Class Initialized
INFO - 2024-05-19 15:27:31 --> Helper loaded: url_helper
INFO - 2024-05-19 15:27:31 --> Helper loaded: file_helper
INFO - 2024-05-19 15:27:31 --> Helper loaded: html_helper
INFO - 2024-05-19 15:27:31 --> Helper loaded: text_helper
INFO - 2024-05-19 15:27:31 --> Helper loaded: form_helper
INFO - 2024-05-19 15:27:31 --> Helper loaded: lang_helper
INFO - 2024-05-19 15:27:31 --> Helper loaded: security_helper
INFO - 2024-05-19 15:27:31 --> Helper loaded: cookie_helper
INFO - 2024-05-19 15:27:31 --> Database Driver Class Initialized
INFO - 2024-05-19 15:27:31 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-19 15:27:31 --> Parser Class Initialized
INFO - 2024-05-19 15:27:31 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-05-19 15:27:31 --> Pagination Class Initialized
INFO - 2024-05-19 15:27:31 --> Form Validation Class Initialized
INFO - 2024-05-19 15:27:31 --> Controller Class Initialized
DEBUG - 2024-05-19 15:27:31 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-05-19 15:27:31 --> Session class already loaded. Second attempt ignored.
INFO - 2024-05-19 15:27:31 --> Model Class Initialized
INFO - 2024-05-19 15:27:31 --> Final output sent to browser
DEBUG - 2024-05-19 15:27:31 --> Total execution time: 0.1223
ERROR - 2024-05-19 15:27:38 --> $config['composer_autoload'] is set to TRUE but E:\xampp\htdocs\maurnaturo\application\vendor/autoload.php was not found.
INFO - 2024-05-19 15:27:38 --> Config Class Initialized
INFO - 2024-05-19 15:27:38 --> Hooks Class Initialized
DEBUG - 2024-05-19 15:27:38 --> UTF-8 Support Enabled
INFO - 2024-05-19 15:27:38 --> Utf8 Class Initialized
INFO - 2024-05-19 15:27:38 --> URI Class Initialized
DEBUG - 2024-05-19 15:27:38 --> No URI present. Default controller set.
INFO - 2024-05-19 15:27:38 --> Router Class Initialized
INFO - 2024-05-19 15:27:38 --> Output Class Initialized
INFO - 2024-05-19 15:27:38 --> Security Class Initialized
DEBUG - 2024-05-19 15:27:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-19 15:27:38 --> Input Class Initialized
INFO - 2024-05-19 15:27:38 --> Language Class Initialized
INFO - 2024-05-19 15:27:38 --> Loader Class Initialized
INFO - 2024-05-19 15:27:38 --> Helper loaded: url_helper
INFO - 2024-05-19 15:27:38 --> Helper loaded: file_helper
INFO - 2024-05-19 15:27:38 --> Helper loaded: html_helper
INFO - 2024-05-19 15:27:38 --> Helper loaded: text_helper
INFO - 2024-05-19 15:27:38 --> Helper loaded: form_helper
INFO - 2024-05-19 15:27:38 --> Helper loaded: lang_helper
INFO - 2024-05-19 15:27:38 --> Helper loaded: security_helper
INFO - 2024-05-19 15:27:38 --> Helper loaded: cookie_helper
INFO - 2024-05-19 15:27:38 --> Database Driver Class Initialized
INFO - 2024-05-19 15:27:38 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-19 15:27:38 --> Parser Class Initialized
INFO - 2024-05-19 15:27:38 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-05-19 15:27:38 --> Pagination Class Initialized
INFO - 2024-05-19 15:27:38 --> Form Validation Class Initialized
INFO - 2024-05-19 15:27:38 --> Controller Class Initialized
INFO - 2024-05-19 15:27:38 --> Model Class Initialized
DEBUG - 2024-05-19 15:27:38 --> Session class already loaded. Second attempt ignored.
INFO - 2024-05-19 15:27:38 --> Model Class Initialized
DEBUG - 2024-05-19 15:27:38 --> Session class already loaded. Second attempt ignored.
INFO - 2024-05-19 15:27:38 --> Model Class Initialized
INFO - 2024-05-19 15:27:38 --> Model Class Initialized
INFO - 2024-05-19 15:27:38 --> Model Class Initialized
INFO - 2024-05-19 15:27:38 --> Model Class Initialized
DEBUG - 2024-05-19 15:27:38 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-05-19 15:27:38 --> Session class already loaded. Second attempt ignored.
INFO - 2024-05-19 15:27:38 --> Model Class Initialized
INFO - 2024-05-19 15:27:38 --> Model Class Initialized
INFO - 2024-05-19 15:27:39 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\include/admin_home.php
DEBUG - 2024-05-19 15:27:39 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-05-19 15:27:39 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\include/top_menu.php
INFO - 2024-05-19 15:27:39 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\include/admin_loggedin_info.php
INFO - 2024-05-19 15:27:39 --> Model Class Initialized
INFO - 2024-05-19 15:27:40 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\include/admin_header.php
INFO - 2024-05-19 15:27:40 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\include/admin_footer.php
INFO - 2024-05-19 15:27:40 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\admin_html_template.php
INFO - 2024-05-19 15:27:40 --> Final output sent to browser
DEBUG - 2024-05-19 15:27:40 --> Total execution time: 1.9940
ERROR - 2024-05-19 15:29:36 --> $config['composer_autoload'] is set to TRUE but E:\xampp\htdocs\maurnaturo\application\vendor/autoload.php was not found.
INFO - 2024-05-19 15:29:36 --> Config Class Initialized
INFO - 2024-05-19 15:29:36 --> Hooks Class Initialized
DEBUG - 2024-05-19 15:29:36 --> UTF-8 Support Enabled
INFO - 2024-05-19 15:29:36 --> Utf8 Class Initialized
INFO - 2024-05-19 15:29:36 --> URI Class Initialized
DEBUG - 2024-05-19 15:29:36 --> No URI present. Default controller set.
INFO - 2024-05-19 15:29:36 --> Router Class Initialized
INFO - 2024-05-19 15:29:36 --> Output Class Initialized
INFO - 2024-05-19 15:29:36 --> Security Class Initialized
DEBUG - 2024-05-19 15:29:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-19 15:29:36 --> Input Class Initialized
INFO - 2024-05-19 15:29:36 --> Language Class Initialized
INFO - 2024-05-19 15:29:36 --> Loader Class Initialized
INFO - 2024-05-19 15:29:36 --> Helper loaded: url_helper
INFO - 2024-05-19 15:29:36 --> Helper loaded: file_helper
INFO - 2024-05-19 15:29:36 --> Helper loaded: html_helper
INFO - 2024-05-19 15:29:36 --> Helper loaded: text_helper
INFO - 2024-05-19 15:29:36 --> Helper loaded: form_helper
INFO - 2024-05-19 15:29:36 --> Helper loaded: lang_helper
INFO - 2024-05-19 15:29:36 --> Helper loaded: security_helper
INFO - 2024-05-19 15:29:36 --> Helper loaded: cookie_helper
INFO - 2024-05-19 15:29:36 --> Database Driver Class Initialized
INFO - 2024-05-19 15:29:36 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-19 15:29:36 --> Parser Class Initialized
INFO - 2024-05-19 15:29:36 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-05-19 15:29:36 --> Pagination Class Initialized
INFO - 2024-05-19 15:29:36 --> Form Validation Class Initialized
INFO - 2024-05-19 15:29:36 --> Controller Class Initialized
INFO - 2024-05-19 15:29:36 --> Model Class Initialized
DEBUG - 2024-05-19 15:29:36 --> Session class already loaded. Second attempt ignored.
INFO - 2024-05-19 15:29:36 --> Model Class Initialized
DEBUG - 2024-05-19 15:29:36 --> Session class already loaded. Second attempt ignored.
INFO - 2024-05-19 15:29:36 --> Model Class Initialized
INFO - 2024-05-19 15:29:36 --> Model Class Initialized
INFO - 2024-05-19 15:29:36 --> Model Class Initialized
INFO - 2024-05-19 15:29:36 --> Model Class Initialized
DEBUG - 2024-05-19 15:29:36 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-05-19 15:29:36 --> Session class already loaded. Second attempt ignored.
INFO - 2024-05-19 15:29:36 --> Model Class Initialized
INFO - 2024-05-19 15:29:36 --> Model Class Initialized
INFO - 2024-05-19 15:29:38 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\include/admin_home.php
DEBUG - 2024-05-19 15:29:38 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-05-19 15:29:38 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\include/top_menu.php
INFO - 2024-05-19 15:29:38 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\include/admin_loggedin_info.php
INFO - 2024-05-19 15:29:38 --> Model Class Initialized
INFO - 2024-05-19 15:29:39 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\include/admin_header.php
INFO - 2024-05-19 15:29:39 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\include/admin_footer.php
INFO - 2024-05-19 15:29:39 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\admin_html_template.php
INFO - 2024-05-19 15:29:39 --> Final output sent to browser
DEBUG - 2024-05-19 15:29:39 --> Total execution time: 3.2517
ERROR - 2024-05-19 15:29:43 --> $config['composer_autoload'] is set to TRUE but E:\xampp\htdocs\maurnaturo\application\vendor/autoload.php was not found.
INFO - 2024-05-19 15:29:43 --> Config Class Initialized
INFO - 2024-05-19 15:29:43 --> Hooks Class Initialized
DEBUG - 2024-05-19 15:29:43 --> UTF-8 Support Enabled
INFO - 2024-05-19 15:29:43 --> Utf8 Class Initialized
INFO - 2024-05-19 15:29:43 --> URI Class Initialized
DEBUG - 2024-05-19 15:29:43 --> No URI present. Default controller set.
INFO - 2024-05-19 15:29:43 --> Router Class Initialized
INFO - 2024-05-19 15:29:43 --> Output Class Initialized
INFO - 2024-05-19 15:29:43 --> Security Class Initialized
DEBUG - 2024-05-19 15:29:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-19 15:29:43 --> Input Class Initialized
INFO - 2024-05-19 15:29:43 --> Language Class Initialized
INFO - 2024-05-19 15:29:43 --> Loader Class Initialized
INFO - 2024-05-19 15:29:43 --> Helper loaded: url_helper
INFO - 2024-05-19 15:29:43 --> Helper loaded: file_helper
INFO - 2024-05-19 15:29:43 --> Helper loaded: html_helper
INFO - 2024-05-19 15:29:43 --> Helper loaded: text_helper
INFO - 2024-05-19 15:29:43 --> Helper loaded: form_helper
INFO - 2024-05-19 15:29:43 --> Helper loaded: lang_helper
INFO - 2024-05-19 15:29:43 --> Helper loaded: security_helper
INFO - 2024-05-19 15:29:43 --> Helper loaded: cookie_helper
INFO - 2024-05-19 15:29:43 --> Database Driver Class Initialized
INFO - 2024-05-19 15:29:43 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-19 15:29:43 --> Parser Class Initialized
INFO - 2024-05-19 15:29:43 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-05-19 15:29:43 --> Pagination Class Initialized
INFO - 2024-05-19 15:29:43 --> Form Validation Class Initialized
INFO - 2024-05-19 15:29:43 --> Controller Class Initialized
INFO - 2024-05-19 15:29:43 --> Model Class Initialized
DEBUG - 2024-05-19 15:29:43 --> Session class already loaded. Second attempt ignored.
INFO - 2024-05-19 15:29:43 --> Model Class Initialized
DEBUG - 2024-05-19 15:29:43 --> Session class already loaded. Second attempt ignored.
INFO - 2024-05-19 15:29:43 --> Model Class Initialized
INFO - 2024-05-19 15:29:43 --> Model Class Initialized
INFO - 2024-05-19 15:29:43 --> Model Class Initialized
INFO - 2024-05-19 15:29:43 --> Model Class Initialized
DEBUG - 2024-05-19 15:29:43 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-05-19 15:29:43 --> Session class already loaded. Second attempt ignored.
INFO - 2024-05-19 15:29:43 --> Model Class Initialized
INFO - 2024-05-19 15:29:43 --> Model Class Initialized
INFO - 2024-05-19 15:29:44 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\include/admin_home.php
DEBUG - 2024-05-19 15:29:44 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-05-19 15:29:44 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\include/top_menu.php
INFO - 2024-05-19 15:29:44 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\include/admin_loggedin_info.php
INFO - 2024-05-19 15:29:44 --> Model Class Initialized
INFO - 2024-05-19 15:29:45 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\include/admin_header.php
INFO - 2024-05-19 15:29:45 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\include/admin_footer.php
INFO - 2024-05-19 15:29:45 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\admin_html_template.php
INFO - 2024-05-19 15:29:45 --> Final output sent to browser
DEBUG - 2024-05-19 15:29:45 --> Total execution time: 1.9911
ERROR - 2024-05-19 15:33:31 --> $config['composer_autoload'] is set to TRUE but E:\xampp\htdocs\maurnaturo\application\vendor/autoload.php was not found.
INFO - 2024-05-19 15:33:31 --> Config Class Initialized
INFO - 2024-05-19 15:33:31 --> Hooks Class Initialized
DEBUG - 2024-05-19 15:33:31 --> UTF-8 Support Enabled
INFO - 2024-05-19 15:33:31 --> Utf8 Class Initialized
INFO - 2024-05-19 15:33:31 --> URI Class Initialized
DEBUG - 2024-05-19 15:33:31 --> No URI present. Default controller set.
INFO - 2024-05-19 15:33:31 --> Router Class Initialized
INFO - 2024-05-19 15:33:31 --> Output Class Initialized
INFO - 2024-05-19 15:33:31 --> Security Class Initialized
DEBUG - 2024-05-19 15:33:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-19 15:33:31 --> Input Class Initialized
INFO - 2024-05-19 15:33:31 --> Language Class Initialized
INFO - 2024-05-19 15:33:31 --> Loader Class Initialized
INFO - 2024-05-19 15:33:31 --> Helper loaded: url_helper
INFO - 2024-05-19 15:33:31 --> Helper loaded: file_helper
INFO - 2024-05-19 15:33:31 --> Helper loaded: html_helper
INFO - 2024-05-19 15:33:31 --> Helper loaded: text_helper
INFO - 2024-05-19 15:33:31 --> Helper loaded: form_helper
INFO - 2024-05-19 15:33:31 --> Helper loaded: lang_helper
INFO - 2024-05-19 15:33:31 --> Helper loaded: security_helper
INFO - 2024-05-19 15:33:31 --> Helper loaded: cookie_helper
INFO - 2024-05-19 15:33:31 --> Database Driver Class Initialized
INFO - 2024-05-19 15:33:31 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-19 15:33:31 --> Parser Class Initialized
INFO - 2024-05-19 15:33:31 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-05-19 15:33:31 --> Pagination Class Initialized
INFO - 2024-05-19 15:33:31 --> Form Validation Class Initialized
INFO - 2024-05-19 15:33:31 --> Controller Class Initialized
INFO - 2024-05-19 15:33:31 --> Model Class Initialized
DEBUG - 2024-05-19 15:33:31 --> Session class already loaded. Second attempt ignored.
INFO - 2024-05-19 15:33:31 --> Model Class Initialized
DEBUG - 2024-05-19 15:33:31 --> Session class already loaded. Second attempt ignored.
INFO - 2024-05-19 15:33:31 --> Model Class Initialized
INFO - 2024-05-19 15:33:31 --> Model Class Initialized
INFO - 2024-05-19 15:33:31 --> Model Class Initialized
INFO - 2024-05-19 15:33:31 --> Model Class Initialized
DEBUG - 2024-05-19 15:33:31 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-05-19 15:33:31 --> Session class already loaded. Second attempt ignored.
INFO - 2024-05-19 15:33:31 --> Model Class Initialized
INFO - 2024-05-19 15:33:31 --> Model Class Initialized
INFO - 2024-05-19 15:33:33 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\include/admin_home.php
DEBUG - 2024-05-19 15:33:33 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-05-19 15:33:33 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\include/top_menu.php
INFO - 2024-05-19 15:33:33 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\include/admin_loggedin_info.php
INFO - 2024-05-19 15:33:33 --> Model Class Initialized
INFO - 2024-05-19 15:33:34 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\include/admin_header.php
INFO - 2024-05-19 15:33:34 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\include/admin_footer.php
INFO - 2024-05-19 15:33:34 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\admin_html_template.php
INFO - 2024-05-19 15:33:34 --> Final output sent to browser
DEBUG - 2024-05-19 15:33:34 --> Total execution time: 2.8319
ERROR - 2024-05-19 15:34:05 --> $config['composer_autoload'] is set to TRUE but E:\xampp\htdocs\maurnaturo\application\vendor/autoload.php was not found.
INFO - 2024-05-19 15:34:05 --> Config Class Initialized
INFO - 2024-05-19 15:34:05 --> Hooks Class Initialized
DEBUG - 2024-05-19 15:34:05 --> UTF-8 Support Enabled
INFO - 2024-05-19 15:34:05 --> Utf8 Class Initialized
INFO - 2024-05-19 15:34:05 --> URI Class Initialized
DEBUG - 2024-05-19 15:34:05 --> No URI present. Default controller set.
INFO - 2024-05-19 15:34:05 --> Router Class Initialized
INFO - 2024-05-19 15:34:05 --> Output Class Initialized
INFO - 2024-05-19 15:34:05 --> Security Class Initialized
DEBUG - 2024-05-19 15:34:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-19 15:34:05 --> Input Class Initialized
INFO - 2024-05-19 15:34:05 --> Language Class Initialized
INFO - 2024-05-19 15:34:05 --> Loader Class Initialized
INFO - 2024-05-19 15:34:05 --> Helper loaded: url_helper
INFO - 2024-05-19 15:34:05 --> Helper loaded: file_helper
INFO - 2024-05-19 15:34:05 --> Helper loaded: html_helper
INFO - 2024-05-19 15:34:05 --> Helper loaded: text_helper
INFO - 2024-05-19 15:34:05 --> Helper loaded: form_helper
INFO - 2024-05-19 15:34:05 --> Helper loaded: lang_helper
INFO - 2024-05-19 15:34:05 --> Helper loaded: security_helper
INFO - 2024-05-19 15:34:05 --> Helper loaded: cookie_helper
INFO - 2024-05-19 15:34:05 --> Database Driver Class Initialized
INFO - 2024-05-19 15:34:05 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-19 15:34:05 --> Parser Class Initialized
INFO - 2024-05-19 15:34:05 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-05-19 15:34:05 --> Pagination Class Initialized
INFO - 2024-05-19 15:34:05 --> Form Validation Class Initialized
INFO - 2024-05-19 15:34:05 --> Controller Class Initialized
INFO - 2024-05-19 15:34:05 --> Model Class Initialized
DEBUG - 2024-05-19 15:34:05 --> Session class already loaded. Second attempt ignored.
INFO - 2024-05-19 15:34:05 --> Model Class Initialized
DEBUG - 2024-05-19 15:34:05 --> Session class already loaded. Second attempt ignored.
INFO - 2024-05-19 15:34:05 --> Model Class Initialized
INFO - 2024-05-19 15:34:05 --> Model Class Initialized
INFO - 2024-05-19 15:34:05 --> Model Class Initialized
INFO - 2024-05-19 15:34:05 --> Model Class Initialized
DEBUG - 2024-05-19 15:34:05 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-05-19 15:34:05 --> Session class already loaded. Second attempt ignored.
INFO - 2024-05-19 15:34:05 --> Model Class Initialized
INFO - 2024-05-19 15:34:05 --> Model Class Initialized
INFO - 2024-05-19 15:34:06 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\include/admin_home.php
DEBUG - 2024-05-19 15:34:06 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-05-19 15:34:06 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\include/top_menu.php
INFO - 2024-05-19 15:34:06 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\include/admin_loggedin_info.php
INFO - 2024-05-19 15:34:06 --> Model Class Initialized
INFO - 2024-05-19 15:34:07 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\include/admin_header.php
INFO - 2024-05-19 15:34:07 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\include/admin_footer.php
INFO - 2024-05-19 15:34:07 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\admin_html_template.php
INFO - 2024-05-19 15:34:07 --> Final output sent to browser
DEBUG - 2024-05-19 15:34:07 --> Total execution time: 2.1174
ERROR - 2024-05-19 15:34:23 --> $config['composer_autoload'] is set to TRUE but E:\xampp\htdocs\maurnaturo\application\vendor/autoload.php was not found.
INFO - 2024-05-19 15:34:23 --> Config Class Initialized
INFO - 2024-05-19 15:34:23 --> Hooks Class Initialized
DEBUG - 2024-05-19 15:34:23 --> UTF-8 Support Enabled
INFO - 2024-05-19 15:34:23 --> Utf8 Class Initialized
INFO - 2024-05-19 15:34:23 --> URI Class Initialized
DEBUG - 2024-05-19 15:34:23 --> No URI present. Default controller set.
INFO - 2024-05-19 15:34:23 --> Router Class Initialized
INFO - 2024-05-19 15:34:23 --> Output Class Initialized
INFO - 2024-05-19 15:34:23 --> Security Class Initialized
DEBUG - 2024-05-19 15:34:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-19 15:34:23 --> Input Class Initialized
INFO - 2024-05-19 15:34:23 --> Language Class Initialized
INFO - 2024-05-19 15:34:23 --> Loader Class Initialized
INFO - 2024-05-19 15:34:23 --> Helper loaded: url_helper
INFO - 2024-05-19 15:34:23 --> Helper loaded: file_helper
INFO - 2024-05-19 15:34:23 --> Helper loaded: html_helper
INFO - 2024-05-19 15:34:23 --> Helper loaded: text_helper
INFO - 2024-05-19 15:34:23 --> Helper loaded: form_helper
INFO - 2024-05-19 15:34:23 --> Helper loaded: lang_helper
INFO - 2024-05-19 15:34:23 --> Helper loaded: security_helper
INFO - 2024-05-19 15:34:23 --> Helper loaded: cookie_helper
INFO - 2024-05-19 15:34:23 --> Database Driver Class Initialized
INFO - 2024-05-19 15:34:23 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-19 15:34:23 --> Parser Class Initialized
INFO - 2024-05-19 15:34:23 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-05-19 15:34:23 --> Pagination Class Initialized
INFO - 2024-05-19 15:34:23 --> Form Validation Class Initialized
INFO - 2024-05-19 15:34:23 --> Controller Class Initialized
INFO - 2024-05-19 15:34:23 --> Model Class Initialized
DEBUG - 2024-05-19 15:34:23 --> Session class already loaded. Second attempt ignored.
INFO - 2024-05-19 15:34:23 --> Model Class Initialized
DEBUG - 2024-05-19 15:34:23 --> Session class already loaded. Second attempt ignored.
INFO - 2024-05-19 15:34:23 --> Model Class Initialized
INFO - 2024-05-19 15:34:23 --> Model Class Initialized
INFO - 2024-05-19 15:34:23 --> Model Class Initialized
INFO - 2024-05-19 15:34:23 --> Model Class Initialized
DEBUG - 2024-05-19 15:34:23 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-05-19 15:34:23 --> Session class already loaded. Second attempt ignored.
INFO - 2024-05-19 15:34:23 --> Model Class Initialized
INFO - 2024-05-19 15:34:23 --> Model Class Initialized
INFO - 2024-05-19 15:34:25 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\include/admin_home.php
DEBUG - 2024-05-19 15:34:25 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-05-19 15:34:25 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\include/top_menu.php
INFO - 2024-05-19 15:34:25 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\include/admin_loggedin_info.php
INFO - 2024-05-19 15:34:25 --> Model Class Initialized
INFO - 2024-05-19 15:34:26 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\include/admin_header.php
INFO - 2024-05-19 15:34:26 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\include/admin_footer.php
INFO - 2024-05-19 15:34:26 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\admin_html_template.php
INFO - 2024-05-19 15:34:26 --> Final output sent to browser
DEBUG - 2024-05-19 15:34:26 --> Total execution time: 2.5323
ERROR - 2024-05-19 15:35:27 --> $config['composer_autoload'] is set to TRUE but E:\xampp\htdocs\maurnaturo\application\vendor/autoload.php was not found.
INFO - 2024-05-19 15:35:27 --> Config Class Initialized
INFO - 2024-05-19 15:35:27 --> Hooks Class Initialized
DEBUG - 2024-05-19 15:35:27 --> UTF-8 Support Enabled
INFO - 2024-05-19 15:35:27 --> Utf8 Class Initialized
INFO - 2024-05-19 15:35:28 --> URI Class Initialized
INFO - 2024-05-19 15:35:28 --> Router Class Initialized
INFO - 2024-05-19 15:35:28 --> Output Class Initialized
INFO - 2024-05-19 15:35:28 --> Security Class Initialized
DEBUG - 2024-05-19 15:35:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-19 15:35:28 --> Input Class Initialized
INFO - 2024-05-19 15:35:28 --> Language Class Initialized
INFO - 2024-05-19 15:35:28 --> Loader Class Initialized
INFO - 2024-05-19 15:35:28 --> Helper loaded: url_helper
INFO - 2024-05-19 15:35:28 --> Helper loaded: file_helper
INFO - 2024-05-19 15:35:28 --> Helper loaded: html_helper
INFO - 2024-05-19 15:35:28 --> Helper loaded: text_helper
INFO - 2024-05-19 15:35:28 --> Helper loaded: form_helper
INFO - 2024-05-19 15:35:28 --> Helper loaded: lang_helper
INFO - 2024-05-19 15:35:28 --> Helper loaded: security_helper
INFO - 2024-05-19 15:35:28 --> Helper loaded: cookie_helper
INFO - 2024-05-19 15:35:28 --> Database Driver Class Initialized
INFO - 2024-05-19 15:35:28 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-19 15:35:28 --> Parser Class Initialized
INFO - 2024-05-19 15:35:28 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-05-19 15:35:28 --> Pagination Class Initialized
INFO - 2024-05-19 15:35:28 --> Form Validation Class Initialized
INFO - 2024-05-19 15:35:28 --> Controller Class Initialized
DEBUG - 2024-05-19 15:35:28 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-05-19 15:35:28 --> Session class already loaded. Second attempt ignored.
INFO - 2024-05-19 15:35:28 --> Model Class Initialized
DEBUG - 2024-05-19 15:35:28 --> Lpayments class already loaded. Second attempt ignored.
INFO - 2024-05-19 15:35:28 --> Model Class Initialized
INFO - 2024-05-19 15:35:28 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\payments/payment.php
DEBUG - 2024-05-19 15:35:28 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-05-19 15:35:28 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\include/top_menu.php
INFO - 2024-05-19 15:35:28 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\include/admin_loggedin_info.php
INFO - 2024-05-19 15:35:28 --> Model Class Initialized
INFO - 2024-05-19 15:35:28 --> Model Class Initialized
INFO - 2024-05-19 15:35:28 --> Model Class Initialized
INFO - 2024-05-19 15:35:29 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\include/admin_header.php
INFO - 2024-05-19 15:35:29 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\include/admin_footer.php
INFO - 2024-05-19 15:35:29 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\admin_html_template.php
INFO - 2024-05-19 15:35:29 --> Final output sent to browser
DEBUG - 2024-05-19 15:35:29 --> Total execution time: 1.4056
ERROR - 2024-05-19 15:35:29 --> $config['composer_autoload'] is set to TRUE but E:\xampp\htdocs\maurnaturo\application\vendor/autoload.php was not found.
INFO - 2024-05-19 15:35:29 --> Config Class Initialized
INFO - 2024-05-19 15:35:29 --> Hooks Class Initialized
DEBUG - 2024-05-19 15:35:29 --> UTF-8 Support Enabled
INFO - 2024-05-19 15:35:29 --> Utf8 Class Initialized
INFO - 2024-05-19 15:35:29 --> URI Class Initialized
INFO - 2024-05-19 15:35:29 --> Router Class Initialized
INFO - 2024-05-19 15:35:29 --> Output Class Initialized
INFO - 2024-05-19 15:35:29 --> Security Class Initialized
DEBUG - 2024-05-19 15:35:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-19 15:35:29 --> Input Class Initialized
INFO - 2024-05-19 15:35:29 --> Language Class Initialized
INFO - 2024-05-19 15:35:29 --> Loader Class Initialized
INFO - 2024-05-19 15:35:29 --> Helper loaded: url_helper
INFO - 2024-05-19 15:35:29 --> Helper loaded: file_helper
INFO - 2024-05-19 15:35:29 --> Helper loaded: html_helper
INFO - 2024-05-19 15:35:29 --> Helper loaded: text_helper
INFO - 2024-05-19 15:35:29 --> Helper loaded: form_helper
INFO - 2024-05-19 15:35:29 --> Helper loaded: lang_helper
INFO - 2024-05-19 15:35:29 --> Helper loaded: security_helper
INFO - 2024-05-19 15:35:29 --> Helper loaded: cookie_helper
INFO - 2024-05-19 15:35:29 --> Database Driver Class Initialized
INFO - 2024-05-19 15:35:29 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-19 15:35:29 --> Parser Class Initialized
INFO - 2024-05-19 15:35:29 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-05-19 15:35:29 --> Pagination Class Initialized
INFO - 2024-05-19 15:35:29 --> Form Validation Class Initialized
INFO - 2024-05-19 15:35:29 --> Controller Class Initialized
DEBUG - 2024-05-19 15:35:29 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-05-19 15:35:29 --> Session class already loaded. Second attempt ignored.
INFO - 2024-05-19 15:35:29 --> Model Class Initialized
INFO - 2024-05-19 15:35:29 --> Final output sent to browser
DEBUG - 2024-05-19 15:35:29 --> Total execution time: 0.1057
ERROR - 2024-05-19 15:50:31 --> $config['composer_autoload'] is set to TRUE but E:\xampp\htdocs\maurnaturo\application\vendor/autoload.php was not found.
INFO - 2024-05-19 15:50:31 --> Config Class Initialized
INFO - 2024-05-19 15:50:31 --> Hooks Class Initialized
DEBUG - 2024-05-19 15:50:31 --> UTF-8 Support Enabled
INFO - 2024-05-19 15:50:31 --> Utf8 Class Initialized
INFO - 2024-05-19 15:50:31 --> URI Class Initialized
INFO - 2024-05-19 15:50:31 --> Router Class Initialized
INFO - 2024-05-19 15:50:31 --> Output Class Initialized
INFO - 2024-05-19 15:50:31 --> Security Class Initialized
DEBUG - 2024-05-19 15:50:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-19 15:50:31 --> Input Class Initialized
INFO - 2024-05-19 15:50:31 --> Language Class Initialized
INFO - 2024-05-19 15:50:31 --> Loader Class Initialized
INFO - 2024-05-19 15:50:31 --> Helper loaded: url_helper
INFO - 2024-05-19 15:50:31 --> Helper loaded: file_helper
INFO - 2024-05-19 15:50:31 --> Helper loaded: html_helper
INFO - 2024-05-19 15:50:31 --> Helper loaded: text_helper
INFO - 2024-05-19 15:50:31 --> Helper loaded: form_helper
INFO - 2024-05-19 15:50:31 --> Helper loaded: lang_helper
INFO - 2024-05-19 15:50:31 --> Helper loaded: security_helper
INFO - 2024-05-19 15:50:31 --> Helper loaded: cookie_helper
INFO - 2024-05-19 15:50:31 --> Database Driver Class Initialized
INFO - 2024-05-19 15:50:31 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-19 15:50:31 --> Parser Class Initialized
INFO - 2024-05-19 15:50:31 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-05-19 15:50:31 --> Pagination Class Initialized
INFO - 2024-05-19 15:50:31 --> Form Validation Class Initialized
INFO - 2024-05-19 15:50:31 --> Controller Class Initialized
DEBUG - 2024-05-19 15:50:31 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-05-19 15:50:31 --> Session class already loaded. Second attempt ignored.
INFO - 2024-05-19 15:50:31 --> Model Class Initialized
INFO - 2024-05-19 15:50:31 --> Model Class Initialized
DEBUG - 2024-05-19 15:50:31 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-05-19 15:50:31 --> Session class already loaded. Second attempt ignored.
INFO - 2024-05-19 15:50:31 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\payments/add_payment_form.php
DEBUG - 2024-05-19 15:50:31 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-05-19 15:50:31 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\include/top_menu.php
INFO - 2024-05-19 15:50:31 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\include/admin_loggedin_info.php
INFO - 2024-05-19 15:50:32 --> Model Class Initialized
INFO - 2024-05-19 15:50:32 --> Model Class Initialized
INFO - 2024-05-19 15:50:32 --> Model Class Initialized
INFO - 2024-05-19 15:50:32 --> Model Class Initialized
INFO - 2024-05-19 15:50:33 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\include/admin_header.php
INFO - 2024-05-19 15:50:33 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\include/admin_footer.php
INFO - 2024-05-19 15:50:33 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\admin_html_template.php
INFO - 2024-05-19 15:50:33 --> Final output sent to browser
DEBUG - 2024-05-19 15:50:33 --> Total execution time: 1.2023
ERROR - 2024-05-19 15:50:39 --> $config['composer_autoload'] is set to TRUE but E:\xampp\htdocs\maurnaturo\application\vendor/autoload.php was not found.
INFO - 2024-05-19 15:50:39 --> Config Class Initialized
INFO - 2024-05-19 15:50:39 --> Hooks Class Initialized
DEBUG - 2024-05-19 15:50:39 --> UTF-8 Support Enabled
INFO - 2024-05-19 15:50:39 --> Utf8 Class Initialized
INFO - 2024-05-19 15:50:39 --> URI Class Initialized
INFO - 2024-05-19 15:50:39 --> Router Class Initialized
INFO - 2024-05-19 15:50:39 --> Output Class Initialized
INFO - 2024-05-19 15:50:39 --> Security Class Initialized
DEBUG - 2024-05-19 15:50:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-19 15:50:39 --> Input Class Initialized
INFO - 2024-05-19 15:50:39 --> Language Class Initialized
INFO - 2024-05-19 15:50:39 --> Loader Class Initialized
INFO - 2024-05-19 15:50:39 --> Helper loaded: url_helper
INFO - 2024-05-19 15:50:39 --> Helper loaded: file_helper
INFO - 2024-05-19 15:50:39 --> Helper loaded: html_helper
INFO - 2024-05-19 15:50:39 --> Helper loaded: text_helper
INFO - 2024-05-19 15:50:39 --> Helper loaded: form_helper
INFO - 2024-05-19 15:50:39 --> Helper loaded: lang_helper
INFO - 2024-05-19 15:50:39 --> Helper loaded: security_helper
INFO - 2024-05-19 15:50:39 --> Helper loaded: cookie_helper
INFO - 2024-05-19 15:50:39 --> Database Driver Class Initialized
INFO - 2024-05-19 15:50:39 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-19 15:50:39 --> Parser Class Initialized
INFO - 2024-05-19 15:50:39 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-05-19 15:50:39 --> Pagination Class Initialized
INFO - 2024-05-19 15:50:39 --> Form Validation Class Initialized
INFO - 2024-05-19 15:50:39 --> Controller Class Initialized
INFO - 2024-05-19 15:50:39 --> Model Class Initialized
DEBUG - 2024-05-19 15:50:39 --> Session class already loaded. Second attempt ignored.
INFO - 2024-05-19 15:50:39 --> Final output sent to browser
DEBUG - 2024-05-19 15:50:39 --> Total execution time: 0.1145
ERROR - 2024-05-19 15:50:39 --> $config['composer_autoload'] is set to TRUE but E:\xampp\htdocs\maurnaturo\application\vendor/autoload.php was not found.
INFO - 2024-05-19 15:50:39 --> Config Class Initialized
INFO - 2024-05-19 15:50:39 --> Hooks Class Initialized
DEBUG - 2024-05-19 15:50:39 --> UTF-8 Support Enabled
INFO - 2024-05-19 15:50:39 --> Utf8 Class Initialized
INFO - 2024-05-19 15:50:39 --> URI Class Initialized
INFO - 2024-05-19 15:50:39 --> Router Class Initialized
INFO - 2024-05-19 15:50:39 --> Output Class Initialized
INFO - 2024-05-19 15:50:39 --> Security Class Initialized
DEBUG - 2024-05-19 15:50:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-19 15:50:39 --> Input Class Initialized
INFO - 2024-05-19 15:50:39 --> Language Class Initialized
INFO - 2024-05-19 15:50:39 --> Loader Class Initialized
INFO - 2024-05-19 15:50:39 --> Helper loaded: url_helper
INFO - 2024-05-19 15:50:39 --> Helper loaded: file_helper
INFO - 2024-05-19 15:50:39 --> Helper loaded: html_helper
INFO - 2024-05-19 15:50:39 --> Helper loaded: text_helper
INFO - 2024-05-19 15:50:39 --> Helper loaded: form_helper
INFO - 2024-05-19 15:50:39 --> Helper loaded: lang_helper
INFO - 2024-05-19 15:50:39 --> Helper loaded: security_helper
INFO - 2024-05-19 15:50:39 --> Helper loaded: cookie_helper
INFO - 2024-05-19 15:50:39 --> Database Driver Class Initialized
INFO - 2024-05-19 15:50:39 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-19 15:50:39 --> Parser Class Initialized
INFO - 2024-05-19 15:50:39 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-05-19 15:50:39 --> Pagination Class Initialized
INFO - 2024-05-19 15:50:39 --> Form Validation Class Initialized
INFO - 2024-05-19 15:50:39 --> Controller Class Initialized
INFO - 2024-05-19 15:50:39 --> Model Class Initialized
DEBUG - 2024-05-19 15:50:39 --> Session class already loaded. Second attempt ignored.
ERROR - 2024-05-19 15:50:39 --> Severity: Warning --> Invalid argument supplied for foreach() E:\xampp\htdocs\maurnaturo\application\controllers\Cinvoice.php 616
INFO - 2024-05-19 15:50:39 --> Final output sent to browser
DEBUG - 2024-05-19 15:50:39 --> Total execution time: 0.0624
ERROR - 2024-05-19 15:50:41 --> $config['composer_autoload'] is set to TRUE but E:\xampp\htdocs\maurnaturo\application\vendor/autoload.php was not found.
INFO - 2024-05-19 15:50:41 --> Config Class Initialized
INFO - 2024-05-19 15:50:41 --> Hooks Class Initialized
DEBUG - 2024-05-19 15:50:41 --> UTF-8 Support Enabled
INFO - 2024-05-19 15:50:41 --> Utf8 Class Initialized
INFO - 2024-05-19 15:50:41 --> URI Class Initialized
INFO - 2024-05-19 15:50:41 --> Router Class Initialized
INFO - 2024-05-19 15:50:41 --> Output Class Initialized
INFO - 2024-05-19 15:50:41 --> Security Class Initialized
DEBUG - 2024-05-19 15:50:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-19 15:50:41 --> Input Class Initialized
INFO - 2024-05-19 15:50:41 --> Language Class Initialized
INFO - 2024-05-19 15:50:41 --> Loader Class Initialized
INFO - 2024-05-19 15:50:41 --> Helper loaded: url_helper
INFO - 2024-05-19 15:50:41 --> Helper loaded: file_helper
INFO - 2024-05-19 15:50:41 --> Helper loaded: html_helper
INFO - 2024-05-19 15:50:41 --> Helper loaded: text_helper
INFO - 2024-05-19 15:50:41 --> Helper loaded: form_helper
INFO - 2024-05-19 15:50:41 --> Helper loaded: lang_helper
INFO - 2024-05-19 15:50:41 --> Helper loaded: security_helper
INFO - 2024-05-19 15:50:41 --> Helper loaded: cookie_helper
INFO - 2024-05-19 15:50:41 --> Database Driver Class Initialized
INFO - 2024-05-19 15:50:41 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-19 15:50:41 --> Parser Class Initialized
INFO - 2024-05-19 15:50:41 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-05-19 15:50:41 --> Pagination Class Initialized
INFO - 2024-05-19 15:50:41 --> Form Validation Class Initialized
INFO - 2024-05-19 15:50:41 --> Controller Class Initialized
INFO - 2024-05-19 15:50:41 --> Model Class Initialized
DEBUG - 2024-05-19 15:50:41 --> Session class already loaded. Second attempt ignored.
INFO - 2024-05-19 15:50:41 --> Final output sent to browser
DEBUG - 2024-05-19 15:50:41 --> Total execution time: 0.0619
ERROR - 2024-05-19 15:50:56 --> $config['composer_autoload'] is set to TRUE but E:\xampp\htdocs\maurnaturo\application\vendor/autoload.php was not found.
INFO - 2024-05-19 15:50:56 --> Config Class Initialized
INFO - 2024-05-19 15:50:56 --> Hooks Class Initialized
DEBUG - 2024-05-19 15:50:56 --> UTF-8 Support Enabled
INFO - 2024-05-19 15:50:56 --> Utf8 Class Initialized
INFO - 2024-05-19 15:50:56 --> URI Class Initialized
INFO - 2024-05-19 15:50:56 --> Router Class Initialized
INFO - 2024-05-19 15:50:56 --> Output Class Initialized
INFO - 2024-05-19 15:50:56 --> Security Class Initialized
DEBUG - 2024-05-19 15:50:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-19 15:50:56 --> Input Class Initialized
INFO - 2024-05-19 15:50:56 --> Language Class Initialized
INFO - 2024-05-19 15:50:56 --> Loader Class Initialized
INFO - 2024-05-19 15:50:56 --> Helper loaded: url_helper
INFO - 2024-05-19 15:50:56 --> Helper loaded: file_helper
INFO - 2024-05-19 15:50:56 --> Helper loaded: html_helper
INFO - 2024-05-19 15:50:56 --> Helper loaded: text_helper
INFO - 2024-05-19 15:50:56 --> Helper loaded: form_helper
INFO - 2024-05-19 15:50:56 --> Helper loaded: lang_helper
INFO - 2024-05-19 15:50:56 --> Helper loaded: security_helper
INFO - 2024-05-19 15:50:56 --> Helper loaded: cookie_helper
INFO - 2024-05-19 15:50:56 --> Database Driver Class Initialized
INFO - 2024-05-19 15:50:56 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-19 15:50:56 --> Parser Class Initialized
INFO - 2024-05-19 15:50:56 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-05-19 15:50:56 --> Pagination Class Initialized
INFO - 2024-05-19 15:50:56 --> Form Validation Class Initialized
INFO - 2024-05-19 15:50:56 --> Controller Class Initialized
DEBUG - 2024-05-19 15:50:56 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-05-19 15:50:56 --> Session class already loaded. Second attempt ignored.
INFO - 2024-05-19 15:50:56 --> Model Class Initialized
ERROR - 2024-05-19 15:50:56 --> Severity: Warning --> Use of undefined constant dts - assumed 'dts' (this will throw an Error in a future version of PHP) E:\xampp\htdocs\maurnaturo\application\controllers\Cpayments.php 60
ERROR - 2024-05-19 15:50:56 --> Severity: Warning --> Illegal string offset 'user_id' E:\xampp\htdocs\maurnaturo\application\controllers\Cpayments.php 60
INFO - 2024-05-19 15:50:56 --> Final output sent to browser
DEBUG - 2024-05-19 15:50:56 --> Total execution time: 0.0869
ERROR - 2024-05-19 15:50:59 --> $config['composer_autoload'] is set to TRUE but E:\xampp\htdocs\maurnaturo\application\vendor/autoload.php was not found.
INFO - 2024-05-19 15:50:59 --> Config Class Initialized
INFO - 2024-05-19 15:50:59 --> Hooks Class Initialized
DEBUG - 2024-05-19 15:50:59 --> UTF-8 Support Enabled
INFO - 2024-05-19 15:50:59 --> Utf8 Class Initialized
INFO - 2024-05-19 15:50:59 --> URI Class Initialized
INFO - 2024-05-19 15:50:59 --> Router Class Initialized
INFO - 2024-05-19 15:50:59 --> Output Class Initialized
INFO - 2024-05-19 15:50:59 --> Security Class Initialized
DEBUG - 2024-05-19 15:50:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-19 15:50:59 --> Input Class Initialized
INFO - 2024-05-19 15:50:59 --> Language Class Initialized
INFO - 2024-05-19 15:50:59 --> Loader Class Initialized
INFO - 2024-05-19 15:50:59 --> Helper loaded: url_helper
INFO - 2024-05-19 15:50:59 --> Helper loaded: file_helper
INFO - 2024-05-19 15:50:59 --> Helper loaded: html_helper
INFO - 2024-05-19 15:50:59 --> Helper loaded: text_helper
INFO - 2024-05-19 15:50:59 --> Helper loaded: form_helper
INFO - 2024-05-19 15:50:59 --> Helper loaded: lang_helper
INFO - 2024-05-19 15:50:59 --> Helper loaded: security_helper
INFO - 2024-05-19 15:50:59 --> Helper loaded: cookie_helper
INFO - 2024-05-19 15:50:59 --> Database Driver Class Initialized
INFO - 2024-05-19 15:50:59 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-19 15:50:59 --> Parser Class Initialized
INFO - 2024-05-19 15:50:59 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-05-19 15:50:59 --> Pagination Class Initialized
INFO - 2024-05-19 15:50:59 --> Form Validation Class Initialized
INFO - 2024-05-19 15:50:59 --> Controller Class Initialized
DEBUG - 2024-05-19 15:50:59 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-05-19 15:50:59 --> Session class already loaded. Second attempt ignored.
INFO - 2024-05-19 15:50:59 --> Model Class Initialized
INFO - 2024-05-19 15:50:59 --> Model Class Initialized
DEBUG - 2024-05-19 15:50:59 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-05-19 15:50:59 --> Session class already loaded. Second attempt ignored.
INFO - 2024-05-19 15:50:59 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\payments/add_payment_form.php
DEBUG - 2024-05-19 15:50:59 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-05-19 15:50:59 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\include/top_menu.php
INFO - 2024-05-19 15:50:59 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\include/admin_loggedin_info.php
INFO - 2024-05-19 15:50:59 --> Model Class Initialized
INFO - 2024-05-19 15:50:59 --> Model Class Initialized
INFO - 2024-05-19 15:50:59 --> Model Class Initialized
INFO - 2024-05-19 15:50:59 --> Model Class Initialized
INFO - 2024-05-19 15:51:00 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\include/admin_header.php
INFO - 2024-05-19 15:51:00 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\include/admin_footer.php
INFO - 2024-05-19 15:51:00 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\admin_html_template.php
INFO - 2024-05-19 15:51:00 --> Final output sent to browser
DEBUG - 2024-05-19 15:51:00 --> Total execution time: 1.4067
ERROR - 2024-05-19 15:51:02 --> $config['composer_autoload'] is set to TRUE but E:\xampp\htdocs\maurnaturo\application\vendor/autoload.php was not found.
INFO - 2024-05-19 15:51:02 --> Config Class Initialized
INFO - 2024-05-19 15:51:02 --> Hooks Class Initialized
DEBUG - 2024-05-19 15:51:02 --> UTF-8 Support Enabled
INFO - 2024-05-19 15:51:02 --> Utf8 Class Initialized
INFO - 2024-05-19 15:51:02 --> URI Class Initialized
INFO - 2024-05-19 15:51:02 --> Router Class Initialized
INFO - 2024-05-19 15:51:02 --> Output Class Initialized
INFO - 2024-05-19 15:51:02 --> Security Class Initialized
DEBUG - 2024-05-19 15:51:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-19 15:51:02 --> Input Class Initialized
INFO - 2024-05-19 15:51:02 --> Language Class Initialized
INFO - 2024-05-19 15:51:02 --> Loader Class Initialized
INFO - 2024-05-19 15:51:02 --> Helper loaded: url_helper
INFO - 2024-05-19 15:51:02 --> Helper loaded: file_helper
INFO - 2024-05-19 15:51:02 --> Helper loaded: html_helper
INFO - 2024-05-19 15:51:02 --> Helper loaded: text_helper
INFO - 2024-05-19 15:51:02 --> Helper loaded: form_helper
INFO - 2024-05-19 15:51:02 --> Helper loaded: lang_helper
INFO - 2024-05-19 15:51:02 --> Helper loaded: security_helper
INFO - 2024-05-19 15:51:02 --> Helper loaded: cookie_helper
INFO - 2024-05-19 15:51:02 --> Database Driver Class Initialized
INFO - 2024-05-19 15:51:02 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-19 15:51:02 --> Parser Class Initialized
INFO - 2024-05-19 15:51:02 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-05-19 15:51:02 --> Pagination Class Initialized
INFO - 2024-05-19 15:51:02 --> Form Validation Class Initialized
INFO - 2024-05-19 15:51:02 --> Controller Class Initialized
DEBUG - 2024-05-19 15:51:02 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-05-19 15:51:02 --> Session class already loaded. Second attempt ignored.
INFO - 2024-05-19 15:51:02 --> Model Class Initialized
DEBUG - 2024-05-19 15:51:02 --> Lpayments class already loaded. Second attempt ignored.
INFO - 2024-05-19 15:51:02 --> Model Class Initialized
INFO - 2024-05-19 15:51:02 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\payments/payment.php
DEBUG - 2024-05-19 15:51:02 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-05-19 15:51:02 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\include/top_menu.php
INFO - 2024-05-19 15:51:02 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\include/admin_loggedin_info.php
INFO - 2024-05-19 15:51:02 --> Model Class Initialized
INFO - 2024-05-19 15:51:02 --> Model Class Initialized
INFO - 2024-05-19 15:51:02 --> Model Class Initialized
INFO - 2024-05-19 15:51:03 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\include/admin_header.php
INFO - 2024-05-19 15:51:03 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\include/admin_footer.php
INFO - 2024-05-19 15:51:03 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\admin_html_template.php
INFO - 2024-05-19 15:51:03 --> Final output sent to browser
DEBUG - 2024-05-19 15:51:03 --> Total execution time: 1.4347
ERROR - 2024-05-19 15:51:04 --> $config['composer_autoload'] is set to TRUE but E:\xampp\htdocs\maurnaturo\application\vendor/autoload.php was not found.
INFO - 2024-05-19 15:51:04 --> Config Class Initialized
INFO - 2024-05-19 15:51:04 --> Hooks Class Initialized
DEBUG - 2024-05-19 15:51:04 --> UTF-8 Support Enabled
INFO - 2024-05-19 15:51:04 --> Utf8 Class Initialized
INFO - 2024-05-19 15:51:04 --> URI Class Initialized
INFO - 2024-05-19 15:51:04 --> Router Class Initialized
INFO - 2024-05-19 15:51:04 --> Output Class Initialized
INFO - 2024-05-19 15:51:04 --> Security Class Initialized
DEBUG - 2024-05-19 15:51:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-19 15:51:04 --> Input Class Initialized
INFO - 2024-05-19 15:51:04 --> Language Class Initialized
INFO - 2024-05-19 15:51:04 --> Loader Class Initialized
INFO - 2024-05-19 15:51:04 --> Helper loaded: url_helper
INFO - 2024-05-19 15:51:04 --> Helper loaded: file_helper
INFO - 2024-05-19 15:51:04 --> Helper loaded: html_helper
INFO - 2024-05-19 15:51:04 --> Helper loaded: text_helper
INFO - 2024-05-19 15:51:04 --> Helper loaded: form_helper
INFO - 2024-05-19 15:51:04 --> Helper loaded: lang_helper
INFO - 2024-05-19 15:51:04 --> Helper loaded: security_helper
INFO - 2024-05-19 15:51:04 --> Helper loaded: cookie_helper
INFO - 2024-05-19 15:51:04 --> Database Driver Class Initialized
INFO - 2024-05-19 15:51:04 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-19 15:51:04 --> Parser Class Initialized
INFO - 2024-05-19 15:51:04 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-05-19 15:51:04 --> Pagination Class Initialized
INFO - 2024-05-19 15:51:04 --> Form Validation Class Initialized
INFO - 2024-05-19 15:51:04 --> Controller Class Initialized
DEBUG - 2024-05-19 15:51:04 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-05-19 15:51:04 --> Session class already loaded. Second attempt ignored.
INFO - 2024-05-19 15:51:04 --> Model Class Initialized
INFO - 2024-05-19 15:51:04 --> Final output sent to browser
DEBUG - 2024-05-19 15:51:04 --> Total execution time: 0.1233
ERROR - 2024-05-19 15:51:11 --> $config['composer_autoload'] is set to TRUE but E:\xampp\htdocs\maurnaturo\application\vendor/autoload.php was not found.
INFO - 2024-05-19 15:51:11 --> Config Class Initialized
INFO - 2024-05-19 15:51:11 --> Hooks Class Initialized
DEBUG - 2024-05-19 15:51:11 --> UTF-8 Support Enabled
INFO - 2024-05-19 15:51:11 --> Utf8 Class Initialized
INFO - 2024-05-19 15:51:11 --> URI Class Initialized
DEBUG - 2024-05-19 15:51:11 --> No URI present. Default controller set.
INFO - 2024-05-19 15:51:11 --> Router Class Initialized
INFO - 2024-05-19 15:51:11 --> Output Class Initialized
INFO - 2024-05-19 15:51:11 --> Security Class Initialized
DEBUG - 2024-05-19 15:51:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-19 15:51:11 --> Input Class Initialized
INFO - 2024-05-19 15:51:11 --> Language Class Initialized
INFO - 2024-05-19 15:51:11 --> Loader Class Initialized
INFO - 2024-05-19 15:51:11 --> Helper loaded: url_helper
INFO - 2024-05-19 15:51:11 --> Helper loaded: file_helper
INFO - 2024-05-19 15:51:11 --> Helper loaded: html_helper
INFO - 2024-05-19 15:51:11 --> Helper loaded: text_helper
INFO - 2024-05-19 15:51:11 --> Helper loaded: form_helper
INFO - 2024-05-19 15:51:11 --> Helper loaded: lang_helper
INFO - 2024-05-19 15:51:11 --> Helper loaded: security_helper
INFO - 2024-05-19 15:51:11 --> Helper loaded: cookie_helper
INFO - 2024-05-19 15:51:11 --> Database Driver Class Initialized
INFO - 2024-05-19 15:51:11 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-19 15:51:11 --> Parser Class Initialized
INFO - 2024-05-19 15:51:11 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-05-19 15:51:11 --> Pagination Class Initialized
INFO - 2024-05-19 15:51:11 --> Form Validation Class Initialized
INFO - 2024-05-19 15:51:11 --> Controller Class Initialized
INFO - 2024-05-19 15:51:11 --> Model Class Initialized
DEBUG - 2024-05-19 15:51:11 --> Session class already loaded. Second attempt ignored.
INFO - 2024-05-19 15:51:11 --> Model Class Initialized
DEBUG - 2024-05-19 15:51:11 --> Session class already loaded. Second attempt ignored.
INFO - 2024-05-19 15:51:11 --> Model Class Initialized
INFO - 2024-05-19 15:51:11 --> Model Class Initialized
INFO - 2024-05-19 15:51:11 --> Model Class Initialized
INFO - 2024-05-19 15:51:11 --> Model Class Initialized
DEBUG - 2024-05-19 15:51:11 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-05-19 15:51:11 --> Session class already loaded. Second attempt ignored.
INFO - 2024-05-19 15:51:11 --> Model Class Initialized
INFO - 2024-05-19 15:51:11 --> Model Class Initialized
INFO - 2024-05-19 15:51:12 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\include/admin_home.php
DEBUG - 2024-05-19 15:51:12 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-05-19 15:51:12 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\include/top_menu.php
INFO - 2024-05-19 15:51:12 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\include/admin_loggedin_info.php
INFO - 2024-05-19 15:51:12 --> Model Class Initialized
INFO - 2024-05-19 15:51:13 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\include/admin_header.php
INFO - 2024-05-19 15:51:13 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\include/admin_footer.php
INFO - 2024-05-19 15:51:13 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\admin_html_template.php
INFO - 2024-05-19 15:51:13 --> Final output sent to browser
DEBUG - 2024-05-19 15:51:13 --> Total execution time: 2.1707
ERROR - 2024-05-19 15:53:21 --> $config['composer_autoload'] is set to TRUE but E:\xampp\htdocs\maurnaturo\application\vendor/autoload.php was not found.
INFO - 2024-05-19 15:53:21 --> Config Class Initialized
INFO - 2024-05-19 15:53:21 --> Hooks Class Initialized
DEBUG - 2024-05-19 15:53:21 --> UTF-8 Support Enabled
INFO - 2024-05-19 15:53:21 --> Utf8 Class Initialized
INFO - 2024-05-19 15:53:21 --> URI Class Initialized
INFO - 2024-05-19 15:53:21 --> Router Class Initialized
INFO - 2024-05-19 15:53:21 --> Output Class Initialized
INFO - 2024-05-19 15:53:21 --> Security Class Initialized
DEBUG - 2024-05-19 15:53:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-19 15:53:21 --> Input Class Initialized
INFO - 2024-05-19 15:53:21 --> Language Class Initialized
INFO - 2024-05-19 15:53:21 --> Loader Class Initialized
INFO - 2024-05-19 15:53:21 --> Helper loaded: url_helper
INFO - 2024-05-19 15:53:21 --> Helper loaded: file_helper
INFO - 2024-05-19 15:53:21 --> Helper loaded: html_helper
INFO - 2024-05-19 15:53:21 --> Helper loaded: text_helper
INFO - 2024-05-19 15:53:21 --> Helper loaded: form_helper
INFO - 2024-05-19 15:53:21 --> Helper loaded: lang_helper
INFO - 2024-05-19 15:53:21 --> Helper loaded: security_helper
INFO - 2024-05-19 15:53:21 --> Helper loaded: cookie_helper
INFO - 2024-05-19 15:53:21 --> Database Driver Class Initialized
INFO - 2024-05-19 15:53:21 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-19 15:53:21 --> Parser Class Initialized
INFO - 2024-05-19 15:53:21 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-05-19 15:53:21 --> Pagination Class Initialized
INFO - 2024-05-19 15:53:21 --> Form Validation Class Initialized
INFO - 2024-05-19 15:53:21 --> Controller Class Initialized
DEBUG - 2024-05-19 15:53:21 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-05-19 15:53:21 --> Session class already loaded. Second attempt ignored.
INFO - 2024-05-19 15:53:21 --> Model Class Initialized
DEBUG - 2024-05-19 15:53:21 --> Lpayments class already loaded. Second attempt ignored.
INFO - 2024-05-19 15:53:21 --> Model Class Initialized
INFO - 2024-05-19 15:53:21 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\payments/payment.php
DEBUG - 2024-05-19 15:53:21 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-05-19 15:53:21 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\include/top_menu.php
INFO - 2024-05-19 15:53:21 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\include/admin_loggedin_info.php
INFO - 2024-05-19 15:53:21 --> Model Class Initialized
INFO - 2024-05-19 15:53:21 --> Model Class Initialized
INFO - 2024-05-19 15:53:21 --> Model Class Initialized
INFO - 2024-05-19 15:53:23 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\include/admin_header.php
INFO - 2024-05-19 15:53:23 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\include/admin_footer.php
INFO - 2024-05-19 15:53:23 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\admin_html_template.php
INFO - 2024-05-19 15:53:23 --> Final output sent to browser
DEBUG - 2024-05-19 15:53:23 --> Total execution time: 1.5431
ERROR - 2024-05-19 15:53:23 --> $config['composer_autoload'] is set to TRUE but E:\xampp\htdocs\maurnaturo\application\vendor/autoload.php was not found.
INFO - 2024-05-19 15:53:23 --> Config Class Initialized
INFO - 2024-05-19 15:53:23 --> Hooks Class Initialized
DEBUG - 2024-05-19 15:53:23 --> UTF-8 Support Enabled
INFO - 2024-05-19 15:53:23 --> Utf8 Class Initialized
INFO - 2024-05-19 15:53:23 --> URI Class Initialized
INFO - 2024-05-19 15:53:23 --> Router Class Initialized
INFO - 2024-05-19 15:53:23 --> Output Class Initialized
INFO - 2024-05-19 15:53:23 --> Security Class Initialized
DEBUG - 2024-05-19 15:53:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-19 15:53:23 --> Input Class Initialized
INFO - 2024-05-19 15:53:23 --> Language Class Initialized
INFO - 2024-05-19 15:53:23 --> Loader Class Initialized
INFO - 2024-05-19 15:53:23 --> Helper loaded: url_helper
INFO - 2024-05-19 15:53:23 --> Helper loaded: file_helper
INFO - 2024-05-19 15:53:23 --> Helper loaded: html_helper
INFO - 2024-05-19 15:53:23 --> Helper loaded: text_helper
INFO - 2024-05-19 15:53:23 --> Helper loaded: form_helper
INFO - 2024-05-19 15:53:23 --> Helper loaded: lang_helper
INFO - 2024-05-19 15:53:23 --> Helper loaded: security_helper
INFO - 2024-05-19 15:53:23 --> Helper loaded: cookie_helper
INFO - 2024-05-19 15:53:23 --> Database Driver Class Initialized
INFO - 2024-05-19 15:53:23 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-19 15:53:23 --> Parser Class Initialized
INFO - 2024-05-19 15:53:23 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-05-19 15:53:23 --> Pagination Class Initialized
INFO - 2024-05-19 15:53:23 --> Form Validation Class Initialized
INFO - 2024-05-19 15:53:23 --> Controller Class Initialized
DEBUG - 2024-05-19 15:53:23 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-05-19 15:53:23 --> Session class already loaded. Second attempt ignored.
INFO - 2024-05-19 15:53:23 --> Model Class Initialized
INFO - 2024-05-19 15:53:23 --> Final output sent to browser
DEBUG - 2024-05-19 15:53:23 --> Total execution time: 0.2685
ERROR - 2024-05-19 15:55:45 --> $config['composer_autoload'] is set to TRUE but E:\xampp\htdocs\maurnaturo\application\vendor/autoload.php was not found.
INFO - 2024-05-19 15:55:45 --> Config Class Initialized
INFO - 2024-05-19 15:55:45 --> Hooks Class Initialized
DEBUG - 2024-05-19 15:55:45 --> UTF-8 Support Enabled
INFO - 2024-05-19 15:55:45 --> Utf8 Class Initialized
INFO - 2024-05-19 15:55:45 --> URI Class Initialized
INFO - 2024-05-19 15:55:45 --> Router Class Initialized
INFO - 2024-05-19 15:55:45 --> Output Class Initialized
INFO - 2024-05-19 15:55:45 --> Security Class Initialized
DEBUG - 2024-05-19 15:55:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-19 15:55:45 --> Input Class Initialized
INFO - 2024-05-19 15:55:45 --> Language Class Initialized
INFO - 2024-05-19 15:55:45 --> Loader Class Initialized
INFO - 2024-05-19 15:55:45 --> Helper loaded: url_helper
INFO - 2024-05-19 15:55:45 --> Helper loaded: file_helper
INFO - 2024-05-19 15:55:45 --> Helper loaded: html_helper
INFO - 2024-05-19 15:55:45 --> Helper loaded: text_helper
INFO - 2024-05-19 15:55:45 --> Helper loaded: form_helper
INFO - 2024-05-19 15:55:45 --> Helper loaded: lang_helper
INFO - 2024-05-19 15:55:45 --> Helper loaded: security_helper
INFO - 2024-05-19 15:55:45 --> Helper loaded: cookie_helper
INFO - 2024-05-19 15:55:45 --> Database Driver Class Initialized
INFO - 2024-05-19 15:55:45 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-19 15:55:45 --> Parser Class Initialized
INFO - 2024-05-19 15:55:45 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-05-19 15:55:45 --> Pagination Class Initialized
INFO - 2024-05-19 15:55:45 --> Form Validation Class Initialized
INFO - 2024-05-19 15:55:45 --> Controller Class Initialized
DEBUG - 2024-05-19 15:55:45 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-05-19 15:55:45 --> Session class already loaded. Second attempt ignored.
INFO - 2024-05-19 15:55:45 --> Model Class Initialized
DEBUG - 2024-05-19 15:55:45 --> Lpayments class already loaded. Second attempt ignored.
INFO - 2024-05-19 15:55:45 --> Model Class Initialized
INFO - 2024-05-19 15:55:45 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\payments/payment.php
DEBUG - 2024-05-19 15:55:45 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-05-19 15:55:45 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\include/top_menu.php
INFO - 2024-05-19 15:55:45 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\include/admin_loggedin_info.php
INFO - 2024-05-19 15:55:45 --> Model Class Initialized
INFO - 2024-05-19 15:55:45 --> Model Class Initialized
INFO - 2024-05-19 15:55:45 --> Model Class Initialized
INFO - 2024-05-19 15:55:47 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\include/admin_header.php
INFO - 2024-05-19 15:55:47 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\include/admin_footer.php
INFO - 2024-05-19 15:55:47 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\admin_html_template.php
INFO - 2024-05-19 15:55:47 --> Final output sent to browser
DEBUG - 2024-05-19 15:55:47 --> Total execution time: 1.4496
ERROR - 2024-05-19 15:55:47 --> $config['composer_autoload'] is set to TRUE but E:\xampp\htdocs\maurnaturo\application\vendor/autoload.php was not found.
INFO - 2024-05-19 15:55:47 --> Config Class Initialized
INFO - 2024-05-19 15:55:47 --> Hooks Class Initialized
DEBUG - 2024-05-19 15:55:47 --> UTF-8 Support Enabled
INFO - 2024-05-19 15:55:47 --> Utf8 Class Initialized
INFO - 2024-05-19 15:55:47 --> URI Class Initialized
INFO - 2024-05-19 15:55:47 --> Router Class Initialized
INFO - 2024-05-19 15:55:47 --> Output Class Initialized
INFO - 2024-05-19 15:55:47 --> Security Class Initialized
DEBUG - 2024-05-19 15:55:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-19 15:55:47 --> Input Class Initialized
INFO - 2024-05-19 15:55:47 --> Language Class Initialized
INFO - 2024-05-19 15:55:47 --> Loader Class Initialized
INFO - 2024-05-19 15:55:47 --> Helper loaded: url_helper
INFO - 2024-05-19 15:55:47 --> Helper loaded: file_helper
INFO - 2024-05-19 15:55:47 --> Helper loaded: html_helper
INFO - 2024-05-19 15:55:47 --> Helper loaded: text_helper
INFO - 2024-05-19 15:55:47 --> Helper loaded: form_helper
INFO - 2024-05-19 15:55:47 --> Helper loaded: lang_helper
INFO - 2024-05-19 15:55:47 --> Helper loaded: security_helper
INFO - 2024-05-19 15:55:47 --> Helper loaded: cookie_helper
INFO - 2024-05-19 15:55:47 --> Database Driver Class Initialized
INFO - 2024-05-19 15:55:47 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-19 15:55:47 --> Parser Class Initialized
INFO - 2024-05-19 15:55:47 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-05-19 15:55:47 --> Pagination Class Initialized
INFO - 2024-05-19 15:55:47 --> Form Validation Class Initialized
INFO - 2024-05-19 15:55:47 --> Controller Class Initialized
DEBUG - 2024-05-19 15:55:47 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-05-19 15:55:47 --> Session class already loaded. Second attempt ignored.
INFO - 2024-05-19 15:55:47 --> Model Class Initialized
INFO - 2024-05-19 15:55:47 --> Final output sent to browser
DEBUG - 2024-05-19 15:55:47 --> Total execution time: 0.1289
ERROR - 2024-05-19 16:12:20 --> $config['composer_autoload'] is set to TRUE but E:\xampp\htdocs\maurnaturo\application\vendor/autoload.php was not found.
INFO - 2024-05-19 16:12:20 --> Config Class Initialized
INFO - 2024-05-19 16:12:20 --> Hooks Class Initialized
DEBUG - 2024-05-19 16:12:20 --> UTF-8 Support Enabled
INFO - 2024-05-19 16:12:20 --> Utf8 Class Initialized
INFO - 2024-05-19 16:12:20 --> URI Class Initialized
INFO - 2024-05-19 16:12:20 --> Router Class Initialized
INFO - 2024-05-19 16:12:20 --> Output Class Initialized
INFO - 2024-05-19 16:12:20 --> Security Class Initialized
DEBUG - 2024-05-19 16:12:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-19 16:12:20 --> Input Class Initialized
INFO - 2024-05-19 16:12:20 --> Language Class Initialized
INFO - 2024-05-19 16:12:20 --> Loader Class Initialized
INFO - 2024-05-19 16:12:20 --> Helper loaded: url_helper
INFO - 2024-05-19 16:12:20 --> Helper loaded: file_helper
INFO - 2024-05-19 16:12:20 --> Helper loaded: html_helper
INFO - 2024-05-19 16:12:20 --> Helper loaded: text_helper
INFO - 2024-05-19 16:12:20 --> Helper loaded: form_helper
INFO - 2024-05-19 16:12:20 --> Helper loaded: lang_helper
INFO - 2024-05-19 16:12:20 --> Helper loaded: security_helper
INFO - 2024-05-19 16:12:20 --> Helper loaded: cookie_helper
INFO - 2024-05-19 16:12:20 --> Database Driver Class Initialized
INFO - 2024-05-19 16:12:20 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-19 16:12:20 --> Parser Class Initialized
INFO - 2024-05-19 16:12:20 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-05-19 16:12:20 --> Pagination Class Initialized
INFO - 2024-05-19 16:12:20 --> Form Validation Class Initialized
INFO - 2024-05-19 16:12:20 --> Controller Class Initialized
DEBUG - 2024-05-19 16:12:20 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-05-19 16:12:20 --> Session class already loaded. Second attempt ignored.
INFO - 2024-05-19 16:12:20 --> Model Class Initialized
DEBUG - 2024-05-19 16:12:20 --> Lpayments class already loaded. Second attempt ignored.
INFO - 2024-05-19 16:12:20 --> Model Class Initialized
INFO - 2024-05-19 16:12:20 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\payments/payment.php
DEBUG - 2024-05-19 16:12:20 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-05-19 16:12:20 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\include/top_menu.php
INFO - 2024-05-19 16:12:20 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\include/admin_loggedin_info.php
INFO - 2024-05-19 16:12:20 --> Model Class Initialized
INFO - 2024-05-19 16:12:20 --> Model Class Initialized
INFO - 2024-05-19 16:12:20 --> Model Class Initialized
INFO - 2024-05-19 16:12:21 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\include/admin_header.php
INFO - 2024-05-19 16:12:21 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\include/admin_footer.php
INFO - 2024-05-19 16:12:21 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\admin_html_template.php
INFO - 2024-05-19 16:12:21 --> Final output sent to browser
DEBUG - 2024-05-19 16:12:21 --> Total execution time: 1.1454
ERROR - 2024-05-19 16:12:22 --> $config['composer_autoload'] is set to TRUE but E:\xampp\htdocs\maurnaturo\application\vendor/autoload.php was not found.
INFO - 2024-05-19 16:12:22 --> Config Class Initialized
INFO - 2024-05-19 16:12:22 --> Hooks Class Initialized
DEBUG - 2024-05-19 16:12:22 --> UTF-8 Support Enabled
INFO - 2024-05-19 16:12:22 --> Utf8 Class Initialized
INFO - 2024-05-19 16:12:22 --> URI Class Initialized
INFO - 2024-05-19 16:12:22 --> Router Class Initialized
INFO - 2024-05-19 16:12:22 --> Output Class Initialized
INFO - 2024-05-19 16:12:22 --> Security Class Initialized
DEBUG - 2024-05-19 16:12:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-19 16:12:22 --> Input Class Initialized
INFO - 2024-05-19 16:12:22 --> Language Class Initialized
INFO - 2024-05-19 16:12:22 --> Loader Class Initialized
INFO - 2024-05-19 16:12:22 --> Helper loaded: url_helper
INFO - 2024-05-19 16:12:22 --> Helper loaded: file_helper
INFO - 2024-05-19 16:12:22 --> Helper loaded: html_helper
INFO - 2024-05-19 16:12:22 --> Helper loaded: text_helper
INFO - 2024-05-19 16:12:22 --> Helper loaded: form_helper
INFO - 2024-05-19 16:12:22 --> Helper loaded: lang_helper
INFO - 2024-05-19 16:12:22 --> Helper loaded: security_helper
INFO - 2024-05-19 16:12:22 --> Helper loaded: cookie_helper
INFO - 2024-05-19 16:12:22 --> Database Driver Class Initialized
INFO - 2024-05-19 16:12:22 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-19 16:12:22 --> Parser Class Initialized
INFO - 2024-05-19 16:12:22 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-05-19 16:12:22 --> Pagination Class Initialized
INFO - 2024-05-19 16:12:22 --> Form Validation Class Initialized
INFO - 2024-05-19 16:12:22 --> Controller Class Initialized
DEBUG - 2024-05-19 16:12:22 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-05-19 16:12:22 --> Session class already loaded. Second attempt ignored.
INFO - 2024-05-19 16:12:22 --> Model Class Initialized
INFO - 2024-05-19 16:12:22 --> Final output sent to browser
DEBUG - 2024-05-19 16:12:22 --> Total execution time: 0.1042
ERROR - 2024-05-19 16:12:26 --> $config['composer_autoload'] is set to TRUE but E:\xampp\htdocs\maurnaturo\application\vendor/autoload.php was not found.
INFO - 2024-05-19 16:12:26 --> Config Class Initialized
INFO - 2024-05-19 16:12:26 --> Hooks Class Initialized
DEBUG - 2024-05-19 16:12:26 --> UTF-8 Support Enabled
INFO - 2024-05-19 16:12:26 --> Utf8 Class Initialized
INFO - 2024-05-19 16:12:26 --> URI Class Initialized
INFO - 2024-05-19 16:12:26 --> Router Class Initialized
INFO - 2024-05-19 16:12:26 --> Output Class Initialized
INFO - 2024-05-19 16:12:26 --> Security Class Initialized
DEBUG - 2024-05-19 16:12:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-19 16:12:26 --> Input Class Initialized
INFO - 2024-05-19 16:12:26 --> Language Class Initialized
INFO - 2024-05-19 16:12:26 --> Loader Class Initialized
INFO - 2024-05-19 16:12:26 --> Helper loaded: url_helper
INFO - 2024-05-19 16:12:26 --> Helper loaded: file_helper
INFO - 2024-05-19 16:12:26 --> Helper loaded: html_helper
INFO - 2024-05-19 16:12:26 --> Helper loaded: text_helper
INFO - 2024-05-19 16:12:26 --> Helper loaded: form_helper
INFO - 2024-05-19 16:12:26 --> Helper loaded: lang_helper
INFO - 2024-05-19 16:12:26 --> Helper loaded: security_helper
INFO - 2024-05-19 16:12:26 --> Helper loaded: cookie_helper
INFO - 2024-05-19 16:12:26 --> Database Driver Class Initialized
INFO - 2024-05-19 16:12:26 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-19 16:12:26 --> Parser Class Initialized
INFO - 2024-05-19 16:12:26 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-05-19 16:12:26 --> Pagination Class Initialized
INFO - 2024-05-19 16:12:26 --> Form Validation Class Initialized
INFO - 2024-05-19 16:12:26 --> Controller Class Initialized
DEBUG - 2024-05-19 16:12:26 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-05-19 16:12:26 --> Session class already loaded. Second attempt ignored.
INFO - 2024-05-19 16:12:26 --> Model Class Initialized
DEBUG - 2024-05-19 16:12:26 --> Lpayments class already loaded. Second attempt ignored.
INFO - 2024-05-19 16:12:26 --> Model Class Initialized
INFO - 2024-05-19 16:12:26 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\payments/payment.php
DEBUG - 2024-05-19 16:12:26 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-05-19 16:12:26 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\include/top_menu.php
INFO - 2024-05-19 16:12:26 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\include/admin_loggedin_info.php
INFO - 2024-05-19 16:12:26 --> Model Class Initialized
INFO - 2024-05-19 16:12:26 --> Model Class Initialized
INFO - 2024-05-19 16:12:26 --> Model Class Initialized
INFO - 2024-05-19 16:12:27 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\include/admin_header.php
INFO - 2024-05-19 16:12:27 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\include/admin_footer.php
INFO - 2024-05-19 16:12:27 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\admin_html_template.php
INFO - 2024-05-19 16:12:27 --> Final output sent to browser
DEBUG - 2024-05-19 16:12:27 --> Total execution time: 1.3515
ERROR - 2024-05-19 16:12:28 --> $config['composer_autoload'] is set to TRUE but E:\xampp\htdocs\maurnaturo\application\vendor/autoload.php was not found.
INFO - 2024-05-19 16:12:28 --> Config Class Initialized
INFO - 2024-05-19 16:12:28 --> Hooks Class Initialized
DEBUG - 2024-05-19 16:12:28 --> UTF-8 Support Enabled
INFO - 2024-05-19 16:12:28 --> Utf8 Class Initialized
INFO - 2024-05-19 16:12:28 --> URI Class Initialized
INFO - 2024-05-19 16:12:28 --> Router Class Initialized
INFO - 2024-05-19 16:12:28 --> Output Class Initialized
INFO - 2024-05-19 16:12:28 --> Security Class Initialized
DEBUG - 2024-05-19 16:12:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-19 16:12:28 --> Input Class Initialized
INFO - 2024-05-19 16:12:28 --> Language Class Initialized
INFO - 2024-05-19 16:12:28 --> Loader Class Initialized
INFO - 2024-05-19 16:12:28 --> Helper loaded: url_helper
INFO - 2024-05-19 16:12:28 --> Helper loaded: file_helper
INFO - 2024-05-19 16:12:28 --> Helper loaded: html_helper
INFO - 2024-05-19 16:12:28 --> Helper loaded: text_helper
INFO - 2024-05-19 16:12:28 --> Helper loaded: form_helper
INFO - 2024-05-19 16:12:28 --> Helper loaded: lang_helper
INFO - 2024-05-19 16:12:28 --> Helper loaded: security_helper
INFO - 2024-05-19 16:12:28 --> Helper loaded: cookie_helper
INFO - 2024-05-19 16:12:28 --> Database Driver Class Initialized
INFO - 2024-05-19 16:12:28 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-19 16:12:28 --> Parser Class Initialized
INFO - 2024-05-19 16:12:28 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-05-19 16:12:28 --> Pagination Class Initialized
INFO - 2024-05-19 16:12:28 --> Form Validation Class Initialized
INFO - 2024-05-19 16:12:28 --> Controller Class Initialized
DEBUG - 2024-05-19 16:12:28 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-05-19 16:12:28 --> Session class already loaded. Second attempt ignored.
INFO - 2024-05-19 16:12:28 --> Model Class Initialized
INFO - 2024-05-19 16:12:28 --> Final output sent to browser
DEBUG - 2024-05-19 16:12:28 --> Total execution time: 0.1569
ERROR - 2024-05-19 16:12:45 --> $config['composer_autoload'] is set to TRUE but E:\xampp\htdocs\maurnaturo\application\vendor/autoload.php was not found.
INFO - 2024-05-19 16:12:45 --> Config Class Initialized
INFO - 2024-05-19 16:12:45 --> Hooks Class Initialized
DEBUG - 2024-05-19 16:12:45 --> UTF-8 Support Enabled
INFO - 2024-05-19 16:12:45 --> Utf8 Class Initialized
INFO - 2024-05-19 16:12:45 --> URI Class Initialized
INFO - 2024-05-19 16:12:45 --> Router Class Initialized
INFO - 2024-05-19 16:12:45 --> Output Class Initialized
INFO - 2024-05-19 16:12:45 --> Security Class Initialized
DEBUG - 2024-05-19 16:12:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-19 16:12:45 --> Input Class Initialized
INFO - 2024-05-19 16:12:45 --> Language Class Initialized
INFO - 2024-05-19 16:12:45 --> Loader Class Initialized
INFO - 2024-05-19 16:12:45 --> Helper loaded: url_helper
INFO - 2024-05-19 16:12:45 --> Helper loaded: file_helper
INFO - 2024-05-19 16:12:45 --> Helper loaded: html_helper
INFO - 2024-05-19 16:12:45 --> Helper loaded: text_helper
INFO - 2024-05-19 16:12:45 --> Helper loaded: form_helper
INFO - 2024-05-19 16:12:45 --> Helper loaded: lang_helper
INFO - 2024-05-19 16:12:45 --> Helper loaded: security_helper
INFO - 2024-05-19 16:12:45 --> Helper loaded: cookie_helper
INFO - 2024-05-19 16:12:45 --> Database Driver Class Initialized
INFO - 2024-05-19 16:12:45 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-19 16:12:45 --> Parser Class Initialized
INFO - 2024-05-19 16:12:45 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-05-19 16:12:45 --> Pagination Class Initialized
INFO - 2024-05-19 16:12:45 --> Form Validation Class Initialized
INFO - 2024-05-19 16:12:45 --> Controller Class Initialized
DEBUG - 2024-05-19 16:12:45 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-05-19 16:12:45 --> Session class already loaded. Second attempt ignored.
INFO - 2024-05-19 16:12:45 --> Model Class Initialized
INFO - 2024-05-19 16:12:45 --> Model Class Initialized
DEBUG - 2024-05-19 16:12:45 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-05-19 16:12:45 --> Session class already loaded. Second attempt ignored.
INFO - 2024-05-19 16:12:45 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\payments/add_payment_form.php
DEBUG - 2024-05-19 16:12:45 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-05-19 16:12:45 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\include/top_menu.php
INFO - 2024-05-19 16:12:45 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\include/admin_loggedin_info.php
INFO - 2024-05-19 16:12:45 --> Model Class Initialized
INFO - 2024-05-19 16:12:45 --> Model Class Initialized
INFO - 2024-05-19 16:12:45 --> Model Class Initialized
INFO - 2024-05-19 16:12:45 --> Model Class Initialized
INFO - 2024-05-19 16:12:46 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\include/admin_header.php
INFO - 2024-05-19 16:12:46 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\include/admin_footer.php
INFO - 2024-05-19 16:12:46 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\admin_html_template.php
INFO - 2024-05-19 16:12:46 --> Final output sent to browser
DEBUG - 2024-05-19 16:12:46 --> Total execution time: 1.0902
ERROR - 2024-05-19 16:13:36 --> $config['composer_autoload'] is set to TRUE but E:\xampp\htdocs\maurnaturo\application\vendor/autoload.php was not found.
INFO - 2024-05-19 16:13:36 --> Config Class Initialized
INFO - 2024-05-19 16:13:36 --> Hooks Class Initialized
DEBUG - 2024-05-19 16:13:36 --> UTF-8 Support Enabled
INFO - 2024-05-19 16:13:36 --> Utf8 Class Initialized
INFO - 2024-05-19 16:13:36 --> URI Class Initialized
INFO - 2024-05-19 16:13:36 --> Router Class Initialized
INFO - 2024-05-19 16:13:36 --> Output Class Initialized
INFO - 2024-05-19 16:13:36 --> Security Class Initialized
DEBUG - 2024-05-19 16:13:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-19 16:13:36 --> Input Class Initialized
INFO - 2024-05-19 16:13:36 --> Language Class Initialized
INFO - 2024-05-19 16:13:36 --> Loader Class Initialized
INFO - 2024-05-19 16:13:36 --> Helper loaded: url_helper
INFO - 2024-05-19 16:13:36 --> Helper loaded: file_helper
INFO - 2024-05-19 16:13:36 --> Helper loaded: html_helper
INFO - 2024-05-19 16:13:36 --> Helper loaded: text_helper
INFO - 2024-05-19 16:13:36 --> Helper loaded: form_helper
INFO - 2024-05-19 16:13:36 --> Helper loaded: lang_helper
INFO - 2024-05-19 16:13:36 --> Helper loaded: security_helper
INFO - 2024-05-19 16:13:36 --> Helper loaded: cookie_helper
INFO - 2024-05-19 16:13:36 --> Database Driver Class Initialized
INFO - 2024-05-19 16:13:36 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-19 16:13:36 --> Parser Class Initialized
INFO - 2024-05-19 16:13:36 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-05-19 16:13:36 --> Pagination Class Initialized
INFO - 2024-05-19 16:13:36 --> Form Validation Class Initialized
INFO - 2024-05-19 16:13:36 --> Controller Class Initialized
DEBUG - 2024-05-19 16:13:36 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-05-19 16:13:36 --> Session class already loaded. Second attempt ignored.
INFO - 2024-05-19 16:13:36 --> Model Class Initialized
ERROR - 2024-05-19 16:17:15 --> $config['composer_autoload'] is set to TRUE but E:\xampp\htdocs\maurnaturo\application\vendor/autoload.php was not found.
INFO - 2024-05-19 16:17:15 --> Config Class Initialized
INFO - 2024-05-19 16:17:15 --> Hooks Class Initialized
DEBUG - 2024-05-19 16:17:15 --> UTF-8 Support Enabled
INFO - 2024-05-19 16:17:15 --> Utf8 Class Initialized
INFO - 2024-05-19 16:17:15 --> URI Class Initialized
INFO - 2024-05-19 16:17:15 --> Router Class Initialized
INFO - 2024-05-19 16:17:15 --> Output Class Initialized
INFO - 2024-05-19 16:17:15 --> Security Class Initialized
DEBUG - 2024-05-19 16:17:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-19 16:17:15 --> Input Class Initialized
INFO - 2024-05-19 16:17:15 --> Language Class Initialized
INFO - 2024-05-19 16:17:15 --> Loader Class Initialized
INFO - 2024-05-19 16:17:15 --> Helper loaded: url_helper
INFO - 2024-05-19 16:17:15 --> Helper loaded: file_helper
INFO - 2024-05-19 16:17:15 --> Helper loaded: html_helper
INFO - 2024-05-19 16:17:15 --> Helper loaded: text_helper
INFO - 2024-05-19 16:17:15 --> Helper loaded: form_helper
INFO - 2024-05-19 16:17:15 --> Helper loaded: lang_helper
INFO - 2024-05-19 16:17:15 --> Helper loaded: security_helper
INFO - 2024-05-19 16:17:15 --> Helper loaded: cookie_helper
INFO - 2024-05-19 16:17:15 --> Database Driver Class Initialized
INFO - 2024-05-19 16:17:15 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-19 16:17:15 --> Parser Class Initialized
INFO - 2024-05-19 16:17:15 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-05-19 16:17:15 --> Pagination Class Initialized
INFO - 2024-05-19 16:17:15 --> Form Validation Class Initialized
INFO - 2024-05-19 16:17:15 --> Controller Class Initialized
DEBUG - 2024-05-19 16:17:15 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-05-19 16:17:15 --> Session class already loaded. Second attempt ignored.
INFO - 2024-05-19 16:17:15 --> Model Class Initialized
DEBUG - 2024-05-19 16:17:15 --> Lpayments class already loaded. Second attempt ignored.
INFO - 2024-05-19 16:17:15 --> Model Class Initialized
INFO - 2024-05-19 16:17:15 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\payments/payment.php
DEBUG - 2024-05-19 16:17:15 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-05-19 16:17:15 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\include/top_menu.php
INFO - 2024-05-19 16:17:15 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\include/admin_loggedin_info.php
INFO - 2024-05-19 16:17:15 --> Model Class Initialized
INFO - 2024-05-19 16:17:15 --> Model Class Initialized
INFO - 2024-05-19 16:17:15 --> Model Class Initialized
INFO - 2024-05-19 16:17:16 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\include/admin_header.php
INFO - 2024-05-19 16:17:16 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\include/admin_footer.php
INFO - 2024-05-19 16:17:16 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\admin_html_template.php
INFO - 2024-05-19 16:17:16 --> Final output sent to browser
DEBUG - 2024-05-19 16:17:16 --> Total execution time: 1.1942
ERROR - 2024-05-19 16:17:17 --> $config['composer_autoload'] is set to TRUE but E:\xampp\htdocs\maurnaturo\application\vendor/autoload.php was not found.
INFO - 2024-05-19 16:17:17 --> Config Class Initialized
INFO - 2024-05-19 16:17:17 --> Hooks Class Initialized
DEBUG - 2024-05-19 16:17:17 --> UTF-8 Support Enabled
INFO - 2024-05-19 16:17:17 --> Utf8 Class Initialized
INFO - 2024-05-19 16:17:17 --> URI Class Initialized
INFO - 2024-05-19 16:17:17 --> Router Class Initialized
INFO - 2024-05-19 16:17:17 --> Output Class Initialized
INFO - 2024-05-19 16:17:17 --> Security Class Initialized
DEBUG - 2024-05-19 16:17:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-19 16:17:17 --> Input Class Initialized
INFO - 2024-05-19 16:17:17 --> Language Class Initialized
INFO - 2024-05-19 16:17:17 --> Loader Class Initialized
INFO - 2024-05-19 16:17:17 --> Helper loaded: url_helper
INFO - 2024-05-19 16:17:17 --> Helper loaded: file_helper
INFO - 2024-05-19 16:17:17 --> Helper loaded: html_helper
INFO - 2024-05-19 16:17:17 --> Helper loaded: text_helper
INFO - 2024-05-19 16:17:17 --> Helper loaded: form_helper
INFO - 2024-05-19 16:17:17 --> Helper loaded: lang_helper
INFO - 2024-05-19 16:17:17 --> Helper loaded: security_helper
INFO - 2024-05-19 16:17:17 --> Helper loaded: cookie_helper
INFO - 2024-05-19 16:17:17 --> Database Driver Class Initialized
INFO - 2024-05-19 16:17:17 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-19 16:17:17 --> Parser Class Initialized
INFO - 2024-05-19 16:17:17 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-05-19 16:17:17 --> Pagination Class Initialized
INFO - 2024-05-19 16:17:17 --> Form Validation Class Initialized
INFO - 2024-05-19 16:17:17 --> Controller Class Initialized
DEBUG - 2024-05-19 16:17:17 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-05-19 16:17:17 --> Session class already loaded. Second attempt ignored.
INFO - 2024-05-19 16:17:17 --> Model Class Initialized
INFO - 2024-05-19 16:17:17 --> Final output sent to browser
DEBUG - 2024-05-19 16:17:17 --> Total execution time: 0.1195
ERROR - 2024-05-19 16:17:24 --> $config['composer_autoload'] is set to TRUE but E:\xampp\htdocs\maurnaturo\application\vendor/autoload.php was not found.
INFO - 2024-05-19 16:17:24 --> Config Class Initialized
INFO - 2024-05-19 16:17:24 --> Hooks Class Initialized
DEBUG - 2024-05-19 16:17:24 --> UTF-8 Support Enabled
INFO - 2024-05-19 16:17:24 --> Utf8 Class Initialized
INFO - 2024-05-19 16:17:24 --> URI Class Initialized
INFO - 2024-05-19 16:17:24 --> Router Class Initialized
INFO - 2024-05-19 16:17:24 --> Output Class Initialized
INFO - 2024-05-19 16:17:24 --> Security Class Initialized
DEBUG - 2024-05-19 16:17:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-19 16:17:24 --> Input Class Initialized
INFO - 2024-05-19 16:17:24 --> Language Class Initialized
INFO - 2024-05-19 16:17:24 --> Loader Class Initialized
INFO - 2024-05-19 16:17:24 --> Helper loaded: url_helper
INFO - 2024-05-19 16:17:24 --> Helper loaded: file_helper
INFO - 2024-05-19 16:17:24 --> Helper loaded: html_helper
INFO - 2024-05-19 16:17:24 --> Helper loaded: text_helper
INFO - 2024-05-19 16:17:24 --> Helper loaded: form_helper
INFO - 2024-05-19 16:17:24 --> Helper loaded: lang_helper
INFO - 2024-05-19 16:17:24 --> Helper loaded: security_helper
INFO - 2024-05-19 16:17:24 --> Helper loaded: cookie_helper
INFO - 2024-05-19 16:17:24 --> Database Driver Class Initialized
INFO - 2024-05-19 16:17:24 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-19 16:17:24 --> Parser Class Initialized
INFO - 2024-05-19 16:17:24 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-05-19 16:17:24 --> Pagination Class Initialized
INFO - 2024-05-19 16:17:24 --> Form Validation Class Initialized
INFO - 2024-05-19 16:17:24 --> Controller Class Initialized
INFO - 2024-05-19 16:17:24 --> Model Class Initialized
DEBUG - 2024-05-19 16:17:24 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-05-19 16:17:24 --> Session class already loaded. Second attempt ignored.
INFO - 2024-05-19 16:17:24 --> Model Class Initialized
DEBUG - 2024-05-19 16:17:24 --> Session class already loaded. Second attempt ignored.
INFO - 2024-05-19 16:17:24 --> Model Class Initialized
INFO - 2024-05-19 16:17:24 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\invoice/invoice.php
DEBUG - 2024-05-19 16:17:24 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-05-19 16:17:24 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\include/top_menu.php
INFO - 2024-05-19 16:17:24 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\include/admin_loggedin_info.php
INFO - 2024-05-19 16:17:24 --> Model Class Initialized
INFO - 2024-05-19 16:17:24 --> Model Class Initialized
INFO - 2024-05-19 16:17:24 --> Model Class Initialized
INFO - 2024-05-19 16:17:25 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\include/admin_header.php
INFO - 2024-05-19 16:17:25 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\include/admin_footer.php
INFO - 2024-05-19 16:17:25 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\admin_html_template.php
INFO - 2024-05-19 16:17:25 --> Final output sent to browser
DEBUG - 2024-05-19 16:17:25 --> Total execution time: 1.1446
ERROR - 2024-05-19 16:17:25 --> $config['composer_autoload'] is set to TRUE but E:\xampp\htdocs\maurnaturo\application\vendor/autoload.php was not found.
INFO - 2024-05-19 16:17:25 --> Config Class Initialized
INFO - 2024-05-19 16:17:25 --> Hooks Class Initialized
DEBUG - 2024-05-19 16:17:25 --> UTF-8 Support Enabled
INFO - 2024-05-19 16:17:25 --> Utf8 Class Initialized
INFO - 2024-05-19 16:17:25 --> URI Class Initialized
INFO - 2024-05-19 16:17:25 --> Router Class Initialized
INFO - 2024-05-19 16:17:25 --> Output Class Initialized
INFO - 2024-05-19 16:17:25 --> Security Class Initialized
DEBUG - 2024-05-19 16:17:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-19 16:17:25 --> Input Class Initialized
INFO - 2024-05-19 16:17:25 --> Language Class Initialized
INFO - 2024-05-19 16:17:25 --> Loader Class Initialized
INFO - 2024-05-19 16:17:25 --> Helper loaded: url_helper
INFO - 2024-05-19 16:17:25 --> Helper loaded: file_helper
INFO - 2024-05-19 16:17:25 --> Helper loaded: html_helper
INFO - 2024-05-19 16:17:25 --> Helper loaded: text_helper
INFO - 2024-05-19 16:17:25 --> Helper loaded: form_helper
INFO - 2024-05-19 16:17:25 --> Helper loaded: lang_helper
INFO - 2024-05-19 16:17:25 --> Helper loaded: security_helper
INFO - 2024-05-19 16:17:25 --> Helper loaded: cookie_helper
INFO - 2024-05-19 16:17:25 --> Database Driver Class Initialized
INFO - 2024-05-19 16:17:25 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-19 16:17:25 --> Parser Class Initialized
INFO - 2024-05-19 16:17:25 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-05-19 16:17:25 --> Pagination Class Initialized
INFO - 2024-05-19 16:17:25 --> Form Validation Class Initialized
INFO - 2024-05-19 16:17:25 --> Controller Class Initialized
INFO - 2024-05-19 16:17:25 --> Model Class Initialized
DEBUG - 2024-05-19 16:17:25 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-05-19 16:17:25 --> Session class already loaded. Second attempt ignored.
INFO - 2024-05-19 16:17:25 --> Model Class Initialized
DEBUG - 2024-05-19 16:17:25 --> Session class already loaded. Second attempt ignored.
INFO - 2024-05-19 16:17:25 --> Model Class Initialized
INFO - 2024-05-19 16:17:25 --> Final output sent to browser
DEBUG - 2024-05-19 16:17:25 --> Total execution time: 0.3094
ERROR - 2024-05-19 16:17:29 --> $config['composer_autoload'] is set to TRUE but E:\xampp\htdocs\maurnaturo\application\vendor/autoload.php was not found.
INFO - 2024-05-19 16:17:29 --> Config Class Initialized
INFO - 2024-05-19 16:17:29 --> Hooks Class Initialized
DEBUG - 2024-05-19 16:17:29 --> UTF-8 Support Enabled
INFO - 2024-05-19 16:17:29 --> Utf8 Class Initialized
INFO - 2024-05-19 16:17:29 --> URI Class Initialized
INFO - 2024-05-19 16:17:29 --> Router Class Initialized
INFO - 2024-05-19 16:17:29 --> Output Class Initialized
INFO - 2024-05-19 16:17:29 --> Security Class Initialized
DEBUG - 2024-05-19 16:17:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-19 16:17:29 --> Input Class Initialized
INFO - 2024-05-19 16:17:29 --> Language Class Initialized
INFO - 2024-05-19 16:17:29 --> Loader Class Initialized
INFO - 2024-05-19 16:17:29 --> Helper loaded: url_helper
INFO - 2024-05-19 16:17:29 --> Helper loaded: file_helper
INFO - 2024-05-19 16:17:29 --> Helper loaded: html_helper
INFO - 2024-05-19 16:17:29 --> Helper loaded: text_helper
INFO - 2024-05-19 16:17:29 --> Helper loaded: form_helper
INFO - 2024-05-19 16:17:29 --> Helper loaded: lang_helper
INFO - 2024-05-19 16:17:29 --> Helper loaded: security_helper
INFO - 2024-05-19 16:17:29 --> Helper loaded: cookie_helper
INFO - 2024-05-19 16:17:29 --> Database Driver Class Initialized
INFO - 2024-05-19 16:17:29 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-19 16:17:29 --> Parser Class Initialized
INFO - 2024-05-19 16:17:29 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-05-19 16:17:29 --> Pagination Class Initialized
INFO - 2024-05-19 16:17:29 --> Form Validation Class Initialized
INFO - 2024-05-19 16:17:29 --> Controller Class Initialized
INFO - 2024-05-19 16:17:29 --> Model Class Initialized
DEBUG - 2024-05-19 16:17:29 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-05-19 16:17:29 --> Session class already loaded. Second attempt ignored.
INFO - 2024-05-19 16:17:29 --> Model Class Initialized
DEBUG - 2024-05-19 16:17:29 --> Session class already loaded. Second attempt ignored.
INFO - 2024-05-19 16:17:29 --> Model Class Initialized
INFO - 2024-05-19 16:17:29 --> Final output sent to browser
DEBUG - 2024-05-19 16:17:29 --> Total execution time: 0.0902
ERROR - 2024-05-19 16:17:30 --> $config['composer_autoload'] is set to TRUE but E:\xampp\htdocs\maurnaturo\application\vendor/autoload.php was not found.
INFO - 2024-05-19 16:17:30 --> Config Class Initialized
INFO - 2024-05-19 16:17:30 --> Hooks Class Initialized
DEBUG - 2024-05-19 16:17:30 --> UTF-8 Support Enabled
INFO - 2024-05-19 16:17:30 --> Utf8 Class Initialized
INFO - 2024-05-19 16:17:30 --> URI Class Initialized
INFO - 2024-05-19 16:17:30 --> Router Class Initialized
INFO - 2024-05-19 16:17:30 --> Output Class Initialized
INFO - 2024-05-19 16:17:30 --> Security Class Initialized
DEBUG - 2024-05-19 16:17:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-19 16:17:30 --> Input Class Initialized
INFO - 2024-05-19 16:17:30 --> Language Class Initialized
INFO - 2024-05-19 16:17:30 --> Loader Class Initialized
INFO - 2024-05-19 16:17:30 --> Helper loaded: url_helper
INFO - 2024-05-19 16:17:30 --> Helper loaded: file_helper
INFO - 2024-05-19 16:17:30 --> Helper loaded: html_helper
INFO - 2024-05-19 16:17:30 --> Helper loaded: text_helper
INFO - 2024-05-19 16:17:30 --> Helper loaded: form_helper
INFO - 2024-05-19 16:17:30 --> Helper loaded: lang_helper
INFO - 2024-05-19 16:17:30 --> Helper loaded: security_helper
INFO - 2024-05-19 16:17:30 --> Helper loaded: cookie_helper
INFO - 2024-05-19 16:17:30 --> Database Driver Class Initialized
INFO - 2024-05-19 16:17:30 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-19 16:17:30 --> Parser Class Initialized
INFO - 2024-05-19 16:17:30 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-05-19 16:17:30 --> Pagination Class Initialized
INFO - 2024-05-19 16:17:30 --> Form Validation Class Initialized
INFO - 2024-05-19 16:17:30 --> Controller Class Initialized
INFO - 2024-05-19 16:17:30 --> Model Class Initialized
DEBUG - 2024-05-19 16:17:30 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-05-19 16:17:30 --> Session class already loaded. Second attempt ignored.
INFO - 2024-05-19 16:17:30 --> Model Class Initialized
DEBUG - 2024-05-19 16:17:30 --> Session class already loaded. Second attempt ignored.
INFO - 2024-05-19 16:17:30 --> Model Class Initialized
INFO - 2024-05-19 16:17:30 --> Final output sent to browser
DEBUG - 2024-05-19 16:17:30 --> Total execution time: 0.0838
ERROR - 2024-05-19 16:17:31 --> $config['composer_autoload'] is set to TRUE but E:\xampp\htdocs\maurnaturo\application\vendor/autoload.php was not found.
INFO - 2024-05-19 16:17:31 --> Config Class Initialized
INFO - 2024-05-19 16:17:31 --> Hooks Class Initialized
DEBUG - 2024-05-19 16:17:31 --> UTF-8 Support Enabled
INFO - 2024-05-19 16:17:31 --> Utf8 Class Initialized
INFO - 2024-05-19 16:17:31 --> URI Class Initialized
INFO - 2024-05-19 16:17:31 --> Router Class Initialized
INFO - 2024-05-19 16:17:31 --> Output Class Initialized
INFO - 2024-05-19 16:17:31 --> Security Class Initialized
DEBUG - 2024-05-19 16:17:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-19 16:17:31 --> Input Class Initialized
INFO - 2024-05-19 16:17:31 --> Language Class Initialized
INFO - 2024-05-19 16:17:31 --> Loader Class Initialized
INFO - 2024-05-19 16:17:31 --> Helper loaded: url_helper
INFO - 2024-05-19 16:17:31 --> Helper loaded: file_helper
INFO - 2024-05-19 16:17:31 --> Helper loaded: html_helper
INFO - 2024-05-19 16:17:31 --> Helper loaded: text_helper
INFO - 2024-05-19 16:17:31 --> Helper loaded: form_helper
INFO - 2024-05-19 16:17:31 --> Helper loaded: lang_helper
INFO - 2024-05-19 16:17:31 --> Helper loaded: security_helper
INFO - 2024-05-19 16:17:31 --> Helper loaded: cookie_helper
INFO - 2024-05-19 16:17:31 --> Database Driver Class Initialized
INFO - 2024-05-19 16:17:31 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-19 16:17:31 --> Parser Class Initialized
INFO - 2024-05-19 16:17:31 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-05-19 16:17:31 --> Pagination Class Initialized
INFO - 2024-05-19 16:17:31 --> Form Validation Class Initialized
INFO - 2024-05-19 16:17:31 --> Controller Class Initialized
INFO - 2024-05-19 16:17:31 --> Model Class Initialized
DEBUG - 2024-05-19 16:17:31 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-05-19 16:17:31 --> Session class already loaded. Second attempt ignored.
INFO - 2024-05-19 16:17:31 --> Model Class Initialized
DEBUG - 2024-05-19 16:17:31 --> Session class already loaded. Second attempt ignored.
INFO - 2024-05-19 16:17:31 --> Model Class Initialized
INFO - 2024-05-19 16:17:31 --> Final output sent to browser
DEBUG - 2024-05-19 16:17:31 --> Total execution time: 0.0975
ERROR - 2024-05-19 16:17:32 --> $config['composer_autoload'] is set to TRUE but E:\xampp\htdocs\maurnaturo\application\vendor/autoload.php was not found.
INFO - 2024-05-19 16:17:32 --> Config Class Initialized
INFO - 2024-05-19 16:17:32 --> Hooks Class Initialized
DEBUG - 2024-05-19 16:17:32 --> UTF-8 Support Enabled
INFO - 2024-05-19 16:17:32 --> Utf8 Class Initialized
INFO - 2024-05-19 16:17:32 --> URI Class Initialized
INFO - 2024-05-19 16:17:32 --> Router Class Initialized
INFO - 2024-05-19 16:17:32 --> Output Class Initialized
INFO - 2024-05-19 16:17:32 --> Security Class Initialized
DEBUG - 2024-05-19 16:17:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-19 16:17:32 --> Input Class Initialized
INFO - 2024-05-19 16:17:32 --> Language Class Initialized
INFO - 2024-05-19 16:17:32 --> Loader Class Initialized
INFO - 2024-05-19 16:17:32 --> Helper loaded: url_helper
INFO - 2024-05-19 16:17:32 --> Helper loaded: file_helper
INFO - 2024-05-19 16:17:32 --> Helper loaded: html_helper
INFO - 2024-05-19 16:17:32 --> Helper loaded: text_helper
INFO - 2024-05-19 16:17:32 --> Helper loaded: form_helper
INFO - 2024-05-19 16:17:32 --> Helper loaded: lang_helper
INFO - 2024-05-19 16:17:32 --> Helper loaded: security_helper
INFO - 2024-05-19 16:17:32 --> Helper loaded: cookie_helper
INFO - 2024-05-19 16:17:32 --> Database Driver Class Initialized
INFO - 2024-05-19 16:17:32 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-19 16:17:32 --> Parser Class Initialized
INFO - 2024-05-19 16:17:32 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-05-19 16:17:32 --> Pagination Class Initialized
INFO - 2024-05-19 16:17:32 --> Form Validation Class Initialized
INFO - 2024-05-19 16:17:32 --> Controller Class Initialized
INFO - 2024-05-19 16:17:32 --> Model Class Initialized
DEBUG - 2024-05-19 16:17:32 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-05-19 16:17:32 --> Session class already loaded. Second attempt ignored.
INFO - 2024-05-19 16:17:32 --> Model Class Initialized
DEBUG - 2024-05-19 16:17:32 --> Session class already loaded. Second attempt ignored.
INFO - 2024-05-19 16:17:32 --> Model Class Initialized
INFO - 2024-05-19 16:17:32 --> Final output sent to browser
DEBUG - 2024-05-19 16:17:32 --> Total execution time: 0.1718
ERROR - 2024-05-19 16:17:44 --> $config['composer_autoload'] is set to TRUE but E:\xampp\htdocs\maurnaturo\application\vendor/autoload.php was not found.
INFO - 2024-05-19 16:17:44 --> Config Class Initialized
INFO - 2024-05-19 16:17:44 --> Hooks Class Initialized
DEBUG - 2024-05-19 16:17:44 --> UTF-8 Support Enabled
INFO - 2024-05-19 16:17:44 --> Utf8 Class Initialized
INFO - 2024-05-19 16:17:44 --> URI Class Initialized
INFO - 2024-05-19 16:17:44 --> Router Class Initialized
INFO - 2024-05-19 16:17:44 --> Output Class Initialized
INFO - 2024-05-19 16:17:44 --> Security Class Initialized
DEBUG - 2024-05-19 16:17:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-19 16:17:44 --> Input Class Initialized
INFO - 2024-05-19 16:17:44 --> Language Class Initialized
INFO - 2024-05-19 16:17:44 --> Loader Class Initialized
INFO - 2024-05-19 16:17:44 --> Helper loaded: url_helper
INFO - 2024-05-19 16:17:44 --> Helper loaded: file_helper
INFO - 2024-05-19 16:17:44 --> Helper loaded: html_helper
INFO - 2024-05-19 16:17:44 --> Helper loaded: text_helper
INFO - 2024-05-19 16:17:44 --> Helper loaded: form_helper
INFO - 2024-05-19 16:17:44 --> Helper loaded: lang_helper
INFO - 2024-05-19 16:17:44 --> Helper loaded: security_helper
INFO - 2024-05-19 16:17:44 --> Helper loaded: cookie_helper
INFO - 2024-05-19 16:17:44 --> Database Driver Class Initialized
INFO - 2024-05-19 16:17:44 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-19 16:17:44 --> Parser Class Initialized
INFO - 2024-05-19 16:17:44 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-05-19 16:17:44 --> Pagination Class Initialized
INFO - 2024-05-19 16:17:44 --> Form Validation Class Initialized
INFO - 2024-05-19 16:17:44 --> Controller Class Initialized
INFO - 2024-05-19 16:17:44 --> Model Class Initialized
DEBUG - 2024-05-19 16:17:44 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-05-19 16:17:44 --> Session class already loaded. Second attempt ignored.
INFO - 2024-05-19 16:17:44 --> Model Class Initialized
DEBUG - 2024-05-19 16:17:44 --> Session class already loaded. Second attempt ignored.
INFO - 2024-05-19 16:17:44 --> Model Class Initialized
INFO - 2024-05-19 16:17:44 --> Final output sent to browser
DEBUG - 2024-05-19 16:17:44 --> Total execution time: 0.1844
ERROR - 2024-05-19 16:17:44 --> $config['composer_autoload'] is set to TRUE but E:\xampp\htdocs\maurnaturo\application\vendor/autoload.php was not found.
INFO - 2024-05-19 16:17:44 --> Config Class Initialized
INFO - 2024-05-19 16:17:44 --> Hooks Class Initialized
DEBUG - 2024-05-19 16:17:44 --> UTF-8 Support Enabled
INFO - 2024-05-19 16:17:44 --> Utf8 Class Initialized
INFO - 2024-05-19 16:17:44 --> URI Class Initialized
INFO - 2024-05-19 16:17:44 --> Router Class Initialized
INFO - 2024-05-19 16:17:44 --> Output Class Initialized
INFO - 2024-05-19 16:17:44 --> Security Class Initialized
DEBUG - 2024-05-19 16:17:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-19 16:17:44 --> Input Class Initialized
INFO - 2024-05-19 16:17:44 --> Language Class Initialized
INFO - 2024-05-19 16:17:44 --> Loader Class Initialized
INFO - 2024-05-19 16:17:44 --> Helper loaded: url_helper
INFO - 2024-05-19 16:17:44 --> Helper loaded: file_helper
INFO - 2024-05-19 16:17:44 --> Helper loaded: html_helper
INFO - 2024-05-19 16:17:44 --> Helper loaded: text_helper
INFO - 2024-05-19 16:17:44 --> Helper loaded: form_helper
INFO - 2024-05-19 16:17:44 --> Helper loaded: lang_helper
INFO - 2024-05-19 16:17:44 --> Helper loaded: security_helper
INFO - 2024-05-19 16:17:44 --> Helper loaded: cookie_helper
INFO - 2024-05-19 16:17:44 --> Database Driver Class Initialized
INFO - 2024-05-19 16:17:44 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-19 16:17:44 --> Parser Class Initialized
INFO - 2024-05-19 16:17:44 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-05-19 16:17:44 --> Pagination Class Initialized
INFO - 2024-05-19 16:17:44 --> Form Validation Class Initialized
INFO - 2024-05-19 16:17:44 --> Controller Class Initialized
INFO - 2024-05-19 16:17:44 --> Model Class Initialized
DEBUG - 2024-05-19 16:17:44 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-05-19 16:17:44 --> Session class already loaded. Second attempt ignored.
INFO - 2024-05-19 16:17:44 --> Model Class Initialized
DEBUG - 2024-05-19 16:17:44 --> Session class already loaded. Second attempt ignored.
INFO - 2024-05-19 16:17:44 --> Model Class Initialized
INFO - 2024-05-19 16:17:44 --> Final output sent to browser
DEBUG - 2024-05-19 16:17:44 --> Total execution time: 0.1480
ERROR - 2024-05-19 16:33:20 --> $config['composer_autoload'] is set to TRUE but E:\xampp\htdocs\maurnaturo\application\vendor/autoload.php was not found.
INFO - 2024-05-19 16:33:20 --> Config Class Initialized
INFO - 2024-05-19 16:33:20 --> Hooks Class Initialized
DEBUG - 2024-05-19 16:33:20 --> UTF-8 Support Enabled
INFO - 2024-05-19 16:33:20 --> Utf8 Class Initialized
INFO - 2024-05-19 16:33:20 --> URI Class Initialized
INFO - 2024-05-19 16:33:20 --> Router Class Initialized
INFO - 2024-05-19 16:33:20 --> Output Class Initialized
INFO - 2024-05-19 16:33:20 --> Security Class Initialized
DEBUG - 2024-05-19 16:33:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-19 16:33:20 --> Input Class Initialized
INFO - 2024-05-19 16:33:20 --> Language Class Initialized
INFO - 2024-05-19 16:33:20 --> Loader Class Initialized
INFO - 2024-05-19 16:33:20 --> Helper loaded: url_helper
INFO - 2024-05-19 16:33:20 --> Helper loaded: file_helper
INFO - 2024-05-19 16:33:20 --> Helper loaded: html_helper
INFO - 2024-05-19 16:33:20 --> Helper loaded: text_helper
INFO - 2024-05-19 16:33:20 --> Helper loaded: form_helper
INFO - 2024-05-19 16:33:20 --> Helper loaded: lang_helper
INFO - 2024-05-19 16:33:20 --> Helper loaded: security_helper
INFO - 2024-05-19 16:33:20 --> Helper loaded: cookie_helper
INFO - 2024-05-19 16:33:20 --> Database Driver Class Initialized
INFO - 2024-05-19 16:33:20 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-19 16:33:20 --> Parser Class Initialized
INFO - 2024-05-19 16:33:20 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-05-19 16:33:20 --> Pagination Class Initialized
INFO - 2024-05-19 16:33:20 --> Form Validation Class Initialized
INFO - 2024-05-19 16:33:20 --> Controller Class Initialized
DEBUG - 2024-05-19 16:33:20 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-05-19 16:33:20 --> Session class already loaded. Second attempt ignored.
INFO - 2024-05-19 16:33:20 --> Model Class Initialized
ERROR - 2024-05-19 16:36:00 --> $config['composer_autoload'] is set to TRUE but E:\xampp\htdocs\maurnaturo\application\vendor/autoload.php was not found.
INFO - 2024-05-19 16:36:00 --> Config Class Initialized
INFO - 2024-05-19 16:36:00 --> Hooks Class Initialized
DEBUG - 2024-05-19 16:36:00 --> UTF-8 Support Enabled
INFO - 2024-05-19 16:36:00 --> Utf8 Class Initialized
INFO - 2024-05-19 16:36:00 --> URI Class Initialized
INFO - 2024-05-19 16:36:00 --> Router Class Initialized
INFO - 2024-05-19 16:36:00 --> Output Class Initialized
INFO - 2024-05-19 16:36:00 --> Security Class Initialized
DEBUG - 2024-05-19 16:36:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-19 16:36:00 --> Input Class Initialized
INFO - 2024-05-19 16:36:00 --> Language Class Initialized
INFO - 2024-05-19 16:36:00 --> Loader Class Initialized
INFO - 2024-05-19 16:36:00 --> Helper loaded: url_helper
INFO - 2024-05-19 16:36:00 --> Helper loaded: file_helper
INFO - 2024-05-19 16:36:00 --> Helper loaded: html_helper
INFO - 2024-05-19 16:36:00 --> Helper loaded: text_helper
INFO - 2024-05-19 16:36:00 --> Helper loaded: form_helper
INFO - 2024-05-19 16:36:00 --> Helper loaded: lang_helper
INFO - 2024-05-19 16:36:00 --> Helper loaded: security_helper
INFO - 2024-05-19 16:36:00 --> Helper loaded: cookie_helper
INFO - 2024-05-19 16:36:00 --> Database Driver Class Initialized
INFO - 2024-05-19 16:36:00 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-19 16:36:00 --> Parser Class Initialized
INFO - 2024-05-19 16:36:00 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-05-19 16:36:00 --> Pagination Class Initialized
INFO - 2024-05-19 16:36:00 --> Form Validation Class Initialized
INFO - 2024-05-19 16:36:00 --> Controller Class Initialized
DEBUG - 2024-05-19 16:36:00 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-05-19 16:36:00 --> Session class already loaded. Second attempt ignored.
INFO - 2024-05-19 16:36:00 --> Model Class Initialized
ERROR - 2024-05-19 16:37:07 --> $config['composer_autoload'] is set to TRUE but E:\xampp\htdocs\maurnaturo\application\vendor/autoload.php was not found.
INFO - 2024-05-19 16:37:07 --> Config Class Initialized
INFO - 2024-05-19 16:37:07 --> Hooks Class Initialized
DEBUG - 2024-05-19 16:37:07 --> UTF-8 Support Enabled
INFO - 2024-05-19 16:37:07 --> Utf8 Class Initialized
INFO - 2024-05-19 16:37:07 --> URI Class Initialized
INFO - 2024-05-19 16:37:07 --> Router Class Initialized
INFO - 2024-05-19 16:37:07 --> Output Class Initialized
INFO - 2024-05-19 16:37:07 --> Security Class Initialized
DEBUG - 2024-05-19 16:37:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-19 16:37:07 --> Input Class Initialized
INFO - 2024-05-19 16:37:07 --> Language Class Initialized
INFO - 2024-05-19 16:37:07 --> Loader Class Initialized
INFO - 2024-05-19 16:37:07 --> Helper loaded: url_helper
INFO - 2024-05-19 16:37:07 --> Helper loaded: file_helper
INFO - 2024-05-19 16:37:07 --> Helper loaded: html_helper
INFO - 2024-05-19 16:37:07 --> Helper loaded: text_helper
INFO - 2024-05-19 16:37:07 --> Helper loaded: form_helper
INFO - 2024-05-19 16:37:07 --> Helper loaded: lang_helper
INFO - 2024-05-19 16:37:07 --> Helper loaded: security_helper
INFO - 2024-05-19 16:37:07 --> Helper loaded: cookie_helper
INFO - 2024-05-19 16:37:07 --> Database Driver Class Initialized
INFO - 2024-05-19 16:37:07 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-19 16:37:07 --> Parser Class Initialized
INFO - 2024-05-19 16:37:07 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-05-19 16:37:07 --> Pagination Class Initialized
INFO - 2024-05-19 16:37:07 --> Form Validation Class Initialized
INFO - 2024-05-19 16:37:07 --> Controller Class Initialized
DEBUG - 2024-05-19 16:37:07 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-05-19 16:37:07 --> Session class already loaded. Second attempt ignored.
INFO - 2024-05-19 16:37:07 --> Model Class Initialized
ERROR - 2024-05-19 16:38:45 --> $config['composer_autoload'] is set to TRUE but E:\xampp\htdocs\maurnaturo\application\vendor/autoload.php was not found.
INFO - 2024-05-19 16:38:45 --> Config Class Initialized
INFO - 2024-05-19 16:38:45 --> Hooks Class Initialized
DEBUG - 2024-05-19 16:38:45 --> UTF-8 Support Enabled
INFO - 2024-05-19 16:38:45 --> Utf8 Class Initialized
INFO - 2024-05-19 16:38:45 --> URI Class Initialized
INFO - 2024-05-19 16:38:45 --> Router Class Initialized
INFO - 2024-05-19 16:38:45 --> Output Class Initialized
INFO - 2024-05-19 16:38:45 --> Security Class Initialized
DEBUG - 2024-05-19 16:38:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-19 16:38:45 --> Input Class Initialized
INFO - 2024-05-19 16:38:45 --> Language Class Initialized
INFO - 2024-05-19 16:38:45 --> Loader Class Initialized
INFO - 2024-05-19 16:38:45 --> Helper loaded: url_helper
INFO - 2024-05-19 16:38:45 --> Helper loaded: file_helper
INFO - 2024-05-19 16:38:45 --> Helper loaded: html_helper
INFO - 2024-05-19 16:38:45 --> Helper loaded: text_helper
INFO - 2024-05-19 16:38:45 --> Helper loaded: form_helper
INFO - 2024-05-19 16:38:45 --> Helper loaded: lang_helper
INFO - 2024-05-19 16:38:45 --> Helper loaded: security_helper
INFO - 2024-05-19 16:38:45 --> Helper loaded: cookie_helper
INFO - 2024-05-19 16:38:45 --> Database Driver Class Initialized
INFO - 2024-05-19 16:38:45 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-19 16:38:45 --> Parser Class Initialized
INFO - 2024-05-19 16:38:45 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-05-19 16:38:45 --> Pagination Class Initialized
INFO - 2024-05-19 16:38:45 --> Form Validation Class Initialized
INFO - 2024-05-19 16:38:45 --> Controller Class Initialized
DEBUG - 2024-05-19 16:38:45 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-05-19 16:38:45 --> Session class already loaded. Second attempt ignored.
INFO - 2024-05-19 16:38:45 --> Model Class Initialized
ERROR - 2024-05-19 16:38:57 --> $config['composer_autoload'] is set to TRUE but E:\xampp\htdocs\maurnaturo\application\vendor/autoload.php was not found.
INFO - 2024-05-19 16:38:57 --> Config Class Initialized
INFO - 2024-05-19 16:38:57 --> Hooks Class Initialized
DEBUG - 2024-05-19 16:38:57 --> UTF-8 Support Enabled
INFO - 2024-05-19 16:38:57 --> Utf8 Class Initialized
INFO - 2024-05-19 16:38:57 --> URI Class Initialized
INFO - 2024-05-19 16:38:57 --> Router Class Initialized
INFO - 2024-05-19 16:38:57 --> Output Class Initialized
INFO - 2024-05-19 16:38:57 --> Security Class Initialized
DEBUG - 2024-05-19 16:38:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-19 16:38:57 --> Input Class Initialized
INFO - 2024-05-19 16:38:57 --> Language Class Initialized
INFO - 2024-05-19 16:38:57 --> Loader Class Initialized
INFO - 2024-05-19 16:38:57 --> Helper loaded: url_helper
INFO - 2024-05-19 16:38:57 --> Helper loaded: file_helper
INFO - 2024-05-19 16:38:57 --> Helper loaded: html_helper
INFO - 2024-05-19 16:38:57 --> Helper loaded: text_helper
INFO - 2024-05-19 16:38:57 --> Helper loaded: form_helper
INFO - 2024-05-19 16:38:57 --> Helper loaded: lang_helper
INFO - 2024-05-19 16:38:57 --> Helper loaded: security_helper
INFO - 2024-05-19 16:38:57 --> Helper loaded: cookie_helper
INFO - 2024-05-19 16:38:57 --> Database Driver Class Initialized
INFO - 2024-05-19 16:38:57 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-19 16:38:57 --> Parser Class Initialized
INFO - 2024-05-19 16:38:57 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-05-19 16:38:57 --> Pagination Class Initialized
INFO - 2024-05-19 16:38:57 --> Form Validation Class Initialized
INFO - 2024-05-19 16:38:57 --> Controller Class Initialized
DEBUG - 2024-05-19 16:38:57 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-05-19 16:38:57 --> Session class already loaded. Second attempt ignored.
INFO - 2024-05-19 16:38:57 --> Model Class Initialized
ERROR - 2024-05-19 16:40:38 --> $config['composer_autoload'] is set to TRUE but E:\xampp\htdocs\maurnaturo\application\vendor/autoload.php was not found.
INFO - 2024-05-19 16:40:38 --> Config Class Initialized
INFO - 2024-05-19 16:40:38 --> Hooks Class Initialized
DEBUG - 2024-05-19 16:40:38 --> UTF-8 Support Enabled
INFO - 2024-05-19 16:40:38 --> Utf8 Class Initialized
INFO - 2024-05-19 16:40:38 --> URI Class Initialized
INFO - 2024-05-19 16:40:38 --> Router Class Initialized
INFO - 2024-05-19 16:40:38 --> Output Class Initialized
INFO - 2024-05-19 16:40:38 --> Security Class Initialized
DEBUG - 2024-05-19 16:40:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-19 16:40:38 --> Input Class Initialized
INFO - 2024-05-19 16:40:38 --> Language Class Initialized
INFO - 2024-05-19 16:40:38 --> Loader Class Initialized
INFO - 2024-05-19 16:40:38 --> Helper loaded: url_helper
INFO - 2024-05-19 16:40:38 --> Helper loaded: file_helper
INFO - 2024-05-19 16:40:38 --> Helper loaded: html_helper
INFO - 2024-05-19 16:40:38 --> Helper loaded: text_helper
INFO - 2024-05-19 16:40:38 --> Helper loaded: form_helper
INFO - 2024-05-19 16:40:38 --> Helper loaded: lang_helper
INFO - 2024-05-19 16:40:38 --> Helper loaded: security_helper
INFO - 2024-05-19 16:40:38 --> Helper loaded: cookie_helper
INFO - 2024-05-19 16:40:38 --> Database Driver Class Initialized
INFO - 2024-05-19 16:40:38 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-19 16:40:38 --> Parser Class Initialized
INFO - 2024-05-19 16:40:38 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-05-19 16:40:38 --> Pagination Class Initialized
INFO - 2024-05-19 16:40:38 --> Form Validation Class Initialized
INFO - 2024-05-19 16:40:38 --> Controller Class Initialized
DEBUG - 2024-05-19 16:40:38 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-05-19 16:40:38 --> Session class already loaded. Second attempt ignored.
INFO - 2024-05-19 16:40:38 --> Model Class Initialized
ERROR - 2024-05-19 16:40:45 --> $config['composer_autoload'] is set to TRUE but E:\xampp\htdocs\maurnaturo\application\vendor/autoload.php was not found.
INFO - 2024-05-19 16:40:45 --> Config Class Initialized
INFO - 2024-05-19 16:40:45 --> Hooks Class Initialized
DEBUG - 2024-05-19 16:40:45 --> UTF-8 Support Enabled
INFO - 2024-05-19 16:40:45 --> Utf8 Class Initialized
INFO - 2024-05-19 16:40:45 --> URI Class Initialized
INFO - 2024-05-19 16:40:45 --> Router Class Initialized
INFO - 2024-05-19 16:40:45 --> Output Class Initialized
INFO - 2024-05-19 16:40:45 --> Security Class Initialized
DEBUG - 2024-05-19 16:40:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-19 16:40:45 --> Input Class Initialized
INFO - 2024-05-19 16:40:45 --> Language Class Initialized
INFO - 2024-05-19 16:40:45 --> Loader Class Initialized
INFO - 2024-05-19 16:40:45 --> Helper loaded: url_helper
INFO - 2024-05-19 16:40:45 --> Helper loaded: file_helper
INFO - 2024-05-19 16:40:45 --> Helper loaded: html_helper
INFO - 2024-05-19 16:40:45 --> Helper loaded: text_helper
INFO - 2024-05-19 16:40:45 --> Helper loaded: form_helper
INFO - 2024-05-19 16:40:45 --> Helper loaded: lang_helper
INFO - 2024-05-19 16:40:45 --> Helper loaded: security_helper
INFO - 2024-05-19 16:40:45 --> Helper loaded: cookie_helper
INFO - 2024-05-19 16:40:45 --> Database Driver Class Initialized
INFO - 2024-05-19 16:40:45 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-19 16:40:45 --> Parser Class Initialized
INFO - 2024-05-19 16:40:45 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-05-19 16:40:45 --> Pagination Class Initialized
INFO - 2024-05-19 16:40:45 --> Form Validation Class Initialized
INFO - 2024-05-19 16:40:45 --> Controller Class Initialized
DEBUG - 2024-05-19 16:40:45 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-05-19 16:40:45 --> Session class already loaded. Second attempt ignored.
INFO - 2024-05-19 16:40:45 --> Model Class Initialized
ERROR - 2024-05-19 16:43:48 --> $config['composer_autoload'] is set to TRUE but E:\xampp\htdocs\maurnaturo\application\vendor/autoload.php was not found.
INFO - 2024-05-19 16:43:48 --> Config Class Initialized
INFO - 2024-05-19 16:43:48 --> Hooks Class Initialized
DEBUG - 2024-05-19 16:43:48 --> UTF-8 Support Enabled
INFO - 2024-05-19 16:43:48 --> Utf8 Class Initialized
INFO - 2024-05-19 16:43:48 --> URI Class Initialized
INFO - 2024-05-19 16:43:48 --> Router Class Initialized
INFO - 2024-05-19 16:43:48 --> Output Class Initialized
INFO - 2024-05-19 16:43:48 --> Security Class Initialized
DEBUG - 2024-05-19 16:43:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-19 16:43:48 --> Input Class Initialized
INFO - 2024-05-19 16:43:48 --> Language Class Initialized
INFO - 2024-05-19 16:43:48 --> Loader Class Initialized
INFO - 2024-05-19 16:43:48 --> Helper loaded: url_helper
INFO - 2024-05-19 16:43:48 --> Helper loaded: file_helper
INFO - 2024-05-19 16:43:48 --> Helper loaded: html_helper
INFO - 2024-05-19 16:43:48 --> Helper loaded: text_helper
INFO - 2024-05-19 16:43:48 --> Helper loaded: form_helper
INFO - 2024-05-19 16:43:48 --> Helper loaded: lang_helper
INFO - 2024-05-19 16:43:48 --> Helper loaded: security_helper
INFO - 2024-05-19 16:43:48 --> Helper loaded: cookie_helper
INFO - 2024-05-19 16:43:48 --> Database Driver Class Initialized
INFO - 2024-05-19 16:43:48 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-19 16:43:48 --> Parser Class Initialized
INFO - 2024-05-19 16:43:48 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-05-19 16:43:48 --> Pagination Class Initialized
INFO - 2024-05-19 16:43:48 --> Form Validation Class Initialized
INFO - 2024-05-19 16:43:48 --> Controller Class Initialized
DEBUG - 2024-05-19 16:43:48 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-05-19 16:43:48 --> Session class already loaded. Second attempt ignored.
INFO - 2024-05-19 16:43:48 --> Model Class Initialized
ERROR - 2024-05-19 17:02:45 --> $config['composer_autoload'] is set to TRUE but E:\xampp\htdocs\maurnaturo\application\vendor/autoload.php was not found.
INFO - 2024-05-19 17:02:45 --> Config Class Initialized
INFO - 2024-05-19 17:02:45 --> Hooks Class Initialized
DEBUG - 2024-05-19 17:02:45 --> UTF-8 Support Enabled
INFO - 2024-05-19 17:02:45 --> Utf8 Class Initialized
INFO - 2024-05-19 17:02:45 --> URI Class Initialized
INFO - 2024-05-19 17:02:45 --> Router Class Initialized
INFO - 2024-05-19 17:02:45 --> Output Class Initialized
INFO - 2024-05-19 17:02:45 --> Security Class Initialized
DEBUG - 2024-05-19 17:02:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-19 17:02:45 --> Input Class Initialized
INFO - 2024-05-19 17:02:45 --> Language Class Initialized
INFO - 2024-05-19 17:02:45 --> Loader Class Initialized
INFO - 2024-05-19 17:02:45 --> Helper loaded: url_helper
INFO - 2024-05-19 17:02:45 --> Helper loaded: file_helper
INFO - 2024-05-19 17:02:45 --> Helper loaded: html_helper
INFO - 2024-05-19 17:02:45 --> Helper loaded: text_helper
INFO - 2024-05-19 17:02:45 --> Helper loaded: form_helper
INFO - 2024-05-19 17:02:45 --> Helper loaded: lang_helper
INFO - 2024-05-19 17:02:45 --> Helper loaded: security_helper
INFO - 2024-05-19 17:02:45 --> Helper loaded: cookie_helper
INFO - 2024-05-19 17:02:45 --> Database Driver Class Initialized
INFO - 2024-05-19 17:02:45 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-19 17:02:45 --> Parser Class Initialized
INFO - 2024-05-19 17:02:45 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-05-19 17:02:45 --> Pagination Class Initialized
INFO - 2024-05-19 17:02:45 --> Form Validation Class Initialized
INFO - 2024-05-19 17:02:45 --> Controller Class Initialized
DEBUG - 2024-05-19 17:02:45 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-05-19 17:02:45 --> Session class already loaded. Second attempt ignored.
INFO - 2024-05-19 17:02:45 --> Model Class Initialized
ERROR - 2024-05-19 17:03:41 --> $config['composer_autoload'] is set to TRUE but E:\xampp\htdocs\maurnaturo\application\vendor/autoload.php was not found.
INFO - 2024-05-19 17:03:41 --> Config Class Initialized
INFO - 2024-05-19 17:03:41 --> Hooks Class Initialized
DEBUG - 2024-05-19 17:03:41 --> UTF-8 Support Enabled
INFO - 2024-05-19 17:03:41 --> Utf8 Class Initialized
INFO - 2024-05-19 17:03:41 --> URI Class Initialized
INFO - 2024-05-19 17:03:41 --> Router Class Initialized
INFO - 2024-05-19 17:03:41 --> Output Class Initialized
INFO - 2024-05-19 17:03:41 --> Security Class Initialized
DEBUG - 2024-05-19 17:03:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-19 17:03:41 --> Input Class Initialized
INFO - 2024-05-19 17:03:41 --> Language Class Initialized
INFO - 2024-05-19 17:03:41 --> Loader Class Initialized
INFO - 2024-05-19 17:03:41 --> Helper loaded: url_helper
INFO - 2024-05-19 17:03:41 --> Helper loaded: file_helper
INFO - 2024-05-19 17:03:41 --> Helper loaded: html_helper
INFO - 2024-05-19 17:03:41 --> Helper loaded: text_helper
INFO - 2024-05-19 17:03:41 --> Helper loaded: form_helper
INFO - 2024-05-19 17:03:41 --> Helper loaded: lang_helper
INFO - 2024-05-19 17:03:41 --> Helper loaded: security_helper
INFO - 2024-05-19 17:03:41 --> Helper loaded: cookie_helper
INFO - 2024-05-19 17:03:41 --> Database Driver Class Initialized
INFO - 2024-05-19 17:03:41 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-19 17:03:41 --> Parser Class Initialized
INFO - 2024-05-19 17:03:41 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-05-19 17:03:41 --> Pagination Class Initialized
INFO - 2024-05-19 17:03:41 --> Form Validation Class Initialized
INFO - 2024-05-19 17:03:41 --> Controller Class Initialized
DEBUG - 2024-05-19 17:03:41 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-05-19 17:03:41 --> Session class already loaded. Second attempt ignored.
INFO - 2024-05-19 17:03:41 --> Model Class Initialized
INFO - 2024-05-19 17:03:41 --> Model Class Initialized
DEBUG - 2024-05-19 17:03:41 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-05-19 17:03:41 --> Session class already loaded. Second attempt ignored.
INFO - 2024-05-19 17:03:41 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\payments/add_payment_form.php
DEBUG - 2024-05-19 17:03:41 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-05-19 17:03:41 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\include/top_menu.php
INFO - 2024-05-19 17:03:41 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\include/admin_loggedin_info.php
INFO - 2024-05-19 17:03:41 --> Model Class Initialized
INFO - 2024-05-19 17:03:41 --> Model Class Initialized
INFO - 2024-05-19 17:03:41 --> Model Class Initialized
INFO - 2024-05-19 17:03:41 --> Model Class Initialized
INFO - 2024-05-19 17:03:43 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\include/admin_header.php
INFO - 2024-05-19 17:03:43 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\include/admin_footer.php
INFO - 2024-05-19 17:03:43 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\admin_html_template.php
INFO - 2024-05-19 17:03:43 --> Final output sent to browser
DEBUG - 2024-05-19 17:03:43 --> Total execution time: 1.9160
ERROR - 2024-05-19 17:04:38 --> $config['composer_autoload'] is set to TRUE but E:\xampp\htdocs\maurnaturo\application\vendor/autoload.php was not found.
INFO - 2024-05-19 17:04:38 --> Config Class Initialized
INFO - 2024-05-19 17:04:38 --> Hooks Class Initialized
DEBUG - 2024-05-19 17:04:38 --> UTF-8 Support Enabled
INFO - 2024-05-19 17:04:38 --> Utf8 Class Initialized
INFO - 2024-05-19 17:04:38 --> URI Class Initialized
INFO - 2024-05-19 17:04:38 --> Router Class Initialized
INFO - 2024-05-19 17:04:38 --> Output Class Initialized
INFO - 2024-05-19 17:04:38 --> Security Class Initialized
DEBUG - 2024-05-19 17:04:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-19 17:04:38 --> Input Class Initialized
INFO - 2024-05-19 17:04:38 --> Language Class Initialized
INFO - 2024-05-19 17:04:38 --> Loader Class Initialized
INFO - 2024-05-19 17:04:38 --> Helper loaded: url_helper
INFO - 2024-05-19 17:04:38 --> Helper loaded: file_helper
INFO - 2024-05-19 17:04:38 --> Helper loaded: html_helper
INFO - 2024-05-19 17:04:38 --> Helper loaded: text_helper
INFO - 2024-05-19 17:04:38 --> Helper loaded: form_helper
INFO - 2024-05-19 17:04:38 --> Helper loaded: lang_helper
INFO - 2024-05-19 17:04:38 --> Helper loaded: security_helper
INFO - 2024-05-19 17:04:38 --> Helper loaded: cookie_helper
INFO - 2024-05-19 17:04:38 --> Database Driver Class Initialized
INFO - 2024-05-19 17:04:38 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-19 17:04:38 --> Parser Class Initialized
INFO - 2024-05-19 17:04:38 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-05-19 17:04:38 --> Pagination Class Initialized
INFO - 2024-05-19 17:04:38 --> Form Validation Class Initialized
INFO - 2024-05-19 17:04:38 --> Controller Class Initialized
DEBUG - 2024-05-19 17:04:38 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-05-19 17:04:38 --> Session class already loaded. Second attempt ignored.
INFO - 2024-05-19 17:04:38 --> Model Class Initialized
DEBUG - 2024-05-19 17:04:38 --> Lpayments class already loaded. Second attempt ignored.
INFO - 2024-05-19 17:04:38 --> Model Class Initialized
INFO - 2024-05-19 17:04:38 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\payments/payment.php
DEBUG - 2024-05-19 17:04:38 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-05-19 17:04:38 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\include/top_menu.php
INFO - 2024-05-19 17:04:38 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\include/admin_loggedin_info.php
INFO - 2024-05-19 17:04:38 --> Model Class Initialized
INFO - 2024-05-19 17:04:38 --> Model Class Initialized
INFO - 2024-05-19 17:04:38 --> Model Class Initialized
INFO - 2024-05-19 17:04:39 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\include/admin_header.php
INFO - 2024-05-19 17:04:39 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\include/admin_footer.php
INFO - 2024-05-19 17:04:39 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\admin_html_template.php
INFO - 2024-05-19 17:04:39 --> Final output sent to browser
DEBUG - 2024-05-19 17:04:39 --> Total execution time: 1.3552
ERROR - 2024-05-19 17:04:40 --> $config['composer_autoload'] is set to TRUE but E:\xampp\htdocs\maurnaturo\application\vendor/autoload.php was not found.
INFO - 2024-05-19 17:04:40 --> Config Class Initialized
INFO - 2024-05-19 17:04:40 --> Hooks Class Initialized
DEBUG - 2024-05-19 17:04:40 --> UTF-8 Support Enabled
INFO - 2024-05-19 17:04:40 --> Utf8 Class Initialized
INFO - 2024-05-19 17:04:40 --> URI Class Initialized
INFO - 2024-05-19 17:04:40 --> Router Class Initialized
INFO - 2024-05-19 17:04:40 --> Output Class Initialized
INFO - 2024-05-19 17:04:40 --> Security Class Initialized
DEBUG - 2024-05-19 17:04:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-19 17:04:40 --> Input Class Initialized
INFO - 2024-05-19 17:04:40 --> Language Class Initialized
INFO - 2024-05-19 17:04:40 --> Loader Class Initialized
INFO - 2024-05-19 17:04:40 --> Helper loaded: url_helper
INFO - 2024-05-19 17:04:40 --> Helper loaded: file_helper
INFO - 2024-05-19 17:04:40 --> Helper loaded: html_helper
INFO - 2024-05-19 17:04:40 --> Helper loaded: text_helper
INFO - 2024-05-19 17:04:40 --> Helper loaded: form_helper
INFO - 2024-05-19 17:04:40 --> Helper loaded: lang_helper
INFO - 2024-05-19 17:04:40 --> Helper loaded: security_helper
INFO - 2024-05-19 17:04:40 --> Helper loaded: cookie_helper
INFO - 2024-05-19 17:04:40 --> Database Driver Class Initialized
INFO - 2024-05-19 17:04:40 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-19 17:04:40 --> Parser Class Initialized
INFO - 2024-05-19 17:04:40 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-05-19 17:04:40 --> Pagination Class Initialized
INFO - 2024-05-19 17:04:40 --> Form Validation Class Initialized
INFO - 2024-05-19 17:04:40 --> Controller Class Initialized
DEBUG - 2024-05-19 17:04:40 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-05-19 17:04:40 --> Session class already loaded. Second attempt ignored.
INFO - 2024-05-19 17:04:40 --> Model Class Initialized
INFO - 2024-05-19 17:04:40 --> Final output sent to browser
DEBUG - 2024-05-19 17:04:40 --> Total execution time: 0.0902
ERROR - 2024-05-19 17:04:51 --> $config['composer_autoload'] is set to TRUE but E:\xampp\htdocs\maurnaturo\application\vendor/autoload.php was not found.
INFO - 2024-05-19 17:04:51 --> Config Class Initialized
INFO - 2024-05-19 17:04:51 --> Hooks Class Initialized
DEBUG - 2024-05-19 17:04:51 --> UTF-8 Support Enabled
INFO - 2024-05-19 17:04:51 --> Utf8 Class Initialized
INFO - 2024-05-19 17:04:51 --> URI Class Initialized
INFO - 2024-05-19 17:04:51 --> Router Class Initialized
INFO - 2024-05-19 17:04:51 --> Output Class Initialized
INFO - 2024-05-19 17:04:51 --> Security Class Initialized
DEBUG - 2024-05-19 17:04:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-19 17:04:51 --> Input Class Initialized
INFO - 2024-05-19 17:04:51 --> Language Class Initialized
INFO - 2024-05-19 17:04:51 --> Loader Class Initialized
INFO - 2024-05-19 17:04:51 --> Helper loaded: url_helper
INFO - 2024-05-19 17:04:51 --> Helper loaded: file_helper
INFO - 2024-05-19 17:04:51 --> Helper loaded: html_helper
INFO - 2024-05-19 17:04:51 --> Helper loaded: text_helper
INFO - 2024-05-19 17:04:51 --> Helper loaded: form_helper
INFO - 2024-05-19 17:04:51 --> Helper loaded: lang_helper
INFO - 2024-05-19 17:04:51 --> Helper loaded: security_helper
INFO - 2024-05-19 17:04:51 --> Helper loaded: cookie_helper
INFO - 2024-05-19 17:04:52 --> Database Driver Class Initialized
INFO - 2024-05-19 17:04:52 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-19 17:04:52 --> Parser Class Initialized
INFO - 2024-05-19 17:04:52 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-05-19 17:04:52 --> Pagination Class Initialized
INFO - 2024-05-19 17:04:52 --> Form Validation Class Initialized
INFO - 2024-05-19 17:04:52 --> Controller Class Initialized
INFO - 2024-05-19 17:04:52 --> Model Class Initialized
DEBUG - 2024-05-19 17:04:52 --> Session class already loaded. Second attempt ignored.
INFO - 2024-05-19 17:04:52 --> Final output sent to browser
DEBUG - 2024-05-19 17:04:52 --> Total execution time: 0.0645
ERROR - 2024-05-19 17:05:11 --> $config['composer_autoload'] is set to TRUE but E:\xampp\htdocs\maurnaturo\application\vendor/autoload.php was not found.
INFO - 2024-05-19 17:05:11 --> Config Class Initialized
INFO - 2024-05-19 17:05:11 --> Hooks Class Initialized
DEBUG - 2024-05-19 17:05:11 --> UTF-8 Support Enabled
INFO - 2024-05-19 17:05:11 --> Utf8 Class Initialized
INFO - 2024-05-19 17:05:11 --> URI Class Initialized
INFO - 2024-05-19 17:05:11 --> Router Class Initialized
INFO - 2024-05-19 17:05:11 --> Output Class Initialized
INFO - 2024-05-19 17:05:11 --> Security Class Initialized
DEBUG - 2024-05-19 17:05:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-19 17:05:11 --> Input Class Initialized
INFO - 2024-05-19 17:05:11 --> Language Class Initialized
INFO - 2024-05-19 17:05:11 --> Loader Class Initialized
INFO - 2024-05-19 17:05:11 --> Helper loaded: url_helper
INFO - 2024-05-19 17:05:11 --> Helper loaded: file_helper
INFO - 2024-05-19 17:05:11 --> Helper loaded: html_helper
INFO - 2024-05-19 17:05:11 --> Helper loaded: text_helper
INFO - 2024-05-19 17:05:11 --> Helper loaded: form_helper
INFO - 2024-05-19 17:05:11 --> Helper loaded: lang_helper
INFO - 2024-05-19 17:05:11 --> Helper loaded: security_helper
INFO - 2024-05-19 17:05:11 --> Helper loaded: cookie_helper
INFO - 2024-05-19 17:05:11 --> Database Driver Class Initialized
INFO - 2024-05-19 17:05:11 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-19 17:05:11 --> Parser Class Initialized
INFO - 2024-05-19 17:05:11 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-05-19 17:05:11 --> Pagination Class Initialized
INFO - 2024-05-19 17:05:11 --> Form Validation Class Initialized
INFO - 2024-05-19 17:05:11 --> Controller Class Initialized
DEBUG - 2024-05-19 17:05:11 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-05-19 17:05:11 --> Session class already loaded. Second attempt ignored.
INFO - 2024-05-19 17:05:11 --> Model Class Initialized
INFO - 2024-05-19 17:05:11 --> Final output sent to browser
DEBUG - 2024-05-19 17:05:11 --> Total execution time: 0.0917
ERROR - 2024-05-19 17:05:13 --> $config['composer_autoload'] is set to TRUE but E:\xampp\htdocs\maurnaturo\application\vendor/autoload.php was not found.
INFO - 2024-05-19 17:05:13 --> Config Class Initialized
INFO - 2024-05-19 17:05:13 --> Hooks Class Initialized
DEBUG - 2024-05-19 17:05:13 --> UTF-8 Support Enabled
INFO - 2024-05-19 17:05:13 --> Utf8 Class Initialized
INFO - 2024-05-19 17:05:13 --> URI Class Initialized
INFO - 2024-05-19 17:05:13 --> Router Class Initialized
INFO - 2024-05-19 17:05:13 --> Output Class Initialized
INFO - 2024-05-19 17:05:13 --> Security Class Initialized
DEBUG - 2024-05-19 17:05:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-19 17:05:13 --> Input Class Initialized
INFO - 2024-05-19 17:05:13 --> Language Class Initialized
INFO - 2024-05-19 17:05:13 --> Loader Class Initialized
INFO - 2024-05-19 17:05:13 --> Helper loaded: url_helper
INFO - 2024-05-19 17:05:13 --> Helper loaded: file_helper
INFO - 2024-05-19 17:05:13 --> Helper loaded: html_helper
INFO - 2024-05-19 17:05:13 --> Helper loaded: text_helper
INFO - 2024-05-19 17:05:13 --> Helper loaded: form_helper
INFO - 2024-05-19 17:05:13 --> Helper loaded: lang_helper
INFO - 2024-05-19 17:05:13 --> Helper loaded: security_helper
INFO - 2024-05-19 17:05:13 --> Helper loaded: cookie_helper
INFO - 2024-05-19 17:05:13 --> Database Driver Class Initialized
INFO - 2024-05-19 17:05:13 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-19 17:05:13 --> Parser Class Initialized
INFO - 2024-05-19 17:05:13 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-05-19 17:05:13 --> Pagination Class Initialized
INFO - 2024-05-19 17:05:13 --> Form Validation Class Initialized
INFO - 2024-05-19 17:05:13 --> Controller Class Initialized
DEBUG - 2024-05-19 17:05:13 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-05-19 17:05:13 --> Session class already loaded. Second attempt ignored.
INFO - 2024-05-19 17:05:13 --> Model Class Initialized
INFO - 2024-05-19 17:05:13 --> Model Class Initialized
DEBUG - 2024-05-19 17:05:13 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-05-19 17:05:13 --> Session class already loaded. Second attempt ignored.
INFO - 2024-05-19 17:05:13 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\payments/add_payment_form.php
DEBUG - 2024-05-19 17:05:13 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-05-19 17:05:13 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\include/top_menu.php
INFO - 2024-05-19 17:05:13 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\include/admin_loggedin_info.php
INFO - 2024-05-19 17:05:13 --> Model Class Initialized
INFO - 2024-05-19 17:05:13 --> Model Class Initialized
INFO - 2024-05-19 17:05:13 --> Model Class Initialized
INFO - 2024-05-19 17:05:13 --> Model Class Initialized
INFO - 2024-05-19 17:05:14 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\include/admin_header.php
INFO - 2024-05-19 17:05:14 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\include/admin_footer.php
INFO - 2024-05-19 17:05:14 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\admin_html_template.php
INFO - 2024-05-19 17:05:14 --> Final output sent to browser
DEBUG - 2024-05-19 17:05:14 --> Total execution time: 1.3047
ERROR - 2024-05-19 17:05:19 --> $config['composer_autoload'] is set to TRUE but E:\xampp\htdocs\maurnaturo\application\vendor/autoload.php was not found.
INFO - 2024-05-19 17:05:19 --> Config Class Initialized
INFO - 2024-05-19 17:05:19 --> Hooks Class Initialized
DEBUG - 2024-05-19 17:05:19 --> UTF-8 Support Enabled
INFO - 2024-05-19 17:05:19 --> Utf8 Class Initialized
INFO - 2024-05-19 17:05:19 --> URI Class Initialized
INFO - 2024-05-19 17:05:19 --> Router Class Initialized
INFO - 2024-05-19 17:05:19 --> Output Class Initialized
INFO - 2024-05-19 17:05:19 --> Security Class Initialized
DEBUG - 2024-05-19 17:05:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-19 17:05:19 --> Input Class Initialized
INFO - 2024-05-19 17:05:19 --> Language Class Initialized
INFO - 2024-05-19 17:05:19 --> Loader Class Initialized
INFO - 2024-05-19 17:05:19 --> Helper loaded: url_helper
INFO - 2024-05-19 17:05:19 --> Helper loaded: file_helper
INFO - 2024-05-19 17:05:19 --> Helper loaded: html_helper
INFO - 2024-05-19 17:05:19 --> Helper loaded: text_helper
INFO - 2024-05-19 17:05:19 --> Helper loaded: form_helper
INFO - 2024-05-19 17:05:19 --> Helper loaded: lang_helper
INFO - 2024-05-19 17:05:19 --> Helper loaded: security_helper
INFO - 2024-05-19 17:05:19 --> Helper loaded: cookie_helper
INFO - 2024-05-19 17:05:19 --> Database Driver Class Initialized
INFO - 2024-05-19 17:05:19 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-19 17:05:19 --> Parser Class Initialized
INFO - 2024-05-19 17:05:19 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-05-19 17:05:19 --> Pagination Class Initialized
INFO - 2024-05-19 17:05:19 --> Form Validation Class Initialized
INFO - 2024-05-19 17:05:19 --> Controller Class Initialized
DEBUG - 2024-05-19 17:05:19 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-05-19 17:05:19 --> Session class already loaded. Second attempt ignored.
INFO - 2024-05-19 17:05:19 --> Model Class Initialized
INFO - 2024-05-19 17:05:19 --> Model Class Initialized
DEBUG - 2024-05-19 17:05:19 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-05-19 17:05:19 --> Session class already loaded. Second attempt ignored.
INFO - 2024-05-19 17:05:19 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\payments/add_payment_form.php
DEBUG - 2024-05-19 17:05:19 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-05-19 17:05:19 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\include/top_menu.php
INFO - 2024-05-19 17:05:19 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\include/admin_loggedin_info.php
INFO - 2024-05-19 17:05:19 --> Model Class Initialized
INFO - 2024-05-19 17:05:19 --> Model Class Initialized
INFO - 2024-05-19 17:05:19 --> Model Class Initialized
INFO - 2024-05-19 17:05:19 --> Model Class Initialized
INFO - 2024-05-19 17:05:20 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\include/admin_header.php
INFO - 2024-05-19 17:05:20 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\include/admin_footer.php
INFO - 2024-05-19 17:05:20 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\admin_html_template.php
INFO - 2024-05-19 17:05:20 --> Final output sent to browser
DEBUG - 2024-05-19 17:05:20 --> Total execution time: 0.9993
ERROR - 2024-05-19 17:07:20 --> $config['composer_autoload'] is set to TRUE but E:\xampp\htdocs\maurnaturo\application\vendor/autoload.php was not found.
INFO - 2024-05-19 17:07:20 --> Config Class Initialized
INFO - 2024-05-19 17:07:20 --> Hooks Class Initialized
DEBUG - 2024-05-19 17:07:20 --> UTF-8 Support Enabled
INFO - 2024-05-19 17:07:20 --> Utf8 Class Initialized
INFO - 2024-05-19 17:07:20 --> URI Class Initialized
INFO - 2024-05-19 17:07:20 --> Router Class Initialized
INFO - 2024-05-19 17:07:20 --> Output Class Initialized
INFO - 2024-05-19 17:07:20 --> Security Class Initialized
DEBUG - 2024-05-19 17:07:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-19 17:07:20 --> Input Class Initialized
INFO - 2024-05-19 17:07:20 --> Language Class Initialized
INFO - 2024-05-19 17:07:20 --> Loader Class Initialized
INFO - 2024-05-19 17:07:20 --> Helper loaded: url_helper
INFO - 2024-05-19 17:07:20 --> Helper loaded: file_helper
INFO - 2024-05-19 17:07:20 --> Helper loaded: html_helper
INFO - 2024-05-19 17:07:20 --> Helper loaded: text_helper
INFO - 2024-05-19 17:07:20 --> Helper loaded: form_helper
INFO - 2024-05-19 17:07:20 --> Helper loaded: lang_helper
INFO - 2024-05-19 17:07:20 --> Helper loaded: security_helper
INFO - 2024-05-19 17:07:20 --> Helper loaded: cookie_helper
INFO - 2024-05-19 17:07:20 --> Database Driver Class Initialized
INFO - 2024-05-19 17:07:20 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-19 17:07:20 --> Parser Class Initialized
INFO - 2024-05-19 17:07:20 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-05-19 17:07:20 --> Pagination Class Initialized
INFO - 2024-05-19 17:07:20 --> Form Validation Class Initialized
INFO - 2024-05-19 17:07:20 --> Controller Class Initialized
DEBUG - 2024-05-19 17:07:20 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-05-19 17:07:20 --> Session class already loaded. Second attempt ignored.
INFO - 2024-05-19 17:07:20 --> Model Class Initialized
INFO - 2024-05-19 17:07:20 --> Model Class Initialized
DEBUG - 2024-05-19 17:07:20 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-05-19 17:07:20 --> Session class already loaded. Second attempt ignored.
INFO - 2024-05-19 17:07:20 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\payments/add_payment_form.php
DEBUG - 2024-05-19 17:07:20 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-05-19 17:07:20 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\include/top_menu.php
INFO - 2024-05-19 17:07:20 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\include/admin_loggedin_info.php
INFO - 2024-05-19 17:07:20 --> Model Class Initialized
INFO - 2024-05-19 17:07:20 --> Model Class Initialized
INFO - 2024-05-19 17:07:20 --> Model Class Initialized
INFO - 2024-05-19 17:07:20 --> Model Class Initialized
INFO - 2024-05-19 17:07:21 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\include/admin_header.php
INFO - 2024-05-19 17:07:21 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\include/admin_footer.php
INFO - 2024-05-19 17:07:21 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\admin_html_template.php
INFO - 2024-05-19 17:07:21 --> Final output sent to browser
DEBUG - 2024-05-19 17:07:21 --> Total execution time: 1.2091
ERROR - 2024-05-19 17:07:31 --> $config['composer_autoload'] is set to TRUE but E:\xampp\htdocs\maurnaturo\application\vendor/autoload.php was not found.
INFO - 2024-05-19 17:07:31 --> Config Class Initialized
INFO - 2024-05-19 17:07:31 --> Hooks Class Initialized
DEBUG - 2024-05-19 17:07:31 --> UTF-8 Support Enabled
INFO - 2024-05-19 17:07:31 --> Utf8 Class Initialized
INFO - 2024-05-19 17:07:31 --> URI Class Initialized
INFO - 2024-05-19 17:07:31 --> Router Class Initialized
INFO - 2024-05-19 17:07:31 --> Output Class Initialized
INFO - 2024-05-19 17:07:31 --> Security Class Initialized
DEBUG - 2024-05-19 17:07:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-19 17:07:31 --> Input Class Initialized
INFO - 2024-05-19 17:07:31 --> Language Class Initialized
INFO - 2024-05-19 17:07:31 --> Loader Class Initialized
INFO - 2024-05-19 17:07:31 --> Helper loaded: url_helper
INFO - 2024-05-19 17:07:31 --> Helper loaded: file_helper
INFO - 2024-05-19 17:07:31 --> Helper loaded: html_helper
INFO - 2024-05-19 17:07:31 --> Helper loaded: text_helper
INFO - 2024-05-19 17:07:31 --> Helper loaded: form_helper
INFO - 2024-05-19 17:07:31 --> Helper loaded: lang_helper
INFO - 2024-05-19 17:07:31 --> Helper loaded: security_helper
INFO - 2024-05-19 17:07:31 --> Helper loaded: cookie_helper
INFO - 2024-05-19 17:07:31 --> Database Driver Class Initialized
INFO - 2024-05-19 17:07:31 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-19 17:07:31 --> Parser Class Initialized
INFO - 2024-05-19 17:07:31 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-05-19 17:07:31 --> Pagination Class Initialized
INFO - 2024-05-19 17:07:31 --> Form Validation Class Initialized
INFO - 2024-05-19 17:07:31 --> Controller Class Initialized
INFO - 2024-05-19 17:07:31 --> Model Class Initialized
DEBUG - 2024-05-19 17:07:31 --> Session class already loaded. Second attempt ignored.
ERROR - 2024-05-19 17:07:31 --> Severity: Warning --> Invalid argument supplied for foreach() E:\xampp\htdocs\maurnaturo\application\controllers\Cinvoice.php 616
INFO - 2024-05-19 17:07:31 --> Final output sent to browser
DEBUG - 2024-05-19 17:07:31 --> Total execution time: 0.0710
ERROR - 2024-05-19 17:07:32 --> $config['composer_autoload'] is set to TRUE but E:\xampp\htdocs\maurnaturo\application\vendor/autoload.php was not found.
INFO - 2024-05-19 17:07:32 --> Config Class Initialized
INFO - 2024-05-19 17:07:32 --> Hooks Class Initialized
DEBUG - 2024-05-19 17:07:32 --> UTF-8 Support Enabled
INFO - 2024-05-19 17:07:32 --> Utf8 Class Initialized
INFO - 2024-05-19 17:07:32 --> URI Class Initialized
INFO - 2024-05-19 17:07:32 --> Router Class Initialized
INFO - 2024-05-19 17:07:32 --> Output Class Initialized
INFO - 2024-05-19 17:07:32 --> Security Class Initialized
DEBUG - 2024-05-19 17:07:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-19 17:07:32 --> Input Class Initialized
INFO - 2024-05-19 17:07:32 --> Language Class Initialized
INFO - 2024-05-19 17:07:32 --> Loader Class Initialized
INFO - 2024-05-19 17:07:32 --> Helper loaded: url_helper
INFO - 2024-05-19 17:07:32 --> Helper loaded: file_helper
INFO - 2024-05-19 17:07:32 --> Helper loaded: html_helper
INFO - 2024-05-19 17:07:32 --> Helper loaded: text_helper
INFO - 2024-05-19 17:07:32 --> Helper loaded: form_helper
INFO - 2024-05-19 17:07:32 --> Helper loaded: lang_helper
INFO - 2024-05-19 17:07:32 --> Helper loaded: security_helper
INFO - 2024-05-19 17:07:32 --> Helper loaded: cookie_helper
INFO - 2024-05-19 17:07:32 --> Database Driver Class Initialized
INFO - 2024-05-19 17:07:32 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-19 17:07:32 --> Parser Class Initialized
INFO - 2024-05-19 17:07:32 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-05-19 17:07:32 --> Pagination Class Initialized
INFO - 2024-05-19 17:07:32 --> Form Validation Class Initialized
INFO - 2024-05-19 17:07:32 --> Controller Class Initialized
INFO - 2024-05-19 17:07:32 --> Model Class Initialized
DEBUG - 2024-05-19 17:07:32 --> Session class already loaded. Second attempt ignored.
ERROR - 2024-05-19 17:07:32 --> Severity: Warning --> Invalid argument supplied for foreach() E:\xampp\htdocs\maurnaturo\application\controllers\Cinvoice.php 616
INFO - 2024-05-19 17:07:32 --> Final output sent to browser
DEBUG - 2024-05-19 17:07:32 --> Total execution time: 0.0646
ERROR - 2024-05-19 17:07:36 --> $config['composer_autoload'] is set to TRUE but E:\xampp\htdocs\maurnaturo\application\vendor/autoload.php was not found.
INFO - 2024-05-19 17:07:36 --> Config Class Initialized
INFO - 2024-05-19 17:07:36 --> Hooks Class Initialized
DEBUG - 2024-05-19 17:07:36 --> UTF-8 Support Enabled
INFO - 2024-05-19 17:07:36 --> Utf8 Class Initialized
INFO - 2024-05-19 17:07:36 --> URI Class Initialized
INFO - 2024-05-19 17:07:36 --> Router Class Initialized
INFO - 2024-05-19 17:07:36 --> Output Class Initialized
INFO - 2024-05-19 17:07:36 --> Security Class Initialized
DEBUG - 2024-05-19 17:07:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-19 17:07:36 --> Input Class Initialized
INFO - 2024-05-19 17:07:36 --> Language Class Initialized
INFO - 2024-05-19 17:07:36 --> Loader Class Initialized
INFO - 2024-05-19 17:07:36 --> Helper loaded: url_helper
INFO - 2024-05-19 17:07:36 --> Helper loaded: file_helper
INFO - 2024-05-19 17:07:36 --> Helper loaded: html_helper
INFO - 2024-05-19 17:07:36 --> Helper loaded: text_helper
INFO - 2024-05-19 17:07:36 --> Helper loaded: form_helper
INFO - 2024-05-19 17:07:36 --> Helper loaded: lang_helper
INFO - 2024-05-19 17:07:36 --> Helper loaded: security_helper
INFO - 2024-05-19 17:07:36 --> Helper loaded: cookie_helper
INFO - 2024-05-19 17:07:36 --> Database Driver Class Initialized
INFO - 2024-05-19 17:07:36 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-19 17:07:36 --> Parser Class Initialized
INFO - 2024-05-19 17:07:36 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-05-19 17:07:36 --> Pagination Class Initialized
INFO - 2024-05-19 17:07:36 --> Form Validation Class Initialized
INFO - 2024-05-19 17:07:36 --> Controller Class Initialized
INFO - 2024-05-19 17:07:36 --> Model Class Initialized
DEBUG - 2024-05-19 17:07:36 --> Session class already loaded. Second attempt ignored.
ERROR - 2024-05-19 17:07:36 --> Severity: Warning --> Invalid argument supplied for foreach() E:\xampp\htdocs\maurnaturo\application\controllers\Cinvoice.php 616
INFO - 2024-05-19 17:07:36 --> Final output sent to browser
DEBUG - 2024-05-19 17:07:36 --> Total execution time: 0.0594
ERROR - 2024-05-19 17:07:43 --> $config['composer_autoload'] is set to TRUE but E:\xampp\htdocs\maurnaturo\application\vendor/autoload.php was not found.
INFO - 2024-05-19 17:07:43 --> Config Class Initialized
INFO - 2024-05-19 17:07:43 --> Hooks Class Initialized
DEBUG - 2024-05-19 17:07:43 --> UTF-8 Support Enabled
INFO - 2024-05-19 17:07:43 --> Utf8 Class Initialized
INFO - 2024-05-19 17:07:43 --> URI Class Initialized
INFO - 2024-05-19 17:07:43 --> Router Class Initialized
INFO - 2024-05-19 17:07:43 --> Output Class Initialized
INFO - 2024-05-19 17:07:43 --> Security Class Initialized
DEBUG - 2024-05-19 17:07:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-19 17:07:43 --> Input Class Initialized
INFO - 2024-05-19 17:07:43 --> Language Class Initialized
INFO - 2024-05-19 17:07:43 --> Loader Class Initialized
INFO - 2024-05-19 17:07:43 --> Helper loaded: url_helper
INFO - 2024-05-19 17:07:43 --> Helper loaded: file_helper
INFO - 2024-05-19 17:07:43 --> Helper loaded: html_helper
INFO - 2024-05-19 17:07:43 --> Helper loaded: text_helper
INFO - 2024-05-19 17:07:43 --> Helper loaded: form_helper
INFO - 2024-05-19 17:07:43 --> Helper loaded: lang_helper
INFO - 2024-05-19 17:07:43 --> Helper loaded: security_helper
INFO - 2024-05-19 17:07:43 --> Helper loaded: cookie_helper
INFO - 2024-05-19 17:07:43 --> Database Driver Class Initialized
INFO - 2024-05-19 17:07:43 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-19 17:07:43 --> Parser Class Initialized
INFO - 2024-05-19 17:07:43 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-05-19 17:07:43 --> Pagination Class Initialized
INFO - 2024-05-19 17:07:43 --> Form Validation Class Initialized
INFO - 2024-05-19 17:07:43 --> Controller Class Initialized
INFO - 2024-05-19 17:07:43 --> Model Class Initialized
DEBUG - 2024-05-19 17:07:43 --> Session class already loaded. Second attempt ignored.
INFO - 2024-05-19 17:07:43 --> Final output sent to browser
DEBUG - 2024-05-19 17:07:43 --> Total execution time: 0.0641
ERROR - 2024-05-19 17:07:43 --> $config['composer_autoload'] is set to TRUE but E:\xampp\htdocs\maurnaturo\application\vendor/autoload.php was not found.
INFO - 2024-05-19 17:07:43 --> Config Class Initialized
INFO - 2024-05-19 17:07:43 --> Hooks Class Initialized
DEBUG - 2024-05-19 17:07:43 --> UTF-8 Support Enabled
INFO - 2024-05-19 17:07:43 --> Utf8 Class Initialized
INFO - 2024-05-19 17:07:43 --> URI Class Initialized
INFO - 2024-05-19 17:07:43 --> Router Class Initialized
INFO - 2024-05-19 17:07:43 --> Output Class Initialized
INFO - 2024-05-19 17:07:44 --> Security Class Initialized
DEBUG - 2024-05-19 17:07:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-19 17:07:44 --> Input Class Initialized
INFO - 2024-05-19 17:07:44 --> Language Class Initialized
INFO - 2024-05-19 17:07:44 --> Loader Class Initialized
INFO - 2024-05-19 17:07:44 --> Helper loaded: url_helper
INFO - 2024-05-19 17:07:44 --> Helper loaded: file_helper
INFO - 2024-05-19 17:07:44 --> Helper loaded: html_helper
INFO - 2024-05-19 17:07:44 --> Helper loaded: text_helper
INFO - 2024-05-19 17:07:44 --> Helper loaded: form_helper
INFO - 2024-05-19 17:07:44 --> Helper loaded: lang_helper
INFO - 2024-05-19 17:07:44 --> Helper loaded: security_helper
INFO - 2024-05-19 17:07:44 --> Helper loaded: cookie_helper
INFO - 2024-05-19 17:07:44 --> Database Driver Class Initialized
INFO - 2024-05-19 17:07:44 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-19 17:07:44 --> Parser Class Initialized
INFO - 2024-05-19 17:07:44 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-05-19 17:07:44 --> Pagination Class Initialized
INFO - 2024-05-19 17:07:44 --> Form Validation Class Initialized
INFO - 2024-05-19 17:07:44 --> Controller Class Initialized
INFO - 2024-05-19 17:07:44 --> Model Class Initialized
DEBUG - 2024-05-19 17:07:44 --> Session class already loaded. Second attempt ignored.
INFO - 2024-05-19 17:07:44 --> Final output sent to browser
DEBUG - 2024-05-19 17:07:44 --> Total execution time: 0.0816
ERROR - 2024-05-19 17:07:44 --> $config['composer_autoload'] is set to TRUE but E:\xampp\htdocs\maurnaturo\application\vendor/autoload.php was not found.
INFO - 2024-05-19 17:07:44 --> Config Class Initialized
INFO - 2024-05-19 17:07:44 --> Hooks Class Initialized
DEBUG - 2024-05-19 17:07:44 --> UTF-8 Support Enabled
INFO - 2024-05-19 17:07:44 --> Utf8 Class Initialized
INFO - 2024-05-19 17:07:44 --> URI Class Initialized
INFO - 2024-05-19 17:07:44 --> Router Class Initialized
INFO - 2024-05-19 17:07:44 --> Output Class Initialized
INFO - 2024-05-19 17:07:44 --> Security Class Initialized
DEBUG - 2024-05-19 17:07:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-19 17:07:44 --> Input Class Initialized
INFO - 2024-05-19 17:07:44 --> Language Class Initialized
INFO - 2024-05-19 17:07:44 --> Loader Class Initialized
INFO - 2024-05-19 17:07:44 --> Helper loaded: url_helper
INFO - 2024-05-19 17:07:44 --> Helper loaded: file_helper
INFO - 2024-05-19 17:07:44 --> Helper loaded: html_helper
INFO - 2024-05-19 17:07:44 --> Helper loaded: text_helper
INFO - 2024-05-19 17:07:44 --> Helper loaded: form_helper
INFO - 2024-05-19 17:07:44 --> Helper loaded: lang_helper
INFO - 2024-05-19 17:07:44 --> Helper loaded: security_helper
INFO - 2024-05-19 17:07:44 --> Helper loaded: cookie_helper
INFO - 2024-05-19 17:07:44 --> Database Driver Class Initialized
INFO - 2024-05-19 17:07:44 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-19 17:07:44 --> Parser Class Initialized
INFO - 2024-05-19 17:07:44 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-05-19 17:07:44 --> Pagination Class Initialized
INFO - 2024-05-19 17:07:44 --> Form Validation Class Initialized
INFO - 2024-05-19 17:07:44 --> Controller Class Initialized
INFO - 2024-05-19 17:07:44 --> Model Class Initialized
DEBUG - 2024-05-19 17:07:44 --> Session class already loaded. Second attempt ignored.
INFO - 2024-05-19 17:07:44 --> Final output sent to browser
DEBUG - 2024-05-19 17:07:44 --> Total execution time: 0.0827
ERROR - 2024-05-19 17:07:45 --> $config['composer_autoload'] is set to TRUE but E:\xampp\htdocs\maurnaturo\application\vendor/autoload.php was not found.
INFO - 2024-05-19 17:07:45 --> Config Class Initialized
INFO - 2024-05-19 17:07:45 --> Hooks Class Initialized
DEBUG - 2024-05-19 17:07:45 --> UTF-8 Support Enabled
INFO - 2024-05-19 17:07:45 --> Utf8 Class Initialized
INFO - 2024-05-19 17:07:45 --> URI Class Initialized
INFO - 2024-05-19 17:07:45 --> Router Class Initialized
INFO - 2024-05-19 17:07:45 --> Output Class Initialized
INFO - 2024-05-19 17:07:45 --> Security Class Initialized
DEBUG - 2024-05-19 17:07:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-19 17:07:45 --> Input Class Initialized
INFO - 2024-05-19 17:07:45 --> Language Class Initialized
INFO - 2024-05-19 17:07:45 --> Loader Class Initialized
INFO - 2024-05-19 17:07:45 --> Helper loaded: url_helper
INFO - 2024-05-19 17:07:45 --> Helper loaded: file_helper
INFO - 2024-05-19 17:07:45 --> Helper loaded: html_helper
INFO - 2024-05-19 17:07:45 --> Helper loaded: text_helper
INFO - 2024-05-19 17:07:45 --> Helper loaded: form_helper
INFO - 2024-05-19 17:07:45 --> Helper loaded: lang_helper
INFO - 2024-05-19 17:07:45 --> Helper loaded: security_helper
INFO - 2024-05-19 17:07:45 --> Helper loaded: cookie_helper
INFO - 2024-05-19 17:07:45 --> Database Driver Class Initialized
INFO - 2024-05-19 17:07:45 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-19 17:07:45 --> Parser Class Initialized
INFO - 2024-05-19 17:07:45 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-05-19 17:07:45 --> Pagination Class Initialized
INFO - 2024-05-19 17:07:45 --> Form Validation Class Initialized
INFO - 2024-05-19 17:07:45 --> Controller Class Initialized
INFO - 2024-05-19 17:07:45 --> Model Class Initialized
DEBUG - 2024-05-19 17:07:45 --> Session class already loaded. Second attempt ignored.
INFO - 2024-05-19 17:07:45 --> Final output sent to browser
DEBUG - 2024-05-19 17:07:45 --> Total execution time: 0.0607
ERROR - 2024-05-19 17:07:46 --> $config['composer_autoload'] is set to TRUE but E:\xampp\htdocs\maurnaturo\application\vendor/autoload.php was not found.
INFO - 2024-05-19 17:07:46 --> Config Class Initialized
INFO - 2024-05-19 17:07:46 --> Hooks Class Initialized
DEBUG - 2024-05-19 17:07:46 --> UTF-8 Support Enabled
INFO - 2024-05-19 17:07:46 --> Utf8 Class Initialized
INFO - 2024-05-19 17:07:46 --> URI Class Initialized
INFO - 2024-05-19 17:07:46 --> Router Class Initialized
INFO - 2024-05-19 17:07:46 --> Output Class Initialized
INFO - 2024-05-19 17:07:46 --> Security Class Initialized
DEBUG - 2024-05-19 17:07:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-19 17:07:46 --> Input Class Initialized
INFO - 2024-05-19 17:07:46 --> Language Class Initialized
INFO - 2024-05-19 17:07:46 --> Loader Class Initialized
INFO - 2024-05-19 17:07:46 --> Helper loaded: url_helper
INFO - 2024-05-19 17:07:46 --> Helper loaded: file_helper
INFO - 2024-05-19 17:07:46 --> Helper loaded: html_helper
INFO - 2024-05-19 17:07:46 --> Helper loaded: text_helper
INFO - 2024-05-19 17:07:46 --> Helper loaded: form_helper
INFO - 2024-05-19 17:07:46 --> Helper loaded: lang_helper
INFO - 2024-05-19 17:07:46 --> Helper loaded: security_helper
INFO - 2024-05-19 17:07:46 --> Helper loaded: cookie_helper
INFO - 2024-05-19 17:07:46 --> Database Driver Class Initialized
INFO - 2024-05-19 17:07:46 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-19 17:07:46 --> Parser Class Initialized
INFO - 2024-05-19 17:07:46 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-05-19 17:07:46 --> Pagination Class Initialized
INFO - 2024-05-19 17:07:46 --> Form Validation Class Initialized
INFO - 2024-05-19 17:07:46 --> Controller Class Initialized
INFO - 2024-05-19 17:07:46 --> Model Class Initialized
DEBUG - 2024-05-19 17:07:46 --> Session class already loaded. Second attempt ignored.
INFO - 2024-05-19 17:07:46 --> Final output sent to browser
DEBUG - 2024-05-19 17:07:46 --> Total execution time: 0.0637
ERROR - 2024-05-19 17:07:58 --> $config['composer_autoload'] is set to TRUE but E:\xampp\htdocs\maurnaturo\application\vendor/autoload.php was not found.
INFO - 2024-05-19 17:07:58 --> Config Class Initialized
INFO - 2024-05-19 17:07:58 --> Hooks Class Initialized
DEBUG - 2024-05-19 17:07:58 --> UTF-8 Support Enabled
INFO - 2024-05-19 17:07:58 --> Utf8 Class Initialized
INFO - 2024-05-19 17:07:58 --> URI Class Initialized
INFO - 2024-05-19 17:07:58 --> Router Class Initialized
INFO - 2024-05-19 17:07:58 --> Output Class Initialized
INFO - 2024-05-19 17:07:58 --> Security Class Initialized
DEBUG - 2024-05-19 17:07:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-19 17:07:58 --> Input Class Initialized
INFO - 2024-05-19 17:07:58 --> Language Class Initialized
INFO - 2024-05-19 17:07:58 --> Loader Class Initialized
INFO - 2024-05-19 17:07:58 --> Helper loaded: url_helper
INFO - 2024-05-19 17:07:58 --> Helper loaded: file_helper
INFO - 2024-05-19 17:07:58 --> Helper loaded: html_helper
INFO - 2024-05-19 17:07:58 --> Helper loaded: text_helper
INFO - 2024-05-19 17:07:58 --> Helper loaded: form_helper
INFO - 2024-05-19 17:07:58 --> Helper loaded: lang_helper
INFO - 2024-05-19 17:07:58 --> Helper loaded: security_helper
INFO - 2024-05-19 17:07:58 --> Helper loaded: cookie_helper
INFO - 2024-05-19 17:07:58 --> Database Driver Class Initialized
INFO - 2024-05-19 17:07:58 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-19 17:07:58 --> Parser Class Initialized
INFO - 2024-05-19 17:07:58 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-05-19 17:07:58 --> Pagination Class Initialized
INFO - 2024-05-19 17:07:58 --> Form Validation Class Initialized
INFO - 2024-05-19 17:07:58 --> Controller Class Initialized
DEBUG - 2024-05-19 17:07:58 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-05-19 17:07:58 --> Session class already loaded. Second attempt ignored.
INFO - 2024-05-19 17:07:58 --> Model Class Initialized
INFO - 2024-05-19 17:07:58 --> Final output sent to browser
DEBUG - 2024-05-19 17:07:58 --> Total execution time: 0.0934
ERROR - 2024-05-19 17:08:17 --> $config['composer_autoload'] is set to TRUE but E:\xampp\htdocs\maurnaturo\application\vendor/autoload.php was not found.
INFO - 2024-05-19 17:08:17 --> Config Class Initialized
INFO - 2024-05-19 17:08:17 --> Hooks Class Initialized
DEBUG - 2024-05-19 17:08:17 --> UTF-8 Support Enabled
INFO - 2024-05-19 17:08:17 --> Utf8 Class Initialized
INFO - 2024-05-19 17:08:17 --> URI Class Initialized
INFO - 2024-05-19 17:08:17 --> Router Class Initialized
INFO - 2024-05-19 17:08:17 --> Output Class Initialized
INFO - 2024-05-19 17:08:17 --> Security Class Initialized
DEBUG - 2024-05-19 17:08:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-19 17:08:17 --> Input Class Initialized
INFO - 2024-05-19 17:08:17 --> Language Class Initialized
INFO - 2024-05-19 17:08:17 --> Loader Class Initialized
INFO - 2024-05-19 17:08:17 --> Helper loaded: url_helper
INFO - 2024-05-19 17:08:17 --> Helper loaded: file_helper
INFO - 2024-05-19 17:08:17 --> Helper loaded: html_helper
INFO - 2024-05-19 17:08:17 --> Helper loaded: text_helper
INFO - 2024-05-19 17:08:17 --> Helper loaded: form_helper
INFO - 2024-05-19 17:08:17 --> Helper loaded: lang_helper
INFO - 2024-05-19 17:08:17 --> Helper loaded: security_helper
INFO - 2024-05-19 17:08:17 --> Helper loaded: cookie_helper
INFO - 2024-05-19 17:08:17 --> Database Driver Class Initialized
INFO - 2024-05-19 17:08:17 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-19 17:08:17 --> Parser Class Initialized
INFO - 2024-05-19 17:08:17 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-05-19 17:08:17 --> Pagination Class Initialized
INFO - 2024-05-19 17:08:17 --> Form Validation Class Initialized
INFO - 2024-05-19 17:08:17 --> Controller Class Initialized
DEBUG - 2024-05-19 17:08:17 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-05-19 17:08:17 --> Session class already loaded. Second attempt ignored.
INFO - 2024-05-19 17:08:17 --> Model Class Initialized
INFO - 2024-05-19 17:08:17 --> Final output sent to browser
DEBUG - 2024-05-19 17:08:17 --> Total execution time: 0.0841
ERROR - 2024-05-19 17:08:26 --> $config['composer_autoload'] is set to TRUE but E:\xampp\htdocs\maurnaturo\application\vendor/autoload.php was not found.
INFO - 2024-05-19 17:08:26 --> Config Class Initialized
INFO - 2024-05-19 17:08:26 --> Hooks Class Initialized
DEBUG - 2024-05-19 17:08:26 --> UTF-8 Support Enabled
INFO - 2024-05-19 17:08:26 --> Utf8 Class Initialized
INFO - 2024-05-19 17:08:26 --> URI Class Initialized
INFO - 2024-05-19 17:08:26 --> Router Class Initialized
INFO - 2024-05-19 17:08:26 --> Output Class Initialized
INFO - 2024-05-19 17:08:26 --> Security Class Initialized
DEBUG - 2024-05-19 17:08:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-19 17:08:26 --> Input Class Initialized
INFO - 2024-05-19 17:08:26 --> Language Class Initialized
INFO - 2024-05-19 17:08:26 --> Loader Class Initialized
INFO - 2024-05-19 17:08:26 --> Helper loaded: url_helper
INFO - 2024-05-19 17:08:26 --> Helper loaded: file_helper
INFO - 2024-05-19 17:08:26 --> Helper loaded: html_helper
INFO - 2024-05-19 17:08:26 --> Helper loaded: text_helper
INFO - 2024-05-19 17:08:26 --> Helper loaded: form_helper
INFO - 2024-05-19 17:08:26 --> Helper loaded: lang_helper
INFO - 2024-05-19 17:08:26 --> Helper loaded: security_helper
INFO - 2024-05-19 17:08:26 --> Helper loaded: cookie_helper
INFO - 2024-05-19 17:08:26 --> Database Driver Class Initialized
INFO - 2024-05-19 17:08:26 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-19 17:08:26 --> Parser Class Initialized
INFO - 2024-05-19 17:08:26 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-05-19 17:08:26 --> Pagination Class Initialized
INFO - 2024-05-19 17:08:26 --> Form Validation Class Initialized
INFO - 2024-05-19 17:08:26 --> Controller Class Initialized
DEBUG - 2024-05-19 17:08:26 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-05-19 17:08:26 --> Session class already loaded. Second attempt ignored.
INFO - 2024-05-19 17:08:26 --> Model Class Initialized
INFO - 2024-05-19 17:08:26 --> Model Class Initialized
DEBUG - 2024-05-19 17:08:26 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-05-19 17:08:26 --> Session class already loaded. Second attempt ignored.
INFO - 2024-05-19 17:08:26 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\payments/add_payment_form.php
DEBUG - 2024-05-19 17:08:26 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-05-19 17:08:26 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\include/top_menu.php
INFO - 2024-05-19 17:08:26 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\include/admin_loggedin_info.php
INFO - 2024-05-19 17:08:26 --> Model Class Initialized
INFO - 2024-05-19 17:08:26 --> Model Class Initialized
INFO - 2024-05-19 17:08:26 --> Model Class Initialized
INFO - 2024-05-19 17:08:26 --> Model Class Initialized
INFO - 2024-05-19 17:08:27 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\include/admin_header.php
INFO - 2024-05-19 17:08:27 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\include/admin_footer.php
INFO - 2024-05-19 17:08:27 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\admin_html_template.php
INFO - 2024-05-19 17:08:27 --> Final output sent to browser
DEBUG - 2024-05-19 17:08:27 --> Total execution time: 1.4343
ERROR - 2024-05-19 17:08:32 --> $config['composer_autoload'] is set to TRUE but E:\xampp\htdocs\maurnaturo\application\vendor/autoload.php was not found.
INFO - 2024-05-19 17:08:32 --> Config Class Initialized
INFO - 2024-05-19 17:08:32 --> Hooks Class Initialized
DEBUG - 2024-05-19 17:08:32 --> UTF-8 Support Enabled
INFO - 2024-05-19 17:08:32 --> Utf8 Class Initialized
INFO - 2024-05-19 17:08:32 --> URI Class Initialized
INFO - 2024-05-19 17:08:32 --> Router Class Initialized
INFO - 2024-05-19 17:08:32 --> Output Class Initialized
INFO - 2024-05-19 17:08:32 --> Security Class Initialized
DEBUG - 2024-05-19 17:08:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-19 17:08:32 --> Input Class Initialized
INFO - 2024-05-19 17:08:32 --> Language Class Initialized
ERROR - 2024-05-19 17:08:32 --> 404 Page Not Found: Assets/plugins
ERROR - 2024-05-19 17:08:32 --> $config['composer_autoload'] is set to TRUE but E:\xampp\htdocs\maurnaturo\application\vendor/autoload.php was not found.
INFO - 2024-05-19 17:08:32 --> Config Class Initialized
INFO - 2024-05-19 17:08:32 --> Hooks Class Initialized
DEBUG - 2024-05-19 17:08:32 --> UTF-8 Support Enabled
INFO - 2024-05-19 17:08:32 --> Utf8 Class Initialized
INFO - 2024-05-19 17:08:32 --> URI Class Initialized
INFO - 2024-05-19 17:08:32 --> Router Class Initialized
INFO - 2024-05-19 17:08:32 --> Output Class Initialized
INFO - 2024-05-19 17:08:32 --> Security Class Initialized
DEBUG - 2024-05-19 17:08:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-19 17:08:32 --> Input Class Initialized
INFO - 2024-05-19 17:08:32 --> Language Class Initialized
ERROR - 2024-05-19 17:08:32 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2024-05-19 17:08:45 --> $config['composer_autoload'] is set to TRUE but E:\xampp\htdocs\maurnaturo\application\vendor/autoload.php was not found.
INFO - 2024-05-19 17:08:45 --> Config Class Initialized
INFO - 2024-05-19 17:08:45 --> Hooks Class Initialized
DEBUG - 2024-05-19 17:08:45 --> UTF-8 Support Enabled
INFO - 2024-05-19 17:08:45 --> Utf8 Class Initialized
INFO - 2024-05-19 17:08:45 --> URI Class Initialized
INFO - 2024-05-19 17:08:45 --> Router Class Initialized
INFO - 2024-05-19 17:08:45 --> Output Class Initialized
INFO - 2024-05-19 17:08:45 --> Security Class Initialized
DEBUG - 2024-05-19 17:08:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-19 17:08:45 --> Input Class Initialized
INFO - 2024-05-19 17:08:45 --> Language Class Initialized
INFO - 2024-05-19 17:08:45 --> Loader Class Initialized
INFO - 2024-05-19 17:08:45 --> Helper loaded: url_helper
INFO - 2024-05-19 17:08:45 --> Helper loaded: file_helper
INFO - 2024-05-19 17:08:45 --> Helper loaded: html_helper
INFO - 2024-05-19 17:08:45 --> Helper loaded: text_helper
INFO - 2024-05-19 17:08:45 --> Helper loaded: form_helper
INFO - 2024-05-19 17:08:45 --> Helper loaded: lang_helper
INFO - 2024-05-19 17:08:45 --> Helper loaded: security_helper
INFO - 2024-05-19 17:08:45 --> Helper loaded: cookie_helper
INFO - 2024-05-19 17:08:45 --> Database Driver Class Initialized
INFO - 2024-05-19 17:08:45 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-19 17:08:45 --> Parser Class Initialized
INFO - 2024-05-19 17:08:45 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-05-19 17:08:45 --> Pagination Class Initialized
INFO - 2024-05-19 17:08:45 --> Form Validation Class Initialized
INFO - 2024-05-19 17:08:45 --> Controller Class Initialized
DEBUG - 2024-05-19 17:08:45 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-05-19 17:08:45 --> Session class already loaded. Second attempt ignored.
INFO - 2024-05-19 17:08:45 --> Model Class Initialized
INFO - 2024-05-19 17:08:45 --> Model Class Initialized
DEBUG - 2024-05-19 17:08:45 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-05-19 17:08:45 --> Session class already loaded. Second attempt ignored.
INFO - 2024-05-19 17:08:45 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\payments/add_payment_form.php
DEBUG - 2024-05-19 17:08:45 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-05-19 17:08:45 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\include/top_menu.php
INFO - 2024-05-19 17:08:45 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\include/admin_loggedin_info.php
INFO - 2024-05-19 17:08:45 --> Model Class Initialized
INFO - 2024-05-19 17:08:45 --> Model Class Initialized
INFO - 2024-05-19 17:08:45 --> Model Class Initialized
INFO - 2024-05-19 17:08:45 --> Model Class Initialized
INFO - 2024-05-19 17:08:47 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\include/admin_header.php
INFO - 2024-05-19 17:08:47 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\include/admin_footer.php
INFO - 2024-05-19 17:08:47 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\admin_html_template.php
INFO - 2024-05-19 17:08:47 --> Final output sent to browser
DEBUG - 2024-05-19 17:08:47 --> Total execution time: 1.3349
ERROR - 2024-05-19 17:10:56 --> $config['composer_autoload'] is set to TRUE but E:\xampp\htdocs\maurnaturo\application\vendor/autoload.php was not found.
INFO - 2024-05-19 17:10:56 --> Config Class Initialized
INFO - 2024-05-19 17:10:56 --> Hooks Class Initialized
DEBUG - 2024-05-19 17:10:56 --> UTF-8 Support Enabled
INFO - 2024-05-19 17:10:56 --> Utf8 Class Initialized
INFO - 2024-05-19 17:10:56 --> URI Class Initialized
INFO - 2024-05-19 17:10:56 --> Router Class Initialized
INFO - 2024-05-19 17:10:56 --> Output Class Initialized
INFO - 2024-05-19 17:10:56 --> Security Class Initialized
DEBUG - 2024-05-19 17:10:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-19 17:10:56 --> Input Class Initialized
INFO - 2024-05-19 17:10:56 --> Language Class Initialized
INFO - 2024-05-19 17:10:56 --> Loader Class Initialized
INFO - 2024-05-19 17:10:56 --> Helper loaded: url_helper
INFO - 2024-05-19 17:10:56 --> Helper loaded: file_helper
INFO - 2024-05-19 17:10:56 --> Helper loaded: html_helper
INFO - 2024-05-19 17:10:56 --> Helper loaded: text_helper
INFO - 2024-05-19 17:10:56 --> Helper loaded: form_helper
INFO - 2024-05-19 17:10:56 --> Helper loaded: lang_helper
INFO - 2024-05-19 17:10:56 --> Helper loaded: security_helper
INFO - 2024-05-19 17:10:56 --> Helper loaded: cookie_helper
INFO - 2024-05-19 17:10:56 --> Database Driver Class Initialized
INFO - 2024-05-19 17:10:56 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-19 17:10:56 --> Parser Class Initialized
INFO - 2024-05-19 17:10:56 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-05-19 17:10:56 --> Pagination Class Initialized
INFO - 2024-05-19 17:10:56 --> Form Validation Class Initialized
INFO - 2024-05-19 17:10:56 --> Controller Class Initialized
DEBUG - 2024-05-19 17:10:56 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-05-19 17:10:56 --> Session class already loaded. Second attempt ignored.
INFO - 2024-05-19 17:10:56 --> Model Class Initialized
INFO - 2024-05-19 17:10:56 --> Model Class Initialized
DEBUG - 2024-05-19 17:10:56 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-05-19 17:10:56 --> Session class already loaded. Second attempt ignored.
INFO - 2024-05-19 17:10:56 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\payments/add_payment_form.php
DEBUG - 2024-05-19 17:10:56 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-05-19 17:10:56 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\include/top_menu.php
INFO - 2024-05-19 17:10:57 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\include/admin_loggedin_info.php
INFO - 2024-05-19 17:10:57 --> Model Class Initialized
INFO - 2024-05-19 17:10:57 --> Model Class Initialized
INFO - 2024-05-19 17:10:57 --> Model Class Initialized
INFO - 2024-05-19 17:10:57 --> Model Class Initialized
INFO - 2024-05-19 17:10:58 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\include/admin_header.php
INFO - 2024-05-19 17:10:58 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\include/admin_footer.php
INFO - 2024-05-19 17:10:58 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\admin_html_template.php
INFO - 2024-05-19 17:10:58 --> Final output sent to browser
DEBUG - 2024-05-19 17:10:58 --> Total execution time: 1.1871
ERROR - 2024-05-19 17:11:12 --> $config['composer_autoload'] is set to TRUE but E:\xampp\htdocs\maurnaturo\application\vendor/autoload.php was not found.
INFO - 2024-05-19 17:11:12 --> Config Class Initialized
INFO - 2024-05-19 17:11:12 --> Hooks Class Initialized
DEBUG - 2024-05-19 17:11:12 --> UTF-8 Support Enabled
INFO - 2024-05-19 17:11:12 --> Utf8 Class Initialized
INFO - 2024-05-19 17:11:12 --> URI Class Initialized
INFO - 2024-05-19 17:11:12 --> Router Class Initialized
INFO - 2024-05-19 17:11:12 --> Output Class Initialized
INFO - 2024-05-19 17:11:12 --> Security Class Initialized
DEBUG - 2024-05-19 17:11:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-19 17:11:12 --> Input Class Initialized
INFO - 2024-05-19 17:11:12 --> Language Class Initialized
INFO - 2024-05-19 17:11:12 --> Loader Class Initialized
INFO - 2024-05-19 17:11:12 --> Helper loaded: url_helper
INFO - 2024-05-19 17:11:12 --> Helper loaded: file_helper
INFO - 2024-05-19 17:11:12 --> Helper loaded: html_helper
INFO - 2024-05-19 17:11:12 --> Helper loaded: text_helper
INFO - 2024-05-19 17:11:12 --> Helper loaded: form_helper
INFO - 2024-05-19 17:11:12 --> Helper loaded: lang_helper
INFO - 2024-05-19 17:11:12 --> Helper loaded: security_helper
INFO - 2024-05-19 17:11:12 --> Helper loaded: cookie_helper
INFO - 2024-05-19 17:11:12 --> Database Driver Class Initialized
INFO - 2024-05-19 17:11:12 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-19 17:11:12 --> Parser Class Initialized
INFO - 2024-05-19 17:11:12 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-05-19 17:11:12 --> Pagination Class Initialized
INFO - 2024-05-19 17:11:12 --> Form Validation Class Initialized
INFO - 2024-05-19 17:11:12 --> Controller Class Initialized
INFO - 2024-05-19 17:11:12 --> Model Class Initialized
DEBUG - 2024-05-19 17:11:12 --> Session class already loaded. Second attempt ignored.
ERROR - 2024-05-19 17:11:12 --> Severity: Warning --> Invalid argument supplied for foreach() E:\xampp\htdocs\maurnaturo\application\controllers\Cinvoice.php 616
INFO - 2024-05-19 17:11:12 --> Final output sent to browser
DEBUG - 2024-05-19 17:11:12 --> Total execution time: 0.0749
ERROR - 2024-05-19 17:11:13 --> $config['composer_autoload'] is set to TRUE but E:\xampp\htdocs\maurnaturo\application\vendor/autoload.php was not found.
INFO - 2024-05-19 17:11:13 --> Config Class Initialized
INFO - 2024-05-19 17:11:13 --> Hooks Class Initialized
DEBUG - 2024-05-19 17:11:13 --> UTF-8 Support Enabled
INFO - 2024-05-19 17:11:13 --> Utf8 Class Initialized
INFO - 2024-05-19 17:11:13 --> URI Class Initialized
INFO - 2024-05-19 17:11:13 --> Router Class Initialized
INFO - 2024-05-19 17:11:13 --> Output Class Initialized
INFO - 2024-05-19 17:11:13 --> Security Class Initialized
DEBUG - 2024-05-19 17:11:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-19 17:11:13 --> Input Class Initialized
INFO - 2024-05-19 17:11:13 --> Language Class Initialized
INFO - 2024-05-19 17:11:13 --> Loader Class Initialized
INFO - 2024-05-19 17:11:13 --> Helper loaded: url_helper
INFO - 2024-05-19 17:11:13 --> Helper loaded: file_helper
INFO - 2024-05-19 17:11:13 --> Helper loaded: html_helper
INFO - 2024-05-19 17:11:13 --> Helper loaded: text_helper
INFO - 2024-05-19 17:11:13 --> Helper loaded: form_helper
INFO - 2024-05-19 17:11:13 --> Helper loaded: lang_helper
INFO - 2024-05-19 17:11:13 --> Helper loaded: security_helper
INFO - 2024-05-19 17:11:13 --> Helper loaded: cookie_helper
INFO - 2024-05-19 17:11:13 --> Database Driver Class Initialized
INFO - 2024-05-19 17:11:13 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-19 17:11:13 --> Parser Class Initialized
INFO - 2024-05-19 17:11:13 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-05-19 17:11:13 --> Pagination Class Initialized
INFO - 2024-05-19 17:11:13 --> Form Validation Class Initialized
INFO - 2024-05-19 17:11:13 --> Controller Class Initialized
INFO - 2024-05-19 17:11:13 --> Model Class Initialized
DEBUG - 2024-05-19 17:11:13 --> Session class already loaded. Second attempt ignored.
INFO - 2024-05-19 17:11:13 --> Final output sent to browser
DEBUG - 2024-05-19 17:11:13 --> Total execution time: 0.1239
ERROR - 2024-05-19 17:11:13 --> $config['composer_autoload'] is set to TRUE but E:\xampp\htdocs\maurnaturo\application\vendor/autoload.php was not found.
INFO - 2024-05-19 17:11:13 --> Config Class Initialized
INFO - 2024-05-19 17:11:13 --> Hooks Class Initialized
DEBUG - 2024-05-19 17:11:13 --> UTF-8 Support Enabled
INFO - 2024-05-19 17:11:13 --> Utf8 Class Initialized
INFO - 2024-05-19 17:11:13 --> URI Class Initialized
INFO - 2024-05-19 17:11:13 --> Router Class Initialized
INFO - 2024-05-19 17:11:13 --> Output Class Initialized
INFO - 2024-05-19 17:11:13 --> Security Class Initialized
DEBUG - 2024-05-19 17:11:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-19 17:11:13 --> Input Class Initialized
INFO - 2024-05-19 17:11:13 --> Language Class Initialized
INFO - 2024-05-19 17:11:13 --> Loader Class Initialized
INFO - 2024-05-19 17:11:13 --> Helper loaded: url_helper
INFO - 2024-05-19 17:11:13 --> Helper loaded: file_helper
INFO - 2024-05-19 17:11:13 --> Helper loaded: html_helper
INFO - 2024-05-19 17:11:13 --> Helper loaded: text_helper
INFO - 2024-05-19 17:11:13 --> Helper loaded: form_helper
INFO - 2024-05-19 17:11:13 --> Helper loaded: lang_helper
INFO - 2024-05-19 17:11:13 --> Helper loaded: security_helper
INFO - 2024-05-19 17:11:13 --> Helper loaded: cookie_helper
INFO - 2024-05-19 17:11:13 --> Database Driver Class Initialized
INFO - 2024-05-19 17:11:13 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-19 17:11:13 --> Parser Class Initialized
INFO - 2024-05-19 17:11:13 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-05-19 17:11:13 --> Pagination Class Initialized
INFO - 2024-05-19 17:11:13 --> Form Validation Class Initialized
INFO - 2024-05-19 17:11:13 --> Controller Class Initialized
INFO - 2024-05-19 17:11:13 --> Model Class Initialized
DEBUG - 2024-05-19 17:11:13 --> Session class already loaded. Second attempt ignored.
INFO - 2024-05-19 17:11:13 --> Final output sent to browser
DEBUG - 2024-05-19 17:11:13 --> Total execution time: 0.0786
ERROR - 2024-05-19 17:11:24 --> $config['composer_autoload'] is set to TRUE but E:\xampp\htdocs\maurnaturo\application\vendor/autoload.php was not found.
INFO - 2024-05-19 17:11:24 --> Config Class Initialized
INFO - 2024-05-19 17:11:24 --> Hooks Class Initialized
DEBUG - 2024-05-19 17:11:24 --> UTF-8 Support Enabled
INFO - 2024-05-19 17:11:24 --> Utf8 Class Initialized
INFO - 2024-05-19 17:11:24 --> URI Class Initialized
INFO - 2024-05-19 17:11:24 --> Router Class Initialized
INFO - 2024-05-19 17:11:24 --> Output Class Initialized
INFO - 2024-05-19 17:11:24 --> Security Class Initialized
DEBUG - 2024-05-19 17:11:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-19 17:11:24 --> Input Class Initialized
INFO - 2024-05-19 17:11:24 --> Language Class Initialized
INFO - 2024-05-19 17:11:24 --> Loader Class Initialized
INFO - 2024-05-19 17:11:24 --> Helper loaded: url_helper
INFO - 2024-05-19 17:11:24 --> Helper loaded: file_helper
INFO - 2024-05-19 17:11:24 --> Helper loaded: html_helper
INFO - 2024-05-19 17:11:24 --> Helper loaded: text_helper
INFO - 2024-05-19 17:11:24 --> Helper loaded: form_helper
INFO - 2024-05-19 17:11:24 --> Helper loaded: lang_helper
INFO - 2024-05-19 17:11:24 --> Helper loaded: security_helper
INFO - 2024-05-19 17:11:24 --> Helper loaded: cookie_helper
INFO - 2024-05-19 17:11:24 --> Database Driver Class Initialized
INFO - 2024-05-19 17:11:24 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-19 17:11:24 --> Parser Class Initialized
INFO - 2024-05-19 17:11:24 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-05-19 17:11:24 --> Pagination Class Initialized
INFO - 2024-05-19 17:11:24 --> Form Validation Class Initialized
INFO - 2024-05-19 17:11:24 --> Controller Class Initialized
DEBUG - 2024-05-19 17:11:24 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-05-19 17:11:24 --> Session class already loaded. Second attempt ignored.
INFO - 2024-05-19 17:11:24 --> Model Class Initialized
INFO - 2024-05-19 17:11:24 --> Final output sent to browser
DEBUG - 2024-05-19 17:11:24 --> Total execution time: 0.0820
ERROR - 2024-05-19 17:11:44 --> $config['composer_autoload'] is set to TRUE but E:\xampp\htdocs\maurnaturo\application\vendor/autoload.php was not found.
INFO - 2024-05-19 17:11:44 --> Config Class Initialized
INFO - 2024-05-19 17:11:44 --> Hooks Class Initialized
DEBUG - 2024-05-19 17:11:44 --> UTF-8 Support Enabled
INFO - 2024-05-19 17:11:44 --> Utf8 Class Initialized
INFO - 2024-05-19 17:11:44 --> URI Class Initialized
INFO - 2024-05-19 17:11:44 --> Router Class Initialized
INFO - 2024-05-19 17:11:44 --> Output Class Initialized
INFO - 2024-05-19 17:11:44 --> Security Class Initialized
DEBUG - 2024-05-19 17:11:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-19 17:11:44 --> Input Class Initialized
INFO - 2024-05-19 17:11:44 --> Language Class Initialized
ERROR - 2024-05-19 17:11:44 --> 404 Page Not Found: Assets/plugins
ERROR - 2024-05-19 17:11:44 --> $config['composer_autoload'] is set to TRUE but E:\xampp\htdocs\maurnaturo\application\vendor/autoload.php was not found.
INFO - 2024-05-19 17:11:44 --> Config Class Initialized
INFO - 2024-05-19 17:11:44 --> Hooks Class Initialized
DEBUG - 2024-05-19 17:11:44 --> UTF-8 Support Enabled
INFO - 2024-05-19 17:11:44 --> Utf8 Class Initialized
INFO - 2024-05-19 17:11:44 --> URI Class Initialized
INFO - 2024-05-19 17:11:44 --> Router Class Initialized
INFO - 2024-05-19 17:11:44 --> Output Class Initialized
INFO - 2024-05-19 17:11:44 --> Security Class Initialized
DEBUG - 2024-05-19 17:11:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-19 17:11:44 --> Input Class Initialized
INFO - 2024-05-19 17:11:44 --> Language Class Initialized
ERROR - 2024-05-19 17:11:44 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2024-05-19 17:14:03 --> $config['composer_autoload'] is set to TRUE but E:\xampp\htdocs\maurnaturo\application\vendor/autoload.php was not found.
INFO - 2024-05-19 17:14:03 --> Config Class Initialized
INFO - 2024-05-19 17:14:03 --> Hooks Class Initialized
DEBUG - 2024-05-19 17:14:03 --> UTF-8 Support Enabled
INFO - 2024-05-19 17:14:03 --> Utf8 Class Initialized
INFO - 2024-05-19 17:14:03 --> URI Class Initialized
INFO - 2024-05-19 17:14:03 --> Router Class Initialized
INFO - 2024-05-19 17:14:03 --> Output Class Initialized
INFO - 2024-05-19 17:14:03 --> Security Class Initialized
DEBUG - 2024-05-19 17:14:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-19 17:14:03 --> Input Class Initialized
INFO - 2024-05-19 17:14:03 --> Language Class Initialized
INFO - 2024-05-19 17:14:03 --> Loader Class Initialized
INFO - 2024-05-19 17:14:03 --> Helper loaded: url_helper
INFO - 2024-05-19 17:14:03 --> Helper loaded: file_helper
INFO - 2024-05-19 17:14:03 --> Helper loaded: html_helper
INFO - 2024-05-19 17:14:03 --> Helper loaded: text_helper
INFO - 2024-05-19 17:14:03 --> Helper loaded: form_helper
INFO - 2024-05-19 17:14:03 --> Helper loaded: lang_helper
INFO - 2024-05-19 17:14:03 --> Helper loaded: security_helper
INFO - 2024-05-19 17:14:03 --> Helper loaded: cookie_helper
INFO - 2024-05-19 17:14:03 --> Database Driver Class Initialized
INFO - 2024-05-19 17:14:03 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-19 17:14:03 --> Parser Class Initialized
INFO - 2024-05-19 17:14:03 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-05-19 17:14:03 --> Pagination Class Initialized
INFO - 2024-05-19 17:14:03 --> Form Validation Class Initialized
INFO - 2024-05-19 17:14:03 --> Controller Class Initialized
DEBUG - 2024-05-19 17:14:03 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-05-19 17:14:03 --> Session class already loaded. Second attempt ignored.
INFO - 2024-05-19 17:14:03 --> Model Class Initialized
INFO - 2024-05-19 17:14:03 --> Model Class Initialized
DEBUG - 2024-05-19 17:14:03 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-05-19 17:14:03 --> Session class already loaded. Second attempt ignored.
INFO - 2024-05-19 17:14:03 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\mr_payments/add_payment_form.php
DEBUG - 2024-05-19 17:14:03 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-05-19 17:14:03 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\include/top_menu.php
INFO - 2024-05-19 17:14:03 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\include/admin_loggedin_info.php
INFO - 2024-05-19 17:14:03 --> Model Class Initialized
INFO - 2024-05-19 17:14:03 --> Model Class Initialized
INFO - 2024-05-19 17:14:03 --> Model Class Initialized
INFO - 2024-05-19 17:14:03 --> Model Class Initialized
INFO - 2024-05-19 17:14:04 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\include/admin_header.php
INFO - 2024-05-19 17:14:04 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\include/admin_footer.php
INFO - 2024-05-19 17:14:04 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\admin_html_template.php
INFO - 2024-05-19 17:14:04 --> Final output sent to browser
DEBUG - 2024-05-19 17:14:04 --> Total execution time: 1.3571
ERROR - 2024-05-19 17:14:05 --> $config['composer_autoload'] is set to TRUE but E:\xampp\htdocs\maurnaturo\application\vendor/autoload.php was not found.
INFO - 2024-05-19 17:14:05 --> Config Class Initialized
INFO - 2024-05-19 17:14:05 --> Hooks Class Initialized
DEBUG - 2024-05-19 17:14:05 --> UTF-8 Support Enabled
INFO - 2024-05-19 17:14:05 --> Utf8 Class Initialized
INFO - 2024-05-19 17:14:05 --> URI Class Initialized
INFO - 2024-05-19 17:14:05 --> Router Class Initialized
INFO - 2024-05-19 17:14:05 --> Output Class Initialized
INFO - 2024-05-19 17:14:05 --> Security Class Initialized
DEBUG - 2024-05-19 17:14:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-19 17:14:05 --> Input Class Initialized
INFO - 2024-05-19 17:14:05 --> Language Class Initialized
ERROR - 2024-05-19 17:14:05 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2024-05-19 17:14:06 --> $config['composer_autoload'] is set to TRUE but E:\xampp\htdocs\maurnaturo\application\vendor/autoload.php was not found.
INFO - 2024-05-19 17:14:06 --> Config Class Initialized
INFO - 2024-05-19 17:14:06 --> Hooks Class Initialized
DEBUG - 2024-05-19 17:14:06 --> UTF-8 Support Enabled
INFO - 2024-05-19 17:14:06 --> Utf8 Class Initialized
INFO - 2024-05-19 17:14:06 --> URI Class Initialized
INFO - 2024-05-19 17:14:06 --> Router Class Initialized
INFO - 2024-05-19 17:14:06 --> Output Class Initialized
INFO - 2024-05-19 17:14:06 --> Security Class Initialized
DEBUG - 2024-05-19 17:14:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-19 17:14:06 --> Input Class Initialized
INFO - 2024-05-19 17:14:06 --> Language Class Initialized
ERROR - 2024-05-19 17:14:06 --> 404 Page Not Found: Assets/plugins
ERROR - 2024-05-19 17:14:14 --> $config['composer_autoload'] is set to TRUE but E:\xampp\htdocs\maurnaturo\application\vendor/autoload.php was not found.
INFO - 2024-05-19 17:14:14 --> Config Class Initialized
INFO - 2024-05-19 17:14:14 --> Hooks Class Initialized
DEBUG - 2024-05-19 17:14:14 --> UTF-8 Support Enabled
INFO - 2024-05-19 17:14:14 --> Utf8 Class Initialized
INFO - 2024-05-19 17:14:14 --> URI Class Initialized
INFO - 2024-05-19 17:14:14 --> Router Class Initialized
INFO - 2024-05-19 17:14:14 --> Output Class Initialized
INFO - 2024-05-19 17:14:14 --> Security Class Initialized
DEBUG - 2024-05-19 17:14:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-19 17:14:14 --> Input Class Initialized
INFO - 2024-05-19 17:14:14 --> Language Class Initialized
INFO - 2024-05-19 17:14:14 --> Loader Class Initialized
INFO - 2024-05-19 17:14:14 --> Helper loaded: url_helper
INFO - 2024-05-19 17:14:14 --> Helper loaded: file_helper
INFO - 2024-05-19 17:14:14 --> Helper loaded: html_helper
INFO - 2024-05-19 17:14:14 --> Helper loaded: text_helper
INFO - 2024-05-19 17:14:14 --> Helper loaded: form_helper
INFO - 2024-05-19 17:14:14 --> Helper loaded: lang_helper
INFO - 2024-05-19 17:14:14 --> Helper loaded: security_helper
INFO - 2024-05-19 17:14:14 --> Helper loaded: cookie_helper
INFO - 2024-05-19 17:14:14 --> Database Driver Class Initialized
INFO - 2024-05-19 17:14:14 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-19 17:14:14 --> Parser Class Initialized
INFO - 2024-05-19 17:14:14 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-05-19 17:14:14 --> Pagination Class Initialized
INFO - 2024-05-19 17:14:14 --> Form Validation Class Initialized
INFO - 2024-05-19 17:14:14 --> Controller Class Initialized
DEBUG - 2024-05-19 17:14:14 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-05-19 17:14:14 --> Session class already loaded. Second attempt ignored.
INFO - 2024-05-19 17:14:14 --> Model Class Initialized
INFO - 2024-05-19 17:14:14 --> Model Class Initialized
DEBUG - 2024-05-19 17:14:14 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-05-19 17:14:14 --> Session class already loaded. Second attempt ignored.
INFO - 2024-05-19 17:14:14 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\payments/add_payment_form.php
DEBUG - 2024-05-19 17:14:14 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-05-19 17:14:14 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\include/top_menu.php
INFO - 2024-05-19 17:14:14 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\include/admin_loggedin_info.php
INFO - 2024-05-19 17:14:14 --> Model Class Initialized
INFO - 2024-05-19 17:14:14 --> Model Class Initialized
INFO - 2024-05-19 17:14:14 --> Model Class Initialized
INFO - 2024-05-19 17:14:14 --> Model Class Initialized
INFO - 2024-05-19 17:14:15 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\include/admin_header.php
INFO - 2024-05-19 17:14:15 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\include/admin_footer.php
INFO - 2024-05-19 17:14:15 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\admin_html_template.php
INFO - 2024-05-19 17:14:15 --> Final output sent to browser
DEBUG - 2024-05-19 17:14:15 --> Total execution time: 1.1000
ERROR - 2024-05-19 17:14:17 --> $config['composer_autoload'] is set to TRUE but E:\xampp\htdocs\maurnaturo\application\vendor/autoload.php was not found.
INFO - 2024-05-19 17:14:17 --> Config Class Initialized
INFO - 2024-05-19 17:14:17 --> Hooks Class Initialized
DEBUG - 2024-05-19 17:14:17 --> UTF-8 Support Enabled
INFO - 2024-05-19 17:14:17 --> Utf8 Class Initialized
INFO - 2024-05-19 17:14:17 --> URI Class Initialized
INFO - 2024-05-19 17:14:17 --> Router Class Initialized
INFO - 2024-05-19 17:14:17 --> Output Class Initialized
INFO - 2024-05-19 17:14:17 --> Security Class Initialized
DEBUG - 2024-05-19 17:14:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-19 17:14:17 --> Input Class Initialized
INFO - 2024-05-19 17:14:17 --> Language Class Initialized
INFO - 2024-05-19 17:14:17 --> Loader Class Initialized
INFO - 2024-05-19 17:14:17 --> Helper loaded: url_helper
INFO - 2024-05-19 17:14:17 --> Helper loaded: file_helper
INFO - 2024-05-19 17:14:17 --> Helper loaded: html_helper
INFO - 2024-05-19 17:14:17 --> Helper loaded: text_helper
INFO - 2024-05-19 17:14:17 --> Helper loaded: form_helper
INFO - 2024-05-19 17:14:17 --> Helper loaded: lang_helper
INFO - 2024-05-19 17:14:17 --> Helper loaded: security_helper
INFO - 2024-05-19 17:14:17 --> Helper loaded: cookie_helper
INFO - 2024-05-19 17:14:17 --> Database Driver Class Initialized
INFO - 2024-05-19 17:14:17 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-19 17:14:17 --> Parser Class Initialized
INFO - 2024-05-19 17:14:17 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-05-19 17:14:17 --> Pagination Class Initialized
INFO - 2024-05-19 17:14:17 --> Form Validation Class Initialized
INFO - 2024-05-19 17:14:17 --> Controller Class Initialized
DEBUG - 2024-05-19 17:14:17 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-05-19 17:14:17 --> Session class already loaded. Second attempt ignored.
INFO - 2024-05-19 17:14:17 --> Model Class Initialized
INFO - 2024-05-19 17:14:17 --> Model Class Initialized
DEBUG - 2024-05-19 17:14:17 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-05-19 17:14:17 --> Session class already loaded. Second attempt ignored.
INFO - 2024-05-19 17:14:17 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\payments/add_payment_form.php
DEBUG - 2024-05-19 17:14:17 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-05-19 17:14:17 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\include/top_menu.php
INFO - 2024-05-19 17:14:17 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\include/admin_loggedin_info.php
INFO - 2024-05-19 17:14:17 --> Model Class Initialized
INFO - 2024-05-19 17:14:17 --> Model Class Initialized
INFO - 2024-05-19 17:14:17 --> Model Class Initialized
INFO - 2024-05-19 17:14:17 --> Model Class Initialized
INFO - 2024-05-19 17:14:18 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\include/admin_header.php
INFO - 2024-05-19 17:14:18 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\include/admin_footer.php
INFO - 2024-05-19 17:14:18 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\admin_html_template.php
INFO - 2024-05-19 17:14:18 --> Final output sent to browser
DEBUG - 2024-05-19 17:14:18 --> Total execution time: 1.1022
ERROR - 2024-05-19 17:14:59 --> $config['composer_autoload'] is set to TRUE but E:\xampp\htdocs\maurnaturo\application\vendor/autoload.php was not found.
INFO - 2024-05-19 17:14:59 --> Config Class Initialized
INFO - 2024-05-19 17:14:59 --> Hooks Class Initialized
DEBUG - 2024-05-19 17:14:59 --> UTF-8 Support Enabled
INFO - 2024-05-19 17:14:59 --> Utf8 Class Initialized
INFO - 2024-05-19 17:14:59 --> URI Class Initialized
INFO - 2024-05-19 17:14:59 --> Router Class Initialized
INFO - 2024-05-19 17:14:59 --> Output Class Initialized
INFO - 2024-05-19 17:14:59 --> Security Class Initialized
DEBUG - 2024-05-19 17:14:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-19 17:14:59 --> Input Class Initialized
INFO - 2024-05-19 17:14:59 --> Language Class Initialized
INFO - 2024-05-19 17:14:59 --> Loader Class Initialized
INFO - 2024-05-19 17:14:59 --> Helper loaded: url_helper
INFO - 2024-05-19 17:14:59 --> Helper loaded: file_helper
INFO - 2024-05-19 17:14:59 --> Helper loaded: html_helper
INFO - 2024-05-19 17:14:59 --> Helper loaded: text_helper
INFO - 2024-05-19 17:14:59 --> Helper loaded: form_helper
INFO - 2024-05-19 17:14:59 --> Helper loaded: lang_helper
INFO - 2024-05-19 17:14:59 --> Helper loaded: security_helper
INFO - 2024-05-19 17:14:59 --> Helper loaded: cookie_helper
INFO - 2024-05-19 17:14:59 --> Database Driver Class Initialized
INFO - 2024-05-19 17:14:59 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-19 17:14:59 --> Parser Class Initialized
INFO - 2024-05-19 17:14:59 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-05-19 17:14:59 --> Pagination Class Initialized
INFO - 2024-05-19 17:14:59 --> Form Validation Class Initialized
INFO - 2024-05-19 17:14:59 --> Controller Class Initialized
DEBUG - 2024-05-19 17:14:59 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-05-19 17:14:59 --> Session class already loaded. Second attempt ignored.
INFO - 2024-05-19 17:14:59 --> Model Class Initialized
INFO - 2024-05-19 17:14:59 --> Model Class Initialized
DEBUG - 2024-05-19 17:14:59 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-05-19 17:14:59 --> Session class already loaded. Second attempt ignored.
INFO - 2024-05-19 17:14:59 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\payments/add_payment_form.php
DEBUG - 2024-05-19 17:14:59 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-05-19 17:14:59 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\include/top_menu.php
INFO - 2024-05-19 17:14:59 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\include/admin_loggedin_info.php
INFO - 2024-05-19 17:14:59 --> Model Class Initialized
INFO - 2024-05-19 17:14:59 --> Model Class Initialized
INFO - 2024-05-19 17:14:59 --> Model Class Initialized
INFO - 2024-05-19 17:14:59 --> Model Class Initialized
INFO - 2024-05-19 17:15:00 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\include/admin_header.php
INFO - 2024-05-19 17:15:00 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\include/admin_footer.php
INFO - 2024-05-19 17:15:00 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\admin_html_template.php
INFO - 2024-05-19 17:15:00 --> Final output sent to browser
DEBUG - 2024-05-19 17:15:00 --> Total execution time: 1.0787
ERROR - 2024-05-19 17:15:03 --> $config['composer_autoload'] is set to TRUE but E:\xampp\htdocs\maurnaturo\application\vendor/autoload.php was not found.
INFO - 2024-05-19 17:15:03 --> Config Class Initialized
INFO - 2024-05-19 17:15:03 --> Hooks Class Initialized
DEBUG - 2024-05-19 17:15:03 --> UTF-8 Support Enabled
INFO - 2024-05-19 17:15:03 --> Utf8 Class Initialized
INFO - 2024-05-19 17:15:03 --> URI Class Initialized
INFO - 2024-05-19 17:15:03 --> Router Class Initialized
INFO - 2024-05-19 17:15:03 --> Output Class Initialized
INFO - 2024-05-19 17:15:03 --> Security Class Initialized
DEBUG - 2024-05-19 17:15:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-19 17:15:03 --> Input Class Initialized
INFO - 2024-05-19 17:15:03 --> Language Class Initialized
INFO - 2024-05-19 17:15:03 --> Loader Class Initialized
INFO - 2024-05-19 17:15:03 --> Helper loaded: url_helper
INFO - 2024-05-19 17:15:03 --> Helper loaded: file_helper
INFO - 2024-05-19 17:15:03 --> Helper loaded: html_helper
INFO - 2024-05-19 17:15:03 --> Helper loaded: text_helper
INFO - 2024-05-19 17:15:03 --> Helper loaded: form_helper
INFO - 2024-05-19 17:15:03 --> Helper loaded: lang_helper
INFO - 2024-05-19 17:15:03 --> Helper loaded: security_helper
INFO - 2024-05-19 17:15:03 --> Helper loaded: cookie_helper
INFO - 2024-05-19 17:15:03 --> Database Driver Class Initialized
INFO - 2024-05-19 17:15:03 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-19 17:15:03 --> Parser Class Initialized
INFO - 2024-05-19 17:15:03 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-05-19 17:15:03 --> Pagination Class Initialized
INFO - 2024-05-19 17:15:03 --> Form Validation Class Initialized
INFO - 2024-05-19 17:15:03 --> Controller Class Initialized
INFO - 2024-05-19 17:15:03 --> Model Class Initialized
DEBUG - 2024-05-19 17:15:03 --> Session class already loaded. Second attempt ignored.
INFO - 2024-05-19 17:15:03 --> Final output sent to browser
DEBUG - 2024-05-19 17:15:03 --> Total execution time: 0.0579
ERROR - 2024-05-19 17:15:04 --> $config['composer_autoload'] is set to TRUE but E:\xampp\htdocs\maurnaturo\application\vendor/autoload.php was not found.
INFO - 2024-05-19 17:15:04 --> Config Class Initialized
INFO - 2024-05-19 17:15:04 --> Hooks Class Initialized
DEBUG - 2024-05-19 17:15:05 --> UTF-8 Support Enabled
INFO - 2024-05-19 17:15:05 --> Utf8 Class Initialized
INFO - 2024-05-19 17:15:05 --> URI Class Initialized
INFO - 2024-05-19 17:15:05 --> Router Class Initialized
INFO - 2024-05-19 17:15:05 --> Output Class Initialized
INFO - 2024-05-19 17:15:05 --> Security Class Initialized
DEBUG - 2024-05-19 17:15:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-19 17:15:05 --> Input Class Initialized
INFO - 2024-05-19 17:15:05 --> Language Class Initialized
INFO - 2024-05-19 17:15:05 --> Loader Class Initialized
INFO - 2024-05-19 17:15:05 --> Helper loaded: url_helper
INFO - 2024-05-19 17:15:05 --> Helper loaded: file_helper
INFO - 2024-05-19 17:15:05 --> Helper loaded: html_helper
INFO - 2024-05-19 17:15:05 --> Helper loaded: text_helper
INFO - 2024-05-19 17:15:05 --> Helper loaded: form_helper
INFO - 2024-05-19 17:15:05 --> Helper loaded: lang_helper
INFO - 2024-05-19 17:15:05 --> Helper loaded: security_helper
INFO - 2024-05-19 17:15:05 --> Helper loaded: cookie_helper
INFO - 2024-05-19 17:15:05 --> Database Driver Class Initialized
INFO - 2024-05-19 17:15:05 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-19 17:15:05 --> Parser Class Initialized
INFO - 2024-05-19 17:15:05 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-05-19 17:15:05 --> Pagination Class Initialized
INFO - 2024-05-19 17:15:05 --> Form Validation Class Initialized
INFO - 2024-05-19 17:15:05 --> Controller Class Initialized
INFO - 2024-05-19 17:15:05 --> Model Class Initialized
DEBUG - 2024-05-19 17:15:05 --> Session class already loaded. Second attempt ignored.
INFO - 2024-05-19 17:15:05 --> Final output sent to browser
DEBUG - 2024-05-19 17:15:05 --> Total execution time: 0.0670
ERROR - 2024-05-19 17:15:13 --> $config['composer_autoload'] is set to TRUE but E:\xampp\htdocs\maurnaturo\application\vendor/autoload.php was not found.
INFO - 2024-05-19 17:15:13 --> Config Class Initialized
INFO - 2024-05-19 17:15:13 --> Hooks Class Initialized
DEBUG - 2024-05-19 17:15:13 --> UTF-8 Support Enabled
INFO - 2024-05-19 17:15:13 --> Utf8 Class Initialized
INFO - 2024-05-19 17:15:13 --> URI Class Initialized
INFO - 2024-05-19 17:15:13 --> Router Class Initialized
INFO - 2024-05-19 17:15:13 --> Output Class Initialized
INFO - 2024-05-19 17:15:13 --> Security Class Initialized
DEBUG - 2024-05-19 17:15:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-19 17:15:13 --> Input Class Initialized
INFO - 2024-05-19 17:15:13 --> Language Class Initialized
INFO - 2024-05-19 17:15:13 --> Loader Class Initialized
INFO - 2024-05-19 17:15:13 --> Helper loaded: url_helper
INFO - 2024-05-19 17:15:13 --> Helper loaded: file_helper
INFO - 2024-05-19 17:15:13 --> Helper loaded: html_helper
INFO - 2024-05-19 17:15:13 --> Helper loaded: text_helper
INFO - 2024-05-19 17:15:13 --> Helper loaded: form_helper
INFO - 2024-05-19 17:15:13 --> Helper loaded: lang_helper
INFO - 2024-05-19 17:15:13 --> Helper loaded: security_helper
INFO - 2024-05-19 17:15:13 --> Helper loaded: cookie_helper
INFO - 2024-05-19 17:15:13 --> Database Driver Class Initialized
INFO - 2024-05-19 17:15:13 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-19 17:15:13 --> Parser Class Initialized
INFO - 2024-05-19 17:15:13 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-05-19 17:15:13 --> Pagination Class Initialized
INFO - 2024-05-19 17:15:13 --> Form Validation Class Initialized
INFO - 2024-05-19 17:15:13 --> Controller Class Initialized
DEBUG - 2024-05-19 17:15:13 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-05-19 17:15:13 --> Session class already loaded. Second attempt ignored.
INFO - 2024-05-19 17:15:13 --> Model Class Initialized
INFO - 2024-05-19 17:15:13 --> Final output sent to browser
DEBUG - 2024-05-19 17:15:13 --> Total execution time: 0.0812
ERROR - 2024-05-19 17:15:18 --> $config['composer_autoload'] is set to TRUE but E:\xampp\htdocs\maurnaturo\application\vendor/autoload.php was not found.
INFO - 2024-05-19 17:15:18 --> Config Class Initialized
INFO - 2024-05-19 17:15:18 --> Hooks Class Initialized
DEBUG - 2024-05-19 17:15:18 --> UTF-8 Support Enabled
INFO - 2024-05-19 17:15:18 --> Utf8 Class Initialized
INFO - 2024-05-19 17:15:18 --> URI Class Initialized
INFO - 2024-05-19 17:15:18 --> Router Class Initialized
INFO - 2024-05-19 17:15:18 --> Output Class Initialized
INFO - 2024-05-19 17:15:18 --> Security Class Initialized
DEBUG - 2024-05-19 17:15:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-19 17:15:18 --> Input Class Initialized
INFO - 2024-05-19 17:15:18 --> Language Class Initialized
INFO - 2024-05-19 17:15:18 --> Loader Class Initialized
INFO - 2024-05-19 17:15:18 --> Helper loaded: url_helper
INFO - 2024-05-19 17:15:18 --> Helper loaded: file_helper
INFO - 2024-05-19 17:15:18 --> Helper loaded: html_helper
INFO - 2024-05-19 17:15:18 --> Helper loaded: text_helper
INFO - 2024-05-19 17:15:18 --> Helper loaded: form_helper
INFO - 2024-05-19 17:15:18 --> Helper loaded: lang_helper
INFO - 2024-05-19 17:15:18 --> Helper loaded: security_helper
INFO - 2024-05-19 17:15:18 --> Helper loaded: cookie_helper
INFO - 2024-05-19 17:15:18 --> Database Driver Class Initialized
INFO - 2024-05-19 17:15:18 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-19 17:15:18 --> Parser Class Initialized
INFO - 2024-05-19 17:15:18 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-05-19 17:15:18 --> Pagination Class Initialized
INFO - 2024-05-19 17:15:18 --> Form Validation Class Initialized
INFO - 2024-05-19 17:15:18 --> Controller Class Initialized
DEBUG - 2024-05-19 17:15:18 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-05-19 17:15:18 --> Session class already loaded. Second attempt ignored.
INFO - 2024-05-19 17:15:18 --> Model Class Initialized
INFO - 2024-05-19 17:15:18 --> Model Class Initialized
DEBUG - 2024-05-19 17:15:18 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-05-19 17:15:18 --> Session class already loaded. Second attempt ignored.
INFO - 2024-05-19 17:15:18 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\payments/add_payment_form.php
DEBUG - 2024-05-19 17:15:18 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-05-19 17:15:18 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\include/top_menu.php
INFO - 2024-05-19 17:15:18 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\include/admin_loggedin_info.php
INFO - 2024-05-19 17:15:18 --> Model Class Initialized
INFO - 2024-05-19 17:15:18 --> Model Class Initialized
INFO - 2024-05-19 17:15:18 --> Model Class Initialized
INFO - 2024-05-19 17:15:18 --> Model Class Initialized
INFO - 2024-05-19 17:15:19 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\include/admin_header.php
INFO - 2024-05-19 17:15:19 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\include/admin_footer.php
INFO - 2024-05-19 17:15:19 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\admin_html_template.php
INFO - 2024-05-19 17:15:19 --> Final output sent to browser
DEBUG - 2024-05-19 17:15:19 --> Total execution time: 1.1252
ERROR - 2024-05-19 17:15:21 --> $config['composer_autoload'] is set to TRUE but E:\xampp\htdocs\maurnaturo\application\vendor/autoload.php was not found.
INFO - 2024-05-19 17:15:21 --> Config Class Initialized
INFO - 2024-05-19 17:15:21 --> Hooks Class Initialized
DEBUG - 2024-05-19 17:15:21 --> UTF-8 Support Enabled
INFO - 2024-05-19 17:15:21 --> Utf8 Class Initialized
INFO - 2024-05-19 17:15:21 --> URI Class Initialized
INFO - 2024-05-19 17:15:21 --> Router Class Initialized
INFO - 2024-05-19 17:15:21 --> Output Class Initialized
INFO - 2024-05-19 17:15:21 --> Security Class Initialized
DEBUG - 2024-05-19 17:15:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-19 17:15:21 --> Input Class Initialized
INFO - 2024-05-19 17:15:21 --> Language Class Initialized
INFO - 2024-05-19 17:15:21 --> Loader Class Initialized
INFO - 2024-05-19 17:15:21 --> Helper loaded: url_helper
INFO - 2024-05-19 17:15:21 --> Helper loaded: file_helper
INFO - 2024-05-19 17:15:21 --> Helper loaded: html_helper
INFO - 2024-05-19 17:15:21 --> Helper loaded: text_helper
INFO - 2024-05-19 17:15:21 --> Helper loaded: form_helper
INFO - 2024-05-19 17:15:21 --> Helper loaded: lang_helper
INFO - 2024-05-19 17:15:21 --> Helper loaded: security_helper
INFO - 2024-05-19 17:15:21 --> Helper loaded: cookie_helper
INFO - 2024-05-19 17:15:21 --> Database Driver Class Initialized
INFO - 2024-05-19 17:15:21 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-19 17:15:21 --> Parser Class Initialized
INFO - 2024-05-19 17:15:21 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-05-19 17:15:21 --> Pagination Class Initialized
INFO - 2024-05-19 17:15:21 --> Form Validation Class Initialized
INFO - 2024-05-19 17:15:21 --> Controller Class Initialized
DEBUG - 2024-05-19 17:15:21 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-05-19 17:15:21 --> Session class already loaded. Second attempt ignored.
INFO - 2024-05-19 17:15:21 --> Model Class Initialized
INFO - 2024-05-19 17:15:21 --> Model Class Initialized
DEBUG - 2024-05-19 17:15:21 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-05-19 17:15:21 --> Session class already loaded. Second attempt ignored.
INFO - 2024-05-19 17:15:21 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\payments/add_payment_form.php
DEBUG - 2024-05-19 17:15:21 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-05-19 17:15:21 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\include/top_menu.php
INFO - 2024-05-19 17:15:21 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\include/admin_loggedin_info.php
INFO - 2024-05-19 17:15:21 --> Model Class Initialized
INFO - 2024-05-19 17:15:21 --> Model Class Initialized
INFO - 2024-05-19 17:15:21 --> Model Class Initialized
INFO - 2024-05-19 17:15:21 --> Model Class Initialized
INFO - 2024-05-19 17:15:22 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\include/admin_header.php
INFO - 2024-05-19 17:15:22 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\include/admin_footer.php
INFO - 2024-05-19 17:15:22 --> File loaded: E:\xampp\htdocs\maurnaturo\application\views\admin_html_template.php
INFO - 2024-05-19 17:15:22 --> Final output sent to browser
DEBUG - 2024-05-19 17:15:22 --> Total execution time: 1.0636
