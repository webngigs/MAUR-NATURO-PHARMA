<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2023-10-20 00:33:51 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-20 00:33:51 --> Config Class Initialized
INFO - 2023-10-20 00:33:51 --> Hooks Class Initialized
DEBUG - 2023-10-20 00:33:51 --> UTF-8 Support Enabled
INFO - 2023-10-20 00:33:51 --> Utf8 Class Initialized
INFO - 2023-10-20 00:33:51 --> URI Class Initialized
INFO - 2023-10-20 00:33:51 --> Router Class Initialized
INFO - 2023-10-20 00:33:51 --> Output Class Initialized
INFO - 2023-10-20 00:33:51 --> Security Class Initialized
DEBUG - 2023-10-20 00:33:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-20 00:33:51 --> Input Class Initialized
INFO - 2023-10-20 00:33:51 --> Language Class Initialized
ERROR - 2023-10-20 00:33:51 --> 404 Page Not Found: Sitemapxml/index
ERROR - 2023-10-20 00:33:53 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-20 00:33:53 --> Config Class Initialized
INFO - 2023-10-20 00:33:53 --> Hooks Class Initialized
DEBUG - 2023-10-20 00:33:53 --> UTF-8 Support Enabled
INFO - 2023-10-20 00:33:53 --> Utf8 Class Initialized
INFO - 2023-10-20 00:33:53 --> URI Class Initialized
DEBUG - 2023-10-20 00:33:53 --> No URI present. Default controller set.
INFO - 2023-10-20 00:33:53 --> Router Class Initialized
INFO - 2023-10-20 00:33:53 --> Output Class Initialized
INFO - 2023-10-20 00:33:53 --> Security Class Initialized
DEBUG - 2023-10-20 00:33:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-20 00:33:53 --> Input Class Initialized
INFO - 2023-10-20 00:33:53 --> Language Class Initialized
INFO - 2023-10-20 00:33:53 --> Loader Class Initialized
INFO - 2023-10-20 00:33:53 --> Helper loaded: url_helper
INFO - 2023-10-20 00:33:53 --> Helper loaded: file_helper
INFO - 2023-10-20 00:33:53 --> Helper loaded: html_helper
INFO - 2023-10-20 00:33:53 --> Helper loaded: text_helper
INFO - 2023-10-20 00:33:53 --> Helper loaded: form_helper
INFO - 2023-10-20 00:33:53 --> Helper loaded: lang_helper
INFO - 2023-10-20 00:33:53 --> Helper loaded: security_helper
INFO - 2023-10-20 00:33:53 --> Helper loaded: cookie_helper
INFO - 2023-10-20 00:33:53 --> Database Driver Class Initialized
INFO - 2023-10-20 00:33:53 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-20 00:33:53 --> Parser Class Initialized
INFO - 2023-10-20 00:33:53 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-20 00:33:53 --> Pagination Class Initialized
INFO - 2023-10-20 00:33:53 --> Form Validation Class Initialized
INFO - 2023-10-20 00:33:53 --> Controller Class Initialized
INFO - 2023-10-20 00:33:53 --> Model Class Initialized
DEBUG - 2023-10-20 00:33:53 --> Session class already loaded. Second attempt ignored.
ERROR - 2023-10-20 00:33:54 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-20 00:33:54 --> Config Class Initialized
INFO - 2023-10-20 00:33:54 --> Hooks Class Initialized
DEBUG - 2023-10-20 00:33:54 --> UTF-8 Support Enabled
INFO - 2023-10-20 00:33:54 --> Utf8 Class Initialized
INFO - 2023-10-20 00:33:54 --> URI Class Initialized
INFO - 2023-10-20 00:33:54 --> Router Class Initialized
INFO - 2023-10-20 00:33:54 --> Output Class Initialized
INFO - 2023-10-20 00:33:54 --> Security Class Initialized
DEBUG - 2023-10-20 00:33:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-20 00:33:54 --> Input Class Initialized
INFO - 2023-10-20 00:33:54 --> Language Class Initialized
ERROR - 2023-10-20 00:33:54 --> 404 Page Not Found: Wp-cronphp/index
ERROR - 2023-10-20 01:01:28 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-20 01:01:28 --> Config Class Initialized
INFO - 2023-10-20 01:01:28 --> Hooks Class Initialized
DEBUG - 2023-10-20 01:01:28 --> UTF-8 Support Enabled
INFO - 2023-10-20 01:01:28 --> Utf8 Class Initialized
INFO - 2023-10-20 01:01:28 --> URI Class Initialized
INFO - 2023-10-20 01:01:28 --> Router Class Initialized
INFO - 2023-10-20 01:01:28 --> Output Class Initialized
INFO - 2023-10-20 01:01:28 --> Security Class Initialized
DEBUG - 2023-10-20 01:01:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-20 01:01:28 --> Input Class Initialized
INFO - 2023-10-20 01:01:28 --> Language Class Initialized
ERROR - 2023-10-20 01:01:28 --> 404 Page Not Found: Well-known/assetlinks.json
ERROR - 2023-10-20 03:49:42 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-20 03:49:42 --> Config Class Initialized
INFO - 2023-10-20 03:49:42 --> Hooks Class Initialized
DEBUG - 2023-10-20 03:49:42 --> UTF-8 Support Enabled
INFO - 2023-10-20 03:49:42 --> Utf8 Class Initialized
INFO - 2023-10-20 03:49:42 --> URI Class Initialized
DEBUG - 2023-10-20 03:49:42 --> No URI present. Default controller set.
INFO - 2023-10-20 03:49:42 --> Router Class Initialized
INFO - 2023-10-20 03:49:42 --> Output Class Initialized
INFO - 2023-10-20 03:49:42 --> Security Class Initialized
DEBUG - 2023-10-20 03:49:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-20 03:49:42 --> Input Class Initialized
INFO - 2023-10-20 03:49:42 --> Language Class Initialized
INFO - 2023-10-20 03:49:42 --> Loader Class Initialized
INFO - 2023-10-20 03:49:42 --> Helper loaded: url_helper
INFO - 2023-10-20 03:49:42 --> Helper loaded: file_helper
INFO - 2023-10-20 03:49:42 --> Helper loaded: html_helper
INFO - 2023-10-20 03:49:42 --> Helper loaded: text_helper
INFO - 2023-10-20 03:49:42 --> Helper loaded: form_helper
INFO - 2023-10-20 03:49:42 --> Helper loaded: lang_helper
INFO - 2023-10-20 03:49:42 --> Helper loaded: security_helper
INFO - 2023-10-20 03:49:42 --> Helper loaded: cookie_helper
INFO - 2023-10-20 03:49:42 --> Database Driver Class Initialized
INFO - 2023-10-20 03:49:42 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-20 03:49:42 --> Parser Class Initialized
INFO - 2023-10-20 03:49:42 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-20 03:49:42 --> Pagination Class Initialized
INFO - 2023-10-20 03:49:42 --> Form Validation Class Initialized
INFO - 2023-10-20 03:49:42 --> Controller Class Initialized
INFO - 2023-10-20 03:49:42 --> Model Class Initialized
DEBUG - 2023-10-20 03:49:42 --> Session class already loaded. Second attempt ignored.
ERROR - 2023-10-20 03:49:42 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-20 03:49:42 --> Config Class Initialized
INFO - 2023-10-20 03:49:42 --> Hooks Class Initialized
DEBUG - 2023-10-20 03:49:42 --> UTF-8 Support Enabled
INFO - 2023-10-20 03:49:42 --> Utf8 Class Initialized
INFO - 2023-10-20 03:49:42 --> URI Class Initialized
INFO - 2023-10-20 03:49:42 --> Router Class Initialized
INFO - 2023-10-20 03:49:42 --> Output Class Initialized
INFO - 2023-10-20 03:49:42 --> Security Class Initialized
DEBUG - 2023-10-20 03:49:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-20 03:49:42 --> Input Class Initialized
INFO - 2023-10-20 03:49:42 --> Language Class Initialized
INFO - 2023-10-20 03:49:42 --> Loader Class Initialized
INFO - 2023-10-20 03:49:42 --> Helper loaded: url_helper
INFO - 2023-10-20 03:49:42 --> Helper loaded: file_helper
INFO - 2023-10-20 03:49:42 --> Helper loaded: html_helper
INFO - 2023-10-20 03:49:42 --> Helper loaded: text_helper
INFO - 2023-10-20 03:49:42 --> Helper loaded: form_helper
INFO - 2023-10-20 03:49:42 --> Helper loaded: lang_helper
INFO - 2023-10-20 03:49:42 --> Helper loaded: security_helper
INFO - 2023-10-20 03:49:42 --> Helper loaded: cookie_helper
INFO - 2023-10-20 03:49:42 --> Database Driver Class Initialized
INFO - 2023-10-20 03:49:42 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-20 03:49:42 --> Parser Class Initialized
INFO - 2023-10-20 03:49:42 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-20 03:49:42 --> Pagination Class Initialized
INFO - 2023-10-20 03:49:42 --> Form Validation Class Initialized
INFO - 2023-10-20 03:49:42 --> Controller Class Initialized
INFO - 2023-10-20 03:49:42 --> Model Class Initialized
DEBUG - 2023-10-20 03:49:42 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-20 03:49:42 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2023-10-20 03:49:42 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-10-20 03:49:42 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-10-20 03:49:42 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-10-20 03:49:42 --> Model Class Initialized
INFO - 2023-10-20 03:49:42 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-10-20 03:49:42 --> Final output sent to browser
DEBUG - 2023-10-20 03:49:42 --> Total execution time: 0.0335
ERROR - 2023-10-20 03:49:46 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-20 03:49:46 --> Config Class Initialized
INFO - 2023-10-20 03:49:46 --> Hooks Class Initialized
DEBUG - 2023-10-20 03:49:46 --> UTF-8 Support Enabled
INFO - 2023-10-20 03:49:46 --> Utf8 Class Initialized
INFO - 2023-10-20 03:49:46 --> URI Class Initialized
INFO - 2023-10-20 03:49:46 --> Router Class Initialized
INFO - 2023-10-20 03:49:46 --> Output Class Initialized
INFO - 2023-10-20 03:49:46 --> Security Class Initialized
DEBUG - 2023-10-20 03:49:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-20 03:49:46 --> Input Class Initialized
INFO - 2023-10-20 03:49:46 --> Language Class Initialized
INFO - 2023-10-20 03:49:46 --> Loader Class Initialized
INFO - 2023-10-20 03:49:46 --> Helper loaded: url_helper
INFO - 2023-10-20 03:49:46 --> Helper loaded: file_helper
INFO - 2023-10-20 03:49:46 --> Helper loaded: html_helper
INFO - 2023-10-20 03:49:46 --> Helper loaded: text_helper
INFO - 2023-10-20 03:49:46 --> Helper loaded: form_helper
INFO - 2023-10-20 03:49:46 --> Helper loaded: lang_helper
INFO - 2023-10-20 03:49:46 --> Helper loaded: security_helper
INFO - 2023-10-20 03:49:46 --> Helper loaded: cookie_helper
INFO - 2023-10-20 03:49:46 --> Database Driver Class Initialized
INFO - 2023-10-20 03:49:46 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-20 03:49:46 --> Parser Class Initialized
INFO - 2023-10-20 03:49:46 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-20 03:49:46 --> Pagination Class Initialized
INFO - 2023-10-20 03:49:46 --> Form Validation Class Initialized
INFO - 2023-10-20 03:49:46 --> Controller Class Initialized
INFO - 2023-10-20 03:49:46 --> Model Class Initialized
DEBUG - 2023-10-20 03:49:46 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-20 03:49:46 --> Model Class Initialized
INFO - 2023-10-20 03:49:46 --> Final output sent to browser
DEBUG - 2023-10-20 03:49:46 --> Total execution time: 0.0190
ERROR - 2023-10-20 03:49:46 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-20 03:49:46 --> Config Class Initialized
INFO - 2023-10-20 03:49:46 --> Hooks Class Initialized
DEBUG - 2023-10-20 03:49:46 --> UTF-8 Support Enabled
INFO - 2023-10-20 03:49:46 --> Utf8 Class Initialized
INFO - 2023-10-20 03:49:46 --> URI Class Initialized
DEBUG - 2023-10-20 03:49:46 --> No URI present. Default controller set.
INFO - 2023-10-20 03:49:46 --> Router Class Initialized
INFO - 2023-10-20 03:49:46 --> Output Class Initialized
INFO - 2023-10-20 03:49:46 --> Security Class Initialized
DEBUG - 2023-10-20 03:49:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-20 03:49:46 --> Input Class Initialized
INFO - 2023-10-20 03:49:46 --> Language Class Initialized
INFO - 2023-10-20 03:49:46 --> Loader Class Initialized
INFO - 2023-10-20 03:49:46 --> Helper loaded: url_helper
INFO - 2023-10-20 03:49:46 --> Helper loaded: file_helper
INFO - 2023-10-20 03:49:46 --> Helper loaded: html_helper
INFO - 2023-10-20 03:49:46 --> Helper loaded: text_helper
INFO - 2023-10-20 03:49:46 --> Helper loaded: form_helper
INFO - 2023-10-20 03:49:46 --> Helper loaded: lang_helper
INFO - 2023-10-20 03:49:46 --> Helper loaded: security_helper
INFO - 2023-10-20 03:49:46 --> Helper loaded: cookie_helper
INFO - 2023-10-20 03:49:46 --> Database Driver Class Initialized
INFO - 2023-10-20 03:49:46 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-20 03:49:46 --> Parser Class Initialized
INFO - 2023-10-20 03:49:46 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-20 03:49:46 --> Pagination Class Initialized
INFO - 2023-10-20 03:49:46 --> Form Validation Class Initialized
INFO - 2023-10-20 03:49:46 --> Controller Class Initialized
INFO - 2023-10-20 03:49:46 --> Model Class Initialized
DEBUG - 2023-10-20 03:49:46 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-20 03:49:46 --> Model Class Initialized
DEBUG - 2023-10-20 03:49:46 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-20 03:49:46 --> Model Class Initialized
INFO - 2023-10-20 03:49:46 --> Model Class Initialized
INFO - 2023-10-20 03:49:46 --> Model Class Initialized
INFO - 2023-10-20 03:49:46 --> Model Class Initialized
DEBUG - 2023-10-20 03:49:46 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-10-20 03:49:46 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-20 03:49:46 --> Model Class Initialized
INFO - 2023-10-20 03:49:46 --> Model Class Initialized
INFO - 2023-10-20 03:49:46 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-10-20 03:49:46 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-10-20 03:49:46 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-10-20 03:49:46 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-10-20 03:49:46 --> Model Class Initialized
INFO - 2023-10-20 03:49:46 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-10-20 03:49:46 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-10-20 03:49:46 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-10-20 03:49:46 --> Final output sent to browser
DEBUG - 2023-10-20 03:49:46 --> Total execution time: 0.3833
ERROR - 2023-10-20 03:49:47 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-20 03:49:47 --> Config Class Initialized
INFO - 2023-10-20 03:49:47 --> Hooks Class Initialized
DEBUG - 2023-10-20 03:49:47 --> UTF-8 Support Enabled
INFO - 2023-10-20 03:49:47 --> Utf8 Class Initialized
INFO - 2023-10-20 03:49:47 --> URI Class Initialized
INFO - 2023-10-20 03:49:47 --> Router Class Initialized
INFO - 2023-10-20 03:49:47 --> Output Class Initialized
INFO - 2023-10-20 03:49:47 --> Security Class Initialized
DEBUG - 2023-10-20 03:49:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-20 03:49:47 --> Input Class Initialized
INFO - 2023-10-20 03:49:47 --> Language Class Initialized
INFO - 2023-10-20 03:49:47 --> Loader Class Initialized
INFO - 2023-10-20 03:49:47 --> Helper loaded: url_helper
INFO - 2023-10-20 03:49:47 --> Helper loaded: file_helper
INFO - 2023-10-20 03:49:47 --> Helper loaded: html_helper
INFO - 2023-10-20 03:49:47 --> Helper loaded: text_helper
INFO - 2023-10-20 03:49:47 --> Helper loaded: form_helper
INFO - 2023-10-20 03:49:47 --> Helper loaded: lang_helper
INFO - 2023-10-20 03:49:47 --> Helper loaded: security_helper
INFO - 2023-10-20 03:49:47 --> Helper loaded: cookie_helper
INFO - 2023-10-20 03:49:47 --> Database Driver Class Initialized
INFO - 2023-10-20 03:49:47 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-20 03:49:47 --> Parser Class Initialized
INFO - 2023-10-20 03:49:47 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-20 03:49:47 --> Pagination Class Initialized
INFO - 2023-10-20 03:49:47 --> Form Validation Class Initialized
INFO - 2023-10-20 03:49:47 --> Controller Class Initialized
DEBUG - 2023-10-20 03:49:47 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-10-20 03:49:47 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-20 03:49:47 --> Model Class Initialized
INFO - 2023-10-20 03:49:47 --> Final output sent to browser
DEBUG - 2023-10-20 03:49:47 --> Total execution time: 0.0135
ERROR - 2023-10-20 03:49:55 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-20 03:49:55 --> Config Class Initialized
INFO - 2023-10-20 03:49:55 --> Hooks Class Initialized
DEBUG - 2023-10-20 03:49:55 --> UTF-8 Support Enabled
INFO - 2023-10-20 03:49:55 --> Utf8 Class Initialized
INFO - 2023-10-20 03:49:55 --> URI Class Initialized
INFO - 2023-10-20 03:49:55 --> Router Class Initialized
INFO - 2023-10-20 03:49:55 --> Output Class Initialized
INFO - 2023-10-20 03:49:55 --> Security Class Initialized
DEBUG - 2023-10-20 03:49:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-20 03:49:55 --> Input Class Initialized
INFO - 2023-10-20 03:49:55 --> Language Class Initialized
INFO - 2023-10-20 03:49:55 --> Loader Class Initialized
INFO - 2023-10-20 03:49:55 --> Helper loaded: url_helper
INFO - 2023-10-20 03:49:55 --> Helper loaded: file_helper
INFO - 2023-10-20 03:49:55 --> Helper loaded: html_helper
INFO - 2023-10-20 03:49:55 --> Helper loaded: text_helper
INFO - 2023-10-20 03:49:55 --> Helper loaded: form_helper
INFO - 2023-10-20 03:49:55 --> Helper loaded: lang_helper
INFO - 2023-10-20 03:49:55 --> Helper loaded: security_helper
INFO - 2023-10-20 03:49:55 --> Helper loaded: cookie_helper
INFO - 2023-10-20 03:49:55 --> Database Driver Class Initialized
INFO - 2023-10-20 03:49:55 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-20 03:49:55 --> Parser Class Initialized
INFO - 2023-10-20 03:49:55 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-20 03:49:55 --> Pagination Class Initialized
INFO - 2023-10-20 03:49:55 --> Form Validation Class Initialized
INFO - 2023-10-20 03:49:55 --> Controller Class Initialized
INFO - 2023-10-20 03:49:55 --> Model Class Initialized
DEBUG - 2023-10-20 03:49:55 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-10-20 03:49:55 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-20 03:49:55 --> Model Class Initialized
DEBUG - 2023-10-20 03:49:55 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-20 03:49:55 --> Model Class Initialized
INFO - 2023-10-20 03:49:55 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice.php
DEBUG - 2023-10-20 03:49:55 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-10-20 03:49:55 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-10-20 03:49:55 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-10-20 03:49:55 --> Model Class Initialized
INFO - 2023-10-20 03:49:55 --> Model Class Initialized
INFO - 2023-10-20 03:49:55 --> Model Class Initialized
INFO - 2023-10-20 03:49:55 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-10-20 03:49:55 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-10-20 03:49:55 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-10-20 03:49:55 --> Final output sent to browser
DEBUG - 2023-10-20 03:49:55 --> Total execution time: 0.2161
ERROR - 2023-10-20 03:49:56 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-20 03:49:56 --> Config Class Initialized
INFO - 2023-10-20 03:49:56 --> Hooks Class Initialized
DEBUG - 2023-10-20 03:49:56 --> UTF-8 Support Enabled
INFO - 2023-10-20 03:49:56 --> Utf8 Class Initialized
INFO - 2023-10-20 03:49:56 --> URI Class Initialized
INFO - 2023-10-20 03:49:56 --> Router Class Initialized
INFO - 2023-10-20 03:49:56 --> Output Class Initialized
INFO - 2023-10-20 03:49:56 --> Security Class Initialized
DEBUG - 2023-10-20 03:49:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-20 03:49:56 --> Input Class Initialized
INFO - 2023-10-20 03:49:56 --> Language Class Initialized
INFO - 2023-10-20 03:49:56 --> Loader Class Initialized
INFO - 2023-10-20 03:49:56 --> Helper loaded: url_helper
INFO - 2023-10-20 03:49:56 --> Helper loaded: file_helper
INFO - 2023-10-20 03:49:56 --> Helper loaded: html_helper
INFO - 2023-10-20 03:49:56 --> Helper loaded: text_helper
INFO - 2023-10-20 03:49:56 --> Helper loaded: form_helper
INFO - 2023-10-20 03:49:56 --> Helper loaded: lang_helper
INFO - 2023-10-20 03:49:56 --> Helper loaded: security_helper
INFO - 2023-10-20 03:49:56 --> Helper loaded: cookie_helper
INFO - 2023-10-20 03:49:56 --> Database Driver Class Initialized
INFO - 2023-10-20 03:49:56 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-20 03:49:56 --> Parser Class Initialized
INFO - 2023-10-20 03:49:56 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-20 03:49:56 --> Pagination Class Initialized
INFO - 2023-10-20 03:49:56 --> Form Validation Class Initialized
INFO - 2023-10-20 03:49:56 --> Controller Class Initialized
INFO - 2023-10-20 03:49:56 --> Model Class Initialized
DEBUG - 2023-10-20 03:49:56 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-10-20 03:49:56 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-20 03:49:56 --> Model Class Initialized
DEBUG - 2023-10-20 03:49:56 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-20 03:49:56 --> Model Class Initialized
INFO - 2023-10-20 03:49:56 --> Final output sent to browser
DEBUG - 2023-10-20 03:49:56 --> Total execution time: 0.0667
ERROR - 2023-10-20 03:50:00 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-20 03:50:00 --> Config Class Initialized
INFO - 2023-10-20 03:50:00 --> Hooks Class Initialized
DEBUG - 2023-10-20 03:50:00 --> UTF-8 Support Enabled
INFO - 2023-10-20 03:50:00 --> Utf8 Class Initialized
INFO - 2023-10-20 03:50:00 --> URI Class Initialized
INFO - 2023-10-20 03:50:00 --> Router Class Initialized
INFO - 2023-10-20 03:50:00 --> Output Class Initialized
INFO - 2023-10-20 03:50:00 --> Security Class Initialized
DEBUG - 2023-10-20 03:50:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-20 03:50:00 --> Input Class Initialized
INFO - 2023-10-20 03:50:00 --> Language Class Initialized
INFO - 2023-10-20 03:50:00 --> Loader Class Initialized
INFO - 2023-10-20 03:50:00 --> Helper loaded: url_helper
INFO - 2023-10-20 03:50:00 --> Helper loaded: file_helper
INFO - 2023-10-20 03:50:00 --> Helper loaded: html_helper
INFO - 2023-10-20 03:50:00 --> Helper loaded: text_helper
INFO - 2023-10-20 03:50:00 --> Helper loaded: form_helper
INFO - 2023-10-20 03:50:00 --> Helper loaded: lang_helper
INFO - 2023-10-20 03:50:00 --> Helper loaded: security_helper
INFO - 2023-10-20 03:50:00 --> Helper loaded: cookie_helper
INFO - 2023-10-20 03:50:00 --> Database Driver Class Initialized
INFO - 2023-10-20 03:50:00 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-20 03:50:00 --> Parser Class Initialized
INFO - 2023-10-20 03:50:00 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-20 03:50:00 --> Pagination Class Initialized
INFO - 2023-10-20 03:50:00 --> Form Validation Class Initialized
INFO - 2023-10-20 03:50:00 --> Controller Class Initialized
INFO - 2023-10-20 03:50:00 --> Model Class Initialized
DEBUG - 2023-10-20 03:50:00 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-10-20 03:50:00 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-20 03:50:00 --> Model Class Initialized
DEBUG - 2023-10-20 03:50:00 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-20 03:50:00 --> Model Class Initialized
INFO - 2023-10-20 03:50:00 --> Final output sent to browser
DEBUG - 2023-10-20 03:50:00 --> Total execution time: 0.0678
ERROR - 2023-10-20 03:50:00 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-20 03:50:00 --> Config Class Initialized
INFO - 2023-10-20 03:50:00 --> Hooks Class Initialized
DEBUG - 2023-10-20 03:50:00 --> UTF-8 Support Enabled
INFO - 2023-10-20 03:50:00 --> Utf8 Class Initialized
INFO - 2023-10-20 03:50:00 --> URI Class Initialized
INFO - 2023-10-20 03:50:00 --> Router Class Initialized
INFO - 2023-10-20 03:50:00 --> Output Class Initialized
INFO - 2023-10-20 03:50:00 --> Security Class Initialized
DEBUG - 2023-10-20 03:50:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-20 03:50:00 --> Input Class Initialized
INFO - 2023-10-20 03:50:00 --> Language Class Initialized
INFO - 2023-10-20 03:50:00 --> Loader Class Initialized
INFO - 2023-10-20 03:50:00 --> Helper loaded: url_helper
INFO - 2023-10-20 03:50:00 --> Helper loaded: file_helper
INFO - 2023-10-20 03:50:00 --> Helper loaded: html_helper
INFO - 2023-10-20 03:50:00 --> Helper loaded: text_helper
INFO - 2023-10-20 03:50:00 --> Helper loaded: form_helper
INFO - 2023-10-20 03:50:00 --> Helper loaded: lang_helper
INFO - 2023-10-20 03:50:00 --> Helper loaded: security_helper
INFO - 2023-10-20 03:50:00 --> Helper loaded: cookie_helper
INFO - 2023-10-20 03:50:00 --> Database Driver Class Initialized
INFO - 2023-10-20 03:50:00 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-20 03:50:00 --> Parser Class Initialized
INFO - 2023-10-20 03:50:00 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-20 03:50:00 --> Pagination Class Initialized
INFO - 2023-10-20 03:50:00 --> Form Validation Class Initialized
INFO - 2023-10-20 03:50:00 --> Controller Class Initialized
INFO - 2023-10-20 03:50:00 --> Model Class Initialized
DEBUG - 2023-10-20 03:50:00 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-10-20 03:50:00 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-20 03:50:00 --> Model Class Initialized
DEBUG - 2023-10-20 03:50:00 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-20 03:50:00 --> Model Class Initialized
INFO - 2023-10-20 03:50:01 --> Final output sent to browser
DEBUG - 2023-10-20 03:50:01 --> Total execution time: 0.0610
ERROR - 2023-10-20 03:50:01 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-20 03:50:01 --> Config Class Initialized
INFO - 2023-10-20 03:50:01 --> Hooks Class Initialized
DEBUG - 2023-10-20 03:50:01 --> UTF-8 Support Enabled
INFO - 2023-10-20 03:50:01 --> Utf8 Class Initialized
INFO - 2023-10-20 03:50:01 --> URI Class Initialized
INFO - 2023-10-20 03:50:01 --> Router Class Initialized
INFO - 2023-10-20 03:50:01 --> Output Class Initialized
INFO - 2023-10-20 03:50:01 --> Security Class Initialized
DEBUG - 2023-10-20 03:50:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-20 03:50:01 --> Input Class Initialized
INFO - 2023-10-20 03:50:01 --> Language Class Initialized
INFO - 2023-10-20 03:50:01 --> Loader Class Initialized
INFO - 2023-10-20 03:50:01 --> Helper loaded: url_helper
INFO - 2023-10-20 03:50:01 --> Helper loaded: file_helper
INFO - 2023-10-20 03:50:01 --> Helper loaded: html_helper
INFO - 2023-10-20 03:50:01 --> Helper loaded: text_helper
INFO - 2023-10-20 03:50:01 --> Helper loaded: form_helper
INFO - 2023-10-20 03:50:01 --> Helper loaded: lang_helper
INFO - 2023-10-20 03:50:01 --> Helper loaded: security_helper
INFO - 2023-10-20 03:50:01 --> Helper loaded: cookie_helper
INFO - 2023-10-20 03:50:01 --> Database Driver Class Initialized
INFO - 2023-10-20 03:50:01 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-20 03:50:01 --> Parser Class Initialized
INFO - 2023-10-20 03:50:01 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-20 03:50:01 --> Pagination Class Initialized
INFO - 2023-10-20 03:50:01 --> Form Validation Class Initialized
INFO - 2023-10-20 03:50:01 --> Controller Class Initialized
INFO - 2023-10-20 03:50:01 --> Model Class Initialized
DEBUG - 2023-10-20 03:50:01 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-10-20 03:50:01 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-20 03:50:01 --> Model Class Initialized
DEBUG - 2023-10-20 03:50:01 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-20 03:50:01 --> Model Class Initialized
INFO - 2023-10-20 03:50:01 --> Final output sent to browser
DEBUG - 2023-10-20 03:50:01 --> Total execution time: 0.0594
ERROR - 2023-10-20 03:50:02 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-20 03:50:02 --> Config Class Initialized
INFO - 2023-10-20 03:50:02 --> Hooks Class Initialized
DEBUG - 2023-10-20 03:50:02 --> UTF-8 Support Enabled
INFO - 2023-10-20 03:50:02 --> Utf8 Class Initialized
INFO - 2023-10-20 03:50:02 --> URI Class Initialized
INFO - 2023-10-20 03:50:02 --> Router Class Initialized
INFO - 2023-10-20 03:50:02 --> Output Class Initialized
INFO - 2023-10-20 03:50:02 --> Security Class Initialized
DEBUG - 2023-10-20 03:50:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-20 03:50:02 --> Input Class Initialized
INFO - 2023-10-20 03:50:02 --> Language Class Initialized
INFO - 2023-10-20 03:50:02 --> Loader Class Initialized
INFO - 2023-10-20 03:50:02 --> Helper loaded: url_helper
INFO - 2023-10-20 03:50:02 --> Helper loaded: file_helper
INFO - 2023-10-20 03:50:02 --> Helper loaded: html_helper
INFO - 2023-10-20 03:50:02 --> Helper loaded: text_helper
INFO - 2023-10-20 03:50:02 --> Helper loaded: form_helper
INFO - 2023-10-20 03:50:02 --> Helper loaded: lang_helper
INFO - 2023-10-20 03:50:02 --> Helper loaded: security_helper
INFO - 2023-10-20 03:50:02 --> Helper loaded: cookie_helper
INFO - 2023-10-20 03:50:02 --> Database Driver Class Initialized
INFO - 2023-10-20 03:50:02 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-20 03:50:02 --> Parser Class Initialized
INFO - 2023-10-20 03:50:02 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-20 03:50:02 --> Pagination Class Initialized
INFO - 2023-10-20 03:50:02 --> Form Validation Class Initialized
INFO - 2023-10-20 03:50:02 --> Controller Class Initialized
INFO - 2023-10-20 03:50:02 --> Model Class Initialized
DEBUG - 2023-10-20 03:50:02 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-10-20 03:50:02 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-20 03:50:02 --> Model Class Initialized
DEBUG - 2023-10-20 03:50:02 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-20 03:50:02 --> Model Class Initialized
INFO - 2023-10-20 03:50:02 --> Final output sent to browser
DEBUG - 2023-10-20 03:50:02 --> Total execution time: 0.0377
ERROR - 2023-10-20 03:50:02 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-20 03:50:02 --> Config Class Initialized
INFO - 2023-10-20 03:50:02 --> Hooks Class Initialized
DEBUG - 2023-10-20 03:50:02 --> UTF-8 Support Enabled
INFO - 2023-10-20 03:50:02 --> Utf8 Class Initialized
INFO - 2023-10-20 03:50:02 --> URI Class Initialized
INFO - 2023-10-20 03:50:02 --> Router Class Initialized
INFO - 2023-10-20 03:50:02 --> Output Class Initialized
INFO - 2023-10-20 03:50:02 --> Security Class Initialized
DEBUG - 2023-10-20 03:50:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-20 03:50:02 --> Input Class Initialized
INFO - 2023-10-20 03:50:02 --> Language Class Initialized
INFO - 2023-10-20 03:50:02 --> Loader Class Initialized
INFO - 2023-10-20 03:50:02 --> Helper loaded: url_helper
INFO - 2023-10-20 03:50:02 --> Helper loaded: file_helper
INFO - 2023-10-20 03:50:02 --> Helper loaded: html_helper
INFO - 2023-10-20 03:50:02 --> Helper loaded: text_helper
INFO - 2023-10-20 03:50:02 --> Helper loaded: form_helper
INFO - 2023-10-20 03:50:02 --> Helper loaded: lang_helper
INFO - 2023-10-20 03:50:02 --> Helper loaded: security_helper
INFO - 2023-10-20 03:50:02 --> Helper loaded: cookie_helper
INFO - 2023-10-20 03:50:02 --> Database Driver Class Initialized
INFO - 2023-10-20 03:50:02 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-20 03:50:02 --> Parser Class Initialized
INFO - 2023-10-20 03:50:02 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-20 03:50:02 --> Pagination Class Initialized
INFO - 2023-10-20 03:50:02 --> Form Validation Class Initialized
INFO - 2023-10-20 03:50:02 --> Controller Class Initialized
INFO - 2023-10-20 03:50:02 --> Model Class Initialized
DEBUG - 2023-10-20 03:50:02 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-10-20 03:50:02 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-20 03:50:02 --> Model Class Initialized
DEBUG - 2023-10-20 03:50:02 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-20 03:50:02 --> Model Class Initialized
INFO - 2023-10-20 03:50:02 --> Final output sent to browser
DEBUG - 2023-10-20 03:50:02 --> Total execution time: 0.0346
ERROR - 2023-10-20 03:50:02 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-20 03:50:02 --> Config Class Initialized
INFO - 2023-10-20 03:50:02 --> Hooks Class Initialized
DEBUG - 2023-10-20 03:50:02 --> UTF-8 Support Enabled
INFO - 2023-10-20 03:50:02 --> Utf8 Class Initialized
INFO - 2023-10-20 03:50:02 --> URI Class Initialized
INFO - 2023-10-20 03:50:02 --> Router Class Initialized
INFO - 2023-10-20 03:50:02 --> Output Class Initialized
INFO - 2023-10-20 03:50:02 --> Security Class Initialized
DEBUG - 2023-10-20 03:50:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-20 03:50:02 --> Input Class Initialized
INFO - 2023-10-20 03:50:02 --> Language Class Initialized
INFO - 2023-10-20 03:50:02 --> Loader Class Initialized
INFO - 2023-10-20 03:50:02 --> Helper loaded: url_helper
INFO - 2023-10-20 03:50:02 --> Helper loaded: file_helper
INFO - 2023-10-20 03:50:02 --> Helper loaded: html_helper
INFO - 2023-10-20 03:50:02 --> Helper loaded: text_helper
INFO - 2023-10-20 03:50:02 --> Helper loaded: form_helper
INFO - 2023-10-20 03:50:02 --> Helper loaded: lang_helper
INFO - 2023-10-20 03:50:02 --> Helper loaded: security_helper
INFO - 2023-10-20 03:50:02 --> Helper loaded: cookie_helper
INFO - 2023-10-20 03:50:02 --> Database Driver Class Initialized
INFO - 2023-10-20 03:50:02 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-20 03:50:02 --> Parser Class Initialized
INFO - 2023-10-20 03:50:02 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-20 03:50:02 --> Pagination Class Initialized
INFO - 2023-10-20 03:50:02 --> Form Validation Class Initialized
INFO - 2023-10-20 03:50:02 --> Controller Class Initialized
INFO - 2023-10-20 03:50:02 --> Model Class Initialized
DEBUG - 2023-10-20 03:50:02 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-10-20 03:50:02 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-20 03:50:02 --> Model Class Initialized
DEBUG - 2023-10-20 03:50:02 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-20 03:50:02 --> Model Class Initialized
INFO - 2023-10-20 03:50:02 --> Final output sent to browser
DEBUG - 2023-10-20 03:50:02 --> Total execution time: 0.0393
ERROR - 2023-10-20 03:50:03 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-20 03:50:03 --> Config Class Initialized
INFO - 2023-10-20 03:50:03 --> Hooks Class Initialized
DEBUG - 2023-10-20 03:50:03 --> UTF-8 Support Enabled
INFO - 2023-10-20 03:50:03 --> Utf8 Class Initialized
INFO - 2023-10-20 03:50:03 --> URI Class Initialized
INFO - 2023-10-20 03:50:03 --> Router Class Initialized
INFO - 2023-10-20 03:50:03 --> Output Class Initialized
INFO - 2023-10-20 03:50:03 --> Security Class Initialized
DEBUG - 2023-10-20 03:50:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-20 03:50:03 --> Input Class Initialized
INFO - 2023-10-20 03:50:03 --> Language Class Initialized
INFO - 2023-10-20 03:50:03 --> Loader Class Initialized
INFO - 2023-10-20 03:50:03 --> Helper loaded: url_helper
INFO - 2023-10-20 03:50:03 --> Helper loaded: file_helper
INFO - 2023-10-20 03:50:03 --> Helper loaded: html_helper
INFO - 2023-10-20 03:50:03 --> Helper loaded: text_helper
INFO - 2023-10-20 03:50:03 --> Helper loaded: form_helper
INFO - 2023-10-20 03:50:03 --> Helper loaded: lang_helper
INFO - 2023-10-20 03:50:03 --> Helper loaded: security_helper
INFO - 2023-10-20 03:50:03 --> Helper loaded: cookie_helper
INFO - 2023-10-20 03:50:03 --> Database Driver Class Initialized
INFO - 2023-10-20 03:50:03 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-20 03:50:03 --> Parser Class Initialized
INFO - 2023-10-20 03:50:03 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-20 03:50:03 --> Pagination Class Initialized
INFO - 2023-10-20 03:50:03 --> Form Validation Class Initialized
INFO - 2023-10-20 03:50:03 --> Controller Class Initialized
INFO - 2023-10-20 03:50:03 --> Model Class Initialized
DEBUG - 2023-10-20 03:50:03 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-10-20 03:50:03 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-20 03:50:03 --> Model Class Initialized
DEBUG - 2023-10-20 03:50:03 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-20 03:50:03 --> Model Class Initialized
INFO - 2023-10-20 03:50:03 --> Final output sent to browser
DEBUG - 2023-10-20 03:50:03 --> Total execution time: 0.0390
ERROR - 2023-10-20 03:57:05 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-20 03:57:05 --> Config Class Initialized
INFO - 2023-10-20 03:57:05 --> Hooks Class Initialized
DEBUG - 2023-10-20 03:57:05 --> UTF-8 Support Enabled
INFO - 2023-10-20 03:57:05 --> Utf8 Class Initialized
INFO - 2023-10-20 03:57:05 --> URI Class Initialized
INFO - 2023-10-20 03:57:05 --> Router Class Initialized
INFO - 2023-10-20 03:57:05 --> Output Class Initialized
INFO - 2023-10-20 03:57:05 --> Security Class Initialized
DEBUG - 2023-10-20 03:57:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-20 03:57:05 --> Input Class Initialized
INFO - 2023-10-20 03:57:05 --> Language Class Initialized
INFO - 2023-10-20 03:57:05 --> Loader Class Initialized
INFO - 2023-10-20 03:57:05 --> Helper loaded: url_helper
INFO - 2023-10-20 03:57:05 --> Helper loaded: file_helper
INFO - 2023-10-20 03:57:05 --> Helper loaded: html_helper
INFO - 2023-10-20 03:57:05 --> Helper loaded: text_helper
INFO - 2023-10-20 03:57:05 --> Helper loaded: form_helper
INFO - 2023-10-20 03:57:05 --> Helper loaded: lang_helper
INFO - 2023-10-20 03:57:05 --> Helper loaded: security_helper
INFO - 2023-10-20 03:57:05 --> Helper loaded: cookie_helper
INFO - 2023-10-20 03:57:05 --> Database Driver Class Initialized
INFO - 2023-10-20 03:57:05 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-20 03:57:05 --> Parser Class Initialized
INFO - 2023-10-20 03:57:05 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-20 03:57:05 --> Pagination Class Initialized
INFO - 2023-10-20 03:57:05 --> Form Validation Class Initialized
INFO - 2023-10-20 03:57:05 --> Controller Class Initialized
INFO - 2023-10-20 03:57:05 --> Model Class Initialized
DEBUG - 2023-10-20 03:57:05 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-10-20 03:57:05 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-20 03:57:05 --> Model Class Initialized
DEBUG - 2023-10-20 03:57:05 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-20 03:57:05 --> Model Class Initialized
INFO - 2023-10-20 03:57:05 --> Final output sent to browser
DEBUG - 2023-10-20 03:57:05 --> Total execution time: 0.0396
ERROR - 2023-10-20 03:57:16 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-20 03:57:16 --> Config Class Initialized
INFO - 2023-10-20 03:57:16 --> Hooks Class Initialized
DEBUG - 2023-10-20 03:57:16 --> UTF-8 Support Enabled
INFO - 2023-10-20 03:57:16 --> Utf8 Class Initialized
INFO - 2023-10-20 03:57:16 --> URI Class Initialized
INFO - 2023-10-20 03:57:16 --> Router Class Initialized
INFO - 2023-10-20 03:57:16 --> Output Class Initialized
INFO - 2023-10-20 03:57:16 --> Security Class Initialized
DEBUG - 2023-10-20 03:57:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-20 03:57:16 --> Input Class Initialized
INFO - 2023-10-20 03:57:16 --> Language Class Initialized
INFO - 2023-10-20 03:57:16 --> Loader Class Initialized
INFO - 2023-10-20 03:57:16 --> Helper loaded: url_helper
INFO - 2023-10-20 03:57:16 --> Helper loaded: file_helper
INFO - 2023-10-20 03:57:16 --> Helper loaded: html_helper
INFO - 2023-10-20 03:57:16 --> Helper loaded: text_helper
INFO - 2023-10-20 03:57:16 --> Helper loaded: form_helper
INFO - 2023-10-20 03:57:16 --> Helper loaded: lang_helper
INFO - 2023-10-20 03:57:16 --> Helper loaded: security_helper
INFO - 2023-10-20 03:57:16 --> Helper loaded: cookie_helper
INFO - 2023-10-20 03:57:16 --> Database Driver Class Initialized
INFO - 2023-10-20 03:57:16 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-20 03:57:16 --> Parser Class Initialized
INFO - 2023-10-20 03:57:16 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-20 03:57:16 --> Pagination Class Initialized
INFO - 2023-10-20 03:57:16 --> Form Validation Class Initialized
INFO - 2023-10-20 03:57:16 --> Controller Class Initialized
INFO - 2023-10-20 03:57:16 --> Model Class Initialized
DEBUG - 2023-10-20 03:57:16 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-10-20 03:57:16 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-20 03:57:16 --> Model Class Initialized
DEBUG - 2023-10-20 03:57:16 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-20 03:57:16 --> Model Class Initialized
INFO - 2023-10-20 03:57:16 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice.php
DEBUG - 2023-10-20 03:57:16 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-10-20 03:57:16 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-10-20 03:57:16 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-10-20 03:57:16 --> Model Class Initialized
INFO - 2023-10-20 03:57:16 --> Model Class Initialized
INFO - 2023-10-20 03:57:16 --> Model Class Initialized
INFO - 2023-10-20 03:57:16 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-10-20 03:57:16 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-10-20 03:57:16 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-10-20 03:57:16 --> Final output sent to browser
DEBUG - 2023-10-20 03:57:16 --> Total execution time: 0.2127
ERROR - 2023-10-20 03:57:17 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-20 03:57:17 --> Config Class Initialized
INFO - 2023-10-20 03:57:17 --> Hooks Class Initialized
DEBUG - 2023-10-20 03:57:17 --> UTF-8 Support Enabled
INFO - 2023-10-20 03:57:17 --> Utf8 Class Initialized
INFO - 2023-10-20 03:57:17 --> URI Class Initialized
INFO - 2023-10-20 03:57:17 --> Router Class Initialized
INFO - 2023-10-20 03:57:17 --> Output Class Initialized
INFO - 2023-10-20 03:57:17 --> Security Class Initialized
DEBUG - 2023-10-20 03:57:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-20 03:57:17 --> Input Class Initialized
INFO - 2023-10-20 03:57:17 --> Language Class Initialized
INFO - 2023-10-20 03:57:17 --> Loader Class Initialized
INFO - 2023-10-20 03:57:17 --> Helper loaded: url_helper
INFO - 2023-10-20 03:57:17 --> Helper loaded: file_helper
INFO - 2023-10-20 03:57:17 --> Helper loaded: html_helper
INFO - 2023-10-20 03:57:17 --> Helper loaded: text_helper
INFO - 2023-10-20 03:57:17 --> Helper loaded: form_helper
INFO - 2023-10-20 03:57:17 --> Helper loaded: lang_helper
INFO - 2023-10-20 03:57:17 --> Helper loaded: security_helper
INFO - 2023-10-20 03:57:17 --> Helper loaded: cookie_helper
INFO - 2023-10-20 03:57:17 --> Database Driver Class Initialized
INFO - 2023-10-20 03:57:17 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-20 03:57:17 --> Parser Class Initialized
INFO - 2023-10-20 03:57:17 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-20 03:57:17 --> Pagination Class Initialized
INFO - 2023-10-20 03:57:17 --> Form Validation Class Initialized
INFO - 2023-10-20 03:57:17 --> Controller Class Initialized
INFO - 2023-10-20 03:57:17 --> Model Class Initialized
DEBUG - 2023-10-20 03:57:17 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-10-20 03:57:17 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-20 03:57:17 --> Model Class Initialized
DEBUG - 2023-10-20 03:57:17 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-20 03:57:17 --> Model Class Initialized
INFO - 2023-10-20 03:57:17 --> Final output sent to browser
DEBUG - 2023-10-20 03:57:17 --> Total execution time: 0.0628
ERROR - 2023-10-20 03:57:21 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-20 03:57:21 --> Config Class Initialized
INFO - 2023-10-20 03:57:21 --> Hooks Class Initialized
DEBUG - 2023-10-20 03:57:21 --> UTF-8 Support Enabled
INFO - 2023-10-20 03:57:21 --> Utf8 Class Initialized
INFO - 2023-10-20 03:57:21 --> URI Class Initialized
INFO - 2023-10-20 03:57:21 --> Router Class Initialized
INFO - 2023-10-20 03:57:21 --> Output Class Initialized
INFO - 2023-10-20 03:57:21 --> Security Class Initialized
DEBUG - 2023-10-20 03:57:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-20 03:57:21 --> Input Class Initialized
INFO - 2023-10-20 03:57:21 --> Language Class Initialized
INFO - 2023-10-20 03:57:21 --> Loader Class Initialized
INFO - 2023-10-20 03:57:21 --> Helper loaded: url_helper
INFO - 2023-10-20 03:57:21 --> Helper loaded: file_helper
INFO - 2023-10-20 03:57:21 --> Helper loaded: html_helper
INFO - 2023-10-20 03:57:21 --> Helper loaded: text_helper
INFO - 2023-10-20 03:57:21 --> Helper loaded: form_helper
INFO - 2023-10-20 03:57:21 --> Helper loaded: lang_helper
INFO - 2023-10-20 03:57:21 --> Helper loaded: security_helper
INFO - 2023-10-20 03:57:21 --> Helper loaded: cookie_helper
INFO - 2023-10-20 03:57:21 --> Database Driver Class Initialized
INFO - 2023-10-20 03:57:21 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-20 03:57:21 --> Parser Class Initialized
INFO - 2023-10-20 03:57:21 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-20 03:57:21 --> Pagination Class Initialized
INFO - 2023-10-20 03:57:21 --> Form Validation Class Initialized
INFO - 2023-10-20 03:57:21 --> Controller Class Initialized
INFO - 2023-10-20 03:57:21 --> Model Class Initialized
DEBUG - 2023-10-20 03:57:21 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-10-20 03:57:21 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-20 03:57:21 --> Model Class Initialized
DEBUG - 2023-10-20 03:57:21 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-20 03:57:21 --> Model Class Initialized
INFO - 2023-10-20 03:57:21 --> Final output sent to browser
DEBUG - 2023-10-20 03:57:21 --> Total execution time: 0.9649
ERROR - 2023-10-20 03:57:30 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-20 03:57:30 --> Config Class Initialized
INFO - 2023-10-20 03:57:30 --> Hooks Class Initialized
DEBUG - 2023-10-20 03:57:30 --> UTF-8 Support Enabled
INFO - 2023-10-20 03:57:30 --> Utf8 Class Initialized
INFO - 2023-10-20 03:57:30 --> URI Class Initialized
DEBUG - 2023-10-20 03:57:30 --> No URI present. Default controller set.
INFO - 2023-10-20 03:57:30 --> Router Class Initialized
INFO - 2023-10-20 03:57:30 --> Output Class Initialized
INFO - 2023-10-20 03:57:30 --> Security Class Initialized
DEBUG - 2023-10-20 03:57:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-20 03:57:30 --> Input Class Initialized
INFO - 2023-10-20 03:57:30 --> Language Class Initialized
INFO - 2023-10-20 03:57:30 --> Loader Class Initialized
INFO - 2023-10-20 03:57:30 --> Helper loaded: url_helper
INFO - 2023-10-20 03:57:30 --> Helper loaded: file_helper
INFO - 2023-10-20 03:57:30 --> Helper loaded: html_helper
INFO - 2023-10-20 03:57:30 --> Helper loaded: text_helper
INFO - 2023-10-20 03:57:30 --> Helper loaded: form_helper
INFO - 2023-10-20 03:57:30 --> Helper loaded: lang_helper
INFO - 2023-10-20 03:57:30 --> Helper loaded: security_helper
INFO - 2023-10-20 03:57:30 --> Helper loaded: cookie_helper
INFO - 2023-10-20 03:57:30 --> Database Driver Class Initialized
INFO - 2023-10-20 03:57:30 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-20 03:57:30 --> Parser Class Initialized
INFO - 2023-10-20 03:57:30 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-20 03:57:30 --> Pagination Class Initialized
INFO - 2023-10-20 03:57:30 --> Form Validation Class Initialized
INFO - 2023-10-20 03:57:30 --> Controller Class Initialized
INFO - 2023-10-20 03:57:30 --> Model Class Initialized
DEBUG - 2023-10-20 03:57:30 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-20 03:57:30 --> Model Class Initialized
DEBUG - 2023-10-20 03:57:30 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-20 03:57:30 --> Model Class Initialized
INFO - 2023-10-20 03:57:30 --> Model Class Initialized
INFO - 2023-10-20 03:57:30 --> Model Class Initialized
INFO - 2023-10-20 03:57:30 --> Model Class Initialized
DEBUG - 2023-10-20 03:57:30 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-10-20 03:57:30 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-20 03:57:30 --> Model Class Initialized
INFO - 2023-10-20 03:57:30 --> Model Class Initialized
INFO - 2023-10-20 03:57:30 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-10-20 03:57:30 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-10-20 03:57:30 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-10-20 03:57:30 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-10-20 03:57:30 --> Model Class Initialized
INFO - 2023-10-20 03:57:30 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-10-20 03:57:30 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-10-20 03:57:30 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-10-20 03:57:30 --> Final output sent to browser
DEBUG - 2023-10-20 03:57:30 --> Total execution time: 0.3751
ERROR - 2023-10-20 03:57:40 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-20 03:57:40 --> Config Class Initialized
INFO - 2023-10-20 03:57:40 --> Hooks Class Initialized
DEBUG - 2023-10-20 03:57:40 --> UTF-8 Support Enabled
INFO - 2023-10-20 03:57:40 --> Utf8 Class Initialized
INFO - 2023-10-20 03:57:40 --> URI Class Initialized
INFO - 2023-10-20 03:57:40 --> Router Class Initialized
INFO - 2023-10-20 03:57:40 --> Output Class Initialized
INFO - 2023-10-20 03:57:40 --> Security Class Initialized
DEBUG - 2023-10-20 03:57:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-20 03:57:40 --> Input Class Initialized
INFO - 2023-10-20 03:57:40 --> Language Class Initialized
INFO - 2023-10-20 03:57:40 --> Loader Class Initialized
INFO - 2023-10-20 03:57:40 --> Helper loaded: url_helper
INFO - 2023-10-20 03:57:40 --> Helper loaded: file_helper
INFO - 2023-10-20 03:57:40 --> Helper loaded: html_helper
INFO - 2023-10-20 03:57:40 --> Helper loaded: text_helper
INFO - 2023-10-20 03:57:40 --> Helper loaded: form_helper
INFO - 2023-10-20 03:57:40 --> Helper loaded: lang_helper
INFO - 2023-10-20 03:57:40 --> Helper loaded: security_helper
INFO - 2023-10-20 03:57:40 --> Helper loaded: cookie_helper
INFO - 2023-10-20 03:57:40 --> Database Driver Class Initialized
INFO - 2023-10-20 03:57:40 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-20 03:57:40 --> Parser Class Initialized
INFO - 2023-10-20 03:57:40 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-20 03:57:40 --> Pagination Class Initialized
INFO - 2023-10-20 03:57:40 --> Form Validation Class Initialized
INFO - 2023-10-20 03:57:40 --> Controller Class Initialized
INFO - 2023-10-20 03:57:40 --> Model Class Initialized
DEBUG - 2023-10-20 03:57:40 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-10-20 03:57:40 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-20 03:57:40 --> Model Class Initialized
DEBUG - 2023-10-20 03:57:40 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-20 03:57:40 --> Model Class Initialized
INFO - 2023-10-20 03:57:40 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice.php
DEBUG - 2023-10-20 03:57:40 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-10-20 03:57:40 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-10-20 03:57:40 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-10-20 03:57:40 --> Model Class Initialized
INFO - 2023-10-20 03:57:40 --> Model Class Initialized
INFO - 2023-10-20 03:57:40 --> Model Class Initialized
INFO - 2023-10-20 03:57:41 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-10-20 03:57:41 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-10-20 03:57:41 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-10-20 03:57:41 --> Final output sent to browser
DEBUG - 2023-10-20 03:57:41 --> Total execution time: 0.2154
ERROR - 2023-10-20 03:57:41 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-20 03:57:41 --> Config Class Initialized
INFO - 2023-10-20 03:57:41 --> Hooks Class Initialized
DEBUG - 2023-10-20 03:57:41 --> UTF-8 Support Enabled
INFO - 2023-10-20 03:57:41 --> Utf8 Class Initialized
INFO - 2023-10-20 03:57:41 --> URI Class Initialized
INFO - 2023-10-20 03:57:41 --> Router Class Initialized
INFO - 2023-10-20 03:57:41 --> Output Class Initialized
INFO - 2023-10-20 03:57:41 --> Security Class Initialized
DEBUG - 2023-10-20 03:57:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-20 03:57:41 --> Input Class Initialized
INFO - 2023-10-20 03:57:41 --> Language Class Initialized
INFO - 2023-10-20 03:57:41 --> Loader Class Initialized
INFO - 2023-10-20 03:57:41 --> Helper loaded: url_helper
INFO - 2023-10-20 03:57:41 --> Helper loaded: file_helper
INFO - 2023-10-20 03:57:41 --> Helper loaded: html_helper
INFO - 2023-10-20 03:57:41 --> Helper loaded: text_helper
INFO - 2023-10-20 03:57:41 --> Helper loaded: form_helper
INFO - 2023-10-20 03:57:41 --> Helper loaded: lang_helper
INFO - 2023-10-20 03:57:41 --> Helper loaded: security_helper
INFO - 2023-10-20 03:57:41 --> Helper loaded: cookie_helper
INFO - 2023-10-20 03:57:41 --> Database Driver Class Initialized
INFO - 2023-10-20 03:57:41 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-20 03:57:41 --> Parser Class Initialized
INFO - 2023-10-20 03:57:41 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-20 03:57:41 --> Pagination Class Initialized
INFO - 2023-10-20 03:57:41 --> Form Validation Class Initialized
INFO - 2023-10-20 03:57:41 --> Controller Class Initialized
INFO - 2023-10-20 03:57:41 --> Model Class Initialized
DEBUG - 2023-10-20 03:57:41 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-10-20 03:57:41 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-20 03:57:41 --> Model Class Initialized
DEBUG - 2023-10-20 03:57:41 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-20 03:57:41 --> Model Class Initialized
INFO - 2023-10-20 03:57:41 --> Final output sent to browser
DEBUG - 2023-10-20 03:57:41 --> Total execution time: 0.0620
ERROR - 2023-10-20 03:57:44 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-20 03:57:44 --> Config Class Initialized
INFO - 2023-10-20 03:57:44 --> Hooks Class Initialized
DEBUG - 2023-10-20 03:57:44 --> UTF-8 Support Enabled
INFO - 2023-10-20 03:57:44 --> Utf8 Class Initialized
INFO - 2023-10-20 03:57:44 --> URI Class Initialized
INFO - 2023-10-20 03:57:44 --> Router Class Initialized
INFO - 2023-10-20 03:57:44 --> Output Class Initialized
INFO - 2023-10-20 03:57:44 --> Security Class Initialized
DEBUG - 2023-10-20 03:57:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-20 03:57:44 --> Input Class Initialized
INFO - 2023-10-20 03:57:44 --> Language Class Initialized
INFO - 2023-10-20 03:57:44 --> Loader Class Initialized
INFO - 2023-10-20 03:57:44 --> Helper loaded: url_helper
INFO - 2023-10-20 03:57:44 --> Helper loaded: file_helper
INFO - 2023-10-20 03:57:44 --> Helper loaded: html_helper
INFO - 2023-10-20 03:57:44 --> Helper loaded: text_helper
INFO - 2023-10-20 03:57:44 --> Helper loaded: form_helper
INFO - 2023-10-20 03:57:44 --> Helper loaded: lang_helper
INFO - 2023-10-20 03:57:44 --> Helper loaded: security_helper
INFO - 2023-10-20 03:57:44 --> Helper loaded: cookie_helper
INFO - 2023-10-20 03:57:44 --> Database Driver Class Initialized
INFO - 2023-10-20 03:57:44 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-20 03:57:44 --> Parser Class Initialized
INFO - 2023-10-20 03:57:44 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-20 03:57:44 --> Pagination Class Initialized
INFO - 2023-10-20 03:57:44 --> Form Validation Class Initialized
INFO - 2023-10-20 03:57:44 --> Controller Class Initialized
INFO - 2023-10-20 03:57:44 --> Model Class Initialized
DEBUG - 2023-10-20 03:57:44 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-10-20 03:57:44 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-20 03:57:44 --> Model Class Initialized
DEBUG - 2023-10-20 03:57:44 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-20 03:57:44 --> Model Class Initialized
INFO - 2023-10-20 03:57:45 --> Final output sent to browser
DEBUG - 2023-10-20 03:57:45 --> Total execution time: 1.0319
ERROR - 2023-10-20 03:58:34 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-20 03:58:34 --> Config Class Initialized
INFO - 2023-10-20 03:58:34 --> Hooks Class Initialized
DEBUG - 2023-10-20 03:58:34 --> UTF-8 Support Enabled
INFO - 2023-10-20 03:58:34 --> Utf8 Class Initialized
INFO - 2023-10-20 03:58:34 --> URI Class Initialized
INFO - 2023-10-20 03:58:34 --> Router Class Initialized
INFO - 2023-10-20 03:58:34 --> Output Class Initialized
INFO - 2023-10-20 03:58:34 --> Security Class Initialized
DEBUG - 2023-10-20 03:58:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-20 03:58:34 --> Input Class Initialized
INFO - 2023-10-20 03:58:34 --> Language Class Initialized
INFO - 2023-10-20 03:58:34 --> Loader Class Initialized
INFO - 2023-10-20 03:58:34 --> Helper loaded: url_helper
INFO - 2023-10-20 03:58:34 --> Helper loaded: file_helper
INFO - 2023-10-20 03:58:34 --> Helper loaded: html_helper
INFO - 2023-10-20 03:58:34 --> Helper loaded: text_helper
INFO - 2023-10-20 03:58:34 --> Helper loaded: form_helper
INFO - 2023-10-20 03:58:34 --> Helper loaded: lang_helper
INFO - 2023-10-20 03:58:34 --> Helper loaded: security_helper
INFO - 2023-10-20 03:58:34 --> Helper loaded: cookie_helper
INFO - 2023-10-20 03:58:34 --> Database Driver Class Initialized
INFO - 2023-10-20 03:58:34 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-20 03:58:34 --> Parser Class Initialized
INFO - 2023-10-20 03:58:34 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-20 03:58:34 --> Pagination Class Initialized
INFO - 2023-10-20 03:58:34 --> Form Validation Class Initialized
INFO - 2023-10-20 03:58:34 --> Controller Class Initialized
INFO - 2023-10-20 03:58:34 --> Model Class Initialized
DEBUG - 2023-10-20 03:58:34 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-10-20 03:58:34 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-20 03:58:34 --> Model Class Initialized
DEBUG - 2023-10-20 03:58:34 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-20 03:58:34 --> Model Class Initialized
INFO - 2023-10-20 03:58:34 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice.php
DEBUG - 2023-10-20 03:58:34 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-10-20 03:58:34 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-10-20 03:58:34 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-10-20 03:58:34 --> Model Class Initialized
INFO - 2023-10-20 03:58:34 --> Model Class Initialized
INFO - 2023-10-20 03:58:34 --> Model Class Initialized
INFO - 2023-10-20 03:58:34 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-10-20 03:58:34 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-10-20 03:58:34 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-10-20 03:58:34 --> Final output sent to browser
DEBUG - 2023-10-20 03:58:34 --> Total execution time: 0.2143
ERROR - 2023-10-20 03:58:35 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-20 03:58:35 --> Config Class Initialized
INFO - 2023-10-20 03:58:35 --> Hooks Class Initialized
DEBUG - 2023-10-20 03:58:35 --> UTF-8 Support Enabled
INFO - 2023-10-20 03:58:35 --> Utf8 Class Initialized
INFO - 2023-10-20 03:58:35 --> URI Class Initialized
INFO - 2023-10-20 03:58:35 --> Router Class Initialized
INFO - 2023-10-20 03:58:35 --> Output Class Initialized
INFO - 2023-10-20 03:58:35 --> Security Class Initialized
DEBUG - 2023-10-20 03:58:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-20 03:58:35 --> Input Class Initialized
INFO - 2023-10-20 03:58:35 --> Language Class Initialized
INFO - 2023-10-20 03:58:35 --> Loader Class Initialized
INFO - 2023-10-20 03:58:35 --> Helper loaded: url_helper
INFO - 2023-10-20 03:58:35 --> Helper loaded: file_helper
INFO - 2023-10-20 03:58:35 --> Helper loaded: html_helper
INFO - 2023-10-20 03:58:35 --> Helper loaded: text_helper
INFO - 2023-10-20 03:58:35 --> Helper loaded: form_helper
INFO - 2023-10-20 03:58:35 --> Helper loaded: lang_helper
INFO - 2023-10-20 03:58:35 --> Helper loaded: security_helper
INFO - 2023-10-20 03:58:35 --> Helper loaded: cookie_helper
INFO - 2023-10-20 03:58:35 --> Database Driver Class Initialized
INFO - 2023-10-20 03:58:35 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-20 03:58:35 --> Parser Class Initialized
INFO - 2023-10-20 03:58:35 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-20 03:58:35 --> Pagination Class Initialized
INFO - 2023-10-20 03:58:35 --> Form Validation Class Initialized
INFO - 2023-10-20 03:58:35 --> Controller Class Initialized
INFO - 2023-10-20 03:58:35 --> Model Class Initialized
DEBUG - 2023-10-20 03:58:35 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-10-20 03:58:35 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-20 03:58:35 --> Model Class Initialized
DEBUG - 2023-10-20 03:58:35 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-20 03:58:35 --> Model Class Initialized
INFO - 2023-10-20 03:58:35 --> Final output sent to browser
DEBUG - 2023-10-20 03:58:35 --> Total execution time: 0.0580
ERROR - 2023-10-20 03:58:37 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-20 03:58:37 --> Config Class Initialized
INFO - 2023-10-20 03:58:37 --> Hooks Class Initialized
DEBUG - 2023-10-20 03:58:37 --> UTF-8 Support Enabled
INFO - 2023-10-20 03:58:37 --> Utf8 Class Initialized
INFO - 2023-10-20 03:58:37 --> URI Class Initialized
INFO - 2023-10-20 03:58:37 --> Router Class Initialized
INFO - 2023-10-20 03:58:37 --> Output Class Initialized
INFO - 2023-10-20 03:58:37 --> Security Class Initialized
DEBUG - 2023-10-20 03:58:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-20 03:58:37 --> Input Class Initialized
INFO - 2023-10-20 03:58:37 --> Language Class Initialized
INFO - 2023-10-20 03:58:37 --> Loader Class Initialized
INFO - 2023-10-20 03:58:37 --> Helper loaded: url_helper
INFO - 2023-10-20 03:58:37 --> Helper loaded: file_helper
INFO - 2023-10-20 03:58:37 --> Helper loaded: html_helper
INFO - 2023-10-20 03:58:37 --> Helper loaded: text_helper
INFO - 2023-10-20 03:58:37 --> Helper loaded: form_helper
INFO - 2023-10-20 03:58:37 --> Helper loaded: lang_helper
INFO - 2023-10-20 03:58:37 --> Helper loaded: security_helper
INFO - 2023-10-20 03:58:37 --> Helper loaded: cookie_helper
INFO - 2023-10-20 03:58:37 --> Database Driver Class Initialized
INFO - 2023-10-20 03:58:37 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-20 03:58:37 --> Parser Class Initialized
INFO - 2023-10-20 03:58:37 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-20 03:58:37 --> Pagination Class Initialized
INFO - 2023-10-20 03:58:37 --> Form Validation Class Initialized
INFO - 2023-10-20 03:58:37 --> Controller Class Initialized
INFO - 2023-10-20 03:58:37 --> Model Class Initialized
DEBUG - 2023-10-20 03:58:37 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-10-20 03:58:37 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-20 03:58:37 --> Model Class Initialized
DEBUG - 2023-10-20 03:58:37 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-20 03:58:37 --> Model Class Initialized
INFO - 2023-10-20 03:58:39 --> Final output sent to browser
DEBUG - 2023-10-20 03:58:39 --> Total execution time: 1.0604
ERROR - 2023-10-20 03:58:41 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-20 03:58:41 --> Config Class Initialized
INFO - 2023-10-20 03:58:41 --> Hooks Class Initialized
DEBUG - 2023-10-20 03:58:41 --> UTF-8 Support Enabled
INFO - 2023-10-20 03:58:41 --> Utf8 Class Initialized
INFO - 2023-10-20 03:58:41 --> URI Class Initialized
INFO - 2023-10-20 03:58:41 --> Router Class Initialized
INFO - 2023-10-20 03:58:41 --> Output Class Initialized
INFO - 2023-10-20 03:58:41 --> Security Class Initialized
DEBUG - 2023-10-20 03:58:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-20 03:58:41 --> Input Class Initialized
INFO - 2023-10-20 03:58:41 --> Language Class Initialized
INFO - 2023-10-20 03:58:41 --> Loader Class Initialized
INFO - 2023-10-20 03:58:41 --> Helper loaded: url_helper
INFO - 2023-10-20 03:58:41 --> Helper loaded: file_helper
INFO - 2023-10-20 03:58:41 --> Helper loaded: html_helper
INFO - 2023-10-20 03:58:41 --> Helper loaded: text_helper
INFO - 2023-10-20 03:58:41 --> Helper loaded: form_helper
INFO - 2023-10-20 03:58:41 --> Helper loaded: lang_helper
INFO - 2023-10-20 03:58:41 --> Helper loaded: security_helper
INFO - 2023-10-20 03:58:41 --> Helper loaded: cookie_helper
INFO - 2023-10-20 03:58:41 --> Database Driver Class Initialized
INFO - 2023-10-20 03:58:41 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-20 03:58:41 --> Parser Class Initialized
INFO - 2023-10-20 03:58:41 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-20 03:58:41 --> Pagination Class Initialized
INFO - 2023-10-20 03:58:41 --> Form Validation Class Initialized
INFO - 2023-10-20 03:58:41 --> Controller Class Initialized
INFO - 2023-10-20 03:58:41 --> Model Class Initialized
DEBUG - 2023-10-20 03:58:41 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-10-20 03:58:41 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-20 03:58:41 --> Model Class Initialized
DEBUG - 2023-10-20 03:58:41 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-20 03:58:41 --> Model Class Initialized
INFO - 2023-10-20 03:58:41 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice.php
DEBUG - 2023-10-20 03:58:41 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-10-20 03:58:41 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-10-20 03:58:41 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-10-20 03:58:41 --> Model Class Initialized
INFO - 2023-10-20 03:58:41 --> Model Class Initialized
INFO - 2023-10-20 03:58:41 --> Model Class Initialized
INFO - 2023-10-20 03:58:41 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-10-20 03:58:41 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-10-20 03:58:41 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-10-20 03:58:41 --> Final output sent to browser
DEBUG - 2023-10-20 03:58:41 --> Total execution time: 0.2168
ERROR - 2023-10-20 03:58:42 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-20 03:58:42 --> Config Class Initialized
INFO - 2023-10-20 03:58:42 --> Hooks Class Initialized
DEBUG - 2023-10-20 03:58:42 --> UTF-8 Support Enabled
INFO - 2023-10-20 03:58:42 --> Utf8 Class Initialized
INFO - 2023-10-20 03:58:42 --> URI Class Initialized
INFO - 2023-10-20 03:58:42 --> Router Class Initialized
INFO - 2023-10-20 03:58:42 --> Output Class Initialized
INFO - 2023-10-20 03:58:42 --> Security Class Initialized
DEBUG - 2023-10-20 03:58:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-20 03:58:42 --> Input Class Initialized
INFO - 2023-10-20 03:58:42 --> Language Class Initialized
INFO - 2023-10-20 03:58:42 --> Loader Class Initialized
INFO - 2023-10-20 03:58:42 --> Helper loaded: url_helper
INFO - 2023-10-20 03:58:42 --> Helper loaded: file_helper
INFO - 2023-10-20 03:58:42 --> Helper loaded: html_helper
INFO - 2023-10-20 03:58:42 --> Helper loaded: text_helper
INFO - 2023-10-20 03:58:42 --> Helper loaded: form_helper
INFO - 2023-10-20 03:58:42 --> Helper loaded: lang_helper
INFO - 2023-10-20 03:58:42 --> Helper loaded: security_helper
INFO - 2023-10-20 03:58:42 --> Helper loaded: cookie_helper
INFO - 2023-10-20 03:58:42 --> Database Driver Class Initialized
INFO - 2023-10-20 03:58:42 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-20 03:58:42 --> Parser Class Initialized
INFO - 2023-10-20 03:58:42 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-20 03:58:42 --> Pagination Class Initialized
INFO - 2023-10-20 03:58:42 --> Form Validation Class Initialized
INFO - 2023-10-20 03:58:42 --> Controller Class Initialized
INFO - 2023-10-20 03:58:42 --> Model Class Initialized
DEBUG - 2023-10-20 03:58:42 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-10-20 03:58:42 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-20 03:58:42 --> Model Class Initialized
DEBUG - 2023-10-20 03:58:42 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-20 03:58:42 --> Model Class Initialized
INFO - 2023-10-20 03:58:42 --> Final output sent to browser
DEBUG - 2023-10-20 03:58:42 --> Total execution time: 0.0593
ERROR - 2023-10-20 03:58:45 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-20 03:58:45 --> Config Class Initialized
INFO - 2023-10-20 03:58:45 --> Hooks Class Initialized
DEBUG - 2023-10-20 03:58:45 --> UTF-8 Support Enabled
INFO - 2023-10-20 03:58:45 --> Utf8 Class Initialized
INFO - 2023-10-20 03:58:45 --> URI Class Initialized
INFO - 2023-10-20 03:58:45 --> Router Class Initialized
INFO - 2023-10-20 03:58:45 --> Output Class Initialized
INFO - 2023-10-20 03:58:45 --> Security Class Initialized
DEBUG - 2023-10-20 03:58:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-20 03:58:45 --> Input Class Initialized
INFO - 2023-10-20 03:58:45 --> Language Class Initialized
INFO - 2023-10-20 03:58:45 --> Loader Class Initialized
INFO - 2023-10-20 03:58:45 --> Helper loaded: url_helper
INFO - 2023-10-20 03:58:45 --> Helper loaded: file_helper
INFO - 2023-10-20 03:58:45 --> Helper loaded: html_helper
INFO - 2023-10-20 03:58:45 --> Helper loaded: text_helper
INFO - 2023-10-20 03:58:45 --> Helper loaded: form_helper
INFO - 2023-10-20 03:58:45 --> Helper loaded: lang_helper
INFO - 2023-10-20 03:58:45 --> Helper loaded: security_helper
INFO - 2023-10-20 03:58:45 --> Helper loaded: cookie_helper
INFO - 2023-10-20 03:58:45 --> Database Driver Class Initialized
INFO - 2023-10-20 03:58:45 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-20 03:58:45 --> Parser Class Initialized
INFO - 2023-10-20 03:58:45 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-20 03:58:45 --> Pagination Class Initialized
INFO - 2023-10-20 03:58:45 --> Form Validation Class Initialized
INFO - 2023-10-20 03:58:45 --> Controller Class Initialized
INFO - 2023-10-20 03:58:45 --> Model Class Initialized
DEBUG - 2023-10-20 03:58:45 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-10-20 03:58:45 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-20 03:58:45 --> Model Class Initialized
DEBUG - 2023-10-20 03:58:45 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-20 03:58:45 --> Model Class Initialized
INFO - 2023-10-20 03:58:46 --> Final output sent to browser
DEBUG - 2023-10-20 03:58:46 --> Total execution time: 1.0168
ERROR - 2023-10-20 03:59:01 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-20 03:59:01 --> Config Class Initialized
INFO - 2023-10-20 03:59:01 --> Hooks Class Initialized
DEBUG - 2023-10-20 03:59:01 --> UTF-8 Support Enabled
INFO - 2023-10-20 03:59:01 --> Utf8 Class Initialized
INFO - 2023-10-20 03:59:01 --> URI Class Initialized
DEBUG - 2023-10-20 03:59:01 --> No URI present. Default controller set.
INFO - 2023-10-20 03:59:01 --> Router Class Initialized
INFO - 2023-10-20 03:59:01 --> Output Class Initialized
INFO - 2023-10-20 03:59:01 --> Security Class Initialized
DEBUG - 2023-10-20 03:59:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-20 03:59:01 --> Input Class Initialized
INFO - 2023-10-20 03:59:01 --> Language Class Initialized
INFO - 2023-10-20 03:59:01 --> Loader Class Initialized
INFO - 2023-10-20 03:59:01 --> Helper loaded: url_helper
INFO - 2023-10-20 03:59:01 --> Helper loaded: file_helper
INFO - 2023-10-20 03:59:01 --> Helper loaded: html_helper
INFO - 2023-10-20 03:59:01 --> Helper loaded: text_helper
INFO - 2023-10-20 03:59:01 --> Helper loaded: form_helper
INFO - 2023-10-20 03:59:01 --> Helper loaded: lang_helper
INFO - 2023-10-20 03:59:01 --> Helper loaded: security_helper
INFO - 2023-10-20 03:59:01 --> Helper loaded: cookie_helper
INFO - 2023-10-20 03:59:01 --> Database Driver Class Initialized
INFO - 2023-10-20 03:59:01 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-20 03:59:01 --> Parser Class Initialized
INFO - 2023-10-20 03:59:01 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-20 03:59:01 --> Pagination Class Initialized
INFO - 2023-10-20 03:59:01 --> Form Validation Class Initialized
INFO - 2023-10-20 03:59:01 --> Controller Class Initialized
INFO - 2023-10-20 03:59:01 --> Model Class Initialized
DEBUG - 2023-10-20 03:59:01 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-20 03:59:01 --> Model Class Initialized
DEBUG - 2023-10-20 03:59:01 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-20 03:59:01 --> Model Class Initialized
INFO - 2023-10-20 03:59:01 --> Model Class Initialized
INFO - 2023-10-20 03:59:01 --> Model Class Initialized
INFO - 2023-10-20 03:59:01 --> Model Class Initialized
DEBUG - 2023-10-20 03:59:01 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-10-20 03:59:01 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-20 03:59:01 --> Model Class Initialized
INFO - 2023-10-20 03:59:01 --> Model Class Initialized
INFO - 2023-10-20 03:59:01 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-10-20 03:59:01 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-10-20 03:59:01 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-10-20 03:59:01 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-10-20 03:59:01 --> Model Class Initialized
INFO - 2023-10-20 03:59:01 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-10-20 03:59:01 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-10-20 03:59:01 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-10-20 03:59:01 --> Final output sent to browser
DEBUG - 2023-10-20 03:59:01 --> Total execution time: 0.3958
ERROR - 2023-10-20 03:59:07 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-20 03:59:07 --> Config Class Initialized
INFO - 2023-10-20 03:59:07 --> Hooks Class Initialized
DEBUG - 2023-10-20 03:59:07 --> UTF-8 Support Enabled
INFO - 2023-10-20 03:59:07 --> Utf8 Class Initialized
INFO - 2023-10-20 03:59:07 --> URI Class Initialized
INFO - 2023-10-20 03:59:07 --> Router Class Initialized
INFO - 2023-10-20 03:59:07 --> Output Class Initialized
INFO - 2023-10-20 03:59:07 --> Security Class Initialized
DEBUG - 2023-10-20 03:59:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-20 03:59:07 --> Input Class Initialized
INFO - 2023-10-20 03:59:07 --> Language Class Initialized
INFO - 2023-10-20 03:59:07 --> Loader Class Initialized
INFO - 2023-10-20 03:59:07 --> Helper loaded: url_helper
INFO - 2023-10-20 03:59:07 --> Helper loaded: file_helper
INFO - 2023-10-20 03:59:07 --> Helper loaded: html_helper
INFO - 2023-10-20 03:59:07 --> Helper loaded: text_helper
INFO - 2023-10-20 03:59:07 --> Helper loaded: form_helper
INFO - 2023-10-20 03:59:07 --> Helper loaded: lang_helper
INFO - 2023-10-20 03:59:07 --> Helper loaded: security_helper
INFO - 2023-10-20 03:59:07 --> Helper loaded: cookie_helper
INFO - 2023-10-20 03:59:07 --> Database Driver Class Initialized
INFO - 2023-10-20 03:59:07 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-20 03:59:07 --> Parser Class Initialized
INFO - 2023-10-20 03:59:07 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-20 03:59:07 --> Pagination Class Initialized
INFO - 2023-10-20 03:59:07 --> Form Validation Class Initialized
INFO - 2023-10-20 03:59:07 --> Controller Class Initialized
INFO - 2023-10-20 03:59:07 --> Model Class Initialized
DEBUG - 2023-10-20 03:59:07 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-10-20 03:59:07 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-20 03:59:07 --> Model Class Initialized
DEBUG - 2023-10-20 03:59:07 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-20 03:59:07 --> Model Class Initialized
INFO - 2023-10-20 03:59:07 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice.php
DEBUG - 2023-10-20 03:59:07 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-10-20 03:59:07 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-10-20 03:59:07 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-10-20 03:59:07 --> Model Class Initialized
INFO - 2023-10-20 03:59:07 --> Model Class Initialized
INFO - 2023-10-20 03:59:07 --> Model Class Initialized
INFO - 2023-10-20 03:59:07 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-10-20 03:59:07 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-10-20 03:59:07 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-10-20 03:59:07 --> Final output sent to browser
DEBUG - 2023-10-20 03:59:07 --> Total execution time: 0.2162
ERROR - 2023-10-20 03:59:08 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-20 03:59:08 --> Config Class Initialized
INFO - 2023-10-20 03:59:08 --> Hooks Class Initialized
DEBUG - 2023-10-20 03:59:08 --> UTF-8 Support Enabled
INFO - 2023-10-20 03:59:08 --> Utf8 Class Initialized
INFO - 2023-10-20 03:59:08 --> URI Class Initialized
INFO - 2023-10-20 03:59:08 --> Router Class Initialized
INFO - 2023-10-20 03:59:08 --> Output Class Initialized
INFO - 2023-10-20 03:59:08 --> Security Class Initialized
DEBUG - 2023-10-20 03:59:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-20 03:59:08 --> Input Class Initialized
INFO - 2023-10-20 03:59:08 --> Language Class Initialized
INFO - 2023-10-20 03:59:08 --> Loader Class Initialized
INFO - 2023-10-20 03:59:08 --> Helper loaded: url_helper
INFO - 2023-10-20 03:59:08 --> Helper loaded: file_helper
INFO - 2023-10-20 03:59:08 --> Helper loaded: html_helper
INFO - 2023-10-20 03:59:08 --> Helper loaded: text_helper
INFO - 2023-10-20 03:59:08 --> Helper loaded: form_helper
INFO - 2023-10-20 03:59:08 --> Helper loaded: lang_helper
INFO - 2023-10-20 03:59:08 --> Helper loaded: security_helper
INFO - 2023-10-20 03:59:08 --> Helper loaded: cookie_helper
INFO - 2023-10-20 03:59:08 --> Database Driver Class Initialized
INFO - 2023-10-20 03:59:08 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-20 03:59:08 --> Parser Class Initialized
INFO - 2023-10-20 03:59:08 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-20 03:59:08 --> Pagination Class Initialized
INFO - 2023-10-20 03:59:08 --> Form Validation Class Initialized
INFO - 2023-10-20 03:59:08 --> Controller Class Initialized
INFO - 2023-10-20 03:59:08 --> Model Class Initialized
DEBUG - 2023-10-20 03:59:08 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-10-20 03:59:08 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-20 03:59:08 --> Model Class Initialized
DEBUG - 2023-10-20 03:59:08 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-20 03:59:08 --> Model Class Initialized
INFO - 2023-10-20 03:59:08 --> Final output sent to browser
DEBUG - 2023-10-20 03:59:08 --> Total execution time: 0.0651
ERROR - 2023-10-20 03:59:21 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-20 03:59:21 --> Config Class Initialized
INFO - 2023-10-20 03:59:21 --> Hooks Class Initialized
DEBUG - 2023-10-20 03:59:21 --> UTF-8 Support Enabled
INFO - 2023-10-20 03:59:21 --> Utf8 Class Initialized
INFO - 2023-10-20 03:59:21 --> URI Class Initialized
INFO - 2023-10-20 03:59:21 --> Router Class Initialized
INFO - 2023-10-20 03:59:21 --> Output Class Initialized
INFO - 2023-10-20 03:59:21 --> Security Class Initialized
DEBUG - 2023-10-20 03:59:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-20 03:59:21 --> Input Class Initialized
INFO - 2023-10-20 03:59:21 --> Language Class Initialized
INFO - 2023-10-20 03:59:21 --> Loader Class Initialized
INFO - 2023-10-20 03:59:21 --> Helper loaded: url_helper
INFO - 2023-10-20 03:59:21 --> Helper loaded: file_helper
INFO - 2023-10-20 03:59:21 --> Helper loaded: html_helper
INFO - 2023-10-20 03:59:21 --> Helper loaded: text_helper
INFO - 2023-10-20 03:59:21 --> Helper loaded: form_helper
INFO - 2023-10-20 03:59:21 --> Helper loaded: lang_helper
INFO - 2023-10-20 03:59:21 --> Helper loaded: security_helper
INFO - 2023-10-20 03:59:21 --> Helper loaded: cookie_helper
INFO - 2023-10-20 03:59:21 --> Database Driver Class Initialized
INFO - 2023-10-20 03:59:21 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-20 03:59:21 --> Parser Class Initialized
INFO - 2023-10-20 03:59:21 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-20 03:59:21 --> Pagination Class Initialized
INFO - 2023-10-20 03:59:21 --> Form Validation Class Initialized
INFO - 2023-10-20 03:59:21 --> Controller Class Initialized
INFO - 2023-10-20 03:59:21 --> Model Class Initialized
DEBUG - 2023-10-20 03:59:21 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-10-20 03:59:21 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-20 03:59:21 --> Model Class Initialized
DEBUG - 2023-10-20 03:59:21 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-20 03:59:21 --> Model Class Initialized
INFO - 2023-10-20 03:59:22 --> Final output sent to browser
DEBUG - 2023-10-20 03:59:22 --> Total execution time: 1.1363
ERROR - 2023-10-20 03:59:42 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-20 03:59:42 --> Config Class Initialized
INFO - 2023-10-20 03:59:42 --> Hooks Class Initialized
DEBUG - 2023-10-20 03:59:42 --> UTF-8 Support Enabled
INFO - 2023-10-20 03:59:42 --> Utf8 Class Initialized
INFO - 2023-10-20 03:59:42 --> URI Class Initialized
INFO - 2023-10-20 03:59:42 --> Router Class Initialized
INFO - 2023-10-20 03:59:42 --> Output Class Initialized
INFO - 2023-10-20 03:59:42 --> Security Class Initialized
DEBUG - 2023-10-20 03:59:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-20 03:59:42 --> Input Class Initialized
INFO - 2023-10-20 03:59:42 --> Language Class Initialized
INFO - 2023-10-20 03:59:42 --> Loader Class Initialized
INFO - 2023-10-20 03:59:42 --> Helper loaded: url_helper
INFO - 2023-10-20 03:59:42 --> Helper loaded: file_helper
INFO - 2023-10-20 03:59:42 --> Helper loaded: html_helper
INFO - 2023-10-20 03:59:42 --> Helper loaded: text_helper
INFO - 2023-10-20 03:59:42 --> Helper loaded: form_helper
INFO - 2023-10-20 03:59:42 --> Helper loaded: lang_helper
INFO - 2023-10-20 03:59:42 --> Helper loaded: security_helper
INFO - 2023-10-20 03:59:42 --> Helper loaded: cookie_helper
INFO - 2023-10-20 03:59:42 --> Database Driver Class Initialized
INFO - 2023-10-20 03:59:42 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-20 03:59:42 --> Parser Class Initialized
INFO - 2023-10-20 03:59:42 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-20 03:59:42 --> Pagination Class Initialized
INFO - 2023-10-20 03:59:42 --> Form Validation Class Initialized
INFO - 2023-10-20 03:59:42 --> Controller Class Initialized
INFO - 2023-10-20 03:59:42 --> Model Class Initialized
DEBUG - 2023-10-20 03:59:42 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-10-20 03:59:42 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-20 03:59:42 --> Model Class Initialized
DEBUG - 2023-10-20 03:59:42 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-20 03:59:42 --> Model Class Initialized
DEBUG - 2023-10-20 03:59:42 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-20 03:59:42 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice_html.php
DEBUG - 2023-10-20 03:59:42 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-10-20 03:59:42 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-10-20 03:59:42 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-10-20 03:59:42 --> Model Class Initialized
INFO - 2023-10-20 03:59:42 --> Model Class Initialized
INFO - 2023-10-20 03:59:42 --> Model Class Initialized
INFO - 2023-10-20 03:59:42 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-10-20 03:59:42 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-10-20 03:59:42 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-10-20 03:59:42 --> Final output sent to browser
DEBUG - 2023-10-20 03:59:42 --> Total execution time: 0.2154
ERROR - 2023-10-20 04:21:49 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-20 04:21:49 --> Config Class Initialized
INFO - 2023-10-20 04:21:49 --> Hooks Class Initialized
DEBUG - 2023-10-20 04:21:49 --> UTF-8 Support Enabled
INFO - 2023-10-20 04:21:49 --> Utf8 Class Initialized
INFO - 2023-10-20 04:21:49 --> URI Class Initialized
DEBUG - 2023-10-20 04:21:49 --> No URI present. Default controller set.
INFO - 2023-10-20 04:21:49 --> Router Class Initialized
INFO - 2023-10-20 04:21:49 --> Output Class Initialized
INFO - 2023-10-20 04:21:49 --> Security Class Initialized
DEBUG - 2023-10-20 04:21:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-20 04:21:49 --> Input Class Initialized
INFO - 2023-10-20 04:21:49 --> Language Class Initialized
INFO - 2023-10-20 04:21:49 --> Loader Class Initialized
INFO - 2023-10-20 04:21:49 --> Helper loaded: url_helper
INFO - 2023-10-20 04:21:49 --> Helper loaded: file_helper
INFO - 2023-10-20 04:21:49 --> Helper loaded: html_helper
INFO - 2023-10-20 04:21:49 --> Helper loaded: text_helper
INFO - 2023-10-20 04:21:49 --> Helper loaded: form_helper
INFO - 2023-10-20 04:21:49 --> Helper loaded: lang_helper
INFO - 2023-10-20 04:21:49 --> Helper loaded: security_helper
INFO - 2023-10-20 04:21:49 --> Helper loaded: cookie_helper
INFO - 2023-10-20 04:21:49 --> Database Driver Class Initialized
INFO - 2023-10-20 04:21:49 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-20 04:21:49 --> Parser Class Initialized
INFO - 2023-10-20 04:21:49 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-20 04:21:49 --> Pagination Class Initialized
INFO - 2023-10-20 04:21:49 --> Form Validation Class Initialized
INFO - 2023-10-20 04:21:49 --> Controller Class Initialized
INFO - 2023-10-20 04:21:49 --> Model Class Initialized
DEBUG - 2023-10-20 04:21:49 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-20 04:21:49 --> Model Class Initialized
DEBUG - 2023-10-20 04:21:49 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-20 04:21:49 --> Model Class Initialized
INFO - 2023-10-20 04:21:49 --> Model Class Initialized
INFO - 2023-10-20 04:21:49 --> Model Class Initialized
INFO - 2023-10-20 04:21:49 --> Model Class Initialized
DEBUG - 2023-10-20 04:21:49 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-10-20 04:21:49 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-20 04:21:49 --> Model Class Initialized
INFO - 2023-10-20 04:21:49 --> Model Class Initialized
INFO - 2023-10-20 04:21:50 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-10-20 04:21:50 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-10-20 04:21:50 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-10-20 04:21:50 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-10-20 04:21:50 --> Model Class Initialized
INFO - 2023-10-20 04:21:50 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-10-20 04:21:50 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-10-20 04:21:50 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-10-20 04:21:50 --> Final output sent to browser
DEBUG - 2023-10-20 04:21:50 --> Total execution time: 0.3691
ERROR - 2023-10-20 04:31:30 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-20 04:31:30 --> Config Class Initialized
INFO - 2023-10-20 04:31:30 --> Hooks Class Initialized
DEBUG - 2023-10-20 04:31:30 --> UTF-8 Support Enabled
INFO - 2023-10-20 04:31:30 --> Utf8 Class Initialized
INFO - 2023-10-20 04:31:30 --> URI Class Initialized
INFO - 2023-10-20 04:31:30 --> Router Class Initialized
INFO - 2023-10-20 04:31:30 --> Output Class Initialized
INFO - 2023-10-20 04:31:30 --> Security Class Initialized
DEBUG - 2023-10-20 04:31:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-20 04:31:30 --> Input Class Initialized
INFO - 2023-10-20 04:31:30 --> Language Class Initialized
ERROR - 2023-10-20 04:31:30 --> 404 Page Not Found: Well-known/assetlinks.json
ERROR - 2023-10-20 04:35:05 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-20 04:35:05 --> Config Class Initialized
INFO - 2023-10-20 04:35:05 --> Hooks Class Initialized
DEBUG - 2023-10-20 04:35:05 --> UTF-8 Support Enabled
INFO - 2023-10-20 04:35:05 --> Utf8 Class Initialized
INFO - 2023-10-20 04:35:05 --> URI Class Initialized
INFO - 2023-10-20 04:35:05 --> Router Class Initialized
INFO - 2023-10-20 04:35:05 --> Output Class Initialized
INFO - 2023-10-20 04:35:05 --> Security Class Initialized
DEBUG - 2023-10-20 04:35:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-20 04:35:05 --> Input Class Initialized
INFO - 2023-10-20 04:35:05 --> Language Class Initialized
INFO - 2023-10-20 04:35:05 --> Loader Class Initialized
INFO - 2023-10-20 04:35:05 --> Helper loaded: url_helper
INFO - 2023-10-20 04:35:05 --> Helper loaded: file_helper
INFO - 2023-10-20 04:35:05 --> Helper loaded: html_helper
INFO - 2023-10-20 04:35:05 --> Helper loaded: text_helper
INFO - 2023-10-20 04:35:05 --> Helper loaded: form_helper
INFO - 2023-10-20 04:35:05 --> Helper loaded: lang_helper
INFO - 2023-10-20 04:35:05 --> Helper loaded: security_helper
INFO - 2023-10-20 04:35:05 --> Helper loaded: cookie_helper
INFO - 2023-10-20 04:35:05 --> Database Driver Class Initialized
INFO - 2023-10-20 04:35:05 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-20 04:35:05 --> Parser Class Initialized
INFO - 2023-10-20 04:35:05 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-20 04:35:05 --> Pagination Class Initialized
INFO - 2023-10-20 04:35:05 --> Form Validation Class Initialized
INFO - 2023-10-20 04:35:05 --> Controller Class Initialized
INFO - 2023-10-20 04:35:05 --> Model Class Initialized
DEBUG - 2023-10-20 04:35:05 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-10-20 04:35:05 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-20 04:35:05 --> Model Class Initialized
DEBUG - 2023-10-20 04:35:05 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-20 04:35:05 --> Model Class Initialized
INFO - 2023-10-20 04:35:05 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice.php
DEBUG - 2023-10-20 04:35:05 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-10-20 04:35:05 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-10-20 04:35:05 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-10-20 04:35:05 --> Model Class Initialized
INFO - 2023-10-20 04:35:05 --> Model Class Initialized
INFO - 2023-10-20 04:35:05 --> Model Class Initialized
INFO - 2023-10-20 04:35:05 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-10-20 04:35:05 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-10-20 04:35:05 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-10-20 04:35:05 --> Final output sent to browser
DEBUG - 2023-10-20 04:35:05 --> Total execution time: 0.2075
ERROR - 2023-10-20 04:35:05 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-20 04:35:05 --> Config Class Initialized
INFO - 2023-10-20 04:35:05 --> Hooks Class Initialized
DEBUG - 2023-10-20 04:35:05 --> UTF-8 Support Enabled
INFO - 2023-10-20 04:35:05 --> Utf8 Class Initialized
INFO - 2023-10-20 04:35:05 --> URI Class Initialized
INFO - 2023-10-20 04:35:05 --> Router Class Initialized
INFO - 2023-10-20 04:35:05 --> Output Class Initialized
INFO - 2023-10-20 04:35:05 --> Security Class Initialized
DEBUG - 2023-10-20 04:35:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-20 04:35:05 --> Input Class Initialized
INFO - 2023-10-20 04:35:05 --> Language Class Initialized
INFO - 2023-10-20 04:35:05 --> Loader Class Initialized
INFO - 2023-10-20 04:35:05 --> Helper loaded: url_helper
INFO - 2023-10-20 04:35:05 --> Helper loaded: file_helper
INFO - 2023-10-20 04:35:05 --> Helper loaded: html_helper
INFO - 2023-10-20 04:35:05 --> Helper loaded: text_helper
INFO - 2023-10-20 04:35:05 --> Helper loaded: form_helper
INFO - 2023-10-20 04:35:05 --> Helper loaded: lang_helper
INFO - 2023-10-20 04:35:05 --> Helper loaded: security_helper
INFO - 2023-10-20 04:35:05 --> Helper loaded: cookie_helper
INFO - 2023-10-20 04:35:05 --> Database Driver Class Initialized
INFO - 2023-10-20 04:35:05 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-20 04:35:05 --> Parser Class Initialized
INFO - 2023-10-20 04:35:05 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-20 04:35:05 --> Pagination Class Initialized
INFO - 2023-10-20 04:35:05 --> Form Validation Class Initialized
INFO - 2023-10-20 04:35:05 --> Controller Class Initialized
INFO - 2023-10-20 04:35:05 --> Model Class Initialized
DEBUG - 2023-10-20 04:35:05 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-10-20 04:35:05 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-20 04:35:05 --> Model Class Initialized
DEBUG - 2023-10-20 04:35:05 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-20 04:35:05 --> Model Class Initialized
INFO - 2023-10-20 04:35:06 --> Final output sent to browser
DEBUG - 2023-10-20 04:35:06 --> Total execution time: 0.0711
ERROR - 2023-10-20 04:35:09 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-20 04:35:09 --> Config Class Initialized
INFO - 2023-10-20 04:35:09 --> Hooks Class Initialized
DEBUG - 2023-10-20 04:35:09 --> UTF-8 Support Enabled
INFO - 2023-10-20 04:35:09 --> Utf8 Class Initialized
INFO - 2023-10-20 04:35:09 --> URI Class Initialized
INFO - 2023-10-20 04:35:09 --> Router Class Initialized
INFO - 2023-10-20 04:35:09 --> Output Class Initialized
INFO - 2023-10-20 04:35:09 --> Security Class Initialized
DEBUG - 2023-10-20 04:35:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-20 04:35:09 --> Input Class Initialized
INFO - 2023-10-20 04:35:09 --> Language Class Initialized
INFO - 2023-10-20 04:35:10 --> Loader Class Initialized
INFO - 2023-10-20 04:35:10 --> Helper loaded: url_helper
INFO - 2023-10-20 04:35:10 --> Helper loaded: file_helper
INFO - 2023-10-20 04:35:10 --> Helper loaded: html_helper
INFO - 2023-10-20 04:35:10 --> Helper loaded: text_helper
INFO - 2023-10-20 04:35:10 --> Helper loaded: form_helper
INFO - 2023-10-20 04:35:10 --> Helper loaded: lang_helper
INFO - 2023-10-20 04:35:10 --> Helper loaded: security_helper
INFO - 2023-10-20 04:35:10 --> Helper loaded: cookie_helper
INFO - 2023-10-20 04:35:10 --> Database Driver Class Initialized
INFO - 2023-10-20 04:35:10 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-20 04:35:10 --> Parser Class Initialized
INFO - 2023-10-20 04:35:10 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-20 04:35:10 --> Pagination Class Initialized
INFO - 2023-10-20 04:35:10 --> Form Validation Class Initialized
INFO - 2023-10-20 04:35:10 --> Controller Class Initialized
INFO - 2023-10-20 04:35:10 --> Model Class Initialized
DEBUG - 2023-10-20 04:35:10 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-10-20 04:35:10 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-20 04:35:10 --> Model Class Initialized
DEBUG - 2023-10-20 04:35:10 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-20 04:35:10 --> Model Class Initialized
INFO - 2023-10-20 04:35:11 --> Final output sent to browser
DEBUG - 2023-10-20 04:35:11 --> Total execution time: 1.0229
ERROR - 2023-10-20 04:35:31 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-20 04:35:31 --> Config Class Initialized
INFO - 2023-10-20 04:35:31 --> Hooks Class Initialized
DEBUG - 2023-10-20 04:35:31 --> UTF-8 Support Enabled
INFO - 2023-10-20 04:35:31 --> Utf8 Class Initialized
INFO - 2023-10-20 04:35:31 --> URI Class Initialized
DEBUG - 2023-10-20 04:35:31 --> No URI present. Default controller set.
INFO - 2023-10-20 04:35:31 --> Router Class Initialized
INFO - 2023-10-20 04:35:31 --> Output Class Initialized
INFO - 2023-10-20 04:35:31 --> Security Class Initialized
DEBUG - 2023-10-20 04:35:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-20 04:35:31 --> Input Class Initialized
INFO - 2023-10-20 04:35:31 --> Language Class Initialized
INFO - 2023-10-20 04:35:31 --> Loader Class Initialized
INFO - 2023-10-20 04:35:31 --> Helper loaded: url_helper
INFO - 2023-10-20 04:35:31 --> Helper loaded: file_helper
INFO - 2023-10-20 04:35:31 --> Helper loaded: html_helper
INFO - 2023-10-20 04:35:31 --> Helper loaded: text_helper
INFO - 2023-10-20 04:35:31 --> Helper loaded: form_helper
INFO - 2023-10-20 04:35:31 --> Helper loaded: lang_helper
INFO - 2023-10-20 04:35:31 --> Helper loaded: security_helper
INFO - 2023-10-20 04:35:31 --> Helper loaded: cookie_helper
INFO - 2023-10-20 04:35:31 --> Database Driver Class Initialized
INFO - 2023-10-20 04:35:31 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-20 04:35:31 --> Parser Class Initialized
INFO - 2023-10-20 04:35:31 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-20 04:35:31 --> Pagination Class Initialized
INFO - 2023-10-20 04:35:31 --> Form Validation Class Initialized
INFO - 2023-10-20 04:35:31 --> Controller Class Initialized
INFO - 2023-10-20 04:35:31 --> Model Class Initialized
DEBUG - 2023-10-20 04:35:31 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-20 04:35:31 --> Model Class Initialized
DEBUG - 2023-10-20 04:35:31 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-20 04:35:31 --> Model Class Initialized
INFO - 2023-10-20 04:35:31 --> Model Class Initialized
INFO - 2023-10-20 04:35:31 --> Model Class Initialized
INFO - 2023-10-20 04:35:31 --> Model Class Initialized
DEBUG - 2023-10-20 04:35:31 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-10-20 04:35:31 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-20 04:35:31 --> Model Class Initialized
INFO - 2023-10-20 04:35:31 --> Model Class Initialized
INFO - 2023-10-20 04:35:31 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-10-20 04:35:31 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-10-20 04:35:31 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-10-20 04:35:31 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-10-20 04:35:31 --> Model Class Initialized
INFO - 2023-10-20 04:35:31 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-10-20 04:35:31 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-10-20 04:35:31 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-10-20 04:35:31 --> Final output sent to browser
DEBUG - 2023-10-20 04:35:31 --> Total execution time: 0.3841
ERROR - 2023-10-20 05:47:01 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-20 05:47:01 --> Config Class Initialized
INFO - 2023-10-20 05:47:01 --> Hooks Class Initialized
DEBUG - 2023-10-20 05:47:01 --> UTF-8 Support Enabled
INFO - 2023-10-20 05:47:01 --> Utf8 Class Initialized
INFO - 2023-10-20 05:47:01 --> URI Class Initialized
DEBUG - 2023-10-20 05:47:01 --> No URI present. Default controller set.
INFO - 2023-10-20 05:47:01 --> Router Class Initialized
INFO - 2023-10-20 05:47:01 --> Output Class Initialized
INFO - 2023-10-20 05:47:01 --> Security Class Initialized
DEBUG - 2023-10-20 05:47:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-20 05:47:01 --> Input Class Initialized
INFO - 2023-10-20 05:47:01 --> Language Class Initialized
INFO - 2023-10-20 05:47:01 --> Loader Class Initialized
INFO - 2023-10-20 05:47:01 --> Helper loaded: url_helper
INFO - 2023-10-20 05:47:01 --> Helper loaded: file_helper
INFO - 2023-10-20 05:47:01 --> Helper loaded: html_helper
INFO - 2023-10-20 05:47:01 --> Helper loaded: text_helper
INFO - 2023-10-20 05:47:01 --> Helper loaded: form_helper
INFO - 2023-10-20 05:47:01 --> Helper loaded: lang_helper
INFO - 2023-10-20 05:47:01 --> Helper loaded: security_helper
INFO - 2023-10-20 05:47:01 --> Helper loaded: cookie_helper
INFO - 2023-10-20 05:47:01 --> Database Driver Class Initialized
INFO - 2023-10-20 05:47:01 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-20 05:47:01 --> Parser Class Initialized
INFO - 2023-10-20 05:47:01 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-20 05:47:01 --> Pagination Class Initialized
INFO - 2023-10-20 05:47:01 --> Form Validation Class Initialized
INFO - 2023-10-20 05:47:01 --> Controller Class Initialized
INFO - 2023-10-20 05:47:01 --> Model Class Initialized
DEBUG - 2023-10-20 05:47:01 --> Session class already loaded. Second attempt ignored.
ERROR - 2023-10-20 05:47:01 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-20 05:47:01 --> Config Class Initialized
INFO - 2023-10-20 05:47:01 --> Hooks Class Initialized
DEBUG - 2023-10-20 05:47:01 --> UTF-8 Support Enabled
INFO - 2023-10-20 05:47:01 --> Utf8 Class Initialized
INFO - 2023-10-20 05:47:01 --> URI Class Initialized
INFO - 2023-10-20 05:47:01 --> Router Class Initialized
INFO - 2023-10-20 05:47:01 --> Output Class Initialized
INFO - 2023-10-20 05:47:01 --> Security Class Initialized
DEBUG - 2023-10-20 05:47:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-20 05:47:01 --> Input Class Initialized
INFO - 2023-10-20 05:47:01 --> Language Class Initialized
INFO - 2023-10-20 05:47:01 --> Loader Class Initialized
INFO - 2023-10-20 05:47:01 --> Helper loaded: url_helper
INFO - 2023-10-20 05:47:01 --> Helper loaded: file_helper
INFO - 2023-10-20 05:47:01 --> Helper loaded: html_helper
INFO - 2023-10-20 05:47:01 --> Helper loaded: text_helper
INFO - 2023-10-20 05:47:01 --> Helper loaded: form_helper
INFO - 2023-10-20 05:47:01 --> Helper loaded: lang_helper
INFO - 2023-10-20 05:47:01 --> Helper loaded: security_helper
INFO - 2023-10-20 05:47:01 --> Helper loaded: cookie_helper
INFO - 2023-10-20 05:47:01 --> Database Driver Class Initialized
INFO - 2023-10-20 05:47:01 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-20 05:47:01 --> Parser Class Initialized
INFO - 2023-10-20 05:47:01 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-20 05:47:01 --> Pagination Class Initialized
INFO - 2023-10-20 05:47:01 --> Form Validation Class Initialized
INFO - 2023-10-20 05:47:01 --> Controller Class Initialized
INFO - 2023-10-20 05:47:01 --> Model Class Initialized
DEBUG - 2023-10-20 05:47:01 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-20 05:47:01 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2023-10-20 05:47:01 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-10-20 05:47:01 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-10-20 05:47:01 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-10-20 05:47:01 --> Model Class Initialized
INFO - 2023-10-20 05:47:01 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-10-20 05:47:01 --> Final output sent to browser
DEBUG - 2023-10-20 05:47:01 --> Total execution time: 0.0382
ERROR - 2023-10-20 05:47:16 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-20 05:47:16 --> Config Class Initialized
INFO - 2023-10-20 05:47:16 --> Hooks Class Initialized
DEBUG - 2023-10-20 05:47:16 --> UTF-8 Support Enabled
INFO - 2023-10-20 05:47:16 --> Utf8 Class Initialized
INFO - 2023-10-20 05:47:16 --> URI Class Initialized
INFO - 2023-10-20 05:47:16 --> Router Class Initialized
INFO - 2023-10-20 05:47:16 --> Output Class Initialized
INFO - 2023-10-20 05:47:16 --> Security Class Initialized
DEBUG - 2023-10-20 05:47:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-20 05:47:16 --> Input Class Initialized
INFO - 2023-10-20 05:47:16 --> Language Class Initialized
INFO - 2023-10-20 05:47:16 --> Loader Class Initialized
INFO - 2023-10-20 05:47:16 --> Helper loaded: url_helper
INFO - 2023-10-20 05:47:16 --> Helper loaded: file_helper
INFO - 2023-10-20 05:47:16 --> Helper loaded: html_helper
INFO - 2023-10-20 05:47:16 --> Helper loaded: text_helper
INFO - 2023-10-20 05:47:16 --> Helper loaded: form_helper
INFO - 2023-10-20 05:47:16 --> Helper loaded: lang_helper
INFO - 2023-10-20 05:47:16 --> Helper loaded: security_helper
INFO - 2023-10-20 05:47:16 --> Helper loaded: cookie_helper
INFO - 2023-10-20 05:47:16 --> Database Driver Class Initialized
INFO - 2023-10-20 05:47:16 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-20 05:47:16 --> Parser Class Initialized
INFO - 2023-10-20 05:47:16 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-20 05:47:16 --> Pagination Class Initialized
INFO - 2023-10-20 05:47:16 --> Form Validation Class Initialized
INFO - 2023-10-20 05:47:16 --> Controller Class Initialized
INFO - 2023-10-20 05:47:16 --> Model Class Initialized
DEBUG - 2023-10-20 05:47:16 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-20 05:47:16 --> Model Class Initialized
INFO - 2023-10-20 05:47:16 --> Final output sent to browser
DEBUG - 2023-10-20 05:47:16 --> Total execution time: 0.0216
ERROR - 2023-10-20 05:47:17 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-20 05:47:17 --> Config Class Initialized
INFO - 2023-10-20 05:47:17 --> Hooks Class Initialized
DEBUG - 2023-10-20 05:47:17 --> UTF-8 Support Enabled
INFO - 2023-10-20 05:47:17 --> Utf8 Class Initialized
INFO - 2023-10-20 05:47:17 --> URI Class Initialized
DEBUG - 2023-10-20 05:47:17 --> No URI present. Default controller set.
INFO - 2023-10-20 05:47:17 --> Router Class Initialized
INFO - 2023-10-20 05:47:17 --> Output Class Initialized
INFO - 2023-10-20 05:47:17 --> Security Class Initialized
DEBUG - 2023-10-20 05:47:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-20 05:47:17 --> Input Class Initialized
INFO - 2023-10-20 05:47:17 --> Language Class Initialized
INFO - 2023-10-20 05:47:17 --> Loader Class Initialized
INFO - 2023-10-20 05:47:17 --> Helper loaded: url_helper
INFO - 2023-10-20 05:47:17 --> Helper loaded: file_helper
INFO - 2023-10-20 05:47:17 --> Helper loaded: html_helper
INFO - 2023-10-20 05:47:17 --> Helper loaded: text_helper
INFO - 2023-10-20 05:47:17 --> Helper loaded: form_helper
INFO - 2023-10-20 05:47:17 --> Helper loaded: lang_helper
INFO - 2023-10-20 05:47:17 --> Helper loaded: security_helper
INFO - 2023-10-20 05:47:17 --> Helper loaded: cookie_helper
INFO - 2023-10-20 05:47:17 --> Database Driver Class Initialized
INFO - 2023-10-20 05:47:17 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-20 05:47:17 --> Parser Class Initialized
INFO - 2023-10-20 05:47:17 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-20 05:47:17 --> Pagination Class Initialized
INFO - 2023-10-20 05:47:17 --> Form Validation Class Initialized
INFO - 2023-10-20 05:47:17 --> Controller Class Initialized
INFO - 2023-10-20 05:47:17 --> Model Class Initialized
DEBUG - 2023-10-20 05:47:17 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-20 05:47:17 --> Model Class Initialized
DEBUG - 2023-10-20 05:47:17 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-20 05:47:17 --> Model Class Initialized
INFO - 2023-10-20 05:47:17 --> Model Class Initialized
INFO - 2023-10-20 05:47:17 --> Model Class Initialized
INFO - 2023-10-20 05:47:17 --> Model Class Initialized
DEBUG - 2023-10-20 05:47:17 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-10-20 05:47:17 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-20 05:47:17 --> Model Class Initialized
INFO - 2023-10-20 05:47:17 --> Model Class Initialized
INFO - 2023-10-20 05:47:17 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-10-20 05:47:17 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-10-20 05:47:17 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-10-20 05:47:17 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-10-20 05:47:17 --> Model Class Initialized
INFO - 2023-10-20 05:47:17 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-10-20 05:47:17 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-10-20 05:47:17 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-10-20 05:47:17 --> Final output sent to browser
DEBUG - 2023-10-20 05:47:17 --> Total execution time: 0.2022
ERROR - 2023-10-20 05:47:25 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-20 05:47:25 --> Config Class Initialized
INFO - 2023-10-20 05:47:25 --> Hooks Class Initialized
DEBUG - 2023-10-20 05:47:25 --> UTF-8 Support Enabled
INFO - 2023-10-20 05:47:25 --> Utf8 Class Initialized
INFO - 2023-10-20 05:47:25 --> URI Class Initialized
INFO - 2023-10-20 05:47:25 --> Router Class Initialized
INFO - 2023-10-20 05:47:25 --> Output Class Initialized
INFO - 2023-10-20 05:47:25 --> Security Class Initialized
DEBUG - 2023-10-20 05:47:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-20 05:47:25 --> Input Class Initialized
INFO - 2023-10-20 05:47:25 --> Language Class Initialized
INFO - 2023-10-20 05:47:25 --> Loader Class Initialized
INFO - 2023-10-20 05:47:25 --> Helper loaded: url_helper
INFO - 2023-10-20 05:47:25 --> Helper loaded: file_helper
INFO - 2023-10-20 05:47:25 --> Helper loaded: html_helper
INFO - 2023-10-20 05:47:25 --> Helper loaded: text_helper
INFO - 2023-10-20 05:47:25 --> Helper loaded: form_helper
INFO - 2023-10-20 05:47:25 --> Helper loaded: lang_helper
INFO - 2023-10-20 05:47:25 --> Helper loaded: security_helper
INFO - 2023-10-20 05:47:25 --> Helper loaded: cookie_helper
INFO - 2023-10-20 05:47:25 --> Database Driver Class Initialized
INFO - 2023-10-20 05:47:25 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-20 05:47:25 --> Parser Class Initialized
INFO - 2023-10-20 05:47:25 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-20 05:47:25 --> Pagination Class Initialized
INFO - 2023-10-20 05:47:25 --> Form Validation Class Initialized
INFO - 2023-10-20 05:47:25 --> Controller Class Initialized
INFO - 2023-10-20 05:47:25 --> Model Class Initialized
DEBUG - 2023-10-20 05:47:25 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-10-20 05:47:25 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-20 05:47:25 --> Model Class Initialized
DEBUG - 2023-10-20 05:47:25 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-20 05:47:25 --> Model Class Initialized
INFO - 2023-10-20 05:47:25 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/add_invoice_form.php
DEBUG - 2023-10-20 05:47:25 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-10-20 05:47:25 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-10-20 05:47:25 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-10-20 05:47:25 --> Model Class Initialized
INFO - 2023-10-20 05:47:25 --> Model Class Initialized
INFO - 2023-10-20 05:47:25 --> Model Class Initialized
INFO - 2023-10-20 05:47:25 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-10-20 05:47:25 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-10-20 05:47:25 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-10-20 05:47:25 --> Final output sent to browser
DEBUG - 2023-10-20 05:47:25 --> Total execution time: 0.1590
ERROR - 2023-10-20 05:47:30 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-20 05:47:30 --> Config Class Initialized
INFO - 2023-10-20 05:47:30 --> Hooks Class Initialized
DEBUG - 2023-10-20 05:47:30 --> UTF-8 Support Enabled
INFO - 2023-10-20 05:47:30 --> Utf8 Class Initialized
INFO - 2023-10-20 05:47:30 --> URI Class Initialized
INFO - 2023-10-20 05:47:30 --> Router Class Initialized
INFO - 2023-10-20 05:47:30 --> Output Class Initialized
INFO - 2023-10-20 05:47:30 --> Security Class Initialized
DEBUG - 2023-10-20 05:47:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-20 05:47:30 --> Input Class Initialized
INFO - 2023-10-20 05:47:30 --> Language Class Initialized
INFO - 2023-10-20 05:47:30 --> Loader Class Initialized
INFO - 2023-10-20 05:47:30 --> Helper loaded: url_helper
INFO - 2023-10-20 05:47:30 --> Helper loaded: file_helper
INFO - 2023-10-20 05:47:30 --> Helper loaded: html_helper
INFO - 2023-10-20 05:47:30 --> Helper loaded: text_helper
INFO - 2023-10-20 05:47:30 --> Helper loaded: form_helper
INFO - 2023-10-20 05:47:30 --> Helper loaded: lang_helper
INFO - 2023-10-20 05:47:30 --> Helper loaded: security_helper
INFO - 2023-10-20 05:47:30 --> Helper loaded: cookie_helper
INFO - 2023-10-20 05:47:30 --> Database Driver Class Initialized
INFO - 2023-10-20 05:47:30 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-20 05:47:30 --> Parser Class Initialized
INFO - 2023-10-20 05:47:30 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-20 05:47:30 --> Pagination Class Initialized
INFO - 2023-10-20 05:47:30 --> Form Validation Class Initialized
INFO - 2023-10-20 05:47:30 --> Controller Class Initialized
INFO - 2023-10-20 05:47:30 --> Model Class Initialized
DEBUG - 2023-10-20 05:47:30 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-20 05:47:30 --> Final output sent to browser
DEBUG - 2023-10-20 05:47:30 --> Total execution time: 0.0156
ERROR - 2023-10-20 05:47:31 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-20 05:47:31 --> Config Class Initialized
INFO - 2023-10-20 05:47:31 --> Hooks Class Initialized
DEBUG - 2023-10-20 05:47:31 --> UTF-8 Support Enabled
INFO - 2023-10-20 05:47:31 --> Utf8 Class Initialized
INFO - 2023-10-20 05:47:31 --> URI Class Initialized
INFO - 2023-10-20 05:47:31 --> Router Class Initialized
INFO - 2023-10-20 05:47:31 --> Output Class Initialized
INFO - 2023-10-20 05:47:31 --> Security Class Initialized
DEBUG - 2023-10-20 05:47:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-20 05:47:31 --> Input Class Initialized
INFO - 2023-10-20 05:47:31 --> Language Class Initialized
INFO - 2023-10-20 05:47:31 --> Loader Class Initialized
INFO - 2023-10-20 05:47:31 --> Helper loaded: url_helper
INFO - 2023-10-20 05:47:31 --> Helper loaded: file_helper
INFO - 2023-10-20 05:47:31 --> Helper loaded: html_helper
INFO - 2023-10-20 05:47:31 --> Helper loaded: text_helper
INFO - 2023-10-20 05:47:31 --> Helper loaded: form_helper
INFO - 2023-10-20 05:47:31 --> Helper loaded: lang_helper
INFO - 2023-10-20 05:47:31 --> Helper loaded: security_helper
INFO - 2023-10-20 05:47:31 --> Helper loaded: cookie_helper
INFO - 2023-10-20 05:47:31 --> Database Driver Class Initialized
INFO - 2023-10-20 05:47:31 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-20 05:47:31 --> Parser Class Initialized
INFO - 2023-10-20 05:47:31 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-20 05:47:31 --> Pagination Class Initialized
INFO - 2023-10-20 05:47:31 --> Form Validation Class Initialized
INFO - 2023-10-20 05:47:31 --> Controller Class Initialized
INFO - 2023-10-20 05:47:31 --> Model Class Initialized
DEBUG - 2023-10-20 05:47:31 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-20 05:47:31 --> Final output sent to browser
DEBUG - 2023-10-20 05:47:31 --> Total execution time: 0.0158
ERROR - 2023-10-20 05:47:32 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-20 05:47:32 --> Config Class Initialized
INFO - 2023-10-20 05:47:32 --> Hooks Class Initialized
DEBUG - 2023-10-20 05:47:32 --> UTF-8 Support Enabled
INFO - 2023-10-20 05:47:32 --> Utf8 Class Initialized
INFO - 2023-10-20 05:47:32 --> URI Class Initialized
INFO - 2023-10-20 05:47:32 --> Router Class Initialized
INFO - 2023-10-20 05:47:32 --> Output Class Initialized
INFO - 2023-10-20 05:47:32 --> Security Class Initialized
DEBUG - 2023-10-20 05:47:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-20 05:47:32 --> Input Class Initialized
INFO - 2023-10-20 05:47:32 --> Language Class Initialized
INFO - 2023-10-20 05:47:32 --> Loader Class Initialized
INFO - 2023-10-20 05:47:32 --> Helper loaded: url_helper
INFO - 2023-10-20 05:47:32 --> Helper loaded: file_helper
INFO - 2023-10-20 05:47:32 --> Helper loaded: html_helper
INFO - 2023-10-20 05:47:32 --> Helper loaded: text_helper
INFO - 2023-10-20 05:47:32 --> Helper loaded: form_helper
INFO - 2023-10-20 05:47:32 --> Helper loaded: lang_helper
INFO - 2023-10-20 05:47:32 --> Helper loaded: security_helper
INFO - 2023-10-20 05:47:32 --> Helper loaded: cookie_helper
INFO - 2023-10-20 05:47:32 --> Database Driver Class Initialized
INFO - 2023-10-20 05:47:32 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-20 05:47:32 --> Parser Class Initialized
INFO - 2023-10-20 05:47:32 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-20 05:47:32 --> Pagination Class Initialized
INFO - 2023-10-20 05:47:32 --> Form Validation Class Initialized
INFO - 2023-10-20 05:47:32 --> Controller Class Initialized
INFO - 2023-10-20 05:47:32 --> Final output sent to browser
DEBUG - 2023-10-20 05:47:32 --> Total execution time: 0.0176
ERROR - 2023-10-20 05:47:36 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-20 05:47:36 --> Config Class Initialized
INFO - 2023-10-20 05:47:36 --> Hooks Class Initialized
DEBUG - 2023-10-20 05:47:36 --> UTF-8 Support Enabled
INFO - 2023-10-20 05:47:36 --> Utf8 Class Initialized
INFO - 2023-10-20 05:47:36 --> URI Class Initialized
INFO - 2023-10-20 05:47:36 --> Router Class Initialized
INFO - 2023-10-20 05:47:36 --> Output Class Initialized
INFO - 2023-10-20 05:47:36 --> Security Class Initialized
DEBUG - 2023-10-20 05:47:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-20 05:47:36 --> Input Class Initialized
INFO - 2023-10-20 05:47:36 --> Language Class Initialized
INFO - 2023-10-20 05:47:36 --> Loader Class Initialized
INFO - 2023-10-20 05:47:36 --> Helper loaded: url_helper
INFO - 2023-10-20 05:47:36 --> Helper loaded: file_helper
INFO - 2023-10-20 05:47:36 --> Helper loaded: html_helper
INFO - 2023-10-20 05:47:36 --> Helper loaded: text_helper
INFO - 2023-10-20 05:47:36 --> Helper loaded: form_helper
INFO - 2023-10-20 05:47:36 --> Helper loaded: lang_helper
INFO - 2023-10-20 05:47:36 --> Helper loaded: security_helper
INFO - 2023-10-20 05:47:36 --> Helper loaded: cookie_helper
INFO - 2023-10-20 05:47:36 --> Database Driver Class Initialized
INFO - 2023-10-20 05:47:36 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-20 05:47:36 --> Parser Class Initialized
INFO - 2023-10-20 05:47:36 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-20 05:47:36 --> Pagination Class Initialized
INFO - 2023-10-20 05:47:36 --> Form Validation Class Initialized
INFO - 2023-10-20 05:47:36 --> Controller Class Initialized
INFO - 2023-10-20 05:47:36 --> Model Class Initialized
DEBUG - 2023-10-20 05:47:36 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-10-20 05:47:36 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-20 05:47:36 --> Model Class Initialized
DEBUG - 2023-10-20 05:47:36 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-20 05:47:36 --> Model Class Initialized
INFO - 2023-10-20 05:47:36 --> Final output sent to browser
DEBUG - 2023-10-20 05:47:36 --> Total execution time: 0.1644
ERROR - 2023-10-20 05:47:37 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-20 05:47:37 --> Config Class Initialized
INFO - 2023-10-20 05:47:37 --> Hooks Class Initialized
DEBUG - 2023-10-20 05:47:37 --> UTF-8 Support Enabled
INFO - 2023-10-20 05:47:37 --> Utf8 Class Initialized
INFO - 2023-10-20 05:47:37 --> URI Class Initialized
INFO - 2023-10-20 05:47:37 --> Router Class Initialized
INFO - 2023-10-20 05:47:37 --> Output Class Initialized
INFO - 2023-10-20 05:47:37 --> Security Class Initialized
DEBUG - 2023-10-20 05:47:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-20 05:47:37 --> Input Class Initialized
INFO - 2023-10-20 05:47:37 --> Language Class Initialized
INFO - 2023-10-20 05:47:37 --> Loader Class Initialized
INFO - 2023-10-20 05:47:37 --> Helper loaded: url_helper
INFO - 2023-10-20 05:47:37 --> Helper loaded: file_helper
INFO - 2023-10-20 05:47:37 --> Helper loaded: html_helper
INFO - 2023-10-20 05:47:37 --> Helper loaded: text_helper
INFO - 2023-10-20 05:47:37 --> Helper loaded: form_helper
INFO - 2023-10-20 05:47:37 --> Helper loaded: lang_helper
INFO - 2023-10-20 05:47:37 --> Helper loaded: security_helper
INFO - 2023-10-20 05:47:37 --> Helper loaded: cookie_helper
INFO - 2023-10-20 05:47:37 --> Database Driver Class Initialized
INFO - 2023-10-20 05:47:37 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-20 05:47:37 --> Parser Class Initialized
INFO - 2023-10-20 05:47:37 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-20 05:47:37 --> Pagination Class Initialized
INFO - 2023-10-20 05:47:37 --> Form Validation Class Initialized
INFO - 2023-10-20 05:47:37 --> Controller Class Initialized
INFO - 2023-10-20 05:47:37 --> Model Class Initialized
DEBUG - 2023-10-20 05:47:37 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-10-20 05:47:37 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-20 05:47:37 --> Model Class Initialized
DEBUG - 2023-10-20 05:47:37 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-20 05:47:37 --> Model Class Initialized
INFO - 2023-10-20 05:47:37 --> Final output sent to browser
DEBUG - 2023-10-20 05:47:37 --> Total execution time: 0.1453
ERROR - 2023-10-20 05:47:38 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-20 05:47:38 --> Config Class Initialized
INFO - 2023-10-20 05:47:38 --> Hooks Class Initialized
DEBUG - 2023-10-20 05:47:38 --> UTF-8 Support Enabled
INFO - 2023-10-20 05:47:38 --> Utf8 Class Initialized
INFO - 2023-10-20 05:47:38 --> URI Class Initialized
INFO - 2023-10-20 05:47:38 --> Router Class Initialized
INFO - 2023-10-20 05:47:38 --> Output Class Initialized
INFO - 2023-10-20 05:47:38 --> Security Class Initialized
DEBUG - 2023-10-20 05:47:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-20 05:47:38 --> Input Class Initialized
INFO - 2023-10-20 05:47:38 --> Language Class Initialized
INFO - 2023-10-20 05:47:38 --> Loader Class Initialized
INFO - 2023-10-20 05:47:38 --> Helper loaded: url_helper
INFO - 2023-10-20 05:47:38 --> Helper loaded: file_helper
INFO - 2023-10-20 05:47:38 --> Helper loaded: html_helper
INFO - 2023-10-20 05:47:38 --> Helper loaded: text_helper
INFO - 2023-10-20 05:47:38 --> Helper loaded: form_helper
INFO - 2023-10-20 05:47:38 --> Helper loaded: lang_helper
INFO - 2023-10-20 05:47:38 --> Helper loaded: security_helper
INFO - 2023-10-20 05:47:38 --> Helper loaded: cookie_helper
INFO - 2023-10-20 05:47:38 --> Database Driver Class Initialized
INFO - 2023-10-20 05:47:38 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-20 05:47:38 --> Parser Class Initialized
INFO - 2023-10-20 05:47:38 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-20 05:47:38 --> Pagination Class Initialized
INFO - 2023-10-20 05:47:38 --> Form Validation Class Initialized
INFO - 2023-10-20 05:47:38 --> Controller Class Initialized
INFO - 2023-10-20 05:47:38 --> Model Class Initialized
DEBUG - 2023-10-20 05:47:38 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-10-20 05:47:38 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-20 05:47:38 --> Model Class Initialized
DEBUG - 2023-10-20 05:47:38 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-20 05:47:38 --> Model Class Initialized
INFO - 2023-10-20 05:47:38 --> Final output sent to browser
DEBUG - 2023-10-20 05:47:38 --> Total execution time: 0.1451
ERROR - 2023-10-20 05:47:41 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-20 05:47:41 --> Config Class Initialized
INFO - 2023-10-20 05:47:41 --> Hooks Class Initialized
DEBUG - 2023-10-20 05:47:41 --> UTF-8 Support Enabled
INFO - 2023-10-20 05:47:41 --> Utf8 Class Initialized
INFO - 2023-10-20 05:47:41 --> URI Class Initialized
INFO - 2023-10-20 05:47:41 --> Router Class Initialized
INFO - 2023-10-20 05:47:41 --> Output Class Initialized
INFO - 2023-10-20 05:47:41 --> Security Class Initialized
DEBUG - 2023-10-20 05:47:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-20 05:47:41 --> Input Class Initialized
INFO - 2023-10-20 05:47:41 --> Language Class Initialized
INFO - 2023-10-20 05:47:41 --> Loader Class Initialized
INFO - 2023-10-20 05:47:41 --> Helper loaded: url_helper
INFO - 2023-10-20 05:47:41 --> Helper loaded: file_helper
INFO - 2023-10-20 05:47:41 --> Helper loaded: html_helper
INFO - 2023-10-20 05:47:41 --> Helper loaded: text_helper
INFO - 2023-10-20 05:47:41 --> Helper loaded: form_helper
INFO - 2023-10-20 05:47:41 --> Helper loaded: lang_helper
INFO - 2023-10-20 05:47:41 --> Helper loaded: security_helper
INFO - 2023-10-20 05:47:41 --> Helper loaded: cookie_helper
INFO - 2023-10-20 05:47:41 --> Database Driver Class Initialized
INFO - 2023-10-20 05:47:41 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-20 05:47:41 --> Parser Class Initialized
INFO - 2023-10-20 05:47:41 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-20 05:47:41 --> Pagination Class Initialized
INFO - 2023-10-20 05:47:41 --> Form Validation Class Initialized
INFO - 2023-10-20 05:47:41 --> Controller Class Initialized
INFO - 2023-10-20 05:47:41 --> Model Class Initialized
DEBUG - 2023-10-20 05:47:41 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-10-20 05:47:41 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-20 05:47:41 --> Model Class Initialized
INFO - 2023-10-20 05:47:41 --> Model Class Initialized
INFO - 2023-10-20 05:47:41 --> Final output sent to browser
DEBUG - 2023-10-20 05:47:41 --> Total execution time: 0.0206
ERROR - 2023-10-20 05:47:44 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-20 05:47:44 --> Config Class Initialized
INFO - 2023-10-20 05:47:44 --> Hooks Class Initialized
DEBUG - 2023-10-20 05:47:44 --> UTF-8 Support Enabled
INFO - 2023-10-20 05:47:44 --> Utf8 Class Initialized
INFO - 2023-10-20 05:47:44 --> URI Class Initialized
INFO - 2023-10-20 05:47:44 --> Router Class Initialized
INFO - 2023-10-20 05:47:44 --> Output Class Initialized
INFO - 2023-10-20 05:47:44 --> Security Class Initialized
DEBUG - 2023-10-20 05:47:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-20 05:47:44 --> Input Class Initialized
INFO - 2023-10-20 05:47:44 --> Language Class Initialized
INFO - 2023-10-20 05:47:44 --> Loader Class Initialized
INFO - 2023-10-20 05:47:44 --> Helper loaded: url_helper
INFO - 2023-10-20 05:47:44 --> Helper loaded: file_helper
INFO - 2023-10-20 05:47:44 --> Helper loaded: html_helper
INFO - 2023-10-20 05:47:44 --> Helper loaded: text_helper
INFO - 2023-10-20 05:47:44 --> Helper loaded: form_helper
INFO - 2023-10-20 05:47:44 --> Helper loaded: lang_helper
INFO - 2023-10-20 05:47:44 --> Helper loaded: security_helper
INFO - 2023-10-20 05:47:44 --> Helper loaded: cookie_helper
INFO - 2023-10-20 05:47:44 --> Database Driver Class Initialized
INFO - 2023-10-20 05:47:44 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-20 05:47:44 --> Parser Class Initialized
INFO - 2023-10-20 05:47:44 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-20 05:47:44 --> Pagination Class Initialized
INFO - 2023-10-20 05:47:44 --> Form Validation Class Initialized
INFO - 2023-10-20 05:47:44 --> Controller Class Initialized
INFO - 2023-10-20 05:47:44 --> Model Class Initialized
DEBUG - 2023-10-20 05:47:44 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-10-20 05:47:44 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-20 05:47:44 --> Model Class Initialized
INFO - 2023-10-20 05:47:44 --> Final output sent to browser
DEBUG - 2023-10-20 05:47:44 --> Total execution time: 0.0169
ERROR - 2023-10-20 05:48:00 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-20 05:48:00 --> Config Class Initialized
INFO - 2023-10-20 05:48:00 --> Hooks Class Initialized
DEBUG - 2023-10-20 05:48:00 --> UTF-8 Support Enabled
INFO - 2023-10-20 05:48:00 --> Utf8 Class Initialized
INFO - 2023-10-20 05:48:00 --> URI Class Initialized
INFO - 2023-10-20 05:48:00 --> Router Class Initialized
INFO - 2023-10-20 05:48:00 --> Output Class Initialized
INFO - 2023-10-20 05:48:00 --> Security Class Initialized
DEBUG - 2023-10-20 05:48:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-20 05:48:00 --> Input Class Initialized
INFO - 2023-10-20 05:48:00 --> Language Class Initialized
INFO - 2023-10-20 05:48:00 --> Loader Class Initialized
INFO - 2023-10-20 05:48:00 --> Helper loaded: url_helper
INFO - 2023-10-20 05:48:00 --> Helper loaded: file_helper
INFO - 2023-10-20 05:48:00 --> Helper loaded: html_helper
INFO - 2023-10-20 05:48:00 --> Helper loaded: text_helper
INFO - 2023-10-20 05:48:00 --> Helper loaded: form_helper
INFO - 2023-10-20 05:48:00 --> Helper loaded: lang_helper
INFO - 2023-10-20 05:48:00 --> Helper loaded: security_helper
INFO - 2023-10-20 05:48:00 --> Helper loaded: cookie_helper
INFO - 2023-10-20 05:48:00 --> Database Driver Class Initialized
INFO - 2023-10-20 05:48:00 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-20 05:48:00 --> Parser Class Initialized
INFO - 2023-10-20 05:48:00 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-20 05:48:00 --> Pagination Class Initialized
INFO - 2023-10-20 05:48:00 --> Form Validation Class Initialized
INFO - 2023-10-20 05:48:00 --> Controller Class Initialized
INFO - 2023-10-20 05:48:00 --> Model Class Initialized
DEBUG - 2023-10-20 05:48:00 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-10-20 05:48:00 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-20 05:48:00 --> Model Class Initialized
DEBUG - 2023-10-20 05:48:00 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-20 05:48:00 --> Model Class Initialized
INFO - 2023-10-20 05:48:01 --> Final output sent to browser
DEBUG - 2023-10-20 05:48:01 --> Total execution time: 0.1495
ERROR - 2023-10-20 05:48:01 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-20 05:48:01 --> Config Class Initialized
INFO - 2023-10-20 05:48:01 --> Hooks Class Initialized
DEBUG - 2023-10-20 05:48:01 --> UTF-8 Support Enabled
INFO - 2023-10-20 05:48:01 --> Utf8 Class Initialized
INFO - 2023-10-20 05:48:01 --> URI Class Initialized
INFO - 2023-10-20 05:48:01 --> Router Class Initialized
INFO - 2023-10-20 05:48:01 --> Output Class Initialized
INFO - 2023-10-20 05:48:01 --> Security Class Initialized
DEBUG - 2023-10-20 05:48:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-20 05:48:01 --> Input Class Initialized
INFO - 2023-10-20 05:48:01 --> Language Class Initialized
INFO - 2023-10-20 05:48:01 --> Loader Class Initialized
INFO - 2023-10-20 05:48:01 --> Helper loaded: url_helper
INFO - 2023-10-20 05:48:01 --> Helper loaded: file_helper
INFO - 2023-10-20 05:48:01 --> Helper loaded: html_helper
INFO - 2023-10-20 05:48:01 --> Helper loaded: text_helper
INFO - 2023-10-20 05:48:01 --> Helper loaded: form_helper
INFO - 2023-10-20 05:48:01 --> Helper loaded: lang_helper
INFO - 2023-10-20 05:48:01 --> Helper loaded: security_helper
INFO - 2023-10-20 05:48:01 --> Helper loaded: cookie_helper
INFO - 2023-10-20 05:48:01 --> Database Driver Class Initialized
INFO - 2023-10-20 05:48:01 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-20 05:48:01 --> Parser Class Initialized
INFO - 2023-10-20 05:48:01 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-20 05:48:01 --> Pagination Class Initialized
INFO - 2023-10-20 05:48:01 --> Form Validation Class Initialized
INFO - 2023-10-20 05:48:01 --> Controller Class Initialized
INFO - 2023-10-20 05:48:01 --> Model Class Initialized
DEBUG - 2023-10-20 05:48:01 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-10-20 05:48:01 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-20 05:48:01 --> Model Class Initialized
DEBUG - 2023-10-20 05:48:01 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-20 05:48:01 --> Model Class Initialized
INFO - 2023-10-20 05:48:01 --> Final output sent to browser
DEBUG - 2023-10-20 05:48:01 --> Total execution time: 0.1523
ERROR - 2023-10-20 05:48:01 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-20 05:48:01 --> Config Class Initialized
INFO - 2023-10-20 05:48:01 --> Hooks Class Initialized
DEBUG - 2023-10-20 05:48:01 --> UTF-8 Support Enabled
INFO - 2023-10-20 05:48:01 --> Utf8 Class Initialized
INFO - 2023-10-20 05:48:01 --> URI Class Initialized
INFO - 2023-10-20 05:48:01 --> Router Class Initialized
INFO - 2023-10-20 05:48:01 --> Output Class Initialized
INFO - 2023-10-20 05:48:01 --> Security Class Initialized
DEBUG - 2023-10-20 05:48:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-20 05:48:01 --> Input Class Initialized
INFO - 2023-10-20 05:48:01 --> Language Class Initialized
INFO - 2023-10-20 05:48:01 --> Loader Class Initialized
INFO - 2023-10-20 05:48:01 --> Helper loaded: url_helper
INFO - 2023-10-20 05:48:01 --> Helper loaded: file_helper
INFO - 2023-10-20 05:48:01 --> Helper loaded: html_helper
INFO - 2023-10-20 05:48:01 --> Helper loaded: text_helper
INFO - 2023-10-20 05:48:01 --> Helper loaded: form_helper
INFO - 2023-10-20 05:48:01 --> Helper loaded: lang_helper
INFO - 2023-10-20 05:48:01 --> Helper loaded: security_helper
INFO - 2023-10-20 05:48:01 --> Helper loaded: cookie_helper
INFO - 2023-10-20 05:48:01 --> Database Driver Class Initialized
INFO - 2023-10-20 05:48:01 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-20 05:48:01 --> Parser Class Initialized
INFO - 2023-10-20 05:48:01 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-20 05:48:01 --> Pagination Class Initialized
INFO - 2023-10-20 05:48:01 --> Form Validation Class Initialized
INFO - 2023-10-20 05:48:01 --> Controller Class Initialized
INFO - 2023-10-20 05:48:01 --> Model Class Initialized
DEBUG - 2023-10-20 05:48:01 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-10-20 05:48:01 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-20 05:48:01 --> Model Class Initialized
DEBUG - 2023-10-20 05:48:01 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-20 05:48:01 --> Model Class Initialized
INFO - 2023-10-20 05:48:02 --> Final output sent to browser
DEBUG - 2023-10-20 05:48:02 --> Total execution time: 0.1653
ERROR - 2023-10-20 05:48:10 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-20 05:48:10 --> Config Class Initialized
INFO - 2023-10-20 05:48:10 --> Hooks Class Initialized
DEBUG - 2023-10-20 05:48:10 --> UTF-8 Support Enabled
INFO - 2023-10-20 05:48:10 --> Utf8 Class Initialized
INFO - 2023-10-20 05:48:10 --> URI Class Initialized
INFO - 2023-10-20 05:48:10 --> Router Class Initialized
INFO - 2023-10-20 05:48:10 --> Output Class Initialized
INFO - 2023-10-20 05:48:10 --> Security Class Initialized
DEBUG - 2023-10-20 05:48:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-20 05:48:10 --> Input Class Initialized
INFO - 2023-10-20 05:48:10 --> Language Class Initialized
INFO - 2023-10-20 05:48:10 --> Loader Class Initialized
INFO - 2023-10-20 05:48:10 --> Helper loaded: url_helper
INFO - 2023-10-20 05:48:10 --> Helper loaded: file_helper
INFO - 2023-10-20 05:48:10 --> Helper loaded: html_helper
INFO - 2023-10-20 05:48:10 --> Helper loaded: text_helper
INFO - 2023-10-20 05:48:10 --> Helper loaded: form_helper
INFO - 2023-10-20 05:48:10 --> Helper loaded: lang_helper
INFO - 2023-10-20 05:48:10 --> Helper loaded: security_helper
INFO - 2023-10-20 05:48:10 --> Helper loaded: cookie_helper
INFO - 2023-10-20 05:48:10 --> Database Driver Class Initialized
INFO - 2023-10-20 05:48:10 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-20 05:48:10 --> Parser Class Initialized
INFO - 2023-10-20 05:48:10 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-20 05:48:10 --> Pagination Class Initialized
INFO - 2023-10-20 05:48:10 --> Form Validation Class Initialized
INFO - 2023-10-20 05:48:10 --> Controller Class Initialized
INFO - 2023-10-20 05:48:10 --> Model Class Initialized
DEBUG - 2023-10-20 05:48:10 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-10-20 05:48:10 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-20 05:48:10 --> Model Class Initialized
INFO - 2023-10-20 05:48:10 --> Model Class Initialized
INFO - 2023-10-20 05:48:10 --> Final output sent to browser
DEBUG - 2023-10-20 05:48:10 --> Total execution time: 0.0241
ERROR - 2023-10-20 05:48:14 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-20 05:48:14 --> Config Class Initialized
INFO - 2023-10-20 05:48:14 --> Hooks Class Initialized
DEBUG - 2023-10-20 05:48:14 --> UTF-8 Support Enabled
INFO - 2023-10-20 05:48:14 --> Utf8 Class Initialized
INFO - 2023-10-20 05:48:14 --> URI Class Initialized
INFO - 2023-10-20 05:48:14 --> Router Class Initialized
INFO - 2023-10-20 05:48:14 --> Output Class Initialized
INFO - 2023-10-20 05:48:14 --> Security Class Initialized
DEBUG - 2023-10-20 05:48:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-20 05:48:14 --> Input Class Initialized
INFO - 2023-10-20 05:48:14 --> Language Class Initialized
INFO - 2023-10-20 05:48:14 --> Loader Class Initialized
INFO - 2023-10-20 05:48:14 --> Helper loaded: url_helper
INFO - 2023-10-20 05:48:14 --> Helper loaded: file_helper
INFO - 2023-10-20 05:48:14 --> Helper loaded: html_helper
INFO - 2023-10-20 05:48:14 --> Helper loaded: text_helper
INFO - 2023-10-20 05:48:14 --> Helper loaded: form_helper
INFO - 2023-10-20 05:48:14 --> Helper loaded: lang_helper
INFO - 2023-10-20 05:48:14 --> Helper loaded: security_helper
INFO - 2023-10-20 05:48:14 --> Helper loaded: cookie_helper
INFO - 2023-10-20 05:48:14 --> Database Driver Class Initialized
INFO - 2023-10-20 05:48:14 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-20 05:48:14 --> Parser Class Initialized
INFO - 2023-10-20 05:48:14 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-20 05:48:14 --> Pagination Class Initialized
INFO - 2023-10-20 05:48:14 --> Form Validation Class Initialized
INFO - 2023-10-20 05:48:14 --> Controller Class Initialized
INFO - 2023-10-20 05:48:14 --> Model Class Initialized
DEBUG - 2023-10-20 05:48:14 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-10-20 05:48:14 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-20 05:48:14 --> Model Class Initialized
INFO - 2023-10-20 05:48:14 --> Final output sent to browser
DEBUG - 2023-10-20 05:48:14 --> Total execution time: 0.0163
ERROR - 2023-10-20 05:48:21 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-20 05:48:21 --> Config Class Initialized
INFO - 2023-10-20 05:48:21 --> Hooks Class Initialized
DEBUG - 2023-10-20 05:48:21 --> UTF-8 Support Enabled
INFO - 2023-10-20 05:48:21 --> Utf8 Class Initialized
INFO - 2023-10-20 05:48:21 --> URI Class Initialized
INFO - 2023-10-20 05:48:21 --> Router Class Initialized
INFO - 2023-10-20 05:48:21 --> Output Class Initialized
INFO - 2023-10-20 05:48:21 --> Security Class Initialized
DEBUG - 2023-10-20 05:48:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-20 05:48:21 --> Input Class Initialized
INFO - 2023-10-20 05:48:21 --> Language Class Initialized
INFO - 2023-10-20 05:48:21 --> Loader Class Initialized
INFO - 2023-10-20 05:48:21 --> Helper loaded: url_helper
INFO - 2023-10-20 05:48:21 --> Helper loaded: file_helper
INFO - 2023-10-20 05:48:21 --> Helper loaded: html_helper
INFO - 2023-10-20 05:48:21 --> Helper loaded: text_helper
INFO - 2023-10-20 05:48:21 --> Helper loaded: form_helper
INFO - 2023-10-20 05:48:21 --> Helper loaded: lang_helper
INFO - 2023-10-20 05:48:21 --> Helper loaded: security_helper
INFO - 2023-10-20 05:48:21 --> Helper loaded: cookie_helper
INFO - 2023-10-20 05:48:21 --> Database Driver Class Initialized
INFO - 2023-10-20 05:48:21 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-20 05:48:21 --> Parser Class Initialized
INFO - 2023-10-20 05:48:21 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-20 05:48:21 --> Pagination Class Initialized
INFO - 2023-10-20 05:48:21 --> Form Validation Class Initialized
INFO - 2023-10-20 05:48:21 --> Controller Class Initialized
INFO - 2023-10-20 05:48:21 --> Model Class Initialized
DEBUG - 2023-10-20 05:48:21 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-10-20 05:48:21 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-20 05:48:21 --> Model Class Initialized
DEBUG - 2023-10-20 05:48:21 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-20 05:48:21 --> Model Class Initialized
INFO - 2023-10-20 05:48:22 --> Final output sent to browser
DEBUG - 2023-10-20 05:48:22 --> Total execution time: 0.1472
ERROR - 2023-10-20 05:48:22 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-20 05:48:22 --> Config Class Initialized
INFO - 2023-10-20 05:48:22 --> Hooks Class Initialized
DEBUG - 2023-10-20 05:48:22 --> UTF-8 Support Enabled
INFO - 2023-10-20 05:48:22 --> Utf8 Class Initialized
INFO - 2023-10-20 05:48:22 --> URI Class Initialized
INFO - 2023-10-20 05:48:22 --> Router Class Initialized
INFO - 2023-10-20 05:48:22 --> Output Class Initialized
INFO - 2023-10-20 05:48:22 --> Security Class Initialized
DEBUG - 2023-10-20 05:48:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-20 05:48:22 --> Input Class Initialized
INFO - 2023-10-20 05:48:22 --> Language Class Initialized
INFO - 2023-10-20 05:48:22 --> Loader Class Initialized
INFO - 2023-10-20 05:48:22 --> Helper loaded: url_helper
INFO - 2023-10-20 05:48:22 --> Helper loaded: file_helper
INFO - 2023-10-20 05:48:22 --> Helper loaded: html_helper
INFO - 2023-10-20 05:48:22 --> Helper loaded: text_helper
INFO - 2023-10-20 05:48:22 --> Helper loaded: form_helper
INFO - 2023-10-20 05:48:22 --> Helper loaded: lang_helper
INFO - 2023-10-20 05:48:22 --> Helper loaded: security_helper
INFO - 2023-10-20 05:48:22 --> Helper loaded: cookie_helper
INFO - 2023-10-20 05:48:22 --> Database Driver Class Initialized
INFO - 2023-10-20 05:48:22 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-20 05:48:22 --> Parser Class Initialized
INFO - 2023-10-20 05:48:22 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-20 05:48:22 --> Pagination Class Initialized
INFO - 2023-10-20 05:48:22 --> Form Validation Class Initialized
INFO - 2023-10-20 05:48:22 --> Controller Class Initialized
INFO - 2023-10-20 05:48:22 --> Model Class Initialized
DEBUG - 2023-10-20 05:48:22 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-10-20 05:48:22 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-20 05:48:22 --> Model Class Initialized
DEBUG - 2023-10-20 05:48:22 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-20 05:48:22 --> Model Class Initialized
INFO - 2023-10-20 05:48:22 --> Final output sent to browser
DEBUG - 2023-10-20 05:48:22 --> Total execution time: 0.1452
ERROR - 2023-10-20 05:48:23 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-20 05:48:23 --> Config Class Initialized
INFO - 2023-10-20 05:48:23 --> Hooks Class Initialized
DEBUG - 2023-10-20 05:48:23 --> UTF-8 Support Enabled
INFO - 2023-10-20 05:48:23 --> Utf8 Class Initialized
INFO - 2023-10-20 05:48:23 --> URI Class Initialized
INFO - 2023-10-20 05:48:23 --> Router Class Initialized
INFO - 2023-10-20 05:48:23 --> Output Class Initialized
INFO - 2023-10-20 05:48:23 --> Security Class Initialized
DEBUG - 2023-10-20 05:48:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-20 05:48:23 --> Input Class Initialized
INFO - 2023-10-20 05:48:23 --> Language Class Initialized
INFO - 2023-10-20 05:48:23 --> Loader Class Initialized
INFO - 2023-10-20 05:48:23 --> Helper loaded: url_helper
INFO - 2023-10-20 05:48:23 --> Helper loaded: file_helper
INFO - 2023-10-20 05:48:23 --> Helper loaded: html_helper
INFO - 2023-10-20 05:48:23 --> Helper loaded: text_helper
INFO - 2023-10-20 05:48:23 --> Helper loaded: form_helper
INFO - 2023-10-20 05:48:23 --> Helper loaded: lang_helper
INFO - 2023-10-20 05:48:23 --> Helper loaded: security_helper
INFO - 2023-10-20 05:48:23 --> Helper loaded: cookie_helper
INFO - 2023-10-20 05:48:23 --> Database Driver Class Initialized
INFO - 2023-10-20 05:48:23 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-20 05:48:23 --> Parser Class Initialized
INFO - 2023-10-20 05:48:23 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-20 05:48:23 --> Pagination Class Initialized
INFO - 2023-10-20 05:48:23 --> Form Validation Class Initialized
INFO - 2023-10-20 05:48:23 --> Controller Class Initialized
INFO - 2023-10-20 05:48:23 --> Model Class Initialized
DEBUG - 2023-10-20 05:48:23 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-10-20 05:48:23 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-20 05:48:23 --> Model Class Initialized
DEBUG - 2023-10-20 05:48:23 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-20 05:48:23 --> Model Class Initialized
INFO - 2023-10-20 05:48:23 --> Final output sent to browser
DEBUG - 2023-10-20 05:48:23 --> Total execution time: 0.1476
ERROR - 2023-10-20 05:48:24 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-20 05:48:24 --> Config Class Initialized
INFO - 2023-10-20 05:48:24 --> Hooks Class Initialized
DEBUG - 2023-10-20 05:48:24 --> UTF-8 Support Enabled
INFO - 2023-10-20 05:48:24 --> Utf8 Class Initialized
INFO - 2023-10-20 05:48:24 --> URI Class Initialized
INFO - 2023-10-20 05:48:24 --> Router Class Initialized
INFO - 2023-10-20 05:48:24 --> Output Class Initialized
INFO - 2023-10-20 05:48:24 --> Security Class Initialized
DEBUG - 2023-10-20 05:48:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-20 05:48:24 --> Input Class Initialized
INFO - 2023-10-20 05:48:24 --> Language Class Initialized
INFO - 2023-10-20 05:48:24 --> Loader Class Initialized
INFO - 2023-10-20 05:48:24 --> Helper loaded: url_helper
INFO - 2023-10-20 05:48:24 --> Helper loaded: file_helper
INFO - 2023-10-20 05:48:24 --> Helper loaded: html_helper
INFO - 2023-10-20 05:48:24 --> Helper loaded: text_helper
INFO - 2023-10-20 05:48:24 --> Helper loaded: form_helper
INFO - 2023-10-20 05:48:24 --> Helper loaded: lang_helper
INFO - 2023-10-20 05:48:24 --> Helper loaded: security_helper
INFO - 2023-10-20 05:48:24 --> Helper loaded: cookie_helper
INFO - 2023-10-20 05:48:24 --> Database Driver Class Initialized
INFO - 2023-10-20 05:48:24 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-20 05:48:24 --> Parser Class Initialized
INFO - 2023-10-20 05:48:24 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-20 05:48:24 --> Pagination Class Initialized
INFO - 2023-10-20 05:48:24 --> Form Validation Class Initialized
INFO - 2023-10-20 05:48:24 --> Controller Class Initialized
INFO - 2023-10-20 05:48:24 --> Model Class Initialized
DEBUG - 2023-10-20 05:48:24 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-10-20 05:48:24 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-20 05:48:24 --> Model Class Initialized
DEBUG - 2023-10-20 05:48:24 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-20 05:48:24 --> Model Class Initialized
INFO - 2023-10-20 05:48:24 --> Final output sent to browser
DEBUG - 2023-10-20 05:48:24 --> Total execution time: 0.0292
ERROR - 2023-10-20 05:48:25 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-20 05:48:25 --> Config Class Initialized
INFO - 2023-10-20 05:48:25 --> Hooks Class Initialized
DEBUG - 2023-10-20 05:48:25 --> UTF-8 Support Enabled
INFO - 2023-10-20 05:48:25 --> Utf8 Class Initialized
INFO - 2023-10-20 05:48:25 --> URI Class Initialized
INFO - 2023-10-20 05:48:25 --> Router Class Initialized
INFO - 2023-10-20 05:48:25 --> Output Class Initialized
INFO - 2023-10-20 05:48:25 --> Security Class Initialized
DEBUG - 2023-10-20 05:48:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-20 05:48:25 --> Input Class Initialized
INFO - 2023-10-20 05:48:25 --> Language Class Initialized
INFO - 2023-10-20 05:48:25 --> Loader Class Initialized
INFO - 2023-10-20 05:48:25 --> Helper loaded: url_helper
INFO - 2023-10-20 05:48:25 --> Helper loaded: file_helper
INFO - 2023-10-20 05:48:25 --> Helper loaded: html_helper
INFO - 2023-10-20 05:48:25 --> Helper loaded: text_helper
INFO - 2023-10-20 05:48:25 --> Helper loaded: form_helper
INFO - 2023-10-20 05:48:25 --> Helper loaded: lang_helper
INFO - 2023-10-20 05:48:25 --> Helper loaded: security_helper
INFO - 2023-10-20 05:48:25 --> Helper loaded: cookie_helper
INFO - 2023-10-20 05:48:25 --> Database Driver Class Initialized
INFO - 2023-10-20 05:48:25 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-20 05:48:25 --> Parser Class Initialized
INFO - 2023-10-20 05:48:25 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-20 05:48:25 --> Pagination Class Initialized
INFO - 2023-10-20 05:48:25 --> Form Validation Class Initialized
INFO - 2023-10-20 05:48:25 --> Controller Class Initialized
INFO - 2023-10-20 05:48:25 --> Model Class Initialized
DEBUG - 2023-10-20 05:48:25 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-10-20 05:48:25 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-20 05:48:25 --> Model Class Initialized
DEBUG - 2023-10-20 05:48:25 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-20 05:48:25 --> Model Class Initialized
INFO - 2023-10-20 05:48:25 --> Final output sent to browser
DEBUG - 2023-10-20 05:48:25 --> Total execution time: 0.0281
ERROR - 2023-10-20 05:48:27 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-20 05:48:27 --> Config Class Initialized
INFO - 2023-10-20 05:48:27 --> Hooks Class Initialized
DEBUG - 2023-10-20 05:48:27 --> UTF-8 Support Enabled
INFO - 2023-10-20 05:48:27 --> Utf8 Class Initialized
INFO - 2023-10-20 05:48:27 --> URI Class Initialized
INFO - 2023-10-20 05:48:27 --> Router Class Initialized
INFO - 2023-10-20 05:48:27 --> Output Class Initialized
INFO - 2023-10-20 05:48:27 --> Security Class Initialized
DEBUG - 2023-10-20 05:48:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-20 05:48:27 --> Input Class Initialized
INFO - 2023-10-20 05:48:27 --> Language Class Initialized
INFO - 2023-10-20 05:48:27 --> Loader Class Initialized
INFO - 2023-10-20 05:48:27 --> Helper loaded: url_helper
INFO - 2023-10-20 05:48:27 --> Helper loaded: file_helper
INFO - 2023-10-20 05:48:27 --> Helper loaded: html_helper
INFO - 2023-10-20 05:48:27 --> Helper loaded: text_helper
INFO - 2023-10-20 05:48:27 --> Helper loaded: form_helper
INFO - 2023-10-20 05:48:27 --> Helper loaded: lang_helper
INFO - 2023-10-20 05:48:27 --> Helper loaded: security_helper
INFO - 2023-10-20 05:48:27 --> Helper loaded: cookie_helper
INFO - 2023-10-20 05:48:27 --> Database Driver Class Initialized
INFO - 2023-10-20 05:48:27 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-20 05:48:27 --> Parser Class Initialized
INFO - 2023-10-20 05:48:27 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-20 05:48:27 --> Pagination Class Initialized
INFO - 2023-10-20 05:48:27 --> Form Validation Class Initialized
INFO - 2023-10-20 05:48:27 --> Controller Class Initialized
INFO - 2023-10-20 05:48:27 --> Model Class Initialized
DEBUG - 2023-10-20 05:48:27 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-10-20 05:48:27 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-20 05:48:27 --> Model Class Initialized
INFO - 2023-10-20 05:48:27 --> Model Class Initialized
INFO - 2023-10-20 05:48:27 --> Final output sent to browser
DEBUG - 2023-10-20 05:48:27 --> Total execution time: 0.0199
ERROR - 2023-10-20 05:48:28 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-20 05:48:28 --> Config Class Initialized
INFO - 2023-10-20 05:48:28 --> Hooks Class Initialized
DEBUG - 2023-10-20 05:48:28 --> UTF-8 Support Enabled
INFO - 2023-10-20 05:48:28 --> Utf8 Class Initialized
INFO - 2023-10-20 05:48:28 --> URI Class Initialized
INFO - 2023-10-20 05:48:28 --> Router Class Initialized
INFO - 2023-10-20 05:48:28 --> Output Class Initialized
INFO - 2023-10-20 05:48:28 --> Security Class Initialized
DEBUG - 2023-10-20 05:48:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-20 05:48:28 --> Input Class Initialized
INFO - 2023-10-20 05:48:28 --> Language Class Initialized
INFO - 2023-10-20 05:48:28 --> Loader Class Initialized
INFO - 2023-10-20 05:48:28 --> Helper loaded: url_helper
INFO - 2023-10-20 05:48:28 --> Helper loaded: file_helper
INFO - 2023-10-20 05:48:28 --> Helper loaded: html_helper
INFO - 2023-10-20 05:48:28 --> Helper loaded: text_helper
INFO - 2023-10-20 05:48:28 --> Helper loaded: form_helper
INFO - 2023-10-20 05:48:28 --> Helper loaded: lang_helper
INFO - 2023-10-20 05:48:28 --> Helper loaded: security_helper
INFO - 2023-10-20 05:48:28 --> Helper loaded: cookie_helper
INFO - 2023-10-20 05:48:28 --> Database Driver Class Initialized
INFO - 2023-10-20 05:48:28 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-20 05:48:28 --> Parser Class Initialized
INFO - 2023-10-20 05:48:28 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-20 05:48:28 --> Pagination Class Initialized
INFO - 2023-10-20 05:48:28 --> Form Validation Class Initialized
INFO - 2023-10-20 05:48:28 --> Controller Class Initialized
INFO - 2023-10-20 05:48:28 --> Model Class Initialized
DEBUG - 2023-10-20 05:48:28 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-10-20 05:48:28 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-20 05:48:28 --> Model Class Initialized
INFO - 2023-10-20 05:48:28 --> Final output sent to browser
DEBUG - 2023-10-20 05:48:28 --> Total execution time: 0.0192
ERROR - 2023-10-20 05:48:41 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-20 05:48:41 --> Config Class Initialized
INFO - 2023-10-20 05:48:41 --> Hooks Class Initialized
DEBUG - 2023-10-20 05:48:41 --> UTF-8 Support Enabled
INFO - 2023-10-20 05:48:41 --> Utf8 Class Initialized
INFO - 2023-10-20 05:48:41 --> URI Class Initialized
INFO - 2023-10-20 05:48:41 --> Router Class Initialized
INFO - 2023-10-20 05:48:41 --> Output Class Initialized
INFO - 2023-10-20 05:48:41 --> Security Class Initialized
DEBUG - 2023-10-20 05:48:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-20 05:48:41 --> Input Class Initialized
INFO - 2023-10-20 05:48:41 --> Language Class Initialized
INFO - 2023-10-20 05:48:41 --> Loader Class Initialized
INFO - 2023-10-20 05:48:41 --> Helper loaded: url_helper
INFO - 2023-10-20 05:48:41 --> Helper loaded: file_helper
INFO - 2023-10-20 05:48:41 --> Helper loaded: html_helper
INFO - 2023-10-20 05:48:41 --> Helper loaded: text_helper
INFO - 2023-10-20 05:48:41 --> Helper loaded: form_helper
INFO - 2023-10-20 05:48:41 --> Helper loaded: lang_helper
INFO - 2023-10-20 05:48:41 --> Helper loaded: security_helper
INFO - 2023-10-20 05:48:41 --> Helper loaded: cookie_helper
INFO - 2023-10-20 05:48:41 --> Database Driver Class Initialized
INFO - 2023-10-20 05:48:41 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-20 05:48:41 --> Parser Class Initialized
INFO - 2023-10-20 05:48:41 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-20 05:48:41 --> Pagination Class Initialized
INFO - 2023-10-20 05:48:41 --> Form Validation Class Initialized
INFO - 2023-10-20 05:48:41 --> Controller Class Initialized
INFO - 2023-10-20 05:48:41 --> Model Class Initialized
DEBUG - 2023-10-20 05:48:41 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-10-20 05:48:41 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-20 05:48:41 --> Model Class Initialized
DEBUG - 2023-10-20 05:48:41 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-20 05:48:41 --> Model Class Initialized
INFO - 2023-10-20 05:48:41 --> Final output sent to browser
DEBUG - 2023-10-20 05:48:41 --> Total execution time: 0.1477
ERROR - 2023-10-20 05:48:41 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-20 05:48:41 --> Config Class Initialized
INFO - 2023-10-20 05:48:41 --> Hooks Class Initialized
DEBUG - 2023-10-20 05:48:41 --> UTF-8 Support Enabled
INFO - 2023-10-20 05:48:41 --> Utf8 Class Initialized
INFO - 2023-10-20 05:48:41 --> URI Class Initialized
INFO - 2023-10-20 05:48:41 --> Router Class Initialized
INFO - 2023-10-20 05:48:41 --> Output Class Initialized
INFO - 2023-10-20 05:48:41 --> Security Class Initialized
DEBUG - 2023-10-20 05:48:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-20 05:48:41 --> Input Class Initialized
INFO - 2023-10-20 05:48:41 --> Language Class Initialized
INFO - 2023-10-20 05:48:41 --> Loader Class Initialized
INFO - 2023-10-20 05:48:41 --> Helper loaded: url_helper
INFO - 2023-10-20 05:48:41 --> Helper loaded: file_helper
INFO - 2023-10-20 05:48:41 --> Helper loaded: html_helper
INFO - 2023-10-20 05:48:41 --> Helper loaded: text_helper
INFO - 2023-10-20 05:48:41 --> Helper loaded: form_helper
INFO - 2023-10-20 05:48:41 --> Helper loaded: lang_helper
INFO - 2023-10-20 05:48:41 --> Helper loaded: security_helper
INFO - 2023-10-20 05:48:41 --> Helper loaded: cookie_helper
INFO - 2023-10-20 05:48:41 --> Database Driver Class Initialized
INFO - 2023-10-20 05:48:41 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-20 05:48:41 --> Parser Class Initialized
INFO - 2023-10-20 05:48:41 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-20 05:48:41 --> Pagination Class Initialized
INFO - 2023-10-20 05:48:41 --> Form Validation Class Initialized
INFO - 2023-10-20 05:48:41 --> Controller Class Initialized
INFO - 2023-10-20 05:48:41 --> Model Class Initialized
DEBUG - 2023-10-20 05:48:41 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-10-20 05:48:41 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-20 05:48:41 --> Model Class Initialized
DEBUG - 2023-10-20 05:48:41 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-20 05:48:41 --> Model Class Initialized
INFO - 2023-10-20 05:48:41 --> Final output sent to browser
DEBUG - 2023-10-20 05:48:41 --> Total execution time: 0.0225
ERROR - 2023-10-20 05:48:43 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-20 05:48:43 --> Config Class Initialized
INFO - 2023-10-20 05:48:43 --> Hooks Class Initialized
DEBUG - 2023-10-20 05:48:43 --> UTF-8 Support Enabled
INFO - 2023-10-20 05:48:43 --> Utf8 Class Initialized
INFO - 2023-10-20 05:48:43 --> URI Class Initialized
INFO - 2023-10-20 05:48:43 --> Router Class Initialized
INFO - 2023-10-20 05:48:43 --> Output Class Initialized
INFO - 2023-10-20 05:48:43 --> Security Class Initialized
DEBUG - 2023-10-20 05:48:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-20 05:48:43 --> Input Class Initialized
INFO - 2023-10-20 05:48:43 --> Language Class Initialized
INFO - 2023-10-20 05:48:43 --> Loader Class Initialized
INFO - 2023-10-20 05:48:43 --> Helper loaded: url_helper
INFO - 2023-10-20 05:48:43 --> Helper loaded: file_helper
INFO - 2023-10-20 05:48:43 --> Helper loaded: html_helper
INFO - 2023-10-20 05:48:43 --> Helper loaded: text_helper
INFO - 2023-10-20 05:48:43 --> Helper loaded: form_helper
INFO - 2023-10-20 05:48:43 --> Helper loaded: lang_helper
INFO - 2023-10-20 05:48:43 --> Helper loaded: security_helper
INFO - 2023-10-20 05:48:43 --> Helper loaded: cookie_helper
INFO - 2023-10-20 05:48:43 --> Database Driver Class Initialized
INFO - 2023-10-20 05:48:43 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-20 05:48:43 --> Parser Class Initialized
INFO - 2023-10-20 05:48:43 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-20 05:48:43 --> Pagination Class Initialized
INFO - 2023-10-20 05:48:43 --> Form Validation Class Initialized
INFO - 2023-10-20 05:48:43 --> Controller Class Initialized
INFO - 2023-10-20 05:48:43 --> Model Class Initialized
DEBUG - 2023-10-20 05:48:43 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-10-20 05:48:43 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-20 05:48:43 --> Model Class Initialized
DEBUG - 2023-10-20 05:48:43 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-20 05:48:43 --> Model Class Initialized
INFO - 2023-10-20 05:48:43 --> Final output sent to browser
DEBUG - 2023-10-20 05:48:43 --> Total execution time: 0.1469
ERROR - 2023-10-20 05:48:44 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-20 05:48:44 --> Config Class Initialized
INFO - 2023-10-20 05:48:44 --> Hooks Class Initialized
DEBUG - 2023-10-20 05:48:44 --> UTF-8 Support Enabled
INFO - 2023-10-20 05:48:44 --> Utf8 Class Initialized
INFO - 2023-10-20 05:48:44 --> URI Class Initialized
INFO - 2023-10-20 05:48:44 --> Router Class Initialized
INFO - 2023-10-20 05:48:44 --> Output Class Initialized
INFO - 2023-10-20 05:48:44 --> Security Class Initialized
DEBUG - 2023-10-20 05:48:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-20 05:48:44 --> Input Class Initialized
INFO - 2023-10-20 05:48:44 --> Language Class Initialized
INFO - 2023-10-20 05:48:44 --> Loader Class Initialized
INFO - 2023-10-20 05:48:44 --> Helper loaded: url_helper
INFO - 2023-10-20 05:48:44 --> Helper loaded: file_helper
INFO - 2023-10-20 05:48:44 --> Helper loaded: html_helper
INFO - 2023-10-20 05:48:44 --> Helper loaded: text_helper
INFO - 2023-10-20 05:48:44 --> Helper loaded: form_helper
INFO - 2023-10-20 05:48:44 --> Helper loaded: lang_helper
INFO - 2023-10-20 05:48:44 --> Helper loaded: security_helper
INFO - 2023-10-20 05:48:44 --> Helper loaded: cookie_helper
INFO - 2023-10-20 05:48:44 --> Database Driver Class Initialized
INFO - 2023-10-20 05:48:44 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-20 05:48:44 --> Parser Class Initialized
INFO - 2023-10-20 05:48:44 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-20 05:48:44 --> Pagination Class Initialized
INFO - 2023-10-20 05:48:44 --> Form Validation Class Initialized
INFO - 2023-10-20 05:48:44 --> Controller Class Initialized
INFO - 2023-10-20 05:48:44 --> Model Class Initialized
DEBUG - 2023-10-20 05:48:44 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-10-20 05:48:44 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-20 05:48:44 --> Model Class Initialized
DEBUG - 2023-10-20 05:48:44 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-20 05:48:44 --> Model Class Initialized
INFO - 2023-10-20 05:48:44 --> Final output sent to browser
DEBUG - 2023-10-20 05:48:44 --> Total execution time: 0.0178
ERROR - 2023-10-20 05:48:45 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-20 05:48:45 --> Config Class Initialized
INFO - 2023-10-20 05:48:45 --> Hooks Class Initialized
DEBUG - 2023-10-20 05:48:45 --> UTF-8 Support Enabled
INFO - 2023-10-20 05:48:45 --> Utf8 Class Initialized
INFO - 2023-10-20 05:48:45 --> URI Class Initialized
INFO - 2023-10-20 05:48:45 --> Router Class Initialized
INFO - 2023-10-20 05:48:45 --> Output Class Initialized
INFO - 2023-10-20 05:48:45 --> Security Class Initialized
DEBUG - 2023-10-20 05:48:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-20 05:48:45 --> Input Class Initialized
INFO - 2023-10-20 05:48:45 --> Language Class Initialized
INFO - 2023-10-20 05:48:45 --> Loader Class Initialized
INFO - 2023-10-20 05:48:45 --> Helper loaded: url_helper
INFO - 2023-10-20 05:48:45 --> Helper loaded: file_helper
INFO - 2023-10-20 05:48:45 --> Helper loaded: html_helper
INFO - 2023-10-20 05:48:45 --> Helper loaded: text_helper
INFO - 2023-10-20 05:48:45 --> Helper loaded: form_helper
INFO - 2023-10-20 05:48:45 --> Helper loaded: lang_helper
INFO - 2023-10-20 05:48:45 --> Helper loaded: security_helper
INFO - 2023-10-20 05:48:45 --> Helper loaded: cookie_helper
INFO - 2023-10-20 05:48:45 --> Database Driver Class Initialized
INFO - 2023-10-20 05:48:45 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-20 05:48:45 --> Parser Class Initialized
INFO - 2023-10-20 05:48:45 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-20 05:48:45 --> Pagination Class Initialized
INFO - 2023-10-20 05:48:45 --> Form Validation Class Initialized
INFO - 2023-10-20 05:48:45 --> Controller Class Initialized
INFO - 2023-10-20 05:48:45 --> Model Class Initialized
DEBUG - 2023-10-20 05:48:45 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-10-20 05:48:45 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-20 05:48:45 --> Model Class Initialized
DEBUG - 2023-10-20 05:48:45 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-20 05:48:45 --> Model Class Initialized
INFO - 2023-10-20 05:48:45 --> Final output sent to browser
DEBUG - 2023-10-20 05:48:45 --> Total execution time: 0.1486
ERROR - 2023-10-20 05:48:46 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-20 05:48:46 --> Config Class Initialized
INFO - 2023-10-20 05:48:46 --> Hooks Class Initialized
DEBUG - 2023-10-20 05:48:46 --> UTF-8 Support Enabled
INFO - 2023-10-20 05:48:46 --> Utf8 Class Initialized
INFO - 2023-10-20 05:48:46 --> URI Class Initialized
INFO - 2023-10-20 05:48:46 --> Router Class Initialized
INFO - 2023-10-20 05:48:46 --> Output Class Initialized
INFO - 2023-10-20 05:48:46 --> Security Class Initialized
DEBUG - 2023-10-20 05:48:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-20 05:48:46 --> Input Class Initialized
INFO - 2023-10-20 05:48:46 --> Language Class Initialized
INFO - 2023-10-20 05:48:46 --> Loader Class Initialized
INFO - 2023-10-20 05:48:46 --> Helper loaded: url_helper
INFO - 2023-10-20 05:48:46 --> Helper loaded: file_helper
INFO - 2023-10-20 05:48:46 --> Helper loaded: html_helper
INFO - 2023-10-20 05:48:46 --> Helper loaded: text_helper
INFO - 2023-10-20 05:48:46 --> Helper loaded: form_helper
INFO - 2023-10-20 05:48:46 --> Helper loaded: lang_helper
INFO - 2023-10-20 05:48:46 --> Helper loaded: security_helper
INFO - 2023-10-20 05:48:46 --> Helper loaded: cookie_helper
INFO - 2023-10-20 05:48:46 --> Database Driver Class Initialized
INFO - 2023-10-20 05:48:46 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-20 05:48:46 --> Parser Class Initialized
INFO - 2023-10-20 05:48:46 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-20 05:48:46 --> Pagination Class Initialized
INFO - 2023-10-20 05:48:46 --> Form Validation Class Initialized
INFO - 2023-10-20 05:48:46 --> Controller Class Initialized
INFO - 2023-10-20 05:48:46 --> Model Class Initialized
DEBUG - 2023-10-20 05:48:46 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-10-20 05:48:46 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-20 05:48:46 --> Model Class Initialized
DEBUG - 2023-10-20 05:48:46 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-20 05:48:46 --> Model Class Initialized
INFO - 2023-10-20 05:48:47 --> Final output sent to browser
DEBUG - 2023-10-20 05:48:47 --> Total execution time: 0.1444
ERROR - 2023-10-20 05:48:47 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-20 05:48:47 --> Config Class Initialized
INFO - 2023-10-20 05:48:47 --> Hooks Class Initialized
DEBUG - 2023-10-20 05:48:47 --> UTF-8 Support Enabled
INFO - 2023-10-20 05:48:47 --> Utf8 Class Initialized
INFO - 2023-10-20 05:48:47 --> URI Class Initialized
INFO - 2023-10-20 05:48:47 --> Router Class Initialized
INFO - 2023-10-20 05:48:47 --> Output Class Initialized
INFO - 2023-10-20 05:48:47 --> Security Class Initialized
DEBUG - 2023-10-20 05:48:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-20 05:48:47 --> Input Class Initialized
INFO - 2023-10-20 05:48:47 --> Language Class Initialized
INFO - 2023-10-20 05:48:47 --> Loader Class Initialized
INFO - 2023-10-20 05:48:47 --> Helper loaded: url_helper
INFO - 2023-10-20 05:48:47 --> Helper loaded: file_helper
INFO - 2023-10-20 05:48:47 --> Helper loaded: html_helper
INFO - 2023-10-20 05:48:47 --> Helper loaded: text_helper
INFO - 2023-10-20 05:48:47 --> Helper loaded: form_helper
INFO - 2023-10-20 05:48:47 --> Helper loaded: lang_helper
INFO - 2023-10-20 05:48:47 --> Helper loaded: security_helper
INFO - 2023-10-20 05:48:47 --> Helper loaded: cookie_helper
INFO - 2023-10-20 05:48:47 --> Database Driver Class Initialized
INFO - 2023-10-20 05:48:47 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-20 05:48:47 --> Parser Class Initialized
INFO - 2023-10-20 05:48:47 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-20 05:48:47 --> Pagination Class Initialized
INFO - 2023-10-20 05:48:47 --> Form Validation Class Initialized
INFO - 2023-10-20 05:48:47 --> Controller Class Initialized
INFO - 2023-10-20 05:48:47 --> Model Class Initialized
DEBUG - 2023-10-20 05:48:47 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-10-20 05:48:47 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-20 05:48:47 --> Model Class Initialized
DEBUG - 2023-10-20 05:48:47 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-20 05:48:47 --> Model Class Initialized
INFO - 2023-10-20 05:48:47 --> Final output sent to browser
DEBUG - 2023-10-20 05:48:47 --> Total execution time: 0.1581
ERROR - 2023-10-20 05:48:49 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-20 05:48:49 --> Config Class Initialized
INFO - 2023-10-20 05:48:49 --> Hooks Class Initialized
DEBUG - 2023-10-20 05:48:49 --> UTF-8 Support Enabled
INFO - 2023-10-20 05:48:49 --> Utf8 Class Initialized
INFO - 2023-10-20 05:48:49 --> URI Class Initialized
INFO - 2023-10-20 05:48:49 --> Router Class Initialized
INFO - 2023-10-20 05:48:49 --> Output Class Initialized
INFO - 2023-10-20 05:48:49 --> Security Class Initialized
DEBUG - 2023-10-20 05:48:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-20 05:48:49 --> Input Class Initialized
INFO - 2023-10-20 05:48:49 --> Language Class Initialized
INFO - 2023-10-20 05:48:49 --> Loader Class Initialized
INFO - 2023-10-20 05:48:49 --> Helper loaded: url_helper
INFO - 2023-10-20 05:48:49 --> Helper loaded: file_helper
INFO - 2023-10-20 05:48:49 --> Helper loaded: html_helper
INFO - 2023-10-20 05:48:49 --> Helper loaded: text_helper
INFO - 2023-10-20 05:48:49 --> Helper loaded: form_helper
INFO - 2023-10-20 05:48:49 --> Helper loaded: lang_helper
INFO - 2023-10-20 05:48:49 --> Helper loaded: security_helper
INFO - 2023-10-20 05:48:49 --> Helper loaded: cookie_helper
INFO - 2023-10-20 05:48:49 --> Database Driver Class Initialized
INFO - 2023-10-20 05:48:49 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-20 05:48:49 --> Parser Class Initialized
INFO - 2023-10-20 05:48:49 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-20 05:48:49 --> Pagination Class Initialized
INFO - 2023-10-20 05:48:49 --> Form Validation Class Initialized
INFO - 2023-10-20 05:48:49 --> Controller Class Initialized
INFO - 2023-10-20 05:48:49 --> Model Class Initialized
DEBUG - 2023-10-20 05:48:49 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-10-20 05:48:49 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-20 05:48:49 --> Model Class Initialized
DEBUG - 2023-10-20 05:48:49 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-20 05:48:49 --> Model Class Initialized
INFO - 2023-10-20 05:48:49 --> Final output sent to browser
DEBUG - 2023-10-20 05:48:49 --> Total execution time: 0.0217
ERROR - 2023-10-20 05:48:50 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-20 05:48:50 --> Config Class Initialized
INFO - 2023-10-20 05:48:50 --> Hooks Class Initialized
DEBUG - 2023-10-20 05:48:50 --> UTF-8 Support Enabled
INFO - 2023-10-20 05:48:50 --> Utf8 Class Initialized
INFO - 2023-10-20 05:48:50 --> URI Class Initialized
INFO - 2023-10-20 05:48:50 --> Router Class Initialized
INFO - 2023-10-20 05:48:50 --> Output Class Initialized
INFO - 2023-10-20 05:48:50 --> Security Class Initialized
DEBUG - 2023-10-20 05:48:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-20 05:48:50 --> Input Class Initialized
INFO - 2023-10-20 05:48:50 --> Language Class Initialized
INFO - 2023-10-20 05:48:50 --> Loader Class Initialized
INFO - 2023-10-20 05:48:50 --> Helper loaded: url_helper
INFO - 2023-10-20 05:48:50 --> Helper loaded: file_helper
INFO - 2023-10-20 05:48:50 --> Helper loaded: html_helper
INFO - 2023-10-20 05:48:50 --> Helper loaded: text_helper
INFO - 2023-10-20 05:48:50 --> Helper loaded: form_helper
INFO - 2023-10-20 05:48:50 --> Helper loaded: lang_helper
INFO - 2023-10-20 05:48:50 --> Helper loaded: security_helper
INFO - 2023-10-20 05:48:50 --> Helper loaded: cookie_helper
INFO - 2023-10-20 05:48:50 --> Database Driver Class Initialized
INFO - 2023-10-20 05:48:50 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-20 05:48:50 --> Parser Class Initialized
INFO - 2023-10-20 05:48:50 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-20 05:48:50 --> Pagination Class Initialized
INFO - 2023-10-20 05:48:50 --> Form Validation Class Initialized
INFO - 2023-10-20 05:48:50 --> Controller Class Initialized
INFO - 2023-10-20 05:48:50 --> Model Class Initialized
DEBUG - 2023-10-20 05:48:50 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-10-20 05:48:50 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-20 05:48:50 --> Model Class Initialized
DEBUG - 2023-10-20 05:48:50 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-20 05:48:50 --> Model Class Initialized
INFO - 2023-10-20 05:48:50 --> Final output sent to browser
DEBUG - 2023-10-20 05:48:50 --> Total execution time: 0.0207
ERROR - 2023-10-20 05:48:50 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-20 05:48:50 --> Config Class Initialized
INFO - 2023-10-20 05:48:50 --> Hooks Class Initialized
DEBUG - 2023-10-20 05:48:50 --> UTF-8 Support Enabled
INFO - 2023-10-20 05:48:50 --> Utf8 Class Initialized
INFO - 2023-10-20 05:48:50 --> URI Class Initialized
INFO - 2023-10-20 05:48:50 --> Router Class Initialized
INFO - 2023-10-20 05:48:50 --> Output Class Initialized
INFO - 2023-10-20 05:48:50 --> Security Class Initialized
DEBUG - 2023-10-20 05:48:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-20 05:48:50 --> Input Class Initialized
INFO - 2023-10-20 05:48:50 --> Language Class Initialized
INFO - 2023-10-20 05:48:50 --> Loader Class Initialized
INFO - 2023-10-20 05:48:50 --> Helper loaded: url_helper
INFO - 2023-10-20 05:48:50 --> Helper loaded: file_helper
INFO - 2023-10-20 05:48:50 --> Helper loaded: html_helper
INFO - 2023-10-20 05:48:50 --> Helper loaded: text_helper
INFO - 2023-10-20 05:48:50 --> Helper loaded: form_helper
INFO - 2023-10-20 05:48:50 --> Helper loaded: lang_helper
INFO - 2023-10-20 05:48:50 --> Helper loaded: security_helper
INFO - 2023-10-20 05:48:50 --> Helper loaded: cookie_helper
INFO - 2023-10-20 05:48:50 --> Database Driver Class Initialized
INFO - 2023-10-20 05:48:50 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-20 05:48:50 --> Parser Class Initialized
INFO - 2023-10-20 05:48:50 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-20 05:48:50 --> Pagination Class Initialized
INFO - 2023-10-20 05:48:50 --> Form Validation Class Initialized
INFO - 2023-10-20 05:48:50 --> Controller Class Initialized
INFO - 2023-10-20 05:48:50 --> Model Class Initialized
DEBUG - 2023-10-20 05:48:50 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-10-20 05:48:50 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-20 05:48:50 --> Model Class Initialized
INFO - 2023-10-20 05:48:50 --> Model Class Initialized
INFO - 2023-10-20 05:48:50 --> Final output sent to browser
DEBUG - 2023-10-20 05:48:50 --> Total execution time: 0.0187
ERROR - 2023-10-20 05:48:52 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-20 05:48:52 --> Config Class Initialized
INFO - 2023-10-20 05:48:52 --> Hooks Class Initialized
DEBUG - 2023-10-20 05:48:52 --> UTF-8 Support Enabled
INFO - 2023-10-20 05:48:52 --> Utf8 Class Initialized
INFO - 2023-10-20 05:48:52 --> URI Class Initialized
INFO - 2023-10-20 05:48:52 --> Router Class Initialized
INFO - 2023-10-20 05:48:52 --> Output Class Initialized
INFO - 2023-10-20 05:48:52 --> Security Class Initialized
DEBUG - 2023-10-20 05:48:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-20 05:48:52 --> Input Class Initialized
INFO - 2023-10-20 05:48:52 --> Language Class Initialized
INFO - 2023-10-20 05:48:52 --> Loader Class Initialized
INFO - 2023-10-20 05:48:52 --> Helper loaded: url_helper
INFO - 2023-10-20 05:48:52 --> Helper loaded: file_helper
INFO - 2023-10-20 05:48:52 --> Helper loaded: html_helper
INFO - 2023-10-20 05:48:52 --> Helper loaded: text_helper
INFO - 2023-10-20 05:48:52 --> Helper loaded: form_helper
INFO - 2023-10-20 05:48:52 --> Helper loaded: lang_helper
INFO - 2023-10-20 05:48:52 --> Helper loaded: security_helper
INFO - 2023-10-20 05:48:52 --> Helper loaded: cookie_helper
INFO - 2023-10-20 05:48:52 --> Database Driver Class Initialized
INFO - 2023-10-20 05:48:52 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-20 05:48:52 --> Parser Class Initialized
INFO - 2023-10-20 05:48:52 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-20 05:48:52 --> Pagination Class Initialized
INFO - 2023-10-20 05:48:52 --> Form Validation Class Initialized
INFO - 2023-10-20 05:48:52 --> Controller Class Initialized
INFO - 2023-10-20 05:48:52 --> Model Class Initialized
DEBUG - 2023-10-20 05:48:52 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-10-20 05:48:52 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-20 05:48:52 --> Model Class Initialized
INFO - 2023-10-20 05:48:52 --> Final output sent to browser
DEBUG - 2023-10-20 05:48:52 --> Total execution time: 0.0155
ERROR - 2023-10-20 05:49:19 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-20 05:49:19 --> Config Class Initialized
INFO - 2023-10-20 05:49:19 --> Hooks Class Initialized
DEBUG - 2023-10-20 05:49:19 --> UTF-8 Support Enabled
INFO - 2023-10-20 05:49:19 --> Utf8 Class Initialized
INFO - 2023-10-20 05:49:19 --> URI Class Initialized
INFO - 2023-10-20 05:49:19 --> Router Class Initialized
INFO - 2023-10-20 05:49:19 --> Output Class Initialized
INFO - 2023-10-20 05:49:19 --> Security Class Initialized
DEBUG - 2023-10-20 05:49:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-20 05:49:19 --> Input Class Initialized
INFO - 2023-10-20 05:49:19 --> Language Class Initialized
INFO - 2023-10-20 05:49:19 --> Loader Class Initialized
INFO - 2023-10-20 05:49:19 --> Helper loaded: url_helper
INFO - 2023-10-20 05:49:19 --> Helper loaded: file_helper
INFO - 2023-10-20 05:49:19 --> Helper loaded: html_helper
INFO - 2023-10-20 05:49:19 --> Helper loaded: text_helper
INFO - 2023-10-20 05:49:19 --> Helper loaded: form_helper
INFO - 2023-10-20 05:49:19 --> Helper loaded: lang_helper
INFO - 2023-10-20 05:49:19 --> Helper loaded: security_helper
INFO - 2023-10-20 05:49:19 --> Helper loaded: cookie_helper
INFO - 2023-10-20 05:49:19 --> Database Driver Class Initialized
INFO - 2023-10-20 05:49:19 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-20 05:49:19 --> Parser Class Initialized
INFO - 2023-10-20 05:49:19 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-20 05:49:19 --> Pagination Class Initialized
INFO - 2023-10-20 05:49:19 --> Form Validation Class Initialized
INFO - 2023-10-20 05:49:19 --> Controller Class Initialized
INFO - 2023-10-20 05:49:19 --> Model Class Initialized
DEBUG - 2023-10-20 05:49:19 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-10-20 05:49:19 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-20 05:49:19 --> Model Class Initialized
DEBUG - 2023-10-20 05:49:19 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-20 05:49:19 --> Model Class Initialized
INFO - 2023-10-20 05:49:20 --> Final output sent to browser
DEBUG - 2023-10-20 05:49:20 --> Total execution time: 0.1494
ERROR - 2023-10-20 05:49:20 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-20 05:49:20 --> Config Class Initialized
INFO - 2023-10-20 05:49:20 --> Hooks Class Initialized
DEBUG - 2023-10-20 05:49:20 --> UTF-8 Support Enabled
INFO - 2023-10-20 05:49:20 --> Utf8 Class Initialized
INFO - 2023-10-20 05:49:20 --> URI Class Initialized
INFO - 2023-10-20 05:49:20 --> Router Class Initialized
INFO - 2023-10-20 05:49:20 --> Output Class Initialized
INFO - 2023-10-20 05:49:20 --> Security Class Initialized
DEBUG - 2023-10-20 05:49:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-20 05:49:20 --> Input Class Initialized
INFO - 2023-10-20 05:49:20 --> Language Class Initialized
INFO - 2023-10-20 05:49:20 --> Loader Class Initialized
INFO - 2023-10-20 05:49:20 --> Helper loaded: url_helper
INFO - 2023-10-20 05:49:20 --> Helper loaded: file_helper
INFO - 2023-10-20 05:49:20 --> Helper loaded: html_helper
INFO - 2023-10-20 05:49:20 --> Helper loaded: text_helper
INFO - 2023-10-20 05:49:20 --> Helper loaded: form_helper
INFO - 2023-10-20 05:49:20 --> Helper loaded: lang_helper
INFO - 2023-10-20 05:49:20 --> Helper loaded: security_helper
INFO - 2023-10-20 05:49:20 --> Helper loaded: cookie_helper
INFO - 2023-10-20 05:49:20 --> Database Driver Class Initialized
INFO - 2023-10-20 05:49:20 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-20 05:49:20 --> Parser Class Initialized
INFO - 2023-10-20 05:49:20 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-20 05:49:20 --> Pagination Class Initialized
INFO - 2023-10-20 05:49:20 --> Form Validation Class Initialized
INFO - 2023-10-20 05:49:20 --> Controller Class Initialized
INFO - 2023-10-20 05:49:20 --> Model Class Initialized
DEBUG - 2023-10-20 05:49:20 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-10-20 05:49:20 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-20 05:49:20 --> Model Class Initialized
DEBUG - 2023-10-20 05:49:20 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-20 05:49:20 --> Model Class Initialized
INFO - 2023-10-20 05:49:20 --> Final output sent to browser
DEBUG - 2023-10-20 05:49:20 --> Total execution time: 0.1439
ERROR - 2023-10-20 05:49:20 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-20 05:49:20 --> Config Class Initialized
INFO - 2023-10-20 05:49:20 --> Hooks Class Initialized
DEBUG - 2023-10-20 05:49:20 --> UTF-8 Support Enabled
INFO - 2023-10-20 05:49:20 --> Utf8 Class Initialized
INFO - 2023-10-20 05:49:20 --> URI Class Initialized
INFO - 2023-10-20 05:49:20 --> Router Class Initialized
INFO - 2023-10-20 05:49:20 --> Output Class Initialized
INFO - 2023-10-20 05:49:20 --> Security Class Initialized
DEBUG - 2023-10-20 05:49:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-20 05:49:20 --> Input Class Initialized
INFO - 2023-10-20 05:49:20 --> Language Class Initialized
INFO - 2023-10-20 05:49:20 --> Loader Class Initialized
INFO - 2023-10-20 05:49:20 --> Helper loaded: url_helper
INFO - 2023-10-20 05:49:20 --> Helper loaded: file_helper
INFO - 2023-10-20 05:49:20 --> Helper loaded: html_helper
INFO - 2023-10-20 05:49:20 --> Helper loaded: text_helper
INFO - 2023-10-20 05:49:20 --> Helper loaded: form_helper
INFO - 2023-10-20 05:49:20 --> Helper loaded: lang_helper
INFO - 2023-10-20 05:49:20 --> Helper loaded: security_helper
INFO - 2023-10-20 05:49:20 --> Helper loaded: cookie_helper
INFO - 2023-10-20 05:49:20 --> Database Driver Class Initialized
INFO - 2023-10-20 05:49:20 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-20 05:49:20 --> Parser Class Initialized
INFO - 2023-10-20 05:49:20 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-20 05:49:20 --> Pagination Class Initialized
INFO - 2023-10-20 05:49:20 --> Form Validation Class Initialized
INFO - 2023-10-20 05:49:20 --> Controller Class Initialized
INFO - 2023-10-20 05:49:20 --> Model Class Initialized
DEBUG - 2023-10-20 05:49:20 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-10-20 05:49:20 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-20 05:49:20 --> Model Class Initialized
DEBUG - 2023-10-20 05:49:20 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-20 05:49:20 --> Model Class Initialized
INFO - 2023-10-20 05:49:21 --> Final output sent to browser
DEBUG - 2023-10-20 05:49:21 --> Total execution time: 0.1600
ERROR - 2023-10-20 05:49:22 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-20 05:49:22 --> Config Class Initialized
INFO - 2023-10-20 05:49:22 --> Hooks Class Initialized
DEBUG - 2023-10-20 05:49:22 --> UTF-8 Support Enabled
INFO - 2023-10-20 05:49:22 --> Utf8 Class Initialized
INFO - 2023-10-20 05:49:22 --> URI Class Initialized
INFO - 2023-10-20 05:49:22 --> Router Class Initialized
INFO - 2023-10-20 05:49:22 --> Output Class Initialized
INFO - 2023-10-20 05:49:22 --> Security Class Initialized
DEBUG - 2023-10-20 05:49:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-20 05:49:22 --> Input Class Initialized
INFO - 2023-10-20 05:49:22 --> Language Class Initialized
INFO - 2023-10-20 05:49:22 --> Loader Class Initialized
INFO - 2023-10-20 05:49:22 --> Helper loaded: url_helper
INFO - 2023-10-20 05:49:22 --> Helper loaded: file_helper
INFO - 2023-10-20 05:49:22 --> Helper loaded: html_helper
INFO - 2023-10-20 05:49:22 --> Helper loaded: text_helper
INFO - 2023-10-20 05:49:22 --> Helper loaded: form_helper
INFO - 2023-10-20 05:49:22 --> Helper loaded: lang_helper
INFO - 2023-10-20 05:49:22 --> Helper loaded: security_helper
INFO - 2023-10-20 05:49:22 --> Helper loaded: cookie_helper
INFO - 2023-10-20 05:49:22 --> Database Driver Class Initialized
INFO - 2023-10-20 05:49:22 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-20 05:49:22 --> Parser Class Initialized
INFO - 2023-10-20 05:49:22 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-20 05:49:22 --> Pagination Class Initialized
INFO - 2023-10-20 05:49:22 --> Form Validation Class Initialized
INFO - 2023-10-20 05:49:22 --> Controller Class Initialized
INFO - 2023-10-20 05:49:22 --> Model Class Initialized
DEBUG - 2023-10-20 05:49:22 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-10-20 05:49:22 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-20 05:49:22 --> Model Class Initialized
DEBUG - 2023-10-20 05:49:22 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-20 05:49:22 --> Model Class Initialized
INFO - 2023-10-20 05:49:22 --> Final output sent to browser
DEBUG - 2023-10-20 05:49:22 --> Total execution time: 0.0223
ERROR - 2023-10-20 05:49:23 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-20 05:49:23 --> Config Class Initialized
INFO - 2023-10-20 05:49:23 --> Hooks Class Initialized
DEBUG - 2023-10-20 05:49:23 --> UTF-8 Support Enabled
INFO - 2023-10-20 05:49:23 --> Utf8 Class Initialized
INFO - 2023-10-20 05:49:23 --> URI Class Initialized
INFO - 2023-10-20 05:49:23 --> Router Class Initialized
INFO - 2023-10-20 05:49:23 --> Output Class Initialized
INFO - 2023-10-20 05:49:23 --> Security Class Initialized
DEBUG - 2023-10-20 05:49:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-20 05:49:23 --> Input Class Initialized
INFO - 2023-10-20 05:49:23 --> Language Class Initialized
INFO - 2023-10-20 05:49:23 --> Loader Class Initialized
INFO - 2023-10-20 05:49:23 --> Helper loaded: url_helper
INFO - 2023-10-20 05:49:23 --> Helper loaded: file_helper
INFO - 2023-10-20 05:49:23 --> Helper loaded: html_helper
INFO - 2023-10-20 05:49:23 --> Helper loaded: text_helper
INFO - 2023-10-20 05:49:23 --> Helper loaded: form_helper
INFO - 2023-10-20 05:49:23 --> Helper loaded: lang_helper
INFO - 2023-10-20 05:49:23 --> Helper loaded: security_helper
INFO - 2023-10-20 05:49:23 --> Helper loaded: cookie_helper
INFO - 2023-10-20 05:49:23 --> Database Driver Class Initialized
INFO - 2023-10-20 05:49:23 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-20 05:49:23 --> Parser Class Initialized
INFO - 2023-10-20 05:49:23 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-20 05:49:23 --> Pagination Class Initialized
INFO - 2023-10-20 05:49:23 --> Form Validation Class Initialized
INFO - 2023-10-20 05:49:23 --> Controller Class Initialized
INFO - 2023-10-20 05:49:23 --> Model Class Initialized
DEBUG - 2023-10-20 05:49:23 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-10-20 05:49:23 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-20 05:49:23 --> Model Class Initialized
INFO - 2023-10-20 05:49:23 --> Model Class Initialized
INFO - 2023-10-20 05:49:23 --> Final output sent to browser
DEBUG - 2023-10-20 05:49:23 --> Total execution time: 0.0226
ERROR - 2023-10-20 05:49:25 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-20 05:49:25 --> Config Class Initialized
INFO - 2023-10-20 05:49:25 --> Hooks Class Initialized
DEBUG - 2023-10-20 05:49:25 --> UTF-8 Support Enabled
INFO - 2023-10-20 05:49:25 --> Utf8 Class Initialized
INFO - 2023-10-20 05:49:25 --> URI Class Initialized
INFO - 2023-10-20 05:49:25 --> Router Class Initialized
INFO - 2023-10-20 05:49:25 --> Output Class Initialized
INFO - 2023-10-20 05:49:25 --> Security Class Initialized
DEBUG - 2023-10-20 05:49:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-20 05:49:25 --> Input Class Initialized
INFO - 2023-10-20 05:49:25 --> Language Class Initialized
INFO - 2023-10-20 05:49:25 --> Loader Class Initialized
INFO - 2023-10-20 05:49:25 --> Helper loaded: url_helper
INFO - 2023-10-20 05:49:25 --> Helper loaded: file_helper
INFO - 2023-10-20 05:49:25 --> Helper loaded: html_helper
INFO - 2023-10-20 05:49:25 --> Helper loaded: text_helper
INFO - 2023-10-20 05:49:25 --> Helper loaded: form_helper
INFO - 2023-10-20 05:49:25 --> Helper loaded: lang_helper
INFO - 2023-10-20 05:49:25 --> Helper loaded: security_helper
INFO - 2023-10-20 05:49:25 --> Helper loaded: cookie_helper
INFO - 2023-10-20 05:49:25 --> Database Driver Class Initialized
INFO - 2023-10-20 05:49:25 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-20 05:49:25 --> Parser Class Initialized
INFO - 2023-10-20 05:49:25 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-20 05:49:25 --> Pagination Class Initialized
INFO - 2023-10-20 05:49:25 --> Form Validation Class Initialized
INFO - 2023-10-20 05:49:25 --> Controller Class Initialized
INFO - 2023-10-20 05:49:25 --> Model Class Initialized
DEBUG - 2023-10-20 05:49:25 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-10-20 05:49:25 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-20 05:49:25 --> Model Class Initialized
INFO - 2023-10-20 05:49:25 --> Final output sent to browser
DEBUG - 2023-10-20 05:49:25 --> Total execution time: 0.0191
ERROR - 2023-10-20 05:49:42 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-20 05:49:42 --> Config Class Initialized
INFO - 2023-10-20 05:49:42 --> Hooks Class Initialized
DEBUG - 2023-10-20 05:49:42 --> UTF-8 Support Enabled
INFO - 2023-10-20 05:49:42 --> Utf8 Class Initialized
INFO - 2023-10-20 05:49:42 --> URI Class Initialized
INFO - 2023-10-20 05:49:42 --> Router Class Initialized
INFO - 2023-10-20 05:49:42 --> Output Class Initialized
INFO - 2023-10-20 05:49:42 --> Security Class Initialized
DEBUG - 2023-10-20 05:49:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-20 05:49:42 --> Input Class Initialized
INFO - 2023-10-20 05:49:42 --> Language Class Initialized
INFO - 2023-10-20 05:49:42 --> Loader Class Initialized
INFO - 2023-10-20 05:49:42 --> Helper loaded: url_helper
INFO - 2023-10-20 05:49:42 --> Helper loaded: file_helper
INFO - 2023-10-20 05:49:42 --> Helper loaded: html_helper
INFO - 2023-10-20 05:49:42 --> Helper loaded: text_helper
INFO - 2023-10-20 05:49:42 --> Helper loaded: form_helper
INFO - 2023-10-20 05:49:42 --> Helper loaded: lang_helper
INFO - 2023-10-20 05:49:42 --> Helper loaded: security_helper
INFO - 2023-10-20 05:49:42 --> Helper loaded: cookie_helper
INFO - 2023-10-20 05:49:42 --> Database Driver Class Initialized
INFO - 2023-10-20 05:49:42 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-20 05:49:42 --> Parser Class Initialized
INFO - 2023-10-20 05:49:42 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-20 05:49:42 --> Pagination Class Initialized
INFO - 2023-10-20 05:49:42 --> Form Validation Class Initialized
INFO - 2023-10-20 05:49:42 --> Controller Class Initialized
INFO - 2023-10-20 05:49:42 --> Model Class Initialized
DEBUG - 2023-10-20 05:49:42 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-10-20 05:49:42 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-20 05:49:42 --> Model Class Initialized
DEBUG - 2023-10-20 05:49:42 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-20 05:49:42 --> Model Class Initialized
INFO - 2023-10-20 05:49:42 --> Final output sent to browser
DEBUG - 2023-10-20 05:49:42 --> Total execution time: 0.1499
ERROR - 2023-10-20 05:49:43 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-20 05:49:43 --> Config Class Initialized
INFO - 2023-10-20 05:49:43 --> Hooks Class Initialized
DEBUG - 2023-10-20 05:49:43 --> UTF-8 Support Enabled
INFO - 2023-10-20 05:49:43 --> Utf8 Class Initialized
INFO - 2023-10-20 05:49:43 --> URI Class Initialized
INFO - 2023-10-20 05:49:43 --> Router Class Initialized
INFO - 2023-10-20 05:49:43 --> Output Class Initialized
INFO - 2023-10-20 05:49:43 --> Security Class Initialized
DEBUG - 2023-10-20 05:49:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-20 05:49:43 --> Input Class Initialized
INFO - 2023-10-20 05:49:43 --> Language Class Initialized
INFO - 2023-10-20 05:49:43 --> Loader Class Initialized
INFO - 2023-10-20 05:49:43 --> Helper loaded: url_helper
INFO - 2023-10-20 05:49:43 --> Helper loaded: file_helper
INFO - 2023-10-20 05:49:43 --> Helper loaded: html_helper
INFO - 2023-10-20 05:49:43 --> Helper loaded: text_helper
INFO - 2023-10-20 05:49:43 --> Helper loaded: form_helper
INFO - 2023-10-20 05:49:43 --> Helper loaded: lang_helper
INFO - 2023-10-20 05:49:43 --> Helper loaded: security_helper
INFO - 2023-10-20 05:49:43 --> Helper loaded: cookie_helper
INFO - 2023-10-20 05:49:43 --> Database Driver Class Initialized
INFO - 2023-10-20 05:49:43 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-20 05:49:43 --> Parser Class Initialized
INFO - 2023-10-20 05:49:43 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-20 05:49:43 --> Pagination Class Initialized
INFO - 2023-10-20 05:49:43 --> Form Validation Class Initialized
INFO - 2023-10-20 05:49:43 --> Controller Class Initialized
INFO - 2023-10-20 05:49:43 --> Model Class Initialized
DEBUG - 2023-10-20 05:49:43 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-10-20 05:49:43 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-20 05:49:43 --> Model Class Initialized
DEBUG - 2023-10-20 05:49:43 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-20 05:49:43 --> Model Class Initialized
INFO - 2023-10-20 05:49:43 --> Final output sent to browser
DEBUG - 2023-10-20 05:49:43 --> Total execution time: 0.1505
ERROR - 2023-10-20 05:49:43 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-20 05:49:43 --> Config Class Initialized
INFO - 2023-10-20 05:49:43 --> Hooks Class Initialized
DEBUG - 2023-10-20 05:49:43 --> UTF-8 Support Enabled
INFO - 2023-10-20 05:49:43 --> Utf8 Class Initialized
INFO - 2023-10-20 05:49:43 --> URI Class Initialized
INFO - 2023-10-20 05:49:43 --> Router Class Initialized
INFO - 2023-10-20 05:49:43 --> Output Class Initialized
INFO - 2023-10-20 05:49:43 --> Security Class Initialized
DEBUG - 2023-10-20 05:49:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-20 05:49:43 --> Input Class Initialized
INFO - 2023-10-20 05:49:43 --> Language Class Initialized
INFO - 2023-10-20 05:49:43 --> Loader Class Initialized
INFO - 2023-10-20 05:49:43 --> Helper loaded: url_helper
INFO - 2023-10-20 05:49:43 --> Helper loaded: file_helper
INFO - 2023-10-20 05:49:43 --> Helper loaded: html_helper
INFO - 2023-10-20 05:49:43 --> Helper loaded: text_helper
INFO - 2023-10-20 05:49:43 --> Helper loaded: form_helper
INFO - 2023-10-20 05:49:43 --> Helper loaded: lang_helper
INFO - 2023-10-20 05:49:43 --> Helper loaded: security_helper
INFO - 2023-10-20 05:49:43 --> Helper loaded: cookie_helper
INFO - 2023-10-20 05:49:43 --> Database Driver Class Initialized
INFO - 2023-10-20 05:49:43 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-20 05:49:43 --> Parser Class Initialized
INFO - 2023-10-20 05:49:43 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-20 05:49:43 --> Pagination Class Initialized
INFO - 2023-10-20 05:49:43 --> Form Validation Class Initialized
INFO - 2023-10-20 05:49:43 --> Controller Class Initialized
INFO - 2023-10-20 05:49:43 --> Model Class Initialized
DEBUG - 2023-10-20 05:49:43 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-10-20 05:49:43 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-20 05:49:43 --> Model Class Initialized
DEBUG - 2023-10-20 05:49:43 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-20 05:49:43 --> Model Class Initialized
INFO - 2023-10-20 05:49:44 --> Final output sent to browser
DEBUG - 2023-10-20 05:49:44 --> Total execution time: 0.1637
ERROR - 2023-10-20 05:49:46 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-20 05:49:46 --> Config Class Initialized
INFO - 2023-10-20 05:49:46 --> Hooks Class Initialized
DEBUG - 2023-10-20 05:49:46 --> UTF-8 Support Enabled
INFO - 2023-10-20 05:49:46 --> Utf8 Class Initialized
INFO - 2023-10-20 05:49:46 --> URI Class Initialized
INFO - 2023-10-20 05:49:46 --> Router Class Initialized
INFO - 2023-10-20 05:49:46 --> Output Class Initialized
INFO - 2023-10-20 05:49:46 --> Security Class Initialized
DEBUG - 2023-10-20 05:49:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-20 05:49:46 --> Input Class Initialized
INFO - 2023-10-20 05:49:46 --> Language Class Initialized
INFO - 2023-10-20 05:49:46 --> Loader Class Initialized
INFO - 2023-10-20 05:49:46 --> Helper loaded: url_helper
INFO - 2023-10-20 05:49:46 --> Helper loaded: file_helper
INFO - 2023-10-20 05:49:46 --> Helper loaded: html_helper
INFO - 2023-10-20 05:49:46 --> Helper loaded: text_helper
INFO - 2023-10-20 05:49:46 --> Helper loaded: form_helper
INFO - 2023-10-20 05:49:46 --> Helper loaded: lang_helper
INFO - 2023-10-20 05:49:46 --> Helper loaded: security_helper
INFO - 2023-10-20 05:49:46 --> Helper loaded: cookie_helper
INFO - 2023-10-20 05:49:46 --> Database Driver Class Initialized
INFO - 2023-10-20 05:49:46 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-20 05:49:46 --> Parser Class Initialized
INFO - 2023-10-20 05:49:46 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-20 05:49:46 --> Pagination Class Initialized
INFO - 2023-10-20 05:49:46 --> Form Validation Class Initialized
INFO - 2023-10-20 05:49:46 --> Controller Class Initialized
INFO - 2023-10-20 05:49:46 --> Model Class Initialized
DEBUG - 2023-10-20 05:49:46 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-10-20 05:49:46 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-20 05:49:46 --> Model Class Initialized
DEBUG - 2023-10-20 05:49:46 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-20 05:49:46 --> Model Class Initialized
INFO - 2023-10-20 05:49:46 --> Final output sent to browser
DEBUG - 2023-10-20 05:49:46 --> Total execution time: 0.0509
ERROR - 2023-10-20 05:49:51 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-20 05:49:51 --> Config Class Initialized
INFO - 2023-10-20 05:49:51 --> Hooks Class Initialized
DEBUG - 2023-10-20 05:49:51 --> UTF-8 Support Enabled
INFO - 2023-10-20 05:49:51 --> Utf8 Class Initialized
INFO - 2023-10-20 05:49:51 --> URI Class Initialized
INFO - 2023-10-20 05:49:51 --> Router Class Initialized
INFO - 2023-10-20 05:49:51 --> Output Class Initialized
INFO - 2023-10-20 05:49:51 --> Security Class Initialized
DEBUG - 2023-10-20 05:49:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-20 05:49:51 --> Input Class Initialized
INFO - 2023-10-20 05:49:51 --> Language Class Initialized
INFO - 2023-10-20 05:49:51 --> Loader Class Initialized
INFO - 2023-10-20 05:49:51 --> Helper loaded: url_helper
INFO - 2023-10-20 05:49:51 --> Helper loaded: file_helper
INFO - 2023-10-20 05:49:51 --> Helper loaded: html_helper
INFO - 2023-10-20 05:49:51 --> Helper loaded: text_helper
INFO - 2023-10-20 05:49:51 --> Helper loaded: form_helper
INFO - 2023-10-20 05:49:51 --> Helper loaded: lang_helper
INFO - 2023-10-20 05:49:51 --> Helper loaded: security_helper
INFO - 2023-10-20 05:49:51 --> Helper loaded: cookie_helper
INFO - 2023-10-20 05:49:51 --> Database Driver Class Initialized
INFO - 2023-10-20 05:49:51 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-20 05:49:51 --> Parser Class Initialized
INFO - 2023-10-20 05:49:51 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-20 05:49:51 --> Pagination Class Initialized
INFO - 2023-10-20 05:49:51 --> Form Validation Class Initialized
INFO - 2023-10-20 05:49:51 --> Controller Class Initialized
INFO - 2023-10-20 05:49:51 --> Model Class Initialized
DEBUG - 2023-10-20 05:49:51 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-10-20 05:49:51 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-20 05:49:51 --> Model Class Initialized
INFO - 2023-10-20 05:49:51 --> Model Class Initialized
INFO - 2023-10-20 05:49:51 --> Final output sent to browser
DEBUG - 2023-10-20 05:49:51 --> Total execution time: 0.0196
ERROR - 2023-10-20 05:49:52 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-20 05:49:52 --> Config Class Initialized
INFO - 2023-10-20 05:49:52 --> Hooks Class Initialized
DEBUG - 2023-10-20 05:49:52 --> UTF-8 Support Enabled
INFO - 2023-10-20 05:49:52 --> Utf8 Class Initialized
INFO - 2023-10-20 05:49:52 --> URI Class Initialized
INFO - 2023-10-20 05:49:52 --> Router Class Initialized
INFO - 2023-10-20 05:49:52 --> Output Class Initialized
INFO - 2023-10-20 05:49:52 --> Security Class Initialized
DEBUG - 2023-10-20 05:49:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-20 05:49:52 --> Input Class Initialized
INFO - 2023-10-20 05:49:52 --> Language Class Initialized
INFO - 2023-10-20 05:49:52 --> Loader Class Initialized
INFO - 2023-10-20 05:49:52 --> Helper loaded: url_helper
INFO - 2023-10-20 05:49:52 --> Helper loaded: file_helper
INFO - 2023-10-20 05:49:52 --> Helper loaded: html_helper
INFO - 2023-10-20 05:49:52 --> Helper loaded: text_helper
INFO - 2023-10-20 05:49:52 --> Helper loaded: form_helper
INFO - 2023-10-20 05:49:52 --> Helper loaded: lang_helper
INFO - 2023-10-20 05:49:52 --> Helper loaded: security_helper
INFO - 2023-10-20 05:49:52 --> Helper loaded: cookie_helper
INFO - 2023-10-20 05:49:52 --> Database Driver Class Initialized
INFO - 2023-10-20 05:49:52 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-20 05:49:52 --> Parser Class Initialized
INFO - 2023-10-20 05:49:52 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-20 05:49:52 --> Pagination Class Initialized
INFO - 2023-10-20 05:49:52 --> Form Validation Class Initialized
INFO - 2023-10-20 05:49:52 --> Controller Class Initialized
INFO - 2023-10-20 05:49:52 --> Model Class Initialized
DEBUG - 2023-10-20 05:49:52 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-10-20 05:49:52 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-20 05:49:52 --> Model Class Initialized
INFO - 2023-10-20 05:49:52 --> Final output sent to browser
DEBUG - 2023-10-20 05:49:52 --> Total execution time: 0.0196
ERROR - 2023-10-20 05:50:03 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-20 05:50:03 --> Config Class Initialized
INFO - 2023-10-20 05:50:03 --> Hooks Class Initialized
DEBUG - 2023-10-20 05:50:03 --> UTF-8 Support Enabled
INFO - 2023-10-20 05:50:03 --> Utf8 Class Initialized
INFO - 2023-10-20 05:50:03 --> URI Class Initialized
INFO - 2023-10-20 05:50:03 --> Router Class Initialized
INFO - 2023-10-20 05:50:03 --> Output Class Initialized
INFO - 2023-10-20 05:50:03 --> Security Class Initialized
DEBUG - 2023-10-20 05:50:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-20 05:50:03 --> Input Class Initialized
INFO - 2023-10-20 05:50:03 --> Language Class Initialized
INFO - 2023-10-20 05:50:03 --> Loader Class Initialized
INFO - 2023-10-20 05:50:03 --> Helper loaded: url_helper
INFO - 2023-10-20 05:50:03 --> Helper loaded: file_helper
INFO - 2023-10-20 05:50:03 --> Helper loaded: html_helper
INFO - 2023-10-20 05:50:03 --> Helper loaded: text_helper
INFO - 2023-10-20 05:50:03 --> Helper loaded: form_helper
INFO - 2023-10-20 05:50:03 --> Helper loaded: lang_helper
INFO - 2023-10-20 05:50:03 --> Helper loaded: security_helper
INFO - 2023-10-20 05:50:03 --> Helper loaded: cookie_helper
INFO - 2023-10-20 05:50:03 --> Database Driver Class Initialized
INFO - 2023-10-20 05:50:03 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-20 05:50:03 --> Parser Class Initialized
INFO - 2023-10-20 05:50:03 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-20 05:50:03 --> Pagination Class Initialized
INFO - 2023-10-20 05:50:03 --> Form Validation Class Initialized
INFO - 2023-10-20 05:50:03 --> Controller Class Initialized
INFO - 2023-10-20 05:50:03 --> Model Class Initialized
DEBUG - 2023-10-20 05:50:03 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-10-20 05:50:03 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-20 05:50:03 --> Model Class Initialized
DEBUG - 2023-10-20 05:50:03 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-20 05:50:03 --> Model Class Initialized
INFO - 2023-10-20 05:50:03 --> Final output sent to browser
DEBUG - 2023-10-20 05:50:03 --> Total execution time: 0.1609
ERROR - 2023-10-20 05:50:04 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-20 05:50:04 --> Config Class Initialized
INFO - 2023-10-20 05:50:04 --> Hooks Class Initialized
DEBUG - 2023-10-20 05:50:04 --> UTF-8 Support Enabled
INFO - 2023-10-20 05:50:04 --> Utf8 Class Initialized
INFO - 2023-10-20 05:50:04 --> URI Class Initialized
INFO - 2023-10-20 05:50:04 --> Router Class Initialized
INFO - 2023-10-20 05:50:04 --> Output Class Initialized
INFO - 2023-10-20 05:50:04 --> Security Class Initialized
DEBUG - 2023-10-20 05:50:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-20 05:50:04 --> Input Class Initialized
INFO - 2023-10-20 05:50:04 --> Language Class Initialized
INFO - 2023-10-20 05:50:04 --> Loader Class Initialized
INFO - 2023-10-20 05:50:04 --> Helper loaded: url_helper
INFO - 2023-10-20 05:50:04 --> Helper loaded: file_helper
INFO - 2023-10-20 05:50:04 --> Helper loaded: html_helper
INFO - 2023-10-20 05:50:04 --> Helper loaded: text_helper
INFO - 2023-10-20 05:50:04 --> Helper loaded: form_helper
INFO - 2023-10-20 05:50:04 --> Helper loaded: lang_helper
INFO - 2023-10-20 05:50:04 --> Helper loaded: security_helper
INFO - 2023-10-20 05:50:04 --> Helper loaded: cookie_helper
INFO - 2023-10-20 05:50:04 --> Database Driver Class Initialized
INFO - 2023-10-20 05:50:04 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-20 05:50:04 --> Parser Class Initialized
INFO - 2023-10-20 05:50:04 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-20 05:50:04 --> Pagination Class Initialized
INFO - 2023-10-20 05:50:04 --> Form Validation Class Initialized
INFO - 2023-10-20 05:50:04 --> Controller Class Initialized
INFO - 2023-10-20 05:50:04 --> Model Class Initialized
DEBUG - 2023-10-20 05:50:04 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-10-20 05:50:04 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-20 05:50:04 --> Model Class Initialized
DEBUG - 2023-10-20 05:50:04 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-20 05:50:04 --> Model Class Initialized
INFO - 2023-10-20 05:50:04 --> Final output sent to browser
DEBUG - 2023-10-20 05:50:04 --> Total execution time: 0.1448
ERROR - 2023-10-20 05:50:04 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-20 05:50:04 --> Config Class Initialized
INFO - 2023-10-20 05:50:04 --> Hooks Class Initialized
DEBUG - 2023-10-20 05:50:04 --> UTF-8 Support Enabled
INFO - 2023-10-20 05:50:04 --> Utf8 Class Initialized
INFO - 2023-10-20 05:50:04 --> URI Class Initialized
INFO - 2023-10-20 05:50:04 --> Router Class Initialized
INFO - 2023-10-20 05:50:04 --> Output Class Initialized
INFO - 2023-10-20 05:50:04 --> Security Class Initialized
DEBUG - 2023-10-20 05:50:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-20 05:50:04 --> Input Class Initialized
INFO - 2023-10-20 05:50:04 --> Language Class Initialized
INFO - 2023-10-20 05:50:04 --> Loader Class Initialized
INFO - 2023-10-20 05:50:04 --> Helper loaded: url_helper
INFO - 2023-10-20 05:50:04 --> Helper loaded: file_helper
INFO - 2023-10-20 05:50:04 --> Helper loaded: html_helper
INFO - 2023-10-20 05:50:04 --> Helper loaded: text_helper
INFO - 2023-10-20 05:50:04 --> Helper loaded: form_helper
INFO - 2023-10-20 05:50:04 --> Helper loaded: lang_helper
INFO - 2023-10-20 05:50:04 --> Helper loaded: security_helper
INFO - 2023-10-20 05:50:04 --> Helper loaded: cookie_helper
INFO - 2023-10-20 05:50:04 --> Database Driver Class Initialized
INFO - 2023-10-20 05:50:04 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-20 05:50:04 --> Parser Class Initialized
INFO - 2023-10-20 05:50:04 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-20 05:50:04 --> Pagination Class Initialized
INFO - 2023-10-20 05:50:04 --> Form Validation Class Initialized
INFO - 2023-10-20 05:50:04 --> Controller Class Initialized
INFO - 2023-10-20 05:50:04 --> Model Class Initialized
DEBUG - 2023-10-20 05:50:04 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-10-20 05:50:04 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-20 05:50:04 --> Model Class Initialized
DEBUG - 2023-10-20 05:50:04 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-20 05:50:04 --> Model Class Initialized
INFO - 2023-10-20 05:50:04 --> Final output sent to browser
DEBUG - 2023-10-20 05:50:04 --> Total execution time: 0.0199
ERROR - 2023-10-20 05:50:05 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-20 05:50:05 --> Config Class Initialized
INFO - 2023-10-20 05:50:05 --> Hooks Class Initialized
DEBUG - 2023-10-20 05:50:05 --> UTF-8 Support Enabled
INFO - 2023-10-20 05:50:05 --> Utf8 Class Initialized
INFO - 2023-10-20 05:50:05 --> URI Class Initialized
INFO - 2023-10-20 05:50:05 --> Router Class Initialized
INFO - 2023-10-20 05:50:05 --> Output Class Initialized
INFO - 2023-10-20 05:50:05 --> Security Class Initialized
DEBUG - 2023-10-20 05:50:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-20 05:50:05 --> Input Class Initialized
INFO - 2023-10-20 05:50:05 --> Language Class Initialized
INFO - 2023-10-20 05:50:05 --> Loader Class Initialized
INFO - 2023-10-20 05:50:05 --> Helper loaded: url_helper
INFO - 2023-10-20 05:50:05 --> Helper loaded: file_helper
INFO - 2023-10-20 05:50:05 --> Helper loaded: html_helper
INFO - 2023-10-20 05:50:05 --> Helper loaded: text_helper
INFO - 2023-10-20 05:50:05 --> Helper loaded: form_helper
INFO - 2023-10-20 05:50:05 --> Helper loaded: lang_helper
INFO - 2023-10-20 05:50:05 --> Helper loaded: security_helper
INFO - 2023-10-20 05:50:05 --> Helper loaded: cookie_helper
INFO - 2023-10-20 05:50:05 --> Database Driver Class Initialized
INFO - 2023-10-20 05:50:05 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-20 05:50:05 --> Parser Class Initialized
INFO - 2023-10-20 05:50:05 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-20 05:50:05 --> Pagination Class Initialized
INFO - 2023-10-20 05:50:05 --> Form Validation Class Initialized
INFO - 2023-10-20 05:50:05 --> Controller Class Initialized
INFO - 2023-10-20 05:50:05 --> Model Class Initialized
DEBUG - 2023-10-20 05:50:05 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-10-20 05:50:05 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-20 05:50:05 --> Model Class Initialized
DEBUG - 2023-10-20 05:50:05 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-20 05:50:05 --> Model Class Initialized
INFO - 2023-10-20 05:50:05 --> Final output sent to browser
DEBUG - 2023-10-20 05:50:05 --> Total execution time: 0.1548
ERROR - 2023-10-20 05:50:06 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-20 05:50:06 --> Config Class Initialized
INFO - 2023-10-20 05:50:06 --> Hooks Class Initialized
DEBUG - 2023-10-20 05:50:06 --> UTF-8 Support Enabled
INFO - 2023-10-20 05:50:06 --> Utf8 Class Initialized
INFO - 2023-10-20 05:50:06 --> URI Class Initialized
INFO - 2023-10-20 05:50:06 --> Router Class Initialized
INFO - 2023-10-20 05:50:06 --> Output Class Initialized
INFO - 2023-10-20 05:50:06 --> Security Class Initialized
DEBUG - 2023-10-20 05:50:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-20 05:50:06 --> Input Class Initialized
INFO - 2023-10-20 05:50:06 --> Language Class Initialized
INFO - 2023-10-20 05:50:06 --> Loader Class Initialized
INFO - 2023-10-20 05:50:06 --> Helper loaded: url_helper
INFO - 2023-10-20 05:50:06 --> Helper loaded: file_helper
INFO - 2023-10-20 05:50:06 --> Helper loaded: html_helper
INFO - 2023-10-20 05:50:06 --> Helper loaded: text_helper
INFO - 2023-10-20 05:50:06 --> Helper loaded: form_helper
INFO - 2023-10-20 05:50:06 --> Helper loaded: lang_helper
INFO - 2023-10-20 05:50:06 --> Helper loaded: security_helper
INFO - 2023-10-20 05:50:06 --> Helper loaded: cookie_helper
INFO - 2023-10-20 05:50:06 --> Database Driver Class Initialized
INFO - 2023-10-20 05:50:06 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-20 05:50:06 --> Parser Class Initialized
INFO - 2023-10-20 05:50:06 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-20 05:50:06 --> Pagination Class Initialized
INFO - 2023-10-20 05:50:06 --> Form Validation Class Initialized
INFO - 2023-10-20 05:50:06 --> Controller Class Initialized
INFO - 2023-10-20 05:50:06 --> Model Class Initialized
DEBUG - 2023-10-20 05:50:06 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-10-20 05:50:06 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-20 05:50:06 --> Model Class Initialized
DEBUG - 2023-10-20 05:50:06 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-20 05:50:06 --> Model Class Initialized
INFO - 2023-10-20 05:50:06 --> Final output sent to browser
DEBUG - 2023-10-20 05:50:06 --> Total execution time: 0.0183
ERROR - 2023-10-20 05:50:08 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-20 05:50:08 --> Config Class Initialized
INFO - 2023-10-20 05:50:08 --> Hooks Class Initialized
DEBUG - 2023-10-20 05:50:08 --> UTF-8 Support Enabled
INFO - 2023-10-20 05:50:08 --> Utf8 Class Initialized
INFO - 2023-10-20 05:50:08 --> URI Class Initialized
INFO - 2023-10-20 05:50:08 --> Router Class Initialized
INFO - 2023-10-20 05:50:08 --> Output Class Initialized
INFO - 2023-10-20 05:50:08 --> Security Class Initialized
DEBUG - 2023-10-20 05:50:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-20 05:50:08 --> Input Class Initialized
INFO - 2023-10-20 05:50:08 --> Language Class Initialized
INFO - 2023-10-20 05:50:08 --> Loader Class Initialized
INFO - 2023-10-20 05:50:08 --> Helper loaded: url_helper
INFO - 2023-10-20 05:50:08 --> Helper loaded: file_helper
INFO - 2023-10-20 05:50:08 --> Helper loaded: html_helper
INFO - 2023-10-20 05:50:08 --> Helper loaded: text_helper
INFO - 2023-10-20 05:50:08 --> Helper loaded: form_helper
INFO - 2023-10-20 05:50:08 --> Helper loaded: lang_helper
INFO - 2023-10-20 05:50:08 --> Helper loaded: security_helper
INFO - 2023-10-20 05:50:08 --> Helper loaded: cookie_helper
INFO - 2023-10-20 05:50:08 --> Database Driver Class Initialized
INFO - 2023-10-20 05:50:08 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-20 05:50:08 --> Parser Class Initialized
INFO - 2023-10-20 05:50:08 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-20 05:50:08 --> Pagination Class Initialized
INFO - 2023-10-20 05:50:08 --> Form Validation Class Initialized
INFO - 2023-10-20 05:50:08 --> Controller Class Initialized
INFO - 2023-10-20 05:50:08 --> Model Class Initialized
DEBUG - 2023-10-20 05:50:08 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-10-20 05:50:08 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-20 05:50:08 --> Model Class Initialized
DEBUG - 2023-10-20 05:50:08 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-20 05:50:08 --> Model Class Initialized
INFO - 2023-10-20 05:50:08 --> Final output sent to browser
DEBUG - 2023-10-20 05:50:08 --> Total execution time: 0.1581
ERROR - 2023-10-20 05:50:09 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-20 05:50:09 --> Config Class Initialized
INFO - 2023-10-20 05:50:09 --> Hooks Class Initialized
DEBUG - 2023-10-20 05:50:09 --> UTF-8 Support Enabled
INFO - 2023-10-20 05:50:09 --> Utf8 Class Initialized
INFO - 2023-10-20 05:50:09 --> URI Class Initialized
INFO - 2023-10-20 05:50:09 --> Router Class Initialized
INFO - 2023-10-20 05:50:09 --> Output Class Initialized
INFO - 2023-10-20 05:50:09 --> Security Class Initialized
DEBUG - 2023-10-20 05:50:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-20 05:50:09 --> Input Class Initialized
INFO - 2023-10-20 05:50:09 --> Language Class Initialized
INFO - 2023-10-20 05:50:09 --> Loader Class Initialized
INFO - 2023-10-20 05:50:09 --> Helper loaded: url_helper
INFO - 2023-10-20 05:50:09 --> Helper loaded: file_helper
INFO - 2023-10-20 05:50:09 --> Helper loaded: html_helper
INFO - 2023-10-20 05:50:09 --> Helper loaded: text_helper
INFO - 2023-10-20 05:50:09 --> Helper loaded: form_helper
INFO - 2023-10-20 05:50:09 --> Helper loaded: lang_helper
INFO - 2023-10-20 05:50:09 --> Helper loaded: security_helper
INFO - 2023-10-20 05:50:09 --> Helper loaded: cookie_helper
INFO - 2023-10-20 05:50:09 --> Database Driver Class Initialized
INFO - 2023-10-20 05:50:09 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-20 05:50:09 --> Parser Class Initialized
INFO - 2023-10-20 05:50:09 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-20 05:50:09 --> Pagination Class Initialized
INFO - 2023-10-20 05:50:09 --> Form Validation Class Initialized
INFO - 2023-10-20 05:50:09 --> Controller Class Initialized
INFO - 2023-10-20 05:50:09 --> Model Class Initialized
DEBUG - 2023-10-20 05:50:09 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-10-20 05:50:09 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-20 05:50:09 --> Model Class Initialized
DEBUG - 2023-10-20 05:50:09 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-20 05:50:09 --> Model Class Initialized
INFO - 2023-10-20 05:50:09 --> Final output sent to browser
DEBUG - 2023-10-20 05:50:09 --> Total execution time: 0.1432
ERROR - 2023-10-20 05:50:39 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-20 05:50:39 --> Config Class Initialized
INFO - 2023-10-20 05:50:39 --> Hooks Class Initialized
DEBUG - 2023-10-20 05:50:39 --> UTF-8 Support Enabled
INFO - 2023-10-20 05:50:39 --> Utf8 Class Initialized
INFO - 2023-10-20 05:50:39 --> URI Class Initialized
INFO - 2023-10-20 05:50:39 --> Router Class Initialized
INFO - 2023-10-20 05:50:39 --> Output Class Initialized
INFO - 2023-10-20 05:50:39 --> Security Class Initialized
DEBUG - 2023-10-20 05:50:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-20 05:50:39 --> Input Class Initialized
INFO - 2023-10-20 05:50:39 --> Language Class Initialized
INFO - 2023-10-20 05:50:39 --> Loader Class Initialized
INFO - 2023-10-20 05:50:39 --> Helper loaded: url_helper
INFO - 2023-10-20 05:50:39 --> Helper loaded: file_helper
INFO - 2023-10-20 05:50:39 --> Helper loaded: html_helper
INFO - 2023-10-20 05:50:39 --> Helper loaded: text_helper
INFO - 2023-10-20 05:50:39 --> Helper loaded: form_helper
INFO - 2023-10-20 05:50:39 --> Helper loaded: lang_helper
INFO - 2023-10-20 05:50:39 --> Helper loaded: security_helper
INFO - 2023-10-20 05:50:39 --> Helper loaded: cookie_helper
INFO - 2023-10-20 05:50:39 --> Database Driver Class Initialized
INFO - 2023-10-20 05:50:39 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-20 05:50:39 --> Parser Class Initialized
INFO - 2023-10-20 05:50:39 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-20 05:50:39 --> Pagination Class Initialized
INFO - 2023-10-20 05:50:39 --> Form Validation Class Initialized
INFO - 2023-10-20 05:50:39 --> Controller Class Initialized
INFO - 2023-10-20 05:50:39 --> Model Class Initialized
DEBUG - 2023-10-20 05:50:39 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-10-20 05:50:39 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-20 05:50:39 --> Model Class Initialized
INFO - 2023-10-20 05:50:39 --> Model Class Initialized
INFO - 2023-10-20 05:50:39 --> Final output sent to browser
DEBUG - 2023-10-20 05:50:39 --> Total execution time: 0.0228
ERROR - 2023-10-20 05:50:44 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-20 05:50:44 --> Config Class Initialized
INFO - 2023-10-20 05:50:44 --> Hooks Class Initialized
DEBUG - 2023-10-20 05:50:44 --> UTF-8 Support Enabled
INFO - 2023-10-20 05:50:44 --> Utf8 Class Initialized
INFO - 2023-10-20 05:50:44 --> URI Class Initialized
INFO - 2023-10-20 05:50:44 --> Router Class Initialized
INFO - 2023-10-20 05:50:44 --> Output Class Initialized
INFO - 2023-10-20 05:50:44 --> Security Class Initialized
DEBUG - 2023-10-20 05:50:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-20 05:50:44 --> Input Class Initialized
INFO - 2023-10-20 05:50:44 --> Language Class Initialized
INFO - 2023-10-20 05:50:44 --> Loader Class Initialized
INFO - 2023-10-20 05:50:44 --> Helper loaded: url_helper
INFO - 2023-10-20 05:50:44 --> Helper loaded: file_helper
INFO - 2023-10-20 05:50:44 --> Helper loaded: html_helper
INFO - 2023-10-20 05:50:44 --> Helper loaded: text_helper
INFO - 2023-10-20 05:50:44 --> Helper loaded: form_helper
INFO - 2023-10-20 05:50:44 --> Helper loaded: lang_helper
INFO - 2023-10-20 05:50:44 --> Helper loaded: security_helper
INFO - 2023-10-20 05:50:44 --> Helper loaded: cookie_helper
INFO - 2023-10-20 05:50:44 --> Database Driver Class Initialized
INFO - 2023-10-20 05:50:44 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-20 05:50:44 --> Parser Class Initialized
INFO - 2023-10-20 05:50:44 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-20 05:50:44 --> Pagination Class Initialized
INFO - 2023-10-20 05:50:44 --> Form Validation Class Initialized
INFO - 2023-10-20 05:50:44 --> Controller Class Initialized
INFO - 2023-10-20 05:50:44 --> Model Class Initialized
DEBUG - 2023-10-20 05:50:44 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-10-20 05:50:44 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-20 05:50:44 --> Model Class Initialized
INFO - 2023-10-20 05:50:44 --> Final output sent to browser
DEBUG - 2023-10-20 05:50:44 --> Total execution time: 0.0169
ERROR - 2023-10-20 05:50:59 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-20 05:50:59 --> Config Class Initialized
INFO - 2023-10-20 05:50:59 --> Hooks Class Initialized
DEBUG - 2023-10-20 05:50:59 --> UTF-8 Support Enabled
INFO - 2023-10-20 05:50:59 --> Utf8 Class Initialized
INFO - 2023-10-20 05:50:59 --> URI Class Initialized
INFO - 2023-10-20 05:50:59 --> Router Class Initialized
INFO - 2023-10-20 05:50:59 --> Output Class Initialized
INFO - 2023-10-20 05:50:59 --> Security Class Initialized
DEBUG - 2023-10-20 05:50:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-20 05:50:59 --> Input Class Initialized
INFO - 2023-10-20 05:50:59 --> Language Class Initialized
INFO - 2023-10-20 05:50:59 --> Loader Class Initialized
INFO - 2023-10-20 05:50:59 --> Helper loaded: url_helper
INFO - 2023-10-20 05:50:59 --> Helper loaded: file_helper
INFO - 2023-10-20 05:50:59 --> Helper loaded: html_helper
INFO - 2023-10-20 05:50:59 --> Helper loaded: text_helper
INFO - 2023-10-20 05:50:59 --> Helper loaded: form_helper
INFO - 2023-10-20 05:50:59 --> Helper loaded: lang_helper
INFO - 2023-10-20 05:50:59 --> Helper loaded: security_helper
INFO - 2023-10-20 05:50:59 --> Helper loaded: cookie_helper
INFO - 2023-10-20 05:50:59 --> Database Driver Class Initialized
INFO - 2023-10-20 05:50:59 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-20 05:50:59 --> Parser Class Initialized
INFO - 2023-10-20 05:50:59 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-20 05:50:59 --> Pagination Class Initialized
INFO - 2023-10-20 05:50:59 --> Form Validation Class Initialized
INFO - 2023-10-20 05:50:59 --> Controller Class Initialized
INFO - 2023-10-20 05:50:59 --> Model Class Initialized
DEBUG - 2023-10-20 05:50:59 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-10-20 05:50:59 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-20 05:50:59 --> Model Class Initialized
DEBUG - 2023-10-20 05:50:59 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-20 05:50:59 --> Model Class Initialized
INFO - 2023-10-20 05:50:59 --> Final output sent to browser
DEBUG - 2023-10-20 05:50:59 --> Total execution time: 0.1491
ERROR - 2023-10-20 05:51:00 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-20 05:51:00 --> Config Class Initialized
INFO - 2023-10-20 05:51:00 --> Hooks Class Initialized
DEBUG - 2023-10-20 05:51:00 --> UTF-8 Support Enabled
INFO - 2023-10-20 05:51:00 --> Utf8 Class Initialized
INFO - 2023-10-20 05:51:00 --> URI Class Initialized
INFO - 2023-10-20 05:51:00 --> Router Class Initialized
INFO - 2023-10-20 05:51:00 --> Output Class Initialized
INFO - 2023-10-20 05:51:00 --> Security Class Initialized
DEBUG - 2023-10-20 05:51:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-20 05:51:00 --> Input Class Initialized
INFO - 2023-10-20 05:51:00 --> Language Class Initialized
INFO - 2023-10-20 05:51:00 --> Loader Class Initialized
INFO - 2023-10-20 05:51:00 --> Helper loaded: url_helper
INFO - 2023-10-20 05:51:00 --> Helper loaded: file_helper
INFO - 2023-10-20 05:51:00 --> Helper loaded: html_helper
INFO - 2023-10-20 05:51:00 --> Helper loaded: text_helper
INFO - 2023-10-20 05:51:00 --> Helper loaded: form_helper
INFO - 2023-10-20 05:51:00 --> Helper loaded: lang_helper
INFO - 2023-10-20 05:51:00 --> Helper loaded: security_helper
INFO - 2023-10-20 05:51:00 --> Helper loaded: cookie_helper
INFO - 2023-10-20 05:51:00 --> Database Driver Class Initialized
INFO - 2023-10-20 05:51:00 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-20 05:51:00 --> Parser Class Initialized
INFO - 2023-10-20 05:51:00 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-20 05:51:00 --> Pagination Class Initialized
INFO - 2023-10-20 05:51:00 --> Form Validation Class Initialized
INFO - 2023-10-20 05:51:00 --> Controller Class Initialized
INFO - 2023-10-20 05:51:00 --> Model Class Initialized
DEBUG - 2023-10-20 05:51:00 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-10-20 05:51:00 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-20 05:51:00 --> Model Class Initialized
DEBUG - 2023-10-20 05:51:00 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-20 05:51:00 --> Model Class Initialized
INFO - 2023-10-20 05:51:00 --> Final output sent to browser
DEBUG - 2023-10-20 05:51:00 --> Total execution time: 0.1579
ERROR - 2023-10-20 05:51:00 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-20 05:51:00 --> Config Class Initialized
INFO - 2023-10-20 05:51:00 --> Hooks Class Initialized
DEBUG - 2023-10-20 05:51:00 --> UTF-8 Support Enabled
INFO - 2023-10-20 05:51:00 --> Utf8 Class Initialized
INFO - 2023-10-20 05:51:00 --> URI Class Initialized
INFO - 2023-10-20 05:51:00 --> Router Class Initialized
INFO - 2023-10-20 05:51:00 --> Output Class Initialized
INFO - 2023-10-20 05:51:00 --> Security Class Initialized
DEBUG - 2023-10-20 05:51:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-20 05:51:00 --> Input Class Initialized
INFO - 2023-10-20 05:51:00 --> Language Class Initialized
INFO - 2023-10-20 05:51:00 --> Loader Class Initialized
INFO - 2023-10-20 05:51:00 --> Helper loaded: url_helper
INFO - 2023-10-20 05:51:00 --> Helper loaded: file_helper
INFO - 2023-10-20 05:51:00 --> Helper loaded: html_helper
INFO - 2023-10-20 05:51:00 --> Helper loaded: text_helper
INFO - 2023-10-20 05:51:00 --> Helper loaded: form_helper
INFO - 2023-10-20 05:51:00 --> Helper loaded: lang_helper
INFO - 2023-10-20 05:51:00 --> Helper loaded: security_helper
INFO - 2023-10-20 05:51:00 --> Helper loaded: cookie_helper
INFO - 2023-10-20 05:51:00 --> Database Driver Class Initialized
INFO - 2023-10-20 05:51:00 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-20 05:51:00 --> Parser Class Initialized
INFO - 2023-10-20 05:51:00 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-20 05:51:00 --> Pagination Class Initialized
INFO - 2023-10-20 05:51:00 --> Form Validation Class Initialized
INFO - 2023-10-20 05:51:00 --> Controller Class Initialized
INFO - 2023-10-20 05:51:00 --> Model Class Initialized
DEBUG - 2023-10-20 05:51:00 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-10-20 05:51:00 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-20 05:51:00 --> Model Class Initialized
DEBUG - 2023-10-20 05:51:00 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-20 05:51:00 --> Model Class Initialized
INFO - 2023-10-20 05:51:00 --> Final output sent to browser
DEBUG - 2023-10-20 05:51:00 --> Total execution time: 0.1497
ERROR - 2023-10-20 05:51:04 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-20 05:51:04 --> Config Class Initialized
INFO - 2023-10-20 05:51:04 --> Hooks Class Initialized
DEBUG - 2023-10-20 05:51:04 --> UTF-8 Support Enabled
INFO - 2023-10-20 05:51:04 --> Utf8 Class Initialized
INFO - 2023-10-20 05:51:04 --> URI Class Initialized
INFO - 2023-10-20 05:51:04 --> Router Class Initialized
INFO - 2023-10-20 05:51:04 --> Output Class Initialized
INFO - 2023-10-20 05:51:04 --> Security Class Initialized
DEBUG - 2023-10-20 05:51:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-20 05:51:04 --> Input Class Initialized
INFO - 2023-10-20 05:51:04 --> Language Class Initialized
INFO - 2023-10-20 05:51:04 --> Loader Class Initialized
INFO - 2023-10-20 05:51:04 --> Helper loaded: url_helper
INFO - 2023-10-20 05:51:04 --> Helper loaded: file_helper
INFO - 2023-10-20 05:51:04 --> Helper loaded: html_helper
INFO - 2023-10-20 05:51:04 --> Helper loaded: text_helper
INFO - 2023-10-20 05:51:04 --> Helper loaded: form_helper
INFO - 2023-10-20 05:51:04 --> Helper loaded: lang_helper
INFO - 2023-10-20 05:51:04 --> Helper loaded: security_helper
INFO - 2023-10-20 05:51:04 --> Helper loaded: cookie_helper
INFO - 2023-10-20 05:51:04 --> Database Driver Class Initialized
INFO - 2023-10-20 05:51:04 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-20 05:51:04 --> Parser Class Initialized
INFO - 2023-10-20 05:51:04 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-20 05:51:04 --> Pagination Class Initialized
INFO - 2023-10-20 05:51:04 --> Form Validation Class Initialized
INFO - 2023-10-20 05:51:04 --> Controller Class Initialized
INFO - 2023-10-20 05:51:04 --> Model Class Initialized
DEBUG - 2023-10-20 05:51:04 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-10-20 05:51:04 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-20 05:51:04 --> Model Class Initialized
DEBUG - 2023-10-20 05:51:04 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-20 05:51:04 --> Model Class Initialized
INFO - 2023-10-20 05:51:04 --> Final output sent to browser
DEBUG - 2023-10-20 05:51:04 --> Total execution time: 0.0259
ERROR - 2023-10-20 05:51:04 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-20 05:51:04 --> Config Class Initialized
INFO - 2023-10-20 05:51:04 --> Hooks Class Initialized
DEBUG - 2023-10-20 05:51:04 --> UTF-8 Support Enabled
INFO - 2023-10-20 05:51:04 --> Utf8 Class Initialized
INFO - 2023-10-20 05:51:04 --> URI Class Initialized
INFO - 2023-10-20 05:51:04 --> Router Class Initialized
INFO - 2023-10-20 05:51:04 --> Output Class Initialized
INFO - 2023-10-20 05:51:04 --> Security Class Initialized
DEBUG - 2023-10-20 05:51:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-20 05:51:04 --> Input Class Initialized
INFO - 2023-10-20 05:51:04 --> Language Class Initialized
INFO - 2023-10-20 05:51:04 --> Loader Class Initialized
INFO - 2023-10-20 05:51:04 --> Helper loaded: url_helper
INFO - 2023-10-20 05:51:04 --> Helper loaded: file_helper
INFO - 2023-10-20 05:51:04 --> Helper loaded: html_helper
INFO - 2023-10-20 05:51:04 --> Helper loaded: text_helper
INFO - 2023-10-20 05:51:04 --> Helper loaded: form_helper
INFO - 2023-10-20 05:51:04 --> Helper loaded: lang_helper
INFO - 2023-10-20 05:51:04 --> Helper loaded: security_helper
INFO - 2023-10-20 05:51:04 --> Helper loaded: cookie_helper
INFO - 2023-10-20 05:51:04 --> Database Driver Class Initialized
INFO - 2023-10-20 05:51:04 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-20 05:51:04 --> Parser Class Initialized
INFO - 2023-10-20 05:51:04 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-20 05:51:04 --> Pagination Class Initialized
INFO - 2023-10-20 05:51:04 --> Form Validation Class Initialized
INFO - 2023-10-20 05:51:04 --> Controller Class Initialized
INFO - 2023-10-20 05:51:04 --> Model Class Initialized
DEBUG - 2023-10-20 05:51:04 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-10-20 05:51:04 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-20 05:51:04 --> Model Class Initialized
DEBUG - 2023-10-20 05:51:04 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-20 05:51:04 --> Model Class Initialized
INFO - 2023-10-20 05:51:04 --> Final output sent to browser
DEBUG - 2023-10-20 05:51:04 --> Total execution time: 0.0173
ERROR - 2023-10-20 05:51:07 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-20 05:51:07 --> Config Class Initialized
INFO - 2023-10-20 05:51:07 --> Hooks Class Initialized
DEBUG - 2023-10-20 05:51:07 --> UTF-8 Support Enabled
INFO - 2023-10-20 05:51:07 --> Utf8 Class Initialized
INFO - 2023-10-20 05:51:07 --> URI Class Initialized
INFO - 2023-10-20 05:51:07 --> Router Class Initialized
INFO - 2023-10-20 05:51:07 --> Output Class Initialized
INFO - 2023-10-20 05:51:07 --> Security Class Initialized
DEBUG - 2023-10-20 05:51:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-20 05:51:07 --> Input Class Initialized
INFO - 2023-10-20 05:51:07 --> Language Class Initialized
INFO - 2023-10-20 05:51:07 --> Loader Class Initialized
INFO - 2023-10-20 05:51:07 --> Helper loaded: url_helper
INFO - 2023-10-20 05:51:07 --> Helper loaded: file_helper
INFO - 2023-10-20 05:51:07 --> Helper loaded: html_helper
INFO - 2023-10-20 05:51:07 --> Helper loaded: text_helper
INFO - 2023-10-20 05:51:07 --> Helper loaded: form_helper
INFO - 2023-10-20 05:51:07 --> Helper loaded: lang_helper
INFO - 2023-10-20 05:51:07 --> Helper loaded: security_helper
INFO - 2023-10-20 05:51:07 --> Helper loaded: cookie_helper
INFO - 2023-10-20 05:51:07 --> Database Driver Class Initialized
INFO - 2023-10-20 05:51:07 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-20 05:51:07 --> Parser Class Initialized
INFO - 2023-10-20 05:51:07 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-20 05:51:07 --> Pagination Class Initialized
INFO - 2023-10-20 05:51:07 --> Form Validation Class Initialized
INFO - 2023-10-20 05:51:07 --> Controller Class Initialized
INFO - 2023-10-20 05:51:07 --> Model Class Initialized
DEBUG - 2023-10-20 05:51:07 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-10-20 05:51:07 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-20 05:51:07 --> Model Class Initialized
DEBUG - 2023-10-20 05:51:07 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-20 05:51:07 --> Model Class Initialized
INFO - 2023-10-20 05:51:07 --> Final output sent to browser
DEBUG - 2023-10-20 05:51:07 --> Total execution time: 0.0254
ERROR - 2023-10-20 05:51:08 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-20 05:51:08 --> Config Class Initialized
INFO - 2023-10-20 05:51:08 --> Hooks Class Initialized
DEBUG - 2023-10-20 05:51:08 --> UTF-8 Support Enabled
INFO - 2023-10-20 05:51:08 --> Utf8 Class Initialized
INFO - 2023-10-20 05:51:08 --> URI Class Initialized
INFO - 2023-10-20 05:51:08 --> Router Class Initialized
INFO - 2023-10-20 05:51:08 --> Output Class Initialized
INFO - 2023-10-20 05:51:08 --> Security Class Initialized
DEBUG - 2023-10-20 05:51:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-20 05:51:08 --> Input Class Initialized
INFO - 2023-10-20 05:51:08 --> Language Class Initialized
INFO - 2023-10-20 05:51:08 --> Loader Class Initialized
INFO - 2023-10-20 05:51:08 --> Helper loaded: url_helper
INFO - 2023-10-20 05:51:08 --> Helper loaded: file_helper
INFO - 2023-10-20 05:51:08 --> Helper loaded: html_helper
INFO - 2023-10-20 05:51:08 --> Helper loaded: text_helper
INFO - 2023-10-20 05:51:08 --> Helper loaded: form_helper
INFO - 2023-10-20 05:51:08 --> Helper loaded: lang_helper
INFO - 2023-10-20 05:51:08 --> Helper loaded: security_helper
INFO - 2023-10-20 05:51:08 --> Helper loaded: cookie_helper
INFO - 2023-10-20 05:51:08 --> Database Driver Class Initialized
INFO - 2023-10-20 05:51:08 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-20 05:51:08 --> Parser Class Initialized
INFO - 2023-10-20 05:51:08 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-20 05:51:08 --> Pagination Class Initialized
INFO - 2023-10-20 05:51:08 --> Form Validation Class Initialized
INFO - 2023-10-20 05:51:08 --> Controller Class Initialized
INFO - 2023-10-20 05:51:08 --> Model Class Initialized
DEBUG - 2023-10-20 05:51:08 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-10-20 05:51:08 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-20 05:51:08 --> Model Class Initialized
DEBUG - 2023-10-20 05:51:08 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-20 05:51:08 --> Model Class Initialized
INFO - 2023-10-20 05:51:08 --> Final output sent to browser
DEBUG - 2023-10-20 05:51:08 --> Total execution time: 0.1473
ERROR - 2023-10-20 05:51:09 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-20 05:51:09 --> Config Class Initialized
INFO - 2023-10-20 05:51:09 --> Hooks Class Initialized
DEBUG - 2023-10-20 05:51:09 --> UTF-8 Support Enabled
INFO - 2023-10-20 05:51:09 --> Utf8 Class Initialized
INFO - 2023-10-20 05:51:09 --> URI Class Initialized
INFO - 2023-10-20 05:51:09 --> Router Class Initialized
INFO - 2023-10-20 05:51:09 --> Output Class Initialized
INFO - 2023-10-20 05:51:09 --> Security Class Initialized
DEBUG - 2023-10-20 05:51:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-20 05:51:09 --> Input Class Initialized
INFO - 2023-10-20 05:51:09 --> Language Class Initialized
INFO - 2023-10-20 05:51:09 --> Loader Class Initialized
INFO - 2023-10-20 05:51:09 --> Helper loaded: url_helper
INFO - 2023-10-20 05:51:09 --> Helper loaded: file_helper
INFO - 2023-10-20 05:51:09 --> Helper loaded: html_helper
INFO - 2023-10-20 05:51:09 --> Helper loaded: text_helper
INFO - 2023-10-20 05:51:09 --> Helper loaded: form_helper
INFO - 2023-10-20 05:51:09 --> Helper loaded: lang_helper
INFO - 2023-10-20 05:51:09 --> Helper loaded: security_helper
INFO - 2023-10-20 05:51:09 --> Helper loaded: cookie_helper
INFO - 2023-10-20 05:51:09 --> Database Driver Class Initialized
INFO - 2023-10-20 05:51:09 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-20 05:51:09 --> Parser Class Initialized
INFO - 2023-10-20 05:51:09 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-20 05:51:09 --> Pagination Class Initialized
INFO - 2023-10-20 05:51:09 --> Form Validation Class Initialized
INFO - 2023-10-20 05:51:09 --> Controller Class Initialized
INFO - 2023-10-20 05:51:09 --> Model Class Initialized
DEBUG - 2023-10-20 05:51:09 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-10-20 05:51:09 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-20 05:51:09 --> Model Class Initialized
INFO - 2023-10-20 05:51:09 --> Model Class Initialized
INFO - 2023-10-20 05:51:09 --> Final output sent to browser
DEBUG - 2023-10-20 05:51:09 --> Total execution time: 0.0247
ERROR - 2023-10-20 05:51:14 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-20 05:51:14 --> Config Class Initialized
INFO - 2023-10-20 05:51:14 --> Hooks Class Initialized
DEBUG - 2023-10-20 05:51:14 --> UTF-8 Support Enabled
INFO - 2023-10-20 05:51:14 --> Utf8 Class Initialized
INFO - 2023-10-20 05:51:14 --> URI Class Initialized
INFO - 2023-10-20 05:51:14 --> Router Class Initialized
INFO - 2023-10-20 05:51:14 --> Output Class Initialized
INFO - 2023-10-20 05:51:14 --> Security Class Initialized
DEBUG - 2023-10-20 05:51:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-20 05:51:14 --> Input Class Initialized
INFO - 2023-10-20 05:51:14 --> Language Class Initialized
INFO - 2023-10-20 05:51:14 --> Loader Class Initialized
INFO - 2023-10-20 05:51:14 --> Helper loaded: url_helper
INFO - 2023-10-20 05:51:14 --> Helper loaded: file_helper
INFO - 2023-10-20 05:51:14 --> Helper loaded: html_helper
INFO - 2023-10-20 05:51:14 --> Helper loaded: text_helper
INFO - 2023-10-20 05:51:14 --> Helper loaded: form_helper
INFO - 2023-10-20 05:51:14 --> Helper loaded: lang_helper
INFO - 2023-10-20 05:51:14 --> Helper loaded: security_helper
INFO - 2023-10-20 05:51:14 --> Helper loaded: cookie_helper
INFO - 2023-10-20 05:51:14 --> Database Driver Class Initialized
INFO - 2023-10-20 05:51:14 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-20 05:51:14 --> Parser Class Initialized
INFO - 2023-10-20 05:51:14 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-20 05:51:14 --> Pagination Class Initialized
INFO - 2023-10-20 05:51:14 --> Form Validation Class Initialized
INFO - 2023-10-20 05:51:14 --> Controller Class Initialized
INFO - 2023-10-20 05:51:14 --> Model Class Initialized
DEBUG - 2023-10-20 05:51:14 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-10-20 05:51:14 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-20 05:51:14 --> Model Class Initialized
DEBUG - 2023-10-20 05:51:14 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-20 05:51:14 --> Model Class Initialized
INFO - 2023-10-20 05:51:14 --> Final output sent to browser
DEBUG - 2023-10-20 05:51:14 --> Total execution time: 0.0176
ERROR - 2023-10-20 05:51:17 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-20 05:51:17 --> Config Class Initialized
INFO - 2023-10-20 05:51:17 --> Hooks Class Initialized
DEBUG - 2023-10-20 05:51:17 --> UTF-8 Support Enabled
INFO - 2023-10-20 05:51:17 --> Utf8 Class Initialized
INFO - 2023-10-20 05:51:17 --> URI Class Initialized
INFO - 2023-10-20 05:51:17 --> Router Class Initialized
INFO - 2023-10-20 05:51:17 --> Output Class Initialized
INFO - 2023-10-20 05:51:17 --> Security Class Initialized
DEBUG - 2023-10-20 05:51:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-20 05:51:17 --> Input Class Initialized
INFO - 2023-10-20 05:51:17 --> Language Class Initialized
INFO - 2023-10-20 05:51:17 --> Loader Class Initialized
INFO - 2023-10-20 05:51:17 --> Helper loaded: url_helper
INFO - 2023-10-20 05:51:17 --> Helper loaded: file_helper
INFO - 2023-10-20 05:51:17 --> Helper loaded: html_helper
INFO - 2023-10-20 05:51:17 --> Helper loaded: text_helper
INFO - 2023-10-20 05:51:17 --> Helper loaded: form_helper
INFO - 2023-10-20 05:51:17 --> Helper loaded: lang_helper
INFO - 2023-10-20 05:51:17 --> Helper loaded: security_helper
INFO - 2023-10-20 05:51:17 --> Helper loaded: cookie_helper
INFO - 2023-10-20 05:51:17 --> Database Driver Class Initialized
INFO - 2023-10-20 05:51:17 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-20 05:51:17 --> Parser Class Initialized
INFO - 2023-10-20 05:51:17 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-20 05:51:17 --> Pagination Class Initialized
INFO - 2023-10-20 05:51:17 --> Form Validation Class Initialized
INFO - 2023-10-20 05:51:17 --> Controller Class Initialized
INFO - 2023-10-20 05:51:17 --> Model Class Initialized
DEBUG - 2023-10-20 05:51:17 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-10-20 05:51:17 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-20 05:51:17 --> Model Class Initialized
DEBUG - 2023-10-20 05:51:17 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-20 05:51:17 --> Model Class Initialized
INFO - 2023-10-20 05:51:17 --> Final output sent to browser
DEBUG - 2023-10-20 05:51:17 --> Total execution time: 0.0208
ERROR - 2023-10-20 05:51:17 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-20 05:51:17 --> Config Class Initialized
INFO - 2023-10-20 05:51:17 --> Hooks Class Initialized
DEBUG - 2023-10-20 05:51:17 --> UTF-8 Support Enabled
INFO - 2023-10-20 05:51:17 --> Utf8 Class Initialized
INFO - 2023-10-20 05:51:17 --> URI Class Initialized
INFO - 2023-10-20 05:51:17 --> Router Class Initialized
INFO - 2023-10-20 05:51:17 --> Output Class Initialized
INFO - 2023-10-20 05:51:17 --> Security Class Initialized
DEBUG - 2023-10-20 05:51:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-20 05:51:17 --> Input Class Initialized
INFO - 2023-10-20 05:51:17 --> Language Class Initialized
INFO - 2023-10-20 05:51:17 --> Loader Class Initialized
INFO - 2023-10-20 05:51:17 --> Helper loaded: url_helper
INFO - 2023-10-20 05:51:17 --> Helper loaded: file_helper
INFO - 2023-10-20 05:51:17 --> Helper loaded: html_helper
INFO - 2023-10-20 05:51:17 --> Helper loaded: text_helper
INFO - 2023-10-20 05:51:17 --> Helper loaded: form_helper
INFO - 2023-10-20 05:51:17 --> Helper loaded: lang_helper
INFO - 2023-10-20 05:51:17 --> Helper loaded: security_helper
INFO - 2023-10-20 05:51:17 --> Helper loaded: cookie_helper
INFO - 2023-10-20 05:51:17 --> Database Driver Class Initialized
INFO - 2023-10-20 05:51:17 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-20 05:51:17 --> Parser Class Initialized
INFO - 2023-10-20 05:51:17 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-20 05:51:17 --> Pagination Class Initialized
INFO - 2023-10-20 05:51:17 --> Form Validation Class Initialized
INFO - 2023-10-20 05:51:17 --> Controller Class Initialized
INFO - 2023-10-20 05:51:17 --> Model Class Initialized
DEBUG - 2023-10-20 05:51:17 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-10-20 05:51:17 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-20 05:51:17 --> Model Class Initialized
DEBUG - 2023-10-20 05:51:17 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-20 05:51:17 --> Model Class Initialized
INFO - 2023-10-20 05:51:17 --> Final output sent to browser
DEBUG - 2023-10-20 05:51:17 --> Total execution time: 0.0185
ERROR - 2023-10-20 05:51:19 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-20 05:51:19 --> Config Class Initialized
INFO - 2023-10-20 05:51:19 --> Hooks Class Initialized
DEBUG - 2023-10-20 05:51:19 --> UTF-8 Support Enabled
INFO - 2023-10-20 05:51:19 --> Utf8 Class Initialized
INFO - 2023-10-20 05:51:19 --> URI Class Initialized
INFO - 2023-10-20 05:51:19 --> Router Class Initialized
INFO - 2023-10-20 05:51:19 --> Output Class Initialized
INFO - 2023-10-20 05:51:19 --> Security Class Initialized
DEBUG - 2023-10-20 05:51:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-20 05:51:19 --> Input Class Initialized
INFO - 2023-10-20 05:51:19 --> Language Class Initialized
INFO - 2023-10-20 05:51:19 --> Loader Class Initialized
INFO - 2023-10-20 05:51:19 --> Helper loaded: url_helper
INFO - 2023-10-20 05:51:19 --> Helper loaded: file_helper
INFO - 2023-10-20 05:51:19 --> Helper loaded: html_helper
INFO - 2023-10-20 05:51:19 --> Helper loaded: text_helper
INFO - 2023-10-20 05:51:19 --> Helper loaded: form_helper
INFO - 2023-10-20 05:51:19 --> Helper loaded: lang_helper
INFO - 2023-10-20 05:51:19 --> Helper loaded: security_helper
INFO - 2023-10-20 05:51:19 --> Helper loaded: cookie_helper
INFO - 2023-10-20 05:51:19 --> Database Driver Class Initialized
INFO - 2023-10-20 05:51:19 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-20 05:51:19 --> Parser Class Initialized
INFO - 2023-10-20 05:51:19 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-20 05:51:19 --> Pagination Class Initialized
INFO - 2023-10-20 05:51:19 --> Form Validation Class Initialized
INFO - 2023-10-20 05:51:19 --> Controller Class Initialized
INFO - 2023-10-20 05:51:19 --> Model Class Initialized
DEBUG - 2023-10-20 05:51:19 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-10-20 05:51:19 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-20 05:51:19 --> Model Class Initialized
DEBUG - 2023-10-20 05:51:19 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-20 05:51:19 --> Model Class Initialized
INFO - 2023-10-20 05:51:19 --> Final output sent to browser
DEBUG - 2023-10-20 05:51:19 --> Total execution time: 0.0227
ERROR - 2023-10-20 05:51:20 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-20 05:51:20 --> Config Class Initialized
INFO - 2023-10-20 05:51:20 --> Hooks Class Initialized
DEBUG - 2023-10-20 05:51:20 --> UTF-8 Support Enabled
INFO - 2023-10-20 05:51:20 --> Utf8 Class Initialized
INFO - 2023-10-20 05:51:20 --> URI Class Initialized
INFO - 2023-10-20 05:51:20 --> Router Class Initialized
INFO - 2023-10-20 05:51:20 --> Output Class Initialized
INFO - 2023-10-20 05:51:20 --> Security Class Initialized
DEBUG - 2023-10-20 05:51:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-20 05:51:20 --> Input Class Initialized
INFO - 2023-10-20 05:51:20 --> Language Class Initialized
INFO - 2023-10-20 05:51:20 --> Loader Class Initialized
INFO - 2023-10-20 05:51:20 --> Helper loaded: url_helper
INFO - 2023-10-20 05:51:20 --> Helper loaded: file_helper
INFO - 2023-10-20 05:51:20 --> Helper loaded: html_helper
INFO - 2023-10-20 05:51:20 --> Helper loaded: text_helper
INFO - 2023-10-20 05:51:20 --> Helper loaded: form_helper
INFO - 2023-10-20 05:51:20 --> Helper loaded: lang_helper
INFO - 2023-10-20 05:51:20 --> Helper loaded: security_helper
INFO - 2023-10-20 05:51:20 --> Helper loaded: cookie_helper
INFO - 2023-10-20 05:51:20 --> Database Driver Class Initialized
INFO - 2023-10-20 05:51:20 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-20 05:51:20 --> Parser Class Initialized
INFO - 2023-10-20 05:51:20 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-20 05:51:20 --> Pagination Class Initialized
INFO - 2023-10-20 05:51:20 --> Form Validation Class Initialized
INFO - 2023-10-20 05:51:20 --> Controller Class Initialized
INFO - 2023-10-20 05:51:20 --> Model Class Initialized
DEBUG - 2023-10-20 05:51:20 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-10-20 05:51:20 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-20 05:51:20 --> Model Class Initialized
DEBUG - 2023-10-20 05:51:20 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-20 05:51:20 --> Model Class Initialized
INFO - 2023-10-20 05:51:20 --> Final output sent to browser
DEBUG - 2023-10-20 05:51:20 --> Total execution time: 0.1605
ERROR - 2023-10-20 05:51:23 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-20 05:51:23 --> Config Class Initialized
INFO - 2023-10-20 05:51:23 --> Hooks Class Initialized
DEBUG - 2023-10-20 05:51:23 --> UTF-8 Support Enabled
INFO - 2023-10-20 05:51:23 --> Utf8 Class Initialized
INFO - 2023-10-20 05:51:23 --> URI Class Initialized
INFO - 2023-10-20 05:51:23 --> Router Class Initialized
INFO - 2023-10-20 05:51:23 --> Output Class Initialized
INFO - 2023-10-20 05:51:23 --> Security Class Initialized
DEBUG - 2023-10-20 05:51:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-20 05:51:23 --> Input Class Initialized
INFO - 2023-10-20 05:51:23 --> Language Class Initialized
INFO - 2023-10-20 05:51:23 --> Loader Class Initialized
INFO - 2023-10-20 05:51:23 --> Helper loaded: url_helper
INFO - 2023-10-20 05:51:23 --> Helper loaded: file_helper
INFO - 2023-10-20 05:51:23 --> Helper loaded: html_helper
INFO - 2023-10-20 05:51:23 --> Helper loaded: text_helper
INFO - 2023-10-20 05:51:23 --> Helper loaded: form_helper
INFO - 2023-10-20 05:51:23 --> Helper loaded: lang_helper
INFO - 2023-10-20 05:51:23 --> Helper loaded: security_helper
INFO - 2023-10-20 05:51:23 --> Helper loaded: cookie_helper
INFO - 2023-10-20 05:51:23 --> Database Driver Class Initialized
INFO - 2023-10-20 05:51:23 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-20 05:51:23 --> Parser Class Initialized
INFO - 2023-10-20 05:51:23 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-20 05:51:23 --> Pagination Class Initialized
INFO - 2023-10-20 05:51:23 --> Form Validation Class Initialized
INFO - 2023-10-20 05:51:23 --> Controller Class Initialized
INFO - 2023-10-20 05:51:23 --> Model Class Initialized
DEBUG - 2023-10-20 05:51:23 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-10-20 05:51:23 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-20 05:51:23 --> Model Class Initialized
DEBUG - 2023-10-20 05:51:23 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-20 05:51:23 --> Model Class Initialized
INFO - 2023-10-20 05:51:23 --> Final output sent to browser
DEBUG - 2023-10-20 05:51:23 --> Total execution time: 0.0312
ERROR - 2023-10-20 05:51:26 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-20 05:51:26 --> Config Class Initialized
INFO - 2023-10-20 05:51:26 --> Hooks Class Initialized
DEBUG - 2023-10-20 05:51:26 --> UTF-8 Support Enabled
INFO - 2023-10-20 05:51:26 --> Utf8 Class Initialized
INFO - 2023-10-20 05:51:26 --> URI Class Initialized
INFO - 2023-10-20 05:51:26 --> Router Class Initialized
INFO - 2023-10-20 05:51:26 --> Output Class Initialized
INFO - 2023-10-20 05:51:26 --> Security Class Initialized
DEBUG - 2023-10-20 05:51:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-20 05:51:26 --> Input Class Initialized
INFO - 2023-10-20 05:51:26 --> Language Class Initialized
INFO - 2023-10-20 05:51:26 --> Loader Class Initialized
INFO - 2023-10-20 05:51:26 --> Helper loaded: url_helper
INFO - 2023-10-20 05:51:26 --> Helper loaded: file_helper
INFO - 2023-10-20 05:51:26 --> Helper loaded: html_helper
INFO - 2023-10-20 05:51:26 --> Helper loaded: text_helper
INFO - 2023-10-20 05:51:26 --> Helper loaded: form_helper
INFO - 2023-10-20 05:51:26 --> Helper loaded: lang_helper
INFO - 2023-10-20 05:51:26 --> Helper loaded: security_helper
INFO - 2023-10-20 05:51:26 --> Helper loaded: cookie_helper
INFO - 2023-10-20 05:51:26 --> Database Driver Class Initialized
INFO - 2023-10-20 05:51:26 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-20 05:51:26 --> Parser Class Initialized
INFO - 2023-10-20 05:51:26 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-20 05:51:26 --> Pagination Class Initialized
INFO - 2023-10-20 05:51:26 --> Form Validation Class Initialized
INFO - 2023-10-20 05:51:26 --> Controller Class Initialized
INFO - 2023-10-20 05:51:26 --> Model Class Initialized
DEBUG - 2023-10-20 05:51:26 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-10-20 05:51:26 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-20 05:51:26 --> Model Class Initialized
INFO - 2023-10-20 05:51:26 --> Model Class Initialized
INFO - 2023-10-20 05:51:26 --> Final output sent to browser
DEBUG - 2023-10-20 05:51:26 --> Total execution time: 0.0216
ERROR - 2023-10-20 05:51:28 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-20 05:51:28 --> Config Class Initialized
INFO - 2023-10-20 05:51:28 --> Hooks Class Initialized
DEBUG - 2023-10-20 05:51:28 --> UTF-8 Support Enabled
INFO - 2023-10-20 05:51:28 --> Utf8 Class Initialized
INFO - 2023-10-20 05:51:28 --> URI Class Initialized
INFO - 2023-10-20 05:51:28 --> Router Class Initialized
INFO - 2023-10-20 05:51:28 --> Output Class Initialized
INFO - 2023-10-20 05:51:28 --> Security Class Initialized
DEBUG - 2023-10-20 05:51:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-20 05:51:28 --> Input Class Initialized
INFO - 2023-10-20 05:51:28 --> Language Class Initialized
INFO - 2023-10-20 05:51:28 --> Loader Class Initialized
INFO - 2023-10-20 05:51:28 --> Helper loaded: url_helper
INFO - 2023-10-20 05:51:28 --> Helper loaded: file_helper
INFO - 2023-10-20 05:51:28 --> Helper loaded: html_helper
INFO - 2023-10-20 05:51:28 --> Helper loaded: text_helper
INFO - 2023-10-20 05:51:28 --> Helper loaded: form_helper
INFO - 2023-10-20 05:51:28 --> Helper loaded: lang_helper
INFO - 2023-10-20 05:51:28 --> Helper loaded: security_helper
INFO - 2023-10-20 05:51:28 --> Helper loaded: cookie_helper
INFO - 2023-10-20 05:51:28 --> Database Driver Class Initialized
INFO - 2023-10-20 05:51:28 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-20 05:51:28 --> Parser Class Initialized
INFO - 2023-10-20 05:51:28 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-20 05:51:28 --> Pagination Class Initialized
INFO - 2023-10-20 05:51:28 --> Form Validation Class Initialized
INFO - 2023-10-20 05:51:28 --> Controller Class Initialized
INFO - 2023-10-20 05:51:28 --> Model Class Initialized
DEBUG - 2023-10-20 05:51:28 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-10-20 05:51:28 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-20 05:51:28 --> Model Class Initialized
INFO - 2023-10-20 05:51:28 --> Final output sent to browser
DEBUG - 2023-10-20 05:51:28 --> Total execution time: 0.0168
ERROR - 2023-10-20 05:53:22 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-20 05:53:22 --> Config Class Initialized
INFO - 2023-10-20 05:53:22 --> Hooks Class Initialized
DEBUG - 2023-10-20 05:53:22 --> UTF-8 Support Enabled
INFO - 2023-10-20 05:53:22 --> Utf8 Class Initialized
INFO - 2023-10-20 05:53:22 --> URI Class Initialized
INFO - 2023-10-20 05:53:22 --> Router Class Initialized
INFO - 2023-10-20 05:53:22 --> Output Class Initialized
INFO - 2023-10-20 05:53:22 --> Security Class Initialized
DEBUG - 2023-10-20 05:53:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-20 05:53:22 --> Input Class Initialized
INFO - 2023-10-20 05:53:22 --> Language Class Initialized
INFO - 2023-10-20 05:53:22 --> Loader Class Initialized
INFO - 2023-10-20 05:53:22 --> Helper loaded: url_helper
INFO - 2023-10-20 05:53:22 --> Helper loaded: file_helper
INFO - 2023-10-20 05:53:22 --> Helper loaded: html_helper
INFO - 2023-10-20 05:53:22 --> Helper loaded: text_helper
INFO - 2023-10-20 05:53:22 --> Helper loaded: form_helper
INFO - 2023-10-20 05:53:22 --> Helper loaded: lang_helper
INFO - 2023-10-20 05:53:22 --> Helper loaded: security_helper
INFO - 2023-10-20 05:53:22 --> Helper loaded: cookie_helper
INFO - 2023-10-20 05:53:22 --> Database Driver Class Initialized
INFO - 2023-10-20 05:53:22 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-20 05:53:22 --> Parser Class Initialized
INFO - 2023-10-20 05:53:22 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-20 05:53:22 --> Pagination Class Initialized
INFO - 2023-10-20 05:53:22 --> Form Validation Class Initialized
INFO - 2023-10-20 05:53:22 --> Controller Class Initialized
INFO - 2023-10-20 05:53:22 --> Model Class Initialized
DEBUG - 2023-10-20 05:53:22 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-10-20 05:53:22 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-20 05:53:22 --> Model Class Initialized
DEBUG - 2023-10-20 05:53:22 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-20 05:53:22 --> Model Class Initialized
INFO - 2023-10-20 05:53:22 --> Final output sent to browser
DEBUG - 2023-10-20 05:53:22 --> Total execution time: 0.1492
ERROR - 2023-10-20 05:53:23 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-20 05:53:23 --> Config Class Initialized
INFO - 2023-10-20 05:53:23 --> Hooks Class Initialized
DEBUG - 2023-10-20 05:53:23 --> UTF-8 Support Enabled
INFO - 2023-10-20 05:53:23 --> Utf8 Class Initialized
INFO - 2023-10-20 05:53:23 --> URI Class Initialized
INFO - 2023-10-20 05:53:23 --> Router Class Initialized
INFO - 2023-10-20 05:53:23 --> Output Class Initialized
INFO - 2023-10-20 05:53:23 --> Security Class Initialized
DEBUG - 2023-10-20 05:53:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-20 05:53:23 --> Input Class Initialized
INFO - 2023-10-20 05:53:23 --> Language Class Initialized
INFO - 2023-10-20 05:53:23 --> Loader Class Initialized
INFO - 2023-10-20 05:53:23 --> Helper loaded: url_helper
INFO - 2023-10-20 05:53:23 --> Helper loaded: file_helper
INFO - 2023-10-20 05:53:23 --> Helper loaded: html_helper
INFO - 2023-10-20 05:53:23 --> Helper loaded: text_helper
INFO - 2023-10-20 05:53:23 --> Helper loaded: form_helper
INFO - 2023-10-20 05:53:23 --> Helper loaded: lang_helper
INFO - 2023-10-20 05:53:23 --> Helper loaded: security_helper
INFO - 2023-10-20 05:53:23 --> Helper loaded: cookie_helper
INFO - 2023-10-20 05:53:23 --> Database Driver Class Initialized
INFO - 2023-10-20 05:53:23 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-20 05:53:23 --> Parser Class Initialized
INFO - 2023-10-20 05:53:23 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-20 05:53:23 --> Pagination Class Initialized
INFO - 2023-10-20 05:53:23 --> Form Validation Class Initialized
INFO - 2023-10-20 05:53:23 --> Controller Class Initialized
INFO - 2023-10-20 05:53:23 --> Model Class Initialized
DEBUG - 2023-10-20 05:53:23 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-10-20 05:53:23 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-20 05:53:23 --> Model Class Initialized
DEBUG - 2023-10-20 05:53:23 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-20 05:53:23 --> Model Class Initialized
INFO - 2023-10-20 05:53:23 --> Final output sent to browser
DEBUG - 2023-10-20 05:53:23 --> Total execution time: 0.1457
ERROR - 2023-10-20 05:53:23 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-20 05:53:23 --> Config Class Initialized
INFO - 2023-10-20 05:53:23 --> Hooks Class Initialized
DEBUG - 2023-10-20 05:53:23 --> UTF-8 Support Enabled
INFO - 2023-10-20 05:53:23 --> Utf8 Class Initialized
INFO - 2023-10-20 05:53:23 --> URI Class Initialized
INFO - 2023-10-20 05:53:23 --> Router Class Initialized
INFO - 2023-10-20 05:53:23 --> Output Class Initialized
INFO - 2023-10-20 05:53:23 --> Security Class Initialized
DEBUG - 2023-10-20 05:53:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-20 05:53:23 --> Input Class Initialized
INFO - 2023-10-20 05:53:23 --> Language Class Initialized
INFO - 2023-10-20 05:53:23 --> Loader Class Initialized
INFO - 2023-10-20 05:53:23 --> Helper loaded: url_helper
INFO - 2023-10-20 05:53:23 --> Helper loaded: file_helper
INFO - 2023-10-20 05:53:23 --> Helper loaded: html_helper
INFO - 2023-10-20 05:53:23 --> Helper loaded: text_helper
INFO - 2023-10-20 05:53:23 --> Helper loaded: form_helper
INFO - 2023-10-20 05:53:23 --> Helper loaded: lang_helper
INFO - 2023-10-20 05:53:23 --> Helper loaded: security_helper
INFO - 2023-10-20 05:53:23 --> Helper loaded: cookie_helper
INFO - 2023-10-20 05:53:23 --> Database Driver Class Initialized
INFO - 2023-10-20 05:53:23 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-20 05:53:23 --> Parser Class Initialized
INFO - 2023-10-20 05:53:23 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-20 05:53:23 --> Pagination Class Initialized
INFO - 2023-10-20 05:53:23 --> Form Validation Class Initialized
INFO - 2023-10-20 05:53:23 --> Controller Class Initialized
INFO - 2023-10-20 05:53:23 --> Model Class Initialized
DEBUG - 2023-10-20 05:53:23 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-10-20 05:53:23 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-20 05:53:23 --> Model Class Initialized
DEBUG - 2023-10-20 05:53:23 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-20 05:53:23 --> Model Class Initialized
INFO - 2023-10-20 05:53:23 --> Final output sent to browser
DEBUG - 2023-10-20 05:53:23 --> Total execution time: 0.1632
ERROR - 2023-10-20 05:53:26 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-20 05:53:26 --> Config Class Initialized
INFO - 2023-10-20 05:53:26 --> Hooks Class Initialized
DEBUG - 2023-10-20 05:53:26 --> UTF-8 Support Enabled
INFO - 2023-10-20 05:53:26 --> Utf8 Class Initialized
INFO - 2023-10-20 05:53:26 --> URI Class Initialized
INFO - 2023-10-20 05:53:26 --> Router Class Initialized
INFO - 2023-10-20 05:53:26 --> Output Class Initialized
INFO - 2023-10-20 05:53:26 --> Security Class Initialized
DEBUG - 2023-10-20 05:53:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-20 05:53:26 --> Input Class Initialized
INFO - 2023-10-20 05:53:26 --> Language Class Initialized
INFO - 2023-10-20 05:53:26 --> Loader Class Initialized
INFO - 2023-10-20 05:53:26 --> Helper loaded: url_helper
INFO - 2023-10-20 05:53:26 --> Helper loaded: file_helper
INFO - 2023-10-20 05:53:26 --> Helper loaded: html_helper
INFO - 2023-10-20 05:53:26 --> Helper loaded: text_helper
INFO - 2023-10-20 05:53:26 --> Helper loaded: form_helper
INFO - 2023-10-20 05:53:26 --> Helper loaded: lang_helper
INFO - 2023-10-20 05:53:26 --> Helper loaded: security_helper
INFO - 2023-10-20 05:53:26 --> Helper loaded: cookie_helper
INFO - 2023-10-20 05:53:26 --> Database Driver Class Initialized
INFO - 2023-10-20 05:53:26 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-20 05:53:26 --> Parser Class Initialized
INFO - 2023-10-20 05:53:26 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-20 05:53:26 --> Pagination Class Initialized
INFO - 2023-10-20 05:53:26 --> Form Validation Class Initialized
INFO - 2023-10-20 05:53:26 --> Controller Class Initialized
INFO - 2023-10-20 05:53:26 --> Model Class Initialized
DEBUG - 2023-10-20 05:53:26 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-10-20 05:53:26 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-20 05:53:26 --> Model Class Initialized
DEBUG - 2023-10-20 05:53:26 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-20 05:53:26 --> Model Class Initialized
INFO - 2023-10-20 05:53:26 --> Final output sent to browser
DEBUG - 2023-10-20 05:53:26 --> Total execution time: 0.0297
ERROR - 2023-10-20 05:53:28 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-20 05:53:28 --> Config Class Initialized
INFO - 2023-10-20 05:53:28 --> Hooks Class Initialized
DEBUG - 2023-10-20 05:53:28 --> UTF-8 Support Enabled
INFO - 2023-10-20 05:53:28 --> Utf8 Class Initialized
INFO - 2023-10-20 05:53:28 --> URI Class Initialized
INFO - 2023-10-20 05:53:28 --> Router Class Initialized
INFO - 2023-10-20 05:53:28 --> Output Class Initialized
INFO - 2023-10-20 05:53:28 --> Security Class Initialized
DEBUG - 2023-10-20 05:53:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-20 05:53:28 --> Input Class Initialized
INFO - 2023-10-20 05:53:28 --> Language Class Initialized
INFO - 2023-10-20 05:53:28 --> Loader Class Initialized
INFO - 2023-10-20 05:53:28 --> Helper loaded: url_helper
INFO - 2023-10-20 05:53:28 --> Helper loaded: file_helper
INFO - 2023-10-20 05:53:28 --> Helper loaded: html_helper
INFO - 2023-10-20 05:53:28 --> Helper loaded: text_helper
INFO - 2023-10-20 05:53:28 --> Helper loaded: form_helper
INFO - 2023-10-20 05:53:28 --> Helper loaded: lang_helper
INFO - 2023-10-20 05:53:28 --> Helper loaded: security_helper
INFO - 2023-10-20 05:53:28 --> Helper loaded: cookie_helper
INFO - 2023-10-20 05:53:28 --> Database Driver Class Initialized
INFO - 2023-10-20 05:53:28 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-20 05:53:28 --> Parser Class Initialized
INFO - 2023-10-20 05:53:28 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-20 05:53:28 --> Pagination Class Initialized
INFO - 2023-10-20 05:53:28 --> Form Validation Class Initialized
INFO - 2023-10-20 05:53:28 --> Controller Class Initialized
INFO - 2023-10-20 05:53:28 --> Model Class Initialized
DEBUG - 2023-10-20 05:53:28 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-10-20 05:53:28 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-20 05:53:28 --> Model Class Initialized
DEBUG - 2023-10-20 05:53:28 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-20 05:53:28 --> Model Class Initialized
INFO - 2023-10-20 05:53:28 --> Final output sent to browser
DEBUG - 2023-10-20 05:53:28 --> Total execution time: 0.1462
ERROR - 2023-10-20 05:53:30 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-20 05:53:30 --> Config Class Initialized
INFO - 2023-10-20 05:53:30 --> Hooks Class Initialized
DEBUG - 2023-10-20 05:53:30 --> UTF-8 Support Enabled
INFO - 2023-10-20 05:53:30 --> Utf8 Class Initialized
INFO - 2023-10-20 05:53:30 --> URI Class Initialized
INFO - 2023-10-20 05:53:30 --> Router Class Initialized
INFO - 2023-10-20 05:53:30 --> Output Class Initialized
INFO - 2023-10-20 05:53:30 --> Security Class Initialized
DEBUG - 2023-10-20 05:53:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-20 05:53:30 --> Input Class Initialized
INFO - 2023-10-20 05:53:30 --> Language Class Initialized
INFO - 2023-10-20 05:53:30 --> Loader Class Initialized
INFO - 2023-10-20 05:53:30 --> Helper loaded: url_helper
INFO - 2023-10-20 05:53:30 --> Helper loaded: file_helper
INFO - 2023-10-20 05:53:30 --> Helper loaded: html_helper
INFO - 2023-10-20 05:53:30 --> Helper loaded: text_helper
INFO - 2023-10-20 05:53:30 --> Helper loaded: form_helper
INFO - 2023-10-20 05:53:30 --> Helper loaded: lang_helper
INFO - 2023-10-20 05:53:30 --> Helper loaded: security_helper
INFO - 2023-10-20 05:53:30 --> Helper loaded: cookie_helper
INFO - 2023-10-20 05:53:30 --> Database Driver Class Initialized
INFO - 2023-10-20 05:53:30 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-20 05:53:30 --> Parser Class Initialized
INFO - 2023-10-20 05:53:30 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-20 05:53:30 --> Pagination Class Initialized
INFO - 2023-10-20 05:53:30 --> Form Validation Class Initialized
INFO - 2023-10-20 05:53:30 --> Controller Class Initialized
INFO - 2023-10-20 05:53:30 --> Model Class Initialized
DEBUG - 2023-10-20 05:53:30 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-10-20 05:53:30 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-20 05:53:30 --> Model Class Initialized
DEBUG - 2023-10-20 05:53:30 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-20 05:53:30 --> Model Class Initialized
INFO - 2023-10-20 05:53:30 --> Final output sent to browser
DEBUG - 2023-10-20 05:53:30 --> Total execution time: 0.0529
ERROR - 2023-10-20 05:53:33 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-20 05:53:33 --> Config Class Initialized
INFO - 2023-10-20 05:53:33 --> Hooks Class Initialized
DEBUG - 2023-10-20 05:53:33 --> UTF-8 Support Enabled
INFO - 2023-10-20 05:53:33 --> Utf8 Class Initialized
INFO - 2023-10-20 05:53:33 --> URI Class Initialized
INFO - 2023-10-20 05:53:33 --> Router Class Initialized
INFO - 2023-10-20 05:53:33 --> Output Class Initialized
INFO - 2023-10-20 05:53:33 --> Security Class Initialized
DEBUG - 2023-10-20 05:53:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-20 05:53:33 --> Input Class Initialized
INFO - 2023-10-20 05:53:33 --> Language Class Initialized
INFO - 2023-10-20 05:53:33 --> Loader Class Initialized
INFO - 2023-10-20 05:53:33 --> Helper loaded: url_helper
INFO - 2023-10-20 05:53:33 --> Helper loaded: file_helper
INFO - 2023-10-20 05:53:33 --> Helper loaded: html_helper
INFO - 2023-10-20 05:53:33 --> Helper loaded: text_helper
INFO - 2023-10-20 05:53:33 --> Helper loaded: form_helper
INFO - 2023-10-20 05:53:33 --> Helper loaded: lang_helper
INFO - 2023-10-20 05:53:33 --> Helper loaded: security_helper
INFO - 2023-10-20 05:53:33 --> Helper loaded: cookie_helper
INFO - 2023-10-20 05:53:33 --> Database Driver Class Initialized
INFO - 2023-10-20 05:53:33 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-20 05:53:33 --> Parser Class Initialized
INFO - 2023-10-20 05:53:33 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-20 05:53:33 --> Pagination Class Initialized
INFO - 2023-10-20 05:53:33 --> Form Validation Class Initialized
INFO - 2023-10-20 05:53:33 --> Controller Class Initialized
INFO - 2023-10-20 05:53:33 --> Model Class Initialized
DEBUG - 2023-10-20 05:53:33 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-10-20 05:53:33 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-20 05:53:33 --> Model Class Initialized
DEBUG - 2023-10-20 05:53:33 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-20 05:53:33 --> Model Class Initialized
INFO - 2023-10-20 05:53:33 --> Final output sent to browser
DEBUG - 2023-10-20 05:53:33 --> Total execution time: 0.0277
ERROR - 2023-10-20 05:53:34 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-20 05:53:34 --> Config Class Initialized
INFO - 2023-10-20 05:53:34 --> Hooks Class Initialized
DEBUG - 2023-10-20 05:53:34 --> UTF-8 Support Enabled
INFO - 2023-10-20 05:53:34 --> Utf8 Class Initialized
INFO - 2023-10-20 05:53:34 --> URI Class Initialized
INFO - 2023-10-20 05:53:34 --> Router Class Initialized
INFO - 2023-10-20 05:53:34 --> Output Class Initialized
INFO - 2023-10-20 05:53:34 --> Security Class Initialized
DEBUG - 2023-10-20 05:53:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-20 05:53:34 --> Input Class Initialized
INFO - 2023-10-20 05:53:34 --> Language Class Initialized
INFO - 2023-10-20 05:53:34 --> Loader Class Initialized
INFO - 2023-10-20 05:53:34 --> Helper loaded: url_helper
INFO - 2023-10-20 05:53:34 --> Helper loaded: file_helper
INFO - 2023-10-20 05:53:34 --> Helper loaded: html_helper
INFO - 2023-10-20 05:53:34 --> Helper loaded: text_helper
INFO - 2023-10-20 05:53:34 --> Helper loaded: form_helper
INFO - 2023-10-20 05:53:34 --> Helper loaded: lang_helper
INFO - 2023-10-20 05:53:34 --> Helper loaded: security_helper
INFO - 2023-10-20 05:53:34 --> Helper loaded: cookie_helper
INFO - 2023-10-20 05:53:34 --> Database Driver Class Initialized
INFO - 2023-10-20 05:53:34 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-20 05:53:34 --> Parser Class Initialized
INFO - 2023-10-20 05:53:34 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-20 05:53:34 --> Pagination Class Initialized
INFO - 2023-10-20 05:53:34 --> Form Validation Class Initialized
INFO - 2023-10-20 05:53:34 --> Controller Class Initialized
INFO - 2023-10-20 05:53:34 --> Model Class Initialized
DEBUG - 2023-10-20 05:53:34 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-10-20 05:53:34 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-20 05:53:34 --> Model Class Initialized
INFO - 2023-10-20 05:53:34 --> Model Class Initialized
INFO - 2023-10-20 05:53:34 --> Final output sent to browser
DEBUG - 2023-10-20 05:53:34 --> Total execution time: 0.0232
ERROR - 2023-10-20 05:53:36 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-20 05:53:36 --> Config Class Initialized
INFO - 2023-10-20 05:53:36 --> Hooks Class Initialized
DEBUG - 2023-10-20 05:53:36 --> UTF-8 Support Enabled
INFO - 2023-10-20 05:53:36 --> Utf8 Class Initialized
INFO - 2023-10-20 05:53:36 --> URI Class Initialized
INFO - 2023-10-20 05:53:36 --> Router Class Initialized
INFO - 2023-10-20 05:53:36 --> Output Class Initialized
INFO - 2023-10-20 05:53:36 --> Security Class Initialized
DEBUG - 2023-10-20 05:53:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-20 05:53:36 --> Input Class Initialized
INFO - 2023-10-20 05:53:36 --> Language Class Initialized
INFO - 2023-10-20 05:53:36 --> Loader Class Initialized
INFO - 2023-10-20 05:53:36 --> Helper loaded: url_helper
INFO - 2023-10-20 05:53:36 --> Helper loaded: file_helper
INFO - 2023-10-20 05:53:36 --> Helper loaded: html_helper
INFO - 2023-10-20 05:53:36 --> Helper loaded: text_helper
INFO - 2023-10-20 05:53:36 --> Helper loaded: form_helper
INFO - 2023-10-20 05:53:36 --> Helper loaded: lang_helper
INFO - 2023-10-20 05:53:36 --> Helper loaded: security_helper
INFO - 2023-10-20 05:53:36 --> Helper loaded: cookie_helper
INFO - 2023-10-20 05:53:36 --> Database Driver Class Initialized
INFO - 2023-10-20 05:53:36 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-20 05:53:36 --> Parser Class Initialized
INFO - 2023-10-20 05:53:36 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-20 05:53:36 --> Pagination Class Initialized
INFO - 2023-10-20 05:53:36 --> Form Validation Class Initialized
INFO - 2023-10-20 05:53:36 --> Controller Class Initialized
INFO - 2023-10-20 05:53:36 --> Model Class Initialized
DEBUG - 2023-10-20 05:53:36 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-10-20 05:53:36 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-20 05:53:36 --> Model Class Initialized
INFO - 2023-10-20 05:53:36 --> Final output sent to browser
DEBUG - 2023-10-20 05:53:36 --> Total execution time: 0.0180
ERROR - 2023-10-20 05:54:35 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-20 05:54:35 --> Config Class Initialized
INFO - 2023-10-20 05:54:35 --> Hooks Class Initialized
DEBUG - 2023-10-20 05:54:35 --> UTF-8 Support Enabled
INFO - 2023-10-20 05:54:35 --> Utf8 Class Initialized
INFO - 2023-10-20 05:54:35 --> URI Class Initialized
INFO - 2023-10-20 05:54:35 --> Router Class Initialized
INFO - 2023-10-20 05:54:35 --> Output Class Initialized
INFO - 2023-10-20 05:54:35 --> Security Class Initialized
DEBUG - 2023-10-20 05:54:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-20 05:54:35 --> Input Class Initialized
INFO - 2023-10-20 05:54:35 --> Language Class Initialized
INFO - 2023-10-20 05:54:35 --> Loader Class Initialized
INFO - 2023-10-20 05:54:35 --> Helper loaded: url_helper
INFO - 2023-10-20 05:54:35 --> Helper loaded: file_helper
INFO - 2023-10-20 05:54:35 --> Helper loaded: html_helper
INFO - 2023-10-20 05:54:35 --> Helper loaded: text_helper
INFO - 2023-10-20 05:54:35 --> Helper loaded: form_helper
INFO - 2023-10-20 05:54:35 --> Helper loaded: lang_helper
INFO - 2023-10-20 05:54:35 --> Helper loaded: security_helper
INFO - 2023-10-20 05:54:35 --> Helper loaded: cookie_helper
INFO - 2023-10-20 05:54:35 --> Database Driver Class Initialized
INFO - 2023-10-20 05:54:35 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-20 05:54:35 --> Parser Class Initialized
INFO - 2023-10-20 05:54:35 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-20 05:54:35 --> Pagination Class Initialized
INFO - 2023-10-20 05:54:35 --> Form Validation Class Initialized
INFO - 2023-10-20 05:54:35 --> Controller Class Initialized
INFO - 2023-10-20 05:54:35 --> Model Class Initialized
DEBUG - 2023-10-20 05:54:35 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-10-20 05:54:35 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-20 05:54:35 --> Model Class Initialized
DEBUG - 2023-10-20 05:54:35 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-20 05:54:35 --> Model Class Initialized
INFO - 2023-10-20 05:54:35 --> Email Class Initialized
DEBUG - 2023-10-20 05:54:35 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-20 05:54:35 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice_html_pdf.php
ERROR - 2023-10-20 05:54:35 --> Severity: Warning --> "continue" targeting switch is equivalent to "break". Did you mean to use "continue 2"? /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/dompdf.cls.php 743
ERROR - 2023-10-20 05:54:35 --> Severity: Warning --> "continue" targeting switch is equivalent to "break". Did you mean to use "continue 2"? /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/dompdf.cls.php 763
ERROR - 2023-10-20 05:54:35 --> Severity: Warning --> "continue" targeting switch is equivalent to "break". Did you mean to use "continue 2"? /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/stylesheet.cls.php 1102
ERROR - 2023-10-20 05:54:35 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/page_frame_decorator.cls.php 439
ERROR - 2023-10-20 05:54:35 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/page_frame_decorator.cls.php 439
ERROR - 2023-10-20 05:54:35 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/page_frame_decorator.cls.php 439
ERROR - 2023-10-20 05:54:35 --> Severity: Warning --> Division by zero /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 572
ERROR - 2023-10-20 05:54:35 --> Severity: Warning --> Division by zero /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 572
ERROR - 2023-10-20 05:54:35 --> Severity: Warning --> Division by zero /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 572
ERROR - 2023-10-20 05:54:35 --> Severity: Warning --> Division by zero /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 572
ERROR - 2023-10-20 05:54:35 --> Severity: Warning --> Division by zero /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 572
ERROR - 2023-10-20 05:54:35 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/table_cell_frame_reflower.cls.php 103
ERROR - 2023-10-20 05:54:35 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/table_cell_frame_reflower.cls.php 103
ERROR - 2023-10-20 05:54:35 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/table_cell_frame_reflower.cls.php 103
ERROR - 2023-10-20 05:54:35 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/table_cell_frame_reflower.cls.php 103
ERROR - 2023-10-20 05:54:35 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/table_cell_frame_reflower.cls.php 103
ERROR - 2023-10-20 05:54:35 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/table_cell_frame_reflower.cls.php 103
ERROR - 2023-10-20 05:54:35 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/table_cell_frame_reflower.cls.php 103
ERROR - 2023-10-20 05:54:35 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/table_cell_frame_reflower.cls.php 103
ERROR - 2023-10-20 05:54:35 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/table_cell_frame_reflower.cls.php 103
ERROR - 2023-10-20 05:54:35 --> Severity: Warning --> Invalid argument supplied for foreach() /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 709
ERROR - 2023-10-20 05:54:35 --> Severity: Warning --> Invalid argument supplied for foreach() /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 709
ERROR - 2023-10-20 05:54:35 --> Severity: Warning --> Invalid argument supplied for foreach() /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 709
ERROR - 2023-10-20 05:54:35 --> Severity: Warning --> Invalid argument supplied for foreach() /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 709
ERROR - 2023-10-20 05:54:35 --> Severity: Warning --> Invalid argument supplied for foreach() /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 709
ERROR - 2023-10-20 05:54:35 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-10-20 05:54:35 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-10-20 05:54:35 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-10-20 05:54:35 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-10-20 05:54:35 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-10-20 05:54:35 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-10-20 05:54:35 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-10-20 05:54:35 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-10-20 05:54:35 --> Severity: Warning --> "continue" targeting switch is equivalent to "break". Did you mean to use "continue 2"? /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/text_renderer.cls.php 126
ERROR - 2023-10-20 05:54:35 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-10-20 05:54:35 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-10-20 05:54:35 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-10-20 05:54:35 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-10-20 05:54:35 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-10-20 05:54:35 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-10-20 05:54:35 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-10-20 05:54:35 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-10-20 05:54:35 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-10-20 05:54:35 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-10-20 05:54:35 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-10-20 05:54:35 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-10-20 05:54:35 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-10-20 05:54:35 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-10-20 05:54:35 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-10-20 05:54:35 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-10-20 05:54:35 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-10-20 05:54:35 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-10-20 05:54:35 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-10-20 05:54:35 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-10-20 05:54:35 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-10-20 05:54:35 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-10-20 05:54:35 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-10-20 05:54:35 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-10-20 05:54:35 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-10-20 05:54:35 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-10-20 05:54:35 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-10-20 05:54:35 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-10-20 05:54:35 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-10-20 05:54:35 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-10-20 05:54:35 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-10-20 05:54:35 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-10-20 05:54:35 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-10-20 05:54:35 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-10-20 05:54:35 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-10-20 05:54:35 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-10-20 05:54:35 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-10-20 05:54:35 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-10-20 05:54:35 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-10-20 05:54:35 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-10-20 05:54:35 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-10-20 05:54:35 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-10-20 05:54:35 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-10-20 05:54:35 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-10-20 05:54:35 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-10-20 05:54:35 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-10-20 05:54:35 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-10-20 05:54:35 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-10-20 05:54:35 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-10-20 05:54:35 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-10-20 05:54:35 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-10-20 05:54:35 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-10-20 05:54:35 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-10-20 05:54:35 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-10-20 05:54:35 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-10-20 05:54:35 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-10-20 05:54:35 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-10-20 05:54:35 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-10-20 05:54:35 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-10-20 05:54:35 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-10-20 05:54:35 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-10-20 05:54:35 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-10-20 05:54:35 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-10-20 05:54:35 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-10-20 05:54:35 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-10-20 05:54:35 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-10-20 05:54:35 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-10-20 05:54:35 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-10-20 05:54:35 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-10-20 05:54:35 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-10-20 05:54:35 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-10-20 05:54:35 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-10-20 05:54:35 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-10-20 05:54:35 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-10-20 05:54:35 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-10-20 05:54:35 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-10-20 05:54:35 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-10-20 05:54:35 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-10-20 05:54:35 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-10-20 05:54:35 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-10-20 05:54:35 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-10-20 05:54:35 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-10-20 05:54:35 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-10-20 05:54:35 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-10-20 05:54:35 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-10-20 05:54:35 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-10-20 05:54:35 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-10-20 05:54:35 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-10-20 05:54:35 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-10-20 05:54:35 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-10-20 05:54:35 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-10-20 05:54:35 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-10-20 05:54:35 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-10-20 05:54:35 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-10-20 05:54:35 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-10-20 05:54:35 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-10-20 05:54:35 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-10-20 05:54:35 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-10-20 05:54:35 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-10-20 05:54:35 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-10-20 05:54:35 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-10-20 05:54:35 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-10-20 05:54:35 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-10-20 05:54:35 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
INFO - 2023-10-20 05:54:36 --> Language file loaded: language/english/email_lang.php
INFO - 2023-10-20 05:54:36 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice_html.php
INFO - 2023-10-20 05:54:36 --> Final output sent to browser
DEBUG - 2023-10-20 05:54:36 --> Total execution time: 0.5552
ERROR - 2023-10-20 05:54:37 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-20 05:54:37 --> Config Class Initialized
INFO - 2023-10-20 05:54:37 --> Hooks Class Initialized
DEBUG - 2023-10-20 05:54:37 --> UTF-8 Support Enabled
INFO - 2023-10-20 05:54:37 --> Utf8 Class Initialized
INFO - 2023-10-20 05:54:37 --> URI Class Initialized
INFO - 2023-10-20 05:54:37 --> Router Class Initialized
INFO - 2023-10-20 05:54:37 --> Output Class Initialized
INFO - 2023-10-20 05:54:37 --> Security Class Initialized
DEBUG - 2023-10-20 05:54:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-20 05:54:37 --> Input Class Initialized
INFO - 2023-10-20 05:54:37 --> Language Class Initialized
INFO - 2023-10-20 05:54:37 --> Loader Class Initialized
INFO - 2023-10-20 05:54:37 --> Helper loaded: url_helper
INFO - 2023-10-20 05:54:37 --> Helper loaded: file_helper
INFO - 2023-10-20 05:54:37 --> Helper loaded: html_helper
INFO - 2023-10-20 05:54:37 --> Helper loaded: text_helper
INFO - 2023-10-20 05:54:37 --> Helper loaded: form_helper
INFO - 2023-10-20 05:54:37 --> Helper loaded: lang_helper
INFO - 2023-10-20 05:54:37 --> Helper loaded: security_helper
INFO - 2023-10-20 05:54:37 --> Helper loaded: cookie_helper
INFO - 2023-10-20 05:54:37 --> Database Driver Class Initialized
INFO - 2023-10-20 05:54:37 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-20 05:54:37 --> Parser Class Initialized
INFO - 2023-10-20 05:54:37 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-20 05:54:37 --> Pagination Class Initialized
INFO - 2023-10-20 05:54:37 --> Form Validation Class Initialized
INFO - 2023-10-20 05:54:37 --> Controller Class Initialized
INFO - 2023-10-20 05:54:37 --> Model Class Initialized
DEBUG - 2023-10-20 05:54:37 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-10-20 05:54:37 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-20 05:54:37 --> Model Class Initialized
DEBUG - 2023-10-20 05:54:37 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-20 05:54:37 --> Model Class Initialized
INFO - 2023-10-20 05:54:37 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/add_invoice_form.php
DEBUG - 2023-10-20 05:54:37 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-10-20 05:54:37 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-10-20 05:54:37 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-10-20 05:54:37 --> Model Class Initialized
INFO - 2023-10-20 05:54:37 --> Model Class Initialized
INFO - 2023-10-20 05:54:37 --> Model Class Initialized
INFO - 2023-10-20 05:54:37 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-10-20 05:54:37 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-10-20 05:54:37 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-10-20 05:54:37 --> Final output sent to browser
DEBUG - 2023-10-20 05:54:37 --> Total execution time: 0.1570
ERROR - 2023-10-20 05:54:40 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-20 05:54:40 --> Config Class Initialized
INFO - 2023-10-20 05:54:40 --> Hooks Class Initialized
DEBUG - 2023-10-20 05:54:40 --> UTF-8 Support Enabled
INFO - 2023-10-20 05:54:40 --> Utf8 Class Initialized
INFO - 2023-10-20 05:54:40 --> URI Class Initialized
DEBUG - 2023-10-20 05:54:40 --> No URI present. Default controller set.
INFO - 2023-10-20 05:54:40 --> Router Class Initialized
INFO - 2023-10-20 05:54:40 --> Output Class Initialized
INFO - 2023-10-20 05:54:40 --> Security Class Initialized
DEBUG - 2023-10-20 05:54:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-20 05:54:40 --> Input Class Initialized
INFO - 2023-10-20 05:54:40 --> Language Class Initialized
INFO - 2023-10-20 05:54:40 --> Loader Class Initialized
INFO - 2023-10-20 05:54:40 --> Helper loaded: url_helper
INFO - 2023-10-20 05:54:40 --> Helper loaded: file_helper
INFO - 2023-10-20 05:54:40 --> Helper loaded: html_helper
INFO - 2023-10-20 05:54:40 --> Helper loaded: text_helper
INFO - 2023-10-20 05:54:40 --> Helper loaded: form_helper
INFO - 2023-10-20 05:54:40 --> Helper loaded: lang_helper
INFO - 2023-10-20 05:54:40 --> Helper loaded: security_helper
INFO - 2023-10-20 05:54:40 --> Helper loaded: cookie_helper
INFO - 2023-10-20 05:54:40 --> Database Driver Class Initialized
INFO - 2023-10-20 05:54:40 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-20 05:54:40 --> Parser Class Initialized
INFO - 2023-10-20 05:54:40 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-20 05:54:40 --> Pagination Class Initialized
INFO - 2023-10-20 05:54:40 --> Form Validation Class Initialized
INFO - 2023-10-20 05:54:40 --> Controller Class Initialized
INFO - 2023-10-20 05:54:40 --> Model Class Initialized
DEBUG - 2023-10-20 05:54:40 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-20 05:54:40 --> Model Class Initialized
DEBUG - 2023-10-20 05:54:40 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-20 05:54:40 --> Model Class Initialized
INFO - 2023-10-20 05:54:40 --> Model Class Initialized
INFO - 2023-10-20 05:54:40 --> Model Class Initialized
INFO - 2023-10-20 05:54:40 --> Model Class Initialized
DEBUG - 2023-10-20 05:54:40 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-10-20 05:54:40 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-20 05:54:40 --> Model Class Initialized
INFO - 2023-10-20 05:54:40 --> Model Class Initialized
INFO - 2023-10-20 05:54:40 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-10-20 05:54:40 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-10-20 05:54:40 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-10-20 05:54:40 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-10-20 05:54:40 --> Model Class Initialized
INFO - 2023-10-20 05:54:40 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-10-20 05:54:40 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-10-20 05:54:40 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-10-20 05:54:40 --> Final output sent to browser
DEBUG - 2023-10-20 05:54:40 --> Total execution time: 0.1965
ERROR - 2023-10-20 05:57:47 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-20 05:57:47 --> Config Class Initialized
INFO - 2023-10-20 05:57:47 --> Hooks Class Initialized
DEBUG - 2023-10-20 05:57:47 --> UTF-8 Support Enabled
INFO - 2023-10-20 05:57:47 --> Utf8 Class Initialized
INFO - 2023-10-20 05:57:47 --> URI Class Initialized
INFO - 2023-10-20 05:57:47 --> Router Class Initialized
INFO - 2023-10-20 05:57:47 --> Output Class Initialized
INFO - 2023-10-20 05:57:47 --> Security Class Initialized
DEBUG - 2023-10-20 05:57:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-20 05:57:47 --> Input Class Initialized
INFO - 2023-10-20 05:57:47 --> Language Class Initialized
INFO - 2023-10-20 05:57:47 --> Loader Class Initialized
INFO - 2023-10-20 05:57:47 --> Helper loaded: url_helper
INFO - 2023-10-20 05:57:47 --> Helper loaded: file_helper
INFO - 2023-10-20 05:57:47 --> Helper loaded: html_helper
INFO - 2023-10-20 05:57:47 --> Helper loaded: text_helper
INFO - 2023-10-20 05:57:47 --> Helper loaded: form_helper
INFO - 2023-10-20 05:57:47 --> Helper loaded: lang_helper
INFO - 2023-10-20 05:57:47 --> Helper loaded: security_helper
INFO - 2023-10-20 05:57:47 --> Helper loaded: cookie_helper
INFO - 2023-10-20 05:57:47 --> Database Driver Class Initialized
INFO - 2023-10-20 05:57:47 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-20 05:57:47 --> Parser Class Initialized
INFO - 2023-10-20 05:57:47 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-20 05:57:47 --> Pagination Class Initialized
INFO - 2023-10-20 05:57:47 --> Form Validation Class Initialized
INFO - 2023-10-20 05:57:47 --> Controller Class Initialized
INFO - 2023-10-20 05:57:47 --> Model Class Initialized
DEBUG - 2023-10-20 05:57:47 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-10-20 05:57:47 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-20 05:57:47 --> Model Class Initialized
DEBUG - 2023-10-20 05:57:47 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-20 05:57:47 --> Model Class Initialized
INFO - 2023-10-20 05:57:47 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/invoice/invoice.php
DEBUG - 2023-10-20 05:57:47 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-10-20 05:57:47 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-10-20 05:57:47 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-10-20 05:57:47 --> Model Class Initialized
INFO - 2023-10-20 05:57:47 --> Model Class Initialized
INFO - 2023-10-20 05:57:47 --> Model Class Initialized
INFO - 2023-10-20 05:57:47 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-10-20 05:57:47 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-10-20 05:57:47 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-10-20 05:57:47 --> Final output sent to browser
DEBUG - 2023-10-20 05:57:47 --> Total execution time: 0.1393
ERROR - 2023-10-20 05:57:48 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-20 05:57:48 --> Config Class Initialized
INFO - 2023-10-20 05:57:48 --> Hooks Class Initialized
DEBUG - 2023-10-20 05:57:48 --> UTF-8 Support Enabled
INFO - 2023-10-20 05:57:48 --> Utf8 Class Initialized
INFO - 2023-10-20 05:57:48 --> URI Class Initialized
INFO - 2023-10-20 05:57:48 --> Router Class Initialized
INFO - 2023-10-20 05:57:48 --> Output Class Initialized
INFO - 2023-10-20 05:57:48 --> Security Class Initialized
DEBUG - 2023-10-20 05:57:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-20 05:57:48 --> Input Class Initialized
INFO - 2023-10-20 05:57:48 --> Language Class Initialized
INFO - 2023-10-20 05:57:48 --> Loader Class Initialized
INFO - 2023-10-20 05:57:48 --> Helper loaded: url_helper
INFO - 2023-10-20 05:57:48 --> Helper loaded: file_helper
INFO - 2023-10-20 05:57:48 --> Helper loaded: html_helper
INFO - 2023-10-20 05:57:48 --> Helper loaded: text_helper
INFO - 2023-10-20 05:57:48 --> Helper loaded: form_helper
INFO - 2023-10-20 05:57:48 --> Helper loaded: lang_helper
INFO - 2023-10-20 05:57:48 --> Helper loaded: security_helper
INFO - 2023-10-20 05:57:48 --> Helper loaded: cookie_helper
INFO - 2023-10-20 05:57:48 --> Database Driver Class Initialized
INFO - 2023-10-20 05:57:48 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-20 05:57:48 --> Parser Class Initialized
INFO - 2023-10-20 05:57:48 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-20 05:57:48 --> Pagination Class Initialized
INFO - 2023-10-20 05:57:48 --> Form Validation Class Initialized
INFO - 2023-10-20 05:57:48 --> Controller Class Initialized
INFO - 2023-10-20 05:57:48 --> Model Class Initialized
DEBUG - 2023-10-20 05:57:48 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-10-20 05:57:48 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-20 05:57:48 --> Model Class Initialized
DEBUG - 2023-10-20 05:57:48 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-20 05:57:48 --> Model Class Initialized
INFO - 2023-10-20 05:57:48 --> Final output sent to browser
DEBUG - 2023-10-20 05:57:48 --> Total execution time: 0.0513
ERROR - 2023-10-20 05:58:29 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-20 05:58:29 --> Config Class Initialized
INFO - 2023-10-20 05:58:29 --> Hooks Class Initialized
DEBUG - 2023-10-20 05:58:29 --> UTF-8 Support Enabled
INFO - 2023-10-20 05:58:29 --> Utf8 Class Initialized
INFO - 2023-10-20 05:58:29 --> URI Class Initialized
DEBUG - 2023-10-20 05:58:29 --> No URI present. Default controller set.
INFO - 2023-10-20 05:58:29 --> Router Class Initialized
INFO - 2023-10-20 05:58:29 --> Output Class Initialized
INFO - 2023-10-20 05:58:29 --> Security Class Initialized
DEBUG - 2023-10-20 05:58:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-20 05:58:29 --> Input Class Initialized
INFO - 2023-10-20 05:58:29 --> Language Class Initialized
INFO - 2023-10-20 05:58:29 --> Loader Class Initialized
INFO - 2023-10-20 05:58:29 --> Helper loaded: url_helper
INFO - 2023-10-20 05:58:29 --> Helper loaded: file_helper
INFO - 2023-10-20 05:58:29 --> Helper loaded: html_helper
INFO - 2023-10-20 05:58:29 --> Helper loaded: text_helper
INFO - 2023-10-20 05:58:29 --> Helper loaded: form_helper
INFO - 2023-10-20 05:58:29 --> Helper loaded: lang_helper
INFO - 2023-10-20 05:58:29 --> Helper loaded: security_helper
INFO - 2023-10-20 05:58:29 --> Helper loaded: cookie_helper
INFO - 2023-10-20 05:58:29 --> Database Driver Class Initialized
INFO - 2023-10-20 05:58:29 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-20 05:58:29 --> Parser Class Initialized
INFO - 2023-10-20 05:58:29 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-20 05:58:29 --> Pagination Class Initialized
INFO - 2023-10-20 05:58:29 --> Form Validation Class Initialized
INFO - 2023-10-20 05:58:29 --> Controller Class Initialized
INFO - 2023-10-20 05:58:29 --> Model Class Initialized
DEBUG - 2023-10-20 05:58:29 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-20 05:58:29 --> Model Class Initialized
DEBUG - 2023-10-20 05:58:29 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-20 05:58:29 --> Model Class Initialized
INFO - 2023-10-20 05:58:29 --> Model Class Initialized
INFO - 2023-10-20 05:58:29 --> Model Class Initialized
INFO - 2023-10-20 05:58:29 --> Model Class Initialized
DEBUG - 2023-10-20 05:58:29 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-10-20 05:58:29 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-20 05:58:29 --> Model Class Initialized
INFO - 2023-10-20 05:58:29 --> Model Class Initialized
INFO - 2023-10-20 05:58:29 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-10-20 05:58:29 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-10-20 05:58:29 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-10-20 05:58:29 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-10-20 05:58:29 --> Model Class Initialized
INFO - 2023-10-20 05:58:29 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-10-20 05:58:29 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-10-20 05:58:29 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-10-20 05:58:29 --> Final output sent to browser
DEBUG - 2023-10-20 05:58:29 --> Total execution time: 0.2088
ERROR - 2023-10-20 05:58:30 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-20 05:58:30 --> Config Class Initialized
INFO - 2023-10-20 05:58:30 --> Hooks Class Initialized
DEBUG - 2023-10-20 05:58:30 --> UTF-8 Support Enabled
INFO - 2023-10-20 05:58:30 --> Utf8 Class Initialized
INFO - 2023-10-20 05:58:30 --> URI Class Initialized
INFO - 2023-10-20 05:58:30 --> Router Class Initialized
INFO - 2023-10-20 05:58:30 --> Output Class Initialized
INFO - 2023-10-20 05:58:30 --> Security Class Initialized
DEBUG - 2023-10-20 05:58:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-20 05:58:30 --> Input Class Initialized
INFO - 2023-10-20 05:58:30 --> Language Class Initialized
INFO - 2023-10-20 05:58:30 --> Loader Class Initialized
INFO - 2023-10-20 05:58:30 --> Helper loaded: url_helper
INFO - 2023-10-20 05:58:30 --> Helper loaded: file_helper
INFO - 2023-10-20 05:58:30 --> Helper loaded: html_helper
INFO - 2023-10-20 05:58:30 --> Helper loaded: text_helper
INFO - 2023-10-20 05:58:30 --> Helper loaded: form_helper
INFO - 2023-10-20 05:58:30 --> Helper loaded: lang_helper
INFO - 2023-10-20 05:58:30 --> Helper loaded: security_helper
INFO - 2023-10-20 05:58:30 --> Helper loaded: cookie_helper
INFO - 2023-10-20 05:58:30 --> Database Driver Class Initialized
INFO - 2023-10-20 05:58:30 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-20 05:58:30 --> Parser Class Initialized
INFO - 2023-10-20 05:58:30 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-20 05:58:30 --> Pagination Class Initialized
INFO - 2023-10-20 05:58:30 --> Form Validation Class Initialized
INFO - 2023-10-20 05:58:30 --> Controller Class Initialized
INFO - 2023-10-20 05:58:30 --> Model Class Initialized
DEBUG - 2023-10-20 05:58:30 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-20 05:58:30 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2023-10-20 05:58:30 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-10-20 05:58:30 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-10-20 05:58:30 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-10-20 05:58:30 --> Model Class Initialized
INFO - 2023-10-20 05:58:30 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-10-20 05:58:30 --> Final output sent to browser
DEBUG - 2023-10-20 05:58:30 --> Total execution time: 0.0279
ERROR - 2023-10-20 05:58:31 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-20 05:58:31 --> Config Class Initialized
INFO - 2023-10-20 05:58:31 --> Hooks Class Initialized
DEBUG - 2023-10-20 05:58:31 --> UTF-8 Support Enabled
INFO - 2023-10-20 05:58:31 --> Utf8 Class Initialized
INFO - 2023-10-20 05:58:31 --> URI Class Initialized
INFO - 2023-10-20 05:58:31 --> Router Class Initialized
INFO - 2023-10-20 05:58:31 --> Output Class Initialized
INFO - 2023-10-20 05:58:31 --> Security Class Initialized
DEBUG - 2023-10-20 05:58:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-20 05:58:31 --> Input Class Initialized
INFO - 2023-10-20 05:58:31 --> Language Class Initialized
INFO - 2023-10-20 05:58:31 --> Loader Class Initialized
INFO - 2023-10-20 05:58:31 --> Helper loaded: url_helper
INFO - 2023-10-20 05:58:31 --> Helper loaded: file_helper
INFO - 2023-10-20 05:58:31 --> Helper loaded: html_helper
INFO - 2023-10-20 05:58:31 --> Helper loaded: text_helper
INFO - 2023-10-20 05:58:31 --> Helper loaded: form_helper
INFO - 2023-10-20 05:58:31 --> Helper loaded: lang_helper
INFO - 2023-10-20 05:58:31 --> Helper loaded: security_helper
INFO - 2023-10-20 05:58:31 --> Helper loaded: cookie_helper
INFO - 2023-10-20 05:58:31 --> Database Driver Class Initialized
INFO - 2023-10-20 05:58:31 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-20 05:58:31 --> Parser Class Initialized
INFO - 2023-10-20 05:58:31 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-20 05:58:31 --> Pagination Class Initialized
INFO - 2023-10-20 05:58:31 --> Form Validation Class Initialized
INFO - 2023-10-20 05:58:31 --> Controller Class Initialized
INFO - 2023-10-20 05:58:31 --> Model Class Initialized
DEBUG - 2023-10-20 05:58:31 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-20 05:58:31 --> Model Class Initialized
DEBUG - 2023-10-20 05:58:31 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-20 05:58:31 --> Model Class Initialized
INFO - 2023-10-20 05:58:31 --> Model Class Initialized
INFO - 2023-10-20 05:58:31 --> Model Class Initialized
INFO - 2023-10-20 05:58:31 --> Model Class Initialized
DEBUG - 2023-10-20 05:58:31 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-10-20 05:58:31 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-20 05:58:31 --> Model Class Initialized
INFO - 2023-10-20 05:58:31 --> Model Class Initialized
INFO - 2023-10-20 05:58:31 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-10-20 05:58:31 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-10-20 05:58:31 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-10-20 05:58:31 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-10-20 05:58:31 --> Model Class Initialized
INFO - 2023-10-20 05:58:31 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-10-20 05:58:31 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-10-20 05:58:31 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-10-20 05:58:31 --> Final output sent to browser
DEBUG - 2023-10-20 05:58:31 --> Total execution time: 0.1932
ERROR - 2023-10-20 05:59:13 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-20 05:59:13 --> Config Class Initialized
INFO - 2023-10-20 05:59:13 --> Hooks Class Initialized
DEBUG - 2023-10-20 05:59:13 --> UTF-8 Support Enabled
INFO - 2023-10-20 05:59:13 --> Utf8 Class Initialized
INFO - 2023-10-20 05:59:13 --> URI Class Initialized
INFO - 2023-10-20 05:59:13 --> Router Class Initialized
INFO - 2023-10-20 05:59:13 --> Output Class Initialized
INFO - 2023-10-20 05:59:13 --> Security Class Initialized
DEBUG - 2023-10-20 05:59:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-20 05:59:13 --> Input Class Initialized
INFO - 2023-10-20 05:59:13 --> Language Class Initialized
INFO - 2023-10-20 05:59:13 --> Loader Class Initialized
INFO - 2023-10-20 05:59:13 --> Helper loaded: url_helper
INFO - 2023-10-20 05:59:13 --> Helper loaded: file_helper
INFO - 2023-10-20 05:59:13 --> Helper loaded: html_helper
INFO - 2023-10-20 05:59:13 --> Helper loaded: text_helper
INFO - 2023-10-20 05:59:13 --> Helper loaded: form_helper
INFO - 2023-10-20 05:59:13 --> Helper loaded: lang_helper
INFO - 2023-10-20 05:59:13 --> Helper loaded: security_helper
INFO - 2023-10-20 05:59:13 --> Helper loaded: cookie_helper
INFO - 2023-10-20 05:59:14 --> Database Driver Class Initialized
INFO - 2023-10-20 05:59:14 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-20 05:59:14 --> Parser Class Initialized
INFO - 2023-10-20 05:59:14 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-20 05:59:14 --> Pagination Class Initialized
INFO - 2023-10-20 05:59:14 --> Form Validation Class Initialized
INFO - 2023-10-20 05:59:14 --> Controller Class Initialized
INFO - 2023-10-20 05:59:14 --> Model Class Initialized
DEBUG - 2023-10-20 05:59:14 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-10-20 05:59:14 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-20 05:59:14 --> Model Class Initialized
DEBUG - 2023-10-20 05:59:14 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-20 05:59:14 --> Model Class Initialized
INFO - 2023-10-20 05:59:14 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice.php
DEBUG - 2023-10-20 05:59:14 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-10-20 05:59:14 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-10-20 05:59:14 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-10-20 05:59:14 --> Model Class Initialized
INFO - 2023-10-20 05:59:14 --> Model Class Initialized
INFO - 2023-10-20 05:59:14 --> Model Class Initialized
INFO - 2023-10-20 05:59:14 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-10-20 05:59:14 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-10-20 05:59:14 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-10-20 05:59:14 --> Final output sent to browser
DEBUG - 2023-10-20 05:59:14 --> Total execution time: 0.1451
ERROR - 2023-10-20 05:59:15 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-20 05:59:15 --> Config Class Initialized
INFO - 2023-10-20 05:59:15 --> Hooks Class Initialized
DEBUG - 2023-10-20 05:59:15 --> UTF-8 Support Enabled
INFO - 2023-10-20 05:59:15 --> Utf8 Class Initialized
INFO - 2023-10-20 05:59:15 --> URI Class Initialized
INFO - 2023-10-20 05:59:15 --> Router Class Initialized
INFO - 2023-10-20 05:59:15 --> Output Class Initialized
INFO - 2023-10-20 05:59:15 --> Security Class Initialized
DEBUG - 2023-10-20 05:59:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-20 05:59:15 --> Input Class Initialized
INFO - 2023-10-20 05:59:15 --> Language Class Initialized
INFO - 2023-10-20 05:59:15 --> Loader Class Initialized
INFO - 2023-10-20 05:59:15 --> Helper loaded: url_helper
INFO - 2023-10-20 05:59:15 --> Helper loaded: file_helper
INFO - 2023-10-20 05:59:15 --> Helper loaded: html_helper
INFO - 2023-10-20 05:59:15 --> Helper loaded: text_helper
INFO - 2023-10-20 05:59:15 --> Helper loaded: form_helper
INFO - 2023-10-20 05:59:15 --> Helper loaded: lang_helper
INFO - 2023-10-20 05:59:15 --> Helper loaded: security_helper
INFO - 2023-10-20 05:59:15 --> Helper loaded: cookie_helper
INFO - 2023-10-20 05:59:15 --> Database Driver Class Initialized
INFO - 2023-10-20 05:59:15 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-20 05:59:15 --> Parser Class Initialized
INFO - 2023-10-20 05:59:15 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-20 05:59:15 --> Pagination Class Initialized
INFO - 2023-10-20 05:59:15 --> Form Validation Class Initialized
INFO - 2023-10-20 05:59:15 --> Controller Class Initialized
INFO - 2023-10-20 05:59:15 --> Model Class Initialized
DEBUG - 2023-10-20 05:59:15 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-10-20 05:59:15 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-20 05:59:15 --> Model Class Initialized
DEBUG - 2023-10-20 05:59:15 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-20 05:59:15 --> Model Class Initialized
INFO - 2023-10-20 05:59:15 --> Final output sent to browser
DEBUG - 2023-10-20 05:59:15 --> Total execution time: 0.0416
ERROR - 2023-10-20 05:59:27 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-20 05:59:27 --> Config Class Initialized
INFO - 2023-10-20 05:59:27 --> Hooks Class Initialized
DEBUG - 2023-10-20 05:59:27 --> UTF-8 Support Enabled
INFO - 2023-10-20 05:59:27 --> Utf8 Class Initialized
INFO - 2023-10-20 05:59:27 --> URI Class Initialized
INFO - 2023-10-20 05:59:27 --> Router Class Initialized
INFO - 2023-10-20 05:59:27 --> Output Class Initialized
INFO - 2023-10-20 05:59:27 --> Security Class Initialized
DEBUG - 2023-10-20 05:59:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-20 05:59:27 --> Input Class Initialized
INFO - 2023-10-20 05:59:27 --> Language Class Initialized
INFO - 2023-10-20 05:59:27 --> Loader Class Initialized
INFO - 2023-10-20 05:59:27 --> Helper loaded: url_helper
INFO - 2023-10-20 05:59:27 --> Helper loaded: file_helper
INFO - 2023-10-20 05:59:27 --> Helper loaded: html_helper
INFO - 2023-10-20 05:59:27 --> Helper loaded: text_helper
INFO - 2023-10-20 05:59:27 --> Helper loaded: form_helper
INFO - 2023-10-20 05:59:27 --> Helper loaded: lang_helper
INFO - 2023-10-20 05:59:27 --> Helper loaded: security_helper
INFO - 2023-10-20 05:59:27 --> Helper loaded: cookie_helper
INFO - 2023-10-20 05:59:27 --> Database Driver Class Initialized
INFO - 2023-10-20 05:59:27 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-20 05:59:27 --> Parser Class Initialized
INFO - 2023-10-20 05:59:27 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-20 05:59:27 --> Pagination Class Initialized
INFO - 2023-10-20 05:59:27 --> Form Validation Class Initialized
INFO - 2023-10-20 05:59:27 --> Controller Class Initialized
INFO - 2023-10-20 05:59:27 --> Model Class Initialized
DEBUG - 2023-10-20 05:59:27 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-10-20 05:59:27 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-20 05:59:27 --> Model Class Initialized
DEBUG - 2023-10-20 05:59:27 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-20 05:59:27 --> Model Class Initialized
INFO - 2023-10-20 05:59:27 --> Final output sent to browser
DEBUG - 2023-10-20 05:59:27 --> Total execution time: 0.0445
ERROR - 2023-10-20 05:59:39 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-20 05:59:39 --> Config Class Initialized
INFO - 2023-10-20 05:59:39 --> Hooks Class Initialized
DEBUG - 2023-10-20 05:59:39 --> UTF-8 Support Enabled
INFO - 2023-10-20 05:59:39 --> Utf8 Class Initialized
INFO - 2023-10-20 05:59:39 --> URI Class Initialized
INFO - 2023-10-20 05:59:39 --> Router Class Initialized
INFO - 2023-10-20 05:59:39 --> Output Class Initialized
INFO - 2023-10-20 05:59:39 --> Security Class Initialized
DEBUG - 2023-10-20 05:59:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-20 05:59:39 --> Input Class Initialized
INFO - 2023-10-20 05:59:39 --> Language Class Initialized
INFO - 2023-10-20 05:59:39 --> Loader Class Initialized
INFO - 2023-10-20 05:59:39 --> Helper loaded: url_helper
INFO - 2023-10-20 05:59:39 --> Helper loaded: file_helper
INFO - 2023-10-20 05:59:39 --> Helper loaded: html_helper
INFO - 2023-10-20 05:59:39 --> Helper loaded: text_helper
INFO - 2023-10-20 05:59:39 --> Helper loaded: form_helper
INFO - 2023-10-20 05:59:39 --> Helper loaded: lang_helper
INFO - 2023-10-20 05:59:39 --> Helper loaded: security_helper
INFO - 2023-10-20 05:59:39 --> Helper loaded: cookie_helper
INFO - 2023-10-20 05:59:39 --> Database Driver Class Initialized
INFO - 2023-10-20 05:59:39 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-20 05:59:39 --> Parser Class Initialized
INFO - 2023-10-20 05:59:39 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-20 05:59:39 --> Pagination Class Initialized
INFO - 2023-10-20 05:59:39 --> Form Validation Class Initialized
INFO - 2023-10-20 05:59:39 --> Controller Class Initialized
INFO - 2023-10-20 05:59:39 --> Model Class Initialized
DEBUG - 2023-10-20 05:59:39 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-10-20 05:59:39 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-20 05:59:39 --> Model Class Initialized
DEBUG - 2023-10-20 05:59:39 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-20 05:59:39 --> Model Class Initialized
DEBUG - 2023-10-20 05:59:39 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-20 05:59:39 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice_html.php
DEBUG - 2023-10-20 05:59:39 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-10-20 05:59:39 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-10-20 05:59:39 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-10-20 05:59:39 --> Model Class Initialized
INFO - 2023-10-20 05:59:39 --> Model Class Initialized
INFO - 2023-10-20 05:59:39 --> Model Class Initialized
INFO - 2023-10-20 05:59:40 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-10-20 05:59:40 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-10-20 05:59:40 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-10-20 05:59:40 --> Final output sent to browser
DEBUG - 2023-10-20 05:59:40 --> Total execution time: 0.1388
ERROR - 2023-10-20 05:59:55 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-20 05:59:55 --> Config Class Initialized
INFO - 2023-10-20 05:59:55 --> Hooks Class Initialized
DEBUG - 2023-10-20 05:59:55 --> UTF-8 Support Enabled
INFO - 2023-10-20 05:59:55 --> Utf8 Class Initialized
INFO - 2023-10-20 05:59:55 --> URI Class Initialized
INFO - 2023-10-20 05:59:55 --> Router Class Initialized
INFO - 2023-10-20 05:59:55 --> Output Class Initialized
INFO - 2023-10-20 05:59:55 --> Security Class Initialized
DEBUG - 2023-10-20 05:59:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-20 05:59:55 --> Input Class Initialized
INFO - 2023-10-20 05:59:55 --> Language Class Initialized
INFO - 2023-10-20 05:59:55 --> Loader Class Initialized
INFO - 2023-10-20 05:59:55 --> Helper loaded: url_helper
INFO - 2023-10-20 05:59:55 --> Helper loaded: file_helper
INFO - 2023-10-20 05:59:55 --> Helper loaded: html_helper
INFO - 2023-10-20 05:59:55 --> Helper loaded: text_helper
INFO - 2023-10-20 05:59:55 --> Helper loaded: form_helper
INFO - 2023-10-20 05:59:55 --> Helper loaded: lang_helper
INFO - 2023-10-20 05:59:55 --> Helper loaded: security_helper
INFO - 2023-10-20 05:59:55 --> Helper loaded: cookie_helper
INFO - 2023-10-20 05:59:55 --> Database Driver Class Initialized
INFO - 2023-10-20 05:59:55 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-20 05:59:55 --> Parser Class Initialized
INFO - 2023-10-20 05:59:55 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-20 05:59:55 --> Pagination Class Initialized
INFO - 2023-10-20 05:59:55 --> Form Validation Class Initialized
INFO - 2023-10-20 05:59:55 --> Controller Class Initialized
INFO - 2023-10-20 05:59:55 --> Model Class Initialized
DEBUG - 2023-10-20 05:59:55 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-10-20 05:59:55 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-20 05:59:55 --> Model Class Initialized
DEBUG - 2023-10-20 05:59:55 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-20 05:59:55 --> Model Class Initialized
INFO - 2023-10-20 05:59:55 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice.php
DEBUG - 2023-10-20 05:59:55 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-10-20 05:59:55 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-10-20 05:59:55 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-10-20 05:59:55 --> Model Class Initialized
INFO - 2023-10-20 05:59:55 --> Model Class Initialized
INFO - 2023-10-20 05:59:55 --> Model Class Initialized
INFO - 2023-10-20 05:59:55 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-10-20 05:59:55 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-10-20 05:59:55 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-10-20 05:59:55 --> Final output sent to browser
DEBUG - 2023-10-20 05:59:55 --> Total execution time: 0.1382
ERROR - 2023-10-20 05:59:56 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-20 05:59:56 --> Config Class Initialized
INFO - 2023-10-20 05:59:56 --> Hooks Class Initialized
DEBUG - 2023-10-20 05:59:56 --> UTF-8 Support Enabled
INFO - 2023-10-20 05:59:56 --> Utf8 Class Initialized
INFO - 2023-10-20 05:59:56 --> URI Class Initialized
INFO - 2023-10-20 05:59:56 --> Router Class Initialized
INFO - 2023-10-20 05:59:56 --> Output Class Initialized
INFO - 2023-10-20 05:59:56 --> Security Class Initialized
DEBUG - 2023-10-20 05:59:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-20 05:59:56 --> Input Class Initialized
INFO - 2023-10-20 05:59:56 --> Language Class Initialized
INFO - 2023-10-20 05:59:56 --> Loader Class Initialized
INFO - 2023-10-20 05:59:56 --> Helper loaded: url_helper
INFO - 2023-10-20 05:59:56 --> Helper loaded: file_helper
INFO - 2023-10-20 05:59:56 --> Helper loaded: html_helper
INFO - 2023-10-20 05:59:56 --> Helper loaded: text_helper
INFO - 2023-10-20 05:59:56 --> Helper loaded: form_helper
INFO - 2023-10-20 05:59:56 --> Helper loaded: lang_helper
INFO - 2023-10-20 05:59:56 --> Helper loaded: security_helper
INFO - 2023-10-20 05:59:56 --> Helper loaded: cookie_helper
INFO - 2023-10-20 05:59:56 --> Database Driver Class Initialized
INFO - 2023-10-20 05:59:56 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-20 05:59:56 --> Parser Class Initialized
INFO - 2023-10-20 05:59:56 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-20 05:59:56 --> Pagination Class Initialized
INFO - 2023-10-20 05:59:56 --> Form Validation Class Initialized
INFO - 2023-10-20 05:59:56 --> Controller Class Initialized
INFO - 2023-10-20 05:59:56 --> Model Class Initialized
DEBUG - 2023-10-20 05:59:56 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-10-20 05:59:56 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-20 05:59:56 --> Model Class Initialized
DEBUG - 2023-10-20 05:59:56 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-20 05:59:56 --> Model Class Initialized
INFO - 2023-10-20 05:59:56 --> Final output sent to browser
DEBUG - 2023-10-20 05:59:56 --> Total execution time: 0.0406
ERROR - 2023-10-20 06:00:07 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-20 06:00:07 --> Config Class Initialized
INFO - 2023-10-20 06:00:07 --> Hooks Class Initialized
DEBUG - 2023-10-20 06:00:07 --> UTF-8 Support Enabled
INFO - 2023-10-20 06:00:07 --> Utf8 Class Initialized
INFO - 2023-10-20 06:00:07 --> URI Class Initialized
INFO - 2023-10-20 06:00:07 --> Router Class Initialized
INFO - 2023-10-20 06:00:07 --> Output Class Initialized
INFO - 2023-10-20 06:00:07 --> Security Class Initialized
DEBUG - 2023-10-20 06:00:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-20 06:00:07 --> Input Class Initialized
INFO - 2023-10-20 06:00:07 --> Language Class Initialized
INFO - 2023-10-20 06:00:07 --> Loader Class Initialized
INFO - 2023-10-20 06:00:07 --> Helper loaded: url_helper
INFO - 2023-10-20 06:00:07 --> Helper loaded: file_helper
INFO - 2023-10-20 06:00:07 --> Helper loaded: html_helper
INFO - 2023-10-20 06:00:07 --> Helper loaded: text_helper
INFO - 2023-10-20 06:00:07 --> Helper loaded: form_helper
INFO - 2023-10-20 06:00:07 --> Helper loaded: lang_helper
INFO - 2023-10-20 06:00:07 --> Helper loaded: security_helper
INFO - 2023-10-20 06:00:07 --> Helper loaded: cookie_helper
INFO - 2023-10-20 06:00:07 --> Database Driver Class Initialized
INFO - 2023-10-20 06:00:07 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-20 06:00:07 --> Parser Class Initialized
INFO - 2023-10-20 06:00:07 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-20 06:00:07 --> Pagination Class Initialized
INFO - 2023-10-20 06:00:07 --> Form Validation Class Initialized
INFO - 2023-10-20 06:00:07 --> Controller Class Initialized
INFO - 2023-10-20 06:00:07 --> Model Class Initialized
DEBUG - 2023-10-20 06:00:07 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-20 06:00:07 --> Model Class Initialized
DEBUG - 2023-10-20 06:00:07 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-20 06:00:07 --> Model Class Initialized
INFO - 2023-10-20 06:00:07 --> Model Class Initialized
INFO - 2023-10-20 06:00:07 --> Model Class Initialized
INFO - 2023-10-20 06:00:07 --> Model Class Initialized
DEBUG - 2023-10-20 06:00:07 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-10-20 06:00:07 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-20 06:00:07 --> Model Class Initialized
INFO - 2023-10-20 06:00:07 --> Model Class Initialized
INFO - 2023-10-20 06:00:07 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-10-20 06:00:07 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-10-20 06:00:07 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-10-20 06:00:07 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-10-20 06:00:07 --> Model Class Initialized
INFO - 2023-10-20 06:00:07 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-10-20 06:00:07 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-10-20 06:00:07 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-10-20 06:00:07 --> Final output sent to browser
DEBUG - 2023-10-20 06:00:07 --> Total execution time: 0.1968
ERROR - 2023-10-20 07:48:33 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-20 07:48:33 --> Config Class Initialized
INFO - 2023-10-20 07:48:33 --> Hooks Class Initialized
DEBUG - 2023-10-20 07:48:33 --> UTF-8 Support Enabled
INFO - 2023-10-20 07:48:33 --> Utf8 Class Initialized
INFO - 2023-10-20 07:48:33 --> URI Class Initialized
DEBUG - 2023-10-20 07:48:33 --> No URI present. Default controller set.
INFO - 2023-10-20 07:48:33 --> Router Class Initialized
INFO - 2023-10-20 07:48:33 --> Output Class Initialized
INFO - 2023-10-20 07:48:33 --> Security Class Initialized
DEBUG - 2023-10-20 07:48:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-20 07:48:33 --> Input Class Initialized
INFO - 2023-10-20 07:48:33 --> Language Class Initialized
INFO - 2023-10-20 07:48:33 --> Loader Class Initialized
INFO - 2023-10-20 07:48:33 --> Helper loaded: url_helper
INFO - 2023-10-20 07:48:33 --> Helper loaded: file_helper
INFO - 2023-10-20 07:48:33 --> Helper loaded: html_helper
INFO - 2023-10-20 07:48:33 --> Helper loaded: text_helper
INFO - 2023-10-20 07:48:33 --> Helper loaded: form_helper
INFO - 2023-10-20 07:48:33 --> Helper loaded: lang_helper
INFO - 2023-10-20 07:48:33 --> Helper loaded: security_helper
INFO - 2023-10-20 07:48:33 --> Helper loaded: cookie_helper
INFO - 2023-10-20 07:48:33 --> Database Driver Class Initialized
INFO - 2023-10-20 07:48:33 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-20 07:48:33 --> Parser Class Initialized
INFO - 2023-10-20 07:48:33 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-20 07:48:33 --> Pagination Class Initialized
INFO - 2023-10-20 07:48:33 --> Form Validation Class Initialized
INFO - 2023-10-20 07:48:33 --> Controller Class Initialized
INFO - 2023-10-20 07:48:33 --> Model Class Initialized
DEBUG - 2023-10-20 07:48:33 --> Session class already loaded. Second attempt ignored.
ERROR - 2023-10-20 07:48:34 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-20 07:48:34 --> Config Class Initialized
INFO - 2023-10-20 07:48:34 --> Hooks Class Initialized
DEBUG - 2023-10-20 07:48:34 --> UTF-8 Support Enabled
INFO - 2023-10-20 07:48:34 --> Utf8 Class Initialized
INFO - 2023-10-20 07:48:34 --> URI Class Initialized
INFO - 2023-10-20 07:48:34 --> Router Class Initialized
INFO - 2023-10-20 07:48:34 --> Output Class Initialized
INFO - 2023-10-20 07:48:34 --> Security Class Initialized
DEBUG - 2023-10-20 07:48:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-20 07:48:34 --> Input Class Initialized
INFO - 2023-10-20 07:48:34 --> Language Class Initialized
INFO - 2023-10-20 07:48:34 --> Loader Class Initialized
INFO - 2023-10-20 07:48:34 --> Helper loaded: url_helper
INFO - 2023-10-20 07:48:34 --> Helper loaded: file_helper
INFO - 2023-10-20 07:48:34 --> Helper loaded: html_helper
INFO - 2023-10-20 07:48:34 --> Helper loaded: text_helper
INFO - 2023-10-20 07:48:34 --> Helper loaded: form_helper
INFO - 2023-10-20 07:48:34 --> Helper loaded: lang_helper
INFO - 2023-10-20 07:48:34 --> Helper loaded: security_helper
INFO - 2023-10-20 07:48:34 --> Helper loaded: cookie_helper
INFO - 2023-10-20 07:48:34 --> Database Driver Class Initialized
INFO - 2023-10-20 07:48:34 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-20 07:48:34 --> Parser Class Initialized
INFO - 2023-10-20 07:48:34 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-20 07:48:34 --> Pagination Class Initialized
INFO - 2023-10-20 07:48:34 --> Form Validation Class Initialized
INFO - 2023-10-20 07:48:34 --> Controller Class Initialized
INFO - 2023-10-20 07:48:34 --> Model Class Initialized
DEBUG - 2023-10-20 07:48:34 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-20 07:48:34 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2023-10-20 07:48:34 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-10-20 07:48:34 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-10-20 07:48:34 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-10-20 07:48:34 --> Model Class Initialized
INFO - 2023-10-20 07:48:34 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-10-20 07:48:34 --> Final output sent to browser
DEBUG - 2023-10-20 07:48:34 --> Total execution time: 0.0303
ERROR - 2023-10-20 08:02:38 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-20 08:02:38 --> Config Class Initialized
INFO - 2023-10-20 08:02:38 --> Hooks Class Initialized
DEBUG - 2023-10-20 08:02:38 --> UTF-8 Support Enabled
INFO - 2023-10-20 08:02:38 --> Utf8 Class Initialized
INFO - 2023-10-20 08:02:38 --> URI Class Initialized
DEBUG - 2023-10-20 08:02:38 --> No URI present. Default controller set.
INFO - 2023-10-20 08:02:38 --> Router Class Initialized
INFO - 2023-10-20 08:02:38 --> Output Class Initialized
INFO - 2023-10-20 08:02:38 --> Security Class Initialized
DEBUG - 2023-10-20 08:02:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-20 08:02:38 --> Input Class Initialized
INFO - 2023-10-20 08:02:38 --> Language Class Initialized
INFO - 2023-10-20 08:02:38 --> Loader Class Initialized
INFO - 2023-10-20 08:02:38 --> Helper loaded: url_helper
INFO - 2023-10-20 08:02:38 --> Helper loaded: file_helper
INFO - 2023-10-20 08:02:38 --> Helper loaded: html_helper
INFO - 2023-10-20 08:02:38 --> Helper loaded: text_helper
INFO - 2023-10-20 08:02:38 --> Helper loaded: form_helper
INFO - 2023-10-20 08:02:38 --> Helper loaded: lang_helper
INFO - 2023-10-20 08:02:38 --> Helper loaded: security_helper
INFO - 2023-10-20 08:02:38 --> Helper loaded: cookie_helper
INFO - 2023-10-20 08:02:38 --> Database Driver Class Initialized
INFO - 2023-10-20 08:02:38 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-20 08:02:38 --> Parser Class Initialized
INFO - 2023-10-20 08:02:38 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-20 08:02:38 --> Pagination Class Initialized
INFO - 2023-10-20 08:02:38 --> Form Validation Class Initialized
INFO - 2023-10-20 08:02:38 --> Controller Class Initialized
INFO - 2023-10-20 08:02:38 --> Model Class Initialized
DEBUG - 2023-10-20 08:02:38 --> Session class already loaded. Second attempt ignored.
ERROR - 2023-10-20 08:02:38 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-20 08:02:38 --> Config Class Initialized
INFO - 2023-10-20 08:02:38 --> Hooks Class Initialized
DEBUG - 2023-10-20 08:02:38 --> UTF-8 Support Enabled
INFO - 2023-10-20 08:02:38 --> Utf8 Class Initialized
INFO - 2023-10-20 08:02:38 --> URI Class Initialized
DEBUG - 2023-10-20 08:02:38 --> No URI present. Default controller set.
INFO - 2023-10-20 08:02:38 --> Router Class Initialized
INFO - 2023-10-20 08:02:38 --> Output Class Initialized
INFO - 2023-10-20 08:02:38 --> Security Class Initialized
DEBUG - 2023-10-20 08:02:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-20 08:02:38 --> Input Class Initialized
INFO - 2023-10-20 08:02:38 --> Language Class Initialized
INFO - 2023-10-20 08:02:38 --> Loader Class Initialized
INFO - 2023-10-20 08:02:38 --> Helper loaded: url_helper
INFO - 2023-10-20 08:02:38 --> Helper loaded: file_helper
INFO - 2023-10-20 08:02:38 --> Helper loaded: html_helper
INFO - 2023-10-20 08:02:38 --> Helper loaded: text_helper
INFO - 2023-10-20 08:02:38 --> Helper loaded: form_helper
INFO - 2023-10-20 08:02:38 --> Helper loaded: lang_helper
INFO - 2023-10-20 08:02:38 --> Helper loaded: security_helper
INFO - 2023-10-20 08:02:38 --> Helper loaded: cookie_helper
INFO - 2023-10-20 08:02:38 --> Database Driver Class Initialized
INFO - 2023-10-20 08:02:38 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-20 08:02:38 --> Parser Class Initialized
INFO - 2023-10-20 08:02:38 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-20 08:02:38 --> Pagination Class Initialized
INFO - 2023-10-20 08:02:38 --> Form Validation Class Initialized
INFO - 2023-10-20 08:02:38 --> Controller Class Initialized
INFO - 2023-10-20 08:02:38 --> Model Class Initialized
DEBUG - 2023-10-20 08:02:38 --> Session class already loaded. Second attempt ignored.
ERROR - 2023-10-20 08:02:40 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-20 08:02:40 --> Config Class Initialized
INFO - 2023-10-20 08:02:40 --> Hooks Class Initialized
DEBUG - 2023-10-20 08:02:40 --> UTF-8 Support Enabled
INFO - 2023-10-20 08:02:40 --> Utf8 Class Initialized
INFO - 2023-10-20 08:02:40 --> URI Class Initialized
DEBUG - 2023-10-20 08:02:40 --> No URI present. Default controller set.
INFO - 2023-10-20 08:02:40 --> Router Class Initialized
INFO - 2023-10-20 08:02:40 --> Output Class Initialized
INFO - 2023-10-20 08:02:40 --> Security Class Initialized
DEBUG - 2023-10-20 08:02:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-20 08:02:40 --> Input Class Initialized
INFO - 2023-10-20 08:02:40 --> Language Class Initialized
INFO - 2023-10-20 08:02:40 --> Loader Class Initialized
INFO - 2023-10-20 08:02:40 --> Helper loaded: url_helper
INFO - 2023-10-20 08:02:40 --> Helper loaded: file_helper
INFO - 2023-10-20 08:02:40 --> Helper loaded: html_helper
INFO - 2023-10-20 08:02:40 --> Helper loaded: text_helper
INFO - 2023-10-20 08:02:40 --> Helper loaded: form_helper
INFO - 2023-10-20 08:02:40 --> Helper loaded: lang_helper
INFO - 2023-10-20 08:02:40 --> Helper loaded: security_helper
INFO - 2023-10-20 08:02:40 --> Helper loaded: cookie_helper
INFO - 2023-10-20 08:02:40 --> Database Driver Class Initialized
INFO - 2023-10-20 08:02:40 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-20 08:02:40 --> Parser Class Initialized
INFO - 2023-10-20 08:02:40 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-20 08:02:40 --> Pagination Class Initialized
INFO - 2023-10-20 08:02:40 --> Form Validation Class Initialized
INFO - 2023-10-20 08:02:40 --> Controller Class Initialized
INFO - 2023-10-20 08:02:40 --> Model Class Initialized
DEBUG - 2023-10-20 08:02:40 --> Session class already loaded. Second attempt ignored.
ERROR - 2023-10-20 08:02:41 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-20 08:02:41 --> Config Class Initialized
INFO - 2023-10-20 08:02:41 --> Hooks Class Initialized
DEBUG - 2023-10-20 08:02:41 --> UTF-8 Support Enabled
INFO - 2023-10-20 08:02:41 --> Utf8 Class Initialized
INFO - 2023-10-20 08:02:41 --> URI Class Initialized
DEBUG - 2023-10-20 08:02:41 --> No URI present. Default controller set.
INFO - 2023-10-20 08:02:41 --> Router Class Initialized
INFO - 2023-10-20 08:02:41 --> Output Class Initialized
INFO - 2023-10-20 08:02:41 --> Security Class Initialized
DEBUG - 2023-10-20 08:02:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-20 08:02:41 --> Input Class Initialized
INFO - 2023-10-20 08:02:41 --> Language Class Initialized
INFO - 2023-10-20 08:02:41 --> Loader Class Initialized
INFO - 2023-10-20 08:02:41 --> Helper loaded: url_helper
INFO - 2023-10-20 08:02:41 --> Helper loaded: file_helper
INFO - 2023-10-20 08:02:41 --> Helper loaded: html_helper
INFO - 2023-10-20 08:02:41 --> Helper loaded: text_helper
INFO - 2023-10-20 08:02:41 --> Helper loaded: form_helper
INFO - 2023-10-20 08:02:41 --> Helper loaded: lang_helper
INFO - 2023-10-20 08:02:41 --> Helper loaded: security_helper
INFO - 2023-10-20 08:02:41 --> Helper loaded: cookie_helper
INFO - 2023-10-20 08:02:41 --> Database Driver Class Initialized
INFO - 2023-10-20 08:02:41 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-20 08:02:41 --> Parser Class Initialized
INFO - 2023-10-20 08:02:41 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-20 08:02:41 --> Pagination Class Initialized
INFO - 2023-10-20 08:02:41 --> Form Validation Class Initialized
INFO - 2023-10-20 08:02:41 --> Controller Class Initialized
INFO - 2023-10-20 08:02:41 --> Model Class Initialized
DEBUG - 2023-10-20 08:02:41 --> Session class already loaded. Second attempt ignored.
ERROR - 2023-10-20 08:02:47 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-20 08:02:47 --> Config Class Initialized
INFO - 2023-10-20 08:02:47 --> Hooks Class Initialized
DEBUG - 2023-10-20 08:02:47 --> UTF-8 Support Enabled
INFO - 2023-10-20 08:02:47 --> Utf8 Class Initialized
INFO - 2023-10-20 08:02:47 --> URI Class Initialized
DEBUG - 2023-10-20 08:02:47 --> No URI present. Default controller set.
INFO - 2023-10-20 08:02:47 --> Router Class Initialized
INFO - 2023-10-20 08:02:47 --> Output Class Initialized
INFO - 2023-10-20 08:02:47 --> Security Class Initialized
DEBUG - 2023-10-20 08:02:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-20 08:02:47 --> Input Class Initialized
INFO - 2023-10-20 08:02:47 --> Language Class Initialized
INFO - 2023-10-20 08:02:47 --> Loader Class Initialized
INFO - 2023-10-20 08:02:47 --> Helper loaded: url_helper
INFO - 2023-10-20 08:02:47 --> Helper loaded: file_helper
INFO - 2023-10-20 08:02:47 --> Helper loaded: html_helper
INFO - 2023-10-20 08:02:47 --> Helper loaded: text_helper
INFO - 2023-10-20 08:02:47 --> Helper loaded: form_helper
INFO - 2023-10-20 08:02:47 --> Helper loaded: lang_helper
INFO - 2023-10-20 08:02:47 --> Helper loaded: security_helper
INFO - 2023-10-20 08:02:47 --> Helper loaded: cookie_helper
INFO - 2023-10-20 08:02:47 --> Database Driver Class Initialized
INFO - 2023-10-20 08:02:47 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-20 08:02:47 --> Parser Class Initialized
INFO - 2023-10-20 08:02:47 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-20 08:02:47 --> Pagination Class Initialized
INFO - 2023-10-20 08:02:47 --> Form Validation Class Initialized
INFO - 2023-10-20 08:02:47 --> Controller Class Initialized
INFO - 2023-10-20 08:02:47 --> Model Class Initialized
DEBUG - 2023-10-20 08:02:47 --> Session class already loaded. Second attempt ignored.
ERROR - 2023-10-20 08:02:47 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-20 08:02:47 --> Config Class Initialized
INFO - 2023-10-20 08:02:47 --> Hooks Class Initialized
DEBUG - 2023-10-20 08:02:47 --> UTF-8 Support Enabled
INFO - 2023-10-20 08:02:47 --> Utf8 Class Initialized
INFO - 2023-10-20 08:02:47 --> URI Class Initialized
DEBUG - 2023-10-20 08:02:47 --> No URI present. Default controller set.
INFO - 2023-10-20 08:02:47 --> Router Class Initialized
INFO - 2023-10-20 08:02:47 --> Output Class Initialized
INFO - 2023-10-20 08:02:47 --> Security Class Initialized
DEBUG - 2023-10-20 08:02:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-20 08:02:47 --> Input Class Initialized
INFO - 2023-10-20 08:02:47 --> Language Class Initialized
INFO - 2023-10-20 08:02:47 --> Loader Class Initialized
INFO - 2023-10-20 08:02:47 --> Helper loaded: url_helper
INFO - 2023-10-20 08:02:47 --> Helper loaded: file_helper
INFO - 2023-10-20 08:02:47 --> Helper loaded: html_helper
INFO - 2023-10-20 08:02:47 --> Helper loaded: text_helper
INFO - 2023-10-20 08:02:47 --> Helper loaded: form_helper
INFO - 2023-10-20 08:02:47 --> Helper loaded: lang_helper
INFO - 2023-10-20 08:02:47 --> Helper loaded: security_helper
INFO - 2023-10-20 08:02:47 --> Helper loaded: cookie_helper
INFO - 2023-10-20 08:02:47 --> Database Driver Class Initialized
INFO - 2023-10-20 08:02:47 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-20 08:02:47 --> Parser Class Initialized
INFO - 2023-10-20 08:02:47 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-20 08:02:47 --> Pagination Class Initialized
INFO - 2023-10-20 08:02:47 --> Form Validation Class Initialized
INFO - 2023-10-20 08:02:47 --> Controller Class Initialized
INFO - 2023-10-20 08:02:47 --> Model Class Initialized
DEBUG - 2023-10-20 08:02:47 --> Session class already loaded. Second attempt ignored.
ERROR - 2023-10-20 08:02:48 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-20 08:02:48 --> Config Class Initialized
INFO - 2023-10-20 08:02:48 --> Hooks Class Initialized
DEBUG - 2023-10-20 08:02:48 --> UTF-8 Support Enabled
INFO - 2023-10-20 08:02:48 --> Utf8 Class Initialized
INFO - 2023-10-20 08:02:48 --> URI Class Initialized
DEBUG - 2023-10-20 08:02:48 --> No URI present. Default controller set.
INFO - 2023-10-20 08:02:48 --> Router Class Initialized
INFO - 2023-10-20 08:02:48 --> Output Class Initialized
INFO - 2023-10-20 08:02:48 --> Security Class Initialized
DEBUG - 2023-10-20 08:02:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-20 08:02:48 --> Input Class Initialized
INFO - 2023-10-20 08:02:48 --> Language Class Initialized
INFO - 2023-10-20 08:02:48 --> Loader Class Initialized
INFO - 2023-10-20 08:02:48 --> Helper loaded: url_helper
INFO - 2023-10-20 08:02:48 --> Helper loaded: file_helper
INFO - 2023-10-20 08:02:48 --> Helper loaded: html_helper
INFO - 2023-10-20 08:02:48 --> Helper loaded: text_helper
INFO - 2023-10-20 08:02:48 --> Helper loaded: form_helper
INFO - 2023-10-20 08:02:48 --> Helper loaded: lang_helper
INFO - 2023-10-20 08:02:48 --> Helper loaded: security_helper
INFO - 2023-10-20 08:02:48 --> Helper loaded: cookie_helper
INFO - 2023-10-20 08:02:48 --> Database Driver Class Initialized
INFO - 2023-10-20 08:02:48 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-20 08:02:48 --> Parser Class Initialized
INFO - 2023-10-20 08:02:48 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-20 08:02:48 --> Pagination Class Initialized
INFO - 2023-10-20 08:02:48 --> Form Validation Class Initialized
INFO - 2023-10-20 08:02:48 --> Controller Class Initialized
INFO - 2023-10-20 08:02:48 --> Model Class Initialized
DEBUG - 2023-10-20 08:02:48 --> Session class already loaded. Second attempt ignored.
ERROR - 2023-10-20 08:02:48 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-20 08:02:48 --> Config Class Initialized
INFO - 2023-10-20 08:02:48 --> Hooks Class Initialized
DEBUG - 2023-10-20 08:02:48 --> UTF-8 Support Enabled
INFO - 2023-10-20 08:02:48 --> Utf8 Class Initialized
INFO - 2023-10-20 08:02:48 --> URI Class Initialized
DEBUG - 2023-10-20 08:02:48 --> No URI present. Default controller set.
INFO - 2023-10-20 08:02:48 --> Router Class Initialized
INFO - 2023-10-20 08:02:48 --> Output Class Initialized
INFO - 2023-10-20 08:02:48 --> Security Class Initialized
DEBUG - 2023-10-20 08:02:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-20 08:02:48 --> Input Class Initialized
INFO - 2023-10-20 08:02:48 --> Language Class Initialized
INFO - 2023-10-20 08:02:48 --> Loader Class Initialized
INFO - 2023-10-20 08:02:48 --> Helper loaded: url_helper
INFO - 2023-10-20 08:02:48 --> Helper loaded: file_helper
INFO - 2023-10-20 08:02:48 --> Helper loaded: html_helper
INFO - 2023-10-20 08:02:48 --> Helper loaded: text_helper
INFO - 2023-10-20 08:02:48 --> Helper loaded: form_helper
INFO - 2023-10-20 08:02:48 --> Helper loaded: lang_helper
INFO - 2023-10-20 08:02:48 --> Helper loaded: security_helper
INFO - 2023-10-20 08:02:48 --> Helper loaded: cookie_helper
INFO - 2023-10-20 08:02:48 --> Database Driver Class Initialized
INFO - 2023-10-20 08:02:48 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-20 08:02:48 --> Parser Class Initialized
INFO - 2023-10-20 08:02:48 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-20 08:02:48 --> Pagination Class Initialized
INFO - 2023-10-20 08:02:48 --> Form Validation Class Initialized
INFO - 2023-10-20 08:02:48 --> Controller Class Initialized
INFO - 2023-10-20 08:02:48 --> Model Class Initialized
DEBUG - 2023-10-20 08:02:48 --> Session class already loaded. Second attempt ignored.
ERROR - 2023-10-20 08:10:57 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-20 08:10:57 --> Config Class Initialized
INFO - 2023-10-20 08:10:57 --> Hooks Class Initialized
DEBUG - 2023-10-20 08:10:57 --> UTF-8 Support Enabled
INFO - 2023-10-20 08:10:57 --> Utf8 Class Initialized
INFO - 2023-10-20 08:10:57 --> URI Class Initialized
DEBUG - 2023-10-20 08:10:57 --> No URI present. Default controller set.
INFO - 2023-10-20 08:10:57 --> Router Class Initialized
INFO - 2023-10-20 08:10:57 --> Output Class Initialized
INFO - 2023-10-20 08:10:57 --> Security Class Initialized
DEBUG - 2023-10-20 08:10:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-20 08:10:57 --> Input Class Initialized
INFO - 2023-10-20 08:10:57 --> Language Class Initialized
INFO - 2023-10-20 08:10:57 --> Loader Class Initialized
INFO - 2023-10-20 08:10:57 --> Helper loaded: url_helper
INFO - 2023-10-20 08:10:57 --> Helper loaded: file_helper
INFO - 2023-10-20 08:10:57 --> Helper loaded: html_helper
INFO - 2023-10-20 08:10:57 --> Helper loaded: text_helper
INFO - 2023-10-20 08:10:57 --> Helper loaded: form_helper
INFO - 2023-10-20 08:10:57 --> Helper loaded: lang_helper
INFO - 2023-10-20 08:10:57 --> Helper loaded: security_helper
INFO - 2023-10-20 08:10:57 --> Helper loaded: cookie_helper
INFO - 2023-10-20 08:10:57 --> Database Driver Class Initialized
INFO - 2023-10-20 08:10:57 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-20 08:10:57 --> Parser Class Initialized
INFO - 2023-10-20 08:10:57 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-20 08:10:57 --> Pagination Class Initialized
INFO - 2023-10-20 08:10:57 --> Form Validation Class Initialized
INFO - 2023-10-20 08:10:57 --> Controller Class Initialized
INFO - 2023-10-20 08:10:57 --> Model Class Initialized
DEBUG - 2023-10-20 08:10:57 --> Session class already loaded. Second attempt ignored.
ERROR - 2023-10-20 08:10:57 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-20 08:10:57 --> Config Class Initialized
INFO - 2023-10-20 08:10:57 --> Hooks Class Initialized
DEBUG - 2023-10-20 08:10:57 --> UTF-8 Support Enabled
INFO - 2023-10-20 08:10:57 --> Utf8 Class Initialized
INFO - 2023-10-20 08:10:57 --> URI Class Initialized
INFO - 2023-10-20 08:10:57 --> Router Class Initialized
INFO - 2023-10-20 08:10:57 --> Output Class Initialized
INFO - 2023-10-20 08:10:57 --> Security Class Initialized
DEBUG - 2023-10-20 08:10:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-20 08:10:57 --> Input Class Initialized
INFO - 2023-10-20 08:10:57 --> Language Class Initialized
INFO - 2023-10-20 08:10:57 --> Loader Class Initialized
INFO - 2023-10-20 08:10:57 --> Helper loaded: url_helper
INFO - 2023-10-20 08:10:57 --> Helper loaded: file_helper
INFO - 2023-10-20 08:10:57 --> Helper loaded: html_helper
INFO - 2023-10-20 08:10:57 --> Helper loaded: text_helper
INFO - 2023-10-20 08:10:57 --> Helper loaded: form_helper
INFO - 2023-10-20 08:10:57 --> Helper loaded: lang_helper
INFO - 2023-10-20 08:10:57 --> Helper loaded: security_helper
INFO - 2023-10-20 08:10:57 --> Helper loaded: cookie_helper
INFO - 2023-10-20 08:10:57 --> Database Driver Class Initialized
INFO - 2023-10-20 08:10:57 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-20 08:10:57 --> Parser Class Initialized
INFO - 2023-10-20 08:10:57 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-20 08:10:57 --> Pagination Class Initialized
INFO - 2023-10-20 08:10:57 --> Form Validation Class Initialized
INFO - 2023-10-20 08:10:57 --> Controller Class Initialized
INFO - 2023-10-20 08:10:57 --> Model Class Initialized
DEBUG - 2023-10-20 08:10:57 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-20 08:10:57 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2023-10-20 08:10:57 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-10-20 08:10:57 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-10-20 08:10:57 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-10-20 08:10:57 --> Model Class Initialized
INFO - 2023-10-20 08:10:57 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-10-20 08:10:57 --> Final output sent to browser
DEBUG - 2023-10-20 08:10:57 --> Total execution time: 0.0297
ERROR - 2023-10-20 08:11:12 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-20 08:11:12 --> Config Class Initialized
INFO - 2023-10-20 08:11:12 --> Hooks Class Initialized
DEBUG - 2023-10-20 08:11:12 --> UTF-8 Support Enabled
INFO - 2023-10-20 08:11:12 --> Utf8 Class Initialized
INFO - 2023-10-20 08:11:12 --> URI Class Initialized
DEBUG - 2023-10-20 08:11:12 --> No URI present. Default controller set.
INFO - 2023-10-20 08:11:12 --> Router Class Initialized
INFO - 2023-10-20 08:11:12 --> Output Class Initialized
INFO - 2023-10-20 08:11:12 --> Security Class Initialized
DEBUG - 2023-10-20 08:11:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-20 08:11:12 --> Input Class Initialized
INFO - 2023-10-20 08:11:12 --> Language Class Initialized
INFO - 2023-10-20 08:11:12 --> Loader Class Initialized
INFO - 2023-10-20 08:11:12 --> Helper loaded: url_helper
INFO - 2023-10-20 08:11:12 --> Helper loaded: file_helper
INFO - 2023-10-20 08:11:12 --> Helper loaded: html_helper
INFO - 2023-10-20 08:11:12 --> Helper loaded: text_helper
INFO - 2023-10-20 08:11:12 --> Helper loaded: form_helper
INFO - 2023-10-20 08:11:12 --> Helper loaded: lang_helper
INFO - 2023-10-20 08:11:12 --> Helper loaded: security_helper
INFO - 2023-10-20 08:11:12 --> Helper loaded: cookie_helper
INFO - 2023-10-20 08:11:12 --> Database Driver Class Initialized
INFO - 2023-10-20 08:11:12 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-20 08:11:12 --> Parser Class Initialized
INFO - 2023-10-20 08:11:12 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-20 08:11:12 --> Pagination Class Initialized
INFO - 2023-10-20 08:11:12 --> Form Validation Class Initialized
INFO - 2023-10-20 08:11:12 --> Controller Class Initialized
INFO - 2023-10-20 08:11:12 --> Model Class Initialized
DEBUG - 2023-10-20 08:11:12 --> Session class already loaded. Second attempt ignored.
ERROR - 2023-10-20 08:11:12 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-20 08:11:12 --> Config Class Initialized
INFO - 2023-10-20 08:11:12 --> Hooks Class Initialized
DEBUG - 2023-10-20 08:11:12 --> UTF-8 Support Enabled
INFO - 2023-10-20 08:11:12 --> Utf8 Class Initialized
INFO - 2023-10-20 08:11:12 --> URI Class Initialized
INFO - 2023-10-20 08:11:12 --> Router Class Initialized
INFO - 2023-10-20 08:11:12 --> Output Class Initialized
INFO - 2023-10-20 08:11:12 --> Security Class Initialized
DEBUG - 2023-10-20 08:11:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-20 08:11:12 --> Input Class Initialized
INFO - 2023-10-20 08:11:12 --> Language Class Initialized
INFO - 2023-10-20 08:11:12 --> Loader Class Initialized
INFO - 2023-10-20 08:11:12 --> Helper loaded: url_helper
INFO - 2023-10-20 08:11:12 --> Helper loaded: file_helper
INFO - 2023-10-20 08:11:12 --> Helper loaded: html_helper
INFO - 2023-10-20 08:11:12 --> Helper loaded: text_helper
INFO - 2023-10-20 08:11:12 --> Helper loaded: form_helper
INFO - 2023-10-20 08:11:12 --> Helper loaded: lang_helper
INFO - 2023-10-20 08:11:12 --> Helper loaded: security_helper
INFO - 2023-10-20 08:11:12 --> Helper loaded: cookie_helper
INFO - 2023-10-20 08:11:12 --> Database Driver Class Initialized
INFO - 2023-10-20 08:11:12 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-20 08:11:12 --> Parser Class Initialized
INFO - 2023-10-20 08:11:12 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-20 08:11:12 --> Pagination Class Initialized
INFO - 2023-10-20 08:11:12 --> Form Validation Class Initialized
INFO - 2023-10-20 08:11:12 --> Controller Class Initialized
INFO - 2023-10-20 08:11:12 --> Model Class Initialized
DEBUG - 2023-10-20 08:11:12 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-20 08:11:12 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2023-10-20 08:11:12 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-10-20 08:11:12 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-10-20 08:11:12 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-10-20 08:11:12 --> Model Class Initialized
INFO - 2023-10-20 08:11:12 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-10-20 08:11:12 --> Final output sent to browser
DEBUG - 2023-10-20 08:11:12 --> Total execution time: 0.0334
ERROR - 2023-10-20 08:11:24 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-20 08:11:24 --> Config Class Initialized
INFO - 2023-10-20 08:11:24 --> Hooks Class Initialized
DEBUG - 2023-10-20 08:11:24 --> UTF-8 Support Enabled
INFO - 2023-10-20 08:11:24 --> Utf8 Class Initialized
INFO - 2023-10-20 08:11:24 --> URI Class Initialized
INFO - 2023-10-20 08:11:24 --> Router Class Initialized
INFO - 2023-10-20 08:11:24 --> Output Class Initialized
INFO - 2023-10-20 08:11:24 --> Security Class Initialized
DEBUG - 2023-10-20 08:11:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-20 08:11:24 --> Input Class Initialized
INFO - 2023-10-20 08:11:24 --> Language Class Initialized
INFO - 2023-10-20 08:11:24 --> Loader Class Initialized
INFO - 2023-10-20 08:11:24 --> Helper loaded: url_helper
INFO - 2023-10-20 08:11:24 --> Helper loaded: file_helper
INFO - 2023-10-20 08:11:24 --> Helper loaded: html_helper
INFO - 2023-10-20 08:11:24 --> Helper loaded: text_helper
INFO - 2023-10-20 08:11:24 --> Helper loaded: form_helper
INFO - 2023-10-20 08:11:24 --> Helper loaded: lang_helper
INFO - 2023-10-20 08:11:24 --> Helper loaded: security_helper
INFO - 2023-10-20 08:11:24 --> Helper loaded: cookie_helper
INFO - 2023-10-20 08:11:24 --> Database Driver Class Initialized
INFO - 2023-10-20 08:11:24 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-20 08:11:24 --> Parser Class Initialized
INFO - 2023-10-20 08:11:24 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-20 08:11:24 --> Pagination Class Initialized
INFO - 2023-10-20 08:11:24 --> Form Validation Class Initialized
INFO - 2023-10-20 08:11:24 --> Controller Class Initialized
INFO - 2023-10-20 08:11:24 --> Model Class Initialized
DEBUG - 2023-10-20 08:11:24 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-20 08:11:24 --> Model Class Initialized
INFO - 2023-10-20 08:11:24 --> Final output sent to browser
DEBUG - 2023-10-20 08:11:24 --> Total execution time: 0.0207
ERROR - 2023-10-20 08:11:24 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-20 08:11:24 --> Config Class Initialized
INFO - 2023-10-20 08:11:24 --> Hooks Class Initialized
DEBUG - 2023-10-20 08:11:24 --> UTF-8 Support Enabled
INFO - 2023-10-20 08:11:24 --> Utf8 Class Initialized
INFO - 2023-10-20 08:11:24 --> URI Class Initialized
DEBUG - 2023-10-20 08:11:24 --> No URI present. Default controller set.
INFO - 2023-10-20 08:11:24 --> Router Class Initialized
INFO - 2023-10-20 08:11:24 --> Output Class Initialized
INFO - 2023-10-20 08:11:24 --> Security Class Initialized
DEBUG - 2023-10-20 08:11:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-20 08:11:24 --> Input Class Initialized
INFO - 2023-10-20 08:11:24 --> Language Class Initialized
INFO - 2023-10-20 08:11:24 --> Loader Class Initialized
INFO - 2023-10-20 08:11:24 --> Helper loaded: url_helper
INFO - 2023-10-20 08:11:24 --> Helper loaded: file_helper
INFO - 2023-10-20 08:11:24 --> Helper loaded: html_helper
INFO - 2023-10-20 08:11:24 --> Helper loaded: text_helper
INFO - 2023-10-20 08:11:24 --> Helper loaded: form_helper
INFO - 2023-10-20 08:11:24 --> Helper loaded: lang_helper
INFO - 2023-10-20 08:11:24 --> Helper loaded: security_helper
INFO - 2023-10-20 08:11:24 --> Helper loaded: cookie_helper
INFO - 2023-10-20 08:11:24 --> Database Driver Class Initialized
INFO - 2023-10-20 08:11:24 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-20 08:11:24 --> Parser Class Initialized
INFO - 2023-10-20 08:11:24 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-20 08:11:24 --> Pagination Class Initialized
INFO - 2023-10-20 08:11:24 --> Form Validation Class Initialized
INFO - 2023-10-20 08:11:24 --> Controller Class Initialized
INFO - 2023-10-20 08:11:24 --> Model Class Initialized
DEBUG - 2023-10-20 08:11:24 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-20 08:11:24 --> Model Class Initialized
DEBUG - 2023-10-20 08:11:24 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-20 08:11:24 --> Model Class Initialized
INFO - 2023-10-20 08:11:24 --> Model Class Initialized
INFO - 2023-10-20 08:11:24 --> Model Class Initialized
INFO - 2023-10-20 08:11:24 --> Model Class Initialized
DEBUG - 2023-10-20 08:11:24 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-10-20 08:11:24 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-20 08:11:24 --> Model Class Initialized
INFO - 2023-10-20 08:11:24 --> Model Class Initialized
INFO - 2023-10-20 08:11:24 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-10-20 08:11:24 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-10-20 08:11:24 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-10-20 08:11:24 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-10-20 08:11:24 --> Model Class Initialized
INFO - 2023-10-20 08:11:24 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-10-20 08:11:24 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-10-20 08:11:24 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-10-20 08:11:24 --> Final output sent to browser
DEBUG - 2023-10-20 08:11:24 --> Total execution time: 0.2067
ERROR - 2023-10-20 08:11:32 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-20 08:11:32 --> Config Class Initialized
INFO - 2023-10-20 08:11:32 --> Hooks Class Initialized
DEBUG - 2023-10-20 08:11:32 --> UTF-8 Support Enabled
INFO - 2023-10-20 08:11:32 --> Utf8 Class Initialized
INFO - 2023-10-20 08:11:32 --> URI Class Initialized
INFO - 2023-10-20 08:11:32 --> Router Class Initialized
INFO - 2023-10-20 08:11:32 --> Output Class Initialized
INFO - 2023-10-20 08:11:32 --> Security Class Initialized
DEBUG - 2023-10-20 08:11:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-20 08:11:32 --> Input Class Initialized
INFO - 2023-10-20 08:11:32 --> Language Class Initialized
INFO - 2023-10-20 08:11:32 --> Loader Class Initialized
INFO - 2023-10-20 08:11:32 --> Helper loaded: url_helper
INFO - 2023-10-20 08:11:32 --> Helper loaded: file_helper
INFO - 2023-10-20 08:11:32 --> Helper loaded: html_helper
INFO - 2023-10-20 08:11:32 --> Helper loaded: text_helper
INFO - 2023-10-20 08:11:32 --> Helper loaded: form_helper
INFO - 2023-10-20 08:11:32 --> Helper loaded: lang_helper
INFO - 2023-10-20 08:11:32 --> Helper loaded: security_helper
INFO - 2023-10-20 08:11:32 --> Helper loaded: cookie_helper
INFO - 2023-10-20 08:11:32 --> Database Driver Class Initialized
INFO - 2023-10-20 08:11:32 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-20 08:11:32 --> Parser Class Initialized
INFO - 2023-10-20 08:11:32 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-20 08:11:32 --> Pagination Class Initialized
INFO - 2023-10-20 08:11:32 --> Form Validation Class Initialized
INFO - 2023-10-20 08:11:32 --> Controller Class Initialized
INFO - 2023-10-20 08:11:32 --> Model Class Initialized
DEBUG - 2023-10-20 08:11:32 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-10-20 08:11:32 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-20 08:11:32 --> Model Class Initialized
DEBUG - 2023-10-20 08:11:32 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-20 08:11:32 --> Model Class Initialized
INFO - 2023-10-20 08:11:32 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/add_invoice_form.php
DEBUG - 2023-10-20 08:11:32 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-10-20 08:11:32 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-10-20 08:11:32 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-10-20 08:11:32 --> Model Class Initialized
INFO - 2023-10-20 08:11:32 --> Model Class Initialized
INFO - 2023-10-20 08:11:32 --> Model Class Initialized
INFO - 2023-10-20 08:11:32 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-10-20 08:11:32 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-10-20 08:11:32 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-10-20 08:11:32 --> Final output sent to browser
DEBUG - 2023-10-20 08:11:32 --> Total execution time: 0.1637
ERROR - 2023-10-20 08:11:38 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-20 08:11:38 --> Config Class Initialized
INFO - 2023-10-20 08:11:38 --> Hooks Class Initialized
DEBUG - 2023-10-20 08:11:38 --> UTF-8 Support Enabled
INFO - 2023-10-20 08:11:38 --> Utf8 Class Initialized
INFO - 2023-10-20 08:11:38 --> URI Class Initialized
INFO - 2023-10-20 08:11:38 --> Router Class Initialized
INFO - 2023-10-20 08:11:38 --> Output Class Initialized
INFO - 2023-10-20 08:11:38 --> Security Class Initialized
DEBUG - 2023-10-20 08:11:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-20 08:11:38 --> Input Class Initialized
INFO - 2023-10-20 08:11:38 --> Language Class Initialized
INFO - 2023-10-20 08:11:38 --> Loader Class Initialized
INFO - 2023-10-20 08:11:38 --> Helper loaded: url_helper
INFO - 2023-10-20 08:11:38 --> Helper loaded: file_helper
INFO - 2023-10-20 08:11:38 --> Helper loaded: html_helper
INFO - 2023-10-20 08:11:38 --> Helper loaded: text_helper
INFO - 2023-10-20 08:11:38 --> Helper loaded: form_helper
INFO - 2023-10-20 08:11:38 --> Helper loaded: lang_helper
INFO - 2023-10-20 08:11:38 --> Helper loaded: security_helper
INFO - 2023-10-20 08:11:38 --> Helper loaded: cookie_helper
INFO - 2023-10-20 08:11:38 --> Database Driver Class Initialized
INFO - 2023-10-20 08:11:38 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-20 08:11:38 --> Parser Class Initialized
INFO - 2023-10-20 08:11:38 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-20 08:11:38 --> Pagination Class Initialized
INFO - 2023-10-20 08:11:38 --> Form Validation Class Initialized
INFO - 2023-10-20 08:11:38 --> Controller Class Initialized
INFO - 2023-10-20 08:11:38 --> Model Class Initialized
DEBUG - 2023-10-20 08:11:38 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-20 08:11:38 --> Final output sent to browser
DEBUG - 2023-10-20 08:11:38 --> Total execution time: 0.0154
ERROR - 2023-10-20 08:11:38 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-20 08:11:38 --> Config Class Initialized
INFO - 2023-10-20 08:11:38 --> Hooks Class Initialized
DEBUG - 2023-10-20 08:11:38 --> UTF-8 Support Enabled
INFO - 2023-10-20 08:11:38 --> Utf8 Class Initialized
INFO - 2023-10-20 08:11:38 --> URI Class Initialized
INFO - 2023-10-20 08:11:38 --> Router Class Initialized
INFO - 2023-10-20 08:11:38 --> Output Class Initialized
INFO - 2023-10-20 08:11:38 --> Security Class Initialized
DEBUG - 2023-10-20 08:11:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-20 08:11:38 --> Input Class Initialized
INFO - 2023-10-20 08:11:38 --> Language Class Initialized
INFO - 2023-10-20 08:11:38 --> Loader Class Initialized
INFO - 2023-10-20 08:11:38 --> Helper loaded: url_helper
INFO - 2023-10-20 08:11:38 --> Helper loaded: file_helper
INFO - 2023-10-20 08:11:38 --> Helper loaded: html_helper
INFO - 2023-10-20 08:11:38 --> Helper loaded: text_helper
INFO - 2023-10-20 08:11:38 --> Helper loaded: form_helper
INFO - 2023-10-20 08:11:38 --> Helper loaded: lang_helper
INFO - 2023-10-20 08:11:38 --> Helper loaded: security_helper
INFO - 2023-10-20 08:11:38 --> Helper loaded: cookie_helper
INFO - 2023-10-20 08:11:38 --> Database Driver Class Initialized
INFO - 2023-10-20 08:11:38 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-20 08:11:38 --> Parser Class Initialized
INFO - 2023-10-20 08:11:38 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-20 08:11:38 --> Pagination Class Initialized
INFO - 2023-10-20 08:11:38 --> Form Validation Class Initialized
INFO - 2023-10-20 08:11:38 --> Controller Class Initialized
INFO - 2023-10-20 08:11:38 --> Model Class Initialized
DEBUG - 2023-10-20 08:11:38 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-20 08:11:38 --> Final output sent to browser
DEBUG - 2023-10-20 08:11:38 --> Total execution time: 0.0155
ERROR - 2023-10-20 08:11:39 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-20 08:11:39 --> Config Class Initialized
INFO - 2023-10-20 08:11:39 --> Hooks Class Initialized
DEBUG - 2023-10-20 08:11:39 --> UTF-8 Support Enabled
INFO - 2023-10-20 08:11:39 --> Utf8 Class Initialized
INFO - 2023-10-20 08:11:39 --> URI Class Initialized
INFO - 2023-10-20 08:11:39 --> Router Class Initialized
INFO - 2023-10-20 08:11:39 --> Output Class Initialized
INFO - 2023-10-20 08:11:39 --> Security Class Initialized
DEBUG - 2023-10-20 08:11:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-20 08:11:39 --> Input Class Initialized
INFO - 2023-10-20 08:11:39 --> Language Class Initialized
INFO - 2023-10-20 08:11:39 --> Loader Class Initialized
INFO - 2023-10-20 08:11:39 --> Helper loaded: url_helper
INFO - 2023-10-20 08:11:39 --> Helper loaded: file_helper
INFO - 2023-10-20 08:11:39 --> Helper loaded: html_helper
INFO - 2023-10-20 08:11:39 --> Helper loaded: text_helper
INFO - 2023-10-20 08:11:39 --> Helper loaded: form_helper
INFO - 2023-10-20 08:11:39 --> Helper loaded: lang_helper
INFO - 2023-10-20 08:11:39 --> Helper loaded: security_helper
INFO - 2023-10-20 08:11:39 --> Helper loaded: cookie_helper
INFO - 2023-10-20 08:11:39 --> Database Driver Class Initialized
INFO - 2023-10-20 08:11:39 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-20 08:11:39 --> Parser Class Initialized
INFO - 2023-10-20 08:11:39 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-20 08:11:39 --> Pagination Class Initialized
INFO - 2023-10-20 08:11:39 --> Form Validation Class Initialized
INFO - 2023-10-20 08:11:39 --> Controller Class Initialized
INFO - 2023-10-20 08:11:39 --> Model Class Initialized
DEBUG - 2023-10-20 08:11:39 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-20 08:11:39 --> Final output sent to browser
DEBUG - 2023-10-20 08:11:39 --> Total execution time: 0.0144
ERROR - 2023-10-20 08:11:39 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-20 08:11:39 --> Config Class Initialized
INFO - 2023-10-20 08:11:39 --> Hooks Class Initialized
DEBUG - 2023-10-20 08:11:39 --> UTF-8 Support Enabled
INFO - 2023-10-20 08:11:39 --> Utf8 Class Initialized
INFO - 2023-10-20 08:11:39 --> URI Class Initialized
INFO - 2023-10-20 08:11:39 --> Router Class Initialized
INFO - 2023-10-20 08:11:39 --> Output Class Initialized
INFO - 2023-10-20 08:11:39 --> Security Class Initialized
DEBUG - 2023-10-20 08:11:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-20 08:11:39 --> Input Class Initialized
INFO - 2023-10-20 08:11:39 --> Language Class Initialized
INFO - 2023-10-20 08:11:39 --> Loader Class Initialized
INFO - 2023-10-20 08:11:39 --> Helper loaded: url_helper
INFO - 2023-10-20 08:11:39 --> Helper loaded: file_helper
INFO - 2023-10-20 08:11:39 --> Helper loaded: html_helper
INFO - 2023-10-20 08:11:39 --> Helper loaded: text_helper
INFO - 2023-10-20 08:11:39 --> Helper loaded: form_helper
INFO - 2023-10-20 08:11:39 --> Helper loaded: lang_helper
INFO - 2023-10-20 08:11:39 --> Helper loaded: security_helper
INFO - 2023-10-20 08:11:39 --> Helper loaded: cookie_helper
INFO - 2023-10-20 08:11:39 --> Database Driver Class Initialized
INFO - 2023-10-20 08:11:39 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-20 08:11:39 --> Parser Class Initialized
INFO - 2023-10-20 08:11:39 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-20 08:11:39 --> Pagination Class Initialized
INFO - 2023-10-20 08:11:39 --> Form Validation Class Initialized
INFO - 2023-10-20 08:11:39 --> Controller Class Initialized
INFO - 2023-10-20 08:11:39 --> Model Class Initialized
DEBUG - 2023-10-20 08:11:39 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-20 08:11:39 --> Final output sent to browser
DEBUG - 2023-10-20 08:11:39 --> Total execution time: 0.0197
ERROR - 2023-10-20 08:11:40 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-20 08:11:40 --> Config Class Initialized
INFO - 2023-10-20 08:11:40 --> Hooks Class Initialized
DEBUG - 2023-10-20 08:11:40 --> UTF-8 Support Enabled
INFO - 2023-10-20 08:11:40 --> Utf8 Class Initialized
INFO - 2023-10-20 08:11:40 --> URI Class Initialized
INFO - 2023-10-20 08:11:40 --> Router Class Initialized
INFO - 2023-10-20 08:11:40 --> Output Class Initialized
INFO - 2023-10-20 08:11:40 --> Security Class Initialized
DEBUG - 2023-10-20 08:11:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-20 08:11:40 --> Input Class Initialized
INFO - 2023-10-20 08:11:40 --> Language Class Initialized
INFO - 2023-10-20 08:11:40 --> Loader Class Initialized
INFO - 2023-10-20 08:11:40 --> Helper loaded: url_helper
INFO - 2023-10-20 08:11:40 --> Helper loaded: file_helper
INFO - 2023-10-20 08:11:40 --> Helper loaded: html_helper
INFO - 2023-10-20 08:11:40 --> Helper loaded: text_helper
INFO - 2023-10-20 08:11:40 --> Helper loaded: form_helper
INFO - 2023-10-20 08:11:40 --> Helper loaded: lang_helper
INFO - 2023-10-20 08:11:40 --> Helper loaded: security_helper
INFO - 2023-10-20 08:11:40 --> Helper loaded: cookie_helper
INFO - 2023-10-20 08:11:40 --> Database Driver Class Initialized
INFO - 2023-10-20 08:11:40 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-20 08:11:40 --> Parser Class Initialized
INFO - 2023-10-20 08:11:40 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-20 08:11:40 --> Pagination Class Initialized
INFO - 2023-10-20 08:11:40 --> Form Validation Class Initialized
INFO - 2023-10-20 08:11:40 --> Controller Class Initialized
INFO - 2023-10-20 08:11:40 --> Model Class Initialized
DEBUG - 2023-10-20 08:11:40 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-20 08:11:40 --> Final output sent to browser
DEBUG - 2023-10-20 08:11:40 --> Total execution time: 0.0145
ERROR - 2023-10-20 08:11:40 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-20 08:11:40 --> Config Class Initialized
INFO - 2023-10-20 08:11:40 --> Hooks Class Initialized
DEBUG - 2023-10-20 08:11:40 --> UTF-8 Support Enabled
INFO - 2023-10-20 08:11:40 --> Utf8 Class Initialized
INFO - 2023-10-20 08:11:40 --> URI Class Initialized
INFO - 2023-10-20 08:11:40 --> Router Class Initialized
INFO - 2023-10-20 08:11:40 --> Output Class Initialized
INFO - 2023-10-20 08:11:40 --> Security Class Initialized
DEBUG - 2023-10-20 08:11:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-20 08:11:40 --> Input Class Initialized
INFO - 2023-10-20 08:11:40 --> Language Class Initialized
INFO - 2023-10-20 08:11:40 --> Loader Class Initialized
INFO - 2023-10-20 08:11:40 --> Helper loaded: url_helper
INFO - 2023-10-20 08:11:40 --> Helper loaded: file_helper
INFO - 2023-10-20 08:11:40 --> Helper loaded: html_helper
INFO - 2023-10-20 08:11:40 --> Helper loaded: text_helper
INFO - 2023-10-20 08:11:40 --> Helper loaded: form_helper
INFO - 2023-10-20 08:11:40 --> Helper loaded: lang_helper
INFO - 2023-10-20 08:11:40 --> Helper loaded: security_helper
INFO - 2023-10-20 08:11:40 --> Helper loaded: cookie_helper
INFO - 2023-10-20 08:11:40 --> Database Driver Class Initialized
INFO - 2023-10-20 08:11:40 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-20 08:11:40 --> Parser Class Initialized
INFO - 2023-10-20 08:11:40 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-20 08:11:40 --> Pagination Class Initialized
INFO - 2023-10-20 08:11:40 --> Form Validation Class Initialized
INFO - 2023-10-20 08:11:40 --> Controller Class Initialized
INFO - 2023-10-20 08:11:40 --> Model Class Initialized
DEBUG - 2023-10-20 08:11:40 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-20 08:11:40 --> Final output sent to browser
DEBUG - 2023-10-20 08:11:40 --> Total execution time: 0.0146
ERROR - 2023-10-20 08:11:41 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-20 08:11:41 --> Config Class Initialized
INFO - 2023-10-20 08:11:41 --> Hooks Class Initialized
DEBUG - 2023-10-20 08:11:41 --> UTF-8 Support Enabled
INFO - 2023-10-20 08:11:41 --> Utf8 Class Initialized
INFO - 2023-10-20 08:11:41 --> URI Class Initialized
INFO - 2023-10-20 08:11:41 --> Router Class Initialized
INFO - 2023-10-20 08:11:41 --> Output Class Initialized
INFO - 2023-10-20 08:11:41 --> Security Class Initialized
DEBUG - 2023-10-20 08:11:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-20 08:11:41 --> Input Class Initialized
INFO - 2023-10-20 08:11:41 --> Language Class Initialized
INFO - 2023-10-20 08:11:41 --> Loader Class Initialized
INFO - 2023-10-20 08:11:41 --> Helper loaded: url_helper
INFO - 2023-10-20 08:11:41 --> Helper loaded: file_helper
INFO - 2023-10-20 08:11:41 --> Helper loaded: html_helper
INFO - 2023-10-20 08:11:41 --> Helper loaded: text_helper
INFO - 2023-10-20 08:11:41 --> Helper loaded: form_helper
INFO - 2023-10-20 08:11:41 --> Helper loaded: lang_helper
INFO - 2023-10-20 08:11:41 --> Helper loaded: security_helper
INFO - 2023-10-20 08:11:41 --> Helper loaded: cookie_helper
INFO - 2023-10-20 08:11:41 --> Database Driver Class Initialized
INFO - 2023-10-20 08:11:41 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-20 08:11:41 --> Parser Class Initialized
INFO - 2023-10-20 08:11:41 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-20 08:11:41 --> Pagination Class Initialized
INFO - 2023-10-20 08:11:41 --> Form Validation Class Initialized
INFO - 2023-10-20 08:11:41 --> Controller Class Initialized
INFO - 2023-10-20 08:11:41 --> Final output sent to browser
DEBUG - 2023-10-20 08:11:41 --> Total execution time: 0.0174
ERROR - 2023-10-20 08:11:44 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-20 08:11:44 --> Config Class Initialized
INFO - 2023-10-20 08:11:44 --> Hooks Class Initialized
DEBUG - 2023-10-20 08:11:44 --> UTF-8 Support Enabled
INFO - 2023-10-20 08:11:44 --> Utf8 Class Initialized
INFO - 2023-10-20 08:11:44 --> URI Class Initialized
INFO - 2023-10-20 08:11:44 --> Router Class Initialized
INFO - 2023-10-20 08:11:44 --> Output Class Initialized
INFO - 2023-10-20 08:11:44 --> Security Class Initialized
DEBUG - 2023-10-20 08:11:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-20 08:11:44 --> Input Class Initialized
INFO - 2023-10-20 08:11:44 --> Language Class Initialized
INFO - 2023-10-20 08:11:44 --> Loader Class Initialized
INFO - 2023-10-20 08:11:44 --> Helper loaded: url_helper
INFO - 2023-10-20 08:11:44 --> Helper loaded: file_helper
INFO - 2023-10-20 08:11:44 --> Helper loaded: html_helper
INFO - 2023-10-20 08:11:44 --> Helper loaded: text_helper
INFO - 2023-10-20 08:11:44 --> Helper loaded: form_helper
INFO - 2023-10-20 08:11:44 --> Helper loaded: lang_helper
INFO - 2023-10-20 08:11:44 --> Helper loaded: security_helper
INFO - 2023-10-20 08:11:44 --> Helper loaded: cookie_helper
INFO - 2023-10-20 08:11:44 --> Database Driver Class Initialized
INFO - 2023-10-20 08:11:44 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-20 08:11:44 --> Parser Class Initialized
INFO - 2023-10-20 08:11:44 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-20 08:11:44 --> Pagination Class Initialized
INFO - 2023-10-20 08:11:44 --> Form Validation Class Initialized
INFO - 2023-10-20 08:11:44 --> Controller Class Initialized
INFO - 2023-10-20 08:11:44 --> Model Class Initialized
DEBUG - 2023-10-20 08:11:44 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-10-20 08:11:44 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-20 08:11:44 --> Model Class Initialized
DEBUG - 2023-10-20 08:11:44 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-20 08:11:44 --> Model Class Initialized
INFO - 2023-10-20 08:11:44 --> Final output sent to browser
DEBUG - 2023-10-20 08:11:44 --> Total execution time: 0.1506
ERROR - 2023-10-20 08:11:45 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-20 08:11:45 --> Config Class Initialized
INFO - 2023-10-20 08:11:45 --> Hooks Class Initialized
DEBUG - 2023-10-20 08:11:45 --> UTF-8 Support Enabled
INFO - 2023-10-20 08:11:45 --> Utf8 Class Initialized
INFO - 2023-10-20 08:11:45 --> URI Class Initialized
INFO - 2023-10-20 08:11:45 --> Router Class Initialized
INFO - 2023-10-20 08:11:45 --> Output Class Initialized
INFO - 2023-10-20 08:11:45 --> Security Class Initialized
DEBUG - 2023-10-20 08:11:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-20 08:11:45 --> Input Class Initialized
INFO - 2023-10-20 08:11:45 --> Language Class Initialized
INFO - 2023-10-20 08:11:45 --> Loader Class Initialized
INFO - 2023-10-20 08:11:45 --> Helper loaded: url_helper
INFO - 2023-10-20 08:11:45 --> Helper loaded: file_helper
INFO - 2023-10-20 08:11:45 --> Helper loaded: html_helper
INFO - 2023-10-20 08:11:45 --> Helper loaded: text_helper
INFO - 2023-10-20 08:11:45 --> Helper loaded: form_helper
INFO - 2023-10-20 08:11:45 --> Helper loaded: lang_helper
INFO - 2023-10-20 08:11:45 --> Helper loaded: security_helper
INFO - 2023-10-20 08:11:45 --> Helper loaded: cookie_helper
INFO - 2023-10-20 08:11:45 --> Database Driver Class Initialized
INFO - 2023-10-20 08:11:45 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-20 08:11:45 --> Parser Class Initialized
INFO - 2023-10-20 08:11:45 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-20 08:11:45 --> Pagination Class Initialized
INFO - 2023-10-20 08:11:45 --> Form Validation Class Initialized
INFO - 2023-10-20 08:11:45 --> Controller Class Initialized
INFO - 2023-10-20 08:11:45 --> Model Class Initialized
DEBUG - 2023-10-20 08:11:45 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-10-20 08:11:45 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-20 08:11:45 --> Model Class Initialized
DEBUG - 2023-10-20 08:11:45 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-20 08:11:45 --> Model Class Initialized
INFO - 2023-10-20 08:11:45 --> Final output sent to browser
DEBUG - 2023-10-20 08:11:45 --> Total execution time: 0.1542
ERROR - 2023-10-20 08:11:45 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-20 08:11:45 --> Config Class Initialized
INFO - 2023-10-20 08:11:45 --> Hooks Class Initialized
DEBUG - 2023-10-20 08:11:45 --> UTF-8 Support Enabled
INFO - 2023-10-20 08:11:45 --> Utf8 Class Initialized
INFO - 2023-10-20 08:11:45 --> URI Class Initialized
INFO - 2023-10-20 08:11:45 --> Router Class Initialized
INFO - 2023-10-20 08:11:45 --> Output Class Initialized
INFO - 2023-10-20 08:11:45 --> Security Class Initialized
DEBUG - 2023-10-20 08:11:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-20 08:11:45 --> Input Class Initialized
INFO - 2023-10-20 08:11:45 --> Language Class Initialized
INFO - 2023-10-20 08:11:45 --> Loader Class Initialized
INFO - 2023-10-20 08:11:45 --> Helper loaded: url_helper
INFO - 2023-10-20 08:11:45 --> Helper loaded: file_helper
INFO - 2023-10-20 08:11:45 --> Helper loaded: html_helper
INFO - 2023-10-20 08:11:45 --> Helper loaded: text_helper
INFO - 2023-10-20 08:11:45 --> Helper loaded: form_helper
INFO - 2023-10-20 08:11:45 --> Helper loaded: lang_helper
INFO - 2023-10-20 08:11:45 --> Helper loaded: security_helper
INFO - 2023-10-20 08:11:45 --> Helper loaded: cookie_helper
INFO - 2023-10-20 08:11:45 --> Database Driver Class Initialized
INFO - 2023-10-20 08:11:45 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-20 08:11:45 --> Parser Class Initialized
INFO - 2023-10-20 08:11:45 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-20 08:11:45 --> Pagination Class Initialized
INFO - 2023-10-20 08:11:45 --> Form Validation Class Initialized
INFO - 2023-10-20 08:11:45 --> Controller Class Initialized
INFO - 2023-10-20 08:11:45 --> Model Class Initialized
DEBUG - 2023-10-20 08:11:45 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-10-20 08:11:45 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-20 08:11:45 --> Model Class Initialized
DEBUG - 2023-10-20 08:11:45 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-20 08:11:45 --> Model Class Initialized
INFO - 2023-10-20 08:11:46 --> Final output sent to browser
DEBUG - 2023-10-20 08:11:46 --> Total execution time: 0.0554
ERROR - 2023-10-20 08:11:46 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-20 08:11:46 --> Config Class Initialized
INFO - 2023-10-20 08:11:46 --> Hooks Class Initialized
DEBUG - 2023-10-20 08:11:46 --> UTF-8 Support Enabled
INFO - 2023-10-20 08:11:46 --> Utf8 Class Initialized
INFO - 2023-10-20 08:11:46 --> URI Class Initialized
INFO - 2023-10-20 08:11:46 --> Router Class Initialized
INFO - 2023-10-20 08:11:46 --> Output Class Initialized
INFO - 2023-10-20 08:11:46 --> Security Class Initialized
DEBUG - 2023-10-20 08:11:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-20 08:11:46 --> Input Class Initialized
INFO - 2023-10-20 08:11:46 --> Language Class Initialized
INFO - 2023-10-20 08:11:46 --> Loader Class Initialized
INFO - 2023-10-20 08:11:46 --> Helper loaded: url_helper
INFO - 2023-10-20 08:11:46 --> Helper loaded: file_helper
INFO - 2023-10-20 08:11:46 --> Helper loaded: html_helper
INFO - 2023-10-20 08:11:46 --> Helper loaded: text_helper
INFO - 2023-10-20 08:11:46 --> Helper loaded: form_helper
INFO - 2023-10-20 08:11:46 --> Helper loaded: lang_helper
INFO - 2023-10-20 08:11:46 --> Helper loaded: security_helper
INFO - 2023-10-20 08:11:46 --> Helper loaded: cookie_helper
INFO - 2023-10-20 08:11:46 --> Database Driver Class Initialized
INFO - 2023-10-20 08:11:46 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-20 08:11:46 --> Parser Class Initialized
INFO - 2023-10-20 08:11:46 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-20 08:11:46 --> Pagination Class Initialized
INFO - 2023-10-20 08:11:46 --> Form Validation Class Initialized
INFO - 2023-10-20 08:11:46 --> Controller Class Initialized
INFO - 2023-10-20 08:11:46 --> Model Class Initialized
DEBUG - 2023-10-20 08:11:46 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-10-20 08:11:46 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-20 08:11:46 --> Model Class Initialized
DEBUG - 2023-10-20 08:11:46 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-20 08:11:46 --> Model Class Initialized
INFO - 2023-10-20 08:11:46 --> Final output sent to browser
DEBUG - 2023-10-20 08:11:46 --> Total execution time: 0.0382
ERROR - 2023-10-20 08:11:48 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-20 08:11:48 --> Config Class Initialized
INFO - 2023-10-20 08:11:48 --> Hooks Class Initialized
DEBUG - 2023-10-20 08:11:48 --> UTF-8 Support Enabled
INFO - 2023-10-20 08:11:48 --> Utf8 Class Initialized
INFO - 2023-10-20 08:11:48 --> URI Class Initialized
INFO - 2023-10-20 08:11:48 --> Router Class Initialized
INFO - 2023-10-20 08:11:48 --> Output Class Initialized
INFO - 2023-10-20 08:11:48 --> Security Class Initialized
DEBUG - 2023-10-20 08:11:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-20 08:11:48 --> Input Class Initialized
INFO - 2023-10-20 08:11:48 --> Language Class Initialized
INFO - 2023-10-20 08:11:48 --> Loader Class Initialized
INFO - 2023-10-20 08:11:48 --> Helper loaded: url_helper
INFO - 2023-10-20 08:11:48 --> Helper loaded: file_helper
INFO - 2023-10-20 08:11:48 --> Helper loaded: html_helper
INFO - 2023-10-20 08:11:48 --> Helper loaded: text_helper
INFO - 2023-10-20 08:11:48 --> Helper loaded: form_helper
INFO - 2023-10-20 08:11:48 --> Helper loaded: lang_helper
INFO - 2023-10-20 08:11:48 --> Helper loaded: security_helper
INFO - 2023-10-20 08:11:48 --> Helper loaded: cookie_helper
INFO - 2023-10-20 08:11:48 --> Database Driver Class Initialized
INFO - 2023-10-20 08:11:48 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-20 08:11:48 --> Parser Class Initialized
INFO - 2023-10-20 08:11:48 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-20 08:11:48 --> Pagination Class Initialized
INFO - 2023-10-20 08:11:48 --> Form Validation Class Initialized
INFO - 2023-10-20 08:11:48 --> Controller Class Initialized
INFO - 2023-10-20 08:11:48 --> Model Class Initialized
DEBUG - 2023-10-20 08:11:48 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-10-20 08:11:48 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-20 08:11:48 --> Model Class Initialized
INFO - 2023-10-20 08:11:48 --> Model Class Initialized
INFO - 2023-10-20 08:11:48 --> Final output sent to browser
DEBUG - 2023-10-20 08:11:48 --> Total execution time: 0.0202
ERROR - 2023-10-20 08:11:49 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-20 08:11:49 --> Config Class Initialized
INFO - 2023-10-20 08:11:49 --> Hooks Class Initialized
DEBUG - 2023-10-20 08:11:49 --> UTF-8 Support Enabled
INFO - 2023-10-20 08:11:49 --> Utf8 Class Initialized
INFO - 2023-10-20 08:11:49 --> URI Class Initialized
INFO - 2023-10-20 08:11:49 --> Router Class Initialized
INFO - 2023-10-20 08:11:49 --> Output Class Initialized
INFO - 2023-10-20 08:11:49 --> Security Class Initialized
DEBUG - 2023-10-20 08:11:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-20 08:11:49 --> Input Class Initialized
INFO - 2023-10-20 08:11:49 --> Language Class Initialized
INFO - 2023-10-20 08:11:49 --> Loader Class Initialized
INFO - 2023-10-20 08:11:49 --> Helper loaded: url_helper
INFO - 2023-10-20 08:11:49 --> Helper loaded: file_helper
INFO - 2023-10-20 08:11:49 --> Helper loaded: html_helper
INFO - 2023-10-20 08:11:49 --> Helper loaded: text_helper
INFO - 2023-10-20 08:11:49 --> Helper loaded: form_helper
INFO - 2023-10-20 08:11:49 --> Helper loaded: lang_helper
INFO - 2023-10-20 08:11:49 --> Helper loaded: security_helper
INFO - 2023-10-20 08:11:49 --> Helper loaded: cookie_helper
INFO - 2023-10-20 08:11:49 --> Database Driver Class Initialized
INFO - 2023-10-20 08:11:49 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-20 08:11:49 --> Parser Class Initialized
INFO - 2023-10-20 08:11:49 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-20 08:11:49 --> Pagination Class Initialized
INFO - 2023-10-20 08:11:49 --> Form Validation Class Initialized
INFO - 2023-10-20 08:11:49 --> Controller Class Initialized
INFO - 2023-10-20 08:11:49 --> Model Class Initialized
DEBUG - 2023-10-20 08:11:49 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-10-20 08:11:49 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-20 08:11:49 --> Model Class Initialized
INFO - 2023-10-20 08:11:49 --> Final output sent to browser
DEBUG - 2023-10-20 08:11:49 --> Total execution time: 0.0163
ERROR - 2023-10-20 08:11:50 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-20 08:11:50 --> Config Class Initialized
INFO - 2023-10-20 08:11:50 --> Hooks Class Initialized
DEBUG - 2023-10-20 08:11:50 --> UTF-8 Support Enabled
INFO - 2023-10-20 08:11:50 --> Utf8 Class Initialized
INFO - 2023-10-20 08:11:50 --> URI Class Initialized
INFO - 2023-10-20 08:11:50 --> Router Class Initialized
INFO - 2023-10-20 08:11:50 --> Output Class Initialized
INFO - 2023-10-20 08:11:50 --> Security Class Initialized
DEBUG - 2023-10-20 08:11:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-20 08:11:50 --> Input Class Initialized
INFO - 2023-10-20 08:11:50 --> Language Class Initialized
INFO - 2023-10-20 08:11:50 --> Loader Class Initialized
INFO - 2023-10-20 08:11:50 --> Helper loaded: url_helper
INFO - 2023-10-20 08:11:50 --> Helper loaded: file_helper
INFO - 2023-10-20 08:11:50 --> Helper loaded: html_helper
INFO - 2023-10-20 08:11:50 --> Helper loaded: text_helper
INFO - 2023-10-20 08:11:50 --> Helper loaded: form_helper
INFO - 2023-10-20 08:11:50 --> Helper loaded: lang_helper
INFO - 2023-10-20 08:11:50 --> Helper loaded: security_helper
INFO - 2023-10-20 08:11:50 --> Helper loaded: cookie_helper
INFO - 2023-10-20 08:11:50 --> Database Driver Class Initialized
INFO - 2023-10-20 08:11:50 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-20 08:11:50 --> Parser Class Initialized
INFO - 2023-10-20 08:11:50 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-20 08:11:50 --> Pagination Class Initialized
INFO - 2023-10-20 08:11:50 --> Form Validation Class Initialized
INFO - 2023-10-20 08:11:50 --> Controller Class Initialized
INFO - 2023-10-20 08:11:50 --> Model Class Initialized
DEBUG - 2023-10-20 08:11:50 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-10-20 08:11:50 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-20 08:11:50 --> Model Class Initialized
INFO - 2023-10-20 08:11:50 --> Final output sent to browser
DEBUG - 2023-10-20 08:11:50 --> Total execution time: 0.0172
ERROR - 2023-10-20 08:12:05 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-20 08:12:05 --> Config Class Initialized
INFO - 2023-10-20 08:12:05 --> Hooks Class Initialized
DEBUG - 2023-10-20 08:12:05 --> UTF-8 Support Enabled
INFO - 2023-10-20 08:12:05 --> Utf8 Class Initialized
INFO - 2023-10-20 08:12:05 --> URI Class Initialized
INFO - 2023-10-20 08:12:05 --> Router Class Initialized
INFO - 2023-10-20 08:12:05 --> Output Class Initialized
INFO - 2023-10-20 08:12:05 --> Security Class Initialized
DEBUG - 2023-10-20 08:12:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-20 08:12:05 --> Input Class Initialized
INFO - 2023-10-20 08:12:05 --> Language Class Initialized
INFO - 2023-10-20 08:12:05 --> Loader Class Initialized
INFO - 2023-10-20 08:12:05 --> Helper loaded: url_helper
INFO - 2023-10-20 08:12:05 --> Helper loaded: file_helper
INFO - 2023-10-20 08:12:05 --> Helper loaded: html_helper
INFO - 2023-10-20 08:12:05 --> Helper loaded: text_helper
INFO - 2023-10-20 08:12:05 --> Helper loaded: form_helper
INFO - 2023-10-20 08:12:05 --> Helper loaded: lang_helper
INFO - 2023-10-20 08:12:05 --> Helper loaded: security_helper
INFO - 2023-10-20 08:12:05 --> Helper loaded: cookie_helper
INFO - 2023-10-20 08:12:05 --> Database Driver Class Initialized
INFO - 2023-10-20 08:12:05 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-20 08:12:05 --> Parser Class Initialized
INFO - 2023-10-20 08:12:05 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-20 08:12:05 --> Pagination Class Initialized
INFO - 2023-10-20 08:12:05 --> Form Validation Class Initialized
INFO - 2023-10-20 08:12:05 --> Controller Class Initialized
INFO - 2023-10-20 08:12:05 --> Model Class Initialized
DEBUG - 2023-10-20 08:12:05 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-10-20 08:12:05 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-20 08:12:05 --> Model Class Initialized
DEBUG - 2023-10-20 08:12:05 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-20 08:12:05 --> Model Class Initialized
INFO - 2023-10-20 08:12:05 --> Email Class Initialized
DEBUG - 2023-10-20 08:12:05 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-20 08:12:05 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice_html_pdf.php
ERROR - 2023-10-20 08:12:05 --> Severity: Warning --> "continue" targeting switch is equivalent to "break". Did you mean to use "continue 2"? /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/dompdf.cls.php 743
ERROR - 2023-10-20 08:12:05 --> Severity: Warning --> "continue" targeting switch is equivalent to "break". Did you mean to use "continue 2"? /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/dompdf.cls.php 763
ERROR - 2023-10-20 08:12:05 --> Severity: Warning --> "continue" targeting switch is equivalent to "break". Did you mean to use "continue 2"? /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/stylesheet.cls.php 1102
ERROR - 2023-10-20 08:12:05 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/page_frame_decorator.cls.php 439
ERROR - 2023-10-20 08:12:05 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/page_frame_decorator.cls.php 439
ERROR - 2023-10-20 08:12:05 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/page_frame_decorator.cls.php 439
ERROR - 2023-10-20 08:12:05 --> Severity: Warning --> Division by zero /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 572
ERROR - 2023-10-20 08:12:05 --> Severity: Warning --> Division by zero /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 572
ERROR - 2023-10-20 08:12:05 --> Severity: Warning --> Division by zero /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 572
ERROR - 2023-10-20 08:12:05 --> Severity: Warning --> Division by zero /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 572
ERROR - 2023-10-20 08:12:05 --> Severity: Warning --> Division by zero /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 572
ERROR - 2023-10-20 08:12:05 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/table_cell_frame_reflower.cls.php 103
ERROR - 2023-10-20 08:12:05 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/table_cell_frame_reflower.cls.php 103
ERROR - 2023-10-20 08:12:05 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/table_cell_frame_reflower.cls.php 103
ERROR - 2023-10-20 08:12:05 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/table_cell_frame_reflower.cls.php 103
ERROR - 2023-10-20 08:12:05 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/table_cell_frame_reflower.cls.php 103
ERROR - 2023-10-20 08:12:05 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/table_cell_frame_reflower.cls.php 103
ERROR - 2023-10-20 08:12:05 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/table_cell_frame_reflower.cls.php 103
ERROR - 2023-10-20 08:12:05 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/table_cell_frame_reflower.cls.php 103
ERROR - 2023-10-20 08:12:05 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/table_cell_frame_reflower.cls.php 103
ERROR - 2023-10-20 08:12:05 --> Severity: Warning --> Invalid argument supplied for foreach() /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 709
ERROR - 2023-10-20 08:12:05 --> Severity: Warning --> Invalid argument supplied for foreach() /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 709
ERROR - 2023-10-20 08:12:05 --> Severity: Warning --> Invalid argument supplied for foreach() /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 709
ERROR - 2023-10-20 08:12:05 --> Severity: Warning --> Invalid argument supplied for foreach() /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 709
ERROR - 2023-10-20 08:12:05 --> Severity: Warning --> Invalid argument supplied for foreach() /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 709
ERROR - 2023-10-20 08:12:05 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-10-20 08:12:05 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-10-20 08:12:05 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-10-20 08:12:05 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-10-20 08:12:05 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-10-20 08:12:05 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-10-20 08:12:05 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-10-20 08:12:05 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-10-20 08:12:05 --> Severity: Warning --> "continue" targeting switch is equivalent to "break". Did you mean to use "continue 2"? /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/text_renderer.cls.php 126
ERROR - 2023-10-20 08:12:05 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-10-20 08:12:05 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-10-20 08:12:05 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-10-20 08:12:05 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-10-20 08:12:05 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-10-20 08:12:05 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-10-20 08:12:05 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-10-20 08:12:05 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-10-20 08:12:05 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-10-20 08:12:05 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-10-20 08:12:05 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-10-20 08:12:05 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-10-20 08:12:05 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-10-20 08:12:05 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-10-20 08:12:05 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-10-20 08:12:05 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-10-20 08:12:05 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-10-20 08:12:05 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-10-20 08:12:05 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-10-20 08:12:05 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-10-20 08:12:05 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-10-20 08:12:05 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-10-20 08:12:05 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-10-20 08:12:05 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-10-20 08:12:05 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-10-20 08:12:05 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-10-20 08:12:05 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-10-20 08:12:05 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-10-20 08:12:05 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-10-20 08:12:05 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-10-20 08:12:05 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-10-20 08:12:05 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-10-20 08:12:05 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-10-20 08:12:05 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-10-20 08:12:05 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-10-20 08:12:05 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-10-20 08:12:05 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-10-20 08:12:05 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-10-20 08:12:05 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-10-20 08:12:05 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-10-20 08:12:05 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-10-20 08:12:05 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-10-20 08:12:05 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-10-20 08:12:05 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-10-20 08:12:05 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-10-20 08:12:05 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-10-20 08:12:05 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-10-20 08:12:05 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-10-20 08:12:05 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-10-20 08:12:05 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-10-20 08:12:05 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-10-20 08:12:05 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-10-20 08:12:05 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-10-20 08:12:05 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-10-20 08:12:05 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-10-20 08:12:05 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-10-20 08:12:05 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-10-20 08:12:05 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-10-20 08:12:05 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-10-20 08:12:05 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-10-20 08:12:05 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-10-20 08:12:05 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-10-20 08:12:05 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-10-20 08:12:05 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-10-20 08:12:05 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-10-20 08:12:05 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-10-20 08:12:05 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-10-20 08:12:05 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-10-20 08:12:05 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-10-20 08:12:05 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-10-20 08:12:05 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-10-20 08:12:05 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-10-20 08:12:05 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-10-20 08:12:05 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-10-20 08:12:05 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-10-20 08:12:05 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-10-20 08:12:05 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-10-20 08:12:05 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-10-20 08:12:05 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-10-20 08:12:05 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-10-20 08:12:05 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-10-20 08:12:05 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-10-20 08:12:05 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-10-20 08:12:05 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-10-20 08:12:05 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-10-20 08:12:05 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-10-20 08:12:05 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-10-20 08:12:05 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-10-20 08:12:05 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-10-20 08:12:05 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-10-20 08:12:05 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-10-20 08:12:05 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-10-20 08:12:05 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-10-20 08:12:05 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-10-20 08:12:05 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-10-20 08:12:05 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
INFO - 2023-10-20 08:12:06 --> Language file loaded: language/english/email_lang.php
INFO - 2023-10-20 08:12:06 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice_html.php
INFO - 2023-10-20 08:12:06 --> Final output sent to browser
DEBUG - 2023-10-20 08:12:06 --> Total execution time: 0.5034
ERROR - 2023-10-20 08:12:09 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-20 08:12:09 --> Config Class Initialized
INFO - 2023-10-20 08:12:09 --> Hooks Class Initialized
DEBUG - 2023-10-20 08:12:09 --> UTF-8 Support Enabled
INFO - 2023-10-20 08:12:09 --> Utf8 Class Initialized
INFO - 2023-10-20 08:12:09 --> URI Class Initialized
INFO - 2023-10-20 08:12:09 --> Router Class Initialized
INFO - 2023-10-20 08:12:09 --> Output Class Initialized
INFO - 2023-10-20 08:12:09 --> Security Class Initialized
DEBUG - 2023-10-20 08:12:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-20 08:12:09 --> Input Class Initialized
INFO - 2023-10-20 08:12:09 --> Language Class Initialized
INFO - 2023-10-20 08:12:09 --> Loader Class Initialized
INFO - 2023-10-20 08:12:09 --> Helper loaded: url_helper
INFO - 2023-10-20 08:12:09 --> Helper loaded: file_helper
INFO - 2023-10-20 08:12:09 --> Helper loaded: html_helper
INFO - 2023-10-20 08:12:09 --> Helper loaded: text_helper
INFO - 2023-10-20 08:12:09 --> Helper loaded: form_helper
INFO - 2023-10-20 08:12:09 --> Helper loaded: lang_helper
INFO - 2023-10-20 08:12:09 --> Helper loaded: security_helper
INFO - 2023-10-20 08:12:09 --> Helper loaded: cookie_helper
INFO - 2023-10-20 08:12:09 --> Database Driver Class Initialized
INFO - 2023-10-20 08:12:09 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-20 08:12:09 --> Parser Class Initialized
INFO - 2023-10-20 08:12:09 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-20 08:12:09 --> Pagination Class Initialized
INFO - 2023-10-20 08:12:09 --> Form Validation Class Initialized
INFO - 2023-10-20 08:12:09 --> Controller Class Initialized
INFO - 2023-10-20 08:12:09 --> Model Class Initialized
DEBUG - 2023-10-20 08:12:09 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-10-20 08:12:09 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-20 08:12:09 --> Model Class Initialized
DEBUG - 2023-10-20 08:12:09 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-20 08:12:09 --> Model Class Initialized
INFO - 2023-10-20 08:12:09 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/add_invoice_form.php
DEBUG - 2023-10-20 08:12:09 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-10-20 08:12:09 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-10-20 08:12:09 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-10-20 08:12:09 --> Model Class Initialized
INFO - 2023-10-20 08:12:09 --> Model Class Initialized
INFO - 2023-10-20 08:12:09 --> Model Class Initialized
INFO - 2023-10-20 08:12:09 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-10-20 08:12:09 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-10-20 08:12:09 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-10-20 08:12:09 --> Final output sent to browser
DEBUG - 2023-10-20 08:12:09 --> Total execution time: 0.1693
ERROR - 2023-10-20 08:12:14 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-20 08:12:14 --> Config Class Initialized
INFO - 2023-10-20 08:12:14 --> Hooks Class Initialized
DEBUG - 2023-10-20 08:12:14 --> UTF-8 Support Enabled
INFO - 2023-10-20 08:12:14 --> Utf8 Class Initialized
INFO - 2023-10-20 08:12:14 --> URI Class Initialized
INFO - 2023-10-20 08:12:14 --> Router Class Initialized
INFO - 2023-10-20 08:12:14 --> Output Class Initialized
INFO - 2023-10-20 08:12:14 --> Security Class Initialized
DEBUG - 2023-10-20 08:12:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-20 08:12:14 --> Input Class Initialized
INFO - 2023-10-20 08:12:14 --> Language Class Initialized
INFO - 2023-10-20 08:12:14 --> Loader Class Initialized
INFO - 2023-10-20 08:12:14 --> Helper loaded: url_helper
INFO - 2023-10-20 08:12:14 --> Helper loaded: file_helper
INFO - 2023-10-20 08:12:14 --> Helper loaded: html_helper
INFO - 2023-10-20 08:12:14 --> Helper loaded: text_helper
INFO - 2023-10-20 08:12:14 --> Helper loaded: form_helper
INFO - 2023-10-20 08:12:14 --> Helper loaded: lang_helper
INFO - 2023-10-20 08:12:14 --> Helper loaded: security_helper
INFO - 2023-10-20 08:12:14 --> Helper loaded: cookie_helper
INFO - 2023-10-20 08:12:14 --> Database Driver Class Initialized
INFO - 2023-10-20 08:12:14 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-20 08:12:14 --> Parser Class Initialized
INFO - 2023-10-20 08:12:14 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-20 08:12:14 --> Pagination Class Initialized
INFO - 2023-10-20 08:12:14 --> Form Validation Class Initialized
INFO - 2023-10-20 08:12:14 --> Controller Class Initialized
INFO - 2023-10-20 08:12:14 --> Model Class Initialized
DEBUG - 2023-10-20 08:12:14 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-10-20 08:12:14 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-20 08:12:14 --> Model Class Initialized
DEBUG - 2023-10-20 08:12:14 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-20 08:12:14 --> Model Class Initialized
INFO - 2023-10-20 08:12:14 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice.php
DEBUG - 2023-10-20 08:12:14 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-10-20 08:12:14 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-10-20 08:12:14 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-10-20 08:12:14 --> Model Class Initialized
INFO - 2023-10-20 08:12:14 --> Model Class Initialized
INFO - 2023-10-20 08:12:14 --> Model Class Initialized
INFO - 2023-10-20 08:12:14 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-10-20 08:12:14 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-10-20 08:12:14 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-10-20 08:12:14 --> Final output sent to browser
DEBUG - 2023-10-20 08:12:14 --> Total execution time: 0.1391
ERROR - 2023-10-20 08:12:15 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-20 08:12:15 --> Config Class Initialized
INFO - 2023-10-20 08:12:15 --> Hooks Class Initialized
DEBUG - 2023-10-20 08:12:15 --> UTF-8 Support Enabled
INFO - 2023-10-20 08:12:15 --> Utf8 Class Initialized
INFO - 2023-10-20 08:12:15 --> URI Class Initialized
INFO - 2023-10-20 08:12:16 --> Router Class Initialized
INFO - 2023-10-20 08:12:16 --> Output Class Initialized
INFO - 2023-10-20 08:12:16 --> Security Class Initialized
DEBUG - 2023-10-20 08:12:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-20 08:12:16 --> Input Class Initialized
INFO - 2023-10-20 08:12:16 --> Language Class Initialized
INFO - 2023-10-20 08:12:16 --> Loader Class Initialized
INFO - 2023-10-20 08:12:16 --> Helper loaded: url_helper
INFO - 2023-10-20 08:12:16 --> Helper loaded: file_helper
INFO - 2023-10-20 08:12:16 --> Helper loaded: html_helper
INFO - 2023-10-20 08:12:16 --> Helper loaded: text_helper
INFO - 2023-10-20 08:12:16 --> Helper loaded: form_helper
INFO - 2023-10-20 08:12:16 --> Helper loaded: lang_helper
INFO - 2023-10-20 08:12:16 --> Helper loaded: security_helper
INFO - 2023-10-20 08:12:16 --> Helper loaded: cookie_helper
INFO - 2023-10-20 08:12:16 --> Database Driver Class Initialized
INFO - 2023-10-20 08:12:16 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-20 08:12:16 --> Parser Class Initialized
INFO - 2023-10-20 08:12:16 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-20 08:12:16 --> Pagination Class Initialized
INFO - 2023-10-20 08:12:16 --> Form Validation Class Initialized
INFO - 2023-10-20 08:12:16 --> Controller Class Initialized
INFO - 2023-10-20 08:12:16 --> Model Class Initialized
DEBUG - 2023-10-20 08:12:16 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-10-20 08:12:16 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-20 08:12:16 --> Model Class Initialized
DEBUG - 2023-10-20 08:12:16 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-20 08:12:16 --> Model Class Initialized
INFO - 2023-10-20 08:12:16 --> Final output sent to browser
DEBUG - 2023-10-20 08:12:16 --> Total execution time: 0.0468
ERROR - 2023-10-20 08:12:24 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-20 08:12:24 --> Config Class Initialized
INFO - 2023-10-20 08:12:24 --> Hooks Class Initialized
DEBUG - 2023-10-20 08:12:24 --> UTF-8 Support Enabled
INFO - 2023-10-20 08:12:24 --> Utf8 Class Initialized
INFO - 2023-10-20 08:12:24 --> URI Class Initialized
INFO - 2023-10-20 08:12:24 --> Router Class Initialized
INFO - 2023-10-20 08:12:24 --> Output Class Initialized
INFO - 2023-10-20 08:12:24 --> Security Class Initialized
DEBUG - 2023-10-20 08:12:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-20 08:12:24 --> Input Class Initialized
INFO - 2023-10-20 08:12:24 --> Language Class Initialized
INFO - 2023-10-20 08:12:24 --> Loader Class Initialized
INFO - 2023-10-20 08:12:24 --> Helper loaded: url_helper
INFO - 2023-10-20 08:12:24 --> Helper loaded: file_helper
INFO - 2023-10-20 08:12:24 --> Helper loaded: html_helper
INFO - 2023-10-20 08:12:24 --> Helper loaded: text_helper
INFO - 2023-10-20 08:12:24 --> Helper loaded: form_helper
INFO - 2023-10-20 08:12:24 --> Helper loaded: lang_helper
INFO - 2023-10-20 08:12:24 --> Helper loaded: security_helper
INFO - 2023-10-20 08:12:24 --> Helper loaded: cookie_helper
INFO - 2023-10-20 08:12:24 --> Database Driver Class Initialized
INFO - 2023-10-20 08:12:24 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-20 08:12:24 --> Parser Class Initialized
INFO - 2023-10-20 08:12:24 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-20 08:12:24 --> Pagination Class Initialized
INFO - 2023-10-20 08:12:24 --> Form Validation Class Initialized
INFO - 2023-10-20 08:12:24 --> Controller Class Initialized
INFO - 2023-10-20 08:12:24 --> Model Class Initialized
DEBUG - 2023-10-20 08:12:24 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-10-20 08:12:24 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-20 08:12:24 --> Model Class Initialized
DEBUG - 2023-10-20 08:12:24 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-20 08:12:24 --> Model Class Initialized
DEBUG - 2023-10-20 08:12:24 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-20 08:12:24 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice_html.php
DEBUG - 2023-10-20 08:12:24 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-10-20 08:12:24 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-10-20 08:12:24 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-10-20 08:12:24 --> Model Class Initialized
INFO - 2023-10-20 08:12:24 --> Model Class Initialized
INFO - 2023-10-20 08:12:24 --> Model Class Initialized
INFO - 2023-10-20 08:12:24 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-10-20 08:12:24 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-10-20 08:12:24 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-10-20 08:12:24 --> Final output sent to browser
DEBUG - 2023-10-20 08:12:24 --> Total execution time: 0.1422
ERROR - 2023-10-20 13:29:05 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-20 13:29:05 --> Config Class Initialized
INFO - 2023-10-20 13:29:05 --> Hooks Class Initialized
DEBUG - 2023-10-20 13:29:05 --> UTF-8 Support Enabled
INFO - 2023-10-20 13:29:05 --> Utf8 Class Initialized
INFO - 2023-10-20 13:29:05 --> URI Class Initialized
DEBUG - 2023-10-20 13:29:05 --> No URI present. Default controller set.
INFO - 2023-10-20 13:29:05 --> Router Class Initialized
INFO - 2023-10-20 13:29:05 --> Output Class Initialized
INFO - 2023-10-20 13:29:05 --> Security Class Initialized
DEBUG - 2023-10-20 13:29:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-20 13:29:05 --> Input Class Initialized
INFO - 2023-10-20 13:29:05 --> Language Class Initialized
INFO - 2023-10-20 13:29:05 --> Loader Class Initialized
INFO - 2023-10-20 13:29:05 --> Helper loaded: url_helper
INFO - 2023-10-20 13:29:05 --> Helper loaded: file_helper
INFO - 2023-10-20 13:29:05 --> Helper loaded: html_helper
INFO - 2023-10-20 13:29:05 --> Helper loaded: text_helper
INFO - 2023-10-20 13:29:05 --> Helper loaded: form_helper
INFO - 2023-10-20 13:29:05 --> Helper loaded: lang_helper
INFO - 2023-10-20 13:29:05 --> Helper loaded: security_helper
INFO - 2023-10-20 13:29:05 --> Helper loaded: cookie_helper
INFO - 2023-10-20 13:29:05 --> Database Driver Class Initialized
INFO - 2023-10-20 13:29:05 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-20 13:29:05 --> Parser Class Initialized
INFO - 2023-10-20 13:29:05 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-20 13:29:05 --> Pagination Class Initialized
INFO - 2023-10-20 13:29:05 --> Form Validation Class Initialized
INFO - 2023-10-20 13:29:05 --> Controller Class Initialized
INFO - 2023-10-20 13:29:05 --> Model Class Initialized
DEBUG - 2023-10-20 13:29:05 --> Session class already loaded. Second attempt ignored.
ERROR - 2023-10-20 13:29:05 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-20 13:29:05 --> Config Class Initialized
INFO - 2023-10-20 13:29:05 --> Hooks Class Initialized
DEBUG - 2023-10-20 13:29:05 --> UTF-8 Support Enabled
INFO - 2023-10-20 13:29:05 --> Utf8 Class Initialized
INFO - 2023-10-20 13:29:05 --> URI Class Initialized
INFO - 2023-10-20 13:29:05 --> Router Class Initialized
INFO - 2023-10-20 13:29:05 --> Output Class Initialized
INFO - 2023-10-20 13:29:05 --> Security Class Initialized
DEBUG - 2023-10-20 13:29:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-20 13:29:05 --> Input Class Initialized
INFO - 2023-10-20 13:29:05 --> Language Class Initialized
INFO - 2023-10-20 13:29:05 --> Loader Class Initialized
INFO - 2023-10-20 13:29:05 --> Helper loaded: url_helper
INFO - 2023-10-20 13:29:05 --> Helper loaded: file_helper
INFO - 2023-10-20 13:29:05 --> Helper loaded: html_helper
INFO - 2023-10-20 13:29:05 --> Helper loaded: text_helper
INFO - 2023-10-20 13:29:05 --> Helper loaded: form_helper
INFO - 2023-10-20 13:29:05 --> Helper loaded: lang_helper
INFO - 2023-10-20 13:29:05 --> Helper loaded: security_helper
INFO - 2023-10-20 13:29:05 --> Helper loaded: cookie_helper
INFO - 2023-10-20 13:29:05 --> Database Driver Class Initialized
INFO - 2023-10-20 13:29:05 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-20 13:29:05 --> Parser Class Initialized
INFO - 2023-10-20 13:29:05 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-20 13:29:05 --> Pagination Class Initialized
INFO - 2023-10-20 13:29:05 --> Form Validation Class Initialized
INFO - 2023-10-20 13:29:05 --> Controller Class Initialized
INFO - 2023-10-20 13:29:05 --> Model Class Initialized
DEBUG - 2023-10-20 13:29:05 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-20 13:29:05 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2023-10-20 13:29:05 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-10-20 13:29:05 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-10-20 13:29:05 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-10-20 13:29:05 --> Model Class Initialized
INFO - 2023-10-20 13:29:05 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-10-20 13:29:05 --> Final output sent to browser
DEBUG - 2023-10-20 13:29:05 --> Total execution time: 0.0340
ERROR - 2023-10-20 13:29:10 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-20 13:29:10 --> Config Class Initialized
INFO - 2023-10-20 13:29:10 --> Hooks Class Initialized
DEBUG - 2023-10-20 13:29:10 --> UTF-8 Support Enabled
INFO - 2023-10-20 13:29:10 --> Utf8 Class Initialized
INFO - 2023-10-20 13:29:10 --> URI Class Initialized
INFO - 2023-10-20 13:29:10 --> Router Class Initialized
INFO - 2023-10-20 13:29:10 --> Output Class Initialized
INFO - 2023-10-20 13:29:10 --> Security Class Initialized
DEBUG - 2023-10-20 13:29:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-20 13:29:10 --> Input Class Initialized
INFO - 2023-10-20 13:29:10 --> Language Class Initialized
INFO - 2023-10-20 13:29:10 --> Loader Class Initialized
INFO - 2023-10-20 13:29:10 --> Helper loaded: url_helper
INFO - 2023-10-20 13:29:10 --> Helper loaded: file_helper
INFO - 2023-10-20 13:29:10 --> Helper loaded: html_helper
INFO - 2023-10-20 13:29:10 --> Helper loaded: text_helper
INFO - 2023-10-20 13:29:10 --> Helper loaded: form_helper
INFO - 2023-10-20 13:29:10 --> Helper loaded: lang_helper
INFO - 2023-10-20 13:29:10 --> Helper loaded: security_helper
INFO - 2023-10-20 13:29:10 --> Helper loaded: cookie_helper
INFO - 2023-10-20 13:29:10 --> Database Driver Class Initialized
INFO - 2023-10-20 13:29:10 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-20 13:29:10 --> Parser Class Initialized
INFO - 2023-10-20 13:29:10 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-20 13:29:10 --> Pagination Class Initialized
INFO - 2023-10-20 13:29:10 --> Form Validation Class Initialized
INFO - 2023-10-20 13:29:10 --> Controller Class Initialized
INFO - 2023-10-20 13:29:10 --> Model Class Initialized
DEBUG - 2023-10-20 13:29:10 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-20 13:29:10 --> Model Class Initialized
INFO - 2023-10-20 13:29:10 --> Final output sent to browser
DEBUG - 2023-10-20 13:29:10 --> Total execution time: 0.0188
ERROR - 2023-10-20 13:29:13 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-20 13:29:13 --> Config Class Initialized
INFO - 2023-10-20 13:29:13 --> Hooks Class Initialized
DEBUG - 2023-10-20 13:29:13 --> UTF-8 Support Enabled
INFO - 2023-10-20 13:29:13 --> Utf8 Class Initialized
INFO - 2023-10-20 13:29:13 --> URI Class Initialized
DEBUG - 2023-10-20 13:29:13 --> No URI present. Default controller set.
INFO - 2023-10-20 13:29:13 --> Router Class Initialized
INFO - 2023-10-20 13:29:13 --> Output Class Initialized
INFO - 2023-10-20 13:29:13 --> Security Class Initialized
DEBUG - 2023-10-20 13:29:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-20 13:29:13 --> Input Class Initialized
INFO - 2023-10-20 13:29:13 --> Language Class Initialized
INFO - 2023-10-20 13:29:13 --> Loader Class Initialized
INFO - 2023-10-20 13:29:13 --> Helper loaded: url_helper
INFO - 2023-10-20 13:29:13 --> Helper loaded: file_helper
INFO - 2023-10-20 13:29:13 --> Helper loaded: html_helper
INFO - 2023-10-20 13:29:13 --> Helper loaded: text_helper
INFO - 2023-10-20 13:29:13 --> Helper loaded: form_helper
INFO - 2023-10-20 13:29:13 --> Helper loaded: lang_helper
INFO - 2023-10-20 13:29:13 --> Helper loaded: security_helper
INFO - 2023-10-20 13:29:13 --> Helper loaded: cookie_helper
INFO - 2023-10-20 13:29:13 --> Database Driver Class Initialized
INFO - 2023-10-20 13:29:13 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-20 13:29:13 --> Parser Class Initialized
INFO - 2023-10-20 13:29:13 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-20 13:29:13 --> Pagination Class Initialized
INFO - 2023-10-20 13:29:13 --> Form Validation Class Initialized
INFO - 2023-10-20 13:29:13 --> Controller Class Initialized
INFO - 2023-10-20 13:29:13 --> Model Class Initialized
DEBUG - 2023-10-20 13:29:13 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-20 13:29:13 --> Model Class Initialized
DEBUG - 2023-10-20 13:29:13 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-20 13:29:13 --> Model Class Initialized
INFO - 2023-10-20 13:29:13 --> Model Class Initialized
INFO - 2023-10-20 13:29:13 --> Model Class Initialized
INFO - 2023-10-20 13:29:13 --> Model Class Initialized
DEBUG - 2023-10-20 13:29:13 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-10-20 13:29:13 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-20 13:29:13 --> Model Class Initialized
INFO - 2023-10-20 13:29:13 --> Model Class Initialized
INFO - 2023-10-20 13:29:13 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-10-20 13:29:13 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-10-20 13:29:13 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-10-20 13:29:13 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-10-20 13:29:13 --> Model Class Initialized
INFO - 2023-10-20 13:29:13 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-10-20 13:29:13 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-10-20 13:29:13 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-10-20 13:29:13 --> Final output sent to browser
DEBUG - 2023-10-20 13:29:13 --> Total execution time: 0.3470
ERROR - 2023-10-20 13:29:14 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-20 13:29:14 --> Config Class Initialized
INFO - 2023-10-20 13:29:14 --> Hooks Class Initialized
DEBUG - 2023-10-20 13:29:14 --> UTF-8 Support Enabled
INFO - 2023-10-20 13:29:14 --> Utf8 Class Initialized
INFO - 2023-10-20 13:29:14 --> URI Class Initialized
INFO - 2023-10-20 13:29:14 --> Router Class Initialized
INFO - 2023-10-20 13:29:14 --> Output Class Initialized
INFO - 2023-10-20 13:29:14 --> Security Class Initialized
DEBUG - 2023-10-20 13:29:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-20 13:29:14 --> Input Class Initialized
INFO - 2023-10-20 13:29:14 --> Language Class Initialized
INFO - 2023-10-20 13:29:14 --> Loader Class Initialized
INFO - 2023-10-20 13:29:14 --> Helper loaded: url_helper
INFO - 2023-10-20 13:29:14 --> Helper loaded: file_helper
INFO - 2023-10-20 13:29:14 --> Helper loaded: html_helper
INFO - 2023-10-20 13:29:14 --> Helper loaded: text_helper
INFO - 2023-10-20 13:29:14 --> Helper loaded: form_helper
INFO - 2023-10-20 13:29:14 --> Helper loaded: lang_helper
INFO - 2023-10-20 13:29:14 --> Helper loaded: security_helper
INFO - 2023-10-20 13:29:14 --> Helper loaded: cookie_helper
INFO - 2023-10-20 13:29:14 --> Database Driver Class Initialized
INFO - 2023-10-20 13:29:14 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-20 13:29:14 --> Parser Class Initialized
INFO - 2023-10-20 13:29:14 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-20 13:29:14 --> Pagination Class Initialized
INFO - 2023-10-20 13:29:14 --> Form Validation Class Initialized
INFO - 2023-10-20 13:29:14 --> Controller Class Initialized
DEBUG - 2023-10-20 13:29:14 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-10-20 13:29:14 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-20 13:29:14 --> Model Class Initialized
INFO - 2023-10-20 13:29:14 --> Final output sent to browser
DEBUG - 2023-10-20 13:29:14 --> Total execution time: 0.0166
ERROR - 2023-10-20 13:29:24 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-20 13:29:24 --> Config Class Initialized
INFO - 2023-10-20 13:29:24 --> Hooks Class Initialized
DEBUG - 2023-10-20 13:29:24 --> UTF-8 Support Enabled
INFO - 2023-10-20 13:29:24 --> Utf8 Class Initialized
INFO - 2023-10-20 13:29:24 --> URI Class Initialized
INFO - 2023-10-20 13:29:24 --> Router Class Initialized
INFO - 2023-10-20 13:29:24 --> Output Class Initialized
INFO - 2023-10-20 13:29:24 --> Security Class Initialized
DEBUG - 2023-10-20 13:29:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-20 13:29:24 --> Input Class Initialized
INFO - 2023-10-20 13:29:24 --> Language Class Initialized
INFO - 2023-10-20 13:29:24 --> Loader Class Initialized
INFO - 2023-10-20 13:29:24 --> Helper loaded: url_helper
INFO - 2023-10-20 13:29:24 --> Helper loaded: file_helper
INFO - 2023-10-20 13:29:24 --> Helper loaded: html_helper
INFO - 2023-10-20 13:29:24 --> Helper loaded: text_helper
INFO - 2023-10-20 13:29:24 --> Helper loaded: form_helper
INFO - 2023-10-20 13:29:24 --> Helper loaded: lang_helper
INFO - 2023-10-20 13:29:24 --> Helper loaded: security_helper
INFO - 2023-10-20 13:29:24 --> Helper loaded: cookie_helper
INFO - 2023-10-20 13:29:24 --> Database Driver Class Initialized
INFO - 2023-10-20 13:29:24 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-20 13:29:24 --> Parser Class Initialized
INFO - 2023-10-20 13:29:24 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-20 13:29:24 --> Pagination Class Initialized
INFO - 2023-10-20 13:29:24 --> Form Validation Class Initialized
INFO - 2023-10-20 13:29:24 --> Controller Class Initialized
INFO - 2023-10-20 13:29:24 --> Model Class Initialized
DEBUG - 2023-10-20 13:29:24 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-10-20 13:29:24 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-20 13:29:24 --> Model Class Initialized
DEBUG - 2023-10-20 13:29:24 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-20 13:29:24 --> Model Class Initialized
INFO - 2023-10-20 13:29:24 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice.php
DEBUG - 2023-10-20 13:29:24 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-10-20 13:29:24 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-10-20 13:29:24 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-10-20 13:29:24 --> Model Class Initialized
INFO - 2023-10-20 13:29:24 --> Model Class Initialized
INFO - 2023-10-20 13:29:24 --> Model Class Initialized
INFO - 2023-10-20 13:29:24 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-10-20 13:29:24 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-10-20 13:29:24 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-10-20 13:29:24 --> Final output sent to browser
DEBUG - 2023-10-20 13:29:24 --> Total execution time: 0.2186
ERROR - 2023-10-20 13:29:41 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-20 13:29:41 --> Config Class Initialized
INFO - 2023-10-20 13:29:41 --> Hooks Class Initialized
DEBUG - 2023-10-20 13:29:41 --> UTF-8 Support Enabled
INFO - 2023-10-20 13:29:41 --> Utf8 Class Initialized
INFO - 2023-10-20 13:29:41 --> URI Class Initialized
INFO - 2023-10-20 13:29:41 --> Router Class Initialized
INFO - 2023-10-20 13:29:41 --> Output Class Initialized
INFO - 2023-10-20 13:29:41 --> Security Class Initialized
DEBUG - 2023-10-20 13:29:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-20 13:29:41 --> Input Class Initialized
INFO - 2023-10-20 13:29:41 --> Language Class Initialized
INFO - 2023-10-20 13:29:41 --> Loader Class Initialized
INFO - 2023-10-20 13:29:41 --> Helper loaded: url_helper
INFO - 2023-10-20 13:29:41 --> Helper loaded: file_helper
INFO - 2023-10-20 13:29:41 --> Helper loaded: html_helper
INFO - 2023-10-20 13:29:41 --> Helper loaded: text_helper
INFO - 2023-10-20 13:29:41 --> Helper loaded: form_helper
INFO - 2023-10-20 13:29:41 --> Helper loaded: lang_helper
INFO - 2023-10-20 13:29:41 --> Helper loaded: security_helper
INFO - 2023-10-20 13:29:41 --> Helper loaded: cookie_helper
INFO - 2023-10-20 13:29:41 --> Database Driver Class Initialized
INFO - 2023-10-20 13:29:41 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-20 13:29:41 --> Parser Class Initialized
INFO - 2023-10-20 13:29:41 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-20 13:29:41 --> Pagination Class Initialized
INFO - 2023-10-20 13:29:41 --> Form Validation Class Initialized
INFO - 2023-10-20 13:29:41 --> Controller Class Initialized
INFO - 2023-10-20 13:29:41 --> Model Class Initialized
DEBUG - 2023-10-20 13:29:41 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-10-20 13:29:41 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-20 13:29:41 --> Model Class Initialized
DEBUG - 2023-10-20 13:29:41 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-20 13:29:41 --> Model Class Initialized
INFO - 2023-10-20 13:29:41 --> Final output sent to browser
DEBUG - 2023-10-20 13:29:41 --> Total execution time: 0.0640
ERROR - 2023-10-20 13:35:36 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-20 13:35:36 --> Config Class Initialized
INFO - 2023-10-20 13:35:36 --> Hooks Class Initialized
DEBUG - 2023-10-20 13:35:36 --> UTF-8 Support Enabled
INFO - 2023-10-20 13:35:36 --> Utf8 Class Initialized
INFO - 2023-10-20 13:35:36 --> URI Class Initialized
INFO - 2023-10-20 13:35:36 --> Router Class Initialized
INFO - 2023-10-20 13:35:36 --> Output Class Initialized
INFO - 2023-10-20 13:35:36 --> Security Class Initialized
DEBUG - 2023-10-20 13:35:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-20 13:35:36 --> Input Class Initialized
INFO - 2023-10-20 13:35:36 --> Language Class Initialized
INFO - 2023-10-20 13:35:36 --> Loader Class Initialized
INFO - 2023-10-20 13:35:36 --> Helper loaded: url_helper
INFO - 2023-10-20 13:35:36 --> Helper loaded: file_helper
INFO - 2023-10-20 13:35:36 --> Helper loaded: html_helper
INFO - 2023-10-20 13:35:36 --> Helper loaded: text_helper
INFO - 2023-10-20 13:35:36 --> Helper loaded: form_helper
INFO - 2023-10-20 13:35:36 --> Helper loaded: lang_helper
INFO - 2023-10-20 13:35:36 --> Helper loaded: security_helper
INFO - 2023-10-20 13:35:36 --> Helper loaded: cookie_helper
INFO - 2023-10-20 13:35:36 --> Database Driver Class Initialized
INFO - 2023-10-20 13:35:36 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-20 13:35:36 --> Parser Class Initialized
INFO - 2023-10-20 13:35:36 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-20 13:35:36 --> Pagination Class Initialized
INFO - 2023-10-20 13:35:36 --> Form Validation Class Initialized
INFO - 2023-10-20 13:35:36 --> Controller Class Initialized
INFO - 2023-10-20 13:35:36 --> Model Class Initialized
DEBUG - 2023-10-20 13:35:36 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-10-20 13:35:37 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-20 13:35:37 --> Model Class Initialized
DEBUG - 2023-10-20 13:35:37 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-20 13:35:37 --> Model Class Initialized
INFO - 2023-10-20 13:35:37 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/add_invoice_form.php
DEBUG - 2023-10-20 13:35:37 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-10-20 13:35:37 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-10-20 13:35:37 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-10-20 13:35:37 --> Model Class Initialized
INFO - 2023-10-20 13:35:37 --> Model Class Initialized
INFO - 2023-10-20 13:35:37 --> Model Class Initialized
INFO - 2023-10-20 13:35:37 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-10-20 13:35:37 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-10-20 13:35:37 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-10-20 13:35:37 --> Final output sent to browser
DEBUG - 2023-10-20 13:35:37 --> Total execution time: 0.2421
ERROR - 2023-10-20 13:35:39 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-20 13:35:39 --> Config Class Initialized
INFO - 2023-10-20 13:35:39 --> Hooks Class Initialized
DEBUG - 2023-10-20 13:35:39 --> UTF-8 Support Enabled
INFO - 2023-10-20 13:35:39 --> Utf8 Class Initialized
INFO - 2023-10-20 13:35:39 --> URI Class Initialized
INFO - 2023-10-20 13:35:39 --> Router Class Initialized
INFO - 2023-10-20 13:35:39 --> Output Class Initialized
INFO - 2023-10-20 13:35:39 --> Security Class Initialized
DEBUG - 2023-10-20 13:35:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-20 13:35:39 --> Input Class Initialized
INFO - 2023-10-20 13:35:39 --> Language Class Initialized
INFO - 2023-10-20 13:35:39 --> Loader Class Initialized
INFO - 2023-10-20 13:35:39 --> Helper loaded: url_helper
INFO - 2023-10-20 13:35:39 --> Helper loaded: file_helper
INFO - 2023-10-20 13:35:39 --> Helper loaded: html_helper
INFO - 2023-10-20 13:35:39 --> Helper loaded: text_helper
INFO - 2023-10-20 13:35:39 --> Helper loaded: form_helper
INFO - 2023-10-20 13:35:39 --> Helper loaded: lang_helper
INFO - 2023-10-20 13:35:39 --> Helper loaded: security_helper
INFO - 2023-10-20 13:35:39 --> Helper loaded: cookie_helper
INFO - 2023-10-20 13:35:39 --> Database Driver Class Initialized
INFO - 2023-10-20 13:35:39 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-20 13:35:39 --> Parser Class Initialized
INFO - 2023-10-20 13:35:39 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-20 13:35:39 --> Pagination Class Initialized
INFO - 2023-10-20 13:35:39 --> Form Validation Class Initialized
INFO - 2023-10-20 13:35:39 --> Controller Class Initialized
INFO - 2023-10-20 13:35:39 --> Model Class Initialized
DEBUG - 2023-10-20 13:35:39 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-10-20 13:35:39 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-20 13:35:39 --> Model Class Initialized
DEBUG - 2023-10-20 13:35:39 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-20 13:35:39 --> Model Class Initialized
INFO - 2023-10-20 13:35:39 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice.php
DEBUG - 2023-10-20 13:35:39 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-10-20 13:35:39 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-10-20 13:35:39 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-10-20 13:35:39 --> Model Class Initialized
INFO - 2023-10-20 13:35:39 --> Model Class Initialized
INFO - 2023-10-20 13:35:39 --> Model Class Initialized
INFO - 2023-10-20 13:35:39 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-10-20 13:35:39 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-10-20 13:35:39 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-10-20 13:35:39 --> Final output sent to browser
DEBUG - 2023-10-20 13:35:39 --> Total execution time: 0.1983
ERROR - 2023-10-20 13:35:41 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-20 13:35:41 --> Config Class Initialized
INFO - 2023-10-20 13:35:41 --> Hooks Class Initialized
DEBUG - 2023-10-20 13:35:41 --> UTF-8 Support Enabled
INFO - 2023-10-20 13:35:41 --> Utf8 Class Initialized
INFO - 2023-10-20 13:35:41 --> URI Class Initialized
INFO - 2023-10-20 13:35:41 --> Router Class Initialized
INFO - 2023-10-20 13:35:41 --> Output Class Initialized
INFO - 2023-10-20 13:35:41 --> Security Class Initialized
DEBUG - 2023-10-20 13:35:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-20 13:35:41 --> Input Class Initialized
INFO - 2023-10-20 13:35:41 --> Language Class Initialized
INFO - 2023-10-20 13:35:41 --> Loader Class Initialized
INFO - 2023-10-20 13:35:41 --> Helper loaded: url_helper
INFO - 2023-10-20 13:35:41 --> Helper loaded: file_helper
INFO - 2023-10-20 13:35:41 --> Helper loaded: html_helper
INFO - 2023-10-20 13:35:41 --> Helper loaded: text_helper
INFO - 2023-10-20 13:35:41 --> Helper loaded: form_helper
INFO - 2023-10-20 13:35:41 --> Helper loaded: lang_helper
INFO - 2023-10-20 13:35:41 --> Helper loaded: security_helper
INFO - 2023-10-20 13:35:41 --> Helper loaded: cookie_helper
INFO - 2023-10-20 13:35:41 --> Database Driver Class Initialized
INFO - 2023-10-20 13:35:41 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-20 13:35:41 --> Parser Class Initialized
INFO - 2023-10-20 13:35:41 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-20 13:35:41 --> Pagination Class Initialized
INFO - 2023-10-20 13:35:41 --> Form Validation Class Initialized
INFO - 2023-10-20 13:35:41 --> Controller Class Initialized
INFO - 2023-10-20 13:35:41 --> Model Class Initialized
DEBUG - 2023-10-20 13:35:41 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-10-20 13:35:41 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-20 13:35:41 --> Model Class Initialized
DEBUG - 2023-10-20 13:35:41 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-20 13:35:41 --> Model Class Initialized
INFO - 2023-10-20 13:35:41 --> Final output sent to browser
DEBUG - 2023-10-20 13:35:41 --> Total execution time: 0.0541
ERROR - 2023-10-20 13:35:48 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-20 13:35:48 --> Config Class Initialized
INFO - 2023-10-20 13:35:48 --> Hooks Class Initialized
DEBUG - 2023-10-20 13:35:48 --> UTF-8 Support Enabled
INFO - 2023-10-20 13:35:48 --> Utf8 Class Initialized
INFO - 2023-10-20 13:35:48 --> URI Class Initialized
INFO - 2023-10-20 13:35:48 --> Router Class Initialized
INFO - 2023-10-20 13:35:48 --> Output Class Initialized
INFO - 2023-10-20 13:35:48 --> Security Class Initialized
DEBUG - 2023-10-20 13:35:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-20 13:35:48 --> Input Class Initialized
INFO - 2023-10-20 13:35:48 --> Language Class Initialized
INFO - 2023-10-20 13:35:48 --> Loader Class Initialized
INFO - 2023-10-20 13:35:48 --> Helper loaded: url_helper
INFO - 2023-10-20 13:35:48 --> Helper loaded: file_helper
INFO - 2023-10-20 13:35:48 --> Helper loaded: html_helper
INFO - 2023-10-20 13:35:48 --> Helper loaded: text_helper
INFO - 2023-10-20 13:35:48 --> Helper loaded: form_helper
INFO - 2023-10-20 13:35:48 --> Helper loaded: lang_helper
INFO - 2023-10-20 13:35:48 --> Helper loaded: security_helper
INFO - 2023-10-20 13:35:48 --> Helper loaded: cookie_helper
INFO - 2023-10-20 13:35:48 --> Database Driver Class Initialized
INFO - 2023-10-20 13:35:48 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-20 13:35:48 --> Parser Class Initialized
INFO - 2023-10-20 13:35:48 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-20 13:35:48 --> Pagination Class Initialized
INFO - 2023-10-20 13:35:48 --> Form Validation Class Initialized
INFO - 2023-10-20 13:35:48 --> Controller Class Initialized
INFO - 2023-10-20 13:35:48 --> Model Class Initialized
DEBUG - 2023-10-20 13:35:48 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-10-20 13:35:48 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-20 13:35:48 --> Model Class Initialized
DEBUG - 2023-10-20 13:35:48 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-20 13:35:48 --> Model Class Initialized
INFO - 2023-10-20 13:35:49 --> Final output sent to browser
DEBUG - 2023-10-20 13:35:49 --> Total execution time: 1.0114
ERROR - 2023-10-20 13:37:57 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-20 13:37:57 --> Config Class Initialized
INFO - 2023-10-20 13:37:57 --> Hooks Class Initialized
DEBUG - 2023-10-20 13:37:57 --> UTF-8 Support Enabled
INFO - 2023-10-20 13:37:57 --> Utf8 Class Initialized
INFO - 2023-10-20 13:37:57 --> URI Class Initialized
DEBUG - 2023-10-20 13:37:57 --> No URI present. Default controller set.
INFO - 2023-10-20 13:37:57 --> Router Class Initialized
INFO - 2023-10-20 13:37:57 --> Output Class Initialized
INFO - 2023-10-20 13:37:57 --> Security Class Initialized
DEBUG - 2023-10-20 13:37:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-20 13:37:57 --> Input Class Initialized
INFO - 2023-10-20 13:37:57 --> Language Class Initialized
INFO - 2023-10-20 13:37:57 --> Loader Class Initialized
INFO - 2023-10-20 13:37:57 --> Helper loaded: url_helper
INFO - 2023-10-20 13:37:57 --> Helper loaded: file_helper
INFO - 2023-10-20 13:37:57 --> Helper loaded: html_helper
INFO - 2023-10-20 13:37:57 --> Helper loaded: text_helper
INFO - 2023-10-20 13:37:57 --> Helper loaded: form_helper
INFO - 2023-10-20 13:37:57 --> Helper loaded: lang_helper
INFO - 2023-10-20 13:37:57 --> Helper loaded: security_helper
INFO - 2023-10-20 13:37:57 --> Helper loaded: cookie_helper
INFO - 2023-10-20 13:37:57 --> Database Driver Class Initialized
INFO - 2023-10-20 13:37:57 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-20 13:37:57 --> Parser Class Initialized
INFO - 2023-10-20 13:37:57 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-20 13:37:57 --> Pagination Class Initialized
INFO - 2023-10-20 13:37:57 --> Form Validation Class Initialized
INFO - 2023-10-20 13:37:57 --> Controller Class Initialized
INFO - 2023-10-20 13:37:57 --> Model Class Initialized
DEBUG - 2023-10-20 13:37:57 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-20 13:37:57 --> Model Class Initialized
DEBUG - 2023-10-20 13:37:57 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-20 13:37:57 --> Model Class Initialized
INFO - 2023-10-20 13:37:57 --> Model Class Initialized
INFO - 2023-10-20 13:37:57 --> Model Class Initialized
INFO - 2023-10-20 13:37:57 --> Model Class Initialized
DEBUG - 2023-10-20 13:37:57 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-10-20 13:37:57 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-20 13:37:57 --> Model Class Initialized
INFO - 2023-10-20 13:37:57 --> Model Class Initialized
INFO - 2023-10-20 13:37:57 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-10-20 13:37:57 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-10-20 13:37:57 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-10-20 13:37:57 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-10-20 13:37:57 --> Model Class Initialized
INFO - 2023-10-20 13:37:57 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-10-20 13:37:57 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-10-20 13:37:57 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-10-20 13:37:57 --> Final output sent to browser
DEBUG - 2023-10-20 13:37:57 --> Total execution time: 0.3803
ERROR - 2023-10-20 13:38:31 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-20 13:38:31 --> Config Class Initialized
INFO - 2023-10-20 13:38:31 --> Hooks Class Initialized
DEBUG - 2023-10-20 13:38:31 --> UTF-8 Support Enabled
INFO - 2023-10-20 13:38:31 --> Utf8 Class Initialized
INFO - 2023-10-20 13:38:31 --> URI Class Initialized
INFO - 2023-10-20 13:38:31 --> Router Class Initialized
INFO - 2023-10-20 13:38:31 --> Output Class Initialized
INFO - 2023-10-20 13:38:31 --> Security Class Initialized
DEBUG - 2023-10-20 13:38:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-20 13:38:31 --> Input Class Initialized
INFO - 2023-10-20 13:38:31 --> Language Class Initialized
INFO - 2023-10-20 13:38:31 --> Loader Class Initialized
INFO - 2023-10-20 13:38:31 --> Helper loaded: url_helper
INFO - 2023-10-20 13:38:31 --> Helper loaded: file_helper
INFO - 2023-10-20 13:38:31 --> Helper loaded: html_helper
INFO - 2023-10-20 13:38:31 --> Helper loaded: text_helper
INFO - 2023-10-20 13:38:31 --> Helper loaded: form_helper
INFO - 2023-10-20 13:38:31 --> Helper loaded: lang_helper
INFO - 2023-10-20 13:38:31 --> Helper loaded: security_helper
INFO - 2023-10-20 13:38:31 --> Helper loaded: cookie_helper
INFO - 2023-10-20 13:38:31 --> Database Driver Class Initialized
INFO - 2023-10-20 13:38:31 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-20 13:38:31 --> Parser Class Initialized
INFO - 2023-10-20 13:38:31 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-20 13:38:31 --> Pagination Class Initialized
INFO - 2023-10-20 13:38:31 --> Form Validation Class Initialized
INFO - 2023-10-20 13:38:31 --> Controller Class Initialized
DEBUG - 2023-10-20 13:38:31 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-10-20 13:38:31 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-20 13:38:31 --> Model Class Initialized
DEBUG - 2023-10-20 13:38:31 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-20 13:38:31 --> Model Class Initialized
DEBUG - 2023-10-20 13:38:31 --> Lcustomer class already loaded. Second attempt ignored.
INFO - 2023-10-20 13:38:31 --> Model Class Initialized
INFO - 2023-10-20 13:38:31 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/customer/customer.php
DEBUG - 2023-10-20 13:38:31 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-10-20 13:38:31 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-10-20 13:38:31 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-10-20 13:38:31 --> Model Class Initialized
INFO - 2023-10-20 13:38:31 --> Model Class Initialized
INFO - 2023-10-20 13:38:31 --> Model Class Initialized
INFO - 2023-10-20 13:38:31 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-10-20 13:38:31 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-10-20 13:38:31 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-10-20 13:38:31 --> Final output sent to browser
DEBUG - 2023-10-20 13:38:31 --> Total execution time: 0.2159
ERROR - 2023-10-20 13:38:32 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-20 13:38:32 --> Config Class Initialized
INFO - 2023-10-20 13:38:32 --> Hooks Class Initialized
DEBUG - 2023-10-20 13:38:32 --> UTF-8 Support Enabled
INFO - 2023-10-20 13:38:32 --> Utf8 Class Initialized
INFO - 2023-10-20 13:38:32 --> URI Class Initialized
INFO - 2023-10-20 13:38:32 --> Router Class Initialized
INFO - 2023-10-20 13:38:32 --> Output Class Initialized
INFO - 2023-10-20 13:38:32 --> Security Class Initialized
DEBUG - 2023-10-20 13:38:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-20 13:38:32 --> Input Class Initialized
INFO - 2023-10-20 13:38:32 --> Language Class Initialized
INFO - 2023-10-20 13:38:32 --> Loader Class Initialized
INFO - 2023-10-20 13:38:32 --> Helper loaded: url_helper
INFO - 2023-10-20 13:38:32 --> Helper loaded: file_helper
INFO - 2023-10-20 13:38:32 --> Helper loaded: html_helper
INFO - 2023-10-20 13:38:32 --> Helper loaded: text_helper
INFO - 2023-10-20 13:38:32 --> Helper loaded: form_helper
INFO - 2023-10-20 13:38:32 --> Helper loaded: lang_helper
INFO - 2023-10-20 13:38:32 --> Helper loaded: security_helper
INFO - 2023-10-20 13:38:32 --> Helper loaded: cookie_helper
INFO - 2023-10-20 13:38:32 --> Database Driver Class Initialized
INFO - 2023-10-20 13:38:32 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-20 13:38:32 --> Parser Class Initialized
INFO - 2023-10-20 13:38:32 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-20 13:38:32 --> Pagination Class Initialized
INFO - 2023-10-20 13:38:32 --> Form Validation Class Initialized
INFO - 2023-10-20 13:38:32 --> Controller Class Initialized
DEBUG - 2023-10-20 13:38:32 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-10-20 13:38:32 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-20 13:38:32 --> Model Class Initialized
DEBUG - 2023-10-20 13:38:32 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-20 13:38:32 --> Model Class Initialized
INFO - 2023-10-20 13:38:32 --> Final output sent to browser
DEBUG - 2023-10-20 13:38:32 --> Total execution time: 0.0349
ERROR - 2023-10-20 13:38:35 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-20 13:38:35 --> Config Class Initialized
INFO - 2023-10-20 13:38:35 --> Hooks Class Initialized
DEBUG - 2023-10-20 13:38:35 --> UTF-8 Support Enabled
INFO - 2023-10-20 13:38:35 --> Utf8 Class Initialized
INFO - 2023-10-20 13:38:35 --> URI Class Initialized
INFO - 2023-10-20 13:38:35 --> Router Class Initialized
INFO - 2023-10-20 13:38:35 --> Output Class Initialized
INFO - 2023-10-20 13:38:35 --> Security Class Initialized
DEBUG - 2023-10-20 13:38:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-20 13:38:35 --> Input Class Initialized
INFO - 2023-10-20 13:38:35 --> Language Class Initialized
INFO - 2023-10-20 13:38:35 --> Loader Class Initialized
INFO - 2023-10-20 13:38:35 --> Helper loaded: url_helper
INFO - 2023-10-20 13:38:35 --> Helper loaded: file_helper
INFO - 2023-10-20 13:38:35 --> Helper loaded: html_helper
INFO - 2023-10-20 13:38:35 --> Helper loaded: text_helper
INFO - 2023-10-20 13:38:35 --> Helper loaded: form_helper
INFO - 2023-10-20 13:38:35 --> Helper loaded: lang_helper
INFO - 2023-10-20 13:38:35 --> Helper loaded: security_helper
INFO - 2023-10-20 13:38:35 --> Helper loaded: cookie_helper
INFO - 2023-10-20 13:38:35 --> Database Driver Class Initialized
INFO - 2023-10-20 13:38:35 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-20 13:38:35 --> Parser Class Initialized
INFO - 2023-10-20 13:38:35 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-20 13:38:35 --> Pagination Class Initialized
INFO - 2023-10-20 13:38:35 --> Form Validation Class Initialized
INFO - 2023-10-20 13:38:35 --> Controller Class Initialized
DEBUG - 2023-10-20 13:38:35 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-10-20 13:38:35 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-20 13:38:35 --> Model Class Initialized
DEBUG - 2023-10-20 13:38:35 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-20 13:38:35 --> Model Class Initialized
INFO - 2023-10-20 13:38:35 --> Final output sent to browser
DEBUG - 2023-10-20 13:38:35 --> Total execution time: 0.1905
ERROR - 2023-10-20 13:38:43 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-20 13:38:43 --> Config Class Initialized
INFO - 2023-10-20 13:38:43 --> Hooks Class Initialized
DEBUG - 2023-10-20 13:38:43 --> UTF-8 Support Enabled
INFO - 2023-10-20 13:38:43 --> Utf8 Class Initialized
INFO - 2023-10-20 13:38:43 --> URI Class Initialized
DEBUG - 2023-10-20 13:38:43 --> No URI present. Default controller set.
INFO - 2023-10-20 13:38:43 --> Router Class Initialized
INFO - 2023-10-20 13:38:43 --> Output Class Initialized
INFO - 2023-10-20 13:38:43 --> Security Class Initialized
DEBUG - 2023-10-20 13:38:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-20 13:38:43 --> Input Class Initialized
INFO - 2023-10-20 13:38:43 --> Language Class Initialized
INFO - 2023-10-20 13:38:43 --> Loader Class Initialized
INFO - 2023-10-20 13:38:43 --> Helper loaded: url_helper
INFO - 2023-10-20 13:38:43 --> Helper loaded: file_helper
INFO - 2023-10-20 13:38:43 --> Helper loaded: html_helper
INFO - 2023-10-20 13:38:43 --> Helper loaded: text_helper
INFO - 2023-10-20 13:38:43 --> Helper loaded: form_helper
INFO - 2023-10-20 13:38:43 --> Helper loaded: lang_helper
INFO - 2023-10-20 13:38:43 --> Helper loaded: security_helper
INFO - 2023-10-20 13:38:43 --> Helper loaded: cookie_helper
INFO - 2023-10-20 13:38:43 --> Database Driver Class Initialized
INFO - 2023-10-20 13:38:43 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-20 13:38:43 --> Parser Class Initialized
INFO - 2023-10-20 13:38:43 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-20 13:38:43 --> Pagination Class Initialized
INFO - 2023-10-20 13:38:43 --> Form Validation Class Initialized
INFO - 2023-10-20 13:38:43 --> Controller Class Initialized
INFO - 2023-10-20 13:38:43 --> Model Class Initialized
DEBUG - 2023-10-20 13:38:43 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-20 13:38:43 --> Model Class Initialized
DEBUG - 2023-10-20 13:38:43 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-20 13:38:43 --> Model Class Initialized
INFO - 2023-10-20 13:38:43 --> Model Class Initialized
INFO - 2023-10-20 13:38:43 --> Model Class Initialized
INFO - 2023-10-20 13:38:43 --> Model Class Initialized
DEBUG - 2023-10-20 13:38:43 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-10-20 13:38:43 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-20 13:38:43 --> Model Class Initialized
INFO - 2023-10-20 13:38:43 --> Model Class Initialized
INFO - 2023-10-20 13:38:43 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-10-20 13:38:43 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-10-20 13:38:43 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-10-20 13:38:43 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-10-20 13:38:43 --> Model Class Initialized
ERROR - 2023-10-20 13:38:43 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-20 13:38:43 --> Config Class Initialized
INFO - 2023-10-20 13:38:43 --> Hooks Class Initialized
DEBUG - 2023-10-20 13:38:43 --> UTF-8 Support Enabled
INFO - 2023-10-20 13:38:43 --> Utf8 Class Initialized
INFO - 2023-10-20 13:38:43 --> URI Class Initialized
DEBUG - 2023-10-20 13:38:43 --> No URI present. Default controller set.
INFO - 2023-10-20 13:38:43 --> Router Class Initialized
INFO - 2023-10-20 13:38:43 --> Output Class Initialized
INFO - 2023-10-20 13:38:43 --> Security Class Initialized
DEBUG - 2023-10-20 13:38:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-20 13:38:43 --> Input Class Initialized
INFO - 2023-10-20 13:38:43 --> Language Class Initialized
INFO - 2023-10-20 13:38:43 --> Loader Class Initialized
INFO - 2023-10-20 13:38:43 --> Helper loaded: url_helper
INFO - 2023-10-20 13:38:43 --> Helper loaded: file_helper
INFO - 2023-10-20 13:38:43 --> Helper loaded: html_helper
INFO - 2023-10-20 13:38:43 --> Helper loaded: text_helper
INFO - 2023-10-20 13:38:43 --> Helper loaded: form_helper
INFO - 2023-10-20 13:38:43 --> Helper loaded: lang_helper
INFO - 2023-10-20 13:38:43 --> Helper loaded: security_helper
INFO - 2023-10-20 13:38:43 --> Helper loaded: cookie_helper
INFO - 2023-10-20 13:38:43 --> Database Driver Class Initialized
INFO - 2023-10-20 13:38:43 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-10-20 13:38:43 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-10-20 13:38:43 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-10-20 13:38:43 --> Final output sent to browser
DEBUG - 2023-10-20 13:38:43 --> Total execution time: 0.3948
INFO - 2023-10-20 13:38:43 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-20 13:38:43 --> Parser Class Initialized
INFO - 2023-10-20 13:38:43 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-20 13:38:43 --> Pagination Class Initialized
INFO - 2023-10-20 13:38:43 --> Form Validation Class Initialized
INFO - 2023-10-20 13:38:43 --> Controller Class Initialized
INFO - 2023-10-20 13:38:43 --> Model Class Initialized
DEBUG - 2023-10-20 13:38:43 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-20 13:38:43 --> Model Class Initialized
DEBUG - 2023-10-20 13:38:43 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-20 13:38:43 --> Model Class Initialized
INFO - 2023-10-20 13:38:43 --> Model Class Initialized
INFO - 2023-10-20 13:38:43 --> Model Class Initialized
INFO - 2023-10-20 13:38:43 --> Model Class Initialized
DEBUG - 2023-10-20 13:38:43 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-10-20 13:38:43 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-20 13:38:43 --> Model Class Initialized
INFO - 2023-10-20 13:38:43 --> Model Class Initialized
INFO - 2023-10-20 13:38:43 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-10-20 13:38:43 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-10-20 13:38:43 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-10-20 13:38:43 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-10-20 13:38:43 --> Model Class Initialized
INFO - 2023-10-20 13:38:44 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-10-20 13:38:44 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-10-20 13:38:44 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-10-20 13:38:44 --> Final output sent to browser
DEBUG - 2023-10-20 13:38:44 --> Total execution time: 0.4264
ERROR - 2023-10-20 13:38:55 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-20 13:38:55 --> Config Class Initialized
INFO - 2023-10-20 13:38:55 --> Hooks Class Initialized
DEBUG - 2023-10-20 13:38:55 --> UTF-8 Support Enabled
INFO - 2023-10-20 13:38:55 --> Utf8 Class Initialized
INFO - 2023-10-20 13:38:55 --> URI Class Initialized
INFO - 2023-10-20 13:38:55 --> Router Class Initialized
INFO - 2023-10-20 13:38:55 --> Output Class Initialized
INFO - 2023-10-20 13:38:55 --> Security Class Initialized
DEBUG - 2023-10-20 13:38:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-20 13:38:55 --> Input Class Initialized
INFO - 2023-10-20 13:38:55 --> Language Class Initialized
INFO - 2023-10-20 13:38:55 --> Loader Class Initialized
INFO - 2023-10-20 13:38:55 --> Helper loaded: url_helper
INFO - 2023-10-20 13:38:55 --> Helper loaded: file_helper
INFO - 2023-10-20 13:38:55 --> Helper loaded: html_helper
INFO - 2023-10-20 13:38:55 --> Helper loaded: text_helper
INFO - 2023-10-20 13:38:55 --> Helper loaded: form_helper
INFO - 2023-10-20 13:38:55 --> Helper loaded: lang_helper
INFO - 2023-10-20 13:38:55 --> Helper loaded: security_helper
INFO - 2023-10-20 13:38:55 --> Helper loaded: cookie_helper
INFO - 2023-10-20 13:38:55 --> Database Driver Class Initialized
INFO - 2023-10-20 13:38:55 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-20 13:38:55 --> Parser Class Initialized
INFO - 2023-10-20 13:38:55 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-20 13:38:55 --> Pagination Class Initialized
INFO - 2023-10-20 13:38:55 --> Form Validation Class Initialized
INFO - 2023-10-20 13:38:55 --> Controller Class Initialized
DEBUG - 2023-10-20 13:38:55 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-10-20 13:38:55 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-20 13:38:55 --> Model Class Initialized
DEBUG - 2023-10-20 13:38:55 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-20 13:38:55 --> Model Class Initialized
DEBUG - 2023-10-20 13:38:55 --> Lcustomer class already loaded. Second attempt ignored.
INFO - 2023-10-20 13:38:55 --> Model Class Initialized
INFO - 2023-10-20 13:38:55 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/customer/customer.php
DEBUG - 2023-10-20 13:38:55 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-10-20 13:38:55 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-10-20 13:38:55 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-10-20 13:38:55 --> Model Class Initialized
INFO - 2023-10-20 13:38:55 --> Model Class Initialized
INFO - 2023-10-20 13:38:55 --> Model Class Initialized
INFO - 2023-10-20 13:38:55 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-10-20 13:38:55 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-10-20 13:38:55 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-10-20 13:38:55 --> Final output sent to browser
DEBUG - 2023-10-20 13:38:55 --> Total execution time: 0.2049
ERROR - 2023-10-20 13:38:57 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-20 13:38:57 --> Config Class Initialized
INFO - 2023-10-20 13:38:57 --> Hooks Class Initialized
DEBUG - 2023-10-20 13:38:57 --> UTF-8 Support Enabled
INFO - 2023-10-20 13:38:57 --> Utf8 Class Initialized
INFO - 2023-10-20 13:38:57 --> URI Class Initialized
INFO - 2023-10-20 13:38:57 --> Router Class Initialized
INFO - 2023-10-20 13:38:57 --> Output Class Initialized
INFO - 2023-10-20 13:38:57 --> Security Class Initialized
DEBUG - 2023-10-20 13:38:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-20 13:38:57 --> Input Class Initialized
INFO - 2023-10-20 13:38:57 --> Language Class Initialized
INFO - 2023-10-20 13:38:57 --> Loader Class Initialized
INFO - 2023-10-20 13:38:57 --> Helper loaded: url_helper
INFO - 2023-10-20 13:38:57 --> Helper loaded: file_helper
INFO - 2023-10-20 13:38:57 --> Helper loaded: html_helper
INFO - 2023-10-20 13:38:57 --> Helper loaded: text_helper
INFO - 2023-10-20 13:38:57 --> Helper loaded: form_helper
INFO - 2023-10-20 13:38:57 --> Helper loaded: lang_helper
INFO - 2023-10-20 13:38:57 --> Helper loaded: security_helper
INFO - 2023-10-20 13:38:57 --> Helper loaded: cookie_helper
INFO - 2023-10-20 13:38:57 --> Database Driver Class Initialized
INFO - 2023-10-20 13:38:57 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-20 13:38:57 --> Parser Class Initialized
INFO - 2023-10-20 13:38:57 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-20 13:38:57 --> Pagination Class Initialized
INFO - 2023-10-20 13:38:57 --> Form Validation Class Initialized
INFO - 2023-10-20 13:38:57 --> Controller Class Initialized
DEBUG - 2023-10-20 13:38:57 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-10-20 13:38:57 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-20 13:38:57 --> Model Class Initialized
DEBUG - 2023-10-20 13:38:57 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-20 13:38:57 --> Model Class Initialized
INFO - 2023-10-20 13:38:57 --> Final output sent to browser
DEBUG - 2023-10-20 13:38:57 --> Total execution time: 0.0341
ERROR - 2023-10-20 13:39:02 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-20 13:39:02 --> Config Class Initialized
INFO - 2023-10-20 13:39:02 --> Hooks Class Initialized
DEBUG - 2023-10-20 13:39:02 --> UTF-8 Support Enabled
INFO - 2023-10-20 13:39:02 --> Utf8 Class Initialized
INFO - 2023-10-20 13:39:02 --> URI Class Initialized
INFO - 2023-10-20 13:39:02 --> Router Class Initialized
INFO - 2023-10-20 13:39:02 --> Output Class Initialized
INFO - 2023-10-20 13:39:02 --> Security Class Initialized
DEBUG - 2023-10-20 13:39:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-20 13:39:02 --> Input Class Initialized
INFO - 2023-10-20 13:39:02 --> Language Class Initialized
INFO - 2023-10-20 13:39:02 --> Loader Class Initialized
INFO - 2023-10-20 13:39:02 --> Helper loaded: url_helper
INFO - 2023-10-20 13:39:02 --> Helper loaded: file_helper
INFO - 2023-10-20 13:39:02 --> Helper loaded: html_helper
INFO - 2023-10-20 13:39:02 --> Helper loaded: text_helper
INFO - 2023-10-20 13:39:02 --> Helper loaded: form_helper
INFO - 2023-10-20 13:39:02 --> Helper loaded: lang_helper
INFO - 2023-10-20 13:39:02 --> Helper loaded: security_helper
INFO - 2023-10-20 13:39:02 --> Helper loaded: cookie_helper
INFO - 2023-10-20 13:39:02 --> Database Driver Class Initialized
INFO - 2023-10-20 13:39:02 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-20 13:39:02 --> Parser Class Initialized
INFO - 2023-10-20 13:39:02 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-20 13:39:02 --> Pagination Class Initialized
INFO - 2023-10-20 13:39:02 --> Form Validation Class Initialized
INFO - 2023-10-20 13:39:02 --> Controller Class Initialized
INFO - 2023-10-20 13:39:02 --> Model Class Initialized
DEBUG - 2023-10-20 13:39:02 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-10-20 13:39:02 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-20 13:39:02 --> Model Class Initialized
DEBUG - 2023-10-20 13:39:02 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-20 13:39:02 --> Model Class Initialized
INFO - 2023-10-20 13:39:02 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice.php
DEBUG - 2023-10-20 13:39:02 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-10-20 13:39:02 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-10-20 13:39:02 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-10-20 13:39:02 --> Model Class Initialized
INFO - 2023-10-20 13:39:02 --> Model Class Initialized
INFO - 2023-10-20 13:39:02 --> Model Class Initialized
INFO - 2023-10-20 13:39:02 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-10-20 13:39:02 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-10-20 13:39:02 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-10-20 13:39:02 --> Final output sent to browser
DEBUG - 2023-10-20 13:39:02 --> Total execution time: 0.1972
ERROR - 2023-10-20 13:39:06 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-20 13:39:06 --> Config Class Initialized
INFO - 2023-10-20 13:39:06 --> Hooks Class Initialized
DEBUG - 2023-10-20 13:39:06 --> UTF-8 Support Enabled
INFO - 2023-10-20 13:39:06 --> Utf8 Class Initialized
INFO - 2023-10-20 13:39:06 --> URI Class Initialized
INFO - 2023-10-20 13:39:06 --> Router Class Initialized
INFO - 2023-10-20 13:39:06 --> Output Class Initialized
INFO - 2023-10-20 13:39:06 --> Security Class Initialized
DEBUG - 2023-10-20 13:39:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-20 13:39:06 --> Input Class Initialized
INFO - 2023-10-20 13:39:06 --> Language Class Initialized
INFO - 2023-10-20 13:39:06 --> Loader Class Initialized
INFO - 2023-10-20 13:39:06 --> Helper loaded: url_helper
INFO - 2023-10-20 13:39:06 --> Helper loaded: file_helper
INFO - 2023-10-20 13:39:06 --> Helper loaded: html_helper
INFO - 2023-10-20 13:39:06 --> Helper loaded: text_helper
INFO - 2023-10-20 13:39:06 --> Helper loaded: form_helper
INFO - 2023-10-20 13:39:06 --> Helper loaded: lang_helper
INFO - 2023-10-20 13:39:06 --> Helper loaded: security_helper
INFO - 2023-10-20 13:39:06 --> Helper loaded: cookie_helper
INFO - 2023-10-20 13:39:06 --> Database Driver Class Initialized
INFO - 2023-10-20 13:39:06 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-20 13:39:06 --> Parser Class Initialized
INFO - 2023-10-20 13:39:06 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-20 13:39:06 --> Pagination Class Initialized
INFO - 2023-10-20 13:39:06 --> Form Validation Class Initialized
INFO - 2023-10-20 13:39:06 --> Controller Class Initialized
INFO - 2023-10-20 13:39:06 --> Model Class Initialized
DEBUG - 2023-10-20 13:39:06 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-10-20 13:39:06 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-20 13:39:06 --> Model Class Initialized
DEBUG - 2023-10-20 13:39:06 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-20 13:39:06 --> Model Class Initialized
INFO - 2023-10-20 13:39:06 --> Final output sent to browser
DEBUG - 2023-10-20 13:39:06 --> Total execution time: 0.0569
ERROR - 2023-10-20 13:40:29 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-20 13:40:29 --> Config Class Initialized
INFO - 2023-10-20 13:40:29 --> Hooks Class Initialized
DEBUG - 2023-10-20 13:40:29 --> UTF-8 Support Enabled
INFO - 2023-10-20 13:40:29 --> Utf8 Class Initialized
INFO - 2023-10-20 13:40:29 --> URI Class Initialized
INFO - 2023-10-20 13:40:29 --> Router Class Initialized
INFO - 2023-10-20 13:40:29 --> Output Class Initialized
INFO - 2023-10-20 13:40:29 --> Security Class Initialized
DEBUG - 2023-10-20 13:40:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-20 13:40:29 --> Input Class Initialized
INFO - 2023-10-20 13:40:29 --> Language Class Initialized
INFO - 2023-10-20 13:40:29 --> Loader Class Initialized
INFO - 2023-10-20 13:40:29 --> Helper loaded: url_helper
INFO - 2023-10-20 13:40:29 --> Helper loaded: file_helper
INFO - 2023-10-20 13:40:29 --> Helper loaded: html_helper
INFO - 2023-10-20 13:40:29 --> Helper loaded: text_helper
INFO - 2023-10-20 13:40:29 --> Helper loaded: form_helper
INFO - 2023-10-20 13:40:29 --> Helper loaded: lang_helper
INFO - 2023-10-20 13:40:29 --> Helper loaded: security_helper
INFO - 2023-10-20 13:40:29 --> Helper loaded: cookie_helper
INFO - 2023-10-20 13:40:29 --> Database Driver Class Initialized
INFO - 2023-10-20 13:40:29 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-20 13:40:29 --> Parser Class Initialized
INFO - 2023-10-20 13:40:29 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-20 13:40:29 --> Pagination Class Initialized
INFO - 2023-10-20 13:40:29 --> Form Validation Class Initialized
INFO - 2023-10-20 13:40:29 --> Controller Class Initialized
INFO - 2023-10-20 13:40:29 --> Model Class Initialized
DEBUG - 2023-10-20 13:40:29 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-10-20 13:40:29 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-20 13:40:29 --> Model Class Initialized
DEBUG - 2023-10-20 13:40:29 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-20 13:40:29 --> Model Class Initialized
INFO - 2023-10-20 13:40:29 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice.php
DEBUG - 2023-10-20 13:40:29 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-10-20 13:40:29 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-10-20 13:40:29 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-10-20 13:40:29 --> Model Class Initialized
INFO - 2023-10-20 13:40:29 --> Model Class Initialized
INFO - 2023-10-20 13:40:29 --> Model Class Initialized
INFO - 2023-10-20 13:40:29 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-10-20 13:40:29 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-10-20 13:40:29 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-10-20 13:40:29 --> Final output sent to browser
DEBUG - 2023-10-20 13:40:29 --> Total execution time: 0.2130
ERROR - 2023-10-20 13:40:31 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-20 13:40:31 --> Config Class Initialized
INFO - 2023-10-20 13:40:31 --> Hooks Class Initialized
DEBUG - 2023-10-20 13:40:31 --> UTF-8 Support Enabled
INFO - 2023-10-20 13:40:31 --> Utf8 Class Initialized
INFO - 2023-10-20 13:40:31 --> URI Class Initialized
INFO - 2023-10-20 13:40:31 --> Router Class Initialized
INFO - 2023-10-20 13:40:31 --> Output Class Initialized
INFO - 2023-10-20 13:40:31 --> Security Class Initialized
DEBUG - 2023-10-20 13:40:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-20 13:40:31 --> Input Class Initialized
INFO - 2023-10-20 13:40:31 --> Language Class Initialized
INFO - 2023-10-20 13:40:31 --> Loader Class Initialized
INFO - 2023-10-20 13:40:31 --> Helper loaded: url_helper
INFO - 2023-10-20 13:40:31 --> Helper loaded: file_helper
INFO - 2023-10-20 13:40:31 --> Helper loaded: html_helper
INFO - 2023-10-20 13:40:31 --> Helper loaded: text_helper
INFO - 2023-10-20 13:40:31 --> Helper loaded: form_helper
INFO - 2023-10-20 13:40:31 --> Helper loaded: lang_helper
INFO - 2023-10-20 13:40:31 --> Helper loaded: security_helper
INFO - 2023-10-20 13:40:31 --> Helper loaded: cookie_helper
INFO - 2023-10-20 13:40:31 --> Database Driver Class Initialized
INFO - 2023-10-20 13:40:31 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-20 13:40:31 --> Parser Class Initialized
INFO - 2023-10-20 13:40:31 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-20 13:40:31 --> Pagination Class Initialized
INFO - 2023-10-20 13:40:31 --> Form Validation Class Initialized
INFO - 2023-10-20 13:40:31 --> Controller Class Initialized
INFO - 2023-10-20 13:40:31 --> Model Class Initialized
DEBUG - 2023-10-20 13:40:31 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-10-20 13:40:31 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-20 13:40:31 --> Model Class Initialized
DEBUG - 2023-10-20 13:40:31 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-20 13:40:31 --> Model Class Initialized
INFO - 2023-10-20 13:40:31 --> Final output sent to browser
DEBUG - 2023-10-20 13:40:31 --> Total execution time: 0.0608
ERROR - 2023-10-20 13:44:49 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-20 13:44:49 --> Config Class Initialized
INFO - 2023-10-20 13:44:49 --> Hooks Class Initialized
DEBUG - 2023-10-20 13:44:49 --> UTF-8 Support Enabled
INFO - 2023-10-20 13:44:49 --> Utf8 Class Initialized
INFO - 2023-10-20 13:44:49 --> URI Class Initialized
INFO - 2023-10-20 13:44:49 --> Router Class Initialized
INFO - 2023-10-20 13:44:49 --> Output Class Initialized
INFO - 2023-10-20 13:44:49 --> Security Class Initialized
DEBUG - 2023-10-20 13:44:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-20 13:44:49 --> Input Class Initialized
INFO - 2023-10-20 13:44:49 --> Language Class Initialized
INFO - 2023-10-20 13:44:49 --> Loader Class Initialized
INFO - 2023-10-20 13:44:49 --> Helper loaded: url_helper
INFO - 2023-10-20 13:44:49 --> Helper loaded: file_helper
INFO - 2023-10-20 13:44:49 --> Helper loaded: html_helper
INFO - 2023-10-20 13:44:49 --> Helper loaded: text_helper
INFO - 2023-10-20 13:44:49 --> Helper loaded: form_helper
INFO - 2023-10-20 13:44:49 --> Helper loaded: lang_helper
INFO - 2023-10-20 13:44:49 --> Helper loaded: security_helper
INFO - 2023-10-20 13:44:49 --> Helper loaded: cookie_helper
INFO - 2023-10-20 13:44:49 --> Database Driver Class Initialized
INFO - 2023-10-20 13:44:49 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-20 13:44:49 --> Parser Class Initialized
INFO - 2023-10-20 13:44:49 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-20 13:44:49 --> Pagination Class Initialized
INFO - 2023-10-20 13:44:49 --> Form Validation Class Initialized
INFO - 2023-10-20 13:44:49 --> Controller Class Initialized
INFO - 2023-10-20 13:44:49 --> Model Class Initialized
DEBUG - 2023-10-20 13:44:49 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-10-20 13:44:49 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-20 13:44:49 --> Model Class Initialized
DEBUG - 2023-10-20 13:44:49 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-20 13:44:49 --> Model Class Initialized
INFO - 2023-10-20 13:44:49 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice.php
DEBUG - 2023-10-20 13:44:49 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-10-20 13:44:49 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-10-20 13:44:49 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-10-20 13:44:49 --> Model Class Initialized
INFO - 2023-10-20 13:44:49 --> Model Class Initialized
INFO - 2023-10-20 13:44:49 --> Model Class Initialized
INFO - 2023-10-20 13:44:49 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-10-20 13:44:49 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-10-20 13:44:49 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-10-20 13:44:49 --> Final output sent to browser
DEBUG - 2023-10-20 13:44:49 --> Total execution time: 0.2190
ERROR - 2023-10-20 13:44:50 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-20 13:44:50 --> Config Class Initialized
INFO - 2023-10-20 13:44:50 --> Hooks Class Initialized
DEBUG - 2023-10-20 13:44:50 --> UTF-8 Support Enabled
INFO - 2023-10-20 13:44:50 --> Utf8 Class Initialized
INFO - 2023-10-20 13:44:50 --> URI Class Initialized
INFO - 2023-10-20 13:44:50 --> Router Class Initialized
INFO - 2023-10-20 13:44:50 --> Output Class Initialized
INFO - 2023-10-20 13:44:50 --> Security Class Initialized
DEBUG - 2023-10-20 13:44:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-20 13:44:50 --> Input Class Initialized
INFO - 2023-10-20 13:44:50 --> Language Class Initialized
INFO - 2023-10-20 13:44:50 --> Loader Class Initialized
INFO - 2023-10-20 13:44:50 --> Helper loaded: url_helper
INFO - 2023-10-20 13:44:50 --> Helper loaded: file_helper
INFO - 2023-10-20 13:44:50 --> Helper loaded: html_helper
INFO - 2023-10-20 13:44:50 --> Helper loaded: text_helper
INFO - 2023-10-20 13:44:50 --> Helper loaded: form_helper
INFO - 2023-10-20 13:44:50 --> Helper loaded: lang_helper
INFO - 2023-10-20 13:44:50 --> Helper loaded: security_helper
INFO - 2023-10-20 13:44:50 --> Helper loaded: cookie_helper
INFO - 2023-10-20 13:44:50 --> Database Driver Class Initialized
INFO - 2023-10-20 13:44:50 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-20 13:44:50 --> Parser Class Initialized
INFO - 2023-10-20 13:44:50 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-20 13:44:50 --> Pagination Class Initialized
INFO - 2023-10-20 13:44:50 --> Form Validation Class Initialized
INFO - 2023-10-20 13:44:50 --> Controller Class Initialized
INFO - 2023-10-20 13:44:50 --> Model Class Initialized
DEBUG - 2023-10-20 13:44:50 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-10-20 13:44:50 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-20 13:44:50 --> Model Class Initialized
DEBUG - 2023-10-20 13:44:50 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-20 13:44:50 --> Model Class Initialized
INFO - 2023-10-20 13:44:50 --> Final output sent to browser
DEBUG - 2023-10-20 13:44:50 --> Total execution time: 0.0578
ERROR - 2023-10-20 13:44:55 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-20 13:44:55 --> Config Class Initialized
INFO - 2023-10-20 13:44:55 --> Hooks Class Initialized
DEBUG - 2023-10-20 13:44:55 --> UTF-8 Support Enabled
INFO - 2023-10-20 13:44:55 --> Utf8 Class Initialized
INFO - 2023-10-20 13:44:55 --> URI Class Initialized
INFO - 2023-10-20 13:44:55 --> Router Class Initialized
INFO - 2023-10-20 13:44:55 --> Output Class Initialized
INFO - 2023-10-20 13:44:55 --> Security Class Initialized
DEBUG - 2023-10-20 13:44:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-20 13:44:55 --> Input Class Initialized
INFO - 2023-10-20 13:44:55 --> Language Class Initialized
INFO - 2023-10-20 13:44:55 --> Loader Class Initialized
INFO - 2023-10-20 13:44:55 --> Helper loaded: url_helper
INFO - 2023-10-20 13:44:55 --> Helper loaded: file_helper
INFO - 2023-10-20 13:44:55 --> Helper loaded: html_helper
INFO - 2023-10-20 13:44:55 --> Helper loaded: text_helper
INFO - 2023-10-20 13:44:55 --> Helper loaded: form_helper
INFO - 2023-10-20 13:44:55 --> Helper loaded: lang_helper
INFO - 2023-10-20 13:44:55 --> Helper loaded: security_helper
INFO - 2023-10-20 13:44:55 --> Helper loaded: cookie_helper
INFO - 2023-10-20 13:44:55 --> Database Driver Class Initialized
INFO - 2023-10-20 13:44:55 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-20 13:44:55 --> Parser Class Initialized
INFO - 2023-10-20 13:44:55 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-20 13:44:55 --> Pagination Class Initialized
INFO - 2023-10-20 13:44:55 --> Form Validation Class Initialized
INFO - 2023-10-20 13:44:55 --> Controller Class Initialized
INFO - 2023-10-20 13:44:55 --> Model Class Initialized
DEBUG - 2023-10-20 13:44:55 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-10-20 13:44:55 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-20 13:44:55 --> Model Class Initialized
DEBUG - 2023-10-20 13:44:55 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-20 13:44:55 --> Model Class Initialized
INFO - 2023-10-20 13:44:55 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice.php
DEBUG - 2023-10-20 13:44:55 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-10-20 13:44:55 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-10-20 13:44:55 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-10-20 13:44:55 --> Model Class Initialized
INFO - 2023-10-20 13:44:55 --> Model Class Initialized
INFO - 2023-10-20 13:44:55 --> Model Class Initialized
INFO - 2023-10-20 13:44:55 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-10-20 13:44:55 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-10-20 13:44:55 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-10-20 13:44:55 --> Final output sent to browser
DEBUG - 2023-10-20 13:44:55 --> Total execution time: 0.2083
ERROR - 2023-10-20 13:44:56 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-20 13:44:56 --> Config Class Initialized
INFO - 2023-10-20 13:44:56 --> Hooks Class Initialized
DEBUG - 2023-10-20 13:44:56 --> UTF-8 Support Enabled
INFO - 2023-10-20 13:44:56 --> Utf8 Class Initialized
INFO - 2023-10-20 13:44:56 --> URI Class Initialized
INFO - 2023-10-20 13:44:56 --> Router Class Initialized
INFO - 2023-10-20 13:44:56 --> Output Class Initialized
INFO - 2023-10-20 13:44:56 --> Security Class Initialized
DEBUG - 2023-10-20 13:44:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-20 13:44:56 --> Input Class Initialized
INFO - 2023-10-20 13:44:56 --> Language Class Initialized
INFO - 2023-10-20 13:44:56 --> Loader Class Initialized
INFO - 2023-10-20 13:44:56 --> Helper loaded: url_helper
INFO - 2023-10-20 13:44:56 --> Helper loaded: file_helper
INFO - 2023-10-20 13:44:56 --> Helper loaded: html_helper
INFO - 2023-10-20 13:44:56 --> Helper loaded: text_helper
INFO - 2023-10-20 13:44:56 --> Helper loaded: form_helper
INFO - 2023-10-20 13:44:56 --> Helper loaded: lang_helper
INFO - 2023-10-20 13:44:56 --> Helper loaded: security_helper
INFO - 2023-10-20 13:44:56 --> Helper loaded: cookie_helper
INFO - 2023-10-20 13:44:56 --> Database Driver Class Initialized
INFO - 2023-10-20 13:44:56 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-20 13:44:56 --> Parser Class Initialized
INFO - 2023-10-20 13:44:56 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-20 13:44:56 --> Pagination Class Initialized
INFO - 2023-10-20 13:44:56 --> Form Validation Class Initialized
INFO - 2023-10-20 13:44:56 --> Controller Class Initialized
INFO - 2023-10-20 13:44:56 --> Model Class Initialized
DEBUG - 2023-10-20 13:44:56 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-10-20 13:44:56 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-20 13:44:56 --> Model Class Initialized
DEBUG - 2023-10-20 13:44:56 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-20 13:44:56 --> Model Class Initialized
INFO - 2023-10-20 13:44:56 --> Final output sent to browser
DEBUG - 2023-10-20 13:44:56 --> Total execution time: 0.0636
ERROR - 2023-10-20 13:44:58 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-20 13:44:58 --> Config Class Initialized
INFO - 2023-10-20 13:44:58 --> Hooks Class Initialized
DEBUG - 2023-10-20 13:44:58 --> UTF-8 Support Enabled
INFO - 2023-10-20 13:44:58 --> Utf8 Class Initialized
INFO - 2023-10-20 13:44:58 --> URI Class Initialized
DEBUG - 2023-10-20 13:44:58 --> No URI present. Default controller set.
INFO - 2023-10-20 13:44:58 --> Router Class Initialized
INFO - 2023-10-20 13:44:58 --> Output Class Initialized
INFO - 2023-10-20 13:44:58 --> Security Class Initialized
DEBUG - 2023-10-20 13:44:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-20 13:44:58 --> Input Class Initialized
INFO - 2023-10-20 13:44:58 --> Language Class Initialized
INFO - 2023-10-20 13:44:58 --> Loader Class Initialized
INFO - 2023-10-20 13:44:58 --> Helper loaded: url_helper
INFO - 2023-10-20 13:44:58 --> Helper loaded: file_helper
INFO - 2023-10-20 13:44:58 --> Helper loaded: html_helper
INFO - 2023-10-20 13:44:58 --> Helper loaded: text_helper
INFO - 2023-10-20 13:44:58 --> Helper loaded: form_helper
INFO - 2023-10-20 13:44:58 --> Helper loaded: lang_helper
INFO - 2023-10-20 13:44:58 --> Helper loaded: security_helper
INFO - 2023-10-20 13:44:58 --> Helper loaded: cookie_helper
INFO - 2023-10-20 13:44:58 --> Database Driver Class Initialized
INFO - 2023-10-20 13:44:58 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-20 13:44:58 --> Parser Class Initialized
INFO - 2023-10-20 13:44:58 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-20 13:44:58 --> Pagination Class Initialized
INFO - 2023-10-20 13:44:58 --> Form Validation Class Initialized
INFO - 2023-10-20 13:44:58 --> Controller Class Initialized
INFO - 2023-10-20 13:44:58 --> Model Class Initialized
DEBUG - 2023-10-20 13:44:58 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-20 13:44:58 --> Model Class Initialized
DEBUG - 2023-10-20 13:44:58 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-20 13:44:58 --> Model Class Initialized
INFO - 2023-10-20 13:44:58 --> Model Class Initialized
INFO - 2023-10-20 13:44:58 --> Model Class Initialized
INFO - 2023-10-20 13:44:58 --> Model Class Initialized
DEBUG - 2023-10-20 13:44:58 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-10-20 13:44:58 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-20 13:44:58 --> Model Class Initialized
INFO - 2023-10-20 13:44:58 --> Model Class Initialized
INFO - 2023-10-20 13:44:58 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-10-20 13:44:58 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-10-20 13:44:58 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-10-20 13:44:58 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-10-20 13:44:58 --> Model Class Initialized
INFO - 2023-10-20 13:44:58 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-10-20 13:44:58 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-10-20 13:44:58 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-10-20 13:44:58 --> Final output sent to browser
DEBUG - 2023-10-20 13:44:58 --> Total execution time: 0.3619
ERROR - 2023-10-20 13:45:22 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-20 13:45:22 --> Config Class Initialized
INFO - 2023-10-20 13:45:22 --> Hooks Class Initialized
DEBUG - 2023-10-20 13:45:22 --> UTF-8 Support Enabled
INFO - 2023-10-20 13:45:22 --> Utf8 Class Initialized
INFO - 2023-10-20 13:45:22 --> URI Class Initialized
INFO - 2023-10-20 13:45:22 --> Router Class Initialized
INFO - 2023-10-20 13:45:22 --> Output Class Initialized
INFO - 2023-10-20 13:45:22 --> Security Class Initialized
DEBUG - 2023-10-20 13:45:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-20 13:45:22 --> Input Class Initialized
INFO - 2023-10-20 13:45:22 --> Language Class Initialized
INFO - 2023-10-20 13:45:22 --> Loader Class Initialized
INFO - 2023-10-20 13:45:22 --> Helper loaded: url_helper
INFO - 2023-10-20 13:45:22 --> Helper loaded: file_helper
INFO - 2023-10-20 13:45:22 --> Helper loaded: html_helper
INFO - 2023-10-20 13:45:22 --> Helper loaded: text_helper
INFO - 2023-10-20 13:45:22 --> Helper loaded: form_helper
INFO - 2023-10-20 13:45:22 --> Helper loaded: lang_helper
INFO - 2023-10-20 13:45:22 --> Helper loaded: security_helper
INFO - 2023-10-20 13:45:22 --> Helper loaded: cookie_helper
INFO - 2023-10-20 13:45:22 --> Database Driver Class Initialized
INFO - 2023-10-20 13:45:22 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-20 13:45:22 --> Parser Class Initialized
INFO - 2023-10-20 13:45:22 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-20 13:45:22 --> Pagination Class Initialized
INFO - 2023-10-20 13:45:22 --> Form Validation Class Initialized
INFO - 2023-10-20 13:45:22 --> Controller Class Initialized
INFO - 2023-10-20 13:45:22 --> Model Class Initialized
DEBUG - 2023-10-20 13:45:22 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-10-20 13:45:22 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-20 13:45:22 --> Model Class Initialized
DEBUG - 2023-10-20 13:45:22 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-20 13:45:22 --> Model Class Initialized
INFO - 2023-10-20 13:45:22 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice.php
DEBUG - 2023-10-20 13:45:22 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-10-20 13:45:22 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-10-20 13:45:22 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-10-20 13:45:22 --> Model Class Initialized
INFO - 2023-10-20 13:45:22 --> Model Class Initialized
INFO - 2023-10-20 13:45:22 --> Model Class Initialized
INFO - 2023-10-20 13:45:22 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-10-20 13:45:22 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-10-20 13:45:22 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-10-20 13:45:22 --> Final output sent to browser
DEBUG - 2023-10-20 13:45:22 --> Total execution time: 0.2148
ERROR - 2023-10-20 13:45:23 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-20 13:45:23 --> Config Class Initialized
INFO - 2023-10-20 13:45:23 --> Hooks Class Initialized
DEBUG - 2023-10-20 13:45:23 --> UTF-8 Support Enabled
INFO - 2023-10-20 13:45:23 --> Utf8 Class Initialized
INFO - 2023-10-20 13:45:23 --> URI Class Initialized
INFO - 2023-10-20 13:45:23 --> Router Class Initialized
INFO - 2023-10-20 13:45:23 --> Output Class Initialized
INFO - 2023-10-20 13:45:23 --> Security Class Initialized
DEBUG - 2023-10-20 13:45:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-20 13:45:23 --> Input Class Initialized
INFO - 2023-10-20 13:45:23 --> Language Class Initialized
INFO - 2023-10-20 13:45:23 --> Loader Class Initialized
INFO - 2023-10-20 13:45:23 --> Helper loaded: url_helper
INFO - 2023-10-20 13:45:23 --> Helper loaded: file_helper
INFO - 2023-10-20 13:45:23 --> Helper loaded: html_helper
INFO - 2023-10-20 13:45:23 --> Helper loaded: text_helper
INFO - 2023-10-20 13:45:23 --> Helper loaded: form_helper
INFO - 2023-10-20 13:45:23 --> Helper loaded: lang_helper
INFO - 2023-10-20 13:45:23 --> Helper loaded: security_helper
INFO - 2023-10-20 13:45:23 --> Helper loaded: cookie_helper
INFO - 2023-10-20 13:45:23 --> Database Driver Class Initialized
INFO - 2023-10-20 13:45:23 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-20 13:45:23 --> Parser Class Initialized
INFO - 2023-10-20 13:45:23 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-20 13:45:23 --> Pagination Class Initialized
INFO - 2023-10-20 13:45:23 --> Form Validation Class Initialized
INFO - 2023-10-20 13:45:23 --> Controller Class Initialized
INFO - 2023-10-20 13:45:23 --> Model Class Initialized
DEBUG - 2023-10-20 13:45:23 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-10-20 13:45:23 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-20 13:45:23 --> Model Class Initialized
DEBUG - 2023-10-20 13:45:23 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-20 13:45:23 --> Model Class Initialized
INFO - 2023-10-20 13:45:23 --> Final output sent to browser
DEBUG - 2023-10-20 13:45:23 --> Total execution time: 0.0586
ERROR - 2023-10-20 13:45:34 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-20 13:45:34 --> Config Class Initialized
INFO - 2023-10-20 13:45:34 --> Hooks Class Initialized
DEBUG - 2023-10-20 13:45:34 --> UTF-8 Support Enabled
INFO - 2023-10-20 13:45:34 --> Utf8 Class Initialized
INFO - 2023-10-20 13:45:34 --> URI Class Initialized
DEBUG - 2023-10-20 13:45:34 --> No URI present. Default controller set.
INFO - 2023-10-20 13:45:34 --> Router Class Initialized
INFO - 2023-10-20 13:45:34 --> Output Class Initialized
INFO - 2023-10-20 13:45:34 --> Security Class Initialized
DEBUG - 2023-10-20 13:45:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-20 13:45:34 --> Input Class Initialized
INFO - 2023-10-20 13:45:34 --> Language Class Initialized
INFO - 2023-10-20 13:45:34 --> Loader Class Initialized
INFO - 2023-10-20 13:45:34 --> Helper loaded: url_helper
INFO - 2023-10-20 13:45:34 --> Helper loaded: file_helper
INFO - 2023-10-20 13:45:34 --> Helper loaded: html_helper
INFO - 2023-10-20 13:45:34 --> Helper loaded: text_helper
INFO - 2023-10-20 13:45:34 --> Helper loaded: form_helper
INFO - 2023-10-20 13:45:34 --> Helper loaded: lang_helper
INFO - 2023-10-20 13:45:34 --> Helper loaded: security_helper
INFO - 2023-10-20 13:45:34 --> Helper loaded: cookie_helper
INFO - 2023-10-20 13:45:34 --> Database Driver Class Initialized
INFO - 2023-10-20 13:45:34 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-20 13:45:34 --> Parser Class Initialized
INFO - 2023-10-20 13:45:34 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-20 13:45:34 --> Pagination Class Initialized
INFO - 2023-10-20 13:45:34 --> Form Validation Class Initialized
INFO - 2023-10-20 13:45:34 --> Controller Class Initialized
INFO - 2023-10-20 13:45:34 --> Model Class Initialized
DEBUG - 2023-10-20 13:45:34 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-20 13:45:34 --> Model Class Initialized
DEBUG - 2023-10-20 13:45:34 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-20 13:45:34 --> Model Class Initialized
INFO - 2023-10-20 13:45:34 --> Model Class Initialized
INFO - 2023-10-20 13:45:34 --> Model Class Initialized
INFO - 2023-10-20 13:45:34 --> Model Class Initialized
DEBUG - 2023-10-20 13:45:34 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-10-20 13:45:34 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-20 13:45:34 --> Model Class Initialized
INFO - 2023-10-20 13:45:34 --> Model Class Initialized
INFO - 2023-10-20 13:45:34 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-10-20 13:45:34 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-10-20 13:45:34 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-10-20 13:45:34 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-10-20 13:45:34 --> Model Class Initialized
INFO - 2023-10-20 13:45:34 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-10-20 13:45:34 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-10-20 13:45:34 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-10-20 13:45:34 --> Final output sent to browser
DEBUG - 2023-10-20 13:45:34 --> Total execution time: 0.3588
ERROR - 2023-10-20 13:45:48 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-20 13:45:48 --> Config Class Initialized
INFO - 2023-10-20 13:45:48 --> Hooks Class Initialized
DEBUG - 2023-10-20 13:45:48 --> UTF-8 Support Enabled
INFO - 2023-10-20 13:45:48 --> Utf8 Class Initialized
INFO - 2023-10-20 13:45:48 --> URI Class Initialized
INFO - 2023-10-20 13:45:48 --> Router Class Initialized
INFO - 2023-10-20 13:45:48 --> Output Class Initialized
INFO - 2023-10-20 13:45:48 --> Security Class Initialized
DEBUG - 2023-10-20 13:45:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-20 13:45:48 --> Input Class Initialized
INFO - 2023-10-20 13:45:48 --> Language Class Initialized
INFO - 2023-10-20 13:45:48 --> Loader Class Initialized
INFO - 2023-10-20 13:45:48 --> Helper loaded: url_helper
INFO - 2023-10-20 13:45:48 --> Helper loaded: file_helper
INFO - 2023-10-20 13:45:48 --> Helper loaded: html_helper
INFO - 2023-10-20 13:45:48 --> Helper loaded: text_helper
INFO - 2023-10-20 13:45:48 --> Helper loaded: form_helper
INFO - 2023-10-20 13:45:48 --> Helper loaded: lang_helper
INFO - 2023-10-20 13:45:48 --> Helper loaded: security_helper
INFO - 2023-10-20 13:45:48 --> Helper loaded: cookie_helper
INFO - 2023-10-20 13:45:48 --> Database Driver Class Initialized
INFO - 2023-10-20 13:45:48 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-20 13:45:48 --> Parser Class Initialized
INFO - 2023-10-20 13:45:48 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-20 13:45:48 --> Pagination Class Initialized
INFO - 2023-10-20 13:45:48 --> Form Validation Class Initialized
INFO - 2023-10-20 13:45:48 --> Controller Class Initialized
INFO - 2023-10-20 13:45:48 --> Model Class Initialized
DEBUG - 2023-10-20 13:45:48 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-10-20 13:45:48 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-20 13:45:48 --> Model Class Initialized
DEBUG - 2023-10-20 13:45:48 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-20 13:45:48 --> Model Class Initialized
INFO - 2023-10-20 13:45:48 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/invoice/invoice.php
DEBUG - 2023-10-20 13:45:48 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-10-20 13:45:48 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-10-20 13:45:48 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-10-20 13:45:48 --> Model Class Initialized
INFO - 2023-10-20 13:45:48 --> Model Class Initialized
INFO - 2023-10-20 13:45:48 --> Model Class Initialized
INFO - 2023-10-20 13:45:48 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-10-20 13:45:48 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-10-20 13:45:48 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-10-20 13:45:48 --> Final output sent to browser
DEBUG - 2023-10-20 13:45:48 --> Total execution time: 0.2236
ERROR - 2023-10-20 13:45:49 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-20 13:45:49 --> Config Class Initialized
INFO - 2023-10-20 13:45:49 --> Hooks Class Initialized
DEBUG - 2023-10-20 13:45:49 --> UTF-8 Support Enabled
INFO - 2023-10-20 13:45:49 --> Utf8 Class Initialized
INFO - 2023-10-20 13:45:49 --> URI Class Initialized
INFO - 2023-10-20 13:45:49 --> Router Class Initialized
INFO - 2023-10-20 13:45:49 --> Output Class Initialized
INFO - 2023-10-20 13:45:49 --> Security Class Initialized
DEBUG - 2023-10-20 13:45:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-20 13:45:49 --> Input Class Initialized
INFO - 2023-10-20 13:45:49 --> Language Class Initialized
INFO - 2023-10-20 13:45:49 --> Loader Class Initialized
INFO - 2023-10-20 13:45:49 --> Helper loaded: url_helper
INFO - 2023-10-20 13:45:49 --> Helper loaded: file_helper
INFO - 2023-10-20 13:45:49 --> Helper loaded: html_helper
INFO - 2023-10-20 13:45:49 --> Helper loaded: text_helper
INFO - 2023-10-20 13:45:49 --> Helper loaded: form_helper
INFO - 2023-10-20 13:45:49 --> Helper loaded: lang_helper
INFO - 2023-10-20 13:45:49 --> Helper loaded: security_helper
INFO - 2023-10-20 13:45:49 --> Helper loaded: cookie_helper
INFO - 2023-10-20 13:45:49 --> Database Driver Class Initialized
INFO - 2023-10-20 13:45:49 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-20 13:45:49 --> Parser Class Initialized
INFO - 2023-10-20 13:45:49 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-20 13:45:49 --> Pagination Class Initialized
INFO - 2023-10-20 13:45:49 --> Form Validation Class Initialized
INFO - 2023-10-20 13:45:49 --> Controller Class Initialized
INFO - 2023-10-20 13:45:49 --> Model Class Initialized
DEBUG - 2023-10-20 13:45:49 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-10-20 13:45:49 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-20 13:45:49 --> Model Class Initialized
DEBUG - 2023-10-20 13:45:49 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-20 13:45:49 --> Model Class Initialized
INFO - 2023-10-20 13:45:49 --> Final output sent to browser
DEBUG - 2023-10-20 13:45:49 --> Total execution time: 0.0536
ERROR - 2023-10-20 13:46:36 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-20 13:46:36 --> Config Class Initialized
INFO - 2023-10-20 13:46:36 --> Hooks Class Initialized
DEBUG - 2023-10-20 13:46:36 --> UTF-8 Support Enabled
INFO - 2023-10-20 13:46:36 --> Utf8 Class Initialized
INFO - 2023-10-20 13:46:36 --> URI Class Initialized
DEBUG - 2023-10-20 13:46:36 --> No URI present. Default controller set.
INFO - 2023-10-20 13:46:36 --> Router Class Initialized
INFO - 2023-10-20 13:46:36 --> Output Class Initialized
INFO - 2023-10-20 13:46:36 --> Security Class Initialized
DEBUG - 2023-10-20 13:46:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-20 13:46:36 --> Input Class Initialized
INFO - 2023-10-20 13:46:36 --> Language Class Initialized
INFO - 2023-10-20 13:46:36 --> Loader Class Initialized
INFO - 2023-10-20 13:46:36 --> Helper loaded: url_helper
INFO - 2023-10-20 13:46:36 --> Helper loaded: file_helper
INFO - 2023-10-20 13:46:36 --> Helper loaded: html_helper
INFO - 2023-10-20 13:46:36 --> Helper loaded: text_helper
INFO - 2023-10-20 13:46:36 --> Helper loaded: form_helper
INFO - 2023-10-20 13:46:36 --> Helper loaded: lang_helper
INFO - 2023-10-20 13:46:36 --> Helper loaded: security_helper
INFO - 2023-10-20 13:46:36 --> Helper loaded: cookie_helper
INFO - 2023-10-20 13:46:36 --> Database Driver Class Initialized
INFO - 2023-10-20 13:46:36 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-20 13:46:36 --> Parser Class Initialized
INFO - 2023-10-20 13:46:36 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-20 13:46:36 --> Pagination Class Initialized
INFO - 2023-10-20 13:46:36 --> Form Validation Class Initialized
INFO - 2023-10-20 13:46:36 --> Controller Class Initialized
INFO - 2023-10-20 13:46:36 --> Model Class Initialized
DEBUG - 2023-10-20 13:46:36 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-20 13:46:36 --> Model Class Initialized
DEBUG - 2023-10-20 13:46:36 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-20 13:46:36 --> Model Class Initialized
INFO - 2023-10-20 13:46:36 --> Model Class Initialized
INFO - 2023-10-20 13:46:36 --> Model Class Initialized
INFO - 2023-10-20 13:46:36 --> Model Class Initialized
DEBUG - 2023-10-20 13:46:36 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-10-20 13:46:36 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-20 13:46:36 --> Model Class Initialized
INFO - 2023-10-20 13:46:36 --> Model Class Initialized
INFO - 2023-10-20 13:46:36 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-10-20 13:46:36 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-10-20 13:46:36 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-10-20 13:46:36 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-10-20 13:46:36 --> Model Class Initialized
INFO - 2023-10-20 13:46:36 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-10-20 13:46:36 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-10-20 13:46:36 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-10-20 13:46:36 --> Final output sent to browser
DEBUG - 2023-10-20 13:46:36 --> Total execution time: 0.3513
ERROR - 2023-10-20 13:46:46 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-20 13:46:46 --> Config Class Initialized
INFO - 2023-10-20 13:46:46 --> Hooks Class Initialized
DEBUG - 2023-10-20 13:46:46 --> UTF-8 Support Enabled
INFO - 2023-10-20 13:46:46 --> Utf8 Class Initialized
INFO - 2023-10-20 13:46:46 --> URI Class Initialized
DEBUG - 2023-10-20 13:46:46 --> No URI present. Default controller set.
INFO - 2023-10-20 13:46:46 --> Router Class Initialized
INFO - 2023-10-20 13:46:46 --> Output Class Initialized
INFO - 2023-10-20 13:46:46 --> Security Class Initialized
DEBUG - 2023-10-20 13:46:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-20 13:46:46 --> Input Class Initialized
INFO - 2023-10-20 13:46:46 --> Language Class Initialized
INFO - 2023-10-20 13:46:46 --> Loader Class Initialized
INFO - 2023-10-20 13:46:46 --> Helper loaded: url_helper
INFO - 2023-10-20 13:46:46 --> Helper loaded: file_helper
INFO - 2023-10-20 13:46:46 --> Helper loaded: html_helper
INFO - 2023-10-20 13:46:46 --> Helper loaded: text_helper
INFO - 2023-10-20 13:46:46 --> Helper loaded: form_helper
INFO - 2023-10-20 13:46:46 --> Helper loaded: lang_helper
INFO - 2023-10-20 13:46:46 --> Helper loaded: security_helper
INFO - 2023-10-20 13:46:46 --> Helper loaded: cookie_helper
INFO - 2023-10-20 13:46:46 --> Database Driver Class Initialized
INFO - 2023-10-20 13:46:46 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-20 13:46:46 --> Parser Class Initialized
INFO - 2023-10-20 13:46:46 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-20 13:46:46 --> Pagination Class Initialized
INFO - 2023-10-20 13:46:46 --> Form Validation Class Initialized
INFO - 2023-10-20 13:46:46 --> Controller Class Initialized
INFO - 2023-10-20 13:46:46 --> Model Class Initialized
DEBUG - 2023-10-20 13:46:46 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-20 13:46:46 --> Model Class Initialized
DEBUG - 2023-10-20 13:46:46 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-20 13:46:46 --> Model Class Initialized
INFO - 2023-10-20 13:46:46 --> Model Class Initialized
INFO - 2023-10-20 13:46:46 --> Model Class Initialized
INFO - 2023-10-20 13:46:46 --> Model Class Initialized
DEBUG - 2023-10-20 13:46:46 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-10-20 13:46:46 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-20 13:46:46 --> Model Class Initialized
INFO - 2023-10-20 13:46:46 --> Model Class Initialized
INFO - 2023-10-20 13:46:46 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-10-20 13:46:46 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-10-20 13:46:46 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-10-20 13:46:46 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-10-20 13:46:46 --> Model Class Initialized
INFO - 2023-10-20 13:46:46 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-10-20 13:46:46 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-10-20 13:46:46 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-10-20 13:46:46 --> Final output sent to browser
DEBUG - 2023-10-20 13:46:46 --> Total execution time: 0.3392
ERROR - 2023-10-20 13:46:52 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-20 13:46:52 --> Config Class Initialized
INFO - 2023-10-20 13:46:52 --> Hooks Class Initialized
DEBUG - 2023-10-20 13:46:52 --> UTF-8 Support Enabled
INFO - 2023-10-20 13:46:52 --> Utf8 Class Initialized
INFO - 2023-10-20 13:46:52 --> URI Class Initialized
DEBUG - 2023-10-20 13:46:52 --> No URI present. Default controller set.
INFO - 2023-10-20 13:46:52 --> Router Class Initialized
INFO - 2023-10-20 13:46:52 --> Output Class Initialized
INFO - 2023-10-20 13:46:52 --> Security Class Initialized
DEBUG - 2023-10-20 13:46:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-20 13:46:52 --> Input Class Initialized
INFO - 2023-10-20 13:46:52 --> Language Class Initialized
INFO - 2023-10-20 13:46:52 --> Loader Class Initialized
INFO - 2023-10-20 13:46:52 --> Helper loaded: url_helper
INFO - 2023-10-20 13:46:52 --> Helper loaded: file_helper
INFO - 2023-10-20 13:46:52 --> Helper loaded: html_helper
INFO - 2023-10-20 13:46:52 --> Helper loaded: text_helper
INFO - 2023-10-20 13:46:52 --> Helper loaded: form_helper
INFO - 2023-10-20 13:46:52 --> Helper loaded: lang_helper
INFO - 2023-10-20 13:46:52 --> Helper loaded: security_helper
INFO - 2023-10-20 13:46:52 --> Helper loaded: cookie_helper
INFO - 2023-10-20 13:46:52 --> Database Driver Class Initialized
INFO - 2023-10-20 13:46:52 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-20 13:46:52 --> Parser Class Initialized
INFO - 2023-10-20 13:46:52 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-20 13:46:52 --> Pagination Class Initialized
INFO - 2023-10-20 13:46:52 --> Form Validation Class Initialized
INFO - 2023-10-20 13:46:52 --> Controller Class Initialized
INFO - 2023-10-20 13:46:52 --> Model Class Initialized
DEBUG - 2023-10-20 13:46:52 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-20 13:46:52 --> Model Class Initialized
DEBUG - 2023-10-20 13:46:52 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-20 13:46:52 --> Model Class Initialized
INFO - 2023-10-20 13:46:52 --> Model Class Initialized
INFO - 2023-10-20 13:46:52 --> Model Class Initialized
INFO - 2023-10-20 13:46:52 --> Model Class Initialized
DEBUG - 2023-10-20 13:46:52 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-10-20 13:46:52 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-20 13:46:52 --> Model Class Initialized
INFO - 2023-10-20 13:46:52 --> Model Class Initialized
INFO - 2023-10-20 13:46:53 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-10-20 13:46:53 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-10-20 13:46:53 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-10-20 13:46:53 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-10-20 13:46:53 --> Model Class Initialized
INFO - 2023-10-20 13:46:53 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-10-20 13:46:53 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-10-20 13:46:53 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-10-20 13:46:53 --> Final output sent to browser
DEBUG - 2023-10-20 13:46:53 --> Total execution time: 0.3582
ERROR - 2023-10-20 13:47:19 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-20 13:47:19 --> Config Class Initialized
INFO - 2023-10-20 13:47:19 --> Hooks Class Initialized
DEBUG - 2023-10-20 13:47:19 --> UTF-8 Support Enabled
INFO - 2023-10-20 13:47:19 --> Utf8 Class Initialized
INFO - 2023-10-20 13:47:19 --> URI Class Initialized
DEBUG - 2023-10-20 13:47:19 --> No URI present. Default controller set.
INFO - 2023-10-20 13:47:19 --> Router Class Initialized
INFO - 2023-10-20 13:47:19 --> Output Class Initialized
INFO - 2023-10-20 13:47:19 --> Security Class Initialized
DEBUG - 2023-10-20 13:47:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-20 13:47:19 --> Input Class Initialized
INFO - 2023-10-20 13:47:19 --> Language Class Initialized
INFO - 2023-10-20 13:47:19 --> Loader Class Initialized
INFO - 2023-10-20 13:47:19 --> Helper loaded: url_helper
INFO - 2023-10-20 13:47:19 --> Helper loaded: file_helper
INFO - 2023-10-20 13:47:19 --> Helper loaded: html_helper
INFO - 2023-10-20 13:47:19 --> Helper loaded: text_helper
INFO - 2023-10-20 13:47:19 --> Helper loaded: form_helper
INFO - 2023-10-20 13:47:19 --> Helper loaded: lang_helper
INFO - 2023-10-20 13:47:19 --> Helper loaded: security_helper
INFO - 2023-10-20 13:47:19 --> Helper loaded: cookie_helper
INFO - 2023-10-20 13:47:19 --> Database Driver Class Initialized
INFO - 2023-10-20 13:47:19 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-20 13:47:19 --> Parser Class Initialized
INFO - 2023-10-20 13:47:19 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-20 13:47:19 --> Pagination Class Initialized
INFO - 2023-10-20 13:47:19 --> Form Validation Class Initialized
INFO - 2023-10-20 13:47:19 --> Controller Class Initialized
INFO - 2023-10-20 13:47:19 --> Model Class Initialized
DEBUG - 2023-10-20 13:47:19 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-20 13:47:19 --> Model Class Initialized
DEBUG - 2023-10-20 13:47:19 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-20 13:47:19 --> Model Class Initialized
INFO - 2023-10-20 13:47:19 --> Model Class Initialized
INFO - 2023-10-20 13:47:19 --> Model Class Initialized
INFO - 2023-10-20 13:47:19 --> Model Class Initialized
DEBUG - 2023-10-20 13:47:19 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-10-20 13:47:19 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-20 13:47:19 --> Model Class Initialized
INFO - 2023-10-20 13:47:19 --> Model Class Initialized
INFO - 2023-10-20 13:47:20 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-10-20 13:47:20 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-10-20 13:47:20 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-10-20 13:47:20 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-10-20 13:47:20 --> Model Class Initialized
INFO - 2023-10-20 13:47:20 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-10-20 13:47:20 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-10-20 13:47:20 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-10-20 13:47:20 --> Final output sent to browser
DEBUG - 2023-10-20 13:47:20 --> Total execution time: 0.3706
ERROR - 2023-10-20 13:47:26 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-20 13:47:26 --> Config Class Initialized
INFO - 2023-10-20 13:47:26 --> Hooks Class Initialized
DEBUG - 2023-10-20 13:47:26 --> UTF-8 Support Enabled
INFO - 2023-10-20 13:47:26 --> Utf8 Class Initialized
INFO - 2023-10-20 13:47:26 --> URI Class Initialized
DEBUG - 2023-10-20 13:47:26 --> No URI present. Default controller set.
INFO - 2023-10-20 13:47:26 --> Router Class Initialized
INFO - 2023-10-20 13:47:26 --> Output Class Initialized
INFO - 2023-10-20 13:47:26 --> Security Class Initialized
DEBUG - 2023-10-20 13:47:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-20 13:47:26 --> Input Class Initialized
INFO - 2023-10-20 13:47:26 --> Language Class Initialized
INFO - 2023-10-20 13:47:26 --> Loader Class Initialized
INFO - 2023-10-20 13:47:26 --> Helper loaded: url_helper
INFO - 2023-10-20 13:47:26 --> Helper loaded: file_helper
INFO - 2023-10-20 13:47:26 --> Helper loaded: html_helper
INFO - 2023-10-20 13:47:26 --> Helper loaded: text_helper
INFO - 2023-10-20 13:47:26 --> Helper loaded: form_helper
INFO - 2023-10-20 13:47:26 --> Helper loaded: lang_helper
INFO - 2023-10-20 13:47:26 --> Helper loaded: security_helper
INFO - 2023-10-20 13:47:26 --> Helper loaded: cookie_helper
INFO - 2023-10-20 13:47:26 --> Database Driver Class Initialized
INFO - 2023-10-20 13:47:26 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-20 13:47:26 --> Parser Class Initialized
INFO - 2023-10-20 13:47:26 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-20 13:47:26 --> Pagination Class Initialized
INFO - 2023-10-20 13:47:26 --> Form Validation Class Initialized
INFO - 2023-10-20 13:47:26 --> Controller Class Initialized
INFO - 2023-10-20 13:47:26 --> Model Class Initialized
DEBUG - 2023-10-20 13:47:26 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-20 13:47:26 --> Model Class Initialized
DEBUG - 2023-10-20 13:47:26 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-20 13:47:26 --> Model Class Initialized
INFO - 2023-10-20 13:47:26 --> Model Class Initialized
INFO - 2023-10-20 13:47:26 --> Model Class Initialized
INFO - 2023-10-20 13:47:26 --> Model Class Initialized
DEBUG - 2023-10-20 13:47:26 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-10-20 13:47:26 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-20 13:47:26 --> Model Class Initialized
INFO - 2023-10-20 13:47:26 --> Model Class Initialized
INFO - 2023-10-20 13:47:26 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-10-20 13:47:26 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-10-20 13:47:26 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-10-20 13:47:26 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-10-20 13:47:26 --> Model Class Initialized
INFO - 2023-10-20 13:47:26 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-10-20 13:47:26 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-10-20 13:47:26 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-10-20 13:47:26 --> Final output sent to browser
DEBUG - 2023-10-20 13:47:26 --> Total execution time: 0.3526
ERROR - 2023-10-20 13:48:18 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-20 13:48:18 --> Config Class Initialized
INFO - 2023-10-20 13:48:18 --> Hooks Class Initialized
DEBUG - 2023-10-20 13:48:18 --> UTF-8 Support Enabled
INFO - 2023-10-20 13:48:18 --> Utf8 Class Initialized
INFO - 2023-10-20 13:48:18 --> URI Class Initialized
INFO - 2023-10-20 13:48:18 --> Router Class Initialized
INFO - 2023-10-20 13:48:18 --> Output Class Initialized
INFO - 2023-10-20 13:48:18 --> Security Class Initialized
DEBUG - 2023-10-20 13:48:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-20 13:48:18 --> Input Class Initialized
INFO - 2023-10-20 13:48:18 --> Language Class Initialized
INFO - 2023-10-20 13:48:18 --> Loader Class Initialized
INFO - 2023-10-20 13:48:18 --> Helper loaded: url_helper
INFO - 2023-10-20 13:48:18 --> Helper loaded: file_helper
INFO - 2023-10-20 13:48:18 --> Helper loaded: html_helper
INFO - 2023-10-20 13:48:18 --> Helper loaded: text_helper
INFO - 2023-10-20 13:48:18 --> Helper loaded: form_helper
INFO - 2023-10-20 13:48:18 --> Helper loaded: lang_helper
INFO - 2023-10-20 13:48:18 --> Helper loaded: security_helper
INFO - 2023-10-20 13:48:18 --> Helper loaded: cookie_helper
INFO - 2023-10-20 13:48:18 --> Database Driver Class Initialized
INFO - 2023-10-20 13:48:18 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-20 13:48:18 --> Parser Class Initialized
INFO - 2023-10-20 13:48:18 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-20 13:48:18 --> Pagination Class Initialized
INFO - 2023-10-20 13:48:18 --> Form Validation Class Initialized
INFO - 2023-10-20 13:48:18 --> Controller Class Initialized
DEBUG - 2023-10-20 13:48:18 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-10-20 13:48:18 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-20 13:48:18 --> Model Class Initialized
DEBUG - 2023-10-20 13:48:18 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-20 13:48:18 --> Model Class Initialized
DEBUG - 2023-10-20 13:48:18 --> Lcustomer class already loaded. Second attempt ignored.
INFO - 2023-10-20 13:48:18 --> Model Class Initialized
INFO - 2023-10-20 13:48:18 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/customer/customer.php
DEBUG - 2023-10-20 13:48:18 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-10-20 13:48:18 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-10-20 13:48:18 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-10-20 13:48:18 --> Model Class Initialized
INFO - 2023-10-20 13:48:18 --> Model Class Initialized
INFO - 2023-10-20 13:48:18 --> Model Class Initialized
INFO - 2023-10-20 13:48:18 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-10-20 13:48:18 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-10-20 13:48:18 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-10-20 13:48:18 --> Final output sent to browser
DEBUG - 2023-10-20 13:48:18 --> Total execution time: 0.2139
ERROR - 2023-10-20 13:48:20 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-20 13:48:20 --> Config Class Initialized
INFO - 2023-10-20 13:48:20 --> Hooks Class Initialized
DEBUG - 2023-10-20 13:48:20 --> UTF-8 Support Enabled
INFO - 2023-10-20 13:48:20 --> Utf8 Class Initialized
INFO - 2023-10-20 13:48:20 --> URI Class Initialized
INFO - 2023-10-20 13:48:20 --> Router Class Initialized
INFO - 2023-10-20 13:48:20 --> Output Class Initialized
INFO - 2023-10-20 13:48:20 --> Security Class Initialized
DEBUG - 2023-10-20 13:48:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-20 13:48:20 --> Input Class Initialized
INFO - 2023-10-20 13:48:20 --> Language Class Initialized
INFO - 2023-10-20 13:48:20 --> Loader Class Initialized
INFO - 2023-10-20 13:48:20 --> Helper loaded: url_helper
INFO - 2023-10-20 13:48:20 --> Helper loaded: file_helper
INFO - 2023-10-20 13:48:20 --> Helper loaded: html_helper
INFO - 2023-10-20 13:48:20 --> Helper loaded: text_helper
INFO - 2023-10-20 13:48:20 --> Helper loaded: form_helper
INFO - 2023-10-20 13:48:20 --> Helper loaded: lang_helper
INFO - 2023-10-20 13:48:20 --> Helper loaded: security_helper
INFO - 2023-10-20 13:48:20 --> Helper loaded: cookie_helper
INFO - 2023-10-20 13:48:20 --> Database Driver Class Initialized
INFO - 2023-10-20 13:48:20 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-20 13:48:20 --> Parser Class Initialized
INFO - 2023-10-20 13:48:20 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-20 13:48:20 --> Pagination Class Initialized
INFO - 2023-10-20 13:48:20 --> Form Validation Class Initialized
INFO - 2023-10-20 13:48:20 --> Controller Class Initialized
DEBUG - 2023-10-20 13:48:20 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-10-20 13:48:20 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-20 13:48:20 --> Model Class Initialized
DEBUG - 2023-10-20 13:48:20 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-20 13:48:20 --> Model Class Initialized
INFO - 2023-10-20 13:48:20 --> Final output sent to browser
DEBUG - 2023-10-20 13:48:20 --> Total execution time: 0.0329
ERROR - 2023-10-20 13:48:23 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-20 13:48:23 --> Config Class Initialized
INFO - 2023-10-20 13:48:23 --> Hooks Class Initialized
DEBUG - 2023-10-20 13:48:23 --> UTF-8 Support Enabled
INFO - 2023-10-20 13:48:23 --> Utf8 Class Initialized
INFO - 2023-10-20 13:48:23 --> URI Class Initialized
INFO - 2023-10-20 13:48:23 --> Router Class Initialized
INFO - 2023-10-20 13:48:23 --> Output Class Initialized
INFO - 2023-10-20 13:48:23 --> Security Class Initialized
DEBUG - 2023-10-20 13:48:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-20 13:48:23 --> Input Class Initialized
INFO - 2023-10-20 13:48:23 --> Language Class Initialized
INFO - 2023-10-20 13:48:23 --> Loader Class Initialized
INFO - 2023-10-20 13:48:23 --> Helper loaded: url_helper
INFO - 2023-10-20 13:48:23 --> Helper loaded: file_helper
INFO - 2023-10-20 13:48:23 --> Helper loaded: html_helper
INFO - 2023-10-20 13:48:23 --> Helper loaded: text_helper
INFO - 2023-10-20 13:48:23 --> Helper loaded: form_helper
INFO - 2023-10-20 13:48:23 --> Helper loaded: lang_helper
INFO - 2023-10-20 13:48:23 --> Helper loaded: security_helper
INFO - 2023-10-20 13:48:23 --> Helper loaded: cookie_helper
INFO - 2023-10-20 13:48:23 --> Database Driver Class Initialized
INFO - 2023-10-20 13:48:23 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-20 13:48:23 --> Parser Class Initialized
INFO - 2023-10-20 13:48:23 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-20 13:48:23 --> Pagination Class Initialized
INFO - 2023-10-20 13:48:23 --> Form Validation Class Initialized
INFO - 2023-10-20 13:48:23 --> Controller Class Initialized
DEBUG - 2023-10-20 13:48:23 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-10-20 13:48:23 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-20 13:48:23 --> Model Class Initialized
DEBUG - 2023-10-20 13:48:23 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-20 13:48:23 --> Model Class Initialized
INFO - 2023-10-20 13:48:23 --> Final output sent to browser
DEBUG - 2023-10-20 13:48:23 --> Total execution time: 0.1741
ERROR - 2023-10-20 14:38:55 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-20 14:38:55 --> Config Class Initialized
INFO - 2023-10-20 14:38:55 --> Hooks Class Initialized
DEBUG - 2023-10-20 14:38:55 --> UTF-8 Support Enabled
INFO - 2023-10-20 14:38:55 --> Utf8 Class Initialized
INFO - 2023-10-20 14:38:55 --> URI Class Initialized
DEBUG - 2023-10-20 14:38:55 --> No URI present. Default controller set.
INFO - 2023-10-20 14:38:55 --> Router Class Initialized
INFO - 2023-10-20 14:38:55 --> Output Class Initialized
INFO - 2023-10-20 14:38:55 --> Security Class Initialized
DEBUG - 2023-10-20 14:38:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-20 14:38:55 --> Input Class Initialized
INFO - 2023-10-20 14:38:55 --> Language Class Initialized
INFO - 2023-10-20 14:38:55 --> Loader Class Initialized
INFO - 2023-10-20 14:38:55 --> Helper loaded: url_helper
INFO - 2023-10-20 14:38:55 --> Helper loaded: file_helper
INFO - 2023-10-20 14:38:55 --> Helper loaded: html_helper
INFO - 2023-10-20 14:38:55 --> Helper loaded: text_helper
INFO - 2023-10-20 14:38:55 --> Helper loaded: form_helper
INFO - 2023-10-20 14:38:55 --> Helper loaded: lang_helper
INFO - 2023-10-20 14:38:55 --> Helper loaded: security_helper
INFO - 2023-10-20 14:38:55 --> Helper loaded: cookie_helper
INFO - 2023-10-20 14:38:55 --> Database Driver Class Initialized
INFO - 2023-10-20 14:38:55 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-20 14:38:55 --> Parser Class Initialized
INFO - 2023-10-20 14:38:55 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-20 14:38:55 --> Pagination Class Initialized
INFO - 2023-10-20 14:38:55 --> Form Validation Class Initialized
INFO - 2023-10-20 14:38:55 --> Controller Class Initialized
INFO - 2023-10-20 14:38:55 --> Model Class Initialized
DEBUG - 2023-10-20 14:38:55 --> Session class already loaded. Second attempt ignored.
ERROR - 2023-10-20 14:38:55 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-20 14:38:55 --> Config Class Initialized
INFO - 2023-10-20 14:38:55 --> Hooks Class Initialized
DEBUG - 2023-10-20 14:38:55 --> UTF-8 Support Enabled
INFO - 2023-10-20 14:38:55 --> Utf8 Class Initialized
INFO - 2023-10-20 14:38:55 --> URI Class Initialized
INFO - 2023-10-20 14:38:55 --> Router Class Initialized
INFO - 2023-10-20 14:38:55 --> Output Class Initialized
INFO - 2023-10-20 14:38:55 --> Security Class Initialized
DEBUG - 2023-10-20 14:38:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-20 14:38:55 --> Input Class Initialized
INFO - 2023-10-20 14:38:55 --> Language Class Initialized
INFO - 2023-10-20 14:38:55 --> Loader Class Initialized
INFO - 2023-10-20 14:38:55 --> Helper loaded: url_helper
INFO - 2023-10-20 14:38:55 --> Helper loaded: file_helper
INFO - 2023-10-20 14:38:55 --> Helper loaded: html_helper
INFO - 2023-10-20 14:38:55 --> Helper loaded: text_helper
INFO - 2023-10-20 14:38:55 --> Helper loaded: form_helper
INFO - 2023-10-20 14:38:55 --> Helper loaded: lang_helper
INFO - 2023-10-20 14:38:55 --> Helper loaded: security_helper
INFO - 2023-10-20 14:38:55 --> Helper loaded: cookie_helper
INFO - 2023-10-20 14:38:55 --> Database Driver Class Initialized
INFO - 2023-10-20 14:38:55 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-20 14:38:55 --> Parser Class Initialized
INFO - 2023-10-20 14:38:55 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-20 14:38:55 --> Pagination Class Initialized
INFO - 2023-10-20 14:38:55 --> Form Validation Class Initialized
INFO - 2023-10-20 14:38:55 --> Controller Class Initialized
INFO - 2023-10-20 14:38:55 --> Model Class Initialized
DEBUG - 2023-10-20 14:38:55 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-20 14:38:55 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2023-10-20 14:38:55 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-10-20 14:38:55 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-10-20 14:38:55 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-10-20 14:38:55 --> Model Class Initialized
INFO - 2023-10-20 14:38:55 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-10-20 14:38:55 --> Final output sent to browser
DEBUG - 2023-10-20 14:38:55 --> Total execution time: 0.0354
ERROR - 2023-10-20 17:58:55 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-20 17:58:55 --> Config Class Initialized
INFO - 2023-10-20 17:58:55 --> Hooks Class Initialized
DEBUG - 2023-10-20 17:58:55 --> UTF-8 Support Enabled
INFO - 2023-10-20 17:58:55 --> Utf8 Class Initialized
INFO - 2023-10-20 17:58:55 --> URI Class Initialized
DEBUG - 2023-10-20 17:58:55 --> No URI present. Default controller set.
INFO - 2023-10-20 17:58:55 --> Router Class Initialized
INFO - 2023-10-20 17:58:55 --> Output Class Initialized
INFO - 2023-10-20 17:58:55 --> Security Class Initialized
DEBUG - 2023-10-20 17:58:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-20 17:58:55 --> Input Class Initialized
INFO - 2023-10-20 17:58:55 --> Language Class Initialized
INFO - 2023-10-20 17:58:55 --> Loader Class Initialized
INFO - 2023-10-20 17:58:55 --> Helper loaded: url_helper
INFO - 2023-10-20 17:58:55 --> Helper loaded: file_helper
INFO - 2023-10-20 17:58:55 --> Helper loaded: html_helper
INFO - 2023-10-20 17:58:55 --> Helper loaded: text_helper
INFO - 2023-10-20 17:58:55 --> Helper loaded: form_helper
INFO - 2023-10-20 17:58:55 --> Helper loaded: lang_helper
INFO - 2023-10-20 17:58:55 --> Helper loaded: security_helper
INFO - 2023-10-20 17:58:55 --> Helper loaded: cookie_helper
INFO - 2023-10-20 17:58:55 --> Database Driver Class Initialized
INFO - 2023-10-20 17:58:55 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-20 17:58:55 --> Parser Class Initialized
INFO - 2023-10-20 17:58:55 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-20 17:58:55 --> Pagination Class Initialized
INFO - 2023-10-20 17:58:55 --> Form Validation Class Initialized
INFO - 2023-10-20 17:58:55 --> Controller Class Initialized
INFO - 2023-10-20 17:58:55 --> Model Class Initialized
DEBUG - 2023-10-20 17:58:55 --> Session class already loaded. Second attempt ignored.
ERROR - 2023-10-20 17:58:56 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-20 17:58:56 --> Config Class Initialized
INFO - 2023-10-20 17:58:56 --> Hooks Class Initialized
DEBUG - 2023-10-20 17:58:56 --> UTF-8 Support Enabled
INFO - 2023-10-20 17:58:56 --> Utf8 Class Initialized
INFO - 2023-10-20 17:58:56 --> URI Class Initialized
INFO - 2023-10-20 17:58:56 --> Router Class Initialized
INFO - 2023-10-20 17:58:56 --> Output Class Initialized
INFO - 2023-10-20 17:58:56 --> Security Class Initialized
DEBUG - 2023-10-20 17:58:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-20 17:58:56 --> Input Class Initialized
INFO - 2023-10-20 17:58:56 --> Language Class Initialized
INFO - 2023-10-20 17:58:56 --> Loader Class Initialized
INFO - 2023-10-20 17:58:56 --> Helper loaded: url_helper
INFO - 2023-10-20 17:58:56 --> Helper loaded: file_helper
INFO - 2023-10-20 17:58:56 --> Helper loaded: html_helper
INFO - 2023-10-20 17:58:56 --> Helper loaded: text_helper
INFO - 2023-10-20 17:58:56 --> Helper loaded: form_helper
INFO - 2023-10-20 17:58:56 --> Helper loaded: lang_helper
INFO - 2023-10-20 17:58:56 --> Helper loaded: security_helper
INFO - 2023-10-20 17:58:56 --> Helper loaded: cookie_helper
INFO - 2023-10-20 17:58:56 --> Database Driver Class Initialized
INFO - 2023-10-20 17:58:56 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-20 17:58:56 --> Parser Class Initialized
INFO - 2023-10-20 17:58:56 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-20 17:58:56 --> Pagination Class Initialized
INFO - 2023-10-20 17:58:56 --> Form Validation Class Initialized
INFO - 2023-10-20 17:58:56 --> Controller Class Initialized
INFO - 2023-10-20 17:58:56 --> Model Class Initialized
DEBUG - 2023-10-20 17:58:56 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-20 17:58:56 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2023-10-20 17:58:56 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-10-20 17:58:56 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-10-20 17:58:56 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-10-20 17:58:56 --> Model Class Initialized
INFO - 2023-10-20 17:58:56 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-10-20 17:58:56 --> Final output sent to browser
DEBUG - 2023-10-20 17:58:56 --> Total execution time: 0.0345
ERROR - 2023-10-20 17:59:11 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-20 17:59:11 --> Config Class Initialized
INFO - 2023-10-20 17:59:11 --> Hooks Class Initialized
DEBUG - 2023-10-20 17:59:11 --> UTF-8 Support Enabled
INFO - 2023-10-20 17:59:11 --> Utf8 Class Initialized
INFO - 2023-10-20 17:59:11 --> URI Class Initialized
INFO - 2023-10-20 17:59:11 --> Router Class Initialized
INFO - 2023-10-20 17:59:11 --> Output Class Initialized
INFO - 2023-10-20 17:59:11 --> Security Class Initialized
DEBUG - 2023-10-20 17:59:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-20 17:59:11 --> Input Class Initialized
INFO - 2023-10-20 17:59:11 --> Language Class Initialized
INFO - 2023-10-20 17:59:11 --> Loader Class Initialized
INFO - 2023-10-20 17:59:11 --> Helper loaded: url_helper
INFO - 2023-10-20 17:59:11 --> Helper loaded: file_helper
INFO - 2023-10-20 17:59:11 --> Helper loaded: html_helper
INFO - 2023-10-20 17:59:11 --> Helper loaded: text_helper
INFO - 2023-10-20 17:59:11 --> Helper loaded: form_helper
INFO - 2023-10-20 17:59:11 --> Helper loaded: lang_helper
INFO - 2023-10-20 17:59:11 --> Helper loaded: security_helper
INFO - 2023-10-20 17:59:11 --> Helper loaded: cookie_helper
INFO - 2023-10-20 17:59:11 --> Database Driver Class Initialized
INFO - 2023-10-20 17:59:12 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-20 17:59:12 --> Parser Class Initialized
INFO - 2023-10-20 17:59:12 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-20 17:59:12 --> Pagination Class Initialized
INFO - 2023-10-20 17:59:12 --> Form Validation Class Initialized
INFO - 2023-10-20 17:59:12 --> Controller Class Initialized
INFO - 2023-10-20 17:59:12 --> Model Class Initialized
DEBUG - 2023-10-20 17:59:12 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-20 17:59:12 --> Model Class Initialized
INFO - 2023-10-20 17:59:12 --> Final output sent to browser
DEBUG - 2023-10-20 17:59:12 --> Total execution time: 0.0222
ERROR - 2023-10-20 17:59:17 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-20 17:59:17 --> Config Class Initialized
INFO - 2023-10-20 17:59:17 --> Hooks Class Initialized
DEBUG - 2023-10-20 17:59:17 --> UTF-8 Support Enabled
INFO - 2023-10-20 17:59:17 --> Utf8 Class Initialized
INFO - 2023-10-20 17:59:17 --> URI Class Initialized
INFO - 2023-10-20 17:59:17 --> Router Class Initialized
INFO - 2023-10-20 17:59:17 --> Output Class Initialized
INFO - 2023-10-20 17:59:17 --> Security Class Initialized
DEBUG - 2023-10-20 17:59:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-20 17:59:17 --> Input Class Initialized
INFO - 2023-10-20 17:59:17 --> Language Class Initialized
INFO - 2023-10-20 17:59:17 --> Loader Class Initialized
INFO - 2023-10-20 17:59:17 --> Helper loaded: url_helper
INFO - 2023-10-20 17:59:17 --> Helper loaded: file_helper
INFO - 2023-10-20 17:59:17 --> Helper loaded: html_helper
INFO - 2023-10-20 17:59:17 --> Helper loaded: text_helper
INFO - 2023-10-20 17:59:17 --> Helper loaded: form_helper
INFO - 2023-10-20 17:59:17 --> Helper loaded: lang_helper
INFO - 2023-10-20 17:59:17 --> Helper loaded: security_helper
INFO - 2023-10-20 17:59:17 --> Helper loaded: cookie_helper
INFO - 2023-10-20 17:59:17 --> Database Driver Class Initialized
INFO - 2023-10-20 17:59:17 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-20 17:59:17 --> Parser Class Initialized
INFO - 2023-10-20 17:59:17 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-20 17:59:17 --> Pagination Class Initialized
INFO - 2023-10-20 17:59:17 --> Form Validation Class Initialized
INFO - 2023-10-20 17:59:17 --> Controller Class Initialized
INFO - 2023-10-20 17:59:17 --> Model Class Initialized
DEBUG - 2023-10-20 17:59:17 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-20 17:59:17 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2023-10-20 17:59:17 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-10-20 17:59:17 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-10-20 17:59:17 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-10-20 17:59:17 --> Model Class Initialized
INFO - 2023-10-20 17:59:17 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-10-20 17:59:17 --> Final output sent to browser
DEBUG - 2023-10-20 17:59:17 --> Total execution time: 0.0279
ERROR - 2023-10-20 17:59:33 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-20 17:59:33 --> Config Class Initialized
INFO - 2023-10-20 17:59:33 --> Hooks Class Initialized
DEBUG - 2023-10-20 17:59:33 --> UTF-8 Support Enabled
INFO - 2023-10-20 17:59:33 --> Utf8 Class Initialized
INFO - 2023-10-20 17:59:33 --> URI Class Initialized
INFO - 2023-10-20 17:59:33 --> Router Class Initialized
INFO - 2023-10-20 17:59:33 --> Output Class Initialized
INFO - 2023-10-20 17:59:33 --> Security Class Initialized
DEBUG - 2023-10-20 17:59:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-20 17:59:33 --> Input Class Initialized
INFO - 2023-10-20 17:59:33 --> Language Class Initialized
INFO - 2023-10-20 17:59:33 --> Loader Class Initialized
INFO - 2023-10-20 17:59:33 --> Helper loaded: url_helper
INFO - 2023-10-20 17:59:33 --> Helper loaded: file_helper
INFO - 2023-10-20 17:59:33 --> Helper loaded: html_helper
INFO - 2023-10-20 17:59:33 --> Helper loaded: text_helper
INFO - 2023-10-20 17:59:33 --> Helper loaded: form_helper
INFO - 2023-10-20 17:59:33 --> Helper loaded: lang_helper
INFO - 2023-10-20 17:59:33 --> Helper loaded: security_helper
INFO - 2023-10-20 17:59:33 --> Helper loaded: cookie_helper
INFO - 2023-10-20 17:59:33 --> Database Driver Class Initialized
INFO - 2023-10-20 17:59:33 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-20 17:59:33 --> Parser Class Initialized
INFO - 2023-10-20 17:59:33 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-20 17:59:33 --> Pagination Class Initialized
INFO - 2023-10-20 17:59:33 --> Form Validation Class Initialized
INFO - 2023-10-20 17:59:33 --> Controller Class Initialized
INFO - 2023-10-20 17:59:33 --> Model Class Initialized
DEBUG - 2023-10-20 17:59:33 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-20 17:59:33 --> Model Class Initialized
INFO - 2023-10-20 17:59:33 --> Final output sent to browser
DEBUG - 2023-10-20 17:59:33 --> Total execution time: 0.0190
ERROR - 2023-10-20 17:59:33 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-20 17:59:33 --> Config Class Initialized
INFO - 2023-10-20 17:59:33 --> Hooks Class Initialized
DEBUG - 2023-10-20 17:59:33 --> UTF-8 Support Enabled
INFO - 2023-10-20 17:59:33 --> Utf8 Class Initialized
INFO - 2023-10-20 17:59:33 --> URI Class Initialized
INFO - 2023-10-20 17:59:33 --> Router Class Initialized
INFO - 2023-10-20 17:59:33 --> Output Class Initialized
INFO - 2023-10-20 17:59:33 --> Security Class Initialized
DEBUG - 2023-10-20 17:59:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-20 17:59:33 --> Input Class Initialized
INFO - 2023-10-20 17:59:33 --> Language Class Initialized
INFO - 2023-10-20 17:59:33 --> Loader Class Initialized
INFO - 2023-10-20 17:59:33 --> Helper loaded: url_helper
INFO - 2023-10-20 17:59:33 --> Helper loaded: file_helper
INFO - 2023-10-20 17:59:33 --> Helper loaded: html_helper
INFO - 2023-10-20 17:59:33 --> Helper loaded: text_helper
INFO - 2023-10-20 17:59:33 --> Helper loaded: form_helper
INFO - 2023-10-20 17:59:33 --> Helper loaded: lang_helper
INFO - 2023-10-20 17:59:33 --> Helper loaded: security_helper
INFO - 2023-10-20 17:59:33 --> Helper loaded: cookie_helper
INFO - 2023-10-20 17:59:33 --> Database Driver Class Initialized
INFO - 2023-10-20 17:59:33 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-20 17:59:33 --> Parser Class Initialized
INFO - 2023-10-20 17:59:33 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-20 17:59:33 --> Pagination Class Initialized
INFO - 2023-10-20 17:59:33 --> Form Validation Class Initialized
INFO - 2023-10-20 17:59:33 --> Controller Class Initialized
INFO - 2023-10-20 17:59:33 --> Model Class Initialized
DEBUG - 2023-10-20 17:59:33 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-20 17:59:34 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2023-10-20 17:59:34 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-10-20 17:59:34 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-10-20 17:59:34 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-10-20 17:59:34 --> Model Class Initialized
INFO - 2023-10-20 17:59:34 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-10-20 17:59:34 --> Final output sent to browser
DEBUG - 2023-10-20 17:59:34 --> Total execution time: 0.0298
ERROR - 2023-10-20 17:59:49 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-20 17:59:49 --> Config Class Initialized
INFO - 2023-10-20 17:59:49 --> Hooks Class Initialized
DEBUG - 2023-10-20 17:59:49 --> UTF-8 Support Enabled
INFO - 2023-10-20 17:59:49 --> Utf8 Class Initialized
INFO - 2023-10-20 17:59:49 --> URI Class Initialized
INFO - 2023-10-20 17:59:49 --> Router Class Initialized
INFO - 2023-10-20 17:59:49 --> Output Class Initialized
INFO - 2023-10-20 17:59:49 --> Security Class Initialized
DEBUG - 2023-10-20 17:59:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-20 17:59:49 --> Input Class Initialized
INFO - 2023-10-20 17:59:49 --> Language Class Initialized
INFO - 2023-10-20 17:59:49 --> Loader Class Initialized
INFO - 2023-10-20 17:59:49 --> Helper loaded: url_helper
INFO - 2023-10-20 17:59:49 --> Helper loaded: file_helper
INFO - 2023-10-20 17:59:49 --> Helper loaded: html_helper
INFO - 2023-10-20 17:59:49 --> Helper loaded: text_helper
INFO - 2023-10-20 17:59:49 --> Helper loaded: form_helper
INFO - 2023-10-20 17:59:49 --> Helper loaded: lang_helper
INFO - 2023-10-20 17:59:49 --> Helper loaded: security_helper
INFO - 2023-10-20 17:59:49 --> Helper loaded: cookie_helper
INFO - 2023-10-20 17:59:49 --> Database Driver Class Initialized
INFO - 2023-10-20 17:59:49 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-20 17:59:49 --> Parser Class Initialized
INFO - 2023-10-20 17:59:49 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-20 17:59:49 --> Pagination Class Initialized
INFO - 2023-10-20 17:59:50 --> Form Validation Class Initialized
INFO - 2023-10-20 17:59:50 --> Controller Class Initialized
INFO - 2023-10-20 17:59:50 --> Model Class Initialized
DEBUG - 2023-10-20 17:59:50 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-20 17:59:50 --> Model Class Initialized
INFO - 2023-10-20 17:59:50 --> Final output sent to browser
DEBUG - 2023-10-20 17:59:50 --> Total execution time: 0.0195
ERROR - 2023-10-20 17:59:50 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-20 17:59:50 --> Config Class Initialized
INFO - 2023-10-20 17:59:50 --> Hooks Class Initialized
DEBUG - 2023-10-20 17:59:50 --> UTF-8 Support Enabled
INFO - 2023-10-20 17:59:50 --> Utf8 Class Initialized
INFO - 2023-10-20 17:59:50 --> URI Class Initialized
DEBUG - 2023-10-20 17:59:50 --> No URI present. Default controller set.
INFO - 2023-10-20 17:59:50 --> Router Class Initialized
INFO - 2023-10-20 17:59:50 --> Output Class Initialized
INFO - 2023-10-20 17:59:50 --> Security Class Initialized
DEBUG - 2023-10-20 17:59:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-20 17:59:50 --> Input Class Initialized
INFO - 2023-10-20 17:59:50 --> Language Class Initialized
INFO - 2023-10-20 17:59:50 --> Loader Class Initialized
INFO - 2023-10-20 17:59:50 --> Helper loaded: url_helper
INFO - 2023-10-20 17:59:50 --> Helper loaded: file_helper
INFO - 2023-10-20 17:59:50 --> Helper loaded: html_helper
INFO - 2023-10-20 17:59:50 --> Helper loaded: text_helper
INFO - 2023-10-20 17:59:50 --> Helper loaded: form_helper
INFO - 2023-10-20 17:59:50 --> Helper loaded: lang_helper
INFO - 2023-10-20 17:59:50 --> Helper loaded: security_helper
INFO - 2023-10-20 17:59:50 --> Helper loaded: cookie_helper
INFO - 2023-10-20 17:59:50 --> Database Driver Class Initialized
INFO - 2023-10-20 17:59:50 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-20 17:59:50 --> Parser Class Initialized
INFO - 2023-10-20 17:59:50 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-20 17:59:50 --> Pagination Class Initialized
INFO - 2023-10-20 17:59:50 --> Form Validation Class Initialized
INFO - 2023-10-20 17:59:50 --> Controller Class Initialized
INFO - 2023-10-20 17:59:50 --> Model Class Initialized
DEBUG - 2023-10-20 17:59:50 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-20 17:59:50 --> Model Class Initialized
DEBUG - 2023-10-20 17:59:50 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-20 17:59:50 --> Model Class Initialized
INFO - 2023-10-20 17:59:50 --> Model Class Initialized
INFO - 2023-10-20 17:59:50 --> Model Class Initialized
INFO - 2023-10-20 17:59:50 --> Model Class Initialized
DEBUG - 2023-10-20 17:59:50 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-10-20 17:59:50 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-20 17:59:50 --> Model Class Initialized
INFO - 2023-10-20 17:59:50 --> Model Class Initialized
INFO - 2023-10-20 17:59:50 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-10-20 17:59:50 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-10-20 17:59:50 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-10-20 17:59:50 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-10-20 17:59:50 --> Model Class Initialized
INFO - 2023-10-20 17:59:50 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-10-20 17:59:50 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-10-20 17:59:50 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-10-20 17:59:50 --> Final output sent to browser
DEBUG - 2023-10-20 17:59:50 --> Total execution time: 0.3512
ERROR - 2023-10-20 18:00:27 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-20 18:00:27 --> Config Class Initialized
INFO - 2023-10-20 18:00:27 --> Hooks Class Initialized
DEBUG - 2023-10-20 18:00:27 --> UTF-8 Support Enabled
INFO - 2023-10-20 18:00:27 --> Utf8 Class Initialized
INFO - 2023-10-20 18:00:27 --> URI Class Initialized
INFO - 2023-10-20 18:00:27 --> Router Class Initialized
INFO - 2023-10-20 18:00:27 --> Output Class Initialized
INFO - 2023-10-20 18:00:27 --> Security Class Initialized
DEBUG - 2023-10-20 18:00:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-20 18:00:27 --> Input Class Initialized
INFO - 2023-10-20 18:00:27 --> Language Class Initialized
INFO - 2023-10-20 18:00:27 --> Loader Class Initialized
INFO - 2023-10-20 18:00:27 --> Helper loaded: url_helper
INFO - 2023-10-20 18:00:27 --> Helper loaded: file_helper
INFO - 2023-10-20 18:00:27 --> Helper loaded: html_helper
INFO - 2023-10-20 18:00:27 --> Helper loaded: text_helper
INFO - 2023-10-20 18:00:27 --> Helper loaded: form_helper
INFO - 2023-10-20 18:00:27 --> Helper loaded: lang_helper
INFO - 2023-10-20 18:00:27 --> Helper loaded: security_helper
INFO - 2023-10-20 18:00:27 --> Helper loaded: cookie_helper
INFO - 2023-10-20 18:00:27 --> Database Driver Class Initialized
INFO - 2023-10-20 18:00:27 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-20 18:00:27 --> Parser Class Initialized
INFO - 2023-10-20 18:00:27 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-20 18:00:27 --> Pagination Class Initialized
INFO - 2023-10-20 18:00:27 --> Form Validation Class Initialized
INFO - 2023-10-20 18:00:27 --> Controller Class Initialized
DEBUG - 2023-10-20 18:00:27 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-10-20 18:00:27 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-20 18:00:27 --> Model Class Initialized
INFO - 2023-10-20 18:00:27 --> Final output sent to browser
DEBUG - 2023-10-20 18:00:27 --> Total execution time: 0.0165
ERROR - 2023-10-20 18:00:42 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-20 18:00:42 --> Config Class Initialized
INFO - 2023-10-20 18:00:42 --> Hooks Class Initialized
DEBUG - 2023-10-20 18:00:42 --> UTF-8 Support Enabled
INFO - 2023-10-20 18:00:42 --> Utf8 Class Initialized
INFO - 2023-10-20 18:00:42 --> URI Class Initialized
INFO - 2023-10-20 18:00:42 --> Router Class Initialized
INFO - 2023-10-20 18:00:42 --> Output Class Initialized
INFO - 2023-10-20 18:00:42 --> Security Class Initialized
DEBUG - 2023-10-20 18:00:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-20 18:00:42 --> Input Class Initialized
INFO - 2023-10-20 18:00:42 --> Language Class Initialized
INFO - 2023-10-20 18:00:42 --> Loader Class Initialized
INFO - 2023-10-20 18:00:42 --> Helper loaded: url_helper
INFO - 2023-10-20 18:00:42 --> Helper loaded: file_helper
INFO - 2023-10-20 18:00:42 --> Helper loaded: html_helper
INFO - 2023-10-20 18:00:42 --> Helper loaded: text_helper
INFO - 2023-10-20 18:00:42 --> Helper loaded: form_helper
INFO - 2023-10-20 18:00:42 --> Helper loaded: lang_helper
INFO - 2023-10-20 18:00:42 --> Helper loaded: security_helper
INFO - 2023-10-20 18:00:42 --> Helper loaded: cookie_helper
INFO - 2023-10-20 18:00:42 --> Database Driver Class Initialized
INFO - 2023-10-20 18:00:42 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-20 18:00:42 --> Parser Class Initialized
INFO - 2023-10-20 18:00:42 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-20 18:00:42 --> Pagination Class Initialized
INFO - 2023-10-20 18:00:42 --> Form Validation Class Initialized
INFO - 2023-10-20 18:00:42 --> Controller Class Initialized
DEBUG - 2023-10-20 18:00:42 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-10-20 18:00:42 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-20 18:00:42 --> Model Class Initialized
DEBUG - 2023-10-20 18:00:42 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-20 18:00:42 --> Model Class Initialized
DEBUG - 2023-10-20 18:00:42 --> Lcustomer class already loaded. Second attempt ignored.
INFO - 2023-10-20 18:00:42 --> Model Class Initialized
INFO - 2023-10-20 18:00:42 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/customer/customer.php
DEBUG - 2023-10-20 18:00:42 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-10-20 18:00:42 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-10-20 18:00:42 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-10-20 18:00:42 --> Model Class Initialized
INFO - 2023-10-20 18:00:42 --> Model Class Initialized
INFO - 2023-10-20 18:00:42 --> Model Class Initialized
INFO - 2023-10-20 18:00:42 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-10-20 18:00:42 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-10-20 18:00:42 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-10-20 18:00:42 --> Final output sent to browser
DEBUG - 2023-10-20 18:00:42 --> Total execution time: 0.1995
ERROR - 2023-10-20 18:00:44 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-20 18:00:44 --> Config Class Initialized
INFO - 2023-10-20 18:00:44 --> Hooks Class Initialized
DEBUG - 2023-10-20 18:00:44 --> UTF-8 Support Enabled
INFO - 2023-10-20 18:00:44 --> Utf8 Class Initialized
INFO - 2023-10-20 18:00:44 --> URI Class Initialized
INFO - 2023-10-20 18:00:44 --> Router Class Initialized
INFO - 2023-10-20 18:00:44 --> Output Class Initialized
INFO - 2023-10-20 18:00:44 --> Security Class Initialized
DEBUG - 2023-10-20 18:00:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-20 18:00:44 --> Input Class Initialized
INFO - 2023-10-20 18:00:44 --> Language Class Initialized
INFO - 2023-10-20 18:00:44 --> Loader Class Initialized
INFO - 2023-10-20 18:00:44 --> Helper loaded: url_helper
INFO - 2023-10-20 18:00:44 --> Helper loaded: file_helper
INFO - 2023-10-20 18:00:44 --> Helper loaded: html_helper
INFO - 2023-10-20 18:00:44 --> Helper loaded: text_helper
INFO - 2023-10-20 18:00:44 --> Helper loaded: form_helper
INFO - 2023-10-20 18:00:44 --> Helper loaded: lang_helper
INFO - 2023-10-20 18:00:44 --> Helper loaded: security_helper
INFO - 2023-10-20 18:00:44 --> Helper loaded: cookie_helper
INFO - 2023-10-20 18:00:44 --> Database Driver Class Initialized
INFO - 2023-10-20 18:00:44 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-20 18:00:44 --> Parser Class Initialized
INFO - 2023-10-20 18:00:44 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-20 18:00:44 --> Pagination Class Initialized
INFO - 2023-10-20 18:00:44 --> Form Validation Class Initialized
INFO - 2023-10-20 18:00:44 --> Controller Class Initialized
DEBUG - 2023-10-20 18:00:44 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-10-20 18:00:44 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-20 18:00:44 --> Model Class Initialized
DEBUG - 2023-10-20 18:00:44 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-20 18:00:44 --> Model Class Initialized
DEBUG - 2023-10-20 18:00:44 --> Lcustomer class already loaded. Second attempt ignored.
INFO - 2023-10-20 18:00:44 --> Model Class Initialized
INFO - 2023-10-20 18:00:44 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/customer/customer.php
DEBUG - 2023-10-20 18:00:44 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-10-20 18:00:44 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-10-20 18:00:44 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-10-20 18:00:44 --> Model Class Initialized
INFO - 2023-10-20 18:00:44 --> Model Class Initialized
INFO - 2023-10-20 18:00:44 --> Model Class Initialized
INFO - 2023-10-20 18:00:45 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-10-20 18:00:45 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-10-20 18:00:45 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-10-20 18:00:45 --> Final output sent to browser
DEBUG - 2023-10-20 18:00:45 --> Total execution time: 0.1970
ERROR - 2023-10-20 18:00:46 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-20 18:00:46 --> Config Class Initialized
INFO - 2023-10-20 18:00:46 --> Hooks Class Initialized
DEBUG - 2023-10-20 18:00:46 --> UTF-8 Support Enabled
INFO - 2023-10-20 18:00:46 --> Utf8 Class Initialized
INFO - 2023-10-20 18:00:46 --> URI Class Initialized
INFO - 2023-10-20 18:00:46 --> Router Class Initialized
INFO - 2023-10-20 18:00:46 --> Output Class Initialized
INFO - 2023-10-20 18:00:46 --> Security Class Initialized
DEBUG - 2023-10-20 18:00:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-20 18:00:46 --> Input Class Initialized
INFO - 2023-10-20 18:00:46 --> Language Class Initialized
INFO - 2023-10-20 18:00:46 --> Loader Class Initialized
INFO - 2023-10-20 18:00:46 --> Helper loaded: url_helper
INFO - 2023-10-20 18:00:46 --> Helper loaded: file_helper
INFO - 2023-10-20 18:00:46 --> Helper loaded: html_helper
INFO - 2023-10-20 18:00:46 --> Helper loaded: text_helper
INFO - 2023-10-20 18:00:46 --> Helper loaded: form_helper
INFO - 2023-10-20 18:00:46 --> Helper loaded: lang_helper
INFO - 2023-10-20 18:00:46 --> Helper loaded: security_helper
INFO - 2023-10-20 18:00:46 --> Helper loaded: cookie_helper
INFO - 2023-10-20 18:00:46 --> Database Driver Class Initialized
INFO - 2023-10-20 18:00:46 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-20 18:00:46 --> Parser Class Initialized
INFO - 2023-10-20 18:00:46 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-20 18:00:46 --> Pagination Class Initialized
INFO - 2023-10-20 18:00:46 --> Form Validation Class Initialized
INFO - 2023-10-20 18:00:46 --> Controller Class Initialized
DEBUG - 2023-10-20 18:00:46 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-10-20 18:00:46 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-20 18:00:46 --> Model Class Initialized
DEBUG - 2023-10-20 18:00:46 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-20 18:00:46 --> Model Class Initialized
DEBUG - 2023-10-20 18:00:46 --> Lcustomer class already loaded. Second attempt ignored.
INFO - 2023-10-20 18:00:46 --> Model Class Initialized
INFO - 2023-10-20 18:00:46 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/customer/customer.php
DEBUG - 2023-10-20 18:00:46 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-10-20 18:00:46 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-10-20 18:00:46 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-10-20 18:00:46 --> Model Class Initialized
INFO - 2023-10-20 18:00:46 --> Model Class Initialized
INFO - 2023-10-20 18:00:46 --> Model Class Initialized
INFO - 2023-10-20 18:00:46 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-10-20 18:00:46 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-10-20 18:00:46 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-10-20 18:00:46 --> Final output sent to browser
DEBUG - 2023-10-20 18:00:46 --> Total execution time: 0.2039
ERROR - 2023-10-20 18:00:52 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-20 18:00:52 --> Config Class Initialized
INFO - 2023-10-20 18:00:52 --> Hooks Class Initialized
DEBUG - 2023-10-20 18:00:52 --> UTF-8 Support Enabled
INFO - 2023-10-20 18:00:52 --> Utf8 Class Initialized
INFO - 2023-10-20 18:00:52 --> URI Class Initialized
INFO - 2023-10-20 18:00:52 --> Router Class Initialized
INFO - 2023-10-20 18:00:52 --> Output Class Initialized
INFO - 2023-10-20 18:00:52 --> Security Class Initialized
DEBUG - 2023-10-20 18:00:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-20 18:00:52 --> Input Class Initialized
INFO - 2023-10-20 18:00:52 --> Language Class Initialized
INFO - 2023-10-20 18:00:52 --> Loader Class Initialized
INFO - 2023-10-20 18:00:52 --> Helper loaded: url_helper
INFO - 2023-10-20 18:00:52 --> Helper loaded: file_helper
INFO - 2023-10-20 18:00:52 --> Helper loaded: html_helper
INFO - 2023-10-20 18:00:52 --> Helper loaded: text_helper
INFO - 2023-10-20 18:00:52 --> Helper loaded: form_helper
INFO - 2023-10-20 18:00:52 --> Helper loaded: lang_helper
INFO - 2023-10-20 18:00:52 --> Helper loaded: security_helper
INFO - 2023-10-20 18:00:52 --> Helper loaded: cookie_helper
INFO - 2023-10-20 18:00:52 --> Database Driver Class Initialized
INFO - 2023-10-20 18:00:52 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-20 18:00:52 --> Parser Class Initialized
INFO - 2023-10-20 18:00:52 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-20 18:00:52 --> Pagination Class Initialized
INFO - 2023-10-20 18:00:52 --> Form Validation Class Initialized
INFO - 2023-10-20 18:00:52 --> Controller Class Initialized
DEBUG - 2023-10-20 18:00:52 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-10-20 18:00:52 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-20 18:00:52 --> Model Class Initialized
DEBUG - 2023-10-20 18:00:52 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-20 18:00:52 --> Model Class Initialized
INFO - 2023-10-20 18:00:52 --> Final output sent to browser
DEBUG - 2023-10-20 18:00:52 --> Total execution time: 0.0323
ERROR - 2023-10-20 18:08:12 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-20 18:08:12 --> Config Class Initialized
INFO - 2023-10-20 18:08:12 --> Hooks Class Initialized
DEBUG - 2023-10-20 18:08:12 --> UTF-8 Support Enabled
INFO - 2023-10-20 18:08:12 --> Utf8 Class Initialized
INFO - 2023-10-20 18:08:12 --> URI Class Initialized
DEBUG - 2023-10-20 18:08:12 --> No URI present. Default controller set.
INFO - 2023-10-20 18:08:12 --> Router Class Initialized
INFO - 2023-10-20 18:08:12 --> Output Class Initialized
INFO - 2023-10-20 18:08:12 --> Security Class Initialized
DEBUG - 2023-10-20 18:08:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-20 18:08:12 --> Input Class Initialized
INFO - 2023-10-20 18:08:12 --> Language Class Initialized
INFO - 2023-10-20 18:08:12 --> Loader Class Initialized
INFO - 2023-10-20 18:08:12 --> Helper loaded: url_helper
INFO - 2023-10-20 18:08:12 --> Helper loaded: file_helper
INFO - 2023-10-20 18:08:12 --> Helper loaded: html_helper
INFO - 2023-10-20 18:08:12 --> Helper loaded: text_helper
INFO - 2023-10-20 18:08:12 --> Helper loaded: form_helper
INFO - 2023-10-20 18:08:12 --> Helper loaded: lang_helper
INFO - 2023-10-20 18:08:12 --> Helper loaded: security_helper
INFO - 2023-10-20 18:08:12 --> Helper loaded: cookie_helper
INFO - 2023-10-20 18:08:12 --> Database Driver Class Initialized
INFO - 2023-10-20 18:08:12 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-20 18:08:12 --> Parser Class Initialized
INFO - 2023-10-20 18:08:12 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-20 18:08:12 --> Pagination Class Initialized
INFO - 2023-10-20 18:08:12 --> Form Validation Class Initialized
INFO - 2023-10-20 18:08:12 --> Controller Class Initialized
INFO - 2023-10-20 18:08:12 --> Model Class Initialized
DEBUG - 2023-10-20 18:08:12 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-20 18:08:12 --> Model Class Initialized
DEBUG - 2023-10-20 18:08:12 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-20 18:08:12 --> Model Class Initialized
INFO - 2023-10-20 18:08:12 --> Model Class Initialized
INFO - 2023-10-20 18:08:12 --> Model Class Initialized
INFO - 2023-10-20 18:08:12 --> Model Class Initialized
DEBUG - 2023-10-20 18:08:12 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-10-20 18:08:12 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-20 18:08:12 --> Model Class Initialized
INFO - 2023-10-20 18:08:12 --> Model Class Initialized
INFO - 2023-10-20 18:08:12 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-10-20 18:08:12 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-10-20 18:08:12 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-10-20 18:08:12 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-10-20 18:08:12 --> Model Class Initialized
INFO - 2023-10-20 18:08:12 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-10-20 18:08:12 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-10-20 18:08:12 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-10-20 18:08:12 --> Final output sent to browser
DEBUG - 2023-10-20 18:08:12 --> Total execution time: 0.3924
ERROR - 2023-10-20 18:08:25 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-20 18:08:25 --> Config Class Initialized
INFO - 2023-10-20 18:08:25 --> Hooks Class Initialized
DEBUG - 2023-10-20 18:08:25 --> UTF-8 Support Enabled
INFO - 2023-10-20 18:08:25 --> Utf8 Class Initialized
INFO - 2023-10-20 18:08:25 --> URI Class Initialized
INFO - 2023-10-20 18:08:25 --> Router Class Initialized
INFO - 2023-10-20 18:08:25 --> Output Class Initialized
INFO - 2023-10-20 18:08:25 --> Security Class Initialized
DEBUG - 2023-10-20 18:08:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-20 18:08:25 --> Input Class Initialized
INFO - 2023-10-20 18:08:25 --> Language Class Initialized
INFO - 2023-10-20 18:08:25 --> Loader Class Initialized
INFO - 2023-10-20 18:08:25 --> Helper loaded: url_helper
INFO - 2023-10-20 18:08:25 --> Helper loaded: file_helper
INFO - 2023-10-20 18:08:25 --> Helper loaded: html_helper
INFO - 2023-10-20 18:08:25 --> Helper loaded: text_helper
INFO - 2023-10-20 18:08:25 --> Helper loaded: form_helper
INFO - 2023-10-20 18:08:25 --> Helper loaded: lang_helper
INFO - 2023-10-20 18:08:25 --> Helper loaded: security_helper
INFO - 2023-10-20 18:08:25 --> Helper loaded: cookie_helper
INFO - 2023-10-20 18:08:25 --> Database Driver Class Initialized
INFO - 2023-10-20 18:08:25 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-20 18:08:25 --> Parser Class Initialized
INFO - 2023-10-20 18:08:25 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-20 18:08:25 --> Pagination Class Initialized
INFO - 2023-10-20 18:08:25 --> Form Validation Class Initialized
INFO - 2023-10-20 18:08:25 --> Controller Class Initialized
INFO - 2023-10-20 18:08:25 --> Model Class Initialized
INFO - 2023-10-20 18:08:25 --> Model Class Initialized
INFO - 2023-10-20 18:08:25 --> Model Class Initialized
INFO - 2023-10-20 18:08:25 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/report/stock_report_batch_wise.php
DEBUG - 2023-10-20 18:08:25 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-10-20 18:08:25 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-10-20 18:08:25 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-10-20 18:08:25 --> Model Class Initialized
INFO - 2023-10-20 18:08:26 --> Model Class Initialized
INFO - 2023-10-20 18:08:26 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-10-20 18:08:26 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-10-20 18:08:26 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-10-20 18:08:26 --> Final output sent to browser
DEBUG - 2023-10-20 18:08:26 --> Total execution time: 0.2038
ERROR - 2023-10-20 18:08:27 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-20 18:08:27 --> Config Class Initialized
INFO - 2023-10-20 18:08:27 --> Hooks Class Initialized
DEBUG - 2023-10-20 18:08:27 --> UTF-8 Support Enabled
INFO - 2023-10-20 18:08:27 --> Utf8 Class Initialized
INFO - 2023-10-20 18:08:27 --> URI Class Initialized
INFO - 2023-10-20 18:08:27 --> Router Class Initialized
INFO - 2023-10-20 18:08:27 --> Output Class Initialized
INFO - 2023-10-20 18:08:27 --> Security Class Initialized
DEBUG - 2023-10-20 18:08:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-20 18:08:27 --> Input Class Initialized
INFO - 2023-10-20 18:08:27 --> Language Class Initialized
INFO - 2023-10-20 18:08:27 --> Loader Class Initialized
INFO - 2023-10-20 18:08:27 --> Helper loaded: url_helper
INFO - 2023-10-20 18:08:27 --> Helper loaded: file_helper
INFO - 2023-10-20 18:08:27 --> Helper loaded: html_helper
INFO - 2023-10-20 18:08:27 --> Helper loaded: text_helper
INFO - 2023-10-20 18:08:27 --> Helper loaded: form_helper
INFO - 2023-10-20 18:08:27 --> Helper loaded: lang_helper
INFO - 2023-10-20 18:08:27 --> Helper loaded: security_helper
INFO - 2023-10-20 18:08:27 --> Helper loaded: cookie_helper
INFO - 2023-10-20 18:08:27 --> Database Driver Class Initialized
INFO - 2023-10-20 18:08:27 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-20 18:08:27 --> Parser Class Initialized
INFO - 2023-10-20 18:08:27 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-20 18:08:27 --> Pagination Class Initialized
INFO - 2023-10-20 18:08:27 --> Form Validation Class Initialized
INFO - 2023-10-20 18:08:27 --> Controller Class Initialized
INFO - 2023-10-20 18:08:27 --> Model Class Initialized
INFO - 2023-10-20 18:08:27 --> Model Class Initialized
INFO - 2023-10-20 18:08:27 --> Final output sent to browser
DEBUG - 2023-10-20 18:08:27 --> Total execution time: 0.0315
ERROR - 2023-10-20 18:08:37 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-20 18:08:37 --> Config Class Initialized
INFO - 2023-10-20 18:08:37 --> Hooks Class Initialized
DEBUG - 2023-10-20 18:08:37 --> UTF-8 Support Enabled
INFO - 2023-10-20 18:08:37 --> Utf8 Class Initialized
INFO - 2023-10-20 18:08:37 --> URI Class Initialized
DEBUG - 2023-10-20 18:08:37 --> No URI present. Default controller set.
INFO - 2023-10-20 18:08:37 --> Router Class Initialized
INFO - 2023-10-20 18:08:37 --> Output Class Initialized
INFO - 2023-10-20 18:08:37 --> Security Class Initialized
DEBUG - 2023-10-20 18:08:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-20 18:08:37 --> Input Class Initialized
INFO - 2023-10-20 18:08:37 --> Language Class Initialized
INFO - 2023-10-20 18:08:37 --> Loader Class Initialized
INFO - 2023-10-20 18:08:37 --> Helper loaded: url_helper
INFO - 2023-10-20 18:08:37 --> Helper loaded: file_helper
INFO - 2023-10-20 18:08:37 --> Helper loaded: html_helper
INFO - 2023-10-20 18:08:37 --> Helper loaded: text_helper
INFO - 2023-10-20 18:08:37 --> Helper loaded: form_helper
INFO - 2023-10-20 18:08:37 --> Helper loaded: lang_helper
INFO - 2023-10-20 18:08:37 --> Helper loaded: security_helper
INFO - 2023-10-20 18:08:37 --> Helper loaded: cookie_helper
INFO - 2023-10-20 18:08:37 --> Database Driver Class Initialized
INFO - 2023-10-20 18:08:37 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-20 18:08:37 --> Parser Class Initialized
INFO - 2023-10-20 18:08:37 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-20 18:08:37 --> Pagination Class Initialized
INFO - 2023-10-20 18:08:37 --> Form Validation Class Initialized
INFO - 2023-10-20 18:08:37 --> Controller Class Initialized
INFO - 2023-10-20 18:08:37 --> Model Class Initialized
DEBUG - 2023-10-20 18:08:37 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-20 18:08:37 --> Model Class Initialized
DEBUG - 2023-10-20 18:08:37 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-20 18:08:37 --> Model Class Initialized
INFO - 2023-10-20 18:08:37 --> Model Class Initialized
INFO - 2023-10-20 18:08:37 --> Model Class Initialized
INFO - 2023-10-20 18:08:37 --> Model Class Initialized
DEBUG - 2023-10-20 18:08:37 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-10-20 18:08:37 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-20 18:08:37 --> Model Class Initialized
INFO - 2023-10-20 18:08:37 --> Model Class Initialized
INFO - 2023-10-20 18:08:37 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-10-20 18:08:37 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-10-20 18:08:37 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-10-20 18:08:37 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-10-20 18:08:37 --> Model Class Initialized
INFO - 2023-10-20 18:08:37 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-10-20 18:08:37 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-10-20 18:08:37 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-10-20 18:08:37 --> Final output sent to browser
DEBUG - 2023-10-20 18:08:37 --> Total execution time: 0.3749
ERROR - 2023-10-20 18:09:27 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-20 18:09:27 --> Config Class Initialized
INFO - 2023-10-20 18:09:27 --> Hooks Class Initialized
DEBUG - 2023-10-20 18:09:27 --> UTF-8 Support Enabled
INFO - 2023-10-20 18:09:27 --> Utf8 Class Initialized
INFO - 2023-10-20 18:09:27 --> URI Class Initialized
INFO - 2023-10-20 18:09:27 --> Router Class Initialized
INFO - 2023-10-20 18:09:27 --> Output Class Initialized
INFO - 2023-10-20 18:09:27 --> Security Class Initialized
DEBUG - 2023-10-20 18:09:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-20 18:09:27 --> Input Class Initialized
INFO - 2023-10-20 18:09:27 --> Language Class Initialized
INFO - 2023-10-20 18:09:27 --> Loader Class Initialized
INFO - 2023-10-20 18:09:27 --> Helper loaded: url_helper
INFO - 2023-10-20 18:09:27 --> Helper loaded: file_helper
INFO - 2023-10-20 18:09:27 --> Helper loaded: html_helper
INFO - 2023-10-20 18:09:27 --> Helper loaded: text_helper
INFO - 2023-10-20 18:09:27 --> Helper loaded: form_helper
INFO - 2023-10-20 18:09:27 --> Helper loaded: lang_helper
INFO - 2023-10-20 18:09:27 --> Helper loaded: security_helper
INFO - 2023-10-20 18:09:27 --> Helper loaded: cookie_helper
INFO - 2023-10-20 18:09:27 --> Database Driver Class Initialized
INFO - 2023-10-20 18:09:27 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-20 18:09:27 --> Parser Class Initialized
INFO - 2023-10-20 18:09:27 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-20 18:09:27 --> Pagination Class Initialized
INFO - 2023-10-20 18:09:27 --> Form Validation Class Initialized
INFO - 2023-10-20 18:09:27 --> Controller Class Initialized
DEBUG - 2023-10-20 18:09:27 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-10-20 18:09:27 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-20 18:09:27 --> Model Class Initialized
INFO - 2023-10-20 18:09:27 --> Model Class Initialized
DEBUG - 2023-10-20 18:09:27 --> Lmr class already loaded. Second attempt ignored.
INFO - 2023-10-20 18:09:27 --> Model Class Initialized
INFO - 2023-10-20 18:09:27 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/mr/mr.php
DEBUG - 2023-10-20 18:09:27 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-10-20 18:09:27 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-10-20 18:09:27 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-10-20 18:09:27 --> Model Class Initialized
INFO - 2023-10-20 18:09:27 --> Model Class Initialized
INFO - 2023-10-20 18:09:27 --> Model Class Initialized
INFO - 2023-10-20 18:09:27 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-10-20 18:09:27 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-10-20 18:09:27 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-10-20 18:09:27 --> Final output sent to browser
DEBUG - 2023-10-20 18:09:27 --> Total execution time: 0.1881
ERROR - 2023-10-20 18:09:28 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-20 18:09:28 --> Config Class Initialized
INFO - 2023-10-20 18:09:28 --> Hooks Class Initialized
DEBUG - 2023-10-20 18:09:28 --> UTF-8 Support Enabled
INFO - 2023-10-20 18:09:28 --> Utf8 Class Initialized
INFO - 2023-10-20 18:09:28 --> URI Class Initialized
INFO - 2023-10-20 18:09:28 --> Router Class Initialized
INFO - 2023-10-20 18:09:28 --> Output Class Initialized
INFO - 2023-10-20 18:09:28 --> Security Class Initialized
DEBUG - 2023-10-20 18:09:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-20 18:09:28 --> Input Class Initialized
INFO - 2023-10-20 18:09:28 --> Language Class Initialized
INFO - 2023-10-20 18:09:28 --> Loader Class Initialized
INFO - 2023-10-20 18:09:28 --> Helper loaded: url_helper
INFO - 2023-10-20 18:09:28 --> Helper loaded: file_helper
INFO - 2023-10-20 18:09:28 --> Helper loaded: html_helper
INFO - 2023-10-20 18:09:28 --> Helper loaded: text_helper
INFO - 2023-10-20 18:09:28 --> Helper loaded: form_helper
INFO - 2023-10-20 18:09:28 --> Helper loaded: lang_helper
INFO - 2023-10-20 18:09:28 --> Helper loaded: security_helper
INFO - 2023-10-20 18:09:28 --> Helper loaded: cookie_helper
INFO - 2023-10-20 18:09:28 --> Database Driver Class Initialized
INFO - 2023-10-20 18:09:28 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-20 18:09:28 --> Parser Class Initialized
INFO - 2023-10-20 18:09:28 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-20 18:09:28 --> Pagination Class Initialized
INFO - 2023-10-20 18:09:28 --> Form Validation Class Initialized
INFO - 2023-10-20 18:09:28 --> Controller Class Initialized
DEBUG - 2023-10-20 18:09:28 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-10-20 18:09:28 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-20 18:09:28 --> Model Class Initialized
INFO - 2023-10-20 18:09:28 --> Model Class Initialized
INFO - 2023-10-20 18:09:28 --> Final output sent to browser
DEBUG - 2023-10-20 18:09:28 --> Total execution time: 0.0219
ERROR - 2023-10-20 18:09:51 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-20 18:09:51 --> Config Class Initialized
INFO - 2023-10-20 18:09:51 --> Hooks Class Initialized
DEBUG - 2023-10-20 18:09:51 --> UTF-8 Support Enabled
INFO - 2023-10-20 18:09:51 --> Utf8 Class Initialized
INFO - 2023-10-20 18:09:51 --> URI Class Initialized
INFO - 2023-10-20 18:09:51 --> Router Class Initialized
INFO - 2023-10-20 18:09:51 --> Output Class Initialized
INFO - 2023-10-20 18:09:51 --> Security Class Initialized
DEBUG - 2023-10-20 18:09:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-20 18:09:51 --> Input Class Initialized
INFO - 2023-10-20 18:09:51 --> Language Class Initialized
INFO - 2023-10-20 18:09:51 --> Loader Class Initialized
INFO - 2023-10-20 18:09:51 --> Helper loaded: url_helper
INFO - 2023-10-20 18:09:51 --> Helper loaded: file_helper
INFO - 2023-10-20 18:09:51 --> Helper loaded: html_helper
INFO - 2023-10-20 18:09:51 --> Helper loaded: text_helper
INFO - 2023-10-20 18:09:51 --> Helper loaded: form_helper
INFO - 2023-10-20 18:09:51 --> Helper loaded: lang_helper
INFO - 2023-10-20 18:09:51 --> Helper loaded: security_helper
INFO - 2023-10-20 18:09:51 --> Helper loaded: cookie_helper
INFO - 2023-10-20 18:09:51 --> Database Driver Class Initialized
INFO - 2023-10-20 18:09:51 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-20 18:09:51 --> Parser Class Initialized
INFO - 2023-10-20 18:09:51 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-20 18:09:51 --> Pagination Class Initialized
INFO - 2023-10-20 18:09:51 --> Form Validation Class Initialized
INFO - 2023-10-20 18:09:51 --> Controller Class Initialized
DEBUG - 2023-10-20 18:09:51 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-10-20 18:09:51 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-20 18:09:51 --> Model Class Initialized
INFO - 2023-10-20 18:09:52 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/web_setting/web_setting.php
DEBUG - 2023-10-20 18:09:52 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-10-20 18:09:52 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-10-20 18:09:52 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-10-20 18:09:52 --> Model Class Initialized
INFO - 2023-10-20 18:09:52 --> Model Class Initialized
INFO - 2023-10-20 18:09:52 --> Model Class Initialized
INFO - 2023-10-20 18:09:52 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-10-20 18:09:52 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-10-20 18:09:52 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-10-20 18:09:52 --> Final output sent to browser
DEBUG - 2023-10-20 18:09:52 --> Total execution time: 0.2023
