<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2023-04-23 01:04:06 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-23 01:04:06 --> Config Class Initialized
INFO - 2023-04-23 01:04:06 --> Hooks Class Initialized
DEBUG - 2023-04-23 01:04:06 --> UTF-8 Support Enabled
INFO - 2023-04-23 01:04:06 --> Utf8 Class Initialized
INFO - 2023-04-23 01:04:06 --> URI Class Initialized
DEBUG - 2023-04-23 01:04:06 --> No URI present. Default controller set.
INFO - 2023-04-23 01:04:06 --> Router Class Initialized
INFO - 2023-04-23 01:04:06 --> Output Class Initialized
INFO - 2023-04-23 01:04:06 --> Security Class Initialized
DEBUG - 2023-04-23 01:04:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-23 01:04:06 --> Input Class Initialized
INFO - 2023-04-23 01:04:06 --> Language Class Initialized
INFO - 2023-04-23 01:04:06 --> Loader Class Initialized
INFO - 2023-04-23 01:04:06 --> Helper loaded: url_helper
INFO - 2023-04-23 01:04:06 --> Helper loaded: file_helper
INFO - 2023-04-23 01:04:06 --> Helper loaded: html_helper
INFO - 2023-04-23 01:04:06 --> Helper loaded: text_helper
INFO - 2023-04-23 01:04:06 --> Helper loaded: form_helper
INFO - 2023-04-23 01:04:06 --> Helper loaded: lang_helper
INFO - 2023-04-23 01:04:06 --> Helper loaded: security_helper
INFO - 2023-04-23 01:04:06 --> Helper loaded: cookie_helper
INFO - 2023-04-23 01:04:06 --> Database Driver Class Initialized
INFO - 2023-04-23 01:04:06 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-23 01:04:06 --> Parser Class Initialized
INFO - 2023-04-23 01:04:06 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-23 01:04:06 --> Pagination Class Initialized
INFO - 2023-04-23 01:04:06 --> Form Validation Class Initialized
INFO - 2023-04-23 01:04:06 --> Controller Class Initialized
INFO - 2023-04-23 01:04:06 --> Model Class Initialized
DEBUG - 2023-04-23 01:04:06 --> Session class already loaded. Second attempt ignored.
ERROR - 2023-04-23 09:45:26 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-23 09:45:26 --> Config Class Initialized
INFO - 2023-04-23 09:45:26 --> Hooks Class Initialized
DEBUG - 2023-04-23 09:45:26 --> UTF-8 Support Enabled
INFO - 2023-04-23 09:45:26 --> Utf8 Class Initialized
INFO - 2023-04-23 09:45:26 --> URI Class Initialized
DEBUG - 2023-04-23 09:45:26 --> No URI present. Default controller set.
INFO - 2023-04-23 09:45:26 --> Router Class Initialized
INFO - 2023-04-23 09:45:26 --> Output Class Initialized
INFO - 2023-04-23 09:45:26 --> Security Class Initialized
DEBUG - 2023-04-23 09:45:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-23 09:45:26 --> Input Class Initialized
INFO - 2023-04-23 09:45:26 --> Language Class Initialized
INFO - 2023-04-23 09:45:26 --> Loader Class Initialized
INFO - 2023-04-23 09:45:26 --> Helper loaded: url_helper
INFO - 2023-04-23 09:45:26 --> Helper loaded: file_helper
INFO - 2023-04-23 09:45:26 --> Helper loaded: html_helper
INFO - 2023-04-23 09:45:26 --> Helper loaded: text_helper
INFO - 2023-04-23 09:45:26 --> Helper loaded: form_helper
INFO - 2023-04-23 09:45:26 --> Helper loaded: lang_helper
INFO - 2023-04-23 09:45:26 --> Helper loaded: security_helper
INFO - 2023-04-23 09:45:26 --> Helper loaded: cookie_helper
INFO - 2023-04-23 09:45:26 --> Database Driver Class Initialized
INFO - 2023-04-23 09:45:26 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-23 09:45:26 --> Parser Class Initialized
INFO - 2023-04-23 09:45:26 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-23 09:45:26 --> Pagination Class Initialized
INFO - 2023-04-23 09:45:26 --> Form Validation Class Initialized
INFO - 2023-04-23 09:45:26 --> Controller Class Initialized
INFO - 2023-04-23 09:45:26 --> Model Class Initialized
DEBUG - 2023-04-23 09:45:26 --> Session class already loaded. Second attempt ignored.
ERROR - 2023-04-23 09:45:26 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-23 09:45:26 --> Config Class Initialized
INFO - 2023-04-23 09:45:26 --> Hooks Class Initialized
DEBUG - 2023-04-23 09:45:26 --> UTF-8 Support Enabled
INFO - 2023-04-23 09:45:26 --> Utf8 Class Initialized
INFO - 2023-04-23 09:45:26 --> URI Class Initialized
INFO - 2023-04-23 09:45:26 --> Router Class Initialized
INFO - 2023-04-23 09:45:26 --> Output Class Initialized
INFO - 2023-04-23 09:45:26 --> Security Class Initialized
DEBUG - 2023-04-23 09:45:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-23 09:45:26 --> Input Class Initialized
INFO - 2023-04-23 09:45:26 --> Language Class Initialized
INFO - 2023-04-23 09:45:26 --> Loader Class Initialized
INFO - 2023-04-23 09:45:26 --> Helper loaded: url_helper
INFO - 2023-04-23 09:45:26 --> Helper loaded: file_helper
INFO - 2023-04-23 09:45:26 --> Helper loaded: html_helper
INFO - 2023-04-23 09:45:26 --> Helper loaded: text_helper
INFO - 2023-04-23 09:45:26 --> Helper loaded: form_helper
INFO - 2023-04-23 09:45:26 --> Helper loaded: lang_helper
INFO - 2023-04-23 09:45:26 --> Helper loaded: security_helper
INFO - 2023-04-23 09:45:26 --> Helper loaded: cookie_helper
INFO - 2023-04-23 09:45:26 --> Database Driver Class Initialized
INFO - 2023-04-23 09:45:26 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-23 09:45:26 --> Parser Class Initialized
INFO - 2023-04-23 09:45:26 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-23 09:45:26 --> Pagination Class Initialized
INFO - 2023-04-23 09:45:26 --> Form Validation Class Initialized
INFO - 2023-04-23 09:45:26 --> Controller Class Initialized
INFO - 2023-04-23 09:45:26 --> Model Class Initialized
DEBUG - 2023-04-23 09:45:26 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-23 09:45:26 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2023-04-23 09:45:26 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-04-23 09:45:26 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-04-23 09:45:26 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-04-23 09:45:26 --> Model Class Initialized
INFO - 2023-04-23 09:45:26 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-04-23 09:45:26 --> Final output sent to browser
DEBUG - 2023-04-23 09:45:26 --> Total execution time: 0.0353
ERROR - 2023-04-23 09:45:47 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-23 09:45:47 --> Config Class Initialized
INFO - 2023-04-23 09:45:47 --> Hooks Class Initialized
DEBUG - 2023-04-23 09:45:47 --> UTF-8 Support Enabled
INFO - 2023-04-23 09:45:47 --> Utf8 Class Initialized
INFO - 2023-04-23 09:45:47 --> URI Class Initialized
INFO - 2023-04-23 09:45:47 --> Router Class Initialized
INFO - 2023-04-23 09:45:47 --> Output Class Initialized
INFO - 2023-04-23 09:45:47 --> Security Class Initialized
DEBUG - 2023-04-23 09:45:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-23 09:45:47 --> Input Class Initialized
INFO - 2023-04-23 09:45:47 --> Language Class Initialized
INFO - 2023-04-23 09:45:47 --> Loader Class Initialized
INFO - 2023-04-23 09:45:47 --> Helper loaded: url_helper
INFO - 2023-04-23 09:45:47 --> Helper loaded: file_helper
INFO - 2023-04-23 09:45:47 --> Helper loaded: html_helper
INFO - 2023-04-23 09:45:47 --> Helper loaded: text_helper
INFO - 2023-04-23 09:45:47 --> Helper loaded: form_helper
INFO - 2023-04-23 09:45:47 --> Helper loaded: lang_helper
INFO - 2023-04-23 09:45:47 --> Helper loaded: security_helper
INFO - 2023-04-23 09:45:47 --> Helper loaded: cookie_helper
INFO - 2023-04-23 09:45:47 --> Database Driver Class Initialized
INFO - 2023-04-23 09:45:47 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-23 09:45:47 --> Parser Class Initialized
INFO - 2023-04-23 09:45:47 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-23 09:45:47 --> Pagination Class Initialized
INFO - 2023-04-23 09:45:47 --> Form Validation Class Initialized
INFO - 2023-04-23 09:45:47 --> Controller Class Initialized
INFO - 2023-04-23 09:45:47 --> Model Class Initialized
DEBUG - 2023-04-23 09:45:47 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-23 09:45:47 --> Model Class Initialized
INFO - 2023-04-23 09:45:47 --> Final output sent to browser
DEBUG - 2023-04-23 09:45:47 --> Total execution time: 0.0213
ERROR - 2023-04-23 09:45:47 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-23 09:45:47 --> Config Class Initialized
INFO - 2023-04-23 09:45:47 --> Hooks Class Initialized
DEBUG - 2023-04-23 09:45:47 --> UTF-8 Support Enabled
INFO - 2023-04-23 09:45:47 --> Utf8 Class Initialized
INFO - 2023-04-23 09:45:47 --> URI Class Initialized
INFO - 2023-04-23 09:45:47 --> Router Class Initialized
INFO - 2023-04-23 09:45:47 --> Output Class Initialized
INFO - 2023-04-23 09:45:47 --> Security Class Initialized
DEBUG - 2023-04-23 09:45:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-23 09:45:47 --> Input Class Initialized
INFO - 2023-04-23 09:45:47 --> Language Class Initialized
INFO - 2023-04-23 09:45:47 --> Loader Class Initialized
INFO - 2023-04-23 09:45:47 --> Helper loaded: url_helper
INFO - 2023-04-23 09:45:47 --> Helper loaded: file_helper
INFO - 2023-04-23 09:45:47 --> Helper loaded: html_helper
INFO - 2023-04-23 09:45:47 --> Helper loaded: text_helper
INFO - 2023-04-23 09:45:47 --> Helper loaded: form_helper
INFO - 2023-04-23 09:45:47 --> Helper loaded: lang_helper
INFO - 2023-04-23 09:45:47 --> Helper loaded: security_helper
INFO - 2023-04-23 09:45:47 --> Helper loaded: cookie_helper
INFO - 2023-04-23 09:45:47 --> Database Driver Class Initialized
INFO - 2023-04-23 09:45:47 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-23 09:45:47 --> Parser Class Initialized
INFO - 2023-04-23 09:45:47 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-23 09:45:47 --> Pagination Class Initialized
INFO - 2023-04-23 09:45:47 --> Form Validation Class Initialized
INFO - 2023-04-23 09:45:47 --> Controller Class Initialized
INFO - 2023-04-23 09:45:47 --> Model Class Initialized
DEBUG - 2023-04-23 09:45:47 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-23 09:45:47 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2023-04-23 09:45:47 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-04-23 09:45:47 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-04-23 09:45:47 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-04-23 09:45:47 --> Model Class Initialized
INFO - 2023-04-23 09:45:47 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-04-23 09:45:47 --> Final output sent to browser
DEBUG - 2023-04-23 09:45:47 --> Total execution time: 0.0343
ERROR - 2023-04-23 09:46:09 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-23 09:46:09 --> Config Class Initialized
INFO - 2023-04-23 09:46:09 --> Hooks Class Initialized
DEBUG - 2023-04-23 09:46:09 --> UTF-8 Support Enabled
INFO - 2023-04-23 09:46:09 --> Utf8 Class Initialized
INFO - 2023-04-23 09:46:09 --> URI Class Initialized
INFO - 2023-04-23 09:46:09 --> Router Class Initialized
INFO - 2023-04-23 09:46:09 --> Output Class Initialized
INFO - 2023-04-23 09:46:09 --> Security Class Initialized
DEBUG - 2023-04-23 09:46:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-23 09:46:09 --> Input Class Initialized
INFO - 2023-04-23 09:46:09 --> Language Class Initialized
INFO - 2023-04-23 09:46:09 --> Loader Class Initialized
INFO - 2023-04-23 09:46:09 --> Helper loaded: url_helper
INFO - 2023-04-23 09:46:09 --> Helper loaded: file_helper
INFO - 2023-04-23 09:46:09 --> Helper loaded: html_helper
INFO - 2023-04-23 09:46:09 --> Helper loaded: text_helper
INFO - 2023-04-23 09:46:09 --> Helper loaded: form_helper
INFO - 2023-04-23 09:46:09 --> Helper loaded: lang_helper
INFO - 2023-04-23 09:46:09 --> Helper loaded: security_helper
INFO - 2023-04-23 09:46:09 --> Helper loaded: cookie_helper
INFO - 2023-04-23 09:46:09 --> Database Driver Class Initialized
INFO - 2023-04-23 09:46:09 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-23 09:46:09 --> Parser Class Initialized
INFO - 2023-04-23 09:46:09 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-23 09:46:09 --> Pagination Class Initialized
INFO - 2023-04-23 09:46:09 --> Form Validation Class Initialized
INFO - 2023-04-23 09:46:09 --> Controller Class Initialized
INFO - 2023-04-23 09:46:09 --> Model Class Initialized
DEBUG - 2023-04-23 09:46:09 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-23 09:46:09 --> Model Class Initialized
INFO - 2023-04-23 09:46:09 --> Final output sent to browser
DEBUG - 2023-04-23 09:46:09 --> Total execution time: 0.0189
ERROR - 2023-04-23 09:46:10 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-23 09:46:10 --> Config Class Initialized
INFO - 2023-04-23 09:46:10 --> Hooks Class Initialized
DEBUG - 2023-04-23 09:46:10 --> UTF-8 Support Enabled
INFO - 2023-04-23 09:46:10 --> Utf8 Class Initialized
INFO - 2023-04-23 09:46:10 --> URI Class Initialized
INFO - 2023-04-23 09:46:10 --> Router Class Initialized
INFO - 2023-04-23 09:46:10 --> Output Class Initialized
INFO - 2023-04-23 09:46:10 --> Security Class Initialized
DEBUG - 2023-04-23 09:46:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-23 09:46:10 --> Input Class Initialized
INFO - 2023-04-23 09:46:10 --> Language Class Initialized
INFO - 2023-04-23 09:46:10 --> Loader Class Initialized
INFO - 2023-04-23 09:46:10 --> Helper loaded: url_helper
INFO - 2023-04-23 09:46:10 --> Helper loaded: file_helper
INFO - 2023-04-23 09:46:10 --> Helper loaded: html_helper
INFO - 2023-04-23 09:46:10 --> Helper loaded: text_helper
INFO - 2023-04-23 09:46:10 --> Helper loaded: form_helper
INFO - 2023-04-23 09:46:10 --> Helper loaded: lang_helper
INFO - 2023-04-23 09:46:10 --> Helper loaded: security_helper
INFO - 2023-04-23 09:46:10 --> Helper loaded: cookie_helper
INFO - 2023-04-23 09:46:10 --> Database Driver Class Initialized
INFO - 2023-04-23 09:46:10 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-23 09:46:10 --> Parser Class Initialized
INFO - 2023-04-23 09:46:10 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-23 09:46:10 --> Pagination Class Initialized
INFO - 2023-04-23 09:46:10 --> Form Validation Class Initialized
INFO - 2023-04-23 09:46:10 --> Controller Class Initialized
INFO - 2023-04-23 09:46:10 --> Model Class Initialized
DEBUG - 2023-04-23 09:46:10 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-23 09:46:10 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2023-04-23 09:46:10 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-04-23 09:46:10 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-04-23 09:46:10 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-04-23 09:46:10 --> Model Class Initialized
INFO - 2023-04-23 09:46:10 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-04-23 09:46:10 --> Final output sent to browser
DEBUG - 2023-04-23 09:46:10 --> Total execution time: 0.0303
ERROR - 2023-04-23 09:46:25 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-23 09:46:25 --> Config Class Initialized
INFO - 2023-04-23 09:46:25 --> Hooks Class Initialized
DEBUG - 2023-04-23 09:46:25 --> UTF-8 Support Enabled
INFO - 2023-04-23 09:46:25 --> Utf8 Class Initialized
INFO - 2023-04-23 09:46:25 --> URI Class Initialized
DEBUG - 2023-04-23 09:46:25 --> No URI present. Default controller set.
INFO - 2023-04-23 09:46:25 --> Router Class Initialized
INFO - 2023-04-23 09:46:25 --> Output Class Initialized
INFO - 2023-04-23 09:46:25 --> Security Class Initialized
DEBUG - 2023-04-23 09:46:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-23 09:46:25 --> Input Class Initialized
INFO - 2023-04-23 09:46:25 --> Language Class Initialized
INFO - 2023-04-23 09:46:25 --> Loader Class Initialized
INFO - 2023-04-23 09:46:25 --> Helper loaded: url_helper
INFO - 2023-04-23 09:46:25 --> Helper loaded: file_helper
INFO - 2023-04-23 09:46:25 --> Helper loaded: html_helper
INFO - 2023-04-23 09:46:25 --> Helper loaded: text_helper
INFO - 2023-04-23 09:46:25 --> Helper loaded: form_helper
INFO - 2023-04-23 09:46:25 --> Helper loaded: lang_helper
INFO - 2023-04-23 09:46:25 --> Helper loaded: security_helper
INFO - 2023-04-23 09:46:25 --> Helper loaded: cookie_helper
INFO - 2023-04-23 09:46:25 --> Database Driver Class Initialized
INFO - 2023-04-23 09:46:25 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-23 09:46:25 --> Parser Class Initialized
INFO - 2023-04-23 09:46:25 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-23 09:46:25 --> Pagination Class Initialized
INFO - 2023-04-23 09:46:25 --> Form Validation Class Initialized
INFO - 2023-04-23 09:46:25 --> Controller Class Initialized
INFO - 2023-04-23 09:46:25 --> Model Class Initialized
DEBUG - 2023-04-23 09:46:25 --> Session class already loaded. Second attempt ignored.
ERROR - 2023-04-23 09:46:25 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-23 09:46:25 --> Config Class Initialized
INFO - 2023-04-23 09:46:25 --> Hooks Class Initialized
DEBUG - 2023-04-23 09:46:25 --> UTF-8 Support Enabled
INFO - 2023-04-23 09:46:25 --> Utf8 Class Initialized
INFO - 2023-04-23 09:46:25 --> URI Class Initialized
INFO - 2023-04-23 09:46:25 --> Router Class Initialized
INFO - 2023-04-23 09:46:25 --> Output Class Initialized
INFO - 2023-04-23 09:46:25 --> Security Class Initialized
DEBUG - 2023-04-23 09:46:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-23 09:46:25 --> Input Class Initialized
INFO - 2023-04-23 09:46:25 --> Language Class Initialized
INFO - 2023-04-23 09:46:25 --> Loader Class Initialized
INFO - 2023-04-23 09:46:25 --> Helper loaded: url_helper
INFO - 2023-04-23 09:46:25 --> Helper loaded: file_helper
INFO - 2023-04-23 09:46:25 --> Helper loaded: html_helper
INFO - 2023-04-23 09:46:25 --> Helper loaded: text_helper
INFO - 2023-04-23 09:46:25 --> Helper loaded: form_helper
INFO - 2023-04-23 09:46:25 --> Helper loaded: lang_helper
INFO - 2023-04-23 09:46:25 --> Helper loaded: security_helper
INFO - 2023-04-23 09:46:25 --> Helper loaded: cookie_helper
INFO - 2023-04-23 09:46:25 --> Database Driver Class Initialized
INFO - 2023-04-23 09:46:25 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-23 09:46:25 --> Parser Class Initialized
INFO - 2023-04-23 09:46:25 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-23 09:46:25 --> Pagination Class Initialized
INFO - 2023-04-23 09:46:25 --> Form Validation Class Initialized
INFO - 2023-04-23 09:46:25 --> Controller Class Initialized
INFO - 2023-04-23 09:46:25 --> Model Class Initialized
DEBUG - 2023-04-23 09:46:25 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-23 09:46:25 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2023-04-23 09:46:25 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-04-23 09:46:25 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-04-23 09:46:25 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-04-23 09:46:25 --> Model Class Initialized
INFO - 2023-04-23 09:46:25 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-04-23 09:46:25 --> Final output sent to browser
DEBUG - 2023-04-23 09:46:25 --> Total execution time: 0.0301
ERROR - 2023-04-23 09:46:48 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-23 09:46:48 --> Config Class Initialized
INFO - 2023-04-23 09:46:48 --> Hooks Class Initialized
DEBUG - 2023-04-23 09:46:48 --> UTF-8 Support Enabled
INFO - 2023-04-23 09:46:48 --> Utf8 Class Initialized
INFO - 2023-04-23 09:46:48 --> URI Class Initialized
INFO - 2023-04-23 09:46:48 --> Router Class Initialized
INFO - 2023-04-23 09:46:48 --> Output Class Initialized
INFO - 2023-04-23 09:46:48 --> Security Class Initialized
DEBUG - 2023-04-23 09:46:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-23 09:46:48 --> Input Class Initialized
INFO - 2023-04-23 09:46:48 --> Language Class Initialized
INFO - 2023-04-23 09:46:48 --> Loader Class Initialized
INFO - 2023-04-23 09:46:48 --> Helper loaded: url_helper
INFO - 2023-04-23 09:46:48 --> Helper loaded: file_helper
INFO - 2023-04-23 09:46:48 --> Helper loaded: html_helper
INFO - 2023-04-23 09:46:48 --> Helper loaded: text_helper
INFO - 2023-04-23 09:46:48 --> Helper loaded: form_helper
INFO - 2023-04-23 09:46:48 --> Helper loaded: lang_helper
INFO - 2023-04-23 09:46:48 --> Helper loaded: security_helper
INFO - 2023-04-23 09:46:48 --> Helper loaded: cookie_helper
INFO - 2023-04-23 09:46:48 --> Database Driver Class Initialized
INFO - 2023-04-23 09:46:48 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-23 09:46:48 --> Parser Class Initialized
INFO - 2023-04-23 09:46:48 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-23 09:46:48 --> Pagination Class Initialized
INFO - 2023-04-23 09:46:48 --> Form Validation Class Initialized
INFO - 2023-04-23 09:46:48 --> Controller Class Initialized
INFO - 2023-04-23 09:46:48 --> Model Class Initialized
DEBUG - 2023-04-23 09:46:48 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-23 09:46:48 --> Model Class Initialized
INFO - 2023-04-23 09:46:48 --> Final output sent to browser
DEBUG - 2023-04-23 09:46:48 --> Total execution time: 0.0189
ERROR - 2023-04-23 09:46:49 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-23 09:46:49 --> Config Class Initialized
INFO - 2023-04-23 09:46:49 --> Hooks Class Initialized
DEBUG - 2023-04-23 09:46:49 --> UTF-8 Support Enabled
INFO - 2023-04-23 09:46:49 --> Utf8 Class Initialized
INFO - 2023-04-23 09:46:49 --> URI Class Initialized
DEBUG - 2023-04-23 09:46:49 --> No URI present. Default controller set.
INFO - 2023-04-23 09:46:49 --> Router Class Initialized
INFO - 2023-04-23 09:46:49 --> Output Class Initialized
INFO - 2023-04-23 09:46:49 --> Security Class Initialized
DEBUG - 2023-04-23 09:46:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-23 09:46:49 --> Input Class Initialized
INFO - 2023-04-23 09:46:49 --> Language Class Initialized
INFO - 2023-04-23 09:46:49 --> Loader Class Initialized
INFO - 2023-04-23 09:46:49 --> Helper loaded: url_helper
INFO - 2023-04-23 09:46:49 --> Helper loaded: file_helper
INFO - 2023-04-23 09:46:49 --> Helper loaded: html_helper
INFO - 2023-04-23 09:46:49 --> Helper loaded: text_helper
INFO - 2023-04-23 09:46:49 --> Helper loaded: form_helper
INFO - 2023-04-23 09:46:49 --> Helper loaded: lang_helper
INFO - 2023-04-23 09:46:49 --> Helper loaded: security_helper
INFO - 2023-04-23 09:46:49 --> Helper loaded: cookie_helper
INFO - 2023-04-23 09:46:49 --> Database Driver Class Initialized
INFO - 2023-04-23 09:46:49 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-23 09:46:49 --> Parser Class Initialized
INFO - 2023-04-23 09:46:49 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-23 09:46:49 --> Pagination Class Initialized
INFO - 2023-04-23 09:46:49 --> Form Validation Class Initialized
INFO - 2023-04-23 09:46:49 --> Controller Class Initialized
INFO - 2023-04-23 09:46:49 --> Model Class Initialized
DEBUG - 2023-04-23 09:46:49 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-23 09:46:49 --> Model Class Initialized
DEBUG - 2023-04-23 09:46:49 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-23 09:46:49 --> Model Class Initialized
INFO - 2023-04-23 09:46:49 --> Model Class Initialized
INFO - 2023-04-23 09:46:49 --> Model Class Initialized
INFO - 2023-04-23 09:46:49 --> Model Class Initialized
DEBUG - 2023-04-23 09:46:49 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-04-23 09:46:49 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-23 09:46:49 --> Model Class Initialized
INFO - 2023-04-23 09:46:49 --> Model Class Initialized
INFO - 2023-04-23 09:46:49 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-04-23 09:46:49 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-04-23 09:46:49 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-04-23 09:46:49 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-04-23 09:46:49 --> Model Class Initialized
INFO - 2023-04-23 09:46:49 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-04-23 09:46:49 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-04-23 09:46:49 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-04-23 09:46:49 --> Final output sent to browser
DEBUG - 2023-04-23 09:46:49 --> Total execution time: 0.1836
ERROR - 2023-04-23 09:46:50 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-23 09:46:50 --> Config Class Initialized
INFO - 2023-04-23 09:46:50 --> Hooks Class Initialized
DEBUG - 2023-04-23 09:46:50 --> UTF-8 Support Enabled
INFO - 2023-04-23 09:46:50 --> Utf8 Class Initialized
INFO - 2023-04-23 09:46:50 --> URI Class Initialized
INFO - 2023-04-23 09:46:50 --> Router Class Initialized
INFO - 2023-04-23 09:46:50 --> Output Class Initialized
INFO - 2023-04-23 09:46:50 --> Security Class Initialized
DEBUG - 2023-04-23 09:46:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-23 09:46:50 --> Input Class Initialized
INFO - 2023-04-23 09:46:50 --> Language Class Initialized
INFO - 2023-04-23 09:46:50 --> Loader Class Initialized
INFO - 2023-04-23 09:46:50 --> Helper loaded: url_helper
INFO - 2023-04-23 09:46:50 --> Helper loaded: file_helper
INFO - 2023-04-23 09:46:50 --> Helper loaded: html_helper
INFO - 2023-04-23 09:46:50 --> Helper loaded: text_helper
INFO - 2023-04-23 09:46:50 --> Helper loaded: form_helper
INFO - 2023-04-23 09:46:50 --> Helper loaded: lang_helper
INFO - 2023-04-23 09:46:50 --> Helper loaded: security_helper
INFO - 2023-04-23 09:46:50 --> Helper loaded: cookie_helper
INFO - 2023-04-23 09:46:50 --> Database Driver Class Initialized
INFO - 2023-04-23 09:46:50 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-23 09:46:50 --> Parser Class Initialized
INFO - 2023-04-23 09:46:50 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-23 09:46:50 --> Pagination Class Initialized
INFO - 2023-04-23 09:46:50 --> Form Validation Class Initialized
INFO - 2023-04-23 09:46:50 --> Controller Class Initialized
DEBUG - 2023-04-23 09:46:50 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-04-23 09:46:50 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-23 09:46:50 --> Model Class Initialized
INFO - 2023-04-23 09:46:50 --> Final output sent to browser
DEBUG - 2023-04-23 09:46:50 --> Total execution time: 0.0164
ERROR - 2023-04-23 09:47:02 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-23 09:47:02 --> Config Class Initialized
INFO - 2023-04-23 09:47:02 --> Hooks Class Initialized
DEBUG - 2023-04-23 09:47:02 --> UTF-8 Support Enabled
INFO - 2023-04-23 09:47:02 --> Utf8 Class Initialized
INFO - 2023-04-23 09:47:02 --> URI Class Initialized
INFO - 2023-04-23 09:47:02 --> Router Class Initialized
INFO - 2023-04-23 09:47:02 --> Output Class Initialized
INFO - 2023-04-23 09:47:02 --> Security Class Initialized
DEBUG - 2023-04-23 09:47:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-23 09:47:02 --> Input Class Initialized
INFO - 2023-04-23 09:47:02 --> Language Class Initialized
INFO - 2023-04-23 09:47:02 --> Loader Class Initialized
INFO - 2023-04-23 09:47:02 --> Helper loaded: url_helper
INFO - 2023-04-23 09:47:02 --> Helper loaded: file_helper
INFO - 2023-04-23 09:47:02 --> Helper loaded: html_helper
INFO - 2023-04-23 09:47:02 --> Helper loaded: text_helper
INFO - 2023-04-23 09:47:02 --> Helper loaded: form_helper
INFO - 2023-04-23 09:47:02 --> Helper loaded: lang_helper
INFO - 2023-04-23 09:47:02 --> Helper loaded: security_helper
INFO - 2023-04-23 09:47:02 --> Helper loaded: cookie_helper
INFO - 2023-04-23 09:47:02 --> Database Driver Class Initialized
INFO - 2023-04-23 09:47:02 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-23 09:47:02 --> Parser Class Initialized
INFO - 2023-04-23 09:47:02 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-23 09:47:02 --> Pagination Class Initialized
INFO - 2023-04-23 09:47:02 --> Form Validation Class Initialized
INFO - 2023-04-23 09:47:02 --> Controller Class Initialized
INFO - 2023-04-23 09:47:02 --> Model Class Initialized
INFO - 2023-04-23 09:47:02 --> Model Class Initialized
ERROR - 2023-04-23 09:47:02 --> Severity: Warning --> Invalid argument supplied for foreach() /home/powera7m/app.maurnaturo.com/application/views/purchase/add_purchase_form.php 157
INFO - 2023-04-23 09:47:02 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/purchase/add_purchase_form.php
DEBUG - 2023-04-23 09:47:02 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-04-23 09:47:02 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-04-23 09:47:02 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-04-23 09:47:02 --> Model Class Initialized
INFO - 2023-04-23 09:47:02 --> Model Class Initialized
INFO - 2023-04-23 09:47:02 --> Model Class Initialized
INFO - 2023-04-23 09:47:03 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-04-23 09:47:03 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-04-23 09:47:03 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-04-23 09:47:03 --> Final output sent to browser
DEBUG - 2023-04-23 09:47:03 --> Total execution time: 0.2076
ERROR - 2023-04-23 12:35:07 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-23 12:35:07 --> Config Class Initialized
INFO - 2023-04-23 12:35:07 --> Hooks Class Initialized
DEBUG - 2023-04-23 12:35:07 --> UTF-8 Support Enabled
INFO - 2023-04-23 12:35:07 --> Utf8 Class Initialized
INFO - 2023-04-23 12:35:07 --> URI Class Initialized
DEBUG - 2023-04-23 12:35:07 --> No URI present. Default controller set.
INFO - 2023-04-23 12:35:07 --> Router Class Initialized
INFO - 2023-04-23 12:35:07 --> Output Class Initialized
INFO - 2023-04-23 12:35:07 --> Security Class Initialized
DEBUG - 2023-04-23 12:35:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-23 12:35:07 --> Input Class Initialized
INFO - 2023-04-23 12:35:07 --> Language Class Initialized
INFO - 2023-04-23 12:35:07 --> Loader Class Initialized
INFO - 2023-04-23 12:35:07 --> Helper loaded: url_helper
INFO - 2023-04-23 12:35:07 --> Helper loaded: file_helper
INFO - 2023-04-23 12:35:07 --> Helper loaded: html_helper
INFO - 2023-04-23 12:35:07 --> Helper loaded: text_helper
INFO - 2023-04-23 12:35:07 --> Helper loaded: form_helper
INFO - 2023-04-23 12:35:07 --> Helper loaded: lang_helper
INFO - 2023-04-23 12:35:07 --> Helper loaded: security_helper
INFO - 2023-04-23 12:35:07 --> Helper loaded: cookie_helper
INFO - 2023-04-23 12:35:07 --> Database Driver Class Initialized
INFO - 2023-04-23 12:35:07 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-23 12:35:07 --> Parser Class Initialized
INFO - 2023-04-23 12:35:07 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-23 12:35:07 --> Pagination Class Initialized
INFO - 2023-04-23 12:35:07 --> Form Validation Class Initialized
INFO - 2023-04-23 12:35:07 --> Controller Class Initialized
INFO - 2023-04-23 12:35:07 --> Model Class Initialized
DEBUG - 2023-04-23 12:35:07 --> Session class already loaded. Second attempt ignored.
ERROR - 2023-04-23 12:35:07 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-23 12:35:07 --> Config Class Initialized
INFO - 2023-04-23 12:35:07 --> Hooks Class Initialized
DEBUG - 2023-04-23 12:35:07 --> UTF-8 Support Enabled
INFO - 2023-04-23 12:35:07 --> Utf8 Class Initialized
INFO - 2023-04-23 12:35:07 --> URI Class Initialized
INFO - 2023-04-23 12:35:07 --> Router Class Initialized
INFO - 2023-04-23 12:35:07 --> Output Class Initialized
INFO - 2023-04-23 12:35:07 --> Security Class Initialized
DEBUG - 2023-04-23 12:35:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-23 12:35:07 --> Input Class Initialized
INFO - 2023-04-23 12:35:07 --> Language Class Initialized
INFO - 2023-04-23 12:35:07 --> Loader Class Initialized
INFO - 2023-04-23 12:35:07 --> Helper loaded: url_helper
INFO - 2023-04-23 12:35:07 --> Helper loaded: file_helper
INFO - 2023-04-23 12:35:07 --> Helper loaded: html_helper
INFO - 2023-04-23 12:35:07 --> Helper loaded: text_helper
INFO - 2023-04-23 12:35:07 --> Helper loaded: form_helper
INFO - 2023-04-23 12:35:07 --> Helper loaded: lang_helper
INFO - 2023-04-23 12:35:07 --> Helper loaded: security_helper
INFO - 2023-04-23 12:35:07 --> Helper loaded: cookie_helper
INFO - 2023-04-23 12:35:07 --> Database Driver Class Initialized
INFO - 2023-04-23 12:35:07 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-23 12:35:07 --> Parser Class Initialized
INFO - 2023-04-23 12:35:07 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-23 12:35:07 --> Pagination Class Initialized
INFO - 2023-04-23 12:35:07 --> Form Validation Class Initialized
INFO - 2023-04-23 12:35:07 --> Controller Class Initialized
INFO - 2023-04-23 12:35:07 --> Model Class Initialized
DEBUG - 2023-04-23 12:35:07 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-23 12:35:07 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2023-04-23 12:35:07 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-04-23 12:35:07 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-04-23 12:35:07 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-04-23 12:35:07 --> Model Class Initialized
INFO - 2023-04-23 12:35:07 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-04-23 12:35:07 --> Final output sent to browser
DEBUG - 2023-04-23 12:35:07 --> Total execution time: 0.0350
ERROR - 2023-04-23 12:51:16 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-23 12:51:16 --> Config Class Initialized
INFO - 2023-04-23 12:51:16 --> Hooks Class Initialized
DEBUG - 2023-04-23 12:51:16 --> UTF-8 Support Enabled
INFO - 2023-04-23 12:51:16 --> Utf8 Class Initialized
INFO - 2023-04-23 12:51:16 --> URI Class Initialized
INFO - 2023-04-23 12:51:16 --> Router Class Initialized
INFO - 2023-04-23 12:51:16 --> Output Class Initialized
INFO - 2023-04-23 12:51:16 --> Security Class Initialized
DEBUG - 2023-04-23 12:51:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-23 12:51:16 --> Input Class Initialized
INFO - 2023-04-23 12:51:16 --> Language Class Initialized
INFO - 2023-04-23 12:51:16 --> Loader Class Initialized
INFO - 2023-04-23 12:51:16 --> Helper loaded: url_helper
INFO - 2023-04-23 12:51:16 --> Helper loaded: file_helper
INFO - 2023-04-23 12:51:16 --> Helper loaded: html_helper
INFO - 2023-04-23 12:51:16 --> Helper loaded: text_helper
INFO - 2023-04-23 12:51:16 --> Helper loaded: form_helper
INFO - 2023-04-23 12:51:16 --> Helper loaded: lang_helper
INFO - 2023-04-23 12:51:16 --> Helper loaded: security_helper
INFO - 2023-04-23 12:51:16 --> Helper loaded: cookie_helper
INFO - 2023-04-23 12:51:16 --> Database Driver Class Initialized
INFO - 2023-04-23 12:51:16 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-23 12:51:16 --> Parser Class Initialized
INFO - 2023-04-23 12:51:16 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-23 12:51:16 --> Pagination Class Initialized
INFO - 2023-04-23 12:51:16 --> Form Validation Class Initialized
INFO - 2023-04-23 12:51:16 --> Controller Class Initialized
INFO - 2023-04-23 12:51:16 --> Model Class Initialized
DEBUG - 2023-04-23 12:51:16 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-23 12:51:16 --> Model Class Initialized
INFO - 2023-04-23 12:51:16 --> Final output sent to browser
DEBUG - 2023-04-23 12:51:16 --> Total execution time: 0.0247
ERROR - 2023-04-23 12:51:16 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-23 12:51:16 --> Config Class Initialized
INFO - 2023-04-23 12:51:16 --> Hooks Class Initialized
DEBUG - 2023-04-23 12:51:16 --> UTF-8 Support Enabled
INFO - 2023-04-23 12:51:16 --> Utf8 Class Initialized
INFO - 2023-04-23 12:51:16 --> URI Class Initialized
DEBUG - 2023-04-23 12:51:16 --> No URI present. Default controller set.
INFO - 2023-04-23 12:51:16 --> Router Class Initialized
INFO - 2023-04-23 12:51:16 --> Output Class Initialized
INFO - 2023-04-23 12:51:16 --> Security Class Initialized
DEBUG - 2023-04-23 12:51:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-23 12:51:16 --> Input Class Initialized
INFO - 2023-04-23 12:51:16 --> Language Class Initialized
INFO - 2023-04-23 12:51:16 --> Loader Class Initialized
INFO - 2023-04-23 12:51:16 --> Helper loaded: url_helper
INFO - 2023-04-23 12:51:16 --> Helper loaded: file_helper
INFO - 2023-04-23 12:51:16 --> Helper loaded: html_helper
INFO - 2023-04-23 12:51:16 --> Helper loaded: text_helper
INFO - 2023-04-23 12:51:16 --> Helper loaded: form_helper
INFO - 2023-04-23 12:51:16 --> Helper loaded: lang_helper
INFO - 2023-04-23 12:51:16 --> Helper loaded: security_helper
INFO - 2023-04-23 12:51:16 --> Helper loaded: cookie_helper
INFO - 2023-04-23 12:51:16 --> Database Driver Class Initialized
INFO - 2023-04-23 12:51:16 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-23 12:51:16 --> Parser Class Initialized
INFO - 2023-04-23 12:51:16 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-23 12:51:16 --> Pagination Class Initialized
INFO - 2023-04-23 12:51:16 --> Form Validation Class Initialized
INFO - 2023-04-23 12:51:16 --> Controller Class Initialized
INFO - 2023-04-23 12:51:16 --> Model Class Initialized
DEBUG - 2023-04-23 12:51:16 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-23 12:51:16 --> Model Class Initialized
DEBUG - 2023-04-23 12:51:16 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-23 12:51:16 --> Model Class Initialized
INFO - 2023-04-23 12:51:16 --> Model Class Initialized
INFO - 2023-04-23 12:51:16 --> Model Class Initialized
INFO - 2023-04-23 12:51:16 --> Model Class Initialized
DEBUG - 2023-04-23 12:51:16 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-04-23 12:51:16 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-23 12:51:16 --> Model Class Initialized
INFO - 2023-04-23 12:51:16 --> Model Class Initialized
INFO - 2023-04-23 12:51:16 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-04-23 12:51:16 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-04-23 12:51:16 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-04-23 12:51:16 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-04-23 12:51:16 --> Model Class Initialized
INFO - 2023-04-23 12:51:16 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-04-23 12:51:16 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-04-23 12:51:16 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-04-23 12:51:16 --> Final output sent to browser
DEBUG - 2023-04-23 12:51:16 --> Total execution time: 0.1830
ERROR - 2023-04-23 12:51:17 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-23 12:51:17 --> Config Class Initialized
INFO - 2023-04-23 12:51:17 --> Hooks Class Initialized
DEBUG - 2023-04-23 12:51:17 --> UTF-8 Support Enabled
INFO - 2023-04-23 12:51:17 --> Utf8 Class Initialized
INFO - 2023-04-23 12:51:17 --> URI Class Initialized
INFO - 2023-04-23 12:51:17 --> Router Class Initialized
INFO - 2023-04-23 12:51:17 --> Output Class Initialized
INFO - 2023-04-23 12:51:17 --> Security Class Initialized
DEBUG - 2023-04-23 12:51:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-23 12:51:17 --> Input Class Initialized
INFO - 2023-04-23 12:51:17 --> Language Class Initialized
INFO - 2023-04-23 12:51:17 --> Loader Class Initialized
INFO - 2023-04-23 12:51:17 --> Helper loaded: url_helper
INFO - 2023-04-23 12:51:17 --> Helper loaded: file_helper
INFO - 2023-04-23 12:51:17 --> Helper loaded: html_helper
INFO - 2023-04-23 12:51:17 --> Helper loaded: text_helper
INFO - 2023-04-23 12:51:17 --> Helper loaded: form_helper
INFO - 2023-04-23 12:51:17 --> Helper loaded: lang_helper
INFO - 2023-04-23 12:51:17 --> Helper loaded: security_helper
INFO - 2023-04-23 12:51:17 --> Helper loaded: cookie_helper
INFO - 2023-04-23 12:51:17 --> Database Driver Class Initialized
INFO - 2023-04-23 12:51:17 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-23 12:51:17 --> Parser Class Initialized
INFO - 2023-04-23 12:51:17 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-23 12:51:17 --> Pagination Class Initialized
INFO - 2023-04-23 12:51:17 --> Form Validation Class Initialized
INFO - 2023-04-23 12:51:17 --> Controller Class Initialized
DEBUG - 2023-04-23 12:51:17 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-04-23 12:51:17 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-23 12:51:17 --> Model Class Initialized
INFO - 2023-04-23 12:51:17 --> Final output sent to browser
DEBUG - 2023-04-23 12:51:17 --> Total execution time: 0.0130
ERROR - 2023-04-23 12:51:28 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-23 12:51:28 --> Config Class Initialized
INFO - 2023-04-23 12:51:28 --> Hooks Class Initialized
DEBUG - 2023-04-23 12:51:28 --> UTF-8 Support Enabled
INFO - 2023-04-23 12:51:28 --> Utf8 Class Initialized
INFO - 2023-04-23 12:51:28 --> URI Class Initialized
INFO - 2023-04-23 12:51:28 --> Router Class Initialized
INFO - 2023-04-23 12:51:28 --> Output Class Initialized
INFO - 2023-04-23 12:51:28 --> Security Class Initialized
DEBUG - 2023-04-23 12:51:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-23 12:51:28 --> Input Class Initialized
INFO - 2023-04-23 12:51:28 --> Language Class Initialized
INFO - 2023-04-23 12:51:28 --> Loader Class Initialized
INFO - 2023-04-23 12:51:28 --> Helper loaded: url_helper
INFO - 2023-04-23 12:51:28 --> Helper loaded: file_helper
INFO - 2023-04-23 12:51:28 --> Helper loaded: html_helper
INFO - 2023-04-23 12:51:28 --> Helper loaded: text_helper
INFO - 2023-04-23 12:51:28 --> Helper loaded: form_helper
INFO - 2023-04-23 12:51:28 --> Helper loaded: lang_helper
INFO - 2023-04-23 12:51:28 --> Helper loaded: security_helper
INFO - 2023-04-23 12:51:28 --> Helper loaded: cookie_helper
INFO - 2023-04-23 12:51:28 --> Database Driver Class Initialized
INFO - 2023-04-23 12:51:28 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-23 12:51:28 --> Parser Class Initialized
INFO - 2023-04-23 12:51:28 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-23 12:51:28 --> Pagination Class Initialized
INFO - 2023-04-23 12:51:28 --> Form Validation Class Initialized
INFO - 2023-04-23 12:51:28 --> Controller Class Initialized
INFO - 2023-04-23 12:51:28 --> Model Class Initialized
INFO - 2023-04-23 12:51:28 --> Model Class Initialized
ERROR - 2023-04-23 12:51:28 --> Severity: Warning --> Invalid argument supplied for foreach() /home/powera7m/app.maurnaturo.com/application/views/purchase/add_purchase_form.php 157
INFO - 2023-04-23 12:51:28 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/purchase/add_purchase_form.php
DEBUG - 2023-04-23 12:51:28 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-04-23 12:51:28 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-04-23 12:51:28 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-04-23 12:51:28 --> Model Class Initialized
INFO - 2023-04-23 12:51:28 --> Model Class Initialized
INFO - 2023-04-23 12:51:28 --> Model Class Initialized
INFO - 2023-04-23 12:51:28 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-04-23 12:51:28 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-04-23 12:51:28 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-04-23 12:51:28 --> Final output sent to browser
DEBUG - 2023-04-23 12:51:28 --> Total execution time: 0.1641
ERROR - 2023-04-23 12:52:40 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-23 12:52:40 --> Config Class Initialized
INFO - 2023-04-23 12:52:40 --> Hooks Class Initialized
DEBUG - 2023-04-23 12:52:40 --> UTF-8 Support Enabled
INFO - 2023-04-23 12:52:40 --> Utf8 Class Initialized
INFO - 2023-04-23 12:52:40 --> URI Class Initialized
INFO - 2023-04-23 12:52:40 --> Router Class Initialized
INFO - 2023-04-23 12:52:40 --> Output Class Initialized
INFO - 2023-04-23 12:52:40 --> Security Class Initialized
DEBUG - 2023-04-23 12:52:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-23 12:52:40 --> Input Class Initialized
INFO - 2023-04-23 12:52:40 --> Language Class Initialized
INFO - 2023-04-23 12:52:40 --> Loader Class Initialized
INFO - 2023-04-23 12:52:40 --> Helper loaded: url_helper
INFO - 2023-04-23 12:52:40 --> Helper loaded: file_helper
INFO - 2023-04-23 12:52:40 --> Helper loaded: html_helper
INFO - 2023-04-23 12:52:40 --> Helper loaded: text_helper
INFO - 2023-04-23 12:52:40 --> Helper loaded: form_helper
INFO - 2023-04-23 12:52:40 --> Helper loaded: lang_helper
INFO - 2023-04-23 12:52:40 --> Helper loaded: security_helper
INFO - 2023-04-23 12:52:40 --> Helper loaded: cookie_helper
INFO - 2023-04-23 12:52:40 --> Database Driver Class Initialized
INFO - 2023-04-23 12:52:40 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-23 12:52:40 --> Parser Class Initialized
INFO - 2023-04-23 12:52:40 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-23 12:52:40 --> Pagination Class Initialized
INFO - 2023-04-23 12:52:40 --> Form Validation Class Initialized
INFO - 2023-04-23 12:52:40 --> Controller Class Initialized
DEBUG - 2023-04-23 12:52:40 --> Auth class already loaded. Second attempt ignored.
INFO - 2023-04-23 12:52:40 --> Model Class Initialized
INFO - 2023-04-23 12:52:40 --> Model Class Initialized
INFO - 2023-04-23 12:52:40 --> Model Class Initialized
INFO - 2023-04-23 12:52:40 --> Model Class Initialized
INFO - 2023-04-23 12:52:40 --> Model Class Initialized
INFO - 2023-04-23 12:52:40 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/product/add_product_form.php
DEBUG - 2023-04-23 12:52:40 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-04-23 12:52:40 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-04-23 12:52:40 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-04-23 12:52:40 --> Model Class Initialized
INFO - 2023-04-23 12:52:40 --> Model Class Initialized
INFO - 2023-04-23 12:52:40 --> Model Class Initialized
INFO - 2023-04-23 12:52:40 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-04-23 12:52:40 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-04-23 12:52:40 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-04-23 12:52:40 --> Final output sent to browser
DEBUG - 2023-04-23 12:52:40 --> Total execution time: 0.1702
ERROR - 2023-04-23 12:52:53 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-23 12:52:53 --> Config Class Initialized
INFO - 2023-04-23 12:52:53 --> Hooks Class Initialized
DEBUG - 2023-04-23 12:52:53 --> UTF-8 Support Enabled
INFO - 2023-04-23 12:52:53 --> Utf8 Class Initialized
INFO - 2023-04-23 12:52:53 --> URI Class Initialized
INFO - 2023-04-23 12:52:53 --> Router Class Initialized
INFO - 2023-04-23 12:52:53 --> Output Class Initialized
INFO - 2023-04-23 12:52:53 --> Security Class Initialized
DEBUG - 2023-04-23 12:52:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-23 12:52:53 --> Input Class Initialized
INFO - 2023-04-23 12:52:53 --> Language Class Initialized
INFO - 2023-04-23 12:52:53 --> Loader Class Initialized
INFO - 2023-04-23 12:52:53 --> Helper loaded: url_helper
INFO - 2023-04-23 12:52:53 --> Helper loaded: file_helper
INFO - 2023-04-23 12:52:53 --> Helper loaded: html_helper
INFO - 2023-04-23 12:52:53 --> Helper loaded: text_helper
INFO - 2023-04-23 12:52:53 --> Helper loaded: form_helper
INFO - 2023-04-23 12:52:53 --> Helper loaded: lang_helper
INFO - 2023-04-23 12:52:53 --> Helper loaded: security_helper
INFO - 2023-04-23 12:52:53 --> Helper loaded: cookie_helper
INFO - 2023-04-23 12:52:53 --> Database Driver Class Initialized
INFO - 2023-04-23 12:52:53 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-23 12:52:53 --> Parser Class Initialized
INFO - 2023-04-23 12:52:53 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-23 12:52:53 --> Pagination Class Initialized
INFO - 2023-04-23 12:52:53 --> Form Validation Class Initialized
INFO - 2023-04-23 12:52:53 --> Controller Class Initialized
INFO - 2023-04-23 12:52:53 --> Model Class Initialized
INFO - 2023-04-23 12:52:53 --> Model Class Initialized
ERROR - 2023-04-23 12:52:53 --> Severity: Warning --> Invalid argument supplied for foreach() /home/powera7m/app.maurnaturo.com/application/views/purchase/add_purchase_form.php 157
INFO - 2023-04-23 12:52:53 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/purchase/add_purchase_form.php
DEBUG - 2023-04-23 12:52:53 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-04-23 12:52:53 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-04-23 12:52:53 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-04-23 12:52:53 --> Model Class Initialized
INFO - 2023-04-23 12:52:53 --> Model Class Initialized
INFO - 2023-04-23 12:52:53 --> Model Class Initialized
INFO - 2023-04-23 12:52:54 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-04-23 12:52:54 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-04-23 12:52:54 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-04-23 12:52:54 --> Final output sent to browser
DEBUG - 2023-04-23 12:52:54 --> Total execution time: 0.2087
ERROR - 2023-04-23 14:29:08 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-23 14:29:08 --> Config Class Initialized
INFO - 2023-04-23 14:29:08 --> Hooks Class Initialized
DEBUG - 2023-04-23 14:29:08 --> UTF-8 Support Enabled
INFO - 2023-04-23 14:29:08 --> Utf8 Class Initialized
INFO - 2023-04-23 14:29:08 --> URI Class Initialized
DEBUG - 2023-04-23 14:29:08 --> No URI present. Default controller set.
INFO - 2023-04-23 14:29:08 --> Router Class Initialized
INFO - 2023-04-23 14:29:08 --> Output Class Initialized
INFO - 2023-04-23 14:29:08 --> Security Class Initialized
DEBUG - 2023-04-23 14:29:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-23 14:29:08 --> Input Class Initialized
INFO - 2023-04-23 14:29:08 --> Language Class Initialized
INFO - 2023-04-23 14:29:08 --> Loader Class Initialized
INFO - 2023-04-23 14:29:08 --> Helper loaded: url_helper
INFO - 2023-04-23 14:29:08 --> Helper loaded: file_helper
INFO - 2023-04-23 14:29:08 --> Helper loaded: html_helper
INFO - 2023-04-23 14:29:08 --> Helper loaded: text_helper
INFO - 2023-04-23 14:29:08 --> Helper loaded: form_helper
INFO - 2023-04-23 14:29:08 --> Helper loaded: lang_helper
INFO - 2023-04-23 14:29:08 --> Helper loaded: security_helper
INFO - 2023-04-23 14:29:08 --> Helper loaded: cookie_helper
INFO - 2023-04-23 14:29:08 --> Database Driver Class Initialized
INFO - 2023-04-23 14:29:08 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-23 14:29:08 --> Parser Class Initialized
INFO - 2023-04-23 14:29:08 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-23 14:29:08 --> Pagination Class Initialized
INFO - 2023-04-23 14:29:08 --> Form Validation Class Initialized
INFO - 2023-04-23 14:29:08 --> Controller Class Initialized
INFO - 2023-04-23 14:29:08 --> Model Class Initialized
DEBUG - 2023-04-23 14:29:08 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-23 14:29:08 --> Model Class Initialized
DEBUG - 2023-04-23 14:29:08 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-23 14:29:08 --> Model Class Initialized
INFO - 2023-04-23 14:29:08 --> Model Class Initialized
INFO - 2023-04-23 14:29:08 --> Model Class Initialized
INFO - 2023-04-23 14:29:08 --> Model Class Initialized
DEBUG - 2023-04-23 14:29:08 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-04-23 14:29:08 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-23 14:29:08 --> Model Class Initialized
INFO - 2023-04-23 14:29:08 --> Model Class Initialized
INFO - 2023-04-23 14:29:08 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-04-23 14:29:08 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-04-23 14:29:08 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-04-23 14:29:08 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-04-23 14:29:08 --> Model Class Initialized
INFO - 2023-04-23 14:29:08 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-04-23 14:29:08 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-04-23 14:29:08 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-04-23 14:29:08 --> Final output sent to browser
DEBUG - 2023-04-23 14:29:08 --> Total execution time: 0.1969
ERROR - 2023-04-23 14:29:15 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-23 14:29:15 --> Config Class Initialized
INFO - 2023-04-23 14:29:15 --> Hooks Class Initialized
DEBUG - 2023-04-23 14:29:15 --> UTF-8 Support Enabled
INFO - 2023-04-23 14:29:15 --> Utf8 Class Initialized
INFO - 2023-04-23 14:29:15 --> URI Class Initialized
INFO - 2023-04-23 14:29:15 --> Router Class Initialized
INFO - 2023-04-23 14:29:15 --> Output Class Initialized
INFO - 2023-04-23 14:29:15 --> Security Class Initialized
DEBUG - 2023-04-23 14:29:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-23 14:29:15 --> Input Class Initialized
INFO - 2023-04-23 14:29:15 --> Language Class Initialized
INFO - 2023-04-23 14:29:15 --> Loader Class Initialized
INFO - 2023-04-23 14:29:15 --> Helper loaded: url_helper
INFO - 2023-04-23 14:29:15 --> Helper loaded: file_helper
INFO - 2023-04-23 14:29:15 --> Helper loaded: html_helper
INFO - 2023-04-23 14:29:15 --> Helper loaded: text_helper
INFO - 2023-04-23 14:29:15 --> Helper loaded: form_helper
INFO - 2023-04-23 14:29:15 --> Helper loaded: lang_helper
INFO - 2023-04-23 14:29:15 --> Helper loaded: security_helper
INFO - 2023-04-23 14:29:15 --> Helper loaded: cookie_helper
INFO - 2023-04-23 14:29:15 --> Database Driver Class Initialized
INFO - 2023-04-23 14:29:15 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-23 14:29:15 --> Parser Class Initialized
INFO - 2023-04-23 14:29:15 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-23 14:29:15 --> Pagination Class Initialized
INFO - 2023-04-23 14:29:15 --> Form Validation Class Initialized
INFO - 2023-04-23 14:29:15 --> Controller Class Initialized
DEBUG - 2023-04-23 14:29:15 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-04-23 14:29:15 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-23 14:29:15 --> Model Class Initialized
DEBUG - 2023-04-23 14:29:15 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-23 14:29:15 --> Model Class Initialized
DEBUG - 2023-04-23 14:29:15 --> Lcustomer class already loaded. Second attempt ignored.
INFO - 2023-04-23 14:29:15 --> Model Class Initialized
INFO - 2023-04-23 14:29:15 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/customer/customer.php
DEBUG - 2023-04-23 14:29:15 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-04-23 14:29:15 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-04-23 14:29:15 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-04-23 14:29:15 --> Model Class Initialized
INFO - 2023-04-23 14:29:15 --> Model Class Initialized
INFO - 2023-04-23 14:29:15 --> Model Class Initialized
INFO - 2023-04-23 14:29:15 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-04-23 14:29:15 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-04-23 14:29:15 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-04-23 14:29:15 --> Final output sent to browser
DEBUG - 2023-04-23 14:29:15 --> Total execution time: 0.1368
ERROR - 2023-04-23 14:29:16 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-23 14:29:16 --> Config Class Initialized
INFO - 2023-04-23 14:29:16 --> Hooks Class Initialized
DEBUG - 2023-04-23 14:29:16 --> UTF-8 Support Enabled
INFO - 2023-04-23 14:29:16 --> Utf8 Class Initialized
INFO - 2023-04-23 14:29:16 --> URI Class Initialized
INFO - 2023-04-23 14:29:16 --> Router Class Initialized
INFO - 2023-04-23 14:29:16 --> Output Class Initialized
INFO - 2023-04-23 14:29:16 --> Security Class Initialized
DEBUG - 2023-04-23 14:29:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-23 14:29:16 --> Input Class Initialized
INFO - 2023-04-23 14:29:16 --> Language Class Initialized
INFO - 2023-04-23 14:29:16 --> Loader Class Initialized
INFO - 2023-04-23 14:29:16 --> Helper loaded: url_helper
INFO - 2023-04-23 14:29:16 --> Helper loaded: file_helper
INFO - 2023-04-23 14:29:16 --> Helper loaded: html_helper
INFO - 2023-04-23 14:29:16 --> Helper loaded: text_helper
INFO - 2023-04-23 14:29:16 --> Helper loaded: form_helper
INFO - 2023-04-23 14:29:16 --> Helper loaded: lang_helper
INFO - 2023-04-23 14:29:16 --> Helper loaded: security_helper
INFO - 2023-04-23 14:29:16 --> Helper loaded: cookie_helper
INFO - 2023-04-23 14:29:16 --> Database Driver Class Initialized
INFO - 2023-04-23 14:29:16 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-23 14:29:16 --> Parser Class Initialized
INFO - 2023-04-23 14:29:16 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-23 14:29:16 --> Pagination Class Initialized
INFO - 2023-04-23 14:29:16 --> Form Validation Class Initialized
INFO - 2023-04-23 14:29:16 --> Controller Class Initialized
DEBUG - 2023-04-23 14:29:16 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-04-23 14:29:16 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-23 14:29:16 --> Model Class Initialized
DEBUG - 2023-04-23 14:29:16 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-23 14:29:16 --> Model Class Initialized
INFO - 2023-04-23 14:29:16 --> Final output sent to browser
DEBUG - 2023-04-23 14:29:16 --> Total execution time: 0.0328
ERROR - 2023-04-23 14:29:24 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-23 14:29:24 --> Config Class Initialized
INFO - 2023-04-23 14:29:24 --> Hooks Class Initialized
DEBUG - 2023-04-23 14:29:24 --> UTF-8 Support Enabled
INFO - 2023-04-23 14:29:24 --> Utf8 Class Initialized
INFO - 2023-04-23 14:29:24 --> URI Class Initialized
INFO - 2023-04-23 14:29:24 --> Router Class Initialized
INFO - 2023-04-23 14:29:24 --> Output Class Initialized
INFO - 2023-04-23 14:29:24 --> Security Class Initialized
DEBUG - 2023-04-23 14:29:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-23 14:29:24 --> Input Class Initialized
INFO - 2023-04-23 14:29:24 --> Language Class Initialized
INFO - 2023-04-23 14:29:24 --> Loader Class Initialized
INFO - 2023-04-23 14:29:24 --> Helper loaded: url_helper
INFO - 2023-04-23 14:29:24 --> Helper loaded: file_helper
INFO - 2023-04-23 14:29:24 --> Helper loaded: html_helper
INFO - 2023-04-23 14:29:24 --> Helper loaded: text_helper
INFO - 2023-04-23 14:29:24 --> Helper loaded: form_helper
INFO - 2023-04-23 14:29:24 --> Helper loaded: lang_helper
INFO - 2023-04-23 14:29:24 --> Helper loaded: security_helper
INFO - 2023-04-23 14:29:24 --> Helper loaded: cookie_helper
INFO - 2023-04-23 14:29:24 --> Database Driver Class Initialized
INFO - 2023-04-23 14:29:24 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-23 14:29:24 --> Parser Class Initialized
INFO - 2023-04-23 14:29:24 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-23 14:29:24 --> Pagination Class Initialized
INFO - 2023-04-23 14:29:24 --> Form Validation Class Initialized
INFO - 2023-04-23 14:29:24 --> Controller Class Initialized
DEBUG - 2023-04-23 14:29:24 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-04-23 14:29:24 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-23 14:29:24 --> Model Class Initialized
DEBUG - 2023-04-23 14:29:24 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-23 14:29:24 --> Model Class Initialized
INFO - 2023-04-23 14:29:24 --> Final output sent to browser
DEBUG - 2023-04-23 14:29:24 --> Total execution time: 0.0793
ERROR - 2023-04-23 14:31:02 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-23 14:31:02 --> Config Class Initialized
INFO - 2023-04-23 14:31:02 --> Hooks Class Initialized
DEBUG - 2023-04-23 14:31:02 --> UTF-8 Support Enabled
INFO - 2023-04-23 14:31:02 --> Utf8 Class Initialized
INFO - 2023-04-23 14:31:02 --> URI Class Initialized
INFO - 2023-04-23 14:31:02 --> Router Class Initialized
INFO - 2023-04-23 14:31:02 --> Output Class Initialized
INFO - 2023-04-23 14:31:02 --> Security Class Initialized
DEBUG - 2023-04-23 14:31:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-23 14:31:02 --> Input Class Initialized
INFO - 2023-04-23 14:31:02 --> Language Class Initialized
INFO - 2023-04-23 14:31:02 --> Loader Class Initialized
INFO - 2023-04-23 14:31:02 --> Helper loaded: url_helper
INFO - 2023-04-23 14:31:02 --> Helper loaded: file_helper
INFO - 2023-04-23 14:31:02 --> Helper loaded: html_helper
INFO - 2023-04-23 14:31:02 --> Helper loaded: text_helper
INFO - 2023-04-23 14:31:02 --> Helper loaded: form_helper
INFO - 2023-04-23 14:31:02 --> Helper loaded: lang_helper
INFO - 2023-04-23 14:31:02 --> Helper loaded: security_helper
INFO - 2023-04-23 14:31:02 --> Helper loaded: cookie_helper
INFO - 2023-04-23 14:31:02 --> Database Driver Class Initialized
INFO - 2023-04-23 14:31:02 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-23 14:31:02 --> Parser Class Initialized
INFO - 2023-04-23 14:31:02 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-23 14:31:02 --> Pagination Class Initialized
INFO - 2023-04-23 14:31:02 --> Form Validation Class Initialized
INFO - 2023-04-23 14:31:02 --> Controller Class Initialized
DEBUG - 2023-04-23 14:31:02 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-04-23 14:31:02 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-23 14:31:02 --> Model Class Initialized
DEBUG - 2023-04-23 14:31:02 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-23 14:31:02 --> Model Class Initialized
INFO - 2023-04-23 14:31:03 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/customer/add_customer_form.php
DEBUG - 2023-04-23 14:31:03 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-04-23 14:31:03 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-04-23 14:31:03 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-04-23 14:31:03 --> Model Class Initialized
INFO - 2023-04-23 14:31:03 --> Model Class Initialized
INFO - 2023-04-23 14:31:03 --> Model Class Initialized
INFO - 2023-04-23 14:31:03 --> Model Class Initialized
INFO - 2023-04-23 14:31:03 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-04-23 14:31:03 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-04-23 14:31:03 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-04-23 14:31:03 --> Final output sent to browser
DEBUG - 2023-04-23 14:31:03 --> Total execution time: 0.4631
ERROR - 2023-04-23 14:31:07 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-23 14:31:07 --> Config Class Initialized
INFO - 2023-04-23 14:31:07 --> Hooks Class Initialized
DEBUG - 2023-04-23 14:31:07 --> UTF-8 Support Enabled
INFO - 2023-04-23 14:31:07 --> Utf8 Class Initialized
INFO - 2023-04-23 14:31:07 --> URI Class Initialized
INFO - 2023-04-23 14:31:07 --> Router Class Initialized
INFO - 2023-04-23 14:31:07 --> Output Class Initialized
INFO - 2023-04-23 14:31:07 --> Security Class Initialized
DEBUG - 2023-04-23 14:31:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-23 14:31:07 --> Input Class Initialized
INFO - 2023-04-23 14:31:07 --> Language Class Initialized
INFO - 2023-04-23 14:31:07 --> Loader Class Initialized
INFO - 2023-04-23 14:31:07 --> Helper loaded: url_helper
INFO - 2023-04-23 14:31:07 --> Helper loaded: file_helper
INFO - 2023-04-23 14:31:07 --> Helper loaded: html_helper
INFO - 2023-04-23 14:31:07 --> Helper loaded: text_helper
INFO - 2023-04-23 14:31:07 --> Helper loaded: form_helper
INFO - 2023-04-23 14:31:07 --> Helper loaded: lang_helper
INFO - 2023-04-23 14:31:07 --> Helper loaded: security_helper
INFO - 2023-04-23 14:31:07 --> Helper loaded: cookie_helper
INFO - 2023-04-23 14:31:07 --> Database Driver Class Initialized
INFO - 2023-04-23 14:31:07 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-23 14:31:07 --> Parser Class Initialized
INFO - 2023-04-23 14:31:07 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-23 14:31:07 --> Pagination Class Initialized
INFO - 2023-04-23 14:31:07 --> Form Validation Class Initialized
INFO - 2023-04-23 14:31:07 --> Controller Class Initialized
INFO - 2023-04-23 14:31:07 --> Model Class Initialized
INFO - 2023-04-23 14:31:07 --> Final output sent to browser
DEBUG - 2023-04-23 14:31:07 --> Total execution time: 0.0135
ERROR - 2023-04-23 14:38:04 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-23 14:38:04 --> Config Class Initialized
INFO - 2023-04-23 14:38:04 --> Hooks Class Initialized
DEBUG - 2023-04-23 14:38:04 --> UTF-8 Support Enabled
INFO - 2023-04-23 14:38:04 --> Utf8 Class Initialized
INFO - 2023-04-23 14:38:04 --> URI Class Initialized
INFO - 2023-04-23 14:38:04 --> Router Class Initialized
INFO - 2023-04-23 14:38:04 --> Output Class Initialized
INFO - 2023-04-23 14:38:04 --> Security Class Initialized
DEBUG - 2023-04-23 14:38:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-23 14:38:04 --> Input Class Initialized
INFO - 2023-04-23 14:38:04 --> Language Class Initialized
INFO - 2023-04-23 14:38:04 --> Loader Class Initialized
INFO - 2023-04-23 14:38:04 --> Helper loaded: url_helper
INFO - 2023-04-23 14:38:04 --> Helper loaded: file_helper
INFO - 2023-04-23 14:38:04 --> Helper loaded: html_helper
INFO - 2023-04-23 14:38:04 --> Helper loaded: text_helper
INFO - 2023-04-23 14:38:04 --> Helper loaded: form_helper
INFO - 2023-04-23 14:38:04 --> Helper loaded: lang_helper
INFO - 2023-04-23 14:38:04 --> Helper loaded: security_helper
INFO - 2023-04-23 14:38:04 --> Helper loaded: cookie_helper
INFO - 2023-04-23 14:38:04 --> Database Driver Class Initialized
INFO - 2023-04-23 14:38:04 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-23 14:38:04 --> Parser Class Initialized
INFO - 2023-04-23 14:38:04 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-23 14:38:04 --> Pagination Class Initialized
INFO - 2023-04-23 14:38:04 --> Form Validation Class Initialized
INFO - 2023-04-23 14:38:04 --> Controller Class Initialized
DEBUG - 2023-04-23 14:38:04 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-04-23 14:38:04 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-23 14:38:04 --> Model Class Initialized
DEBUG - 2023-04-23 14:38:04 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-23 14:38:04 --> Model Class Initialized
DEBUG - 2023-04-23 14:38:04 --> Auth class already loaded. Second attempt ignored.
INFO - 2023-04-23 14:38:04 --> Email Class Initialized
INFO - 2023-04-23 14:38:04 --> Language file loaded: language/english/email_lang.php
ERROR - 2023-04-23 14:38:04 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-23 14:38:04 --> Config Class Initialized
INFO - 2023-04-23 14:38:04 --> Hooks Class Initialized
DEBUG - 2023-04-23 14:38:04 --> UTF-8 Support Enabled
INFO - 2023-04-23 14:38:04 --> Utf8 Class Initialized
INFO - 2023-04-23 14:38:04 --> URI Class Initialized
INFO - 2023-04-23 14:38:04 --> Router Class Initialized
INFO - 2023-04-23 14:38:04 --> Output Class Initialized
INFO - 2023-04-23 14:38:04 --> Security Class Initialized
DEBUG - 2023-04-23 14:38:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-23 14:38:04 --> Input Class Initialized
INFO - 2023-04-23 14:38:04 --> Language Class Initialized
INFO - 2023-04-23 14:38:04 --> Loader Class Initialized
INFO - 2023-04-23 14:38:04 --> Helper loaded: url_helper
INFO - 2023-04-23 14:38:04 --> Helper loaded: file_helper
INFO - 2023-04-23 14:38:04 --> Helper loaded: html_helper
INFO - 2023-04-23 14:38:04 --> Helper loaded: text_helper
INFO - 2023-04-23 14:38:04 --> Helper loaded: form_helper
INFO - 2023-04-23 14:38:04 --> Helper loaded: lang_helper
INFO - 2023-04-23 14:38:04 --> Helper loaded: security_helper
INFO - 2023-04-23 14:38:04 --> Helper loaded: cookie_helper
INFO - 2023-04-23 14:38:04 --> Database Driver Class Initialized
INFO - 2023-04-23 14:38:04 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-23 14:38:04 --> Parser Class Initialized
INFO - 2023-04-23 14:38:04 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-23 14:38:04 --> Pagination Class Initialized
INFO - 2023-04-23 14:38:04 --> Form Validation Class Initialized
INFO - 2023-04-23 14:38:04 --> Controller Class Initialized
DEBUG - 2023-04-23 14:38:04 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-04-23 14:38:04 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-23 14:38:04 --> Model Class Initialized
DEBUG - 2023-04-23 14:38:04 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-23 14:38:04 --> Model Class Initialized
DEBUG - 2023-04-23 14:38:04 --> Lcustomer class already loaded. Second attempt ignored.
INFO - 2023-04-23 14:38:04 --> Model Class Initialized
INFO - 2023-04-23 14:38:04 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/customer/customer.php
DEBUG - 2023-04-23 14:38:04 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-04-23 14:38:04 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-04-23 14:38:04 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-04-23 14:38:04 --> Model Class Initialized
INFO - 2023-04-23 14:38:04 --> Model Class Initialized
INFO - 2023-04-23 14:38:04 --> Model Class Initialized
INFO - 2023-04-23 14:38:04 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-04-23 14:38:04 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-04-23 14:38:04 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-04-23 14:38:04 --> Final output sent to browser
DEBUG - 2023-04-23 14:38:04 --> Total execution time: 0.1295
ERROR - 2023-04-23 14:38:05 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-23 14:38:05 --> Config Class Initialized
INFO - 2023-04-23 14:38:05 --> Hooks Class Initialized
DEBUG - 2023-04-23 14:38:05 --> UTF-8 Support Enabled
INFO - 2023-04-23 14:38:05 --> Utf8 Class Initialized
INFO - 2023-04-23 14:38:05 --> URI Class Initialized
INFO - 2023-04-23 14:38:05 --> Router Class Initialized
INFO - 2023-04-23 14:38:05 --> Output Class Initialized
INFO - 2023-04-23 14:38:05 --> Security Class Initialized
DEBUG - 2023-04-23 14:38:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-23 14:38:05 --> Input Class Initialized
INFO - 2023-04-23 14:38:05 --> Language Class Initialized
INFO - 2023-04-23 14:38:05 --> Loader Class Initialized
INFO - 2023-04-23 14:38:05 --> Helper loaded: url_helper
INFO - 2023-04-23 14:38:05 --> Helper loaded: file_helper
INFO - 2023-04-23 14:38:05 --> Helper loaded: html_helper
INFO - 2023-04-23 14:38:05 --> Helper loaded: text_helper
INFO - 2023-04-23 14:38:05 --> Helper loaded: form_helper
INFO - 2023-04-23 14:38:05 --> Helper loaded: lang_helper
INFO - 2023-04-23 14:38:05 --> Helper loaded: security_helper
INFO - 2023-04-23 14:38:05 --> Helper loaded: cookie_helper
INFO - 2023-04-23 14:38:05 --> Database Driver Class Initialized
INFO - 2023-04-23 14:38:05 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-23 14:38:05 --> Parser Class Initialized
INFO - 2023-04-23 14:38:05 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-23 14:38:05 --> Pagination Class Initialized
INFO - 2023-04-23 14:38:05 --> Form Validation Class Initialized
INFO - 2023-04-23 14:38:05 --> Controller Class Initialized
DEBUG - 2023-04-23 14:38:05 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-04-23 14:38:05 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-23 14:38:05 --> Model Class Initialized
DEBUG - 2023-04-23 14:38:05 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-23 14:38:05 --> Model Class Initialized
INFO - 2023-04-23 14:38:05 --> Final output sent to browser
DEBUG - 2023-04-23 14:38:05 --> Total execution time: 0.0289
ERROR - 2023-04-23 14:38:11 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-23 14:38:11 --> Config Class Initialized
INFO - 2023-04-23 14:38:11 --> Hooks Class Initialized
DEBUG - 2023-04-23 14:38:11 --> UTF-8 Support Enabled
INFO - 2023-04-23 14:38:11 --> Utf8 Class Initialized
INFO - 2023-04-23 14:38:11 --> URI Class Initialized
INFO - 2023-04-23 14:38:11 --> Router Class Initialized
INFO - 2023-04-23 14:38:11 --> Output Class Initialized
INFO - 2023-04-23 14:38:11 --> Security Class Initialized
DEBUG - 2023-04-23 14:38:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-23 14:38:11 --> Input Class Initialized
INFO - 2023-04-23 14:38:11 --> Language Class Initialized
INFO - 2023-04-23 14:38:11 --> Loader Class Initialized
INFO - 2023-04-23 14:38:11 --> Helper loaded: url_helper
INFO - 2023-04-23 14:38:11 --> Helper loaded: file_helper
INFO - 2023-04-23 14:38:11 --> Helper loaded: html_helper
INFO - 2023-04-23 14:38:11 --> Helper loaded: text_helper
INFO - 2023-04-23 14:38:11 --> Helper loaded: form_helper
INFO - 2023-04-23 14:38:11 --> Helper loaded: lang_helper
INFO - 2023-04-23 14:38:11 --> Helper loaded: security_helper
INFO - 2023-04-23 14:38:11 --> Helper loaded: cookie_helper
INFO - 2023-04-23 14:38:11 --> Database Driver Class Initialized
INFO - 2023-04-23 14:38:11 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-23 14:38:11 --> Parser Class Initialized
INFO - 2023-04-23 14:38:11 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-23 14:38:11 --> Pagination Class Initialized
INFO - 2023-04-23 14:38:11 --> Form Validation Class Initialized
INFO - 2023-04-23 14:38:11 --> Controller Class Initialized
DEBUG - 2023-04-23 14:38:11 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-04-23 14:38:11 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-23 14:38:11 --> Model Class Initialized
DEBUG - 2023-04-23 14:38:11 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-23 14:38:11 --> Model Class Initialized
INFO - 2023-04-23 14:38:11 --> Final output sent to browser
DEBUG - 2023-04-23 14:38:11 --> Total execution time: 0.0788
ERROR - 2023-04-23 14:38:57 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-23 14:38:57 --> Config Class Initialized
INFO - 2023-04-23 14:38:57 --> Hooks Class Initialized
DEBUG - 2023-04-23 14:38:57 --> UTF-8 Support Enabled
INFO - 2023-04-23 14:38:57 --> Utf8 Class Initialized
INFO - 2023-04-23 14:38:57 --> URI Class Initialized
DEBUG - 2023-04-23 14:38:57 --> No URI present. Default controller set.
INFO - 2023-04-23 14:38:57 --> Router Class Initialized
INFO - 2023-04-23 14:38:57 --> Output Class Initialized
INFO - 2023-04-23 14:38:57 --> Security Class Initialized
DEBUG - 2023-04-23 14:38:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-23 14:38:57 --> Input Class Initialized
INFO - 2023-04-23 14:38:57 --> Language Class Initialized
INFO - 2023-04-23 14:38:57 --> Loader Class Initialized
INFO - 2023-04-23 14:38:57 --> Helper loaded: url_helper
INFO - 2023-04-23 14:38:57 --> Helper loaded: file_helper
INFO - 2023-04-23 14:38:57 --> Helper loaded: html_helper
INFO - 2023-04-23 14:38:57 --> Helper loaded: text_helper
INFO - 2023-04-23 14:38:57 --> Helper loaded: form_helper
INFO - 2023-04-23 14:38:57 --> Helper loaded: lang_helper
INFO - 2023-04-23 14:38:57 --> Helper loaded: security_helper
INFO - 2023-04-23 14:38:57 --> Helper loaded: cookie_helper
INFO - 2023-04-23 14:38:57 --> Database Driver Class Initialized
INFO - 2023-04-23 14:38:57 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-23 14:38:57 --> Parser Class Initialized
INFO - 2023-04-23 14:38:57 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-23 14:38:57 --> Pagination Class Initialized
INFO - 2023-04-23 14:38:57 --> Form Validation Class Initialized
INFO - 2023-04-23 14:38:57 --> Controller Class Initialized
INFO - 2023-04-23 14:38:57 --> Model Class Initialized
DEBUG - 2023-04-23 14:38:57 --> Session class already loaded. Second attempt ignored.
ERROR - 2023-04-23 14:38:57 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-23 14:38:57 --> Config Class Initialized
INFO - 2023-04-23 14:38:57 --> Hooks Class Initialized
DEBUG - 2023-04-23 14:38:57 --> UTF-8 Support Enabled
INFO - 2023-04-23 14:38:57 --> Utf8 Class Initialized
INFO - 2023-04-23 14:38:57 --> URI Class Initialized
INFO - 2023-04-23 14:38:57 --> Router Class Initialized
INFO - 2023-04-23 14:38:57 --> Output Class Initialized
INFO - 2023-04-23 14:38:57 --> Security Class Initialized
DEBUG - 2023-04-23 14:38:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-23 14:38:57 --> Input Class Initialized
INFO - 2023-04-23 14:38:57 --> Language Class Initialized
INFO - 2023-04-23 14:38:57 --> Loader Class Initialized
INFO - 2023-04-23 14:38:57 --> Helper loaded: url_helper
INFO - 2023-04-23 14:38:57 --> Helper loaded: file_helper
INFO - 2023-04-23 14:38:57 --> Helper loaded: html_helper
INFO - 2023-04-23 14:38:57 --> Helper loaded: text_helper
INFO - 2023-04-23 14:38:57 --> Helper loaded: form_helper
INFO - 2023-04-23 14:38:57 --> Helper loaded: lang_helper
INFO - 2023-04-23 14:38:57 --> Helper loaded: security_helper
INFO - 2023-04-23 14:38:57 --> Helper loaded: cookie_helper
INFO - 2023-04-23 14:38:57 --> Database Driver Class Initialized
INFO - 2023-04-23 14:38:57 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-23 14:38:57 --> Parser Class Initialized
INFO - 2023-04-23 14:38:57 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-23 14:38:57 --> Pagination Class Initialized
INFO - 2023-04-23 14:38:57 --> Form Validation Class Initialized
INFO - 2023-04-23 14:38:57 --> Controller Class Initialized
INFO - 2023-04-23 14:38:57 --> Model Class Initialized
DEBUG - 2023-04-23 14:38:57 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-23 14:38:57 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2023-04-23 14:38:57 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-04-23 14:38:57 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-04-23 14:38:57 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-04-23 14:38:57 --> Model Class Initialized
INFO - 2023-04-23 14:38:57 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-04-23 14:38:57 --> Final output sent to browser
DEBUG - 2023-04-23 14:38:57 --> Total execution time: 0.0293
ERROR - 2023-04-23 14:39:03 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-23 14:39:03 --> Config Class Initialized
INFO - 2023-04-23 14:39:03 --> Hooks Class Initialized
DEBUG - 2023-04-23 14:39:03 --> UTF-8 Support Enabled
INFO - 2023-04-23 14:39:03 --> Utf8 Class Initialized
INFO - 2023-04-23 14:39:03 --> URI Class Initialized
INFO - 2023-04-23 14:39:03 --> Router Class Initialized
INFO - 2023-04-23 14:39:03 --> Output Class Initialized
INFO - 2023-04-23 14:39:03 --> Security Class Initialized
DEBUG - 2023-04-23 14:39:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-23 14:39:03 --> Input Class Initialized
INFO - 2023-04-23 14:39:03 --> Language Class Initialized
INFO - 2023-04-23 14:39:03 --> Loader Class Initialized
INFO - 2023-04-23 14:39:03 --> Helper loaded: url_helper
INFO - 2023-04-23 14:39:03 --> Helper loaded: file_helper
INFO - 2023-04-23 14:39:03 --> Helper loaded: html_helper
INFO - 2023-04-23 14:39:03 --> Helper loaded: text_helper
INFO - 2023-04-23 14:39:03 --> Helper loaded: form_helper
INFO - 2023-04-23 14:39:03 --> Helper loaded: lang_helper
INFO - 2023-04-23 14:39:03 --> Helper loaded: security_helper
INFO - 2023-04-23 14:39:03 --> Helper loaded: cookie_helper
INFO - 2023-04-23 14:39:03 --> Database Driver Class Initialized
INFO - 2023-04-23 14:39:03 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-23 14:39:03 --> Parser Class Initialized
INFO - 2023-04-23 14:39:03 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-23 14:39:03 --> Pagination Class Initialized
INFO - 2023-04-23 14:39:03 --> Form Validation Class Initialized
INFO - 2023-04-23 14:39:03 --> Controller Class Initialized
DEBUG - 2023-04-23 14:39:03 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-04-23 14:39:03 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-23 14:39:03 --> Model Class Initialized
DEBUG - 2023-04-23 14:39:03 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-23 14:39:03 --> Model Class Initialized
INFO - 2023-04-23 14:39:03 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/customer/view_customer.php
DEBUG - 2023-04-23 14:39:03 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-04-23 14:39:03 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-04-23 14:39:03 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-04-23 14:39:03 --> Model Class Initialized
INFO - 2023-04-23 14:39:03 --> Model Class Initialized
INFO - 2023-04-23 14:39:03 --> Model Class Initialized
INFO - 2023-04-23 14:39:03 --> Model Class Initialized
INFO - 2023-04-23 14:39:03 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-04-23 14:39:03 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-04-23 14:39:03 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-04-23 14:39:03 --> Final output sent to browser
DEBUG - 2023-04-23 14:39:03 --> Total execution time: 0.1315
ERROR - 2023-04-23 14:39:29 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-23 14:39:29 --> Config Class Initialized
INFO - 2023-04-23 14:39:29 --> Hooks Class Initialized
DEBUG - 2023-04-23 14:39:29 --> UTF-8 Support Enabled
INFO - 2023-04-23 14:39:29 --> Utf8 Class Initialized
INFO - 2023-04-23 14:39:29 --> URI Class Initialized
INFO - 2023-04-23 14:39:29 --> Router Class Initialized
INFO - 2023-04-23 14:39:29 --> Output Class Initialized
INFO - 2023-04-23 14:39:29 --> Security Class Initialized
DEBUG - 2023-04-23 14:39:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-23 14:39:29 --> Input Class Initialized
INFO - 2023-04-23 14:39:29 --> Language Class Initialized
INFO - 2023-04-23 14:39:29 --> Loader Class Initialized
INFO - 2023-04-23 14:39:29 --> Helper loaded: url_helper
INFO - 2023-04-23 14:39:29 --> Helper loaded: file_helper
INFO - 2023-04-23 14:39:29 --> Helper loaded: html_helper
INFO - 2023-04-23 14:39:29 --> Helper loaded: text_helper
INFO - 2023-04-23 14:39:29 --> Helper loaded: form_helper
INFO - 2023-04-23 14:39:29 --> Helper loaded: lang_helper
INFO - 2023-04-23 14:39:29 --> Helper loaded: security_helper
INFO - 2023-04-23 14:39:29 --> Helper loaded: cookie_helper
INFO - 2023-04-23 14:39:29 --> Database Driver Class Initialized
INFO - 2023-04-23 14:39:29 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-23 14:39:29 --> Parser Class Initialized
INFO - 2023-04-23 14:39:29 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-23 14:39:29 --> Pagination Class Initialized
INFO - 2023-04-23 14:39:29 --> Form Validation Class Initialized
INFO - 2023-04-23 14:39:29 --> Controller Class Initialized
INFO - 2023-04-23 14:39:29 --> Model Class Initialized
DEBUG - 2023-04-23 14:39:29 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-23 14:39:29 --> Model Class Initialized
INFO - 2023-04-23 14:39:29 --> Final output sent to browser
DEBUG - 2023-04-23 14:39:29 --> Total execution time: 0.0191
ERROR - 2023-04-23 14:39:29 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-23 14:39:29 --> Config Class Initialized
INFO - 2023-04-23 14:39:29 --> Hooks Class Initialized
DEBUG - 2023-04-23 14:39:29 --> UTF-8 Support Enabled
INFO - 2023-04-23 14:39:29 --> Utf8 Class Initialized
INFO - 2023-04-23 14:39:29 --> URI Class Initialized
DEBUG - 2023-04-23 14:39:29 --> No URI present. Default controller set.
INFO - 2023-04-23 14:39:29 --> Router Class Initialized
INFO - 2023-04-23 14:39:29 --> Output Class Initialized
INFO - 2023-04-23 14:39:29 --> Security Class Initialized
DEBUG - 2023-04-23 14:39:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-23 14:39:29 --> Input Class Initialized
INFO - 2023-04-23 14:39:29 --> Language Class Initialized
INFO - 2023-04-23 14:39:29 --> Loader Class Initialized
INFO - 2023-04-23 14:39:29 --> Helper loaded: url_helper
INFO - 2023-04-23 14:39:29 --> Helper loaded: file_helper
INFO - 2023-04-23 14:39:29 --> Helper loaded: html_helper
INFO - 2023-04-23 14:39:29 --> Helper loaded: text_helper
INFO - 2023-04-23 14:39:29 --> Helper loaded: form_helper
INFO - 2023-04-23 14:39:29 --> Helper loaded: lang_helper
INFO - 2023-04-23 14:39:29 --> Helper loaded: security_helper
INFO - 2023-04-23 14:39:29 --> Helper loaded: cookie_helper
INFO - 2023-04-23 14:39:29 --> Database Driver Class Initialized
INFO - 2023-04-23 14:39:29 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-23 14:39:29 --> Parser Class Initialized
INFO - 2023-04-23 14:39:29 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-23 14:39:29 --> Pagination Class Initialized
INFO - 2023-04-23 14:39:29 --> Form Validation Class Initialized
INFO - 2023-04-23 14:39:29 --> Controller Class Initialized
INFO - 2023-04-23 14:39:29 --> Model Class Initialized
DEBUG - 2023-04-23 14:39:29 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-23 14:39:29 --> Model Class Initialized
DEBUG - 2023-04-23 14:39:29 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-23 14:39:29 --> Model Class Initialized
INFO - 2023-04-23 14:39:29 --> Model Class Initialized
INFO - 2023-04-23 14:39:29 --> Model Class Initialized
INFO - 2023-04-23 14:39:29 --> Model Class Initialized
DEBUG - 2023-04-23 14:39:29 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-04-23 14:39:29 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-23 14:39:29 --> Model Class Initialized
INFO - 2023-04-23 14:39:29 --> Model Class Initialized
INFO - 2023-04-23 14:39:29 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-04-23 14:39:29 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-04-23 14:39:29 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-04-23 14:39:29 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-04-23 14:39:29 --> Model Class Initialized
INFO - 2023-04-23 14:39:29 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-04-23 14:39:29 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-04-23 14:39:29 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-04-23 14:39:29 --> Final output sent to browser
DEBUG - 2023-04-23 14:39:29 --> Total execution time: 0.0610
ERROR - 2023-04-23 14:39:41 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-23 14:39:41 --> Config Class Initialized
INFO - 2023-04-23 14:39:41 --> Hooks Class Initialized
DEBUG - 2023-04-23 14:39:41 --> UTF-8 Support Enabled
INFO - 2023-04-23 14:39:41 --> Utf8 Class Initialized
INFO - 2023-04-23 14:39:41 --> URI Class Initialized
INFO - 2023-04-23 14:39:41 --> Router Class Initialized
INFO - 2023-04-23 14:39:41 --> Output Class Initialized
INFO - 2023-04-23 14:39:41 --> Security Class Initialized
DEBUG - 2023-04-23 14:39:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-23 14:39:41 --> Input Class Initialized
INFO - 2023-04-23 14:39:41 --> Language Class Initialized
INFO - 2023-04-23 14:39:41 --> Loader Class Initialized
INFO - 2023-04-23 14:39:41 --> Helper loaded: url_helper
INFO - 2023-04-23 14:39:41 --> Helper loaded: file_helper
INFO - 2023-04-23 14:39:41 --> Helper loaded: html_helper
INFO - 2023-04-23 14:39:41 --> Helper loaded: text_helper
INFO - 2023-04-23 14:39:41 --> Helper loaded: form_helper
INFO - 2023-04-23 14:39:41 --> Helper loaded: lang_helper
INFO - 2023-04-23 14:39:41 --> Helper loaded: security_helper
INFO - 2023-04-23 14:39:41 --> Helper loaded: cookie_helper
INFO - 2023-04-23 14:39:41 --> Database Driver Class Initialized
INFO - 2023-04-23 14:39:41 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-23 14:39:41 --> Parser Class Initialized
INFO - 2023-04-23 14:39:41 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-23 14:39:41 --> Pagination Class Initialized
INFO - 2023-04-23 14:39:41 --> Form Validation Class Initialized
INFO - 2023-04-23 14:39:41 --> Controller Class Initialized
INFO - 2023-04-23 14:39:41 --> Model Class Initialized
DEBUG - 2023-04-23 14:39:41 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-04-23 14:39:41 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-23 14:39:41 --> Model Class Initialized
DEBUG - 2023-04-23 14:39:41 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-23 14:39:41 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/demandrequest/add_demandrequest_form.php
DEBUG - 2023-04-23 14:39:41 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-04-23 14:39:41 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-04-23 14:39:41 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-04-23 14:39:41 --> Model Class Initialized
INFO - 2023-04-23 14:39:41 --> Model Class Initialized
INFO - 2023-04-23 14:39:41 --> Model Class Initialized
INFO - 2023-04-23 14:39:41 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-04-23 14:39:41 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-04-23 14:39:41 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-04-23 14:39:41 --> Final output sent to browser
DEBUG - 2023-04-23 14:39:41 --> Total execution time: 0.0655
ERROR - 2023-04-23 14:40:02 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-23 14:40:02 --> Config Class Initialized
INFO - 2023-04-23 14:40:02 --> Hooks Class Initialized
DEBUG - 2023-04-23 14:40:02 --> UTF-8 Support Enabled
INFO - 2023-04-23 14:40:02 --> Utf8 Class Initialized
INFO - 2023-04-23 14:40:02 --> URI Class Initialized
INFO - 2023-04-23 14:40:02 --> Router Class Initialized
INFO - 2023-04-23 14:40:02 --> Output Class Initialized
INFO - 2023-04-23 14:40:02 --> Security Class Initialized
DEBUG - 2023-04-23 14:40:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-23 14:40:02 --> Input Class Initialized
INFO - 2023-04-23 14:40:02 --> Language Class Initialized
INFO - 2023-04-23 14:40:02 --> Loader Class Initialized
INFO - 2023-04-23 14:40:02 --> Helper loaded: url_helper
INFO - 2023-04-23 14:40:02 --> Helper loaded: file_helper
INFO - 2023-04-23 14:40:02 --> Helper loaded: html_helper
INFO - 2023-04-23 14:40:02 --> Helper loaded: text_helper
INFO - 2023-04-23 14:40:02 --> Helper loaded: form_helper
INFO - 2023-04-23 14:40:02 --> Helper loaded: lang_helper
INFO - 2023-04-23 14:40:02 --> Helper loaded: security_helper
INFO - 2023-04-23 14:40:02 --> Helper loaded: cookie_helper
INFO - 2023-04-23 14:40:02 --> Database Driver Class Initialized
INFO - 2023-04-23 14:40:02 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-23 14:40:02 --> Parser Class Initialized
INFO - 2023-04-23 14:40:02 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-23 14:40:02 --> Pagination Class Initialized
INFO - 2023-04-23 14:40:02 --> Form Validation Class Initialized
INFO - 2023-04-23 14:40:02 --> Controller Class Initialized
INFO - 2023-04-23 14:40:02 --> Model Class Initialized
DEBUG - 2023-04-23 14:40:02 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-04-23 14:40:02 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-23 14:40:02 --> Model Class Initialized
DEBUG - 2023-04-23 14:40:02 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-23 14:40:02 --> Model Class Initialized
INFO - 2023-04-23 14:40:02 --> Final output sent to browser
DEBUG - 2023-04-23 14:40:02 --> Total execution time: 0.0217
ERROR - 2023-04-23 14:40:03 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-23 14:40:03 --> Config Class Initialized
INFO - 2023-04-23 14:40:03 --> Hooks Class Initialized
DEBUG - 2023-04-23 14:40:03 --> UTF-8 Support Enabled
INFO - 2023-04-23 14:40:03 --> Utf8 Class Initialized
INFO - 2023-04-23 14:40:03 --> URI Class Initialized
INFO - 2023-04-23 14:40:03 --> Router Class Initialized
INFO - 2023-04-23 14:40:03 --> Output Class Initialized
INFO - 2023-04-23 14:40:03 --> Security Class Initialized
DEBUG - 2023-04-23 14:40:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-23 14:40:03 --> Input Class Initialized
INFO - 2023-04-23 14:40:03 --> Language Class Initialized
INFO - 2023-04-23 14:40:03 --> Loader Class Initialized
INFO - 2023-04-23 14:40:03 --> Helper loaded: url_helper
INFO - 2023-04-23 14:40:03 --> Helper loaded: file_helper
INFO - 2023-04-23 14:40:03 --> Helper loaded: html_helper
INFO - 2023-04-23 14:40:03 --> Helper loaded: text_helper
INFO - 2023-04-23 14:40:03 --> Helper loaded: form_helper
INFO - 2023-04-23 14:40:03 --> Helper loaded: lang_helper
INFO - 2023-04-23 14:40:03 --> Helper loaded: security_helper
INFO - 2023-04-23 14:40:03 --> Helper loaded: cookie_helper
INFO - 2023-04-23 14:40:03 --> Database Driver Class Initialized
INFO - 2023-04-23 14:40:03 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-23 14:40:03 --> Parser Class Initialized
INFO - 2023-04-23 14:40:03 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-23 14:40:03 --> Pagination Class Initialized
INFO - 2023-04-23 14:40:03 --> Form Validation Class Initialized
INFO - 2023-04-23 14:40:03 --> Controller Class Initialized
INFO - 2023-04-23 14:40:03 --> Model Class Initialized
DEBUG - 2023-04-23 14:40:03 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-04-23 14:40:03 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-23 14:40:03 --> Model Class Initialized
DEBUG - 2023-04-23 14:40:03 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-23 14:40:03 --> Model Class Initialized
INFO - 2023-04-23 14:40:03 --> Final output sent to browser
DEBUG - 2023-04-23 14:40:03 --> Total execution time: 0.0195
ERROR - 2023-04-23 14:40:04 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-23 14:40:04 --> Config Class Initialized
INFO - 2023-04-23 14:40:04 --> Hooks Class Initialized
DEBUG - 2023-04-23 14:40:04 --> UTF-8 Support Enabled
INFO - 2023-04-23 14:40:04 --> Utf8 Class Initialized
INFO - 2023-04-23 14:40:04 --> URI Class Initialized
INFO - 2023-04-23 14:40:04 --> Router Class Initialized
INFO - 2023-04-23 14:40:04 --> Output Class Initialized
INFO - 2023-04-23 14:40:04 --> Security Class Initialized
DEBUG - 2023-04-23 14:40:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-23 14:40:04 --> Input Class Initialized
INFO - 2023-04-23 14:40:04 --> Language Class Initialized
INFO - 2023-04-23 14:40:04 --> Loader Class Initialized
INFO - 2023-04-23 14:40:04 --> Helper loaded: url_helper
INFO - 2023-04-23 14:40:04 --> Helper loaded: file_helper
INFO - 2023-04-23 14:40:04 --> Helper loaded: html_helper
INFO - 2023-04-23 14:40:04 --> Helper loaded: text_helper
INFO - 2023-04-23 14:40:04 --> Helper loaded: form_helper
INFO - 2023-04-23 14:40:04 --> Helper loaded: lang_helper
INFO - 2023-04-23 14:40:04 --> Helper loaded: security_helper
INFO - 2023-04-23 14:40:04 --> Helper loaded: cookie_helper
INFO - 2023-04-23 14:40:04 --> Database Driver Class Initialized
INFO - 2023-04-23 14:40:04 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-23 14:40:04 --> Parser Class Initialized
INFO - 2023-04-23 14:40:04 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-23 14:40:04 --> Pagination Class Initialized
INFO - 2023-04-23 14:40:04 --> Form Validation Class Initialized
INFO - 2023-04-23 14:40:04 --> Controller Class Initialized
INFO - 2023-04-23 14:40:04 --> Model Class Initialized
DEBUG - 2023-04-23 14:40:04 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-04-23 14:40:04 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-23 14:40:04 --> Model Class Initialized
DEBUG - 2023-04-23 14:40:04 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-23 14:40:04 --> Model Class Initialized
INFO - 2023-04-23 14:40:04 --> Final output sent to browser
DEBUG - 2023-04-23 14:40:04 --> Total execution time: 0.0176
ERROR - 2023-04-23 14:40:05 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-23 14:40:05 --> Config Class Initialized
INFO - 2023-04-23 14:40:05 --> Hooks Class Initialized
DEBUG - 2023-04-23 14:40:05 --> UTF-8 Support Enabled
INFO - 2023-04-23 14:40:05 --> Utf8 Class Initialized
INFO - 2023-04-23 14:40:05 --> URI Class Initialized
INFO - 2023-04-23 14:40:05 --> Router Class Initialized
INFO - 2023-04-23 14:40:05 --> Output Class Initialized
INFO - 2023-04-23 14:40:05 --> Security Class Initialized
DEBUG - 2023-04-23 14:40:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-23 14:40:05 --> Input Class Initialized
INFO - 2023-04-23 14:40:05 --> Language Class Initialized
INFO - 2023-04-23 14:40:05 --> Loader Class Initialized
INFO - 2023-04-23 14:40:05 --> Helper loaded: url_helper
INFO - 2023-04-23 14:40:05 --> Helper loaded: file_helper
INFO - 2023-04-23 14:40:05 --> Helper loaded: html_helper
INFO - 2023-04-23 14:40:05 --> Helper loaded: text_helper
INFO - 2023-04-23 14:40:05 --> Helper loaded: form_helper
INFO - 2023-04-23 14:40:05 --> Helper loaded: lang_helper
INFO - 2023-04-23 14:40:05 --> Helper loaded: security_helper
INFO - 2023-04-23 14:40:05 --> Helper loaded: cookie_helper
INFO - 2023-04-23 14:40:05 --> Database Driver Class Initialized
INFO - 2023-04-23 14:40:05 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-23 14:40:05 --> Parser Class Initialized
INFO - 2023-04-23 14:40:05 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-23 14:40:05 --> Pagination Class Initialized
INFO - 2023-04-23 14:40:05 --> Form Validation Class Initialized
INFO - 2023-04-23 14:40:05 --> Controller Class Initialized
INFO - 2023-04-23 14:40:05 --> Model Class Initialized
DEBUG - 2023-04-23 14:40:05 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-04-23 14:40:05 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-23 14:40:05 --> Model Class Initialized
DEBUG - 2023-04-23 14:40:05 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-23 14:40:05 --> Model Class Initialized
INFO - 2023-04-23 14:40:05 --> Final output sent to browser
DEBUG - 2023-04-23 14:40:05 --> Total execution time: 0.0177
ERROR - 2023-04-23 14:40:06 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-23 14:40:06 --> Config Class Initialized
INFO - 2023-04-23 14:40:06 --> Hooks Class Initialized
DEBUG - 2023-04-23 14:40:06 --> UTF-8 Support Enabled
INFO - 2023-04-23 14:40:06 --> Utf8 Class Initialized
INFO - 2023-04-23 14:40:06 --> URI Class Initialized
INFO - 2023-04-23 14:40:06 --> Router Class Initialized
INFO - 2023-04-23 14:40:06 --> Output Class Initialized
INFO - 2023-04-23 14:40:06 --> Security Class Initialized
DEBUG - 2023-04-23 14:40:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-23 14:40:06 --> Input Class Initialized
INFO - 2023-04-23 14:40:06 --> Language Class Initialized
INFO - 2023-04-23 14:40:06 --> Loader Class Initialized
INFO - 2023-04-23 14:40:06 --> Helper loaded: url_helper
INFO - 2023-04-23 14:40:06 --> Helper loaded: file_helper
INFO - 2023-04-23 14:40:06 --> Helper loaded: html_helper
INFO - 2023-04-23 14:40:06 --> Helper loaded: text_helper
INFO - 2023-04-23 14:40:06 --> Helper loaded: form_helper
INFO - 2023-04-23 14:40:06 --> Helper loaded: lang_helper
INFO - 2023-04-23 14:40:06 --> Helper loaded: security_helper
INFO - 2023-04-23 14:40:06 --> Helper loaded: cookie_helper
INFO - 2023-04-23 14:40:06 --> Database Driver Class Initialized
INFO - 2023-04-23 14:40:06 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-23 14:40:06 --> Parser Class Initialized
INFO - 2023-04-23 14:40:06 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-23 14:40:06 --> Pagination Class Initialized
INFO - 2023-04-23 14:40:06 --> Form Validation Class Initialized
INFO - 2023-04-23 14:40:06 --> Controller Class Initialized
INFO - 2023-04-23 14:40:06 --> Model Class Initialized
DEBUG - 2023-04-23 14:40:06 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-04-23 14:40:06 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-23 14:40:06 --> Model Class Initialized
DEBUG - 2023-04-23 14:40:06 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-23 14:40:06 --> Model Class Initialized
INFO - 2023-04-23 14:40:06 --> Final output sent to browser
DEBUG - 2023-04-23 14:40:06 --> Total execution time: 0.0164
ERROR - 2023-04-23 14:40:09 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-23 14:40:09 --> Config Class Initialized
INFO - 2023-04-23 14:40:09 --> Hooks Class Initialized
DEBUG - 2023-04-23 14:40:09 --> UTF-8 Support Enabled
INFO - 2023-04-23 14:40:09 --> Utf8 Class Initialized
INFO - 2023-04-23 14:40:09 --> URI Class Initialized
INFO - 2023-04-23 14:40:09 --> Router Class Initialized
INFO - 2023-04-23 14:40:09 --> Output Class Initialized
INFO - 2023-04-23 14:40:09 --> Security Class Initialized
DEBUG - 2023-04-23 14:40:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-23 14:40:09 --> Input Class Initialized
INFO - 2023-04-23 14:40:09 --> Language Class Initialized
INFO - 2023-04-23 14:40:09 --> Loader Class Initialized
INFO - 2023-04-23 14:40:09 --> Helper loaded: url_helper
INFO - 2023-04-23 14:40:09 --> Helper loaded: file_helper
INFO - 2023-04-23 14:40:09 --> Helper loaded: html_helper
INFO - 2023-04-23 14:40:09 --> Helper loaded: text_helper
INFO - 2023-04-23 14:40:09 --> Helper loaded: form_helper
INFO - 2023-04-23 14:40:09 --> Helper loaded: lang_helper
INFO - 2023-04-23 14:40:09 --> Helper loaded: security_helper
INFO - 2023-04-23 14:40:09 --> Helper loaded: cookie_helper
INFO - 2023-04-23 14:40:09 --> Database Driver Class Initialized
INFO - 2023-04-23 14:40:09 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-23 14:40:09 --> Parser Class Initialized
INFO - 2023-04-23 14:40:09 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-23 14:40:09 --> Pagination Class Initialized
INFO - 2023-04-23 14:40:09 --> Form Validation Class Initialized
INFO - 2023-04-23 14:40:09 --> Controller Class Initialized
INFO - 2023-04-23 14:40:09 --> Model Class Initialized
DEBUG - 2023-04-23 14:40:09 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-04-23 14:40:09 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-23 14:40:09 --> Model Class Initialized
INFO - 2023-04-23 14:40:09 --> Model Class Initialized
INFO - 2023-04-23 14:40:09 --> Final output sent to browser
DEBUG - 2023-04-23 14:40:09 --> Total execution time: 0.0240
ERROR - 2023-04-23 14:40:21 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-23 14:40:21 --> Config Class Initialized
INFO - 2023-04-23 14:40:21 --> Hooks Class Initialized
DEBUG - 2023-04-23 14:40:21 --> UTF-8 Support Enabled
INFO - 2023-04-23 14:40:21 --> Utf8 Class Initialized
INFO - 2023-04-23 14:40:21 --> URI Class Initialized
INFO - 2023-04-23 14:40:21 --> Router Class Initialized
INFO - 2023-04-23 14:40:21 --> Output Class Initialized
INFO - 2023-04-23 14:40:21 --> Security Class Initialized
DEBUG - 2023-04-23 14:40:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-23 14:40:21 --> Input Class Initialized
INFO - 2023-04-23 14:40:21 --> Language Class Initialized
INFO - 2023-04-23 14:40:21 --> Loader Class Initialized
INFO - 2023-04-23 14:40:21 --> Helper loaded: url_helper
INFO - 2023-04-23 14:40:21 --> Helper loaded: file_helper
INFO - 2023-04-23 14:40:21 --> Helper loaded: html_helper
INFO - 2023-04-23 14:40:21 --> Helper loaded: text_helper
INFO - 2023-04-23 14:40:21 --> Helper loaded: form_helper
INFO - 2023-04-23 14:40:21 --> Helper loaded: lang_helper
INFO - 2023-04-23 14:40:21 --> Helper loaded: security_helper
INFO - 2023-04-23 14:40:21 --> Helper loaded: cookie_helper
INFO - 2023-04-23 14:40:21 --> Database Driver Class Initialized
INFO - 2023-04-23 14:40:21 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-23 14:40:21 --> Parser Class Initialized
INFO - 2023-04-23 14:40:21 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-23 14:40:21 --> Pagination Class Initialized
INFO - 2023-04-23 14:40:21 --> Form Validation Class Initialized
INFO - 2023-04-23 14:40:21 --> Controller Class Initialized
INFO - 2023-04-23 14:40:21 --> Model Class Initialized
DEBUG - 2023-04-23 14:40:21 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-04-23 14:40:21 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-23 14:40:21 --> Model Class Initialized
DEBUG - 2023-04-23 14:40:21 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-23 14:40:21 --> Model Class Initialized
INFO - 2023-04-23 14:40:21 --> Final output sent to browser
DEBUG - 2023-04-23 14:40:21 --> Total execution time: 0.0201
ERROR - 2023-04-23 14:40:22 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-23 14:40:22 --> Config Class Initialized
INFO - 2023-04-23 14:40:22 --> Hooks Class Initialized
DEBUG - 2023-04-23 14:40:22 --> UTF-8 Support Enabled
INFO - 2023-04-23 14:40:22 --> Utf8 Class Initialized
INFO - 2023-04-23 14:40:22 --> URI Class Initialized
INFO - 2023-04-23 14:40:22 --> Router Class Initialized
INFO - 2023-04-23 14:40:22 --> Output Class Initialized
INFO - 2023-04-23 14:40:22 --> Security Class Initialized
DEBUG - 2023-04-23 14:40:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-23 14:40:22 --> Input Class Initialized
INFO - 2023-04-23 14:40:22 --> Language Class Initialized
INFO - 2023-04-23 14:40:22 --> Loader Class Initialized
INFO - 2023-04-23 14:40:22 --> Helper loaded: url_helper
INFO - 2023-04-23 14:40:22 --> Helper loaded: file_helper
INFO - 2023-04-23 14:40:22 --> Helper loaded: html_helper
INFO - 2023-04-23 14:40:22 --> Helper loaded: text_helper
INFO - 2023-04-23 14:40:22 --> Helper loaded: form_helper
INFO - 2023-04-23 14:40:22 --> Helper loaded: lang_helper
INFO - 2023-04-23 14:40:22 --> Helper loaded: security_helper
INFO - 2023-04-23 14:40:22 --> Helper loaded: cookie_helper
INFO - 2023-04-23 14:40:22 --> Database Driver Class Initialized
INFO - 2023-04-23 14:40:22 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-23 14:40:22 --> Parser Class Initialized
INFO - 2023-04-23 14:40:22 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-23 14:40:22 --> Pagination Class Initialized
INFO - 2023-04-23 14:40:22 --> Form Validation Class Initialized
INFO - 2023-04-23 14:40:22 --> Controller Class Initialized
INFO - 2023-04-23 14:40:22 --> Model Class Initialized
DEBUG - 2023-04-23 14:40:22 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-04-23 14:40:22 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-23 14:40:22 --> Model Class Initialized
DEBUG - 2023-04-23 14:40:22 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-23 14:40:22 --> Model Class Initialized
INFO - 2023-04-23 14:40:22 --> Final output sent to browser
DEBUG - 2023-04-23 14:40:22 --> Total execution time: 0.0173
ERROR - 2023-04-23 14:40:23 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-23 14:40:23 --> Config Class Initialized
INFO - 2023-04-23 14:40:23 --> Hooks Class Initialized
DEBUG - 2023-04-23 14:40:23 --> UTF-8 Support Enabled
INFO - 2023-04-23 14:40:23 --> Utf8 Class Initialized
INFO - 2023-04-23 14:40:23 --> URI Class Initialized
INFO - 2023-04-23 14:40:23 --> Router Class Initialized
INFO - 2023-04-23 14:40:23 --> Output Class Initialized
INFO - 2023-04-23 14:40:23 --> Security Class Initialized
DEBUG - 2023-04-23 14:40:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-23 14:40:23 --> Input Class Initialized
INFO - 2023-04-23 14:40:23 --> Language Class Initialized
INFO - 2023-04-23 14:40:23 --> Loader Class Initialized
INFO - 2023-04-23 14:40:23 --> Helper loaded: url_helper
INFO - 2023-04-23 14:40:23 --> Helper loaded: file_helper
INFO - 2023-04-23 14:40:23 --> Helper loaded: html_helper
INFO - 2023-04-23 14:40:23 --> Helper loaded: text_helper
INFO - 2023-04-23 14:40:23 --> Helper loaded: form_helper
INFO - 2023-04-23 14:40:23 --> Helper loaded: lang_helper
INFO - 2023-04-23 14:40:23 --> Helper loaded: security_helper
INFO - 2023-04-23 14:40:23 --> Helper loaded: cookie_helper
INFO - 2023-04-23 14:40:23 --> Database Driver Class Initialized
INFO - 2023-04-23 14:40:23 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-23 14:40:23 --> Parser Class Initialized
INFO - 2023-04-23 14:40:23 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-23 14:40:23 --> Pagination Class Initialized
INFO - 2023-04-23 14:40:23 --> Form Validation Class Initialized
INFO - 2023-04-23 14:40:23 --> Controller Class Initialized
INFO - 2023-04-23 14:40:23 --> Model Class Initialized
DEBUG - 2023-04-23 14:40:23 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-04-23 14:40:23 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-23 14:40:23 --> Model Class Initialized
DEBUG - 2023-04-23 14:40:23 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-23 14:40:23 --> Model Class Initialized
INFO - 2023-04-23 14:40:23 --> Final output sent to browser
DEBUG - 2023-04-23 14:40:23 --> Total execution time: 0.0179
ERROR - 2023-04-23 14:40:26 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-23 14:40:26 --> Config Class Initialized
INFO - 2023-04-23 14:40:26 --> Hooks Class Initialized
DEBUG - 2023-04-23 14:40:26 --> UTF-8 Support Enabled
INFO - 2023-04-23 14:40:26 --> Utf8 Class Initialized
INFO - 2023-04-23 14:40:26 --> URI Class Initialized
INFO - 2023-04-23 14:40:26 --> Router Class Initialized
INFO - 2023-04-23 14:40:26 --> Output Class Initialized
INFO - 2023-04-23 14:40:26 --> Security Class Initialized
DEBUG - 2023-04-23 14:40:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-23 14:40:26 --> Input Class Initialized
INFO - 2023-04-23 14:40:26 --> Language Class Initialized
INFO - 2023-04-23 14:40:26 --> Loader Class Initialized
INFO - 2023-04-23 14:40:26 --> Helper loaded: url_helper
INFO - 2023-04-23 14:40:26 --> Helper loaded: file_helper
INFO - 2023-04-23 14:40:26 --> Helper loaded: html_helper
INFO - 2023-04-23 14:40:26 --> Helper loaded: text_helper
INFO - 2023-04-23 14:40:26 --> Helper loaded: form_helper
INFO - 2023-04-23 14:40:26 --> Helper loaded: lang_helper
INFO - 2023-04-23 14:40:26 --> Helper loaded: security_helper
INFO - 2023-04-23 14:40:26 --> Helper loaded: cookie_helper
INFO - 2023-04-23 14:40:26 --> Database Driver Class Initialized
INFO - 2023-04-23 14:40:26 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-23 14:40:26 --> Parser Class Initialized
INFO - 2023-04-23 14:40:26 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-23 14:40:26 --> Pagination Class Initialized
INFO - 2023-04-23 14:40:26 --> Form Validation Class Initialized
INFO - 2023-04-23 14:40:26 --> Controller Class Initialized
INFO - 2023-04-23 14:40:26 --> Model Class Initialized
DEBUG - 2023-04-23 14:40:26 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-04-23 14:40:26 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-23 14:40:26 --> Model Class Initialized
INFO - 2023-04-23 14:40:26 --> Model Class Initialized
INFO - 2023-04-23 14:40:26 --> Final output sent to browser
DEBUG - 2023-04-23 14:40:26 --> Total execution time: 0.0207
ERROR - 2023-04-23 14:40:35 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-23 14:40:35 --> Config Class Initialized
INFO - 2023-04-23 14:40:35 --> Hooks Class Initialized
DEBUG - 2023-04-23 14:40:35 --> UTF-8 Support Enabled
INFO - 2023-04-23 14:40:35 --> Utf8 Class Initialized
INFO - 2023-04-23 14:40:35 --> URI Class Initialized
INFO - 2023-04-23 14:40:35 --> Router Class Initialized
INFO - 2023-04-23 14:40:35 --> Output Class Initialized
INFO - 2023-04-23 14:40:35 --> Security Class Initialized
DEBUG - 2023-04-23 14:40:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-23 14:40:35 --> Input Class Initialized
INFO - 2023-04-23 14:40:35 --> Language Class Initialized
INFO - 2023-04-23 14:40:35 --> Loader Class Initialized
INFO - 2023-04-23 14:40:35 --> Helper loaded: url_helper
INFO - 2023-04-23 14:40:35 --> Helper loaded: file_helper
INFO - 2023-04-23 14:40:35 --> Helper loaded: html_helper
INFO - 2023-04-23 14:40:35 --> Helper loaded: text_helper
INFO - 2023-04-23 14:40:35 --> Helper loaded: form_helper
INFO - 2023-04-23 14:40:35 --> Helper loaded: lang_helper
INFO - 2023-04-23 14:40:35 --> Helper loaded: security_helper
INFO - 2023-04-23 14:40:35 --> Helper loaded: cookie_helper
INFO - 2023-04-23 14:40:35 --> Database Driver Class Initialized
INFO - 2023-04-23 14:40:35 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-23 14:40:35 --> Parser Class Initialized
INFO - 2023-04-23 14:40:35 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-23 14:40:35 --> Pagination Class Initialized
INFO - 2023-04-23 14:40:35 --> Form Validation Class Initialized
INFO - 2023-04-23 14:40:35 --> Controller Class Initialized
INFO - 2023-04-23 14:40:35 --> Model Class Initialized
DEBUG - 2023-04-23 14:40:35 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-04-23 14:40:35 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-23 14:40:35 --> Model Class Initialized
DEBUG - 2023-04-23 14:40:35 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-23 14:40:35 --> Model Class Initialized
INFO - 2023-04-23 14:40:35 --> Final output sent to browser
DEBUG - 2023-04-23 14:40:35 --> Total execution time: 0.0205
ERROR - 2023-04-23 14:40:36 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-23 14:40:36 --> Config Class Initialized
INFO - 2023-04-23 14:40:36 --> Hooks Class Initialized
DEBUG - 2023-04-23 14:40:36 --> UTF-8 Support Enabled
INFO - 2023-04-23 14:40:36 --> Utf8 Class Initialized
INFO - 2023-04-23 14:40:36 --> URI Class Initialized
INFO - 2023-04-23 14:40:36 --> Router Class Initialized
INFO - 2023-04-23 14:40:36 --> Output Class Initialized
INFO - 2023-04-23 14:40:36 --> Security Class Initialized
DEBUG - 2023-04-23 14:40:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-23 14:40:36 --> Input Class Initialized
INFO - 2023-04-23 14:40:36 --> Language Class Initialized
INFO - 2023-04-23 14:40:36 --> Loader Class Initialized
INFO - 2023-04-23 14:40:36 --> Helper loaded: url_helper
INFO - 2023-04-23 14:40:36 --> Helper loaded: file_helper
INFO - 2023-04-23 14:40:36 --> Helper loaded: html_helper
INFO - 2023-04-23 14:40:36 --> Helper loaded: text_helper
INFO - 2023-04-23 14:40:36 --> Helper loaded: form_helper
INFO - 2023-04-23 14:40:36 --> Helper loaded: lang_helper
INFO - 2023-04-23 14:40:36 --> Helper loaded: security_helper
INFO - 2023-04-23 14:40:36 --> Helper loaded: cookie_helper
INFO - 2023-04-23 14:40:36 --> Database Driver Class Initialized
INFO - 2023-04-23 14:40:36 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-23 14:40:36 --> Parser Class Initialized
INFO - 2023-04-23 14:40:36 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-23 14:40:36 --> Pagination Class Initialized
INFO - 2023-04-23 14:40:36 --> Form Validation Class Initialized
INFO - 2023-04-23 14:40:36 --> Controller Class Initialized
INFO - 2023-04-23 14:40:36 --> Model Class Initialized
DEBUG - 2023-04-23 14:40:36 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-04-23 14:40:36 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-23 14:40:36 --> Model Class Initialized
DEBUG - 2023-04-23 14:40:36 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-23 14:40:36 --> Model Class Initialized
INFO - 2023-04-23 14:40:36 --> Final output sent to browser
DEBUG - 2023-04-23 14:40:36 --> Total execution time: 0.0200
ERROR - 2023-04-23 14:40:36 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-23 14:40:36 --> Config Class Initialized
INFO - 2023-04-23 14:40:36 --> Hooks Class Initialized
DEBUG - 2023-04-23 14:40:36 --> UTF-8 Support Enabled
INFO - 2023-04-23 14:40:36 --> Utf8 Class Initialized
INFO - 2023-04-23 14:40:36 --> URI Class Initialized
INFO - 2023-04-23 14:40:36 --> Router Class Initialized
INFO - 2023-04-23 14:40:36 --> Output Class Initialized
INFO - 2023-04-23 14:40:36 --> Security Class Initialized
DEBUG - 2023-04-23 14:40:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-23 14:40:36 --> Input Class Initialized
INFO - 2023-04-23 14:40:36 --> Language Class Initialized
INFO - 2023-04-23 14:40:36 --> Loader Class Initialized
INFO - 2023-04-23 14:40:36 --> Helper loaded: url_helper
INFO - 2023-04-23 14:40:36 --> Helper loaded: file_helper
INFO - 2023-04-23 14:40:36 --> Helper loaded: html_helper
INFO - 2023-04-23 14:40:36 --> Helper loaded: text_helper
INFO - 2023-04-23 14:40:36 --> Helper loaded: form_helper
INFO - 2023-04-23 14:40:36 --> Helper loaded: lang_helper
INFO - 2023-04-23 14:40:36 --> Helper loaded: security_helper
INFO - 2023-04-23 14:40:36 --> Helper loaded: cookie_helper
INFO - 2023-04-23 14:40:36 --> Database Driver Class Initialized
INFO - 2023-04-23 14:40:36 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-23 14:40:36 --> Parser Class Initialized
INFO - 2023-04-23 14:40:36 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-23 14:40:36 --> Pagination Class Initialized
INFO - 2023-04-23 14:40:36 --> Form Validation Class Initialized
INFO - 2023-04-23 14:40:36 --> Controller Class Initialized
INFO - 2023-04-23 14:40:36 --> Model Class Initialized
DEBUG - 2023-04-23 14:40:36 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-04-23 14:40:36 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-23 14:40:36 --> Model Class Initialized
DEBUG - 2023-04-23 14:40:36 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-23 14:40:36 --> Model Class Initialized
INFO - 2023-04-23 14:40:36 --> Final output sent to browser
DEBUG - 2023-04-23 14:40:36 --> Total execution time: 0.0174
ERROR - 2023-04-23 14:40:38 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-23 14:40:38 --> Config Class Initialized
INFO - 2023-04-23 14:40:38 --> Hooks Class Initialized
DEBUG - 2023-04-23 14:40:38 --> UTF-8 Support Enabled
INFO - 2023-04-23 14:40:38 --> Utf8 Class Initialized
INFO - 2023-04-23 14:40:38 --> URI Class Initialized
INFO - 2023-04-23 14:40:38 --> Router Class Initialized
INFO - 2023-04-23 14:40:38 --> Output Class Initialized
INFO - 2023-04-23 14:40:38 --> Security Class Initialized
DEBUG - 2023-04-23 14:40:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-23 14:40:38 --> Input Class Initialized
INFO - 2023-04-23 14:40:38 --> Language Class Initialized
INFO - 2023-04-23 14:40:38 --> Loader Class Initialized
INFO - 2023-04-23 14:40:38 --> Helper loaded: url_helper
INFO - 2023-04-23 14:40:38 --> Helper loaded: file_helper
INFO - 2023-04-23 14:40:38 --> Helper loaded: html_helper
INFO - 2023-04-23 14:40:38 --> Helper loaded: text_helper
INFO - 2023-04-23 14:40:38 --> Helper loaded: form_helper
INFO - 2023-04-23 14:40:38 --> Helper loaded: lang_helper
INFO - 2023-04-23 14:40:38 --> Helper loaded: security_helper
INFO - 2023-04-23 14:40:38 --> Helper loaded: cookie_helper
INFO - 2023-04-23 14:40:38 --> Database Driver Class Initialized
INFO - 2023-04-23 14:40:38 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-23 14:40:38 --> Parser Class Initialized
INFO - 2023-04-23 14:40:38 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-23 14:40:38 --> Pagination Class Initialized
INFO - 2023-04-23 14:40:38 --> Form Validation Class Initialized
INFO - 2023-04-23 14:40:38 --> Controller Class Initialized
INFO - 2023-04-23 14:40:38 --> Model Class Initialized
DEBUG - 2023-04-23 14:40:38 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-04-23 14:40:38 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-23 14:40:38 --> Model Class Initialized
DEBUG - 2023-04-23 14:40:38 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-23 14:40:38 --> Model Class Initialized
INFO - 2023-04-23 14:40:38 --> Final output sent to browser
DEBUG - 2023-04-23 14:40:38 --> Total execution time: 0.0171
ERROR - 2023-04-23 14:40:39 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-23 14:40:39 --> Config Class Initialized
INFO - 2023-04-23 14:40:39 --> Hooks Class Initialized
DEBUG - 2023-04-23 14:40:39 --> UTF-8 Support Enabled
INFO - 2023-04-23 14:40:39 --> Utf8 Class Initialized
INFO - 2023-04-23 14:40:39 --> URI Class Initialized
INFO - 2023-04-23 14:40:39 --> Router Class Initialized
INFO - 2023-04-23 14:40:39 --> Output Class Initialized
INFO - 2023-04-23 14:40:39 --> Security Class Initialized
DEBUG - 2023-04-23 14:40:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-23 14:40:39 --> Input Class Initialized
INFO - 2023-04-23 14:40:39 --> Language Class Initialized
INFO - 2023-04-23 14:40:39 --> Loader Class Initialized
INFO - 2023-04-23 14:40:39 --> Helper loaded: url_helper
INFO - 2023-04-23 14:40:39 --> Helper loaded: file_helper
INFO - 2023-04-23 14:40:39 --> Helper loaded: html_helper
INFO - 2023-04-23 14:40:39 --> Helper loaded: text_helper
INFO - 2023-04-23 14:40:39 --> Helper loaded: form_helper
INFO - 2023-04-23 14:40:39 --> Helper loaded: lang_helper
INFO - 2023-04-23 14:40:39 --> Helper loaded: security_helper
INFO - 2023-04-23 14:40:39 --> Helper loaded: cookie_helper
INFO - 2023-04-23 14:40:39 --> Database Driver Class Initialized
INFO - 2023-04-23 14:40:39 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-23 14:40:39 --> Parser Class Initialized
INFO - 2023-04-23 14:40:39 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-23 14:40:39 --> Pagination Class Initialized
INFO - 2023-04-23 14:40:39 --> Form Validation Class Initialized
INFO - 2023-04-23 14:40:39 --> Controller Class Initialized
INFO - 2023-04-23 14:40:39 --> Model Class Initialized
DEBUG - 2023-04-23 14:40:39 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-04-23 14:40:39 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-23 14:40:39 --> Model Class Initialized
DEBUG - 2023-04-23 14:40:39 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-23 14:40:39 --> Model Class Initialized
INFO - 2023-04-23 14:40:39 --> Final output sent to browser
DEBUG - 2023-04-23 14:40:39 --> Total execution time: 0.0163
ERROR - 2023-04-23 14:40:42 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-23 14:40:42 --> Config Class Initialized
INFO - 2023-04-23 14:40:42 --> Hooks Class Initialized
DEBUG - 2023-04-23 14:40:42 --> UTF-8 Support Enabled
INFO - 2023-04-23 14:40:42 --> Utf8 Class Initialized
INFO - 2023-04-23 14:40:42 --> URI Class Initialized
INFO - 2023-04-23 14:40:42 --> Router Class Initialized
INFO - 2023-04-23 14:40:42 --> Output Class Initialized
INFO - 2023-04-23 14:40:42 --> Security Class Initialized
DEBUG - 2023-04-23 14:40:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-23 14:40:42 --> Input Class Initialized
INFO - 2023-04-23 14:40:42 --> Language Class Initialized
INFO - 2023-04-23 14:40:42 --> Loader Class Initialized
INFO - 2023-04-23 14:40:42 --> Helper loaded: url_helper
INFO - 2023-04-23 14:40:42 --> Helper loaded: file_helper
INFO - 2023-04-23 14:40:42 --> Helper loaded: html_helper
INFO - 2023-04-23 14:40:42 --> Helper loaded: text_helper
INFO - 2023-04-23 14:40:42 --> Helper loaded: form_helper
INFO - 2023-04-23 14:40:42 --> Helper loaded: lang_helper
INFO - 2023-04-23 14:40:42 --> Helper loaded: security_helper
INFO - 2023-04-23 14:40:42 --> Helper loaded: cookie_helper
INFO - 2023-04-23 14:40:42 --> Database Driver Class Initialized
INFO - 2023-04-23 14:40:42 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-23 14:40:42 --> Parser Class Initialized
INFO - 2023-04-23 14:40:42 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-23 14:40:42 --> Pagination Class Initialized
INFO - 2023-04-23 14:40:42 --> Form Validation Class Initialized
INFO - 2023-04-23 14:40:42 --> Controller Class Initialized
INFO - 2023-04-23 14:40:42 --> Model Class Initialized
DEBUG - 2023-04-23 14:40:42 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-04-23 14:40:42 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-23 14:40:42 --> Model Class Initialized
DEBUG - 2023-04-23 14:40:42 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-23 14:40:42 --> Model Class Initialized
INFO - 2023-04-23 14:40:42 --> Final output sent to browser
DEBUG - 2023-04-23 14:40:42 --> Total execution time: 0.0176
ERROR - 2023-04-23 14:40:47 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-23 14:40:47 --> Config Class Initialized
INFO - 2023-04-23 14:40:47 --> Hooks Class Initialized
DEBUG - 2023-04-23 14:40:47 --> UTF-8 Support Enabled
INFO - 2023-04-23 14:40:47 --> Utf8 Class Initialized
INFO - 2023-04-23 14:40:47 --> URI Class Initialized
INFO - 2023-04-23 14:40:47 --> Router Class Initialized
INFO - 2023-04-23 14:40:47 --> Output Class Initialized
INFO - 2023-04-23 14:40:47 --> Security Class Initialized
DEBUG - 2023-04-23 14:40:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-23 14:40:47 --> Input Class Initialized
INFO - 2023-04-23 14:40:47 --> Language Class Initialized
INFO - 2023-04-23 14:40:47 --> Loader Class Initialized
INFO - 2023-04-23 14:40:47 --> Helper loaded: url_helper
INFO - 2023-04-23 14:40:47 --> Helper loaded: file_helper
INFO - 2023-04-23 14:40:47 --> Helper loaded: html_helper
INFO - 2023-04-23 14:40:47 --> Helper loaded: text_helper
INFO - 2023-04-23 14:40:47 --> Helper loaded: form_helper
INFO - 2023-04-23 14:40:47 --> Helper loaded: lang_helper
INFO - 2023-04-23 14:40:47 --> Helper loaded: security_helper
INFO - 2023-04-23 14:40:47 --> Helper loaded: cookie_helper
INFO - 2023-04-23 14:40:47 --> Database Driver Class Initialized
INFO - 2023-04-23 14:40:47 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-23 14:40:47 --> Parser Class Initialized
INFO - 2023-04-23 14:40:47 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-23 14:40:47 --> Pagination Class Initialized
INFO - 2023-04-23 14:40:47 --> Form Validation Class Initialized
INFO - 2023-04-23 14:40:47 --> Controller Class Initialized
INFO - 2023-04-23 14:40:47 --> Model Class Initialized
DEBUG - 2023-04-23 14:40:47 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-04-23 14:40:47 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-23 14:40:47 --> Model Class Initialized
INFO - 2023-04-23 14:40:47 --> Model Class Initialized
INFO - 2023-04-23 14:40:47 --> Final output sent to browser
DEBUG - 2023-04-23 14:40:47 --> Total execution time: 0.0212
ERROR - 2023-04-23 14:41:00 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-23 14:41:00 --> Config Class Initialized
INFO - 2023-04-23 14:41:00 --> Hooks Class Initialized
DEBUG - 2023-04-23 14:41:00 --> UTF-8 Support Enabled
INFO - 2023-04-23 14:41:00 --> Utf8 Class Initialized
INFO - 2023-04-23 14:41:00 --> URI Class Initialized
INFO - 2023-04-23 14:41:00 --> Router Class Initialized
INFO - 2023-04-23 14:41:00 --> Output Class Initialized
INFO - 2023-04-23 14:41:00 --> Security Class Initialized
DEBUG - 2023-04-23 14:41:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-23 14:41:00 --> Input Class Initialized
INFO - 2023-04-23 14:41:00 --> Language Class Initialized
INFO - 2023-04-23 14:41:00 --> Loader Class Initialized
INFO - 2023-04-23 14:41:00 --> Helper loaded: url_helper
INFO - 2023-04-23 14:41:00 --> Helper loaded: file_helper
INFO - 2023-04-23 14:41:00 --> Helper loaded: html_helper
INFO - 2023-04-23 14:41:00 --> Helper loaded: text_helper
INFO - 2023-04-23 14:41:00 --> Helper loaded: form_helper
INFO - 2023-04-23 14:41:00 --> Helper loaded: lang_helper
INFO - 2023-04-23 14:41:00 --> Helper loaded: security_helper
INFO - 2023-04-23 14:41:00 --> Helper loaded: cookie_helper
INFO - 2023-04-23 14:41:00 --> Database Driver Class Initialized
INFO - 2023-04-23 14:41:00 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-23 14:41:00 --> Parser Class Initialized
INFO - 2023-04-23 14:41:00 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-23 14:41:00 --> Pagination Class Initialized
INFO - 2023-04-23 14:41:00 --> Form Validation Class Initialized
INFO - 2023-04-23 14:41:00 --> Controller Class Initialized
INFO - 2023-04-23 14:41:00 --> Model Class Initialized
DEBUG - 2023-04-23 14:41:00 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-04-23 14:41:00 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-23 14:41:00 --> Model Class Initialized
DEBUG - 2023-04-23 14:41:00 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-23 14:41:00 --> Model Class Initialized
INFO - 2023-04-23 14:41:00 --> Final output sent to browser
DEBUG - 2023-04-23 14:41:00 --> Total execution time: 0.0210
ERROR - 2023-04-23 14:41:01 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-23 14:41:01 --> Config Class Initialized
INFO - 2023-04-23 14:41:01 --> Hooks Class Initialized
DEBUG - 2023-04-23 14:41:01 --> UTF-8 Support Enabled
INFO - 2023-04-23 14:41:01 --> Utf8 Class Initialized
INFO - 2023-04-23 14:41:01 --> URI Class Initialized
INFO - 2023-04-23 14:41:01 --> Router Class Initialized
INFO - 2023-04-23 14:41:01 --> Output Class Initialized
INFO - 2023-04-23 14:41:01 --> Security Class Initialized
DEBUG - 2023-04-23 14:41:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-23 14:41:01 --> Input Class Initialized
INFO - 2023-04-23 14:41:01 --> Language Class Initialized
INFO - 2023-04-23 14:41:01 --> Loader Class Initialized
INFO - 2023-04-23 14:41:01 --> Helper loaded: url_helper
INFO - 2023-04-23 14:41:01 --> Helper loaded: file_helper
INFO - 2023-04-23 14:41:01 --> Helper loaded: html_helper
INFO - 2023-04-23 14:41:01 --> Helper loaded: text_helper
INFO - 2023-04-23 14:41:01 --> Helper loaded: form_helper
INFO - 2023-04-23 14:41:01 --> Helper loaded: lang_helper
INFO - 2023-04-23 14:41:01 --> Helper loaded: security_helper
INFO - 2023-04-23 14:41:01 --> Helper loaded: cookie_helper
INFO - 2023-04-23 14:41:01 --> Database Driver Class Initialized
INFO - 2023-04-23 14:41:01 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-23 14:41:01 --> Parser Class Initialized
INFO - 2023-04-23 14:41:01 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-23 14:41:01 --> Pagination Class Initialized
INFO - 2023-04-23 14:41:01 --> Form Validation Class Initialized
INFO - 2023-04-23 14:41:01 --> Controller Class Initialized
INFO - 2023-04-23 14:41:01 --> Model Class Initialized
DEBUG - 2023-04-23 14:41:01 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-04-23 14:41:01 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-23 14:41:01 --> Model Class Initialized
DEBUG - 2023-04-23 14:41:01 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-23 14:41:01 --> Model Class Initialized
INFO - 2023-04-23 14:41:01 --> Final output sent to browser
DEBUG - 2023-04-23 14:41:01 --> Total execution time: 0.0184
ERROR - 2023-04-23 14:41:05 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-23 14:41:05 --> Config Class Initialized
INFO - 2023-04-23 14:41:05 --> Hooks Class Initialized
DEBUG - 2023-04-23 14:41:05 --> UTF-8 Support Enabled
INFO - 2023-04-23 14:41:05 --> Utf8 Class Initialized
INFO - 2023-04-23 14:41:05 --> URI Class Initialized
INFO - 2023-04-23 14:41:05 --> Router Class Initialized
INFO - 2023-04-23 14:41:05 --> Output Class Initialized
INFO - 2023-04-23 14:41:05 --> Security Class Initialized
DEBUG - 2023-04-23 14:41:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-23 14:41:05 --> Input Class Initialized
INFO - 2023-04-23 14:41:05 --> Language Class Initialized
INFO - 2023-04-23 14:41:05 --> Loader Class Initialized
INFO - 2023-04-23 14:41:05 --> Helper loaded: url_helper
INFO - 2023-04-23 14:41:05 --> Helper loaded: file_helper
INFO - 2023-04-23 14:41:05 --> Helper loaded: html_helper
INFO - 2023-04-23 14:41:05 --> Helper loaded: text_helper
INFO - 2023-04-23 14:41:05 --> Helper loaded: form_helper
INFO - 2023-04-23 14:41:05 --> Helper loaded: lang_helper
INFO - 2023-04-23 14:41:05 --> Helper loaded: security_helper
INFO - 2023-04-23 14:41:05 --> Helper loaded: cookie_helper
INFO - 2023-04-23 14:41:05 --> Database Driver Class Initialized
INFO - 2023-04-23 14:41:05 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-23 14:41:05 --> Parser Class Initialized
INFO - 2023-04-23 14:41:05 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-23 14:41:05 --> Pagination Class Initialized
INFO - 2023-04-23 14:41:05 --> Form Validation Class Initialized
INFO - 2023-04-23 14:41:05 --> Controller Class Initialized
INFO - 2023-04-23 14:41:05 --> Model Class Initialized
DEBUG - 2023-04-23 14:41:05 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-04-23 14:41:05 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-23 14:41:05 --> Model Class Initialized
INFO - 2023-04-23 14:41:05 --> Model Class Initialized
INFO - 2023-04-23 14:41:05 --> Final output sent to browser
DEBUG - 2023-04-23 14:41:05 --> Total execution time: 0.0178
ERROR - 2023-04-23 14:41:17 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-23 14:41:17 --> Config Class Initialized
INFO - 2023-04-23 14:41:17 --> Hooks Class Initialized
DEBUG - 2023-04-23 14:41:17 --> UTF-8 Support Enabled
INFO - 2023-04-23 14:41:17 --> Utf8 Class Initialized
INFO - 2023-04-23 14:41:17 --> URI Class Initialized
INFO - 2023-04-23 14:41:17 --> Router Class Initialized
INFO - 2023-04-23 14:41:17 --> Output Class Initialized
INFO - 2023-04-23 14:41:17 --> Security Class Initialized
DEBUG - 2023-04-23 14:41:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-23 14:41:17 --> Input Class Initialized
INFO - 2023-04-23 14:41:17 --> Language Class Initialized
INFO - 2023-04-23 14:41:17 --> Loader Class Initialized
INFO - 2023-04-23 14:41:17 --> Helper loaded: url_helper
INFO - 2023-04-23 14:41:17 --> Helper loaded: file_helper
INFO - 2023-04-23 14:41:17 --> Helper loaded: html_helper
INFO - 2023-04-23 14:41:17 --> Helper loaded: text_helper
INFO - 2023-04-23 14:41:17 --> Helper loaded: form_helper
INFO - 2023-04-23 14:41:17 --> Helper loaded: lang_helper
INFO - 2023-04-23 14:41:17 --> Helper loaded: security_helper
INFO - 2023-04-23 14:41:17 --> Helper loaded: cookie_helper
INFO - 2023-04-23 14:41:17 --> Database Driver Class Initialized
INFO - 2023-04-23 14:41:17 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-23 14:41:17 --> Parser Class Initialized
INFO - 2023-04-23 14:41:17 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-23 14:41:17 --> Pagination Class Initialized
INFO - 2023-04-23 14:41:17 --> Form Validation Class Initialized
INFO - 2023-04-23 14:41:17 --> Controller Class Initialized
INFO - 2023-04-23 14:41:17 --> Model Class Initialized
DEBUG - 2023-04-23 14:41:17 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-04-23 14:41:17 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-23 14:41:17 --> Model Class Initialized
DEBUG - 2023-04-23 14:41:17 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-23 14:41:17 --> Model Class Initialized
INFO - 2023-04-23 14:41:17 --> Final output sent to browser
DEBUG - 2023-04-23 14:41:17 --> Total execution time: 0.0203
ERROR - 2023-04-23 14:41:21 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-23 14:41:21 --> Config Class Initialized
INFO - 2023-04-23 14:41:21 --> Hooks Class Initialized
DEBUG - 2023-04-23 14:41:21 --> UTF-8 Support Enabled
INFO - 2023-04-23 14:41:21 --> Utf8 Class Initialized
INFO - 2023-04-23 14:41:21 --> URI Class Initialized
INFO - 2023-04-23 14:41:21 --> Router Class Initialized
INFO - 2023-04-23 14:41:21 --> Output Class Initialized
INFO - 2023-04-23 14:41:21 --> Security Class Initialized
DEBUG - 2023-04-23 14:41:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-23 14:41:21 --> Input Class Initialized
INFO - 2023-04-23 14:41:21 --> Language Class Initialized
INFO - 2023-04-23 14:41:21 --> Loader Class Initialized
INFO - 2023-04-23 14:41:21 --> Helper loaded: url_helper
INFO - 2023-04-23 14:41:21 --> Helper loaded: file_helper
INFO - 2023-04-23 14:41:21 --> Helper loaded: html_helper
INFO - 2023-04-23 14:41:21 --> Helper loaded: text_helper
INFO - 2023-04-23 14:41:21 --> Helper loaded: form_helper
INFO - 2023-04-23 14:41:21 --> Helper loaded: lang_helper
INFO - 2023-04-23 14:41:21 --> Helper loaded: security_helper
INFO - 2023-04-23 14:41:21 --> Helper loaded: cookie_helper
INFO - 2023-04-23 14:41:21 --> Database Driver Class Initialized
INFO - 2023-04-23 14:41:21 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-23 14:41:21 --> Parser Class Initialized
INFO - 2023-04-23 14:41:21 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-23 14:41:21 --> Pagination Class Initialized
INFO - 2023-04-23 14:41:21 --> Form Validation Class Initialized
INFO - 2023-04-23 14:41:21 --> Controller Class Initialized
INFO - 2023-04-23 14:41:21 --> Model Class Initialized
DEBUG - 2023-04-23 14:41:21 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-04-23 14:41:21 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-23 14:41:21 --> Model Class Initialized
DEBUG - 2023-04-23 14:41:21 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-23 14:41:21 --> Model Class Initialized
INFO - 2023-04-23 14:41:21 --> Final output sent to browser
DEBUG - 2023-04-23 14:41:21 --> Total execution time: 0.0209
ERROR - 2023-04-23 14:41:23 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-23 14:41:23 --> Config Class Initialized
INFO - 2023-04-23 14:41:23 --> Hooks Class Initialized
DEBUG - 2023-04-23 14:41:23 --> UTF-8 Support Enabled
INFO - 2023-04-23 14:41:23 --> Utf8 Class Initialized
INFO - 2023-04-23 14:41:23 --> URI Class Initialized
INFO - 2023-04-23 14:41:23 --> Router Class Initialized
INFO - 2023-04-23 14:41:23 --> Output Class Initialized
INFO - 2023-04-23 14:41:23 --> Security Class Initialized
DEBUG - 2023-04-23 14:41:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-23 14:41:23 --> Input Class Initialized
INFO - 2023-04-23 14:41:23 --> Language Class Initialized
INFO - 2023-04-23 14:41:23 --> Loader Class Initialized
INFO - 2023-04-23 14:41:23 --> Helper loaded: url_helper
INFO - 2023-04-23 14:41:23 --> Helper loaded: file_helper
INFO - 2023-04-23 14:41:23 --> Helper loaded: html_helper
INFO - 2023-04-23 14:41:23 --> Helper loaded: text_helper
INFO - 2023-04-23 14:41:23 --> Helper loaded: form_helper
INFO - 2023-04-23 14:41:23 --> Helper loaded: lang_helper
INFO - 2023-04-23 14:41:23 --> Helper loaded: security_helper
INFO - 2023-04-23 14:41:23 --> Helper loaded: cookie_helper
INFO - 2023-04-23 14:41:23 --> Database Driver Class Initialized
INFO - 2023-04-23 14:41:23 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-23 14:41:23 --> Parser Class Initialized
INFO - 2023-04-23 14:41:23 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-23 14:41:23 --> Pagination Class Initialized
INFO - 2023-04-23 14:41:23 --> Form Validation Class Initialized
INFO - 2023-04-23 14:41:23 --> Controller Class Initialized
INFO - 2023-04-23 14:41:23 --> Model Class Initialized
DEBUG - 2023-04-23 14:41:23 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-04-23 14:41:23 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-23 14:41:23 --> Model Class Initialized
INFO - 2023-04-23 14:41:23 --> Model Class Initialized
INFO - 2023-04-23 14:41:23 --> Final output sent to browser
DEBUG - 2023-04-23 14:41:23 --> Total execution time: 0.0185
ERROR - 2023-04-23 14:41:35 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-23 14:41:35 --> Config Class Initialized
INFO - 2023-04-23 14:41:35 --> Hooks Class Initialized
DEBUG - 2023-04-23 14:41:35 --> UTF-8 Support Enabled
INFO - 2023-04-23 14:41:35 --> Utf8 Class Initialized
INFO - 2023-04-23 14:41:35 --> URI Class Initialized
INFO - 2023-04-23 14:41:35 --> Router Class Initialized
INFO - 2023-04-23 14:41:35 --> Output Class Initialized
INFO - 2023-04-23 14:41:35 --> Security Class Initialized
DEBUG - 2023-04-23 14:41:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-23 14:41:35 --> Input Class Initialized
INFO - 2023-04-23 14:41:35 --> Language Class Initialized
INFO - 2023-04-23 14:41:35 --> Loader Class Initialized
INFO - 2023-04-23 14:41:35 --> Helper loaded: url_helper
INFO - 2023-04-23 14:41:35 --> Helper loaded: file_helper
INFO - 2023-04-23 14:41:35 --> Helper loaded: html_helper
INFO - 2023-04-23 14:41:35 --> Helper loaded: text_helper
INFO - 2023-04-23 14:41:35 --> Helper loaded: form_helper
INFO - 2023-04-23 14:41:35 --> Helper loaded: lang_helper
INFO - 2023-04-23 14:41:35 --> Helper loaded: security_helper
INFO - 2023-04-23 14:41:35 --> Helper loaded: cookie_helper
INFO - 2023-04-23 14:41:35 --> Database Driver Class Initialized
INFO - 2023-04-23 14:41:35 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-23 14:41:35 --> Parser Class Initialized
INFO - 2023-04-23 14:41:35 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-23 14:41:35 --> Pagination Class Initialized
INFO - 2023-04-23 14:41:35 --> Form Validation Class Initialized
INFO - 2023-04-23 14:41:35 --> Controller Class Initialized
INFO - 2023-04-23 14:41:35 --> Model Class Initialized
DEBUG - 2023-04-23 14:41:35 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-04-23 14:41:35 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-23 14:41:35 --> Model Class Initialized
DEBUG - 2023-04-23 14:41:35 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-23 14:41:35 --> Model Class Initialized
INFO - 2023-04-23 14:41:35 --> Final output sent to browser
DEBUG - 2023-04-23 14:41:35 --> Total execution time: 0.0206
ERROR - 2023-04-23 14:41:37 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-23 14:41:37 --> Config Class Initialized
INFO - 2023-04-23 14:41:37 --> Hooks Class Initialized
DEBUG - 2023-04-23 14:41:37 --> UTF-8 Support Enabled
INFO - 2023-04-23 14:41:37 --> Utf8 Class Initialized
INFO - 2023-04-23 14:41:37 --> URI Class Initialized
INFO - 2023-04-23 14:41:37 --> Router Class Initialized
INFO - 2023-04-23 14:41:37 --> Output Class Initialized
INFO - 2023-04-23 14:41:37 --> Security Class Initialized
DEBUG - 2023-04-23 14:41:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-23 14:41:37 --> Input Class Initialized
INFO - 2023-04-23 14:41:37 --> Language Class Initialized
INFO - 2023-04-23 14:41:37 --> Loader Class Initialized
INFO - 2023-04-23 14:41:37 --> Helper loaded: url_helper
INFO - 2023-04-23 14:41:37 --> Helper loaded: file_helper
INFO - 2023-04-23 14:41:37 --> Helper loaded: html_helper
INFO - 2023-04-23 14:41:37 --> Helper loaded: text_helper
INFO - 2023-04-23 14:41:37 --> Helper loaded: form_helper
INFO - 2023-04-23 14:41:37 --> Helper loaded: lang_helper
INFO - 2023-04-23 14:41:37 --> Helper loaded: security_helper
INFO - 2023-04-23 14:41:37 --> Helper loaded: cookie_helper
INFO - 2023-04-23 14:41:37 --> Database Driver Class Initialized
INFO - 2023-04-23 14:41:37 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-23 14:41:37 --> Parser Class Initialized
INFO - 2023-04-23 14:41:37 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-23 14:41:37 --> Pagination Class Initialized
INFO - 2023-04-23 14:41:37 --> Form Validation Class Initialized
INFO - 2023-04-23 14:41:37 --> Controller Class Initialized
INFO - 2023-04-23 14:41:37 --> Model Class Initialized
DEBUG - 2023-04-23 14:41:37 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-04-23 14:41:37 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-23 14:41:37 --> Model Class Initialized
DEBUG - 2023-04-23 14:41:37 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-23 14:41:37 --> Model Class Initialized
INFO - 2023-04-23 14:41:37 --> Final output sent to browser
DEBUG - 2023-04-23 14:41:37 --> Total execution time: 0.0163
ERROR - 2023-04-23 14:41:38 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-23 14:41:38 --> Config Class Initialized
INFO - 2023-04-23 14:41:38 --> Hooks Class Initialized
DEBUG - 2023-04-23 14:41:38 --> UTF-8 Support Enabled
INFO - 2023-04-23 14:41:38 --> Utf8 Class Initialized
INFO - 2023-04-23 14:41:38 --> URI Class Initialized
INFO - 2023-04-23 14:41:38 --> Router Class Initialized
INFO - 2023-04-23 14:41:38 --> Output Class Initialized
INFO - 2023-04-23 14:41:38 --> Security Class Initialized
DEBUG - 2023-04-23 14:41:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-23 14:41:38 --> Input Class Initialized
INFO - 2023-04-23 14:41:38 --> Language Class Initialized
INFO - 2023-04-23 14:41:38 --> Loader Class Initialized
INFO - 2023-04-23 14:41:38 --> Helper loaded: url_helper
INFO - 2023-04-23 14:41:38 --> Helper loaded: file_helper
INFO - 2023-04-23 14:41:38 --> Helper loaded: html_helper
INFO - 2023-04-23 14:41:38 --> Helper loaded: text_helper
INFO - 2023-04-23 14:41:38 --> Helper loaded: form_helper
INFO - 2023-04-23 14:41:38 --> Helper loaded: lang_helper
INFO - 2023-04-23 14:41:38 --> Helper loaded: security_helper
INFO - 2023-04-23 14:41:38 --> Helper loaded: cookie_helper
INFO - 2023-04-23 14:41:38 --> Database Driver Class Initialized
INFO - 2023-04-23 14:41:38 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-23 14:41:38 --> Parser Class Initialized
INFO - 2023-04-23 14:41:38 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-23 14:41:38 --> Pagination Class Initialized
INFO - 2023-04-23 14:41:38 --> Form Validation Class Initialized
INFO - 2023-04-23 14:41:38 --> Controller Class Initialized
INFO - 2023-04-23 14:41:38 --> Model Class Initialized
DEBUG - 2023-04-23 14:41:38 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-04-23 14:41:38 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-23 14:41:38 --> Model Class Initialized
DEBUG - 2023-04-23 14:41:38 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-23 14:41:38 --> Model Class Initialized
INFO - 2023-04-23 14:41:38 --> Final output sent to browser
DEBUG - 2023-04-23 14:41:38 --> Total execution time: 0.0178
ERROR - 2023-04-23 14:41:39 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-23 14:41:39 --> Config Class Initialized
INFO - 2023-04-23 14:41:39 --> Hooks Class Initialized
DEBUG - 2023-04-23 14:41:39 --> UTF-8 Support Enabled
INFO - 2023-04-23 14:41:39 --> Utf8 Class Initialized
INFO - 2023-04-23 14:41:39 --> URI Class Initialized
INFO - 2023-04-23 14:41:39 --> Router Class Initialized
INFO - 2023-04-23 14:41:39 --> Output Class Initialized
INFO - 2023-04-23 14:41:39 --> Security Class Initialized
DEBUG - 2023-04-23 14:41:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-23 14:41:39 --> Input Class Initialized
INFO - 2023-04-23 14:41:39 --> Language Class Initialized
INFO - 2023-04-23 14:41:39 --> Loader Class Initialized
INFO - 2023-04-23 14:41:39 --> Helper loaded: url_helper
INFO - 2023-04-23 14:41:39 --> Helper loaded: file_helper
INFO - 2023-04-23 14:41:39 --> Helper loaded: html_helper
INFO - 2023-04-23 14:41:39 --> Helper loaded: text_helper
INFO - 2023-04-23 14:41:39 --> Helper loaded: form_helper
INFO - 2023-04-23 14:41:39 --> Helper loaded: lang_helper
INFO - 2023-04-23 14:41:39 --> Helper loaded: security_helper
INFO - 2023-04-23 14:41:39 --> Helper loaded: cookie_helper
INFO - 2023-04-23 14:41:39 --> Database Driver Class Initialized
INFO - 2023-04-23 14:41:39 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-23 14:41:39 --> Parser Class Initialized
INFO - 2023-04-23 14:41:39 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-23 14:41:39 --> Pagination Class Initialized
INFO - 2023-04-23 14:41:39 --> Form Validation Class Initialized
INFO - 2023-04-23 14:41:39 --> Controller Class Initialized
INFO - 2023-04-23 14:41:39 --> Model Class Initialized
DEBUG - 2023-04-23 14:41:39 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-04-23 14:41:39 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-23 14:41:39 --> Model Class Initialized
DEBUG - 2023-04-23 14:41:39 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-23 14:41:39 --> Model Class Initialized
INFO - 2023-04-23 14:41:39 --> Final output sent to browser
DEBUG - 2023-04-23 14:41:39 --> Total execution time: 0.0208
ERROR - 2023-04-23 14:41:42 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-23 14:41:42 --> Config Class Initialized
INFO - 2023-04-23 14:41:42 --> Hooks Class Initialized
DEBUG - 2023-04-23 14:41:42 --> UTF-8 Support Enabled
INFO - 2023-04-23 14:41:42 --> Utf8 Class Initialized
INFO - 2023-04-23 14:41:42 --> URI Class Initialized
INFO - 2023-04-23 14:41:42 --> Router Class Initialized
INFO - 2023-04-23 14:41:42 --> Output Class Initialized
INFO - 2023-04-23 14:41:42 --> Security Class Initialized
DEBUG - 2023-04-23 14:41:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-23 14:41:42 --> Input Class Initialized
INFO - 2023-04-23 14:41:42 --> Language Class Initialized
INFO - 2023-04-23 14:41:42 --> Loader Class Initialized
INFO - 2023-04-23 14:41:42 --> Helper loaded: url_helper
INFO - 2023-04-23 14:41:42 --> Helper loaded: file_helper
INFO - 2023-04-23 14:41:42 --> Helper loaded: html_helper
INFO - 2023-04-23 14:41:42 --> Helper loaded: text_helper
INFO - 2023-04-23 14:41:42 --> Helper loaded: form_helper
INFO - 2023-04-23 14:41:42 --> Helper loaded: lang_helper
INFO - 2023-04-23 14:41:42 --> Helper loaded: security_helper
INFO - 2023-04-23 14:41:42 --> Helper loaded: cookie_helper
INFO - 2023-04-23 14:41:42 --> Database Driver Class Initialized
INFO - 2023-04-23 14:41:42 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-23 14:41:42 --> Parser Class Initialized
INFO - 2023-04-23 14:41:42 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-23 14:41:42 --> Pagination Class Initialized
INFO - 2023-04-23 14:41:42 --> Form Validation Class Initialized
INFO - 2023-04-23 14:41:42 --> Controller Class Initialized
INFO - 2023-04-23 14:41:42 --> Model Class Initialized
DEBUG - 2023-04-23 14:41:42 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-04-23 14:41:42 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-23 14:41:42 --> Model Class Initialized
INFO - 2023-04-23 14:41:42 --> Model Class Initialized
INFO - 2023-04-23 14:41:42 --> Final output sent to browser
DEBUG - 2023-04-23 14:41:42 --> Total execution time: 0.0201
ERROR - 2023-04-23 14:41:52 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-23 14:41:52 --> Config Class Initialized
INFO - 2023-04-23 14:41:52 --> Hooks Class Initialized
DEBUG - 2023-04-23 14:41:52 --> UTF-8 Support Enabled
INFO - 2023-04-23 14:41:52 --> Utf8 Class Initialized
INFO - 2023-04-23 14:41:52 --> URI Class Initialized
INFO - 2023-04-23 14:41:52 --> Router Class Initialized
INFO - 2023-04-23 14:41:52 --> Output Class Initialized
INFO - 2023-04-23 14:41:52 --> Security Class Initialized
DEBUG - 2023-04-23 14:41:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-23 14:41:52 --> Input Class Initialized
INFO - 2023-04-23 14:41:52 --> Language Class Initialized
INFO - 2023-04-23 14:41:52 --> Loader Class Initialized
INFO - 2023-04-23 14:41:52 --> Helper loaded: url_helper
INFO - 2023-04-23 14:41:52 --> Helper loaded: file_helper
INFO - 2023-04-23 14:41:52 --> Helper loaded: html_helper
INFO - 2023-04-23 14:41:52 --> Helper loaded: text_helper
INFO - 2023-04-23 14:41:52 --> Helper loaded: form_helper
INFO - 2023-04-23 14:41:52 --> Helper loaded: lang_helper
INFO - 2023-04-23 14:41:52 --> Helper loaded: security_helper
INFO - 2023-04-23 14:41:52 --> Helper loaded: cookie_helper
INFO - 2023-04-23 14:41:52 --> Database Driver Class Initialized
INFO - 2023-04-23 14:41:52 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-23 14:41:52 --> Parser Class Initialized
INFO - 2023-04-23 14:41:52 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-23 14:41:52 --> Pagination Class Initialized
INFO - 2023-04-23 14:41:52 --> Form Validation Class Initialized
INFO - 2023-04-23 14:41:52 --> Controller Class Initialized
INFO - 2023-04-23 14:41:52 --> Model Class Initialized
DEBUG - 2023-04-23 14:41:52 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-04-23 14:41:52 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-23 14:41:52 --> Model Class Initialized
DEBUG - 2023-04-23 14:41:52 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-23 14:41:52 --> Model Class Initialized
INFO - 2023-04-23 14:41:52 --> Final output sent to browser
DEBUG - 2023-04-23 14:41:52 --> Total execution time: 0.0208
ERROR - 2023-04-23 14:41:52 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-23 14:41:52 --> Config Class Initialized
INFO - 2023-04-23 14:41:52 --> Hooks Class Initialized
DEBUG - 2023-04-23 14:41:52 --> UTF-8 Support Enabled
INFO - 2023-04-23 14:41:52 --> Utf8 Class Initialized
INFO - 2023-04-23 14:41:52 --> URI Class Initialized
INFO - 2023-04-23 14:41:52 --> Router Class Initialized
INFO - 2023-04-23 14:41:52 --> Output Class Initialized
INFO - 2023-04-23 14:41:52 --> Security Class Initialized
DEBUG - 2023-04-23 14:41:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-23 14:41:52 --> Input Class Initialized
INFO - 2023-04-23 14:41:52 --> Language Class Initialized
INFO - 2023-04-23 14:41:52 --> Loader Class Initialized
INFO - 2023-04-23 14:41:52 --> Helper loaded: url_helper
INFO - 2023-04-23 14:41:52 --> Helper loaded: file_helper
INFO - 2023-04-23 14:41:52 --> Helper loaded: html_helper
INFO - 2023-04-23 14:41:52 --> Helper loaded: text_helper
INFO - 2023-04-23 14:41:52 --> Helper loaded: form_helper
INFO - 2023-04-23 14:41:52 --> Helper loaded: lang_helper
INFO - 2023-04-23 14:41:52 --> Helper loaded: security_helper
INFO - 2023-04-23 14:41:52 --> Helper loaded: cookie_helper
INFO - 2023-04-23 14:41:52 --> Database Driver Class Initialized
INFO - 2023-04-23 14:41:52 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-23 14:41:52 --> Parser Class Initialized
INFO - 2023-04-23 14:41:52 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-23 14:41:52 --> Pagination Class Initialized
INFO - 2023-04-23 14:41:52 --> Form Validation Class Initialized
INFO - 2023-04-23 14:41:52 --> Controller Class Initialized
INFO - 2023-04-23 14:41:52 --> Model Class Initialized
DEBUG - 2023-04-23 14:41:52 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-04-23 14:41:52 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-23 14:41:52 --> Model Class Initialized
DEBUG - 2023-04-23 14:41:52 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-23 14:41:52 --> Model Class Initialized
INFO - 2023-04-23 14:41:52 --> Final output sent to browser
DEBUG - 2023-04-23 14:41:52 --> Total execution time: 0.0175
ERROR - 2023-04-23 14:41:55 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-23 14:41:55 --> Config Class Initialized
INFO - 2023-04-23 14:41:55 --> Hooks Class Initialized
DEBUG - 2023-04-23 14:41:55 --> UTF-8 Support Enabled
INFO - 2023-04-23 14:41:55 --> Utf8 Class Initialized
INFO - 2023-04-23 14:41:55 --> URI Class Initialized
INFO - 2023-04-23 14:41:55 --> Router Class Initialized
INFO - 2023-04-23 14:41:55 --> Output Class Initialized
INFO - 2023-04-23 14:41:55 --> Security Class Initialized
DEBUG - 2023-04-23 14:41:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-23 14:41:55 --> Input Class Initialized
INFO - 2023-04-23 14:41:55 --> Language Class Initialized
INFO - 2023-04-23 14:41:55 --> Loader Class Initialized
INFO - 2023-04-23 14:41:55 --> Helper loaded: url_helper
INFO - 2023-04-23 14:41:55 --> Helper loaded: file_helper
INFO - 2023-04-23 14:41:55 --> Helper loaded: html_helper
INFO - 2023-04-23 14:41:55 --> Helper loaded: text_helper
INFO - 2023-04-23 14:41:55 --> Helper loaded: form_helper
INFO - 2023-04-23 14:41:55 --> Helper loaded: lang_helper
INFO - 2023-04-23 14:41:55 --> Helper loaded: security_helper
INFO - 2023-04-23 14:41:55 --> Helper loaded: cookie_helper
INFO - 2023-04-23 14:41:55 --> Database Driver Class Initialized
INFO - 2023-04-23 14:41:55 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-23 14:41:55 --> Parser Class Initialized
INFO - 2023-04-23 14:41:55 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-23 14:41:55 --> Pagination Class Initialized
INFO - 2023-04-23 14:41:55 --> Form Validation Class Initialized
INFO - 2023-04-23 14:41:55 --> Controller Class Initialized
INFO - 2023-04-23 14:41:55 --> Model Class Initialized
DEBUG - 2023-04-23 14:41:55 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-04-23 14:41:55 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-23 14:41:55 --> Model Class Initialized
INFO - 2023-04-23 14:41:55 --> Model Class Initialized
INFO - 2023-04-23 14:41:55 --> Final output sent to browser
DEBUG - 2023-04-23 14:41:55 --> Total execution time: 0.0212
ERROR - 2023-04-23 14:42:07 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-23 14:42:07 --> Config Class Initialized
INFO - 2023-04-23 14:42:07 --> Hooks Class Initialized
DEBUG - 2023-04-23 14:42:07 --> UTF-8 Support Enabled
INFO - 2023-04-23 14:42:07 --> Utf8 Class Initialized
INFO - 2023-04-23 14:42:07 --> URI Class Initialized
INFO - 2023-04-23 14:42:07 --> Router Class Initialized
INFO - 2023-04-23 14:42:07 --> Output Class Initialized
INFO - 2023-04-23 14:42:07 --> Security Class Initialized
DEBUG - 2023-04-23 14:42:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-23 14:42:07 --> Input Class Initialized
INFO - 2023-04-23 14:42:07 --> Language Class Initialized
INFO - 2023-04-23 14:42:07 --> Loader Class Initialized
INFO - 2023-04-23 14:42:07 --> Helper loaded: url_helper
INFO - 2023-04-23 14:42:07 --> Helper loaded: file_helper
INFO - 2023-04-23 14:42:07 --> Helper loaded: html_helper
INFO - 2023-04-23 14:42:07 --> Helper loaded: text_helper
INFO - 2023-04-23 14:42:07 --> Helper loaded: form_helper
INFO - 2023-04-23 14:42:07 --> Helper loaded: lang_helper
INFO - 2023-04-23 14:42:07 --> Helper loaded: security_helper
INFO - 2023-04-23 14:42:07 --> Helper loaded: cookie_helper
INFO - 2023-04-23 14:42:07 --> Database Driver Class Initialized
INFO - 2023-04-23 14:42:07 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-23 14:42:07 --> Parser Class Initialized
INFO - 2023-04-23 14:42:07 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-23 14:42:07 --> Pagination Class Initialized
INFO - 2023-04-23 14:42:07 --> Form Validation Class Initialized
INFO - 2023-04-23 14:42:07 --> Controller Class Initialized
INFO - 2023-04-23 14:42:08 --> Model Class Initialized
DEBUG - 2023-04-23 14:42:08 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-04-23 14:42:08 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-23 14:42:08 --> Model Class Initialized
DEBUG - 2023-04-23 14:42:08 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-23 14:42:08 --> Model Class Initialized
INFO - 2023-04-23 14:42:08 --> Final output sent to browser
DEBUG - 2023-04-23 14:42:08 --> Total execution time: 0.0213
ERROR - 2023-04-23 14:42:08 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-23 14:42:08 --> Config Class Initialized
INFO - 2023-04-23 14:42:08 --> Hooks Class Initialized
DEBUG - 2023-04-23 14:42:08 --> UTF-8 Support Enabled
INFO - 2023-04-23 14:42:08 --> Utf8 Class Initialized
INFO - 2023-04-23 14:42:08 --> URI Class Initialized
INFO - 2023-04-23 14:42:08 --> Router Class Initialized
INFO - 2023-04-23 14:42:08 --> Output Class Initialized
INFO - 2023-04-23 14:42:08 --> Security Class Initialized
DEBUG - 2023-04-23 14:42:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-23 14:42:08 --> Input Class Initialized
INFO - 2023-04-23 14:42:08 --> Language Class Initialized
INFO - 2023-04-23 14:42:08 --> Loader Class Initialized
INFO - 2023-04-23 14:42:08 --> Helper loaded: url_helper
INFO - 2023-04-23 14:42:08 --> Helper loaded: file_helper
INFO - 2023-04-23 14:42:08 --> Helper loaded: html_helper
INFO - 2023-04-23 14:42:08 --> Helper loaded: text_helper
INFO - 2023-04-23 14:42:08 --> Helper loaded: form_helper
INFO - 2023-04-23 14:42:08 --> Helper loaded: lang_helper
INFO - 2023-04-23 14:42:08 --> Helper loaded: security_helper
INFO - 2023-04-23 14:42:08 --> Helper loaded: cookie_helper
INFO - 2023-04-23 14:42:08 --> Database Driver Class Initialized
INFO - 2023-04-23 14:42:08 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-23 14:42:08 --> Parser Class Initialized
INFO - 2023-04-23 14:42:08 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-23 14:42:08 --> Pagination Class Initialized
INFO - 2023-04-23 14:42:08 --> Form Validation Class Initialized
INFO - 2023-04-23 14:42:08 --> Controller Class Initialized
INFO - 2023-04-23 14:42:08 --> Model Class Initialized
DEBUG - 2023-04-23 14:42:08 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-04-23 14:42:08 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-23 14:42:08 --> Model Class Initialized
DEBUG - 2023-04-23 14:42:08 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-23 14:42:08 --> Model Class Initialized
INFO - 2023-04-23 14:42:08 --> Final output sent to browser
DEBUG - 2023-04-23 14:42:08 --> Total execution time: 0.0175
ERROR - 2023-04-23 14:42:10 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-23 14:42:10 --> Config Class Initialized
INFO - 2023-04-23 14:42:10 --> Hooks Class Initialized
DEBUG - 2023-04-23 14:42:10 --> UTF-8 Support Enabled
INFO - 2023-04-23 14:42:10 --> Utf8 Class Initialized
INFO - 2023-04-23 14:42:10 --> URI Class Initialized
INFO - 2023-04-23 14:42:10 --> Router Class Initialized
INFO - 2023-04-23 14:42:10 --> Output Class Initialized
INFO - 2023-04-23 14:42:10 --> Security Class Initialized
DEBUG - 2023-04-23 14:42:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-23 14:42:10 --> Input Class Initialized
INFO - 2023-04-23 14:42:10 --> Language Class Initialized
INFO - 2023-04-23 14:42:10 --> Loader Class Initialized
INFO - 2023-04-23 14:42:10 --> Helper loaded: url_helper
INFO - 2023-04-23 14:42:10 --> Helper loaded: file_helper
INFO - 2023-04-23 14:42:10 --> Helper loaded: html_helper
INFO - 2023-04-23 14:42:10 --> Helper loaded: text_helper
INFO - 2023-04-23 14:42:10 --> Helper loaded: form_helper
INFO - 2023-04-23 14:42:10 --> Helper loaded: lang_helper
INFO - 2023-04-23 14:42:10 --> Helper loaded: security_helper
INFO - 2023-04-23 14:42:10 --> Helper loaded: cookie_helper
INFO - 2023-04-23 14:42:10 --> Database Driver Class Initialized
INFO - 2023-04-23 14:42:10 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-23 14:42:10 --> Parser Class Initialized
INFO - 2023-04-23 14:42:10 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-23 14:42:10 --> Pagination Class Initialized
INFO - 2023-04-23 14:42:10 --> Form Validation Class Initialized
INFO - 2023-04-23 14:42:10 --> Controller Class Initialized
INFO - 2023-04-23 14:42:10 --> Model Class Initialized
DEBUG - 2023-04-23 14:42:10 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-04-23 14:42:10 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-23 14:42:10 --> Model Class Initialized
DEBUG - 2023-04-23 14:42:10 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-23 14:42:10 --> Model Class Initialized
INFO - 2023-04-23 14:42:10 --> Final output sent to browser
DEBUG - 2023-04-23 14:42:10 --> Total execution time: 0.0209
ERROR - 2023-04-23 14:42:13 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-23 14:42:13 --> Config Class Initialized
INFO - 2023-04-23 14:42:13 --> Hooks Class Initialized
DEBUG - 2023-04-23 14:42:13 --> UTF-8 Support Enabled
INFO - 2023-04-23 14:42:13 --> Utf8 Class Initialized
INFO - 2023-04-23 14:42:13 --> URI Class Initialized
INFO - 2023-04-23 14:42:13 --> Router Class Initialized
INFO - 2023-04-23 14:42:13 --> Output Class Initialized
INFO - 2023-04-23 14:42:13 --> Security Class Initialized
DEBUG - 2023-04-23 14:42:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-23 14:42:13 --> Input Class Initialized
INFO - 2023-04-23 14:42:13 --> Language Class Initialized
INFO - 2023-04-23 14:42:13 --> Loader Class Initialized
INFO - 2023-04-23 14:42:13 --> Helper loaded: url_helper
INFO - 2023-04-23 14:42:13 --> Helper loaded: file_helper
INFO - 2023-04-23 14:42:13 --> Helper loaded: html_helper
INFO - 2023-04-23 14:42:13 --> Helper loaded: text_helper
INFO - 2023-04-23 14:42:13 --> Helper loaded: form_helper
INFO - 2023-04-23 14:42:13 --> Helper loaded: lang_helper
INFO - 2023-04-23 14:42:13 --> Helper loaded: security_helper
INFO - 2023-04-23 14:42:13 --> Helper loaded: cookie_helper
INFO - 2023-04-23 14:42:13 --> Database Driver Class Initialized
INFO - 2023-04-23 14:42:13 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-23 14:42:13 --> Parser Class Initialized
INFO - 2023-04-23 14:42:13 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-23 14:42:13 --> Pagination Class Initialized
INFO - 2023-04-23 14:42:13 --> Form Validation Class Initialized
INFO - 2023-04-23 14:42:13 --> Controller Class Initialized
INFO - 2023-04-23 14:42:13 --> Model Class Initialized
DEBUG - 2023-04-23 14:42:13 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-04-23 14:42:13 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-23 14:42:13 --> Model Class Initialized
INFO - 2023-04-23 14:42:13 --> Model Class Initialized
INFO - 2023-04-23 14:42:13 --> Final output sent to browser
DEBUG - 2023-04-23 14:42:13 --> Total execution time: 0.0188
ERROR - 2023-04-23 14:42:36 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-23 14:42:36 --> Config Class Initialized
INFO - 2023-04-23 14:42:36 --> Hooks Class Initialized
DEBUG - 2023-04-23 14:42:36 --> UTF-8 Support Enabled
INFO - 2023-04-23 14:42:36 --> Utf8 Class Initialized
INFO - 2023-04-23 14:42:36 --> URI Class Initialized
INFO - 2023-04-23 14:42:36 --> Router Class Initialized
INFO - 2023-04-23 14:42:36 --> Output Class Initialized
INFO - 2023-04-23 14:42:36 --> Security Class Initialized
DEBUG - 2023-04-23 14:42:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-23 14:42:36 --> Input Class Initialized
INFO - 2023-04-23 14:42:36 --> Language Class Initialized
INFO - 2023-04-23 14:42:36 --> Loader Class Initialized
INFO - 2023-04-23 14:42:36 --> Helper loaded: url_helper
INFO - 2023-04-23 14:42:36 --> Helper loaded: file_helper
INFO - 2023-04-23 14:42:36 --> Helper loaded: html_helper
INFO - 2023-04-23 14:42:36 --> Helper loaded: text_helper
INFO - 2023-04-23 14:42:36 --> Helper loaded: form_helper
INFO - 2023-04-23 14:42:36 --> Helper loaded: lang_helper
INFO - 2023-04-23 14:42:36 --> Helper loaded: security_helper
INFO - 2023-04-23 14:42:36 --> Helper loaded: cookie_helper
INFO - 2023-04-23 14:42:36 --> Database Driver Class Initialized
INFO - 2023-04-23 14:42:36 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-23 14:42:36 --> Parser Class Initialized
INFO - 2023-04-23 14:42:36 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-23 14:42:36 --> Pagination Class Initialized
INFO - 2023-04-23 14:42:36 --> Form Validation Class Initialized
INFO - 2023-04-23 14:42:36 --> Controller Class Initialized
INFO - 2023-04-23 14:42:37 --> Model Class Initialized
DEBUG - 2023-04-23 14:42:37 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-04-23 14:42:37 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-23 14:42:37 --> Model Class Initialized
DEBUG - 2023-04-23 14:42:37 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-23 14:42:37 --> Model Class Initialized
INFO - 2023-04-23 14:42:37 --> Final output sent to browser
DEBUG - 2023-04-23 14:42:37 --> Total execution time: 0.0233
ERROR - 2023-04-23 14:42:37 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-23 14:42:37 --> Config Class Initialized
INFO - 2023-04-23 14:42:37 --> Hooks Class Initialized
DEBUG - 2023-04-23 14:42:37 --> UTF-8 Support Enabled
INFO - 2023-04-23 14:42:37 --> Utf8 Class Initialized
INFO - 2023-04-23 14:42:37 --> URI Class Initialized
INFO - 2023-04-23 14:42:37 --> Router Class Initialized
INFO - 2023-04-23 14:42:37 --> Output Class Initialized
INFO - 2023-04-23 14:42:37 --> Security Class Initialized
DEBUG - 2023-04-23 14:42:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-23 14:42:37 --> Input Class Initialized
INFO - 2023-04-23 14:42:37 --> Language Class Initialized
INFO - 2023-04-23 14:42:37 --> Loader Class Initialized
INFO - 2023-04-23 14:42:37 --> Helper loaded: url_helper
INFO - 2023-04-23 14:42:37 --> Helper loaded: file_helper
INFO - 2023-04-23 14:42:37 --> Helper loaded: html_helper
INFO - 2023-04-23 14:42:37 --> Helper loaded: text_helper
INFO - 2023-04-23 14:42:37 --> Helper loaded: form_helper
INFO - 2023-04-23 14:42:37 --> Helper loaded: lang_helper
INFO - 2023-04-23 14:42:37 --> Helper loaded: security_helper
INFO - 2023-04-23 14:42:37 --> Helper loaded: cookie_helper
INFO - 2023-04-23 14:42:37 --> Database Driver Class Initialized
INFO - 2023-04-23 14:42:37 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-23 14:42:37 --> Parser Class Initialized
INFO - 2023-04-23 14:42:37 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-23 14:42:37 --> Pagination Class Initialized
INFO - 2023-04-23 14:42:37 --> Form Validation Class Initialized
INFO - 2023-04-23 14:42:37 --> Controller Class Initialized
INFO - 2023-04-23 14:42:37 --> Model Class Initialized
DEBUG - 2023-04-23 14:42:37 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-04-23 14:42:37 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-23 14:42:37 --> Model Class Initialized
DEBUG - 2023-04-23 14:42:37 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-23 14:42:37 --> Model Class Initialized
INFO - 2023-04-23 14:42:37 --> Final output sent to browser
DEBUG - 2023-04-23 14:42:37 --> Total execution time: 0.0175
ERROR - 2023-04-23 14:42:37 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-23 14:42:37 --> Config Class Initialized
INFO - 2023-04-23 14:42:37 --> Hooks Class Initialized
DEBUG - 2023-04-23 14:42:37 --> UTF-8 Support Enabled
INFO - 2023-04-23 14:42:37 --> Utf8 Class Initialized
INFO - 2023-04-23 14:42:37 --> URI Class Initialized
INFO - 2023-04-23 14:42:37 --> Router Class Initialized
INFO - 2023-04-23 14:42:37 --> Output Class Initialized
INFO - 2023-04-23 14:42:37 --> Security Class Initialized
DEBUG - 2023-04-23 14:42:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-23 14:42:37 --> Input Class Initialized
INFO - 2023-04-23 14:42:37 --> Language Class Initialized
INFO - 2023-04-23 14:42:37 --> Loader Class Initialized
INFO - 2023-04-23 14:42:37 --> Helper loaded: url_helper
INFO - 2023-04-23 14:42:37 --> Helper loaded: file_helper
INFO - 2023-04-23 14:42:37 --> Helper loaded: html_helper
INFO - 2023-04-23 14:42:37 --> Helper loaded: text_helper
INFO - 2023-04-23 14:42:37 --> Helper loaded: form_helper
INFO - 2023-04-23 14:42:37 --> Helper loaded: lang_helper
INFO - 2023-04-23 14:42:37 --> Helper loaded: security_helper
INFO - 2023-04-23 14:42:37 --> Helper loaded: cookie_helper
INFO - 2023-04-23 14:42:37 --> Database Driver Class Initialized
INFO - 2023-04-23 14:42:37 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-23 14:42:37 --> Parser Class Initialized
INFO - 2023-04-23 14:42:37 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-23 14:42:37 --> Pagination Class Initialized
INFO - 2023-04-23 14:42:37 --> Form Validation Class Initialized
INFO - 2023-04-23 14:42:37 --> Controller Class Initialized
INFO - 2023-04-23 14:42:37 --> Model Class Initialized
DEBUG - 2023-04-23 14:42:37 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-04-23 14:42:37 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-23 14:42:37 --> Model Class Initialized
DEBUG - 2023-04-23 14:42:37 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-23 14:42:37 --> Model Class Initialized
INFO - 2023-04-23 14:42:37 --> Final output sent to browser
DEBUG - 2023-04-23 14:42:37 --> Total execution time: 0.0165
ERROR - 2023-04-23 14:42:40 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-23 14:42:40 --> Config Class Initialized
INFO - 2023-04-23 14:42:40 --> Hooks Class Initialized
DEBUG - 2023-04-23 14:42:40 --> UTF-8 Support Enabled
INFO - 2023-04-23 14:42:40 --> Utf8 Class Initialized
INFO - 2023-04-23 14:42:40 --> URI Class Initialized
INFO - 2023-04-23 14:42:40 --> Router Class Initialized
INFO - 2023-04-23 14:42:40 --> Output Class Initialized
INFO - 2023-04-23 14:42:40 --> Security Class Initialized
DEBUG - 2023-04-23 14:42:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-23 14:42:40 --> Input Class Initialized
INFO - 2023-04-23 14:42:40 --> Language Class Initialized
INFO - 2023-04-23 14:42:40 --> Loader Class Initialized
INFO - 2023-04-23 14:42:40 --> Helper loaded: url_helper
INFO - 2023-04-23 14:42:40 --> Helper loaded: file_helper
INFO - 2023-04-23 14:42:40 --> Helper loaded: html_helper
INFO - 2023-04-23 14:42:40 --> Helper loaded: text_helper
INFO - 2023-04-23 14:42:40 --> Helper loaded: form_helper
INFO - 2023-04-23 14:42:40 --> Helper loaded: lang_helper
INFO - 2023-04-23 14:42:40 --> Helper loaded: security_helper
INFO - 2023-04-23 14:42:40 --> Helper loaded: cookie_helper
INFO - 2023-04-23 14:42:40 --> Database Driver Class Initialized
INFO - 2023-04-23 14:42:40 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-23 14:42:40 --> Parser Class Initialized
INFO - 2023-04-23 14:42:40 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-23 14:42:40 --> Pagination Class Initialized
INFO - 2023-04-23 14:42:40 --> Form Validation Class Initialized
INFO - 2023-04-23 14:42:40 --> Controller Class Initialized
INFO - 2023-04-23 14:42:40 --> Model Class Initialized
DEBUG - 2023-04-23 14:42:40 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-04-23 14:42:40 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-23 14:42:40 --> Model Class Initialized
DEBUG - 2023-04-23 14:42:40 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-23 14:42:40 --> Model Class Initialized
INFO - 2023-04-23 14:42:40 --> Final output sent to browser
DEBUG - 2023-04-23 14:42:40 --> Total execution time: 0.0201
ERROR - 2023-04-23 14:42:41 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-23 14:42:41 --> Config Class Initialized
INFO - 2023-04-23 14:42:41 --> Hooks Class Initialized
DEBUG - 2023-04-23 14:42:41 --> UTF-8 Support Enabled
INFO - 2023-04-23 14:42:41 --> Utf8 Class Initialized
INFO - 2023-04-23 14:42:41 --> URI Class Initialized
INFO - 2023-04-23 14:42:41 --> Router Class Initialized
INFO - 2023-04-23 14:42:41 --> Output Class Initialized
INFO - 2023-04-23 14:42:41 --> Security Class Initialized
DEBUG - 2023-04-23 14:42:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-23 14:42:41 --> Input Class Initialized
INFO - 2023-04-23 14:42:41 --> Language Class Initialized
INFO - 2023-04-23 14:42:41 --> Loader Class Initialized
INFO - 2023-04-23 14:42:41 --> Helper loaded: url_helper
INFO - 2023-04-23 14:42:41 --> Helper loaded: file_helper
INFO - 2023-04-23 14:42:41 --> Helper loaded: html_helper
INFO - 2023-04-23 14:42:41 --> Helper loaded: text_helper
INFO - 2023-04-23 14:42:41 --> Helper loaded: form_helper
INFO - 2023-04-23 14:42:41 --> Helper loaded: lang_helper
INFO - 2023-04-23 14:42:41 --> Helper loaded: security_helper
INFO - 2023-04-23 14:42:41 --> Helper loaded: cookie_helper
INFO - 2023-04-23 14:42:41 --> Database Driver Class Initialized
INFO - 2023-04-23 14:42:41 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-23 14:42:41 --> Parser Class Initialized
INFO - 2023-04-23 14:42:41 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-23 14:42:41 --> Pagination Class Initialized
INFO - 2023-04-23 14:42:41 --> Form Validation Class Initialized
INFO - 2023-04-23 14:42:41 --> Controller Class Initialized
INFO - 2023-04-23 14:42:41 --> Model Class Initialized
DEBUG - 2023-04-23 14:42:41 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-04-23 14:42:41 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-23 14:42:41 --> Model Class Initialized
DEBUG - 2023-04-23 14:42:41 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-23 14:42:41 --> Model Class Initialized
INFO - 2023-04-23 14:42:41 --> Final output sent to browser
DEBUG - 2023-04-23 14:42:41 --> Total execution time: 0.0171
ERROR - 2023-04-23 14:42:42 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-23 14:42:42 --> Config Class Initialized
INFO - 2023-04-23 14:42:42 --> Hooks Class Initialized
DEBUG - 2023-04-23 14:42:42 --> UTF-8 Support Enabled
INFO - 2023-04-23 14:42:42 --> Utf8 Class Initialized
INFO - 2023-04-23 14:42:42 --> URI Class Initialized
INFO - 2023-04-23 14:42:42 --> Router Class Initialized
INFO - 2023-04-23 14:42:42 --> Output Class Initialized
INFO - 2023-04-23 14:42:42 --> Security Class Initialized
DEBUG - 2023-04-23 14:42:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-23 14:42:42 --> Input Class Initialized
INFO - 2023-04-23 14:42:42 --> Language Class Initialized
INFO - 2023-04-23 14:42:42 --> Loader Class Initialized
INFO - 2023-04-23 14:42:42 --> Helper loaded: url_helper
INFO - 2023-04-23 14:42:42 --> Helper loaded: file_helper
INFO - 2023-04-23 14:42:42 --> Helper loaded: html_helper
INFO - 2023-04-23 14:42:42 --> Helper loaded: text_helper
INFO - 2023-04-23 14:42:42 --> Helper loaded: form_helper
INFO - 2023-04-23 14:42:42 --> Helper loaded: lang_helper
INFO - 2023-04-23 14:42:42 --> Helper loaded: security_helper
INFO - 2023-04-23 14:42:42 --> Helper loaded: cookie_helper
INFO - 2023-04-23 14:42:42 --> Database Driver Class Initialized
INFO - 2023-04-23 14:42:42 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-23 14:42:42 --> Parser Class Initialized
INFO - 2023-04-23 14:42:42 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-23 14:42:42 --> Pagination Class Initialized
INFO - 2023-04-23 14:42:42 --> Form Validation Class Initialized
INFO - 2023-04-23 14:42:42 --> Controller Class Initialized
INFO - 2023-04-23 14:42:42 --> Model Class Initialized
DEBUG - 2023-04-23 14:42:42 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-04-23 14:42:42 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-23 14:42:42 --> Model Class Initialized
DEBUG - 2023-04-23 14:42:42 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-23 14:42:42 --> Model Class Initialized
INFO - 2023-04-23 14:42:42 --> Final output sent to browser
DEBUG - 2023-04-23 14:42:42 --> Total execution time: 0.0174
ERROR - 2023-04-23 14:42:44 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-23 14:42:44 --> Config Class Initialized
INFO - 2023-04-23 14:42:44 --> Hooks Class Initialized
DEBUG - 2023-04-23 14:42:44 --> UTF-8 Support Enabled
INFO - 2023-04-23 14:42:44 --> Utf8 Class Initialized
INFO - 2023-04-23 14:42:44 --> URI Class Initialized
INFO - 2023-04-23 14:42:44 --> Router Class Initialized
INFO - 2023-04-23 14:42:44 --> Output Class Initialized
INFO - 2023-04-23 14:42:44 --> Security Class Initialized
DEBUG - 2023-04-23 14:42:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-23 14:42:44 --> Input Class Initialized
INFO - 2023-04-23 14:42:44 --> Language Class Initialized
INFO - 2023-04-23 14:42:44 --> Loader Class Initialized
INFO - 2023-04-23 14:42:44 --> Helper loaded: url_helper
INFO - 2023-04-23 14:42:44 --> Helper loaded: file_helper
INFO - 2023-04-23 14:42:44 --> Helper loaded: html_helper
INFO - 2023-04-23 14:42:44 --> Helper loaded: text_helper
INFO - 2023-04-23 14:42:44 --> Helper loaded: form_helper
INFO - 2023-04-23 14:42:44 --> Helper loaded: lang_helper
INFO - 2023-04-23 14:42:44 --> Helper loaded: security_helper
INFO - 2023-04-23 14:42:44 --> Helper loaded: cookie_helper
INFO - 2023-04-23 14:42:44 --> Database Driver Class Initialized
INFO - 2023-04-23 14:42:44 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-23 14:42:44 --> Parser Class Initialized
INFO - 2023-04-23 14:42:44 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-23 14:42:44 --> Pagination Class Initialized
INFO - 2023-04-23 14:42:44 --> Form Validation Class Initialized
INFO - 2023-04-23 14:42:44 --> Controller Class Initialized
INFO - 2023-04-23 14:42:44 --> Model Class Initialized
DEBUG - 2023-04-23 14:42:44 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-04-23 14:42:44 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-23 14:42:44 --> Model Class Initialized
DEBUG - 2023-04-23 14:42:44 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-23 14:42:44 --> Model Class Initialized
INFO - 2023-04-23 14:42:44 --> Final output sent to browser
DEBUG - 2023-04-23 14:42:44 --> Total execution time: 0.0173
ERROR - 2023-04-23 14:42:45 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-23 14:42:45 --> Config Class Initialized
INFO - 2023-04-23 14:42:45 --> Hooks Class Initialized
DEBUG - 2023-04-23 14:42:45 --> UTF-8 Support Enabled
INFO - 2023-04-23 14:42:45 --> Utf8 Class Initialized
INFO - 2023-04-23 14:42:45 --> URI Class Initialized
INFO - 2023-04-23 14:42:45 --> Router Class Initialized
INFO - 2023-04-23 14:42:45 --> Output Class Initialized
INFO - 2023-04-23 14:42:45 --> Security Class Initialized
DEBUG - 2023-04-23 14:42:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-23 14:42:45 --> Input Class Initialized
INFO - 2023-04-23 14:42:45 --> Language Class Initialized
INFO - 2023-04-23 14:42:45 --> Loader Class Initialized
INFO - 2023-04-23 14:42:45 --> Helper loaded: url_helper
INFO - 2023-04-23 14:42:45 --> Helper loaded: file_helper
INFO - 2023-04-23 14:42:45 --> Helper loaded: html_helper
INFO - 2023-04-23 14:42:45 --> Helper loaded: text_helper
INFO - 2023-04-23 14:42:45 --> Helper loaded: form_helper
INFO - 2023-04-23 14:42:45 --> Helper loaded: lang_helper
INFO - 2023-04-23 14:42:45 --> Helper loaded: security_helper
INFO - 2023-04-23 14:42:45 --> Helper loaded: cookie_helper
INFO - 2023-04-23 14:42:45 --> Database Driver Class Initialized
INFO - 2023-04-23 14:42:45 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-23 14:42:45 --> Parser Class Initialized
INFO - 2023-04-23 14:42:45 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-23 14:42:45 --> Pagination Class Initialized
INFO - 2023-04-23 14:42:45 --> Form Validation Class Initialized
INFO - 2023-04-23 14:42:45 --> Controller Class Initialized
INFO - 2023-04-23 14:42:45 --> Model Class Initialized
DEBUG - 2023-04-23 14:42:45 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-04-23 14:42:45 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-23 14:42:45 --> Model Class Initialized
DEBUG - 2023-04-23 14:42:45 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-23 14:42:45 --> Model Class Initialized
INFO - 2023-04-23 14:42:45 --> Final output sent to browser
DEBUG - 2023-04-23 14:42:45 --> Total execution time: 0.0171
ERROR - 2023-04-23 14:42:47 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-23 14:42:47 --> Config Class Initialized
INFO - 2023-04-23 14:42:47 --> Hooks Class Initialized
DEBUG - 2023-04-23 14:42:47 --> UTF-8 Support Enabled
INFO - 2023-04-23 14:42:47 --> Utf8 Class Initialized
INFO - 2023-04-23 14:42:47 --> URI Class Initialized
INFO - 2023-04-23 14:42:47 --> Router Class Initialized
INFO - 2023-04-23 14:42:47 --> Output Class Initialized
INFO - 2023-04-23 14:42:47 --> Security Class Initialized
DEBUG - 2023-04-23 14:42:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-23 14:42:47 --> Input Class Initialized
INFO - 2023-04-23 14:42:47 --> Language Class Initialized
INFO - 2023-04-23 14:42:47 --> Loader Class Initialized
INFO - 2023-04-23 14:42:47 --> Helper loaded: url_helper
INFO - 2023-04-23 14:42:47 --> Helper loaded: file_helper
INFO - 2023-04-23 14:42:47 --> Helper loaded: html_helper
INFO - 2023-04-23 14:42:47 --> Helper loaded: text_helper
INFO - 2023-04-23 14:42:47 --> Helper loaded: form_helper
INFO - 2023-04-23 14:42:47 --> Helper loaded: lang_helper
INFO - 2023-04-23 14:42:47 --> Helper loaded: security_helper
INFO - 2023-04-23 14:42:47 --> Helper loaded: cookie_helper
INFO - 2023-04-23 14:42:47 --> Database Driver Class Initialized
INFO - 2023-04-23 14:42:47 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-23 14:42:47 --> Parser Class Initialized
INFO - 2023-04-23 14:42:47 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-23 14:42:47 --> Pagination Class Initialized
INFO - 2023-04-23 14:42:47 --> Form Validation Class Initialized
INFO - 2023-04-23 14:42:47 --> Controller Class Initialized
INFO - 2023-04-23 14:42:47 --> Model Class Initialized
DEBUG - 2023-04-23 14:42:47 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-04-23 14:42:47 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-23 14:42:47 --> Model Class Initialized
DEBUG - 2023-04-23 14:42:47 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-23 14:42:47 --> Model Class Initialized
INFO - 2023-04-23 14:42:47 --> Final output sent to browser
DEBUG - 2023-04-23 14:42:47 --> Total execution time: 0.0162
ERROR - 2023-04-23 14:42:49 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-23 14:42:49 --> Config Class Initialized
INFO - 2023-04-23 14:42:49 --> Hooks Class Initialized
DEBUG - 2023-04-23 14:42:49 --> UTF-8 Support Enabled
INFO - 2023-04-23 14:42:49 --> Utf8 Class Initialized
INFO - 2023-04-23 14:42:49 --> URI Class Initialized
INFO - 2023-04-23 14:42:49 --> Router Class Initialized
INFO - 2023-04-23 14:42:49 --> Output Class Initialized
INFO - 2023-04-23 14:42:49 --> Security Class Initialized
DEBUG - 2023-04-23 14:42:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-23 14:42:49 --> Input Class Initialized
INFO - 2023-04-23 14:42:49 --> Language Class Initialized
INFO - 2023-04-23 14:42:49 --> Loader Class Initialized
INFO - 2023-04-23 14:42:49 --> Helper loaded: url_helper
INFO - 2023-04-23 14:42:49 --> Helper loaded: file_helper
INFO - 2023-04-23 14:42:49 --> Helper loaded: html_helper
INFO - 2023-04-23 14:42:49 --> Helper loaded: text_helper
INFO - 2023-04-23 14:42:49 --> Helper loaded: form_helper
INFO - 2023-04-23 14:42:49 --> Helper loaded: lang_helper
INFO - 2023-04-23 14:42:49 --> Helper loaded: security_helper
INFO - 2023-04-23 14:42:49 --> Helper loaded: cookie_helper
INFO - 2023-04-23 14:42:49 --> Database Driver Class Initialized
INFO - 2023-04-23 14:42:49 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-23 14:42:49 --> Parser Class Initialized
INFO - 2023-04-23 14:42:49 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-23 14:42:49 --> Pagination Class Initialized
INFO - 2023-04-23 14:42:49 --> Form Validation Class Initialized
INFO - 2023-04-23 14:42:49 --> Controller Class Initialized
INFO - 2023-04-23 14:42:49 --> Model Class Initialized
DEBUG - 2023-04-23 14:42:49 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-04-23 14:42:49 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-23 14:42:49 --> Model Class Initialized
DEBUG - 2023-04-23 14:42:49 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-23 14:42:49 --> Model Class Initialized
INFO - 2023-04-23 14:42:49 --> Final output sent to browser
DEBUG - 2023-04-23 14:42:49 --> Total execution time: 0.0179
ERROR - 2023-04-23 14:42:49 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-23 14:42:49 --> Config Class Initialized
INFO - 2023-04-23 14:42:49 --> Hooks Class Initialized
DEBUG - 2023-04-23 14:42:49 --> UTF-8 Support Enabled
INFO - 2023-04-23 14:42:49 --> Utf8 Class Initialized
INFO - 2023-04-23 14:42:49 --> URI Class Initialized
INFO - 2023-04-23 14:42:49 --> Router Class Initialized
INFO - 2023-04-23 14:42:49 --> Output Class Initialized
INFO - 2023-04-23 14:42:49 --> Security Class Initialized
DEBUG - 2023-04-23 14:42:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-23 14:42:49 --> Input Class Initialized
INFO - 2023-04-23 14:42:49 --> Language Class Initialized
INFO - 2023-04-23 14:42:49 --> Loader Class Initialized
INFO - 2023-04-23 14:42:49 --> Helper loaded: url_helper
INFO - 2023-04-23 14:42:49 --> Helper loaded: file_helper
INFO - 2023-04-23 14:42:49 --> Helper loaded: html_helper
INFO - 2023-04-23 14:42:49 --> Helper loaded: text_helper
INFO - 2023-04-23 14:42:49 --> Helper loaded: form_helper
INFO - 2023-04-23 14:42:49 --> Helper loaded: lang_helper
INFO - 2023-04-23 14:42:49 --> Helper loaded: security_helper
INFO - 2023-04-23 14:42:49 --> Helper loaded: cookie_helper
INFO - 2023-04-23 14:42:49 --> Database Driver Class Initialized
INFO - 2023-04-23 14:42:49 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-23 14:42:49 --> Parser Class Initialized
INFO - 2023-04-23 14:42:49 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-23 14:42:49 --> Pagination Class Initialized
INFO - 2023-04-23 14:42:49 --> Form Validation Class Initialized
INFO - 2023-04-23 14:42:49 --> Controller Class Initialized
INFO - 2023-04-23 14:42:49 --> Model Class Initialized
DEBUG - 2023-04-23 14:42:49 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-04-23 14:42:49 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-23 14:42:49 --> Model Class Initialized
DEBUG - 2023-04-23 14:42:49 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-23 14:42:49 --> Model Class Initialized
INFO - 2023-04-23 14:42:49 --> Final output sent to browser
DEBUG - 2023-04-23 14:42:49 --> Total execution time: 0.0162
ERROR - 2023-04-23 14:42:58 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-23 14:42:58 --> Config Class Initialized
INFO - 2023-04-23 14:42:58 --> Hooks Class Initialized
DEBUG - 2023-04-23 14:42:58 --> UTF-8 Support Enabled
INFO - 2023-04-23 14:42:58 --> Utf8 Class Initialized
INFO - 2023-04-23 14:42:58 --> URI Class Initialized
INFO - 2023-04-23 14:42:58 --> Router Class Initialized
INFO - 2023-04-23 14:42:58 --> Output Class Initialized
INFO - 2023-04-23 14:42:58 --> Security Class Initialized
DEBUG - 2023-04-23 14:42:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-23 14:42:58 --> Input Class Initialized
INFO - 2023-04-23 14:42:58 --> Language Class Initialized
INFO - 2023-04-23 14:42:58 --> Loader Class Initialized
INFO - 2023-04-23 14:42:58 --> Helper loaded: url_helper
INFO - 2023-04-23 14:42:58 --> Helper loaded: file_helper
INFO - 2023-04-23 14:42:58 --> Helper loaded: html_helper
INFO - 2023-04-23 14:42:58 --> Helper loaded: text_helper
INFO - 2023-04-23 14:42:58 --> Helper loaded: form_helper
INFO - 2023-04-23 14:42:58 --> Helper loaded: lang_helper
INFO - 2023-04-23 14:42:58 --> Helper loaded: security_helper
INFO - 2023-04-23 14:42:58 --> Helper loaded: cookie_helper
INFO - 2023-04-23 14:42:58 --> Database Driver Class Initialized
INFO - 2023-04-23 14:42:58 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-23 14:42:58 --> Parser Class Initialized
INFO - 2023-04-23 14:42:58 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-23 14:42:58 --> Pagination Class Initialized
INFO - 2023-04-23 14:42:58 --> Form Validation Class Initialized
INFO - 2023-04-23 14:42:58 --> Controller Class Initialized
INFO - 2023-04-23 14:42:58 --> Model Class Initialized
DEBUG - 2023-04-23 14:42:58 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-04-23 14:42:58 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-23 14:42:58 --> Model Class Initialized
DEBUG - 2023-04-23 14:42:58 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-23 14:42:58 --> Model Class Initialized
INFO - 2023-04-23 14:42:58 --> Final output sent to browser
DEBUG - 2023-04-23 14:42:58 --> Total execution time: 0.0173
ERROR - 2023-04-23 14:43:00 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-23 14:43:00 --> Config Class Initialized
INFO - 2023-04-23 14:43:00 --> Hooks Class Initialized
DEBUG - 2023-04-23 14:43:00 --> UTF-8 Support Enabled
INFO - 2023-04-23 14:43:00 --> Utf8 Class Initialized
INFO - 2023-04-23 14:43:00 --> URI Class Initialized
INFO - 2023-04-23 14:43:00 --> Router Class Initialized
INFO - 2023-04-23 14:43:00 --> Output Class Initialized
INFO - 2023-04-23 14:43:00 --> Security Class Initialized
DEBUG - 2023-04-23 14:43:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-23 14:43:00 --> Input Class Initialized
INFO - 2023-04-23 14:43:00 --> Language Class Initialized
INFO - 2023-04-23 14:43:00 --> Loader Class Initialized
INFO - 2023-04-23 14:43:00 --> Helper loaded: url_helper
INFO - 2023-04-23 14:43:00 --> Helper loaded: file_helper
INFO - 2023-04-23 14:43:00 --> Helper loaded: html_helper
INFO - 2023-04-23 14:43:00 --> Helper loaded: text_helper
INFO - 2023-04-23 14:43:00 --> Helper loaded: form_helper
INFO - 2023-04-23 14:43:00 --> Helper loaded: lang_helper
INFO - 2023-04-23 14:43:00 --> Helper loaded: security_helper
INFO - 2023-04-23 14:43:00 --> Helper loaded: cookie_helper
INFO - 2023-04-23 14:43:00 --> Database Driver Class Initialized
INFO - 2023-04-23 14:43:00 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-23 14:43:00 --> Parser Class Initialized
INFO - 2023-04-23 14:43:00 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-23 14:43:00 --> Pagination Class Initialized
INFO - 2023-04-23 14:43:00 --> Form Validation Class Initialized
INFO - 2023-04-23 14:43:00 --> Controller Class Initialized
INFO - 2023-04-23 14:43:00 --> Model Class Initialized
DEBUG - 2023-04-23 14:43:00 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-04-23 14:43:00 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-23 14:43:00 --> Model Class Initialized
DEBUG - 2023-04-23 14:43:00 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-23 14:43:00 --> Model Class Initialized
INFO - 2023-04-23 14:43:00 --> Final output sent to browser
DEBUG - 2023-04-23 14:43:00 --> Total execution time: 0.0175
ERROR - 2023-04-23 14:43:01 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-23 14:43:01 --> Config Class Initialized
INFO - 2023-04-23 14:43:01 --> Hooks Class Initialized
DEBUG - 2023-04-23 14:43:01 --> UTF-8 Support Enabled
INFO - 2023-04-23 14:43:01 --> Utf8 Class Initialized
INFO - 2023-04-23 14:43:01 --> URI Class Initialized
INFO - 2023-04-23 14:43:01 --> Router Class Initialized
INFO - 2023-04-23 14:43:01 --> Output Class Initialized
INFO - 2023-04-23 14:43:01 --> Security Class Initialized
DEBUG - 2023-04-23 14:43:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-23 14:43:01 --> Input Class Initialized
INFO - 2023-04-23 14:43:01 --> Language Class Initialized
INFO - 2023-04-23 14:43:01 --> Loader Class Initialized
INFO - 2023-04-23 14:43:01 --> Helper loaded: url_helper
INFO - 2023-04-23 14:43:01 --> Helper loaded: file_helper
INFO - 2023-04-23 14:43:01 --> Helper loaded: html_helper
INFO - 2023-04-23 14:43:01 --> Helper loaded: text_helper
INFO - 2023-04-23 14:43:01 --> Helper loaded: form_helper
INFO - 2023-04-23 14:43:01 --> Helper loaded: lang_helper
INFO - 2023-04-23 14:43:01 --> Helper loaded: security_helper
INFO - 2023-04-23 14:43:01 --> Helper loaded: cookie_helper
INFO - 2023-04-23 14:43:01 --> Database Driver Class Initialized
INFO - 2023-04-23 14:43:01 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-23 14:43:01 --> Parser Class Initialized
INFO - 2023-04-23 14:43:01 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-23 14:43:01 --> Pagination Class Initialized
INFO - 2023-04-23 14:43:01 --> Form Validation Class Initialized
INFO - 2023-04-23 14:43:01 --> Controller Class Initialized
INFO - 2023-04-23 14:43:01 --> Model Class Initialized
DEBUG - 2023-04-23 14:43:01 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-04-23 14:43:01 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-23 14:43:01 --> Model Class Initialized
DEBUG - 2023-04-23 14:43:01 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-23 14:43:01 --> Model Class Initialized
INFO - 2023-04-23 14:43:01 --> Final output sent to browser
DEBUG - 2023-04-23 14:43:01 --> Total execution time: 0.0175
ERROR - 2023-04-23 14:43:04 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-23 14:43:04 --> Config Class Initialized
INFO - 2023-04-23 14:43:04 --> Hooks Class Initialized
DEBUG - 2023-04-23 14:43:04 --> UTF-8 Support Enabled
INFO - 2023-04-23 14:43:04 --> Utf8 Class Initialized
INFO - 2023-04-23 14:43:04 --> URI Class Initialized
INFO - 2023-04-23 14:43:04 --> Router Class Initialized
INFO - 2023-04-23 14:43:04 --> Output Class Initialized
INFO - 2023-04-23 14:43:04 --> Security Class Initialized
DEBUG - 2023-04-23 14:43:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-23 14:43:04 --> Input Class Initialized
INFO - 2023-04-23 14:43:04 --> Language Class Initialized
INFO - 2023-04-23 14:43:04 --> Loader Class Initialized
INFO - 2023-04-23 14:43:04 --> Helper loaded: url_helper
INFO - 2023-04-23 14:43:04 --> Helper loaded: file_helper
INFO - 2023-04-23 14:43:04 --> Helper loaded: html_helper
INFO - 2023-04-23 14:43:04 --> Helper loaded: text_helper
INFO - 2023-04-23 14:43:04 --> Helper loaded: form_helper
INFO - 2023-04-23 14:43:04 --> Helper loaded: lang_helper
INFO - 2023-04-23 14:43:04 --> Helper loaded: security_helper
INFO - 2023-04-23 14:43:04 --> Helper loaded: cookie_helper
INFO - 2023-04-23 14:43:04 --> Database Driver Class Initialized
INFO - 2023-04-23 14:43:04 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-23 14:43:04 --> Parser Class Initialized
INFO - 2023-04-23 14:43:04 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-23 14:43:04 --> Pagination Class Initialized
INFO - 2023-04-23 14:43:04 --> Form Validation Class Initialized
INFO - 2023-04-23 14:43:04 --> Controller Class Initialized
INFO - 2023-04-23 14:43:04 --> Model Class Initialized
DEBUG - 2023-04-23 14:43:04 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-04-23 14:43:04 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-23 14:43:04 --> Model Class Initialized
DEBUG - 2023-04-23 14:43:04 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-23 14:43:04 --> Model Class Initialized
INFO - 2023-04-23 14:43:04 --> Final output sent to browser
DEBUG - 2023-04-23 14:43:04 --> Total execution time: 0.0173
ERROR - 2023-04-23 14:43:06 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-23 14:43:06 --> Config Class Initialized
INFO - 2023-04-23 14:43:06 --> Hooks Class Initialized
DEBUG - 2023-04-23 14:43:06 --> UTF-8 Support Enabled
INFO - 2023-04-23 14:43:06 --> Utf8 Class Initialized
INFO - 2023-04-23 14:43:06 --> URI Class Initialized
INFO - 2023-04-23 14:43:06 --> Router Class Initialized
INFO - 2023-04-23 14:43:06 --> Output Class Initialized
INFO - 2023-04-23 14:43:06 --> Security Class Initialized
DEBUG - 2023-04-23 14:43:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-23 14:43:06 --> Input Class Initialized
INFO - 2023-04-23 14:43:06 --> Language Class Initialized
INFO - 2023-04-23 14:43:06 --> Loader Class Initialized
INFO - 2023-04-23 14:43:06 --> Helper loaded: url_helper
INFO - 2023-04-23 14:43:06 --> Helper loaded: file_helper
INFO - 2023-04-23 14:43:06 --> Helper loaded: html_helper
INFO - 2023-04-23 14:43:06 --> Helper loaded: text_helper
INFO - 2023-04-23 14:43:06 --> Helper loaded: form_helper
INFO - 2023-04-23 14:43:06 --> Helper loaded: lang_helper
INFO - 2023-04-23 14:43:06 --> Helper loaded: security_helper
INFO - 2023-04-23 14:43:06 --> Helper loaded: cookie_helper
INFO - 2023-04-23 14:43:06 --> Database Driver Class Initialized
INFO - 2023-04-23 14:43:06 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-23 14:43:06 --> Parser Class Initialized
INFO - 2023-04-23 14:43:06 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-23 14:43:06 --> Pagination Class Initialized
INFO - 2023-04-23 14:43:06 --> Form Validation Class Initialized
INFO - 2023-04-23 14:43:06 --> Controller Class Initialized
INFO - 2023-04-23 14:43:06 --> Model Class Initialized
DEBUG - 2023-04-23 14:43:06 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-04-23 14:43:06 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-23 14:43:06 --> Model Class Initialized
INFO - 2023-04-23 14:43:06 --> Model Class Initialized
INFO - 2023-04-23 14:43:06 --> Final output sent to browser
DEBUG - 2023-04-23 14:43:06 --> Total execution time: 0.0170
ERROR - 2023-04-23 14:43:40 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-23 14:43:40 --> Config Class Initialized
INFO - 2023-04-23 14:43:40 --> Hooks Class Initialized
DEBUG - 2023-04-23 14:43:40 --> UTF-8 Support Enabled
INFO - 2023-04-23 14:43:40 --> Utf8 Class Initialized
INFO - 2023-04-23 14:43:40 --> URI Class Initialized
INFO - 2023-04-23 14:43:40 --> Router Class Initialized
INFO - 2023-04-23 14:43:40 --> Output Class Initialized
INFO - 2023-04-23 14:43:40 --> Security Class Initialized
DEBUG - 2023-04-23 14:43:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-23 14:43:40 --> Input Class Initialized
INFO - 2023-04-23 14:43:40 --> Language Class Initialized
INFO - 2023-04-23 14:43:40 --> Loader Class Initialized
INFO - 2023-04-23 14:43:40 --> Helper loaded: url_helper
INFO - 2023-04-23 14:43:40 --> Helper loaded: file_helper
INFO - 2023-04-23 14:43:40 --> Helper loaded: html_helper
INFO - 2023-04-23 14:43:40 --> Helper loaded: text_helper
INFO - 2023-04-23 14:43:40 --> Helper loaded: form_helper
INFO - 2023-04-23 14:43:40 --> Helper loaded: lang_helper
INFO - 2023-04-23 14:43:40 --> Helper loaded: security_helper
INFO - 2023-04-23 14:43:40 --> Helper loaded: cookie_helper
INFO - 2023-04-23 14:43:40 --> Database Driver Class Initialized
INFO - 2023-04-23 14:43:40 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-23 14:43:40 --> Parser Class Initialized
INFO - 2023-04-23 14:43:40 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-23 14:43:40 --> Pagination Class Initialized
INFO - 2023-04-23 14:43:40 --> Form Validation Class Initialized
INFO - 2023-04-23 14:43:40 --> Controller Class Initialized
INFO - 2023-04-23 14:43:40 --> Model Class Initialized
DEBUG - 2023-04-23 14:43:40 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-04-23 14:43:40 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-23 14:43:40 --> Model Class Initialized
INFO - 2023-04-23 14:43:40 --> Email Class Initialized
INFO - 2023-04-23 14:43:40 --> Language file loaded: language/english/email_lang.php
ERROR - 2023-04-23 14:43:41 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-23 14:43:41 --> Config Class Initialized
INFO - 2023-04-23 14:43:41 --> Hooks Class Initialized
DEBUG - 2023-04-23 14:43:41 --> UTF-8 Support Enabled
INFO - 2023-04-23 14:43:41 --> Utf8 Class Initialized
INFO - 2023-04-23 14:43:41 --> URI Class Initialized
INFO - 2023-04-23 14:43:41 --> Router Class Initialized
INFO - 2023-04-23 14:43:41 --> Output Class Initialized
INFO - 2023-04-23 14:43:41 --> Security Class Initialized
DEBUG - 2023-04-23 14:43:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-23 14:43:41 --> Input Class Initialized
INFO - 2023-04-23 14:43:41 --> Language Class Initialized
INFO - 2023-04-23 14:43:41 --> Loader Class Initialized
INFO - 2023-04-23 14:43:41 --> Helper loaded: url_helper
INFO - 2023-04-23 14:43:41 --> Helper loaded: file_helper
INFO - 2023-04-23 14:43:41 --> Helper loaded: html_helper
INFO - 2023-04-23 14:43:41 --> Helper loaded: text_helper
INFO - 2023-04-23 14:43:41 --> Helper loaded: form_helper
INFO - 2023-04-23 14:43:41 --> Helper loaded: lang_helper
INFO - 2023-04-23 14:43:41 --> Helper loaded: security_helper
INFO - 2023-04-23 14:43:41 --> Helper loaded: cookie_helper
INFO - 2023-04-23 14:43:41 --> Database Driver Class Initialized
INFO - 2023-04-23 14:43:41 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-23 14:43:41 --> Parser Class Initialized
INFO - 2023-04-23 14:43:41 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-23 14:43:41 --> Pagination Class Initialized
INFO - 2023-04-23 14:43:41 --> Form Validation Class Initialized
INFO - 2023-04-23 14:43:41 --> Controller Class Initialized
INFO - 2023-04-23 14:43:41 --> Model Class Initialized
DEBUG - 2023-04-23 14:43:41 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-04-23 14:43:41 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-23 14:43:41 --> Model Class Initialized
DEBUG - 2023-04-23 14:43:41 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-23 14:43:41 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/demandrequest/add_demandrequest_form.php
DEBUG - 2023-04-23 14:43:41 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-04-23 14:43:41 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-04-23 14:43:41 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-04-23 14:43:41 --> Model Class Initialized
INFO - 2023-04-23 14:43:41 --> Model Class Initialized
INFO - 2023-04-23 14:43:41 --> Model Class Initialized
INFO - 2023-04-23 14:43:41 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-04-23 14:43:41 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-04-23 14:43:41 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-04-23 14:43:41 --> Final output sent to browser
DEBUG - 2023-04-23 14:43:41 --> Total execution time: 0.0565
ERROR - 2023-04-23 14:44:00 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-23 14:44:00 --> Config Class Initialized
INFO - 2023-04-23 14:44:00 --> Hooks Class Initialized
DEBUG - 2023-04-23 14:44:00 --> UTF-8 Support Enabled
INFO - 2023-04-23 14:44:00 --> Utf8 Class Initialized
INFO - 2023-04-23 14:44:00 --> URI Class Initialized
INFO - 2023-04-23 14:44:00 --> Router Class Initialized
INFO - 2023-04-23 14:44:00 --> Output Class Initialized
INFO - 2023-04-23 14:44:00 --> Security Class Initialized
DEBUG - 2023-04-23 14:44:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-23 14:44:00 --> Input Class Initialized
INFO - 2023-04-23 14:44:00 --> Language Class Initialized
INFO - 2023-04-23 14:44:00 --> Loader Class Initialized
INFO - 2023-04-23 14:44:00 --> Helper loaded: url_helper
INFO - 2023-04-23 14:44:00 --> Helper loaded: file_helper
INFO - 2023-04-23 14:44:00 --> Helper loaded: html_helper
INFO - 2023-04-23 14:44:00 --> Helper loaded: text_helper
INFO - 2023-04-23 14:44:00 --> Helper loaded: form_helper
INFO - 2023-04-23 14:44:00 --> Helper loaded: lang_helper
INFO - 2023-04-23 14:44:00 --> Helper loaded: security_helper
INFO - 2023-04-23 14:44:00 --> Helper loaded: cookie_helper
INFO - 2023-04-23 14:44:00 --> Database Driver Class Initialized
INFO - 2023-04-23 14:44:00 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-23 14:44:00 --> Parser Class Initialized
INFO - 2023-04-23 14:44:00 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-23 14:44:00 --> Pagination Class Initialized
INFO - 2023-04-23 14:44:00 --> Form Validation Class Initialized
INFO - 2023-04-23 14:44:00 --> Controller Class Initialized
INFO - 2023-04-23 14:44:00 --> Model Class Initialized
DEBUG - 2023-04-23 14:44:00 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-04-23 14:44:00 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-23 14:44:00 --> Model Class Initialized
INFO - 2023-04-23 14:44:00 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/demandrequest/customer_demandrequest.php
DEBUG - 2023-04-23 14:44:00 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-04-23 14:44:00 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-04-23 14:44:00 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-04-23 14:44:00 --> Model Class Initialized
INFO - 2023-04-23 14:44:00 --> Model Class Initialized
INFO - 2023-04-23 14:44:00 --> Model Class Initialized
INFO - 2023-04-23 14:44:00 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-04-23 14:44:00 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-04-23 14:44:00 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-04-23 14:44:00 --> Final output sent to browser
DEBUG - 2023-04-23 14:44:00 --> Total execution time: 0.1531
ERROR - 2023-04-23 14:44:00 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-23 14:44:00 --> Config Class Initialized
INFO - 2023-04-23 14:44:00 --> Hooks Class Initialized
DEBUG - 2023-04-23 14:44:00 --> UTF-8 Support Enabled
INFO - 2023-04-23 14:44:00 --> Utf8 Class Initialized
INFO - 2023-04-23 14:44:00 --> URI Class Initialized
INFO - 2023-04-23 14:44:00 --> Router Class Initialized
INFO - 2023-04-23 14:44:00 --> Output Class Initialized
INFO - 2023-04-23 14:44:00 --> Security Class Initialized
DEBUG - 2023-04-23 14:44:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-23 14:44:00 --> Input Class Initialized
INFO - 2023-04-23 14:44:00 --> Language Class Initialized
INFO - 2023-04-23 14:44:00 --> Loader Class Initialized
INFO - 2023-04-23 14:44:00 --> Helper loaded: url_helper
INFO - 2023-04-23 14:44:00 --> Helper loaded: file_helper
INFO - 2023-04-23 14:44:00 --> Helper loaded: html_helper
INFO - 2023-04-23 14:44:00 --> Helper loaded: text_helper
INFO - 2023-04-23 14:44:00 --> Helper loaded: form_helper
INFO - 2023-04-23 14:44:00 --> Helper loaded: lang_helper
INFO - 2023-04-23 14:44:00 --> Helper loaded: security_helper
INFO - 2023-04-23 14:44:00 --> Helper loaded: cookie_helper
INFO - 2023-04-23 14:44:00 --> Database Driver Class Initialized
INFO - 2023-04-23 14:44:00 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-23 14:44:00 --> Parser Class Initialized
INFO - 2023-04-23 14:44:00 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-23 14:44:00 --> Pagination Class Initialized
INFO - 2023-04-23 14:44:00 --> Form Validation Class Initialized
INFO - 2023-04-23 14:44:00 --> Controller Class Initialized
INFO - 2023-04-23 14:44:00 --> Model Class Initialized
DEBUG - 2023-04-23 14:44:00 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-04-23 14:44:00 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-23 14:44:00 --> Model Class Initialized
INFO - 2023-04-23 14:44:00 --> Final output sent to browser
DEBUG - 2023-04-23 14:44:00 --> Total execution time: 0.0284
ERROR - 2023-04-23 14:44:10 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-23 14:44:10 --> Config Class Initialized
INFO - 2023-04-23 14:44:10 --> Hooks Class Initialized
DEBUG - 2023-04-23 14:44:10 --> UTF-8 Support Enabled
INFO - 2023-04-23 14:44:10 --> Utf8 Class Initialized
INFO - 2023-04-23 14:44:10 --> URI Class Initialized
INFO - 2023-04-23 14:44:10 --> Router Class Initialized
INFO - 2023-04-23 14:44:10 --> Output Class Initialized
INFO - 2023-04-23 14:44:10 --> Security Class Initialized
DEBUG - 2023-04-23 14:44:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-23 14:44:10 --> Input Class Initialized
INFO - 2023-04-23 14:44:10 --> Language Class Initialized
INFO - 2023-04-23 14:44:10 --> Loader Class Initialized
INFO - 2023-04-23 14:44:10 --> Helper loaded: url_helper
INFO - 2023-04-23 14:44:10 --> Helper loaded: file_helper
INFO - 2023-04-23 14:44:10 --> Helper loaded: html_helper
INFO - 2023-04-23 14:44:10 --> Helper loaded: text_helper
INFO - 2023-04-23 14:44:10 --> Helper loaded: form_helper
INFO - 2023-04-23 14:44:10 --> Helper loaded: lang_helper
INFO - 2023-04-23 14:44:10 --> Helper loaded: security_helper
INFO - 2023-04-23 14:44:10 --> Helper loaded: cookie_helper
INFO - 2023-04-23 14:44:10 --> Database Driver Class Initialized
INFO - 2023-04-23 14:44:10 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-23 14:44:10 --> Parser Class Initialized
INFO - 2023-04-23 14:44:10 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-23 14:44:10 --> Pagination Class Initialized
INFO - 2023-04-23 14:44:10 --> Form Validation Class Initialized
INFO - 2023-04-23 14:44:10 --> Controller Class Initialized
INFO - 2023-04-23 14:44:10 --> Model Class Initialized
DEBUG - 2023-04-23 14:44:10 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-04-23 14:44:10 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-23 14:44:10 --> Model Class Initialized
DEBUG - 2023-04-23 14:44:10 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-23 14:44:10 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/demandrequest/demandrequest_html.php
DEBUG - 2023-04-23 14:44:10 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-04-23 14:44:10 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-04-23 14:44:10 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-04-23 14:44:10 --> Model Class Initialized
INFO - 2023-04-23 14:44:10 --> Model Class Initialized
INFO - 2023-04-23 14:44:10 --> Model Class Initialized
INFO - 2023-04-23 14:44:10 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-04-23 14:44:10 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-04-23 14:44:10 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-04-23 14:44:10 --> Final output sent to browser
DEBUG - 2023-04-23 14:44:10 --> Total execution time: 0.1388
ERROR - 2023-04-23 14:45:25 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-23 14:45:25 --> Config Class Initialized
INFO - 2023-04-23 14:45:25 --> Hooks Class Initialized
DEBUG - 2023-04-23 14:45:25 --> UTF-8 Support Enabled
INFO - 2023-04-23 14:45:25 --> Utf8 Class Initialized
INFO - 2023-04-23 14:45:25 --> URI Class Initialized
INFO - 2023-04-23 14:45:25 --> Router Class Initialized
INFO - 2023-04-23 14:45:25 --> Output Class Initialized
INFO - 2023-04-23 14:45:25 --> Security Class Initialized
DEBUG - 2023-04-23 14:45:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-23 14:45:25 --> Input Class Initialized
INFO - 2023-04-23 14:45:25 --> Language Class Initialized
INFO - 2023-04-23 14:45:25 --> Loader Class Initialized
INFO - 2023-04-23 14:45:25 --> Helper loaded: url_helper
INFO - 2023-04-23 14:45:25 --> Helper loaded: file_helper
INFO - 2023-04-23 14:45:25 --> Helper loaded: html_helper
INFO - 2023-04-23 14:45:25 --> Helper loaded: text_helper
INFO - 2023-04-23 14:45:25 --> Helper loaded: form_helper
INFO - 2023-04-23 14:45:25 --> Helper loaded: lang_helper
INFO - 2023-04-23 14:45:25 --> Helper loaded: security_helper
INFO - 2023-04-23 14:45:25 --> Helper loaded: cookie_helper
INFO - 2023-04-23 14:45:25 --> Database Driver Class Initialized
INFO - 2023-04-23 14:45:25 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-23 14:45:25 --> Parser Class Initialized
INFO - 2023-04-23 14:45:25 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-23 14:45:25 --> Pagination Class Initialized
INFO - 2023-04-23 14:45:25 --> Form Validation Class Initialized
INFO - 2023-04-23 14:45:25 --> Controller Class Initialized
INFO - 2023-04-23 14:45:25 --> Model Class Initialized
DEBUG - 2023-04-23 14:45:25 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-04-23 14:45:25 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-23 14:45:25 --> Model Class Initialized
INFO - 2023-04-23 14:45:25 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/demandrequest/customer_demandrequest.php
DEBUG - 2023-04-23 14:45:25 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-04-23 14:45:25 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-04-23 14:45:25 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-04-23 14:45:25 --> Model Class Initialized
INFO - 2023-04-23 14:45:25 --> Model Class Initialized
INFO - 2023-04-23 14:45:25 --> Model Class Initialized
INFO - 2023-04-23 14:45:25 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-04-23 14:45:25 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-04-23 14:45:25 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-04-23 14:45:25 --> Final output sent to browser
DEBUG - 2023-04-23 14:45:25 --> Total execution time: 0.1417
ERROR - 2023-04-23 14:45:26 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-23 14:45:26 --> Config Class Initialized
INFO - 2023-04-23 14:45:26 --> Hooks Class Initialized
DEBUG - 2023-04-23 14:45:26 --> UTF-8 Support Enabled
INFO - 2023-04-23 14:45:26 --> Utf8 Class Initialized
INFO - 2023-04-23 14:45:26 --> URI Class Initialized
INFO - 2023-04-23 14:45:26 --> Router Class Initialized
INFO - 2023-04-23 14:45:26 --> Output Class Initialized
INFO - 2023-04-23 14:45:26 --> Security Class Initialized
DEBUG - 2023-04-23 14:45:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-23 14:45:26 --> Input Class Initialized
INFO - 2023-04-23 14:45:26 --> Language Class Initialized
INFO - 2023-04-23 14:45:26 --> Loader Class Initialized
INFO - 2023-04-23 14:45:26 --> Helper loaded: url_helper
INFO - 2023-04-23 14:45:26 --> Helper loaded: file_helper
INFO - 2023-04-23 14:45:26 --> Helper loaded: html_helper
INFO - 2023-04-23 14:45:26 --> Helper loaded: text_helper
INFO - 2023-04-23 14:45:26 --> Helper loaded: form_helper
INFO - 2023-04-23 14:45:26 --> Helper loaded: lang_helper
INFO - 2023-04-23 14:45:26 --> Helper loaded: security_helper
INFO - 2023-04-23 14:45:26 --> Helper loaded: cookie_helper
INFO - 2023-04-23 14:45:26 --> Database Driver Class Initialized
INFO - 2023-04-23 14:45:26 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-23 14:45:26 --> Parser Class Initialized
INFO - 2023-04-23 14:45:26 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-23 14:45:26 --> Pagination Class Initialized
INFO - 2023-04-23 14:45:26 --> Form Validation Class Initialized
INFO - 2023-04-23 14:45:26 --> Controller Class Initialized
INFO - 2023-04-23 14:45:26 --> Model Class Initialized
DEBUG - 2023-04-23 14:45:26 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-04-23 14:45:26 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-23 14:45:26 --> Model Class Initialized
INFO - 2023-04-23 14:45:26 --> Final output sent to browser
DEBUG - 2023-04-23 14:45:26 --> Total execution time: 0.0299
ERROR - 2023-04-23 14:45:37 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-23 14:45:37 --> Config Class Initialized
INFO - 2023-04-23 14:45:37 --> Hooks Class Initialized
DEBUG - 2023-04-23 14:45:37 --> UTF-8 Support Enabled
INFO - 2023-04-23 14:45:37 --> Utf8 Class Initialized
INFO - 2023-04-23 14:45:37 --> URI Class Initialized
INFO - 2023-04-23 14:45:37 --> Router Class Initialized
INFO - 2023-04-23 14:45:37 --> Output Class Initialized
INFO - 2023-04-23 14:45:37 --> Security Class Initialized
DEBUG - 2023-04-23 14:45:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-23 14:45:37 --> Input Class Initialized
INFO - 2023-04-23 14:45:37 --> Language Class Initialized
INFO - 2023-04-23 14:45:37 --> Loader Class Initialized
INFO - 2023-04-23 14:45:37 --> Helper loaded: url_helper
INFO - 2023-04-23 14:45:37 --> Helper loaded: file_helper
INFO - 2023-04-23 14:45:37 --> Helper loaded: html_helper
INFO - 2023-04-23 14:45:37 --> Helper loaded: text_helper
INFO - 2023-04-23 14:45:37 --> Helper loaded: form_helper
INFO - 2023-04-23 14:45:37 --> Helper loaded: lang_helper
INFO - 2023-04-23 14:45:37 --> Helper loaded: security_helper
INFO - 2023-04-23 14:45:37 --> Helper loaded: cookie_helper
INFO - 2023-04-23 14:45:37 --> Database Driver Class Initialized
INFO - 2023-04-23 14:45:37 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-23 14:45:37 --> Parser Class Initialized
INFO - 2023-04-23 14:45:37 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-23 14:45:37 --> Pagination Class Initialized
INFO - 2023-04-23 14:45:37 --> Form Validation Class Initialized
INFO - 2023-04-23 14:45:37 --> Controller Class Initialized
INFO - 2023-04-23 14:45:37 --> Model Class Initialized
DEBUG - 2023-04-23 14:45:37 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-04-23 14:45:37 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-23 14:45:37 --> Model Class Initialized
ERROR - 2023-04-23 14:45:37 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-23 14:45:37 --> Config Class Initialized
INFO - 2023-04-23 14:45:37 --> Hooks Class Initialized
DEBUG - 2023-04-23 14:45:37 --> UTF-8 Support Enabled
INFO - 2023-04-23 14:45:37 --> Utf8 Class Initialized
INFO - 2023-04-23 14:45:37 --> URI Class Initialized
INFO - 2023-04-23 14:45:37 --> Router Class Initialized
INFO - 2023-04-23 14:45:37 --> Output Class Initialized
INFO - 2023-04-23 14:45:37 --> Security Class Initialized
DEBUG - 2023-04-23 14:45:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-23 14:45:37 --> Input Class Initialized
INFO - 2023-04-23 14:45:37 --> Language Class Initialized
INFO - 2023-04-23 14:45:37 --> Loader Class Initialized
INFO - 2023-04-23 14:45:37 --> Helper loaded: url_helper
INFO - 2023-04-23 14:45:37 --> Helper loaded: file_helper
INFO - 2023-04-23 14:45:37 --> Helper loaded: html_helper
INFO - 2023-04-23 14:45:37 --> Helper loaded: text_helper
INFO - 2023-04-23 14:45:37 --> Helper loaded: form_helper
INFO - 2023-04-23 14:45:37 --> Helper loaded: lang_helper
INFO - 2023-04-23 14:45:37 --> Helper loaded: security_helper
INFO - 2023-04-23 14:45:37 --> Helper loaded: cookie_helper
INFO - 2023-04-23 14:45:37 --> Database Driver Class Initialized
INFO - 2023-04-23 14:45:37 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-23 14:45:37 --> Parser Class Initialized
INFO - 2023-04-23 14:45:37 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-23 14:45:37 --> Pagination Class Initialized
INFO - 2023-04-23 14:45:37 --> Form Validation Class Initialized
INFO - 2023-04-23 14:45:37 --> Controller Class Initialized
INFO - 2023-04-23 14:45:37 --> Model Class Initialized
DEBUG - 2023-04-23 14:45:37 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-04-23 14:45:37 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-23 14:45:37 --> Model Class Initialized
INFO - 2023-04-23 14:45:37 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/demandrequest/customer_demandrequest.php
DEBUG - 2023-04-23 14:45:37 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-04-23 14:45:37 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-04-23 14:45:37 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-04-23 14:45:37 --> Model Class Initialized
INFO - 2023-04-23 14:45:37 --> Model Class Initialized
INFO - 2023-04-23 14:45:37 --> Model Class Initialized
INFO - 2023-04-23 14:45:37 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-04-23 14:45:37 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-04-23 14:45:37 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-04-23 14:45:37 --> Final output sent to browser
DEBUG - 2023-04-23 14:45:37 --> Total execution time: 0.1444
ERROR - 2023-04-23 14:45:38 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-23 14:45:38 --> Config Class Initialized
INFO - 2023-04-23 14:45:38 --> Hooks Class Initialized
DEBUG - 2023-04-23 14:45:38 --> UTF-8 Support Enabled
INFO - 2023-04-23 14:45:38 --> Utf8 Class Initialized
INFO - 2023-04-23 14:45:38 --> URI Class Initialized
INFO - 2023-04-23 14:45:38 --> Router Class Initialized
INFO - 2023-04-23 14:45:38 --> Output Class Initialized
INFO - 2023-04-23 14:45:38 --> Security Class Initialized
DEBUG - 2023-04-23 14:45:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-23 14:45:38 --> Input Class Initialized
INFO - 2023-04-23 14:45:38 --> Language Class Initialized
INFO - 2023-04-23 14:45:38 --> Loader Class Initialized
INFO - 2023-04-23 14:45:38 --> Helper loaded: url_helper
INFO - 2023-04-23 14:45:38 --> Helper loaded: file_helper
INFO - 2023-04-23 14:45:38 --> Helper loaded: html_helper
INFO - 2023-04-23 14:45:38 --> Helper loaded: text_helper
INFO - 2023-04-23 14:45:38 --> Helper loaded: form_helper
INFO - 2023-04-23 14:45:38 --> Helper loaded: lang_helper
INFO - 2023-04-23 14:45:38 --> Helper loaded: security_helper
INFO - 2023-04-23 14:45:38 --> Helper loaded: cookie_helper
INFO - 2023-04-23 14:45:38 --> Database Driver Class Initialized
INFO - 2023-04-23 14:45:38 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-23 14:45:38 --> Parser Class Initialized
INFO - 2023-04-23 14:45:38 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-23 14:45:38 --> Pagination Class Initialized
INFO - 2023-04-23 14:45:38 --> Form Validation Class Initialized
INFO - 2023-04-23 14:45:38 --> Controller Class Initialized
INFO - 2023-04-23 14:45:38 --> Model Class Initialized
DEBUG - 2023-04-23 14:45:38 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-04-23 14:45:38 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-23 14:45:38 --> Model Class Initialized
INFO - 2023-04-23 14:45:38 --> Final output sent to browser
DEBUG - 2023-04-23 14:45:38 --> Total execution time: 0.0284
ERROR - 2023-04-23 14:45:53 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-23 14:45:53 --> Config Class Initialized
INFO - 2023-04-23 14:45:53 --> Hooks Class Initialized
DEBUG - 2023-04-23 14:45:53 --> UTF-8 Support Enabled
INFO - 2023-04-23 14:45:53 --> Utf8 Class Initialized
INFO - 2023-04-23 14:45:53 --> URI Class Initialized
INFO - 2023-04-23 14:45:53 --> Router Class Initialized
INFO - 2023-04-23 14:45:53 --> Output Class Initialized
INFO - 2023-04-23 14:45:53 --> Security Class Initialized
DEBUG - 2023-04-23 14:45:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-23 14:45:53 --> Input Class Initialized
INFO - 2023-04-23 14:45:53 --> Language Class Initialized
INFO - 2023-04-23 14:45:53 --> Loader Class Initialized
INFO - 2023-04-23 14:45:53 --> Helper loaded: url_helper
INFO - 2023-04-23 14:45:53 --> Helper loaded: file_helper
INFO - 2023-04-23 14:45:53 --> Helper loaded: html_helper
INFO - 2023-04-23 14:45:53 --> Helper loaded: text_helper
INFO - 2023-04-23 14:45:53 --> Helper loaded: form_helper
INFO - 2023-04-23 14:45:53 --> Helper loaded: lang_helper
INFO - 2023-04-23 14:45:53 --> Helper loaded: security_helper
INFO - 2023-04-23 14:45:53 --> Helper loaded: cookie_helper
INFO - 2023-04-23 14:45:53 --> Database Driver Class Initialized
INFO - 2023-04-23 14:45:53 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-23 14:45:53 --> Parser Class Initialized
INFO - 2023-04-23 14:45:53 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-23 14:45:53 --> Pagination Class Initialized
INFO - 2023-04-23 14:45:53 --> Form Validation Class Initialized
INFO - 2023-04-23 14:45:53 --> Controller Class Initialized
INFO - 2023-04-23 14:45:54 --> Model Class Initialized
DEBUG - 2023-04-23 14:45:54 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-04-23 14:45:54 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-23 14:45:54 --> Model Class Initialized
INFO - 2023-04-23 14:45:54 --> Final output sent to browser
DEBUG - 2023-04-23 14:45:54 --> Total execution time: 0.0375
ERROR - 2023-04-23 14:46:14 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-23 14:46:14 --> Config Class Initialized
INFO - 2023-04-23 14:46:14 --> Hooks Class Initialized
DEBUG - 2023-04-23 14:46:14 --> UTF-8 Support Enabled
INFO - 2023-04-23 14:46:14 --> Utf8 Class Initialized
INFO - 2023-04-23 14:46:14 --> URI Class Initialized
INFO - 2023-04-23 14:46:14 --> Router Class Initialized
INFO - 2023-04-23 14:46:14 --> Output Class Initialized
INFO - 2023-04-23 14:46:14 --> Security Class Initialized
DEBUG - 2023-04-23 14:46:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-23 14:46:14 --> Input Class Initialized
INFO - 2023-04-23 14:46:14 --> Language Class Initialized
INFO - 2023-04-23 14:46:14 --> Loader Class Initialized
INFO - 2023-04-23 14:46:14 --> Helper loaded: url_helper
INFO - 2023-04-23 14:46:14 --> Helper loaded: file_helper
INFO - 2023-04-23 14:46:14 --> Helper loaded: html_helper
INFO - 2023-04-23 14:46:14 --> Helper loaded: text_helper
INFO - 2023-04-23 14:46:14 --> Helper loaded: form_helper
INFO - 2023-04-23 14:46:14 --> Helper loaded: lang_helper
INFO - 2023-04-23 14:46:14 --> Helper loaded: security_helper
INFO - 2023-04-23 14:46:14 --> Helper loaded: cookie_helper
INFO - 2023-04-23 14:46:14 --> Database Driver Class Initialized
INFO - 2023-04-23 14:46:14 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-23 14:46:14 --> Parser Class Initialized
INFO - 2023-04-23 14:46:14 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-23 14:46:14 --> Pagination Class Initialized
INFO - 2023-04-23 14:46:14 --> Form Validation Class Initialized
INFO - 2023-04-23 14:46:14 --> Controller Class Initialized
INFO - 2023-04-23 14:46:14 --> Model Class Initialized
DEBUG - 2023-04-23 14:46:14 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-04-23 14:46:14 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-23 14:46:14 --> Model Class Initialized
DEBUG - 2023-04-23 14:46:14 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-23 14:46:14 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/demandrequest/demandrequest_html.php
DEBUG - 2023-04-23 14:46:14 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-04-23 14:46:14 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-04-23 14:46:14 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-04-23 14:46:14 --> Model Class Initialized
INFO - 2023-04-23 14:46:14 --> Model Class Initialized
INFO - 2023-04-23 14:46:14 --> Model Class Initialized
INFO - 2023-04-23 14:46:15 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-04-23 14:46:15 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-04-23 14:46:15 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-04-23 14:46:15 --> Final output sent to browser
DEBUG - 2023-04-23 14:46:15 --> Total execution time: 0.1342
ERROR - 2023-04-23 14:47:34 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-23 14:47:34 --> Config Class Initialized
INFO - 2023-04-23 14:47:34 --> Hooks Class Initialized
DEBUG - 2023-04-23 14:47:34 --> UTF-8 Support Enabled
INFO - 2023-04-23 14:47:34 --> Utf8 Class Initialized
INFO - 2023-04-23 14:47:34 --> URI Class Initialized
INFO - 2023-04-23 14:47:34 --> Router Class Initialized
INFO - 2023-04-23 14:47:34 --> Output Class Initialized
INFO - 2023-04-23 14:47:34 --> Security Class Initialized
DEBUG - 2023-04-23 14:47:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-23 14:47:34 --> Input Class Initialized
INFO - 2023-04-23 14:47:34 --> Language Class Initialized
INFO - 2023-04-23 14:47:34 --> Loader Class Initialized
INFO - 2023-04-23 14:47:34 --> Helper loaded: url_helper
INFO - 2023-04-23 14:47:34 --> Helper loaded: file_helper
INFO - 2023-04-23 14:47:34 --> Helper loaded: html_helper
INFO - 2023-04-23 14:47:34 --> Helper loaded: text_helper
INFO - 2023-04-23 14:47:34 --> Helper loaded: form_helper
INFO - 2023-04-23 14:47:34 --> Helper loaded: lang_helper
INFO - 2023-04-23 14:47:34 --> Helper loaded: security_helper
INFO - 2023-04-23 14:47:34 --> Helper loaded: cookie_helper
INFO - 2023-04-23 14:47:34 --> Database Driver Class Initialized
INFO - 2023-04-23 14:47:34 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-23 14:47:34 --> Parser Class Initialized
INFO - 2023-04-23 14:47:34 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-23 14:47:34 --> Pagination Class Initialized
INFO - 2023-04-23 14:47:34 --> Form Validation Class Initialized
INFO - 2023-04-23 14:47:34 --> Controller Class Initialized
INFO - 2023-04-23 14:47:34 --> Model Class Initialized
DEBUG - 2023-04-23 14:47:34 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-04-23 14:47:34 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-23 14:47:34 --> Model Class Initialized
INFO - 2023-04-23 14:47:34 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/stockrequest/inventory.php
DEBUG - 2023-04-23 14:47:34 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-04-23 14:47:34 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-04-23 14:47:34 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-04-23 14:47:34 --> Model Class Initialized
INFO - 2023-04-23 14:47:34 --> Model Class Initialized
INFO - 2023-04-23 14:47:34 --> Model Class Initialized
INFO - 2023-04-23 14:47:34 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-04-23 14:47:34 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-04-23 14:47:34 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-04-23 14:47:34 --> Final output sent to browser
DEBUG - 2023-04-23 14:47:34 --> Total execution time: 0.1350
ERROR - 2023-04-23 14:47:35 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-23 14:47:35 --> Config Class Initialized
INFO - 2023-04-23 14:47:35 --> Hooks Class Initialized
DEBUG - 2023-04-23 14:47:35 --> UTF-8 Support Enabled
INFO - 2023-04-23 14:47:35 --> Utf8 Class Initialized
INFO - 2023-04-23 14:47:35 --> URI Class Initialized
INFO - 2023-04-23 14:47:35 --> Router Class Initialized
INFO - 2023-04-23 14:47:35 --> Output Class Initialized
INFO - 2023-04-23 14:47:35 --> Security Class Initialized
DEBUG - 2023-04-23 14:47:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-23 14:47:35 --> Input Class Initialized
INFO - 2023-04-23 14:47:35 --> Language Class Initialized
INFO - 2023-04-23 14:47:35 --> Loader Class Initialized
INFO - 2023-04-23 14:47:35 --> Helper loaded: url_helper
INFO - 2023-04-23 14:47:35 --> Helper loaded: file_helper
INFO - 2023-04-23 14:47:35 --> Helper loaded: html_helper
INFO - 2023-04-23 14:47:35 --> Helper loaded: text_helper
INFO - 2023-04-23 14:47:35 --> Helper loaded: form_helper
INFO - 2023-04-23 14:47:35 --> Helper loaded: lang_helper
INFO - 2023-04-23 14:47:35 --> Helper loaded: security_helper
INFO - 2023-04-23 14:47:35 --> Helper loaded: cookie_helper
INFO - 2023-04-23 14:47:35 --> Database Driver Class Initialized
INFO - 2023-04-23 14:47:35 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-23 14:47:35 --> Parser Class Initialized
INFO - 2023-04-23 14:47:35 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-23 14:47:35 --> Pagination Class Initialized
INFO - 2023-04-23 14:47:35 --> Form Validation Class Initialized
INFO - 2023-04-23 14:47:35 --> Controller Class Initialized
INFO - 2023-04-23 14:47:35 --> Model Class Initialized
DEBUG - 2023-04-23 14:47:35 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-04-23 14:47:35 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-23 14:47:35 --> Model Class Initialized
INFO - 2023-04-23 14:47:35 --> Final output sent to browser
DEBUG - 2023-04-23 14:47:35 --> Total execution time: 0.0196
ERROR - 2023-04-23 14:47:50 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-23 14:47:50 --> Config Class Initialized
INFO - 2023-04-23 14:47:50 --> Hooks Class Initialized
DEBUG - 2023-04-23 14:47:50 --> UTF-8 Support Enabled
INFO - 2023-04-23 14:47:50 --> Utf8 Class Initialized
INFO - 2023-04-23 14:47:50 --> URI Class Initialized
INFO - 2023-04-23 14:47:50 --> Router Class Initialized
INFO - 2023-04-23 14:47:50 --> Output Class Initialized
INFO - 2023-04-23 14:47:50 --> Security Class Initialized
DEBUG - 2023-04-23 14:47:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-23 14:47:50 --> Input Class Initialized
INFO - 2023-04-23 14:47:50 --> Language Class Initialized
INFO - 2023-04-23 14:47:50 --> Loader Class Initialized
INFO - 2023-04-23 14:47:50 --> Helper loaded: url_helper
INFO - 2023-04-23 14:47:50 --> Helper loaded: file_helper
INFO - 2023-04-23 14:47:50 --> Helper loaded: html_helper
INFO - 2023-04-23 14:47:50 --> Helper loaded: text_helper
INFO - 2023-04-23 14:47:50 --> Helper loaded: form_helper
INFO - 2023-04-23 14:47:50 --> Helper loaded: lang_helper
INFO - 2023-04-23 14:47:50 --> Helper loaded: security_helper
INFO - 2023-04-23 14:47:50 --> Helper loaded: cookie_helper
INFO - 2023-04-23 14:47:50 --> Database Driver Class Initialized
INFO - 2023-04-23 14:47:50 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-23 14:47:50 --> Parser Class Initialized
INFO - 2023-04-23 14:47:50 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-23 14:47:50 --> Pagination Class Initialized
INFO - 2023-04-23 14:47:50 --> Form Validation Class Initialized
INFO - 2023-04-23 14:47:50 --> Controller Class Initialized
INFO - 2023-04-23 14:47:50 --> Model Class Initialized
DEBUG - 2023-04-23 14:47:50 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-04-23 14:47:50 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-23 14:47:50 --> Model Class Initialized
INFO - 2023-04-23 14:47:50 --> Final output sent to browser
DEBUG - 2023-04-23 14:47:50 --> Total execution time: 0.0243
ERROR - 2023-04-23 14:48:09 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-23 14:48:09 --> Config Class Initialized
INFO - 2023-04-23 14:48:09 --> Hooks Class Initialized
DEBUG - 2023-04-23 14:48:09 --> UTF-8 Support Enabled
INFO - 2023-04-23 14:48:09 --> Utf8 Class Initialized
INFO - 2023-04-23 14:48:09 --> URI Class Initialized
INFO - 2023-04-23 14:48:09 --> Router Class Initialized
INFO - 2023-04-23 14:48:09 --> Output Class Initialized
INFO - 2023-04-23 14:48:09 --> Security Class Initialized
DEBUG - 2023-04-23 14:48:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-23 14:48:09 --> Input Class Initialized
INFO - 2023-04-23 14:48:09 --> Language Class Initialized
INFO - 2023-04-23 14:48:09 --> Loader Class Initialized
INFO - 2023-04-23 14:48:09 --> Helper loaded: url_helper
INFO - 2023-04-23 14:48:09 --> Helper loaded: file_helper
INFO - 2023-04-23 14:48:09 --> Helper loaded: html_helper
INFO - 2023-04-23 14:48:09 --> Helper loaded: text_helper
INFO - 2023-04-23 14:48:09 --> Helper loaded: form_helper
INFO - 2023-04-23 14:48:09 --> Helper loaded: lang_helper
INFO - 2023-04-23 14:48:09 --> Helper loaded: security_helper
INFO - 2023-04-23 14:48:09 --> Helper loaded: cookie_helper
INFO - 2023-04-23 14:48:09 --> Database Driver Class Initialized
INFO - 2023-04-23 14:48:09 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-23 14:48:09 --> Parser Class Initialized
INFO - 2023-04-23 14:48:09 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-23 14:48:09 --> Pagination Class Initialized
INFO - 2023-04-23 14:48:09 --> Form Validation Class Initialized
INFO - 2023-04-23 14:48:09 --> Controller Class Initialized
DEBUG - 2023-04-23 14:48:09 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-04-23 14:48:09 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-23 14:48:09 --> Model Class Initialized
DEBUG - 2023-04-23 14:48:09 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-23 14:48:09 --> Model Class Initialized
DEBUG - 2023-04-23 14:48:09 --> Lcustomer class already loaded. Second attempt ignored.
INFO - 2023-04-23 14:48:09 --> Model Class Initialized
INFO - 2023-04-23 14:48:09 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/customer/customer.php
DEBUG - 2023-04-23 14:48:09 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-04-23 14:48:09 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-04-23 14:48:09 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-04-23 14:48:09 --> Model Class Initialized
INFO - 2023-04-23 14:48:09 --> Model Class Initialized
INFO - 2023-04-23 14:48:09 --> Model Class Initialized
INFO - 2023-04-23 14:48:09 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-04-23 14:48:09 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-04-23 14:48:09 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-04-23 14:48:09 --> Final output sent to browser
DEBUG - 2023-04-23 14:48:09 --> Total execution time: 0.1390
ERROR - 2023-04-23 14:48:10 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-23 14:48:10 --> Config Class Initialized
INFO - 2023-04-23 14:48:10 --> Hooks Class Initialized
DEBUG - 2023-04-23 14:48:10 --> UTF-8 Support Enabled
INFO - 2023-04-23 14:48:10 --> Utf8 Class Initialized
INFO - 2023-04-23 14:48:10 --> URI Class Initialized
INFO - 2023-04-23 14:48:10 --> Router Class Initialized
INFO - 2023-04-23 14:48:10 --> Output Class Initialized
INFO - 2023-04-23 14:48:10 --> Security Class Initialized
DEBUG - 2023-04-23 14:48:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-23 14:48:10 --> Input Class Initialized
INFO - 2023-04-23 14:48:10 --> Language Class Initialized
INFO - 2023-04-23 14:48:10 --> Loader Class Initialized
INFO - 2023-04-23 14:48:10 --> Helper loaded: url_helper
INFO - 2023-04-23 14:48:10 --> Helper loaded: file_helper
INFO - 2023-04-23 14:48:10 --> Helper loaded: html_helper
INFO - 2023-04-23 14:48:10 --> Helper loaded: text_helper
INFO - 2023-04-23 14:48:10 --> Helper loaded: form_helper
INFO - 2023-04-23 14:48:10 --> Helper loaded: lang_helper
INFO - 2023-04-23 14:48:10 --> Helper loaded: security_helper
INFO - 2023-04-23 14:48:10 --> Helper loaded: cookie_helper
INFO - 2023-04-23 14:48:10 --> Database Driver Class Initialized
INFO - 2023-04-23 14:48:10 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-23 14:48:10 --> Parser Class Initialized
INFO - 2023-04-23 14:48:10 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-23 14:48:10 --> Pagination Class Initialized
INFO - 2023-04-23 14:48:10 --> Form Validation Class Initialized
INFO - 2023-04-23 14:48:10 --> Controller Class Initialized
DEBUG - 2023-04-23 14:48:10 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-04-23 14:48:10 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-23 14:48:10 --> Model Class Initialized
DEBUG - 2023-04-23 14:48:10 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-23 14:48:10 --> Model Class Initialized
INFO - 2023-04-23 14:48:10 --> Final output sent to browser
DEBUG - 2023-04-23 14:48:10 --> Total execution time: 0.0311
ERROR - 2023-04-23 14:48:14 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-23 14:48:14 --> Config Class Initialized
INFO - 2023-04-23 14:48:14 --> Hooks Class Initialized
DEBUG - 2023-04-23 14:48:14 --> UTF-8 Support Enabled
INFO - 2023-04-23 14:48:14 --> Utf8 Class Initialized
INFO - 2023-04-23 14:48:14 --> URI Class Initialized
INFO - 2023-04-23 14:48:14 --> Router Class Initialized
INFO - 2023-04-23 14:48:14 --> Output Class Initialized
INFO - 2023-04-23 14:48:14 --> Security Class Initialized
DEBUG - 2023-04-23 14:48:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-23 14:48:14 --> Input Class Initialized
INFO - 2023-04-23 14:48:14 --> Language Class Initialized
INFO - 2023-04-23 14:48:14 --> Loader Class Initialized
INFO - 2023-04-23 14:48:14 --> Helper loaded: url_helper
INFO - 2023-04-23 14:48:14 --> Helper loaded: file_helper
INFO - 2023-04-23 14:48:14 --> Helper loaded: html_helper
INFO - 2023-04-23 14:48:14 --> Helper loaded: text_helper
INFO - 2023-04-23 14:48:14 --> Helper loaded: form_helper
INFO - 2023-04-23 14:48:14 --> Helper loaded: lang_helper
INFO - 2023-04-23 14:48:14 --> Helper loaded: security_helper
INFO - 2023-04-23 14:48:14 --> Helper loaded: cookie_helper
INFO - 2023-04-23 14:48:14 --> Database Driver Class Initialized
INFO - 2023-04-23 14:48:14 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-23 14:48:14 --> Parser Class Initialized
INFO - 2023-04-23 14:48:14 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-23 14:48:14 --> Pagination Class Initialized
INFO - 2023-04-23 14:48:14 --> Form Validation Class Initialized
INFO - 2023-04-23 14:48:14 --> Controller Class Initialized
DEBUG - 2023-04-23 14:48:14 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-04-23 14:48:14 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-23 14:48:14 --> Model Class Initialized
DEBUG - 2023-04-23 14:48:14 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-23 14:48:14 --> Model Class Initialized
INFO - 2023-04-23 14:48:14 --> Final output sent to browser
DEBUG - 2023-04-23 14:48:14 --> Total execution time: 0.0759
ERROR - 2023-04-23 14:48:19 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-23 14:48:19 --> Config Class Initialized
INFO - 2023-04-23 14:48:19 --> Hooks Class Initialized
DEBUG - 2023-04-23 14:48:19 --> UTF-8 Support Enabled
INFO - 2023-04-23 14:48:19 --> Utf8 Class Initialized
INFO - 2023-04-23 14:48:19 --> URI Class Initialized
INFO - 2023-04-23 14:48:19 --> Router Class Initialized
INFO - 2023-04-23 14:48:19 --> Output Class Initialized
INFO - 2023-04-23 14:48:19 --> Security Class Initialized
DEBUG - 2023-04-23 14:48:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-23 14:48:19 --> Input Class Initialized
INFO - 2023-04-23 14:48:19 --> Language Class Initialized
INFO - 2023-04-23 14:48:19 --> Loader Class Initialized
INFO - 2023-04-23 14:48:19 --> Helper loaded: url_helper
INFO - 2023-04-23 14:48:19 --> Helper loaded: file_helper
INFO - 2023-04-23 14:48:19 --> Helper loaded: html_helper
INFO - 2023-04-23 14:48:19 --> Helper loaded: text_helper
INFO - 2023-04-23 14:48:19 --> Helper loaded: form_helper
INFO - 2023-04-23 14:48:19 --> Helper loaded: lang_helper
INFO - 2023-04-23 14:48:19 --> Helper loaded: security_helper
INFO - 2023-04-23 14:48:19 --> Helper loaded: cookie_helper
INFO - 2023-04-23 14:48:19 --> Database Driver Class Initialized
INFO - 2023-04-23 14:48:19 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-23 14:48:19 --> Parser Class Initialized
INFO - 2023-04-23 14:48:19 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-23 14:48:19 --> Pagination Class Initialized
INFO - 2023-04-23 14:48:19 --> Form Validation Class Initialized
INFO - 2023-04-23 14:48:19 --> Controller Class Initialized
DEBUG - 2023-04-23 14:48:19 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-04-23 14:48:19 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-23 14:48:19 --> Model Class Initialized
DEBUG - 2023-04-23 14:48:19 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-23 14:48:19 --> Model Class Initialized
INFO - 2023-04-23 14:48:19 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/customer/edit_customer_form.php
DEBUG - 2023-04-23 14:48:19 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-04-23 14:48:19 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-04-23 14:48:19 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-04-23 14:48:19 --> Model Class Initialized
INFO - 2023-04-23 14:48:19 --> Model Class Initialized
INFO - 2023-04-23 14:48:19 --> Model Class Initialized
INFO - 2023-04-23 14:48:19 --> Model Class Initialized
INFO - 2023-04-23 14:48:19 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-04-23 14:48:19 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-04-23 14:48:19 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-04-23 14:48:19 --> Final output sent to browser
DEBUG - 2023-04-23 14:48:19 --> Total execution time: 0.1678
ERROR - 2023-04-23 14:52:37 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-23 14:52:37 --> Config Class Initialized
INFO - 2023-04-23 14:52:37 --> Hooks Class Initialized
DEBUG - 2023-04-23 14:52:37 --> UTF-8 Support Enabled
INFO - 2023-04-23 14:52:37 --> Utf8 Class Initialized
INFO - 2023-04-23 14:52:37 --> URI Class Initialized
INFO - 2023-04-23 14:52:37 --> Router Class Initialized
INFO - 2023-04-23 14:52:37 --> Output Class Initialized
INFO - 2023-04-23 14:52:37 --> Security Class Initialized
DEBUG - 2023-04-23 14:52:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-23 14:52:37 --> Input Class Initialized
INFO - 2023-04-23 14:52:37 --> Language Class Initialized
INFO - 2023-04-23 14:52:37 --> Loader Class Initialized
INFO - 2023-04-23 14:52:37 --> Helper loaded: url_helper
INFO - 2023-04-23 14:52:37 --> Helper loaded: file_helper
INFO - 2023-04-23 14:52:37 --> Helper loaded: html_helper
INFO - 2023-04-23 14:52:37 --> Helper loaded: text_helper
INFO - 2023-04-23 14:52:37 --> Helper loaded: form_helper
INFO - 2023-04-23 14:52:37 --> Helper loaded: lang_helper
INFO - 2023-04-23 14:52:37 --> Helper loaded: security_helper
INFO - 2023-04-23 14:52:37 --> Helper loaded: cookie_helper
INFO - 2023-04-23 14:52:37 --> Database Driver Class Initialized
INFO - 2023-04-23 14:52:37 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-23 14:52:37 --> Parser Class Initialized
INFO - 2023-04-23 14:52:37 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-23 14:52:37 --> Pagination Class Initialized
INFO - 2023-04-23 14:52:37 --> Form Validation Class Initialized
INFO - 2023-04-23 14:52:37 --> Controller Class Initialized
DEBUG - 2023-04-23 14:52:37 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-04-23 14:52:37 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-23 14:52:37 --> Model Class Initialized
DEBUG - 2023-04-23 14:52:37 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-23 14:52:37 --> Model Class Initialized
ERROR - 2023-04-23 14:52:38 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-23 14:52:38 --> Config Class Initialized
INFO - 2023-04-23 14:52:38 --> Hooks Class Initialized
DEBUG - 2023-04-23 14:52:38 --> UTF-8 Support Enabled
INFO - 2023-04-23 14:52:38 --> Utf8 Class Initialized
INFO - 2023-04-23 14:52:38 --> URI Class Initialized
INFO - 2023-04-23 14:52:38 --> Router Class Initialized
INFO - 2023-04-23 14:52:38 --> Output Class Initialized
INFO - 2023-04-23 14:52:38 --> Security Class Initialized
DEBUG - 2023-04-23 14:52:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-23 14:52:38 --> Input Class Initialized
INFO - 2023-04-23 14:52:38 --> Language Class Initialized
INFO - 2023-04-23 14:52:38 --> Loader Class Initialized
INFO - 2023-04-23 14:52:38 --> Helper loaded: url_helper
INFO - 2023-04-23 14:52:38 --> Helper loaded: file_helper
INFO - 2023-04-23 14:52:38 --> Helper loaded: html_helper
INFO - 2023-04-23 14:52:38 --> Helper loaded: text_helper
INFO - 2023-04-23 14:52:38 --> Helper loaded: form_helper
INFO - 2023-04-23 14:52:38 --> Helper loaded: lang_helper
INFO - 2023-04-23 14:52:38 --> Helper loaded: security_helper
INFO - 2023-04-23 14:52:38 --> Helper loaded: cookie_helper
INFO - 2023-04-23 14:52:38 --> Database Driver Class Initialized
INFO - 2023-04-23 14:52:38 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-23 14:52:38 --> Parser Class Initialized
INFO - 2023-04-23 14:52:38 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-23 14:52:38 --> Pagination Class Initialized
INFO - 2023-04-23 14:52:38 --> Form Validation Class Initialized
INFO - 2023-04-23 14:52:38 --> Controller Class Initialized
DEBUG - 2023-04-23 14:52:38 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-04-23 14:52:38 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-23 14:52:38 --> Model Class Initialized
DEBUG - 2023-04-23 14:52:38 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-23 14:52:38 --> Model Class Initialized
DEBUG - 2023-04-23 14:52:38 --> Lcustomer class already loaded. Second attempt ignored.
INFO - 2023-04-23 14:52:38 --> Model Class Initialized
INFO - 2023-04-23 14:52:38 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/customer/customer.php
DEBUG - 2023-04-23 14:52:38 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-04-23 14:52:38 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-04-23 14:52:38 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-04-23 14:52:38 --> Model Class Initialized
INFO - 2023-04-23 14:52:38 --> Model Class Initialized
INFO - 2023-04-23 14:52:38 --> Model Class Initialized
INFO - 2023-04-23 14:52:38 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-04-23 14:52:38 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-04-23 14:52:38 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-04-23 14:52:38 --> Final output sent to browser
DEBUG - 2023-04-23 14:52:38 --> Total execution time: 0.1375
ERROR - 2023-04-23 14:52:39 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-23 14:52:39 --> Config Class Initialized
INFO - 2023-04-23 14:52:39 --> Hooks Class Initialized
DEBUG - 2023-04-23 14:52:39 --> UTF-8 Support Enabled
INFO - 2023-04-23 14:52:39 --> Utf8 Class Initialized
INFO - 2023-04-23 14:52:39 --> URI Class Initialized
INFO - 2023-04-23 14:52:39 --> Router Class Initialized
INFO - 2023-04-23 14:52:39 --> Output Class Initialized
INFO - 2023-04-23 14:52:39 --> Security Class Initialized
DEBUG - 2023-04-23 14:52:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-23 14:52:39 --> Input Class Initialized
INFO - 2023-04-23 14:52:39 --> Language Class Initialized
INFO - 2023-04-23 14:52:39 --> Loader Class Initialized
INFO - 2023-04-23 14:52:39 --> Helper loaded: url_helper
INFO - 2023-04-23 14:52:39 --> Helper loaded: file_helper
INFO - 2023-04-23 14:52:39 --> Helper loaded: html_helper
INFO - 2023-04-23 14:52:39 --> Helper loaded: text_helper
INFO - 2023-04-23 14:52:39 --> Helper loaded: form_helper
INFO - 2023-04-23 14:52:39 --> Helper loaded: lang_helper
INFO - 2023-04-23 14:52:39 --> Helper loaded: security_helper
INFO - 2023-04-23 14:52:39 --> Helper loaded: cookie_helper
INFO - 2023-04-23 14:52:39 --> Database Driver Class Initialized
INFO - 2023-04-23 14:52:39 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-23 14:52:39 --> Parser Class Initialized
INFO - 2023-04-23 14:52:39 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-23 14:52:39 --> Pagination Class Initialized
INFO - 2023-04-23 14:52:39 --> Form Validation Class Initialized
INFO - 2023-04-23 14:52:39 --> Controller Class Initialized
DEBUG - 2023-04-23 14:52:39 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-04-23 14:52:39 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-23 14:52:39 --> Model Class Initialized
DEBUG - 2023-04-23 14:52:39 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-23 14:52:39 --> Model Class Initialized
INFO - 2023-04-23 14:52:39 --> Final output sent to browser
DEBUG - 2023-04-23 14:52:39 --> Total execution time: 0.0364
ERROR - 2023-04-23 14:52:55 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-23 14:52:55 --> Config Class Initialized
INFO - 2023-04-23 14:52:55 --> Hooks Class Initialized
DEBUG - 2023-04-23 14:52:55 --> UTF-8 Support Enabled
INFO - 2023-04-23 14:52:55 --> Utf8 Class Initialized
INFO - 2023-04-23 14:52:55 --> URI Class Initialized
INFO - 2023-04-23 14:52:55 --> Router Class Initialized
INFO - 2023-04-23 14:52:55 --> Output Class Initialized
INFO - 2023-04-23 14:52:55 --> Security Class Initialized
DEBUG - 2023-04-23 14:52:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-23 14:52:55 --> Input Class Initialized
INFO - 2023-04-23 14:52:55 --> Language Class Initialized
INFO - 2023-04-23 14:52:55 --> Loader Class Initialized
INFO - 2023-04-23 14:52:55 --> Helper loaded: url_helper
INFO - 2023-04-23 14:52:55 --> Helper loaded: file_helper
INFO - 2023-04-23 14:52:55 --> Helper loaded: html_helper
INFO - 2023-04-23 14:52:55 --> Helper loaded: text_helper
INFO - 2023-04-23 14:52:55 --> Helper loaded: form_helper
INFO - 2023-04-23 14:52:55 --> Helper loaded: lang_helper
INFO - 2023-04-23 14:52:55 --> Helper loaded: security_helper
INFO - 2023-04-23 14:52:55 --> Helper loaded: cookie_helper
INFO - 2023-04-23 14:52:55 --> Database Driver Class Initialized
INFO - 2023-04-23 14:52:55 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-23 14:52:55 --> Parser Class Initialized
INFO - 2023-04-23 14:52:55 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-23 14:52:55 --> Pagination Class Initialized
INFO - 2023-04-23 14:52:55 --> Form Validation Class Initialized
INFO - 2023-04-23 14:52:55 --> Controller Class Initialized
INFO - 2023-04-23 14:52:55 --> Model Class Initialized
DEBUG - 2023-04-23 14:52:55 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-04-23 14:52:55 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-23 14:52:55 --> Model Class Initialized
DEBUG - 2023-04-23 14:52:55 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-23 14:52:55 --> Model Class Initialized
INFO - 2023-04-23 14:52:55 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice.php
DEBUG - 2023-04-23 14:52:55 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-04-23 14:52:55 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-04-23 14:52:55 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-04-23 14:52:55 --> Model Class Initialized
INFO - 2023-04-23 14:52:55 --> Model Class Initialized
INFO - 2023-04-23 14:52:55 --> Model Class Initialized
INFO - 2023-04-23 14:52:55 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-04-23 14:52:55 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-04-23 14:52:55 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-04-23 14:52:55 --> Final output sent to browser
DEBUG - 2023-04-23 14:52:55 --> Total execution time: 0.0642
ERROR - 2023-04-23 14:52:56 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-23 14:52:56 --> Config Class Initialized
INFO - 2023-04-23 14:52:56 --> Hooks Class Initialized
DEBUG - 2023-04-23 14:52:56 --> UTF-8 Support Enabled
INFO - 2023-04-23 14:52:56 --> Utf8 Class Initialized
INFO - 2023-04-23 14:52:56 --> URI Class Initialized
INFO - 2023-04-23 14:52:56 --> Router Class Initialized
INFO - 2023-04-23 14:52:56 --> Output Class Initialized
INFO - 2023-04-23 14:52:56 --> Security Class Initialized
DEBUG - 2023-04-23 14:52:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-23 14:52:56 --> Input Class Initialized
INFO - 2023-04-23 14:52:56 --> Language Class Initialized
INFO - 2023-04-23 14:52:56 --> Loader Class Initialized
INFO - 2023-04-23 14:52:56 --> Helper loaded: url_helper
INFO - 2023-04-23 14:52:56 --> Helper loaded: file_helper
INFO - 2023-04-23 14:52:56 --> Helper loaded: html_helper
INFO - 2023-04-23 14:52:56 --> Helper loaded: text_helper
INFO - 2023-04-23 14:52:56 --> Helper loaded: form_helper
INFO - 2023-04-23 14:52:56 --> Helper loaded: lang_helper
INFO - 2023-04-23 14:52:56 --> Helper loaded: security_helper
INFO - 2023-04-23 14:52:56 --> Helper loaded: cookie_helper
INFO - 2023-04-23 14:52:56 --> Database Driver Class Initialized
INFO - 2023-04-23 14:52:56 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-23 14:52:56 --> Parser Class Initialized
INFO - 2023-04-23 14:52:56 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-23 14:52:56 --> Pagination Class Initialized
INFO - 2023-04-23 14:52:56 --> Form Validation Class Initialized
INFO - 2023-04-23 14:52:56 --> Controller Class Initialized
INFO - 2023-04-23 14:52:56 --> Model Class Initialized
DEBUG - 2023-04-23 14:52:56 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-04-23 14:52:56 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-23 14:52:56 --> Model Class Initialized
DEBUG - 2023-04-23 14:52:56 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-23 14:52:56 --> Model Class Initialized
INFO - 2023-04-23 14:52:56 --> Final output sent to browser
DEBUG - 2023-04-23 14:52:56 --> Total execution time: 0.1831
ERROR - 2023-04-23 14:53:00 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-23 14:53:00 --> Config Class Initialized
INFO - 2023-04-23 14:53:00 --> Hooks Class Initialized
DEBUG - 2023-04-23 14:53:00 --> UTF-8 Support Enabled
INFO - 2023-04-23 14:53:00 --> Utf8 Class Initialized
INFO - 2023-04-23 14:53:00 --> URI Class Initialized
INFO - 2023-04-23 14:53:00 --> Router Class Initialized
INFO - 2023-04-23 14:53:00 --> Output Class Initialized
INFO - 2023-04-23 14:53:00 --> Security Class Initialized
DEBUG - 2023-04-23 14:53:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-23 14:53:00 --> Input Class Initialized
INFO - 2023-04-23 14:53:00 --> Language Class Initialized
INFO - 2023-04-23 14:53:00 --> Loader Class Initialized
INFO - 2023-04-23 14:53:00 --> Helper loaded: url_helper
INFO - 2023-04-23 14:53:00 --> Helper loaded: file_helper
INFO - 2023-04-23 14:53:00 --> Helper loaded: html_helper
INFO - 2023-04-23 14:53:00 --> Helper loaded: text_helper
INFO - 2023-04-23 14:53:00 --> Helper loaded: form_helper
INFO - 2023-04-23 14:53:00 --> Helper loaded: lang_helper
INFO - 2023-04-23 14:53:00 --> Helper loaded: security_helper
INFO - 2023-04-23 14:53:00 --> Helper loaded: cookie_helper
INFO - 2023-04-23 14:53:00 --> Database Driver Class Initialized
INFO - 2023-04-23 14:53:00 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-23 14:53:00 --> Parser Class Initialized
INFO - 2023-04-23 14:53:00 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-23 14:53:00 --> Pagination Class Initialized
INFO - 2023-04-23 14:53:00 --> Form Validation Class Initialized
INFO - 2023-04-23 14:53:00 --> Controller Class Initialized
INFO - 2023-04-23 14:53:00 --> Model Class Initialized
DEBUG - 2023-04-23 14:53:00 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-04-23 14:53:00 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-23 14:53:00 --> Model Class Initialized
DEBUG - 2023-04-23 14:53:00 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-23 14:53:00 --> Model Class Initialized
INFO - 2023-04-23 14:53:00 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/invoice/invoice.php
DEBUG - 2023-04-23 14:53:00 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-04-23 14:53:00 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-04-23 14:53:00 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-04-23 14:53:00 --> Model Class Initialized
INFO - 2023-04-23 14:53:00 --> Model Class Initialized
INFO - 2023-04-23 14:53:00 --> Model Class Initialized
INFO - 2023-04-23 14:53:00 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-04-23 14:53:00 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-04-23 14:53:00 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-04-23 14:53:00 --> Final output sent to browser
DEBUG - 2023-04-23 14:53:00 --> Total execution time: 0.0575
ERROR - 2023-04-23 14:53:01 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-23 14:53:01 --> Config Class Initialized
INFO - 2023-04-23 14:53:01 --> Hooks Class Initialized
DEBUG - 2023-04-23 14:53:01 --> UTF-8 Support Enabled
INFO - 2023-04-23 14:53:01 --> Utf8 Class Initialized
INFO - 2023-04-23 14:53:01 --> URI Class Initialized
INFO - 2023-04-23 14:53:01 --> Router Class Initialized
INFO - 2023-04-23 14:53:01 --> Output Class Initialized
INFO - 2023-04-23 14:53:01 --> Security Class Initialized
DEBUG - 2023-04-23 14:53:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-23 14:53:01 --> Input Class Initialized
INFO - 2023-04-23 14:53:01 --> Language Class Initialized
INFO - 2023-04-23 14:53:01 --> Loader Class Initialized
INFO - 2023-04-23 14:53:01 --> Helper loaded: url_helper
INFO - 2023-04-23 14:53:01 --> Helper loaded: file_helper
INFO - 2023-04-23 14:53:01 --> Helper loaded: html_helper
INFO - 2023-04-23 14:53:01 --> Helper loaded: text_helper
INFO - 2023-04-23 14:53:01 --> Helper loaded: form_helper
INFO - 2023-04-23 14:53:01 --> Helper loaded: lang_helper
INFO - 2023-04-23 14:53:01 --> Helper loaded: security_helper
INFO - 2023-04-23 14:53:01 --> Helper loaded: cookie_helper
INFO - 2023-04-23 14:53:01 --> Database Driver Class Initialized
INFO - 2023-04-23 14:53:01 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-23 14:53:01 --> Parser Class Initialized
INFO - 2023-04-23 14:53:01 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-23 14:53:01 --> Pagination Class Initialized
INFO - 2023-04-23 14:53:01 --> Form Validation Class Initialized
INFO - 2023-04-23 14:53:01 --> Controller Class Initialized
INFO - 2023-04-23 14:53:01 --> Model Class Initialized
DEBUG - 2023-04-23 14:53:01 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-04-23 14:53:01 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-23 14:53:01 --> Model Class Initialized
DEBUG - 2023-04-23 14:53:01 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-23 14:53:01 --> Model Class Initialized
INFO - 2023-04-23 14:53:01 --> Final output sent to browser
DEBUG - 2023-04-23 14:53:01 --> Total execution time: 0.0196
ERROR - 2023-04-23 14:53:08 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-23 14:53:08 --> Config Class Initialized
INFO - 2023-04-23 14:53:08 --> Hooks Class Initialized
DEBUG - 2023-04-23 14:53:08 --> UTF-8 Support Enabled
INFO - 2023-04-23 14:53:08 --> Utf8 Class Initialized
INFO - 2023-04-23 14:53:08 --> URI Class Initialized
INFO - 2023-04-23 14:53:08 --> Router Class Initialized
INFO - 2023-04-23 14:53:08 --> Output Class Initialized
INFO - 2023-04-23 14:53:08 --> Security Class Initialized
DEBUG - 2023-04-23 14:53:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-23 14:53:08 --> Input Class Initialized
INFO - 2023-04-23 14:53:08 --> Language Class Initialized
INFO - 2023-04-23 14:53:08 --> Loader Class Initialized
INFO - 2023-04-23 14:53:08 --> Helper loaded: url_helper
INFO - 2023-04-23 14:53:08 --> Helper loaded: file_helper
INFO - 2023-04-23 14:53:08 --> Helper loaded: html_helper
INFO - 2023-04-23 14:53:08 --> Helper loaded: text_helper
INFO - 2023-04-23 14:53:08 --> Helper loaded: form_helper
INFO - 2023-04-23 14:53:08 --> Helper loaded: lang_helper
INFO - 2023-04-23 14:53:08 --> Helper loaded: security_helper
INFO - 2023-04-23 14:53:08 --> Helper loaded: cookie_helper
INFO - 2023-04-23 14:53:08 --> Database Driver Class Initialized
INFO - 2023-04-23 14:53:08 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-23 14:53:08 --> Parser Class Initialized
INFO - 2023-04-23 14:53:08 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-23 14:53:08 --> Pagination Class Initialized
INFO - 2023-04-23 14:53:08 --> Form Validation Class Initialized
INFO - 2023-04-23 14:53:08 --> Controller Class Initialized
INFO - 2023-04-23 14:53:08 --> Model Class Initialized
DEBUG - 2023-04-23 14:53:08 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-04-23 14:53:08 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-23 14:53:08 --> Model Class Initialized
INFO - 2023-04-23 14:53:08 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/demandrequest/demandrequest.php
DEBUG - 2023-04-23 14:53:08 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-04-23 14:53:08 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-04-23 14:53:08 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-04-23 14:53:08 --> Model Class Initialized
INFO - 2023-04-23 14:53:08 --> Model Class Initialized
INFO - 2023-04-23 14:53:08 --> Model Class Initialized
INFO - 2023-04-23 14:53:08 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-04-23 14:53:08 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-04-23 14:53:08 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-04-23 14:53:08 --> Final output sent to browser
DEBUG - 2023-04-23 14:53:08 --> Total execution time: 0.0583
ERROR - 2023-04-23 14:53:08 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-23 14:53:08 --> Config Class Initialized
INFO - 2023-04-23 14:53:08 --> Hooks Class Initialized
DEBUG - 2023-04-23 14:53:08 --> UTF-8 Support Enabled
INFO - 2023-04-23 14:53:08 --> Utf8 Class Initialized
INFO - 2023-04-23 14:53:08 --> URI Class Initialized
INFO - 2023-04-23 14:53:08 --> Router Class Initialized
INFO - 2023-04-23 14:53:08 --> Output Class Initialized
INFO - 2023-04-23 14:53:08 --> Security Class Initialized
DEBUG - 2023-04-23 14:53:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-23 14:53:08 --> Input Class Initialized
INFO - 2023-04-23 14:53:08 --> Language Class Initialized
INFO - 2023-04-23 14:53:08 --> Loader Class Initialized
INFO - 2023-04-23 14:53:08 --> Helper loaded: url_helper
INFO - 2023-04-23 14:53:08 --> Helper loaded: file_helper
INFO - 2023-04-23 14:53:08 --> Helper loaded: html_helper
INFO - 2023-04-23 14:53:08 --> Helper loaded: text_helper
INFO - 2023-04-23 14:53:08 --> Helper loaded: form_helper
INFO - 2023-04-23 14:53:08 --> Helper loaded: lang_helper
INFO - 2023-04-23 14:53:08 --> Helper loaded: security_helper
INFO - 2023-04-23 14:53:08 --> Helper loaded: cookie_helper
INFO - 2023-04-23 14:53:08 --> Database Driver Class Initialized
INFO - 2023-04-23 14:53:08 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-23 14:53:08 --> Parser Class Initialized
INFO - 2023-04-23 14:53:08 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-23 14:53:08 --> Pagination Class Initialized
INFO - 2023-04-23 14:53:08 --> Form Validation Class Initialized
INFO - 2023-04-23 14:53:08 --> Controller Class Initialized
INFO - 2023-04-23 14:53:08 --> Model Class Initialized
DEBUG - 2023-04-23 14:53:08 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-04-23 14:53:08 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-23 14:53:08 --> Model Class Initialized
INFO - 2023-04-23 14:53:08 --> Final output sent to browser
DEBUG - 2023-04-23 14:53:08 --> Total execution time: 0.0178
ERROR - 2023-04-23 14:53:19 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-23 14:53:19 --> Config Class Initialized
INFO - 2023-04-23 14:53:19 --> Hooks Class Initialized
DEBUG - 2023-04-23 14:53:19 --> UTF-8 Support Enabled
INFO - 2023-04-23 14:53:19 --> Utf8 Class Initialized
INFO - 2023-04-23 14:53:19 --> URI Class Initialized
INFO - 2023-04-23 14:53:19 --> Router Class Initialized
INFO - 2023-04-23 14:53:19 --> Output Class Initialized
INFO - 2023-04-23 14:53:19 --> Security Class Initialized
DEBUG - 2023-04-23 14:53:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-23 14:53:19 --> Input Class Initialized
INFO - 2023-04-23 14:53:19 --> Language Class Initialized
INFO - 2023-04-23 14:53:19 --> Loader Class Initialized
INFO - 2023-04-23 14:53:19 --> Helper loaded: url_helper
INFO - 2023-04-23 14:53:19 --> Helper loaded: file_helper
INFO - 2023-04-23 14:53:19 --> Helper loaded: html_helper
INFO - 2023-04-23 14:53:19 --> Helper loaded: text_helper
INFO - 2023-04-23 14:53:19 --> Helper loaded: form_helper
INFO - 2023-04-23 14:53:19 --> Helper loaded: lang_helper
INFO - 2023-04-23 14:53:19 --> Helper loaded: security_helper
INFO - 2023-04-23 14:53:19 --> Helper loaded: cookie_helper
INFO - 2023-04-23 14:53:19 --> Database Driver Class Initialized
INFO - 2023-04-23 14:53:19 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-23 14:53:19 --> Parser Class Initialized
INFO - 2023-04-23 14:53:19 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-23 14:53:19 --> Pagination Class Initialized
INFO - 2023-04-23 14:53:19 --> Form Validation Class Initialized
INFO - 2023-04-23 14:53:19 --> Controller Class Initialized
INFO - 2023-04-23 14:53:19 --> Model Class Initialized
DEBUG - 2023-04-23 14:53:19 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-04-23 14:53:19 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-23 14:53:19 --> Model Class Initialized
DEBUG - 2023-04-23 14:53:19 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-23 14:53:19 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/demandrequest/demandrequest_html.php
DEBUG - 2023-04-23 14:53:19 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-04-23 14:53:19 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-04-23 14:53:19 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-04-23 14:53:19 --> Model Class Initialized
INFO - 2023-04-23 14:53:19 --> Model Class Initialized
INFO - 2023-04-23 14:53:19 --> Model Class Initialized
INFO - 2023-04-23 14:53:19 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-04-23 14:53:19 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-04-23 14:53:19 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-04-23 14:53:19 --> Final output sent to browser
DEBUG - 2023-04-23 14:53:19 --> Total execution time: 0.0533
ERROR - 2023-04-23 14:53:30 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-23 14:53:30 --> Config Class Initialized
INFO - 2023-04-23 14:53:30 --> Hooks Class Initialized
DEBUG - 2023-04-23 14:53:30 --> UTF-8 Support Enabled
INFO - 2023-04-23 14:53:30 --> Utf8 Class Initialized
INFO - 2023-04-23 14:53:30 --> URI Class Initialized
INFO - 2023-04-23 14:53:30 --> Router Class Initialized
INFO - 2023-04-23 14:53:30 --> Output Class Initialized
INFO - 2023-04-23 14:53:30 --> Security Class Initialized
DEBUG - 2023-04-23 14:53:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-23 14:53:30 --> Input Class Initialized
INFO - 2023-04-23 14:53:30 --> Language Class Initialized
INFO - 2023-04-23 14:53:30 --> Loader Class Initialized
INFO - 2023-04-23 14:53:30 --> Helper loaded: url_helper
INFO - 2023-04-23 14:53:30 --> Helper loaded: file_helper
INFO - 2023-04-23 14:53:30 --> Helper loaded: html_helper
INFO - 2023-04-23 14:53:30 --> Helper loaded: text_helper
INFO - 2023-04-23 14:53:30 --> Helper loaded: form_helper
INFO - 2023-04-23 14:53:30 --> Helper loaded: lang_helper
INFO - 2023-04-23 14:53:30 --> Helper loaded: security_helper
INFO - 2023-04-23 14:53:30 --> Helper loaded: cookie_helper
INFO - 2023-04-23 14:53:30 --> Database Driver Class Initialized
INFO - 2023-04-23 14:53:30 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-23 14:53:30 --> Parser Class Initialized
INFO - 2023-04-23 14:53:30 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-23 14:53:30 --> Pagination Class Initialized
INFO - 2023-04-23 14:53:30 --> Form Validation Class Initialized
INFO - 2023-04-23 14:53:30 --> Controller Class Initialized
INFO - 2023-04-23 14:53:30 --> Model Class Initialized
DEBUG - 2023-04-23 14:53:30 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-04-23 14:53:30 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-23 14:53:30 --> Model Class Initialized
DEBUG - 2023-04-23 14:53:30 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-23 14:53:30 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/demandrequest/demandrequest_html.php
DEBUG - 2023-04-23 14:53:30 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-04-23 14:53:30 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-04-23 14:53:30 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-04-23 14:53:30 --> Model Class Initialized
INFO - 2023-04-23 14:53:30 --> Model Class Initialized
INFO - 2023-04-23 14:53:30 --> Model Class Initialized
INFO - 2023-04-23 14:53:30 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-04-23 14:53:30 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-04-23 14:53:30 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-04-23 14:53:30 --> Final output sent to browser
DEBUG - 2023-04-23 14:53:30 --> Total execution time: 0.0548
ERROR - 2023-04-23 14:53:59 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-23 14:53:59 --> Config Class Initialized
INFO - 2023-04-23 14:53:59 --> Hooks Class Initialized
DEBUG - 2023-04-23 14:53:59 --> UTF-8 Support Enabled
INFO - 2023-04-23 14:53:59 --> Utf8 Class Initialized
INFO - 2023-04-23 14:53:59 --> URI Class Initialized
INFO - 2023-04-23 14:53:59 --> Router Class Initialized
INFO - 2023-04-23 14:53:59 --> Output Class Initialized
INFO - 2023-04-23 14:53:59 --> Security Class Initialized
DEBUG - 2023-04-23 14:53:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-23 14:53:59 --> Input Class Initialized
INFO - 2023-04-23 14:53:59 --> Language Class Initialized
INFO - 2023-04-23 14:53:59 --> Loader Class Initialized
INFO - 2023-04-23 14:53:59 --> Helper loaded: url_helper
INFO - 2023-04-23 14:53:59 --> Helper loaded: file_helper
INFO - 2023-04-23 14:53:59 --> Helper loaded: html_helper
INFO - 2023-04-23 14:53:59 --> Helper loaded: text_helper
INFO - 2023-04-23 14:53:59 --> Helper loaded: form_helper
INFO - 2023-04-23 14:53:59 --> Helper loaded: lang_helper
INFO - 2023-04-23 14:53:59 --> Helper loaded: security_helper
INFO - 2023-04-23 14:53:59 --> Helper loaded: cookie_helper
INFO - 2023-04-23 14:53:59 --> Database Driver Class Initialized
INFO - 2023-04-23 14:53:59 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-23 14:53:59 --> Parser Class Initialized
INFO - 2023-04-23 14:53:59 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-23 14:53:59 --> Pagination Class Initialized
INFO - 2023-04-23 14:53:59 --> Form Validation Class Initialized
INFO - 2023-04-23 14:53:59 --> Controller Class Initialized
INFO - 2023-04-23 14:53:59 --> Model Class Initialized
DEBUG - 2023-04-23 14:53:59 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-04-23 14:53:59 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-23 14:53:59 --> Model Class Initialized
INFO - 2023-04-23 14:53:59 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/demandrequest/customer_demandrequest.php
DEBUG - 2023-04-23 14:53:59 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-04-23 14:53:59 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-04-23 14:53:59 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-04-23 14:53:59 --> Model Class Initialized
INFO - 2023-04-23 14:53:59 --> Model Class Initialized
INFO - 2023-04-23 14:53:59 --> Model Class Initialized
INFO - 2023-04-23 14:53:59 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-04-23 14:53:59 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-04-23 14:53:59 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-04-23 14:53:59 --> Final output sent to browser
DEBUG - 2023-04-23 14:53:59 --> Total execution time: 0.1599
ERROR - 2023-04-23 14:54:00 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-23 14:54:00 --> Config Class Initialized
INFO - 2023-04-23 14:54:00 --> Hooks Class Initialized
DEBUG - 2023-04-23 14:54:00 --> UTF-8 Support Enabled
INFO - 2023-04-23 14:54:00 --> Utf8 Class Initialized
INFO - 2023-04-23 14:54:00 --> URI Class Initialized
INFO - 2023-04-23 14:54:00 --> Router Class Initialized
INFO - 2023-04-23 14:54:00 --> Output Class Initialized
INFO - 2023-04-23 14:54:00 --> Security Class Initialized
DEBUG - 2023-04-23 14:54:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-23 14:54:00 --> Input Class Initialized
INFO - 2023-04-23 14:54:00 --> Language Class Initialized
INFO - 2023-04-23 14:54:00 --> Loader Class Initialized
INFO - 2023-04-23 14:54:00 --> Helper loaded: url_helper
INFO - 2023-04-23 14:54:00 --> Helper loaded: file_helper
INFO - 2023-04-23 14:54:00 --> Helper loaded: html_helper
INFO - 2023-04-23 14:54:00 --> Helper loaded: text_helper
INFO - 2023-04-23 14:54:00 --> Helper loaded: form_helper
INFO - 2023-04-23 14:54:00 --> Helper loaded: lang_helper
INFO - 2023-04-23 14:54:00 --> Helper loaded: security_helper
INFO - 2023-04-23 14:54:00 --> Helper loaded: cookie_helper
INFO - 2023-04-23 14:54:00 --> Database Driver Class Initialized
INFO - 2023-04-23 14:54:00 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-23 14:54:00 --> Parser Class Initialized
INFO - 2023-04-23 14:54:00 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-23 14:54:00 --> Pagination Class Initialized
INFO - 2023-04-23 14:54:00 --> Form Validation Class Initialized
INFO - 2023-04-23 14:54:00 --> Controller Class Initialized
INFO - 2023-04-23 14:54:00 --> Model Class Initialized
DEBUG - 2023-04-23 14:54:00 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-04-23 14:54:00 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-23 14:54:00 --> Model Class Initialized
INFO - 2023-04-23 14:54:00 --> Final output sent to browser
DEBUG - 2023-04-23 14:54:00 --> Total execution time: 0.0290
ERROR - 2023-04-23 14:54:04 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-23 14:54:04 --> Config Class Initialized
INFO - 2023-04-23 14:54:04 --> Hooks Class Initialized
DEBUG - 2023-04-23 14:54:04 --> UTF-8 Support Enabled
INFO - 2023-04-23 14:54:04 --> Utf8 Class Initialized
INFO - 2023-04-23 14:54:04 --> URI Class Initialized
DEBUG - 2023-04-23 14:54:04 --> No URI present. Default controller set.
INFO - 2023-04-23 14:54:04 --> Router Class Initialized
INFO - 2023-04-23 14:54:04 --> Output Class Initialized
INFO - 2023-04-23 14:54:04 --> Security Class Initialized
DEBUG - 2023-04-23 14:54:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-23 14:54:04 --> Input Class Initialized
INFO - 2023-04-23 14:54:04 --> Language Class Initialized
INFO - 2023-04-23 14:54:04 --> Loader Class Initialized
INFO - 2023-04-23 14:54:04 --> Helper loaded: url_helper
INFO - 2023-04-23 14:54:04 --> Helper loaded: file_helper
INFO - 2023-04-23 14:54:04 --> Helper loaded: html_helper
INFO - 2023-04-23 14:54:04 --> Helper loaded: text_helper
INFO - 2023-04-23 14:54:04 --> Helper loaded: form_helper
INFO - 2023-04-23 14:54:04 --> Helper loaded: lang_helper
INFO - 2023-04-23 14:54:04 --> Helper loaded: security_helper
INFO - 2023-04-23 14:54:04 --> Helper loaded: cookie_helper
INFO - 2023-04-23 14:54:04 --> Database Driver Class Initialized
INFO - 2023-04-23 14:54:04 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-23 14:54:04 --> Parser Class Initialized
INFO - 2023-04-23 14:54:04 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-23 14:54:04 --> Pagination Class Initialized
INFO - 2023-04-23 14:54:04 --> Form Validation Class Initialized
INFO - 2023-04-23 14:54:04 --> Controller Class Initialized
INFO - 2023-04-23 14:54:04 --> Model Class Initialized
DEBUG - 2023-04-23 14:54:04 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-23 14:54:04 --> Model Class Initialized
DEBUG - 2023-04-23 14:54:04 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-23 14:54:04 --> Model Class Initialized
INFO - 2023-04-23 14:54:04 --> Model Class Initialized
INFO - 2023-04-23 14:54:04 --> Model Class Initialized
INFO - 2023-04-23 14:54:04 --> Model Class Initialized
DEBUG - 2023-04-23 14:54:04 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-04-23 14:54:04 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-23 14:54:04 --> Model Class Initialized
INFO - 2023-04-23 14:54:04 --> Model Class Initialized
INFO - 2023-04-23 14:54:04 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-04-23 14:54:04 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-04-23 14:54:04 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-04-23 14:54:04 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-04-23 14:54:04 --> Model Class Initialized
INFO - 2023-04-23 14:54:04 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-04-23 14:54:04 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-04-23 14:54:04 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-04-23 14:54:04 --> Final output sent to browser
DEBUG - 2023-04-23 14:54:04 --> Total execution time: 0.1776
ERROR - 2023-04-23 14:54:25 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-23 14:54:25 --> Config Class Initialized
INFO - 2023-04-23 14:54:25 --> Hooks Class Initialized
DEBUG - 2023-04-23 14:54:25 --> UTF-8 Support Enabled
INFO - 2023-04-23 14:54:25 --> Utf8 Class Initialized
INFO - 2023-04-23 14:54:25 --> URI Class Initialized
INFO - 2023-04-23 14:54:25 --> Router Class Initialized
INFO - 2023-04-23 14:54:25 --> Output Class Initialized
INFO - 2023-04-23 14:54:25 --> Security Class Initialized
DEBUG - 2023-04-23 14:54:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-23 14:54:25 --> Input Class Initialized
INFO - 2023-04-23 14:54:25 --> Language Class Initialized
INFO - 2023-04-23 14:54:25 --> Loader Class Initialized
INFO - 2023-04-23 14:54:25 --> Helper loaded: url_helper
INFO - 2023-04-23 14:54:25 --> Helper loaded: file_helper
INFO - 2023-04-23 14:54:25 --> Helper loaded: html_helper
INFO - 2023-04-23 14:54:25 --> Helper loaded: text_helper
INFO - 2023-04-23 14:54:25 --> Helper loaded: form_helper
INFO - 2023-04-23 14:54:25 --> Helper loaded: lang_helper
INFO - 2023-04-23 14:54:25 --> Helper loaded: security_helper
INFO - 2023-04-23 14:54:25 --> Helper loaded: cookie_helper
INFO - 2023-04-23 14:54:25 --> Database Driver Class Initialized
INFO - 2023-04-23 14:54:25 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-23 14:54:25 --> Parser Class Initialized
INFO - 2023-04-23 14:54:25 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-23 14:54:25 --> Pagination Class Initialized
INFO - 2023-04-23 14:54:25 --> Form Validation Class Initialized
INFO - 2023-04-23 14:54:25 --> Controller Class Initialized
INFO - 2023-04-23 14:54:25 --> Model Class Initialized
DEBUG - 2023-04-23 14:54:25 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-04-23 14:54:25 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-23 14:54:25 --> Model Class Initialized
INFO - 2023-04-23 14:54:25 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/demandrequest/customer_demandrequest.php
DEBUG - 2023-04-23 14:54:25 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-04-23 14:54:25 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-04-23 14:54:25 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-04-23 14:54:25 --> Model Class Initialized
INFO - 2023-04-23 14:54:25 --> Model Class Initialized
INFO - 2023-04-23 14:54:25 --> Model Class Initialized
INFO - 2023-04-23 14:54:25 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-04-23 14:54:25 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-04-23 14:54:25 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-04-23 14:54:25 --> Final output sent to browser
DEBUG - 2023-04-23 14:54:25 --> Total execution time: 0.1400
ERROR - 2023-04-23 14:54:26 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-23 14:54:26 --> Config Class Initialized
INFO - 2023-04-23 14:54:26 --> Hooks Class Initialized
DEBUG - 2023-04-23 14:54:26 --> UTF-8 Support Enabled
INFO - 2023-04-23 14:54:26 --> Utf8 Class Initialized
INFO - 2023-04-23 14:54:26 --> URI Class Initialized
INFO - 2023-04-23 14:54:26 --> Router Class Initialized
INFO - 2023-04-23 14:54:26 --> Output Class Initialized
INFO - 2023-04-23 14:54:26 --> Security Class Initialized
DEBUG - 2023-04-23 14:54:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-23 14:54:26 --> Input Class Initialized
INFO - 2023-04-23 14:54:26 --> Language Class Initialized
INFO - 2023-04-23 14:54:26 --> Loader Class Initialized
INFO - 2023-04-23 14:54:26 --> Helper loaded: url_helper
INFO - 2023-04-23 14:54:26 --> Helper loaded: file_helper
INFO - 2023-04-23 14:54:26 --> Helper loaded: html_helper
INFO - 2023-04-23 14:54:26 --> Helper loaded: text_helper
INFO - 2023-04-23 14:54:26 --> Helper loaded: form_helper
INFO - 2023-04-23 14:54:26 --> Helper loaded: lang_helper
INFO - 2023-04-23 14:54:26 --> Helper loaded: security_helper
INFO - 2023-04-23 14:54:26 --> Helper loaded: cookie_helper
INFO - 2023-04-23 14:54:26 --> Database Driver Class Initialized
INFO - 2023-04-23 14:54:26 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-23 14:54:26 --> Parser Class Initialized
INFO - 2023-04-23 14:54:26 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-23 14:54:26 --> Pagination Class Initialized
INFO - 2023-04-23 14:54:26 --> Form Validation Class Initialized
INFO - 2023-04-23 14:54:26 --> Controller Class Initialized
INFO - 2023-04-23 14:54:26 --> Model Class Initialized
DEBUG - 2023-04-23 14:54:26 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-04-23 14:54:26 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-23 14:54:26 --> Model Class Initialized
INFO - 2023-04-23 14:54:26 --> Final output sent to browser
DEBUG - 2023-04-23 14:54:26 --> Total execution time: 0.0275
ERROR - 2023-04-23 14:54:50 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-23 14:54:50 --> Config Class Initialized
INFO - 2023-04-23 14:54:50 --> Hooks Class Initialized
DEBUG - 2023-04-23 14:54:50 --> UTF-8 Support Enabled
INFO - 2023-04-23 14:54:50 --> Utf8 Class Initialized
INFO - 2023-04-23 14:54:50 --> URI Class Initialized
INFO - 2023-04-23 14:54:50 --> Router Class Initialized
INFO - 2023-04-23 14:54:50 --> Output Class Initialized
INFO - 2023-04-23 14:54:50 --> Security Class Initialized
DEBUG - 2023-04-23 14:54:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-23 14:54:50 --> Input Class Initialized
INFO - 2023-04-23 14:54:50 --> Language Class Initialized
INFO - 2023-04-23 14:54:50 --> Loader Class Initialized
INFO - 2023-04-23 14:54:50 --> Helper loaded: url_helper
INFO - 2023-04-23 14:54:50 --> Helper loaded: file_helper
INFO - 2023-04-23 14:54:50 --> Helper loaded: html_helper
INFO - 2023-04-23 14:54:50 --> Helper loaded: text_helper
INFO - 2023-04-23 14:54:50 --> Helper loaded: form_helper
INFO - 2023-04-23 14:54:50 --> Helper loaded: lang_helper
INFO - 2023-04-23 14:54:50 --> Helper loaded: security_helper
INFO - 2023-04-23 14:54:50 --> Helper loaded: cookie_helper
INFO - 2023-04-23 14:54:50 --> Database Driver Class Initialized
INFO - 2023-04-23 14:54:50 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-23 14:54:50 --> Parser Class Initialized
INFO - 2023-04-23 14:54:50 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-23 14:54:50 --> Pagination Class Initialized
INFO - 2023-04-23 14:54:51 --> Form Validation Class Initialized
INFO - 2023-04-23 14:54:51 --> Controller Class Initialized
INFO - 2023-04-23 14:54:51 --> Model Class Initialized
DEBUG - 2023-04-23 14:54:51 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-04-23 14:54:51 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-23 14:54:51 --> Model Class Initialized
DEBUG - 2023-04-23 14:54:51 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-23 14:54:51 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/demandrequest/demandrequest_html.php
DEBUG - 2023-04-23 14:54:51 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-04-23 14:54:51 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-04-23 14:54:51 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-04-23 14:54:51 --> Model Class Initialized
INFO - 2023-04-23 14:54:51 --> Model Class Initialized
INFO - 2023-04-23 14:54:51 --> Model Class Initialized
INFO - 2023-04-23 14:54:51 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-04-23 14:54:51 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-04-23 14:54:51 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-04-23 14:54:51 --> Final output sent to browser
DEBUG - 2023-04-23 14:54:51 --> Total execution time: 0.1404
ERROR - 2023-04-23 14:55:09 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-23 14:55:09 --> Config Class Initialized
INFO - 2023-04-23 14:55:09 --> Hooks Class Initialized
DEBUG - 2023-04-23 14:55:09 --> UTF-8 Support Enabled
INFO - 2023-04-23 14:55:09 --> Utf8 Class Initialized
INFO - 2023-04-23 14:55:09 --> URI Class Initialized
DEBUG - 2023-04-23 14:55:09 --> No URI present. Default controller set.
INFO - 2023-04-23 14:55:09 --> Router Class Initialized
INFO - 2023-04-23 14:55:09 --> Output Class Initialized
INFO - 2023-04-23 14:55:09 --> Security Class Initialized
DEBUG - 2023-04-23 14:55:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-23 14:55:09 --> Input Class Initialized
INFO - 2023-04-23 14:55:09 --> Language Class Initialized
INFO - 2023-04-23 14:55:09 --> Loader Class Initialized
INFO - 2023-04-23 14:55:09 --> Helper loaded: url_helper
INFO - 2023-04-23 14:55:09 --> Helper loaded: file_helper
INFO - 2023-04-23 14:55:09 --> Helper loaded: html_helper
INFO - 2023-04-23 14:55:09 --> Helper loaded: text_helper
INFO - 2023-04-23 14:55:09 --> Helper loaded: form_helper
INFO - 2023-04-23 14:55:09 --> Helper loaded: lang_helper
INFO - 2023-04-23 14:55:09 --> Helper loaded: security_helper
INFO - 2023-04-23 14:55:09 --> Helper loaded: cookie_helper
INFO - 2023-04-23 14:55:09 --> Database Driver Class Initialized
INFO - 2023-04-23 14:55:09 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-23 14:55:09 --> Parser Class Initialized
INFO - 2023-04-23 14:55:09 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-23 14:55:09 --> Pagination Class Initialized
INFO - 2023-04-23 14:55:09 --> Form Validation Class Initialized
INFO - 2023-04-23 14:55:09 --> Controller Class Initialized
INFO - 2023-04-23 14:55:09 --> Model Class Initialized
DEBUG - 2023-04-23 14:55:09 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-23 14:55:09 --> Model Class Initialized
DEBUG - 2023-04-23 14:55:09 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-23 14:55:09 --> Model Class Initialized
INFO - 2023-04-23 14:55:09 --> Model Class Initialized
INFO - 2023-04-23 14:55:09 --> Model Class Initialized
INFO - 2023-04-23 14:55:09 --> Model Class Initialized
DEBUG - 2023-04-23 14:55:09 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-04-23 14:55:09 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-23 14:55:09 --> Model Class Initialized
INFO - 2023-04-23 14:55:09 --> Model Class Initialized
INFO - 2023-04-23 14:55:09 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-04-23 14:55:09 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-04-23 14:55:09 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-04-23 14:55:09 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-04-23 14:55:09 --> Model Class Initialized
INFO - 2023-04-23 14:55:09 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-04-23 14:55:09 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-04-23 14:55:09 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-04-23 14:55:09 --> Final output sent to browser
DEBUG - 2023-04-23 14:55:09 --> Total execution time: 0.1635
ERROR - 2023-04-23 14:55:42 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-23 14:55:42 --> Config Class Initialized
INFO - 2023-04-23 14:55:42 --> Hooks Class Initialized
DEBUG - 2023-04-23 14:55:42 --> UTF-8 Support Enabled
INFO - 2023-04-23 14:55:42 --> Utf8 Class Initialized
INFO - 2023-04-23 14:55:42 --> URI Class Initialized
INFO - 2023-04-23 14:55:42 --> Router Class Initialized
INFO - 2023-04-23 14:55:42 --> Output Class Initialized
INFO - 2023-04-23 14:55:42 --> Security Class Initialized
DEBUG - 2023-04-23 14:55:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-23 14:55:42 --> Input Class Initialized
INFO - 2023-04-23 14:55:42 --> Language Class Initialized
INFO - 2023-04-23 14:55:42 --> Loader Class Initialized
INFO - 2023-04-23 14:55:42 --> Helper loaded: url_helper
INFO - 2023-04-23 14:55:42 --> Helper loaded: file_helper
INFO - 2023-04-23 14:55:42 --> Helper loaded: html_helper
INFO - 2023-04-23 14:55:42 --> Helper loaded: text_helper
INFO - 2023-04-23 14:55:42 --> Helper loaded: form_helper
INFO - 2023-04-23 14:55:42 --> Helper loaded: lang_helper
INFO - 2023-04-23 14:55:42 --> Helper loaded: security_helper
INFO - 2023-04-23 14:55:42 --> Helper loaded: cookie_helper
INFO - 2023-04-23 14:55:42 --> Database Driver Class Initialized
INFO - 2023-04-23 14:55:42 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-23 14:55:42 --> Parser Class Initialized
INFO - 2023-04-23 14:55:42 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-23 14:55:42 --> Pagination Class Initialized
INFO - 2023-04-23 14:55:42 --> Form Validation Class Initialized
INFO - 2023-04-23 14:55:42 --> Controller Class Initialized
INFO - 2023-04-23 14:55:42 --> Model Class Initialized
DEBUG - 2023-04-23 14:55:42 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-04-23 14:55:42 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-23 14:55:42 --> Model Class Initialized
DEBUG - 2023-04-23 14:55:42 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-23 14:55:42 --> Model Class Initialized
INFO - 2023-04-23 14:55:42 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice.php
DEBUG - 2023-04-23 14:55:42 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-04-23 14:55:42 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-04-23 14:55:42 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-04-23 14:55:42 --> Model Class Initialized
INFO - 2023-04-23 14:55:42 --> Model Class Initialized
INFO - 2023-04-23 14:55:42 --> Model Class Initialized
INFO - 2023-04-23 14:55:42 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-04-23 14:55:42 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-04-23 14:55:42 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-04-23 14:55:42 --> Final output sent to browser
DEBUG - 2023-04-23 14:55:42 --> Total execution time: 0.1418
ERROR - 2023-04-23 14:55:42 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-23 14:55:42 --> Config Class Initialized
INFO - 2023-04-23 14:55:42 --> Hooks Class Initialized
DEBUG - 2023-04-23 14:55:42 --> UTF-8 Support Enabled
INFO - 2023-04-23 14:55:42 --> Utf8 Class Initialized
INFO - 2023-04-23 14:55:42 --> URI Class Initialized
INFO - 2023-04-23 14:55:42 --> Router Class Initialized
INFO - 2023-04-23 14:55:42 --> Output Class Initialized
INFO - 2023-04-23 14:55:42 --> Security Class Initialized
DEBUG - 2023-04-23 14:55:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-23 14:55:42 --> Input Class Initialized
INFO - 2023-04-23 14:55:42 --> Language Class Initialized
INFO - 2023-04-23 14:55:42 --> Loader Class Initialized
INFO - 2023-04-23 14:55:42 --> Helper loaded: url_helper
INFO - 2023-04-23 14:55:42 --> Helper loaded: file_helper
INFO - 2023-04-23 14:55:42 --> Helper loaded: html_helper
INFO - 2023-04-23 14:55:42 --> Helper loaded: text_helper
INFO - 2023-04-23 14:55:42 --> Helper loaded: form_helper
INFO - 2023-04-23 14:55:42 --> Helper loaded: lang_helper
INFO - 2023-04-23 14:55:42 --> Helper loaded: security_helper
INFO - 2023-04-23 14:55:42 --> Helper loaded: cookie_helper
INFO - 2023-04-23 14:55:42 --> Database Driver Class Initialized
INFO - 2023-04-23 14:55:42 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-23 14:55:42 --> Parser Class Initialized
INFO - 2023-04-23 14:55:42 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-23 14:55:42 --> Pagination Class Initialized
INFO - 2023-04-23 14:55:42 --> Form Validation Class Initialized
INFO - 2023-04-23 14:55:42 --> Controller Class Initialized
INFO - 2023-04-23 14:55:42 --> Model Class Initialized
DEBUG - 2023-04-23 14:55:42 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-04-23 14:55:42 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-23 14:55:42 --> Model Class Initialized
DEBUG - 2023-04-23 14:55:42 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-23 14:55:42 --> Model Class Initialized
INFO - 2023-04-23 14:55:43 --> Final output sent to browser
DEBUG - 2023-04-23 14:55:43 --> Total execution time: 0.0561
ERROR - 2023-04-23 14:55:49 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-23 14:55:49 --> Config Class Initialized
INFO - 2023-04-23 14:55:49 --> Hooks Class Initialized
DEBUG - 2023-04-23 14:55:49 --> UTF-8 Support Enabled
INFO - 2023-04-23 14:55:49 --> Utf8 Class Initialized
INFO - 2023-04-23 14:55:49 --> URI Class Initialized
INFO - 2023-04-23 14:55:49 --> Router Class Initialized
INFO - 2023-04-23 14:55:49 --> Output Class Initialized
INFO - 2023-04-23 14:55:49 --> Security Class Initialized
DEBUG - 2023-04-23 14:55:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-23 14:55:49 --> Input Class Initialized
INFO - 2023-04-23 14:55:49 --> Language Class Initialized
INFO - 2023-04-23 14:55:49 --> Loader Class Initialized
INFO - 2023-04-23 14:55:49 --> Helper loaded: url_helper
INFO - 2023-04-23 14:55:49 --> Helper loaded: file_helper
INFO - 2023-04-23 14:55:49 --> Helper loaded: html_helper
INFO - 2023-04-23 14:55:49 --> Helper loaded: text_helper
INFO - 2023-04-23 14:55:49 --> Helper loaded: form_helper
INFO - 2023-04-23 14:55:49 --> Helper loaded: lang_helper
INFO - 2023-04-23 14:55:49 --> Helper loaded: security_helper
INFO - 2023-04-23 14:55:49 --> Helper loaded: cookie_helper
INFO - 2023-04-23 14:55:49 --> Database Driver Class Initialized
INFO - 2023-04-23 14:55:49 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-23 14:55:49 --> Parser Class Initialized
INFO - 2023-04-23 14:55:49 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-23 14:55:49 --> Pagination Class Initialized
INFO - 2023-04-23 14:55:49 --> Form Validation Class Initialized
INFO - 2023-04-23 14:55:49 --> Controller Class Initialized
INFO - 2023-04-23 14:55:49 --> Model Class Initialized
DEBUG - 2023-04-23 14:55:49 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-04-23 14:55:49 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-23 14:55:49 --> Model Class Initialized
DEBUG - 2023-04-23 14:55:49 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-23 14:55:49 --> Model Class Initialized
INFO - 2023-04-23 14:55:49 --> Final output sent to browser
DEBUG - 2023-04-23 14:55:49 --> Total execution time: 0.0635
ERROR - 2023-04-23 14:55:57 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-23 14:55:57 --> Config Class Initialized
INFO - 2023-04-23 14:55:57 --> Hooks Class Initialized
DEBUG - 2023-04-23 14:55:57 --> UTF-8 Support Enabled
INFO - 2023-04-23 14:55:57 --> Utf8 Class Initialized
INFO - 2023-04-23 14:55:57 --> URI Class Initialized
INFO - 2023-04-23 14:55:57 --> Router Class Initialized
INFO - 2023-04-23 14:55:57 --> Output Class Initialized
INFO - 2023-04-23 14:55:57 --> Security Class Initialized
DEBUG - 2023-04-23 14:55:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-23 14:55:57 --> Input Class Initialized
INFO - 2023-04-23 14:55:57 --> Language Class Initialized
INFO - 2023-04-23 14:55:57 --> Loader Class Initialized
INFO - 2023-04-23 14:55:57 --> Helper loaded: url_helper
INFO - 2023-04-23 14:55:57 --> Helper loaded: file_helper
INFO - 2023-04-23 14:55:57 --> Helper loaded: html_helper
INFO - 2023-04-23 14:55:57 --> Helper loaded: text_helper
INFO - 2023-04-23 14:55:57 --> Helper loaded: form_helper
INFO - 2023-04-23 14:55:57 --> Helper loaded: lang_helper
INFO - 2023-04-23 14:55:57 --> Helper loaded: security_helper
INFO - 2023-04-23 14:55:57 --> Helper loaded: cookie_helper
INFO - 2023-04-23 14:55:57 --> Database Driver Class Initialized
INFO - 2023-04-23 14:55:57 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-23 14:55:57 --> Parser Class Initialized
INFO - 2023-04-23 14:55:57 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-23 14:55:57 --> Pagination Class Initialized
INFO - 2023-04-23 14:55:57 --> Form Validation Class Initialized
INFO - 2023-04-23 14:55:57 --> Controller Class Initialized
DEBUG - 2023-04-23 14:55:57 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-04-23 14:55:57 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-23 14:55:57 --> Model Class Initialized
DEBUG - 2023-04-23 14:55:57 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-23 14:55:57 --> Model Class Initialized
DEBUG - 2023-04-23 14:55:57 --> Lcustomer class already loaded. Second attempt ignored.
INFO - 2023-04-23 14:55:57 --> Model Class Initialized
INFO - 2023-04-23 14:55:57 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/customer/customer.php
DEBUG - 2023-04-23 14:55:57 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-04-23 14:55:57 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-04-23 14:55:57 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-04-23 14:55:57 --> Model Class Initialized
INFO - 2023-04-23 14:55:57 --> Model Class Initialized
INFO - 2023-04-23 14:55:57 --> Model Class Initialized
INFO - 2023-04-23 14:55:57 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-04-23 14:55:57 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-04-23 14:55:57 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-04-23 14:55:57 --> Final output sent to browser
DEBUG - 2023-04-23 14:55:57 --> Total execution time: 0.1477
ERROR - 2023-04-23 14:55:58 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-23 14:55:58 --> Config Class Initialized
INFO - 2023-04-23 14:55:58 --> Hooks Class Initialized
DEBUG - 2023-04-23 14:55:58 --> UTF-8 Support Enabled
INFO - 2023-04-23 14:55:58 --> Utf8 Class Initialized
INFO - 2023-04-23 14:55:58 --> URI Class Initialized
INFO - 2023-04-23 14:55:58 --> Router Class Initialized
INFO - 2023-04-23 14:55:58 --> Output Class Initialized
INFO - 2023-04-23 14:55:58 --> Security Class Initialized
DEBUG - 2023-04-23 14:55:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-23 14:55:58 --> Input Class Initialized
INFO - 2023-04-23 14:55:58 --> Language Class Initialized
INFO - 2023-04-23 14:55:58 --> Loader Class Initialized
INFO - 2023-04-23 14:55:58 --> Helper loaded: url_helper
INFO - 2023-04-23 14:55:58 --> Helper loaded: file_helper
INFO - 2023-04-23 14:55:58 --> Helper loaded: html_helper
INFO - 2023-04-23 14:55:58 --> Helper loaded: text_helper
INFO - 2023-04-23 14:55:58 --> Helper loaded: form_helper
INFO - 2023-04-23 14:55:58 --> Helper loaded: lang_helper
INFO - 2023-04-23 14:55:58 --> Helper loaded: security_helper
INFO - 2023-04-23 14:55:58 --> Helper loaded: cookie_helper
INFO - 2023-04-23 14:55:58 --> Database Driver Class Initialized
INFO - 2023-04-23 14:55:58 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-23 14:55:58 --> Parser Class Initialized
INFO - 2023-04-23 14:55:58 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-23 14:55:58 --> Pagination Class Initialized
INFO - 2023-04-23 14:55:58 --> Form Validation Class Initialized
INFO - 2023-04-23 14:55:58 --> Controller Class Initialized
DEBUG - 2023-04-23 14:55:58 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-04-23 14:55:58 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-23 14:55:58 --> Model Class Initialized
DEBUG - 2023-04-23 14:55:58 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-23 14:55:58 --> Model Class Initialized
INFO - 2023-04-23 14:55:58 --> Final output sent to browser
DEBUG - 2023-04-23 14:55:58 --> Total execution time: 0.0326
ERROR - 2023-04-23 14:56:02 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-23 14:56:02 --> Config Class Initialized
INFO - 2023-04-23 14:56:02 --> Hooks Class Initialized
DEBUG - 2023-04-23 14:56:02 --> UTF-8 Support Enabled
INFO - 2023-04-23 14:56:02 --> Utf8 Class Initialized
INFO - 2023-04-23 14:56:02 --> URI Class Initialized
INFO - 2023-04-23 14:56:02 --> Router Class Initialized
INFO - 2023-04-23 14:56:02 --> Output Class Initialized
INFO - 2023-04-23 14:56:02 --> Security Class Initialized
DEBUG - 2023-04-23 14:56:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-23 14:56:02 --> Input Class Initialized
INFO - 2023-04-23 14:56:02 --> Language Class Initialized
INFO - 2023-04-23 14:56:02 --> Loader Class Initialized
INFO - 2023-04-23 14:56:02 --> Helper loaded: url_helper
INFO - 2023-04-23 14:56:02 --> Helper loaded: file_helper
INFO - 2023-04-23 14:56:02 --> Helper loaded: html_helper
INFO - 2023-04-23 14:56:02 --> Helper loaded: text_helper
INFO - 2023-04-23 14:56:02 --> Helper loaded: form_helper
INFO - 2023-04-23 14:56:02 --> Helper loaded: lang_helper
INFO - 2023-04-23 14:56:02 --> Helper loaded: security_helper
INFO - 2023-04-23 14:56:02 --> Helper loaded: cookie_helper
INFO - 2023-04-23 14:56:02 --> Database Driver Class Initialized
INFO - 2023-04-23 14:56:02 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-23 14:56:02 --> Parser Class Initialized
INFO - 2023-04-23 14:56:02 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-23 14:56:02 --> Pagination Class Initialized
INFO - 2023-04-23 14:56:02 --> Form Validation Class Initialized
INFO - 2023-04-23 14:56:02 --> Controller Class Initialized
DEBUG - 2023-04-23 14:56:02 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-04-23 14:56:02 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-23 14:56:02 --> Model Class Initialized
DEBUG - 2023-04-23 14:56:02 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-23 14:56:02 --> Model Class Initialized
INFO - 2023-04-23 14:56:02 --> Final output sent to browser
DEBUG - 2023-04-23 14:56:02 --> Total execution time: 0.0836
ERROR - 2023-04-23 14:56:20 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-23 14:56:20 --> Config Class Initialized
INFO - 2023-04-23 14:56:20 --> Hooks Class Initialized
DEBUG - 2023-04-23 14:56:20 --> UTF-8 Support Enabled
INFO - 2023-04-23 14:56:20 --> Utf8 Class Initialized
INFO - 2023-04-23 14:56:20 --> URI Class Initialized
INFO - 2023-04-23 14:56:20 --> Router Class Initialized
INFO - 2023-04-23 14:56:20 --> Output Class Initialized
INFO - 2023-04-23 14:56:20 --> Security Class Initialized
DEBUG - 2023-04-23 14:56:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-23 14:56:20 --> Input Class Initialized
INFO - 2023-04-23 14:56:20 --> Language Class Initialized
INFO - 2023-04-23 14:56:20 --> Loader Class Initialized
INFO - 2023-04-23 14:56:20 --> Helper loaded: url_helper
INFO - 2023-04-23 14:56:20 --> Helper loaded: file_helper
INFO - 2023-04-23 14:56:20 --> Helper loaded: html_helper
INFO - 2023-04-23 14:56:20 --> Helper loaded: text_helper
INFO - 2023-04-23 14:56:20 --> Helper loaded: form_helper
INFO - 2023-04-23 14:56:20 --> Helper loaded: lang_helper
INFO - 2023-04-23 14:56:20 --> Helper loaded: security_helper
INFO - 2023-04-23 14:56:20 --> Helper loaded: cookie_helper
INFO - 2023-04-23 14:56:20 --> Database Driver Class Initialized
INFO - 2023-04-23 14:56:20 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-23 14:56:20 --> Parser Class Initialized
INFO - 2023-04-23 14:56:20 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-23 14:56:20 --> Pagination Class Initialized
INFO - 2023-04-23 14:56:20 --> Form Validation Class Initialized
INFO - 2023-04-23 14:56:20 --> Controller Class Initialized
DEBUG - 2023-04-23 14:56:20 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-04-23 14:56:20 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-23 14:56:20 --> Model Class Initialized
DEBUG - 2023-04-23 14:56:20 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-23 14:56:20 --> Model Class Initialized
INFO - 2023-04-23 14:56:20 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/customer/view_customer.php
DEBUG - 2023-04-23 14:56:20 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-04-23 14:56:20 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-04-23 14:56:20 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-04-23 14:56:20 --> Model Class Initialized
INFO - 2023-04-23 14:56:20 --> Model Class Initialized
INFO - 2023-04-23 14:56:20 --> Model Class Initialized
INFO - 2023-04-23 14:56:20 --> Model Class Initialized
INFO - 2023-04-23 14:56:20 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-04-23 14:56:20 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-04-23 14:56:20 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-04-23 14:56:20 --> Final output sent to browser
DEBUG - 2023-04-23 14:56:20 --> Total execution time: 0.1457
ERROR - 2023-04-23 14:56:29 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-23 14:56:29 --> Config Class Initialized
INFO - 2023-04-23 14:56:29 --> Hooks Class Initialized
DEBUG - 2023-04-23 14:56:29 --> UTF-8 Support Enabled
INFO - 2023-04-23 14:56:29 --> Utf8 Class Initialized
INFO - 2023-04-23 14:56:29 --> URI Class Initialized
INFO - 2023-04-23 14:56:29 --> Router Class Initialized
INFO - 2023-04-23 14:56:29 --> Output Class Initialized
INFO - 2023-04-23 14:56:29 --> Security Class Initialized
DEBUG - 2023-04-23 14:56:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-23 14:56:29 --> Input Class Initialized
INFO - 2023-04-23 14:56:29 --> Language Class Initialized
INFO - 2023-04-23 14:56:29 --> Loader Class Initialized
INFO - 2023-04-23 14:56:29 --> Helper loaded: url_helper
INFO - 2023-04-23 14:56:29 --> Helper loaded: file_helper
INFO - 2023-04-23 14:56:29 --> Helper loaded: html_helper
INFO - 2023-04-23 14:56:29 --> Helper loaded: text_helper
INFO - 2023-04-23 14:56:29 --> Helper loaded: form_helper
INFO - 2023-04-23 14:56:29 --> Helper loaded: lang_helper
INFO - 2023-04-23 14:56:29 --> Helper loaded: security_helper
INFO - 2023-04-23 14:56:29 --> Helper loaded: cookie_helper
INFO - 2023-04-23 14:56:29 --> Database Driver Class Initialized
INFO - 2023-04-23 14:56:29 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-23 14:56:29 --> Parser Class Initialized
INFO - 2023-04-23 14:56:29 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-23 14:56:29 --> Pagination Class Initialized
INFO - 2023-04-23 14:56:29 --> Form Validation Class Initialized
INFO - 2023-04-23 14:56:29 --> Controller Class Initialized
DEBUG - 2023-04-23 14:56:29 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-04-23 14:56:29 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-23 14:56:29 --> Model Class Initialized
DEBUG - 2023-04-23 14:56:29 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-23 14:56:29 --> Model Class Initialized
DEBUG - 2023-04-23 14:56:29 --> Lcustomer class already loaded. Second attempt ignored.
INFO - 2023-04-23 14:56:29 --> Model Class Initialized
INFO - 2023-04-23 14:56:29 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/customer/customer.php
DEBUG - 2023-04-23 14:56:29 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-04-23 14:56:29 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-04-23 14:56:29 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-04-23 14:56:29 --> Model Class Initialized
INFO - 2023-04-23 14:56:29 --> Model Class Initialized
INFO - 2023-04-23 14:56:29 --> Model Class Initialized
INFO - 2023-04-23 14:56:29 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-04-23 14:56:29 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-04-23 14:56:29 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-04-23 14:56:29 --> Final output sent to browser
DEBUG - 2023-04-23 14:56:29 --> Total execution time: 0.1326
ERROR - 2023-04-23 14:56:30 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-23 14:56:30 --> Config Class Initialized
INFO - 2023-04-23 14:56:30 --> Hooks Class Initialized
DEBUG - 2023-04-23 14:56:30 --> UTF-8 Support Enabled
INFO - 2023-04-23 14:56:30 --> Utf8 Class Initialized
INFO - 2023-04-23 14:56:30 --> URI Class Initialized
INFO - 2023-04-23 14:56:30 --> Router Class Initialized
INFO - 2023-04-23 14:56:30 --> Output Class Initialized
INFO - 2023-04-23 14:56:30 --> Security Class Initialized
DEBUG - 2023-04-23 14:56:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-23 14:56:30 --> Input Class Initialized
INFO - 2023-04-23 14:56:30 --> Language Class Initialized
INFO - 2023-04-23 14:56:30 --> Loader Class Initialized
INFO - 2023-04-23 14:56:30 --> Helper loaded: url_helper
INFO - 2023-04-23 14:56:30 --> Helper loaded: file_helper
INFO - 2023-04-23 14:56:30 --> Helper loaded: html_helper
INFO - 2023-04-23 14:56:30 --> Helper loaded: text_helper
INFO - 2023-04-23 14:56:30 --> Helper loaded: form_helper
INFO - 2023-04-23 14:56:30 --> Helper loaded: lang_helper
INFO - 2023-04-23 14:56:30 --> Helper loaded: security_helper
INFO - 2023-04-23 14:56:30 --> Helper loaded: cookie_helper
INFO - 2023-04-23 14:56:30 --> Database Driver Class Initialized
INFO - 2023-04-23 14:56:30 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-23 14:56:30 --> Parser Class Initialized
INFO - 2023-04-23 14:56:30 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-23 14:56:30 --> Pagination Class Initialized
INFO - 2023-04-23 14:56:30 --> Form Validation Class Initialized
INFO - 2023-04-23 14:56:30 --> Controller Class Initialized
DEBUG - 2023-04-23 14:56:30 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-04-23 14:56:30 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-23 14:56:30 --> Model Class Initialized
DEBUG - 2023-04-23 14:56:30 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-23 14:56:30 --> Model Class Initialized
INFO - 2023-04-23 14:56:30 --> Final output sent to browser
DEBUG - 2023-04-23 14:56:30 --> Total execution time: 0.0290
ERROR - 2023-04-23 14:56:52 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-23 14:56:52 --> Config Class Initialized
INFO - 2023-04-23 14:56:52 --> Hooks Class Initialized
DEBUG - 2023-04-23 14:56:52 --> UTF-8 Support Enabled
INFO - 2023-04-23 14:56:52 --> Utf8 Class Initialized
INFO - 2023-04-23 14:56:52 --> URI Class Initialized
INFO - 2023-04-23 14:56:52 --> Router Class Initialized
INFO - 2023-04-23 14:56:52 --> Output Class Initialized
INFO - 2023-04-23 14:56:52 --> Security Class Initialized
DEBUG - 2023-04-23 14:56:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-23 14:56:52 --> Input Class Initialized
INFO - 2023-04-23 14:56:52 --> Language Class Initialized
INFO - 2023-04-23 14:56:52 --> Loader Class Initialized
INFO - 2023-04-23 14:56:52 --> Helper loaded: url_helper
INFO - 2023-04-23 14:56:52 --> Helper loaded: file_helper
INFO - 2023-04-23 14:56:52 --> Helper loaded: html_helper
INFO - 2023-04-23 14:56:52 --> Helper loaded: text_helper
INFO - 2023-04-23 14:56:52 --> Helper loaded: form_helper
INFO - 2023-04-23 14:56:52 --> Helper loaded: lang_helper
INFO - 2023-04-23 14:56:52 --> Helper loaded: security_helper
INFO - 2023-04-23 14:56:52 --> Helper loaded: cookie_helper
INFO - 2023-04-23 14:56:52 --> Database Driver Class Initialized
INFO - 2023-04-23 14:56:52 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-23 14:56:52 --> Parser Class Initialized
INFO - 2023-04-23 14:56:52 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-23 14:56:52 --> Pagination Class Initialized
INFO - 2023-04-23 14:56:52 --> Form Validation Class Initialized
INFO - 2023-04-23 14:56:52 --> Controller Class Initialized
DEBUG - 2023-04-23 14:56:52 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-04-23 14:56:52 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-23 14:56:52 --> Model Class Initialized
DEBUG - 2023-04-23 14:56:52 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-23 14:56:52 --> Model Class Initialized
INFO - 2023-04-23 14:56:52 --> Final output sent to browser
DEBUG - 2023-04-23 14:56:52 --> Total execution time: 0.0833
ERROR - 2023-04-23 15:06:54 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-23 15:06:54 --> Config Class Initialized
INFO - 2023-04-23 15:06:54 --> Hooks Class Initialized
DEBUG - 2023-04-23 15:06:54 --> UTF-8 Support Enabled
INFO - 2023-04-23 15:06:54 --> Utf8 Class Initialized
INFO - 2023-04-23 15:06:54 --> URI Class Initialized
DEBUG - 2023-04-23 15:06:54 --> No URI present. Default controller set.
INFO - 2023-04-23 15:06:54 --> Router Class Initialized
INFO - 2023-04-23 15:06:54 --> Output Class Initialized
INFO - 2023-04-23 15:06:54 --> Security Class Initialized
DEBUG - 2023-04-23 15:06:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-23 15:06:54 --> Input Class Initialized
INFO - 2023-04-23 15:06:54 --> Language Class Initialized
INFO - 2023-04-23 15:06:54 --> Loader Class Initialized
INFO - 2023-04-23 15:06:54 --> Helper loaded: url_helper
INFO - 2023-04-23 15:06:54 --> Helper loaded: file_helper
INFO - 2023-04-23 15:06:54 --> Helper loaded: html_helper
INFO - 2023-04-23 15:06:54 --> Helper loaded: text_helper
INFO - 2023-04-23 15:06:54 --> Helper loaded: form_helper
INFO - 2023-04-23 15:06:54 --> Helper loaded: lang_helper
INFO - 2023-04-23 15:06:54 --> Helper loaded: security_helper
INFO - 2023-04-23 15:06:54 --> Helper loaded: cookie_helper
INFO - 2023-04-23 15:06:54 --> Database Driver Class Initialized
INFO - 2023-04-23 15:06:54 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-23 15:06:54 --> Parser Class Initialized
INFO - 2023-04-23 15:06:54 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-23 15:06:54 --> Pagination Class Initialized
INFO - 2023-04-23 15:06:54 --> Form Validation Class Initialized
INFO - 2023-04-23 15:06:54 --> Controller Class Initialized
INFO - 2023-04-23 15:06:54 --> Model Class Initialized
DEBUG - 2023-04-23 15:06:54 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-23 15:06:54 --> Model Class Initialized
DEBUG - 2023-04-23 15:06:54 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-23 15:06:54 --> Model Class Initialized
INFO - 2023-04-23 15:06:54 --> Model Class Initialized
INFO - 2023-04-23 15:06:54 --> Model Class Initialized
INFO - 2023-04-23 15:06:54 --> Model Class Initialized
DEBUG - 2023-04-23 15:06:54 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-04-23 15:06:54 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-23 15:06:54 --> Model Class Initialized
INFO - 2023-04-23 15:06:54 --> Model Class Initialized
INFO - 2023-04-23 15:06:54 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-04-23 15:06:54 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-04-23 15:06:54 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-04-23 15:06:54 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-04-23 15:06:54 --> Model Class Initialized
INFO - 2023-04-23 15:06:54 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-04-23 15:06:54 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-04-23 15:06:54 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-04-23 15:06:54 --> Final output sent to browser
DEBUG - 2023-04-23 15:06:54 --> Total execution time: 0.1672
ERROR - 2023-04-23 15:07:05 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-23 15:07:05 --> Config Class Initialized
INFO - 2023-04-23 15:07:05 --> Hooks Class Initialized
DEBUG - 2023-04-23 15:07:05 --> UTF-8 Support Enabled
INFO - 2023-04-23 15:07:05 --> Utf8 Class Initialized
INFO - 2023-04-23 15:07:05 --> URI Class Initialized
INFO - 2023-04-23 15:07:05 --> Router Class Initialized
INFO - 2023-04-23 15:07:05 --> Output Class Initialized
INFO - 2023-04-23 15:07:05 --> Security Class Initialized
DEBUG - 2023-04-23 15:07:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-23 15:07:05 --> Input Class Initialized
INFO - 2023-04-23 15:07:05 --> Language Class Initialized
INFO - 2023-04-23 15:07:05 --> Loader Class Initialized
INFO - 2023-04-23 15:07:05 --> Helper loaded: url_helper
INFO - 2023-04-23 15:07:05 --> Helper loaded: file_helper
INFO - 2023-04-23 15:07:05 --> Helper loaded: html_helper
INFO - 2023-04-23 15:07:05 --> Helper loaded: text_helper
INFO - 2023-04-23 15:07:05 --> Helper loaded: form_helper
INFO - 2023-04-23 15:07:05 --> Helper loaded: lang_helper
INFO - 2023-04-23 15:07:05 --> Helper loaded: security_helper
INFO - 2023-04-23 15:07:05 --> Helper loaded: cookie_helper
INFO - 2023-04-23 15:07:05 --> Database Driver Class Initialized
INFO - 2023-04-23 15:07:05 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-23 15:07:05 --> Parser Class Initialized
INFO - 2023-04-23 15:07:05 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-23 15:07:05 --> Pagination Class Initialized
INFO - 2023-04-23 15:07:05 --> Form Validation Class Initialized
INFO - 2023-04-23 15:07:05 --> Controller Class Initialized
DEBUG - 2023-04-23 15:07:05 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-04-23 15:07:05 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-23 15:07:05 --> Model Class Initialized
DEBUG - 2023-04-23 15:07:05 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-23 15:07:05 --> Model Class Initialized
DEBUG - 2023-04-23 15:07:05 --> Lcustomer class already loaded. Second attempt ignored.
INFO - 2023-04-23 15:07:05 --> Model Class Initialized
INFO - 2023-04-23 15:07:05 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/customer/customer.php
DEBUG - 2023-04-23 15:07:05 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-04-23 15:07:05 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-04-23 15:07:05 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-04-23 15:07:05 --> Model Class Initialized
INFO - 2023-04-23 15:07:05 --> Model Class Initialized
INFO - 2023-04-23 15:07:05 --> Model Class Initialized
INFO - 2023-04-23 15:07:05 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-04-23 15:07:05 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-04-23 15:07:05 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-04-23 15:07:05 --> Final output sent to browser
DEBUG - 2023-04-23 15:07:05 --> Total execution time: 0.1359
ERROR - 2023-04-23 15:07:06 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-23 15:07:06 --> Config Class Initialized
INFO - 2023-04-23 15:07:06 --> Hooks Class Initialized
DEBUG - 2023-04-23 15:07:06 --> UTF-8 Support Enabled
INFO - 2023-04-23 15:07:06 --> Utf8 Class Initialized
INFO - 2023-04-23 15:07:06 --> URI Class Initialized
INFO - 2023-04-23 15:07:06 --> Router Class Initialized
INFO - 2023-04-23 15:07:06 --> Output Class Initialized
INFO - 2023-04-23 15:07:06 --> Security Class Initialized
DEBUG - 2023-04-23 15:07:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-23 15:07:06 --> Input Class Initialized
INFO - 2023-04-23 15:07:06 --> Language Class Initialized
INFO - 2023-04-23 15:07:06 --> Loader Class Initialized
INFO - 2023-04-23 15:07:06 --> Helper loaded: url_helper
INFO - 2023-04-23 15:07:06 --> Helper loaded: file_helper
INFO - 2023-04-23 15:07:06 --> Helper loaded: html_helper
INFO - 2023-04-23 15:07:06 --> Helper loaded: text_helper
INFO - 2023-04-23 15:07:06 --> Helper loaded: form_helper
INFO - 2023-04-23 15:07:06 --> Helper loaded: lang_helper
INFO - 2023-04-23 15:07:06 --> Helper loaded: security_helper
INFO - 2023-04-23 15:07:06 --> Helper loaded: cookie_helper
INFO - 2023-04-23 15:07:06 --> Database Driver Class Initialized
INFO - 2023-04-23 15:07:06 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-23 15:07:06 --> Parser Class Initialized
INFO - 2023-04-23 15:07:06 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-23 15:07:06 --> Pagination Class Initialized
INFO - 2023-04-23 15:07:06 --> Form Validation Class Initialized
INFO - 2023-04-23 15:07:06 --> Controller Class Initialized
DEBUG - 2023-04-23 15:07:06 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-04-23 15:07:06 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-23 15:07:06 --> Model Class Initialized
DEBUG - 2023-04-23 15:07:06 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-23 15:07:06 --> Model Class Initialized
INFO - 2023-04-23 15:07:06 --> Final output sent to browser
DEBUG - 2023-04-23 15:07:06 --> Total execution time: 0.0306
ERROR - 2023-04-23 15:07:10 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-23 15:07:10 --> Config Class Initialized
INFO - 2023-04-23 15:07:10 --> Hooks Class Initialized
DEBUG - 2023-04-23 15:07:10 --> UTF-8 Support Enabled
INFO - 2023-04-23 15:07:10 --> Utf8 Class Initialized
INFO - 2023-04-23 15:07:10 --> URI Class Initialized
INFO - 2023-04-23 15:07:10 --> Router Class Initialized
INFO - 2023-04-23 15:07:10 --> Output Class Initialized
INFO - 2023-04-23 15:07:10 --> Security Class Initialized
DEBUG - 2023-04-23 15:07:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-23 15:07:10 --> Input Class Initialized
INFO - 2023-04-23 15:07:10 --> Language Class Initialized
INFO - 2023-04-23 15:07:10 --> Loader Class Initialized
INFO - 2023-04-23 15:07:10 --> Helper loaded: url_helper
INFO - 2023-04-23 15:07:10 --> Helper loaded: file_helper
INFO - 2023-04-23 15:07:10 --> Helper loaded: html_helper
INFO - 2023-04-23 15:07:10 --> Helper loaded: text_helper
INFO - 2023-04-23 15:07:10 --> Helper loaded: form_helper
INFO - 2023-04-23 15:07:10 --> Helper loaded: lang_helper
INFO - 2023-04-23 15:07:10 --> Helper loaded: security_helper
INFO - 2023-04-23 15:07:10 --> Helper loaded: cookie_helper
INFO - 2023-04-23 15:07:10 --> Database Driver Class Initialized
INFO - 2023-04-23 15:07:10 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-23 15:07:10 --> Parser Class Initialized
INFO - 2023-04-23 15:07:10 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-23 15:07:10 --> Pagination Class Initialized
INFO - 2023-04-23 15:07:10 --> Form Validation Class Initialized
INFO - 2023-04-23 15:07:10 --> Controller Class Initialized
DEBUG - 2023-04-23 15:07:10 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-04-23 15:07:10 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-23 15:07:10 --> Model Class Initialized
DEBUG - 2023-04-23 15:07:10 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-23 15:07:10 --> Model Class Initialized
INFO - 2023-04-23 15:07:10 --> Final output sent to browser
DEBUG - 2023-04-23 15:07:10 --> Total execution time: 0.0727
ERROR - 2023-04-23 15:07:17 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-23 15:07:17 --> Config Class Initialized
INFO - 2023-04-23 15:07:17 --> Hooks Class Initialized
DEBUG - 2023-04-23 15:07:17 --> UTF-8 Support Enabled
INFO - 2023-04-23 15:07:17 --> Utf8 Class Initialized
INFO - 2023-04-23 15:07:17 --> URI Class Initialized
INFO - 2023-04-23 15:07:17 --> Router Class Initialized
INFO - 2023-04-23 15:07:17 --> Output Class Initialized
INFO - 2023-04-23 15:07:17 --> Security Class Initialized
DEBUG - 2023-04-23 15:07:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-23 15:07:17 --> Input Class Initialized
INFO - 2023-04-23 15:07:17 --> Language Class Initialized
INFO - 2023-04-23 15:07:17 --> Loader Class Initialized
INFO - 2023-04-23 15:07:17 --> Helper loaded: url_helper
INFO - 2023-04-23 15:07:17 --> Helper loaded: file_helper
INFO - 2023-04-23 15:07:17 --> Helper loaded: html_helper
INFO - 2023-04-23 15:07:17 --> Helper loaded: text_helper
INFO - 2023-04-23 15:07:17 --> Helper loaded: form_helper
INFO - 2023-04-23 15:07:17 --> Helper loaded: lang_helper
INFO - 2023-04-23 15:07:17 --> Helper loaded: security_helper
INFO - 2023-04-23 15:07:17 --> Helper loaded: cookie_helper
INFO - 2023-04-23 15:07:17 --> Database Driver Class Initialized
INFO - 2023-04-23 15:07:17 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-23 15:07:17 --> Parser Class Initialized
INFO - 2023-04-23 15:07:17 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-23 15:07:17 --> Pagination Class Initialized
INFO - 2023-04-23 15:07:17 --> Form Validation Class Initialized
INFO - 2023-04-23 15:07:17 --> Controller Class Initialized
DEBUG - 2023-04-23 15:07:17 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-04-23 15:07:17 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-23 15:07:17 --> Model Class Initialized
DEBUG - 2023-04-23 15:07:17 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-23 15:07:17 --> Model Class Initialized
INFO - 2023-04-23 15:07:17 --> Final output sent to browser
DEBUG - 2023-04-23 15:07:17 --> Total execution time: 0.0476
ERROR - 2023-04-23 15:07:44 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-23 15:07:44 --> Config Class Initialized
INFO - 2023-04-23 15:07:44 --> Hooks Class Initialized
DEBUG - 2023-04-23 15:07:44 --> UTF-8 Support Enabled
INFO - 2023-04-23 15:07:44 --> Utf8 Class Initialized
INFO - 2023-04-23 15:07:44 --> URI Class Initialized
INFO - 2023-04-23 15:07:44 --> Router Class Initialized
INFO - 2023-04-23 15:07:44 --> Output Class Initialized
INFO - 2023-04-23 15:07:44 --> Security Class Initialized
DEBUG - 2023-04-23 15:07:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-23 15:07:44 --> Input Class Initialized
INFO - 2023-04-23 15:07:44 --> Language Class Initialized
INFO - 2023-04-23 15:07:44 --> Loader Class Initialized
INFO - 2023-04-23 15:07:44 --> Helper loaded: url_helper
INFO - 2023-04-23 15:07:44 --> Helper loaded: file_helper
INFO - 2023-04-23 15:07:44 --> Helper loaded: html_helper
INFO - 2023-04-23 15:07:44 --> Helper loaded: text_helper
INFO - 2023-04-23 15:07:44 --> Helper loaded: form_helper
INFO - 2023-04-23 15:07:44 --> Helper loaded: lang_helper
INFO - 2023-04-23 15:07:44 --> Helper loaded: security_helper
INFO - 2023-04-23 15:07:44 --> Helper loaded: cookie_helper
INFO - 2023-04-23 15:07:44 --> Database Driver Class Initialized
INFO - 2023-04-23 15:07:44 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-23 15:07:44 --> Parser Class Initialized
INFO - 2023-04-23 15:07:44 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-23 15:07:44 --> Pagination Class Initialized
INFO - 2023-04-23 15:07:44 --> Form Validation Class Initialized
INFO - 2023-04-23 15:07:44 --> Controller Class Initialized
DEBUG - 2023-04-23 15:07:44 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-04-23 15:07:44 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-23 15:07:44 --> Model Class Initialized
DEBUG - 2023-04-23 15:07:44 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-23 15:07:44 --> Model Class Initialized
INFO - 2023-04-23 15:07:44 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/customer/edit_customer_form.php
DEBUG - 2023-04-23 15:07:44 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-04-23 15:07:44 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-04-23 15:07:44 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-04-23 15:07:44 --> Model Class Initialized
INFO - 2023-04-23 15:07:44 --> Model Class Initialized
INFO - 2023-04-23 15:07:44 --> Model Class Initialized
INFO - 2023-04-23 15:07:44 --> Model Class Initialized
INFO - 2023-04-23 15:07:44 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-04-23 15:07:44 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-04-23 15:07:44 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-04-23 15:07:44 --> Final output sent to browser
DEBUG - 2023-04-23 15:07:44 --> Total execution time: 0.1564
ERROR - 2023-04-23 15:07:55 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-23 15:07:55 --> Config Class Initialized
INFO - 2023-04-23 15:07:55 --> Hooks Class Initialized
DEBUG - 2023-04-23 15:07:55 --> UTF-8 Support Enabled
INFO - 2023-04-23 15:07:55 --> Utf8 Class Initialized
INFO - 2023-04-23 15:07:55 --> URI Class Initialized
INFO - 2023-04-23 15:07:55 --> Router Class Initialized
INFO - 2023-04-23 15:07:55 --> Output Class Initialized
INFO - 2023-04-23 15:07:55 --> Security Class Initialized
DEBUG - 2023-04-23 15:07:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-23 15:07:55 --> Input Class Initialized
INFO - 2023-04-23 15:07:55 --> Language Class Initialized
INFO - 2023-04-23 15:07:55 --> Loader Class Initialized
INFO - 2023-04-23 15:07:55 --> Helper loaded: url_helper
INFO - 2023-04-23 15:07:55 --> Helper loaded: file_helper
INFO - 2023-04-23 15:07:55 --> Helper loaded: html_helper
INFO - 2023-04-23 15:07:55 --> Helper loaded: text_helper
INFO - 2023-04-23 15:07:55 --> Helper loaded: form_helper
INFO - 2023-04-23 15:07:55 --> Helper loaded: lang_helper
INFO - 2023-04-23 15:07:55 --> Helper loaded: security_helper
INFO - 2023-04-23 15:07:55 --> Helper loaded: cookie_helper
INFO - 2023-04-23 15:07:55 --> Database Driver Class Initialized
INFO - 2023-04-23 15:07:55 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-23 15:07:55 --> Parser Class Initialized
INFO - 2023-04-23 15:07:55 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-23 15:07:55 --> Pagination Class Initialized
INFO - 2023-04-23 15:07:55 --> Form Validation Class Initialized
INFO - 2023-04-23 15:07:55 --> Controller Class Initialized
DEBUG - 2023-04-23 15:07:55 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-04-23 15:07:55 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-23 15:07:55 --> Model Class Initialized
DEBUG - 2023-04-23 15:07:55 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-23 15:07:55 --> Model Class Initialized
ERROR - 2023-04-23 15:07:56 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-23 15:07:56 --> Config Class Initialized
INFO - 2023-04-23 15:07:56 --> Hooks Class Initialized
DEBUG - 2023-04-23 15:07:56 --> UTF-8 Support Enabled
INFO - 2023-04-23 15:07:56 --> Utf8 Class Initialized
INFO - 2023-04-23 15:07:56 --> URI Class Initialized
INFO - 2023-04-23 15:07:56 --> Router Class Initialized
INFO - 2023-04-23 15:07:56 --> Output Class Initialized
INFO - 2023-04-23 15:07:56 --> Security Class Initialized
DEBUG - 2023-04-23 15:07:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-23 15:07:56 --> Input Class Initialized
INFO - 2023-04-23 15:07:56 --> Language Class Initialized
INFO - 2023-04-23 15:07:56 --> Loader Class Initialized
INFO - 2023-04-23 15:07:56 --> Helper loaded: url_helper
INFO - 2023-04-23 15:07:56 --> Helper loaded: file_helper
INFO - 2023-04-23 15:07:56 --> Helper loaded: html_helper
INFO - 2023-04-23 15:07:56 --> Helper loaded: text_helper
INFO - 2023-04-23 15:07:56 --> Helper loaded: form_helper
INFO - 2023-04-23 15:07:56 --> Helper loaded: lang_helper
INFO - 2023-04-23 15:07:56 --> Helper loaded: security_helper
INFO - 2023-04-23 15:07:56 --> Helper loaded: cookie_helper
INFO - 2023-04-23 15:07:56 --> Database Driver Class Initialized
INFO - 2023-04-23 15:07:56 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-23 15:07:56 --> Parser Class Initialized
INFO - 2023-04-23 15:07:56 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-23 15:07:56 --> Pagination Class Initialized
INFO - 2023-04-23 15:07:56 --> Form Validation Class Initialized
INFO - 2023-04-23 15:07:56 --> Controller Class Initialized
DEBUG - 2023-04-23 15:07:56 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-04-23 15:07:56 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-23 15:07:56 --> Model Class Initialized
DEBUG - 2023-04-23 15:07:56 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-23 15:07:56 --> Model Class Initialized
DEBUG - 2023-04-23 15:07:56 --> Lcustomer class already loaded. Second attempt ignored.
INFO - 2023-04-23 15:07:56 --> Model Class Initialized
INFO - 2023-04-23 15:07:56 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/customer/customer.php
DEBUG - 2023-04-23 15:07:56 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-04-23 15:07:56 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-04-23 15:07:56 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-04-23 15:07:56 --> Model Class Initialized
INFO - 2023-04-23 15:07:56 --> Model Class Initialized
INFO - 2023-04-23 15:07:56 --> Model Class Initialized
INFO - 2023-04-23 15:07:56 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-04-23 15:07:56 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-04-23 15:07:56 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-04-23 15:07:56 --> Final output sent to browser
DEBUG - 2023-04-23 15:07:56 --> Total execution time: 0.1345
ERROR - 2023-04-23 15:07:57 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-23 15:07:57 --> Config Class Initialized
INFO - 2023-04-23 15:07:57 --> Hooks Class Initialized
DEBUG - 2023-04-23 15:07:57 --> UTF-8 Support Enabled
INFO - 2023-04-23 15:07:57 --> Utf8 Class Initialized
INFO - 2023-04-23 15:07:57 --> URI Class Initialized
INFO - 2023-04-23 15:07:57 --> Router Class Initialized
INFO - 2023-04-23 15:07:57 --> Output Class Initialized
INFO - 2023-04-23 15:07:57 --> Security Class Initialized
DEBUG - 2023-04-23 15:07:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-23 15:07:57 --> Input Class Initialized
INFO - 2023-04-23 15:07:57 --> Language Class Initialized
INFO - 2023-04-23 15:07:57 --> Loader Class Initialized
INFO - 2023-04-23 15:07:57 --> Helper loaded: url_helper
INFO - 2023-04-23 15:07:57 --> Helper loaded: file_helper
INFO - 2023-04-23 15:07:57 --> Helper loaded: html_helper
INFO - 2023-04-23 15:07:57 --> Helper loaded: text_helper
INFO - 2023-04-23 15:07:57 --> Helper loaded: form_helper
INFO - 2023-04-23 15:07:57 --> Helper loaded: lang_helper
INFO - 2023-04-23 15:07:57 --> Helper loaded: security_helper
INFO - 2023-04-23 15:07:57 --> Helper loaded: cookie_helper
INFO - 2023-04-23 15:07:57 --> Database Driver Class Initialized
INFO - 2023-04-23 15:07:57 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-23 15:07:57 --> Parser Class Initialized
INFO - 2023-04-23 15:07:57 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-23 15:07:57 --> Pagination Class Initialized
INFO - 2023-04-23 15:07:57 --> Form Validation Class Initialized
INFO - 2023-04-23 15:07:57 --> Controller Class Initialized
DEBUG - 2023-04-23 15:07:57 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-04-23 15:07:57 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-23 15:07:57 --> Model Class Initialized
DEBUG - 2023-04-23 15:07:57 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-23 15:07:57 --> Model Class Initialized
INFO - 2023-04-23 15:07:57 --> Final output sent to browser
DEBUG - 2023-04-23 15:07:57 --> Total execution time: 0.0313
ERROR - 2023-04-23 15:08:01 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-23 15:08:01 --> Config Class Initialized
INFO - 2023-04-23 15:08:01 --> Hooks Class Initialized
DEBUG - 2023-04-23 15:08:01 --> UTF-8 Support Enabled
INFO - 2023-04-23 15:08:01 --> Utf8 Class Initialized
INFO - 2023-04-23 15:08:01 --> URI Class Initialized
INFO - 2023-04-23 15:08:01 --> Router Class Initialized
INFO - 2023-04-23 15:08:01 --> Output Class Initialized
INFO - 2023-04-23 15:08:01 --> Security Class Initialized
DEBUG - 2023-04-23 15:08:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-23 15:08:01 --> Input Class Initialized
INFO - 2023-04-23 15:08:01 --> Language Class Initialized
INFO - 2023-04-23 15:08:01 --> Loader Class Initialized
INFO - 2023-04-23 15:08:01 --> Helper loaded: url_helper
INFO - 2023-04-23 15:08:01 --> Helper loaded: file_helper
INFO - 2023-04-23 15:08:01 --> Helper loaded: html_helper
INFO - 2023-04-23 15:08:01 --> Helper loaded: text_helper
INFO - 2023-04-23 15:08:01 --> Helper loaded: form_helper
INFO - 2023-04-23 15:08:01 --> Helper loaded: lang_helper
INFO - 2023-04-23 15:08:01 --> Helper loaded: security_helper
INFO - 2023-04-23 15:08:01 --> Helper loaded: cookie_helper
INFO - 2023-04-23 15:08:01 --> Database Driver Class Initialized
INFO - 2023-04-23 15:08:01 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-23 15:08:01 --> Parser Class Initialized
INFO - 2023-04-23 15:08:01 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-23 15:08:01 --> Pagination Class Initialized
INFO - 2023-04-23 15:08:01 --> Form Validation Class Initialized
INFO - 2023-04-23 15:08:01 --> Controller Class Initialized
DEBUG - 2023-04-23 15:08:01 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-04-23 15:08:01 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-23 15:08:01 --> Model Class Initialized
DEBUG - 2023-04-23 15:08:01 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-23 15:08:01 --> Model Class Initialized
INFO - 2023-04-23 15:08:01 --> Final output sent to browser
DEBUG - 2023-04-23 15:08:01 --> Total execution time: 0.0796
ERROR - 2023-04-23 15:08:32 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-23 15:08:32 --> Config Class Initialized
INFO - 2023-04-23 15:08:32 --> Hooks Class Initialized
DEBUG - 2023-04-23 15:08:32 --> UTF-8 Support Enabled
INFO - 2023-04-23 15:08:32 --> Utf8 Class Initialized
INFO - 2023-04-23 15:08:32 --> URI Class Initialized
INFO - 2023-04-23 15:08:32 --> Router Class Initialized
INFO - 2023-04-23 15:08:32 --> Output Class Initialized
INFO - 2023-04-23 15:08:32 --> Security Class Initialized
DEBUG - 2023-04-23 15:08:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-23 15:08:32 --> Input Class Initialized
INFO - 2023-04-23 15:08:32 --> Language Class Initialized
INFO - 2023-04-23 15:08:32 --> Loader Class Initialized
INFO - 2023-04-23 15:08:32 --> Helper loaded: url_helper
INFO - 2023-04-23 15:08:32 --> Helper loaded: file_helper
INFO - 2023-04-23 15:08:32 --> Helper loaded: html_helper
INFO - 2023-04-23 15:08:32 --> Helper loaded: text_helper
INFO - 2023-04-23 15:08:32 --> Helper loaded: form_helper
INFO - 2023-04-23 15:08:32 --> Helper loaded: lang_helper
INFO - 2023-04-23 15:08:32 --> Helper loaded: security_helper
INFO - 2023-04-23 15:08:32 --> Helper loaded: cookie_helper
INFO - 2023-04-23 15:08:32 --> Database Driver Class Initialized
INFO - 2023-04-23 15:08:32 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-23 15:08:32 --> Parser Class Initialized
INFO - 2023-04-23 15:08:32 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-23 15:08:32 --> Pagination Class Initialized
INFO - 2023-04-23 15:08:32 --> Form Validation Class Initialized
INFO - 2023-04-23 15:08:32 --> Controller Class Initialized
DEBUG - 2023-04-23 15:08:32 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-04-23 15:08:32 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-23 15:08:32 --> Model Class Initialized
DEBUG - 2023-04-23 15:08:32 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-23 15:08:32 --> Model Class Initialized
INFO - 2023-04-23 15:08:32 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/customer/edit_customer_form.php
DEBUG - 2023-04-23 15:08:32 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-04-23 15:08:32 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-04-23 15:08:32 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-04-23 15:08:32 --> Model Class Initialized
INFO - 2023-04-23 15:08:32 --> Model Class Initialized
INFO - 2023-04-23 15:08:32 --> Model Class Initialized
INFO - 2023-04-23 15:08:32 --> Model Class Initialized
INFO - 2023-04-23 15:08:33 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-04-23 15:08:33 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-04-23 15:08:33 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-04-23 15:08:33 --> Final output sent to browser
DEBUG - 2023-04-23 15:08:33 --> Total execution time: 0.1873
ERROR - 2023-04-23 15:08:49 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-23 15:08:49 --> Config Class Initialized
INFO - 2023-04-23 15:08:49 --> Hooks Class Initialized
DEBUG - 2023-04-23 15:08:49 --> UTF-8 Support Enabled
INFO - 2023-04-23 15:08:49 --> Utf8 Class Initialized
INFO - 2023-04-23 15:08:49 --> URI Class Initialized
INFO - 2023-04-23 15:08:49 --> Router Class Initialized
INFO - 2023-04-23 15:08:49 --> Output Class Initialized
INFO - 2023-04-23 15:08:49 --> Security Class Initialized
DEBUG - 2023-04-23 15:08:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-23 15:08:49 --> Input Class Initialized
INFO - 2023-04-23 15:08:49 --> Language Class Initialized
INFO - 2023-04-23 15:08:49 --> Loader Class Initialized
INFO - 2023-04-23 15:08:49 --> Helper loaded: url_helper
INFO - 2023-04-23 15:08:49 --> Helper loaded: file_helper
INFO - 2023-04-23 15:08:49 --> Helper loaded: html_helper
INFO - 2023-04-23 15:08:49 --> Helper loaded: text_helper
INFO - 2023-04-23 15:08:49 --> Helper loaded: form_helper
INFO - 2023-04-23 15:08:49 --> Helper loaded: lang_helper
INFO - 2023-04-23 15:08:49 --> Helper loaded: security_helper
INFO - 2023-04-23 15:08:49 --> Helper loaded: cookie_helper
INFO - 2023-04-23 15:08:49 --> Database Driver Class Initialized
INFO - 2023-04-23 15:08:49 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-23 15:08:49 --> Parser Class Initialized
INFO - 2023-04-23 15:08:49 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-23 15:08:49 --> Pagination Class Initialized
INFO - 2023-04-23 15:08:49 --> Form Validation Class Initialized
INFO - 2023-04-23 15:08:49 --> Controller Class Initialized
DEBUG - 2023-04-23 15:08:49 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-04-23 15:08:49 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-23 15:08:49 --> Model Class Initialized
DEBUG - 2023-04-23 15:08:49 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-23 15:08:49 --> Model Class Initialized
ERROR - 2023-04-23 15:08:49 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-23 15:08:49 --> Config Class Initialized
INFO - 2023-04-23 15:08:49 --> Hooks Class Initialized
DEBUG - 2023-04-23 15:08:49 --> UTF-8 Support Enabled
INFO - 2023-04-23 15:08:49 --> Utf8 Class Initialized
INFO - 2023-04-23 15:08:49 --> URI Class Initialized
INFO - 2023-04-23 15:08:49 --> Router Class Initialized
INFO - 2023-04-23 15:08:49 --> Output Class Initialized
INFO - 2023-04-23 15:08:49 --> Security Class Initialized
DEBUG - 2023-04-23 15:08:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-23 15:08:49 --> Input Class Initialized
INFO - 2023-04-23 15:08:49 --> Language Class Initialized
INFO - 2023-04-23 15:08:49 --> Loader Class Initialized
INFO - 2023-04-23 15:08:49 --> Helper loaded: url_helper
INFO - 2023-04-23 15:08:49 --> Helper loaded: file_helper
INFO - 2023-04-23 15:08:49 --> Helper loaded: html_helper
INFO - 2023-04-23 15:08:49 --> Helper loaded: text_helper
INFO - 2023-04-23 15:08:49 --> Helper loaded: form_helper
INFO - 2023-04-23 15:08:49 --> Helper loaded: lang_helper
INFO - 2023-04-23 15:08:49 --> Helper loaded: security_helper
INFO - 2023-04-23 15:08:49 --> Helper loaded: cookie_helper
INFO - 2023-04-23 15:08:49 --> Database Driver Class Initialized
INFO - 2023-04-23 15:08:49 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-23 15:08:49 --> Parser Class Initialized
INFO - 2023-04-23 15:08:49 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-23 15:08:49 --> Pagination Class Initialized
INFO - 2023-04-23 15:08:49 --> Form Validation Class Initialized
INFO - 2023-04-23 15:08:49 --> Controller Class Initialized
DEBUG - 2023-04-23 15:08:49 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-04-23 15:08:49 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-23 15:08:49 --> Model Class Initialized
DEBUG - 2023-04-23 15:08:49 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-23 15:08:49 --> Model Class Initialized
DEBUG - 2023-04-23 15:08:49 --> Lcustomer class already loaded. Second attempt ignored.
INFO - 2023-04-23 15:08:49 --> Model Class Initialized
INFO - 2023-04-23 15:08:49 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/customer/customer.php
DEBUG - 2023-04-23 15:08:49 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-04-23 15:08:49 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-04-23 15:08:49 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-04-23 15:08:49 --> Model Class Initialized
INFO - 2023-04-23 15:08:49 --> Model Class Initialized
INFO - 2023-04-23 15:08:49 --> Model Class Initialized
INFO - 2023-04-23 15:08:50 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-04-23 15:08:50 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-04-23 15:08:50 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-04-23 15:08:50 --> Final output sent to browser
DEBUG - 2023-04-23 15:08:50 --> Total execution time: 0.1332
ERROR - 2023-04-23 15:08:50 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-23 15:08:50 --> Config Class Initialized
INFO - 2023-04-23 15:08:50 --> Hooks Class Initialized
DEBUG - 2023-04-23 15:08:50 --> UTF-8 Support Enabled
INFO - 2023-04-23 15:08:50 --> Utf8 Class Initialized
INFO - 2023-04-23 15:08:50 --> URI Class Initialized
INFO - 2023-04-23 15:08:50 --> Router Class Initialized
INFO - 2023-04-23 15:08:50 --> Output Class Initialized
INFO - 2023-04-23 15:08:50 --> Security Class Initialized
DEBUG - 2023-04-23 15:08:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-23 15:08:50 --> Input Class Initialized
INFO - 2023-04-23 15:08:50 --> Language Class Initialized
INFO - 2023-04-23 15:08:50 --> Loader Class Initialized
INFO - 2023-04-23 15:08:50 --> Helper loaded: url_helper
INFO - 2023-04-23 15:08:50 --> Helper loaded: file_helper
INFO - 2023-04-23 15:08:50 --> Helper loaded: html_helper
INFO - 2023-04-23 15:08:50 --> Helper loaded: text_helper
INFO - 2023-04-23 15:08:50 --> Helper loaded: form_helper
INFO - 2023-04-23 15:08:50 --> Helper loaded: lang_helper
INFO - 2023-04-23 15:08:50 --> Helper loaded: security_helper
INFO - 2023-04-23 15:08:50 --> Helper loaded: cookie_helper
INFO - 2023-04-23 15:08:50 --> Database Driver Class Initialized
INFO - 2023-04-23 15:08:50 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-23 15:08:50 --> Parser Class Initialized
INFO - 2023-04-23 15:08:50 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-23 15:08:50 --> Pagination Class Initialized
INFO - 2023-04-23 15:08:50 --> Form Validation Class Initialized
INFO - 2023-04-23 15:08:50 --> Controller Class Initialized
DEBUG - 2023-04-23 15:08:50 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-04-23 15:08:50 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-23 15:08:50 --> Model Class Initialized
DEBUG - 2023-04-23 15:08:50 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-23 15:08:50 --> Model Class Initialized
INFO - 2023-04-23 15:08:50 --> Final output sent to browser
DEBUG - 2023-04-23 15:08:50 --> Total execution time: 0.0291
ERROR - 2023-04-23 15:09:04 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-23 15:09:04 --> Config Class Initialized
INFO - 2023-04-23 15:09:04 --> Hooks Class Initialized
DEBUG - 2023-04-23 15:09:04 --> UTF-8 Support Enabled
INFO - 2023-04-23 15:09:04 --> Utf8 Class Initialized
INFO - 2023-04-23 15:09:04 --> URI Class Initialized
INFO - 2023-04-23 15:09:04 --> Router Class Initialized
INFO - 2023-04-23 15:09:04 --> Output Class Initialized
INFO - 2023-04-23 15:09:04 --> Security Class Initialized
DEBUG - 2023-04-23 15:09:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-23 15:09:04 --> Input Class Initialized
INFO - 2023-04-23 15:09:04 --> Language Class Initialized
INFO - 2023-04-23 15:09:04 --> Loader Class Initialized
INFO - 2023-04-23 15:09:04 --> Helper loaded: url_helper
INFO - 2023-04-23 15:09:04 --> Helper loaded: file_helper
INFO - 2023-04-23 15:09:04 --> Helper loaded: html_helper
INFO - 2023-04-23 15:09:04 --> Helper loaded: text_helper
INFO - 2023-04-23 15:09:04 --> Helper loaded: form_helper
INFO - 2023-04-23 15:09:04 --> Helper loaded: lang_helper
INFO - 2023-04-23 15:09:04 --> Helper loaded: security_helper
INFO - 2023-04-23 15:09:04 --> Helper loaded: cookie_helper
INFO - 2023-04-23 15:09:04 --> Database Driver Class Initialized
INFO - 2023-04-23 15:09:04 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-23 15:09:04 --> Parser Class Initialized
INFO - 2023-04-23 15:09:04 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-23 15:09:04 --> Pagination Class Initialized
INFO - 2023-04-23 15:09:04 --> Form Validation Class Initialized
INFO - 2023-04-23 15:09:04 --> Controller Class Initialized
DEBUG - 2023-04-23 15:09:04 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-04-23 15:09:04 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-23 15:09:04 --> Model Class Initialized
DEBUG - 2023-04-23 15:09:04 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-23 15:09:04 --> Model Class Initialized
INFO - 2023-04-23 15:09:04 --> Final output sent to browser
DEBUG - 2023-04-23 15:09:04 --> Total execution time: 0.0839
ERROR - 2023-04-23 15:09:05 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-23 15:09:05 --> Config Class Initialized
INFO - 2023-04-23 15:09:05 --> Hooks Class Initialized
DEBUG - 2023-04-23 15:09:05 --> UTF-8 Support Enabled
INFO - 2023-04-23 15:09:05 --> Utf8 Class Initialized
INFO - 2023-04-23 15:09:05 --> URI Class Initialized
INFO - 2023-04-23 15:09:05 --> Router Class Initialized
INFO - 2023-04-23 15:09:05 --> Output Class Initialized
INFO - 2023-04-23 15:09:05 --> Security Class Initialized
DEBUG - 2023-04-23 15:09:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-23 15:09:05 --> Input Class Initialized
INFO - 2023-04-23 15:09:05 --> Language Class Initialized
INFO - 2023-04-23 15:09:05 --> Loader Class Initialized
INFO - 2023-04-23 15:09:05 --> Helper loaded: url_helper
INFO - 2023-04-23 15:09:05 --> Helper loaded: file_helper
INFO - 2023-04-23 15:09:05 --> Helper loaded: html_helper
INFO - 2023-04-23 15:09:05 --> Helper loaded: text_helper
INFO - 2023-04-23 15:09:05 --> Helper loaded: form_helper
INFO - 2023-04-23 15:09:05 --> Helper loaded: lang_helper
INFO - 2023-04-23 15:09:05 --> Helper loaded: security_helper
INFO - 2023-04-23 15:09:05 --> Helper loaded: cookie_helper
INFO - 2023-04-23 15:09:05 --> Database Driver Class Initialized
INFO - 2023-04-23 15:09:05 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-23 15:09:05 --> Parser Class Initialized
INFO - 2023-04-23 15:09:05 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-23 15:09:05 --> Pagination Class Initialized
INFO - 2023-04-23 15:09:05 --> Form Validation Class Initialized
INFO - 2023-04-23 15:09:05 --> Controller Class Initialized
DEBUG - 2023-04-23 15:09:05 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-04-23 15:09:05 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-23 15:09:05 --> Model Class Initialized
DEBUG - 2023-04-23 15:09:05 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-23 15:09:05 --> Model Class Initialized
INFO - 2023-04-23 15:09:05 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/customer/edit_customer_form.php
DEBUG - 2023-04-23 15:09:05 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-04-23 15:09:05 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-04-23 15:09:05 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-04-23 15:09:05 --> Model Class Initialized
INFO - 2023-04-23 15:09:05 --> Model Class Initialized
INFO - 2023-04-23 15:09:05 --> Model Class Initialized
INFO - 2023-04-23 15:09:05 --> Model Class Initialized
INFO - 2023-04-23 15:09:05 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-04-23 15:09:05 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-04-23 15:09:05 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-04-23 15:09:05 --> Final output sent to browser
DEBUG - 2023-04-23 15:09:05 --> Total execution time: 0.1704
ERROR - 2023-04-23 15:09:37 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-23 15:09:37 --> Config Class Initialized
INFO - 2023-04-23 15:09:37 --> Hooks Class Initialized
DEBUG - 2023-04-23 15:09:37 --> UTF-8 Support Enabled
INFO - 2023-04-23 15:09:37 --> Utf8 Class Initialized
INFO - 2023-04-23 15:09:37 --> URI Class Initialized
INFO - 2023-04-23 15:09:37 --> Router Class Initialized
INFO - 2023-04-23 15:09:37 --> Output Class Initialized
INFO - 2023-04-23 15:09:37 --> Security Class Initialized
DEBUG - 2023-04-23 15:09:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-23 15:09:37 --> Input Class Initialized
INFO - 2023-04-23 15:09:37 --> Language Class Initialized
INFO - 2023-04-23 15:09:37 --> Loader Class Initialized
INFO - 2023-04-23 15:09:37 --> Helper loaded: url_helper
INFO - 2023-04-23 15:09:37 --> Helper loaded: file_helper
INFO - 2023-04-23 15:09:37 --> Helper loaded: html_helper
INFO - 2023-04-23 15:09:37 --> Helper loaded: text_helper
INFO - 2023-04-23 15:09:37 --> Helper loaded: form_helper
INFO - 2023-04-23 15:09:37 --> Helper loaded: lang_helper
INFO - 2023-04-23 15:09:37 --> Helper loaded: security_helper
INFO - 2023-04-23 15:09:37 --> Helper loaded: cookie_helper
INFO - 2023-04-23 15:09:37 --> Database Driver Class Initialized
INFO - 2023-04-23 15:09:38 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-23 15:09:38 --> Parser Class Initialized
INFO - 2023-04-23 15:09:38 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-23 15:09:38 --> Pagination Class Initialized
INFO - 2023-04-23 15:09:38 --> Form Validation Class Initialized
INFO - 2023-04-23 15:09:38 --> Controller Class Initialized
DEBUG - 2023-04-23 15:09:38 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-04-23 15:09:38 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-23 15:09:38 --> Model Class Initialized
DEBUG - 2023-04-23 15:09:38 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-23 15:09:38 --> Model Class Initialized
ERROR - 2023-04-23 15:09:38 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-23 15:09:38 --> Config Class Initialized
INFO - 2023-04-23 15:09:38 --> Hooks Class Initialized
DEBUG - 2023-04-23 15:09:38 --> UTF-8 Support Enabled
INFO - 2023-04-23 15:09:38 --> Utf8 Class Initialized
INFO - 2023-04-23 15:09:38 --> URI Class Initialized
INFO - 2023-04-23 15:09:38 --> Router Class Initialized
INFO - 2023-04-23 15:09:38 --> Output Class Initialized
INFO - 2023-04-23 15:09:38 --> Security Class Initialized
DEBUG - 2023-04-23 15:09:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-23 15:09:38 --> Input Class Initialized
INFO - 2023-04-23 15:09:38 --> Language Class Initialized
INFO - 2023-04-23 15:09:38 --> Loader Class Initialized
INFO - 2023-04-23 15:09:38 --> Helper loaded: url_helper
INFO - 2023-04-23 15:09:38 --> Helper loaded: file_helper
INFO - 2023-04-23 15:09:38 --> Helper loaded: html_helper
INFO - 2023-04-23 15:09:38 --> Helper loaded: text_helper
INFO - 2023-04-23 15:09:38 --> Helper loaded: form_helper
INFO - 2023-04-23 15:09:38 --> Helper loaded: lang_helper
INFO - 2023-04-23 15:09:38 --> Helper loaded: security_helper
INFO - 2023-04-23 15:09:38 --> Helper loaded: cookie_helper
INFO - 2023-04-23 15:09:38 --> Database Driver Class Initialized
INFO - 2023-04-23 15:09:38 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-23 15:09:38 --> Parser Class Initialized
INFO - 2023-04-23 15:09:38 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-23 15:09:38 --> Pagination Class Initialized
INFO - 2023-04-23 15:09:38 --> Form Validation Class Initialized
INFO - 2023-04-23 15:09:38 --> Controller Class Initialized
DEBUG - 2023-04-23 15:09:38 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-04-23 15:09:38 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-23 15:09:38 --> Model Class Initialized
DEBUG - 2023-04-23 15:09:38 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-23 15:09:38 --> Model Class Initialized
DEBUG - 2023-04-23 15:09:38 --> Lcustomer class already loaded. Second attempt ignored.
INFO - 2023-04-23 15:09:38 --> Model Class Initialized
INFO - 2023-04-23 15:09:38 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/customer/customer.php
DEBUG - 2023-04-23 15:09:38 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-04-23 15:09:38 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-04-23 15:09:38 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-04-23 15:09:38 --> Model Class Initialized
INFO - 2023-04-23 15:09:38 --> Model Class Initialized
INFO - 2023-04-23 15:09:38 --> Model Class Initialized
INFO - 2023-04-23 15:09:39 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-04-23 15:09:39 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-04-23 15:09:39 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-04-23 15:09:39 --> Final output sent to browser
DEBUG - 2023-04-23 15:09:39 --> Total execution time: 0.5422
ERROR - 2023-04-23 15:09:39 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-23 15:09:39 --> Config Class Initialized
INFO - 2023-04-23 15:09:39 --> Hooks Class Initialized
DEBUG - 2023-04-23 15:09:39 --> UTF-8 Support Enabled
INFO - 2023-04-23 15:09:39 --> Utf8 Class Initialized
INFO - 2023-04-23 15:09:39 --> URI Class Initialized
INFO - 2023-04-23 15:09:39 --> Router Class Initialized
INFO - 2023-04-23 15:09:39 --> Output Class Initialized
INFO - 2023-04-23 15:09:39 --> Security Class Initialized
DEBUG - 2023-04-23 15:09:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-23 15:09:39 --> Input Class Initialized
INFO - 2023-04-23 15:09:39 --> Language Class Initialized
INFO - 2023-04-23 15:09:39 --> Loader Class Initialized
INFO - 2023-04-23 15:09:39 --> Helper loaded: url_helper
INFO - 2023-04-23 15:09:39 --> Helper loaded: file_helper
INFO - 2023-04-23 15:09:39 --> Helper loaded: html_helper
INFO - 2023-04-23 15:09:39 --> Helper loaded: text_helper
INFO - 2023-04-23 15:09:39 --> Helper loaded: form_helper
INFO - 2023-04-23 15:09:39 --> Helper loaded: lang_helper
INFO - 2023-04-23 15:09:39 --> Helper loaded: security_helper
INFO - 2023-04-23 15:09:39 --> Helper loaded: cookie_helper
INFO - 2023-04-23 15:09:39 --> Database Driver Class Initialized
INFO - 2023-04-23 15:09:39 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-23 15:09:39 --> Parser Class Initialized
INFO - 2023-04-23 15:09:39 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-23 15:09:39 --> Pagination Class Initialized
INFO - 2023-04-23 15:09:39 --> Form Validation Class Initialized
INFO - 2023-04-23 15:09:39 --> Controller Class Initialized
DEBUG - 2023-04-23 15:09:39 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-04-23 15:09:39 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-23 15:09:39 --> Model Class Initialized
DEBUG - 2023-04-23 15:09:39 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-23 15:09:39 --> Model Class Initialized
INFO - 2023-04-23 15:09:39 --> Final output sent to browser
DEBUG - 2023-04-23 15:09:39 --> Total execution time: 0.0287
ERROR - 2023-04-23 15:09:47 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-23 15:09:47 --> Config Class Initialized
INFO - 2023-04-23 15:09:47 --> Hooks Class Initialized
DEBUG - 2023-04-23 15:09:47 --> UTF-8 Support Enabled
INFO - 2023-04-23 15:09:47 --> Utf8 Class Initialized
INFO - 2023-04-23 15:09:47 --> URI Class Initialized
INFO - 2023-04-23 15:09:47 --> Router Class Initialized
INFO - 2023-04-23 15:09:47 --> Output Class Initialized
INFO - 2023-04-23 15:09:47 --> Security Class Initialized
DEBUG - 2023-04-23 15:09:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-23 15:09:47 --> Input Class Initialized
INFO - 2023-04-23 15:09:47 --> Language Class Initialized
INFO - 2023-04-23 15:09:47 --> Loader Class Initialized
INFO - 2023-04-23 15:09:47 --> Helper loaded: url_helper
INFO - 2023-04-23 15:09:47 --> Helper loaded: file_helper
INFO - 2023-04-23 15:09:47 --> Helper loaded: html_helper
INFO - 2023-04-23 15:09:47 --> Helper loaded: text_helper
INFO - 2023-04-23 15:09:47 --> Helper loaded: form_helper
INFO - 2023-04-23 15:09:47 --> Helper loaded: lang_helper
INFO - 2023-04-23 15:09:47 --> Helper loaded: security_helper
INFO - 2023-04-23 15:09:47 --> Helper loaded: cookie_helper
INFO - 2023-04-23 15:09:47 --> Database Driver Class Initialized
INFO - 2023-04-23 15:09:47 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-23 15:09:47 --> Parser Class Initialized
INFO - 2023-04-23 15:09:47 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-23 15:09:47 --> Pagination Class Initialized
INFO - 2023-04-23 15:09:47 --> Form Validation Class Initialized
INFO - 2023-04-23 15:09:47 --> Controller Class Initialized
DEBUG - 2023-04-23 15:09:47 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-04-23 15:09:47 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-23 15:09:47 --> Model Class Initialized
DEBUG - 2023-04-23 15:09:47 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-23 15:09:47 --> Model Class Initialized
INFO - 2023-04-23 15:09:47 --> Final output sent to browser
DEBUG - 2023-04-23 15:09:47 --> Total execution time: 0.0784
ERROR - 2023-04-23 15:10:05 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-23 15:10:05 --> Config Class Initialized
INFO - 2023-04-23 15:10:05 --> Hooks Class Initialized
DEBUG - 2023-04-23 15:10:05 --> UTF-8 Support Enabled
INFO - 2023-04-23 15:10:05 --> Utf8 Class Initialized
INFO - 2023-04-23 15:10:05 --> URI Class Initialized
DEBUG - 2023-04-23 15:10:05 --> No URI present. Default controller set.
INFO - 2023-04-23 15:10:05 --> Router Class Initialized
INFO - 2023-04-23 15:10:05 --> Output Class Initialized
INFO - 2023-04-23 15:10:05 --> Security Class Initialized
DEBUG - 2023-04-23 15:10:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-23 15:10:05 --> Input Class Initialized
INFO - 2023-04-23 15:10:05 --> Language Class Initialized
INFO - 2023-04-23 15:10:05 --> Loader Class Initialized
INFO - 2023-04-23 15:10:05 --> Helper loaded: url_helper
INFO - 2023-04-23 15:10:05 --> Helper loaded: file_helper
INFO - 2023-04-23 15:10:05 --> Helper loaded: html_helper
INFO - 2023-04-23 15:10:05 --> Helper loaded: text_helper
INFO - 2023-04-23 15:10:05 --> Helper loaded: form_helper
INFO - 2023-04-23 15:10:05 --> Helper loaded: lang_helper
INFO - 2023-04-23 15:10:05 --> Helper loaded: security_helper
INFO - 2023-04-23 15:10:05 --> Helper loaded: cookie_helper
INFO - 2023-04-23 15:10:05 --> Database Driver Class Initialized
INFO - 2023-04-23 15:10:05 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-23 15:10:05 --> Parser Class Initialized
INFO - 2023-04-23 15:10:05 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-23 15:10:05 --> Pagination Class Initialized
INFO - 2023-04-23 15:10:05 --> Form Validation Class Initialized
INFO - 2023-04-23 15:10:05 --> Controller Class Initialized
INFO - 2023-04-23 15:10:05 --> Model Class Initialized
DEBUG - 2023-04-23 15:10:05 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-23 15:10:05 --> Model Class Initialized
DEBUG - 2023-04-23 15:10:05 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-23 15:10:05 --> Model Class Initialized
INFO - 2023-04-23 15:10:05 --> Model Class Initialized
INFO - 2023-04-23 15:10:05 --> Model Class Initialized
INFO - 2023-04-23 15:10:05 --> Model Class Initialized
DEBUG - 2023-04-23 15:10:05 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-04-23 15:10:05 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-23 15:10:05 --> Model Class Initialized
INFO - 2023-04-23 15:10:05 --> Model Class Initialized
INFO - 2023-04-23 15:10:05 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-04-23 15:10:05 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-04-23 15:10:05 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-04-23 15:10:05 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-04-23 15:10:05 --> Model Class Initialized
INFO - 2023-04-23 15:10:06 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-04-23 15:10:06 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-04-23 15:10:06 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-04-23 15:10:06 --> Final output sent to browser
DEBUG - 2023-04-23 15:10:06 --> Total execution time: 0.1684
ERROR - 2023-04-23 15:10:29 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-23 15:10:29 --> Config Class Initialized
INFO - 2023-04-23 15:10:29 --> Hooks Class Initialized
DEBUG - 2023-04-23 15:10:29 --> UTF-8 Support Enabled
INFO - 2023-04-23 15:10:29 --> Utf8 Class Initialized
INFO - 2023-04-23 15:10:29 --> URI Class Initialized
INFO - 2023-04-23 15:10:29 --> Router Class Initialized
INFO - 2023-04-23 15:10:29 --> Output Class Initialized
INFO - 2023-04-23 15:10:29 --> Security Class Initialized
DEBUG - 2023-04-23 15:10:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-23 15:10:29 --> Input Class Initialized
INFO - 2023-04-23 15:10:29 --> Language Class Initialized
INFO - 2023-04-23 15:10:29 --> Loader Class Initialized
INFO - 2023-04-23 15:10:29 --> Helper loaded: url_helper
INFO - 2023-04-23 15:10:29 --> Helper loaded: file_helper
INFO - 2023-04-23 15:10:29 --> Helper loaded: html_helper
INFO - 2023-04-23 15:10:29 --> Helper loaded: text_helper
INFO - 2023-04-23 15:10:29 --> Helper loaded: form_helper
INFO - 2023-04-23 15:10:29 --> Helper loaded: lang_helper
INFO - 2023-04-23 15:10:29 --> Helper loaded: security_helper
INFO - 2023-04-23 15:10:29 --> Helper loaded: cookie_helper
INFO - 2023-04-23 15:10:29 --> Database Driver Class Initialized
INFO - 2023-04-23 15:10:29 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-23 15:10:29 --> Parser Class Initialized
INFO - 2023-04-23 15:10:29 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-23 15:10:29 --> Pagination Class Initialized
INFO - 2023-04-23 15:10:29 --> Form Validation Class Initialized
INFO - 2023-04-23 15:10:29 --> Controller Class Initialized
INFO - 2023-04-23 15:10:29 --> Model Class Initialized
DEBUG - 2023-04-23 15:10:29 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-04-23 15:10:29 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-23 15:10:29 --> Model Class Initialized
DEBUG - 2023-04-23 15:10:29 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-23 15:10:29 --> Model Class Initialized
INFO - 2023-04-23 15:10:29 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice.php
DEBUG - 2023-04-23 15:10:29 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-04-23 15:10:29 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-04-23 15:10:29 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-04-23 15:10:29 --> Model Class Initialized
INFO - 2023-04-23 15:10:29 --> Model Class Initialized
INFO - 2023-04-23 15:10:29 --> Model Class Initialized
INFO - 2023-04-23 15:10:29 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-04-23 15:10:29 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-04-23 15:10:29 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-04-23 15:10:29 --> Final output sent to browser
DEBUG - 2023-04-23 15:10:29 --> Total execution time: 0.1476
ERROR - 2023-04-23 15:10:30 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-23 15:10:30 --> Config Class Initialized
INFO - 2023-04-23 15:10:30 --> Hooks Class Initialized
DEBUG - 2023-04-23 15:10:30 --> UTF-8 Support Enabled
INFO - 2023-04-23 15:10:30 --> Utf8 Class Initialized
INFO - 2023-04-23 15:10:30 --> URI Class Initialized
INFO - 2023-04-23 15:10:30 --> Router Class Initialized
INFO - 2023-04-23 15:10:30 --> Output Class Initialized
INFO - 2023-04-23 15:10:30 --> Security Class Initialized
DEBUG - 2023-04-23 15:10:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-23 15:10:30 --> Input Class Initialized
INFO - 2023-04-23 15:10:30 --> Language Class Initialized
INFO - 2023-04-23 15:10:30 --> Loader Class Initialized
INFO - 2023-04-23 15:10:30 --> Helper loaded: url_helper
INFO - 2023-04-23 15:10:30 --> Helper loaded: file_helper
INFO - 2023-04-23 15:10:30 --> Helper loaded: html_helper
INFO - 2023-04-23 15:10:30 --> Helper loaded: text_helper
INFO - 2023-04-23 15:10:30 --> Helper loaded: form_helper
INFO - 2023-04-23 15:10:30 --> Helper loaded: lang_helper
INFO - 2023-04-23 15:10:30 --> Helper loaded: security_helper
INFO - 2023-04-23 15:10:30 --> Helper loaded: cookie_helper
INFO - 2023-04-23 15:10:30 --> Database Driver Class Initialized
INFO - 2023-04-23 15:10:30 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-23 15:10:30 --> Parser Class Initialized
INFO - 2023-04-23 15:10:30 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-23 15:10:30 --> Pagination Class Initialized
INFO - 2023-04-23 15:10:30 --> Form Validation Class Initialized
INFO - 2023-04-23 15:10:30 --> Controller Class Initialized
INFO - 2023-04-23 15:10:30 --> Model Class Initialized
DEBUG - 2023-04-23 15:10:30 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-04-23 15:10:30 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-23 15:10:30 --> Model Class Initialized
DEBUG - 2023-04-23 15:10:30 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-23 15:10:30 --> Model Class Initialized
INFO - 2023-04-23 15:10:30 --> Final output sent to browser
DEBUG - 2023-04-23 15:10:30 --> Total execution time: 0.0547
ERROR - 2023-04-23 15:10:34 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-23 15:10:34 --> Config Class Initialized
INFO - 2023-04-23 15:10:34 --> Hooks Class Initialized
DEBUG - 2023-04-23 15:10:34 --> UTF-8 Support Enabled
INFO - 2023-04-23 15:10:34 --> Utf8 Class Initialized
INFO - 2023-04-23 15:10:34 --> URI Class Initialized
INFO - 2023-04-23 15:10:34 --> Router Class Initialized
INFO - 2023-04-23 15:10:34 --> Output Class Initialized
INFO - 2023-04-23 15:10:34 --> Security Class Initialized
DEBUG - 2023-04-23 15:10:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-23 15:10:34 --> Input Class Initialized
INFO - 2023-04-23 15:10:34 --> Language Class Initialized
INFO - 2023-04-23 15:10:34 --> Loader Class Initialized
INFO - 2023-04-23 15:10:34 --> Helper loaded: url_helper
INFO - 2023-04-23 15:10:34 --> Helper loaded: file_helper
INFO - 2023-04-23 15:10:34 --> Helper loaded: html_helper
INFO - 2023-04-23 15:10:34 --> Helper loaded: text_helper
INFO - 2023-04-23 15:10:34 --> Helper loaded: form_helper
INFO - 2023-04-23 15:10:34 --> Helper loaded: lang_helper
INFO - 2023-04-23 15:10:34 --> Helper loaded: security_helper
INFO - 2023-04-23 15:10:34 --> Helper loaded: cookie_helper
INFO - 2023-04-23 15:10:34 --> Database Driver Class Initialized
INFO - 2023-04-23 15:10:34 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-23 15:10:34 --> Parser Class Initialized
INFO - 2023-04-23 15:10:34 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-23 15:10:34 --> Pagination Class Initialized
INFO - 2023-04-23 15:10:34 --> Form Validation Class Initialized
INFO - 2023-04-23 15:10:34 --> Controller Class Initialized
INFO - 2023-04-23 15:10:34 --> Model Class Initialized
DEBUG - 2023-04-23 15:10:34 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-04-23 15:10:34 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-23 15:10:34 --> Model Class Initialized
DEBUG - 2023-04-23 15:10:34 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-23 15:10:34 --> Model Class Initialized
INFO - 2023-04-23 15:10:34 --> Final output sent to browser
DEBUG - 2023-04-23 15:10:34 --> Total execution time: 0.0725
ERROR - 2023-04-23 15:10:48 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-23 15:10:48 --> Config Class Initialized
INFO - 2023-04-23 15:10:48 --> Hooks Class Initialized
DEBUG - 2023-04-23 15:10:48 --> UTF-8 Support Enabled
INFO - 2023-04-23 15:10:48 --> Utf8 Class Initialized
INFO - 2023-04-23 15:10:48 --> URI Class Initialized
DEBUG - 2023-04-23 15:10:48 --> No URI present. Default controller set.
INFO - 2023-04-23 15:10:48 --> Router Class Initialized
INFO - 2023-04-23 15:10:48 --> Output Class Initialized
INFO - 2023-04-23 15:10:48 --> Security Class Initialized
DEBUG - 2023-04-23 15:10:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-23 15:10:48 --> Input Class Initialized
INFO - 2023-04-23 15:10:48 --> Language Class Initialized
INFO - 2023-04-23 15:10:48 --> Loader Class Initialized
INFO - 2023-04-23 15:10:48 --> Helper loaded: url_helper
INFO - 2023-04-23 15:10:48 --> Helper loaded: file_helper
INFO - 2023-04-23 15:10:48 --> Helper loaded: html_helper
INFO - 2023-04-23 15:10:48 --> Helper loaded: text_helper
INFO - 2023-04-23 15:10:48 --> Helper loaded: form_helper
INFO - 2023-04-23 15:10:48 --> Helper loaded: lang_helper
INFO - 2023-04-23 15:10:48 --> Helper loaded: security_helper
INFO - 2023-04-23 15:10:48 --> Helper loaded: cookie_helper
INFO - 2023-04-23 15:10:48 --> Database Driver Class Initialized
INFO - 2023-04-23 15:10:48 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-23 15:10:48 --> Parser Class Initialized
INFO - 2023-04-23 15:10:48 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-23 15:10:48 --> Pagination Class Initialized
INFO - 2023-04-23 15:10:48 --> Form Validation Class Initialized
INFO - 2023-04-23 15:10:48 --> Controller Class Initialized
INFO - 2023-04-23 15:10:48 --> Model Class Initialized
DEBUG - 2023-04-23 15:10:48 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-23 15:10:48 --> Model Class Initialized
DEBUG - 2023-04-23 15:10:48 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-23 15:10:48 --> Model Class Initialized
INFO - 2023-04-23 15:10:48 --> Model Class Initialized
INFO - 2023-04-23 15:10:48 --> Model Class Initialized
INFO - 2023-04-23 15:10:48 --> Model Class Initialized
DEBUG - 2023-04-23 15:10:48 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-04-23 15:10:48 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-23 15:10:48 --> Model Class Initialized
INFO - 2023-04-23 15:10:48 --> Model Class Initialized
INFO - 2023-04-23 15:10:49 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-04-23 15:10:49 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-04-23 15:10:49 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-04-23 15:10:49 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-04-23 15:10:49 --> Model Class Initialized
INFO - 2023-04-23 15:10:49 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-04-23 15:10:49 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-04-23 15:10:49 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-04-23 15:10:49 --> Final output sent to browser
DEBUG - 2023-04-23 15:10:49 --> Total execution time: 0.1658
ERROR - 2023-04-23 15:11:28 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-23 15:11:28 --> Config Class Initialized
INFO - 2023-04-23 15:11:28 --> Hooks Class Initialized
DEBUG - 2023-04-23 15:11:28 --> UTF-8 Support Enabled
INFO - 2023-04-23 15:11:28 --> Utf8 Class Initialized
INFO - 2023-04-23 15:11:28 --> URI Class Initialized
DEBUG - 2023-04-23 15:11:28 --> No URI present. Default controller set.
INFO - 2023-04-23 15:11:28 --> Router Class Initialized
INFO - 2023-04-23 15:11:28 --> Output Class Initialized
INFO - 2023-04-23 15:11:28 --> Security Class Initialized
DEBUG - 2023-04-23 15:11:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-23 15:11:28 --> Input Class Initialized
INFO - 2023-04-23 15:11:28 --> Language Class Initialized
INFO - 2023-04-23 15:11:28 --> Loader Class Initialized
INFO - 2023-04-23 15:11:28 --> Helper loaded: url_helper
INFO - 2023-04-23 15:11:28 --> Helper loaded: file_helper
INFO - 2023-04-23 15:11:28 --> Helper loaded: html_helper
INFO - 2023-04-23 15:11:28 --> Helper loaded: text_helper
INFO - 2023-04-23 15:11:28 --> Helper loaded: form_helper
INFO - 2023-04-23 15:11:28 --> Helper loaded: lang_helper
INFO - 2023-04-23 15:11:28 --> Helper loaded: security_helper
INFO - 2023-04-23 15:11:28 --> Helper loaded: cookie_helper
INFO - 2023-04-23 15:11:28 --> Database Driver Class Initialized
INFO - 2023-04-23 15:11:28 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-23 15:11:28 --> Parser Class Initialized
INFO - 2023-04-23 15:11:28 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-23 15:11:28 --> Pagination Class Initialized
INFO - 2023-04-23 15:11:28 --> Form Validation Class Initialized
INFO - 2023-04-23 15:11:28 --> Controller Class Initialized
INFO - 2023-04-23 15:11:28 --> Model Class Initialized
DEBUG - 2023-04-23 15:11:28 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-23 15:11:28 --> Model Class Initialized
DEBUG - 2023-04-23 15:11:28 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-23 15:11:28 --> Model Class Initialized
INFO - 2023-04-23 15:11:28 --> Model Class Initialized
INFO - 2023-04-23 15:11:28 --> Model Class Initialized
INFO - 2023-04-23 15:11:28 --> Model Class Initialized
DEBUG - 2023-04-23 15:11:28 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-04-23 15:11:28 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-23 15:11:28 --> Model Class Initialized
INFO - 2023-04-23 15:11:28 --> Model Class Initialized
INFO - 2023-04-23 15:11:28 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-04-23 15:11:28 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-04-23 15:11:28 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-04-23 15:11:28 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-04-23 15:11:28 --> Model Class Initialized
INFO - 2023-04-23 15:11:28 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-04-23 15:11:28 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-04-23 15:11:28 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-04-23 15:11:28 --> Final output sent to browser
DEBUG - 2023-04-23 15:11:28 --> Total execution time: 0.1669
ERROR - 2023-04-23 15:11:40 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-23 15:11:40 --> Config Class Initialized
INFO - 2023-04-23 15:11:40 --> Hooks Class Initialized
DEBUG - 2023-04-23 15:11:40 --> UTF-8 Support Enabled
INFO - 2023-04-23 15:11:40 --> Utf8 Class Initialized
INFO - 2023-04-23 15:11:40 --> URI Class Initialized
INFO - 2023-04-23 15:11:40 --> Router Class Initialized
INFO - 2023-04-23 15:11:40 --> Output Class Initialized
INFO - 2023-04-23 15:11:40 --> Security Class Initialized
DEBUG - 2023-04-23 15:11:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-23 15:11:40 --> Input Class Initialized
INFO - 2023-04-23 15:11:40 --> Language Class Initialized
INFO - 2023-04-23 15:11:40 --> Loader Class Initialized
INFO - 2023-04-23 15:11:40 --> Helper loaded: url_helper
INFO - 2023-04-23 15:11:40 --> Helper loaded: file_helper
INFO - 2023-04-23 15:11:40 --> Helper loaded: html_helper
INFO - 2023-04-23 15:11:40 --> Helper loaded: text_helper
INFO - 2023-04-23 15:11:40 --> Helper loaded: form_helper
INFO - 2023-04-23 15:11:40 --> Helper loaded: lang_helper
INFO - 2023-04-23 15:11:40 --> Helper loaded: security_helper
INFO - 2023-04-23 15:11:40 --> Helper loaded: cookie_helper
INFO - 2023-04-23 15:11:40 --> Database Driver Class Initialized
INFO - 2023-04-23 15:11:40 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-23 15:11:40 --> Parser Class Initialized
INFO - 2023-04-23 15:11:40 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-23 15:11:40 --> Pagination Class Initialized
INFO - 2023-04-23 15:11:40 --> Form Validation Class Initialized
INFO - 2023-04-23 15:11:40 --> Controller Class Initialized
INFO - 2023-04-23 15:11:40 --> Model Class Initialized
DEBUG - 2023-04-23 15:11:40 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-04-23 15:11:40 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-23 15:11:40 --> Model Class Initialized
DEBUG - 2023-04-23 15:11:40 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-23 15:11:40 --> Model Class Initialized
INFO - 2023-04-23 15:11:40 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice.php
DEBUG - 2023-04-23 15:11:40 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-04-23 15:11:40 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-04-23 15:11:40 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-04-23 15:11:40 --> Model Class Initialized
INFO - 2023-04-23 15:11:41 --> Model Class Initialized
INFO - 2023-04-23 15:11:41 --> Model Class Initialized
INFO - 2023-04-23 15:11:41 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-04-23 15:11:41 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-04-23 15:11:41 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-04-23 15:11:41 --> Final output sent to browser
DEBUG - 2023-04-23 15:11:41 --> Total execution time: 0.1326
ERROR - 2023-04-23 15:11:41 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-23 15:11:41 --> Config Class Initialized
INFO - 2023-04-23 15:11:41 --> Hooks Class Initialized
DEBUG - 2023-04-23 15:11:41 --> UTF-8 Support Enabled
INFO - 2023-04-23 15:11:41 --> Utf8 Class Initialized
INFO - 2023-04-23 15:11:41 --> URI Class Initialized
INFO - 2023-04-23 15:11:41 --> Router Class Initialized
INFO - 2023-04-23 15:11:41 --> Output Class Initialized
INFO - 2023-04-23 15:11:41 --> Security Class Initialized
DEBUG - 2023-04-23 15:11:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-23 15:11:41 --> Input Class Initialized
INFO - 2023-04-23 15:11:41 --> Language Class Initialized
INFO - 2023-04-23 15:11:41 --> Loader Class Initialized
INFO - 2023-04-23 15:11:41 --> Helper loaded: url_helper
INFO - 2023-04-23 15:11:41 --> Helper loaded: file_helper
INFO - 2023-04-23 15:11:41 --> Helper loaded: html_helper
INFO - 2023-04-23 15:11:41 --> Helper loaded: text_helper
INFO - 2023-04-23 15:11:41 --> Helper loaded: form_helper
INFO - 2023-04-23 15:11:41 --> Helper loaded: lang_helper
INFO - 2023-04-23 15:11:41 --> Helper loaded: security_helper
INFO - 2023-04-23 15:11:41 --> Helper loaded: cookie_helper
INFO - 2023-04-23 15:11:41 --> Database Driver Class Initialized
INFO - 2023-04-23 15:11:41 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-23 15:11:41 --> Parser Class Initialized
INFO - 2023-04-23 15:11:41 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-23 15:11:41 --> Pagination Class Initialized
INFO - 2023-04-23 15:11:41 --> Form Validation Class Initialized
INFO - 2023-04-23 15:11:41 --> Controller Class Initialized
INFO - 2023-04-23 15:11:41 --> Model Class Initialized
DEBUG - 2023-04-23 15:11:41 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-04-23 15:11:41 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-23 15:11:41 --> Model Class Initialized
DEBUG - 2023-04-23 15:11:41 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-23 15:11:41 --> Model Class Initialized
INFO - 2023-04-23 15:11:41 --> Final output sent to browser
DEBUG - 2023-04-23 15:11:41 --> Total execution time: 0.0527
ERROR - 2023-04-23 15:11:46 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-23 15:11:46 --> Config Class Initialized
INFO - 2023-04-23 15:11:46 --> Hooks Class Initialized
DEBUG - 2023-04-23 15:11:46 --> UTF-8 Support Enabled
INFO - 2023-04-23 15:11:46 --> Utf8 Class Initialized
INFO - 2023-04-23 15:11:46 --> URI Class Initialized
INFO - 2023-04-23 15:11:46 --> Router Class Initialized
INFO - 2023-04-23 15:11:46 --> Output Class Initialized
INFO - 2023-04-23 15:11:46 --> Security Class Initialized
DEBUG - 2023-04-23 15:11:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-23 15:11:46 --> Input Class Initialized
INFO - 2023-04-23 15:11:46 --> Language Class Initialized
INFO - 2023-04-23 15:11:46 --> Loader Class Initialized
INFO - 2023-04-23 15:11:46 --> Helper loaded: url_helper
INFO - 2023-04-23 15:11:46 --> Helper loaded: file_helper
INFO - 2023-04-23 15:11:46 --> Helper loaded: html_helper
INFO - 2023-04-23 15:11:46 --> Helper loaded: text_helper
INFO - 2023-04-23 15:11:46 --> Helper loaded: form_helper
INFO - 2023-04-23 15:11:46 --> Helper loaded: lang_helper
INFO - 2023-04-23 15:11:46 --> Helper loaded: security_helper
INFO - 2023-04-23 15:11:46 --> Helper loaded: cookie_helper
INFO - 2023-04-23 15:11:46 --> Database Driver Class Initialized
INFO - 2023-04-23 15:11:46 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-23 15:11:46 --> Parser Class Initialized
INFO - 2023-04-23 15:11:46 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-23 15:11:46 --> Pagination Class Initialized
INFO - 2023-04-23 15:11:46 --> Form Validation Class Initialized
INFO - 2023-04-23 15:11:46 --> Controller Class Initialized
INFO - 2023-04-23 15:11:46 --> Model Class Initialized
DEBUG - 2023-04-23 15:11:46 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-04-23 15:11:46 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-23 15:11:46 --> Model Class Initialized
DEBUG - 2023-04-23 15:11:46 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-23 15:11:46 --> Model Class Initialized
INFO - 2023-04-23 15:11:46 --> Final output sent to browser
DEBUG - 2023-04-23 15:11:46 --> Total execution time: 0.0744
ERROR - 2023-04-23 16:16:46 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-23 16:16:46 --> Config Class Initialized
INFO - 2023-04-23 16:16:46 --> Hooks Class Initialized
DEBUG - 2023-04-23 16:16:46 --> UTF-8 Support Enabled
INFO - 2023-04-23 16:16:46 --> Utf8 Class Initialized
INFO - 2023-04-23 16:16:46 --> URI Class Initialized
INFO - 2023-04-23 16:16:46 --> Router Class Initialized
INFO - 2023-04-23 16:16:46 --> Output Class Initialized
INFO - 2023-04-23 16:16:46 --> Security Class Initialized
DEBUG - 2023-04-23 16:16:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-23 16:16:46 --> Input Class Initialized
INFO - 2023-04-23 16:16:46 --> Language Class Initialized
INFO - 2023-04-23 16:16:46 --> Loader Class Initialized
INFO - 2023-04-23 16:16:46 --> Helper loaded: url_helper
INFO - 2023-04-23 16:16:46 --> Helper loaded: file_helper
INFO - 2023-04-23 16:16:46 --> Helper loaded: html_helper
INFO - 2023-04-23 16:16:46 --> Helper loaded: text_helper
INFO - 2023-04-23 16:16:46 --> Helper loaded: form_helper
INFO - 2023-04-23 16:16:46 --> Helper loaded: lang_helper
INFO - 2023-04-23 16:16:46 --> Helper loaded: security_helper
INFO - 2023-04-23 16:16:46 --> Helper loaded: cookie_helper
INFO - 2023-04-23 16:16:46 --> Database Driver Class Initialized
INFO - 2023-04-23 16:16:46 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-23 16:16:46 --> Parser Class Initialized
INFO - 2023-04-23 16:16:46 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-23 16:16:46 --> Pagination Class Initialized
INFO - 2023-04-23 16:16:46 --> Form Validation Class Initialized
INFO - 2023-04-23 16:16:46 --> Controller Class Initialized
INFO - 2023-04-23 16:16:46 --> Model Class Initialized
DEBUG - 2023-04-23 16:16:46 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-04-23 16:16:46 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-23 16:16:46 --> Model Class Initialized
DEBUG - 2023-04-23 16:16:46 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-23 16:16:46 --> Model Class Initialized
INFO - 2023-04-23 16:16:46 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice.php
DEBUG - 2023-04-23 16:16:46 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-04-23 16:16:46 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-04-23 16:16:46 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-04-23 16:16:46 --> Model Class Initialized
INFO - 2023-04-23 16:16:46 --> Model Class Initialized
INFO - 2023-04-23 16:16:46 --> Model Class Initialized
INFO - 2023-04-23 16:16:46 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-04-23 16:16:46 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-04-23 16:16:46 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-04-23 16:16:46 --> Final output sent to browser
DEBUG - 2023-04-23 16:16:46 --> Total execution time: 0.1690
ERROR - 2023-04-23 16:16:47 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-23 16:16:47 --> Config Class Initialized
INFO - 2023-04-23 16:16:47 --> Hooks Class Initialized
DEBUG - 2023-04-23 16:16:47 --> UTF-8 Support Enabled
INFO - 2023-04-23 16:16:47 --> Utf8 Class Initialized
INFO - 2023-04-23 16:16:47 --> URI Class Initialized
INFO - 2023-04-23 16:16:47 --> Router Class Initialized
INFO - 2023-04-23 16:16:47 --> Output Class Initialized
INFO - 2023-04-23 16:16:47 --> Security Class Initialized
DEBUG - 2023-04-23 16:16:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-23 16:16:47 --> Input Class Initialized
INFO - 2023-04-23 16:16:47 --> Language Class Initialized
INFO - 2023-04-23 16:16:47 --> Loader Class Initialized
INFO - 2023-04-23 16:16:47 --> Helper loaded: url_helper
INFO - 2023-04-23 16:16:47 --> Helper loaded: file_helper
INFO - 2023-04-23 16:16:47 --> Helper loaded: html_helper
INFO - 2023-04-23 16:16:47 --> Helper loaded: text_helper
INFO - 2023-04-23 16:16:47 --> Helper loaded: form_helper
INFO - 2023-04-23 16:16:47 --> Helper loaded: lang_helper
INFO - 2023-04-23 16:16:47 --> Helper loaded: security_helper
INFO - 2023-04-23 16:16:47 --> Helper loaded: cookie_helper
INFO - 2023-04-23 16:16:47 --> Database Driver Class Initialized
INFO - 2023-04-23 16:16:47 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-23 16:16:47 --> Parser Class Initialized
INFO - 2023-04-23 16:16:47 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-23 16:16:47 --> Pagination Class Initialized
INFO - 2023-04-23 16:16:47 --> Form Validation Class Initialized
INFO - 2023-04-23 16:16:47 --> Controller Class Initialized
INFO - 2023-04-23 16:16:47 --> Model Class Initialized
DEBUG - 2023-04-23 16:16:47 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-04-23 16:16:47 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-23 16:16:47 --> Model Class Initialized
DEBUG - 2023-04-23 16:16:47 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-23 16:16:47 --> Model Class Initialized
INFO - 2023-04-23 16:16:47 --> Final output sent to browser
DEBUG - 2023-04-23 16:16:47 --> Total execution time: 0.0572
ERROR - 2023-04-23 16:16:57 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-23 16:16:57 --> Config Class Initialized
INFO - 2023-04-23 16:16:57 --> Hooks Class Initialized
DEBUG - 2023-04-23 16:16:57 --> UTF-8 Support Enabled
INFO - 2023-04-23 16:16:57 --> Utf8 Class Initialized
INFO - 2023-04-23 16:16:57 --> URI Class Initialized
INFO - 2023-04-23 16:16:57 --> Router Class Initialized
INFO - 2023-04-23 16:16:57 --> Output Class Initialized
INFO - 2023-04-23 16:16:57 --> Security Class Initialized
DEBUG - 2023-04-23 16:16:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-23 16:16:57 --> Input Class Initialized
INFO - 2023-04-23 16:16:57 --> Language Class Initialized
INFO - 2023-04-23 16:16:57 --> Loader Class Initialized
INFO - 2023-04-23 16:16:57 --> Helper loaded: url_helper
INFO - 2023-04-23 16:16:57 --> Helper loaded: file_helper
INFO - 2023-04-23 16:16:57 --> Helper loaded: html_helper
INFO - 2023-04-23 16:16:57 --> Helper loaded: text_helper
INFO - 2023-04-23 16:16:57 --> Helper loaded: form_helper
INFO - 2023-04-23 16:16:57 --> Helper loaded: lang_helper
INFO - 2023-04-23 16:16:57 --> Helper loaded: security_helper
INFO - 2023-04-23 16:16:57 --> Helper loaded: cookie_helper
INFO - 2023-04-23 16:16:57 --> Database Driver Class Initialized
INFO - 2023-04-23 16:16:57 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-23 16:16:57 --> Parser Class Initialized
INFO - 2023-04-23 16:16:57 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-23 16:16:57 --> Pagination Class Initialized
INFO - 2023-04-23 16:16:57 --> Form Validation Class Initialized
INFO - 2023-04-23 16:16:57 --> Controller Class Initialized
INFO - 2023-04-23 16:16:57 --> Model Class Initialized
INFO - 2023-04-23 16:16:57 --> Model Class Initialized
INFO - 2023-04-23 16:16:57 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/purchase/purchase.php
DEBUG - 2023-04-23 16:16:57 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-04-23 16:16:57 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-04-23 16:16:57 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-04-23 16:16:57 --> Model Class Initialized
INFO - 2023-04-23 16:16:57 --> Model Class Initialized
INFO - 2023-04-23 16:16:57 --> Model Class Initialized
INFO - 2023-04-23 16:16:57 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-04-23 16:16:57 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-04-23 16:16:57 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-04-23 16:16:57 --> Final output sent to browser
DEBUG - 2023-04-23 16:16:57 --> Total execution time: 0.1588
ERROR - 2023-04-23 16:16:58 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-23 16:16:58 --> Config Class Initialized
INFO - 2023-04-23 16:16:58 --> Hooks Class Initialized
DEBUG - 2023-04-23 16:16:58 --> UTF-8 Support Enabled
INFO - 2023-04-23 16:16:58 --> Utf8 Class Initialized
INFO - 2023-04-23 16:16:58 --> URI Class Initialized
INFO - 2023-04-23 16:16:58 --> Router Class Initialized
INFO - 2023-04-23 16:16:58 --> Output Class Initialized
INFO - 2023-04-23 16:16:58 --> Security Class Initialized
DEBUG - 2023-04-23 16:16:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-23 16:16:58 --> Input Class Initialized
INFO - 2023-04-23 16:16:58 --> Language Class Initialized
INFO - 2023-04-23 16:16:58 --> Loader Class Initialized
INFO - 2023-04-23 16:16:58 --> Helper loaded: url_helper
INFO - 2023-04-23 16:16:58 --> Helper loaded: file_helper
INFO - 2023-04-23 16:16:58 --> Helper loaded: html_helper
INFO - 2023-04-23 16:16:58 --> Helper loaded: text_helper
INFO - 2023-04-23 16:16:58 --> Helper loaded: form_helper
INFO - 2023-04-23 16:16:58 --> Helper loaded: lang_helper
INFO - 2023-04-23 16:16:58 --> Helper loaded: security_helper
INFO - 2023-04-23 16:16:58 --> Helper loaded: cookie_helper
INFO - 2023-04-23 16:16:58 --> Database Driver Class Initialized
INFO - 2023-04-23 16:16:58 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-23 16:16:58 --> Parser Class Initialized
INFO - 2023-04-23 16:16:58 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-23 16:16:58 --> Pagination Class Initialized
INFO - 2023-04-23 16:16:58 --> Form Validation Class Initialized
INFO - 2023-04-23 16:16:58 --> Controller Class Initialized
INFO - 2023-04-23 16:16:58 --> Model Class Initialized
INFO - 2023-04-23 16:16:58 --> Model Class Initialized
INFO - 2023-04-23 16:16:58 --> Final output sent to browser
DEBUG - 2023-04-23 16:16:58 --> Total execution time: 0.0480
ERROR - 2023-04-23 16:17:14 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-23 16:17:14 --> Config Class Initialized
INFO - 2023-04-23 16:17:14 --> Hooks Class Initialized
DEBUG - 2023-04-23 16:17:14 --> UTF-8 Support Enabled
INFO - 2023-04-23 16:17:14 --> Utf8 Class Initialized
INFO - 2023-04-23 16:17:14 --> URI Class Initialized
INFO - 2023-04-23 16:17:14 --> Router Class Initialized
INFO - 2023-04-23 16:17:14 --> Output Class Initialized
INFO - 2023-04-23 16:17:14 --> Security Class Initialized
DEBUG - 2023-04-23 16:17:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-23 16:17:14 --> Input Class Initialized
INFO - 2023-04-23 16:17:14 --> Language Class Initialized
INFO - 2023-04-23 16:17:14 --> Loader Class Initialized
INFO - 2023-04-23 16:17:14 --> Helper loaded: url_helper
INFO - 2023-04-23 16:17:14 --> Helper loaded: file_helper
INFO - 2023-04-23 16:17:14 --> Helper loaded: html_helper
INFO - 2023-04-23 16:17:14 --> Helper loaded: text_helper
INFO - 2023-04-23 16:17:14 --> Helper loaded: form_helper
INFO - 2023-04-23 16:17:14 --> Helper loaded: lang_helper
INFO - 2023-04-23 16:17:14 --> Helper loaded: security_helper
INFO - 2023-04-23 16:17:14 --> Helper loaded: cookie_helper
INFO - 2023-04-23 16:17:14 --> Database Driver Class Initialized
INFO - 2023-04-23 16:17:14 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-23 16:17:14 --> Parser Class Initialized
INFO - 2023-04-23 16:17:14 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-23 16:17:14 --> Pagination Class Initialized
INFO - 2023-04-23 16:17:14 --> Form Validation Class Initialized
INFO - 2023-04-23 16:17:14 --> Controller Class Initialized
DEBUG - 2023-04-23 16:17:14 --> Auth class already loaded. Second attempt ignored.
INFO - 2023-04-23 16:17:14 --> Model Class Initialized
INFO - 2023-04-23 16:17:14 --> Model Class Initialized
INFO - 2023-04-23 16:17:14 --> Model Class Initialized
INFO - 2023-04-23 16:17:14 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/product/product.php
DEBUG - 2023-04-23 16:17:14 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-04-23 16:17:14 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-04-23 16:17:14 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-04-23 16:17:14 --> Model Class Initialized
INFO - 2023-04-23 16:17:14 --> Model Class Initialized
INFO - 2023-04-23 16:17:15 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-04-23 16:17:15 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-04-23 16:17:15 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-04-23 16:17:15 --> Final output sent to browser
DEBUG - 2023-04-23 16:17:15 --> Total execution time: 0.1650
ERROR - 2023-04-23 16:17:16 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-23 16:17:16 --> Config Class Initialized
INFO - 2023-04-23 16:17:16 --> Hooks Class Initialized
DEBUG - 2023-04-23 16:17:16 --> UTF-8 Support Enabled
INFO - 2023-04-23 16:17:16 --> Utf8 Class Initialized
INFO - 2023-04-23 16:17:16 --> URI Class Initialized
INFO - 2023-04-23 16:17:16 --> Router Class Initialized
INFO - 2023-04-23 16:17:16 --> Output Class Initialized
INFO - 2023-04-23 16:17:16 --> Security Class Initialized
DEBUG - 2023-04-23 16:17:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-23 16:17:16 --> Input Class Initialized
INFO - 2023-04-23 16:17:16 --> Language Class Initialized
INFO - 2023-04-23 16:17:16 --> Loader Class Initialized
INFO - 2023-04-23 16:17:16 --> Helper loaded: url_helper
INFO - 2023-04-23 16:17:16 --> Helper loaded: file_helper
INFO - 2023-04-23 16:17:16 --> Helper loaded: html_helper
INFO - 2023-04-23 16:17:16 --> Helper loaded: text_helper
INFO - 2023-04-23 16:17:16 --> Helper loaded: form_helper
INFO - 2023-04-23 16:17:16 --> Helper loaded: lang_helper
INFO - 2023-04-23 16:17:16 --> Helper loaded: security_helper
INFO - 2023-04-23 16:17:16 --> Helper loaded: cookie_helper
INFO - 2023-04-23 16:17:16 --> Database Driver Class Initialized
INFO - 2023-04-23 16:17:16 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-23 16:17:16 --> Parser Class Initialized
INFO - 2023-04-23 16:17:16 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-23 16:17:16 --> Pagination Class Initialized
INFO - 2023-04-23 16:17:16 --> Form Validation Class Initialized
INFO - 2023-04-23 16:17:16 --> Controller Class Initialized
DEBUG - 2023-04-23 16:17:16 --> Auth class already loaded. Second attempt ignored.
INFO - 2023-04-23 16:17:16 --> Model Class Initialized
INFO - 2023-04-23 16:17:16 --> Model Class Initialized
INFO - 2023-04-23 16:17:16 --> Final output sent to browser
DEBUG - 2023-04-23 16:17:16 --> Total execution time: 0.0483
ERROR - 2023-04-23 16:17:28 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-23 16:17:28 --> Config Class Initialized
INFO - 2023-04-23 16:17:28 --> Hooks Class Initialized
DEBUG - 2023-04-23 16:17:28 --> UTF-8 Support Enabled
INFO - 2023-04-23 16:17:28 --> Utf8 Class Initialized
INFO - 2023-04-23 16:17:28 --> URI Class Initialized
INFO - 2023-04-23 16:17:28 --> Router Class Initialized
INFO - 2023-04-23 16:17:28 --> Output Class Initialized
INFO - 2023-04-23 16:17:28 --> Security Class Initialized
DEBUG - 2023-04-23 16:17:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-23 16:17:28 --> Input Class Initialized
INFO - 2023-04-23 16:17:28 --> Language Class Initialized
INFO - 2023-04-23 16:17:28 --> Loader Class Initialized
INFO - 2023-04-23 16:17:28 --> Helper loaded: url_helper
INFO - 2023-04-23 16:17:28 --> Helper loaded: file_helper
INFO - 2023-04-23 16:17:28 --> Helper loaded: html_helper
INFO - 2023-04-23 16:17:28 --> Helper loaded: text_helper
INFO - 2023-04-23 16:17:28 --> Helper loaded: form_helper
INFO - 2023-04-23 16:17:28 --> Helper loaded: lang_helper
INFO - 2023-04-23 16:17:28 --> Helper loaded: security_helper
INFO - 2023-04-23 16:17:28 --> Helper loaded: cookie_helper
INFO - 2023-04-23 16:17:28 --> Database Driver Class Initialized
INFO - 2023-04-23 16:17:28 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-23 16:17:28 --> Parser Class Initialized
INFO - 2023-04-23 16:17:28 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-23 16:17:28 --> Pagination Class Initialized
INFO - 2023-04-23 16:17:28 --> Form Validation Class Initialized
INFO - 2023-04-23 16:17:28 --> Controller Class Initialized
INFO - 2023-04-23 16:17:28 --> Model Class Initialized
INFO - 2023-04-23 16:17:28 --> Model Class Initialized
INFO - 2023-04-23 16:17:28 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/purchase/purchase.php
DEBUG - 2023-04-23 16:17:28 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-04-23 16:17:28 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-04-23 16:17:28 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-04-23 16:17:28 --> Model Class Initialized
INFO - 2023-04-23 16:17:28 --> Model Class Initialized
INFO - 2023-04-23 16:17:28 --> Model Class Initialized
INFO - 2023-04-23 16:17:28 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-04-23 16:17:28 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-04-23 16:17:28 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-04-23 16:17:28 --> Final output sent to browser
DEBUG - 2023-04-23 16:17:28 --> Total execution time: 0.1690
ERROR - 2023-04-23 16:17:29 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-23 16:17:29 --> Config Class Initialized
INFO - 2023-04-23 16:17:29 --> Hooks Class Initialized
DEBUG - 2023-04-23 16:17:29 --> UTF-8 Support Enabled
INFO - 2023-04-23 16:17:29 --> Utf8 Class Initialized
INFO - 2023-04-23 16:17:29 --> URI Class Initialized
INFO - 2023-04-23 16:17:29 --> Router Class Initialized
INFO - 2023-04-23 16:17:29 --> Output Class Initialized
INFO - 2023-04-23 16:17:29 --> Security Class Initialized
DEBUG - 2023-04-23 16:17:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-23 16:17:29 --> Input Class Initialized
INFO - 2023-04-23 16:17:29 --> Language Class Initialized
INFO - 2023-04-23 16:17:29 --> Loader Class Initialized
INFO - 2023-04-23 16:17:29 --> Helper loaded: url_helper
INFO - 2023-04-23 16:17:29 --> Helper loaded: file_helper
INFO - 2023-04-23 16:17:29 --> Helper loaded: html_helper
INFO - 2023-04-23 16:17:29 --> Helper loaded: text_helper
INFO - 2023-04-23 16:17:29 --> Helper loaded: form_helper
INFO - 2023-04-23 16:17:29 --> Helper loaded: lang_helper
INFO - 2023-04-23 16:17:29 --> Helper loaded: security_helper
INFO - 2023-04-23 16:17:29 --> Helper loaded: cookie_helper
INFO - 2023-04-23 16:17:29 --> Database Driver Class Initialized
INFO - 2023-04-23 16:17:29 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-23 16:17:29 --> Parser Class Initialized
INFO - 2023-04-23 16:17:29 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-23 16:17:29 --> Pagination Class Initialized
INFO - 2023-04-23 16:17:29 --> Form Validation Class Initialized
INFO - 2023-04-23 16:17:29 --> Controller Class Initialized
INFO - 2023-04-23 16:17:29 --> Model Class Initialized
INFO - 2023-04-23 16:17:29 --> Model Class Initialized
INFO - 2023-04-23 16:17:29 --> Final output sent to browser
DEBUG - 2023-04-23 16:17:29 --> Total execution time: 0.0473
ERROR - 2023-04-23 16:17:33 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-23 16:17:33 --> Config Class Initialized
INFO - 2023-04-23 16:17:33 --> Hooks Class Initialized
DEBUG - 2023-04-23 16:17:33 --> UTF-8 Support Enabled
INFO - 2023-04-23 16:17:33 --> Utf8 Class Initialized
INFO - 2023-04-23 16:17:33 --> URI Class Initialized
INFO - 2023-04-23 16:17:33 --> Router Class Initialized
INFO - 2023-04-23 16:17:33 --> Output Class Initialized
INFO - 2023-04-23 16:17:33 --> Security Class Initialized
DEBUG - 2023-04-23 16:17:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-23 16:17:33 --> Input Class Initialized
INFO - 2023-04-23 16:17:33 --> Language Class Initialized
INFO - 2023-04-23 16:17:33 --> Loader Class Initialized
INFO - 2023-04-23 16:17:33 --> Helper loaded: url_helper
INFO - 2023-04-23 16:17:33 --> Helper loaded: file_helper
INFO - 2023-04-23 16:17:33 --> Helper loaded: html_helper
INFO - 2023-04-23 16:17:33 --> Helper loaded: text_helper
INFO - 2023-04-23 16:17:33 --> Helper loaded: form_helper
INFO - 2023-04-23 16:17:33 --> Helper loaded: lang_helper
INFO - 2023-04-23 16:17:33 --> Helper loaded: security_helper
INFO - 2023-04-23 16:17:33 --> Helper loaded: cookie_helper
INFO - 2023-04-23 16:17:33 --> Database Driver Class Initialized
INFO - 2023-04-23 16:17:33 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-23 16:17:33 --> Parser Class Initialized
INFO - 2023-04-23 16:17:33 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-23 16:17:33 --> Pagination Class Initialized
INFO - 2023-04-23 16:17:33 --> Form Validation Class Initialized
INFO - 2023-04-23 16:17:33 --> Controller Class Initialized
INFO - 2023-04-23 16:17:33 --> Model Class Initialized
INFO - 2023-04-23 16:17:33 --> Model Class Initialized
ERROR - 2023-04-23 16:17:33 --> Severity: Warning --> Invalid argument supplied for foreach() /home/powera7m/app.maurnaturo.com/application/views/purchase/add_purchase_form.php 157
INFO - 2023-04-23 16:17:33 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/purchase/add_purchase_form.php
DEBUG - 2023-04-23 16:17:33 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-04-23 16:17:33 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-04-23 16:17:33 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-04-23 16:17:33 --> Model Class Initialized
INFO - 2023-04-23 16:17:33 --> Model Class Initialized
INFO - 2023-04-23 16:17:33 --> Model Class Initialized
INFO - 2023-04-23 16:17:34 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-04-23 16:17:34 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-04-23 16:17:34 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-04-23 16:17:34 --> Final output sent to browser
DEBUG - 2023-04-23 16:17:34 --> Total execution time: 0.1950
ERROR - 2023-04-23 16:18:14 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-23 16:18:14 --> Config Class Initialized
INFO - 2023-04-23 16:18:14 --> Hooks Class Initialized
DEBUG - 2023-04-23 16:18:14 --> UTF-8 Support Enabled
INFO - 2023-04-23 16:18:14 --> Utf8 Class Initialized
INFO - 2023-04-23 16:18:14 --> URI Class Initialized
INFO - 2023-04-23 16:18:14 --> Router Class Initialized
INFO - 2023-04-23 16:18:14 --> Output Class Initialized
INFO - 2023-04-23 16:18:14 --> Security Class Initialized
DEBUG - 2023-04-23 16:18:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-23 16:18:14 --> Input Class Initialized
INFO - 2023-04-23 16:18:14 --> Language Class Initialized
INFO - 2023-04-23 16:18:14 --> Loader Class Initialized
INFO - 2023-04-23 16:18:14 --> Helper loaded: url_helper
INFO - 2023-04-23 16:18:14 --> Helper loaded: file_helper
INFO - 2023-04-23 16:18:14 --> Helper loaded: html_helper
INFO - 2023-04-23 16:18:14 --> Helper loaded: text_helper
INFO - 2023-04-23 16:18:14 --> Helper loaded: form_helper
INFO - 2023-04-23 16:18:14 --> Helper loaded: lang_helper
INFO - 2023-04-23 16:18:14 --> Helper loaded: security_helper
INFO - 2023-04-23 16:18:14 --> Helper loaded: cookie_helper
INFO - 2023-04-23 16:18:14 --> Database Driver Class Initialized
INFO - 2023-04-23 16:18:14 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-23 16:18:14 --> Parser Class Initialized
INFO - 2023-04-23 16:18:14 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-23 16:18:14 --> Pagination Class Initialized
INFO - 2023-04-23 16:18:14 --> Form Validation Class Initialized
INFO - 2023-04-23 16:18:14 --> Controller Class Initialized
INFO - 2023-04-23 16:18:14 --> Model Class Initialized
DEBUG - 2023-04-23 16:18:14 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-04-23 16:18:14 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-23 16:18:14 --> Model Class Initialized
INFO - 2023-04-23 16:18:14 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/stockrequest/inventory.php
DEBUG - 2023-04-23 16:18:14 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-04-23 16:18:14 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-04-23 16:18:14 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-04-23 16:18:14 --> Model Class Initialized
INFO - 2023-04-23 16:18:14 --> Model Class Initialized
INFO - 2023-04-23 16:18:14 --> Model Class Initialized
INFO - 2023-04-23 16:18:14 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-04-23 16:18:14 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-04-23 16:18:14 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-04-23 16:18:14 --> Final output sent to browser
DEBUG - 2023-04-23 16:18:14 --> Total execution time: 0.1334
ERROR - 2023-04-23 16:18:15 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-23 16:18:15 --> Config Class Initialized
INFO - 2023-04-23 16:18:15 --> Hooks Class Initialized
DEBUG - 2023-04-23 16:18:15 --> UTF-8 Support Enabled
INFO - 2023-04-23 16:18:15 --> Utf8 Class Initialized
INFO - 2023-04-23 16:18:15 --> URI Class Initialized
INFO - 2023-04-23 16:18:15 --> Router Class Initialized
INFO - 2023-04-23 16:18:15 --> Output Class Initialized
INFO - 2023-04-23 16:18:15 --> Security Class Initialized
DEBUG - 2023-04-23 16:18:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-23 16:18:15 --> Input Class Initialized
INFO - 2023-04-23 16:18:15 --> Language Class Initialized
INFO - 2023-04-23 16:18:15 --> Loader Class Initialized
INFO - 2023-04-23 16:18:15 --> Helper loaded: url_helper
INFO - 2023-04-23 16:18:15 --> Helper loaded: file_helper
INFO - 2023-04-23 16:18:15 --> Helper loaded: html_helper
INFO - 2023-04-23 16:18:15 --> Helper loaded: text_helper
INFO - 2023-04-23 16:18:15 --> Helper loaded: form_helper
INFO - 2023-04-23 16:18:15 --> Helper loaded: lang_helper
INFO - 2023-04-23 16:18:15 --> Helper loaded: security_helper
INFO - 2023-04-23 16:18:15 --> Helper loaded: cookie_helper
INFO - 2023-04-23 16:18:15 --> Database Driver Class Initialized
INFO - 2023-04-23 16:18:15 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-23 16:18:15 --> Parser Class Initialized
INFO - 2023-04-23 16:18:15 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-23 16:18:15 --> Pagination Class Initialized
INFO - 2023-04-23 16:18:15 --> Form Validation Class Initialized
INFO - 2023-04-23 16:18:15 --> Controller Class Initialized
INFO - 2023-04-23 16:18:15 --> Model Class Initialized
DEBUG - 2023-04-23 16:18:15 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-04-23 16:18:15 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-23 16:18:15 --> Model Class Initialized
INFO - 2023-04-23 16:18:15 --> Final output sent to browser
DEBUG - 2023-04-23 16:18:15 --> Total execution time: 0.0200
ERROR - 2023-04-23 16:18:34 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-23 16:18:34 --> Config Class Initialized
INFO - 2023-04-23 16:18:34 --> Hooks Class Initialized
DEBUG - 2023-04-23 16:18:34 --> UTF-8 Support Enabled
INFO - 2023-04-23 16:18:34 --> Utf8 Class Initialized
INFO - 2023-04-23 16:18:34 --> URI Class Initialized
DEBUG - 2023-04-23 16:18:34 --> No URI present. Default controller set.
INFO - 2023-04-23 16:18:34 --> Router Class Initialized
INFO - 2023-04-23 16:18:34 --> Output Class Initialized
INFO - 2023-04-23 16:18:34 --> Security Class Initialized
DEBUG - 2023-04-23 16:18:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-23 16:18:34 --> Input Class Initialized
INFO - 2023-04-23 16:18:34 --> Language Class Initialized
INFO - 2023-04-23 16:18:34 --> Loader Class Initialized
INFO - 2023-04-23 16:18:34 --> Helper loaded: url_helper
INFO - 2023-04-23 16:18:34 --> Helper loaded: file_helper
INFO - 2023-04-23 16:18:34 --> Helper loaded: html_helper
INFO - 2023-04-23 16:18:34 --> Helper loaded: text_helper
INFO - 2023-04-23 16:18:34 --> Helper loaded: form_helper
INFO - 2023-04-23 16:18:34 --> Helper loaded: lang_helper
INFO - 2023-04-23 16:18:34 --> Helper loaded: security_helper
INFO - 2023-04-23 16:18:34 --> Helper loaded: cookie_helper
INFO - 2023-04-23 16:18:34 --> Database Driver Class Initialized
INFO - 2023-04-23 16:18:34 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-23 16:18:34 --> Parser Class Initialized
INFO - 2023-04-23 16:18:34 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-23 16:18:34 --> Pagination Class Initialized
INFO - 2023-04-23 16:18:34 --> Form Validation Class Initialized
INFO - 2023-04-23 16:18:34 --> Controller Class Initialized
INFO - 2023-04-23 16:18:34 --> Model Class Initialized
DEBUG - 2023-04-23 16:18:34 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-23 16:18:34 --> Model Class Initialized
DEBUG - 2023-04-23 16:18:34 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-23 16:18:34 --> Model Class Initialized
INFO - 2023-04-23 16:18:34 --> Model Class Initialized
INFO - 2023-04-23 16:18:34 --> Model Class Initialized
INFO - 2023-04-23 16:18:34 --> Model Class Initialized
DEBUG - 2023-04-23 16:18:34 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-04-23 16:18:34 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-23 16:18:34 --> Model Class Initialized
INFO - 2023-04-23 16:18:34 --> Model Class Initialized
INFO - 2023-04-23 16:18:34 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-04-23 16:18:34 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-04-23 16:18:34 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-04-23 16:18:34 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-04-23 16:18:34 --> Model Class Initialized
INFO - 2023-04-23 16:18:35 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-04-23 16:18:35 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-04-23 16:18:35 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-04-23 16:18:35 --> Final output sent to browser
DEBUG - 2023-04-23 16:18:35 --> Total execution time: 0.1806
ERROR - 2023-04-23 16:24:47 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-23 16:24:47 --> Config Class Initialized
INFO - 2023-04-23 16:24:47 --> Hooks Class Initialized
DEBUG - 2023-04-23 16:24:47 --> UTF-8 Support Enabled
INFO - 2023-04-23 16:24:47 --> Utf8 Class Initialized
INFO - 2023-04-23 16:24:47 --> URI Class Initialized
INFO - 2023-04-23 16:24:47 --> Router Class Initialized
INFO - 2023-04-23 16:24:47 --> Output Class Initialized
INFO - 2023-04-23 16:24:47 --> Security Class Initialized
DEBUG - 2023-04-23 16:24:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-23 16:24:47 --> Input Class Initialized
INFO - 2023-04-23 16:24:47 --> Language Class Initialized
INFO - 2023-04-23 16:24:47 --> Loader Class Initialized
INFO - 2023-04-23 16:24:47 --> Helper loaded: url_helper
INFO - 2023-04-23 16:24:47 --> Helper loaded: file_helper
INFO - 2023-04-23 16:24:47 --> Helper loaded: html_helper
INFO - 2023-04-23 16:24:47 --> Helper loaded: text_helper
INFO - 2023-04-23 16:24:47 --> Helper loaded: form_helper
INFO - 2023-04-23 16:24:47 --> Helper loaded: lang_helper
INFO - 2023-04-23 16:24:47 --> Helper loaded: security_helper
INFO - 2023-04-23 16:24:47 --> Helper loaded: cookie_helper
INFO - 2023-04-23 16:24:47 --> Database Driver Class Initialized
INFO - 2023-04-23 16:24:47 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-23 16:24:47 --> Parser Class Initialized
INFO - 2023-04-23 16:24:47 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-23 16:24:47 --> Pagination Class Initialized
INFO - 2023-04-23 16:24:47 --> Form Validation Class Initialized
INFO - 2023-04-23 16:24:47 --> Controller Class Initialized
INFO - 2023-04-23 16:24:47 --> Model Class Initialized
DEBUG - 2023-04-23 16:24:47 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-04-23 16:24:47 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-23 16:24:47 --> Model Class Initialized
INFO - 2023-04-23 16:24:47 --> Final output sent to browser
DEBUG - 2023-04-23 16:24:47 --> Total execution time: 0.0233
ERROR - 2023-04-23 16:31:28 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-23 16:31:28 --> Config Class Initialized
INFO - 2023-04-23 16:31:28 --> Hooks Class Initialized
DEBUG - 2023-04-23 16:31:28 --> UTF-8 Support Enabled
INFO - 2023-04-23 16:31:28 --> Utf8 Class Initialized
INFO - 2023-04-23 16:31:28 --> URI Class Initialized
INFO - 2023-04-23 16:31:28 --> Router Class Initialized
INFO - 2023-04-23 16:31:28 --> Output Class Initialized
INFO - 2023-04-23 16:31:28 --> Security Class Initialized
DEBUG - 2023-04-23 16:31:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-23 16:31:28 --> Input Class Initialized
INFO - 2023-04-23 16:31:28 --> Language Class Initialized
INFO - 2023-04-23 16:31:28 --> Loader Class Initialized
INFO - 2023-04-23 16:31:28 --> Helper loaded: url_helper
INFO - 2023-04-23 16:31:28 --> Helper loaded: file_helper
INFO - 2023-04-23 16:31:28 --> Helper loaded: html_helper
INFO - 2023-04-23 16:31:28 --> Helper loaded: text_helper
INFO - 2023-04-23 16:31:28 --> Helper loaded: form_helper
INFO - 2023-04-23 16:31:28 --> Helper loaded: lang_helper
INFO - 2023-04-23 16:31:28 --> Helper loaded: security_helper
INFO - 2023-04-23 16:31:28 --> Helper loaded: cookie_helper
INFO - 2023-04-23 16:31:28 --> Database Driver Class Initialized
INFO - 2023-04-23 16:31:28 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-23 16:31:28 --> Parser Class Initialized
INFO - 2023-04-23 16:31:28 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-23 16:31:28 --> Pagination Class Initialized
INFO - 2023-04-23 16:31:28 --> Form Validation Class Initialized
INFO - 2023-04-23 16:31:28 --> Controller Class Initialized
INFO - 2023-04-23 16:31:28 --> Model Class Initialized
DEBUG - 2023-04-23 16:31:28 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-04-23 16:31:28 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-23 16:31:28 --> Model Class Initialized
INFO - 2023-04-23 16:31:28 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/stockrequest/inventory.php
DEBUG - 2023-04-23 16:31:28 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-04-23 16:31:28 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-04-23 16:31:28 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-04-23 16:31:28 --> Model Class Initialized
INFO - 2023-04-23 16:31:28 --> Model Class Initialized
INFO - 2023-04-23 16:31:28 --> Model Class Initialized
INFO - 2023-04-23 16:31:28 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-04-23 16:31:28 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-04-23 16:31:28 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-04-23 16:31:28 --> Final output sent to browser
DEBUG - 2023-04-23 16:31:28 --> Total execution time: 0.1417
ERROR - 2023-04-23 16:31:29 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-23 16:31:29 --> Config Class Initialized
INFO - 2023-04-23 16:31:29 --> Hooks Class Initialized
DEBUG - 2023-04-23 16:31:29 --> UTF-8 Support Enabled
INFO - 2023-04-23 16:31:29 --> Utf8 Class Initialized
INFO - 2023-04-23 16:31:29 --> URI Class Initialized
INFO - 2023-04-23 16:31:29 --> Router Class Initialized
INFO - 2023-04-23 16:31:29 --> Output Class Initialized
INFO - 2023-04-23 16:31:29 --> Security Class Initialized
DEBUG - 2023-04-23 16:31:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-23 16:31:29 --> Input Class Initialized
INFO - 2023-04-23 16:31:29 --> Language Class Initialized
INFO - 2023-04-23 16:31:29 --> Loader Class Initialized
INFO - 2023-04-23 16:31:29 --> Helper loaded: url_helper
INFO - 2023-04-23 16:31:29 --> Helper loaded: file_helper
INFO - 2023-04-23 16:31:29 --> Helper loaded: html_helper
INFO - 2023-04-23 16:31:29 --> Helper loaded: text_helper
INFO - 2023-04-23 16:31:29 --> Helper loaded: form_helper
INFO - 2023-04-23 16:31:29 --> Helper loaded: lang_helper
INFO - 2023-04-23 16:31:29 --> Helper loaded: security_helper
INFO - 2023-04-23 16:31:29 --> Helper loaded: cookie_helper
INFO - 2023-04-23 16:31:29 --> Database Driver Class Initialized
INFO - 2023-04-23 16:31:29 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-23 16:31:29 --> Parser Class Initialized
INFO - 2023-04-23 16:31:29 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-23 16:31:29 --> Pagination Class Initialized
INFO - 2023-04-23 16:31:29 --> Form Validation Class Initialized
INFO - 2023-04-23 16:31:29 --> Controller Class Initialized
INFO - 2023-04-23 16:31:29 --> Model Class Initialized
DEBUG - 2023-04-23 16:31:29 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-04-23 16:31:29 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-23 16:31:29 --> Model Class Initialized
INFO - 2023-04-23 16:31:29 --> Final output sent to browser
DEBUG - 2023-04-23 16:31:29 --> Total execution time: 0.0198
ERROR - 2023-04-23 16:31:33 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-23 16:31:33 --> Config Class Initialized
INFO - 2023-04-23 16:31:33 --> Hooks Class Initialized
DEBUG - 2023-04-23 16:31:33 --> UTF-8 Support Enabled
INFO - 2023-04-23 16:31:33 --> Utf8 Class Initialized
INFO - 2023-04-23 16:31:33 --> URI Class Initialized
INFO - 2023-04-23 16:31:33 --> Router Class Initialized
INFO - 2023-04-23 16:31:33 --> Output Class Initialized
INFO - 2023-04-23 16:31:33 --> Security Class Initialized
DEBUG - 2023-04-23 16:31:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-23 16:31:33 --> Input Class Initialized
INFO - 2023-04-23 16:31:33 --> Language Class Initialized
INFO - 2023-04-23 16:31:33 --> Loader Class Initialized
INFO - 2023-04-23 16:31:33 --> Helper loaded: url_helper
INFO - 2023-04-23 16:31:33 --> Helper loaded: file_helper
INFO - 2023-04-23 16:31:33 --> Helper loaded: html_helper
INFO - 2023-04-23 16:31:33 --> Helper loaded: text_helper
INFO - 2023-04-23 16:31:33 --> Helper loaded: form_helper
INFO - 2023-04-23 16:31:33 --> Helper loaded: lang_helper
INFO - 2023-04-23 16:31:33 --> Helper loaded: security_helper
INFO - 2023-04-23 16:31:33 --> Helper loaded: cookie_helper
INFO - 2023-04-23 16:31:33 --> Database Driver Class Initialized
INFO - 2023-04-23 16:31:33 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-23 16:31:33 --> Parser Class Initialized
INFO - 2023-04-23 16:31:33 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-23 16:31:33 --> Pagination Class Initialized
INFO - 2023-04-23 16:31:33 --> Form Validation Class Initialized
INFO - 2023-04-23 16:31:33 --> Controller Class Initialized
INFO - 2023-04-23 16:31:33 --> Model Class Initialized
DEBUG - 2023-04-23 16:31:33 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-04-23 16:31:33 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-23 16:31:33 --> Model Class Initialized
INFO - 2023-04-23 16:31:33 --> Final output sent to browser
DEBUG - 2023-04-23 16:31:33 --> Total execution time: 0.0195
ERROR - 2023-04-23 16:32:41 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-23 16:32:41 --> Config Class Initialized
INFO - 2023-04-23 16:32:41 --> Hooks Class Initialized
DEBUG - 2023-04-23 16:32:41 --> UTF-8 Support Enabled
INFO - 2023-04-23 16:32:41 --> Utf8 Class Initialized
INFO - 2023-04-23 16:32:41 --> URI Class Initialized
INFO - 2023-04-23 16:32:41 --> Router Class Initialized
INFO - 2023-04-23 16:32:41 --> Output Class Initialized
INFO - 2023-04-23 16:32:41 --> Security Class Initialized
DEBUG - 2023-04-23 16:32:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-23 16:32:41 --> Input Class Initialized
INFO - 2023-04-23 16:32:41 --> Language Class Initialized
INFO - 2023-04-23 16:32:41 --> Loader Class Initialized
INFO - 2023-04-23 16:32:41 --> Helper loaded: url_helper
INFO - 2023-04-23 16:32:41 --> Helper loaded: file_helper
INFO - 2023-04-23 16:32:41 --> Helper loaded: html_helper
INFO - 2023-04-23 16:32:41 --> Helper loaded: text_helper
INFO - 2023-04-23 16:32:41 --> Helper loaded: form_helper
INFO - 2023-04-23 16:32:41 --> Helper loaded: lang_helper
INFO - 2023-04-23 16:32:41 --> Helper loaded: security_helper
INFO - 2023-04-23 16:32:41 --> Helper loaded: cookie_helper
INFO - 2023-04-23 16:32:41 --> Database Driver Class Initialized
INFO - 2023-04-23 16:32:41 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-23 16:32:41 --> Parser Class Initialized
INFO - 2023-04-23 16:32:41 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-23 16:32:41 --> Pagination Class Initialized
INFO - 2023-04-23 16:32:41 --> Form Validation Class Initialized
INFO - 2023-04-23 16:32:41 --> Controller Class Initialized
DEBUG - 2023-04-23 16:32:41 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-04-23 16:32:41 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-23 16:32:41 --> Model Class Initialized
DEBUG - 2023-04-23 16:32:41 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-23 16:32:41 --> Model Class Initialized
DEBUG - 2023-04-23 16:32:41 --> Lcustomer class already loaded. Second attempt ignored.
INFO - 2023-04-23 16:32:41 --> Model Class Initialized
INFO - 2023-04-23 16:32:41 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/customer/customer.php
DEBUG - 2023-04-23 16:32:41 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-04-23 16:32:41 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-04-23 16:32:41 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-04-23 16:32:41 --> Model Class Initialized
INFO - 2023-04-23 16:32:41 --> Model Class Initialized
INFO - 2023-04-23 16:32:41 --> Model Class Initialized
INFO - 2023-04-23 16:32:41 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-04-23 16:32:41 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-04-23 16:32:41 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-04-23 16:32:41 --> Final output sent to browser
DEBUG - 2023-04-23 16:32:41 --> Total execution time: 0.1389
ERROR - 2023-04-23 16:32:42 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-23 16:32:42 --> Config Class Initialized
INFO - 2023-04-23 16:32:42 --> Hooks Class Initialized
DEBUG - 2023-04-23 16:32:42 --> UTF-8 Support Enabled
INFO - 2023-04-23 16:32:42 --> Utf8 Class Initialized
INFO - 2023-04-23 16:32:42 --> URI Class Initialized
INFO - 2023-04-23 16:32:42 --> Router Class Initialized
INFO - 2023-04-23 16:32:42 --> Output Class Initialized
INFO - 2023-04-23 16:32:42 --> Security Class Initialized
DEBUG - 2023-04-23 16:32:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-23 16:32:42 --> Input Class Initialized
INFO - 2023-04-23 16:32:42 --> Language Class Initialized
INFO - 2023-04-23 16:32:42 --> Loader Class Initialized
INFO - 2023-04-23 16:32:42 --> Helper loaded: url_helper
INFO - 2023-04-23 16:32:42 --> Helper loaded: file_helper
INFO - 2023-04-23 16:32:42 --> Helper loaded: html_helper
INFO - 2023-04-23 16:32:42 --> Helper loaded: text_helper
INFO - 2023-04-23 16:32:42 --> Helper loaded: form_helper
INFO - 2023-04-23 16:32:42 --> Helper loaded: lang_helper
INFO - 2023-04-23 16:32:42 --> Helper loaded: security_helper
INFO - 2023-04-23 16:32:42 --> Helper loaded: cookie_helper
INFO - 2023-04-23 16:32:42 --> Database Driver Class Initialized
INFO - 2023-04-23 16:32:42 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-23 16:32:42 --> Parser Class Initialized
INFO - 2023-04-23 16:32:42 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-23 16:32:42 --> Pagination Class Initialized
INFO - 2023-04-23 16:32:42 --> Form Validation Class Initialized
INFO - 2023-04-23 16:32:42 --> Controller Class Initialized
DEBUG - 2023-04-23 16:32:42 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-04-23 16:32:42 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-23 16:32:42 --> Model Class Initialized
DEBUG - 2023-04-23 16:32:42 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-23 16:32:42 --> Model Class Initialized
INFO - 2023-04-23 16:32:42 --> Final output sent to browser
DEBUG - 2023-04-23 16:32:42 --> Total execution time: 0.0337
ERROR - 2023-04-23 16:47:41 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-23 16:47:41 --> Config Class Initialized
INFO - 2023-04-23 16:47:41 --> Hooks Class Initialized
DEBUG - 2023-04-23 16:47:41 --> UTF-8 Support Enabled
INFO - 2023-04-23 16:47:41 --> Utf8 Class Initialized
INFO - 2023-04-23 16:47:41 --> URI Class Initialized
INFO - 2023-04-23 16:47:41 --> Router Class Initialized
INFO - 2023-04-23 16:47:41 --> Output Class Initialized
INFO - 2023-04-23 16:47:41 --> Security Class Initialized
DEBUG - 2023-04-23 16:47:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-23 16:47:41 --> Input Class Initialized
INFO - 2023-04-23 16:47:41 --> Language Class Initialized
INFO - 2023-04-23 16:47:41 --> Loader Class Initialized
INFO - 2023-04-23 16:47:41 --> Helper loaded: url_helper
INFO - 2023-04-23 16:47:41 --> Helper loaded: file_helper
INFO - 2023-04-23 16:47:41 --> Helper loaded: html_helper
INFO - 2023-04-23 16:47:41 --> Helper loaded: text_helper
INFO - 2023-04-23 16:47:41 --> Helper loaded: form_helper
INFO - 2023-04-23 16:47:41 --> Helper loaded: lang_helper
INFO - 2023-04-23 16:47:41 --> Helper loaded: security_helper
INFO - 2023-04-23 16:47:41 --> Helper loaded: cookie_helper
INFO - 2023-04-23 16:47:41 --> Database Driver Class Initialized
INFO - 2023-04-23 16:47:41 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-23 16:47:41 --> Parser Class Initialized
INFO - 2023-04-23 16:47:41 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-23 16:47:41 --> Pagination Class Initialized
INFO - 2023-04-23 16:47:41 --> Form Validation Class Initialized
INFO - 2023-04-23 16:47:41 --> Controller Class Initialized
DEBUG - 2023-04-23 16:47:41 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-04-23 16:47:41 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-23 16:47:41 --> Model Class Initialized
DEBUG - 2023-04-23 16:47:41 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-04-23 16:47:41 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-04-23 16:47:41 --> Ltarget class already loaded. Second attempt ignored.
INFO - 2023-04-23 16:47:41 --> Model Class Initialized
DEBUG - 2023-04-23 16:47:41 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-04-23 16:47:41 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-23 16:47:41 --> Model Class Initialized
DEBUG - 2023-04-23 16:47:41 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-23 16:47:41 --> Model Class Initialized
INFO - 2023-04-23 16:47:41 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/target/target.php
DEBUG - 2023-04-23 16:47:41 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-04-23 16:47:41 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-04-23 16:47:41 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-04-23 16:47:41 --> Model Class Initialized
INFO - 2023-04-23 16:47:41 --> Model Class Initialized
INFO - 2023-04-23 16:47:41 --> Model Class Initialized
INFO - 2023-04-23 16:47:41 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-04-23 16:47:41 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-04-23 16:47:41 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-04-23 16:47:41 --> Final output sent to browser
DEBUG - 2023-04-23 16:47:41 --> Total execution time: 0.1608
ERROR - 2023-04-23 16:47:42 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-23 16:47:42 --> Config Class Initialized
INFO - 2023-04-23 16:47:42 --> Hooks Class Initialized
DEBUG - 2023-04-23 16:47:42 --> UTF-8 Support Enabled
INFO - 2023-04-23 16:47:42 --> Utf8 Class Initialized
INFO - 2023-04-23 16:47:42 --> URI Class Initialized
INFO - 2023-04-23 16:47:42 --> Router Class Initialized
INFO - 2023-04-23 16:47:42 --> Output Class Initialized
INFO - 2023-04-23 16:47:42 --> Security Class Initialized
DEBUG - 2023-04-23 16:47:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-23 16:47:42 --> Input Class Initialized
INFO - 2023-04-23 16:47:42 --> Language Class Initialized
INFO - 2023-04-23 16:47:42 --> Loader Class Initialized
INFO - 2023-04-23 16:47:42 --> Helper loaded: url_helper
INFO - 2023-04-23 16:47:42 --> Helper loaded: file_helper
INFO - 2023-04-23 16:47:42 --> Helper loaded: html_helper
INFO - 2023-04-23 16:47:42 --> Helper loaded: text_helper
INFO - 2023-04-23 16:47:42 --> Helper loaded: form_helper
INFO - 2023-04-23 16:47:42 --> Helper loaded: lang_helper
INFO - 2023-04-23 16:47:42 --> Helper loaded: security_helper
INFO - 2023-04-23 16:47:42 --> Helper loaded: cookie_helper
INFO - 2023-04-23 16:47:42 --> Database Driver Class Initialized
INFO - 2023-04-23 16:47:42 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-23 16:47:42 --> Parser Class Initialized
INFO - 2023-04-23 16:47:42 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-23 16:47:42 --> Pagination Class Initialized
INFO - 2023-04-23 16:47:42 --> Form Validation Class Initialized
INFO - 2023-04-23 16:47:42 --> Controller Class Initialized
DEBUG - 2023-04-23 16:47:42 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-04-23 16:47:42 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-23 16:47:42 --> Model Class Initialized
DEBUG - 2023-04-23 16:47:42 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-04-23 16:47:42 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-23 16:47:42 --> Model Class Initialized
DEBUG - 2023-04-23 16:47:42 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-04-23 16:47:42 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-23 16:47:42 --> Model Class Initialized
DEBUG - 2023-04-23 16:47:42 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-23 16:47:42 --> Model Class Initialized
INFO - 2023-04-23 16:47:42 --> Final output sent to browser
DEBUG - 2023-04-23 16:47:42 --> Total execution time: 0.0219
ERROR - 2023-04-23 16:52:38 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-23 16:52:38 --> Config Class Initialized
INFO - 2023-04-23 16:52:38 --> Hooks Class Initialized
DEBUG - 2023-04-23 16:52:38 --> UTF-8 Support Enabled
INFO - 2023-04-23 16:52:38 --> Utf8 Class Initialized
INFO - 2023-04-23 16:52:38 --> URI Class Initialized
DEBUG - 2023-04-23 16:52:38 --> No URI present. Default controller set.
INFO - 2023-04-23 16:52:38 --> Router Class Initialized
INFO - 2023-04-23 16:52:38 --> Output Class Initialized
INFO - 2023-04-23 16:52:38 --> Security Class Initialized
DEBUG - 2023-04-23 16:52:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-23 16:52:38 --> Input Class Initialized
INFO - 2023-04-23 16:52:38 --> Language Class Initialized
INFO - 2023-04-23 16:52:38 --> Loader Class Initialized
INFO - 2023-04-23 16:52:38 --> Helper loaded: url_helper
INFO - 2023-04-23 16:52:38 --> Helper loaded: file_helper
INFO - 2023-04-23 16:52:38 --> Helper loaded: html_helper
INFO - 2023-04-23 16:52:38 --> Helper loaded: text_helper
INFO - 2023-04-23 16:52:38 --> Helper loaded: form_helper
INFO - 2023-04-23 16:52:38 --> Helper loaded: lang_helper
INFO - 2023-04-23 16:52:38 --> Helper loaded: security_helper
INFO - 2023-04-23 16:52:38 --> Helper loaded: cookie_helper
INFO - 2023-04-23 16:52:38 --> Database Driver Class Initialized
INFO - 2023-04-23 16:52:38 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-23 16:52:38 --> Parser Class Initialized
INFO - 2023-04-23 16:52:38 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-23 16:52:38 --> Pagination Class Initialized
INFO - 2023-04-23 16:52:38 --> Form Validation Class Initialized
INFO - 2023-04-23 16:52:38 --> Controller Class Initialized
INFO - 2023-04-23 16:52:38 --> Model Class Initialized
DEBUG - 2023-04-23 16:52:38 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-23 16:52:38 --> Model Class Initialized
DEBUG - 2023-04-23 16:52:38 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-23 16:52:38 --> Model Class Initialized
INFO - 2023-04-23 16:52:38 --> Model Class Initialized
INFO - 2023-04-23 16:52:38 --> Model Class Initialized
INFO - 2023-04-23 16:52:38 --> Model Class Initialized
DEBUG - 2023-04-23 16:52:38 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-04-23 16:52:38 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-23 16:52:38 --> Model Class Initialized
INFO - 2023-04-23 16:52:38 --> Model Class Initialized
INFO - 2023-04-23 16:52:38 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-04-23 16:52:38 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-04-23 16:52:38 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-04-23 16:52:38 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-04-23 16:52:38 --> Model Class Initialized
INFO - 2023-04-23 16:52:38 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-04-23 16:52:38 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-04-23 16:52:38 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-04-23 16:52:38 --> Final output sent to browser
DEBUG - 2023-04-23 16:52:38 --> Total execution time: 0.1906
ERROR - 2023-04-23 16:53:05 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-23 16:53:05 --> Config Class Initialized
INFO - 2023-04-23 16:53:05 --> Hooks Class Initialized
DEBUG - 2023-04-23 16:53:05 --> UTF-8 Support Enabled
INFO - 2023-04-23 16:53:05 --> Utf8 Class Initialized
INFO - 2023-04-23 16:53:05 --> URI Class Initialized
INFO - 2023-04-23 16:53:05 --> Router Class Initialized
INFO - 2023-04-23 16:53:05 --> Output Class Initialized
INFO - 2023-04-23 16:53:05 --> Security Class Initialized
DEBUG - 2023-04-23 16:53:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-23 16:53:05 --> Input Class Initialized
INFO - 2023-04-23 16:53:05 --> Language Class Initialized
INFO - 2023-04-23 16:53:05 --> Loader Class Initialized
INFO - 2023-04-23 16:53:05 --> Helper loaded: url_helper
INFO - 2023-04-23 16:53:05 --> Helper loaded: file_helper
INFO - 2023-04-23 16:53:05 --> Helper loaded: html_helper
INFO - 2023-04-23 16:53:05 --> Helper loaded: text_helper
INFO - 2023-04-23 16:53:05 --> Helper loaded: form_helper
INFO - 2023-04-23 16:53:05 --> Helper loaded: lang_helper
INFO - 2023-04-23 16:53:05 --> Helper loaded: security_helper
INFO - 2023-04-23 16:53:05 --> Helper loaded: cookie_helper
INFO - 2023-04-23 16:53:05 --> Database Driver Class Initialized
INFO - 2023-04-23 16:53:05 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-23 16:53:05 --> Parser Class Initialized
INFO - 2023-04-23 16:53:05 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-23 16:53:05 --> Pagination Class Initialized
INFO - 2023-04-23 16:53:05 --> Form Validation Class Initialized
INFO - 2023-04-23 16:53:05 --> Controller Class Initialized
DEBUG - 2023-04-23 16:53:05 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-04-23 16:53:05 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-23 16:53:05 --> Model Class Initialized
INFO - 2023-04-23 16:53:05 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/web_setting/web_setting.php
DEBUG - 2023-04-23 16:53:05 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-04-23 16:53:05 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-04-23 16:53:05 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-04-23 16:53:05 --> Model Class Initialized
INFO - 2023-04-23 16:53:05 --> Model Class Initialized
INFO - 2023-04-23 16:53:05 --> Model Class Initialized
INFO - 2023-04-23 16:53:05 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-04-23 16:53:05 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-04-23 16:53:05 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-04-23 16:53:05 --> Final output sent to browser
DEBUG - 2023-04-23 16:53:05 --> Total execution time: 0.1849
ERROR - 2023-04-23 16:53:57 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-23 16:53:57 --> Config Class Initialized
INFO - 2023-04-23 16:53:57 --> Hooks Class Initialized
DEBUG - 2023-04-23 16:53:57 --> UTF-8 Support Enabled
INFO - 2023-04-23 16:53:57 --> Utf8 Class Initialized
INFO - 2023-04-23 16:53:57 --> URI Class Initialized
INFO - 2023-04-23 16:53:57 --> Router Class Initialized
INFO - 2023-04-23 16:53:57 --> Output Class Initialized
INFO - 2023-04-23 16:53:57 --> Security Class Initialized
DEBUG - 2023-04-23 16:53:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-23 16:53:57 --> Input Class Initialized
INFO - 2023-04-23 16:53:57 --> Language Class Initialized
INFO - 2023-04-23 16:53:57 --> Loader Class Initialized
INFO - 2023-04-23 16:53:57 --> Helper loaded: url_helper
INFO - 2023-04-23 16:53:57 --> Helper loaded: file_helper
INFO - 2023-04-23 16:53:57 --> Helper loaded: html_helper
INFO - 2023-04-23 16:53:57 --> Helper loaded: text_helper
INFO - 2023-04-23 16:53:57 --> Helper loaded: form_helper
INFO - 2023-04-23 16:53:57 --> Helper loaded: lang_helper
INFO - 2023-04-23 16:53:57 --> Helper loaded: security_helper
INFO - 2023-04-23 16:53:57 --> Helper loaded: cookie_helper
INFO - 2023-04-23 16:53:57 --> Database Driver Class Initialized
INFO - 2023-04-23 16:53:57 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-23 16:53:57 --> Parser Class Initialized
INFO - 2023-04-23 16:53:57 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-23 16:53:57 --> Pagination Class Initialized
INFO - 2023-04-23 16:53:57 --> Form Validation Class Initialized
INFO - 2023-04-23 16:53:57 --> Controller Class Initialized
DEBUG - 2023-04-23 16:53:57 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-04-23 16:53:57 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-23 16:53:57 --> Model Class Initialized
INFO - 2023-04-23 16:53:57 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/permission/role_view_form.php
DEBUG - 2023-04-23 16:53:57 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-04-23 16:53:57 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-04-23 16:53:57 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-04-23 16:53:57 --> Model Class Initialized
INFO - 2023-04-23 16:53:57 --> Model Class Initialized
INFO - 2023-04-23 16:53:57 --> Model Class Initialized
INFO - 2023-04-23 16:53:57 --> Model Class Initialized
INFO - 2023-04-23 16:53:57 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-04-23 16:53:57 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-04-23 16:53:57 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-04-23 16:53:57 --> Final output sent to browser
DEBUG - 2023-04-23 16:53:57 --> Total execution time: 0.1445
ERROR - 2023-04-23 16:54:33 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-23 16:54:33 --> Config Class Initialized
INFO - 2023-04-23 16:54:33 --> Hooks Class Initialized
DEBUG - 2023-04-23 16:54:33 --> UTF-8 Support Enabled
INFO - 2023-04-23 16:54:33 --> Utf8 Class Initialized
INFO - 2023-04-23 16:54:33 --> URI Class Initialized
INFO - 2023-04-23 16:54:33 --> Router Class Initialized
INFO - 2023-04-23 16:54:33 --> Output Class Initialized
INFO - 2023-04-23 16:54:33 --> Security Class Initialized
DEBUG - 2023-04-23 16:54:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-23 16:54:33 --> Input Class Initialized
INFO - 2023-04-23 16:54:33 --> Language Class Initialized
INFO - 2023-04-23 16:54:33 --> Loader Class Initialized
INFO - 2023-04-23 16:54:33 --> Helper loaded: url_helper
INFO - 2023-04-23 16:54:33 --> Helper loaded: file_helper
INFO - 2023-04-23 16:54:33 --> Helper loaded: html_helper
INFO - 2023-04-23 16:54:33 --> Helper loaded: text_helper
INFO - 2023-04-23 16:54:33 --> Helper loaded: form_helper
INFO - 2023-04-23 16:54:33 --> Helper loaded: lang_helper
INFO - 2023-04-23 16:54:33 --> Helper loaded: security_helper
INFO - 2023-04-23 16:54:33 --> Helper loaded: cookie_helper
INFO - 2023-04-23 16:54:33 --> Database Driver Class Initialized
INFO - 2023-04-23 16:54:33 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-23 16:54:33 --> Parser Class Initialized
INFO - 2023-04-23 16:54:33 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-23 16:54:33 --> Pagination Class Initialized
INFO - 2023-04-23 16:54:33 --> Form Validation Class Initialized
INFO - 2023-04-23 16:54:33 --> Controller Class Initialized
INFO - 2023-04-23 16:54:33 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/synchronizer/backup_and_restore.php
DEBUG - 2023-04-23 16:54:33 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-04-23 16:54:33 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-04-23 16:54:33 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-04-23 16:54:33 --> Model Class Initialized
INFO - 2023-04-23 16:54:33 --> Model Class Initialized
INFO - 2023-04-23 16:54:33 --> Model Class Initialized
INFO - 2023-04-23 16:54:33 --> Model Class Initialized
INFO - 2023-04-23 16:54:33 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-04-23 16:54:33 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-04-23 16:54:33 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-04-23 16:54:33 --> Final output sent to browser
DEBUG - 2023-04-23 16:54:33 --> Total execution time: 0.1641
ERROR - 2023-04-23 16:54:45 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-23 16:54:45 --> Config Class Initialized
INFO - 2023-04-23 16:54:45 --> Hooks Class Initialized
DEBUG - 2023-04-23 16:54:45 --> UTF-8 Support Enabled
INFO - 2023-04-23 16:54:45 --> Utf8 Class Initialized
INFO - 2023-04-23 16:54:45 --> URI Class Initialized
INFO - 2023-04-23 16:54:45 --> Router Class Initialized
INFO - 2023-04-23 16:54:45 --> Output Class Initialized
INFO - 2023-04-23 16:54:45 --> Security Class Initialized
DEBUG - 2023-04-23 16:54:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-23 16:54:45 --> Input Class Initialized
INFO - 2023-04-23 16:54:45 --> Language Class Initialized
INFO - 2023-04-23 16:54:45 --> Loader Class Initialized
INFO - 2023-04-23 16:54:45 --> Helper loaded: url_helper
INFO - 2023-04-23 16:54:45 --> Helper loaded: file_helper
INFO - 2023-04-23 16:54:45 --> Helper loaded: html_helper
INFO - 2023-04-23 16:54:45 --> Helper loaded: text_helper
INFO - 2023-04-23 16:54:45 --> Helper loaded: form_helper
INFO - 2023-04-23 16:54:45 --> Helper loaded: lang_helper
INFO - 2023-04-23 16:54:45 --> Helper loaded: security_helper
INFO - 2023-04-23 16:54:45 --> Helper loaded: cookie_helper
INFO - 2023-04-23 16:54:45 --> Database Driver Class Initialized
INFO - 2023-04-23 16:54:45 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-23 16:54:45 --> Parser Class Initialized
INFO - 2023-04-23 16:54:45 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-23 16:54:45 --> Pagination Class Initialized
INFO - 2023-04-23 16:54:45 --> Form Validation Class Initialized
INFO - 2023-04-23 16:54:45 --> Controller Class Initialized
INFO - 2023-04-23 16:54:45 --> Database Utility Class Initialized
INFO - 2023-04-23 16:54:45 --> Helper loaded: download_helper
ERROR - 2023-04-23 16:55:18 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-23 16:55:18 --> Config Class Initialized
INFO - 2023-04-23 16:55:18 --> Hooks Class Initialized
DEBUG - 2023-04-23 16:55:18 --> UTF-8 Support Enabled
INFO - 2023-04-23 16:55:18 --> Utf8 Class Initialized
INFO - 2023-04-23 16:55:18 --> URI Class Initialized
DEBUG - 2023-04-23 16:55:18 --> No URI present. Default controller set.
INFO - 2023-04-23 16:55:18 --> Router Class Initialized
INFO - 2023-04-23 16:55:18 --> Output Class Initialized
INFO - 2023-04-23 16:55:18 --> Security Class Initialized
DEBUG - 2023-04-23 16:55:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-23 16:55:18 --> Input Class Initialized
INFO - 2023-04-23 16:55:18 --> Language Class Initialized
INFO - 2023-04-23 16:55:18 --> Loader Class Initialized
INFO - 2023-04-23 16:55:18 --> Helper loaded: url_helper
INFO - 2023-04-23 16:55:18 --> Helper loaded: file_helper
INFO - 2023-04-23 16:55:18 --> Helper loaded: html_helper
INFO - 2023-04-23 16:55:18 --> Helper loaded: text_helper
INFO - 2023-04-23 16:55:18 --> Helper loaded: form_helper
INFO - 2023-04-23 16:55:18 --> Helper loaded: lang_helper
INFO - 2023-04-23 16:55:18 --> Helper loaded: security_helper
INFO - 2023-04-23 16:55:18 --> Helper loaded: cookie_helper
INFO - 2023-04-23 16:55:18 --> Database Driver Class Initialized
INFO - 2023-04-23 16:55:18 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-23 16:55:18 --> Parser Class Initialized
INFO - 2023-04-23 16:55:18 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-23 16:55:18 --> Pagination Class Initialized
INFO - 2023-04-23 16:55:18 --> Form Validation Class Initialized
INFO - 2023-04-23 16:55:18 --> Controller Class Initialized
INFO - 2023-04-23 16:55:18 --> Model Class Initialized
DEBUG - 2023-04-23 16:55:18 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-23 16:55:18 --> Model Class Initialized
DEBUG - 2023-04-23 16:55:18 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-23 16:55:18 --> Model Class Initialized
INFO - 2023-04-23 16:55:18 --> Model Class Initialized
INFO - 2023-04-23 16:55:18 --> Model Class Initialized
INFO - 2023-04-23 16:55:18 --> Model Class Initialized
DEBUG - 2023-04-23 16:55:18 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-04-23 16:55:18 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-23 16:55:18 --> Model Class Initialized
INFO - 2023-04-23 16:55:18 --> Model Class Initialized
INFO - 2023-04-23 16:55:18 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-04-23 16:55:18 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-04-23 16:55:18 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-04-23 16:55:18 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-04-23 16:55:18 --> Model Class Initialized
INFO - 2023-04-23 16:55:18 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-04-23 16:55:18 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-04-23 16:55:18 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-04-23 16:55:18 --> Final output sent to browser
DEBUG - 2023-04-23 16:55:18 --> Total execution time: 0.1867
ERROR - 2023-04-23 16:56:09 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-23 16:56:09 --> Config Class Initialized
INFO - 2023-04-23 16:56:09 --> Hooks Class Initialized
DEBUG - 2023-04-23 16:56:09 --> UTF-8 Support Enabled
INFO - 2023-04-23 16:56:09 --> Utf8 Class Initialized
INFO - 2023-04-23 16:56:09 --> URI Class Initialized
INFO - 2023-04-23 16:56:09 --> Router Class Initialized
INFO - 2023-04-23 16:56:09 --> Output Class Initialized
INFO - 2023-04-23 16:56:09 --> Security Class Initialized
DEBUG - 2023-04-23 16:56:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-23 16:56:09 --> Input Class Initialized
INFO - 2023-04-23 16:56:09 --> Language Class Initialized
INFO - 2023-04-23 16:56:09 --> Loader Class Initialized
INFO - 2023-04-23 16:56:09 --> Helper loaded: url_helper
INFO - 2023-04-23 16:56:09 --> Helper loaded: file_helper
INFO - 2023-04-23 16:56:09 --> Helper loaded: html_helper
INFO - 2023-04-23 16:56:09 --> Helper loaded: text_helper
INFO - 2023-04-23 16:56:09 --> Helper loaded: form_helper
INFO - 2023-04-23 16:56:09 --> Helper loaded: lang_helper
INFO - 2023-04-23 16:56:09 --> Helper loaded: security_helper
INFO - 2023-04-23 16:56:09 --> Helper loaded: cookie_helper
INFO - 2023-04-23 16:56:09 --> Database Driver Class Initialized
INFO - 2023-04-23 16:56:09 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-23 16:56:09 --> Parser Class Initialized
INFO - 2023-04-23 16:56:09 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-23 16:56:09 --> Pagination Class Initialized
INFO - 2023-04-23 16:56:09 --> Form Validation Class Initialized
INFO - 2023-04-23 16:56:09 --> Controller Class Initialized
INFO - 2023-04-23 16:56:09 --> Model Class Initialized
DEBUG - 2023-04-23 16:56:09 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-23 16:56:09 --> Model Class Initialized
INFO - 2023-04-23 22:56:09 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/report/purchase_report.php
DEBUG - 2023-04-23 22:56:09 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-04-23 22:56:09 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-04-23 22:56:09 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-04-23 22:56:09 --> Model Class Initialized
INFO - 2023-04-23 22:56:09 --> Model Class Initialized
INFO - 2023-04-23 22:56:10 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-04-23 22:56:10 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-04-23 22:56:10 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-04-23 22:56:10 --> Final output sent to browser
DEBUG - 2023-04-23 22:56:10 --> Total execution time: 0.1728
ERROR - 2023-04-23 16:59:19 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-23 16:59:19 --> Config Class Initialized
INFO - 2023-04-23 16:59:19 --> Hooks Class Initialized
DEBUG - 2023-04-23 16:59:19 --> UTF-8 Support Enabled
INFO - 2023-04-23 16:59:19 --> Utf8 Class Initialized
INFO - 2023-04-23 16:59:19 --> URI Class Initialized
INFO - 2023-04-23 16:59:19 --> Router Class Initialized
INFO - 2023-04-23 16:59:19 --> Output Class Initialized
INFO - 2023-04-23 16:59:19 --> Security Class Initialized
DEBUG - 2023-04-23 16:59:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-23 16:59:19 --> Input Class Initialized
INFO - 2023-04-23 16:59:19 --> Language Class Initialized
INFO - 2023-04-23 16:59:19 --> Loader Class Initialized
INFO - 2023-04-23 16:59:19 --> Helper loaded: url_helper
INFO - 2023-04-23 16:59:19 --> Helper loaded: file_helper
INFO - 2023-04-23 16:59:19 --> Helper loaded: html_helper
INFO - 2023-04-23 16:59:19 --> Helper loaded: text_helper
INFO - 2023-04-23 16:59:19 --> Helper loaded: form_helper
INFO - 2023-04-23 16:59:19 --> Helper loaded: lang_helper
INFO - 2023-04-23 16:59:19 --> Helper loaded: security_helper
INFO - 2023-04-23 16:59:19 --> Helper loaded: cookie_helper
INFO - 2023-04-23 16:59:19 --> Database Driver Class Initialized
INFO - 2023-04-23 16:59:19 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-23 16:59:19 --> Parser Class Initialized
INFO - 2023-04-23 16:59:19 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-23 16:59:19 --> Pagination Class Initialized
INFO - 2023-04-23 16:59:19 --> Form Validation Class Initialized
INFO - 2023-04-23 16:59:19 --> Controller Class Initialized
DEBUG - 2023-04-23 16:59:19 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-04-23 16:59:19 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-23 16:59:19 --> Model Class Initialized
INFO - 2023-04-23 16:59:19 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/gift/add_gift_form.php
DEBUG - 2023-04-23 16:59:19 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-04-23 16:59:19 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-04-23 16:59:19 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-04-23 16:59:19 --> Model Class Initialized
INFO - 2023-04-23 16:59:19 --> Model Class Initialized
INFO - 2023-04-23 16:59:20 --> Model Class Initialized
INFO - 2023-04-23 16:59:20 --> Model Class Initialized
INFO - 2023-04-23 16:59:20 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-04-23 16:59:20 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-04-23 16:59:20 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-04-23 16:59:20 --> Final output sent to browser
DEBUG - 2023-04-23 16:59:20 --> Total execution time: 0.1544
ERROR - 2023-04-23 16:59:31 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-23 16:59:31 --> Config Class Initialized
INFO - 2023-04-23 16:59:31 --> Hooks Class Initialized
DEBUG - 2023-04-23 16:59:31 --> UTF-8 Support Enabled
INFO - 2023-04-23 16:59:31 --> Utf8 Class Initialized
INFO - 2023-04-23 16:59:31 --> URI Class Initialized
INFO - 2023-04-23 16:59:31 --> Router Class Initialized
INFO - 2023-04-23 16:59:31 --> Output Class Initialized
INFO - 2023-04-23 16:59:31 --> Security Class Initialized
DEBUG - 2023-04-23 16:59:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-23 16:59:31 --> Input Class Initialized
INFO - 2023-04-23 16:59:31 --> Language Class Initialized
INFO - 2023-04-23 16:59:31 --> Loader Class Initialized
INFO - 2023-04-23 16:59:31 --> Helper loaded: url_helper
INFO - 2023-04-23 16:59:31 --> Helper loaded: file_helper
INFO - 2023-04-23 16:59:31 --> Helper loaded: html_helper
INFO - 2023-04-23 16:59:31 --> Helper loaded: text_helper
INFO - 2023-04-23 16:59:31 --> Helper loaded: form_helper
INFO - 2023-04-23 16:59:31 --> Helper loaded: lang_helper
INFO - 2023-04-23 16:59:31 --> Helper loaded: security_helper
INFO - 2023-04-23 16:59:31 --> Helper loaded: cookie_helper
INFO - 2023-04-23 16:59:31 --> Database Driver Class Initialized
INFO - 2023-04-23 16:59:31 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-23 16:59:31 --> Parser Class Initialized
INFO - 2023-04-23 16:59:31 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-23 16:59:31 --> Pagination Class Initialized
INFO - 2023-04-23 16:59:31 --> Form Validation Class Initialized
INFO - 2023-04-23 16:59:31 --> Controller Class Initialized
DEBUG - 2023-04-23 16:59:31 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-04-23 16:59:31 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-23 16:59:31 --> Model Class Initialized
DEBUG - 2023-04-23 16:59:31 --> Lgift class already loaded. Second attempt ignored.
INFO - 2023-04-23 16:59:31 --> Model Class Initialized
DEBUG - 2023-04-23 16:59:31 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-04-23 16:59:31 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-23 16:59:31 --> Model Class Initialized
DEBUG - 2023-04-23 16:59:31 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-23 16:59:31 --> Model Class Initialized
INFO - 2023-04-23 16:59:31 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/gift/gift.php
DEBUG - 2023-04-23 16:59:31 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-04-23 16:59:31 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-04-23 16:59:31 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-04-23 16:59:31 --> Model Class Initialized
INFO - 2023-04-23 16:59:31 --> Model Class Initialized
INFO - 2023-04-23 16:59:31 --> Model Class Initialized
INFO - 2023-04-23 16:59:31 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-04-23 16:59:31 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-04-23 16:59:31 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-04-23 16:59:31 --> Final output sent to browser
DEBUG - 2023-04-23 16:59:31 --> Total execution time: 0.1662
ERROR - 2023-04-23 16:59:32 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-23 16:59:32 --> Config Class Initialized
INFO - 2023-04-23 16:59:32 --> Hooks Class Initialized
DEBUG - 2023-04-23 16:59:32 --> UTF-8 Support Enabled
INFO - 2023-04-23 16:59:32 --> Utf8 Class Initialized
INFO - 2023-04-23 16:59:32 --> URI Class Initialized
INFO - 2023-04-23 16:59:32 --> Router Class Initialized
INFO - 2023-04-23 16:59:32 --> Output Class Initialized
INFO - 2023-04-23 16:59:32 --> Security Class Initialized
DEBUG - 2023-04-23 16:59:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-23 16:59:32 --> Input Class Initialized
INFO - 2023-04-23 16:59:32 --> Language Class Initialized
INFO - 2023-04-23 16:59:32 --> Loader Class Initialized
INFO - 2023-04-23 16:59:32 --> Helper loaded: url_helper
INFO - 2023-04-23 16:59:32 --> Helper loaded: file_helper
INFO - 2023-04-23 16:59:32 --> Helper loaded: html_helper
INFO - 2023-04-23 16:59:32 --> Helper loaded: text_helper
INFO - 2023-04-23 16:59:32 --> Helper loaded: form_helper
INFO - 2023-04-23 16:59:32 --> Helper loaded: lang_helper
INFO - 2023-04-23 16:59:32 --> Helper loaded: security_helper
INFO - 2023-04-23 16:59:32 --> Helper loaded: cookie_helper
INFO - 2023-04-23 16:59:32 --> Database Driver Class Initialized
INFO - 2023-04-23 16:59:32 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-23 16:59:32 --> Parser Class Initialized
INFO - 2023-04-23 16:59:32 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-23 16:59:32 --> Pagination Class Initialized
INFO - 2023-04-23 16:59:32 --> Form Validation Class Initialized
INFO - 2023-04-23 16:59:32 --> Controller Class Initialized
DEBUG - 2023-04-23 16:59:32 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-04-23 16:59:32 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-23 16:59:32 --> Model Class Initialized
INFO - 2023-04-23 16:59:32 --> Final output sent to browser
DEBUG - 2023-04-23 16:59:32 --> Total execution time: 0.0156
ERROR - 2023-04-23 16:59:42 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-23 16:59:42 --> Config Class Initialized
INFO - 2023-04-23 16:59:42 --> Hooks Class Initialized
DEBUG - 2023-04-23 16:59:42 --> UTF-8 Support Enabled
INFO - 2023-04-23 16:59:42 --> Utf8 Class Initialized
INFO - 2023-04-23 16:59:42 --> URI Class Initialized
DEBUG - 2023-04-23 16:59:42 --> No URI present. Default controller set.
INFO - 2023-04-23 16:59:42 --> Router Class Initialized
INFO - 2023-04-23 16:59:42 --> Output Class Initialized
INFO - 2023-04-23 16:59:42 --> Security Class Initialized
DEBUG - 2023-04-23 16:59:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-23 16:59:42 --> Input Class Initialized
INFO - 2023-04-23 16:59:42 --> Language Class Initialized
INFO - 2023-04-23 16:59:42 --> Loader Class Initialized
INFO - 2023-04-23 16:59:42 --> Helper loaded: url_helper
INFO - 2023-04-23 16:59:42 --> Helper loaded: file_helper
INFO - 2023-04-23 16:59:42 --> Helper loaded: html_helper
INFO - 2023-04-23 16:59:42 --> Helper loaded: text_helper
INFO - 2023-04-23 16:59:42 --> Helper loaded: form_helper
INFO - 2023-04-23 16:59:42 --> Helper loaded: lang_helper
INFO - 2023-04-23 16:59:42 --> Helper loaded: security_helper
INFO - 2023-04-23 16:59:42 --> Helper loaded: cookie_helper
INFO - 2023-04-23 16:59:42 --> Database Driver Class Initialized
INFO - 2023-04-23 16:59:42 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-23 16:59:42 --> Parser Class Initialized
INFO - 2023-04-23 16:59:42 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-23 16:59:42 --> Pagination Class Initialized
INFO - 2023-04-23 16:59:42 --> Form Validation Class Initialized
INFO - 2023-04-23 16:59:42 --> Controller Class Initialized
INFO - 2023-04-23 16:59:42 --> Model Class Initialized
DEBUG - 2023-04-23 16:59:42 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-23 16:59:42 --> Model Class Initialized
DEBUG - 2023-04-23 16:59:42 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-23 16:59:42 --> Model Class Initialized
INFO - 2023-04-23 16:59:42 --> Model Class Initialized
INFO - 2023-04-23 16:59:42 --> Model Class Initialized
INFO - 2023-04-23 16:59:42 --> Model Class Initialized
DEBUG - 2023-04-23 16:59:42 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-04-23 16:59:42 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-23 16:59:42 --> Model Class Initialized
INFO - 2023-04-23 16:59:42 --> Model Class Initialized
INFO - 2023-04-23 16:59:42 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-04-23 16:59:42 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-04-23 16:59:42 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-04-23 16:59:42 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-04-23 16:59:42 --> Model Class Initialized
INFO - 2023-04-23 16:59:42 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-04-23 16:59:42 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-04-23 16:59:42 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-04-23 16:59:42 --> Final output sent to browser
DEBUG - 2023-04-23 16:59:42 --> Total execution time: 0.1763
ERROR - 2023-04-23 17:24:38 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-23 17:24:38 --> Config Class Initialized
INFO - 2023-04-23 17:24:38 --> Hooks Class Initialized
DEBUG - 2023-04-23 17:24:38 --> UTF-8 Support Enabled
INFO - 2023-04-23 17:24:38 --> Utf8 Class Initialized
INFO - 2023-04-23 17:24:38 --> URI Class Initialized
DEBUG - 2023-04-23 17:24:38 --> No URI present. Default controller set.
INFO - 2023-04-23 17:24:38 --> Router Class Initialized
INFO - 2023-04-23 17:24:38 --> Output Class Initialized
INFO - 2023-04-23 17:24:38 --> Security Class Initialized
DEBUG - 2023-04-23 17:24:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-23 17:24:38 --> Input Class Initialized
INFO - 2023-04-23 17:24:38 --> Language Class Initialized
INFO - 2023-04-23 17:24:38 --> Loader Class Initialized
INFO - 2023-04-23 17:24:38 --> Helper loaded: url_helper
INFO - 2023-04-23 17:24:38 --> Helper loaded: file_helper
INFO - 2023-04-23 17:24:38 --> Helper loaded: html_helper
INFO - 2023-04-23 17:24:38 --> Helper loaded: text_helper
INFO - 2023-04-23 17:24:38 --> Helper loaded: form_helper
INFO - 2023-04-23 17:24:38 --> Helper loaded: lang_helper
INFO - 2023-04-23 17:24:38 --> Helper loaded: security_helper
INFO - 2023-04-23 17:24:38 --> Helper loaded: cookie_helper
INFO - 2023-04-23 17:24:38 --> Database Driver Class Initialized
INFO - 2023-04-23 17:24:38 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-23 17:24:38 --> Parser Class Initialized
INFO - 2023-04-23 17:24:38 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-23 17:24:38 --> Pagination Class Initialized
INFO - 2023-04-23 17:24:38 --> Form Validation Class Initialized
INFO - 2023-04-23 17:24:38 --> Controller Class Initialized
INFO - 2023-04-23 17:24:38 --> Model Class Initialized
DEBUG - 2023-04-23 17:24:38 --> Session class already loaded. Second attempt ignored.
ERROR - 2023-04-23 17:24:39 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-23 17:24:39 --> Config Class Initialized
INFO - 2023-04-23 17:24:39 --> Hooks Class Initialized
DEBUG - 2023-04-23 17:24:39 --> UTF-8 Support Enabled
INFO - 2023-04-23 17:24:39 --> Utf8 Class Initialized
INFO - 2023-04-23 17:24:39 --> URI Class Initialized
INFO - 2023-04-23 17:24:39 --> Router Class Initialized
INFO - 2023-04-23 17:24:39 --> Output Class Initialized
INFO - 2023-04-23 17:24:39 --> Security Class Initialized
DEBUG - 2023-04-23 17:24:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-23 17:24:39 --> Input Class Initialized
INFO - 2023-04-23 17:24:39 --> Language Class Initialized
INFO - 2023-04-23 17:24:39 --> Loader Class Initialized
INFO - 2023-04-23 17:24:39 --> Helper loaded: url_helper
INFO - 2023-04-23 17:24:39 --> Helper loaded: file_helper
INFO - 2023-04-23 17:24:39 --> Helper loaded: html_helper
INFO - 2023-04-23 17:24:39 --> Helper loaded: text_helper
INFO - 2023-04-23 17:24:39 --> Helper loaded: form_helper
INFO - 2023-04-23 17:24:39 --> Helper loaded: lang_helper
INFO - 2023-04-23 17:24:39 --> Helper loaded: security_helper
INFO - 2023-04-23 17:24:39 --> Helper loaded: cookie_helper
INFO - 2023-04-23 17:24:39 --> Database Driver Class Initialized
INFO - 2023-04-23 17:24:39 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-23 17:24:39 --> Parser Class Initialized
INFO - 2023-04-23 17:24:39 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-23 17:24:39 --> Pagination Class Initialized
INFO - 2023-04-23 17:24:39 --> Form Validation Class Initialized
INFO - 2023-04-23 17:24:39 --> Controller Class Initialized
INFO - 2023-04-23 17:24:39 --> Model Class Initialized
DEBUG - 2023-04-23 17:24:39 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-23 17:24:39 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2023-04-23 17:24:39 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-04-23 17:24:39 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-04-23 17:24:39 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-04-23 17:24:39 --> Model Class Initialized
INFO - 2023-04-23 17:24:39 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-04-23 17:24:39 --> Final output sent to browser
DEBUG - 2023-04-23 17:24:39 --> Total execution time: 0.0317
ERROR - 2023-04-23 17:24:52 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-23 17:24:52 --> Config Class Initialized
INFO - 2023-04-23 17:24:52 --> Hooks Class Initialized
DEBUG - 2023-04-23 17:24:52 --> UTF-8 Support Enabled
INFO - 2023-04-23 17:24:52 --> Utf8 Class Initialized
INFO - 2023-04-23 17:24:52 --> URI Class Initialized
INFO - 2023-04-23 17:24:52 --> Router Class Initialized
INFO - 2023-04-23 17:24:52 --> Output Class Initialized
INFO - 2023-04-23 17:24:52 --> Security Class Initialized
DEBUG - 2023-04-23 17:24:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-23 17:24:52 --> Input Class Initialized
INFO - 2023-04-23 17:24:52 --> Language Class Initialized
INFO - 2023-04-23 17:24:52 --> Loader Class Initialized
INFO - 2023-04-23 17:24:52 --> Helper loaded: url_helper
INFO - 2023-04-23 17:24:52 --> Helper loaded: file_helper
INFO - 2023-04-23 17:24:52 --> Helper loaded: html_helper
INFO - 2023-04-23 17:24:52 --> Helper loaded: text_helper
INFO - 2023-04-23 17:24:52 --> Helper loaded: form_helper
INFO - 2023-04-23 17:24:52 --> Helper loaded: lang_helper
INFO - 2023-04-23 17:24:52 --> Helper loaded: security_helper
INFO - 2023-04-23 17:24:52 --> Helper loaded: cookie_helper
INFO - 2023-04-23 17:24:52 --> Database Driver Class Initialized
INFO - 2023-04-23 17:24:52 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-23 17:24:52 --> Parser Class Initialized
INFO - 2023-04-23 17:24:52 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-23 17:24:52 --> Pagination Class Initialized
INFO - 2023-04-23 17:24:52 --> Form Validation Class Initialized
INFO - 2023-04-23 17:24:52 --> Controller Class Initialized
INFO - 2023-04-23 17:24:52 --> Model Class Initialized
DEBUG - 2023-04-23 17:24:52 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-23 17:24:52 --> Model Class Initialized
INFO - 2023-04-23 17:24:52 --> Final output sent to browser
DEBUG - 2023-04-23 17:24:52 --> Total execution time: 0.0183
ERROR - 2023-04-23 17:24:52 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-23 17:24:52 --> Config Class Initialized
INFO - 2023-04-23 17:24:52 --> Hooks Class Initialized
DEBUG - 2023-04-23 17:24:52 --> UTF-8 Support Enabled
INFO - 2023-04-23 17:24:52 --> Utf8 Class Initialized
INFO - 2023-04-23 17:24:52 --> URI Class Initialized
DEBUG - 2023-04-23 17:24:52 --> No URI present. Default controller set.
INFO - 2023-04-23 17:24:52 --> Router Class Initialized
INFO - 2023-04-23 17:24:52 --> Output Class Initialized
INFO - 2023-04-23 17:24:52 --> Security Class Initialized
DEBUG - 2023-04-23 17:24:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-23 17:24:52 --> Input Class Initialized
INFO - 2023-04-23 17:24:52 --> Language Class Initialized
INFO - 2023-04-23 17:24:52 --> Loader Class Initialized
INFO - 2023-04-23 17:24:52 --> Helper loaded: url_helper
INFO - 2023-04-23 17:24:52 --> Helper loaded: file_helper
INFO - 2023-04-23 17:24:52 --> Helper loaded: html_helper
INFO - 2023-04-23 17:24:52 --> Helper loaded: text_helper
INFO - 2023-04-23 17:24:52 --> Helper loaded: form_helper
INFO - 2023-04-23 17:24:52 --> Helper loaded: lang_helper
INFO - 2023-04-23 17:24:52 --> Helper loaded: security_helper
INFO - 2023-04-23 17:24:52 --> Helper loaded: cookie_helper
INFO - 2023-04-23 17:24:52 --> Database Driver Class Initialized
INFO - 2023-04-23 17:24:52 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-23 17:24:52 --> Parser Class Initialized
INFO - 2023-04-23 17:24:52 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-23 17:24:52 --> Pagination Class Initialized
INFO - 2023-04-23 17:24:52 --> Form Validation Class Initialized
INFO - 2023-04-23 17:24:52 --> Controller Class Initialized
INFO - 2023-04-23 17:24:52 --> Model Class Initialized
DEBUG - 2023-04-23 17:24:52 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-23 17:24:52 --> Model Class Initialized
DEBUG - 2023-04-23 17:24:52 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-23 17:24:52 --> Model Class Initialized
INFO - 2023-04-23 17:24:52 --> Model Class Initialized
INFO - 2023-04-23 17:24:52 --> Model Class Initialized
INFO - 2023-04-23 17:24:52 --> Model Class Initialized
DEBUG - 2023-04-23 17:24:52 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-04-23 17:24:52 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-23 17:24:52 --> Model Class Initialized
INFO - 2023-04-23 17:24:52 --> Model Class Initialized
INFO - 2023-04-23 17:24:52 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-04-23 17:24:52 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-04-23 17:24:52 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-04-23 17:24:52 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-04-23 17:24:52 --> Model Class Initialized
INFO - 2023-04-23 17:24:53 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-04-23 17:24:53 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-04-23 17:24:53 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-04-23 17:24:53 --> Final output sent to browser
DEBUG - 2023-04-23 17:24:53 --> Total execution time: 0.1711
ERROR - 2023-04-23 17:24:54 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-23 17:24:54 --> Config Class Initialized
INFO - 2023-04-23 17:24:54 --> Hooks Class Initialized
DEBUG - 2023-04-23 17:24:54 --> UTF-8 Support Enabled
INFO - 2023-04-23 17:24:54 --> Utf8 Class Initialized
INFO - 2023-04-23 17:24:54 --> URI Class Initialized
INFO - 2023-04-23 17:24:54 --> Router Class Initialized
INFO - 2023-04-23 17:24:54 --> Output Class Initialized
INFO - 2023-04-23 17:24:54 --> Security Class Initialized
DEBUG - 2023-04-23 17:24:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-23 17:24:54 --> Input Class Initialized
INFO - 2023-04-23 17:24:54 --> Language Class Initialized
INFO - 2023-04-23 17:24:54 --> Loader Class Initialized
INFO - 2023-04-23 17:24:54 --> Helper loaded: url_helper
INFO - 2023-04-23 17:24:54 --> Helper loaded: file_helper
INFO - 2023-04-23 17:24:54 --> Helper loaded: html_helper
INFO - 2023-04-23 17:24:54 --> Helper loaded: text_helper
INFO - 2023-04-23 17:24:54 --> Helper loaded: form_helper
INFO - 2023-04-23 17:24:54 --> Helper loaded: lang_helper
INFO - 2023-04-23 17:24:54 --> Helper loaded: security_helper
INFO - 2023-04-23 17:24:54 --> Helper loaded: cookie_helper
INFO - 2023-04-23 17:24:54 --> Database Driver Class Initialized
INFO - 2023-04-23 17:24:54 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-23 17:24:54 --> Parser Class Initialized
INFO - 2023-04-23 17:24:54 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-23 17:24:54 --> Pagination Class Initialized
INFO - 2023-04-23 17:24:54 --> Form Validation Class Initialized
INFO - 2023-04-23 17:24:54 --> Controller Class Initialized
DEBUG - 2023-04-23 17:24:54 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-04-23 17:24:54 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-23 17:24:54 --> Model Class Initialized
INFO - 2023-04-23 17:24:54 --> Final output sent to browser
DEBUG - 2023-04-23 17:24:54 --> Total execution time: 0.0131
ERROR - 2023-04-23 17:25:23 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-23 17:25:23 --> Config Class Initialized
INFO - 2023-04-23 17:25:23 --> Hooks Class Initialized
DEBUG - 2023-04-23 17:25:23 --> UTF-8 Support Enabled
INFO - 2023-04-23 17:25:23 --> Utf8 Class Initialized
INFO - 2023-04-23 17:25:23 --> URI Class Initialized
INFO - 2023-04-23 17:25:23 --> Router Class Initialized
INFO - 2023-04-23 17:25:23 --> Output Class Initialized
INFO - 2023-04-23 17:25:23 --> Security Class Initialized
DEBUG - 2023-04-23 17:25:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-23 17:25:23 --> Input Class Initialized
INFO - 2023-04-23 17:25:23 --> Language Class Initialized
INFO - 2023-04-23 17:25:23 --> Loader Class Initialized
INFO - 2023-04-23 17:25:23 --> Helper loaded: url_helper
INFO - 2023-04-23 17:25:23 --> Helper loaded: file_helper
INFO - 2023-04-23 17:25:23 --> Helper loaded: html_helper
INFO - 2023-04-23 17:25:23 --> Helper loaded: text_helper
INFO - 2023-04-23 17:25:23 --> Helper loaded: form_helper
INFO - 2023-04-23 17:25:23 --> Helper loaded: lang_helper
INFO - 2023-04-23 17:25:23 --> Helper loaded: security_helper
INFO - 2023-04-23 17:25:23 --> Helper loaded: cookie_helper
INFO - 2023-04-23 17:25:23 --> Database Driver Class Initialized
INFO - 2023-04-23 17:25:23 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-23 17:25:23 --> Parser Class Initialized
INFO - 2023-04-23 17:25:23 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-23 17:25:23 --> Pagination Class Initialized
INFO - 2023-04-23 17:25:23 --> Form Validation Class Initialized
INFO - 2023-04-23 17:25:23 --> Controller Class Initialized
INFO - 2023-04-23 17:25:23 --> Model Class Initialized
DEBUG - 2023-04-23 17:25:23 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-23 17:25:23 --> Model Class Initialized
INFO - 2023-04-23 17:25:23 --> Model Class Initialized
INFO - 2023-04-23 23:25:23 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/report/profit_lose_report.php
DEBUG - 2023-04-23 23:25:23 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-04-23 23:25:23 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-04-23 23:25:23 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-04-23 23:25:23 --> Model Class Initialized
INFO - 2023-04-23 23:25:23 --> Model Class Initialized
INFO - 2023-04-23 23:25:24 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-04-23 23:25:24 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-04-23 23:25:24 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-04-23 23:25:24 --> Final output sent to browser
DEBUG - 2023-04-23 23:25:24 --> Total execution time: 0.1442
ERROR - 2023-04-23 17:25:34 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-23 17:25:34 --> Config Class Initialized
INFO - 2023-04-23 17:25:34 --> Hooks Class Initialized
DEBUG - 2023-04-23 17:25:34 --> UTF-8 Support Enabled
INFO - 2023-04-23 17:25:34 --> Utf8 Class Initialized
INFO - 2023-04-23 17:25:34 --> URI Class Initialized
DEBUG - 2023-04-23 17:25:34 --> No URI present. Default controller set.
INFO - 2023-04-23 17:25:34 --> Router Class Initialized
INFO - 2023-04-23 17:25:34 --> Output Class Initialized
INFO - 2023-04-23 17:25:34 --> Security Class Initialized
DEBUG - 2023-04-23 17:25:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-23 17:25:34 --> Input Class Initialized
INFO - 2023-04-23 17:25:34 --> Language Class Initialized
INFO - 2023-04-23 17:25:34 --> Loader Class Initialized
INFO - 2023-04-23 17:25:34 --> Helper loaded: url_helper
INFO - 2023-04-23 17:25:34 --> Helper loaded: file_helper
INFO - 2023-04-23 17:25:34 --> Helper loaded: html_helper
INFO - 2023-04-23 17:25:34 --> Helper loaded: text_helper
INFO - 2023-04-23 17:25:34 --> Helper loaded: form_helper
INFO - 2023-04-23 17:25:34 --> Helper loaded: lang_helper
INFO - 2023-04-23 17:25:34 --> Helper loaded: security_helper
INFO - 2023-04-23 17:25:34 --> Helper loaded: cookie_helper
INFO - 2023-04-23 17:25:34 --> Database Driver Class Initialized
INFO - 2023-04-23 17:25:34 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-23 17:25:34 --> Parser Class Initialized
INFO - 2023-04-23 17:25:34 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-23 17:25:34 --> Pagination Class Initialized
INFO - 2023-04-23 17:25:34 --> Form Validation Class Initialized
INFO - 2023-04-23 17:25:34 --> Controller Class Initialized
INFO - 2023-04-23 17:25:34 --> Model Class Initialized
DEBUG - 2023-04-23 17:25:34 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-23 17:25:34 --> Model Class Initialized
DEBUG - 2023-04-23 17:25:34 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-23 17:25:34 --> Model Class Initialized
INFO - 2023-04-23 17:25:34 --> Model Class Initialized
INFO - 2023-04-23 17:25:34 --> Model Class Initialized
INFO - 2023-04-23 17:25:34 --> Model Class Initialized
DEBUG - 2023-04-23 17:25:34 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-04-23 17:25:34 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-23 17:25:34 --> Model Class Initialized
INFO - 2023-04-23 17:25:34 --> Model Class Initialized
INFO - 2023-04-23 17:25:34 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-04-23 17:25:34 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-04-23 17:25:34 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-04-23 17:25:34 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-04-23 17:25:34 --> Model Class Initialized
INFO - 2023-04-23 17:25:34 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-04-23 17:25:34 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-04-23 17:25:34 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-04-23 17:25:34 --> Final output sent to browser
DEBUG - 2023-04-23 17:25:34 --> Total execution time: 0.1845
ERROR - 2023-04-23 17:25:35 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-23 17:25:35 --> Config Class Initialized
INFO - 2023-04-23 17:25:35 --> Hooks Class Initialized
DEBUG - 2023-04-23 17:25:35 --> UTF-8 Support Enabled
INFO - 2023-04-23 17:25:35 --> Utf8 Class Initialized
INFO - 2023-04-23 17:25:35 --> URI Class Initialized
INFO - 2023-04-23 17:25:35 --> Router Class Initialized
INFO - 2023-04-23 17:25:35 --> Output Class Initialized
INFO - 2023-04-23 17:25:35 --> Security Class Initialized
DEBUG - 2023-04-23 17:25:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-23 17:25:35 --> Input Class Initialized
INFO - 2023-04-23 17:25:35 --> Language Class Initialized
INFO - 2023-04-23 17:25:35 --> Loader Class Initialized
INFO - 2023-04-23 17:25:35 --> Helper loaded: url_helper
INFO - 2023-04-23 17:25:35 --> Helper loaded: file_helper
INFO - 2023-04-23 17:25:35 --> Helper loaded: html_helper
INFO - 2023-04-23 17:25:35 --> Helper loaded: text_helper
INFO - 2023-04-23 17:25:35 --> Helper loaded: form_helper
INFO - 2023-04-23 17:25:35 --> Helper loaded: lang_helper
INFO - 2023-04-23 17:25:35 --> Helper loaded: security_helper
INFO - 2023-04-23 17:25:35 --> Helper loaded: cookie_helper
INFO - 2023-04-23 17:25:35 --> Database Driver Class Initialized
INFO - 2023-04-23 17:25:35 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-23 17:25:35 --> Parser Class Initialized
INFO - 2023-04-23 17:25:35 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-23 17:25:35 --> Pagination Class Initialized
INFO - 2023-04-23 17:25:35 --> Form Validation Class Initialized
INFO - 2023-04-23 17:25:35 --> Controller Class Initialized
INFO - 2023-04-23 17:25:35 --> Model Class Initialized
DEBUG - 2023-04-23 17:25:35 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-23 17:25:35 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2023-04-23 17:25:35 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-04-23 17:25:35 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-04-23 17:25:35 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-04-23 17:25:35 --> Model Class Initialized
INFO - 2023-04-23 17:25:35 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-04-23 17:25:35 --> Final output sent to browser
DEBUG - 2023-04-23 17:25:35 --> Total execution time: 0.0293
ERROR - 2023-04-23 17:25:35 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-23 17:25:35 --> Config Class Initialized
INFO - 2023-04-23 17:25:35 --> Hooks Class Initialized
DEBUG - 2023-04-23 17:25:35 --> UTF-8 Support Enabled
INFO - 2023-04-23 17:25:35 --> Utf8 Class Initialized
INFO - 2023-04-23 17:25:35 --> URI Class Initialized
INFO - 2023-04-23 17:25:35 --> Router Class Initialized
INFO - 2023-04-23 17:25:35 --> Output Class Initialized
INFO - 2023-04-23 17:25:35 --> Security Class Initialized
DEBUG - 2023-04-23 17:25:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-23 17:25:35 --> Input Class Initialized
INFO - 2023-04-23 17:25:35 --> Language Class Initialized
INFO - 2023-04-23 17:25:35 --> Loader Class Initialized
INFO - 2023-04-23 17:25:35 --> Helper loaded: url_helper
INFO - 2023-04-23 17:25:35 --> Helper loaded: file_helper
INFO - 2023-04-23 17:25:35 --> Helper loaded: html_helper
INFO - 2023-04-23 17:25:35 --> Helper loaded: text_helper
INFO - 2023-04-23 17:25:35 --> Helper loaded: form_helper
INFO - 2023-04-23 17:25:35 --> Helper loaded: lang_helper
INFO - 2023-04-23 17:25:35 --> Helper loaded: security_helper
INFO - 2023-04-23 17:25:35 --> Helper loaded: cookie_helper
INFO - 2023-04-23 17:25:35 --> Database Driver Class Initialized
INFO - 2023-04-23 17:25:35 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-23 17:25:35 --> Parser Class Initialized
INFO - 2023-04-23 17:25:35 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-23 17:25:35 --> Pagination Class Initialized
INFO - 2023-04-23 17:25:35 --> Form Validation Class Initialized
INFO - 2023-04-23 17:25:35 --> Controller Class Initialized
INFO - 2023-04-23 17:25:35 --> Model Class Initialized
DEBUG - 2023-04-23 17:25:35 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-23 17:25:35 --> Model Class Initialized
DEBUG - 2023-04-23 17:25:35 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-23 17:25:35 --> Model Class Initialized
INFO - 2023-04-23 17:25:35 --> Model Class Initialized
INFO - 2023-04-23 17:25:35 --> Model Class Initialized
INFO - 2023-04-23 17:25:35 --> Model Class Initialized
DEBUG - 2023-04-23 17:25:35 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-04-23 17:25:35 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-23 17:25:35 --> Model Class Initialized
INFO - 2023-04-23 17:25:35 --> Model Class Initialized
INFO - 2023-04-23 17:25:35 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-04-23 17:25:35 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-04-23 17:25:35 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-04-23 17:25:35 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-04-23 17:25:35 --> Model Class Initialized
INFO - 2023-04-23 17:25:35 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-04-23 17:25:35 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-04-23 17:25:35 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-04-23 17:25:35 --> Final output sent to browser
DEBUG - 2023-04-23 17:25:35 --> Total execution time: 0.1802
