<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2023-12-25 02:02:09 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-12-25 02:02:09 --> Config Class Initialized
INFO - 2023-12-25 02:02:09 --> Hooks Class Initialized
DEBUG - 2023-12-25 02:02:09 --> UTF-8 Support Enabled
INFO - 2023-12-25 02:02:09 --> Utf8 Class Initialized
INFO - 2023-12-25 02:02:09 --> URI Class Initialized
DEBUG - 2023-12-25 02:02:09 --> No URI present. Default controller set.
INFO - 2023-12-25 02:02:09 --> Router Class Initialized
INFO - 2023-12-25 02:02:09 --> Output Class Initialized
INFO - 2023-12-25 02:02:09 --> Security Class Initialized
DEBUG - 2023-12-25 02:02:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-25 02:02:09 --> Input Class Initialized
INFO - 2023-12-25 02:02:09 --> Language Class Initialized
INFO - 2023-12-25 02:02:09 --> Loader Class Initialized
INFO - 2023-12-25 02:02:09 --> Helper loaded: url_helper
INFO - 2023-12-25 02:02:09 --> Helper loaded: file_helper
INFO - 2023-12-25 02:02:09 --> Helper loaded: html_helper
INFO - 2023-12-25 02:02:09 --> Helper loaded: text_helper
INFO - 2023-12-25 02:02:09 --> Helper loaded: form_helper
INFO - 2023-12-25 02:02:09 --> Helper loaded: lang_helper
INFO - 2023-12-25 02:02:09 --> Helper loaded: security_helper
INFO - 2023-12-25 02:02:09 --> Helper loaded: cookie_helper
INFO - 2023-12-25 02:02:09 --> Database Driver Class Initialized
INFO - 2023-12-25 02:02:09 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-25 02:02:09 --> Parser Class Initialized
INFO - 2023-12-25 02:02:09 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-12-25 02:02:09 --> Pagination Class Initialized
INFO - 2023-12-25 02:02:09 --> Form Validation Class Initialized
INFO - 2023-12-25 02:02:09 --> Controller Class Initialized
INFO - 2023-12-25 02:02:09 --> Model Class Initialized
DEBUG - 2023-12-25 02:02:09 --> Session class already loaded. Second attempt ignored.
ERROR - 2023-12-25 02:02:10 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-12-25 02:02:10 --> Config Class Initialized
INFO - 2023-12-25 02:02:10 --> Hooks Class Initialized
DEBUG - 2023-12-25 02:02:10 --> UTF-8 Support Enabled
INFO - 2023-12-25 02:02:10 --> Utf8 Class Initialized
INFO - 2023-12-25 02:02:10 --> URI Class Initialized
INFO - 2023-12-25 02:02:10 --> Router Class Initialized
INFO - 2023-12-25 02:02:10 --> Output Class Initialized
INFO - 2023-12-25 02:02:10 --> Security Class Initialized
DEBUG - 2023-12-25 02:02:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-25 02:02:10 --> Input Class Initialized
INFO - 2023-12-25 02:02:10 --> Language Class Initialized
INFO - 2023-12-25 02:02:10 --> Loader Class Initialized
INFO - 2023-12-25 02:02:10 --> Helper loaded: url_helper
INFO - 2023-12-25 02:02:10 --> Helper loaded: file_helper
INFO - 2023-12-25 02:02:10 --> Helper loaded: html_helper
INFO - 2023-12-25 02:02:10 --> Helper loaded: text_helper
INFO - 2023-12-25 02:02:10 --> Helper loaded: form_helper
INFO - 2023-12-25 02:02:10 --> Helper loaded: lang_helper
INFO - 2023-12-25 02:02:10 --> Helper loaded: security_helper
INFO - 2023-12-25 02:02:10 --> Helper loaded: cookie_helper
INFO - 2023-12-25 02:02:10 --> Database Driver Class Initialized
INFO - 2023-12-25 02:02:10 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-25 02:02:10 --> Parser Class Initialized
INFO - 2023-12-25 02:02:10 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-12-25 02:02:10 --> Pagination Class Initialized
INFO - 2023-12-25 02:02:10 --> Form Validation Class Initialized
INFO - 2023-12-25 02:02:10 --> Controller Class Initialized
INFO - 2023-12-25 02:02:10 --> Model Class Initialized
DEBUG - 2023-12-25 02:02:10 --> Session class already loaded. Second attempt ignored.
INFO - 2023-12-25 02:02:10 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2023-12-25 02:02:10 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-12-25 02:02:10 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-12-25 02:02:10 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-12-25 02:02:10 --> Model Class Initialized
INFO - 2023-12-25 02:02:10 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-12-25 02:02:10 --> Final output sent to browser
DEBUG - 2023-12-25 02:02:10 --> Total execution time: 0.0318
ERROR - 2023-12-25 02:02:35 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-12-25 02:02:35 --> Config Class Initialized
INFO - 2023-12-25 02:02:35 --> Hooks Class Initialized
DEBUG - 2023-12-25 02:02:35 --> UTF-8 Support Enabled
INFO - 2023-12-25 02:02:35 --> Utf8 Class Initialized
INFO - 2023-12-25 02:02:35 --> URI Class Initialized
INFO - 2023-12-25 02:02:35 --> Router Class Initialized
INFO - 2023-12-25 02:02:35 --> Output Class Initialized
INFO - 2023-12-25 02:02:35 --> Security Class Initialized
DEBUG - 2023-12-25 02:02:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-25 02:02:35 --> Input Class Initialized
INFO - 2023-12-25 02:02:35 --> Language Class Initialized
INFO - 2023-12-25 02:02:35 --> Loader Class Initialized
INFO - 2023-12-25 02:02:35 --> Helper loaded: url_helper
INFO - 2023-12-25 02:02:35 --> Helper loaded: file_helper
INFO - 2023-12-25 02:02:35 --> Helper loaded: html_helper
INFO - 2023-12-25 02:02:35 --> Helper loaded: text_helper
INFO - 2023-12-25 02:02:35 --> Helper loaded: form_helper
INFO - 2023-12-25 02:02:35 --> Helper loaded: lang_helper
INFO - 2023-12-25 02:02:35 --> Helper loaded: security_helper
INFO - 2023-12-25 02:02:35 --> Helper loaded: cookie_helper
INFO - 2023-12-25 02:02:35 --> Database Driver Class Initialized
INFO - 2023-12-25 02:02:35 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-25 02:02:35 --> Parser Class Initialized
INFO - 2023-12-25 02:02:35 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-12-25 02:02:35 --> Pagination Class Initialized
INFO - 2023-12-25 02:02:35 --> Form Validation Class Initialized
INFO - 2023-12-25 02:02:35 --> Controller Class Initialized
INFO - 2023-12-25 02:02:35 --> Model Class Initialized
DEBUG - 2023-12-25 02:02:35 --> Session class already loaded. Second attempt ignored.
INFO - 2023-12-25 02:02:35 --> Model Class Initialized
INFO - 2023-12-25 02:02:35 --> Final output sent to browser
DEBUG - 2023-12-25 02:02:35 --> Total execution time: 0.0238
ERROR - 2023-12-25 02:02:36 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-12-25 02:02:36 --> Config Class Initialized
INFO - 2023-12-25 02:02:36 --> Hooks Class Initialized
DEBUG - 2023-12-25 02:02:36 --> UTF-8 Support Enabled
INFO - 2023-12-25 02:02:36 --> Utf8 Class Initialized
INFO - 2023-12-25 02:02:36 --> URI Class Initialized
DEBUG - 2023-12-25 02:02:36 --> No URI present. Default controller set.
INFO - 2023-12-25 02:02:36 --> Router Class Initialized
INFO - 2023-12-25 02:02:36 --> Output Class Initialized
INFO - 2023-12-25 02:02:36 --> Security Class Initialized
DEBUG - 2023-12-25 02:02:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-25 02:02:36 --> Input Class Initialized
INFO - 2023-12-25 02:02:36 --> Language Class Initialized
INFO - 2023-12-25 02:02:36 --> Loader Class Initialized
INFO - 2023-12-25 02:02:36 --> Helper loaded: url_helper
INFO - 2023-12-25 02:02:36 --> Helper loaded: file_helper
INFO - 2023-12-25 02:02:36 --> Helper loaded: html_helper
INFO - 2023-12-25 02:02:36 --> Helper loaded: text_helper
INFO - 2023-12-25 02:02:36 --> Helper loaded: form_helper
INFO - 2023-12-25 02:02:36 --> Helper loaded: lang_helper
INFO - 2023-12-25 02:02:36 --> Helper loaded: security_helper
INFO - 2023-12-25 02:02:36 --> Helper loaded: cookie_helper
INFO - 2023-12-25 02:02:36 --> Database Driver Class Initialized
INFO - 2023-12-25 02:02:36 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-25 02:02:36 --> Parser Class Initialized
INFO - 2023-12-25 02:02:36 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-12-25 02:02:36 --> Pagination Class Initialized
INFO - 2023-12-25 02:02:36 --> Form Validation Class Initialized
INFO - 2023-12-25 02:02:36 --> Controller Class Initialized
INFO - 2023-12-25 02:02:36 --> Model Class Initialized
DEBUG - 2023-12-25 02:02:36 --> Session class already loaded. Second attempt ignored.
INFO - 2023-12-25 02:02:36 --> Model Class Initialized
DEBUG - 2023-12-25 02:02:36 --> Session class already loaded. Second attempt ignored.
INFO - 2023-12-25 02:02:36 --> Model Class Initialized
INFO - 2023-12-25 02:02:36 --> Model Class Initialized
INFO - 2023-12-25 02:02:36 --> Model Class Initialized
INFO - 2023-12-25 02:02:36 --> Model Class Initialized
DEBUG - 2023-12-25 02:02:36 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-12-25 02:02:36 --> Session class already loaded. Second attempt ignored.
INFO - 2023-12-25 02:02:36 --> Model Class Initialized
INFO - 2023-12-25 02:02:36 --> Model Class Initialized
INFO - 2023-12-25 02:02:36 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-12-25 02:02:36 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-12-25 02:02:36 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-12-25 02:02:36 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-12-25 02:02:36 --> Model Class Initialized
INFO - 2023-12-25 02:02:36 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-12-25 02:02:36 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-12-25 02:02:36 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-12-25 02:02:36 --> Final output sent to browser
DEBUG - 2023-12-25 02:02:36 --> Total execution time: 0.2349
ERROR - 2023-12-25 02:02:43 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-12-25 02:02:43 --> Config Class Initialized
INFO - 2023-12-25 02:02:43 --> Hooks Class Initialized
DEBUG - 2023-12-25 02:02:43 --> UTF-8 Support Enabled
INFO - 2023-12-25 02:02:43 --> Utf8 Class Initialized
INFO - 2023-12-25 02:02:43 --> URI Class Initialized
INFO - 2023-12-25 02:02:43 --> Router Class Initialized
INFO - 2023-12-25 02:02:43 --> Output Class Initialized
INFO - 2023-12-25 02:02:43 --> Security Class Initialized
DEBUG - 2023-12-25 02:02:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-25 02:02:43 --> Input Class Initialized
INFO - 2023-12-25 02:02:43 --> Language Class Initialized
INFO - 2023-12-25 02:02:43 --> Loader Class Initialized
INFO - 2023-12-25 02:02:43 --> Helper loaded: url_helper
INFO - 2023-12-25 02:02:43 --> Helper loaded: file_helper
INFO - 2023-12-25 02:02:43 --> Helper loaded: html_helper
INFO - 2023-12-25 02:02:43 --> Helper loaded: text_helper
INFO - 2023-12-25 02:02:43 --> Helper loaded: form_helper
INFO - 2023-12-25 02:02:43 --> Helper loaded: lang_helper
INFO - 2023-12-25 02:02:43 --> Helper loaded: security_helper
INFO - 2023-12-25 02:02:43 --> Helper loaded: cookie_helper
INFO - 2023-12-25 02:02:43 --> Database Driver Class Initialized
INFO - 2023-12-25 02:02:43 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-25 02:02:43 --> Parser Class Initialized
INFO - 2023-12-25 02:02:43 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-12-25 02:02:43 --> Pagination Class Initialized
INFO - 2023-12-25 02:02:43 --> Form Validation Class Initialized
INFO - 2023-12-25 02:02:43 --> Controller Class Initialized
INFO - 2023-12-25 02:02:43 --> Model Class Initialized
DEBUG - 2023-12-25 02:02:43 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-12-25 02:02:43 --> Session class already loaded. Second attempt ignored.
INFO - 2023-12-25 02:02:43 --> Model Class Initialized
DEBUG - 2023-12-25 02:02:43 --> Session class already loaded. Second attempt ignored.
INFO - 2023-12-25 02:02:43 --> Model Class Initialized
INFO - 2023-12-25 02:02:43 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice.php
DEBUG - 2023-12-25 02:02:43 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-12-25 02:02:43 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-12-25 02:02:43 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-12-25 02:02:43 --> Model Class Initialized
INFO - 2023-12-25 02:02:43 --> Model Class Initialized
INFO - 2023-12-25 02:02:43 --> Model Class Initialized
INFO - 2023-12-25 02:02:43 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-12-25 02:02:43 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-12-25 02:02:43 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-12-25 02:02:43 --> Final output sent to browser
DEBUG - 2023-12-25 02:02:43 --> Total execution time: 0.1484
ERROR - 2023-12-25 02:02:44 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-12-25 02:02:44 --> Config Class Initialized
INFO - 2023-12-25 02:02:44 --> Hooks Class Initialized
DEBUG - 2023-12-25 02:02:44 --> UTF-8 Support Enabled
INFO - 2023-12-25 02:02:44 --> Utf8 Class Initialized
INFO - 2023-12-25 02:02:44 --> URI Class Initialized
INFO - 2023-12-25 02:02:44 --> Router Class Initialized
INFO - 2023-12-25 02:02:44 --> Output Class Initialized
INFO - 2023-12-25 02:02:44 --> Security Class Initialized
DEBUG - 2023-12-25 02:02:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-25 02:02:44 --> Input Class Initialized
INFO - 2023-12-25 02:02:44 --> Language Class Initialized
INFO - 2023-12-25 02:02:44 --> Loader Class Initialized
INFO - 2023-12-25 02:02:44 --> Helper loaded: url_helper
INFO - 2023-12-25 02:02:44 --> Helper loaded: file_helper
INFO - 2023-12-25 02:02:44 --> Helper loaded: html_helper
INFO - 2023-12-25 02:02:44 --> Helper loaded: text_helper
INFO - 2023-12-25 02:02:44 --> Helper loaded: form_helper
INFO - 2023-12-25 02:02:44 --> Helper loaded: lang_helper
INFO - 2023-12-25 02:02:44 --> Helper loaded: security_helper
INFO - 2023-12-25 02:02:44 --> Helper loaded: cookie_helper
INFO - 2023-12-25 02:02:44 --> Database Driver Class Initialized
INFO - 2023-12-25 02:02:44 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-25 02:02:44 --> Parser Class Initialized
INFO - 2023-12-25 02:02:44 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-12-25 02:02:44 --> Pagination Class Initialized
INFO - 2023-12-25 02:02:44 --> Form Validation Class Initialized
INFO - 2023-12-25 02:02:44 --> Controller Class Initialized
INFO - 2023-12-25 02:02:44 --> Model Class Initialized
DEBUG - 2023-12-25 02:02:44 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-12-25 02:02:44 --> Session class already loaded. Second attempt ignored.
INFO - 2023-12-25 02:02:44 --> Model Class Initialized
DEBUG - 2023-12-25 02:02:44 --> Session class already loaded. Second attempt ignored.
INFO - 2023-12-25 02:02:44 --> Model Class Initialized
INFO - 2023-12-25 02:02:44 --> Final output sent to browser
DEBUG - 2023-12-25 02:02:44 --> Total execution time: 0.0413
ERROR - 2023-12-25 02:02:48 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-12-25 02:02:48 --> Config Class Initialized
INFO - 2023-12-25 02:02:48 --> Hooks Class Initialized
DEBUG - 2023-12-25 02:02:48 --> UTF-8 Support Enabled
INFO - 2023-12-25 02:02:48 --> Utf8 Class Initialized
INFO - 2023-12-25 02:02:48 --> URI Class Initialized
INFO - 2023-12-25 02:02:48 --> Router Class Initialized
INFO - 2023-12-25 02:02:48 --> Output Class Initialized
INFO - 2023-12-25 02:02:48 --> Security Class Initialized
DEBUG - 2023-12-25 02:02:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-25 02:02:48 --> Input Class Initialized
INFO - 2023-12-25 02:02:48 --> Language Class Initialized
INFO - 2023-12-25 02:02:48 --> Loader Class Initialized
INFO - 2023-12-25 02:02:48 --> Helper loaded: url_helper
INFO - 2023-12-25 02:02:48 --> Helper loaded: file_helper
INFO - 2023-12-25 02:02:48 --> Helper loaded: html_helper
INFO - 2023-12-25 02:02:48 --> Helper loaded: text_helper
INFO - 2023-12-25 02:02:48 --> Helper loaded: form_helper
INFO - 2023-12-25 02:02:48 --> Helper loaded: lang_helper
INFO - 2023-12-25 02:02:48 --> Helper loaded: security_helper
INFO - 2023-12-25 02:02:48 --> Helper loaded: cookie_helper
INFO - 2023-12-25 02:02:48 --> Database Driver Class Initialized
INFO - 2023-12-25 02:02:48 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-25 02:02:48 --> Parser Class Initialized
INFO - 2023-12-25 02:02:48 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-12-25 02:02:48 --> Pagination Class Initialized
INFO - 2023-12-25 02:02:48 --> Form Validation Class Initialized
INFO - 2023-12-25 02:02:48 --> Controller Class Initialized
INFO - 2023-12-25 02:02:48 --> Model Class Initialized
DEBUG - 2023-12-25 02:02:48 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-12-25 02:02:48 --> Session class already loaded. Second attempt ignored.
INFO - 2023-12-25 02:02:48 --> Model Class Initialized
DEBUG - 2023-12-25 02:02:48 --> Session class already loaded. Second attempt ignored.
INFO - 2023-12-25 02:02:48 --> Model Class Initialized
INFO - 2023-12-25 02:02:48 --> Final output sent to browser
DEBUG - 2023-12-25 02:02:48 --> Total execution time: 0.0732
ERROR - 2023-12-25 02:03:58 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-12-25 02:03:58 --> Config Class Initialized
INFO - 2023-12-25 02:03:58 --> Hooks Class Initialized
DEBUG - 2023-12-25 02:03:58 --> UTF-8 Support Enabled
INFO - 2023-12-25 02:03:58 --> Utf8 Class Initialized
INFO - 2023-12-25 02:03:58 --> URI Class Initialized
DEBUG - 2023-12-25 02:03:58 --> No URI present. Default controller set.
INFO - 2023-12-25 02:03:58 --> Router Class Initialized
INFO - 2023-12-25 02:03:58 --> Output Class Initialized
INFO - 2023-12-25 02:03:58 --> Security Class Initialized
DEBUG - 2023-12-25 02:03:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-25 02:03:58 --> Input Class Initialized
INFO - 2023-12-25 02:03:58 --> Language Class Initialized
INFO - 2023-12-25 02:03:58 --> Loader Class Initialized
INFO - 2023-12-25 02:03:58 --> Helper loaded: url_helper
INFO - 2023-12-25 02:03:58 --> Helper loaded: file_helper
INFO - 2023-12-25 02:03:58 --> Helper loaded: html_helper
INFO - 2023-12-25 02:03:58 --> Helper loaded: text_helper
INFO - 2023-12-25 02:03:58 --> Helper loaded: form_helper
INFO - 2023-12-25 02:03:58 --> Helper loaded: lang_helper
INFO - 2023-12-25 02:03:58 --> Helper loaded: security_helper
INFO - 2023-12-25 02:03:58 --> Helper loaded: cookie_helper
INFO - 2023-12-25 02:03:58 --> Database Driver Class Initialized
INFO - 2023-12-25 02:03:58 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-25 02:03:58 --> Parser Class Initialized
INFO - 2023-12-25 02:03:58 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-12-25 02:03:58 --> Pagination Class Initialized
INFO - 2023-12-25 02:03:58 --> Form Validation Class Initialized
INFO - 2023-12-25 02:03:58 --> Controller Class Initialized
INFO - 2023-12-25 02:03:58 --> Model Class Initialized
DEBUG - 2023-12-25 02:03:58 --> Session class already loaded. Second attempt ignored.
INFO - 2023-12-25 02:03:58 --> Model Class Initialized
DEBUG - 2023-12-25 02:03:58 --> Session class already loaded. Second attempt ignored.
INFO - 2023-12-25 02:03:58 --> Model Class Initialized
INFO - 2023-12-25 02:03:58 --> Model Class Initialized
INFO - 2023-12-25 02:03:58 --> Model Class Initialized
INFO - 2023-12-25 02:03:58 --> Model Class Initialized
DEBUG - 2023-12-25 02:03:58 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-12-25 02:03:58 --> Session class already loaded. Second attempt ignored.
INFO - 2023-12-25 02:03:58 --> Model Class Initialized
INFO - 2023-12-25 02:03:58 --> Model Class Initialized
INFO - 2023-12-25 02:03:58 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-12-25 02:03:58 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-12-25 02:03:58 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-12-25 02:03:58 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-12-25 02:03:58 --> Model Class Initialized
INFO - 2023-12-25 02:03:58 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-12-25 02:03:58 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-12-25 02:03:58 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-12-25 02:03:58 --> Final output sent to browser
DEBUG - 2023-12-25 02:03:58 --> Total execution time: 0.2265
ERROR - 2023-12-25 02:03:58 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-12-25 02:03:58 --> Config Class Initialized
INFO - 2023-12-25 02:03:58 --> Hooks Class Initialized
DEBUG - 2023-12-25 02:03:58 --> UTF-8 Support Enabled
INFO - 2023-12-25 02:03:58 --> Utf8 Class Initialized
INFO - 2023-12-25 02:03:58 --> URI Class Initialized
INFO - 2023-12-25 02:03:58 --> Router Class Initialized
INFO - 2023-12-25 02:03:58 --> Output Class Initialized
INFO - 2023-12-25 02:03:58 --> Security Class Initialized
DEBUG - 2023-12-25 02:03:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-25 02:03:58 --> Input Class Initialized
INFO - 2023-12-25 02:03:58 --> Language Class Initialized
INFO - 2023-12-25 02:03:58 --> Loader Class Initialized
INFO - 2023-12-25 02:03:58 --> Helper loaded: url_helper
INFO - 2023-12-25 02:03:58 --> Helper loaded: file_helper
INFO - 2023-12-25 02:03:58 --> Helper loaded: html_helper
INFO - 2023-12-25 02:03:58 --> Helper loaded: text_helper
INFO - 2023-12-25 02:03:58 --> Helper loaded: form_helper
INFO - 2023-12-25 02:03:58 --> Helper loaded: lang_helper
INFO - 2023-12-25 02:03:58 --> Helper loaded: security_helper
INFO - 2023-12-25 02:03:58 --> Helper loaded: cookie_helper
INFO - 2023-12-25 02:03:58 --> Database Driver Class Initialized
INFO - 2023-12-25 02:03:58 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-25 02:03:58 --> Parser Class Initialized
INFO - 2023-12-25 02:03:58 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-12-25 02:03:58 --> Pagination Class Initialized
INFO - 2023-12-25 02:03:58 --> Form Validation Class Initialized
INFO - 2023-12-25 02:03:58 --> Controller Class Initialized
INFO - 2023-12-25 02:03:58 --> Model Class Initialized
DEBUG - 2023-12-25 02:03:58 --> Session class already loaded. Second attempt ignored.
INFO - 2023-12-25 02:03:58 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2023-12-25 02:03:58 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-12-25 02:03:58 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-12-25 02:03:58 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-12-25 02:03:58 --> Model Class Initialized
INFO - 2023-12-25 02:03:58 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-12-25 02:03:58 --> Final output sent to browser
DEBUG - 2023-12-25 02:03:58 --> Total execution time: 0.0290
ERROR - 2023-12-25 02:03:59 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-12-25 02:03:59 --> Config Class Initialized
INFO - 2023-12-25 02:03:59 --> Hooks Class Initialized
DEBUG - 2023-12-25 02:03:59 --> UTF-8 Support Enabled
INFO - 2023-12-25 02:03:59 --> Utf8 Class Initialized
INFO - 2023-12-25 02:03:59 --> URI Class Initialized
INFO - 2023-12-25 02:03:59 --> Router Class Initialized
INFO - 2023-12-25 02:03:59 --> Output Class Initialized
INFO - 2023-12-25 02:03:59 --> Security Class Initialized
DEBUG - 2023-12-25 02:03:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-25 02:03:59 --> Input Class Initialized
INFO - 2023-12-25 02:03:59 --> Language Class Initialized
INFO - 2023-12-25 02:03:59 --> Loader Class Initialized
INFO - 2023-12-25 02:03:59 --> Helper loaded: url_helper
INFO - 2023-12-25 02:03:59 --> Helper loaded: file_helper
INFO - 2023-12-25 02:03:59 --> Helper loaded: html_helper
INFO - 2023-12-25 02:03:59 --> Helper loaded: text_helper
INFO - 2023-12-25 02:03:59 --> Helper loaded: form_helper
INFO - 2023-12-25 02:03:59 --> Helper loaded: lang_helper
INFO - 2023-12-25 02:03:59 --> Helper loaded: security_helper
INFO - 2023-12-25 02:03:59 --> Helper loaded: cookie_helper
INFO - 2023-12-25 02:03:59 --> Database Driver Class Initialized
INFO - 2023-12-25 02:03:59 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-25 02:03:59 --> Parser Class Initialized
INFO - 2023-12-25 02:03:59 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-12-25 02:03:59 --> Pagination Class Initialized
INFO - 2023-12-25 02:03:59 --> Form Validation Class Initialized
INFO - 2023-12-25 02:03:59 --> Controller Class Initialized
INFO - 2023-12-25 02:03:59 --> Model Class Initialized
DEBUG - 2023-12-25 02:03:59 --> Session class already loaded. Second attempt ignored.
INFO - 2023-12-25 02:03:59 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2023-12-25 02:03:59 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-12-25 02:03:59 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-12-25 02:03:59 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-12-25 02:03:59 --> Model Class Initialized
INFO - 2023-12-25 02:03:59 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-12-25 02:03:59 --> Final output sent to browser
DEBUG - 2023-12-25 02:03:59 --> Total execution time: 0.0303
ERROR - 2023-12-25 02:03:59 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-12-25 02:03:59 --> Config Class Initialized
INFO - 2023-12-25 02:03:59 --> Hooks Class Initialized
DEBUG - 2023-12-25 02:03:59 --> UTF-8 Support Enabled
INFO - 2023-12-25 02:03:59 --> Utf8 Class Initialized
INFO - 2023-12-25 02:03:59 --> URI Class Initialized
INFO - 2023-12-25 02:03:59 --> Router Class Initialized
INFO - 2023-12-25 02:03:59 --> Output Class Initialized
INFO - 2023-12-25 02:03:59 --> Security Class Initialized
DEBUG - 2023-12-25 02:03:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-25 02:03:59 --> Input Class Initialized
INFO - 2023-12-25 02:03:59 --> Language Class Initialized
INFO - 2023-12-25 02:03:59 --> Loader Class Initialized
INFO - 2023-12-25 02:03:59 --> Helper loaded: url_helper
INFO - 2023-12-25 02:03:59 --> Helper loaded: file_helper
INFO - 2023-12-25 02:03:59 --> Helper loaded: html_helper
INFO - 2023-12-25 02:03:59 --> Helper loaded: text_helper
INFO - 2023-12-25 02:03:59 --> Helper loaded: form_helper
INFO - 2023-12-25 02:03:59 --> Helper loaded: lang_helper
INFO - 2023-12-25 02:03:59 --> Helper loaded: security_helper
INFO - 2023-12-25 02:03:59 --> Helper loaded: cookie_helper
INFO - 2023-12-25 02:03:59 --> Database Driver Class Initialized
INFO - 2023-12-25 02:03:59 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-25 02:03:59 --> Parser Class Initialized
INFO - 2023-12-25 02:03:59 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-12-25 02:03:59 --> Pagination Class Initialized
INFO - 2023-12-25 02:03:59 --> Form Validation Class Initialized
INFO - 2023-12-25 02:03:59 --> Controller Class Initialized
INFO - 2023-12-25 02:03:59 --> Model Class Initialized
DEBUG - 2023-12-25 02:03:59 --> Session class already loaded. Second attempt ignored.
INFO - 2023-12-25 02:03:59 --> Model Class Initialized
DEBUG - 2023-12-25 02:03:59 --> Session class already loaded. Second attempt ignored.
INFO - 2023-12-25 02:03:59 --> Model Class Initialized
INFO - 2023-12-25 02:03:59 --> Model Class Initialized
INFO - 2023-12-25 02:03:59 --> Model Class Initialized
INFO - 2023-12-25 02:03:59 --> Model Class Initialized
DEBUG - 2023-12-25 02:03:59 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-12-25 02:03:59 --> Session class already loaded. Second attempt ignored.
INFO - 2023-12-25 02:03:59 --> Model Class Initialized
INFO - 2023-12-25 02:03:59 --> Model Class Initialized
INFO - 2023-12-25 02:03:59 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-12-25 02:03:59 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-12-25 02:03:59 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-12-25 02:03:59 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-12-25 02:03:59 --> Model Class Initialized
INFO - 2023-12-25 02:03:59 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-12-25 02:03:59 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-12-25 02:03:59 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-12-25 02:03:59 --> Final output sent to browser
DEBUG - 2023-12-25 02:03:59 --> Total execution time: 0.2175
ERROR - 2023-12-25 04:21:16 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-12-25 04:21:16 --> Config Class Initialized
INFO - 2023-12-25 04:21:16 --> Hooks Class Initialized
DEBUG - 2023-12-25 04:21:16 --> UTF-8 Support Enabled
INFO - 2023-12-25 04:21:16 --> Utf8 Class Initialized
INFO - 2023-12-25 04:21:16 --> URI Class Initialized
INFO - 2023-12-25 04:21:16 --> Router Class Initialized
INFO - 2023-12-25 04:21:16 --> Output Class Initialized
INFO - 2023-12-25 04:21:16 --> Security Class Initialized
DEBUG - 2023-12-25 04:21:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-25 04:21:16 --> Input Class Initialized
INFO - 2023-12-25 04:21:16 --> Language Class Initialized
ERROR - 2023-12-25 04:21:16 --> 404 Page Not Found: Well-known/assetlinks.json
ERROR - 2023-12-25 05:33:41 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-12-25 05:33:41 --> Config Class Initialized
INFO - 2023-12-25 05:33:41 --> Hooks Class Initialized
DEBUG - 2023-12-25 05:33:41 --> UTF-8 Support Enabled
INFO - 2023-12-25 05:33:41 --> Utf8 Class Initialized
INFO - 2023-12-25 05:33:41 --> URI Class Initialized
DEBUG - 2023-12-25 05:33:41 --> No URI present. Default controller set.
INFO - 2023-12-25 05:33:41 --> Router Class Initialized
INFO - 2023-12-25 05:33:41 --> Output Class Initialized
INFO - 2023-12-25 05:33:41 --> Security Class Initialized
DEBUG - 2023-12-25 05:33:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-25 05:33:41 --> Input Class Initialized
INFO - 2023-12-25 05:33:41 --> Language Class Initialized
INFO - 2023-12-25 05:33:41 --> Loader Class Initialized
INFO - 2023-12-25 05:33:41 --> Helper loaded: url_helper
INFO - 2023-12-25 05:33:41 --> Helper loaded: file_helper
INFO - 2023-12-25 05:33:41 --> Helper loaded: html_helper
INFO - 2023-12-25 05:33:41 --> Helper loaded: text_helper
INFO - 2023-12-25 05:33:41 --> Helper loaded: form_helper
INFO - 2023-12-25 05:33:41 --> Helper loaded: lang_helper
INFO - 2023-12-25 05:33:41 --> Helper loaded: security_helper
INFO - 2023-12-25 05:33:41 --> Helper loaded: cookie_helper
INFO - 2023-12-25 05:33:41 --> Database Driver Class Initialized
INFO - 2023-12-25 05:33:41 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-25 05:33:41 --> Parser Class Initialized
INFO - 2023-12-25 05:33:41 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-12-25 05:33:41 --> Pagination Class Initialized
INFO - 2023-12-25 05:33:41 --> Form Validation Class Initialized
INFO - 2023-12-25 05:33:41 --> Controller Class Initialized
INFO - 2023-12-25 05:33:41 --> Model Class Initialized
DEBUG - 2023-12-25 05:33:41 --> Session class already loaded. Second attempt ignored.
ERROR - 2023-12-25 05:33:41 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-12-25 05:33:41 --> Config Class Initialized
INFO - 2023-12-25 05:33:41 --> Hooks Class Initialized
DEBUG - 2023-12-25 05:33:41 --> UTF-8 Support Enabled
INFO - 2023-12-25 05:33:41 --> Utf8 Class Initialized
INFO - 2023-12-25 05:33:41 --> URI Class Initialized
INFO - 2023-12-25 05:33:41 --> Router Class Initialized
INFO - 2023-12-25 05:33:41 --> Output Class Initialized
INFO - 2023-12-25 05:33:41 --> Security Class Initialized
DEBUG - 2023-12-25 05:33:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-25 05:33:41 --> Input Class Initialized
INFO - 2023-12-25 05:33:41 --> Language Class Initialized
INFO - 2023-12-25 05:33:41 --> Loader Class Initialized
INFO - 2023-12-25 05:33:41 --> Helper loaded: url_helper
INFO - 2023-12-25 05:33:41 --> Helper loaded: file_helper
INFO - 2023-12-25 05:33:41 --> Helper loaded: html_helper
INFO - 2023-12-25 05:33:41 --> Helper loaded: text_helper
INFO - 2023-12-25 05:33:42 --> Helper loaded: form_helper
INFO - 2023-12-25 05:33:42 --> Helper loaded: lang_helper
INFO - 2023-12-25 05:33:42 --> Helper loaded: security_helper
INFO - 2023-12-25 05:33:42 --> Helper loaded: cookie_helper
INFO - 2023-12-25 05:33:42 --> Database Driver Class Initialized
INFO - 2023-12-25 05:33:42 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-25 05:33:42 --> Parser Class Initialized
INFO - 2023-12-25 05:33:42 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-12-25 05:33:42 --> Pagination Class Initialized
INFO - 2023-12-25 05:33:42 --> Form Validation Class Initialized
INFO - 2023-12-25 05:33:42 --> Controller Class Initialized
INFO - 2023-12-25 05:33:42 --> Model Class Initialized
DEBUG - 2023-12-25 05:33:42 --> Session class already loaded. Second attempt ignored.
INFO - 2023-12-25 05:33:42 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2023-12-25 05:33:42 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-12-25 05:33:42 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-12-25 05:33:42 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-12-25 05:33:42 --> Model Class Initialized
INFO - 2023-12-25 05:33:42 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-12-25 05:33:42 --> Final output sent to browser
DEBUG - 2023-12-25 05:33:42 --> Total execution time: 0.0373
ERROR - 2023-12-25 05:48:14 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-12-25 05:48:14 --> Config Class Initialized
INFO - 2023-12-25 05:48:14 --> Hooks Class Initialized
DEBUG - 2023-12-25 05:48:14 --> UTF-8 Support Enabled
INFO - 2023-12-25 05:48:14 --> Utf8 Class Initialized
INFO - 2023-12-25 05:48:14 --> URI Class Initialized
DEBUG - 2023-12-25 05:48:14 --> No URI present. Default controller set.
INFO - 2023-12-25 05:48:14 --> Router Class Initialized
INFO - 2023-12-25 05:48:14 --> Output Class Initialized
INFO - 2023-12-25 05:48:14 --> Security Class Initialized
DEBUG - 2023-12-25 05:48:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-25 05:48:14 --> Input Class Initialized
INFO - 2023-12-25 05:48:14 --> Language Class Initialized
INFO - 2023-12-25 05:48:14 --> Loader Class Initialized
INFO - 2023-12-25 05:48:14 --> Helper loaded: url_helper
INFO - 2023-12-25 05:48:14 --> Helper loaded: file_helper
INFO - 2023-12-25 05:48:14 --> Helper loaded: html_helper
INFO - 2023-12-25 05:48:14 --> Helper loaded: text_helper
INFO - 2023-12-25 05:48:14 --> Helper loaded: form_helper
INFO - 2023-12-25 05:48:14 --> Helper loaded: lang_helper
INFO - 2023-12-25 05:48:14 --> Helper loaded: security_helper
INFO - 2023-12-25 05:48:14 --> Helper loaded: cookie_helper
INFO - 2023-12-25 05:48:14 --> Database Driver Class Initialized
INFO - 2023-12-25 05:48:14 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-25 05:48:14 --> Parser Class Initialized
INFO - 2023-12-25 05:48:14 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-12-25 05:48:14 --> Pagination Class Initialized
INFO - 2023-12-25 05:48:14 --> Form Validation Class Initialized
INFO - 2023-12-25 05:48:14 --> Controller Class Initialized
INFO - 2023-12-25 05:48:14 --> Model Class Initialized
DEBUG - 2023-12-25 05:48:14 --> Session class already loaded. Second attempt ignored.
ERROR - 2023-12-25 05:48:14 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-12-25 05:48:14 --> Config Class Initialized
INFO - 2023-12-25 05:48:14 --> Hooks Class Initialized
DEBUG - 2023-12-25 05:48:14 --> UTF-8 Support Enabled
INFO - 2023-12-25 05:48:14 --> Utf8 Class Initialized
INFO - 2023-12-25 05:48:14 --> URI Class Initialized
INFO - 2023-12-25 05:48:14 --> Router Class Initialized
INFO - 2023-12-25 05:48:14 --> Output Class Initialized
INFO - 2023-12-25 05:48:14 --> Security Class Initialized
DEBUG - 2023-12-25 05:48:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-25 05:48:14 --> Input Class Initialized
INFO - 2023-12-25 05:48:14 --> Language Class Initialized
INFO - 2023-12-25 05:48:14 --> Loader Class Initialized
INFO - 2023-12-25 05:48:14 --> Helper loaded: url_helper
INFO - 2023-12-25 05:48:14 --> Helper loaded: file_helper
INFO - 2023-12-25 05:48:14 --> Helper loaded: html_helper
INFO - 2023-12-25 05:48:14 --> Helper loaded: text_helper
INFO - 2023-12-25 05:48:14 --> Helper loaded: form_helper
INFO - 2023-12-25 05:48:14 --> Helper loaded: lang_helper
INFO - 2023-12-25 05:48:14 --> Helper loaded: security_helper
INFO - 2023-12-25 05:48:14 --> Helper loaded: cookie_helper
INFO - 2023-12-25 05:48:14 --> Database Driver Class Initialized
INFO - 2023-12-25 05:48:14 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-25 05:48:14 --> Parser Class Initialized
INFO - 2023-12-25 05:48:14 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-12-25 05:48:14 --> Pagination Class Initialized
INFO - 2023-12-25 05:48:14 --> Form Validation Class Initialized
INFO - 2023-12-25 05:48:14 --> Controller Class Initialized
INFO - 2023-12-25 05:48:14 --> Model Class Initialized
DEBUG - 2023-12-25 05:48:14 --> Session class already loaded. Second attempt ignored.
INFO - 2023-12-25 05:48:14 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2023-12-25 05:48:14 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-12-25 05:48:14 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-12-25 05:48:14 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-12-25 05:48:14 --> Model Class Initialized
INFO - 2023-12-25 05:48:14 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-12-25 05:48:14 --> Final output sent to browser
DEBUG - 2023-12-25 05:48:14 --> Total execution time: 0.0366
ERROR - 2023-12-25 05:48:26 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-12-25 05:48:26 --> Config Class Initialized
INFO - 2023-12-25 05:48:26 --> Hooks Class Initialized
DEBUG - 2023-12-25 05:48:26 --> UTF-8 Support Enabled
INFO - 2023-12-25 05:48:26 --> Utf8 Class Initialized
INFO - 2023-12-25 05:48:26 --> URI Class Initialized
INFO - 2023-12-25 05:48:26 --> Router Class Initialized
INFO - 2023-12-25 05:48:26 --> Output Class Initialized
INFO - 2023-12-25 05:48:26 --> Security Class Initialized
DEBUG - 2023-12-25 05:48:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-25 05:48:26 --> Input Class Initialized
INFO - 2023-12-25 05:48:26 --> Language Class Initialized
INFO - 2023-12-25 05:48:26 --> Loader Class Initialized
INFO - 2023-12-25 05:48:26 --> Helper loaded: url_helper
INFO - 2023-12-25 05:48:26 --> Helper loaded: file_helper
INFO - 2023-12-25 05:48:26 --> Helper loaded: html_helper
INFO - 2023-12-25 05:48:26 --> Helper loaded: text_helper
INFO - 2023-12-25 05:48:26 --> Helper loaded: form_helper
INFO - 2023-12-25 05:48:26 --> Helper loaded: lang_helper
INFO - 2023-12-25 05:48:26 --> Helper loaded: security_helper
INFO - 2023-12-25 05:48:26 --> Helper loaded: cookie_helper
INFO - 2023-12-25 05:48:26 --> Database Driver Class Initialized
INFO - 2023-12-25 05:48:26 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-25 05:48:26 --> Parser Class Initialized
INFO - 2023-12-25 05:48:26 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-12-25 05:48:26 --> Pagination Class Initialized
INFO - 2023-12-25 05:48:26 --> Form Validation Class Initialized
INFO - 2023-12-25 05:48:26 --> Controller Class Initialized
INFO - 2023-12-25 05:48:26 --> Model Class Initialized
DEBUG - 2023-12-25 05:48:26 --> Session class already loaded. Second attempt ignored.
INFO - 2023-12-25 05:48:26 --> Model Class Initialized
INFO - 2023-12-25 05:48:26 --> Final output sent to browser
DEBUG - 2023-12-25 05:48:26 --> Total execution time: 0.0231
ERROR - 2023-12-25 05:48:27 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-12-25 05:48:27 --> Config Class Initialized
INFO - 2023-12-25 05:48:27 --> Hooks Class Initialized
DEBUG - 2023-12-25 05:48:27 --> UTF-8 Support Enabled
INFO - 2023-12-25 05:48:27 --> Utf8 Class Initialized
INFO - 2023-12-25 05:48:27 --> URI Class Initialized
DEBUG - 2023-12-25 05:48:27 --> No URI present. Default controller set.
INFO - 2023-12-25 05:48:27 --> Router Class Initialized
INFO - 2023-12-25 05:48:27 --> Output Class Initialized
INFO - 2023-12-25 05:48:27 --> Security Class Initialized
DEBUG - 2023-12-25 05:48:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-25 05:48:27 --> Input Class Initialized
INFO - 2023-12-25 05:48:27 --> Language Class Initialized
INFO - 2023-12-25 05:48:27 --> Loader Class Initialized
INFO - 2023-12-25 05:48:27 --> Helper loaded: url_helper
INFO - 2023-12-25 05:48:27 --> Helper loaded: file_helper
INFO - 2023-12-25 05:48:27 --> Helper loaded: html_helper
INFO - 2023-12-25 05:48:27 --> Helper loaded: text_helper
INFO - 2023-12-25 05:48:27 --> Helper loaded: form_helper
INFO - 2023-12-25 05:48:27 --> Helper loaded: lang_helper
INFO - 2023-12-25 05:48:27 --> Helper loaded: security_helper
INFO - 2023-12-25 05:48:27 --> Helper loaded: cookie_helper
INFO - 2023-12-25 05:48:27 --> Database Driver Class Initialized
INFO - 2023-12-25 05:48:27 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-25 05:48:27 --> Parser Class Initialized
INFO - 2023-12-25 05:48:27 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-12-25 05:48:27 --> Pagination Class Initialized
INFO - 2023-12-25 05:48:27 --> Form Validation Class Initialized
INFO - 2023-12-25 05:48:27 --> Controller Class Initialized
INFO - 2023-12-25 05:48:27 --> Model Class Initialized
DEBUG - 2023-12-25 05:48:27 --> Session class already loaded. Second attempt ignored.
INFO - 2023-12-25 05:48:27 --> Model Class Initialized
DEBUG - 2023-12-25 05:48:27 --> Session class already loaded. Second attempt ignored.
INFO - 2023-12-25 05:48:27 --> Model Class Initialized
INFO - 2023-12-25 05:48:27 --> Model Class Initialized
INFO - 2023-12-25 05:48:27 --> Model Class Initialized
INFO - 2023-12-25 05:48:27 --> Model Class Initialized
DEBUG - 2023-12-25 05:48:27 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-12-25 05:48:27 --> Session class already loaded. Second attempt ignored.
INFO - 2023-12-25 05:48:27 --> Model Class Initialized
INFO - 2023-12-25 05:48:27 --> Model Class Initialized
INFO - 2023-12-25 05:48:27 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-12-25 05:48:27 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-12-25 05:48:27 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-12-25 05:48:27 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-12-25 05:48:27 --> Model Class Initialized
INFO - 2023-12-25 05:48:27 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-12-25 05:48:27 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-12-25 05:48:27 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-12-25 05:48:27 --> Final output sent to browser
DEBUG - 2023-12-25 05:48:27 --> Total execution time: 0.2351
ERROR - 2023-12-25 05:48:39 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-12-25 05:48:39 --> Config Class Initialized
INFO - 2023-12-25 05:48:39 --> Hooks Class Initialized
DEBUG - 2023-12-25 05:48:39 --> UTF-8 Support Enabled
INFO - 2023-12-25 05:48:39 --> Utf8 Class Initialized
INFO - 2023-12-25 05:48:39 --> URI Class Initialized
INFO - 2023-12-25 05:48:39 --> Router Class Initialized
INFO - 2023-12-25 05:48:39 --> Output Class Initialized
INFO - 2023-12-25 05:48:39 --> Security Class Initialized
DEBUG - 2023-12-25 05:48:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-25 05:48:39 --> Input Class Initialized
INFO - 2023-12-25 05:48:39 --> Language Class Initialized
INFO - 2023-12-25 05:48:39 --> Loader Class Initialized
INFO - 2023-12-25 05:48:39 --> Helper loaded: url_helper
INFO - 2023-12-25 05:48:39 --> Helper loaded: file_helper
INFO - 2023-12-25 05:48:39 --> Helper loaded: html_helper
INFO - 2023-12-25 05:48:39 --> Helper loaded: text_helper
INFO - 2023-12-25 05:48:39 --> Helper loaded: form_helper
INFO - 2023-12-25 05:48:39 --> Helper loaded: lang_helper
INFO - 2023-12-25 05:48:39 --> Helper loaded: security_helper
INFO - 2023-12-25 05:48:39 --> Helper loaded: cookie_helper
INFO - 2023-12-25 05:48:39 --> Database Driver Class Initialized
INFO - 2023-12-25 05:48:39 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-25 05:48:39 --> Parser Class Initialized
INFO - 2023-12-25 05:48:39 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-12-25 05:48:39 --> Pagination Class Initialized
INFO - 2023-12-25 05:48:39 --> Form Validation Class Initialized
INFO - 2023-12-25 05:48:39 --> Controller Class Initialized
INFO - 2023-12-25 05:48:39 --> Model Class Initialized
DEBUG - 2023-12-25 05:48:39 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-12-25 05:48:39 --> Session class already loaded. Second attempt ignored.
INFO - 2023-12-25 05:48:39 --> Model Class Initialized
INFO - 2023-12-25 05:48:39 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/stockrequest/inventory.php
DEBUG - 2023-12-25 05:48:39 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-12-25 05:48:39 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-12-25 05:48:39 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-12-25 05:48:39 --> Model Class Initialized
INFO - 2023-12-25 05:48:39 --> Model Class Initialized
INFO - 2023-12-25 05:48:39 --> Model Class Initialized
INFO - 2023-12-25 05:48:39 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-12-25 05:48:39 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-12-25 05:48:39 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-12-25 05:48:39 --> Final output sent to browser
DEBUG - 2023-12-25 05:48:39 --> Total execution time: 0.1464
ERROR - 2023-12-25 05:48:40 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-12-25 05:48:40 --> Config Class Initialized
INFO - 2023-12-25 05:48:40 --> Hooks Class Initialized
DEBUG - 2023-12-25 05:48:40 --> UTF-8 Support Enabled
INFO - 2023-12-25 05:48:40 --> Utf8 Class Initialized
INFO - 2023-12-25 05:48:40 --> URI Class Initialized
INFO - 2023-12-25 05:48:40 --> Router Class Initialized
INFO - 2023-12-25 05:48:40 --> Output Class Initialized
INFO - 2023-12-25 05:48:40 --> Security Class Initialized
DEBUG - 2023-12-25 05:48:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-25 05:48:40 --> Input Class Initialized
INFO - 2023-12-25 05:48:40 --> Language Class Initialized
INFO - 2023-12-25 05:48:40 --> Loader Class Initialized
INFO - 2023-12-25 05:48:40 --> Helper loaded: url_helper
INFO - 2023-12-25 05:48:40 --> Helper loaded: file_helper
INFO - 2023-12-25 05:48:40 --> Helper loaded: html_helper
INFO - 2023-12-25 05:48:40 --> Helper loaded: text_helper
INFO - 2023-12-25 05:48:40 --> Helper loaded: form_helper
INFO - 2023-12-25 05:48:40 --> Helper loaded: lang_helper
INFO - 2023-12-25 05:48:40 --> Helper loaded: security_helper
INFO - 2023-12-25 05:48:40 --> Helper loaded: cookie_helper
INFO - 2023-12-25 05:48:40 --> Database Driver Class Initialized
INFO - 2023-12-25 05:48:40 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-25 05:48:40 --> Parser Class Initialized
INFO - 2023-12-25 05:48:40 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-12-25 05:48:40 --> Pagination Class Initialized
INFO - 2023-12-25 05:48:40 --> Form Validation Class Initialized
INFO - 2023-12-25 05:48:40 --> Controller Class Initialized
INFO - 2023-12-25 05:48:40 --> Model Class Initialized
DEBUG - 2023-12-25 05:48:40 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-12-25 05:48:40 --> Session class already loaded. Second attempt ignored.
INFO - 2023-12-25 05:48:40 --> Model Class Initialized
INFO - 2023-12-25 05:48:40 --> Final output sent to browser
DEBUG - 2023-12-25 05:48:40 --> Total execution time: 0.0503
ERROR - 2023-12-25 05:48:45 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-12-25 05:48:45 --> Config Class Initialized
INFO - 2023-12-25 05:48:45 --> Hooks Class Initialized
DEBUG - 2023-12-25 05:48:45 --> UTF-8 Support Enabled
INFO - 2023-12-25 05:48:45 --> Utf8 Class Initialized
INFO - 2023-12-25 05:48:45 --> URI Class Initialized
INFO - 2023-12-25 05:48:45 --> Router Class Initialized
INFO - 2023-12-25 05:48:45 --> Output Class Initialized
INFO - 2023-12-25 05:48:45 --> Security Class Initialized
DEBUG - 2023-12-25 05:48:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-25 05:48:45 --> Input Class Initialized
INFO - 2023-12-25 05:48:45 --> Language Class Initialized
INFO - 2023-12-25 05:48:45 --> Loader Class Initialized
INFO - 2023-12-25 05:48:45 --> Helper loaded: url_helper
INFO - 2023-12-25 05:48:45 --> Helper loaded: file_helper
INFO - 2023-12-25 05:48:45 --> Helper loaded: html_helper
INFO - 2023-12-25 05:48:45 --> Helper loaded: text_helper
INFO - 2023-12-25 05:48:45 --> Helper loaded: form_helper
INFO - 2023-12-25 05:48:45 --> Helper loaded: lang_helper
INFO - 2023-12-25 05:48:45 --> Helper loaded: security_helper
INFO - 2023-12-25 05:48:45 --> Helper loaded: cookie_helper
INFO - 2023-12-25 05:48:45 --> Database Driver Class Initialized
INFO - 2023-12-25 05:48:45 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-25 05:48:45 --> Parser Class Initialized
INFO - 2023-12-25 05:48:45 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-12-25 05:48:45 --> Pagination Class Initialized
INFO - 2023-12-25 05:48:45 --> Form Validation Class Initialized
INFO - 2023-12-25 05:48:45 --> Controller Class Initialized
INFO - 2023-12-25 05:48:45 --> Model Class Initialized
DEBUG - 2023-12-25 05:48:45 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-12-25 05:48:45 --> Session class already loaded. Second attempt ignored.
INFO - 2023-12-25 05:48:45 --> Model Class Initialized
INFO - 2023-12-25 05:48:45 --> Final output sent to browser
DEBUG - 2023-12-25 05:48:45 --> Total execution time: 0.0492
ERROR - 2023-12-25 05:50:28 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-12-25 05:50:28 --> Config Class Initialized
INFO - 2023-12-25 05:50:28 --> Hooks Class Initialized
DEBUG - 2023-12-25 05:50:28 --> UTF-8 Support Enabled
INFO - 2023-12-25 05:50:28 --> Utf8 Class Initialized
INFO - 2023-12-25 05:50:28 --> URI Class Initialized
DEBUG - 2023-12-25 05:50:28 --> No URI present. Default controller set.
INFO - 2023-12-25 05:50:28 --> Router Class Initialized
INFO - 2023-12-25 05:50:28 --> Output Class Initialized
INFO - 2023-12-25 05:50:28 --> Security Class Initialized
DEBUG - 2023-12-25 05:50:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-25 05:50:28 --> Input Class Initialized
INFO - 2023-12-25 05:50:28 --> Language Class Initialized
INFO - 2023-12-25 05:50:28 --> Loader Class Initialized
INFO - 2023-12-25 05:50:28 --> Helper loaded: url_helper
INFO - 2023-12-25 05:50:28 --> Helper loaded: file_helper
INFO - 2023-12-25 05:50:28 --> Helper loaded: html_helper
INFO - 2023-12-25 05:50:28 --> Helper loaded: text_helper
INFO - 2023-12-25 05:50:28 --> Helper loaded: form_helper
INFO - 2023-12-25 05:50:28 --> Helper loaded: lang_helper
INFO - 2023-12-25 05:50:28 --> Helper loaded: security_helper
INFO - 2023-12-25 05:50:28 --> Helper loaded: cookie_helper
INFO - 2023-12-25 05:50:28 --> Database Driver Class Initialized
INFO - 2023-12-25 05:50:28 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-25 05:50:28 --> Parser Class Initialized
INFO - 2023-12-25 05:50:28 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-12-25 05:50:28 --> Pagination Class Initialized
INFO - 2023-12-25 05:50:28 --> Form Validation Class Initialized
INFO - 2023-12-25 05:50:28 --> Controller Class Initialized
INFO - 2023-12-25 05:50:28 --> Model Class Initialized
DEBUG - 2023-12-25 05:50:28 --> Session class already loaded. Second attempt ignored.
INFO - 2023-12-25 05:50:28 --> Model Class Initialized
DEBUG - 2023-12-25 05:50:28 --> Session class already loaded. Second attempt ignored.
INFO - 2023-12-25 05:50:28 --> Model Class Initialized
INFO - 2023-12-25 05:50:28 --> Model Class Initialized
INFO - 2023-12-25 05:50:28 --> Model Class Initialized
INFO - 2023-12-25 05:50:28 --> Model Class Initialized
DEBUG - 2023-12-25 05:50:28 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-12-25 05:50:28 --> Session class already loaded. Second attempt ignored.
INFO - 2023-12-25 05:50:28 --> Model Class Initialized
INFO - 2023-12-25 05:50:28 --> Model Class Initialized
ERROR - 2023-12-25 05:50:28 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-12-25 05:50:28 --> Config Class Initialized
INFO - 2023-12-25 05:50:28 --> Hooks Class Initialized
DEBUG - 2023-12-25 05:50:28 --> UTF-8 Support Enabled
INFO - 2023-12-25 05:50:28 --> Utf8 Class Initialized
INFO - 2023-12-25 05:50:28 --> URI Class Initialized
INFO - 2023-12-25 05:50:28 --> Router Class Initialized
INFO - 2023-12-25 05:50:28 --> Output Class Initialized
INFO - 2023-12-25 05:50:28 --> Security Class Initialized
DEBUG - 2023-12-25 05:50:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-25 05:50:28 --> Input Class Initialized
INFO - 2023-12-25 05:50:28 --> Language Class Initialized
INFO - 2023-12-25 05:50:28 --> Loader Class Initialized
INFO - 2023-12-25 05:50:28 --> Helper loaded: url_helper
INFO - 2023-12-25 05:50:28 --> Helper loaded: file_helper
INFO - 2023-12-25 05:50:28 --> Helper loaded: html_helper
INFO - 2023-12-25 05:50:28 --> Helper loaded: text_helper
INFO - 2023-12-25 05:50:28 --> Helper loaded: form_helper
INFO - 2023-12-25 05:50:28 --> Helper loaded: lang_helper
INFO - 2023-12-25 05:50:28 --> Helper loaded: security_helper
INFO - 2023-12-25 05:50:28 --> Helper loaded: cookie_helper
INFO - 2023-12-25 05:50:28 --> Database Driver Class Initialized
INFO - 2023-12-25 05:50:28 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-12-25 05:50:28 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-12-25 05:50:28 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-12-25 05:50:28 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-12-25 05:50:28 --> Model Class Initialized
INFO - 2023-12-25 05:50:28 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-12-25 05:50:28 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-12-25 05:50:28 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-12-25 05:50:28 --> Final output sent to browser
DEBUG - 2023-12-25 05:50:28 --> Total execution time: 0.2408
INFO - 2023-12-25 05:50:28 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-25 05:50:28 --> Parser Class Initialized
INFO - 2023-12-25 05:50:28 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-12-25 05:50:28 --> Pagination Class Initialized
INFO - 2023-12-25 05:50:28 --> Form Validation Class Initialized
INFO - 2023-12-25 05:50:28 --> Controller Class Initialized
INFO - 2023-12-25 05:50:28 --> Model Class Initialized
DEBUG - 2023-12-25 05:50:28 --> Session class already loaded. Second attempt ignored.
INFO - 2023-12-25 05:50:28 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2023-12-25 05:50:28 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-12-25 05:50:28 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-12-25 05:50:28 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-12-25 05:50:28 --> Model Class Initialized
INFO - 2023-12-25 05:50:28 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-12-25 05:50:28 --> Final output sent to browser
DEBUG - 2023-12-25 05:50:28 --> Total execution time: 0.1787
ERROR - 2023-12-25 05:50:29 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-12-25 05:50:29 --> Config Class Initialized
INFO - 2023-12-25 05:50:29 --> Hooks Class Initialized
DEBUG - 2023-12-25 05:50:29 --> UTF-8 Support Enabled
INFO - 2023-12-25 05:50:29 --> Utf8 Class Initialized
INFO - 2023-12-25 05:50:29 --> URI Class Initialized
INFO - 2023-12-25 05:50:29 --> Router Class Initialized
INFO - 2023-12-25 05:50:29 --> Output Class Initialized
INFO - 2023-12-25 05:50:29 --> Security Class Initialized
DEBUG - 2023-12-25 05:50:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-25 05:50:29 --> Input Class Initialized
INFO - 2023-12-25 05:50:29 --> Language Class Initialized
INFO - 2023-12-25 05:50:29 --> Loader Class Initialized
INFO - 2023-12-25 05:50:29 --> Helper loaded: url_helper
INFO - 2023-12-25 05:50:29 --> Helper loaded: file_helper
INFO - 2023-12-25 05:50:29 --> Helper loaded: html_helper
INFO - 2023-12-25 05:50:29 --> Helper loaded: text_helper
INFO - 2023-12-25 05:50:29 --> Helper loaded: form_helper
INFO - 2023-12-25 05:50:29 --> Helper loaded: lang_helper
INFO - 2023-12-25 05:50:29 --> Helper loaded: security_helper
INFO - 2023-12-25 05:50:29 --> Helper loaded: cookie_helper
INFO - 2023-12-25 05:50:29 --> Database Driver Class Initialized
INFO - 2023-12-25 05:50:29 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-25 05:50:29 --> Parser Class Initialized
INFO - 2023-12-25 05:50:29 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-12-25 05:50:29 --> Pagination Class Initialized
INFO - 2023-12-25 05:50:29 --> Form Validation Class Initialized
INFO - 2023-12-25 05:50:29 --> Controller Class Initialized
INFO - 2023-12-25 05:50:29 --> Model Class Initialized
DEBUG - 2023-12-25 05:50:29 --> Session class already loaded. Second attempt ignored.
INFO - 2023-12-25 05:50:29 --> Model Class Initialized
DEBUG - 2023-12-25 05:50:29 --> Session class already loaded. Second attempt ignored.
INFO - 2023-12-25 05:50:29 --> Model Class Initialized
INFO - 2023-12-25 05:50:29 --> Model Class Initialized
INFO - 2023-12-25 05:50:29 --> Model Class Initialized
INFO - 2023-12-25 05:50:29 --> Model Class Initialized
DEBUG - 2023-12-25 05:50:29 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-12-25 05:50:29 --> Session class already loaded. Second attempt ignored.
INFO - 2023-12-25 05:50:29 --> Model Class Initialized
INFO - 2023-12-25 05:50:29 --> Model Class Initialized
INFO - 2023-12-25 05:50:29 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-12-25 05:50:29 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-12-25 05:50:29 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-12-25 05:50:29 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-12-25 05:50:29 --> Model Class Initialized
INFO - 2023-12-25 05:50:29 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-12-25 05:50:29 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-12-25 05:50:29 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-12-25 05:50:29 --> Final output sent to browser
DEBUG - 2023-12-25 05:50:29 --> Total execution time: 0.2440
ERROR - 2023-12-25 07:26:44 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-12-25 07:26:44 --> Config Class Initialized
INFO - 2023-12-25 07:26:44 --> Hooks Class Initialized
DEBUG - 2023-12-25 07:26:44 --> UTF-8 Support Enabled
INFO - 2023-12-25 07:26:44 --> Utf8 Class Initialized
INFO - 2023-12-25 07:26:44 --> URI Class Initialized
DEBUG - 2023-12-25 07:26:44 --> No URI present. Default controller set.
INFO - 2023-12-25 07:26:44 --> Router Class Initialized
INFO - 2023-12-25 07:26:44 --> Output Class Initialized
INFO - 2023-12-25 07:26:44 --> Security Class Initialized
DEBUG - 2023-12-25 07:26:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-25 07:26:44 --> Input Class Initialized
INFO - 2023-12-25 07:26:44 --> Language Class Initialized
INFO - 2023-12-25 07:26:44 --> Loader Class Initialized
INFO - 2023-12-25 07:26:44 --> Helper loaded: url_helper
INFO - 2023-12-25 07:26:44 --> Helper loaded: file_helper
INFO - 2023-12-25 07:26:44 --> Helper loaded: html_helper
INFO - 2023-12-25 07:26:44 --> Helper loaded: text_helper
INFO - 2023-12-25 07:26:44 --> Helper loaded: form_helper
INFO - 2023-12-25 07:26:44 --> Helper loaded: lang_helper
INFO - 2023-12-25 07:26:44 --> Helper loaded: security_helper
INFO - 2023-12-25 07:26:44 --> Helper loaded: cookie_helper
INFO - 2023-12-25 07:26:44 --> Database Driver Class Initialized
INFO - 2023-12-25 07:26:44 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-25 07:26:44 --> Parser Class Initialized
INFO - 2023-12-25 07:26:44 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-12-25 07:26:44 --> Pagination Class Initialized
INFO - 2023-12-25 07:26:44 --> Form Validation Class Initialized
INFO - 2023-12-25 07:26:44 --> Controller Class Initialized
INFO - 2023-12-25 07:26:44 --> Model Class Initialized
DEBUG - 2023-12-25 07:26:44 --> Session class already loaded. Second attempt ignored.
ERROR - 2023-12-25 07:26:44 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-12-25 07:26:44 --> Config Class Initialized
INFO - 2023-12-25 07:26:44 --> Hooks Class Initialized
DEBUG - 2023-12-25 07:26:44 --> UTF-8 Support Enabled
INFO - 2023-12-25 07:26:44 --> Utf8 Class Initialized
INFO - 2023-12-25 07:26:44 --> URI Class Initialized
INFO - 2023-12-25 07:26:44 --> Router Class Initialized
INFO - 2023-12-25 07:26:44 --> Output Class Initialized
INFO - 2023-12-25 07:26:44 --> Security Class Initialized
DEBUG - 2023-12-25 07:26:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-25 07:26:44 --> Input Class Initialized
INFO - 2023-12-25 07:26:44 --> Language Class Initialized
INFO - 2023-12-25 07:26:44 --> Loader Class Initialized
INFO - 2023-12-25 07:26:44 --> Helper loaded: url_helper
INFO - 2023-12-25 07:26:44 --> Helper loaded: file_helper
INFO - 2023-12-25 07:26:44 --> Helper loaded: html_helper
INFO - 2023-12-25 07:26:44 --> Helper loaded: text_helper
INFO - 2023-12-25 07:26:44 --> Helper loaded: form_helper
INFO - 2023-12-25 07:26:44 --> Helper loaded: lang_helper
INFO - 2023-12-25 07:26:44 --> Helper loaded: security_helper
INFO - 2023-12-25 07:26:44 --> Helper loaded: cookie_helper
INFO - 2023-12-25 07:26:44 --> Database Driver Class Initialized
INFO - 2023-12-25 07:26:44 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-25 07:26:44 --> Parser Class Initialized
INFO - 2023-12-25 07:26:44 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-12-25 07:26:44 --> Pagination Class Initialized
INFO - 2023-12-25 07:26:44 --> Form Validation Class Initialized
INFO - 2023-12-25 07:26:44 --> Controller Class Initialized
INFO - 2023-12-25 07:26:44 --> Model Class Initialized
DEBUG - 2023-12-25 07:26:44 --> Session class already loaded. Second attempt ignored.
INFO - 2023-12-25 07:26:44 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2023-12-25 07:26:44 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-12-25 07:26:44 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-12-25 07:26:44 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-12-25 07:26:44 --> Model Class Initialized
INFO - 2023-12-25 07:26:44 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-12-25 07:26:44 --> Final output sent to browser
DEBUG - 2023-12-25 07:26:44 --> Total execution time: 0.0406
ERROR - 2023-12-25 07:26:48 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-12-25 07:26:48 --> Config Class Initialized
INFO - 2023-12-25 07:26:48 --> Hooks Class Initialized
DEBUG - 2023-12-25 07:26:48 --> UTF-8 Support Enabled
INFO - 2023-12-25 07:26:48 --> Utf8 Class Initialized
INFO - 2023-12-25 07:26:48 --> URI Class Initialized
INFO - 2023-12-25 07:26:48 --> Router Class Initialized
INFO - 2023-12-25 07:26:48 --> Output Class Initialized
INFO - 2023-12-25 07:26:48 --> Security Class Initialized
DEBUG - 2023-12-25 07:26:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-25 07:26:48 --> Input Class Initialized
INFO - 2023-12-25 07:26:48 --> Language Class Initialized
INFO - 2023-12-25 07:26:48 --> Loader Class Initialized
INFO - 2023-12-25 07:26:48 --> Helper loaded: url_helper
INFO - 2023-12-25 07:26:48 --> Helper loaded: file_helper
INFO - 2023-12-25 07:26:48 --> Helper loaded: html_helper
INFO - 2023-12-25 07:26:48 --> Helper loaded: text_helper
INFO - 2023-12-25 07:26:48 --> Helper loaded: form_helper
INFO - 2023-12-25 07:26:48 --> Helper loaded: lang_helper
INFO - 2023-12-25 07:26:48 --> Helper loaded: security_helper
INFO - 2023-12-25 07:26:48 --> Helper loaded: cookie_helper
INFO - 2023-12-25 07:26:48 --> Database Driver Class Initialized
INFO - 2023-12-25 07:26:48 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-25 07:26:48 --> Parser Class Initialized
INFO - 2023-12-25 07:26:48 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-12-25 07:26:48 --> Pagination Class Initialized
INFO - 2023-12-25 07:26:48 --> Form Validation Class Initialized
INFO - 2023-12-25 07:26:48 --> Controller Class Initialized
INFO - 2023-12-25 07:26:48 --> Model Class Initialized
DEBUG - 2023-12-25 07:26:48 --> Session class already loaded. Second attempt ignored.
INFO - 2023-12-25 07:26:48 --> Model Class Initialized
INFO - 2023-12-25 07:26:48 --> Final output sent to browser
DEBUG - 2023-12-25 07:26:48 --> Total execution time: 0.0181
ERROR - 2023-12-25 07:26:49 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-12-25 07:26:49 --> Config Class Initialized
INFO - 2023-12-25 07:26:49 --> Hooks Class Initialized
DEBUG - 2023-12-25 07:26:49 --> UTF-8 Support Enabled
INFO - 2023-12-25 07:26:49 --> Utf8 Class Initialized
INFO - 2023-12-25 07:26:49 --> URI Class Initialized
DEBUG - 2023-12-25 07:26:49 --> No URI present. Default controller set.
INFO - 2023-12-25 07:26:49 --> Router Class Initialized
INFO - 2023-12-25 07:26:49 --> Output Class Initialized
INFO - 2023-12-25 07:26:49 --> Security Class Initialized
DEBUG - 2023-12-25 07:26:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-25 07:26:49 --> Input Class Initialized
INFO - 2023-12-25 07:26:49 --> Language Class Initialized
INFO - 2023-12-25 07:26:49 --> Loader Class Initialized
INFO - 2023-12-25 07:26:49 --> Helper loaded: url_helper
INFO - 2023-12-25 07:26:49 --> Helper loaded: file_helper
INFO - 2023-12-25 07:26:49 --> Helper loaded: html_helper
INFO - 2023-12-25 07:26:49 --> Helper loaded: text_helper
INFO - 2023-12-25 07:26:49 --> Helper loaded: form_helper
INFO - 2023-12-25 07:26:49 --> Helper loaded: lang_helper
INFO - 2023-12-25 07:26:49 --> Helper loaded: security_helper
INFO - 2023-12-25 07:26:49 --> Helper loaded: cookie_helper
INFO - 2023-12-25 07:26:49 --> Database Driver Class Initialized
INFO - 2023-12-25 07:26:49 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-25 07:26:49 --> Parser Class Initialized
INFO - 2023-12-25 07:26:49 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-12-25 07:26:49 --> Pagination Class Initialized
INFO - 2023-12-25 07:26:49 --> Form Validation Class Initialized
INFO - 2023-12-25 07:26:49 --> Controller Class Initialized
INFO - 2023-12-25 07:26:49 --> Model Class Initialized
DEBUG - 2023-12-25 07:26:49 --> Session class already loaded. Second attempt ignored.
INFO - 2023-12-25 07:26:49 --> Model Class Initialized
DEBUG - 2023-12-25 07:26:49 --> Session class already loaded. Second attempt ignored.
INFO - 2023-12-25 07:26:49 --> Model Class Initialized
INFO - 2023-12-25 07:26:49 --> Model Class Initialized
INFO - 2023-12-25 07:26:49 --> Model Class Initialized
INFO - 2023-12-25 07:26:49 --> Model Class Initialized
DEBUG - 2023-12-25 07:26:49 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-12-25 07:26:49 --> Session class already loaded. Second attempt ignored.
INFO - 2023-12-25 07:26:49 --> Model Class Initialized
INFO - 2023-12-25 07:26:49 --> Model Class Initialized
INFO - 2023-12-25 07:26:49 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-12-25 07:26:49 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-12-25 07:26:49 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-12-25 07:26:49 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-12-25 07:26:49 --> Model Class Initialized
INFO - 2023-12-25 07:26:49 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-12-25 07:26:49 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-12-25 07:26:49 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-12-25 07:26:49 --> Final output sent to browser
DEBUG - 2023-12-25 07:26:49 --> Total execution time: 0.4224
ERROR - 2023-12-25 07:26:50 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-12-25 07:26:50 --> Config Class Initialized
INFO - 2023-12-25 07:26:50 --> Hooks Class Initialized
DEBUG - 2023-12-25 07:26:50 --> UTF-8 Support Enabled
INFO - 2023-12-25 07:26:50 --> Utf8 Class Initialized
INFO - 2023-12-25 07:26:50 --> URI Class Initialized
INFO - 2023-12-25 07:26:50 --> Router Class Initialized
INFO - 2023-12-25 07:26:50 --> Output Class Initialized
INFO - 2023-12-25 07:26:50 --> Security Class Initialized
DEBUG - 2023-12-25 07:26:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-25 07:26:50 --> Input Class Initialized
INFO - 2023-12-25 07:26:50 --> Language Class Initialized
INFO - 2023-12-25 07:26:50 --> Loader Class Initialized
INFO - 2023-12-25 07:26:50 --> Helper loaded: url_helper
INFO - 2023-12-25 07:26:50 --> Helper loaded: file_helper
INFO - 2023-12-25 07:26:50 --> Helper loaded: html_helper
INFO - 2023-12-25 07:26:50 --> Helper loaded: text_helper
INFO - 2023-12-25 07:26:50 --> Helper loaded: form_helper
INFO - 2023-12-25 07:26:50 --> Helper loaded: lang_helper
INFO - 2023-12-25 07:26:50 --> Helper loaded: security_helper
INFO - 2023-12-25 07:26:50 --> Helper loaded: cookie_helper
INFO - 2023-12-25 07:26:50 --> Database Driver Class Initialized
INFO - 2023-12-25 07:26:50 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-25 07:26:50 --> Parser Class Initialized
INFO - 2023-12-25 07:26:50 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-12-25 07:26:50 --> Pagination Class Initialized
INFO - 2023-12-25 07:26:50 --> Form Validation Class Initialized
INFO - 2023-12-25 07:26:50 --> Controller Class Initialized
DEBUG - 2023-12-25 07:26:50 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-12-25 07:26:50 --> Session class already loaded. Second attempt ignored.
INFO - 2023-12-25 07:26:50 --> Model Class Initialized
INFO - 2023-12-25 07:26:50 --> Final output sent to browser
DEBUG - 2023-12-25 07:26:50 --> Total execution time: 0.0156
ERROR - 2023-12-25 07:27:02 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-12-25 07:27:02 --> Config Class Initialized
INFO - 2023-12-25 07:27:02 --> Hooks Class Initialized
DEBUG - 2023-12-25 07:27:02 --> UTF-8 Support Enabled
INFO - 2023-12-25 07:27:02 --> Utf8 Class Initialized
INFO - 2023-12-25 07:27:02 --> URI Class Initialized
DEBUG - 2023-12-25 07:27:02 --> No URI present. Default controller set.
INFO - 2023-12-25 07:27:02 --> Router Class Initialized
INFO - 2023-12-25 07:27:02 --> Output Class Initialized
INFO - 2023-12-25 07:27:02 --> Security Class Initialized
DEBUG - 2023-12-25 07:27:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-25 07:27:02 --> Input Class Initialized
INFO - 2023-12-25 07:27:02 --> Language Class Initialized
INFO - 2023-12-25 07:27:02 --> Loader Class Initialized
INFO - 2023-12-25 07:27:02 --> Helper loaded: url_helper
INFO - 2023-12-25 07:27:02 --> Helper loaded: file_helper
INFO - 2023-12-25 07:27:02 --> Helper loaded: html_helper
INFO - 2023-12-25 07:27:02 --> Helper loaded: text_helper
INFO - 2023-12-25 07:27:02 --> Helper loaded: form_helper
INFO - 2023-12-25 07:27:02 --> Helper loaded: lang_helper
INFO - 2023-12-25 07:27:02 --> Helper loaded: security_helper
INFO - 2023-12-25 07:27:02 --> Helper loaded: cookie_helper
INFO - 2023-12-25 07:27:02 --> Database Driver Class Initialized
INFO - 2023-12-25 07:27:02 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-25 07:27:02 --> Parser Class Initialized
INFO - 2023-12-25 07:27:02 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-12-25 07:27:02 --> Pagination Class Initialized
INFO - 2023-12-25 07:27:02 --> Form Validation Class Initialized
INFO - 2023-12-25 07:27:02 --> Controller Class Initialized
INFO - 2023-12-25 07:27:02 --> Model Class Initialized
DEBUG - 2023-12-25 07:27:02 --> Session class already loaded. Second attempt ignored.
ERROR - 2023-12-25 07:27:03 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-12-25 07:27:03 --> Config Class Initialized
INFO - 2023-12-25 07:27:03 --> Hooks Class Initialized
DEBUG - 2023-12-25 07:27:03 --> UTF-8 Support Enabled
INFO - 2023-12-25 07:27:03 --> Utf8 Class Initialized
INFO - 2023-12-25 07:27:03 --> URI Class Initialized
INFO - 2023-12-25 07:27:03 --> Router Class Initialized
INFO - 2023-12-25 07:27:03 --> Output Class Initialized
INFO - 2023-12-25 07:27:03 --> Security Class Initialized
DEBUG - 2023-12-25 07:27:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-25 07:27:03 --> Input Class Initialized
INFO - 2023-12-25 07:27:03 --> Language Class Initialized
INFO - 2023-12-25 07:27:03 --> Loader Class Initialized
INFO - 2023-12-25 07:27:03 --> Helper loaded: url_helper
INFO - 2023-12-25 07:27:03 --> Helper loaded: file_helper
INFO - 2023-12-25 07:27:03 --> Helper loaded: html_helper
INFO - 2023-12-25 07:27:03 --> Helper loaded: text_helper
INFO - 2023-12-25 07:27:03 --> Helper loaded: form_helper
INFO - 2023-12-25 07:27:03 --> Helper loaded: lang_helper
INFO - 2023-12-25 07:27:03 --> Helper loaded: security_helper
INFO - 2023-12-25 07:27:03 --> Helper loaded: cookie_helper
INFO - 2023-12-25 07:27:03 --> Database Driver Class Initialized
INFO - 2023-12-25 07:27:03 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-25 07:27:03 --> Parser Class Initialized
INFO - 2023-12-25 07:27:03 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-12-25 07:27:03 --> Pagination Class Initialized
INFO - 2023-12-25 07:27:03 --> Form Validation Class Initialized
INFO - 2023-12-25 07:27:03 --> Controller Class Initialized
INFO - 2023-12-25 07:27:03 --> Model Class Initialized
DEBUG - 2023-12-25 07:27:03 --> Session class already loaded. Second attempt ignored.
INFO - 2023-12-25 07:27:03 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2023-12-25 07:27:03 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-12-25 07:27:03 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-12-25 07:27:03 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-12-25 07:27:03 --> Model Class Initialized
INFO - 2023-12-25 07:27:03 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-12-25 07:27:03 --> Final output sent to browser
DEBUG - 2023-12-25 07:27:03 --> Total execution time: 0.0356
ERROR - 2023-12-25 07:27:09 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-12-25 07:27:09 --> Config Class Initialized
INFO - 2023-12-25 07:27:09 --> Hooks Class Initialized
DEBUG - 2023-12-25 07:27:09 --> UTF-8 Support Enabled
INFO - 2023-12-25 07:27:09 --> Utf8 Class Initialized
INFO - 2023-12-25 07:27:09 --> URI Class Initialized
INFO - 2023-12-25 07:27:09 --> Router Class Initialized
INFO - 2023-12-25 07:27:09 --> Output Class Initialized
INFO - 2023-12-25 07:27:09 --> Security Class Initialized
DEBUG - 2023-12-25 07:27:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-25 07:27:09 --> Input Class Initialized
INFO - 2023-12-25 07:27:09 --> Language Class Initialized
INFO - 2023-12-25 07:27:09 --> Loader Class Initialized
INFO - 2023-12-25 07:27:09 --> Helper loaded: url_helper
INFO - 2023-12-25 07:27:09 --> Helper loaded: file_helper
INFO - 2023-12-25 07:27:09 --> Helper loaded: html_helper
INFO - 2023-12-25 07:27:09 --> Helper loaded: text_helper
INFO - 2023-12-25 07:27:09 --> Helper loaded: form_helper
INFO - 2023-12-25 07:27:09 --> Helper loaded: lang_helper
INFO - 2023-12-25 07:27:09 --> Helper loaded: security_helper
INFO - 2023-12-25 07:27:09 --> Helper loaded: cookie_helper
INFO - 2023-12-25 07:27:09 --> Database Driver Class Initialized
INFO - 2023-12-25 07:27:09 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-25 07:27:09 --> Parser Class Initialized
INFO - 2023-12-25 07:27:09 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-12-25 07:27:09 --> Pagination Class Initialized
INFO - 2023-12-25 07:27:09 --> Form Validation Class Initialized
INFO - 2023-12-25 07:27:09 --> Controller Class Initialized
INFO - 2023-12-25 07:27:09 --> Model Class Initialized
DEBUG - 2023-12-25 07:27:09 --> Session class already loaded. Second attempt ignored.
INFO - 2023-12-25 07:27:09 --> Model Class Initialized
INFO - 2023-12-25 07:27:09 --> Final output sent to browser
DEBUG - 2023-12-25 07:27:09 --> Total execution time: 0.0212
ERROR - 2023-12-25 07:27:10 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-12-25 07:27:10 --> Config Class Initialized
INFO - 2023-12-25 07:27:10 --> Hooks Class Initialized
DEBUG - 2023-12-25 07:27:10 --> UTF-8 Support Enabled
INFO - 2023-12-25 07:27:10 --> Utf8 Class Initialized
INFO - 2023-12-25 07:27:10 --> URI Class Initialized
DEBUG - 2023-12-25 07:27:10 --> No URI present. Default controller set.
INFO - 2023-12-25 07:27:10 --> Router Class Initialized
INFO - 2023-12-25 07:27:10 --> Output Class Initialized
INFO - 2023-12-25 07:27:10 --> Security Class Initialized
DEBUG - 2023-12-25 07:27:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-25 07:27:10 --> Input Class Initialized
INFO - 2023-12-25 07:27:10 --> Language Class Initialized
INFO - 2023-12-25 07:27:10 --> Loader Class Initialized
INFO - 2023-12-25 07:27:10 --> Helper loaded: url_helper
INFO - 2023-12-25 07:27:10 --> Helper loaded: file_helper
INFO - 2023-12-25 07:27:10 --> Helper loaded: html_helper
INFO - 2023-12-25 07:27:10 --> Helper loaded: text_helper
INFO - 2023-12-25 07:27:10 --> Helper loaded: form_helper
INFO - 2023-12-25 07:27:10 --> Helper loaded: lang_helper
INFO - 2023-12-25 07:27:10 --> Helper loaded: security_helper
INFO - 2023-12-25 07:27:10 --> Helper loaded: cookie_helper
INFO - 2023-12-25 07:27:10 --> Database Driver Class Initialized
INFO - 2023-12-25 07:27:10 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-25 07:27:10 --> Parser Class Initialized
INFO - 2023-12-25 07:27:10 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-12-25 07:27:10 --> Pagination Class Initialized
INFO - 2023-12-25 07:27:10 --> Form Validation Class Initialized
INFO - 2023-12-25 07:27:10 --> Controller Class Initialized
INFO - 2023-12-25 07:27:10 --> Model Class Initialized
DEBUG - 2023-12-25 07:27:10 --> Session class already loaded. Second attempt ignored.
INFO - 2023-12-25 07:27:10 --> Model Class Initialized
DEBUG - 2023-12-25 07:27:10 --> Session class already loaded. Second attempt ignored.
INFO - 2023-12-25 07:27:10 --> Model Class Initialized
INFO - 2023-12-25 07:27:10 --> Model Class Initialized
INFO - 2023-12-25 07:27:10 --> Model Class Initialized
INFO - 2023-12-25 07:27:10 --> Model Class Initialized
DEBUG - 2023-12-25 07:27:10 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-12-25 07:27:10 --> Session class already loaded. Second attempt ignored.
INFO - 2023-12-25 07:27:10 --> Model Class Initialized
INFO - 2023-12-25 07:27:10 --> Model Class Initialized
INFO - 2023-12-25 07:27:10 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-12-25 07:27:10 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-12-25 07:27:10 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-12-25 07:27:10 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-12-25 07:27:10 --> Model Class Initialized
INFO - 2023-12-25 07:27:10 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-12-25 07:27:10 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-12-25 07:27:10 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-12-25 07:27:10 --> Final output sent to browser
DEBUG - 2023-12-25 07:27:10 --> Total execution time: 0.4103
ERROR - 2023-12-25 07:27:11 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-12-25 07:27:11 --> Config Class Initialized
INFO - 2023-12-25 07:27:11 --> Hooks Class Initialized
DEBUG - 2023-12-25 07:27:11 --> UTF-8 Support Enabled
INFO - 2023-12-25 07:27:11 --> Utf8 Class Initialized
INFO - 2023-12-25 07:27:11 --> URI Class Initialized
INFO - 2023-12-25 07:27:11 --> Router Class Initialized
INFO - 2023-12-25 07:27:11 --> Output Class Initialized
INFO - 2023-12-25 07:27:11 --> Security Class Initialized
DEBUG - 2023-12-25 07:27:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-25 07:27:11 --> Input Class Initialized
INFO - 2023-12-25 07:27:11 --> Language Class Initialized
INFO - 2023-12-25 07:27:11 --> Loader Class Initialized
INFO - 2023-12-25 07:27:11 --> Helper loaded: url_helper
INFO - 2023-12-25 07:27:11 --> Helper loaded: file_helper
INFO - 2023-12-25 07:27:11 --> Helper loaded: html_helper
INFO - 2023-12-25 07:27:11 --> Helper loaded: text_helper
INFO - 2023-12-25 07:27:11 --> Helper loaded: form_helper
INFO - 2023-12-25 07:27:11 --> Helper loaded: lang_helper
INFO - 2023-12-25 07:27:11 --> Helper loaded: security_helper
INFO - 2023-12-25 07:27:11 --> Helper loaded: cookie_helper
INFO - 2023-12-25 07:27:11 --> Database Driver Class Initialized
INFO - 2023-12-25 07:27:11 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-25 07:27:11 --> Parser Class Initialized
INFO - 2023-12-25 07:27:11 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-12-25 07:27:11 --> Pagination Class Initialized
INFO - 2023-12-25 07:27:11 --> Form Validation Class Initialized
INFO - 2023-12-25 07:27:11 --> Controller Class Initialized
DEBUG - 2023-12-25 07:27:11 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-12-25 07:27:11 --> Session class already loaded. Second attempt ignored.
INFO - 2023-12-25 07:27:11 --> Model Class Initialized
INFO - 2023-12-25 07:27:11 --> Final output sent to browser
DEBUG - 2023-12-25 07:27:11 --> Total execution time: 0.0136
ERROR - 2023-12-25 07:28:51 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-12-25 07:28:51 --> Config Class Initialized
INFO - 2023-12-25 07:28:51 --> Hooks Class Initialized
DEBUG - 2023-12-25 07:28:51 --> UTF-8 Support Enabled
INFO - 2023-12-25 07:28:51 --> Utf8 Class Initialized
INFO - 2023-12-25 07:28:51 --> URI Class Initialized
DEBUG - 2023-12-25 07:28:51 --> No URI present. Default controller set.
INFO - 2023-12-25 07:28:51 --> Router Class Initialized
INFO - 2023-12-25 07:28:51 --> Output Class Initialized
INFO - 2023-12-25 07:28:51 --> Security Class Initialized
DEBUG - 2023-12-25 07:28:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-25 07:28:51 --> Input Class Initialized
INFO - 2023-12-25 07:28:51 --> Language Class Initialized
INFO - 2023-12-25 07:28:51 --> Loader Class Initialized
INFO - 2023-12-25 07:28:51 --> Helper loaded: url_helper
INFO - 2023-12-25 07:28:51 --> Helper loaded: file_helper
INFO - 2023-12-25 07:28:51 --> Helper loaded: html_helper
INFO - 2023-12-25 07:28:51 --> Helper loaded: text_helper
INFO - 2023-12-25 07:28:51 --> Helper loaded: form_helper
INFO - 2023-12-25 07:28:51 --> Helper loaded: lang_helper
INFO - 2023-12-25 07:28:51 --> Helper loaded: security_helper
INFO - 2023-12-25 07:28:51 --> Helper loaded: cookie_helper
INFO - 2023-12-25 07:28:51 --> Database Driver Class Initialized
INFO - 2023-12-25 07:28:51 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-25 07:28:51 --> Parser Class Initialized
INFO - 2023-12-25 07:28:51 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-12-25 07:28:51 --> Pagination Class Initialized
INFO - 2023-12-25 07:28:51 --> Form Validation Class Initialized
INFO - 2023-12-25 07:28:51 --> Controller Class Initialized
INFO - 2023-12-25 07:28:51 --> Model Class Initialized
DEBUG - 2023-12-25 07:28:51 --> Session class already loaded. Second attempt ignored.
INFO - 2023-12-25 07:28:51 --> Model Class Initialized
DEBUG - 2023-12-25 07:28:51 --> Session class already loaded. Second attempt ignored.
INFO - 2023-12-25 07:28:51 --> Model Class Initialized
INFO - 2023-12-25 07:28:51 --> Model Class Initialized
INFO - 2023-12-25 07:28:51 --> Model Class Initialized
INFO - 2023-12-25 07:28:51 --> Model Class Initialized
DEBUG - 2023-12-25 07:28:51 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-12-25 07:28:51 --> Session class already loaded. Second attempt ignored.
INFO - 2023-12-25 07:28:51 --> Model Class Initialized
INFO - 2023-12-25 07:28:51 --> Model Class Initialized
INFO - 2023-12-25 07:28:51 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-12-25 07:28:51 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-12-25 07:28:51 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-12-25 07:28:51 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-12-25 07:28:51 --> Model Class Initialized
INFO - 2023-12-25 07:28:51 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-12-25 07:28:51 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-12-25 07:28:51 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-12-25 07:28:51 --> Final output sent to browser
DEBUG - 2023-12-25 07:28:51 --> Total execution time: 0.4027
ERROR - 2023-12-25 07:28:57 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-12-25 07:28:57 --> Config Class Initialized
INFO - 2023-12-25 07:28:57 --> Hooks Class Initialized
DEBUG - 2023-12-25 07:28:57 --> UTF-8 Support Enabled
INFO - 2023-12-25 07:28:57 --> Utf8 Class Initialized
INFO - 2023-12-25 07:28:57 --> URI Class Initialized
INFO - 2023-12-25 07:28:57 --> Router Class Initialized
INFO - 2023-12-25 07:28:57 --> Output Class Initialized
INFO - 2023-12-25 07:28:57 --> Security Class Initialized
DEBUG - 2023-12-25 07:28:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-25 07:28:57 --> Input Class Initialized
INFO - 2023-12-25 07:28:57 --> Language Class Initialized
INFO - 2023-12-25 07:28:57 --> Loader Class Initialized
INFO - 2023-12-25 07:28:57 --> Helper loaded: url_helper
INFO - 2023-12-25 07:28:57 --> Helper loaded: file_helper
INFO - 2023-12-25 07:28:57 --> Helper loaded: html_helper
INFO - 2023-12-25 07:28:57 --> Helper loaded: text_helper
INFO - 2023-12-25 07:28:57 --> Helper loaded: form_helper
INFO - 2023-12-25 07:28:57 --> Helper loaded: lang_helper
INFO - 2023-12-25 07:28:57 --> Helper loaded: security_helper
INFO - 2023-12-25 07:28:57 --> Helper loaded: cookie_helper
INFO - 2023-12-25 07:28:57 --> Database Driver Class Initialized
INFO - 2023-12-25 07:28:57 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-25 07:28:57 --> Parser Class Initialized
INFO - 2023-12-25 07:28:57 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-12-25 07:28:57 --> Pagination Class Initialized
INFO - 2023-12-25 07:28:57 --> Form Validation Class Initialized
INFO - 2023-12-25 07:28:57 --> Controller Class Initialized
INFO - 2023-12-25 07:28:57 --> Model Class Initialized
DEBUG - 2023-12-25 07:28:57 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-12-25 07:28:57 --> Session class already loaded. Second attempt ignored.
INFO - 2023-12-25 07:28:57 --> Model Class Initialized
DEBUG - 2023-12-25 07:28:57 --> Session class already loaded. Second attempt ignored.
INFO - 2023-12-25 07:28:57 --> Model Class Initialized
INFO - 2023-12-25 07:28:57 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice.php
DEBUG - 2023-12-25 07:28:57 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-12-25 07:28:57 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-12-25 07:28:57 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-12-25 07:28:57 --> Model Class Initialized
INFO - 2023-12-25 07:28:57 --> Model Class Initialized
INFO - 2023-12-25 07:28:57 --> Model Class Initialized
INFO - 2023-12-25 07:28:57 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-12-25 07:28:57 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-12-25 07:28:57 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-12-25 07:28:57 --> Final output sent to browser
DEBUG - 2023-12-25 07:28:57 --> Total execution time: 0.2152
ERROR - 2023-12-25 07:28:58 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-12-25 07:28:58 --> Config Class Initialized
INFO - 2023-12-25 07:28:58 --> Hooks Class Initialized
DEBUG - 2023-12-25 07:28:58 --> UTF-8 Support Enabled
INFO - 2023-12-25 07:28:58 --> Utf8 Class Initialized
INFO - 2023-12-25 07:28:58 --> URI Class Initialized
INFO - 2023-12-25 07:28:58 --> Router Class Initialized
INFO - 2023-12-25 07:28:58 --> Output Class Initialized
INFO - 2023-12-25 07:28:58 --> Security Class Initialized
DEBUG - 2023-12-25 07:28:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-25 07:28:58 --> Input Class Initialized
INFO - 2023-12-25 07:28:58 --> Language Class Initialized
INFO - 2023-12-25 07:28:58 --> Loader Class Initialized
INFO - 2023-12-25 07:28:58 --> Helper loaded: url_helper
INFO - 2023-12-25 07:28:58 --> Helper loaded: file_helper
INFO - 2023-12-25 07:28:58 --> Helper loaded: html_helper
INFO - 2023-12-25 07:28:58 --> Helper loaded: text_helper
INFO - 2023-12-25 07:28:58 --> Helper loaded: form_helper
INFO - 2023-12-25 07:28:58 --> Helper loaded: lang_helper
INFO - 2023-12-25 07:28:58 --> Helper loaded: security_helper
INFO - 2023-12-25 07:28:58 --> Helper loaded: cookie_helper
INFO - 2023-12-25 07:28:58 --> Database Driver Class Initialized
INFO - 2023-12-25 07:28:58 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-25 07:28:58 --> Parser Class Initialized
INFO - 2023-12-25 07:28:58 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-12-25 07:28:58 --> Pagination Class Initialized
INFO - 2023-12-25 07:28:58 --> Form Validation Class Initialized
INFO - 2023-12-25 07:28:58 --> Controller Class Initialized
INFO - 2023-12-25 07:28:58 --> Model Class Initialized
DEBUG - 2023-12-25 07:28:58 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-12-25 07:28:58 --> Session class already loaded. Second attempt ignored.
INFO - 2023-12-25 07:28:58 --> Model Class Initialized
DEBUG - 2023-12-25 07:28:58 --> Session class already loaded. Second attempt ignored.
INFO - 2023-12-25 07:28:58 --> Model Class Initialized
INFO - 2023-12-25 07:28:58 --> Final output sent to browser
DEBUG - 2023-12-25 07:28:58 --> Total execution time: 0.0551
ERROR - 2023-12-25 07:29:14 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-12-25 07:29:14 --> Config Class Initialized
INFO - 2023-12-25 07:29:14 --> Hooks Class Initialized
DEBUG - 2023-12-25 07:29:14 --> UTF-8 Support Enabled
INFO - 2023-12-25 07:29:14 --> Utf8 Class Initialized
INFO - 2023-12-25 07:29:14 --> URI Class Initialized
INFO - 2023-12-25 07:29:14 --> Router Class Initialized
INFO - 2023-12-25 07:29:14 --> Output Class Initialized
INFO - 2023-12-25 07:29:14 --> Security Class Initialized
DEBUG - 2023-12-25 07:29:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-25 07:29:14 --> Input Class Initialized
INFO - 2023-12-25 07:29:14 --> Language Class Initialized
INFO - 2023-12-25 07:29:14 --> Loader Class Initialized
INFO - 2023-12-25 07:29:14 --> Helper loaded: url_helper
INFO - 2023-12-25 07:29:14 --> Helper loaded: file_helper
INFO - 2023-12-25 07:29:14 --> Helper loaded: html_helper
INFO - 2023-12-25 07:29:14 --> Helper loaded: text_helper
INFO - 2023-12-25 07:29:14 --> Helper loaded: form_helper
INFO - 2023-12-25 07:29:14 --> Helper loaded: lang_helper
INFO - 2023-12-25 07:29:14 --> Helper loaded: security_helper
INFO - 2023-12-25 07:29:14 --> Helper loaded: cookie_helper
INFO - 2023-12-25 07:29:14 --> Database Driver Class Initialized
INFO - 2023-12-25 07:29:14 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-25 07:29:14 --> Parser Class Initialized
INFO - 2023-12-25 07:29:14 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-12-25 07:29:14 --> Pagination Class Initialized
INFO - 2023-12-25 07:29:14 --> Form Validation Class Initialized
INFO - 2023-12-25 07:29:14 --> Controller Class Initialized
INFO - 2023-12-25 07:29:14 --> Model Class Initialized
DEBUG - 2023-12-25 07:29:14 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-12-25 07:29:14 --> Session class already loaded. Second attempt ignored.
INFO - 2023-12-25 07:29:14 --> Model Class Initialized
DEBUG - 2023-12-25 07:29:14 --> Session class already loaded. Second attempt ignored.
INFO - 2023-12-25 07:29:14 --> Model Class Initialized
DEBUG - 2023-12-25 07:29:14 --> Session class already loaded. Second attempt ignored.
INFO - 2023-12-25 07:29:14 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice_html.php
DEBUG - 2023-12-25 07:29:14 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-12-25 07:29:14 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-12-25 07:29:14 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-12-25 07:29:14 --> Model Class Initialized
INFO - 2023-12-25 07:29:14 --> Model Class Initialized
INFO - 2023-12-25 07:29:14 --> Model Class Initialized
INFO - 2023-12-25 07:29:14 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-12-25 07:29:14 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-12-25 07:29:14 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-12-25 07:29:14 --> Final output sent to browser
DEBUG - 2023-12-25 07:29:14 --> Total execution time: 0.2206
ERROR - 2023-12-25 07:29:41 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-12-25 07:29:41 --> Config Class Initialized
INFO - 2023-12-25 07:29:41 --> Hooks Class Initialized
DEBUG - 2023-12-25 07:29:41 --> UTF-8 Support Enabled
INFO - 2023-12-25 07:29:41 --> Utf8 Class Initialized
INFO - 2023-12-25 07:29:41 --> URI Class Initialized
INFO - 2023-12-25 07:29:41 --> Router Class Initialized
INFO - 2023-12-25 07:29:41 --> Output Class Initialized
INFO - 2023-12-25 07:29:41 --> Security Class Initialized
DEBUG - 2023-12-25 07:29:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-25 07:29:41 --> Input Class Initialized
INFO - 2023-12-25 07:29:41 --> Language Class Initialized
INFO - 2023-12-25 07:29:41 --> Loader Class Initialized
INFO - 2023-12-25 07:29:41 --> Helper loaded: url_helper
INFO - 2023-12-25 07:29:41 --> Helper loaded: file_helper
INFO - 2023-12-25 07:29:41 --> Helper loaded: html_helper
INFO - 2023-12-25 07:29:41 --> Helper loaded: text_helper
INFO - 2023-12-25 07:29:41 --> Helper loaded: form_helper
INFO - 2023-12-25 07:29:41 --> Helper loaded: lang_helper
INFO - 2023-12-25 07:29:41 --> Helper loaded: security_helper
INFO - 2023-12-25 07:29:41 --> Helper loaded: cookie_helper
INFO - 2023-12-25 07:29:41 --> Database Driver Class Initialized
INFO - 2023-12-25 07:29:41 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-25 07:29:41 --> Parser Class Initialized
INFO - 2023-12-25 07:29:41 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-12-25 07:29:41 --> Pagination Class Initialized
INFO - 2023-12-25 07:29:41 --> Form Validation Class Initialized
INFO - 2023-12-25 07:29:41 --> Controller Class Initialized
INFO - 2023-12-25 07:29:41 --> Model Class Initialized
DEBUG - 2023-12-25 07:29:41 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-12-25 07:29:41 --> Session class already loaded. Second attempt ignored.
INFO - 2023-12-25 07:29:41 --> Model Class Initialized
DEBUG - 2023-12-25 07:29:41 --> Session class already loaded. Second attempt ignored.
INFO - 2023-12-25 07:29:41 --> Model Class Initialized
INFO - 2023-12-25 07:29:41 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice.php
DEBUG - 2023-12-25 07:29:41 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-12-25 07:29:41 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-12-25 07:29:41 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-12-25 07:29:41 --> Model Class Initialized
INFO - 2023-12-25 07:29:41 --> Model Class Initialized
INFO - 2023-12-25 07:29:41 --> Model Class Initialized
INFO - 2023-12-25 07:29:41 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-12-25 07:29:41 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-12-25 07:29:41 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-12-25 07:29:41 --> Final output sent to browser
DEBUG - 2023-12-25 07:29:41 --> Total execution time: 0.2092
ERROR - 2023-12-25 07:29:42 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-12-25 07:29:42 --> Config Class Initialized
INFO - 2023-12-25 07:29:42 --> Hooks Class Initialized
DEBUG - 2023-12-25 07:29:42 --> UTF-8 Support Enabled
INFO - 2023-12-25 07:29:42 --> Utf8 Class Initialized
INFO - 2023-12-25 07:29:42 --> URI Class Initialized
INFO - 2023-12-25 07:29:42 --> Router Class Initialized
INFO - 2023-12-25 07:29:42 --> Output Class Initialized
INFO - 2023-12-25 07:29:42 --> Security Class Initialized
DEBUG - 2023-12-25 07:29:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-25 07:29:42 --> Input Class Initialized
INFO - 2023-12-25 07:29:42 --> Language Class Initialized
INFO - 2023-12-25 07:29:42 --> Loader Class Initialized
INFO - 2023-12-25 07:29:42 --> Helper loaded: url_helper
INFO - 2023-12-25 07:29:42 --> Helper loaded: file_helper
INFO - 2023-12-25 07:29:42 --> Helper loaded: html_helper
INFO - 2023-12-25 07:29:42 --> Helper loaded: text_helper
INFO - 2023-12-25 07:29:42 --> Helper loaded: form_helper
INFO - 2023-12-25 07:29:42 --> Helper loaded: lang_helper
INFO - 2023-12-25 07:29:42 --> Helper loaded: security_helper
INFO - 2023-12-25 07:29:42 --> Helper loaded: cookie_helper
INFO - 2023-12-25 07:29:42 --> Database Driver Class Initialized
INFO - 2023-12-25 07:29:42 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-25 07:29:42 --> Parser Class Initialized
INFO - 2023-12-25 07:29:42 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-12-25 07:29:42 --> Pagination Class Initialized
INFO - 2023-12-25 07:29:42 --> Form Validation Class Initialized
INFO - 2023-12-25 07:29:42 --> Controller Class Initialized
INFO - 2023-12-25 07:29:42 --> Model Class Initialized
DEBUG - 2023-12-25 07:29:42 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-12-25 07:29:42 --> Session class already loaded. Second attempt ignored.
INFO - 2023-12-25 07:29:42 --> Model Class Initialized
DEBUG - 2023-12-25 07:29:42 --> Session class already loaded. Second attempt ignored.
INFO - 2023-12-25 07:29:42 --> Model Class Initialized
INFO - 2023-12-25 07:29:42 --> Final output sent to browser
DEBUG - 2023-12-25 07:29:42 --> Total execution time: 0.0528
ERROR - 2023-12-25 07:29:59 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-12-25 07:29:59 --> Config Class Initialized
INFO - 2023-12-25 07:29:59 --> Hooks Class Initialized
DEBUG - 2023-12-25 07:29:59 --> UTF-8 Support Enabled
INFO - 2023-12-25 07:29:59 --> Utf8 Class Initialized
INFO - 2023-12-25 07:29:59 --> URI Class Initialized
INFO - 2023-12-25 07:29:59 --> Router Class Initialized
INFO - 2023-12-25 07:29:59 --> Output Class Initialized
INFO - 2023-12-25 07:29:59 --> Security Class Initialized
DEBUG - 2023-12-25 07:29:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-25 07:29:59 --> Input Class Initialized
INFO - 2023-12-25 07:29:59 --> Language Class Initialized
INFO - 2023-12-25 07:29:59 --> Loader Class Initialized
INFO - 2023-12-25 07:29:59 --> Helper loaded: url_helper
INFO - 2023-12-25 07:29:59 --> Helper loaded: file_helper
INFO - 2023-12-25 07:29:59 --> Helper loaded: html_helper
INFO - 2023-12-25 07:29:59 --> Helper loaded: text_helper
INFO - 2023-12-25 07:29:59 --> Helper loaded: form_helper
INFO - 2023-12-25 07:29:59 --> Helper loaded: lang_helper
INFO - 2023-12-25 07:29:59 --> Helper loaded: security_helper
INFO - 2023-12-25 07:29:59 --> Helper loaded: cookie_helper
INFO - 2023-12-25 07:29:59 --> Database Driver Class Initialized
INFO - 2023-12-25 07:29:59 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-25 07:29:59 --> Parser Class Initialized
INFO - 2023-12-25 07:29:59 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-12-25 07:29:59 --> Pagination Class Initialized
INFO - 2023-12-25 07:29:59 --> Form Validation Class Initialized
INFO - 2023-12-25 07:29:59 --> Controller Class Initialized
INFO - 2023-12-25 07:29:59 --> Model Class Initialized
DEBUG - 2023-12-25 07:29:59 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-12-25 07:29:59 --> Session class already loaded. Second attempt ignored.
INFO - 2023-12-25 07:29:59 --> Model Class Initialized
DEBUG - 2023-12-25 07:29:59 --> Session class already loaded. Second attempt ignored.
INFO - 2023-12-25 07:29:59 --> Model Class Initialized
DEBUG - 2023-12-25 07:29:59 --> Session class already loaded. Second attempt ignored.
INFO - 2023-12-25 07:29:59 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice_html.php
DEBUG - 2023-12-25 07:29:59 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-12-25 07:29:59 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-12-25 07:29:59 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-12-25 07:29:59 --> Model Class Initialized
INFO - 2023-12-25 07:29:59 --> Model Class Initialized
INFO - 2023-12-25 07:29:59 --> Model Class Initialized
INFO - 2023-12-25 07:29:59 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-12-25 07:29:59 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-12-25 07:29:59 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-12-25 07:29:59 --> Final output sent to browser
DEBUG - 2023-12-25 07:29:59 --> Total execution time: 0.2432
ERROR - 2023-12-25 08:51:19 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-12-25 08:51:19 --> Config Class Initialized
INFO - 2023-12-25 08:51:19 --> Hooks Class Initialized
DEBUG - 2023-12-25 08:51:19 --> UTF-8 Support Enabled
INFO - 2023-12-25 08:51:19 --> Utf8 Class Initialized
INFO - 2023-12-25 08:51:19 --> URI Class Initialized
INFO - 2023-12-25 08:51:19 --> Router Class Initialized
INFO - 2023-12-25 08:51:19 --> Output Class Initialized
INFO - 2023-12-25 08:51:19 --> Security Class Initialized
DEBUG - 2023-12-25 08:51:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-25 08:51:19 --> Input Class Initialized
INFO - 2023-12-25 08:51:19 --> Language Class Initialized
ERROR - 2023-12-25 08:51:19 --> 404 Page Not Found: Well-known/assetlinks.json
ERROR - 2023-12-25 09:28:55 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-12-25 09:28:55 --> Config Class Initialized
INFO - 2023-12-25 09:28:55 --> Hooks Class Initialized
DEBUG - 2023-12-25 09:28:55 --> UTF-8 Support Enabled
INFO - 2023-12-25 09:28:55 --> Utf8 Class Initialized
INFO - 2023-12-25 09:28:55 --> URI Class Initialized
DEBUG - 2023-12-25 09:28:55 --> No URI present. Default controller set.
INFO - 2023-12-25 09:28:55 --> Router Class Initialized
INFO - 2023-12-25 09:28:55 --> Output Class Initialized
INFO - 2023-12-25 09:28:55 --> Security Class Initialized
DEBUG - 2023-12-25 09:28:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-25 09:28:55 --> Input Class Initialized
INFO - 2023-12-25 09:28:55 --> Language Class Initialized
INFO - 2023-12-25 09:28:55 --> Loader Class Initialized
INFO - 2023-12-25 09:28:55 --> Helper loaded: url_helper
INFO - 2023-12-25 09:28:55 --> Helper loaded: file_helper
INFO - 2023-12-25 09:28:55 --> Helper loaded: html_helper
INFO - 2023-12-25 09:28:55 --> Helper loaded: text_helper
INFO - 2023-12-25 09:28:55 --> Helper loaded: form_helper
INFO - 2023-12-25 09:28:55 --> Helper loaded: lang_helper
INFO - 2023-12-25 09:28:55 --> Helper loaded: security_helper
INFO - 2023-12-25 09:28:55 --> Helper loaded: cookie_helper
INFO - 2023-12-25 09:28:55 --> Database Driver Class Initialized
INFO - 2023-12-25 09:28:55 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-25 09:28:55 --> Parser Class Initialized
INFO - 2023-12-25 09:28:55 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-12-25 09:28:55 --> Pagination Class Initialized
INFO - 2023-12-25 09:28:55 --> Form Validation Class Initialized
INFO - 2023-12-25 09:28:55 --> Controller Class Initialized
INFO - 2023-12-25 09:28:55 --> Model Class Initialized
DEBUG - 2023-12-25 09:28:55 --> Session class already loaded. Second attempt ignored.
ERROR - 2023-12-25 17:10:25 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-12-25 17:10:25 --> Config Class Initialized
INFO - 2023-12-25 17:10:25 --> Hooks Class Initialized
DEBUG - 2023-12-25 17:10:25 --> UTF-8 Support Enabled
INFO - 2023-12-25 17:10:25 --> Utf8 Class Initialized
INFO - 2023-12-25 17:10:25 --> URI Class Initialized
DEBUG - 2023-12-25 17:10:25 --> No URI present. Default controller set.
INFO - 2023-12-25 17:10:25 --> Router Class Initialized
INFO - 2023-12-25 17:10:25 --> Output Class Initialized
INFO - 2023-12-25 17:10:25 --> Security Class Initialized
DEBUG - 2023-12-25 17:10:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-25 17:10:25 --> Input Class Initialized
INFO - 2023-12-25 17:10:25 --> Language Class Initialized
INFO - 2023-12-25 17:10:25 --> Loader Class Initialized
INFO - 2023-12-25 17:10:25 --> Helper loaded: url_helper
INFO - 2023-12-25 17:10:25 --> Helper loaded: file_helper
INFO - 2023-12-25 17:10:25 --> Helper loaded: html_helper
INFO - 2023-12-25 17:10:25 --> Helper loaded: text_helper
INFO - 2023-12-25 17:10:25 --> Helper loaded: form_helper
INFO - 2023-12-25 17:10:25 --> Helper loaded: lang_helper
INFO - 2023-12-25 17:10:25 --> Helper loaded: security_helper
INFO - 2023-12-25 17:10:25 --> Helper loaded: cookie_helper
INFO - 2023-12-25 17:10:25 --> Database Driver Class Initialized
INFO - 2023-12-25 17:10:25 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-25 17:10:25 --> Parser Class Initialized
INFO - 2023-12-25 17:10:25 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-12-25 17:10:25 --> Pagination Class Initialized
INFO - 2023-12-25 17:10:25 --> Form Validation Class Initialized
INFO - 2023-12-25 17:10:25 --> Controller Class Initialized
INFO - 2023-12-25 17:10:25 --> Model Class Initialized
DEBUG - 2023-12-25 17:10:25 --> Session class already loaded. Second attempt ignored.
ERROR - 2023-12-25 17:10:26 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-12-25 17:10:26 --> Config Class Initialized
INFO - 2023-12-25 17:10:26 --> Hooks Class Initialized
DEBUG - 2023-12-25 17:10:26 --> UTF-8 Support Enabled
INFO - 2023-12-25 17:10:26 --> Utf8 Class Initialized
INFO - 2023-12-25 17:10:26 --> URI Class Initialized
INFO - 2023-12-25 17:10:26 --> Router Class Initialized
INFO - 2023-12-25 17:10:26 --> Output Class Initialized
INFO - 2023-12-25 17:10:26 --> Security Class Initialized
DEBUG - 2023-12-25 17:10:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-25 17:10:26 --> Input Class Initialized
INFO - 2023-12-25 17:10:26 --> Language Class Initialized
INFO - 2023-12-25 17:10:26 --> Loader Class Initialized
INFO - 2023-12-25 17:10:26 --> Helper loaded: url_helper
INFO - 2023-12-25 17:10:26 --> Helper loaded: file_helper
INFO - 2023-12-25 17:10:26 --> Helper loaded: html_helper
INFO - 2023-12-25 17:10:26 --> Helper loaded: text_helper
INFO - 2023-12-25 17:10:26 --> Helper loaded: form_helper
INFO - 2023-12-25 17:10:26 --> Helper loaded: lang_helper
INFO - 2023-12-25 17:10:26 --> Helper loaded: security_helper
INFO - 2023-12-25 17:10:26 --> Helper loaded: cookie_helper
INFO - 2023-12-25 17:10:26 --> Database Driver Class Initialized
INFO - 2023-12-25 17:10:26 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-25 17:10:26 --> Parser Class Initialized
INFO - 2023-12-25 17:10:26 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-12-25 17:10:26 --> Pagination Class Initialized
INFO - 2023-12-25 17:10:26 --> Form Validation Class Initialized
INFO - 2023-12-25 17:10:26 --> Controller Class Initialized
INFO - 2023-12-25 17:10:26 --> Model Class Initialized
DEBUG - 2023-12-25 17:10:26 --> Session class already loaded. Second attempt ignored.
INFO - 2023-12-25 17:10:26 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2023-12-25 17:10:26 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-12-25 17:10:26 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-12-25 17:10:26 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-12-25 17:10:26 --> Model Class Initialized
INFO - 2023-12-25 17:10:26 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-12-25 17:10:26 --> Final output sent to browser
DEBUG - 2023-12-25 17:10:26 --> Total execution time: 0.0383
ERROR - 2023-12-25 17:11:13 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-12-25 17:11:13 --> Config Class Initialized
INFO - 2023-12-25 17:11:13 --> Hooks Class Initialized
DEBUG - 2023-12-25 17:11:13 --> UTF-8 Support Enabled
INFO - 2023-12-25 17:11:13 --> Utf8 Class Initialized
INFO - 2023-12-25 17:11:13 --> URI Class Initialized
INFO - 2023-12-25 17:11:13 --> Router Class Initialized
INFO - 2023-12-25 17:11:13 --> Output Class Initialized
INFO - 2023-12-25 17:11:13 --> Security Class Initialized
DEBUG - 2023-12-25 17:11:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-25 17:11:13 --> Input Class Initialized
INFO - 2023-12-25 17:11:13 --> Language Class Initialized
INFO - 2023-12-25 17:11:13 --> Loader Class Initialized
INFO - 2023-12-25 17:11:13 --> Helper loaded: url_helper
INFO - 2023-12-25 17:11:13 --> Helper loaded: file_helper
INFO - 2023-12-25 17:11:13 --> Helper loaded: html_helper
INFO - 2023-12-25 17:11:13 --> Helper loaded: text_helper
INFO - 2023-12-25 17:11:13 --> Helper loaded: form_helper
INFO - 2023-12-25 17:11:13 --> Helper loaded: lang_helper
INFO - 2023-12-25 17:11:13 --> Helper loaded: security_helper
INFO - 2023-12-25 17:11:13 --> Helper loaded: cookie_helper
INFO - 2023-12-25 17:11:13 --> Database Driver Class Initialized
INFO - 2023-12-25 17:11:13 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-25 17:11:13 --> Parser Class Initialized
INFO - 2023-12-25 17:11:13 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-12-25 17:11:13 --> Pagination Class Initialized
INFO - 2023-12-25 17:11:13 --> Form Validation Class Initialized
INFO - 2023-12-25 17:11:13 --> Controller Class Initialized
INFO - 2023-12-25 17:11:13 --> Model Class Initialized
DEBUG - 2023-12-25 17:11:13 --> Session class already loaded. Second attempt ignored.
INFO - 2023-12-25 17:11:13 --> Model Class Initialized
INFO - 2023-12-25 17:11:13 --> Final output sent to browser
DEBUG - 2023-12-25 17:11:13 --> Total execution time: 0.0221
ERROR - 2023-12-25 17:11:14 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-12-25 17:11:14 --> Config Class Initialized
INFO - 2023-12-25 17:11:14 --> Hooks Class Initialized
DEBUG - 2023-12-25 17:11:14 --> UTF-8 Support Enabled
INFO - 2023-12-25 17:11:14 --> Utf8 Class Initialized
INFO - 2023-12-25 17:11:14 --> URI Class Initialized
DEBUG - 2023-12-25 17:11:14 --> No URI present. Default controller set.
INFO - 2023-12-25 17:11:14 --> Router Class Initialized
INFO - 2023-12-25 17:11:14 --> Output Class Initialized
INFO - 2023-12-25 17:11:14 --> Security Class Initialized
DEBUG - 2023-12-25 17:11:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-25 17:11:14 --> Input Class Initialized
INFO - 2023-12-25 17:11:14 --> Language Class Initialized
INFO - 2023-12-25 17:11:14 --> Loader Class Initialized
INFO - 2023-12-25 17:11:14 --> Helper loaded: url_helper
INFO - 2023-12-25 17:11:14 --> Helper loaded: file_helper
INFO - 2023-12-25 17:11:14 --> Helper loaded: html_helper
INFO - 2023-12-25 17:11:14 --> Helper loaded: text_helper
INFO - 2023-12-25 17:11:14 --> Helper loaded: form_helper
INFO - 2023-12-25 17:11:14 --> Helper loaded: lang_helper
INFO - 2023-12-25 17:11:14 --> Helper loaded: security_helper
INFO - 2023-12-25 17:11:14 --> Helper loaded: cookie_helper
INFO - 2023-12-25 17:11:14 --> Database Driver Class Initialized
INFO - 2023-12-25 17:11:14 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-25 17:11:14 --> Parser Class Initialized
INFO - 2023-12-25 17:11:14 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-12-25 17:11:14 --> Pagination Class Initialized
INFO - 2023-12-25 17:11:14 --> Form Validation Class Initialized
INFO - 2023-12-25 17:11:14 --> Controller Class Initialized
INFO - 2023-12-25 17:11:14 --> Model Class Initialized
DEBUG - 2023-12-25 17:11:14 --> Session class already loaded. Second attempt ignored.
INFO - 2023-12-25 17:11:14 --> Model Class Initialized
DEBUG - 2023-12-25 17:11:14 --> Session class already loaded. Second attempt ignored.
INFO - 2023-12-25 17:11:14 --> Model Class Initialized
INFO - 2023-12-25 17:11:14 --> Model Class Initialized
INFO - 2023-12-25 17:11:14 --> Model Class Initialized
INFO - 2023-12-25 17:11:14 --> Model Class Initialized
DEBUG - 2023-12-25 17:11:14 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-12-25 17:11:14 --> Session class already loaded. Second attempt ignored.
INFO - 2023-12-25 17:11:14 --> Model Class Initialized
INFO - 2023-12-25 17:11:14 --> Model Class Initialized
INFO - 2023-12-25 17:11:14 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-12-25 17:11:14 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-12-25 17:11:14 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-12-25 17:11:14 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-12-25 17:11:14 --> Model Class Initialized
INFO - 2023-12-25 17:11:14 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-12-25 17:11:14 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-12-25 17:11:14 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-12-25 17:11:14 --> Final output sent to browser
DEBUG - 2023-12-25 17:11:14 --> Total execution time: 0.4187
ERROR - 2023-12-25 17:11:16 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-12-25 17:11:16 --> Config Class Initialized
INFO - 2023-12-25 17:11:16 --> Hooks Class Initialized
DEBUG - 2023-12-25 17:11:16 --> UTF-8 Support Enabled
INFO - 2023-12-25 17:11:16 --> Utf8 Class Initialized
INFO - 2023-12-25 17:11:16 --> URI Class Initialized
INFO - 2023-12-25 17:11:16 --> Router Class Initialized
INFO - 2023-12-25 17:11:16 --> Output Class Initialized
INFO - 2023-12-25 17:11:16 --> Security Class Initialized
DEBUG - 2023-12-25 17:11:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-25 17:11:16 --> Input Class Initialized
INFO - 2023-12-25 17:11:16 --> Language Class Initialized
INFO - 2023-12-25 17:11:16 --> Loader Class Initialized
INFO - 2023-12-25 17:11:16 --> Helper loaded: url_helper
INFO - 2023-12-25 17:11:16 --> Helper loaded: file_helper
INFO - 2023-12-25 17:11:16 --> Helper loaded: html_helper
INFO - 2023-12-25 17:11:16 --> Helper loaded: text_helper
INFO - 2023-12-25 17:11:16 --> Helper loaded: form_helper
INFO - 2023-12-25 17:11:16 --> Helper loaded: lang_helper
INFO - 2023-12-25 17:11:16 --> Helper loaded: security_helper
INFO - 2023-12-25 17:11:16 --> Helper loaded: cookie_helper
INFO - 2023-12-25 17:11:16 --> Database Driver Class Initialized
INFO - 2023-12-25 17:11:16 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-25 17:11:16 --> Parser Class Initialized
INFO - 2023-12-25 17:11:16 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-12-25 17:11:16 --> Pagination Class Initialized
INFO - 2023-12-25 17:11:16 --> Form Validation Class Initialized
INFO - 2023-12-25 17:11:16 --> Controller Class Initialized
DEBUG - 2023-12-25 17:11:16 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-12-25 17:11:16 --> Session class already loaded. Second attempt ignored.
INFO - 2023-12-25 17:11:16 --> Model Class Initialized
INFO - 2023-12-25 17:11:16 --> Final output sent to browser
DEBUG - 2023-12-25 17:11:16 --> Total execution time: 0.0153
ERROR - 2023-12-25 21:24:26 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-12-25 21:24:26 --> Config Class Initialized
INFO - 2023-12-25 21:24:26 --> Hooks Class Initialized
DEBUG - 2023-12-25 21:24:26 --> UTF-8 Support Enabled
INFO - 2023-12-25 21:24:26 --> Utf8 Class Initialized
INFO - 2023-12-25 21:24:26 --> URI Class Initialized
DEBUG - 2023-12-25 21:24:26 --> No URI present. Default controller set.
INFO - 2023-12-25 21:24:26 --> Router Class Initialized
INFO - 2023-12-25 21:24:26 --> Output Class Initialized
INFO - 2023-12-25 21:24:26 --> Security Class Initialized
DEBUG - 2023-12-25 21:24:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-25 21:24:26 --> Input Class Initialized
INFO - 2023-12-25 21:24:26 --> Language Class Initialized
INFO - 2023-12-25 21:24:26 --> Loader Class Initialized
INFO - 2023-12-25 21:24:26 --> Helper loaded: url_helper
INFO - 2023-12-25 21:24:26 --> Helper loaded: file_helper
INFO - 2023-12-25 21:24:26 --> Helper loaded: html_helper
INFO - 2023-12-25 21:24:26 --> Helper loaded: text_helper
INFO - 2023-12-25 21:24:26 --> Helper loaded: form_helper
INFO - 2023-12-25 21:24:26 --> Helper loaded: lang_helper
INFO - 2023-12-25 21:24:26 --> Helper loaded: security_helper
INFO - 2023-12-25 21:24:26 --> Helper loaded: cookie_helper
INFO - 2023-12-25 21:24:26 --> Database Driver Class Initialized
INFO - 2023-12-25 21:24:26 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-25 21:24:26 --> Parser Class Initialized
INFO - 2023-12-25 21:24:26 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-12-25 21:24:26 --> Pagination Class Initialized
INFO - 2023-12-25 21:24:26 --> Form Validation Class Initialized
INFO - 2023-12-25 21:24:26 --> Controller Class Initialized
INFO - 2023-12-25 21:24:26 --> Model Class Initialized
DEBUG - 2023-12-25 21:24:26 --> Session class already loaded. Second attempt ignored.
ERROR - 2023-12-25 23:10:30 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-12-25 23:10:30 --> Config Class Initialized
INFO - 2023-12-25 23:10:30 --> Hooks Class Initialized
DEBUG - 2023-12-25 23:10:30 --> UTF-8 Support Enabled
INFO - 2023-12-25 23:10:30 --> Utf8 Class Initialized
INFO - 2023-12-25 23:10:30 --> URI Class Initialized
DEBUG - 2023-12-25 23:10:30 --> No URI present. Default controller set.
INFO - 2023-12-25 23:10:30 --> Router Class Initialized
INFO - 2023-12-25 23:10:30 --> Output Class Initialized
INFO - 2023-12-25 23:10:30 --> Security Class Initialized
DEBUG - 2023-12-25 23:10:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-25 23:10:30 --> Input Class Initialized
INFO - 2023-12-25 23:10:30 --> Language Class Initialized
INFO - 2023-12-25 23:10:30 --> Loader Class Initialized
INFO - 2023-12-25 23:10:30 --> Helper loaded: url_helper
INFO - 2023-12-25 23:10:30 --> Helper loaded: file_helper
INFO - 2023-12-25 23:10:30 --> Helper loaded: html_helper
INFO - 2023-12-25 23:10:30 --> Helper loaded: text_helper
INFO - 2023-12-25 23:10:30 --> Helper loaded: form_helper
INFO - 2023-12-25 23:10:30 --> Helper loaded: lang_helper
INFO - 2023-12-25 23:10:30 --> Helper loaded: security_helper
INFO - 2023-12-25 23:10:30 --> Helper loaded: cookie_helper
INFO - 2023-12-25 23:10:30 --> Database Driver Class Initialized
INFO - 2023-12-25 23:10:30 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-25 23:10:30 --> Parser Class Initialized
INFO - 2023-12-25 23:10:30 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-12-25 23:10:30 --> Pagination Class Initialized
INFO - 2023-12-25 23:10:30 --> Form Validation Class Initialized
INFO - 2023-12-25 23:10:30 --> Controller Class Initialized
INFO - 2023-12-25 23:10:30 --> Model Class Initialized
DEBUG - 2023-12-25 23:10:30 --> Session class already loaded. Second attempt ignored.
