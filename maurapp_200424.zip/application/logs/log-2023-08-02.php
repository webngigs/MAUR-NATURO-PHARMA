<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2023-08-02 01:12:05 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-02 01:12:05 --> Config Class Initialized
INFO - 2023-08-02 01:12:05 --> Hooks Class Initialized
DEBUG - 2023-08-02 01:12:05 --> UTF-8 Support Enabled
INFO - 2023-08-02 01:12:05 --> Utf8 Class Initialized
INFO - 2023-08-02 01:12:05 --> URI Class Initialized
DEBUG - 2023-08-02 01:12:05 --> No URI present. Default controller set.
INFO - 2023-08-02 01:12:05 --> Router Class Initialized
INFO - 2023-08-02 01:12:05 --> Output Class Initialized
INFO - 2023-08-02 01:12:05 --> Security Class Initialized
DEBUG - 2023-08-02 01:12:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-02 01:12:05 --> Input Class Initialized
INFO - 2023-08-02 01:12:05 --> Language Class Initialized
INFO - 2023-08-02 01:12:05 --> Loader Class Initialized
INFO - 2023-08-02 01:12:05 --> Helper loaded: url_helper
INFO - 2023-08-02 01:12:05 --> Helper loaded: file_helper
INFO - 2023-08-02 01:12:05 --> Helper loaded: html_helper
INFO - 2023-08-02 01:12:05 --> Helper loaded: text_helper
INFO - 2023-08-02 01:12:05 --> Helper loaded: form_helper
INFO - 2023-08-02 01:12:05 --> Helper loaded: lang_helper
INFO - 2023-08-02 01:12:05 --> Helper loaded: security_helper
INFO - 2023-08-02 01:12:05 --> Helper loaded: cookie_helper
INFO - 2023-08-02 01:12:05 --> Database Driver Class Initialized
INFO - 2023-08-02 01:12:05 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-02 01:12:05 --> Parser Class Initialized
INFO - 2023-08-02 01:12:05 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-02 01:12:05 --> Pagination Class Initialized
INFO - 2023-08-02 01:12:05 --> Form Validation Class Initialized
INFO - 2023-08-02 01:12:05 --> Controller Class Initialized
INFO - 2023-08-02 01:12:05 --> Model Class Initialized
DEBUG - 2023-08-02 01:12:05 --> Session class already loaded. Second attempt ignored.
ERROR - 2023-08-02 01:12:06 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-02 01:12:06 --> Config Class Initialized
INFO - 2023-08-02 01:12:06 --> Hooks Class Initialized
DEBUG - 2023-08-02 01:12:06 --> UTF-8 Support Enabled
INFO - 2023-08-02 01:12:06 --> Utf8 Class Initialized
INFO - 2023-08-02 01:12:06 --> URI Class Initialized
INFO - 2023-08-02 01:12:06 --> Router Class Initialized
INFO - 2023-08-02 01:12:06 --> Output Class Initialized
INFO - 2023-08-02 01:12:06 --> Security Class Initialized
DEBUG - 2023-08-02 01:12:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-02 01:12:06 --> Input Class Initialized
INFO - 2023-08-02 01:12:06 --> Language Class Initialized
INFO - 2023-08-02 01:12:06 --> Loader Class Initialized
INFO - 2023-08-02 01:12:06 --> Helper loaded: url_helper
INFO - 2023-08-02 01:12:06 --> Helper loaded: file_helper
INFO - 2023-08-02 01:12:06 --> Helper loaded: html_helper
INFO - 2023-08-02 01:12:06 --> Helper loaded: text_helper
INFO - 2023-08-02 01:12:06 --> Helper loaded: form_helper
INFO - 2023-08-02 01:12:06 --> Helper loaded: lang_helper
INFO - 2023-08-02 01:12:06 --> Helper loaded: security_helper
INFO - 2023-08-02 01:12:06 --> Helper loaded: cookie_helper
INFO - 2023-08-02 01:12:06 --> Database Driver Class Initialized
INFO - 2023-08-02 01:12:06 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-02 01:12:06 --> Parser Class Initialized
INFO - 2023-08-02 01:12:06 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-02 01:12:06 --> Pagination Class Initialized
INFO - 2023-08-02 01:12:06 --> Form Validation Class Initialized
INFO - 2023-08-02 01:12:06 --> Controller Class Initialized
INFO - 2023-08-02 01:12:06 --> Model Class Initialized
DEBUG - 2023-08-02 01:12:06 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-02 01:12:06 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2023-08-02 01:12:06 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-08-02 01:12:06 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-08-02 01:12:06 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-08-02 01:12:06 --> Model Class Initialized
INFO - 2023-08-02 01:12:06 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-08-02 01:12:06 --> Final output sent to browser
DEBUG - 2023-08-02 01:12:06 --> Total execution time: 0.0314
ERROR - 2023-08-02 01:12:15 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-02 01:12:15 --> Config Class Initialized
INFO - 2023-08-02 01:12:15 --> Hooks Class Initialized
DEBUG - 2023-08-02 01:12:15 --> UTF-8 Support Enabled
INFO - 2023-08-02 01:12:15 --> Utf8 Class Initialized
INFO - 2023-08-02 01:12:15 --> URI Class Initialized
INFO - 2023-08-02 01:12:15 --> Router Class Initialized
INFO - 2023-08-02 01:12:15 --> Output Class Initialized
INFO - 2023-08-02 01:12:15 --> Security Class Initialized
DEBUG - 2023-08-02 01:12:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-02 01:12:15 --> Input Class Initialized
INFO - 2023-08-02 01:12:15 --> Language Class Initialized
INFO - 2023-08-02 01:12:15 --> Loader Class Initialized
INFO - 2023-08-02 01:12:15 --> Helper loaded: url_helper
INFO - 2023-08-02 01:12:15 --> Helper loaded: file_helper
INFO - 2023-08-02 01:12:15 --> Helper loaded: html_helper
INFO - 2023-08-02 01:12:15 --> Helper loaded: text_helper
INFO - 2023-08-02 01:12:15 --> Helper loaded: form_helper
INFO - 2023-08-02 01:12:15 --> Helper loaded: lang_helper
INFO - 2023-08-02 01:12:15 --> Helper loaded: security_helper
INFO - 2023-08-02 01:12:15 --> Helper loaded: cookie_helper
INFO - 2023-08-02 01:12:15 --> Database Driver Class Initialized
INFO - 2023-08-02 01:12:15 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-02 01:12:15 --> Parser Class Initialized
INFO - 2023-08-02 01:12:15 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-02 01:12:15 --> Pagination Class Initialized
INFO - 2023-08-02 01:12:15 --> Form Validation Class Initialized
INFO - 2023-08-02 01:12:15 --> Controller Class Initialized
INFO - 2023-08-02 01:12:15 --> Model Class Initialized
DEBUG - 2023-08-02 01:12:15 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-02 01:12:15 --> Model Class Initialized
INFO - 2023-08-02 01:12:15 --> Final output sent to browser
DEBUG - 2023-08-02 01:12:15 --> Total execution time: 0.0189
ERROR - 2023-08-02 01:12:15 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-02 01:12:15 --> Config Class Initialized
INFO - 2023-08-02 01:12:15 --> Hooks Class Initialized
DEBUG - 2023-08-02 01:12:15 --> UTF-8 Support Enabled
INFO - 2023-08-02 01:12:15 --> Utf8 Class Initialized
INFO - 2023-08-02 01:12:15 --> URI Class Initialized
DEBUG - 2023-08-02 01:12:15 --> No URI present. Default controller set.
INFO - 2023-08-02 01:12:15 --> Router Class Initialized
INFO - 2023-08-02 01:12:15 --> Output Class Initialized
INFO - 2023-08-02 01:12:15 --> Security Class Initialized
DEBUG - 2023-08-02 01:12:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-02 01:12:15 --> Input Class Initialized
INFO - 2023-08-02 01:12:15 --> Language Class Initialized
INFO - 2023-08-02 01:12:15 --> Loader Class Initialized
INFO - 2023-08-02 01:12:15 --> Helper loaded: url_helper
INFO - 2023-08-02 01:12:15 --> Helper loaded: file_helper
INFO - 2023-08-02 01:12:15 --> Helper loaded: html_helper
INFO - 2023-08-02 01:12:15 --> Helper loaded: text_helper
INFO - 2023-08-02 01:12:15 --> Helper loaded: form_helper
INFO - 2023-08-02 01:12:15 --> Helper loaded: lang_helper
INFO - 2023-08-02 01:12:15 --> Helper loaded: security_helper
INFO - 2023-08-02 01:12:15 --> Helper loaded: cookie_helper
INFO - 2023-08-02 01:12:15 --> Database Driver Class Initialized
INFO - 2023-08-02 01:12:15 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-02 01:12:15 --> Parser Class Initialized
INFO - 2023-08-02 01:12:15 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-02 01:12:15 --> Pagination Class Initialized
INFO - 2023-08-02 01:12:15 --> Form Validation Class Initialized
INFO - 2023-08-02 01:12:15 --> Controller Class Initialized
INFO - 2023-08-02 01:12:15 --> Model Class Initialized
DEBUG - 2023-08-02 01:12:15 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-02 01:12:15 --> Model Class Initialized
DEBUG - 2023-08-02 01:12:15 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-02 01:12:15 --> Model Class Initialized
INFO - 2023-08-02 01:12:15 --> Model Class Initialized
INFO - 2023-08-02 01:12:15 --> Model Class Initialized
INFO - 2023-08-02 01:12:15 --> Model Class Initialized
DEBUG - 2023-08-02 01:12:15 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-02 01:12:15 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-02 01:12:15 --> Model Class Initialized
INFO - 2023-08-02 01:12:15 --> Model Class Initialized
INFO - 2023-08-02 01:12:15 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-08-02 01:12:15 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-08-02 01:12:15 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-08-02 01:12:15 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-08-02 01:12:15 --> Model Class Initialized
INFO - 2023-08-02 01:12:15 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-08-02 01:12:15 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-08-02 01:12:15 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-08-02 01:12:15 --> Final output sent to browser
DEBUG - 2023-08-02 01:12:15 --> Total execution time: 0.1777
ERROR - 2023-08-02 01:12:16 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-02 01:12:16 --> Config Class Initialized
INFO - 2023-08-02 01:12:16 --> Hooks Class Initialized
DEBUG - 2023-08-02 01:12:16 --> UTF-8 Support Enabled
INFO - 2023-08-02 01:12:16 --> Utf8 Class Initialized
INFO - 2023-08-02 01:12:16 --> URI Class Initialized
INFO - 2023-08-02 01:12:16 --> Router Class Initialized
INFO - 2023-08-02 01:12:16 --> Output Class Initialized
INFO - 2023-08-02 01:12:16 --> Security Class Initialized
DEBUG - 2023-08-02 01:12:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-02 01:12:16 --> Input Class Initialized
INFO - 2023-08-02 01:12:16 --> Language Class Initialized
INFO - 2023-08-02 01:12:16 --> Loader Class Initialized
INFO - 2023-08-02 01:12:16 --> Helper loaded: url_helper
INFO - 2023-08-02 01:12:16 --> Helper loaded: file_helper
INFO - 2023-08-02 01:12:16 --> Helper loaded: html_helper
INFO - 2023-08-02 01:12:16 --> Helper loaded: text_helper
INFO - 2023-08-02 01:12:16 --> Helper loaded: form_helper
INFO - 2023-08-02 01:12:16 --> Helper loaded: lang_helper
INFO - 2023-08-02 01:12:16 --> Helper loaded: security_helper
INFO - 2023-08-02 01:12:16 --> Helper loaded: cookie_helper
INFO - 2023-08-02 01:12:16 --> Database Driver Class Initialized
INFO - 2023-08-02 01:12:16 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-02 01:12:16 --> Parser Class Initialized
INFO - 2023-08-02 01:12:16 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-02 01:12:16 --> Pagination Class Initialized
INFO - 2023-08-02 01:12:16 --> Form Validation Class Initialized
INFO - 2023-08-02 01:12:16 --> Controller Class Initialized
DEBUG - 2023-08-02 01:12:16 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-02 01:12:16 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-02 01:12:16 --> Model Class Initialized
INFO - 2023-08-02 01:12:16 --> Final output sent to browser
DEBUG - 2023-08-02 01:12:16 --> Total execution time: 0.0313
ERROR - 2023-08-02 01:12:50 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-02 01:12:50 --> Config Class Initialized
INFO - 2023-08-02 01:12:50 --> Hooks Class Initialized
DEBUG - 2023-08-02 01:12:50 --> UTF-8 Support Enabled
INFO - 2023-08-02 01:12:50 --> Utf8 Class Initialized
INFO - 2023-08-02 01:12:50 --> URI Class Initialized
INFO - 2023-08-02 01:12:50 --> Router Class Initialized
INFO - 2023-08-02 01:12:50 --> Output Class Initialized
INFO - 2023-08-02 01:12:50 --> Security Class Initialized
DEBUG - 2023-08-02 01:12:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-02 01:12:50 --> Input Class Initialized
INFO - 2023-08-02 01:12:50 --> Language Class Initialized
INFO - 2023-08-02 01:12:50 --> Loader Class Initialized
INFO - 2023-08-02 01:12:50 --> Helper loaded: url_helper
INFO - 2023-08-02 01:12:50 --> Helper loaded: file_helper
INFO - 2023-08-02 01:12:50 --> Helper loaded: html_helper
INFO - 2023-08-02 01:12:50 --> Helper loaded: text_helper
INFO - 2023-08-02 01:12:50 --> Helper loaded: form_helper
INFO - 2023-08-02 01:12:50 --> Helper loaded: lang_helper
INFO - 2023-08-02 01:12:50 --> Helper loaded: security_helper
INFO - 2023-08-02 01:12:50 --> Helper loaded: cookie_helper
INFO - 2023-08-02 01:12:50 --> Database Driver Class Initialized
INFO - 2023-08-02 01:12:50 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-02 01:12:50 --> Parser Class Initialized
INFO - 2023-08-02 01:12:50 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-02 01:12:50 --> Pagination Class Initialized
INFO - 2023-08-02 01:12:50 --> Form Validation Class Initialized
INFO - 2023-08-02 01:12:50 --> Controller Class Initialized
INFO - 2023-08-02 01:12:50 --> Model Class Initialized
DEBUG - 2023-08-02 01:12:50 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-02 01:12:50 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-02 01:12:50 --> Model Class Initialized
DEBUG - 2023-08-02 01:12:50 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-02 01:12:50 --> Model Class Initialized
INFO - 2023-08-02 01:12:50 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice.php
DEBUG - 2023-08-02 01:12:50 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-08-02 01:12:50 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-08-02 01:12:50 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-08-02 01:12:50 --> Model Class Initialized
INFO - 2023-08-02 01:12:50 --> Model Class Initialized
INFO - 2023-08-02 01:12:50 --> Model Class Initialized
INFO - 2023-08-02 01:12:50 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-08-02 01:12:50 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-08-02 01:12:50 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-08-02 01:12:50 --> Final output sent to browser
DEBUG - 2023-08-02 01:12:50 --> Total execution time: 0.1284
ERROR - 2023-08-02 01:12:51 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-02 01:12:51 --> Config Class Initialized
INFO - 2023-08-02 01:12:51 --> Hooks Class Initialized
DEBUG - 2023-08-02 01:12:51 --> UTF-8 Support Enabled
INFO - 2023-08-02 01:12:51 --> Utf8 Class Initialized
INFO - 2023-08-02 01:12:51 --> URI Class Initialized
INFO - 2023-08-02 01:12:51 --> Router Class Initialized
INFO - 2023-08-02 01:12:51 --> Output Class Initialized
INFO - 2023-08-02 01:12:51 --> Security Class Initialized
DEBUG - 2023-08-02 01:12:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-02 01:12:51 --> Input Class Initialized
INFO - 2023-08-02 01:12:51 --> Language Class Initialized
INFO - 2023-08-02 01:12:51 --> Loader Class Initialized
INFO - 2023-08-02 01:12:51 --> Helper loaded: url_helper
INFO - 2023-08-02 01:12:51 --> Helper loaded: file_helper
INFO - 2023-08-02 01:12:51 --> Helper loaded: html_helper
INFO - 2023-08-02 01:12:51 --> Helper loaded: text_helper
INFO - 2023-08-02 01:12:51 --> Helper loaded: form_helper
INFO - 2023-08-02 01:12:51 --> Helper loaded: lang_helper
INFO - 2023-08-02 01:12:51 --> Helper loaded: security_helper
INFO - 2023-08-02 01:12:51 --> Helper loaded: cookie_helper
INFO - 2023-08-02 01:12:51 --> Database Driver Class Initialized
INFO - 2023-08-02 01:12:51 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-02 01:12:51 --> Parser Class Initialized
INFO - 2023-08-02 01:12:51 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-02 01:12:51 --> Pagination Class Initialized
INFO - 2023-08-02 01:12:51 --> Form Validation Class Initialized
INFO - 2023-08-02 01:12:51 --> Controller Class Initialized
INFO - 2023-08-02 01:12:51 --> Model Class Initialized
DEBUG - 2023-08-02 01:12:51 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-02 01:12:51 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-02 01:12:51 --> Model Class Initialized
DEBUG - 2023-08-02 01:12:51 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-02 01:12:51 --> Model Class Initialized
INFO - 2023-08-02 01:12:51 --> Final output sent to browser
DEBUG - 2023-08-02 01:12:51 --> Total execution time: 0.0573
ERROR - 2023-08-02 01:12:53 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-02 01:12:53 --> Config Class Initialized
INFO - 2023-08-02 01:12:53 --> Hooks Class Initialized
DEBUG - 2023-08-02 01:12:53 --> UTF-8 Support Enabled
INFO - 2023-08-02 01:12:53 --> Utf8 Class Initialized
INFO - 2023-08-02 01:12:53 --> URI Class Initialized
INFO - 2023-08-02 01:12:53 --> Router Class Initialized
INFO - 2023-08-02 01:12:53 --> Output Class Initialized
INFO - 2023-08-02 01:12:53 --> Security Class Initialized
DEBUG - 2023-08-02 01:12:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-02 01:12:53 --> Input Class Initialized
INFO - 2023-08-02 01:12:53 --> Language Class Initialized
INFO - 2023-08-02 01:12:53 --> Loader Class Initialized
INFO - 2023-08-02 01:12:53 --> Helper loaded: url_helper
INFO - 2023-08-02 01:12:53 --> Helper loaded: file_helper
INFO - 2023-08-02 01:12:53 --> Helper loaded: html_helper
INFO - 2023-08-02 01:12:53 --> Helper loaded: text_helper
INFO - 2023-08-02 01:12:53 --> Helper loaded: form_helper
INFO - 2023-08-02 01:12:53 --> Helper loaded: lang_helper
INFO - 2023-08-02 01:12:53 --> Helper loaded: security_helper
INFO - 2023-08-02 01:12:53 --> Helper loaded: cookie_helper
INFO - 2023-08-02 01:12:53 --> Database Driver Class Initialized
INFO - 2023-08-02 01:12:53 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-02 01:12:53 --> Parser Class Initialized
INFO - 2023-08-02 01:12:53 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-02 01:12:53 --> Pagination Class Initialized
INFO - 2023-08-02 01:12:53 --> Form Validation Class Initialized
INFO - 2023-08-02 01:12:53 --> Controller Class Initialized
INFO - 2023-08-02 01:12:53 --> Model Class Initialized
DEBUG - 2023-08-02 01:12:53 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-02 01:12:53 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-02 01:12:53 --> Model Class Initialized
DEBUG - 2023-08-02 01:12:53 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-02 01:12:53 --> Model Class Initialized
DEBUG - 2023-08-02 01:12:53 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-02 01:12:53 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice_html.php
DEBUG - 2023-08-02 01:12:53 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-08-02 01:12:53 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-08-02 01:12:53 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-08-02 01:12:53 --> Model Class Initialized
INFO - 2023-08-02 01:12:53 --> Model Class Initialized
INFO - 2023-08-02 01:12:53 --> Model Class Initialized
INFO - 2023-08-02 01:12:53 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-08-02 01:12:53 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-08-02 01:12:53 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-08-02 01:12:53 --> Final output sent to browser
DEBUG - 2023-08-02 01:12:53 --> Total execution time: 0.1775
ERROR - 2023-08-02 01:13:01 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-02 01:13:01 --> Config Class Initialized
INFO - 2023-08-02 01:13:01 --> Hooks Class Initialized
DEBUG - 2023-08-02 01:13:01 --> UTF-8 Support Enabled
INFO - 2023-08-02 01:13:01 --> Utf8 Class Initialized
INFO - 2023-08-02 01:13:01 --> URI Class Initialized
INFO - 2023-08-02 01:13:01 --> Router Class Initialized
INFO - 2023-08-02 01:13:01 --> Output Class Initialized
INFO - 2023-08-02 01:13:01 --> Security Class Initialized
DEBUG - 2023-08-02 01:13:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-02 01:13:01 --> Input Class Initialized
INFO - 2023-08-02 01:13:01 --> Language Class Initialized
INFO - 2023-08-02 01:13:01 --> Loader Class Initialized
INFO - 2023-08-02 01:13:01 --> Helper loaded: url_helper
INFO - 2023-08-02 01:13:01 --> Helper loaded: file_helper
INFO - 2023-08-02 01:13:01 --> Helper loaded: html_helper
INFO - 2023-08-02 01:13:01 --> Helper loaded: text_helper
INFO - 2023-08-02 01:13:01 --> Helper loaded: form_helper
INFO - 2023-08-02 01:13:01 --> Helper loaded: lang_helper
INFO - 2023-08-02 01:13:01 --> Helper loaded: security_helper
INFO - 2023-08-02 01:13:01 --> Helper loaded: cookie_helper
INFO - 2023-08-02 01:13:01 --> Database Driver Class Initialized
INFO - 2023-08-02 01:13:01 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-02 01:13:01 --> Parser Class Initialized
INFO - 2023-08-02 01:13:01 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-02 01:13:01 --> Pagination Class Initialized
INFO - 2023-08-02 01:13:01 --> Form Validation Class Initialized
INFO - 2023-08-02 01:13:01 --> Controller Class Initialized
INFO - 2023-08-02 01:13:01 --> Model Class Initialized
DEBUG - 2023-08-02 01:13:01 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-02 01:13:01 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-02 01:13:01 --> Model Class Initialized
DEBUG - 2023-08-02 01:13:01 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-02 01:13:01 --> Model Class Initialized
INFO - 2023-08-02 01:13:01 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/invoice/invoice.php
DEBUG - 2023-08-02 01:13:01 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-08-02 01:13:01 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-08-02 01:13:01 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-08-02 01:13:01 --> Model Class Initialized
INFO - 2023-08-02 01:13:01 --> Model Class Initialized
INFO - 2023-08-02 01:13:01 --> Model Class Initialized
INFO - 2023-08-02 01:13:01 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-08-02 01:13:01 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-08-02 01:13:01 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-08-02 01:13:01 --> Final output sent to browser
DEBUG - 2023-08-02 01:13:01 --> Total execution time: 0.1363
ERROR - 2023-08-02 01:13:02 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-02 01:13:02 --> Config Class Initialized
INFO - 2023-08-02 01:13:02 --> Hooks Class Initialized
DEBUG - 2023-08-02 01:13:02 --> UTF-8 Support Enabled
INFO - 2023-08-02 01:13:02 --> Utf8 Class Initialized
INFO - 2023-08-02 01:13:02 --> URI Class Initialized
INFO - 2023-08-02 01:13:02 --> Router Class Initialized
INFO - 2023-08-02 01:13:02 --> Output Class Initialized
INFO - 2023-08-02 01:13:02 --> Security Class Initialized
DEBUG - 2023-08-02 01:13:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-02 01:13:02 --> Input Class Initialized
INFO - 2023-08-02 01:13:02 --> Language Class Initialized
INFO - 2023-08-02 01:13:02 --> Loader Class Initialized
INFO - 2023-08-02 01:13:02 --> Helper loaded: url_helper
INFO - 2023-08-02 01:13:02 --> Helper loaded: file_helper
INFO - 2023-08-02 01:13:02 --> Helper loaded: html_helper
INFO - 2023-08-02 01:13:02 --> Helper loaded: text_helper
INFO - 2023-08-02 01:13:02 --> Helper loaded: form_helper
INFO - 2023-08-02 01:13:02 --> Helper loaded: lang_helper
INFO - 2023-08-02 01:13:02 --> Helper loaded: security_helper
INFO - 2023-08-02 01:13:02 --> Helper loaded: cookie_helper
INFO - 2023-08-02 01:13:02 --> Database Driver Class Initialized
INFO - 2023-08-02 01:13:02 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-02 01:13:02 --> Parser Class Initialized
INFO - 2023-08-02 01:13:02 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-02 01:13:02 --> Pagination Class Initialized
INFO - 2023-08-02 01:13:02 --> Form Validation Class Initialized
INFO - 2023-08-02 01:13:02 --> Controller Class Initialized
INFO - 2023-08-02 01:13:02 --> Model Class Initialized
DEBUG - 2023-08-02 01:13:02 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-02 01:13:02 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-02 01:13:02 --> Model Class Initialized
DEBUG - 2023-08-02 01:13:02 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-02 01:13:02 --> Model Class Initialized
INFO - 2023-08-02 01:13:02 --> Final output sent to browser
DEBUG - 2023-08-02 01:13:02 --> Total execution time: 0.0424
ERROR - 2023-08-02 01:13:05 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-02 01:13:05 --> Config Class Initialized
INFO - 2023-08-02 01:13:05 --> Hooks Class Initialized
DEBUG - 2023-08-02 01:13:05 --> UTF-8 Support Enabled
INFO - 2023-08-02 01:13:05 --> Utf8 Class Initialized
INFO - 2023-08-02 01:13:05 --> URI Class Initialized
INFO - 2023-08-02 01:13:05 --> Router Class Initialized
INFO - 2023-08-02 01:13:05 --> Output Class Initialized
INFO - 2023-08-02 01:13:05 --> Security Class Initialized
DEBUG - 2023-08-02 01:13:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-02 01:13:05 --> Input Class Initialized
INFO - 2023-08-02 01:13:05 --> Language Class Initialized
INFO - 2023-08-02 01:13:05 --> Loader Class Initialized
INFO - 2023-08-02 01:13:05 --> Helper loaded: url_helper
INFO - 2023-08-02 01:13:05 --> Helper loaded: file_helper
INFO - 2023-08-02 01:13:05 --> Helper loaded: html_helper
INFO - 2023-08-02 01:13:05 --> Helper loaded: text_helper
INFO - 2023-08-02 01:13:05 --> Helper loaded: form_helper
INFO - 2023-08-02 01:13:05 --> Helper loaded: lang_helper
INFO - 2023-08-02 01:13:05 --> Helper loaded: security_helper
INFO - 2023-08-02 01:13:05 --> Helper loaded: cookie_helper
INFO - 2023-08-02 01:13:05 --> Database Driver Class Initialized
INFO - 2023-08-02 01:13:05 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-02 01:13:05 --> Parser Class Initialized
INFO - 2023-08-02 01:13:05 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-02 01:13:05 --> Pagination Class Initialized
INFO - 2023-08-02 01:13:05 --> Form Validation Class Initialized
INFO - 2023-08-02 01:13:05 --> Controller Class Initialized
INFO - 2023-08-02 01:13:05 --> Model Class Initialized
DEBUG - 2023-08-02 01:13:05 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-02 01:13:05 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-02 01:13:05 --> Model Class Initialized
DEBUG - 2023-08-02 01:13:05 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-02 01:13:05 --> Model Class Initialized
INFO - 2023-08-02 01:13:05 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/invoice/invoice_html.php
DEBUG - 2023-08-02 01:13:05 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-08-02 01:13:05 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-08-02 01:13:05 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-08-02 01:13:05 --> Model Class Initialized
INFO - 2023-08-02 01:13:05 --> Model Class Initialized
INFO - 2023-08-02 01:13:05 --> Model Class Initialized
INFO - 2023-08-02 01:13:05 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-08-02 01:13:05 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-08-02 01:13:05 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-08-02 01:13:05 --> Final output sent to browser
DEBUG - 2023-08-02 01:13:05 --> Total execution time: 0.1439
ERROR - 2023-08-02 03:31:38 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-02 03:31:38 --> Config Class Initialized
INFO - 2023-08-02 03:31:38 --> Hooks Class Initialized
DEBUG - 2023-08-02 03:31:38 --> UTF-8 Support Enabled
INFO - 2023-08-02 03:31:38 --> Utf8 Class Initialized
INFO - 2023-08-02 03:31:38 --> URI Class Initialized
DEBUG - 2023-08-02 03:31:38 --> No URI present. Default controller set.
INFO - 2023-08-02 03:31:38 --> Router Class Initialized
INFO - 2023-08-02 03:31:38 --> Output Class Initialized
INFO - 2023-08-02 03:31:38 --> Security Class Initialized
DEBUG - 2023-08-02 03:31:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-02 03:31:38 --> Input Class Initialized
INFO - 2023-08-02 03:31:38 --> Language Class Initialized
INFO - 2023-08-02 03:31:38 --> Loader Class Initialized
INFO - 2023-08-02 03:31:38 --> Helper loaded: url_helper
INFO - 2023-08-02 03:31:38 --> Helper loaded: file_helper
INFO - 2023-08-02 03:31:38 --> Helper loaded: html_helper
INFO - 2023-08-02 03:31:38 --> Helper loaded: text_helper
INFO - 2023-08-02 03:31:38 --> Helper loaded: form_helper
INFO - 2023-08-02 03:31:38 --> Helper loaded: lang_helper
INFO - 2023-08-02 03:31:38 --> Helper loaded: security_helper
INFO - 2023-08-02 03:31:38 --> Helper loaded: cookie_helper
INFO - 2023-08-02 03:31:38 --> Database Driver Class Initialized
INFO - 2023-08-02 03:31:38 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-02 03:31:38 --> Parser Class Initialized
INFO - 2023-08-02 03:31:38 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-02 03:31:38 --> Pagination Class Initialized
INFO - 2023-08-02 03:31:38 --> Form Validation Class Initialized
INFO - 2023-08-02 03:31:38 --> Controller Class Initialized
INFO - 2023-08-02 03:31:38 --> Model Class Initialized
DEBUG - 2023-08-02 03:31:38 --> Session class already loaded. Second attempt ignored.
ERROR - 2023-08-02 03:31:39 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-02 03:31:39 --> Config Class Initialized
INFO - 2023-08-02 03:31:39 --> Hooks Class Initialized
DEBUG - 2023-08-02 03:31:39 --> UTF-8 Support Enabled
INFO - 2023-08-02 03:31:39 --> Utf8 Class Initialized
INFO - 2023-08-02 03:31:39 --> URI Class Initialized
INFO - 2023-08-02 03:31:39 --> Router Class Initialized
INFO - 2023-08-02 03:31:39 --> Output Class Initialized
INFO - 2023-08-02 03:31:39 --> Security Class Initialized
DEBUG - 2023-08-02 03:31:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-02 03:31:39 --> Input Class Initialized
INFO - 2023-08-02 03:31:39 --> Language Class Initialized
INFO - 2023-08-02 03:31:39 --> Loader Class Initialized
INFO - 2023-08-02 03:31:39 --> Helper loaded: url_helper
INFO - 2023-08-02 03:31:39 --> Helper loaded: file_helper
INFO - 2023-08-02 03:31:39 --> Helper loaded: html_helper
INFO - 2023-08-02 03:31:39 --> Helper loaded: text_helper
INFO - 2023-08-02 03:31:39 --> Helper loaded: form_helper
INFO - 2023-08-02 03:31:39 --> Helper loaded: lang_helper
INFO - 2023-08-02 03:31:39 --> Helper loaded: security_helper
INFO - 2023-08-02 03:31:39 --> Helper loaded: cookie_helper
INFO - 2023-08-02 03:31:39 --> Database Driver Class Initialized
INFO - 2023-08-02 03:31:39 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-02 03:31:39 --> Parser Class Initialized
INFO - 2023-08-02 03:31:39 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-02 03:31:39 --> Pagination Class Initialized
INFO - 2023-08-02 03:31:39 --> Form Validation Class Initialized
INFO - 2023-08-02 03:31:39 --> Controller Class Initialized
INFO - 2023-08-02 03:31:39 --> Model Class Initialized
DEBUG - 2023-08-02 03:31:39 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-02 03:31:39 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2023-08-02 03:31:39 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-08-02 03:31:39 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-08-02 03:31:39 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-08-02 03:31:39 --> Model Class Initialized
INFO - 2023-08-02 03:31:39 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-08-02 03:31:39 --> Final output sent to browser
DEBUG - 2023-08-02 03:31:39 --> Total execution time: 0.0323
ERROR - 2023-08-02 03:31:54 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-02 03:31:54 --> Config Class Initialized
INFO - 2023-08-02 03:31:54 --> Hooks Class Initialized
DEBUG - 2023-08-02 03:31:54 --> UTF-8 Support Enabled
INFO - 2023-08-02 03:31:54 --> Utf8 Class Initialized
INFO - 2023-08-02 03:31:54 --> URI Class Initialized
INFO - 2023-08-02 03:31:54 --> Router Class Initialized
INFO - 2023-08-02 03:31:54 --> Output Class Initialized
INFO - 2023-08-02 03:31:54 --> Security Class Initialized
DEBUG - 2023-08-02 03:31:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-02 03:31:54 --> Input Class Initialized
INFO - 2023-08-02 03:31:54 --> Language Class Initialized
INFO - 2023-08-02 03:31:54 --> Loader Class Initialized
INFO - 2023-08-02 03:31:54 --> Helper loaded: url_helper
INFO - 2023-08-02 03:31:54 --> Helper loaded: file_helper
INFO - 2023-08-02 03:31:54 --> Helper loaded: html_helper
INFO - 2023-08-02 03:31:54 --> Helper loaded: text_helper
INFO - 2023-08-02 03:31:54 --> Helper loaded: form_helper
INFO - 2023-08-02 03:31:54 --> Helper loaded: lang_helper
INFO - 2023-08-02 03:31:54 --> Helper loaded: security_helper
INFO - 2023-08-02 03:31:54 --> Helper loaded: cookie_helper
INFO - 2023-08-02 03:31:54 --> Database Driver Class Initialized
INFO - 2023-08-02 03:31:54 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-02 03:31:54 --> Parser Class Initialized
INFO - 2023-08-02 03:31:54 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-02 03:31:54 --> Pagination Class Initialized
INFO - 2023-08-02 03:31:54 --> Form Validation Class Initialized
INFO - 2023-08-02 03:31:54 --> Controller Class Initialized
INFO - 2023-08-02 03:31:54 --> Model Class Initialized
DEBUG - 2023-08-02 03:31:54 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-02 03:31:54 --> Model Class Initialized
INFO - 2023-08-02 03:31:54 --> Final output sent to browser
DEBUG - 2023-08-02 03:31:54 --> Total execution time: 0.0206
ERROR - 2023-08-02 03:31:55 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-02 03:31:55 --> Config Class Initialized
INFO - 2023-08-02 03:31:55 --> Hooks Class Initialized
DEBUG - 2023-08-02 03:31:55 --> UTF-8 Support Enabled
INFO - 2023-08-02 03:31:55 --> Utf8 Class Initialized
INFO - 2023-08-02 03:31:55 --> URI Class Initialized
DEBUG - 2023-08-02 03:31:55 --> No URI present. Default controller set.
INFO - 2023-08-02 03:31:55 --> Router Class Initialized
INFO - 2023-08-02 03:31:55 --> Output Class Initialized
INFO - 2023-08-02 03:31:55 --> Security Class Initialized
DEBUG - 2023-08-02 03:31:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-02 03:31:55 --> Input Class Initialized
INFO - 2023-08-02 03:31:55 --> Language Class Initialized
INFO - 2023-08-02 03:31:55 --> Loader Class Initialized
INFO - 2023-08-02 03:31:55 --> Helper loaded: url_helper
INFO - 2023-08-02 03:31:55 --> Helper loaded: file_helper
INFO - 2023-08-02 03:31:55 --> Helper loaded: html_helper
INFO - 2023-08-02 03:31:55 --> Helper loaded: text_helper
INFO - 2023-08-02 03:31:55 --> Helper loaded: form_helper
INFO - 2023-08-02 03:31:55 --> Helper loaded: lang_helper
INFO - 2023-08-02 03:31:55 --> Helper loaded: security_helper
INFO - 2023-08-02 03:31:55 --> Helper loaded: cookie_helper
INFO - 2023-08-02 03:31:55 --> Database Driver Class Initialized
INFO - 2023-08-02 03:31:55 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-02 03:31:55 --> Parser Class Initialized
INFO - 2023-08-02 03:31:55 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-02 03:31:55 --> Pagination Class Initialized
INFO - 2023-08-02 03:31:55 --> Form Validation Class Initialized
INFO - 2023-08-02 03:31:55 --> Controller Class Initialized
INFO - 2023-08-02 03:31:55 --> Model Class Initialized
DEBUG - 2023-08-02 03:31:55 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-02 03:31:55 --> Model Class Initialized
DEBUG - 2023-08-02 03:31:55 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-02 03:31:55 --> Model Class Initialized
INFO - 2023-08-02 03:31:55 --> Model Class Initialized
INFO - 2023-08-02 03:31:55 --> Model Class Initialized
INFO - 2023-08-02 03:31:55 --> Model Class Initialized
DEBUG - 2023-08-02 03:31:55 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-02 03:31:55 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-02 03:31:55 --> Model Class Initialized
INFO - 2023-08-02 03:31:55 --> Model Class Initialized
INFO - 2023-08-02 03:31:55 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-08-02 03:31:55 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-08-02 03:31:55 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-08-02 03:31:55 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-08-02 03:31:55 --> Model Class Initialized
INFO - 2023-08-02 03:31:55 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-08-02 03:31:55 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-08-02 03:31:55 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-08-02 03:31:55 --> Final output sent to browser
DEBUG - 2023-08-02 03:31:55 --> Total execution time: 0.0877
ERROR - 2023-08-02 03:33:01 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-02 03:33:01 --> Config Class Initialized
INFO - 2023-08-02 03:33:01 --> Hooks Class Initialized
DEBUG - 2023-08-02 03:33:01 --> UTF-8 Support Enabled
INFO - 2023-08-02 03:33:01 --> Utf8 Class Initialized
INFO - 2023-08-02 03:33:01 --> URI Class Initialized
INFO - 2023-08-02 03:33:01 --> Router Class Initialized
INFO - 2023-08-02 03:33:01 --> Output Class Initialized
INFO - 2023-08-02 03:33:01 --> Security Class Initialized
DEBUG - 2023-08-02 03:33:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-02 03:33:01 --> Input Class Initialized
INFO - 2023-08-02 03:33:01 --> Language Class Initialized
INFO - 2023-08-02 03:33:01 --> Loader Class Initialized
INFO - 2023-08-02 03:33:01 --> Helper loaded: url_helper
INFO - 2023-08-02 03:33:01 --> Helper loaded: file_helper
INFO - 2023-08-02 03:33:01 --> Helper loaded: html_helper
INFO - 2023-08-02 03:33:01 --> Helper loaded: text_helper
INFO - 2023-08-02 03:33:01 --> Helper loaded: form_helper
INFO - 2023-08-02 03:33:01 --> Helper loaded: lang_helper
INFO - 2023-08-02 03:33:01 --> Helper loaded: security_helper
INFO - 2023-08-02 03:33:01 --> Helper loaded: cookie_helper
INFO - 2023-08-02 03:33:01 --> Database Driver Class Initialized
INFO - 2023-08-02 03:33:01 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-02 03:33:01 --> Parser Class Initialized
INFO - 2023-08-02 03:33:01 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-02 03:33:01 --> Pagination Class Initialized
INFO - 2023-08-02 03:33:01 --> Form Validation Class Initialized
INFO - 2023-08-02 03:33:01 --> Controller Class Initialized
INFO - 2023-08-02 03:33:01 --> Model Class Initialized
DEBUG - 2023-08-02 03:33:01 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-02 03:33:01 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-02 03:33:01 --> Model Class Initialized
INFO - 2023-08-02 03:33:01 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/demandrequest/demandrequest.php
DEBUG - 2023-08-02 03:33:01 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-08-02 03:33:01 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-08-02 03:33:01 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-08-02 03:33:01 --> Model Class Initialized
INFO - 2023-08-02 03:33:01 --> Model Class Initialized
INFO - 2023-08-02 03:33:01 --> Model Class Initialized
INFO - 2023-08-02 03:33:01 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-08-02 03:33:01 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-08-02 03:33:01 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-08-02 03:33:01 --> Final output sent to browser
DEBUG - 2023-08-02 03:33:01 --> Total execution time: 0.0822
ERROR - 2023-08-02 03:33:03 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-02 03:33:03 --> Config Class Initialized
INFO - 2023-08-02 03:33:03 --> Hooks Class Initialized
DEBUG - 2023-08-02 03:33:03 --> UTF-8 Support Enabled
INFO - 2023-08-02 03:33:03 --> Utf8 Class Initialized
INFO - 2023-08-02 03:33:03 --> URI Class Initialized
INFO - 2023-08-02 03:33:03 --> Router Class Initialized
INFO - 2023-08-02 03:33:03 --> Output Class Initialized
INFO - 2023-08-02 03:33:03 --> Security Class Initialized
DEBUG - 2023-08-02 03:33:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-02 03:33:03 --> Input Class Initialized
INFO - 2023-08-02 03:33:03 --> Language Class Initialized
INFO - 2023-08-02 03:33:03 --> Loader Class Initialized
INFO - 2023-08-02 03:33:03 --> Helper loaded: url_helper
INFO - 2023-08-02 03:33:03 --> Helper loaded: file_helper
INFO - 2023-08-02 03:33:03 --> Helper loaded: html_helper
INFO - 2023-08-02 03:33:03 --> Helper loaded: text_helper
INFO - 2023-08-02 03:33:03 --> Helper loaded: form_helper
INFO - 2023-08-02 03:33:03 --> Helper loaded: lang_helper
INFO - 2023-08-02 03:33:03 --> Helper loaded: security_helper
INFO - 2023-08-02 03:33:03 --> Helper loaded: cookie_helper
INFO - 2023-08-02 03:33:03 --> Database Driver Class Initialized
INFO - 2023-08-02 03:33:03 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-02 03:33:03 --> Parser Class Initialized
INFO - 2023-08-02 03:33:03 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-02 03:33:03 --> Pagination Class Initialized
INFO - 2023-08-02 03:33:03 --> Form Validation Class Initialized
INFO - 2023-08-02 03:33:03 --> Controller Class Initialized
INFO - 2023-08-02 03:33:03 --> Model Class Initialized
DEBUG - 2023-08-02 03:33:03 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-02 03:33:03 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-02 03:33:03 --> Model Class Initialized
INFO - 2023-08-02 03:33:03 --> Final output sent to browser
DEBUG - 2023-08-02 03:33:03 --> Total execution time: 0.0176
ERROR - 2023-08-02 06:12:26 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-02 06:12:26 --> Config Class Initialized
INFO - 2023-08-02 06:12:26 --> Hooks Class Initialized
DEBUG - 2023-08-02 06:12:26 --> UTF-8 Support Enabled
INFO - 2023-08-02 06:12:26 --> Utf8 Class Initialized
INFO - 2023-08-02 06:12:26 --> URI Class Initialized
DEBUG - 2023-08-02 06:12:26 --> No URI present. Default controller set.
INFO - 2023-08-02 06:12:26 --> Router Class Initialized
INFO - 2023-08-02 06:12:26 --> Output Class Initialized
INFO - 2023-08-02 06:12:26 --> Security Class Initialized
DEBUG - 2023-08-02 06:12:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-02 06:12:26 --> Input Class Initialized
INFO - 2023-08-02 06:12:26 --> Language Class Initialized
INFO - 2023-08-02 06:12:26 --> Loader Class Initialized
INFO - 2023-08-02 06:12:26 --> Helper loaded: url_helper
INFO - 2023-08-02 06:12:26 --> Helper loaded: file_helper
INFO - 2023-08-02 06:12:26 --> Helper loaded: html_helper
INFO - 2023-08-02 06:12:26 --> Helper loaded: text_helper
INFO - 2023-08-02 06:12:26 --> Helper loaded: form_helper
INFO - 2023-08-02 06:12:26 --> Helper loaded: lang_helper
INFO - 2023-08-02 06:12:26 --> Helper loaded: security_helper
INFO - 2023-08-02 06:12:26 --> Helper loaded: cookie_helper
INFO - 2023-08-02 06:12:26 --> Database Driver Class Initialized
INFO - 2023-08-02 06:12:26 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-02 06:12:26 --> Parser Class Initialized
INFO - 2023-08-02 06:12:26 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-02 06:12:26 --> Pagination Class Initialized
INFO - 2023-08-02 06:12:26 --> Form Validation Class Initialized
INFO - 2023-08-02 06:12:26 --> Controller Class Initialized
INFO - 2023-08-02 06:12:26 --> Model Class Initialized
DEBUG - 2023-08-02 06:12:26 --> Session class already loaded. Second attempt ignored.
ERROR - 2023-08-02 06:12:26 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-02 06:12:26 --> Config Class Initialized
INFO - 2023-08-02 06:12:26 --> Hooks Class Initialized
DEBUG - 2023-08-02 06:12:26 --> UTF-8 Support Enabled
INFO - 2023-08-02 06:12:26 --> Utf8 Class Initialized
INFO - 2023-08-02 06:12:26 --> URI Class Initialized
INFO - 2023-08-02 06:12:26 --> Router Class Initialized
INFO - 2023-08-02 06:12:26 --> Output Class Initialized
INFO - 2023-08-02 06:12:26 --> Security Class Initialized
DEBUG - 2023-08-02 06:12:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-02 06:12:26 --> Input Class Initialized
INFO - 2023-08-02 06:12:26 --> Language Class Initialized
INFO - 2023-08-02 06:12:26 --> Loader Class Initialized
INFO - 2023-08-02 06:12:26 --> Helper loaded: url_helper
INFO - 2023-08-02 06:12:26 --> Helper loaded: file_helper
INFO - 2023-08-02 06:12:26 --> Helper loaded: html_helper
INFO - 2023-08-02 06:12:26 --> Helper loaded: text_helper
INFO - 2023-08-02 06:12:26 --> Helper loaded: form_helper
INFO - 2023-08-02 06:12:26 --> Helper loaded: lang_helper
INFO - 2023-08-02 06:12:26 --> Helper loaded: security_helper
INFO - 2023-08-02 06:12:26 --> Helper loaded: cookie_helper
INFO - 2023-08-02 06:12:26 --> Database Driver Class Initialized
INFO - 2023-08-02 06:12:26 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-02 06:12:26 --> Parser Class Initialized
INFO - 2023-08-02 06:12:26 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-02 06:12:26 --> Pagination Class Initialized
INFO - 2023-08-02 06:12:26 --> Form Validation Class Initialized
INFO - 2023-08-02 06:12:26 --> Controller Class Initialized
INFO - 2023-08-02 06:12:26 --> Model Class Initialized
DEBUG - 2023-08-02 06:12:26 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-02 06:12:26 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2023-08-02 06:12:26 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-08-02 06:12:26 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-08-02 06:12:26 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-08-02 06:12:26 --> Model Class Initialized
INFO - 2023-08-02 06:12:26 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-08-02 06:12:26 --> Final output sent to browser
DEBUG - 2023-08-02 06:12:26 --> Total execution time: 0.0305
ERROR - 2023-08-02 06:17:36 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-02 06:17:36 --> Config Class Initialized
INFO - 2023-08-02 06:17:36 --> Hooks Class Initialized
DEBUG - 2023-08-02 06:17:36 --> UTF-8 Support Enabled
INFO - 2023-08-02 06:17:36 --> Utf8 Class Initialized
INFO - 2023-08-02 06:17:36 --> URI Class Initialized
INFO - 2023-08-02 06:17:36 --> Router Class Initialized
INFO - 2023-08-02 06:17:36 --> Output Class Initialized
INFO - 2023-08-02 06:17:36 --> Security Class Initialized
DEBUG - 2023-08-02 06:17:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-02 06:17:36 --> Input Class Initialized
INFO - 2023-08-02 06:17:36 --> Language Class Initialized
INFO - 2023-08-02 06:17:36 --> Loader Class Initialized
INFO - 2023-08-02 06:17:36 --> Helper loaded: url_helper
INFO - 2023-08-02 06:17:36 --> Helper loaded: file_helper
INFO - 2023-08-02 06:17:36 --> Helper loaded: html_helper
INFO - 2023-08-02 06:17:36 --> Helper loaded: text_helper
INFO - 2023-08-02 06:17:36 --> Helper loaded: form_helper
INFO - 2023-08-02 06:17:36 --> Helper loaded: lang_helper
INFO - 2023-08-02 06:17:36 --> Helper loaded: security_helper
INFO - 2023-08-02 06:17:36 --> Helper loaded: cookie_helper
INFO - 2023-08-02 06:17:36 --> Database Driver Class Initialized
INFO - 2023-08-02 06:17:36 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-02 06:17:36 --> Parser Class Initialized
INFO - 2023-08-02 06:17:36 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-02 06:17:36 --> Pagination Class Initialized
INFO - 2023-08-02 06:17:36 --> Form Validation Class Initialized
INFO - 2023-08-02 06:17:36 --> Controller Class Initialized
INFO - 2023-08-02 06:17:36 --> Model Class Initialized
DEBUG - 2023-08-02 06:17:36 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-02 06:17:36 --> Model Class Initialized
INFO - 2023-08-02 06:17:36 --> Final output sent to browser
DEBUG - 2023-08-02 06:17:36 --> Total execution time: 0.0228
ERROR - 2023-08-02 06:17:37 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-02 06:17:37 --> Config Class Initialized
INFO - 2023-08-02 06:17:37 --> Hooks Class Initialized
DEBUG - 2023-08-02 06:17:37 --> UTF-8 Support Enabled
INFO - 2023-08-02 06:17:37 --> Utf8 Class Initialized
INFO - 2023-08-02 06:17:37 --> URI Class Initialized
DEBUG - 2023-08-02 06:17:37 --> No URI present. Default controller set.
INFO - 2023-08-02 06:17:37 --> Router Class Initialized
INFO - 2023-08-02 06:17:37 --> Output Class Initialized
INFO - 2023-08-02 06:17:37 --> Security Class Initialized
DEBUG - 2023-08-02 06:17:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-02 06:17:37 --> Input Class Initialized
INFO - 2023-08-02 06:17:37 --> Language Class Initialized
INFO - 2023-08-02 06:17:37 --> Loader Class Initialized
INFO - 2023-08-02 06:17:37 --> Helper loaded: url_helper
INFO - 2023-08-02 06:17:37 --> Helper loaded: file_helper
INFO - 2023-08-02 06:17:37 --> Helper loaded: html_helper
INFO - 2023-08-02 06:17:37 --> Helper loaded: text_helper
INFO - 2023-08-02 06:17:37 --> Helper loaded: form_helper
INFO - 2023-08-02 06:17:37 --> Helper loaded: lang_helper
INFO - 2023-08-02 06:17:37 --> Helper loaded: security_helper
INFO - 2023-08-02 06:17:37 --> Helper loaded: cookie_helper
INFO - 2023-08-02 06:17:37 --> Database Driver Class Initialized
INFO - 2023-08-02 06:17:37 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-02 06:17:37 --> Parser Class Initialized
INFO - 2023-08-02 06:17:37 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-02 06:17:37 --> Pagination Class Initialized
INFO - 2023-08-02 06:17:37 --> Form Validation Class Initialized
INFO - 2023-08-02 06:17:37 --> Controller Class Initialized
INFO - 2023-08-02 06:17:37 --> Model Class Initialized
DEBUG - 2023-08-02 06:17:37 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-02 06:17:37 --> Model Class Initialized
DEBUG - 2023-08-02 06:17:37 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-02 06:17:37 --> Model Class Initialized
INFO - 2023-08-02 06:17:37 --> Model Class Initialized
INFO - 2023-08-02 06:17:37 --> Model Class Initialized
INFO - 2023-08-02 06:17:37 --> Model Class Initialized
DEBUG - 2023-08-02 06:17:37 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-02 06:17:37 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-02 06:17:37 --> Model Class Initialized
INFO - 2023-08-02 06:17:37 --> Model Class Initialized
INFO - 2023-08-02 06:17:37 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-08-02 06:17:37 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-08-02 06:17:37 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-08-02 06:17:37 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-08-02 06:17:37 --> Model Class Initialized
INFO - 2023-08-02 06:17:37 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-08-02 06:17:37 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-08-02 06:17:37 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-08-02 06:17:37 --> Final output sent to browser
DEBUG - 2023-08-02 06:17:37 --> Total execution time: 0.0908
ERROR - 2023-08-02 08:51:01 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-02 08:51:01 --> Config Class Initialized
INFO - 2023-08-02 08:51:01 --> Hooks Class Initialized
DEBUG - 2023-08-02 08:51:01 --> UTF-8 Support Enabled
INFO - 2023-08-02 08:51:01 --> Utf8 Class Initialized
INFO - 2023-08-02 08:51:01 --> URI Class Initialized
DEBUG - 2023-08-02 08:51:01 --> No URI present. Default controller set.
INFO - 2023-08-02 08:51:01 --> Router Class Initialized
INFO - 2023-08-02 08:51:01 --> Output Class Initialized
INFO - 2023-08-02 08:51:01 --> Security Class Initialized
DEBUG - 2023-08-02 08:51:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-02 08:51:01 --> Input Class Initialized
INFO - 2023-08-02 08:51:01 --> Language Class Initialized
INFO - 2023-08-02 08:51:01 --> Loader Class Initialized
INFO - 2023-08-02 08:51:01 --> Helper loaded: url_helper
INFO - 2023-08-02 08:51:01 --> Helper loaded: file_helper
INFO - 2023-08-02 08:51:01 --> Helper loaded: html_helper
INFO - 2023-08-02 08:51:01 --> Helper loaded: text_helper
INFO - 2023-08-02 08:51:01 --> Helper loaded: form_helper
INFO - 2023-08-02 08:51:01 --> Helper loaded: lang_helper
INFO - 2023-08-02 08:51:01 --> Helper loaded: security_helper
INFO - 2023-08-02 08:51:01 --> Helper loaded: cookie_helper
INFO - 2023-08-02 08:51:01 --> Database Driver Class Initialized
INFO - 2023-08-02 08:51:01 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-02 08:51:01 --> Parser Class Initialized
INFO - 2023-08-02 08:51:01 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-02 08:51:01 --> Pagination Class Initialized
INFO - 2023-08-02 08:51:01 --> Form Validation Class Initialized
INFO - 2023-08-02 08:51:01 --> Controller Class Initialized
INFO - 2023-08-02 08:51:01 --> Model Class Initialized
DEBUG - 2023-08-02 08:51:01 --> Session class already loaded. Second attempt ignored.
ERROR - 2023-08-02 08:51:01 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-02 08:51:01 --> Config Class Initialized
INFO - 2023-08-02 08:51:01 --> Hooks Class Initialized
DEBUG - 2023-08-02 08:51:01 --> UTF-8 Support Enabled
INFO - 2023-08-02 08:51:01 --> Utf8 Class Initialized
INFO - 2023-08-02 08:51:01 --> URI Class Initialized
INFO - 2023-08-02 08:51:01 --> Router Class Initialized
INFO - 2023-08-02 08:51:01 --> Output Class Initialized
INFO - 2023-08-02 08:51:01 --> Security Class Initialized
DEBUG - 2023-08-02 08:51:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-02 08:51:01 --> Input Class Initialized
INFO - 2023-08-02 08:51:01 --> Language Class Initialized
INFO - 2023-08-02 08:51:01 --> Loader Class Initialized
INFO - 2023-08-02 08:51:01 --> Helper loaded: url_helper
INFO - 2023-08-02 08:51:01 --> Helper loaded: file_helper
INFO - 2023-08-02 08:51:01 --> Helper loaded: html_helper
INFO - 2023-08-02 08:51:01 --> Helper loaded: text_helper
INFO - 2023-08-02 08:51:01 --> Helper loaded: form_helper
INFO - 2023-08-02 08:51:01 --> Helper loaded: lang_helper
INFO - 2023-08-02 08:51:01 --> Helper loaded: security_helper
INFO - 2023-08-02 08:51:01 --> Helper loaded: cookie_helper
INFO - 2023-08-02 08:51:01 --> Database Driver Class Initialized
INFO - 2023-08-02 08:51:01 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-02 08:51:01 --> Parser Class Initialized
INFO - 2023-08-02 08:51:01 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-02 08:51:01 --> Pagination Class Initialized
INFO - 2023-08-02 08:51:01 --> Form Validation Class Initialized
INFO - 2023-08-02 08:51:01 --> Controller Class Initialized
INFO - 2023-08-02 08:51:01 --> Model Class Initialized
DEBUG - 2023-08-02 08:51:01 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-02 08:51:01 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2023-08-02 08:51:01 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-08-02 08:51:01 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-08-02 08:51:01 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-08-02 08:51:01 --> Model Class Initialized
INFO - 2023-08-02 08:51:01 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-08-02 08:51:01 --> Final output sent to browser
DEBUG - 2023-08-02 08:51:01 --> Total execution time: 0.0327
ERROR - 2023-08-02 08:51:12 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-02 08:51:12 --> Config Class Initialized
INFO - 2023-08-02 08:51:12 --> Hooks Class Initialized
DEBUG - 2023-08-02 08:51:12 --> UTF-8 Support Enabled
INFO - 2023-08-02 08:51:12 --> Utf8 Class Initialized
INFO - 2023-08-02 08:51:12 --> URI Class Initialized
INFO - 2023-08-02 08:51:12 --> Router Class Initialized
INFO - 2023-08-02 08:51:12 --> Output Class Initialized
INFO - 2023-08-02 08:51:12 --> Security Class Initialized
DEBUG - 2023-08-02 08:51:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-02 08:51:12 --> Input Class Initialized
INFO - 2023-08-02 08:51:12 --> Language Class Initialized
INFO - 2023-08-02 08:51:12 --> Loader Class Initialized
INFO - 2023-08-02 08:51:12 --> Helper loaded: url_helper
INFO - 2023-08-02 08:51:12 --> Helper loaded: file_helper
INFO - 2023-08-02 08:51:12 --> Helper loaded: html_helper
INFO - 2023-08-02 08:51:12 --> Helper loaded: text_helper
INFO - 2023-08-02 08:51:12 --> Helper loaded: form_helper
INFO - 2023-08-02 08:51:12 --> Helper loaded: lang_helper
INFO - 2023-08-02 08:51:12 --> Helper loaded: security_helper
INFO - 2023-08-02 08:51:12 --> Helper loaded: cookie_helper
INFO - 2023-08-02 08:51:12 --> Database Driver Class Initialized
INFO - 2023-08-02 08:51:12 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-02 08:51:12 --> Parser Class Initialized
INFO - 2023-08-02 08:51:12 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-02 08:51:12 --> Pagination Class Initialized
INFO - 2023-08-02 08:51:12 --> Form Validation Class Initialized
INFO - 2023-08-02 08:51:12 --> Controller Class Initialized
INFO - 2023-08-02 08:51:12 --> Model Class Initialized
DEBUG - 2023-08-02 08:51:12 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-02 08:51:12 --> Model Class Initialized
INFO - 2023-08-02 08:51:12 --> Final output sent to browser
DEBUG - 2023-08-02 08:51:12 --> Total execution time: 0.0168
ERROR - 2023-08-02 08:51:12 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-02 08:51:12 --> Config Class Initialized
INFO - 2023-08-02 08:51:12 --> Hooks Class Initialized
DEBUG - 2023-08-02 08:51:12 --> UTF-8 Support Enabled
INFO - 2023-08-02 08:51:12 --> Utf8 Class Initialized
INFO - 2023-08-02 08:51:12 --> URI Class Initialized
DEBUG - 2023-08-02 08:51:12 --> No URI present. Default controller set.
INFO - 2023-08-02 08:51:12 --> Router Class Initialized
INFO - 2023-08-02 08:51:12 --> Output Class Initialized
INFO - 2023-08-02 08:51:12 --> Security Class Initialized
DEBUG - 2023-08-02 08:51:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-02 08:51:12 --> Input Class Initialized
INFO - 2023-08-02 08:51:12 --> Language Class Initialized
INFO - 2023-08-02 08:51:12 --> Loader Class Initialized
INFO - 2023-08-02 08:51:12 --> Helper loaded: url_helper
INFO - 2023-08-02 08:51:12 --> Helper loaded: file_helper
INFO - 2023-08-02 08:51:12 --> Helper loaded: html_helper
INFO - 2023-08-02 08:51:12 --> Helper loaded: text_helper
INFO - 2023-08-02 08:51:12 --> Helper loaded: form_helper
INFO - 2023-08-02 08:51:12 --> Helper loaded: lang_helper
INFO - 2023-08-02 08:51:12 --> Helper loaded: security_helper
INFO - 2023-08-02 08:51:12 --> Helper loaded: cookie_helper
INFO - 2023-08-02 08:51:12 --> Database Driver Class Initialized
INFO - 2023-08-02 08:51:12 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-02 08:51:12 --> Parser Class Initialized
INFO - 2023-08-02 08:51:12 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-02 08:51:12 --> Pagination Class Initialized
INFO - 2023-08-02 08:51:12 --> Form Validation Class Initialized
INFO - 2023-08-02 08:51:12 --> Controller Class Initialized
INFO - 2023-08-02 08:51:12 --> Model Class Initialized
DEBUG - 2023-08-02 08:51:12 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-02 08:51:12 --> Model Class Initialized
DEBUG - 2023-08-02 08:51:12 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-02 08:51:12 --> Model Class Initialized
INFO - 2023-08-02 08:51:12 --> Model Class Initialized
INFO - 2023-08-02 08:51:12 --> Model Class Initialized
INFO - 2023-08-02 08:51:12 --> Model Class Initialized
DEBUG - 2023-08-02 08:51:12 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-02 08:51:12 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-02 08:51:12 --> Model Class Initialized
INFO - 2023-08-02 08:51:12 --> Model Class Initialized
INFO - 2023-08-02 08:51:12 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-08-02 08:51:12 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-08-02 08:51:12 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-08-02 08:51:12 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-08-02 08:51:12 --> Model Class Initialized
INFO - 2023-08-02 08:51:12 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-08-02 08:51:12 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-08-02 08:51:12 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-08-02 08:51:12 --> Final output sent to browser
DEBUG - 2023-08-02 08:51:12 --> Total execution time: 0.1844
ERROR - 2023-08-02 08:51:13 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-02 08:51:13 --> Config Class Initialized
INFO - 2023-08-02 08:51:13 --> Hooks Class Initialized
DEBUG - 2023-08-02 08:51:13 --> UTF-8 Support Enabled
INFO - 2023-08-02 08:51:13 --> Utf8 Class Initialized
INFO - 2023-08-02 08:51:13 --> URI Class Initialized
INFO - 2023-08-02 08:51:13 --> Router Class Initialized
INFO - 2023-08-02 08:51:13 --> Output Class Initialized
INFO - 2023-08-02 08:51:13 --> Security Class Initialized
DEBUG - 2023-08-02 08:51:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-02 08:51:13 --> Input Class Initialized
INFO - 2023-08-02 08:51:13 --> Language Class Initialized
INFO - 2023-08-02 08:51:13 --> Loader Class Initialized
INFO - 2023-08-02 08:51:13 --> Helper loaded: url_helper
INFO - 2023-08-02 08:51:13 --> Helper loaded: file_helper
INFO - 2023-08-02 08:51:13 --> Helper loaded: html_helper
INFO - 2023-08-02 08:51:13 --> Helper loaded: text_helper
INFO - 2023-08-02 08:51:13 --> Helper loaded: form_helper
INFO - 2023-08-02 08:51:13 --> Helper loaded: lang_helper
INFO - 2023-08-02 08:51:13 --> Helper loaded: security_helper
INFO - 2023-08-02 08:51:13 --> Helper loaded: cookie_helper
INFO - 2023-08-02 08:51:13 --> Database Driver Class Initialized
INFO - 2023-08-02 08:51:13 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-02 08:51:13 --> Parser Class Initialized
INFO - 2023-08-02 08:51:13 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-02 08:51:13 --> Pagination Class Initialized
INFO - 2023-08-02 08:51:13 --> Form Validation Class Initialized
INFO - 2023-08-02 08:51:13 --> Controller Class Initialized
DEBUG - 2023-08-02 08:51:13 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-02 08:51:13 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-02 08:51:13 --> Model Class Initialized
INFO - 2023-08-02 08:51:13 --> Final output sent to browser
DEBUG - 2023-08-02 08:51:13 --> Total execution time: 0.0129
ERROR - 2023-08-02 08:55:47 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-02 08:55:47 --> Config Class Initialized
INFO - 2023-08-02 08:55:47 --> Hooks Class Initialized
DEBUG - 2023-08-02 08:55:47 --> UTF-8 Support Enabled
INFO - 2023-08-02 08:55:47 --> Utf8 Class Initialized
INFO - 2023-08-02 08:55:47 --> URI Class Initialized
DEBUG - 2023-08-02 08:55:47 --> No URI present. Default controller set.
INFO - 2023-08-02 08:55:47 --> Router Class Initialized
INFO - 2023-08-02 08:55:47 --> Output Class Initialized
INFO - 2023-08-02 08:55:47 --> Security Class Initialized
DEBUG - 2023-08-02 08:55:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-02 08:55:47 --> Input Class Initialized
INFO - 2023-08-02 08:55:47 --> Language Class Initialized
INFO - 2023-08-02 08:55:47 --> Loader Class Initialized
INFO - 2023-08-02 08:55:47 --> Helper loaded: url_helper
INFO - 2023-08-02 08:55:47 --> Helper loaded: file_helper
INFO - 2023-08-02 08:55:47 --> Helper loaded: html_helper
INFO - 2023-08-02 08:55:47 --> Helper loaded: text_helper
INFO - 2023-08-02 08:55:47 --> Helper loaded: form_helper
INFO - 2023-08-02 08:55:47 --> Helper loaded: lang_helper
INFO - 2023-08-02 08:55:47 --> Helper loaded: security_helper
INFO - 2023-08-02 08:55:47 --> Helper loaded: cookie_helper
INFO - 2023-08-02 08:55:47 --> Database Driver Class Initialized
INFO - 2023-08-02 08:55:47 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-02 08:55:47 --> Parser Class Initialized
INFO - 2023-08-02 08:55:47 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-02 08:55:47 --> Pagination Class Initialized
INFO - 2023-08-02 08:55:47 --> Form Validation Class Initialized
INFO - 2023-08-02 08:55:47 --> Controller Class Initialized
INFO - 2023-08-02 08:55:47 --> Model Class Initialized
DEBUG - 2023-08-02 08:55:47 --> Session class already loaded. Second attempt ignored.
ERROR - 2023-08-02 08:55:47 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-02 08:55:47 --> Config Class Initialized
INFO - 2023-08-02 08:55:47 --> Hooks Class Initialized
DEBUG - 2023-08-02 08:55:47 --> UTF-8 Support Enabled
INFO - 2023-08-02 08:55:47 --> Utf8 Class Initialized
INFO - 2023-08-02 08:55:47 --> URI Class Initialized
INFO - 2023-08-02 08:55:47 --> Router Class Initialized
INFO - 2023-08-02 08:55:47 --> Output Class Initialized
INFO - 2023-08-02 08:55:47 --> Security Class Initialized
DEBUG - 2023-08-02 08:55:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-02 08:55:47 --> Input Class Initialized
INFO - 2023-08-02 08:55:47 --> Language Class Initialized
INFO - 2023-08-02 08:55:47 --> Loader Class Initialized
INFO - 2023-08-02 08:55:47 --> Helper loaded: url_helper
INFO - 2023-08-02 08:55:47 --> Helper loaded: file_helper
INFO - 2023-08-02 08:55:47 --> Helper loaded: html_helper
INFO - 2023-08-02 08:55:47 --> Helper loaded: text_helper
INFO - 2023-08-02 08:55:47 --> Helper loaded: form_helper
INFO - 2023-08-02 08:55:47 --> Helper loaded: lang_helper
INFO - 2023-08-02 08:55:47 --> Helper loaded: security_helper
INFO - 2023-08-02 08:55:47 --> Helper loaded: cookie_helper
INFO - 2023-08-02 08:55:47 --> Database Driver Class Initialized
INFO - 2023-08-02 08:55:47 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-02 08:55:47 --> Parser Class Initialized
INFO - 2023-08-02 08:55:47 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-02 08:55:47 --> Pagination Class Initialized
INFO - 2023-08-02 08:55:47 --> Form Validation Class Initialized
INFO - 2023-08-02 08:55:47 --> Controller Class Initialized
INFO - 2023-08-02 08:55:47 --> Model Class Initialized
DEBUG - 2023-08-02 08:55:47 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-02 08:55:47 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2023-08-02 08:55:47 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-08-02 08:55:47 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-08-02 08:55:47 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-08-02 08:55:47 --> Model Class Initialized
INFO - 2023-08-02 08:55:47 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-08-02 08:55:47 --> Final output sent to browser
DEBUG - 2023-08-02 08:55:47 --> Total execution time: 0.0299
ERROR - 2023-08-02 10:59:48 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-02 10:59:48 --> Config Class Initialized
INFO - 2023-08-02 10:59:48 --> Hooks Class Initialized
DEBUG - 2023-08-02 10:59:48 --> UTF-8 Support Enabled
INFO - 2023-08-02 10:59:48 --> Utf8 Class Initialized
INFO - 2023-08-02 10:59:48 --> URI Class Initialized
DEBUG - 2023-08-02 10:59:48 --> No URI present. Default controller set.
INFO - 2023-08-02 10:59:48 --> Router Class Initialized
INFO - 2023-08-02 10:59:48 --> Output Class Initialized
INFO - 2023-08-02 10:59:48 --> Security Class Initialized
DEBUG - 2023-08-02 10:59:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-02 10:59:48 --> Input Class Initialized
INFO - 2023-08-02 10:59:48 --> Language Class Initialized
INFO - 2023-08-02 10:59:48 --> Loader Class Initialized
INFO - 2023-08-02 10:59:48 --> Helper loaded: url_helper
INFO - 2023-08-02 10:59:48 --> Helper loaded: file_helper
INFO - 2023-08-02 10:59:48 --> Helper loaded: html_helper
INFO - 2023-08-02 10:59:48 --> Helper loaded: text_helper
INFO - 2023-08-02 10:59:48 --> Helper loaded: form_helper
INFO - 2023-08-02 10:59:48 --> Helper loaded: lang_helper
INFO - 2023-08-02 10:59:48 --> Helper loaded: security_helper
INFO - 2023-08-02 10:59:48 --> Helper loaded: cookie_helper
INFO - 2023-08-02 10:59:48 --> Database Driver Class Initialized
INFO - 2023-08-02 10:59:48 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-02 10:59:48 --> Parser Class Initialized
INFO - 2023-08-02 10:59:48 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-02 10:59:48 --> Pagination Class Initialized
INFO - 2023-08-02 10:59:48 --> Form Validation Class Initialized
INFO - 2023-08-02 10:59:48 --> Controller Class Initialized
INFO - 2023-08-02 10:59:48 --> Model Class Initialized
DEBUG - 2023-08-02 10:59:48 --> Session class already loaded. Second attempt ignored.
ERROR - 2023-08-02 11:41:18 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-02 11:41:18 --> Config Class Initialized
INFO - 2023-08-02 11:41:18 --> Hooks Class Initialized
DEBUG - 2023-08-02 11:41:18 --> UTF-8 Support Enabled
INFO - 2023-08-02 11:41:18 --> Utf8 Class Initialized
INFO - 2023-08-02 11:41:18 --> URI Class Initialized
DEBUG - 2023-08-02 11:41:18 --> No URI present. Default controller set.
INFO - 2023-08-02 11:41:18 --> Router Class Initialized
INFO - 2023-08-02 11:41:18 --> Output Class Initialized
INFO - 2023-08-02 11:41:18 --> Security Class Initialized
DEBUG - 2023-08-02 11:41:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-02 11:41:18 --> Input Class Initialized
INFO - 2023-08-02 11:41:18 --> Language Class Initialized
INFO - 2023-08-02 11:41:18 --> Loader Class Initialized
INFO - 2023-08-02 11:41:18 --> Helper loaded: url_helper
INFO - 2023-08-02 11:41:18 --> Helper loaded: file_helper
INFO - 2023-08-02 11:41:18 --> Helper loaded: html_helper
INFO - 2023-08-02 11:41:18 --> Helper loaded: text_helper
INFO - 2023-08-02 11:41:18 --> Helper loaded: form_helper
INFO - 2023-08-02 11:41:18 --> Helper loaded: lang_helper
INFO - 2023-08-02 11:41:18 --> Helper loaded: security_helper
INFO - 2023-08-02 11:41:18 --> Helper loaded: cookie_helper
INFO - 2023-08-02 11:41:18 --> Database Driver Class Initialized
INFO - 2023-08-02 11:41:18 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-02 11:41:18 --> Parser Class Initialized
INFO - 2023-08-02 11:41:18 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-02 11:41:18 --> Pagination Class Initialized
INFO - 2023-08-02 11:41:18 --> Form Validation Class Initialized
INFO - 2023-08-02 11:41:18 --> Controller Class Initialized
INFO - 2023-08-02 11:41:18 --> Model Class Initialized
DEBUG - 2023-08-02 11:41:18 --> Session class already loaded. Second attempt ignored.
ERROR - 2023-08-02 11:41:19 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-02 11:41:19 --> Config Class Initialized
INFO - 2023-08-02 11:41:19 --> Hooks Class Initialized
DEBUG - 2023-08-02 11:41:19 --> UTF-8 Support Enabled
INFO - 2023-08-02 11:41:19 --> Utf8 Class Initialized
INFO - 2023-08-02 11:41:19 --> URI Class Initialized
INFO - 2023-08-02 11:41:19 --> Router Class Initialized
INFO - 2023-08-02 11:41:19 --> Output Class Initialized
INFO - 2023-08-02 11:41:19 --> Security Class Initialized
DEBUG - 2023-08-02 11:41:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-02 11:41:19 --> Input Class Initialized
INFO - 2023-08-02 11:41:19 --> Language Class Initialized
INFO - 2023-08-02 11:41:19 --> Loader Class Initialized
INFO - 2023-08-02 11:41:19 --> Helper loaded: url_helper
INFO - 2023-08-02 11:41:19 --> Helper loaded: file_helper
INFO - 2023-08-02 11:41:19 --> Helper loaded: html_helper
INFO - 2023-08-02 11:41:19 --> Helper loaded: text_helper
INFO - 2023-08-02 11:41:19 --> Helper loaded: form_helper
INFO - 2023-08-02 11:41:19 --> Helper loaded: lang_helper
INFO - 2023-08-02 11:41:19 --> Helper loaded: security_helper
INFO - 2023-08-02 11:41:19 --> Helper loaded: cookie_helper
INFO - 2023-08-02 11:41:19 --> Database Driver Class Initialized
INFO - 2023-08-02 11:41:19 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-02 11:41:19 --> Parser Class Initialized
INFO - 2023-08-02 11:41:19 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-02 11:41:19 --> Pagination Class Initialized
INFO - 2023-08-02 11:41:19 --> Form Validation Class Initialized
INFO - 2023-08-02 11:41:19 --> Controller Class Initialized
INFO - 2023-08-02 11:41:19 --> Model Class Initialized
DEBUG - 2023-08-02 11:41:19 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-02 11:41:19 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2023-08-02 11:41:19 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-08-02 11:41:19 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-08-02 11:41:19 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-08-02 11:41:19 --> Model Class Initialized
INFO - 2023-08-02 11:41:19 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-08-02 11:41:19 --> Final output sent to browser
DEBUG - 2023-08-02 11:41:19 --> Total execution time: 0.0383
ERROR - 2023-08-02 11:49:00 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-02 11:49:00 --> Config Class Initialized
INFO - 2023-08-02 11:49:00 --> Hooks Class Initialized
DEBUG - 2023-08-02 11:49:00 --> UTF-8 Support Enabled
INFO - 2023-08-02 11:49:00 --> Utf8 Class Initialized
INFO - 2023-08-02 11:49:00 --> URI Class Initialized
DEBUG - 2023-08-02 11:49:00 --> No URI present. Default controller set.
INFO - 2023-08-02 11:49:00 --> Router Class Initialized
INFO - 2023-08-02 11:49:00 --> Output Class Initialized
INFO - 2023-08-02 11:49:00 --> Security Class Initialized
DEBUG - 2023-08-02 11:49:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-02 11:49:00 --> Input Class Initialized
INFO - 2023-08-02 11:49:00 --> Language Class Initialized
INFO - 2023-08-02 11:49:00 --> Loader Class Initialized
INFO - 2023-08-02 11:49:00 --> Helper loaded: url_helper
INFO - 2023-08-02 11:49:00 --> Helper loaded: file_helper
INFO - 2023-08-02 11:49:00 --> Helper loaded: html_helper
INFO - 2023-08-02 11:49:00 --> Helper loaded: text_helper
INFO - 2023-08-02 11:49:00 --> Helper loaded: form_helper
INFO - 2023-08-02 11:49:00 --> Helper loaded: lang_helper
INFO - 2023-08-02 11:49:00 --> Helper loaded: security_helper
INFO - 2023-08-02 11:49:00 --> Helper loaded: cookie_helper
INFO - 2023-08-02 11:49:00 --> Database Driver Class Initialized
INFO - 2023-08-02 11:49:00 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-02 11:49:00 --> Parser Class Initialized
INFO - 2023-08-02 11:49:00 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-02 11:49:00 --> Pagination Class Initialized
INFO - 2023-08-02 11:49:00 --> Form Validation Class Initialized
INFO - 2023-08-02 11:49:00 --> Controller Class Initialized
INFO - 2023-08-02 11:49:00 --> Model Class Initialized
DEBUG - 2023-08-02 11:49:00 --> Session class already loaded. Second attempt ignored.
ERROR - 2023-08-02 11:49:23 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-02 11:49:23 --> Config Class Initialized
INFO - 2023-08-02 11:49:23 --> Hooks Class Initialized
DEBUG - 2023-08-02 11:49:23 --> UTF-8 Support Enabled
INFO - 2023-08-02 11:49:23 --> Utf8 Class Initialized
INFO - 2023-08-02 11:49:23 --> URI Class Initialized
INFO - 2023-08-02 11:49:23 --> Router Class Initialized
INFO - 2023-08-02 11:49:23 --> Output Class Initialized
INFO - 2023-08-02 11:49:23 --> Security Class Initialized
DEBUG - 2023-08-02 11:49:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-02 11:49:23 --> Input Class Initialized
INFO - 2023-08-02 11:49:23 --> Language Class Initialized
INFO - 2023-08-02 11:49:23 --> Loader Class Initialized
INFO - 2023-08-02 11:49:23 --> Helper loaded: url_helper
INFO - 2023-08-02 11:49:23 --> Helper loaded: file_helper
INFO - 2023-08-02 11:49:23 --> Helper loaded: html_helper
INFO - 2023-08-02 11:49:23 --> Helper loaded: text_helper
INFO - 2023-08-02 11:49:23 --> Helper loaded: form_helper
INFO - 2023-08-02 11:49:23 --> Helper loaded: lang_helper
INFO - 2023-08-02 11:49:23 --> Helper loaded: security_helper
INFO - 2023-08-02 11:49:23 --> Helper loaded: cookie_helper
INFO - 2023-08-02 11:49:23 --> Database Driver Class Initialized
INFO - 2023-08-02 11:49:23 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-02 11:49:23 --> Parser Class Initialized
INFO - 2023-08-02 11:49:23 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-02 11:49:23 --> Pagination Class Initialized
INFO - 2023-08-02 11:49:23 --> Form Validation Class Initialized
INFO - 2023-08-02 11:49:23 --> Controller Class Initialized
INFO - 2023-08-02 11:49:23 --> Model Class Initialized
DEBUG - 2023-08-02 11:49:23 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-02 11:49:23 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2023-08-02 11:49:23 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-08-02 11:49:23 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-08-02 11:49:23 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-08-02 11:49:23 --> Model Class Initialized
INFO - 2023-08-02 11:49:23 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-08-02 11:49:23 --> Final output sent to browser
DEBUG - 2023-08-02 11:49:23 --> Total execution time: 0.0338
ERROR - 2023-08-02 12:58:44 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-02 12:58:44 --> Config Class Initialized
INFO - 2023-08-02 12:58:44 --> Hooks Class Initialized
DEBUG - 2023-08-02 12:58:44 --> UTF-8 Support Enabled
INFO - 2023-08-02 12:58:44 --> Utf8 Class Initialized
INFO - 2023-08-02 12:58:44 --> URI Class Initialized
INFO - 2023-08-02 12:58:44 --> Router Class Initialized
INFO - 2023-08-02 12:58:44 --> Output Class Initialized
INFO - 2023-08-02 12:58:44 --> Security Class Initialized
DEBUG - 2023-08-02 12:58:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-02 12:58:44 --> Input Class Initialized
INFO - 2023-08-02 12:58:44 --> Language Class Initialized
INFO - 2023-08-02 12:58:44 --> Loader Class Initialized
INFO - 2023-08-02 12:58:44 --> Helper loaded: url_helper
INFO - 2023-08-02 12:58:44 --> Helper loaded: file_helper
INFO - 2023-08-02 12:58:44 --> Helper loaded: html_helper
INFO - 2023-08-02 12:58:44 --> Helper loaded: text_helper
INFO - 2023-08-02 12:58:44 --> Helper loaded: form_helper
INFO - 2023-08-02 12:58:44 --> Helper loaded: lang_helper
INFO - 2023-08-02 12:58:44 --> Helper loaded: security_helper
INFO - 2023-08-02 12:58:44 --> Helper loaded: cookie_helper
INFO - 2023-08-02 12:58:44 --> Database Driver Class Initialized
INFO - 2023-08-02 12:58:44 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-02 12:58:44 --> Parser Class Initialized
INFO - 2023-08-02 12:58:44 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-02 12:58:44 --> Pagination Class Initialized
INFO - 2023-08-02 12:58:44 --> Form Validation Class Initialized
INFO - 2023-08-02 12:58:44 --> Controller Class Initialized
INFO - 2023-08-02 12:58:44 --> Model Class Initialized
DEBUG - 2023-08-02 12:58:44 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-02 12:58:44 --> Model Class Initialized
INFO - 2023-08-02 12:58:44 --> Final output sent to browser
DEBUG - 2023-08-02 12:58:44 --> Total execution time: 0.0203
ERROR - 2023-08-02 12:58:45 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-02 12:58:45 --> Config Class Initialized
INFO - 2023-08-02 12:58:45 --> Hooks Class Initialized
DEBUG - 2023-08-02 12:58:45 --> UTF-8 Support Enabled
INFO - 2023-08-02 12:58:45 --> Utf8 Class Initialized
INFO - 2023-08-02 12:58:45 --> URI Class Initialized
DEBUG - 2023-08-02 12:58:45 --> No URI present. Default controller set.
INFO - 2023-08-02 12:58:45 --> Router Class Initialized
INFO - 2023-08-02 12:58:45 --> Output Class Initialized
INFO - 2023-08-02 12:58:45 --> Security Class Initialized
DEBUG - 2023-08-02 12:58:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-02 12:58:45 --> Input Class Initialized
INFO - 2023-08-02 12:58:45 --> Language Class Initialized
INFO - 2023-08-02 12:58:45 --> Loader Class Initialized
INFO - 2023-08-02 12:58:45 --> Helper loaded: url_helper
INFO - 2023-08-02 12:58:45 --> Helper loaded: file_helper
INFO - 2023-08-02 12:58:45 --> Helper loaded: html_helper
INFO - 2023-08-02 12:58:45 --> Helper loaded: text_helper
INFO - 2023-08-02 12:58:45 --> Helper loaded: form_helper
INFO - 2023-08-02 12:58:45 --> Helper loaded: lang_helper
INFO - 2023-08-02 12:58:45 --> Helper loaded: security_helper
INFO - 2023-08-02 12:58:45 --> Helper loaded: cookie_helper
INFO - 2023-08-02 12:58:45 --> Database Driver Class Initialized
INFO - 2023-08-02 12:58:45 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-02 12:58:45 --> Parser Class Initialized
INFO - 2023-08-02 12:58:45 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-02 12:58:45 --> Pagination Class Initialized
INFO - 2023-08-02 12:58:45 --> Form Validation Class Initialized
INFO - 2023-08-02 12:58:45 --> Controller Class Initialized
INFO - 2023-08-02 12:58:45 --> Model Class Initialized
DEBUG - 2023-08-02 12:58:45 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-02 12:58:45 --> Model Class Initialized
DEBUG - 2023-08-02 12:58:45 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-02 12:58:45 --> Model Class Initialized
INFO - 2023-08-02 12:58:45 --> Model Class Initialized
INFO - 2023-08-02 12:58:45 --> Model Class Initialized
INFO - 2023-08-02 12:58:45 --> Model Class Initialized
DEBUG - 2023-08-02 12:58:45 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-02 12:58:45 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-02 12:58:45 --> Model Class Initialized
INFO - 2023-08-02 12:58:45 --> Model Class Initialized
INFO - 2023-08-02 12:58:45 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-08-02 12:58:45 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-08-02 12:58:45 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-08-02 12:58:45 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-08-02 12:58:45 --> Model Class Initialized
INFO - 2023-08-02 12:58:45 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-08-02 12:58:45 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-08-02 12:58:45 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-08-02 12:58:45 --> Final output sent to browser
DEBUG - 2023-08-02 12:58:45 --> Total execution time: 0.1729
ERROR - 2023-08-02 12:58:46 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-02 12:58:46 --> Config Class Initialized
INFO - 2023-08-02 12:58:46 --> Hooks Class Initialized
DEBUG - 2023-08-02 12:58:46 --> UTF-8 Support Enabled
INFO - 2023-08-02 12:58:46 --> Utf8 Class Initialized
INFO - 2023-08-02 12:58:46 --> URI Class Initialized
INFO - 2023-08-02 12:58:46 --> Router Class Initialized
INFO - 2023-08-02 12:58:46 --> Output Class Initialized
INFO - 2023-08-02 12:58:46 --> Security Class Initialized
DEBUG - 2023-08-02 12:58:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-02 12:58:46 --> Input Class Initialized
INFO - 2023-08-02 12:58:46 --> Language Class Initialized
INFO - 2023-08-02 12:58:46 --> Loader Class Initialized
INFO - 2023-08-02 12:58:46 --> Helper loaded: url_helper
INFO - 2023-08-02 12:58:46 --> Helper loaded: file_helper
INFO - 2023-08-02 12:58:46 --> Helper loaded: html_helper
INFO - 2023-08-02 12:58:46 --> Helper loaded: text_helper
INFO - 2023-08-02 12:58:46 --> Helper loaded: form_helper
INFO - 2023-08-02 12:58:46 --> Helper loaded: lang_helper
INFO - 2023-08-02 12:58:46 --> Helper loaded: security_helper
INFO - 2023-08-02 12:58:46 --> Helper loaded: cookie_helper
INFO - 2023-08-02 12:58:46 --> Database Driver Class Initialized
INFO - 2023-08-02 12:58:46 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-02 12:58:46 --> Parser Class Initialized
INFO - 2023-08-02 12:58:46 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-02 12:58:46 --> Pagination Class Initialized
INFO - 2023-08-02 12:58:46 --> Form Validation Class Initialized
INFO - 2023-08-02 12:58:46 --> Controller Class Initialized
DEBUG - 2023-08-02 12:58:46 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-02 12:58:46 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-02 12:58:46 --> Model Class Initialized
INFO - 2023-08-02 12:58:46 --> Final output sent to browser
DEBUG - 2023-08-02 12:58:46 --> Total execution time: 0.0135
ERROR - 2023-08-02 12:58:59 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-02 12:58:59 --> Config Class Initialized
INFO - 2023-08-02 12:58:59 --> Hooks Class Initialized
DEBUG - 2023-08-02 12:58:59 --> UTF-8 Support Enabled
INFO - 2023-08-02 12:58:59 --> Utf8 Class Initialized
INFO - 2023-08-02 12:58:59 --> URI Class Initialized
INFO - 2023-08-02 12:58:59 --> Router Class Initialized
INFO - 2023-08-02 12:58:59 --> Output Class Initialized
INFO - 2023-08-02 12:58:59 --> Security Class Initialized
DEBUG - 2023-08-02 12:58:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-02 12:58:59 --> Input Class Initialized
INFO - 2023-08-02 12:58:59 --> Language Class Initialized
INFO - 2023-08-02 12:58:59 --> Loader Class Initialized
INFO - 2023-08-02 12:58:59 --> Helper loaded: url_helper
INFO - 2023-08-02 12:58:59 --> Helper loaded: file_helper
INFO - 2023-08-02 12:58:59 --> Helper loaded: html_helper
INFO - 2023-08-02 12:58:59 --> Helper loaded: text_helper
INFO - 2023-08-02 12:58:59 --> Helper loaded: form_helper
INFO - 2023-08-02 12:58:59 --> Helper loaded: lang_helper
INFO - 2023-08-02 12:58:59 --> Helper loaded: security_helper
INFO - 2023-08-02 12:58:59 --> Helper loaded: cookie_helper
INFO - 2023-08-02 12:58:59 --> Database Driver Class Initialized
INFO - 2023-08-02 12:58:59 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-02 12:58:59 --> Parser Class Initialized
INFO - 2023-08-02 12:58:59 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-02 12:58:59 --> Pagination Class Initialized
INFO - 2023-08-02 12:58:59 --> Form Validation Class Initialized
INFO - 2023-08-02 12:58:59 --> Controller Class Initialized
INFO - 2023-08-02 12:58:59 --> Model Class Initialized
DEBUG - 2023-08-02 12:58:59 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-02 12:58:59 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-02 12:58:59 --> Model Class Initialized
INFO - 2023-08-02 12:58:59 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/stockrequest/stockrequest.php
DEBUG - 2023-08-02 12:58:59 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-08-02 12:58:59 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-08-02 12:58:59 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-08-02 12:58:59 --> Model Class Initialized
INFO - 2023-08-02 12:58:59 --> Model Class Initialized
INFO - 2023-08-02 12:58:59 --> Model Class Initialized
INFO - 2023-08-02 12:58:59 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-08-02 12:58:59 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-08-02 12:58:59 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-08-02 12:58:59 --> Final output sent to browser
DEBUG - 2023-08-02 12:58:59 --> Total execution time: 0.1342
ERROR - 2023-08-02 12:59:00 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-02 12:59:00 --> Config Class Initialized
INFO - 2023-08-02 12:59:00 --> Hooks Class Initialized
DEBUG - 2023-08-02 12:59:00 --> UTF-8 Support Enabled
INFO - 2023-08-02 12:59:00 --> Utf8 Class Initialized
INFO - 2023-08-02 12:59:00 --> URI Class Initialized
INFO - 2023-08-02 12:59:00 --> Router Class Initialized
INFO - 2023-08-02 12:59:00 --> Output Class Initialized
INFO - 2023-08-02 12:59:00 --> Security Class Initialized
DEBUG - 2023-08-02 12:59:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-02 12:59:00 --> Input Class Initialized
INFO - 2023-08-02 12:59:00 --> Language Class Initialized
INFO - 2023-08-02 12:59:00 --> Loader Class Initialized
INFO - 2023-08-02 12:59:00 --> Helper loaded: url_helper
INFO - 2023-08-02 12:59:00 --> Helper loaded: file_helper
INFO - 2023-08-02 12:59:00 --> Helper loaded: html_helper
INFO - 2023-08-02 12:59:00 --> Helper loaded: text_helper
INFO - 2023-08-02 12:59:00 --> Helper loaded: form_helper
INFO - 2023-08-02 12:59:00 --> Helper loaded: lang_helper
INFO - 2023-08-02 12:59:00 --> Helper loaded: security_helper
INFO - 2023-08-02 12:59:00 --> Helper loaded: cookie_helper
INFO - 2023-08-02 12:59:00 --> Database Driver Class Initialized
INFO - 2023-08-02 12:59:00 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-02 12:59:00 --> Parser Class Initialized
INFO - 2023-08-02 12:59:00 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-02 12:59:00 --> Pagination Class Initialized
INFO - 2023-08-02 12:59:00 --> Form Validation Class Initialized
INFO - 2023-08-02 12:59:00 --> Controller Class Initialized
INFO - 2023-08-02 12:59:00 --> Model Class Initialized
DEBUG - 2023-08-02 12:59:00 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-02 12:59:00 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-02 12:59:00 --> Model Class Initialized
INFO - 2023-08-02 12:59:00 --> Final output sent to browser
DEBUG - 2023-08-02 12:59:00 --> Total execution time: 0.0269
ERROR - 2023-08-02 12:59:08 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-02 12:59:08 --> Config Class Initialized
INFO - 2023-08-02 12:59:08 --> Hooks Class Initialized
DEBUG - 2023-08-02 12:59:08 --> UTF-8 Support Enabled
INFO - 2023-08-02 12:59:08 --> Utf8 Class Initialized
INFO - 2023-08-02 12:59:08 --> URI Class Initialized
INFO - 2023-08-02 12:59:08 --> Router Class Initialized
INFO - 2023-08-02 12:59:08 --> Output Class Initialized
INFO - 2023-08-02 12:59:08 --> Security Class Initialized
DEBUG - 2023-08-02 12:59:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-02 12:59:08 --> Input Class Initialized
INFO - 2023-08-02 12:59:08 --> Language Class Initialized
INFO - 2023-08-02 12:59:08 --> Loader Class Initialized
INFO - 2023-08-02 12:59:08 --> Helper loaded: url_helper
INFO - 2023-08-02 12:59:08 --> Helper loaded: file_helper
INFO - 2023-08-02 12:59:08 --> Helper loaded: html_helper
INFO - 2023-08-02 12:59:08 --> Helper loaded: text_helper
INFO - 2023-08-02 12:59:08 --> Helper loaded: form_helper
INFO - 2023-08-02 12:59:08 --> Helper loaded: lang_helper
INFO - 2023-08-02 12:59:08 --> Helper loaded: security_helper
INFO - 2023-08-02 12:59:08 --> Helper loaded: cookie_helper
INFO - 2023-08-02 12:59:08 --> Database Driver Class Initialized
INFO - 2023-08-02 12:59:08 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-02 12:59:08 --> Parser Class Initialized
INFO - 2023-08-02 12:59:08 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-02 12:59:08 --> Pagination Class Initialized
INFO - 2023-08-02 12:59:08 --> Form Validation Class Initialized
INFO - 2023-08-02 12:59:08 --> Controller Class Initialized
INFO - 2023-08-02 12:59:08 --> Model Class Initialized
DEBUG - 2023-08-02 12:59:08 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-02 12:59:08 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-02 12:59:08 --> Model Class Initialized
INFO - 2023-08-02 12:59:08 --> Final output sent to browser
DEBUG - 2023-08-02 12:59:08 --> Total execution time: 0.0733
ERROR - 2023-08-02 12:59:26 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-02 12:59:26 --> Config Class Initialized
INFO - 2023-08-02 12:59:26 --> Hooks Class Initialized
DEBUG - 2023-08-02 12:59:26 --> UTF-8 Support Enabled
INFO - 2023-08-02 12:59:26 --> Utf8 Class Initialized
INFO - 2023-08-02 12:59:26 --> URI Class Initialized
INFO - 2023-08-02 12:59:26 --> Router Class Initialized
INFO - 2023-08-02 12:59:26 --> Output Class Initialized
INFO - 2023-08-02 12:59:26 --> Security Class Initialized
DEBUG - 2023-08-02 12:59:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-02 12:59:26 --> Input Class Initialized
INFO - 2023-08-02 12:59:26 --> Language Class Initialized
INFO - 2023-08-02 12:59:26 --> Loader Class Initialized
INFO - 2023-08-02 12:59:26 --> Helper loaded: url_helper
INFO - 2023-08-02 12:59:26 --> Helper loaded: file_helper
INFO - 2023-08-02 12:59:26 --> Helper loaded: html_helper
INFO - 2023-08-02 12:59:26 --> Helper loaded: text_helper
INFO - 2023-08-02 12:59:26 --> Helper loaded: form_helper
INFO - 2023-08-02 12:59:26 --> Helper loaded: lang_helper
INFO - 2023-08-02 12:59:26 --> Helper loaded: security_helper
INFO - 2023-08-02 12:59:26 --> Helper loaded: cookie_helper
INFO - 2023-08-02 12:59:26 --> Database Driver Class Initialized
INFO - 2023-08-02 12:59:26 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-02 12:59:26 --> Parser Class Initialized
INFO - 2023-08-02 12:59:26 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-02 12:59:26 --> Pagination Class Initialized
INFO - 2023-08-02 12:59:26 --> Form Validation Class Initialized
INFO - 2023-08-02 12:59:26 --> Controller Class Initialized
INFO - 2023-08-02 12:59:26 --> Model Class Initialized
DEBUG - 2023-08-02 12:59:26 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-02 12:59:26 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-02 12:59:26 --> Model Class Initialized
DEBUG - 2023-08-02 12:59:26 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-02 12:59:26 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/stockrequest/stockrequest_html.php
DEBUG - 2023-08-02 12:59:26 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-08-02 12:59:26 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-08-02 12:59:26 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-08-02 12:59:26 --> Model Class Initialized
INFO - 2023-08-02 12:59:26 --> Model Class Initialized
INFO - 2023-08-02 12:59:26 --> Model Class Initialized
INFO - 2023-08-02 12:59:26 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-08-02 12:59:26 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-08-02 12:59:26 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-08-02 12:59:26 --> Final output sent to browser
DEBUG - 2023-08-02 12:59:26 --> Total execution time: 0.1399
ERROR - 2023-08-02 12:59:35 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-02 12:59:35 --> Config Class Initialized
INFO - 2023-08-02 12:59:35 --> Hooks Class Initialized
DEBUG - 2023-08-02 12:59:35 --> UTF-8 Support Enabled
INFO - 2023-08-02 12:59:35 --> Utf8 Class Initialized
INFO - 2023-08-02 12:59:35 --> URI Class Initialized
INFO - 2023-08-02 12:59:35 --> Router Class Initialized
INFO - 2023-08-02 12:59:35 --> Output Class Initialized
INFO - 2023-08-02 12:59:35 --> Security Class Initialized
DEBUG - 2023-08-02 12:59:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-02 12:59:35 --> Input Class Initialized
INFO - 2023-08-02 12:59:35 --> Language Class Initialized
INFO - 2023-08-02 12:59:35 --> Loader Class Initialized
INFO - 2023-08-02 12:59:35 --> Helper loaded: url_helper
INFO - 2023-08-02 12:59:35 --> Helper loaded: file_helper
INFO - 2023-08-02 12:59:35 --> Helper loaded: html_helper
INFO - 2023-08-02 12:59:35 --> Helper loaded: text_helper
INFO - 2023-08-02 12:59:35 --> Helper loaded: form_helper
INFO - 2023-08-02 12:59:35 --> Helper loaded: lang_helper
INFO - 2023-08-02 12:59:35 --> Helper loaded: security_helper
INFO - 2023-08-02 12:59:35 --> Helper loaded: cookie_helper
INFO - 2023-08-02 12:59:35 --> Database Driver Class Initialized
INFO - 2023-08-02 12:59:35 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-02 12:59:35 --> Parser Class Initialized
INFO - 2023-08-02 12:59:35 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-02 12:59:35 --> Pagination Class Initialized
INFO - 2023-08-02 12:59:35 --> Form Validation Class Initialized
INFO - 2023-08-02 12:59:35 --> Controller Class Initialized
INFO - 2023-08-02 12:59:35 --> Model Class Initialized
DEBUG - 2023-08-02 12:59:35 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-02 12:59:35 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-02 12:59:35 --> Model Class Initialized
INFO - 2023-08-02 12:59:35 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/stockrequest/stockrequest.php
DEBUG - 2023-08-02 12:59:35 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-08-02 12:59:35 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-08-02 12:59:35 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-08-02 12:59:35 --> Model Class Initialized
INFO - 2023-08-02 12:59:35 --> Model Class Initialized
INFO - 2023-08-02 12:59:35 --> Model Class Initialized
INFO - 2023-08-02 12:59:35 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-08-02 12:59:35 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-08-02 12:59:35 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-08-02 12:59:35 --> Final output sent to browser
DEBUG - 2023-08-02 12:59:35 --> Total execution time: 0.1445
ERROR - 2023-08-02 12:59:57 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-02 12:59:57 --> Config Class Initialized
INFO - 2023-08-02 12:59:57 --> Hooks Class Initialized
DEBUG - 2023-08-02 12:59:57 --> UTF-8 Support Enabled
INFO - 2023-08-02 12:59:57 --> Utf8 Class Initialized
INFO - 2023-08-02 12:59:57 --> URI Class Initialized
INFO - 2023-08-02 12:59:57 --> Router Class Initialized
INFO - 2023-08-02 12:59:57 --> Output Class Initialized
INFO - 2023-08-02 12:59:57 --> Security Class Initialized
DEBUG - 2023-08-02 12:59:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-02 12:59:57 --> Input Class Initialized
INFO - 2023-08-02 12:59:57 --> Language Class Initialized
INFO - 2023-08-02 12:59:57 --> Loader Class Initialized
INFO - 2023-08-02 12:59:57 --> Helper loaded: url_helper
INFO - 2023-08-02 12:59:57 --> Helper loaded: file_helper
INFO - 2023-08-02 12:59:57 --> Helper loaded: html_helper
INFO - 2023-08-02 12:59:57 --> Helper loaded: text_helper
INFO - 2023-08-02 12:59:57 --> Helper loaded: form_helper
INFO - 2023-08-02 12:59:57 --> Helper loaded: lang_helper
INFO - 2023-08-02 12:59:57 --> Helper loaded: security_helper
INFO - 2023-08-02 12:59:57 --> Helper loaded: cookie_helper
INFO - 2023-08-02 12:59:57 --> Database Driver Class Initialized
INFO - 2023-08-02 12:59:57 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-02 12:59:57 --> Parser Class Initialized
INFO - 2023-08-02 12:59:57 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-02 12:59:57 --> Pagination Class Initialized
INFO - 2023-08-02 12:59:57 --> Form Validation Class Initialized
INFO - 2023-08-02 12:59:57 --> Controller Class Initialized
INFO - 2023-08-02 12:59:57 --> Model Class Initialized
DEBUG - 2023-08-02 12:59:57 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-02 12:59:57 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-02 12:59:57 --> Model Class Initialized
INFO - 2023-08-02 12:59:57 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/stockrequest/stockrequest.php
DEBUG - 2023-08-02 12:59:57 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-08-02 12:59:57 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-08-02 12:59:57 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-08-02 12:59:57 --> Model Class Initialized
INFO - 2023-08-02 12:59:57 --> Model Class Initialized
INFO - 2023-08-02 12:59:57 --> Model Class Initialized
INFO - 2023-08-02 12:59:57 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-08-02 12:59:57 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-08-02 12:59:57 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-08-02 12:59:57 --> Final output sent to browser
DEBUG - 2023-08-02 12:59:57 --> Total execution time: 0.1421
ERROR - 2023-08-02 13:00:10 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-02 13:00:10 --> Config Class Initialized
INFO - 2023-08-02 13:00:10 --> Hooks Class Initialized
DEBUG - 2023-08-02 13:00:10 --> UTF-8 Support Enabled
INFO - 2023-08-02 13:00:10 --> Utf8 Class Initialized
INFO - 2023-08-02 13:00:10 --> URI Class Initialized
INFO - 2023-08-02 13:00:10 --> Router Class Initialized
INFO - 2023-08-02 13:00:10 --> Output Class Initialized
INFO - 2023-08-02 13:00:10 --> Security Class Initialized
DEBUG - 2023-08-02 13:00:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-02 13:00:10 --> Input Class Initialized
INFO - 2023-08-02 13:00:10 --> Language Class Initialized
INFO - 2023-08-02 13:00:10 --> Loader Class Initialized
INFO - 2023-08-02 13:00:10 --> Helper loaded: url_helper
INFO - 2023-08-02 13:00:10 --> Helper loaded: file_helper
INFO - 2023-08-02 13:00:10 --> Helper loaded: html_helper
INFO - 2023-08-02 13:00:10 --> Helper loaded: text_helper
INFO - 2023-08-02 13:00:10 --> Helper loaded: form_helper
INFO - 2023-08-02 13:00:10 --> Helper loaded: lang_helper
INFO - 2023-08-02 13:00:10 --> Helper loaded: security_helper
INFO - 2023-08-02 13:00:10 --> Helper loaded: cookie_helper
INFO - 2023-08-02 13:00:10 --> Database Driver Class Initialized
INFO - 2023-08-02 13:00:10 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-02 13:00:10 --> Parser Class Initialized
INFO - 2023-08-02 13:00:10 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-02 13:00:10 --> Pagination Class Initialized
INFO - 2023-08-02 13:00:10 --> Form Validation Class Initialized
INFO - 2023-08-02 13:00:10 --> Controller Class Initialized
INFO - 2023-08-02 13:00:10 --> Model Class Initialized
DEBUG - 2023-08-02 13:00:10 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-02 13:00:10 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-02 13:00:10 --> Model Class Initialized
INFO - 2023-08-02 13:00:10 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/stockrequest/stockrequest.php
DEBUG - 2023-08-02 13:00:10 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-08-02 13:00:10 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-08-02 13:00:10 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-08-02 13:00:10 --> Model Class Initialized
INFO - 2023-08-02 13:00:10 --> Model Class Initialized
INFO - 2023-08-02 13:00:10 --> Model Class Initialized
INFO - 2023-08-02 13:00:10 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-08-02 13:00:10 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-08-02 13:00:10 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-08-02 13:00:10 --> Final output sent to browser
DEBUG - 2023-08-02 13:00:10 --> Total execution time: 0.1492
ERROR - 2023-08-02 13:00:31 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-02 13:00:31 --> Config Class Initialized
INFO - 2023-08-02 13:00:31 --> Hooks Class Initialized
DEBUG - 2023-08-02 13:00:31 --> UTF-8 Support Enabled
INFO - 2023-08-02 13:00:31 --> Utf8 Class Initialized
INFO - 2023-08-02 13:00:31 --> URI Class Initialized
DEBUG - 2023-08-02 13:00:31 --> No URI present. Default controller set.
INFO - 2023-08-02 13:00:31 --> Router Class Initialized
INFO - 2023-08-02 13:00:31 --> Output Class Initialized
INFO - 2023-08-02 13:00:31 --> Security Class Initialized
DEBUG - 2023-08-02 13:00:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-02 13:00:31 --> Input Class Initialized
INFO - 2023-08-02 13:00:31 --> Language Class Initialized
INFO - 2023-08-02 13:00:31 --> Loader Class Initialized
INFO - 2023-08-02 13:00:31 --> Helper loaded: url_helper
INFO - 2023-08-02 13:00:31 --> Helper loaded: file_helper
INFO - 2023-08-02 13:00:31 --> Helper loaded: html_helper
INFO - 2023-08-02 13:00:31 --> Helper loaded: text_helper
INFO - 2023-08-02 13:00:31 --> Helper loaded: form_helper
INFO - 2023-08-02 13:00:31 --> Helper loaded: lang_helper
INFO - 2023-08-02 13:00:31 --> Helper loaded: security_helper
INFO - 2023-08-02 13:00:31 --> Helper loaded: cookie_helper
INFO - 2023-08-02 13:00:31 --> Database Driver Class Initialized
INFO - 2023-08-02 13:00:31 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-02 13:00:31 --> Parser Class Initialized
INFO - 2023-08-02 13:00:31 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-02 13:00:31 --> Pagination Class Initialized
INFO - 2023-08-02 13:00:31 --> Form Validation Class Initialized
INFO - 2023-08-02 13:00:31 --> Controller Class Initialized
INFO - 2023-08-02 13:00:31 --> Model Class Initialized
DEBUG - 2023-08-02 13:00:31 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-02 13:00:31 --> Model Class Initialized
DEBUG - 2023-08-02 13:00:31 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-02 13:00:31 --> Model Class Initialized
INFO - 2023-08-02 13:00:31 --> Model Class Initialized
INFO - 2023-08-02 13:00:31 --> Model Class Initialized
INFO - 2023-08-02 13:00:31 --> Model Class Initialized
DEBUG - 2023-08-02 13:00:31 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-02 13:00:31 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-02 13:00:31 --> Model Class Initialized
INFO - 2023-08-02 13:00:31 --> Model Class Initialized
INFO - 2023-08-02 13:00:31 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-08-02 13:00:31 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-08-02 13:00:31 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-08-02 13:00:31 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-08-02 13:00:31 --> Model Class Initialized
INFO - 2023-08-02 13:00:31 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-08-02 13:00:31 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-08-02 13:00:31 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-08-02 13:00:31 --> Final output sent to browser
DEBUG - 2023-08-02 13:00:31 --> Total execution time: 0.1825
ERROR - 2023-08-02 13:00:32 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-02 13:00:32 --> Config Class Initialized
INFO - 2023-08-02 13:00:32 --> Hooks Class Initialized
DEBUG - 2023-08-02 13:00:32 --> UTF-8 Support Enabled
INFO - 2023-08-02 13:00:32 --> Utf8 Class Initialized
INFO - 2023-08-02 13:00:32 --> URI Class Initialized
DEBUG - 2023-08-02 13:00:32 --> No URI present. Default controller set.
INFO - 2023-08-02 13:00:32 --> Router Class Initialized
INFO - 2023-08-02 13:00:32 --> Output Class Initialized
INFO - 2023-08-02 13:00:32 --> Security Class Initialized
DEBUG - 2023-08-02 13:00:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-02 13:00:32 --> Input Class Initialized
INFO - 2023-08-02 13:00:32 --> Language Class Initialized
INFO - 2023-08-02 13:00:32 --> Loader Class Initialized
INFO - 2023-08-02 13:00:32 --> Helper loaded: url_helper
INFO - 2023-08-02 13:00:32 --> Helper loaded: file_helper
INFO - 2023-08-02 13:00:32 --> Helper loaded: html_helper
INFO - 2023-08-02 13:00:32 --> Helper loaded: text_helper
INFO - 2023-08-02 13:00:32 --> Helper loaded: form_helper
INFO - 2023-08-02 13:00:32 --> Helper loaded: lang_helper
INFO - 2023-08-02 13:00:32 --> Helper loaded: security_helper
INFO - 2023-08-02 13:00:32 --> Helper loaded: cookie_helper
INFO - 2023-08-02 13:00:32 --> Database Driver Class Initialized
INFO - 2023-08-02 13:00:32 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-02 13:00:32 --> Parser Class Initialized
INFO - 2023-08-02 13:00:32 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-02 13:00:32 --> Pagination Class Initialized
INFO - 2023-08-02 13:00:32 --> Form Validation Class Initialized
INFO - 2023-08-02 13:00:32 --> Controller Class Initialized
INFO - 2023-08-02 13:00:32 --> Model Class Initialized
DEBUG - 2023-08-02 13:00:32 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-02 13:00:32 --> Model Class Initialized
DEBUG - 2023-08-02 13:00:32 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-02 13:00:32 --> Model Class Initialized
INFO - 2023-08-02 13:00:32 --> Model Class Initialized
INFO - 2023-08-02 13:00:32 --> Model Class Initialized
INFO - 2023-08-02 13:00:32 --> Model Class Initialized
DEBUG - 2023-08-02 13:00:32 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-02 13:00:32 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-02 13:00:32 --> Model Class Initialized
INFO - 2023-08-02 13:00:32 --> Model Class Initialized
INFO - 2023-08-02 13:00:32 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-08-02 13:00:32 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-08-02 13:00:32 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-08-02 13:00:32 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-08-02 13:00:32 --> Model Class Initialized
INFO - 2023-08-02 13:00:32 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-08-02 13:00:32 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-08-02 13:00:32 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-08-02 13:00:32 --> Final output sent to browser
DEBUG - 2023-08-02 13:00:32 --> Total execution time: 0.1600
ERROR - 2023-08-02 13:00:50 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-02 13:00:50 --> Config Class Initialized
INFO - 2023-08-02 13:00:50 --> Hooks Class Initialized
DEBUG - 2023-08-02 13:00:50 --> UTF-8 Support Enabled
INFO - 2023-08-02 13:00:50 --> Utf8 Class Initialized
INFO - 2023-08-02 13:00:50 --> URI Class Initialized
INFO - 2023-08-02 13:00:50 --> Router Class Initialized
INFO - 2023-08-02 13:00:50 --> Output Class Initialized
INFO - 2023-08-02 13:00:50 --> Security Class Initialized
DEBUG - 2023-08-02 13:00:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-02 13:00:50 --> Input Class Initialized
INFO - 2023-08-02 13:00:50 --> Language Class Initialized
INFO - 2023-08-02 13:00:50 --> Loader Class Initialized
INFO - 2023-08-02 13:00:50 --> Helper loaded: url_helper
INFO - 2023-08-02 13:00:50 --> Helper loaded: file_helper
INFO - 2023-08-02 13:00:50 --> Helper loaded: html_helper
INFO - 2023-08-02 13:00:50 --> Helper loaded: text_helper
INFO - 2023-08-02 13:00:50 --> Helper loaded: form_helper
INFO - 2023-08-02 13:00:50 --> Helper loaded: lang_helper
INFO - 2023-08-02 13:00:50 --> Helper loaded: security_helper
INFO - 2023-08-02 13:00:50 --> Helper loaded: cookie_helper
INFO - 2023-08-02 13:00:50 --> Database Driver Class Initialized
INFO - 2023-08-02 13:00:50 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-02 13:00:50 --> Parser Class Initialized
INFO - 2023-08-02 13:00:50 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-02 13:00:50 --> Pagination Class Initialized
INFO - 2023-08-02 13:00:50 --> Form Validation Class Initialized
INFO - 2023-08-02 13:00:50 --> Controller Class Initialized
INFO - 2023-08-02 13:00:50 --> Model Class Initialized
DEBUG - 2023-08-02 13:00:50 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-02 13:00:50 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-02 13:00:50 --> Model Class Initialized
INFO - 2023-08-02 13:00:50 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/stockrequest/stockrequest.php
DEBUG - 2023-08-02 13:00:50 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-08-02 13:00:50 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-08-02 13:00:50 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-08-02 13:00:50 --> Model Class Initialized
INFO - 2023-08-02 13:00:50 --> Model Class Initialized
INFO - 2023-08-02 13:00:50 --> Model Class Initialized
INFO - 2023-08-02 13:00:50 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-08-02 13:00:50 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-08-02 13:00:50 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-08-02 13:00:50 --> Final output sent to browser
DEBUG - 2023-08-02 13:00:50 --> Total execution time: 0.1299
ERROR - 2023-08-02 13:00:51 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-02 13:00:51 --> Config Class Initialized
INFO - 2023-08-02 13:00:51 --> Hooks Class Initialized
DEBUG - 2023-08-02 13:00:51 --> UTF-8 Support Enabled
INFO - 2023-08-02 13:00:51 --> Utf8 Class Initialized
INFO - 2023-08-02 13:00:51 --> URI Class Initialized
INFO - 2023-08-02 13:00:51 --> Router Class Initialized
INFO - 2023-08-02 13:00:51 --> Output Class Initialized
INFO - 2023-08-02 13:00:51 --> Security Class Initialized
DEBUG - 2023-08-02 13:00:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-02 13:00:51 --> Input Class Initialized
INFO - 2023-08-02 13:00:51 --> Language Class Initialized
INFO - 2023-08-02 13:00:51 --> Loader Class Initialized
INFO - 2023-08-02 13:00:51 --> Helper loaded: url_helper
INFO - 2023-08-02 13:00:51 --> Helper loaded: file_helper
INFO - 2023-08-02 13:00:51 --> Helper loaded: html_helper
INFO - 2023-08-02 13:00:51 --> Helper loaded: text_helper
INFO - 2023-08-02 13:00:51 --> Helper loaded: form_helper
INFO - 2023-08-02 13:00:51 --> Helper loaded: lang_helper
INFO - 2023-08-02 13:00:51 --> Helper loaded: security_helper
INFO - 2023-08-02 13:00:51 --> Helper loaded: cookie_helper
INFO - 2023-08-02 13:00:51 --> Database Driver Class Initialized
INFO - 2023-08-02 13:00:51 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-02 13:00:51 --> Parser Class Initialized
INFO - 2023-08-02 13:00:51 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-02 13:00:51 --> Pagination Class Initialized
INFO - 2023-08-02 13:00:51 --> Form Validation Class Initialized
INFO - 2023-08-02 13:00:51 --> Controller Class Initialized
INFO - 2023-08-02 13:00:51 --> Model Class Initialized
DEBUG - 2023-08-02 13:00:51 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-02 13:00:51 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-02 13:00:51 --> Model Class Initialized
INFO - 2023-08-02 13:00:51 --> Final output sent to browser
DEBUG - 2023-08-02 13:00:51 --> Total execution time: 0.0262
ERROR - 2023-08-02 13:00:59 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-02 13:00:59 --> Config Class Initialized
INFO - 2023-08-02 13:00:59 --> Hooks Class Initialized
DEBUG - 2023-08-02 13:00:59 --> UTF-8 Support Enabled
INFO - 2023-08-02 13:00:59 --> Utf8 Class Initialized
INFO - 2023-08-02 13:00:59 --> URI Class Initialized
INFO - 2023-08-02 13:00:59 --> Router Class Initialized
INFO - 2023-08-02 13:00:59 --> Output Class Initialized
INFO - 2023-08-02 13:00:59 --> Security Class Initialized
DEBUG - 2023-08-02 13:00:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-02 13:00:59 --> Input Class Initialized
INFO - 2023-08-02 13:00:59 --> Language Class Initialized
INFO - 2023-08-02 13:00:59 --> Loader Class Initialized
INFO - 2023-08-02 13:00:59 --> Helper loaded: url_helper
INFO - 2023-08-02 13:00:59 --> Helper loaded: file_helper
INFO - 2023-08-02 13:00:59 --> Helper loaded: html_helper
INFO - 2023-08-02 13:00:59 --> Helper loaded: text_helper
INFO - 2023-08-02 13:00:59 --> Helper loaded: form_helper
INFO - 2023-08-02 13:00:59 --> Helper loaded: lang_helper
INFO - 2023-08-02 13:00:59 --> Helper loaded: security_helper
INFO - 2023-08-02 13:00:59 --> Helper loaded: cookie_helper
INFO - 2023-08-02 13:00:59 --> Database Driver Class Initialized
INFO - 2023-08-02 13:00:59 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-02 13:00:59 --> Parser Class Initialized
INFO - 2023-08-02 13:00:59 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-02 13:00:59 --> Pagination Class Initialized
INFO - 2023-08-02 13:00:59 --> Form Validation Class Initialized
INFO - 2023-08-02 13:00:59 --> Controller Class Initialized
INFO - 2023-08-02 13:00:59 --> Model Class Initialized
DEBUG - 2023-08-02 13:00:59 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-02 13:00:59 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-02 13:00:59 --> Model Class Initialized
DEBUG - 2023-08-02 13:00:59 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-02 13:00:59 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/stockrequest/stockrequest_html.php
DEBUG - 2023-08-02 13:00:59 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-08-02 13:00:59 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-08-02 13:00:59 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-08-02 13:00:59 --> Model Class Initialized
INFO - 2023-08-02 13:00:59 --> Model Class Initialized
INFO - 2023-08-02 13:00:59 --> Model Class Initialized
INFO - 2023-08-02 13:00:59 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-08-02 13:00:59 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-08-02 13:00:59 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-08-02 13:00:59 --> Final output sent to browser
DEBUG - 2023-08-02 13:00:59 --> Total execution time: 0.1230
ERROR - 2023-08-02 13:01:06 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-02 13:01:06 --> Config Class Initialized
INFO - 2023-08-02 13:01:06 --> Hooks Class Initialized
DEBUG - 2023-08-02 13:01:06 --> UTF-8 Support Enabled
INFO - 2023-08-02 13:01:06 --> Utf8 Class Initialized
INFO - 2023-08-02 13:01:06 --> URI Class Initialized
INFO - 2023-08-02 13:01:06 --> Router Class Initialized
INFO - 2023-08-02 13:01:06 --> Output Class Initialized
INFO - 2023-08-02 13:01:06 --> Security Class Initialized
DEBUG - 2023-08-02 13:01:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-02 13:01:06 --> Input Class Initialized
INFO - 2023-08-02 13:01:06 --> Language Class Initialized
INFO - 2023-08-02 13:01:06 --> Loader Class Initialized
INFO - 2023-08-02 13:01:06 --> Helper loaded: url_helper
INFO - 2023-08-02 13:01:06 --> Helper loaded: file_helper
INFO - 2023-08-02 13:01:06 --> Helper loaded: html_helper
INFO - 2023-08-02 13:01:06 --> Helper loaded: text_helper
INFO - 2023-08-02 13:01:06 --> Helper loaded: form_helper
INFO - 2023-08-02 13:01:06 --> Helper loaded: lang_helper
INFO - 2023-08-02 13:01:06 --> Helper loaded: security_helper
INFO - 2023-08-02 13:01:06 --> Helper loaded: cookie_helper
INFO - 2023-08-02 13:01:06 --> Database Driver Class Initialized
INFO - 2023-08-02 13:01:06 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-02 13:01:06 --> Parser Class Initialized
INFO - 2023-08-02 13:01:06 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-02 13:01:06 --> Pagination Class Initialized
INFO - 2023-08-02 13:01:06 --> Form Validation Class Initialized
INFO - 2023-08-02 13:01:06 --> Controller Class Initialized
INFO - 2023-08-02 13:01:06 --> Model Class Initialized
DEBUG - 2023-08-02 13:01:06 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-02 13:01:06 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-02 13:01:06 --> Model Class Initialized
INFO - 2023-08-02 13:01:06 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/stockrequest/stockrequest.php
DEBUG - 2023-08-02 13:01:06 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-08-02 13:01:06 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-08-02 13:01:06 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-08-02 13:01:06 --> Model Class Initialized
INFO - 2023-08-02 13:01:06 --> Model Class Initialized
INFO - 2023-08-02 13:01:06 --> Model Class Initialized
INFO - 2023-08-02 13:01:06 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-08-02 13:01:06 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-08-02 13:01:06 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-08-02 13:01:06 --> Final output sent to browser
DEBUG - 2023-08-02 13:01:06 --> Total execution time: 0.1398
ERROR - 2023-08-02 13:01:07 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-02 13:01:07 --> Config Class Initialized
INFO - 2023-08-02 13:01:07 --> Hooks Class Initialized
DEBUG - 2023-08-02 13:01:07 --> UTF-8 Support Enabled
INFO - 2023-08-02 13:01:07 --> Utf8 Class Initialized
INFO - 2023-08-02 13:01:07 --> URI Class Initialized
INFO - 2023-08-02 13:01:07 --> Router Class Initialized
INFO - 2023-08-02 13:01:07 --> Output Class Initialized
INFO - 2023-08-02 13:01:07 --> Security Class Initialized
DEBUG - 2023-08-02 13:01:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-02 13:01:07 --> Input Class Initialized
INFO - 2023-08-02 13:01:07 --> Language Class Initialized
INFO - 2023-08-02 13:01:07 --> Loader Class Initialized
INFO - 2023-08-02 13:01:07 --> Helper loaded: url_helper
INFO - 2023-08-02 13:01:07 --> Helper loaded: file_helper
INFO - 2023-08-02 13:01:07 --> Helper loaded: html_helper
INFO - 2023-08-02 13:01:07 --> Helper loaded: text_helper
INFO - 2023-08-02 13:01:07 --> Helper loaded: form_helper
INFO - 2023-08-02 13:01:07 --> Helper loaded: lang_helper
INFO - 2023-08-02 13:01:07 --> Helper loaded: security_helper
INFO - 2023-08-02 13:01:07 --> Helper loaded: cookie_helper
INFO - 2023-08-02 13:01:07 --> Database Driver Class Initialized
INFO - 2023-08-02 13:01:07 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-02 13:01:07 --> Parser Class Initialized
INFO - 2023-08-02 13:01:07 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-02 13:01:07 --> Pagination Class Initialized
INFO - 2023-08-02 13:01:07 --> Form Validation Class Initialized
INFO - 2023-08-02 13:01:07 --> Controller Class Initialized
INFO - 2023-08-02 13:01:07 --> Model Class Initialized
DEBUG - 2023-08-02 13:01:07 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-02 13:01:07 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-02 13:01:07 --> Model Class Initialized
INFO - 2023-08-02 13:01:07 --> Final output sent to browser
DEBUG - 2023-08-02 13:01:07 --> Total execution time: 0.0276
ERROR - 2023-08-02 13:01:10 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-02 13:01:10 --> Config Class Initialized
INFO - 2023-08-02 13:01:10 --> Hooks Class Initialized
DEBUG - 2023-08-02 13:01:10 --> UTF-8 Support Enabled
INFO - 2023-08-02 13:01:10 --> Utf8 Class Initialized
INFO - 2023-08-02 13:01:10 --> URI Class Initialized
INFO - 2023-08-02 13:01:10 --> Router Class Initialized
INFO - 2023-08-02 13:01:10 --> Output Class Initialized
INFO - 2023-08-02 13:01:10 --> Security Class Initialized
DEBUG - 2023-08-02 13:01:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-02 13:01:10 --> Input Class Initialized
INFO - 2023-08-02 13:01:10 --> Language Class Initialized
INFO - 2023-08-02 13:01:10 --> Loader Class Initialized
INFO - 2023-08-02 13:01:10 --> Helper loaded: url_helper
INFO - 2023-08-02 13:01:10 --> Helper loaded: file_helper
INFO - 2023-08-02 13:01:10 --> Helper loaded: html_helper
INFO - 2023-08-02 13:01:10 --> Helper loaded: text_helper
INFO - 2023-08-02 13:01:10 --> Helper loaded: form_helper
INFO - 2023-08-02 13:01:10 --> Helper loaded: lang_helper
INFO - 2023-08-02 13:01:10 --> Helper loaded: security_helper
INFO - 2023-08-02 13:01:10 --> Helper loaded: cookie_helper
INFO - 2023-08-02 13:01:10 --> Database Driver Class Initialized
INFO - 2023-08-02 13:01:10 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-02 13:01:10 --> Parser Class Initialized
INFO - 2023-08-02 13:01:10 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-02 13:01:10 --> Pagination Class Initialized
INFO - 2023-08-02 13:01:10 --> Form Validation Class Initialized
INFO - 2023-08-02 13:01:10 --> Controller Class Initialized
INFO - 2023-08-02 13:01:10 --> Model Class Initialized
DEBUG - 2023-08-02 13:01:10 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-02 13:01:10 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-02 13:01:10 --> Model Class Initialized
DEBUG - 2023-08-02 13:01:10 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-02 13:01:10 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/stockrequest/stockrequest_html.php
DEBUG - 2023-08-02 13:01:10 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-08-02 13:01:10 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-08-02 13:01:10 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-08-02 13:01:10 --> Model Class Initialized
INFO - 2023-08-02 13:01:10 --> Model Class Initialized
INFO - 2023-08-02 13:01:10 --> Model Class Initialized
INFO - 2023-08-02 13:01:10 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-08-02 13:01:10 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-08-02 13:01:10 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-08-02 13:01:10 --> Final output sent to browser
DEBUG - 2023-08-02 13:01:10 --> Total execution time: 0.1293
ERROR - 2023-08-02 13:01:14 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-02 13:01:14 --> Config Class Initialized
INFO - 2023-08-02 13:01:14 --> Hooks Class Initialized
DEBUG - 2023-08-02 13:01:14 --> UTF-8 Support Enabled
INFO - 2023-08-02 13:01:14 --> Utf8 Class Initialized
INFO - 2023-08-02 13:01:14 --> URI Class Initialized
INFO - 2023-08-02 13:01:14 --> Router Class Initialized
INFO - 2023-08-02 13:01:14 --> Output Class Initialized
INFO - 2023-08-02 13:01:14 --> Security Class Initialized
DEBUG - 2023-08-02 13:01:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-02 13:01:14 --> Input Class Initialized
INFO - 2023-08-02 13:01:14 --> Language Class Initialized
INFO - 2023-08-02 13:01:14 --> Loader Class Initialized
INFO - 2023-08-02 13:01:14 --> Helper loaded: url_helper
INFO - 2023-08-02 13:01:14 --> Helper loaded: file_helper
INFO - 2023-08-02 13:01:14 --> Helper loaded: html_helper
INFO - 2023-08-02 13:01:14 --> Helper loaded: text_helper
INFO - 2023-08-02 13:01:14 --> Helper loaded: form_helper
INFO - 2023-08-02 13:01:14 --> Helper loaded: lang_helper
INFO - 2023-08-02 13:01:14 --> Helper loaded: security_helper
INFO - 2023-08-02 13:01:14 --> Helper loaded: cookie_helper
INFO - 2023-08-02 13:01:14 --> Database Driver Class Initialized
INFO - 2023-08-02 13:01:14 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-02 13:01:14 --> Parser Class Initialized
INFO - 2023-08-02 13:01:14 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-02 13:01:14 --> Pagination Class Initialized
INFO - 2023-08-02 13:01:14 --> Form Validation Class Initialized
INFO - 2023-08-02 13:01:14 --> Controller Class Initialized
INFO - 2023-08-02 13:01:14 --> Model Class Initialized
DEBUG - 2023-08-02 13:01:14 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-02 13:01:14 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-02 13:01:14 --> Model Class Initialized
INFO - 2023-08-02 13:01:14 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/stockrequest/stockrequest.php
DEBUG - 2023-08-02 13:01:14 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-08-02 13:01:14 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-08-02 13:01:14 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-08-02 13:01:14 --> Model Class Initialized
INFO - 2023-08-02 13:01:14 --> Model Class Initialized
INFO - 2023-08-02 13:01:14 --> Model Class Initialized
INFO - 2023-08-02 13:01:14 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-08-02 13:01:14 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-08-02 13:01:14 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-08-02 13:01:14 --> Final output sent to browser
DEBUG - 2023-08-02 13:01:14 --> Total execution time: 0.1257
ERROR - 2023-08-02 13:01:15 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-02 13:01:15 --> Config Class Initialized
INFO - 2023-08-02 13:01:15 --> Hooks Class Initialized
DEBUG - 2023-08-02 13:01:15 --> UTF-8 Support Enabled
INFO - 2023-08-02 13:01:15 --> Utf8 Class Initialized
INFO - 2023-08-02 13:01:15 --> URI Class Initialized
INFO - 2023-08-02 13:01:15 --> Router Class Initialized
INFO - 2023-08-02 13:01:15 --> Output Class Initialized
INFO - 2023-08-02 13:01:15 --> Security Class Initialized
DEBUG - 2023-08-02 13:01:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-02 13:01:15 --> Input Class Initialized
INFO - 2023-08-02 13:01:15 --> Language Class Initialized
INFO - 2023-08-02 13:01:15 --> Loader Class Initialized
INFO - 2023-08-02 13:01:15 --> Helper loaded: url_helper
INFO - 2023-08-02 13:01:15 --> Helper loaded: file_helper
INFO - 2023-08-02 13:01:15 --> Helper loaded: html_helper
INFO - 2023-08-02 13:01:15 --> Helper loaded: text_helper
INFO - 2023-08-02 13:01:15 --> Helper loaded: form_helper
INFO - 2023-08-02 13:01:15 --> Helper loaded: lang_helper
INFO - 2023-08-02 13:01:15 --> Helper loaded: security_helper
INFO - 2023-08-02 13:01:15 --> Helper loaded: cookie_helper
INFO - 2023-08-02 13:01:15 --> Database Driver Class Initialized
INFO - 2023-08-02 13:01:15 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-02 13:01:15 --> Parser Class Initialized
INFO - 2023-08-02 13:01:15 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-02 13:01:15 --> Pagination Class Initialized
INFO - 2023-08-02 13:01:15 --> Form Validation Class Initialized
INFO - 2023-08-02 13:01:15 --> Controller Class Initialized
INFO - 2023-08-02 13:01:15 --> Model Class Initialized
DEBUG - 2023-08-02 13:01:15 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-02 13:01:15 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-02 13:01:15 --> Model Class Initialized
INFO - 2023-08-02 13:01:15 --> Final output sent to browser
DEBUG - 2023-08-02 13:01:15 --> Total execution time: 0.0251
ERROR - 2023-08-02 13:01:17 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-02 13:01:17 --> Config Class Initialized
INFO - 2023-08-02 13:01:17 --> Hooks Class Initialized
DEBUG - 2023-08-02 13:01:17 --> UTF-8 Support Enabled
INFO - 2023-08-02 13:01:17 --> Utf8 Class Initialized
INFO - 2023-08-02 13:01:17 --> URI Class Initialized
INFO - 2023-08-02 13:01:17 --> Router Class Initialized
INFO - 2023-08-02 13:01:17 --> Output Class Initialized
INFO - 2023-08-02 13:01:17 --> Security Class Initialized
DEBUG - 2023-08-02 13:01:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-02 13:01:17 --> Input Class Initialized
INFO - 2023-08-02 13:01:17 --> Language Class Initialized
INFO - 2023-08-02 13:01:17 --> Loader Class Initialized
INFO - 2023-08-02 13:01:17 --> Helper loaded: url_helper
INFO - 2023-08-02 13:01:17 --> Helper loaded: file_helper
INFO - 2023-08-02 13:01:17 --> Helper loaded: html_helper
INFO - 2023-08-02 13:01:17 --> Helper loaded: text_helper
INFO - 2023-08-02 13:01:17 --> Helper loaded: form_helper
INFO - 2023-08-02 13:01:17 --> Helper loaded: lang_helper
INFO - 2023-08-02 13:01:17 --> Helper loaded: security_helper
INFO - 2023-08-02 13:01:17 --> Helper loaded: cookie_helper
INFO - 2023-08-02 13:01:17 --> Database Driver Class Initialized
INFO - 2023-08-02 13:01:17 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-02 13:01:17 --> Parser Class Initialized
INFO - 2023-08-02 13:01:17 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-02 13:01:17 --> Pagination Class Initialized
INFO - 2023-08-02 13:01:17 --> Form Validation Class Initialized
INFO - 2023-08-02 13:01:17 --> Controller Class Initialized
INFO - 2023-08-02 13:01:17 --> Model Class Initialized
DEBUG - 2023-08-02 13:01:17 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-02 13:01:17 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-02 13:01:17 --> Model Class Initialized
DEBUG - 2023-08-02 13:01:17 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-02 13:01:17 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/stockrequest/stockrequest_html.php
DEBUG - 2023-08-02 13:01:17 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-08-02 13:01:17 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-08-02 13:01:17 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-08-02 13:01:17 --> Model Class Initialized
INFO - 2023-08-02 13:01:17 --> Model Class Initialized
INFO - 2023-08-02 13:01:17 --> Model Class Initialized
INFO - 2023-08-02 13:01:18 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-08-02 13:01:18 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-08-02 13:01:18 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-08-02 13:01:18 --> Final output sent to browser
DEBUG - 2023-08-02 13:01:18 --> Total execution time: 0.1328
ERROR - 2023-08-02 13:01:39 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-02 13:01:39 --> Config Class Initialized
INFO - 2023-08-02 13:01:39 --> Hooks Class Initialized
DEBUG - 2023-08-02 13:01:39 --> UTF-8 Support Enabled
INFO - 2023-08-02 13:01:39 --> Utf8 Class Initialized
INFO - 2023-08-02 13:01:39 --> URI Class Initialized
DEBUG - 2023-08-02 13:01:39 --> No URI present. Default controller set.
INFO - 2023-08-02 13:01:39 --> Router Class Initialized
INFO - 2023-08-02 13:01:39 --> Output Class Initialized
INFO - 2023-08-02 13:01:39 --> Security Class Initialized
DEBUG - 2023-08-02 13:01:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-02 13:01:39 --> Input Class Initialized
INFO - 2023-08-02 13:01:39 --> Language Class Initialized
INFO - 2023-08-02 13:01:39 --> Loader Class Initialized
INFO - 2023-08-02 13:01:39 --> Helper loaded: url_helper
INFO - 2023-08-02 13:01:39 --> Helper loaded: file_helper
INFO - 2023-08-02 13:01:39 --> Helper loaded: html_helper
INFO - 2023-08-02 13:01:39 --> Helper loaded: text_helper
INFO - 2023-08-02 13:01:39 --> Helper loaded: form_helper
INFO - 2023-08-02 13:01:39 --> Helper loaded: lang_helper
INFO - 2023-08-02 13:01:39 --> Helper loaded: security_helper
INFO - 2023-08-02 13:01:39 --> Helper loaded: cookie_helper
INFO - 2023-08-02 13:01:39 --> Database Driver Class Initialized
INFO - 2023-08-02 13:01:39 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-02 13:01:39 --> Parser Class Initialized
INFO - 2023-08-02 13:01:39 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-02 13:01:39 --> Pagination Class Initialized
INFO - 2023-08-02 13:01:39 --> Form Validation Class Initialized
INFO - 2023-08-02 13:01:39 --> Controller Class Initialized
INFO - 2023-08-02 13:01:39 --> Model Class Initialized
DEBUG - 2023-08-02 13:01:39 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-02 13:01:39 --> Model Class Initialized
DEBUG - 2023-08-02 13:01:39 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-02 13:01:39 --> Model Class Initialized
INFO - 2023-08-02 13:01:39 --> Model Class Initialized
INFO - 2023-08-02 13:01:39 --> Model Class Initialized
INFO - 2023-08-02 13:01:39 --> Model Class Initialized
DEBUG - 2023-08-02 13:01:39 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-02 13:01:39 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-02 13:01:39 --> Model Class Initialized
INFO - 2023-08-02 13:01:39 --> Model Class Initialized
INFO - 2023-08-02 13:01:39 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-08-02 13:01:39 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-08-02 13:01:39 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-08-02 13:01:39 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-08-02 13:01:39 --> Model Class Initialized
INFO - 2023-08-02 13:01:40 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-08-02 13:01:40 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-08-02 13:01:40 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-08-02 13:01:40 --> Final output sent to browser
DEBUG - 2023-08-02 13:01:40 --> Total execution time: 0.1840
ERROR - 2023-08-02 13:27:06 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-02 13:27:06 --> Config Class Initialized
INFO - 2023-08-02 13:27:06 --> Hooks Class Initialized
DEBUG - 2023-08-02 13:27:06 --> UTF-8 Support Enabled
INFO - 2023-08-02 13:27:06 --> Utf8 Class Initialized
INFO - 2023-08-02 13:27:06 --> URI Class Initialized
DEBUG - 2023-08-02 13:27:06 --> No URI present. Default controller set.
INFO - 2023-08-02 13:27:06 --> Router Class Initialized
INFO - 2023-08-02 13:27:06 --> Output Class Initialized
INFO - 2023-08-02 13:27:06 --> Security Class Initialized
DEBUG - 2023-08-02 13:27:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-02 13:27:06 --> Input Class Initialized
INFO - 2023-08-02 13:27:06 --> Language Class Initialized
INFO - 2023-08-02 13:27:06 --> Loader Class Initialized
INFO - 2023-08-02 13:27:06 --> Helper loaded: url_helper
INFO - 2023-08-02 13:27:06 --> Helper loaded: file_helper
INFO - 2023-08-02 13:27:06 --> Helper loaded: html_helper
INFO - 2023-08-02 13:27:06 --> Helper loaded: text_helper
INFO - 2023-08-02 13:27:06 --> Helper loaded: form_helper
INFO - 2023-08-02 13:27:06 --> Helper loaded: lang_helper
INFO - 2023-08-02 13:27:06 --> Helper loaded: security_helper
INFO - 2023-08-02 13:27:06 --> Helper loaded: cookie_helper
INFO - 2023-08-02 13:27:06 --> Database Driver Class Initialized
INFO - 2023-08-02 13:27:06 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-02 13:27:06 --> Parser Class Initialized
INFO - 2023-08-02 13:27:06 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-02 13:27:06 --> Pagination Class Initialized
INFO - 2023-08-02 13:27:06 --> Form Validation Class Initialized
INFO - 2023-08-02 13:27:06 --> Controller Class Initialized
INFO - 2023-08-02 13:27:06 --> Model Class Initialized
DEBUG - 2023-08-02 13:27:06 --> Session class already loaded. Second attempt ignored.
ERROR - 2023-08-02 14:01:37 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-02 14:01:37 --> Config Class Initialized
INFO - 2023-08-02 14:01:37 --> Hooks Class Initialized
DEBUG - 2023-08-02 14:01:37 --> UTF-8 Support Enabled
INFO - 2023-08-02 14:01:37 --> Utf8 Class Initialized
INFO - 2023-08-02 14:01:37 --> URI Class Initialized
INFO - 2023-08-02 14:01:37 --> Router Class Initialized
INFO - 2023-08-02 14:01:37 --> Output Class Initialized
INFO - 2023-08-02 14:01:37 --> Security Class Initialized
DEBUG - 2023-08-02 14:01:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-02 14:01:37 --> Input Class Initialized
INFO - 2023-08-02 14:01:37 --> Language Class Initialized
INFO - 2023-08-02 14:01:37 --> Loader Class Initialized
INFO - 2023-08-02 14:01:37 --> Helper loaded: url_helper
INFO - 2023-08-02 14:01:37 --> Helper loaded: file_helper
INFO - 2023-08-02 14:01:37 --> Helper loaded: html_helper
INFO - 2023-08-02 14:01:37 --> Helper loaded: text_helper
INFO - 2023-08-02 14:01:37 --> Helper loaded: form_helper
INFO - 2023-08-02 14:01:37 --> Helper loaded: lang_helper
INFO - 2023-08-02 14:01:37 --> Helper loaded: security_helper
INFO - 2023-08-02 14:01:37 --> Helper loaded: cookie_helper
INFO - 2023-08-02 14:01:37 --> Database Driver Class Initialized
INFO - 2023-08-02 14:01:37 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-02 14:01:37 --> Parser Class Initialized
INFO - 2023-08-02 14:01:37 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-02 14:01:37 --> Pagination Class Initialized
INFO - 2023-08-02 14:01:37 --> Form Validation Class Initialized
INFO - 2023-08-02 14:01:37 --> Controller Class Initialized
INFO - 2023-08-02 14:01:37 --> Model Class Initialized
DEBUG - 2023-08-02 14:01:37 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-02 14:01:37 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-02 14:01:37 --> Model Class Initialized
INFO - 2023-08-02 14:01:37 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/stockrequest/stockrequest.php
DEBUG - 2023-08-02 14:01:37 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-08-02 14:01:37 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-08-02 14:01:37 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-08-02 14:01:37 --> Model Class Initialized
INFO - 2023-08-02 14:01:37 --> Model Class Initialized
INFO - 2023-08-02 14:01:37 --> Model Class Initialized
INFO - 2023-08-02 14:01:37 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-08-02 14:01:37 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-08-02 14:01:37 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-08-02 14:01:37 --> Final output sent to browser
DEBUG - 2023-08-02 14:01:37 --> Total execution time: 0.1360
ERROR - 2023-08-02 14:01:38 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-02 14:01:38 --> Config Class Initialized
INFO - 2023-08-02 14:01:38 --> Hooks Class Initialized
DEBUG - 2023-08-02 14:01:38 --> UTF-8 Support Enabled
INFO - 2023-08-02 14:01:38 --> Utf8 Class Initialized
INFO - 2023-08-02 14:01:38 --> URI Class Initialized
INFO - 2023-08-02 14:01:38 --> Router Class Initialized
INFO - 2023-08-02 14:01:38 --> Output Class Initialized
INFO - 2023-08-02 14:01:38 --> Security Class Initialized
DEBUG - 2023-08-02 14:01:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-02 14:01:38 --> Input Class Initialized
INFO - 2023-08-02 14:01:38 --> Language Class Initialized
INFO - 2023-08-02 14:01:38 --> Loader Class Initialized
INFO - 2023-08-02 14:01:38 --> Helper loaded: url_helper
INFO - 2023-08-02 14:01:38 --> Helper loaded: file_helper
INFO - 2023-08-02 14:01:38 --> Helper loaded: html_helper
INFO - 2023-08-02 14:01:38 --> Helper loaded: text_helper
INFO - 2023-08-02 14:01:38 --> Helper loaded: form_helper
INFO - 2023-08-02 14:01:38 --> Helper loaded: lang_helper
INFO - 2023-08-02 14:01:38 --> Helper loaded: security_helper
INFO - 2023-08-02 14:01:38 --> Helper loaded: cookie_helper
INFO - 2023-08-02 14:01:38 --> Database Driver Class Initialized
INFO - 2023-08-02 14:01:38 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-02 14:01:38 --> Parser Class Initialized
INFO - 2023-08-02 14:01:38 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-02 14:01:38 --> Pagination Class Initialized
INFO - 2023-08-02 14:01:38 --> Form Validation Class Initialized
INFO - 2023-08-02 14:01:38 --> Controller Class Initialized
INFO - 2023-08-02 14:01:38 --> Model Class Initialized
DEBUG - 2023-08-02 14:01:38 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-02 14:01:38 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-02 14:01:38 --> Model Class Initialized
INFO - 2023-08-02 14:01:38 --> Final output sent to browser
DEBUG - 2023-08-02 14:01:38 --> Total execution time: 0.0259
ERROR - 2023-08-02 14:04:03 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-02 14:04:03 --> Config Class Initialized
INFO - 2023-08-02 14:04:03 --> Hooks Class Initialized
DEBUG - 2023-08-02 14:04:03 --> UTF-8 Support Enabled
INFO - 2023-08-02 14:04:03 --> Utf8 Class Initialized
INFO - 2023-08-02 14:04:03 --> URI Class Initialized
INFO - 2023-08-02 14:04:03 --> Router Class Initialized
INFO - 2023-08-02 14:04:03 --> Output Class Initialized
INFO - 2023-08-02 14:04:03 --> Security Class Initialized
DEBUG - 2023-08-02 14:04:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-02 14:04:03 --> Input Class Initialized
INFO - 2023-08-02 14:04:03 --> Language Class Initialized
INFO - 2023-08-02 14:04:03 --> Loader Class Initialized
INFO - 2023-08-02 14:04:03 --> Helper loaded: url_helper
INFO - 2023-08-02 14:04:03 --> Helper loaded: file_helper
INFO - 2023-08-02 14:04:03 --> Helper loaded: html_helper
INFO - 2023-08-02 14:04:03 --> Helper loaded: text_helper
INFO - 2023-08-02 14:04:03 --> Helper loaded: form_helper
INFO - 2023-08-02 14:04:03 --> Helper loaded: lang_helper
INFO - 2023-08-02 14:04:03 --> Helper loaded: security_helper
INFO - 2023-08-02 14:04:03 --> Helper loaded: cookie_helper
INFO - 2023-08-02 14:04:03 --> Database Driver Class Initialized
INFO - 2023-08-02 14:04:03 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-02 14:04:03 --> Parser Class Initialized
INFO - 2023-08-02 14:04:03 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-02 14:04:03 --> Pagination Class Initialized
INFO - 2023-08-02 14:04:03 --> Form Validation Class Initialized
INFO - 2023-08-02 14:04:03 --> Controller Class Initialized
INFO - 2023-08-02 14:04:03 --> Model Class Initialized
DEBUG - 2023-08-02 14:04:03 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-02 14:04:03 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-02 14:04:03 --> Model Class Initialized
INFO - 2023-08-02 14:04:03 --> Final output sent to browser
DEBUG - 2023-08-02 14:04:03 --> Total execution time: 0.0845
ERROR - 2023-08-02 14:04:09 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-02 14:04:09 --> Config Class Initialized
INFO - 2023-08-02 14:04:09 --> Hooks Class Initialized
DEBUG - 2023-08-02 14:04:09 --> UTF-8 Support Enabled
INFO - 2023-08-02 14:04:09 --> Utf8 Class Initialized
INFO - 2023-08-02 14:04:09 --> URI Class Initialized
DEBUG - 2023-08-02 14:04:09 --> No URI present. Default controller set.
INFO - 2023-08-02 14:04:09 --> Router Class Initialized
INFO - 2023-08-02 14:04:09 --> Output Class Initialized
INFO - 2023-08-02 14:04:09 --> Security Class Initialized
DEBUG - 2023-08-02 14:04:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-02 14:04:09 --> Input Class Initialized
INFO - 2023-08-02 14:04:09 --> Language Class Initialized
INFO - 2023-08-02 14:04:09 --> Loader Class Initialized
INFO - 2023-08-02 14:04:09 --> Helper loaded: url_helper
INFO - 2023-08-02 14:04:09 --> Helper loaded: file_helper
INFO - 2023-08-02 14:04:09 --> Helper loaded: html_helper
INFO - 2023-08-02 14:04:09 --> Helper loaded: text_helper
INFO - 2023-08-02 14:04:09 --> Helper loaded: form_helper
INFO - 2023-08-02 14:04:09 --> Helper loaded: lang_helper
INFO - 2023-08-02 14:04:09 --> Helper loaded: security_helper
INFO - 2023-08-02 14:04:09 --> Helper loaded: cookie_helper
INFO - 2023-08-02 14:04:09 --> Database Driver Class Initialized
INFO - 2023-08-02 14:04:09 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-02 14:04:09 --> Parser Class Initialized
INFO - 2023-08-02 14:04:09 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-02 14:04:09 --> Pagination Class Initialized
INFO - 2023-08-02 14:04:09 --> Form Validation Class Initialized
INFO - 2023-08-02 14:04:09 --> Controller Class Initialized
INFO - 2023-08-02 14:04:09 --> Model Class Initialized
DEBUG - 2023-08-02 14:04:09 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-02 14:04:09 --> Model Class Initialized
DEBUG - 2023-08-02 14:04:09 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-02 14:04:09 --> Model Class Initialized
INFO - 2023-08-02 14:04:09 --> Model Class Initialized
INFO - 2023-08-02 14:04:09 --> Model Class Initialized
INFO - 2023-08-02 14:04:09 --> Model Class Initialized
DEBUG - 2023-08-02 14:04:09 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-02 14:04:09 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-02 14:04:09 --> Model Class Initialized
INFO - 2023-08-02 14:04:09 --> Model Class Initialized
INFO - 2023-08-02 14:04:09 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-08-02 14:04:09 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-08-02 14:04:09 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-08-02 14:04:09 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-08-02 14:04:09 --> Model Class Initialized
INFO - 2023-08-02 14:04:10 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-08-02 14:04:10 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-08-02 14:04:10 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-08-02 14:04:10 --> Final output sent to browser
DEBUG - 2023-08-02 14:04:10 --> Total execution time: 0.1732
ERROR - 2023-08-02 14:04:39 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-02 14:04:39 --> Config Class Initialized
INFO - 2023-08-02 14:04:39 --> Hooks Class Initialized
DEBUG - 2023-08-02 14:04:39 --> UTF-8 Support Enabled
INFO - 2023-08-02 14:04:39 --> Utf8 Class Initialized
INFO - 2023-08-02 14:04:39 --> URI Class Initialized
DEBUG - 2023-08-02 14:04:39 --> No URI present. Default controller set.
INFO - 2023-08-02 14:04:39 --> Router Class Initialized
INFO - 2023-08-02 14:04:39 --> Output Class Initialized
INFO - 2023-08-02 14:04:39 --> Security Class Initialized
DEBUG - 2023-08-02 14:04:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-02 14:04:39 --> Input Class Initialized
INFO - 2023-08-02 14:04:39 --> Language Class Initialized
INFO - 2023-08-02 14:04:39 --> Loader Class Initialized
INFO - 2023-08-02 14:04:39 --> Helper loaded: url_helper
INFO - 2023-08-02 14:04:39 --> Helper loaded: file_helper
INFO - 2023-08-02 14:04:39 --> Helper loaded: html_helper
INFO - 2023-08-02 14:04:39 --> Helper loaded: text_helper
INFO - 2023-08-02 14:04:39 --> Helper loaded: form_helper
INFO - 2023-08-02 14:04:39 --> Helper loaded: lang_helper
INFO - 2023-08-02 14:04:39 --> Helper loaded: security_helper
INFO - 2023-08-02 14:04:39 --> Helper loaded: cookie_helper
INFO - 2023-08-02 14:04:39 --> Database Driver Class Initialized
INFO - 2023-08-02 14:04:39 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-02 14:04:39 --> Parser Class Initialized
INFO - 2023-08-02 14:04:39 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-02 14:04:39 --> Pagination Class Initialized
INFO - 2023-08-02 14:04:39 --> Form Validation Class Initialized
INFO - 2023-08-02 14:04:39 --> Controller Class Initialized
INFO - 2023-08-02 14:04:39 --> Model Class Initialized
DEBUG - 2023-08-02 14:04:39 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-02 14:04:39 --> Model Class Initialized
DEBUG - 2023-08-02 14:04:39 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-02 14:04:39 --> Model Class Initialized
INFO - 2023-08-02 14:04:39 --> Model Class Initialized
INFO - 2023-08-02 14:04:39 --> Model Class Initialized
INFO - 2023-08-02 14:04:39 --> Model Class Initialized
DEBUG - 2023-08-02 14:04:39 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-02 14:04:39 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-02 14:04:39 --> Model Class Initialized
INFO - 2023-08-02 14:04:39 --> Model Class Initialized
INFO - 2023-08-02 14:04:39 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-08-02 14:04:39 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-08-02 14:04:39 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-08-02 14:04:39 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-08-02 14:04:39 --> Model Class Initialized
INFO - 2023-08-02 14:04:39 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-08-02 14:04:39 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-08-02 14:04:39 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-08-02 14:04:39 --> Final output sent to browser
DEBUG - 2023-08-02 14:04:39 --> Total execution time: 0.1877
ERROR - 2023-08-02 14:04:54 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-02 14:04:54 --> Config Class Initialized
INFO - 2023-08-02 14:04:54 --> Hooks Class Initialized
DEBUG - 2023-08-02 14:04:54 --> UTF-8 Support Enabled
INFO - 2023-08-02 14:04:54 --> Utf8 Class Initialized
INFO - 2023-08-02 14:04:54 --> URI Class Initialized
INFO - 2023-08-02 14:04:54 --> Router Class Initialized
INFO - 2023-08-02 14:04:54 --> Output Class Initialized
INFO - 2023-08-02 14:04:54 --> Security Class Initialized
DEBUG - 2023-08-02 14:04:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-02 14:04:54 --> Input Class Initialized
INFO - 2023-08-02 14:04:54 --> Language Class Initialized
INFO - 2023-08-02 14:04:54 --> Loader Class Initialized
INFO - 2023-08-02 14:04:54 --> Helper loaded: url_helper
INFO - 2023-08-02 14:04:54 --> Helper loaded: file_helper
INFO - 2023-08-02 14:04:54 --> Helper loaded: html_helper
INFO - 2023-08-02 14:04:54 --> Helper loaded: text_helper
INFO - 2023-08-02 14:04:54 --> Helper loaded: form_helper
INFO - 2023-08-02 14:04:54 --> Helper loaded: lang_helper
INFO - 2023-08-02 14:04:54 --> Helper loaded: security_helper
INFO - 2023-08-02 14:04:54 --> Helper loaded: cookie_helper
INFO - 2023-08-02 14:04:54 --> Database Driver Class Initialized
INFO - 2023-08-02 14:04:54 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-02 14:04:54 --> Parser Class Initialized
INFO - 2023-08-02 14:04:54 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-02 14:04:54 --> Pagination Class Initialized
INFO - 2023-08-02 14:04:54 --> Form Validation Class Initialized
INFO - 2023-08-02 14:04:54 --> Controller Class Initialized
INFO - 2023-08-02 14:04:54 --> Model Class Initialized
DEBUG - 2023-08-02 14:04:54 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-02 14:04:54 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-02 14:04:54 --> Model Class Initialized
DEBUG - 2023-08-02 14:04:54 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-02 14:04:54 --> Model Class Initialized
INFO - 2023-08-02 14:04:54 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/invoice/invoice.php
DEBUG - 2023-08-02 14:04:54 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-08-02 14:04:54 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-08-02 14:04:54 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-08-02 14:04:54 --> Model Class Initialized
INFO - 2023-08-02 14:04:54 --> Model Class Initialized
INFO - 2023-08-02 14:04:54 --> Model Class Initialized
INFO - 2023-08-02 14:04:54 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-08-02 14:04:54 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-08-02 14:04:54 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-08-02 14:04:54 --> Final output sent to browser
DEBUG - 2023-08-02 14:04:54 --> Total execution time: 0.1442
ERROR - 2023-08-02 14:04:55 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-02 14:04:55 --> Config Class Initialized
INFO - 2023-08-02 14:04:55 --> Hooks Class Initialized
DEBUG - 2023-08-02 14:04:55 --> UTF-8 Support Enabled
INFO - 2023-08-02 14:04:55 --> Utf8 Class Initialized
INFO - 2023-08-02 14:04:55 --> URI Class Initialized
INFO - 2023-08-02 14:04:55 --> Router Class Initialized
INFO - 2023-08-02 14:04:55 --> Output Class Initialized
INFO - 2023-08-02 14:04:55 --> Security Class Initialized
DEBUG - 2023-08-02 14:04:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-02 14:04:55 --> Input Class Initialized
INFO - 2023-08-02 14:04:55 --> Language Class Initialized
INFO - 2023-08-02 14:04:55 --> Loader Class Initialized
INFO - 2023-08-02 14:04:55 --> Helper loaded: url_helper
INFO - 2023-08-02 14:04:55 --> Helper loaded: file_helper
INFO - 2023-08-02 14:04:55 --> Helper loaded: html_helper
INFO - 2023-08-02 14:04:55 --> Helper loaded: text_helper
INFO - 2023-08-02 14:04:55 --> Helper loaded: form_helper
INFO - 2023-08-02 14:04:55 --> Helper loaded: lang_helper
INFO - 2023-08-02 14:04:55 --> Helper loaded: security_helper
INFO - 2023-08-02 14:04:55 --> Helper loaded: cookie_helper
INFO - 2023-08-02 14:04:55 --> Database Driver Class Initialized
INFO - 2023-08-02 14:04:55 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-02 14:04:55 --> Parser Class Initialized
INFO - 2023-08-02 14:04:55 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-02 14:04:55 --> Pagination Class Initialized
INFO - 2023-08-02 14:04:55 --> Form Validation Class Initialized
INFO - 2023-08-02 14:04:55 --> Controller Class Initialized
INFO - 2023-08-02 14:04:55 --> Model Class Initialized
DEBUG - 2023-08-02 14:04:55 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-02 14:04:55 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-02 14:04:55 --> Model Class Initialized
DEBUG - 2023-08-02 14:04:55 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-02 14:04:55 --> Model Class Initialized
INFO - 2023-08-02 14:04:55 --> Final output sent to browser
DEBUG - 2023-08-02 14:04:55 --> Total execution time: 0.0578
ERROR - 2023-08-02 14:04:58 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-02 14:04:58 --> Config Class Initialized
INFO - 2023-08-02 14:04:58 --> Hooks Class Initialized
DEBUG - 2023-08-02 14:04:58 --> UTF-8 Support Enabled
INFO - 2023-08-02 14:04:58 --> Utf8 Class Initialized
INFO - 2023-08-02 14:04:58 --> URI Class Initialized
INFO - 2023-08-02 14:04:58 --> Router Class Initialized
INFO - 2023-08-02 14:04:58 --> Output Class Initialized
INFO - 2023-08-02 14:04:58 --> Security Class Initialized
DEBUG - 2023-08-02 14:04:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-02 14:04:58 --> Input Class Initialized
INFO - 2023-08-02 14:04:58 --> Language Class Initialized
INFO - 2023-08-02 14:04:58 --> Loader Class Initialized
INFO - 2023-08-02 14:04:58 --> Helper loaded: url_helper
INFO - 2023-08-02 14:04:58 --> Helper loaded: file_helper
INFO - 2023-08-02 14:04:58 --> Helper loaded: html_helper
INFO - 2023-08-02 14:04:58 --> Helper loaded: text_helper
INFO - 2023-08-02 14:04:58 --> Helper loaded: form_helper
INFO - 2023-08-02 14:04:58 --> Helper loaded: lang_helper
INFO - 2023-08-02 14:04:58 --> Helper loaded: security_helper
INFO - 2023-08-02 14:04:58 --> Helper loaded: cookie_helper
INFO - 2023-08-02 14:04:58 --> Database Driver Class Initialized
INFO - 2023-08-02 14:04:58 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-02 14:04:58 --> Parser Class Initialized
INFO - 2023-08-02 14:04:58 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-02 14:04:58 --> Pagination Class Initialized
INFO - 2023-08-02 14:04:58 --> Form Validation Class Initialized
INFO - 2023-08-02 14:04:58 --> Controller Class Initialized
INFO - 2023-08-02 14:04:58 --> Model Class Initialized
DEBUG - 2023-08-02 14:04:58 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-02 14:04:58 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-02 14:04:58 --> Model Class Initialized
DEBUG - 2023-08-02 14:04:58 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-02 14:04:58 --> Model Class Initialized
INFO - 2023-08-02 14:04:58 --> Final output sent to browser
DEBUG - 2023-08-02 14:04:58 --> Total execution time: 0.0735
ERROR - 2023-08-02 14:06:33 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-02 14:06:33 --> Config Class Initialized
INFO - 2023-08-02 14:06:33 --> Hooks Class Initialized
DEBUG - 2023-08-02 14:06:33 --> UTF-8 Support Enabled
INFO - 2023-08-02 14:06:33 --> Utf8 Class Initialized
INFO - 2023-08-02 14:06:33 --> URI Class Initialized
INFO - 2023-08-02 14:06:33 --> Router Class Initialized
INFO - 2023-08-02 14:06:33 --> Output Class Initialized
INFO - 2023-08-02 14:06:33 --> Security Class Initialized
DEBUG - 2023-08-02 14:06:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-02 14:06:33 --> Input Class Initialized
INFO - 2023-08-02 14:06:33 --> Language Class Initialized
INFO - 2023-08-02 14:06:33 --> Loader Class Initialized
INFO - 2023-08-02 14:06:33 --> Helper loaded: url_helper
INFO - 2023-08-02 14:06:33 --> Helper loaded: file_helper
INFO - 2023-08-02 14:06:33 --> Helper loaded: html_helper
INFO - 2023-08-02 14:06:33 --> Helper loaded: text_helper
INFO - 2023-08-02 14:06:33 --> Helper loaded: form_helper
INFO - 2023-08-02 14:06:33 --> Helper loaded: lang_helper
INFO - 2023-08-02 14:06:33 --> Helper loaded: security_helper
INFO - 2023-08-02 14:06:33 --> Helper loaded: cookie_helper
INFO - 2023-08-02 14:06:33 --> Database Driver Class Initialized
INFO - 2023-08-02 14:06:33 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-02 14:06:33 --> Parser Class Initialized
INFO - 2023-08-02 14:06:33 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-02 14:06:33 --> Pagination Class Initialized
INFO - 2023-08-02 14:06:33 --> Form Validation Class Initialized
INFO - 2023-08-02 14:06:33 --> Controller Class Initialized
INFO - 2023-08-02 14:06:33 --> Model Class Initialized
DEBUG - 2023-08-02 14:06:33 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-02 14:06:33 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-02 14:06:33 --> Model Class Initialized
DEBUG - 2023-08-02 14:06:33 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-02 14:06:33 --> Model Class Initialized
INFO - 2023-08-02 14:06:33 --> Final output sent to browser
DEBUG - 2023-08-02 14:06:33 --> Total execution time: 0.0651
ERROR - 2023-08-02 14:07:09 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-02 14:07:09 --> Config Class Initialized
INFO - 2023-08-02 14:07:09 --> Hooks Class Initialized
DEBUG - 2023-08-02 14:07:09 --> UTF-8 Support Enabled
INFO - 2023-08-02 14:07:09 --> Utf8 Class Initialized
INFO - 2023-08-02 14:07:09 --> URI Class Initialized
INFO - 2023-08-02 14:07:09 --> Router Class Initialized
INFO - 2023-08-02 14:07:09 --> Output Class Initialized
INFO - 2023-08-02 14:07:09 --> Security Class Initialized
DEBUG - 2023-08-02 14:07:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-02 14:07:09 --> Input Class Initialized
INFO - 2023-08-02 14:07:09 --> Language Class Initialized
INFO - 2023-08-02 14:07:09 --> Loader Class Initialized
INFO - 2023-08-02 14:07:09 --> Helper loaded: url_helper
INFO - 2023-08-02 14:07:09 --> Helper loaded: file_helper
INFO - 2023-08-02 14:07:09 --> Helper loaded: html_helper
INFO - 2023-08-02 14:07:09 --> Helper loaded: text_helper
INFO - 2023-08-02 14:07:09 --> Helper loaded: form_helper
INFO - 2023-08-02 14:07:09 --> Helper loaded: lang_helper
INFO - 2023-08-02 14:07:09 --> Helper loaded: security_helper
INFO - 2023-08-02 14:07:09 --> Helper loaded: cookie_helper
INFO - 2023-08-02 14:07:09 --> Database Driver Class Initialized
INFO - 2023-08-02 14:07:09 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-02 14:07:09 --> Parser Class Initialized
INFO - 2023-08-02 14:07:09 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-02 14:07:09 --> Pagination Class Initialized
INFO - 2023-08-02 14:07:09 --> Form Validation Class Initialized
INFO - 2023-08-02 14:07:09 --> Controller Class Initialized
INFO - 2023-08-02 14:07:09 --> Model Class Initialized
DEBUG - 2023-08-02 14:07:09 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-02 14:07:09 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-02 14:07:09 --> Model Class Initialized
DEBUG - 2023-08-02 14:07:09 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-02 14:07:09 --> Model Class Initialized
INFO - 2023-08-02 14:07:09 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/invoice/invoice_html.php
DEBUG - 2023-08-02 14:07:09 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-08-02 14:07:09 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-08-02 14:07:09 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-08-02 14:07:09 --> Model Class Initialized
INFO - 2023-08-02 14:07:09 --> Model Class Initialized
INFO - 2023-08-02 14:07:09 --> Model Class Initialized
INFO - 2023-08-02 14:07:09 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-08-02 14:07:09 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-08-02 14:07:09 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-08-02 14:07:09 --> Final output sent to browser
DEBUG - 2023-08-02 14:07:09 --> Total execution time: 0.1500
ERROR - 2023-08-02 14:09:01 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-02 14:09:01 --> Config Class Initialized
INFO - 2023-08-02 14:09:01 --> Hooks Class Initialized
DEBUG - 2023-08-02 14:09:01 --> UTF-8 Support Enabled
INFO - 2023-08-02 14:09:01 --> Utf8 Class Initialized
INFO - 2023-08-02 14:09:01 --> URI Class Initialized
DEBUG - 2023-08-02 14:09:01 --> No URI present. Default controller set.
INFO - 2023-08-02 14:09:01 --> Router Class Initialized
INFO - 2023-08-02 14:09:01 --> Output Class Initialized
INFO - 2023-08-02 14:09:01 --> Security Class Initialized
DEBUG - 2023-08-02 14:09:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-02 14:09:01 --> Input Class Initialized
INFO - 2023-08-02 14:09:01 --> Language Class Initialized
INFO - 2023-08-02 14:09:01 --> Loader Class Initialized
INFO - 2023-08-02 14:09:01 --> Helper loaded: url_helper
INFO - 2023-08-02 14:09:01 --> Helper loaded: file_helper
INFO - 2023-08-02 14:09:01 --> Helper loaded: html_helper
INFO - 2023-08-02 14:09:01 --> Helper loaded: text_helper
INFO - 2023-08-02 14:09:01 --> Helper loaded: form_helper
INFO - 2023-08-02 14:09:01 --> Helper loaded: lang_helper
INFO - 2023-08-02 14:09:01 --> Helper loaded: security_helper
INFO - 2023-08-02 14:09:01 --> Helper loaded: cookie_helper
INFO - 2023-08-02 14:09:01 --> Database Driver Class Initialized
INFO - 2023-08-02 14:09:01 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-02 14:09:01 --> Parser Class Initialized
INFO - 2023-08-02 14:09:01 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-02 14:09:01 --> Pagination Class Initialized
INFO - 2023-08-02 14:09:01 --> Form Validation Class Initialized
INFO - 2023-08-02 14:09:01 --> Controller Class Initialized
INFO - 2023-08-02 14:09:01 --> Model Class Initialized
DEBUG - 2023-08-02 14:09:01 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-02 14:09:01 --> Model Class Initialized
DEBUG - 2023-08-02 14:09:01 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-02 14:09:01 --> Model Class Initialized
INFO - 2023-08-02 14:09:01 --> Model Class Initialized
INFO - 2023-08-02 14:09:01 --> Model Class Initialized
INFO - 2023-08-02 14:09:01 --> Model Class Initialized
DEBUG - 2023-08-02 14:09:01 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-02 14:09:01 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-02 14:09:01 --> Model Class Initialized
INFO - 2023-08-02 14:09:01 --> Model Class Initialized
INFO - 2023-08-02 14:09:01 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-08-02 14:09:01 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-08-02 14:09:01 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-08-02 14:09:01 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-08-02 14:09:01 --> Model Class Initialized
INFO - 2023-08-02 14:09:01 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-08-02 14:09:01 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-08-02 14:09:01 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-08-02 14:09:01 --> Final output sent to browser
DEBUG - 2023-08-02 14:09:01 --> Total execution time: 0.2250
ERROR - 2023-08-02 14:09:51 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-02 14:09:51 --> Config Class Initialized
INFO - 2023-08-02 14:09:51 --> Hooks Class Initialized
DEBUG - 2023-08-02 14:09:51 --> UTF-8 Support Enabled
INFO - 2023-08-02 14:09:51 --> Utf8 Class Initialized
INFO - 2023-08-02 14:09:51 --> URI Class Initialized
DEBUG - 2023-08-02 14:09:51 --> No URI present. Default controller set.
INFO - 2023-08-02 14:09:51 --> Router Class Initialized
INFO - 2023-08-02 14:09:51 --> Output Class Initialized
INFO - 2023-08-02 14:09:51 --> Security Class Initialized
DEBUG - 2023-08-02 14:09:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-02 14:09:51 --> Input Class Initialized
INFO - 2023-08-02 14:09:51 --> Language Class Initialized
INFO - 2023-08-02 14:09:51 --> Loader Class Initialized
INFO - 2023-08-02 14:09:51 --> Helper loaded: url_helper
INFO - 2023-08-02 14:09:51 --> Helper loaded: file_helper
INFO - 2023-08-02 14:09:51 --> Helper loaded: html_helper
INFO - 2023-08-02 14:09:51 --> Helper loaded: text_helper
INFO - 2023-08-02 14:09:51 --> Helper loaded: form_helper
INFO - 2023-08-02 14:09:51 --> Helper loaded: lang_helper
INFO - 2023-08-02 14:09:51 --> Helper loaded: security_helper
INFO - 2023-08-02 14:09:51 --> Helper loaded: cookie_helper
INFO - 2023-08-02 14:09:51 --> Database Driver Class Initialized
INFO - 2023-08-02 14:09:51 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-02 14:09:51 --> Parser Class Initialized
INFO - 2023-08-02 14:09:51 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-02 14:09:51 --> Pagination Class Initialized
INFO - 2023-08-02 14:09:51 --> Form Validation Class Initialized
INFO - 2023-08-02 14:09:51 --> Controller Class Initialized
INFO - 2023-08-02 14:09:51 --> Model Class Initialized
DEBUG - 2023-08-02 14:09:51 --> Session class already loaded. Second attempt ignored.
ERROR - 2023-08-02 14:09:52 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-02 14:09:52 --> Config Class Initialized
INFO - 2023-08-02 14:09:52 --> Hooks Class Initialized
DEBUG - 2023-08-02 14:09:52 --> UTF-8 Support Enabled
INFO - 2023-08-02 14:09:52 --> Utf8 Class Initialized
INFO - 2023-08-02 14:09:52 --> URI Class Initialized
INFO - 2023-08-02 14:09:52 --> Router Class Initialized
INFO - 2023-08-02 14:09:52 --> Output Class Initialized
INFO - 2023-08-02 14:09:52 --> Security Class Initialized
DEBUG - 2023-08-02 14:09:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-02 14:09:52 --> Input Class Initialized
INFO - 2023-08-02 14:09:52 --> Language Class Initialized
INFO - 2023-08-02 14:09:52 --> Loader Class Initialized
INFO - 2023-08-02 14:09:52 --> Helper loaded: url_helper
INFO - 2023-08-02 14:09:52 --> Helper loaded: file_helper
INFO - 2023-08-02 14:09:52 --> Helper loaded: html_helper
INFO - 2023-08-02 14:09:52 --> Helper loaded: text_helper
INFO - 2023-08-02 14:09:52 --> Helper loaded: form_helper
INFO - 2023-08-02 14:09:52 --> Helper loaded: lang_helper
INFO - 2023-08-02 14:09:52 --> Helper loaded: security_helper
INFO - 2023-08-02 14:09:52 --> Helper loaded: cookie_helper
INFO - 2023-08-02 14:09:52 --> Database Driver Class Initialized
INFO - 2023-08-02 14:09:52 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-02 14:09:52 --> Parser Class Initialized
INFO - 2023-08-02 14:09:52 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-02 14:09:52 --> Pagination Class Initialized
INFO - 2023-08-02 14:09:52 --> Form Validation Class Initialized
INFO - 2023-08-02 14:09:52 --> Controller Class Initialized
INFO - 2023-08-02 14:09:52 --> Model Class Initialized
DEBUG - 2023-08-02 14:09:52 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-02 14:09:52 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2023-08-02 14:09:52 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-08-02 14:09:52 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-08-02 14:09:52 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-08-02 14:09:52 --> Model Class Initialized
INFO - 2023-08-02 14:09:52 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-08-02 14:09:52 --> Final output sent to browser
DEBUG - 2023-08-02 14:09:52 --> Total execution time: 0.0300
ERROR - 2023-08-02 14:10:00 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-02 14:10:00 --> Config Class Initialized
INFO - 2023-08-02 14:10:00 --> Hooks Class Initialized
DEBUG - 2023-08-02 14:10:00 --> UTF-8 Support Enabled
INFO - 2023-08-02 14:10:00 --> Utf8 Class Initialized
INFO - 2023-08-02 14:10:00 --> URI Class Initialized
INFO - 2023-08-02 14:10:00 --> Router Class Initialized
INFO - 2023-08-02 14:10:00 --> Output Class Initialized
INFO - 2023-08-02 14:10:00 --> Security Class Initialized
DEBUG - 2023-08-02 14:10:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-02 14:10:00 --> Input Class Initialized
INFO - 2023-08-02 14:10:00 --> Language Class Initialized
INFO - 2023-08-02 14:10:00 --> Loader Class Initialized
INFO - 2023-08-02 14:10:00 --> Helper loaded: url_helper
INFO - 2023-08-02 14:10:00 --> Helper loaded: file_helper
INFO - 2023-08-02 14:10:00 --> Helper loaded: html_helper
INFO - 2023-08-02 14:10:00 --> Helper loaded: text_helper
INFO - 2023-08-02 14:10:00 --> Helper loaded: form_helper
INFO - 2023-08-02 14:10:00 --> Helper loaded: lang_helper
INFO - 2023-08-02 14:10:00 --> Helper loaded: security_helper
INFO - 2023-08-02 14:10:00 --> Helper loaded: cookie_helper
INFO - 2023-08-02 14:10:00 --> Database Driver Class Initialized
INFO - 2023-08-02 14:10:00 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-02 14:10:00 --> Parser Class Initialized
INFO - 2023-08-02 14:10:00 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-02 14:10:00 --> Pagination Class Initialized
INFO - 2023-08-02 14:10:00 --> Form Validation Class Initialized
INFO - 2023-08-02 14:10:00 --> Controller Class Initialized
INFO - 2023-08-02 14:10:00 --> Model Class Initialized
DEBUG - 2023-08-02 14:10:00 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-02 14:10:00 --> Model Class Initialized
INFO - 2023-08-02 14:10:00 --> Final output sent to browser
DEBUG - 2023-08-02 14:10:00 --> Total execution time: 0.0202
ERROR - 2023-08-02 14:10:00 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-02 14:10:00 --> Config Class Initialized
INFO - 2023-08-02 14:10:00 --> Hooks Class Initialized
DEBUG - 2023-08-02 14:10:00 --> UTF-8 Support Enabled
INFO - 2023-08-02 14:10:00 --> Utf8 Class Initialized
INFO - 2023-08-02 14:10:00 --> URI Class Initialized
DEBUG - 2023-08-02 14:10:00 --> No URI present. Default controller set.
INFO - 2023-08-02 14:10:00 --> Router Class Initialized
INFO - 2023-08-02 14:10:00 --> Output Class Initialized
INFO - 2023-08-02 14:10:00 --> Security Class Initialized
DEBUG - 2023-08-02 14:10:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-02 14:10:00 --> Input Class Initialized
INFO - 2023-08-02 14:10:00 --> Language Class Initialized
INFO - 2023-08-02 14:10:00 --> Loader Class Initialized
INFO - 2023-08-02 14:10:00 --> Helper loaded: url_helper
INFO - 2023-08-02 14:10:00 --> Helper loaded: file_helper
INFO - 2023-08-02 14:10:00 --> Helper loaded: html_helper
INFO - 2023-08-02 14:10:00 --> Helper loaded: text_helper
INFO - 2023-08-02 14:10:00 --> Helper loaded: form_helper
INFO - 2023-08-02 14:10:00 --> Helper loaded: lang_helper
INFO - 2023-08-02 14:10:00 --> Helper loaded: security_helper
INFO - 2023-08-02 14:10:00 --> Helper loaded: cookie_helper
INFO - 2023-08-02 14:10:00 --> Database Driver Class Initialized
INFO - 2023-08-02 14:10:00 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-02 14:10:00 --> Parser Class Initialized
INFO - 2023-08-02 14:10:00 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-02 14:10:00 --> Pagination Class Initialized
INFO - 2023-08-02 14:10:00 --> Form Validation Class Initialized
INFO - 2023-08-02 14:10:00 --> Controller Class Initialized
INFO - 2023-08-02 14:10:00 --> Model Class Initialized
DEBUG - 2023-08-02 14:10:00 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-02 14:10:00 --> Model Class Initialized
DEBUG - 2023-08-02 14:10:00 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-02 14:10:00 --> Model Class Initialized
INFO - 2023-08-02 14:10:00 --> Model Class Initialized
INFO - 2023-08-02 14:10:00 --> Model Class Initialized
INFO - 2023-08-02 14:10:00 --> Model Class Initialized
DEBUG - 2023-08-02 14:10:00 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-02 14:10:00 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-02 14:10:00 --> Model Class Initialized
INFO - 2023-08-02 14:10:00 --> Model Class Initialized
INFO - 2023-08-02 14:10:00 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-08-02 14:10:00 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-08-02 14:10:00 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-08-02 14:10:00 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-08-02 14:10:00 --> Model Class Initialized
INFO - 2023-08-02 14:10:00 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-08-02 14:10:00 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-08-02 14:10:00 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-08-02 14:10:00 --> Final output sent to browser
DEBUG - 2023-08-02 14:10:00 --> Total execution time: 0.0879
ERROR - 2023-08-02 14:10:38 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-02 14:10:38 --> Config Class Initialized
INFO - 2023-08-02 14:10:38 --> Hooks Class Initialized
DEBUG - 2023-08-02 14:10:38 --> UTF-8 Support Enabled
INFO - 2023-08-02 14:10:38 --> Utf8 Class Initialized
INFO - 2023-08-02 14:10:38 --> URI Class Initialized
DEBUG - 2023-08-02 14:10:38 --> No URI present. Default controller set.
INFO - 2023-08-02 14:10:38 --> Router Class Initialized
INFO - 2023-08-02 14:10:38 --> Output Class Initialized
INFO - 2023-08-02 14:10:38 --> Security Class Initialized
DEBUG - 2023-08-02 14:10:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-02 14:10:38 --> Input Class Initialized
INFO - 2023-08-02 14:10:38 --> Language Class Initialized
INFO - 2023-08-02 14:10:38 --> Loader Class Initialized
INFO - 2023-08-02 14:10:38 --> Helper loaded: url_helper
INFO - 2023-08-02 14:10:38 --> Helper loaded: file_helper
INFO - 2023-08-02 14:10:38 --> Helper loaded: html_helper
INFO - 2023-08-02 14:10:38 --> Helper loaded: text_helper
INFO - 2023-08-02 14:10:38 --> Helper loaded: form_helper
INFO - 2023-08-02 14:10:38 --> Helper loaded: lang_helper
INFO - 2023-08-02 14:10:38 --> Helper loaded: security_helper
INFO - 2023-08-02 14:10:38 --> Helper loaded: cookie_helper
INFO - 2023-08-02 14:10:38 --> Database Driver Class Initialized
INFO - 2023-08-02 14:10:38 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-02 14:10:38 --> Parser Class Initialized
INFO - 2023-08-02 14:10:38 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-02 14:10:38 --> Pagination Class Initialized
INFO - 2023-08-02 14:10:38 --> Form Validation Class Initialized
INFO - 2023-08-02 14:10:38 --> Controller Class Initialized
INFO - 2023-08-02 14:10:38 --> Model Class Initialized
DEBUG - 2023-08-02 14:10:38 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-02 14:10:38 --> Model Class Initialized
DEBUG - 2023-08-02 14:10:38 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-02 14:10:38 --> Model Class Initialized
INFO - 2023-08-02 14:10:38 --> Model Class Initialized
INFO - 2023-08-02 14:10:38 --> Model Class Initialized
INFO - 2023-08-02 14:10:38 --> Model Class Initialized
DEBUG - 2023-08-02 14:10:38 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-02 14:10:38 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-02 14:10:38 --> Model Class Initialized
INFO - 2023-08-02 14:10:38 --> Model Class Initialized
INFO - 2023-08-02 14:10:39 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-08-02 14:10:39 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-08-02 14:10:39 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-08-02 14:10:39 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-08-02 14:10:39 --> Model Class Initialized
INFO - 2023-08-02 14:10:39 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-08-02 14:10:39 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-08-02 14:10:39 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-08-02 14:10:39 --> Final output sent to browser
DEBUG - 2023-08-02 14:10:39 --> Total execution time: 0.1773
ERROR - 2023-08-02 14:10:39 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-02 14:10:39 --> Config Class Initialized
INFO - 2023-08-02 14:10:39 --> Hooks Class Initialized
DEBUG - 2023-08-02 14:10:39 --> UTF-8 Support Enabled
INFO - 2023-08-02 14:10:39 --> Utf8 Class Initialized
INFO - 2023-08-02 14:10:39 --> URI Class Initialized
DEBUG - 2023-08-02 14:10:39 --> No URI present. Default controller set.
INFO - 2023-08-02 14:10:39 --> Router Class Initialized
INFO - 2023-08-02 14:10:39 --> Output Class Initialized
INFO - 2023-08-02 14:10:39 --> Security Class Initialized
DEBUG - 2023-08-02 14:10:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-02 14:10:39 --> Input Class Initialized
INFO - 2023-08-02 14:10:39 --> Language Class Initialized
INFO - 2023-08-02 14:10:39 --> Loader Class Initialized
INFO - 2023-08-02 14:10:39 --> Helper loaded: url_helper
INFO - 2023-08-02 14:10:39 --> Helper loaded: file_helper
INFO - 2023-08-02 14:10:39 --> Helper loaded: html_helper
INFO - 2023-08-02 14:10:39 --> Helper loaded: text_helper
INFO - 2023-08-02 14:10:39 --> Helper loaded: form_helper
INFO - 2023-08-02 14:10:39 --> Helper loaded: lang_helper
INFO - 2023-08-02 14:10:39 --> Helper loaded: security_helper
INFO - 2023-08-02 14:10:39 --> Helper loaded: cookie_helper
INFO - 2023-08-02 14:10:39 --> Database Driver Class Initialized
INFO - 2023-08-02 14:10:39 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-02 14:10:39 --> Parser Class Initialized
INFO - 2023-08-02 14:10:39 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-02 14:10:39 --> Pagination Class Initialized
INFO - 2023-08-02 14:10:39 --> Form Validation Class Initialized
INFO - 2023-08-02 14:10:39 --> Controller Class Initialized
INFO - 2023-08-02 14:10:39 --> Model Class Initialized
DEBUG - 2023-08-02 14:10:39 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-02 14:10:39 --> Model Class Initialized
DEBUG - 2023-08-02 14:10:39 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-02 14:10:39 --> Model Class Initialized
INFO - 2023-08-02 14:10:39 --> Model Class Initialized
INFO - 2023-08-02 14:10:39 --> Model Class Initialized
INFO - 2023-08-02 14:10:39 --> Model Class Initialized
DEBUG - 2023-08-02 14:10:39 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-02 14:10:39 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-02 14:10:39 --> Model Class Initialized
INFO - 2023-08-02 14:10:39 --> Model Class Initialized
INFO - 2023-08-02 14:10:39 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-08-02 14:10:39 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-08-02 14:10:39 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-08-02 14:10:39 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-08-02 14:10:39 --> Model Class Initialized
INFO - 2023-08-02 14:10:39 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-08-02 14:10:39 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-08-02 14:10:39 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-08-02 14:10:39 --> Final output sent to browser
DEBUG - 2023-08-02 14:10:39 --> Total execution time: 0.1736
ERROR - 2023-08-02 14:10:43 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-02 14:10:43 --> Config Class Initialized
INFO - 2023-08-02 14:10:43 --> Hooks Class Initialized
DEBUG - 2023-08-02 14:10:43 --> UTF-8 Support Enabled
INFO - 2023-08-02 14:10:43 --> Utf8 Class Initialized
INFO - 2023-08-02 14:10:43 --> URI Class Initialized
INFO - 2023-08-02 14:10:43 --> Router Class Initialized
INFO - 2023-08-02 14:10:43 --> Output Class Initialized
INFO - 2023-08-02 14:10:43 --> Security Class Initialized
DEBUG - 2023-08-02 14:10:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-02 14:10:43 --> Input Class Initialized
INFO - 2023-08-02 14:10:43 --> Language Class Initialized
INFO - 2023-08-02 14:10:43 --> Loader Class Initialized
INFO - 2023-08-02 14:10:43 --> Helper loaded: url_helper
INFO - 2023-08-02 14:10:43 --> Helper loaded: file_helper
INFO - 2023-08-02 14:10:43 --> Helper loaded: html_helper
INFO - 2023-08-02 14:10:43 --> Helper loaded: text_helper
INFO - 2023-08-02 14:10:43 --> Helper loaded: form_helper
INFO - 2023-08-02 14:10:43 --> Helper loaded: lang_helper
INFO - 2023-08-02 14:10:43 --> Helper loaded: security_helper
INFO - 2023-08-02 14:10:43 --> Helper loaded: cookie_helper
INFO - 2023-08-02 14:10:43 --> Database Driver Class Initialized
INFO - 2023-08-02 14:10:43 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-02 14:10:43 --> Parser Class Initialized
INFO - 2023-08-02 14:10:43 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-02 14:10:43 --> Pagination Class Initialized
INFO - 2023-08-02 14:10:43 --> Form Validation Class Initialized
INFO - 2023-08-02 14:10:43 --> Controller Class Initialized
INFO - 2023-08-02 14:10:43 --> Model Class Initialized
DEBUG - 2023-08-02 14:10:43 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-02 14:10:43 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-02 14:10:43 --> Model Class Initialized
DEBUG - 2023-08-02 14:10:43 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-02 14:10:43 --> Model Class Initialized
INFO - 2023-08-02 14:10:43 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice.php
DEBUG - 2023-08-02 14:10:43 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-08-02 14:10:43 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-08-02 14:10:43 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-08-02 14:10:43 --> Model Class Initialized
INFO - 2023-08-02 14:10:43 --> Model Class Initialized
INFO - 2023-08-02 14:10:43 --> Model Class Initialized
INFO - 2023-08-02 14:10:43 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-08-02 14:10:43 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-08-02 14:10:43 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-08-02 14:10:43 --> Final output sent to browser
DEBUG - 2023-08-02 14:10:43 --> Total execution time: 0.1429
ERROR - 2023-08-02 14:10:43 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-02 14:10:43 --> Config Class Initialized
INFO - 2023-08-02 14:10:43 --> Hooks Class Initialized
DEBUG - 2023-08-02 14:10:43 --> UTF-8 Support Enabled
INFO - 2023-08-02 14:10:43 --> Utf8 Class Initialized
INFO - 2023-08-02 14:10:43 --> URI Class Initialized
INFO - 2023-08-02 14:10:43 --> Router Class Initialized
INFO - 2023-08-02 14:10:43 --> Output Class Initialized
INFO - 2023-08-02 14:10:43 --> Security Class Initialized
DEBUG - 2023-08-02 14:10:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-02 14:10:43 --> Input Class Initialized
INFO - 2023-08-02 14:10:43 --> Language Class Initialized
INFO - 2023-08-02 14:10:43 --> Loader Class Initialized
INFO - 2023-08-02 14:10:43 --> Helper loaded: url_helper
INFO - 2023-08-02 14:10:43 --> Helper loaded: file_helper
INFO - 2023-08-02 14:10:43 --> Helper loaded: html_helper
INFO - 2023-08-02 14:10:43 --> Helper loaded: text_helper
INFO - 2023-08-02 14:10:43 --> Helper loaded: form_helper
INFO - 2023-08-02 14:10:43 --> Helper loaded: lang_helper
INFO - 2023-08-02 14:10:43 --> Helper loaded: security_helper
INFO - 2023-08-02 14:10:43 --> Helper loaded: cookie_helper
INFO - 2023-08-02 14:10:43 --> Database Driver Class Initialized
INFO - 2023-08-02 14:10:43 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-02 14:10:43 --> Parser Class Initialized
INFO - 2023-08-02 14:10:43 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-02 14:10:43 --> Pagination Class Initialized
INFO - 2023-08-02 14:10:43 --> Form Validation Class Initialized
INFO - 2023-08-02 14:10:43 --> Controller Class Initialized
INFO - 2023-08-02 14:10:43 --> Model Class Initialized
DEBUG - 2023-08-02 14:10:43 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-02 14:10:43 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-02 14:10:43 --> Model Class Initialized
DEBUG - 2023-08-02 14:10:43 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-02 14:10:43 --> Model Class Initialized
INFO - 2023-08-02 14:10:43 --> Final output sent to browser
DEBUG - 2023-08-02 14:10:43 --> Total execution time: 0.0648
ERROR - 2023-08-02 14:10:49 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-02 14:10:49 --> Config Class Initialized
INFO - 2023-08-02 14:10:49 --> Hooks Class Initialized
DEBUG - 2023-08-02 14:10:49 --> UTF-8 Support Enabled
INFO - 2023-08-02 14:10:49 --> Utf8 Class Initialized
INFO - 2023-08-02 14:10:49 --> URI Class Initialized
INFO - 2023-08-02 14:10:49 --> Router Class Initialized
INFO - 2023-08-02 14:10:49 --> Output Class Initialized
INFO - 2023-08-02 14:10:49 --> Security Class Initialized
DEBUG - 2023-08-02 14:10:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-02 14:10:49 --> Input Class Initialized
INFO - 2023-08-02 14:10:49 --> Language Class Initialized
INFO - 2023-08-02 14:10:49 --> Loader Class Initialized
INFO - 2023-08-02 14:10:49 --> Helper loaded: url_helper
INFO - 2023-08-02 14:10:49 --> Helper loaded: file_helper
INFO - 2023-08-02 14:10:49 --> Helper loaded: html_helper
INFO - 2023-08-02 14:10:49 --> Helper loaded: text_helper
INFO - 2023-08-02 14:10:49 --> Helper loaded: form_helper
INFO - 2023-08-02 14:10:49 --> Helper loaded: lang_helper
INFO - 2023-08-02 14:10:49 --> Helper loaded: security_helper
INFO - 2023-08-02 14:10:49 --> Helper loaded: cookie_helper
INFO - 2023-08-02 14:10:49 --> Database Driver Class Initialized
INFO - 2023-08-02 14:10:49 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-02 14:10:49 --> Parser Class Initialized
INFO - 2023-08-02 14:10:49 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-02 14:10:49 --> Pagination Class Initialized
INFO - 2023-08-02 14:10:49 --> Form Validation Class Initialized
INFO - 2023-08-02 14:10:49 --> Controller Class Initialized
INFO - 2023-08-02 14:10:49 --> Model Class Initialized
DEBUG - 2023-08-02 14:10:49 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-02 14:10:49 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-02 14:10:49 --> Model Class Initialized
DEBUG - 2023-08-02 14:10:49 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-02 14:10:49 --> Model Class Initialized
INFO - 2023-08-02 14:10:49 --> Final output sent to browser
DEBUG - 2023-08-02 14:10:49 --> Total execution time: 0.3670
ERROR - 2023-08-02 14:11:14 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-02 14:11:14 --> Config Class Initialized
INFO - 2023-08-02 14:11:14 --> Hooks Class Initialized
DEBUG - 2023-08-02 14:11:14 --> UTF-8 Support Enabled
INFO - 2023-08-02 14:11:14 --> Utf8 Class Initialized
INFO - 2023-08-02 14:11:14 --> URI Class Initialized
INFO - 2023-08-02 14:11:14 --> Router Class Initialized
INFO - 2023-08-02 14:11:14 --> Output Class Initialized
INFO - 2023-08-02 14:11:14 --> Security Class Initialized
DEBUG - 2023-08-02 14:11:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-02 14:11:14 --> Input Class Initialized
INFO - 2023-08-02 14:11:14 --> Language Class Initialized
INFO - 2023-08-02 14:11:14 --> Loader Class Initialized
INFO - 2023-08-02 14:11:14 --> Helper loaded: url_helper
INFO - 2023-08-02 14:11:14 --> Helper loaded: file_helper
INFO - 2023-08-02 14:11:14 --> Helper loaded: html_helper
INFO - 2023-08-02 14:11:14 --> Helper loaded: text_helper
INFO - 2023-08-02 14:11:14 --> Helper loaded: form_helper
INFO - 2023-08-02 14:11:14 --> Helper loaded: lang_helper
INFO - 2023-08-02 14:11:14 --> Helper loaded: security_helper
INFO - 2023-08-02 14:11:14 --> Helper loaded: cookie_helper
INFO - 2023-08-02 14:11:14 --> Database Driver Class Initialized
INFO - 2023-08-02 14:11:14 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-02 14:11:14 --> Parser Class Initialized
INFO - 2023-08-02 14:11:14 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-02 14:11:14 --> Pagination Class Initialized
INFO - 2023-08-02 14:11:14 --> Form Validation Class Initialized
INFO - 2023-08-02 14:11:14 --> Controller Class Initialized
INFO - 2023-08-02 14:11:14 --> Model Class Initialized
DEBUG - 2023-08-02 14:11:14 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-02 14:11:14 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-02 14:11:14 --> Model Class Initialized
DEBUG - 2023-08-02 14:11:14 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-02 14:11:14 --> Model Class Initialized
INFO - 2023-08-02 14:11:14 --> Final output sent to browser
DEBUG - 2023-08-02 14:11:14 --> Total execution time: 0.3606
ERROR - 2023-08-02 14:11:25 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-02 14:11:25 --> Config Class Initialized
INFO - 2023-08-02 14:11:25 --> Hooks Class Initialized
DEBUG - 2023-08-02 14:11:25 --> UTF-8 Support Enabled
INFO - 2023-08-02 14:11:25 --> Utf8 Class Initialized
INFO - 2023-08-02 14:11:25 --> URI Class Initialized
INFO - 2023-08-02 14:11:25 --> Router Class Initialized
INFO - 2023-08-02 14:11:25 --> Output Class Initialized
INFO - 2023-08-02 14:11:25 --> Security Class Initialized
DEBUG - 2023-08-02 14:11:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-02 14:11:25 --> Input Class Initialized
INFO - 2023-08-02 14:11:25 --> Language Class Initialized
INFO - 2023-08-02 14:11:25 --> Loader Class Initialized
INFO - 2023-08-02 14:11:25 --> Helper loaded: url_helper
INFO - 2023-08-02 14:11:25 --> Helper loaded: file_helper
INFO - 2023-08-02 14:11:25 --> Helper loaded: html_helper
INFO - 2023-08-02 14:11:25 --> Helper loaded: text_helper
INFO - 2023-08-02 14:11:25 --> Helper loaded: form_helper
INFO - 2023-08-02 14:11:25 --> Helper loaded: lang_helper
INFO - 2023-08-02 14:11:25 --> Helper loaded: security_helper
INFO - 2023-08-02 14:11:25 --> Helper loaded: cookie_helper
INFO - 2023-08-02 14:11:25 --> Database Driver Class Initialized
INFO - 2023-08-02 14:11:25 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-02 14:11:25 --> Parser Class Initialized
INFO - 2023-08-02 14:11:25 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-02 14:11:25 --> Pagination Class Initialized
INFO - 2023-08-02 14:11:25 --> Form Validation Class Initialized
INFO - 2023-08-02 14:11:25 --> Controller Class Initialized
INFO - 2023-08-02 14:11:25 --> Model Class Initialized
DEBUG - 2023-08-02 14:11:25 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-02 14:11:25 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-02 14:11:25 --> Model Class Initialized
DEBUG - 2023-08-02 14:11:25 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-02 14:11:25 --> Model Class Initialized
INFO - 2023-08-02 14:11:26 --> Final output sent to browser
DEBUG - 2023-08-02 14:11:26 --> Total execution time: 0.3679
ERROR - 2023-08-02 14:11:52 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-02 14:11:52 --> Config Class Initialized
INFO - 2023-08-02 14:11:52 --> Hooks Class Initialized
DEBUG - 2023-08-02 14:11:52 --> UTF-8 Support Enabled
INFO - 2023-08-02 14:11:52 --> Utf8 Class Initialized
INFO - 2023-08-02 14:11:52 --> URI Class Initialized
INFO - 2023-08-02 14:11:52 --> Router Class Initialized
INFO - 2023-08-02 14:11:52 --> Output Class Initialized
INFO - 2023-08-02 14:11:52 --> Security Class Initialized
DEBUG - 2023-08-02 14:11:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-02 14:11:52 --> Input Class Initialized
INFO - 2023-08-02 14:11:52 --> Language Class Initialized
INFO - 2023-08-02 14:11:52 --> Loader Class Initialized
INFO - 2023-08-02 14:11:52 --> Helper loaded: url_helper
INFO - 2023-08-02 14:11:52 --> Helper loaded: file_helper
INFO - 2023-08-02 14:11:52 --> Helper loaded: html_helper
INFO - 2023-08-02 14:11:52 --> Helper loaded: text_helper
INFO - 2023-08-02 14:11:52 --> Helper loaded: form_helper
INFO - 2023-08-02 14:11:52 --> Helper loaded: lang_helper
INFO - 2023-08-02 14:11:52 --> Helper loaded: security_helper
INFO - 2023-08-02 14:11:52 --> Helper loaded: cookie_helper
INFO - 2023-08-02 14:11:52 --> Database Driver Class Initialized
INFO - 2023-08-02 14:11:52 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-02 14:11:52 --> Parser Class Initialized
INFO - 2023-08-02 14:11:52 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-02 14:11:52 --> Pagination Class Initialized
INFO - 2023-08-02 14:11:52 --> Form Validation Class Initialized
INFO - 2023-08-02 14:11:52 --> Controller Class Initialized
INFO - 2023-08-02 14:11:52 --> Model Class Initialized
DEBUG - 2023-08-02 14:11:52 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-02 14:11:52 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-02 14:11:52 --> Model Class Initialized
DEBUG - 2023-08-02 14:11:52 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-02 14:11:52 --> Model Class Initialized
INFO - 2023-08-02 14:11:52 --> Final output sent to browser
DEBUG - 2023-08-02 14:11:52 --> Total execution time: 0.4555
ERROR - 2023-08-02 14:12:09 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-02 14:12:09 --> Config Class Initialized
INFO - 2023-08-02 14:12:09 --> Hooks Class Initialized
DEBUG - 2023-08-02 14:12:09 --> UTF-8 Support Enabled
INFO - 2023-08-02 14:12:09 --> Utf8 Class Initialized
INFO - 2023-08-02 14:12:09 --> URI Class Initialized
INFO - 2023-08-02 14:12:09 --> Router Class Initialized
INFO - 2023-08-02 14:12:09 --> Output Class Initialized
INFO - 2023-08-02 14:12:09 --> Security Class Initialized
DEBUG - 2023-08-02 14:12:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-02 14:12:09 --> Input Class Initialized
INFO - 2023-08-02 14:12:09 --> Language Class Initialized
INFO - 2023-08-02 14:12:09 --> Loader Class Initialized
INFO - 2023-08-02 14:12:09 --> Helper loaded: url_helper
INFO - 2023-08-02 14:12:09 --> Helper loaded: file_helper
INFO - 2023-08-02 14:12:09 --> Helper loaded: html_helper
INFO - 2023-08-02 14:12:09 --> Helper loaded: text_helper
INFO - 2023-08-02 14:12:09 --> Helper loaded: form_helper
INFO - 2023-08-02 14:12:09 --> Helper loaded: lang_helper
INFO - 2023-08-02 14:12:09 --> Helper loaded: security_helper
INFO - 2023-08-02 14:12:09 --> Helper loaded: cookie_helper
INFO - 2023-08-02 14:12:09 --> Database Driver Class Initialized
INFO - 2023-08-02 14:12:09 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-02 14:12:09 --> Parser Class Initialized
INFO - 2023-08-02 14:12:09 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-02 14:12:09 --> Pagination Class Initialized
INFO - 2023-08-02 14:12:09 --> Form Validation Class Initialized
INFO - 2023-08-02 14:12:09 --> Controller Class Initialized
INFO - 2023-08-02 14:12:09 --> Model Class Initialized
DEBUG - 2023-08-02 14:12:09 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-02 14:12:09 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-02 14:12:09 --> Model Class Initialized
DEBUG - 2023-08-02 14:12:09 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-02 14:12:09 --> Model Class Initialized
INFO - 2023-08-02 14:12:09 --> Final output sent to browser
DEBUG - 2023-08-02 14:12:09 --> Total execution time: 0.3632
ERROR - 2023-08-02 14:12:28 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-02 14:12:28 --> Config Class Initialized
INFO - 2023-08-02 14:12:28 --> Hooks Class Initialized
DEBUG - 2023-08-02 14:12:28 --> UTF-8 Support Enabled
INFO - 2023-08-02 14:12:28 --> Utf8 Class Initialized
INFO - 2023-08-02 14:12:28 --> URI Class Initialized
DEBUG - 2023-08-02 14:12:28 --> No URI present. Default controller set.
INFO - 2023-08-02 14:12:28 --> Router Class Initialized
INFO - 2023-08-02 14:12:28 --> Output Class Initialized
INFO - 2023-08-02 14:12:28 --> Security Class Initialized
DEBUG - 2023-08-02 14:12:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-02 14:12:28 --> Input Class Initialized
INFO - 2023-08-02 14:12:28 --> Language Class Initialized
INFO - 2023-08-02 14:12:28 --> Loader Class Initialized
INFO - 2023-08-02 14:12:28 --> Helper loaded: url_helper
INFO - 2023-08-02 14:12:28 --> Helper loaded: file_helper
INFO - 2023-08-02 14:12:28 --> Helper loaded: html_helper
INFO - 2023-08-02 14:12:28 --> Helper loaded: text_helper
INFO - 2023-08-02 14:12:28 --> Helper loaded: form_helper
INFO - 2023-08-02 14:12:28 --> Helper loaded: lang_helper
INFO - 2023-08-02 14:12:28 --> Helper loaded: security_helper
INFO - 2023-08-02 14:12:28 --> Helper loaded: cookie_helper
INFO - 2023-08-02 14:12:28 --> Database Driver Class Initialized
INFO - 2023-08-02 14:12:28 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-02 14:12:28 --> Parser Class Initialized
INFO - 2023-08-02 14:12:28 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-02 14:12:28 --> Pagination Class Initialized
INFO - 2023-08-02 14:12:28 --> Form Validation Class Initialized
INFO - 2023-08-02 14:12:28 --> Controller Class Initialized
INFO - 2023-08-02 14:12:28 --> Model Class Initialized
DEBUG - 2023-08-02 14:12:28 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-02 14:12:28 --> Model Class Initialized
DEBUG - 2023-08-02 14:12:28 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-02 14:12:28 --> Model Class Initialized
INFO - 2023-08-02 14:12:28 --> Model Class Initialized
INFO - 2023-08-02 14:12:28 --> Model Class Initialized
INFO - 2023-08-02 14:12:28 --> Model Class Initialized
DEBUG - 2023-08-02 14:12:28 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-02 14:12:28 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-02 14:12:28 --> Model Class Initialized
INFO - 2023-08-02 14:12:28 --> Model Class Initialized
INFO - 2023-08-02 14:12:28 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-08-02 14:12:28 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-08-02 14:12:28 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-08-02 14:12:28 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-08-02 14:12:28 --> Model Class Initialized
INFO - 2023-08-02 14:12:28 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-08-02 14:12:28 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-08-02 14:12:28 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-08-02 14:12:28 --> Final output sent to browser
DEBUG - 2023-08-02 14:12:28 --> Total execution time: 0.1779
ERROR - 2023-08-02 14:12:32 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-02 14:12:32 --> Config Class Initialized
INFO - 2023-08-02 14:12:32 --> Hooks Class Initialized
DEBUG - 2023-08-02 14:12:32 --> UTF-8 Support Enabled
INFO - 2023-08-02 14:12:32 --> Utf8 Class Initialized
INFO - 2023-08-02 14:12:32 --> URI Class Initialized
INFO - 2023-08-02 14:12:32 --> Router Class Initialized
INFO - 2023-08-02 14:12:32 --> Output Class Initialized
INFO - 2023-08-02 14:12:32 --> Security Class Initialized
DEBUG - 2023-08-02 14:12:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-02 14:12:32 --> Input Class Initialized
INFO - 2023-08-02 14:12:32 --> Language Class Initialized
INFO - 2023-08-02 14:12:32 --> Loader Class Initialized
INFO - 2023-08-02 14:12:32 --> Helper loaded: url_helper
INFO - 2023-08-02 14:12:32 --> Helper loaded: file_helper
INFO - 2023-08-02 14:12:32 --> Helper loaded: html_helper
INFO - 2023-08-02 14:12:32 --> Helper loaded: text_helper
INFO - 2023-08-02 14:12:32 --> Helper loaded: form_helper
INFO - 2023-08-02 14:12:32 --> Helper loaded: lang_helper
INFO - 2023-08-02 14:12:32 --> Helper loaded: security_helper
INFO - 2023-08-02 14:12:32 --> Helper loaded: cookie_helper
INFO - 2023-08-02 14:12:32 --> Database Driver Class Initialized
INFO - 2023-08-02 14:12:32 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-02 14:12:32 --> Parser Class Initialized
INFO - 2023-08-02 14:12:32 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-02 14:12:32 --> Pagination Class Initialized
INFO - 2023-08-02 14:12:32 --> Form Validation Class Initialized
INFO - 2023-08-02 14:12:32 --> Controller Class Initialized
INFO - 2023-08-02 14:12:32 --> Model Class Initialized
DEBUG - 2023-08-02 14:12:32 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-02 14:12:32 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-02 14:12:32 --> Model Class Initialized
DEBUG - 2023-08-02 14:12:32 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-02 14:12:32 --> Model Class Initialized
INFO - 2023-08-02 14:12:32 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice.php
DEBUG - 2023-08-02 14:12:32 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-08-02 14:12:32 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-08-02 14:12:32 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-08-02 14:12:32 --> Model Class Initialized
INFO - 2023-08-02 14:12:32 --> Model Class Initialized
INFO - 2023-08-02 14:12:32 --> Model Class Initialized
INFO - 2023-08-02 14:12:33 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-08-02 14:12:33 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-08-02 14:12:33 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-08-02 14:12:33 --> Final output sent to browser
DEBUG - 2023-08-02 14:12:33 --> Total execution time: 0.1312
ERROR - 2023-08-02 14:12:33 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-02 14:12:33 --> Config Class Initialized
INFO - 2023-08-02 14:12:33 --> Hooks Class Initialized
DEBUG - 2023-08-02 14:12:33 --> UTF-8 Support Enabled
INFO - 2023-08-02 14:12:33 --> Utf8 Class Initialized
INFO - 2023-08-02 14:12:33 --> URI Class Initialized
INFO - 2023-08-02 14:12:33 --> Router Class Initialized
INFO - 2023-08-02 14:12:33 --> Output Class Initialized
INFO - 2023-08-02 14:12:33 --> Security Class Initialized
DEBUG - 2023-08-02 14:12:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-02 14:12:33 --> Input Class Initialized
INFO - 2023-08-02 14:12:33 --> Language Class Initialized
INFO - 2023-08-02 14:12:33 --> Loader Class Initialized
INFO - 2023-08-02 14:12:33 --> Helper loaded: url_helper
INFO - 2023-08-02 14:12:33 --> Helper loaded: file_helper
INFO - 2023-08-02 14:12:33 --> Helper loaded: html_helper
INFO - 2023-08-02 14:12:33 --> Helper loaded: text_helper
INFO - 2023-08-02 14:12:33 --> Helper loaded: form_helper
INFO - 2023-08-02 14:12:33 --> Helper loaded: lang_helper
INFO - 2023-08-02 14:12:33 --> Helper loaded: security_helper
INFO - 2023-08-02 14:12:33 --> Helper loaded: cookie_helper
INFO - 2023-08-02 14:12:33 --> Database Driver Class Initialized
INFO - 2023-08-02 14:12:33 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-02 14:12:33 --> Parser Class Initialized
INFO - 2023-08-02 14:12:33 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-02 14:12:33 --> Pagination Class Initialized
INFO - 2023-08-02 14:12:33 --> Form Validation Class Initialized
INFO - 2023-08-02 14:12:33 --> Controller Class Initialized
INFO - 2023-08-02 14:12:33 --> Model Class Initialized
DEBUG - 2023-08-02 14:12:33 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-02 14:12:33 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-02 14:12:33 --> Model Class Initialized
DEBUG - 2023-08-02 14:12:33 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-02 14:12:33 --> Model Class Initialized
INFO - 2023-08-02 14:12:33 --> Final output sent to browser
DEBUG - 2023-08-02 14:12:33 --> Total execution time: 0.0513
ERROR - 2023-08-02 14:12:41 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-02 14:12:41 --> Config Class Initialized
INFO - 2023-08-02 14:12:41 --> Hooks Class Initialized
DEBUG - 2023-08-02 14:12:41 --> UTF-8 Support Enabled
INFO - 2023-08-02 14:12:41 --> Utf8 Class Initialized
INFO - 2023-08-02 14:12:41 --> URI Class Initialized
INFO - 2023-08-02 14:12:41 --> Router Class Initialized
INFO - 2023-08-02 14:12:41 --> Output Class Initialized
INFO - 2023-08-02 14:12:41 --> Security Class Initialized
DEBUG - 2023-08-02 14:12:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-02 14:12:41 --> Input Class Initialized
INFO - 2023-08-02 14:12:41 --> Language Class Initialized
INFO - 2023-08-02 14:12:41 --> Loader Class Initialized
INFO - 2023-08-02 14:12:41 --> Helper loaded: url_helper
INFO - 2023-08-02 14:12:41 --> Helper loaded: file_helper
INFO - 2023-08-02 14:12:41 --> Helper loaded: html_helper
INFO - 2023-08-02 14:12:41 --> Helper loaded: text_helper
INFO - 2023-08-02 14:12:41 --> Helper loaded: form_helper
INFO - 2023-08-02 14:12:41 --> Helper loaded: lang_helper
INFO - 2023-08-02 14:12:41 --> Helper loaded: security_helper
INFO - 2023-08-02 14:12:41 --> Helper loaded: cookie_helper
INFO - 2023-08-02 14:12:41 --> Database Driver Class Initialized
INFO - 2023-08-02 14:12:41 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-02 14:12:41 --> Parser Class Initialized
INFO - 2023-08-02 14:12:41 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-02 14:12:41 --> Pagination Class Initialized
INFO - 2023-08-02 14:12:41 --> Form Validation Class Initialized
INFO - 2023-08-02 14:12:41 --> Controller Class Initialized
INFO - 2023-08-02 14:12:41 --> Model Class Initialized
DEBUG - 2023-08-02 14:12:41 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-02 14:12:41 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-02 14:12:41 --> Model Class Initialized
DEBUG - 2023-08-02 14:12:41 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-02 14:12:41 --> Model Class Initialized
INFO - 2023-08-02 14:12:41 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice.php
DEBUG - 2023-08-02 14:12:41 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-08-02 14:12:41 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-08-02 14:12:41 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-08-02 14:12:41 --> Model Class Initialized
INFO - 2023-08-02 14:12:41 --> Model Class Initialized
INFO - 2023-08-02 14:12:41 --> Model Class Initialized
INFO - 2023-08-02 14:12:42 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-08-02 14:12:42 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-08-02 14:12:42 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-08-02 14:12:42 --> Final output sent to browser
DEBUG - 2023-08-02 14:12:42 --> Total execution time: 0.1435
ERROR - 2023-08-02 14:12:42 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-02 14:12:42 --> Config Class Initialized
INFO - 2023-08-02 14:12:42 --> Hooks Class Initialized
DEBUG - 2023-08-02 14:12:42 --> UTF-8 Support Enabled
INFO - 2023-08-02 14:12:42 --> Utf8 Class Initialized
INFO - 2023-08-02 14:12:42 --> URI Class Initialized
INFO - 2023-08-02 14:12:42 --> Router Class Initialized
INFO - 2023-08-02 14:12:42 --> Output Class Initialized
INFO - 2023-08-02 14:12:42 --> Security Class Initialized
DEBUG - 2023-08-02 14:12:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-02 14:12:42 --> Input Class Initialized
INFO - 2023-08-02 14:12:42 --> Language Class Initialized
INFO - 2023-08-02 14:12:42 --> Loader Class Initialized
INFO - 2023-08-02 14:12:42 --> Helper loaded: url_helper
INFO - 2023-08-02 14:12:42 --> Helper loaded: file_helper
INFO - 2023-08-02 14:12:42 --> Helper loaded: html_helper
INFO - 2023-08-02 14:12:42 --> Helper loaded: text_helper
INFO - 2023-08-02 14:12:42 --> Helper loaded: form_helper
INFO - 2023-08-02 14:12:42 --> Helper loaded: lang_helper
INFO - 2023-08-02 14:12:42 --> Helper loaded: security_helper
INFO - 2023-08-02 14:12:42 --> Helper loaded: cookie_helper
INFO - 2023-08-02 14:12:42 --> Database Driver Class Initialized
INFO - 2023-08-02 14:12:42 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-02 14:12:42 --> Parser Class Initialized
INFO - 2023-08-02 14:12:42 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-02 14:12:42 --> Pagination Class Initialized
INFO - 2023-08-02 14:12:42 --> Form Validation Class Initialized
INFO - 2023-08-02 14:12:42 --> Controller Class Initialized
INFO - 2023-08-02 14:12:42 --> Model Class Initialized
DEBUG - 2023-08-02 14:12:42 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-02 14:12:42 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-02 14:12:42 --> Model Class Initialized
DEBUG - 2023-08-02 14:12:42 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-02 14:12:42 --> Model Class Initialized
INFO - 2023-08-02 14:12:42 --> Final output sent to browser
DEBUG - 2023-08-02 14:12:42 --> Total execution time: 0.0559
ERROR - 2023-08-02 14:13:34 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-02 14:13:34 --> Config Class Initialized
INFO - 2023-08-02 14:13:34 --> Hooks Class Initialized
DEBUG - 2023-08-02 14:13:34 --> UTF-8 Support Enabled
INFO - 2023-08-02 14:13:34 --> Utf8 Class Initialized
INFO - 2023-08-02 14:13:34 --> URI Class Initialized
INFO - 2023-08-02 14:13:34 --> Router Class Initialized
INFO - 2023-08-02 14:13:34 --> Output Class Initialized
INFO - 2023-08-02 14:13:34 --> Security Class Initialized
DEBUG - 2023-08-02 14:13:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-02 14:13:34 --> Input Class Initialized
INFO - 2023-08-02 14:13:34 --> Language Class Initialized
INFO - 2023-08-02 14:13:34 --> Loader Class Initialized
INFO - 2023-08-02 14:13:34 --> Helper loaded: url_helper
INFO - 2023-08-02 14:13:34 --> Helper loaded: file_helper
INFO - 2023-08-02 14:13:34 --> Helper loaded: html_helper
INFO - 2023-08-02 14:13:34 --> Helper loaded: text_helper
INFO - 2023-08-02 14:13:34 --> Helper loaded: form_helper
INFO - 2023-08-02 14:13:34 --> Helper loaded: lang_helper
INFO - 2023-08-02 14:13:34 --> Helper loaded: security_helper
INFO - 2023-08-02 14:13:34 --> Helper loaded: cookie_helper
INFO - 2023-08-02 14:13:34 --> Database Driver Class Initialized
INFO - 2023-08-02 14:13:34 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-02 14:13:34 --> Parser Class Initialized
INFO - 2023-08-02 14:13:34 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-02 14:13:34 --> Pagination Class Initialized
INFO - 2023-08-02 14:13:34 --> Form Validation Class Initialized
INFO - 2023-08-02 14:13:34 --> Controller Class Initialized
INFO - 2023-08-02 14:13:34 --> Model Class Initialized
DEBUG - 2023-08-02 14:13:34 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-02 14:13:34 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-02 14:13:34 --> Model Class Initialized
DEBUG - 2023-08-02 14:13:34 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-02 14:13:34 --> Model Class Initialized
INFO - 2023-08-02 14:13:34 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice.php
DEBUG - 2023-08-02 14:13:34 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-08-02 14:13:34 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-08-02 14:13:34 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-08-02 14:13:34 --> Model Class Initialized
INFO - 2023-08-02 14:13:34 --> Model Class Initialized
INFO - 2023-08-02 14:13:34 --> Model Class Initialized
INFO - 2023-08-02 14:13:34 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-08-02 14:13:34 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-08-02 14:13:34 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-08-02 14:13:34 --> Final output sent to browser
DEBUG - 2023-08-02 14:13:34 --> Total execution time: 0.1399
ERROR - 2023-08-02 14:13:34 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-02 14:13:34 --> Config Class Initialized
INFO - 2023-08-02 14:13:34 --> Hooks Class Initialized
DEBUG - 2023-08-02 14:13:34 --> UTF-8 Support Enabled
INFO - 2023-08-02 14:13:34 --> Utf8 Class Initialized
INFO - 2023-08-02 14:13:34 --> URI Class Initialized
INFO - 2023-08-02 14:13:34 --> Router Class Initialized
INFO - 2023-08-02 14:13:34 --> Output Class Initialized
INFO - 2023-08-02 14:13:34 --> Security Class Initialized
DEBUG - 2023-08-02 14:13:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-02 14:13:34 --> Input Class Initialized
INFO - 2023-08-02 14:13:34 --> Language Class Initialized
INFO - 2023-08-02 14:13:34 --> Loader Class Initialized
INFO - 2023-08-02 14:13:34 --> Helper loaded: url_helper
INFO - 2023-08-02 14:13:34 --> Helper loaded: file_helper
INFO - 2023-08-02 14:13:34 --> Helper loaded: html_helper
INFO - 2023-08-02 14:13:34 --> Helper loaded: text_helper
INFO - 2023-08-02 14:13:34 --> Helper loaded: form_helper
INFO - 2023-08-02 14:13:34 --> Helper loaded: lang_helper
INFO - 2023-08-02 14:13:34 --> Helper loaded: security_helper
INFO - 2023-08-02 14:13:34 --> Helper loaded: cookie_helper
INFO - 2023-08-02 14:13:34 --> Database Driver Class Initialized
INFO - 2023-08-02 14:13:34 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-02 14:13:34 --> Parser Class Initialized
INFO - 2023-08-02 14:13:34 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-02 14:13:34 --> Pagination Class Initialized
INFO - 2023-08-02 14:13:34 --> Form Validation Class Initialized
INFO - 2023-08-02 14:13:34 --> Controller Class Initialized
INFO - 2023-08-02 14:13:34 --> Model Class Initialized
DEBUG - 2023-08-02 14:13:34 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-02 14:13:34 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-02 14:13:34 --> Model Class Initialized
DEBUG - 2023-08-02 14:13:34 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-02 14:13:34 --> Model Class Initialized
INFO - 2023-08-02 14:13:34 --> Final output sent to browser
DEBUG - 2023-08-02 14:13:34 --> Total execution time: 0.0575
ERROR - 2023-08-02 14:13:37 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-02 14:13:37 --> Config Class Initialized
INFO - 2023-08-02 14:13:37 --> Hooks Class Initialized
DEBUG - 2023-08-02 14:13:37 --> UTF-8 Support Enabled
INFO - 2023-08-02 14:13:37 --> Utf8 Class Initialized
INFO - 2023-08-02 14:13:37 --> URI Class Initialized
INFO - 2023-08-02 14:13:37 --> Router Class Initialized
INFO - 2023-08-02 14:13:37 --> Output Class Initialized
INFO - 2023-08-02 14:13:37 --> Security Class Initialized
DEBUG - 2023-08-02 14:13:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-02 14:13:37 --> Input Class Initialized
INFO - 2023-08-02 14:13:37 --> Language Class Initialized
INFO - 2023-08-02 14:13:37 --> Loader Class Initialized
INFO - 2023-08-02 14:13:37 --> Helper loaded: url_helper
INFO - 2023-08-02 14:13:37 --> Helper loaded: file_helper
INFO - 2023-08-02 14:13:37 --> Helper loaded: html_helper
INFO - 2023-08-02 14:13:37 --> Helper loaded: text_helper
INFO - 2023-08-02 14:13:37 --> Helper loaded: form_helper
INFO - 2023-08-02 14:13:37 --> Helper loaded: lang_helper
INFO - 2023-08-02 14:13:37 --> Helper loaded: security_helper
INFO - 2023-08-02 14:13:37 --> Helper loaded: cookie_helper
INFO - 2023-08-02 14:13:37 --> Database Driver Class Initialized
INFO - 2023-08-02 14:13:37 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-02 14:13:37 --> Parser Class Initialized
INFO - 2023-08-02 14:13:37 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-02 14:13:37 --> Pagination Class Initialized
INFO - 2023-08-02 14:13:37 --> Form Validation Class Initialized
INFO - 2023-08-02 14:13:37 --> Controller Class Initialized
INFO - 2023-08-02 14:13:37 --> Model Class Initialized
DEBUG - 2023-08-02 14:13:37 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-02 14:13:37 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-02 14:13:37 --> Model Class Initialized
DEBUG - 2023-08-02 14:13:37 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-02 14:13:37 --> Model Class Initialized
INFO - 2023-08-02 14:13:38 --> Final output sent to browser
DEBUG - 2023-08-02 14:13:38 --> Total execution time: 0.4127
ERROR - 2023-08-02 14:18:40 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-02 14:18:40 --> Config Class Initialized
INFO - 2023-08-02 14:18:40 --> Hooks Class Initialized
DEBUG - 2023-08-02 14:18:40 --> UTF-8 Support Enabled
INFO - 2023-08-02 14:18:40 --> Utf8 Class Initialized
INFO - 2023-08-02 14:18:40 --> URI Class Initialized
INFO - 2023-08-02 14:18:40 --> Router Class Initialized
INFO - 2023-08-02 14:18:40 --> Output Class Initialized
INFO - 2023-08-02 14:18:40 --> Security Class Initialized
DEBUG - 2023-08-02 14:18:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-02 14:18:40 --> Input Class Initialized
INFO - 2023-08-02 14:18:40 --> Language Class Initialized
INFO - 2023-08-02 14:18:40 --> Loader Class Initialized
INFO - 2023-08-02 14:18:40 --> Helper loaded: url_helper
INFO - 2023-08-02 14:18:40 --> Helper loaded: file_helper
INFO - 2023-08-02 14:18:40 --> Helper loaded: html_helper
INFO - 2023-08-02 14:18:40 --> Helper loaded: text_helper
INFO - 2023-08-02 14:18:40 --> Helper loaded: form_helper
INFO - 2023-08-02 14:18:40 --> Helper loaded: lang_helper
INFO - 2023-08-02 14:18:40 --> Helper loaded: security_helper
INFO - 2023-08-02 14:18:40 --> Helper loaded: cookie_helper
INFO - 2023-08-02 14:18:40 --> Database Driver Class Initialized
INFO - 2023-08-02 14:18:40 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-02 14:18:40 --> Parser Class Initialized
INFO - 2023-08-02 14:18:40 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-02 14:18:40 --> Pagination Class Initialized
INFO - 2023-08-02 14:18:40 --> Form Validation Class Initialized
INFO - 2023-08-02 14:18:40 --> Controller Class Initialized
INFO - 2023-08-02 14:18:40 --> Model Class Initialized
DEBUG - 2023-08-02 14:18:40 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-02 14:18:40 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-02 14:18:40 --> Model Class Initialized
DEBUG - 2023-08-02 14:18:40 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-02 14:18:40 --> Model Class Initialized
INFO - 2023-08-02 14:18:40 --> Final output sent to browser
DEBUG - 2023-08-02 14:18:40 --> Total execution time: 0.3762
ERROR - 2023-08-02 14:18:40 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-02 14:18:40 --> Config Class Initialized
INFO - 2023-08-02 14:18:40 --> Hooks Class Initialized
DEBUG - 2023-08-02 14:18:40 --> UTF-8 Support Enabled
INFO - 2023-08-02 14:18:40 --> Utf8 Class Initialized
INFO - 2023-08-02 14:18:40 --> URI Class Initialized
INFO - 2023-08-02 14:18:40 --> Router Class Initialized
INFO - 2023-08-02 14:18:40 --> Output Class Initialized
INFO - 2023-08-02 14:18:40 --> Security Class Initialized
DEBUG - 2023-08-02 14:18:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-02 14:18:40 --> Input Class Initialized
INFO - 2023-08-02 14:18:40 --> Language Class Initialized
INFO - 2023-08-02 14:18:40 --> Loader Class Initialized
INFO - 2023-08-02 14:18:40 --> Helper loaded: url_helper
INFO - 2023-08-02 14:18:40 --> Helper loaded: file_helper
INFO - 2023-08-02 14:18:40 --> Helper loaded: html_helper
INFO - 2023-08-02 14:18:40 --> Helper loaded: text_helper
INFO - 2023-08-02 14:18:40 --> Helper loaded: form_helper
INFO - 2023-08-02 14:18:40 --> Helper loaded: lang_helper
INFO - 2023-08-02 14:18:40 --> Helper loaded: security_helper
INFO - 2023-08-02 14:18:40 --> Helper loaded: cookie_helper
INFO - 2023-08-02 14:18:40 --> Database Driver Class Initialized
INFO - 2023-08-02 14:18:40 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-02 14:18:40 --> Parser Class Initialized
INFO - 2023-08-02 14:18:40 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-02 14:18:40 --> Pagination Class Initialized
INFO - 2023-08-02 14:18:40 --> Form Validation Class Initialized
INFO - 2023-08-02 14:18:40 --> Controller Class Initialized
INFO - 2023-08-02 14:18:40 --> Model Class Initialized
DEBUG - 2023-08-02 14:18:40 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-02 14:18:40 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-02 14:18:40 --> Model Class Initialized
DEBUG - 2023-08-02 14:18:40 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-02 14:18:40 --> Model Class Initialized
INFO - 2023-08-02 14:18:40 --> Final output sent to browser
DEBUG - 2023-08-02 14:18:40 --> Total execution time: 0.2379
ERROR - 2023-08-02 14:18:41 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-02 14:18:41 --> Config Class Initialized
INFO - 2023-08-02 14:18:41 --> Hooks Class Initialized
DEBUG - 2023-08-02 14:18:41 --> UTF-8 Support Enabled
INFO - 2023-08-02 14:18:41 --> Utf8 Class Initialized
INFO - 2023-08-02 14:18:41 --> URI Class Initialized
INFO - 2023-08-02 14:18:41 --> Router Class Initialized
INFO - 2023-08-02 14:18:41 --> Output Class Initialized
INFO - 2023-08-02 14:18:41 --> Security Class Initialized
DEBUG - 2023-08-02 14:18:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-02 14:18:41 --> Input Class Initialized
INFO - 2023-08-02 14:18:41 --> Language Class Initialized
INFO - 2023-08-02 14:18:41 --> Loader Class Initialized
INFO - 2023-08-02 14:18:41 --> Helper loaded: url_helper
INFO - 2023-08-02 14:18:41 --> Helper loaded: file_helper
INFO - 2023-08-02 14:18:41 --> Helper loaded: html_helper
INFO - 2023-08-02 14:18:41 --> Helper loaded: text_helper
INFO - 2023-08-02 14:18:41 --> Helper loaded: form_helper
INFO - 2023-08-02 14:18:41 --> Helper loaded: lang_helper
INFO - 2023-08-02 14:18:41 --> Helper loaded: security_helper
INFO - 2023-08-02 14:18:41 --> Helper loaded: cookie_helper
INFO - 2023-08-02 14:18:41 --> Database Driver Class Initialized
INFO - 2023-08-02 14:18:41 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-02 14:18:41 --> Parser Class Initialized
INFO - 2023-08-02 14:18:41 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-02 14:18:41 --> Pagination Class Initialized
INFO - 2023-08-02 14:18:41 --> Form Validation Class Initialized
INFO - 2023-08-02 14:18:41 --> Controller Class Initialized
INFO - 2023-08-02 14:18:41 --> Model Class Initialized
DEBUG - 2023-08-02 14:18:41 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-02 14:18:41 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-02 14:18:41 --> Model Class Initialized
DEBUG - 2023-08-02 14:18:41 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-02 14:18:41 --> Model Class Initialized
INFO - 2023-08-02 14:18:41 --> Final output sent to browser
DEBUG - 2023-08-02 14:18:41 --> Total execution time: 0.2581
ERROR - 2023-08-02 14:18:42 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-02 14:18:42 --> Config Class Initialized
INFO - 2023-08-02 14:18:42 --> Hooks Class Initialized
DEBUG - 2023-08-02 14:18:42 --> UTF-8 Support Enabled
INFO - 2023-08-02 14:18:42 --> Utf8 Class Initialized
INFO - 2023-08-02 14:18:42 --> URI Class Initialized
INFO - 2023-08-02 14:18:42 --> Router Class Initialized
INFO - 2023-08-02 14:18:42 --> Output Class Initialized
INFO - 2023-08-02 14:18:42 --> Security Class Initialized
DEBUG - 2023-08-02 14:18:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-02 14:18:42 --> Input Class Initialized
INFO - 2023-08-02 14:18:42 --> Language Class Initialized
INFO - 2023-08-02 14:18:42 --> Loader Class Initialized
INFO - 2023-08-02 14:18:42 --> Helper loaded: url_helper
INFO - 2023-08-02 14:18:42 --> Helper loaded: file_helper
INFO - 2023-08-02 14:18:42 --> Helper loaded: html_helper
INFO - 2023-08-02 14:18:42 --> Helper loaded: text_helper
INFO - 2023-08-02 14:18:42 --> Helper loaded: form_helper
INFO - 2023-08-02 14:18:42 --> Helper loaded: lang_helper
INFO - 2023-08-02 14:18:42 --> Helper loaded: security_helper
INFO - 2023-08-02 14:18:42 --> Helper loaded: cookie_helper
INFO - 2023-08-02 14:18:42 --> Database Driver Class Initialized
INFO - 2023-08-02 14:18:42 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-02 14:18:42 --> Parser Class Initialized
INFO - 2023-08-02 14:18:42 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-02 14:18:42 --> Pagination Class Initialized
INFO - 2023-08-02 14:18:42 --> Form Validation Class Initialized
INFO - 2023-08-02 14:18:42 --> Controller Class Initialized
INFO - 2023-08-02 14:18:42 --> Model Class Initialized
DEBUG - 2023-08-02 14:18:42 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-02 14:18:42 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-02 14:18:42 --> Model Class Initialized
DEBUG - 2023-08-02 14:18:42 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-02 14:18:42 --> Model Class Initialized
INFO - 2023-08-02 14:18:42 --> Final output sent to browser
DEBUG - 2023-08-02 14:18:42 --> Total execution time: 0.0410
ERROR - 2023-08-02 14:18:42 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-02 14:18:42 --> Config Class Initialized
INFO - 2023-08-02 14:18:42 --> Hooks Class Initialized
DEBUG - 2023-08-02 14:18:42 --> UTF-8 Support Enabled
INFO - 2023-08-02 14:18:42 --> Utf8 Class Initialized
INFO - 2023-08-02 14:18:42 --> URI Class Initialized
INFO - 2023-08-02 14:18:42 --> Router Class Initialized
INFO - 2023-08-02 14:18:42 --> Output Class Initialized
INFO - 2023-08-02 14:18:42 --> Security Class Initialized
DEBUG - 2023-08-02 14:18:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-02 14:18:42 --> Input Class Initialized
INFO - 2023-08-02 14:18:42 --> Language Class Initialized
INFO - 2023-08-02 14:18:42 --> Loader Class Initialized
INFO - 2023-08-02 14:18:42 --> Helper loaded: url_helper
INFO - 2023-08-02 14:18:42 --> Helper loaded: file_helper
INFO - 2023-08-02 14:18:42 --> Helper loaded: html_helper
INFO - 2023-08-02 14:18:42 --> Helper loaded: text_helper
INFO - 2023-08-02 14:18:42 --> Helper loaded: form_helper
INFO - 2023-08-02 14:18:42 --> Helper loaded: lang_helper
INFO - 2023-08-02 14:18:42 --> Helper loaded: security_helper
INFO - 2023-08-02 14:18:42 --> Helper loaded: cookie_helper
INFO - 2023-08-02 14:18:42 --> Database Driver Class Initialized
INFO - 2023-08-02 14:18:42 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-02 14:18:42 --> Parser Class Initialized
INFO - 2023-08-02 14:18:42 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-02 14:18:42 --> Pagination Class Initialized
INFO - 2023-08-02 14:18:42 --> Form Validation Class Initialized
INFO - 2023-08-02 14:18:42 --> Controller Class Initialized
INFO - 2023-08-02 14:18:42 --> Model Class Initialized
DEBUG - 2023-08-02 14:18:42 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-02 14:18:42 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-02 14:18:42 --> Model Class Initialized
DEBUG - 2023-08-02 14:18:42 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-02 14:18:42 --> Model Class Initialized
INFO - 2023-08-02 14:18:42 --> Final output sent to browser
DEBUG - 2023-08-02 14:18:42 --> Total execution time: 0.0322
ERROR - 2023-08-02 14:24:44 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-02 14:24:44 --> Config Class Initialized
INFO - 2023-08-02 14:24:44 --> Hooks Class Initialized
DEBUG - 2023-08-02 14:24:44 --> UTF-8 Support Enabled
INFO - 2023-08-02 14:24:44 --> Utf8 Class Initialized
INFO - 2023-08-02 14:24:44 --> URI Class Initialized
DEBUG - 2023-08-02 14:24:44 --> No URI present. Default controller set.
INFO - 2023-08-02 14:24:44 --> Router Class Initialized
INFO - 2023-08-02 14:24:44 --> Output Class Initialized
INFO - 2023-08-02 14:24:44 --> Security Class Initialized
DEBUG - 2023-08-02 14:24:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-02 14:24:44 --> Input Class Initialized
INFO - 2023-08-02 14:24:44 --> Language Class Initialized
INFO - 2023-08-02 14:24:44 --> Loader Class Initialized
INFO - 2023-08-02 14:24:44 --> Helper loaded: url_helper
INFO - 2023-08-02 14:24:44 --> Helper loaded: file_helper
INFO - 2023-08-02 14:24:44 --> Helper loaded: html_helper
INFO - 2023-08-02 14:24:44 --> Helper loaded: text_helper
INFO - 2023-08-02 14:24:44 --> Helper loaded: form_helper
INFO - 2023-08-02 14:24:44 --> Helper loaded: lang_helper
INFO - 2023-08-02 14:24:44 --> Helper loaded: security_helper
INFO - 2023-08-02 14:24:44 --> Helper loaded: cookie_helper
INFO - 2023-08-02 14:24:44 --> Database Driver Class Initialized
INFO - 2023-08-02 14:24:44 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-02 14:24:44 --> Parser Class Initialized
INFO - 2023-08-02 14:24:44 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-02 14:24:44 --> Pagination Class Initialized
INFO - 2023-08-02 14:24:44 --> Form Validation Class Initialized
INFO - 2023-08-02 14:24:44 --> Controller Class Initialized
INFO - 2023-08-02 14:24:44 --> Model Class Initialized
DEBUG - 2023-08-02 14:24:44 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-02 14:24:44 --> Model Class Initialized
DEBUG - 2023-08-02 14:24:44 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-02 14:24:44 --> Model Class Initialized
INFO - 2023-08-02 14:24:44 --> Model Class Initialized
INFO - 2023-08-02 14:24:44 --> Model Class Initialized
INFO - 2023-08-02 14:24:44 --> Model Class Initialized
DEBUG - 2023-08-02 14:24:44 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-02 14:24:44 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-02 14:24:44 --> Model Class Initialized
INFO - 2023-08-02 14:24:44 --> Model Class Initialized
INFO - 2023-08-02 14:24:44 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-08-02 14:24:44 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-08-02 14:24:44 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-08-02 14:24:44 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-08-02 14:24:44 --> Model Class Initialized
INFO - 2023-08-02 14:24:44 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-08-02 14:24:44 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-08-02 14:24:44 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-08-02 14:24:44 --> Final output sent to browser
DEBUG - 2023-08-02 14:24:44 --> Total execution time: 0.1887
ERROR - 2023-08-02 14:26:21 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-02 14:26:21 --> Config Class Initialized
INFO - 2023-08-02 14:26:21 --> Hooks Class Initialized
DEBUG - 2023-08-02 14:26:21 --> UTF-8 Support Enabled
INFO - 2023-08-02 14:26:21 --> Utf8 Class Initialized
INFO - 2023-08-02 14:26:21 --> URI Class Initialized
INFO - 2023-08-02 14:26:21 --> Router Class Initialized
INFO - 2023-08-02 14:26:21 --> Output Class Initialized
INFO - 2023-08-02 14:26:21 --> Security Class Initialized
DEBUG - 2023-08-02 14:26:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-02 14:26:21 --> Input Class Initialized
INFO - 2023-08-02 14:26:21 --> Language Class Initialized
INFO - 2023-08-02 14:26:21 --> Loader Class Initialized
INFO - 2023-08-02 14:26:21 --> Helper loaded: url_helper
INFO - 2023-08-02 14:26:21 --> Helper loaded: file_helper
INFO - 2023-08-02 14:26:21 --> Helper loaded: html_helper
INFO - 2023-08-02 14:26:21 --> Helper loaded: text_helper
INFO - 2023-08-02 14:26:21 --> Helper loaded: form_helper
INFO - 2023-08-02 14:26:21 --> Helper loaded: lang_helper
INFO - 2023-08-02 14:26:21 --> Helper loaded: security_helper
INFO - 2023-08-02 14:26:21 --> Helper loaded: cookie_helper
INFO - 2023-08-02 14:26:21 --> Database Driver Class Initialized
INFO - 2023-08-02 14:26:21 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-02 14:26:21 --> Parser Class Initialized
INFO - 2023-08-02 14:26:21 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-02 14:26:21 --> Pagination Class Initialized
INFO - 2023-08-02 14:26:21 --> Form Validation Class Initialized
INFO - 2023-08-02 14:26:21 --> Controller Class Initialized
DEBUG - 2023-08-02 14:26:21 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-02 14:26:21 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-02 14:26:21 --> Model Class Initialized
DEBUG - 2023-08-02 14:26:21 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-02 14:26:21 --> Model Class Initialized
DEBUG - 2023-08-02 14:26:21 --> Lcustomer class already loaded. Second attempt ignored.
INFO - 2023-08-02 14:26:21 --> Model Class Initialized
INFO - 2023-08-02 14:26:21 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/customer/customer.php
DEBUG - 2023-08-02 14:26:21 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-08-02 14:26:21 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-08-02 14:26:21 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-08-02 14:26:21 --> Model Class Initialized
INFO - 2023-08-02 14:26:21 --> Model Class Initialized
INFO - 2023-08-02 14:26:21 --> Model Class Initialized
INFO - 2023-08-02 14:26:21 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-08-02 14:26:21 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-08-02 14:26:21 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-08-02 14:26:21 --> Final output sent to browser
DEBUG - 2023-08-02 14:26:21 --> Total execution time: 0.0950
ERROR - 2023-08-02 14:26:22 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-02 14:26:22 --> Config Class Initialized
INFO - 2023-08-02 14:26:22 --> Hooks Class Initialized
DEBUG - 2023-08-02 14:26:22 --> UTF-8 Support Enabled
INFO - 2023-08-02 14:26:22 --> Utf8 Class Initialized
INFO - 2023-08-02 14:26:22 --> URI Class Initialized
INFO - 2023-08-02 14:26:22 --> Router Class Initialized
INFO - 2023-08-02 14:26:22 --> Output Class Initialized
INFO - 2023-08-02 14:26:22 --> Security Class Initialized
DEBUG - 2023-08-02 14:26:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-02 14:26:22 --> Input Class Initialized
INFO - 2023-08-02 14:26:22 --> Language Class Initialized
INFO - 2023-08-02 14:26:22 --> Loader Class Initialized
INFO - 2023-08-02 14:26:22 --> Helper loaded: url_helper
INFO - 2023-08-02 14:26:22 --> Helper loaded: file_helper
INFO - 2023-08-02 14:26:22 --> Helper loaded: html_helper
INFO - 2023-08-02 14:26:22 --> Helper loaded: text_helper
INFO - 2023-08-02 14:26:22 --> Helper loaded: form_helper
INFO - 2023-08-02 14:26:22 --> Helper loaded: lang_helper
INFO - 2023-08-02 14:26:22 --> Helper loaded: security_helper
INFO - 2023-08-02 14:26:22 --> Helper loaded: cookie_helper
INFO - 2023-08-02 14:26:22 --> Database Driver Class Initialized
INFO - 2023-08-02 14:26:22 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-02 14:26:22 --> Parser Class Initialized
INFO - 2023-08-02 14:26:22 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-02 14:26:22 --> Pagination Class Initialized
INFO - 2023-08-02 14:26:22 --> Form Validation Class Initialized
INFO - 2023-08-02 14:26:22 --> Controller Class Initialized
DEBUG - 2023-08-02 14:26:22 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-02 14:26:22 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-02 14:26:22 --> Model Class Initialized
DEBUG - 2023-08-02 14:26:22 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-02 14:26:22 --> Model Class Initialized
INFO - 2023-08-02 14:26:22 --> Final output sent to browser
DEBUG - 2023-08-02 14:26:22 --> Total execution time: 0.0232
ERROR - 2023-08-02 14:26:30 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-02 14:26:30 --> Config Class Initialized
INFO - 2023-08-02 14:26:30 --> Hooks Class Initialized
DEBUG - 2023-08-02 14:26:30 --> UTF-8 Support Enabled
INFO - 2023-08-02 14:26:30 --> Utf8 Class Initialized
INFO - 2023-08-02 14:26:30 --> URI Class Initialized
INFO - 2023-08-02 14:26:30 --> Router Class Initialized
INFO - 2023-08-02 14:26:30 --> Output Class Initialized
INFO - 2023-08-02 14:26:30 --> Security Class Initialized
DEBUG - 2023-08-02 14:26:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-02 14:26:30 --> Input Class Initialized
INFO - 2023-08-02 14:26:30 --> Language Class Initialized
INFO - 2023-08-02 14:26:30 --> Loader Class Initialized
INFO - 2023-08-02 14:26:30 --> Helper loaded: url_helper
INFO - 2023-08-02 14:26:30 --> Helper loaded: file_helper
INFO - 2023-08-02 14:26:30 --> Helper loaded: html_helper
INFO - 2023-08-02 14:26:30 --> Helper loaded: text_helper
INFO - 2023-08-02 14:26:30 --> Helper loaded: form_helper
INFO - 2023-08-02 14:26:30 --> Helper loaded: lang_helper
INFO - 2023-08-02 14:26:30 --> Helper loaded: security_helper
INFO - 2023-08-02 14:26:30 --> Helper loaded: cookie_helper
INFO - 2023-08-02 14:26:30 --> Database Driver Class Initialized
INFO - 2023-08-02 14:26:30 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-02 14:26:30 --> Parser Class Initialized
INFO - 2023-08-02 14:26:30 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-02 14:26:30 --> Pagination Class Initialized
INFO - 2023-08-02 14:26:30 --> Form Validation Class Initialized
INFO - 2023-08-02 14:26:30 --> Controller Class Initialized
DEBUG - 2023-08-02 14:26:30 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-02 14:26:30 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-02 14:26:30 --> Model Class Initialized
DEBUG - 2023-08-02 14:26:30 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-02 14:26:30 --> Model Class Initialized
INFO - 2023-08-02 14:26:30 --> Final output sent to browser
DEBUG - 2023-08-02 14:26:30 --> Total execution time: 0.0254
ERROR - 2023-08-02 14:28:32 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-02 14:28:32 --> Config Class Initialized
INFO - 2023-08-02 14:28:32 --> Hooks Class Initialized
DEBUG - 2023-08-02 14:28:32 --> UTF-8 Support Enabled
INFO - 2023-08-02 14:28:32 --> Utf8 Class Initialized
INFO - 2023-08-02 14:28:32 --> URI Class Initialized
DEBUG - 2023-08-02 14:28:32 --> No URI present. Default controller set.
INFO - 2023-08-02 14:28:32 --> Router Class Initialized
INFO - 2023-08-02 14:28:32 --> Output Class Initialized
INFO - 2023-08-02 14:28:32 --> Security Class Initialized
DEBUG - 2023-08-02 14:28:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-02 14:28:32 --> Input Class Initialized
INFO - 2023-08-02 14:28:32 --> Language Class Initialized
INFO - 2023-08-02 14:28:32 --> Loader Class Initialized
INFO - 2023-08-02 14:28:32 --> Helper loaded: url_helper
INFO - 2023-08-02 14:28:32 --> Helper loaded: file_helper
INFO - 2023-08-02 14:28:32 --> Helper loaded: html_helper
INFO - 2023-08-02 14:28:32 --> Helper loaded: text_helper
INFO - 2023-08-02 14:28:33 --> Helper loaded: form_helper
INFO - 2023-08-02 14:28:33 --> Helper loaded: lang_helper
INFO - 2023-08-02 14:28:33 --> Helper loaded: security_helper
INFO - 2023-08-02 14:28:33 --> Helper loaded: cookie_helper
INFO - 2023-08-02 14:28:33 --> Database Driver Class Initialized
INFO - 2023-08-02 14:28:33 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-02 14:28:33 --> Parser Class Initialized
INFO - 2023-08-02 14:28:33 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-02 14:28:33 --> Pagination Class Initialized
INFO - 2023-08-02 14:28:33 --> Form Validation Class Initialized
INFO - 2023-08-02 14:28:33 --> Controller Class Initialized
INFO - 2023-08-02 14:28:33 --> Model Class Initialized
DEBUG - 2023-08-02 14:28:33 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-02 14:28:33 --> Model Class Initialized
DEBUG - 2023-08-02 14:28:33 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-02 14:28:33 --> Model Class Initialized
INFO - 2023-08-02 14:28:33 --> Model Class Initialized
INFO - 2023-08-02 14:28:33 --> Model Class Initialized
INFO - 2023-08-02 14:28:33 --> Model Class Initialized
DEBUG - 2023-08-02 14:28:33 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-02 14:28:33 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-02 14:28:33 --> Model Class Initialized
INFO - 2023-08-02 14:28:33 --> Model Class Initialized
INFO - 2023-08-02 14:28:33 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-08-02 14:28:33 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-08-02 14:28:33 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-08-02 14:28:33 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-08-02 14:28:33 --> Model Class Initialized
INFO - 2023-08-02 14:28:33 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-08-02 14:28:33 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-08-02 14:28:33 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-08-02 14:28:33 --> Final output sent to browser
DEBUG - 2023-08-02 14:28:33 --> Total execution time: 0.0858
ERROR - 2023-08-02 14:30:21 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-02 14:30:21 --> Config Class Initialized
INFO - 2023-08-02 14:30:21 --> Hooks Class Initialized
DEBUG - 2023-08-02 14:30:21 --> UTF-8 Support Enabled
INFO - 2023-08-02 14:30:21 --> Utf8 Class Initialized
INFO - 2023-08-02 14:30:21 --> URI Class Initialized
INFO - 2023-08-02 14:30:21 --> Router Class Initialized
INFO - 2023-08-02 14:30:21 --> Output Class Initialized
INFO - 2023-08-02 14:30:21 --> Security Class Initialized
DEBUG - 2023-08-02 14:30:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-02 14:30:21 --> Input Class Initialized
INFO - 2023-08-02 14:30:21 --> Language Class Initialized
INFO - 2023-08-02 14:30:21 --> Loader Class Initialized
INFO - 2023-08-02 14:30:21 --> Helper loaded: url_helper
INFO - 2023-08-02 14:30:21 --> Helper loaded: file_helper
INFO - 2023-08-02 14:30:21 --> Helper loaded: html_helper
INFO - 2023-08-02 14:30:21 --> Helper loaded: text_helper
INFO - 2023-08-02 14:30:21 --> Helper loaded: form_helper
INFO - 2023-08-02 14:30:21 --> Helper loaded: lang_helper
INFO - 2023-08-02 14:30:21 --> Helper loaded: security_helper
INFO - 2023-08-02 14:30:21 --> Helper loaded: cookie_helper
INFO - 2023-08-02 14:30:21 --> Database Driver Class Initialized
INFO - 2023-08-02 14:30:21 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-02 14:30:21 --> Parser Class Initialized
INFO - 2023-08-02 14:30:21 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-02 14:30:21 --> Pagination Class Initialized
INFO - 2023-08-02 14:30:21 --> Form Validation Class Initialized
INFO - 2023-08-02 14:30:21 --> Controller Class Initialized
INFO - 2023-08-02 14:30:21 --> Model Class Initialized
DEBUG - 2023-08-02 14:30:21 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-02 14:30:21 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-02 14:30:21 --> Model Class Initialized
DEBUG - 2023-08-02 14:30:21 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-02 14:30:21 --> Model Class Initialized
INFO - 2023-08-02 14:30:21 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice.php
DEBUG - 2023-08-02 14:30:21 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-08-02 14:30:21 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-08-02 14:30:21 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-08-02 14:30:21 --> Model Class Initialized
INFO - 2023-08-02 14:30:21 --> Model Class Initialized
INFO - 2023-08-02 14:30:21 --> Model Class Initialized
INFO - 2023-08-02 14:30:21 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-08-02 14:30:21 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-08-02 14:30:21 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-08-02 14:30:21 --> Final output sent to browser
DEBUG - 2023-08-02 14:30:21 --> Total execution time: 0.0799
ERROR - 2023-08-02 14:30:22 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-02 14:30:22 --> Config Class Initialized
INFO - 2023-08-02 14:30:22 --> Hooks Class Initialized
DEBUG - 2023-08-02 14:30:22 --> UTF-8 Support Enabled
INFO - 2023-08-02 14:30:22 --> Utf8 Class Initialized
INFO - 2023-08-02 14:30:22 --> URI Class Initialized
INFO - 2023-08-02 14:30:22 --> Router Class Initialized
INFO - 2023-08-02 14:30:22 --> Output Class Initialized
INFO - 2023-08-02 14:30:22 --> Security Class Initialized
DEBUG - 2023-08-02 14:30:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-02 14:30:22 --> Input Class Initialized
INFO - 2023-08-02 14:30:22 --> Language Class Initialized
INFO - 2023-08-02 14:30:22 --> Loader Class Initialized
INFO - 2023-08-02 14:30:22 --> Helper loaded: url_helper
INFO - 2023-08-02 14:30:22 --> Helper loaded: file_helper
INFO - 2023-08-02 14:30:22 --> Helper loaded: html_helper
INFO - 2023-08-02 14:30:22 --> Helper loaded: text_helper
INFO - 2023-08-02 14:30:22 --> Helper loaded: form_helper
INFO - 2023-08-02 14:30:22 --> Helper loaded: lang_helper
INFO - 2023-08-02 14:30:22 --> Helper loaded: security_helper
INFO - 2023-08-02 14:30:22 --> Helper loaded: cookie_helper
INFO - 2023-08-02 14:30:22 --> Database Driver Class Initialized
INFO - 2023-08-02 14:30:22 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-02 14:30:22 --> Parser Class Initialized
INFO - 2023-08-02 14:30:22 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-02 14:30:22 --> Pagination Class Initialized
INFO - 2023-08-02 14:30:22 --> Form Validation Class Initialized
INFO - 2023-08-02 14:30:22 --> Controller Class Initialized
INFO - 2023-08-02 14:30:22 --> Model Class Initialized
DEBUG - 2023-08-02 14:30:22 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-02 14:30:22 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-02 14:30:22 --> Model Class Initialized
DEBUG - 2023-08-02 14:30:22 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-02 14:30:22 --> Model Class Initialized
INFO - 2023-08-02 14:30:22 --> Final output sent to browser
DEBUG - 2023-08-02 14:30:22 --> Total execution time: 0.0355
ERROR - 2023-08-02 15:28:30 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-02 15:28:30 --> Config Class Initialized
INFO - 2023-08-02 15:28:30 --> Hooks Class Initialized
DEBUG - 2023-08-02 15:28:30 --> UTF-8 Support Enabled
INFO - 2023-08-02 15:28:30 --> Utf8 Class Initialized
INFO - 2023-08-02 15:28:30 --> URI Class Initialized
DEBUG - 2023-08-02 15:28:30 --> No URI present. Default controller set.
INFO - 2023-08-02 15:28:30 --> Router Class Initialized
INFO - 2023-08-02 15:28:30 --> Output Class Initialized
INFO - 2023-08-02 15:28:30 --> Security Class Initialized
DEBUG - 2023-08-02 15:28:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-02 15:28:30 --> Input Class Initialized
INFO - 2023-08-02 15:28:30 --> Language Class Initialized
INFO - 2023-08-02 15:28:30 --> Loader Class Initialized
INFO - 2023-08-02 15:28:30 --> Helper loaded: url_helper
INFO - 2023-08-02 15:28:30 --> Helper loaded: file_helper
INFO - 2023-08-02 15:28:30 --> Helper loaded: html_helper
INFO - 2023-08-02 15:28:30 --> Helper loaded: text_helper
INFO - 2023-08-02 15:28:30 --> Helper loaded: form_helper
INFO - 2023-08-02 15:28:30 --> Helper loaded: lang_helper
INFO - 2023-08-02 15:28:30 --> Helper loaded: security_helper
INFO - 2023-08-02 15:28:30 --> Helper loaded: cookie_helper
INFO - 2023-08-02 15:28:30 --> Database Driver Class Initialized
INFO - 2023-08-02 15:28:30 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-02 15:28:30 --> Parser Class Initialized
INFO - 2023-08-02 15:28:30 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-02 15:28:30 --> Pagination Class Initialized
INFO - 2023-08-02 15:28:30 --> Form Validation Class Initialized
INFO - 2023-08-02 15:28:30 --> Controller Class Initialized
INFO - 2023-08-02 15:28:30 --> Model Class Initialized
DEBUG - 2023-08-02 15:28:30 --> Session class already loaded. Second attempt ignored.
ERROR - 2023-08-02 15:28:30 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-02 15:28:30 --> Config Class Initialized
INFO - 2023-08-02 15:28:30 --> Hooks Class Initialized
DEBUG - 2023-08-02 15:28:30 --> UTF-8 Support Enabled
INFO - 2023-08-02 15:28:30 --> Utf8 Class Initialized
INFO - 2023-08-02 15:28:30 --> URI Class Initialized
INFO - 2023-08-02 15:28:30 --> Router Class Initialized
INFO - 2023-08-02 15:28:30 --> Output Class Initialized
INFO - 2023-08-02 15:28:30 --> Security Class Initialized
DEBUG - 2023-08-02 15:28:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-02 15:28:30 --> Input Class Initialized
INFO - 2023-08-02 15:28:30 --> Language Class Initialized
INFO - 2023-08-02 15:28:30 --> Loader Class Initialized
INFO - 2023-08-02 15:28:30 --> Helper loaded: url_helper
INFO - 2023-08-02 15:28:30 --> Helper loaded: file_helper
INFO - 2023-08-02 15:28:30 --> Helper loaded: html_helper
INFO - 2023-08-02 15:28:30 --> Helper loaded: text_helper
INFO - 2023-08-02 15:28:30 --> Helper loaded: form_helper
INFO - 2023-08-02 15:28:30 --> Helper loaded: lang_helper
INFO - 2023-08-02 15:28:30 --> Helper loaded: security_helper
INFO - 2023-08-02 15:28:30 --> Helper loaded: cookie_helper
INFO - 2023-08-02 15:28:30 --> Database Driver Class Initialized
INFO - 2023-08-02 15:28:30 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-02 15:28:30 --> Parser Class Initialized
INFO - 2023-08-02 15:28:30 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-02 15:28:30 --> Pagination Class Initialized
INFO - 2023-08-02 15:28:30 --> Form Validation Class Initialized
INFO - 2023-08-02 15:28:30 --> Controller Class Initialized
INFO - 2023-08-02 15:28:30 --> Model Class Initialized
DEBUG - 2023-08-02 15:28:30 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-02 15:28:30 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2023-08-02 15:28:30 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-08-02 15:28:30 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-08-02 15:28:30 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-08-02 15:28:30 --> Model Class Initialized
INFO - 2023-08-02 15:28:30 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-08-02 15:28:30 --> Final output sent to browser
DEBUG - 2023-08-02 15:28:30 --> Total execution time: 0.0341
ERROR - 2023-08-02 15:29:30 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-02 15:29:30 --> Config Class Initialized
INFO - 2023-08-02 15:29:30 --> Hooks Class Initialized
DEBUG - 2023-08-02 15:29:30 --> UTF-8 Support Enabled
INFO - 2023-08-02 15:29:30 --> Utf8 Class Initialized
INFO - 2023-08-02 15:29:30 --> URI Class Initialized
INFO - 2023-08-02 15:29:30 --> Router Class Initialized
INFO - 2023-08-02 15:29:30 --> Output Class Initialized
INFO - 2023-08-02 15:29:30 --> Security Class Initialized
DEBUG - 2023-08-02 15:29:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-02 15:29:30 --> Input Class Initialized
INFO - 2023-08-02 15:29:30 --> Language Class Initialized
INFO - 2023-08-02 15:29:30 --> Loader Class Initialized
INFO - 2023-08-02 15:29:30 --> Helper loaded: url_helper
INFO - 2023-08-02 15:29:30 --> Helper loaded: file_helper
INFO - 2023-08-02 15:29:30 --> Helper loaded: html_helper
INFO - 2023-08-02 15:29:30 --> Helper loaded: text_helper
INFO - 2023-08-02 15:29:30 --> Helper loaded: form_helper
INFO - 2023-08-02 15:29:30 --> Helper loaded: lang_helper
INFO - 2023-08-02 15:29:30 --> Helper loaded: security_helper
INFO - 2023-08-02 15:29:30 --> Helper loaded: cookie_helper
INFO - 2023-08-02 15:29:30 --> Database Driver Class Initialized
INFO - 2023-08-02 15:29:30 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-02 15:29:30 --> Parser Class Initialized
INFO - 2023-08-02 15:29:30 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-02 15:29:30 --> Pagination Class Initialized
INFO - 2023-08-02 15:29:30 --> Form Validation Class Initialized
INFO - 2023-08-02 15:29:30 --> Controller Class Initialized
INFO - 2023-08-02 15:29:30 --> Model Class Initialized
DEBUG - 2023-08-02 15:29:30 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-02 15:29:30 --> Model Class Initialized
INFO - 2023-08-02 15:29:30 --> Final output sent to browser
DEBUG - 2023-08-02 15:29:30 --> Total execution time: 0.0198
ERROR - 2023-08-02 15:29:30 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-02 15:29:30 --> Config Class Initialized
INFO - 2023-08-02 15:29:30 --> Hooks Class Initialized
DEBUG - 2023-08-02 15:29:30 --> UTF-8 Support Enabled
INFO - 2023-08-02 15:29:30 --> Utf8 Class Initialized
INFO - 2023-08-02 15:29:30 --> URI Class Initialized
DEBUG - 2023-08-02 15:29:30 --> No URI present. Default controller set.
INFO - 2023-08-02 15:29:30 --> Router Class Initialized
INFO - 2023-08-02 15:29:30 --> Output Class Initialized
INFO - 2023-08-02 15:29:30 --> Security Class Initialized
DEBUG - 2023-08-02 15:29:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-02 15:29:30 --> Input Class Initialized
INFO - 2023-08-02 15:29:30 --> Language Class Initialized
INFO - 2023-08-02 15:29:30 --> Loader Class Initialized
INFO - 2023-08-02 15:29:30 --> Helper loaded: url_helper
INFO - 2023-08-02 15:29:30 --> Helper loaded: file_helper
INFO - 2023-08-02 15:29:30 --> Helper loaded: html_helper
INFO - 2023-08-02 15:29:30 --> Helper loaded: text_helper
INFO - 2023-08-02 15:29:30 --> Helper loaded: form_helper
INFO - 2023-08-02 15:29:30 --> Helper loaded: lang_helper
INFO - 2023-08-02 15:29:30 --> Helper loaded: security_helper
INFO - 2023-08-02 15:29:30 --> Helper loaded: cookie_helper
INFO - 2023-08-02 15:29:30 --> Database Driver Class Initialized
INFO - 2023-08-02 15:29:30 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-02 15:29:30 --> Parser Class Initialized
INFO - 2023-08-02 15:29:30 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-02 15:29:30 --> Pagination Class Initialized
INFO - 2023-08-02 15:29:30 --> Form Validation Class Initialized
INFO - 2023-08-02 15:29:30 --> Controller Class Initialized
INFO - 2023-08-02 15:29:30 --> Model Class Initialized
DEBUG - 2023-08-02 15:29:30 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-02 15:29:30 --> Model Class Initialized
DEBUG - 2023-08-02 15:29:30 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-02 15:29:30 --> Model Class Initialized
INFO - 2023-08-02 15:29:30 --> Model Class Initialized
INFO - 2023-08-02 15:29:30 --> Model Class Initialized
INFO - 2023-08-02 15:29:30 --> Model Class Initialized
DEBUG - 2023-08-02 15:29:30 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-02 15:29:30 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-02 15:29:30 --> Model Class Initialized
INFO - 2023-08-02 15:29:30 --> Model Class Initialized
INFO - 2023-08-02 15:29:30 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-08-02 15:29:30 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-08-02 15:29:30 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-08-02 15:29:30 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-08-02 15:29:30 --> Model Class Initialized
INFO - 2023-08-02 15:29:30 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-08-02 15:29:30 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-08-02 15:29:30 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-08-02 15:29:30 --> Final output sent to browser
DEBUG - 2023-08-02 15:29:30 --> Total execution time: 0.0828
ERROR - 2023-08-02 15:29:50 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-02 15:29:50 --> Config Class Initialized
INFO - 2023-08-02 15:29:50 --> Hooks Class Initialized
DEBUG - 2023-08-02 15:29:50 --> UTF-8 Support Enabled
INFO - 2023-08-02 15:29:50 --> Utf8 Class Initialized
INFO - 2023-08-02 15:29:50 --> URI Class Initialized
INFO - 2023-08-02 15:29:50 --> Router Class Initialized
INFO - 2023-08-02 15:29:50 --> Output Class Initialized
INFO - 2023-08-02 15:29:50 --> Security Class Initialized
DEBUG - 2023-08-02 15:29:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-02 15:29:50 --> Input Class Initialized
INFO - 2023-08-02 15:29:50 --> Language Class Initialized
INFO - 2023-08-02 15:29:50 --> Loader Class Initialized
INFO - 2023-08-02 15:29:50 --> Helper loaded: url_helper
INFO - 2023-08-02 15:29:50 --> Helper loaded: file_helper
INFO - 2023-08-02 15:29:50 --> Helper loaded: html_helper
INFO - 2023-08-02 15:29:50 --> Helper loaded: text_helper
INFO - 2023-08-02 15:29:50 --> Helper loaded: form_helper
INFO - 2023-08-02 15:29:50 --> Helper loaded: lang_helper
INFO - 2023-08-02 15:29:50 --> Helper loaded: security_helper
INFO - 2023-08-02 15:29:50 --> Helper loaded: cookie_helper
INFO - 2023-08-02 15:29:50 --> Database Driver Class Initialized
INFO - 2023-08-02 15:29:50 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-02 15:29:50 --> Parser Class Initialized
INFO - 2023-08-02 15:29:50 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-02 15:29:50 --> Pagination Class Initialized
INFO - 2023-08-02 15:29:50 --> Form Validation Class Initialized
INFO - 2023-08-02 15:29:50 --> Controller Class Initialized
DEBUG - 2023-08-02 15:29:50 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-02 15:29:50 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-02 15:29:50 --> Model Class Initialized
DEBUG - 2023-08-02 15:29:50 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-02 15:29:50 --> Model Class Initialized
INFO - 2023-08-02 15:29:51 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/customer/add_customer_form.php
DEBUG - 2023-08-02 15:29:51 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-08-02 15:29:51 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-08-02 15:29:51 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-08-02 15:29:51 --> Model Class Initialized
INFO - 2023-08-02 15:29:51 --> Model Class Initialized
INFO - 2023-08-02 15:29:51 --> Model Class Initialized
INFO - 2023-08-02 15:29:51 --> Model Class Initialized
INFO - 2023-08-02 15:29:51 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-08-02 15:29:51 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-08-02 15:29:51 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-08-02 15:29:51 --> Final output sent to browser
DEBUG - 2023-08-02 15:29:51 --> Total execution time: 0.1053
ERROR - 2023-08-02 15:30:26 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-02 15:30:26 --> Config Class Initialized
INFO - 2023-08-02 15:30:26 --> Hooks Class Initialized
DEBUG - 2023-08-02 15:30:26 --> UTF-8 Support Enabled
INFO - 2023-08-02 15:30:26 --> Utf8 Class Initialized
INFO - 2023-08-02 15:30:26 --> URI Class Initialized
DEBUG - 2023-08-02 15:30:26 --> No URI present. Default controller set.
INFO - 2023-08-02 15:30:26 --> Router Class Initialized
INFO - 2023-08-02 15:30:26 --> Output Class Initialized
INFO - 2023-08-02 15:30:26 --> Security Class Initialized
DEBUG - 2023-08-02 15:30:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-02 15:30:26 --> Input Class Initialized
INFO - 2023-08-02 15:30:26 --> Language Class Initialized
INFO - 2023-08-02 15:30:26 --> Loader Class Initialized
INFO - 2023-08-02 15:30:26 --> Helper loaded: url_helper
INFO - 2023-08-02 15:30:26 --> Helper loaded: file_helper
INFO - 2023-08-02 15:30:26 --> Helper loaded: html_helper
INFO - 2023-08-02 15:30:26 --> Helper loaded: text_helper
INFO - 2023-08-02 15:30:26 --> Helper loaded: form_helper
INFO - 2023-08-02 15:30:26 --> Helper loaded: lang_helper
INFO - 2023-08-02 15:30:26 --> Helper loaded: security_helper
INFO - 2023-08-02 15:30:26 --> Helper loaded: cookie_helper
INFO - 2023-08-02 15:30:26 --> Database Driver Class Initialized
INFO - 2023-08-02 15:30:26 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-02 15:30:26 --> Parser Class Initialized
INFO - 2023-08-02 15:30:26 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-02 15:30:26 --> Pagination Class Initialized
INFO - 2023-08-02 15:30:26 --> Form Validation Class Initialized
INFO - 2023-08-02 15:30:26 --> Controller Class Initialized
INFO - 2023-08-02 15:30:26 --> Model Class Initialized
DEBUG - 2023-08-02 15:30:26 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-02 15:30:26 --> Model Class Initialized
DEBUG - 2023-08-02 15:30:26 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-02 15:30:26 --> Model Class Initialized
INFO - 2023-08-02 15:30:26 --> Model Class Initialized
INFO - 2023-08-02 15:30:26 --> Model Class Initialized
INFO - 2023-08-02 15:30:26 --> Model Class Initialized
DEBUG - 2023-08-02 15:30:26 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-02 15:30:26 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-02 15:30:26 --> Model Class Initialized
INFO - 2023-08-02 15:30:26 --> Model Class Initialized
INFO - 2023-08-02 15:30:26 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-08-02 15:30:26 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-08-02 15:30:26 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-08-02 15:30:26 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-08-02 15:30:26 --> Model Class Initialized
INFO - 2023-08-02 15:30:26 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-08-02 15:30:26 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-08-02 15:30:26 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-08-02 15:30:26 --> Final output sent to browser
DEBUG - 2023-08-02 15:30:26 --> Total execution time: 0.0943
ERROR - 2023-08-02 15:30:40 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-02 15:30:40 --> Config Class Initialized
INFO - 2023-08-02 15:30:40 --> Hooks Class Initialized
DEBUG - 2023-08-02 15:30:40 --> UTF-8 Support Enabled
INFO - 2023-08-02 15:30:40 --> Utf8 Class Initialized
INFO - 2023-08-02 15:30:40 --> URI Class Initialized
INFO - 2023-08-02 15:30:40 --> Router Class Initialized
INFO - 2023-08-02 15:30:40 --> Output Class Initialized
INFO - 2023-08-02 15:30:40 --> Security Class Initialized
DEBUG - 2023-08-02 15:30:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-02 15:30:40 --> Input Class Initialized
INFO - 2023-08-02 15:30:40 --> Language Class Initialized
INFO - 2023-08-02 15:30:40 --> Loader Class Initialized
INFO - 2023-08-02 15:30:40 --> Helper loaded: url_helper
INFO - 2023-08-02 15:30:40 --> Helper loaded: file_helper
INFO - 2023-08-02 15:30:40 --> Helper loaded: html_helper
INFO - 2023-08-02 15:30:40 --> Helper loaded: text_helper
INFO - 2023-08-02 15:30:40 --> Helper loaded: form_helper
INFO - 2023-08-02 15:30:40 --> Helper loaded: lang_helper
INFO - 2023-08-02 15:30:40 --> Helper loaded: security_helper
INFO - 2023-08-02 15:30:40 --> Helper loaded: cookie_helper
INFO - 2023-08-02 15:30:40 --> Database Driver Class Initialized
INFO - 2023-08-02 15:30:40 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-02 15:30:40 --> Parser Class Initialized
INFO - 2023-08-02 15:30:40 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-02 15:30:40 --> Pagination Class Initialized
INFO - 2023-08-02 15:30:40 --> Form Validation Class Initialized
INFO - 2023-08-02 15:30:40 --> Controller Class Initialized
DEBUG - 2023-08-02 15:30:40 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-02 15:30:40 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-02 15:30:40 --> Model Class Initialized
DEBUG - 2023-08-02 15:30:40 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-02 15:30:40 --> Model Class Initialized
INFO - 2023-08-02 15:30:40 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/customer/add_customer_form.php
DEBUG - 2023-08-02 15:30:40 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-08-02 15:30:40 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-08-02 15:30:40 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-08-02 15:30:40 --> Model Class Initialized
INFO - 2023-08-02 15:30:40 --> Model Class Initialized
INFO - 2023-08-02 15:30:40 --> Model Class Initialized
INFO - 2023-08-02 15:30:40 --> Model Class Initialized
INFO - 2023-08-02 15:30:40 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-08-02 15:30:40 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-08-02 15:30:40 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-08-02 15:30:40 --> Final output sent to browser
DEBUG - 2023-08-02 15:30:40 --> Total execution time: 0.0993
ERROR - 2023-08-02 15:37:09 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-02 15:37:09 --> Config Class Initialized
INFO - 2023-08-02 15:37:09 --> Hooks Class Initialized
DEBUG - 2023-08-02 15:37:09 --> UTF-8 Support Enabled
INFO - 2023-08-02 15:37:09 --> Utf8 Class Initialized
INFO - 2023-08-02 15:37:09 --> URI Class Initialized
INFO - 2023-08-02 15:37:09 --> Router Class Initialized
INFO - 2023-08-02 15:37:09 --> Output Class Initialized
INFO - 2023-08-02 15:37:09 --> Security Class Initialized
DEBUG - 2023-08-02 15:37:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-02 15:37:09 --> Input Class Initialized
INFO - 2023-08-02 15:37:09 --> Language Class Initialized
INFO - 2023-08-02 15:37:09 --> Loader Class Initialized
INFO - 2023-08-02 15:37:09 --> Helper loaded: url_helper
INFO - 2023-08-02 15:37:09 --> Helper loaded: file_helper
INFO - 2023-08-02 15:37:09 --> Helper loaded: html_helper
INFO - 2023-08-02 15:37:09 --> Helper loaded: text_helper
INFO - 2023-08-02 15:37:09 --> Helper loaded: form_helper
INFO - 2023-08-02 15:37:09 --> Helper loaded: lang_helper
INFO - 2023-08-02 15:37:09 --> Helper loaded: security_helper
INFO - 2023-08-02 15:37:09 --> Helper loaded: cookie_helper
INFO - 2023-08-02 15:37:09 --> Database Driver Class Initialized
INFO - 2023-08-02 15:37:09 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-02 15:37:09 --> Parser Class Initialized
INFO - 2023-08-02 15:37:09 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-02 15:37:09 --> Pagination Class Initialized
INFO - 2023-08-02 15:37:09 --> Form Validation Class Initialized
INFO - 2023-08-02 15:37:09 --> Controller Class Initialized
DEBUG - 2023-08-02 15:37:09 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-02 15:37:09 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-02 15:37:09 --> Model Class Initialized
DEBUG - 2023-08-02 15:37:09 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-02 15:37:09 --> Model Class Initialized
DEBUG - 2023-08-02 15:37:09 --> Auth class already loaded. Second attempt ignored.
INFO - 2023-08-02 15:37:09 --> Final output sent to browser
DEBUG - 2023-08-02 15:37:09 --> Total execution time: 0.0276
ERROR - 2023-08-02 15:37:49 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-02 15:37:49 --> Config Class Initialized
INFO - 2023-08-02 15:37:49 --> Hooks Class Initialized
DEBUG - 2023-08-02 15:37:49 --> UTF-8 Support Enabled
INFO - 2023-08-02 15:37:49 --> Utf8 Class Initialized
INFO - 2023-08-02 15:37:49 --> URI Class Initialized
INFO - 2023-08-02 15:37:49 --> Router Class Initialized
INFO - 2023-08-02 15:37:49 --> Output Class Initialized
INFO - 2023-08-02 15:37:49 --> Security Class Initialized
DEBUG - 2023-08-02 15:37:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-02 15:37:49 --> Input Class Initialized
INFO - 2023-08-02 15:37:49 --> Language Class Initialized
INFO - 2023-08-02 15:37:49 --> Loader Class Initialized
INFO - 2023-08-02 15:37:49 --> Helper loaded: url_helper
INFO - 2023-08-02 15:37:49 --> Helper loaded: file_helper
INFO - 2023-08-02 15:37:49 --> Helper loaded: html_helper
INFO - 2023-08-02 15:37:49 --> Helper loaded: text_helper
INFO - 2023-08-02 15:37:49 --> Helper loaded: form_helper
INFO - 2023-08-02 15:37:49 --> Helper loaded: lang_helper
INFO - 2023-08-02 15:37:49 --> Helper loaded: security_helper
INFO - 2023-08-02 15:37:49 --> Helper loaded: cookie_helper
INFO - 2023-08-02 15:37:49 --> Database Driver Class Initialized
INFO - 2023-08-02 15:37:49 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-02 15:37:49 --> Parser Class Initialized
INFO - 2023-08-02 15:37:49 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-02 15:37:49 --> Pagination Class Initialized
INFO - 2023-08-02 15:37:49 --> Form Validation Class Initialized
INFO - 2023-08-02 15:37:49 --> Controller Class Initialized
DEBUG - 2023-08-02 15:37:49 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-02 15:37:49 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-02 15:37:49 --> Model Class Initialized
DEBUG - 2023-08-02 15:37:49 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-02 15:37:49 --> Model Class Initialized
INFO - 2023-08-02 15:37:49 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/customer/add_customer_form.php
DEBUG - 2023-08-02 15:37:49 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-08-02 15:37:49 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-08-02 15:37:49 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-08-02 15:37:49 --> Model Class Initialized
INFO - 2023-08-02 15:37:49 --> Model Class Initialized
INFO - 2023-08-02 15:37:49 --> Model Class Initialized
INFO - 2023-08-02 15:37:49 --> Model Class Initialized
INFO - 2023-08-02 15:37:49 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-08-02 15:37:49 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-08-02 15:37:49 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-08-02 15:37:49 --> Final output sent to browser
DEBUG - 2023-08-02 15:37:49 --> Total execution time: 0.1087
ERROR - 2023-08-02 15:37:52 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-02 15:37:52 --> Config Class Initialized
INFO - 2023-08-02 15:37:52 --> Hooks Class Initialized
DEBUG - 2023-08-02 15:37:52 --> UTF-8 Support Enabled
INFO - 2023-08-02 15:37:52 --> Utf8 Class Initialized
INFO - 2023-08-02 15:37:52 --> URI Class Initialized
DEBUG - 2023-08-02 15:37:52 --> No URI present. Default controller set.
INFO - 2023-08-02 15:37:52 --> Router Class Initialized
INFO - 2023-08-02 15:37:52 --> Output Class Initialized
INFO - 2023-08-02 15:37:52 --> Security Class Initialized
DEBUG - 2023-08-02 15:37:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-02 15:37:52 --> Input Class Initialized
INFO - 2023-08-02 15:37:52 --> Language Class Initialized
INFO - 2023-08-02 15:37:52 --> Loader Class Initialized
INFO - 2023-08-02 15:37:52 --> Helper loaded: url_helper
INFO - 2023-08-02 15:37:52 --> Helper loaded: file_helper
INFO - 2023-08-02 15:37:52 --> Helper loaded: html_helper
INFO - 2023-08-02 15:37:52 --> Helper loaded: text_helper
INFO - 2023-08-02 15:37:52 --> Helper loaded: form_helper
INFO - 2023-08-02 15:37:52 --> Helper loaded: lang_helper
INFO - 2023-08-02 15:37:52 --> Helper loaded: security_helper
INFO - 2023-08-02 15:37:52 --> Helper loaded: cookie_helper
INFO - 2023-08-02 15:37:52 --> Database Driver Class Initialized
INFO - 2023-08-02 15:37:52 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-02 15:37:52 --> Parser Class Initialized
INFO - 2023-08-02 15:37:52 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-02 15:37:52 --> Pagination Class Initialized
INFO - 2023-08-02 15:37:52 --> Form Validation Class Initialized
INFO - 2023-08-02 15:37:52 --> Controller Class Initialized
INFO - 2023-08-02 15:37:52 --> Model Class Initialized
DEBUG - 2023-08-02 15:37:52 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-02 15:37:52 --> Model Class Initialized
DEBUG - 2023-08-02 15:37:52 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-02 15:37:52 --> Model Class Initialized
INFO - 2023-08-02 15:37:52 --> Model Class Initialized
INFO - 2023-08-02 15:37:52 --> Model Class Initialized
INFO - 2023-08-02 15:37:52 --> Model Class Initialized
DEBUG - 2023-08-02 15:37:52 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-02 15:37:52 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-02 15:37:52 --> Model Class Initialized
INFO - 2023-08-02 15:37:52 --> Model Class Initialized
INFO - 2023-08-02 15:37:52 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-08-02 15:37:52 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-08-02 15:37:52 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-08-02 15:37:52 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-08-02 15:37:52 --> Model Class Initialized
INFO - 2023-08-02 15:37:52 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-08-02 15:37:52 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-08-02 15:37:52 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-08-02 15:37:52 --> Final output sent to browser
DEBUG - 2023-08-02 15:37:52 --> Total execution time: 0.0900
ERROR - 2023-08-02 15:39:18 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-02 15:39:18 --> Config Class Initialized
INFO - 2023-08-02 15:39:18 --> Hooks Class Initialized
DEBUG - 2023-08-02 15:39:18 --> UTF-8 Support Enabled
INFO - 2023-08-02 15:39:18 --> Utf8 Class Initialized
INFO - 2023-08-02 15:39:18 --> URI Class Initialized
INFO - 2023-08-02 15:39:18 --> Router Class Initialized
INFO - 2023-08-02 15:39:18 --> Output Class Initialized
INFO - 2023-08-02 15:39:18 --> Security Class Initialized
DEBUG - 2023-08-02 15:39:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-02 15:39:18 --> Input Class Initialized
INFO - 2023-08-02 15:39:18 --> Language Class Initialized
INFO - 2023-08-02 15:39:18 --> Loader Class Initialized
INFO - 2023-08-02 15:39:18 --> Helper loaded: url_helper
INFO - 2023-08-02 15:39:18 --> Helper loaded: file_helper
INFO - 2023-08-02 15:39:18 --> Helper loaded: html_helper
INFO - 2023-08-02 15:39:18 --> Helper loaded: text_helper
INFO - 2023-08-02 15:39:18 --> Helper loaded: form_helper
INFO - 2023-08-02 15:39:18 --> Helper loaded: lang_helper
INFO - 2023-08-02 15:39:18 --> Helper loaded: security_helper
INFO - 2023-08-02 15:39:18 --> Helper loaded: cookie_helper
INFO - 2023-08-02 15:39:18 --> Database Driver Class Initialized
INFO - 2023-08-02 15:39:18 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-02 15:39:18 --> Parser Class Initialized
INFO - 2023-08-02 15:39:18 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-02 15:39:18 --> Pagination Class Initialized
INFO - 2023-08-02 15:39:18 --> Form Validation Class Initialized
INFO - 2023-08-02 15:39:18 --> Controller Class Initialized
INFO - 2023-08-02 15:39:18 --> Model Class Initialized
DEBUG - 2023-08-02 15:39:18 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-02 15:39:18 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-02 15:39:18 --> Model Class Initialized
DEBUG - 2023-08-02 15:39:18 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-02 15:39:18 --> Model Class Initialized
INFO - 2023-08-02 15:39:18 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/add_invoice_form.php
DEBUG - 2023-08-02 15:39:18 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-08-02 15:39:18 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-08-02 15:39:18 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-08-02 15:39:18 --> Model Class Initialized
INFO - 2023-08-02 15:39:18 --> Model Class Initialized
INFO - 2023-08-02 15:39:18 --> Model Class Initialized
INFO - 2023-08-02 15:39:18 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-08-02 15:39:18 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-08-02 15:39:18 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-08-02 15:39:18 --> Final output sent to browser
DEBUG - 2023-08-02 15:39:18 --> Total execution time: 0.0950
ERROR - 2023-08-02 15:39:35 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-02 15:39:35 --> Config Class Initialized
INFO - 2023-08-02 15:39:35 --> Hooks Class Initialized
DEBUG - 2023-08-02 15:39:35 --> UTF-8 Support Enabled
INFO - 2023-08-02 15:39:35 --> Utf8 Class Initialized
INFO - 2023-08-02 15:39:35 --> URI Class Initialized
INFO - 2023-08-02 15:39:35 --> Router Class Initialized
INFO - 2023-08-02 15:39:35 --> Output Class Initialized
INFO - 2023-08-02 15:39:35 --> Security Class Initialized
DEBUG - 2023-08-02 15:39:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-02 15:39:35 --> Input Class Initialized
INFO - 2023-08-02 15:39:35 --> Language Class Initialized
INFO - 2023-08-02 15:39:35 --> Loader Class Initialized
INFO - 2023-08-02 15:39:35 --> Helper loaded: url_helper
INFO - 2023-08-02 15:39:35 --> Helper loaded: file_helper
INFO - 2023-08-02 15:39:35 --> Helper loaded: html_helper
INFO - 2023-08-02 15:39:35 --> Helper loaded: text_helper
INFO - 2023-08-02 15:39:35 --> Helper loaded: form_helper
INFO - 2023-08-02 15:39:35 --> Helper loaded: lang_helper
INFO - 2023-08-02 15:39:35 --> Helper loaded: security_helper
INFO - 2023-08-02 15:39:35 --> Helper loaded: cookie_helper
INFO - 2023-08-02 15:39:35 --> Database Driver Class Initialized
INFO - 2023-08-02 15:39:35 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-02 15:39:35 --> Parser Class Initialized
INFO - 2023-08-02 15:39:35 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-02 15:39:35 --> Pagination Class Initialized
INFO - 2023-08-02 15:39:35 --> Form Validation Class Initialized
INFO - 2023-08-02 15:39:35 --> Controller Class Initialized
INFO - 2023-08-02 15:39:35 --> Model Class Initialized
DEBUG - 2023-08-02 15:39:35 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-02 15:39:35 --> Final output sent to browser
DEBUG - 2023-08-02 15:39:35 --> Total execution time: 0.0190
ERROR - 2023-08-02 15:39:36 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-02 15:39:36 --> Config Class Initialized
INFO - 2023-08-02 15:39:36 --> Hooks Class Initialized
DEBUG - 2023-08-02 15:39:36 --> UTF-8 Support Enabled
INFO - 2023-08-02 15:39:36 --> Utf8 Class Initialized
INFO - 2023-08-02 15:39:36 --> URI Class Initialized
INFO - 2023-08-02 15:39:36 --> Router Class Initialized
INFO - 2023-08-02 15:39:36 --> Output Class Initialized
INFO - 2023-08-02 15:39:36 --> Security Class Initialized
DEBUG - 2023-08-02 15:39:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-02 15:39:36 --> Input Class Initialized
INFO - 2023-08-02 15:39:36 --> Language Class Initialized
INFO - 2023-08-02 15:39:36 --> Loader Class Initialized
INFO - 2023-08-02 15:39:36 --> Helper loaded: url_helper
INFO - 2023-08-02 15:39:36 --> Helper loaded: file_helper
INFO - 2023-08-02 15:39:36 --> Helper loaded: html_helper
INFO - 2023-08-02 15:39:36 --> Helper loaded: text_helper
INFO - 2023-08-02 15:39:36 --> Helper loaded: form_helper
INFO - 2023-08-02 15:39:36 --> Helper loaded: lang_helper
INFO - 2023-08-02 15:39:36 --> Helper loaded: security_helper
INFO - 2023-08-02 15:39:36 --> Helper loaded: cookie_helper
INFO - 2023-08-02 15:39:36 --> Database Driver Class Initialized
INFO - 2023-08-02 15:39:36 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-02 15:39:36 --> Parser Class Initialized
INFO - 2023-08-02 15:39:36 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-02 15:39:36 --> Pagination Class Initialized
INFO - 2023-08-02 15:39:36 --> Form Validation Class Initialized
INFO - 2023-08-02 15:39:36 --> Controller Class Initialized
INFO - 2023-08-02 15:39:36 --> Model Class Initialized
DEBUG - 2023-08-02 15:39:36 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-02 15:39:36 --> Final output sent to browser
DEBUG - 2023-08-02 15:39:36 --> Total execution time: 0.0163
ERROR - 2023-08-02 15:39:36 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-02 15:39:36 --> Config Class Initialized
INFO - 2023-08-02 15:39:36 --> Hooks Class Initialized
DEBUG - 2023-08-02 15:39:36 --> UTF-8 Support Enabled
INFO - 2023-08-02 15:39:36 --> Utf8 Class Initialized
INFO - 2023-08-02 15:39:36 --> URI Class Initialized
INFO - 2023-08-02 15:39:36 --> Router Class Initialized
INFO - 2023-08-02 15:39:36 --> Output Class Initialized
INFO - 2023-08-02 15:39:36 --> Security Class Initialized
DEBUG - 2023-08-02 15:39:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-02 15:39:36 --> Input Class Initialized
INFO - 2023-08-02 15:39:36 --> Language Class Initialized
INFO - 2023-08-02 15:39:36 --> Loader Class Initialized
INFO - 2023-08-02 15:39:36 --> Helper loaded: url_helper
INFO - 2023-08-02 15:39:36 --> Helper loaded: file_helper
INFO - 2023-08-02 15:39:36 --> Helper loaded: html_helper
INFO - 2023-08-02 15:39:36 --> Helper loaded: text_helper
INFO - 2023-08-02 15:39:36 --> Helper loaded: form_helper
INFO - 2023-08-02 15:39:36 --> Helper loaded: lang_helper
INFO - 2023-08-02 15:39:36 --> Helper loaded: security_helper
INFO - 2023-08-02 15:39:36 --> Helper loaded: cookie_helper
INFO - 2023-08-02 15:39:36 --> Database Driver Class Initialized
INFO - 2023-08-02 15:39:36 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-02 15:39:36 --> Parser Class Initialized
INFO - 2023-08-02 15:39:36 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-02 15:39:36 --> Pagination Class Initialized
INFO - 2023-08-02 15:39:36 --> Form Validation Class Initialized
INFO - 2023-08-02 15:39:36 --> Controller Class Initialized
INFO - 2023-08-02 15:39:36 --> Model Class Initialized
DEBUG - 2023-08-02 15:39:36 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-02 15:39:36 --> Final output sent to browser
DEBUG - 2023-08-02 15:39:36 --> Total execution time: 0.0159
ERROR - 2023-08-02 15:39:37 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-02 15:39:37 --> Config Class Initialized
INFO - 2023-08-02 15:39:37 --> Hooks Class Initialized
DEBUG - 2023-08-02 15:39:37 --> UTF-8 Support Enabled
INFO - 2023-08-02 15:39:37 --> Utf8 Class Initialized
INFO - 2023-08-02 15:39:37 --> URI Class Initialized
INFO - 2023-08-02 15:39:37 --> Router Class Initialized
INFO - 2023-08-02 15:39:37 --> Output Class Initialized
INFO - 2023-08-02 15:39:37 --> Security Class Initialized
DEBUG - 2023-08-02 15:39:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-02 15:39:37 --> Input Class Initialized
INFO - 2023-08-02 15:39:37 --> Language Class Initialized
INFO - 2023-08-02 15:39:37 --> Loader Class Initialized
INFO - 2023-08-02 15:39:37 --> Helper loaded: url_helper
INFO - 2023-08-02 15:39:37 --> Helper loaded: file_helper
INFO - 2023-08-02 15:39:37 --> Helper loaded: html_helper
INFO - 2023-08-02 15:39:37 --> Helper loaded: text_helper
INFO - 2023-08-02 15:39:37 --> Helper loaded: form_helper
INFO - 2023-08-02 15:39:37 --> Helper loaded: lang_helper
INFO - 2023-08-02 15:39:37 --> Helper loaded: security_helper
INFO - 2023-08-02 15:39:37 --> Helper loaded: cookie_helper
INFO - 2023-08-02 15:39:37 --> Database Driver Class Initialized
INFO - 2023-08-02 15:39:37 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-02 15:39:37 --> Parser Class Initialized
INFO - 2023-08-02 15:39:37 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-02 15:39:37 --> Pagination Class Initialized
INFO - 2023-08-02 15:39:37 --> Form Validation Class Initialized
INFO - 2023-08-02 15:39:37 --> Controller Class Initialized
INFO - 2023-08-02 15:39:37 --> Model Class Initialized
DEBUG - 2023-08-02 15:39:37 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-02 15:39:37 --> Final output sent to browser
DEBUG - 2023-08-02 15:39:37 --> Total execution time: 0.0162
ERROR - 2023-08-02 15:39:38 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-02 15:39:38 --> Config Class Initialized
INFO - 2023-08-02 15:39:38 --> Hooks Class Initialized
DEBUG - 2023-08-02 15:39:38 --> UTF-8 Support Enabled
INFO - 2023-08-02 15:39:38 --> Utf8 Class Initialized
INFO - 2023-08-02 15:39:38 --> URI Class Initialized
INFO - 2023-08-02 15:39:38 --> Router Class Initialized
INFO - 2023-08-02 15:39:38 --> Output Class Initialized
INFO - 2023-08-02 15:39:38 --> Security Class Initialized
DEBUG - 2023-08-02 15:39:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-02 15:39:38 --> Input Class Initialized
INFO - 2023-08-02 15:39:38 --> Language Class Initialized
INFO - 2023-08-02 15:39:38 --> Loader Class Initialized
INFO - 2023-08-02 15:39:38 --> Helper loaded: url_helper
INFO - 2023-08-02 15:39:38 --> Helper loaded: file_helper
INFO - 2023-08-02 15:39:38 --> Helper loaded: html_helper
INFO - 2023-08-02 15:39:38 --> Helper loaded: text_helper
INFO - 2023-08-02 15:39:38 --> Helper loaded: form_helper
INFO - 2023-08-02 15:39:38 --> Helper loaded: lang_helper
INFO - 2023-08-02 15:39:38 --> Helper loaded: security_helper
INFO - 2023-08-02 15:39:38 --> Helper loaded: cookie_helper
INFO - 2023-08-02 15:39:38 --> Database Driver Class Initialized
INFO - 2023-08-02 15:39:38 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-02 15:39:38 --> Parser Class Initialized
INFO - 2023-08-02 15:39:38 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-02 15:39:38 --> Pagination Class Initialized
INFO - 2023-08-02 15:39:38 --> Form Validation Class Initialized
INFO - 2023-08-02 15:39:38 --> Controller Class Initialized
INFO - 2023-08-02 15:39:38 --> Final output sent to browser
DEBUG - 2023-08-02 15:39:38 --> Total execution time: 0.0143
ERROR - 2023-08-02 15:40:43 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-02 15:40:43 --> Config Class Initialized
INFO - 2023-08-02 15:40:43 --> Hooks Class Initialized
DEBUG - 2023-08-02 15:40:43 --> UTF-8 Support Enabled
INFO - 2023-08-02 15:40:43 --> Utf8 Class Initialized
INFO - 2023-08-02 15:40:43 --> URI Class Initialized
DEBUG - 2023-08-02 15:40:43 --> No URI present. Default controller set.
INFO - 2023-08-02 15:40:43 --> Router Class Initialized
INFO - 2023-08-02 15:40:43 --> Output Class Initialized
INFO - 2023-08-02 15:40:43 --> Security Class Initialized
DEBUG - 2023-08-02 15:40:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-02 15:40:43 --> Input Class Initialized
INFO - 2023-08-02 15:40:43 --> Language Class Initialized
INFO - 2023-08-02 15:40:43 --> Loader Class Initialized
INFO - 2023-08-02 15:40:43 --> Helper loaded: url_helper
INFO - 2023-08-02 15:40:43 --> Helper loaded: file_helper
INFO - 2023-08-02 15:40:43 --> Helper loaded: html_helper
INFO - 2023-08-02 15:40:43 --> Helper loaded: text_helper
INFO - 2023-08-02 15:40:43 --> Helper loaded: form_helper
INFO - 2023-08-02 15:40:43 --> Helper loaded: lang_helper
INFO - 2023-08-02 15:40:43 --> Helper loaded: security_helper
INFO - 2023-08-02 15:40:43 --> Helper loaded: cookie_helper
INFO - 2023-08-02 15:40:43 --> Database Driver Class Initialized
INFO - 2023-08-02 15:40:43 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-02 15:40:43 --> Parser Class Initialized
INFO - 2023-08-02 15:40:43 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-02 15:40:43 --> Pagination Class Initialized
INFO - 2023-08-02 15:40:43 --> Form Validation Class Initialized
INFO - 2023-08-02 15:40:43 --> Controller Class Initialized
INFO - 2023-08-02 15:40:43 --> Model Class Initialized
DEBUG - 2023-08-02 15:40:43 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-02 15:40:43 --> Model Class Initialized
DEBUG - 2023-08-02 15:40:43 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-02 15:40:43 --> Model Class Initialized
INFO - 2023-08-02 15:40:43 --> Model Class Initialized
INFO - 2023-08-02 15:40:43 --> Model Class Initialized
INFO - 2023-08-02 15:40:43 --> Model Class Initialized
DEBUG - 2023-08-02 15:40:43 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-02 15:40:43 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-02 15:40:43 --> Model Class Initialized
INFO - 2023-08-02 15:40:43 --> Model Class Initialized
INFO - 2023-08-02 15:40:43 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-08-02 15:40:43 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-08-02 15:40:43 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-08-02 15:40:43 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-08-02 15:40:43 --> Model Class Initialized
INFO - 2023-08-02 15:40:43 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-08-02 15:40:43 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-08-02 15:40:43 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-08-02 15:40:43 --> Final output sent to browser
DEBUG - 2023-08-02 15:40:43 --> Total execution time: 0.0878
ERROR - 2023-08-02 15:40:47 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-02 15:40:47 --> Config Class Initialized
INFO - 2023-08-02 15:40:47 --> Hooks Class Initialized
DEBUG - 2023-08-02 15:40:47 --> UTF-8 Support Enabled
INFO - 2023-08-02 15:40:47 --> Utf8 Class Initialized
INFO - 2023-08-02 15:40:47 --> URI Class Initialized
INFO - 2023-08-02 15:40:47 --> Router Class Initialized
INFO - 2023-08-02 15:40:47 --> Output Class Initialized
INFO - 2023-08-02 15:40:47 --> Security Class Initialized
DEBUG - 2023-08-02 15:40:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-02 15:40:47 --> Input Class Initialized
INFO - 2023-08-02 15:40:47 --> Language Class Initialized
INFO - 2023-08-02 15:40:47 --> Loader Class Initialized
INFO - 2023-08-02 15:40:47 --> Helper loaded: url_helper
INFO - 2023-08-02 15:40:47 --> Helper loaded: file_helper
INFO - 2023-08-02 15:40:47 --> Helper loaded: html_helper
INFO - 2023-08-02 15:40:47 --> Helper loaded: text_helper
INFO - 2023-08-02 15:40:47 --> Helper loaded: form_helper
INFO - 2023-08-02 15:40:47 --> Helper loaded: lang_helper
INFO - 2023-08-02 15:40:47 --> Helper loaded: security_helper
INFO - 2023-08-02 15:40:47 --> Helper loaded: cookie_helper
INFO - 2023-08-02 15:40:47 --> Database Driver Class Initialized
INFO - 2023-08-02 15:40:47 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-02 15:40:47 --> Parser Class Initialized
INFO - 2023-08-02 15:40:47 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-02 15:40:47 --> Pagination Class Initialized
INFO - 2023-08-02 15:40:47 --> Form Validation Class Initialized
INFO - 2023-08-02 15:40:47 --> Controller Class Initialized
INFO - 2023-08-02 15:40:47 --> Model Class Initialized
DEBUG - 2023-08-02 15:40:47 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-02 15:40:47 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-02 15:40:47 --> Model Class Initialized
DEBUG - 2023-08-02 15:40:47 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-02 15:40:47 --> Model Class Initialized
INFO - 2023-08-02 15:40:47 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/add_invoice_form.php
DEBUG - 2023-08-02 15:40:47 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-08-02 15:40:47 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-08-02 15:40:47 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-08-02 15:40:47 --> Model Class Initialized
INFO - 2023-08-02 15:40:47 --> Model Class Initialized
INFO - 2023-08-02 15:40:47 --> Model Class Initialized
INFO - 2023-08-02 15:40:47 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-08-02 15:40:47 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-08-02 15:40:47 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-08-02 15:40:47 --> Final output sent to browser
DEBUG - 2023-08-02 15:40:47 --> Total execution time: 0.0943
ERROR - 2023-08-02 15:40:51 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-02 15:40:51 --> Config Class Initialized
INFO - 2023-08-02 15:40:51 --> Hooks Class Initialized
DEBUG - 2023-08-02 15:40:51 --> UTF-8 Support Enabled
INFO - 2023-08-02 15:40:51 --> Utf8 Class Initialized
INFO - 2023-08-02 15:40:51 --> URI Class Initialized
INFO - 2023-08-02 15:40:51 --> Router Class Initialized
INFO - 2023-08-02 15:40:51 --> Output Class Initialized
INFO - 2023-08-02 15:40:51 --> Security Class Initialized
DEBUG - 2023-08-02 15:40:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-02 15:40:51 --> Input Class Initialized
INFO - 2023-08-02 15:40:51 --> Language Class Initialized
INFO - 2023-08-02 15:40:51 --> Loader Class Initialized
INFO - 2023-08-02 15:40:51 --> Helper loaded: url_helper
INFO - 2023-08-02 15:40:51 --> Helper loaded: file_helper
INFO - 2023-08-02 15:40:51 --> Helper loaded: html_helper
INFO - 2023-08-02 15:40:51 --> Helper loaded: text_helper
INFO - 2023-08-02 15:40:51 --> Helper loaded: form_helper
INFO - 2023-08-02 15:40:51 --> Helper loaded: lang_helper
INFO - 2023-08-02 15:40:51 --> Helper loaded: security_helper
INFO - 2023-08-02 15:40:51 --> Helper loaded: cookie_helper
INFO - 2023-08-02 15:40:51 --> Database Driver Class Initialized
INFO - 2023-08-02 15:40:51 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-02 15:40:51 --> Parser Class Initialized
INFO - 2023-08-02 15:40:51 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-02 15:40:51 --> Pagination Class Initialized
INFO - 2023-08-02 15:40:51 --> Form Validation Class Initialized
INFO - 2023-08-02 15:40:51 --> Controller Class Initialized
INFO - 2023-08-02 15:40:51 --> Model Class Initialized
DEBUG - 2023-08-02 15:40:51 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-02 15:40:51 --> Final output sent to browser
DEBUG - 2023-08-02 15:40:51 --> Total execution time: 0.0158
ERROR - 2023-08-02 15:40:52 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-02 15:40:52 --> Config Class Initialized
INFO - 2023-08-02 15:40:52 --> Hooks Class Initialized
DEBUG - 2023-08-02 15:40:52 --> UTF-8 Support Enabled
INFO - 2023-08-02 15:40:52 --> Utf8 Class Initialized
INFO - 2023-08-02 15:40:52 --> URI Class Initialized
INFO - 2023-08-02 15:40:52 --> Router Class Initialized
INFO - 2023-08-02 15:40:52 --> Output Class Initialized
INFO - 2023-08-02 15:40:52 --> Security Class Initialized
DEBUG - 2023-08-02 15:40:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-02 15:40:52 --> Input Class Initialized
INFO - 2023-08-02 15:40:52 --> Language Class Initialized
INFO - 2023-08-02 15:40:52 --> Loader Class Initialized
INFO - 2023-08-02 15:40:52 --> Helper loaded: url_helper
INFO - 2023-08-02 15:40:52 --> Helper loaded: file_helper
INFO - 2023-08-02 15:40:52 --> Helper loaded: html_helper
INFO - 2023-08-02 15:40:52 --> Helper loaded: text_helper
INFO - 2023-08-02 15:40:52 --> Helper loaded: form_helper
INFO - 2023-08-02 15:40:52 --> Helper loaded: lang_helper
INFO - 2023-08-02 15:40:52 --> Helper loaded: security_helper
INFO - 2023-08-02 15:40:52 --> Helper loaded: cookie_helper
INFO - 2023-08-02 15:40:52 --> Database Driver Class Initialized
INFO - 2023-08-02 15:40:52 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-02 15:40:52 --> Parser Class Initialized
INFO - 2023-08-02 15:40:52 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-02 15:40:52 --> Pagination Class Initialized
INFO - 2023-08-02 15:40:52 --> Form Validation Class Initialized
INFO - 2023-08-02 15:40:52 --> Controller Class Initialized
INFO - 2023-08-02 15:40:52 --> Model Class Initialized
DEBUG - 2023-08-02 15:40:52 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-02 15:40:52 --> Final output sent to browser
DEBUG - 2023-08-02 15:40:52 --> Total execution time: 0.0157
ERROR - 2023-08-02 15:40:53 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-02 15:40:53 --> Config Class Initialized
INFO - 2023-08-02 15:40:53 --> Hooks Class Initialized
DEBUG - 2023-08-02 15:40:53 --> UTF-8 Support Enabled
INFO - 2023-08-02 15:40:53 --> Utf8 Class Initialized
INFO - 2023-08-02 15:40:53 --> URI Class Initialized
INFO - 2023-08-02 15:40:53 --> Router Class Initialized
INFO - 2023-08-02 15:40:53 --> Output Class Initialized
INFO - 2023-08-02 15:40:53 --> Security Class Initialized
DEBUG - 2023-08-02 15:40:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-02 15:40:53 --> Input Class Initialized
INFO - 2023-08-02 15:40:53 --> Language Class Initialized
INFO - 2023-08-02 15:40:53 --> Loader Class Initialized
INFO - 2023-08-02 15:40:53 --> Helper loaded: url_helper
INFO - 2023-08-02 15:40:53 --> Helper loaded: file_helper
INFO - 2023-08-02 15:40:53 --> Helper loaded: html_helper
INFO - 2023-08-02 15:40:53 --> Helper loaded: text_helper
INFO - 2023-08-02 15:40:53 --> Helper loaded: form_helper
INFO - 2023-08-02 15:40:53 --> Helper loaded: lang_helper
INFO - 2023-08-02 15:40:53 --> Helper loaded: security_helper
INFO - 2023-08-02 15:40:53 --> Helper loaded: cookie_helper
INFO - 2023-08-02 15:40:53 --> Database Driver Class Initialized
INFO - 2023-08-02 15:40:53 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-02 15:40:53 --> Parser Class Initialized
INFO - 2023-08-02 15:40:53 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-02 15:40:53 --> Pagination Class Initialized
INFO - 2023-08-02 15:40:53 --> Form Validation Class Initialized
INFO - 2023-08-02 15:40:53 --> Controller Class Initialized
INFO - 2023-08-02 15:40:53 --> Final output sent to browser
DEBUG - 2023-08-02 15:40:53 --> Total execution time: 0.0133
ERROR - 2023-08-02 15:41:02 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-02 15:41:02 --> Config Class Initialized
INFO - 2023-08-02 15:41:02 --> Hooks Class Initialized
DEBUG - 2023-08-02 15:41:02 --> UTF-8 Support Enabled
INFO - 2023-08-02 15:41:02 --> Utf8 Class Initialized
INFO - 2023-08-02 15:41:02 --> URI Class Initialized
INFO - 2023-08-02 15:41:02 --> Router Class Initialized
INFO - 2023-08-02 15:41:02 --> Output Class Initialized
INFO - 2023-08-02 15:41:02 --> Security Class Initialized
DEBUG - 2023-08-02 15:41:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-02 15:41:02 --> Input Class Initialized
INFO - 2023-08-02 15:41:02 --> Language Class Initialized
INFO - 2023-08-02 15:41:02 --> Loader Class Initialized
INFO - 2023-08-02 15:41:02 --> Helper loaded: url_helper
INFO - 2023-08-02 15:41:02 --> Helper loaded: file_helper
INFO - 2023-08-02 15:41:02 --> Helper loaded: html_helper
INFO - 2023-08-02 15:41:02 --> Helper loaded: text_helper
INFO - 2023-08-02 15:41:02 --> Helper loaded: form_helper
INFO - 2023-08-02 15:41:02 --> Helper loaded: lang_helper
INFO - 2023-08-02 15:41:02 --> Helper loaded: security_helper
INFO - 2023-08-02 15:41:02 --> Helper loaded: cookie_helper
INFO - 2023-08-02 15:41:02 --> Database Driver Class Initialized
INFO - 2023-08-02 15:41:02 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-02 15:41:02 --> Parser Class Initialized
INFO - 2023-08-02 15:41:02 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-02 15:41:02 --> Pagination Class Initialized
INFO - 2023-08-02 15:41:02 --> Form Validation Class Initialized
INFO - 2023-08-02 15:41:02 --> Controller Class Initialized
INFO - 2023-08-02 15:41:02 --> Model Class Initialized
DEBUG - 2023-08-02 15:41:02 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-02 15:41:02 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-02 15:41:02 --> Model Class Initialized
DEBUG - 2023-08-02 15:41:02 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-02 15:41:02 --> Model Class Initialized
INFO - 2023-08-02 15:41:02 --> Final output sent to browser
DEBUG - 2023-08-02 15:41:02 --> Total execution time: 0.0466
ERROR - 2023-08-02 15:41:02 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-02 15:41:02 --> Config Class Initialized
INFO - 2023-08-02 15:41:02 --> Hooks Class Initialized
DEBUG - 2023-08-02 15:41:02 --> UTF-8 Support Enabled
INFO - 2023-08-02 15:41:02 --> Utf8 Class Initialized
INFO - 2023-08-02 15:41:02 --> URI Class Initialized
INFO - 2023-08-02 15:41:02 --> Router Class Initialized
INFO - 2023-08-02 15:41:02 --> Output Class Initialized
INFO - 2023-08-02 15:41:02 --> Security Class Initialized
DEBUG - 2023-08-02 15:41:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-02 15:41:02 --> Input Class Initialized
INFO - 2023-08-02 15:41:02 --> Language Class Initialized
INFO - 2023-08-02 15:41:02 --> Loader Class Initialized
INFO - 2023-08-02 15:41:02 --> Helper loaded: url_helper
INFO - 2023-08-02 15:41:02 --> Helper loaded: file_helper
INFO - 2023-08-02 15:41:02 --> Helper loaded: html_helper
INFO - 2023-08-02 15:41:02 --> Helper loaded: text_helper
INFO - 2023-08-02 15:41:02 --> Helper loaded: form_helper
INFO - 2023-08-02 15:41:02 --> Helper loaded: lang_helper
INFO - 2023-08-02 15:41:02 --> Helper loaded: security_helper
INFO - 2023-08-02 15:41:02 --> Helper loaded: cookie_helper
INFO - 2023-08-02 15:41:02 --> Database Driver Class Initialized
INFO - 2023-08-02 15:41:02 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-02 15:41:02 --> Parser Class Initialized
INFO - 2023-08-02 15:41:02 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-02 15:41:02 --> Pagination Class Initialized
INFO - 2023-08-02 15:41:02 --> Form Validation Class Initialized
INFO - 2023-08-02 15:41:02 --> Controller Class Initialized
INFO - 2023-08-02 15:41:02 --> Model Class Initialized
DEBUG - 2023-08-02 15:41:02 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-02 15:41:02 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-02 15:41:02 --> Model Class Initialized
DEBUG - 2023-08-02 15:41:02 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-02 15:41:02 --> Model Class Initialized
INFO - 2023-08-02 15:41:02 --> Final output sent to browser
DEBUG - 2023-08-02 15:41:02 --> Total execution time: 0.0488
ERROR - 2023-08-02 15:41:03 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-02 15:41:03 --> Config Class Initialized
INFO - 2023-08-02 15:41:03 --> Hooks Class Initialized
DEBUG - 2023-08-02 15:41:03 --> UTF-8 Support Enabled
INFO - 2023-08-02 15:41:03 --> Utf8 Class Initialized
INFO - 2023-08-02 15:41:03 --> URI Class Initialized
INFO - 2023-08-02 15:41:03 --> Router Class Initialized
INFO - 2023-08-02 15:41:03 --> Output Class Initialized
INFO - 2023-08-02 15:41:03 --> Security Class Initialized
DEBUG - 2023-08-02 15:41:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-02 15:41:03 --> Input Class Initialized
INFO - 2023-08-02 15:41:03 --> Language Class Initialized
INFO - 2023-08-02 15:41:03 --> Loader Class Initialized
INFO - 2023-08-02 15:41:03 --> Helper loaded: url_helper
INFO - 2023-08-02 15:41:03 --> Helper loaded: file_helper
INFO - 2023-08-02 15:41:03 --> Helper loaded: html_helper
INFO - 2023-08-02 15:41:03 --> Helper loaded: text_helper
INFO - 2023-08-02 15:41:03 --> Helper loaded: form_helper
INFO - 2023-08-02 15:41:03 --> Helper loaded: lang_helper
INFO - 2023-08-02 15:41:03 --> Helper loaded: security_helper
INFO - 2023-08-02 15:41:03 --> Helper loaded: cookie_helper
INFO - 2023-08-02 15:41:03 --> Database Driver Class Initialized
INFO - 2023-08-02 15:41:03 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-02 15:41:03 --> Parser Class Initialized
INFO - 2023-08-02 15:41:03 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-02 15:41:03 --> Pagination Class Initialized
INFO - 2023-08-02 15:41:03 --> Form Validation Class Initialized
INFO - 2023-08-02 15:41:03 --> Controller Class Initialized
INFO - 2023-08-02 15:41:03 --> Model Class Initialized
DEBUG - 2023-08-02 15:41:03 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-02 15:41:03 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-02 15:41:03 --> Model Class Initialized
DEBUG - 2023-08-02 15:41:03 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-02 15:41:03 --> Model Class Initialized
INFO - 2023-08-02 15:41:03 --> Final output sent to browser
DEBUG - 2023-08-02 15:41:03 --> Total execution time: 0.0474
ERROR - 2023-08-02 15:41:13 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-02 15:41:13 --> Config Class Initialized
INFO - 2023-08-02 15:41:13 --> Hooks Class Initialized
DEBUG - 2023-08-02 15:41:13 --> UTF-8 Support Enabled
INFO - 2023-08-02 15:41:13 --> Utf8 Class Initialized
INFO - 2023-08-02 15:41:13 --> URI Class Initialized
INFO - 2023-08-02 15:41:13 --> Router Class Initialized
INFO - 2023-08-02 15:41:13 --> Output Class Initialized
INFO - 2023-08-02 15:41:13 --> Security Class Initialized
DEBUG - 2023-08-02 15:41:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-02 15:41:13 --> Input Class Initialized
INFO - 2023-08-02 15:41:13 --> Language Class Initialized
INFO - 2023-08-02 15:41:13 --> Loader Class Initialized
INFO - 2023-08-02 15:41:13 --> Helper loaded: url_helper
INFO - 2023-08-02 15:41:13 --> Helper loaded: file_helper
INFO - 2023-08-02 15:41:13 --> Helper loaded: html_helper
INFO - 2023-08-02 15:41:13 --> Helper loaded: text_helper
INFO - 2023-08-02 15:41:13 --> Helper loaded: form_helper
INFO - 2023-08-02 15:41:13 --> Helper loaded: lang_helper
INFO - 2023-08-02 15:41:13 --> Helper loaded: security_helper
INFO - 2023-08-02 15:41:13 --> Helper loaded: cookie_helper
INFO - 2023-08-02 15:41:13 --> Database Driver Class Initialized
INFO - 2023-08-02 15:41:13 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-02 15:41:13 --> Parser Class Initialized
INFO - 2023-08-02 15:41:13 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-02 15:41:13 --> Pagination Class Initialized
INFO - 2023-08-02 15:41:13 --> Form Validation Class Initialized
INFO - 2023-08-02 15:41:13 --> Controller Class Initialized
INFO - 2023-08-02 15:41:13 --> Model Class Initialized
DEBUG - 2023-08-02 15:41:13 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-02 15:41:13 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-02 15:41:13 --> Model Class Initialized
INFO - 2023-08-02 15:41:13 --> Model Class Initialized
INFO - 2023-08-02 15:41:13 --> Final output sent to browser
DEBUG - 2023-08-02 15:41:13 --> Total execution time: 0.0186
ERROR - 2023-08-02 15:41:16 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-02 15:41:16 --> Config Class Initialized
INFO - 2023-08-02 15:41:16 --> Hooks Class Initialized
DEBUG - 2023-08-02 15:41:16 --> UTF-8 Support Enabled
INFO - 2023-08-02 15:41:16 --> Utf8 Class Initialized
INFO - 2023-08-02 15:41:16 --> URI Class Initialized
INFO - 2023-08-02 15:41:16 --> Router Class Initialized
INFO - 2023-08-02 15:41:16 --> Output Class Initialized
INFO - 2023-08-02 15:41:16 --> Security Class Initialized
DEBUG - 2023-08-02 15:41:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-02 15:41:16 --> Input Class Initialized
INFO - 2023-08-02 15:41:16 --> Language Class Initialized
INFO - 2023-08-02 15:41:16 --> Loader Class Initialized
INFO - 2023-08-02 15:41:16 --> Helper loaded: url_helper
INFO - 2023-08-02 15:41:16 --> Helper loaded: file_helper
INFO - 2023-08-02 15:41:16 --> Helper loaded: html_helper
INFO - 2023-08-02 15:41:16 --> Helper loaded: text_helper
INFO - 2023-08-02 15:41:16 --> Helper loaded: form_helper
INFO - 2023-08-02 15:41:16 --> Helper loaded: lang_helper
INFO - 2023-08-02 15:41:16 --> Helper loaded: security_helper
INFO - 2023-08-02 15:41:16 --> Helper loaded: cookie_helper
INFO - 2023-08-02 15:41:16 --> Database Driver Class Initialized
INFO - 2023-08-02 15:41:16 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-02 15:41:16 --> Parser Class Initialized
INFO - 2023-08-02 15:41:16 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-02 15:41:16 --> Pagination Class Initialized
INFO - 2023-08-02 15:41:16 --> Form Validation Class Initialized
INFO - 2023-08-02 15:41:16 --> Controller Class Initialized
INFO - 2023-08-02 15:41:16 --> Model Class Initialized
DEBUG - 2023-08-02 15:41:16 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-02 15:41:16 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-02 15:41:16 --> Model Class Initialized
INFO - 2023-08-02 15:41:16 --> Final output sent to browser
DEBUG - 2023-08-02 15:41:16 --> Total execution time: 0.0168
ERROR - 2023-08-02 15:41:33 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-02 15:41:33 --> Config Class Initialized
INFO - 2023-08-02 15:41:33 --> Hooks Class Initialized
DEBUG - 2023-08-02 15:41:33 --> UTF-8 Support Enabled
INFO - 2023-08-02 15:41:33 --> Utf8 Class Initialized
INFO - 2023-08-02 15:41:33 --> URI Class Initialized
INFO - 2023-08-02 15:41:33 --> Router Class Initialized
INFO - 2023-08-02 15:41:33 --> Output Class Initialized
INFO - 2023-08-02 15:41:33 --> Security Class Initialized
DEBUG - 2023-08-02 15:41:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-02 15:41:33 --> Input Class Initialized
INFO - 2023-08-02 15:41:33 --> Language Class Initialized
INFO - 2023-08-02 15:41:33 --> Loader Class Initialized
INFO - 2023-08-02 15:41:33 --> Helper loaded: url_helper
INFO - 2023-08-02 15:41:33 --> Helper loaded: file_helper
INFO - 2023-08-02 15:41:33 --> Helper loaded: html_helper
INFO - 2023-08-02 15:41:33 --> Helper loaded: text_helper
INFO - 2023-08-02 15:41:33 --> Helper loaded: form_helper
INFO - 2023-08-02 15:41:33 --> Helper loaded: lang_helper
INFO - 2023-08-02 15:41:33 --> Helper loaded: security_helper
INFO - 2023-08-02 15:41:33 --> Helper loaded: cookie_helper
INFO - 2023-08-02 15:41:33 --> Database Driver Class Initialized
INFO - 2023-08-02 15:41:33 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-02 15:41:33 --> Parser Class Initialized
INFO - 2023-08-02 15:41:33 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-02 15:41:33 --> Pagination Class Initialized
INFO - 2023-08-02 15:41:33 --> Form Validation Class Initialized
INFO - 2023-08-02 15:41:33 --> Controller Class Initialized
INFO - 2023-08-02 15:41:33 --> Model Class Initialized
DEBUG - 2023-08-02 15:41:33 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-02 15:41:33 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-02 15:41:33 --> Model Class Initialized
DEBUG - 2023-08-02 15:41:33 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-02 15:41:33 --> Model Class Initialized
INFO - 2023-08-02 15:41:33 --> Final output sent to browser
DEBUG - 2023-08-02 15:41:33 --> Total execution time: 0.0511
ERROR - 2023-08-02 15:41:34 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-02 15:41:34 --> Config Class Initialized
INFO - 2023-08-02 15:41:34 --> Hooks Class Initialized
DEBUG - 2023-08-02 15:41:34 --> UTF-8 Support Enabled
INFO - 2023-08-02 15:41:34 --> Utf8 Class Initialized
INFO - 2023-08-02 15:41:34 --> URI Class Initialized
INFO - 2023-08-02 15:41:34 --> Router Class Initialized
INFO - 2023-08-02 15:41:34 --> Output Class Initialized
INFO - 2023-08-02 15:41:34 --> Security Class Initialized
DEBUG - 2023-08-02 15:41:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-02 15:41:34 --> Input Class Initialized
INFO - 2023-08-02 15:41:34 --> Language Class Initialized
INFO - 2023-08-02 15:41:34 --> Loader Class Initialized
INFO - 2023-08-02 15:41:34 --> Helper loaded: url_helper
INFO - 2023-08-02 15:41:34 --> Helper loaded: file_helper
INFO - 2023-08-02 15:41:34 --> Helper loaded: html_helper
INFO - 2023-08-02 15:41:34 --> Helper loaded: text_helper
INFO - 2023-08-02 15:41:34 --> Helper loaded: form_helper
INFO - 2023-08-02 15:41:34 --> Helper loaded: lang_helper
INFO - 2023-08-02 15:41:34 --> Helper loaded: security_helper
INFO - 2023-08-02 15:41:34 --> Helper loaded: cookie_helper
INFO - 2023-08-02 15:41:34 --> Database Driver Class Initialized
INFO - 2023-08-02 15:41:34 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-02 15:41:34 --> Parser Class Initialized
INFO - 2023-08-02 15:41:34 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-02 15:41:34 --> Pagination Class Initialized
INFO - 2023-08-02 15:41:34 --> Form Validation Class Initialized
INFO - 2023-08-02 15:41:34 --> Controller Class Initialized
INFO - 2023-08-02 15:41:34 --> Model Class Initialized
DEBUG - 2023-08-02 15:41:34 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-02 15:41:34 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-02 15:41:34 --> Model Class Initialized
DEBUG - 2023-08-02 15:41:34 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-02 15:41:34 --> Model Class Initialized
INFO - 2023-08-02 15:41:34 --> Final output sent to browser
DEBUG - 2023-08-02 15:41:34 --> Total execution time: 0.0493
ERROR - 2023-08-02 15:41:34 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-02 15:41:34 --> Config Class Initialized
INFO - 2023-08-02 15:41:34 --> Hooks Class Initialized
DEBUG - 2023-08-02 15:41:34 --> UTF-8 Support Enabled
INFO - 2023-08-02 15:41:34 --> Utf8 Class Initialized
INFO - 2023-08-02 15:41:34 --> URI Class Initialized
INFO - 2023-08-02 15:41:34 --> Router Class Initialized
INFO - 2023-08-02 15:41:34 --> Output Class Initialized
INFO - 2023-08-02 15:41:34 --> Security Class Initialized
DEBUG - 2023-08-02 15:41:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-02 15:41:34 --> Input Class Initialized
INFO - 2023-08-02 15:41:34 --> Language Class Initialized
INFO - 2023-08-02 15:41:34 --> Loader Class Initialized
INFO - 2023-08-02 15:41:34 --> Helper loaded: url_helper
INFO - 2023-08-02 15:41:34 --> Helper loaded: file_helper
INFO - 2023-08-02 15:41:34 --> Helper loaded: html_helper
INFO - 2023-08-02 15:41:34 --> Helper loaded: text_helper
INFO - 2023-08-02 15:41:34 --> Helper loaded: form_helper
INFO - 2023-08-02 15:41:34 --> Helper loaded: lang_helper
INFO - 2023-08-02 15:41:34 --> Helper loaded: security_helper
INFO - 2023-08-02 15:41:34 --> Helper loaded: cookie_helper
INFO - 2023-08-02 15:41:34 --> Database Driver Class Initialized
INFO - 2023-08-02 15:41:34 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-02 15:41:34 --> Parser Class Initialized
INFO - 2023-08-02 15:41:34 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-02 15:41:34 --> Pagination Class Initialized
INFO - 2023-08-02 15:41:34 --> Form Validation Class Initialized
INFO - 2023-08-02 15:41:34 --> Controller Class Initialized
INFO - 2023-08-02 15:41:34 --> Model Class Initialized
DEBUG - 2023-08-02 15:41:34 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-02 15:41:34 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-02 15:41:34 --> Model Class Initialized
DEBUG - 2023-08-02 15:41:34 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-02 15:41:34 --> Model Class Initialized
INFO - 2023-08-02 15:41:34 --> Final output sent to browser
DEBUG - 2023-08-02 15:41:34 --> Total execution time: 0.0489
ERROR - 2023-08-02 15:41:36 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-02 15:41:36 --> Config Class Initialized
INFO - 2023-08-02 15:41:36 --> Hooks Class Initialized
DEBUG - 2023-08-02 15:41:36 --> UTF-8 Support Enabled
INFO - 2023-08-02 15:41:36 --> Utf8 Class Initialized
INFO - 2023-08-02 15:41:36 --> URI Class Initialized
INFO - 2023-08-02 15:41:36 --> Router Class Initialized
INFO - 2023-08-02 15:41:36 --> Output Class Initialized
INFO - 2023-08-02 15:41:36 --> Security Class Initialized
DEBUG - 2023-08-02 15:41:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-02 15:41:36 --> Input Class Initialized
INFO - 2023-08-02 15:41:36 --> Language Class Initialized
INFO - 2023-08-02 15:41:36 --> Loader Class Initialized
INFO - 2023-08-02 15:41:36 --> Helper loaded: url_helper
INFO - 2023-08-02 15:41:36 --> Helper loaded: file_helper
INFO - 2023-08-02 15:41:36 --> Helper loaded: html_helper
INFO - 2023-08-02 15:41:36 --> Helper loaded: text_helper
INFO - 2023-08-02 15:41:36 --> Helper loaded: form_helper
INFO - 2023-08-02 15:41:36 --> Helper loaded: lang_helper
INFO - 2023-08-02 15:41:36 --> Helper loaded: security_helper
INFO - 2023-08-02 15:41:36 --> Helper loaded: cookie_helper
INFO - 2023-08-02 15:41:36 --> Database Driver Class Initialized
INFO - 2023-08-02 15:41:36 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-02 15:41:36 --> Parser Class Initialized
INFO - 2023-08-02 15:41:36 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-02 15:41:36 --> Pagination Class Initialized
INFO - 2023-08-02 15:41:36 --> Form Validation Class Initialized
INFO - 2023-08-02 15:41:36 --> Controller Class Initialized
INFO - 2023-08-02 15:41:36 --> Model Class Initialized
DEBUG - 2023-08-02 15:41:36 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-02 15:41:36 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-02 15:41:36 --> Model Class Initialized
DEBUG - 2023-08-02 15:41:36 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-02 15:41:36 --> Model Class Initialized
INFO - 2023-08-02 15:41:36 --> Final output sent to browser
DEBUG - 2023-08-02 15:41:36 --> Total execution time: 0.0207
ERROR - 2023-08-02 15:41:36 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-02 15:41:36 --> Config Class Initialized
INFO - 2023-08-02 15:41:36 --> Hooks Class Initialized
DEBUG - 2023-08-02 15:41:36 --> UTF-8 Support Enabled
INFO - 2023-08-02 15:41:36 --> Utf8 Class Initialized
INFO - 2023-08-02 15:41:36 --> URI Class Initialized
INFO - 2023-08-02 15:41:36 --> Router Class Initialized
INFO - 2023-08-02 15:41:36 --> Output Class Initialized
INFO - 2023-08-02 15:41:36 --> Security Class Initialized
DEBUG - 2023-08-02 15:41:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-02 15:41:36 --> Input Class Initialized
INFO - 2023-08-02 15:41:36 --> Language Class Initialized
INFO - 2023-08-02 15:41:36 --> Loader Class Initialized
INFO - 2023-08-02 15:41:36 --> Helper loaded: url_helper
INFO - 2023-08-02 15:41:36 --> Helper loaded: file_helper
INFO - 2023-08-02 15:41:36 --> Helper loaded: html_helper
INFO - 2023-08-02 15:41:36 --> Helper loaded: text_helper
INFO - 2023-08-02 15:41:36 --> Helper loaded: form_helper
INFO - 2023-08-02 15:41:36 --> Helper loaded: lang_helper
INFO - 2023-08-02 15:41:36 --> Helper loaded: security_helper
INFO - 2023-08-02 15:41:36 --> Helper loaded: cookie_helper
INFO - 2023-08-02 15:41:36 --> Database Driver Class Initialized
INFO - 2023-08-02 15:41:36 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-02 15:41:36 --> Parser Class Initialized
INFO - 2023-08-02 15:41:36 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-02 15:41:36 --> Pagination Class Initialized
INFO - 2023-08-02 15:41:36 --> Form Validation Class Initialized
INFO - 2023-08-02 15:41:36 --> Controller Class Initialized
INFO - 2023-08-02 15:41:36 --> Model Class Initialized
DEBUG - 2023-08-02 15:41:36 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-02 15:41:36 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-02 15:41:36 --> Model Class Initialized
DEBUG - 2023-08-02 15:41:36 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-02 15:41:36 --> Model Class Initialized
INFO - 2023-08-02 15:41:36 --> Final output sent to browser
DEBUG - 2023-08-02 15:41:36 --> Total execution time: 0.0183
ERROR - 2023-08-02 15:41:37 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-02 15:41:37 --> Config Class Initialized
INFO - 2023-08-02 15:41:37 --> Hooks Class Initialized
DEBUG - 2023-08-02 15:41:37 --> UTF-8 Support Enabled
INFO - 2023-08-02 15:41:37 --> Utf8 Class Initialized
INFO - 2023-08-02 15:41:37 --> URI Class Initialized
INFO - 2023-08-02 15:41:37 --> Router Class Initialized
INFO - 2023-08-02 15:41:37 --> Output Class Initialized
INFO - 2023-08-02 15:41:37 --> Security Class Initialized
DEBUG - 2023-08-02 15:41:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-02 15:41:37 --> Input Class Initialized
INFO - 2023-08-02 15:41:37 --> Language Class Initialized
INFO - 2023-08-02 15:41:37 --> Loader Class Initialized
INFO - 2023-08-02 15:41:37 --> Helper loaded: url_helper
INFO - 2023-08-02 15:41:37 --> Helper loaded: file_helper
INFO - 2023-08-02 15:41:37 --> Helper loaded: html_helper
INFO - 2023-08-02 15:41:37 --> Helper loaded: text_helper
INFO - 2023-08-02 15:41:37 --> Helper loaded: form_helper
INFO - 2023-08-02 15:41:37 --> Helper loaded: lang_helper
INFO - 2023-08-02 15:41:37 --> Helper loaded: security_helper
INFO - 2023-08-02 15:41:37 --> Helper loaded: cookie_helper
INFO - 2023-08-02 15:41:37 --> Database Driver Class Initialized
INFO - 2023-08-02 15:41:37 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-02 15:41:37 --> Parser Class Initialized
INFO - 2023-08-02 15:41:37 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-02 15:41:37 --> Pagination Class Initialized
INFO - 2023-08-02 15:41:37 --> Form Validation Class Initialized
INFO - 2023-08-02 15:41:37 --> Controller Class Initialized
INFO - 2023-08-02 15:41:37 --> Model Class Initialized
DEBUG - 2023-08-02 15:41:37 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-02 15:41:37 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-02 15:41:37 --> Model Class Initialized
DEBUG - 2023-08-02 15:41:37 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-02 15:41:37 --> Model Class Initialized
INFO - 2023-08-02 15:41:37 --> Final output sent to browser
DEBUG - 2023-08-02 15:41:37 --> Total execution time: 0.0476
ERROR - 2023-08-02 15:41:38 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-02 15:41:38 --> Config Class Initialized
INFO - 2023-08-02 15:41:38 --> Hooks Class Initialized
DEBUG - 2023-08-02 15:41:38 --> UTF-8 Support Enabled
INFO - 2023-08-02 15:41:38 --> Utf8 Class Initialized
INFO - 2023-08-02 15:41:38 --> URI Class Initialized
INFO - 2023-08-02 15:41:38 --> Router Class Initialized
INFO - 2023-08-02 15:41:38 --> Output Class Initialized
INFO - 2023-08-02 15:41:38 --> Security Class Initialized
DEBUG - 2023-08-02 15:41:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-02 15:41:38 --> Input Class Initialized
INFO - 2023-08-02 15:41:38 --> Language Class Initialized
INFO - 2023-08-02 15:41:38 --> Loader Class Initialized
INFO - 2023-08-02 15:41:38 --> Helper loaded: url_helper
INFO - 2023-08-02 15:41:38 --> Helper loaded: file_helper
INFO - 2023-08-02 15:41:38 --> Helper loaded: html_helper
INFO - 2023-08-02 15:41:38 --> Helper loaded: text_helper
INFO - 2023-08-02 15:41:38 --> Helper loaded: form_helper
INFO - 2023-08-02 15:41:38 --> Helper loaded: lang_helper
INFO - 2023-08-02 15:41:38 --> Helper loaded: security_helper
INFO - 2023-08-02 15:41:38 --> Helper loaded: cookie_helper
INFO - 2023-08-02 15:41:38 --> Database Driver Class Initialized
INFO - 2023-08-02 15:41:38 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-02 15:41:38 --> Parser Class Initialized
INFO - 2023-08-02 15:41:38 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-02 15:41:38 --> Pagination Class Initialized
INFO - 2023-08-02 15:41:38 --> Form Validation Class Initialized
INFO - 2023-08-02 15:41:38 --> Controller Class Initialized
INFO - 2023-08-02 15:41:38 --> Model Class Initialized
DEBUG - 2023-08-02 15:41:38 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-02 15:41:38 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-02 15:41:38 --> Model Class Initialized
DEBUG - 2023-08-02 15:41:38 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-02 15:41:38 --> Model Class Initialized
INFO - 2023-08-02 15:41:38 --> Final output sent to browser
DEBUG - 2023-08-02 15:41:38 --> Total execution time: 0.0310
ERROR - 2023-08-02 15:41:39 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-02 15:41:39 --> Config Class Initialized
INFO - 2023-08-02 15:41:39 --> Hooks Class Initialized
DEBUG - 2023-08-02 15:41:39 --> UTF-8 Support Enabled
INFO - 2023-08-02 15:41:39 --> Utf8 Class Initialized
INFO - 2023-08-02 15:41:39 --> URI Class Initialized
INFO - 2023-08-02 15:41:39 --> Router Class Initialized
INFO - 2023-08-02 15:41:39 --> Output Class Initialized
INFO - 2023-08-02 15:41:39 --> Security Class Initialized
DEBUG - 2023-08-02 15:41:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-02 15:41:39 --> Input Class Initialized
INFO - 2023-08-02 15:41:39 --> Language Class Initialized
INFO - 2023-08-02 15:41:39 --> Loader Class Initialized
INFO - 2023-08-02 15:41:39 --> Helper loaded: url_helper
INFO - 2023-08-02 15:41:39 --> Helper loaded: file_helper
INFO - 2023-08-02 15:41:39 --> Helper loaded: html_helper
INFO - 2023-08-02 15:41:39 --> Helper loaded: text_helper
INFO - 2023-08-02 15:41:39 --> Helper loaded: form_helper
INFO - 2023-08-02 15:41:39 --> Helper loaded: lang_helper
INFO - 2023-08-02 15:41:39 --> Helper loaded: security_helper
INFO - 2023-08-02 15:41:39 --> Helper loaded: cookie_helper
INFO - 2023-08-02 15:41:39 --> Database Driver Class Initialized
INFO - 2023-08-02 15:41:39 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-02 15:41:39 --> Parser Class Initialized
INFO - 2023-08-02 15:41:39 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-02 15:41:39 --> Pagination Class Initialized
INFO - 2023-08-02 15:41:39 --> Form Validation Class Initialized
INFO - 2023-08-02 15:41:39 --> Controller Class Initialized
INFO - 2023-08-02 15:41:39 --> Model Class Initialized
DEBUG - 2023-08-02 15:41:39 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-02 15:41:39 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-02 15:41:39 --> Model Class Initialized
DEBUG - 2023-08-02 15:41:39 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-02 15:41:39 --> Model Class Initialized
INFO - 2023-08-02 15:41:39 --> Final output sent to browser
DEBUG - 2023-08-02 15:41:39 --> Total execution time: 0.0213
ERROR - 2023-08-02 15:41:40 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-02 15:41:40 --> Config Class Initialized
INFO - 2023-08-02 15:41:40 --> Hooks Class Initialized
DEBUG - 2023-08-02 15:41:40 --> UTF-8 Support Enabled
INFO - 2023-08-02 15:41:40 --> Utf8 Class Initialized
INFO - 2023-08-02 15:41:40 --> URI Class Initialized
INFO - 2023-08-02 15:41:40 --> Router Class Initialized
INFO - 2023-08-02 15:41:40 --> Output Class Initialized
INFO - 2023-08-02 15:41:40 --> Security Class Initialized
DEBUG - 2023-08-02 15:41:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-02 15:41:40 --> Input Class Initialized
INFO - 2023-08-02 15:41:40 --> Language Class Initialized
INFO - 2023-08-02 15:41:40 --> Loader Class Initialized
INFO - 2023-08-02 15:41:40 --> Helper loaded: url_helper
INFO - 2023-08-02 15:41:40 --> Helper loaded: file_helper
INFO - 2023-08-02 15:41:40 --> Helper loaded: html_helper
INFO - 2023-08-02 15:41:40 --> Helper loaded: text_helper
INFO - 2023-08-02 15:41:40 --> Helper loaded: form_helper
INFO - 2023-08-02 15:41:40 --> Helper loaded: lang_helper
INFO - 2023-08-02 15:41:40 --> Helper loaded: security_helper
INFO - 2023-08-02 15:41:40 --> Helper loaded: cookie_helper
INFO - 2023-08-02 15:41:40 --> Database Driver Class Initialized
INFO - 2023-08-02 15:41:40 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-02 15:41:40 --> Parser Class Initialized
INFO - 2023-08-02 15:41:40 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-02 15:41:40 --> Pagination Class Initialized
INFO - 2023-08-02 15:41:40 --> Form Validation Class Initialized
INFO - 2023-08-02 15:41:40 --> Controller Class Initialized
INFO - 2023-08-02 15:41:40 --> Model Class Initialized
DEBUG - 2023-08-02 15:41:40 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-02 15:41:40 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-02 15:41:40 --> Model Class Initialized
DEBUG - 2023-08-02 15:41:40 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-02 15:41:40 --> Model Class Initialized
INFO - 2023-08-02 15:41:40 --> Final output sent to browser
DEBUG - 2023-08-02 15:41:40 --> Total execution time: 0.0223
ERROR - 2023-08-02 15:41:41 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-02 15:41:41 --> Config Class Initialized
INFO - 2023-08-02 15:41:41 --> Hooks Class Initialized
DEBUG - 2023-08-02 15:41:41 --> UTF-8 Support Enabled
INFO - 2023-08-02 15:41:41 --> Utf8 Class Initialized
INFO - 2023-08-02 15:41:41 --> URI Class Initialized
INFO - 2023-08-02 15:41:41 --> Router Class Initialized
INFO - 2023-08-02 15:41:41 --> Output Class Initialized
INFO - 2023-08-02 15:41:41 --> Security Class Initialized
DEBUG - 2023-08-02 15:41:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-02 15:41:41 --> Input Class Initialized
INFO - 2023-08-02 15:41:41 --> Language Class Initialized
INFO - 2023-08-02 15:41:41 --> Loader Class Initialized
INFO - 2023-08-02 15:41:41 --> Helper loaded: url_helper
INFO - 2023-08-02 15:41:41 --> Helper loaded: file_helper
INFO - 2023-08-02 15:41:41 --> Helper loaded: html_helper
INFO - 2023-08-02 15:41:41 --> Helper loaded: text_helper
INFO - 2023-08-02 15:41:41 --> Helper loaded: form_helper
INFO - 2023-08-02 15:41:41 --> Helper loaded: lang_helper
INFO - 2023-08-02 15:41:41 --> Helper loaded: security_helper
INFO - 2023-08-02 15:41:41 --> Helper loaded: cookie_helper
INFO - 2023-08-02 15:41:41 --> Database Driver Class Initialized
INFO - 2023-08-02 15:41:41 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-02 15:41:41 --> Parser Class Initialized
INFO - 2023-08-02 15:41:41 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-02 15:41:41 --> Pagination Class Initialized
INFO - 2023-08-02 15:41:41 --> Form Validation Class Initialized
INFO - 2023-08-02 15:41:41 --> Controller Class Initialized
INFO - 2023-08-02 15:41:41 --> Model Class Initialized
DEBUG - 2023-08-02 15:41:41 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-02 15:41:41 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-02 15:41:41 --> Model Class Initialized
INFO - 2023-08-02 15:41:41 --> Model Class Initialized
INFO - 2023-08-02 15:41:41 --> Final output sent to browser
DEBUG - 2023-08-02 15:41:41 --> Total execution time: 0.0191
ERROR - 2023-08-02 15:41:48 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-02 15:41:48 --> Config Class Initialized
INFO - 2023-08-02 15:41:48 --> Hooks Class Initialized
DEBUG - 2023-08-02 15:41:48 --> UTF-8 Support Enabled
INFO - 2023-08-02 15:41:48 --> Utf8 Class Initialized
INFO - 2023-08-02 15:41:48 --> URI Class Initialized
INFO - 2023-08-02 15:41:48 --> Router Class Initialized
INFO - 2023-08-02 15:41:48 --> Output Class Initialized
INFO - 2023-08-02 15:41:48 --> Security Class Initialized
DEBUG - 2023-08-02 15:41:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-02 15:41:48 --> Input Class Initialized
INFO - 2023-08-02 15:41:48 --> Language Class Initialized
INFO - 2023-08-02 15:41:48 --> Loader Class Initialized
INFO - 2023-08-02 15:41:48 --> Helper loaded: url_helper
INFO - 2023-08-02 15:41:48 --> Helper loaded: file_helper
INFO - 2023-08-02 15:41:48 --> Helper loaded: html_helper
INFO - 2023-08-02 15:41:48 --> Helper loaded: text_helper
INFO - 2023-08-02 15:41:48 --> Helper loaded: form_helper
INFO - 2023-08-02 15:41:48 --> Helper loaded: lang_helper
INFO - 2023-08-02 15:41:48 --> Helper loaded: security_helper
INFO - 2023-08-02 15:41:48 --> Helper loaded: cookie_helper
INFO - 2023-08-02 15:41:48 --> Database Driver Class Initialized
INFO - 2023-08-02 15:41:48 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-02 15:41:48 --> Parser Class Initialized
INFO - 2023-08-02 15:41:48 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-02 15:41:48 --> Pagination Class Initialized
INFO - 2023-08-02 15:41:48 --> Form Validation Class Initialized
INFO - 2023-08-02 15:41:48 --> Controller Class Initialized
INFO - 2023-08-02 15:41:48 --> Model Class Initialized
DEBUG - 2023-08-02 15:41:48 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-02 15:41:48 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-02 15:41:48 --> Model Class Initialized
DEBUG - 2023-08-02 15:41:48 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-02 15:41:48 --> Model Class Initialized
INFO - 2023-08-02 15:41:48 --> Final output sent to browser
DEBUG - 2023-08-02 15:41:48 --> Total execution time: 0.0489
ERROR - 2023-08-02 15:41:48 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-02 15:41:48 --> Config Class Initialized
INFO - 2023-08-02 15:41:48 --> Hooks Class Initialized
DEBUG - 2023-08-02 15:41:48 --> UTF-8 Support Enabled
INFO - 2023-08-02 15:41:48 --> Utf8 Class Initialized
INFO - 2023-08-02 15:41:48 --> URI Class Initialized
INFO - 2023-08-02 15:41:48 --> Router Class Initialized
INFO - 2023-08-02 15:41:48 --> Output Class Initialized
INFO - 2023-08-02 15:41:48 --> Security Class Initialized
DEBUG - 2023-08-02 15:41:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-02 15:41:48 --> Input Class Initialized
INFO - 2023-08-02 15:41:48 --> Language Class Initialized
INFO - 2023-08-02 15:41:48 --> Loader Class Initialized
INFO - 2023-08-02 15:41:48 --> Helper loaded: url_helper
INFO - 2023-08-02 15:41:48 --> Helper loaded: file_helper
INFO - 2023-08-02 15:41:48 --> Helper loaded: html_helper
INFO - 2023-08-02 15:41:48 --> Helper loaded: text_helper
INFO - 2023-08-02 15:41:48 --> Helper loaded: form_helper
INFO - 2023-08-02 15:41:48 --> Helper loaded: lang_helper
INFO - 2023-08-02 15:41:48 --> Helper loaded: security_helper
INFO - 2023-08-02 15:41:48 --> Helper loaded: cookie_helper
INFO - 2023-08-02 15:41:48 --> Database Driver Class Initialized
INFO - 2023-08-02 15:41:48 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-02 15:41:48 --> Parser Class Initialized
INFO - 2023-08-02 15:41:48 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-02 15:41:48 --> Pagination Class Initialized
INFO - 2023-08-02 15:41:48 --> Form Validation Class Initialized
INFO - 2023-08-02 15:41:48 --> Controller Class Initialized
INFO - 2023-08-02 15:41:48 --> Model Class Initialized
DEBUG - 2023-08-02 15:41:48 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-02 15:41:48 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-02 15:41:48 --> Model Class Initialized
DEBUG - 2023-08-02 15:41:48 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-02 15:41:48 --> Model Class Initialized
INFO - 2023-08-02 15:41:48 --> Final output sent to browser
DEBUG - 2023-08-02 15:41:48 --> Total execution time: 0.0525
ERROR - 2023-08-02 15:41:49 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-02 15:41:49 --> Config Class Initialized
INFO - 2023-08-02 15:41:49 --> Hooks Class Initialized
DEBUG - 2023-08-02 15:41:49 --> UTF-8 Support Enabled
INFO - 2023-08-02 15:41:49 --> Utf8 Class Initialized
INFO - 2023-08-02 15:41:49 --> URI Class Initialized
INFO - 2023-08-02 15:41:49 --> Router Class Initialized
INFO - 2023-08-02 15:41:49 --> Output Class Initialized
INFO - 2023-08-02 15:41:49 --> Security Class Initialized
DEBUG - 2023-08-02 15:41:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-02 15:41:49 --> Input Class Initialized
INFO - 2023-08-02 15:41:49 --> Language Class Initialized
INFO - 2023-08-02 15:41:49 --> Loader Class Initialized
INFO - 2023-08-02 15:41:49 --> Helper loaded: url_helper
INFO - 2023-08-02 15:41:49 --> Helper loaded: file_helper
INFO - 2023-08-02 15:41:49 --> Helper loaded: html_helper
INFO - 2023-08-02 15:41:49 --> Helper loaded: text_helper
INFO - 2023-08-02 15:41:49 --> Helper loaded: form_helper
INFO - 2023-08-02 15:41:49 --> Helper loaded: lang_helper
INFO - 2023-08-02 15:41:49 --> Helper loaded: security_helper
INFO - 2023-08-02 15:41:49 --> Helper loaded: cookie_helper
INFO - 2023-08-02 15:41:49 --> Database Driver Class Initialized
INFO - 2023-08-02 15:41:49 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-02 15:41:49 --> Parser Class Initialized
INFO - 2023-08-02 15:41:49 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-02 15:41:49 --> Pagination Class Initialized
INFO - 2023-08-02 15:41:49 --> Form Validation Class Initialized
INFO - 2023-08-02 15:41:49 --> Controller Class Initialized
INFO - 2023-08-02 15:41:49 --> Model Class Initialized
DEBUG - 2023-08-02 15:41:49 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-02 15:41:49 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-02 15:41:49 --> Model Class Initialized
DEBUG - 2023-08-02 15:41:49 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-02 15:41:49 --> Model Class Initialized
INFO - 2023-08-02 15:41:49 --> Final output sent to browser
DEBUG - 2023-08-02 15:41:49 --> Total execution time: 0.0482
ERROR - 2023-08-02 15:41:50 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-02 15:41:50 --> Config Class Initialized
INFO - 2023-08-02 15:41:50 --> Hooks Class Initialized
DEBUG - 2023-08-02 15:41:50 --> UTF-8 Support Enabled
INFO - 2023-08-02 15:41:50 --> Utf8 Class Initialized
INFO - 2023-08-02 15:41:50 --> URI Class Initialized
INFO - 2023-08-02 15:41:50 --> Router Class Initialized
INFO - 2023-08-02 15:41:50 --> Output Class Initialized
INFO - 2023-08-02 15:41:50 --> Security Class Initialized
DEBUG - 2023-08-02 15:41:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-02 15:41:50 --> Input Class Initialized
INFO - 2023-08-02 15:41:50 --> Language Class Initialized
INFO - 2023-08-02 15:41:50 --> Loader Class Initialized
INFO - 2023-08-02 15:41:50 --> Helper loaded: url_helper
INFO - 2023-08-02 15:41:50 --> Helper loaded: file_helper
INFO - 2023-08-02 15:41:50 --> Helper loaded: html_helper
INFO - 2023-08-02 15:41:50 --> Helper loaded: text_helper
INFO - 2023-08-02 15:41:50 --> Helper loaded: form_helper
INFO - 2023-08-02 15:41:50 --> Helper loaded: lang_helper
INFO - 2023-08-02 15:41:50 --> Helper loaded: security_helper
INFO - 2023-08-02 15:41:50 --> Helper loaded: cookie_helper
INFO - 2023-08-02 15:41:50 --> Database Driver Class Initialized
INFO - 2023-08-02 15:41:50 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-02 15:41:50 --> Parser Class Initialized
INFO - 2023-08-02 15:41:50 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-02 15:41:50 --> Pagination Class Initialized
INFO - 2023-08-02 15:41:50 --> Form Validation Class Initialized
INFO - 2023-08-02 15:41:50 --> Controller Class Initialized
INFO - 2023-08-02 15:41:50 --> Model Class Initialized
DEBUG - 2023-08-02 15:41:50 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-02 15:41:50 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-02 15:41:50 --> Model Class Initialized
DEBUG - 2023-08-02 15:41:50 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-02 15:41:50 --> Model Class Initialized
INFO - 2023-08-02 15:41:50 --> Final output sent to browser
DEBUG - 2023-08-02 15:41:50 --> Total execution time: 0.0274
ERROR - 2023-08-02 15:41:51 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-02 15:41:51 --> Config Class Initialized
INFO - 2023-08-02 15:41:51 --> Hooks Class Initialized
DEBUG - 2023-08-02 15:41:51 --> UTF-8 Support Enabled
INFO - 2023-08-02 15:41:51 --> Utf8 Class Initialized
INFO - 2023-08-02 15:41:51 --> URI Class Initialized
INFO - 2023-08-02 15:41:51 --> Router Class Initialized
INFO - 2023-08-02 15:41:51 --> Output Class Initialized
INFO - 2023-08-02 15:41:51 --> Security Class Initialized
DEBUG - 2023-08-02 15:41:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-02 15:41:51 --> Input Class Initialized
INFO - 2023-08-02 15:41:51 --> Language Class Initialized
INFO - 2023-08-02 15:41:51 --> Loader Class Initialized
INFO - 2023-08-02 15:41:51 --> Helper loaded: url_helper
INFO - 2023-08-02 15:41:51 --> Helper loaded: file_helper
INFO - 2023-08-02 15:41:51 --> Helper loaded: html_helper
INFO - 2023-08-02 15:41:51 --> Helper loaded: text_helper
INFO - 2023-08-02 15:41:51 --> Helper loaded: form_helper
INFO - 2023-08-02 15:41:51 --> Helper loaded: lang_helper
INFO - 2023-08-02 15:41:51 --> Helper loaded: security_helper
INFO - 2023-08-02 15:41:51 --> Helper loaded: cookie_helper
INFO - 2023-08-02 15:41:51 --> Database Driver Class Initialized
INFO - 2023-08-02 15:41:51 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-02 15:41:51 --> Parser Class Initialized
INFO - 2023-08-02 15:41:51 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-02 15:41:51 --> Pagination Class Initialized
INFO - 2023-08-02 15:41:51 --> Form Validation Class Initialized
INFO - 2023-08-02 15:41:51 --> Controller Class Initialized
INFO - 2023-08-02 15:41:51 --> Model Class Initialized
DEBUG - 2023-08-02 15:41:51 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-02 15:41:51 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-02 15:41:51 --> Model Class Initialized
DEBUG - 2023-08-02 15:41:51 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-02 15:41:51 --> Model Class Initialized
INFO - 2023-08-02 15:41:51 --> Final output sent to browser
DEBUG - 2023-08-02 15:41:51 --> Total execution time: 0.0195
ERROR - 2023-08-02 15:41:52 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-02 15:41:52 --> Config Class Initialized
INFO - 2023-08-02 15:41:52 --> Hooks Class Initialized
DEBUG - 2023-08-02 15:41:52 --> UTF-8 Support Enabled
INFO - 2023-08-02 15:41:52 --> Utf8 Class Initialized
INFO - 2023-08-02 15:41:52 --> URI Class Initialized
INFO - 2023-08-02 15:41:52 --> Router Class Initialized
INFO - 2023-08-02 15:41:52 --> Output Class Initialized
INFO - 2023-08-02 15:41:52 --> Security Class Initialized
DEBUG - 2023-08-02 15:41:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-02 15:41:52 --> Input Class Initialized
INFO - 2023-08-02 15:41:52 --> Language Class Initialized
INFO - 2023-08-02 15:41:52 --> Loader Class Initialized
INFO - 2023-08-02 15:41:52 --> Helper loaded: url_helper
INFO - 2023-08-02 15:41:52 --> Helper loaded: file_helper
INFO - 2023-08-02 15:41:52 --> Helper loaded: html_helper
INFO - 2023-08-02 15:41:52 --> Helper loaded: text_helper
INFO - 2023-08-02 15:41:52 --> Helper loaded: form_helper
INFO - 2023-08-02 15:41:52 --> Helper loaded: lang_helper
INFO - 2023-08-02 15:41:52 --> Helper loaded: security_helper
INFO - 2023-08-02 15:41:52 --> Helper loaded: cookie_helper
INFO - 2023-08-02 15:41:52 --> Database Driver Class Initialized
INFO - 2023-08-02 15:41:52 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-02 15:41:52 --> Parser Class Initialized
INFO - 2023-08-02 15:41:52 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-02 15:41:52 --> Pagination Class Initialized
INFO - 2023-08-02 15:41:52 --> Form Validation Class Initialized
INFO - 2023-08-02 15:41:52 --> Controller Class Initialized
INFO - 2023-08-02 15:41:52 --> Model Class Initialized
DEBUG - 2023-08-02 15:41:52 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-02 15:41:52 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-02 15:41:52 --> Model Class Initialized
INFO - 2023-08-02 15:41:52 --> Model Class Initialized
INFO - 2023-08-02 15:41:52 --> Final output sent to browser
DEBUG - 2023-08-02 15:41:52 --> Total execution time: 0.0190
ERROR - 2023-08-02 15:42:05 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-02 15:42:05 --> Config Class Initialized
INFO - 2023-08-02 15:42:05 --> Hooks Class Initialized
DEBUG - 2023-08-02 15:42:05 --> UTF-8 Support Enabled
INFO - 2023-08-02 15:42:05 --> Utf8 Class Initialized
INFO - 2023-08-02 15:42:05 --> URI Class Initialized
INFO - 2023-08-02 15:42:05 --> Router Class Initialized
INFO - 2023-08-02 15:42:05 --> Output Class Initialized
INFO - 2023-08-02 15:42:05 --> Security Class Initialized
DEBUG - 2023-08-02 15:42:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-02 15:42:05 --> Input Class Initialized
INFO - 2023-08-02 15:42:05 --> Language Class Initialized
INFO - 2023-08-02 15:42:05 --> Loader Class Initialized
INFO - 2023-08-02 15:42:05 --> Helper loaded: url_helper
INFO - 2023-08-02 15:42:05 --> Helper loaded: file_helper
INFO - 2023-08-02 15:42:05 --> Helper loaded: html_helper
INFO - 2023-08-02 15:42:05 --> Helper loaded: text_helper
INFO - 2023-08-02 15:42:05 --> Helper loaded: form_helper
INFO - 2023-08-02 15:42:05 --> Helper loaded: lang_helper
INFO - 2023-08-02 15:42:05 --> Helper loaded: security_helper
INFO - 2023-08-02 15:42:05 --> Helper loaded: cookie_helper
INFO - 2023-08-02 15:42:05 --> Database Driver Class Initialized
INFO - 2023-08-02 15:42:05 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-02 15:42:05 --> Parser Class Initialized
INFO - 2023-08-02 15:42:05 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-02 15:42:05 --> Pagination Class Initialized
INFO - 2023-08-02 15:42:05 --> Form Validation Class Initialized
INFO - 2023-08-02 15:42:05 --> Controller Class Initialized
INFO - 2023-08-02 15:42:05 --> Model Class Initialized
DEBUG - 2023-08-02 15:42:05 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-02 15:42:05 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-02 15:42:05 --> Model Class Initialized
DEBUG - 2023-08-02 15:42:05 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-02 15:42:05 --> Model Class Initialized
INFO - 2023-08-02 15:42:05 --> Final output sent to browser
DEBUG - 2023-08-02 15:42:05 --> Total execution time: 0.0216
ERROR - 2023-08-02 15:42:05 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-02 15:42:05 --> Config Class Initialized
INFO - 2023-08-02 15:42:05 --> Hooks Class Initialized
DEBUG - 2023-08-02 15:42:05 --> UTF-8 Support Enabled
INFO - 2023-08-02 15:42:05 --> Utf8 Class Initialized
INFO - 2023-08-02 15:42:05 --> URI Class Initialized
INFO - 2023-08-02 15:42:05 --> Router Class Initialized
INFO - 2023-08-02 15:42:05 --> Output Class Initialized
INFO - 2023-08-02 15:42:05 --> Security Class Initialized
DEBUG - 2023-08-02 15:42:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-02 15:42:05 --> Input Class Initialized
INFO - 2023-08-02 15:42:05 --> Language Class Initialized
INFO - 2023-08-02 15:42:05 --> Loader Class Initialized
INFO - 2023-08-02 15:42:05 --> Helper loaded: url_helper
INFO - 2023-08-02 15:42:05 --> Helper loaded: file_helper
INFO - 2023-08-02 15:42:05 --> Helper loaded: html_helper
INFO - 2023-08-02 15:42:05 --> Helper loaded: text_helper
INFO - 2023-08-02 15:42:05 --> Helper loaded: form_helper
INFO - 2023-08-02 15:42:05 --> Helper loaded: lang_helper
INFO - 2023-08-02 15:42:05 --> Helper loaded: security_helper
INFO - 2023-08-02 15:42:05 --> Helper loaded: cookie_helper
INFO - 2023-08-02 15:42:05 --> Database Driver Class Initialized
INFO - 2023-08-02 15:42:05 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-02 15:42:05 --> Parser Class Initialized
INFO - 2023-08-02 15:42:05 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-02 15:42:05 --> Pagination Class Initialized
INFO - 2023-08-02 15:42:05 --> Form Validation Class Initialized
INFO - 2023-08-02 15:42:05 --> Controller Class Initialized
INFO - 2023-08-02 15:42:05 --> Model Class Initialized
DEBUG - 2023-08-02 15:42:05 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-02 15:42:05 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-02 15:42:05 --> Model Class Initialized
DEBUG - 2023-08-02 15:42:05 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-02 15:42:05 --> Model Class Initialized
INFO - 2023-08-02 15:42:05 --> Final output sent to browser
DEBUG - 2023-08-02 15:42:05 --> Total execution time: 0.0190
ERROR - 2023-08-02 15:42:06 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-02 15:42:06 --> Config Class Initialized
INFO - 2023-08-02 15:42:06 --> Hooks Class Initialized
DEBUG - 2023-08-02 15:42:06 --> UTF-8 Support Enabled
INFO - 2023-08-02 15:42:06 --> Utf8 Class Initialized
INFO - 2023-08-02 15:42:06 --> URI Class Initialized
INFO - 2023-08-02 15:42:06 --> Router Class Initialized
INFO - 2023-08-02 15:42:06 --> Output Class Initialized
INFO - 2023-08-02 15:42:06 --> Security Class Initialized
DEBUG - 2023-08-02 15:42:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-02 15:42:06 --> Input Class Initialized
INFO - 2023-08-02 15:42:06 --> Language Class Initialized
INFO - 2023-08-02 15:42:06 --> Loader Class Initialized
INFO - 2023-08-02 15:42:06 --> Helper loaded: url_helper
INFO - 2023-08-02 15:42:06 --> Helper loaded: file_helper
INFO - 2023-08-02 15:42:06 --> Helper loaded: html_helper
INFO - 2023-08-02 15:42:06 --> Helper loaded: text_helper
INFO - 2023-08-02 15:42:06 --> Helper loaded: form_helper
INFO - 2023-08-02 15:42:06 --> Helper loaded: lang_helper
INFO - 2023-08-02 15:42:06 --> Helper loaded: security_helper
INFO - 2023-08-02 15:42:06 --> Helper loaded: cookie_helper
INFO - 2023-08-02 15:42:06 --> Database Driver Class Initialized
INFO - 2023-08-02 15:42:06 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-02 15:42:06 --> Parser Class Initialized
INFO - 2023-08-02 15:42:06 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-02 15:42:06 --> Pagination Class Initialized
INFO - 2023-08-02 15:42:06 --> Form Validation Class Initialized
INFO - 2023-08-02 15:42:06 --> Controller Class Initialized
INFO - 2023-08-02 15:42:06 --> Model Class Initialized
DEBUG - 2023-08-02 15:42:06 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-02 15:42:06 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-02 15:42:06 --> Model Class Initialized
DEBUG - 2023-08-02 15:42:06 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-02 15:42:06 --> Model Class Initialized
INFO - 2023-08-02 15:42:06 --> Final output sent to browser
DEBUG - 2023-08-02 15:42:06 --> Total execution time: 0.0203
ERROR - 2023-08-02 15:42:08 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-02 15:42:08 --> Config Class Initialized
INFO - 2023-08-02 15:42:08 --> Hooks Class Initialized
DEBUG - 2023-08-02 15:42:08 --> UTF-8 Support Enabled
INFO - 2023-08-02 15:42:08 --> Utf8 Class Initialized
INFO - 2023-08-02 15:42:08 --> URI Class Initialized
INFO - 2023-08-02 15:42:08 --> Router Class Initialized
INFO - 2023-08-02 15:42:08 --> Output Class Initialized
INFO - 2023-08-02 15:42:08 --> Security Class Initialized
DEBUG - 2023-08-02 15:42:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-02 15:42:08 --> Input Class Initialized
INFO - 2023-08-02 15:42:08 --> Language Class Initialized
INFO - 2023-08-02 15:42:08 --> Loader Class Initialized
INFO - 2023-08-02 15:42:08 --> Helper loaded: url_helper
INFO - 2023-08-02 15:42:08 --> Helper loaded: file_helper
INFO - 2023-08-02 15:42:08 --> Helper loaded: html_helper
INFO - 2023-08-02 15:42:08 --> Helper loaded: text_helper
INFO - 2023-08-02 15:42:08 --> Helper loaded: form_helper
INFO - 2023-08-02 15:42:08 --> Helper loaded: lang_helper
INFO - 2023-08-02 15:42:08 --> Helper loaded: security_helper
INFO - 2023-08-02 15:42:08 --> Helper loaded: cookie_helper
INFO - 2023-08-02 15:42:08 --> Database Driver Class Initialized
INFO - 2023-08-02 15:42:08 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-02 15:42:08 --> Parser Class Initialized
INFO - 2023-08-02 15:42:08 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-02 15:42:08 --> Pagination Class Initialized
INFO - 2023-08-02 15:42:08 --> Form Validation Class Initialized
INFO - 2023-08-02 15:42:08 --> Controller Class Initialized
INFO - 2023-08-02 15:42:08 --> Model Class Initialized
DEBUG - 2023-08-02 15:42:08 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-02 15:42:08 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-02 15:42:08 --> Model Class Initialized
INFO - 2023-08-02 15:42:08 --> Model Class Initialized
INFO - 2023-08-02 15:42:08 --> Final output sent to browser
DEBUG - 2023-08-02 15:42:08 --> Total execution time: 0.0184
ERROR - 2023-08-02 15:42:15 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-02 15:42:15 --> Config Class Initialized
INFO - 2023-08-02 15:42:15 --> Hooks Class Initialized
DEBUG - 2023-08-02 15:42:15 --> UTF-8 Support Enabled
INFO - 2023-08-02 15:42:15 --> Utf8 Class Initialized
INFO - 2023-08-02 15:42:15 --> URI Class Initialized
INFO - 2023-08-02 15:42:15 --> Router Class Initialized
INFO - 2023-08-02 15:42:15 --> Output Class Initialized
INFO - 2023-08-02 15:42:15 --> Security Class Initialized
DEBUG - 2023-08-02 15:42:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-02 15:42:15 --> Input Class Initialized
INFO - 2023-08-02 15:42:15 --> Language Class Initialized
INFO - 2023-08-02 15:42:15 --> Loader Class Initialized
INFO - 2023-08-02 15:42:15 --> Helper loaded: url_helper
INFO - 2023-08-02 15:42:15 --> Helper loaded: file_helper
INFO - 2023-08-02 15:42:15 --> Helper loaded: html_helper
INFO - 2023-08-02 15:42:15 --> Helper loaded: text_helper
INFO - 2023-08-02 15:42:15 --> Helper loaded: form_helper
INFO - 2023-08-02 15:42:15 --> Helper loaded: lang_helper
INFO - 2023-08-02 15:42:15 --> Helper loaded: security_helper
INFO - 2023-08-02 15:42:15 --> Helper loaded: cookie_helper
INFO - 2023-08-02 15:42:15 --> Database Driver Class Initialized
INFO - 2023-08-02 15:42:15 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-02 15:42:15 --> Parser Class Initialized
INFO - 2023-08-02 15:42:15 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-02 15:42:15 --> Pagination Class Initialized
INFO - 2023-08-02 15:42:15 --> Form Validation Class Initialized
INFO - 2023-08-02 15:42:15 --> Controller Class Initialized
INFO - 2023-08-02 15:42:15 --> Model Class Initialized
DEBUG - 2023-08-02 15:42:15 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-02 15:42:15 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-02 15:42:15 --> Model Class Initialized
DEBUG - 2023-08-02 15:42:15 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-02 15:42:15 --> Model Class Initialized
INFO - 2023-08-02 15:42:15 --> Final output sent to browser
DEBUG - 2023-08-02 15:42:15 --> Total execution time: 0.0483
ERROR - 2023-08-02 15:42:16 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-02 15:42:16 --> Config Class Initialized
INFO - 2023-08-02 15:42:16 --> Hooks Class Initialized
DEBUG - 2023-08-02 15:42:16 --> UTF-8 Support Enabled
INFO - 2023-08-02 15:42:16 --> Utf8 Class Initialized
INFO - 2023-08-02 15:42:16 --> URI Class Initialized
INFO - 2023-08-02 15:42:16 --> Router Class Initialized
INFO - 2023-08-02 15:42:16 --> Output Class Initialized
INFO - 2023-08-02 15:42:16 --> Security Class Initialized
DEBUG - 2023-08-02 15:42:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-02 15:42:16 --> Input Class Initialized
INFO - 2023-08-02 15:42:16 --> Language Class Initialized
INFO - 2023-08-02 15:42:16 --> Loader Class Initialized
INFO - 2023-08-02 15:42:16 --> Helper loaded: url_helper
INFO - 2023-08-02 15:42:16 --> Helper loaded: file_helper
INFO - 2023-08-02 15:42:16 --> Helper loaded: html_helper
INFO - 2023-08-02 15:42:16 --> Helper loaded: text_helper
INFO - 2023-08-02 15:42:16 --> Helper loaded: form_helper
INFO - 2023-08-02 15:42:16 --> Helper loaded: lang_helper
INFO - 2023-08-02 15:42:16 --> Helper loaded: security_helper
INFO - 2023-08-02 15:42:16 --> Helper loaded: cookie_helper
INFO - 2023-08-02 15:42:16 --> Database Driver Class Initialized
INFO - 2023-08-02 15:42:16 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-02 15:42:16 --> Parser Class Initialized
INFO - 2023-08-02 15:42:16 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-02 15:42:16 --> Pagination Class Initialized
INFO - 2023-08-02 15:42:16 --> Form Validation Class Initialized
INFO - 2023-08-02 15:42:16 --> Controller Class Initialized
INFO - 2023-08-02 15:42:16 --> Model Class Initialized
DEBUG - 2023-08-02 15:42:16 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-02 15:42:16 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-02 15:42:16 --> Model Class Initialized
DEBUG - 2023-08-02 15:42:16 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-02 15:42:16 --> Model Class Initialized
INFO - 2023-08-02 15:42:16 --> Final output sent to browser
DEBUG - 2023-08-02 15:42:16 --> Total execution time: 0.0479
ERROR - 2023-08-02 15:42:16 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-02 15:42:16 --> Config Class Initialized
INFO - 2023-08-02 15:42:16 --> Hooks Class Initialized
DEBUG - 2023-08-02 15:42:16 --> UTF-8 Support Enabled
INFO - 2023-08-02 15:42:16 --> Utf8 Class Initialized
INFO - 2023-08-02 15:42:16 --> URI Class Initialized
INFO - 2023-08-02 15:42:16 --> Router Class Initialized
INFO - 2023-08-02 15:42:16 --> Output Class Initialized
INFO - 2023-08-02 15:42:16 --> Security Class Initialized
DEBUG - 2023-08-02 15:42:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-02 15:42:16 --> Input Class Initialized
INFO - 2023-08-02 15:42:16 --> Language Class Initialized
INFO - 2023-08-02 15:42:16 --> Loader Class Initialized
INFO - 2023-08-02 15:42:16 --> Helper loaded: url_helper
INFO - 2023-08-02 15:42:16 --> Helper loaded: file_helper
INFO - 2023-08-02 15:42:16 --> Helper loaded: html_helper
INFO - 2023-08-02 15:42:16 --> Helper loaded: text_helper
INFO - 2023-08-02 15:42:16 --> Helper loaded: form_helper
INFO - 2023-08-02 15:42:16 --> Helper loaded: lang_helper
INFO - 2023-08-02 15:42:16 --> Helper loaded: security_helper
INFO - 2023-08-02 15:42:16 --> Helper loaded: cookie_helper
INFO - 2023-08-02 15:42:16 --> Database Driver Class Initialized
INFO - 2023-08-02 15:42:16 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-02 15:42:16 --> Parser Class Initialized
INFO - 2023-08-02 15:42:16 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-02 15:42:16 --> Pagination Class Initialized
INFO - 2023-08-02 15:42:16 --> Form Validation Class Initialized
INFO - 2023-08-02 15:42:16 --> Controller Class Initialized
INFO - 2023-08-02 15:42:16 --> Model Class Initialized
DEBUG - 2023-08-02 15:42:16 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-02 15:42:16 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-02 15:42:16 --> Model Class Initialized
DEBUG - 2023-08-02 15:42:16 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-02 15:42:16 --> Model Class Initialized
INFO - 2023-08-02 15:42:16 --> Final output sent to browser
DEBUG - 2023-08-02 15:42:16 --> Total execution time: 0.0509
ERROR - 2023-08-02 15:42:18 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-02 15:42:18 --> Config Class Initialized
INFO - 2023-08-02 15:42:18 --> Hooks Class Initialized
DEBUG - 2023-08-02 15:42:18 --> UTF-8 Support Enabled
INFO - 2023-08-02 15:42:18 --> Utf8 Class Initialized
INFO - 2023-08-02 15:42:18 --> URI Class Initialized
INFO - 2023-08-02 15:42:18 --> Router Class Initialized
INFO - 2023-08-02 15:42:18 --> Output Class Initialized
INFO - 2023-08-02 15:42:18 --> Security Class Initialized
DEBUG - 2023-08-02 15:42:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-02 15:42:18 --> Input Class Initialized
INFO - 2023-08-02 15:42:18 --> Language Class Initialized
INFO - 2023-08-02 15:42:18 --> Loader Class Initialized
INFO - 2023-08-02 15:42:18 --> Helper loaded: url_helper
INFO - 2023-08-02 15:42:18 --> Helper loaded: file_helper
INFO - 2023-08-02 15:42:18 --> Helper loaded: html_helper
INFO - 2023-08-02 15:42:18 --> Helper loaded: text_helper
INFO - 2023-08-02 15:42:18 --> Helper loaded: form_helper
INFO - 2023-08-02 15:42:18 --> Helper loaded: lang_helper
INFO - 2023-08-02 15:42:18 --> Helper loaded: security_helper
INFO - 2023-08-02 15:42:18 --> Helper loaded: cookie_helper
INFO - 2023-08-02 15:42:18 --> Database Driver Class Initialized
INFO - 2023-08-02 15:42:18 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-02 15:42:18 --> Parser Class Initialized
INFO - 2023-08-02 15:42:18 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-02 15:42:18 --> Pagination Class Initialized
INFO - 2023-08-02 15:42:18 --> Form Validation Class Initialized
INFO - 2023-08-02 15:42:18 --> Controller Class Initialized
INFO - 2023-08-02 15:42:18 --> Model Class Initialized
DEBUG - 2023-08-02 15:42:18 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-02 15:42:18 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-02 15:42:18 --> Model Class Initialized
DEBUG - 2023-08-02 15:42:18 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-02 15:42:18 --> Model Class Initialized
INFO - 2023-08-02 15:42:18 --> Final output sent to browser
DEBUG - 2023-08-02 15:42:18 --> Total execution time: 0.0195
ERROR - 2023-08-02 15:42:19 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-02 15:42:19 --> Config Class Initialized
INFO - 2023-08-02 15:42:19 --> Hooks Class Initialized
DEBUG - 2023-08-02 15:42:19 --> UTF-8 Support Enabled
INFO - 2023-08-02 15:42:19 --> Utf8 Class Initialized
INFO - 2023-08-02 15:42:19 --> URI Class Initialized
INFO - 2023-08-02 15:42:19 --> Router Class Initialized
INFO - 2023-08-02 15:42:19 --> Output Class Initialized
INFO - 2023-08-02 15:42:19 --> Security Class Initialized
DEBUG - 2023-08-02 15:42:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-02 15:42:19 --> Input Class Initialized
INFO - 2023-08-02 15:42:19 --> Language Class Initialized
INFO - 2023-08-02 15:42:19 --> Loader Class Initialized
INFO - 2023-08-02 15:42:19 --> Helper loaded: url_helper
INFO - 2023-08-02 15:42:19 --> Helper loaded: file_helper
INFO - 2023-08-02 15:42:19 --> Helper loaded: html_helper
INFO - 2023-08-02 15:42:19 --> Helper loaded: text_helper
INFO - 2023-08-02 15:42:19 --> Helper loaded: form_helper
INFO - 2023-08-02 15:42:19 --> Helper loaded: lang_helper
INFO - 2023-08-02 15:42:19 --> Helper loaded: security_helper
INFO - 2023-08-02 15:42:19 --> Helper loaded: cookie_helper
INFO - 2023-08-02 15:42:19 --> Database Driver Class Initialized
INFO - 2023-08-02 15:42:19 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-02 15:42:19 --> Parser Class Initialized
INFO - 2023-08-02 15:42:19 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-02 15:42:19 --> Pagination Class Initialized
INFO - 2023-08-02 15:42:19 --> Form Validation Class Initialized
INFO - 2023-08-02 15:42:19 --> Controller Class Initialized
INFO - 2023-08-02 15:42:19 --> Model Class Initialized
DEBUG - 2023-08-02 15:42:19 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-02 15:42:19 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-02 15:42:19 --> Model Class Initialized
DEBUG - 2023-08-02 15:42:19 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-02 15:42:19 --> Model Class Initialized
INFO - 2023-08-02 15:42:19 --> Final output sent to browser
DEBUG - 2023-08-02 15:42:19 --> Total execution time: 0.0199
ERROR - 2023-08-02 15:42:20 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-02 15:42:20 --> Config Class Initialized
INFO - 2023-08-02 15:42:20 --> Hooks Class Initialized
DEBUG - 2023-08-02 15:42:20 --> UTF-8 Support Enabled
INFO - 2023-08-02 15:42:20 --> Utf8 Class Initialized
INFO - 2023-08-02 15:42:20 --> URI Class Initialized
INFO - 2023-08-02 15:42:20 --> Router Class Initialized
INFO - 2023-08-02 15:42:20 --> Output Class Initialized
INFO - 2023-08-02 15:42:20 --> Security Class Initialized
DEBUG - 2023-08-02 15:42:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-02 15:42:20 --> Input Class Initialized
INFO - 2023-08-02 15:42:20 --> Language Class Initialized
INFO - 2023-08-02 15:42:20 --> Loader Class Initialized
INFO - 2023-08-02 15:42:20 --> Helper loaded: url_helper
INFO - 2023-08-02 15:42:20 --> Helper loaded: file_helper
INFO - 2023-08-02 15:42:20 --> Helper loaded: html_helper
INFO - 2023-08-02 15:42:20 --> Helper loaded: text_helper
INFO - 2023-08-02 15:42:20 --> Helper loaded: form_helper
INFO - 2023-08-02 15:42:20 --> Helper loaded: lang_helper
INFO - 2023-08-02 15:42:20 --> Helper loaded: security_helper
INFO - 2023-08-02 15:42:20 --> Helper loaded: cookie_helper
INFO - 2023-08-02 15:42:20 --> Database Driver Class Initialized
INFO - 2023-08-02 15:42:20 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-02 15:42:20 --> Parser Class Initialized
INFO - 2023-08-02 15:42:20 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-02 15:42:20 --> Pagination Class Initialized
INFO - 2023-08-02 15:42:20 --> Form Validation Class Initialized
INFO - 2023-08-02 15:42:20 --> Controller Class Initialized
INFO - 2023-08-02 15:42:20 --> Model Class Initialized
DEBUG - 2023-08-02 15:42:20 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-02 15:42:20 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-02 15:42:20 --> Model Class Initialized
INFO - 2023-08-02 15:42:20 --> Model Class Initialized
INFO - 2023-08-02 15:42:20 --> Final output sent to browser
DEBUG - 2023-08-02 15:42:20 --> Total execution time: 0.0177
ERROR - 2023-08-02 15:42:46 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-02 15:42:46 --> Config Class Initialized
INFO - 2023-08-02 15:42:46 --> Hooks Class Initialized
DEBUG - 2023-08-02 15:42:46 --> UTF-8 Support Enabled
INFO - 2023-08-02 15:42:46 --> Utf8 Class Initialized
INFO - 2023-08-02 15:42:46 --> URI Class Initialized
INFO - 2023-08-02 15:42:46 --> Router Class Initialized
INFO - 2023-08-02 15:42:46 --> Output Class Initialized
INFO - 2023-08-02 15:42:46 --> Security Class Initialized
DEBUG - 2023-08-02 15:42:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-02 15:42:46 --> Input Class Initialized
INFO - 2023-08-02 15:42:46 --> Language Class Initialized
INFO - 2023-08-02 15:42:46 --> Loader Class Initialized
INFO - 2023-08-02 15:42:46 --> Helper loaded: url_helper
INFO - 2023-08-02 15:42:46 --> Helper loaded: file_helper
INFO - 2023-08-02 15:42:46 --> Helper loaded: html_helper
INFO - 2023-08-02 15:42:46 --> Helper loaded: text_helper
INFO - 2023-08-02 15:42:46 --> Helper loaded: form_helper
INFO - 2023-08-02 15:42:46 --> Helper loaded: lang_helper
INFO - 2023-08-02 15:42:46 --> Helper loaded: security_helper
INFO - 2023-08-02 15:42:46 --> Helper loaded: cookie_helper
INFO - 2023-08-02 15:42:46 --> Database Driver Class Initialized
INFO - 2023-08-02 15:42:46 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-02 15:42:46 --> Parser Class Initialized
INFO - 2023-08-02 15:42:46 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-02 15:42:46 --> Pagination Class Initialized
INFO - 2023-08-02 15:42:46 --> Form Validation Class Initialized
INFO - 2023-08-02 15:42:46 --> Controller Class Initialized
INFO - 2023-08-02 15:42:46 --> Model Class Initialized
DEBUG - 2023-08-02 15:42:46 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-02 15:42:46 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-02 15:42:46 --> Model Class Initialized
INFO - 2023-08-02 15:42:46 --> Final output sent to browser
DEBUG - 2023-08-02 15:42:46 --> Total execution time: 0.0188
ERROR - 2023-08-02 15:42:48 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-02 15:42:48 --> Config Class Initialized
INFO - 2023-08-02 15:42:48 --> Hooks Class Initialized
DEBUG - 2023-08-02 15:42:48 --> UTF-8 Support Enabled
INFO - 2023-08-02 15:42:48 --> Utf8 Class Initialized
INFO - 2023-08-02 15:42:48 --> URI Class Initialized
INFO - 2023-08-02 15:42:48 --> Router Class Initialized
INFO - 2023-08-02 15:42:48 --> Output Class Initialized
INFO - 2023-08-02 15:42:48 --> Security Class Initialized
DEBUG - 2023-08-02 15:42:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-02 15:42:48 --> Input Class Initialized
INFO - 2023-08-02 15:42:48 --> Language Class Initialized
INFO - 2023-08-02 15:42:48 --> Loader Class Initialized
INFO - 2023-08-02 15:42:48 --> Helper loaded: url_helper
INFO - 2023-08-02 15:42:48 --> Helper loaded: file_helper
INFO - 2023-08-02 15:42:48 --> Helper loaded: html_helper
INFO - 2023-08-02 15:42:48 --> Helper loaded: text_helper
INFO - 2023-08-02 15:42:48 --> Helper loaded: form_helper
INFO - 2023-08-02 15:42:48 --> Helper loaded: lang_helper
INFO - 2023-08-02 15:42:48 --> Helper loaded: security_helper
INFO - 2023-08-02 15:42:48 --> Helper loaded: cookie_helper
INFO - 2023-08-02 15:42:48 --> Database Driver Class Initialized
INFO - 2023-08-02 15:42:48 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-02 15:42:48 --> Parser Class Initialized
INFO - 2023-08-02 15:42:48 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-02 15:42:48 --> Pagination Class Initialized
INFO - 2023-08-02 15:42:48 --> Form Validation Class Initialized
INFO - 2023-08-02 15:42:48 --> Controller Class Initialized
INFO - 2023-08-02 15:42:48 --> Model Class Initialized
DEBUG - 2023-08-02 15:42:48 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-02 15:42:48 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-02 15:42:48 --> Model Class Initialized
INFO - 2023-08-02 15:42:48 --> Final output sent to browser
DEBUG - 2023-08-02 15:42:48 --> Total execution time: 0.0179
ERROR - 2023-08-02 15:42:50 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-02 15:42:50 --> Config Class Initialized
INFO - 2023-08-02 15:42:50 --> Hooks Class Initialized
DEBUG - 2023-08-02 15:42:50 --> UTF-8 Support Enabled
INFO - 2023-08-02 15:42:50 --> Utf8 Class Initialized
INFO - 2023-08-02 15:42:50 --> URI Class Initialized
INFO - 2023-08-02 15:42:50 --> Router Class Initialized
INFO - 2023-08-02 15:42:50 --> Output Class Initialized
INFO - 2023-08-02 15:42:50 --> Security Class Initialized
DEBUG - 2023-08-02 15:42:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-02 15:42:50 --> Input Class Initialized
INFO - 2023-08-02 15:42:50 --> Language Class Initialized
INFO - 2023-08-02 15:42:50 --> Loader Class Initialized
INFO - 2023-08-02 15:42:50 --> Helper loaded: url_helper
INFO - 2023-08-02 15:42:50 --> Helper loaded: file_helper
INFO - 2023-08-02 15:42:50 --> Helper loaded: html_helper
INFO - 2023-08-02 15:42:50 --> Helper loaded: text_helper
INFO - 2023-08-02 15:42:50 --> Helper loaded: form_helper
INFO - 2023-08-02 15:42:50 --> Helper loaded: lang_helper
INFO - 2023-08-02 15:42:50 --> Helper loaded: security_helper
INFO - 2023-08-02 15:42:50 --> Helper loaded: cookie_helper
INFO - 2023-08-02 15:42:50 --> Database Driver Class Initialized
INFO - 2023-08-02 15:42:50 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-02 15:42:50 --> Parser Class Initialized
INFO - 2023-08-02 15:42:50 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-02 15:42:50 --> Pagination Class Initialized
INFO - 2023-08-02 15:42:50 --> Form Validation Class Initialized
INFO - 2023-08-02 15:42:50 --> Controller Class Initialized
INFO - 2023-08-02 15:42:50 --> Model Class Initialized
DEBUG - 2023-08-02 15:42:50 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-02 15:42:50 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-02 15:42:50 --> Model Class Initialized
INFO - 2023-08-02 15:42:50 --> Final output sent to browser
DEBUG - 2023-08-02 15:42:50 --> Total execution time: 0.0169
ERROR - 2023-08-02 15:42:52 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-02 15:42:52 --> Config Class Initialized
INFO - 2023-08-02 15:42:52 --> Hooks Class Initialized
DEBUG - 2023-08-02 15:42:52 --> UTF-8 Support Enabled
INFO - 2023-08-02 15:42:52 --> Utf8 Class Initialized
INFO - 2023-08-02 15:42:52 --> URI Class Initialized
INFO - 2023-08-02 15:42:52 --> Router Class Initialized
INFO - 2023-08-02 15:42:52 --> Output Class Initialized
INFO - 2023-08-02 15:42:52 --> Security Class Initialized
DEBUG - 2023-08-02 15:42:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-02 15:42:52 --> Input Class Initialized
INFO - 2023-08-02 15:42:52 --> Language Class Initialized
INFO - 2023-08-02 15:42:52 --> Loader Class Initialized
INFO - 2023-08-02 15:42:52 --> Helper loaded: url_helper
INFO - 2023-08-02 15:42:52 --> Helper loaded: file_helper
INFO - 2023-08-02 15:42:52 --> Helper loaded: html_helper
INFO - 2023-08-02 15:42:52 --> Helper loaded: text_helper
INFO - 2023-08-02 15:42:52 --> Helper loaded: form_helper
INFO - 2023-08-02 15:42:52 --> Helper loaded: lang_helper
INFO - 2023-08-02 15:42:52 --> Helper loaded: security_helper
INFO - 2023-08-02 15:42:52 --> Helper loaded: cookie_helper
INFO - 2023-08-02 15:42:52 --> Database Driver Class Initialized
INFO - 2023-08-02 15:42:52 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-02 15:42:52 --> Parser Class Initialized
INFO - 2023-08-02 15:42:52 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-02 15:42:52 --> Pagination Class Initialized
INFO - 2023-08-02 15:42:52 --> Form Validation Class Initialized
INFO - 2023-08-02 15:42:52 --> Controller Class Initialized
INFO - 2023-08-02 15:42:52 --> Model Class Initialized
DEBUG - 2023-08-02 15:42:52 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-02 15:42:52 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-02 15:42:52 --> Model Class Initialized
INFO - 2023-08-02 15:42:52 --> Final output sent to browser
DEBUG - 2023-08-02 15:42:52 --> Total execution time: 0.0169
ERROR - 2023-08-02 15:45:08 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-02 15:45:08 --> Config Class Initialized
INFO - 2023-08-02 15:45:08 --> Hooks Class Initialized
DEBUG - 2023-08-02 15:45:08 --> UTF-8 Support Enabled
INFO - 2023-08-02 15:45:08 --> Utf8 Class Initialized
INFO - 2023-08-02 15:45:08 --> URI Class Initialized
INFO - 2023-08-02 15:45:08 --> Router Class Initialized
INFO - 2023-08-02 15:45:08 --> Output Class Initialized
INFO - 2023-08-02 15:45:08 --> Security Class Initialized
DEBUG - 2023-08-02 15:45:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-02 15:45:08 --> Input Class Initialized
INFO - 2023-08-02 15:45:08 --> Language Class Initialized
INFO - 2023-08-02 15:45:08 --> Loader Class Initialized
INFO - 2023-08-02 15:45:08 --> Helper loaded: url_helper
INFO - 2023-08-02 15:45:08 --> Helper loaded: file_helper
INFO - 2023-08-02 15:45:08 --> Helper loaded: html_helper
INFO - 2023-08-02 15:45:08 --> Helper loaded: text_helper
INFO - 2023-08-02 15:45:08 --> Helper loaded: form_helper
INFO - 2023-08-02 15:45:08 --> Helper loaded: lang_helper
INFO - 2023-08-02 15:45:08 --> Helper loaded: security_helper
INFO - 2023-08-02 15:45:08 --> Helper loaded: cookie_helper
INFO - 2023-08-02 15:45:08 --> Database Driver Class Initialized
INFO - 2023-08-02 15:45:08 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-02 15:45:08 --> Parser Class Initialized
INFO - 2023-08-02 15:45:08 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-02 15:45:08 --> Pagination Class Initialized
INFO - 2023-08-02 15:45:08 --> Form Validation Class Initialized
INFO - 2023-08-02 15:45:08 --> Controller Class Initialized
INFO - 2023-08-02 15:45:08 --> Model Class Initialized
DEBUG - 2023-08-02 15:45:08 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-02 15:45:08 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-02 15:45:08 --> Model Class Initialized
DEBUG - 2023-08-02 15:45:08 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-02 15:45:08 --> Model Class Initialized
INFO - 2023-08-02 15:45:08 --> Email Class Initialized
DEBUG - 2023-08-02 15:45:08 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-02 15:45:08 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice_html_pdf.php
ERROR - 2023-08-02 15:45:08 --> Severity: Warning --> "continue" targeting switch is equivalent to "break". Did you mean to use "continue 2"? /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/dompdf.cls.php 743
ERROR - 2023-08-02 15:45:08 --> Severity: Warning --> "continue" targeting switch is equivalent to "break". Did you mean to use "continue 2"? /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/dompdf.cls.php 763
ERROR - 2023-08-02 15:45:08 --> Severity: Warning --> "continue" targeting switch is equivalent to "break". Did you mean to use "continue 2"? /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/stylesheet.cls.php 1102
ERROR - 2023-08-02 15:45:08 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/page_frame_decorator.cls.php 439
ERROR - 2023-08-02 15:45:08 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/page_frame_decorator.cls.php 439
ERROR - 2023-08-02 15:45:08 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/page_frame_decorator.cls.php 439
ERROR - 2023-08-02 15:45:08 --> Severity: Warning --> Division by zero /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 572
ERROR - 2023-08-02 15:45:08 --> Severity: Warning --> Division by zero /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 572
ERROR - 2023-08-02 15:45:08 --> Severity: Warning --> Division by zero /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 572
ERROR - 2023-08-02 15:45:08 --> Severity: Warning --> Division by zero /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 572
ERROR - 2023-08-02 15:45:08 --> Severity: Warning --> Division by zero /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 572
ERROR - 2023-08-02 15:45:08 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/table_cell_frame_reflower.cls.php 103
ERROR - 2023-08-02 15:45:08 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/table_cell_frame_reflower.cls.php 103
ERROR - 2023-08-02 15:45:08 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/table_cell_frame_reflower.cls.php 103
ERROR - 2023-08-02 15:45:08 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/table_cell_frame_reflower.cls.php 103
ERROR - 2023-08-02 15:45:08 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/table_cell_frame_reflower.cls.php 103
ERROR - 2023-08-02 15:45:08 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/table_cell_frame_reflower.cls.php 103
ERROR - 2023-08-02 15:45:08 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/table_cell_frame_reflower.cls.php 103
ERROR - 2023-08-02 15:45:08 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/table_cell_frame_reflower.cls.php 103
ERROR - 2023-08-02 15:45:08 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/table_cell_frame_reflower.cls.php 103
ERROR - 2023-08-02 15:45:08 --> Severity: Warning --> Invalid argument supplied for foreach() /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 709
ERROR - 2023-08-02 15:45:08 --> Severity: Warning --> Invalid argument supplied for foreach() /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 709
ERROR - 2023-08-02 15:45:08 --> Severity: Warning --> Invalid argument supplied for foreach() /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 709
ERROR - 2023-08-02 15:45:08 --> Severity: Warning --> Invalid argument supplied for foreach() /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 709
ERROR - 2023-08-02 15:45:08 --> Severity: Warning --> Invalid argument supplied for foreach() /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 709
ERROR - 2023-08-02 15:45:08 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-02 15:45:08 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-02 15:45:08 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-02 15:45:08 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-02 15:45:08 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-02 15:45:08 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-02 15:45:08 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-02 15:45:08 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-02 15:45:08 --> Severity: Warning --> "continue" targeting switch is equivalent to "break". Did you mean to use "continue 2"? /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/text_renderer.cls.php 126
ERROR - 2023-08-02 15:45:08 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-02 15:45:08 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-02 15:45:08 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-02 15:45:08 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-02 15:45:08 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-02 15:45:08 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-02 15:45:08 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-02 15:45:08 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-02 15:45:08 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-02 15:45:08 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-02 15:45:08 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-02 15:45:08 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-02 15:45:08 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-02 15:45:08 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-02 15:45:08 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-02 15:45:08 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-02 15:45:08 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-02 15:45:08 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-02 15:45:08 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-02 15:45:08 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-02 15:45:08 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-02 15:45:08 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-02 15:45:08 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-02 15:45:08 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-02 15:45:08 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-02 15:45:08 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-02 15:45:08 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-02 15:45:08 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-02 15:45:08 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-02 15:45:08 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-02 15:45:08 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-02 15:45:08 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-02 15:45:08 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-02 15:45:08 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-02 15:45:08 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-02 15:45:08 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-02 15:45:08 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-02 15:45:08 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-02 15:45:08 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-02 15:45:08 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-02 15:45:08 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-02 15:45:08 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-02 15:45:08 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-02 15:45:08 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-02 15:45:08 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-02 15:45:08 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-02 15:45:08 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-02 15:45:08 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-02 15:45:08 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-02 15:45:08 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-02 15:45:08 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-02 15:45:08 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-02 15:45:08 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-02 15:45:08 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-02 15:45:08 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-02 15:45:08 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-02 15:45:08 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-02 15:45:08 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-02 15:45:08 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-02 15:45:08 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-02 15:45:08 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-02 15:45:08 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-02 15:45:08 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-02 15:45:08 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-02 15:45:08 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-02 15:45:08 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-02 15:45:08 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-02 15:45:08 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-02 15:45:08 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-02 15:45:08 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-02 15:45:08 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-02 15:45:08 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-02 15:45:08 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-02 15:45:08 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-02 15:45:08 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-02 15:45:08 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-02 15:45:08 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-02 15:45:08 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-02 15:45:08 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-02 15:45:08 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-02 15:45:08 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-02 15:45:08 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-02 15:45:08 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-02 15:45:08 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-02 15:45:08 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-02 15:45:08 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-02 15:45:08 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-02 15:45:08 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-02 15:45:08 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-02 15:45:08 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-02 15:45:08 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-02 15:45:08 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-02 15:45:08 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-02 15:45:08 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-02 15:45:08 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-02 15:45:08 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-02 15:45:08 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-02 15:45:08 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-02 15:45:08 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-02 15:45:08 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-02 15:45:08 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-02 15:45:08 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-02 15:45:08 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-02 15:45:08 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
INFO - 2023-08-02 15:45:08 --> Language file loaded: language/english/email_lang.php
INFO - 2023-08-02 15:45:09 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice_html.php
INFO - 2023-08-02 15:45:09 --> Final output sent to browser
DEBUG - 2023-08-02 15:45:09 --> Total execution time: 0.5232
ERROR - 2023-08-02 15:45:11 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-02 15:45:11 --> Config Class Initialized
INFO - 2023-08-02 15:45:11 --> Hooks Class Initialized
DEBUG - 2023-08-02 15:45:11 --> UTF-8 Support Enabled
INFO - 2023-08-02 15:45:11 --> Utf8 Class Initialized
INFO - 2023-08-02 15:45:11 --> URI Class Initialized
INFO - 2023-08-02 15:45:11 --> Router Class Initialized
INFO - 2023-08-02 15:45:11 --> Output Class Initialized
INFO - 2023-08-02 15:45:11 --> Security Class Initialized
DEBUG - 2023-08-02 15:45:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-02 15:45:11 --> Input Class Initialized
INFO - 2023-08-02 15:45:11 --> Language Class Initialized
INFO - 2023-08-02 15:45:11 --> Loader Class Initialized
INFO - 2023-08-02 15:45:11 --> Helper loaded: url_helper
INFO - 2023-08-02 15:45:11 --> Helper loaded: file_helper
INFO - 2023-08-02 15:45:11 --> Helper loaded: html_helper
INFO - 2023-08-02 15:45:11 --> Helper loaded: text_helper
INFO - 2023-08-02 15:45:11 --> Helper loaded: form_helper
INFO - 2023-08-02 15:45:11 --> Helper loaded: lang_helper
INFO - 2023-08-02 15:45:11 --> Helper loaded: security_helper
INFO - 2023-08-02 15:45:11 --> Helper loaded: cookie_helper
INFO - 2023-08-02 15:45:11 --> Database Driver Class Initialized
INFO - 2023-08-02 15:45:11 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-02 15:45:11 --> Parser Class Initialized
INFO - 2023-08-02 15:45:11 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-02 15:45:11 --> Pagination Class Initialized
INFO - 2023-08-02 15:45:11 --> Form Validation Class Initialized
INFO - 2023-08-02 15:45:11 --> Controller Class Initialized
INFO - 2023-08-02 15:45:11 --> Model Class Initialized
DEBUG - 2023-08-02 15:45:11 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-02 15:45:11 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-02 15:45:11 --> Model Class Initialized
DEBUG - 2023-08-02 15:45:11 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-02 15:45:11 --> Model Class Initialized
INFO - 2023-08-02 15:45:11 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice_html_manual.php
DEBUG - 2023-08-02 15:45:11 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-08-02 15:45:11 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-08-02 15:45:11 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-08-02 15:45:11 --> Model Class Initialized
INFO - 2023-08-02 15:45:11 --> Model Class Initialized
INFO - 2023-08-02 15:45:11 --> Model Class Initialized
INFO - 2023-08-02 15:45:11 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-08-02 15:45:11 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-08-02 15:45:11 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-08-02 15:45:11 --> Final output sent to browser
DEBUG - 2023-08-02 15:45:11 --> Total execution time: 0.0862
ERROR - 2023-08-02 15:45:14 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-02 15:45:14 --> Config Class Initialized
INFO - 2023-08-02 15:45:14 --> Hooks Class Initialized
DEBUG - 2023-08-02 15:45:14 --> UTF-8 Support Enabled
INFO - 2023-08-02 15:45:14 --> Utf8 Class Initialized
INFO - 2023-08-02 15:45:14 --> URI Class Initialized
INFO - 2023-08-02 15:45:14 --> Router Class Initialized
INFO - 2023-08-02 15:45:14 --> Output Class Initialized
INFO - 2023-08-02 15:45:14 --> Security Class Initialized
DEBUG - 2023-08-02 15:45:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-02 15:45:14 --> Input Class Initialized
INFO - 2023-08-02 15:45:14 --> Language Class Initialized
INFO - 2023-08-02 15:45:14 --> Loader Class Initialized
INFO - 2023-08-02 15:45:14 --> Helper loaded: url_helper
INFO - 2023-08-02 15:45:14 --> Helper loaded: file_helper
INFO - 2023-08-02 15:45:14 --> Helper loaded: html_helper
INFO - 2023-08-02 15:45:14 --> Helper loaded: text_helper
INFO - 2023-08-02 15:45:14 --> Helper loaded: form_helper
INFO - 2023-08-02 15:45:14 --> Helper loaded: lang_helper
INFO - 2023-08-02 15:45:14 --> Helper loaded: security_helper
INFO - 2023-08-02 15:45:14 --> Helper loaded: cookie_helper
INFO - 2023-08-02 15:45:14 --> Database Driver Class Initialized
INFO - 2023-08-02 15:45:14 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-02 15:45:14 --> Parser Class Initialized
INFO - 2023-08-02 15:45:14 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-02 15:45:14 --> Pagination Class Initialized
INFO - 2023-08-02 15:45:14 --> Form Validation Class Initialized
INFO - 2023-08-02 15:45:14 --> Controller Class Initialized
INFO - 2023-08-02 15:45:14 --> Model Class Initialized
DEBUG - 2023-08-02 15:45:14 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-02 15:45:14 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-02 15:45:14 --> Model Class Initialized
DEBUG - 2023-08-02 15:45:14 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-02 15:45:14 --> Model Class Initialized
INFO - 2023-08-02 15:45:14 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/add_invoice_form.php
DEBUG - 2023-08-02 15:45:14 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-08-02 15:45:14 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-08-02 15:45:14 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-08-02 15:45:14 --> Model Class Initialized
INFO - 2023-08-02 15:45:14 --> Model Class Initialized
INFO - 2023-08-02 15:45:14 --> Model Class Initialized
INFO - 2023-08-02 15:45:14 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-08-02 15:45:14 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-08-02 15:45:14 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-08-02 15:45:14 --> Final output sent to browser
DEBUG - 2023-08-02 15:45:14 --> Total execution time: 0.0899
ERROR - 2023-08-02 15:45:20 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-02 15:45:20 --> Config Class Initialized
INFO - 2023-08-02 15:45:20 --> Hooks Class Initialized
DEBUG - 2023-08-02 15:45:20 --> UTF-8 Support Enabled
INFO - 2023-08-02 15:45:20 --> Utf8 Class Initialized
INFO - 2023-08-02 15:45:20 --> URI Class Initialized
DEBUG - 2023-08-02 15:45:20 --> No URI present. Default controller set.
INFO - 2023-08-02 15:45:20 --> Router Class Initialized
INFO - 2023-08-02 15:45:20 --> Output Class Initialized
INFO - 2023-08-02 15:45:20 --> Security Class Initialized
DEBUG - 2023-08-02 15:45:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-02 15:45:20 --> Input Class Initialized
INFO - 2023-08-02 15:45:20 --> Language Class Initialized
INFO - 2023-08-02 15:45:20 --> Loader Class Initialized
INFO - 2023-08-02 15:45:20 --> Helper loaded: url_helper
INFO - 2023-08-02 15:45:20 --> Helper loaded: file_helper
INFO - 2023-08-02 15:45:20 --> Helper loaded: html_helper
INFO - 2023-08-02 15:45:20 --> Helper loaded: text_helper
INFO - 2023-08-02 15:45:20 --> Helper loaded: form_helper
INFO - 2023-08-02 15:45:20 --> Helper loaded: lang_helper
INFO - 2023-08-02 15:45:20 --> Helper loaded: security_helper
INFO - 2023-08-02 15:45:20 --> Helper loaded: cookie_helper
INFO - 2023-08-02 15:45:20 --> Database Driver Class Initialized
INFO - 2023-08-02 15:45:20 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-02 15:45:20 --> Parser Class Initialized
INFO - 2023-08-02 15:45:20 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-02 15:45:20 --> Pagination Class Initialized
INFO - 2023-08-02 15:45:20 --> Form Validation Class Initialized
INFO - 2023-08-02 15:45:20 --> Controller Class Initialized
INFO - 2023-08-02 15:45:20 --> Model Class Initialized
DEBUG - 2023-08-02 15:45:20 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-02 15:45:20 --> Model Class Initialized
DEBUG - 2023-08-02 15:45:20 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-02 15:45:20 --> Model Class Initialized
INFO - 2023-08-02 15:45:20 --> Model Class Initialized
INFO - 2023-08-02 15:45:20 --> Model Class Initialized
INFO - 2023-08-02 15:45:20 --> Model Class Initialized
DEBUG - 2023-08-02 15:45:20 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-02 15:45:20 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-02 15:45:20 --> Model Class Initialized
INFO - 2023-08-02 15:45:20 --> Model Class Initialized
INFO - 2023-08-02 15:45:20 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-08-02 15:45:20 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-08-02 15:45:20 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-08-02 15:45:20 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-08-02 15:45:20 --> Model Class Initialized
INFO - 2023-08-02 15:45:20 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-08-02 15:45:20 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-08-02 15:45:20 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-08-02 15:45:20 --> Final output sent to browser
DEBUG - 2023-08-02 15:45:20 --> Total execution time: 0.0845
