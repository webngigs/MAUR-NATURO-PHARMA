<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2023-12-07 04:55:13 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-12-07 04:55:13 --> Config Class Initialized
INFO - 2023-12-07 04:55:13 --> Hooks Class Initialized
DEBUG - 2023-12-07 04:55:13 --> UTF-8 Support Enabled
INFO - 2023-12-07 04:55:13 --> Utf8 Class Initialized
INFO - 2023-12-07 04:55:13 --> URI Class Initialized
INFO - 2023-12-07 04:55:13 --> Router Class Initialized
INFO - 2023-12-07 04:55:13 --> Output Class Initialized
INFO - 2023-12-07 04:55:13 --> Security Class Initialized
DEBUG - 2023-12-07 04:55:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-07 04:55:13 --> Input Class Initialized
INFO - 2023-12-07 04:55:13 --> Language Class Initialized
ERROR - 2023-12-07 04:55:13 --> 404 Page Not Found: Well-known/assetlinks.json
ERROR - 2023-12-07 06:18:05 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-12-07 06:18:05 --> Config Class Initialized
INFO - 2023-12-07 06:18:05 --> Hooks Class Initialized
DEBUG - 2023-12-07 06:18:05 --> UTF-8 Support Enabled
INFO - 2023-12-07 06:18:05 --> Utf8 Class Initialized
INFO - 2023-12-07 06:18:05 --> URI Class Initialized
DEBUG - 2023-12-07 06:18:05 --> No URI present. Default controller set.
INFO - 2023-12-07 06:18:05 --> Router Class Initialized
INFO - 2023-12-07 06:18:05 --> Output Class Initialized
INFO - 2023-12-07 06:18:05 --> Security Class Initialized
DEBUG - 2023-12-07 06:18:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-07 06:18:05 --> Input Class Initialized
INFO - 2023-12-07 06:18:05 --> Language Class Initialized
INFO - 2023-12-07 06:18:05 --> Loader Class Initialized
INFO - 2023-12-07 06:18:05 --> Helper loaded: url_helper
INFO - 2023-12-07 06:18:05 --> Helper loaded: file_helper
INFO - 2023-12-07 06:18:05 --> Helper loaded: html_helper
INFO - 2023-12-07 06:18:05 --> Helper loaded: text_helper
INFO - 2023-12-07 06:18:05 --> Helper loaded: form_helper
INFO - 2023-12-07 06:18:05 --> Helper loaded: lang_helper
INFO - 2023-12-07 06:18:05 --> Helper loaded: security_helper
INFO - 2023-12-07 06:18:05 --> Helper loaded: cookie_helper
INFO - 2023-12-07 06:18:05 --> Database Driver Class Initialized
INFO - 2023-12-07 06:18:05 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-07 06:18:05 --> Parser Class Initialized
INFO - 2023-12-07 06:18:05 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-12-07 06:18:05 --> Pagination Class Initialized
INFO - 2023-12-07 06:18:05 --> Form Validation Class Initialized
INFO - 2023-12-07 06:18:05 --> Controller Class Initialized
INFO - 2023-12-07 06:18:05 --> Model Class Initialized
DEBUG - 2023-12-07 06:18:05 --> Session class already loaded. Second attempt ignored.
ERROR - 2023-12-07 06:18:05 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-12-07 06:18:05 --> Config Class Initialized
INFO - 2023-12-07 06:18:05 --> Hooks Class Initialized
DEBUG - 2023-12-07 06:18:05 --> UTF-8 Support Enabled
INFO - 2023-12-07 06:18:05 --> Utf8 Class Initialized
INFO - 2023-12-07 06:18:05 --> URI Class Initialized
INFO - 2023-12-07 06:18:05 --> Router Class Initialized
INFO - 2023-12-07 06:18:05 --> Output Class Initialized
INFO - 2023-12-07 06:18:05 --> Security Class Initialized
DEBUG - 2023-12-07 06:18:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-07 06:18:05 --> Input Class Initialized
INFO - 2023-12-07 06:18:05 --> Language Class Initialized
INFO - 2023-12-07 06:18:05 --> Loader Class Initialized
INFO - 2023-12-07 06:18:05 --> Helper loaded: url_helper
INFO - 2023-12-07 06:18:05 --> Helper loaded: file_helper
INFO - 2023-12-07 06:18:05 --> Helper loaded: html_helper
INFO - 2023-12-07 06:18:05 --> Helper loaded: text_helper
INFO - 2023-12-07 06:18:05 --> Helper loaded: form_helper
INFO - 2023-12-07 06:18:05 --> Helper loaded: lang_helper
INFO - 2023-12-07 06:18:05 --> Helper loaded: security_helper
INFO - 2023-12-07 06:18:05 --> Helper loaded: cookie_helper
INFO - 2023-12-07 06:18:05 --> Database Driver Class Initialized
INFO - 2023-12-07 06:18:05 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-07 06:18:05 --> Parser Class Initialized
INFO - 2023-12-07 06:18:05 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-12-07 06:18:05 --> Pagination Class Initialized
INFO - 2023-12-07 06:18:05 --> Form Validation Class Initialized
INFO - 2023-12-07 06:18:05 --> Controller Class Initialized
INFO - 2023-12-07 06:18:05 --> Model Class Initialized
DEBUG - 2023-12-07 06:18:05 --> Session class already loaded. Second attempt ignored.
INFO - 2023-12-07 06:18:05 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2023-12-07 06:18:05 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-12-07 06:18:05 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-12-07 06:18:05 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-12-07 06:18:05 --> Model Class Initialized
INFO - 2023-12-07 06:18:05 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-12-07 06:18:05 --> Final output sent to browser
DEBUG - 2023-12-07 06:18:05 --> Total execution time: 0.0349
ERROR - 2023-12-07 06:18:08 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-12-07 06:18:08 --> Config Class Initialized
INFO - 2023-12-07 06:18:08 --> Hooks Class Initialized
DEBUG - 2023-12-07 06:18:08 --> UTF-8 Support Enabled
INFO - 2023-12-07 06:18:08 --> Utf8 Class Initialized
INFO - 2023-12-07 06:18:08 --> URI Class Initialized
INFO - 2023-12-07 06:18:08 --> Router Class Initialized
INFO - 2023-12-07 06:18:08 --> Output Class Initialized
INFO - 2023-12-07 06:18:08 --> Security Class Initialized
DEBUG - 2023-12-07 06:18:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-07 06:18:08 --> Input Class Initialized
INFO - 2023-12-07 06:18:08 --> Language Class Initialized
INFO - 2023-12-07 06:18:08 --> Loader Class Initialized
INFO - 2023-12-07 06:18:08 --> Helper loaded: url_helper
INFO - 2023-12-07 06:18:08 --> Helper loaded: file_helper
INFO - 2023-12-07 06:18:08 --> Helper loaded: html_helper
INFO - 2023-12-07 06:18:08 --> Helper loaded: text_helper
INFO - 2023-12-07 06:18:08 --> Helper loaded: form_helper
INFO - 2023-12-07 06:18:08 --> Helper loaded: lang_helper
INFO - 2023-12-07 06:18:08 --> Helper loaded: security_helper
INFO - 2023-12-07 06:18:08 --> Helper loaded: cookie_helper
INFO - 2023-12-07 06:18:08 --> Database Driver Class Initialized
INFO - 2023-12-07 06:18:08 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-07 06:18:08 --> Parser Class Initialized
INFO - 2023-12-07 06:18:08 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-12-07 06:18:08 --> Pagination Class Initialized
INFO - 2023-12-07 06:18:08 --> Form Validation Class Initialized
INFO - 2023-12-07 06:18:08 --> Controller Class Initialized
INFO - 2023-12-07 06:18:08 --> Model Class Initialized
DEBUG - 2023-12-07 06:18:08 --> Session class already loaded. Second attempt ignored.
INFO - 2023-12-07 06:18:08 --> Model Class Initialized
INFO - 2023-12-07 06:18:08 --> Final output sent to browser
DEBUG - 2023-12-07 06:18:08 --> Total execution time: 0.0197
ERROR - 2023-12-07 06:18:08 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-12-07 06:18:08 --> Config Class Initialized
INFO - 2023-12-07 06:18:08 --> Hooks Class Initialized
DEBUG - 2023-12-07 06:18:08 --> UTF-8 Support Enabled
INFO - 2023-12-07 06:18:08 --> Utf8 Class Initialized
INFO - 2023-12-07 06:18:08 --> URI Class Initialized
DEBUG - 2023-12-07 06:18:08 --> No URI present. Default controller set.
INFO - 2023-12-07 06:18:08 --> Router Class Initialized
INFO - 2023-12-07 06:18:08 --> Output Class Initialized
INFO - 2023-12-07 06:18:08 --> Security Class Initialized
DEBUG - 2023-12-07 06:18:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-07 06:18:08 --> Input Class Initialized
INFO - 2023-12-07 06:18:08 --> Language Class Initialized
INFO - 2023-12-07 06:18:08 --> Loader Class Initialized
INFO - 2023-12-07 06:18:08 --> Helper loaded: url_helper
INFO - 2023-12-07 06:18:08 --> Helper loaded: file_helper
INFO - 2023-12-07 06:18:08 --> Helper loaded: html_helper
INFO - 2023-12-07 06:18:08 --> Helper loaded: text_helper
INFO - 2023-12-07 06:18:08 --> Helper loaded: form_helper
INFO - 2023-12-07 06:18:08 --> Helper loaded: lang_helper
INFO - 2023-12-07 06:18:08 --> Helper loaded: security_helper
INFO - 2023-12-07 06:18:08 --> Helper loaded: cookie_helper
INFO - 2023-12-07 06:18:08 --> Database Driver Class Initialized
INFO - 2023-12-07 06:18:08 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-07 06:18:08 --> Parser Class Initialized
INFO - 2023-12-07 06:18:08 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-12-07 06:18:08 --> Pagination Class Initialized
INFO - 2023-12-07 06:18:08 --> Form Validation Class Initialized
INFO - 2023-12-07 06:18:08 --> Controller Class Initialized
INFO - 2023-12-07 06:18:08 --> Model Class Initialized
DEBUG - 2023-12-07 06:18:08 --> Session class already loaded. Second attempt ignored.
INFO - 2023-12-07 06:18:08 --> Model Class Initialized
DEBUG - 2023-12-07 06:18:08 --> Session class already loaded. Second attempt ignored.
INFO - 2023-12-07 06:18:08 --> Model Class Initialized
INFO - 2023-12-07 06:18:08 --> Model Class Initialized
INFO - 2023-12-07 06:18:08 --> Model Class Initialized
INFO - 2023-12-07 06:18:08 --> Model Class Initialized
DEBUG - 2023-12-07 06:18:08 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-12-07 06:18:08 --> Session class already loaded. Second attempt ignored.
INFO - 2023-12-07 06:18:08 --> Model Class Initialized
INFO - 2023-12-07 06:18:08 --> Model Class Initialized
INFO - 2023-12-07 06:18:09 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-12-07 06:18:09 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-12-07 06:18:09 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-12-07 06:18:09 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-12-07 06:18:09 --> Model Class Initialized
INFO - 2023-12-07 06:18:09 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-12-07 06:18:09 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-12-07 06:18:09 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-12-07 06:18:09 --> Final output sent to browser
DEBUG - 2023-12-07 06:18:09 --> Total execution time: 0.4436
ERROR - 2023-12-07 06:18:09 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-12-07 06:18:09 --> Config Class Initialized
INFO - 2023-12-07 06:18:09 --> Hooks Class Initialized
DEBUG - 2023-12-07 06:18:09 --> UTF-8 Support Enabled
INFO - 2023-12-07 06:18:09 --> Utf8 Class Initialized
INFO - 2023-12-07 06:18:09 --> URI Class Initialized
INFO - 2023-12-07 06:18:09 --> Router Class Initialized
INFO - 2023-12-07 06:18:09 --> Output Class Initialized
INFO - 2023-12-07 06:18:09 --> Security Class Initialized
DEBUG - 2023-12-07 06:18:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-07 06:18:09 --> Input Class Initialized
INFO - 2023-12-07 06:18:09 --> Language Class Initialized
INFO - 2023-12-07 06:18:09 --> Loader Class Initialized
INFO - 2023-12-07 06:18:09 --> Helper loaded: url_helper
INFO - 2023-12-07 06:18:09 --> Helper loaded: file_helper
INFO - 2023-12-07 06:18:09 --> Helper loaded: html_helper
INFO - 2023-12-07 06:18:09 --> Helper loaded: text_helper
INFO - 2023-12-07 06:18:09 --> Helper loaded: form_helper
INFO - 2023-12-07 06:18:09 --> Helper loaded: lang_helper
INFO - 2023-12-07 06:18:09 --> Helper loaded: security_helper
INFO - 2023-12-07 06:18:09 --> Helper loaded: cookie_helper
INFO - 2023-12-07 06:18:09 --> Database Driver Class Initialized
INFO - 2023-12-07 06:18:09 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-07 06:18:09 --> Parser Class Initialized
INFO - 2023-12-07 06:18:09 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-12-07 06:18:09 --> Pagination Class Initialized
INFO - 2023-12-07 06:18:09 --> Form Validation Class Initialized
INFO - 2023-12-07 06:18:09 --> Controller Class Initialized
DEBUG - 2023-12-07 06:18:09 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-12-07 06:18:09 --> Session class already loaded. Second attempt ignored.
INFO - 2023-12-07 06:18:09 --> Model Class Initialized
INFO - 2023-12-07 06:18:09 --> Final output sent to browser
DEBUG - 2023-12-07 06:18:09 --> Total execution time: 0.0140
ERROR - 2023-12-07 06:18:26 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-12-07 06:18:26 --> Config Class Initialized
INFO - 2023-12-07 06:18:26 --> Hooks Class Initialized
DEBUG - 2023-12-07 06:18:26 --> UTF-8 Support Enabled
INFO - 2023-12-07 06:18:26 --> Utf8 Class Initialized
INFO - 2023-12-07 06:18:26 --> URI Class Initialized
INFO - 2023-12-07 06:18:26 --> Router Class Initialized
INFO - 2023-12-07 06:18:26 --> Output Class Initialized
INFO - 2023-12-07 06:18:26 --> Security Class Initialized
DEBUG - 2023-12-07 06:18:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-07 06:18:26 --> Input Class Initialized
INFO - 2023-12-07 06:18:26 --> Language Class Initialized
INFO - 2023-12-07 06:18:26 --> Loader Class Initialized
INFO - 2023-12-07 06:18:26 --> Helper loaded: url_helper
INFO - 2023-12-07 06:18:26 --> Helper loaded: file_helper
INFO - 2023-12-07 06:18:26 --> Helper loaded: html_helper
INFO - 2023-12-07 06:18:26 --> Helper loaded: text_helper
INFO - 2023-12-07 06:18:26 --> Helper loaded: form_helper
INFO - 2023-12-07 06:18:26 --> Helper loaded: lang_helper
INFO - 2023-12-07 06:18:26 --> Helper loaded: security_helper
INFO - 2023-12-07 06:18:26 --> Helper loaded: cookie_helper
INFO - 2023-12-07 06:18:26 --> Database Driver Class Initialized
INFO - 2023-12-07 06:18:26 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-07 06:18:26 --> Parser Class Initialized
INFO - 2023-12-07 06:18:26 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-12-07 06:18:26 --> Pagination Class Initialized
INFO - 2023-12-07 06:18:26 --> Form Validation Class Initialized
INFO - 2023-12-07 06:18:26 --> Controller Class Initialized
DEBUG - 2023-12-07 06:18:26 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-12-07 06:18:26 --> Session class already loaded. Second attempt ignored.
INFO - 2023-12-07 06:18:26 --> Model Class Initialized
INFO - 2023-12-07 06:18:26 --> Model Class Initialized
DEBUG - 2023-12-07 06:18:26 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-12-07 06:18:26 --> Session class already loaded. Second attempt ignored.
INFO - 2023-12-07 06:18:26 --> Model Class Initialized
DEBUG - 2023-12-07 06:18:26 --> Session class already loaded. Second attempt ignored.
INFO - 2023-12-07 06:18:26 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/gst/list.php
DEBUG - 2023-12-07 06:18:26 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-12-07 06:18:26 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-12-07 06:18:26 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-12-07 06:18:26 --> Model Class Initialized
INFO - 2023-12-07 06:18:26 --> Model Class Initialized
INFO - 2023-12-07 06:18:26 --> Model Class Initialized
INFO - 2023-12-07 06:18:26 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-12-07 06:18:26 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-12-07 06:18:26 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-12-07 06:18:26 --> Final output sent to browser
DEBUG - 2023-12-07 06:18:26 --> Total execution time: 0.2420
ERROR - 2023-12-07 06:18:31 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-12-07 06:18:31 --> Config Class Initialized
INFO - 2023-12-07 06:18:31 --> Hooks Class Initialized
DEBUG - 2023-12-07 06:18:31 --> UTF-8 Support Enabled
INFO - 2023-12-07 06:18:31 --> Utf8 Class Initialized
INFO - 2023-12-07 06:18:31 --> URI Class Initialized
INFO - 2023-12-07 06:18:31 --> Router Class Initialized
INFO - 2023-12-07 06:18:31 --> Output Class Initialized
INFO - 2023-12-07 06:18:31 --> Security Class Initialized
DEBUG - 2023-12-07 06:18:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-07 06:18:31 --> Input Class Initialized
INFO - 2023-12-07 06:18:31 --> Language Class Initialized
INFO - 2023-12-07 06:18:31 --> Loader Class Initialized
INFO - 2023-12-07 06:18:31 --> Helper loaded: url_helper
INFO - 2023-12-07 06:18:31 --> Helper loaded: file_helper
INFO - 2023-12-07 06:18:31 --> Helper loaded: html_helper
INFO - 2023-12-07 06:18:31 --> Helper loaded: text_helper
INFO - 2023-12-07 06:18:31 --> Helper loaded: form_helper
INFO - 2023-12-07 06:18:31 --> Helper loaded: lang_helper
INFO - 2023-12-07 06:18:31 --> Helper loaded: security_helper
INFO - 2023-12-07 06:18:31 --> Helper loaded: cookie_helper
INFO - 2023-12-07 06:18:31 --> Database Driver Class Initialized
INFO - 2023-12-07 06:18:31 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-07 06:18:31 --> Parser Class Initialized
INFO - 2023-12-07 06:18:31 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-12-07 06:18:31 --> Pagination Class Initialized
INFO - 2023-12-07 06:18:31 --> Form Validation Class Initialized
INFO - 2023-12-07 06:18:31 --> Controller Class Initialized
INFO - 2023-12-07 06:18:31 --> Model Class Initialized
DEBUG - 2023-12-07 06:18:31 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-12-07 06:18:31 --> Session class already loaded. Second attempt ignored.
INFO - 2023-12-07 06:18:31 --> Model Class Initialized
DEBUG - 2023-12-07 06:18:31 --> Session class already loaded. Second attempt ignored.
INFO - 2023-12-07 06:18:31 --> Model Class Initialized
INFO - 2023-12-07 06:18:31 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice.php
DEBUG - 2023-12-07 06:18:31 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-12-07 06:18:31 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-12-07 06:18:31 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-12-07 06:18:31 --> Model Class Initialized
INFO - 2023-12-07 06:18:31 --> Model Class Initialized
INFO - 2023-12-07 06:18:31 --> Model Class Initialized
INFO - 2023-12-07 06:18:31 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-12-07 06:18:31 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-12-07 06:18:31 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-12-07 06:18:31 --> Final output sent to browser
DEBUG - 2023-12-07 06:18:31 --> Total execution time: 0.2169
ERROR - 2023-12-07 06:18:32 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-12-07 06:18:32 --> Config Class Initialized
INFO - 2023-12-07 06:18:32 --> Hooks Class Initialized
DEBUG - 2023-12-07 06:18:32 --> UTF-8 Support Enabled
INFO - 2023-12-07 06:18:32 --> Utf8 Class Initialized
INFO - 2023-12-07 06:18:32 --> URI Class Initialized
INFO - 2023-12-07 06:18:32 --> Router Class Initialized
INFO - 2023-12-07 06:18:32 --> Output Class Initialized
INFO - 2023-12-07 06:18:32 --> Security Class Initialized
DEBUG - 2023-12-07 06:18:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-07 06:18:32 --> Input Class Initialized
INFO - 2023-12-07 06:18:32 --> Language Class Initialized
INFO - 2023-12-07 06:18:32 --> Loader Class Initialized
INFO - 2023-12-07 06:18:32 --> Helper loaded: url_helper
INFO - 2023-12-07 06:18:32 --> Helper loaded: file_helper
INFO - 2023-12-07 06:18:32 --> Helper loaded: html_helper
INFO - 2023-12-07 06:18:32 --> Helper loaded: text_helper
INFO - 2023-12-07 06:18:32 --> Helper loaded: form_helper
INFO - 2023-12-07 06:18:32 --> Helper loaded: lang_helper
INFO - 2023-12-07 06:18:32 --> Helper loaded: security_helper
INFO - 2023-12-07 06:18:32 --> Helper loaded: cookie_helper
INFO - 2023-12-07 06:18:32 --> Database Driver Class Initialized
INFO - 2023-12-07 06:18:32 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-07 06:18:32 --> Parser Class Initialized
INFO - 2023-12-07 06:18:32 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-12-07 06:18:32 --> Pagination Class Initialized
INFO - 2023-12-07 06:18:32 --> Form Validation Class Initialized
INFO - 2023-12-07 06:18:32 --> Controller Class Initialized
INFO - 2023-12-07 06:18:32 --> Model Class Initialized
DEBUG - 2023-12-07 06:18:32 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-12-07 06:18:32 --> Session class already loaded. Second attempt ignored.
INFO - 2023-12-07 06:18:32 --> Model Class Initialized
DEBUG - 2023-12-07 06:18:32 --> Session class already loaded. Second attempt ignored.
INFO - 2023-12-07 06:18:32 --> Model Class Initialized
INFO - 2023-12-07 06:18:32 --> Final output sent to browser
DEBUG - 2023-12-07 06:18:32 --> Total execution time: 0.0615
ERROR - 2023-12-07 06:18:36 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-12-07 06:18:36 --> Config Class Initialized
INFO - 2023-12-07 06:18:36 --> Hooks Class Initialized
DEBUG - 2023-12-07 06:18:36 --> UTF-8 Support Enabled
INFO - 2023-12-07 06:18:36 --> Utf8 Class Initialized
INFO - 2023-12-07 06:18:36 --> URI Class Initialized
INFO - 2023-12-07 06:18:36 --> Router Class Initialized
INFO - 2023-12-07 06:18:36 --> Output Class Initialized
INFO - 2023-12-07 06:18:36 --> Security Class Initialized
DEBUG - 2023-12-07 06:18:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-07 06:18:36 --> Input Class Initialized
INFO - 2023-12-07 06:18:36 --> Language Class Initialized
INFO - 2023-12-07 06:18:36 --> Loader Class Initialized
INFO - 2023-12-07 06:18:36 --> Helper loaded: url_helper
INFO - 2023-12-07 06:18:36 --> Helper loaded: file_helper
INFO - 2023-12-07 06:18:36 --> Helper loaded: html_helper
INFO - 2023-12-07 06:18:36 --> Helper loaded: text_helper
INFO - 2023-12-07 06:18:36 --> Helper loaded: form_helper
INFO - 2023-12-07 06:18:36 --> Helper loaded: lang_helper
INFO - 2023-12-07 06:18:36 --> Helper loaded: security_helper
INFO - 2023-12-07 06:18:36 --> Helper loaded: cookie_helper
INFO - 2023-12-07 06:18:36 --> Database Driver Class Initialized
INFO - 2023-12-07 06:18:36 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-07 06:18:36 --> Parser Class Initialized
INFO - 2023-12-07 06:18:36 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-12-07 06:18:36 --> Pagination Class Initialized
INFO - 2023-12-07 06:18:36 --> Form Validation Class Initialized
INFO - 2023-12-07 06:18:36 --> Controller Class Initialized
INFO - 2023-12-07 06:18:36 --> Model Class Initialized
DEBUG - 2023-12-07 06:18:36 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-12-07 06:18:36 --> Session class already loaded. Second attempt ignored.
INFO - 2023-12-07 06:18:36 --> Model Class Initialized
DEBUG - 2023-12-07 06:18:36 --> Session class already loaded. Second attempt ignored.
INFO - 2023-12-07 06:18:36 --> Model Class Initialized
INFO - 2023-12-07 06:18:37 --> Final output sent to browser
DEBUG - 2023-12-07 06:18:37 --> Total execution time: 1.0309
ERROR - 2023-12-07 06:18:41 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-12-07 06:18:41 --> Config Class Initialized
INFO - 2023-12-07 06:18:41 --> Hooks Class Initialized
DEBUG - 2023-12-07 06:18:41 --> UTF-8 Support Enabled
INFO - 2023-12-07 06:18:41 --> Utf8 Class Initialized
INFO - 2023-12-07 06:18:41 --> URI Class Initialized
DEBUG - 2023-12-07 06:18:41 --> No URI present. Default controller set.
INFO - 2023-12-07 06:18:41 --> Router Class Initialized
INFO - 2023-12-07 06:18:41 --> Output Class Initialized
INFO - 2023-12-07 06:18:41 --> Security Class Initialized
DEBUG - 2023-12-07 06:18:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-07 06:18:41 --> Input Class Initialized
INFO - 2023-12-07 06:18:41 --> Language Class Initialized
INFO - 2023-12-07 06:18:41 --> Loader Class Initialized
INFO - 2023-12-07 06:18:41 --> Helper loaded: url_helper
INFO - 2023-12-07 06:18:41 --> Helper loaded: file_helper
INFO - 2023-12-07 06:18:41 --> Helper loaded: html_helper
INFO - 2023-12-07 06:18:41 --> Helper loaded: text_helper
INFO - 2023-12-07 06:18:41 --> Helper loaded: form_helper
INFO - 2023-12-07 06:18:41 --> Helper loaded: lang_helper
INFO - 2023-12-07 06:18:41 --> Helper loaded: security_helper
INFO - 2023-12-07 06:18:41 --> Helper loaded: cookie_helper
INFO - 2023-12-07 06:18:41 --> Database Driver Class Initialized
INFO - 2023-12-07 06:18:41 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-07 06:18:41 --> Parser Class Initialized
INFO - 2023-12-07 06:18:41 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-12-07 06:18:41 --> Pagination Class Initialized
INFO - 2023-12-07 06:18:41 --> Form Validation Class Initialized
INFO - 2023-12-07 06:18:41 --> Controller Class Initialized
INFO - 2023-12-07 06:18:41 --> Model Class Initialized
DEBUG - 2023-12-07 06:18:41 --> Session class already loaded. Second attempt ignored.
INFO - 2023-12-07 06:18:41 --> Model Class Initialized
DEBUG - 2023-12-07 06:18:41 --> Session class already loaded. Second attempt ignored.
INFO - 2023-12-07 06:18:41 --> Model Class Initialized
INFO - 2023-12-07 06:18:41 --> Model Class Initialized
INFO - 2023-12-07 06:18:41 --> Model Class Initialized
INFO - 2023-12-07 06:18:41 --> Model Class Initialized
DEBUG - 2023-12-07 06:18:41 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-12-07 06:18:41 --> Session class already loaded. Second attempt ignored.
INFO - 2023-12-07 06:18:41 --> Model Class Initialized
INFO - 2023-12-07 06:18:41 --> Model Class Initialized
INFO - 2023-12-07 06:18:41 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-12-07 06:18:41 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-12-07 06:18:41 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-12-07 06:18:41 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-12-07 06:18:41 --> Model Class Initialized
INFO - 2023-12-07 06:18:41 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-12-07 06:18:41 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-12-07 06:18:41 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-12-07 06:18:41 --> Final output sent to browser
DEBUG - 2023-12-07 06:18:41 --> Total execution time: 0.3978
ERROR - 2023-12-07 06:24:18 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-12-07 06:24:18 --> Config Class Initialized
INFO - 2023-12-07 06:24:18 --> Hooks Class Initialized
DEBUG - 2023-12-07 06:24:18 --> UTF-8 Support Enabled
INFO - 2023-12-07 06:24:18 --> Utf8 Class Initialized
INFO - 2023-12-07 06:24:18 --> URI Class Initialized
DEBUG - 2023-12-07 06:24:18 --> No URI present. Default controller set.
INFO - 2023-12-07 06:24:18 --> Router Class Initialized
INFO - 2023-12-07 06:24:18 --> Output Class Initialized
INFO - 2023-12-07 06:24:18 --> Security Class Initialized
DEBUG - 2023-12-07 06:24:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-07 06:24:18 --> Input Class Initialized
INFO - 2023-12-07 06:24:18 --> Language Class Initialized
INFO - 2023-12-07 06:24:18 --> Loader Class Initialized
INFO - 2023-12-07 06:24:18 --> Helper loaded: url_helper
INFO - 2023-12-07 06:24:18 --> Helper loaded: file_helper
INFO - 2023-12-07 06:24:18 --> Helper loaded: html_helper
INFO - 2023-12-07 06:24:18 --> Helper loaded: text_helper
INFO - 2023-12-07 06:24:18 --> Helper loaded: form_helper
INFO - 2023-12-07 06:24:18 --> Helper loaded: lang_helper
INFO - 2023-12-07 06:24:18 --> Helper loaded: security_helper
INFO - 2023-12-07 06:24:18 --> Helper loaded: cookie_helper
INFO - 2023-12-07 06:24:18 --> Database Driver Class Initialized
INFO - 2023-12-07 06:24:18 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-07 06:24:18 --> Parser Class Initialized
INFO - 2023-12-07 06:24:18 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-12-07 06:24:18 --> Pagination Class Initialized
INFO - 2023-12-07 06:24:18 --> Form Validation Class Initialized
INFO - 2023-12-07 06:24:18 --> Controller Class Initialized
INFO - 2023-12-07 06:24:18 --> Model Class Initialized
DEBUG - 2023-12-07 06:24:18 --> Session class already loaded. Second attempt ignored.
ERROR - 2023-12-07 06:42:04 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-12-07 06:42:04 --> Config Class Initialized
INFO - 2023-12-07 06:42:04 --> Hooks Class Initialized
DEBUG - 2023-12-07 06:42:04 --> UTF-8 Support Enabled
INFO - 2023-12-07 06:42:04 --> Utf8 Class Initialized
INFO - 2023-12-07 06:42:04 --> URI Class Initialized
DEBUG - 2023-12-07 06:42:04 --> No URI present. Default controller set.
INFO - 2023-12-07 06:42:04 --> Router Class Initialized
INFO - 2023-12-07 06:42:04 --> Output Class Initialized
INFO - 2023-12-07 06:42:04 --> Security Class Initialized
DEBUG - 2023-12-07 06:42:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-07 06:42:04 --> Input Class Initialized
INFO - 2023-12-07 06:42:04 --> Language Class Initialized
INFO - 2023-12-07 06:42:04 --> Loader Class Initialized
INFO - 2023-12-07 06:42:04 --> Helper loaded: url_helper
INFO - 2023-12-07 06:42:04 --> Helper loaded: file_helper
INFO - 2023-12-07 06:42:04 --> Helper loaded: html_helper
INFO - 2023-12-07 06:42:04 --> Helper loaded: text_helper
INFO - 2023-12-07 06:42:04 --> Helper loaded: form_helper
INFO - 2023-12-07 06:42:04 --> Helper loaded: lang_helper
INFO - 2023-12-07 06:42:04 --> Helper loaded: security_helper
INFO - 2023-12-07 06:42:04 --> Helper loaded: cookie_helper
INFO - 2023-12-07 06:42:04 --> Database Driver Class Initialized
INFO - 2023-12-07 06:42:04 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-07 06:42:04 --> Parser Class Initialized
INFO - 2023-12-07 06:42:04 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-12-07 06:42:04 --> Pagination Class Initialized
INFO - 2023-12-07 06:42:04 --> Form Validation Class Initialized
INFO - 2023-12-07 06:42:04 --> Controller Class Initialized
INFO - 2023-12-07 06:42:04 --> Model Class Initialized
DEBUG - 2023-12-07 06:42:04 --> Session class already loaded. Second attempt ignored.
INFO - 2023-12-07 06:42:04 --> Model Class Initialized
DEBUG - 2023-12-07 06:42:04 --> Session class already loaded. Second attempt ignored.
INFO - 2023-12-07 06:42:04 --> Model Class Initialized
INFO - 2023-12-07 06:42:04 --> Model Class Initialized
INFO - 2023-12-07 06:42:04 --> Model Class Initialized
INFO - 2023-12-07 06:42:04 --> Model Class Initialized
DEBUG - 2023-12-07 06:42:04 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-12-07 06:42:04 --> Session class already loaded. Second attempt ignored.
INFO - 2023-12-07 06:42:04 --> Model Class Initialized
INFO - 2023-12-07 06:42:05 --> Model Class Initialized
INFO - 2023-12-07 06:42:05 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-12-07 06:42:05 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-12-07 06:42:05 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-12-07 06:42:05 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-12-07 06:42:05 --> Model Class Initialized
INFO - 2023-12-07 06:42:05 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-12-07 06:42:05 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-12-07 06:42:05 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-12-07 06:42:05 --> Final output sent to browser
DEBUG - 2023-12-07 06:42:05 --> Total execution time: 0.3931
ERROR - 2023-12-07 06:42:14 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-12-07 06:42:14 --> Config Class Initialized
INFO - 2023-12-07 06:42:14 --> Hooks Class Initialized
DEBUG - 2023-12-07 06:42:14 --> UTF-8 Support Enabled
INFO - 2023-12-07 06:42:14 --> Utf8 Class Initialized
INFO - 2023-12-07 06:42:14 --> URI Class Initialized
INFO - 2023-12-07 06:42:14 --> Router Class Initialized
INFO - 2023-12-07 06:42:14 --> Output Class Initialized
INFO - 2023-12-07 06:42:14 --> Security Class Initialized
DEBUG - 2023-12-07 06:42:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-07 06:42:14 --> Input Class Initialized
INFO - 2023-12-07 06:42:14 --> Language Class Initialized
INFO - 2023-12-07 06:42:14 --> Loader Class Initialized
INFO - 2023-12-07 06:42:14 --> Helper loaded: url_helper
INFO - 2023-12-07 06:42:14 --> Helper loaded: file_helper
INFO - 2023-12-07 06:42:14 --> Helper loaded: html_helper
INFO - 2023-12-07 06:42:14 --> Helper loaded: text_helper
INFO - 2023-12-07 06:42:14 --> Helper loaded: form_helper
INFO - 2023-12-07 06:42:14 --> Helper loaded: lang_helper
INFO - 2023-12-07 06:42:14 --> Helper loaded: security_helper
INFO - 2023-12-07 06:42:14 --> Helper loaded: cookie_helper
INFO - 2023-12-07 06:42:14 --> Database Driver Class Initialized
INFO - 2023-12-07 06:42:14 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-07 06:42:14 --> Parser Class Initialized
INFO - 2023-12-07 06:42:14 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-12-07 06:42:14 --> Pagination Class Initialized
INFO - 2023-12-07 06:42:14 --> Form Validation Class Initialized
INFO - 2023-12-07 06:42:14 --> Controller Class Initialized
INFO - 2023-12-07 06:42:14 --> Model Class Initialized
DEBUG - 2023-12-07 06:42:14 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-12-07 06:42:14 --> Session class already loaded. Second attempt ignored.
INFO - 2023-12-07 06:42:14 --> Model Class Initialized
DEBUG - 2023-12-07 06:42:14 --> Session class already loaded. Second attempt ignored.
INFO - 2023-12-07 06:42:14 --> Model Class Initialized
INFO - 2023-12-07 06:42:14 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice.php
DEBUG - 2023-12-07 06:42:14 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-12-07 06:42:14 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-12-07 06:42:14 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-12-07 06:42:14 --> Model Class Initialized
INFO - 2023-12-07 06:42:14 --> Model Class Initialized
INFO - 2023-12-07 06:42:14 --> Model Class Initialized
INFO - 2023-12-07 06:42:14 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-12-07 06:42:14 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-12-07 06:42:14 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-12-07 06:42:14 --> Final output sent to browser
DEBUG - 2023-12-07 06:42:14 --> Total execution time: 0.2211
ERROR - 2023-12-07 06:42:15 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-12-07 06:42:15 --> Config Class Initialized
INFO - 2023-12-07 06:42:15 --> Hooks Class Initialized
DEBUG - 2023-12-07 06:42:15 --> UTF-8 Support Enabled
INFO - 2023-12-07 06:42:15 --> Utf8 Class Initialized
INFO - 2023-12-07 06:42:15 --> URI Class Initialized
INFO - 2023-12-07 06:42:15 --> Router Class Initialized
INFO - 2023-12-07 06:42:15 --> Output Class Initialized
INFO - 2023-12-07 06:42:15 --> Security Class Initialized
DEBUG - 2023-12-07 06:42:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-07 06:42:15 --> Input Class Initialized
INFO - 2023-12-07 06:42:15 --> Language Class Initialized
INFO - 2023-12-07 06:42:15 --> Loader Class Initialized
INFO - 2023-12-07 06:42:15 --> Helper loaded: url_helper
INFO - 2023-12-07 06:42:15 --> Helper loaded: file_helper
INFO - 2023-12-07 06:42:15 --> Helper loaded: html_helper
INFO - 2023-12-07 06:42:15 --> Helper loaded: text_helper
INFO - 2023-12-07 06:42:15 --> Helper loaded: form_helper
INFO - 2023-12-07 06:42:15 --> Helper loaded: lang_helper
INFO - 2023-12-07 06:42:15 --> Helper loaded: security_helper
INFO - 2023-12-07 06:42:15 --> Helper loaded: cookie_helper
INFO - 2023-12-07 06:42:15 --> Database Driver Class Initialized
INFO - 2023-12-07 06:42:15 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-07 06:42:15 --> Parser Class Initialized
INFO - 2023-12-07 06:42:15 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-12-07 06:42:15 --> Pagination Class Initialized
INFO - 2023-12-07 06:42:15 --> Form Validation Class Initialized
INFO - 2023-12-07 06:42:15 --> Controller Class Initialized
INFO - 2023-12-07 06:42:15 --> Model Class Initialized
DEBUG - 2023-12-07 06:42:15 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-12-07 06:42:15 --> Session class already loaded. Second attempt ignored.
INFO - 2023-12-07 06:42:15 --> Model Class Initialized
DEBUG - 2023-12-07 06:42:15 --> Session class already loaded. Second attempt ignored.
INFO - 2023-12-07 06:42:15 --> Model Class Initialized
INFO - 2023-12-07 06:42:15 --> Final output sent to browser
DEBUG - 2023-12-07 06:42:15 --> Total execution time: 0.0680
ERROR - 2023-12-07 06:44:24 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-12-07 06:44:24 --> Config Class Initialized
INFO - 2023-12-07 06:44:24 --> Hooks Class Initialized
DEBUG - 2023-12-07 06:44:24 --> UTF-8 Support Enabled
INFO - 2023-12-07 06:44:24 --> Utf8 Class Initialized
INFO - 2023-12-07 06:44:24 --> URI Class Initialized
DEBUG - 2023-12-07 06:44:24 --> No URI present. Default controller set.
INFO - 2023-12-07 06:44:24 --> Router Class Initialized
INFO - 2023-12-07 06:44:24 --> Output Class Initialized
INFO - 2023-12-07 06:44:24 --> Security Class Initialized
DEBUG - 2023-12-07 06:44:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-07 06:44:24 --> Input Class Initialized
INFO - 2023-12-07 06:44:24 --> Language Class Initialized
INFO - 2023-12-07 06:44:24 --> Loader Class Initialized
INFO - 2023-12-07 06:44:24 --> Helper loaded: url_helper
INFO - 2023-12-07 06:44:24 --> Helper loaded: file_helper
INFO - 2023-12-07 06:44:24 --> Helper loaded: html_helper
INFO - 2023-12-07 06:44:24 --> Helper loaded: text_helper
INFO - 2023-12-07 06:44:24 --> Helper loaded: form_helper
INFO - 2023-12-07 06:44:24 --> Helper loaded: lang_helper
INFO - 2023-12-07 06:44:24 --> Helper loaded: security_helper
INFO - 2023-12-07 06:44:24 --> Helper loaded: cookie_helper
INFO - 2023-12-07 06:44:24 --> Database Driver Class Initialized
INFO - 2023-12-07 06:44:24 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-07 06:44:24 --> Parser Class Initialized
INFO - 2023-12-07 06:44:24 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-12-07 06:44:24 --> Pagination Class Initialized
INFO - 2023-12-07 06:44:24 --> Form Validation Class Initialized
INFO - 2023-12-07 06:44:24 --> Controller Class Initialized
INFO - 2023-12-07 06:44:24 --> Model Class Initialized
DEBUG - 2023-12-07 06:44:24 --> Session class already loaded. Second attempt ignored.
ERROR - 2023-12-07 06:44:25 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-12-07 06:44:25 --> Config Class Initialized
INFO - 2023-12-07 06:44:25 --> Hooks Class Initialized
DEBUG - 2023-12-07 06:44:25 --> UTF-8 Support Enabled
INFO - 2023-12-07 06:44:25 --> Utf8 Class Initialized
INFO - 2023-12-07 06:44:25 --> URI Class Initialized
INFO - 2023-12-07 06:44:25 --> Router Class Initialized
INFO - 2023-12-07 06:44:25 --> Output Class Initialized
INFO - 2023-12-07 06:44:25 --> Security Class Initialized
DEBUG - 2023-12-07 06:44:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-07 06:44:25 --> Input Class Initialized
INFO - 2023-12-07 06:44:25 --> Language Class Initialized
INFO - 2023-12-07 06:44:25 --> Loader Class Initialized
INFO - 2023-12-07 06:44:25 --> Helper loaded: url_helper
INFO - 2023-12-07 06:44:25 --> Helper loaded: file_helper
INFO - 2023-12-07 06:44:25 --> Helper loaded: html_helper
INFO - 2023-12-07 06:44:25 --> Helper loaded: text_helper
INFO - 2023-12-07 06:44:25 --> Helper loaded: form_helper
INFO - 2023-12-07 06:44:25 --> Helper loaded: lang_helper
INFO - 2023-12-07 06:44:25 --> Helper loaded: security_helper
INFO - 2023-12-07 06:44:25 --> Helper loaded: cookie_helper
INFO - 2023-12-07 06:44:25 --> Database Driver Class Initialized
INFO - 2023-12-07 06:44:25 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-07 06:44:25 --> Parser Class Initialized
INFO - 2023-12-07 06:44:25 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-12-07 06:44:25 --> Pagination Class Initialized
INFO - 2023-12-07 06:44:25 --> Form Validation Class Initialized
INFO - 2023-12-07 06:44:25 --> Controller Class Initialized
INFO - 2023-12-07 06:44:25 --> Model Class Initialized
DEBUG - 2023-12-07 06:44:25 --> Session class already loaded. Second attempt ignored.
INFO - 2023-12-07 06:44:25 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2023-12-07 06:44:25 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-12-07 06:44:25 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-12-07 06:44:25 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-12-07 06:44:25 --> Model Class Initialized
INFO - 2023-12-07 06:44:25 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-12-07 06:44:25 --> Final output sent to browser
DEBUG - 2023-12-07 06:44:25 --> Total execution time: 0.0287
ERROR - 2023-12-07 08:40:00 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-12-07 08:40:00 --> Config Class Initialized
INFO - 2023-12-07 08:40:00 --> Hooks Class Initialized
DEBUG - 2023-12-07 08:40:00 --> UTF-8 Support Enabled
INFO - 2023-12-07 08:40:00 --> Utf8 Class Initialized
INFO - 2023-12-07 08:40:00 --> URI Class Initialized
DEBUG - 2023-12-07 08:40:00 --> No URI present. Default controller set.
INFO - 2023-12-07 08:40:00 --> Router Class Initialized
INFO - 2023-12-07 08:40:00 --> Output Class Initialized
INFO - 2023-12-07 08:40:00 --> Security Class Initialized
DEBUG - 2023-12-07 08:40:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-07 08:40:00 --> Input Class Initialized
INFO - 2023-12-07 08:40:00 --> Language Class Initialized
INFO - 2023-12-07 08:40:00 --> Loader Class Initialized
INFO - 2023-12-07 08:40:00 --> Helper loaded: url_helper
INFO - 2023-12-07 08:40:00 --> Helper loaded: file_helper
INFO - 2023-12-07 08:40:00 --> Helper loaded: html_helper
INFO - 2023-12-07 08:40:00 --> Helper loaded: text_helper
INFO - 2023-12-07 08:40:00 --> Helper loaded: form_helper
INFO - 2023-12-07 08:40:00 --> Helper loaded: lang_helper
INFO - 2023-12-07 08:40:00 --> Helper loaded: security_helper
INFO - 2023-12-07 08:40:00 --> Helper loaded: cookie_helper
INFO - 2023-12-07 08:40:00 --> Database Driver Class Initialized
INFO - 2023-12-07 08:40:00 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-07 08:40:00 --> Parser Class Initialized
INFO - 2023-12-07 08:40:00 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-12-07 08:40:00 --> Pagination Class Initialized
INFO - 2023-12-07 08:40:00 --> Form Validation Class Initialized
INFO - 2023-12-07 08:40:00 --> Controller Class Initialized
INFO - 2023-12-07 08:40:00 --> Model Class Initialized
DEBUG - 2023-12-07 08:40:00 --> Session class already loaded. Second attempt ignored.
ERROR - 2023-12-07 08:40:00 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-12-07 08:40:00 --> Config Class Initialized
INFO - 2023-12-07 08:40:00 --> Hooks Class Initialized
DEBUG - 2023-12-07 08:40:00 --> UTF-8 Support Enabled
INFO - 2023-12-07 08:40:00 --> Utf8 Class Initialized
INFO - 2023-12-07 08:40:00 --> URI Class Initialized
INFO - 2023-12-07 08:40:00 --> Router Class Initialized
INFO - 2023-12-07 08:40:00 --> Output Class Initialized
INFO - 2023-12-07 08:40:00 --> Security Class Initialized
DEBUG - 2023-12-07 08:40:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-07 08:40:00 --> Input Class Initialized
INFO - 2023-12-07 08:40:00 --> Language Class Initialized
INFO - 2023-12-07 08:40:00 --> Loader Class Initialized
INFO - 2023-12-07 08:40:00 --> Helper loaded: url_helper
INFO - 2023-12-07 08:40:00 --> Helper loaded: file_helper
INFO - 2023-12-07 08:40:00 --> Helper loaded: html_helper
INFO - 2023-12-07 08:40:00 --> Helper loaded: text_helper
INFO - 2023-12-07 08:40:00 --> Helper loaded: form_helper
INFO - 2023-12-07 08:40:00 --> Helper loaded: lang_helper
INFO - 2023-12-07 08:40:00 --> Helper loaded: security_helper
INFO - 2023-12-07 08:40:00 --> Helper loaded: cookie_helper
INFO - 2023-12-07 08:40:00 --> Database Driver Class Initialized
INFO - 2023-12-07 08:40:00 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-07 08:40:00 --> Parser Class Initialized
INFO - 2023-12-07 08:40:00 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-12-07 08:40:00 --> Pagination Class Initialized
INFO - 2023-12-07 08:40:00 --> Form Validation Class Initialized
INFO - 2023-12-07 08:40:00 --> Controller Class Initialized
INFO - 2023-12-07 08:40:00 --> Model Class Initialized
DEBUG - 2023-12-07 08:40:00 --> Session class already loaded. Second attempt ignored.
INFO - 2023-12-07 08:40:00 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2023-12-07 08:40:00 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-12-07 08:40:00 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-12-07 08:40:00 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-12-07 08:40:00 --> Model Class Initialized
INFO - 2023-12-07 08:40:00 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-12-07 08:40:00 --> Final output sent to browser
DEBUG - 2023-12-07 08:40:00 --> Total execution time: 0.0284
ERROR - 2023-12-07 09:08:31 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-12-07 09:08:31 --> Config Class Initialized
INFO - 2023-12-07 09:08:31 --> Hooks Class Initialized
DEBUG - 2023-12-07 09:08:31 --> UTF-8 Support Enabled
INFO - 2023-12-07 09:08:31 --> Utf8 Class Initialized
INFO - 2023-12-07 09:08:31 --> URI Class Initialized
DEBUG - 2023-12-07 09:08:31 --> No URI present. Default controller set.
INFO - 2023-12-07 09:08:31 --> Router Class Initialized
INFO - 2023-12-07 09:08:31 --> Output Class Initialized
INFO - 2023-12-07 09:08:31 --> Security Class Initialized
DEBUG - 2023-12-07 09:08:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-07 09:08:31 --> Input Class Initialized
INFO - 2023-12-07 09:08:31 --> Language Class Initialized
INFO - 2023-12-07 09:08:31 --> Loader Class Initialized
INFO - 2023-12-07 09:08:31 --> Helper loaded: url_helper
INFO - 2023-12-07 09:08:31 --> Helper loaded: file_helper
INFO - 2023-12-07 09:08:31 --> Helper loaded: html_helper
INFO - 2023-12-07 09:08:31 --> Helper loaded: text_helper
INFO - 2023-12-07 09:08:31 --> Helper loaded: form_helper
INFO - 2023-12-07 09:08:31 --> Helper loaded: lang_helper
INFO - 2023-12-07 09:08:31 --> Helper loaded: security_helper
INFO - 2023-12-07 09:08:31 --> Helper loaded: cookie_helper
INFO - 2023-12-07 09:08:31 --> Database Driver Class Initialized
INFO - 2023-12-07 09:08:31 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-07 09:08:31 --> Parser Class Initialized
INFO - 2023-12-07 09:08:31 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-12-07 09:08:31 --> Pagination Class Initialized
INFO - 2023-12-07 09:08:31 --> Form Validation Class Initialized
INFO - 2023-12-07 09:08:31 --> Controller Class Initialized
INFO - 2023-12-07 09:08:31 --> Model Class Initialized
DEBUG - 2023-12-07 09:08:31 --> Session class already loaded. Second attempt ignored.
ERROR - 2023-12-07 09:08:32 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-12-07 09:08:32 --> Config Class Initialized
INFO - 2023-12-07 09:08:32 --> Hooks Class Initialized
DEBUG - 2023-12-07 09:08:32 --> UTF-8 Support Enabled
INFO - 2023-12-07 09:08:32 --> Utf8 Class Initialized
INFO - 2023-12-07 09:08:32 --> URI Class Initialized
INFO - 2023-12-07 09:08:32 --> Router Class Initialized
INFO - 2023-12-07 09:08:32 --> Output Class Initialized
INFO - 2023-12-07 09:08:32 --> Security Class Initialized
DEBUG - 2023-12-07 09:08:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-07 09:08:32 --> Input Class Initialized
INFO - 2023-12-07 09:08:32 --> Language Class Initialized
INFO - 2023-12-07 09:08:32 --> Loader Class Initialized
INFO - 2023-12-07 09:08:32 --> Helper loaded: url_helper
INFO - 2023-12-07 09:08:32 --> Helper loaded: file_helper
INFO - 2023-12-07 09:08:32 --> Helper loaded: html_helper
INFO - 2023-12-07 09:08:32 --> Helper loaded: text_helper
INFO - 2023-12-07 09:08:32 --> Helper loaded: form_helper
INFO - 2023-12-07 09:08:32 --> Helper loaded: lang_helper
INFO - 2023-12-07 09:08:32 --> Helper loaded: security_helper
INFO - 2023-12-07 09:08:32 --> Helper loaded: cookie_helper
INFO - 2023-12-07 09:08:32 --> Database Driver Class Initialized
INFO - 2023-12-07 09:08:32 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-07 09:08:32 --> Parser Class Initialized
INFO - 2023-12-07 09:08:32 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-12-07 09:08:32 --> Pagination Class Initialized
INFO - 2023-12-07 09:08:32 --> Form Validation Class Initialized
INFO - 2023-12-07 09:08:32 --> Controller Class Initialized
INFO - 2023-12-07 09:08:32 --> Model Class Initialized
DEBUG - 2023-12-07 09:08:32 --> Session class already loaded. Second attempt ignored.
INFO - 2023-12-07 09:08:32 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2023-12-07 09:08:32 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-12-07 09:08:32 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-12-07 09:08:32 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-12-07 09:08:32 --> Model Class Initialized
INFO - 2023-12-07 09:08:32 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-12-07 09:08:32 --> Final output sent to browser
DEBUG - 2023-12-07 09:08:32 --> Total execution time: 0.0302
ERROR - 2023-12-07 14:26:37 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-12-07 14:26:37 --> Config Class Initialized
INFO - 2023-12-07 14:26:37 --> Hooks Class Initialized
DEBUG - 2023-12-07 14:26:37 --> UTF-8 Support Enabled
INFO - 2023-12-07 14:26:37 --> Utf8 Class Initialized
INFO - 2023-12-07 14:26:37 --> URI Class Initialized
DEBUG - 2023-12-07 14:26:37 --> No URI present. Default controller set.
INFO - 2023-12-07 14:26:37 --> Router Class Initialized
INFO - 2023-12-07 14:26:37 --> Output Class Initialized
INFO - 2023-12-07 14:26:37 --> Security Class Initialized
DEBUG - 2023-12-07 14:26:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-07 14:26:37 --> Input Class Initialized
INFO - 2023-12-07 14:26:37 --> Language Class Initialized
INFO - 2023-12-07 14:26:37 --> Loader Class Initialized
INFO - 2023-12-07 14:26:37 --> Helper loaded: url_helper
INFO - 2023-12-07 14:26:37 --> Helper loaded: file_helper
INFO - 2023-12-07 14:26:37 --> Helper loaded: html_helper
INFO - 2023-12-07 14:26:37 --> Helper loaded: text_helper
INFO - 2023-12-07 14:26:37 --> Helper loaded: form_helper
INFO - 2023-12-07 14:26:37 --> Helper loaded: lang_helper
INFO - 2023-12-07 14:26:37 --> Helper loaded: security_helper
INFO - 2023-12-07 14:26:37 --> Helper loaded: cookie_helper
INFO - 2023-12-07 14:26:37 --> Database Driver Class Initialized
INFO - 2023-12-07 14:26:37 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-07 14:26:37 --> Parser Class Initialized
INFO - 2023-12-07 14:26:37 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-12-07 14:26:37 --> Pagination Class Initialized
INFO - 2023-12-07 14:26:37 --> Form Validation Class Initialized
INFO - 2023-12-07 14:26:37 --> Controller Class Initialized
INFO - 2023-12-07 14:26:37 --> Model Class Initialized
DEBUG - 2023-12-07 14:26:37 --> Session class already loaded. Second attempt ignored.
ERROR - 2023-12-07 15:22:46 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-12-07 15:22:46 --> Config Class Initialized
INFO - 2023-12-07 15:22:46 --> Hooks Class Initialized
DEBUG - 2023-12-07 15:22:46 --> UTF-8 Support Enabled
INFO - 2023-12-07 15:22:46 --> Utf8 Class Initialized
INFO - 2023-12-07 15:22:46 --> URI Class Initialized
DEBUG - 2023-12-07 15:22:46 --> No URI present. Default controller set.
INFO - 2023-12-07 15:22:46 --> Router Class Initialized
INFO - 2023-12-07 15:22:46 --> Output Class Initialized
INFO - 2023-12-07 15:22:46 --> Security Class Initialized
DEBUG - 2023-12-07 15:22:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-07 15:22:46 --> Input Class Initialized
INFO - 2023-12-07 15:22:46 --> Language Class Initialized
INFO - 2023-12-07 15:22:46 --> Loader Class Initialized
INFO - 2023-12-07 15:22:46 --> Helper loaded: url_helper
INFO - 2023-12-07 15:22:46 --> Helper loaded: file_helper
INFO - 2023-12-07 15:22:46 --> Helper loaded: html_helper
INFO - 2023-12-07 15:22:46 --> Helper loaded: text_helper
INFO - 2023-12-07 15:22:46 --> Helper loaded: form_helper
INFO - 2023-12-07 15:22:46 --> Helper loaded: lang_helper
INFO - 2023-12-07 15:22:46 --> Helper loaded: security_helper
INFO - 2023-12-07 15:22:46 --> Helper loaded: cookie_helper
INFO - 2023-12-07 15:22:46 --> Database Driver Class Initialized
INFO - 2023-12-07 15:22:46 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-07 15:22:46 --> Parser Class Initialized
INFO - 2023-12-07 15:22:46 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-12-07 15:22:46 --> Pagination Class Initialized
INFO - 2023-12-07 15:22:46 --> Form Validation Class Initialized
INFO - 2023-12-07 15:22:46 --> Controller Class Initialized
INFO - 2023-12-07 15:22:46 --> Model Class Initialized
DEBUG - 2023-12-07 15:22:46 --> Session class already loaded. Second attempt ignored.
ERROR - 2023-12-07 15:22:47 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-12-07 15:22:47 --> Config Class Initialized
INFO - 2023-12-07 15:22:47 --> Hooks Class Initialized
DEBUG - 2023-12-07 15:22:47 --> UTF-8 Support Enabled
INFO - 2023-12-07 15:22:47 --> Utf8 Class Initialized
INFO - 2023-12-07 15:22:47 --> URI Class Initialized
INFO - 2023-12-07 15:22:47 --> Router Class Initialized
INFO - 2023-12-07 15:22:47 --> Output Class Initialized
INFO - 2023-12-07 15:22:47 --> Security Class Initialized
DEBUG - 2023-12-07 15:22:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-07 15:22:47 --> Input Class Initialized
INFO - 2023-12-07 15:22:47 --> Language Class Initialized
INFO - 2023-12-07 15:22:47 --> Loader Class Initialized
INFO - 2023-12-07 15:22:47 --> Helper loaded: url_helper
INFO - 2023-12-07 15:22:47 --> Helper loaded: file_helper
INFO - 2023-12-07 15:22:47 --> Helper loaded: html_helper
INFO - 2023-12-07 15:22:47 --> Helper loaded: text_helper
INFO - 2023-12-07 15:22:47 --> Helper loaded: form_helper
INFO - 2023-12-07 15:22:47 --> Helper loaded: lang_helper
INFO - 2023-12-07 15:22:47 --> Helper loaded: security_helper
INFO - 2023-12-07 15:22:47 --> Helper loaded: cookie_helper
INFO - 2023-12-07 15:22:47 --> Database Driver Class Initialized
INFO - 2023-12-07 15:22:47 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-07 15:22:47 --> Parser Class Initialized
INFO - 2023-12-07 15:22:47 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-12-07 15:22:47 --> Pagination Class Initialized
INFO - 2023-12-07 15:22:47 --> Form Validation Class Initialized
INFO - 2023-12-07 15:22:47 --> Controller Class Initialized
INFO - 2023-12-07 15:22:47 --> Model Class Initialized
DEBUG - 2023-12-07 15:22:47 --> Session class already loaded. Second attempt ignored.
INFO - 2023-12-07 15:22:47 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2023-12-07 15:22:47 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-12-07 15:22:47 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-12-07 15:22:47 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-12-07 15:22:47 --> Model Class Initialized
INFO - 2023-12-07 15:22:47 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-12-07 15:22:47 --> Final output sent to browser
DEBUG - 2023-12-07 15:22:47 --> Total execution time: 0.0322
ERROR - 2023-12-07 17:44:38 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-12-07 17:44:38 --> Config Class Initialized
INFO - 2023-12-07 17:44:38 --> Hooks Class Initialized
DEBUG - 2023-12-07 17:44:38 --> UTF-8 Support Enabled
INFO - 2023-12-07 17:44:38 --> Utf8 Class Initialized
INFO - 2023-12-07 17:44:38 --> URI Class Initialized
INFO - 2023-12-07 17:44:38 --> Router Class Initialized
INFO - 2023-12-07 17:44:38 --> Output Class Initialized
INFO - 2023-12-07 17:44:38 --> Security Class Initialized
DEBUG - 2023-12-07 17:44:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-07 17:44:38 --> Input Class Initialized
INFO - 2023-12-07 17:44:38 --> Language Class Initialized
ERROR - 2023-12-07 17:44:38 --> 404 Page Not Found: Well-known/assetlinks.json
