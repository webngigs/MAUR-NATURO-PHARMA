<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2023-09-24 04:06:24 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-24 04:06:24 --> Config Class Initialized
INFO - 2023-09-24 04:06:24 --> Hooks Class Initialized
DEBUG - 2023-09-24 04:06:24 --> UTF-8 Support Enabled
INFO - 2023-09-24 04:06:24 --> Utf8 Class Initialized
INFO - 2023-09-24 04:06:24 --> URI Class Initialized
DEBUG - 2023-09-24 04:06:24 --> No URI present. Default controller set.
INFO - 2023-09-24 04:06:24 --> Router Class Initialized
INFO - 2023-09-24 04:06:24 --> Output Class Initialized
INFO - 2023-09-24 04:06:24 --> Security Class Initialized
DEBUG - 2023-09-24 04:06:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-24 04:06:24 --> Input Class Initialized
INFO - 2023-09-24 04:06:24 --> Language Class Initialized
INFO - 2023-09-24 04:06:24 --> Loader Class Initialized
INFO - 2023-09-24 04:06:24 --> Helper loaded: url_helper
INFO - 2023-09-24 04:06:24 --> Helper loaded: file_helper
INFO - 2023-09-24 04:06:24 --> Helper loaded: html_helper
INFO - 2023-09-24 04:06:24 --> Helper loaded: text_helper
INFO - 2023-09-24 04:06:24 --> Helper loaded: form_helper
INFO - 2023-09-24 04:06:24 --> Helper loaded: lang_helper
INFO - 2023-09-24 04:06:24 --> Helper loaded: security_helper
INFO - 2023-09-24 04:06:24 --> Helper loaded: cookie_helper
INFO - 2023-09-24 04:06:24 --> Database Driver Class Initialized
INFO - 2023-09-24 04:06:24 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-24 04:06:24 --> Parser Class Initialized
INFO - 2023-09-24 04:06:24 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-24 04:06:24 --> Pagination Class Initialized
INFO - 2023-09-24 04:06:24 --> Form Validation Class Initialized
INFO - 2023-09-24 04:06:24 --> Controller Class Initialized
INFO - 2023-09-24 04:06:24 --> Model Class Initialized
DEBUG - 2023-09-24 04:06:24 --> Session class already loaded. Second attempt ignored.
ERROR - 2023-09-24 04:06:24 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-24 04:06:24 --> Config Class Initialized
INFO - 2023-09-24 04:06:24 --> Hooks Class Initialized
DEBUG - 2023-09-24 04:06:24 --> UTF-8 Support Enabled
INFO - 2023-09-24 04:06:24 --> Utf8 Class Initialized
INFO - 2023-09-24 04:06:24 --> URI Class Initialized
INFO - 2023-09-24 04:06:24 --> Router Class Initialized
INFO - 2023-09-24 04:06:24 --> Output Class Initialized
INFO - 2023-09-24 04:06:24 --> Security Class Initialized
DEBUG - 2023-09-24 04:06:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-24 04:06:24 --> Input Class Initialized
INFO - 2023-09-24 04:06:24 --> Language Class Initialized
INFO - 2023-09-24 04:06:24 --> Loader Class Initialized
INFO - 2023-09-24 04:06:24 --> Helper loaded: url_helper
INFO - 2023-09-24 04:06:24 --> Helper loaded: file_helper
INFO - 2023-09-24 04:06:24 --> Helper loaded: html_helper
INFO - 2023-09-24 04:06:24 --> Helper loaded: text_helper
INFO - 2023-09-24 04:06:24 --> Helper loaded: form_helper
INFO - 2023-09-24 04:06:24 --> Helper loaded: lang_helper
INFO - 2023-09-24 04:06:24 --> Helper loaded: security_helper
INFO - 2023-09-24 04:06:24 --> Helper loaded: cookie_helper
INFO - 2023-09-24 04:06:24 --> Database Driver Class Initialized
INFO - 2023-09-24 04:06:24 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-24 04:06:24 --> Parser Class Initialized
INFO - 2023-09-24 04:06:24 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-24 04:06:24 --> Pagination Class Initialized
INFO - 2023-09-24 04:06:24 --> Form Validation Class Initialized
INFO - 2023-09-24 04:06:24 --> Controller Class Initialized
INFO - 2023-09-24 04:06:24 --> Model Class Initialized
DEBUG - 2023-09-24 04:06:24 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-24 04:06:24 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2023-09-24 04:06:24 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-09-24 04:06:24 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-09-24 04:06:24 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-09-24 04:06:24 --> Model Class Initialized
INFO - 2023-09-24 04:06:24 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-09-24 04:06:24 --> Final output sent to browser
DEBUG - 2023-09-24 04:06:24 --> Total execution time: 0.0392
ERROR - 2023-09-24 04:06:35 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-24 04:06:35 --> Config Class Initialized
INFO - 2023-09-24 04:06:35 --> Hooks Class Initialized
DEBUG - 2023-09-24 04:06:35 --> UTF-8 Support Enabled
INFO - 2023-09-24 04:06:35 --> Utf8 Class Initialized
INFO - 2023-09-24 04:06:35 --> URI Class Initialized
DEBUG - 2023-09-24 04:06:35 --> No URI present. Default controller set.
INFO - 2023-09-24 04:06:35 --> Router Class Initialized
INFO - 2023-09-24 04:06:35 --> Output Class Initialized
INFO - 2023-09-24 04:06:35 --> Security Class Initialized
DEBUG - 2023-09-24 04:06:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-24 04:06:35 --> Input Class Initialized
INFO - 2023-09-24 04:06:35 --> Language Class Initialized
INFO - 2023-09-24 04:06:35 --> Loader Class Initialized
INFO - 2023-09-24 04:06:35 --> Helper loaded: url_helper
INFO - 2023-09-24 04:06:35 --> Helper loaded: file_helper
INFO - 2023-09-24 04:06:35 --> Helper loaded: html_helper
INFO - 2023-09-24 04:06:35 --> Helper loaded: text_helper
INFO - 2023-09-24 04:06:35 --> Helper loaded: form_helper
INFO - 2023-09-24 04:06:35 --> Helper loaded: lang_helper
INFO - 2023-09-24 04:06:35 --> Helper loaded: security_helper
INFO - 2023-09-24 04:06:35 --> Helper loaded: cookie_helper
INFO - 2023-09-24 04:06:35 --> Database Driver Class Initialized
INFO - 2023-09-24 04:06:35 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-24 04:06:35 --> Parser Class Initialized
INFO - 2023-09-24 04:06:35 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-24 04:06:35 --> Pagination Class Initialized
INFO - 2023-09-24 04:06:35 --> Form Validation Class Initialized
INFO - 2023-09-24 04:06:35 --> Controller Class Initialized
INFO - 2023-09-24 04:06:35 --> Model Class Initialized
DEBUG - 2023-09-24 04:06:35 --> Session class already loaded. Second attempt ignored.
ERROR - 2023-09-24 04:06:35 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-24 04:06:35 --> Config Class Initialized
INFO - 2023-09-24 04:06:35 --> Hooks Class Initialized
DEBUG - 2023-09-24 04:06:35 --> UTF-8 Support Enabled
INFO - 2023-09-24 04:06:35 --> Utf8 Class Initialized
INFO - 2023-09-24 04:06:35 --> URI Class Initialized
INFO - 2023-09-24 04:06:35 --> Router Class Initialized
INFO - 2023-09-24 04:06:35 --> Output Class Initialized
INFO - 2023-09-24 04:06:35 --> Security Class Initialized
DEBUG - 2023-09-24 04:06:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-24 04:06:35 --> Input Class Initialized
INFO - 2023-09-24 04:06:35 --> Language Class Initialized
INFO - 2023-09-24 04:06:35 --> Loader Class Initialized
INFO - 2023-09-24 04:06:35 --> Helper loaded: url_helper
INFO - 2023-09-24 04:06:35 --> Helper loaded: file_helper
INFO - 2023-09-24 04:06:35 --> Helper loaded: html_helper
INFO - 2023-09-24 04:06:35 --> Helper loaded: text_helper
INFO - 2023-09-24 04:06:35 --> Helper loaded: form_helper
INFO - 2023-09-24 04:06:35 --> Helper loaded: lang_helper
INFO - 2023-09-24 04:06:35 --> Helper loaded: security_helper
INFO - 2023-09-24 04:06:35 --> Helper loaded: cookie_helper
INFO - 2023-09-24 04:06:35 --> Database Driver Class Initialized
INFO - 2023-09-24 04:06:35 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-24 04:06:35 --> Parser Class Initialized
INFO - 2023-09-24 04:06:35 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-24 04:06:35 --> Pagination Class Initialized
INFO - 2023-09-24 04:06:35 --> Form Validation Class Initialized
INFO - 2023-09-24 04:06:35 --> Controller Class Initialized
INFO - 2023-09-24 04:06:35 --> Model Class Initialized
DEBUG - 2023-09-24 04:06:35 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-24 04:06:35 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2023-09-24 04:06:35 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-09-24 04:06:35 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-09-24 04:06:35 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-09-24 04:06:35 --> Model Class Initialized
INFO - 2023-09-24 04:06:35 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-09-24 04:06:35 --> Final output sent to browser
DEBUG - 2023-09-24 04:06:35 --> Total execution time: 0.0316
ERROR - 2023-09-24 04:06:37 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-24 04:06:37 --> Config Class Initialized
INFO - 2023-09-24 04:06:37 --> Hooks Class Initialized
DEBUG - 2023-09-24 04:06:37 --> UTF-8 Support Enabled
INFO - 2023-09-24 04:06:37 --> Utf8 Class Initialized
INFO - 2023-09-24 04:06:37 --> URI Class Initialized
INFO - 2023-09-24 04:06:37 --> Router Class Initialized
INFO - 2023-09-24 04:06:37 --> Output Class Initialized
INFO - 2023-09-24 04:06:37 --> Security Class Initialized
DEBUG - 2023-09-24 04:06:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-24 04:06:37 --> Input Class Initialized
INFO - 2023-09-24 04:06:37 --> Language Class Initialized
INFO - 2023-09-24 04:06:37 --> Loader Class Initialized
INFO - 2023-09-24 04:06:37 --> Helper loaded: url_helper
INFO - 2023-09-24 04:06:38 --> Helper loaded: file_helper
INFO - 2023-09-24 04:06:38 --> Helper loaded: html_helper
INFO - 2023-09-24 04:06:38 --> Helper loaded: text_helper
INFO - 2023-09-24 04:06:38 --> Helper loaded: form_helper
INFO - 2023-09-24 04:06:38 --> Helper loaded: lang_helper
INFO - 2023-09-24 04:06:38 --> Helper loaded: security_helper
INFO - 2023-09-24 04:06:38 --> Helper loaded: cookie_helper
INFO - 2023-09-24 04:06:38 --> Database Driver Class Initialized
INFO - 2023-09-24 04:06:38 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-24 04:06:38 --> Parser Class Initialized
INFO - 2023-09-24 04:06:38 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-24 04:06:38 --> Pagination Class Initialized
INFO - 2023-09-24 04:06:38 --> Form Validation Class Initialized
INFO - 2023-09-24 04:06:38 --> Controller Class Initialized
INFO - 2023-09-24 04:06:38 --> Model Class Initialized
DEBUG - 2023-09-24 04:06:38 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-24 04:06:38 --> Model Class Initialized
INFO - 2023-09-24 04:06:38 --> Final output sent to browser
DEBUG - 2023-09-24 04:06:38 --> Total execution time: 0.0183
ERROR - 2023-09-24 04:06:38 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-24 04:06:38 --> Config Class Initialized
INFO - 2023-09-24 04:06:38 --> Hooks Class Initialized
DEBUG - 2023-09-24 04:06:38 --> UTF-8 Support Enabled
INFO - 2023-09-24 04:06:38 --> Utf8 Class Initialized
INFO - 2023-09-24 04:06:38 --> URI Class Initialized
DEBUG - 2023-09-24 04:06:38 --> No URI present. Default controller set.
INFO - 2023-09-24 04:06:38 --> Router Class Initialized
INFO - 2023-09-24 04:06:38 --> Output Class Initialized
INFO - 2023-09-24 04:06:38 --> Security Class Initialized
DEBUG - 2023-09-24 04:06:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-24 04:06:38 --> Input Class Initialized
INFO - 2023-09-24 04:06:38 --> Language Class Initialized
INFO - 2023-09-24 04:06:38 --> Loader Class Initialized
INFO - 2023-09-24 04:06:38 --> Helper loaded: url_helper
INFO - 2023-09-24 04:06:38 --> Helper loaded: file_helper
INFO - 2023-09-24 04:06:38 --> Helper loaded: html_helper
INFO - 2023-09-24 04:06:38 --> Helper loaded: text_helper
INFO - 2023-09-24 04:06:38 --> Helper loaded: form_helper
INFO - 2023-09-24 04:06:38 --> Helper loaded: lang_helper
INFO - 2023-09-24 04:06:38 --> Helper loaded: security_helper
INFO - 2023-09-24 04:06:38 --> Helper loaded: cookie_helper
INFO - 2023-09-24 04:06:38 --> Database Driver Class Initialized
INFO - 2023-09-24 04:06:38 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-24 04:06:38 --> Parser Class Initialized
INFO - 2023-09-24 04:06:38 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-24 04:06:38 --> Pagination Class Initialized
INFO - 2023-09-24 04:06:38 --> Form Validation Class Initialized
INFO - 2023-09-24 04:06:38 --> Controller Class Initialized
INFO - 2023-09-24 04:06:38 --> Model Class Initialized
DEBUG - 2023-09-24 04:06:38 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-24 04:06:38 --> Model Class Initialized
DEBUG - 2023-09-24 04:06:38 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-24 04:06:38 --> Model Class Initialized
INFO - 2023-09-24 04:06:38 --> Model Class Initialized
INFO - 2023-09-24 04:06:38 --> Model Class Initialized
INFO - 2023-09-24 04:06:38 --> Model Class Initialized
DEBUG - 2023-09-24 04:06:38 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-09-24 04:06:38 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-24 04:06:38 --> Model Class Initialized
INFO - 2023-09-24 04:06:38 --> Model Class Initialized
INFO - 2023-09-24 04:06:38 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-09-24 04:06:38 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-09-24 04:06:38 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-09-24 04:06:38 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-09-24 04:06:38 --> Model Class Initialized
INFO - 2023-09-24 04:06:38 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-09-24 04:06:38 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-09-24 04:06:38 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-09-24 04:06:38 --> Final output sent to browser
DEBUG - 2023-09-24 04:06:38 --> Total execution time: 0.2529
ERROR - 2023-09-24 04:06:39 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-24 04:06:39 --> Config Class Initialized
INFO - 2023-09-24 04:06:39 --> Hooks Class Initialized
DEBUG - 2023-09-24 04:06:39 --> UTF-8 Support Enabled
INFO - 2023-09-24 04:06:39 --> Utf8 Class Initialized
INFO - 2023-09-24 04:06:39 --> URI Class Initialized
INFO - 2023-09-24 04:06:39 --> Router Class Initialized
INFO - 2023-09-24 04:06:39 --> Output Class Initialized
INFO - 2023-09-24 04:06:39 --> Security Class Initialized
DEBUG - 2023-09-24 04:06:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-24 04:06:39 --> Input Class Initialized
INFO - 2023-09-24 04:06:39 --> Language Class Initialized
INFO - 2023-09-24 04:06:39 --> Loader Class Initialized
INFO - 2023-09-24 04:06:39 --> Helper loaded: url_helper
INFO - 2023-09-24 04:06:39 --> Helper loaded: file_helper
INFO - 2023-09-24 04:06:39 --> Helper loaded: html_helper
INFO - 2023-09-24 04:06:39 --> Helper loaded: text_helper
INFO - 2023-09-24 04:06:39 --> Helper loaded: form_helper
INFO - 2023-09-24 04:06:39 --> Helper loaded: lang_helper
INFO - 2023-09-24 04:06:39 --> Helper loaded: security_helper
INFO - 2023-09-24 04:06:39 --> Helper loaded: cookie_helper
INFO - 2023-09-24 04:06:39 --> Database Driver Class Initialized
INFO - 2023-09-24 04:06:39 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-24 04:06:39 --> Parser Class Initialized
INFO - 2023-09-24 04:06:39 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-24 04:06:39 --> Pagination Class Initialized
INFO - 2023-09-24 04:06:39 --> Form Validation Class Initialized
INFO - 2023-09-24 04:06:39 --> Controller Class Initialized
DEBUG - 2023-09-24 04:06:39 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-09-24 04:06:39 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-24 04:06:39 --> Model Class Initialized
INFO - 2023-09-24 04:06:39 --> Final output sent to browser
DEBUG - 2023-09-24 04:06:39 --> Total execution time: 0.0133
ERROR - 2023-09-24 04:06:50 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-24 04:06:50 --> Config Class Initialized
INFO - 2023-09-24 04:06:50 --> Hooks Class Initialized
DEBUG - 2023-09-24 04:06:50 --> UTF-8 Support Enabled
INFO - 2023-09-24 04:06:50 --> Utf8 Class Initialized
INFO - 2023-09-24 04:06:50 --> URI Class Initialized
INFO - 2023-09-24 04:06:50 --> Router Class Initialized
INFO - 2023-09-24 04:06:50 --> Output Class Initialized
INFO - 2023-09-24 04:06:50 --> Security Class Initialized
DEBUG - 2023-09-24 04:06:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-24 04:06:50 --> Input Class Initialized
INFO - 2023-09-24 04:06:50 --> Language Class Initialized
INFO - 2023-09-24 04:06:50 --> Loader Class Initialized
INFO - 2023-09-24 04:06:50 --> Helper loaded: url_helper
INFO - 2023-09-24 04:06:50 --> Helper loaded: file_helper
INFO - 2023-09-24 04:06:50 --> Helper loaded: html_helper
INFO - 2023-09-24 04:06:50 --> Helper loaded: text_helper
INFO - 2023-09-24 04:06:50 --> Helper loaded: form_helper
INFO - 2023-09-24 04:06:50 --> Helper loaded: lang_helper
INFO - 2023-09-24 04:06:50 --> Helper loaded: security_helper
INFO - 2023-09-24 04:06:50 --> Helper loaded: cookie_helper
INFO - 2023-09-24 04:06:50 --> Database Driver Class Initialized
INFO - 2023-09-24 04:06:50 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-24 04:06:50 --> Parser Class Initialized
INFO - 2023-09-24 04:06:50 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-24 04:06:50 --> Pagination Class Initialized
INFO - 2023-09-24 04:06:50 --> Form Validation Class Initialized
INFO - 2023-09-24 04:06:50 --> Controller Class Initialized
INFO - 2023-09-24 04:06:50 --> Model Class Initialized
DEBUG - 2023-09-24 04:06:50 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-24 04:06:50 --> Model Class Initialized
INFO - 2023-09-24 04:06:50 --> Final output sent to browser
DEBUG - 2023-09-24 04:06:50 --> Total execution time: 0.0193
ERROR - 2023-09-24 04:06:51 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-24 04:06:51 --> Config Class Initialized
INFO - 2023-09-24 04:06:51 --> Hooks Class Initialized
DEBUG - 2023-09-24 04:06:51 --> UTF-8 Support Enabled
INFO - 2023-09-24 04:06:51 --> Utf8 Class Initialized
INFO - 2023-09-24 04:06:51 --> URI Class Initialized
DEBUG - 2023-09-24 04:06:51 --> No URI present. Default controller set.
INFO - 2023-09-24 04:06:51 --> Router Class Initialized
INFO - 2023-09-24 04:06:51 --> Output Class Initialized
INFO - 2023-09-24 04:06:51 --> Security Class Initialized
DEBUG - 2023-09-24 04:06:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-24 04:06:51 --> Input Class Initialized
INFO - 2023-09-24 04:06:51 --> Language Class Initialized
INFO - 2023-09-24 04:06:51 --> Loader Class Initialized
INFO - 2023-09-24 04:06:51 --> Helper loaded: url_helper
INFO - 2023-09-24 04:06:51 --> Helper loaded: file_helper
INFO - 2023-09-24 04:06:51 --> Helper loaded: html_helper
INFO - 2023-09-24 04:06:51 --> Helper loaded: text_helper
INFO - 2023-09-24 04:06:51 --> Helper loaded: form_helper
INFO - 2023-09-24 04:06:51 --> Helper loaded: lang_helper
INFO - 2023-09-24 04:06:51 --> Helper loaded: security_helper
INFO - 2023-09-24 04:06:51 --> Helper loaded: cookie_helper
INFO - 2023-09-24 04:06:51 --> Database Driver Class Initialized
INFO - 2023-09-24 04:06:51 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-24 04:06:51 --> Parser Class Initialized
INFO - 2023-09-24 04:06:51 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-24 04:06:51 --> Pagination Class Initialized
INFO - 2023-09-24 04:06:51 --> Form Validation Class Initialized
INFO - 2023-09-24 04:06:51 --> Controller Class Initialized
INFO - 2023-09-24 04:06:51 --> Model Class Initialized
DEBUG - 2023-09-24 04:06:51 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-24 04:06:51 --> Model Class Initialized
DEBUG - 2023-09-24 04:06:51 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-24 04:06:51 --> Model Class Initialized
INFO - 2023-09-24 04:06:51 --> Model Class Initialized
INFO - 2023-09-24 04:06:51 --> Model Class Initialized
INFO - 2023-09-24 04:06:51 --> Model Class Initialized
DEBUG - 2023-09-24 04:06:51 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-09-24 04:06:51 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-24 04:06:51 --> Model Class Initialized
INFO - 2023-09-24 04:06:51 --> Model Class Initialized
INFO - 2023-09-24 04:06:51 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-09-24 04:06:51 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-09-24 04:06:51 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-09-24 04:06:51 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-09-24 04:06:51 --> Model Class Initialized
INFO - 2023-09-24 04:06:51 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-09-24 04:06:51 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-09-24 04:06:51 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-09-24 04:06:51 --> Final output sent to browser
DEBUG - 2023-09-24 04:06:51 --> Total execution time: 0.1127
ERROR - 2023-09-24 04:06:55 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-24 04:06:55 --> Config Class Initialized
INFO - 2023-09-24 04:06:55 --> Hooks Class Initialized
DEBUG - 2023-09-24 04:06:55 --> UTF-8 Support Enabled
INFO - 2023-09-24 04:06:55 --> Utf8 Class Initialized
INFO - 2023-09-24 04:06:55 --> URI Class Initialized
INFO - 2023-09-24 04:06:55 --> Router Class Initialized
INFO - 2023-09-24 04:06:55 --> Output Class Initialized
INFO - 2023-09-24 04:06:55 --> Security Class Initialized
DEBUG - 2023-09-24 04:06:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-24 04:06:55 --> Input Class Initialized
INFO - 2023-09-24 04:06:55 --> Language Class Initialized
INFO - 2023-09-24 04:06:55 --> Loader Class Initialized
INFO - 2023-09-24 04:06:55 --> Helper loaded: url_helper
INFO - 2023-09-24 04:06:55 --> Helper loaded: file_helper
INFO - 2023-09-24 04:06:55 --> Helper loaded: html_helper
INFO - 2023-09-24 04:06:55 --> Helper loaded: text_helper
INFO - 2023-09-24 04:06:55 --> Helper loaded: form_helper
INFO - 2023-09-24 04:06:55 --> Helper loaded: lang_helper
INFO - 2023-09-24 04:06:55 --> Helper loaded: security_helper
INFO - 2023-09-24 04:06:55 --> Helper loaded: cookie_helper
INFO - 2023-09-24 04:06:55 --> Database Driver Class Initialized
INFO - 2023-09-24 04:06:55 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-24 04:06:55 --> Parser Class Initialized
INFO - 2023-09-24 04:06:55 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-24 04:06:55 --> Pagination Class Initialized
INFO - 2023-09-24 04:06:55 --> Form Validation Class Initialized
INFO - 2023-09-24 04:06:55 --> Controller Class Initialized
INFO - 2023-09-24 04:06:55 --> Model Class Initialized
DEBUG - 2023-09-24 04:06:55 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-09-24 04:06:55 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-24 04:06:55 --> Model Class Initialized
DEBUG - 2023-09-24 04:06:55 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-24 04:06:55 --> Model Class Initialized
INFO - 2023-09-24 04:06:55 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice.php
DEBUG - 2023-09-24 04:06:55 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-09-24 04:06:55 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-09-24 04:06:55 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-09-24 04:06:55 --> Model Class Initialized
INFO - 2023-09-24 04:06:55 --> Model Class Initialized
INFO - 2023-09-24 04:06:55 --> Model Class Initialized
INFO - 2023-09-24 04:06:55 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-09-24 04:06:55 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-09-24 04:06:55 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-09-24 04:06:55 --> Final output sent to browser
DEBUG - 2023-09-24 04:06:55 --> Total execution time: 0.1145
ERROR - 2023-09-24 04:06:56 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-24 04:06:56 --> Config Class Initialized
INFO - 2023-09-24 04:06:56 --> Hooks Class Initialized
DEBUG - 2023-09-24 04:06:56 --> UTF-8 Support Enabled
INFO - 2023-09-24 04:06:56 --> Utf8 Class Initialized
INFO - 2023-09-24 04:06:56 --> URI Class Initialized
INFO - 2023-09-24 04:06:56 --> Router Class Initialized
INFO - 2023-09-24 04:06:56 --> Output Class Initialized
INFO - 2023-09-24 04:06:56 --> Security Class Initialized
DEBUG - 2023-09-24 04:06:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-24 04:06:56 --> Input Class Initialized
INFO - 2023-09-24 04:06:56 --> Language Class Initialized
INFO - 2023-09-24 04:06:56 --> Loader Class Initialized
INFO - 2023-09-24 04:06:56 --> Helper loaded: url_helper
INFO - 2023-09-24 04:06:56 --> Helper loaded: file_helper
INFO - 2023-09-24 04:06:56 --> Helper loaded: html_helper
INFO - 2023-09-24 04:06:56 --> Helper loaded: text_helper
INFO - 2023-09-24 04:06:56 --> Helper loaded: form_helper
INFO - 2023-09-24 04:06:56 --> Helper loaded: lang_helper
INFO - 2023-09-24 04:06:56 --> Helper loaded: security_helper
INFO - 2023-09-24 04:06:56 --> Helper loaded: cookie_helper
INFO - 2023-09-24 04:06:56 --> Database Driver Class Initialized
INFO - 2023-09-24 04:06:56 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-24 04:06:56 --> Parser Class Initialized
INFO - 2023-09-24 04:06:56 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-24 04:06:56 --> Pagination Class Initialized
INFO - 2023-09-24 04:06:56 --> Form Validation Class Initialized
INFO - 2023-09-24 04:06:56 --> Controller Class Initialized
INFO - 2023-09-24 04:06:56 --> Model Class Initialized
DEBUG - 2023-09-24 04:06:56 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-09-24 04:06:56 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-24 04:06:56 --> Model Class Initialized
DEBUG - 2023-09-24 04:06:56 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-24 04:06:56 --> Model Class Initialized
INFO - 2023-09-24 04:06:56 --> Final output sent to browser
DEBUG - 2023-09-24 04:06:56 --> Total execution time: 0.0525
ERROR - 2023-09-24 04:07:00 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-24 04:07:00 --> Config Class Initialized
INFO - 2023-09-24 04:07:00 --> Hooks Class Initialized
DEBUG - 2023-09-24 04:07:00 --> UTF-8 Support Enabled
INFO - 2023-09-24 04:07:00 --> Utf8 Class Initialized
INFO - 2023-09-24 04:07:00 --> URI Class Initialized
INFO - 2023-09-24 04:07:00 --> Router Class Initialized
INFO - 2023-09-24 04:07:00 --> Output Class Initialized
INFO - 2023-09-24 04:07:00 --> Security Class Initialized
DEBUG - 2023-09-24 04:07:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-24 04:07:00 --> Input Class Initialized
INFO - 2023-09-24 04:07:00 --> Language Class Initialized
INFO - 2023-09-24 04:07:00 --> Loader Class Initialized
INFO - 2023-09-24 04:07:00 --> Helper loaded: url_helper
INFO - 2023-09-24 04:07:00 --> Helper loaded: file_helper
INFO - 2023-09-24 04:07:00 --> Helper loaded: html_helper
INFO - 2023-09-24 04:07:00 --> Helper loaded: text_helper
INFO - 2023-09-24 04:07:00 --> Helper loaded: form_helper
INFO - 2023-09-24 04:07:00 --> Helper loaded: lang_helper
INFO - 2023-09-24 04:07:00 --> Helper loaded: security_helper
INFO - 2023-09-24 04:07:00 --> Helper loaded: cookie_helper
INFO - 2023-09-24 04:07:00 --> Database Driver Class Initialized
INFO - 2023-09-24 04:07:00 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-24 04:07:00 --> Parser Class Initialized
INFO - 2023-09-24 04:07:00 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-24 04:07:00 --> Pagination Class Initialized
INFO - 2023-09-24 04:07:00 --> Form Validation Class Initialized
INFO - 2023-09-24 04:07:00 --> Controller Class Initialized
INFO - 2023-09-24 04:07:00 --> Model Class Initialized
DEBUG - 2023-09-24 04:07:00 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-09-24 04:07:00 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-24 04:07:00 --> Model Class Initialized
DEBUG - 2023-09-24 04:07:00 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-24 04:07:00 --> Model Class Initialized
INFO - 2023-09-24 04:07:01 --> Final output sent to browser
DEBUG - 2023-09-24 04:07:01 --> Total execution time: 0.3915
ERROR - 2023-09-24 04:07:07 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-24 04:07:07 --> Config Class Initialized
INFO - 2023-09-24 04:07:07 --> Hooks Class Initialized
DEBUG - 2023-09-24 04:07:07 --> UTF-8 Support Enabled
INFO - 2023-09-24 04:07:07 --> Utf8 Class Initialized
INFO - 2023-09-24 04:07:07 --> URI Class Initialized
DEBUG - 2023-09-24 04:07:07 --> No URI present. Default controller set.
INFO - 2023-09-24 04:07:07 --> Router Class Initialized
INFO - 2023-09-24 04:07:07 --> Output Class Initialized
INFO - 2023-09-24 04:07:07 --> Security Class Initialized
DEBUG - 2023-09-24 04:07:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-24 04:07:07 --> Input Class Initialized
INFO - 2023-09-24 04:07:07 --> Language Class Initialized
INFO - 2023-09-24 04:07:07 --> Loader Class Initialized
INFO - 2023-09-24 04:07:07 --> Helper loaded: url_helper
INFO - 2023-09-24 04:07:07 --> Helper loaded: file_helper
INFO - 2023-09-24 04:07:07 --> Helper loaded: html_helper
INFO - 2023-09-24 04:07:07 --> Helper loaded: text_helper
INFO - 2023-09-24 04:07:07 --> Helper loaded: form_helper
INFO - 2023-09-24 04:07:07 --> Helper loaded: lang_helper
INFO - 2023-09-24 04:07:07 --> Helper loaded: security_helper
INFO - 2023-09-24 04:07:07 --> Helper loaded: cookie_helper
INFO - 2023-09-24 04:07:07 --> Database Driver Class Initialized
INFO - 2023-09-24 04:07:07 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-24 04:07:07 --> Parser Class Initialized
INFO - 2023-09-24 04:07:07 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-24 04:07:07 --> Pagination Class Initialized
INFO - 2023-09-24 04:07:07 --> Form Validation Class Initialized
INFO - 2023-09-24 04:07:07 --> Controller Class Initialized
INFO - 2023-09-24 04:07:07 --> Model Class Initialized
DEBUG - 2023-09-24 04:07:07 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-24 04:07:07 --> Model Class Initialized
DEBUG - 2023-09-24 04:07:07 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-24 04:07:07 --> Model Class Initialized
INFO - 2023-09-24 04:07:07 --> Model Class Initialized
INFO - 2023-09-24 04:07:07 --> Model Class Initialized
INFO - 2023-09-24 04:07:07 --> Model Class Initialized
DEBUG - 2023-09-24 04:07:07 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-09-24 04:07:07 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-24 04:07:07 --> Model Class Initialized
INFO - 2023-09-24 04:07:07 --> Model Class Initialized
INFO - 2023-09-24 04:07:07 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-09-24 04:07:07 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-09-24 04:07:07 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-09-24 04:07:07 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-09-24 04:07:07 --> Model Class Initialized
INFO - 2023-09-24 04:07:07 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-09-24 04:07:07 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-09-24 04:07:07 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-09-24 04:07:07 --> Final output sent to browser
DEBUG - 2023-09-24 04:07:07 --> Total execution time: 0.1092
ERROR - 2023-09-24 04:07:52 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-24 04:07:52 --> Config Class Initialized
INFO - 2023-09-24 04:07:52 --> Hooks Class Initialized
DEBUG - 2023-09-24 04:07:52 --> UTF-8 Support Enabled
INFO - 2023-09-24 04:07:52 --> Utf8 Class Initialized
INFO - 2023-09-24 04:07:52 --> URI Class Initialized
DEBUG - 2023-09-24 04:07:52 --> No URI present. Default controller set.
INFO - 2023-09-24 04:07:52 --> Router Class Initialized
INFO - 2023-09-24 04:07:52 --> Output Class Initialized
INFO - 2023-09-24 04:07:52 --> Security Class Initialized
DEBUG - 2023-09-24 04:07:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-24 04:07:52 --> Input Class Initialized
INFO - 2023-09-24 04:07:52 --> Language Class Initialized
INFO - 2023-09-24 04:07:52 --> Loader Class Initialized
INFO - 2023-09-24 04:07:52 --> Helper loaded: url_helper
INFO - 2023-09-24 04:07:52 --> Helper loaded: file_helper
INFO - 2023-09-24 04:07:52 --> Helper loaded: html_helper
INFO - 2023-09-24 04:07:52 --> Helper loaded: text_helper
INFO - 2023-09-24 04:07:52 --> Helper loaded: form_helper
INFO - 2023-09-24 04:07:52 --> Helper loaded: lang_helper
INFO - 2023-09-24 04:07:52 --> Helper loaded: security_helper
INFO - 2023-09-24 04:07:52 --> Helper loaded: cookie_helper
INFO - 2023-09-24 04:07:52 --> Database Driver Class Initialized
INFO - 2023-09-24 04:07:52 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-24 04:07:52 --> Parser Class Initialized
INFO - 2023-09-24 04:07:52 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-24 04:07:52 --> Pagination Class Initialized
INFO - 2023-09-24 04:07:52 --> Form Validation Class Initialized
INFO - 2023-09-24 04:07:52 --> Controller Class Initialized
INFO - 2023-09-24 04:07:52 --> Model Class Initialized
DEBUG - 2023-09-24 04:07:52 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-24 04:07:52 --> Model Class Initialized
DEBUG - 2023-09-24 04:07:52 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-24 04:07:52 --> Model Class Initialized
INFO - 2023-09-24 04:07:52 --> Model Class Initialized
INFO - 2023-09-24 04:07:52 --> Model Class Initialized
INFO - 2023-09-24 04:07:52 --> Model Class Initialized
DEBUG - 2023-09-24 04:07:52 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-09-24 04:07:52 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-24 04:07:52 --> Model Class Initialized
INFO - 2023-09-24 04:07:52 --> Model Class Initialized
INFO - 2023-09-24 04:07:52 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-09-24 04:07:52 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-09-24 04:07:52 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-09-24 04:07:52 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-09-24 04:07:52 --> Model Class Initialized
INFO - 2023-09-24 04:07:52 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-09-24 04:07:52 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-09-24 04:07:52 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-09-24 04:07:52 --> Final output sent to browser
DEBUG - 2023-09-24 04:07:52 --> Total execution time: 0.1218
ERROR - 2023-09-24 04:07:56 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-24 04:07:56 --> Config Class Initialized
INFO - 2023-09-24 04:07:56 --> Hooks Class Initialized
DEBUG - 2023-09-24 04:07:56 --> UTF-8 Support Enabled
INFO - 2023-09-24 04:07:56 --> Utf8 Class Initialized
INFO - 2023-09-24 04:07:56 --> URI Class Initialized
INFO - 2023-09-24 04:07:56 --> Router Class Initialized
INFO - 2023-09-24 04:07:56 --> Output Class Initialized
INFO - 2023-09-24 04:07:56 --> Security Class Initialized
DEBUG - 2023-09-24 04:07:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-24 04:07:56 --> Input Class Initialized
INFO - 2023-09-24 04:07:56 --> Language Class Initialized
INFO - 2023-09-24 04:07:56 --> Loader Class Initialized
INFO - 2023-09-24 04:07:56 --> Helper loaded: url_helper
INFO - 2023-09-24 04:07:56 --> Helper loaded: file_helper
INFO - 2023-09-24 04:07:56 --> Helper loaded: html_helper
INFO - 2023-09-24 04:07:56 --> Helper loaded: text_helper
INFO - 2023-09-24 04:07:56 --> Helper loaded: form_helper
INFO - 2023-09-24 04:07:56 --> Helper loaded: lang_helper
INFO - 2023-09-24 04:07:56 --> Helper loaded: security_helper
INFO - 2023-09-24 04:07:56 --> Helper loaded: cookie_helper
INFO - 2023-09-24 04:07:56 --> Database Driver Class Initialized
INFO - 2023-09-24 04:07:56 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-24 04:07:56 --> Parser Class Initialized
INFO - 2023-09-24 04:07:56 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-24 04:07:56 --> Pagination Class Initialized
INFO - 2023-09-24 04:07:56 --> Form Validation Class Initialized
INFO - 2023-09-24 04:07:56 --> Controller Class Initialized
INFO - 2023-09-24 04:07:56 --> Model Class Initialized
DEBUG - 2023-09-24 04:07:56 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-24 04:07:56 --> Final output sent to browser
DEBUG - 2023-09-24 04:07:56 --> Total execution time: 0.0131
ERROR - 2023-09-24 04:07:56 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-24 04:07:56 --> Config Class Initialized
INFO - 2023-09-24 04:07:56 --> Hooks Class Initialized
DEBUG - 2023-09-24 04:07:56 --> UTF-8 Support Enabled
INFO - 2023-09-24 04:07:56 --> Utf8 Class Initialized
INFO - 2023-09-24 04:07:56 --> URI Class Initialized
INFO - 2023-09-24 04:07:56 --> Router Class Initialized
INFO - 2023-09-24 04:07:56 --> Output Class Initialized
INFO - 2023-09-24 04:07:56 --> Security Class Initialized
DEBUG - 2023-09-24 04:07:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-24 04:07:56 --> Input Class Initialized
INFO - 2023-09-24 04:07:56 --> Language Class Initialized
INFO - 2023-09-24 04:07:56 --> Loader Class Initialized
INFO - 2023-09-24 04:07:56 --> Helper loaded: url_helper
INFO - 2023-09-24 04:07:56 --> Helper loaded: file_helper
INFO - 2023-09-24 04:07:56 --> Helper loaded: html_helper
INFO - 2023-09-24 04:07:56 --> Helper loaded: text_helper
INFO - 2023-09-24 04:07:56 --> Helper loaded: form_helper
INFO - 2023-09-24 04:07:56 --> Helper loaded: lang_helper
INFO - 2023-09-24 04:07:56 --> Helper loaded: security_helper
INFO - 2023-09-24 04:07:56 --> Helper loaded: cookie_helper
INFO - 2023-09-24 04:07:56 --> Database Driver Class Initialized
INFO - 2023-09-24 04:07:56 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-24 04:07:56 --> Parser Class Initialized
INFO - 2023-09-24 04:07:56 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-24 04:07:56 --> Pagination Class Initialized
INFO - 2023-09-24 04:07:56 --> Form Validation Class Initialized
INFO - 2023-09-24 04:07:56 --> Controller Class Initialized
INFO - 2023-09-24 04:07:56 --> Model Class Initialized
DEBUG - 2023-09-24 04:07:56 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-24 04:07:56 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2023-09-24 04:07:56 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-09-24 04:07:56 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-09-24 04:07:56 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-09-24 04:07:56 --> Model Class Initialized
INFO - 2023-09-24 04:07:56 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-09-24 04:07:56 --> Final output sent to browser
DEBUG - 2023-09-24 04:07:56 --> Total execution time: 0.0373
ERROR - 2023-09-24 04:08:02 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-24 04:08:02 --> Config Class Initialized
INFO - 2023-09-24 04:08:02 --> Hooks Class Initialized
DEBUG - 2023-09-24 04:08:02 --> UTF-8 Support Enabled
INFO - 2023-09-24 04:08:02 --> Utf8 Class Initialized
INFO - 2023-09-24 04:08:02 --> URI Class Initialized
INFO - 2023-09-24 04:08:02 --> Router Class Initialized
INFO - 2023-09-24 04:08:02 --> Output Class Initialized
INFO - 2023-09-24 04:08:02 --> Security Class Initialized
DEBUG - 2023-09-24 04:08:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-24 04:08:02 --> Input Class Initialized
INFO - 2023-09-24 04:08:02 --> Language Class Initialized
INFO - 2023-09-24 04:08:02 --> Loader Class Initialized
INFO - 2023-09-24 04:08:02 --> Helper loaded: url_helper
INFO - 2023-09-24 04:08:02 --> Helper loaded: file_helper
INFO - 2023-09-24 04:08:02 --> Helper loaded: html_helper
INFO - 2023-09-24 04:08:02 --> Helper loaded: text_helper
INFO - 2023-09-24 04:08:02 --> Helper loaded: form_helper
INFO - 2023-09-24 04:08:02 --> Helper loaded: lang_helper
INFO - 2023-09-24 04:08:02 --> Helper loaded: security_helper
INFO - 2023-09-24 04:08:02 --> Helper loaded: cookie_helper
INFO - 2023-09-24 04:08:02 --> Database Driver Class Initialized
INFO - 2023-09-24 04:08:02 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-24 04:08:02 --> Parser Class Initialized
INFO - 2023-09-24 04:08:02 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-24 04:08:02 --> Pagination Class Initialized
INFO - 2023-09-24 04:08:02 --> Form Validation Class Initialized
INFO - 2023-09-24 04:08:02 --> Controller Class Initialized
INFO - 2023-09-24 04:08:02 --> Model Class Initialized
DEBUG - 2023-09-24 04:08:02 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-24 04:08:02 --> Model Class Initialized
INFO - 2023-09-24 04:08:02 --> Final output sent to browser
DEBUG - 2023-09-24 04:08:02 --> Total execution time: 0.0163
ERROR - 2023-09-24 04:08:02 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-24 04:08:02 --> Config Class Initialized
INFO - 2023-09-24 04:08:02 --> Hooks Class Initialized
DEBUG - 2023-09-24 04:08:02 --> UTF-8 Support Enabled
INFO - 2023-09-24 04:08:02 --> Utf8 Class Initialized
INFO - 2023-09-24 04:08:02 --> URI Class Initialized
DEBUG - 2023-09-24 04:08:02 --> No URI present. Default controller set.
INFO - 2023-09-24 04:08:02 --> Router Class Initialized
INFO - 2023-09-24 04:08:02 --> Output Class Initialized
INFO - 2023-09-24 04:08:02 --> Security Class Initialized
DEBUG - 2023-09-24 04:08:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-24 04:08:02 --> Input Class Initialized
INFO - 2023-09-24 04:08:02 --> Language Class Initialized
INFO - 2023-09-24 04:08:02 --> Loader Class Initialized
INFO - 2023-09-24 04:08:02 --> Helper loaded: url_helper
INFO - 2023-09-24 04:08:02 --> Helper loaded: file_helper
INFO - 2023-09-24 04:08:02 --> Helper loaded: html_helper
INFO - 2023-09-24 04:08:02 --> Helper loaded: text_helper
INFO - 2023-09-24 04:08:02 --> Helper loaded: form_helper
INFO - 2023-09-24 04:08:02 --> Helper loaded: lang_helper
INFO - 2023-09-24 04:08:02 --> Helper loaded: security_helper
INFO - 2023-09-24 04:08:02 --> Helper loaded: cookie_helper
INFO - 2023-09-24 04:08:02 --> Database Driver Class Initialized
INFO - 2023-09-24 04:08:02 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-24 04:08:02 --> Parser Class Initialized
INFO - 2023-09-24 04:08:02 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-24 04:08:02 --> Pagination Class Initialized
INFO - 2023-09-24 04:08:02 --> Form Validation Class Initialized
INFO - 2023-09-24 04:08:02 --> Controller Class Initialized
INFO - 2023-09-24 04:08:02 --> Model Class Initialized
DEBUG - 2023-09-24 04:08:02 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-24 04:08:03 --> Model Class Initialized
DEBUG - 2023-09-24 04:08:03 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-24 04:08:03 --> Model Class Initialized
INFO - 2023-09-24 04:08:03 --> Model Class Initialized
INFO - 2023-09-24 04:08:03 --> Model Class Initialized
INFO - 2023-09-24 04:08:03 --> Model Class Initialized
DEBUG - 2023-09-24 04:08:03 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-09-24 04:08:03 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-24 04:08:03 --> Model Class Initialized
INFO - 2023-09-24 04:08:03 --> Model Class Initialized
INFO - 2023-09-24 04:08:03 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-09-24 04:08:03 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-09-24 04:08:03 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-09-24 04:08:03 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-09-24 04:08:03 --> Model Class Initialized
INFO - 2023-09-24 04:08:03 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-09-24 04:08:03 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-09-24 04:08:03 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-09-24 04:08:03 --> Final output sent to browser
DEBUG - 2023-09-24 04:08:03 --> Total execution time: 0.1113
ERROR - 2023-09-24 04:08:07 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-24 04:08:07 --> Config Class Initialized
INFO - 2023-09-24 04:08:07 --> Hooks Class Initialized
DEBUG - 2023-09-24 04:08:07 --> UTF-8 Support Enabled
INFO - 2023-09-24 04:08:07 --> Utf8 Class Initialized
INFO - 2023-09-24 04:08:07 --> URI Class Initialized
INFO - 2023-09-24 04:08:07 --> Router Class Initialized
INFO - 2023-09-24 04:08:07 --> Output Class Initialized
INFO - 2023-09-24 04:08:07 --> Security Class Initialized
DEBUG - 2023-09-24 04:08:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-24 04:08:07 --> Input Class Initialized
INFO - 2023-09-24 04:08:07 --> Language Class Initialized
INFO - 2023-09-24 04:08:07 --> Loader Class Initialized
INFO - 2023-09-24 04:08:07 --> Helper loaded: url_helper
INFO - 2023-09-24 04:08:07 --> Helper loaded: file_helper
INFO - 2023-09-24 04:08:07 --> Helper loaded: html_helper
INFO - 2023-09-24 04:08:07 --> Helper loaded: text_helper
INFO - 2023-09-24 04:08:07 --> Helper loaded: form_helper
INFO - 2023-09-24 04:08:07 --> Helper loaded: lang_helper
INFO - 2023-09-24 04:08:07 --> Helper loaded: security_helper
INFO - 2023-09-24 04:08:07 --> Helper loaded: cookie_helper
INFO - 2023-09-24 04:08:07 --> Database Driver Class Initialized
INFO - 2023-09-24 04:08:07 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-24 04:08:07 --> Parser Class Initialized
INFO - 2023-09-24 04:08:07 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-24 04:08:07 --> Pagination Class Initialized
INFO - 2023-09-24 04:08:07 --> Form Validation Class Initialized
INFO - 2023-09-24 04:08:07 --> Controller Class Initialized
INFO - 2023-09-24 04:08:07 --> Model Class Initialized
DEBUG - 2023-09-24 04:08:07 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-09-24 04:08:07 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-24 04:08:07 --> Model Class Initialized
DEBUG - 2023-09-24 04:08:07 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-24 04:08:07 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/demandrequest/add_demandrequest_form.php
DEBUG - 2023-09-24 04:08:07 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-09-24 04:08:07 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-09-24 04:08:07 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-09-24 04:08:07 --> Model Class Initialized
INFO - 2023-09-24 04:08:07 --> Model Class Initialized
INFO - 2023-09-24 04:08:07 --> Model Class Initialized
INFO - 2023-09-24 04:08:07 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-09-24 04:08:07 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-09-24 04:08:07 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-09-24 04:08:07 --> Final output sent to browser
DEBUG - 2023-09-24 04:08:07 --> Total execution time: 0.1108
ERROR - 2023-09-24 04:08:16 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-24 04:08:16 --> Config Class Initialized
INFO - 2023-09-24 04:08:16 --> Hooks Class Initialized
DEBUG - 2023-09-24 04:08:16 --> UTF-8 Support Enabled
INFO - 2023-09-24 04:08:16 --> Utf8 Class Initialized
INFO - 2023-09-24 04:08:16 --> URI Class Initialized
INFO - 2023-09-24 04:08:16 --> Router Class Initialized
INFO - 2023-09-24 04:08:16 --> Output Class Initialized
INFO - 2023-09-24 04:08:16 --> Security Class Initialized
DEBUG - 2023-09-24 04:08:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-24 04:08:16 --> Input Class Initialized
INFO - 2023-09-24 04:08:16 --> Language Class Initialized
INFO - 2023-09-24 04:08:16 --> Loader Class Initialized
INFO - 2023-09-24 04:08:16 --> Helper loaded: url_helper
INFO - 2023-09-24 04:08:16 --> Helper loaded: file_helper
INFO - 2023-09-24 04:08:16 --> Helper loaded: html_helper
INFO - 2023-09-24 04:08:16 --> Helper loaded: text_helper
INFO - 2023-09-24 04:08:16 --> Helper loaded: form_helper
INFO - 2023-09-24 04:08:16 --> Helper loaded: lang_helper
INFO - 2023-09-24 04:08:16 --> Helper loaded: security_helper
INFO - 2023-09-24 04:08:16 --> Helper loaded: cookie_helper
INFO - 2023-09-24 04:08:16 --> Database Driver Class Initialized
INFO - 2023-09-24 04:08:16 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-24 04:08:16 --> Parser Class Initialized
INFO - 2023-09-24 04:08:16 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-24 04:08:16 --> Pagination Class Initialized
INFO - 2023-09-24 04:08:16 --> Form Validation Class Initialized
INFO - 2023-09-24 04:08:16 --> Controller Class Initialized
INFO - 2023-09-24 04:08:16 --> Model Class Initialized
DEBUG - 2023-09-24 04:08:16 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-09-24 04:08:16 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-24 04:08:16 --> Model Class Initialized
DEBUG - 2023-09-24 04:08:16 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-24 04:08:16 --> Model Class Initialized
INFO - 2023-09-24 04:08:16 --> Final output sent to browser
DEBUG - 2023-09-24 04:08:16 --> Total execution time: 0.0664
ERROR - 2023-09-24 04:08:17 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-24 04:08:17 --> Config Class Initialized
INFO - 2023-09-24 04:08:17 --> Hooks Class Initialized
DEBUG - 2023-09-24 04:08:17 --> UTF-8 Support Enabled
INFO - 2023-09-24 04:08:17 --> Utf8 Class Initialized
INFO - 2023-09-24 04:08:17 --> URI Class Initialized
INFO - 2023-09-24 04:08:17 --> Router Class Initialized
INFO - 2023-09-24 04:08:17 --> Output Class Initialized
INFO - 2023-09-24 04:08:17 --> Security Class Initialized
DEBUG - 2023-09-24 04:08:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-24 04:08:17 --> Input Class Initialized
INFO - 2023-09-24 04:08:17 --> Language Class Initialized
INFO - 2023-09-24 04:08:17 --> Loader Class Initialized
INFO - 2023-09-24 04:08:17 --> Helper loaded: url_helper
INFO - 2023-09-24 04:08:17 --> Helper loaded: file_helper
INFO - 2023-09-24 04:08:17 --> Helper loaded: html_helper
INFO - 2023-09-24 04:08:17 --> Helper loaded: text_helper
INFO - 2023-09-24 04:08:17 --> Helper loaded: form_helper
INFO - 2023-09-24 04:08:17 --> Helper loaded: lang_helper
INFO - 2023-09-24 04:08:17 --> Helper loaded: security_helper
INFO - 2023-09-24 04:08:17 --> Helper loaded: cookie_helper
INFO - 2023-09-24 04:08:17 --> Database Driver Class Initialized
INFO - 2023-09-24 04:08:17 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-24 04:08:17 --> Parser Class Initialized
INFO - 2023-09-24 04:08:17 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-24 04:08:17 --> Pagination Class Initialized
INFO - 2023-09-24 04:08:17 --> Form Validation Class Initialized
INFO - 2023-09-24 04:08:17 --> Controller Class Initialized
INFO - 2023-09-24 04:08:17 --> Model Class Initialized
DEBUG - 2023-09-24 04:08:17 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-09-24 04:08:17 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-24 04:08:17 --> Model Class Initialized
DEBUG - 2023-09-24 04:08:17 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-24 04:08:17 --> Model Class Initialized
INFO - 2023-09-24 04:08:17 --> Final output sent to browser
DEBUG - 2023-09-24 04:08:17 --> Total execution time: 0.0652
ERROR - 2023-09-24 04:08:17 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-24 04:08:17 --> Config Class Initialized
INFO - 2023-09-24 04:08:17 --> Hooks Class Initialized
DEBUG - 2023-09-24 04:08:17 --> UTF-8 Support Enabled
INFO - 2023-09-24 04:08:17 --> Utf8 Class Initialized
INFO - 2023-09-24 04:08:17 --> URI Class Initialized
INFO - 2023-09-24 04:08:17 --> Router Class Initialized
INFO - 2023-09-24 04:08:17 --> Output Class Initialized
INFO - 2023-09-24 04:08:17 --> Security Class Initialized
DEBUG - 2023-09-24 04:08:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-24 04:08:17 --> Input Class Initialized
INFO - 2023-09-24 04:08:17 --> Language Class Initialized
INFO - 2023-09-24 04:08:17 --> Loader Class Initialized
INFO - 2023-09-24 04:08:17 --> Helper loaded: url_helper
INFO - 2023-09-24 04:08:17 --> Helper loaded: file_helper
INFO - 2023-09-24 04:08:17 --> Helper loaded: html_helper
INFO - 2023-09-24 04:08:17 --> Helper loaded: text_helper
INFO - 2023-09-24 04:08:17 --> Helper loaded: form_helper
INFO - 2023-09-24 04:08:17 --> Helper loaded: lang_helper
INFO - 2023-09-24 04:08:17 --> Helper loaded: security_helper
INFO - 2023-09-24 04:08:17 --> Helper loaded: cookie_helper
INFO - 2023-09-24 04:08:17 --> Database Driver Class Initialized
INFO - 2023-09-24 04:08:17 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-24 04:08:17 --> Parser Class Initialized
INFO - 2023-09-24 04:08:17 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-24 04:08:17 --> Pagination Class Initialized
INFO - 2023-09-24 04:08:17 --> Form Validation Class Initialized
INFO - 2023-09-24 04:08:17 --> Controller Class Initialized
INFO - 2023-09-24 04:08:17 --> Model Class Initialized
DEBUG - 2023-09-24 04:08:17 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-09-24 04:08:17 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-24 04:08:17 --> Model Class Initialized
DEBUG - 2023-09-24 04:08:17 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-24 04:08:17 --> Model Class Initialized
INFO - 2023-09-24 04:08:17 --> Final output sent to browser
DEBUG - 2023-09-24 04:08:17 --> Total execution time: 0.0614
ERROR - 2023-09-24 04:08:18 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-24 04:08:18 --> Config Class Initialized
INFO - 2023-09-24 04:08:18 --> Hooks Class Initialized
DEBUG - 2023-09-24 04:08:18 --> UTF-8 Support Enabled
INFO - 2023-09-24 04:08:18 --> Utf8 Class Initialized
INFO - 2023-09-24 04:08:18 --> URI Class Initialized
INFO - 2023-09-24 04:08:18 --> Router Class Initialized
INFO - 2023-09-24 04:08:18 --> Output Class Initialized
INFO - 2023-09-24 04:08:18 --> Security Class Initialized
DEBUG - 2023-09-24 04:08:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-24 04:08:18 --> Input Class Initialized
INFO - 2023-09-24 04:08:18 --> Language Class Initialized
INFO - 2023-09-24 04:08:18 --> Loader Class Initialized
INFO - 2023-09-24 04:08:18 --> Helper loaded: url_helper
INFO - 2023-09-24 04:08:18 --> Helper loaded: file_helper
INFO - 2023-09-24 04:08:18 --> Helper loaded: html_helper
INFO - 2023-09-24 04:08:18 --> Helper loaded: text_helper
INFO - 2023-09-24 04:08:18 --> Helper loaded: form_helper
INFO - 2023-09-24 04:08:18 --> Helper loaded: lang_helper
INFO - 2023-09-24 04:08:18 --> Helper loaded: security_helper
INFO - 2023-09-24 04:08:18 --> Helper loaded: cookie_helper
INFO - 2023-09-24 04:08:18 --> Database Driver Class Initialized
INFO - 2023-09-24 04:08:18 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-24 04:08:18 --> Parser Class Initialized
INFO - 2023-09-24 04:08:18 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-24 04:08:18 --> Pagination Class Initialized
INFO - 2023-09-24 04:08:18 --> Form Validation Class Initialized
INFO - 2023-09-24 04:08:18 --> Controller Class Initialized
INFO - 2023-09-24 04:08:18 --> Model Class Initialized
DEBUG - 2023-09-24 04:08:18 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-09-24 04:08:18 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-24 04:08:18 --> Model Class Initialized
DEBUG - 2023-09-24 04:08:18 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-24 04:08:18 --> Model Class Initialized
INFO - 2023-09-24 04:08:18 --> Final output sent to browser
DEBUG - 2023-09-24 04:08:18 --> Total execution time: 0.0622
ERROR - 2023-09-24 04:08:18 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-24 04:08:18 --> Config Class Initialized
INFO - 2023-09-24 04:08:18 --> Hooks Class Initialized
DEBUG - 2023-09-24 04:08:18 --> UTF-8 Support Enabled
INFO - 2023-09-24 04:08:18 --> Utf8 Class Initialized
INFO - 2023-09-24 04:08:18 --> URI Class Initialized
INFO - 2023-09-24 04:08:18 --> Router Class Initialized
INFO - 2023-09-24 04:08:18 --> Output Class Initialized
INFO - 2023-09-24 04:08:18 --> Security Class Initialized
DEBUG - 2023-09-24 04:08:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-24 04:08:18 --> Input Class Initialized
INFO - 2023-09-24 04:08:18 --> Language Class Initialized
INFO - 2023-09-24 04:08:18 --> Loader Class Initialized
INFO - 2023-09-24 04:08:18 --> Helper loaded: url_helper
INFO - 2023-09-24 04:08:18 --> Helper loaded: file_helper
INFO - 2023-09-24 04:08:18 --> Helper loaded: html_helper
INFO - 2023-09-24 04:08:18 --> Helper loaded: text_helper
INFO - 2023-09-24 04:08:18 --> Helper loaded: form_helper
INFO - 2023-09-24 04:08:18 --> Helper loaded: lang_helper
INFO - 2023-09-24 04:08:18 --> Helper loaded: security_helper
INFO - 2023-09-24 04:08:18 --> Helper loaded: cookie_helper
INFO - 2023-09-24 04:08:18 --> Database Driver Class Initialized
INFO - 2023-09-24 04:08:18 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-24 04:08:18 --> Parser Class Initialized
INFO - 2023-09-24 04:08:18 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-24 04:08:18 --> Pagination Class Initialized
INFO - 2023-09-24 04:08:18 --> Form Validation Class Initialized
INFO - 2023-09-24 04:08:18 --> Controller Class Initialized
INFO - 2023-09-24 04:08:18 --> Model Class Initialized
DEBUG - 2023-09-24 04:08:18 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-09-24 04:08:18 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-24 04:08:18 --> Model Class Initialized
DEBUG - 2023-09-24 04:08:18 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-24 04:08:18 --> Model Class Initialized
INFO - 2023-09-24 04:08:18 --> Final output sent to browser
DEBUG - 2023-09-24 04:08:18 --> Total execution time: 0.0213
ERROR - 2023-09-24 04:08:20 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-24 04:08:20 --> Config Class Initialized
INFO - 2023-09-24 04:08:20 --> Hooks Class Initialized
DEBUG - 2023-09-24 04:08:20 --> UTF-8 Support Enabled
INFO - 2023-09-24 04:08:20 --> Utf8 Class Initialized
INFO - 2023-09-24 04:08:20 --> URI Class Initialized
INFO - 2023-09-24 04:08:20 --> Router Class Initialized
INFO - 2023-09-24 04:08:20 --> Output Class Initialized
INFO - 2023-09-24 04:08:20 --> Security Class Initialized
DEBUG - 2023-09-24 04:08:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-24 04:08:20 --> Input Class Initialized
INFO - 2023-09-24 04:08:20 --> Language Class Initialized
INFO - 2023-09-24 04:08:20 --> Loader Class Initialized
INFO - 2023-09-24 04:08:20 --> Helper loaded: url_helper
INFO - 2023-09-24 04:08:20 --> Helper loaded: file_helper
INFO - 2023-09-24 04:08:20 --> Helper loaded: html_helper
INFO - 2023-09-24 04:08:20 --> Helper loaded: text_helper
INFO - 2023-09-24 04:08:20 --> Helper loaded: form_helper
INFO - 2023-09-24 04:08:20 --> Helper loaded: lang_helper
INFO - 2023-09-24 04:08:20 --> Helper loaded: security_helper
INFO - 2023-09-24 04:08:20 --> Helper loaded: cookie_helper
INFO - 2023-09-24 04:08:20 --> Database Driver Class Initialized
INFO - 2023-09-24 04:08:20 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-24 04:08:20 --> Parser Class Initialized
INFO - 2023-09-24 04:08:20 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-24 04:08:20 --> Pagination Class Initialized
INFO - 2023-09-24 04:08:20 --> Form Validation Class Initialized
INFO - 2023-09-24 04:08:20 --> Controller Class Initialized
INFO - 2023-09-24 04:08:20 --> Model Class Initialized
DEBUG - 2023-09-24 04:08:20 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-09-24 04:08:20 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-24 04:08:20 --> Model Class Initialized
DEBUG - 2023-09-24 04:08:20 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-24 04:08:20 --> Model Class Initialized
INFO - 2023-09-24 04:08:20 --> Model Class Initialized
INFO - 2023-09-24 04:08:20 --> Final output sent to browser
DEBUG - 2023-09-24 04:08:20 --> Total execution time: 0.0216
ERROR - 2023-09-24 04:08:21 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-24 04:08:21 --> Config Class Initialized
INFO - 2023-09-24 04:08:21 --> Hooks Class Initialized
DEBUG - 2023-09-24 04:08:21 --> UTF-8 Support Enabled
INFO - 2023-09-24 04:08:21 --> Utf8 Class Initialized
INFO - 2023-09-24 04:08:21 --> URI Class Initialized
INFO - 2023-09-24 04:08:21 --> Router Class Initialized
INFO - 2023-09-24 04:08:21 --> Output Class Initialized
INFO - 2023-09-24 04:08:21 --> Security Class Initialized
DEBUG - 2023-09-24 04:08:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-24 04:08:21 --> Input Class Initialized
INFO - 2023-09-24 04:08:21 --> Language Class Initialized
INFO - 2023-09-24 04:08:21 --> Loader Class Initialized
INFO - 2023-09-24 04:08:21 --> Helper loaded: url_helper
INFO - 2023-09-24 04:08:21 --> Helper loaded: file_helper
INFO - 2023-09-24 04:08:21 --> Helper loaded: html_helper
INFO - 2023-09-24 04:08:21 --> Helper loaded: text_helper
INFO - 2023-09-24 04:08:21 --> Helper loaded: form_helper
INFO - 2023-09-24 04:08:21 --> Helper loaded: lang_helper
INFO - 2023-09-24 04:08:21 --> Helper loaded: security_helper
INFO - 2023-09-24 04:08:21 --> Helper loaded: cookie_helper
INFO - 2023-09-24 04:08:21 --> Database Driver Class Initialized
INFO - 2023-09-24 04:08:21 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-24 04:08:21 --> Parser Class Initialized
INFO - 2023-09-24 04:08:21 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-24 04:08:21 --> Pagination Class Initialized
INFO - 2023-09-24 04:08:21 --> Form Validation Class Initialized
INFO - 2023-09-24 04:08:21 --> Controller Class Initialized
INFO - 2023-09-24 04:08:21 --> Model Class Initialized
DEBUG - 2023-09-24 04:08:21 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-09-24 04:08:21 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-24 04:08:21 --> Model Class Initialized
DEBUG - 2023-09-24 04:08:21 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-24 04:08:21 --> Model Class Initialized
INFO - 2023-09-24 04:08:21 --> Final output sent to browser
DEBUG - 2023-09-24 04:08:21 --> Total execution time: 0.0183
ERROR - 2023-09-24 04:08:26 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-24 04:08:26 --> Config Class Initialized
INFO - 2023-09-24 04:08:26 --> Hooks Class Initialized
DEBUG - 2023-09-24 04:08:26 --> UTF-8 Support Enabled
INFO - 2023-09-24 04:08:26 --> Utf8 Class Initialized
INFO - 2023-09-24 04:08:26 --> URI Class Initialized
INFO - 2023-09-24 04:08:26 --> Router Class Initialized
INFO - 2023-09-24 04:08:26 --> Output Class Initialized
INFO - 2023-09-24 04:08:26 --> Security Class Initialized
DEBUG - 2023-09-24 04:08:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-24 04:08:26 --> Input Class Initialized
INFO - 2023-09-24 04:08:26 --> Language Class Initialized
INFO - 2023-09-24 04:08:26 --> Loader Class Initialized
INFO - 2023-09-24 04:08:26 --> Helper loaded: url_helper
INFO - 2023-09-24 04:08:26 --> Helper loaded: file_helper
INFO - 2023-09-24 04:08:26 --> Helper loaded: html_helper
INFO - 2023-09-24 04:08:26 --> Helper loaded: text_helper
INFO - 2023-09-24 04:08:26 --> Helper loaded: form_helper
INFO - 2023-09-24 04:08:26 --> Helper loaded: lang_helper
INFO - 2023-09-24 04:08:26 --> Helper loaded: security_helper
INFO - 2023-09-24 04:08:26 --> Helper loaded: cookie_helper
INFO - 2023-09-24 04:08:26 --> Database Driver Class Initialized
INFO - 2023-09-24 04:08:26 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-24 04:08:26 --> Parser Class Initialized
INFO - 2023-09-24 04:08:26 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-24 04:08:26 --> Pagination Class Initialized
INFO - 2023-09-24 04:08:26 --> Form Validation Class Initialized
INFO - 2023-09-24 04:08:26 --> Controller Class Initialized
INFO - 2023-09-24 04:08:26 --> Model Class Initialized
DEBUG - 2023-09-24 04:08:26 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-09-24 04:08:26 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-24 04:08:26 --> Model Class Initialized
DEBUG - 2023-09-24 04:08:26 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-24 04:08:26 --> Model Class Initialized
INFO - 2023-09-24 04:08:26 --> Final output sent to browser
DEBUG - 2023-09-24 04:08:26 --> Total execution time: 0.0630
ERROR - 2023-09-24 04:08:27 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-24 04:08:27 --> Config Class Initialized
INFO - 2023-09-24 04:08:27 --> Hooks Class Initialized
DEBUG - 2023-09-24 04:08:27 --> UTF-8 Support Enabled
INFO - 2023-09-24 04:08:27 --> Utf8 Class Initialized
INFO - 2023-09-24 04:08:27 --> URI Class Initialized
INFO - 2023-09-24 04:08:27 --> Router Class Initialized
INFO - 2023-09-24 04:08:27 --> Output Class Initialized
INFO - 2023-09-24 04:08:27 --> Security Class Initialized
DEBUG - 2023-09-24 04:08:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-24 04:08:27 --> Input Class Initialized
INFO - 2023-09-24 04:08:27 --> Language Class Initialized
INFO - 2023-09-24 04:08:27 --> Loader Class Initialized
INFO - 2023-09-24 04:08:27 --> Helper loaded: url_helper
INFO - 2023-09-24 04:08:27 --> Helper loaded: file_helper
INFO - 2023-09-24 04:08:27 --> Helper loaded: html_helper
INFO - 2023-09-24 04:08:27 --> Helper loaded: text_helper
INFO - 2023-09-24 04:08:27 --> Helper loaded: form_helper
INFO - 2023-09-24 04:08:27 --> Helper loaded: lang_helper
INFO - 2023-09-24 04:08:27 --> Helper loaded: security_helper
INFO - 2023-09-24 04:08:27 --> Helper loaded: cookie_helper
INFO - 2023-09-24 04:08:27 --> Database Driver Class Initialized
INFO - 2023-09-24 04:08:27 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-24 04:08:27 --> Parser Class Initialized
INFO - 2023-09-24 04:08:27 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-24 04:08:27 --> Pagination Class Initialized
INFO - 2023-09-24 04:08:27 --> Form Validation Class Initialized
INFO - 2023-09-24 04:08:27 --> Controller Class Initialized
INFO - 2023-09-24 04:08:27 --> Model Class Initialized
DEBUG - 2023-09-24 04:08:27 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-09-24 04:08:27 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-24 04:08:27 --> Model Class Initialized
DEBUG - 2023-09-24 04:08:27 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-24 04:08:27 --> Model Class Initialized
INFO - 2023-09-24 04:08:27 --> Final output sent to browser
DEBUG - 2023-09-24 04:08:27 --> Total execution time: 0.0187
ERROR - 2023-09-24 04:08:28 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-24 04:08:28 --> Config Class Initialized
INFO - 2023-09-24 04:08:28 --> Hooks Class Initialized
DEBUG - 2023-09-24 04:08:28 --> UTF-8 Support Enabled
INFO - 2023-09-24 04:08:28 --> Utf8 Class Initialized
INFO - 2023-09-24 04:08:28 --> URI Class Initialized
INFO - 2023-09-24 04:08:28 --> Router Class Initialized
INFO - 2023-09-24 04:08:28 --> Output Class Initialized
INFO - 2023-09-24 04:08:28 --> Security Class Initialized
DEBUG - 2023-09-24 04:08:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-24 04:08:28 --> Input Class Initialized
INFO - 2023-09-24 04:08:28 --> Language Class Initialized
INFO - 2023-09-24 04:08:28 --> Loader Class Initialized
INFO - 2023-09-24 04:08:28 --> Helper loaded: url_helper
INFO - 2023-09-24 04:08:28 --> Helper loaded: file_helper
INFO - 2023-09-24 04:08:28 --> Helper loaded: html_helper
INFO - 2023-09-24 04:08:28 --> Helper loaded: text_helper
INFO - 2023-09-24 04:08:28 --> Helper loaded: form_helper
INFO - 2023-09-24 04:08:28 --> Helper loaded: lang_helper
INFO - 2023-09-24 04:08:28 --> Helper loaded: security_helper
INFO - 2023-09-24 04:08:28 --> Helper loaded: cookie_helper
INFO - 2023-09-24 04:08:28 --> Database Driver Class Initialized
INFO - 2023-09-24 04:08:28 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-24 04:08:28 --> Parser Class Initialized
INFO - 2023-09-24 04:08:28 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-24 04:08:28 --> Pagination Class Initialized
INFO - 2023-09-24 04:08:28 --> Form Validation Class Initialized
INFO - 2023-09-24 04:08:28 --> Controller Class Initialized
INFO - 2023-09-24 04:08:28 --> Model Class Initialized
DEBUG - 2023-09-24 04:08:28 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-09-24 04:08:28 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-24 04:08:28 --> Model Class Initialized
DEBUG - 2023-09-24 04:08:28 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-24 04:08:28 --> Model Class Initialized
INFO - 2023-09-24 04:08:29 --> Final output sent to browser
DEBUG - 2023-09-24 04:08:29 --> Total execution time: 0.0676
ERROR - 2023-09-24 04:08:29 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-24 04:08:29 --> Config Class Initialized
INFO - 2023-09-24 04:08:29 --> Hooks Class Initialized
DEBUG - 2023-09-24 04:08:29 --> UTF-8 Support Enabled
INFO - 2023-09-24 04:08:29 --> Utf8 Class Initialized
INFO - 2023-09-24 04:08:29 --> URI Class Initialized
INFO - 2023-09-24 04:08:29 --> Router Class Initialized
INFO - 2023-09-24 04:08:29 --> Output Class Initialized
INFO - 2023-09-24 04:08:29 --> Security Class Initialized
DEBUG - 2023-09-24 04:08:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-24 04:08:29 --> Input Class Initialized
INFO - 2023-09-24 04:08:29 --> Language Class Initialized
INFO - 2023-09-24 04:08:29 --> Loader Class Initialized
INFO - 2023-09-24 04:08:29 --> Helper loaded: url_helper
INFO - 2023-09-24 04:08:29 --> Helper loaded: file_helper
INFO - 2023-09-24 04:08:29 --> Helper loaded: html_helper
INFO - 2023-09-24 04:08:29 --> Helper loaded: text_helper
INFO - 2023-09-24 04:08:29 --> Helper loaded: form_helper
INFO - 2023-09-24 04:08:29 --> Helper loaded: lang_helper
INFO - 2023-09-24 04:08:29 --> Helper loaded: security_helper
INFO - 2023-09-24 04:08:29 --> Helper loaded: cookie_helper
INFO - 2023-09-24 04:08:29 --> Database Driver Class Initialized
INFO - 2023-09-24 04:08:29 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-24 04:08:29 --> Parser Class Initialized
INFO - 2023-09-24 04:08:29 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-24 04:08:29 --> Pagination Class Initialized
INFO - 2023-09-24 04:08:29 --> Form Validation Class Initialized
INFO - 2023-09-24 04:08:29 --> Controller Class Initialized
INFO - 2023-09-24 04:08:29 --> Model Class Initialized
DEBUG - 2023-09-24 04:08:29 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-09-24 04:08:29 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-24 04:08:29 --> Model Class Initialized
DEBUG - 2023-09-24 04:08:29 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-24 04:08:29 --> Model Class Initialized
INFO - 2023-09-24 04:08:29 --> Final output sent to browser
DEBUG - 2023-09-24 04:08:29 --> Total execution time: 0.0627
ERROR - 2023-09-24 04:08:31 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-24 04:08:31 --> Config Class Initialized
INFO - 2023-09-24 04:08:31 --> Hooks Class Initialized
DEBUG - 2023-09-24 04:08:31 --> UTF-8 Support Enabled
INFO - 2023-09-24 04:08:31 --> Utf8 Class Initialized
INFO - 2023-09-24 04:08:31 --> URI Class Initialized
INFO - 2023-09-24 04:08:31 --> Router Class Initialized
INFO - 2023-09-24 04:08:31 --> Output Class Initialized
INFO - 2023-09-24 04:08:31 --> Security Class Initialized
DEBUG - 2023-09-24 04:08:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-24 04:08:31 --> Input Class Initialized
INFO - 2023-09-24 04:08:31 --> Language Class Initialized
INFO - 2023-09-24 04:08:31 --> Loader Class Initialized
INFO - 2023-09-24 04:08:31 --> Helper loaded: url_helper
INFO - 2023-09-24 04:08:31 --> Helper loaded: file_helper
INFO - 2023-09-24 04:08:31 --> Helper loaded: html_helper
INFO - 2023-09-24 04:08:31 --> Helper loaded: text_helper
INFO - 2023-09-24 04:08:31 --> Helper loaded: form_helper
INFO - 2023-09-24 04:08:31 --> Helper loaded: lang_helper
INFO - 2023-09-24 04:08:31 --> Helper loaded: security_helper
INFO - 2023-09-24 04:08:31 --> Helper loaded: cookie_helper
INFO - 2023-09-24 04:08:31 --> Database Driver Class Initialized
INFO - 2023-09-24 04:08:31 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-24 04:08:31 --> Parser Class Initialized
INFO - 2023-09-24 04:08:31 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-24 04:08:31 --> Pagination Class Initialized
INFO - 2023-09-24 04:08:31 --> Form Validation Class Initialized
INFO - 2023-09-24 04:08:31 --> Controller Class Initialized
INFO - 2023-09-24 04:08:31 --> Model Class Initialized
DEBUG - 2023-09-24 04:08:31 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-09-24 04:08:31 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-24 04:08:31 --> Model Class Initialized
DEBUG - 2023-09-24 04:08:31 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-24 04:08:31 --> Model Class Initialized
INFO - 2023-09-24 04:08:31 --> Final output sent to browser
DEBUG - 2023-09-24 04:08:31 --> Total execution time: 0.0693
ERROR - 2023-09-24 04:08:31 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-24 04:08:31 --> Config Class Initialized
INFO - 2023-09-24 04:08:31 --> Hooks Class Initialized
DEBUG - 2023-09-24 04:08:31 --> UTF-8 Support Enabled
INFO - 2023-09-24 04:08:31 --> Utf8 Class Initialized
INFO - 2023-09-24 04:08:31 --> URI Class Initialized
INFO - 2023-09-24 04:08:31 --> Router Class Initialized
INFO - 2023-09-24 04:08:31 --> Output Class Initialized
INFO - 2023-09-24 04:08:31 --> Security Class Initialized
DEBUG - 2023-09-24 04:08:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-24 04:08:31 --> Input Class Initialized
INFO - 2023-09-24 04:08:31 --> Language Class Initialized
INFO - 2023-09-24 04:08:31 --> Loader Class Initialized
INFO - 2023-09-24 04:08:31 --> Helper loaded: url_helper
INFO - 2023-09-24 04:08:31 --> Helper loaded: file_helper
INFO - 2023-09-24 04:08:31 --> Helper loaded: html_helper
INFO - 2023-09-24 04:08:31 --> Helper loaded: text_helper
INFO - 2023-09-24 04:08:31 --> Helper loaded: form_helper
INFO - 2023-09-24 04:08:31 --> Helper loaded: lang_helper
INFO - 2023-09-24 04:08:31 --> Helper loaded: security_helper
INFO - 2023-09-24 04:08:31 --> Helper loaded: cookie_helper
INFO - 2023-09-24 04:08:31 --> Database Driver Class Initialized
INFO - 2023-09-24 04:08:31 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-24 04:08:31 --> Parser Class Initialized
INFO - 2023-09-24 04:08:31 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-24 04:08:31 --> Pagination Class Initialized
INFO - 2023-09-24 04:08:31 --> Form Validation Class Initialized
INFO - 2023-09-24 04:08:31 --> Controller Class Initialized
INFO - 2023-09-24 04:08:31 --> Model Class Initialized
DEBUG - 2023-09-24 04:08:31 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-09-24 04:08:31 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-24 04:08:31 --> Model Class Initialized
DEBUG - 2023-09-24 04:08:31 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-24 04:08:31 --> Model Class Initialized
INFO - 2023-09-24 04:08:31 --> Final output sent to browser
DEBUG - 2023-09-24 04:08:31 --> Total execution time: 0.0632
ERROR - 2023-09-24 04:08:32 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-24 04:08:32 --> Config Class Initialized
INFO - 2023-09-24 04:08:32 --> Hooks Class Initialized
DEBUG - 2023-09-24 04:08:32 --> UTF-8 Support Enabled
INFO - 2023-09-24 04:08:32 --> Utf8 Class Initialized
INFO - 2023-09-24 04:08:32 --> URI Class Initialized
INFO - 2023-09-24 04:08:32 --> Router Class Initialized
INFO - 2023-09-24 04:08:32 --> Output Class Initialized
INFO - 2023-09-24 04:08:32 --> Security Class Initialized
DEBUG - 2023-09-24 04:08:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-24 04:08:32 --> Input Class Initialized
INFO - 2023-09-24 04:08:32 --> Language Class Initialized
INFO - 2023-09-24 04:08:32 --> Loader Class Initialized
INFO - 2023-09-24 04:08:32 --> Helper loaded: url_helper
INFO - 2023-09-24 04:08:32 --> Helper loaded: file_helper
INFO - 2023-09-24 04:08:32 --> Helper loaded: html_helper
INFO - 2023-09-24 04:08:32 --> Helper loaded: text_helper
INFO - 2023-09-24 04:08:32 --> Helper loaded: form_helper
INFO - 2023-09-24 04:08:32 --> Helper loaded: lang_helper
INFO - 2023-09-24 04:08:32 --> Helper loaded: security_helper
INFO - 2023-09-24 04:08:32 --> Helper loaded: cookie_helper
INFO - 2023-09-24 04:08:32 --> Database Driver Class Initialized
INFO - 2023-09-24 04:08:32 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-24 04:08:32 --> Parser Class Initialized
INFO - 2023-09-24 04:08:32 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-24 04:08:32 --> Pagination Class Initialized
INFO - 2023-09-24 04:08:32 --> Form Validation Class Initialized
INFO - 2023-09-24 04:08:32 --> Controller Class Initialized
INFO - 2023-09-24 04:08:32 --> Model Class Initialized
DEBUG - 2023-09-24 04:08:32 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-09-24 04:08:32 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-24 04:08:32 --> Model Class Initialized
DEBUG - 2023-09-24 04:08:32 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-24 04:08:32 --> Model Class Initialized
INFO - 2023-09-24 04:08:32 --> Final output sent to browser
DEBUG - 2023-09-24 04:08:32 --> Total execution time: 0.0340
ERROR - 2023-09-24 04:08:33 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-24 04:08:33 --> Config Class Initialized
INFO - 2023-09-24 04:08:33 --> Hooks Class Initialized
DEBUG - 2023-09-24 04:08:33 --> UTF-8 Support Enabled
INFO - 2023-09-24 04:08:33 --> Utf8 Class Initialized
INFO - 2023-09-24 04:08:33 --> URI Class Initialized
INFO - 2023-09-24 04:08:33 --> Router Class Initialized
INFO - 2023-09-24 04:08:33 --> Output Class Initialized
INFO - 2023-09-24 04:08:33 --> Security Class Initialized
DEBUG - 2023-09-24 04:08:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-24 04:08:33 --> Input Class Initialized
INFO - 2023-09-24 04:08:33 --> Language Class Initialized
INFO - 2023-09-24 04:08:33 --> Loader Class Initialized
INFO - 2023-09-24 04:08:33 --> Helper loaded: url_helper
INFO - 2023-09-24 04:08:33 --> Helper loaded: file_helper
INFO - 2023-09-24 04:08:33 --> Helper loaded: html_helper
INFO - 2023-09-24 04:08:33 --> Helper loaded: text_helper
INFO - 2023-09-24 04:08:33 --> Helper loaded: form_helper
INFO - 2023-09-24 04:08:33 --> Helper loaded: lang_helper
INFO - 2023-09-24 04:08:33 --> Helper loaded: security_helper
INFO - 2023-09-24 04:08:33 --> Helper loaded: cookie_helper
INFO - 2023-09-24 04:08:33 --> Database Driver Class Initialized
INFO - 2023-09-24 04:08:33 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-24 04:08:33 --> Parser Class Initialized
INFO - 2023-09-24 04:08:33 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-24 04:08:33 --> Pagination Class Initialized
INFO - 2023-09-24 04:08:33 --> Form Validation Class Initialized
INFO - 2023-09-24 04:08:33 --> Controller Class Initialized
INFO - 2023-09-24 04:08:33 --> Model Class Initialized
DEBUG - 2023-09-24 04:08:33 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-09-24 04:08:33 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-24 04:08:33 --> Model Class Initialized
DEBUG - 2023-09-24 04:08:33 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-24 04:08:33 --> Model Class Initialized
INFO - 2023-09-24 04:08:33 --> Final output sent to browser
DEBUG - 2023-09-24 04:08:33 --> Total execution time: 0.0251
ERROR - 2023-09-24 04:08:35 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-24 04:08:35 --> Config Class Initialized
INFO - 2023-09-24 04:08:35 --> Hooks Class Initialized
DEBUG - 2023-09-24 04:08:35 --> UTF-8 Support Enabled
INFO - 2023-09-24 04:08:35 --> Utf8 Class Initialized
INFO - 2023-09-24 04:08:35 --> URI Class Initialized
INFO - 2023-09-24 04:08:35 --> Router Class Initialized
INFO - 2023-09-24 04:08:35 --> Output Class Initialized
INFO - 2023-09-24 04:08:35 --> Security Class Initialized
DEBUG - 2023-09-24 04:08:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-24 04:08:35 --> Input Class Initialized
INFO - 2023-09-24 04:08:35 --> Language Class Initialized
INFO - 2023-09-24 04:08:35 --> Loader Class Initialized
INFO - 2023-09-24 04:08:35 --> Helper loaded: url_helper
INFO - 2023-09-24 04:08:35 --> Helper loaded: file_helper
INFO - 2023-09-24 04:08:35 --> Helper loaded: html_helper
INFO - 2023-09-24 04:08:35 --> Helper loaded: text_helper
INFO - 2023-09-24 04:08:35 --> Helper loaded: form_helper
INFO - 2023-09-24 04:08:35 --> Helper loaded: lang_helper
INFO - 2023-09-24 04:08:35 --> Helper loaded: security_helper
INFO - 2023-09-24 04:08:35 --> Helper loaded: cookie_helper
INFO - 2023-09-24 04:08:35 --> Database Driver Class Initialized
INFO - 2023-09-24 04:08:35 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-24 04:08:35 --> Parser Class Initialized
INFO - 2023-09-24 04:08:35 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-24 04:08:35 --> Pagination Class Initialized
INFO - 2023-09-24 04:08:35 --> Form Validation Class Initialized
INFO - 2023-09-24 04:08:35 --> Controller Class Initialized
INFO - 2023-09-24 04:08:35 --> Model Class Initialized
DEBUG - 2023-09-24 04:08:35 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-09-24 04:08:35 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-24 04:08:35 --> Model Class Initialized
DEBUG - 2023-09-24 04:08:35 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-24 04:08:35 --> Model Class Initialized
INFO - 2023-09-24 04:08:35 --> Model Class Initialized
INFO - 2023-09-24 04:08:35 --> Final output sent to browser
DEBUG - 2023-09-24 04:08:35 --> Total execution time: 0.0259
ERROR - 2023-09-24 04:08:43 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-24 04:08:43 --> Config Class Initialized
INFO - 2023-09-24 04:08:43 --> Hooks Class Initialized
DEBUG - 2023-09-24 04:08:43 --> UTF-8 Support Enabled
INFO - 2023-09-24 04:08:43 --> Utf8 Class Initialized
INFO - 2023-09-24 04:08:43 --> URI Class Initialized
INFO - 2023-09-24 04:08:43 --> Router Class Initialized
INFO - 2023-09-24 04:08:43 --> Output Class Initialized
INFO - 2023-09-24 04:08:43 --> Security Class Initialized
DEBUG - 2023-09-24 04:08:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-24 04:08:43 --> Input Class Initialized
INFO - 2023-09-24 04:08:43 --> Language Class Initialized
INFO - 2023-09-24 04:08:43 --> Loader Class Initialized
INFO - 2023-09-24 04:08:43 --> Helper loaded: url_helper
INFO - 2023-09-24 04:08:43 --> Helper loaded: file_helper
INFO - 2023-09-24 04:08:43 --> Helper loaded: html_helper
INFO - 2023-09-24 04:08:43 --> Helper loaded: text_helper
INFO - 2023-09-24 04:08:43 --> Helper loaded: form_helper
INFO - 2023-09-24 04:08:43 --> Helper loaded: lang_helper
INFO - 2023-09-24 04:08:43 --> Helper loaded: security_helper
INFO - 2023-09-24 04:08:43 --> Helper loaded: cookie_helper
INFO - 2023-09-24 04:08:43 --> Database Driver Class Initialized
INFO - 2023-09-24 04:08:43 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-24 04:08:43 --> Parser Class Initialized
INFO - 2023-09-24 04:08:43 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-24 04:08:43 --> Pagination Class Initialized
INFO - 2023-09-24 04:08:43 --> Form Validation Class Initialized
INFO - 2023-09-24 04:08:43 --> Controller Class Initialized
INFO - 2023-09-24 04:08:43 --> Model Class Initialized
DEBUG - 2023-09-24 04:08:43 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-09-24 04:08:43 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-24 04:08:43 --> Model Class Initialized
DEBUG - 2023-09-24 04:08:43 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-24 04:08:43 --> Model Class Initialized
INFO - 2023-09-24 04:08:43 --> Final output sent to browser
DEBUG - 2023-09-24 04:08:43 --> Total execution time: 0.0644
ERROR - 2023-09-24 04:08:44 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-24 04:08:44 --> Config Class Initialized
INFO - 2023-09-24 04:08:44 --> Hooks Class Initialized
DEBUG - 2023-09-24 04:08:44 --> UTF-8 Support Enabled
INFO - 2023-09-24 04:08:44 --> Utf8 Class Initialized
INFO - 2023-09-24 04:08:44 --> URI Class Initialized
INFO - 2023-09-24 04:08:44 --> Router Class Initialized
INFO - 2023-09-24 04:08:44 --> Output Class Initialized
INFO - 2023-09-24 04:08:44 --> Security Class Initialized
DEBUG - 2023-09-24 04:08:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-24 04:08:44 --> Input Class Initialized
INFO - 2023-09-24 04:08:44 --> Language Class Initialized
INFO - 2023-09-24 04:08:44 --> Loader Class Initialized
INFO - 2023-09-24 04:08:44 --> Helper loaded: url_helper
INFO - 2023-09-24 04:08:44 --> Helper loaded: file_helper
INFO - 2023-09-24 04:08:44 --> Helper loaded: html_helper
INFO - 2023-09-24 04:08:44 --> Helper loaded: text_helper
INFO - 2023-09-24 04:08:44 --> Helper loaded: form_helper
INFO - 2023-09-24 04:08:44 --> Helper loaded: lang_helper
INFO - 2023-09-24 04:08:44 --> Helper loaded: security_helper
INFO - 2023-09-24 04:08:44 --> Helper loaded: cookie_helper
INFO - 2023-09-24 04:08:44 --> Database Driver Class Initialized
INFO - 2023-09-24 04:08:44 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-24 04:08:44 --> Parser Class Initialized
INFO - 2023-09-24 04:08:44 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-24 04:08:44 --> Pagination Class Initialized
INFO - 2023-09-24 04:08:44 --> Form Validation Class Initialized
INFO - 2023-09-24 04:08:44 --> Controller Class Initialized
INFO - 2023-09-24 04:08:44 --> Model Class Initialized
DEBUG - 2023-09-24 04:08:44 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-09-24 04:08:44 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-24 04:08:44 --> Model Class Initialized
DEBUG - 2023-09-24 04:08:44 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-24 04:08:44 --> Model Class Initialized
INFO - 2023-09-24 04:08:44 --> Final output sent to browser
DEBUG - 2023-09-24 04:08:44 --> Total execution time: 0.0745
ERROR - 2023-09-24 04:08:44 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-24 04:08:44 --> Config Class Initialized
INFO - 2023-09-24 04:08:44 --> Hooks Class Initialized
DEBUG - 2023-09-24 04:08:44 --> UTF-8 Support Enabled
INFO - 2023-09-24 04:08:44 --> Utf8 Class Initialized
INFO - 2023-09-24 04:08:44 --> URI Class Initialized
INFO - 2023-09-24 04:08:44 --> Router Class Initialized
INFO - 2023-09-24 04:08:44 --> Output Class Initialized
INFO - 2023-09-24 04:08:44 --> Security Class Initialized
DEBUG - 2023-09-24 04:08:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-24 04:08:44 --> Input Class Initialized
INFO - 2023-09-24 04:08:44 --> Language Class Initialized
INFO - 2023-09-24 04:08:44 --> Loader Class Initialized
INFO - 2023-09-24 04:08:44 --> Helper loaded: url_helper
INFO - 2023-09-24 04:08:44 --> Helper loaded: file_helper
INFO - 2023-09-24 04:08:44 --> Helper loaded: html_helper
INFO - 2023-09-24 04:08:44 --> Helper loaded: text_helper
INFO - 2023-09-24 04:08:44 --> Helper loaded: form_helper
INFO - 2023-09-24 04:08:44 --> Helper loaded: lang_helper
INFO - 2023-09-24 04:08:44 --> Helper loaded: security_helper
INFO - 2023-09-24 04:08:44 --> Helper loaded: cookie_helper
INFO - 2023-09-24 04:08:44 --> Database Driver Class Initialized
INFO - 2023-09-24 04:08:44 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-24 04:08:44 --> Parser Class Initialized
INFO - 2023-09-24 04:08:44 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-24 04:08:44 --> Pagination Class Initialized
INFO - 2023-09-24 04:08:44 --> Form Validation Class Initialized
INFO - 2023-09-24 04:08:44 --> Controller Class Initialized
INFO - 2023-09-24 04:08:44 --> Model Class Initialized
DEBUG - 2023-09-24 04:08:44 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-09-24 04:08:44 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-24 04:08:44 --> Model Class Initialized
DEBUG - 2023-09-24 04:08:44 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-24 04:08:44 --> Model Class Initialized
INFO - 2023-09-24 04:08:44 --> Final output sent to browser
DEBUG - 2023-09-24 04:08:44 --> Total execution time: 0.0736
ERROR - 2023-09-24 04:08:45 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-24 04:08:45 --> Config Class Initialized
INFO - 2023-09-24 04:08:45 --> Hooks Class Initialized
DEBUG - 2023-09-24 04:08:45 --> UTF-8 Support Enabled
INFO - 2023-09-24 04:08:45 --> Utf8 Class Initialized
INFO - 2023-09-24 04:08:45 --> URI Class Initialized
INFO - 2023-09-24 04:08:45 --> Router Class Initialized
INFO - 2023-09-24 04:08:45 --> Output Class Initialized
INFO - 2023-09-24 04:08:45 --> Security Class Initialized
DEBUG - 2023-09-24 04:08:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-24 04:08:45 --> Input Class Initialized
INFO - 2023-09-24 04:08:45 --> Language Class Initialized
INFO - 2023-09-24 04:08:45 --> Loader Class Initialized
INFO - 2023-09-24 04:08:45 --> Helper loaded: url_helper
INFO - 2023-09-24 04:08:45 --> Helper loaded: file_helper
INFO - 2023-09-24 04:08:45 --> Helper loaded: html_helper
INFO - 2023-09-24 04:08:45 --> Helper loaded: text_helper
INFO - 2023-09-24 04:08:45 --> Helper loaded: form_helper
INFO - 2023-09-24 04:08:45 --> Helper loaded: lang_helper
INFO - 2023-09-24 04:08:45 --> Helper loaded: security_helper
INFO - 2023-09-24 04:08:45 --> Helper loaded: cookie_helper
INFO - 2023-09-24 04:08:45 --> Database Driver Class Initialized
INFO - 2023-09-24 04:08:45 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-24 04:08:45 --> Parser Class Initialized
INFO - 2023-09-24 04:08:45 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-24 04:08:45 --> Pagination Class Initialized
INFO - 2023-09-24 04:08:45 --> Form Validation Class Initialized
INFO - 2023-09-24 04:08:45 --> Controller Class Initialized
INFO - 2023-09-24 04:08:45 --> Model Class Initialized
DEBUG - 2023-09-24 04:08:45 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-09-24 04:08:45 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-24 04:08:45 --> Model Class Initialized
DEBUG - 2023-09-24 04:08:45 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-24 04:08:45 --> Model Class Initialized
INFO - 2023-09-24 04:08:45 --> Final output sent to browser
DEBUG - 2023-09-24 04:08:45 --> Total execution time: 0.0621
ERROR - 2023-09-24 04:08:47 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-24 04:08:47 --> Config Class Initialized
INFO - 2023-09-24 04:08:47 --> Hooks Class Initialized
DEBUG - 2023-09-24 04:08:47 --> UTF-8 Support Enabled
INFO - 2023-09-24 04:08:47 --> Utf8 Class Initialized
INFO - 2023-09-24 04:08:47 --> URI Class Initialized
INFO - 2023-09-24 04:08:47 --> Router Class Initialized
INFO - 2023-09-24 04:08:47 --> Output Class Initialized
INFO - 2023-09-24 04:08:47 --> Security Class Initialized
DEBUG - 2023-09-24 04:08:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-24 04:08:47 --> Input Class Initialized
INFO - 2023-09-24 04:08:47 --> Language Class Initialized
INFO - 2023-09-24 04:08:47 --> Loader Class Initialized
INFO - 2023-09-24 04:08:47 --> Helper loaded: url_helper
INFO - 2023-09-24 04:08:47 --> Helper loaded: file_helper
INFO - 2023-09-24 04:08:47 --> Helper loaded: html_helper
INFO - 2023-09-24 04:08:47 --> Helper loaded: text_helper
INFO - 2023-09-24 04:08:47 --> Helper loaded: form_helper
INFO - 2023-09-24 04:08:47 --> Helper loaded: lang_helper
INFO - 2023-09-24 04:08:47 --> Helper loaded: security_helper
INFO - 2023-09-24 04:08:47 --> Helper loaded: cookie_helper
INFO - 2023-09-24 04:08:47 --> Database Driver Class Initialized
INFO - 2023-09-24 04:08:47 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-24 04:08:47 --> Parser Class Initialized
INFO - 2023-09-24 04:08:47 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-24 04:08:47 --> Pagination Class Initialized
INFO - 2023-09-24 04:08:47 --> Form Validation Class Initialized
INFO - 2023-09-24 04:08:47 --> Controller Class Initialized
INFO - 2023-09-24 04:08:47 --> Model Class Initialized
DEBUG - 2023-09-24 04:08:47 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-09-24 04:08:47 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-24 04:08:47 --> Model Class Initialized
DEBUG - 2023-09-24 04:08:47 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-24 04:08:47 --> Model Class Initialized
INFO - 2023-09-24 04:08:47 --> Final output sent to browser
DEBUG - 2023-09-24 04:08:47 --> Total execution time: 0.0301
ERROR - 2023-09-24 04:08:48 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-24 04:08:48 --> Config Class Initialized
INFO - 2023-09-24 04:08:48 --> Hooks Class Initialized
DEBUG - 2023-09-24 04:08:48 --> UTF-8 Support Enabled
INFO - 2023-09-24 04:08:48 --> Utf8 Class Initialized
INFO - 2023-09-24 04:08:48 --> URI Class Initialized
INFO - 2023-09-24 04:08:48 --> Router Class Initialized
INFO - 2023-09-24 04:08:48 --> Output Class Initialized
INFO - 2023-09-24 04:08:48 --> Security Class Initialized
DEBUG - 2023-09-24 04:08:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-24 04:08:48 --> Input Class Initialized
INFO - 2023-09-24 04:08:48 --> Language Class Initialized
INFO - 2023-09-24 04:08:48 --> Loader Class Initialized
INFO - 2023-09-24 04:08:48 --> Helper loaded: url_helper
INFO - 2023-09-24 04:08:48 --> Helper loaded: file_helper
INFO - 2023-09-24 04:08:48 --> Helper loaded: html_helper
INFO - 2023-09-24 04:08:48 --> Helper loaded: text_helper
INFO - 2023-09-24 04:08:48 --> Helper loaded: form_helper
INFO - 2023-09-24 04:08:48 --> Helper loaded: lang_helper
INFO - 2023-09-24 04:08:48 --> Helper loaded: security_helper
INFO - 2023-09-24 04:08:48 --> Helper loaded: cookie_helper
INFO - 2023-09-24 04:08:48 --> Database Driver Class Initialized
INFO - 2023-09-24 04:08:48 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-24 04:08:48 --> Parser Class Initialized
INFO - 2023-09-24 04:08:48 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-24 04:08:48 --> Pagination Class Initialized
INFO - 2023-09-24 04:08:48 --> Form Validation Class Initialized
INFO - 2023-09-24 04:08:48 --> Controller Class Initialized
INFO - 2023-09-24 04:08:48 --> Model Class Initialized
DEBUG - 2023-09-24 04:08:48 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-09-24 04:08:48 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-24 04:08:48 --> Model Class Initialized
DEBUG - 2023-09-24 04:08:48 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-24 04:08:48 --> Model Class Initialized
INFO - 2023-09-24 04:08:48 --> Final output sent to browser
DEBUG - 2023-09-24 04:08:48 --> Total execution time: 0.0205
ERROR - 2023-09-24 04:08:49 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-24 04:08:49 --> Config Class Initialized
INFO - 2023-09-24 04:08:49 --> Hooks Class Initialized
DEBUG - 2023-09-24 04:08:49 --> UTF-8 Support Enabled
INFO - 2023-09-24 04:08:49 --> Utf8 Class Initialized
INFO - 2023-09-24 04:08:49 --> URI Class Initialized
INFO - 2023-09-24 04:08:49 --> Router Class Initialized
INFO - 2023-09-24 04:08:49 --> Output Class Initialized
INFO - 2023-09-24 04:08:49 --> Security Class Initialized
DEBUG - 2023-09-24 04:08:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-24 04:08:49 --> Input Class Initialized
INFO - 2023-09-24 04:08:49 --> Language Class Initialized
INFO - 2023-09-24 04:08:49 --> Loader Class Initialized
INFO - 2023-09-24 04:08:49 --> Helper loaded: url_helper
INFO - 2023-09-24 04:08:49 --> Helper loaded: file_helper
INFO - 2023-09-24 04:08:49 --> Helper loaded: html_helper
INFO - 2023-09-24 04:08:49 --> Helper loaded: text_helper
INFO - 2023-09-24 04:08:49 --> Helper loaded: form_helper
INFO - 2023-09-24 04:08:49 --> Helper loaded: lang_helper
INFO - 2023-09-24 04:08:49 --> Helper loaded: security_helper
INFO - 2023-09-24 04:08:49 --> Helper loaded: cookie_helper
INFO - 2023-09-24 04:08:49 --> Database Driver Class Initialized
INFO - 2023-09-24 04:08:49 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-24 04:08:49 --> Parser Class Initialized
INFO - 2023-09-24 04:08:49 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-24 04:08:49 --> Pagination Class Initialized
INFO - 2023-09-24 04:08:49 --> Form Validation Class Initialized
INFO - 2023-09-24 04:08:49 --> Controller Class Initialized
INFO - 2023-09-24 04:08:49 --> Model Class Initialized
DEBUG - 2023-09-24 04:08:49 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-09-24 04:08:49 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-24 04:08:49 --> Model Class Initialized
DEBUG - 2023-09-24 04:08:49 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-24 04:08:49 --> Model Class Initialized
INFO - 2023-09-24 04:08:49 --> Model Class Initialized
INFO - 2023-09-24 04:08:49 --> Final output sent to browser
DEBUG - 2023-09-24 04:08:49 --> Total execution time: 0.0215
ERROR - 2023-09-24 04:09:15 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-24 04:09:15 --> Config Class Initialized
INFO - 2023-09-24 04:09:15 --> Hooks Class Initialized
DEBUG - 2023-09-24 04:09:15 --> UTF-8 Support Enabled
INFO - 2023-09-24 04:09:15 --> Utf8 Class Initialized
INFO - 2023-09-24 04:09:15 --> URI Class Initialized
INFO - 2023-09-24 04:09:15 --> Router Class Initialized
INFO - 2023-09-24 04:09:15 --> Output Class Initialized
INFO - 2023-09-24 04:09:15 --> Security Class Initialized
DEBUG - 2023-09-24 04:09:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-24 04:09:15 --> Input Class Initialized
INFO - 2023-09-24 04:09:15 --> Language Class Initialized
INFO - 2023-09-24 04:09:15 --> Loader Class Initialized
INFO - 2023-09-24 04:09:15 --> Helper loaded: url_helper
INFO - 2023-09-24 04:09:15 --> Helper loaded: file_helper
INFO - 2023-09-24 04:09:15 --> Helper loaded: html_helper
INFO - 2023-09-24 04:09:15 --> Helper loaded: text_helper
INFO - 2023-09-24 04:09:15 --> Helper loaded: form_helper
INFO - 2023-09-24 04:09:15 --> Helper loaded: lang_helper
INFO - 2023-09-24 04:09:15 --> Helper loaded: security_helper
INFO - 2023-09-24 04:09:15 --> Helper loaded: cookie_helper
INFO - 2023-09-24 04:09:15 --> Database Driver Class Initialized
INFO - 2023-09-24 04:09:15 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-24 04:09:15 --> Parser Class Initialized
INFO - 2023-09-24 04:09:15 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-24 04:09:15 --> Pagination Class Initialized
INFO - 2023-09-24 04:09:15 --> Form Validation Class Initialized
INFO - 2023-09-24 04:09:15 --> Controller Class Initialized
INFO - 2023-09-24 04:09:15 --> Model Class Initialized
DEBUG - 2023-09-24 04:09:15 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-09-24 04:09:15 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-24 04:09:15 --> Model Class Initialized
DEBUG - 2023-09-24 04:09:15 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-24 04:09:15 --> Model Class Initialized
INFO - 2023-09-24 04:09:15 --> Final output sent to browser
DEBUG - 2023-09-24 04:09:15 --> Total execution time: 0.0673
ERROR - 2023-09-24 04:09:16 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-24 04:09:16 --> Config Class Initialized
INFO - 2023-09-24 04:09:16 --> Hooks Class Initialized
DEBUG - 2023-09-24 04:09:16 --> UTF-8 Support Enabled
INFO - 2023-09-24 04:09:16 --> Utf8 Class Initialized
INFO - 2023-09-24 04:09:16 --> URI Class Initialized
INFO - 2023-09-24 04:09:16 --> Router Class Initialized
INFO - 2023-09-24 04:09:16 --> Output Class Initialized
INFO - 2023-09-24 04:09:16 --> Security Class Initialized
DEBUG - 2023-09-24 04:09:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-24 04:09:16 --> Input Class Initialized
INFO - 2023-09-24 04:09:16 --> Language Class Initialized
INFO - 2023-09-24 04:09:16 --> Loader Class Initialized
INFO - 2023-09-24 04:09:16 --> Helper loaded: url_helper
INFO - 2023-09-24 04:09:16 --> Helper loaded: file_helper
INFO - 2023-09-24 04:09:16 --> Helper loaded: html_helper
INFO - 2023-09-24 04:09:16 --> Helper loaded: text_helper
INFO - 2023-09-24 04:09:16 --> Helper loaded: form_helper
INFO - 2023-09-24 04:09:16 --> Helper loaded: lang_helper
INFO - 2023-09-24 04:09:16 --> Helper loaded: security_helper
INFO - 2023-09-24 04:09:16 --> Helper loaded: cookie_helper
INFO - 2023-09-24 04:09:16 --> Database Driver Class Initialized
INFO - 2023-09-24 04:09:16 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-24 04:09:16 --> Parser Class Initialized
INFO - 2023-09-24 04:09:16 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-24 04:09:16 --> Pagination Class Initialized
INFO - 2023-09-24 04:09:16 --> Form Validation Class Initialized
INFO - 2023-09-24 04:09:16 --> Controller Class Initialized
INFO - 2023-09-24 04:09:16 --> Model Class Initialized
DEBUG - 2023-09-24 04:09:16 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-09-24 04:09:16 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-24 04:09:16 --> Model Class Initialized
DEBUG - 2023-09-24 04:09:16 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-24 04:09:16 --> Model Class Initialized
INFO - 2023-09-24 04:09:16 --> Final output sent to browser
DEBUG - 2023-09-24 04:09:16 --> Total execution time: 0.0634
ERROR - 2023-09-24 04:09:16 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-24 04:09:16 --> Config Class Initialized
INFO - 2023-09-24 04:09:16 --> Hooks Class Initialized
DEBUG - 2023-09-24 04:09:16 --> UTF-8 Support Enabled
INFO - 2023-09-24 04:09:16 --> Utf8 Class Initialized
INFO - 2023-09-24 04:09:16 --> URI Class Initialized
INFO - 2023-09-24 04:09:16 --> Router Class Initialized
INFO - 2023-09-24 04:09:16 --> Output Class Initialized
INFO - 2023-09-24 04:09:16 --> Security Class Initialized
DEBUG - 2023-09-24 04:09:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-24 04:09:16 --> Input Class Initialized
INFO - 2023-09-24 04:09:16 --> Language Class Initialized
INFO - 2023-09-24 04:09:16 --> Loader Class Initialized
INFO - 2023-09-24 04:09:16 --> Helper loaded: url_helper
INFO - 2023-09-24 04:09:16 --> Helper loaded: file_helper
INFO - 2023-09-24 04:09:16 --> Helper loaded: html_helper
INFO - 2023-09-24 04:09:16 --> Helper loaded: text_helper
INFO - 2023-09-24 04:09:16 --> Helper loaded: form_helper
INFO - 2023-09-24 04:09:16 --> Helper loaded: lang_helper
INFO - 2023-09-24 04:09:16 --> Helper loaded: security_helper
INFO - 2023-09-24 04:09:16 --> Helper loaded: cookie_helper
INFO - 2023-09-24 04:09:16 --> Database Driver Class Initialized
INFO - 2023-09-24 04:09:16 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-24 04:09:16 --> Parser Class Initialized
INFO - 2023-09-24 04:09:16 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-24 04:09:16 --> Pagination Class Initialized
INFO - 2023-09-24 04:09:16 --> Form Validation Class Initialized
INFO - 2023-09-24 04:09:16 --> Controller Class Initialized
INFO - 2023-09-24 04:09:16 --> Model Class Initialized
DEBUG - 2023-09-24 04:09:16 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-09-24 04:09:16 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-24 04:09:16 --> Model Class Initialized
DEBUG - 2023-09-24 04:09:16 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-24 04:09:16 --> Model Class Initialized
INFO - 2023-09-24 04:09:17 --> Final output sent to browser
DEBUG - 2023-09-24 04:09:17 --> Total execution time: 0.0623
ERROR - 2023-09-24 04:09:17 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-24 04:09:17 --> Config Class Initialized
INFO - 2023-09-24 04:09:17 --> Hooks Class Initialized
DEBUG - 2023-09-24 04:09:17 --> UTF-8 Support Enabled
INFO - 2023-09-24 04:09:17 --> Utf8 Class Initialized
INFO - 2023-09-24 04:09:17 --> URI Class Initialized
INFO - 2023-09-24 04:09:17 --> Router Class Initialized
INFO - 2023-09-24 04:09:17 --> Output Class Initialized
INFO - 2023-09-24 04:09:17 --> Security Class Initialized
DEBUG - 2023-09-24 04:09:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-24 04:09:17 --> Input Class Initialized
INFO - 2023-09-24 04:09:17 --> Language Class Initialized
INFO - 2023-09-24 04:09:17 --> Loader Class Initialized
INFO - 2023-09-24 04:09:17 --> Helper loaded: url_helper
INFO - 2023-09-24 04:09:17 --> Helper loaded: file_helper
INFO - 2023-09-24 04:09:17 --> Helper loaded: html_helper
INFO - 2023-09-24 04:09:17 --> Helper loaded: text_helper
INFO - 2023-09-24 04:09:17 --> Helper loaded: form_helper
INFO - 2023-09-24 04:09:17 --> Helper loaded: lang_helper
INFO - 2023-09-24 04:09:17 --> Helper loaded: security_helper
INFO - 2023-09-24 04:09:17 --> Helper loaded: cookie_helper
INFO - 2023-09-24 04:09:17 --> Database Driver Class Initialized
INFO - 2023-09-24 04:09:17 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-24 04:09:17 --> Parser Class Initialized
INFO - 2023-09-24 04:09:17 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-24 04:09:17 --> Pagination Class Initialized
INFO - 2023-09-24 04:09:17 --> Form Validation Class Initialized
INFO - 2023-09-24 04:09:17 --> Controller Class Initialized
INFO - 2023-09-24 04:09:17 --> Model Class Initialized
DEBUG - 2023-09-24 04:09:17 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-09-24 04:09:17 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-24 04:09:17 --> Model Class Initialized
DEBUG - 2023-09-24 04:09:17 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-24 04:09:17 --> Model Class Initialized
INFO - 2023-09-24 04:09:17 --> Final output sent to browser
DEBUG - 2023-09-24 04:09:17 --> Total execution time: 0.0207
ERROR - 2023-09-24 04:09:19 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-24 04:09:19 --> Config Class Initialized
INFO - 2023-09-24 04:09:19 --> Hooks Class Initialized
DEBUG - 2023-09-24 04:09:19 --> UTF-8 Support Enabled
INFO - 2023-09-24 04:09:19 --> Utf8 Class Initialized
INFO - 2023-09-24 04:09:19 --> URI Class Initialized
INFO - 2023-09-24 04:09:19 --> Router Class Initialized
INFO - 2023-09-24 04:09:19 --> Output Class Initialized
INFO - 2023-09-24 04:09:19 --> Security Class Initialized
DEBUG - 2023-09-24 04:09:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-24 04:09:19 --> Input Class Initialized
INFO - 2023-09-24 04:09:19 --> Language Class Initialized
INFO - 2023-09-24 04:09:19 --> Loader Class Initialized
INFO - 2023-09-24 04:09:19 --> Helper loaded: url_helper
INFO - 2023-09-24 04:09:19 --> Helper loaded: file_helper
INFO - 2023-09-24 04:09:19 --> Helper loaded: html_helper
INFO - 2023-09-24 04:09:19 --> Helper loaded: text_helper
INFO - 2023-09-24 04:09:19 --> Helper loaded: form_helper
INFO - 2023-09-24 04:09:19 --> Helper loaded: lang_helper
INFO - 2023-09-24 04:09:19 --> Helper loaded: security_helper
INFO - 2023-09-24 04:09:19 --> Helper loaded: cookie_helper
INFO - 2023-09-24 04:09:19 --> Database Driver Class Initialized
INFO - 2023-09-24 04:09:19 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-24 04:09:19 --> Parser Class Initialized
INFO - 2023-09-24 04:09:19 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-24 04:09:19 --> Pagination Class Initialized
INFO - 2023-09-24 04:09:19 --> Form Validation Class Initialized
INFO - 2023-09-24 04:09:19 --> Controller Class Initialized
INFO - 2023-09-24 04:09:19 --> Model Class Initialized
DEBUG - 2023-09-24 04:09:19 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-09-24 04:09:19 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-24 04:09:19 --> Model Class Initialized
DEBUG - 2023-09-24 04:09:19 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-24 04:09:19 --> Model Class Initialized
INFO - 2023-09-24 04:09:19 --> Model Class Initialized
INFO - 2023-09-24 04:09:19 --> Final output sent to browser
DEBUG - 2023-09-24 04:09:19 --> Total execution time: 0.0219
ERROR - 2023-09-24 04:09:22 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-24 04:09:22 --> Config Class Initialized
INFO - 2023-09-24 04:09:22 --> Hooks Class Initialized
DEBUG - 2023-09-24 04:09:22 --> UTF-8 Support Enabled
INFO - 2023-09-24 04:09:22 --> Utf8 Class Initialized
INFO - 2023-09-24 04:09:22 --> URI Class Initialized
INFO - 2023-09-24 04:09:22 --> Router Class Initialized
INFO - 2023-09-24 04:09:22 --> Output Class Initialized
INFO - 2023-09-24 04:09:22 --> Security Class Initialized
DEBUG - 2023-09-24 04:09:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-24 04:09:22 --> Input Class Initialized
INFO - 2023-09-24 04:09:22 --> Language Class Initialized
INFO - 2023-09-24 04:09:22 --> Loader Class Initialized
INFO - 2023-09-24 04:09:22 --> Helper loaded: url_helper
INFO - 2023-09-24 04:09:22 --> Helper loaded: file_helper
INFO - 2023-09-24 04:09:22 --> Helper loaded: html_helper
INFO - 2023-09-24 04:09:22 --> Helper loaded: text_helper
INFO - 2023-09-24 04:09:22 --> Helper loaded: form_helper
INFO - 2023-09-24 04:09:22 --> Helper loaded: lang_helper
INFO - 2023-09-24 04:09:22 --> Helper loaded: security_helper
INFO - 2023-09-24 04:09:22 --> Helper loaded: cookie_helper
INFO - 2023-09-24 04:09:22 --> Database Driver Class Initialized
INFO - 2023-09-24 04:09:22 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-24 04:09:22 --> Parser Class Initialized
INFO - 2023-09-24 04:09:22 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-24 04:09:22 --> Pagination Class Initialized
INFO - 2023-09-24 04:09:22 --> Form Validation Class Initialized
INFO - 2023-09-24 04:09:22 --> Controller Class Initialized
INFO - 2023-09-24 04:09:22 --> Model Class Initialized
DEBUG - 2023-09-24 04:09:22 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-09-24 04:09:22 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-24 04:09:22 --> Model Class Initialized
DEBUG - 2023-09-24 04:09:22 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-24 04:09:22 --> Model Class Initialized
INFO - 2023-09-24 04:09:22 --> Final output sent to browser
DEBUG - 2023-09-24 04:09:22 --> Total execution time: 0.0212
ERROR - 2023-09-24 04:09:22 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-24 04:09:22 --> Config Class Initialized
INFO - 2023-09-24 04:09:22 --> Hooks Class Initialized
DEBUG - 2023-09-24 04:09:22 --> UTF-8 Support Enabled
INFO - 2023-09-24 04:09:22 --> Utf8 Class Initialized
INFO - 2023-09-24 04:09:22 --> URI Class Initialized
INFO - 2023-09-24 04:09:22 --> Router Class Initialized
INFO - 2023-09-24 04:09:22 --> Output Class Initialized
INFO - 2023-09-24 04:09:22 --> Security Class Initialized
DEBUG - 2023-09-24 04:09:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-24 04:09:22 --> Input Class Initialized
INFO - 2023-09-24 04:09:22 --> Language Class Initialized
INFO - 2023-09-24 04:09:22 --> Loader Class Initialized
INFO - 2023-09-24 04:09:22 --> Helper loaded: url_helper
INFO - 2023-09-24 04:09:22 --> Helper loaded: file_helper
INFO - 2023-09-24 04:09:22 --> Helper loaded: html_helper
INFO - 2023-09-24 04:09:22 --> Helper loaded: text_helper
INFO - 2023-09-24 04:09:22 --> Helper loaded: form_helper
INFO - 2023-09-24 04:09:22 --> Helper loaded: lang_helper
INFO - 2023-09-24 04:09:22 --> Helper loaded: security_helper
INFO - 2023-09-24 04:09:22 --> Helper loaded: cookie_helper
INFO - 2023-09-24 04:09:22 --> Database Driver Class Initialized
INFO - 2023-09-24 04:09:22 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-24 04:09:22 --> Parser Class Initialized
INFO - 2023-09-24 04:09:22 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-24 04:09:22 --> Pagination Class Initialized
INFO - 2023-09-24 04:09:22 --> Form Validation Class Initialized
INFO - 2023-09-24 04:09:22 --> Controller Class Initialized
INFO - 2023-09-24 04:09:22 --> Model Class Initialized
DEBUG - 2023-09-24 04:09:22 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-09-24 04:09:22 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-24 04:09:22 --> Model Class Initialized
DEBUG - 2023-09-24 04:09:22 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-24 04:09:22 --> Model Class Initialized
INFO - 2023-09-24 04:09:22 --> Final output sent to browser
DEBUG - 2023-09-24 04:09:22 --> Total execution time: 0.0218
ERROR - 2023-09-24 04:09:24 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-24 04:09:24 --> Config Class Initialized
INFO - 2023-09-24 04:09:24 --> Hooks Class Initialized
DEBUG - 2023-09-24 04:09:24 --> UTF-8 Support Enabled
INFO - 2023-09-24 04:09:24 --> Utf8 Class Initialized
INFO - 2023-09-24 04:09:24 --> URI Class Initialized
INFO - 2023-09-24 04:09:24 --> Router Class Initialized
INFO - 2023-09-24 04:09:24 --> Output Class Initialized
INFO - 2023-09-24 04:09:24 --> Security Class Initialized
DEBUG - 2023-09-24 04:09:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-24 04:09:24 --> Input Class Initialized
INFO - 2023-09-24 04:09:24 --> Language Class Initialized
INFO - 2023-09-24 04:09:24 --> Loader Class Initialized
INFO - 2023-09-24 04:09:24 --> Helper loaded: url_helper
INFO - 2023-09-24 04:09:24 --> Helper loaded: file_helper
INFO - 2023-09-24 04:09:24 --> Helper loaded: html_helper
INFO - 2023-09-24 04:09:24 --> Helper loaded: text_helper
INFO - 2023-09-24 04:09:24 --> Helper loaded: form_helper
INFO - 2023-09-24 04:09:24 --> Helper loaded: lang_helper
INFO - 2023-09-24 04:09:24 --> Helper loaded: security_helper
INFO - 2023-09-24 04:09:24 --> Helper loaded: cookie_helper
INFO - 2023-09-24 04:09:24 --> Database Driver Class Initialized
INFO - 2023-09-24 04:09:24 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-24 04:09:24 --> Parser Class Initialized
INFO - 2023-09-24 04:09:24 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-24 04:09:24 --> Pagination Class Initialized
INFO - 2023-09-24 04:09:24 --> Form Validation Class Initialized
INFO - 2023-09-24 04:09:24 --> Controller Class Initialized
INFO - 2023-09-24 04:09:24 --> Model Class Initialized
DEBUG - 2023-09-24 04:09:24 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-09-24 04:09:24 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-24 04:09:24 --> Model Class Initialized
DEBUG - 2023-09-24 04:09:24 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-24 04:09:24 --> Model Class Initialized
INFO - 2023-09-24 04:09:24 --> Final output sent to browser
DEBUG - 2023-09-24 04:09:24 --> Total execution time: 0.0209
ERROR - 2023-09-24 04:09:31 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-24 04:09:31 --> Config Class Initialized
INFO - 2023-09-24 04:09:31 --> Hooks Class Initialized
DEBUG - 2023-09-24 04:09:31 --> UTF-8 Support Enabled
INFO - 2023-09-24 04:09:31 --> Utf8 Class Initialized
INFO - 2023-09-24 04:09:31 --> URI Class Initialized
INFO - 2023-09-24 04:09:31 --> Router Class Initialized
INFO - 2023-09-24 04:09:31 --> Output Class Initialized
INFO - 2023-09-24 04:09:31 --> Security Class Initialized
DEBUG - 2023-09-24 04:09:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-24 04:09:31 --> Input Class Initialized
INFO - 2023-09-24 04:09:31 --> Language Class Initialized
INFO - 2023-09-24 04:09:31 --> Loader Class Initialized
INFO - 2023-09-24 04:09:31 --> Helper loaded: url_helper
INFO - 2023-09-24 04:09:31 --> Helper loaded: file_helper
INFO - 2023-09-24 04:09:31 --> Helper loaded: html_helper
INFO - 2023-09-24 04:09:31 --> Helper loaded: text_helper
INFO - 2023-09-24 04:09:31 --> Helper loaded: form_helper
INFO - 2023-09-24 04:09:31 --> Helper loaded: lang_helper
INFO - 2023-09-24 04:09:31 --> Helper loaded: security_helper
INFO - 2023-09-24 04:09:31 --> Helper loaded: cookie_helper
INFO - 2023-09-24 04:09:31 --> Database Driver Class Initialized
INFO - 2023-09-24 04:09:31 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-24 04:09:31 --> Parser Class Initialized
INFO - 2023-09-24 04:09:31 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-24 04:09:31 --> Pagination Class Initialized
INFO - 2023-09-24 04:09:31 --> Form Validation Class Initialized
INFO - 2023-09-24 04:09:31 --> Controller Class Initialized
INFO - 2023-09-24 04:09:31 --> Model Class Initialized
DEBUG - 2023-09-24 04:09:31 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-09-24 04:09:31 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-24 04:09:31 --> Model Class Initialized
DEBUG - 2023-09-24 04:09:31 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-24 04:09:31 --> Model Class Initialized
INFO - 2023-09-24 04:09:31 --> Final output sent to browser
DEBUG - 2023-09-24 04:09:31 --> Total execution time: 0.0180
ERROR - 2023-09-24 04:09:33 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-24 04:09:33 --> Config Class Initialized
INFO - 2023-09-24 04:09:33 --> Hooks Class Initialized
DEBUG - 2023-09-24 04:09:33 --> UTF-8 Support Enabled
INFO - 2023-09-24 04:09:33 --> Utf8 Class Initialized
INFO - 2023-09-24 04:09:33 --> URI Class Initialized
INFO - 2023-09-24 04:09:33 --> Router Class Initialized
INFO - 2023-09-24 04:09:33 --> Output Class Initialized
INFO - 2023-09-24 04:09:33 --> Security Class Initialized
DEBUG - 2023-09-24 04:09:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-24 04:09:33 --> Input Class Initialized
INFO - 2023-09-24 04:09:33 --> Language Class Initialized
INFO - 2023-09-24 04:09:33 --> Loader Class Initialized
INFO - 2023-09-24 04:09:33 --> Helper loaded: url_helper
INFO - 2023-09-24 04:09:33 --> Helper loaded: file_helper
INFO - 2023-09-24 04:09:33 --> Helper loaded: html_helper
INFO - 2023-09-24 04:09:33 --> Helper loaded: text_helper
INFO - 2023-09-24 04:09:33 --> Helper loaded: form_helper
INFO - 2023-09-24 04:09:33 --> Helper loaded: lang_helper
INFO - 2023-09-24 04:09:33 --> Helper loaded: security_helper
INFO - 2023-09-24 04:09:33 --> Helper loaded: cookie_helper
INFO - 2023-09-24 04:09:33 --> Database Driver Class Initialized
INFO - 2023-09-24 04:09:33 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-24 04:09:33 --> Parser Class Initialized
INFO - 2023-09-24 04:09:33 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-24 04:09:33 --> Pagination Class Initialized
INFO - 2023-09-24 04:09:33 --> Form Validation Class Initialized
INFO - 2023-09-24 04:09:33 --> Controller Class Initialized
INFO - 2023-09-24 04:09:33 --> Model Class Initialized
DEBUG - 2023-09-24 04:09:33 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-09-24 04:09:33 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-24 04:09:33 --> Model Class Initialized
DEBUG - 2023-09-24 04:09:33 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-24 04:09:33 --> Model Class Initialized
INFO - 2023-09-24 04:09:33 --> Final output sent to browser
DEBUG - 2023-09-24 04:09:33 --> Total execution time: 0.0217
ERROR - 2023-09-24 04:09:34 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-24 04:09:34 --> Config Class Initialized
INFO - 2023-09-24 04:09:34 --> Hooks Class Initialized
DEBUG - 2023-09-24 04:09:34 --> UTF-8 Support Enabled
INFO - 2023-09-24 04:09:34 --> Utf8 Class Initialized
INFO - 2023-09-24 04:09:34 --> URI Class Initialized
INFO - 2023-09-24 04:09:34 --> Router Class Initialized
INFO - 2023-09-24 04:09:34 --> Output Class Initialized
INFO - 2023-09-24 04:09:34 --> Security Class Initialized
DEBUG - 2023-09-24 04:09:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-24 04:09:34 --> Input Class Initialized
INFO - 2023-09-24 04:09:34 --> Language Class Initialized
INFO - 2023-09-24 04:09:34 --> Loader Class Initialized
INFO - 2023-09-24 04:09:34 --> Helper loaded: url_helper
INFO - 2023-09-24 04:09:34 --> Helper loaded: file_helper
INFO - 2023-09-24 04:09:34 --> Helper loaded: html_helper
INFO - 2023-09-24 04:09:34 --> Helper loaded: text_helper
INFO - 2023-09-24 04:09:34 --> Helper loaded: form_helper
INFO - 2023-09-24 04:09:34 --> Helper loaded: lang_helper
INFO - 2023-09-24 04:09:34 --> Helper loaded: security_helper
INFO - 2023-09-24 04:09:34 --> Helper loaded: cookie_helper
INFO - 2023-09-24 04:09:34 --> Database Driver Class Initialized
INFO - 2023-09-24 04:09:34 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-24 04:09:34 --> Parser Class Initialized
INFO - 2023-09-24 04:09:34 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-24 04:09:34 --> Pagination Class Initialized
INFO - 2023-09-24 04:09:34 --> Form Validation Class Initialized
INFO - 2023-09-24 04:09:34 --> Controller Class Initialized
INFO - 2023-09-24 04:09:34 --> Model Class Initialized
DEBUG - 2023-09-24 04:09:34 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-09-24 04:09:34 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-24 04:09:34 --> Model Class Initialized
DEBUG - 2023-09-24 04:09:34 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-24 04:09:34 --> Model Class Initialized
INFO - 2023-09-24 04:09:34 --> Final output sent to browser
DEBUG - 2023-09-24 04:09:34 --> Total execution time: 0.0183
ERROR - 2023-09-24 04:09:34 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-24 04:09:34 --> Config Class Initialized
INFO - 2023-09-24 04:09:34 --> Hooks Class Initialized
DEBUG - 2023-09-24 04:09:34 --> UTF-8 Support Enabled
INFO - 2023-09-24 04:09:34 --> Utf8 Class Initialized
INFO - 2023-09-24 04:09:34 --> URI Class Initialized
INFO - 2023-09-24 04:09:34 --> Router Class Initialized
INFO - 2023-09-24 04:09:34 --> Output Class Initialized
INFO - 2023-09-24 04:09:34 --> Security Class Initialized
DEBUG - 2023-09-24 04:09:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-24 04:09:34 --> Input Class Initialized
INFO - 2023-09-24 04:09:34 --> Language Class Initialized
INFO - 2023-09-24 04:09:34 --> Loader Class Initialized
INFO - 2023-09-24 04:09:34 --> Helper loaded: url_helper
INFO - 2023-09-24 04:09:34 --> Helper loaded: file_helper
INFO - 2023-09-24 04:09:34 --> Helper loaded: html_helper
INFO - 2023-09-24 04:09:34 --> Helper loaded: text_helper
INFO - 2023-09-24 04:09:34 --> Helper loaded: form_helper
INFO - 2023-09-24 04:09:34 --> Helper loaded: lang_helper
INFO - 2023-09-24 04:09:34 --> Helper loaded: security_helper
INFO - 2023-09-24 04:09:34 --> Helper loaded: cookie_helper
INFO - 2023-09-24 04:09:34 --> Database Driver Class Initialized
INFO - 2023-09-24 04:09:34 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-24 04:09:34 --> Parser Class Initialized
INFO - 2023-09-24 04:09:34 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-24 04:09:34 --> Pagination Class Initialized
INFO - 2023-09-24 04:09:34 --> Form Validation Class Initialized
INFO - 2023-09-24 04:09:34 --> Controller Class Initialized
INFO - 2023-09-24 04:09:34 --> Model Class Initialized
DEBUG - 2023-09-24 04:09:34 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-09-24 04:09:34 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-24 04:09:34 --> Model Class Initialized
DEBUG - 2023-09-24 04:09:34 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-24 04:09:34 --> Model Class Initialized
INFO - 2023-09-24 04:09:34 --> Final output sent to browser
DEBUG - 2023-09-24 04:09:34 --> Total execution time: 0.0183
ERROR - 2023-09-24 04:09:36 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-24 04:09:36 --> Config Class Initialized
INFO - 2023-09-24 04:09:36 --> Hooks Class Initialized
DEBUG - 2023-09-24 04:09:36 --> UTF-8 Support Enabled
INFO - 2023-09-24 04:09:36 --> Utf8 Class Initialized
INFO - 2023-09-24 04:09:36 --> URI Class Initialized
INFO - 2023-09-24 04:09:36 --> Router Class Initialized
INFO - 2023-09-24 04:09:36 --> Output Class Initialized
INFO - 2023-09-24 04:09:36 --> Security Class Initialized
DEBUG - 2023-09-24 04:09:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-24 04:09:36 --> Input Class Initialized
INFO - 2023-09-24 04:09:36 --> Language Class Initialized
INFO - 2023-09-24 04:09:36 --> Loader Class Initialized
INFO - 2023-09-24 04:09:36 --> Helper loaded: url_helper
INFO - 2023-09-24 04:09:36 --> Helper loaded: file_helper
INFO - 2023-09-24 04:09:36 --> Helper loaded: html_helper
INFO - 2023-09-24 04:09:36 --> Helper loaded: text_helper
INFO - 2023-09-24 04:09:36 --> Helper loaded: form_helper
INFO - 2023-09-24 04:09:36 --> Helper loaded: lang_helper
INFO - 2023-09-24 04:09:36 --> Helper loaded: security_helper
INFO - 2023-09-24 04:09:36 --> Helper loaded: cookie_helper
INFO - 2023-09-24 04:09:36 --> Database Driver Class Initialized
INFO - 2023-09-24 04:09:36 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-24 04:09:36 --> Parser Class Initialized
INFO - 2023-09-24 04:09:36 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-24 04:09:36 --> Pagination Class Initialized
INFO - 2023-09-24 04:09:36 --> Form Validation Class Initialized
INFO - 2023-09-24 04:09:36 --> Controller Class Initialized
INFO - 2023-09-24 04:09:36 --> Model Class Initialized
DEBUG - 2023-09-24 04:09:36 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-09-24 04:09:36 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-24 04:09:36 --> Model Class Initialized
DEBUG - 2023-09-24 04:09:36 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-24 04:09:36 --> Model Class Initialized
INFO - 2023-09-24 04:09:36 --> Final output sent to browser
DEBUG - 2023-09-24 04:09:36 --> Total execution time: 0.0205
ERROR - 2023-09-24 04:09:37 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-24 04:09:37 --> Config Class Initialized
INFO - 2023-09-24 04:09:37 --> Hooks Class Initialized
DEBUG - 2023-09-24 04:09:37 --> UTF-8 Support Enabled
INFO - 2023-09-24 04:09:37 --> Utf8 Class Initialized
INFO - 2023-09-24 04:09:37 --> URI Class Initialized
INFO - 2023-09-24 04:09:37 --> Router Class Initialized
INFO - 2023-09-24 04:09:37 --> Output Class Initialized
INFO - 2023-09-24 04:09:37 --> Security Class Initialized
DEBUG - 2023-09-24 04:09:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-24 04:09:37 --> Input Class Initialized
INFO - 2023-09-24 04:09:37 --> Language Class Initialized
INFO - 2023-09-24 04:09:37 --> Loader Class Initialized
INFO - 2023-09-24 04:09:37 --> Helper loaded: url_helper
INFO - 2023-09-24 04:09:37 --> Helper loaded: file_helper
INFO - 2023-09-24 04:09:37 --> Helper loaded: html_helper
INFO - 2023-09-24 04:09:37 --> Helper loaded: text_helper
INFO - 2023-09-24 04:09:37 --> Helper loaded: form_helper
INFO - 2023-09-24 04:09:37 --> Helper loaded: lang_helper
INFO - 2023-09-24 04:09:37 --> Helper loaded: security_helper
INFO - 2023-09-24 04:09:37 --> Helper loaded: cookie_helper
INFO - 2023-09-24 04:09:37 --> Database Driver Class Initialized
INFO - 2023-09-24 04:09:37 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-24 04:09:37 --> Parser Class Initialized
INFO - 2023-09-24 04:09:37 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-24 04:09:37 --> Pagination Class Initialized
INFO - 2023-09-24 04:09:37 --> Form Validation Class Initialized
INFO - 2023-09-24 04:09:37 --> Controller Class Initialized
INFO - 2023-09-24 04:09:37 --> Model Class Initialized
DEBUG - 2023-09-24 04:09:37 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-09-24 04:09:37 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-24 04:09:37 --> Model Class Initialized
DEBUG - 2023-09-24 04:09:37 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-24 04:09:37 --> Model Class Initialized
INFO - 2023-09-24 04:09:37 --> Final output sent to browser
DEBUG - 2023-09-24 04:09:37 --> Total execution time: 0.0184
ERROR - 2023-09-24 04:09:40 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-24 04:09:40 --> Config Class Initialized
INFO - 2023-09-24 04:09:40 --> Hooks Class Initialized
DEBUG - 2023-09-24 04:09:40 --> UTF-8 Support Enabled
INFO - 2023-09-24 04:09:40 --> Utf8 Class Initialized
INFO - 2023-09-24 04:09:40 --> URI Class Initialized
INFO - 2023-09-24 04:09:40 --> Router Class Initialized
INFO - 2023-09-24 04:09:40 --> Output Class Initialized
INFO - 2023-09-24 04:09:40 --> Security Class Initialized
DEBUG - 2023-09-24 04:09:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-24 04:09:40 --> Input Class Initialized
INFO - 2023-09-24 04:09:40 --> Language Class Initialized
INFO - 2023-09-24 04:09:40 --> Loader Class Initialized
INFO - 2023-09-24 04:09:40 --> Helper loaded: url_helper
INFO - 2023-09-24 04:09:40 --> Helper loaded: file_helper
INFO - 2023-09-24 04:09:40 --> Helper loaded: html_helper
INFO - 2023-09-24 04:09:40 --> Helper loaded: text_helper
INFO - 2023-09-24 04:09:40 --> Helper loaded: form_helper
INFO - 2023-09-24 04:09:40 --> Helper loaded: lang_helper
INFO - 2023-09-24 04:09:40 --> Helper loaded: security_helper
INFO - 2023-09-24 04:09:40 --> Helper loaded: cookie_helper
INFO - 2023-09-24 04:09:40 --> Database Driver Class Initialized
INFO - 2023-09-24 04:09:40 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-24 04:09:40 --> Parser Class Initialized
INFO - 2023-09-24 04:09:40 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-24 04:09:40 --> Pagination Class Initialized
INFO - 2023-09-24 04:09:40 --> Form Validation Class Initialized
INFO - 2023-09-24 04:09:40 --> Controller Class Initialized
INFO - 2023-09-24 04:09:40 --> Model Class Initialized
DEBUG - 2023-09-24 04:09:40 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-09-24 04:09:40 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-24 04:09:40 --> Model Class Initialized
DEBUG - 2023-09-24 04:09:40 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-24 04:09:40 --> Model Class Initialized
INFO - 2023-09-24 04:09:40 --> Final output sent to browser
DEBUG - 2023-09-24 04:09:40 --> Total execution time: 0.0649
ERROR - 2023-09-24 04:09:47 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-24 04:09:47 --> Config Class Initialized
INFO - 2023-09-24 04:09:47 --> Hooks Class Initialized
DEBUG - 2023-09-24 04:09:47 --> UTF-8 Support Enabled
INFO - 2023-09-24 04:09:47 --> Utf8 Class Initialized
INFO - 2023-09-24 04:09:47 --> URI Class Initialized
INFO - 2023-09-24 04:09:47 --> Router Class Initialized
INFO - 2023-09-24 04:09:47 --> Output Class Initialized
INFO - 2023-09-24 04:09:47 --> Security Class Initialized
DEBUG - 2023-09-24 04:09:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-24 04:09:47 --> Input Class Initialized
INFO - 2023-09-24 04:09:47 --> Language Class Initialized
INFO - 2023-09-24 04:09:47 --> Loader Class Initialized
INFO - 2023-09-24 04:09:47 --> Helper loaded: url_helper
INFO - 2023-09-24 04:09:47 --> Helper loaded: file_helper
INFO - 2023-09-24 04:09:47 --> Helper loaded: html_helper
INFO - 2023-09-24 04:09:47 --> Helper loaded: text_helper
INFO - 2023-09-24 04:09:47 --> Helper loaded: form_helper
INFO - 2023-09-24 04:09:47 --> Helper loaded: lang_helper
INFO - 2023-09-24 04:09:47 --> Helper loaded: security_helper
INFO - 2023-09-24 04:09:47 --> Helper loaded: cookie_helper
INFO - 2023-09-24 04:09:47 --> Database Driver Class Initialized
INFO - 2023-09-24 04:09:47 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-24 04:09:47 --> Parser Class Initialized
INFO - 2023-09-24 04:09:47 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-24 04:09:47 --> Pagination Class Initialized
INFO - 2023-09-24 04:09:47 --> Form Validation Class Initialized
INFO - 2023-09-24 04:09:47 --> Controller Class Initialized
INFO - 2023-09-24 04:09:47 --> Model Class Initialized
DEBUG - 2023-09-24 04:09:47 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-09-24 04:09:47 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-24 04:09:47 --> Model Class Initialized
DEBUG - 2023-09-24 04:09:47 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-24 04:09:47 --> Model Class Initialized
INFO - 2023-09-24 04:09:47 --> Final output sent to browser
DEBUG - 2023-09-24 04:09:47 --> Total execution time: 0.0262
ERROR - 2023-09-24 04:09:49 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-24 04:09:49 --> Config Class Initialized
INFO - 2023-09-24 04:09:49 --> Hooks Class Initialized
DEBUG - 2023-09-24 04:09:49 --> UTF-8 Support Enabled
INFO - 2023-09-24 04:09:49 --> Utf8 Class Initialized
INFO - 2023-09-24 04:09:49 --> URI Class Initialized
INFO - 2023-09-24 04:09:49 --> Router Class Initialized
INFO - 2023-09-24 04:09:49 --> Output Class Initialized
INFO - 2023-09-24 04:09:49 --> Security Class Initialized
DEBUG - 2023-09-24 04:09:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-24 04:09:49 --> Input Class Initialized
INFO - 2023-09-24 04:09:49 --> Language Class Initialized
INFO - 2023-09-24 04:09:49 --> Loader Class Initialized
INFO - 2023-09-24 04:09:49 --> Helper loaded: url_helper
INFO - 2023-09-24 04:09:49 --> Helper loaded: file_helper
INFO - 2023-09-24 04:09:49 --> Helper loaded: html_helper
INFO - 2023-09-24 04:09:49 --> Helper loaded: text_helper
INFO - 2023-09-24 04:09:49 --> Helper loaded: form_helper
INFO - 2023-09-24 04:09:49 --> Helper loaded: lang_helper
INFO - 2023-09-24 04:09:49 --> Helper loaded: security_helper
INFO - 2023-09-24 04:09:49 --> Helper loaded: cookie_helper
INFO - 2023-09-24 04:09:49 --> Database Driver Class Initialized
INFO - 2023-09-24 04:09:49 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-24 04:09:49 --> Parser Class Initialized
INFO - 2023-09-24 04:09:49 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-24 04:09:49 --> Pagination Class Initialized
INFO - 2023-09-24 04:09:49 --> Form Validation Class Initialized
INFO - 2023-09-24 04:09:49 --> Controller Class Initialized
INFO - 2023-09-24 04:09:49 --> Model Class Initialized
DEBUG - 2023-09-24 04:09:49 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-09-24 04:09:49 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-24 04:09:49 --> Model Class Initialized
DEBUG - 2023-09-24 04:09:49 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-24 04:09:49 --> Model Class Initialized
INFO - 2023-09-24 04:09:49 --> Model Class Initialized
INFO - 2023-09-24 04:09:49 --> Final output sent to browser
DEBUG - 2023-09-24 04:09:49 --> Total execution time: 0.0220
ERROR - 2023-09-24 04:09:54 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-24 04:09:54 --> Config Class Initialized
INFO - 2023-09-24 04:09:54 --> Hooks Class Initialized
DEBUG - 2023-09-24 04:09:54 --> UTF-8 Support Enabled
INFO - 2023-09-24 04:09:54 --> Utf8 Class Initialized
INFO - 2023-09-24 04:09:54 --> URI Class Initialized
INFO - 2023-09-24 04:09:54 --> Router Class Initialized
INFO - 2023-09-24 04:09:54 --> Output Class Initialized
INFO - 2023-09-24 04:09:54 --> Security Class Initialized
DEBUG - 2023-09-24 04:09:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-24 04:09:54 --> Input Class Initialized
INFO - 2023-09-24 04:09:54 --> Language Class Initialized
INFO - 2023-09-24 04:09:54 --> Loader Class Initialized
INFO - 2023-09-24 04:09:54 --> Helper loaded: url_helper
INFO - 2023-09-24 04:09:54 --> Helper loaded: file_helper
INFO - 2023-09-24 04:09:54 --> Helper loaded: html_helper
INFO - 2023-09-24 04:09:54 --> Helper loaded: text_helper
INFO - 2023-09-24 04:09:54 --> Helper loaded: form_helper
INFO - 2023-09-24 04:09:54 --> Helper loaded: lang_helper
INFO - 2023-09-24 04:09:54 --> Helper loaded: security_helper
INFO - 2023-09-24 04:09:54 --> Helper loaded: cookie_helper
INFO - 2023-09-24 04:09:54 --> Database Driver Class Initialized
INFO - 2023-09-24 04:09:54 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-24 04:09:54 --> Parser Class Initialized
INFO - 2023-09-24 04:09:54 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-24 04:09:54 --> Pagination Class Initialized
INFO - 2023-09-24 04:09:54 --> Form Validation Class Initialized
INFO - 2023-09-24 04:09:54 --> Controller Class Initialized
INFO - 2023-09-24 04:09:54 --> Model Class Initialized
DEBUG - 2023-09-24 04:09:54 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-09-24 04:09:54 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-24 04:09:54 --> Model Class Initialized
DEBUG - 2023-09-24 04:09:54 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-24 04:09:54 --> Model Class Initialized
INFO - 2023-09-24 04:09:54 --> Final output sent to browser
DEBUG - 2023-09-24 04:09:54 --> Total execution time: 0.0646
ERROR - 2023-09-24 04:09:55 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-24 04:09:55 --> Config Class Initialized
INFO - 2023-09-24 04:09:55 --> Hooks Class Initialized
DEBUG - 2023-09-24 04:09:55 --> UTF-8 Support Enabled
INFO - 2023-09-24 04:09:55 --> Utf8 Class Initialized
INFO - 2023-09-24 04:09:55 --> URI Class Initialized
INFO - 2023-09-24 04:09:55 --> Router Class Initialized
INFO - 2023-09-24 04:09:55 --> Output Class Initialized
INFO - 2023-09-24 04:09:55 --> Security Class Initialized
DEBUG - 2023-09-24 04:09:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-24 04:09:55 --> Input Class Initialized
INFO - 2023-09-24 04:09:55 --> Language Class Initialized
INFO - 2023-09-24 04:09:55 --> Loader Class Initialized
INFO - 2023-09-24 04:09:55 --> Helper loaded: url_helper
INFO - 2023-09-24 04:09:55 --> Helper loaded: file_helper
INFO - 2023-09-24 04:09:55 --> Helper loaded: html_helper
INFO - 2023-09-24 04:09:55 --> Helper loaded: text_helper
INFO - 2023-09-24 04:09:55 --> Helper loaded: form_helper
INFO - 2023-09-24 04:09:55 --> Helper loaded: lang_helper
INFO - 2023-09-24 04:09:55 --> Helper loaded: security_helper
INFO - 2023-09-24 04:09:55 --> Helper loaded: cookie_helper
INFO - 2023-09-24 04:09:55 --> Database Driver Class Initialized
INFO - 2023-09-24 04:09:55 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-24 04:09:55 --> Parser Class Initialized
INFO - 2023-09-24 04:09:55 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-24 04:09:55 --> Pagination Class Initialized
INFO - 2023-09-24 04:09:55 --> Form Validation Class Initialized
INFO - 2023-09-24 04:09:55 --> Controller Class Initialized
INFO - 2023-09-24 04:09:55 --> Model Class Initialized
DEBUG - 2023-09-24 04:09:55 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-09-24 04:09:55 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-24 04:09:55 --> Model Class Initialized
DEBUG - 2023-09-24 04:09:55 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-24 04:09:55 --> Model Class Initialized
INFO - 2023-09-24 04:09:55 --> Final output sent to browser
DEBUG - 2023-09-24 04:09:55 --> Total execution time: 0.0631
ERROR - 2023-09-24 04:09:55 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-24 04:09:55 --> Config Class Initialized
INFO - 2023-09-24 04:09:55 --> Hooks Class Initialized
DEBUG - 2023-09-24 04:09:55 --> UTF-8 Support Enabled
INFO - 2023-09-24 04:09:55 --> Utf8 Class Initialized
INFO - 2023-09-24 04:09:55 --> URI Class Initialized
INFO - 2023-09-24 04:09:55 --> Router Class Initialized
INFO - 2023-09-24 04:09:55 --> Output Class Initialized
INFO - 2023-09-24 04:09:55 --> Security Class Initialized
DEBUG - 2023-09-24 04:09:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-24 04:09:55 --> Input Class Initialized
INFO - 2023-09-24 04:09:55 --> Language Class Initialized
INFO - 2023-09-24 04:09:55 --> Loader Class Initialized
INFO - 2023-09-24 04:09:55 --> Helper loaded: url_helper
INFO - 2023-09-24 04:09:55 --> Helper loaded: file_helper
INFO - 2023-09-24 04:09:55 --> Helper loaded: html_helper
INFO - 2023-09-24 04:09:55 --> Helper loaded: text_helper
INFO - 2023-09-24 04:09:55 --> Helper loaded: form_helper
INFO - 2023-09-24 04:09:55 --> Helper loaded: lang_helper
INFO - 2023-09-24 04:09:55 --> Helper loaded: security_helper
INFO - 2023-09-24 04:09:55 --> Helper loaded: cookie_helper
INFO - 2023-09-24 04:09:55 --> Database Driver Class Initialized
INFO - 2023-09-24 04:09:55 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-24 04:09:55 --> Parser Class Initialized
INFO - 2023-09-24 04:09:55 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-24 04:09:55 --> Pagination Class Initialized
INFO - 2023-09-24 04:09:55 --> Form Validation Class Initialized
INFO - 2023-09-24 04:09:55 --> Controller Class Initialized
INFO - 2023-09-24 04:09:55 --> Model Class Initialized
DEBUG - 2023-09-24 04:09:55 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-09-24 04:09:55 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-24 04:09:55 --> Model Class Initialized
DEBUG - 2023-09-24 04:09:55 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-24 04:09:55 --> Model Class Initialized
INFO - 2023-09-24 04:09:55 --> Final output sent to browser
DEBUG - 2023-09-24 04:09:55 --> Total execution time: 0.0628
ERROR - 2023-09-24 04:09:56 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-24 04:09:56 --> Config Class Initialized
INFO - 2023-09-24 04:09:56 --> Hooks Class Initialized
DEBUG - 2023-09-24 04:09:56 --> UTF-8 Support Enabled
INFO - 2023-09-24 04:09:56 --> Utf8 Class Initialized
INFO - 2023-09-24 04:09:56 --> URI Class Initialized
INFO - 2023-09-24 04:09:56 --> Router Class Initialized
INFO - 2023-09-24 04:09:56 --> Output Class Initialized
INFO - 2023-09-24 04:09:56 --> Security Class Initialized
DEBUG - 2023-09-24 04:09:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-24 04:09:56 --> Input Class Initialized
INFO - 2023-09-24 04:09:56 --> Language Class Initialized
INFO - 2023-09-24 04:09:56 --> Loader Class Initialized
INFO - 2023-09-24 04:09:56 --> Helper loaded: url_helper
INFO - 2023-09-24 04:09:56 --> Helper loaded: file_helper
INFO - 2023-09-24 04:09:56 --> Helper loaded: html_helper
INFO - 2023-09-24 04:09:56 --> Helper loaded: text_helper
INFO - 2023-09-24 04:09:56 --> Helper loaded: form_helper
INFO - 2023-09-24 04:09:56 --> Helper loaded: lang_helper
INFO - 2023-09-24 04:09:56 --> Helper loaded: security_helper
INFO - 2023-09-24 04:09:56 --> Helper loaded: cookie_helper
INFO - 2023-09-24 04:09:56 --> Database Driver Class Initialized
INFO - 2023-09-24 04:09:56 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-24 04:09:56 --> Parser Class Initialized
INFO - 2023-09-24 04:09:56 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-24 04:09:56 --> Pagination Class Initialized
INFO - 2023-09-24 04:09:56 --> Form Validation Class Initialized
INFO - 2023-09-24 04:09:56 --> Controller Class Initialized
INFO - 2023-09-24 04:09:56 --> Model Class Initialized
DEBUG - 2023-09-24 04:09:56 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-09-24 04:09:56 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-24 04:09:56 --> Model Class Initialized
DEBUG - 2023-09-24 04:09:56 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-24 04:09:56 --> Model Class Initialized
INFO - 2023-09-24 04:09:56 --> Final output sent to browser
DEBUG - 2023-09-24 04:09:56 --> Total execution time: 0.0329
ERROR - 2023-09-24 04:09:56 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-24 04:09:56 --> Config Class Initialized
INFO - 2023-09-24 04:09:56 --> Hooks Class Initialized
DEBUG - 2023-09-24 04:09:56 --> UTF-8 Support Enabled
INFO - 2023-09-24 04:09:56 --> Utf8 Class Initialized
INFO - 2023-09-24 04:09:56 --> URI Class Initialized
INFO - 2023-09-24 04:09:56 --> Router Class Initialized
INFO - 2023-09-24 04:09:56 --> Output Class Initialized
INFO - 2023-09-24 04:09:56 --> Security Class Initialized
DEBUG - 2023-09-24 04:09:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-24 04:09:56 --> Input Class Initialized
INFO - 2023-09-24 04:09:56 --> Language Class Initialized
INFO - 2023-09-24 04:09:56 --> Loader Class Initialized
INFO - 2023-09-24 04:09:56 --> Helper loaded: url_helper
INFO - 2023-09-24 04:09:56 --> Helper loaded: file_helper
INFO - 2023-09-24 04:09:56 --> Helper loaded: html_helper
INFO - 2023-09-24 04:09:56 --> Helper loaded: text_helper
INFO - 2023-09-24 04:09:56 --> Helper loaded: form_helper
INFO - 2023-09-24 04:09:56 --> Helper loaded: lang_helper
INFO - 2023-09-24 04:09:56 --> Helper loaded: security_helper
INFO - 2023-09-24 04:09:56 --> Helper loaded: cookie_helper
INFO - 2023-09-24 04:09:56 --> Database Driver Class Initialized
INFO - 2023-09-24 04:09:56 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-24 04:09:56 --> Parser Class Initialized
INFO - 2023-09-24 04:09:56 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-24 04:09:56 --> Pagination Class Initialized
INFO - 2023-09-24 04:09:56 --> Form Validation Class Initialized
INFO - 2023-09-24 04:09:56 --> Controller Class Initialized
INFO - 2023-09-24 04:09:56 --> Model Class Initialized
DEBUG - 2023-09-24 04:09:56 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-09-24 04:09:56 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-24 04:09:56 --> Model Class Initialized
DEBUG - 2023-09-24 04:09:56 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-24 04:09:56 --> Model Class Initialized
INFO - 2023-09-24 04:09:56 --> Final output sent to browser
DEBUG - 2023-09-24 04:09:56 --> Total execution time: 0.0221
ERROR - 2023-09-24 04:09:56 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-24 04:09:56 --> Config Class Initialized
INFO - 2023-09-24 04:09:56 --> Hooks Class Initialized
DEBUG - 2023-09-24 04:09:56 --> UTF-8 Support Enabled
INFO - 2023-09-24 04:09:56 --> Utf8 Class Initialized
INFO - 2023-09-24 04:09:56 --> URI Class Initialized
INFO - 2023-09-24 04:09:56 --> Router Class Initialized
INFO - 2023-09-24 04:09:56 --> Output Class Initialized
INFO - 2023-09-24 04:09:56 --> Security Class Initialized
DEBUG - 2023-09-24 04:09:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-24 04:09:56 --> Input Class Initialized
INFO - 2023-09-24 04:09:56 --> Language Class Initialized
INFO - 2023-09-24 04:09:56 --> Loader Class Initialized
INFO - 2023-09-24 04:09:56 --> Helper loaded: url_helper
INFO - 2023-09-24 04:09:56 --> Helper loaded: file_helper
INFO - 2023-09-24 04:09:56 --> Helper loaded: html_helper
INFO - 2023-09-24 04:09:56 --> Helper loaded: text_helper
INFO - 2023-09-24 04:09:56 --> Helper loaded: form_helper
INFO - 2023-09-24 04:09:56 --> Helper loaded: lang_helper
INFO - 2023-09-24 04:09:56 --> Helper loaded: security_helper
INFO - 2023-09-24 04:09:56 --> Helper loaded: cookie_helper
INFO - 2023-09-24 04:09:56 --> Database Driver Class Initialized
INFO - 2023-09-24 04:09:56 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-24 04:09:56 --> Parser Class Initialized
INFO - 2023-09-24 04:09:56 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-24 04:09:56 --> Pagination Class Initialized
INFO - 2023-09-24 04:09:56 --> Form Validation Class Initialized
INFO - 2023-09-24 04:09:56 --> Controller Class Initialized
INFO - 2023-09-24 04:09:56 --> Model Class Initialized
DEBUG - 2023-09-24 04:09:56 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-09-24 04:09:56 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-24 04:09:56 --> Model Class Initialized
DEBUG - 2023-09-24 04:09:56 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-24 04:09:56 --> Model Class Initialized
INFO - 2023-09-24 04:09:56 --> Final output sent to browser
DEBUG - 2023-09-24 04:09:56 --> Total execution time: 0.0200
ERROR - 2023-09-24 04:09:58 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-24 04:09:58 --> Config Class Initialized
INFO - 2023-09-24 04:09:58 --> Hooks Class Initialized
DEBUG - 2023-09-24 04:09:58 --> UTF-8 Support Enabled
INFO - 2023-09-24 04:09:58 --> Utf8 Class Initialized
INFO - 2023-09-24 04:09:58 --> URI Class Initialized
INFO - 2023-09-24 04:09:58 --> Router Class Initialized
INFO - 2023-09-24 04:09:58 --> Output Class Initialized
INFO - 2023-09-24 04:09:58 --> Security Class Initialized
DEBUG - 2023-09-24 04:09:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-24 04:09:58 --> Input Class Initialized
INFO - 2023-09-24 04:09:58 --> Language Class Initialized
INFO - 2023-09-24 04:09:58 --> Loader Class Initialized
INFO - 2023-09-24 04:09:58 --> Helper loaded: url_helper
INFO - 2023-09-24 04:09:58 --> Helper loaded: file_helper
INFO - 2023-09-24 04:09:58 --> Helper loaded: html_helper
INFO - 2023-09-24 04:09:58 --> Helper loaded: text_helper
INFO - 2023-09-24 04:09:58 --> Helper loaded: form_helper
INFO - 2023-09-24 04:09:58 --> Helper loaded: lang_helper
INFO - 2023-09-24 04:09:58 --> Helper loaded: security_helper
INFO - 2023-09-24 04:09:58 --> Helper loaded: cookie_helper
INFO - 2023-09-24 04:09:58 --> Database Driver Class Initialized
INFO - 2023-09-24 04:09:58 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-24 04:09:58 --> Parser Class Initialized
INFO - 2023-09-24 04:09:58 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-24 04:09:58 --> Pagination Class Initialized
INFO - 2023-09-24 04:09:58 --> Form Validation Class Initialized
INFO - 2023-09-24 04:09:58 --> Controller Class Initialized
INFO - 2023-09-24 04:09:58 --> Model Class Initialized
DEBUG - 2023-09-24 04:09:58 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-09-24 04:09:58 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-24 04:09:58 --> Model Class Initialized
DEBUG - 2023-09-24 04:09:58 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-24 04:09:58 --> Model Class Initialized
INFO - 2023-09-24 04:09:58 --> Model Class Initialized
INFO - 2023-09-24 04:09:58 --> Final output sent to browser
DEBUG - 2023-09-24 04:09:58 --> Total execution time: 0.0242
ERROR - 2023-09-24 04:10:05 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-24 04:10:05 --> Config Class Initialized
INFO - 2023-09-24 04:10:05 --> Hooks Class Initialized
DEBUG - 2023-09-24 04:10:05 --> UTF-8 Support Enabled
INFO - 2023-09-24 04:10:05 --> Utf8 Class Initialized
INFO - 2023-09-24 04:10:05 --> URI Class Initialized
INFO - 2023-09-24 04:10:05 --> Router Class Initialized
INFO - 2023-09-24 04:10:05 --> Output Class Initialized
INFO - 2023-09-24 04:10:05 --> Security Class Initialized
DEBUG - 2023-09-24 04:10:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-24 04:10:05 --> Input Class Initialized
INFO - 2023-09-24 04:10:05 --> Language Class Initialized
INFO - 2023-09-24 04:10:05 --> Loader Class Initialized
INFO - 2023-09-24 04:10:05 --> Helper loaded: url_helper
INFO - 2023-09-24 04:10:05 --> Helper loaded: file_helper
INFO - 2023-09-24 04:10:05 --> Helper loaded: html_helper
INFO - 2023-09-24 04:10:05 --> Helper loaded: text_helper
INFO - 2023-09-24 04:10:05 --> Helper loaded: form_helper
INFO - 2023-09-24 04:10:05 --> Helper loaded: lang_helper
INFO - 2023-09-24 04:10:05 --> Helper loaded: security_helper
INFO - 2023-09-24 04:10:05 --> Helper loaded: cookie_helper
INFO - 2023-09-24 04:10:05 --> Database Driver Class Initialized
INFO - 2023-09-24 04:10:05 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-24 04:10:05 --> Parser Class Initialized
INFO - 2023-09-24 04:10:05 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-24 04:10:05 --> Pagination Class Initialized
INFO - 2023-09-24 04:10:05 --> Form Validation Class Initialized
INFO - 2023-09-24 04:10:05 --> Controller Class Initialized
INFO - 2023-09-24 04:10:05 --> Model Class Initialized
DEBUG - 2023-09-24 04:10:05 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-09-24 04:10:05 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-24 04:10:05 --> Model Class Initialized
DEBUG - 2023-09-24 04:10:05 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-24 04:10:05 --> Model Class Initialized
INFO - 2023-09-24 04:10:05 --> Final output sent to browser
DEBUG - 2023-09-24 04:10:05 --> Total execution time: 0.0210
ERROR - 2023-09-24 04:10:05 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-24 04:10:05 --> Config Class Initialized
INFO - 2023-09-24 04:10:05 --> Hooks Class Initialized
DEBUG - 2023-09-24 04:10:05 --> UTF-8 Support Enabled
INFO - 2023-09-24 04:10:05 --> Utf8 Class Initialized
INFO - 2023-09-24 04:10:05 --> URI Class Initialized
INFO - 2023-09-24 04:10:05 --> Router Class Initialized
INFO - 2023-09-24 04:10:05 --> Output Class Initialized
INFO - 2023-09-24 04:10:05 --> Security Class Initialized
DEBUG - 2023-09-24 04:10:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-24 04:10:05 --> Input Class Initialized
INFO - 2023-09-24 04:10:05 --> Language Class Initialized
INFO - 2023-09-24 04:10:05 --> Loader Class Initialized
INFO - 2023-09-24 04:10:05 --> Helper loaded: url_helper
INFO - 2023-09-24 04:10:05 --> Helper loaded: file_helper
INFO - 2023-09-24 04:10:05 --> Helper loaded: html_helper
INFO - 2023-09-24 04:10:05 --> Helper loaded: text_helper
INFO - 2023-09-24 04:10:05 --> Helper loaded: form_helper
INFO - 2023-09-24 04:10:05 --> Helper loaded: lang_helper
INFO - 2023-09-24 04:10:05 --> Helper loaded: security_helper
INFO - 2023-09-24 04:10:05 --> Helper loaded: cookie_helper
INFO - 2023-09-24 04:10:05 --> Database Driver Class Initialized
INFO - 2023-09-24 04:10:05 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-24 04:10:05 --> Parser Class Initialized
INFO - 2023-09-24 04:10:05 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-24 04:10:05 --> Pagination Class Initialized
INFO - 2023-09-24 04:10:05 --> Form Validation Class Initialized
INFO - 2023-09-24 04:10:05 --> Controller Class Initialized
INFO - 2023-09-24 04:10:05 --> Model Class Initialized
DEBUG - 2023-09-24 04:10:05 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-09-24 04:10:05 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-24 04:10:05 --> Model Class Initialized
DEBUG - 2023-09-24 04:10:05 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-24 04:10:05 --> Model Class Initialized
INFO - 2023-09-24 04:10:05 --> Final output sent to browser
DEBUG - 2023-09-24 04:10:05 --> Total execution time: 0.0229
ERROR - 2023-09-24 04:10:07 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-24 04:10:07 --> Config Class Initialized
INFO - 2023-09-24 04:10:07 --> Hooks Class Initialized
DEBUG - 2023-09-24 04:10:07 --> UTF-8 Support Enabled
INFO - 2023-09-24 04:10:07 --> Utf8 Class Initialized
INFO - 2023-09-24 04:10:07 --> URI Class Initialized
INFO - 2023-09-24 04:10:07 --> Router Class Initialized
INFO - 2023-09-24 04:10:07 --> Output Class Initialized
INFO - 2023-09-24 04:10:07 --> Security Class Initialized
DEBUG - 2023-09-24 04:10:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-24 04:10:07 --> Input Class Initialized
INFO - 2023-09-24 04:10:07 --> Language Class Initialized
INFO - 2023-09-24 04:10:07 --> Loader Class Initialized
INFO - 2023-09-24 04:10:07 --> Helper loaded: url_helper
INFO - 2023-09-24 04:10:07 --> Helper loaded: file_helper
INFO - 2023-09-24 04:10:07 --> Helper loaded: html_helper
INFO - 2023-09-24 04:10:07 --> Helper loaded: text_helper
INFO - 2023-09-24 04:10:07 --> Helper loaded: form_helper
INFO - 2023-09-24 04:10:07 --> Helper loaded: lang_helper
INFO - 2023-09-24 04:10:07 --> Helper loaded: security_helper
INFO - 2023-09-24 04:10:07 --> Helper loaded: cookie_helper
INFO - 2023-09-24 04:10:07 --> Database Driver Class Initialized
INFO - 2023-09-24 04:10:07 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-24 04:10:07 --> Parser Class Initialized
INFO - 2023-09-24 04:10:07 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-24 04:10:07 --> Pagination Class Initialized
INFO - 2023-09-24 04:10:07 --> Form Validation Class Initialized
INFO - 2023-09-24 04:10:07 --> Controller Class Initialized
INFO - 2023-09-24 04:10:07 --> Model Class Initialized
DEBUG - 2023-09-24 04:10:07 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-09-24 04:10:07 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-24 04:10:07 --> Model Class Initialized
DEBUG - 2023-09-24 04:10:07 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-24 04:10:07 --> Model Class Initialized
INFO - 2023-09-24 04:10:07 --> Model Class Initialized
INFO - 2023-09-24 04:10:07 --> Final output sent to browser
DEBUG - 2023-09-24 04:10:07 --> Total execution time: 0.0265
ERROR - 2023-09-24 04:10:44 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-24 04:10:44 --> Config Class Initialized
INFO - 2023-09-24 04:10:44 --> Hooks Class Initialized
DEBUG - 2023-09-24 04:10:44 --> UTF-8 Support Enabled
INFO - 2023-09-24 04:10:44 --> Utf8 Class Initialized
INFO - 2023-09-24 04:10:44 --> URI Class Initialized
INFO - 2023-09-24 04:10:44 --> Router Class Initialized
INFO - 2023-09-24 04:10:44 --> Output Class Initialized
INFO - 2023-09-24 04:10:44 --> Security Class Initialized
DEBUG - 2023-09-24 04:10:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-24 04:10:44 --> Input Class Initialized
INFO - 2023-09-24 04:10:44 --> Language Class Initialized
INFO - 2023-09-24 04:10:44 --> Loader Class Initialized
INFO - 2023-09-24 04:10:44 --> Helper loaded: url_helper
INFO - 2023-09-24 04:10:44 --> Helper loaded: file_helper
INFO - 2023-09-24 04:10:44 --> Helper loaded: html_helper
INFO - 2023-09-24 04:10:44 --> Helper loaded: text_helper
INFO - 2023-09-24 04:10:44 --> Helper loaded: form_helper
INFO - 2023-09-24 04:10:44 --> Helper loaded: lang_helper
INFO - 2023-09-24 04:10:44 --> Helper loaded: security_helper
INFO - 2023-09-24 04:10:44 --> Helper loaded: cookie_helper
INFO - 2023-09-24 04:10:44 --> Database Driver Class Initialized
INFO - 2023-09-24 04:10:44 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-24 04:10:44 --> Parser Class Initialized
INFO - 2023-09-24 04:10:44 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-24 04:10:44 --> Pagination Class Initialized
INFO - 2023-09-24 04:10:44 --> Form Validation Class Initialized
INFO - 2023-09-24 04:10:44 --> Controller Class Initialized
INFO - 2023-09-24 04:10:44 --> Model Class Initialized
DEBUG - 2023-09-24 04:10:44 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-09-24 04:10:44 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-24 04:10:44 --> Model Class Initialized
DEBUG - 2023-09-24 04:10:44 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-24 04:10:44 --> Model Class Initialized
INFO - 2023-09-24 04:10:44 --> Final output sent to browser
DEBUG - 2023-09-24 04:10:44 --> Total execution time: 0.0758
ERROR - 2023-09-24 04:10:45 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-24 04:10:45 --> Config Class Initialized
INFO - 2023-09-24 04:10:45 --> Hooks Class Initialized
DEBUG - 2023-09-24 04:10:45 --> UTF-8 Support Enabled
INFO - 2023-09-24 04:10:45 --> Utf8 Class Initialized
INFO - 2023-09-24 04:10:45 --> URI Class Initialized
INFO - 2023-09-24 04:10:45 --> Router Class Initialized
INFO - 2023-09-24 04:10:45 --> Output Class Initialized
INFO - 2023-09-24 04:10:45 --> Security Class Initialized
DEBUG - 2023-09-24 04:10:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-24 04:10:45 --> Input Class Initialized
INFO - 2023-09-24 04:10:45 --> Language Class Initialized
INFO - 2023-09-24 04:10:45 --> Loader Class Initialized
INFO - 2023-09-24 04:10:45 --> Helper loaded: url_helper
INFO - 2023-09-24 04:10:45 --> Helper loaded: file_helper
INFO - 2023-09-24 04:10:45 --> Helper loaded: html_helper
INFO - 2023-09-24 04:10:45 --> Helper loaded: text_helper
INFO - 2023-09-24 04:10:45 --> Helper loaded: form_helper
INFO - 2023-09-24 04:10:45 --> Helper loaded: lang_helper
INFO - 2023-09-24 04:10:45 --> Helper loaded: security_helper
INFO - 2023-09-24 04:10:45 --> Helper loaded: cookie_helper
INFO - 2023-09-24 04:10:45 --> Database Driver Class Initialized
INFO - 2023-09-24 04:10:45 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-24 04:10:45 --> Parser Class Initialized
INFO - 2023-09-24 04:10:45 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-24 04:10:45 --> Pagination Class Initialized
INFO - 2023-09-24 04:10:45 --> Form Validation Class Initialized
INFO - 2023-09-24 04:10:45 --> Controller Class Initialized
INFO - 2023-09-24 04:10:45 --> Model Class Initialized
DEBUG - 2023-09-24 04:10:45 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-09-24 04:10:45 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-24 04:10:45 --> Model Class Initialized
DEBUG - 2023-09-24 04:10:45 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-24 04:10:45 --> Model Class Initialized
INFO - 2023-09-24 04:10:45 --> Final output sent to browser
DEBUG - 2023-09-24 04:10:45 --> Total execution time: 0.0641
ERROR - 2023-09-24 04:10:45 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-24 04:10:45 --> Config Class Initialized
INFO - 2023-09-24 04:10:45 --> Hooks Class Initialized
DEBUG - 2023-09-24 04:10:45 --> UTF-8 Support Enabled
INFO - 2023-09-24 04:10:45 --> Utf8 Class Initialized
INFO - 2023-09-24 04:10:45 --> URI Class Initialized
INFO - 2023-09-24 04:10:45 --> Router Class Initialized
INFO - 2023-09-24 04:10:45 --> Output Class Initialized
INFO - 2023-09-24 04:10:45 --> Security Class Initialized
DEBUG - 2023-09-24 04:10:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-24 04:10:45 --> Input Class Initialized
INFO - 2023-09-24 04:10:45 --> Language Class Initialized
INFO - 2023-09-24 04:10:45 --> Loader Class Initialized
INFO - 2023-09-24 04:10:45 --> Helper loaded: url_helper
INFO - 2023-09-24 04:10:45 --> Helper loaded: file_helper
INFO - 2023-09-24 04:10:45 --> Helper loaded: html_helper
INFO - 2023-09-24 04:10:45 --> Helper loaded: text_helper
INFO - 2023-09-24 04:10:45 --> Helper loaded: form_helper
INFO - 2023-09-24 04:10:45 --> Helper loaded: lang_helper
INFO - 2023-09-24 04:10:45 --> Helper loaded: security_helper
INFO - 2023-09-24 04:10:45 --> Helper loaded: cookie_helper
INFO - 2023-09-24 04:10:45 --> Database Driver Class Initialized
INFO - 2023-09-24 04:10:45 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-24 04:10:45 --> Parser Class Initialized
INFO - 2023-09-24 04:10:45 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-24 04:10:45 --> Pagination Class Initialized
INFO - 2023-09-24 04:10:45 --> Form Validation Class Initialized
INFO - 2023-09-24 04:10:45 --> Controller Class Initialized
INFO - 2023-09-24 04:10:45 --> Model Class Initialized
DEBUG - 2023-09-24 04:10:45 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-09-24 04:10:45 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-24 04:10:45 --> Model Class Initialized
DEBUG - 2023-09-24 04:10:45 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-24 04:10:45 --> Model Class Initialized
INFO - 2023-09-24 04:10:45 --> Final output sent to browser
DEBUG - 2023-09-24 04:10:45 --> Total execution time: 0.0652
ERROR - 2023-09-24 04:10:45 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-24 04:10:45 --> Config Class Initialized
INFO - 2023-09-24 04:10:45 --> Hooks Class Initialized
DEBUG - 2023-09-24 04:10:45 --> UTF-8 Support Enabled
INFO - 2023-09-24 04:10:45 --> Utf8 Class Initialized
INFO - 2023-09-24 04:10:45 --> URI Class Initialized
INFO - 2023-09-24 04:10:45 --> Router Class Initialized
INFO - 2023-09-24 04:10:45 --> Output Class Initialized
INFO - 2023-09-24 04:10:45 --> Security Class Initialized
DEBUG - 2023-09-24 04:10:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-24 04:10:45 --> Input Class Initialized
INFO - 2023-09-24 04:10:45 --> Language Class Initialized
INFO - 2023-09-24 04:10:45 --> Loader Class Initialized
INFO - 2023-09-24 04:10:45 --> Helper loaded: url_helper
INFO - 2023-09-24 04:10:45 --> Helper loaded: file_helper
INFO - 2023-09-24 04:10:45 --> Helper loaded: html_helper
INFO - 2023-09-24 04:10:45 --> Helper loaded: text_helper
INFO - 2023-09-24 04:10:45 --> Helper loaded: form_helper
INFO - 2023-09-24 04:10:45 --> Helper loaded: lang_helper
INFO - 2023-09-24 04:10:45 --> Helper loaded: security_helper
INFO - 2023-09-24 04:10:45 --> Helper loaded: cookie_helper
INFO - 2023-09-24 04:10:45 --> Database Driver Class Initialized
INFO - 2023-09-24 04:10:45 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-24 04:10:45 --> Parser Class Initialized
INFO - 2023-09-24 04:10:45 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-24 04:10:45 --> Pagination Class Initialized
INFO - 2023-09-24 04:10:45 --> Form Validation Class Initialized
INFO - 2023-09-24 04:10:45 --> Controller Class Initialized
INFO - 2023-09-24 04:10:45 --> Model Class Initialized
DEBUG - 2023-09-24 04:10:45 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-09-24 04:10:45 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-24 04:10:45 --> Model Class Initialized
DEBUG - 2023-09-24 04:10:45 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-24 04:10:45 --> Model Class Initialized
INFO - 2023-09-24 04:10:45 --> Final output sent to browser
DEBUG - 2023-09-24 04:10:45 --> Total execution time: 0.0811
ERROR - 2023-09-24 04:10:49 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-24 04:10:49 --> Config Class Initialized
INFO - 2023-09-24 04:10:49 --> Hooks Class Initialized
DEBUG - 2023-09-24 04:10:49 --> UTF-8 Support Enabled
INFO - 2023-09-24 04:10:49 --> Utf8 Class Initialized
INFO - 2023-09-24 04:10:49 --> URI Class Initialized
INFO - 2023-09-24 04:10:49 --> Router Class Initialized
INFO - 2023-09-24 04:10:49 --> Output Class Initialized
INFO - 2023-09-24 04:10:49 --> Security Class Initialized
DEBUG - 2023-09-24 04:10:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-24 04:10:49 --> Input Class Initialized
INFO - 2023-09-24 04:10:49 --> Language Class Initialized
INFO - 2023-09-24 04:10:49 --> Loader Class Initialized
INFO - 2023-09-24 04:10:49 --> Helper loaded: url_helper
INFO - 2023-09-24 04:10:49 --> Helper loaded: file_helper
INFO - 2023-09-24 04:10:49 --> Helper loaded: html_helper
INFO - 2023-09-24 04:10:49 --> Helper loaded: text_helper
INFO - 2023-09-24 04:10:49 --> Helper loaded: form_helper
INFO - 2023-09-24 04:10:49 --> Helper loaded: lang_helper
INFO - 2023-09-24 04:10:49 --> Helper loaded: security_helper
INFO - 2023-09-24 04:10:49 --> Helper loaded: cookie_helper
INFO - 2023-09-24 04:10:49 --> Database Driver Class Initialized
INFO - 2023-09-24 04:10:49 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-24 04:10:49 --> Parser Class Initialized
INFO - 2023-09-24 04:10:49 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-24 04:10:49 --> Pagination Class Initialized
INFO - 2023-09-24 04:10:49 --> Form Validation Class Initialized
INFO - 2023-09-24 04:10:49 --> Controller Class Initialized
INFO - 2023-09-24 04:10:49 --> Model Class Initialized
DEBUG - 2023-09-24 04:10:49 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-09-24 04:10:49 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-24 04:10:49 --> Model Class Initialized
DEBUG - 2023-09-24 04:10:49 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-24 04:10:49 --> Model Class Initialized
INFO - 2023-09-24 04:10:49 --> Final output sent to browser
DEBUG - 2023-09-24 04:10:49 --> Total execution time: 0.0332
ERROR - 2023-09-24 04:10:50 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-24 04:10:50 --> Config Class Initialized
INFO - 2023-09-24 04:10:50 --> Hooks Class Initialized
DEBUG - 2023-09-24 04:10:50 --> UTF-8 Support Enabled
INFO - 2023-09-24 04:10:50 --> Utf8 Class Initialized
INFO - 2023-09-24 04:10:50 --> URI Class Initialized
INFO - 2023-09-24 04:10:50 --> Router Class Initialized
INFO - 2023-09-24 04:10:50 --> Output Class Initialized
INFO - 2023-09-24 04:10:50 --> Security Class Initialized
DEBUG - 2023-09-24 04:10:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-24 04:10:50 --> Input Class Initialized
INFO - 2023-09-24 04:10:50 --> Language Class Initialized
INFO - 2023-09-24 04:10:50 --> Loader Class Initialized
INFO - 2023-09-24 04:10:50 --> Helper loaded: url_helper
INFO - 2023-09-24 04:10:50 --> Helper loaded: file_helper
INFO - 2023-09-24 04:10:50 --> Helper loaded: html_helper
INFO - 2023-09-24 04:10:50 --> Helper loaded: text_helper
INFO - 2023-09-24 04:10:50 --> Helper loaded: form_helper
INFO - 2023-09-24 04:10:50 --> Helper loaded: lang_helper
INFO - 2023-09-24 04:10:50 --> Helper loaded: security_helper
INFO - 2023-09-24 04:10:50 --> Helper loaded: cookie_helper
INFO - 2023-09-24 04:10:50 --> Database Driver Class Initialized
INFO - 2023-09-24 04:10:50 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-24 04:10:50 --> Parser Class Initialized
INFO - 2023-09-24 04:10:50 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-24 04:10:50 --> Pagination Class Initialized
INFO - 2023-09-24 04:10:50 --> Form Validation Class Initialized
INFO - 2023-09-24 04:10:50 --> Controller Class Initialized
INFO - 2023-09-24 04:10:50 --> Model Class Initialized
DEBUG - 2023-09-24 04:10:50 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-09-24 04:10:50 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-24 04:10:50 --> Model Class Initialized
DEBUG - 2023-09-24 04:10:50 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-24 04:10:50 --> Model Class Initialized
INFO - 2023-09-24 04:10:50 --> Final output sent to browser
DEBUG - 2023-09-24 04:10:50 --> Total execution time: 0.0313
ERROR - 2023-09-24 04:10:52 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-24 04:10:52 --> Config Class Initialized
INFO - 2023-09-24 04:10:52 --> Hooks Class Initialized
DEBUG - 2023-09-24 04:10:52 --> UTF-8 Support Enabled
INFO - 2023-09-24 04:10:52 --> Utf8 Class Initialized
INFO - 2023-09-24 04:10:52 --> URI Class Initialized
INFO - 2023-09-24 04:10:52 --> Router Class Initialized
INFO - 2023-09-24 04:10:52 --> Output Class Initialized
INFO - 2023-09-24 04:10:52 --> Security Class Initialized
DEBUG - 2023-09-24 04:10:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-24 04:10:52 --> Input Class Initialized
INFO - 2023-09-24 04:10:52 --> Language Class Initialized
INFO - 2023-09-24 04:10:52 --> Loader Class Initialized
INFO - 2023-09-24 04:10:52 --> Helper loaded: url_helper
INFO - 2023-09-24 04:10:52 --> Helper loaded: file_helper
INFO - 2023-09-24 04:10:52 --> Helper loaded: html_helper
INFO - 2023-09-24 04:10:52 --> Helper loaded: text_helper
INFO - 2023-09-24 04:10:52 --> Helper loaded: form_helper
INFO - 2023-09-24 04:10:52 --> Helper loaded: lang_helper
INFO - 2023-09-24 04:10:52 --> Helper loaded: security_helper
INFO - 2023-09-24 04:10:52 --> Helper loaded: cookie_helper
INFO - 2023-09-24 04:10:52 --> Database Driver Class Initialized
INFO - 2023-09-24 04:10:52 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-24 04:10:52 --> Parser Class Initialized
INFO - 2023-09-24 04:10:52 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-24 04:10:52 --> Pagination Class Initialized
INFO - 2023-09-24 04:10:52 --> Form Validation Class Initialized
INFO - 2023-09-24 04:10:52 --> Controller Class Initialized
INFO - 2023-09-24 04:10:52 --> Model Class Initialized
DEBUG - 2023-09-24 04:10:52 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-09-24 04:10:52 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-24 04:10:52 --> Model Class Initialized
DEBUG - 2023-09-24 04:10:52 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-24 04:10:52 --> Model Class Initialized
INFO - 2023-09-24 04:10:52 --> Model Class Initialized
INFO - 2023-09-24 04:10:52 --> Final output sent to browser
DEBUG - 2023-09-24 04:10:52 --> Total execution time: 0.0221
ERROR - 2023-09-24 04:11:06 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-24 04:11:06 --> Config Class Initialized
INFO - 2023-09-24 04:11:06 --> Hooks Class Initialized
DEBUG - 2023-09-24 04:11:06 --> UTF-8 Support Enabled
INFO - 2023-09-24 04:11:06 --> Utf8 Class Initialized
INFO - 2023-09-24 04:11:06 --> URI Class Initialized
INFO - 2023-09-24 04:11:06 --> Router Class Initialized
INFO - 2023-09-24 04:11:06 --> Output Class Initialized
INFO - 2023-09-24 04:11:06 --> Security Class Initialized
DEBUG - 2023-09-24 04:11:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-24 04:11:06 --> Input Class Initialized
INFO - 2023-09-24 04:11:06 --> Language Class Initialized
INFO - 2023-09-24 04:11:06 --> Loader Class Initialized
INFO - 2023-09-24 04:11:06 --> Helper loaded: url_helper
INFO - 2023-09-24 04:11:06 --> Helper loaded: file_helper
INFO - 2023-09-24 04:11:06 --> Helper loaded: html_helper
INFO - 2023-09-24 04:11:06 --> Helper loaded: text_helper
INFO - 2023-09-24 04:11:06 --> Helper loaded: form_helper
INFO - 2023-09-24 04:11:06 --> Helper loaded: lang_helper
INFO - 2023-09-24 04:11:06 --> Helper loaded: security_helper
INFO - 2023-09-24 04:11:06 --> Helper loaded: cookie_helper
INFO - 2023-09-24 04:11:06 --> Database Driver Class Initialized
INFO - 2023-09-24 04:11:06 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-24 04:11:06 --> Parser Class Initialized
INFO - 2023-09-24 04:11:06 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-24 04:11:06 --> Pagination Class Initialized
INFO - 2023-09-24 04:11:06 --> Form Validation Class Initialized
INFO - 2023-09-24 04:11:06 --> Controller Class Initialized
INFO - 2023-09-24 04:11:06 --> Model Class Initialized
DEBUG - 2023-09-24 04:11:06 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-09-24 04:11:06 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-24 04:11:06 --> Model Class Initialized
DEBUG - 2023-09-24 04:11:06 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-24 04:11:06 --> Model Class Initialized
INFO - 2023-09-24 04:11:06 --> Final output sent to browser
DEBUG - 2023-09-24 04:11:06 --> Total execution time: 0.0815
ERROR - 2023-09-24 04:11:06 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-24 04:11:06 --> Config Class Initialized
INFO - 2023-09-24 04:11:06 --> Hooks Class Initialized
DEBUG - 2023-09-24 04:11:06 --> UTF-8 Support Enabled
INFO - 2023-09-24 04:11:06 --> Utf8 Class Initialized
INFO - 2023-09-24 04:11:06 --> URI Class Initialized
INFO - 2023-09-24 04:11:06 --> Router Class Initialized
INFO - 2023-09-24 04:11:06 --> Output Class Initialized
INFO - 2023-09-24 04:11:06 --> Security Class Initialized
DEBUG - 2023-09-24 04:11:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-24 04:11:06 --> Input Class Initialized
INFO - 2023-09-24 04:11:06 --> Language Class Initialized
INFO - 2023-09-24 04:11:06 --> Loader Class Initialized
INFO - 2023-09-24 04:11:06 --> Helper loaded: url_helper
INFO - 2023-09-24 04:11:06 --> Helper loaded: file_helper
INFO - 2023-09-24 04:11:06 --> Helper loaded: html_helper
INFO - 2023-09-24 04:11:06 --> Helper loaded: text_helper
INFO - 2023-09-24 04:11:06 --> Helper loaded: form_helper
INFO - 2023-09-24 04:11:06 --> Helper loaded: lang_helper
INFO - 2023-09-24 04:11:06 --> Helper loaded: security_helper
INFO - 2023-09-24 04:11:06 --> Helper loaded: cookie_helper
INFO - 2023-09-24 04:11:06 --> Database Driver Class Initialized
INFO - 2023-09-24 04:11:06 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-24 04:11:06 --> Parser Class Initialized
INFO - 2023-09-24 04:11:06 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-24 04:11:06 --> Pagination Class Initialized
INFO - 2023-09-24 04:11:06 --> Form Validation Class Initialized
INFO - 2023-09-24 04:11:06 --> Controller Class Initialized
INFO - 2023-09-24 04:11:06 --> Model Class Initialized
DEBUG - 2023-09-24 04:11:06 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-09-24 04:11:06 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-24 04:11:06 --> Model Class Initialized
DEBUG - 2023-09-24 04:11:06 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-24 04:11:06 --> Model Class Initialized
INFO - 2023-09-24 04:11:06 --> Final output sent to browser
DEBUG - 2023-09-24 04:11:06 --> Total execution time: 0.0725
ERROR - 2023-09-24 04:11:07 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-24 04:11:07 --> Config Class Initialized
INFO - 2023-09-24 04:11:07 --> Hooks Class Initialized
DEBUG - 2023-09-24 04:11:07 --> UTF-8 Support Enabled
INFO - 2023-09-24 04:11:07 --> Utf8 Class Initialized
INFO - 2023-09-24 04:11:07 --> URI Class Initialized
INFO - 2023-09-24 04:11:07 --> Router Class Initialized
INFO - 2023-09-24 04:11:07 --> Output Class Initialized
INFO - 2023-09-24 04:11:07 --> Security Class Initialized
DEBUG - 2023-09-24 04:11:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-24 04:11:07 --> Input Class Initialized
INFO - 2023-09-24 04:11:07 --> Language Class Initialized
INFO - 2023-09-24 04:11:07 --> Loader Class Initialized
INFO - 2023-09-24 04:11:07 --> Helper loaded: url_helper
INFO - 2023-09-24 04:11:07 --> Helper loaded: file_helper
INFO - 2023-09-24 04:11:07 --> Helper loaded: html_helper
INFO - 2023-09-24 04:11:07 --> Helper loaded: text_helper
INFO - 2023-09-24 04:11:07 --> Helper loaded: form_helper
INFO - 2023-09-24 04:11:07 --> Helper loaded: lang_helper
INFO - 2023-09-24 04:11:07 --> Helper loaded: security_helper
INFO - 2023-09-24 04:11:07 --> Helper loaded: cookie_helper
INFO - 2023-09-24 04:11:07 --> Database Driver Class Initialized
INFO - 2023-09-24 04:11:07 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-24 04:11:07 --> Parser Class Initialized
INFO - 2023-09-24 04:11:07 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-24 04:11:07 --> Pagination Class Initialized
INFO - 2023-09-24 04:11:07 --> Form Validation Class Initialized
INFO - 2023-09-24 04:11:07 --> Controller Class Initialized
INFO - 2023-09-24 04:11:07 --> Model Class Initialized
DEBUG - 2023-09-24 04:11:07 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-09-24 04:11:07 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-24 04:11:07 --> Model Class Initialized
DEBUG - 2023-09-24 04:11:07 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-24 04:11:07 --> Model Class Initialized
INFO - 2023-09-24 04:11:07 --> Final output sent to browser
DEBUG - 2023-09-24 04:11:07 --> Total execution time: 0.1060
ERROR - 2023-09-24 04:11:08 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-24 04:11:08 --> Config Class Initialized
INFO - 2023-09-24 04:11:08 --> Hooks Class Initialized
DEBUG - 2023-09-24 04:11:08 --> UTF-8 Support Enabled
INFO - 2023-09-24 04:11:08 --> Utf8 Class Initialized
INFO - 2023-09-24 04:11:08 --> URI Class Initialized
INFO - 2023-09-24 04:11:08 --> Router Class Initialized
INFO - 2023-09-24 04:11:08 --> Output Class Initialized
INFO - 2023-09-24 04:11:08 --> Security Class Initialized
DEBUG - 2023-09-24 04:11:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-24 04:11:08 --> Input Class Initialized
INFO - 2023-09-24 04:11:08 --> Language Class Initialized
INFO - 2023-09-24 04:11:08 --> Loader Class Initialized
INFO - 2023-09-24 04:11:08 --> Helper loaded: url_helper
INFO - 2023-09-24 04:11:08 --> Helper loaded: file_helper
INFO - 2023-09-24 04:11:08 --> Helper loaded: html_helper
INFO - 2023-09-24 04:11:08 --> Helper loaded: text_helper
INFO - 2023-09-24 04:11:08 --> Helper loaded: form_helper
INFO - 2023-09-24 04:11:08 --> Helper loaded: lang_helper
INFO - 2023-09-24 04:11:08 --> Helper loaded: security_helper
INFO - 2023-09-24 04:11:08 --> Helper loaded: cookie_helper
INFO - 2023-09-24 04:11:08 --> Database Driver Class Initialized
INFO - 2023-09-24 04:11:08 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-24 04:11:08 --> Parser Class Initialized
INFO - 2023-09-24 04:11:08 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-24 04:11:08 --> Pagination Class Initialized
INFO - 2023-09-24 04:11:08 --> Form Validation Class Initialized
INFO - 2023-09-24 04:11:08 --> Controller Class Initialized
INFO - 2023-09-24 04:11:08 --> Model Class Initialized
DEBUG - 2023-09-24 04:11:08 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-09-24 04:11:08 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-24 04:11:08 --> Model Class Initialized
DEBUG - 2023-09-24 04:11:08 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-24 04:11:08 --> Model Class Initialized
INFO - 2023-09-24 04:11:08 --> Final output sent to browser
DEBUG - 2023-09-24 04:11:08 --> Total execution time: 0.0709
ERROR - 2023-09-24 04:11:09 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-24 04:11:09 --> Config Class Initialized
INFO - 2023-09-24 04:11:09 --> Hooks Class Initialized
DEBUG - 2023-09-24 04:11:09 --> UTF-8 Support Enabled
INFO - 2023-09-24 04:11:09 --> Utf8 Class Initialized
INFO - 2023-09-24 04:11:09 --> URI Class Initialized
INFO - 2023-09-24 04:11:09 --> Router Class Initialized
INFO - 2023-09-24 04:11:09 --> Output Class Initialized
INFO - 2023-09-24 04:11:09 --> Security Class Initialized
DEBUG - 2023-09-24 04:11:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-24 04:11:09 --> Input Class Initialized
INFO - 2023-09-24 04:11:09 --> Language Class Initialized
INFO - 2023-09-24 04:11:09 --> Loader Class Initialized
INFO - 2023-09-24 04:11:09 --> Helper loaded: url_helper
INFO - 2023-09-24 04:11:09 --> Helper loaded: file_helper
INFO - 2023-09-24 04:11:09 --> Helper loaded: html_helper
INFO - 2023-09-24 04:11:09 --> Helper loaded: text_helper
INFO - 2023-09-24 04:11:09 --> Helper loaded: form_helper
INFO - 2023-09-24 04:11:09 --> Helper loaded: lang_helper
INFO - 2023-09-24 04:11:09 --> Helper loaded: security_helper
INFO - 2023-09-24 04:11:09 --> Helper loaded: cookie_helper
INFO - 2023-09-24 04:11:09 --> Database Driver Class Initialized
INFO - 2023-09-24 04:11:09 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-24 04:11:09 --> Parser Class Initialized
INFO - 2023-09-24 04:11:09 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-24 04:11:09 --> Pagination Class Initialized
INFO - 2023-09-24 04:11:09 --> Form Validation Class Initialized
INFO - 2023-09-24 04:11:09 --> Controller Class Initialized
INFO - 2023-09-24 04:11:09 --> Model Class Initialized
DEBUG - 2023-09-24 04:11:09 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-09-24 04:11:09 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-24 04:11:09 --> Model Class Initialized
DEBUG - 2023-09-24 04:11:09 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-24 04:11:09 --> Model Class Initialized
INFO - 2023-09-24 04:11:09 --> Final output sent to browser
DEBUG - 2023-09-24 04:11:09 --> Total execution time: 0.0230
ERROR - 2023-09-24 04:11:12 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-24 04:11:12 --> Config Class Initialized
INFO - 2023-09-24 04:11:12 --> Hooks Class Initialized
DEBUG - 2023-09-24 04:11:12 --> UTF-8 Support Enabled
INFO - 2023-09-24 04:11:12 --> Utf8 Class Initialized
INFO - 2023-09-24 04:11:12 --> URI Class Initialized
INFO - 2023-09-24 04:11:12 --> Router Class Initialized
INFO - 2023-09-24 04:11:12 --> Output Class Initialized
INFO - 2023-09-24 04:11:12 --> Security Class Initialized
DEBUG - 2023-09-24 04:11:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-24 04:11:12 --> Input Class Initialized
INFO - 2023-09-24 04:11:12 --> Language Class Initialized
INFO - 2023-09-24 04:11:12 --> Loader Class Initialized
INFO - 2023-09-24 04:11:12 --> Helper loaded: url_helper
INFO - 2023-09-24 04:11:12 --> Helper loaded: file_helper
INFO - 2023-09-24 04:11:12 --> Helper loaded: html_helper
INFO - 2023-09-24 04:11:12 --> Helper loaded: text_helper
INFO - 2023-09-24 04:11:12 --> Helper loaded: form_helper
INFO - 2023-09-24 04:11:12 --> Helper loaded: lang_helper
INFO - 2023-09-24 04:11:12 --> Helper loaded: security_helper
INFO - 2023-09-24 04:11:12 --> Helper loaded: cookie_helper
INFO - 2023-09-24 04:11:12 --> Database Driver Class Initialized
INFO - 2023-09-24 04:11:12 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-24 04:11:12 --> Parser Class Initialized
INFO - 2023-09-24 04:11:12 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-24 04:11:12 --> Pagination Class Initialized
INFO - 2023-09-24 04:11:12 --> Form Validation Class Initialized
INFO - 2023-09-24 04:11:12 --> Controller Class Initialized
INFO - 2023-09-24 04:11:12 --> Model Class Initialized
DEBUG - 2023-09-24 04:11:12 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-09-24 04:11:12 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-24 04:11:12 --> Model Class Initialized
DEBUG - 2023-09-24 04:11:12 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-24 04:11:12 --> Model Class Initialized
INFO - 2023-09-24 04:11:12 --> Final output sent to browser
DEBUG - 2023-09-24 04:11:12 --> Total execution time: 0.0639
ERROR - 2023-09-24 04:11:12 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-24 04:11:12 --> Config Class Initialized
INFO - 2023-09-24 04:11:12 --> Hooks Class Initialized
DEBUG - 2023-09-24 04:11:12 --> UTF-8 Support Enabled
INFO - 2023-09-24 04:11:12 --> Utf8 Class Initialized
INFO - 2023-09-24 04:11:12 --> URI Class Initialized
INFO - 2023-09-24 04:11:12 --> Router Class Initialized
INFO - 2023-09-24 04:11:12 --> Output Class Initialized
INFO - 2023-09-24 04:11:12 --> Security Class Initialized
DEBUG - 2023-09-24 04:11:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-24 04:11:12 --> Input Class Initialized
INFO - 2023-09-24 04:11:12 --> Language Class Initialized
INFO - 2023-09-24 04:11:12 --> Loader Class Initialized
INFO - 2023-09-24 04:11:12 --> Helper loaded: url_helper
INFO - 2023-09-24 04:11:12 --> Helper loaded: file_helper
INFO - 2023-09-24 04:11:12 --> Helper loaded: html_helper
INFO - 2023-09-24 04:11:12 --> Helper loaded: text_helper
INFO - 2023-09-24 04:11:12 --> Helper loaded: form_helper
INFO - 2023-09-24 04:11:12 --> Helper loaded: lang_helper
INFO - 2023-09-24 04:11:12 --> Helper loaded: security_helper
INFO - 2023-09-24 04:11:12 --> Helper loaded: cookie_helper
INFO - 2023-09-24 04:11:12 --> Database Driver Class Initialized
INFO - 2023-09-24 04:11:12 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-24 04:11:12 --> Parser Class Initialized
INFO - 2023-09-24 04:11:12 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-24 04:11:12 --> Pagination Class Initialized
INFO - 2023-09-24 04:11:12 --> Form Validation Class Initialized
INFO - 2023-09-24 04:11:12 --> Controller Class Initialized
INFO - 2023-09-24 04:11:12 --> Model Class Initialized
DEBUG - 2023-09-24 04:11:12 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-09-24 04:11:12 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-24 04:11:12 --> Model Class Initialized
DEBUG - 2023-09-24 04:11:12 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-24 04:11:12 --> Model Class Initialized
INFO - 2023-09-24 04:11:12 --> Final output sent to browser
DEBUG - 2023-09-24 04:11:12 --> Total execution time: 0.0810
ERROR - 2023-09-24 04:11:12 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-24 04:11:12 --> Config Class Initialized
INFO - 2023-09-24 04:11:12 --> Hooks Class Initialized
DEBUG - 2023-09-24 04:11:12 --> UTF-8 Support Enabled
INFO - 2023-09-24 04:11:12 --> Utf8 Class Initialized
INFO - 2023-09-24 04:11:12 --> URI Class Initialized
INFO - 2023-09-24 04:11:12 --> Router Class Initialized
INFO - 2023-09-24 04:11:12 --> Output Class Initialized
INFO - 2023-09-24 04:11:12 --> Security Class Initialized
DEBUG - 2023-09-24 04:11:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-24 04:11:12 --> Input Class Initialized
INFO - 2023-09-24 04:11:12 --> Language Class Initialized
INFO - 2023-09-24 04:11:12 --> Loader Class Initialized
INFO - 2023-09-24 04:11:12 --> Helper loaded: url_helper
INFO - 2023-09-24 04:11:12 --> Helper loaded: file_helper
INFO - 2023-09-24 04:11:12 --> Helper loaded: html_helper
INFO - 2023-09-24 04:11:12 --> Helper loaded: text_helper
INFO - 2023-09-24 04:11:12 --> Helper loaded: form_helper
INFO - 2023-09-24 04:11:12 --> Helper loaded: lang_helper
INFO - 2023-09-24 04:11:12 --> Helper loaded: security_helper
INFO - 2023-09-24 04:11:12 --> Helper loaded: cookie_helper
INFO - 2023-09-24 04:11:12 --> Database Driver Class Initialized
INFO - 2023-09-24 04:11:12 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-24 04:11:12 --> Parser Class Initialized
INFO - 2023-09-24 04:11:12 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-24 04:11:12 --> Pagination Class Initialized
INFO - 2023-09-24 04:11:13 --> Form Validation Class Initialized
INFO - 2023-09-24 04:11:13 --> Controller Class Initialized
INFO - 2023-09-24 04:11:13 --> Model Class Initialized
DEBUG - 2023-09-24 04:11:13 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-09-24 04:11:13 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-24 04:11:13 --> Model Class Initialized
DEBUG - 2023-09-24 04:11:13 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-24 04:11:13 --> Model Class Initialized
INFO - 2023-09-24 04:11:13 --> Final output sent to browser
DEBUG - 2023-09-24 04:11:13 --> Total execution time: 0.0807
ERROR - 2023-09-24 04:11:14 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-24 04:11:14 --> Config Class Initialized
INFO - 2023-09-24 04:11:14 --> Hooks Class Initialized
DEBUG - 2023-09-24 04:11:14 --> UTF-8 Support Enabled
INFO - 2023-09-24 04:11:14 --> Utf8 Class Initialized
INFO - 2023-09-24 04:11:14 --> URI Class Initialized
INFO - 2023-09-24 04:11:14 --> Router Class Initialized
INFO - 2023-09-24 04:11:14 --> Output Class Initialized
INFO - 2023-09-24 04:11:14 --> Security Class Initialized
DEBUG - 2023-09-24 04:11:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-24 04:11:14 --> Input Class Initialized
INFO - 2023-09-24 04:11:14 --> Language Class Initialized
INFO - 2023-09-24 04:11:14 --> Loader Class Initialized
INFO - 2023-09-24 04:11:14 --> Helper loaded: url_helper
INFO - 2023-09-24 04:11:14 --> Helper loaded: file_helper
INFO - 2023-09-24 04:11:14 --> Helper loaded: html_helper
INFO - 2023-09-24 04:11:14 --> Helper loaded: text_helper
INFO - 2023-09-24 04:11:14 --> Helper loaded: form_helper
INFO - 2023-09-24 04:11:14 --> Helper loaded: lang_helper
INFO - 2023-09-24 04:11:14 --> Helper loaded: security_helper
INFO - 2023-09-24 04:11:14 --> Helper loaded: cookie_helper
INFO - 2023-09-24 04:11:14 --> Database Driver Class Initialized
INFO - 2023-09-24 04:11:14 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-24 04:11:14 --> Parser Class Initialized
INFO - 2023-09-24 04:11:14 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-24 04:11:14 --> Pagination Class Initialized
INFO - 2023-09-24 04:11:14 --> Form Validation Class Initialized
INFO - 2023-09-24 04:11:14 --> Controller Class Initialized
INFO - 2023-09-24 04:11:14 --> Model Class Initialized
DEBUG - 2023-09-24 04:11:14 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-09-24 04:11:14 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-24 04:11:14 --> Model Class Initialized
DEBUG - 2023-09-24 04:11:14 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-24 04:11:14 --> Model Class Initialized
INFO - 2023-09-24 04:11:14 --> Final output sent to browser
DEBUG - 2023-09-24 04:11:14 --> Total execution time: 0.0716
ERROR - 2023-09-24 04:11:14 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-24 04:11:14 --> Config Class Initialized
INFO - 2023-09-24 04:11:14 --> Hooks Class Initialized
DEBUG - 2023-09-24 04:11:14 --> UTF-8 Support Enabled
INFO - 2023-09-24 04:11:14 --> Utf8 Class Initialized
INFO - 2023-09-24 04:11:14 --> URI Class Initialized
INFO - 2023-09-24 04:11:14 --> Router Class Initialized
INFO - 2023-09-24 04:11:14 --> Output Class Initialized
INFO - 2023-09-24 04:11:14 --> Security Class Initialized
DEBUG - 2023-09-24 04:11:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-24 04:11:14 --> Input Class Initialized
INFO - 2023-09-24 04:11:14 --> Language Class Initialized
INFO - 2023-09-24 04:11:14 --> Loader Class Initialized
INFO - 2023-09-24 04:11:14 --> Helper loaded: url_helper
INFO - 2023-09-24 04:11:14 --> Helper loaded: file_helper
INFO - 2023-09-24 04:11:14 --> Helper loaded: html_helper
INFO - 2023-09-24 04:11:14 --> Helper loaded: text_helper
INFO - 2023-09-24 04:11:14 --> Helper loaded: form_helper
INFO - 2023-09-24 04:11:14 --> Helper loaded: lang_helper
INFO - 2023-09-24 04:11:14 --> Helper loaded: security_helper
INFO - 2023-09-24 04:11:14 --> Helper loaded: cookie_helper
INFO - 2023-09-24 04:11:14 --> Database Driver Class Initialized
INFO - 2023-09-24 04:11:14 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-24 04:11:14 --> Parser Class Initialized
INFO - 2023-09-24 04:11:14 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-24 04:11:14 --> Pagination Class Initialized
INFO - 2023-09-24 04:11:14 --> Form Validation Class Initialized
INFO - 2023-09-24 04:11:14 --> Controller Class Initialized
INFO - 2023-09-24 04:11:14 --> Model Class Initialized
DEBUG - 2023-09-24 04:11:14 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-09-24 04:11:14 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-24 04:11:14 --> Model Class Initialized
DEBUG - 2023-09-24 04:11:14 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-24 04:11:14 --> Model Class Initialized
INFO - 2023-09-24 04:11:15 --> Final output sent to browser
DEBUG - 2023-09-24 04:11:15 --> Total execution time: 0.0633
ERROR - 2023-09-24 04:11:15 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-24 04:11:15 --> Config Class Initialized
INFO - 2023-09-24 04:11:15 --> Hooks Class Initialized
DEBUG - 2023-09-24 04:11:15 --> UTF-8 Support Enabled
INFO - 2023-09-24 04:11:15 --> Utf8 Class Initialized
INFO - 2023-09-24 04:11:15 --> URI Class Initialized
INFO - 2023-09-24 04:11:15 --> Router Class Initialized
INFO - 2023-09-24 04:11:15 --> Output Class Initialized
INFO - 2023-09-24 04:11:15 --> Security Class Initialized
DEBUG - 2023-09-24 04:11:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-24 04:11:15 --> Input Class Initialized
INFO - 2023-09-24 04:11:15 --> Language Class Initialized
INFO - 2023-09-24 04:11:15 --> Loader Class Initialized
INFO - 2023-09-24 04:11:15 --> Helper loaded: url_helper
INFO - 2023-09-24 04:11:15 --> Helper loaded: file_helper
INFO - 2023-09-24 04:11:15 --> Helper loaded: html_helper
INFO - 2023-09-24 04:11:15 --> Helper loaded: text_helper
INFO - 2023-09-24 04:11:15 --> Helper loaded: form_helper
INFO - 2023-09-24 04:11:15 --> Helper loaded: lang_helper
INFO - 2023-09-24 04:11:15 --> Helper loaded: security_helper
INFO - 2023-09-24 04:11:15 --> Helper loaded: cookie_helper
INFO - 2023-09-24 04:11:15 --> Database Driver Class Initialized
INFO - 2023-09-24 04:11:15 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-24 04:11:15 --> Parser Class Initialized
INFO - 2023-09-24 04:11:15 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-24 04:11:15 --> Pagination Class Initialized
INFO - 2023-09-24 04:11:15 --> Form Validation Class Initialized
INFO - 2023-09-24 04:11:15 --> Controller Class Initialized
INFO - 2023-09-24 04:11:15 --> Model Class Initialized
DEBUG - 2023-09-24 04:11:15 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-09-24 04:11:15 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-24 04:11:15 --> Model Class Initialized
DEBUG - 2023-09-24 04:11:15 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-24 04:11:15 --> Model Class Initialized
INFO - 2023-09-24 04:11:15 --> Final output sent to browser
DEBUG - 2023-09-24 04:11:15 --> Total execution time: 0.0714
ERROR - 2023-09-24 04:11:15 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-24 04:11:15 --> Config Class Initialized
INFO - 2023-09-24 04:11:15 --> Hooks Class Initialized
DEBUG - 2023-09-24 04:11:15 --> UTF-8 Support Enabled
INFO - 2023-09-24 04:11:15 --> Utf8 Class Initialized
INFO - 2023-09-24 04:11:15 --> URI Class Initialized
INFO - 2023-09-24 04:11:15 --> Router Class Initialized
INFO - 2023-09-24 04:11:15 --> Output Class Initialized
INFO - 2023-09-24 04:11:15 --> Security Class Initialized
DEBUG - 2023-09-24 04:11:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-24 04:11:15 --> Input Class Initialized
INFO - 2023-09-24 04:11:15 --> Language Class Initialized
INFO - 2023-09-24 04:11:15 --> Loader Class Initialized
INFO - 2023-09-24 04:11:15 --> Helper loaded: url_helper
INFO - 2023-09-24 04:11:15 --> Helper loaded: file_helper
INFO - 2023-09-24 04:11:15 --> Helper loaded: html_helper
INFO - 2023-09-24 04:11:15 --> Helper loaded: text_helper
INFO - 2023-09-24 04:11:15 --> Helper loaded: form_helper
INFO - 2023-09-24 04:11:15 --> Helper loaded: lang_helper
INFO - 2023-09-24 04:11:15 --> Helper loaded: security_helper
INFO - 2023-09-24 04:11:15 --> Helper loaded: cookie_helper
INFO - 2023-09-24 04:11:15 --> Database Driver Class Initialized
INFO - 2023-09-24 04:11:15 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-24 04:11:15 --> Parser Class Initialized
INFO - 2023-09-24 04:11:15 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-24 04:11:15 --> Pagination Class Initialized
INFO - 2023-09-24 04:11:15 --> Form Validation Class Initialized
INFO - 2023-09-24 04:11:15 --> Controller Class Initialized
INFO - 2023-09-24 04:11:15 --> Model Class Initialized
DEBUG - 2023-09-24 04:11:15 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-09-24 04:11:15 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-24 04:11:15 --> Model Class Initialized
DEBUG - 2023-09-24 04:11:15 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-24 04:11:15 --> Model Class Initialized
INFO - 2023-09-24 04:11:15 --> Final output sent to browser
DEBUG - 2023-09-24 04:11:15 --> Total execution time: 0.0714
ERROR - 2023-09-24 04:11:17 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-24 04:11:17 --> Config Class Initialized
INFO - 2023-09-24 04:11:17 --> Hooks Class Initialized
DEBUG - 2023-09-24 04:11:17 --> UTF-8 Support Enabled
INFO - 2023-09-24 04:11:17 --> Utf8 Class Initialized
INFO - 2023-09-24 04:11:17 --> URI Class Initialized
INFO - 2023-09-24 04:11:17 --> Router Class Initialized
INFO - 2023-09-24 04:11:17 --> Output Class Initialized
INFO - 2023-09-24 04:11:17 --> Security Class Initialized
DEBUG - 2023-09-24 04:11:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-24 04:11:17 --> Input Class Initialized
INFO - 2023-09-24 04:11:17 --> Language Class Initialized
INFO - 2023-09-24 04:11:17 --> Loader Class Initialized
INFO - 2023-09-24 04:11:17 --> Helper loaded: url_helper
INFO - 2023-09-24 04:11:17 --> Helper loaded: file_helper
INFO - 2023-09-24 04:11:17 --> Helper loaded: html_helper
INFO - 2023-09-24 04:11:17 --> Helper loaded: text_helper
INFO - 2023-09-24 04:11:17 --> Helper loaded: form_helper
INFO - 2023-09-24 04:11:17 --> Helper loaded: lang_helper
INFO - 2023-09-24 04:11:17 --> Helper loaded: security_helper
INFO - 2023-09-24 04:11:17 --> Helper loaded: cookie_helper
INFO - 2023-09-24 04:11:17 --> Database Driver Class Initialized
INFO - 2023-09-24 04:11:17 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-24 04:11:17 --> Parser Class Initialized
INFO - 2023-09-24 04:11:17 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-24 04:11:17 --> Pagination Class Initialized
INFO - 2023-09-24 04:11:17 --> Form Validation Class Initialized
INFO - 2023-09-24 04:11:17 --> Controller Class Initialized
INFO - 2023-09-24 04:11:17 --> Model Class Initialized
DEBUG - 2023-09-24 04:11:17 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-09-24 04:11:17 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-24 04:11:17 --> Model Class Initialized
DEBUG - 2023-09-24 04:11:17 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-24 04:11:17 --> Model Class Initialized
INFO - 2023-09-24 04:11:17 --> Final output sent to browser
DEBUG - 2023-09-24 04:11:17 --> Total execution time: 0.0198
ERROR - 2023-09-24 04:11:20 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-24 04:11:20 --> Config Class Initialized
INFO - 2023-09-24 04:11:20 --> Hooks Class Initialized
DEBUG - 2023-09-24 04:11:20 --> UTF-8 Support Enabled
INFO - 2023-09-24 04:11:20 --> Utf8 Class Initialized
INFO - 2023-09-24 04:11:20 --> URI Class Initialized
INFO - 2023-09-24 04:11:20 --> Router Class Initialized
INFO - 2023-09-24 04:11:20 --> Output Class Initialized
INFO - 2023-09-24 04:11:20 --> Security Class Initialized
DEBUG - 2023-09-24 04:11:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-24 04:11:20 --> Input Class Initialized
INFO - 2023-09-24 04:11:20 --> Language Class Initialized
INFO - 2023-09-24 04:11:20 --> Loader Class Initialized
INFO - 2023-09-24 04:11:20 --> Helper loaded: url_helper
INFO - 2023-09-24 04:11:20 --> Helper loaded: file_helper
INFO - 2023-09-24 04:11:20 --> Helper loaded: html_helper
INFO - 2023-09-24 04:11:20 --> Helper loaded: text_helper
INFO - 2023-09-24 04:11:20 --> Helper loaded: form_helper
INFO - 2023-09-24 04:11:20 --> Helper loaded: lang_helper
INFO - 2023-09-24 04:11:20 --> Helper loaded: security_helper
INFO - 2023-09-24 04:11:20 --> Helper loaded: cookie_helper
INFO - 2023-09-24 04:11:20 --> Database Driver Class Initialized
INFO - 2023-09-24 04:11:20 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-24 04:11:20 --> Parser Class Initialized
INFO - 2023-09-24 04:11:20 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-24 04:11:20 --> Pagination Class Initialized
INFO - 2023-09-24 04:11:20 --> Form Validation Class Initialized
INFO - 2023-09-24 04:11:20 --> Controller Class Initialized
INFO - 2023-09-24 04:11:20 --> Model Class Initialized
DEBUG - 2023-09-24 04:11:20 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-09-24 04:11:20 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-24 04:11:20 --> Model Class Initialized
DEBUG - 2023-09-24 04:11:20 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-24 04:11:20 --> Model Class Initialized
INFO - 2023-09-24 04:11:20 --> Final output sent to browser
DEBUG - 2023-09-24 04:11:20 --> Total execution time: 0.0715
ERROR - 2023-09-24 04:11:21 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-24 04:11:21 --> Config Class Initialized
INFO - 2023-09-24 04:11:21 --> Hooks Class Initialized
DEBUG - 2023-09-24 04:11:21 --> UTF-8 Support Enabled
INFO - 2023-09-24 04:11:21 --> Utf8 Class Initialized
INFO - 2023-09-24 04:11:21 --> URI Class Initialized
INFO - 2023-09-24 04:11:21 --> Router Class Initialized
INFO - 2023-09-24 04:11:21 --> Output Class Initialized
INFO - 2023-09-24 04:11:21 --> Security Class Initialized
DEBUG - 2023-09-24 04:11:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-24 04:11:21 --> Input Class Initialized
INFO - 2023-09-24 04:11:21 --> Language Class Initialized
INFO - 2023-09-24 04:11:21 --> Loader Class Initialized
INFO - 2023-09-24 04:11:21 --> Helper loaded: url_helper
INFO - 2023-09-24 04:11:21 --> Helper loaded: file_helper
INFO - 2023-09-24 04:11:21 --> Helper loaded: html_helper
INFO - 2023-09-24 04:11:21 --> Helper loaded: text_helper
INFO - 2023-09-24 04:11:21 --> Helper loaded: form_helper
INFO - 2023-09-24 04:11:21 --> Helper loaded: lang_helper
INFO - 2023-09-24 04:11:21 --> Helper loaded: security_helper
INFO - 2023-09-24 04:11:21 --> Helper loaded: cookie_helper
INFO - 2023-09-24 04:11:21 --> Database Driver Class Initialized
INFO - 2023-09-24 04:11:21 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-24 04:11:21 --> Parser Class Initialized
INFO - 2023-09-24 04:11:21 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-24 04:11:21 --> Pagination Class Initialized
INFO - 2023-09-24 04:11:21 --> Form Validation Class Initialized
INFO - 2023-09-24 04:11:21 --> Controller Class Initialized
INFO - 2023-09-24 04:11:21 --> Model Class Initialized
DEBUG - 2023-09-24 04:11:21 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-09-24 04:11:21 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-24 04:11:21 --> Model Class Initialized
DEBUG - 2023-09-24 04:11:21 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-24 04:11:21 --> Model Class Initialized
INFO - 2023-09-24 04:11:21 --> Final output sent to browser
DEBUG - 2023-09-24 04:11:21 --> Total execution time: 0.0642
ERROR - 2023-09-24 04:11:22 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-24 04:11:22 --> Config Class Initialized
INFO - 2023-09-24 04:11:22 --> Hooks Class Initialized
DEBUG - 2023-09-24 04:11:22 --> UTF-8 Support Enabled
INFO - 2023-09-24 04:11:22 --> Utf8 Class Initialized
INFO - 2023-09-24 04:11:22 --> URI Class Initialized
INFO - 2023-09-24 04:11:22 --> Router Class Initialized
INFO - 2023-09-24 04:11:22 --> Output Class Initialized
INFO - 2023-09-24 04:11:22 --> Security Class Initialized
DEBUG - 2023-09-24 04:11:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-24 04:11:22 --> Input Class Initialized
INFO - 2023-09-24 04:11:22 --> Language Class Initialized
INFO - 2023-09-24 04:11:22 --> Loader Class Initialized
INFO - 2023-09-24 04:11:22 --> Helper loaded: url_helper
INFO - 2023-09-24 04:11:22 --> Helper loaded: file_helper
INFO - 2023-09-24 04:11:22 --> Helper loaded: html_helper
INFO - 2023-09-24 04:11:22 --> Helper loaded: text_helper
INFO - 2023-09-24 04:11:22 --> Helper loaded: form_helper
INFO - 2023-09-24 04:11:22 --> Helper loaded: lang_helper
INFO - 2023-09-24 04:11:22 --> Helper loaded: security_helper
INFO - 2023-09-24 04:11:22 --> Helper loaded: cookie_helper
INFO - 2023-09-24 04:11:22 --> Database Driver Class Initialized
INFO - 2023-09-24 04:11:22 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-24 04:11:22 --> Parser Class Initialized
INFO - 2023-09-24 04:11:22 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-24 04:11:22 --> Pagination Class Initialized
INFO - 2023-09-24 04:11:22 --> Form Validation Class Initialized
INFO - 2023-09-24 04:11:22 --> Controller Class Initialized
INFO - 2023-09-24 04:11:22 --> Model Class Initialized
DEBUG - 2023-09-24 04:11:22 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-09-24 04:11:22 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-24 04:11:22 --> Model Class Initialized
DEBUG - 2023-09-24 04:11:22 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-24 04:11:22 --> Model Class Initialized
INFO - 2023-09-24 04:11:22 --> Final output sent to browser
DEBUG - 2023-09-24 04:11:22 --> Total execution time: 0.0654
ERROR - 2023-09-24 04:11:22 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-24 04:11:22 --> Config Class Initialized
INFO - 2023-09-24 04:11:22 --> Hooks Class Initialized
DEBUG - 2023-09-24 04:11:22 --> UTF-8 Support Enabled
INFO - 2023-09-24 04:11:22 --> Utf8 Class Initialized
INFO - 2023-09-24 04:11:22 --> URI Class Initialized
INFO - 2023-09-24 04:11:22 --> Router Class Initialized
INFO - 2023-09-24 04:11:22 --> Output Class Initialized
INFO - 2023-09-24 04:11:22 --> Security Class Initialized
DEBUG - 2023-09-24 04:11:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-24 04:11:22 --> Input Class Initialized
INFO - 2023-09-24 04:11:22 --> Language Class Initialized
INFO - 2023-09-24 04:11:22 --> Loader Class Initialized
INFO - 2023-09-24 04:11:22 --> Helper loaded: url_helper
INFO - 2023-09-24 04:11:22 --> Helper loaded: file_helper
INFO - 2023-09-24 04:11:22 --> Helper loaded: html_helper
INFO - 2023-09-24 04:11:22 --> Helper loaded: text_helper
INFO - 2023-09-24 04:11:22 --> Helper loaded: form_helper
INFO - 2023-09-24 04:11:22 --> Helper loaded: lang_helper
INFO - 2023-09-24 04:11:22 --> Helper loaded: security_helper
INFO - 2023-09-24 04:11:22 --> Helper loaded: cookie_helper
INFO - 2023-09-24 04:11:22 --> Database Driver Class Initialized
INFO - 2023-09-24 04:11:22 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-24 04:11:22 --> Parser Class Initialized
INFO - 2023-09-24 04:11:22 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-24 04:11:22 --> Pagination Class Initialized
INFO - 2023-09-24 04:11:22 --> Form Validation Class Initialized
INFO - 2023-09-24 04:11:22 --> Controller Class Initialized
INFO - 2023-09-24 04:11:22 --> Model Class Initialized
DEBUG - 2023-09-24 04:11:22 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-09-24 04:11:22 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-24 04:11:22 --> Model Class Initialized
DEBUG - 2023-09-24 04:11:22 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-24 04:11:22 --> Model Class Initialized
INFO - 2023-09-24 04:11:22 --> Final output sent to browser
DEBUG - 2023-09-24 04:11:22 --> Total execution time: 0.0737
ERROR - 2023-09-24 04:11:22 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-24 04:11:22 --> Config Class Initialized
INFO - 2023-09-24 04:11:22 --> Hooks Class Initialized
DEBUG - 2023-09-24 04:11:22 --> UTF-8 Support Enabled
INFO - 2023-09-24 04:11:22 --> Utf8 Class Initialized
INFO - 2023-09-24 04:11:22 --> URI Class Initialized
INFO - 2023-09-24 04:11:22 --> Router Class Initialized
INFO - 2023-09-24 04:11:22 --> Output Class Initialized
INFO - 2023-09-24 04:11:22 --> Security Class Initialized
DEBUG - 2023-09-24 04:11:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-24 04:11:22 --> Input Class Initialized
INFO - 2023-09-24 04:11:22 --> Language Class Initialized
INFO - 2023-09-24 04:11:22 --> Loader Class Initialized
INFO - 2023-09-24 04:11:22 --> Helper loaded: url_helper
INFO - 2023-09-24 04:11:22 --> Helper loaded: file_helper
INFO - 2023-09-24 04:11:22 --> Helper loaded: html_helper
INFO - 2023-09-24 04:11:22 --> Helper loaded: text_helper
INFO - 2023-09-24 04:11:22 --> Helper loaded: form_helper
INFO - 2023-09-24 04:11:22 --> Helper loaded: lang_helper
INFO - 2023-09-24 04:11:22 --> Helper loaded: security_helper
INFO - 2023-09-24 04:11:22 --> Helper loaded: cookie_helper
INFO - 2023-09-24 04:11:22 --> Database Driver Class Initialized
INFO - 2023-09-24 04:11:22 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-24 04:11:22 --> Parser Class Initialized
INFO - 2023-09-24 04:11:22 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-24 04:11:22 --> Pagination Class Initialized
INFO - 2023-09-24 04:11:22 --> Form Validation Class Initialized
INFO - 2023-09-24 04:11:22 --> Controller Class Initialized
INFO - 2023-09-24 04:11:22 --> Model Class Initialized
DEBUG - 2023-09-24 04:11:22 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-09-24 04:11:22 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-24 04:11:22 --> Model Class Initialized
DEBUG - 2023-09-24 04:11:22 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-24 04:11:22 --> Model Class Initialized
INFO - 2023-09-24 04:11:23 --> Final output sent to browser
DEBUG - 2023-09-24 04:11:23 --> Total execution time: 0.0717
ERROR - 2023-09-24 04:11:41 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-24 04:11:41 --> Config Class Initialized
INFO - 2023-09-24 04:11:41 --> Hooks Class Initialized
DEBUG - 2023-09-24 04:11:41 --> UTF-8 Support Enabled
INFO - 2023-09-24 04:11:41 --> Utf8 Class Initialized
INFO - 2023-09-24 04:11:41 --> URI Class Initialized
INFO - 2023-09-24 04:11:41 --> Router Class Initialized
INFO - 2023-09-24 04:11:41 --> Output Class Initialized
INFO - 2023-09-24 04:11:41 --> Security Class Initialized
DEBUG - 2023-09-24 04:11:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-24 04:11:41 --> Input Class Initialized
INFO - 2023-09-24 04:11:41 --> Language Class Initialized
INFO - 2023-09-24 04:11:41 --> Loader Class Initialized
INFO - 2023-09-24 04:11:41 --> Helper loaded: url_helper
INFO - 2023-09-24 04:11:41 --> Helper loaded: file_helper
INFO - 2023-09-24 04:11:41 --> Helper loaded: html_helper
INFO - 2023-09-24 04:11:41 --> Helper loaded: text_helper
INFO - 2023-09-24 04:11:41 --> Helper loaded: form_helper
INFO - 2023-09-24 04:11:41 --> Helper loaded: lang_helper
INFO - 2023-09-24 04:11:41 --> Helper loaded: security_helper
INFO - 2023-09-24 04:11:41 --> Helper loaded: cookie_helper
INFO - 2023-09-24 04:11:41 --> Database Driver Class Initialized
INFO - 2023-09-24 04:11:41 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-24 04:11:41 --> Parser Class Initialized
INFO - 2023-09-24 04:11:41 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-24 04:11:41 --> Pagination Class Initialized
INFO - 2023-09-24 04:11:41 --> Form Validation Class Initialized
INFO - 2023-09-24 04:11:41 --> Controller Class Initialized
INFO - 2023-09-24 04:11:41 --> Model Class Initialized
DEBUG - 2023-09-24 04:11:41 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-09-24 04:11:41 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-24 04:11:41 --> Model Class Initialized
DEBUG - 2023-09-24 04:11:41 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-24 04:11:41 --> Model Class Initialized
INFO - 2023-09-24 04:11:41 --> Final output sent to browser
DEBUG - 2023-09-24 04:11:41 --> Total execution time: 0.0222
ERROR - 2023-09-24 04:11:42 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-24 04:11:42 --> Config Class Initialized
INFO - 2023-09-24 04:11:42 --> Hooks Class Initialized
DEBUG - 2023-09-24 04:11:42 --> UTF-8 Support Enabled
INFO - 2023-09-24 04:11:42 --> Utf8 Class Initialized
INFO - 2023-09-24 04:11:42 --> URI Class Initialized
INFO - 2023-09-24 04:11:42 --> Router Class Initialized
INFO - 2023-09-24 04:11:42 --> Output Class Initialized
INFO - 2023-09-24 04:11:42 --> Security Class Initialized
DEBUG - 2023-09-24 04:11:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-24 04:11:42 --> Input Class Initialized
INFO - 2023-09-24 04:11:42 --> Language Class Initialized
INFO - 2023-09-24 04:11:42 --> Loader Class Initialized
INFO - 2023-09-24 04:11:42 --> Helper loaded: url_helper
INFO - 2023-09-24 04:11:42 --> Helper loaded: file_helper
INFO - 2023-09-24 04:11:42 --> Helper loaded: html_helper
INFO - 2023-09-24 04:11:42 --> Helper loaded: text_helper
INFO - 2023-09-24 04:11:42 --> Helper loaded: form_helper
INFO - 2023-09-24 04:11:42 --> Helper loaded: lang_helper
INFO - 2023-09-24 04:11:42 --> Helper loaded: security_helper
INFO - 2023-09-24 04:11:42 --> Helper loaded: cookie_helper
INFO - 2023-09-24 04:11:42 --> Database Driver Class Initialized
INFO - 2023-09-24 04:11:42 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-24 04:11:42 --> Parser Class Initialized
INFO - 2023-09-24 04:11:42 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-24 04:11:42 --> Pagination Class Initialized
INFO - 2023-09-24 04:11:42 --> Form Validation Class Initialized
INFO - 2023-09-24 04:11:42 --> Controller Class Initialized
INFO - 2023-09-24 04:11:42 --> Model Class Initialized
DEBUG - 2023-09-24 04:11:42 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-09-24 04:11:42 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-24 04:11:42 --> Model Class Initialized
DEBUG - 2023-09-24 04:11:42 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-24 04:11:42 --> Model Class Initialized
INFO - 2023-09-24 04:11:42 --> Final output sent to browser
DEBUG - 2023-09-24 04:11:42 --> Total execution time: 0.0231
ERROR - 2023-09-24 04:11:44 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-24 04:11:44 --> Config Class Initialized
INFO - 2023-09-24 04:11:44 --> Hooks Class Initialized
DEBUG - 2023-09-24 04:11:44 --> UTF-8 Support Enabled
INFO - 2023-09-24 04:11:44 --> Utf8 Class Initialized
INFO - 2023-09-24 04:11:44 --> URI Class Initialized
INFO - 2023-09-24 04:11:44 --> Router Class Initialized
INFO - 2023-09-24 04:11:44 --> Output Class Initialized
INFO - 2023-09-24 04:11:44 --> Security Class Initialized
DEBUG - 2023-09-24 04:11:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-24 04:11:44 --> Input Class Initialized
INFO - 2023-09-24 04:11:44 --> Language Class Initialized
INFO - 2023-09-24 04:11:44 --> Loader Class Initialized
INFO - 2023-09-24 04:11:44 --> Helper loaded: url_helper
INFO - 2023-09-24 04:11:44 --> Helper loaded: file_helper
INFO - 2023-09-24 04:11:44 --> Helper loaded: html_helper
INFO - 2023-09-24 04:11:44 --> Helper loaded: text_helper
INFO - 2023-09-24 04:11:44 --> Helper loaded: form_helper
INFO - 2023-09-24 04:11:44 --> Helper loaded: lang_helper
INFO - 2023-09-24 04:11:44 --> Helper loaded: security_helper
INFO - 2023-09-24 04:11:44 --> Helper loaded: cookie_helper
INFO - 2023-09-24 04:11:44 --> Database Driver Class Initialized
INFO - 2023-09-24 04:11:44 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-24 04:11:44 --> Parser Class Initialized
INFO - 2023-09-24 04:11:44 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-24 04:11:44 --> Pagination Class Initialized
INFO - 2023-09-24 04:11:44 --> Form Validation Class Initialized
INFO - 2023-09-24 04:11:44 --> Controller Class Initialized
INFO - 2023-09-24 04:11:44 --> Model Class Initialized
DEBUG - 2023-09-24 04:11:44 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-09-24 04:11:44 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-24 04:11:44 --> Model Class Initialized
DEBUG - 2023-09-24 04:11:44 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-24 04:11:44 --> Model Class Initialized
INFO - 2023-09-24 04:11:44 --> Final output sent to browser
DEBUG - 2023-09-24 04:11:44 --> Total execution time: 0.0257
ERROR - 2023-09-24 04:11:45 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-24 04:11:45 --> Config Class Initialized
INFO - 2023-09-24 04:11:45 --> Hooks Class Initialized
DEBUG - 2023-09-24 04:11:45 --> UTF-8 Support Enabled
INFO - 2023-09-24 04:11:45 --> Utf8 Class Initialized
INFO - 2023-09-24 04:11:45 --> URI Class Initialized
INFO - 2023-09-24 04:11:45 --> Router Class Initialized
INFO - 2023-09-24 04:11:45 --> Output Class Initialized
INFO - 2023-09-24 04:11:45 --> Security Class Initialized
DEBUG - 2023-09-24 04:11:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-24 04:11:45 --> Input Class Initialized
INFO - 2023-09-24 04:11:45 --> Language Class Initialized
INFO - 2023-09-24 04:11:45 --> Loader Class Initialized
INFO - 2023-09-24 04:11:45 --> Helper loaded: url_helper
INFO - 2023-09-24 04:11:45 --> Helper loaded: file_helper
INFO - 2023-09-24 04:11:45 --> Helper loaded: html_helper
INFO - 2023-09-24 04:11:45 --> Helper loaded: text_helper
INFO - 2023-09-24 04:11:45 --> Helper loaded: form_helper
INFO - 2023-09-24 04:11:45 --> Helper loaded: lang_helper
INFO - 2023-09-24 04:11:45 --> Helper loaded: security_helper
INFO - 2023-09-24 04:11:45 --> Helper loaded: cookie_helper
INFO - 2023-09-24 04:11:45 --> Database Driver Class Initialized
INFO - 2023-09-24 04:11:45 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-24 04:11:45 --> Parser Class Initialized
INFO - 2023-09-24 04:11:45 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-24 04:11:45 --> Pagination Class Initialized
INFO - 2023-09-24 04:11:45 --> Form Validation Class Initialized
INFO - 2023-09-24 04:11:45 --> Controller Class Initialized
INFO - 2023-09-24 04:11:45 --> Model Class Initialized
DEBUG - 2023-09-24 04:11:45 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-09-24 04:11:45 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-24 04:11:45 --> Model Class Initialized
DEBUG - 2023-09-24 04:11:45 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-24 04:11:45 --> Model Class Initialized
INFO - 2023-09-24 04:11:45 --> Final output sent to browser
DEBUG - 2023-09-24 04:11:45 --> Total execution time: 0.0257
ERROR - 2023-09-24 04:11:45 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-24 04:11:45 --> Config Class Initialized
INFO - 2023-09-24 04:11:45 --> Hooks Class Initialized
DEBUG - 2023-09-24 04:11:45 --> UTF-8 Support Enabled
INFO - 2023-09-24 04:11:45 --> Utf8 Class Initialized
INFO - 2023-09-24 04:11:45 --> URI Class Initialized
INFO - 2023-09-24 04:11:45 --> Router Class Initialized
INFO - 2023-09-24 04:11:45 --> Output Class Initialized
INFO - 2023-09-24 04:11:45 --> Security Class Initialized
DEBUG - 2023-09-24 04:11:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-24 04:11:45 --> Input Class Initialized
INFO - 2023-09-24 04:11:45 --> Language Class Initialized
INFO - 2023-09-24 04:11:45 --> Loader Class Initialized
INFO - 2023-09-24 04:11:45 --> Helper loaded: url_helper
INFO - 2023-09-24 04:11:45 --> Helper loaded: file_helper
INFO - 2023-09-24 04:11:45 --> Helper loaded: html_helper
INFO - 2023-09-24 04:11:45 --> Helper loaded: text_helper
INFO - 2023-09-24 04:11:45 --> Helper loaded: form_helper
INFO - 2023-09-24 04:11:45 --> Helper loaded: lang_helper
INFO - 2023-09-24 04:11:45 --> Helper loaded: security_helper
INFO - 2023-09-24 04:11:45 --> Helper loaded: cookie_helper
INFO - 2023-09-24 04:11:45 --> Database Driver Class Initialized
INFO - 2023-09-24 04:11:45 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-24 04:11:45 --> Parser Class Initialized
INFO - 2023-09-24 04:11:45 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-24 04:11:45 --> Pagination Class Initialized
INFO - 2023-09-24 04:11:45 --> Form Validation Class Initialized
INFO - 2023-09-24 04:11:45 --> Controller Class Initialized
INFO - 2023-09-24 04:11:45 --> Model Class Initialized
DEBUG - 2023-09-24 04:11:45 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-09-24 04:11:45 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-24 04:11:45 --> Model Class Initialized
DEBUG - 2023-09-24 04:11:45 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-24 04:11:45 --> Model Class Initialized
INFO - 2023-09-24 04:11:45 --> Final output sent to browser
DEBUG - 2023-09-24 04:11:45 --> Total execution time: 0.0313
ERROR - 2023-09-24 04:11:46 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-24 04:11:46 --> Config Class Initialized
INFO - 2023-09-24 04:11:46 --> Hooks Class Initialized
DEBUG - 2023-09-24 04:11:46 --> UTF-8 Support Enabled
INFO - 2023-09-24 04:11:46 --> Utf8 Class Initialized
INFO - 2023-09-24 04:11:46 --> URI Class Initialized
INFO - 2023-09-24 04:11:46 --> Router Class Initialized
INFO - 2023-09-24 04:11:46 --> Output Class Initialized
INFO - 2023-09-24 04:11:46 --> Security Class Initialized
DEBUG - 2023-09-24 04:11:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-24 04:11:46 --> Input Class Initialized
INFO - 2023-09-24 04:11:46 --> Language Class Initialized
INFO - 2023-09-24 04:11:46 --> Loader Class Initialized
INFO - 2023-09-24 04:11:46 --> Helper loaded: url_helper
INFO - 2023-09-24 04:11:46 --> Helper loaded: file_helper
INFO - 2023-09-24 04:11:46 --> Helper loaded: html_helper
INFO - 2023-09-24 04:11:46 --> Helper loaded: text_helper
INFO - 2023-09-24 04:11:46 --> Helper loaded: form_helper
INFO - 2023-09-24 04:11:46 --> Helper loaded: lang_helper
INFO - 2023-09-24 04:11:46 --> Helper loaded: security_helper
INFO - 2023-09-24 04:11:46 --> Helper loaded: cookie_helper
INFO - 2023-09-24 04:11:46 --> Database Driver Class Initialized
INFO - 2023-09-24 04:11:46 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-24 04:11:46 --> Parser Class Initialized
INFO - 2023-09-24 04:11:46 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-24 04:11:46 --> Pagination Class Initialized
INFO - 2023-09-24 04:11:46 --> Form Validation Class Initialized
INFO - 2023-09-24 04:11:46 --> Controller Class Initialized
INFO - 2023-09-24 04:11:46 --> Model Class Initialized
DEBUG - 2023-09-24 04:11:46 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-09-24 04:11:46 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-24 04:11:46 --> Model Class Initialized
DEBUG - 2023-09-24 04:11:46 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-24 04:11:46 --> Model Class Initialized
INFO - 2023-09-24 04:11:46 --> Final output sent to browser
DEBUG - 2023-09-24 04:11:46 --> Total execution time: 0.0683
ERROR - 2023-09-24 04:11:47 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-24 04:11:47 --> Config Class Initialized
INFO - 2023-09-24 04:11:47 --> Hooks Class Initialized
DEBUG - 2023-09-24 04:11:47 --> UTF-8 Support Enabled
INFO - 2023-09-24 04:11:47 --> Utf8 Class Initialized
INFO - 2023-09-24 04:11:47 --> URI Class Initialized
INFO - 2023-09-24 04:11:47 --> Router Class Initialized
INFO - 2023-09-24 04:11:47 --> Output Class Initialized
INFO - 2023-09-24 04:11:47 --> Security Class Initialized
DEBUG - 2023-09-24 04:11:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-24 04:11:47 --> Input Class Initialized
INFO - 2023-09-24 04:11:47 --> Language Class Initialized
INFO - 2023-09-24 04:11:47 --> Loader Class Initialized
INFO - 2023-09-24 04:11:47 --> Helper loaded: url_helper
INFO - 2023-09-24 04:11:47 --> Helper loaded: file_helper
INFO - 2023-09-24 04:11:47 --> Helper loaded: html_helper
INFO - 2023-09-24 04:11:47 --> Helper loaded: text_helper
INFO - 2023-09-24 04:11:47 --> Helper loaded: form_helper
INFO - 2023-09-24 04:11:47 --> Helper loaded: lang_helper
INFO - 2023-09-24 04:11:47 --> Helper loaded: security_helper
INFO - 2023-09-24 04:11:47 --> Helper loaded: cookie_helper
INFO - 2023-09-24 04:11:47 --> Database Driver Class Initialized
INFO - 2023-09-24 04:11:47 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-24 04:11:47 --> Parser Class Initialized
INFO - 2023-09-24 04:11:47 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-24 04:11:47 --> Pagination Class Initialized
INFO - 2023-09-24 04:11:47 --> Form Validation Class Initialized
INFO - 2023-09-24 04:11:47 --> Controller Class Initialized
INFO - 2023-09-24 04:11:47 --> Model Class Initialized
DEBUG - 2023-09-24 04:11:47 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-09-24 04:11:47 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-24 04:11:47 --> Model Class Initialized
DEBUG - 2023-09-24 04:11:47 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-24 04:11:47 --> Model Class Initialized
INFO - 2023-09-24 04:11:47 --> Final output sent to browser
DEBUG - 2023-09-24 04:11:47 --> Total execution time: 0.0203
ERROR - 2023-09-24 04:11:51 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-24 04:11:51 --> Config Class Initialized
INFO - 2023-09-24 04:11:51 --> Hooks Class Initialized
DEBUG - 2023-09-24 04:11:51 --> UTF-8 Support Enabled
INFO - 2023-09-24 04:11:51 --> Utf8 Class Initialized
INFO - 2023-09-24 04:11:51 --> URI Class Initialized
INFO - 2023-09-24 04:11:51 --> Router Class Initialized
INFO - 2023-09-24 04:11:51 --> Output Class Initialized
INFO - 2023-09-24 04:11:51 --> Security Class Initialized
DEBUG - 2023-09-24 04:11:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-24 04:11:51 --> Input Class Initialized
INFO - 2023-09-24 04:11:51 --> Language Class Initialized
INFO - 2023-09-24 04:11:51 --> Loader Class Initialized
INFO - 2023-09-24 04:11:51 --> Helper loaded: url_helper
INFO - 2023-09-24 04:11:51 --> Helper loaded: file_helper
INFO - 2023-09-24 04:11:51 --> Helper loaded: html_helper
INFO - 2023-09-24 04:11:51 --> Helper loaded: text_helper
INFO - 2023-09-24 04:11:51 --> Helper loaded: form_helper
INFO - 2023-09-24 04:11:51 --> Helper loaded: lang_helper
INFO - 2023-09-24 04:11:51 --> Helper loaded: security_helper
INFO - 2023-09-24 04:11:51 --> Helper loaded: cookie_helper
INFO - 2023-09-24 04:11:51 --> Database Driver Class Initialized
INFO - 2023-09-24 04:11:51 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-24 04:11:51 --> Parser Class Initialized
INFO - 2023-09-24 04:11:51 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-24 04:11:51 --> Pagination Class Initialized
INFO - 2023-09-24 04:11:51 --> Form Validation Class Initialized
INFO - 2023-09-24 04:11:51 --> Controller Class Initialized
INFO - 2023-09-24 04:11:51 --> Model Class Initialized
DEBUG - 2023-09-24 04:11:51 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-09-24 04:11:51 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-24 04:11:51 --> Model Class Initialized
DEBUG - 2023-09-24 04:11:51 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-24 04:11:51 --> Model Class Initialized
INFO - 2023-09-24 04:11:51 --> Final output sent to browser
DEBUG - 2023-09-24 04:11:51 --> Total execution time: 0.0743
ERROR - 2023-09-24 04:11:52 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-24 04:11:52 --> Config Class Initialized
INFO - 2023-09-24 04:11:52 --> Hooks Class Initialized
DEBUG - 2023-09-24 04:11:52 --> UTF-8 Support Enabled
INFO - 2023-09-24 04:11:52 --> Utf8 Class Initialized
INFO - 2023-09-24 04:11:52 --> URI Class Initialized
INFO - 2023-09-24 04:11:52 --> Router Class Initialized
INFO - 2023-09-24 04:11:52 --> Output Class Initialized
INFO - 2023-09-24 04:11:52 --> Security Class Initialized
DEBUG - 2023-09-24 04:11:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-24 04:11:52 --> Input Class Initialized
INFO - 2023-09-24 04:11:52 --> Language Class Initialized
INFO - 2023-09-24 04:11:52 --> Loader Class Initialized
INFO - 2023-09-24 04:11:52 --> Helper loaded: url_helper
INFO - 2023-09-24 04:11:52 --> Helper loaded: file_helper
INFO - 2023-09-24 04:11:52 --> Helper loaded: html_helper
INFO - 2023-09-24 04:11:52 --> Helper loaded: text_helper
INFO - 2023-09-24 04:11:52 --> Helper loaded: form_helper
INFO - 2023-09-24 04:11:52 --> Helper loaded: lang_helper
INFO - 2023-09-24 04:11:52 --> Helper loaded: security_helper
INFO - 2023-09-24 04:11:52 --> Helper loaded: cookie_helper
INFO - 2023-09-24 04:11:52 --> Database Driver Class Initialized
INFO - 2023-09-24 04:11:52 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-24 04:11:52 --> Parser Class Initialized
INFO - 2023-09-24 04:11:52 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-24 04:11:52 --> Pagination Class Initialized
INFO - 2023-09-24 04:11:52 --> Form Validation Class Initialized
INFO - 2023-09-24 04:11:52 --> Controller Class Initialized
INFO - 2023-09-24 04:11:52 --> Model Class Initialized
DEBUG - 2023-09-24 04:11:52 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-09-24 04:11:52 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-24 04:11:52 --> Model Class Initialized
DEBUG - 2023-09-24 04:11:52 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-24 04:11:52 --> Model Class Initialized
INFO - 2023-09-24 04:11:52 --> Final output sent to browser
DEBUG - 2023-09-24 04:11:52 --> Total execution time: 0.0660
ERROR - 2023-09-24 04:11:53 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-24 04:11:53 --> Config Class Initialized
INFO - 2023-09-24 04:11:53 --> Hooks Class Initialized
DEBUG - 2023-09-24 04:11:53 --> UTF-8 Support Enabled
INFO - 2023-09-24 04:11:53 --> Utf8 Class Initialized
INFO - 2023-09-24 04:11:53 --> URI Class Initialized
INFO - 2023-09-24 04:11:53 --> Router Class Initialized
INFO - 2023-09-24 04:11:53 --> Output Class Initialized
INFO - 2023-09-24 04:11:53 --> Security Class Initialized
DEBUG - 2023-09-24 04:11:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-24 04:11:53 --> Input Class Initialized
INFO - 2023-09-24 04:11:53 --> Language Class Initialized
INFO - 2023-09-24 04:11:53 --> Loader Class Initialized
INFO - 2023-09-24 04:11:53 --> Helper loaded: url_helper
INFO - 2023-09-24 04:11:53 --> Helper loaded: file_helper
INFO - 2023-09-24 04:11:53 --> Helper loaded: html_helper
INFO - 2023-09-24 04:11:53 --> Helper loaded: text_helper
INFO - 2023-09-24 04:11:53 --> Helper loaded: form_helper
INFO - 2023-09-24 04:11:53 --> Helper loaded: lang_helper
INFO - 2023-09-24 04:11:53 --> Helper loaded: security_helper
INFO - 2023-09-24 04:11:53 --> Helper loaded: cookie_helper
INFO - 2023-09-24 04:11:53 --> Database Driver Class Initialized
INFO - 2023-09-24 04:11:53 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-24 04:11:53 --> Parser Class Initialized
INFO - 2023-09-24 04:11:53 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-24 04:11:53 --> Pagination Class Initialized
INFO - 2023-09-24 04:11:53 --> Form Validation Class Initialized
INFO - 2023-09-24 04:11:53 --> Controller Class Initialized
INFO - 2023-09-24 04:11:53 --> Model Class Initialized
DEBUG - 2023-09-24 04:11:53 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-09-24 04:11:53 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-24 04:11:53 --> Model Class Initialized
DEBUG - 2023-09-24 04:11:53 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-24 04:11:53 --> Model Class Initialized
INFO - 2023-09-24 04:11:53 --> Final output sent to browser
DEBUG - 2023-09-24 04:11:53 --> Total execution time: 0.0215
ERROR - 2023-09-24 04:11:55 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-24 04:11:55 --> Config Class Initialized
INFO - 2023-09-24 04:11:55 --> Hooks Class Initialized
DEBUG - 2023-09-24 04:11:55 --> UTF-8 Support Enabled
INFO - 2023-09-24 04:11:55 --> Utf8 Class Initialized
INFO - 2023-09-24 04:11:55 --> URI Class Initialized
INFO - 2023-09-24 04:11:55 --> Router Class Initialized
INFO - 2023-09-24 04:11:55 --> Output Class Initialized
INFO - 2023-09-24 04:11:55 --> Security Class Initialized
DEBUG - 2023-09-24 04:11:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-24 04:11:55 --> Input Class Initialized
INFO - 2023-09-24 04:11:55 --> Language Class Initialized
INFO - 2023-09-24 04:11:55 --> Loader Class Initialized
INFO - 2023-09-24 04:11:55 --> Helper loaded: url_helper
INFO - 2023-09-24 04:11:55 --> Helper loaded: file_helper
INFO - 2023-09-24 04:11:55 --> Helper loaded: html_helper
INFO - 2023-09-24 04:11:55 --> Helper loaded: text_helper
INFO - 2023-09-24 04:11:55 --> Helper loaded: form_helper
INFO - 2023-09-24 04:11:55 --> Helper loaded: lang_helper
INFO - 2023-09-24 04:11:55 --> Helper loaded: security_helper
INFO - 2023-09-24 04:11:55 --> Helper loaded: cookie_helper
INFO - 2023-09-24 04:11:55 --> Database Driver Class Initialized
INFO - 2023-09-24 04:11:55 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-24 04:11:55 --> Parser Class Initialized
INFO - 2023-09-24 04:11:55 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-24 04:11:55 --> Pagination Class Initialized
INFO - 2023-09-24 04:11:55 --> Form Validation Class Initialized
INFO - 2023-09-24 04:11:55 --> Controller Class Initialized
INFO - 2023-09-24 04:11:55 --> Model Class Initialized
DEBUG - 2023-09-24 04:11:55 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-09-24 04:11:55 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-24 04:11:55 --> Model Class Initialized
DEBUG - 2023-09-24 04:11:55 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-24 04:11:55 --> Model Class Initialized
INFO - 2023-09-24 04:11:55 --> Final output sent to browser
DEBUG - 2023-09-24 04:11:55 --> Total execution time: 0.0701
ERROR - 2023-09-24 04:12:02 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-24 04:12:02 --> Config Class Initialized
INFO - 2023-09-24 04:12:02 --> Hooks Class Initialized
DEBUG - 2023-09-24 04:12:02 --> UTF-8 Support Enabled
INFO - 2023-09-24 04:12:02 --> Utf8 Class Initialized
INFO - 2023-09-24 04:12:02 --> URI Class Initialized
INFO - 2023-09-24 04:12:02 --> Router Class Initialized
INFO - 2023-09-24 04:12:02 --> Output Class Initialized
INFO - 2023-09-24 04:12:02 --> Security Class Initialized
DEBUG - 2023-09-24 04:12:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-24 04:12:02 --> Input Class Initialized
INFO - 2023-09-24 04:12:02 --> Language Class Initialized
INFO - 2023-09-24 04:12:02 --> Loader Class Initialized
INFO - 2023-09-24 04:12:02 --> Helper loaded: url_helper
INFO - 2023-09-24 04:12:02 --> Helper loaded: file_helper
INFO - 2023-09-24 04:12:02 --> Helper loaded: html_helper
INFO - 2023-09-24 04:12:02 --> Helper loaded: text_helper
INFO - 2023-09-24 04:12:02 --> Helper loaded: form_helper
INFO - 2023-09-24 04:12:02 --> Helper loaded: lang_helper
INFO - 2023-09-24 04:12:02 --> Helper loaded: security_helper
INFO - 2023-09-24 04:12:02 --> Helper loaded: cookie_helper
INFO - 2023-09-24 04:12:02 --> Database Driver Class Initialized
INFO - 2023-09-24 04:12:02 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-24 04:12:02 --> Parser Class Initialized
INFO - 2023-09-24 04:12:02 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-24 04:12:02 --> Pagination Class Initialized
INFO - 2023-09-24 04:12:02 --> Form Validation Class Initialized
INFO - 2023-09-24 04:12:02 --> Controller Class Initialized
INFO - 2023-09-24 04:12:02 --> Model Class Initialized
DEBUG - 2023-09-24 04:12:02 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-09-24 04:12:02 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-24 04:12:02 --> Model Class Initialized
DEBUG - 2023-09-24 04:12:02 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-24 04:12:02 --> Model Class Initialized
INFO - 2023-09-24 04:12:02 --> Model Class Initialized
INFO - 2023-09-24 04:12:02 --> Final output sent to browser
DEBUG - 2023-09-24 04:12:02 --> Total execution time: 0.0251
ERROR - 2023-09-24 04:12:03 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-24 04:12:03 --> Config Class Initialized
INFO - 2023-09-24 04:12:03 --> Hooks Class Initialized
DEBUG - 2023-09-24 04:12:03 --> UTF-8 Support Enabled
INFO - 2023-09-24 04:12:03 --> Utf8 Class Initialized
INFO - 2023-09-24 04:12:03 --> URI Class Initialized
INFO - 2023-09-24 04:12:03 --> Router Class Initialized
INFO - 2023-09-24 04:12:03 --> Output Class Initialized
INFO - 2023-09-24 04:12:03 --> Security Class Initialized
DEBUG - 2023-09-24 04:12:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-24 04:12:03 --> Input Class Initialized
INFO - 2023-09-24 04:12:03 --> Language Class Initialized
INFO - 2023-09-24 04:12:03 --> Loader Class Initialized
INFO - 2023-09-24 04:12:03 --> Helper loaded: url_helper
INFO - 2023-09-24 04:12:03 --> Helper loaded: file_helper
INFO - 2023-09-24 04:12:03 --> Helper loaded: html_helper
INFO - 2023-09-24 04:12:03 --> Helper loaded: text_helper
INFO - 2023-09-24 04:12:03 --> Helper loaded: form_helper
INFO - 2023-09-24 04:12:03 --> Helper loaded: lang_helper
INFO - 2023-09-24 04:12:03 --> Helper loaded: security_helper
INFO - 2023-09-24 04:12:03 --> Helper loaded: cookie_helper
INFO - 2023-09-24 04:12:03 --> Database Driver Class Initialized
INFO - 2023-09-24 04:12:03 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-24 04:12:03 --> Parser Class Initialized
INFO - 2023-09-24 04:12:03 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-24 04:12:03 --> Pagination Class Initialized
INFO - 2023-09-24 04:12:03 --> Form Validation Class Initialized
INFO - 2023-09-24 04:12:03 --> Controller Class Initialized
INFO - 2023-09-24 04:12:03 --> Model Class Initialized
DEBUG - 2023-09-24 04:12:03 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-09-24 04:12:03 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-24 04:12:03 --> Model Class Initialized
DEBUG - 2023-09-24 04:12:03 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-24 04:12:03 --> Model Class Initialized
INFO - 2023-09-24 04:12:03 --> Final output sent to browser
DEBUG - 2023-09-24 04:12:03 --> Total execution time: 0.0189
ERROR - 2023-09-24 04:12:05 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-24 04:12:05 --> Config Class Initialized
INFO - 2023-09-24 04:12:05 --> Hooks Class Initialized
DEBUG - 2023-09-24 04:12:05 --> UTF-8 Support Enabled
INFO - 2023-09-24 04:12:05 --> Utf8 Class Initialized
INFO - 2023-09-24 04:12:05 --> URI Class Initialized
INFO - 2023-09-24 04:12:05 --> Router Class Initialized
INFO - 2023-09-24 04:12:05 --> Output Class Initialized
INFO - 2023-09-24 04:12:05 --> Security Class Initialized
DEBUG - 2023-09-24 04:12:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-24 04:12:05 --> Input Class Initialized
INFO - 2023-09-24 04:12:05 --> Language Class Initialized
INFO - 2023-09-24 04:12:05 --> Loader Class Initialized
INFO - 2023-09-24 04:12:05 --> Helper loaded: url_helper
INFO - 2023-09-24 04:12:05 --> Helper loaded: file_helper
INFO - 2023-09-24 04:12:05 --> Helper loaded: html_helper
INFO - 2023-09-24 04:12:05 --> Helper loaded: text_helper
INFO - 2023-09-24 04:12:05 --> Helper loaded: form_helper
INFO - 2023-09-24 04:12:05 --> Helper loaded: lang_helper
INFO - 2023-09-24 04:12:05 --> Helper loaded: security_helper
INFO - 2023-09-24 04:12:05 --> Helper loaded: cookie_helper
INFO - 2023-09-24 04:12:05 --> Database Driver Class Initialized
INFO - 2023-09-24 04:12:05 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-24 04:12:05 --> Parser Class Initialized
INFO - 2023-09-24 04:12:05 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-24 04:12:05 --> Pagination Class Initialized
INFO - 2023-09-24 04:12:05 --> Form Validation Class Initialized
INFO - 2023-09-24 04:12:05 --> Controller Class Initialized
INFO - 2023-09-24 04:12:05 --> Model Class Initialized
DEBUG - 2023-09-24 04:12:05 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-09-24 04:12:05 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-24 04:12:05 --> Model Class Initialized
DEBUG - 2023-09-24 04:12:05 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-24 04:12:05 --> Model Class Initialized
INFO - 2023-09-24 04:12:05 --> Final output sent to browser
DEBUG - 2023-09-24 04:12:05 --> Total execution time: 0.0241
ERROR - 2023-09-24 04:12:05 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-24 04:12:05 --> Config Class Initialized
INFO - 2023-09-24 04:12:05 --> Hooks Class Initialized
DEBUG - 2023-09-24 04:12:05 --> UTF-8 Support Enabled
INFO - 2023-09-24 04:12:05 --> Utf8 Class Initialized
INFO - 2023-09-24 04:12:05 --> URI Class Initialized
INFO - 2023-09-24 04:12:05 --> Router Class Initialized
INFO - 2023-09-24 04:12:05 --> Output Class Initialized
INFO - 2023-09-24 04:12:05 --> Security Class Initialized
DEBUG - 2023-09-24 04:12:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-24 04:12:05 --> Input Class Initialized
INFO - 2023-09-24 04:12:05 --> Language Class Initialized
INFO - 2023-09-24 04:12:05 --> Loader Class Initialized
INFO - 2023-09-24 04:12:05 --> Helper loaded: url_helper
INFO - 2023-09-24 04:12:05 --> Helper loaded: file_helper
INFO - 2023-09-24 04:12:05 --> Helper loaded: html_helper
INFO - 2023-09-24 04:12:05 --> Helper loaded: text_helper
INFO - 2023-09-24 04:12:05 --> Helper loaded: form_helper
INFO - 2023-09-24 04:12:05 --> Helper loaded: lang_helper
INFO - 2023-09-24 04:12:05 --> Helper loaded: security_helper
INFO - 2023-09-24 04:12:05 --> Helper loaded: cookie_helper
INFO - 2023-09-24 04:12:05 --> Database Driver Class Initialized
INFO - 2023-09-24 04:12:05 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-24 04:12:05 --> Parser Class Initialized
INFO - 2023-09-24 04:12:05 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-24 04:12:05 --> Pagination Class Initialized
INFO - 2023-09-24 04:12:05 --> Form Validation Class Initialized
INFO - 2023-09-24 04:12:05 --> Controller Class Initialized
INFO - 2023-09-24 04:12:05 --> Model Class Initialized
DEBUG - 2023-09-24 04:12:05 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-09-24 04:12:05 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-24 04:12:05 --> Model Class Initialized
DEBUG - 2023-09-24 04:12:05 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-24 04:12:05 --> Model Class Initialized
INFO - 2023-09-24 04:12:05 --> Final output sent to browser
DEBUG - 2023-09-24 04:12:05 --> Total execution time: 0.0635
ERROR - 2023-09-24 04:12:29 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-24 04:12:29 --> Config Class Initialized
INFO - 2023-09-24 04:12:29 --> Hooks Class Initialized
DEBUG - 2023-09-24 04:12:29 --> UTF-8 Support Enabled
INFO - 2023-09-24 04:12:29 --> Utf8 Class Initialized
INFO - 2023-09-24 04:12:29 --> URI Class Initialized
INFO - 2023-09-24 04:12:29 --> Router Class Initialized
INFO - 2023-09-24 04:12:29 --> Output Class Initialized
INFO - 2023-09-24 04:12:29 --> Security Class Initialized
DEBUG - 2023-09-24 04:12:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-24 04:12:29 --> Input Class Initialized
INFO - 2023-09-24 04:12:29 --> Language Class Initialized
INFO - 2023-09-24 04:12:29 --> Loader Class Initialized
INFO - 2023-09-24 04:12:29 --> Helper loaded: url_helper
INFO - 2023-09-24 04:12:29 --> Helper loaded: file_helper
INFO - 2023-09-24 04:12:29 --> Helper loaded: html_helper
INFO - 2023-09-24 04:12:29 --> Helper loaded: text_helper
INFO - 2023-09-24 04:12:29 --> Helper loaded: form_helper
INFO - 2023-09-24 04:12:29 --> Helper loaded: lang_helper
INFO - 2023-09-24 04:12:29 --> Helper loaded: security_helper
INFO - 2023-09-24 04:12:29 --> Helper loaded: cookie_helper
INFO - 2023-09-24 04:12:29 --> Database Driver Class Initialized
INFO - 2023-09-24 04:12:29 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-24 04:12:29 --> Parser Class Initialized
INFO - 2023-09-24 04:12:29 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-24 04:12:29 --> Pagination Class Initialized
INFO - 2023-09-24 04:12:29 --> Form Validation Class Initialized
INFO - 2023-09-24 04:12:29 --> Controller Class Initialized
INFO - 2023-09-24 04:12:29 --> Model Class Initialized
DEBUG - 2023-09-24 04:12:29 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-09-24 04:12:29 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-24 04:12:29 --> Model Class Initialized
DEBUG - 2023-09-24 04:12:29 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-24 04:12:29 --> Model Class Initialized
INFO - 2023-09-24 04:12:29 --> Final output sent to browser
DEBUG - 2023-09-24 04:12:29 --> Total execution time: 0.0368
ERROR - 2023-09-24 04:12:30 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-24 04:12:30 --> Config Class Initialized
INFO - 2023-09-24 04:12:30 --> Hooks Class Initialized
DEBUG - 2023-09-24 04:12:30 --> UTF-8 Support Enabled
INFO - 2023-09-24 04:12:30 --> Utf8 Class Initialized
INFO - 2023-09-24 04:12:30 --> URI Class Initialized
INFO - 2023-09-24 04:12:30 --> Router Class Initialized
INFO - 2023-09-24 04:12:30 --> Output Class Initialized
INFO - 2023-09-24 04:12:30 --> Security Class Initialized
DEBUG - 2023-09-24 04:12:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-24 04:12:30 --> Input Class Initialized
INFO - 2023-09-24 04:12:30 --> Language Class Initialized
INFO - 2023-09-24 04:12:30 --> Loader Class Initialized
INFO - 2023-09-24 04:12:30 --> Helper loaded: url_helper
INFO - 2023-09-24 04:12:30 --> Helper loaded: file_helper
INFO - 2023-09-24 04:12:30 --> Helper loaded: html_helper
INFO - 2023-09-24 04:12:30 --> Helper loaded: text_helper
INFO - 2023-09-24 04:12:30 --> Helper loaded: form_helper
INFO - 2023-09-24 04:12:30 --> Helper loaded: lang_helper
INFO - 2023-09-24 04:12:30 --> Helper loaded: security_helper
INFO - 2023-09-24 04:12:30 --> Helper loaded: cookie_helper
INFO - 2023-09-24 04:12:30 --> Database Driver Class Initialized
INFO - 2023-09-24 04:12:30 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-24 04:12:30 --> Parser Class Initialized
INFO - 2023-09-24 04:12:30 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-24 04:12:30 --> Pagination Class Initialized
INFO - 2023-09-24 04:12:30 --> Form Validation Class Initialized
INFO - 2023-09-24 04:12:30 --> Controller Class Initialized
INFO - 2023-09-24 04:12:30 --> Model Class Initialized
DEBUG - 2023-09-24 04:12:30 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-09-24 04:12:30 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-24 04:12:30 --> Model Class Initialized
DEBUG - 2023-09-24 04:12:30 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-24 04:12:30 --> Model Class Initialized
INFO - 2023-09-24 04:12:30 --> Final output sent to browser
DEBUG - 2023-09-24 04:12:30 --> Total execution time: 0.0207
ERROR - 2023-09-24 04:12:30 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-24 04:12:30 --> Config Class Initialized
INFO - 2023-09-24 04:12:30 --> Hooks Class Initialized
DEBUG - 2023-09-24 04:12:30 --> UTF-8 Support Enabled
INFO - 2023-09-24 04:12:30 --> Utf8 Class Initialized
INFO - 2023-09-24 04:12:30 --> URI Class Initialized
INFO - 2023-09-24 04:12:30 --> Router Class Initialized
INFO - 2023-09-24 04:12:30 --> Output Class Initialized
INFO - 2023-09-24 04:12:30 --> Security Class Initialized
DEBUG - 2023-09-24 04:12:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-24 04:12:30 --> Input Class Initialized
INFO - 2023-09-24 04:12:30 --> Language Class Initialized
INFO - 2023-09-24 04:12:30 --> Loader Class Initialized
INFO - 2023-09-24 04:12:30 --> Helper loaded: url_helper
INFO - 2023-09-24 04:12:30 --> Helper loaded: file_helper
INFO - 2023-09-24 04:12:30 --> Helper loaded: html_helper
INFO - 2023-09-24 04:12:30 --> Helper loaded: text_helper
INFO - 2023-09-24 04:12:30 --> Helper loaded: form_helper
INFO - 2023-09-24 04:12:30 --> Helper loaded: lang_helper
INFO - 2023-09-24 04:12:30 --> Helper loaded: security_helper
INFO - 2023-09-24 04:12:30 --> Helper loaded: cookie_helper
INFO - 2023-09-24 04:12:30 --> Database Driver Class Initialized
INFO - 2023-09-24 04:12:30 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-24 04:12:30 --> Parser Class Initialized
INFO - 2023-09-24 04:12:30 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-24 04:12:30 --> Pagination Class Initialized
INFO - 2023-09-24 04:12:30 --> Form Validation Class Initialized
INFO - 2023-09-24 04:12:30 --> Controller Class Initialized
INFO - 2023-09-24 04:12:30 --> Model Class Initialized
DEBUG - 2023-09-24 04:12:30 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-09-24 04:12:30 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-24 04:12:30 --> Model Class Initialized
DEBUG - 2023-09-24 04:12:30 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-24 04:12:30 --> Model Class Initialized
INFO - 2023-09-24 04:12:30 --> Final output sent to browser
DEBUG - 2023-09-24 04:12:30 --> Total execution time: 0.0202
ERROR - 2023-09-24 04:12:31 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-24 04:12:31 --> Config Class Initialized
INFO - 2023-09-24 04:12:31 --> Hooks Class Initialized
DEBUG - 2023-09-24 04:12:31 --> UTF-8 Support Enabled
INFO - 2023-09-24 04:12:31 --> Utf8 Class Initialized
INFO - 2023-09-24 04:12:31 --> URI Class Initialized
INFO - 2023-09-24 04:12:31 --> Router Class Initialized
INFO - 2023-09-24 04:12:31 --> Output Class Initialized
INFO - 2023-09-24 04:12:31 --> Security Class Initialized
DEBUG - 2023-09-24 04:12:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-24 04:12:31 --> Input Class Initialized
INFO - 2023-09-24 04:12:31 --> Language Class Initialized
INFO - 2023-09-24 04:12:31 --> Loader Class Initialized
INFO - 2023-09-24 04:12:31 --> Helper loaded: url_helper
INFO - 2023-09-24 04:12:31 --> Helper loaded: file_helper
INFO - 2023-09-24 04:12:31 --> Helper loaded: html_helper
INFO - 2023-09-24 04:12:31 --> Helper loaded: text_helper
INFO - 2023-09-24 04:12:31 --> Helper loaded: form_helper
INFO - 2023-09-24 04:12:31 --> Helper loaded: lang_helper
INFO - 2023-09-24 04:12:31 --> Helper loaded: security_helper
INFO - 2023-09-24 04:12:31 --> Helper loaded: cookie_helper
INFO - 2023-09-24 04:12:31 --> Database Driver Class Initialized
INFO - 2023-09-24 04:12:31 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-24 04:12:31 --> Parser Class Initialized
INFO - 2023-09-24 04:12:31 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-24 04:12:31 --> Pagination Class Initialized
INFO - 2023-09-24 04:12:31 --> Form Validation Class Initialized
INFO - 2023-09-24 04:12:31 --> Controller Class Initialized
INFO - 2023-09-24 04:12:31 --> Model Class Initialized
DEBUG - 2023-09-24 04:12:31 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-09-24 04:12:31 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-24 04:12:31 --> Model Class Initialized
DEBUG - 2023-09-24 04:12:31 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-24 04:12:31 --> Model Class Initialized
INFO - 2023-09-24 04:12:31 --> Final output sent to browser
DEBUG - 2023-09-24 04:12:31 --> Total execution time: 0.0328
ERROR - 2023-09-24 04:12:31 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-24 04:12:31 --> Config Class Initialized
INFO - 2023-09-24 04:12:31 --> Hooks Class Initialized
DEBUG - 2023-09-24 04:12:31 --> UTF-8 Support Enabled
INFO - 2023-09-24 04:12:31 --> Utf8 Class Initialized
INFO - 2023-09-24 04:12:31 --> URI Class Initialized
INFO - 2023-09-24 04:12:31 --> Router Class Initialized
INFO - 2023-09-24 04:12:31 --> Output Class Initialized
INFO - 2023-09-24 04:12:31 --> Security Class Initialized
DEBUG - 2023-09-24 04:12:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-24 04:12:31 --> Input Class Initialized
INFO - 2023-09-24 04:12:31 --> Language Class Initialized
INFO - 2023-09-24 04:12:31 --> Loader Class Initialized
INFO - 2023-09-24 04:12:31 --> Helper loaded: url_helper
INFO - 2023-09-24 04:12:31 --> Helper loaded: file_helper
INFO - 2023-09-24 04:12:31 --> Helper loaded: html_helper
INFO - 2023-09-24 04:12:31 --> Helper loaded: text_helper
INFO - 2023-09-24 04:12:31 --> Helper loaded: form_helper
INFO - 2023-09-24 04:12:31 --> Helper loaded: lang_helper
INFO - 2023-09-24 04:12:31 --> Helper loaded: security_helper
INFO - 2023-09-24 04:12:31 --> Helper loaded: cookie_helper
INFO - 2023-09-24 04:12:31 --> Database Driver Class Initialized
INFO - 2023-09-24 04:12:31 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-24 04:12:31 --> Parser Class Initialized
INFO - 2023-09-24 04:12:31 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-24 04:12:31 --> Pagination Class Initialized
INFO - 2023-09-24 04:12:31 --> Form Validation Class Initialized
INFO - 2023-09-24 04:12:31 --> Controller Class Initialized
INFO - 2023-09-24 04:12:31 --> Model Class Initialized
DEBUG - 2023-09-24 04:12:31 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-09-24 04:12:31 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-24 04:12:31 --> Model Class Initialized
DEBUG - 2023-09-24 04:12:31 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-24 04:12:31 --> Model Class Initialized
INFO - 2023-09-24 04:12:31 --> Final output sent to browser
DEBUG - 2023-09-24 04:12:31 --> Total execution time: 0.0653
ERROR - 2023-09-24 04:12:35 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-24 04:12:35 --> Config Class Initialized
INFO - 2023-09-24 04:12:35 --> Hooks Class Initialized
DEBUG - 2023-09-24 04:12:35 --> UTF-8 Support Enabled
INFO - 2023-09-24 04:12:35 --> Utf8 Class Initialized
INFO - 2023-09-24 04:12:35 --> URI Class Initialized
INFO - 2023-09-24 04:12:35 --> Router Class Initialized
INFO - 2023-09-24 04:12:35 --> Output Class Initialized
INFO - 2023-09-24 04:12:35 --> Security Class Initialized
DEBUG - 2023-09-24 04:12:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-24 04:12:35 --> Input Class Initialized
INFO - 2023-09-24 04:12:35 --> Language Class Initialized
INFO - 2023-09-24 04:12:35 --> Loader Class Initialized
INFO - 2023-09-24 04:12:35 --> Helper loaded: url_helper
INFO - 2023-09-24 04:12:35 --> Helper loaded: file_helper
INFO - 2023-09-24 04:12:35 --> Helper loaded: html_helper
INFO - 2023-09-24 04:12:35 --> Helper loaded: text_helper
INFO - 2023-09-24 04:12:35 --> Helper loaded: form_helper
INFO - 2023-09-24 04:12:35 --> Helper loaded: lang_helper
INFO - 2023-09-24 04:12:35 --> Helper loaded: security_helper
INFO - 2023-09-24 04:12:35 --> Helper loaded: cookie_helper
INFO - 2023-09-24 04:12:35 --> Database Driver Class Initialized
INFO - 2023-09-24 04:12:35 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-24 04:12:35 --> Parser Class Initialized
INFO - 2023-09-24 04:12:35 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-24 04:12:35 --> Pagination Class Initialized
INFO - 2023-09-24 04:12:35 --> Form Validation Class Initialized
INFO - 2023-09-24 04:12:35 --> Controller Class Initialized
INFO - 2023-09-24 04:12:35 --> Model Class Initialized
DEBUG - 2023-09-24 04:12:35 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-09-24 04:12:35 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-24 04:12:35 --> Model Class Initialized
DEBUG - 2023-09-24 04:12:35 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-24 04:12:35 --> Model Class Initialized
INFO - 2023-09-24 04:12:35 --> Final output sent to browser
DEBUG - 2023-09-24 04:12:35 --> Total execution time: 0.0244
ERROR - 2023-09-24 04:12:36 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-24 04:12:36 --> Config Class Initialized
INFO - 2023-09-24 04:12:36 --> Hooks Class Initialized
DEBUG - 2023-09-24 04:12:36 --> UTF-8 Support Enabled
INFO - 2023-09-24 04:12:36 --> Utf8 Class Initialized
INFO - 2023-09-24 04:12:36 --> URI Class Initialized
INFO - 2023-09-24 04:12:36 --> Router Class Initialized
INFO - 2023-09-24 04:12:36 --> Output Class Initialized
INFO - 2023-09-24 04:12:36 --> Security Class Initialized
DEBUG - 2023-09-24 04:12:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-24 04:12:36 --> Input Class Initialized
INFO - 2023-09-24 04:12:36 --> Language Class Initialized
INFO - 2023-09-24 04:12:36 --> Loader Class Initialized
INFO - 2023-09-24 04:12:36 --> Helper loaded: url_helper
INFO - 2023-09-24 04:12:36 --> Helper loaded: file_helper
INFO - 2023-09-24 04:12:36 --> Helper loaded: html_helper
INFO - 2023-09-24 04:12:36 --> Helper loaded: text_helper
INFO - 2023-09-24 04:12:36 --> Helper loaded: form_helper
INFO - 2023-09-24 04:12:36 --> Helper loaded: lang_helper
INFO - 2023-09-24 04:12:36 --> Helper loaded: security_helper
INFO - 2023-09-24 04:12:36 --> Helper loaded: cookie_helper
INFO - 2023-09-24 04:12:36 --> Database Driver Class Initialized
INFO - 2023-09-24 04:12:36 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-24 04:12:36 --> Parser Class Initialized
INFO - 2023-09-24 04:12:36 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-24 04:12:36 --> Pagination Class Initialized
INFO - 2023-09-24 04:12:36 --> Form Validation Class Initialized
INFO - 2023-09-24 04:12:36 --> Controller Class Initialized
INFO - 2023-09-24 04:12:36 --> Model Class Initialized
DEBUG - 2023-09-24 04:12:36 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-09-24 04:12:36 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-24 04:12:36 --> Model Class Initialized
DEBUG - 2023-09-24 04:12:36 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-24 04:12:36 --> Model Class Initialized
INFO - 2023-09-24 04:12:36 --> Final output sent to browser
DEBUG - 2023-09-24 04:12:36 --> Total execution time: 0.0229
ERROR - 2023-09-24 04:12:36 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-24 04:12:36 --> Config Class Initialized
INFO - 2023-09-24 04:12:36 --> Hooks Class Initialized
DEBUG - 2023-09-24 04:12:36 --> UTF-8 Support Enabled
INFO - 2023-09-24 04:12:36 --> Utf8 Class Initialized
INFO - 2023-09-24 04:12:36 --> URI Class Initialized
INFO - 2023-09-24 04:12:36 --> Router Class Initialized
INFO - 2023-09-24 04:12:36 --> Output Class Initialized
INFO - 2023-09-24 04:12:36 --> Security Class Initialized
DEBUG - 2023-09-24 04:12:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-24 04:12:36 --> Input Class Initialized
INFO - 2023-09-24 04:12:36 --> Language Class Initialized
INFO - 2023-09-24 04:12:36 --> Loader Class Initialized
INFO - 2023-09-24 04:12:36 --> Helper loaded: url_helper
INFO - 2023-09-24 04:12:36 --> Helper loaded: file_helper
INFO - 2023-09-24 04:12:36 --> Helper loaded: html_helper
INFO - 2023-09-24 04:12:36 --> Helper loaded: text_helper
INFO - 2023-09-24 04:12:36 --> Helper loaded: form_helper
INFO - 2023-09-24 04:12:36 --> Helper loaded: lang_helper
INFO - 2023-09-24 04:12:36 --> Helper loaded: security_helper
INFO - 2023-09-24 04:12:36 --> Helper loaded: cookie_helper
INFO - 2023-09-24 04:12:36 --> Database Driver Class Initialized
INFO - 2023-09-24 04:12:36 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-24 04:12:36 --> Parser Class Initialized
INFO - 2023-09-24 04:12:36 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-24 04:12:36 --> Pagination Class Initialized
INFO - 2023-09-24 04:12:36 --> Form Validation Class Initialized
INFO - 2023-09-24 04:12:36 --> Controller Class Initialized
INFO - 2023-09-24 04:12:36 --> Model Class Initialized
DEBUG - 2023-09-24 04:12:36 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-09-24 04:12:36 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-24 04:12:36 --> Model Class Initialized
DEBUG - 2023-09-24 04:12:36 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-24 04:12:36 --> Model Class Initialized
INFO - 2023-09-24 04:12:36 --> Final output sent to browser
DEBUG - 2023-09-24 04:12:36 --> Total execution time: 0.0203
ERROR - 2023-09-24 04:12:37 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-24 04:12:37 --> Config Class Initialized
INFO - 2023-09-24 04:12:37 --> Hooks Class Initialized
DEBUG - 2023-09-24 04:12:37 --> UTF-8 Support Enabled
INFO - 2023-09-24 04:12:37 --> Utf8 Class Initialized
INFO - 2023-09-24 04:12:37 --> URI Class Initialized
INFO - 2023-09-24 04:12:37 --> Router Class Initialized
INFO - 2023-09-24 04:12:37 --> Output Class Initialized
INFO - 2023-09-24 04:12:37 --> Security Class Initialized
DEBUG - 2023-09-24 04:12:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-24 04:12:37 --> Input Class Initialized
INFO - 2023-09-24 04:12:37 --> Language Class Initialized
INFO - 2023-09-24 04:12:37 --> Loader Class Initialized
INFO - 2023-09-24 04:12:37 --> Helper loaded: url_helper
INFO - 2023-09-24 04:12:37 --> Helper loaded: file_helper
INFO - 2023-09-24 04:12:37 --> Helper loaded: html_helper
INFO - 2023-09-24 04:12:37 --> Helper loaded: text_helper
INFO - 2023-09-24 04:12:37 --> Helper loaded: form_helper
INFO - 2023-09-24 04:12:37 --> Helper loaded: lang_helper
INFO - 2023-09-24 04:12:37 --> Helper loaded: security_helper
INFO - 2023-09-24 04:12:37 --> Helper loaded: cookie_helper
INFO - 2023-09-24 04:12:37 --> Database Driver Class Initialized
INFO - 2023-09-24 04:12:37 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-24 04:12:37 --> Parser Class Initialized
INFO - 2023-09-24 04:12:37 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-24 04:12:37 --> Pagination Class Initialized
INFO - 2023-09-24 04:12:37 --> Form Validation Class Initialized
INFO - 2023-09-24 04:12:37 --> Controller Class Initialized
INFO - 2023-09-24 04:12:37 --> Model Class Initialized
DEBUG - 2023-09-24 04:12:37 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-09-24 04:12:37 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-24 04:12:37 --> Model Class Initialized
DEBUG - 2023-09-24 04:12:37 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-24 04:12:37 --> Model Class Initialized
INFO - 2023-09-24 04:12:37 --> Final output sent to browser
DEBUG - 2023-09-24 04:12:37 --> Total execution time: 0.0198
ERROR - 2023-09-24 04:12:38 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-24 04:12:38 --> Config Class Initialized
INFO - 2023-09-24 04:12:38 --> Hooks Class Initialized
DEBUG - 2023-09-24 04:12:38 --> UTF-8 Support Enabled
INFO - 2023-09-24 04:12:38 --> Utf8 Class Initialized
INFO - 2023-09-24 04:12:38 --> URI Class Initialized
INFO - 2023-09-24 04:12:38 --> Router Class Initialized
INFO - 2023-09-24 04:12:38 --> Output Class Initialized
INFO - 2023-09-24 04:12:38 --> Security Class Initialized
DEBUG - 2023-09-24 04:12:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-24 04:12:38 --> Input Class Initialized
INFO - 2023-09-24 04:12:38 --> Language Class Initialized
INFO - 2023-09-24 04:12:38 --> Loader Class Initialized
INFO - 2023-09-24 04:12:38 --> Helper loaded: url_helper
INFO - 2023-09-24 04:12:38 --> Helper loaded: file_helper
INFO - 2023-09-24 04:12:38 --> Helper loaded: html_helper
INFO - 2023-09-24 04:12:38 --> Helper loaded: text_helper
INFO - 2023-09-24 04:12:38 --> Helper loaded: form_helper
INFO - 2023-09-24 04:12:38 --> Helper loaded: lang_helper
INFO - 2023-09-24 04:12:38 --> Helper loaded: security_helper
INFO - 2023-09-24 04:12:38 --> Helper loaded: cookie_helper
INFO - 2023-09-24 04:12:38 --> Database Driver Class Initialized
INFO - 2023-09-24 04:12:38 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-24 04:12:38 --> Parser Class Initialized
INFO - 2023-09-24 04:12:38 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-24 04:12:38 --> Pagination Class Initialized
INFO - 2023-09-24 04:12:38 --> Form Validation Class Initialized
INFO - 2023-09-24 04:12:38 --> Controller Class Initialized
INFO - 2023-09-24 04:12:38 --> Model Class Initialized
DEBUG - 2023-09-24 04:12:38 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-09-24 04:12:38 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-24 04:12:38 --> Model Class Initialized
DEBUG - 2023-09-24 04:12:38 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-24 04:12:38 --> Model Class Initialized
INFO - 2023-09-24 04:12:38 --> Final output sent to browser
DEBUG - 2023-09-24 04:12:38 --> Total execution time: 0.0246
ERROR - 2023-09-24 04:12:45 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-24 04:12:45 --> Config Class Initialized
INFO - 2023-09-24 04:12:45 --> Hooks Class Initialized
DEBUG - 2023-09-24 04:12:45 --> UTF-8 Support Enabled
INFO - 2023-09-24 04:12:45 --> Utf8 Class Initialized
INFO - 2023-09-24 04:12:45 --> URI Class Initialized
INFO - 2023-09-24 04:12:45 --> Router Class Initialized
INFO - 2023-09-24 04:12:45 --> Output Class Initialized
INFO - 2023-09-24 04:12:45 --> Security Class Initialized
DEBUG - 2023-09-24 04:12:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-24 04:12:45 --> Input Class Initialized
INFO - 2023-09-24 04:12:45 --> Language Class Initialized
INFO - 2023-09-24 04:12:45 --> Loader Class Initialized
INFO - 2023-09-24 04:12:45 --> Helper loaded: url_helper
INFO - 2023-09-24 04:12:45 --> Helper loaded: file_helper
INFO - 2023-09-24 04:12:45 --> Helper loaded: html_helper
INFO - 2023-09-24 04:12:45 --> Helper loaded: text_helper
INFO - 2023-09-24 04:12:45 --> Helper loaded: form_helper
INFO - 2023-09-24 04:12:45 --> Helper loaded: lang_helper
INFO - 2023-09-24 04:12:45 --> Helper loaded: security_helper
INFO - 2023-09-24 04:12:45 --> Helper loaded: cookie_helper
INFO - 2023-09-24 04:12:45 --> Database Driver Class Initialized
INFO - 2023-09-24 04:12:45 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-24 04:12:45 --> Parser Class Initialized
INFO - 2023-09-24 04:12:45 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-24 04:12:45 --> Pagination Class Initialized
INFO - 2023-09-24 04:12:45 --> Form Validation Class Initialized
INFO - 2023-09-24 04:12:45 --> Controller Class Initialized
INFO - 2023-09-24 04:12:45 --> Model Class Initialized
DEBUG - 2023-09-24 04:12:45 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-09-24 04:12:45 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-24 04:12:45 --> Model Class Initialized
DEBUG - 2023-09-24 04:12:45 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-24 04:12:45 --> Model Class Initialized
INFO - 2023-09-24 04:12:45 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice.php
DEBUG - 2023-09-24 04:12:45 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-09-24 04:12:45 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-09-24 04:12:45 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-09-24 04:12:45 --> Model Class Initialized
INFO - 2023-09-24 04:12:45 --> Model Class Initialized
INFO - 2023-09-24 04:12:45 --> Model Class Initialized
INFO - 2023-09-24 04:12:45 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-09-24 04:12:45 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-09-24 04:12:45 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-09-24 04:12:45 --> Final output sent to browser
DEBUG - 2023-09-24 04:12:45 --> Total execution time: 0.1897
ERROR - 2023-09-24 04:12:46 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-24 04:12:46 --> Config Class Initialized
INFO - 2023-09-24 04:12:46 --> Hooks Class Initialized
DEBUG - 2023-09-24 04:12:46 --> UTF-8 Support Enabled
INFO - 2023-09-24 04:12:46 --> Utf8 Class Initialized
INFO - 2023-09-24 04:12:46 --> URI Class Initialized
INFO - 2023-09-24 04:12:46 --> Router Class Initialized
INFO - 2023-09-24 04:12:46 --> Output Class Initialized
INFO - 2023-09-24 04:12:46 --> Security Class Initialized
DEBUG - 2023-09-24 04:12:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-24 04:12:46 --> Input Class Initialized
INFO - 2023-09-24 04:12:46 --> Language Class Initialized
INFO - 2023-09-24 04:12:46 --> Loader Class Initialized
INFO - 2023-09-24 04:12:46 --> Helper loaded: url_helper
INFO - 2023-09-24 04:12:46 --> Helper loaded: file_helper
INFO - 2023-09-24 04:12:46 --> Helper loaded: html_helper
INFO - 2023-09-24 04:12:46 --> Helper loaded: text_helper
INFO - 2023-09-24 04:12:46 --> Helper loaded: form_helper
INFO - 2023-09-24 04:12:46 --> Helper loaded: lang_helper
INFO - 2023-09-24 04:12:46 --> Helper loaded: security_helper
INFO - 2023-09-24 04:12:46 --> Helper loaded: cookie_helper
INFO - 2023-09-24 04:12:46 --> Database Driver Class Initialized
INFO - 2023-09-24 04:12:46 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-24 04:12:46 --> Parser Class Initialized
INFO - 2023-09-24 04:12:46 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-24 04:12:46 --> Pagination Class Initialized
INFO - 2023-09-24 04:12:46 --> Form Validation Class Initialized
INFO - 2023-09-24 04:12:46 --> Controller Class Initialized
INFO - 2023-09-24 04:12:46 --> Model Class Initialized
DEBUG - 2023-09-24 04:12:46 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-09-24 04:12:46 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-24 04:12:46 --> Model Class Initialized
DEBUG - 2023-09-24 04:12:46 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-24 04:12:46 --> Model Class Initialized
INFO - 2023-09-24 04:12:46 --> Final output sent to browser
DEBUG - 2023-09-24 04:12:46 --> Total execution time: 0.0613
ERROR - 2023-09-24 04:12:53 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-24 04:12:53 --> Config Class Initialized
INFO - 2023-09-24 04:12:53 --> Hooks Class Initialized
DEBUG - 2023-09-24 04:12:53 --> UTF-8 Support Enabled
INFO - 2023-09-24 04:12:53 --> Utf8 Class Initialized
INFO - 2023-09-24 04:12:53 --> URI Class Initialized
INFO - 2023-09-24 04:12:53 --> Router Class Initialized
INFO - 2023-09-24 04:12:53 --> Output Class Initialized
INFO - 2023-09-24 04:12:53 --> Security Class Initialized
DEBUG - 2023-09-24 04:12:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-24 04:12:53 --> Input Class Initialized
INFO - 2023-09-24 04:12:53 --> Language Class Initialized
INFO - 2023-09-24 04:12:53 --> Loader Class Initialized
INFO - 2023-09-24 04:12:53 --> Helper loaded: url_helper
INFO - 2023-09-24 04:12:53 --> Helper loaded: file_helper
INFO - 2023-09-24 04:12:53 --> Helper loaded: html_helper
INFO - 2023-09-24 04:12:53 --> Helper loaded: text_helper
INFO - 2023-09-24 04:12:53 --> Helper loaded: form_helper
INFO - 2023-09-24 04:12:53 --> Helper loaded: lang_helper
INFO - 2023-09-24 04:12:53 --> Helper loaded: security_helper
INFO - 2023-09-24 04:12:53 --> Helper loaded: cookie_helper
INFO - 2023-09-24 04:12:53 --> Database Driver Class Initialized
INFO - 2023-09-24 04:12:53 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-24 04:12:53 --> Parser Class Initialized
INFO - 2023-09-24 04:12:53 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-24 04:12:53 --> Pagination Class Initialized
INFO - 2023-09-24 04:12:53 --> Form Validation Class Initialized
INFO - 2023-09-24 04:12:53 --> Controller Class Initialized
INFO - 2023-09-24 04:12:53 --> Model Class Initialized
DEBUG - 2023-09-24 04:12:53 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-09-24 04:12:53 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-24 04:12:53 --> Model Class Initialized
DEBUG - 2023-09-24 04:12:53 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-24 04:12:53 --> Model Class Initialized
INFO - 2023-09-24 04:12:53 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice.php
DEBUG - 2023-09-24 04:12:53 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-09-24 04:12:53 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-09-24 04:12:53 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-09-24 04:12:53 --> Model Class Initialized
INFO - 2023-09-24 04:12:53 --> Model Class Initialized
INFO - 2023-09-24 04:12:53 --> Model Class Initialized
INFO - 2023-09-24 04:12:53 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-09-24 04:12:53 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-09-24 04:12:53 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-09-24 04:12:53 --> Final output sent to browser
DEBUG - 2023-09-24 04:12:53 --> Total execution time: 0.1647
ERROR - 2023-09-24 04:12:54 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-24 04:12:54 --> Config Class Initialized
INFO - 2023-09-24 04:12:54 --> Hooks Class Initialized
DEBUG - 2023-09-24 04:12:54 --> UTF-8 Support Enabled
INFO - 2023-09-24 04:12:54 --> Utf8 Class Initialized
INFO - 2023-09-24 04:12:54 --> URI Class Initialized
INFO - 2023-09-24 04:12:54 --> Router Class Initialized
INFO - 2023-09-24 04:12:54 --> Output Class Initialized
INFO - 2023-09-24 04:12:54 --> Security Class Initialized
DEBUG - 2023-09-24 04:12:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-24 04:12:54 --> Input Class Initialized
INFO - 2023-09-24 04:12:54 --> Language Class Initialized
INFO - 2023-09-24 04:12:54 --> Loader Class Initialized
INFO - 2023-09-24 04:12:54 --> Helper loaded: url_helper
INFO - 2023-09-24 04:12:54 --> Helper loaded: file_helper
INFO - 2023-09-24 04:12:54 --> Helper loaded: html_helper
INFO - 2023-09-24 04:12:54 --> Helper loaded: text_helper
INFO - 2023-09-24 04:12:54 --> Helper loaded: form_helper
INFO - 2023-09-24 04:12:54 --> Helper loaded: lang_helper
INFO - 2023-09-24 04:12:54 --> Helper loaded: security_helper
INFO - 2023-09-24 04:12:54 --> Helper loaded: cookie_helper
INFO - 2023-09-24 04:12:54 --> Database Driver Class Initialized
INFO - 2023-09-24 04:12:54 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-24 04:12:54 --> Parser Class Initialized
INFO - 2023-09-24 04:12:54 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-24 04:12:54 --> Pagination Class Initialized
INFO - 2023-09-24 04:12:54 --> Form Validation Class Initialized
INFO - 2023-09-24 04:12:54 --> Controller Class Initialized
INFO - 2023-09-24 04:12:54 --> Model Class Initialized
DEBUG - 2023-09-24 04:12:54 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-09-24 04:12:54 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-24 04:12:54 --> Model Class Initialized
DEBUG - 2023-09-24 04:12:54 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-24 04:12:54 --> Model Class Initialized
INFO - 2023-09-24 04:12:54 --> Final output sent to browser
DEBUG - 2023-09-24 04:12:54 --> Total execution time: 0.0640
ERROR - 2023-09-24 04:12:56 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-24 04:12:56 --> Config Class Initialized
INFO - 2023-09-24 04:12:56 --> Hooks Class Initialized
DEBUG - 2023-09-24 04:12:56 --> UTF-8 Support Enabled
INFO - 2023-09-24 04:12:56 --> Utf8 Class Initialized
INFO - 2023-09-24 04:12:56 --> URI Class Initialized
INFO - 2023-09-24 04:12:56 --> Router Class Initialized
INFO - 2023-09-24 04:12:56 --> Output Class Initialized
INFO - 2023-09-24 04:12:56 --> Security Class Initialized
DEBUG - 2023-09-24 04:12:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-24 04:12:56 --> Input Class Initialized
INFO - 2023-09-24 04:12:56 --> Language Class Initialized
INFO - 2023-09-24 04:12:56 --> Loader Class Initialized
INFO - 2023-09-24 04:12:56 --> Helper loaded: url_helper
INFO - 2023-09-24 04:12:56 --> Helper loaded: file_helper
INFO - 2023-09-24 04:12:56 --> Helper loaded: html_helper
INFO - 2023-09-24 04:12:56 --> Helper loaded: text_helper
INFO - 2023-09-24 04:12:56 --> Helper loaded: form_helper
INFO - 2023-09-24 04:12:56 --> Helper loaded: lang_helper
INFO - 2023-09-24 04:12:56 --> Helper loaded: security_helper
INFO - 2023-09-24 04:12:56 --> Helper loaded: cookie_helper
INFO - 2023-09-24 04:12:56 --> Database Driver Class Initialized
INFO - 2023-09-24 04:12:56 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-24 04:12:56 --> Parser Class Initialized
INFO - 2023-09-24 04:12:56 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-24 04:12:56 --> Pagination Class Initialized
INFO - 2023-09-24 04:12:56 --> Form Validation Class Initialized
INFO - 2023-09-24 04:12:56 --> Controller Class Initialized
INFO - 2023-09-24 04:12:56 --> Model Class Initialized
DEBUG - 2023-09-24 04:12:56 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-09-24 04:12:56 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-24 04:12:56 --> Model Class Initialized
DEBUG - 2023-09-24 04:12:56 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-24 04:12:56 --> Model Class Initialized
INFO - 2023-09-24 04:12:56 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/add_invoice_form.php
DEBUG - 2023-09-24 04:12:56 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-09-24 04:12:56 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-09-24 04:12:56 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-09-24 04:12:56 --> Model Class Initialized
INFO - 2023-09-24 04:12:56 --> Model Class Initialized
INFO - 2023-09-24 04:12:56 --> Model Class Initialized
INFO - 2023-09-24 04:12:56 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-09-24 04:12:56 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-09-24 04:12:56 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-09-24 04:12:56 --> Final output sent to browser
DEBUG - 2023-09-24 04:12:56 --> Total execution time: 0.2030
ERROR - 2023-09-24 04:13:02 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-24 04:13:02 --> Config Class Initialized
INFO - 2023-09-24 04:13:02 --> Hooks Class Initialized
DEBUG - 2023-09-24 04:13:02 --> UTF-8 Support Enabled
INFO - 2023-09-24 04:13:02 --> Utf8 Class Initialized
INFO - 2023-09-24 04:13:02 --> URI Class Initialized
INFO - 2023-09-24 04:13:02 --> Router Class Initialized
INFO - 2023-09-24 04:13:02 --> Output Class Initialized
INFO - 2023-09-24 04:13:02 --> Security Class Initialized
DEBUG - 2023-09-24 04:13:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-24 04:13:02 --> Input Class Initialized
INFO - 2023-09-24 04:13:02 --> Language Class Initialized
INFO - 2023-09-24 04:13:02 --> Loader Class Initialized
INFO - 2023-09-24 04:13:02 --> Helper loaded: url_helper
INFO - 2023-09-24 04:13:02 --> Helper loaded: file_helper
INFO - 2023-09-24 04:13:02 --> Helper loaded: html_helper
INFO - 2023-09-24 04:13:02 --> Helper loaded: text_helper
INFO - 2023-09-24 04:13:02 --> Helper loaded: form_helper
INFO - 2023-09-24 04:13:02 --> Helper loaded: lang_helper
INFO - 2023-09-24 04:13:02 --> Helper loaded: security_helper
INFO - 2023-09-24 04:13:02 --> Helper loaded: cookie_helper
INFO - 2023-09-24 04:13:02 --> Database Driver Class Initialized
INFO - 2023-09-24 04:13:02 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-24 04:13:02 --> Parser Class Initialized
INFO - 2023-09-24 04:13:02 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-24 04:13:02 --> Pagination Class Initialized
INFO - 2023-09-24 04:13:02 --> Form Validation Class Initialized
INFO - 2023-09-24 04:13:02 --> Controller Class Initialized
INFO - 2023-09-24 04:13:02 --> Model Class Initialized
DEBUG - 2023-09-24 04:13:02 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-24 04:13:02 --> Final output sent to browser
DEBUG - 2023-09-24 04:13:02 --> Total execution time: 0.0175
ERROR - 2023-09-24 04:13:02 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-24 04:13:02 --> Config Class Initialized
INFO - 2023-09-24 04:13:02 --> Hooks Class Initialized
DEBUG - 2023-09-24 04:13:02 --> UTF-8 Support Enabled
INFO - 2023-09-24 04:13:02 --> Utf8 Class Initialized
INFO - 2023-09-24 04:13:02 --> URI Class Initialized
INFO - 2023-09-24 04:13:02 --> Router Class Initialized
INFO - 2023-09-24 04:13:02 --> Output Class Initialized
INFO - 2023-09-24 04:13:02 --> Security Class Initialized
DEBUG - 2023-09-24 04:13:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-24 04:13:02 --> Input Class Initialized
INFO - 2023-09-24 04:13:02 --> Language Class Initialized
INFO - 2023-09-24 04:13:02 --> Loader Class Initialized
INFO - 2023-09-24 04:13:02 --> Helper loaded: url_helper
INFO - 2023-09-24 04:13:02 --> Helper loaded: file_helper
INFO - 2023-09-24 04:13:02 --> Helper loaded: html_helper
INFO - 2023-09-24 04:13:02 --> Helper loaded: text_helper
INFO - 2023-09-24 04:13:02 --> Helper loaded: form_helper
INFO - 2023-09-24 04:13:02 --> Helper loaded: lang_helper
INFO - 2023-09-24 04:13:02 --> Helper loaded: security_helper
INFO - 2023-09-24 04:13:02 --> Helper loaded: cookie_helper
INFO - 2023-09-24 04:13:02 --> Database Driver Class Initialized
INFO - 2023-09-24 04:13:02 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-24 04:13:02 --> Parser Class Initialized
INFO - 2023-09-24 04:13:02 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-24 04:13:02 --> Pagination Class Initialized
INFO - 2023-09-24 04:13:02 --> Form Validation Class Initialized
INFO - 2023-09-24 04:13:02 --> Controller Class Initialized
INFO - 2023-09-24 04:13:02 --> Model Class Initialized
DEBUG - 2023-09-24 04:13:02 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-24 04:13:02 --> Final output sent to browser
DEBUG - 2023-09-24 04:13:02 --> Total execution time: 0.0160
ERROR - 2023-09-24 04:13:04 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-24 04:13:04 --> Config Class Initialized
INFO - 2023-09-24 04:13:04 --> Hooks Class Initialized
DEBUG - 2023-09-24 04:13:04 --> UTF-8 Support Enabled
INFO - 2023-09-24 04:13:04 --> Utf8 Class Initialized
INFO - 2023-09-24 04:13:04 --> URI Class Initialized
INFO - 2023-09-24 04:13:04 --> Router Class Initialized
INFO - 2023-09-24 04:13:04 --> Output Class Initialized
INFO - 2023-09-24 04:13:04 --> Security Class Initialized
DEBUG - 2023-09-24 04:13:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-24 04:13:04 --> Input Class Initialized
INFO - 2023-09-24 04:13:04 --> Language Class Initialized
INFO - 2023-09-24 04:13:04 --> Loader Class Initialized
INFO - 2023-09-24 04:13:04 --> Helper loaded: url_helper
INFO - 2023-09-24 04:13:04 --> Helper loaded: file_helper
INFO - 2023-09-24 04:13:04 --> Helper loaded: html_helper
INFO - 2023-09-24 04:13:04 --> Helper loaded: text_helper
INFO - 2023-09-24 04:13:04 --> Helper loaded: form_helper
INFO - 2023-09-24 04:13:04 --> Helper loaded: lang_helper
INFO - 2023-09-24 04:13:04 --> Helper loaded: security_helper
INFO - 2023-09-24 04:13:04 --> Helper loaded: cookie_helper
INFO - 2023-09-24 04:13:04 --> Database Driver Class Initialized
INFO - 2023-09-24 04:13:04 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-24 04:13:04 --> Parser Class Initialized
INFO - 2023-09-24 04:13:04 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-24 04:13:04 --> Pagination Class Initialized
INFO - 2023-09-24 04:13:04 --> Form Validation Class Initialized
INFO - 2023-09-24 04:13:04 --> Controller Class Initialized
INFO - 2023-09-24 04:13:04 --> Final output sent to browser
DEBUG - 2023-09-24 04:13:04 --> Total execution time: 0.0136
ERROR - 2023-09-24 04:13:07 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-24 04:13:07 --> Config Class Initialized
INFO - 2023-09-24 04:13:07 --> Hooks Class Initialized
DEBUG - 2023-09-24 04:13:07 --> UTF-8 Support Enabled
INFO - 2023-09-24 04:13:07 --> Utf8 Class Initialized
INFO - 2023-09-24 04:13:07 --> URI Class Initialized
INFO - 2023-09-24 04:13:07 --> Router Class Initialized
INFO - 2023-09-24 04:13:07 --> Output Class Initialized
INFO - 2023-09-24 04:13:07 --> Security Class Initialized
DEBUG - 2023-09-24 04:13:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-24 04:13:07 --> Input Class Initialized
INFO - 2023-09-24 04:13:07 --> Language Class Initialized
INFO - 2023-09-24 04:13:07 --> Loader Class Initialized
INFO - 2023-09-24 04:13:07 --> Helper loaded: url_helper
INFO - 2023-09-24 04:13:07 --> Helper loaded: file_helper
INFO - 2023-09-24 04:13:07 --> Helper loaded: html_helper
INFO - 2023-09-24 04:13:07 --> Helper loaded: text_helper
INFO - 2023-09-24 04:13:07 --> Helper loaded: form_helper
INFO - 2023-09-24 04:13:07 --> Helper loaded: lang_helper
INFO - 2023-09-24 04:13:07 --> Helper loaded: security_helper
INFO - 2023-09-24 04:13:07 --> Helper loaded: cookie_helper
INFO - 2023-09-24 04:13:07 --> Database Driver Class Initialized
INFO - 2023-09-24 04:13:07 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-24 04:13:07 --> Parser Class Initialized
INFO - 2023-09-24 04:13:07 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-24 04:13:07 --> Pagination Class Initialized
INFO - 2023-09-24 04:13:07 --> Form Validation Class Initialized
INFO - 2023-09-24 04:13:07 --> Controller Class Initialized
INFO - 2023-09-24 04:13:07 --> Model Class Initialized
DEBUG - 2023-09-24 04:13:07 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-09-24 04:13:07 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-24 04:13:07 --> Model Class Initialized
DEBUG - 2023-09-24 04:13:07 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-24 04:13:07 --> Model Class Initialized
INFO - 2023-09-24 04:13:07 --> Final output sent to browser
DEBUG - 2023-09-24 04:13:07 --> Total execution time: 0.1122
ERROR - 2023-09-24 04:13:07 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-24 04:13:07 --> Config Class Initialized
INFO - 2023-09-24 04:13:07 --> Hooks Class Initialized
DEBUG - 2023-09-24 04:13:07 --> UTF-8 Support Enabled
INFO - 2023-09-24 04:13:07 --> Utf8 Class Initialized
INFO - 2023-09-24 04:13:07 --> URI Class Initialized
INFO - 2023-09-24 04:13:07 --> Router Class Initialized
INFO - 2023-09-24 04:13:07 --> Output Class Initialized
INFO - 2023-09-24 04:13:07 --> Security Class Initialized
DEBUG - 2023-09-24 04:13:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-24 04:13:07 --> Input Class Initialized
INFO - 2023-09-24 04:13:07 --> Language Class Initialized
INFO - 2023-09-24 04:13:07 --> Loader Class Initialized
INFO - 2023-09-24 04:13:07 --> Helper loaded: url_helper
INFO - 2023-09-24 04:13:07 --> Helper loaded: file_helper
INFO - 2023-09-24 04:13:07 --> Helper loaded: html_helper
INFO - 2023-09-24 04:13:07 --> Helper loaded: text_helper
INFO - 2023-09-24 04:13:07 --> Helper loaded: form_helper
INFO - 2023-09-24 04:13:07 --> Helper loaded: lang_helper
INFO - 2023-09-24 04:13:07 --> Helper loaded: security_helper
INFO - 2023-09-24 04:13:07 --> Helper loaded: cookie_helper
INFO - 2023-09-24 04:13:07 --> Database Driver Class Initialized
INFO - 2023-09-24 04:13:07 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-24 04:13:07 --> Parser Class Initialized
INFO - 2023-09-24 04:13:07 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-24 04:13:07 --> Pagination Class Initialized
INFO - 2023-09-24 04:13:07 --> Form Validation Class Initialized
INFO - 2023-09-24 04:13:07 --> Controller Class Initialized
INFO - 2023-09-24 04:13:07 --> Model Class Initialized
DEBUG - 2023-09-24 04:13:07 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-09-24 04:13:07 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-24 04:13:07 --> Model Class Initialized
DEBUG - 2023-09-24 04:13:07 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-24 04:13:07 --> Model Class Initialized
INFO - 2023-09-24 04:13:07 --> Final output sent to browser
DEBUG - 2023-09-24 04:13:07 --> Total execution time: 0.1139
ERROR - 2023-09-24 04:13:08 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-24 04:13:08 --> Config Class Initialized
INFO - 2023-09-24 04:13:08 --> Hooks Class Initialized
DEBUG - 2023-09-24 04:13:08 --> UTF-8 Support Enabled
INFO - 2023-09-24 04:13:08 --> Utf8 Class Initialized
INFO - 2023-09-24 04:13:08 --> URI Class Initialized
INFO - 2023-09-24 04:13:08 --> Router Class Initialized
INFO - 2023-09-24 04:13:08 --> Output Class Initialized
INFO - 2023-09-24 04:13:08 --> Security Class Initialized
DEBUG - 2023-09-24 04:13:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-24 04:13:08 --> Input Class Initialized
INFO - 2023-09-24 04:13:08 --> Language Class Initialized
INFO - 2023-09-24 04:13:08 --> Loader Class Initialized
INFO - 2023-09-24 04:13:08 --> Helper loaded: url_helper
INFO - 2023-09-24 04:13:08 --> Helper loaded: file_helper
INFO - 2023-09-24 04:13:08 --> Helper loaded: html_helper
INFO - 2023-09-24 04:13:08 --> Helper loaded: text_helper
INFO - 2023-09-24 04:13:08 --> Helper loaded: form_helper
INFO - 2023-09-24 04:13:08 --> Helper loaded: lang_helper
INFO - 2023-09-24 04:13:08 --> Helper loaded: security_helper
INFO - 2023-09-24 04:13:08 --> Helper loaded: cookie_helper
INFO - 2023-09-24 04:13:08 --> Database Driver Class Initialized
INFO - 2023-09-24 04:13:08 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-24 04:13:08 --> Parser Class Initialized
INFO - 2023-09-24 04:13:08 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-24 04:13:08 --> Pagination Class Initialized
INFO - 2023-09-24 04:13:08 --> Form Validation Class Initialized
INFO - 2023-09-24 04:13:08 --> Controller Class Initialized
INFO - 2023-09-24 04:13:08 --> Model Class Initialized
DEBUG - 2023-09-24 04:13:08 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-09-24 04:13:08 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-24 04:13:08 --> Model Class Initialized
DEBUG - 2023-09-24 04:13:08 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-24 04:13:08 --> Model Class Initialized
INFO - 2023-09-24 04:13:08 --> Final output sent to browser
DEBUG - 2023-09-24 04:13:08 --> Total execution time: 0.0259
ERROR - 2023-09-24 04:13:27 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-24 04:13:27 --> Config Class Initialized
INFO - 2023-09-24 04:13:27 --> Hooks Class Initialized
DEBUG - 2023-09-24 04:13:27 --> UTF-8 Support Enabled
INFO - 2023-09-24 04:13:27 --> Utf8 Class Initialized
INFO - 2023-09-24 04:13:27 --> URI Class Initialized
INFO - 2023-09-24 04:13:27 --> Router Class Initialized
INFO - 2023-09-24 04:13:27 --> Output Class Initialized
INFO - 2023-09-24 04:13:27 --> Security Class Initialized
DEBUG - 2023-09-24 04:13:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-24 04:13:27 --> Input Class Initialized
INFO - 2023-09-24 04:13:27 --> Language Class Initialized
INFO - 2023-09-24 04:13:27 --> Loader Class Initialized
INFO - 2023-09-24 04:13:27 --> Helper loaded: url_helper
INFO - 2023-09-24 04:13:27 --> Helper loaded: file_helper
INFO - 2023-09-24 04:13:27 --> Helper loaded: html_helper
INFO - 2023-09-24 04:13:27 --> Helper loaded: text_helper
INFO - 2023-09-24 04:13:27 --> Helper loaded: form_helper
INFO - 2023-09-24 04:13:27 --> Helper loaded: lang_helper
INFO - 2023-09-24 04:13:27 --> Helper loaded: security_helper
INFO - 2023-09-24 04:13:27 --> Helper loaded: cookie_helper
INFO - 2023-09-24 04:13:27 --> Database Driver Class Initialized
INFO - 2023-09-24 04:13:27 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-24 04:13:27 --> Parser Class Initialized
INFO - 2023-09-24 04:13:27 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-24 04:13:27 --> Pagination Class Initialized
INFO - 2023-09-24 04:13:27 --> Form Validation Class Initialized
INFO - 2023-09-24 04:13:27 --> Controller Class Initialized
INFO - 2023-09-24 04:13:27 --> Model Class Initialized
DEBUG - 2023-09-24 04:13:27 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-09-24 04:13:27 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-24 04:13:27 --> Model Class Initialized
DEBUG - 2023-09-24 04:13:27 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-24 04:13:27 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/stockrequest/add_stockrequest_form.php
DEBUG - 2023-09-24 04:13:27 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-09-24 04:13:27 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-09-24 04:13:27 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-09-24 04:13:27 --> Model Class Initialized
INFO - 2023-09-24 04:13:27 --> Model Class Initialized
INFO - 2023-09-24 04:13:27 --> Model Class Initialized
INFO - 2023-09-24 04:13:28 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-09-24 04:13:28 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-09-24 04:13:28 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-09-24 04:13:28 --> Final output sent to browser
DEBUG - 2023-09-24 04:13:28 --> Total execution time: 0.1857
ERROR - 2023-09-24 04:13:34 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-24 04:13:34 --> Config Class Initialized
INFO - 2023-09-24 04:13:34 --> Hooks Class Initialized
DEBUG - 2023-09-24 04:13:34 --> UTF-8 Support Enabled
INFO - 2023-09-24 04:13:34 --> Utf8 Class Initialized
INFO - 2023-09-24 04:13:34 --> URI Class Initialized
INFO - 2023-09-24 04:13:34 --> Router Class Initialized
INFO - 2023-09-24 04:13:34 --> Output Class Initialized
INFO - 2023-09-24 04:13:34 --> Security Class Initialized
DEBUG - 2023-09-24 04:13:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-24 04:13:34 --> Input Class Initialized
INFO - 2023-09-24 04:13:34 --> Language Class Initialized
INFO - 2023-09-24 04:13:34 --> Loader Class Initialized
INFO - 2023-09-24 04:13:34 --> Helper loaded: url_helper
INFO - 2023-09-24 04:13:34 --> Helper loaded: file_helper
INFO - 2023-09-24 04:13:34 --> Helper loaded: html_helper
INFO - 2023-09-24 04:13:34 --> Helper loaded: text_helper
INFO - 2023-09-24 04:13:34 --> Helper loaded: form_helper
INFO - 2023-09-24 04:13:34 --> Helper loaded: lang_helper
INFO - 2023-09-24 04:13:34 --> Helper loaded: security_helper
INFO - 2023-09-24 04:13:34 --> Helper loaded: cookie_helper
INFO - 2023-09-24 04:13:34 --> Database Driver Class Initialized
INFO - 2023-09-24 04:13:34 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-24 04:13:34 --> Parser Class Initialized
INFO - 2023-09-24 04:13:34 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-24 04:13:34 --> Pagination Class Initialized
INFO - 2023-09-24 04:13:34 --> Form Validation Class Initialized
INFO - 2023-09-24 04:13:34 --> Controller Class Initialized
INFO - 2023-09-24 04:13:34 --> Model Class Initialized
INFO - 2023-09-24 04:13:34 --> Final output sent to browser
DEBUG - 2023-09-24 04:13:34 --> Total execution time: 0.0310
ERROR - 2023-09-24 04:13:34 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-24 04:13:34 --> Config Class Initialized
INFO - 2023-09-24 04:13:34 --> Hooks Class Initialized
DEBUG - 2023-09-24 04:13:34 --> UTF-8 Support Enabled
INFO - 2023-09-24 04:13:34 --> Utf8 Class Initialized
INFO - 2023-09-24 04:13:34 --> URI Class Initialized
INFO - 2023-09-24 04:13:34 --> Router Class Initialized
INFO - 2023-09-24 04:13:34 --> Output Class Initialized
INFO - 2023-09-24 04:13:34 --> Security Class Initialized
DEBUG - 2023-09-24 04:13:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-24 04:13:34 --> Input Class Initialized
INFO - 2023-09-24 04:13:34 --> Language Class Initialized
INFO - 2023-09-24 04:13:34 --> Loader Class Initialized
INFO - 2023-09-24 04:13:34 --> Helper loaded: url_helper
INFO - 2023-09-24 04:13:34 --> Helper loaded: file_helper
INFO - 2023-09-24 04:13:34 --> Helper loaded: html_helper
INFO - 2023-09-24 04:13:34 --> Helper loaded: text_helper
INFO - 2023-09-24 04:13:34 --> Helper loaded: form_helper
INFO - 2023-09-24 04:13:34 --> Helper loaded: lang_helper
INFO - 2023-09-24 04:13:34 --> Helper loaded: security_helper
INFO - 2023-09-24 04:13:34 --> Helper loaded: cookie_helper
INFO - 2023-09-24 04:13:34 --> Database Driver Class Initialized
INFO - 2023-09-24 04:13:34 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-24 04:13:34 --> Parser Class Initialized
INFO - 2023-09-24 04:13:34 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-24 04:13:34 --> Pagination Class Initialized
INFO - 2023-09-24 04:13:34 --> Form Validation Class Initialized
INFO - 2023-09-24 04:13:34 --> Controller Class Initialized
INFO - 2023-09-24 04:13:34 --> Model Class Initialized
INFO - 2023-09-24 04:13:34 --> Final output sent to browser
DEBUG - 2023-09-24 04:13:34 --> Total execution time: 0.0955
ERROR - 2023-09-24 04:13:35 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-24 04:13:35 --> Config Class Initialized
INFO - 2023-09-24 04:13:35 --> Hooks Class Initialized
DEBUG - 2023-09-24 04:13:35 --> UTF-8 Support Enabled
INFO - 2023-09-24 04:13:35 --> Utf8 Class Initialized
INFO - 2023-09-24 04:13:35 --> URI Class Initialized
INFO - 2023-09-24 04:13:35 --> Router Class Initialized
INFO - 2023-09-24 04:13:35 --> Output Class Initialized
INFO - 2023-09-24 04:13:35 --> Security Class Initialized
DEBUG - 2023-09-24 04:13:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-24 04:13:35 --> Input Class Initialized
INFO - 2023-09-24 04:13:35 --> Language Class Initialized
INFO - 2023-09-24 04:13:35 --> Loader Class Initialized
INFO - 2023-09-24 04:13:35 --> Helper loaded: url_helper
INFO - 2023-09-24 04:13:35 --> Helper loaded: file_helper
INFO - 2023-09-24 04:13:35 --> Helper loaded: html_helper
INFO - 2023-09-24 04:13:35 --> Helper loaded: text_helper
INFO - 2023-09-24 04:13:35 --> Helper loaded: form_helper
INFO - 2023-09-24 04:13:35 --> Helper loaded: lang_helper
INFO - 2023-09-24 04:13:35 --> Helper loaded: security_helper
INFO - 2023-09-24 04:13:35 --> Helper loaded: cookie_helper
INFO - 2023-09-24 04:13:35 --> Database Driver Class Initialized
INFO - 2023-09-24 04:13:35 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-24 04:13:35 --> Parser Class Initialized
INFO - 2023-09-24 04:13:35 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-24 04:13:35 --> Pagination Class Initialized
INFO - 2023-09-24 04:13:35 --> Form Validation Class Initialized
INFO - 2023-09-24 04:13:35 --> Controller Class Initialized
INFO - 2023-09-24 04:13:35 --> Model Class Initialized
ERROR - 2023-09-24 04:13:35 --> Severity: Warning --> Invalid argument supplied for foreach() /home/powera7m/app.maurnaturo.com/application/controllers/Cstockrequest.php 204
INFO - 2023-09-24 04:13:35 --> Final output sent to browser
DEBUG - 2023-09-24 04:13:35 --> Total execution time: 0.0134
ERROR - 2023-09-24 04:13:37 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-24 04:13:37 --> Config Class Initialized
INFO - 2023-09-24 04:13:37 --> Hooks Class Initialized
DEBUG - 2023-09-24 04:13:37 --> UTF-8 Support Enabled
INFO - 2023-09-24 04:13:37 --> Utf8 Class Initialized
INFO - 2023-09-24 04:13:37 --> URI Class Initialized
INFO - 2023-09-24 04:13:37 --> Router Class Initialized
INFO - 2023-09-24 04:13:37 --> Output Class Initialized
INFO - 2023-09-24 04:13:37 --> Security Class Initialized
DEBUG - 2023-09-24 04:13:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-24 04:13:37 --> Input Class Initialized
INFO - 2023-09-24 04:13:37 --> Language Class Initialized
INFO - 2023-09-24 04:13:37 --> Loader Class Initialized
INFO - 2023-09-24 04:13:37 --> Helper loaded: url_helper
INFO - 2023-09-24 04:13:37 --> Helper loaded: file_helper
INFO - 2023-09-24 04:13:37 --> Helper loaded: html_helper
INFO - 2023-09-24 04:13:37 --> Helper loaded: text_helper
INFO - 2023-09-24 04:13:37 --> Helper loaded: form_helper
INFO - 2023-09-24 04:13:37 --> Helper loaded: lang_helper
INFO - 2023-09-24 04:13:37 --> Helper loaded: security_helper
INFO - 2023-09-24 04:13:37 --> Helper loaded: cookie_helper
INFO - 2023-09-24 04:13:37 --> Database Driver Class Initialized
INFO - 2023-09-24 04:13:37 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-24 04:13:37 --> Parser Class Initialized
INFO - 2023-09-24 04:13:37 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-24 04:13:37 --> Pagination Class Initialized
INFO - 2023-09-24 04:13:37 --> Form Validation Class Initialized
INFO - 2023-09-24 04:13:37 --> Controller Class Initialized
INFO - 2023-09-24 04:13:37 --> Model Class Initialized
ERROR - 2023-09-24 04:13:37 --> Severity: Warning --> Invalid argument supplied for foreach() /home/powera7m/app.maurnaturo.com/application/controllers/Cstockrequest.php 204
INFO - 2023-09-24 04:13:37 --> Final output sent to browser
DEBUG - 2023-09-24 04:13:37 --> Total execution time: 0.0137
ERROR - 2023-09-24 04:13:39 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-24 04:13:39 --> Config Class Initialized
INFO - 2023-09-24 04:13:39 --> Hooks Class Initialized
DEBUG - 2023-09-24 04:13:39 --> UTF-8 Support Enabled
INFO - 2023-09-24 04:13:39 --> Utf8 Class Initialized
INFO - 2023-09-24 04:13:39 --> URI Class Initialized
INFO - 2023-09-24 04:13:39 --> Router Class Initialized
INFO - 2023-09-24 04:13:39 --> Output Class Initialized
INFO - 2023-09-24 04:13:39 --> Security Class Initialized
DEBUG - 2023-09-24 04:13:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-24 04:13:39 --> Input Class Initialized
INFO - 2023-09-24 04:13:39 --> Language Class Initialized
INFO - 2023-09-24 04:13:39 --> Loader Class Initialized
INFO - 2023-09-24 04:13:39 --> Helper loaded: url_helper
INFO - 2023-09-24 04:13:39 --> Helper loaded: file_helper
INFO - 2023-09-24 04:13:39 --> Helper loaded: html_helper
INFO - 2023-09-24 04:13:39 --> Helper loaded: text_helper
INFO - 2023-09-24 04:13:39 --> Helper loaded: form_helper
INFO - 2023-09-24 04:13:39 --> Helper loaded: lang_helper
INFO - 2023-09-24 04:13:39 --> Helper loaded: security_helper
INFO - 2023-09-24 04:13:39 --> Helper loaded: cookie_helper
INFO - 2023-09-24 04:13:39 --> Database Driver Class Initialized
INFO - 2023-09-24 04:13:39 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-24 04:13:39 --> Parser Class Initialized
INFO - 2023-09-24 04:13:39 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-24 04:13:39 --> Pagination Class Initialized
INFO - 2023-09-24 04:13:39 --> Form Validation Class Initialized
INFO - 2023-09-24 04:13:39 --> Controller Class Initialized
INFO - 2023-09-24 04:13:39 --> Model Class Initialized
INFO - 2023-09-24 04:13:39 --> Final output sent to browser
DEBUG - 2023-09-24 04:13:39 --> Total execution time: 0.0132
ERROR - 2023-09-24 04:13:39 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-24 04:13:39 --> Config Class Initialized
INFO - 2023-09-24 04:13:39 --> Hooks Class Initialized
DEBUG - 2023-09-24 04:13:39 --> UTF-8 Support Enabled
INFO - 2023-09-24 04:13:39 --> Utf8 Class Initialized
INFO - 2023-09-24 04:13:39 --> URI Class Initialized
INFO - 2023-09-24 04:13:39 --> Router Class Initialized
INFO - 2023-09-24 04:13:39 --> Output Class Initialized
INFO - 2023-09-24 04:13:39 --> Security Class Initialized
DEBUG - 2023-09-24 04:13:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-24 04:13:39 --> Input Class Initialized
INFO - 2023-09-24 04:13:39 --> Language Class Initialized
INFO - 2023-09-24 04:13:39 --> Loader Class Initialized
INFO - 2023-09-24 04:13:39 --> Helper loaded: url_helper
INFO - 2023-09-24 04:13:39 --> Helper loaded: file_helper
INFO - 2023-09-24 04:13:39 --> Helper loaded: html_helper
INFO - 2023-09-24 04:13:39 --> Helper loaded: text_helper
INFO - 2023-09-24 04:13:39 --> Helper loaded: form_helper
INFO - 2023-09-24 04:13:39 --> Helper loaded: lang_helper
INFO - 2023-09-24 04:13:39 --> Helper loaded: security_helper
INFO - 2023-09-24 04:13:39 --> Helper loaded: cookie_helper
INFO - 2023-09-24 04:13:39 --> Database Driver Class Initialized
INFO - 2023-09-24 04:13:39 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-24 04:13:39 --> Parser Class Initialized
INFO - 2023-09-24 04:13:39 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-24 04:13:39 --> Pagination Class Initialized
INFO - 2023-09-24 04:13:39 --> Form Validation Class Initialized
INFO - 2023-09-24 04:13:39 --> Controller Class Initialized
INFO - 2023-09-24 04:13:39 --> Model Class Initialized
INFO - 2023-09-24 04:13:39 --> Final output sent to browser
DEBUG - 2023-09-24 04:13:39 --> Total execution time: 0.0145
ERROR - 2023-09-24 04:13:44 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-24 04:13:44 --> Config Class Initialized
INFO - 2023-09-24 04:13:44 --> Hooks Class Initialized
DEBUG - 2023-09-24 04:13:44 --> UTF-8 Support Enabled
INFO - 2023-09-24 04:13:44 --> Utf8 Class Initialized
INFO - 2023-09-24 04:13:44 --> URI Class Initialized
INFO - 2023-09-24 04:13:44 --> Router Class Initialized
INFO - 2023-09-24 04:13:44 --> Output Class Initialized
INFO - 2023-09-24 04:13:44 --> Security Class Initialized
DEBUG - 2023-09-24 04:13:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-24 04:13:44 --> Input Class Initialized
INFO - 2023-09-24 04:13:44 --> Language Class Initialized
INFO - 2023-09-24 04:13:44 --> Loader Class Initialized
INFO - 2023-09-24 04:13:44 --> Helper loaded: url_helper
INFO - 2023-09-24 04:13:44 --> Helper loaded: file_helper
INFO - 2023-09-24 04:13:44 --> Helper loaded: html_helper
INFO - 2023-09-24 04:13:44 --> Helper loaded: text_helper
INFO - 2023-09-24 04:13:44 --> Helper loaded: form_helper
INFO - 2023-09-24 04:13:44 --> Helper loaded: lang_helper
INFO - 2023-09-24 04:13:44 --> Helper loaded: security_helper
INFO - 2023-09-24 04:13:44 --> Helper loaded: cookie_helper
INFO - 2023-09-24 04:13:44 --> Database Driver Class Initialized
INFO - 2023-09-24 04:13:44 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-24 04:13:44 --> Parser Class Initialized
INFO - 2023-09-24 04:13:44 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-24 04:13:44 --> Pagination Class Initialized
INFO - 2023-09-24 04:13:44 --> Form Validation Class Initialized
INFO - 2023-09-24 04:13:44 --> Controller Class Initialized
INFO - 2023-09-24 04:13:44 --> Model Class Initialized
DEBUG - 2023-09-24 04:13:44 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-09-24 04:13:44 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-24 04:13:44 --> Model Class Initialized
DEBUG - 2023-09-24 04:13:44 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-24 04:13:44 --> Model Class Initialized
INFO - 2023-09-24 04:13:44 --> Final output sent to browser
DEBUG - 2023-09-24 04:13:44 --> Total execution time: 0.0223
ERROR - 2023-09-24 04:13:45 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-24 04:13:45 --> Config Class Initialized
INFO - 2023-09-24 04:13:45 --> Hooks Class Initialized
DEBUG - 2023-09-24 04:13:45 --> UTF-8 Support Enabled
INFO - 2023-09-24 04:13:45 --> Utf8 Class Initialized
INFO - 2023-09-24 04:13:45 --> URI Class Initialized
INFO - 2023-09-24 04:13:45 --> Router Class Initialized
INFO - 2023-09-24 04:13:45 --> Output Class Initialized
INFO - 2023-09-24 04:13:45 --> Security Class Initialized
DEBUG - 2023-09-24 04:13:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-24 04:13:45 --> Input Class Initialized
INFO - 2023-09-24 04:13:45 --> Language Class Initialized
INFO - 2023-09-24 04:13:45 --> Loader Class Initialized
INFO - 2023-09-24 04:13:45 --> Helper loaded: url_helper
INFO - 2023-09-24 04:13:45 --> Helper loaded: file_helper
INFO - 2023-09-24 04:13:45 --> Helper loaded: html_helper
INFO - 2023-09-24 04:13:45 --> Helper loaded: text_helper
INFO - 2023-09-24 04:13:45 --> Helper loaded: form_helper
INFO - 2023-09-24 04:13:45 --> Helper loaded: lang_helper
INFO - 2023-09-24 04:13:45 --> Helper loaded: security_helper
INFO - 2023-09-24 04:13:45 --> Helper loaded: cookie_helper
INFO - 2023-09-24 04:13:45 --> Database Driver Class Initialized
INFO - 2023-09-24 04:13:45 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-24 04:13:45 --> Parser Class Initialized
INFO - 2023-09-24 04:13:45 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-24 04:13:45 --> Pagination Class Initialized
INFO - 2023-09-24 04:13:45 --> Form Validation Class Initialized
INFO - 2023-09-24 04:13:45 --> Controller Class Initialized
INFO - 2023-09-24 04:13:45 --> Model Class Initialized
DEBUG - 2023-09-24 04:13:45 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-09-24 04:13:45 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-24 04:13:45 --> Model Class Initialized
DEBUG - 2023-09-24 04:13:45 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-24 04:13:45 --> Model Class Initialized
INFO - 2023-09-24 04:13:45 --> Final output sent to browser
DEBUG - 2023-09-24 04:13:45 --> Total execution time: 0.0196
ERROR - 2023-09-24 04:13:45 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-24 04:13:45 --> Config Class Initialized
INFO - 2023-09-24 04:13:45 --> Hooks Class Initialized
DEBUG - 2023-09-24 04:13:45 --> UTF-8 Support Enabled
INFO - 2023-09-24 04:13:45 --> Utf8 Class Initialized
INFO - 2023-09-24 04:13:45 --> URI Class Initialized
INFO - 2023-09-24 04:13:45 --> Router Class Initialized
INFO - 2023-09-24 04:13:45 --> Output Class Initialized
INFO - 2023-09-24 04:13:45 --> Security Class Initialized
DEBUG - 2023-09-24 04:13:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-24 04:13:45 --> Input Class Initialized
INFO - 2023-09-24 04:13:45 --> Language Class Initialized
INFO - 2023-09-24 04:13:45 --> Loader Class Initialized
INFO - 2023-09-24 04:13:45 --> Helper loaded: url_helper
INFO - 2023-09-24 04:13:45 --> Helper loaded: file_helper
INFO - 2023-09-24 04:13:45 --> Helper loaded: html_helper
INFO - 2023-09-24 04:13:45 --> Helper loaded: text_helper
INFO - 2023-09-24 04:13:45 --> Helper loaded: form_helper
INFO - 2023-09-24 04:13:45 --> Helper loaded: lang_helper
INFO - 2023-09-24 04:13:45 --> Helper loaded: security_helper
INFO - 2023-09-24 04:13:45 --> Helper loaded: cookie_helper
INFO - 2023-09-24 04:13:45 --> Database Driver Class Initialized
INFO - 2023-09-24 04:13:45 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-24 04:13:45 --> Parser Class Initialized
INFO - 2023-09-24 04:13:45 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-24 04:13:45 --> Pagination Class Initialized
INFO - 2023-09-24 04:13:45 --> Form Validation Class Initialized
INFO - 2023-09-24 04:13:45 --> Controller Class Initialized
INFO - 2023-09-24 04:13:45 --> Model Class Initialized
DEBUG - 2023-09-24 04:13:45 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-09-24 04:13:45 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-24 04:13:45 --> Model Class Initialized
DEBUG - 2023-09-24 04:13:45 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-24 04:13:45 --> Model Class Initialized
INFO - 2023-09-24 04:13:45 --> Final output sent to browser
DEBUG - 2023-09-24 04:13:45 --> Total execution time: 0.0209
ERROR - 2023-09-24 04:13:46 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-24 04:13:46 --> Config Class Initialized
INFO - 2023-09-24 04:13:46 --> Hooks Class Initialized
DEBUG - 2023-09-24 04:13:46 --> UTF-8 Support Enabled
INFO - 2023-09-24 04:13:46 --> Utf8 Class Initialized
INFO - 2023-09-24 04:13:46 --> URI Class Initialized
INFO - 2023-09-24 04:13:46 --> Router Class Initialized
INFO - 2023-09-24 04:13:46 --> Output Class Initialized
INFO - 2023-09-24 04:13:46 --> Security Class Initialized
DEBUG - 2023-09-24 04:13:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-24 04:13:46 --> Input Class Initialized
INFO - 2023-09-24 04:13:46 --> Language Class Initialized
INFO - 2023-09-24 04:13:46 --> Loader Class Initialized
INFO - 2023-09-24 04:13:46 --> Helper loaded: url_helper
INFO - 2023-09-24 04:13:46 --> Helper loaded: file_helper
INFO - 2023-09-24 04:13:46 --> Helper loaded: html_helper
INFO - 2023-09-24 04:13:46 --> Helper loaded: text_helper
INFO - 2023-09-24 04:13:46 --> Helper loaded: form_helper
INFO - 2023-09-24 04:13:46 --> Helper loaded: lang_helper
INFO - 2023-09-24 04:13:46 --> Helper loaded: security_helper
INFO - 2023-09-24 04:13:46 --> Helper loaded: cookie_helper
INFO - 2023-09-24 04:13:46 --> Database Driver Class Initialized
INFO - 2023-09-24 04:13:46 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-24 04:13:46 --> Parser Class Initialized
INFO - 2023-09-24 04:13:46 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-24 04:13:46 --> Pagination Class Initialized
INFO - 2023-09-24 04:13:46 --> Form Validation Class Initialized
INFO - 2023-09-24 04:13:46 --> Controller Class Initialized
INFO - 2023-09-24 04:13:46 --> Model Class Initialized
DEBUG - 2023-09-24 04:13:46 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-09-24 04:13:46 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-24 04:13:46 --> Model Class Initialized
DEBUG - 2023-09-24 04:13:46 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-24 04:13:46 --> Model Class Initialized
INFO - 2023-09-24 04:13:46 --> Final output sent to browser
DEBUG - 2023-09-24 04:13:46 --> Total execution time: 0.0183
ERROR - 2023-09-24 04:13:48 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-24 04:13:48 --> Config Class Initialized
INFO - 2023-09-24 04:13:48 --> Hooks Class Initialized
DEBUG - 2023-09-24 04:13:48 --> UTF-8 Support Enabled
INFO - 2023-09-24 04:13:48 --> Utf8 Class Initialized
INFO - 2023-09-24 04:13:48 --> URI Class Initialized
INFO - 2023-09-24 04:13:48 --> Router Class Initialized
INFO - 2023-09-24 04:13:48 --> Output Class Initialized
INFO - 2023-09-24 04:13:48 --> Security Class Initialized
DEBUG - 2023-09-24 04:13:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-24 04:13:48 --> Input Class Initialized
INFO - 2023-09-24 04:13:48 --> Language Class Initialized
INFO - 2023-09-24 04:13:48 --> Loader Class Initialized
INFO - 2023-09-24 04:13:48 --> Helper loaded: url_helper
INFO - 2023-09-24 04:13:48 --> Helper loaded: file_helper
INFO - 2023-09-24 04:13:48 --> Helper loaded: html_helper
INFO - 2023-09-24 04:13:48 --> Helper loaded: text_helper
INFO - 2023-09-24 04:13:48 --> Helper loaded: form_helper
INFO - 2023-09-24 04:13:48 --> Helper loaded: lang_helper
INFO - 2023-09-24 04:13:48 --> Helper loaded: security_helper
INFO - 2023-09-24 04:13:48 --> Helper loaded: cookie_helper
INFO - 2023-09-24 04:13:48 --> Database Driver Class Initialized
INFO - 2023-09-24 04:13:48 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-24 04:13:48 --> Parser Class Initialized
INFO - 2023-09-24 04:13:48 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-24 04:13:48 --> Pagination Class Initialized
INFO - 2023-09-24 04:13:48 --> Form Validation Class Initialized
INFO - 2023-09-24 04:13:48 --> Controller Class Initialized
INFO - 2023-09-24 04:13:48 --> Model Class Initialized
DEBUG - 2023-09-24 04:13:48 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-09-24 04:13:48 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-24 04:13:48 --> Model Class Initialized
DEBUG - 2023-09-24 04:13:48 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-24 04:13:48 --> Model Class Initialized
INFO - 2023-09-24 04:13:48 --> Model Class Initialized
INFO - 2023-09-24 04:13:48 --> Final output sent to browser
DEBUG - 2023-09-24 04:13:48 --> Total execution time: 0.0216
ERROR - 2023-09-24 04:13:50 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-24 04:13:50 --> Config Class Initialized
INFO - 2023-09-24 04:13:50 --> Hooks Class Initialized
DEBUG - 2023-09-24 04:13:50 --> UTF-8 Support Enabled
INFO - 2023-09-24 04:13:50 --> Utf8 Class Initialized
INFO - 2023-09-24 04:13:50 --> URI Class Initialized
INFO - 2023-09-24 04:13:50 --> Router Class Initialized
INFO - 2023-09-24 04:13:50 --> Output Class Initialized
INFO - 2023-09-24 04:13:50 --> Security Class Initialized
DEBUG - 2023-09-24 04:13:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-24 04:13:50 --> Input Class Initialized
INFO - 2023-09-24 04:13:50 --> Language Class Initialized
INFO - 2023-09-24 04:13:50 --> Loader Class Initialized
INFO - 2023-09-24 04:13:50 --> Helper loaded: url_helper
INFO - 2023-09-24 04:13:50 --> Helper loaded: file_helper
INFO - 2023-09-24 04:13:50 --> Helper loaded: html_helper
INFO - 2023-09-24 04:13:50 --> Helper loaded: text_helper
INFO - 2023-09-24 04:13:50 --> Helper loaded: form_helper
INFO - 2023-09-24 04:13:50 --> Helper loaded: lang_helper
INFO - 2023-09-24 04:13:50 --> Helper loaded: security_helper
INFO - 2023-09-24 04:13:50 --> Helper loaded: cookie_helper
INFO - 2023-09-24 04:13:50 --> Database Driver Class Initialized
INFO - 2023-09-24 04:13:50 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-24 04:13:50 --> Parser Class Initialized
INFO - 2023-09-24 04:13:50 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-24 04:13:50 --> Pagination Class Initialized
INFO - 2023-09-24 04:13:50 --> Form Validation Class Initialized
INFO - 2023-09-24 04:13:50 --> Controller Class Initialized
INFO - 2023-09-24 04:13:50 --> Model Class Initialized
DEBUG - 2023-09-24 04:13:50 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-09-24 04:13:50 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-24 04:13:50 --> Model Class Initialized
DEBUG - 2023-09-24 04:13:50 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-24 04:13:50 --> Model Class Initialized
INFO - 2023-09-24 04:13:50 --> Final output sent to browser
DEBUG - 2023-09-24 04:13:50 --> Total execution time: 0.0183
ERROR - 2023-09-24 04:13:57 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-24 04:13:57 --> Config Class Initialized
INFO - 2023-09-24 04:13:57 --> Hooks Class Initialized
DEBUG - 2023-09-24 04:13:57 --> UTF-8 Support Enabled
INFO - 2023-09-24 04:13:57 --> Utf8 Class Initialized
INFO - 2023-09-24 04:13:57 --> URI Class Initialized
INFO - 2023-09-24 04:13:57 --> Router Class Initialized
INFO - 2023-09-24 04:13:57 --> Output Class Initialized
INFO - 2023-09-24 04:13:57 --> Security Class Initialized
DEBUG - 2023-09-24 04:13:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-24 04:13:57 --> Input Class Initialized
INFO - 2023-09-24 04:13:57 --> Language Class Initialized
INFO - 2023-09-24 04:13:57 --> Loader Class Initialized
INFO - 2023-09-24 04:13:57 --> Helper loaded: url_helper
INFO - 2023-09-24 04:13:57 --> Helper loaded: file_helper
INFO - 2023-09-24 04:13:57 --> Helper loaded: html_helper
INFO - 2023-09-24 04:13:57 --> Helper loaded: text_helper
INFO - 2023-09-24 04:13:57 --> Helper loaded: form_helper
INFO - 2023-09-24 04:13:57 --> Helper loaded: lang_helper
INFO - 2023-09-24 04:13:57 --> Helper loaded: security_helper
INFO - 2023-09-24 04:13:57 --> Helper loaded: cookie_helper
INFO - 2023-09-24 04:13:57 --> Database Driver Class Initialized
INFO - 2023-09-24 04:13:57 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-24 04:13:57 --> Parser Class Initialized
INFO - 2023-09-24 04:13:57 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-24 04:13:57 --> Pagination Class Initialized
INFO - 2023-09-24 04:13:57 --> Form Validation Class Initialized
INFO - 2023-09-24 04:13:57 --> Controller Class Initialized
INFO - 2023-09-24 04:13:57 --> Model Class Initialized
DEBUG - 2023-09-24 04:13:57 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-09-24 04:13:57 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-24 04:13:57 --> Model Class Initialized
INFO - 2023-09-24 04:13:57 --> Email Class Initialized
INFO - 2023-09-24 04:13:57 --> Language file loaded: language/english/email_lang.php
ERROR - 2023-09-24 04:13:57 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-24 04:13:57 --> Config Class Initialized
INFO - 2023-09-24 04:13:57 --> Hooks Class Initialized
DEBUG - 2023-09-24 04:13:57 --> UTF-8 Support Enabled
INFO - 2023-09-24 04:13:57 --> Utf8 Class Initialized
INFO - 2023-09-24 04:13:57 --> URI Class Initialized
INFO - 2023-09-24 04:13:57 --> Router Class Initialized
INFO - 2023-09-24 04:13:57 --> Output Class Initialized
INFO - 2023-09-24 04:13:57 --> Security Class Initialized
DEBUG - 2023-09-24 04:13:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-24 04:13:57 --> Input Class Initialized
INFO - 2023-09-24 04:13:57 --> Language Class Initialized
INFO - 2023-09-24 04:13:57 --> Loader Class Initialized
INFO - 2023-09-24 04:13:57 --> Helper loaded: url_helper
INFO - 2023-09-24 04:13:57 --> Helper loaded: file_helper
INFO - 2023-09-24 04:13:57 --> Helper loaded: html_helper
INFO - 2023-09-24 04:13:57 --> Helper loaded: text_helper
INFO - 2023-09-24 04:13:57 --> Helper loaded: form_helper
INFO - 2023-09-24 04:13:57 --> Helper loaded: lang_helper
INFO - 2023-09-24 04:13:57 --> Helper loaded: security_helper
INFO - 2023-09-24 04:13:57 --> Helper loaded: cookie_helper
INFO - 2023-09-24 04:13:57 --> Database Driver Class Initialized
INFO - 2023-09-24 04:13:57 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-24 04:13:57 --> Parser Class Initialized
INFO - 2023-09-24 04:13:57 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-24 04:13:57 --> Pagination Class Initialized
INFO - 2023-09-24 04:13:57 --> Form Validation Class Initialized
INFO - 2023-09-24 04:13:57 --> Controller Class Initialized
INFO - 2023-09-24 04:13:57 --> Model Class Initialized
DEBUG - 2023-09-24 04:13:57 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-09-24 04:13:57 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-24 04:13:57 --> Model Class Initialized
DEBUG - 2023-09-24 04:13:57 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-24 04:13:57 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/stockrequest/stockrequest_html.php
DEBUG - 2023-09-24 04:13:57 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-09-24 04:13:57 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-09-24 04:13:57 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-09-24 04:13:57 --> Model Class Initialized
INFO - 2023-09-24 04:13:57 --> Model Class Initialized
INFO - 2023-09-24 04:13:57 --> Model Class Initialized
INFO - 2023-09-24 04:13:57 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-09-24 04:13:57 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-09-24 04:13:57 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-09-24 04:13:57 --> Final output sent to browser
DEBUG - 2023-09-24 04:13:57 --> Total execution time: 0.1922
ERROR - 2023-09-24 04:14:13 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-24 04:14:13 --> Config Class Initialized
INFO - 2023-09-24 04:14:13 --> Hooks Class Initialized
DEBUG - 2023-09-24 04:14:13 --> UTF-8 Support Enabled
INFO - 2023-09-24 04:14:13 --> Utf8 Class Initialized
INFO - 2023-09-24 04:14:13 --> URI Class Initialized
DEBUG - 2023-09-24 04:14:13 --> No URI present. Default controller set.
INFO - 2023-09-24 04:14:13 --> Router Class Initialized
INFO - 2023-09-24 04:14:13 --> Output Class Initialized
INFO - 2023-09-24 04:14:13 --> Security Class Initialized
DEBUG - 2023-09-24 04:14:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-24 04:14:13 --> Input Class Initialized
INFO - 2023-09-24 04:14:13 --> Language Class Initialized
INFO - 2023-09-24 04:14:13 --> Loader Class Initialized
INFO - 2023-09-24 04:14:13 --> Helper loaded: url_helper
INFO - 2023-09-24 04:14:13 --> Helper loaded: file_helper
INFO - 2023-09-24 04:14:13 --> Helper loaded: html_helper
INFO - 2023-09-24 04:14:13 --> Helper loaded: text_helper
INFO - 2023-09-24 04:14:13 --> Helper loaded: form_helper
INFO - 2023-09-24 04:14:13 --> Helper loaded: lang_helper
INFO - 2023-09-24 04:14:13 --> Helper loaded: security_helper
INFO - 2023-09-24 04:14:13 --> Helper loaded: cookie_helper
INFO - 2023-09-24 04:14:13 --> Database Driver Class Initialized
INFO - 2023-09-24 04:14:13 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-24 04:14:13 --> Parser Class Initialized
INFO - 2023-09-24 04:14:13 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-24 04:14:13 --> Pagination Class Initialized
INFO - 2023-09-24 04:14:13 --> Form Validation Class Initialized
INFO - 2023-09-24 04:14:13 --> Controller Class Initialized
INFO - 2023-09-24 04:14:13 --> Model Class Initialized
DEBUG - 2023-09-24 04:14:13 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-24 04:14:13 --> Model Class Initialized
DEBUG - 2023-09-24 04:14:13 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-24 04:14:13 --> Model Class Initialized
INFO - 2023-09-24 04:14:13 --> Model Class Initialized
INFO - 2023-09-24 04:14:13 --> Model Class Initialized
INFO - 2023-09-24 04:14:14 --> Model Class Initialized
DEBUG - 2023-09-24 04:14:14 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-09-24 04:14:14 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-24 04:14:14 --> Model Class Initialized
INFO - 2023-09-24 04:14:14 --> Model Class Initialized
INFO - 2023-09-24 04:14:14 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-09-24 04:14:14 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-09-24 04:14:14 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-09-24 04:14:14 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-09-24 04:14:14 --> Model Class Initialized
INFO - 2023-09-24 04:14:14 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-09-24 04:14:14 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-09-24 04:14:14 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-09-24 04:14:14 --> Final output sent to browser
DEBUG - 2023-09-24 04:14:14 --> Total execution time: 0.1253
ERROR - 2023-09-24 04:14:45 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-24 04:14:45 --> Config Class Initialized
INFO - 2023-09-24 04:14:45 --> Hooks Class Initialized
DEBUG - 2023-09-24 04:14:45 --> UTF-8 Support Enabled
INFO - 2023-09-24 04:14:45 --> Utf8 Class Initialized
INFO - 2023-09-24 04:14:45 --> URI Class Initialized
INFO - 2023-09-24 04:14:45 --> Router Class Initialized
INFO - 2023-09-24 04:14:45 --> Output Class Initialized
INFO - 2023-09-24 04:14:45 --> Security Class Initialized
DEBUG - 2023-09-24 04:14:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-24 04:14:45 --> Input Class Initialized
INFO - 2023-09-24 04:14:45 --> Language Class Initialized
INFO - 2023-09-24 04:14:45 --> Loader Class Initialized
INFO - 2023-09-24 04:14:45 --> Helper loaded: url_helper
INFO - 2023-09-24 04:14:45 --> Helper loaded: file_helper
INFO - 2023-09-24 04:14:45 --> Helper loaded: html_helper
INFO - 2023-09-24 04:14:45 --> Helper loaded: text_helper
INFO - 2023-09-24 04:14:45 --> Helper loaded: form_helper
INFO - 2023-09-24 04:14:45 --> Helper loaded: lang_helper
INFO - 2023-09-24 04:14:45 --> Helper loaded: security_helper
INFO - 2023-09-24 04:14:45 --> Helper loaded: cookie_helper
INFO - 2023-09-24 04:14:45 --> Database Driver Class Initialized
INFO - 2023-09-24 04:14:45 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-24 04:14:45 --> Parser Class Initialized
INFO - 2023-09-24 04:14:45 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-24 04:14:45 --> Pagination Class Initialized
INFO - 2023-09-24 04:14:45 --> Form Validation Class Initialized
INFO - 2023-09-24 04:14:45 --> Controller Class Initialized
INFO - 2023-09-24 04:14:45 --> Model Class Initialized
DEBUG - 2023-09-24 04:14:45 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-09-24 04:14:45 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-24 04:14:45 --> Model Class Initialized
INFO - 2023-09-24 04:14:45 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/demandrequest/customer_demandrequest.php
DEBUG - 2023-09-24 04:14:45 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-09-24 04:14:45 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-09-24 04:14:45 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-09-24 04:14:45 --> Model Class Initialized
INFO - 2023-09-24 04:14:45 --> Model Class Initialized
INFO - 2023-09-24 04:14:45 --> Model Class Initialized
INFO - 2023-09-24 04:14:45 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-09-24 04:14:45 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-09-24 04:14:45 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-09-24 04:14:45 --> Final output sent to browser
DEBUG - 2023-09-24 04:14:45 --> Total execution time: 0.0945
ERROR - 2023-09-24 04:14:45 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-24 04:14:45 --> Config Class Initialized
INFO - 2023-09-24 04:14:45 --> Hooks Class Initialized
DEBUG - 2023-09-24 04:14:45 --> UTF-8 Support Enabled
INFO - 2023-09-24 04:14:45 --> Utf8 Class Initialized
INFO - 2023-09-24 04:14:45 --> URI Class Initialized
INFO - 2023-09-24 04:14:45 --> Router Class Initialized
INFO - 2023-09-24 04:14:45 --> Output Class Initialized
INFO - 2023-09-24 04:14:45 --> Security Class Initialized
DEBUG - 2023-09-24 04:14:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-24 04:14:45 --> Input Class Initialized
INFO - 2023-09-24 04:14:45 --> Language Class Initialized
INFO - 2023-09-24 04:14:45 --> Loader Class Initialized
INFO - 2023-09-24 04:14:45 --> Helper loaded: url_helper
INFO - 2023-09-24 04:14:45 --> Helper loaded: file_helper
INFO - 2023-09-24 04:14:45 --> Helper loaded: html_helper
INFO - 2023-09-24 04:14:45 --> Helper loaded: text_helper
INFO - 2023-09-24 04:14:45 --> Helper loaded: form_helper
INFO - 2023-09-24 04:14:45 --> Helper loaded: lang_helper
INFO - 2023-09-24 04:14:45 --> Helper loaded: security_helper
INFO - 2023-09-24 04:14:45 --> Helper loaded: cookie_helper
INFO - 2023-09-24 04:14:45 --> Database Driver Class Initialized
INFO - 2023-09-24 04:14:45 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-24 04:14:45 --> Parser Class Initialized
INFO - 2023-09-24 04:14:45 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-24 04:14:45 --> Pagination Class Initialized
INFO - 2023-09-24 04:14:45 --> Form Validation Class Initialized
INFO - 2023-09-24 04:14:45 --> Controller Class Initialized
INFO - 2023-09-24 04:14:45 --> Model Class Initialized
DEBUG - 2023-09-24 04:14:45 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-09-24 04:14:45 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-24 04:14:45 --> Model Class Initialized
INFO - 2023-09-24 04:14:45 --> Final output sent to browser
DEBUG - 2023-09-24 04:14:45 --> Total execution time: 0.0176
ERROR - 2023-09-24 04:14:53 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-24 04:14:53 --> Config Class Initialized
INFO - 2023-09-24 04:14:53 --> Hooks Class Initialized
DEBUG - 2023-09-24 04:14:53 --> UTF-8 Support Enabled
INFO - 2023-09-24 04:14:53 --> Utf8 Class Initialized
INFO - 2023-09-24 04:14:53 --> URI Class Initialized
INFO - 2023-09-24 04:14:53 --> Router Class Initialized
INFO - 2023-09-24 04:14:53 --> Output Class Initialized
INFO - 2023-09-24 04:14:53 --> Security Class Initialized
DEBUG - 2023-09-24 04:14:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-24 04:14:53 --> Input Class Initialized
INFO - 2023-09-24 04:14:53 --> Language Class Initialized
INFO - 2023-09-24 04:14:53 --> Loader Class Initialized
INFO - 2023-09-24 04:14:53 --> Helper loaded: url_helper
INFO - 2023-09-24 04:14:53 --> Helper loaded: file_helper
INFO - 2023-09-24 04:14:53 --> Helper loaded: html_helper
INFO - 2023-09-24 04:14:53 --> Helper loaded: text_helper
INFO - 2023-09-24 04:14:53 --> Helper loaded: form_helper
INFO - 2023-09-24 04:14:53 --> Helper loaded: lang_helper
INFO - 2023-09-24 04:14:53 --> Helper loaded: security_helper
INFO - 2023-09-24 04:14:53 --> Helper loaded: cookie_helper
INFO - 2023-09-24 04:14:53 --> Database Driver Class Initialized
INFO - 2023-09-24 04:14:53 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-24 04:14:53 --> Parser Class Initialized
INFO - 2023-09-24 04:14:53 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-24 04:14:53 --> Pagination Class Initialized
INFO - 2023-09-24 04:14:53 --> Form Validation Class Initialized
INFO - 2023-09-24 04:14:53 --> Controller Class Initialized
INFO - 2023-09-24 04:14:53 --> Model Class Initialized
DEBUG - 2023-09-24 04:14:53 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-09-24 04:14:53 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-24 04:14:53 --> Model Class Initialized
INFO - 2023-09-24 04:14:53 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/stockrequest/stockrequest.php
DEBUG - 2023-09-24 04:14:53 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-09-24 04:14:53 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-09-24 04:14:53 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-09-24 04:14:53 --> Model Class Initialized
INFO - 2023-09-24 04:14:53 --> Model Class Initialized
INFO - 2023-09-24 04:14:53 --> Model Class Initialized
INFO - 2023-09-24 04:14:53 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-09-24 04:14:53 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-09-24 04:14:53 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-09-24 04:14:53 --> Final output sent to browser
DEBUG - 2023-09-24 04:14:53 --> Total execution time: 0.1062
ERROR - 2023-09-24 04:14:53 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-24 04:14:53 --> Config Class Initialized
INFO - 2023-09-24 04:14:53 --> Hooks Class Initialized
DEBUG - 2023-09-24 04:14:53 --> UTF-8 Support Enabled
INFO - 2023-09-24 04:14:53 --> Utf8 Class Initialized
INFO - 2023-09-24 04:14:53 --> URI Class Initialized
INFO - 2023-09-24 04:14:53 --> Router Class Initialized
INFO - 2023-09-24 04:14:53 --> Output Class Initialized
INFO - 2023-09-24 04:14:53 --> Security Class Initialized
DEBUG - 2023-09-24 04:14:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-24 04:14:53 --> Input Class Initialized
INFO - 2023-09-24 04:14:53 --> Language Class Initialized
INFO - 2023-09-24 04:14:53 --> Loader Class Initialized
INFO - 2023-09-24 04:14:53 --> Helper loaded: url_helper
INFO - 2023-09-24 04:14:53 --> Helper loaded: file_helper
INFO - 2023-09-24 04:14:53 --> Helper loaded: html_helper
INFO - 2023-09-24 04:14:53 --> Helper loaded: text_helper
INFO - 2023-09-24 04:14:53 --> Helper loaded: form_helper
INFO - 2023-09-24 04:14:53 --> Helper loaded: lang_helper
INFO - 2023-09-24 04:14:53 --> Helper loaded: security_helper
INFO - 2023-09-24 04:14:53 --> Helper loaded: cookie_helper
INFO - 2023-09-24 04:14:53 --> Database Driver Class Initialized
INFO - 2023-09-24 04:14:53 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-24 04:14:53 --> Parser Class Initialized
INFO - 2023-09-24 04:14:53 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-24 04:14:53 --> Pagination Class Initialized
INFO - 2023-09-24 04:14:53 --> Form Validation Class Initialized
INFO - 2023-09-24 04:14:53 --> Controller Class Initialized
INFO - 2023-09-24 04:14:53 --> Model Class Initialized
DEBUG - 2023-09-24 04:14:53 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-09-24 04:14:53 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-24 04:14:53 --> Model Class Initialized
INFO - 2023-09-24 04:14:53 --> Final output sent to browser
DEBUG - 2023-09-24 04:14:53 --> Total execution time: 0.0298
ERROR - 2023-09-24 04:14:56 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-24 04:14:56 --> Config Class Initialized
INFO - 2023-09-24 04:14:56 --> Hooks Class Initialized
DEBUG - 2023-09-24 04:14:56 --> UTF-8 Support Enabled
INFO - 2023-09-24 04:14:56 --> Utf8 Class Initialized
INFO - 2023-09-24 04:14:56 --> URI Class Initialized
INFO - 2023-09-24 04:14:56 --> Router Class Initialized
INFO - 2023-09-24 04:14:56 --> Output Class Initialized
INFO - 2023-09-24 04:14:56 --> Security Class Initialized
DEBUG - 2023-09-24 04:14:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-24 04:14:56 --> Input Class Initialized
INFO - 2023-09-24 04:14:56 --> Language Class Initialized
INFO - 2023-09-24 04:14:56 --> Loader Class Initialized
INFO - 2023-09-24 04:14:56 --> Helper loaded: url_helper
INFO - 2023-09-24 04:14:56 --> Helper loaded: file_helper
INFO - 2023-09-24 04:14:56 --> Helper loaded: html_helper
INFO - 2023-09-24 04:14:56 --> Helper loaded: text_helper
INFO - 2023-09-24 04:14:56 --> Helper loaded: form_helper
INFO - 2023-09-24 04:14:56 --> Helper loaded: lang_helper
INFO - 2023-09-24 04:14:56 --> Helper loaded: security_helper
INFO - 2023-09-24 04:14:56 --> Helper loaded: cookie_helper
INFO - 2023-09-24 04:14:56 --> Database Driver Class Initialized
INFO - 2023-09-24 04:14:56 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-24 04:14:56 --> Parser Class Initialized
INFO - 2023-09-24 04:14:56 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-24 04:14:56 --> Pagination Class Initialized
INFO - 2023-09-24 04:14:56 --> Form Validation Class Initialized
INFO - 2023-09-24 04:14:56 --> Controller Class Initialized
INFO - 2023-09-24 04:14:56 --> Model Class Initialized
DEBUG - 2023-09-24 04:14:56 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-09-24 04:14:56 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-24 04:14:56 --> Model Class Initialized
DEBUG - 2023-09-24 04:14:56 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-24 04:14:56 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/stockrequest/stockrequest_html.php
DEBUG - 2023-09-24 04:14:56 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-09-24 04:14:56 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-09-24 04:14:56 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-09-24 04:14:56 --> Model Class Initialized
INFO - 2023-09-24 04:14:56 --> Model Class Initialized
INFO - 2023-09-24 04:14:56 --> Model Class Initialized
INFO - 2023-09-24 04:14:56 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-09-24 04:14:56 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-09-24 04:14:56 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-09-24 04:14:56 --> Final output sent to browser
DEBUG - 2023-09-24 04:14:56 --> Total execution time: 0.0928
ERROR - 2023-09-24 04:14:59 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-24 04:14:59 --> Config Class Initialized
INFO - 2023-09-24 04:14:59 --> Hooks Class Initialized
DEBUG - 2023-09-24 04:14:59 --> UTF-8 Support Enabled
INFO - 2023-09-24 04:14:59 --> Utf8 Class Initialized
INFO - 2023-09-24 04:14:59 --> URI Class Initialized
INFO - 2023-09-24 04:14:59 --> Router Class Initialized
INFO - 2023-09-24 04:14:59 --> Output Class Initialized
INFO - 2023-09-24 04:14:59 --> Security Class Initialized
DEBUG - 2023-09-24 04:14:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-24 04:14:59 --> Input Class Initialized
INFO - 2023-09-24 04:14:59 --> Language Class Initialized
INFO - 2023-09-24 04:14:59 --> Loader Class Initialized
INFO - 2023-09-24 04:14:59 --> Helper loaded: url_helper
INFO - 2023-09-24 04:14:59 --> Helper loaded: file_helper
INFO - 2023-09-24 04:14:59 --> Helper loaded: html_helper
INFO - 2023-09-24 04:14:59 --> Helper loaded: text_helper
INFO - 2023-09-24 04:14:59 --> Helper loaded: form_helper
INFO - 2023-09-24 04:14:59 --> Helper loaded: lang_helper
INFO - 2023-09-24 04:14:59 --> Helper loaded: security_helper
INFO - 2023-09-24 04:14:59 --> Helper loaded: cookie_helper
INFO - 2023-09-24 04:14:59 --> Database Driver Class Initialized
INFO - 2023-09-24 04:14:59 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-24 04:14:59 --> Parser Class Initialized
INFO - 2023-09-24 04:14:59 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-24 04:14:59 --> Pagination Class Initialized
INFO - 2023-09-24 04:14:59 --> Form Validation Class Initialized
INFO - 2023-09-24 04:14:59 --> Controller Class Initialized
INFO - 2023-09-24 04:14:59 --> Final output sent to browser
DEBUG - 2023-09-24 04:14:59 --> Total execution time: 0.0145
ERROR - 2023-09-24 04:15:01 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-24 04:15:01 --> Config Class Initialized
INFO - 2023-09-24 04:15:01 --> Hooks Class Initialized
DEBUG - 2023-09-24 04:15:01 --> UTF-8 Support Enabled
INFO - 2023-09-24 04:15:01 --> Utf8 Class Initialized
INFO - 2023-09-24 04:15:01 --> URI Class Initialized
INFO - 2023-09-24 04:15:01 --> Router Class Initialized
INFO - 2023-09-24 04:15:01 --> Output Class Initialized
INFO - 2023-09-24 04:15:01 --> Security Class Initialized
DEBUG - 2023-09-24 04:15:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-24 04:15:01 --> Input Class Initialized
INFO - 2023-09-24 04:15:01 --> Language Class Initialized
INFO - 2023-09-24 04:15:01 --> Loader Class Initialized
INFO - 2023-09-24 04:15:01 --> Helper loaded: url_helper
INFO - 2023-09-24 04:15:01 --> Helper loaded: file_helper
INFO - 2023-09-24 04:15:01 --> Helper loaded: html_helper
INFO - 2023-09-24 04:15:01 --> Helper loaded: text_helper
INFO - 2023-09-24 04:15:01 --> Helper loaded: form_helper
INFO - 2023-09-24 04:15:01 --> Helper loaded: lang_helper
INFO - 2023-09-24 04:15:01 --> Helper loaded: security_helper
INFO - 2023-09-24 04:15:01 --> Helper loaded: cookie_helper
INFO - 2023-09-24 04:15:01 --> Database Driver Class Initialized
INFO - 2023-09-24 04:15:01 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-24 04:15:01 --> Parser Class Initialized
INFO - 2023-09-24 04:15:01 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-24 04:15:01 --> Pagination Class Initialized
INFO - 2023-09-24 04:15:01 --> Form Validation Class Initialized
INFO - 2023-09-24 04:15:01 --> Controller Class Initialized
INFO - 2023-09-24 04:15:01 --> Model Class Initialized
DEBUG - 2023-09-24 04:15:01 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-09-24 04:15:01 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-24 04:15:01 --> Model Class Initialized
DEBUG - 2023-09-24 04:15:01 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-24 04:15:01 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/stockrequest/stockrequest_html.php
DEBUG - 2023-09-24 04:15:01 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-09-24 04:15:01 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-09-24 04:15:01 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-09-24 04:15:01 --> Model Class Initialized
INFO - 2023-09-24 04:15:01 --> Model Class Initialized
INFO - 2023-09-24 04:15:01 --> Model Class Initialized
INFO - 2023-09-24 04:15:01 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-09-24 04:15:01 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-09-24 04:15:01 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-09-24 04:15:01 --> Final output sent to browser
DEBUG - 2023-09-24 04:15:01 --> Total execution time: 0.1180
ERROR - 2023-09-24 04:15:05 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-24 04:15:05 --> Config Class Initialized
INFO - 2023-09-24 04:15:05 --> Hooks Class Initialized
DEBUG - 2023-09-24 04:15:05 --> UTF-8 Support Enabled
INFO - 2023-09-24 04:15:05 --> Utf8 Class Initialized
INFO - 2023-09-24 04:15:05 --> URI Class Initialized
INFO - 2023-09-24 04:15:05 --> Router Class Initialized
INFO - 2023-09-24 04:15:05 --> Output Class Initialized
INFO - 2023-09-24 04:15:05 --> Security Class Initialized
DEBUG - 2023-09-24 04:15:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-24 04:15:05 --> Input Class Initialized
INFO - 2023-09-24 04:15:05 --> Language Class Initialized
INFO - 2023-09-24 04:15:05 --> Loader Class Initialized
INFO - 2023-09-24 04:15:05 --> Helper loaded: url_helper
INFO - 2023-09-24 04:15:05 --> Helper loaded: file_helper
INFO - 2023-09-24 04:15:05 --> Helper loaded: html_helper
INFO - 2023-09-24 04:15:05 --> Helper loaded: text_helper
INFO - 2023-09-24 04:15:05 --> Helper loaded: form_helper
INFO - 2023-09-24 04:15:05 --> Helper loaded: lang_helper
INFO - 2023-09-24 04:15:05 --> Helper loaded: security_helper
INFO - 2023-09-24 04:15:05 --> Helper loaded: cookie_helper
INFO - 2023-09-24 04:15:05 --> Database Driver Class Initialized
INFO - 2023-09-24 04:15:05 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-24 04:15:05 --> Parser Class Initialized
INFO - 2023-09-24 04:15:05 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-24 04:15:05 --> Pagination Class Initialized
INFO - 2023-09-24 04:15:05 --> Form Validation Class Initialized
INFO - 2023-09-24 04:15:05 --> Controller Class Initialized
INFO - 2023-09-24 04:15:05 --> Model Class Initialized
DEBUG - 2023-09-24 04:15:05 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-09-24 04:15:05 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-24 04:15:05 --> Model Class Initialized
DEBUG - 2023-09-24 04:15:05 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-24 04:15:05 --> Model Class Initialized
INFO - 2023-09-24 04:15:05 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/add_invoice_form.php
DEBUG - 2023-09-24 04:15:05 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-09-24 04:15:05 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-09-24 04:15:05 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-09-24 04:15:05 --> Model Class Initialized
INFO - 2023-09-24 04:15:05 --> Model Class Initialized
INFO - 2023-09-24 04:15:05 --> Model Class Initialized
INFO - 2023-09-24 04:15:05 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-09-24 04:15:05 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-09-24 04:15:05 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-09-24 04:15:05 --> Final output sent to browser
DEBUG - 2023-09-24 04:15:05 --> Total execution time: 0.1266
ERROR - 2023-09-24 04:15:10 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-24 04:15:10 --> Config Class Initialized
INFO - 2023-09-24 04:15:10 --> Hooks Class Initialized
DEBUG - 2023-09-24 04:15:10 --> UTF-8 Support Enabled
INFO - 2023-09-24 04:15:10 --> Utf8 Class Initialized
INFO - 2023-09-24 04:15:10 --> URI Class Initialized
INFO - 2023-09-24 04:15:10 --> Router Class Initialized
INFO - 2023-09-24 04:15:10 --> Output Class Initialized
INFO - 2023-09-24 04:15:10 --> Security Class Initialized
DEBUG - 2023-09-24 04:15:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-24 04:15:10 --> Input Class Initialized
INFO - 2023-09-24 04:15:10 --> Language Class Initialized
INFO - 2023-09-24 04:15:10 --> Loader Class Initialized
INFO - 2023-09-24 04:15:10 --> Helper loaded: url_helper
INFO - 2023-09-24 04:15:10 --> Helper loaded: file_helper
INFO - 2023-09-24 04:15:10 --> Helper loaded: html_helper
INFO - 2023-09-24 04:15:10 --> Helper loaded: text_helper
INFO - 2023-09-24 04:15:10 --> Helper loaded: form_helper
INFO - 2023-09-24 04:15:10 --> Helper loaded: lang_helper
INFO - 2023-09-24 04:15:10 --> Helper loaded: security_helper
INFO - 2023-09-24 04:15:10 --> Helper loaded: cookie_helper
INFO - 2023-09-24 04:15:10 --> Database Driver Class Initialized
INFO - 2023-09-24 04:15:10 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-24 04:15:10 --> Parser Class Initialized
INFO - 2023-09-24 04:15:10 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-24 04:15:10 --> Pagination Class Initialized
INFO - 2023-09-24 04:15:10 --> Form Validation Class Initialized
INFO - 2023-09-24 04:15:10 --> Controller Class Initialized
INFO - 2023-09-24 04:15:10 --> Model Class Initialized
DEBUG - 2023-09-24 04:15:10 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-24 04:15:10 --> Final output sent to browser
DEBUG - 2023-09-24 04:15:10 --> Total execution time: 0.0157
ERROR - 2023-09-24 04:15:20 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-24 04:15:20 --> Config Class Initialized
INFO - 2023-09-24 04:15:20 --> Hooks Class Initialized
DEBUG - 2023-09-24 04:15:20 --> UTF-8 Support Enabled
INFO - 2023-09-24 04:15:20 --> Utf8 Class Initialized
INFO - 2023-09-24 04:15:20 --> URI Class Initialized
INFO - 2023-09-24 04:15:20 --> Router Class Initialized
INFO - 2023-09-24 04:15:20 --> Output Class Initialized
INFO - 2023-09-24 04:15:20 --> Security Class Initialized
DEBUG - 2023-09-24 04:15:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-24 04:15:20 --> Input Class Initialized
INFO - 2023-09-24 04:15:20 --> Language Class Initialized
INFO - 2023-09-24 04:15:20 --> Loader Class Initialized
INFO - 2023-09-24 04:15:20 --> Helper loaded: url_helper
INFO - 2023-09-24 04:15:20 --> Helper loaded: file_helper
INFO - 2023-09-24 04:15:20 --> Helper loaded: html_helper
INFO - 2023-09-24 04:15:20 --> Helper loaded: text_helper
INFO - 2023-09-24 04:15:20 --> Helper loaded: form_helper
INFO - 2023-09-24 04:15:20 --> Helper loaded: lang_helper
INFO - 2023-09-24 04:15:20 --> Helper loaded: security_helper
INFO - 2023-09-24 04:15:20 --> Helper loaded: cookie_helper
INFO - 2023-09-24 04:15:20 --> Database Driver Class Initialized
INFO - 2023-09-24 04:15:20 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-24 04:15:20 --> Parser Class Initialized
INFO - 2023-09-24 04:15:20 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-24 04:15:20 --> Pagination Class Initialized
INFO - 2023-09-24 04:15:20 --> Form Validation Class Initialized
INFO - 2023-09-24 04:15:20 --> Controller Class Initialized
INFO - 2023-09-24 04:15:20 --> Model Class Initialized
DEBUG - 2023-09-24 04:15:20 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-09-24 04:15:20 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-24 04:15:20 --> Model Class Initialized
INFO - 2023-09-24 04:15:20 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/demandrequest/customer_demandrequest.php
DEBUG - 2023-09-24 04:15:20 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-09-24 04:15:20 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-09-24 04:15:20 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-09-24 04:15:20 --> Model Class Initialized
INFO - 2023-09-24 04:15:20 --> Model Class Initialized
INFO - 2023-09-24 04:15:20 --> Model Class Initialized
INFO - 2023-09-24 04:15:20 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-09-24 04:15:20 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-09-24 04:15:20 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-09-24 04:15:20 --> Final output sent to browser
DEBUG - 2023-09-24 04:15:20 --> Total execution time: 0.0937
ERROR - 2023-09-24 04:15:20 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-24 04:15:20 --> Config Class Initialized
INFO - 2023-09-24 04:15:20 --> Hooks Class Initialized
DEBUG - 2023-09-24 04:15:20 --> UTF-8 Support Enabled
INFO - 2023-09-24 04:15:20 --> Utf8 Class Initialized
INFO - 2023-09-24 04:15:20 --> URI Class Initialized
INFO - 2023-09-24 04:15:20 --> Router Class Initialized
INFO - 2023-09-24 04:15:20 --> Output Class Initialized
INFO - 2023-09-24 04:15:20 --> Security Class Initialized
DEBUG - 2023-09-24 04:15:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-24 04:15:20 --> Input Class Initialized
INFO - 2023-09-24 04:15:20 --> Language Class Initialized
INFO - 2023-09-24 04:15:20 --> Loader Class Initialized
INFO - 2023-09-24 04:15:20 --> Helper loaded: url_helper
INFO - 2023-09-24 04:15:20 --> Helper loaded: file_helper
INFO - 2023-09-24 04:15:20 --> Helper loaded: html_helper
INFO - 2023-09-24 04:15:20 --> Helper loaded: text_helper
INFO - 2023-09-24 04:15:20 --> Helper loaded: form_helper
INFO - 2023-09-24 04:15:20 --> Helper loaded: lang_helper
INFO - 2023-09-24 04:15:20 --> Helper loaded: security_helper
INFO - 2023-09-24 04:15:20 --> Helper loaded: cookie_helper
INFO - 2023-09-24 04:15:20 --> Database Driver Class Initialized
INFO - 2023-09-24 04:15:20 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-24 04:15:20 --> Parser Class Initialized
INFO - 2023-09-24 04:15:20 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-24 04:15:20 --> Pagination Class Initialized
INFO - 2023-09-24 04:15:20 --> Form Validation Class Initialized
INFO - 2023-09-24 04:15:20 --> Controller Class Initialized
INFO - 2023-09-24 04:15:20 --> Model Class Initialized
DEBUG - 2023-09-24 04:15:20 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-09-24 04:15:20 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-24 04:15:20 --> Model Class Initialized
INFO - 2023-09-24 04:15:20 --> Final output sent to browser
DEBUG - 2023-09-24 04:15:20 --> Total execution time: 0.0191
ERROR - 2023-09-24 04:15:23 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-24 04:15:23 --> Config Class Initialized
INFO - 2023-09-24 04:15:23 --> Hooks Class Initialized
DEBUG - 2023-09-24 04:15:23 --> UTF-8 Support Enabled
INFO - 2023-09-24 04:15:23 --> Utf8 Class Initialized
INFO - 2023-09-24 04:15:23 --> URI Class Initialized
INFO - 2023-09-24 04:15:23 --> Router Class Initialized
INFO - 2023-09-24 04:15:23 --> Output Class Initialized
INFO - 2023-09-24 04:15:23 --> Security Class Initialized
DEBUG - 2023-09-24 04:15:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-24 04:15:23 --> Input Class Initialized
INFO - 2023-09-24 04:15:23 --> Language Class Initialized
INFO - 2023-09-24 04:15:23 --> Loader Class Initialized
INFO - 2023-09-24 04:15:23 --> Helper loaded: url_helper
INFO - 2023-09-24 04:15:23 --> Helper loaded: file_helper
INFO - 2023-09-24 04:15:23 --> Helper loaded: html_helper
INFO - 2023-09-24 04:15:23 --> Helper loaded: text_helper
INFO - 2023-09-24 04:15:23 --> Helper loaded: form_helper
INFO - 2023-09-24 04:15:23 --> Helper loaded: lang_helper
INFO - 2023-09-24 04:15:23 --> Helper loaded: security_helper
INFO - 2023-09-24 04:15:23 --> Helper loaded: cookie_helper
INFO - 2023-09-24 04:15:23 --> Database Driver Class Initialized
INFO - 2023-09-24 04:15:23 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-24 04:15:23 --> Parser Class Initialized
INFO - 2023-09-24 04:15:23 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-24 04:15:23 --> Pagination Class Initialized
INFO - 2023-09-24 04:15:23 --> Form Validation Class Initialized
INFO - 2023-09-24 04:15:23 --> Controller Class Initialized
INFO - 2023-09-24 04:15:23 --> Model Class Initialized
DEBUG - 2023-09-24 04:15:23 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-09-24 04:15:23 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-24 04:15:23 --> Model Class Initialized
DEBUG - 2023-09-24 04:15:23 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-24 04:15:23 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/demandrequest/add_demandrequest_form.php
DEBUG - 2023-09-24 04:15:23 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-09-24 04:15:23 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-09-24 04:15:23 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-09-24 04:15:23 --> Model Class Initialized
INFO - 2023-09-24 04:15:23 --> Model Class Initialized
INFO - 2023-09-24 04:15:23 --> Model Class Initialized
INFO - 2023-09-24 04:15:23 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-09-24 04:15:23 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-09-24 04:15:23 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-09-24 04:15:23 --> Final output sent to browser
DEBUG - 2023-09-24 04:15:23 --> Total execution time: 0.0946
ERROR - 2023-09-24 04:15:28 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-24 04:15:28 --> Config Class Initialized
INFO - 2023-09-24 04:15:28 --> Hooks Class Initialized
DEBUG - 2023-09-24 04:15:28 --> UTF-8 Support Enabled
INFO - 2023-09-24 04:15:28 --> Utf8 Class Initialized
INFO - 2023-09-24 04:15:28 --> URI Class Initialized
INFO - 2023-09-24 04:15:28 --> Router Class Initialized
INFO - 2023-09-24 04:15:28 --> Output Class Initialized
INFO - 2023-09-24 04:15:28 --> Security Class Initialized
DEBUG - 2023-09-24 04:15:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-24 04:15:28 --> Input Class Initialized
INFO - 2023-09-24 04:15:28 --> Language Class Initialized
INFO - 2023-09-24 04:15:28 --> Loader Class Initialized
INFO - 2023-09-24 04:15:28 --> Helper loaded: url_helper
INFO - 2023-09-24 04:15:28 --> Helper loaded: file_helper
INFO - 2023-09-24 04:15:28 --> Helper loaded: html_helper
INFO - 2023-09-24 04:15:28 --> Helper loaded: text_helper
INFO - 2023-09-24 04:15:28 --> Helper loaded: form_helper
INFO - 2023-09-24 04:15:28 --> Helper loaded: lang_helper
INFO - 2023-09-24 04:15:28 --> Helper loaded: security_helper
INFO - 2023-09-24 04:15:28 --> Helper loaded: cookie_helper
INFO - 2023-09-24 04:15:28 --> Database Driver Class Initialized
INFO - 2023-09-24 04:15:28 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-24 04:15:28 --> Parser Class Initialized
INFO - 2023-09-24 04:15:28 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-24 04:15:28 --> Pagination Class Initialized
INFO - 2023-09-24 04:15:28 --> Form Validation Class Initialized
INFO - 2023-09-24 04:15:28 --> Controller Class Initialized
INFO - 2023-09-24 04:15:28 --> Model Class Initialized
DEBUG - 2023-09-24 04:15:28 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-09-24 04:15:28 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-24 04:15:28 --> Model Class Initialized
DEBUG - 2023-09-24 04:15:28 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-24 04:15:28 --> Model Class Initialized
INFO - 2023-09-24 04:15:28 --> Final output sent to browser
DEBUG - 2023-09-24 04:15:28 --> Total execution time: 0.0674
ERROR - 2023-09-24 04:15:30 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-24 04:15:30 --> Config Class Initialized
INFO - 2023-09-24 04:15:30 --> Hooks Class Initialized
DEBUG - 2023-09-24 04:15:30 --> UTF-8 Support Enabled
INFO - 2023-09-24 04:15:30 --> Utf8 Class Initialized
INFO - 2023-09-24 04:15:30 --> URI Class Initialized
INFO - 2023-09-24 04:15:30 --> Router Class Initialized
INFO - 2023-09-24 04:15:30 --> Output Class Initialized
INFO - 2023-09-24 04:15:30 --> Security Class Initialized
DEBUG - 2023-09-24 04:15:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-24 04:15:30 --> Input Class Initialized
INFO - 2023-09-24 04:15:30 --> Language Class Initialized
INFO - 2023-09-24 04:15:30 --> Loader Class Initialized
INFO - 2023-09-24 04:15:30 --> Helper loaded: url_helper
INFO - 2023-09-24 04:15:30 --> Helper loaded: file_helper
INFO - 2023-09-24 04:15:30 --> Helper loaded: html_helper
INFO - 2023-09-24 04:15:30 --> Helper loaded: text_helper
INFO - 2023-09-24 04:15:30 --> Helper loaded: form_helper
INFO - 2023-09-24 04:15:30 --> Helper loaded: lang_helper
INFO - 2023-09-24 04:15:30 --> Helper loaded: security_helper
INFO - 2023-09-24 04:15:30 --> Helper loaded: cookie_helper
INFO - 2023-09-24 04:15:30 --> Database Driver Class Initialized
INFO - 2023-09-24 04:15:30 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-24 04:15:30 --> Parser Class Initialized
INFO - 2023-09-24 04:15:30 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-24 04:15:30 --> Pagination Class Initialized
INFO - 2023-09-24 04:15:30 --> Form Validation Class Initialized
INFO - 2023-09-24 04:15:30 --> Controller Class Initialized
INFO - 2023-09-24 04:15:30 --> Model Class Initialized
DEBUG - 2023-09-24 04:15:30 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-09-24 04:15:30 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-24 04:15:30 --> Model Class Initialized
DEBUG - 2023-09-24 04:15:30 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-24 04:15:30 --> Model Class Initialized
INFO - 2023-09-24 04:15:30 --> Final output sent to browser
DEBUG - 2023-09-24 04:15:30 --> Total execution time: 0.0685
ERROR - 2023-09-24 04:15:30 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-24 04:15:30 --> Config Class Initialized
INFO - 2023-09-24 04:15:30 --> Hooks Class Initialized
DEBUG - 2023-09-24 04:15:30 --> UTF-8 Support Enabled
INFO - 2023-09-24 04:15:30 --> Utf8 Class Initialized
INFO - 2023-09-24 04:15:30 --> URI Class Initialized
INFO - 2023-09-24 04:15:30 --> Router Class Initialized
INFO - 2023-09-24 04:15:30 --> Output Class Initialized
INFO - 2023-09-24 04:15:30 --> Security Class Initialized
DEBUG - 2023-09-24 04:15:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-24 04:15:30 --> Input Class Initialized
INFO - 2023-09-24 04:15:30 --> Language Class Initialized
INFO - 2023-09-24 04:15:30 --> Loader Class Initialized
INFO - 2023-09-24 04:15:30 --> Helper loaded: url_helper
INFO - 2023-09-24 04:15:30 --> Helper loaded: file_helper
INFO - 2023-09-24 04:15:30 --> Helper loaded: html_helper
INFO - 2023-09-24 04:15:30 --> Helper loaded: text_helper
INFO - 2023-09-24 04:15:30 --> Helper loaded: form_helper
INFO - 2023-09-24 04:15:30 --> Helper loaded: lang_helper
INFO - 2023-09-24 04:15:30 --> Helper loaded: security_helper
INFO - 2023-09-24 04:15:30 --> Helper loaded: cookie_helper
INFO - 2023-09-24 04:15:30 --> Database Driver Class Initialized
INFO - 2023-09-24 04:15:30 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-24 04:15:30 --> Parser Class Initialized
INFO - 2023-09-24 04:15:30 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-24 04:15:30 --> Pagination Class Initialized
INFO - 2023-09-24 04:15:30 --> Form Validation Class Initialized
INFO - 2023-09-24 04:15:30 --> Controller Class Initialized
INFO - 2023-09-24 04:15:30 --> Model Class Initialized
DEBUG - 2023-09-24 04:15:30 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-09-24 04:15:30 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-24 04:15:30 --> Model Class Initialized
DEBUG - 2023-09-24 04:15:30 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-24 04:15:30 --> Model Class Initialized
INFO - 2023-09-24 04:15:30 --> Final output sent to browser
DEBUG - 2023-09-24 04:15:30 --> Total execution time: 0.0205
ERROR - 2023-09-24 04:15:31 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-24 04:15:31 --> Config Class Initialized
INFO - 2023-09-24 04:15:31 --> Hooks Class Initialized
DEBUG - 2023-09-24 04:15:31 --> UTF-8 Support Enabled
INFO - 2023-09-24 04:15:31 --> Utf8 Class Initialized
INFO - 2023-09-24 04:15:31 --> URI Class Initialized
INFO - 2023-09-24 04:15:31 --> Router Class Initialized
INFO - 2023-09-24 04:15:31 --> Output Class Initialized
INFO - 2023-09-24 04:15:31 --> Security Class Initialized
DEBUG - 2023-09-24 04:15:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-24 04:15:31 --> Input Class Initialized
INFO - 2023-09-24 04:15:31 --> Language Class Initialized
INFO - 2023-09-24 04:15:31 --> Loader Class Initialized
INFO - 2023-09-24 04:15:31 --> Helper loaded: url_helper
INFO - 2023-09-24 04:15:31 --> Helper loaded: file_helper
INFO - 2023-09-24 04:15:31 --> Helper loaded: html_helper
INFO - 2023-09-24 04:15:31 --> Helper loaded: text_helper
INFO - 2023-09-24 04:15:31 --> Helper loaded: form_helper
INFO - 2023-09-24 04:15:31 --> Helper loaded: lang_helper
INFO - 2023-09-24 04:15:31 --> Helper loaded: security_helper
INFO - 2023-09-24 04:15:31 --> Helper loaded: cookie_helper
INFO - 2023-09-24 04:15:31 --> Database Driver Class Initialized
INFO - 2023-09-24 04:15:31 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-24 04:15:31 --> Parser Class Initialized
INFO - 2023-09-24 04:15:31 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-24 04:15:31 --> Pagination Class Initialized
INFO - 2023-09-24 04:15:31 --> Form Validation Class Initialized
INFO - 2023-09-24 04:15:31 --> Controller Class Initialized
INFO - 2023-09-24 04:15:31 --> Model Class Initialized
DEBUG - 2023-09-24 04:15:31 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-09-24 04:15:31 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-24 04:15:31 --> Model Class Initialized
DEBUG - 2023-09-24 04:15:31 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-24 04:15:31 --> Model Class Initialized
INFO - 2023-09-24 04:15:31 --> Model Class Initialized
INFO - 2023-09-24 04:15:31 --> Final output sent to browser
DEBUG - 2023-09-24 04:15:31 --> Total execution time: 0.0262
ERROR - 2023-09-24 04:15:37 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-24 04:15:37 --> Config Class Initialized
INFO - 2023-09-24 04:15:37 --> Hooks Class Initialized
DEBUG - 2023-09-24 04:15:37 --> UTF-8 Support Enabled
INFO - 2023-09-24 04:15:37 --> Utf8 Class Initialized
INFO - 2023-09-24 04:15:37 --> URI Class Initialized
INFO - 2023-09-24 04:15:37 --> Router Class Initialized
INFO - 2023-09-24 04:15:37 --> Output Class Initialized
INFO - 2023-09-24 04:15:37 --> Security Class Initialized
DEBUG - 2023-09-24 04:15:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-24 04:15:37 --> Input Class Initialized
INFO - 2023-09-24 04:15:37 --> Language Class Initialized
INFO - 2023-09-24 04:15:37 --> Loader Class Initialized
INFO - 2023-09-24 04:15:37 --> Helper loaded: url_helper
INFO - 2023-09-24 04:15:37 --> Helper loaded: file_helper
INFO - 2023-09-24 04:15:37 --> Helper loaded: html_helper
INFO - 2023-09-24 04:15:37 --> Helper loaded: text_helper
INFO - 2023-09-24 04:15:37 --> Helper loaded: form_helper
INFO - 2023-09-24 04:15:37 --> Helper loaded: lang_helper
INFO - 2023-09-24 04:15:37 --> Helper loaded: security_helper
INFO - 2023-09-24 04:15:37 --> Helper loaded: cookie_helper
INFO - 2023-09-24 04:15:37 --> Database Driver Class Initialized
INFO - 2023-09-24 04:15:37 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-24 04:15:37 --> Parser Class Initialized
INFO - 2023-09-24 04:15:37 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-24 04:15:37 --> Pagination Class Initialized
INFO - 2023-09-24 04:15:37 --> Form Validation Class Initialized
INFO - 2023-09-24 04:15:37 --> Controller Class Initialized
INFO - 2023-09-24 04:15:37 --> Model Class Initialized
DEBUG - 2023-09-24 04:15:37 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-09-24 04:15:37 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-24 04:15:37 --> Model Class Initialized
DEBUG - 2023-09-24 04:15:37 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-24 04:15:37 --> Model Class Initialized
INFO - 2023-09-24 04:15:37 --> Final output sent to browser
DEBUG - 2023-09-24 04:15:37 --> Total execution time: 0.0714
ERROR - 2023-09-24 04:15:37 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-24 04:15:37 --> Config Class Initialized
INFO - 2023-09-24 04:15:37 --> Hooks Class Initialized
DEBUG - 2023-09-24 04:15:37 --> UTF-8 Support Enabled
INFO - 2023-09-24 04:15:37 --> Utf8 Class Initialized
INFO - 2023-09-24 04:15:37 --> URI Class Initialized
INFO - 2023-09-24 04:15:37 --> Router Class Initialized
INFO - 2023-09-24 04:15:37 --> Output Class Initialized
INFO - 2023-09-24 04:15:37 --> Security Class Initialized
DEBUG - 2023-09-24 04:15:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-24 04:15:37 --> Input Class Initialized
INFO - 2023-09-24 04:15:37 --> Language Class Initialized
INFO - 2023-09-24 04:15:37 --> Loader Class Initialized
INFO - 2023-09-24 04:15:37 --> Helper loaded: url_helper
INFO - 2023-09-24 04:15:37 --> Helper loaded: file_helper
INFO - 2023-09-24 04:15:37 --> Helper loaded: html_helper
INFO - 2023-09-24 04:15:37 --> Helper loaded: text_helper
INFO - 2023-09-24 04:15:37 --> Helper loaded: form_helper
INFO - 2023-09-24 04:15:37 --> Helper loaded: lang_helper
INFO - 2023-09-24 04:15:37 --> Helper loaded: security_helper
INFO - 2023-09-24 04:15:37 --> Helper loaded: cookie_helper
INFO - 2023-09-24 04:15:37 --> Database Driver Class Initialized
INFO - 2023-09-24 04:15:37 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-24 04:15:37 --> Parser Class Initialized
INFO - 2023-09-24 04:15:37 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-24 04:15:37 --> Pagination Class Initialized
INFO - 2023-09-24 04:15:37 --> Form Validation Class Initialized
INFO - 2023-09-24 04:15:37 --> Controller Class Initialized
INFO - 2023-09-24 04:15:37 --> Model Class Initialized
DEBUG - 2023-09-24 04:15:37 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-09-24 04:15:37 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-24 04:15:37 --> Model Class Initialized
DEBUG - 2023-09-24 04:15:37 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-24 04:15:37 --> Model Class Initialized
INFO - 2023-09-24 04:15:37 --> Final output sent to browser
DEBUG - 2023-09-24 04:15:37 --> Total execution time: 0.0194
ERROR - 2023-09-24 04:15:38 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-24 04:15:38 --> Config Class Initialized
INFO - 2023-09-24 04:15:38 --> Hooks Class Initialized
DEBUG - 2023-09-24 04:15:38 --> UTF-8 Support Enabled
INFO - 2023-09-24 04:15:38 --> Utf8 Class Initialized
INFO - 2023-09-24 04:15:38 --> URI Class Initialized
INFO - 2023-09-24 04:15:38 --> Router Class Initialized
INFO - 2023-09-24 04:15:38 --> Output Class Initialized
INFO - 2023-09-24 04:15:38 --> Security Class Initialized
DEBUG - 2023-09-24 04:15:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-24 04:15:38 --> Input Class Initialized
INFO - 2023-09-24 04:15:38 --> Language Class Initialized
INFO - 2023-09-24 04:15:38 --> Loader Class Initialized
INFO - 2023-09-24 04:15:38 --> Helper loaded: url_helper
INFO - 2023-09-24 04:15:38 --> Helper loaded: file_helper
INFO - 2023-09-24 04:15:38 --> Helper loaded: html_helper
INFO - 2023-09-24 04:15:38 --> Helper loaded: text_helper
INFO - 2023-09-24 04:15:38 --> Helper loaded: form_helper
INFO - 2023-09-24 04:15:38 --> Helper loaded: lang_helper
INFO - 2023-09-24 04:15:38 --> Helper loaded: security_helper
INFO - 2023-09-24 04:15:38 --> Helper loaded: cookie_helper
INFO - 2023-09-24 04:15:38 --> Database Driver Class Initialized
INFO - 2023-09-24 04:15:38 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-24 04:15:38 --> Parser Class Initialized
INFO - 2023-09-24 04:15:38 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-24 04:15:38 --> Pagination Class Initialized
INFO - 2023-09-24 04:15:38 --> Form Validation Class Initialized
INFO - 2023-09-24 04:15:38 --> Controller Class Initialized
INFO - 2023-09-24 04:15:38 --> Model Class Initialized
DEBUG - 2023-09-24 04:15:38 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-09-24 04:15:38 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-24 04:15:38 --> Model Class Initialized
DEBUG - 2023-09-24 04:15:38 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-24 04:15:38 --> Model Class Initialized
INFO - 2023-09-24 04:15:38 --> Final output sent to browser
DEBUG - 2023-09-24 04:15:38 --> Total execution time: 0.0654
ERROR - 2023-09-24 04:15:39 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-24 04:15:39 --> Config Class Initialized
INFO - 2023-09-24 04:15:39 --> Hooks Class Initialized
DEBUG - 2023-09-24 04:15:39 --> UTF-8 Support Enabled
INFO - 2023-09-24 04:15:39 --> Utf8 Class Initialized
INFO - 2023-09-24 04:15:39 --> URI Class Initialized
INFO - 2023-09-24 04:15:39 --> Router Class Initialized
INFO - 2023-09-24 04:15:39 --> Output Class Initialized
INFO - 2023-09-24 04:15:39 --> Security Class Initialized
DEBUG - 2023-09-24 04:15:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-24 04:15:39 --> Input Class Initialized
INFO - 2023-09-24 04:15:39 --> Language Class Initialized
INFO - 2023-09-24 04:15:39 --> Loader Class Initialized
INFO - 2023-09-24 04:15:39 --> Helper loaded: url_helper
INFO - 2023-09-24 04:15:39 --> Helper loaded: file_helper
INFO - 2023-09-24 04:15:39 --> Helper loaded: html_helper
INFO - 2023-09-24 04:15:39 --> Helper loaded: text_helper
INFO - 2023-09-24 04:15:39 --> Helper loaded: form_helper
INFO - 2023-09-24 04:15:39 --> Helper loaded: lang_helper
INFO - 2023-09-24 04:15:39 --> Helper loaded: security_helper
INFO - 2023-09-24 04:15:39 --> Helper loaded: cookie_helper
INFO - 2023-09-24 04:15:39 --> Database Driver Class Initialized
INFO - 2023-09-24 04:15:39 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-24 04:15:39 --> Parser Class Initialized
INFO - 2023-09-24 04:15:39 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-24 04:15:39 --> Pagination Class Initialized
INFO - 2023-09-24 04:15:39 --> Form Validation Class Initialized
INFO - 2023-09-24 04:15:39 --> Controller Class Initialized
INFO - 2023-09-24 04:15:40 --> Model Class Initialized
DEBUG - 2023-09-24 04:15:40 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-09-24 04:15:40 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-24 04:15:40 --> Model Class Initialized
DEBUG - 2023-09-24 04:15:40 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-24 04:15:40 --> Model Class Initialized
INFO - 2023-09-24 04:15:40 --> Final output sent to browser
DEBUG - 2023-09-24 04:15:40 --> Total execution time: 0.0660
ERROR - 2023-09-24 04:15:40 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-24 04:15:40 --> Config Class Initialized
INFO - 2023-09-24 04:15:40 --> Hooks Class Initialized
DEBUG - 2023-09-24 04:15:40 --> UTF-8 Support Enabled
INFO - 2023-09-24 04:15:40 --> Utf8 Class Initialized
INFO - 2023-09-24 04:15:40 --> URI Class Initialized
INFO - 2023-09-24 04:15:40 --> Router Class Initialized
INFO - 2023-09-24 04:15:40 --> Output Class Initialized
INFO - 2023-09-24 04:15:40 --> Security Class Initialized
DEBUG - 2023-09-24 04:15:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-24 04:15:40 --> Input Class Initialized
INFO - 2023-09-24 04:15:40 --> Language Class Initialized
INFO - 2023-09-24 04:15:40 --> Loader Class Initialized
INFO - 2023-09-24 04:15:40 --> Helper loaded: url_helper
INFO - 2023-09-24 04:15:40 --> Helper loaded: file_helper
INFO - 2023-09-24 04:15:40 --> Helper loaded: html_helper
INFO - 2023-09-24 04:15:40 --> Helper loaded: text_helper
INFO - 2023-09-24 04:15:40 --> Helper loaded: form_helper
INFO - 2023-09-24 04:15:40 --> Helper loaded: lang_helper
INFO - 2023-09-24 04:15:40 --> Helper loaded: security_helper
INFO - 2023-09-24 04:15:40 --> Helper loaded: cookie_helper
INFO - 2023-09-24 04:15:40 --> Database Driver Class Initialized
INFO - 2023-09-24 04:15:40 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-24 04:15:40 --> Parser Class Initialized
INFO - 2023-09-24 04:15:40 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-24 04:15:40 --> Pagination Class Initialized
INFO - 2023-09-24 04:15:40 --> Form Validation Class Initialized
INFO - 2023-09-24 04:15:40 --> Controller Class Initialized
INFO - 2023-09-24 04:15:40 --> Model Class Initialized
DEBUG - 2023-09-24 04:15:40 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-09-24 04:15:40 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-24 04:15:40 --> Model Class Initialized
DEBUG - 2023-09-24 04:15:40 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-24 04:15:40 --> Model Class Initialized
INFO - 2023-09-24 04:15:40 --> Final output sent to browser
DEBUG - 2023-09-24 04:15:40 --> Total execution time: 0.0331
ERROR - 2023-09-24 04:15:56 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-24 04:15:56 --> Config Class Initialized
INFO - 2023-09-24 04:15:56 --> Hooks Class Initialized
DEBUG - 2023-09-24 04:15:56 --> UTF-8 Support Enabled
INFO - 2023-09-24 04:15:56 --> Utf8 Class Initialized
INFO - 2023-09-24 04:15:56 --> URI Class Initialized
INFO - 2023-09-24 04:15:56 --> Router Class Initialized
INFO - 2023-09-24 04:15:56 --> Output Class Initialized
INFO - 2023-09-24 04:15:56 --> Security Class Initialized
DEBUG - 2023-09-24 04:15:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-24 04:15:56 --> Input Class Initialized
INFO - 2023-09-24 04:15:56 --> Language Class Initialized
INFO - 2023-09-24 04:15:56 --> Loader Class Initialized
INFO - 2023-09-24 04:15:56 --> Helper loaded: url_helper
INFO - 2023-09-24 04:15:56 --> Helper loaded: file_helper
INFO - 2023-09-24 04:15:56 --> Helper loaded: html_helper
INFO - 2023-09-24 04:15:56 --> Helper loaded: text_helper
INFO - 2023-09-24 04:15:56 --> Helper loaded: form_helper
INFO - 2023-09-24 04:15:56 --> Helper loaded: lang_helper
INFO - 2023-09-24 04:15:56 --> Helper loaded: security_helper
INFO - 2023-09-24 04:15:56 --> Helper loaded: cookie_helper
INFO - 2023-09-24 04:15:56 --> Database Driver Class Initialized
INFO - 2023-09-24 04:15:56 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-24 04:15:56 --> Parser Class Initialized
INFO - 2023-09-24 04:15:56 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-24 04:15:56 --> Pagination Class Initialized
INFO - 2023-09-24 04:15:56 --> Form Validation Class Initialized
INFO - 2023-09-24 04:15:56 --> Controller Class Initialized
INFO - 2023-09-24 04:15:56 --> Model Class Initialized
DEBUG - 2023-09-24 04:15:56 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-09-24 04:15:56 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-24 04:15:56 --> Model Class Initialized
DEBUG - 2023-09-24 04:15:56 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-24 04:15:56 --> Model Class Initialized
INFO - 2023-09-24 04:15:56 --> Model Class Initialized
INFO - 2023-09-24 04:15:56 --> Final output sent to browser
DEBUG - 2023-09-24 04:15:56 --> Total execution time: 0.0263
ERROR - 2023-09-24 04:16:02 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-24 04:16:02 --> Config Class Initialized
INFO - 2023-09-24 04:16:02 --> Hooks Class Initialized
DEBUG - 2023-09-24 04:16:02 --> UTF-8 Support Enabled
INFO - 2023-09-24 04:16:02 --> Utf8 Class Initialized
INFO - 2023-09-24 04:16:02 --> URI Class Initialized
INFO - 2023-09-24 04:16:02 --> Router Class Initialized
INFO - 2023-09-24 04:16:02 --> Output Class Initialized
INFO - 2023-09-24 04:16:02 --> Security Class Initialized
DEBUG - 2023-09-24 04:16:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-24 04:16:02 --> Input Class Initialized
INFO - 2023-09-24 04:16:02 --> Language Class Initialized
INFO - 2023-09-24 04:16:02 --> Loader Class Initialized
INFO - 2023-09-24 04:16:02 --> Helper loaded: url_helper
INFO - 2023-09-24 04:16:02 --> Helper loaded: file_helper
INFO - 2023-09-24 04:16:02 --> Helper loaded: html_helper
INFO - 2023-09-24 04:16:02 --> Helper loaded: text_helper
INFO - 2023-09-24 04:16:02 --> Helper loaded: form_helper
INFO - 2023-09-24 04:16:02 --> Helper loaded: lang_helper
INFO - 2023-09-24 04:16:02 --> Helper loaded: security_helper
INFO - 2023-09-24 04:16:02 --> Helper loaded: cookie_helper
INFO - 2023-09-24 04:16:02 --> Database Driver Class Initialized
INFO - 2023-09-24 04:16:02 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-24 04:16:02 --> Parser Class Initialized
INFO - 2023-09-24 04:16:02 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-24 04:16:02 --> Pagination Class Initialized
INFO - 2023-09-24 04:16:02 --> Form Validation Class Initialized
INFO - 2023-09-24 04:16:02 --> Controller Class Initialized
INFO - 2023-09-24 04:16:02 --> Model Class Initialized
DEBUG - 2023-09-24 04:16:02 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-09-24 04:16:02 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-24 04:16:02 --> Model Class Initialized
DEBUG - 2023-09-24 04:16:02 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-24 04:16:02 --> Model Class Initialized
INFO - 2023-09-24 04:16:02 --> Final output sent to browser
DEBUG - 2023-09-24 04:16:02 --> Total execution time: 0.0676
ERROR - 2023-09-24 04:16:02 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-24 04:16:02 --> Config Class Initialized
INFO - 2023-09-24 04:16:02 --> Hooks Class Initialized
DEBUG - 2023-09-24 04:16:02 --> UTF-8 Support Enabled
INFO - 2023-09-24 04:16:02 --> Utf8 Class Initialized
INFO - 2023-09-24 04:16:02 --> URI Class Initialized
INFO - 2023-09-24 04:16:02 --> Router Class Initialized
INFO - 2023-09-24 04:16:02 --> Output Class Initialized
INFO - 2023-09-24 04:16:02 --> Security Class Initialized
DEBUG - 2023-09-24 04:16:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-24 04:16:02 --> Input Class Initialized
INFO - 2023-09-24 04:16:02 --> Language Class Initialized
INFO - 2023-09-24 04:16:02 --> Loader Class Initialized
INFO - 2023-09-24 04:16:02 --> Helper loaded: url_helper
INFO - 2023-09-24 04:16:02 --> Helper loaded: file_helper
INFO - 2023-09-24 04:16:02 --> Helper loaded: html_helper
INFO - 2023-09-24 04:16:02 --> Helper loaded: text_helper
INFO - 2023-09-24 04:16:02 --> Helper loaded: form_helper
INFO - 2023-09-24 04:16:02 --> Helper loaded: lang_helper
INFO - 2023-09-24 04:16:02 --> Helper loaded: security_helper
INFO - 2023-09-24 04:16:02 --> Helper loaded: cookie_helper
INFO - 2023-09-24 04:16:02 --> Database Driver Class Initialized
INFO - 2023-09-24 04:16:02 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-24 04:16:02 --> Parser Class Initialized
INFO - 2023-09-24 04:16:02 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-24 04:16:02 --> Pagination Class Initialized
INFO - 2023-09-24 04:16:02 --> Form Validation Class Initialized
INFO - 2023-09-24 04:16:02 --> Controller Class Initialized
INFO - 2023-09-24 04:16:02 --> Model Class Initialized
DEBUG - 2023-09-24 04:16:02 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-09-24 04:16:02 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-24 04:16:02 --> Model Class Initialized
DEBUG - 2023-09-24 04:16:02 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-24 04:16:02 --> Model Class Initialized
INFO - 2023-09-24 04:16:02 --> Final output sent to browser
DEBUG - 2023-09-24 04:16:02 --> Total execution time: 0.0713
ERROR - 2023-09-24 04:16:03 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-24 04:16:03 --> Config Class Initialized
INFO - 2023-09-24 04:16:03 --> Hooks Class Initialized
DEBUG - 2023-09-24 04:16:03 --> UTF-8 Support Enabled
INFO - 2023-09-24 04:16:03 --> Utf8 Class Initialized
INFO - 2023-09-24 04:16:03 --> URI Class Initialized
INFO - 2023-09-24 04:16:03 --> Router Class Initialized
INFO - 2023-09-24 04:16:03 --> Output Class Initialized
INFO - 2023-09-24 04:16:03 --> Security Class Initialized
DEBUG - 2023-09-24 04:16:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-24 04:16:03 --> Input Class Initialized
INFO - 2023-09-24 04:16:03 --> Language Class Initialized
INFO - 2023-09-24 04:16:03 --> Loader Class Initialized
INFO - 2023-09-24 04:16:03 --> Helper loaded: url_helper
INFO - 2023-09-24 04:16:03 --> Helper loaded: file_helper
INFO - 2023-09-24 04:16:03 --> Helper loaded: html_helper
INFO - 2023-09-24 04:16:03 --> Helper loaded: text_helper
INFO - 2023-09-24 04:16:03 --> Helper loaded: form_helper
INFO - 2023-09-24 04:16:03 --> Helper loaded: lang_helper
INFO - 2023-09-24 04:16:03 --> Helper loaded: security_helper
INFO - 2023-09-24 04:16:03 --> Helper loaded: cookie_helper
INFO - 2023-09-24 04:16:03 --> Database Driver Class Initialized
INFO - 2023-09-24 04:16:03 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-24 04:16:03 --> Parser Class Initialized
INFO - 2023-09-24 04:16:03 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-24 04:16:03 --> Pagination Class Initialized
INFO - 2023-09-24 04:16:03 --> Form Validation Class Initialized
INFO - 2023-09-24 04:16:03 --> Controller Class Initialized
INFO - 2023-09-24 04:16:03 --> Model Class Initialized
DEBUG - 2023-09-24 04:16:03 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-09-24 04:16:03 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-24 04:16:03 --> Model Class Initialized
DEBUG - 2023-09-24 04:16:03 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-24 04:16:03 --> Model Class Initialized
INFO - 2023-09-24 04:16:03 --> Final output sent to browser
DEBUG - 2023-09-24 04:16:03 --> Total execution time: 0.0699
ERROR - 2023-09-24 04:16:03 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-24 04:16:03 --> Config Class Initialized
INFO - 2023-09-24 04:16:03 --> Hooks Class Initialized
DEBUG - 2023-09-24 04:16:03 --> UTF-8 Support Enabled
INFO - 2023-09-24 04:16:03 --> Utf8 Class Initialized
INFO - 2023-09-24 04:16:03 --> URI Class Initialized
INFO - 2023-09-24 04:16:03 --> Router Class Initialized
INFO - 2023-09-24 04:16:03 --> Output Class Initialized
INFO - 2023-09-24 04:16:03 --> Security Class Initialized
DEBUG - 2023-09-24 04:16:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-24 04:16:03 --> Input Class Initialized
INFO - 2023-09-24 04:16:03 --> Language Class Initialized
INFO - 2023-09-24 04:16:03 --> Loader Class Initialized
INFO - 2023-09-24 04:16:03 --> Helper loaded: url_helper
INFO - 2023-09-24 04:16:03 --> Helper loaded: file_helper
INFO - 2023-09-24 04:16:03 --> Helper loaded: html_helper
INFO - 2023-09-24 04:16:03 --> Helper loaded: text_helper
INFO - 2023-09-24 04:16:03 --> Helper loaded: form_helper
INFO - 2023-09-24 04:16:03 --> Helper loaded: lang_helper
INFO - 2023-09-24 04:16:03 --> Helper loaded: security_helper
INFO - 2023-09-24 04:16:03 --> Helper loaded: cookie_helper
INFO - 2023-09-24 04:16:03 --> Database Driver Class Initialized
INFO - 2023-09-24 04:16:03 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-24 04:16:03 --> Parser Class Initialized
INFO - 2023-09-24 04:16:03 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-24 04:16:03 --> Pagination Class Initialized
INFO - 2023-09-24 04:16:03 --> Form Validation Class Initialized
INFO - 2023-09-24 04:16:03 --> Controller Class Initialized
INFO - 2023-09-24 04:16:03 --> Model Class Initialized
DEBUG - 2023-09-24 04:16:03 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-09-24 04:16:03 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-24 04:16:03 --> Model Class Initialized
DEBUG - 2023-09-24 04:16:03 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-24 04:16:03 --> Model Class Initialized
INFO - 2023-09-24 04:16:03 --> Final output sent to browser
DEBUG - 2023-09-24 04:16:03 --> Total execution time: 0.0668
ERROR - 2023-09-24 04:16:07 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-24 04:16:07 --> Config Class Initialized
INFO - 2023-09-24 04:16:07 --> Hooks Class Initialized
DEBUG - 2023-09-24 04:16:07 --> UTF-8 Support Enabled
INFO - 2023-09-24 04:16:07 --> Utf8 Class Initialized
INFO - 2023-09-24 04:16:07 --> URI Class Initialized
INFO - 2023-09-24 04:16:07 --> Router Class Initialized
INFO - 2023-09-24 04:16:07 --> Output Class Initialized
INFO - 2023-09-24 04:16:07 --> Security Class Initialized
DEBUG - 2023-09-24 04:16:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-24 04:16:07 --> Input Class Initialized
INFO - 2023-09-24 04:16:07 --> Language Class Initialized
INFO - 2023-09-24 04:16:07 --> Loader Class Initialized
INFO - 2023-09-24 04:16:07 --> Helper loaded: url_helper
INFO - 2023-09-24 04:16:07 --> Helper loaded: file_helper
INFO - 2023-09-24 04:16:07 --> Helper loaded: html_helper
INFO - 2023-09-24 04:16:07 --> Helper loaded: text_helper
INFO - 2023-09-24 04:16:07 --> Helper loaded: form_helper
INFO - 2023-09-24 04:16:07 --> Helper loaded: lang_helper
INFO - 2023-09-24 04:16:07 --> Helper loaded: security_helper
INFO - 2023-09-24 04:16:07 --> Helper loaded: cookie_helper
INFO - 2023-09-24 04:16:07 --> Database Driver Class Initialized
INFO - 2023-09-24 04:16:07 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-24 04:16:07 --> Parser Class Initialized
INFO - 2023-09-24 04:16:07 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-24 04:16:07 --> Pagination Class Initialized
INFO - 2023-09-24 04:16:07 --> Form Validation Class Initialized
INFO - 2023-09-24 04:16:07 --> Controller Class Initialized
INFO - 2023-09-24 04:16:07 --> Model Class Initialized
DEBUG - 2023-09-24 04:16:07 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-09-24 04:16:07 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-24 04:16:07 --> Model Class Initialized
DEBUG - 2023-09-24 04:16:07 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-24 04:16:07 --> Model Class Initialized
INFO - 2023-09-24 04:16:07 --> Model Class Initialized
INFO - 2023-09-24 04:16:07 --> Final output sent to browser
DEBUG - 2023-09-24 04:16:07 --> Total execution time: 0.0214
ERROR - 2023-09-24 04:16:45 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-24 04:16:45 --> Config Class Initialized
INFO - 2023-09-24 04:16:45 --> Hooks Class Initialized
DEBUG - 2023-09-24 04:16:45 --> UTF-8 Support Enabled
INFO - 2023-09-24 04:16:45 --> Utf8 Class Initialized
INFO - 2023-09-24 04:16:45 --> URI Class Initialized
INFO - 2023-09-24 04:16:45 --> Router Class Initialized
INFO - 2023-09-24 04:16:45 --> Output Class Initialized
INFO - 2023-09-24 04:16:45 --> Security Class Initialized
DEBUG - 2023-09-24 04:16:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-24 04:16:45 --> Input Class Initialized
INFO - 2023-09-24 04:16:45 --> Language Class Initialized
INFO - 2023-09-24 04:16:45 --> Loader Class Initialized
INFO - 2023-09-24 04:16:45 --> Helper loaded: url_helper
INFO - 2023-09-24 04:16:45 --> Helper loaded: file_helper
INFO - 2023-09-24 04:16:45 --> Helper loaded: html_helper
INFO - 2023-09-24 04:16:45 --> Helper loaded: text_helper
INFO - 2023-09-24 04:16:45 --> Helper loaded: form_helper
INFO - 2023-09-24 04:16:45 --> Helper loaded: lang_helper
INFO - 2023-09-24 04:16:45 --> Helper loaded: security_helper
INFO - 2023-09-24 04:16:45 --> Helper loaded: cookie_helper
INFO - 2023-09-24 04:16:45 --> Database Driver Class Initialized
INFO - 2023-09-24 04:16:45 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-24 04:16:45 --> Parser Class Initialized
INFO - 2023-09-24 04:16:45 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-24 04:16:45 --> Pagination Class Initialized
INFO - 2023-09-24 04:16:45 --> Form Validation Class Initialized
INFO - 2023-09-24 04:16:45 --> Controller Class Initialized
INFO - 2023-09-24 04:16:45 --> Model Class Initialized
DEBUG - 2023-09-24 04:16:45 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-09-24 04:16:45 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-24 04:16:45 --> Model Class Initialized
DEBUG - 2023-09-24 04:16:45 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-24 04:16:45 --> Model Class Initialized
INFO - 2023-09-24 04:16:45 --> Final output sent to browser
DEBUG - 2023-09-24 04:16:45 --> Total execution time: 0.0213
ERROR - 2023-09-24 04:16:48 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-24 04:16:48 --> Config Class Initialized
INFO - 2023-09-24 04:16:48 --> Hooks Class Initialized
DEBUG - 2023-09-24 04:16:48 --> UTF-8 Support Enabled
INFO - 2023-09-24 04:16:48 --> Utf8 Class Initialized
INFO - 2023-09-24 04:16:48 --> URI Class Initialized
INFO - 2023-09-24 04:16:48 --> Router Class Initialized
INFO - 2023-09-24 04:16:48 --> Output Class Initialized
INFO - 2023-09-24 04:16:48 --> Security Class Initialized
DEBUG - 2023-09-24 04:16:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-24 04:16:48 --> Input Class Initialized
INFO - 2023-09-24 04:16:48 --> Language Class Initialized
INFO - 2023-09-24 04:16:48 --> Loader Class Initialized
INFO - 2023-09-24 04:16:48 --> Helper loaded: url_helper
INFO - 2023-09-24 04:16:48 --> Helper loaded: file_helper
INFO - 2023-09-24 04:16:48 --> Helper loaded: html_helper
INFO - 2023-09-24 04:16:48 --> Helper loaded: text_helper
INFO - 2023-09-24 04:16:48 --> Helper loaded: form_helper
INFO - 2023-09-24 04:16:48 --> Helper loaded: lang_helper
INFO - 2023-09-24 04:16:48 --> Helper loaded: security_helper
INFO - 2023-09-24 04:16:48 --> Helper loaded: cookie_helper
INFO - 2023-09-24 04:16:48 --> Database Driver Class Initialized
INFO - 2023-09-24 04:16:48 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-24 04:16:48 --> Parser Class Initialized
INFO - 2023-09-24 04:16:48 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-24 04:16:48 --> Pagination Class Initialized
INFO - 2023-09-24 04:16:48 --> Form Validation Class Initialized
INFO - 2023-09-24 04:16:48 --> Controller Class Initialized
INFO - 2023-09-24 04:16:48 --> Model Class Initialized
DEBUG - 2023-09-24 04:16:48 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-09-24 04:16:48 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-24 04:16:48 --> Model Class Initialized
DEBUG - 2023-09-24 04:16:48 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-24 04:16:48 --> Model Class Initialized
INFO - 2023-09-24 04:16:48 --> Final output sent to browser
DEBUG - 2023-09-24 04:16:48 --> Total execution time: 0.0698
ERROR - 2023-09-24 04:16:50 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-24 04:16:50 --> Config Class Initialized
INFO - 2023-09-24 04:16:50 --> Hooks Class Initialized
DEBUG - 2023-09-24 04:16:50 --> UTF-8 Support Enabled
INFO - 2023-09-24 04:16:50 --> Utf8 Class Initialized
INFO - 2023-09-24 04:16:50 --> URI Class Initialized
INFO - 2023-09-24 04:16:50 --> Router Class Initialized
INFO - 2023-09-24 04:16:50 --> Output Class Initialized
INFO - 2023-09-24 04:16:50 --> Security Class Initialized
DEBUG - 2023-09-24 04:16:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-24 04:16:50 --> Input Class Initialized
INFO - 2023-09-24 04:16:50 --> Language Class Initialized
INFO - 2023-09-24 04:16:50 --> Loader Class Initialized
INFO - 2023-09-24 04:16:50 --> Helper loaded: url_helper
INFO - 2023-09-24 04:16:50 --> Helper loaded: file_helper
INFO - 2023-09-24 04:16:50 --> Helper loaded: html_helper
INFO - 2023-09-24 04:16:50 --> Helper loaded: text_helper
INFO - 2023-09-24 04:16:50 --> Helper loaded: form_helper
INFO - 2023-09-24 04:16:50 --> Helper loaded: lang_helper
INFO - 2023-09-24 04:16:50 --> Helper loaded: security_helper
INFO - 2023-09-24 04:16:50 --> Helper loaded: cookie_helper
INFO - 2023-09-24 04:16:50 --> Database Driver Class Initialized
INFO - 2023-09-24 04:16:50 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-24 04:16:50 --> Parser Class Initialized
INFO - 2023-09-24 04:16:50 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-24 04:16:50 --> Pagination Class Initialized
INFO - 2023-09-24 04:16:50 --> Form Validation Class Initialized
INFO - 2023-09-24 04:16:50 --> Controller Class Initialized
INFO - 2023-09-24 04:16:50 --> Model Class Initialized
DEBUG - 2023-09-24 04:16:50 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-09-24 04:16:50 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-24 04:16:50 --> Model Class Initialized
DEBUG - 2023-09-24 04:16:50 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-24 04:16:50 --> Model Class Initialized
INFO - 2023-09-24 04:16:50 --> Final output sent to browser
DEBUG - 2023-09-24 04:16:50 --> Total execution time: 0.0670
ERROR - 2023-09-24 04:16:50 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-24 04:16:50 --> Config Class Initialized
INFO - 2023-09-24 04:16:50 --> Hooks Class Initialized
DEBUG - 2023-09-24 04:16:50 --> UTF-8 Support Enabled
INFO - 2023-09-24 04:16:50 --> Utf8 Class Initialized
INFO - 2023-09-24 04:16:50 --> URI Class Initialized
INFO - 2023-09-24 04:16:50 --> Router Class Initialized
INFO - 2023-09-24 04:16:50 --> Output Class Initialized
INFO - 2023-09-24 04:16:50 --> Security Class Initialized
DEBUG - 2023-09-24 04:16:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-24 04:16:50 --> Input Class Initialized
INFO - 2023-09-24 04:16:50 --> Language Class Initialized
INFO - 2023-09-24 04:16:50 --> Loader Class Initialized
INFO - 2023-09-24 04:16:50 --> Helper loaded: url_helper
INFO - 2023-09-24 04:16:50 --> Helper loaded: file_helper
INFO - 2023-09-24 04:16:50 --> Helper loaded: html_helper
INFO - 2023-09-24 04:16:50 --> Helper loaded: text_helper
INFO - 2023-09-24 04:16:50 --> Helper loaded: form_helper
INFO - 2023-09-24 04:16:50 --> Helper loaded: lang_helper
INFO - 2023-09-24 04:16:50 --> Helper loaded: security_helper
INFO - 2023-09-24 04:16:50 --> Helper loaded: cookie_helper
INFO - 2023-09-24 04:16:50 --> Database Driver Class Initialized
INFO - 2023-09-24 04:16:50 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-24 04:16:50 --> Parser Class Initialized
INFO - 2023-09-24 04:16:50 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-24 04:16:50 --> Pagination Class Initialized
INFO - 2023-09-24 04:16:50 --> Form Validation Class Initialized
INFO - 2023-09-24 04:16:50 --> Controller Class Initialized
INFO - 2023-09-24 04:16:50 --> Model Class Initialized
DEBUG - 2023-09-24 04:16:50 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-09-24 04:16:50 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-24 04:16:50 --> Model Class Initialized
DEBUG - 2023-09-24 04:16:50 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-24 04:16:50 --> Model Class Initialized
INFO - 2023-09-24 04:16:50 --> Final output sent to browser
DEBUG - 2023-09-24 04:16:50 --> Total execution time: 0.0793
ERROR - 2023-09-24 04:16:51 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-24 04:16:51 --> Config Class Initialized
INFO - 2023-09-24 04:16:51 --> Hooks Class Initialized
DEBUG - 2023-09-24 04:16:51 --> UTF-8 Support Enabled
INFO - 2023-09-24 04:16:51 --> Utf8 Class Initialized
INFO - 2023-09-24 04:16:51 --> URI Class Initialized
INFO - 2023-09-24 04:16:51 --> Router Class Initialized
INFO - 2023-09-24 04:16:51 --> Output Class Initialized
INFO - 2023-09-24 04:16:51 --> Security Class Initialized
DEBUG - 2023-09-24 04:16:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-24 04:16:51 --> Input Class Initialized
INFO - 2023-09-24 04:16:51 --> Language Class Initialized
INFO - 2023-09-24 04:16:51 --> Loader Class Initialized
INFO - 2023-09-24 04:16:51 --> Helper loaded: url_helper
INFO - 2023-09-24 04:16:51 --> Helper loaded: file_helper
INFO - 2023-09-24 04:16:51 --> Helper loaded: html_helper
INFO - 2023-09-24 04:16:51 --> Helper loaded: text_helper
INFO - 2023-09-24 04:16:51 --> Helper loaded: form_helper
INFO - 2023-09-24 04:16:51 --> Helper loaded: lang_helper
INFO - 2023-09-24 04:16:51 --> Helper loaded: security_helper
INFO - 2023-09-24 04:16:51 --> Helper loaded: cookie_helper
INFO - 2023-09-24 04:16:51 --> Database Driver Class Initialized
INFO - 2023-09-24 04:16:51 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-24 04:16:51 --> Parser Class Initialized
INFO - 2023-09-24 04:16:51 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-24 04:16:51 --> Pagination Class Initialized
INFO - 2023-09-24 04:16:51 --> Form Validation Class Initialized
INFO - 2023-09-24 04:16:51 --> Controller Class Initialized
INFO - 2023-09-24 04:16:51 --> Model Class Initialized
DEBUG - 2023-09-24 04:16:51 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-09-24 04:16:51 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-24 04:16:51 --> Model Class Initialized
DEBUG - 2023-09-24 04:16:51 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-24 04:16:51 --> Model Class Initialized
INFO - 2023-09-24 04:16:51 --> Final output sent to browser
DEBUG - 2023-09-24 04:16:51 --> Total execution time: 0.0635
ERROR - 2023-09-24 04:16:51 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-24 04:16:51 --> Config Class Initialized
INFO - 2023-09-24 04:16:51 --> Hooks Class Initialized
DEBUG - 2023-09-24 04:16:51 --> UTF-8 Support Enabled
INFO - 2023-09-24 04:16:51 --> Utf8 Class Initialized
INFO - 2023-09-24 04:16:51 --> URI Class Initialized
INFO - 2023-09-24 04:16:51 --> Router Class Initialized
INFO - 2023-09-24 04:16:51 --> Output Class Initialized
INFO - 2023-09-24 04:16:51 --> Security Class Initialized
DEBUG - 2023-09-24 04:16:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-24 04:16:51 --> Input Class Initialized
INFO - 2023-09-24 04:16:51 --> Language Class Initialized
INFO - 2023-09-24 04:16:51 --> Loader Class Initialized
INFO - 2023-09-24 04:16:51 --> Helper loaded: url_helper
INFO - 2023-09-24 04:16:51 --> Helper loaded: file_helper
INFO - 2023-09-24 04:16:51 --> Helper loaded: html_helper
INFO - 2023-09-24 04:16:51 --> Helper loaded: text_helper
INFO - 2023-09-24 04:16:51 --> Helper loaded: form_helper
INFO - 2023-09-24 04:16:51 --> Helper loaded: lang_helper
INFO - 2023-09-24 04:16:51 --> Helper loaded: security_helper
INFO - 2023-09-24 04:16:51 --> Helper loaded: cookie_helper
INFO - 2023-09-24 04:16:51 --> Database Driver Class Initialized
INFO - 2023-09-24 04:16:51 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-24 04:16:51 --> Parser Class Initialized
INFO - 2023-09-24 04:16:51 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-24 04:16:51 --> Pagination Class Initialized
INFO - 2023-09-24 04:16:51 --> Form Validation Class Initialized
INFO - 2023-09-24 04:16:51 --> Controller Class Initialized
INFO - 2023-09-24 04:16:51 --> Model Class Initialized
DEBUG - 2023-09-24 04:16:51 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-09-24 04:16:51 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-24 04:16:51 --> Model Class Initialized
DEBUG - 2023-09-24 04:16:51 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-24 04:16:51 --> Model Class Initialized
INFO - 2023-09-24 04:16:51 --> Final output sent to browser
DEBUG - 2023-09-24 04:16:51 --> Total execution time: 0.0667
ERROR - 2023-09-24 04:16:52 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-24 04:16:52 --> Config Class Initialized
INFO - 2023-09-24 04:16:52 --> Hooks Class Initialized
DEBUG - 2023-09-24 04:16:52 --> UTF-8 Support Enabled
INFO - 2023-09-24 04:16:52 --> Utf8 Class Initialized
INFO - 2023-09-24 04:16:52 --> URI Class Initialized
INFO - 2023-09-24 04:16:52 --> Router Class Initialized
INFO - 2023-09-24 04:16:52 --> Output Class Initialized
INFO - 2023-09-24 04:16:52 --> Security Class Initialized
DEBUG - 2023-09-24 04:16:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-24 04:16:52 --> Input Class Initialized
INFO - 2023-09-24 04:16:52 --> Language Class Initialized
INFO - 2023-09-24 04:16:52 --> Loader Class Initialized
INFO - 2023-09-24 04:16:52 --> Helper loaded: url_helper
INFO - 2023-09-24 04:16:52 --> Helper loaded: file_helper
INFO - 2023-09-24 04:16:52 --> Helper loaded: html_helper
INFO - 2023-09-24 04:16:52 --> Helper loaded: text_helper
INFO - 2023-09-24 04:16:52 --> Helper loaded: form_helper
INFO - 2023-09-24 04:16:52 --> Helper loaded: lang_helper
INFO - 2023-09-24 04:16:52 --> Helper loaded: security_helper
INFO - 2023-09-24 04:16:52 --> Helper loaded: cookie_helper
INFO - 2023-09-24 04:16:52 --> Database Driver Class Initialized
INFO - 2023-09-24 04:16:52 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-24 04:16:52 --> Parser Class Initialized
INFO - 2023-09-24 04:16:52 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-24 04:16:52 --> Pagination Class Initialized
INFO - 2023-09-24 04:16:52 --> Form Validation Class Initialized
INFO - 2023-09-24 04:16:52 --> Controller Class Initialized
INFO - 2023-09-24 04:16:52 --> Model Class Initialized
DEBUG - 2023-09-24 04:16:52 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-09-24 04:16:52 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-24 04:16:52 --> Model Class Initialized
DEBUG - 2023-09-24 04:16:52 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-24 04:16:52 --> Model Class Initialized
INFO - 2023-09-24 04:16:52 --> Final output sent to browser
DEBUG - 2023-09-24 04:16:52 --> Total execution time: 0.0320
ERROR - 2023-09-24 04:16:52 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-24 04:16:52 --> Config Class Initialized
INFO - 2023-09-24 04:16:52 --> Hooks Class Initialized
DEBUG - 2023-09-24 04:16:52 --> UTF-8 Support Enabled
INFO - 2023-09-24 04:16:52 --> Utf8 Class Initialized
INFO - 2023-09-24 04:16:52 --> URI Class Initialized
INFO - 2023-09-24 04:16:52 --> Router Class Initialized
INFO - 2023-09-24 04:16:52 --> Output Class Initialized
INFO - 2023-09-24 04:16:52 --> Security Class Initialized
DEBUG - 2023-09-24 04:16:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-24 04:16:52 --> Input Class Initialized
INFO - 2023-09-24 04:16:52 --> Language Class Initialized
INFO - 2023-09-24 04:16:52 --> Loader Class Initialized
INFO - 2023-09-24 04:16:52 --> Helper loaded: url_helper
INFO - 2023-09-24 04:16:52 --> Helper loaded: file_helper
INFO - 2023-09-24 04:16:52 --> Helper loaded: html_helper
INFO - 2023-09-24 04:16:52 --> Helper loaded: text_helper
INFO - 2023-09-24 04:16:52 --> Helper loaded: form_helper
INFO - 2023-09-24 04:16:52 --> Helper loaded: lang_helper
INFO - 2023-09-24 04:16:52 --> Helper loaded: security_helper
INFO - 2023-09-24 04:16:52 --> Helper loaded: cookie_helper
INFO - 2023-09-24 04:16:52 --> Database Driver Class Initialized
INFO - 2023-09-24 04:16:52 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-24 04:16:52 --> Parser Class Initialized
INFO - 2023-09-24 04:16:52 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-24 04:16:52 --> Pagination Class Initialized
INFO - 2023-09-24 04:16:52 --> Form Validation Class Initialized
INFO - 2023-09-24 04:16:52 --> Controller Class Initialized
INFO - 2023-09-24 04:16:52 --> Model Class Initialized
DEBUG - 2023-09-24 04:16:52 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-09-24 04:16:52 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-24 04:16:52 --> Model Class Initialized
DEBUG - 2023-09-24 04:16:52 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-24 04:16:52 --> Model Class Initialized
INFO - 2023-09-24 04:16:52 --> Final output sent to browser
DEBUG - 2023-09-24 04:16:52 --> Total execution time: 0.0194
ERROR - 2023-09-24 04:16:52 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-24 04:16:52 --> Config Class Initialized
INFO - 2023-09-24 04:16:52 --> Hooks Class Initialized
DEBUG - 2023-09-24 04:16:52 --> UTF-8 Support Enabled
INFO - 2023-09-24 04:16:52 --> Utf8 Class Initialized
INFO - 2023-09-24 04:16:52 --> URI Class Initialized
INFO - 2023-09-24 04:16:52 --> Router Class Initialized
INFO - 2023-09-24 04:16:52 --> Output Class Initialized
INFO - 2023-09-24 04:16:52 --> Security Class Initialized
DEBUG - 2023-09-24 04:16:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-24 04:16:52 --> Input Class Initialized
INFO - 2023-09-24 04:16:52 --> Language Class Initialized
INFO - 2023-09-24 04:16:52 --> Loader Class Initialized
INFO - 2023-09-24 04:16:52 --> Helper loaded: url_helper
INFO - 2023-09-24 04:16:52 --> Helper loaded: file_helper
INFO - 2023-09-24 04:16:52 --> Helper loaded: html_helper
INFO - 2023-09-24 04:16:52 --> Helper loaded: text_helper
INFO - 2023-09-24 04:16:52 --> Helper loaded: form_helper
INFO - 2023-09-24 04:16:52 --> Helper loaded: lang_helper
INFO - 2023-09-24 04:16:52 --> Helper loaded: security_helper
INFO - 2023-09-24 04:16:52 --> Helper loaded: cookie_helper
INFO - 2023-09-24 04:16:52 --> Database Driver Class Initialized
INFO - 2023-09-24 04:16:52 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-24 04:16:52 --> Parser Class Initialized
INFO - 2023-09-24 04:16:52 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-24 04:16:52 --> Pagination Class Initialized
INFO - 2023-09-24 04:16:52 --> Form Validation Class Initialized
INFO - 2023-09-24 04:16:52 --> Controller Class Initialized
INFO - 2023-09-24 04:16:52 --> Model Class Initialized
DEBUG - 2023-09-24 04:16:52 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-09-24 04:16:52 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-24 04:16:52 --> Model Class Initialized
DEBUG - 2023-09-24 04:16:52 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-24 04:16:52 --> Model Class Initialized
INFO - 2023-09-24 04:16:52 --> Final output sent to browser
DEBUG - 2023-09-24 04:16:52 --> Total execution time: 0.0203
ERROR - 2023-09-24 04:17:03 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-24 04:17:03 --> Config Class Initialized
INFO - 2023-09-24 04:17:03 --> Hooks Class Initialized
DEBUG - 2023-09-24 04:17:03 --> UTF-8 Support Enabled
INFO - 2023-09-24 04:17:03 --> Utf8 Class Initialized
INFO - 2023-09-24 04:17:03 --> URI Class Initialized
INFO - 2023-09-24 04:17:03 --> Router Class Initialized
INFO - 2023-09-24 04:17:03 --> Output Class Initialized
INFO - 2023-09-24 04:17:03 --> Security Class Initialized
DEBUG - 2023-09-24 04:17:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-24 04:17:03 --> Input Class Initialized
INFO - 2023-09-24 04:17:03 --> Language Class Initialized
INFO - 2023-09-24 04:17:03 --> Loader Class Initialized
INFO - 2023-09-24 04:17:03 --> Helper loaded: url_helper
INFO - 2023-09-24 04:17:03 --> Helper loaded: file_helper
INFO - 2023-09-24 04:17:03 --> Helper loaded: html_helper
INFO - 2023-09-24 04:17:03 --> Helper loaded: text_helper
INFO - 2023-09-24 04:17:03 --> Helper loaded: form_helper
INFO - 2023-09-24 04:17:03 --> Helper loaded: lang_helper
INFO - 2023-09-24 04:17:03 --> Helper loaded: security_helper
INFO - 2023-09-24 04:17:03 --> Helper loaded: cookie_helper
INFO - 2023-09-24 04:17:03 --> Database Driver Class Initialized
INFO - 2023-09-24 04:17:03 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-24 04:17:03 --> Parser Class Initialized
INFO - 2023-09-24 04:17:03 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-24 04:17:03 --> Pagination Class Initialized
INFO - 2023-09-24 04:17:03 --> Form Validation Class Initialized
INFO - 2023-09-24 04:17:03 --> Controller Class Initialized
INFO - 2023-09-24 04:17:03 --> Model Class Initialized
DEBUG - 2023-09-24 04:17:03 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-09-24 04:17:03 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-24 04:17:03 --> Model Class Initialized
DEBUG - 2023-09-24 04:17:03 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-24 04:17:03 --> Model Class Initialized
INFO - 2023-09-24 04:17:03 --> Final output sent to browser
DEBUG - 2023-09-24 04:17:03 --> Total execution time: 0.0682
ERROR - 2023-09-24 04:17:03 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-24 04:17:03 --> Config Class Initialized
INFO - 2023-09-24 04:17:03 --> Hooks Class Initialized
DEBUG - 2023-09-24 04:17:03 --> UTF-8 Support Enabled
INFO - 2023-09-24 04:17:03 --> Utf8 Class Initialized
INFO - 2023-09-24 04:17:03 --> URI Class Initialized
INFO - 2023-09-24 04:17:03 --> Router Class Initialized
INFO - 2023-09-24 04:17:03 --> Output Class Initialized
INFO - 2023-09-24 04:17:03 --> Security Class Initialized
DEBUG - 2023-09-24 04:17:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-24 04:17:03 --> Input Class Initialized
INFO - 2023-09-24 04:17:03 --> Language Class Initialized
INFO - 2023-09-24 04:17:03 --> Loader Class Initialized
INFO - 2023-09-24 04:17:03 --> Helper loaded: url_helper
INFO - 2023-09-24 04:17:03 --> Helper loaded: file_helper
INFO - 2023-09-24 04:17:03 --> Helper loaded: html_helper
INFO - 2023-09-24 04:17:03 --> Helper loaded: text_helper
INFO - 2023-09-24 04:17:03 --> Helper loaded: form_helper
INFO - 2023-09-24 04:17:03 --> Helper loaded: lang_helper
INFO - 2023-09-24 04:17:03 --> Helper loaded: security_helper
INFO - 2023-09-24 04:17:03 --> Helper loaded: cookie_helper
INFO - 2023-09-24 04:17:03 --> Database Driver Class Initialized
INFO - 2023-09-24 04:17:03 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-24 04:17:03 --> Parser Class Initialized
INFO - 2023-09-24 04:17:03 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-24 04:17:03 --> Pagination Class Initialized
INFO - 2023-09-24 04:17:03 --> Form Validation Class Initialized
INFO - 2023-09-24 04:17:03 --> Controller Class Initialized
INFO - 2023-09-24 04:17:03 --> Model Class Initialized
DEBUG - 2023-09-24 04:17:03 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-09-24 04:17:03 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-24 04:17:03 --> Model Class Initialized
DEBUG - 2023-09-24 04:17:03 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-24 04:17:03 --> Model Class Initialized
INFO - 2023-09-24 04:17:04 --> Final output sent to browser
DEBUG - 2023-09-24 04:17:04 --> Total execution time: 0.0765
ERROR - 2023-09-24 04:17:04 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-24 04:17:04 --> Config Class Initialized
INFO - 2023-09-24 04:17:04 --> Hooks Class Initialized
DEBUG - 2023-09-24 04:17:04 --> UTF-8 Support Enabled
INFO - 2023-09-24 04:17:04 --> Utf8 Class Initialized
INFO - 2023-09-24 04:17:04 --> URI Class Initialized
INFO - 2023-09-24 04:17:04 --> Router Class Initialized
INFO - 2023-09-24 04:17:04 --> Output Class Initialized
INFO - 2023-09-24 04:17:04 --> Security Class Initialized
DEBUG - 2023-09-24 04:17:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-24 04:17:04 --> Input Class Initialized
INFO - 2023-09-24 04:17:04 --> Language Class Initialized
INFO - 2023-09-24 04:17:04 --> Loader Class Initialized
INFO - 2023-09-24 04:17:04 --> Helper loaded: url_helper
INFO - 2023-09-24 04:17:04 --> Helper loaded: file_helper
INFO - 2023-09-24 04:17:04 --> Helper loaded: html_helper
INFO - 2023-09-24 04:17:04 --> Helper loaded: text_helper
INFO - 2023-09-24 04:17:04 --> Helper loaded: form_helper
INFO - 2023-09-24 04:17:04 --> Helper loaded: lang_helper
INFO - 2023-09-24 04:17:04 --> Helper loaded: security_helper
INFO - 2023-09-24 04:17:04 --> Helper loaded: cookie_helper
INFO - 2023-09-24 04:17:04 --> Database Driver Class Initialized
INFO - 2023-09-24 04:17:04 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-24 04:17:04 --> Parser Class Initialized
INFO - 2023-09-24 04:17:04 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-24 04:17:04 --> Pagination Class Initialized
INFO - 2023-09-24 04:17:04 --> Form Validation Class Initialized
INFO - 2023-09-24 04:17:04 --> Controller Class Initialized
INFO - 2023-09-24 04:17:04 --> Model Class Initialized
DEBUG - 2023-09-24 04:17:04 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-09-24 04:17:04 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-24 04:17:04 --> Model Class Initialized
DEBUG - 2023-09-24 04:17:04 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-24 04:17:04 --> Model Class Initialized
INFO - 2023-09-24 04:17:04 --> Final output sent to browser
DEBUG - 2023-09-24 04:17:04 --> Total execution time: 0.0658
ERROR - 2023-09-24 04:17:05 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-24 04:17:05 --> Config Class Initialized
INFO - 2023-09-24 04:17:05 --> Hooks Class Initialized
DEBUG - 2023-09-24 04:17:05 --> UTF-8 Support Enabled
INFO - 2023-09-24 04:17:05 --> Utf8 Class Initialized
INFO - 2023-09-24 04:17:05 --> URI Class Initialized
INFO - 2023-09-24 04:17:05 --> Router Class Initialized
INFO - 2023-09-24 04:17:05 --> Output Class Initialized
INFO - 2023-09-24 04:17:05 --> Security Class Initialized
DEBUG - 2023-09-24 04:17:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-24 04:17:05 --> Input Class Initialized
INFO - 2023-09-24 04:17:05 --> Language Class Initialized
INFO - 2023-09-24 04:17:05 --> Loader Class Initialized
INFO - 2023-09-24 04:17:05 --> Helper loaded: url_helper
INFO - 2023-09-24 04:17:05 --> Helper loaded: file_helper
INFO - 2023-09-24 04:17:05 --> Helper loaded: html_helper
INFO - 2023-09-24 04:17:05 --> Helper loaded: text_helper
INFO - 2023-09-24 04:17:05 --> Helper loaded: form_helper
INFO - 2023-09-24 04:17:05 --> Helper loaded: lang_helper
INFO - 2023-09-24 04:17:05 --> Helper loaded: security_helper
INFO - 2023-09-24 04:17:05 --> Helper loaded: cookie_helper
INFO - 2023-09-24 04:17:05 --> Database Driver Class Initialized
INFO - 2023-09-24 04:17:05 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-24 04:17:05 --> Parser Class Initialized
INFO - 2023-09-24 04:17:05 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-24 04:17:05 --> Pagination Class Initialized
INFO - 2023-09-24 04:17:05 --> Form Validation Class Initialized
INFO - 2023-09-24 04:17:05 --> Controller Class Initialized
INFO - 2023-09-24 04:17:05 --> Model Class Initialized
DEBUG - 2023-09-24 04:17:05 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-09-24 04:17:05 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-24 04:17:05 --> Model Class Initialized
DEBUG - 2023-09-24 04:17:05 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-24 04:17:05 --> Model Class Initialized
INFO - 2023-09-24 04:17:05 --> Final output sent to browser
DEBUG - 2023-09-24 04:17:05 --> Total execution time: 0.0274
ERROR - 2023-09-24 04:17:06 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-24 04:17:06 --> Config Class Initialized
INFO - 2023-09-24 04:17:06 --> Hooks Class Initialized
DEBUG - 2023-09-24 04:17:06 --> UTF-8 Support Enabled
INFO - 2023-09-24 04:17:06 --> Utf8 Class Initialized
INFO - 2023-09-24 04:17:06 --> URI Class Initialized
INFO - 2023-09-24 04:17:06 --> Router Class Initialized
INFO - 2023-09-24 04:17:06 --> Output Class Initialized
INFO - 2023-09-24 04:17:06 --> Security Class Initialized
DEBUG - 2023-09-24 04:17:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-24 04:17:06 --> Input Class Initialized
INFO - 2023-09-24 04:17:06 --> Language Class Initialized
INFO - 2023-09-24 04:17:06 --> Loader Class Initialized
INFO - 2023-09-24 04:17:06 --> Helper loaded: url_helper
INFO - 2023-09-24 04:17:06 --> Helper loaded: file_helper
INFO - 2023-09-24 04:17:06 --> Helper loaded: html_helper
INFO - 2023-09-24 04:17:06 --> Helper loaded: text_helper
INFO - 2023-09-24 04:17:06 --> Helper loaded: form_helper
INFO - 2023-09-24 04:17:06 --> Helper loaded: lang_helper
INFO - 2023-09-24 04:17:06 --> Helper loaded: security_helper
INFO - 2023-09-24 04:17:06 --> Helper loaded: cookie_helper
INFO - 2023-09-24 04:17:06 --> Database Driver Class Initialized
INFO - 2023-09-24 04:17:06 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-24 04:17:06 --> Parser Class Initialized
INFO - 2023-09-24 04:17:06 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-24 04:17:06 --> Pagination Class Initialized
INFO - 2023-09-24 04:17:06 --> Form Validation Class Initialized
INFO - 2023-09-24 04:17:06 --> Controller Class Initialized
INFO - 2023-09-24 04:17:06 --> Model Class Initialized
DEBUG - 2023-09-24 04:17:06 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-09-24 04:17:06 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-24 04:17:06 --> Model Class Initialized
DEBUG - 2023-09-24 04:17:06 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-24 04:17:06 --> Model Class Initialized
INFO - 2023-09-24 04:17:06 --> Model Class Initialized
INFO - 2023-09-24 04:17:06 --> Final output sent to browser
DEBUG - 2023-09-24 04:17:06 --> Total execution time: 0.0231
ERROR - 2023-09-24 04:17:11 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-24 04:17:11 --> Config Class Initialized
INFO - 2023-09-24 04:17:11 --> Hooks Class Initialized
DEBUG - 2023-09-24 04:17:11 --> UTF-8 Support Enabled
INFO - 2023-09-24 04:17:11 --> Utf8 Class Initialized
INFO - 2023-09-24 04:17:11 --> URI Class Initialized
INFO - 2023-09-24 04:17:11 --> Router Class Initialized
INFO - 2023-09-24 04:17:11 --> Output Class Initialized
INFO - 2023-09-24 04:17:11 --> Security Class Initialized
DEBUG - 2023-09-24 04:17:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-24 04:17:11 --> Input Class Initialized
INFO - 2023-09-24 04:17:11 --> Language Class Initialized
INFO - 2023-09-24 04:17:11 --> Loader Class Initialized
INFO - 2023-09-24 04:17:11 --> Helper loaded: url_helper
INFO - 2023-09-24 04:17:11 --> Helper loaded: file_helper
INFO - 2023-09-24 04:17:11 --> Helper loaded: html_helper
INFO - 2023-09-24 04:17:11 --> Helper loaded: text_helper
INFO - 2023-09-24 04:17:11 --> Helper loaded: form_helper
INFO - 2023-09-24 04:17:11 --> Helper loaded: lang_helper
INFO - 2023-09-24 04:17:11 --> Helper loaded: security_helper
INFO - 2023-09-24 04:17:11 --> Helper loaded: cookie_helper
INFO - 2023-09-24 04:17:11 --> Database Driver Class Initialized
INFO - 2023-09-24 04:17:11 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-24 04:17:11 --> Parser Class Initialized
INFO - 2023-09-24 04:17:11 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-24 04:17:11 --> Pagination Class Initialized
INFO - 2023-09-24 04:17:11 --> Form Validation Class Initialized
INFO - 2023-09-24 04:17:11 --> Controller Class Initialized
INFO - 2023-09-24 04:17:11 --> Model Class Initialized
DEBUG - 2023-09-24 04:17:11 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-09-24 04:17:11 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-24 04:17:11 --> Model Class Initialized
DEBUG - 2023-09-24 04:17:11 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-24 04:17:11 --> Model Class Initialized
INFO - 2023-09-24 04:17:11 --> Final output sent to browser
DEBUG - 2023-09-24 04:17:11 --> Total execution time: 0.0668
ERROR - 2023-09-24 04:17:12 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-24 04:17:12 --> Config Class Initialized
INFO - 2023-09-24 04:17:12 --> Hooks Class Initialized
DEBUG - 2023-09-24 04:17:12 --> UTF-8 Support Enabled
INFO - 2023-09-24 04:17:12 --> Utf8 Class Initialized
INFO - 2023-09-24 04:17:12 --> URI Class Initialized
INFO - 2023-09-24 04:17:12 --> Router Class Initialized
INFO - 2023-09-24 04:17:12 --> Output Class Initialized
INFO - 2023-09-24 04:17:12 --> Security Class Initialized
DEBUG - 2023-09-24 04:17:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-24 04:17:12 --> Input Class Initialized
INFO - 2023-09-24 04:17:12 --> Language Class Initialized
INFO - 2023-09-24 04:17:12 --> Loader Class Initialized
INFO - 2023-09-24 04:17:12 --> Helper loaded: url_helper
INFO - 2023-09-24 04:17:12 --> Helper loaded: file_helper
INFO - 2023-09-24 04:17:12 --> Helper loaded: html_helper
INFO - 2023-09-24 04:17:12 --> Helper loaded: text_helper
INFO - 2023-09-24 04:17:12 --> Helper loaded: form_helper
INFO - 2023-09-24 04:17:12 --> Helper loaded: lang_helper
INFO - 2023-09-24 04:17:12 --> Helper loaded: security_helper
INFO - 2023-09-24 04:17:12 --> Helper loaded: cookie_helper
INFO - 2023-09-24 04:17:12 --> Database Driver Class Initialized
INFO - 2023-09-24 04:17:12 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-24 04:17:12 --> Parser Class Initialized
INFO - 2023-09-24 04:17:12 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-24 04:17:12 --> Pagination Class Initialized
INFO - 2023-09-24 04:17:12 --> Form Validation Class Initialized
INFO - 2023-09-24 04:17:12 --> Controller Class Initialized
INFO - 2023-09-24 04:17:12 --> Model Class Initialized
DEBUG - 2023-09-24 04:17:12 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-09-24 04:17:12 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-24 04:17:12 --> Model Class Initialized
DEBUG - 2023-09-24 04:17:12 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-24 04:17:12 --> Model Class Initialized
INFO - 2023-09-24 04:17:12 --> Final output sent to browser
DEBUG - 2023-09-24 04:17:12 --> Total execution time: 0.0652
ERROR - 2023-09-24 04:17:13 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-24 04:17:13 --> Config Class Initialized
INFO - 2023-09-24 04:17:13 --> Hooks Class Initialized
DEBUG - 2023-09-24 04:17:13 --> UTF-8 Support Enabled
INFO - 2023-09-24 04:17:13 --> Utf8 Class Initialized
INFO - 2023-09-24 04:17:13 --> URI Class Initialized
INFO - 2023-09-24 04:17:13 --> Router Class Initialized
INFO - 2023-09-24 04:17:13 --> Output Class Initialized
INFO - 2023-09-24 04:17:13 --> Security Class Initialized
DEBUG - 2023-09-24 04:17:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-24 04:17:13 --> Input Class Initialized
INFO - 2023-09-24 04:17:13 --> Language Class Initialized
INFO - 2023-09-24 04:17:13 --> Loader Class Initialized
INFO - 2023-09-24 04:17:13 --> Helper loaded: url_helper
INFO - 2023-09-24 04:17:13 --> Helper loaded: file_helper
INFO - 2023-09-24 04:17:13 --> Helper loaded: html_helper
INFO - 2023-09-24 04:17:13 --> Helper loaded: text_helper
INFO - 2023-09-24 04:17:13 --> Helper loaded: form_helper
INFO - 2023-09-24 04:17:13 --> Helper loaded: lang_helper
INFO - 2023-09-24 04:17:13 --> Helper loaded: security_helper
INFO - 2023-09-24 04:17:13 --> Helper loaded: cookie_helper
INFO - 2023-09-24 04:17:13 --> Database Driver Class Initialized
INFO - 2023-09-24 04:17:13 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-24 04:17:13 --> Parser Class Initialized
INFO - 2023-09-24 04:17:13 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-24 04:17:13 --> Pagination Class Initialized
INFO - 2023-09-24 04:17:13 --> Form Validation Class Initialized
INFO - 2023-09-24 04:17:13 --> Controller Class Initialized
INFO - 2023-09-24 04:17:13 --> Model Class Initialized
DEBUG - 2023-09-24 04:17:13 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-09-24 04:17:13 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-24 04:17:13 --> Model Class Initialized
DEBUG - 2023-09-24 04:17:13 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-24 04:17:13 --> Model Class Initialized
INFO - 2023-09-24 04:17:13 --> Final output sent to browser
DEBUG - 2023-09-24 04:17:13 --> Total execution time: 0.0307
ERROR - 2023-09-24 04:17:16 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-24 04:17:16 --> Config Class Initialized
INFO - 2023-09-24 04:17:16 --> Hooks Class Initialized
DEBUG - 2023-09-24 04:17:16 --> UTF-8 Support Enabled
INFO - 2023-09-24 04:17:16 --> Utf8 Class Initialized
INFO - 2023-09-24 04:17:16 --> URI Class Initialized
INFO - 2023-09-24 04:17:16 --> Router Class Initialized
INFO - 2023-09-24 04:17:16 --> Output Class Initialized
INFO - 2023-09-24 04:17:16 --> Security Class Initialized
DEBUG - 2023-09-24 04:17:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-24 04:17:16 --> Input Class Initialized
INFO - 2023-09-24 04:17:16 --> Language Class Initialized
INFO - 2023-09-24 04:17:16 --> Loader Class Initialized
INFO - 2023-09-24 04:17:16 --> Helper loaded: url_helper
INFO - 2023-09-24 04:17:16 --> Helper loaded: file_helper
INFO - 2023-09-24 04:17:16 --> Helper loaded: html_helper
INFO - 2023-09-24 04:17:16 --> Helper loaded: text_helper
INFO - 2023-09-24 04:17:16 --> Helper loaded: form_helper
INFO - 2023-09-24 04:17:16 --> Helper loaded: lang_helper
INFO - 2023-09-24 04:17:16 --> Helper loaded: security_helper
INFO - 2023-09-24 04:17:16 --> Helper loaded: cookie_helper
INFO - 2023-09-24 04:17:16 --> Database Driver Class Initialized
INFO - 2023-09-24 04:17:16 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-24 04:17:16 --> Parser Class Initialized
INFO - 2023-09-24 04:17:16 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-24 04:17:16 --> Pagination Class Initialized
INFO - 2023-09-24 04:17:16 --> Form Validation Class Initialized
INFO - 2023-09-24 04:17:16 --> Controller Class Initialized
INFO - 2023-09-24 04:17:16 --> Model Class Initialized
DEBUG - 2023-09-24 04:17:16 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-09-24 04:17:16 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-24 04:17:16 --> Model Class Initialized
DEBUG - 2023-09-24 04:17:16 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-24 04:17:16 --> Model Class Initialized
INFO - 2023-09-24 04:17:16 --> Final output sent to browser
DEBUG - 2023-09-24 04:17:16 --> Total execution time: 0.0212
ERROR - 2023-09-24 04:17:18 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-24 04:17:18 --> Config Class Initialized
INFO - 2023-09-24 04:17:18 --> Hooks Class Initialized
DEBUG - 2023-09-24 04:17:18 --> UTF-8 Support Enabled
INFO - 2023-09-24 04:17:18 --> Utf8 Class Initialized
INFO - 2023-09-24 04:17:18 --> URI Class Initialized
INFO - 2023-09-24 04:17:18 --> Router Class Initialized
INFO - 2023-09-24 04:17:18 --> Output Class Initialized
INFO - 2023-09-24 04:17:18 --> Security Class Initialized
DEBUG - 2023-09-24 04:17:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-24 04:17:18 --> Input Class Initialized
INFO - 2023-09-24 04:17:18 --> Language Class Initialized
INFO - 2023-09-24 04:17:18 --> Loader Class Initialized
INFO - 2023-09-24 04:17:18 --> Helper loaded: url_helper
INFO - 2023-09-24 04:17:18 --> Helper loaded: file_helper
INFO - 2023-09-24 04:17:18 --> Helper loaded: html_helper
INFO - 2023-09-24 04:17:18 --> Helper loaded: text_helper
INFO - 2023-09-24 04:17:18 --> Helper loaded: form_helper
INFO - 2023-09-24 04:17:18 --> Helper loaded: lang_helper
INFO - 2023-09-24 04:17:18 --> Helper loaded: security_helper
INFO - 2023-09-24 04:17:18 --> Helper loaded: cookie_helper
INFO - 2023-09-24 04:17:18 --> Database Driver Class Initialized
INFO - 2023-09-24 04:17:18 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-24 04:17:18 --> Parser Class Initialized
INFO - 2023-09-24 04:17:18 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-24 04:17:18 --> Pagination Class Initialized
INFO - 2023-09-24 04:17:18 --> Form Validation Class Initialized
INFO - 2023-09-24 04:17:18 --> Controller Class Initialized
INFO - 2023-09-24 04:17:18 --> Model Class Initialized
DEBUG - 2023-09-24 04:17:18 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-09-24 04:17:18 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-24 04:17:18 --> Model Class Initialized
DEBUG - 2023-09-24 04:17:18 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-24 04:17:18 --> Model Class Initialized
INFO - 2023-09-24 04:17:18 --> Model Class Initialized
INFO - 2023-09-24 04:17:18 --> Final output sent to browser
DEBUG - 2023-09-24 04:17:18 --> Total execution time: 0.0231
ERROR - 2023-09-24 04:17:45 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-24 04:17:45 --> Config Class Initialized
INFO - 2023-09-24 04:17:45 --> Hooks Class Initialized
DEBUG - 2023-09-24 04:17:45 --> UTF-8 Support Enabled
INFO - 2023-09-24 04:17:45 --> Utf8 Class Initialized
INFO - 2023-09-24 04:17:45 --> URI Class Initialized
INFO - 2023-09-24 04:17:45 --> Router Class Initialized
INFO - 2023-09-24 04:17:45 --> Output Class Initialized
INFO - 2023-09-24 04:17:45 --> Security Class Initialized
DEBUG - 2023-09-24 04:17:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-24 04:17:45 --> Input Class Initialized
INFO - 2023-09-24 04:17:45 --> Language Class Initialized
INFO - 2023-09-24 04:17:45 --> Loader Class Initialized
INFO - 2023-09-24 04:17:45 --> Helper loaded: url_helper
INFO - 2023-09-24 04:17:45 --> Helper loaded: file_helper
INFO - 2023-09-24 04:17:45 --> Helper loaded: html_helper
INFO - 2023-09-24 04:17:45 --> Helper loaded: text_helper
INFO - 2023-09-24 04:17:45 --> Helper loaded: form_helper
INFO - 2023-09-24 04:17:45 --> Helper loaded: lang_helper
INFO - 2023-09-24 04:17:45 --> Helper loaded: security_helper
INFO - 2023-09-24 04:17:45 --> Helper loaded: cookie_helper
INFO - 2023-09-24 04:17:45 --> Database Driver Class Initialized
INFO - 2023-09-24 04:17:45 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-24 04:17:45 --> Parser Class Initialized
INFO - 2023-09-24 04:17:45 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-24 04:17:45 --> Pagination Class Initialized
INFO - 2023-09-24 04:17:45 --> Form Validation Class Initialized
INFO - 2023-09-24 04:17:45 --> Controller Class Initialized
INFO - 2023-09-24 04:17:45 --> Model Class Initialized
DEBUG - 2023-09-24 04:17:45 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-09-24 04:17:45 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-24 04:17:45 --> Model Class Initialized
DEBUG - 2023-09-24 04:17:45 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-24 04:17:45 --> Model Class Initialized
INFO - 2023-09-24 04:17:45 --> Final output sent to browser
DEBUG - 2023-09-24 04:17:45 --> Total execution time: 0.0697
ERROR - 2023-09-24 04:17:45 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-24 04:17:45 --> Config Class Initialized
INFO - 2023-09-24 04:17:45 --> Hooks Class Initialized
DEBUG - 2023-09-24 04:17:45 --> UTF-8 Support Enabled
INFO - 2023-09-24 04:17:45 --> Utf8 Class Initialized
INFO - 2023-09-24 04:17:45 --> URI Class Initialized
INFO - 2023-09-24 04:17:45 --> Router Class Initialized
INFO - 2023-09-24 04:17:45 --> Output Class Initialized
INFO - 2023-09-24 04:17:45 --> Security Class Initialized
DEBUG - 2023-09-24 04:17:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-24 04:17:45 --> Input Class Initialized
INFO - 2023-09-24 04:17:45 --> Language Class Initialized
INFO - 2023-09-24 04:17:45 --> Loader Class Initialized
INFO - 2023-09-24 04:17:45 --> Helper loaded: url_helper
INFO - 2023-09-24 04:17:45 --> Helper loaded: file_helper
INFO - 2023-09-24 04:17:45 --> Helper loaded: html_helper
INFO - 2023-09-24 04:17:45 --> Helper loaded: text_helper
INFO - 2023-09-24 04:17:45 --> Helper loaded: form_helper
INFO - 2023-09-24 04:17:45 --> Helper loaded: lang_helper
INFO - 2023-09-24 04:17:45 --> Helper loaded: security_helper
INFO - 2023-09-24 04:17:45 --> Helper loaded: cookie_helper
INFO - 2023-09-24 04:17:45 --> Database Driver Class Initialized
INFO - 2023-09-24 04:17:45 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-24 04:17:45 --> Parser Class Initialized
INFO - 2023-09-24 04:17:45 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-24 04:17:45 --> Pagination Class Initialized
INFO - 2023-09-24 04:17:45 --> Form Validation Class Initialized
INFO - 2023-09-24 04:17:45 --> Controller Class Initialized
INFO - 2023-09-24 04:17:45 --> Model Class Initialized
DEBUG - 2023-09-24 04:17:45 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-09-24 04:17:45 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-24 04:17:45 --> Model Class Initialized
DEBUG - 2023-09-24 04:17:45 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-24 04:17:45 --> Model Class Initialized
INFO - 2023-09-24 04:17:45 --> Final output sent to browser
DEBUG - 2023-09-24 04:17:45 --> Total execution time: 0.0673
ERROR - 2023-09-24 04:17:46 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-24 04:17:46 --> Config Class Initialized
INFO - 2023-09-24 04:17:46 --> Hooks Class Initialized
DEBUG - 2023-09-24 04:17:46 --> UTF-8 Support Enabled
INFO - 2023-09-24 04:17:46 --> Utf8 Class Initialized
INFO - 2023-09-24 04:17:46 --> URI Class Initialized
INFO - 2023-09-24 04:17:46 --> Router Class Initialized
INFO - 2023-09-24 04:17:46 --> Output Class Initialized
INFO - 2023-09-24 04:17:46 --> Security Class Initialized
DEBUG - 2023-09-24 04:17:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-24 04:17:46 --> Input Class Initialized
INFO - 2023-09-24 04:17:46 --> Language Class Initialized
INFO - 2023-09-24 04:17:46 --> Loader Class Initialized
INFO - 2023-09-24 04:17:46 --> Helper loaded: url_helper
INFO - 2023-09-24 04:17:46 --> Helper loaded: file_helper
INFO - 2023-09-24 04:17:46 --> Helper loaded: html_helper
INFO - 2023-09-24 04:17:46 --> Helper loaded: text_helper
INFO - 2023-09-24 04:17:46 --> Helper loaded: form_helper
INFO - 2023-09-24 04:17:46 --> Helper loaded: lang_helper
INFO - 2023-09-24 04:17:46 --> Helper loaded: security_helper
INFO - 2023-09-24 04:17:46 --> Helper loaded: cookie_helper
INFO - 2023-09-24 04:17:46 --> Database Driver Class Initialized
INFO - 2023-09-24 04:17:46 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-24 04:17:46 --> Parser Class Initialized
INFO - 2023-09-24 04:17:46 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-24 04:17:46 --> Pagination Class Initialized
INFO - 2023-09-24 04:17:46 --> Form Validation Class Initialized
INFO - 2023-09-24 04:17:46 --> Controller Class Initialized
INFO - 2023-09-24 04:17:46 --> Model Class Initialized
DEBUG - 2023-09-24 04:17:46 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-09-24 04:17:46 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-24 04:17:46 --> Model Class Initialized
DEBUG - 2023-09-24 04:17:46 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-24 04:17:46 --> Model Class Initialized
INFO - 2023-09-24 04:17:46 --> Final output sent to browser
DEBUG - 2023-09-24 04:17:46 --> Total execution time: 0.0660
ERROR - 2023-09-24 04:17:46 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-24 04:17:46 --> Config Class Initialized
INFO - 2023-09-24 04:17:46 --> Hooks Class Initialized
DEBUG - 2023-09-24 04:17:46 --> UTF-8 Support Enabled
INFO - 2023-09-24 04:17:46 --> Utf8 Class Initialized
INFO - 2023-09-24 04:17:46 --> URI Class Initialized
INFO - 2023-09-24 04:17:46 --> Router Class Initialized
INFO - 2023-09-24 04:17:46 --> Output Class Initialized
INFO - 2023-09-24 04:17:46 --> Security Class Initialized
DEBUG - 2023-09-24 04:17:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-24 04:17:46 --> Input Class Initialized
INFO - 2023-09-24 04:17:46 --> Language Class Initialized
INFO - 2023-09-24 04:17:46 --> Loader Class Initialized
INFO - 2023-09-24 04:17:46 --> Helper loaded: url_helper
INFO - 2023-09-24 04:17:46 --> Helper loaded: file_helper
INFO - 2023-09-24 04:17:46 --> Helper loaded: html_helper
INFO - 2023-09-24 04:17:46 --> Helper loaded: text_helper
INFO - 2023-09-24 04:17:46 --> Helper loaded: form_helper
INFO - 2023-09-24 04:17:46 --> Helper loaded: lang_helper
INFO - 2023-09-24 04:17:46 --> Helper loaded: security_helper
INFO - 2023-09-24 04:17:46 --> Helper loaded: cookie_helper
INFO - 2023-09-24 04:17:46 --> Database Driver Class Initialized
INFO - 2023-09-24 04:17:46 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-24 04:17:46 --> Parser Class Initialized
INFO - 2023-09-24 04:17:46 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-24 04:17:46 --> Pagination Class Initialized
INFO - 2023-09-24 04:17:46 --> Form Validation Class Initialized
INFO - 2023-09-24 04:17:46 --> Controller Class Initialized
INFO - 2023-09-24 04:17:46 --> Model Class Initialized
DEBUG - 2023-09-24 04:17:46 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-09-24 04:17:46 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-24 04:17:46 --> Model Class Initialized
DEBUG - 2023-09-24 04:17:46 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-24 04:17:46 --> Model Class Initialized
INFO - 2023-09-24 04:17:46 --> Final output sent to browser
DEBUG - 2023-09-24 04:17:46 --> Total execution time: 0.0206
ERROR - 2023-09-24 04:17:48 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-24 04:17:48 --> Config Class Initialized
INFO - 2023-09-24 04:17:48 --> Hooks Class Initialized
DEBUG - 2023-09-24 04:17:48 --> UTF-8 Support Enabled
INFO - 2023-09-24 04:17:48 --> Utf8 Class Initialized
INFO - 2023-09-24 04:17:48 --> URI Class Initialized
INFO - 2023-09-24 04:17:48 --> Router Class Initialized
INFO - 2023-09-24 04:17:48 --> Output Class Initialized
INFO - 2023-09-24 04:17:48 --> Security Class Initialized
DEBUG - 2023-09-24 04:17:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-24 04:17:48 --> Input Class Initialized
INFO - 2023-09-24 04:17:48 --> Language Class Initialized
INFO - 2023-09-24 04:17:48 --> Loader Class Initialized
INFO - 2023-09-24 04:17:48 --> Helper loaded: url_helper
INFO - 2023-09-24 04:17:48 --> Helper loaded: file_helper
INFO - 2023-09-24 04:17:48 --> Helper loaded: html_helper
INFO - 2023-09-24 04:17:48 --> Helper loaded: text_helper
INFO - 2023-09-24 04:17:48 --> Helper loaded: form_helper
INFO - 2023-09-24 04:17:48 --> Helper loaded: lang_helper
INFO - 2023-09-24 04:17:48 --> Helper loaded: security_helper
INFO - 2023-09-24 04:17:48 --> Helper loaded: cookie_helper
INFO - 2023-09-24 04:17:48 --> Database Driver Class Initialized
INFO - 2023-09-24 04:17:48 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-24 04:17:48 --> Parser Class Initialized
INFO - 2023-09-24 04:17:48 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-24 04:17:48 --> Pagination Class Initialized
INFO - 2023-09-24 04:17:48 --> Form Validation Class Initialized
INFO - 2023-09-24 04:17:48 --> Controller Class Initialized
INFO - 2023-09-24 04:17:48 --> Model Class Initialized
DEBUG - 2023-09-24 04:17:48 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-09-24 04:17:48 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-24 04:17:48 --> Model Class Initialized
DEBUG - 2023-09-24 04:17:48 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-24 04:17:48 --> Model Class Initialized
INFO - 2023-09-24 04:17:48 --> Model Class Initialized
INFO - 2023-09-24 04:17:48 --> Final output sent to browser
DEBUG - 2023-09-24 04:17:48 --> Total execution time: 0.0211
ERROR - 2023-09-24 04:17:53 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-24 04:17:53 --> Config Class Initialized
INFO - 2023-09-24 04:17:53 --> Hooks Class Initialized
DEBUG - 2023-09-24 04:17:53 --> UTF-8 Support Enabled
INFO - 2023-09-24 04:17:53 --> Utf8 Class Initialized
INFO - 2023-09-24 04:17:53 --> URI Class Initialized
INFO - 2023-09-24 04:17:53 --> Router Class Initialized
INFO - 2023-09-24 04:17:53 --> Output Class Initialized
INFO - 2023-09-24 04:17:53 --> Security Class Initialized
DEBUG - 2023-09-24 04:17:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-24 04:17:53 --> Input Class Initialized
INFO - 2023-09-24 04:17:53 --> Language Class Initialized
INFO - 2023-09-24 04:17:53 --> Loader Class Initialized
INFO - 2023-09-24 04:17:53 --> Helper loaded: url_helper
INFO - 2023-09-24 04:17:53 --> Helper loaded: file_helper
INFO - 2023-09-24 04:17:53 --> Helper loaded: html_helper
INFO - 2023-09-24 04:17:53 --> Helper loaded: text_helper
INFO - 2023-09-24 04:17:53 --> Helper loaded: form_helper
INFO - 2023-09-24 04:17:53 --> Helper loaded: lang_helper
INFO - 2023-09-24 04:17:53 --> Helper loaded: security_helper
INFO - 2023-09-24 04:17:53 --> Helper loaded: cookie_helper
INFO - 2023-09-24 04:17:53 --> Database Driver Class Initialized
INFO - 2023-09-24 04:17:53 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-24 04:17:53 --> Parser Class Initialized
INFO - 2023-09-24 04:17:53 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-24 04:17:53 --> Pagination Class Initialized
INFO - 2023-09-24 04:17:53 --> Form Validation Class Initialized
INFO - 2023-09-24 04:17:53 --> Controller Class Initialized
INFO - 2023-09-24 04:17:53 --> Model Class Initialized
DEBUG - 2023-09-24 04:17:53 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-09-24 04:17:53 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-24 04:17:53 --> Model Class Initialized
DEBUG - 2023-09-24 04:17:53 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-24 04:17:53 --> Model Class Initialized
INFO - 2023-09-24 04:17:53 --> Final output sent to browser
DEBUG - 2023-09-24 04:17:53 --> Total execution time: 0.0686
ERROR - 2023-09-24 04:17:53 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-24 04:17:53 --> Config Class Initialized
INFO - 2023-09-24 04:17:53 --> Hooks Class Initialized
DEBUG - 2023-09-24 04:17:53 --> UTF-8 Support Enabled
INFO - 2023-09-24 04:17:53 --> Utf8 Class Initialized
INFO - 2023-09-24 04:17:53 --> URI Class Initialized
INFO - 2023-09-24 04:17:53 --> Router Class Initialized
INFO - 2023-09-24 04:17:53 --> Output Class Initialized
INFO - 2023-09-24 04:17:53 --> Security Class Initialized
DEBUG - 2023-09-24 04:17:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-24 04:17:53 --> Input Class Initialized
INFO - 2023-09-24 04:17:53 --> Language Class Initialized
INFO - 2023-09-24 04:17:53 --> Loader Class Initialized
INFO - 2023-09-24 04:17:53 --> Helper loaded: url_helper
INFO - 2023-09-24 04:17:53 --> Helper loaded: file_helper
INFO - 2023-09-24 04:17:53 --> Helper loaded: html_helper
INFO - 2023-09-24 04:17:53 --> Helper loaded: text_helper
INFO - 2023-09-24 04:17:53 --> Helper loaded: form_helper
INFO - 2023-09-24 04:17:53 --> Helper loaded: lang_helper
INFO - 2023-09-24 04:17:53 --> Helper loaded: security_helper
INFO - 2023-09-24 04:17:53 --> Helper loaded: cookie_helper
INFO - 2023-09-24 04:17:53 --> Database Driver Class Initialized
INFO - 2023-09-24 04:17:53 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-24 04:17:53 --> Parser Class Initialized
INFO - 2023-09-24 04:17:53 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-24 04:17:53 --> Pagination Class Initialized
INFO - 2023-09-24 04:17:53 --> Form Validation Class Initialized
INFO - 2023-09-24 04:17:53 --> Controller Class Initialized
INFO - 2023-09-24 04:17:53 --> Model Class Initialized
DEBUG - 2023-09-24 04:17:53 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-09-24 04:17:53 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-24 04:17:53 --> Model Class Initialized
DEBUG - 2023-09-24 04:17:53 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-24 04:17:53 --> Model Class Initialized
INFO - 2023-09-24 04:17:53 --> Final output sent to browser
DEBUG - 2023-09-24 04:17:53 --> Total execution time: 0.0849
ERROR - 2023-09-24 04:17:54 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-24 04:17:54 --> Config Class Initialized
INFO - 2023-09-24 04:17:54 --> Hooks Class Initialized
DEBUG - 2023-09-24 04:17:54 --> UTF-8 Support Enabled
INFO - 2023-09-24 04:17:54 --> Utf8 Class Initialized
INFO - 2023-09-24 04:17:54 --> URI Class Initialized
INFO - 2023-09-24 04:17:54 --> Router Class Initialized
INFO - 2023-09-24 04:17:54 --> Output Class Initialized
INFO - 2023-09-24 04:17:54 --> Security Class Initialized
DEBUG - 2023-09-24 04:17:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-24 04:17:54 --> Input Class Initialized
INFO - 2023-09-24 04:17:54 --> Language Class Initialized
INFO - 2023-09-24 04:17:54 --> Loader Class Initialized
INFO - 2023-09-24 04:17:54 --> Helper loaded: url_helper
INFO - 2023-09-24 04:17:54 --> Helper loaded: file_helper
INFO - 2023-09-24 04:17:54 --> Helper loaded: html_helper
INFO - 2023-09-24 04:17:54 --> Helper loaded: text_helper
INFO - 2023-09-24 04:17:54 --> Helper loaded: form_helper
INFO - 2023-09-24 04:17:54 --> Helper loaded: lang_helper
INFO - 2023-09-24 04:17:54 --> Helper loaded: security_helper
INFO - 2023-09-24 04:17:54 --> Helper loaded: cookie_helper
INFO - 2023-09-24 04:17:54 --> Database Driver Class Initialized
INFO - 2023-09-24 04:17:54 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-24 04:17:54 --> Parser Class Initialized
INFO - 2023-09-24 04:17:54 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-24 04:17:54 --> Pagination Class Initialized
INFO - 2023-09-24 04:17:54 --> Form Validation Class Initialized
INFO - 2023-09-24 04:17:54 --> Controller Class Initialized
INFO - 2023-09-24 04:17:54 --> Model Class Initialized
DEBUG - 2023-09-24 04:17:54 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-09-24 04:17:54 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-24 04:17:54 --> Model Class Initialized
DEBUG - 2023-09-24 04:17:54 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-24 04:17:54 --> Model Class Initialized
INFO - 2023-09-24 04:17:54 --> Final output sent to browser
DEBUG - 2023-09-24 04:17:54 --> Total execution time: 0.0251
ERROR - 2023-09-24 04:17:59 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-24 04:17:59 --> Config Class Initialized
INFO - 2023-09-24 04:17:59 --> Hooks Class Initialized
DEBUG - 2023-09-24 04:17:59 --> UTF-8 Support Enabled
INFO - 2023-09-24 04:17:59 --> Utf8 Class Initialized
INFO - 2023-09-24 04:17:59 --> URI Class Initialized
INFO - 2023-09-24 04:17:59 --> Router Class Initialized
INFO - 2023-09-24 04:17:59 --> Output Class Initialized
INFO - 2023-09-24 04:17:59 --> Security Class Initialized
DEBUG - 2023-09-24 04:17:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-24 04:17:59 --> Input Class Initialized
INFO - 2023-09-24 04:17:59 --> Language Class Initialized
INFO - 2023-09-24 04:17:59 --> Loader Class Initialized
INFO - 2023-09-24 04:17:59 --> Helper loaded: url_helper
INFO - 2023-09-24 04:17:59 --> Helper loaded: file_helper
INFO - 2023-09-24 04:17:59 --> Helper loaded: html_helper
INFO - 2023-09-24 04:17:59 --> Helper loaded: text_helper
INFO - 2023-09-24 04:17:59 --> Helper loaded: form_helper
INFO - 2023-09-24 04:17:59 --> Helper loaded: lang_helper
INFO - 2023-09-24 04:17:59 --> Helper loaded: security_helper
INFO - 2023-09-24 04:17:59 --> Helper loaded: cookie_helper
INFO - 2023-09-24 04:17:59 --> Database Driver Class Initialized
INFO - 2023-09-24 04:17:59 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-24 04:17:59 --> Parser Class Initialized
INFO - 2023-09-24 04:17:59 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-24 04:17:59 --> Pagination Class Initialized
INFO - 2023-09-24 04:17:59 --> Form Validation Class Initialized
INFO - 2023-09-24 04:17:59 --> Controller Class Initialized
INFO - 2023-09-24 04:17:59 --> Model Class Initialized
DEBUG - 2023-09-24 04:17:59 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-09-24 04:17:59 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-24 04:17:59 --> Model Class Initialized
DEBUG - 2023-09-24 04:17:59 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-24 04:17:59 --> Model Class Initialized
INFO - 2023-09-24 04:17:59 --> Final output sent to browser
DEBUG - 2023-09-24 04:17:59 --> Total execution time: 0.0215
ERROR - 2023-09-24 04:18:01 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-24 04:18:01 --> Config Class Initialized
INFO - 2023-09-24 04:18:01 --> Hooks Class Initialized
DEBUG - 2023-09-24 04:18:01 --> UTF-8 Support Enabled
INFO - 2023-09-24 04:18:01 --> Utf8 Class Initialized
INFO - 2023-09-24 04:18:01 --> URI Class Initialized
INFO - 2023-09-24 04:18:01 --> Router Class Initialized
INFO - 2023-09-24 04:18:01 --> Output Class Initialized
INFO - 2023-09-24 04:18:01 --> Security Class Initialized
DEBUG - 2023-09-24 04:18:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-24 04:18:01 --> Input Class Initialized
INFO - 2023-09-24 04:18:01 --> Language Class Initialized
INFO - 2023-09-24 04:18:01 --> Loader Class Initialized
INFO - 2023-09-24 04:18:01 --> Helper loaded: url_helper
INFO - 2023-09-24 04:18:01 --> Helper loaded: file_helper
INFO - 2023-09-24 04:18:01 --> Helper loaded: html_helper
INFO - 2023-09-24 04:18:01 --> Helper loaded: text_helper
INFO - 2023-09-24 04:18:01 --> Helper loaded: form_helper
INFO - 2023-09-24 04:18:01 --> Helper loaded: lang_helper
INFO - 2023-09-24 04:18:01 --> Helper loaded: security_helper
INFO - 2023-09-24 04:18:01 --> Helper loaded: cookie_helper
INFO - 2023-09-24 04:18:01 --> Database Driver Class Initialized
INFO - 2023-09-24 04:18:01 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-24 04:18:01 --> Parser Class Initialized
INFO - 2023-09-24 04:18:01 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-24 04:18:01 --> Pagination Class Initialized
INFO - 2023-09-24 04:18:01 --> Form Validation Class Initialized
INFO - 2023-09-24 04:18:01 --> Controller Class Initialized
INFO - 2023-09-24 04:18:01 --> Model Class Initialized
DEBUG - 2023-09-24 04:18:01 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-09-24 04:18:01 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-24 04:18:01 --> Model Class Initialized
DEBUG - 2023-09-24 04:18:01 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-24 04:18:01 --> Model Class Initialized
INFO - 2023-09-24 04:18:01 --> Final output sent to browser
DEBUG - 2023-09-24 04:18:01 --> Total execution time: 0.0305
ERROR - 2023-09-24 04:18:01 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-24 04:18:01 --> Config Class Initialized
INFO - 2023-09-24 04:18:01 --> Hooks Class Initialized
DEBUG - 2023-09-24 04:18:01 --> UTF-8 Support Enabled
INFO - 2023-09-24 04:18:01 --> Utf8 Class Initialized
INFO - 2023-09-24 04:18:01 --> URI Class Initialized
INFO - 2023-09-24 04:18:01 --> Router Class Initialized
INFO - 2023-09-24 04:18:01 --> Output Class Initialized
INFO - 2023-09-24 04:18:01 --> Security Class Initialized
DEBUG - 2023-09-24 04:18:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-24 04:18:01 --> Input Class Initialized
INFO - 2023-09-24 04:18:01 --> Language Class Initialized
INFO - 2023-09-24 04:18:01 --> Loader Class Initialized
INFO - 2023-09-24 04:18:01 --> Helper loaded: url_helper
INFO - 2023-09-24 04:18:01 --> Helper loaded: file_helper
INFO - 2023-09-24 04:18:01 --> Helper loaded: html_helper
INFO - 2023-09-24 04:18:01 --> Helper loaded: text_helper
INFO - 2023-09-24 04:18:01 --> Helper loaded: form_helper
INFO - 2023-09-24 04:18:01 --> Helper loaded: lang_helper
INFO - 2023-09-24 04:18:01 --> Helper loaded: security_helper
INFO - 2023-09-24 04:18:01 --> Helper loaded: cookie_helper
INFO - 2023-09-24 04:18:01 --> Database Driver Class Initialized
INFO - 2023-09-24 04:18:01 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-24 04:18:01 --> Parser Class Initialized
INFO - 2023-09-24 04:18:01 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-24 04:18:01 --> Pagination Class Initialized
INFO - 2023-09-24 04:18:01 --> Form Validation Class Initialized
INFO - 2023-09-24 04:18:01 --> Controller Class Initialized
INFO - 2023-09-24 04:18:01 --> Model Class Initialized
DEBUG - 2023-09-24 04:18:01 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-09-24 04:18:01 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-24 04:18:01 --> Model Class Initialized
DEBUG - 2023-09-24 04:18:01 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-24 04:18:01 --> Model Class Initialized
INFO - 2023-09-24 04:18:01 --> Final output sent to browser
DEBUG - 2023-09-24 04:18:01 --> Total execution time: 0.0761
ERROR - 2023-09-24 04:18:03 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-24 04:18:03 --> Config Class Initialized
INFO - 2023-09-24 04:18:03 --> Hooks Class Initialized
DEBUG - 2023-09-24 04:18:03 --> UTF-8 Support Enabled
INFO - 2023-09-24 04:18:03 --> Utf8 Class Initialized
INFO - 2023-09-24 04:18:03 --> URI Class Initialized
INFO - 2023-09-24 04:18:03 --> Router Class Initialized
INFO - 2023-09-24 04:18:03 --> Output Class Initialized
INFO - 2023-09-24 04:18:03 --> Security Class Initialized
DEBUG - 2023-09-24 04:18:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-24 04:18:03 --> Input Class Initialized
INFO - 2023-09-24 04:18:03 --> Language Class Initialized
INFO - 2023-09-24 04:18:03 --> Loader Class Initialized
INFO - 2023-09-24 04:18:03 --> Helper loaded: url_helper
INFO - 2023-09-24 04:18:03 --> Helper loaded: file_helper
INFO - 2023-09-24 04:18:03 --> Helper loaded: html_helper
INFO - 2023-09-24 04:18:03 --> Helper loaded: text_helper
INFO - 2023-09-24 04:18:03 --> Helper loaded: form_helper
INFO - 2023-09-24 04:18:03 --> Helper loaded: lang_helper
INFO - 2023-09-24 04:18:03 --> Helper loaded: security_helper
INFO - 2023-09-24 04:18:03 --> Helper loaded: cookie_helper
INFO - 2023-09-24 04:18:03 --> Database Driver Class Initialized
INFO - 2023-09-24 04:18:03 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-24 04:18:03 --> Parser Class Initialized
INFO - 2023-09-24 04:18:03 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-24 04:18:03 --> Pagination Class Initialized
INFO - 2023-09-24 04:18:03 --> Form Validation Class Initialized
INFO - 2023-09-24 04:18:03 --> Controller Class Initialized
INFO - 2023-09-24 04:18:03 --> Model Class Initialized
DEBUG - 2023-09-24 04:18:03 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-09-24 04:18:03 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-24 04:18:03 --> Model Class Initialized
DEBUG - 2023-09-24 04:18:03 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-24 04:18:03 --> Model Class Initialized
INFO - 2023-09-24 04:18:03 --> Final output sent to browser
DEBUG - 2023-09-24 04:18:03 --> Total execution time: 0.0303
ERROR - 2023-09-24 04:18:04 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-24 04:18:04 --> Config Class Initialized
INFO - 2023-09-24 04:18:04 --> Hooks Class Initialized
DEBUG - 2023-09-24 04:18:04 --> UTF-8 Support Enabled
INFO - 2023-09-24 04:18:04 --> Utf8 Class Initialized
INFO - 2023-09-24 04:18:04 --> URI Class Initialized
INFO - 2023-09-24 04:18:04 --> Router Class Initialized
INFO - 2023-09-24 04:18:04 --> Output Class Initialized
INFO - 2023-09-24 04:18:04 --> Security Class Initialized
DEBUG - 2023-09-24 04:18:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-24 04:18:04 --> Input Class Initialized
INFO - 2023-09-24 04:18:04 --> Language Class Initialized
INFO - 2023-09-24 04:18:04 --> Loader Class Initialized
INFO - 2023-09-24 04:18:04 --> Helper loaded: url_helper
INFO - 2023-09-24 04:18:04 --> Helper loaded: file_helper
INFO - 2023-09-24 04:18:04 --> Helper loaded: html_helper
INFO - 2023-09-24 04:18:04 --> Helper loaded: text_helper
INFO - 2023-09-24 04:18:04 --> Helper loaded: form_helper
INFO - 2023-09-24 04:18:04 --> Helper loaded: lang_helper
INFO - 2023-09-24 04:18:04 --> Helper loaded: security_helper
INFO - 2023-09-24 04:18:04 --> Helper loaded: cookie_helper
INFO - 2023-09-24 04:18:04 --> Database Driver Class Initialized
INFO - 2023-09-24 04:18:04 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-24 04:18:04 --> Parser Class Initialized
INFO - 2023-09-24 04:18:04 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-24 04:18:04 --> Pagination Class Initialized
INFO - 2023-09-24 04:18:04 --> Form Validation Class Initialized
INFO - 2023-09-24 04:18:04 --> Controller Class Initialized
INFO - 2023-09-24 04:18:04 --> Model Class Initialized
DEBUG - 2023-09-24 04:18:04 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-09-24 04:18:04 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-24 04:18:04 --> Model Class Initialized
DEBUG - 2023-09-24 04:18:04 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-24 04:18:04 --> Model Class Initialized
INFO - 2023-09-24 04:18:04 --> Final output sent to browser
DEBUG - 2023-09-24 04:18:04 --> Total execution time: 0.0229
ERROR - 2023-09-24 04:18:06 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-24 04:18:06 --> Config Class Initialized
INFO - 2023-09-24 04:18:06 --> Hooks Class Initialized
DEBUG - 2023-09-24 04:18:06 --> UTF-8 Support Enabled
INFO - 2023-09-24 04:18:06 --> Utf8 Class Initialized
INFO - 2023-09-24 04:18:06 --> URI Class Initialized
INFO - 2023-09-24 04:18:06 --> Router Class Initialized
INFO - 2023-09-24 04:18:06 --> Output Class Initialized
INFO - 2023-09-24 04:18:06 --> Security Class Initialized
DEBUG - 2023-09-24 04:18:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-24 04:18:06 --> Input Class Initialized
INFO - 2023-09-24 04:18:06 --> Language Class Initialized
INFO - 2023-09-24 04:18:06 --> Loader Class Initialized
INFO - 2023-09-24 04:18:06 --> Helper loaded: url_helper
INFO - 2023-09-24 04:18:06 --> Helper loaded: file_helper
INFO - 2023-09-24 04:18:06 --> Helper loaded: html_helper
INFO - 2023-09-24 04:18:06 --> Helper loaded: text_helper
INFO - 2023-09-24 04:18:06 --> Helper loaded: form_helper
INFO - 2023-09-24 04:18:06 --> Helper loaded: lang_helper
INFO - 2023-09-24 04:18:06 --> Helper loaded: security_helper
INFO - 2023-09-24 04:18:06 --> Helper loaded: cookie_helper
INFO - 2023-09-24 04:18:06 --> Database Driver Class Initialized
INFO - 2023-09-24 04:18:06 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-24 04:18:06 --> Parser Class Initialized
INFO - 2023-09-24 04:18:06 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-24 04:18:06 --> Pagination Class Initialized
INFO - 2023-09-24 04:18:06 --> Form Validation Class Initialized
INFO - 2023-09-24 04:18:06 --> Controller Class Initialized
INFO - 2023-09-24 04:18:06 --> Model Class Initialized
DEBUG - 2023-09-24 04:18:06 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-09-24 04:18:06 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-24 04:18:06 --> Model Class Initialized
DEBUG - 2023-09-24 04:18:06 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-24 04:18:06 --> Model Class Initialized
INFO - 2023-09-24 04:18:06 --> Model Class Initialized
INFO - 2023-09-24 04:18:06 --> Final output sent to browser
DEBUG - 2023-09-24 04:18:06 --> Total execution time: 0.0261
ERROR - 2023-09-24 04:18:41 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-24 04:18:41 --> Config Class Initialized
INFO - 2023-09-24 04:18:41 --> Hooks Class Initialized
DEBUG - 2023-09-24 04:18:41 --> UTF-8 Support Enabled
INFO - 2023-09-24 04:18:41 --> Utf8 Class Initialized
INFO - 2023-09-24 04:18:41 --> URI Class Initialized
INFO - 2023-09-24 04:18:41 --> Router Class Initialized
INFO - 2023-09-24 04:18:41 --> Output Class Initialized
INFO - 2023-09-24 04:18:41 --> Security Class Initialized
DEBUG - 2023-09-24 04:18:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-24 04:18:41 --> Input Class Initialized
INFO - 2023-09-24 04:18:41 --> Language Class Initialized
INFO - 2023-09-24 04:18:41 --> Loader Class Initialized
INFO - 2023-09-24 04:18:41 --> Helper loaded: url_helper
INFO - 2023-09-24 04:18:41 --> Helper loaded: file_helper
INFO - 2023-09-24 04:18:41 --> Helper loaded: html_helper
INFO - 2023-09-24 04:18:41 --> Helper loaded: text_helper
INFO - 2023-09-24 04:18:41 --> Helper loaded: form_helper
INFO - 2023-09-24 04:18:41 --> Helper loaded: lang_helper
INFO - 2023-09-24 04:18:41 --> Helper loaded: security_helper
INFO - 2023-09-24 04:18:41 --> Helper loaded: cookie_helper
INFO - 2023-09-24 04:18:41 --> Database Driver Class Initialized
INFO - 2023-09-24 04:18:41 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-24 04:18:41 --> Parser Class Initialized
INFO - 2023-09-24 04:18:41 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-24 04:18:41 --> Pagination Class Initialized
INFO - 2023-09-24 04:18:41 --> Form Validation Class Initialized
INFO - 2023-09-24 04:18:41 --> Controller Class Initialized
INFO - 2023-09-24 04:18:41 --> Model Class Initialized
DEBUG - 2023-09-24 04:18:41 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-09-24 04:18:41 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-24 04:18:41 --> Model Class Initialized
DEBUG - 2023-09-24 04:18:41 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-24 04:18:41 --> Model Class Initialized
INFO - 2023-09-24 04:18:41 --> Final output sent to browser
DEBUG - 2023-09-24 04:18:41 --> Total execution time: 0.0699
ERROR - 2023-09-24 04:18:41 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-24 04:18:41 --> Config Class Initialized
INFO - 2023-09-24 04:18:41 --> Hooks Class Initialized
DEBUG - 2023-09-24 04:18:41 --> UTF-8 Support Enabled
INFO - 2023-09-24 04:18:41 --> Utf8 Class Initialized
INFO - 2023-09-24 04:18:41 --> URI Class Initialized
INFO - 2023-09-24 04:18:41 --> Router Class Initialized
INFO - 2023-09-24 04:18:41 --> Output Class Initialized
INFO - 2023-09-24 04:18:41 --> Security Class Initialized
DEBUG - 2023-09-24 04:18:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-24 04:18:41 --> Input Class Initialized
INFO - 2023-09-24 04:18:41 --> Language Class Initialized
INFO - 2023-09-24 04:18:41 --> Loader Class Initialized
INFO - 2023-09-24 04:18:41 --> Helper loaded: url_helper
INFO - 2023-09-24 04:18:41 --> Helper loaded: file_helper
INFO - 2023-09-24 04:18:41 --> Helper loaded: html_helper
INFO - 2023-09-24 04:18:41 --> Helper loaded: text_helper
INFO - 2023-09-24 04:18:41 --> Helper loaded: form_helper
INFO - 2023-09-24 04:18:41 --> Helper loaded: lang_helper
INFO - 2023-09-24 04:18:41 --> Helper loaded: security_helper
INFO - 2023-09-24 04:18:41 --> Helper loaded: cookie_helper
INFO - 2023-09-24 04:18:41 --> Database Driver Class Initialized
INFO - 2023-09-24 04:18:41 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-24 04:18:41 --> Parser Class Initialized
INFO - 2023-09-24 04:18:41 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-24 04:18:41 --> Pagination Class Initialized
INFO - 2023-09-24 04:18:41 --> Form Validation Class Initialized
INFO - 2023-09-24 04:18:41 --> Controller Class Initialized
INFO - 2023-09-24 04:18:41 --> Model Class Initialized
DEBUG - 2023-09-24 04:18:41 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-09-24 04:18:41 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-24 04:18:41 --> Model Class Initialized
DEBUG - 2023-09-24 04:18:41 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-24 04:18:41 --> Model Class Initialized
INFO - 2023-09-24 04:18:41 --> Final output sent to browser
DEBUG - 2023-09-24 04:18:41 --> Total execution time: 0.0655
ERROR - 2023-09-24 04:18:42 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-24 04:18:42 --> Config Class Initialized
INFO - 2023-09-24 04:18:42 --> Hooks Class Initialized
DEBUG - 2023-09-24 04:18:42 --> UTF-8 Support Enabled
INFO - 2023-09-24 04:18:42 --> Utf8 Class Initialized
INFO - 2023-09-24 04:18:42 --> URI Class Initialized
INFO - 2023-09-24 04:18:42 --> Router Class Initialized
INFO - 2023-09-24 04:18:42 --> Output Class Initialized
INFO - 2023-09-24 04:18:42 --> Security Class Initialized
DEBUG - 2023-09-24 04:18:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-24 04:18:42 --> Input Class Initialized
INFO - 2023-09-24 04:18:42 --> Language Class Initialized
INFO - 2023-09-24 04:18:42 --> Loader Class Initialized
INFO - 2023-09-24 04:18:42 --> Helper loaded: url_helper
INFO - 2023-09-24 04:18:42 --> Helper loaded: file_helper
INFO - 2023-09-24 04:18:42 --> Helper loaded: html_helper
INFO - 2023-09-24 04:18:42 --> Helper loaded: text_helper
INFO - 2023-09-24 04:18:42 --> Helper loaded: form_helper
INFO - 2023-09-24 04:18:42 --> Helper loaded: lang_helper
INFO - 2023-09-24 04:18:42 --> Helper loaded: security_helper
INFO - 2023-09-24 04:18:42 --> Helper loaded: cookie_helper
INFO - 2023-09-24 04:18:42 --> Database Driver Class Initialized
INFO - 2023-09-24 04:18:42 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-24 04:18:42 --> Parser Class Initialized
INFO - 2023-09-24 04:18:42 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-24 04:18:42 --> Pagination Class Initialized
INFO - 2023-09-24 04:18:42 --> Form Validation Class Initialized
INFO - 2023-09-24 04:18:42 --> Controller Class Initialized
INFO - 2023-09-24 04:18:42 --> Model Class Initialized
DEBUG - 2023-09-24 04:18:42 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-09-24 04:18:42 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-24 04:18:42 --> Model Class Initialized
DEBUG - 2023-09-24 04:18:42 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-24 04:18:42 --> Model Class Initialized
INFO - 2023-09-24 04:18:42 --> Final output sent to browser
DEBUG - 2023-09-24 04:18:42 --> Total execution time: 0.0228
ERROR - 2023-09-24 04:18:44 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-24 04:18:44 --> Config Class Initialized
INFO - 2023-09-24 04:18:44 --> Hooks Class Initialized
DEBUG - 2023-09-24 04:18:44 --> UTF-8 Support Enabled
INFO - 2023-09-24 04:18:44 --> Utf8 Class Initialized
INFO - 2023-09-24 04:18:44 --> URI Class Initialized
INFO - 2023-09-24 04:18:44 --> Router Class Initialized
INFO - 2023-09-24 04:18:44 --> Output Class Initialized
INFO - 2023-09-24 04:18:44 --> Security Class Initialized
DEBUG - 2023-09-24 04:18:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-24 04:18:44 --> Input Class Initialized
INFO - 2023-09-24 04:18:44 --> Language Class Initialized
INFO - 2023-09-24 04:18:44 --> Loader Class Initialized
INFO - 2023-09-24 04:18:44 --> Helper loaded: url_helper
INFO - 2023-09-24 04:18:44 --> Helper loaded: file_helper
INFO - 2023-09-24 04:18:44 --> Helper loaded: html_helper
INFO - 2023-09-24 04:18:44 --> Helper loaded: text_helper
INFO - 2023-09-24 04:18:44 --> Helper loaded: form_helper
INFO - 2023-09-24 04:18:44 --> Helper loaded: lang_helper
INFO - 2023-09-24 04:18:44 --> Helper loaded: security_helper
INFO - 2023-09-24 04:18:44 --> Helper loaded: cookie_helper
INFO - 2023-09-24 04:18:44 --> Database Driver Class Initialized
INFO - 2023-09-24 04:18:44 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-24 04:18:44 --> Parser Class Initialized
INFO - 2023-09-24 04:18:44 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-24 04:18:44 --> Pagination Class Initialized
INFO - 2023-09-24 04:18:44 --> Form Validation Class Initialized
INFO - 2023-09-24 04:18:44 --> Controller Class Initialized
INFO - 2023-09-24 04:18:44 --> Model Class Initialized
DEBUG - 2023-09-24 04:18:44 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-09-24 04:18:44 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-24 04:18:44 --> Model Class Initialized
DEBUG - 2023-09-24 04:18:44 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-24 04:18:44 --> Model Class Initialized
INFO - 2023-09-24 04:18:44 --> Model Class Initialized
INFO - 2023-09-24 04:18:44 --> Final output sent to browser
DEBUG - 2023-09-24 04:18:44 --> Total execution time: 0.0254
ERROR - 2023-09-24 04:19:17 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-24 04:19:17 --> Config Class Initialized
INFO - 2023-09-24 04:19:17 --> Hooks Class Initialized
DEBUG - 2023-09-24 04:19:17 --> UTF-8 Support Enabled
INFO - 2023-09-24 04:19:17 --> Utf8 Class Initialized
INFO - 2023-09-24 04:19:17 --> URI Class Initialized
INFO - 2023-09-24 04:19:17 --> Router Class Initialized
INFO - 2023-09-24 04:19:17 --> Output Class Initialized
INFO - 2023-09-24 04:19:17 --> Security Class Initialized
DEBUG - 2023-09-24 04:19:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-24 04:19:17 --> Input Class Initialized
INFO - 2023-09-24 04:19:17 --> Language Class Initialized
INFO - 2023-09-24 04:19:17 --> Loader Class Initialized
INFO - 2023-09-24 04:19:17 --> Helper loaded: url_helper
INFO - 2023-09-24 04:19:17 --> Helper loaded: file_helper
INFO - 2023-09-24 04:19:17 --> Helper loaded: html_helper
INFO - 2023-09-24 04:19:17 --> Helper loaded: text_helper
INFO - 2023-09-24 04:19:17 --> Helper loaded: form_helper
INFO - 2023-09-24 04:19:17 --> Helper loaded: lang_helper
INFO - 2023-09-24 04:19:17 --> Helper loaded: security_helper
INFO - 2023-09-24 04:19:17 --> Helper loaded: cookie_helper
INFO - 2023-09-24 04:19:17 --> Database Driver Class Initialized
INFO - 2023-09-24 04:19:17 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-24 04:19:17 --> Parser Class Initialized
INFO - 2023-09-24 04:19:17 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-24 04:19:17 --> Pagination Class Initialized
INFO - 2023-09-24 04:19:17 --> Form Validation Class Initialized
INFO - 2023-09-24 04:19:17 --> Controller Class Initialized
INFO - 2023-09-24 04:19:17 --> Model Class Initialized
DEBUG - 2023-09-24 04:19:17 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-09-24 04:19:17 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-24 04:19:17 --> Model Class Initialized
DEBUG - 2023-09-24 04:19:17 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-24 04:19:17 --> Model Class Initialized
INFO - 2023-09-24 04:19:17 --> Final output sent to browser
DEBUG - 2023-09-24 04:19:17 --> Total execution time: 0.0708
ERROR - 2023-09-24 04:19:17 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-24 04:19:17 --> Config Class Initialized
INFO - 2023-09-24 04:19:17 --> Hooks Class Initialized
DEBUG - 2023-09-24 04:19:17 --> UTF-8 Support Enabled
INFO - 2023-09-24 04:19:17 --> Utf8 Class Initialized
INFO - 2023-09-24 04:19:17 --> URI Class Initialized
INFO - 2023-09-24 04:19:17 --> Router Class Initialized
INFO - 2023-09-24 04:19:17 --> Output Class Initialized
INFO - 2023-09-24 04:19:17 --> Security Class Initialized
DEBUG - 2023-09-24 04:19:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-24 04:19:17 --> Input Class Initialized
INFO - 2023-09-24 04:19:17 --> Language Class Initialized
INFO - 2023-09-24 04:19:17 --> Loader Class Initialized
INFO - 2023-09-24 04:19:17 --> Helper loaded: url_helper
INFO - 2023-09-24 04:19:17 --> Helper loaded: file_helper
INFO - 2023-09-24 04:19:17 --> Helper loaded: html_helper
INFO - 2023-09-24 04:19:17 --> Helper loaded: text_helper
INFO - 2023-09-24 04:19:17 --> Helper loaded: form_helper
INFO - 2023-09-24 04:19:17 --> Helper loaded: lang_helper
INFO - 2023-09-24 04:19:17 --> Helper loaded: security_helper
INFO - 2023-09-24 04:19:17 --> Helper loaded: cookie_helper
INFO - 2023-09-24 04:19:17 --> Database Driver Class Initialized
INFO - 2023-09-24 04:19:17 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-24 04:19:17 --> Parser Class Initialized
INFO - 2023-09-24 04:19:17 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-24 04:19:17 --> Pagination Class Initialized
INFO - 2023-09-24 04:19:17 --> Form Validation Class Initialized
INFO - 2023-09-24 04:19:17 --> Controller Class Initialized
INFO - 2023-09-24 04:19:17 --> Model Class Initialized
DEBUG - 2023-09-24 04:19:17 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-09-24 04:19:17 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-24 04:19:17 --> Model Class Initialized
DEBUG - 2023-09-24 04:19:17 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-24 04:19:17 --> Model Class Initialized
INFO - 2023-09-24 04:19:18 --> Final output sent to browser
DEBUG - 2023-09-24 04:19:18 --> Total execution time: 0.0655
ERROR - 2023-09-24 04:19:18 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-24 04:19:18 --> Config Class Initialized
INFO - 2023-09-24 04:19:18 --> Hooks Class Initialized
DEBUG - 2023-09-24 04:19:18 --> UTF-8 Support Enabled
INFO - 2023-09-24 04:19:18 --> Utf8 Class Initialized
INFO - 2023-09-24 04:19:18 --> URI Class Initialized
INFO - 2023-09-24 04:19:18 --> Router Class Initialized
INFO - 2023-09-24 04:19:18 --> Output Class Initialized
INFO - 2023-09-24 04:19:18 --> Security Class Initialized
DEBUG - 2023-09-24 04:19:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-24 04:19:18 --> Input Class Initialized
INFO - 2023-09-24 04:19:18 --> Language Class Initialized
INFO - 2023-09-24 04:19:18 --> Loader Class Initialized
INFO - 2023-09-24 04:19:18 --> Helper loaded: url_helper
INFO - 2023-09-24 04:19:18 --> Helper loaded: file_helper
INFO - 2023-09-24 04:19:18 --> Helper loaded: html_helper
INFO - 2023-09-24 04:19:18 --> Helper loaded: text_helper
INFO - 2023-09-24 04:19:18 --> Helper loaded: form_helper
INFO - 2023-09-24 04:19:18 --> Helper loaded: lang_helper
INFO - 2023-09-24 04:19:18 --> Helper loaded: security_helper
INFO - 2023-09-24 04:19:18 --> Helper loaded: cookie_helper
INFO - 2023-09-24 04:19:18 --> Database Driver Class Initialized
INFO - 2023-09-24 04:19:18 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-24 04:19:18 --> Parser Class Initialized
INFO - 2023-09-24 04:19:18 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-24 04:19:18 --> Pagination Class Initialized
INFO - 2023-09-24 04:19:18 --> Form Validation Class Initialized
INFO - 2023-09-24 04:19:18 --> Controller Class Initialized
INFO - 2023-09-24 04:19:18 --> Model Class Initialized
DEBUG - 2023-09-24 04:19:18 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-09-24 04:19:18 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-24 04:19:18 --> Model Class Initialized
DEBUG - 2023-09-24 04:19:18 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-24 04:19:18 --> Model Class Initialized
INFO - 2023-09-24 04:19:18 --> Final output sent to browser
DEBUG - 2023-09-24 04:19:18 --> Total execution time: 0.0223
ERROR - 2023-09-24 04:19:21 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-24 04:19:21 --> Config Class Initialized
INFO - 2023-09-24 04:19:21 --> Hooks Class Initialized
DEBUG - 2023-09-24 04:19:21 --> UTF-8 Support Enabled
INFO - 2023-09-24 04:19:21 --> Utf8 Class Initialized
INFO - 2023-09-24 04:19:21 --> URI Class Initialized
INFO - 2023-09-24 04:19:21 --> Router Class Initialized
INFO - 2023-09-24 04:19:21 --> Output Class Initialized
INFO - 2023-09-24 04:19:21 --> Security Class Initialized
DEBUG - 2023-09-24 04:19:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-24 04:19:21 --> Input Class Initialized
INFO - 2023-09-24 04:19:21 --> Language Class Initialized
INFO - 2023-09-24 04:19:21 --> Loader Class Initialized
INFO - 2023-09-24 04:19:21 --> Helper loaded: url_helper
INFO - 2023-09-24 04:19:21 --> Helper loaded: file_helper
INFO - 2023-09-24 04:19:21 --> Helper loaded: html_helper
INFO - 2023-09-24 04:19:21 --> Helper loaded: text_helper
INFO - 2023-09-24 04:19:21 --> Helper loaded: form_helper
INFO - 2023-09-24 04:19:21 --> Helper loaded: lang_helper
INFO - 2023-09-24 04:19:21 --> Helper loaded: security_helper
INFO - 2023-09-24 04:19:21 --> Helper loaded: cookie_helper
INFO - 2023-09-24 04:19:21 --> Database Driver Class Initialized
INFO - 2023-09-24 04:19:21 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-24 04:19:21 --> Parser Class Initialized
INFO - 2023-09-24 04:19:21 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-24 04:19:21 --> Pagination Class Initialized
INFO - 2023-09-24 04:19:21 --> Form Validation Class Initialized
INFO - 2023-09-24 04:19:21 --> Controller Class Initialized
INFO - 2023-09-24 04:19:21 --> Model Class Initialized
DEBUG - 2023-09-24 04:19:21 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-09-24 04:19:21 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-24 04:19:21 --> Model Class Initialized
DEBUG - 2023-09-24 04:19:21 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-24 04:19:21 --> Model Class Initialized
INFO - 2023-09-24 04:19:21 --> Model Class Initialized
INFO - 2023-09-24 04:19:21 --> Final output sent to browser
DEBUG - 2023-09-24 04:19:21 --> Total execution time: 0.0243
ERROR - 2023-09-24 04:19:29 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-24 04:19:29 --> Config Class Initialized
INFO - 2023-09-24 04:19:29 --> Hooks Class Initialized
DEBUG - 2023-09-24 04:19:29 --> UTF-8 Support Enabled
INFO - 2023-09-24 04:19:29 --> Utf8 Class Initialized
INFO - 2023-09-24 04:19:29 --> URI Class Initialized
INFO - 2023-09-24 04:19:29 --> Router Class Initialized
INFO - 2023-09-24 04:19:29 --> Output Class Initialized
INFO - 2023-09-24 04:19:29 --> Security Class Initialized
DEBUG - 2023-09-24 04:19:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-24 04:19:29 --> Input Class Initialized
INFO - 2023-09-24 04:19:29 --> Language Class Initialized
INFO - 2023-09-24 04:19:29 --> Loader Class Initialized
INFO - 2023-09-24 04:19:29 --> Helper loaded: url_helper
INFO - 2023-09-24 04:19:29 --> Helper loaded: file_helper
INFO - 2023-09-24 04:19:29 --> Helper loaded: html_helper
INFO - 2023-09-24 04:19:29 --> Helper loaded: text_helper
INFO - 2023-09-24 04:19:29 --> Helper loaded: form_helper
INFO - 2023-09-24 04:19:29 --> Helper loaded: lang_helper
INFO - 2023-09-24 04:19:29 --> Helper loaded: security_helper
INFO - 2023-09-24 04:19:29 --> Helper loaded: cookie_helper
INFO - 2023-09-24 04:19:29 --> Database Driver Class Initialized
INFO - 2023-09-24 04:19:29 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-24 04:19:29 --> Parser Class Initialized
INFO - 2023-09-24 04:19:29 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-24 04:19:29 --> Pagination Class Initialized
INFO - 2023-09-24 04:19:29 --> Form Validation Class Initialized
INFO - 2023-09-24 04:19:29 --> Controller Class Initialized
INFO - 2023-09-24 04:19:29 --> Model Class Initialized
DEBUG - 2023-09-24 04:19:29 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-09-24 04:19:29 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-24 04:19:29 --> Model Class Initialized
INFO - 2023-09-24 04:19:29 --> Email Class Initialized
INFO - 2023-09-24 04:19:29 --> Language file loaded: language/english/email_lang.php
ERROR - 2023-09-24 04:19:29 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-24 04:19:29 --> Config Class Initialized
INFO - 2023-09-24 04:19:29 --> Hooks Class Initialized
DEBUG - 2023-09-24 04:19:29 --> UTF-8 Support Enabled
INFO - 2023-09-24 04:19:29 --> Utf8 Class Initialized
INFO - 2023-09-24 04:19:29 --> URI Class Initialized
INFO - 2023-09-24 04:19:29 --> Router Class Initialized
INFO - 2023-09-24 04:19:29 --> Output Class Initialized
INFO - 2023-09-24 04:19:29 --> Security Class Initialized
DEBUG - 2023-09-24 04:19:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-24 04:19:29 --> Input Class Initialized
INFO - 2023-09-24 04:19:29 --> Language Class Initialized
INFO - 2023-09-24 04:19:29 --> Loader Class Initialized
INFO - 2023-09-24 04:19:29 --> Helper loaded: url_helper
INFO - 2023-09-24 04:19:29 --> Helper loaded: file_helper
INFO - 2023-09-24 04:19:29 --> Helper loaded: html_helper
INFO - 2023-09-24 04:19:29 --> Helper loaded: text_helper
INFO - 2023-09-24 04:19:29 --> Helper loaded: form_helper
INFO - 2023-09-24 04:19:29 --> Helper loaded: lang_helper
INFO - 2023-09-24 04:19:29 --> Helper loaded: security_helper
INFO - 2023-09-24 04:19:29 --> Helper loaded: cookie_helper
INFO - 2023-09-24 04:19:29 --> Database Driver Class Initialized
INFO - 2023-09-24 04:19:29 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-24 04:19:29 --> Parser Class Initialized
INFO - 2023-09-24 04:19:29 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-24 04:19:29 --> Pagination Class Initialized
INFO - 2023-09-24 04:19:29 --> Form Validation Class Initialized
INFO - 2023-09-24 04:19:29 --> Controller Class Initialized
INFO - 2023-09-24 04:19:29 --> Model Class Initialized
DEBUG - 2023-09-24 04:19:29 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-09-24 04:19:29 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-24 04:19:29 --> Model Class Initialized
DEBUG - 2023-09-24 04:19:29 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-24 04:19:29 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/demandrequest/add_demandrequest_form.php
DEBUG - 2023-09-24 04:19:29 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-09-24 04:19:29 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-09-24 04:19:29 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-09-24 04:19:29 --> Model Class Initialized
INFO - 2023-09-24 04:19:29 --> Model Class Initialized
INFO - 2023-09-24 04:19:29 --> Model Class Initialized
INFO - 2023-09-24 04:19:29 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-09-24 04:19:29 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-09-24 04:19:29 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-09-24 04:19:29 --> Final output sent to browser
DEBUG - 2023-09-24 04:19:29 --> Total execution time: 0.1002
ERROR - 2023-09-24 13:16:26 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-24 13:16:26 --> Config Class Initialized
INFO - 2023-09-24 13:16:26 --> Hooks Class Initialized
DEBUG - 2023-09-24 13:16:26 --> UTF-8 Support Enabled
INFO - 2023-09-24 13:16:26 --> Utf8 Class Initialized
INFO - 2023-09-24 13:16:26 --> URI Class Initialized
DEBUG - 2023-09-24 13:16:26 --> No URI present. Default controller set.
INFO - 2023-09-24 13:16:26 --> Router Class Initialized
INFO - 2023-09-24 13:16:26 --> Output Class Initialized
INFO - 2023-09-24 13:16:26 --> Security Class Initialized
DEBUG - 2023-09-24 13:16:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-24 13:16:26 --> Input Class Initialized
INFO - 2023-09-24 13:16:26 --> Language Class Initialized
INFO - 2023-09-24 13:16:26 --> Loader Class Initialized
INFO - 2023-09-24 13:16:26 --> Helper loaded: url_helper
INFO - 2023-09-24 13:16:26 --> Helper loaded: file_helper
INFO - 2023-09-24 13:16:26 --> Helper loaded: html_helper
INFO - 2023-09-24 13:16:26 --> Helper loaded: text_helper
INFO - 2023-09-24 13:16:26 --> Helper loaded: form_helper
INFO - 2023-09-24 13:16:26 --> Helper loaded: lang_helper
INFO - 2023-09-24 13:16:26 --> Helper loaded: security_helper
INFO - 2023-09-24 13:16:26 --> Helper loaded: cookie_helper
INFO - 2023-09-24 13:16:26 --> Database Driver Class Initialized
INFO - 2023-09-24 13:16:26 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-24 13:16:26 --> Parser Class Initialized
INFO - 2023-09-24 13:16:26 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-24 13:16:26 --> Pagination Class Initialized
INFO - 2023-09-24 13:16:26 --> Form Validation Class Initialized
INFO - 2023-09-24 13:16:26 --> Controller Class Initialized
INFO - 2023-09-24 13:16:26 --> Model Class Initialized
DEBUG - 2023-09-24 13:16:26 --> Session class already loaded. Second attempt ignored.
ERROR - 2023-09-24 13:16:27 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-24 13:16:27 --> Config Class Initialized
INFO - 2023-09-24 13:16:27 --> Hooks Class Initialized
DEBUG - 2023-09-24 13:16:27 --> UTF-8 Support Enabled
INFO - 2023-09-24 13:16:27 --> Utf8 Class Initialized
INFO - 2023-09-24 13:16:27 --> URI Class Initialized
INFO - 2023-09-24 13:16:27 --> Router Class Initialized
INFO - 2023-09-24 13:16:27 --> Output Class Initialized
INFO - 2023-09-24 13:16:27 --> Security Class Initialized
DEBUG - 2023-09-24 13:16:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-24 13:16:27 --> Input Class Initialized
INFO - 2023-09-24 13:16:27 --> Language Class Initialized
INFO - 2023-09-24 13:16:27 --> Loader Class Initialized
INFO - 2023-09-24 13:16:27 --> Helper loaded: url_helper
INFO - 2023-09-24 13:16:27 --> Helper loaded: file_helper
INFO - 2023-09-24 13:16:27 --> Helper loaded: html_helper
INFO - 2023-09-24 13:16:27 --> Helper loaded: text_helper
INFO - 2023-09-24 13:16:27 --> Helper loaded: form_helper
INFO - 2023-09-24 13:16:27 --> Helper loaded: lang_helper
INFO - 2023-09-24 13:16:27 --> Helper loaded: security_helper
INFO - 2023-09-24 13:16:27 --> Helper loaded: cookie_helper
INFO - 2023-09-24 13:16:27 --> Database Driver Class Initialized
INFO - 2023-09-24 13:16:27 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-24 13:16:27 --> Parser Class Initialized
INFO - 2023-09-24 13:16:27 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-24 13:16:27 --> Pagination Class Initialized
INFO - 2023-09-24 13:16:27 --> Form Validation Class Initialized
INFO - 2023-09-24 13:16:27 --> Controller Class Initialized
INFO - 2023-09-24 13:16:27 --> Model Class Initialized
DEBUG - 2023-09-24 13:16:27 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-24 13:16:27 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2023-09-24 13:16:27 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-09-24 13:16:27 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-09-24 13:16:27 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-09-24 13:16:27 --> Model Class Initialized
INFO - 2023-09-24 13:16:27 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-09-24 13:16:27 --> Final output sent to browser
DEBUG - 2023-09-24 13:16:27 --> Total execution time: 0.0326
ERROR - 2023-09-24 13:16:31 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-24 13:16:31 --> Config Class Initialized
INFO - 2023-09-24 13:16:31 --> Hooks Class Initialized
DEBUG - 2023-09-24 13:16:31 --> UTF-8 Support Enabled
INFO - 2023-09-24 13:16:31 --> Utf8 Class Initialized
INFO - 2023-09-24 13:16:31 --> URI Class Initialized
INFO - 2023-09-24 13:16:31 --> Router Class Initialized
INFO - 2023-09-24 13:16:31 --> Output Class Initialized
INFO - 2023-09-24 13:16:31 --> Security Class Initialized
DEBUG - 2023-09-24 13:16:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-24 13:16:31 --> Input Class Initialized
INFO - 2023-09-24 13:16:31 --> Language Class Initialized
INFO - 2023-09-24 13:16:31 --> Loader Class Initialized
INFO - 2023-09-24 13:16:31 --> Helper loaded: url_helper
INFO - 2023-09-24 13:16:31 --> Helper loaded: file_helper
INFO - 2023-09-24 13:16:31 --> Helper loaded: html_helper
INFO - 2023-09-24 13:16:31 --> Helper loaded: text_helper
INFO - 2023-09-24 13:16:31 --> Helper loaded: form_helper
INFO - 2023-09-24 13:16:31 --> Helper loaded: lang_helper
INFO - 2023-09-24 13:16:31 --> Helper loaded: security_helper
INFO - 2023-09-24 13:16:31 --> Helper loaded: cookie_helper
INFO - 2023-09-24 13:16:31 --> Database Driver Class Initialized
INFO - 2023-09-24 13:16:31 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-24 13:16:31 --> Parser Class Initialized
INFO - 2023-09-24 13:16:31 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-24 13:16:31 --> Pagination Class Initialized
INFO - 2023-09-24 13:16:31 --> Form Validation Class Initialized
INFO - 2023-09-24 13:16:31 --> Controller Class Initialized
INFO - 2023-09-24 13:16:31 --> Model Class Initialized
DEBUG - 2023-09-24 13:16:31 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-24 13:16:31 --> Model Class Initialized
INFO - 2023-09-24 13:16:31 --> Final output sent to browser
DEBUG - 2023-09-24 13:16:31 --> Total execution time: 0.0199
ERROR - 2023-09-24 13:16:31 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-24 13:16:31 --> Config Class Initialized
INFO - 2023-09-24 13:16:31 --> Hooks Class Initialized
DEBUG - 2023-09-24 13:16:31 --> UTF-8 Support Enabled
INFO - 2023-09-24 13:16:31 --> Utf8 Class Initialized
INFO - 2023-09-24 13:16:31 --> URI Class Initialized
DEBUG - 2023-09-24 13:16:31 --> No URI present. Default controller set.
INFO - 2023-09-24 13:16:31 --> Router Class Initialized
INFO - 2023-09-24 13:16:31 --> Output Class Initialized
INFO - 2023-09-24 13:16:31 --> Security Class Initialized
DEBUG - 2023-09-24 13:16:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-24 13:16:31 --> Input Class Initialized
INFO - 2023-09-24 13:16:31 --> Language Class Initialized
INFO - 2023-09-24 13:16:31 --> Loader Class Initialized
INFO - 2023-09-24 13:16:31 --> Helper loaded: url_helper
INFO - 2023-09-24 13:16:31 --> Helper loaded: file_helper
INFO - 2023-09-24 13:16:31 --> Helper loaded: html_helper
INFO - 2023-09-24 13:16:31 --> Helper loaded: text_helper
INFO - 2023-09-24 13:16:31 --> Helper loaded: form_helper
INFO - 2023-09-24 13:16:31 --> Helper loaded: lang_helper
INFO - 2023-09-24 13:16:31 --> Helper loaded: security_helper
INFO - 2023-09-24 13:16:31 --> Helper loaded: cookie_helper
INFO - 2023-09-24 13:16:31 --> Database Driver Class Initialized
INFO - 2023-09-24 13:16:31 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-24 13:16:31 --> Parser Class Initialized
INFO - 2023-09-24 13:16:31 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-24 13:16:31 --> Pagination Class Initialized
INFO - 2023-09-24 13:16:31 --> Form Validation Class Initialized
INFO - 2023-09-24 13:16:31 --> Controller Class Initialized
INFO - 2023-09-24 13:16:31 --> Model Class Initialized
DEBUG - 2023-09-24 13:16:31 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-24 13:16:31 --> Model Class Initialized
DEBUG - 2023-09-24 13:16:31 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-24 13:16:31 --> Model Class Initialized
INFO - 2023-09-24 13:16:31 --> Model Class Initialized
INFO - 2023-09-24 13:16:31 --> Model Class Initialized
INFO - 2023-09-24 13:16:31 --> Model Class Initialized
DEBUG - 2023-09-24 13:16:31 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-09-24 13:16:31 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-24 13:16:31 --> Model Class Initialized
INFO - 2023-09-24 13:16:31 --> Model Class Initialized
INFO - 2023-09-24 13:16:32 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-09-24 13:16:32 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-09-24 13:16:32 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-09-24 13:16:32 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-09-24 13:16:32 --> Model Class Initialized
INFO - 2023-09-24 13:16:32 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-09-24 13:16:32 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-09-24 13:16:32 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-09-24 13:16:32 --> Final output sent to browser
DEBUG - 2023-09-24 13:16:32 --> Total execution time: 0.1219
ERROR - 2023-09-24 13:17:03 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-24 13:17:03 --> Config Class Initialized
INFO - 2023-09-24 13:17:03 --> Hooks Class Initialized
DEBUG - 2023-09-24 13:17:03 --> UTF-8 Support Enabled
INFO - 2023-09-24 13:17:03 --> Utf8 Class Initialized
INFO - 2023-09-24 13:17:03 --> URI Class Initialized
INFO - 2023-09-24 13:17:03 --> Router Class Initialized
INFO - 2023-09-24 13:17:03 --> Output Class Initialized
INFO - 2023-09-24 13:17:03 --> Security Class Initialized
DEBUG - 2023-09-24 13:17:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-24 13:17:03 --> Input Class Initialized
INFO - 2023-09-24 13:17:03 --> Language Class Initialized
INFO - 2023-09-24 13:17:03 --> Loader Class Initialized
INFO - 2023-09-24 13:17:03 --> Helper loaded: url_helper
INFO - 2023-09-24 13:17:03 --> Helper loaded: file_helper
INFO - 2023-09-24 13:17:03 --> Helper loaded: html_helper
INFO - 2023-09-24 13:17:03 --> Helper loaded: text_helper
INFO - 2023-09-24 13:17:03 --> Helper loaded: form_helper
INFO - 2023-09-24 13:17:03 --> Helper loaded: lang_helper
INFO - 2023-09-24 13:17:03 --> Helper loaded: security_helper
INFO - 2023-09-24 13:17:03 --> Helper loaded: cookie_helper
INFO - 2023-09-24 13:17:03 --> Database Driver Class Initialized
INFO - 2023-09-24 13:17:03 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-24 13:17:03 --> Parser Class Initialized
INFO - 2023-09-24 13:17:03 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-24 13:17:03 --> Pagination Class Initialized
INFO - 2023-09-24 13:17:03 --> Form Validation Class Initialized
INFO - 2023-09-24 13:17:03 --> Controller Class Initialized
INFO - 2023-09-24 13:17:03 --> Model Class Initialized
DEBUG - 2023-09-24 13:17:03 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-09-24 13:17:03 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-24 13:17:03 --> Model Class Initialized
DEBUG - 2023-09-24 13:17:03 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-24 13:17:03 --> Model Class Initialized
INFO - 2023-09-24 13:17:03 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice.php
DEBUG - 2023-09-24 13:17:03 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-09-24 13:17:03 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-09-24 13:17:03 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-09-24 13:17:03 --> Model Class Initialized
INFO - 2023-09-24 13:17:03 --> Model Class Initialized
INFO - 2023-09-24 13:17:03 --> Model Class Initialized
INFO - 2023-09-24 13:17:03 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-09-24 13:17:03 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-09-24 13:17:03 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-09-24 13:17:03 --> Final output sent to browser
DEBUG - 2023-09-24 13:17:03 --> Total execution time: 0.0879
ERROR - 2023-09-24 13:17:03 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-24 13:17:03 --> Config Class Initialized
INFO - 2023-09-24 13:17:03 --> Hooks Class Initialized
DEBUG - 2023-09-24 13:17:03 --> UTF-8 Support Enabled
INFO - 2023-09-24 13:17:03 --> Utf8 Class Initialized
INFO - 2023-09-24 13:17:03 --> URI Class Initialized
INFO - 2023-09-24 13:17:03 --> Router Class Initialized
INFO - 2023-09-24 13:17:03 --> Output Class Initialized
INFO - 2023-09-24 13:17:03 --> Security Class Initialized
DEBUG - 2023-09-24 13:17:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-24 13:17:03 --> Input Class Initialized
INFO - 2023-09-24 13:17:03 --> Language Class Initialized
INFO - 2023-09-24 13:17:03 --> Loader Class Initialized
INFO - 2023-09-24 13:17:03 --> Helper loaded: url_helper
INFO - 2023-09-24 13:17:03 --> Helper loaded: file_helper
INFO - 2023-09-24 13:17:03 --> Helper loaded: html_helper
INFO - 2023-09-24 13:17:03 --> Helper loaded: text_helper
INFO - 2023-09-24 13:17:03 --> Helper loaded: form_helper
INFO - 2023-09-24 13:17:03 --> Helper loaded: lang_helper
INFO - 2023-09-24 13:17:03 --> Helper loaded: security_helper
INFO - 2023-09-24 13:17:03 --> Helper loaded: cookie_helper
INFO - 2023-09-24 13:17:03 --> Database Driver Class Initialized
INFO - 2023-09-24 13:17:03 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-24 13:17:03 --> Parser Class Initialized
INFO - 2023-09-24 13:17:03 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-24 13:17:03 --> Pagination Class Initialized
INFO - 2023-09-24 13:17:03 --> Form Validation Class Initialized
INFO - 2023-09-24 13:17:03 --> Controller Class Initialized
INFO - 2023-09-24 13:17:03 --> Model Class Initialized
DEBUG - 2023-09-24 13:17:03 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-09-24 13:17:03 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-24 13:17:03 --> Model Class Initialized
DEBUG - 2023-09-24 13:17:03 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-24 13:17:03 --> Model Class Initialized
INFO - 2023-09-24 13:17:03 --> Final output sent to browser
DEBUG - 2023-09-24 13:17:03 --> Total execution time: 0.0428
ERROR - 2023-09-24 13:17:17 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-24 13:17:17 --> Config Class Initialized
INFO - 2023-09-24 13:17:17 --> Hooks Class Initialized
DEBUG - 2023-09-24 13:17:17 --> UTF-8 Support Enabled
INFO - 2023-09-24 13:17:17 --> Utf8 Class Initialized
INFO - 2023-09-24 13:17:17 --> URI Class Initialized
INFO - 2023-09-24 13:17:17 --> Router Class Initialized
INFO - 2023-09-24 13:17:17 --> Output Class Initialized
INFO - 2023-09-24 13:17:17 --> Security Class Initialized
DEBUG - 2023-09-24 13:17:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-24 13:17:17 --> Input Class Initialized
INFO - 2023-09-24 13:17:17 --> Language Class Initialized
INFO - 2023-09-24 13:17:17 --> Loader Class Initialized
INFO - 2023-09-24 13:17:17 --> Helper loaded: url_helper
INFO - 2023-09-24 13:17:17 --> Helper loaded: file_helper
INFO - 2023-09-24 13:17:17 --> Helper loaded: html_helper
INFO - 2023-09-24 13:17:17 --> Helper loaded: text_helper
INFO - 2023-09-24 13:17:17 --> Helper loaded: form_helper
INFO - 2023-09-24 13:17:17 --> Helper loaded: lang_helper
INFO - 2023-09-24 13:17:17 --> Helper loaded: security_helper
INFO - 2023-09-24 13:17:17 --> Helper loaded: cookie_helper
INFO - 2023-09-24 13:17:17 --> Database Driver Class Initialized
INFO - 2023-09-24 13:17:17 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-24 13:17:17 --> Parser Class Initialized
INFO - 2023-09-24 13:17:17 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-24 13:17:17 --> Pagination Class Initialized
INFO - 2023-09-24 13:17:17 --> Form Validation Class Initialized
INFO - 2023-09-24 13:17:17 --> Controller Class Initialized
INFO - 2023-09-24 13:17:17 --> Model Class Initialized
DEBUG - 2023-09-24 13:17:17 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-09-24 13:17:17 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-24 13:17:17 --> Model Class Initialized
DEBUG - 2023-09-24 13:17:17 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-24 13:17:17 --> Model Class Initialized
INFO - 2023-09-24 13:17:17 --> Final output sent to browser
DEBUG - 2023-09-24 13:17:17 --> Total execution time: 0.1523
ERROR - 2023-09-24 13:18:33 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-24 13:18:33 --> Config Class Initialized
INFO - 2023-09-24 13:18:33 --> Hooks Class Initialized
DEBUG - 2023-09-24 13:18:33 --> UTF-8 Support Enabled
INFO - 2023-09-24 13:18:33 --> Utf8 Class Initialized
INFO - 2023-09-24 13:18:33 --> URI Class Initialized
INFO - 2023-09-24 13:18:33 --> Router Class Initialized
INFO - 2023-09-24 13:18:33 --> Output Class Initialized
INFO - 2023-09-24 13:18:33 --> Security Class Initialized
DEBUG - 2023-09-24 13:18:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-24 13:18:33 --> Input Class Initialized
INFO - 2023-09-24 13:18:33 --> Language Class Initialized
INFO - 2023-09-24 13:18:33 --> Loader Class Initialized
INFO - 2023-09-24 13:18:33 --> Helper loaded: url_helper
INFO - 2023-09-24 13:18:33 --> Helper loaded: file_helper
INFO - 2023-09-24 13:18:33 --> Helper loaded: html_helper
INFO - 2023-09-24 13:18:33 --> Helper loaded: text_helper
INFO - 2023-09-24 13:18:33 --> Helper loaded: form_helper
INFO - 2023-09-24 13:18:33 --> Helper loaded: lang_helper
INFO - 2023-09-24 13:18:33 --> Helper loaded: security_helper
INFO - 2023-09-24 13:18:33 --> Helper loaded: cookie_helper
INFO - 2023-09-24 13:18:33 --> Database Driver Class Initialized
INFO - 2023-09-24 13:18:33 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-24 13:18:33 --> Parser Class Initialized
INFO - 2023-09-24 13:18:33 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-24 13:18:33 --> Pagination Class Initialized
INFO - 2023-09-24 13:18:33 --> Form Validation Class Initialized
INFO - 2023-09-24 13:18:33 --> Controller Class Initialized
INFO - 2023-09-24 13:18:33 --> Model Class Initialized
DEBUG - 2023-09-24 13:18:33 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-09-24 13:18:33 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-24 13:18:33 --> Model Class Initialized
DEBUG - 2023-09-24 13:18:33 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-24 13:18:33 --> Model Class Initialized
INFO - 2023-09-24 13:18:33 --> Final output sent to browser
DEBUG - 2023-09-24 13:18:33 --> Total execution time: 0.0232
ERROR - 2023-09-24 13:19:06 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-24 13:19:06 --> Config Class Initialized
INFO - 2023-09-24 13:19:06 --> Hooks Class Initialized
DEBUG - 2023-09-24 13:19:06 --> UTF-8 Support Enabled
INFO - 2023-09-24 13:19:06 --> Utf8 Class Initialized
INFO - 2023-09-24 13:19:06 --> URI Class Initialized
INFO - 2023-09-24 13:19:06 --> Router Class Initialized
INFO - 2023-09-24 13:19:06 --> Output Class Initialized
INFO - 2023-09-24 13:19:06 --> Security Class Initialized
DEBUG - 2023-09-24 13:19:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-24 13:19:06 --> Input Class Initialized
INFO - 2023-09-24 13:19:06 --> Language Class Initialized
INFO - 2023-09-24 13:19:06 --> Loader Class Initialized
INFO - 2023-09-24 13:19:06 --> Helper loaded: url_helper
INFO - 2023-09-24 13:19:06 --> Helper loaded: file_helper
INFO - 2023-09-24 13:19:06 --> Helper loaded: html_helper
INFO - 2023-09-24 13:19:06 --> Helper loaded: text_helper
INFO - 2023-09-24 13:19:06 --> Helper loaded: form_helper
INFO - 2023-09-24 13:19:06 --> Helper loaded: lang_helper
INFO - 2023-09-24 13:19:06 --> Helper loaded: security_helper
INFO - 2023-09-24 13:19:06 --> Helper loaded: cookie_helper
INFO - 2023-09-24 13:19:06 --> Database Driver Class Initialized
INFO - 2023-09-24 13:19:06 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-24 13:19:06 --> Parser Class Initialized
INFO - 2023-09-24 13:19:06 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-24 13:19:06 --> Pagination Class Initialized
INFO - 2023-09-24 13:19:06 --> Form Validation Class Initialized
INFO - 2023-09-24 13:19:06 --> Controller Class Initialized
INFO - 2023-09-24 13:19:06 --> Model Class Initialized
DEBUG - 2023-09-24 13:19:06 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-09-24 13:19:06 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-24 13:19:06 --> Model Class Initialized
DEBUG - 2023-09-24 13:19:06 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-24 13:19:06 --> Model Class Initialized
INFO - 2023-09-24 13:19:06 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice.php
DEBUG - 2023-09-24 13:19:06 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-09-24 13:19:06 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-09-24 13:19:06 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-09-24 13:19:06 --> Model Class Initialized
INFO - 2023-09-24 13:19:06 --> Model Class Initialized
INFO - 2023-09-24 13:19:06 --> Model Class Initialized
INFO - 2023-09-24 13:19:06 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-09-24 13:19:06 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-09-24 13:19:06 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-09-24 13:19:06 --> Final output sent to browser
DEBUG - 2023-09-24 13:19:06 --> Total execution time: 0.0930
ERROR - 2023-09-24 13:19:07 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-24 13:19:07 --> Config Class Initialized
INFO - 2023-09-24 13:19:07 --> Hooks Class Initialized
DEBUG - 2023-09-24 13:19:07 --> UTF-8 Support Enabled
INFO - 2023-09-24 13:19:07 --> Utf8 Class Initialized
INFO - 2023-09-24 13:19:07 --> URI Class Initialized
INFO - 2023-09-24 13:19:07 --> Router Class Initialized
INFO - 2023-09-24 13:19:07 --> Output Class Initialized
INFO - 2023-09-24 13:19:07 --> Security Class Initialized
DEBUG - 2023-09-24 13:19:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-24 13:19:07 --> Input Class Initialized
INFO - 2023-09-24 13:19:07 --> Language Class Initialized
INFO - 2023-09-24 13:19:07 --> Loader Class Initialized
INFO - 2023-09-24 13:19:07 --> Helper loaded: url_helper
INFO - 2023-09-24 13:19:07 --> Helper loaded: file_helper
INFO - 2023-09-24 13:19:07 --> Helper loaded: html_helper
INFO - 2023-09-24 13:19:07 --> Helper loaded: text_helper
INFO - 2023-09-24 13:19:07 --> Helper loaded: form_helper
INFO - 2023-09-24 13:19:07 --> Helper loaded: lang_helper
INFO - 2023-09-24 13:19:07 --> Helper loaded: security_helper
INFO - 2023-09-24 13:19:07 --> Helper loaded: cookie_helper
INFO - 2023-09-24 13:19:07 --> Database Driver Class Initialized
INFO - 2023-09-24 13:19:07 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-24 13:19:07 --> Parser Class Initialized
INFO - 2023-09-24 13:19:07 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-24 13:19:07 --> Pagination Class Initialized
INFO - 2023-09-24 13:19:07 --> Form Validation Class Initialized
INFO - 2023-09-24 13:19:07 --> Controller Class Initialized
INFO - 2023-09-24 13:19:07 --> Model Class Initialized
DEBUG - 2023-09-24 13:19:07 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-09-24 13:19:07 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-24 13:19:07 --> Model Class Initialized
DEBUG - 2023-09-24 13:19:07 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-24 13:19:07 --> Model Class Initialized
INFO - 2023-09-24 13:19:07 --> Final output sent to browser
DEBUG - 2023-09-24 13:19:07 --> Total execution time: 0.0466
ERROR - 2023-09-24 13:19:15 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-24 13:19:15 --> Config Class Initialized
INFO - 2023-09-24 13:19:15 --> Hooks Class Initialized
DEBUG - 2023-09-24 13:19:15 --> UTF-8 Support Enabled
INFO - 2023-09-24 13:19:15 --> Utf8 Class Initialized
INFO - 2023-09-24 13:19:15 --> URI Class Initialized
DEBUG - 2023-09-24 13:19:15 --> No URI present. Default controller set.
INFO - 2023-09-24 13:19:15 --> Router Class Initialized
INFO - 2023-09-24 13:19:15 --> Output Class Initialized
INFO - 2023-09-24 13:19:15 --> Security Class Initialized
DEBUG - 2023-09-24 13:19:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-24 13:19:15 --> Input Class Initialized
INFO - 2023-09-24 13:19:15 --> Language Class Initialized
INFO - 2023-09-24 13:19:15 --> Loader Class Initialized
INFO - 2023-09-24 13:19:15 --> Helper loaded: url_helper
INFO - 2023-09-24 13:19:15 --> Helper loaded: file_helper
INFO - 2023-09-24 13:19:15 --> Helper loaded: html_helper
INFO - 2023-09-24 13:19:15 --> Helper loaded: text_helper
INFO - 2023-09-24 13:19:15 --> Helper loaded: form_helper
INFO - 2023-09-24 13:19:15 --> Helper loaded: lang_helper
INFO - 2023-09-24 13:19:15 --> Helper loaded: security_helper
INFO - 2023-09-24 13:19:15 --> Helper loaded: cookie_helper
INFO - 2023-09-24 13:19:15 --> Database Driver Class Initialized
INFO - 2023-09-24 13:19:15 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-24 13:19:15 --> Parser Class Initialized
INFO - 2023-09-24 13:19:15 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-24 13:19:15 --> Pagination Class Initialized
INFO - 2023-09-24 13:19:15 --> Form Validation Class Initialized
INFO - 2023-09-24 13:19:15 --> Controller Class Initialized
INFO - 2023-09-24 13:19:15 --> Model Class Initialized
DEBUG - 2023-09-24 13:19:15 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-24 13:19:15 --> Model Class Initialized
DEBUG - 2023-09-24 13:19:15 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-24 13:19:15 --> Model Class Initialized
INFO - 2023-09-24 13:19:15 --> Model Class Initialized
INFO - 2023-09-24 13:19:15 --> Model Class Initialized
INFO - 2023-09-24 13:19:15 --> Model Class Initialized
DEBUG - 2023-09-24 13:19:15 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-09-24 13:19:15 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-24 13:19:15 --> Model Class Initialized
INFO - 2023-09-24 13:19:15 --> Model Class Initialized
INFO - 2023-09-24 13:19:15 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-09-24 13:19:15 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-09-24 13:19:15 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-09-24 13:19:15 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-09-24 13:19:15 --> Model Class Initialized
INFO - 2023-09-24 13:19:15 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-09-24 13:19:15 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-09-24 13:19:15 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-09-24 13:19:15 --> Final output sent to browser
DEBUG - 2023-09-24 13:19:15 --> Total execution time: 0.1022
ERROR - 2023-09-24 13:19:29 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-24 13:19:29 --> Config Class Initialized
INFO - 2023-09-24 13:19:29 --> Hooks Class Initialized
DEBUG - 2023-09-24 13:19:29 --> UTF-8 Support Enabled
INFO - 2023-09-24 13:19:29 --> Utf8 Class Initialized
INFO - 2023-09-24 13:19:29 --> URI Class Initialized
DEBUG - 2023-09-24 13:19:29 --> No URI present. Default controller set.
INFO - 2023-09-24 13:19:29 --> Router Class Initialized
INFO - 2023-09-24 13:19:29 --> Output Class Initialized
INFO - 2023-09-24 13:19:29 --> Security Class Initialized
DEBUG - 2023-09-24 13:19:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-24 13:19:29 --> Input Class Initialized
INFO - 2023-09-24 13:19:29 --> Language Class Initialized
INFO - 2023-09-24 13:19:29 --> Loader Class Initialized
INFO - 2023-09-24 13:19:29 --> Helper loaded: url_helper
INFO - 2023-09-24 13:19:29 --> Helper loaded: file_helper
INFO - 2023-09-24 13:19:29 --> Helper loaded: html_helper
INFO - 2023-09-24 13:19:29 --> Helper loaded: text_helper
INFO - 2023-09-24 13:19:29 --> Helper loaded: form_helper
INFO - 2023-09-24 13:19:29 --> Helper loaded: lang_helper
INFO - 2023-09-24 13:19:29 --> Helper loaded: security_helper
INFO - 2023-09-24 13:19:29 --> Helper loaded: cookie_helper
INFO - 2023-09-24 13:19:29 --> Database Driver Class Initialized
INFO - 2023-09-24 13:19:29 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-24 13:19:29 --> Parser Class Initialized
INFO - 2023-09-24 13:19:29 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-24 13:19:29 --> Pagination Class Initialized
INFO - 2023-09-24 13:19:29 --> Form Validation Class Initialized
INFO - 2023-09-24 13:19:29 --> Controller Class Initialized
INFO - 2023-09-24 13:19:29 --> Model Class Initialized
DEBUG - 2023-09-24 13:19:29 --> Session class already loaded. Second attempt ignored.
ERROR - 2023-09-24 13:19:29 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-24 13:19:29 --> Config Class Initialized
INFO - 2023-09-24 13:19:29 --> Hooks Class Initialized
DEBUG - 2023-09-24 13:19:29 --> UTF-8 Support Enabled
INFO - 2023-09-24 13:19:29 --> Utf8 Class Initialized
INFO - 2023-09-24 13:19:29 --> URI Class Initialized
INFO - 2023-09-24 13:19:29 --> Router Class Initialized
INFO - 2023-09-24 13:19:29 --> Output Class Initialized
INFO - 2023-09-24 13:19:29 --> Security Class Initialized
DEBUG - 2023-09-24 13:19:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-24 13:19:29 --> Input Class Initialized
INFO - 2023-09-24 13:19:29 --> Language Class Initialized
INFO - 2023-09-24 13:19:29 --> Loader Class Initialized
INFO - 2023-09-24 13:19:29 --> Helper loaded: url_helper
INFO - 2023-09-24 13:19:29 --> Helper loaded: file_helper
INFO - 2023-09-24 13:19:29 --> Helper loaded: html_helper
INFO - 2023-09-24 13:19:29 --> Helper loaded: text_helper
INFO - 2023-09-24 13:19:29 --> Helper loaded: form_helper
INFO - 2023-09-24 13:19:29 --> Helper loaded: lang_helper
INFO - 2023-09-24 13:19:29 --> Helper loaded: security_helper
INFO - 2023-09-24 13:19:29 --> Helper loaded: cookie_helper
INFO - 2023-09-24 13:19:29 --> Database Driver Class Initialized
INFO - 2023-09-24 13:19:29 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-24 13:19:29 --> Parser Class Initialized
INFO - 2023-09-24 13:19:29 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-24 13:19:29 --> Pagination Class Initialized
INFO - 2023-09-24 13:19:29 --> Form Validation Class Initialized
INFO - 2023-09-24 13:19:29 --> Controller Class Initialized
INFO - 2023-09-24 13:19:29 --> Model Class Initialized
DEBUG - 2023-09-24 13:19:29 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-24 13:19:29 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2023-09-24 13:19:29 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-09-24 13:19:29 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-09-24 13:19:29 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-09-24 13:19:29 --> Model Class Initialized
INFO - 2023-09-24 13:19:29 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-09-24 13:19:29 --> Final output sent to browser
DEBUG - 2023-09-24 13:19:29 --> Total execution time: 0.0297
ERROR - 2023-09-24 13:19:31 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-24 13:19:31 --> Config Class Initialized
INFO - 2023-09-24 13:19:31 --> Hooks Class Initialized
DEBUG - 2023-09-24 13:19:31 --> UTF-8 Support Enabled
INFO - 2023-09-24 13:19:31 --> Utf8 Class Initialized
INFO - 2023-09-24 13:19:31 --> URI Class Initialized
INFO - 2023-09-24 13:19:31 --> Router Class Initialized
INFO - 2023-09-24 13:19:31 --> Output Class Initialized
INFO - 2023-09-24 13:19:31 --> Security Class Initialized
DEBUG - 2023-09-24 13:19:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-24 13:19:31 --> Input Class Initialized
INFO - 2023-09-24 13:19:31 --> Language Class Initialized
INFO - 2023-09-24 13:19:31 --> Loader Class Initialized
INFO - 2023-09-24 13:19:31 --> Helper loaded: url_helper
INFO - 2023-09-24 13:19:31 --> Helper loaded: file_helper
INFO - 2023-09-24 13:19:31 --> Helper loaded: html_helper
INFO - 2023-09-24 13:19:31 --> Helper loaded: text_helper
INFO - 2023-09-24 13:19:31 --> Helper loaded: form_helper
INFO - 2023-09-24 13:19:31 --> Helper loaded: lang_helper
INFO - 2023-09-24 13:19:31 --> Helper loaded: security_helper
INFO - 2023-09-24 13:19:31 --> Helper loaded: cookie_helper
INFO - 2023-09-24 13:19:31 --> Database Driver Class Initialized
INFO - 2023-09-24 13:19:31 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-24 13:19:31 --> Parser Class Initialized
INFO - 2023-09-24 13:19:31 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-24 13:19:31 --> Pagination Class Initialized
INFO - 2023-09-24 13:19:31 --> Form Validation Class Initialized
INFO - 2023-09-24 13:19:31 --> Controller Class Initialized
INFO - 2023-09-24 13:19:31 --> Model Class Initialized
DEBUG - 2023-09-24 13:19:31 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-24 13:19:31 --> Model Class Initialized
INFO - 2023-09-24 13:19:31 --> Final output sent to browser
DEBUG - 2023-09-24 13:19:31 --> Total execution time: 0.0165
ERROR - 2023-09-24 13:19:32 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-24 13:19:32 --> Config Class Initialized
INFO - 2023-09-24 13:19:32 --> Hooks Class Initialized
DEBUG - 2023-09-24 13:19:32 --> UTF-8 Support Enabled
INFO - 2023-09-24 13:19:32 --> Utf8 Class Initialized
INFO - 2023-09-24 13:19:32 --> URI Class Initialized
DEBUG - 2023-09-24 13:19:32 --> No URI present. Default controller set.
INFO - 2023-09-24 13:19:32 --> Router Class Initialized
INFO - 2023-09-24 13:19:32 --> Output Class Initialized
INFO - 2023-09-24 13:19:32 --> Security Class Initialized
DEBUG - 2023-09-24 13:19:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-24 13:19:32 --> Input Class Initialized
INFO - 2023-09-24 13:19:32 --> Language Class Initialized
INFO - 2023-09-24 13:19:32 --> Loader Class Initialized
INFO - 2023-09-24 13:19:32 --> Helper loaded: url_helper
INFO - 2023-09-24 13:19:32 --> Helper loaded: file_helper
INFO - 2023-09-24 13:19:32 --> Helper loaded: html_helper
INFO - 2023-09-24 13:19:32 --> Helper loaded: text_helper
INFO - 2023-09-24 13:19:32 --> Helper loaded: form_helper
INFO - 2023-09-24 13:19:32 --> Helper loaded: lang_helper
INFO - 2023-09-24 13:19:32 --> Helper loaded: security_helper
INFO - 2023-09-24 13:19:32 --> Helper loaded: cookie_helper
INFO - 2023-09-24 13:19:32 --> Database Driver Class Initialized
INFO - 2023-09-24 13:19:32 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-24 13:19:32 --> Parser Class Initialized
INFO - 2023-09-24 13:19:32 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-24 13:19:32 --> Pagination Class Initialized
INFO - 2023-09-24 13:19:32 --> Form Validation Class Initialized
INFO - 2023-09-24 13:19:32 --> Controller Class Initialized
INFO - 2023-09-24 13:19:32 --> Model Class Initialized
DEBUG - 2023-09-24 13:19:32 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-24 13:19:32 --> Model Class Initialized
DEBUG - 2023-09-24 13:19:32 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-24 13:19:32 --> Model Class Initialized
INFO - 2023-09-24 13:19:32 --> Model Class Initialized
INFO - 2023-09-24 13:19:32 --> Model Class Initialized
INFO - 2023-09-24 13:19:32 --> Model Class Initialized
DEBUG - 2023-09-24 13:19:32 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-09-24 13:19:32 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-24 13:19:32 --> Model Class Initialized
INFO - 2023-09-24 13:19:32 --> Model Class Initialized
INFO - 2023-09-24 13:19:32 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-09-24 13:19:32 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-09-24 13:19:32 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-09-24 13:19:32 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-09-24 13:19:32 --> Model Class Initialized
INFO - 2023-09-24 13:19:32 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-09-24 13:19:32 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-09-24 13:19:32 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-09-24 13:19:32 --> Final output sent to browser
DEBUG - 2023-09-24 13:19:32 --> Total execution time: 0.2206
ERROR - 2023-09-24 13:19:32 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-24 13:19:32 --> Config Class Initialized
INFO - 2023-09-24 13:19:32 --> Hooks Class Initialized
DEBUG - 2023-09-24 13:19:32 --> UTF-8 Support Enabled
INFO - 2023-09-24 13:19:32 --> Utf8 Class Initialized
INFO - 2023-09-24 13:19:32 --> URI Class Initialized
INFO - 2023-09-24 13:19:32 --> Router Class Initialized
INFO - 2023-09-24 13:19:32 --> Output Class Initialized
INFO - 2023-09-24 13:19:32 --> Security Class Initialized
DEBUG - 2023-09-24 13:19:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-24 13:19:32 --> Input Class Initialized
INFO - 2023-09-24 13:19:32 --> Language Class Initialized
INFO - 2023-09-24 13:19:32 --> Loader Class Initialized
INFO - 2023-09-24 13:19:32 --> Helper loaded: url_helper
INFO - 2023-09-24 13:19:32 --> Helper loaded: file_helper
INFO - 2023-09-24 13:19:32 --> Helper loaded: html_helper
INFO - 2023-09-24 13:19:32 --> Helper loaded: text_helper
INFO - 2023-09-24 13:19:32 --> Helper loaded: form_helper
INFO - 2023-09-24 13:19:32 --> Helper loaded: lang_helper
INFO - 2023-09-24 13:19:32 --> Helper loaded: security_helper
INFO - 2023-09-24 13:19:32 --> Helper loaded: cookie_helper
INFO - 2023-09-24 13:19:32 --> Database Driver Class Initialized
INFO - 2023-09-24 13:19:32 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-24 13:19:32 --> Parser Class Initialized
INFO - 2023-09-24 13:19:32 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-24 13:19:32 --> Pagination Class Initialized
INFO - 2023-09-24 13:19:33 --> Form Validation Class Initialized
INFO - 2023-09-24 13:19:33 --> Controller Class Initialized
DEBUG - 2023-09-24 13:19:33 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-09-24 13:19:33 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-24 13:19:33 --> Model Class Initialized
INFO - 2023-09-24 13:19:33 --> Final output sent to browser
DEBUG - 2023-09-24 13:19:33 --> Total execution time: 0.0135
ERROR - 2023-09-24 13:19:54 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-24 13:19:54 --> Config Class Initialized
INFO - 2023-09-24 13:19:54 --> Hooks Class Initialized
DEBUG - 2023-09-24 13:19:54 --> UTF-8 Support Enabled
INFO - 2023-09-24 13:19:54 --> Utf8 Class Initialized
INFO - 2023-09-24 13:19:54 --> URI Class Initialized
INFO - 2023-09-24 13:19:54 --> Router Class Initialized
INFO - 2023-09-24 13:19:54 --> Output Class Initialized
INFO - 2023-09-24 13:19:54 --> Security Class Initialized
DEBUG - 2023-09-24 13:19:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-24 13:19:54 --> Input Class Initialized
INFO - 2023-09-24 13:19:54 --> Language Class Initialized
INFO - 2023-09-24 13:19:54 --> Loader Class Initialized
INFO - 2023-09-24 13:19:54 --> Helper loaded: url_helper
INFO - 2023-09-24 13:19:54 --> Helper loaded: file_helper
INFO - 2023-09-24 13:19:54 --> Helper loaded: html_helper
INFO - 2023-09-24 13:19:54 --> Helper loaded: text_helper
INFO - 2023-09-24 13:19:54 --> Helper loaded: form_helper
INFO - 2023-09-24 13:19:54 --> Helper loaded: lang_helper
INFO - 2023-09-24 13:19:54 --> Helper loaded: security_helper
INFO - 2023-09-24 13:19:54 --> Helper loaded: cookie_helper
INFO - 2023-09-24 13:19:54 --> Database Driver Class Initialized
INFO - 2023-09-24 13:19:54 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-24 13:19:54 --> Parser Class Initialized
INFO - 2023-09-24 13:19:54 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-24 13:19:54 --> Pagination Class Initialized
INFO - 2023-09-24 13:19:54 --> Form Validation Class Initialized
INFO - 2023-09-24 13:19:54 --> Controller Class Initialized
INFO - 2023-09-24 13:19:54 --> Model Class Initialized
DEBUG - 2023-09-24 13:19:54 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-09-24 13:19:54 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-24 13:19:54 --> Model Class Initialized
DEBUG - 2023-09-24 13:19:54 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-24 13:19:54 --> Model Class Initialized
INFO - 2023-09-24 13:19:54 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice.php
DEBUG - 2023-09-24 13:19:54 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-09-24 13:19:54 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-09-24 13:19:54 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-09-24 13:19:54 --> Model Class Initialized
INFO - 2023-09-24 13:19:54 --> Model Class Initialized
INFO - 2023-09-24 13:19:54 --> Model Class Initialized
INFO - 2023-09-24 13:19:54 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-09-24 13:19:54 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-09-24 13:19:54 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-09-24 13:19:54 --> Final output sent to browser
DEBUG - 2023-09-24 13:19:54 --> Total execution time: 0.0834
ERROR - 2023-09-24 13:19:55 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-24 13:19:55 --> Config Class Initialized
INFO - 2023-09-24 13:19:55 --> Hooks Class Initialized
DEBUG - 2023-09-24 13:19:55 --> UTF-8 Support Enabled
INFO - 2023-09-24 13:19:55 --> Utf8 Class Initialized
INFO - 2023-09-24 13:19:55 --> URI Class Initialized
INFO - 2023-09-24 13:19:55 --> Router Class Initialized
INFO - 2023-09-24 13:19:55 --> Output Class Initialized
INFO - 2023-09-24 13:19:55 --> Security Class Initialized
DEBUG - 2023-09-24 13:19:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-24 13:19:55 --> Input Class Initialized
INFO - 2023-09-24 13:19:55 --> Language Class Initialized
INFO - 2023-09-24 13:19:55 --> Loader Class Initialized
INFO - 2023-09-24 13:19:55 --> Helper loaded: url_helper
INFO - 2023-09-24 13:19:55 --> Helper loaded: file_helper
INFO - 2023-09-24 13:19:55 --> Helper loaded: html_helper
INFO - 2023-09-24 13:19:55 --> Helper loaded: text_helper
INFO - 2023-09-24 13:19:55 --> Helper loaded: form_helper
INFO - 2023-09-24 13:19:55 --> Helper loaded: lang_helper
INFO - 2023-09-24 13:19:55 --> Helper loaded: security_helper
INFO - 2023-09-24 13:19:55 --> Helper loaded: cookie_helper
INFO - 2023-09-24 13:19:55 --> Database Driver Class Initialized
INFO - 2023-09-24 13:19:55 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-24 13:19:55 --> Parser Class Initialized
INFO - 2023-09-24 13:19:55 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-24 13:19:55 --> Pagination Class Initialized
INFO - 2023-09-24 13:19:55 --> Form Validation Class Initialized
INFO - 2023-09-24 13:19:55 --> Controller Class Initialized
INFO - 2023-09-24 13:19:55 --> Model Class Initialized
DEBUG - 2023-09-24 13:19:55 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-09-24 13:19:55 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-24 13:19:55 --> Model Class Initialized
DEBUG - 2023-09-24 13:19:55 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-24 13:19:55 --> Model Class Initialized
INFO - 2023-09-24 13:19:55 --> Final output sent to browser
DEBUG - 2023-09-24 13:19:55 --> Total execution time: 0.0376
ERROR - 2023-09-24 13:20:02 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-24 13:20:02 --> Config Class Initialized
INFO - 2023-09-24 13:20:02 --> Hooks Class Initialized
DEBUG - 2023-09-24 13:20:02 --> UTF-8 Support Enabled
INFO - 2023-09-24 13:20:02 --> Utf8 Class Initialized
INFO - 2023-09-24 13:20:02 --> URI Class Initialized
DEBUG - 2023-09-24 13:20:02 --> No URI present. Default controller set.
INFO - 2023-09-24 13:20:02 --> Router Class Initialized
INFO - 2023-09-24 13:20:02 --> Output Class Initialized
INFO - 2023-09-24 13:20:02 --> Security Class Initialized
DEBUG - 2023-09-24 13:20:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-24 13:20:02 --> Input Class Initialized
INFO - 2023-09-24 13:20:02 --> Language Class Initialized
INFO - 2023-09-24 13:20:02 --> Loader Class Initialized
INFO - 2023-09-24 13:20:02 --> Helper loaded: url_helper
INFO - 2023-09-24 13:20:02 --> Helper loaded: file_helper
INFO - 2023-09-24 13:20:02 --> Helper loaded: html_helper
INFO - 2023-09-24 13:20:02 --> Helper loaded: text_helper
INFO - 2023-09-24 13:20:02 --> Helper loaded: form_helper
INFO - 2023-09-24 13:20:02 --> Helper loaded: lang_helper
INFO - 2023-09-24 13:20:02 --> Helper loaded: security_helper
INFO - 2023-09-24 13:20:02 --> Helper loaded: cookie_helper
INFO - 2023-09-24 13:20:02 --> Database Driver Class Initialized
INFO - 2023-09-24 13:20:02 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-24 13:20:02 --> Parser Class Initialized
INFO - 2023-09-24 13:20:02 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-24 13:20:02 --> Pagination Class Initialized
INFO - 2023-09-24 13:20:02 --> Form Validation Class Initialized
INFO - 2023-09-24 13:20:02 --> Controller Class Initialized
INFO - 2023-09-24 13:20:02 --> Model Class Initialized
DEBUG - 2023-09-24 13:20:02 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-24 13:20:02 --> Model Class Initialized
DEBUG - 2023-09-24 13:20:02 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-24 13:20:02 --> Model Class Initialized
INFO - 2023-09-24 13:20:02 --> Model Class Initialized
INFO - 2023-09-24 13:20:02 --> Model Class Initialized
INFO - 2023-09-24 13:20:02 --> Model Class Initialized
DEBUG - 2023-09-24 13:20:02 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-09-24 13:20:02 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-24 13:20:02 --> Model Class Initialized
INFO - 2023-09-24 13:20:02 --> Model Class Initialized
INFO - 2023-09-24 13:20:02 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-09-24 13:20:02 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-09-24 13:20:02 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-09-24 13:20:02 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-09-24 13:20:02 --> Model Class Initialized
INFO - 2023-09-24 13:20:02 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-09-24 13:20:02 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-09-24 13:20:02 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-09-24 13:20:02 --> Final output sent to browser
DEBUG - 2023-09-24 13:20:02 --> Total execution time: 0.1109
ERROR - 2023-09-24 13:20:16 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-24 13:20:16 --> Config Class Initialized
INFO - 2023-09-24 13:20:16 --> Hooks Class Initialized
DEBUG - 2023-09-24 13:20:16 --> UTF-8 Support Enabled
INFO - 2023-09-24 13:20:16 --> Utf8 Class Initialized
INFO - 2023-09-24 13:20:16 --> URI Class Initialized
DEBUG - 2023-09-24 13:20:16 --> No URI present. Default controller set.
INFO - 2023-09-24 13:20:16 --> Router Class Initialized
INFO - 2023-09-24 13:20:16 --> Output Class Initialized
INFO - 2023-09-24 13:20:16 --> Security Class Initialized
DEBUG - 2023-09-24 13:20:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-24 13:20:16 --> Input Class Initialized
INFO - 2023-09-24 13:20:16 --> Language Class Initialized
INFO - 2023-09-24 13:20:16 --> Loader Class Initialized
INFO - 2023-09-24 13:20:16 --> Helper loaded: url_helper
INFO - 2023-09-24 13:20:16 --> Helper loaded: file_helper
INFO - 2023-09-24 13:20:16 --> Helper loaded: html_helper
INFO - 2023-09-24 13:20:16 --> Helper loaded: text_helper
INFO - 2023-09-24 13:20:16 --> Helper loaded: form_helper
INFO - 2023-09-24 13:20:16 --> Helper loaded: lang_helper
INFO - 2023-09-24 13:20:16 --> Helper loaded: security_helper
INFO - 2023-09-24 13:20:16 --> Helper loaded: cookie_helper
INFO - 2023-09-24 13:20:16 --> Database Driver Class Initialized
INFO - 2023-09-24 13:20:16 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-24 13:20:16 --> Parser Class Initialized
INFO - 2023-09-24 13:20:16 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-24 13:20:16 --> Pagination Class Initialized
INFO - 2023-09-24 13:20:16 --> Form Validation Class Initialized
INFO - 2023-09-24 13:20:16 --> Controller Class Initialized
INFO - 2023-09-24 13:20:16 --> Model Class Initialized
DEBUG - 2023-09-24 13:20:16 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-24 13:20:16 --> Model Class Initialized
DEBUG - 2023-09-24 13:20:16 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-24 13:20:16 --> Model Class Initialized
INFO - 2023-09-24 13:20:16 --> Model Class Initialized
INFO - 2023-09-24 13:20:16 --> Model Class Initialized
INFO - 2023-09-24 13:20:16 --> Model Class Initialized
DEBUG - 2023-09-24 13:20:16 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-09-24 13:20:16 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-24 13:20:16 --> Model Class Initialized
INFO - 2023-09-24 13:20:16 --> Model Class Initialized
INFO - 2023-09-24 13:20:16 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-09-24 13:20:16 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-09-24 13:20:16 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-09-24 13:20:16 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-09-24 13:20:16 --> Model Class Initialized
INFO - 2023-09-24 13:20:16 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-09-24 13:20:16 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-09-24 13:20:16 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-09-24 13:20:16 --> Final output sent to browser
DEBUG - 2023-09-24 13:20:16 --> Total execution time: 0.1175
ERROR - 2023-09-24 13:20:24 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-24 13:20:24 --> Config Class Initialized
INFO - 2023-09-24 13:20:24 --> Hooks Class Initialized
DEBUG - 2023-09-24 13:20:24 --> UTF-8 Support Enabled
INFO - 2023-09-24 13:20:24 --> Utf8 Class Initialized
INFO - 2023-09-24 13:20:24 --> URI Class Initialized
DEBUG - 2023-09-24 13:20:24 --> No URI present. Default controller set.
INFO - 2023-09-24 13:20:24 --> Router Class Initialized
INFO - 2023-09-24 13:20:24 --> Output Class Initialized
INFO - 2023-09-24 13:20:24 --> Security Class Initialized
DEBUG - 2023-09-24 13:20:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-24 13:20:24 --> Input Class Initialized
INFO - 2023-09-24 13:20:24 --> Language Class Initialized
INFO - 2023-09-24 13:20:24 --> Loader Class Initialized
INFO - 2023-09-24 13:20:24 --> Helper loaded: url_helper
INFO - 2023-09-24 13:20:24 --> Helper loaded: file_helper
INFO - 2023-09-24 13:20:24 --> Helper loaded: html_helper
INFO - 2023-09-24 13:20:24 --> Helper loaded: text_helper
INFO - 2023-09-24 13:20:24 --> Helper loaded: form_helper
INFO - 2023-09-24 13:20:24 --> Helper loaded: lang_helper
INFO - 2023-09-24 13:20:24 --> Helper loaded: security_helper
INFO - 2023-09-24 13:20:24 --> Helper loaded: cookie_helper
INFO - 2023-09-24 13:20:24 --> Database Driver Class Initialized
INFO - 2023-09-24 13:20:24 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-24 13:20:24 --> Parser Class Initialized
INFO - 2023-09-24 13:20:24 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-24 13:20:24 --> Pagination Class Initialized
INFO - 2023-09-24 13:20:24 --> Form Validation Class Initialized
INFO - 2023-09-24 13:20:24 --> Controller Class Initialized
INFO - 2023-09-24 13:20:24 --> Model Class Initialized
DEBUG - 2023-09-24 13:20:24 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-24 13:20:24 --> Model Class Initialized
DEBUG - 2023-09-24 13:20:24 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-24 13:20:24 --> Model Class Initialized
INFO - 2023-09-24 13:20:24 --> Model Class Initialized
INFO - 2023-09-24 13:20:24 --> Model Class Initialized
INFO - 2023-09-24 13:20:24 --> Model Class Initialized
DEBUG - 2023-09-24 13:20:24 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-09-24 13:20:24 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-24 13:20:24 --> Model Class Initialized
INFO - 2023-09-24 13:20:24 --> Model Class Initialized
INFO - 2023-09-24 13:20:25 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-09-24 13:20:25 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-09-24 13:20:25 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-09-24 13:20:25 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-09-24 13:20:25 --> Model Class Initialized
INFO - 2023-09-24 13:20:25 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-09-24 13:20:25 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-09-24 13:20:25 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-09-24 13:20:25 --> Final output sent to browser
DEBUG - 2023-09-24 13:20:25 --> Total execution time: 0.1107
ERROR - 2023-09-24 13:20:36 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-24 13:20:36 --> Config Class Initialized
INFO - 2023-09-24 13:20:36 --> Hooks Class Initialized
DEBUG - 2023-09-24 13:20:36 --> UTF-8 Support Enabled
INFO - 2023-09-24 13:20:36 --> Utf8 Class Initialized
INFO - 2023-09-24 13:20:36 --> URI Class Initialized
INFO - 2023-09-24 13:20:36 --> Router Class Initialized
INFO - 2023-09-24 13:20:36 --> Output Class Initialized
INFO - 2023-09-24 13:20:36 --> Security Class Initialized
DEBUG - 2023-09-24 13:20:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-24 13:20:36 --> Input Class Initialized
INFO - 2023-09-24 13:20:36 --> Language Class Initialized
INFO - 2023-09-24 13:20:36 --> Loader Class Initialized
INFO - 2023-09-24 13:20:36 --> Helper loaded: url_helper
INFO - 2023-09-24 13:20:36 --> Helper loaded: file_helper
INFO - 2023-09-24 13:20:36 --> Helper loaded: html_helper
INFO - 2023-09-24 13:20:36 --> Helper loaded: text_helper
INFO - 2023-09-24 13:20:36 --> Helper loaded: form_helper
INFO - 2023-09-24 13:20:36 --> Helper loaded: lang_helper
INFO - 2023-09-24 13:20:36 --> Helper loaded: security_helper
INFO - 2023-09-24 13:20:36 --> Helper loaded: cookie_helper
INFO - 2023-09-24 13:20:36 --> Database Driver Class Initialized
INFO - 2023-09-24 13:20:36 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-24 13:20:36 --> Parser Class Initialized
INFO - 2023-09-24 13:20:36 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-24 13:20:36 --> Pagination Class Initialized
INFO - 2023-09-24 13:20:36 --> Form Validation Class Initialized
INFO - 2023-09-24 13:20:36 --> Controller Class Initialized
INFO - 2023-09-24 13:20:36 --> Model Class Initialized
INFO - 2023-09-24 13:20:36 --> Model Class Initialized
INFO - 2023-09-24 13:20:36 --> Model Class Initialized
INFO - 2023-09-24 13:20:36 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/report/stock_report_batch_wise.php
DEBUG - 2023-09-24 13:20:36 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-09-24 13:20:36 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-09-24 13:20:36 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-09-24 13:20:36 --> Model Class Initialized
INFO - 2023-09-24 13:20:36 --> Model Class Initialized
INFO - 2023-09-24 13:20:36 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-09-24 13:20:36 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-09-24 13:20:36 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-09-24 13:20:36 --> Final output sent to browser
DEBUG - 2023-09-24 13:20:36 --> Total execution time: 0.1533
ERROR - 2023-09-24 13:20:37 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-24 13:20:37 --> Config Class Initialized
INFO - 2023-09-24 13:20:37 --> Hooks Class Initialized
DEBUG - 2023-09-24 13:20:37 --> UTF-8 Support Enabled
INFO - 2023-09-24 13:20:37 --> Utf8 Class Initialized
INFO - 2023-09-24 13:20:37 --> URI Class Initialized
INFO - 2023-09-24 13:20:37 --> Router Class Initialized
INFO - 2023-09-24 13:20:37 --> Output Class Initialized
INFO - 2023-09-24 13:20:37 --> Security Class Initialized
DEBUG - 2023-09-24 13:20:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-24 13:20:37 --> Input Class Initialized
INFO - 2023-09-24 13:20:37 --> Language Class Initialized
INFO - 2023-09-24 13:20:37 --> Loader Class Initialized
INFO - 2023-09-24 13:20:37 --> Helper loaded: url_helper
INFO - 2023-09-24 13:20:37 --> Helper loaded: file_helper
INFO - 2023-09-24 13:20:37 --> Helper loaded: html_helper
INFO - 2023-09-24 13:20:37 --> Helper loaded: text_helper
INFO - 2023-09-24 13:20:37 --> Helper loaded: form_helper
INFO - 2023-09-24 13:20:37 --> Helper loaded: lang_helper
INFO - 2023-09-24 13:20:37 --> Helper loaded: security_helper
INFO - 2023-09-24 13:20:37 --> Helper loaded: cookie_helper
INFO - 2023-09-24 13:20:37 --> Database Driver Class Initialized
INFO - 2023-09-24 13:20:37 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-24 13:20:37 --> Parser Class Initialized
INFO - 2023-09-24 13:20:37 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-24 13:20:37 --> Pagination Class Initialized
INFO - 2023-09-24 13:20:37 --> Form Validation Class Initialized
INFO - 2023-09-24 13:20:37 --> Controller Class Initialized
INFO - 2023-09-24 13:20:37 --> Model Class Initialized
INFO - 2023-09-24 13:20:37 --> Model Class Initialized
INFO - 2023-09-24 13:20:37 --> Final output sent to browser
DEBUG - 2023-09-24 13:20:37 --> Total execution time: 0.0294
ERROR - 2023-09-24 13:20:40 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-24 13:20:40 --> Config Class Initialized
INFO - 2023-09-24 13:20:40 --> Hooks Class Initialized
DEBUG - 2023-09-24 13:20:40 --> UTF-8 Support Enabled
INFO - 2023-09-24 13:20:40 --> Utf8 Class Initialized
INFO - 2023-09-24 13:20:40 --> URI Class Initialized
INFO - 2023-09-24 13:20:40 --> Router Class Initialized
INFO - 2023-09-24 13:20:40 --> Output Class Initialized
INFO - 2023-09-24 13:20:40 --> Security Class Initialized
DEBUG - 2023-09-24 13:20:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-24 13:20:40 --> Input Class Initialized
INFO - 2023-09-24 13:20:40 --> Language Class Initialized
INFO - 2023-09-24 13:20:40 --> Loader Class Initialized
INFO - 2023-09-24 13:20:40 --> Helper loaded: url_helper
INFO - 2023-09-24 13:20:40 --> Helper loaded: file_helper
INFO - 2023-09-24 13:20:40 --> Helper loaded: html_helper
INFO - 2023-09-24 13:20:40 --> Helper loaded: text_helper
INFO - 2023-09-24 13:20:40 --> Helper loaded: form_helper
INFO - 2023-09-24 13:20:40 --> Helper loaded: lang_helper
INFO - 2023-09-24 13:20:40 --> Helper loaded: security_helper
INFO - 2023-09-24 13:20:40 --> Helper loaded: cookie_helper
INFO - 2023-09-24 13:20:40 --> Database Driver Class Initialized
INFO - 2023-09-24 13:20:40 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-24 13:20:40 --> Parser Class Initialized
INFO - 2023-09-24 13:20:40 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-24 13:20:40 --> Pagination Class Initialized
INFO - 2023-09-24 13:20:40 --> Form Validation Class Initialized
INFO - 2023-09-24 13:20:40 --> Controller Class Initialized
INFO - 2023-09-24 13:20:40 --> Model Class Initialized
INFO - 2023-09-24 13:20:40 --> Model Class Initialized
INFO - 2023-09-24 13:20:40 --> Final output sent to browser
DEBUG - 2023-09-24 13:20:40 --> Total execution time: 0.0506
ERROR - 2023-09-24 13:21:21 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-24 13:21:21 --> Config Class Initialized
INFO - 2023-09-24 13:21:21 --> Hooks Class Initialized
DEBUG - 2023-09-24 13:21:21 --> UTF-8 Support Enabled
INFO - 2023-09-24 13:21:21 --> Utf8 Class Initialized
INFO - 2023-09-24 13:21:21 --> URI Class Initialized
DEBUG - 2023-09-24 13:21:21 --> No URI present. Default controller set.
INFO - 2023-09-24 13:21:21 --> Router Class Initialized
INFO - 2023-09-24 13:21:21 --> Output Class Initialized
INFO - 2023-09-24 13:21:21 --> Security Class Initialized
DEBUG - 2023-09-24 13:21:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-24 13:21:21 --> Input Class Initialized
INFO - 2023-09-24 13:21:21 --> Language Class Initialized
INFO - 2023-09-24 13:21:21 --> Loader Class Initialized
INFO - 2023-09-24 13:21:21 --> Helper loaded: url_helper
INFO - 2023-09-24 13:21:21 --> Helper loaded: file_helper
INFO - 2023-09-24 13:21:21 --> Helper loaded: html_helper
INFO - 2023-09-24 13:21:21 --> Helper loaded: text_helper
INFO - 2023-09-24 13:21:21 --> Helper loaded: form_helper
INFO - 2023-09-24 13:21:21 --> Helper loaded: lang_helper
INFO - 2023-09-24 13:21:21 --> Helper loaded: security_helper
INFO - 2023-09-24 13:21:21 --> Helper loaded: cookie_helper
INFO - 2023-09-24 13:21:21 --> Database Driver Class Initialized
INFO - 2023-09-24 13:21:21 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-24 13:21:21 --> Parser Class Initialized
INFO - 2023-09-24 13:21:21 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-24 13:21:21 --> Pagination Class Initialized
INFO - 2023-09-24 13:21:21 --> Form Validation Class Initialized
INFO - 2023-09-24 13:21:21 --> Controller Class Initialized
INFO - 2023-09-24 13:21:21 --> Model Class Initialized
DEBUG - 2023-09-24 13:21:21 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-24 13:21:21 --> Model Class Initialized
DEBUG - 2023-09-24 13:21:21 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-24 13:21:21 --> Model Class Initialized
INFO - 2023-09-24 13:21:21 --> Model Class Initialized
INFO - 2023-09-24 13:21:21 --> Model Class Initialized
INFO - 2023-09-24 13:21:21 --> Model Class Initialized
DEBUG - 2023-09-24 13:21:21 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-09-24 13:21:21 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-24 13:21:21 --> Model Class Initialized
INFO - 2023-09-24 13:21:21 --> Model Class Initialized
INFO - 2023-09-24 13:21:21 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-09-24 13:21:21 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-09-24 13:21:21 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-09-24 13:21:21 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-09-24 13:21:21 --> Model Class Initialized
INFO - 2023-09-24 13:21:21 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-09-24 13:21:21 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-09-24 13:21:21 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-09-24 13:21:21 --> Final output sent to browser
DEBUG - 2023-09-24 13:21:21 --> Total execution time: 0.1073
ERROR - 2023-09-24 13:40:05 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-24 13:40:05 --> Config Class Initialized
INFO - 2023-09-24 13:40:05 --> Hooks Class Initialized
DEBUG - 2023-09-24 13:40:05 --> UTF-8 Support Enabled
INFO - 2023-09-24 13:40:05 --> Utf8 Class Initialized
INFO - 2023-09-24 13:40:05 --> URI Class Initialized
DEBUG - 2023-09-24 13:40:05 --> No URI present. Default controller set.
INFO - 2023-09-24 13:40:05 --> Router Class Initialized
INFO - 2023-09-24 13:40:05 --> Output Class Initialized
INFO - 2023-09-24 13:40:05 --> Security Class Initialized
DEBUG - 2023-09-24 13:40:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-24 13:40:05 --> Input Class Initialized
INFO - 2023-09-24 13:40:05 --> Language Class Initialized
INFO - 2023-09-24 13:40:05 --> Loader Class Initialized
INFO - 2023-09-24 13:40:05 --> Helper loaded: url_helper
INFO - 2023-09-24 13:40:05 --> Helper loaded: file_helper
INFO - 2023-09-24 13:40:05 --> Helper loaded: html_helper
INFO - 2023-09-24 13:40:05 --> Helper loaded: text_helper
INFO - 2023-09-24 13:40:05 --> Helper loaded: form_helper
INFO - 2023-09-24 13:40:05 --> Helper loaded: lang_helper
INFO - 2023-09-24 13:40:05 --> Helper loaded: security_helper
INFO - 2023-09-24 13:40:05 --> Helper loaded: cookie_helper
INFO - 2023-09-24 13:40:05 --> Database Driver Class Initialized
INFO - 2023-09-24 13:40:05 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-24 13:40:05 --> Parser Class Initialized
INFO - 2023-09-24 13:40:05 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-24 13:40:05 --> Pagination Class Initialized
INFO - 2023-09-24 13:40:05 --> Form Validation Class Initialized
INFO - 2023-09-24 13:40:05 --> Controller Class Initialized
INFO - 2023-09-24 13:40:05 --> Model Class Initialized
DEBUG - 2023-09-24 13:40:05 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-24 13:40:05 --> Model Class Initialized
DEBUG - 2023-09-24 13:40:05 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-24 13:40:05 --> Model Class Initialized
INFO - 2023-09-24 13:40:05 --> Model Class Initialized
INFO - 2023-09-24 13:40:05 --> Model Class Initialized
INFO - 2023-09-24 13:40:05 --> Model Class Initialized
DEBUG - 2023-09-24 13:40:05 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-09-24 13:40:05 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-24 13:40:05 --> Model Class Initialized
INFO - 2023-09-24 13:40:05 --> Model Class Initialized
INFO - 2023-09-24 13:40:05 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-09-24 13:40:05 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-09-24 13:40:05 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-09-24 13:40:05 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-09-24 13:40:05 --> Model Class Initialized
INFO - 2023-09-24 13:40:05 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-09-24 13:40:05 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-09-24 13:40:05 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-09-24 13:40:05 --> Final output sent to browser
DEBUG - 2023-09-24 13:40:05 --> Total execution time: 0.1351
ERROR - 2023-09-24 13:50:11 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-24 13:50:11 --> Config Class Initialized
INFO - 2023-09-24 13:50:11 --> Hooks Class Initialized
DEBUG - 2023-09-24 13:50:11 --> UTF-8 Support Enabled
INFO - 2023-09-24 13:50:11 --> Utf8 Class Initialized
INFO - 2023-09-24 13:50:11 --> URI Class Initialized
DEBUG - 2023-09-24 13:50:11 --> No URI present. Default controller set.
INFO - 2023-09-24 13:50:11 --> Router Class Initialized
INFO - 2023-09-24 13:50:11 --> Output Class Initialized
INFO - 2023-09-24 13:50:11 --> Security Class Initialized
DEBUG - 2023-09-24 13:50:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-24 13:50:11 --> Input Class Initialized
INFO - 2023-09-24 13:50:11 --> Language Class Initialized
INFO - 2023-09-24 13:50:11 --> Loader Class Initialized
INFO - 2023-09-24 13:50:11 --> Helper loaded: url_helper
INFO - 2023-09-24 13:50:11 --> Helper loaded: file_helper
INFO - 2023-09-24 13:50:11 --> Helper loaded: html_helper
INFO - 2023-09-24 13:50:11 --> Helper loaded: text_helper
INFO - 2023-09-24 13:50:11 --> Helper loaded: form_helper
INFO - 2023-09-24 13:50:11 --> Helper loaded: lang_helper
INFO - 2023-09-24 13:50:11 --> Helper loaded: security_helper
INFO - 2023-09-24 13:50:11 --> Helper loaded: cookie_helper
INFO - 2023-09-24 13:50:11 --> Database Driver Class Initialized
INFO - 2023-09-24 13:50:11 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-24 13:50:11 --> Parser Class Initialized
INFO - 2023-09-24 13:50:11 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-24 13:50:11 --> Pagination Class Initialized
INFO - 2023-09-24 13:50:11 --> Form Validation Class Initialized
INFO - 2023-09-24 13:50:11 --> Controller Class Initialized
INFO - 2023-09-24 13:50:11 --> Model Class Initialized
DEBUG - 2023-09-24 13:50:11 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-24 13:50:11 --> Model Class Initialized
DEBUG - 2023-09-24 13:50:11 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-24 13:50:11 --> Model Class Initialized
INFO - 2023-09-24 13:50:11 --> Model Class Initialized
INFO - 2023-09-24 13:50:11 --> Model Class Initialized
INFO - 2023-09-24 13:50:11 --> Model Class Initialized
DEBUG - 2023-09-24 13:50:11 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-09-24 13:50:11 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-24 13:50:11 --> Model Class Initialized
INFO - 2023-09-24 13:50:11 --> Model Class Initialized
INFO - 2023-09-24 13:50:11 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-09-24 13:50:11 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-09-24 13:50:11 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-09-24 13:50:11 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-09-24 13:50:11 --> Model Class Initialized
INFO - 2023-09-24 13:50:11 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-09-24 13:50:11 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-09-24 13:50:11 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-09-24 13:50:11 --> Final output sent to browser
DEBUG - 2023-09-24 13:50:11 --> Total execution time: 0.1051
ERROR - 2023-09-24 13:50:20 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-24 13:50:20 --> Config Class Initialized
INFO - 2023-09-24 13:50:20 --> Hooks Class Initialized
DEBUG - 2023-09-24 13:50:20 --> UTF-8 Support Enabled
INFO - 2023-09-24 13:50:20 --> Utf8 Class Initialized
INFO - 2023-09-24 13:50:20 --> URI Class Initialized
DEBUG - 2023-09-24 13:50:20 --> No URI present. Default controller set.
INFO - 2023-09-24 13:50:20 --> Router Class Initialized
INFO - 2023-09-24 13:50:20 --> Output Class Initialized
INFO - 2023-09-24 13:50:20 --> Security Class Initialized
DEBUG - 2023-09-24 13:50:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-24 13:50:20 --> Input Class Initialized
INFO - 2023-09-24 13:50:20 --> Language Class Initialized
INFO - 2023-09-24 13:50:20 --> Loader Class Initialized
INFO - 2023-09-24 13:50:20 --> Helper loaded: url_helper
INFO - 2023-09-24 13:50:20 --> Helper loaded: file_helper
INFO - 2023-09-24 13:50:20 --> Helper loaded: html_helper
INFO - 2023-09-24 13:50:20 --> Helper loaded: text_helper
INFO - 2023-09-24 13:50:20 --> Helper loaded: form_helper
INFO - 2023-09-24 13:50:20 --> Helper loaded: lang_helper
INFO - 2023-09-24 13:50:20 --> Helper loaded: security_helper
INFO - 2023-09-24 13:50:20 --> Helper loaded: cookie_helper
INFO - 2023-09-24 13:50:20 --> Database Driver Class Initialized
INFO - 2023-09-24 13:50:20 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-24 13:50:20 --> Parser Class Initialized
INFO - 2023-09-24 13:50:20 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-24 13:50:20 --> Pagination Class Initialized
INFO - 2023-09-24 13:50:20 --> Form Validation Class Initialized
INFO - 2023-09-24 13:50:20 --> Controller Class Initialized
INFO - 2023-09-24 13:50:20 --> Model Class Initialized
DEBUG - 2023-09-24 13:50:20 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-24 13:50:20 --> Model Class Initialized
DEBUG - 2023-09-24 13:50:20 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-24 13:50:20 --> Model Class Initialized
INFO - 2023-09-24 13:50:20 --> Model Class Initialized
INFO - 2023-09-24 13:50:20 --> Model Class Initialized
INFO - 2023-09-24 13:50:20 --> Model Class Initialized
DEBUG - 2023-09-24 13:50:20 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-09-24 13:50:20 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-24 13:50:20 --> Model Class Initialized
INFO - 2023-09-24 13:50:20 --> Model Class Initialized
INFO - 2023-09-24 13:50:20 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-09-24 13:50:20 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-09-24 13:50:20 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-09-24 13:50:20 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-09-24 13:50:20 --> Model Class Initialized
INFO - 2023-09-24 13:50:20 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-09-24 13:50:20 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-09-24 13:50:20 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-09-24 13:50:20 --> Final output sent to browser
DEBUG - 2023-09-24 13:50:20 --> Total execution time: 0.2250
ERROR - 2023-09-24 13:50:30 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-24 13:50:30 --> Config Class Initialized
INFO - 2023-09-24 13:50:30 --> Hooks Class Initialized
DEBUG - 2023-09-24 13:50:30 --> UTF-8 Support Enabled
INFO - 2023-09-24 13:50:30 --> Utf8 Class Initialized
INFO - 2023-09-24 13:50:30 --> URI Class Initialized
DEBUG - 2023-09-24 13:50:30 --> No URI present. Default controller set.
INFO - 2023-09-24 13:50:30 --> Router Class Initialized
INFO - 2023-09-24 13:50:30 --> Output Class Initialized
INFO - 2023-09-24 13:50:30 --> Security Class Initialized
DEBUG - 2023-09-24 13:50:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-24 13:50:30 --> Input Class Initialized
INFO - 2023-09-24 13:50:30 --> Language Class Initialized
INFO - 2023-09-24 13:50:30 --> Loader Class Initialized
INFO - 2023-09-24 13:50:30 --> Helper loaded: url_helper
INFO - 2023-09-24 13:50:30 --> Helper loaded: file_helper
INFO - 2023-09-24 13:50:30 --> Helper loaded: html_helper
INFO - 2023-09-24 13:50:30 --> Helper loaded: text_helper
INFO - 2023-09-24 13:50:30 --> Helper loaded: form_helper
INFO - 2023-09-24 13:50:30 --> Helper loaded: lang_helper
INFO - 2023-09-24 13:50:30 --> Helper loaded: security_helper
INFO - 2023-09-24 13:50:30 --> Helper loaded: cookie_helper
INFO - 2023-09-24 13:50:30 --> Database Driver Class Initialized
INFO - 2023-09-24 13:50:30 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-24 13:50:30 --> Parser Class Initialized
INFO - 2023-09-24 13:50:30 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-24 13:50:30 --> Pagination Class Initialized
INFO - 2023-09-24 13:50:30 --> Form Validation Class Initialized
INFO - 2023-09-24 13:50:30 --> Controller Class Initialized
INFO - 2023-09-24 13:50:30 --> Model Class Initialized
DEBUG - 2023-09-24 13:50:30 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-24 13:50:30 --> Model Class Initialized
DEBUG - 2023-09-24 13:50:30 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-24 13:50:30 --> Model Class Initialized
INFO - 2023-09-24 13:50:30 --> Model Class Initialized
INFO - 2023-09-24 13:50:30 --> Model Class Initialized
INFO - 2023-09-24 13:50:30 --> Model Class Initialized
DEBUG - 2023-09-24 13:50:30 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-09-24 13:50:30 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-24 13:50:30 --> Model Class Initialized
INFO - 2023-09-24 13:50:30 --> Model Class Initialized
INFO - 2023-09-24 13:50:30 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-09-24 13:50:30 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-09-24 13:50:30 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-09-24 13:50:30 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-09-24 13:50:30 --> Model Class Initialized
INFO - 2023-09-24 13:50:30 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-09-24 13:50:30 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-09-24 13:50:30 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-09-24 13:50:30 --> Final output sent to browser
DEBUG - 2023-09-24 13:50:30 --> Total execution time: 0.2161
ERROR - 2023-09-24 13:52:40 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-24 13:52:40 --> Config Class Initialized
INFO - 2023-09-24 13:52:40 --> Hooks Class Initialized
DEBUG - 2023-09-24 13:52:40 --> UTF-8 Support Enabled
INFO - 2023-09-24 13:52:40 --> Utf8 Class Initialized
INFO - 2023-09-24 13:52:40 --> URI Class Initialized
INFO - 2023-09-24 13:52:40 --> Router Class Initialized
INFO - 2023-09-24 13:52:40 --> Output Class Initialized
INFO - 2023-09-24 13:52:40 --> Security Class Initialized
DEBUG - 2023-09-24 13:52:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-24 13:52:40 --> Input Class Initialized
INFO - 2023-09-24 13:52:40 --> Language Class Initialized
INFO - 2023-09-24 13:52:40 --> Loader Class Initialized
INFO - 2023-09-24 13:52:40 --> Helper loaded: url_helper
INFO - 2023-09-24 13:52:40 --> Helper loaded: file_helper
INFO - 2023-09-24 13:52:40 --> Helper loaded: html_helper
INFO - 2023-09-24 13:52:40 --> Helper loaded: text_helper
INFO - 2023-09-24 13:52:40 --> Helper loaded: form_helper
INFO - 2023-09-24 13:52:40 --> Helper loaded: lang_helper
INFO - 2023-09-24 13:52:40 --> Helper loaded: security_helper
INFO - 2023-09-24 13:52:40 --> Helper loaded: cookie_helper
INFO - 2023-09-24 13:52:40 --> Database Driver Class Initialized
INFO - 2023-09-24 13:52:40 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-24 13:52:40 --> Parser Class Initialized
INFO - 2023-09-24 13:52:40 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-24 13:52:40 --> Pagination Class Initialized
INFO - 2023-09-24 13:52:40 --> Form Validation Class Initialized
INFO - 2023-09-24 13:52:40 --> Controller Class Initialized
DEBUG - 2023-09-24 13:52:40 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-09-24 13:52:40 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-24 13:52:40 --> Model Class Initialized
DEBUG - 2023-09-24 13:52:40 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-24 13:52:40 --> Model Class Initialized
DEBUG - 2023-09-24 13:52:40 --> Lcustomer class already loaded. Second attempt ignored.
INFO - 2023-09-24 13:52:40 --> Model Class Initialized
INFO - 2023-09-24 13:52:40 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/customer/customer.php
DEBUG - 2023-09-24 13:52:40 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-09-24 13:52:40 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-09-24 13:52:40 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-09-24 13:52:40 --> Model Class Initialized
INFO - 2023-09-24 13:52:40 --> Model Class Initialized
INFO - 2023-09-24 13:52:40 --> Model Class Initialized
INFO - 2023-09-24 13:52:40 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-09-24 13:52:40 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-09-24 13:52:40 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-09-24 13:52:40 --> Final output sent to browser
DEBUG - 2023-09-24 13:52:40 --> Total execution time: 0.1463
ERROR - 2023-09-24 13:52:41 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-24 13:52:41 --> Config Class Initialized
INFO - 2023-09-24 13:52:41 --> Hooks Class Initialized
DEBUG - 2023-09-24 13:52:41 --> UTF-8 Support Enabled
INFO - 2023-09-24 13:52:41 --> Utf8 Class Initialized
INFO - 2023-09-24 13:52:41 --> URI Class Initialized
INFO - 2023-09-24 13:52:41 --> Router Class Initialized
INFO - 2023-09-24 13:52:41 --> Output Class Initialized
INFO - 2023-09-24 13:52:41 --> Security Class Initialized
DEBUG - 2023-09-24 13:52:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-24 13:52:41 --> Input Class Initialized
INFO - 2023-09-24 13:52:41 --> Language Class Initialized
INFO - 2023-09-24 13:52:41 --> Loader Class Initialized
INFO - 2023-09-24 13:52:41 --> Helper loaded: url_helper
INFO - 2023-09-24 13:52:41 --> Helper loaded: file_helper
INFO - 2023-09-24 13:52:41 --> Helper loaded: html_helper
INFO - 2023-09-24 13:52:41 --> Helper loaded: text_helper
INFO - 2023-09-24 13:52:41 --> Helper loaded: form_helper
INFO - 2023-09-24 13:52:41 --> Helper loaded: lang_helper
INFO - 2023-09-24 13:52:41 --> Helper loaded: security_helper
INFO - 2023-09-24 13:52:41 --> Helper loaded: cookie_helper
INFO - 2023-09-24 13:52:41 --> Database Driver Class Initialized
INFO - 2023-09-24 13:52:41 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-24 13:52:41 --> Parser Class Initialized
INFO - 2023-09-24 13:52:41 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-24 13:52:41 --> Pagination Class Initialized
INFO - 2023-09-24 13:52:41 --> Form Validation Class Initialized
INFO - 2023-09-24 13:52:41 --> Controller Class Initialized
DEBUG - 2023-09-24 13:52:41 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-09-24 13:52:41 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-24 13:52:41 --> Model Class Initialized
DEBUG - 2023-09-24 13:52:41 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-24 13:52:41 --> Model Class Initialized
INFO - 2023-09-24 13:52:41 --> Final output sent to browser
DEBUG - 2023-09-24 13:52:41 --> Total execution time: 0.0316
ERROR - 2023-09-24 13:52:59 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-24 13:52:59 --> Config Class Initialized
INFO - 2023-09-24 13:52:59 --> Hooks Class Initialized
DEBUG - 2023-09-24 13:52:59 --> UTF-8 Support Enabled
INFO - 2023-09-24 13:52:59 --> Utf8 Class Initialized
INFO - 2023-09-24 13:52:59 --> URI Class Initialized
INFO - 2023-09-24 13:52:59 --> Router Class Initialized
INFO - 2023-09-24 13:52:59 --> Output Class Initialized
INFO - 2023-09-24 13:52:59 --> Security Class Initialized
DEBUG - 2023-09-24 13:52:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-24 13:52:59 --> Input Class Initialized
INFO - 2023-09-24 13:52:59 --> Language Class Initialized
INFO - 2023-09-24 13:52:59 --> Loader Class Initialized
INFO - 2023-09-24 13:52:59 --> Helper loaded: url_helper
INFO - 2023-09-24 13:52:59 --> Helper loaded: file_helper
INFO - 2023-09-24 13:52:59 --> Helper loaded: html_helper
INFO - 2023-09-24 13:52:59 --> Helper loaded: text_helper
INFO - 2023-09-24 13:52:59 --> Helper loaded: form_helper
INFO - 2023-09-24 13:52:59 --> Helper loaded: lang_helper
INFO - 2023-09-24 13:52:59 --> Helper loaded: security_helper
INFO - 2023-09-24 13:52:59 --> Helper loaded: cookie_helper
INFO - 2023-09-24 13:52:59 --> Database Driver Class Initialized
INFO - 2023-09-24 13:52:59 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-24 13:52:59 --> Parser Class Initialized
INFO - 2023-09-24 13:52:59 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-24 13:52:59 --> Pagination Class Initialized
INFO - 2023-09-24 13:52:59 --> Form Validation Class Initialized
INFO - 2023-09-24 13:52:59 --> Controller Class Initialized
DEBUG - 2023-09-24 13:52:59 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-09-24 13:52:59 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-24 13:52:59 --> Model Class Initialized
DEBUG - 2023-09-24 13:52:59 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-24 13:52:59 --> Model Class Initialized
INFO - 2023-09-24 13:52:59 --> Final output sent to browser
DEBUG - 2023-09-24 13:52:59 --> Total execution time: 0.1871
ERROR - 2023-09-24 13:53:15 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-24 13:53:15 --> Config Class Initialized
INFO - 2023-09-24 13:53:15 --> Hooks Class Initialized
DEBUG - 2023-09-24 13:53:15 --> UTF-8 Support Enabled
INFO - 2023-09-24 13:53:15 --> Utf8 Class Initialized
INFO - 2023-09-24 13:53:15 --> URI Class Initialized
DEBUG - 2023-09-24 13:53:15 --> No URI present. Default controller set.
INFO - 2023-09-24 13:53:15 --> Router Class Initialized
INFO - 2023-09-24 13:53:15 --> Output Class Initialized
INFO - 2023-09-24 13:53:15 --> Security Class Initialized
DEBUG - 2023-09-24 13:53:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-24 13:53:15 --> Input Class Initialized
INFO - 2023-09-24 13:53:15 --> Language Class Initialized
INFO - 2023-09-24 13:53:15 --> Loader Class Initialized
INFO - 2023-09-24 13:53:15 --> Helper loaded: url_helper
INFO - 2023-09-24 13:53:15 --> Helper loaded: file_helper
INFO - 2023-09-24 13:53:15 --> Helper loaded: html_helper
INFO - 2023-09-24 13:53:15 --> Helper loaded: text_helper
INFO - 2023-09-24 13:53:15 --> Helper loaded: form_helper
INFO - 2023-09-24 13:53:15 --> Helper loaded: lang_helper
INFO - 2023-09-24 13:53:15 --> Helper loaded: security_helper
INFO - 2023-09-24 13:53:15 --> Helper loaded: cookie_helper
INFO - 2023-09-24 13:53:15 --> Database Driver Class Initialized
INFO - 2023-09-24 13:53:15 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-24 13:53:15 --> Parser Class Initialized
INFO - 2023-09-24 13:53:15 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-24 13:53:15 --> Pagination Class Initialized
INFO - 2023-09-24 13:53:15 --> Form Validation Class Initialized
INFO - 2023-09-24 13:53:15 --> Controller Class Initialized
INFO - 2023-09-24 13:53:15 --> Model Class Initialized
DEBUG - 2023-09-24 13:53:15 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-24 13:53:15 --> Model Class Initialized
DEBUG - 2023-09-24 13:53:15 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-24 13:53:15 --> Model Class Initialized
INFO - 2023-09-24 13:53:15 --> Model Class Initialized
INFO - 2023-09-24 13:53:15 --> Model Class Initialized
INFO - 2023-09-24 13:53:15 --> Model Class Initialized
DEBUG - 2023-09-24 13:53:15 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-09-24 13:53:15 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-24 13:53:15 --> Model Class Initialized
INFO - 2023-09-24 13:53:15 --> Model Class Initialized
INFO - 2023-09-24 13:53:15 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-09-24 13:53:15 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-09-24 13:53:15 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-09-24 13:53:15 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-09-24 13:53:15 --> Model Class Initialized
INFO - 2023-09-24 13:53:16 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-09-24 13:53:16 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-09-24 13:53:16 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-09-24 13:53:16 --> Final output sent to browser
DEBUG - 2023-09-24 13:53:16 --> Total execution time: 0.2167
ERROR - 2023-09-24 16:53:08 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-24 16:53:08 --> Config Class Initialized
INFO - 2023-09-24 16:53:08 --> Hooks Class Initialized
DEBUG - 2023-09-24 16:53:08 --> UTF-8 Support Enabled
INFO - 2023-09-24 16:53:08 --> Utf8 Class Initialized
INFO - 2023-09-24 16:53:08 --> URI Class Initialized
DEBUG - 2023-09-24 16:53:08 --> No URI present. Default controller set.
INFO - 2023-09-24 16:53:08 --> Router Class Initialized
INFO - 2023-09-24 16:53:08 --> Output Class Initialized
INFO - 2023-09-24 16:53:08 --> Security Class Initialized
DEBUG - 2023-09-24 16:53:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-24 16:53:08 --> Input Class Initialized
INFO - 2023-09-24 16:53:08 --> Language Class Initialized
INFO - 2023-09-24 16:53:08 --> Loader Class Initialized
INFO - 2023-09-24 16:53:08 --> Helper loaded: url_helper
INFO - 2023-09-24 16:53:08 --> Helper loaded: file_helper
INFO - 2023-09-24 16:53:08 --> Helper loaded: html_helper
INFO - 2023-09-24 16:53:08 --> Helper loaded: text_helper
INFO - 2023-09-24 16:53:08 --> Helper loaded: form_helper
INFO - 2023-09-24 16:53:08 --> Helper loaded: lang_helper
INFO - 2023-09-24 16:53:08 --> Helper loaded: security_helper
INFO - 2023-09-24 16:53:08 --> Helper loaded: cookie_helper
INFO - 2023-09-24 16:53:08 --> Database Driver Class Initialized
INFO - 2023-09-24 16:53:08 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-24 16:53:08 --> Parser Class Initialized
INFO - 2023-09-24 16:53:08 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-24 16:53:08 --> Pagination Class Initialized
INFO - 2023-09-24 16:53:08 --> Form Validation Class Initialized
INFO - 2023-09-24 16:53:08 --> Controller Class Initialized
INFO - 2023-09-24 16:53:08 --> Model Class Initialized
DEBUG - 2023-09-24 16:53:08 --> Session class already loaded. Second attempt ignored.
ERROR - 2023-09-24 16:53:09 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-24 16:53:09 --> Config Class Initialized
INFO - 2023-09-24 16:53:09 --> Hooks Class Initialized
DEBUG - 2023-09-24 16:53:09 --> UTF-8 Support Enabled
INFO - 2023-09-24 16:53:09 --> Utf8 Class Initialized
INFO - 2023-09-24 16:53:09 --> URI Class Initialized
INFO - 2023-09-24 16:53:09 --> Router Class Initialized
INFO - 2023-09-24 16:53:09 --> Output Class Initialized
INFO - 2023-09-24 16:53:09 --> Security Class Initialized
DEBUG - 2023-09-24 16:53:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-24 16:53:09 --> Input Class Initialized
INFO - 2023-09-24 16:53:09 --> Language Class Initialized
INFO - 2023-09-24 16:53:09 --> Loader Class Initialized
INFO - 2023-09-24 16:53:09 --> Helper loaded: url_helper
INFO - 2023-09-24 16:53:09 --> Helper loaded: file_helper
INFO - 2023-09-24 16:53:09 --> Helper loaded: html_helper
INFO - 2023-09-24 16:53:09 --> Helper loaded: text_helper
INFO - 2023-09-24 16:53:09 --> Helper loaded: form_helper
INFO - 2023-09-24 16:53:09 --> Helper loaded: lang_helper
INFO - 2023-09-24 16:53:09 --> Helper loaded: security_helper
INFO - 2023-09-24 16:53:09 --> Helper loaded: cookie_helper
INFO - 2023-09-24 16:53:09 --> Database Driver Class Initialized
INFO - 2023-09-24 16:53:09 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-24 16:53:09 --> Parser Class Initialized
INFO - 2023-09-24 16:53:09 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-24 16:53:09 --> Pagination Class Initialized
INFO - 2023-09-24 16:53:09 --> Form Validation Class Initialized
INFO - 2023-09-24 16:53:09 --> Controller Class Initialized
INFO - 2023-09-24 16:53:09 --> Model Class Initialized
DEBUG - 2023-09-24 16:53:09 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-24 16:53:09 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2023-09-24 16:53:09 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-09-24 16:53:09 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-09-24 16:53:09 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-09-24 16:53:09 --> Model Class Initialized
INFO - 2023-09-24 16:53:09 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-09-24 16:53:09 --> Final output sent to browser
DEBUG - 2023-09-24 16:53:09 --> Total execution time: 0.0338
ERROR - 2023-09-24 17:04:23 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-24 17:04:23 --> Config Class Initialized
INFO - 2023-09-24 17:04:23 --> Hooks Class Initialized
DEBUG - 2023-09-24 17:04:23 --> UTF-8 Support Enabled
INFO - 2023-09-24 17:04:23 --> Utf8 Class Initialized
INFO - 2023-09-24 17:04:23 --> URI Class Initialized
DEBUG - 2023-09-24 17:04:23 --> No URI present. Default controller set.
INFO - 2023-09-24 17:04:23 --> Router Class Initialized
INFO - 2023-09-24 17:04:23 --> Output Class Initialized
INFO - 2023-09-24 17:04:23 --> Security Class Initialized
DEBUG - 2023-09-24 17:04:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-24 17:04:23 --> Input Class Initialized
INFO - 2023-09-24 17:04:23 --> Language Class Initialized
INFO - 2023-09-24 17:04:23 --> Loader Class Initialized
INFO - 2023-09-24 17:04:23 --> Helper loaded: url_helper
INFO - 2023-09-24 17:04:23 --> Helper loaded: file_helper
INFO - 2023-09-24 17:04:23 --> Helper loaded: html_helper
INFO - 2023-09-24 17:04:23 --> Helper loaded: text_helper
INFO - 2023-09-24 17:04:23 --> Helper loaded: form_helper
INFO - 2023-09-24 17:04:23 --> Helper loaded: lang_helper
INFO - 2023-09-24 17:04:23 --> Helper loaded: security_helper
INFO - 2023-09-24 17:04:23 --> Helper loaded: cookie_helper
INFO - 2023-09-24 17:04:23 --> Database Driver Class Initialized
INFO - 2023-09-24 17:04:23 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-24 17:04:23 --> Parser Class Initialized
INFO - 2023-09-24 17:04:23 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-24 17:04:23 --> Pagination Class Initialized
INFO - 2023-09-24 17:04:23 --> Form Validation Class Initialized
INFO - 2023-09-24 17:04:23 --> Controller Class Initialized
INFO - 2023-09-24 17:04:23 --> Model Class Initialized
DEBUG - 2023-09-24 17:04:23 --> Session class already loaded. Second attempt ignored.
ERROR - 2023-09-24 17:04:24 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-24 17:04:24 --> Config Class Initialized
INFO - 2023-09-24 17:04:24 --> Hooks Class Initialized
DEBUG - 2023-09-24 17:04:24 --> UTF-8 Support Enabled
INFO - 2023-09-24 17:04:24 --> Utf8 Class Initialized
INFO - 2023-09-24 17:04:24 --> URI Class Initialized
INFO - 2023-09-24 17:04:24 --> Router Class Initialized
INFO - 2023-09-24 17:04:24 --> Output Class Initialized
INFO - 2023-09-24 17:04:24 --> Security Class Initialized
DEBUG - 2023-09-24 17:04:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-24 17:04:24 --> Input Class Initialized
INFO - 2023-09-24 17:04:24 --> Language Class Initialized
INFO - 2023-09-24 17:04:24 --> Loader Class Initialized
INFO - 2023-09-24 17:04:24 --> Helper loaded: url_helper
INFO - 2023-09-24 17:04:24 --> Helper loaded: file_helper
INFO - 2023-09-24 17:04:24 --> Helper loaded: html_helper
INFO - 2023-09-24 17:04:24 --> Helper loaded: text_helper
INFO - 2023-09-24 17:04:24 --> Helper loaded: form_helper
INFO - 2023-09-24 17:04:24 --> Helper loaded: lang_helper
INFO - 2023-09-24 17:04:24 --> Helper loaded: security_helper
INFO - 2023-09-24 17:04:24 --> Helper loaded: cookie_helper
INFO - 2023-09-24 17:04:24 --> Database Driver Class Initialized
INFO - 2023-09-24 17:04:24 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-24 17:04:24 --> Parser Class Initialized
INFO - 2023-09-24 17:04:24 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-24 17:04:24 --> Pagination Class Initialized
INFO - 2023-09-24 17:04:24 --> Form Validation Class Initialized
INFO - 2023-09-24 17:04:24 --> Controller Class Initialized
INFO - 2023-09-24 17:04:24 --> Model Class Initialized
DEBUG - 2023-09-24 17:04:24 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-24 17:04:24 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2023-09-24 17:04:24 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-09-24 17:04:24 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-09-24 17:04:24 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-09-24 17:04:24 --> Model Class Initialized
INFO - 2023-09-24 17:04:24 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-09-24 17:04:24 --> Final output sent to browser
DEBUG - 2023-09-24 17:04:24 --> Total execution time: 0.0324
