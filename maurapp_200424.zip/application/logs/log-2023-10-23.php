<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2023-10-23 00:01:52 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-23 00:01:52 --> Config Class Initialized
INFO - 2023-10-23 00:01:52 --> Hooks Class Initialized
DEBUG - 2023-10-23 00:01:52 --> UTF-8 Support Enabled
INFO - 2023-10-23 00:01:52 --> Utf8 Class Initialized
INFO - 2023-10-23 00:01:52 --> URI Class Initialized
INFO - 2023-10-23 00:01:52 --> Router Class Initialized
INFO - 2023-10-23 00:01:52 --> Output Class Initialized
INFO - 2023-10-23 00:01:52 --> Security Class Initialized
DEBUG - 2023-10-23 00:01:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-23 00:01:52 --> Input Class Initialized
INFO - 2023-10-23 00:01:52 --> Language Class Initialized
ERROR - 2023-10-23 00:01:52 --> 404 Page Not Found: Well-known/assetlinks.json
ERROR - 2023-10-23 00:10:21 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-23 00:10:21 --> Config Class Initialized
INFO - 2023-10-23 00:10:21 --> Hooks Class Initialized
DEBUG - 2023-10-23 00:10:21 --> UTF-8 Support Enabled
INFO - 2023-10-23 00:10:21 --> Utf8 Class Initialized
INFO - 2023-10-23 00:10:21 --> URI Class Initialized
DEBUG - 2023-10-23 00:10:21 --> No URI present. Default controller set.
INFO - 2023-10-23 00:10:21 --> Router Class Initialized
INFO - 2023-10-23 00:10:21 --> Output Class Initialized
INFO - 2023-10-23 00:10:21 --> Security Class Initialized
DEBUG - 2023-10-23 00:10:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-23 00:10:21 --> Input Class Initialized
INFO - 2023-10-23 00:10:21 --> Language Class Initialized
INFO - 2023-10-23 00:10:21 --> Loader Class Initialized
INFO - 2023-10-23 00:10:21 --> Helper loaded: url_helper
INFO - 2023-10-23 00:10:21 --> Helper loaded: file_helper
INFO - 2023-10-23 00:10:21 --> Helper loaded: html_helper
INFO - 2023-10-23 00:10:21 --> Helper loaded: text_helper
INFO - 2023-10-23 00:10:21 --> Helper loaded: form_helper
INFO - 2023-10-23 00:10:21 --> Helper loaded: lang_helper
INFO - 2023-10-23 00:10:21 --> Helper loaded: security_helper
INFO - 2023-10-23 00:10:21 --> Helper loaded: cookie_helper
INFO - 2023-10-23 00:10:21 --> Database Driver Class Initialized
INFO - 2023-10-23 00:10:21 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-23 00:10:21 --> Parser Class Initialized
INFO - 2023-10-23 00:10:21 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-23 00:10:21 --> Pagination Class Initialized
INFO - 2023-10-23 00:10:21 --> Form Validation Class Initialized
INFO - 2023-10-23 00:10:21 --> Controller Class Initialized
INFO - 2023-10-23 00:10:21 --> Model Class Initialized
DEBUG - 2023-10-23 00:10:21 --> Session class already loaded. Second attempt ignored.
ERROR - 2023-10-23 04:01:54 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-23 04:01:54 --> Config Class Initialized
INFO - 2023-10-23 04:01:54 --> Hooks Class Initialized
DEBUG - 2023-10-23 04:01:54 --> UTF-8 Support Enabled
INFO - 2023-10-23 04:01:54 --> Utf8 Class Initialized
INFO - 2023-10-23 04:01:54 --> URI Class Initialized
INFO - 2023-10-23 04:01:54 --> Router Class Initialized
INFO - 2023-10-23 04:01:54 --> Output Class Initialized
INFO - 2023-10-23 04:01:54 --> Security Class Initialized
DEBUG - 2023-10-23 04:01:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-23 04:01:54 --> Input Class Initialized
INFO - 2023-10-23 04:01:54 --> Language Class Initialized
ERROR - 2023-10-23 04:01:54 --> 404 Page Not Found: Well-known/assetlinks.json
ERROR - 2023-10-23 05:10:08 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-23 05:10:08 --> Config Class Initialized
INFO - 2023-10-23 05:10:08 --> Hooks Class Initialized
DEBUG - 2023-10-23 05:10:08 --> UTF-8 Support Enabled
INFO - 2023-10-23 05:10:08 --> Utf8 Class Initialized
INFO - 2023-10-23 05:10:08 --> URI Class Initialized
DEBUG - 2023-10-23 05:10:08 --> No URI present. Default controller set.
INFO - 2023-10-23 05:10:08 --> Router Class Initialized
INFO - 2023-10-23 05:10:08 --> Output Class Initialized
INFO - 2023-10-23 05:10:08 --> Security Class Initialized
DEBUG - 2023-10-23 05:10:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-23 05:10:08 --> Input Class Initialized
INFO - 2023-10-23 05:10:08 --> Language Class Initialized
INFO - 2023-10-23 05:10:08 --> Loader Class Initialized
INFO - 2023-10-23 05:10:08 --> Helper loaded: url_helper
INFO - 2023-10-23 05:10:08 --> Helper loaded: file_helper
INFO - 2023-10-23 05:10:08 --> Helper loaded: html_helper
INFO - 2023-10-23 05:10:08 --> Helper loaded: text_helper
INFO - 2023-10-23 05:10:08 --> Helper loaded: form_helper
INFO - 2023-10-23 05:10:08 --> Helper loaded: lang_helper
INFO - 2023-10-23 05:10:08 --> Helper loaded: security_helper
INFO - 2023-10-23 05:10:08 --> Helper loaded: cookie_helper
INFO - 2023-10-23 05:10:08 --> Database Driver Class Initialized
INFO - 2023-10-23 05:10:08 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-23 05:10:08 --> Parser Class Initialized
INFO - 2023-10-23 05:10:08 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-23 05:10:08 --> Pagination Class Initialized
INFO - 2023-10-23 05:10:08 --> Form Validation Class Initialized
INFO - 2023-10-23 05:10:08 --> Controller Class Initialized
INFO - 2023-10-23 05:10:08 --> Model Class Initialized
DEBUG - 2023-10-23 05:10:08 --> Session class already loaded. Second attempt ignored.
ERROR - 2023-10-23 05:10:10 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-23 05:10:10 --> Config Class Initialized
INFO - 2023-10-23 05:10:10 --> Hooks Class Initialized
DEBUG - 2023-10-23 05:10:10 --> UTF-8 Support Enabled
INFO - 2023-10-23 05:10:10 --> Utf8 Class Initialized
INFO - 2023-10-23 05:10:10 --> URI Class Initialized
INFO - 2023-10-23 05:10:10 --> Router Class Initialized
INFO - 2023-10-23 05:10:10 --> Output Class Initialized
INFO - 2023-10-23 05:10:10 --> Security Class Initialized
DEBUG - 2023-10-23 05:10:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-23 05:10:10 --> Input Class Initialized
INFO - 2023-10-23 05:10:10 --> Language Class Initialized
INFO - 2023-10-23 05:10:10 --> Loader Class Initialized
INFO - 2023-10-23 05:10:10 --> Helper loaded: url_helper
INFO - 2023-10-23 05:10:10 --> Helper loaded: file_helper
INFO - 2023-10-23 05:10:10 --> Helper loaded: html_helper
INFO - 2023-10-23 05:10:10 --> Helper loaded: text_helper
INFO - 2023-10-23 05:10:10 --> Helper loaded: form_helper
INFO - 2023-10-23 05:10:10 --> Helper loaded: lang_helper
INFO - 2023-10-23 05:10:10 --> Helper loaded: security_helper
INFO - 2023-10-23 05:10:10 --> Helper loaded: cookie_helper
INFO - 2023-10-23 05:10:10 --> Database Driver Class Initialized
INFO - 2023-10-23 05:10:10 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-23 05:10:10 --> Parser Class Initialized
INFO - 2023-10-23 05:10:10 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-23 05:10:10 --> Pagination Class Initialized
INFO - 2023-10-23 05:10:10 --> Form Validation Class Initialized
INFO - 2023-10-23 05:10:10 --> Controller Class Initialized
INFO - 2023-10-23 05:10:10 --> Model Class Initialized
DEBUG - 2023-10-23 05:10:10 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-23 05:10:10 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2023-10-23 05:10:10 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-10-23 05:10:10 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-10-23 05:10:10 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-10-23 05:10:10 --> Model Class Initialized
INFO - 2023-10-23 05:10:10 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-10-23 05:10:10 --> Final output sent to browser
DEBUG - 2023-10-23 05:10:10 --> Total execution time: 0.0352
ERROR - 2023-10-23 07:28:15 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-23 07:28:15 --> Config Class Initialized
INFO - 2023-10-23 07:28:15 --> Hooks Class Initialized
DEBUG - 2023-10-23 07:28:15 --> UTF-8 Support Enabled
INFO - 2023-10-23 07:28:15 --> Utf8 Class Initialized
INFO - 2023-10-23 07:28:15 --> URI Class Initialized
DEBUG - 2023-10-23 07:28:15 --> No URI present. Default controller set.
INFO - 2023-10-23 07:28:15 --> Router Class Initialized
INFO - 2023-10-23 07:28:15 --> Output Class Initialized
INFO - 2023-10-23 07:28:15 --> Security Class Initialized
DEBUG - 2023-10-23 07:28:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-23 07:28:15 --> Input Class Initialized
INFO - 2023-10-23 07:28:15 --> Language Class Initialized
INFO - 2023-10-23 07:28:15 --> Loader Class Initialized
INFO - 2023-10-23 07:28:15 --> Helper loaded: url_helper
INFO - 2023-10-23 07:28:15 --> Helper loaded: file_helper
INFO - 2023-10-23 07:28:15 --> Helper loaded: html_helper
INFO - 2023-10-23 07:28:15 --> Helper loaded: text_helper
INFO - 2023-10-23 07:28:15 --> Helper loaded: form_helper
INFO - 2023-10-23 07:28:15 --> Helper loaded: lang_helper
INFO - 2023-10-23 07:28:15 --> Helper loaded: security_helper
INFO - 2023-10-23 07:28:15 --> Helper loaded: cookie_helper
INFO - 2023-10-23 07:28:15 --> Database Driver Class Initialized
INFO - 2023-10-23 07:28:15 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-23 07:28:15 --> Parser Class Initialized
INFO - 2023-10-23 07:28:15 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-23 07:28:15 --> Pagination Class Initialized
INFO - 2023-10-23 07:28:15 --> Form Validation Class Initialized
INFO - 2023-10-23 07:28:15 --> Controller Class Initialized
INFO - 2023-10-23 07:28:15 --> Model Class Initialized
DEBUG - 2023-10-23 07:28:15 --> Session class already loaded. Second attempt ignored.
ERROR - 2023-10-23 07:28:15 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-23 07:28:15 --> Config Class Initialized
INFO - 2023-10-23 07:28:15 --> Hooks Class Initialized
DEBUG - 2023-10-23 07:28:15 --> UTF-8 Support Enabled
INFO - 2023-10-23 07:28:15 --> Utf8 Class Initialized
INFO - 2023-10-23 07:28:15 --> URI Class Initialized
INFO - 2023-10-23 07:28:15 --> Router Class Initialized
INFO - 2023-10-23 07:28:15 --> Output Class Initialized
INFO - 2023-10-23 07:28:15 --> Security Class Initialized
DEBUG - 2023-10-23 07:28:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-23 07:28:15 --> Input Class Initialized
INFO - 2023-10-23 07:28:15 --> Language Class Initialized
INFO - 2023-10-23 07:28:15 --> Loader Class Initialized
INFO - 2023-10-23 07:28:15 --> Helper loaded: url_helper
INFO - 2023-10-23 07:28:15 --> Helper loaded: file_helper
INFO - 2023-10-23 07:28:15 --> Helper loaded: html_helper
INFO - 2023-10-23 07:28:15 --> Helper loaded: text_helper
INFO - 2023-10-23 07:28:15 --> Helper loaded: form_helper
INFO - 2023-10-23 07:28:15 --> Helper loaded: lang_helper
INFO - 2023-10-23 07:28:15 --> Helper loaded: security_helper
INFO - 2023-10-23 07:28:15 --> Helper loaded: cookie_helper
INFO - 2023-10-23 07:28:15 --> Database Driver Class Initialized
INFO - 2023-10-23 07:28:15 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-23 07:28:15 --> Parser Class Initialized
INFO - 2023-10-23 07:28:15 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-23 07:28:15 --> Pagination Class Initialized
INFO - 2023-10-23 07:28:15 --> Form Validation Class Initialized
INFO - 2023-10-23 07:28:15 --> Controller Class Initialized
INFO - 2023-10-23 07:28:15 --> Model Class Initialized
DEBUG - 2023-10-23 07:28:15 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-23 07:28:16 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2023-10-23 07:28:16 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-10-23 07:28:16 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-10-23 07:28:16 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-10-23 07:28:16 --> Model Class Initialized
INFO - 2023-10-23 07:28:16 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-10-23 07:28:16 --> Final output sent to browser
DEBUG - 2023-10-23 07:28:16 --> Total execution time: 0.0352
ERROR - 2023-10-23 07:28:26 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-23 07:28:26 --> Config Class Initialized
INFO - 2023-10-23 07:28:26 --> Hooks Class Initialized
DEBUG - 2023-10-23 07:28:26 --> UTF-8 Support Enabled
INFO - 2023-10-23 07:28:26 --> Utf8 Class Initialized
INFO - 2023-10-23 07:28:26 --> URI Class Initialized
INFO - 2023-10-23 07:28:26 --> Router Class Initialized
INFO - 2023-10-23 07:28:26 --> Output Class Initialized
INFO - 2023-10-23 07:28:26 --> Security Class Initialized
DEBUG - 2023-10-23 07:28:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-23 07:28:26 --> Input Class Initialized
INFO - 2023-10-23 07:28:26 --> Language Class Initialized
INFO - 2023-10-23 07:28:26 --> Loader Class Initialized
INFO - 2023-10-23 07:28:26 --> Helper loaded: url_helper
INFO - 2023-10-23 07:28:26 --> Helper loaded: file_helper
INFO - 2023-10-23 07:28:26 --> Helper loaded: html_helper
INFO - 2023-10-23 07:28:26 --> Helper loaded: text_helper
INFO - 2023-10-23 07:28:26 --> Helper loaded: form_helper
INFO - 2023-10-23 07:28:26 --> Helper loaded: lang_helper
INFO - 2023-10-23 07:28:26 --> Helper loaded: security_helper
INFO - 2023-10-23 07:28:26 --> Helper loaded: cookie_helper
INFO - 2023-10-23 07:28:26 --> Database Driver Class Initialized
INFO - 2023-10-23 07:28:26 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-23 07:28:26 --> Parser Class Initialized
INFO - 2023-10-23 07:28:26 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-23 07:28:26 --> Pagination Class Initialized
INFO - 2023-10-23 07:28:26 --> Form Validation Class Initialized
INFO - 2023-10-23 07:28:26 --> Controller Class Initialized
INFO - 2023-10-23 07:28:26 --> Model Class Initialized
DEBUG - 2023-10-23 07:28:26 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-23 07:28:26 --> Model Class Initialized
INFO - 2023-10-23 07:28:26 --> Final output sent to browser
DEBUG - 2023-10-23 07:28:26 --> Total execution time: 0.0215
ERROR - 2023-10-23 07:28:26 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-23 07:28:26 --> Config Class Initialized
INFO - 2023-10-23 07:28:26 --> Hooks Class Initialized
DEBUG - 2023-10-23 07:28:26 --> UTF-8 Support Enabled
INFO - 2023-10-23 07:28:26 --> Utf8 Class Initialized
INFO - 2023-10-23 07:28:26 --> URI Class Initialized
DEBUG - 2023-10-23 07:28:26 --> No URI present. Default controller set.
INFO - 2023-10-23 07:28:26 --> Router Class Initialized
INFO - 2023-10-23 07:28:26 --> Output Class Initialized
INFO - 2023-10-23 07:28:26 --> Security Class Initialized
DEBUG - 2023-10-23 07:28:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-23 07:28:26 --> Input Class Initialized
INFO - 2023-10-23 07:28:26 --> Language Class Initialized
INFO - 2023-10-23 07:28:26 --> Loader Class Initialized
INFO - 2023-10-23 07:28:26 --> Helper loaded: url_helper
INFO - 2023-10-23 07:28:26 --> Helper loaded: file_helper
INFO - 2023-10-23 07:28:26 --> Helper loaded: html_helper
INFO - 2023-10-23 07:28:26 --> Helper loaded: text_helper
INFO - 2023-10-23 07:28:26 --> Helper loaded: form_helper
INFO - 2023-10-23 07:28:26 --> Helper loaded: lang_helper
INFO - 2023-10-23 07:28:26 --> Helper loaded: security_helper
INFO - 2023-10-23 07:28:26 --> Helper loaded: cookie_helper
INFO - 2023-10-23 07:28:26 --> Database Driver Class Initialized
INFO - 2023-10-23 07:28:26 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-23 07:28:26 --> Parser Class Initialized
INFO - 2023-10-23 07:28:26 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-23 07:28:26 --> Pagination Class Initialized
INFO - 2023-10-23 07:28:26 --> Form Validation Class Initialized
INFO - 2023-10-23 07:28:26 --> Controller Class Initialized
INFO - 2023-10-23 07:28:26 --> Model Class Initialized
DEBUG - 2023-10-23 07:28:26 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-23 07:28:26 --> Model Class Initialized
DEBUG - 2023-10-23 07:28:26 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-23 07:28:26 --> Model Class Initialized
INFO - 2023-10-23 07:28:26 --> Model Class Initialized
INFO - 2023-10-23 07:28:26 --> Model Class Initialized
INFO - 2023-10-23 07:28:26 --> Model Class Initialized
DEBUG - 2023-10-23 07:28:26 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-10-23 07:28:26 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-23 07:28:27 --> Model Class Initialized
INFO - 2023-10-23 07:28:27 --> Model Class Initialized
INFO - 2023-10-23 07:28:27 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-10-23 07:28:27 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-10-23 07:28:27 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-10-23 07:28:27 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-10-23 07:28:27 --> Model Class Initialized
INFO - 2023-10-23 07:28:27 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-10-23 07:28:27 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-10-23 07:28:27 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-10-23 07:28:27 --> Final output sent to browser
DEBUG - 2023-10-23 07:28:27 --> Total execution time: 0.2055
ERROR - 2023-10-23 07:28:43 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-23 07:28:43 --> Config Class Initialized
INFO - 2023-10-23 07:28:43 --> Hooks Class Initialized
DEBUG - 2023-10-23 07:28:43 --> UTF-8 Support Enabled
INFO - 2023-10-23 07:28:43 --> Utf8 Class Initialized
INFO - 2023-10-23 07:28:43 --> URI Class Initialized
INFO - 2023-10-23 07:28:43 --> Router Class Initialized
INFO - 2023-10-23 07:28:43 --> Output Class Initialized
INFO - 2023-10-23 07:28:43 --> Security Class Initialized
DEBUG - 2023-10-23 07:28:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-23 07:28:43 --> Input Class Initialized
INFO - 2023-10-23 07:28:43 --> Language Class Initialized
INFO - 2023-10-23 07:28:43 --> Loader Class Initialized
INFO - 2023-10-23 07:28:43 --> Helper loaded: url_helper
INFO - 2023-10-23 07:28:43 --> Helper loaded: file_helper
INFO - 2023-10-23 07:28:43 --> Helper loaded: html_helper
INFO - 2023-10-23 07:28:43 --> Helper loaded: text_helper
INFO - 2023-10-23 07:28:43 --> Helper loaded: form_helper
INFO - 2023-10-23 07:28:43 --> Helper loaded: lang_helper
INFO - 2023-10-23 07:28:43 --> Helper loaded: security_helper
INFO - 2023-10-23 07:28:43 --> Helper loaded: cookie_helper
INFO - 2023-10-23 07:28:43 --> Database Driver Class Initialized
INFO - 2023-10-23 07:28:43 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-23 07:28:43 --> Parser Class Initialized
INFO - 2023-10-23 07:28:43 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-23 07:28:43 --> Pagination Class Initialized
INFO - 2023-10-23 07:28:43 --> Form Validation Class Initialized
INFO - 2023-10-23 07:28:43 --> Controller Class Initialized
INFO - 2023-10-23 07:28:43 --> Model Class Initialized
DEBUG - 2023-10-23 07:28:43 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-10-23 07:28:43 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-23 07:28:43 --> Model Class Initialized
DEBUG - 2023-10-23 07:28:43 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-23 07:28:43 --> Model Class Initialized
INFO - 2023-10-23 07:28:43 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice.php
DEBUG - 2023-10-23 07:28:43 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-10-23 07:28:43 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-10-23 07:28:43 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-10-23 07:28:43 --> Model Class Initialized
INFO - 2023-10-23 07:28:43 --> Model Class Initialized
INFO - 2023-10-23 07:28:43 --> Model Class Initialized
INFO - 2023-10-23 07:28:43 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-10-23 07:28:43 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-10-23 07:28:43 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-10-23 07:28:43 --> Final output sent to browser
DEBUG - 2023-10-23 07:28:43 --> Total execution time: 0.1397
ERROR - 2023-10-23 07:28:44 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-23 07:28:44 --> Config Class Initialized
INFO - 2023-10-23 07:28:44 --> Hooks Class Initialized
DEBUG - 2023-10-23 07:28:44 --> UTF-8 Support Enabled
INFO - 2023-10-23 07:28:44 --> Utf8 Class Initialized
INFO - 2023-10-23 07:28:44 --> URI Class Initialized
INFO - 2023-10-23 07:28:44 --> Router Class Initialized
INFO - 2023-10-23 07:28:44 --> Output Class Initialized
INFO - 2023-10-23 07:28:44 --> Security Class Initialized
DEBUG - 2023-10-23 07:28:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-23 07:28:44 --> Input Class Initialized
INFO - 2023-10-23 07:28:44 --> Language Class Initialized
INFO - 2023-10-23 07:28:44 --> Loader Class Initialized
INFO - 2023-10-23 07:28:44 --> Helper loaded: url_helper
INFO - 2023-10-23 07:28:44 --> Helper loaded: file_helper
INFO - 2023-10-23 07:28:44 --> Helper loaded: html_helper
INFO - 2023-10-23 07:28:44 --> Helper loaded: text_helper
INFO - 2023-10-23 07:28:44 --> Helper loaded: form_helper
INFO - 2023-10-23 07:28:44 --> Helper loaded: lang_helper
INFO - 2023-10-23 07:28:44 --> Helper loaded: security_helper
INFO - 2023-10-23 07:28:44 --> Helper loaded: cookie_helper
INFO - 2023-10-23 07:28:44 --> Database Driver Class Initialized
INFO - 2023-10-23 07:28:44 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-23 07:28:44 --> Parser Class Initialized
INFO - 2023-10-23 07:28:44 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-23 07:28:44 --> Pagination Class Initialized
INFO - 2023-10-23 07:28:44 --> Form Validation Class Initialized
INFO - 2023-10-23 07:28:44 --> Controller Class Initialized
INFO - 2023-10-23 07:28:44 --> Model Class Initialized
DEBUG - 2023-10-23 07:28:44 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-10-23 07:28:44 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-23 07:28:44 --> Model Class Initialized
DEBUG - 2023-10-23 07:28:44 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-23 07:28:44 --> Model Class Initialized
INFO - 2023-10-23 07:28:44 --> Final output sent to browser
DEBUG - 2023-10-23 07:28:44 --> Total execution time: 0.0397
ERROR - 2023-10-23 07:28:56 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-23 07:28:56 --> Config Class Initialized
INFO - 2023-10-23 07:28:56 --> Hooks Class Initialized
DEBUG - 2023-10-23 07:28:56 --> UTF-8 Support Enabled
INFO - 2023-10-23 07:28:56 --> Utf8 Class Initialized
INFO - 2023-10-23 07:28:56 --> URI Class Initialized
INFO - 2023-10-23 07:28:56 --> Router Class Initialized
INFO - 2023-10-23 07:28:56 --> Output Class Initialized
INFO - 2023-10-23 07:28:56 --> Security Class Initialized
DEBUG - 2023-10-23 07:28:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-23 07:28:56 --> Input Class Initialized
INFO - 2023-10-23 07:28:56 --> Language Class Initialized
INFO - 2023-10-23 07:28:56 --> Loader Class Initialized
INFO - 2023-10-23 07:28:56 --> Helper loaded: url_helper
INFO - 2023-10-23 07:28:56 --> Helper loaded: file_helper
INFO - 2023-10-23 07:28:56 --> Helper loaded: html_helper
INFO - 2023-10-23 07:28:56 --> Helper loaded: text_helper
INFO - 2023-10-23 07:28:56 --> Helper loaded: form_helper
INFO - 2023-10-23 07:28:56 --> Helper loaded: lang_helper
INFO - 2023-10-23 07:28:56 --> Helper loaded: security_helper
INFO - 2023-10-23 07:28:56 --> Helper loaded: cookie_helper
INFO - 2023-10-23 07:28:56 --> Database Driver Class Initialized
INFO - 2023-10-23 07:28:56 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-23 07:28:56 --> Parser Class Initialized
INFO - 2023-10-23 07:28:56 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-23 07:28:56 --> Pagination Class Initialized
INFO - 2023-10-23 07:28:56 --> Form Validation Class Initialized
INFO - 2023-10-23 07:28:56 --> Controller Class Initialized
INFO - 2023-10-23 07:28:56 --> Model Class Initialized
DEBUG - 2023-10-23 07:28:56 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-10-23 07:28:56 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-23 07:28:56 --> Model Class Initialized
DEBUG - 2023-10-23 07:28:56 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-23 07:28:56 --> Model Class Initialized
DEBUG - 2023-10-23 07:28:56 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-23 07:28:56 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice_html.php
DEBUG - 2023-10-23 07:28:56 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-10-23 07:28:56 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-10-23 07:28:56 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-10-23 07:28:56 --> Model Class Initialized
INFO - 2023-10-23 07:28:56 --> Model Class Initialized
INFO - 2023-10-23 07:28:56 --> Model Class Initialized
INFO - 2023-10-23 07:28:56 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-10-23 07:28:56 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-10-23 07:28:56 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-10-23 07:28:56 --> Final output sent to browser
DEBUG - 2023-10-23 07:28:56 --> Total execution time: 0.1424
ERROR - 2023-10-23 07:29:29 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-23 07:29:29 --> Config Class Initialized
INFO - 2023-10-23 07:29:29 --> Hooks Class Initialized
DEBUG - 2023-10-23 07:29:29 --> UTF-8 Support Enabled
INFO - 2023-10-23 07:29:29 --> Utf8 Class Initialized
INFO - 2023-10-23 07:29:29 --> URI Class Initialized
INFO - 2023-10-23 07:29:29 --> Router Class Initialized
INFO - 2023-10-23 07:29:29 --> Output Class Initialized
INFO - 2023-10-23 07:29:29 --> Security Class Initialized
DEBUG - 2023-10-23 07:29:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-23 07:29:29 --> Input Class Initialized
INFO - 2023-10-23 07:29:29 --> Language Class Initialized
INFO - 2023-10-23 07:29:29 --> Loader Class Initialized
INFO - 2023-10-23 07:29:29 --> Helper loaded: url_helper
INFO - 2023-10-23 07:29:29 --> Helper loaded: file_helper
INFO - 2023-10-23 07:29:29 --> Helper loaded: html_helper
INFO - 2023-10-23 07:29:29 --> Helper loaded: text_helper
INFO - 2023-10-23 07:29:29 --> Helper loaded: form_helper
INFO - 2023-10-23 07:29:29 --> Helper loaded: lang_helper
INFO - 2023-10-23 07:29:29 --> Helper loaded: security_helper
INFO - 2023-10-23 07:29:29 --> Helper loaded: cookie_helper
INFO - 2023-10-23 07:29:29 --> Database Driver Class Initialized
INFO - 2023-10-23 07:29:29 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-23 07:29:29 --> Parser Class Initialized
INFO - 2023-10-23 07:29:29 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-23 07:29:29 --> Pagination Class Initialized
INFO - 2023-10-23 07:29:29 --> Form Validation Class Initialized
INFO - 2023-10-23 07:29:29 --> Controller Class Initialized
INFO - 2023-10-23 07:29:29 --> Model Class Initialized
DEBUG - 2023-10-23 07:29:29 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-10-23 07:29:29 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-23 07:29:29 --> Model Class Initialized
DEBUG - 2023-10-23 07:29:29 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-23 07:29:29 --> Model Class Initialized
INFO - 2023-10-23 07:29:29 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice.php
DEBUG - 2023-10-23 07:29:29 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-10-23 07:29:29 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-10-23 07:29:29 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-10-23 07:29:29 --> Model Class Initialized
INFO - 2023-10-23 07:29:29 --> Model Class Initialized
INFO - 2023-10-23 07:29:29 --> Model Class Initialized
INFO - 2023-10-23 07:29:29 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-10-23 07:29:29 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-10-23 07:29:29 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-10-23 07:29:29 --> Final output sent to browser
DEBUG - 2023-10-23 07:29:29 --> Total execution time: 0.1359
ERROR - 2023-10-23 07:29:30 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-23 07:29:30 --> Config Class Initialized
INFO - 2023-10-23 07:29:30 --> Hooks Class Initialized
DEBUG - 2023-10-23 07:29:30 --> UTF-8 Support Enabled
INFO - 2023-10-23 07:29:30 --> Utf8 Class Initialized
INFO - 2023-10-23 07:29:30 --> URI Class Initialized
INFO - 2023-10-23 07:29:30 --> Router Class Initialized
INFO - 2023-10-23 07:29:30 --> Output Class Initialized
INFO - 2023-10-23 07:29:30 --> Security Class Initialized
DEBUG - 2023-10-23 07:29:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-23 07:29:30 --> Input Class Initialized
INFO - 2023-10-23 07:29:30 --> Language Class Initialized
INFO - 2023-10-23 07:29:30 --> Loader Class Initialized
INFO - 2023-10-23 07:29:30 --> Helper loaded: url_helper
INFO - 2023-10-23 07:29:30 --> Helper loaded: file_helper
INFO - 2023-10-23 07:29:30 --> Helper loaded: html_helper
INFO - 2023-10-23 07:29:30 --> Helper loaded: text_helper
INFO - 2023-10-23 07:29:30 --> Helper loaded: form_helper
INFO - 2023-10-23 07:29:30 --> Helper loaded: lang_helper
INFO - 2023-10-23 07:29:30 --> Helper loaded: security_helper
INFO - 2023-10-23 07:29:30 --> Helper loaded: cookie_helper
INFO - 2023-10-23 07:29:30 --> Database Driver Class Initialized
INFO - 2023-10-23 07:29:30 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-23 07:29:30 --> Parser Class Initialized
INFO - 2023-10-23 07:29:30 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-23 07:29:30 --> Pagination Class Initialized
INFO - 2023-10-23 07:29:30 --> Form Validation Class Initialized
INFO - 2023-10-23 07:29:30 --> Controller Class Initialized
INFO - 2023-10-23 07:29:30 --> Model Class Initialized
DEBUG - 2023-10-23 07:29:30 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-10-23 07:29:30 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-23 07:29:30 --> Model Class Initialized
DEBUG - 2023-10-23 07:29:30 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-23 07:29:30 --> Model Class Initialized
INFO - 2023-10-23 07:29:30 --> Final output sent to browser
DEBUG - 2023-10-23 07:29:30 --> Total execution time: 0.0429
ERROR - 2023-10-23 07:29:34 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-23 07:29:34 --> Config Class Initialized
INFO - 2023-10-23 07:29:34 --> Hooks Class Initialized
DEBUG - 2023-10-23 07:29:34 --> UTF-8 Support Enabled
INFO - 2023-10-23 07:29:34 --> Utf8 Class Initialized
INFO - 2023-10-23 07:29:34 --> URI Class Initialized
INFO - 2023-10-23 07:29:34 --> Router Class Initialized
INFO - 2023-10-23 07:29:34 --> Output Class Initialized
INFO - 2023-10-23 07:29:34 --> Security Class Initialized
DEBUG - 2023-10-23 07:29:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-23 07:29:34 --> Input Class Initialized
INFO - 2023-10-23 07:29:34 --> Language Class Initialized
INFO - 2023-10-23 07:29:34 --> Loader Class Initialized
INFO - 2023-10-23 07:29:34 --> Helper loaded: url_helper
INFO - 2023-10-23 07:29:34 --> Helper loaded: file_helper
INFO - 2023-10-23 07:29:34 --> Helper loaded: html_helper
INFO - 2023-10-23 07:29:34 --> Helper loaded: text_helper
INFO - 2023-10-23 07:29:34 --> Helper loaded: form_helper
INFO - 2023-10-23 07:29:34 --> Helper loaded: lang_helper
INFO - 2023-10-23 07:29:34 --> Helper loaded: security_helper
INFO - 2023-10-23 07:29:34 --> Helper loaded: cookie_helper
INFO - 2023-10-23 07:29:34 --> Database Driver Class Initialized
INFO - 2023-10-23 07:29:34 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-23 07:29:34 --> Parser Class Initialized
INFO - 2023-10-23 07:29:34 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-23 07:29:34 --> Pagination Class Initialized
INFO - 2023-10-23 07:29:34 --> Form Validation Class Initialized
INFO - 2023-10-23 07:29:34 --> Controller Class Initialized
INFO - 2023-10-23 07:29:34 --> Model Class Initialized
DEBUG - 2023-10-23 07:29:34 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-10-23 07:29:34 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-23 07:29:34 --> Model Class Initialized
DEBUG - 2023-10-23 07:29:34 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-23 07:29:34 --> Model Class Initialized
DEBUG - 2023-10-23 07:29:34 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-23 07:29:34 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice_html.php
DEBUG - 2023-10-23 07:29:34 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-10-23 07:29:34 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-10-23 07:29:34 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-10-23 07:29:34 --> Model Class Initialized
INFO - 2023-10-23 07:29:34 --> Model Class Initialized
INFO - 2023-10-23 07:29:34 --> Model Class Initialized
INFO - 2023-10-23 07:29:34 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-10-23 07:29:34 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-10-23 07:29:34 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-10-23 07:29:34 --> Final output sent to browser
DEBUG - 2023-10-23 07:29:34 --> Total execution time: 0.1388
ERROR - 2023-10-23 07:38:29 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-23 07:38:29 --> Config Class Initialized
INFO - 2023-10-23 07:38:29 --> Hooks Class Initialized
DEBUG - 2023-10-23 07:38:29 --> UTF-8 Support Enabled
INFO - 2023-10-23 07:38:29 --> Utf8 Class Initialized
INFO - 2023-10-23 07:38:29 --> URI Class Initialized
DEBUG - 2023-10-23 07:38:29 --> No URI present. Default controller set.
INFO - 2023-10-23 07:38:29 --> Router Class Initialized
INFO - 2023-10-23 07:38:29 --> Output Class Initialized
INFO - 2023-10-23 07:38:29 --> Security Class Initialized
DEBUG - 2023-10-23 07:38:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-23 07:38:29 --> Input Class Initialized
INFO - 2023-10-23 07:38:29 --> Language Class Initialized
INFO - 2023-10-23 07:38:29 --> Loader Class Initialized
INFO - 2023-10-23 07:38:29 --> Helper loaded: url_helper
INFO - 2023-10-23 07:38:29 --> Helper loaded: file_helper
INFO - 2023-10-23 07:38:29 --> Helper loaded: html_helper
INFO - 2023-10-23 07:38:29 --> Helper loaded: text_helper
INFO - 2023-10-23 07:38:29 --> Helper loaded: form_helper
INFO - 2023-10-23 07:38:29 --> Helper loaded: lang_helper
INFO - 2023-10-23 07:38:29 --> Helper loaded: security_helper
INFO - 2023-10-23 07:38:29 --> Helper loaded: cookie_helper
INFO - 2023-10-23 07:38:29 --> Database Driver Class Initialized
INFO - 2023-10-23 07:38:29 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-23 07:38:29 --> Parser Class Initialized
INFO - 2023-10-23 07:38:29 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-23 07:38:29 --> Pagination Class Initialized
INFO - 2023-10-23 07:38:29 --> Form Validation Class Initialized
INFO - 2023-10-23 07:38:29 --> Controller Class Initialized
INFO - 2023-10-23 07:38:29 --> Model Class Initialized
DEBUG - 2023-10-23 07:38:29 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-23 07:38:29 --> Model Class Initialized
DEBUG - 2023-10-23 07:38:29 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-23 07:38:29 --> Model Class Initialized
INFO - 2023-10-23 07:38:29 --> Model Class Initialized
INFO - 2023-10-23 07:38:29 --> Model Class Initialized
INFO - 2023-10-23 07:38:29 --> Model Class Initialized
DEBUG - 2023-10-23 07:38:29 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-10-23 07:38:29 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-23 07:38:29 --> Model Class Initialized
INFO - 2023-10-23 07:38:29 --> Model Class Initialized
INFO - 2023-10-23 07:38:29 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-10-23 07:38:29 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-10-23 07:38:29 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-10-23 07:38:29 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-10-23 07:38:29 --> Model Class Initialized
INFO - 2023-10-23 07:38:29 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-10-23 07:38:29 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-10-23 07:38:29 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-10-23 07:38:29 --> Final output sent to browser
DEBUG - 2023-10-23 07:38:29 --> Total execution time: 0.1964
ERROR - 2023-10-23 07:38:35 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-23 07:38:35 --> Config Class Initialized
INFO - 2023-10-23 07:38:35 --> Hooks Class Initialized
DEBUG - 2023-10-23 07:38:35 --> UTF-8 Support Enabled
INFO - 2023-10-23 07:38:35 --> Utf8 Class Initialized
INFO - 2023-10-23 07:38:35 --> URI Class Initialized
INFO - 2023-10-23 07:38:35 --> Router Class Initialized
INFO - 2023-10-23 07:38:35 --> Output Class Initialized
INFO - 2023-10-23 07:38:35 --> Security Class Initialized
DEBUG - 2023-10-23 07:38:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-23 07:38:35 --> Input Class Initialized
INFO - 2023-10-23 07:38:35 --> Language Class Initialized
INFO - 2023-10-23 07:38:35 --> Loader Class Initialized
INFO - 2023-10-23 07:38:35 --> Helper loaded: url_helper
INFO - 2023-10-23 07:38:35 --> Helper loaded: file_helper
INFO - 2023-10-23 07:38:35 --> Helper loaded: html_helper
INFO - 2023-10-23 07:38:35 --> Helper loaded: text_helper
INFO - 2023-10-23 07:38:35 --> Helper loaded: form_helper
INFO - 2023-10-23 07:38:35 --> Helper loaded: lang_helper
INFO - 2023-10-23 07:38:35 --> Helper loaded: security_helper
INFO - 2023-10-23 07:38:35 --> Helper loaded: cookie_helper
INFO - 2023-10-23 07:38:35 --> Database Driver Class Initialized
INFO - 2023-10-23 07:38:35 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-23 07:38:35 --> Parser Class Initialized
INFO - 2023-10-23 07:38:35 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-23 07:38:35 --> Pagination Class Initialized
INFO - 2023-10-23 07:38:35 --> Form Validation Class Initialized
INFO - 2023-10-23 07:38:35 --> Controller Class Initialized
INFO - 2023-10-23 07:38:35 --> Model Class Initialized
DEBUG - 2023-10-23 07:38:35 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-10-23 07:38:35 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-23 07:38:35 --> Model Class Initialized
DEBUG - 2023-10-23 07:38:35 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-23 07:38:35 --> Model Class Initialized
INFO - 2023-10-23 07:38:35 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice.php
DEBUG - 2023-10-23 07:38:35 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-10-23 07:38:35 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-10-23 07:38:35 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-10-23 07:38:35 --> Model Class Initialized
INFO - 2023-10-23 07:38:35 --> Model Class Initialized
INFO - 2023-10-23 07:38:35 --> Model Class Initialized
INFO - 2023-10-23 07:38:35 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-10-23 07:38:35 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-10-23 07:38:35 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-10-23 07:38:35 --> Final output sent to browser
DEBUG - 2023-10-23 07:38:35 --> Total execution time: 0.1272
ERROR - 2023-10-23 07:38:36 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-23 07:38:36 --> Config Class Initialized
INFO - 2023-10-23 07:38:36 --> Hooks Class Initialized
DEBUG - 2023-10-23 07:38:36 --> UTF-8 Support Enabled
INFO - 2023-10-23 07:38:36 --> Utf8 Class Initialized
INFO - 2023-10-23 07:38:36 --> URI Class Initialized
INFO - 2023-10-23 07:38:36 --> Router Class Initialized
INFO - 2023-10-23 07:38:36 --> Output Class Initialized
INFO - 2023-10-23 07:38:36 --> Security Class Initialized
DEBUG - 2023-10-23 07:38:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-23 07:38:36 --> Input Class Initialized
INFO - 2023-10-23 07:38:36 --> Language Class Initialized
INFO - 2023-10-23 07:38:36 --> Loader Class Initialized
INFO - 2023-10-23 07:38:36 --> Helper loaded: url_helper
INFO - 2023-10-23 07:38:36 --> Helper loaded: file_helper
INFO - 2023-10-23 07:38:36 --> Helper loaded: html_helper
INFO - 2023-10-23 07:38:36 --> Helper loaded: text_helper
INFO - 2023-10-23 07:38:36 --> Helper loaded: form_helper
INFO - 2023-10-23 07:38:36 --> Helper loaded: lang_helper
INFO - 2023-10-23 07:38:36 --> Helper loaded: security_helper
INFO - 2023-10-23 07:38:36 --> Helper loaded: cookie_helper
INFO - 2023-10-23 07:38:36 --> Database Driver Class Initialized
INFO - 2023-10-23 07:38:36 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-23 07:38:36 --> Parser Class Initialized
INFO - 2023-10-23 07:38:36 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-23 07:38:36 --> Pagination Class Initialized
INFO - 2023-10-23 07:38:36 --> Form Validation Class Initialized
INFO - 2023-10-23 07:38:36 --> Controller Class Initialized
INFO - 2023-10-23 07:38:36 --> Model Class Initialized
DEBUG - 2023-10-23 07:38:36 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-10-23 07:38:36 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-23 07:38:36 --> Model Class Initialized
DEBUG - 2023-10-23 07:38:36 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-23 07:38:36 --> Model Class Initialized
INFO - 2023-10-23 07:38:36 --> Final output sent to browser
DEBUG - 2023-10-23 07:38:36 --> Total execution time: 0.0399
ERROR - 2023-10-23 17:35:46 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-23 17:35:46 --> Config Class Initialized
INFO - 2023-10-23 17:35:46 --> Hooks Class Initialized
DEBUG - 2023-10-23 17:35:46 --> UTF-8 Support Enabled
INFO - 2023-10-23 17:35:46 --> Utf8 Class Initialized
INFO - 2023-10-23 17:35:46 --> URI Class Initialized
DEBUG - 2023-10-23 17:35:46 --> No URI present. Default controller set.
INFO - 2023-10-23 17:35:46 --> Router Class Initialized
INFO - 2023-10-23 17:35:46 --> Output Class Initialized
INFO - 2023-10-23 17:35:46 --> Security Class Initialized
DEBUG - 2023-10-23 17:35:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-23 17:35:46 --> Input Class Initialized
INFO - 2023-10-23 17:35:46 --> Language Class Initialized
INFO - 2023-10-23 17:35:46 --> Loader Class Initialized
INFO - 2023-10-23 17:35:46 --> Helper loaded: url_helper
INFO - 2023-10-23 17:35:46 --> Helper loaded: file_helper
INFO - 2023-10-23 17:35:46 --> Helper loaded: html_helper
INFO - 2023-10-23 17:35:46 --> Helper loaded: text_helper
INFO - 2023-10-23 17:35:46 --> Helper loaded: form_helper
INFO - 2023-10-23 17:35:46 --> Helper loaded: lang_helper
INFO - 2023-10-23 17:35:46 --> Helper loaded: security_helper
INFO - 2023-10-23 17:35:46 --> Helper loaded: cookie_helper
INFO - 2023-10-23 17:35:46 --> Database Driver Class Initialized
INFO - 2023-10-23 17:35:46 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-23 17:35:46 --> Parser Class Initialized
INFO - 2023-10-23 17:35:46 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-23 17:35:46 --> Pagination Class Initialized
INFO - 2023-10-23 17:35:46 --> Form Validation Class Initialized
INFO - 2023-10-23 17:35:46 --> Controller Class Initialized
INFO - 2023-10-23 17:35:46 --> Model Class Initialized
DEBUG - 2023-10-23 17:35:46 --> Session class already loaded. Second attempt ignored.
ERROR - 2023-10-23 17:35:46 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-23 17:35:46 --> Config Class Initialized
INFO - 2023-10-23 17:35:46 --> Hooks Class Initialized
DEBUG - 2023-10-23 17:35:46 --> UTF-8 Support Enabled
INFO - 2023-10-23 17:35:46 --> Utf8 Class Initialized
INFO - 2023-10-23 17:35:46 --> URI Class Initialized
INFO - 2023-10-23 17:35:46 --> Router Class Initialized
INFO - 2023-10-23 17:35:46 --> Output Class Initialized
INFO - 2023-10-23 17:35:46 --> Security Class Initialized
DEBUG - 2023-10-23 17:35:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-23 17:35:46 --> Input Class Initialized
INFO - 2023-10-23 17:35:46 --> Language Class Initialized
INFO - 2023-10-23 17:35:46 --> Loader Class Initialized
INFO - 2023-10-23 17:35:46 --> Helper loaded: url_helper
INFO - 2023-10-23 17:35:46 --> Helper loaded: file_helper
INFO - 2023-10-23 17:35:46 --> Helper loaded: html_helper
INFO - 2023-10-23 17:35:46 --> Helper loaded: text_helper
INFO - 2023-10-23 17:35:46 --> Helper loaded: form_helper
INFO - 2023-10-23 17:35:46 --> Helper loaded: lang_helper
INFO - 2023-10-23 17:35:46 --> Helper loaded: security_helper
INFO - 2023-10-23 17:35:46 --> Helper loaded: cookie_helper
INFO - 2023-10-23 17:35:46 --> Database Driver Class Initialized
INFO - 2023-10-23 17:35:46 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-23 17:35:46 --> Parser Class Initialized
INFO - 2023-10-23 17:35:46 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-23 17:35:46 --> Pagination Class Initialized
INFO - 2023-10-23 17:35:46 --> Form Validation Class Initialized
INFO - 2023-10-23 17:35:46 --> Controller Class Initialized
INFO - 2023-10-23 17:35:46 --> Model Class Initialized
DEBUG - 2023-10-23 17:35:46 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-23 17:35:46 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2023-10-23 17:35:46 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-10-23 17:35:46 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-10-23 17:35:46 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-10-23 17:35:46 --> Model Class Initialized
INFO - 2023-10-23 17:35:46 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-10-23 17:35:46 --> Final output sent to browser
DEBUG - 2023-10-23 17:35:46 --> Total execution time: 0.0383
ERROR - 2023-10-23 17:35:49 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-23 17:35:49 --> Config Class Initialized
INFO - 2023-10-23 17:35:49 --> Hooks Class Initialized
DEBUG - 2023-10-23 17:35:49 --> UTF-8 Support Enabled
INFO - 2023-10-23 17:35:49 --> Utf8 Class Initialized
INFO - 2023-10-23 17:35:49 --> URI Class Initialized
DEBUG - 2023-10-23 17:35:49 --> No URI present. Default controller set.
INFO - 2023-10-23 17:35:49 --> Router Class Initialized
INFO - 2023-10-23 17:35:49 --> Output Class Initialized
INFO - 2023-10-23 17:35:49 --> Security Class Initialized
DEBUG - 2023-10-23 17:35:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-23 17:35:49 --> Input Class Initialized
INFO - 2023-10-23 17:35:49 --> Language Class Initialized
INFO - 2023-10-23 17:35:49 --> Loader Class Initialized
INFO - 2023-10-23 17:35:49 --> Helper loaded: url_helper
INFO - 2023-10-23 17:35:49 --> Helper loaded: file_helper
INFO - 2023-10-23 17:35:49 --> Helper loaded: html_helper
INFO - 2023-10-23 17:35:49 --> Helper loaded: text_helper
INFO - 2023-10-23 17:35:49 --> Helper loaded: form_helper
INFO - 2023-10-23 17:35:49 --> Helper loaded: lang_helper
INFO - 2023-10-23 17:35:49 --> Helper loaded: security_helper
INFO - 2023-10-23 17:35:49 --> Helper loaded: cookie_helper
INFO - 2023-10-23 17:35:49 --> Database Driver Class Initialized
INFO - 2023-10-23 17:35:49 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-23 17:35:49 --> Parser Class Initialized
INFO - 2023-10-23 17:35:49 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-23 17:35:49 --> Pagination Class Initialized
INFO - 2023-10-23 17:35:49 --> Form Validation Class Initialized
INFO - 2023-10-23 17:35:49 --> Controller Class Initialized
INFO - 2023-10-23 17:35:49 --> Model Class Initialized
DEBUG - 2023-10-23 17:35:49 --> Session class already loaded. Second attempt ignored.
ERROR - 2023-10-23 17:35:50 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-23 17:35:50 --> Config Class Initialized
INFO - 2023-10-23 17:35:50 --> Hooks Class Initialized
DEBUG - 2023-10-23 17:35:50 --> UTF-8 Support Enabled
INFO - 2023-10-23 17:35:50 --> Utf8 Class Initialized
INFO - 2023-10-23 17:35:50 --> URI Class Initialized
INFO - 2023-10-23 17:35:50 --> Router Class Initialized
INFO - 2023-10-23 17:35:50 --> Output Class Initialized
INFO - 2023-10-23 17:35:50 --> Security Class Initialized
DEBUG - 2023-10-23 17:35:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-23 17:35:50 --> Input Class Initialized
INFO - 2023-10-23 17:35:50 --> Language Class Initialized
INFO - 2023-10-23 17:35:50 --> Loader Class Initialized
INFO - 2023-10-23 17:35:50 --> Helper loaded: url_helper
INFO - 2023-10-23 17:35:50 --> Helper loaded: file_helper
INFO - 2023-10-23 17:35:50 --> Helper loaded: html_helper
INFO - 2023-10-23 17:35:50 --> Helper loaded: text_helper
INFO - 2023-10-23 17:35:50 --> Helper loaded: form_helper
INFO - 2023-10-23 17:35:50 --> Helper loaded: lang_helper
INFO - 2023-10-23 17:35:50 --> Helper loaded: security_helper
INFO - 2023-10-23 17:35:50 --> Helper loaded: cookie_helper
INFO - 2023-10-23 17:35:50 --> Database Driver Class Initialized
INFO - 2023-10-23 17:35:50 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-23 17:35:50 --> Parser Class Initialized
INFO - 2023-10-23 17:35:50 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-23 17:35:50 --> Pagination Class Initialized
INFO - 2023-10-23 17:35:50 --> Form Validation Class Initialized
INFO - 2023-10-23 17:35:50 --> Controller Class Initialized
INFO - 2023-10-23 17:35:50 --> Model Class Initialized
DEBUG - 2023-10-23 17:35:50 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-23 17:35:50 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2023-10-23 17:35:50 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-10-23 17:35:50 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-10-23 17:35:50 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-10-23 17:35:50 --> Model Class Initialized
INFO - 2023-10-23 17:35:50 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-10-23 17:35:50 --> Final output sent to browser
DEBUG - 2023-10-23 17:35:50 --> Total execution time: 0.0311
ERROR - 2023-10-23 17:35:59 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-23 17:35:59 --> Config Class Initialized
INFO - 2023-10-23 17:35:59 --> Hooks Class Initialized
DEBUG - 2023-10-23 17:35:59 --> UTF-8 Support Enabled
INFO - 2023-10-23 17:35:59 --> Utf8 Class Initialized
INFO - 2023-10-23 17:35:59 --> URI Class Initialized
DEBUG - 2023-10-23 17:35:59 --> No URI present. Default controller set.
INFO - 2023-10-23 17:35:59 --> Router Class Initialized
INFO - 2023-10-23 17:35:59 --> Output Class Initialized
INFO - 2023-10-23 17:35:59 --> Security Class Initialized
DEBUG - 2023-10-23 17:35:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-23 17:35:59 --> Input Class Initialized
INFO - 2023-10-23 17:35:59 --> Language Class Initialized
INFO - 2023-10-23 17:35:59 --> Loader Class Initialized
INFO - 2023-10-23 17:35:59 --> Helper loaded: url_helper
INFO - 2023-10-23 17:35:59 --> Helper loaded: file_helper
INFO - 2023-10-23 17:35:59 --> Helper loaded: html_helper
INFO - 2023-10-23 17:35:59 --> Helper loaded: text_helper
INFO - 2023-10-23 17:35:59 --> Helper loaded: form_helper
INFO - 2023-10-23 17:35:59 --> Helper loaded: lang_helper
INFO - 2023-10-23 17:35:59 --> Helper loaded: security_helper
INFO - 2023-10-23 17:35:59 --> Helper loaded: cookie_helper
INFO - 2023-10-23 17:35:59 --> Database Driver Class Initialized
INFO - 2023-10-23 17:35:59 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-23 17:35:59 --> Parser Class Initialized
INFO - 2023-10-23 17:35:59 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-23 17:35:59 --> Pagination Class Initialized
INFO - 2023-10-23 17:35:59 --> Form Validation Class Initialized
INFO - 2023-10-23 17:35:59 --> Controller Class Initialized
INFO - 2023-10-23 17:35:59 --> Model Class Initialized
DEBUG - 2023-10-23 17:35:59 --> Session class already loaded. Second attempt ignored.
ERROR - 2023-10-23 17:36:00 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-23 17:36:00 --> Config Class Initialized
INFO - 2023-10-23 17:36:00 --> Hooks Class Initialized
DEBUG - 2023-10-23 17:36:00 --> UTF-8 Support Enabled
INFO - 2023-10-23 17:36:00 --> Utf8 Class Initialized
INFO - 2023-10-23 17:36:00 --> URI Class Initialized
INFO - 2023-10-23 17:36:00 --> Router Class Initialized
INFO - 2023-10-23 17:36:00 --> Output Class Initialized
INFO - 2023-10-23 17:36:00 --> Security Class Initialized
DEBUG - 2023-10-23 17:36:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-23 17:36:00 --> Input Class Initialized
INFO - 2023-10-23 17:36:00 --> Language Class Initialized
INFO - 2023-10-23 17:36:00 --> Loader Class Initialized
INFO - 2023-10-23 17:36:00 --> Helper loaded: url_helper
INFO - 2023-10-23 17:36:00 --> Helper loaded: file_helper
INFO - 2023-10-23 17:36:00 --> Helper loaded: html_helper
INFO - 2023-10-23 17:36:00 --> Helper loaded: text_helper
INFO - 2023-10-23 17:36:00 --> Helper loaded: form_helper
INFO - 2023-10-23 17:36:00 --> Helper loaded: lang_helper
INFO - 2023-10-23 17:36:00 --> Helper loaded: security_helper
INFO - 2023-10-23 17:36:00 --> Helper loaded: cookie_helper
INFO - 2023-10-23 17:36:00 --> Database Driver Class Initialized
INFO - 2023-10-23 17:36:00 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-23 17:36:00 --> Parser Class Initialized
INFO - 2023-10-23 17:36:00 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-23 17:36:00 --> Pagination Class Initialized
INFO - 2023-10-23 17:36:00 --> Form Validation Class Initialized
INFO - 2023-10-23 17:36:00 --> Controller Class Initialized
INFO - 2023-10-23 17:36:00 --> Model Class Initialized
DEBUG - 2023-10-23 17:36:00 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-23 17:36:00 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2023-10-23 17:36:00 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-10-23 17:36:00 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-10-23 17:36:00 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-10-23 17:36:00 --> Model Class Initialized
INFO - 2023-10-23 17:36:00 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-10-23 17:36:00 --> Final output sent to browser
DEBUG - 2023-10-23 17:36:00 --> Total execution time: 0.0274
ERROR - 2023-10-23 17:41:11 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-23 17:41:11 --> Config Class Initialized
INFO - 2023-10-23 17:41:11 --> Hooks Class Initialized
DEBUG - 2023-10-23 17:41:11 --> UTF-8 Support Enabled
INFO - 2023-10-23 17:41:11 --> Utf8 Class Initialized
INFO - 2023-10-23 17:41:11 --> URI Class Initialized
DEBUG - 2023-10-23 17:41:11 --> No URI present. Default controller set.
INFO - 2023-10-23 17:41:11 --> Router Class Initialized
INFO - 2023-10-23 17:41:11 --> Output Class Initialized
INFO - 2023-10-23 17:41:11 --> Security Class Initialized
DEBUG - 2023-10-23 17:41:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-23 17:41:11 --> Input Class Initialized
INFO - 2023-10-23 17:41:11 --> Language Class Initialized
INFO - 2023-10-23 17:41:11 --> Loader Class Initialized
INFO - 2023-10-23 17:41:11 --> Helper loaded: url_helper
INFO - 2023-10-23 17:41:11 --> Helper loaded: file_helper
INFO - 2023-10-23 17:41:11 --> Helper loaded: html_helper
INFO - 2023-10-23 17:41:11 --> Helper loaded: text_helper
INFO - 2023-10-23 17:41:11 --> Helper loaded: form_helper
INFO - 2023-10-23 17:41:11 --> Helper loaded: lang_helper
INFO - 2023-10-23 17:41:11 --> Helper loaded: security_helper
INFO - 2023-10-23 17:41:11 --> Helper loaded: cookie_helper
INFO - 2023-10-23 17:41:11 --> Database Driver Class Initialized
INFO - 2023-10-23 17:41:11 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-23 17:41:11 --> Parser Class Initialized
INFO - 2023-10-23 17:41:11 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-23 17:41:11 --> Pagination Class Initialized
INFO - 2023-10-23 17:41:11 --> Form Validation Class Initialized
INFO - 2023-10-23 17:41:11 --> Controller Class Initialized
INFO - 2023-10-23 17:41:11 --> Model Class Initialized
DEBUG - 2023-10-23 17:41:11 --> Session class already loaded. Second attempt ignored.
ERROR - 2023-10-23 17:41:12 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-23 17:41:12 --> Config Class Initialized
INFO - 2023-10-23 17:41:12 --> Hooks Class Initialized
DEBUG - 2023-10-23 17:41:12 --> UTF-8 Support Enabled
INFO - 2023-10-23 17:41:12 --> Utf8 Class Initialized
INFO - 2023-10-23 17:41:12 --> URI Class Initialized
INFO - 2023-10-23 17:41:12 --> Router Class Initialized
INFO - 2023-10-23 17:41:12 --> Output Class Initialized
INFO - 2023-10-23 17:41:12 --> Security Class Initialized
DEBUG - 2023-10-23 17:41:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-23 17:41:12 --> Input Class Initialized
INFO - 2023-10-23 17:41:12 --> Language Class Initialized
INFO - 2023-10-23 17:41:12 --> Loader Class Initialized
INFO - 2023-10-23 17:41:12 --> Helper loaded: url_helper
INFO - 2023-10-23 17:41:12 --> Helper loaded: file_helper
INFO - 2023-10-23 17:41:12 --> Helper loaded: html_helper
INFO - 2023-10-23 17:41:12 --> Helper loaded: text_helper
INFO - 2023-10-23 17:41:12 --> Helper loaded: form_helper
INFO - 2023-10-23 17:41:12 --> Helper loaded: lang_helper
INFO - 2023-10-23 17:41:12 --> Helper loaded: security_helper
INFO - 2023-10-23 17:41:12 --> Helper loaded: cookie_helper
INFO - 2023-10-23 17:41:12 --> Database Driver Class Initialized
INFO - 2023-10-23 17:41:12 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-23 17:41:12 --> Parser Class Initialized
INFO - 2023-10-23 17:41:12 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-23 17:41:12 --> Pagination Class Initialized
INFO - 2023-10-23 17:41:12 --> Form Validation Class Initialized
INFO - 2023-10-23 17:41:12 --> Controller Class Initialized
INFO - 2023-10-23 17:41:12 --> Model Class Initialized
DEBUG - 2023-10-23 17:41:12 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-23 17:41:12 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2023-10-23 17:41:12 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-10-23 17:41:12 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-10-23 17:41:12 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-10-23 17:41:12 --> Model Class Initialized
INFO - 2023-10-23 17:41:12 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-10-23 17:41:12 --> Final output sent to browser
DEBUG - 2023-10-23 17:41:12 --> Total execution time: 0.0312
ERROR - 2023-10-23 17:41:17 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-23 17:41:17 --> Config Class Initialized
INFO - 2023-10-23 17:41:17 --> Hooks Class Initialized
DEBUG - 2023-10-23 17:41:17 --> UTF-8 Support Enabled
INFO - 2023-10-23 17:41:17 --> Utf8 Class Initialized
INFO - 2023-10-23 17:41:17 --> URI Class Initialized
INFO - 2023-10-23 17:41:17 --> Router Class Initialized
INFO - 2023-10-23 17:41:17 --> Output Class Initialized
INFO - 2023-10-23 17:41:17 --> Security Class Initialized
DEBUG - 2023-10-23 17:41:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-23 17:41:17 --> Input Class Initialized
INFO - 2023-10-23 17:41:17 --> Language Class Initialized
INFO - 2023-10-23 17:41:17 --> Loader Class Initialized
INFO - 2023-10-23 17:41:17 --> Helper loaded: url_helper
INFO - 2023-10-23 17:41:17 --> Helper loaded: file_helper
INFO - 2023-10-23 17:41:17 --> Helper loaded: html_helper
INFO - 2023-10-23 17:41:17 --> Helper loaded: text_helper
INFO - 2023-10-23 17:41:17 --> Helper loaded: form_helper
INFO - 2023-10-23 17:41:17 --> Helper loaded: lang_helper
INFO - 2023-10-23 17:41:17 --> Helper loaded: security_helper
INFO - 2023-10-23 17:41:17 --> Helper loaded: cookie_helper
INFO - 2023-10-23 17:41:17 --> Database Driver Class Initialized
INFO - 2023-10-23 17:41:17 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-23 17:41:17 --> Parser Class Initialized
INFO - 2023-10-23 17:41:17 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-23 17:41:17 --> Pagination Class Initialized
INFO - 2023-10-23 17:41:17 --> Form Validation Class Initialized
INFO - 2023-10-23 17:41:17 --> Controller Class Initialized
INFO - 2023-10-23 17:41:17 --> Model Class Initialized
DEBUG - 2023-10-23 17:41:17 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-23 17:41:17 --> Model Class Initialized
INFO - 2023-10-23 17:41:17 --> Final output sent to browser
DEBUG - 2023-10-23 17:41:17 --> Total execution time: 0.0187
ERROR - 2023-10-23 17:41:17 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-23 17:41:17 --> Config Class Initialized
INFO - 2023-10-23 17:41:17 --> Hooks Class Initialized
DEBUG - 2023-10-23 17:41:17 --> UTF-8 Support Enabled
INFO - 2023-10-23 17:41:17 --> Utf8 Class Initialized
INFO - 2023-10-23 17:41:17 --> URI Class Initialized
DEBUG - 2023-10-23 17:41:17 --> No URI present. Default controller set.
INFO - 2023-10-23 17:41:17 --> Router Class Initialized
INFO - 2023-10-23 17:41:17 --> Output Class Initialized
INFO - 2023-10-23 17:41:17 --> Security Class Initialized
DEBUG - 2023-10-23 17:41:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-23 17:41:17 --> Input Class Initialized
INFO - 2023-10-23 17:41:17 --> Language Class Initialized
INFO - 2023-10-23 17:41:17 --> Loader Class Initialized
INFO - 2023-10-23 17:41:17 --> Helper loaded: url_helper
INFO - 2023-10-23 17:41:17 --> Helper loaded: file_helper
INFO - 2023-10-23 17:41:17 --> Helper loaded: html_helper
INFO - 2023-10-23 17:41:17 --> Helper loaded: text_helper
INFO - 2023-10-23 17:41:17 --> Helper loaded: form_helper
INFO - 2023-10-23 17:41:17 --> Helper loaded: lang_helper
INFO - 2023-10-23 17:41:17 --> Helper loaded: security_helper
INFO - 2023-10-23 17:41:17 --> Helper loaded: cookie_helper
INFO - 2023-10-23 17:41:17 --> Database Driver Class Initialized
INFO - 2023-10-23 17:41:17 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-23 17:41:17 --> Parser Class Initialized
INFO - 2023-10-23 17:41:17 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-23 17:41:17 --> Pagination Class Initialized
INFO - 2023-10-23 17:41:17 --> Form Validation Class Initialized
INFO - 2023-10-23 17:41:17 --> Controller Class Initialized
INFO - 2023-10-23 17:41:17 --> Model Class Initialized
DEBUG - 2023-10-23 17:41:17 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-23 17:41:17 --> Model Class Initialized
DEBUG - 2023-10-23 17:41:17 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-23 17:41:17 --> Model Class Initialized
INFO - 2023-10-23 17:41:17 --> Model Class Initialized
INFO - 2023-10-23 17:41:17 --> Model Class Initialized
INFO - 2023-10-23 17:41:17 --> Model Class Initialized
DEBUG - 2023-10-23 17:41:17 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-10-23 17:41:17 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-23 17:41:17 --> Model Class Initialized
INFO - 2023-10-23 17:41:17 --> Model Class Initialized
INFO - 2023-10-23 17:41:18 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-10-23 17:41:18 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-10-23 17:41:18 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-10-23 17:41:18 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-10-23 17:41:18 --> Model Class Initialized
INFO - 2023-10-23 17:41:18 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-10-23 17:41:18 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-10-23 17:41:18 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-10-23 17:41:18 --> Final output sent to browser
DEBUG - 2023-10-23 17:41:18 --> Total execution time: 0.3649
ERROR - 2023-10-23 17:41:20 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-23 17:41:20 --> Config Class Initialized
INFO - 2023-10-23 17:41:20 --> Hooks Class Initialized
DEBUG - 2023-10-23 17:41:20 --> UTF-8 Support Enabled
INFO - 2023-10-23 17:41:20 --> Utf8 Class Initialized
INFO - 2023-10-23 17:41:20 --> URI Class Initialized
INFO - 2023-10-23 17:41:20 --> Router Class Initialized
INFO - 2023-10-23 17:41:20 --> Output Class Initialized
INFO - 2023-10-23 17:41:20 --> Security Class Initialized
DEBUG - 2023-10-23 17:41:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-23 17:41:20 --> Input Class Initialized
INFO - 2023-10-23 17:41:20 --> Language Class Initialized
INFO - 2023-10-23 17:41:20 --> Loader Class Initialized
INFO - 2023-10-23 17:41:20 --> Helper loaded: url_helper
INFO - 2023-10-23 17:41:20 --> Helper loaded: file_helper
INFO - 2023-10-23 17:41:20 --> Helper loaded: html_helper
INFO - 2023-10-23 17:41:20 --> Helper loaded: text_helper
INFO - 2023-10-23 17:41:20 --> Helper loaded: form_helper
INFO - 2023-10-23 17:41:20 --> Helper loaded: lang_helper
INFO - 2023-10-23 17:41:20 --> Helper loaded: security_helper
INFO - 2023-10-23 17:41:20 --> Helper loaded: cookie_helper
INFO - 2023-10-23 17:41:20 --> Database Driver Class Initialized
INFO - 2023-10-23 17:41:20 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-23 17:41:20 --> Parser Class Initialized
INFO - 2023-10-23 17:41:20 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-23 17:41:20 --> Pagination Class Initialized
INFO - 2023-10-23 17:41:20 --> Form Validation Class Initialized
INFO - 2023-10-23 17:41:20 --> Controller Class Initialized
DEBUG - 2023-10-23 17:41:20 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-10-23 17:41:20 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-23 17:41:20 --> Model Class Initialized
INFO - 2023-10-23 17:41:20 --> Final output sent to browser
DEBUG - 2023-10-23 17:41:20 --> Total execution time: 0.0138
ERROR - 2023-10-23 17:41:29 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-23 17:41:29 --> Config Class Initialized
INFO - 2023-10-23 17:41:29 --> Hooks Class Initialized
DEBUG - 2023-10-23 17:41:29 --> UTF-8 Support Enabled
INFO - 2023-10-23 17:41:29 --> Utf8 Class Initialized
INFO - 2023-10-23 17:41:29 --> URI Class Initialized
INFO - 2023-10-23 17:41:29 --> Router Class Initialized
INFO - 2023-10-23 17:41:29 --> Output Class Initialized
INFO - 2023-10-23 17:41:29 --> Security Class Initialized
DEBUG - 2023-10-23 17:41:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-23 17:41:29 --> Input Class Initialized
INFO - 2023-10-23 17:41:29 --> Language Class Initialized
INFO - 2023-10-23 17:41:29 --> Loader Class Initialized
INFO - 2023-10-23 17:41:29 --> Helper loaded: url_helper
INFO - 2023-10-23 17:41:29 --> Helper loaded: file_helper
INFO - 2023-10-23 17:41:29 --> Helper loaded: html_helper
INFO - 2023-10-23 17:41:29 --> Helper loaded: text_helper
INFO - 2023-10-23 17:41:29 --> Helper loaded: form_helper
INFO - 2023-10-23 17:41:29 --> Helper loaded: lang_helper
INFO - 2023-10-23 17:41:29 --> Helper loaded: security_helper
INFO - 2023-10-23 17:41:29 --> Helper loaded: cookie_helper
INFO - 2023-10-23 17:41:29 --> Database Driver Class Initialized
INFO - 2023-10-23 17:41:29 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-23 17:41:29 --> Parser Class Initialized
INFO - 2023-10-23 17:41:29 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-23 17:41:29 --> Pagination Class Initialized
INFO - 2023-10-23 17:41:29 --> Form Validation Class Initialized
INFO - 2023-10-23 17:41:29 --> Controller Class Initialized
INFO - 2023-10-23 17:41:29 --> Model Class Initialized
DEBUG - 2023-10-23 17:41:29 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-10-23 17:41:29 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-23 17:41:29 --> Model Class Initialized
DEBUG - 2023-10-23 17:41:29 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-23 17:41:29 --> Model Class Initialized
INFO - 2023-10-23 17:41:30 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice.php
DEBUG - 2023-10-23 17:41:30 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-10-23 17:41:30 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-10-23 17:41:30 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-10-23 17:41:30 --> Model Class Initialized
INFO - 2023-10-23 17:41:30 --> Model Class Initialized
INFO - 2023-10-23 17:41:30 --> Model Class Initialized
INFO - 2023-10-23 17:41:30 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-10-23 17:41:30 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-10-23 17:41:30 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-10-23 17:41:30 --> Final output sent to browser
DEBUG - 2023-10-23 17:41:30 --> Total execution time: 0.2105
ERROR - 2023-10-23 17:41:32 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-23 17:41:32 --> Config Class Initialized
INFO - 2023-10-23 17:41:32 --> Hooks Class Initialized
DEBUG - 2023-10-23 17:41:32 --> UTF-8 Support Enabled
INFO - 2023-10-23 17:41:32 --> Utf8 Class Initialized
INFO - 2023-10-23 17:41:32 --> URI Class Initialized
INFO - 2023-10-23 17:41:32 --> Router Class Initialized
INFO - 2023-10-23 17:41:32 --> Output Class Initialized
INFO - 2023-10-23 17:41:32 --> Security Class Initialized
DEBUG - 2023-10-23 17:41:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-23 17:41:32 --> Input Class Initialized
INFO - 2023-10-23 17:41:32 --> Language Class Initialized
INFO - 2023-10-23 17:41:32 --> Loader Class Initialized
INFO - 2023-10-23 17:41:32 --> Helper loaded: url_helper
INFO - 2023-10-23 17:41:32 --> Helper loaded: file_helper
INFO - 2023-10-23 17:41:32 --> Helper loaded: html_helper
INFO - 2023-10-23 17:41:32 --> Helper loaded: text_helper
INFO - 2023-10-23 17:41:32 --> Helper loaded: form_helper
INFO - 2023-10-23 17:41:32 --> Helper loaded: lang_helper
INFO - 2023-10-23 17:41:32 --> Helper loaded: security_helper
INFO - 2023-10-23 17:41:32 --> Helper loaded: cookie_helper
INFO - 2023-10-23 17:41:32 --> Database Driver Class Initialized
INFO - 2023-10-23 17:41:32 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-23 17:41:32 --> Parser Class Initialized
INFO - 2023-10-23 17:41:32 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-23 17:41:32 --> Pagination Class Initialized
INFO - 2023-10-23 17:41:32 --> Form Validation Class Initialized
INFO - 2023-10-23 17:41:32 --> Controller Class Initialized
INFO - 2023-10-23 17:41:32 --> Model Class Initialized
DEBUG - 2023-10-23 17:41:32 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-10-23 17:41:32 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-23 17:41:32 --> Model Class Initialized
DEBUG - 2023-10-23 17:41:32 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-23 17:41:32 --> Model Class Initialized
INFO - 2023-10-23 17:41:32 --> Final output sent to browser
DEBUG - 2023-10-23 17:41:32 --> Total execution time: 0.0629
ERROR - 2023-10-23 17:41:44 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-23 17:41:44 --> Config Class Initialized
INFO - 2023-10-23 17:41:44 --> Hooks Class Initialized
DEBUG - 2023-10-23 17:41:44 --> UTF-8 Support Enabled
INFO - 2023-10-23 17:41:44 --> Utf8 Class Initialized
INFO - 2023-10-23 17:41:44 --> URI Class Initialized
INFO - 2023-10-23 17:41:44 --> Router Class Initialized
INFO - 2023-10-23 17:41:44 --> Output Class Initialized
INFO - 2023-10-23 17:41:44 --> Security Class Initialized
DEBUG - 2023-10-23 17:41:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-23 17:41:44 --> Input Class Initialized
INFO - 2023-10-23 17:41:44 --> Language Class Initialized
INFO - 2023-10-23 17:41:44 --> Loader Class Initialized
INFO - 2023-10-23 17:41:44 --> Helper loaded: url_helper
INFO - 2023-10-23 17:41:44 --> Helper loaded: file_helper
INFO - 2023-10-23 17:41:44 --> Helper loaded: html_helper
INFO - 2023-10-23 17:41:44 --> Helper loaded: text_helper
INFO - 2023-10-23 17:41:44 --> Helper loaded: form_helper
INFO - 2023-10-23 17:41:44 --> Helper loaded: lang_helper
INFO - 2023-10-23 17:41:44 --> Helper loaded: security_helper
INFO - 2023-10-23 17:41:44 --> Helper loaded: cookie_helper
INFO - 2023-10-23 17:41:44 --> Database Driver Class Initialized
INFO - 2023-10-23 17:41:44 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-23 17:41:44 --> Parser Class Initialized
INFO - 2023-10-23 17:41:44 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-23 17:41:44 --> Pagination Class Initialized
INFO - 2023-10-23 17:41:44 --> Form Validation Class Initialized
INFO - 2023-10-23 17:41:44 --> Controller Class Initialized
INFO - 2023-10-23 17:41:44 --> Model Class Initialized
DEBUG - 2023-10-23 17:41:44 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-10-23 17:41:44 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-23 17:41:44 --> Model Class Initialized
DEBUG - 2023-10-23 17:41:44 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-23 17:41:44 --> Model Class Initialized
INFO - 2023-10-23 17:41:44 --> Final output sent to browser
DEBUG - 2023-10-23 17:41:44 --> Total execution time: 0.0587
ERROR - 2023-10-23 17:41:45 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-23 17:41:45 --> Config Class Initialized
INFO - 2023-10-23 17:41:45 --> Hooks Class Initialized
DEBUG - 2023-10-23 17:41:45 --> UTF-8 Support Enabled
INFO - 2023-10-23 17:41:45 --> Utf8 Class Initialized
INFO - 2023-10-23 17:41:45 --> URI Class Initialized
INFO - 2023-10-23 17:41:45 --> Router Class Initialized
INFO - 2023-10-23 17:41:45 --> Output Class Initialized
INFO - 2023-10-23 17:41:45 --> Security Class Initialized
DEBUG - 2023-10-23 17:41:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-23 17:41:45 --> Input Class Initialized
INFO - 2023-10-23 17:41:45 --> Language Class Initialized
INFO - 2023-10-23 17:41:45 --> Loader Class Initialized
INFO - 2023-10-23 17:41:45 --> Helper loaded: url_helper
INFO - 2023-10-23 17:41:45 --> Helper loaded: file_helper
INFO - 2023-10-23 17:41:45 --> Helper loaded: html_helper
INFO - 2023-10-23 17:41:45 --> Helper loaded: text_helper
INFO - 2023-10-23 17:41:45 --> Helper loaded: form_helper
INFO - 2023-10-23 17:41:45 --> Helper loaded: lang_helper
INFO - 2023-10-23 17:41:45 --> Helper loaded: security_helper
INFO - 2023-10-23 17:41:45 --> Helper loaded: cookie_helper
INFO - 2023-10-23 17:41:45 --> Database Driver Class Initialized
INFO - 2023-10-23 17:41:45 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-23 17:41:45 --> Parser Class Initialized
INFO - 2023-10-23 17:41:45 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-23 17:41:45 --> Pagination Class Initialized
INFO - 2023-10-23 17:41:45 --> Form Validation Class Initialized
INFO - 2023-10-23 17:41:45 --> Controller Class Initialized
INFO - 2023-10-23 17:41:45 --> Model Class Initialized
DEBUG - 2023-10-23 17:41:45 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-10-23 17:41:45 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-23 17:41:45 --> Model Class Initialized
DEBUG - 2023-10-23 17:41:45 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-23 17:41:45 --> Model Class Initialized
INFO - 2023-10-23 17:41:45 --> Final output sent to browser
DEBUG - 2023-10-23 17:41:45 --> Total execution time: 0.0606
ERROR - 2023-10-23 17:41:52 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-23 17:41:52 --> Config Class Initialized
INFO - 2023-10-23 17:41:52 --> Hooks Class Initialized
DEBUG - 2023-10-23 17:41:52 --> UTF-8 Support Enabled
INFO - 2023-10-23 17:41:52 --> Utf8 Class Initialized
INFO - 2023-10-23 17:41:52 --> URI Class Initialized
INFO - 2023-10-23 17:41:52 --> Router Class Initialized
INFO - 2023-10-23 17:41:52 --> Output Class Initialized
INFO - 2023-10-23 17:41:52 --> Security Class Initialized
DEBUG - 2023-10-23 17:41:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-23 17:41:52 --> Input Class Initialized
INFO - 2023-10-23 17:41:52 --> Language Class Initialized
INFO - 2023-10-23 17:41:52 --> Loader Class Initialized
INFO - 2023-10-23 17:41:52 --> Helper loaded: url_helper
INFO - 2023-10-23 17:41:52 --> Helper loaded: file_helper
INFO - 2023-10-23 17:41:52 --> Helper loaded: html_helper
INFO - 2023-10-23 17:41:52 --> Helper loaded: text_helper
INFO - 2023-10-23 17:41:52 --> Helper loaded: form_helper
INFO - 2023-10-23 17:41:52 --> Helper loaded: lang_helper
INFO - 2023-10-23 17:41:52 --> Helper loaded: security_helper
INFO - 2023-10-23 17:41:52 --> Helper loaded: cookie_helper
INFO - 2023-10-23 17:41:52 --> Database Driver Class Initialized
INFO - 2023-10-23 17:41:52 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-23 17:41:52 --> Parser Class Initialized
INFO - 2023-10-23 17:41:52 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-23 17:41:52 --> Pagination Class Initialized
INFO - 2023-10-23 17:41:52 --> Form Validation Class Initialized
INFO - 2023-10-23 17:41:52 --> Controller Class Initialized
INFO - 2023-10-23 17:41:52 --> Model Class Initialized
DEBUG - 2023-10-23 17:41:52 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-10-23 17:41:52 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-23 17:41:52 --> Model Class Initialized
DEBUG - 2023-10-23 17:41:52 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-23 17:41:52 --> Model Class Initialized
INFO - 2023-10-23 17:41:52 --> Final output sent to browser
DEBUG - 2023-10-23 17:41:52 --> Total execution time: 0.1493
ERROR - 2023-10-23 23:32:00 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-23 23:32:00 --> Config Class Initialized
INFO - 2023-10-23 23:32:00 --> Hooks Class Initialized
DEBUG - 2023-10-23 23:32:00 --> UTF-8 Support Enabled
INFO - 2023-10-23 23:32:00 --> Utf8 Class Initialized
INFO - 2023-10-23 23:32:00 --> URI Class Initialized
INFO - 2023-10-23 23:32:00 --> Router Class Initialized
INFO - 2023-10-23 23:32:00 --> Output Class Initialized
INFO - 2023-10-23 23:32:00 --> Security Class Initialized
DEBUG - 2023-10-23 23:32:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-23 23:32:00 --> Input Class Initialized
INFO - 2023-10-23 23:32:00 --> Language Class Initialized
ERROR - 2023-10-23 23:32:00 --> 404 Page Not Found: Well-known/assetlinks.json
