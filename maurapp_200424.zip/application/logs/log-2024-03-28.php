<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2024-03-28 01:04:07 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-03-28 01:04:07 --> Config Class Initialized
INFO - 2024-03-28 01:04:07 --> Hooks Class Initialized
DEBUG - 2024-03-28 01:04:07 --> UTF-8 Support Enabled
INFO - 2024-03-28 01:04:07 --> Utf8 Class Initialized
INFO - 2024-03-28 01:04:07 --> URI Class Initialized
DEBUG - 2024-03-28 01:04:07 --> No URI present. Default controller set.
INFO - 2024-03-28 01:04:07 --> Router Class Initialized
INFO - 2024-03-28 01:04:07 --> Output Class Initialized
INFO - 2024-03-28 01:04:07 --> Security Class Initialized
DEBUG - 2024-03-28 01:04:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-28 01:04:07 --> Input Class Initialized
INFO - 2024-03-28 01:04:07 --> Language Class Initialized
INFO - 2024-03-28 01:04:07 --> Loader Class Initialized
INFO - 2024-03-28 01:04:07 --> Helper loaded: url_helper
INFO - 2024-03-28 01:04:07 --> Helper loaded: file_helper
INFO - 2024-03-28 01:04:07 --> Helper loaded: html_helper
INFO - 2024-03-28 01:04:07 --> Helper loaded: text_helper
INFO - 2024-03-28 01:04:07 --> Helper loaded: form_helper
INFO - 2024-03-28 01:04:07 --> Helper loaded: lang_helper
INFO - 2024-03-28 01:04:07 --> Helper loaded: security_helper
INFO - 2024-03-28 01:04:07 --> Helper loaded: cookie_helper
INFO - 2024-03-28 01:04:07 --> Database Driver Class Initialized
INFO - 2024-03-28 01:04:07 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-28 01:04:07 --> Parser Class Initialized
INFO - 2024-03-28 01:04:07 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-03-28 01:04:07 --> Pagination Class Initialized
INFO - 2024-03-28 01:04:07 --> Form Validation Class Initialized
INFO - 2024-03-28 01:04:07 --> Controller Class Initialized
INFO - 2024-03-28 01:04:07 --> Model Class Initialized
DEBUG - 2024-03-28 01:04:07 --> Session class already loaded. Second attempt ignored.
ERROR - 2024-03-28 01:04:08 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-03-28 01:04:08 --> Config Class Initialized
INFO - 2024-03-28 01:04:08 --> Hooks Class Initialized
DEBUG - 2024-03-28 01:04:08 --> UTF-8 Support Enabled
INFO - 2024-03-28 01:04:08 --> Utf8 Class Initialized
INFO - 2024-03-28 01:04:08 --> URI Class Initialized
INFO - 2024-03-28 01:04:08 --> Router Class Initialized
INFO - 2024-03-28 01:04:08 --> Output Class Initialized
INFO - 2024-03-28 01:04:08 --> Security Class Initialized
DEBUG - 2024-03-28 01:04:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-28 01:04:08 --> Input Class Initialized
INFO - 2024-03-28 01:04:08 --> Language Class Initialized
INFO - 2024-03-28 01:04:08 --> Loader Class Initialized
INFO - 2024-03-28 01:04:08 --> Helper loaded: url_helper
INFO - 2024-03-28 01:04:08 --> Helper loaded: file_helper
INFO - 2024-03-28 01:04:08 --> Helper loaded: html_helper
INFO - 2024-03-28 01:04:08 --> Helper loaded: text_helper
INFO - 2024-03-28 01:04:08 --> Helper loaded: form_helper
INFO - 2024-03-28 01:04:08 --> Helper loaded: lang_helper
INFO - 2024-03-28 01:04:08 --> Helper loaded: security_helper
INFO - 2024-03-28 01:04:08 --> Helper loaded: cookie_helper
INFO - 2024-03-28 01:04:08 --> Database Driver Class Initialized
INFO - 2024-03-28 01:04:08 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-28 01:04:08 --> Parser Class Initialized
INFO - 2024-03-28 01:04:08 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-03-28 01:04:08 --> Pagination Class Initialized
INFO - 2024-03-28 01:04:08 --> Form Validation Class Initialized
INFO - 2024-03-28 01:04:08 --> Controller Class Initialized
INFO - 2024-03-28 01:04:08 --> Model Class Initialized
DEBUG - 2024-03-28 01:04:08 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-28 01:04:08 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2024-03-28 01:04:08 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-03-28 01:04:08 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-03-28 01:04:08 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-03-28 01:04:08 --> Model Class Initialized
INFO - 2024-03-28 01:04:08 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-03-28 01:04:08 --> Final output sent to browser
DEBUG - 2024-03-28 01:04:08 --> Total execution time: 0.0343
ERROR - 2024-03-28 08:48:54 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-03-28 08:48:54 --> Config Class Initialized
INFO - 2024-03-28 08:48:54 --> Hooks Class Initialized
DEBUG - 2024-03-28 08:48:54 --> UTF-8 Support Enabled
INFO - 2024-03-28 08:48:54 --> Utf8 Class Initialized
INFO - 2024-03-28 08:48:54 --> URI Class Initialized
DEBUG - 2024-03-28 08:48:54 --> No URI present. Default controller set.
INFO - 2024-03-28 08:48:54 --> Router Class Initialized
INFO - 2024-03-28 08:48:54 --> Output Class Initialized
INFO - 2024-03-28 08:48:54 --> Security Class Initialized
DEBUG - 2024-03-28 08:48:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-28 08:48:54 --> Input Class Initialized
INFO - 2024-03-28 08:48:54 --> Language Class Initialized
INFO - 2024-03-28 08:48:54 --> Loader Class Initialized
INFO - 2024-03-28 08:48:54 --> Helper loaded: url_helper
INFO - 2024-03-28 08:48:54 --> Helper loaded: file_helper
INFO - 2024-03-28 08:48:54 --> Helper loaded: html_helper
INFO - 2024-03-28 08:48:54 --> Helper loaded: text_helper
INFO - 2024-03-28 08:48:54 --> Helper loaded: form_helper
INFO - 2024-03-28 08:48:54 --> Helper loaded: lang_helper
INFO - 2024-03-28 08:48:54 --> Helper loaded: security_helper
INFO - 2024-03-28 08:48:54 --> Helper loaded: cookie_helper
INFO - 2024-03-28 08:48:54 --> Database Driver Class Initialized
INFO - 2024-03-28 08:48:54 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-28 08:48:54 --> Parser Class Initialized
INFO - 2024-03-28 08:48:54 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-03-28 08:48:54 --> Pagination Class Initialized
INFO - 2024-03-28 08:48:54 --> Form Validation Class Initialized
INFO - 2024-03-28 08:48:54 --> Controller Class Initialized
INFO - 2024-03-28 08:48:54 --> Model Class Initialized
DEBUG - 2024-03-28 08:48:54 --> Session class already loaded. Second attempt ignored.
ERROR - 2024-03-28 08:48:54 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-03-28 08:48:54 --> Config Class Initialized
INFO - 2024-03-28 08:48:54 --> Hooks Class Initialized
DEBUG - 2024-03-28 08:48:54 --> UTF-8 Support Enabled
INFO - 2024-03-28 08:48:54 --> Utf8 Class Initialized
INFO - 2024-03-28 08:48:54 --> URI Class Initialized
INFO - 2024-03-28 08:48:54 --> Router Class Initialized
INFO - 2024-03-28 08:48:54 --> Output Class Initialized
INFO - 2024-03-28 08:48:54 --> Security Class Initialized
DEBUG - 2024-03-28 08:48:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-28 08:48:54 --> Input Class Initialized
INFO - 2024-03-28 08:48:54 --> Language Class Initialized
INFO - 2024-03-28 08:48:54 --> Loader Class Initialized
INFO - 2024-03-28 08:48:54 --> Helper loaded: url_helper
INFO - 2024-03-28 08:48:54 --> Helper loaded: file_helper
INFO - 2024-03-28 08:48:54 --> Helper loaded: html_helper
INFO - 2024-03-28 08:48:54 --> Helper loaded: text_helper
INFO - 2024-03-28 08:48:54 --> Helper loaded: form_helper
INFO - 2024-03-28 08:48:54 --> Helper loaded: lang_helper
INFO - 2024-03-28 08:48:54 --> Helper loaded: security_helper
INFO - 2024-03-28 08:48:54 --> Helper loaded: cookie_helper
INFO - 2024-03-28 08:48:54 --> Database Driver Class Initialized
INFO - 2024-03-28 08:48:54 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-28 08:48:54 --> Parser Class Initialized
INFO - 2024-03-28 08:48:54 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-03-28 08:48:54 --> Pagination Class Initialized
INFO - 2024-03-28 08:48:54 --> Form Validation Class Initialized
INFO - 2024-03-28 08:48:54 --> Controller Class Initialized
INFO - 2024-03-28 08:48:54 --> Model Class Initialized
DEBUG - 2024-03-28 08:48:54 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-28 08:48:54 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2024-03-28 08:48:54 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-03-28 08:48:54 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-03-28 08:48:54 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-03-28 08:48:54 --> Model Class Initialized
INFO - 2024-03-28 08:48:54 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-03-28 08:48:54 --> Final output sent to browser
DEBUG - 2024-03-28 08:48:54 --> Total execution time: 0.0349
ERROR - 2024-03-28 08:49:14 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-03-28 08:49:14 --> Config Class Initialized
INFO - 2024-03-28 08:49:14 --> Hooks Class Initialized
DEBUG - 2024-03-28 08:49:14 --> UTF-8 Support Enabled
INFO - 2024-03-28 08:49:14 --> Utf8 Class Initialized
INFO - 2024-03-28 08:49:14 --> URI Class Initialized
INFO - 2024-03-28 08:49:14 --> Router Class Initialized
INFO - 2024-03-28 08:49:14 --> Output Class Initialized
INFO - 2024-03-28 08:49:14 --> Security Class Initialized
DEBUG - 2024-03-28 08:49:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-28 08:49:14 --> Input Class Initialized
INFO - 2024-03-28 08:49:14 --> Language Class Initialized
INFO - 2024-03-28 08:49:14 --> Loader Class Initialized
INFO - 2024-03-28 08:49:14 --> Helper loaded: url_helper
INFO - 2024-03-28 08:49:14 --> Helper loaded: file_helper
INFO - 2024-03-28 08:49:14 --> Helper loaded: html_helper
INFO - 2024-03-28 08:49:14 --> Helper loaded: text_helper
INFO - 2024-03-28 08:49:14 --> Helper loaded: form_helper
INFO - 2024-03-28 08:49:14 --> Helper loaded: lang_helper
INFO - 2024-03-28 08:49:14 --> Helper loaded: security_helper
INFO - 2024-03-28 08:49:14 --> Helper loaded: cookie_helper
INFO - 2024-03-28 08:49:14 --> Database Driver Class Initialized
INFO - 2024-03-28 08:49:14 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-28 08:49:14 --> Parser Class Initialized
INFO - 2024-03-28 08:49:14 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-03-28 08:49:14 --> Pagination Class Initialized
INFO - 2024-03-28 08:49:14 --> Form Validation Class Initialized
INFO - 2024-03-28 08:49:14 --> Controller Class Initialized
INFO - 2024-03-28 08:49:14 --> Model Class Initialized
DEBUG - 2024-03-28 08:49:14 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-28 08:49:14 --> Model Class Initialized
INFO - 2024-03-28 08:49:14 --> Final output sent to browser
DEBUG - 2024-03-28 08:49:14 --> Total execution time: 0.0214
ERROR - 2024-03-28 08:49:14 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-03-28 08:49:14 --> Config Class Initialized
INFO - 2024-03-28 08:49:14 --> Hooks Class Initialized
DEBUG - 2024-03-28 08:49:14 --> UTF-8 Support Enabled
INFO - 2024-03-28 08:49:14 --> Utf8 Class Initialized
INFO - 2024-03-28 08:49:14 --> URI Class Initialized
DEBUG - 2024-03-28 08:49:14 --> No URI present. Default controller set.
INFO - 2024-03-28 08:49:14 --> Router Class Initialized
INFO - 2024-03-28 08:49:14 --> Output Class Initialized
INFO - 2024-03-28 08:49:14 --> Security Class Initialized
DEBUG - 2024-03-28 08:49:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-28 08:49:14 --> Input Class Initialized
INFO - 2024-03-28 08:49:14 --> Language Class Initialized
INFO - 2024-03-28 08:49:14 --> Loader Class Initialized
INFO - 2024-03-28 08:49:14 --> Helper loaded: url_helper
INFO - 2024-03-28 08:49:14 --> Helper loaded: file_helper
INFO - 2024-03-28 08:49:14 --> Helper loaded: html_helper
INFO - 2024-03-28 08:49:14 --> Helper loaded: text_helper
INFO - 2024-03-28 08:49:14 --> Helper loaded: form_helper
INFO - 2024-03-28 08:49:14 --> Helper loaded: lang_helper
INFO - 2024-03-28 08:49:14 --> Helper loaded: security_helper
INFO - 2024-03-28 08:49:14 --> Helper loaded: cookie_helper
INFO - 2024-03-28 08:49:14 --> Database Driver Class Initialized
INFO - 2024-03-28 08:49:14 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-28 08:49:14 --> Parser Class Initialized
INFO - 2024-03-28 08:49:14 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-03-28 08:49:14 --> Pagination Class Initialized
INFO - 2024-03-28 08:49:14 --> Form Validation Class Initialized
INFO - 2024-03-28 08:49:14 --> Controller Class Initialized
INFO - 2024-03-28 08:49:14 --> Model Class Initialized
DEBUG - 2024-03-28 08:49:14 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-28 08:49:14 --> Model Class Initialized
DEBUG - 2024-03-28 08:49:14 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-28 08:49:14 --> Model Class Initialized
INFO - 2024-03-28 08:49:14 --> Model Class Initialized
INFO - 2024-03-28 08:49:14 --> Model Class Initialized
INFO - 2024-03-28 08:49:14 --> Model Class Initialized
DEBUG - 2024-03-28 08:49:14 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-03-28 08:49:14 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-28 08:49:14 --> Model Class Initialized
INFO - 2024-03-28 08:49:14 --> Model Class Initialized
INFO - 2024-03-28 08:49:15 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2024-03-28 08:49:15 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-03-28 08:49:15 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-03-28 08:49:15 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-03-28 08:49:15 --> Model Class Initialized
INFO - 2024-03-28 08:49:15 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-03-28 08:49:15 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-03-28 08:49:15 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-03-28 08:49:15 --> Final output sent to browser
DEBUG - 2024-03-28 08:49:15 --> Total execution time: 0.2550
ERROR - 2024-03-28 08:49:33 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-03-28 08:49:33 --> Config Class Initialized
INFO - 2024-03-28 08:49:33 --> Hooks Class Initialized
DEBUG - 2024-03-28 08:49:33 --> UTF-8 Support Enabled
INFO - 2024-03-28 08:49:33 --> Utf8 Class Initialized
INFO - 2024-03-28 08:49:33 --> URI Class Initialized
INFO - 2024-03-28 08:49:33 --> Router Class Initialized
INFO - 2024-03-28 08:49:33 --> Output Class Initialized
INFO - 2024-03-28 08:49:33 --> Security Class Initialized
DEBUG - 2024-03-28 08:49:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-28 08:49:33 --> Input Class Initialized
INFO - 2024-03-28 08:49:33 --> Language Class Initialized
INFO - 2024-03-28 08:49:33 --> Loader Class Initialized
INFO - 2024-03-28 08:49:33 --> Helper loaded: url_helper
INFO - 2024-03-28 08:49:33 --> Helper loaded: file_helper
INFO - 2024-03-28 08:49:33 --> Helper loaded: html_helper
INFO - 2024-03-28 08:49:33 --> Helper loaded: text_helper
INFO - 2024-03-28 08:49:33 --> Helper loaded: form_helper
INFO - 2024-03-28 08:49:33 --> Helper loaded: lang_helper
INFO - 2024-03-28 08:49:33 --> Helper loaded: security_helper
INFO - 2024-03-28 08:49:33 --> Helper loaded: cookie_helper
INFO - 2024-03-28 08:49:33 --> Database Driver Class Initialized
INFO - 2024-03-28 08:49:33 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-28 08:49:33 --> Parser Class Initialized
INFO - 2024-03-28 08:49:33 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-03-28 08:49:33 --> Pagination Class Initialized
INFO - 2024-03-28 08:49:33 --> Form Validation Class Initialized
INFO - 2024-03-28 08:49:33 --> Controller Class Initialized
INFO - 2024-03-28 08:49:33 --> Model Class Initialized
DEBUG - 2024-03-28 08:49:33 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-03-28 08:49:33 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-28 08:49:33 --> Model Class Initialized
DEBUG - 2024-03-28 08:49:33 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-28 08:49:33 --> Model Class Initialized
INFO - 2024-03-28 08:49:33 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/add_invoice_form.php
DEBUG - 2024-03-28 08:49:33 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-03-28 08:49:33 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-03-28 08:49:33 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-03-28 08:49:33 --> Model Class Initialized
INFO - 2024-03-28 08:49:33 --> Model Class Initialized
INFO - 2024-03-28 08:49:33 --> Model Class Initialized
INFO - 2024-03-28 08:49:33 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-03-28 08:49:33 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-03-28 08:49:33 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-03-28 08:49:33 --> Final output sent to browser
DEBUG - 2024-03-28 08:49:33 --> Total execution time: 0.2036
ERROR - 2024-03-28 08:49:40 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-03-28 08:49:40 --> Config Class Initialized
INFO - 2024-03-28 08:49:40 --> Hooks Class Initialized
DEBUG - 2024-03-28 08:49:40 --> UTF-8 Support Enabled
INFO - 2024-03-28 08:49:40 --> Utf8 Class Initialized
INFO - 2024-03-28 08:49:40 --> URI Class Initialized
INFO - 2024-03-28 08:49:40 --> Router Class Initialized
INFO - 2024-03-28 08:49:40 --> Output Class Initialized
INFO - 2024-03-28 08:49:40 --> Security Class Initialized
DEBUG - 2024-03-28 08:49:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-28 08:49:40 --> Input Class Initialized
INFO - 2024-03-28 08:49:40 --> Language Class Initialized
INFO - 2024-03-28 08:49:40 --> Loader Class Initialized
INFO - 2024-03-28 08:49:40 --> Helper loaded: url_helper
INFO - 2024-03-28 08:49:40 --> Helper loaded: file_helper
INFO - 2024-03-28 08:49:40 --> Helper loaded: html_helper
INFO - 2024-03-28 08:49:40 --> Helper loaded: text_helper
INFO - 2024-03-28 08:49:40 --> Helper loaded: form_helper
INFO - 2024-03-28 08:49:40 --> Helper loaded: lang_helper
INFO - 2024-03-28 08:49:40 --> Helper loaded: security_helper
INFO - 2024-03-28 08:49:40 --> Helper loaded: cookie_helper
INFO - 2024-03-28 08:49:40 --> Database Driver Class Initialized
INFO - 2024-03-28 08:49:40 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-28 08:49:40 --> Parser Class Initialized
INFO - 2024-03-28 08:49:40 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-03-28 08:49:40 --> Pagination Class Initialized
INFO - 2024-03-28 08:49:40 --> Form Validation Class Initialized
INFO - 2024-03-28 08:49:40 --> Controller Class Initialized
INFO - 2024-03-28 08:49:40 --> Model Class Initialized
DEBUG - 2024-03-28 08:49:40 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-28 08:49:40 --> Final output sent to browser
DEBUG - 2024-03-28 08:49:40 --> Total execution time: 0.0159
ERROR - 2024-03-28 08:49:41 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-03-28 08:49:41 --> Config Class Initialized
INFO - 2024-03-28 08:49:41 --> Hooks Class Initialized
DEBUG - 2024-03-28 08:49:41 --> UTF-8 Support Enabled
INFO - 2024-03-28 08:49:41 --> Utf8 Class Initialized
INFO - 2024-03-28 08:49:41 --> URI Class Initialized
INFO - 2024-03-28 08:49:41 --> Router Class Initialized
INFO - 2024-03-28 08:49:41 --> Output Class Initialized
INFO - 2024-03-28 08:49:41 --> Security Class Initialized
DEBUG - 2024-03-28 08:49:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-28 08:49:41 --> Input Class Initialized
INFO - 2024-03-28 08:49:41 --> Language Class Initialized
INFO - 2024-03-28 08:49:41 --> Loader Class Initialized
INFO - 2024-03-28 08:49:41 --> Helper loaded: url_helper
INFO - 2024-03-28 08:49:41 --> Helper loaded: file_helper
INFO - 2024-03-28 08:49:41 --> Helper loaded: html_helper
INFO - 2024-03-28 08:49:41 --> Helper loaded: text_helper
INFO - 2024-03-28 08:49:41 --> Helper loaded: form_helper
INFO - 2024-03-28 08:49:41 --> Helper loaded: lang_helper
INFO - 2024-03-28 08:49:41 --> Helper loaded: security_helper
INFO - 2024-03-28 08:49:41 --> Helper loaded: cookie_helper
INFO - 2024-03-28 08:49:41 --> Database Driver Class Initialized
INFO - 2024-03-28 08:49:41 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-28 08:49:41 --> Parser Class Initialized
INFO - 2024-03-28 08:49:41 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-03-28 08:49:41 --> Pagination Class Initialized
INFO - 2024-03-28 08:49:41 --> Form Validation Class Initialized
INFO - 2024-03-28 08:49:41 --> Controller Class Initialized
INFO - 2024-03-28 08:49:41 --> Model Class Initialized
DEBUG - 2024-03-28 08:49:41 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-28 08:49:41 --> Final output sent to browser
DEBUG - 2024-03-28 08:49:41 --> Total execution time: 0.0146
ERROR - 2024-03-28 08:49:42 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-03-28 08:49:42 --> Config Class Initialized
INFO - 2024-03-28 08:49:42 --> Hooks Class Initialized
DEBUG - 2024-03-28 08:49:42 --> UTF-8 Support Enabled
INFO - 2024-03-28 08:49:42 --> Utf8 Class Initialized
INFO - 2024-03-28 08:49:42 --> URI Class Initialized
INFO - 2024-03-28 08:49:42 --> Router Class Initialized
INFO - 2024-03-28 08:49:42 --> Output Class Initialized
INFO - 2024-03-28 08:49:42 --> Security Class Initialized
DEBUG - 2024-03-28 08:49:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-28 08:49:42 --> Input Class Initialized
INFO - 2024-03-28 08:49:42 --> Language Class Initialized
INFO - 2024-03-28 08:49:42 --> Loader Class Initialized
INFO - 2024-03-28 08:49:42 --> Helper loaded: url_helper
INFO - 2024-03-28 08:49:42 --> Helper loaded: file_helper
INFO - 2024-03-28 08:49:42 --> Helper loaded: html_helper
INFO - 2024-03-28 08:49:42 --> Helper loaded: text_helper
INFO - 2024-03-28 08:49:42 --> Helper loaded: form_helper
INFO - 2024-03-28 08:49:42 --> Helper loaded: lang_helper
INFO - 2024-03-28 08:49:42 --> Helper loaded: security_helper
INFO - 2024-03-28 08:49:42 --> Helper loaded: cookie_helper
INFO - 2024-03-28 08:49:42 --> Database Driver Class Initialized
INFO - 2024-03-28 08:49:42 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-28 08:49:42 --> Parser Class Initialized
INFO - 2024-03-28 08:49:42 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-03-28 08:49:42 --> Pagination Class Initialized
INFO - 2024-03-28 08:49:42 --> Form Validation Class Initialized
INFO - 2024-03-28 08:49:42 --> Controller Class Initialized
INFO - 2024-03-28 08:49:42 --> Model Class Initialized
DEBUG - 2024-03-28 08:49:42 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-28 08:49:42 --> Final output sent to browser
DEBUG - 2024-03-28 08:49:42 --> Total execution time: 0.0153
ERROR - 2024-03-28 08:49:46 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-03-28 08:49:46 --> Config Class Initialized
INFO - 2024-03-28 08:49:46 --> Hooks Class Initialized
DEBUG - 2024-03-28 08:49:46 --> UTF-8 Support Enabled
INFO - 2024-03-28 08:49:46 --> Utf8 Class Initialized
INFO - 2024-03-28 08:49:46 --> URI Class Initialized
INFO - 2024-03-28 08:49:46 --> Router Class Initialized
INFO - 2024-03-28 08:49:46 --> Output Class Initialized
INFO - 2024-03-28 08:49:46 --> Security Class Initialized
DEBUG - 2024-03-28 08:49:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-28 08:49:46 --> Input Class Initialized
INFO - 2024-03-28 08:49:46 --> Language Class Initialized
INFO - 2024-03-28 08:49:46 --> Loader Class Initialized
INFO - 2024-03-28 08:49:46 --> Helper loaded: url_helper
INFO - 2024-03-28 08:49:46 --> Helper loaded: file_helper
INFO - 2024-03-28 08:49:46 --> Helper loaded: html_helper
INFO - 2024-03-28 08:49:46 --> Helper loaded: text_helper
INFO - 2024-03-28 08:49:46 --> Helper loaded: form_helper
INFO - 2024-03-28 08:49:46 --> Helper loaded: lang_helper
INFO - 2024-03-28 08:49:46 --> Helper loaded: security_helper
INFO - 2024-03-28 08:49:46 --> Helper loaded: cookie_helper
INFO - 2024-03-28 08:49:46 --> Database Driver Class Initialized
INFO - 2024-03-28 08:49:46 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-28 08:49:46 --> Parser Class Initialized
INFO - 2024-03-28 08:49:46 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-03-28 08:49:46 --> Pagination Class Initialized
INFO - 2024-03-28 08:49:46 --> Form Validation Class Initialized
INFO - 2024-03-28 08:49:46 --> Controller Class Initialized
INFO - 2024-03-28 08:49:46 --> Final output sent to browser
DEBUG - 2024-03-28 08:49:46 --> Total execution time: 0.0131
ERROR - 2024-03-28 08:49:55 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-03-28 08:49:55 --> Config Class Initialized
INFO - 2024-03-28 08:49:55 --> Hooks Class Initialized
DEBUG - 2024-03-28 08:49:55 --> UTF-8 Support Enabled
INFO - 2024-03-28 08:49:55 --> Utf8 Class Initialized
INFO - 2024-03-28 08:49:55 --> URI Class Initialized
INFO - 2024-03-28 08:49:55 --> Router Class Initialized
INFO - 2024-03-28 08:49:55 --> Output Class Initialized
INFO - 2024-03-28 08:49:55 --> Security Class Initialized
DEBUG - 2024-03-28 08:49:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-28 08:49:55 --> Input Class Initialized
INFO - 2024-03-28 08:49:55 --> Language Class Initialized
INFO - 2024-03-28 08:49:55 --> Loader Class Initialized
INFO - 2024-03-28 08:49:55 --> Helper loaded: url_helper
INFO - 2024-03-28 08:49:55 --> Helper loaded: file_helper
INFO - 2024-03-28 08:49:55 --> Helper loaded: html_helper
INFO - 2024-03-28 08:49:55 --> Helper loaded: text_helper
INFO - 2024-03-28 08:49:55 --> Helper loaded: form_helper
INFO - 2024-03-28 08:49:55 --> Helper loaded: lang_helper
INFO - 2024-03-28 08:49:55 --> Helper loaded: security_helper
INFO - 2024-03-28 08:49:55 --> Helper loaded: cookie_helper
INFO - 2024-03-28 08:49:55 --> Database Driver Class Initialized
INFO - 2024-03-28 08:49:55 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-28 08:49:55 --> Parser Class Initialized
INFO - 2024-03-28 08:49:55 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-03-28 08:49:55 --> Pagination Class Initialized
INFO - 2024-03-28 08:49:55 --> Form Validation Class Initialized
INFO - 2024-03-28 08:49:55 --> Controller Class Initialized
INFO - 2024-03-28 08:49:55 --> Model Class Initialized
DEBUG - 2024-03-28 08:49:55 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-03-28 08:49:55 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-28 08:49:55 --> Model Class Initialized
DEBUG - 2024-03-28 08:49:55 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-28 08:49:55 --> Model Class Initialized
INFO - 2024-03-28 08:49:55 --> Final output sent to browser
DEBUG - 2024-03-28 08:49:55 --> Total execution time: 0.2217
ERROR - 2024-03-28 08:49:56 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-03-28 08:49:56 --> Config Class Initialized
INFO - 2024-03-28 08:49:56 --> Hooks Class Initialized
DEBUG - 2024-03-28 08:49:56 --> UTF-8 Support Enabled
INFO - 2024-03-28 08:49:56 --> Utf8 Class Initialized
INFO - 2024-03-28 08:49:56 --> URI Class Initialized
INFO - 2024-03-28 08:49:56 --> Router Class Initialized
INFO - 2024-03-28 08:49:56 --> Output Class Initialized
INFO - 2024-03-28 08:49:56 --> Security Class Initialized
DEBUG - 2024-03-28 08:49:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-28 08:49:56 --> Input Class Initialized
INFO - 2024-03-28 08:49:56 --> Language Class Initialized
INFO - 2024-03-28 08:49:56 --> Loader Class Initialized
INFO - 2024-03-28 08:49:56 --> Helper loaded: url_helper
INFO - 2024-03-28 08:49:56 --> Helper loaded: file_helper
INFO - 2024-03-28 08:49:56 --> Helper loaded: html_helper
INFO - 2024-03-28 08:49:56 --> Helper loaded: text_helper
INFO - 2024-03-28 08:49:56 --> Helper loaded: form_helper
INFO - 2024-03-28 08:49:56 --> Helper loaded: lang_helper
INFO - 2024-03-28 08:49:56 --> Helper loaded: security_helper
INFO - 2024-03-28 08:49:56 --> Helper loaded: cookie_helper
INFO - 2024-03-28 08:49:56 --> Database Driver Class Initialized
INFO - 2024-03-28 08:49:56 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-28 08:49:56 --> Parser Class Initialized
INFO - 2024-03-28 08:49:56 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-03-28 08:49:56 --> Pagination Class Initialized
INFO - 2024-03-28 08:49:56 --> Form Validation Class Initialized
INFO - 2024-03-28 08:49:56 --> Controller Class Initialized
INFO - 2024-03-28 08:49:56 --> Model Class Initialized
DEBUG - 2024-03-28 08:49:56 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-03-28 08:49:56 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-28 08:49:56 --> Model Class Initialized
DEBUG - 2024-03-28 08:49:56 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-28 08:49:56 --> Model Class Initialized
INFO - 2024-03-28 08:49:56 --> Final output sent to browser
DEBUG - 2024-03-28 08:49:56 --> Total execution time: 0.0179
ERROR - 2024-03-28 08:49:57 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-03-28 08:49:57 --> Config Class Initialized
INFO - 2024-03-28 08:49:57 --> Hooks Class Initialized
DEBUG - 2024-03-28 08:49:57 --> UTF-8 Support Enabled
INFO - 2024-03-28 08:49:57 --> Utf8 Class Initialized
INFO - 2024-03-28 08:49:57 --> URI Class Initialized
INFO - 2024-03-28 08:49:57 --> Router Class Initialized
INFO - 2024-03-28 08:49:57 --> Output Class Initialized
INFO - 2024-03-28 08:49:57 --> Security Class Initialized
DEBUG - 2024-03-28 08:49:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-28 08:49:57 --> Input Class Initialized
INFO - 2024-03-28 08:49:57 --> Language Class Initialized
INFO - 2024-03-28 08:49:57 --> Loader Class Initialized
INFO - 2024-03-28 08:49:57 --> Helper loaded: url_helper
INFO - 2024-03-28 08:49:57 --> Helper loaded: file_helper
INFO - 2024-03-28 08:49:57 --> Helper loaded: html_helper
INFO - 2024-03-28 08:49:57 --> Helper loaded: text_helper
INFO - 2024-03-28 08:49:57 --> Helper loaded: form_helper
INFO - 2024-03-28 08:49:57 --> Helper loaded: lang_helper
INFO - 2024-03-28 08:49:57 --> Helper loaded: security_helper
INFO - 2024-03-28 08:49:57 --> Helper loaded: cookie_helper
INFO - 2024-03-28 08:49:57 --> Database Driver Class Initialized
INFO - 2024-03-28 08:49:57 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-28 08:49:57 --> Parser Class Initialized
INFO - 2024-03-28 08:49:57 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-03-28 08:49:57 --> Pagination Class Initialized
INFO - 2024-03-28 08:49:57 --> Form Validation Class Initialized
INFO - 2024-03-28 08:49:57 --> Controller Class Initialized
INFO - 2024-03-28 08:49:57 --> Model Class Initialized
DEBUG - 2024-03-28 08:49:57 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-03-28 08:49:57 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-28 08:49:57 --> Model Class Initialized
DEBUG - 2024-03-28 08:49:57 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-28 08:49:57 --> Model Class Initialized
INFO - 2024-03-28 08:49:57 --> Final output sent to browser
DEBUG - 2024-03-28 08:49:57 --> Total execution time: 0.2111
ERROR - 2024-03-28 08:49:57 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-03-28 08:49:57 --> Config Class Initialized
INFO - 2024-03-28 08:49:57 --> Hooks Class Initialized
DEBUG - 2024-03-28 08:49:57 --> UTF-8 Support Enabled
INFO - 2024-03-28 08:49:57 --> Utf8 Class Initialized
INFO - 2024-03-28 08:49:57 --> URI Class Initialized
INFO - 2024-03-28 08:49:57 --> Router Class Initialized
INFO - 2024-03-28 08:49:57 --> Output Class Initialized
INFO - 2024-03-28 08:49:57 --> Security Class Initialized
DEBUG - 2024-03-28 08:49:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-28 08:49:57 --> Input Class Initialized
INFO - 2024-03-28 08:49:57 --> Language Class Initialized
INFO - 2024-03-28 08:49:57 --> Loader Class Initialized
INFO - 2024-03-28 08:49:57 --> Helper loaded: url_helper
INFO - 2024-03-28 08:49:57 --> Helper loaded: file_helper
INFO - 2024-03-28 08:49:57 --> Helper loaded: html_helper
INFO - 2024-03-28 08:49:57 --> Helper loaded: text_helper
INFO - 2024-03-28 08:49:57 --> Helper loaded: form_helper
INFO - 2024-03-28 08:49:57 --> Helper loaded: lang_helper
INFO - 2024-03-28 08:49:57 --> Helper loaded: security_helper
INFO - 2024-03-28 08:49:57 --> Helper loaded: cookie_helper
INFO - 2024-03-28 08:49:57 --> Database Driver Class Initialized
INFO - 2024-03-28 08:49:57 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-28 08:49:57 --> Parser Class Initialized
INFO - 2024-03-28 08:49:57 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-03-28 08:49:57 --> Pagination Class Initialized
INFO - 2024-03-28 08:49:57 --> Form Validation Class Initialized
INFO - 2024-03-28 08:49:57 --> Controller Class Initialized
INFO - 2024-03-28 08:49:57 --> Model Class Initialized
DEBUG - 2024-03-28 08:49:57 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-03-28 08:49:57 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-28 08:49:57 --> Model Class Initialized
DEBUG - 2024-03-28 08:49:57 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-28 08:49:57 --> Model Class Initialized
INFO - 2024-03-28 08:49:58 --> Final output sent to browser
DEBUG - 2024-03-28 08:49:58 --> Total execution time: 0.2078
ERROR - 2024-03-28 08:49:58 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-03-28 08:49:58 --> Config Class Initialized
INFO - 2024-03-28 08:49:58 --> Hooks Class Initialized
DEBUG - 2024-03-28 08:49:58 --> UTF-8 Support Enabled
INFO - 2024-03-28 08:49:58 --> Utf8 Class Initialized
INFO - 2024-03-28 08:49:58 --> URI Class Initialized
INFO - 2024-03-28 08:49:58 --> Router Class Initialized
INFO - 2024-03-28 08:49:58 --> Output Class Initialized
INFO - 2024-03-28 08:49:58 --> Security Class Initialized
DEBUG - 2024-03-28 08:49:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-28 08:49:58 --> Input Class Initialized
INFO - 2024-03-28 08:49:58 --> Language Class Initialized
INFO - 2024-03-28 08:49:58 --> Loader Class Initialized
INFO - 2024-03-28 08:49:58 --> Helper loaded: url_helper
INFO - 2024-03-28 08:49:58 --> Helper loaded: file_helper
INFO - 2024-03-28 08:49:58 --> Helper loaded: html_helper
INFO - 2024-03-28 08:49:58 --> Helper loaded: text_helper
INFO - 2024-03-28 08:49:58 --> Helper loaded: form_helper
INFO - 2024-03-28 08:49:58 --> Helper loaded: lang_helper
INFO - 2024-03-28 08:49:58 --> Helper loaded: security_helper
INFO - 2024-03-28 08:49:58 --> Helper loaded: cookie_helper
INFO - 2024-03-28 08:49:58 --> Database Driver Class Initialized
INFO - 2024-03-28 08:49:58 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-28 08:49:58 --> Parser Class Initialized
INFO - 2024-03-28 08:49:58 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-03-28 08:49:58 --> Pagination Class Initialized
INFO - 2024-03-28 08:49:58 --> Form Validation Class Initialized
INFO - 2024-03-28 08:49:58 --> Controller Class Initialized
INFO - 2024-03-28 08:49:58 --> Model Class Initialized
DEBUG - 2024-03-28 08:49:58 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-03-28 08:49:58 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-28 08:49:58 --> Model Class Initialized
DEBUG - 2024-03-28 08:49:58 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-28 08:49:58 --> Model Class Initialized
INFO - 2024-03-28 08:49:58 --> Final output sent to browser
DEBUG - 2024-03-28 08:49:58 --> Total execution time: 0.0231
ERROR - 2024-03-28 08:49:58 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-03-28 08:49:58 --> Config Class Initialized
INFO - 2024-03-28 08:49:58 --> Hooks Class Initialized
DEBUG - 2024-03-28 08:49:58 --> UTF-8 Support Enabled
INFO - 2024-03-28 08:49:58 --> Utf8 Class Initialized
INFO - 2024-03-28 08:49:58 --> URI Class Initialized
INFO - 2024-03-28 08:49:58 --> Router Class Initialized
INFO - 2024-03-28 08:49:58 --> Output Class Initialized
INFO - 2024-03-28 08:49:58 --> Security Class Initialized
DEBUG - 2024-03-28 08:49:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-28 08:49:58 --> Input Class Initialized
INFO - 2024-03-28 08:49:58 --> Language Class Initialized
INFO - 2024-03-28 08:49:58 --> Loader Class Initialized
INFO - 2024-03-28 08:49:58 --> Helper loaded: url_helper
INFO - 2024-03-28 08:49:58 --> Helper loaded: file_helper
INFO - 2024-03-28 08:49:58 --> Helper loaded: html_helper
INFO - 2024-03-28 08:49:58 --> Helper loaded: text_helper
INFO - 2024-03-28 08:49:58 --> Helper loaded: form_helper
INFO - 2024-03-28 08:49:58 --> Helper loaded: lang_helper
INFO - 2024-03-28 08:49:58 --> Helper loaded: security_helper
INFO - 2024-03-28 08:49:58 --> Helper loaded: cookie_helper
INFO - 2024-03-28 08:49:58 --> Database Driver Class Initialized
INFO - 2024-03-28 08:49:58 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-28 08:49:58 --> Parser Class Initialized
INFO - 2024-03-28 08:49:58 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-03-28 08:49:58 --> Pagination Class Initialized
INFO - 2024-03-28 08:49:58 --> Form Validation Class Initialized
INFO - 2024-03-28 08:49:58 --> Controller Class Initialized
INFO - 2024-03-28 08:49:58 --> Model Class Initialized
DEBUG - 2024-03-28 08:49:58 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-03-28 08:49:58 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-28 08:49:58 --> Model Class Initialized
DEBUG - 2024-03-28 08:49:58 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-28 08:49:58 --> Model Class Initialized
INFO - 2024-03-28 08:49:59 --> Final output sent to browser
DEBUG - 2024-03-28 08:49:59 --> Total execution time: 0.2139
ERROR - 2024-03-28 08:49:59 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-03-28 08:49:59 --> Config Class Initialized
INFO - 2024-03-28 08:49:59 --> Hooks Class Initialized
DEBUG - 2024-03-28 08:49:59 --> UTF-8 Support Enabled
INFO - 2024-03-28 08:49:59 --> Utf8 Class Initialized
INFO - 2024-03-28 08:49:59 --> URI Class Initialized
INFO - 2024-03-28 08:49:59 --> Router Class Initialized
INFO - 2024-03-28 08:49:59 --> Output Class Initialized
INFO - 2024-03-28 08:49:59 --> Security Class Initialized
DEBUG - 2024-03-28 08:49:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-28 08:49:59 --> Input Class Initialized
INFO - 2024-03-28 08:49:59 --> Language Class Initialized
INFO - 2024-03-28 08:49:59 --> Loader Class Initialized
INFO - 2024-03-28 08:49:59 --> Helper loaded: url_helper
INFO - 2024-03-28 08:49:59 --> Helper loaded: file_helper
INFO - 2024-03-28 08:49:59 --> Helper loaded: html_helper
INFO - 2024-03-28 08:49:59 --> Helper loaded: text_helper
INFO - 2024-03-28 08:49:59 --> Helper loaded: form_helper
INFO - 2024-03-28 08:49:59 --> Helper loaded: lang_helper
INFO - 2024-03-28 08:49:59 --> Helper loaded: security_helper
INFO - 2024-03-28 08:49:59 --> Helper loaded: cookie_helper
INFO - 2024-03-28 08:49:59 --> Database Driver Class Initialized
INFO - 2024-03-28 08:49:59 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-28 08:49:59 --> Parser Class Initialized
INFO - 2024-03-28 08:49:59 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-03-28 08:49:59 --> Pagination Class Initialized
INFO - 2024-03-28 08:49:59 --> Form Validation Class Initialized
INFO - 2024-03-28 08:49:59 --> Controller Class Initialized
INFO - 2024-03-28 08:49:59 --> Model Class Initialized
DEBUG - 2024-03-28 08:49:59 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-03-28 08:49:59 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-28 08:49:59 --> Model Class Initialized
DEBUG - 2024-03-28 08:49:59 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-28 08:49:59 --> Model Class Initialized
INFO - 2024-03-28 08:49:59 --> Final output sent to browser
DEBUG - 2024-03-28 08:49:59 --> Total execution time: 0.2138
ERROR - 2024-03-28 08:50:00 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-03-28 08:50:00 --> Config Class Initialized
INFO - 2024-03-28 08:50:00 --> Hooks Class Initialized
DEBUG - 2024-03-28 08:50:00 --> UTF-8 Support Enabled
INFO - 2024-03-28 08:50:00 --> Utf8 Class Initialized
INFO - 2024-03-28 08:50:00 --> URI Class Initialized
INFO - 2024-03-28 08:50:00 --> Router Class Initialized
INFO - 2024-03-28 08:50:00 --> Output Class Initialized
INFO - 2024-03-28 08:50:00 --> Security Class Initialized
DEBUG - 2024-03-28 08:50:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-28 08:50:00 --> Input Class Initialized
INFO - 2024-03-28 08:50:00 --> Language Class Initialized
INFO - 2024-03-28 08:50:00 --> Loader Class Initialized
INFO - 2024-03-28 08:50:00 --> Helper loaded: url_helper
INFO - 2024-03-28 08:50:00 --> Helper loaded: file_helper
INFO - 2024-03-28 08:50:00 --> Helper loaded: html_helper
INFO - 2024-03-28 08:50:00 --> Helper loaded: text_helper
INFO - 2024-03-28 08:50:00 --> Helper loaded: form_helper
INFO - 2024-03-28 08:50:00 --> Helper loaded: lang_helper
INFO - 2024-03-28 08:50:00 --> Helper loaded: security_helper
INFO - 2024-03-28 08:50:00 --> Helper loaded: cookie_helper
INFO - 2024-03-28 08:50:00 --> Database Driver Class Initialized
INFO - 2024-03-28 08:50:00 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-28 08:50:00 --> Parser Class Initialized
INFO - 2024-03-28 08:50:00 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-03-28 08:50:00 --> Pagination Class Initialized
INFO - 2024-03-28 08:50:00 --> Form Validation Class Initialized
INFO - 2024-03-28 08:50:00 --> Controller Class Initialized
INFO - 2024-03-28 08:50:00 --> Model Class Initialized
DEBUG - 2024-03-28 08:50:00 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-03-28 08:50:00 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-28 08:50:00 --> Model Class Initialized
DEBUG - 2024-03-28 08:50:00 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-28 08:50:00 --> Model Class Initialized
INFO - 2024-03-28 08:50:00 --> Final output sent to browser
DEBUG - 2024-03-28 08:50:00 --> Total execution time: 0.0660
ERROR - 2024-03-28 08:50:03 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-03-28 08:50:03 --> Config Class Initialized
INFO - 2024-03-28 08:50:03 --> Hooks Class Initialized
DEBUG - 2024-03-28 08:50:03 --> UTF-8 Support Enabled
INFO - 2024-03-28 08:50:03 --> Utf8 Class Initialized
INFO - 2024-03-28 08:50:03 --> URI Class Initialized
INFO - 2024-03-28 08:50:03 --> Router Class Initialized
INFO - 2024-03-28 08:50:03 --> Output Class Initialized
INFO - 2024-03-28 08:50:03 --> Security Class Initialized
DEBUG - 2024-03-28 08:50:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-28 08:50:03 --> Input Class Initialized
INFO - 2024-03-28 08:50:03 --> Language Class Initialized
INFO - 2024-03-28 08:50:03 --> Loader Class Initialized
INFO - 2024-03-28 08:50:03 --> Helper loaded: url_helper
INFO - 2024-03-28 08:50:03 --> Helper loaded: file_helper
INFO - 2024-03-28 08:50:03 --> Helper loaded: html_helper
INFO - 2024-03-28 08:50:03 --> Helper loaded: text_helper
INFO - 2024-03-28 08:50:03 --> Helper loaded: form_helper
INFO - 2024-03-28 08:50:03 --> Helper loaded: lang_helper
INFO - 2024-03-28 08:50:03 --> Helper loaded: security_helper
INFO - 2024-03-28 08:50:03 --> Helper loaded: cookie_helper
INFO - 2024-03-28 08:50:03 --> Database Driver Class Initialized
INFO - 2024-03-28 08:50:03 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-28 08:50:03 --> Parser Class Initialized
INFO - 2024-03-28 08:50:03 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-03-28 08:50:03 --> Pagination Class Initialized
INFO - 2024-03-28 08:50:03 --> Form Validation Class Initialized
INFO - 2024-03-28 08:50:03 --> Controller Class Initialized
INFO - 2024-03-28 08:50:03 --> Model Class Initialized
DEBUG - 2024-03-28 08:50:03 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-03-28 08:50:03 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-28 08:50:03 --> Model Class Initialized
DEBUG - 2024-03-28 08:50:03 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-28 08:50:03 --> Model Class Initialized
INFO - 2024-03-28 08:50:03 --> Final output sent to browser
DEBUG - 2024-03-28 08:50:03 --> Total execution time: 0.0268
ERROR - 2024-03-28 08:50:04 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-03-28 08:50:04 --> Config Class Initialized
INFO - 2024-03-28 08:50:04 --> Hooks Class Initialized
DEBUG - 2024-03-28 08:50:04 --> UTF-8 Support Enabled
INFO - 2024-03-28 08:50:04 --> Utf8 Class Initialized
INFO - 2024-03-28 08:50:04 --> URI Class Initialized
INFO - 2024-03-28 08:50:04 --> Router Class Initialized
INFO - 2024-03-28 08:50:04 --> Output Class Initialized
INFO - 2024-03-28 08:50:04 --> Security Class Initialized
DEBUG - 2024-03-28 08:50:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-28 08:50:04 --> Input Class Initialized
INFO - 2024-03-28 08:50:04 --> Language Class Initialized
INFO - 2024-03-28 08:50:04 --> Loader Class Initialized
INFO - 2024-03-28 08:50:04 --> Helper loaded: url_helper
INFO - 2024-03-28 08:50:04 --> Helper loaded: file_helper
INFO - 2024-03-28 08:50:04 --> Helper loaded: html_helper
INFO - 2024-03-28 08:50:04 --> Helper loaded: text_helper
INFO - 2024-03-28 08:50:04 --> Helper loaded: form_helper
INFO - 2024-03-28 08:50:04 --> Helper loaded: lang_helper
INFO - 2024-03-28 08:50:04 --> Helper loaded: security_helper
INFO - 2024-03-28 08:50:04 --> Helper loaded: cookie_helper
INFO - 2024-03-28 08:50:04 --> Database Driver Class Initialized
INFO - 2024-03-28 08:50:04 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-28 08:50:04 --> Parser Class Initialized
INFO - 2024-03-28 08:50:04 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-03-28 08:50:04 --> Pagination Class Initialized
INFO - 2024-03-28 08:50:04 --> Form Validation Class Initialized
INFO - 2024-03-28 08:50:04 --> Controller Class Initialized
INFO - 2024-03-28 08:50:04 --> Model Class Initialized
DEBUG - 2024-03-28 08:50:04 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-03-28 08:50:04 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-28 08:50:04 --> Model Class Initialized
INFO - 2024-03-28 08:50:04 --> Model Class Initialized
INFO - 2024-03-28 08:50:04 --> Final output sent to browser
DEBUG - 2024-03-28 08:50:04 --> Total execution time: 0.0214
ERROR - 2024-03-28 08:50:17 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-03-28 08:50:17 --> Config Class Initialized
INFO - 2024-03-28 08:50:17 --> Hooks Class Initialized
DEBUG - 2024-03-28 08:50:17 --> UTF-8 Support Enabled
INFO - 2024-03-28 08:50:17 --> Utf8 Class Initialized
INFO - 2024-03-28 08:50:17 --> URI Class Initialized
INFO - 2024-03-28 08:50:17 --> Router Class Initialized
INFO - 2024-03-28 08:50:17 --> Output Class Initialized
INFO - 2024-03-28 08:50:17 --> Security Class Initialized
DEBUG - 2024-03-28 08:50:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-28 08:50:17 --> Input Class Initialized
INFO - 2024-03-28 08:50:17 --> Language Class Initialized
INFO - 2024-03-28 08:50:17 --> Loader Class Initialized
INFO - 2024-03-28 08:50:17 --> Helper loaded: url_helper
INFO - 2024-03-28 08:50:17 --> Helper loaded: file_helper
INFO - 2024-03-28 08:50:17 --> Helper loaded: html_helper
INFO - 2024-03-28 08:50:17 --> Helper loaded: text_helper
INFO - 2024-03-28 08:50:17 --> Helper loaded: form_helper
INFO - 2024-03-28 08:50:17 --> Helper loaded: lang_helper
INFO - 2024-03-28 08:50:17 --> Helper loaded: security_helper
INFO - 2024-03-28 08:50:17 --> Helper loaded: cookie_helper
INFO - 2024-03-28 08:50:17 --> Database Driver Class Initialized
INFO - 2024-03-28 08:50:17 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-28 08:50:17 --> Parser Class Initialized
INFO - 2024-03-28 08:50:17 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-03-28 08:50:17 --> Pagination Class Initialized
INFO - 2024-03-28 08:50:17 --> Form Validation Class Initialized
INFO - 2024-03-28 08:50:17 --> Controller Class Initialized
INFO - 2024-03-28 08:50:17 --> Model Class Initialized
DEBUG - 2024-03-28 08:50:17 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-03-28 08:50:17 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-28 08:50:17 --> Model Class Initialized
DEBUG - 2024-03-28 08:50:17 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-28 08:50:17 --> Model Class Initialized
INFO - 2024-03-28 08:50:17 --> Final output sent to browser
DEBUG - 2024-03-28 08:50:17 --> Total execution time: 0.0249
ERROR - 2024-03-28 08:50:22 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-03-28 08:50:22 --> Config Class Initialized
INFO - 2024-03-28 08:50:22 --> Hooks Class Initialized
DEBUG - 2024-03-28 08:50:22 --> UTF-8 Support Enabled
INFO - 2024-03-28 08:50:22 --> Utf8 Class Initialized
INFO - 2024-03-28 08:50:22 --> URI Class Initialized
INFO - 2024-03-28 08:50:22 --> Router Class Initialized
INFO - 2024-03-28 08:50:22 --> Output Class Initialized
INFO - 2024-03-28 08:50:22 --> Security Class Initialized
DEBUG - 2024-03-28 08:50:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-28 08:50:22 --> Input Class Initialized
INFO - 2024-03-28 08:50:22 --> Language Class Initialized
INFO - 2024-03-28 08:50:22 --> Loader Class Initialized
INFO - 2024-03-28 08:50:22 --> Helper loaded: url_helper
INFO - 2024-03-28 08:50:22 --> Helper loaded: file_helper
INFO - 2024-03-28 08:50:22 --> Helper loaded: html_helper
INFO - 2024-03-28 08:50:22 --> Helper loaded: text_helper
INFO - 2024-03-28 08:50:22 --> Helper loaded: form_helper
INFO - 2024-03-28 08:50:22 --> Helper loaded: lang_helper
INFO - 2024-03-28 08:50:22 --> Helper loaded: security_helper
INFO - 2024-03-28 08:50:22 --> Helper loaded: cookie_helper
INFO - 2024-03-28 08:50:22 --> Database Driver Class Initialized
INFO - 2024-03-28 08:50:22 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-28 08:50:22 --> Parser Class Initialized
INFO - 2024-03-28 08:50:22 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-03-28 08:50:22 --> Pagination Class Initialized
INFO - 2024-03-28 08:50:22 --> Form Validation Class Initialized
INFO - 2024-03-28 08:50:22 --> Controller Class Initialized
INFO - 2024-03-28 08:50:22 --> Model Class Initialized
DEBUG - 2024-03-28 08:50:22 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-03-28 08:50:22 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-28 08:50:22 --> Model Class Initialized
DEBUG - 2024-03-28 08:50:22 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-28 08:50:22 --> Model Class Initialized
INFO - 2024-03-28 08:50:22 --> Final output sent to browser
DEBUG - 2024-03-28 08:50:22 --> Total execution time: 0.0186
ERROR - 2024-03-28 08:50:24 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-03-28 08:50:24 --> Config Class Initialized
INFO - 2024-03-28 08:50:24 --> Hooks Class Initialized
DEBUG - 2024-03-28 08:50:24 --> UTF-8 Support Enabled
INFO - 2024-03-28 08:50:24 --> Utf8 Class Initialized
INFO - 2024-03-28 08:50:24 --> URI Class Initialized
INFO - 2024-03-28 08:50:24 --> Router Class Initialized
INFO - 2024-03-28 08:50:24 --> Output Class Initialized
INFO - 2024-03-28 08:50:24 --> Security Class Initialized
DEBUG - 2024-03-28 08:50:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-28 08:50:24 --> Input Class Initialized
INFO - 2024-03-28 08:50:24 --> Language Class Initialized
INFO - 2024-03-28 08:50:24 --> Loader Class Initialized
INFO - 2024-03-28 08:50:24 --> Helper loaded: url_helper
INFO - 2024-03-28 08:50:24 --> Helper loaded: file_helper
INFO - 2024-03-28 08:50:24 --> Helper loaded: html_helper
INFO - 2024-03-28 08:50:24 --> Helper loaded: text_helper
INFO - 2024-03-28 08:50:24 --> Helper loaded: form_helper
INFO - 2024-03-28 08:50:24 --> Helper loaded: lang_helper
INFO - 2024-03-28 08:50:24 --> Helper loaded: security_helper
INFO - 2024-03-28 08:50:24 --> Helper loaded: cookie_helper
INFO - 2024-03-28 08:50:24 --> Database Driver Class Initialized
INFO - 2024-03-28 08:50:24 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-28 08:50:24 --> Parser Class Initialized
INFO - 2024-03-28 08:50:24 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-03-28 08:50:24 --> Pagination Class Initialized
INFO - 2024-03-28 08:50:24 --> Form Validation Class Initialized
INFO - 2024-03-28 08:50:24 --> Controller Class Initialized
INFO - 2024-03-28 08:50:24 --> Model Class Initialized
DEBUG - 2024-03-28 08:50:24 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-03-28 08:50:24 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-28 08:50:24 --> Model Class Initialized
DEBUG - 2024-03-28 08:50:24 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-28 08:50:24 --> Model Class Initialized
INFO - 2024-03-28 08:50:24 --> Final output sent to browser
DEBUG - 2024-03-28 08:50:24 --> Total execution time: 0.0176
ERROR - 2024-03-28 08:50:26 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-03-28 08:50:26 --> Config Class Initialized
INFO - 2024-03-28 08:50:26 --> Hooks Class Initialized
DEBUG - 2024-03-28 08:50:26 --> UTF-8 Support Enabled
INFO - 2024-03-28 08:50:26 --> Utf8 Class Initialized
INFO - 2024-03-28 08:50:26 --> URI Class Initialized
INFO - 2024-03-28 08:50:26 --> Router Class Initialized
INFO - 2024-03-28 08:50:26 --> Output Class Initialized
INFO - 2024-03-28 08:50:26 --> Security Class Initialized
DEBUG - 2024-03-28 08:50:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-28 08:50:26 --> Input Class Initialized
INFO - 2024-03-28 08:50:26 --> Language Class Initialized
INFO - 2024-03-28 08:50:26 --> Loader Class Initialized
INFO - 2024-03-28 08:50:26 --> Helper loaded: url_helper
INFO - 2024-03-28 08:50:26 --> Helper loaded: file_helper
INFO - 2024-03-28 08:50:26 --> Helper loaded: html_helper
INFO - 2024-03-28 08:50:26 --> Helper loaded: text_helper
INFO - 2024-03-28 08:50:26 --> Helper loaded: form_helper
INFO - 2024-03-28 08:50:26 --> Helper loaded: lang_helper
INFO - 2024-03-28 08:50:26 --> Helper loaded: security_helper
INFO - 2024-03-28 08:50:26 --> Helper loaded: cookie_helper
INFO - 2024-03-28 08:50:26 --> Database Driver Class Initialized
INFO - 2024-03-28 08:50:26 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-28 08:50:26 --> Parser Class Initialized
INFO - 2024-03-28 08:50:26 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-03-28 08:50:26 --> Pagination Class Initialized
INFO - 2024-03-28 08:50:26 --> Form Validation Class Initialized
INFO - 2024-03-28 08:50:26 --> Controller Class Initialized
INFO - 2024-03-28 08:50:26 --> Model Class Initialized
DEBUG - 2024-03-28 08:50:26 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-03-28 08:50:26 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-28 08:50:26 --> Model Class Initialized
DEBUG - 2024-03-28 08:50:26 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-28 08:50:26 --> Model Class Initialized
INFO - 2024-03-28 08:50:26 --> Final output sent to browser
DEBUG - 2024-03-28 08:50:26 --> Total execution time: 0.0181
ERROR - 2024-03-28 08:50:27 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-03-28 08:50:27 --> Config Class Initialized
INFO - 2024-03-28 08:50:27 --> Hooks Class Initialized
DEBUG - 2024-03-28 08:50:27 --> UTF-8 Support Enabled
INFO - 2024-03-28 08:50:27 --> Utf8 Class Initialized
INFO - 2024-03-28 08:50:27 --> URI Class Initialized
INFO - 2024-03-28 08:50:27 --> Router Class Initialized
INFO - 2024-03-28 08:50:27 --> Output Class Initialized
INFO - 2024-03-28 08:50:27 --> Security Class Initialized
DEBUG - 2024-03-28 08:50:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-28 08:50:27 --> Input Class Initialized
INFO - 2024-03-28 08:50:27 --> Language Class Initialized
INFO - 2024-03-28 08:50:27 --> Loader Class Initialized
INFO - 2024-03-28 08:50:27 --> Helper loaded: url_helper
INFO - 2024-03-28 08:50:27 --> Helper loaded: file_helper
INFO - 2024-03-28 08:50:27 --> Helper loaded: html_helper
INFO - 2024-03-28 08:50:27 --> Helper loaded: text_helper
INFO - 2024-03-28 08:50:27 --> Helper loaded: form_helper
INFO - 2024-03-28 08:50:27 --> Helper loaded: lang_helper
INFO - 2024-03-28 08:50:27 --> Helper loaded: security_helper
INFO - 2024-03-28 08:50:27 --> Helper loaded: cookie_helper
INFO - 2024-03-28 08:50:27 --> Database Driver Class Initialized
INFO - 2024-03-28 08:50:27 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-28 08:50:27 --> Parser Class Initialized
INFO - 2024-03-28 08:50:27 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-03-28 08:50:27 --> Pagination Class Initialized
INFO - 2024-03-28 08:50:27 --> Form Validation Class Initialized
INFO - 2024-03-28 08:50:27 --> Controller Class Initialized
INFO - 2024-03-28 08:50:27 --> Model Class Initialized
DEBUG - 2024-03-28 08:50:27 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-03-28 08:50:27 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-28 08:50:27 --> Model Class Initialized
DEBUG - 2024-03-28 08:50:27 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-28 08:50:27 --> Model Class Initialized
INFO - 2024-03-28 08:50:27 --> Final output sent to browser
DEBUG - 2024-03-28 08:50:27 --> Total execution time: 0.0180
ERROR - 2024-03-28 08:50:27 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-03-28 08:50:27 --> Config Class Initialized
INFO - 2024-03-28 08:50:27 --> Hooks Class Initialized
DEBUG - 2024-03-28 08:50:27 --> UTF-8 Support Enabled
INFO - 2024-03-28 08:50:27 --> Utf8 Class Initialized
INFO - 2024-03-28 08:50:27 --> URI Class Initialized
INFO - 2024-03-28 08:50:27 --> Router Class Initialized
INFO - 2024-03-28 08:50:27 --> Output Class Initialized
INFO - 2024-03-28 08:50:27 --> Security Class Initialized
DEBUG - 2024-03-28 08:50:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-28 08:50:27 --> Input Class Initialized
INFO - 2024-03-28 08:50:27 --> Language Class Initialized
INFO - 2024-03-28 08:50:27 --> Loader Class Initialized
INFO - 2024-03-28 08:50:27 --> Helper loaded: url_helper
INFO - 2024-03-28 08:50:27 --> Helper loaded: file_helper
INFO - 2024-03-28 08:50:27 --> Helper loaded: html_helper
INFO - 2024-03-28 08:50:27 --> Helper loaded: text_helper
INFO - 2024-03-28 08:50:27 --> Helper loaded: form_helper
INFO - 2024-03-28 08:50:27 --> Helper loaded: lang_helper
INFO - 2024-03-28 08:50:27 --> Helper loaded: security_helper
INFO - 2024-03-28 08:50:27 --> Helper loaded: cookie_helper
INFO - 2024-03-28 08:50:27 --> Database Driver Class Initialized
INFO - 2024-03-28 08:50:27 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-28 08:50:27 --> Parser Class Initialized
INFO - 2024-03-28 08:50:27 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-03-28 08:50:27 --> Pagination Class Initialized
INFO - 2024-03-28 08:50:27 --> Form Validation Class Initialized
INFO - 2024-03-28 08:50:27 --> Controller Class Initialized
INFO - 2024-03-28 08:50:27 --> Model Class Initialized
DEBUG - 2024-03-28 08:50:27 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-03-28 08:50:27 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-28 08:50:27 --> Model Class Initialized
DEBUG - 2024-03-28 08:50:27 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-28 08:50:27 --> Model Class Initialized
INFO - 2024-03-28 08:50:27 --> Final output sent to browser
DEBUG - 2024-03-28 08:50:27 --> Total execution time: 0.0179
ERROR - 2024-03-28 08:50:28 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-03-28 08:50:28 --> Config Class Initialized
INFO - 2024-03-28 08:50:28 --> Hooks Class Initialized
DEBUG - 2024-03-28 08:50:28 --> UTF-8 Support Enabled
INFO - 2024-03-28 08:50:28 --> Utf8 Class Initialized
INFO - 2024-03-28 08:50:28 --> URI Class Initialized
INFO - 2024-03-28 08:50:28 --> Router Class Initialized
INFO - 2024-03-28 08:50:28 --> Output Class Initialized
INFO - 2024-03-28 08:50:28 --> Security Class Initialized
DEBUG - 2024-03-28 08:50:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-28 08:50:28 --> Input Class Initialized
INFO - 2024-03-28 08:50:28 --> Language Class Initialized
INFO - 2024-03-28 08:50:28 --> Loader Class Initialized
INFO - 2024-03-28 08:50:28 --> Helper loaded: url_helper
INFO - 2024-03-28 08:50:28 --> Helper loaded: file_helper
INFO - 2024-03-28 08:50:28 --> Helper loaded: html_helper
INFO - 2024-03-28 08:50:28 --> Helper loaded: text_helper
INFO - 2024-03-28 08:50:28 --> Helper loaded: form_helper
INFO - 2024-03-28 08:50:28 --> Helper loaded: lang_helper
INFO - 2024-03-28 08:50:28 --> Helper loaded: security_helper
INFO - 2024-03-28 08:50:28 --> Helper loaded: cookie_helper
INFO - 2024-03-28 08:50:28 --> Database Driver Class Initialized
INFO - 2024-03-28 08:50:28 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-28 08:50:28 --> Parser Class Initialized
INFO - 2024-03-28 08:50:28 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-03-28 08:50:28 --> Pagination Class Initialized
INFO - 2024-03-28 08:50:28 --> Form Validation Class Initialized
INFO - 2024-03-28 08:50:28 --> Controller Class Initialized
INFO - 2024-03-28 08:50:28 --> Model Class Initialized
DEBUG - 2024-03-28 08:50:28 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-03-28 08:50:28 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-28 08:50:28 --> Model Class Initialized
DEBUG - 2024-03-28 08:50:28 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-28 08:50:28 --> Model Class Initialized
INFO - 2024-03-28 08:50:28 --> Final output sent to browser
DEBUG - 2024-03-28 08:50:28 --> Total execution time: 0.0218
ERROR - 2024-03-28 08:50:31 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-03-28 08:50:31 --> Config Class Initialized
INFO - 2024-03-28 08:50:31 --> Hooks Class Initialized
DEBUG - 2024-03-28 08:50:31 --> UTF-8 Support Enabled
INFO - 2024-03-28 08:50:31 --> Utf8 Class Initialized
INFO - 2024-03-28 08:50:31 --> URI Class Initialized
INFO - 2024-03-28 08:50:31 --> Router Class Initialized
INFO - 2024-03-28 08:50:31 --> Output Class Initialized
INFO - 2024-03-28 08:50:31 --> Security Class Initialized
DEBUG - 2024-03-28 08:50:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-28 08:50:31 --> Input Class Initialized
INFO - 2024-03-28 08:50:31 --> Language Class Initialized
INFO - 2024-03-28 08:50:31 --> Loader Class Initialized
INFO - 2024-03-28 08:50:31 --> Helper loaded: url_helper
INFO - 2024-03-28 08:50:31 --> Helper loaded: file_helper
INFO - 2024-03-28 08:50:31 --> Helper loaded: html_helper
INFO - 2024-03-28 08:50:31 --> Helper loaded: text_helper
INFO - 2024-03-28 08:50:31 --> Helper loaded: form_helper
INFO - 2024-03-28 08:50:31 --> Helper loaded: lang_helper
INFO - 2024-03-28 08:50:31 --> Helper loaded: security_helper
INFO - 2024-03-28 08:50:31 --> Helper loaded: cookie_helper
INFO - 2024-03-28 08:50:31 --> Database Driver Class Initialized
INFO - 2024-03-28 08:50:31 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-28 08:50:31 --> Parser Class Initialized
INFO - 2024-03-28 08:50:31 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-03-28 08:50:31 --> Pagination Class Initialized
INFO - 2024-03-28 08:50:31 --> Form Validation Class Initialized
INFO - 2024-03-28 08:50:31 --> Controller Class Initialized
INFO - 2024-03-28 08:50:31 --> Model Class Initialized
DEBUG - 2024-03-28 08:50:31 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-03-28 08:50:31 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-28 08:50:31 --> Model Class Initialized
DEBUG - 2024-03-28 08:50:31 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-28 08:50:31 --> Model Class Initialized
INFO - 2024-03-28 08:50:31 --> Final output sent to browser
DEBUG - 2024-03-28 08:50:31 --> Total execution time: 0.0233
ERROR - 2024-03-28 08:50:33 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-03-28 08:50:33 --> Config Class Initialized
INFO - 2024-03-28 08:50:33 --> Hooks Class Initialized
DEBUG - 2024-03-28 08:50:33 --> UTF-8 Support Enabled
INFO - 2024-03-28 08:50:33 --> Utf8 Class Initialized
INFO - 2024-03-28 08:50:33 --> URI Class Initialized
INFO - 2024-03-28 08:50:33 --> Router Class Initialized
INFO - 2024-03-28 08:50:33 --> Output Class Initialized
INFO - 2024-03-28 08:50:33 --> Security Class Initialized
DEBUG - 2024-03-28 08:50:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-28 08:50:33 --> Input Class Initialized
INFO - 2024-03-28 08:50:33 --> Language Class Initialized
INFO - 2024-03-28 08:50:33 --> Loader Class Initialized
INFO - 2024-03-28 08:50:33 --> Helper loaded: url_helper
INFO - 2024-03-28 08:50:33 --> Helper loaded: file_helper
INFO - 2024-03-28 08:50:33 --> Helper loaded: html_helper
INFO - 2024-03-28 08:50:33 --> Helper loaded: text_helper
INFO - 2024-03-28 08:50:33 --> Helper loaded: form_helper
INFO - 2024-03-28 08:50:33 --> Helper loaded: lang_helper
INFO - 2024-03-28 08:50:33 --> Helper loaded: security_helper
INFO - 2024-03-28 08:50:33 --> Helper loaded: cookie_helper
INFO - 2024-03-28 08:50:33 --> Database Driver Class Initialized
INFO - 2024-03-28 08:50:33 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-28 08:50:33 --> Parser Class Initialized
INFO - 2024-03-28 08:50:33 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-03-28 08:50:33 --> Pagination Class Initialized
INFO - 2024-03-28 08:50:33 --> Form Validation Class Initialized
INFO - 2024-03-28 08:50:33 --> Controller Class Initialized
INFO - 2024-03-28 08:50:33 --> Model Class Initialized
DEBUG - 2024-03-28 08:50:33 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-03-28 08:50:33 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-28 08:50:33 --> Model Class Initialized
INFO - 2024-03-28 08:50:33 --> Model Class Initialized
INFO - 2024-03-28 08:50:33 --> Final output sent to browser
DEBUG - 2024-03-28 08:50:33 --> Total execution time: 0.0190
ERROR - 2024-03-28 08:50:35 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-03-28 08:50:35 --> Config Class Initialized
INFO - 2024-03-28 08:50:35 --> Hooks Class Initialized
DEBUG - 2024-03-28 08:50:35 --> UTF-8 Support Enabled
INFO - 2024-03-28 08:50:35 --> Utf8 Class Initialized
INFO - 2024-03-28 08:50:35 --> URI Class Initialized
INFO - 2024-03-28 08:50:35 --> Router Class Initialized
INFO - 2024-03-28 08:50:35 --> Output Class Initialized
INFO - 2024-03-28 08:50:35 --> Security Class Initialized
DEBUG - 2024-03-28 08:50:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-28 08:50:35 --> Input Class Initialized
INFO - 2024-03-28 08:50:35 --> Language Class Initialized
INFO - 2024-03-28 08:50:35 --> Loader Class Initialized
INFO - 2024-03-28 08:50:35 --> Helper loaded: url_helper
INFO - 2024-03-28 08:50:35 --> Helper loaded: file_helper
INFO - 2024-03-28 08:50:35 --> Helper loaded: html_helper
INFO - 2024-03-28 08:50:35 --> Helper loaded: text_helper
INFO - 2024-03-28 08:50:35 --> Helper loaded: form_helper
INFO - 2024-03-28 08:50:35 --> Helper loaded: lang_helper
INFO - 2024-03-28 08:50:35 --> Helper loaded: security_helper
INFO - 2024-03-28 08:50:35 --> Helper loaded: cookie_helper
INFO - 2024-03-28 08:50:35 --> Database Driver Class Initialized
INFO - 2024-03-28 08:50:35 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-28 08:50:35 --> Parser Class Initialized
INFO - 2024-03-28 08:50:35 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-03-28 08:50:35 --> Pagination Class Initialized
INFO - 2024-03-28 08:50:35 --> Form Validation Class Initialized
INFO - 2024-03-28 08:50:35 --> Controller Class Initialized
INFO - 2024-03-28 08:50:35 --> Model Class Initialized
DEBUG - 2024-03-28 08:50:35 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-03-28 08:50:35 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-28 08:50:35 --> Model Class Initialized
INFO - 2024-03-28 08:50:35 --> Final output sent to browser
DEBUG - 2024-03-28 08:50:35 --> Total execution time: 0.0167
ERROR - 2024-03-28 08:51:13 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-03-28 08:51:13 --> Config Class Initialized
INFO - 2024-03-28 08:51:13 --> Hooks Class Initialized
DEBUG - 2024-03-28 08:51:13 --> UTF-8 Support Enabled
INFO - 2024-03-28 08:51:13 --> Utf8 Class Initialized
INFO - 2024-03-28 08:51:13 --> URI Class Initialized
INFO - 2024-03-28 08:51:13 --> Router Class Initialized
INFO - 2024-03-28 08:51:13 --> Output Class Initialized
INFO - 2024-03-28 08:51:13 --> Security Class Initialized
DEBUG - 2024-03-28 08:51:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-28 08:51:13 --> Input Class Initialized
INFO - 2024-03-28 08:51:13 --> Language Class Initialized
INFO - 2024-03-28 08:51:13 --> Loader Class Initialized
INFO - 2024-03-28 08:51:13 --> Helper loaded: url_helper
INFO - 2024-03-28 08:51:13 --> Helper loaded: file_helper
INFO - 2024-03-28 08:51:13 --> Helper loaded: html_helper
INFO - 2024-03-28 08:51:13 --> Helper loaded: text_helper
INFO - 2024-03-28 08:51:13 --> Helper loaded: form_helper
INFO - 2024-03-28 08:51:13 --> Helper loaded: lang_helper
INFO - 2024-03-28 08:51:13 --> Helper loaded: security_helper
INFO - 2024-03-28 08:51:13 --> Helper loaded: cookie_helper
INFO - 2024-03-28 08:51:13 --> Database Driver Class Initialized
INFO - 2024-03-28 08:51:13 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-28 08:51:13 --> Parser Class Initialized
INFO - 2024-03-28 08:51:13 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-03-28 08:51:13 --> Pagination Class Initialized
INFO - 2024-03-28 08:51:13 --> Form Validation Class Initialized
INFO - 2024-03-28 08:51:13 --> Controller Class Initialized
INFO - 2024-03-28 08:51:13 --> Model Class Initialized
DEBUG - 2024-03-28 08:51:13 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-03-28 08:51:13 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-28 08:51:13 --> Model Class Initialized
DEBUG - 2024-03-28 08:51:13 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-28 08:51:13 --> Model Class Initialized
INFO - 2024-03-28 08:51:13 --> Email Class Initialized
DEBUG - 2024-03-28 08:51:13 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-28 08:51:13 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice_html_pdf.php
ERROR - 2024-03-28 08:51:13 --> Severity: Warning --> "continue" targeting switch is equivalent to "break". Did you mean to use "continue 2"? /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/dompdf.cls.php 743
ERROR - 2024-03-28 08:51:13 --> Severity: Warning --> "continue" targeting switch is equivalent to "break". Did you mean to use "continue 2"? /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/dompdf.cls.php 763
ERROR - 2024-03-28 08:51:13 --> Severity: Warning --> "continue" targeting switch is equivalent to "break". Did you mean to use "continue 2"? /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/stylesheet.cls.php 1102
ERROR - 2024-03-28 08:51:13 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/page_frame_decorator.cls.php 439
ERROR - 2024-03-28 08:51:13 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/page_frame_decorator.cls.php 439
ERROR - 2024-03-28 08:51:13 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/page_frame_decorator.cls.php 439
ERROR - 2024-03-28 08:51:13 --> Severity: Warning --> Division by zero /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 572
ERROR - 2024-03-28 08:51:13 --> Severity: Warning --> Division by zero /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 572
ERROR - 2024-03-28 08:51:13 --> Severity: Warning --> Division by zero /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 572
ERROR - 2024-03-28 08:51:13 --> Severity: Warning --> Division by zero /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 572
ERROR - 2024-03-28 08:51:13 --> Severity: Warning --> Division by zero /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 572
ERROR - 2024-03-28 08:51:13 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/table_cell_frame_reflower.cls.php 103
ERROR - 2024-03-28 08:51:13 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/table_cell_frame_reflower.cls.php 103
ERROR - 2024-03-28 08:51:13 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/table_cell_frame_reflower.cls.php 103
ERROR - 2024-03-28 08:51:13 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/table_cell_frame_reflower.cls.php 103
ERROR - 2024-03-28 08:51:13 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/table_cell_frame_reflower.cls.php 103
ERROR - 2024-03-28 08:51:13 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/table_cell_frame_reflower.cls.php 103
ERROR - 2024-03-28 08:51:13 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/table_cell_frame_reflower.cls.php 103
ERROR - 2024-03-28 08:51:13 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/table_cell_frame_reflower.cls.php 103
ERROR - 2024-03-28 08:51:13 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/table_cell_frame_reflower.cls.php 103
ERROR - 2024-03-28 08:51:13 --> Severity: Warning --> Invalid argument supplied for foreach() /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 709
ERROR - 2024-03-28 08:51:13 --> Severity: Warning --> Invalid argument supplied for foreach() /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 709
ERROR - 2024-03-28 08:51:13 --> Severity: Warning --> Invalid argument supplied for foreach() /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 709
ERROR - 2024-03-28 08:51:13 --> Severity: Warning --> Invalid argument supplied for foreach() /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 709
ERROR - 2024-03-28 08:51:13 --> Severity: Warning --> Invalid argument supplied for foreach() /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 709
ERROR - 2024-03-28 08:51:13 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-03-28 08:51:13 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-03-28 08:51:13 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-03-28 08:51:13 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-03-28 08:51:13 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-03-28 08:51:13 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-03-28 08:51:13 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-03-28 08:51:13 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-03-28 08:51:13 --> Severity: Warning --> "continue" targeting switch is equivalent to "break". Did you mean to use "continue 2"? /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/text_renderer.cls.php 126
ERROR - 2024-03-28 08:51:13 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-03-28 08:51:13 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-03-28 08:51:13 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-03-28 08:51:13 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-03-28 08:51:13 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-03-28 08:51:13 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-03-28 08:51:13 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-03-28 08:51:13 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-03-28 08:51:13 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-03-28 08:51:13 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-03-28 08:51:13 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-03-28 08:51:13 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-03-28 08:51:13 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-03-28 08:51:13 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-03-28 08:51:13 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-03-28 08:51:13 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-03-28 08:51:13 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-03-28 08:51:13 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-03-28 08:51:13 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-03-28 08:51:13 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-03-28 08:51:13 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-03-28 08:51:13 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-03-28 08:51:13 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-03-28 08:51:13 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-03-28 08:51:13 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-03-28 08:51:13 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-03-28 08:51:13 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-03-28 08:51:13 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-03-28 08:51:13 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-03-28 08:51:13 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-03-28 08:51:13 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-03-28 08:51:13 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-03-28 08:51:13 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-03-28 08:51:13 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-03-28 08:51:13 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-03-28 08:51:13 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-03-28 08:51:13 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-03-28 08:51:13 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-03-28 08:51:13 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-03-28 08:51:13 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-03-28 08:51:13 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-03-28 08:51:13 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-03-28 08:51:13 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-03-28 08:51:13 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-03-28 08:51:13 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-03-28 08:51:13 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-03-28 08:51:13 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-03-28 08:51:13 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-03-28 08:51:13 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-03-28 08:51:13 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-03-28 08:51:13 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-03-28 08:51:13 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-03-28 08:51:13 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-03-28 08:51:13 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-03-28 08:51:13 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-03-28 08:51:13 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-03-28 08:51:13 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-03-28 08:51:13 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-03-28 08:51:13 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-03-28 08:51:13 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-03-28 08:51:13 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-03-28 08:51:13 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-03-28 08:51:13 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-03-28 08:51:13 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-03-28 08:51:13 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-03-28 08:51:13 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-03-28 08:51:13 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-03-28 08:51:13 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-03-28 08:51:13 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-03-28 08:51:13 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-03-28 08:51:13 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-03-28 08:51:13 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-03-28 08:51:13 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-03-28 08:51:13 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-03-28 08:51:13 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-03-28 08:51:13 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-03-28 08:51:13 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-03-28 08:51:13 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-03-28 08:51:13 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-03-28 08:51:13 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-03-28 08:51:13 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-03-28 08:51:13 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-03-28 08:51:13 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-03-28 08:51:13 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-03-28 08:51:13 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-03-28 08:51:13 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-03-28 08:51:13 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-03-28 08:51:13 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-03-28 08:51:13 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-03-28 08:51:13 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-03-28 08:51:13 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-03-28 08:51:13 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-03-28 08:51:13 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-03-28 08:51:13 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-03-28 08:51:13 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-03-28 08:51:13 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
INFO - 2024-03-28 08:51:13 --> Language file loaded: language/english/email_lang.php
INFO - 2024-03-28 08:51:13 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice_html.php
INFO - 2024-03-28 08:51:13 --> Final output sent to browser
DEBUG - 2024-03-28 08:51:13 --> Total execution time: 0.2312
ERROR - 2024-03-28 08:51:16 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-03-28 08:51:16 --> Config Class Initialized
INFO - 2024-03-28 08:51:16 --> Hooks Class Initialized
DEBUG - 2024-03-28 08:51:16 --> UTF-8 Support Enabled
INFO - 2024-03-28 08:51:16 --> Utf8 Class Initialized
INFO - 2024-03-28 08:51:16 --> URI Class Initialized
INFO - 2024-03-28 08:51:16 --> Router Class Initialized
INFO - 2024-03-28 08:51:16 --> Output Class Initialized
INFO - 2024-03-28 08:51:16 --> Security Class Initialized
DEBUG - 2024-03-28 08:51:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-28 08:51:16 --> Input Class Initialized
INFO - 2024-03-28 08:51:16 --> Language Class Initialized
INFO - 2024-03-28 08:51:16 --> Loader Class Initialized
INFO - 2024-03-28 08:51:16 --> Helper loaded: url_helper
INFO - 2024-03-28 08:51:16 --> Helper loaded: file_helper
INFO - 2024-03-28 08:51:16 --> Helper loaded: html_helper
INFO - 2024-03-28 08:51:16 --> Helper loaded: text_helper
INFO - 2024-03-28 08:51:16 --> Helper loaded: form_helper
INFO - 2024-03-28 08:51:16 --> Helper loaded: lang_helper
INFO - 2024-03-28 08:51:16 --> Helper loaded: security_helper
INFO - 2024-03-28 08:51:16 --> Helper loaded: cookie_helper
INFO - 2024-03-28 08:51:16 --> Database Driver Class Initialized
INFO - 2024-03-28 08:51:16 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-28 08:51:16 --> Parser Class Initialized
INFO - 2024-03-28 08:51:16 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-03-28 08:51:16 --> Pagination Class Initialized
INFO - 2024-03-28 08:51:16 --> Form Validation Class Initialized
INFO - 2024-03-28 08:51:16 --> Controller Class Initialized
INFO - 2024-03-28 08:51:16 --> Model Class Initialized
DEBUG - 2024-03-28 08:51:16 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-03-28 08:51:16 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-28 08:51:16 --> Model Class Initialized
DEBUG - 2024-03-28 08:51:16 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-28 08:51:16 --> Model Class Initialized
INFO - 2024-03-28 08:51:16 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/add_invoice_form.php
DEBUG - 2024-03-28 08:51:16 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-03-28 08:51:16 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-03-28 08:51:16 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-03-28 08:51:16 --> Model Class Initialized
INFO - 2024-03-28 08:51:16 --> Model Class Initialized
INFO - 2024-03-28 08:51:16 --> Model Class Initialized
INFO - 2024-03-28 08:51:16 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-03-28 08:51:16 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-03-28 08:51:16 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-03-28 08:51:16 --> Final output sent to browser
DEBUG - 2024-03-28 08:51:16 --> Total execution time: 0.1987
ERROR - 2024-03-28 08:51:21 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-03-28 08:51:21 --> Config Class Initialized
INFO - 2024-03-28 08:51:21 --> Hooks Class Initialized
DEBUG - 2024-03-28 08:51:21 --> UTF-8 Support Enabled
INFO - 2024-03-28 08:51:21 --> Utf8 Class Initialized
INFO - 2024-03-28 08:51:21 --> URI Class Initialized
INFO - 2024-03-28 08:51:21 --> Router Class Initialized
INFO - 2024-03-28 08:51:21 --> Output Class Initialized
INFO - 2024-03-28 08:51:21 --> Security Class Initialized
DEBUG - 2024-03-28 08:51:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-28 08:51:21 --> Input Class Initialized
INFO - 2024-03-28 08:51:21 --> Language Class Initialized
INFO - 2024-03-28 08:51:21 --> Loader Class Initialized
INFO - 2024-03-28 08:51:21 --> Helper loaded: url_helper
INFO - 2024-03-28 08:51:21 --> Helper loaded: file_helper
INFO - 2024-03-28 08:51:21 --> Helper loaded: html_helper
INFO - 2024-03-28 08:51:21 --> Helper loaded: text_helper
INFO - 2024-03-28 08:51:21 --> Helper loaded: form_helper
INFO - 2024-03-28 08:51:21 --> Helper loaded: lang_helper
INFO - 2024-03-28 08:51:21 --> Helper loaded: security_helper
INFO - 2024-03-28 08:51:21 --> Helper loaded: cookie_helper
INFO - 2024-03-28 08:51:21 --> Database Driver Class Initialized
INFO - 2024-03-28 08:51:21 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-28 08:51:21 --> Parser Class Initialized
INFO - 2024-03-28 08:51:21 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-03-28 08:51:21 --> Pagination Class Initialized
INFO - 2024-03-28 08:51:21 --> Form Validation Class Initialized
INFO - 2024-03-28 08:51:21 --> Controller Class Initialized
INFO - 2024-03-28 08:51:21 --> Model Class Initialized
DEBUG - 2024-03-28 08:51:21 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-28 08:51:21 --> Final output sent to browser
DEBUG - 2024-03-28 08:51:21 --> Total execution time: 0.0194
ERROR - 2024-03-28 08:51:21 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-03-28 08:51:21 --> Config Class Initialized
INFO - 2024-03-28 08:51:21 --> Hooks Class Initialized
DEBUG - 2024-03-28 08:51:21 --> UTF-8 Support Enabled
INFO - 2024-03-28 08:51:21 --> Utf8 Class Initialized
INFO - 2024-03-28 08:51:21 --> URI Class Initialized
INFO - 2024-03-28 08:51:21 --> Router Class Initialized
INFO - 2024-03-28 08:51:21 --> Output Class Initialized
INFO - 2024-03-28 08:51:21 --> Security Class Initialized
DEBUG - 2024-03-28 08:51:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-28 08:51:21 --> Input Class Initialized
INFO - 2024-03-28 08:51:21 --> Language Class Initialized
INFO - 2024-03-28 08:51:21 --> Loader Class Initialized
INFO - 2024-03-28 08:51:21 --> Helper loaded: url_helper
INFO - 2024-03-28 08:51:21 --> Helper loaded: file_helper
INFO - 2024-03-28 08:51:21 --> Helper loaded: html_helper
INFO - 2024-03-28 08:51:21 --> Helper loaded: text_helper
INFO - 2024-03-28 08:51:21 --> Helper loaded: form_helper
INFO - 2024-03-28 08:51:21 --> Helper loaded: lang_helper
INFO - 2024-03-28 08:51:21 --> Helper loaded: security_helper
INFO - 2024-03-28 08:51:21 --> Helper loaded: cookie_helper
INFO - 2024-03-28 08:51:21 --> Database Driver Class Initialized
INFO - 2024-03-28 08:51:21 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-28 08:51:21 --> Parser Class Initialized
INFO - 2024-03-28 08:51:21 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-03-28 08:51:21 --> Pagination Class Initialized
INFO - 2024-03-28 08:51:21 --> Form Validation Class Initialized
INFO - 2024-03-28 08:51:21 --> Controller Class Initialized
INFO - 2024-03-28 08:51:21 --> Model Class Initialized
DEBUG - 2024-03-28 08:51:21 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-28 08:51:21 --> Final output sent to browser
DEBUG - 2024-03-28 08:51:21 --> Total execution time: 0.0150
ERROR - 2024-03-28 08:51:31 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-03-28 08:51:31 --> Config Class Initialized
INFO - 2024-03-28 08:51:31 --> Hooks Class Initialized
DEBUG - 2024-03-28 08:51:31 --> UTF-8 Support Enabled
INFO - 2024-03-28 08:51:31 --> Utf8 Class Initialized
INFO - 2024-03-28 08:51:31 --> URI Class Initialized
INFO - 2024-03-28 08:51:31 --> Router Class Initialized
INFO - 2024-03-28 08:51:31 --> Output Class Initialized
INFO - 2024-03-28 08:51:31 --> Security Class Initialized
DEBUG - 2024-03-28 08:51:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-28 08:51:31 --> Input Class Initialized
INFO - 2024-03-28 08:51:31 --> Language Class Initialized
INFO - 2024-03-28 08:51:31 --> Loader Class Initialized
INFO - 2024-03-28 08:51:31 --> Helper loaded: url_helper
INFO - 2024-03-28 08:51:31 --> Helper loaded: file_helper
INFO - 2024-03-28 08:51:31 --> Helper loaded: html_helper
INFO - 2024-03-28 08:51:31 --> Helper loaded: text_helper
INFO - 2024-03-28 08:51:31 --> Helper loaded: form_helper
INFO - 2024-03-28 08:51:31 --> Helper loaded: lang_helper
INFO - 2024-03-28 08:51:31 --> Helper loaded: security_helper
INFO - 2024-03-28 08:51:31 --> Helper loaded: cookie_helper
INFO - 2024-03-28 08:51:31 --> Database Driver Class Initialized
INFO - 2024-03-28 08:51:31 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-28 08:51:31 --> Parser Class Initialized
INFO - 2024-03-28 08:51:31 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-03-28 08:51:31 --> Pagination Class Initialized
INFO - 2024-03-28 08:51:31 --> Form Validation Class Initialized
INFO - 2024-03-28 08:51:31 --> Controller Class Initialized
INFO - 2024-03-28 08:51:31 --> Model Class Initialized
DEBUG - 2024-03-28 08:51:31 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-28 08:51:31 --> Final output sent to browser
DEBUG - 2024-03-28 08:51:31 --> Total execution time: 0.0159
ERROR - 2024-03-28 08:52:10 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-03-28 08:52:10 --> Config Class Initialized
INFO - 2024-03-28 08:52:10 --> Hooks Class Initialized
DEBUG - 2024-03-28 08:52:10 --> UTF-8 Support Enabled
INFO - 2024-03-28 08:52:10 --> Utf8 Class Initialized
INFO - 2024-03-28 08:52:10 --> URI Class Initialized
INFO - 2024-03-28 08:52:10 --> Router Class Initialized
INFO - 2024-03-28 08:52:10 --> Output Class Initialized
INFO - 2024-03-28 08:52:10 --> Security Class Initialized
DEBUG - 2024-03-28 08:52:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-28 08:52:10 --> Input Class Initialized
INFO - 2024-03-28 08:52:10 --> Language Class Initialized
INFO - 2024-03-28 08:52:10 --> Loader Class Initialized
INFO - 2024-03-28 08:52:10 --> Helper loaded: url_helper
INFO - 2024-03-28 08:52:10 --> Helper loaded: file_helper
INFO - 2024-03-28 08:52:10 --> Helper loaded: html_helper
INFO - 2024-03-28 08:52:10 --> Helper loaded: text_helper
INFO - 2024-03-28 08:52:10 --> Helper loaded: form_helper
INFO - 2024-03-28 08:52:10 --> Helper loaded: lang_helper
INFO - 2024-03-28 08:52:10 --> Helper loaded: security_helper
INFO - 2024-03-28 08:52:10 --> Helper loaded: cookie_helper
INFO - 2024-03-28 08:52:10 --> Database Driver Class Initialized
INFO - 2024-03-28 08:52:10 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-28 08:52:10 --> Parser Class Initialized
INFO - 2024-03-28 08:52:10 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-03-28 08:52:10 --> Pagination Class Initialized
INFO - 2024-03-28 08:52:10 --> Form Validation Class Initialized
INFO - 2024-03-28 08:52:10 --> Controller Class Initialized
INFO - 2024-03-28 08:52:10 --> Model Class Initialized
DEBUG - 2024-03-28 08:52:10 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-28 08:52:10 --> Final output sent to browser
DEBUG - 2024-03-28 08:52:10 --> Total execution time: 0.0203
ERROR - 2024-03-28 08:52:17 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-03-28 08:52:17 --> Config Class Initialized
INFO - 2024-03-28 08:52:17 --> Hooks Class Initialized
DEBUG - 2024-03-28 08:52:17 --> UTF-8 Support Enabled
INFO - 2024-03-28 08:52:17 --> Utf8 Class Initialized
INFO - 2024-03-28 08:52:17 --> URI Class Initialized
INFO - 2024-03-28 08:52:17 --> Router Class Initialized
INFO - 2024-03-28 08:52:17 --> Output Class Initialized
INFO - 2024-03-28 08:52:17 --> Security Class Initialized
DEBUG - 2024-03-28 08:52:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-28 08:52:17 --> Input Class Initialized
INFO - 2024-03-28 08:52:17 --> Language Class Initialized
INFO - 2024-03-28 08:52:17 --> Loader Class Initialized
INFO - 2024-03-28 08:52:17 --> Helper loaded: url_helper
INFO - 2024-03-28 08:52:17 --> Helper loaded: file_helper
INFO - 2024-03-28 08:52:17 --> Helper loaded: html_helper
INFO - 2024-03-28 08:52:17 --> Helper loaded: text_helper
INFO - 2024-03-28 08:52:17 --> Helper loaded: form_helper
INFO - 2024-03-28 08:52:17 --> Helper loaded: lang_helper
INFO - 2024-03-28 08:52:17 --> Helper loaded: security_helper
INFO - 2024-03-28 08:52:17 --> Helper loaded: cookie_helper
INFO - 2024-03-28 08:52:17 --> Database Driver Class Initialized
INFO - 2024-03-28 08:52:17 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-28 08:52:17 --> Parser Class Initialized
INFO - 2024-03-28 08:52:17 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-03-28 08:52:17 --> Pagination Class Initialized
INFO - 2024-03-28 08:52:17 --> Form Validation Class Initialized
INFO - 2024-03-28 08:52:17 --> Controller Class Initialized
INFO - 2024-03-28 08:52:17 --> Model Class Initialized
DEBUG - 2024-03-28 08:52:17 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-28 08:52:17 --> Final output sent to browser
DEBUG - 2024-03-28 08:52:17 --> Total execution time: 0.0144
ERROR - 2024-03-28 08:52:17 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-03-28 08:52:17 --> Config Class Initialized
INFO - 2024-03-28 08:52:17 --> Hooks Class Initialized
DEBUG - 2024-03-28 08:52:17 --> UTF-8 Support Enabled
INFO - 2024-03-28 08:52:17 --> Utf8 Class Initialized
INFO - 2024-03-28 08:52:17 --> URI Class Initialized
INFO - 2024-03-28 08:52:17 --> Router Class Initialized
INFO - 2024-03-28 08:52:17 --> Output Class Initialized
INFO - 2024-03-28 08:52:17 --> Security Class Initialized
DEBUG - 2024-03-28 08:52:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-28 08:52:17 --> Input Class Initialized
INFO - 2024-03-28 08:52:17 --> Language Class Initialized
INFO - 2024-03-28 08:52:17 --> Loader Class Initialized
INFO - 2024-03-28 08:52:17 --> Helper loaded: url_helper
INFO - 2024-03-28 08:52:17 --> Helper loaded: file_helper
INFO - 2024-03-28 08:52:17 --> Helper loaded: html_helper
INFO - 2024-03-28 08:52:17 --> Helper loaded: text_helper
INFO - 2024-03-28 08:52:17 --> Helper loaded: form_helper
INFO - 2024-03-28 08:52:17 --> Helper loaded: lang_helper
INFO - 2024-03-28 08:52:17 --> Helper loaded: security_helper
INFO - 2024-03-28 08:52:17 --> Helper loaded: cookie_helper
INFO - 2024-03-28 08:52:17 --> Database Driver Class Initialized
INFO - 2024-03-28 08:52:17 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-28 08:52:17 --> Parser Class Initialized
INFO - 2024-03-28 08:52:17 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-03-28 08:52:17 --> Pagination Class Initialized
INFO - 2024-03-28 08:52:17 --> Form Validation Class Initialized
INFO - 2024-03-28 08:52:17 --> Controller Class Initialized
INFO - 2024-03-28 08:52:17 --> Model Class Initialized
DEBUG - 2024-03-28 08:52:17 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-28 08:52:17 --> Final output sent to browser
DEBUG - 2024-03-28 08:52:17 --> Total execution time: 0.0156
ERROR - 2024-03-28 08:52:18 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-03-28 08:52:18 --> Config Class Initialized
INFO - 2024-03-28 08:52:18 --> Hooks Class Initialized
DEBUG - 2024-03-28 08:52:18 --> UTF-8 Support Enabled
INFO - 2024-03-28 08:52:18 --> Utf8 Class Initialized
INFO - 2024-03-28 08:52:18 --> URI Class Initialized
INFO - 2024-03-28 08:52:18 --> Router Class Initialized
INFO - 2024-03-28 08:52:18 --> Output Class Initialized
INFO - 2024-03-28 08:52:18 --> Security Class Initialized
DEBUG - 2024-03-28 08:52:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-28 08:52:18 --> Input Class Initialized
INFO - 2024-03-28 08:52:18 --> Language Class Initialized
INFO - 2024-03-28 08:52:18 --> Loader Class Initialized
INFO - 2024-03-28 08:52:18 --> Helper loaded: url_helper
INFO - 2024-03-28 08:52:18 --> Helper loaded: file_helper
INFO - 2024-03-28 08:52:18 --> Helper loaded: html_helper
INFO - 2024-03-28 08:52:18 --> Helper loaded: text_helper
INFO - 2024-03-28 08:52:18 --> Helper loaded: form_helper
INFO - 2024-03-28 08:52:18 --> Helper loaded: lang_helper
INFO - 2024-03-28 08:52:18 --> Helper loaded: security_helper
INFO - 2024-03-28 08:52:18 --> Helper loaded: cookie_helper
INFO - 2024-03-28 08:52:18 --> Database Driver Class Initialized
INFO - 2024-03-28 08:52:18 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-28 08:52:18 --> Parser Class Initialized
INFO - 2024-03-28 08:52:18 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-03-28 08:52:18 --> Pagination Class Initialized
INFO - 2024-03-28 08:52:18 --> Form Validation Class Initialized
INFO - 2024-03-28 08:52:18 --> Controller Class Initialized
INFO - 2024-03-28 08:52:18 --> Model Class Initialized
DEBUG - 2024-03-28 08:52:18 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-28 08:52:18 --> Final output sent to browser
DEBUG - 2024-03-28 08:52:18 --> Total execution time: 0.0160
ERROR - 2024-03-28 08:52:19 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-03-28 08:52:19 --> Config Class Initialized
INFO - 2024-03-28 08:52:19 --> Hooks Class Initialized
DEBUG - 2024-03-28 08:52:19 --> UTF-8 Support Enabled
INFO - 2024-03-28 08:52:19 --> Utf8 Class Initialized
INFO - 2024-03-28 08:52:19 --> URI Class Initialized
INFO - 2024-03-28 08:52:19 --> Router Class Initialized
INFO - 2024-03-28 08:52:19 --> Output Class Initialized
INFO - 2024-03-28 08:52:19 --> Security Class Initialized
DEBUG - 2024-03-28 08:52:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-28 08:52:19 --> Input Class Initialized
INFO - 2024-03-28 08:52:19 --> Language Class Initialized
INFO - 2024-03-28 08:52:19 --> Loader Class Initialized
INFO - 2024-03-28 08:52:19 --> Helper loaded: url_helper
INFO - 2024-03-28 08:52:19 --> Helper loaded: file_helper
INFO - 2024-03-28 08:52:19 --> Helper loaded: html_helper
INFO - 2024-03-28 08:52:19 --> Helper loaded: text_helper
INFO - 2024-03-28 08:52:19 --> Helper loaded: form_helper
INFO - 2024-03-28 08:52:19 --> Helper loaded: lang_helper
INFO - 2024-03-28 08:52:19 --> Helper loaded: security_helper
INFO - 2024-03-28 08:52:19 --> Helper loaded: cookie_helper
INFO - 2024-03-28 08:52:19 --> Database Driver Class Initialized
INFO - 2024-03-28 08:52:19 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-28 08:52:19 --> Parser Class Initialized
INFO - 2024-03-28 08:52:19 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-03-28 08:52:19 --> Pagination Class Initialized
INFO - 2024-03-28 08:52:19 --> Form Validation Class Initialized
INFO - 2024-03-28 08:52:19 --> Controller Class Initialized
INFO - 2024-03-28 08:52:19 --> Model Class Initialized
DEBUG - 2024-03-28 08:52:19 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-28 08:52:19 --> Final output sent to browser
DEBUG - 2024-03-28 08:52:19 --> Total execution time: 0.0149
ERROR - 2024-03-28 08:52:19 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-03-28 08:52:19 --> Config Class Initialized
INFO - 2024-03-28 08:52:19 --> Hooks Class Initialized
DEBUG - 2024-03-28 08:52:19 --> UTF-8 Support Enabled
INFO - 2024-03-28 08:52:19 --> Utf8 Class Initialized
INFO - 2024-03-28 08:52:19 --> URI Class Initialized
INFO - 2024-03-28 08:52:19 --> Router Class Initialized
INFO - 2024-03-28 08:52:19 --> Output Class Initialized
INFO - 2024-03-28 08:52:19 --> Security Class Initialized
DEBUG - 2024-03-28 08:52:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-28 08:52:19 --> Input Class Initialized
INFO - 2024-03-28 08:52:19 --> Language Class Initialized
INFO - 2024-03-28 08:52:19 --> Loader Class Initialized
INFO - 2024-03-28 08:52:19 --> Helper loaded: url_helper
INFO - 2024-03-28 08:52:19 --> Helper loaded: file_helper
INFO - 2024-03-28 08:52:19 --> Helper loaded: html_helper
INFO - 2024-03-28 08:52:19 --> Helper loaded: text_helper
INFO - 2024-03-28 08:52:19 --> Helper loaded: form_helper
INFO - 2024-03-28 08:52:19 --> Helper loaded: lang_helper
INFO - 2024-03-28 08:52:19 --> Helper loaded: security_helper
INFO - 2024-03-28 08:52:19 --> Helper loaded: cookie_helper
INFO - 2024-03-28 08:52:19 --> Database Driver Class Initialized
INFO - 2024-03-28 08:52:19 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-28 08:52:19 --> Parser Class Initialized
INFO - 2024-03-28 08:52:19 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-03-28 08:52:19 --> Pagination Class Initialized
INFO - 2024-03-28 08:52:19 --> Form Validation Class Initialized
INFO - 2024-03-28 08:52:19 --> Controller Class Initialized
INFO - 2024-03-28 08:52:19 --> Model Class Initialized
DEBUG - 2024-03-28 08:52:19 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-28 08:52:19 --> Final output sent to browser
DEBUG - 2024-03-28 08:52:19 --> Total execution time: 0.0153
ERROR - 2024-03-28 08:52:20 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-03-28 08:52:20 --> Config Class Initialized
INFO - 2024-03-28 08:52:20 --> Hooks Class Initialized
DEBUG - 2024-03-28 08:52:20 --> UTF-8 Support Enabled
INFO - 2024-03-28 08:52:20 --> Utf8 Class Initialized
INFO - 2024-03-28 08:52:20 --> URI Class Initialized
INFO - 2024-03-28 08:52:20 --> Router Class Initialized
INFO - 2024-03-28 08:52:20 --> Output Class Initialized
INFO - 2024-03-28 08:52:20 --> Security Class Initialized
DEBUG - 2024-03-28 08:52:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-28 08:52:20 --> Input Class Initialized
INFO - 2024-03-28 08:52:20 --> Language Class Initialized
INFO - 2024-03-28 08:52:20 --> Loader Class Initialized
INFO - 2024-03-28 08:52:20 --> Helper loaded: url_helper
INFO - 2024-03-28 08:52:20 --> Helper loaded: file_helper
INFO - 2024-03-28 08:52:20 --> Helper loaded: html_helper
INFO - 2024-03-28 08:52:20 --> Helper loaded: text_helper
INFO - 2024-03-28 08:52:20 --> Helper loaded: form_helper
INFO - 2024-03-28 08:52:20 --> Helper loaded: lang_helper
INFO - 2024-03-28 08:52:20 --> Helper loaded: security_helper
INFO - 2024-03-28 08:52:20 --> Helper loaded: cookie_helper
INFO - 2024-03-28 08:52:20 --> Database Driver Class Initialized
INFO - 2024-03-28 08:52:20 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-28 08:52:20 --> Parser Class Initialized
INFO - 2024-03-28 08:52:20 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-03-28 08:52:20 --> Pagination Class Initialized
INFO - 2024-03-28 08:52:20 --> Form Validation Class Initialized
INFO - 2024-03-28 08:52:20 --> Controller Class Initialized
INFO - 2024-03-28 08:52:20 --> Model Class Initialized
DEBUG - 2024-03-28 08:52:20 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-28 08:52:20 --> Final output sent to browser
DEBUG - 2024-03-28 08:52:20 --> Total execution time: 0.0172
ERROR - 2024-03-28 08:52:20 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-03-28 08:52:20 --> Config Class Initialized
INFO - 2024-03-28 08:52:20 --> Hooks Class Initialized
DEBUG - 2024-03-28 08:52:20 --> UTF-8 Support Enabled
INFO - 2024-03-28 08:52:20 --> Utf8 Class Initialized
INFO - 2024-03-28 08:52:20 --> URI Class Initialized
INFO - 2024-03-28 08:52:20 --> Router Class Initialized
INFO - 2024-03-28 08:52:20 --> Output Class Initialized
INFO - 2024-03-28 08:52:20 --> Security Class Initialized
DEBUG - 2024-03-28 08:52:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-28 08:52:20 --> Input Class Initialized
INFO - 2024-03-28 08:52:20 --> Language Class Initialized
INFO - 2024-03-28 08:52:20 --> Loader Class Initialized
INFO - 2024-03-28 08:52:20 --> Helper loaded: url_helper
INFO - 2024-03-28 08:52:20 --> Helper loaded: file_helper
INFO - 2024-03-28 08:52:20 --> Helper loaded: html_helper
INFO - 2024-03-28 08:52:20 --> Helper loaded: text_helper
INFO - 2024-03-28 08:52:20 --> Helper loaded: form_helper
INFO - 2024-03-28 08:52:20 --> Helper loaded: lang_helper
INFO - 2024-03-28 08:52:20 --> Helper loaded: security_helper
INFO - 2024-03-28 08:52:20 --> Helper loaded: cookie_helper
INFO - 2024-03-28 08:52:20 --> Database Driver Class Initialized
INFO - 2024-03-28 08:52:20 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-28 08:52:20 --> Parser Class Initialized
INFO - 2024-03-28 08:52:20 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-03-28 08:52:20 --> Pagination Class Initialized
INFO - 2024-03-28 08:52:20 --> Form Validation Class Initialized
INFO - 2024-03-28 08:52:20 --> Controller Class Initialized
INFO - 2024-03-28 08:52:20 --> Model Class Initialized
DEBUG - 2024-03-28 08:52:20 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-28 08:52:20 --> Final output sent to browser
DEBUG - 2024-03-28 08:52:20 --> Total execution time: 0.0189
ERROR - 2024-03-28 08:52:33 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-03-28 08:52:33 --> Config Class Initialized
INFO - 2024-03-28 08:52:33 --> Hooks Class Initialized
DEBUG - 2024-03-28 08:52:33 --> UTF-8 Support Enabled
INFO - 2024-03-28 08:52:33 --> Utf8 Class Initialized
INFO - 2024-03-28 08:52:33 --> URI Class Initialized
INFO - 2024-03-28 08:52:33 --> Router Class Initialized
INFO - 2024-03-28 08:52:33 --> Output Class Initialized
INFO - 2024-03-28 08:52:33 --> Security Class Initialized
DEBUG - 2024-03-28 08:52:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-28 08:52:33 --> Input Class Initialized
INFO - 2024-03-28 08:52:33 --> Language Class Initialized
INFO - 2024-03-28 08:52:33 --> Loader Class Initialized
INFO - 2024-03-28 08:52:33 --> Helper loaded: url_helper
INFO - 2024-03-28 08:52:33 --> Helper loaded: file_helper
INFO - 2024-03-28 08:52:33 --> Helper loaded: html_helper
INFO - 2024-03-28 08:52:33 --> Helper loaded: text_helper
INFO - 2024-03-28 08:52:33 --> Helper loaded: form_helper
INFO - 2024-03-28 08:52:33 --> Helper loaded: lang_helper
INFO - 2024-03-28 08:52:33 --> Helper loaded: security_helper
INFO - 2024-03-28 08:52:33 --> Helper loaded: cookie_helper
INFO - 2024-03-28 08:52:33 --> Database Driver Class Initialized
INFO - 2024-03-28 08:52:33 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-28 08:52:33 --> Parser Class Initialized
INFO - 2024-03-28 08:52:33 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-03-28 08:52:33 --> Pagination Class Initialized
INFO - 2024-03-28 08:52:33 --> Form Validation Class Initialized
INFO - 2024-03-28 08:52:33 --> Controller Class Initialized
INFO - 2024-03-28 08:52:33 --> Final output sent to browser
DEBUG - 2024-03-28 08:52:33 --> Total execution time: 0.0164
ERROR - 2024-03-28 08:52:40 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-03-28 08:52:40 --> Config Class Initialized
INFO - 2024-03-28 08:52:40 --> Hooks Class Initialized
DEBUG - 2024-03-28 08:52:40 --> UTF-8 Support Enabled
INFO - 2024-03-28 08:52:40 --> Utf8 Class Initialized
INFO - 2024-03-28 08:52:40 --> URI Class Initialized
INFO - 2024-03-28 08:52:40 --> Router Class Initialized
INFO - 2024-03-28 08:52:40 --> Output Class Initialized
INFO - 2024-03-28 08:52:40 --> Security Class Initialized
DEBUG - 2024-03-28 08:52:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-28 08:52:40 --> Input Class Initialized
INFO - 2024-03-28 08:52:40 --> Language Class Initialized
INFO - 2024-03-28 08:52:40 --> Loader Class Initialized
INFO - 2024-03-28 08:52:40 --> Helper loaded: url_helper
INFO - 2024-03-28 08:52:40 --> Helper loaded: file_helper
INFO - 2024-03-28 08:52:40 --> Helper loaded: html_helper
INFO - 2024-03-28 08:52:40 --> Helper loaded: text_helper
INFO - 2024-03-28 08:52:40 --> Helper loaded: form_helper
INFO - 2024-03-28 08:52:40 --> Helper loaded: lang_helper
INFO - 2024-03-28 08:52:40 --> Helper loaded: security_helper
INFO - 2024-03-28 08:52:40 --> Helper loaded: cookie_helper
INFO - 2024-03-28 08:52:40 --> Database Driver Class Initialized
INFO - 2024-03-28 08:52:40 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-28 08:52:40 --> Parser Class Initialized
INFO - 2024-03-28 08:52:40 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-03-28 08:52:40 --> Pagination Class Initialized
INFO - 2024-03-28 08:52:40 --> Form Validation Class Initialized
INFO - 2024-03-28 08:52:40 --> Controller Class Initialized
INFO - 2024-03-28 08:52:40 --> Model Class Initialized
DEBUG - 2024-03-28 08:52:40 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-03-28 08:52:40 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-28 08:52:40 --> Model Class Initialized
DEBUG - 2024-03-28 08:52:40 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-28 08:52:40 --> Model Class Initialized
INFO - 2024-03-28 08:52:40 --> Final output sent to browser
DEBUG - 2024-03-28 08:52:40 --> Total execution time: 0.0194
ERROR - 2024-03-28 08:52:42 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-03-28 08:52:42 --> Config Class Initialized
INFO - 2024-03-28 08:52:42 --> Hooks Class Initialized
DEBUG - 2024-03-28 08:52:42 --> UTF-8 Support Enabled
INFO - 2024-03-28 08:52:42 --> Utf8 Class Initialized
INFO - 2024-03-28 08:52:42 --> URI Class Initialized
INFO - 2024-03-28 08:52:42 --> Router Class Initialized
INFO - 2024-03-28 08:52:42 --> Output Class Initialized
INFO - 2024-03-28 08:52:42 --> Security Class Initialized
DEBUG - 2024-03-28 08:52:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-28 08:52:42 --> Input Class Initialized
INFO - 2024-03-28 08:52:42 --> Language Class Initialized
INFO - 2024-03-28 08:52:42 --> Loader Class Initialized
INFO - 2024-03-28 08:52:42 --> Helper loaded: url_helper
INFO - 2024-03-28 08:52:42 --> Helper loaded: file_helper
INFO - 2024-03-28 08:52:42 --> Helper loaded: html_helper
INFO - 2024-03-28 08:52:42 --> Helper loaded: text_helper
INFO - 2024-03-28 08:52:42 --> Helper loaded: form_helper
INFO - 2024-03-28 08:52:42 --> Helper loaded: lang_helper
INFO - 2024-03-28 08:52:42 --> Helper loaded: security_helper
INFO - 2024-03-28 08:52:42 --> Helper loaded: cookie_helper
INFO - 2024-03-28 08:52:42 --> Database Driver Class Initialized
INFO - 2024-03-28 08:52:42 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-28 08:52:42 --> Parser Class Initialized
INFO - 2024-03-28 08:52:42 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-03-28 08:52:42 --> Pagination Class Initialized
INFO - 2024-03-28 08:52:42 --> Form Validation Class Initialized
INFO - 2024-03-28 08:52:42 --> Controller Class Initialized
INFO - 2024-03-28 08:52:42 --> Model Class Initialized
DEBUG - 2024-03-28 08:52:42 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-03-28 08:52:42 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-28 08:52:42 --> Model Class Initialized
DEBUG - 2024-03-28 08:52:42 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-28 08:52:42 --> Model Class Initialized
INFO - 2024-03-28 08:52:43 --> Final output sent to browser
DEBUG - 2024-03-28 08:52:43 --> Total execution time: 0.2105
ERROR - 2024-03-28 08:52:43 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-03-28 08:52:43 --> Config Class Initialized
INFO - 2024-03-28 08:52:43 --> Hooks Class Initialized
DEBUG - 2024-03-28 08:52:43 --> UTF-8 Support Enabled
INFO - 2024-03-28 08:52:43 --> Utf8 Class Initialized
INFO - 2024-03-28 08:52:43 --> URI Class Initialized
INFO - 2024-03-28 08:52:43 --> Router Class Initialized
INFO - 2024-03-28 08:52:43 --> Output Class Initialized
INFO - 2024-03-28 08:52:43 --> Security Class Initialized
DEBUG - 2024-03-28 08:52:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-28 08:52:43 --> Input Class Initialized
INFO - 2024-03-28 08:52:43 --> Language Class Initialized
INFO - 2024-03-28 08:52:43 --> Loader Class Initialized
INFO - 2024-03-28 08:52:43 --> Helper loaded: url_helper
INFO - 2024-03-28 08:52:43 --> Helper loaded: file_helper
INFO - 2024-03-28 08:52:43 --> Helper loaded: html_helper
INFO - 2024-03-28 08:52:43 --> Helper loaded: text_helper
INFO - 2024-03-28 08:52:43 --> Helper loaded: form_helper
INFO - 2024-03-28 08:52:43 --> Helper loaded: lang_helper
INFO - 2024-03-28 08:52:43 --> Helper loaded: security_helper
INFO - 2024-03-28 08:52:43 --> Helper loaded: cookie_helper
INFO - 2024-03-28 08:52:43 --> Database Driver Class Initialized
INFO - 2024-03-28 08:52:43 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-28 08:52:43 --> Parser Class Initialized
INFO - 2024-03-28 08:52:43 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-03-28 08:52:43 --> Pagination Class Initialized
INFO - 2024-03-28 08:52:43 --> Form Validation Class Initialized
INFO - 2024-03-28 08:52:43 --> Controller Class Initialized
INFO - 2024-03-28 08:52:43 --> Model Class Initialized
DEBUG - 2024-03-28 08:52:43 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-03-28 08:52:43 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-28 08:52:43 --> Model Class Initialized
DEBUG - 2024-03-28 08:52:43 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-28 08:52:43 --> Model Class Initialized
INFO - 2024-03-28 08:52:44 --> Final output sent to browser
DEBUG - 2024-03-28 08:52:44 --> Total execution time: 0.2264
ERROR - 2024-03-28 08:52:44 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-03-28 08:52:44 --> Config Class Initialized
INFO - 2024-03-28 08:52:44 --> Hooks Class Initialized
DEBUG - 2024-03-28 08:52:44 --> UTF-8 Support Enabled
INFO - 2024-03-28 08:52:44 --> Utf8 Class Initialized
INFO - 2024-03-28 08:52:44 --> URI Class Initialized
INFO - 2024-03-28 08:52:44 --> Router Class Initialized
INFO - 2024-03-28 08:52:44 --> Output Class Initialized
INFO - 2024-03-28 08:52:44 --> Security Class Initialized
DEBUG - 2024-03-28 08:52:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-28 08:52:44 --> Input Class Initialized
INFO - 2024-03-28 08:52:44 --> Language Class Initialized
INFO - 2024-03-28 08:52:44 --> Loader Class Initialized
INFO - 2024-03-28 08:52:44 --> Helper loaded: url_helper
INFO - 2024-03-28 08:52:44 --> Helper loaded: file_helper
INFO - 2024-03-28 08:52:44 --> Helper loaded: html_helper
INFO - 2024-03-28 08:52:44 --> Helper loaded: text_helper
INFO - 2024-03-28 08:52:44 --> Helper loaded: form_helper
INFO - 2024-03-28 08:52:44 --> Helper loaded: lang_helper
INFO - 2024-03-28 08:52:44 --> Helper loaded: security_helper
INFO - 2024-03-28 08:52:44 --> Helper loaded: cookie_helper
INFO - 2024-03-28 08:52:44 --> Database Driver Class Initialized
INFO - 2024-03-28 08:52:44 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-28 08:52:44 --> Parser Class Initialized
INFO - 2024-03-28 08:52:44 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-03-28 08:52:44 --> Pagination Class Initialized
INFO - 2024-03-28 08:52:44 --> Form Validation Class Initialized
INFO - 2024-03-28 08:52:44 --> Controller Class Initialized
INFO - 2024-03-28 08:52:44 --> Model Class Initialized
DEBUG - 2024-03-28 08:52:44 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-03-28 08:52:44 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-28 08:52:44 --> Model Class Initialized
DEBUG - 2024-03-28 08:52:44 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-28 08:52:44 --> Model Class Initialized
INFO - 2024-03-28 08:52:45 --> Final output sent to browser
DEBUG - 2024-03-28 08:52:45 --> Total execution time: 0.2136
ERROR - 2024-03-28 08:52:45 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-03-28 08:52:45 --> Config Class Initialized
INFO - 2024-03-28 08:52:45 --> Hooks Class Initialized
DEBUG - 2024-03-28 08:52:45 --> UTF-8 Support Enabled
INFO - 2024-03-28 08:52:45 --> Utf8 Class Initialized
INFO - 2024-03-28 08:52:45 --> URI Class Initialized
INFO - 2024-03-28 08:52:45 --> Router Class Initialized
INFO - 2024-03-28 08:52:45 --> Output Class Initialized
INFO - 2024-03-28 08:52:45 --> Security Class Initialized
DEBUG - 2024-03-28 08:52:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-28 08:52:45 --> Input Class Initialized
INFO - 2024-03-28 08:52:45 --> Language Class Initialized
INFO - 2024-03-28 08:52:45 --> Loader Class Initialized
INFO - 2024-03-28 08:52:45 --> Helper loaded: url_helper
INFO - 2024-03-28 08:52:45 --> Helper loaded: file_helper
INFO - 2024-03-28 08:52:45 --> Helper loaded: html_helper
INFO - 2024-03-28 08:52:45 --> Helper loaded: text_helper
INFO - 2024-03-28 08:52:45 --> Helper loaded: form_helper
INFO - 2024-03-28 08:52:45 --> Helper loaded: lang_helper
INFO - 2024-03-28 08:52:45 --> Helper loaded: security_helper
INFO - 2024-03-28 08:52:45 --> Helper loaded: cookie_helper
INFO - 2024-03-28 08:52:45 --> Database Driver Class Initialized
INFO - 2024-03-28 08:52:45 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-28 08:52:45 --> Parser Class Initialized
INFO - 2024-03-28 08:52:45 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-03-28 08:52:45 --> Pagination Class Initialized
INFO - 2024-03-28 08:52:45 --> Form Validation Class Initialized
INFO - 2024-03-28 08:52:45 --> Controller Class Initialized
INFO - 2024-03-28 08:52:45 --> Model Class Initialized
DEBUG - 2024-03-28 08:52:45 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-03-28 08:52:45 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-28 08:52:45 --> Model Class Initialized
DEBUG - 2024-03-28 08:52:45 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-28 08:52:45 --> Model Class Initialized
INFO - 2024-03-28 08:52:45 --> Final output sent to browser
DEBUG - 2024-03-28 08:52:45 --> Total execution time: 0.2103
ERROR - 2024-03-28 08:52:46 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-03-28 08:52:46 --> Config Class Initialized
INFO - 2024-03-28 08:52:46 --> Hooks Class Initialized
DEBUG - 2024-03-28 08:52:46 --> UTF-8 Support Enabled
INFO - 2024-03-28 08:52:46 --> Utf8 Class Initialized
INFO - 2024-03-28 08:52:46 --> URI Class Initialized
INFO - 2024-03-28 08:52:46 --> Router Class Initialized
INFO - 2024-03-28 08:52:46 --> Output Class Initialized
INFO - 2024-03-28 08:52:46 --> Security Class Initialized
DEBUG - 2024-03-28 08:52:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-28 08:52:46 --> Input Class Initialized
INFO - 2024-03-28 08:52:46 --> Language Class Initialized
INFO - 2024-03-28 08:52:46 --> Loader Class Initialized
INFO - 2024-03-28 08:52:46 --> Helper loaded: url_helper
INFO - 2024-03-28 08:52:46 --> Helper loaded: file_helper
INFO - 2024-03-28 08:52:46 --> Helper loaded: html_helper
INFO - 2024-03-28 08:52:46 --> Helper loaded: text_helper
INFO - 2024-03-28 08:52:46 --> Helper loaded: form_helper
INFO - 2024-03-28 08:52:46 --> Helper loaded: lang_helper
INFO - 2024-03-28 08:52:46 --> Helper loaded: security_helper
INFO - 2024-03-28 08:52:46 --> Helper loaded: cookie_helper
INFO - 2024-03-28 08:52:46 --> Database Driver Class Initialized
INFO - 2024-03-28 08:52:46 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-28 08:52:46 --> Parser Class Initialized
INFO - 2024-03-28 08:52:46 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-03-28 08:52:46 --> Pagination Class Initialized
INFO - 2024-03-28 08:52:46 --> Form Validation Class Initialized
INFO - 2024-03-28 08:52:46 --> Controller Class Initialized
INFO - 2024-03-28 08:52:46 --> Model Class Initialized
DEBUG - 2024-03-28 08:52:46 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-03-28 08:52:46 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-28 08:52:46 --> Model Class Initialized
DEBUG - 2024-03-28 08:52:46 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-28 08:52:46 --> Model Class Initialized
INFO - 2024-03-28 08:52:46 --> Final output sent to browser
DEBUG - 2024-03-28 08:52:46 --> Total execution time: 0.0767
ERROR - 2024-03-28 08:52:47 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-03-28 08:52:47 --> Config Class Initialized
INFO - 2024-03-28 08:52:47 --> Hooks Class Initialized
DEBUG - 2024-03-28 08:52:47 --> UTF-8 Support Enabled
INFO - 2024-03-28 08:52:47 --> Utf8 Class Initialized
INFO - 2024-03-28 08:52:47 --> URI Class Initialized
INFO - 2024-03-28 08:52:47 --> Router Class Initialized
INFO - 2024-03-28 08:52:47 --> Output Class Initialized
INFO - 2024-03-28 08:52:47 --> Security Class Initialized
DEBUG - 2024-03-28 08:52:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-28 08:52:47 --> Input Class Initialized
INFO - 2024-03-28 08:52:47 --> Language Class Initialized
INFO - 2024-03-28 08:52:47 --> Loader Class Initialized
INFO - 2024-03-28 08:52:47 --> Helper loaded: url_helper
INFO - 2024-03-28 08:52:47 --> Helper loaded: file_helper
INFO - 2024-03-28 08:52:47 --> Helper loaded: html_helper
INFO - 2024-03-28 08:52:47 --> Helper loaded: text_helper
INFO - 2024-03-28 08:52:47 --> Helper loaded: form_helper
INFO - 2024-03-28 08:52:47 --> Helper loaded: lang_helper
INFO - 2024-03-28 08:52:47 --> Helper loaded: security_helper
INFO - 2024-03-28 08:52:47 --> Helper loaded: cookie_helper
INFO - 2024-03-28 08:52:47 --> Database Driver Class Initialized
INFO - 2024-03-28 08:52:48 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-28 08:52:48 --> Parser Class Initialized
INFO - 2024-03-28 08:52:48 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-03-28 08:52:48 --> Pagination Class Initialized
INFO - 2024-03-28 08:52:48 --> Form Validation Class Initialized
INFO - 2024-03-28 08:52:48 --> Controller Class Initialized
INFO - 2024-03-28 08:52:48 --> Model Class Initialized
DEBUG - 2024-03-28 08:52:48 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-03-28 08:52:48 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-28 08:52:48 --> Model Class Initialized
DEBUG - 2024-03-28 08:52:48 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-28 08:52:48 --> Model Class Initialized
INFO - 2024-03-28 08:52:48 --> Final output sent to browser
DEBUG - 2024-03-28 08:52:48 --> Total execution time: 0.0280
ERROR - 2024-03-28 08:52:49 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-03-28 08:52:49 --> Config Class Initialized
INFO - 2024-03-28 08:52:49 --> Hooks Class Initialized
DEBUG - 2024-03-28 08:52:49 --> UTF-8 Support Enabled
INFO - 2024-03-28 08:52:49 --> Utf8 Class Initialized
INFO - 2024-03-28 08:52:49 --> URI Class Initialized
INFO - 2024-03-28 08:52:49 --> Router Class Initialized
INFO - 2024-03-28 08:52:49 --> Output Class Initialized
INFO - 2024-03-28 08:52:49 --> Security Class Initialized
DEBUG - 2024-03-28 08:52:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-28 08:52:49 --> Input Class Initialized
INFO - 2024-03-28 08:52:49 --> Language Class Initialized
INFO - 2024-03-28 08:52:49 --> Loader Class Initialized
INFO - 2024-03-28 08:52:49 --> Helper loaded: url_helper
INFO - 2024-03-28 08:52:49 --> Helper loaded: file_helper
INFO - 2024-03-28 08:52:49 --> Helper loaded: html_helper
INFO - 2024-03-28 08:52:49 --> Helper loaded: text_helper
INFO - 2024-03-28 08:52:49 --> Helper loaded: form_helper
INFO - 2024-03-28 08:52:49 --> Helper loaded: lang_helper
INFO - 2024-03-28 08:52:49 --> Helper loaded: security_helper
INFO - 2024-03-28 08:52:49 --> Helper loaded: cookie_helper
INFO - 2024-03-28 08:52:49 --> Database Driver Class Initialized
INFO - 2024-03-28 08:52:49 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-28 08:52:49 --> Parser Class Initialized
INFO - 2024-03-28 08:52:49 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-03-28 08:52:49 --> Pagination Class Initialized
INFO - 2024-03-28 08:52:49 --> Form Validation Class Initialized
INFO - 2024-03-28 08:52:49 --> Controller Class Initialized
INFO - 2024-03-28 08:52:49 --> Model Class Initialized
DEBUG - 2024-03-28 08:52:49 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-03-28 08:52:49 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-28 08:52:49 --> Model Class Initialized
INFO - 2024-03-28 08:52:49 --> Model Class Initialized
INFO - 2024-03-28 08:52:49 --> Final output sent to browser
DEBUG - 2024-03-28 08:52:49 --> Total execution time: 0.0217
ERROR - 2024-03-28 08:52:50 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-03-28 08:52:50 --> Config Class Initialized
INFO - 2024-03-28 08:52:50 --> Hooks Class Initialized
DEBUG - 2024-03-28 08:52:50 --> UTF-8 Support Enabled
INFO - 2024-03-28 08:52:50 --> Utf8 Class Initialized
INFO - 2024-03-28 08:52:50 --> URI Class Initialized
INFO - 2024-03-28 08:52:50 --> Router Class Initialized
INFO - 2024-03-28 08:52:50 --> Output Class Initialized
INFO - 2024-03-28 08:52:50 --> Security Class Initialized
DEBUG - 2024-03-28 08:52:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-28 08:52:50 --> Input Class Initialized
INFO - 2024-03-28 08:52:50 --> Language Class Initialized
INFO - 2024-03-28 08:52:50 --> Loader Class Initialized
INFO - 2024-03-28 08:52:50 --> Helper loaded: url_helper
INFO - 2024-03-28 08:52:50 --> Helper loaded: file_helper
INFO - 2024-03-28 08:52:50 --> Helper loaded: html_helper
INFO - 2024-03-28 08:52:50 --> Helper loaded: text_helper
INFO - 2024-03-28 08:52:50 --> Helper loaded: form_helper
INFO - 2024-03-28 08:52:50 --> Helper loaded: lang_helper
INFO - 2024-03-28 08:52:50 --> Helper loaded: security_helper
INFO - 2024-03-28 08:52:50 --> Helper loaded: cookie_helper
INFO - 2024-03-28 08:52:50 --> Database Driver Class Initialized
INFO - 2024-03-28 08:52:50 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-28 08:52:50 --> Parser Class Initialized
INFO - 2024-03-28 08:52:50 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-03-28 08:52:50 --> Pagination Class Initialized
INFO - 2024-03-28 08:52:50 --> Form Validation Class Initialized
INFO - 2024-03-28 08:52:50 --> Controller Class Initialized
INFO - 2024-03-28 08:52:50 --> Model Class Initialized
DEBUG - 2024-03-28 08:52:50 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-03-28 08:52:50 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-28 08:52:50 --> Model Class Initialized
INFO - 2024-03-28 08:52:50 --> Final output sent to browser
DEBUG - 2024-03-28 08:52:50 --> Total execution time: 0.0155
ERROR - 2024-03-28 08:52:51 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-03-28 08:52:51 --> Config Class Initialized
INFO - 2024-03-28 08:52:51 --> Hooks Class Initialized
DEBUG - 2024-03-28 08:52:51 --> UTF-8 Support Enabled
INFO - 2024-03-28 08:52:51 --> Utf8 Class Initialized
INFO - 2024-03-28 08:52:51 --> URI Class Initialized
INFO - 2024-03-28 08:52:51 --> Router Class Initialized
INFO - 2024-03-28 08:52:51 --> Output Class Initialized
INFO - 2024-03-28 08:52:51 --> Security Class Initialized
DEBUG - 2024-03-28 08:52:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-28 08:52:51 --> Input Class Initialized
INFO - 2024-03-28 08:52:51 --> Language Class Initialized
INFO - 2024-03-28 08:52:51 --> Loader Class Initialized
INFO - 2024-03-28 08:52:51 --> Helper loaded: url_helper
INFO - 2024-03-28 08:52:51 --> Helper loaded: file_helper
INFO - 2024-03-28 08:52:51 --> Helper loaded: html_helper
INFO - 2024-03-28 08:52:51 --> Helper loaded: text_helper
INFO - 2024-03-28 08:52:51 --> Helper loaded: form_helper
INFO - 2024-03-28 08:52:51 --> Helper loaded: lang_helper
INFO - 2024-03-28 08:52:51 --> Helper loaded: security_helper
INFO - 2024-03-28 08:52:51 --> Helper loaded: cookie_helper
INFO - 2024-03-28 08:52:51 --> Database Driver Class Initialized
INFO - 2024-03-28 08:52:51 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-28 08:52:51 --> Parser Class Initialized
INFO - 2024-03-28 08:52:51 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-03-28 08:52:51 --> Pagination Class Initialized
INFO - 2024-03-28 08:52:51 --> Form Validation Class Initialized
INFO - 2024-03-28 08:52:51 --> Controller Class Initialized
INFO - 2024-03-28 08:52:51 --> Model Class Initialized
DEBUG - 2024-03-28 08:52:51 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-03-28 08:52:51 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-28 08:52:51 --> Model Class Initialized
INFO - 2024-03-28 08:52:51 --> Final output sent to browser
DEBUG - 2024-03-28 08:52:51 --> Total execution time: 0.0186
ERROR - 2024-03-28 08:53:04 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-03-28 08:53:04 --> Config Class Initialized
INFO - 2024-03-28 08:53:04 --> Hooks Class Initialized
DEBUG - 2024-03-28 08:53:04 --> UTF-8 Support Enabled
INFO - 2024-03-28 08:53:04 --> Utf8 Class Initialized
INFO - 2024-03-28 08:53:04 --> URI Class Initialized
INFO - 2024-03-28 08:53:04 --> Router Class Initialized
INFO - 2024-03-28 08:53:04 --> Output Class Initialized
INFO - 2024-03-28 08:53:04 --> Security Class Initialized
DEBUG - 2024-03-28 08:53:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-28 08:53:04 --> Input Class Initialized
INFO - 2024-03-28 08:53:04 --> Language Class Initialized
INFO - 2024-03-28 08:53:04 --> Loader Class Initialized
INFO - 2024-03-28 08:53:04 --> Helper loaded: url_helper
INFO - 2024-03-28 08:53:04 --> Helper loaded: file_helper
INFO - 2024-03-28 08:53:04 --> Helper loaded: html_helper
INFO - 2024-03-28 08:53:04 --> Helper loaded: text_helper
INFO - 2024-03-28 08:53:04 --> Helper loaded: form_helper
INFO - 2024-03-28 08:53:04 --> Helper loaded: lang_helper
INFO - 2024-03-28 08:53:04 --> Helper loaded: security_helper
INFO - 2024-03-28 08:53:04 --> Helper loaded: cookie_helper
INFO - 2024-03-28 08:53:04 --> Database Driver Class Initialized
INFO - 2024-03-28 08:53:04 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-28 08:53:04 --> Parser Class Initialized
INFO - 2024-03-28 08:53:04 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-03-28 08:53:04 --> Pagination Class Initialized
INFO - 2024-03-28 08:53:04 --> Form Validation Class Initialized
INFO - 2024-03-28 08:53:04 --> Controller Class Initialized
INFO - 2024-03-28 08:53:04 --> Model Class Initialized
DEBUG - 2024-03-28 08:53:04 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-03-28 08:53:04 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-28 08:53:04 --> Model Class Initialized
DEBUG - 2024-03-28 08:53:04 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-28 08:53:04 --> Model Class Initialized
INFO - 2024-03-28 08:53:04 --> Email Class Initialized
DEBUG - 2024-03-28 08:53:04 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-28 08:53:04 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice_html_pdf.php
ERROR - 2024-03-28 08:53:04 --> Severity: Warning --> "continue" targeting switch is equivalent to "break". Did you mean to use "continue 2"? /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/dompdf.cls.php 743
ERROR - 2024-03-28 08:53:04 --> Severity: Warning --> "continue" targeting switch is equivalent to "break". Did you mean to use "continue 2"? /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/dompdf.cls.php 763
ERROR - 2024-03-28 08:53:04 --> Severity: Warning --> "continue" targeting switch is equivalent to "break". Did you mean to use "continue 2"? /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/stylesheet.cls.php 1102
ERROR - 2024-03-28 08:53:04 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/page_frame_decorator.cls.php 439
ERROR - 2024-03-28 08:53:04 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/page_frame_decorator.cls.php 439
ERROR - 2024-03-28 08:53:04 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/page_frame_decorator.cls.php 439
ERROR - 2024-03-28 08:53:04 --> Severity: Warning --> Division by zero /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 572
ERROR - 2024-03-28 08:53:04 --> Severity: Warning --> Division by zero /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 572
ERROR - 2024-03-28 08:53:04 --> Severity: Warning --> Division by zero /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 572
ERROR - 2024-03-28 08:53:04 --> Severity: Warning --> Division by zero /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 572
ERROR - 2024-03-28 08:53:04 --> Severity: Warning --> Division by zero /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 572
ERROR - 2024-03-28 08:53:04 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/table_cell_frame_reflower.cls.php 103
ERROR - 2024-03-28 08:53:04 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/table_cell_frame_reflower.cls.php 103
ERROR - 2024-03-28 08:53:04 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/table_cell_frame_reflower.cls.php 103
ERROR - 2024-03-28 08:53:04 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/table_cell_frame_reflower.cls.php 103
ERROR - 2024-03-28 08:53:04 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/table_cell_frame_reflower.cls.php 103
ERROR - 2024-03-28 08:53:04 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/table_cell_frame_reflower.cls.php 103
ERROR - 2024-03-28 08:53:04 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/table_cell_frame_reflower.cls.php 103
ERROR - 2024-03-28 08:53:04 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/table_cell_frame_reflower.cls.php 103
ERROR - 2024-03-28 08:53:04 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/table_cell_frame_reflower.cls.php 103
ERROR - 2024-03-28 08:53:04 --> Severity: Warning --> Invalid argument supplied for foreach() /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 709
ERROR - 2024-03-28 08:53:04 --> Severity: Warning --> Invalid argument supplied for foreach() /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 709
ERROR - 2024-03-28 08:53:04 --> Severity: Warning --> Invalid argument supplied for foreach() /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 709
ERROR - 2024-03-28 08:53:04 --> Severity: Warning --> Invalid argument supplied for foreach() /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 709
ERROR - 2024-03-28 08:53:04 --> Severity: Warning --> Invalid argument supplied for foreach() /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 709
ERROR - 2024-03-28 08:53:04 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-03-28 08:53:04 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-03-28 08:53:04 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-03-28 08:53:04 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-03-28 08:53:04 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-03-28 08:53:04 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-03-28 08:53:04 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-03-28 08:53:04 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-03-28 08:53:04 --> Severity: Warning --> "continue" targeting switch is equivalent to "break". Did you mean to use "continue 2"? /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/text_renderer.cls.php 126
ERROR - 2024-03-28 08:53:04 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-03-28 08:53:04 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-03-28 08:53:04 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-03-28 08:53:04 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-03-28 08:53:04 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-03-28 08:53:04 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-03-28 08:53:04 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-03-28 08:53:04 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-03-28 08:53:04 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-03-28 08:53:04 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-03-28 08:53:04 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-03-28 08:53:04 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-03-28 08:53:04 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-03-28 08:53:04 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-03-28 08:53:04 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-03-28 08:53:04 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-03-28 08:53:04 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-03-28 08:53:04 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-03-28 08:53:04 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-03-28 08:53:04 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-03-28 08:53:04 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-03-28 08:53:04 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-03-28 08:53:04 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-03-28 08:53:04 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-03-28 08:53:04 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-03-28 08:53:04 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-03-28 08:53:04 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-03-28 08:53:04 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-03-28 08:53:04 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-03-28 08:53:04 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-03-28 08:53:04 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-03-28 08:53:04 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-03-28 08:53:04 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-03-28 08:53:04 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-03-28 08:53:04 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-03-28 08:53:04 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-03-28 08:53:04 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-03-28 08:53:04 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-03-28 08:53:04 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-03-28 08:53:04 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-03-28 08:53:04 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-03-28 08:53:04 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-03-28 08:53:04 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-03-28 08:53:04 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-03-28 08:53:04 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-03-28 08:53:04 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-03-28 08:53:04 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-03-28 08:53:04 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-03-28 08:53:04 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-03-28 08:53:04 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-03-28 08:53:04 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-03-28 08:53:04 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-03-28 08:53:04 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-03-28 08:53:04 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-03-28 08:53:04 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-03-28 08:53:04 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-03-28 08:53:04 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-03-28 08:53:04 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-03-28 08:53:04 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-03-28 08:53:04 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-03-28 08:53:04 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-03-28 08:53:04 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-03-28 08:53:04 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-03-28 08:53:04 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-03-28 08:53:04 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-03-28 08:53:04 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-03-28 08:53:04 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-03-28 08:53:04 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-03-28 08:53:04 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-03-28 08:53:04 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-03-28 08:53:04 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-03-28 08:53:04 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-03-28 08:53:04 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-03-28 08:53:04 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-03-28 08:53:04 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-03-28 08:53:04 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-03-28 08:53:04 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-03-28 08:53:04 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-03-28 08:53:04 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-03-28 08:53:04 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-03-28 08:53:04 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-03-28 08:53:04 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-03-28 08:53:04 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-03-28 08:53:04 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-03-28 08:53:04 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-03-28 08:53:04 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-03-28 08:53:04 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-03-28 08:53:04 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-03-28 08:53:04 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-03-28 08:53:04 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-03-28 08:53:04 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-03-28 08:53:04 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-03-28 08:53:04 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-03-28 08:53:04 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-03-28 08:53:04 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-03-28 08:53:04 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
INFO - 2024-03-28 08:53:04 --> Language file loaded: language/english/email_lang.php
INFO - 2024-03-28 08:53:04 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice_html.php
INFO - 2024-03-28 08:53:04 --> Final output sent to browser
DEBUG - 2024-03-28 08:53:04 --> Total execution time: 0.2298
ERROR - 2024-03-28 08:53:07 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-03-28 08:53:07 --> Config Class Initialized
INFO - 2024-03-28 08:53:07 --> Hooks Class Initialized
DEBUG - 2024-03-28 08:53:07 --> UTF-8 Support Enabled
INFO - 2024-03-28 08:53:07 --> Utf8 Class Initialized
INFO - 2024-03-28 08:53:07 --> URI Class Initialized
INFO - 2024-03-28 08:53:07 --> Router Class Initialized
INFO - 2024-03-28 08:53:07 --> Output Class Initialized
INFO - 2024-03-28 08:53:07 --> Security Class Initialized
DEBUG - 2024-03-28 08:53:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-28 08:53:07 --> Input Class Initialized
INFO - 2024-03-28 08:53:07 --> Language Class Initialized
INFO - 2024-03-28 08:53:07 --> Loader Class Initialized
INFO - 2024-03-28 08:53:07 --> Helper loaded: url_helper
INFO - 2024-03-28 08:53:07 --> Helper loaded: file_helper
INFO - 2024-03-28 08:53:07 --> Helper loaded: html_helper
INFO - 2024-03-28 08:53:07 --> Helper loaded: text_helper
INFO - 2024-03-28 08:53:07 --> Helper loaded: form_helper
INFO - 2024-03-28 08:53:07 --> Helper loaded: lang_helper
INFO - 2024-03-28 08:53:07 --> Helper loaded: security_helper
INFO - 2024-03-28 08:53:07 --> Helper loaded: cookie_helper
INFO - 2024-03-28 08:53:07 --> Database Driver Class Initialized
INFO - 2024-03-28 08:53:07 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-28 08:53:07 --> Parser Class Initialized
INFO - 2024-03-28 08:53:07 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-03-28 08:53:07 --> Pagination Class Initialized
INFO - 2024-03-28 08:53:07 --> Form Validation Class Initialized
INFO - 2024-03-28 08:53:07 --> Controller Class Initialized
INFO - 2024-03-28 08:53:07 --> Model Class Initialized
DEBUG - 2024-03-28 08:53:07 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-03-28 08:53:07 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-28 08:53:07 --> Model Class Initialized
DEBUG - 2024-03-28 08:53:07 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-28 08:53:07 --> Model Class Initialized
INFO - 2024-03-28 08:53:07 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/add_invoice_form.php
DEBUG - 2024-03-28 08:53:07 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-03-28 08:53:07 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-03-28 08:53:07 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-03-28 08:53:07 --> Model Class Initialized
INFO - 2024-03-28 08:53:07 --> Model Class Initialized
INFO - 2024-03-28 08:53:07 --> Model Class Initialized
INFO - 2024-03-28 08:53:07 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-03-28 08:53:07 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-03-28 08:53:07 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-03-28 08:53:07 --> Final output sent to browser
DEBUG - 2024-03-28 08:53:07 --> Total execution time: 0.2011
ERROR - 2024-03-28 08:53:12 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-03-28 08:53:12 --> Config Class Initialized
INFO - 2024-03-28 08:53:12 --> Hooks Class Initialized
DEBUG - 2024-03-28 08:53:12 --> UTF-8 Support Enabled
INFO - 2024-03-28 08:53:12 --> Utf8 Class Initialized
INFO - 2024-03-28 08:53:12 --> URI Class Initialized
INFO - 2024-03-28 08:53:12 --> Router Class Initialized
INFO - 2024-03-28 08:53:12 --> Output Class Initialized
INFO - 2024-03-28 08:53:12 --> Security Class Initialized
DEBUG - 2024-03-28 08:53:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-28 08:53:12 --> Input Class Initialized
INFO - 2024-03-28 08:53:12 --> Language Class Initialized
INFO - 2024-03-28 08:53:12 --> Loader Class Initialized
INFO - 2024-03-28 08:53:12 --> Helper loaded: url_helper
INFO - 2024-03-28 08:53:12 --> Helper loaded: file_helper
INFO - 2024-03-28 08:53:12 --> Helper loaded: html_helper
INFO - 2024-03-28 08:53:12 --> Helper loaded: text_helper
INFO - 2024-03-28 08:53:12 --> Helper loaded: form_helper
INFO - 2024-03-28 08:53:12 --> Helper loaded: lang_helper
INFO - 2024-03-28 08:53:12 --> Helper loaded: security_helper
INFO - 2024-03-28 08:53:12 --> Helper loaded: cookie_helper
INFO - 2024-03-28 08:53:12 --> Database Driver Class Initialized
INFO - 2024-03-28 08:53:12 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-28 08:53:12 --> Parser Class Initialized
INFO - 2024-03-28 08:53:12 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-03-28 08:53:12 --> Pagination Class Initialized
INFO - 2024-03-28 08:53:12 --> Form Validation Class Initialized
INFO - 2024-03-28 08:53:12 --> Controller Class Initialized
INFO - 2024-03-28 08:53:12 --> Model Class Initialized
DEBUG - 2024-03-28 08:53:12 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-28 08:53:12 --> Final output sent to browser
DEBUG - 2024-03-28 08:53:12 --> Total execution time: 0.0152
ERROR - 2024-03-28 08:53:13 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-03-28 08:53:13 --> Config Class Initialized
INFO - 2024-03-28 08:53:13 --> Hooks Class Initialized
DEBUG - 2024-03-28 08:53:13 --> UTF-8 Support Enabled
INFO - 2024-03-28 08:53:13 --> Utf8 Class Initialized
INFO - 2024-03-28 08:53:13 --> URI Class Initialized
INFO - 2024-03-28 08:53:13 --> Router Class Initialized
INFO - 2024-03-28 08:53:13 --> Output Class Initialized
INFO - 2024-03-28 08:53:13 --> Security Class Initialized
DEBUG - 2024-03-28 08:53:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-28 08:53:13 --> Input Class Initialized
INFO - 2024-03-28 08:53:13 --> Language Class Initialized
INFO - 2024-03-28 08:53:13 --> Loader Class Initialized
INFO - 2024-03-28 08:53:13 --> Helper loaded: url_helper
INFO - 2024-03-28 08:53:13 --> Helper loaded: file_helper
INFO - 2024-03-28 08:53:13 --> Helper loaded: html_helper
INFO - 2024-03-28 08:53:13 --> Helper loaded: text_helper
INFO - 2024-03-28 08:53:13 --> Helper loaded: form_helper
INFO - 2024-03-28 08:53:13 --> Helper loaded: lang_helper
INFO - 2024-03-28 08:53:13 --> Helper loaded: security_helper
INFO - 2024-03-28 08:53:13 --> Helper loaded: cookie_helper
INFO - 2024-03-28 08:53:13 --> Database Driver Class Initialized
INFO - 2024-03-28 08:53:13 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-28 08:53:13 --> Parser Class Initialized
INFO - 2024-03-28 08:53:13 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-03-28 08:53:13 --> Pagination Class Initialized
INFO - 2024-03-28 08:53:13 --> Form Validation Class Initialized
INFO - 2024-03-28 08:53:13 --> Controller Class Initialized
INFO - 2024-03-28 08:53:13 --> Model Class Initialized
DEBUG - 2024-03-28 08:53:13 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-28 08:53:13 --> Final output sent to browser
DEBUG - 2024-03-28 08:53:13 --> Total execution time: 0.0196
ERROR - 2024-03-28 08:53:13 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-03-28 08:53:13 --> Config Class Initialized
INFO - 2024-03-28 08:53:13 --> Hooks Class Initialized
DEBUG - 2024-03-28 08:53:13 --> UTF-8 Support Enabled
INFO - 2024-03-28 08:53:13 --> Utf8 Class Initialized
INFO - 2024-03-28 08:53:13 --> URI Class Initialized
INFO - 2024-03-28 08:53:13 --> Router Class Initialized
INFO - 2024-03-28 08:53:13 --> Output Class Initialized
INFO - 2024-03-28 08:53:13 --> Security Class Initialized
DEBUG - 2024-03-28 08:53:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-28 08:53:13 --> Input Class Initialized
INFO - 2024-03-28 08:53:13 --> Language Class Initialized
INFO - 2024-03-28 08:53:13 --> Loader Class Initialized
INFO - 2024-03-28 08:53:13 --> Helper loaded: url_helper
INFO - 2024-03-28 08:53:13 --> Helper loaded: file_helper
INFO - 2024-03-28 08:53:13 --> Helper loaded: html_helper
INFO - 2024-03-28 08:53:13 --> Helper loaded: text_helper
INFO - 2024-03-28 08:53:13 --> Helper loaded: form_helper
INFO - 2024-03-28 08:53:13 --> Helper loaded: lang_helper
INFO - 2024-03-28 08:53:13 --> Helper loaded: security_helper
INFO - 2024-03-28 08:53:13 --> Helper loaded: cookie_helper
INFO - 2024-03-28 08:53:13 --> Database Driver Class Initialized
INFO - 2024-03-28 08:53:13 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-28 08:53:13 --> Parser Class Initialized
INFO - 2024-03-28 08:53:13 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-03-28 08:53:13 --> Pagination Class Initialized
INFO - 2024-03-28 08:53:13 --> Form Validation Class Initialized
INFO - 2024-03-28 08:53:13 --> Controller Class Initialized
INFO - 2024-03-28 08:53:13 --> Model Class Initialized
DEBUG - 2024-03-28 08:53:13 --> Session class already loaded. Second attempt ignored.
ERROR - 2024-03-28 08:53:13 --> Severity: Warning --> Invalid argument supplied for foreach() /home/powera7m/app.maurnaturo.com/application/controllers/Cproformainvoice.php 664
INFO - 2024-03-28 08:53:13 --> Final output sent to browser
DEBUG - 2024-03-28 08:53:13 --> Total execution time: 0.0164
ERROR - 2024-03-28 08:53:14 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-03-28 08:53:14 --> Config Class Initialized
INFO - 2024-03-28 08:53:14 --> Hooks Class Initialized
DEBUG - 2024-03-28 08:53:14 --> UTF-8 Support Enabled
INFO - 2024-03-28 08:53:14 --> Utf8 Class Initialized
INFO - 2024-03-28 08:53:14 --> URI Class Initialized
INFO - 2024-03-28 08:53:14 --> Router Class Initialized
INFO - 2024-03-28 08:53:14 --> Output Class Initialized
INFO - 2024-03-28 08:53:14 --> Security Class Initialized
DEBUG - 2024-03-28 08:53:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-28 08:53:14 --> Input Class Initialized
INFO - 2024-03-28 08:53:14 --> Language Class Initialized
INFO - 2024-03-28 08:53:14 --> Loader Class Initialized
INFO - 2024-03-28 08:53:14 --> Helper loaded: url_helper
INFO - 2024-03-28 08:53:14 --> Helper loaded: file_helper
INFO - 2024-03-28 08:53:14 --> Helper loaded: html_helper
INFO - 2024-03-28 08:53:14 --> Helper loaded: text_helper
INFO - 2024-03-28 08:53:14 --> Helper loaded: form_helper
INFO - 2024-03-28 08:53:14 --> Helper loaded: lang_helper
INFO - 2024-03-28 08:53:14 --> Helper loaded: security_helper
INFO - 2024-03-28 08:53:14 --> Helper loaded: cookie_helper
INFO - 2024-03-28 08:53:14 --> Database Driver Class Initialized
INFO - 2024-03-28 08:53:14 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-28 08:53:14 --> Parser Class Initialized
INFO - 2024-03-28 08:53:14 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-03-28 08:53:14 --> Pagination Class Initialized
INFO - 2024-03-28 08:53:14 --> Form Validation Class Initialized
INFO - 2024-03-28 08:53:14 --> Controller Class Initialized
INFO - 2024-03-28 08:53:14 --> Model Class Initialized
DEBUG - 2024-03-28 08:53:14 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-28 08:53:14 --> Final output sent to browser
DEBUG - 2024-03-28 08:53:14 --> Total execution time: 0.0144
ERROR - 2024-03-28 08:53:14 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-03-28 08:53:14 --> Config Class Initialized
INFO - 2024-03-28 08:53:14 --> Hooks Class Initialized
DEBUG - 2024-03-28 08:53:14 --> UTF-8 Support Enabled
INFO - 2024-03-28 08:53:14 --> Utf8 Class Initialized
INFO - 2024-03-28 08:53:14 --> URI Class Initialized
INFO - 2024-03-28 08:53:14 --> Router Class Initialized
INFO - 2024-03-28 08:53:14 --> Output Class Initialized
INFO - 2024-03-28 08:53:14 --> Security Class Initialized
DEBUG - 2024-03-28 08:53:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-28 08:53:14 --> Input Class Initialized
INFO - 2024-03-28 08:53:14 --> Language Class Initialized
INFO - 2024-03-28 08:53:14 --> Loader Class Initialized
INFO - 2024-03-28 08:53:14 --> Helper loaded: url_helper
INFO - 2024-03-28 08:53:14 --> Helper loaded: file_helper
INFO - 2024-03-28 08:53:14 --> Helper loaded: html_helper
INFO - 2024-03-28 08:53:14 --> Helper loaded: text_helper
INFO - 2024-03-28 08:53:14 --> Helper loaded: form_helper
INFO - 2024-03-28 08:53:14 --> Helper loaded: lang_helper
INFO - 2024-03-28 08:53:14 --> Helper loaded: security_helper
INFO - 2024-03-28 08:53:14 --> Helper loaded: cookie_helper
INFO - 2024-03-28 08:53:14 --> Database Driver Class Initialized
INFO - 2024-03-28 08:53:14 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-28 08:53:14 --> Parser Class Initialized
INFO - 2024-03-28 08:53:14 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-03-28 08:53:14 --> Pagination Class Initialized
INFO - 2024-03-28 08:53:14 --> Form Validation Class Initialized
INFO - 2024-03-28 08:53:14 --> Controller Class Initialized
INFO - 2024-03-28 08:53:14 --> Model Class Initialized
DEBUG - 2024-03-28 08:53:14 --> Session class already loaded. Second attempt ignored.
ERROR - 2024-03-28 08:53:14 --> Severity: Warning --> Invalid argument supplied for foreach() /home/powera7m/app.maurnaturo.com/application/controllers/Cproformainvoice.php 664
INFO - 2024-03-28 08:53:14 --> Final output sent to browser
DEBUG - 2024-03-28 08:53:14 --> Total execution time: 0.0144
ERROR - 2024-03-28 08:53:16 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-03-28 08:53:16 --> Config Class Initialized
INFO - 2024-03-28 08:53:16 --> Hooks Class Initialized
DEBUG - 2024-03-28 08:53:16 --> UTF-8 Support Enabled
INFO - 2024-03-28 08:53:16 --> Utf8 Class Initialized
INFO - 2024-03-28 08:53:16 --> URI Class Initialized
INFO - 2024-03-28 08:53:16 --> Router Class Initialized
INFO - 2024-03-28 08:53:16 --> Output Class Initialized
INFO - 2024-03-28 08:53:16 --> Security Class Initialized
DEBUG - 2024-03-28 08:53:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-28 08:53:16 --> Input Class Initialized
INFO - 2024-03-28 08:53:16 --> Language Class Initialized
INFO - 2024-03-28 08:53:16 --> Loader Class Initialized
INFO - 2024-03-28 08:53:16 --> Helper loaded: url_helper
INFO - 2024-03-28 08:53:16 --> Helper loaded: file_helper
INFO - 2024-03-28 08:53:16 --> Helper loaded: html_helper
INFO - 2024-03-28 08:53:16 --> Helper loaded: text_helper
INFO - 2024-03-28 08:53:16 --> Helper loaded: form_helper
INFO - 2024-03-28 08:53:16 --> Helper loaded: lang_helper
INFO - 2024-03-28 08:53:16 --> Helper loaded: security_helper
INFO - 2024-03-28 08:53:16 --> Helper loaded: cookie_helper
INFO - 2024-03-28 08:53:16 --> Database Driver Class Initialized
INFO - 2024-03-28 08:53:16 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-28 08:53:16 --> Parser Class Initialized
INFO - 2024-03-28 08:53:16 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-03-28 08:53:16 --> Pagination Class Initialized
INFO - 2024-03-28 08:53:16 --> Form Validation Class Initialized
INFO - 2024-03-28 08:53:16 --> Controller Class Initialized
INFO - 2024-03-28 08:53:16 --> Model Class Initialized
DEBUG - 2024-03-28 08:53:16 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-28 08:53:16 --> Final output sent to browser
DEBUG - 2024-03-28 08:53:16 --> Total execution time: 0.0159
ERROR - 2024-03-28 08:53:24 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-03-28 08:53:24 --> Config Class Initialized
INFO - 2024-03-28 08:53:24 --> Hooks Class Initialized
DEBUG - 2024-03-28 08:53:24 --> UTF-8 Support Enabled
INFO - 2024-03-28 08:53:24 --> Utf8 Class Initialized
INFO - 2024-03-28 08:53:24 --> URI Class Initialized
INFO - 2024-03-28 08:53:24 --> Router Class Initialized
INFO - 2024-03-28 08:53:24 --> Output Class Initialized
INFO - 2024-03-28 08:53:24 --> Security Class Initialized
DEBUG - 2024-03-28 08:53:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-28 08:53:24 --> Input Class Initialized
INFO - 2024-03-28 08:53:24 --> Language Class Initialized
INFO - 2024-03-28 08:53:24 --> Loader Class Initialized
INFO - 2024-03-28 08:53:24 --> Helper loaded: url_helper
INFO - 2024-03-28 08:53:24 --> Helper loaded: file_helper
INFO - 2024-03-28 08:53:24 --> Helper loaded: html_helper
INFO - 2024-03-28 08:53:24 --> Helper loaded: text_helper
INFO - 2024-03-28 08:53:24 --> Helper loaded: form_helper
INFO - 2024-03-28 08:53:24 --> Helper loaded: lang_helper
INFO - 2024-03-28 08:53:24 --> Helper loaded: security_helper
INFO - 2024-03-28 08:53:24 --> Helper loaded: cookie_helper
INFO - 2024-03-28 08:53:24 --> Database Driver Class Initialized
INFO - 2024-03-28 08:53:24 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-28 08:53:24 --> Parser Class Initialized
INFO - 2024-03-28 08:53:24 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-03-28 08:53:24 --> Pagination Class Initialized
INFO - 2024-03-28 08:53:24 --> Form Validation Class Initialized
INFO - 2024-03-28 08:53:24 --> Controller Class Initialized
INFO - 2024-03-28 08:53:24 --> Final output sent to browser
DEBUG - 2024-03-28 08:53:24 --> Total execution time: 0.0171
ERROR - 2024-03-28 08:53:29 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-03-28 08:53:29 --> Config Class Initialized
INFO - 2024-03-28 08:53:29 --> Hooks Class Initialized
DEBUG - 2024-03-28 08:53:29 --> UTF-8 Support Enabled
INFO - 2024-03-28 08:53:29 --> Utf8 Class Initialized
INFO - 2024-03-28 08:53:29 --> URI Class Initialized
INFO - 2024-03-28 08:53:29 --> Router Class Initialized
INFO - 2024-03-28 08:53:29 --> Output Class Initialized
INFO - 2024-03-28 08:53:29 --> Security Class Initialized
DEBUG - 2024-03-28 08:53:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-28 08:53:29 --> Input Class Initialized
INFO - 2024-03-28 08:53:29 --> Language Class Initialized
INFO - 2024-03-28 08:53:29 --> Loader Class Initialized
INFO - 2024-03-28 08:53:29 --> Helper loaded: url_helper
INFO - 2024-03-28 08:53:29 --> Helper loaded: file_helper
INFO - 2024-03-28 08:53:29 --> Helper loaded: html_helper
INFO - 2024-03-28 08:53:29 --> Helper loaded: text_helper
INFO - 2024-03-28 08:53:29 --> Helper loaded: form_helper
INFO - 2024-03-28 08:53:29 --> Helper loaded: lang_helper
INFO - 2024-03-28 08:53:29 --> Helper loaded: security_helper
INFO - 2024-03-28 08:53:29 --> Helper loaded: cookie_helper
INFO - 2024-03-28 08:53:29 --> Database Driver Class Initialized
INFO - 2024-03-28 08:53:29 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-28 08:53:29 --> Parser Class Initialized
INFO - 2024-03-28 08:53:29 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-03-28 08:53:29 --> Pagination Class Initialized
INFO - 2024-03-28 08:53:29 --> Form Validation Class Initialized
INFO - 2024-03-28 08:53:29 --> Controller Class Initialized
INFO - 2024-03-28 08:53:29 --> Model Class Initialized
DEBUG - 2024-03-28 08:53:29 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-03-28 08:53:29 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-28 08:53:29 --> Model Class Initialized
DEBUG - 2024-03-28 08:53:29 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-28 08:53:29 --> Model Class Initialized
INFO - 2024-03-28 08:53:29 --> Final output sent to browser
DEBUG - 2024-03-28 08:53:29 --> Total execution time: 0.2126
ERROR - 2024-03-28 08:53:30 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-03-28 08:53:30 --> Config Class Initialized
INFO - 2024-03-28 08:53:30 --> Hooks Class Initialized
DEBUG - 2024-03-28 08:53:30 --> UTF-8 Support Enabled
INFO - 2024-03-28 08:53:30 --> Utf8 Class Initialized
INFO - 2024-03-28 08:53:30 --> URI Class Initialized
INFO - 2024-03-28 08:53:30 --> Router Class Initialized
INFO - 2024-03-28 08:53:30 --> Output Class Initialized
INFO - 2024-03-28 08:53:30 --> Security Class Initialized
DEBUG - 2024-03-28 08:53:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-28 08:53:30 --> Input Class Initialized
INFO - 2024-03-28 08:53:30 --> Language Class Initialized
INFO - 2024-03-28 08:53:30 --> Loader Class Initialized
INFO - 2024-03-28 08:53:30 --> Helper loaded: url_helper
INFO - 2024-03-28 08:53:30 --> Helper loaded: file_helper
INFO - 2024-03-28 08:53:30 --> Helper loaded: html_helper
INFO - 2024-03-28 08:53:30 --> Helper loaded: text_helper
INFO - 2024-03-28 08:53:30 --> Helper loaded: form_helper
INFO - 2024-03-28 08:53:30 --> Helper loaded: lang_helper
INFO - 2024-03-28 08:53:30 --> Helper loaded: security_helper
INFO - 2024-03-28 08:53:30 --> Helper loaded: cookie_helper
INFO - 2024-03-28 08:53:30 --> Database Driver Class Initialized
INFO - 2024-03-28 08:53:30 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-28 08:53:30 --> Parser Class Initialized
INFO - 2024-03-28 08:53:30 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-03-28 08:53:30 --> Pagination Class Initialized
INFO - 2024-03-28 08:53:30 --> Form Validation Class Initialized
INFO - 2024-03-28 08:53:30 --> Controller Class Initialized
INFO - 2024-03-28 08:53:30 --> Model Class Initialized
DEBUG - 2024-03-28 08:53:30 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-03-28 08:53:30 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-28 08:53:30 --> Model Class Initialized
DEBUG - 2024-03-28 08:53:30 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-28 08:53:30 --> Model Class Initialized
INFO - 2024-03-28 08:53:30 --> Final output sent to browser
DEBUG - 2024-03-28 08:53:30 --> Total execution time: 0.2202
ERROR - 2024-03-28 08:53:30 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-03-28 08:53:30 --> Config Class Initialized
INFO - 2024-03-28 08:53:30 --> Hooks Class Initialized
DEBUG - 2024-03-28 08:53:30 --> UTF-8 Support Enabled
INFO - 2024-03-28 08:53:30 --> Utf8 Class Initialized
INFO - 2024-03-28 08:53:30 --> URI Class Initialized
INFO - 2024-03-28 08:53:30 --> Router Class Initialized
INFO - 2024-03-28 08:53:30 --> Output Class Initialized
INFO - 2024-03-28 08:53:30 --> Security Class Initialized
DEBUG - 2024-03-28 08:53:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-28 08:53:30 --> Input Class Initialized
INFO - 2024-03-28 08:53:30 --> Language Class Initialized
INFO - 2024-03-28 08:53:30 --> Loader Class Initialized
INFO - 2024-03-28 08:53:30 --> Helper loaded: url_helper
INFO - 2024-03-28 08:53:30 --> Helper loaded: file_helper
INFO - 2024-03-28 08:53:30 --> Helper loaded: html_helper
INFO - 2024-03-28 08:53:30 --> Helper loaded: text_helper
INFO - 2024-03-28 08:53:30 --> Helper loaded: form_helper
INFO - 2024-03-28 08:53:30 --> Helper loaded: lang_helper
INFO - 2024-03-28 08:53:30 --> Helper loaded: security_helper
INFO - 2024-03-28 08:53:30 --> Helper loaded: cookie_helper
INFO - 2024-03-28 08:53:30 --> Database Driver Class Initialized
INFO - 2024-03-28 08:53:30 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-28 08:53:30 --> Parser Class Initialized
INFO - 2024-03-28 08:53:30 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-03-28 08:53:30 --> Pagination Class Initialized
INFO - 2024-03-28 08:53:30 --> Form Validation Class Initialized
INFO - 2024-03-28 08:53:30 --> Controller Class Initialized
INFO - 2024-03-28 08:53:30 --> Model Class Initialized
DEBUG - 2024-03-28 08:53:30 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-03-28 08:53:30 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-28 08:53:30 --> Model Class Initialized
DEBUG - 2024-03-28 08:53:30 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-28 08:53:30 --> Model Class Initialized
INFO - 2024-03-28 08:53:30 --> Final output sent to browser
DEBUG - 2024-03-28 08:53:30 --> Total execution time: 0.2425
ERROR - 2024-03-28 08:53:31 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-03-28 08:53:31 --> Config Class Initialized
INFO - 2024-03-28 08:53:31 --> Hooks Class Initialized
DEBUG - 2024-03-28 08:53:31 --> UTF-8 Support Enabled
INFO - 2024-03-28 08:53:31 --> Utf8 Class Initialized
INFO - 2024-03-28 08:53:31 --> URI Class Initialized
INFO - 2024-03-28 08:53:31 --> Router Class Initialized
INFO - 2024-03-28 08:53:31 --> Output Class Initialized
INFO - 2024-03-28 08:53:31 --> Security Class Initialized
DEBUG - 2024-03-28 08:53:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-28 08:53:31 --> Input Class Initialized
INFO - 2024-03-28 08:53:31 --> Language Class Initialized
INFO - 2024-03-28 08:53:31 --> Loader Class Initialized
INFO - 2024-03-28 08:53:31 --> Helper loaded: url_helper
INFO - 2024-03-28 08:53:31 --> Helper loaded: file_helper
INFO - 2024-03-28 08:53:31 --> Helper loaded: html_helper
INFO - 2024-03-28 08:53:31 --> Helper loaded: text_helper
INFO - 2024-03-28 08:53:31 --> Helper loaded: form_helper
INFO - 2024-03-28 08:53:31 --> Helper loaded: lang_helper
INFO - 2024-03-28 08:53:31 --> Helper loaded: security_helper
INFO - 2024-03-28 08:53:31 --> Helper loaded: cookie_helper
INFO - 2024-03-28 08:53:31 --> Database Driver Class Initialized
INFO - 2024-03-28 08:53:31 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-28 08:53:31 --> Parser Class Initialized
INFO - 2024-03-28 08:53:31 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-03-28 08:53:31 --> Pagination Class Initialized
INFO - 2024-03-28 08:53:31 --> Form Validation Class Initialized
INFO - 2024-03-28 08:53:31 --> Controller Class Initialized
INFO - 2024-03-28 08:53:31 --> Model Class Initialized
DEBUG - 2024-03-28 08:53:31 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-03-28 08:53:31 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-28 08:53:31 --> Model Class Initialized
DEBUG - 2024-03-28 08:53:31 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-28 08:53:31 --> Model Class Initialized
INFO - 2024-03-28 08:53:31 --> Final output sent to browser
DEBUG - 2024-03-28 08:53:31 --> Total execution time: 0.0647
ERROR - 2024-03-28 08:53:32 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-03-28 08:53:32 --> Config Class Initialized
INFO - 2024-03-28 08:53:32 --> Hooks Class Initialized
DEBUG - 2024-03-28 08:53:32 --> UTF-8 Support Enabled
INFO - 2024-03-28 08:53:32 --> Utf8 Class Initialized
INFO - 2024-03-28 08:53:32 --> URI Class Initialized
INFO - 2024-03-28 08:53:32 --> Router Class Initialized
INFO - 2024-03-28 08:53:32 --> Output Class Initialized
INFO - 2024-03-28 08:53:32 --> Security Class Initialized
DEBUG - 2024-03-28 08:53:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-28 08:53:32 --> Input Class Initialized
INFO - 2024-03-28 08:53:32 --> Language Class Initialized
INFO - 2024-03-28 08:53:32 --> Loader Class Initialized
INFO - 2024-03-28 08:53:32 --> Helper loaded: url_helper
INFO - 2024-03-28 08:53:32 --> Helper loaded: file_helper
INFO - 2024-03-28 08:53:32 --> Helper loaded: html_helper
INFO - 2024-03-28 08:53:32 --> Helper loaded: text_helper
INFO - 2024-03-28 08:53:32 --> Helper loaded: form_helper
INFO - 2024-03-28 08:53:32 --> Helper loaded: lang_helper
INFO - 2024-03-28 08:53:32 --> Helper loaded: security_helper
INFO - 2024-03-28 08:53:32 --> Helper loaded: cookie_helper
INFO - 2024-03-28 08:53:32 --> Database Driver Class Initialized
INFO - 2024-03-28 08:53:32 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-28 08:53:32 --> Parser Class Initialized
INFO - 2024-03-28 08:53:32 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-03-28 08:53:32 --> Pagination Class Initialized
INFO - 2024-03-28 08:53:32 --> Form Validation Class Initialized
INFO - 2024-03-28 08:53:32 --> Controller Class Initialized
INFO - 2024-03-28 08:53:32 --> Model Class Initialized
DEBUG - 2024-03-28 08:53:32 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-03-28 08:53:32 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-28 08:53:32 --> Model Class Initialized
DEBUG - 2024-03-28 08:53:32 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-28 08:53:32 --> Model Class Initialized
INFO - 2024-03-28 08:53:32 --> Final output sent to browser
DEBUG - 2024-03-28 08:53:32 --> Total execution time: 0.0308
ERROR - 2024-03-28 08:53:33 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-03-28 08:53:33 --> Config Class Initialized
INFO - 2024-03-28 08:53:33 --> Hooks Class Initialized
DEBUG - 2024-03-28 08:53:33 --> UTF-8 Support Enabled
INFO - 2024-03-28 08:53:33 --> Utf8 Class Initialized
INFO - 2024-03-28 08:53:33 --> URI Class Initialized
INFO - 2024-03-28 08:53:33 --> Router Class Initialized
INFO - 2024-03-28 08:53:33 --> Output Class Initialized
INFO - 2024-03-28 08:53:33 --> Security Class Initialized
DEBUG - 2024-03-28 08:53:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-28 08:53:33 --> Input Class Initialized
INFO - 2024-03-28 08:53:33 --> Language Class Initialized
INFO - 2024-03-28 08:53:33 --> Loader Class Initialized
INFO - 2024-03-28 08:53:33 --> Helper loaded: url_helper
INFO - 2024-03-28 08:53:33 --> Helper loaded: file_helper
INFO - 2024-03-28 08:53:33 --> Helper loaded: html_helper
INFO - 2024-03-28 08:53:33 --> Helper loaded: text_helper
INFO - 2024-03-28 08:53:33 --> Helper loaded: form_helper
INFO - 2024-03-28 08:53:33 --> Helper loaded: lang_helper
INFO - 2024-03-28 08:53:33 --> Helper loaded: security_helper
INFO - 2024-03-28 08:53:33 --> Helper loaded: cookie_helper
INFO - 2024-03-28 08:53:33 --> Database Driver Class Initialized
INFO - 2024-03-28 08:53:33 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-28 08:53:33 --> Parser Class Initialized
INFO - 2024-03-28 08:53:33 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-03-28 08:53:33 --> Pagination Class Initialized
INFO - 2024-03-28 08:53:33 --> Form Validation Class Initialized
INFO - 2024-03-28 08:53:33 --> Controller Class Initialized
INFO - 2024-03-28 08:53:33 --> Model Class Initialized
DEBUG - 2024-03-28 08:53:33 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-03-28 08:53:33 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-28 08:53:33 --> Model Class Initialized
INFO - 2024-03-28 08:53:33 --> Model Class Initialized
INFO - 2024-03-28 08:53:33 --> Final output sent to browser
DEBUG - 2024-03-28 08:53:33 --> Total execution time: 0.0234
ERROR - 2024-03-28 08:53:35 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-03-28 08:53:35 --> Config Class Initialized
INFO - 2024-03-28 08:53:35 --> Hooks Class Initialized
DEBUG - 2024-03-28 08:53:35 --> UTF-8 Support Enabled
INFO - 2024-03-28 08:53:35 --> Utf8 Class Initialized
INFO - 2024-03-28 08:53:35 --> URI Class Initialized
INFO - 2024-03-28 08:53:35 --> Router Class Initialized
INFO - 2024-03-28 08:53:35 --> Output Class Initialized
INFO - 2024-03-28 08:53:35 --> Security Class Initialized
DEBUG - 2024-03-28 08:53:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-28 08:53:35 --> Input Class Initialized
INFO - 2024-03-28 08:53:35 --> Language Class Initialized
INFO - 2024-03-28 08:53:35 --> Loader Class Initialized
INFO - 2024-03-28 08:53:35 --> Helper loaded: url_helper
INFO - 2024-03-28 08:53:35 --> Helper loaded: file_helper
INFO - 2024-03-28 08:53:35 --> Helper loaded: html_helper
INFO - 2024-03-28 08:53:35 --> Helper loaded: text_helper
INFO - 2024-03-28 08:53:35 --> Helper loaded: form_helper
INFO - 2024-03-28 08:53:35 --> Helper loaded: lang_helper
INFO - 2024-03-28 08:53:35 --> Helper loaded: security_helper
INFO - 2024-03-28 08:53:35 --> Helper loaded: cookie_helper
INFO - 2024-03-28 08:53:35 --> Database Driver Class Initialized
INFO - 2024-03-28 08:53:35 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-28 08:53:35 --> Parser Class Initialized
INFO - 2024-03-28 08:53:35 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-03-28 08:53:35 --> Pagination Class Initialized
INFO - 2024-03-28 08:53:35 --> Form Validation Class Initialized
INFO - 2024-03-28 08:53:35 --> Controller Class Initialized
INFO - 2024-03-28 08:53:35 --> Model Class Initialized
DEBUG - 2024-03-28 08:53:35 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-03-28 08:53:35 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-28 08:53:35 --> Model Class Initialized
INFO - 2024-03-28 08:53:35 --> Final output sent to browser
DEBUG - 2024-03-28 08:53:35 --> Total execution time: 0.0166
ERROR - 2024-03-28 08:53:48 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-03-28 08:53:48 --> Config Class Initialized
INFO - 2024-03-28 08:53:48 --> Hooks Class Initialized
DEBUG - 2024-03-28 08:53:48 --> UTF-8 Support Enabled
INFO - 2024-03-28 08:53:48 --> Utf8 Class Initialized
INFO - 2024-03-28 08:53:48 --> URI Class Initialized
INFO - 2024-03-28 08:53:48 --> Router Class Initialized
INFO - 2024-03-28 08:53:48 --> Output Class Initialized
INFO - 2024-03-28 08:53:48 --> Security Class Initialized
DEBUG - 2024-03-28 08:53:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-28 08:53:48 --> Input Class Initialized
INFO - 2024-03-28 08:53:48 --> Language Class Initialized
INFO - 2024-03-28 08:53:48 --> Loader Class Initialized
INFO - 2024-03-28 08:53:48 --> Helper loaded: url_helper
INFO - 2024-03-28 08:53:48 --> Helper loaded: file_helper
INFO - 2024-03-28 08:53:48 --> Helper loaded: html_helper
INFO - 2024-03-28 08:53:48 --> Helper loaded: text_helper
INFO - 2024-03-28 08:53:48 --> Helper loaded: form_helper
INFO - 2024-03-28 08:53:48 --> Helper loaded: lang_helper
INFO - 2024-03-28 08:53:48 --> Helper loaded: security_helper
INFO - 2024-03-28 08:53:48 --> Helper loaded: cookie_helper
INFO - 2024-03-28 08:53:48 --> Database Driver Class Initialized
INFO - 2024-03-28 08:53:48 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-28 08:53:48 --> Parser Class Initialized
INFO - 2024-03-28 08:53:48 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-03-28 08:53:48 --> Pagination Class Initialized
INFO - 2024-03-28 08:53:48 --> Form Validation Class Initialized
INFO - 2024-03-28 08:53:48 --> Controller Class Initialized
INFO - 2024-03-28 08:53:48 --> Model Class Initialized
DEBUG - 2024-03-28 08:53:48 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-03-28 08:53:48 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-28 08:53:48 --> Model Class Initialized
DEBUG - 2024-03-28 08:53:48 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-28 08:53:48 --> Model Class Initialized
INFO - 2024-03-28 08:53:48 --> Email Class Initialized
DEBUG - 2024-03-28 08:53:48 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-28 08:53:48 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice_html_pdf.php
ERROR - 2024-03-28 08:53:48 --> Severity: Warning --> "continue" targeting switch is equivalent to "break". Did you mean to use "continue 2"? /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/dompdf.cls.php 743
ERROR - 2024-03-28 08:53:48 --> Severity: Warning --> "continue" targeting switch is equivalent to "break". Did you mean to use "continue 2"? /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/dompdf.cls.php 763
ERROR - 2024-03-28 08:53:48 --> Severity: Warning --> "continue" targeting switch is equivalent to "break". Did you mean to use "continue 2"? /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/stylesheet.cls.php 1102
ERROR - 2024-03-28 08:53:49 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/page_frame_decorator.cls.php 439
ERROR - 2024-03-28 08:53:49 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/page_frame_decorator.cls.php 439
ERROR - 2024-03-28 08:53:49 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/page_frame_decorator.cls.php 439
ERROR - 2024-03-28 08:53:49 --> Severity: Warning --> Division by zero /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 572
ERROR - 2024-03-28 08:53:49 --> Severity: Warning --> Division by zero /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 572
ERROR - 2024-03-28 08:53:49 --> Severity: Warning --> Division by zero /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 572
ERROR - 2024-03-28 08:53:49 --> Severity: Warning --> Division by zero /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 572
ERROR - 2024-03-28 08:53:49 --> Severity: Warning --> Division by zero /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 572
ERROR - 2024-03-28 08:53:49 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/table_cell_frame_reflower.cls.php 103
ERROR - 2024-03-28 08:53:49 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/table_cell_frame_reflower.cls.php 103
ERROR - 2024-03-28 08:53:49 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/table_cell_frame_reflower.cls.php 103
ERROR - 2024-03-28 08:53:49 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/table_cell_frame_reflower.cls.php 103
ERROR - 2024-03-28 08:53:49 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/table_cell_frame_reflower.cls.php 103
ERROR - 2024-03-28 08:53:49 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/table_cell_frame_reflower.cls.php 103
ERROR - 2024-03-28 08:53:49 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/table_cell_frame_reflower.cls.php 103
ERROR - 2024-03-28 08:53:49 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/table_cell_frame_reflower.cls.php 103
ERROR - 2024-03-28 08:53:49 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/table_cell_frame_reflower.cls.php 103
ERROR - 2024-03-28 08:53:49 --> Severity: Warning --> Invalid argument supplied for foreach() /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 709
ERROR - 2024-03-28 08:53:49 --> Severity: Warning --> Invalid argument supplied for foreach() /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 709
ERROR - 2024-03-28 08:53:49 --> Severity: Warning --> Invalid argument supplied for foreach() /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 709
ERROR - 2024-03-28 08:53:49 --> Severity: Warning --> Invalid argument supplied for foreach() /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 709
ERROR - 2024-03-28 08:53:49 --> Severity: Warning --> Invalid argument supplied for foreach() /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 709
ERROR - 2024-03-28 08:53:49 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-03-28 08:53:49 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-03-28 08:53:49 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-03-28 08:53:49 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-03-28 08:53:49 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-03-28 08:53:49 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-03-28 08:53:49 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-03-28 08:53:49 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-03-28 08:53:49 --> Severity: Warning --> "continue" targeting switch is equivalent to "break". Did you mean to use "continue 2"? /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/text_renderer.cls.php 126
ERROR - 2024-03-28 08:53:49 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-03-28 08:53:49 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-03-28 08:53:49 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-03-28 08:53:49 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-03-28 08:53:49 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-03-28 08:53:49 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-03-28 08:53:49 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-03-28 08:53:49 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-03-28 08:53:49 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-03-28 08:53:49 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-03-28 08:53:49 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-03-28 08:53:49 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-03-28 08:53:49 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-03-28 08:53:49 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-03-28 08:53:49 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-03-28 08:53:49 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-03-28 08:53:49 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-03-28 08:53:49 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-03-28 08:53:49 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-03-28 08:53:49 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-03-28 08:53:49 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-03-28 08:53:49 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-03-28 08:53:49 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-03-28 08:53:49 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-03-28 08:53:49 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-03-28 08:53:49 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-03-28 08:53:49 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-03-28 08:53:49 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-03-28 08:53:49 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-03-28 08:53:49 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-03-28 08:53:49 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-03-28 08:53:49 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-03-28 08:53:49 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-03-28 08:53:49 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-03-28 08:53:49 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-03-28 08:53:49 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-03-28 08:53:49 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-03-28 08:53:49 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-03-28 08:53:49 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-03-28 08:53:49 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-03-28 08:53:49 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-03-28 08:53:49 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-03-28 08:53:49 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-03-28 08:53:49 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-03-28 08:53:49 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-03-28 08:53:49 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-03-28 08:53:49 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-03-28 08:53:49 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-03-28 08:53:49 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-03-28 08:53:49 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-03-28 08:53:49 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-03-28 08:53:49 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-03-28 08:53:49 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-03-28 08:53:49 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-03-28 08:53:49 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-03-28 08:53:49 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-03-28 08:53:49 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-03-28 08:53:49 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-03-28 08:53:49 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-03-28 08:53:49 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-03-28 08:53:49 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-03-28 08:53:49 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-03-28 08:53:49 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-03-28 08:53:49 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-03-28 08:53:49 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-03-28 08:53:49 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-03-28 08:53:49 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-03-28 08:53:49 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-03-28 08:53:49 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-03-28 08:53:49 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-03-28 08:53:49 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-03-28 08:53:49 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-03-28 08:53:49 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-03-28 08:53:49 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-03-28 08:53:49 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-03-28 08:53:49 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-03-28 08:53:49 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-03-28 08:53:49 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-03-28 08:53:49 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-03-28 08:53:49 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-03-28 08:53:49 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-03-28 08:53:49 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-03-28 08:53:49 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-03-28 08:53:49 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-03-28 08:53:49 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-03-28 08:53:49 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-03-28 08:53:49 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-03-28 08:53:49 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-03-28 08:53:49 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-03-28 08:53:49 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-03-28 08:53:49 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-03-28 08:53:49 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-03-28 08:53:49 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-03-28 08:53:49 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-03-28 08:53:49 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-03-28 08:53:49 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
INFO - 2024-03-28 08:53:49 --> Language file loaded: language/english/email_lang.php
INFO - 2024-03-28 08:53:49 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice_html.php
INFO - 2024-03-28 08:53:49 --> Final output sent to browser
DEBUG - 2024-03-28 08:53:49 --> Total execution time: 0.2514
ERROR - 2024-03-28 08:53:50 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-03-28 08:53:50 --> Config Class Initialized
INFO - 2024-03-28 08:53:50 --> Hooks Class Initialized
DEBUG - 2024-03-28 08:53:50 --> UTF-8 Support Enabled
INFO - 2024-03-28 08:53:50 --> Utf8 Class Initialized
INFO - 2024-03-28 08:53:50 --> URI Class Initialized
INFO - 2024-03-28 08:53:50 --> Router Class Initialized
INFO - 2024-03-28 08:53:50 --> Output Class Initialized
INFO - 2024-03-28 08:53:50 --> Security Class Initialized
DEBUG - 2024-03-28 08:53:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-28 08:53:50 --> Input Class Initialized
INFO - 2024-03-28 08:53:50 --> Language Class Initialized
INFO - 2024-03-28 08:53:50 --> Loader Class Initialized
INFO - 2024-03-28 08:53:50 --> Helper loaded: url_helper
INFO - 2024-03-28 08:53:50 --> Helper loaded: file_helper
INFO - 2024-03-28 08:53:50 --> Helper loaded: html_helper
INFO - 2024-03-28 08:53:50 --> Helper loaded: text_helper
INFO - 2024-03-28 08:53:50 --> Helper loaded: form_helper
INFO - 2024-03-28 08:53:50 --> Helper loaded: lang_helper
INFO - 2024-03-28 08:53:50 --> Helper loaded: security_helper
INFO - 2024-03-28 08:53:50 --> Helper loaded: cookie_helper
INFO - 2024-03-28 08:53:50 --> Database Driver Class Initialized
INFO - 2024-03-28 08:53:50 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-28 08:53:50 --> Parser Class Initialized
INFO - 2024-03-28 08:53:50 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-03-28 08:53:50 --> Pagination Class Initialized
INFO - 2024-03-28 08:53:50 --> Form Validation Class Initialized
INFO - 2024-03-28 08:53:50 --> Controller Class Initialized
INFO - 2024-03-28 08:53:50 --> Model Class Initialized
DEBUG - 2024-03-28 08:53:50 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-03-28 08:53:50 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-28 08:53:50 --> Model Class Initialized
DEBUG - 2024-03-28 08:53:50 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-28 08:53:50 --> Model Class Initialized
INFO - 2024-03-28 08:53:50 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/add_invoice_form.php
DEBUG - 2024-03-28 08:53:50 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-03-28 08:53:50 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-03-28 08:53:50 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-03-28 08:53:50 --> Model Class Initialized
INFO - 2024-03-28 08:53:50 --> Model Class Initialized
INFO - 2024-03-28 08:53:50 --> Model Class Initialized
INFO - 2024-03-28 08:53:51 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-03-28 08:53:51 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-03-28 08:53:51 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-03-28 08:53:51 --> Final output sent to browser
DEBUG - 2024-03-28 08:53:51 --> Total execution time: 0.1973
ERROR - 2024-03-28 12:08:59 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-03-28 12:08:59 --> Config Class Initialized
INFO - 2024-03-28 12:08:59 --> Hooks Class Initialized
DEBUG - 2024-03-28 12:08:59 --> UTF-8 Support Enabled
INFO - 2024-03-28 12:08:59 --> Utf8 Class Initialized
INFO - 2024-03-28 12:08:59 --> URI Class Initialized
DEBUG - 2024-03-28 12:08:59 --> No URI present. Default controller set.
INFO - 2024-03-28 12:08:59 --> Router Class Initialized
INFO - 2024-03-28 12:08:59 --> Output Class Initialized
INFO - 2024-03-28 12:08:59 --> Security Class Initialized
DEBUG - 2024-03-28 12:08:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-28 12:08:59 --> Input Class Initialized
INFO - 2024-03-28 12:08:59 --> Language Class Initialized
INFO - 2024-03-28 12:08:59 --> Loader Class Initialized
INFO - 2024-03-28 12:08:59 --> Helper loaded: url_helper
INFO - 2024-03-28 12:08:59 --> Helper loaded: file_helper
INFO - 2024-03-28 12:08:59 --> Helper loaded: html_helper
INFO - 2024-03-28 12:08:59 --> Helper loaded: text_helper
INFO - 2024-03-28 12:08:59 --> Helper loaded: form_helper
INFO - 2024-03-28 12:08:59 --> Helper loaded: lang_helper
INFO - 2024-03-28 12:08:59 --> Helper loaded: security_helper
INFO - 2024-03-28 12:08:59 --> Helper loaded: cookie_helper
INFO - 2024-03-28 12:08:59 --> Database Driver Class Initialized
INFO - 2024-03-28 12:08:59 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-28 12:08:59 --> Parser Class Initialized
INFO - 2024-03-28 12:08:59 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-03-28 12:08:59 --> Pagination Class Initialized
INFO - 2024-03-28 12:08:59 --> Form Validation Class Initialized
INFO - 2024-03-28 12:08:59 --> Controller Class Initialized
INFO - 2024-03-28 12:08:59 --> Model Class Initialized
DEBUG - 2024-03-28 12:08:59 --> Session class already loaded. Second attempt ignored.
ERROR - 2024-03-28 12:09:00 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-03-28 12:09:00 --> Config Class Initialized
INFO - 2024-03-28 12:09:00 --> Hooks Class Initialized
DEBUG - 2024-03-28 12:09:00 --> UTF-8 Support Enabled
INFO - 2024-03-28 12:09:00 --> Utf8 Class Initialized
INFO - 2024-03-28 12:09:00 --> URI Class Initialized
INFO - 2024-03-28 12:09:00 --> Router Class Initialized
INFO - 2024-03-28 12:09:00 --> Output Class Initialized
INFO - 2024-03-28 12:09:00 --> Security Class Initialized
DEBUG - 2024-03-28 12:09:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-28 12:09:00 --> Input Class Initialized
INFO - 2024-03-28 12:09:00 --> Language Class Initialized
INFO - 2024-03-28 12:09:00 --> Loader Class Initialized
INFO - 2024-03-28 12:09:00 --> Helper loaded: url_helper
INFO - 2024-03-28 12:09:00 --> Helper loaded: file_helper
INFO - 2024-03-28 12:09:00 --> Helper loaded: html_helper
INFO - 2024-03-28 12:09:00 --> Helper loaded: text_helper
INFO - 2024-03-28 12:09:00 --> Helper loaded: form_helper
INFO - 2024-03-28 12:09:00 --> Helper loaded: lang_helper
INFO - 2024-03-28 12:09:00 --> Helper loaded: security_helper
INFO - 2024-03-28 12:09:00 --> Helper loaded: cookie_helper
INFO - 2024-03-28 12:09:00 --> Database Driver Class Initialized
INFO - 2024-03-28 12:09:00 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-28 12:09:00 --> Parser Class Initialized
INFO - 2024-03-28 12:09:00 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-03-28 12:09:00 --> Pagination Class Initialized
INFO - 2024-03-28 12:09:00 --> Form Validation Class Initialized
INFO - 2024-03-28 12:09:00 --> Controller Class Initialized
INFO - 2024-03-28 12:09:00 --> Model Class Initialized
DEBUG - 2024-03-28 12:09:00 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-28 12:09:00 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2024-03-28 12:09:00 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-03-28 12:09:00 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-03-28 12:09:00 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-03-28 12:09:00 --> Model Class Initialized
INFO - 2024-03-28 12:09:00 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-03-28 12:09:00 --> Final output sent to browser
DEBUG - 2024-03-28 12:09:00 --> Total execution time: 0.0382
ERROR - 2024-03-28 14:36:49 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-03-28 14:36:49 --> Config Class Initialized
INFO - 2024-03-28 14:36:49 --> Hooks Class Initialized
DEBUG - 2024-03-28 14:36:49 --> UTF-8 Support Enabled
INFO - 2024-03-28 14:36:49 --> Utf8 Class Initialized
INFO - 2024-03-28 14:36:49 --> URI Class Initialized
DEBUG - 2024-03-28 14:36:49 --> No URI present. Default controller set.
INFO - 2024-03-28 14:36:49 --> Router Class Initialized
INFO - 2024-03-28 14:36:49 --> Output Class Initialized
INFO - 2024-03-28 14:36:49 --> Security Class Initialized
DEBUG - 2024-03-28 14:36:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-28 14:36:49 --> Input Class Initialized
INFO - 2024-03-28 14:36:49 --> Language Class Initialized
INFO - 2024-03-28 14:36:49 --> Loader Class Initialized
INFO - 2024-03-28 14:36:49 --> Helper loaded: url_helper
INFO - 2024-03-28 14:36:49 --> Helper loaded: file_helper
INFO - 2024-03-28 14:36:49 --> Helper loaded: html_helper
INFO - 2024-03-28 14:36:49 --> Helper loaded: text_helper
INFO - 2024-03-28 14:36:49 --> Helper loaded: form_helper
INFO - 2024-03-28 14:36:49 --> Helper loaded: lang_helper
INFO - 2024-03-28 14:36:49 --> Helper loaded: security_helper
INFO - 2024-03-28 14:36:49 --> Helper loaded: cookie_helper
INFO - 2024-03-28 14:36:49 --> Database Driver Class Initialized
INFO - 2024-03-28 14:36:49 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-28 14:36:49 --> Parser Class Initialized
INFO - 2024-03-28 14:36:49 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-03-28 14:36:49 --> Pagination Class Initialized
INFO - 2024-03-28 14:36:49 --> Form Validation Class Initialized
INFO - 2024-03-28 14:36:49 --> Controller Class Initialized
INFO - 2024-03-28 14:36:49 --> Model Class Initialized
DEBUG - 2024-03-28 14:36:49 --> Session class already loaded. Second attempt ignored.
ERROR - 2024-03-28 15:26:50 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-03-28 15:26:50 --> Config Class Initialized
INFO - 2024-03-28 15:26:50 --> Hooks Class Initialized
DEBUG - 2024-03-28 15:26:50 --> UTF-8 Support Enabled
INFO - 2024-03-28 15:26:50 --> Utf8 Class Initialized
INFO - 2024-03-28 15:26:50 --> URI Class Initialized
INFO - 2024-03-28 15:26:50 --> Router Class Initialized
INFO - 2024-03-28 15:26:50 --> Output Class Initialized
INFO - 2024-03-28 15:26:50 --> Security Class Initialized
DEBUG - 2024-03-28 15:26:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-28 15:26:50 --> Input Class Initialized
INFO - 2024-03-28 15:26:50 --> Language Class Initialized
ERROR - 2024-03-28 15:26:50 --> 404 Page Not Found: Well-known/assetlinks.json
ERROR - 2024-03-28 18:38:44 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-03-28 18:38:44 --> Config Class Initialized
INFO - 2024-03-28 18:38:44 --> Hooks Class Initialized
DEBUG - 2024-03-28 18:38:44 --> UTF-8 Support Enabled
INFO - 2024-03-28 18:38:44 --> Utf8 Class Initialized
INFO - 2024-03-28 18:38:44 --> URI Class Initialized
DEBUG - 2024-03-28 18:38:44 --> No URI present. Default controller set.
INFO - 2024-03-28 18:38:44 --> Router Class Initialized
INFO - 2024-03-28 18:38:44 --> Output Class Initialized
INFO - 2024-03-28 18:38:44 --> Security Class Initialized
DEBUG - 2024-03-28 18:38:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-28 18:38:44 --> Input Class Initialized
INFO - 2024-03-28 18:38:44 --> Language Class Initialized
INFO - 2024-03-28 18:38:44 --> Loader Class Initialized
INFO - 2024-03-28 18:38:44 --> Helper loaded: url_helper
INFO - 2024-03-28 18:38:44 --> Helper loaded: file_helper
INFO - 2024-03-28 18:38:44 --> Helper loaded: html_helper
INFO - 2024-03-28 18:38:44 --> Helper loaded: text_helper
INFO - 2024-03-28 18:38:44 --> Helper loaded: form_helper
INFO - 2024-03-28 18:38:44 --> Helper loaded: lang_helper
INFO - 2024-03-28 18:38:44 --> Helper loaded: security_helper
INFO - 2024-03-28 18:38:44 --> Helper loaded: cookie_helper
INFO - 2024-03-28 18:38:44 --> Database Driver Class Initialized
INFO - 2024-03-28 18:38:44 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-28 18:38:44 --> Parser Class Initialized
INFO - 2024-03-28 18:38:44 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-03-28 18:38:44 --> Pagination Class Initialized
INFO - 2024-03-28 18:38:44 --> Form Validation Class Initialized
INFO - 2024-03-28 18:38:44 --> Controller Class Initialized
INFO - 2024-03-28 18:38:44 --> Model Class Initialized
DEBUG - 2024-03-28 18:38:44 --> Session class already loaded. Second attempt ignored.
ERROR - 2024-03-28 18:42:28 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-03-28 18:42:28 --> Config Class Initialized
INFO - 2024-03-28 18:42:28 --> Hooks Class Initialized
DEBUG - 2024-03-28 18:42:28 --> UTF-8 Support Enabled
INFO - 2024-03-28 18:42:28 --> Utf8 Class Initialized
INFO - 2024-03-28 18:42:28 --> URI Class Initialized
DEBUG - 2024-03-28 18:42:28 --> No URI present. Default controller set.
INFO - 2024-03-28 18:42:28 --> Router Class Initialized
INFO - 2024-03-28 18:42:28 --> Output Class Initialized
INFO - 2024-03-28 18:42:28 --> Security Class Initialized
DEBUG - 2024-03-28 18:42:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-28 18:42:28 --> Input Class Initialized
INFO - 2024-03-28 18:42:28 --> Language Class Initialized
INFO - 2024-03-28 18:42:28 --> Loader Class Initialized
INFO - 2024-03-28 18:42:28 --> Helper loaded: url_helper
INFO - 2024-03-28 18:42:28 --> Helper loaded: file_helper
INFO - 2024-03-28 18:42:28 --> Helper loaded: html_helper
INFO - 2024-03-28 18:42:28 --> Helper loaded: text_helper
INFO - 2024-03-28 18:42:28 --> Helper loaded: form_helper
INFO - 2024-03-28 18:42:28 --> Helper loaded: lang_helper
INFO - 2024-03-28 18:42:28 --> Helper loaded: security_helper
INFO - 2024-03-28 18:42:28 --> Helper loaded: cookie_helper
INFO - 2024-03-28 18:42:28 --> Database Driver Class Initialized
INFO - 2024-03-28 18:42:28 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-28 18:42:28 --> Parser Class Initialized
INFO - 2024-03-28 18:42:28 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-03-28 18:42:28 --> Pagination Class Initialized
INFO - 2024-03-28 18:42:28 --> Form Validation Class Initialized
INFO - 2024-03-28 18:42:28 --> Controller Class Initialized
INFO - 2024-03-28 18:42:28 --> Model Class Initialized
DEBUG - 2024-03-28 18:42:28 --> Session class already loaded. Second attempt ignored.
ERROR - 2024-03-28 18:42:29 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-03-28 18:42:29 --> Config Class Initialized
INFO - 2024-03-28 18:42:29 --> Hooks Class Initialized
DEBUG - 2024-03-28 18:42:29 --> UTF-8 Support Enabled
INFO - 2024-03-28 18:42:29 --> Utf8 Class Initialized
INFO - 2024-03-28 18:42:29 --> URI Class Initialized
INFO - 2024-03-28 18:42:29 --> Router Class Initialized
INFO - 2024-03-28 18:42:29 --> Output Class Initialized
INFO - 2024-03-28 18:42:29 --> Security Class Initialized
DEBUG - 2024-03-28 18:42:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-28 18:42:29 --> Input Class Initialized
INFO - 2024-03-28 18:42:29 --> Language Class Initialized
INFO - 2024-03-28 18:42:29 --> Loader Class Initialized
INFO - 2024-03-28 18:42:29 --> Helper loaded: url_helper
INFO - 2024-03-28 18:42:29 --> Helper loaded: file_helper
INFO - 2024-03-28 18:42:29 --> Helper loaded: html_helper
INFO - 2024-03-28 18:42:29 --> Helper loaded: text_helper
INFO - 2024-03-28 18:42:29 --> Helper loaded: form_helper
INFO - 2024-03-28 18:42:29 --> Helper loaded: lang_helper
INFO - 2024-03-28 18:42:29 --> Helper loaded: security_helper
INFO - 2024-03-28 18:42:29 --> Helper loaded: cookie_helper
INFO - 2024-03-28 18:42:29 --> Database Driver Class Initialized
INFO - 2024-03-28 18:42:29 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-28 18:42:29 --> Parser Class Initialized
INFO - 2024-03-28 18:42:29 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-03-28 18:42:29 --> Pagination Class Initialized
INFO - 2024-03-28 18:42:29 --> Form Validation Class Initialized
INFO - 2024-03-28 18:42:29 --> Controller Class Initialized
INFO - 2024-03-28 18:42:29 --> Model Class Initialized
DEBUG - 2024-03-28 18:42:29 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-28 18:42:29 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2024-03-28 18:42:29 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-03-28 18:42:29 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-03-28 18:42:29 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-03-28 18:42:29 --> Model Class Initialized
INFO - 2024-03-28 18:42:29 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-03-28 18:42:29 --> Final output sent to browser
DEBUG - 2024-03-28 18:42:29 --> Total execution time: 0.0357
ERROR - 2024-03-28 18:42:37 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-03-28 18:42:37 --> Config Class Initialized
INFO - 2024-03-28 18:42:37 --> Hooks Class Initialized
DEBUG - 2024-03-28 18:42:37 --> UTF-8 Support Enabled
INFO - 2024-03-28 18:42:37 --> Utf8 Class Initialized
INFO - 2024-03-28 18:42:37 --> URI Class Initialized
INFO - 2024-03-28 18:42:37 --> Router Class Initialized
INFO - 2024-03-28 18:42:37 --> Output Class Initialized
INFO - 2024-03-28 18:42:37 --> Security Class Initialized
DEBUG - 2024-03-28 18:42:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-28 18:42:37 --> Input Class Initialized
INFO - 2024-03-28 18:42:37 --> Language Class Initialized
INFO - 2024-03-28 18:42:37 --> Loader Class Initialized
INFO - 2024-03-28 18:42:37 --> Helper loaded: url_helper
INFO - 2024-03-28 18:42:37 --> Helper loaded: file_helper
INFO - 2024-03-28 18:42:37 --> Helper loaded: html_helper
INFO - 2024-03-28 18:42:37 --> Helper loaded: text_helper
INFO - 2024-03-28 18:42:37 --> Helper loaded: form_helper
INFO - 2024-03-28 18:42:37 --> Helper loaded: lang_helper
INFO - 2024-03-28 18:42:37 --> Helper loaded: security_helper
INFO - 2024-03-28 18:42:37 --> Helper loaded: cookie_helper
INFO - 2024-03-28 18:42:37 --> Database Driver Class Initialized
INFO - 2024-03-28 18:42:37 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-28 18:42:37 --> Parser Class Initialized
INFO - 2024-03-28 18:42:37 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-03-28 18:42:37 --> Pagination Class Initialized
INFO - 2024-03-28 18:42:37 --> Form Validation Class Initialized
INFO - 2024-03-28 18:42:37 --> Controller Class Initialized
INFO - 2024-03-28 18:42:37 --> Model Class Initialized
DEBUG - 2024-03-28 18:42:37 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-28 18:42:37 --> Model Class Initialized
INFO - 2024-03-28 18:42:37 --> Final output sent to browser
DEBUG - 2024-03-28 18:42:37 --> Total execution time: 0.0188
ERROR - 2024-03-28 18:42:37 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-03-28 18:42:37 --> Config Class Initialized
INFO - 2024-03-28 18:42:37 --> Hooks Class Initialized
DEBUG - 2024-03-28 18:42:37 --> UTF-8 Support Enabled
INFO - 2024-03-28 18:42:37 --> Utf8 Class Initialized
INFO - 2024-03-28 18:42:37 --> URI Class Initialized
DEBUG - 2024-03-28 18:42:37 --> No URI present. Default controller set.
INFO - 2024-03-28 18:42:37 --> Router Class Initialized
INFO - 2024-03-28 18:42:37 --> Output Class Initialized
INFO - 2024-03-28 18:42:37 --> Security Class Initialized
DEBUG - 2024-03-28 18:42:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-28 18:42:37 --> Input Class Initialized
INFO - 2024-03-28 18:42:37 --> Language Class Initialized
INFO - 2024-03-28 18:42:37 --> Loader Class Initialized
INFO - 2024-03-28 18:42:37 --> Helper loaded: url_helper
INFO - 2024-03-28 18:42:37 --> Helper loaded: file_helper
INFO - 2024-03-28 18:42:37 --> Helper loaded: html_helper
INFO - 2024-03-28 18:42:37 --> Helper loaded: text_helper
INFO - 2024-03-28 18:42:37 --> Helper loaded: form_helper
INFO - 2024-03-28 18:42:37 --> Helper loaded: lang_helper
INFO - 2024-03-28 18:42:37 --> Helper loaded: security_helper
INFO - 2024-03-28 18:42:37 --> Helper loaded: cookie_helper
INFO - 2024-03-28 18:42:37 --> Database Driver Class Initialized
INFO - 2024-03-28 18:42:37 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-28 18:42:37 --> Parser Class Initialized
INFO - 2024-03-28 18:42:37 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-03-28 18:42:37 --> Pagination Class Initialized
INFO - 2024-03-28 18:42:37 --> Form Validation Class Initialized
INFO - 2024-03-28 18:42:37 --> Controller Class Initialized
INFO - 2024-03-28 18:42:37 --> Model Class Initialized
DEBUG - 2024-03-28 18:42:37 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-28 18:42:37 --> Model Class Initialized
DEBUG - 2024-03-28 18:42:37 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-28 18:42:37 --> Model Class Initialized
INFO - 2024-03-28 18:42:37 --> Model Class Initialized
INFO - 2024-03-28 18:42:37 --> Model Class Initialized
INFO - 2024-03-28 18:42:37 --> Model Class Initialized
DEBUG - 2024-03-28 18:42:37 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-03-28 18:42:37 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-28 18:42:37 --> Model Class Initialized
INFO - 2024-03-28 18:42:37 --> Model Class Initialized
INFO - 2024-03-28 18:42:37 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2024-03-28 18:42:37 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-03-28 18:42:37 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-03-28 18:42:37 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-03-28 18:42:37 --> Model Class Initialized
INFO - 2024-03-28 18:42:38 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-03-28 18:42:38 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-03-28 18:42:38 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-03-28 18:42:38 --> Final output sent to browser
DEBUG - 2024-03-28 18:42:38 --> Total execution time: 0.4410
ERROR - 2024-03-28 18:42:38 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-03-28 18:42:38 --> Config Class Initialized
INFO - 2024-03-28 18:42:38 --> Hooks Class Initialized
DEBUG - 2024-03-28 18:42:38 --> UTF-8 Support Enabled
INFO - 2024-03-28 18:42:38 --> Utf8 Class Initialized
INFO - 2024-03-28 18:42:38 --> URI Class Initialized
INFO - 2024-03-28 18:42:38 --> Router Class Initialized
INFO - 2024-03-28 18:42:38 --> Output Class Initialized
INFO - 2024-03-28 18:42:38 --> Security Class Initialized
DEBUG - 2024-03-28 18:42:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-28 18:42:38 --> Input Class Initialized
INFO - 2024-03-28 18:42:38 --> Language Class Initialized
INFO - 2024-03-28 18:42:38 --> Loader Class Initialized
INFO - 2024-03-28 18:42:38 --> Helper loaded: url_helper
INFO - 2024-03-28 18:42:38 --> Helper loaded: file_helper
INFO - 2024-03-28 18:42:38 --> Helper loaded: html_helper
INFO - 2024-03-28 18:42:38 --> Helper loaded: text_helper
INFO - 2024-03-28 18:42:38 --> Helper loaded: form_helper
INFO - 2024-03-28 18:42:38 --> Helper loaded: lang_helper
INFO - 2024-03-28 18:42:38 --> Helper loaded: security_helper
INFO - 2024-03-28 18:42:38 --> Helper loaded: cookie_helper
INFO - 2024-03-28 18:42:39 --> Database Driver Class Initialized
INFO - 2024-03-28 18:42:39 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-28 18:42:39 --> Parser Class Initialized
INFO - 2024-03-28 18:42:39 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-03-28 18:42:39 --> Pagination Class Initialized
INFO - 2024-03-28 18:42:39 --> Form Validation Class Initialized
INFO - 2024-03-28 18:42:39 --> Controller Class Initialized
DEBUG - 2024-03-28 18:42:39 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-03-28 18:42:39 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-28 18:42:39 --> Model Class Initialized
INFO - 2024-03-28 18:42:39 --> Final output sent to browser
DEBUG - 2024-03-28 18:42:39 --> Total execution time: 0.0130
ERROR - 2024-03-28 18:42:47 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-03-28 18:42:47 --> Config Class Initialized
INFO - 2024-03-28 18:42:47 --> Hooks Class Initialized
DEBUG - 2024-03-28 18:42:47 --> UTF-8 Support Enabled
INFO - 2024-03-28 18:42:47 --> Utf8 Class Initialized
INFO - 2024-03-28 18:42:47 --> URI Class Initialized
INFO - 2024-03-28 18:42:47 --> Router Class Initialized
INFO - 2024-03-28 18:42:47 --> Output Class Initialized
INFO - 2024-03-28 18:42:47 --> Security Class Initialized
DEBUG - 2024-03-28 18:42:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-28 18:42:47 --> Input Class Initialized
INFO - 2024-03-28 18:42:47 --> Language Class Initialized
INFO - 2024-03-28 18:42:47 --> Loader Class Initialized
INFO - 2024-03-28 18:42:47 --> Helper loaded: url_helper
INFO - 2024-03-28 18:42:47 --> Helper loaded: file_helper
INFO - 2024-03-28 18:42:47 --> Helper loaded: html_helper
INFO - 2024-03-28 18:42:47 --> Helper loaded: text_helper
INFO - 2024-03-28 18:42:47 --> Helper loaded: form_helper
INFO - 2024-03-28 18:42:47 --> Helper loaded: lang_helper
INFO - 2024-03-28 18:42:47 --> Helper loaded: security_helper
INFO - 2024-03-28 18:42:47 --> Helper loaded: cookie_helper
INFO - 2024-03-28 18:42:47 --> Database Driver Class Initialized
INFO - 2024-03-28 18:42:47 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-28 18:42:47 --> Parser Class Initialized
INFO - 2024-03-28 18:42:47 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-03-28 18:42:47 --> Pagination Class Initialized
INFO - 2024-03-28 18:42:47 --> Form Validation Class Initialized
INFO - 2024-03-28 18:42:47 --> Controller Class Initialized
INFO - 2024-03-28 18:42:47 --> Model Class Initialized
DEBUG - 2024-03-28 18:42:47 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-03-28 18:42:47 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-28 18:42:47 --> Model Class Initialized
DEBUG - 2024-03-28 18:42:47 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-28 18:42:47 --> Model Class Initialized
INFO - 2024-03-28 18:42:47 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice.php
DEBUG - 2024-03-28 18:42:47 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-03-28 18:42:47 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-03-28 18:42:47 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-03-28 18:42:47 --> Model Class Initialized
INFO - 2024-03-28 18:42:47 --> Model Class Initialized
INFO - 2024-03-28 18:42:47 --> Model Class Initialized
INFO - 2024-03-28 18:42:47 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-03-28 18:42:47 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-03-28 18:42:47 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-03-28 18:42:47 --> Final output sent to browser
DEBUG - 2024-03-28 18:42:47 --> Total execution time: 0.2197
ERROR - 2024-03-28 18:42:48 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-03-28 18:42:48 --> Config Class Initialized
INFO - 2024-03-28 18:42:48 --> Hooks Class Initialized
DEBUG - 2024-03-28 18:42:48 --> UTF-8 Support Enabled
INFO - 2024-03-28 18:42:48 --> Utf8 Class Initialized
INFO - 2024-03-28 18:42:48 --> URI Class Initialized
INFO - 2024-03-28 18:42:48 --> Router Class Initialized
INFO - 2024-03-28 18:42:48 --> Output Class Initialized
INFO - 2024-03-28 18:42:48 --> Security Class Initialized
DEBUG - 2024-03-28 18:42:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-28 18:42:48 --> Input Class Initialized
INFO - 2024-03-28 18:42:48 --> Language Class Initialized
INFO - 2024-03-28 18:42:48 --> Loader Class Initialized
INFO - 2024-03-28 18:42:48 --> Helper loaded: url_helper
INFO - 2024-03-28 18:42:48 --> Helper loaded: file_helper
INFO - 2024-03-28 18:42:48 --> Helper loaded: html_helper
INFO - 2024-03-28 18:42:48 --> Helper loaded: text_helper
INFO - 2024-03-28 18:42:48 --> Helper loaded: form_helper
INFO - 2024-03-28 18:42:48 --> Helper loaded: lang_helper
INFO - 2024-03-28 18:42:48 --> Helper loaded: security_helper
INFO - 2024-03-28 18:42:48 --> Helper loaded: cookie_helper
INFO - 2024-03-28 18:42:48 --> Database Driver Class Initialized
INFO - 2024-03-28 18:42:48 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-28 18:42:48 --> Parser Class Initialized
INFO - 2024-03-28 18:42:48 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-03-28 18:42:48 --> Pagination Class Initialized
INFO - 2024-03-28 18:42:48 --> Form Validation Class Initialized
INFO - 2024-03-28 18:42:48 --> Controller Class Initialized
INFO - 2024-03-28 18:42:48 --> Model Class Initialized
DEBUG - 2024-03-28 18:42:48 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-03-28 18:42:48 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-28 18:42:48 --> Model Class Initialized
DEBUG - 2024-03-28 18:42:48 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-28 18:42:48 --> Model Class Initialized
INFO - 2024-03-28 18:42:48 --> Final output sent to browser
DEBUG - 2024-03-28 18:42:48 --> Total execution time: 0.0600
ERROR - 2024-03-28 18:43:14 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-03-28 18:43:14 --> Config Class Initialized
INFO - 2024-03-28 18:43:14 --> Hooks Class Initialized
DEBUG - 2024-03-28 18:43:14 --> UTF-8 Support Enabled
INFO - 2024-03-28 18:43:14 --> Utf8 Class Initialized
INFO - 2024-03-28 18:43:14 --> URI Class Initialized
DEBUG - 2024-03-28 18:43:14 --> No URI present. Default controller set.
INFO - 2024-03-28 18:43:14 --> Router Class Initialized
INFO - 2024-03-28 18:43:14 --> Output Class Initialized
INFO - 2024-03-28 18:43:14 --> Security Class Initialized
DEBUG - 2024-03-28 18:43:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-28 18:43:14 --> Input Class Initialized
INFO - 2024-03-28 18:43:14 --> Language Class Initialized
INFO - 2024-03-28 18:43:14 --> Loader Class Initialized
INFO - 2024-03-28 18:43:14 --> Helper loaded: url_helper
INFO - 2024-03-28 18:43:14 --> Helper loaded: file_helper
INFO - 2024-03-28 18:43:14 --> Helper loaded: html_helper
INFO - 2024-03-28 18:43:14 --> Helper loaded: text_helper
INFO - 2024-03-28 18:43:14 --> Helper loaded: form_helper
INFO - 2024-03-28 18:43:14 --> Helper loaded: lang_helper
INFO - 2024-03-28 18:43:14 --> Helper loaded: security_helper
INFO - 2024-03-28 18:43:14 --> Helper loaded: cookie_helper
INFO - 2024-03-28 18:43:14 --> Database Driver Class Initialized
INFO - 2024-03-28 18:43:14 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-28 18:43:14 --> Parser Class Initialized
INFO - 2024-03-28 18:43:14 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-03-28 18:43:14 --> Pagination Class Initialized
INFO - 2024-03-28 18:43:14 --> Form Validation Class Initialized
INFO - 2024-03-28 18:43:14 --> Controller Class Initialized
INFO - 2024-03-28 18:43:14 --> Model Class Initialized
DEBUG - 2024-03-28 18:43:14 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-28 18:43:14 --> Model Class Initialized
DEBUG - 2024-03-28 18:43:14 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-28 18:43:14 --> Model Class Initialized
INFO - 2024-03-28 18:43:14 --> Model Class Initialized
INFO - 2024-03-28 18:43:14 --> Model Class Initialized
INFO - 2024-03-28 18:43:14 --> Model Class Initialized
DEBUG - 2024-03-28 18:43:14 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-03-28 18:43:14 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-28 18:43:14 --> Model Class Initialized
INFO - 2024-03-28 18:43:14 --> Model Class Initialized
INFO - 2024-03-28 18:43:15 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2024-03-28 18:43:15 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-03-28 18:43:15 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-03-28 18:43:15 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-03-28 18:43:15 --> Model Class Initialized
INFO - 2024-03-28 18:43:15 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-03-28 18:43:15 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-03-28 18:43:15 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-03-28 18:43:15 --> Final output sent to browser
DEBUG - 2024-03-28 18:43:15 --> Total execution time: 0.4384
ERROR - 2024-03-28 18:52:51 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-03-28 18:52:51 --> Config Class Initialized
INFO - 2024-03-28 18:52:51 --> Hooks Class Initialized
DEBUG - 2024-03-28 18:52:51 --> UTF-8 Support Enabled
INFO - 2024-03-28 18:52:51 --> Utf8 Class Initialized
INFO - 2024-03-28 18:52:51 --> URI Class Initialized
DEBUG - 2024-03-28 18:52:51 --> No URI present. Default controller set.
INFO - 2024-03-28 18:52:51 --> Router Class Initialized
INFO - 2024-03-28 18:52:51 --> Output Class Initialized
INFO - 2024-03-28 18:52:51 --> Security Class Initialized
DEBUG - 2024-03-28 18:52:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-28 18:52:51 --> Input Class Initialized
INFO - 2024-03-28 18:52:51 --> Language Class Initialized
INFO - 2024-03-28 18:52:51 --> Loader Class Initialized
INFO - 2024-03-28 18:52:51 --> Helper loaded: url_helper
INFO - 2024-03-28 18:52:51 --> Helper loaded: file_helper
INFO - 2024-03-28 18:52:51 --> Helper loaded: html_helper
INFO - 2024-03-28 18:52:51 --> Helper loaded: text_helper
INFO - 2024-03-28 18:52:51 --> Helper loaded: form_helper
INFO - 2024-03-28 18:52:51 --> Helper loaded: lang_helper
INFO - 2024-03-28 18:52:51 --> Helper loaded: security_helper
INFO - 2024-03-28 18:52:51 --> Helper loaded: cookie_helper
INFO - 2024-03-28 18:52:51 --> Database Driver Class Initialized
INFO - 2024-03-28 18:52:51 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-28 18:52:51 --> Parser Class Initialized
INFO - 2024-03-28 18:52:51 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-03-28 18:52:51 --> Pagination Class Initialized
INFO - 2024-03-28 18:52:51 --> Form Validation Class Initialized
INFO - 2024-03-28 18:52:51 --> Controller Class Initialized
INFO - 2024-03-28 18:52:51 --> Model Class Initialized
DEBUG - 2024-03-28 18:52:51 --> Session class already loaded. Second attempt ignored.
ERROR - 2024-03-28 20:57:03 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-03-28 20:57:03 --> Config Class Initialized
INFO - 2024-03-28 20:57:03 --> Hooks Class Initialized
DEBUG - 2024-03-28 20:57:03 --> UTF-8 Support Enabled
INFO - 2024-03-28 20:57:03 --> Utf8 Class Initialized
INFO - 2024-03-28 20:57:03 --> URI Class Initialized
INFO - 2024-03-28 20:57:03 --> Router Class Initialized
INFO - 2024-03-28 20:57:03 --> Output Class Initialized
INFO - 2024-03-28 20:57:03 --> Security Class Initialized
DEBUG - 2024-03-28 20:57:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-28 20:57:03 --> Input Class Initialized
INFO - 2024-03-28 20:57:03 --> Language Class Initialized
ERROR - 2024-03-28 20:57:03 --> 404 Page Not Found: Well-known/assetlinks.json
