<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2024-04-17 01:43:35 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-04-17 01:43:35 --> Config Class Initialized
INFO - 2024-04-17 01:43:35 --> Hooks Class Initialized
DEBUG - 2024-04-17 01:43:35 --> UTF-8 Support Enabled
INFO - 2024-04-17 01:43:35 --> Utf8 Class Initialized
INFO - 2024-04-17 01:43:35 --> URI Class Initialized
DEBUG - 2024-04-17 01:43:35 --> No URI present. Default controller set.
INFO - 2024-04-17 01:43:35 --> Router Class Initialized
INFO - 2024-04-17 01:43:35 --> Output Class Initialized
INFO - 2024-04-17 01:43:35 --> Security Class Initialized
DEBUG - 2024-04-17 01:43:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-04-17 01:43:35 --> Input Class Initialized
INFO - 2024-04-17 01:43:35 --> Language Class Initialized
INFO - 2024-04-17 01:43:35 --> Loader Class Initialized
INFO - 2024-04-17 01:43:35 --> Helper loaded: url_helper
INFO - 2024-04-17 01:43:35 --> Helper loaded: file_helper
INFO - 2024-04-17 01:43:35 --> Helper loaded: html_helper
INFO - 2024-04-17 01:43:35 --> Helper loaded: text_helper
INFO - 2024-04-17 01:43:35 --> Helper loaded: form_helper
INFO - 2024-04-17 01:43:35 --> Helper loaded: lang_helper
INFO - 2024-04-17 01:43:35 --> Helper loaded: security_helper
INFO - 2024-04-17 01:43:35 --> Helper loaded: cookie_helper
INFO - 2024-04-17 01:43:35 --> Database Driver Class Initialized
INFO - 2024-04-17 01:43:35 --> Session: Class initialized using 'files' driver.
INFO - 2024-04-17 01:43:35 --> Parser Class Initialized
INFO - 2024-04-17 01:43:35 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-04-17 01:43:35 --> Pagination Class Initialized
INFO - 2024-04-17 01:43:35 --> Form Validation Class Initialized
INFO - 2024-04-17 01:43:35 --> Controller Class Initialized
INFO - 2024-04-17 01:43:35 --> Model Class Initialized
DEBUG - 2024-04-17 01:43:35 --> Session class already loaded. Second attempt ignored.
ERROR - 2024-04-17 01:43:36 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-04-17 01:43:36 --> Config Class Initialized
INFO - 2024-04-17 01:43:36 --> Hooks Class Initialized
DEBUG - 2024-04-17 01:43:36 --> UTF-8 Support Enabled
INFO - 2024-04-17 01:43:36 --> Utf8 Class Initialized
INFO - 2024-04-17 01:43:36 --> URI Class Initialized
INFO - 2024-04-17 01:43:36 --> Router Class Initialized
INFO - 2024-04-17 01:43:36 --> Output Class Initialized
INFO - 2024-04-17 01:43:36 --> Security Class Initialized
DEBUG - 2024-04-17 01:43:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-04-17 01:43:36 --> Input Class Initialized
INFO - 2024-04-17 01:43:36 --> Language Class Initialized
INFO - 2024-04-17 01:43:36 --> Loader Class Initialized
INFO - 2024-04-17 01:43:36 --> Helper loaded: url_helper
INFO - 2024-04-17 01:43:36 --> Helper loaded: file_helper
INFO - 2024-04-17 01:43:36 --> Helper loaded: html_helper
INFO - 2024-04-17 01:43:36 --> Helper loaded: text_helper
INFO - 2024-04-17 01:43:36 --> Helper loaded: form_helper
INFO - 2024-04-17 01:43:36 --> Helper loaded: lang_helper
INFO - 2024-04-17 01:43:36 --> Helper loaded: security_helper
INFO - 2024-04-17 01:43:36 --> Helper loaded: cookie_helper
INFO - 2024-04-17 01:43:36 --> Database Driver Class Initialized
INFO - 2024-04-17 01:43:36 --> Session: Class initialized using 'files' driver.
INFO - 2024-04-17 01:43:36 --> Parser Class Initialized
INFO - 2024-04-17 01:43:36 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-04-17 01:43:36 --> Pagination Class Initialized
INFO - 2024-04-17 01:43:36 --> Form Validation Class Initialized
INFO - 2024-04-17 01:43:36 --> Controller Class Initialized
INFO - 2024-04-17 01:43:36 --> Model Class Initialized
DEBUG - 2024-04-17 01:43:36 --> Session class already loaded. Second attempt ignored.
INFO - 2024-04-17 01:43:36 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2024-04-17 01:43:36 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-04-17 01:43:36 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-04-17 01:43:36 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-04-17 01:43:36 --> Model Class Initialized
INFO - 2024-04-17 01:43:36 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-04-17 01:43:36 --> Final output sent to browser
DEBUG - 2024-04-17 01:43:36 --> Total execution time: 0.3915
ERROR - 2024-04-17 01:43:48 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-04-17 01:43:48 --> Config Class Initialized
INFO - 2024-04-17 01:43:48 --> Hooks Class Initialized
DEBUG - 2024-04-17 01:43:48 --> UTF-8 Support Enabled
INFO - 2024-04-17 01:43:48 --> Utf8 Class Initialized
INFO - 2024-04-17 01:43:48 --> URI Class Initialized
INFO - 2024-04-17 01:43:48 --> Router Class Initialized
INFO - 2024-04-17 01:43:48 --> Output Class Initialized
INFO - 2024-04-17 01:43:48 --> Security Class Initialized
DEBUG - 2024-04-17 01:43:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-04-17 01:43:48 --> Input Class Initialized
INFO - 2024-04-17 01:43:48 --> Language Class Initialized
INFO - 2024-04-17 01:43:48 --> Loader Class Initialized
INFO - 2024-04-17 01:43:48 --> Helper loaded: url_helper
INFO - 2024-04-17 01:43:48 --> Helper loaded: file_helper
INFO - 2024-04-17 01:43:48 --> Helper loaded: html_helper
INFO - 2024-04-17 01:43:48 --> Helper loaded: text_helper
INFO - 2024-04-17 01:43:48 --> Helper loaded: form_helper
INFO - 2024-04-17 01:43:48 --> Helper loaded: lang_helper
INFO - 2024-04-17 01:43:48 --> Helper loaded: security_helper
INFO - 2024-04-17 01:43:48 --> Helper loaded: cookie_helper
INFO - 2024-04-17 01:43:48 --> Database Driver Class Initialized
INFO - 2024-04-17 01:43:48 --> Session: Class initialized using 'files' driver.
INFO - 2024-04-17 01:43:48 --> Parser Class Initialized
INFO - 2024-04-17 01:43:48 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-04-17 01:43:48 --> Pagination Class Initialized
INFO - 2024-04-17 01:43:48 --> Form Validation Class Initialized
INFO - 2024-04-17 01:43:48 --> Controller Class Initialized
INFO - 2024-04-17 01:43:48 --> Model Class Initialized
DEBUG - 2024-04-17 01:43:48 --> Session class already loaded. Second attempt ignored.
INFO - 2024-04-17 01:43:48 --> Model Class Initialized
INFO - 2024-04-17 01:43:48 --> Final output sent to browser
DEBUG - 2024-04-17 01:43:48 --> Total execution time: 0.0199
ERROR - 2024-04-17 01:43:48 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-04-17 01:43:48 --> Config Class Initialized
INFO - 2024-04-17 01:43:48 --> Hooks Class Initialized
DEBUG - 2024-04-17 01:43:48 --> UTF-8 Support Enabled
INFO - 2024-04-17 01:43:48 --> Utf8 Class Initialized
INFO - 2024-04-17 01:43:48 --> URI Class Initialized
DEBUG - 2024-04-17 01:43:48 --> No URI present. Default controller set.
INFO - 2024-04-17 01:43:48 --> Router Class Initialized
INFO - 2024-04-17 01:43:48 --> Output Class Initialized
INFO - 2024-04-17 01:43:48 --> Security Class Initialized
DEBUG - 2024-04-17 01:43:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-04-17 01:43:48 --> Input Class Initialized
INFO - 2024-04-17 01:43:48 --> Language Class Initialized
INFO - 2024-04-17 01:43:48 --> Loader Class Initialized
INFO - 2024-04-17 01:43:48 --> Helper loaded: url_helper
INFO - 2024-04-17 01:43:48 --> Helper loaded: file_helper
INFO - 2024-04-17 01:43:48 --> Helper loaded: html_helper
INFO - 2024-04-17 01:43:48 --> Helper loaded: text_helper
INFO - 2024-04-17 01:43:48 --> Helper loaded: form_helper
INFO - 2024-04-17 01:43:48 --> Helper loaded: lang_helper
INFO - 2024-04-17 01:43:48 --> Helper loaded: security_helper
INFO - 2024-04-17 01:43:48 --> Helper loaded: cookie_helper
INFO - 2024-04-17 01:43:48 --> Database Driver Class Initialized
INFO - 2024-04-17 01:43:48 --> Session: Class initialized using 'files' driver.
INFO - 2024-04-17 01:43:48 --> Parser Class Initialized
INFO - 2024-04-17 01:43:48 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-04-17 01:43:48 --> Pagination Class Initialized
INFO - 2024-04-17 01:43:48 --> Form Validation Class Initialized
INFO - 2024-04-17 01:43:48 --> Controller Class Initialized
INFO - 2024-04-17 01:43:48 --> Model Class Initialized
DEBUG - 2024-04-17 01:43:48 --> Session class already loaded. Second attempt ignored.
INFO - 2024-04-17 01:43:48 --> Model Class Initialized
DEBUG - 2024-04-17 01:43:48 --> Session class already loaded. Second attempt ignored.
INFO - 2024-04-17 01:43:48 --> Model Class Initialized
INFO - 2024-04-17 01:43:48 --> Model Class Initialized
INFO - 2024-04-17 01:43:48 --> Model Class Initialized
INFO - 2024-04-17 01:43:48 --> Model Class Initialized
DEBUG - 2024-04-17 01:43:48 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-04-17 01:43:48 --> Session class already loaded. Second attempt ignored.
INFO - 2024-04-17 01:43:48 --> Model Class Initialized
INFO - 2024-04-17 01:43:48 --> Model Class Initialized
INFO - 2024-04-17 01:43:48 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2024-04-17 01:43:48 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-04-17 01:43:48 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-04-17 01:43:48 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-04-17 01:43:48 --> Model Class Initialized
INFO - 2024-04-17 01:43:48 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-04-17 01:43:48 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-04-17 01:43:48 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-04-17 01:43:48 --> Final output sent to browser
DEBUG - 2024-04-17 01:43:48 --> Total execution time: 0.3671
ERROR - 2024-04-17 01:44:04 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-04-17 01:44:04 --> Config Class Initialized
INFO - 2024-04-17 01:44:04 --> Hooks Class Initialized
DEBUG - 2024-04-17 01:44:04 --> UTF-8 Support Enabled
INFO - 2024-04-17 01:44:04 --> Utf8 Class Initialized
INFO - 2024-04-17 01:44:04 --> URI Class Initialized
INFO - 2024-04-17 01:44:04 --> Router Class Initialized
INFO - 2024-04-17 01:44:04 --> Output Class Initialized
INFO - 2024-04-17 01:44:04 --> Security Class Initialized
DEBUG - 2024-04-17 01:44:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-04-17 01:44:04 --> Input Class Initialized
INFO - 2024-04-17 01:44:04 --> Language Class Initialized
INFO - 2024-04-17 01:44:04 --> Loader Class Initialized
INFO - 2024-04-17 01:44:04 --> Helper loaded: url_helper
INFO - 2024-04-17 01:44:04 --> Helper loaded: file_helper
INFO - 2024-04-17 01:44:04 --> Helper loaded: html_helper
INFO - 2024-04-17 01:44:04 --> Helper loaded: text_helper
INFO - 2024-04-17 01:44:04 --> Helper loaded: form_helper
INFO - 2024-04-17 01:44:04 --> Helper loaded: lang_helper
INFO - 2024-04-17 01:44:04 --> Helper loaded: security_helper
INFO - 2024-04-17 01:44:04 --> Helper loaded: cookie_helper
INFO - 2024-04-17 01:44:04 --> Database Driver Class Initialized
INFO - 2024-04-17 01:44:04 --> Session: Class initialized using 'files' driver.
INFO - 2024-04-17 01:44:04 --> Parser Class Initialized
INFO - 2024-04-17 01:44:04 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-04-17 01:44:04 --> Pagination Class Initialized
INFO - 2024-04-17 01:44:04 --> Form Validation Class Initialized
INFO - 2024-04-17 01:44:04 --> Controller Class Initialized
INFO - 2024-04-17 01:44:04 --> Model Class Initialized
DEBUG - 2024-04-17 01:44:04 --> Session class already loaded. Second attempt ignored.
INFO - 2024-04-17 01:44:04 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2024-04-17 01:44:04 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-04-17 01:44:04 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-04-17 01:44:04 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-04-17 01:44:04 --> Model Class Initialized
INFO - 2024-04-17 01:44:04 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-04-17 01:44:04 --> Final output sent to browser
DEBUG - 2024-04-17 01:44:04 --> Total execution time: 0.0318
ERROR - 2024-04-17 01:44:04 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-04-17 01:44:04 --> Config Class Initialized
INFO - 2024-04-17 01:44:04 --> Hooks Class Initialized
DEBUG - 2024-04-17 01:44:04 --> UTF-8 Support Enabled
INFO - 2024-04-17 01:44:04 --> Utf8 Class Initialized
INFO - 2024-04-17 01:44:04 --> URI Class Initialized
INFO - 2024-04-17 01:44:04 --> Router Class Initialized
INFO - 2024-04-17 01:44:04 --> Output Class Initialized
INFO - 2024-04-17 01:44:04 --> Security Class Initialized
DEBUG - 2024-04-17 01:44:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-04-17 01:44:04 --> Input Class Initialized
INFO - 2024-04-17 01:44:04 --> Language Class Initialized
INFO - 2024-04-17 01:44:04 --> Loader Class Initialized
INFO - 2024-04-17 01:44:04 --> Helper loaded: url_helper
INFO - 2024-04-17 01:44:04 --> Helper loaded: file_helper
INFO - 2024-04-17 01:44:04 --> Helper loaded: html_helper
INFO - 2024-04-17 01:44:04 --> Helper loaded: text_helper
INFO - 2024-04-17 01:44:04 --> Helper loaded: form_helper
INFO - 2024-04-17 01:44:04 --> Helper loaded: lang_helper
INFO - 2024-04-17 01:44:04 --> Helper loaded: security_helper
INFO - 2024-04-17 01:44:04 --> Helper loaded: cookie_helper
INFO - 2024-04-17 01:44:04 --> Database Driver Class Initialized
INFO - 2024-04-17 01:44:04 --> Session: Class initialized using 'files' driver.
INFO - 2024-04-17 01:44:04 --> Parser Class Initialized
INFO - 2024-04-17 01:44:04 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-04-17 01:44:04 --> Pagination Class Initialized
INFO - 2024-04-17 01:44:04 --> Form Validation Class Initialized
INFO - 2024-04-17 01:44:04 --> Controller Class Initialized
INFO - 2024-04-17 01:44:04 --> Model Class Initialized
DEBUG - 2024-04-17 01:44:04 --> Session class already loaded. Second attempt ignored.
INFO - 2024-04-17 01:44:04 --> Model Class Initialized
DEBUG - 2024-04-17 01:44:04 --> Session class already loaded. Second attempt ignored.
INFO - 2024-04-17 01:44:04 --> Model Class Initialized
INFO - 2024-04-17 01:44:04 --> Model Class Initialized
INFO - 2024-04-17 01:44:04 --> Model Class Initialized
INFO - 2024-04-17 01:44:04 --> Model Class Initialized
DEBUG - 2024-04-17 01:44:04 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-04-17 01:44:04 --> Session class already loaded. Second attempt ignored.
INFO - 2024-04-17 01:44:04 --> Model Class Initialized
INFO - 2024-04-17 01:44:04 --> Model Class Initialized
INFO - 2024-04-17 01:44:05 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2024-04-17 01:44:05 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-04-17 01:44:05 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-04-17 01:44:05 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-04-17 01:44:05 --> Model Class Initialized
INFO - 2024-04-17 01:44:05 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-04-17 01:44:05 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-04-17 01:44:05 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-04-17 01:44:05 --> Final output sent to browser
DEBUG - 2024-04-17 01:44:05 --> Total execution time: 0.3641
ERROR - 2024-04-17 08:47:07 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-04-17 08:47:07 --> Config Class Initialized
INFO - 2024-04-17 08:47:07 --> Hooks Class Initialized
DEBUG - 2024-04-17 08:47:07 --> UTF-8 Support Enabled
INFO - 2024-04-17 08:47:07 --> Utf8 Class Initialized
INFO - 2024-04-17 08:47:07 --> URI Class Initialized
DEBUG - 2024-04-17 08:47:07 --> No URI present. Default controller set.
INFO - 2024-04-17 08:47:07 --> Router Class Initialized
INFO - 2024-04-17 08:47:07 --> Output Class Initialized
INFO - 2024-04-17 08:47:07 --> Security Class Initialized
DEBUG - 2024-04-17 08:47:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-04-17 08:47:07 --> Input Class Initialized
INFO - 2024-04-17 08:47:07 --> Language Class Initialized
INFO - 2024-04-17 08:47:07 --> Loader Class Initialized
INFO - 2024-04-17 08:47:07 --> Helper loaded: url_helper
INFO - 2024-04-17 08:47:07 --> Helper loaded: file_helper
INFO - 2024-04-17 08:47:07 --> Helper loaded: html_helper
INFO - 2024-04-17 08:47:07 --> Helper loaded: text_helper
INFO - 2024-04-17 08:47:07 --> Helper loaded: form_helper
INFO - 2024-04-17 08:47:07 --> Helper loaded: lang_helper
INFO - 2024-04-17 08:47:07 --> Helper loaded: security_helper
INFO - 2024-04-17 08:47:07 --> Helper loaded: cookie_helper
INFO - 2024-04-17 08:47:07 --> Database Driver Class Initialized
INFO - 2024-04-17 08:47:07 --> Session: Class initialized using 'files' driver.
INFO - 2024-04-17 08:47:07 --> Parser Class Initialized
INFO - 2024-04-17 08:47:07 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-04-17 08:47:07 --> Pagination Class Initialized
INFO - 2024-04-17 08:47:07 --> Form Validation Class Initialized
INFO - 2024-04-17 08:47:07 --> Controller Class Initialized
INFO - 2024-04-17 08:47:07 --> Model Class Initialized
DEBUG - 2024-04-17 08:47:07 --> Session class already loaded. Second attempt ignored.
ERROR - 2024-04-17 08:47:08 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-04-17 08:47:08 --> Config Class Initialized
INFO - 2024-04-17 08:47:08 --> Hooks Class Initialized
DEBUG - 2024-04-17 08:47:08 --> UTF-8 Support Enabled
INFO - 2024-04-17 08:47:08 --> Utf8 Class Initialized
INFO - 2024-04-17 08:47:08 --> URI Class Initialized
INFO - 2024-04-17 08:47:08 --> Router Class Initialized
INFO - 2024-04-17 08:47:08 --> Output Class Initialized
INFO - 2024-04-17 08:47:08 --> Security Class Initialized
DEBUG - 2024-04-17 08:47:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-04-17 08:47:08 --> Input Class Initialized
INFO - 2024-04-17 08:47:08 --> Language Class Initialized
INFO - 2024-04-17 08:47:08 --> Loader Class Initialized
INFO - 2024-04-17 08:47:08 --> Helper loaded: url_helper
INFO - 2024-04-17 08:47:08 --> Helper loaded: file_helper
INFO - 2024-04-17 08:47:08 --> Helper loaded: html_helper
INFO - 2024-04-17 08:47:08 --> Helper loaded: text_helper
INFO - 2024-04-17 08:47:08 --> Helper loaded: form_helper
INFO - 2024-04-17 08:47:08 --> Helper loaded: lang_helper
INFO - 2024-04-17 08:47:08 --> Helper loaded: security_helper
INFO - 2024-04-17 08:47:08 --> Helper loaded: cookie_helper
INFO - 2024-04-17 08:47:08 --> Database Driver Class Initialized
INFO - 2024-04-17 08:47:08 --> Session: Class initialized using 'files' driver.
INFO - 2024-04-17 08:47:08 --> Parser Class Initialized
INFO - 2024-04-17 08:47:08 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-04-17 08:47:08 --> Pagination Class Initialized
INFO - 2024-04-17 08:47:08 --> Form Validation Class Initialized
INFO - 2024-04-17 08:47:08 --> Controller Class Initialized
INFO - 2024-04-17 08:47:08 --> Model Class Initialized
DEBUG - 2024-04-17 08:47:08 --> Session class already loaded. Second attempt ignored.
INFO - 2024-04-17 08:47:08 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2024-04-17 08:47:08 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-04-17 08:47:08 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-04-17 08:47:08 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-04-17 08:47:08 --> Model Class Initialized
INFO - 2024-04-17 08:47:08 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-04-17 08:47:08 --> Final output sent to browser
DEBUG - 2024-04-17 08:47:08 --> Total execution time: 0.0354
ERROR - 2024-04-17 10:09:08 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-04-17 10:09:08 --> Config Class Initialized
INFO - 2024-04-17 10:09:08 --> Hooks Class Initialized
DEBUG - 2024-04-17 10:09:08 --> UTF-8 Support Enabled
INFO - 2024-04-17 10:09:08 --> Utf8 Class Initialized
INFO - 2024-04-17 10:09:08 --> URI Class Initialized
INFO - 2024-04-17 10:09:08 --> Router Class Initialized
INFO - 2024-04-17 10:09:08 --> Output Class Initialized
INFO - 2024-04-17 10:09:08 --> Security Class Initialized
DEBUG - 2024-04-17 10:09:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-04-17 10:09:08 --> Input Class Initialized
INFO - 2024-04-17 10:09:08 --> Language Class Initialized
ERROR - 2024-04-17 10:09:08 --> 404 Page Not Found: Well-known/assetlinks.json
ERROR - 2024-04-17 17:39:15 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-04-17 17:39:15 --> Config Class Initialized
INFO - 2024-04-17 17:39:15 --> Hooks Class Initialized
DEBUG - 2024-04-17 17:39:15 --> UTF-8 Support Enabled
INFO - 2024-04-17 17:39:15 --> Utf8 Class Initialized
INFO - 2024-04-17 17:39:15 --> URI Class Initialized
INFO - 2024-04-17 17:39:15 --> Router Class Initialized
INFO - 2024-04-17 17:39:15 --> Output Class Initialized
INFO - 2024-04-17 17:39:15 --> Security Class Initialized
DEBUG - 2024-04-17 17:39:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-04-17 17:39:15 --> Input Class Initialized
INFO - 2024-04-17 17:39:15 --> Language Class Initialized
ERROR - 2024-04-17 17:39:15 --> 404 Page Not Found: Well-known/assetlinks.json
