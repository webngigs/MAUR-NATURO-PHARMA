<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2024-02-03 02:27:24 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-03 02:27:24 --> Config Class Initialized
INFO - 2024-02-03 02:27:24 --> Hooks Class Initialized
DEBUG - 2024-02-03 02:27:24 --> UTF-8 Support Enabled
INFO - 2024-02-03 02:27:24 --> Utf8 Class Initialized
INFO - 2024-02-03 02:27:24 --> URI Class Initialized
INFO - 2024-02-03 02:27:24 --> Router Class Initialized
INFO - 2024-02-03 02:27:24 --> Output Class Initialized
INFO - 2024-02-03 02:27:24 --> Security Class Initialized
DEBUG - 2024-02-03 02:27:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-03 02:27:24 --> Input Class Initialized
INFO - 2024-02-03 02:27:24 --> Language Class Initialized
ERROR - 2024-02-03 02:27:24 --> 404 Page Not Found: Well-known/assetlinks.json
ERROR - 2024-02-03 10:49:50 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-03 10:49:50 --> Config Class Initialized
INFO - 2024-02-03 10:49:50 --> Hooks Class Initialized
DEBUG - 2024-02-03 10:49:50 --> UTF-8 Support Enabled
INFO - 2024-02-03 10:49:50 --> Utf8 Class Initialized
INFO - 2024-02-03 10:49:50 --> URI Class Initialized
DEBUG - 2024-02-03 10:49:50 --> No URI present. Default controller set.
INFO - 2024-02-03 10:49:50 --> Router Class Initialized
INFO - 2024-02-03 10:49:50 --> Output Class Initialized
INFO - 2024-02-03 10:49:50 --> Security Class Initialized
DEBUG - 2024-02-03 10:49:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-03 10:49:50 --> Input Class Initialized
INFO - 2024-02-03 10:49:50 --> Language Class Initialized
INFO - 2024-02-03 10:49:50 --> Loader Class Initialized
INFO - 2024-02-03 10:49:50 --> Helper loaded: url_helper
INFO - 2024-02-03 10:49:50 --> Helper loaded: file_helper
INFO - 2024-02-03 10:49:50 --> Helper loaded: html_helper
INFO - 2024-02-03 10:49:50 --> Helper loaded: text_helper
INFO - 2024-02-03 10:49:50 --> Helper loaded: form_helper
INFO - 2024-02-03 10:49:50 --> Helper loaded: lang_helper
INFO - 2024-02-03 10:49:50 --> Helper loaded: security_helper
INFO - 2024-02-03 10:49:50 --> Helper loaded: cookie_helper
INFO - 2024-02-03 10:49:50 --> Database Driver Class Initialized
INFO - 2024-02-03 10:49:50 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-03 10:49:50 --> Parser Class Initialized
INFO - 2024-02-03 10:49:50 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-03 10:49:50 --> Pagination Class Initialized
INFO - 2024-02-03 10:49:50 --> Form Validation Class Initialized
INFO - 2024-02-03 10:49:50 --> Controller Class Initialized
INFO - 2024-02-03 10:49:50 --> Model Class Initialized
DEBUG - 2024-02-03 10:49:50 --> Session class already loaded. Second attempt ignored.
ERROR - 2024-02-03 13:37:18 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-03 13:37:18 --> Config Class Initialized
INFO - 2024-02-03 13:37:18 --> Hooks Class Initialized
DEBUG - 2024-02-03 13:37:18 --> UTF-8 Support Enabled
INFO - 2024-02-03 13:37:18 --> Utf8 Class Initialized
INFO - 2024-02-03 13:37:18 --> URI Class Initialized
INFO - 2024-02-03 13:37:18 --> Router Class Initialized
INFO - 2024-02-03 13:37:18 --> Output Class Initialized
INFO - 2024-02-03 13:37:18 --> Security Class Initialized
DEBUG - 2024-02-03 13:37:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-03 13:37:18 --> Input Class Initialized
INFO - 2024-02-03 13:37:18 --> Language Class Initialized
INFO - 2024-02-03 13:37:18 --> Loader Class Initialized
INFO - 2024-02-03 13:37:18 --> Helper loaded: url_helper
INFO - 2024-02-03 13:37:18 --> Helper loaded: file_helper
INFO - 2024-02-03 13:37:18 --> Helper loaded: html_helper
INFO - 2024-02-03 13:37:18 --> Helper loaded: text_helper
INFO - 2024-02-03 13:37:18 --> Helper loaded: form_helper
INFO - 2024-02-03 13:37:18 --> Helper loaded: lang_helper
INFO - 2024-02-03 13:37:18 --> Helper loaded: security_helper
INFO - 2024-02-03 13:37:18 --> Helper loaded: cookie_helper
INFO - 2024-02-03 13:37:18 --> Database Driver Class Initialized
INFO - 2024-02-03 13:37:18 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-03 13:37:18 --> Parser Class Initialized
INFO - 2024-02-03 13:37:18 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-03 13:37:18 --> Pagination Class Initialized
INFO - 2024-02-03 13:37:18 --> Form Validation Class Initialized
INFO - 2024-02-03 13:37:18 --> Controller Class Initialized
ERROR - 2024-02-03 13:37:18 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-03 13:37:18 --> Config Class Initialized
INFO - 2024-02-03 13:37:18 --> Hooks Class Initialized
DEBUG - 2024-02-03 13:37:18 --> UTF-8 Support Enabled
INFO - 2024-02-03 13:37:18 --> Utf8 Class Initialized
INFO - 2024-02-03 13:37:18 --> URI Class Initialized
INFO - 2024-02-03 13:37:18 --> Router Class Initialized
INFO - 2024-02-03 13:37:18 --> Output Class Initialized
INFO - 2024-02-03 13:37:18 --> Security Class Initialized
DEBUG - 2024-02-03 13:37:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-03 13:37:18 --> Input Class Initialized
INFO - 2024-02-03 13:37:18 --> Language Class Initialized
INFO - 2024-02-03 13:37:18 --> Loader Class Initialized
INFO - 2024-02-03 13:37:18 --> Helper loaded: url_helper
INFO - 2024-02-03 13:37:18 --> Helper loaded: file_helper
INFO - 2024-02-03 13:37:18 --> Helper loaded: html_helper
INFO - 2024-02-03 13:37:18 --> Helper loaded: text_helper
INFO - 2024-02-03 13:37:18 --> Helper loaded: form_helper
INFO - 2024-02-03 13:37:18 --> Helper loaded: lang_helper
INFO - 2024-02-03 13:37:18 --> Helper loaded: security_helper
INFO - 2024-02-03 13:37:18 --> Helper loaded: cookie_helper
INFO - 2024-02-03 13:37:18 --> Database Driver Class Initialized
INFO - 2024-02-03 13:37:18 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-03 13:37:18 --> Parser Class Initialized
INFO - 2024-02-03 13:37:18 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-03 13:37:18 --> Pagination Class Initialized
INFO - 2024-02-03 13:37:18 --> Form Validation Class Initialized
INFO - 2024-02-03 13:37:18 --> Controller Class Initialized
INFO - 2024-02-03 13:37:18 --> Model Class Initialized
DEBUG - 2024-02-03 13:37:18 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-03 13:37:18 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2024-02-03 13:37:18 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-02-03 13:37:18 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-02-03 13:37:18 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-02-03 13:37:18 --> Model Class Initialized
INFO - 2024-02-03 13:37:18 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-02-03 13:37:18 --> Final output sent to browser
DEBUG - 2024-02-03 13:37:18 --> Total execution time: 0.0358
ERROR - 2024-02-03 14:35:22 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-03 14:35:22 --> Config Class Initialized
INFO - 2024-02-03 14:35:22 --> Hooks Class Initialized
DEBUG - 2024-02-03 14:35:22 --> UTF-8 Support Enabled
INFO - 2024-02-03 14:35:22 --> Utf8 Class Initialized
INFO - 2024-02-03 14:35:22 --> URI Class Initialized
INFO - 2024-02-03 14:35:22 --> Router Class Initialized
INFO - 2024-02-03 14:35:22 --> Output Class Initialized
INFO - 2024-02-03 14:35:22 --> Security Class Initialized
DEBUG - 2024-02-03 14:35:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-03 14:35:22 --> Input Class Initialized
INFO - 2024-02-03 14:35:22 --> Language Class Initialized
ERROR - 2024-02-03 14:35:22 --> 404 Page Not Found: Well-known/assetlinks.json
ERROR - 2024-02-03 16:48:21 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-03 16:48:21 --> Config Class Initialized
INFO - 2024-02-03 16:48:21 --> Hooks Class Initialized
DEBUG - 2024-02-03 16:48:21 --> UTF-8 Support Enabled
INFO - 2024-02-03 16:48:21 --> Utf8 Class Initialized
INFO - 2024-02-03 16:48:21 --> URI Class Initialized
INFO - 2024-02-03 16:48:21 --> Router Class Initialized
INFO - 2024-02-03 16:48:21 --> Output Class Initialized
INFO - 2024-02-03 16:48:21 --> Security Class Initialized
DEBUG - 2024-02-03 16:48:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-03 16:48:21 --> Input Class Initialized
INFO - 2024-02-03 16:48:21 --> Language Class Initialized
INFO - 2024-02-03 16:48:21 --> Loader Class Initialized
INFO - 2024-02-03 16:48:21 --> Helper loaded: url_helper
INFO - 2024-02-03 16:48:21 --> Helper loaded: file_helper
INFO - 2024-02-03 16:48:21 --> Helper loaded: html_helper
INFO - 2024-02-03 16:48:21 --> Helper loaded: text_helper
INFO - 2024-02-03 16:48:21 --> Helper loaded: form_helper
INFO - 2024-02-03 16:48:21 --> Helper loaded: lang_helper
INFO - 2024-02-03 16:48:21 --> Helper loaded: security_helper
INFO - 2024-02-03 16:48:21 --> Helper loaded: cookie_helper
INFO - 2024-02-03 16:48:21 --> Database Driver Class Initialized
INFO - 2024-02-03 16:48:21 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-03 16:48:21 --> Parser Class Initialized
INFO - 2024-02-03 16:48:21 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-03 16:48:21 --> Pagination Class Initialized
INFO - 2024-02-03 16:48:21 --> Form Validation Class Initialized
INFO - 2024-02-03 16:48:21 --> Controller Class Initialized
INFO - 2024-02-03 16:48:21 --> Model Class Initialized
DEBUG - 2024-02-03 16:48:21 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-03 16:48:21 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2024-02-03 16:48:21 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-02-03 16:48:21 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-02-03 16:48:21 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-02-03 16:48:21 --> Model Class Initialized
INFO - 2024-02-03 16:48:21 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-02-03 16:48:21 --> Final output sent to browser
DEBUG - 2024-02-03 16:48:21 --> Total execution time: 0.0455
ERROR - 2024-02-03 16:52:17 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-03 16:52:17 --> Config Class Initialized
INFO - 2024-02-03 16:52:17 --> Hooks Class Initialized
DEBUG - 2024-02-03 16:52:17 --> UTF-8 Support Enabled
INFO - 2024-02-03 16:52:17 --> Utf8 Class Initialized
INFO - 2024-02-03 16:52:17 --> URI Class Initialized
DEBUG - 2024-02-03 16:52:17 --> No URI present. Default controller set.
INFO - 2024-02-03 16:52:17 --> Router Class Initialized
INFO - 2024-02-03 16:52:17 --> Output Class Initialized
INFO - 2024-02-03 16:52:17 --> Security Class Initialized
DEBUG - 2024-02-03 16:52:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-03 16:52:17 --> Input Class Initialized
INFO - 2024-02-03 16:52:17 --> Language Class Initialized
INFO - 2024-02-03 16:52:17 --> Loader Class Initialized
INFO - 2024-02-03 16:52:17 --> Helper loaded: url_helper
INFO - 2024-02-03 16:52:17 --> Helper loaded: file_helper
INFO - 2024-02-03 16:52:17 --> Helper loaded: html_helper
INFO - 2024-02-03 16:52:17 --> Helper loaded: text_helper
INFO - 2024-02-03 16:52:17 --> Helper loaded: form_helper
INFO - 2024-02-03 16:52:17 --> Helper loaded: lang_helper
INFO - 2024-02-03 16:52:17 --> Helper loaded: security_helper
INFO - 2024-02-03 16:52:17 --> Helper loaded: cookie_helper
INFO - 2024-02-03 16:52:17 --> Database Driver Class Initialized
INFO - 2024-02-03 16:52:17 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-03 16:52:17 --> Parser Class Initialized
INFO - 2024-02-03 16:52:17 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-03 16:52:17 --> Pagination Class Initialized
INFO - 2024-02-03 16:52:17 --> Form Validation Class Initialized
INFO - 2024-02-03 16:52:17 --> Controller Class Initialized
INFO - 2024-02-03 16:52:17 --> Model Class Initialized
DEBUG - 2024-02-03 16:52:17 --> Session class already loaded. Second attempt ignored.
ERROR - 2024-02-03 16:52:17 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-03 16:52:17 --> Config Class Initialized
INFO - 2024-02-03 16:52:17 --> Hooks Class Initialized
DEBUG - 2024-02-03 16:52:17 --> UTF-8 Support Enabled
INFO - 2024-02-03 16:52:17 --> Utf8 Class Initialized
INFO - 2024-02-03 16:52:17 --> URI Class Initialized
INFO - 2024-02-03 16:52:17 --> Router Class Initialized
INFO - 2024-02-03 16:52:17 --> Output Class Initialized
INFO - 2024-02-03 16:52:17 --> Security Class Initialized
DEBUG - 2024-02-03 16:52:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-03 16:52:17 --> Input Class Initialized
INFO - 2024-02-03 16:52:17 --> Language Class Initialized
INFO - 2024-02-03 16:52:17 --> Loader Class Initialized
INFO - 2024-02-03 16:52:17 --> Helper loaded: url_helper
INFO - 2024-02-03 16:52:17 --> Helper loaded: file_helper
INFO - 2024-02-03 16:52:17 --> Helper loaded: html_helper
INFO - 2024-02-03 16:52:17 --> Helper loaded: text_helper
INFO - 2024-02-03 16:52:17 --> Helper loaded: form_helper
INFO - 2024-02-03 16:52:17 --> Helper loaded: lang_helper
INFO - 2024-02-03 16:52:17 --> Helper loaded: security_helper
INFO - 2024-02-03 16:52:17 --> Helper loaded: cookie_helper
INFO - 2024-02-03 16:52:17 --> Database Driver Class Initialized
INFO - 2024-02-03 16:52:17 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-03 16:52:17 --> Parser Class Initialized
INFO - 2024-02-03 16:52:17 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-03 16:52:17 --> Pagination Class Initialized
INFO - 2024-02-03 16:52:17 --> Form Validation Class Initialized
INFO - 2024-02-03 16:52:17 --> Controller Class Initialized
INFO - 2024-02-03 16:52:17 --> Model Class Initialized
DEBUG - 2024-02-03 16:52:17 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-03 16:52:17 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2024-02-03 16:52:17 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-02-03 16:52:17 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-02-03 16:52:17 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-02-03 16:52:17 --> Model Class Initialized
INFO - 2024-02-03 16:52:17 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-02-03 16:52:17 --> Final output sent to browser
DEBUG - 2024-02-03 16:52:17 --> Total execution time: 0.0294
ERROR - 2024-02-03 16:52:21 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-03 16:52:21 --> Config Class Initialized
INFO - 2024-02-03 16:52:21 --> Hooks Class Initialized
DEBUG - 2024-02-03 16:52:21 --> UTF-8 Support Enabled
INFO - 2024-02-03 16:52:21 --> Utf8 Class Initialized
INFO - 2024-02-03 16:52:21 --> URI Class Initialized
INFO - 2024-02-03 16:52:21 --> Router Class Initialized
INFO - 2024-02-03 16:52:21 --> Output Class Initialized
INFO - 2024-02-03 16:52:21 --> Security Class Initialized
DEBUG - 2024-02-03 16:52:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-03 16:52:21 --> Input Class Initialized
INFO - 2024-02-03 16:52:21 --> Language Class Initialized
INFO - 2024-02-03 16:52:21 --> Loader Class Initialized
INFO - 2024-02-03 16:52:21 --> Helper loaded: url_helper
INFO - 2024-02-03 16:52:21 --> Helper loaded: file_helper
INFO - 2024-02-03 16:52:21 --> Helper loaded: html_helper
INFO - 2024-02-03 16:52:21 --> Helper loaded: text_helper
INFO - 2024-02-03 16:52:21 --> Helper loaded: form_helper
INFO - 2024-02-03 16:52:21 --> Helper loaded: lang_helper
INFO - 2024-02-03 16:52:21 --> Helper loaded: security_helper
INFO - 2024-02-03 16:52:21 --> Helper loaded: cookie_helper
INFO - 2024-02-03 16:52:21 --> Database Driver Class Initialized
INFO - 2024-02-03 16:52:21 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-03 16:52:21 --> Parser Class Initialized
INFO - 2024-02-03 16:52:21 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-03 16:52:21 --> Pagination Class Initialized
INFO - 2024-02-03 16:52:21 --> Form Validation Class Initialized
INFO - 2024-02-03 16:52:21 --> Controller Class Initialized
INFO - 2024-02-03 16:52:21 --> Model Class Initialized
DEBUG - 2024-02-03 16:52:21 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-03 16:52:21 --> Model Class Initialized
INFO - 2024-02-03 16:52:21 --> Final output sent to browser
DEBUG - 2024-02-03 16:52:21 --> Total execution time: 0.0223
ERROR - 2024-02-03 16:52:22 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-03 16:52:22 --> Config Class Initialized
INFO - 2024-02-03 16:52:22 --> Hooks Class Initialized
DEBUG - 2024-02-03 16:52:22 --> UTF-8 Support Enabled
INFO - 2024-02-03 16:52:22 --> Utf8 Class Initialized
INFO - 2024-02-03 16:52:22 --> URI Class Initialized
DEBUG - 2024-02-03 16:52:22 --> No URI present. Default controller set.
INFO - 2024-02-03 16:52:22 --> Router Class Initialized
INFO - 2024-02-03 16:52:22 --> Output Class Initialized
INFO - 2024-02-03 16:52:22 --> Security Class Initialized
DEBUG - 2024-02-03 16:52:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-03 16:52:22 --> Input Class Initialized
INFO - 2024-02-03 16:52:22 --> Language Class Initialized
INFO - 2024-02-03 16:52:22 --> Loader Class Initialized
INFO - 2024-02-03 16:52:22 --> Helper loaded: url_helper
INFO - 2024-02-03 16:52:22 --> Helper loaded: file_helper
INFO - 2024-02-03 16:52:22 --> Helper loaded: html_helper
INFO - 2024-02-03 16:52:22 --> Helper loaded: text_helper
INFO - 2024-02-03 16:52:22 --> Helper loaded: form_helper
INFO - 2024-02-03 16:52:22 --> Helper loaded: lang_helper
INFO - 2024-02-03 16:52:22 --> Helper loaded: security_helper
INFO - 2024-02-03 16:52:22 --> Helper loaded: cookie_helper
INFO - 2024-02-03 16:52:22 --> Database Driver Class Initialized
INFO - 2024-02-03 16:52:22 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-03 16:52:22 --> Parser Class Initialized
INFO - 2024-02-03 16:52:22 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-03 16:52:22 --> Pagination Class Initialized
INFO - 2024-02-03 16:52:22 --> Form Validation Class Initialized
INFO - 2024-02-03 16:52:22 --> Controller Class Initialized
INFO - 2024-02-03 16:52:22 --> Model Class Initialized
DEBUG - 2024-02-03 16:52:22 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-03 16:52:22 --> Model Class Initialized
DEBUG - 2024-02-03 16:52:22 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-03 16:52:22 --> Model Class Initialized
INFO - 2024-02-03 16:52:22 --> Model Class Initialized
INFO - 2024-02-03 16:52:22 --> Model Class Initialized
INFO - 2024-02-03 16:52:22 --> Model Class Initialized
DEBUG - 2024-02-03 16:52:22 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-03 16:52:22 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-03 16:52:22 --> Model Class Initialized
INFO - 2024-02-03 16:52:22 --> Model Class Initialized
INFO - 2024-02-03 16:52:22 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2024-02-03 16:52:22 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-02-03 16:52:22 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-02-03 16:52:22 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-02-03 16:52:22 --> Model Class Initialized
INFO - 2024-02-03 16:52:22 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-02-03 16:52:22 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-02-03 16:52:22 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-02-03 16:52:22 --> Final output sent to browser
DEBUG - 2024-02-03 16:52:22 --> Total execution time: 0.2371
ERROR - 2024-02-03 16:52:48 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-03 16:52:48 --> Config Class Initialized
INFO - 2024-02-03 16:52:48 --> Hooks Class Initialized
DEBUG - 2024-02-03 16:52:48 --> UTF-8 Support Enabled
INFO - 2024-02-03 16:52:48 --> Utf8 Class Initialized
INFO - 2024-02-03 16:52:48 --> URI Class Initialized
INFO - 2024-02-03 16:52:48 --> Router Class Initialized
INFO - 2024-02-03 16:52:48 --> Output Class Initialized
INFO - 2024-02-03 16:52:48 --> Security Class Initialized
DEBUG - 2024-02-03 16:52:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-03 16:52:48 --> Input Class Initialized
INFO - 2024-02-03 16:52:48 --> Language Class Initialized
INFO - 2024-02-03 16:52:48 --> Loader Class Initialized
INFO - 2024-02-03 16:52:48 --> Helper loaded: url_helper
INFO - 2024-02-03 16:52:48 --> Helper loaded: file_helper
INFO - 2024-02-03 16:52:48 --> Helper loaded: html_helper
INFO - 2024-02-03 16:52:48 --> Helper loaded: text_helper
INFO - 2024-02-03 16:52:48 --> Helper loaded: form_helper
INFO - 2024-02-03 16:52:48 --> Helper loaded: lang_helper
INFO - 2024-02-03 16:52:48 --> Helper loaded: security_helper
INFO - 2024-02-03 16:52:48 --> Helper loaded: cookie_helper
INFO - 2024-02-03 16:52:48 --> Database Driver Class Initialized
INFO - 2024-02-03 16:52:48 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-03 16:52:48 --> Parser Class Initialized
INFO - 2024-02-03 16:52:48 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-03 16:52:48 --> Pagination Class Initialized
INFO - 2024-02-03 16:52:48 --> Form Validation Class Initialized
INFO - 2024-02-03 16:52:48 --> Controller Class Initialized
INFO - 2024-02-03 16:52:48 --> Model Class Initialized
DEBUG - 2024-02-03 16:52:48 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-03 16:52:48 --> Final output sent to browser
DEBUG - 2024-02-03 16:52:48 --> Total execution time: 0.0202
ERROR - 2024-02-03 16:52:48 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-03 16:52:48 --> Config Class Initialized
INFO - 2024-02-03 16:52:48 --> Hooks Class Initialized
DEBUG - 2024-02-03 16:52:48 --> UTF-8 Support Enabled
INFO - 2024-02-03 16:52:48 --> Utf8 Class Initialized
INFO - 2024-02-03 16:52:48 --> URI Class Initialized
INFO - 2024-02-03 16:52:48 --> Router Class Initialized
INFO - 2024-02-03 16:52:48 --> Output Class Initialized
INFO - 2024-02-03 16:52:48 --> Security Class Initialized
DEBUG - 2024-02-03 16:52:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-03 16:52:48 --> Input Class Initialized
INFO - 2024-02-03 16:52:48 --> Language Class Initialized
INFO - 2024-02-03 16:52:48 --> Loader Class Initialized
INFO - 2024-02-03 16:52:48 --> Helper loaded: url_helper
INFO - 2024-02-03 16:52:48 --> Helper loaded: file_helper
INFO - 2024-02-03 16:52:48 --> Helper loaded: html_helper
INFO - 2024-02-03 16:52:48 --> Helper loaded: text_helper
INFO - 2024-02-03 16:52:48 --> Helper loaded: form_helper
INFO - 2024-02-03 16:52:48 --> Helper loaded: lang_helper
INFO - 2024-02-03 16:52:48 --> Helper loaded: security_helper
INFO - 2024-02-03 16:52:48 --> Helper loaded: cookie_helper
INFO - 2024-02-03 16:52:48 --> Database Driver Class Initialized
INFO - 2024-02-03 16:52:48 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-03 16:52:48 --> Parser Class Initialized
INFO - 2024-02-03 16:52:48 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-03 16:52:48 --> Pagination Class Initialized
INFO - 2024-02-03 16:52:48 --> Form Validation Class Initialized
INFO - 2024-02-03 16:52:48 --> Controller Class Initialized
INFO - 2024-02-03 16:52:48 --> Model Class Initialized
DEBUG - 2024-02-03 16:52:48 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-03 16:52:48 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2024-02-03 16:52:48 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-02-03 16:52:48 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-02-03 16:52:48 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-02-03 16:52:48 --> Model Class Initialized
INFO - 2024-02-03 16:52:48 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-02-03 16:52:48 --> Final output sent to browser
DEBUG - 2024-02-03 16:52:48 --> Total execution time: 0.0352
ERROR - 2024-02-03 16:52:59 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-03 16:52:59 --> Config Class Initialized
INFO - 2024-02-03 16:52:59 --> Hooks Class Initialized
DEBUG - 2024-02-03 16:52:59 --> UTF-8 Support Enabled
INFO - 2024-02-03 16:52:59 --> Utf8 Class Initialized
INFO - 2024-02-03 16:52:59 --> URI Class Initialized
INFO - 2024-02-03 16:52:59 --> Router Class Initialized
INFO - 2024-02-03 16:52:59 --> Output Class Initialized
INFO - 2024-02-03 16:52:59 --> Security Class Initialized
DEBUG - 2024-02-03 16:52:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-03 16:52:59 --> Input Class Initialized
INFO - 2024-02-03 16:52:59 --> Language Class Initialized
INFO - 2024-02-03 16:52:59 --> Loader Class Initialized
INFO - 2024-02-03 16:52:59 --> Helper loaded: url_helper
INFO - 2024-02-03 16:52:59 --> Helper loaded: file_helper
INFO - 2024-02-03 16:52:59 --> Helper loaded: html_helper
INFO - 2024-02-03 16:52:59 --> Helper loaded: text_helper
INFO - 2024-02-03 16:52:59 --> Helper loaded: form_helper
INFO - 2024-02-03 16:52:59 --> Helper loaded: lang_helper
INFO - 2024-02-03 16:52:59 --> Helper loaded: security_helper
INFO - 2024-02-03 16:52:59 --> Helper loaded: cookie_helper
INFO - 2024-02-03 16:52:59 --> Database Driver Class Initialized
INFO - 2024-02-03 16:52:59 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-03 16:52:59 --> Parser Class Initialized
INFO - 2024-02-03 16:52:59 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-03 16:52:59 --> Pagination Class Initialized
INFO - 2024-02-03 16:52:59 --> Form Validation Class Initialized
INFO - 2024-02-03 16:52:59 --> Controller Class Initialized
INFO - 2024-02-03 16:52:59 --> Model Class Initialized
DEBUG - 2024-02-03 16:52:59 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-03 16:52:59 --> Model Class Initialized
INFO - 2024-02-03 16:52:59 --> Final output sent to browser
DEBUG - 2024-02-03 16:52:59 --> Total execution time: 0.0172
ERROR - 2024-02-03 16:52:59 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-03 16:52:59 --> Config Class Initialized
INFO - 2024-02-03 16:52:59 --> Hooks Class Initialized
DEBUG - 2024-02-03 16:52:59 --> UTF-8 Support Enabled
INFO - 2024-02-03 16:52:59 --> Utf8 Class Initialized
INFO - 2024-02-03 16:52:59 --> URI Class Initialized
DEBUG - 2024-02-03 16:52:59 --> No URI present. Default controller set.
INFO - 2024-02-03 16:52:59 --> Router Class Initialized
INFO - 2024-02-03 16:52:59 --> Output Class Initialized
INFO - 2024-02-03 16:52:59 --> Security Class Initialized
DEBUG - 2024-02-03 16:52:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-03 16:52:59 --> Input Class Initialized
INFO - 2024-02-03 16:52:59 --> Language Class Initialized
INFO - 2024-02-03 16:52:59 --> Loader Class Initialized
INFO - 2024-02-03 16:52:59 --> Helper loaded: url_helper
INFO - 2024-02-03 16:52:59 --> Helper loaded: file_helper
INFO - 2024-02-03 16:52:59 --> Helper loaded: html_helper
INFO - 2024-02-03 16:52:59 --> Helper loaded: text_helper
INFO - 2024-02-03 16:52:59 --> Helper loaded: form_helper
INFO - 2024-02-03 16:52:59 --> Helper loaded: lang_helper
INFO - 2024-02-03 16:52:59 --> Helper loaded: security_helper
INFO - 2024-02-03 16:52:59 --> Helper loaded: cookie_helper
INFO - 2024-02-03 16:52:59 --> Database Driver Class Initialized
INFO - 2024-02-03 16:52:59 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-03 16:52:59 --> Parser Class Initialized
INFO - 2024-02-03 16:52:59 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-03 16:52:59 --> Pagination Class Initialized
INFO - 2024-02-03 16:52:59 --> Form Validation Class Initialized
INFO - 2024-02-03 16:52:59 --> Controller Class Initialized
INFO - 2024-02-03 16:52:59 --> Model Class Initialized
DEBUG - 2024-02-03 16:52:59 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-03 16:52:59 --> Model Class Initialized
DEBUG - 2024-02-03 16:52:59 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-03 16:52:59 --> Model Class Initialized
INFO - 2024-02-03 16:52:59 --> Model Class Initialized
INFO - 2024-02-03 16:52:59 --> Model Class Initialized
INFO - 2024-02-03 16:52:59 --> Model Class Initialized
DEBUG - 2024-02-03 16:52:59 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-03 16:52:59 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-03 16:52:59 --> Model Class Initialized
INFO - 2024-02-03 16:52:59 --> Model Class Initialized
INFO - 2024-02-03 16:52:59 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2024-02-03 16:52:59 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-02-03 16:52:59 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-02-03 16:52:59 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-02-03 16:52:59 --> Model Class Initialized
INFO - 2024-02-03 16:53:00 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-02-03 16:53:00 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-02-03 16:53:00 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-02-03 16:53:00 --> Final output sent to browser
DEBUG - 2024-02-03 16:53:00 --> Total execution time: 0.3925
ERROR - 2024-02-03 16:53:00 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-03 16:53:00 --> Config Class Initialized
INFO - 2024-02-03 16:53:00 --> Hooks Class Initialized
DEBUG - 2024-02-03 16:53:00 --> UTF-8 Support Enabled
INFO - 2024-02-03 16:53:00 --> Utf8 Class Initialized
INFO - 2024-02-03 16:53:00 --> URI Class Initialized
INFO - 2024-02-03 16:53:00 --> Router Class Initialized
INFO - 2024-02-03 16:53:00 --> Output Class Initialized
INFO - 2024-02-03 16:53:00 --> Security Class Initialized
DEBUG - 2024-02-03 16:53:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-03 16:53:00 --> Input Class Initialized
INFO - 2024-02-03 16:53:00 --> Language Class Initialized
INFO - 2024-02-03 16:53:00 --> Loader Class Initialized
INFO - 2024-02-03 16:53:00 --> Helper loaded: url_helper
INFO - 2024-02-03 16:53:00 --> Helper loaded: file_helper
INFO - 2024-02-03 16:53:00 --> Helper loaded: html_helper
INFO - 2024-02-03 16:53:00 --> Helper loaded: text_helper
INFO - 2024-02-03 16:53:00 --> Helper loaded: form_helper
INFO - 2024-02-03 16:53:00 --> Helper loaded: lang_helper
INFO - 2024-02-03 16:53:00 --> Helper loaded: security_helper
INFO - 2024-02-03 16:53:00 --> Helper loaded: cookie_helper
INFO - 2024-02-03 16:53:00 --> Database Driver Class Initialized
INFO - 2024-02-03 16:53:00 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-03 16:53:00 --> Parser Class Initialized
INFO - 2024-02-03 16:53:00 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-03 16:53:00 --> Pagination Class Initialized
INFO - 2024-02-03 16:53:00 --> Form Validation Class Initialized
INFO - 2024-02-03 16:53:00 --> Controller Class Initialized
DEBUG - 2024-02-03 16:53:00 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-03 16:53:00 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-03 16:53:00 --> Model Class Initialized
INFO - 2024-02-03 16:53:00 --> Final output sent to browser
DEBUG - 2024-02-03 16:53:00 --> Total execution time: 0.0131
ERROR - 2024-02-03 16:53:35 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-03 16:53:35 --> Config Class Initialized
INFO - 2024-02-03 16:53:35 --> Hooks Class Initialized
DEBUG - 2024-02-03 16:53:35 --> UTF-8 Support Enabled
INFO - 2024-02-03 16:53:35 --> Utf8 Class Initialized
INFO - 2024-02-03 16:53:35 --> URI Class Initialized
INFO - 2024-02-03 16:53:35 --> Router Class Initialized
INFO - 2024-02-03 16:53:35 --> Output Class Initialized
INFO - 2024-02-03 16:53:35 --> Security Class Initialized
DEBUG - 2024-02-03 16:53:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-03 16:53:35 --> Input Class Initialized
INFO - 2024-02-03 16:53:35 --> Language Class Initialized
INFO - 2024-02-03 16:53:35 --> Loader Class Initialized
INFO - 2024-02-03 16:53:35 --> Helper loaded: url_helper
INFO - 2024-02-03 16:53:35 --> Helper loaded: file_helper
INFO - 2024-02-03 16:53:35 --> Helper loaded: html_helper
INFO - 2024-02-03 16:53:35 --> Helper loaded: text_helper
INFO - 2024-02-03 16:53:35 --> Helper loaded: form_helper
INFO - 2024-02-03 16:53:35 --> Helper loaded: lang_helper
INFO - 2024-02-03 16:53:35 --> Helper loaded: security_helper
INFO - 2024-02-03 16:53:35 --> Helper loaded: cookie_helper
INFO - 2024-02-03 16:53:35 --> Database Driver Class Initialized
INFO - 2024-02-03 16:53:35 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-03 16:53:35 --> Parser Class Initialized
INFO - 2024-02-03 16:53:35 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-03 16:53:35 --> Pagination Class Initialized
INFO - 2024-02-03 16:53:35 --> Form Validation Class Initialized
INFO - 2024-02-03 16:53:35 --> Controller Class Initialized
INFO - 2024-02-03 16:53:35 --> Model Class Initialized
DEBUG - 2024-02-03 16:53:35 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-03 16:53:35 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-03 16:53:35 --> Model Class Initialized
DEBUG - 2024-02-03 16:53:35 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-03 16:53:35 --> Model Class Initialized
INFO - 2024-02-03 16:53:35 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice.php
DEBUG - 2024-02-03 16:53:35 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-02-03 16:53:35 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-02-03 16:53:35 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-02-03 16:53:35 --> Model Class Initialized
INFO - 2024-02-03 16:53:35 --> Model Class Initialized
INFO - 2024-02-03 16:53:35 --> Model Class Initialized
INFO - 2024-02-03 16:53:35 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-02-03 16:53:35 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-02-03 16:53:35 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-02-03 16:53:35 --> Final output sent to browser
DEBUG - 2024-02-03 16:53:35 --> Total execution time: 0.2147
ERROR - 2024-02-03 16:53:36 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-03 16:53:36 --> Config Class Initialized
INFO - 2024-02-03 16:53:36 --> Hooks Class Initialized
DEBUG - 2024-02-03 16:53:36 --> UTF-8 Support Enabled
INFO - 2024-02-03 16:53:36 --> Utf8 Class Initialized
INFO - 2024-02-03 16:53:36 --> URI Class Initialized
INFO - 2024-02-03 16:53:36 --> Router Class Initialized
INFO - 2024-02-03 16:53:36 --> Output Class Initialized
INFO - 2024-02-03 16:53:36 --> Security Class Initialized
DEBUG - 2024-02-03 16:53:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-03 16:53:36 --> Input Class Initialized
INFO - 2024-02-03 16:53:36 --> Language Class Initialized
INFO - 2024-02-03 16:53:36 --> Loader Class Initialized
INFO - 2024-02-03 16:53:36 --> Helper loaded: url_helper
INFO - 2024-02-03 16:53:36 --> Helper loaded: file_helper
INFO - 2024-02-03 16:53:36 --> Helper loaded: html_helper
INFO - 2024-02-03 16:53:36 --> Helper loaded: text_helper
INFO - 2024-02-03 16:53:36 --> Helper loaded: form_helper
INFO - 2024-02-03 16:53:36 --> Helper loaded: lang_helper
INFO - 2024-02-03 16:53:36 --> Helper loaded: security_helper
INFO - 2024-02-03 16:53:36 --> Helper loaded: cookie_helper
INFO - 2024-02-03 16:53:36 --> Database Driver Class Initialized
INFO - 2024-02-03 16:53:36 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-03 16:53:36 --> Parser Class Initialized
INFO - 2024-02-03 16:53:36 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-03 16:53:36 --> Pagination Class Initialized
INFO - 2024-02-03 16:53:36 --> Form Validation Class Initialized
INFO - 2024-02-03 16:53:36 --> Controller Class Initialized
INFO - 2024-02-03 16:53:36 --> Model Class Initialized
DEBUG - 2024-02-03 16:53:36 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-03 16:53:36 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-03 16:53:36 --> Model Class Initialized
DEBUG - 2024-02-03 16:53:36 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-03 16:53:36 --> Model Class Initialized
INFO - 2024-02-03 16:53:36 --> Final output sent to browser
DEBUG - 2024-02-03 16:53:36 --> Total execution time: 0.0546
ERROR - 2024-02-03 16:54:26 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-03 16:54:26 --> Config Class Initialized
INFO - 2024-02-03 16:54:26 --> Hooks Class Initialized
DEBUG - 2024-02-03 16:54:26 --> UTF-8 Support Enabled
INFO - 2024-02-03 16:54:26 --> Utf8 Class Initialized
INFO - 2024-02-03 16:54:26 --> URI Class Initialized
INFO - 2024-02-03 16:54:26 --> Router Class Initialized
INFO - 2024-02-03 16:54:26 --> Output Class Initialized
INFO - 2024-02-03 16:54:26 --> Security Class Initialized
DEBUG - 2024-02-03 16:54:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-03 16:54:26 --> Input Class Initialized
INFO - 2024-02-03 16:54:26 --> Language Class Initialized
INFO - 2024-02-03 16:54:26 --> Loader Class Initialized
INFO - 2024-02-03 16:54:26 --> Helper loaded: url_helper
INFO - 2024-02-03 16:54:26 --> Helper loaded: file_helper
INFO - 2024-02-03 16:54:26 --> Helper loaded: html_helper
INFO - 2024-02-03 16:54:26 --> Helper loaded: text_helper
INFO - 2024-02-03 16:54:26 --> Helper loaded: form_helper
INFO - 2024-02-03 16:54:26 --> Helper loaded: lang_helper
INFO - 2024-02-03 16:54:26 --> Helper loaded: security_helper
INFO - 2024-02-03 16:54:26 --> Helper loaded: cookie_helper
INFO - 2024-02-03 16:54:26 --> Database Driver Class Initialized
INFO - 2024-02-03 16:54:26 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-03 16:54:26 --> Parser Class Initialized
INFO - 2024-02-03 16:54:26 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-03 16:54:26 --> Pagination Class Initialized
INFO - 2024-02-03 16:54:26 --> Form Validation Class Initialized
INFO - 2024-02-03 16:54:26 --> Controller Class Initialized
INFO - 2024-02-03 16:54:26 --> Model Class Initialized
DEBUG - 2024-02-03 16:54:26 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-03 16:54:26 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-03 16:54:26 --> Model Class Initialized
DEBUG - 2024-02-03 16:54:26 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-03 16:54:26 --> Model Class Initialized
INFO - 2024-02-03 16:54:27 --> Final output sent to browser
DEBUG - 2024-02-03 16:54:27 --> Total execution time: 1.2062
ERROR - 2024-02-03 16:54:52 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-03 16:54:52 --> Config Class Initialized
INFO - 2024-02-03 16:54:52 --> Hooks Class Initialized
DEBUG - 2024-02-03 16:54:52 --> UTF-8 Support Enabled
INFO - 2024-02-03 16:54:52 --> Utf8 Class Initialized
INFO - 2024-02-03 16:54:52 --> URI Class Initialized
INFO - 2024-02-03 16:54:52 --> Router Class Initialized
INFO - 2024-02-03 16:54:52 --> Output Class Initialized
INFO - 2024-02-03 16:54:52 --> Security Class Initialized
DEBUG - 2024-02-03 16:54:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-03 16:54:52 --> Input Class Initialized
INFO - 2024-02-03 16:54:52 --> Language Class Initialized
INFO - 2024-02-03 16:54:52 --> Loader Class Initialized
INFO - 2024-02-03 16:54:52 --> Helper loaded: url_helper
INFO - 2024-02-03 16:54:52 --> Helper loaded: file_helper
INFO - 2024-02-03 16:54:52 --> Helper loaded: html_helper
INFO - 2024-02-03 16:54:52 --> Helper loaded: text_helper
INFO - 2024-02-03 16:54:52 --> Helper loaded: form_helper
INFO - 2024-02-03 16:54:52 --> Helper loaded: lang_helper
INFO - 2024-02-03 16:54:52 --> Helper loaded: security_helper
INFO - 2024-02-03 16:54:52 --> Helper loaded: cookie_helper
INFO - 2024-02-03 16:54:52 --> Database Driver Class Initialized
INFO - 2024-02-03 16:54:52 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-03 16:54:52 --> Parser Class Initialized
INFO - 2024-02-03 16:54:52 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-03 16:54:52 --> Pagination Class Initialized
INFO - 2024-02-03 16:54:52 --> Form Validation Class Initialized
INFO - 2024-02-03 16:54:52 --> Controller Class Initialized
DEBUG - 2024-02-03 16:54:52 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-03 16:54:52 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-03 16:54:52 --> Model Class Initialized
DEBUG - 2024-02-03 16:54:52 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-03 16:54:52 --> Model Class Initialized
DEBUG - 2024-02-03 16:54:52 --> Lcustomer class already loaded. Second attempt ignored.
INFO - 2024-02-03 16:54:52 --> Model Class Initialized
INFO - 2024-02-03 16:54:52 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/customer/customer.php
DEBUG - 2024-02-03 16:54:52 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-02-03 16:54:52 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-02-03 16:54:52 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-02-03 16:54:52 --> Model Class Initialized
INFO - 2024-02-03 16:54:52 --> Model Class Initialized
INFO - 2024-02-03 16:54:52 --> Model Class Initialized
INFO - 2024-02-03 16:54:53 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-02-03 16:54:53 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-02-03 16:54:53 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-02-03 16:54:53 --> Final output sent to browser
DEBUG - 2024-02-03 16:54:53 --> Total execution time: 0.2222
ERROR - 2024-02-03 16:54:53 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-03 16:54:53 --> Config Class Initialized
INFO - 2024-02-03 16:54:53 --> Hooks Class Initialized
DEBUG - 2024-02-03 16:54:53 --> UTF-8 Support Enabled
INFO - 2024-02-03 16:54:53 --> Utf8 Class Initialized
INFO - 2024-02-03 16:54:53 --> URI Class Initialized
INFO - 2024-02-03 16:54:53 --> Router Class Initialized
INFO - 2024-02-03 16:54:53 --> Output Class Initialized
INFO - 2024-02-03 16:54:53 --> Security Class Initialized
DEBUG - 2024-02-03 16:54:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-03 16:54:53 --> Input Class Initialized
INFO - 2024-02-03 16:54:53 --> Language Class Initialized
INFO - 2024-02-03 16:54:53 --> Loader Class Initialized
INFO - 2024-02-03 16:54:53 --> Helper loaded: url_helper
INFO - 2024-02-03 16:54:53 --> Helper loaded: file_helper
INFO - 2024-02-03 16:54:53 --> Helper loaded: html_helper
INFO - 2024-02-03 16:54:53 --> Helper loaded: text_helper
INFO - 2024-02-03 16:54:53 --> Helper loaded: form_helper
INFO - 2024-02-03 16:54:53 --> Helper loaded: lang_helper
INFO - 2024-02-03 16:54:53 --> Helper loaded: security_helper
INFO - 2024-02-03 16:54:53 --> Helper loaded: cookie_helper
INFO - 2024-02-03 16:54:53 --> Database Driver Class Initialized
INFO - 2024-02-03 16:54:53 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-03 16:54:53 --> Parser Class Initialized
INFO - 2024-02-03 16:54:53 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-03 16:54:53 --> Pagination Class Initialized
INFO - 2024-02-03 16:54:53 --> Form Validation Class Initialized
INFO - 2024-02-03 16:54:53 --> Controller Class Initialized
DEBUG - 2024-02-03 16:54:53 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-03 16:54:53 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-03 16:54:53 --> Model Class Initialized
DEBUG - 2024-02-03 16:54:53 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-03 16:54:53 --> Model Class Initialized
INFO - 2024-02-03 16:54:53 --> Final output sent to browser
DEBUG - 2024-02-03 16:54:53 --> Total execution time: 0.0304
ERROR - 2024-02-03 16:55:45 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-03 16:55:45 --> Config Class Initialized
INFO - 2024-02-03 16:55:45 --> Hooks Class Initialized
DEBUG - 2024-02-03 16:55:45 --> UTF-8 Support Enabled
INFO - 2024-02-03 16:55:45 --> Utf8 Class Initialized
INFO - 2024-02-03 16:55:45 --> URI Class Initialized
DEBUG - 2024-02-03 16:55:45 --> No URI present. Default controller set.
INFO - 2024-02-03 16:55:45 --> Router Class Initialized
INFO - 2024-02-03 16:55:45 --> Output Class Initialized
INFO - 2024-02-03 16:55:45 --> Security Class Initialized
DEBUG - 2024-02-03 16:55:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-03 16:55:45 --> Input Class Initialized
INFO - 2024-02-03 16:55:45 --> Language Class Initialized
INFO - 2024-02-03 16:55:45 --> Loader Class Initialized
INFO - 2024-02-03 16:55:45 --> Helper loaded: url_helper
INFO - 2024-02-03 16:55:45 --> Helper loaded: file_helper
INFO - 2024-02-03 16:55:45 --> Helper loaded: html_helper
INFO - 2024-02-03 16:55:45 --> Helper loaded: text_helper
INFO - 2024-02-03 16:55:45 --> Helper loaded: form_helper
INFO - 2024-02-03 16:55:45 --> Helper loaded: lang_helper
INFO - 2024-02-03 16:55:45 --> Helper loaded: security_helper
INFO - 2024-02-03 16:55:45 --> Helper loaded: cookie_helper
INFO - 2024-02-03 16:55:45 --> Database Driver Class Initialized
INFO - 2024-02-03 16:55:45 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-03 16:55:45 --> Parser Class Initialized
INFO - 2024-02-03 16:55:45 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-03 16:55:45 --> Pagination Class Initialized
INFO - 2024-02-03 16:55:45 --> Form Validation Class Initialized
INFO - 2024-02-03 16:55:45 --> Controller Class Initialized
INFO - 2024-02-03 16:55:45 --> Model Class Initialized
DEBUG - 2024-02-03 16:55:45 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-03 16:55:45 --> Model Class Initialized
DEBUG - 2024-02-03 16:55:45 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-03 16:55:45 --> Model Class Initialized
INFO - 2024-02-03 16:55:45 --> Model Class Initialized
INFO - 2024-02-03 16:55:45 --> Model Class Initialized
INFO - 2024-02-03 16:55:45 --> Model Class Initialized
DEBUG - 2024-02-03 16:55:45 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-03 16:55:45 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-03 16:55:45 --> Model Class Initialized
INFO - 2024-02-03 16:55:45 --> Model Class Initialized
INFO - 2024-02-03 16:55:45 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2024-02-03 16:55:45 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-02-03 16:55:45 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-02-03 16:55:45 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-02-03 16:55:45 --> Model Class Initialized
INFO - 2024-02-03 16:55:45 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-02-03 16:55:45 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-02-03 16:55:45 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-02-03 16:55:45 --> Final output sent to browser
DEBUG - 2024-02-03 16:55:45 --> Total execution time: 0.4036
ERROR - 2024-02-03 16:55:57 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-03 16:55:57 --> Config Class Initialized
INFO - 2024-02-03 16:55:57 --> Hooks Class Initialized
DEBUG - 2024-02-03 16:55:57 --> UTF-8 Support Enabled
INFO - 2024-02-03 16:55:57 --> Utf8 Class Initialized
INFO - 2024-02-03 16:55:57 --> URI Class Initialized
INFO - 2024-02-03 16:55:57 --> Router Class Initialized
INFO - 2024-02-03 16:55:57 --> Output Class Initialized
INFO - 2024-02-03 16:55:57 --> Security Class Initialized
DEBUG - 2024-02-03 16:55:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-03 16:55:57 --> Input Class Initialized
INFO - 2024-02-03 16:55:57 --> Language Class Initialized
INFO - 2024-02-03 16:55:57 --> Loader Class Initialized
INFO - 2024-02-03 16:55:57 --> Helper loaded: url_helper
INFO - 2024-02-03 16:55:57 --> Helper loaded: file_helper
INFO - 2024-02-03 16:55:57 --> Helper loaded: html_helper
INFO - 2024-02-03 16:55:57 --> Helper loaded: text_helper
INFO - 2024-02-03 16:55:57 --> Helper loaded: form_helper
INFO - 2024-02-03 16:55:57 --> Helper loaded: lang_helper
INFO - 2024-02-03 16:55:57 --> Helper loaded: security_helper
INFO - 2024-02-03 16:55:57 --> Helper loaded: cookie_helper
INFO - 2024-02-03 16:55:57 --> Database Driver Class Initialized
INFO - 2024-02-03 16:55:57 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-03 16:55:57 --> Parser Class Initialized
INFO - 2024-02-03 16:55:57 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-03 16:55:57 --> Pagination Class Initialized
INFO - 2024-02-03 16:55:57 --> Form Validation Class Initialized
INFO - 2024-02-03 16:55:57 --> Controller Class Initialized
DEBUG - 2024-02-03 16:55:57 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-03 16:55:57 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-03 16:55:57 --> Model Class Initialized
DEBUG - 2024-02-03 16:55:57 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-03 16:55:57 --> Model Class Initialized
DEBUG - 2024-02-03 16:55:57 --> Lcustomer class already loaded. Second attempt ignored.
INFO - 2024-02-03 16:55:57 --> Model Class Initialized
INFO - 2024-02-03 16:55:57 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/customer/customer.php
DEBUG - 2024-02-03 16:55:57 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-02-03 16:55:57 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-02-03 16:55:58 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-02-03 16:55:58 --> Model Class Initialized
INFO - 2024-02-03 16:55:58 --> Model Class Initialized
INFO - 2024-02-03 16:55:58 --> Model Class Initialized
INFO - 2024-02-03 16:55:58 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-02-03 16:55:58 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-02-03 16:55:58 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-02-03 16:55:58 --> Final output sent to browser
DEBUG - 2024-02-03 16:55:58 --> Total execution time: 0.2048
ERROR - 2024-02-03 16:55:58 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-03 16:55:58 --> Config Class Initialized
INFO - 2024-02-03 16:55:58 --> Hooks Class Initialized
DEBUG - 2024-02-03 16:55:58 --> UTF-8 Support Enabled
INFO - 2024-02-03 16:55:58 --> Utf8 Class Initialized
INFO - 2024-02-03 16:55:58 --> URI Class Initialized
INFO - 2024-02-03 16:55:58 --> Router Class Initialized
INFO - 2024-02-03 16:55:58 --> Output Class Initialized
INFO - 2024-02-03 16:55:58 --> Security Class Initialized
DEBUG - 2024-02-03 16:55:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-03 16:55:58 --> Input Class Initialized
INFO - 2024-02-03 16:55:58 --> Language Class Initialized
INFO - 2024-02-03 16:55:58 --> Loader Class Initialized
INFO - 2024-02-03 16:55:58 --> Helper loaded: url_helper
INFO - 2024-02-03 16:55:58 --> Helper loaded: file_helper
INFO - 2024-02-03 16:55:58 --> Helper loaded: html_helper
INFO - 2024-02-03 16:55:58 --> Helper loaded: text_helper
INFO - 2024-02-03 16:55:58 --> Helper loaded: form_helper
INFO - 2024-02-03 16:55:58 --> Helper loaded: lang_helper
INFO - 2024-02-03 16:55:58 --> Helper loaded: security_helper
INFO - 2024-02-03 16:55:58 --> Helper loaded: cookie_helper
INFO - 2024-02-03 16:55:58 --> Database Driver Class Initialized
INFO - 2024-02-03 16:55:58 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-03 16:55:58 --> Parser Class Initialized
INFO - 2024-02-03 16:55:58 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-03 16:55:58 --> Pagination Class Initialized
INFO - 2024-02-03 16:55:58 --> Form Validation Class Initialized
INFO - 2024-02-03 16:55:58 --> Controller Class Initialized
DEBUG - 2024-02-03 16:55:58 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-03 16:55:58 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-03 16:55:58 --> Model Class Initialized
DEBUG - 2024-02-03 16:55:58 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-03 16:55:58 --> Model Class Initialized
INFO - 2024-02-03 16:55:58 --> Final output sent to browser
DEBUG - 2024-02-03 16:55:58 --> Total execution time: 0.0342
ERROR - 2024-02-03 17:13:35 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-03 17:13:35 --> Config Class Initialized
INFO - 2024-02-03 17:13:35 --> Hooks Class Initialized
DEBUG - 2024-02-03 17:13:35 --> UTF-8 Support Enabled
INFO - 2024-02-03 17:13:35 --> Utf8 Class Initialized
INFO - 2024-02-03 17:13:35 --> URI Class Initialized
DEBUG - 2024-02-03 17:13:35 --> No URI present. Default controller set.
INFO - 2024-02-03 17:13:35 --> Router Class Initialized
INFO - 2024-02-03 17:13:35 --> Output Class Initialized
INFO - 2024-02-03 17:13:35 --> Security Class Initialized
DEBUG - 2024-02-03 17:13:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-03 17:13:35 --> Input Class Initialized
INFO - 2024-02-03 17:13:35 --> Language Class Initialized
INFO - 2024-02-03 17:13:35 --> Loader Class Initialized
INFO - 2024-02-03 17:13:35 --> Helper loaded: url_helper
INFO - 2024-02-03 17:13:35 --> Helper loaded: file_helper
INFO - 2024-02-03 17:13:35 --> Helper loaded: html_helper
INFO - 2024-02-03 17:13:35 --> Helper loaded: text_helper
INFO - 2024-02-03 17:13:35 --> Helper loaded: form_helper
INFO - 2024-02-03 17:13:35 --> Helper loaded: lang_helper
INFO - 2024-02-03 17:13:35 --> Helper loaded: security_helper
INFO - 2024-02-03 17:13:35 --> Helper loaded: cookie_helper
INFO - 2024-02-03 17:13:35 --> Database Driver Class Initialized
INFO - 2024-02-03 17:13:35 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-03 17:13:35 --> Parser Class Initialized
INFO - 2024-02-03 17:13:35 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-03 17:13:35 --> Pagination Class Initialized
INFO - 2024-02-03 17:13:35 --> Form Validation Class Initialized
INFO - 2024-02-03 17:13:35 --> Controller Class Initialized
INFO - 2024-02-03 17:13:35 --> Model Class Initialized
DEBUG - 2024-02-03 17:13:35 --> Session class already loaded. Second attempt ignored.
ERROR - 2024-02-03 21:03:37 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-03 21:03:37 --> Config Class Initialized
INFO - 2024-02-03 21:03:37 --> Hooks Class Initialized
DEBUG - 2024-02-03 21:03:37 --> UTF-8 Support Enabled
INFO - 2024-02-03 21:03:37 --> Utf8 Class Initialized
INFO - 2024-02-03 21:03:37 --> URI Class Initialized
INFO - 2024-02-03 21:03:37 --> Router Class Initialized
INFO - 2024-02-03 21:03:37 --> Output Class Initialized
INFO - 2024-02-03 21:03:37 --> Security Class Initialized
DEBUG - 2024-02-03 21:03:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-03 21:03:37 --> Input Class Initialized
INFO - 2024-02-03 21:03:37 --> Language Class Initialized
ERROR - 2024-02-03 21:03:37 --> 404 Page Not Found: Enhancecp/index
ERROR - 2024-02-03 22:52:04 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-03 22:52:04 --> Config Class Initialized
INFO - 2024-02-03 22:52:04 --> Hooks Class Initialized
DEBUG - 2024-02-03 22:52:04 --> UTF-8 Support Enabled
INFO - 2024-02-03 22:52:04 --> Utf8 Class Initialized
INFO - 2024-02-03 22:52:04 --> URI Class Initialized
INFO - 2024-02-03 22:52:04 --> Router Class Initialized
INFO - 2024-02-03 22:52:04 --> Output Class Initialized
INFO - 2024-02-03 22:52:04 --> Security Class Initialized
DEBUG - 2024-02-03 22:52:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-03 22:52:04 --> Input Class Initialized
INFO - 2024-02-03 22:52:04 --> Language Class Initialized
ERROR - 2024-02-03 22:52:04 --> 404 Page Not Found: Wp-loginphp/index
