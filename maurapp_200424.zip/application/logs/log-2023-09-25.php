<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2023-09-25 06:04:01 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-25 06:04:01 --> Config Class Initialized
INFO - 2023-09-25 06:04:01 --> Hooks Class Initialized
DEBUG - 2023-09-25 06:04:01 --> UTF-8 Support Enabled
INFO - 2023-09-25 06:04:01 --> Utf8 Class Initialized
INFO - 2023-09-25 06:04:01 --> URI Class Initialized
DEBUG - 2023-09-25 06:04:01 --> No URI present. Default controller set.
INFO - 2023-09-25 06:04:01 --> Router Class Initialized
INFO - 2023-09-25 06:04:01 --> Output Class Initialized
INFO - 2023-09-25 06:04:01 --> Security Class Initialized
DEBUG - 2023-09-25 06:04:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-25 06:04:01 --> Input Class Initialized
INFO - 2023-09-25 06:04:01 --> Language Class Initialized
INFO - 2023-09-25 06:04:01 --> Loader Class Initialized
INFO - 2023-09-25 06:04:01 --> Helper loaded: url_helper
INFO - 2023-09-25 06:04:01 --> Helper loaded: file_helper
INFO - 2023-09-25 06:04:01 --> Helper loaded: html_helper
INFO - 2023-09-25 06:04:01 --> Helper loaded: text_helper
INFO - 2023-09-25 06:04:01 --> Helper loaded: form_helper
INFO - 2023-09-25 06:04:01 --> Helper loaded: lang_helper
INFO - 2023-09-25 06:04:01 --> Helper loaded: security_helper
INFO - 2023-09-25 06:04:01 --> Helper loaded: cookie_helper
INFO - 2023-09-25 06:04:01 --> Database Driver Class Initialized
INFO - 2023-09-25 06:04:01 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-25 06:04:01 --> Parser Class Initialized
INFO - 2023-09-25 06:04:01 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-25 06:04:01 --> Pagination Class Initialized
INFO - 2023-09-25 06:04:01 --> Form Validation Class Initialized
INFO - 2023-09-25 06:04:01 --> Controller Class Initialized
INFO - 2023-09-25 06:04:01 --> Model Class Initialized
DEBUG - 2023-09-25 06:04:01 --> Session class already loaded. Second attempt ignored.
ERROR - 2023-09-25 06:04:01 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-25 06:04:01 --> Config Class Initialized
INFO - 2023-09-25 06:04:01 --> Hooks Class Initialized
DEBUG - 2023-09-25 06:04:01 --> UTF-8 Support Enabled
INFO - 2023-09-25 06:04:01 --> Utf8 Class Initialized
INFO - 2023-09-25 06:04:01 --> URI Class Initialized
INFO - 2023-09-25 06:04:01 --> Router Class Initialized
INFO - 2023-09-25 06:04:01 --> Output Class Initialized
INFO - 2023-09-25 06:04:01 --> Security Class Initialized
DEBUG - 2023-09-25 06:04:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-25 06:04:01 --> Input Class Initialized
INFO - 2023-09-25 06:04:01 --> Language Class Initialized
INFO - 2023-09-25 06:04:01 --> Loader Class Initialized
INFO - 2023-09-25 06:04:01 --> Helper loaded: url_helper
INFO - 2023-09-25 06:04:01 --> Helper loaded: file_helper
INFO - 2023-09-25 06:04:01 --> Helper loaded: html_helper
INFO - 2023-09-25 06:04:01 --> Helper loaded: text_helper
INFO - 2023-09-25 06:04:01 --> Helper loaded: form_helper
INFO - 2023-09-25 06:04:01 --> Helper loaded: lang_helper
INFO - 2023-09-25 06:04:01 --> Helper loaded: security_helper
INFO - 2023-09-25 06:04:01 --> Helper loaded: cookie_helper
INFO - 2023-09-25 06:04:01 --> Database Driver Class Initialized
INFO - 2023-09-25 06:04:01 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-25 06:04:01 --> Parser Class Initialized
INFO - 2023-09-25 06:04:01 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-25 06:04:01 --> Pagination Class Initialized
INFO - 2023-09-25 06:04:01 --> Form Validation Class Initialized
INFO - 2023-09-25 06:04:01 --> Controller Class Initialized
INFO - 2023-09-25 06:04:01 --> Model Class Initialized
DEBUG - 2023-09-25 06:04:01 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-25 06:04:01 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2023-09-25 06:04:01 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-09-25 06:04:01 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-09-25 06:04:01 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-09-25 06:04:01 --> Model Class Initialized
INFO - 2023-09-25 06:04:01 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-09-25 06:04:01 --> Final output sent to browser
DEBUG - 2023-09-25 06:04:01 --> Total execution time: 0.0359
ERROR - 2023-09-25 06:04:04 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-25 06:04:04 --> Config Class Initialized
INFO - 2023-09-25 06:04:04 --> Hooks Class Initialized
DEBUG - 2023-09-25 06:04:04 --> UTF-8 Support Enabled
INFO - 2023-09-25 06:04:04 --> Utf8 Class Initialized
INFO - 2023-09-25 06:04:04 --> URI Class Initialized
INFO - 2023-09-25 06:04:04 --> Router Class Initialized
INFO - 2023-09-25 06:04:04 --> Output Class Initialized
INFO - 2023-09-25 06:04:04 --> Security Class Initialized
DEBUG - 2023-09-25 06:04:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-25 06:04:04 --> Input Class Initialized
INFO - 2023-09-25 06:04:04 --> Language Class Initialized
INFO - 2023-09-25 06:04:04 --> Loader Class Initialized
INFO - 2023-09-25 06:04:04 --> Helper loaded: url_helper
INFO - 2023-09-25 06:04:04 --> Helper loaded: file_helper
INFO - 2023-09-25 06:04:04 --> Helper loaded: html_helper
INFO - 2023-09-25 06:04:04 --> Helper loaded: text_helper
INFO - 2023-09-25 06:04:04 --> Helper loaded: form_helper
INFO - 2023-09-25 06:04:04 --> Helper loaded: lang_helper
INFO - 2023-09-25 06:04:04 --> Helper loaded: security_helper
INFO - 2023-09-25 06:04:04 --> Helper loaded: cookie_helper
INFO - 2023-09-25 06:04:04 --> Database Driver Class Initialized
INFO - 2023-09-25 06:04:04 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-25 06:04:04 --> Parser Class Initialized
INFO - 2023-09-25 06:04:04 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-25 06:04:04 --> Pagination Class Initialized
INFO - 2023-09-25 06:04:04 --> Form Validation Class Initialized
INFO - 2023-09-25 06:04:04 --> Controller Class Initialized
INFO - 2023-09-25 06:04:04 --> Model Class Initialized
DEBUG - 2023-09-25 06:04:04 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-25 06:04:04 --> Model Class Initialized
INFO - 2023-09-25 06:04:04 --> Final output sent to browser
DEBUG - 2023-09-25 06:04:04 --> Total execution time: 0.0204
ERROR - 2023-09-25 06:04:05 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-25 06:04:05 --> Config Class Initialized
INFO - 2023-09-25 06:04:05 --> Hooks Class Initialized
DEBUG - 2023-09-25 06:04:05 --> UTF-8 Support Enabled
INFO - 2023-09-25 06:04:05 --> Utf8 Class Initialized
INFO - 2023-09-25 06:04:05 --> URI Class Initialized
DEBUG - 2023-09-25 06:04:05 --> No URI present. Default controller set.
INFO - 2023-09-25 06:04:05 --> Router Class Initialized
INFO - 2023-09-25 06:04:05 --> Output Class Initialized
INFO - 2023-09-25 06:04:05 --> Security Class Initialized
DEBUG - 2023-09-25 06:04:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-25 06:04:05 --> Input Class Initialized
INFO - 2023-09-25 06:04:05 --> Language Class Initialized
INFO - 2023-09-25 06:04:05 --> Loader Class Initialized
INFO - 2023-09-25 06:04:05 --> Helper loaded: url_helper
INFO - 2023-09-25 06:04:05 --> Helper loaded: file_helper
INFO - 2023-09-25 06:04:05 --> Helper loaded: html_helper
INFO - 2023-09-25 06:04:05 --> Helper loaded: text_helper
INFO - 2023-09-25 06:04:05 --> Helper loaded: form_helper
INFO - 2023-09-25 06:04:05 --> Helper loaded: lang_helper
INFO - 2023-09-25 06:04:05 --> Helper loaded: security_helper
INFO - 2023-09-25 06:04:05 --> Helper loaded: cookie_helper
INFO - 2023-09-25 06:04:05 --> Database Driver Class Initialized
INFO - 2023-09-25 06:04:05 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-25 06:04:05 --> Parser Class Initialized
INFO - 2023-09-25 06:04:05 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-25 06:04:05 --> Pagination Class Initialized
INFO - 2023-09-25 06:04:05 --> Form Validation Class Initialized
INFO - 2023-09-25 06:04:05 --> Controller Class Initialized
INFO - 2023-09-25 06:04:05 --> Model Class Initialized
DEBUG - 2023-09-25 06:04:05 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-25 06:04:05 --> Model Class Initialized
DEBUG - 2023-09-25 06:04:05 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-25 06:04:05 --> Model Class Initialized
INFO - 2023-09-25 06:04:05 --> Model Class Initialized
INFO - 2023-09-25 06:04:05 --> Model Class Initialized
INFO - 2023-09-25 06:04:05 --> Model Class Initialized
DEBUG - 2023-09-25 06:04:05 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-09-25 06:04:05 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-25 06:04:05 --> Model Class Initialized
INFO - 2023-09-25 06:04:05 --> Model Class Initialized
INFO - 2023-09-25 06:04:05 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-09-25 06:04:05 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-09-25 06:04:05 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-09-25 06:04:05 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-09-25 06:04:05 --> Model Class Initialized
INFO - 2023-09-25 06:04:05 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-09-25 06:04:05 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-09-25 06:04:05 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-09-25 06:04:05 --> Final output sent to browser
DEBUG - 2023-09-25 06:04:05 --> Total execution time: 0.2987
ERROR - 2023-09-25 06:04:05 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-25 06:04:05 --> Config Class Initialized
INFO - 2023-09-25 06:04:05 --> Hooks Class Initialized
DEBUG - 2023-09-25 06:04:05 --> UTF-8 Support Enabled
INFO - 2023-09-25 06:04:05 --> Utf8 Class Initialized
INFO - 2023-09-25 06:04:05 --> URI Class Initialized
INFO - 2023-09-25 06:04:05 --> Router Class Initialized
INFO - 2023-09-25 06:04:05 --> Output Class Initialized
INFO - 2023-09-25 06:04:05 --> Security Class Initialized
DEBUG - 2023-09-25 06:04:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-25 06:04:05 --> Input Class Initialized
INFO - 2023-09-25 06:04:05 --> Language Class Initialized
INFO - 2023-09-25 06:04:05 --> Loader Class Initialized
INFO - 2023-09-25 06:04:05 --> Helper loaded: url_helper
INFO - 2023-09-25 06:04:05 --> Helper loaded: file_helper
INFO - 2023-09-25 06:04:05 --> Helper loaded: html_helper
INFO - 2023-09-25 06:04:05 --> Helper loaded: text_helper
INFO - 2023-09-25 06:04:05 --> Helper loaded: form_helper
INFO - 2023-09-25 06:04:05 --> Helper loaded: lang_helper
INFO - 2023-09-25 06:04:05 --> Helper loaded: security_helper
INFO - 2023-09-25 06:04:05 --> Helper loaded: cookie_helper
INFO - 2023-09-25 06:04:05 --> Database Driver Class Initialized
INFO - 2023-09-25 06:04:05 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-25 06:04:05 --> Parser Class Initialized
INFO - 2023-09-25 06:04:05 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-25 06:04:05 --> Pagination Class Initialized
INFO - 2023-09-25 06:04:05 --> Form Validation Class Initialized
INFO - 2023-09-25 06:04:05 --> Controller Class Initialized
DEBUG - 2023-09-25 06:04:05 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-09-25 06:04:05 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-25 06:04:05 --> Model Class Initialized
INFO - 2023-09-25 06:04:05 --> Final output sent to browser
DEBUG - 2023-09-25 06:04:05 --> Total execution time: 0.0131
ERROR - 2023-09-25 06:04:48 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-25 06:04:48 --> Config Class Initialized
INFO - 2023-09-25 06:04:48 --> Hooks Class Initialized
DEBUG - 2023-09-25 06:04:48 --> UTF-8 Support Enabled
INFO - 2023-09-25 06:04:48 --> Utf8 Class Initialized
INFO - 2023-09-25 06:04:48 --> URI Class Initialized
INFO - 2023-09-25 06:04:48 --> Router Class Initialized
INFO - 2023-09-25 06:04:48 --> Output Class Initialized
INFO - 2023-09-25 06:04:48 --> Security Class Initialized
DEBUG - 2023-09-25 06:04:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-25 06:04:48 --> Input Class Initialized
INFO - 2023-09-25 06:04:48 --> Language Class Initialized
INFO - 2023-09-25 06:04:48 --> Loader Class Initialized
INFO - 2023-09-25 06:04:48 --> Helper loaded: url_helper
INFO - 2023-09-25 06:04:48 --> Helper loaded: file_helper
INFO - 2023-09-25 06:04:48 --> Helper loaded: html_helper
INFO - 2023-09-25 06:04:48 --> Helper loaded: text_helper
INFO - 2023-09-25 06:04:48 --> Helper loaded: form_helper
INFO - 2023-09-25 06:04:48 --> Helper loaded: lang_helper
INFO - 2023-09-25 06:04:48 --> Helper loaded: security_helper
INFO - 2023-09-25 06:04:48 --> Helper loaded: cookie_helper
INFO - 2023-09-25 06:04:48 --> Database Driver Class Initialized
INFO - 2023-09-25 06:04:48 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-25 06:04:48 --> Parser Class Initialized
INFO - 2023-09-25 06:04:48 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-25 06:04:48 --> Pagination Class Initialized
INFO - 2023-09-25 06:04:48 --> Form Validation Class Initialized
INFO - 2023-09-25 06:04:48 --> Controller Class Initialized
INFO - 2023-09-25 06:04:48 --> Model Class Initialized
DEBUG - 2023-09-25 06:04:48 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-09-25 06:04:48 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-25 06:04:48 --> Model Class Initialized
DEBUG - 2023-09-25 06:04:48 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-25 06:04:48 --> Model Class Initialized
INFO - 2023-09-25 06:04:49 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice.php
DEBUG - 2023-09-25 06:04:49 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-09-25 06:04:49 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-09-25 06:04:49 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-09-25 06:04:49 --> Model Class Initialized
INFO - 2023-09-25 06:04:49 --> Model Class Initialized
INFO - 2023-09-25 06:04:49 --> Model Class Initialized
INFO - 2023-09-25 06:04:49 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-09-25 06:04:49 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-09-25 06:04:49 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-09-25 06:04:49 --> Final output sent to browser
DEBUG - 2023-09-25 06:04:49 --> Total execution time: 0.1600
ERROR - 2023-09-25 06:04:49 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-25 06:04:49 --> Config Class Initialized
INFO - 2023-09-25 06:04:49 --> Hooks Class Initialized
DEBUG - 2023-09-25 06:04:49 --> UTF-8 Support Enabled
INFO - 2023-09-25 06:04:49 --> Utf8 Class Initialized
INFO - 2023-09-25 06:04:49 --> URI Class Initialized
INFO - 2023-09-25 06:04:49 --> Router Class Initialized
INFO - 2023-09-25 06:04:49 --> Output Class Initialized
INFO - 2023-09-25 06:04:49 --> Security Class Initialized
DEBUG - 2023-09-25 06:04:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-25 06:04:49 --> Input Class Initialized
INFO - 2023-09-25 06:04:49 --> Language Class Initialized
INFO - 2023-09-25 06:04:49 --> Loader Class Initialized
INFO - 2023-09-25 06:04:49 --> Helper loaded: url_helper
INFO - 2023-09-25 06:04:49 --> Helper loaded: file_helper
INFO - 2023-09-25 06:04:49 --> Helper loaded: html_helper
INFO - 2023-09-25 06:04:49 --> Helper loaded: text_helper
INFO - 2023-09-25 06:04:49 --> Helper loaded: form_helper
INFO - 2023-09-25 06:04:49 --> Helper loaded: lang_helper
INFO - 2023-09-25 06:04:49 --> Helper loaded: security_helper
INFO - 2023-09-25 06:04:49 --> Helper loaded: cookie_helper
INFO - 2023-09-25 06:04:49 --> Database Driver Class Initialized
INFO - 2023-09-25 06:04:49 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-25 06:04:49 --> Parser Class Initialized
INFO - 2023-09-25 06:04:49 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-25 06:04:49 --> Pagination Class Initialized
INFO - 2023-09-25 06:04:49 --> Form Validation Class Initialized
INFO - 2023-09-25 06:04:49 --> Controller Class Initialized
INFO - 2023-09-25 06:04:49 --> Model Class Initialized
DEBUG - 2023-09-25 06:04:49 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-09-25 06:04:49 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-25 06:04:49 --> Model Class Initialized
DEBUG - 2023-09-25 06:04:49 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-25 06:04:49 --> Model Class Initialized
INFO - 2023-09-25 06:04:49 --> Final output sent to browser
DEBUG - 2023-09-25 06:04:49 --> Total execution time: 0.0532
ERROR - 2023-09-25 06:04:54 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-25 06:04:54 --> Config Class Initialized
INFO - 2023-09-25 06:04:54 --> Hooks Class Initialized
DEBUG - 2023-09-25 06:04:54 --> UTF-8 Support Enabled
INFO - 2023-09-25 06:04:54 --> Utf8 Class Initialized
INFO - 2023-09-25 06:04:54 --> URI Class Initialized
INFO - 2023-09-25 06:04:54 --> Router Class Initialized
INFO - 2023-09-25 06:04:54 --> Output Class Initialized
INFO - 2023-09-25 06:04:54 --> Security Class Initialized
DEBUG - 2023-09-25 06:04:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-25 06:04:54 --> Input Class Initialized
INFO - 2023-09-25 06:04:54 --> Language Class Initialized
INFO - 2023-09-25 06:04:54 --> Loader Class Initialized
INFO - 2023-09-25 06:04:54 --> Helper loaded: url_helper
INFO - 2023-09-25 06:04:54 --> Helper loaded: file_helper
INFO - 2023-09-25 06:04:54 --> Helper loaded: html_helper
INFO - 2023-09-25 06:04:54 --> Helper loaded: text_helper
INFO - 2023-09-25 06:04:54 --> Helper loaded: form_helper
INFO - 2023-09-25 06:04:54 --> Helper loaded: lang_helper
INFO - 2023-09-25 06:04:54 --> Helper loaded: security_helper
INFO - 2023-09-25 06:04:54 --> Helper loaded: cookie_helper
INFO - 2023-09-25 06:04:54 --> Database Driver Class Initialized
INFO - 2023-09-25 06:04:54 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-25 06:04:54 --> Parser Class Initialized
INFO - 2023-09-25 06:04:54 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-25 06:04:54 --> Pagination Class Initialized
INFO - 2023-09-25 06:04:54 --> Form Validation Class Initialized
INFO - 2023-09-25 06:04:54 --> Controller Class Initialized
INFO - 2023-09-25 06:04:54 --> Model Class Initialized
DEBUG - 2023-09-25 06:04:54 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-09-25 06:04:54 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-25 06:04:54 --> Model Class Initialized
DEBUG - 2023-09-25 06:04:54 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-25 06:04:54 --> Model Class Initialized
INFO - 2023-09-25 06:04:55 --> Final output sent to browser
DEBUG - 2023-09-25 06:04:55 --> Total execution time: 0.8305
ERROR - 2023-09-25 06:05:07 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-25 06:05:07 --> Config Class Initialized
INFO - 2023-09-25 06:05:07 --> Hooks Class Initialized
DEBUG - 2023-09-25 06:05:07 --> UTF-8 Support Enabled
INFO - 2023-09-25 06:05:07 --> Utf8 Class Initialized
INFO - 2023-09-25 06:05:07 --> URI Class Initialized
DEBUG - 2023-09-25 06:05:07 --> No URI present. Default controller set.
INFO - 2023-09-25 06:05:07 --> Router Class Initialized
INFO - 2023-09-25 06:05:07 --> Output Class Initialized
INFO - 2023-09-25 06:05:07 --> Security Class Initialized
DEBUG - 2023-09-25 06:05:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-25 06:05:07 --> Input Class Initialized
INFO - 2023-09-25 06:05:07 --> Language Class Initialized
INFO - 2023-09-25 06:05:07 --> Loader Class Initialized
INFO - 2023-09-25 06:05:07 --> Helper loaded: url_helper
INFO - 2023-09-25 06:05:07 --> Helper loaded: file_helper
INFO - 2023-09-25 06:05:07 --> Helper loaded: html_helper
INFO - 2023-09-25 06:05:07 --> Helper loaded: text_helper
INFO - 2023-09-25 06:05:07 --> Helper loaded: form_helper
INFO - 2023-09-25 06:05:07 --> Helper loaded: lang_helper
INFO - 2023-09-25 06:05:07 --> Helper loaded: security_helper
INFO - 2023-09-25 06:05:07 --> Helper loaded: cookie_helper
INFO - 2023-09-25 06:05:07 --> Database Driver Class Initialized
INFO - 2023-09-25 06:05:07 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-25 06:05:07 --> Parser Class Initialized
INFO - 2023-09-25 06:05:07 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-25 06:05:07 --> Pagination Class Initialized
INFO - 2023-09-25 06:05:07 --> Form Validation Class Initialized
INFO - 2023-09-25 06:05:07 --> Controller Class Initialized
INFO - 2023-09-25 06:05:07 --> Model Class Initialized
DEBUG - 2023-09-25 06:05:07 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-25 06:05:07 --> Model Class Initialized
DEBUG - 2023-09-25 06:05:07 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-25 06:05:07 --> Model Class Initialized
INFO - 2023-09-25 06:05:07 --> Model Class Initialized
INFO - 2023-09-25 06:05:07 --> Model Class Initialized
INFO - 2023-09-25 06:05:07 --> Model Class Initialized
DEBUG - 2023-09-25 06:05:07 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-09-25 06:05:07 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-25 06:05:07 --> Model Class Initialized
INFO - 2023-09-25 06:05:07 --> Model Class Initialized
INFO - 2023-09-25 06:05:07 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-09-25 06:05:07 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-09-25 06:05:07 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-09-25 06:05:07 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-09-25 06:05:07 --> Model Class Initialized
INFO - 2023-09-25 06:05:08 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-09-25 06:05:08 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-09-25 06:05:08 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-09-25 06:05:08 --> Final output sent to browser
DEBUG - 2023-09-25 06:05:08 --> Total execution time: 0.2221
ERROR - 2023-09-25 06:09:52 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-25 06:09:52 --> Config Class Initialized
INFO - 2023-09-25 06:09:52 --> Hooks Class Initialized
DEBUG - 2023-09-25 06:09:52 --> UTF-8 Support Enabled
INFO - 2023-09-25 06:09:52 --> Utf8 Class Initialized
INFO - 2023-09-25 06:09:52 --> URI Class Initialized
DEBUG - 2023-09-25 06:09:52 --> No URI present. Default controller set.
INFO - 2023-09-25 06:09:52 --> Router Class Initialized
INFO - 2023-09-25 06:09:52 --> Output Class Initialized
INFO - 2023-09-25 06:09:52 --> Security Class Initialized
DEBUG - 2023-09-25 06:09:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-25 06:09:52 --> Input Class Initialized
INFO - 2023-09-25 06:09:52 --> Language Class Initialized
INFO - 2023-09-25 06:09:52 --> Loader Class Initialized
INFO - 2023-09-25 06:09:52 --> Helper loaded: url_helper
INFO - 2023-09-25 06:09:52 --> Helper loaded: file_helper
INFO - 2023-09-25 06:09:52 --> Helper loaded: html_helper
INFO - 2023-09-25 06:09:52 --> Helper loaded: text_helper
INFO - 2023-09-25 06:09:52 --> Helper loaded: form_helper
INFO - 2023-09-25 06:09:52 --> Helper loaded: lang_helper
INFO - 2023-09-25 06:09:52 --> Helper loaded: security_helper
INFO - 2023-09-25 06:09:52 --> Helper loaded: cookie_helper
INFO - 2023-09-25 06:09:52 --> Database Driver Class Initialized
INFO - 2023-09-25 06:09:52 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-25 06:09:52 --> Parser Class Initialized
INFO - 2023-09-25 06:09:52 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-25 06:09:52 --> Pagination Class Initialized
INFO - 2023-09-25 06:09:52 --> Form Validation Class Initialized
INFO - 2023-09-25 06:09:52 --> Controller Class Initialized
INFO - 2023-09-25 06:09:52 --> Model Class Initialized
DEBUG - 2023-09-25 06:09:52 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-25 06:09:52 --> Model Class Initialized
DEBUG - 2023-09-25 06:09:52 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-25 06:09:52 --> Model Class Initialized
INFO - 2023-09-25 06:09:52 --> Model Class Initialized
INFO - 2023-09-25 06:09:52 --> Model Class Initialized
INFO - 2023-09-25 06:09:52 --> Model Class Initialized
DEBUG - 2023-09-25 06:09:52 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-09-25 06:09:52 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-25 06:09:52 --> Model Class Initialized
INFO - 2023-09-25 06:09:52 --> Model Class Initialized
INFO - 2023-09-25 06:09:52 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-09-25 06:09:52 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-09-25 06:09:52 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-09-25 06:09:52 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-09-25 06:09:52 --> Model Class Initialized
INFO - 2023-09-25 06:09:52 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-09-25 06:09:52 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-09-25 06:09:52 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-09-25 06:09:52 --> Final output sent to browser
DEBUG - 2023-09-25 06:09:52 --> Total execution time: 0.2030
ERROR - 2023-09-25 06:11:36 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-25 06:11:36 --> Config Class Initialized
INFO - 2023-09-25 06:11:36 --> Hooks Class Initialized
DEBUG - 2023-09-25 06:11:36 --> UTF-8 Support Enabled
INFO - 2023-09-25 06:11:36 --> Utf8 Class Initialized
INFO - 2023-09-25 06:11:36 --> URI Class Initialized
INFO - 2023-09-25 06:11:36 --> Router Class Initialized
INFO - 2023-09-25 06:11:36 --> Output Class Initialized
INFO - 2023-09-25 06:11:36 --> Security Class Initialized
DEBUG - 2023-09-25 06:11:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-25 06:11:36 --> Input Class Initialized
INFO - 2023-09-25 06:11:36 --> Language Class Initialized
INFO - 2023-09-25 06:11:36 --> Loader Class Initialized
INFO - 2023-09-25 06:11:36 --> Helper loaded: url_helper
INFO - 2023-09-25 06:11:36 --> Helper loaded: file_helper
INFO - 2023-09-25 06:11:36 --> Helper loaded: html_helper
INFO - 2023-09-25 06:11:36 --> Helper loaded: text_helper
INFO - 2023-09-25 06:11:36 --> Helper loaded: form_helper
INFO - 2023-09-25 06:11:36 --> Helper loaded: lang_helper
INFO - 2023-09-25 06:11:36 --> Helper loaded: security_helper
INFO - 2023-09-25 06:11:36 --> Helper loaded: cookie_helper
INFO - 2023-09-25 06:11:36 --> Database Driver Class Initialized
INFO - 2023-09-25 06:11:36 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-25 06:11:36 --> Parser Class Initialized
INFO - 2023-09-25 06:11:36 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-25 06:11:36 --> Pagination Class Initialized
INFO - 2023-09-25 06:11:36 --> Form Validation Class Initialized
INFO - 2023-09-25 06:11:36 --> Controller Class Initialized
INFO - 2023-09-25 06:11:36 --> Model Class Initialized
DEBUG - 2023-09-25 06:11:36 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-09-25 06:11:36 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-25 06:11:36 --> Model Class Initialized
DEBUG - 2023-09-25 06:11:36 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-25 06:11:36 --> Model Class Initialized
INFO - 2023-09-25 06:11:36 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice.php
DEBUG - 2023-09-25 06:11:36 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-09-25 06:11:36 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-09-25 06:11:36 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-09-25 06:11:36 --> Model Class Initialized
INFO - 2023-09-25 06:11:36 --> Model Class Initialized
INFO - 2023-09-25 06:11:36 --> Model Class Initialized
INFO - 2023-09-25 06:11:36 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-09-25 06:11:36 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-09-25 06:11:36 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-09-25 06:11:36 --> Final output sent to browser
DEBUG - 2023-09-25 06:11:36 --> Total execution time: 0.1603
ERROR - 2023-09-25 06:11:37 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-25 06:11:37 --> Config Class Initialized
INFO - 2023-09-25 06:11:37 --> Hooks Class Initialized
DEBUG - 2023-09-25 06:11:37 --> UTF-8 Support Enabled
INFO - 2023-09-25 06:11:37 --> Utf8 Class Initialized
INFO - 2023-09-25 06:11:37 --> URI Class Initialized
INFO - 2023-09-25 06:11:37 --> Router Class Initialized
INFO - 2023-09-25 06:11:37 --> Output Class Initialized
INFO - 2023-09-25 06:11:37 --> Security Class Initialized
DEBUG - 2023-09-25 06:11:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-25 06:11:37 --> Input Class Initialized
INFO - 2023-09-25 06:11:37 --> Language Class Initialized
INFO - 2023-09-25 06:11:37 --> Loader Class Initialized
INFO - 2023-09-25 06:11:37 --> Helper loaded: url_helper
INFO - 2023-09-25 06:11:37 --> Helper loaded: file_helper
INFO - 2023-09-25 06:11:37 --> Helper loaded: html_helper
INFO - 2023-09-25 06:11:37 --> Helper loaded: text_helper
INFO - 2023-09-25 06:11:37 --> Helper loaded: form_helper
INFO - 2023-09-25 06:11:37 --> Helper loaded: lang_helper
INFO - 2023-09-25 06:11:37 --> Helper loaded: security_helper
INFO - 2023-09-25 06:11:37 --> Helper loaded: cookie_helper
INFO - 2023-09-25 06:11:37 --> Database Driver Class Initialized
INFO - 2023-09-25 06:11:37 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-25 06:11:37 --> Parser Class Initialized
INFO - 2023-09-25 06:11:37 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-25 06:11:37 --> Pagination Class Initialized
INFO - 2023-09-25 06:11:37 --> Form Validation Class Initialized
INFO - 2023-09-25 06:11:37 --> Controller Class Initialized
INFO - 2023-09-25 06:11:37 --> Model Class Initialized
DEBUG - 2023-09-25 06:11:37 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-09-25 06:11:37 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-25 06:11:37 --> Model Class Initialized
DEBUG - 2023-09-25 06:11:37 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-25 06:11:37 --> Model Class Initialized
INFO - 2023-09-25 06:11:37 --> Final output sent to browser
DEBUG - 2023-09-25 06:11:37 --> Total execution time: 0.0541
ERROR - 2023-09-25 06:12:36 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-25 06:12:36 --> Config Class Initialized
INFO - 2023-09-25 06:12:36 --> Hooks Class Initialized
DEBUG - 2023-09-25 06:12:36 --> UTF-8 Support Enabled
INFO - 2023-09-25 06:12:36 --> Utf8 Class Initialized
INFO - 2023-09-25 06:12:36 --> URI Class Initialized
DEBUG - 2023-09-25 06:12:36 --> No URI present. Default controller set.
INFO - 2023-09-25 06:12:36 --> Router Class Initialized
INFO - 2023-09-25 06:12:36 --> Output Class Initialized
INFO - 2023-09-25 06:12:36 --> Security Class Initialized
DEBUG - 2023-09-25 06:12:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-25 06:12:36 --> Input Class Initialized
INFO - 2023-09-25 06:12:36 --> Language Class Initialized
INFO - 2023-09-25 06:12:36 --> Loader Class Initialized
INFO - 2023-09-25 06:12:36 --> Helper loaded: url_helper
INFO - 2023-09-25 06:12:36 --> Helper loaded: file_helper
INFO - 2023-09-25 06:12:36 --> Helper loaded: html_helper
INFO - 2023-09-25 06:12:36 --> Helper loaded: text_helper
INFO - 2023-09-25 06:12:36 --> Helper loaded: form_helper
INFO - 2023-09-25 06:12:36 --> Helper loaded: lang_helper
INFO - 2023-09-25 06:12:36 --> Helper loaded: security_helper
INFO - 2023-09-25 06:12:36 --> Helper loaded: cookie_helper
INFO - 2023-09-25 06:12:36 --> Database Driver Class Initialized
INFO - 2023-09-25 06:12:36 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-25 06:12:36 --> Parser Class Initialized
INFO - 2023-09-25 06:12:36 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-25 06:12:36 --> Pagination Class Initialized
INFO - 2023-09-25 06:12:36 --> Form Validation Class Initialized
INFO - 2023-09-25 06:12:36 --> Controller Class Initialized
INFO - 2023-09-25 06:12:36 --> Model Class Initialized
DEBUG - 2023-09-25 06:12:36 --> Session class already loaded. Second attempt ignored.
ERROR - 2023-09-25 06:12:36 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-25 06:12:36 --> Config Class Initialized
INFO - 2023-09-25 06:12:36 --> Hooks Class Initialized
DEBUG - 2023-09-25 06:12:36 --> UTF-8 Support Enabled
INFO - 2023-09-25 06:12:36 --> Utf8 Class Initialized
INFO - 2023-09-25 06:12:36 --> URI Class Initialized
INFO - 2023-09-25 06:12:36 --> Router Class Initialized
INFO - 2023-09-25 06:12:36 --> Output Class Initialized
INFO - 2023-09-25 06:12:36 --> Security Class Initialized
DEBUG - 2023-09-25 06:12:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-25 06:12:36 --> Input Class Initialized
INFO - 2023-09-25 06:12:36 --> Language Class Initialized
INFO - 2023-09-25 06:12:36 --> Loader Class Initialized
INFO - 2023-09-25 06:12:36 --> Helper loaded: url_helper
INFO - 2023-09-25 06:12:36 --> Helper loaded: file_helper
INFO - 2023-09-25 06:12:36 --> Helper loaded: html_helper
INFO - 2023-09-25 06:12:36 --> Helper loaded: text_helper
INFO - 2023-09-25 06:12:36 --> Helper loaded: form_helper
INFO - 2023-09-25 06:12:36 --> Helper loaded: lang_helper
INFO - 2023-09-25 06:12:36 --> Helper loaded: security_helper
INFO - 2023-09-25 06:12:36 --> Helper loaded: cookie_helper
INFO - 2023-09-25 06:12:36 --> Database Driver Class Initialized
INFO - 2023-09-25 06:12:36 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-25 06:12:36 --> Parser Class Initialized
INFO - 2023-09-25 06:12:36 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-25 06:12:36 --> Pagination Class Initialized
INFO - 2023-09-25 06:12:36 --> Form Validation Class Initialized
INFO - 2023-09-25 06:12:36 --> Controller Class Initialized
INFO - 2023-09-25 06:12:36 --> Model Class Initialized
DEBUG - 2023-09-25 06:12:36 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-25 06:12:36 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2023-09-25 06:12:36 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-09-25 06:12:36 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-09-25 06:12:36 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-09-25 06:12:36 --> Model Class Initialized
INFO - 2023-09-25 06:12:36 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-09-25 06:12:36 --> Final output sent to browser
DEBUG - 2023-09-25 06:12:36 --> Total execution time: 0.0336
ERROR - 2023-09-25 06:12:40 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-25 06:12:40 --> Config Class Initialized
INFO - 2023-09-25 06:12:40 --> Hooks Class Initialized
DEBUG - 2023-09-25 06:12:40 --> UTF-8 Support Enabled
INFO - 2023-09-25 06:12:40 --> Utf8 Class Initialized
INFO - 2023-09-25 06:12:40 --> URI Class Initialized
INFO - 2023-09-25 06:12:40 --> Router Class Initialized
INFO - 2023-09-25 06:12:40 --> Output Class Initialized
INFO - 2023-09-25 06:12:40 --> Security Class Initialized
DEBUG - 2023-09-25 06:12:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-25 06:12:40 --> Input Class Initialized
INFO - 2023-09-25 06:12:40 --> Language Class Initialized
INFO - 2023-09-25 06:12:40 --> Loader Class Initialized
INFO - 2023-09-25 06:12:40 --> Helper loaded: url_helper
INFO - 2023-09-25 06:12:40 --> Helper loaded: file_helper
INFO - 2023-09-25 06:12:40 --> Helper loaded: html_helper
INFO - 2023-09-25 06:12:40 --> Helper loaded: text_helper
INFO - 2023-09-25 06:12:40 --> Helper loaded: form_helper
INFO - 2023-09-25 06:12:40 --> Helper loaded: lang_helper
INFO - 2023-09-25 06:12:40 --> Helper loaded: security_helper
INFO - 2023-09-25 06:12:40 --> Helper loaded: cookie_helper
INFO - 2023-09-25 06:12:40 --> Database Driver Class Initialized
INFO - 2023-09-25 06:12:40 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-25 06:12:40 --> Parser Class Initialized
INFO - 2023-09-25 06:12:40 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-25 06:12:40 --> Pagination Class Initialized
INFO - 2023-09-25 06:12:40 --> Form Validation Class Initialized
INFO - 2023-09-25 06:12:40 --> Controller Class Initialized
INFO - 2023-09-25 06:12:40 --> Model Class Initialized
DEBUG - 2023-09-25 06:12:40 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-25 06:12:40 --> Model Class Initialized
INFO - 2023-09-25 06:12:40 --> Final output sent to browser
DEBUG - 2023-09-25 06:12:40 --> Total execution time: 0.0171
ERROR - 2023-09-25 06:12:40 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-25 06:12:40 --> Config Class Initialized
INFO - 2023-09-25 06:12:40 --> Hooks Class Initialized
DEBUG - 2023-09-25 06:12:40 --> UTF-8 Support Enabled
INFO - 2023-09-25 06:12:40 --> Utf8 Class Initialized
INFO - 2023-09-25 06:12:40 --> URI Class Initialized
DEBUG - 2023-09-25 06:12:40 --> No URI present. Default controller set.
INFO - 2023-09-25 06:12:40 --> Router Class Initialized
INFO - 2023-09-25 06:12:40 --> Output Class Initialized
INFO - 2023-09-25 06:12:40 --> Security Class Initialized
DEBUG - 2023-09-25 06:12:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-25 06:12:40 --> Input Class Initialized
INFO - 2023-09-25 06:12:40 --> Language Class Initialized
INFO - 2023-09-25 06:12:40 --> Loader Class Initialized
INFO - 2023-09-25 06:12:40 --> Helper loaded: url_helper
INFO - 2023-09-25 06:12:40 --> Helper loaded: file_helper
INFO - 2023-09-25 06:12:40 --> Helper loaded: html_helper
INFO - 2023-09-25 06:12:40 --> Helper loaded: text_helper
INFO - 2023-09-25 06:12:40 --> Helper loaded: form_helper
INFO - 2023-09-25 06:12:40 --> Helper loaded: lang_helper
INFO - 2023-09-25 06:12:40 --> Helper loaded: security_helper
INFO - 2023-09-25 06:12:40 --> Helper loaded: cookie_helper
INFO - 2023-09-25 06:12:40 --> Database Driver Class Initialized
INFO - 2023-09-25 06:12:40 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-25 06:12:40 --> Parser Class Initialized
INFO - 2023-09-25 06:12:40 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-25 06:12:40 --> Pagination Class Initialized
INFO - 2023-09-25 06:12:40 --> Form Validation Class Initialized
INFO - 2023-09-25 06:12:40 --> Controller Class Initialized
INFO - 2023-09-25 06:12:40 --> Model Class Initialized
DEBUG - 2023-09-25 06:12:40 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-25 06:12:40 --> Model Class Initialized
DEBUG - 2023-09-25 06:12:40 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-25 06:12:40 --> Model Class Initialized
INFO - 2023-09-25 06:12:40 --> Model Class Initialized
INFO - 2023-09-25 06:12:40 --> Model Class Initialized
INFO - 2023-09-25 06:12:40 --> Model Class Initialized
DEBUG - 2023-09-25 06:12:40 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-09-25 06:12:40 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-25 06:12:40 --> Model Class Initialized
INFO - 2023-09-25 06:12:40 --> Model Class Initialized
INFO - 2023-09-25 06:12:40 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-09-25 06:12:40 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-09-25 06:12:40 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-09-25 06:12:40 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-09-25 06:12:40 --> Model Class Initialized
INFO - 2023-09-25 06:12:41 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-09-25 06:12:41 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-09-25 06:12:41 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-09-25 06:12:41 --> Final output sent to browser
DEBUG - 2023-09-25 06:12:41 --> Total execution time: 0.1009
ERROR - 2023-09-25 06:12:46 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-25 06:12:46 --> Config Class Initialized
INFO - 2023-09-25 06:12:46 --> Hooks Class Initialized
DEBUG - 2023-09-25 06:12:46 --> UTF-8 Support Enabled
INFO - 2023-09-25 06:12:46 --> Utf8 Class Initialized
INFO - 2023-09-25 06:12:46 --> URI Class Initialized
INFO - 2023-09-25 06:12:46 --> Router Class Initialized
INFO - 2023-09-25 06:12:46 --> Output Class Initialized
INFO - 2023-09-25 06:12:46 --> Security Class Initialized
DEBUG - 2023-09-25 06:12:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-25 06:12:46 --> Input Class Initialized
INFO - 2023-09-25 06:12:46 --> Language Class Initialized
INFO - 2023-09-25 06:12:46 --> Loader Class Initialized
INFO - 2023-09-25 06:12:46 --> Helper loaded: url_helper
INFO - 2023-09-25 06:12:46 --> Helper loaded: file_helper
INFO - 2023-09-25 06:12:46 --> Helper loaded: html_helper
INFO - 2023-09-25 06:12:46 --> Helper loaded: text_helper
INFO - 2023-09-25 06:12:46 --> Helper loaded: form_helper
INFO - 2023-09-25 06:12:46 --> Helper loaded: lang_helper
INFO - 2023-09-25 06:12:46 --> Helper loaded: security_helper
INFO - 2023-09-25 06:12:46 --> Helper loaded: cookie_helper
INFO - 2023-09-25 06:12:46 --> Database Driver Class Initialized
INFO - 2023-09-25 06:12:46 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-25 06:12:46 --> Parser Class Initialized
INFO - 2023-09-25 06:12:46 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-25 06:12:46 --> Pagination Class Initialized
INFO - 2023-09-25 06:12:46 --> Form Validation Class Initialized
INFO - 2023-09-25 06:12:46 --> Controller Class Initialized
INFO - 2023-09-25 06:12:46 --> Model Class Initialized
DEBUG - 2023-09-25 06:12:46 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-09-25 06:12:46 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-25 06:12:46 --> Model Class Initialized
INFO - 2023-09-25 06:12:46 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/stockrequest/inventory.php
DEBUG - 2023-09-25 06:12:46 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-09-25 06:12:46 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-09-25 06:12:46 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-09-25 06:12:46 --> Model Class Initialized
INFO - 2023-09-25 06:12:46 --> Model Class Initialized
INFO - 2023-09-25 06:12:46 --> Model Class Initialized
INFO - 2023-09-25 06:12:46 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-09-25 06:12:46 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-09-25 06:12:46 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-09-25 06:12:46 --> Final output sent to browser
DEBUG - 2023-09-25 06:12:46 --> Total execution time: 0.0750
ERROR - 2023-09-25 06:12:46 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-25 06:12:46 --> Config Class Initialized
INFO - 2023-09-25 06:12:46 --> Hooks Class Initialized
DEBUG - 2023-09-25 06:12:46 --> UTF-8 Support Enabled
INFO - 2023-09-25 06:12:46 --> Utf8 Class Initialized
INFO - 2023-09-25 06:12:46 --> URI Class Initialized
INFO - 2023-09-25 06:12:46 --> Router Class Initialized
INFO - 2023-09-25 06:12:46 --> Output Class Initialized
INFO - 2023-09-25 06:12:46 --> Security Class Initialized
DEBUG - 2023-09-25 06:12:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-25 06:12:46 --> Input Class Initialized
INFO - 2023-09-25 06:12:46 --> Language Class Initialized
INFO - 2023-09-25 06:12:46 --> Loader Class Initialized
INFO - 2023-09-25 06:12:46 --> Helper loaded: url_helper
INFO - 2023-09-25 06:12:46 --> Helper loaded: file_helper
INFO - 2023-09-25 06:12:46 --> Helper loaded: html_helper
INFO - 2023-09-25 06:12:46 --> Helper loaded: text_helper
INFO - 2023-09-25 06:12:46 --> Helper loaded: form_helper
INFO - 2023-09-25 06:12:46 --> Helper loaded: lang_helper
INFO - 2023-09-25 06:12:46 --> Helper loaded: security_helper
INFO - 2023-09-25 06:12:46 --> Helper loaded: cookie_helper
INFO - 2023-09-25 06:12:46 --> Database Driver Class Initialized
INFO - 2023-09-25 06:12:46 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-25 06:12:46 --> Parser Class Initialized
INFO - 2023-09-25 06:12:46 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-25 06:12:46 --> Pagination Class Initialized
INFO - 2023-09-25 06:12:46 --> Form Validation Class Initialized
INFO - 2023-09-25 06:12:46 --> Controller Class Initialized
INFO - 2023-09-25 06:12:46 --> Model Class Initialized
DEBUG - 2023-09-25 06:12:46 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-09-25 06:12:46 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-25 06:12:46 --> Model Class Initialized
INFO - 2023-09-25 06:12:46 --> Final output sent to browser
DEBUG - 2023-09-25 06:12:46 --> Total execution time: 0.0350
ERROR - 2023-09-25 06:12:53 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-25 06:12:53 --> Config Class Initialized
INFO - 2023-09-25 06:12:53 --> Hooks Class Initialized
DEBUG - 2023-09-25 06:12:53 --> UTF-8 Support Enabled
INFO - 2023-09-25 06:12:53 --> Utf8 Class Initialized
INFO - 2023-09-25 06:12:53 --> URI Class Initialized
INFO - 2023-09-25 06:12:53 --> Router Class Initialized
INFO - 2023-09-25 06:12:53 --> Output Class Initialized
INFO - 2023-09-25 06:12:53 --> Security Class Initialized
DEBUG - 2023-09-25 06:12:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-25 06:12:53 --> Input Class Initialized
INFO - 2023-09-25 06:12:53 --> Language Class Initialized
INFO - 2023-09-25 06:12:53 --> Loader Class Initialized
INFO - 2023-09-25 06:12:53 --> Helper loaded: url_helper
INFO - 2023-09-25 06:12:53 --> Helper loaded: file_helper
INFO - 2023-09-25 06:12:53 --> Helper loaded: html_helper
INFO - 2023-09-25 06:12:53 --> Helper loaded: text_helper
INFO - 2023-09-25 06:12:53 --> Helper loaded: form_helper
INFO - 2023-09-25 06:12:53 --> Helper loaded: lang_helper
INFO - 2023-09-25 06:12:53 --> Helper loaded: security_helper
INFO - 2023-09-25 06:12:53 --> Helper loaded: cookie_helper
INFO - 2023-09-25 06:12:53 --> Database Driver Class Initialized
INFO - 2023-09-25 06:12:53 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-25 06:12:53 --> Parser Class Initialized
INFO - 2023-09-25 06:12:53 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-25 06:12:53 --> Pagination Class Initialized
INFO - 2023-09-25 06:12:53 --> Form Validation Class Initialized
INFO - 2023-09-25 06:12:53 --> Controller Class Initialized
INFO - 2023-09-25 06:12:53 --> Model Class Initialized
DEBUG - 2023-09-25 06:12:53 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-09-25 06:12:53 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-25 06:12:53 --> Model Class Initialized
INFO - 2023-09-25 06:12:53 --> Final output sent to browser
DEBUG - 2023-09-25 06:12:53 --> Total execution time: 0.0300
ERROR - 2023-09-25 06:13:51 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-25 06:13:51 --> Config Class Initialized
INFO - 2023-09-25 06:13:51 --> Hooks Class Initialized
DEBUG - 2023-09-25 06:13:51 --> UTF-8 Support Enabled
INFO - 2023-09-25 06:13:51 --> Utf8 Class Initialized
INFO - 2023-09-25 06:13:51 --> URI Class Initialized
DEBUG - 2023-09-25 06:13:51 --> No URI present. Default controller set.
INFO - 2023-09-25 06:13:51 --> Router Class Initialized
INFO - 2023-09-25 06:13:51 --> Output Class Initialized
INFO - 2023-09-25 06:13:51 --> Security Class Initialized
DEBUG - 2023-09-25 06:13:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-25 06:13:51 --> Input Class Initialized
INFO - 2023-09-25 06:13:51 --> Language Class Initialized
INFO - 2023-09-25 06:13:51 --> Loader Class Initialized
INFO - 2023-09-25 06:13:51 --> Helper loaded: url_helper
INFO - 2023-09-25 06:13:51 --> Helper loaded: file_helper
INFO - 2023-09-25 06:13:51 --> Helper loaded: html_helper
INFO - 2023-09-25 06:13:51 --> Helper loaded: text_helper
INFO - 2023-09-25 06:13:51 --> Helper loaded: form_helper
INFO - 2023-09-25 06:13:51 --> Helper loaded: lang_helper
INFO - 2023-09-25 06:13:51 --> Helper loaded: security_helper
INFO - 2023-09-25 06:13:51 --> Helper loaded: cookie_helper
INFO - 2023-09-25 06:13:51 --> Database Driver Class Initialized
INFO - 2023-09-25 06:13:51 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-25 06:13:51 --> Parser Class Initialized
INFO - 2023-09-25 06:13:51 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-25 06:13:51 --> Pagination Class Initialized
INFO - 2023-09-25 06:13:51 --> Form Validation Class Initialized
INFO - 2023-09-25 06:13:51 --> Controller Class Initialized
INFO - 2023-09-25 06:13:51 --> Model Class Initialized
DEBUG - 2023-09-25 06:13:51 --> Session class already loaded. Second attempt ignored.
ERROR - 2023-09-25 06:13:52 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-25 06:13:52 --> Config Class Initialized
INFO - 2023-09-25 06:13:52 --> Hooks Class Initialized
DEBUG - 2023-09-25 06:13:52 --> UTF-8 Support Enabled
INFO - 2023-09-25 06:13:52 --> Utf8 Class Initialized
INFO - 2023-09-25 06:13:52 --> URI Class Initialized
INFO - 2023-09-25 06:13:52 --> Router Class Initialized
INFO - 2023-09-25 06:13:52 --> Output Class Initialized
INFO - 2023-09-25 06:13:52 --> Security Class Initialized
DEBUG - 2023-09-25 06:13:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-25 06:13:52 --> Input Class Initialized
INFO - 2023-09-25 06:13:52 --> Language Class Initialized
INFO - 2023-09-25 06:13:52 --> Loader Class Initialized
INFO - 2023-09-25 06:13:52 --> Helper loaded: url_helper
INFO - 2023-09-25 06:13:52 --> Helper loaded: file_helper
INFO - 2023-09-25 06:13:52 --> Helper loaded: html_helper
INFO - 2023-09-25 06:13:52 --> Helper loaded: text_helper
INFO - 2023-09-25 06:13:52 --> Helper loaded: form_helper
INFO - 2023-09-25 06:13:52 --> Helper loaded: lang_helper
INFO - 2023-09-25 06:13:52 --> Helper loaded: security_helper
INFO - 2023-09-25 06:13:52 --> Helper loaded: cookie_helper
INFO - 2023-09-25 06:13:52 --> Database Driver Class Initialized
INFO - 2023-09-25 06:13:52 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-25 06:13:52 --> Parser Class Initialized
INFO - 2023-09-25 06:13:52 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-25 06:13:52 --> Pagination Class Initialized
INFO - 2023-09-25 06:13:52 --> Form Validation Class Initialized
INFO - 2023-09-25 06:13:52 --> Controller Class Initialized
INFO - 2023-09-25 06:13:52 --> Model Class Initialized
DEBUG - 2023-09-25 06:13:52 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-25 06:13:52 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2023-09-25 06:13:52 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-09-25 06:13:52 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-09-25 06:13:52 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-09-25 06:13:52 --> Model Class Initialized
INFO - 2023-09-25 06:13:52 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-09-25 06:13:52 --> Final output sent to browser
DEBUG - 2023-09-25 06:13:52 --> Total execution time: 0.0317
ERROR - 2023-09-25 06:52:39 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-25 06:52:39 --> Config Class Initialized
INFO - 2023-09-25 06:52:39 --> Hooks Class Initialized
DEBUG - 2023-09-25 06:52:39 --> UTF-8 Support Enabled
INFO - 2023-09-25 06:52:39 --> Utf8 Class Initialized
INFO - 2023-09-25 06:52:39 --> URI Class Initialized
DEBUG - 2023-09-25 06:52:39 --> No URI present. Default controller set.
INFO - 2023-09-25 06:52:39 --> Router Class Initialized
INFO - 2023-09-25 06:52:39 --> Output Class Initialized
INFO - 2023-09-25 06:52:39 --> Security Class Initialized
DEBUG - 2023-09-25 06:52:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-25 06:52:39 --> Input Class Initialized
INFO - 2023-09-25 06:52:39 --> Language Class Initialized
INFO - 2023-09-25 06:52:39 --> Loader Class Initialized
INFO - 2023-09-25 06:52:39 --> Helper loaded: url_helper
INFO - 2023-09-25 06:52:39 --> Helper loaded: file_helper
INFO - 2023-09-25 06:52:39 --> Helper loaded: html_helper
INFO - 2023-09-25 06:52:39 --> Helper loaded: text_helper
INFO - 2023-09-25 06:52:39 --> Helper loaded: form_helper
INFO - 2023-09-25 06:52:39 --> Helper loaded: lang_helper
INFO - 2023-09-25 06:52:39 --> Helper loaded: security_helper
INFO - 2023-09-25 06:52:39 --> Helper loaded: cookie_helper
INFO - 2023-09-25 06:52:39 --> Database Driver Class Initialized
INFO - 2023-09-25 06:52:39 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-25 06:52:39 --> Parser Class Initialized
INFO - 2023-09-25 06:52:39 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-25 06:52:39 --> Pagination Class Initialized
INFO - 2023-09-25 06:52:39 --> Form Validation Class Initialized
INFO - 2023-09-25 06:52:39 --> Controller Class Initialized
INFO - 2023-09-25 06:52:39 --> Model Class Initialized
DEBUG - 2023-09-25 06:52:39 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-25 06:52:39 --> Model Class Initialized
DEBUG - 2023-09-25 06:52:39 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-25 06:52:39 --> Model Class Initialized
INFO - 2023-09-25 06:52:39 --> Model Class Initialized
INFO - 2023-09-25 06:52:39 --> Model Class Initialized
INFO - 2023-09-25 06:52:39 --> Model Class Initialized
DEBUG - 2023-09-25 06:52:39 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-09-25 06:52:39 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-25 06:52:39 --> Model Class Initialized
INFO - 2023-09-25 06:52:39 --> Model Class Initialized
INFO - 2023-09-25 06:52:40 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-09-25 06:52:40 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-09-25 06:52:40 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-09-25 06:52:40 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-09-25 06:52:40 --> Model Class Initialized
INFO - 2023-09-25 06:52:40 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-09-25 06:52:40 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-09-25 06:52:40 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-09-25 06:52:40 --> Final output sent to browser
DEBUG - 2023-09-25 06:52:40 --> Total execution time: 0.2384
ERROR - 2023-09-25 06:52:46 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-25 06:52:46 --> Config Class Initialized
INFO - 2023-09-25 06:52:46 --> Hooks Class Initialized
DEBUG - 2023-09-25 06:52:46 --> UTF-8 Support Enabled
INFO - 2023-09-25 06:52:46 --> Utf8 Class Initialized
INFO - 2023-09-25 06:52:46 --> URI Class Initialized
DEBUG - 2023-09-25 06:52:46 --> No URI present. Default controller set.
INFO - 2023-09-25 06:52:46 --> Router Class Initialized
INFO - 2023-09-25 06:52:46 --> Output Class Initialized
INFO - 2023-09-25 06:52:46 --> Security Class Initialized
DEBUG - 2023-09-25 06:52:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-25 06:52:46 --> Input Class Initialized
INFO - 2023-09-25 06:52:46 --> Language Class Initialized
INFO - 2023-09-25 06:52:46 --> Loader Class Initialized
INFO - 2023-09-25 06:52:46 --> Helper loaded: url_helper
INFO - 2023-09-25 06:52:46 --> Helper loaded: file_helper
INFO - 2023-09-25 06:52:46 --> Helper loaded: html_helper
INFO - 2023-09-25 06:52:46 --> Helper loaded: text_helper
INFO - 2023-09-25 06:52:46 --> Helper loaded: form_helper
INFO - 2023-09-25 06:52:46 --> Helper loaded: lang_helper
INFO - 2023-09-25 06:52:46 --> Helper loaded: security_helper
INFO - 2023-09-25 06:52:46 --> Helper loaded: cookie_helper
INFO - 2023-09-25 06:52:46 --> Database Driver Class Initialized
INFO - 2023-09-25 06:52:46 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-25 06:52:46 --> Parser Class Initialized
INFO - 2023-09-25 06:52:46 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-25 06:52:46 --> Pagination Class Initialized
INFO - 2023-09-25 06:52:46 --> Form Validation Class Initialized
INFO - 2023-09-25 06:52:46 --> Controller Class Initialized
INFO - 2023-09-25 06:52:46 --> Model Class Initialized
DEBUG - 2023-09-25 06:52:46 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-25 06:52:46 --> Model Class Initialized
DEBUG - 2023-09-25 06:52:46 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-25 06:52:46 --> Model Class Initialized
INFO - 2023-09-25 06:52:46 --> Model Class Initialized
INFO - 2023-09-25 06:52:46 --> Model Class Initialized
INFO - 2023-09-25 06:52:46 --> Model Class Initialized
DEBUG - 2023-09-25 06:52:46 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-09-25 06:52:46 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-25 06:52:46 --> Model Class Initialized
INFO - 2023-09-25 06:52:46 --> Model Class Initialized
INFO - 2023-09-25 06:52:46 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-09-25 06:52:46 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-09-25 06:52:46 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-09-25 06:52:46 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-09-25 06:52:46 --> Model Class Initialized
INFO - 2023-09-25 06:52:46 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-09-25 06:52:46 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-09-25 06:52:46 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-09-25 06:52:46 --> Final output sent to browser
DEBUG - 2023-09-25 06:52:46 --> Total execution time: 0.1095
ERROR - 2023-09-25 06:52:50 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-25 06:52:50 --> Config Class Initialized
INFO - 2023-09-25 06:52:50 --> Hooks Class Initialized
DEBUG - 2023-09-25 06:52:50 --> UTF-8 Support Enabled
INFO - 2023-09-25 06:52:50 --> Utf8 Class Initialized
INFO - 2023-09-25 06:52:50 --> URI Class Initialized
INFO - 2023-09-25 06:52:50 --> Router Class Initialized
INFO - 2023-09-25 06:52:50 --> Output Class Initialized
INFO - 2023-09-25 06:52:50 --> Security Class Initialized
DEBUG - 2023-09-25 06:52:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-25 06:52:50 --> Input Class Initialized
INFO - 2023-09-25 06:52:50 --> Language Class Initialized
INFO - 2023-09-25 06:52:50 --> Loader Class Initialized
INFO - 2023-09-25 06:52:50 --> Helper loaded: url_helper
INFO - 2023-09-25 06:52:50 --> Helper loaded: file_helper
INFO - 2023-09-25 06:52:50 --> Helper loaded: html_helper
INFO - 2023-09-25 06:52:50 --> Helper loaded: text_helper
INFO - 2023-09-25 06:52:50 --> Helper loaded: form_helper
INFO - 2023-09-25 06:52:50 --> Helper loaded: lang_helper
INFO - 2023-09-25 06:52:50 --> Helper loaded: security_helper
INFO - 2023-09-25 06:52:50 --> Helper loaded: cookie_helper
INFO - 2023-09-25 06:52:50 --> Database Driver Class Initialized
INFO - 2023-09-25 06:52:50 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-25 06:52:50 --> Parser Class Initialized
INFO - 2023-09-25 06:52:50 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-25 06:52:50 --> Pagination Class Initialized
INFO - 2023-09-25 06:52:50 --> Form Validation Class Initialized
INFO - 2023-09-25 06:52:50 --> Controller Class Initialized
INFO - 2023-09-25 06:52:50 --> Model Class Initialized
DEBUG - 2023-09-25 06:52:50 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-25 06:52:50 --> Final output sent to browser
DEBUG - 2023-09-25 06:52:50 --> Total execution time: 0.0129
ERROR - 2023-09-25 06:52:50 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-25 06:52:50 --> Config Class Initialized
INFO - 2023-09-25 06:52:50 --> Hooks Class Initialized
DEBUG - 2023-09-25 06:52:50 --> UTF-8 Support Enabled
INFO - 2023-09-25 06:52:50 --> Utf8 Class Initialized
INFO - 2023-09-25 06:52:50 --> URI Class Initialized
INFO - 2023-09-25 06:52:50 --> Router Class Initialized
INFO - 2023-09-25 06:52:50 --> Output Class Initialized
INFO - 2023-09-25 06:52:50 --> Security Class Initialized
DEBUG - 2023-09-25 06:52:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-25 06:52:50 --> Input Class Initialized
INFO - 2023-09-25 06:52:50 --> Language Class Initialized
INFO - 2023-09-25 06:52:50 --> Loader Class Initialized
INFO - 2023-09-25 06:52:50 --> Helper loaded: url_helper
INFO - 2023-09-25 06:52:50 --> Helper loaded: file_helper
INFO - 2023-09-25 06:52:50 --> Helper loaded: html_helper
INFO - 2023-09-25 06:52:50 --> Helper loaded: text_helper
INFO - 2023-09-25 06:52:50 --> Helper loaded: form_helper
INFO - 2023-09-25 06:52:50 --> Helper loaded: lang_helper
INFO - 2023-09-25 06:52:50 --> Helper loaded: security_helper
INFO - 2023-09-25 06:52:50 --> Helper loaded: cookie_helper
INFO - 2023-09-25 06:52:50 --> Database Driver Class Initialized
INFO - 2023-09-25 06:52:50 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-25 06:52:50 --> Parser Class Initialized
INFO - 2023-09-25 06:52:50 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-25 06:52:50 --> Pagination Class Initialized
INFO - 2023-09-25 06:52:50 --> Form Validation Class Initialized
INFO - 2023-09-25 06:52:50 --> Controller Class Initialized
INFO - 2023-09-25 06:52:50 --> Model Class Initialized
DEBUG - 2023-09-25 06:52:50 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-25 06:52:50 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2023-09-25 06:52:50 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-09-25 06:52:50 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-09-25 06:52:50 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-09-25 06:52:50 --> Model Class Initialized
INFO - 2023-09-25 06:52:50 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-09-25 06:52:50 --> Final output sent to browser
DEBUG - 2023-09-25 06:52:50 --> Total execution time: 0.0300
ERROR - 2023-09-25 06:52:56 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-25 06:52:56 --> Config Class Initialized
INFO - 2023-09-25 06:52:56 --> Hooks Class Initialized
DEBUG - 2023-09-25 06:52:56 --> UTF-8 Support Enabled
INFO - 2023-09-25 06:52:56 --> Utf8 Class Initialized
INFO - 2023-09-25 06:52:56 --> URI Class Initialized
INFO - 2023-09-25 06:52:56 --> Router Class Initialized
INFO - 2023-09-25 06:52:56 --> Output Class Initialized
INFO - 2023-09-25 06:52:56 --> Security Class Initialized
DEBUG - 2023-09-25 06:52:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-25 06:52:56 --> Input Class Initialized
INFO - 2023-09-25 06:52:56 --> Language Class Initialized
INFO - 2023-09-25 06:52:56 --> Loader Class Initialized
INFO - 2023-09-25 06:52:56 --> Helper loaded: url_helper
INFO - 2023-09-25 06:52:56 --> Helper loaded: file_helper
INFO - 2023-09-25 06:52:56 --> Helper loaded: html_helper
INFO - 2023-09-25 06:52:56 --> Helper loaded: text_helper
INFO - 2023-09-25 06:52:56 --> Helper loaded: form_helper
INFO - 2023-09-25 06:52:56 --> Helper loaded: lang_helper
INFO - 2023-09-25 06:52:56 --> Helper loaded: security_helper
INFO - 2023-09-25 06:52:56 --> Helper loaded: cookie_helper
INFO - 2023-09-25 06:52:56 --> Database Driver Class Initialized
INFO - 2023-09-25 06:52:56 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-25 06:52:56 --> Parser Class Initialized
INFO - 2023-09-25 06:52:56 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-25 06:52:56 --> Pagination Class Initialized
INFO - 2023-09-25 06:52:56 --> Form Validation Class Initialized
INFO - 2023-09-25 06:52:56 --> Controller Class Initialized
INFO - 2023-09-25 06:52:56 --> Model Class Initialized
DEBUG - 2023-09-25 06:52:56 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-25 06:52:56 --> Model Class Initialized
INFO - 2023-09-25 06:52:56 --> Final output sent to browser
DEBUG - 2023-09-25 06:52:56 --> Total execution time: 0.0167
ERROR - 2023-09-25 06:52:56 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-25 06:52:56 --> Config Class Initialized
INFO - 2023-09-25 06:52:56 --> Hooks Class Initialized
DEBUG - 2023-09-25 06:52:56 --> UTF-8 Support Enabled
INFO - 2023-09-25 06:52:56 --> Utf8 Class Initialized
INFO - 2023-09-25 06:52:56 --> URI Class Initialized
DEBUG - 2023-09-25 06:52:56 --> No URI present. Default controller set.
INFO - 2023-09-25 06:52:56 --> Router Class Initialized
INFO - 2023-09-25 06:52:56 --> Output Class Initialized
INFO - 2023-09-25 06:52:56 --> Security Class Initialized
DEBUG - 2023-09-25 06:52:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-25 06:52:56 --> Input Class Initialized
INFO - 2023-09-25 06:52:56 --> Language Class Initialized
INFO - 2023-09-25 06:52:56 --> Loader Class Initialized
INFO - 2023-09-25 06:52:56 --> Helper loaded: url_helper
INFO - 2023-09-25 06:52:56 --> Helper loaded: file_helper
INFO - 2023-09-25 06:52:56 --> Helper loaded: html_helper
INFO - 2023-09-25 06:52:56 --> Helper loaded: text_helper
INFO - 2023-09-25 06:52:56 --> Helper loaded: form_helper
INFO - 2023-09-25 06:52:56 --> Helper loaded: lang_helper
INFO - 2023-09-25 06:52:56 --> Helper loaded: security_helper
INFO - 2023-09-25 06:52:56 --> Helper loaded: cookie_helper
INFO - 2023-09-25 06:52:56 --> Database Driver Class Initialized
INFO - 2023-09-25 06:52:56 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-25 06:52:56 --> Parser Class Initialized
INFO - 2023-09-25 06:52:56 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-25 06:52:56 --> Pagination Class Initialized
INFO - 2023-09-25 06:52:56 --> Form Validation Class Initialized
INFO - 2023-09-25 06:52:56 --> Controller Class Initialized
INFO - 2023-09-25 06:52:56 --> Model Class Initialized
DEBUG - 2023-09-25 06:52:56 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-25 06:52:56 --> Model Class Initialized
DEBUG - 2023-09-25 06:52:56 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-25 06:52:56 --> Model Class Initialized
INFO - 2023-09-25 06:52:56 --> Model Class Initialized
INFO - 2023-09-25 06:52:56 --> Model Class Initialized
INFO - 2023-09-25 06:52:56 --> Model Class Initialized
DEBUG - 2023-09-25 06:52:56 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-09-25 06:52:56 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-25 06:52:56 --> Model Class Initialized
INFO - 2023-09-25 06:52:56 --> Model Class Initialized
INFO - 2023-09-25 06:52:56 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-09-25 06:52:56 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-09-25 06:52:56 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-09-25 06:52:56 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-09-25 06:52:56 --> Model Class Initialized
INFO - 2023-09-25 06:52:56 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-09-25 06:52:56 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-09-25 06:52:56 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-09-25 06:52:56 --> Final output sent to browser
DEBUG - 2023-09-25 06:52:56 --> Total execution time: 0.1033
ERROR - 2023-09-25 06:53:00 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-25 06:53:00 --> Config Class Initialized
INFO - 2023-09-25 06:53:00 --> Hooks Class Initialized
DEBUG - 2023-09-25 06:53:00 --> UTF-8 Support Enabled
INFO - 2023-09-25 06:53:00 --> Utf8 Class Initialized
INFO - 2023-09-25 06:53:00 --> URI Class Initialized
INFO - 2023-09-25 06:53:00 --> Router Class Initialized
INFO - 2023-09-25 06:53:00 --> Output Class Initialized
INFO - 2023-09-25 06:53:00 --> Security Class Initialized
DEBUG - 2023-09-25 06:53:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-25 06:53:00 --> Input Class Initialized
INFO - 2023-09-25 06:53:00 --> Language Class Initialized
INFO - 2023-09-25 06:53:00 --> Loader Class Initialized
INFO - 2023-09-25 06:53:00 --> Helper loaded: url_helper
INFO - 2023-09-25 06:53:00 --> Helper loaded: file_helper
INFO - 2023-09-25 06:53:00 --> Helper loaded: html_helper
INFO - 2023-09-25 06:53:00 --> Helper loaded: text_helper
INFO - 2023-09-25 06:53:00 --> Helper loaded: form_helper
INFO - 2023-09-25 06:53:00 --> Helper loaded: lang_helper
INFO - 2023-09-25 06:53:00 --> Helper loaded: security_helper
INFO - 2023-09-25 06:53:00 --> Helper loaded: cookie_helper
INFO - 2023-09-25 06:53:00 --> Database Driver Class Initialized
INFO - 2023-09-25 06:53:00 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-25 06:53:00 --> Parser Class Initialized
INFO - 2023-09-25 06:53:00 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-25 06:53:00 --> Pagination Class Initialized
INFO - 2023-09-25 06:53:00 --> Form Validation Class Initialized
INFO - 2023-09-25 06:53:00 --> Controller Class Initialized
INFO - 2023-09-25 06:53:00 --> Model Class Initialized
DEBUG - 2023-09-25 06:53:00 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-09-25 06:53:00 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-25 06:53:00 --> Model Class Initialized
DEBUG - 2023-09-25 06:53:00 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-25 06:53:00 --> Model Class Initialized
INFO - 2023-09-25 06:53:00 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice.php
DEBUG - 2023-09-25 06:53:00 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-09-25 06:53:00 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-09-25 06:53:00 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-09-25 06:53:00 --> Model Class Initialized
INFO - 2023-09-25 06:53:00 --> Model Class Initialized
INFO - 2023-09-25 06:53:00 --> Model Class Initialized
INFO - 2023-09-25 06:53:00 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-09-25 06:53:00 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-09-25 06:53:00 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-09-25 06:53:00 --> Final output sent to browser
DEBUG - 2023-09-25 06:53:00 --> Total execution time: 0.0953
ERROR - 2023-09-25 06:53:00 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-25 06:53:00 --> Config Class Initialized
INFO - 2023-09-25 06:53:00 --> Hooks Class Initialized
DEBUG - 2023-09-25 06:53:00 --> UTF-8 Support Enabled
INFO - 2023-09-25 06:53:00 --> Utf8 Class Initialized
INFO - 2023-09-25 06:53:00 --> URI Class Initialized
INFO - 2023-09-25 06:53:00 --> Router Class Initialized
INFO - 2023-09-25 06:53:00 --> Output Class Initialized
INFO - 2023-09-25 06:53:00 --> Security Class Initialized
DEBUG - 2023-09-25 06:53:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-25 06:53:00 --> Input Class Initialized
INFO - 2023-09-25 06:53:00 --> Language Class Initialized
INFO - 2023-09-25 06:53:00 --> Loader Class Initialized
INFO - 2023-09-25 06:53:00 --> Helper loaded: url_helper
INFO - 2023-09-25 06:53:00 --> Helper loaded: file_helper
INFO - 2023-09-25 06:53:00 --> Helper loaded: html_helper
INFO - 2023-09-25 06:53:00 --> Helper loaded: text_helper
INFO - 2023-09-25 06:53:00 --> Helper loaded: form_helper
INFO - 2023-09-25 06:53:00 --> Helper loaded: lang_helper
INFO - 2023-09-25 06:53:00 --> Helper loaded: security_helper
INFO - 2023-09-25 06:53:00 --> Helper loaded: cookie_helper
INFO - 2023-09-25 06:53:00 --> Database Driver Class Initialized
INFO - 2023-09-25 06:53:00 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-25 06:53:00 --> Parser Class Initialized
INFO - 2023-09-25 06:53:00 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-25 06:53:00 --> Pagination Class Initialized
INFO - 2023-09-25 06:53:00 --> Form Validation Class Initialized
INFO - 2023-09-25 06:53:00 --> Controller Class Initialized
INFO - 2023-09-25 06:53:00 --> Model Class Initialized
DEBUG - 2023-09-25 06:53:00 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-09-25 06:53:00 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-25 06:53:00 --> Model Class Initialized
DEBUG - 2023-09-25 06:53:00 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-25 06:53:00 --> Model Class Initialized
INFO - 2023-09-25 06:53:00 --> Final output sent to browser
DEBUG - 2023-09-25 06:53:00 --> Total execution time: 0.0460
ERROR - 2023-09-25 14:46:26 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-25 14:46:26 --> Config Class Initialized
INFO - 2023-09-25 14:46:26 --> Hooks Class Initialized
DEBUG - 2023-09-25 14:46:26 --> UTF-8 Support Enabled
INFO - 2023-09-25 14:46:26 --> Utf8 Class Initialized
INFO - 2023-09-25 14:46:26 --> URI Class Initialized
DEBUG - 2023-09-25 14:46:26 --> No URI present. Default controller set.
INFO - 2023-09-25 14:46:26 --> Router Class Initialized
INFO - 2023-09-25 14:46:26 --> Output Class Initialized
INFO - 2023-09-25 14:46:26 --> Security Class Initialized
DEBUG - 2023-09-25 14:46:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-25 14:46:26 --> Input Class Initialized
INFO - 2023-09-25 14:46:26 --> Language Class Initialized
INFO - 2023-09-25 14:46:26 --> Loader Class Initialized
INFO - 2023-09-25 14:46:26 --> Helper loaded: url_helper
INFO - 2023-09-25 14:46:26 --> Helper loaded: file_helper
INFO - 2023-09-25 14:46:26 --> Helper loaded: html_helper
INFO - 2023-09-25 14:46:26 --> Helper loaded: text_helper
INFO - 2023-09-25 14:46:26 --> Helper loaded: form_helper
INFO - 2023-09-25 14:46:26 --> Helper loaded: lang_helper
INFO - 2023-09-25 14:46:26 --> Helper loaded: security_helper
INFO - 2023-09-25 14:46:26 --> Helper loaded: cookie_helper
INFO - 2023-09-25 14:46:26 --> Database Driver Class Initialized
INFO - 2023-09-25 14:46:26 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-25 14:46:26 --> Parser Class Initialized
INFO - 2023-09-25 14:46:26 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-25 14:46:26 --> Pagination Class Initialized
INFO - 2023-09-25 14:46:26 --> Form Validation Class Initialized
INFO - 2023-09-25 14:46:26 --> Controller Class Initialized
INFO - 2023-09-25 14:46:26 --> Model Class Initialized
DEBUG - 2023-09-25 14:46:26 --> Session class already loaded. Second attempt ignored.
ERROR - 2023-09-25 14:46:27 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-25 14:46:27 --> Config Class Initialized
INFO - 2023-09-25 14:46:27 --> Hooks Class Initialized
DEBUG - 2023-09-25 14:46:27 --> UTF-8 Support Enabled
INFO - 2023-09-25 14:46:27 --> Utf8 Class Initialized
INFO - 2023-09-25 14:46:27 --> URI Class Initialized
INFO - 2023-09-25 14:46:27 --> Router Class Initialized
INFO - 2023-09-25 14:46:27 --> Output Class Initialized
INFO - 2023-09-25 14:46:27 --> Security Class Initialized
DEBUG - 2023-09-25 14:46:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-25 14:46:27 --> Input Class Initialized
INFO - 2023-09-25 14:46:27 --> Language Class Initialized
ERROR - 2023-09-25 14:46:27 --> 404 Page Not Found: Wp-includes/wlwmanifest.xml
ERROR - 2023-09-25 14:46:27 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-25 14:46:27 --> Config Class Initialized
INFO - 2023-09-25 14:46:27 --> Hooks Class Initialized
DEBUG - 2023-09-25 14:46:27 --> UTF-8 Support Enabled
INFO - 2023-09-25 14:46:27 --> Utf8 Class Initialized
INFO - 2023-09-25 14:46:27 --> URI Class Initialized
INFO - 2023-09-25 14:46:27 --> Router Class Initialized
INFO - 2023-09-25 14:46:27 --> Output Class Initialized
INFO - 2023-09-25 14:46:27 --> Security Class Initialized
DEBUG - 2023-09-25 14:46:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-25 14:46:27 --> Input Class Initialized
INFO - 2023-09-25 14:46:27 --> Language Class Initialized
ERROR - 2023-09-25 14:46:27 --> 404 Page Not Found: Xmlrpcphp/index
ERROR - 2023-09-25 14:46:27 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-25 14:46:27 --> Config Class Initialized
INFO - 2023-09-25 14:46:27 --> Hooks Class Initialized
DEBUG - 2023-09-25 14:46:27 --> UTF-8 Support Enabled
INFO - 2023-09-25 14:46:27 --> Utf8 Class Initialized
INFO - 2023-09-25 14:46:27 --> URI Class Initialized
DEBUG - 2023-09-25 14:46:27 --> No URI present. Default controller set.
INFO - 2023-09-25 14:46:27 --> Router Class Initialized
INFO - 2023-09-25 14:46:27 --> Output Class Initialized
INFO - 2023-09-25 14:46:27 --> Security Class Initialized
DEBUG - 2023-09-25 14:46:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-25 14:46:27 --> Input Class Initialized
INFO - 2023-09-25 14:46:27 --> Language Class Initialized
INFO - 2023-09-25 14:46:27 --> Loader Class Initialized
INFO - 2023-09-25 14:46:27 --> Helper loaded: url_helper
INFO - 2023-09-25 14:46:27 --> Helper loaded: file_helper
INFO - 2023-09-25 14:46:27 --> Helper loaded: html_helper
INFO - 2023-09-25 14:46:27 --> Helper loaded: text_helper
INFO - 2023-09-25 14:46:27 --> Helper loaded: form_helper
INFO - 2023-09-25 14:46:27 --> Helper loaded: lang_helper
INFO - 2023-09-25 14:46:27 --> Helper loaded: security_helper
INFO - 2023-09-25 14:46:27 --> Helper loaded: cookie_helper
INFO - 2023-09-25 14:46:27 --> Database Driver Class Initialized
INFO - 2023-09-25 14:46:27 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-25 14:46:27 --> Parser Class Initialized
INFO - 2023-09-25 14:46:27 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-25 14:46:27 --> Pagination Class Initialized
INFO - 2023-09-25 14:46:27 --> Form Validation Class Initialized
INFO - 2023-09-25 14:46:27 --> Controller Class Initialized
INFO - 2023-09-25 14:46:27 --> Model Class Initialized
DEBUG - 2023-09-25 14:46:27 --> Session class already loaded. Second attempt ignored.
ERROR - 2023-09-25 14:46:27 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-25 14:46:27 --> Config Class Initialized
INFO - 2023-09-25 14:46:27 --> Hooks Class Initialized
DEBUG - 2023-09-25 14:46:27 --> UTF-8 Support Enabled
INFO - 2023-09-25 14:46:27 --> Utf8 Class Initialized
INFO - 2023-09-25 14:46:27 --> URI Class Initialized
INFO - 2023-09-25 14:46:27 --> Router Class Initialized
INFO - 2023-09-25 14:46:27 --> Output Class Initialized
INFO - 2023-09-25 14:46:27 --> Security Class Initialized
DEBUG - 2023-09-25 14:46:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-25 14:46:27 --> Input Class Initialized
INFO - 2023-09-25 14:46:27 --> Language Class Initialized
ERROR - 2023-09-25 14:46:27 --> 404 Page Not Found: Blog/wp-includes
ERROR - 2023-09-25 14:46:27 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-25 14:46:27 --> Config Class Initialized
INFO - 2023-09-25 14:46:27 --> Hooks Class Initialized
DEBUG - 2023-09-25 14:46:27 --> UTF-8 Support Enabled
INFO - 2023-09-25 14:46:27 --> Utf8 Class Initialized
INFO - 2023-09-25 14:46:27 --> URI Class Initialized
INFO - 2023-09-25 14:46:27 --> Router Class Initialized
INFO - 2023-09-25 14:46:27 --> Output Class Initialized
INFO - 2023-09-25 14:46:27 --> Security Class Initialized
DEBUG - 2023-09-25 14:46:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-25 14:46:27 --> Input Class Initialized
INFO - 2023-09-25 14:46:27 --> Language Class Initialized
ERROR - 2023-09-25 14:46:27 --> 404 Page Not Found: Web/wp-includes
ERROR - 2023-09-25 14:46:27 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-25 14:46:27 --> Config Class Initialized
INFO - 2023-09-25 14:46:27 --> Hooks Class Initialized
DEBUG - 2023-09-25 14:46:27 --> UTF-8 Support Enabled
INFO - 2023-09-25 14:46:27 --> Utf8 Class Initialized
INFO - 2023-09-25 14:46:27 --> URI Class Initialized
INFO - 2023-09-25 14:46:27 --> Router Class Initialized
INFO - 2023-09-25 14:46:27 --> Output Class Initialized
INFO - 2023-09-25 14:46:27 --> Security Class Initialized
DEBUG - 2023-09-25 14:46:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-25 14:46:27 --> Input Class Initialized
INFO - 2023-09-25 14:46:27 --> Language Class Initialized
ERROR - 2023-09-25 14:46:27 --> 404 Page Not Found: Wordpress/wp-includes
ERROR - 2023-09-25 14:46:27 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-25 14:46:27 --> Config Class Initialized
INFO - 2023-09-25 14:46:27 --> Hooks Class Initialized
DEBUG - 2023-09-25 14:46:27 --> UTF-8 Support Enabled
INFO - 2023-09-25 14:46:27 --> Utf8 Class Initialized
INFO - 2023-09-25 14:46:27 --> URI Class Initialized
INFO - 2023-09-25 14:46:27 --> Router Class Initialized
INFO - 2023-09-25 14:46:27 --> Output Class Initialized
INFO - 2023-09-25 14:46:27 --> Security Class Initialized
DEBUG - 2023-09-25 14:46:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-25 14:46:27 --> Input Class Initialized
INFO - 2023-09-25 14:46:27 --> Language Class Initialized
ERROR - 2023-09-25 14:46:27 --> 404 Page Not Found: Website/wp-includes
ERROR - 2023-09-25 14:46:27 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-25 14:46:27 --> Config Class Initialized
INFO - 2023-09-25 14:46:27 --> Hooks Class Initialized
DEBUG - 2023-09-25 14:46:27 --> UTF-8 Support Enabled
INFO - 2023-09-25 14:46:27 --> Utf8 Class Initialized
INFO - 2023-09-25 14:46:27 --> URI Class Initialized
INFO - 2023-09-25 14:46:27 --> Router Class Initialized
INFO - 2023-09-25 14:46:27 --> Output Class Initialized
INFO - 2023-09-25 14:46:27 --> Security Class Initialized
DEBUG - 2023-09-25 14:46:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-25 14:46:27 --> Input Class Initialized
INFO - 2023-09-25 14:46:27 --> Language Class Initialized
ERROR - 2023-09-25 14:46:27 --> 404 Page Not Found: Wp/wp-includes
ERROR - 2023-09-25 14:46:28 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-25 14:46:28 --> Config Class Initialized
INFO - 2023-09-25 14:46:28 --> Hooks Class Initialized
DEBUG - 2023-09-25 14:46:28 --> UTF-8 Support Enabled
INFO - 2023-09-25 14:46:28 --> Utf8 Class Initialized
INFO - 2023-09-25 14:46:28 --> URI Class Initialized
INFO - 2023-09-25 14:46:28 --> Router Class Initialized
INFO - 2023-09-25 14:46:28 --> Output Class Initialized
INFO - 2023-09-25 14:46:28 --> Security Class Initialized
DEBUG - 2023-09-25 14:46:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-25 14:46:28 --> Input Class Initialized
INFO - 2023-09-25 14:46:28 --> Language Class Initialized
ERROR - 2023-09-25 14:46:28 --> 404 Page Not Found: News/wp-includes
ERROR - 2023-09-25 14:46:28 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-25 14:46:28 --> Config Class Initialized
INFO - 2023-09-25 14:46:28 --> Hooks Class Initialized
DEBUG - 2023-09-25 14:46:28 --> UTF-8 Support Enabled
INFO - 2023-09-25 14:46:28 --> Utf8 Class Initialized
INFO - 2023-09-25 14:46:28 --> URI Class Initialized
INFO - 2023-09-25 14:46:28 --> Router Class Initialized
INFO - 2023-09-25 14:46:28 --> Output Class Initialized
INFO - 2023-09-25 14:46:28 --> Security Class Initialized
DEBUG - 2023-09-25 14:46:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-25 14:46:28 --> Input Class Initialized
INFO - 2023-09-25 14:46:28 --> Language Class Initialized
ERROR - 2023-09-25 14:46:28 --> 404 Page Not Found: 2020/wp-includes
ERROR - 2023-09-25 14:46:28 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-25 14:46:28 --> Config Class Initialized
INFO - 2023-09-25 14:46:28 --> Hooks Class Initialized
DEBUG - 2023-09-25 14:46:28 --> UTF-8 Support Enabled
INFO - 2023-09-25 14:46:28 --> Utf8 Class Initialized
INFO - 2023-09-25 14:46:28 --> URI Class Initialized
INFO - 2023-09-25 14:46:28 --> Router Class Initialized
INFO - 2023-09-25 14:46:28 --> Output Class Initialized
INFO - 2023-09-25 14:46:28 --> Security Class Initialized
DEBUG - 2023-09-25 14:46:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-25 14:46:28 --> Input Class Initialized
INFO - 2023-09-25 14:46:28 --> Language Class Initialized
ERROR - 2023-09-25 14:46:28 --> 404 Page Not Found: 2019/wp-includes
ERROR - 2023-09-25 14:46:28 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-25 14:46:28 --> Config Class Initialized
INFO - 2023-09-25 14:46:28 --> Hooks Class Initialized
DEBUG - 2023-09-25 14:46:28 --> UTF-8 Support Enabled
INFO - 2023-09-25 14:46:28 --> Utf8 Class Initialized
INFO - 2023-09-25 14:46:28 --> URI Class Initialized
INFO - 2023-09-25 14:46:28 --> Router Class Initialized
INFO - 2023-09-25 14:46:28 --> Output Class Initialized
INFO - 2023-09-25 14:46:28 --> Security Class Initialized
DEBUG - 2023-09-25 14:46:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-25 14:46:28 --> Input Class Initialized
INFO - 2023-09-25 14:46:28 --> Language Class Initialized
ERROR - 2023-09-25 14:46:28 --> 404 Page Not Found: Shop/wp-includes
ERROR - 2023-09-25 14:46:28 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-25 14:46:28 --> Config Class Initialized
INFO - 2023-09-25 14:46:28 --> Hooks Class Initialized
DEBUG - 2023-09-25 14:46:28 --> UTF-8 Support Enabled
INFO - 2023-09-25 14:46:28 --> Utf8 Class Initialized
INFO - 2023-09-25 14:46:28 --> URI Class Initialized
INFO - 2023-09-25 14:46:28 --> Router Class Initialized
INFO - 2023-09-25 14:46:28 --> Output Class Initialized
INFO - 2023-09-25 14:46:28 --> Security Class Initialized
DEBUG - 2023-09-25 14:46:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-25 14:46:28 --> Input Class Initialized
INFO - 2023-09-25 14:46:28 --> Language Class Initialized
ERROR - 2023-09-25 14:46:28 --> 404 Page Not Found: Wp1/wp-includes
ERROR - 2023-09-25 14:46:28 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-25 14:46:28 --> Config Class Initialized
INFO - 2023-09-25 14:46:28 --> Hooks Class Initialized
DEBUG - 2023-09-25 14:46:28 --> UTF-8 Support Enabled
INFO - 2023-09-25 14:46:28 --> Utf8 Class Initialized
INFO - 2023-09-25 14:46:28 --> URI Class Initialized
INFO - 2023-09-25 14:46:28 --> Router Class Initialized
INFO - 2023-09-25 14:46:28 --> Output Class Initialized
INFO - 2023-09-25 14:46:28 --> Security Class Initialized
DEBUG - 2023-09-25 14:46:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-25 14:46:28 --> Input Class Initialized
INFO - 2023-09-25 14:46:28 --> Language Class Initialized
ERROR - 2023-09-25 14:46:28 --> 404 Page Not Found: Test/wp-includes
ERROR - 2023-09-25 14:46:28 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-25 14:46:28 --> Config Class Initialized
INFO - 2023-09-25 14:46:28 --> Hooks Class Initialized
DEBUG - 2023-09-25 14:46:28 --> UTF-8 Support Enabled
INFO - 2023-09-25 14:46:28 --> Utf8 Class Initialized
INFO - 2023-09-25 14:46:28 --> URI Class Initialized
INFO - 2023-09-25 14:46:28 --> Router Class Initialized
INFO - 2023-09-25 14:46:28 --> Output Class Initialized
INFO - 2023-09-25 14:46:28 --> Security Class Initialized
DEBUG - 2023-09-25 14:46:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-25 14:46:28 --> Input Class Initialized
INFO - 2023-09-25 14:46:28 --> Language Class Initialized
ERROR - 2023-09-25 14:46:28 --> 404 Page Not Found: Wp2/wp-includes
ERROR - 2023-09-25 14:46:28 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-25 14:46:28 --> Config Class Initialized
INFO - 2023-09-25 14:46:28 --> Hooks Class Initialized
DEBUG - 2023-09-25 14:46:28 --> UTF-8 Support Enabled
INFO - 2023-09-25 14:46:28 --> Utf8 Class Initialized
INFO - 2023-09-25 14:46:28 --> URI Class Initialized
INFO - 2023-09-25 14:46:28 --> Router Class Initialized
INFO - 2023-09-25 14:46:28 --> Output Class Initialized
INFO - 2023-09-25 14:46:28 --> Security Class Initialized
DEBUG - 2023-09-25 14:46:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-25 14:46:28 --> Input Class Initialized
INFO - 2023-09-25 14:46:28 --> Language Class Initialized
ERROR - 2023-09-25 14:46:28 --> 404 Page Not Found: Site/wp-includes
ERROR - 2023-09-25 14:46:28 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-25 14:46:28 --> Config Class Initialized
INFO - 2023-09-25 14:46:28 --> Hooks Class Initialized
DEBUG - 2023-09-25 14:46:28 --> UTF-8 Support Enabled
INFO - 2023-09-25 14:46:28 --> Utf8 Class Initialized
INFO - 2023-09-25 14:46:28 --> URI Class Initialized
INFO - 2023-09-25 14:46:28 --> Router Class Initialized
INFO - 2023-09-25 14:46:28 --> Output Class Initialized
INFO - 2023-09-25 14:46:28 --> Security Class Initialized
DEBUG - 2023-09-25 14:46:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-25 14:46:28 --> Input Class Initialized
INFO - 2023-09-25 14:46:28 --> Language Class Initialized
ERROR - 2023-09-25 14:46:28 --> 404 Page Not Found: Cms/wp-includes
ERROR - 2023-09-25 14:46:28 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-25 14:46:28 --> Config Class Initialized
INFO - 2023-09-25 14:46:28 --> Hooks Class Initialized
DEBUG - 2023-09-25 14:46:28 --> UTF-8 Support Enabled
INFO - 2023-09-25 14:46:28 --> Utf8 Class Initialized
INFO - 2023-09-25 14:46:28 --> URI Class Initialized
INFO - 2023-09-25 14:46:28 --> Router Class Initialized
INFO - 2023-09-25 14:46:28 --> Output Class Initialized
INFO - 2023-09-25 14:46:28 --> Security Class Initialized
DEBUG - 2023-09-25 14:46:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-25 14:46:28 --> Input Class Initialized
INFO - 2023-09-25 14:46:28 --> Language Class Initialized
ERROR - 2023-09-25 14:46:28 --> 404 Page Not Found: Sito/wp-includes
ERROR - 2023-09-25 16:37:04 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-25 16:37:04 --> Config Class Initialized
INFO - 2023-09-25 16:37:04 --> Hooks Class Initialized
DEBUG - 2023-09-25 16:37:04 --> UTF-8 Support Enabled
INFO - 2023-09-25 16:37:04 --> Utf8 Class Initialized
INFO - 2023-09-25 16:37:04 --> URI Class Initialized
DEBUG - 2023-09-25 16:37:04 --> No URI present. Default controller set.
INFO - 2023-09-25 16:37:04 --> Router Class Initialized
INFO - 2023-09-25 16:37:04 --> Output Class Initialized
INFO - 2023-09-25 16:37:04 --> Security Class Initialized
DEBUG - 2023-09-25 16:37:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-25 16:37:04 --> Input Class Initialized
INFO - 2023-09-25 16:37:04 --> Language Class Initialized
INFO - 2023-09-25 16:37:04 --> Loader Class Initialized
INFO - 2023-09-25 16:37:04 --> Helper loaded: url_helper
INFO - 2023-09-25 16:37:04 --> Helper loaded: file_helper
INFO - 2023-09-25 16:37:04 --> Helper loaded: html_helper
INFO - 2023-09-25 16:37:04 --> Helper loaded: text_helper
INFO - 2023-09-25 16:37:04 --> Helper loaded: form_helper
INFO - 2023-09-25 16:37:04 --> Helper loaded: lang_helper
INFO - 2023-09-25 16:37:04 --> Helper loaded: security_helper
INFO - 2023-09-25 16:37:04 --> Helper loaded: cookie_helper
INFO - 2023-09-25 16:37:04 --> Database Driver Class Initialized
INFO - 2023-09-25 16:37:04 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-25 16:37:04 --> Parser Class Initialized
INFO - 2023-09-25 16:37:04 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-25 16:37:04 --> Pagination Class Initialized
INFO - 2023-09-25 16:37:04 --> Form Validation Class Initialized
INFO - 2023-09-25 16:37:04 --> Controller Class Initialized
INFO - 2023-09-25 16:37:04 --> Model Class Initialized
DEBUG - 2023-09-25 16:37:04 --> Session class already loaded. Second attempt ignored.
ERROR - 2023-09-25 16:37:06 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-25 16:37:06 --> Config Class Initialized
INFO - 2023-09-25 16:37:06 --> Hooks Class Initialized
DEBUG - 2023-09-25 16:37:06 --> UTF-8 Support Enabled
INFO - 2023-09-25 16:37:06 --> Utf8 Class Initialized
INFO - 2023-09-25 16:37:06 --> URI Class Initialized
INFO - 2023-09-25 16:37:06 --> Router Class Initialized
INFO - 2023-09-25 16:37:06 --> Output Class Initialized
INFO - 2023-09-25 16:37:06 --> Security Class Initialized
DEBUG - 2023-09-25 16:37:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-25 16:37:06 --> Input Class Initialized
INFO - 2023-09-25 16:37:06 --> Language Class Initialized
INFO - 2023-09-25 16:37:06 --> Loader Class Initialized
INFO - 2023-09-25 16:37:06 --> Helper loaded: url_helper
INFO - 2023-09-25 16:37:06 --> Helper loaded: file_helper
INFO - 2023-09-25 16:37:06 --> Helper loaded: html_helper
INFO - 2023-09-25 16:37:06 --> Helper loaded: text_helper
INFO - 2023-09-25 16:37:06 --> Helper loaded: form_helper
INFO - 2023-09-25 16:37:06 --> Helper loaded: lang_helper
INFO - 2023-09-25 16:37:06 --> Helper loaded: security_helper
INFO - 2023-09-25 16:37:06 --> Helper loaded: cookie_helper
INFO - 2023-09-25 16:37:06 --> Database Driver Class Initialized
INFO - 2023-09-25 16:37:06 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-25 16:37:06 --> Parser Class Initialized
INFO - 2023-09-25 16:37:06 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-25 16:37:06 --> Pagination Class Initialized
INFO - 2023-09-25 16:37:06 --> Form Validation Class Initialized
INFO - 2023-09-25 16:37:06 --> Controller Class Initialized
INFO - 2023-09-25 16:37:06 --> Model Class Initialized
DEBUG - 2023-09-25 16:37:06 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-25 16:37:06 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2023-09-25 16:37:06 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-09-25 16:37:06 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-09-25 16:37:06 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-09-25 16:37:06 --> Model Class Initialized
INFO - 2023-09-25 16:37:06 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-09-25 16:37:06 --> Final output sent to browser
DEBUG - 2023-09-25 16:37:06 --> Total execution time: 0.0437
ERROR - 2023-09-25 16:38:33 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-25 16:38:33 --> Config Class Initialized
INFO - 2023-09-25 16:38:33 --> Hooks Class Initialized
DEBUG - 2023-09-25 16:38:33 --> UTF-8 Support Enabled
INFO - 2023-09-25 16:38:33 --> Utf8 Class Initialized
INFO - 2023-09-25 16:38:33 --> URI Class Initialized
DEBUG - 2023-09-25 16:38:33 --> No URI present. Default controller set.
INFO - 2023-09-25 16:38:33 --> Router Class Initialized
INFO - 2023-09-25 16:38:33 --> Output Class Initialized
INFO - 2023-09-25 16:38:33 --> Security Class Initialized
DEBUG - 2023-09-25 16:38:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-25 16:38:33 --> Input Class Initialized
INFO - 2023-09-25 16:38:33 --> Language Class Initialized
INFO - 2023-09-25 16:38:33 --> Loader Class Initialized
INFO - 2023-09-25 16:38:33 --> Helper loaded: url_helper
INFO - 2023-09-25 16:38:33 --> Helper loaded: file_helper
INFO - 2023-09-25 16:38:33 --> Helper loaded: html_helper
INFO - 2023-09-25 16:38:33 --> Helper loaded: text_helper
INFO - 2023-09-25 16:38:33 --> Helper loaded: form_helper
INFO - 2023-09-25 16:38:33 --> Helper loaded: lang_helper
INFO - 2023-09-25 16:38:33 --> Helper loaded: security_helper
INFO - 2023-09-25 16:38:33 --> Helper loaded: cookie_helper
INFO - 2023-09-25 16:38:33 --> Database Driver Class Initialized
INFO - 2023-09-25 16:38:34 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-25 16:38:34 --> Parser Class Initialized
INFO - 2023-09-25 16:38:34 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-25 16:38:34 --> Pagination Class Initialized
INFO - 2023-09-25 16:38:34 --> Form Validation Class Initialized
INFO - 2023-09-25 16:38:34 --> Controller Class Initialized
INFO - 2023-09-25 16:38:34 --> Model Class Initialized
DEBUG - 2023-09-25 16:38:34 --> Session class already loaded. Second attempt ignored.
ERROR - 2023-09-25 16:38:36 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-25 16:38:36 --> Config Class Initialized
INFO - 2023-09-25 16:38:36 --> Hooks Class Initialized
DEBUG - 2023-09-25 16:38:36 --> UTF-8 Support Enabled
INFO - 2023-09-25 16:38:36 --> Utf8 Class Initialized
INFO - 2023-09-25 16:38:36 --> URI Class Initialized
INFO - 2023-09-25 16:38:36 --> Router Class Initialized
INFO - 2023-09-25 16:38:36 --> Output Class Initialized
INFO - 2023-09-25 16:38:36 --> Security Class Initialized
DEBUG - 2023-09-25 16:38:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-25 16:38:36 --> Input Class Initialized
INFO - 2023-09-25 16:38:36 --> Language Class Initialized
INFO - 2023-09-25 16:38:36 --> Loader Class Initialized
INFO - 2023-09-25 16:38:36 --> Helper loaded: url_helper
INFO - 2023-09-25 16:38:36 --> Helper loaded: file_helper
INFO - 2023-09-25 16:38:36 --> Helper loaded: html_helper
INFO - 2023-09-25 16:38:36 --> Helper loaded: text_helper
INFO - 2023-09-25 16:38:36 --> Helper loaded: form_helper
INFO - 2023-09-25 16:38:36 --> Helper loaded: lang_helper
INFO - 2023-09-25 16:38:36 --> Helper loaded: security_helper
INFO - 2023-09-25 16:38:36 --> Helper loaded: cookie_helper
INFO - 2023-09-25 16:38:36 --> Database Driver Class Initialized
INFO - 2023-09-25 16:38:36 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-25 16:38:36 --> Parser Class Initialized
INFO - 2023-09-25 16:38:36 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-25 16:38:36 --> Pagination Class Initialized
INFO - 2023-09-25 16:38:36 --> Form Validation Class Initialized
INFO - 2023-09-25 16:38:36 --> Controller Class Initialized
INFO - 2023-09-25 16:38:36 --> Model Class Initialized
DEBUG - 2023-09-25 16:38:36 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-25 16:38:36 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2023-09-25 16:38:36 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-09-25 16:38:36 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-09-25 16:38:36 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-09-25 16:38:36 --> Model Class Initialized
INFO - 2023-09-25 16:38:36 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-09-25 16:38:36 --> Final output sent to browser
DEBUG - 2023-09-25 16:38:36 --> Total execution time: 0.0323
ERROR - 2023-09-25 16:38:46 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-25 16:38:46 --> Config Class Initialized
INFO - 2023-09-25 16:38:46 --> Hooks Class Initialized
DEBUG - 2023-09-25 16:38:46 --> UTF-8 Support Enabled
INFO - 2023-09-25 16:38:46 --> Utf8 Class Initialized
INFO - 2023-09-25 16:38:46 --> URI Class Initialized
INFO - 2023-09-25 16:38:46 --> Router Class Initialized
INFO - 2023-09-25 16:38:46 --> Output Class Initialized
INFO - 2023-09-25 16:38:46 --> Security Class Initialized
DEBUG - 2023-09-25 16:38:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-25 16:38:46 --> Input Class Initialized
INFO - 2023-09-25 16:38:46 --> Language Class Initialized
INFO - 2023-09-25 16:38:46 --> Loader Class Initialized
INFO - 2023-09-25 16:38:46 --> Helper loaded: url_helper
INFO - 2023-09-25 16:38:46 --> Helper loaded: file_helper
INFO - 2023-09-25 16:38:46 --> Helper loaded: html_helper
INFO - 2023-09-25 16:38:46 --> Helper loaded: text_helper
INFO - 2023-09-25 16:38:46 --> Helper loaded: form_helper
INFO - 2023-09-25 16:38:46 --> Helper loaded: lang_helper
INFO - 2023-09-25 16:38:46 --> Helper loaded: security_helper
INFO - 2023-09-25 16:38:46 --> Helper loaded: cookie_helper
INFO - 2023-09-25 16:38:46 --> Database Driver Class Initialized
INFO - 2023-09-25 16:38:46 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-25 16:38:46 --> Parser Class Initialized
INFO - 2023-09-25 16:38:46 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-25 16:38:46 --> Pagination Class Initialized
INFO - 2023-09-25 16:38:46 --> Form Validation Class Initialized
INFO - 2023-09-25 16:38:46 --> Controller Class Initialized
INFO - 2023-09-25 16:38:46 --> Model Class Initialized
DEBUG - 2023-09-25 16:38:46 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-25 16:38:46 --> Model Class Initialized
INFO - 2023-09-25 16:38:46 --> Final output sent to browser
DEBUG - 2023-09-25 16:38:46 --> Total execution time: 0.0224
ERROR - 2023-09-25 16:38:49 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-25 16:38:49 --> Config Class Initialized
INFO - 2023-09-25 16:38:49 --> Hooks Class Initialized
DEBUG - 2023-09-25 16:38:49 --> UTF-8 Support Enabled
INFO - 2023-09-25 16:38:49 --> Utf8 Class Initialized
INFO - 2023-09-25 16:38:49 --> URI Class Initialized
DEBUG - 2023-09-25 16:38:49 --> No URI present. Default controller set.
INFO - 2023-09-25 16:38:49 --> Router Class Initialized
INFO - 2023-09-25 16:38:49 --> Output Class Initialized
INFO - 2023-09-25 16:38:49 --> Security Class Initialized
DEBUG - 2023-09-25 16:38:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-25 16:38:49 --> Input Class Initialized
INFO - 2023-09-25 16:38:49 --> Language Class Initialized
INFO - 2023-09-25 16:38:49 --> Loader Class Initialized
INFO - 2023-09-25 16:38:49 --> Helper loaded: url_helper
INFO - 2023-09-25 16:38:49 --> Helper loaded: file_helper
INFO - 2023-09-25 16:38:49 --> Helper loaded: html_helper
INFO - 2023-09-25 16:38:49 --> Helper loaded: text_helper
INFO - 2023-09-25 16:38:49 --> Helper loaded: form_helper
INFO - 2023-09-25 16:38:49 --> Helper loaded: lang_helper
INFO - 2023-09-25 16:38:49 --> Helper loaded: security_helper
INFO - 2023-09-25 16:38:49 --> Helper loaded: cookie_helper
INFO - 2023-09-25 16:38:49 --> Database Driver Class Initialized
INFO - 2023-09-25 16:38:49 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-25 16:38:49 --> Parser Class Initialized
INFO - 2023-09-25 16:38:49 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-25 16:38:49 --> Pagination Class Initialized
INFO - 2023-09-25 16:38:49 --> Form Validation Class Initialized
INFO - 2023-09-25 16:38:49 --> Controller Class Initialized
INFO - 2023-09-25 16:38:49 --> Model Class Initialized
DEBUG - 2023-09-25 16:38:49 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-25 16:38:49 --> Model Class Initialized
DEBUG - 2023-09-25 16:38:49 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-25 16:38:49 --> Model Class Initialized
INFO - 2023-09-25 16:38:49 --> Model Class Initialized
INFO - 2023-09-25 16:38:49 --> Model Class Initialized
INFO - 2023-09-25 16:38:49 --> Model Class Initialized
DEBUG - 2023-09-25 16:38:49 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-09-25 16:38:49 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-25 16:38:49 --> Model Class Initialized
INFO - 2023-09-25 16:38:49 --> Model Class Initialized
INFO - 2023-09-25 16:38:49 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-09-25 16:38:49 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-09-25 16:38:49 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-09-25 16:38:49 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-09-25 16:38:49 --> Model Class Initialized
INFO - 2023-09-25 16:38:49 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-09-25 16:38:49 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-09-25 16:38:49 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-09-25 16:38:49 --> Final output sent to browser
DEBUG - 2023-09-25 16:38:49 --> Total execution time: 0.2682
ERROR - 2023-09-25 16:38:53 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-25 16:38:53 --> Config Class Initialized
INFO - 2023-09-25 16:38:53 --> Hooks Class Initialized
DEBUG - 2023-09-25 16:38:53 --> UTF-8 Support Enabled
INFO - 2023-09-25 16:38:53 --> Utf8 Class Initialized
INFO - 2023-09-25 16:38:53 --> URI Class Initialized
INFO - 2023-09-25 16:38:53 --> Router Class Initialized
INFO - 2023-09-25 16:38:53 --> Output Class Initialized
INFO - 2023-09-25 16:38:53 --> Security Class Initialized
DEBUG - 2023-09-25 16:38:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-25 16:38:53 --> Input Class Initialized
INFO - 2023-09-25 16:38:53 --> Language Class Initialized
INFO - 2023-09-25 16:38:53 --> Loader Class Initialized
INFO - 2023-09-25 16:38:53 --> Helper loaded: url_helper
INFO - 2023-09-25 16:38:53 --> Helper loaded: file_helper
INFO - 2023-09-25 16:38:53 --> Helper loaded: html_helper
INFO - 2023-09-25 16:38:53 --> Helper loaded: text_helper
INFO - 2023-09-25 16:38:53 --> Helper loaded: form_helper
INFO - 2023-09-25 16:38:53 --> Helper loaded: lang_helper
INFO - 2023-09-25 16:38:53 --> Helper loaded: security_helper
INFO - 2023-09-25 16:38:53 --> Helper loaded: cookie_helper
INFO - 2023-09-25 16:38:53 --> Database Driver Class Initialized
INFO - 2023-09-25 16:38:53 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-25 16:38:53 --> Parser Class Initialized
INFO - 2023-09-25 16:38:53 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-25 16:38:53 --> Pagination Class Initialized
INFO - 2023-09-25 16:38:53 --> Form Validation Class Initialized
INFO - 2023-09-25 16:38:53 --> Controller Class Initialized
DEBUG - 2023-09-25 16:38:53 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-09-25 16:38:53 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-25 16:38:53 --> Model Class Initialized
INFO - 2023-09-25 16:38:53 --> Final output sent to browser
DEBUG - 2023-09-25 16:38:53 --> Total execution time: 0.0166
ERROR - 2023-09-25 16:48:41 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-25 16:48:41 --> Config Class Initialized
INFO - 2023-09-25 16:48:41 --> Hooks Class Initialized
DEBUG - 2023-09-25 16:48:41 --> UTF-8 Support Enabled
INFO - 2023-09-25 16:48:41 --> Utf8 Class Initialized
INFO - 2023-09-25 16:48:41 --> URI Class Initialized
DEBUG - 2023-09-25 16:48:41 --> No URI present. Default controller set.
INFO - 2023-09-25 16:48:41 --> Router Class Initialized
INFO - 2023-09-25 16:48:41 --> Output Class Initialized
INFO - 2023-09-25 16:48:41 --> Security Class Initialized
DEBUG - 2023-09-25 16:48:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-25 16:48:41 --> Input Class Initialized
INFO - 2023-09-25 16:48:41 --> Language Class Initialized
INFO - 2023-09-25 16:48:41 --> Loader Class Initialized
INFO - 2023-09-25 16:48:41 --> Helper loaded: url_helper
INFO - 2023-09-25 16:48:41 --> Helper loaded: file_helper
INFO - 2023-09-25 16:48:41 --> Helper loaded: html_helper
INFO - 2023-09-25 16:48:41 --> Helper loaded: text_helper
INFO - 2023-09-25 16:48:41 --> Helper loaded: form_helper
INFO - 2023-09-25 16:48:41 --> Helper loaded: lang_helper
INFO - 2023-09-25 16:48:41 --> Helper loaded: security_helper
INFO - 2023-09-25 16:48:41 --> Helper loaded: cookie_helper
INFO - 2023-09-25 16:48:41 --> Database Driver Class Initialized
INFO - 2023-09-25 16:48:41 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-25 16:48:41 --> Parser Class Initialized
INFO - 2023-09-25 16:48:41 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-25 16:48:41 --> Pagination Class Initialized
INFO - 2023-09-25 16:48:41 --> Form Validation Class Initialized
INFO - 2023-09-25 16:48:41 --> Controller Class Initialized
INFO - 2023-09-25 16:48:41 --> Model Class Initialized
DEBUG - 2023-09-25 16:48:41 --> Session class already loaded. Second attempt ignored.
ERROR - 2023-09-25 16:48:46 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-25 16:48:46 --> Config Class Initialized
INFO - 2023-09-25 16:48:46 --> Hooks Class Initialized
DEBUG - 2023-09-25 16:48:46 --> UTF-8 Support Enabled
INFO - 2023-09-25 16:48:46 --> Utf8 Class Initialized
INFO - 2023-09-25 16:48:46 --> URI Class Initialized
DEBUG - 2023-09-25 16:48:46 --> No URI present. Default controller set.
INFO - 2023-09-25 16:48:46 --> Router Class Initialized
INFO - 2023-09-25 16:48:46 --> Output Class Initialized
INFO - 2023-09-25 16:48:46 --> Security Class Initialized
DEBUG - 2023-09-25 16:48:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-25 16:48:46 --> Input Class Initialized
INFO - 2023-09-25 16:48:46 --> Language Class Initialized
INFO - 2023-09-25 16:48:46 --> Loader Class Initialized
INFO - 2023-09-25 16:48:46 --> Helper loaded: url_helper
INFO - 2023-09-25 16:48:46 --> Helper loaded: file_helper
INFO - 2023-09-25 16:48:46 --> Helper loaded: html_helper
INFO - 2023-09-25 16:48:46 --> Helper loaded: text_helper
INFO - 2023-09-25 16:48:46 --> Helper loaded: form_helper
INFO - 2023-09-25 16:48:46 --> Helper loaded: lang_helper
INFO - 2023-09-25 16:48:46 --> Helper loaded: security_helper
INFO - 2023-09-25 16:48:46 --> Helper loaded: cookie_helper
INFO - 2023-09-25 16:48:46 --> Database Driver Class Initialized
INFO - 2023-09-25 16:48:46 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-25 16:48:46 --> Parser Class Initialized
INFO - 2023-09-25 16:48:46 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-25 16:48:46 --> Pagination Class Initialized
INFO - 2023-09-25 16:48:46 --> Form Validation Class Initialized
INFO - 2023-09-25 16:48:46 --> Controller Class Initialized
INFO - 2023-09-25 16:48:46 --> Model Class Initialized
DEBUG - 2023-09-25 16:48:46 --> Session class already loaded. Second attempt ignored.
ERROR - 2023-09-25 16:48:46 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-25 16:48:46 --> Config Class Initialized
INFO - 2023-09-25 16:48:46 --> Hooks Class Initialized
DEBUG - 2023-09-25 16:48:46 --> UTF-8 Support Enabled
INFO - 2023-09-25 16:48:46 --> Utf8 Class Initialized
INFO - 2023-09-25 16:48:46 --> URI Class Initialized
INFO - 2023-09-25 16:48:46 --> Router Class Initialized
INFO - 2023-09-25 16:48:46 --> Output Class Initialized
INFO - 2023-09-25 16:48:46 --> Security Class Initialized
DEBUG - 2023-09-25 16:48:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-25 16:48:46 --> Input Class Initialized
INFO - 2023-09-25 16:48:46 --> Language Class Initialized
INFO - 2023-09-25 16:48:46 --> Loader Class Initialized
INFO - 2023-09-25 16:48:46 --> Helper loaded: url_helper
INFO - 2023-09-25 16:48:46 --> Helper loaded: file_helper
INFO - 2023-09-25 16:48:46 --> Helper loaded: html_helper
INFO - 2023-09-25 16:48:46 --> Helper loaded: text_helper
INFO - 2023-09-25 16:48:46 --> Helper loaded: form_helper
INFO - 2023-09-25 16:48:46 --> Helper loaded: lang_helper
INFO - 2023-09-25 16:48:46 --> Helper loaded: security_helper
INFO - 2023-09-25 16:48:46 --> Helper loaded: cookie_helper
INFO - 2023-09-25 16:48:46 --> Database Driver Class Initialized
INFO - 2023-09-25 16:48:46 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-25 16:48:46 --> Parser Class Initialized
INFO - 2023-09-25 16:48:46 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-25 16:48:46 --> Pagination Class Initialized
INFO - 2023-09-25 16:48:46 --> Form Validation Class Initialized
INFO - 2023-09-25 16:48:46 --> Controller Class Initialized
INFO - 2023-09-25 16:48:46 --> Model Class Initialized
DEBUG - 2023-09-25 16:48:46 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-25 16:48:46 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2023-09-25 16:48:46 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-09-25 16:48:46 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-09-25 16:48:46 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-09-25 16:48:46 --> Model Class Initialized
INFO - 2023-09-25 16:48:46 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-09-25 16:48:46 --> Final output sent to browser
DEBUG - 2023-09-25 16:48:46 --> Total execution time: 0.0298
ERROR - 2023-09-25 16:48:50 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-25 16:48:50 --> Config Class Initialized
INFO - 2023-09-25 16:48:50 --> Hooks Class Initialized
DEBUG - 2023-09-25 16:48:50 --> UTF-8 Support Enabled
INFO - 2023-09-25 16:48:50 --> Utf8 Class Initialized
INFO - 2023-09-25 16:48:50 --> URI Class Initialized
INFO - 2023-09-25 16:48:50 --> Router Class Initialized
INFO - 2023-09-25 16:48:50 --> Output Class Initialized
INFO - 2023-09-25 16:48:50 --> Security Class Initialized
DEBUG - 2023-09-25 16:48:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-25 16:48:50 --> Input Class Initialized
INFO - 2023-09-25 16:48:50 --> Language Class Initialized
INFO - 2023-09-25 16:48:50 --> Loader Class Initialized
INFO - 2023-09-25 16:48:50 --> Helper loaded: url_helper
INFO - 2023-09-25 16:48:50 --> Helper loaded: file_helper
INFO - 2023-09-25 16:48:50 --> Helper loaded: html_helper
INFO - 2023-09-25 16:48:50 --> Helper loaded: text_helper
INFO - 2023-09-25 16:48:50 --> Helper loaded: form_helper
INFO - 2023-09-25 16:48:50 --> Helper loaded: lang_helper
INFO - 2023-09-25 16:48:50 --> Helper loaded: security_helper
INFO - 2023-09-25 16:48:50 --> Helper loaded: cookie_helper
INFO - 2023-09-25 16:48:50 --> Database Driver Class Initialized
INFO - 2023-09-25 16:48:50 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-25 16:48:50 --> Parser Class Initialized
INFO - 2023-09-25 16:48:50 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-25 16:48:50 --> Pagination Class Initialized
INFO - 2023-09-25 16:48:50 --> Form Validation Class Initialized
INFO - 2023-09-25 16:48:50 --> Controller Class Initialized
INFO - 2023-09-25 16:48:50 --> Model Class Initialized
DEBUG - 2023-09-25 16:48:50 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-25 16:48:50 --> Model Class Initialized
INFO - 2023-09-25 16:48:50 --> Final output sent to browser
DEBUG - 2023-09-25 16:48:50 --> Total execution time: 0.0184
ERROR - 2023-09-25 16:48:51 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-25 16:48:51 --> Config Class Initialized
INFO - 2023-09-25 16:48:51 --> Hooks Class Initialized
DEBUG - 2023-09-25 16:48:51 --> UTF-8 Support Enabled
INFO - 2023-09-25 16:48:51 --> Utf8 Class Initialized
INFO - 2023-09-25 16:48:51 --> URI Class Initialized
DEBUG - 2023-09-25 16:48:51 --> No URI present. Default controller set.
INFO - 2023-09-25 16:48:51 --> Router Class Initialized
INFO - 2023-09-25 16:48:51 --> Output Class Initialized
INFO - 2023-09-25 16:48:51 --> Security Class Initialized
DEBUG - 2023-09-25 16:48:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-25 16:48:51 --> Input Class Initialized
INFO - 2023-09-25 16:48:51 --> Language Class Initialized
INFO - 2023-09-25 16:48:51 --> Loader Class Initialized
INFO - 2023-09-25 16:48:51 --> Helper loaded: url_helper
INFO - 2023-09-25 16:48:51 --> Helper loaded: file_helper
INFO - 2023-09-25 16:48:51 --> Helper loaded: html_helper
INFO - 2023-09-25 16:48:51 --> Helper loaded: text_helper
INFO - 2023-09-25 16:48:51 --> Helper loaded: form_helper
INFO - 2023-09-25 16:48:51 --> Helper loaded: lang_helper
INFO - 2023-09-25 16:48:51 --> Helper loaded: security_helper
INFO - 2023-09-25 16:48:51 --> Helper loaded: cookie_helper
INFO - 2023-09-25 16:48:51 --> Database Driver Class Initialized
INFO - 2023-09-25 16:48:51 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-25 16:48:51 --> Parser Class Initialized
INFO - 2023-09-25 16:48:51 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-25 16:48:51 --> Pagination Class Initialized
INFO - 2023-09-25 16:48:51 --> Form Validation Class Initialized
INFO - 2023-09-25 16:48:51 --> Controller Class Initialized
INFO - 2023-09-25 16:48:51 --> Model Class Initialized
DEBUG - 2023-09-25 16:48:51 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-25 16:48:51 --> Model Class Initialized
DEBUG - 2023-09-25 16:48:51 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-25 16:48:51 --> Model Class Initialized
INFO - 2023-09-25 16:48:51 --> Model Class Initialized
INFO - 2023-09-25 16:48:51 --> Model Class Initialized
INFO - 2023-09-25 16:48:51 --> Model Class Initialized
DEBUG - 2023-09-25 16:48:51 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-09-25 16:48:51 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-25 16:48:51 --> Model Class Initialized
INFO - 2023-09-25 16:48:51 --> Model Class Initialized
INFO - 2023-09-25 16:48:51 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-09-25 16:48:51 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-09-25 16:48:51 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-09-25 16:48:51 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-09-25 16:48:51 --> Model Class Initialized
INFO - 2023-09-25 16:48:51 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-09-25 16:48:51 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-09-25 16:48:51 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-09-25 16:48:51 --> Final output sent to browser
DEBUG - 2023-09-25 16:48:51 --> Total execution time: 0.1118
ERROR - 2023-09-25 16:48:54 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-25 16:48:54 --> Config Class Initialized
INFO - 2023-09-25 16:48:54 --> Hooks Class Initialized
DEBUG - 2023-09-25 16:48:54 --> UTF-8 Support Enabled
INFO - 2023-09-25 16:48:54 --> Utf8 Class Initialized
INFO - 2023-09-25 16:48:54 --> URI Class Initialized
INFO - 2023-09-25 16:48:54 --> Router Class Initialized
INFO - 2023-09-25 16:48:54 --> Output Class Initialized
INFO - 2023-09-25 16:48:54 --> Security Class Initialized
DEBUG - 2023-09-25 16:48:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-25 16:48:54 --> Input Class Initialized
INFO - 2023-09-25 16:48:54 --> Language Class Initialized
INFO - 2023-09-25 16:48:54 --> Loader Class Initialized
INFO - 2023-09-25 16:48:54 --> Helper loaded: url_helper
INFO - 2023-09-25 16:48:54 --> Helper loaded: file_helper
INFO - 2023-09-25 16:48:54 --> Helper loaded: html_helper
INFO - 2023-09-25 16:48:54 --> Helper loaded: text_helper
INFO - 2023-09-25 16:48:54 --> Helper loaded: form_helper
INFO - 2023-09-25 16:48:54 --> Helper loaded: lang_helper
INFO - 2023-09-25 16:48:54 --> Helper loaded: security_helper
INFO - 2023-09-25 16:48:54 --> Helper loaded: cookie_helper
INFO - 2023-09-25 16:48:54 --> Database Driver Class Initialized
INFO - 2023-09-25 16:48:54 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-25 16:48:54 --> Parser Class Initialized
INFO - 2023-09-25 16:48:54 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-25 16:48:54 --> Pagination Class Initialized
INFO - 2023-09-25 16:48:54 --> Form Validation Class Initialized
INFO - 2023-09-25 16:48:54 --> Controller Class Initialized
INFO - 2023-09-25 16:48:54 --> Model Class Initialized
DEBUG - 2023-09-25 16:48:54 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-09-25 16:48:54 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-25 16:48:54 --> Model Class Initialized
DEBUG - 2023-09-25 16:48:54 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-25 16:48:54 --> Model Class Initialized
INFO - 2023-09-25 16:48:54 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice.php
DEBUG - 2023-09-25 16:48:54 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-09-25 16:48:54 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-09-25 16:48:54 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-09-25 16:48:54 --> Model Class Initialized
INFO - 2023-09-25 16:48:54 --> Model Class Initialized
INFO - 2023-09-25 16:48:54 --> Model Class Initialized
INFO - 2023-09-25 16:48:54 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-09-25 16:48:54 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-09-25 16:48:54 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-09-25 16:48:54 --> Final output sent to browser
DEBUG - 2023-09-25 16:48:54 --> Total execution time: 0.0864
ERROR - 2023-09-25 16:48:55 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-25 16:48:55 --> Config Class Initialized
INFO - 2023-09-25 16:48:55 --> Hooks Class Initialized
DEBUG - 2023-09-25 16:48:55 --> UTF-8 Support Enabled
INFO - 2023-09-25 16:48:55 --> Utf8 Class Initialized
INFO - 2023-09-25 16:48:55 --> URI Class Initialized
INFO - 2023-09-25 16:48:55 --> Router Class Initialized
INFO - 2023-09-25 16:48:55 --> Output Class Initialized
INFO - 2023-09-25 16:48:55 --> Security Class Initialized
DEBUG - 2023-09-25 16:48:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-25 16:48:55 --> Input Class Initialized
INFO - 2023-09-25 16:48:55 --> Language Class Initialized
INFO - 2023-09-25 16:48:55 --> Loader Class Initialized
INFO - 2023-09-25 16:48:55 --> Helper loaded: url_helper
INFO - 2023-09-25 16:48:55 --> Helper loaded: file_helper
INFO - 2023-09-25 16:48:55 --> Helper loaded: html_helper
INFO - 2023-09-25 16:48:55 --> Helper loaded: text_helper
INFO - 2023-09-25 16:48:55 --> Helper loaded: form_helper
INFO - 2023-09-25 16:48:55 --> Helper loaded: lang_helper
INFO - 2023-09-25 16:48:55 --> Helper loaded: security_helper
INFO - 2023-09-25 16:48:55 --> Helper loaded: cookie_helper
INFO - 2023-09-25 16:48:55 --> Database Driver Class Initialized
INFO - 2023-09-25 16:48:55 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-25 16:48:55 --> Parser Class Initialized
INFO - 2023-09-25 16:48:55 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-25 16:48:55 --> Pagination Class Initialized
INFO - 2023-09-25 16:48:55 --> Form Validation Class Initialized
INFO - 2023-09-25 16:48:55 --> Controller Class Initialized
INFO - 2023-09-25 16:48:55 --> Model Class Initialized
DEBUG - 2023-09-25 16:48:55 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-09-25 16:48:55 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-25 16:48:55 --> Model Class Initialized
DEBUG - 2023-09-25 16:48:55 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-25 16:48:55 --> Model Class Initialized
INFO - 2023-09-25 16:48:55 --> Final output sent to browser
DEBUG - 2023-09-25 16:48:55 --> Total execution time: 0.0369
ERROR - 2023-09-25 16:48:57 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-25 16:48:57 --> Config Class Initialized
INFO - 2023-09-25 16:48:57 --> Hooks Class Initialized
DEBUG - 2023-09-25 16:48:57 --> UTF-8 Support Enabled
INFO - 2023-09-25 16:48:57 --> Utf8 Class Initialized
INFO - 2023-09-25 16:48:57 --> URI Class Initialized
INFO - 2023-09-25 16:48:57 --> Router Class Initialized
INFO - 2023-09-25 16:48:57 --> Output Class Initialized
INFO - 2023-09-25 16:48:57 --> Security Class Initialized
DEBUG - 2023-09-25 16:48:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-25 16:48:57 --> Input Class Initialized
INFO - 2023-09-25 16:48:57 --> Language Class Initialized
INFO - 2023-09-25 16:48:57 --> Loader Class Initialized
INFO - 2023-09-25 16:48:57 --> Helper loaded: url_helper
INFO - 2023-09-25 16:48:57 --> Helper loaded: file_helper
INFO - 2023-09-25 16:48:57 --> Helper loaded: html_helper
INFO - 2023-09-25 16:48:57 --> Helper loaded: text_helper
INFO - 2023-09-25 16:48:57 --> Helper loaded: form_helper
INFO - 2023-09-25 16:48:57 --> Helper loaded: lang_helper
INFO - 2023-09-25 16:48:57 --> Helper loaded: security_helper
INFO - 2023-09-25 16:48:57 --> Helper loaded: cookie_helper
INFO - 2023-09-25 16:48:57 --> Database Driver Class Initialized
INFO - 2023-09-25 16:48:57 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-25 16:48:57 --> Parser Class Initialized
INFO - 2023-09-25 16:48:57 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-25 16:48:57 --> Pagination Class Initialized
INFO - 2023-09-25 16:48:57 --> Form Validation Class Initialized
INFO - 2023-09-25 16:48:57 --> Controller Class Initialized
INFO - 2023-09-25 16:48:57 --> Model Class Initialized
DEBUG - 2023-09-25 16:48:57 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-09-25 16:48:57 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-25 16:48:57 --> Model Class Initialized
DEBUG - 2023-09-25 16:48:57 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-25 16:48:57 --> Model Class Initialized
INFO - 2023-09-25 16:48:57 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/add_invoice_form.php
DEBUG - 2023-09-25 16:48:57 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-09-25 16:48:57 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-09-25 16:48:57 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-09-25 16:48:57 --> Model Class Initialized
INFO - 2023-09-25 16:48:57 --> Model Class Initialized
INFO - 2023-09-25 16:48:57 --> Model Class Initialized
INFO - 2023-09-25 16:48:57 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-09-25 16:48:57 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-09-25 16:48:57 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-09-25 16:48:57 --> Final output sent to browser
DEBUG - 2023-09-25 16:48:57 --> Total execution time: 0.1070
ERROR - 2023-09-25 16:49:01 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-25 16:49:01 --> Config Class Initialized
INFO - 2023-09-25 16:49:01 --> Hooks Class Initialized
DEBUG - 2023-09-25 16:49:01 --> UTF-8 Support Enabled
INFO - 2023-09-25 16:49:01 --> Utf8 Class Initialized
INFO - 2023-09-25 16:49:01 --> URI Class Initialized
INFO - 2023-09-25 16:49:01 --> Router Class Initialized
INFO - 2023-09-25 16:49:01 --> Output Class Initialized
INFO - 2023-09-25 16:49:01 --> Security Class Initialized
DEBUG - 2023-09-25 16:49:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-25 16:49:01 --> Input Class Initialized
INFO - 2023-09-25 16:49:01 --> Language Class Initialized
INFO - 2023-09-25 16:49:01 --> Loader Class Initialized
INFO - 2023-09-25 16:49:01 --> Helper loaded: url_helper
INFO - 2023-09-25 16:49:01 --> Helper loaded: file_helper
INFO - 2023-09-25 16:49:01 --> Helper loaded: html_helper
INFO - 2023-09-25 16:49:01 --> Helper loaded: text_helper
INFO - 2023-09-25 16:49:01 --> Helper loaded: form_helper
INFO - 2023-09-25 16:49:01 --> Helper loaded: lang_helper
INFO - 2023-09-25 16:49:01 --> Helper loaded: security_helper
INFO - 2023-09-25 16:49:01 --> Helper loaded: cookie_helper
INFO - 2023-09-25 16:49:01 --> Database Driver Class Initialized
INFO - 2023-09-25 16:49:01 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-25 16:49:01 --> Parser Class Initialized
INFO - 2023-09-25 16:49:01 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-25 16:49:01 --> Pagination Class Initialized
INFO - 2023-09-25 16:49:01 --> Form Validation Class Initialized
INFO - 2023-09-25 16:49:01 --> Controller Class Initialized
INFO - 2023-09-25 16:49:01 --> Model Class Initialized
DEBUG - 2023-09-25 16:49:01 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-25 16:49:01 --> Final output sent to browser
DEBUG - 2023-09-25 16:49:01 --> Total execution time: 0.0157
ERROR - 2023-09-25 16:49:02 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-25 16:49:02 --> Config Class Initialized
INFO - 2023-09-25 16:49:02 --> Hooks Class Initialized
DEBUG - 2023-09-25 16:49:02 --> UTF-8 Support Enabled
INFO - 2023-09-25 16:49:02 --> Utf8 Class Initialized
INFO - 2023-09-25 16:49:02 --> URI Class Initialized
INFO - 2023-09-25 16:49:02 --> Router Class Initialized
INFO - 2023-09-25 16:49:02 --> Output Class Initialized
INFO - 2023-09-25 16:49:02 --> Security Class Initialized
DEBUG - 2023-09-25 16:49:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-25 16:49:02 --> Input Class Initialized
INFO - 2023-09-25 16:49:02 --> Language Class Initialized
INFO - 2023-09-25 16:49:02 --> Loader Class Initialized
INFO - 2023-09-25 16:49:02 --> Helper loaded: url_helper
INFO - 2023-09-25 16:49:02 --> Helper loaded: file_helper
INFO - 2023-09-25 16:49:02 --> Helper loaded: html_helper
INFO - 2023-09-25 16:49:02 --> Helper loaded: text_helper
INFO - 2023-09-25 16:49:02 --> Helper loaded: form_helper
INFO - 2023-09-25 16:49:02 --> Helper loaded: lang_helper
INFO - 2023-09-25 16:49:02 --> Helper loaded: security_helper
INFO - 2023-09-25 16:49:02 --> Helper loaded: cookie_helper
INFO - 2023-09-25 16:49:02 --> Database Driver Class Initialized
INFO - 2023-09-25 16:49:02 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-25 16:49:02 --> Parser Class Initialized
INFO - 2023-09-25 16:49:02 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-25 16:49:02 --> Pagination Class Initialized
INFO - 2023-09-25 16:49:02 --> Form Validation Class Initialized
INFO - 2023-09-25 16:49:02 --> Controller Class Initialized
INFO - 2023-09-25 16:49:02 --> Model Class Initialized
DEBUG - 2023-09-25 16:49:02 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-25 16:49:02 --> Final output sent to browser
DEBUG - 2023-09-25 16:49:02 --> Total execution time: 0.0182
ERROR - 2023-09-25 16:49:03 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-25 16:49:03 --> Config Class Initialized
INFO - 2023-09-25 16:49:03 --> Hooks Class Initialized
DEBUG - 2023-09-25 16:49:03 --> UTF-8 Support Enabled
INFO - 2023-09-25 16:49:03 --> Utf8 Class Initialized
INFO - 2023-09-25 16:49:03 --> URI Class Initialized
INFO - 2023-09-25 16:49:03 --> Router Class Initialized
INFO - 2023-09-25 16:49:03 --> Output Class Initialized
INFO - 2023-09-25 16:49:03 --> Security Class Initialized
DEBUG - 2023-09-25 16:49:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-25 16:49:03 --> Input Class Initialized
INFO - 2023-09-25 16:49:03 --> Language Class Initialized
INFO - 2023-09-25 16:49:03 --> Loader Class Initialized
INFO - 2023-09-25 16:49:03 --> Helper loaded: url_helper
INFO - 2023-09-25 16:49:03 --> Helper loaded: file_helper
INFO - 2023-09-25 16:49:03 --> Helper loaded: html_helper
INFO - 2023-09-25 16:49:03 --> Helper loaded: text_helper
INFO - 2023-09-25 16:49:03 --> Helper loaded: form_helper
INFO - 2023-09-25 16:49:03 --> Helper loaded: lang_helper
INFO - 2023-09-25 16:49:03 --> Helper loaded: security_helper
INFO - 2023-09-25 16:49:03 --> Helper loaded: cookie_helper
INFO - 2023-09-25 16:49:03 --> Database Driver Class Initialized
INFO - 2023-09-25 16:49:03 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-25 16:49:03 --> Parser Class Initialized
INFO - 2023-09-25 16:49:03 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-25 16:49:03 --> Pagination Class Initialized
INFO - 2023-09-25 16:49:03 --> Form Validation Class Initialized
INFO - 2023-09-25 16:49:03 --> Controller Class Initialized
INFO - 2023-09-25 16:49:03 --> Final output sent to browser
DEBUG - 2023-09-25 16:49:03 --> Total execution time: 0.0142
ERROR - 2023-09-25 16:49:06 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-25 16:49:06 --> Config Class Initialized
INFO - 2023-09-25 16:49:06 --> Hooks Class Initialized
DEBUG - 2023-09-25 16:49:06 --> UTF-8 Support Enabled
INFO - 2023-09-25 16:49:06 --> Utf8 Class Initialized
INFO - 2023-09-25 16:49:06 --> URI Class Initialized
INFO - 2023-09-25 16:49:06 --> Router Class Initialized
INFO - 2023-09-25 16:49:06 --> Output Class Initialized
INFO - 2023-09-25 16:49:06 --> Security Class Initialized
DEBUG - 2023-09-25 16:49:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-25 16:49:06 --> Input Class Initialized
INFO - 2023-09-25 16:49:06 --> Language Class Initialized
INFO - 2023-09-25 16:49:06 --> Loader Class Initialized
INFO - 2023-09-25 16:49:06 --> Helper loaded: url_helper
INFO - 2023-09-25 16:49:06 --> Helper loaded: file_helper
INFO - 2023-09-25 16:49:06 --> Helper loaded: html_helper
INFO - 2023-09-25 16:49:06 --> Helper loaded: text_helper
INFO - 2023-09-25 16:49:06 --> Helper loaded: form_helper
INFO - 2023-09-25 16:49:06 --> Helper loaded: lang_helper
INFO - 2023-09-25 16:49:06 --> Helper loaded: security_helper
INFO - 2023-09-25 16:49:06 --> Helper loaded: cookie_helper
INFO - 2023-09-25 16:49:06 --> Database Driver Class Initialized
INFO - 2023-09-25 16:49:06 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-25 16:49:06 --> Parser Class Initialized
INFO - 2023-09-25 16:49:06 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-25 16:49:06 --> Pagination Class Initialized
INFO - 2023-09-25 16:49:06 --> Form Validation Class Initialized
INFO - 2023-09-25 16:49:06 --> Controller Class Initialized
INFO - 2023-09-25 16:49:06 --> Model Class Initialized
DEBUG - 2023-09-25 16:49:06 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-09-25 16:49:06 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-25 16:49:06 --> Model Class Initialized
DEBUG - 2023-09-25 16:49:06 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-25 16:49:06 --> Model Class Initialized
INFO - 2023-09-25 16:49:06 --> Final output sent to browser
DEBUG - 2023-09-25 16:49:06 --> Total execution time: 0.1146
ERROR - 2023-09-25 16:49:06 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-25 16:49:06 --> Config Class Initialized
INFO - 2023-09-25 16:49:06 --> Hooks Class Initialized
DEBUG - 2023-09-25 16:49:06 --> UTF-8 Support Enabled
INFO - 2023-09-25 16:49:06 --> Utf8 Class Initialized
INFO - 2023-09-25 16:49:06 --> URI Class Initialized
INFO - 2023-09-25 16:49:06 --> Router Class Initialized
INFO - 2023-09-25 16:49:06 --> Output Class Initialized
INFO - 2023-09-25 16:49:06 --> Security Class Initialized
DEBUG - 2023-09-25 16:49:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-25 16:49:06 --> Input Class Initialized
INFO - 2023-09-25 16:49:06 --> Language Class Initialized
INFO - 2023-09-25 16:49:06 --> Loader Class Initialized
INFO - 2023-09-25 16:49:06 --> Helper loaded: url_helper
INFO - 2023-09-25 16:49:06 --> Helper loaded: file_helper
INFO - 2023-09-25 16:49:06 --> Helper loaded: html_helper
INFO - 2023-09-25 16:49:06 --> Helper loaded: text_helper
INFO - 2023-09-25 16:49:06 --> Helper loaded: form_helper
INFO - 2023-09-25 16:49:06 --> Helper loaded: lang_helper
INFO - 2023-09-25 16:49:06 --> Helper loaded: security_helper
INFO - 2023-09-25 16:49:06 --> Helper loaded: cookie_helper
INFO - 2023-09-25 16:49:06 --> Database Driver Class Initialized
INFO - 2023-09-25 16:49:06 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-25 16:49:06 --> Parser Class Initialized
INFO - 2023-09-25 16:49:06 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-25 16:49:06 --> Pagination Class Initialized
INFO - 2023-09-25 16:49:06 --> Form Validation Class Initialized
INFO - 2023-09-25 16:49:06 --> Controller Class Initialized
INFO - 2023-09-25 16:49:06 --> Model Class Initialized
DEBUG - 2023-09-25 16:49:06 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-09-25 16:49:06 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-25 16:49:06 --> Model Class Initialized
DEBUG - 2023-09-25 16:49:06 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-25 16:49:06 --> Model Class Initialized
INFO - 2023-09-25 16:49:06 --> Final output sent to browser
DEBUG - 2023-09-25 16:49:06 --> Total execution time: 0.1124
ERROR - 2023-09-25 16:49:07 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-25 16:49:07 --> Config Class Initialized
INFO - 2023-09-25 16:49:07 --> Hooks Class Initialized
DEBUG - 2023-09-25 16:49:07 --> UTF-8 Support Enabled
INFO - 2023-09-25 16:49:07 --> Utf8 Class Initialized
INFO - 2023-09-25 16:49:07 --> URI Class Initialized
INFO - 2023-09-25 16:49:07 --> Router Class Initialized
INFO - 2023-09-25 16:49:07 --> Output Class Initialized
INFO - 2023-09-25 16:49:07 --> Security Class Initialized
DEBUG - 2023-09-25 16:49:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-25 16:49:07 --> Input Class Initialized
INFO - 2023-09-25 16:49:07 --> Language Class Initialized
INFO - 2023-09-25 16:49:07 --> Loader Class Initialized
INFO - 2023-09-25 16:49:07 --> Helper loaded: url_helper
INFO - 2023-09-25 16:49:07 --> Helper loaded: file_helper
INFO - 2023-09-25 16:49:07 --> Helper loaded: html_helper
INFO - 2023-09-25 16:49:07 --> Helper loaded: text_helper
INFO - 2023-09-25 16:49:07 --> Helper loaded: form_helper
INFO - 2023-09-25 16:49:07 --> Helper loaded: lang_helper
INFO - 2023-09-25 16:49:07 --> Helper loaded: security_helper
INFO - 2023-09-25 16:49:07 --> Helper loaded: cookie_helper
INFO - 2023-09-25 16:49:07 --> Database Driver Class Initialized
INFO - 2023-09-25 16:49:07 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-25 16:49:07 --> Parser Class Initialized
INFO - 2023-09-25 16:49:07 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-25 16:49:07 --> Pagination Class Initialized
INFO - 2023-09-25 16:49:07 --> Form Validation Class Initialized
INFO - 2023-09-25 16:49:07 --> Controller Class Initialized
INFO - 2023-09-25 16:49:07 --> Model Class Initialized
DEBUG - 2023-09-25 16:49:07 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-09-25 16:49:07 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-25 16:49:07 --> Model Class Initialized
DEBUG - 2023-09-25 16:49:07 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-25 16:49:07 --> Model Class Initialized
INFO - 2023-09-25 16:49:07 --> Final output sent to browser
DEBUG - 2023-09-25 16:49:07 --> Total execution time: 0.0321
ERROR - 2023-09-25 16:49:08 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-25 16:49:08 --> Config Class Initialized
INFO - 2023-09-25 16:49:08 --> Hooks Class Initialized
DEBUG - 2023-09-25 16:49:08 --> UTF-8 Support Enabled
INFO - 2023-09-25 16:49:08 --> Utf8 Class Initialized
INFO - 2023-09-25 16:49:08 --> URI Class Initialized
INFO - 2023-09-25 16:49:08 --> Router Class Initialized
INFO - 2023-09-25 16:49:08 --> Output Class Initialized
INFO - 2023-09-25 16:49:08 --> Security Class Initialized
DEBUG - 2023-09-25 16:49:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-25 16:49:08 --> Input Class Initialized
INFO - 2023-09-25 16:49:08 --> Language Class Initialized
INFO - 2023-09-25 16:49:08 --> Loader Class Initialized
INFO - 2023-09-25 16:49:08 --> Helper loaded: url_helper
INFO - 2023-09-25 16:49:08 --> Helper loaded: file_helper
INFO - 2023-09-25 16:49:08 --> Helper loaded: html_helper
INFO - 2023-09-25 16:49:08 --> Helper loaded: text_helper
INFO - 2023-09-25 16:49:08 --> Helper loaded: form_helper
INFO - 2023-09-25 16:49:08 --> Helper loaded: lang_helper
INFO - 2023-09-25 16:49:08 --> Helper loaded: security_helper
INFO - 2023-09-25 16:49:08 --> Helper loaded: cookie_helper
INFO - 2023-09-25 16:49:08 --> Database Driver Class Initialized
INFO - 2023-09-25 16:49:08 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-25 16:49:08 --> Parser Class Initialized
INFO - 2023-09-25 16:49:08 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-25 16:49:08 --> Pagination Class Initialized
INFO - 2023-09-25 16:49:08 --> Form Validation Class Initialized
INFO - 2023-09-25 16:49:08 --> Controller Class Initialized
INFO - 2023-09-25 16:49:08 --> Model Class Initialized
DEBUG - 2023-09-25 16:49:08 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-09-25 16:49:08 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-25 16:49:08 --> Model Class Initialized
DEBUG - 2023-09-25 16:49:08 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-25 16:49:08 --> Model Class Initialized
INFO - 2023-09-25 16:49:08 --> Final output sent to browser
DEBUG - 2023-09-25 16:49:08 --> Total execution time: 0.0359
ERROR - 2023-09-25 16:49:09 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-25 16:49:09 --> Config Class Initialized
INFO - 2023-09-25 16:49:09 --> Hooks Class Initialized
DEBUG - 2023-09-25 16:49:09 --> UTF-8 Support Enabled
INFO - 2023-09-25 16:49:09 --> Utf8 Class Initialized
INFO - 2023-09-25 16:49:09 --> URI Class Initialized
INFO - 2023-09-25 16:49:09 --> Router Class Initialized
INFO - 2023-09-25 16:49:09 --> Output Class Initialized
INFO - 2023-09-25 16:49:09 --> Security Class Initialized
DEBUG - 2023-09-25 16:49:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-25 16:49:09 --> Input Class Initialized
INFO - 2023-09-25 16:49:09 --> Language Class Initialized
INFO - 2023-09-25 16:49:09 --> Loader Class Initialized
INFO - 2023-09-25 16:49:09 --> Helper loaded: url_helper
INFO - 2023-09-25 16:49:09 --> Helper loaded: file_helper
INFO - 2023-09-25 16:49:09 --> Helper loaded: html_helper
INFO - 2023-09-25 16:49:09 --> Helper loaded: text_helper
INFO - 2023-09-25 16:49:09 --> Helper loaded: form_helper
INFO - 2023-09-25 16:49:09 --> Helper loaded: lang_helper
INFO - 2023-09-25 16:49:09 --> Helper loaded: security_helper
INFO - 2023-09-25 16:49:09 --> Helper loaded: cookie_helper
INFO - 2023-09-25 16:49:09 --> Database Driver Class Initialized
INFO - 2023-09-25 16:49:09 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-25 16:49:09 --> Parser Class Initialized
INFO - 2023-09-25 16:49:09 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-25 16:49:09 --> Pagination Class Initialized
INFO - 2023-09-25 16:49:09 --> Form Validation Class Initialized
INFO - 2023-09-25 16:49:09 --> Controller Class Initialized
INFO - 2023-09-25 16:49:09 --> Model Class Initialized
DEBUG - 2023-09-25 16:49:09 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-09-25 16:49:09 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-25 16:49:09 --> Model Class Initialized
INFO - 2023-09-25 16:49:09 --> Model Class Initialized
INFO - 2023-09-25 16:49:09 --> Final output sent to browser
DEBUG - 2023-09-25 16:49:09 --> Total execution time: 0.0216
ERROR - 2023-09-25 16:49:11 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-25 16:49:11 --> Config Class Initialized
INFO - 2023-09-25 16:49:11 --> Hooks Class Initialized
DEBUG - 2023-09-25 16:49:11 --> UTF-8 Support Enabled
INFO - 2023-09-25 16:49:11 --> Utf8 Class Initialized
INFO - 2023-09-25 16:49:11 --> URI Class Initialized
INFO - 2023-09-25 16:49:11 --> Router Class Initialized
INFO - 2023-09-25 16:49:11 --> Output Class Initialized
INFO - 2023-09-25 16:49:11 --> Security Class Initialized
DEBUG - 2023-09-25 16:49:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-25 16:49:11 --> Input Class Initialized
INFO - 2023-09-25 16:49:11 --> Language Class Initialized
INFO - 2023-09-25 16:49:11 --> Loader Class Initialized
INFO - 2023-09-25 16:49:11 --> Helper loaded: url_helper
INFO - 2023-09-25 16:49:11 --> Helper loaded: file_helper
INFO - 2023-09-25 16:49:11 --> Helper loaded: html_helper
INFO - 2023-09-25 16:49:11 --> Helper loaded: text_helper
INFO - 2023-09-25 16:49:11 --> Helper loaded: form_helper
INFO - 2023-09-25 16:49:11 --> Helper loaded: lang_helper
INFO - 2023-09-25 16:49:11 --> Helper loaded: security_helper
INFO - 2023-09-25 16:49:11 --> Helper loaded: cookie_helper
INFO - 2023-09-25 16:49:11 --> Database Driver Class Initialized
INFO - 2023-09-25 16:49:11 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-25 16:49:11 --> Parser Class Initialized
INFO - 2023-09-25 16:49:11 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-25 16:49:11 --> Pagination Class Initialized
INFO - 2023-09-25 16:49:11 --> Form Validation Class Initialized
INFO - 2023-09-25 16:49:11 --> Controller Class Initialized
INFO - 2023-09-25 16:49:11 --> Model Class Initialized
DEBUG - 2023-09-25 16:49:11 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-09-25 16:49:11 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-25 16:49:11 --> Model Class Initialized
INFO - 2023-09-25 16:49:11 --> Final output sent to browser
DEBUG - 2023-09-25 16:49:11 --> Total execution time: 0.0203
ERROR - 2023-09-25 16:49:24 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-25 16:49:24 --> Config Class Initialized
INFO - 2023-09-25 16:49:24 --> Hooks Class Initialized
DEBUG - 2023-09-25 16:49:24 --> UTF-8 Support Enabled
INFO - 2023-09-25 16:49:24 --> Utf8 Class Initialized
INFO - 2023-09-25 16:49:24 --> URI Class Initialized
DEBUG - 2023-09-25 16:49:24 --> No URI present. Default controller set.
INFO - 2023-09-25 16:49:24 --> Router Class Initialized
INFO - 2023-09-25 16:49:24 --> Output Class Initialized
INFO - 2023-09-25 16:49:24 --> Security Class Initialized
DEBUG - 2023-09-25 16:49:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-25 16:49:24 --> Input Class Initialized
INFO - 2023-09-25 16:49:24 --> Language Class Initialized
INFO - 2023-09-25 16:49:24 --> Loader Class Initialized
INFO - 2023-09-25 16:49:24 --> Helper loaded: url_helper
INFO - 2023-09-25 16:49:24 --> Helper loaded: file_helper
INFO - 2023-09-25 16:49:24 --> Helper loaded: html_helper
INFO - 2023-09-25 16:49:24 --> Helper loaded: text_helper
INFO - 2023-09-25 16:49:24 --> Helper loaded: form_helper
INFO - 2023-09-25 16:49:24 --> Helper loaded: lang_helper
INFO - 2023-09-25 16:49:24 --> Helper loaded: security_helper
INFO - 2023-09-25 16:49:24 --> Helper loaded: cookie_helper
INFO - 2023-09-25 16:49:24 --> Database Driver Class Initialized
INFO - 2023-09-25 16:49:24 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-25 16:49:24 --> Parser Class Initialized
INFO - 2023-09-25 16:49:24 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-25 16:49:24 --> Pagination Class Initialized
INFO - 2023-09-25 16:49:24 --> Form Validation Class Initialized
INFO - 2023-09-25 16:49:24 --> Controller Class Initialized
INFO - 2023-09-25 16:49:24 --> Model Class Initialized
DEBUG - 2023-09-25 16:49:24 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-25 16:49:24 --> Model Class Initialized
DEBUG - 2023-09-25 16:49:24 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-25 16:49:24 --> Model Class Initialized
INFO - 2023-09-25 16:49:24 --> Model Class Initialized
INFO - 2023-09-25 16:49:24 --> Model Class Initialized
INFO - 2023-09-25 16:49:24 --> Model Class Initialized
DEBUG - 2023-09-25 16:49:24 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-09-25 16:49:24 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-25 16:49:24 --> Model Class Initialized
INFO - 2023-09-25 16:49:24 --> Model Class Initialized
INFO - 2023-09-25 16:49:24 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-09-25 16:49:24 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-09-25 16:49:24 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-09-25 16:49:24 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-09-25 16:49:24 --> Model Class Initialized
INFO - 2023-09-25 16:49:24 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-09-25 16:49:24 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-09-25 16:49:24 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-09-25 16:49:24 --> Final output sent to browser
DEBUG - 2023-09-25 16:49:24 --> Total execution time: 0.2260
ERROR - 2023-09-25 16:49:40 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-25 16:49:40 --> Config Class Initialized
INFO - 2023-09-25 16:49:40 --> Hooks Class Initialized
DEBUG - 2023-09-25 16:49:40 --> UTF-8 Support Enabled
INFO - 2023-09-25 16:49:40 --> Utf8 Class Initialized
INFO - 2023-09-25 16:49:40 --> URI Class Initialized
INFO - 2023-09-25 16:49:40 --> Router Class Initialized
INFO - 2023-09-25 16:49:40 --> Output Class Initialized
INFO - 2023-09-25 16:49:40 --> Security Class Initialized
DEBUG - 2023-09-25 16:49:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-25 16:49:40 --> Input Class Initialized
INFO - 2023-09-25 16:49:40 --> Language Class Initialized
INFO - 2023-09-25 16:49:40 --> Loader Class Initialized
INFO - 2023-09-25 16:49:40 --> Helper loaded: url_helper
INFO - 2023-09-25 16:49:40 --> Helper loaded: file_helper
INFO - 2023-09-25 16:49:40 --> Helper loaded: html_helper
INFO - 2023-09-25 16:49:40 --> Helper loaded: text_helper
INFO - 2023-09-25 16:49:40 --> Helper loaded: form_helper
INFO - 2023-09-25 16:49:40 --> Helper loaded: lang_helper
INFO - 2023-09-25 16:49:40 --> Helper loaded: security_helper
INFO - 2023-09-25 16:49:40 --> Helper loaded: cookie_helper
INFO - 2023-09-25 16:49:40 --> Database Driver Class Initialized
INFO - 2023-09-25 16:49:40 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-25 16:49:40 --> Parser Class Initialized
INFO - 2023-09-25 16:49:40 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-25 16:49:40 --> Pagination Class Initialized
INFO - 2023-09-25 16:49:40 --> Form Validation Class Initialized
INFO - 2023-09-25 16:49:40 --> Controller Class Initialized
INFO - 2023-09-25 16:49:40 --> Model Class Initialized
INFO - 2023-09-25 16:49:40 --> Model Class Initialized
INFO - 2023-09-25 16:49:40 --> Model Class Initialized
INFO - 2023-09-25 16:49:40 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/report/stock_report_batch_wise.php
DEBUG - 2023-09-25 16:49:40 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-09-25 16:49:40 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-09-25 16:49:40 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-09-25 16:49:40 --> Model Class Initialized
INFO - 2023-09-25 16:49:40 --> Model Class Initialized
INFO - 2023-09-25 16:49:40 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-09-25 16:49:40 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-09-25 16:49:40 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-09-25 16:49:40 --> Final output sent to browser
DEBUG - 2023-09-25 16:49:40 --> Total execution time: 0.1665
ERROR - 2023-09-25 16:49:40 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-25 16:49:40 --> Config Class Initialized
INFO - 2023-09-25 16:49:40 --> Hooks Class Initialized
DEBUG - 2023-09-25 16:49:40 --> UTF-8 Support Enabled
INFO - 2023-09-25 16:49:40 --> Utf8 Class Initialized
INFO - 2023-09-25 16:49:40 --> URI Class Initialized
INFO - 2023-09-25 16:49:40 --> Router Class Initialized
INFO - 2023-09-25 16:49:40 --> Output Class Initialized
INFO - 2023-09-25 16:49:40 --> Security Class Initialized
DEBUG - 2023-09-25 16:49:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-25 16:49:40 --> Input Class Initialized
INFO - 2023-09-25 16:49:40 --> Language Class Initialized
INFO - 2023-09-25 16:49:40 --> Loader Class Initialized
INFO - 2023-09-25 16:49:40 --> Helper loaded: url_helper
INFO - 2023-09-25 16:49:40 --> Helper loaded: file_helper
INFO - 2023-09-25 16:49:40 --> Helper loaded: html_helper
INFO - 2023-09-25 16:49:40 --> Helper loaded: text_helper
INFO - 2023-09-25 16:49:40 --> Helper loaded: form_helper
INFO - 2023-09-25 16:49:40 --> Helper loaded: lang_helper
INFO - 2023-09-25 16:49:40 --> Helper loaded: security_helper
INFO - 2023-09-25 16:49:41 --> Helper loaded: cookie_helper
INFO - 2023-09-25 16:49:41 --> Database Driver Class Initialized
INFO - 2023-09-25 16:49:41 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-25 16:49:41 --> Parser Class Initialized
INFO - 2023-09-25 16:49:41 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-25 16:49:41 --> Pagination Class Initialized
INFO - 2023-09-25 16:49:41 --> Form Validation Class Initialized
INFO - 2023-09-25 16:49:41 --> Controller Class Initialized
INFO - 2023-09-25 16:49:41 --> Model Class Initialized
INFO - 2023-09-25 16:49:41 --> Model Class Initialized
INFO - 2023-09-25 16:49:41 --> Final output sent to browser
DEBUG - 2023-09-25 16:49:41 --> Total execution time: 0.0265
ERROR - 2023-09-25 16:49:45 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-25 16:49:45 --> Config Class Initialized
INFO - 2023-09-25 16:49:45 --> Hooks Class Initialized
DEBUG - 2023-09-25 16:49:45 --> UTF-8 Support Enabled
INFO - 2023-09-25 16:49:45 --> Utf8 Class Initialized
INFO - 2023-09-25 16:49:45 --> URI Class Initialized
INFO - 2023-09-25 16:49:45 --> Router Class Initialized
INFO - 2023-09-25 16:49:45 --> Output Class Initialized
INFO - 2023-09-25 16:49:45 --> Security Class Initialized
DEBUG - 2023-09-25 16:49:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-25 16:49:45 --> Input Class Initialized
INFO - 2023-09-25 16:49:45 --> Language Class Initialized
INFO - 2023-09-25 16:49:45 --> Loader Class Initialized
INFO - 2023-09-25 16:49:45 --> Helper loaded: url_helper
INFO - 2023-09-25 16:49:45 --> Helper loaded: file_helper
INFO - 2023-09-25 16:49:45 --> Helper loaded: html_helper
INFO - 2023-09-25 16:49:45 --> Helper loaded: text_helper
INFO - 2023-09-25 16:49:45 --> Helper loaded: form_helper
INFO - 2023-09-25 16:49:45 --> Helper loaded: lang_helper
INFO - 2023-09-25 16:49:45 --> Helper loaded: security_helper
INFO - 2023-09-25 16:49:45 --> Helper loaded: cookie_helper
INFO - 2023-09-25 16:49:45 --> Database Driver Class Initialized
INFO - 2023-09-25 16:49:45 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-25 16:49:45 --> Parser Class Initialized
INFO - 2023-09-25 16:49:45 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-25 16:49:45 --> Pagination Class Initialized
INFO - 2023-09-25 16:49:45 --> Form Validation Class Initialized
INFO - 2023-09-25 16:49:45 --> Controller Class Initialized
DEBUG - 2023-09-25 16:49:45 --> Auth class already loaded. Second attempt ignored.
INFO - 2023-09-25 16:49:45 --> Model Class Initialized
INFO - 2023-09-25 16:49:45 --> Model Class Initialized
INFO - 2023-09-25 16:49:45 --> Model Class Initialized
INFO - 2023-09-25 16:49:45 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/product/product_details.php
DEBUG - 2023-09-25 16:49:45 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-09-25 16:49:45 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-09-25 16:49:45 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-09-25 16:49:45 --> Model Class Initialized
INFO - 2023-09-25 16:49:45 --> Model Class Initialized
INFO - 2023-09-25 16:49:45 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-09-25 16:49:45 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-09-25 16:49:45 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-09-25 16:49:45 --> Final output sent to browser
DEBUG - 2023-09-25 16:49:45 --> Total execution time: 0.1809
ERROR - 2023-09-25 16:51:28 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-25 16:51:28 --> Config Class Initialized
INFO - 2023-09-25 16:51:28 --> Hooks Class Initialized
DEBUG - 2023-09-25 16:51:28 --> UTF-8 Support Enabled
INFO - 2023-09-25 16:51:28 --> Utf8 Class Initialized
INFO - 2023-09-25 16:51:28 --> URI Class Initialized
DEBUG - 2023-09-25 16:51:28 --> No URI present. Default controller set.
INFO - 2023-09-25 16:51:28 --> Router Class Initialized
INFO - 2023-09-25 16:51:28 --> Output Class Initialized
INFO - 2023-09-25 16:51:28 --> Security Class Initialized
DEBUG - 2023-09-25 16:51:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-25 16:51:28 --> Input Class Initialized
INFO - 2023-09-25 16:51:28 --> Language Class Initialized
INFO - 2023-09-25 16:51:28 --> Loader Class Initialized
INFO - 2023-09-25 16:51:28 --> Helper loaded: url_helper
INFO - 2023-09-25 16:51:28 --> Helper loaded: file_helper
INFO - 2023-09-25 16:51:28 --> Helper loaded: html_helper
INFO - 2023-09-25 16:51:28 --> Helper loaded: text_helper
INFO - 2023-09-25 16:51:28 --> Helper loaded: form_helper
INFO - 2023-09-25 16:51:28 --> Helper loaded: lang_helper
INFO - 2023-09-25 16:51:28 --> Helper loaded: security_helper
INFO - 2023-09-25 16:51:28 --> Helper loaded: cookie_helper
INFO - 2023-09-25 16:51:28 --> Database Driver Class Initialized
INFO - 2023-09-25 16:51:28 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-25 16:51:28 --> Parser Class Initialized
INFO - 2023-09-25 16:51:28 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-25 16:51:28 --> Pagination Class Initialized
INFO - 2023-09-25 16:51:28 --> Form Validation Class Initialized
INFO - 2023-09-25 16:51:28 --> Controller Class Initialized
INFO - 2023-09-25 16:51:28 --> Model Class Initialized
DEBUG - 2023-09-25 16:51:28 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-25 16:51:28 --> Model Class Initialized
DEBUG - 2023-09-25 16:51:28 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-25 16:51:28 --> Model Class Initialized
INFO - 2023-09-25 16:51:28 --> Model Class Initialized
INFO - 2023-09-25 16:51:28 --> Model Class Initialized
INFO - 2023-09-25 16:51:28 --> Model Class Initialized
DEBUG - 2023-09-25 16:51:28 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-09-25 16:51:28 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-25 16:51:28 --> Model Class Initialized
INFO - 2023-09-25 16:51:28 --> Model Class Initialized
INFO - 2023-09-25 16:51:28 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-09-25 16:51:28 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-09-25 16:51:28 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-09-25 16:51:28 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-09-25 16:51:28 --> Model Class Initialized
INFO - 2023-09-25 16:51:28 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-09-25 16:51:28 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-09-25 16:51:28 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-09-25 16:51:28 --> Final output sent to browser
DEBUG - 2023-09-25 16:51:28 --> Total execution time: 0.1161
ERROR - 2023-09-25 16:58:42 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-25 16:58:42 --> Config Class Initialized
INFO - 2023-09-25 16:58:42 --> Hooks Class Initialized
DEBUG - 2023-09-25 16:58:42 --> UTF-8 Support Enabled
INFO - 2023-09-25 16:58:42 --> Utf8 Class Initialized
INFO - 2023-09-25 16:58:42 --> URI Class Initialized
DEBUG - 2023-09-25 16:58:42 --> No URI present. Default controller set.
INFO - 2023-09-25 16:58:42 --> Router Class Initialized
INFO - 2023-09-25 16:58:42 --> Output Class Initialized
INFO - 2023-09-25 16:58:42 --> Security Class Initialized
DEBUG - 2023-09-25 16:58:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-25 16:58:42 --> Input Class Initialized
INFO - 2023-09-25 16:58:42 --> Language Class Initialized
INFO - 2023-09-25 16:58:42 --> Loader Class Initialized
INFO - 2023-09-25 16:58:42 --> Helper loaded: url_helper
INFO - 2023-09-25 16:58:42 --> Helper loaded: file_helper
INFO - 2023-09-25 16:58:42 --> Helper loaded: html_helper
INFO - 2023-09-25 16:58:42 --> Helper loaded: text_helper
INFO - 2023-09-25 16:58:42 --> Helper loaded: form_helper
INFO - 2023-09-25 16:58:42 --> Helper loaded: lang_helper
INFO - 2023-09-25 16:58:42 --> Helper loaded: security_helper
INFO - 2023-09-25 16:58:42 --> Helper loaded: cookie_helper
INFO - 2023-09-25 16:58:42 --> Database Driver Class Initialized
INFO - 2023-09-25 16:58:42 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-25 16:58:42 --> Parser Class Initialized
INFO - 2023-09-25 16:58:42 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-25 16:58:42 --> Pagination Class Initialized
INFO - 2023-09-25 16:58:42 --> Form Validation Class Initialized
INFO - 2023-09-25 16:58:42 --> Controller Class Initialized
INFO - 2023-09-25 16:58:42 --> Model Class Initialized
DEBUG - 2023-09-25 16:58:42 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-25 16:58:42 --> Model Class Initialized
DEBUG - 2023-09-25 16:58:42 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-25 16:58:42 --> Model Class Initialized
INFO - 2023-09-25 16:58:42 --> Model Class Initialized
INFO - 2023-09-25 16:58:42 --> Model Class Initialized
INFO - 2023-09-25 16:58:42 --> Model Class Initialized
DEBUG - 2023-09-25 16:58:42 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-09-25 16:58:42 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-25 16:58:42 --> Model Class Initialized
INFO - 2023-09-25 16:58:42 --> Model Class Initialized
INFO - 2023-09-25 16:58:42 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-09-25 16:58:42 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-09-25 16:58:42 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-09-25 16:58:42 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-09-25 16:58:42 --> Model Class Initialized
INFO - 2023-09-25 16:58:43 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-09-25 16:58:43 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-09-25 16:58:43 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-09-25 16:58:43 --> Final output sent to browser
DEBUG - 2023-09-25 16:58:43 --> Total execution time: 0.1059
ERROR - 2023-09-25 16:58:55 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-25 16:58:55 --> Config Class Initialized
INFO - 2023-09-25 16:58:55 --> Hooks Class Initialized
DEBUG - 2023-09-25 16:58:55 --> UTF-8 Support Enabled
INFO - 2023-09-25 16:58:55 --> Utf8 Class Initialized
INFO - 2023-09-25 16:58:55 --> URI Class Initialized
INFO - 2023-09-25 16:58:55 --> Router Class Initialized
INFO - 2023-09-25 16:58:55 --> Output Class Initialized
INFO - 2023-09-25 16:58:55 --> Security Class Initialized
DEBUG - 2023-09-25 16:58:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-25 16:58:55 --> Input Class Initialized
INFO - 2023-09-25 16:58:55 --> Language Class Initialized
INFO - 2023-09-25 16:58:55 --> Loader Class Initialized
INFO - 2023-09-25 16:58:55 --> Helper loaded: url_helper
INFO - 2023-09-25 16:58:55 --> Helper loaded: file_helper
INFO - 2023-09-25 16:58:55 --> Helper loaded: html_helper
INFO - 2023-09-25 16:58:55 --> Helper loaded: text_helper
INFO - 2023-09-25 16:58:55 --> Helper loaded: form_helper
INFO - 2023-09-25 16:58:55 --> Helper loaded: lang_helper
INFO - 2023-09-25 16:58:55 --> Helper loaded: security_helper
INFO - 2023-09-25 16:58:55 --> Helper loaded: cookie_helper
INFO - 2023-09-25 16:58:55 --> Database Driver Class Initialized
INFO - 2023-09-25 16:58:55 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-25 16:58:55 --> Parser Class Initialized
INFO - 2023-09-25 16:58:55 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-25 16:58:55 --> Pagination Class Initialized
INFO - 2023-09-25 16:58:55 --> Form Validation Class Initialized
INFO - 2023-09-25 16:58:55 --> Controller Class Initialized
INFO - 2023-09-25 16:58:55 --> Model Class Initialized
DEBUG - 2023-09-25 16:58:55 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-09-25 16:58:55 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-25 16:58:55 --> Model Class Initialized
INFO - 2023-09-25 16:58:55 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/stockrequest/inventory.php
DEBUG - 2023-09-25 16:58:55 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-09-25 16:58:55 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-09-25 16:58:55 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-09-25 16:58:55 --> Model Class Initialized
INFO - 2023-09-25 16:58:55 --> Model Class Initialized
INFO - 2023-09-25 16:58:55 --> Model Class Initialized
INFO - 2023-09-25 16:58:55 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-09-25 16:58:55 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-09-25 16:58:55 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-09-25 16:58:55 --> Final output sent to browser
DEBUG - 2023-09-25 16:58:55 --> Total execution time: 0.0794
ERROR - 2023-09-25 16:58:56 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-25 16:58:56 --> Config Class Initialized
INFO - 2023-09-25 16:58:56 --> Hooks Class Initialized
DEBUG - 2023-09-25 16:58:56 --> UTF-8 Support Enabled
INFO - 2023-09-25 16:58:56 --> Utf8 Class Initialized
INFO - 2023-09-25 16:58:56 --> URI Class Initialized
INFO - 2023-09-25 16:58:56 --> Router Class Initialized
INFO - 2023-09-25 16:58:56 --> Output Class Initialized
INFO - 2023-09-25 16:58:56 --> Security Class Initialized
DEBUG - 2023-09-25 16:58:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-25 16:58:56 --> Input Class Initialized
INFO - 2023-09-25 16:58:56 --> Language Class Initialized
INFO - 2023-09-25 16:58:56 --> Loader Class Initialized
INFO - 2023-09-25 16:58:56 --> Helper loaded: url_helper
INFO - 2023-09-25 16:58:56 --> Helper loaded: file_helper
INFO - 2023-09-25 16:58:56 --> Helper loaded: html_helper
INFO - 2023-09-25 16:58:56 --> Helper loaded: text_helper
INFO - 2023-09-25 16:58:56 --> Helper loaded: form_helper
INFO - 2023-09-25 16:58:56 --> Helper loaded: lang_helper
INFO - 2023-09-25 16:58:56 --> Helper loaded: security_helper
INFO - 2023-09-25 16:58:56 --> Helper loaded: cookie_helper
INFO - 2023-09-25 16:58:56 --> Database Driver Class Initialized
INFO - 2023-09-25 16:58:56 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-25 16:58:56 --> Parser Class Initialized
INFO - 2023-09-25 16:58:56 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-25 16:58:56 --> Pagination Class Initialized
INFO - 2023-09-25 16:58:56 --> Form Validation Class Initialized
INFO - 2023-09-25 16:58:56 --> Controller Class Initialized
INFO - 2023-09-25 16:58:56 --> Model Class Initialized
DEBUG - 2023-09-25 16:58:56 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-09-25 16:58:56 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-25 16:58:56 --> Model Class Initialized
INFO - 2023-09-25 16:58:56 --> Final output sent to browser
DEBUG - 2023-09-25 16:58:56 --> Total execution time: 0.0344
ERROR - 2023-09-25 16:59:00 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-25 16:59:00 --> Config Class Initialized
INFO - 2023-09-25 16:59:00 --> Hooks Class Initialized
DEBUG - 2023-09-25 16:59:00 --> UTF-8 Support Enabled
INFO - 2023-09-25 16:59:00 --> Utf8 Class Initialized
INFO - 2023-09-25 16:59:00 --> URI Class Initialized
INFO - 2023-09-25 16:59:00 --> Router Class Initialized
INFO - 2023-09-25 16:59:00 --> Output Class Initialized
INFO - 2023-09-25 16:59:00 --> Security Class Initialized
DEBUG - 2023-09-25 16:59:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-25 16:59:00 --> Input Class Initialized
INFO - 2023-09-25 16:59:00 --> Language Class Initialized
INFO - 2023-09-25 16:59:00 --> Loader Class Initialized
INFO - 2023-09-25 16:59:00 --> Helper loaded: url_helper
INFO - 2023-09-25 16:59:00 --> Helper loaded: file_helper
INFO - 2023-09-25 16:59:00 --> Helper loaded: html_helper
INFO - 2023-09-25 16:59:00 --> Helper loaded: text_helper
INFO - 2023-09-25 16:59:00 --> Helper loaded: form_helper
INFO - 2023-09-25 16:59:00 --> Helper loaded: lang_helper
INFO - 2023-09-25 16:59:00 --> Helper loaded: security_helper
INFO - 2023-09-25 16:59:00 --> Helper loaded: cookie_helper
INFO - 2023-09-25 16:59:00 --> Database Driver Class Initialized
INFO - 2023-09-25 16:59:00 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-25 16:59:00 --> Parser Class Initialized
INFO - 2023-09-25 16:59:00 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-25 16:59:00 --> Pagination Class Initialized
INFO - 2023-09-25 16:59:00 --> Form Validation Class Initialized
INFO - 2023-09-25 16:59:00 --> Controller Class Initialized
INFO - 2023-09-25 16:59:00 --> Model Class Initialized
DEBUG - 2023-09-25 16:59:00 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-09-25 16:59:00 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-25 16:59:00 --> Model Class Initialized
INFO - 2023-09-25 16:59:01 --> Final output sent to browser
DEBUG - 2023-09-25 16:59:01 --> Total execution time: 0.0344
ERROR - 2023-09-25 16:59:36 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-25 16:59:36 --> Config Class Initialized
INFO - 2023-09-25 16:59:36 --> Hooks Class Initialized
DEBUG - 2023-09-25 16:59:36 --> UTF-8 Support Enabled
INFO - 2023-09-25 16:59:36 --> Utf8 Class Initialized
INFO - 2023-09-25 16:59:36 --> URI Class Initialized
DEBUG - 2023-09-25 16:59:36 --> No URI present. Default controller set.
INFO - 2023-09-25 16:59:36 --> Router Class Initialized
INFO - 2023-09-25 16:59:36 --> Output Class Initialized
INFO - 2023-09-25 16:59:36 --> Security Class Initialized
DEBUG - 2023-09-25 16:59:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-25 16:59:36 --> Input Class Initialized
INFO - 2023-09-25 16:59:36 --> Language Class Initialized
INFO - 2023-09-25 16:59:36 --> Loader Class Initialized
INFO - 2023-09-25 16:59:36 --> Helper loaded: url_helper
INFO - 2023-09-25 16:59:36 --> Helper loaded: file_helper
INFO - 2023-09-25 16:59:36 --> Helper loaded: html_helper
INFO - 2023-09-25 16:59:36 --> Helper loaded: text_helper
INFO - 2023-09-25 16:59:36 --> Helper loaded: form_helper
INFO - 2023-09-25 16:59:36 --> Helper loaded: lang_helper
INFO - 2023-09-25 16:59:36 --> Helper loaded: security_helper
INFO - 2023-09-25 16:59:36 --> Helper loaded: cookie_helper
INFO - 2023-09-25 16:59:36 --> Database Driver Class Initialized
INFO - 2023-09-25 16:59:36 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-25 16:59:36 --> Parser Class Initialized
INFO - 2023-09-25 16:59:36 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-25 16:59:36 --> Pagination Class Initialized
INFO - 2023-09-25 16:59:36 --> Form Validation Class Initialized
INFO - 2023-09-25 16:59:36 --> Controller Class Initialized
INFO - 2023-09-25 16:59:36 --> Model Class Initialized
DEBUG - 2023-09-25 16:59:36 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-25 16:59:36 --> Model Class Initialized
DEBUG - 2023-09-25 16:59:36 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-25 16:59:36 --> Model Class Initialized
INFO - 2023-09-25 16:59:36 --> Model Class Initialized
INFO - 2023-09-25 16:59:36 --> Model Class Initialized
INFO - 2023-09-25 16:59:36 --> Model Class Initialized
DEBUG - 2023-09-25 16:59:36 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-09-25 16:59:36 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-25 16:59:36 --> Model Class Initialized
INFO - 2023-09-25 16:59:36 --> Model Class Initialized
INFO - 2023-09-25 16:59:36 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-09-25 16:59:36 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-09-25 16:59:36 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-09-25 16:59:36 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-09-25 16:59:36 --> Model Class Initialized
INFO - 2023-09-25 16:59:36 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-09-25 16:59:36 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-09-25 16:59:36 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-09-25 16:59:36 --> Final output sent to browser
DEBUG - 2023-09-25 16:59:36 --> Total execution time: 0.1000
ERROR - 2023-09-25 16:59:45 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-25 16:59:45 --> Config Class Initialized
INFO - 2023-09-25 16:59:45 --> Hooks Class Initialized
DEBUG - 2023-09-25 16:59:45 --> UTF-8 Support Enabled
INFO - 2023-09-25 16:59:45 --> Utf8 Class Initialized
INFO - 2023-09-25 16:59:45 --> URI Class Initialized
INFO - 2023-09-25 16:59:45 --> Router Class Initialized
INFO - 2023-09-25 16:59:45 --> Output Class Initialized
INFO - 2023-09-25 16:59:45 --> Security Class Initialized
DEBUG - 2023-09-25 16:59:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-25 16:59:45 --> Input Class Initialized
INFO - 2023-09-25 16:59:45 --> Language Class Initialized
INFO - 2023-09-25 16:59:45 --> Loader Class Initialized
INFO - 2023-09-25 16:59:45 --> Helper loaded: url_helper
INFO - 2023-09-25 16:59:45 --> Helper loaded: file_helper
INFO - 2023-09-25 16:59:45 --> Helper loaded: html_helper
INFO - 2023-09-25 16:59:45 --> Helper loaded: text_helper
INFO - 2023-09-25 16:59:45 --> Helper loaded: form_helper
INFO - 2023-09-25 16:59:45 --> Helper loaded: lang_helper
INFO - 2023-09-25 16:59:45 --> Helper loaded: security_helper
INFO - 2023-09-25 16:59:45 --> Helper loaded: cookie_helper
INFO - 2023-09-25 16:59:45 --> Database Driver Class Initialized
INFO - 2023-09-25 16:59:45 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-25 16:59:45 --> Parser Class Initialized
INFO - 2023-09-25 16:59:45 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-25 16:59:45 --> Pagination Class Initialized
INFO - 2023-09-25 16:59:45 --> Form Validation Class Initialized
INFO - 2023-09-25 16:59:45 --> Controller Class Initialized
DEBUG - 2023-09-25 16:59:45 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-09-25 16:59:45 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-25 16:59:45 --> Model Class Initialized
DEBUG - 2023-09-25 16:59:45 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-25 16:59:45 --> Model Class Initialized
DEBUG - 2023-09-25 16:59:45 --> Lcustomer class already loaded. Second attempt ignored.
INFO - 2023-09-25 16:59:45 --> Model Class Initialized
INFO - 2023-09-25 16:59:45 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/customer/customer.php
DEBUG - 2023-09-25 16:59:45 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-09-25 16:59:45 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-09-25 16:59:45 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-09-25 16:59:45 --> Model Class Initialized
INFO - 2023-09-25 16:59:45 --> Model Class Initialized
INFO - 2023-09-25 16:59:45 --> Model Class Initialized
INFO - 2023-09-25 16:59:45 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-09-25 16:59:45 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-09-25 16:59:45 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-09-25 16:59:45 --> Final output sent to browser
DEBUG - 2023-09-25 16:59:45 --> Total execution time: 0.0782
ERROR - 2023-09-25 16:59:46 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-25 16:59:46 --> Config Class Initialized
INFO - 2023-09-25 16:59:46 --> Hooks Class Initialized
DEBUG - 2023-09-25 16:59:46 --> UTF-8 Support Enabled
INFO - 2023-09-25 16:59:46 --> Utf8 Class Initialized
INFO - 2023-09-25 16:59:46 --> URI Class Initialized
INFO - 2023-09-25 16:59:46 --> Router Class Initialized
INFO - 2023-09-25 16:59:46 --> Output Class Initialized
INFO - 2023-09-25 16:59:46 --> Security Class Initialized
DEBUG - 2023-09-25 16:59:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-25 16:59:46 --> Input Class Initialized
INFO - 2023-09-25 16:59:46 --> Language Class Initialized
INFO - 2023-09-25 16:59:46 --> Loader Class Initialized
INFO - 2023-09-25 16:59:46 --> Helper loaded: url_helper
INFO - 2023-09-25 16:59:46 --> Helper loaded: file_helper
INFO - 2023-09-25 16:59:46 --> Helper loaded: html_helper
INFO - 2023-09-25 16:59:46 --> Helper loaded: text_helper
INFO - 2023-09-25 16:59:46 --> Helper loaded: form_helper
INFO - 2023-09-25 16:59:46 --> Helper loaded: lang_helper
INFO - 2023-09-25 16:59:46 --> Helper loaded: security_helper
INFO - 2023-09-25 16:59:46 --> Helper loaded: cookie_helper
INFO - 2023-09-25 16:59:46 --> Database Driver Class Initialized
INFO - 2023-09-25 16:59:46 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-25 16:59:46 --> Parser Class Initialized
INFO - 2023-09-25 16:59:46 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-25 16:59:46 --> Pagination Class Initialized
INFO - 2023-09-25 16:59:46 --> Form Validation Class Initialized
INFO - 2023-09-25 16:59:46 --> Controller Class Initialized
DEBUG - 2023-09-25 16:59:46 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-09-25 16:59:46 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-25 16:59:46 --> Model Class Initialized
DEBUG - 2023-09-25 16:59:46 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-25 16:59:46 --> Model Class Initialized
INFO - 2023-09-25 16:59:46 --> Final output sent to browser
DEBUG - 2023-09-25 16:59:46 --> Total execution time: 0.0206
ERROR - 2023-09-25 16:59:50 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-25 16:59:50 --> Config Class Initialized
INFO - 2023-09-25 16:59:50 --> Hooks Class Initialized
DEBUG - 2023-09-25 16:59:50 --> UTF-8 Support Enabled
INFO - 2023-09-25 16:59:50 --> Utf8 Class Initialized
INFO - 2023-09-25 16:59:50 --> URI Class Initialized
INFO - 2023-09-25 16:59:50 --> Router Class Initialized
INFO - 2023-09-25 16:59:50 --> Output Class Initialized
INFO - 2023-09-25 16:59:50 --> Security Class Initialized
DEBUG - 2023-09-25 16:59:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-25 16:59:50 --> Input Class Initialized
INFO - 2023-09-25 16:59:50 --> Language Class Initialized
INFO - 2023-09-25 16:59:50 --> Loader Class Initialized
INFO - 2023-09-25 16:59:50 --> Helper loaded: url_helper
INFO - 2023-09-25 16:59:50 --> Helper loaded: file_helper
INFO - 2023-09-25 16:59:50 --> Helper loaded: html_helper
INFO - 2023-09-25 16:59:50 --> Helper loaded: text_helper
INFO - 2023-09-25 16:59:50 --> Helper loaded: form_helper
INFO - 2023-09-25 16:59:50 --> Helper loaded: lang_helper
INFO - 2023-09-25 16:59:50 --> Helper loaded: security_helper
INFO - 2023-09-25 16:59:50 --> Helper loaded: cookie_helper
INFO - 2023-09-25 16:59:50 --> Database Driver Class Initialized
INFO - 2023-09-25 16:59:50 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-25 16:59:50 --> Parser Class Initialized
INFO - 2023-09-25 16:59:50 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-25 16:59:50 --> Pagination Class Initialized
INFO - 2023-09-25 16:59:50 --> Form Validation Class Initialized
INFO - 2023-09-25 16:59:50 --> Controller Class Initialized
DEBUG - 2023-09-25 16:59:50 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-09-25 16:59:50 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-25 16:59:50 --> Model Class Initialized
DEBUG - 2023-09-25 16:59:50 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-25 16:59:50 --> Model Class Initialized
INFO - 2023-09-25 16:59:50 --> Final output sent to browser
DEBUG - 2023-09-25 16:59:50 --> Total execution time: 0.0359
ERROR - 2023-09-25 17:01:41 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-25 17:01:41 --> Config Class Initialized
INFO - 2023-09-25 17:01:41 --> Hooks Class Initialized
DEBUG - 2023-09-25 17:01:41 --> UTF-8 Support Enabled
INFO - 2023-09-25 17:01:41 --> Utf8 Class Initialized
INFO - 2023-09-25 17:01:41 --> URI Class Initialized
INFO - 2023-09-25 17:01:41 --> Router Class Initialized
INFO - 2023-09-25 17:01:41 --> Output Class Initialized
INFO - 2023-09-25 17:01:41 --> Security Class Initialized
DEBUG - 2023-09-25 17:01:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-25 17:01:41 --> Input Class Initialized
INFO - 2023-09-25 17:01:41 --> Language Class Initialized
INFO - 2023-09-25 17:01:41 --> Loader Class Initialized
INFO - 2023-09-25 17:01:41 --> Helper loaded: url_helper
INFO - 2023-09-25 17:01:41 --> Helper loaded: file_helper
INFO - 2023-09-25 17:01:41 --> Helper loaded: html_helper
INFO - 2023-09-25 17:01:41 --> Helper loaded: text_helper
INFO - 2023-09-25 17:01:41 --> Helper loaded: form_helper
INFO - 2023-09-25 17:01:41 --> Helper loaded: lang_helper
INFO - 2023-09-25 17:01:41 --> Helper loaded: security_helper
INFO - 2023-09-25 17:01:41 --> Helper loaded: cookie_helper
INFO - 2023-09-25 17:01:41 --> Database Driver Class Initialized
INFO - 2023-09-25 17:01:41 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-25 17:01:41 --> Parser Class Initialized
INFO - 2023-09-25 17:01:41 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-25 17:01:41 --> Pagination Class Initialized
INFO - 2023-09-25 17:01:41 --> Form Validation Class Initialized
INFO - 2023-09-25 17:01:41 --> Controller Class Initialized
INFO - 2023-09-25 17:01:41 --> Model Class Initialized
DEBUG - 2023-09-25 17:01:41 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-09-25 17:01:41 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-25 17:01:41 --> Model Class Initialized
DEBUG - 2023-09-25 17:01:41 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-25 17:01:41 --> Model Class Initialized
INFO - 2023-09-25 17:01:41 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice.php
DEBUG - 2023-09-25 17:01:41 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-09-25 17:01:41 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-09-25 17:01:41 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-09-25 17:01:41 --> Model Class Initialized
INFO - 2023-09-25 17:01:41 --> Model Class Initialized
INFO - 2023-09-25 17:01:41 --> Model Class Initialized
INFO - 2023-09-25 17:01:41 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-09-25 17:01:41 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-09-25 17:01:41 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-09-25 17:01:41 --> Final output sent to browser
DEBUG - 2023-09-25 17:01:41 --> Total execution time: 0.1630
ERROR - 2023-09-25 17:01:42 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-25 17:01:42 --> Config Class Initialized
INFO - 2023-09-25 17:01:42 --> Hooks Class Initialized
DEBUG - 2023-09-25 17:01:42 --> UTF-8 Support Enabled
INFO - 2023-09-25 17:01:42 --> Utf8 Class Initialized
INFO - 2023-09-25 17:01:42 --> URI Class Initialized
INFO - 2023-09-25 17:01:42 --> Router Class Initialized
INFO - 2023-09-25 17:01:42 --> Output Class Initialized
INFO - 2023-09-25 17:01:42 --> Security Class Initialized
DEBUG - 2023-09-25 17:01:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-25 17:01:42 --> Input Class Initialized
INFO - 2023-09-25 17:01:42 --> Language Class Initialized
INFO - 2023-09-25 17:01:42 --> Loader Class Initialized
INFO - 2023-09-25 17:01:42 --> Helper loaded: url_helper
INFO - 2023-09-25 17:01:42 --> Helper loaded: file_helper
INFO - 2023-09-25 17:01:42 --> Helper loaded: html_helper
INFO - 2023-09-25 17:01:42 --> Helper loaded: text_helper
INFO - 2023-09-25 17:01:42 --> Helper loaded: form_helper
INFO - 2023-09-25 17:01:42 --> Helper loaded: lang_helper
INFO - 2023-09-25 17:01:42 --> Helper loaded: security_helper
INFO - 2023-09-25 17:01:42 --> Helper loaded: cookie_helper
INFO - 2023-09-25 17:01:42 --> Database Driver Class Initialized
INFO - 2023-09-25 17:01:42 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-25 17:01:42 --> Parser Class Initialized
INFO - 2023-09-25 17:01:42 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-25 17:01:42 --> Pagination Class Initialized
INFO - 2023-09-25 17:01:42 --> Form Validation Class Initialized
INFO - 2023-09-25 17:01:42 --> Controller Class Initialized
INFO - 2023-09-25 17:01:42 --> Model Class Initialized
DEBUG - 2023-09-25 17:01:42 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-09-25 17:01:42 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-25 17:01:42 --> Model Class Initialized
DEBUG - 2023-09-25 17:01:42 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-25 17:01:42 --> Model Class Initialized
INFO - 2023-09-25 17:01:42 --> Final output sent to browser
DEBUG - 2023-09-25 17:01:42 --> Total execution time: 0.0547
ERROR - 2023-09-25 17:01:45 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-25 17:01:45 --> Config Class Initialized
INFO - 2023-09-25 17:01:45 --> Hooks Class Initialized
DEBUG - 2023-09-25 17:01:45 --> UTF-8 Support Enabled
INFO - 2023-09-25 17:01:45 --> Utf8 Class Initialized
INFO - 2023-09-25 17:01:45 --> URI Class Initialized
INFO - 2023-09-25 17:01:45 --> Router Class Initialized
INFO - 2023-09-25 17:01:45 --> Output Class Initialized
INFO - 2023-09-25 17:01:45 --> Security Class Initialized
DEBUG - 2023-09-25 17:01:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-25 17:01:45 --> Input Class Initialized
INFO - 2023-09-25 17:01:45 --> Language Class Initialized
INFO - 2023-09-25 17:01:45 --> Loader Class Initialized
INFO - 2023-09-25 17:01:45 --> Helper loaded: url_helper
INFO - 2023-09-25 17:01:45 --> Helper loaded: file_helper
INFO - 2023-09-25 17:01:45 --> Helper loaded: html_helper
INFO - 2023-09-25 17:01:45 --> Helper loaded: text_helper
INFO - 2023-09-25 17:01:45 --> Helper loaded: form_helper
INFO - 2023-09-25 17:01:45 --> Helper loaded: lang_helper
INFO - 2023-09-25 17:01:45 --> Helper loaded: security_helper
INFO - 2023-09-25 17:01:45 --> Helper loaded: cookie_helper
INFO - 2023-09-25 17:01:45 --> Database Driver Class Initialized
INFO - 2023-09-25 17:01:45 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-25 17:01:45 --> Parser Class Initialized
INFO - 2023-09-25 17:01:45 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-25 17:01:45 --> Pagination Class Initialized
INFO - 2023-09-25 17:01:45 --> Form Validation Class Initialized
INFO - 2023-09-25 17:01:45 --> Controller Class Initialized
INFO - 2023-09-25 17:01:45 --> Model Class Initialized
DEBUG - 2023-09-25 17:01:45 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-09-25 17:01:45 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-25 17:01:45 --> Model Class Initialized
DEBUG - 2023-09-25 17:01:45 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-25 17:01:45 --> Model Class Initialized
INFO - 2023-09-25 17:01:45 --> Final output sent to browser
DEBUG - 2023-09-25 17:01:45 --> Total execution time: 0.0564
ERROR - 2023-09-25 17:01:45 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-25 17:01:45 --> Config Class Initialized
INFO - 2023-09-25 17:01:45 --> Hooks Class Initialized
DEBUG - 2023-09-25 17:01:45 --> UTF-8 Support Enabled
INFO - 2023-09-25 17:01:45 --> Utf8 Class Initialized
INFO - 2023-09-25 17:01:45 --> URI Class Initialized
INFO - 2023-09-25 17:01:45 --> Router Class Initialized
INFO - 2023-09-25 17:01:45 --> Output Class Initialized
INFO - 2023-09-25 17:01:45 --> Security Class Initialized
DEBUG - 2023-09-25 17:01:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-25 17:01:45 --> Input Class Initialized
INFO - 2023-09-25 17:01:45 --> Language Class Initialized
INFO - 2023-09-25 17:01:45 --> Loader Class Initialized
INFO - 2023-09-25 17:01:45 --> Helper loaded: url_helper
INFO - 2023-09-25 17:01:45 --> Helper loaded: file_helper
INFO - 2023-09-25 17:01:45 --> Helper loaded: html_helper
INFO - 2023-09-25 17:01:45 --> Helper loaded: text_helper
INFO - 2023-09-25 17:01:45 --> Helper loaded: form_helper
INFO - 2023-09-25 17:01:45 --> Helper loaded: lang_helper
INFO - 2023-09-25 17:01:45 --> Helper loaded: security_helper
INFO - 2023-09-25 17:01:45 --> Helper loaded: cookie_helper
INFO - 2023-09-25 17:01:45 --> Database Driver Class Initialized
INFO - 2023-09-25 17:01:45 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-25 17:01:45 --> Parser Class Initialized
INFO - 2023-09-25 17:01:45 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-25 17:01:45 --> Pagination Class Initialized
INFO - 2023-09-25 17:01:45 --> Form Validation Class Initialized
INFO - 2023-09-25 17:01:45 --> Controller Class Initialized
INFO - 2023-09-25 17:01:45 --> Model Class Initialized
DEBUG - 2023-09-25 17:01:45 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-09-25 17:01:45 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-25 17:01:45 --> Model Class Initialized
DEBUG - 2023-09-25 17:01:45 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-25 17:01:45 --> Model Class Initialized
INFO - 2023-09-25 17:01:46 --> Final output sent to browser
DEBUG - 2023-09-25 17:01:46 --> Total execution time: 0.0602
ERROR - 2023-09-25 17:01:46 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-25 17:01:46 --> Config Class Initialized
INFO - 2023-09-25 17:01:46 --> Hooks Class Initialized
DEBUG - 2023-09-25 17:01:46 --> UTF-8 Support Enabled
INFO - 2023-09-25 17:01:46 --> Utf8 Class Initialized
INFO - 2023-09-25 17:01:46 --> URI Class Initialized
INFO - 2023-09-25 17:01:46 --> Router Class Initialized
INFO - 2023-09-25 17:01:46 --> Output Class Initialized
INFO - 2023-09-25 17:01:46 --> Security Class Initialized
DEBUG - 2023-09-25 17:01:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-25 17:01:46 --> Input Class Initialized
INFO - 2023-09-25 17:01:46 --> Language Class Initialized
INFO - 2023-09-25 17:01:46 --> Loader Class Initialized
INFO - 2023-09-25 17:01:46 --> Helper loaded: url_helper
INFO - 2023-09-25 17:01:46 --> Helper loaded: file_helper
INFO - 2023-09-25 17:01:46 --> Helper loaded: html_helper
INFO - 2023-09-25 17:01:46 --> Helper loaded: text_helper
INFO - 2023-09-25 17:01:46 --> Helper loaded: form_helper
INFO - 2023-09-25 17:01:46 --> Helper loaded: lang_helper
INFO - 2023-09-25 17:01:46 --> Helper loaded: security_helper
INFO - 2023-09-25 17:01:46 --> Helper loaded: cookie_helper
INFO - 2023-09-25 17:01:46 --> Database Driver Class Initialized
INFO - 2023-09-25 17:01:46 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-25 17:01:46 --> Parser Class Initialized
INFO - 2023-09-25 17:01:46 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-25 17:01:46 --> Pagination Class Initialized
INFO - 2023-09-25 17:01:46 --> Form Validation Class Initialized
INFO - 2023-09-25 17:01:46 --> Controller Class Initialized
INFO - 2023-09-25 17:01:46 --> Model Class Initialized
DEBUG - 2023-09-25 17:01:46 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-09-25 17:01:46 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-25 17:01:46 --> Model Class Initialized
DEBUG - 2023-09-25 17:01:46 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-25 17:01:46 --> Model Class Initialized
INFO - 2023-09-25 17:01:46 --> Final output sent to browser
DEBUG - 2023-09-25 17:01:46 --> Total execution time: 0.0626
ERROR - 2023-09-25 17:01:46 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-25 17:01:46 --> Config Class Initialized
INFO - 2023-09-25 17:01:46 --> Hooks Class Initialized
DEBUG - 2023-09-25 17:01:46 --> UTF-8 Support Enabled
INFO - 2023-09-25 17:01:46 --> Utf8 Class Initialized
INFO - 2023-09-25 17:01:46 --> URI Class Initialized
INFO - 2023-09-25 17:01:46 --> Router Class Initialized
INFO - 2023-09-25 17:01:46 --> Output Class Initialized
INFO - 2023-09-25 17:01:46 --> Security Class Initialized
DEBUG - 2023-09-25 17:01:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-25 17:01:46 --> Input Class Initialized
INFO - 2023-09-25 17:01:46 --> Language Class Initialized
INFO - 2023-09-25 17:01:46 --> Loader Class Initialized
INFO - 2023-09-25 17:01:46 --> Helper loaded: url_helper
INFO - 2023-09-25 17:01:46 --> Helper loaded: file_helper
INFO - 2023-09-25 17:01:46 --> Helper loaded: html_helper
INFO - 2023-09-25 17:01:46 --> Helper loaded: text_helper
INFO - 2023-09-25 17:01:46 --> Helper loaded: form_helper
INFO - 2023-09-25 17:01:46 --> Helper loaded: lang_helper
INFO - 2023-09-25 17:01:46 --> Helper loaded: security_helper
INFO - 2023-09-25 17:01:46 --> Helper loaded: cookie_helper
INFO - 2023-09-25 17:01:46 --> Database Driver Class Initialized
INFO - 2023-09-25 17:01:46 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-25 17:01:46 --> Parser Class Initialized
INFO - 2023-09-25 17:01:46 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-25 17:01:46 --> Pagination Class Initialized
INFO - 2023-09-25 17:01:46 --> Form Validation Class Initialized
INFO - 2023-09-25 17:01:46 --> Controller Class Initialized
INFO - 2023-09-25 17:01:46 --> Model Class Initialized
DEBUG - 2023-09-25 17:01:46 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-09-25 17:01:46 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-25 17:01:46 --> Model Class Initialized
DEBUG - 2023-09-25 17:01:46 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-25 17:01:46 --> Model Class Initialized
INFO - 2023-09-25 17:01:46 --> Final output sent to browser
DEBUG - 2023-09-25 17:01:46 --> Total execution time: 0.0656
ERROR - 2023-09-25 17:01:58 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-25 17:01:58 --> Config Class Initialized
INFO - 2023-09-25 17:01:58 --> Hooks Class Initialized
DEBUG - 2023-09-25 17:01:58 --> UTF-8 Support Enabled
INFO - 2023-09-25 17:01:58 --> Utf8 Class Initialized
INFO - 2023-09-25 17:01:58 --> URI Class Initialized
INFO - 2023-09-25 17:01:58 --> Router Class Initialized
INFO - 2023-09-25 17:01:58 --> Output Class Initialized
INFO - 2023-09-25 17:01:58 --> Security Class Initialized
DEBUG - 2023-09-25 17:01:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-25 17:01:58 --> Input Class Initialized
INFO - 2023-09-25 17:01:58 --> Language Class Initialized
INFO - 2023-09-25 17:01:58 --> Loader Class Initialized
INFO - 2023-09-25 17:01:58 --> Helper loaded: url_helper
INFO - 2023-09-25 17:01:58 --> Helper loaded: file_helper
INFO - 2023-09-25 17:01:58 --> Helper loaded: html_helper
INFO - 2023-09-25 17:01:58 --> Helper loaded: text_helper
INFO - 2023-09-25 17:01:58 --> Helper loaded: form_helper
INFO - 2023-09-25 17:01:58 --> Helper loaded: lang_helper
INFO - 2023-09-25 17:01:58 --> Helper loaded: security_helper
INFO - 2023-09-25 17:01:58 --> Helper loaded: cookie_helper
INFO - 2023-09-25 17:01:58 --> Database Driver Class Initialized
INFO - 2023-09-25 17:01:58 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-25 17:01:58 --> Parser Class Initialized
INFO - 2023-09-25 17:01:58 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-25 17:01:58 --> Pagination Class Initialized
INFO - 2023-09-25 17:01:58 --> Form Validation Class Initialized
INFO - 2023-09-25 17:01:58 --> Controller Class Initialized
INFO - 2023-09-25 17:01:58 --> Model Class Initialized
DEBUG - 2023-09-25 17:01:58 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-09-25 17:01:58 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-25 17:01:58 --> Model Class Initialized
DEBUG - 2023-09-25 17:01:58 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-25 17:01:58 --> Model Class Initialized
INFO - 2023-09-25 17:01:58 --> Final output sent to browser
DEBUG - 2023-09-25 17:01:58 --> Total execution time: 0.1659
ERROR - 2023-09-25 17:02:16 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-25 17:02:16 --> Config Class Initialized
INFO - 2023-09-25 17:02:16 --> Hooks Class Initialized
DEBUG - 2023-09-25 17:02:16 --> UTF-8 Support Enabled
INFO - 2023-09-25 17:02:16 --> Utf8 Class Initialized
INFO - 2023-09-25 17:02:16 --> URI Class Initialized
INFO - 2023-09-25 17:02:16 --> Router Class Initialized
INFO - 2023-09-25 17:02:16 --> Output Class Initialized
INFO - 2023-09-25 17:02:16 --> Security Class Initialized
DEBUG - 2023-09-25 17:02:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-25 17:02:16 --> Input Class Initialized
INFO - 2023-09-25 17:02:16 --> Language Class Initialized
INFO - 2023-09-25 17:02:16 --> Loader Class Initialized
INFO - 2023-09-25 17:02:16 --> Helper loaded: url_helper
INFO - 2023-09-25 17:02:16 --> Helper loaded: file_helper
INFO - 2023-09-25 17:02:16 --> Helper loaded: html_helper
INFO - 2023-09-25 17:02:16 --> Helper loaded: text_helper
INFO - 2023-09-25 17:02:16 --> Helper loaded: form_helper
INFO - 2023-09-25 17:02:16 --> Helper loaded: lang_helper
INFO - 2023-09-25 17:02:16 --> Helper loaded: security_helper
INFO - 2023-09-25 17:02:16 --> Helper loaded: cookie_helper
INFO - 2023-09-25 17:02:16 --> Database Driver Class Initialized
INFO - 2023-09-25 17:02:16 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-25 17:02:16 --> Parser Class Initialized
INFO - 2023-09-25 17:02:16 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-25 17:02:16 --> Pagination Class Initialized
INFO - 2023-09-25 17:02:16 --> Form Validation Class Initialized
INFO - 2023-09-25 17:02:16 --> Controller Class Initialized
INFO - 2023-09-25 17:02:16 --> Model Class Initialized
DEBUG - 2023-09-25 17:02:16 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-09-25 17:02:16 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-25 17:02:16 --> Model Class Initialized
DEBUG - 2023-09-25 17:02:16 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-25 17:02:16 --> Model Class Initialized
DEBUG - 2023-09-25 17:02:16 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-25 17:02:16 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice_html.php
DEBUG - 2023-09-25 17:02:16 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-09-25 17:02:16 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-09-25 17:02:16 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-09-25 17:02:16 --> Model Class Initialized
INFO - 2023-09-25 17:02:16 --> Model Class Initialized
INFO - 2023-09-25 17:02:16 --> Model Class Initialized
INFO - 2023-09-25 17:02:16 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-09-25 17:02:16 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-09-25 17:02:16 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-09-25 17:02:16 --> Final output sent to browser
DEBUG - 2023-09-25 17:02:16 --> Total execution time: 0.1603
ERROR - 2023-09-25 17:02:35 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-25 17:02:35 --> Config Class Initialized
INFO - 2023-09-25 17:02:35 --> Hooks Class Initialized
DEBUG - 2023-09-25 17:02:35 --> UTF-8 Support Enabled
INFO - 2023-09-25 17:02:35 --> Utf8 Class Initialized
INFO - 2023-09-25 17:02:35 --> URI Class Initialized
INFO - 2023-09-25 17:02:35 --> Router Class Initialized
INFO - 2023-09-25 17:02:35 --> Output Class Initialized
INFO - 2023-09-25 17:02:35 --> Security Class Initialized
DEBUG - 2023-09-25 17:02:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-25 17:02:35 --> Input Class Initialized
INFO - 2023-09-25 17:02:35 --> Language Class Initialized
INFO - 2023-09-25 17:02:35 --> Loader Class Initialized
INFO - 2023-09-25 17:02:35 --> Helper loaded: url_helper
INFO - 2023-09-25 17:02:35 --> Helper loaded: file_helper
INFO - 2023-09-25 17:02:35 --> Helper loaded: html_helper
INFO - 2023-09-25 17:02:35 --> Helper loaded: text_helper
INFO - 2023-09-25 17:02:35 --> Helper loaded: form_helper
INFO - 2023-09-25 17:02:35 --> Helper loaded: lang_helper
INFO - 2023-09-25 17:02:35 --> Helper loaded: security_helper
INFO - 2023-09-25 17:02:35 --> Helper loaded: cookie_helper
INFO - 2023-09-25 17:02:35 --> Database Driver Class Initialized
INFO - 2023-09-25 17:02:35 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-25 17:02:35 --> Parser Class Initialized
INFO - 2023-09-25 17:02:35 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-25 17:02:35 --> Pagination Class Initialized
INFO - 2023-09-25 17:02:35 --> Form Validation Class Initialized
INFO - 2023-09-25 17:02:35 --> Controller Class Initialized
INFO - 2023-09-25 17:02:35 --> Model Class Initialized
DEBUG - 2023-09-25 17:02:35 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-09-25 17:02:35 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-25 17:02:35 --> Model Class Initialized
DEBUG - 2023-09-25 17:02:35 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-25 17:02:35 --> Model Class Initialized
INFO - 2023-09-25 17:02:36 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice.php
DEBUG - 2023-09-25 17:02:36 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-09-25 17:02:36 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-09-25 17:02:36 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-09-25 17:02:36 --> Model Class Initialized
INFO - 2023-09-25 17:02:36 --> Model Class Initialized
INFO - 2023-09-25 17:02:36 --> Model Class Initialized
INFO - 2023-09-25 17:02:36 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-09-25 17:02:36 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-09-25 17:02:36 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-09-25 17:02:36 --> Final output sent to browser
DEBUG - 2023-09-25 17:02:36 --> Total execution time: 0.1551
ERROR - 2023-09-25 17:02:36 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-25 17:02:36 --> Config Class Initialized
INFO - 2023-09-25 17:02:36 --> Hooks Class Initialized
DEBUG - 2023-09-25 17:02:36 --> UTF-8 Support Enabled
INFO - 2023-09-25 17:02:36 --> Utf8 Class Initialized
INFO - 2023-09-25 17:02:36 --> URI Class Initialized
INFO - 2023-09-25 17:02:36 --> Router Class Initialized
INFO - 2023-09-25 17:02:36 --> Output Class Initialized
INFO - 2023-09-25 17:02:36 --> Security Class Initialized
DEBUG - 2023-09-25 17:02:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-25 17:02:36 --> Input Class Initialized
INFO - 2023-09-25 17:02:36 --> Language Class Initialized
INFO - 2023-09-25 17:02:36 --> Loader Class Initialized
INFO - 2023-09-25 17:02:36 --> Helper loaded: url_helper
INFO - 2023-09-25 17:02:36 --> Helper loaded: file_helper
INFO - 2023-09-25 17:02:36 --> Helper loaded: html_helper
INFO - 2023-09-25 17:02:36 --> Helper loaded: text_helper
INFO - 2023-09-25 17:02:36 --> Helper loaded: form_helper
INFO - 2023-09-25 17:02:36 --> Helper loaded: lang_helper
INFO - 2023-09-25 17:02:36 --> Helper loaded: security_helper
INFO - 2023-09-25 17:02:36 --> Helper loaded: cookie_helper
INFO - 2023-09-25 17:02:36 --> Database Driver Class Initialized
INFO - 2023-09-25 17:02:36 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-25 17:02:36 --> Parser Class Initialized
INFO - 2023-09-25 17:02:36 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-25 17:02:36 --> Pagination Class Initialized
INFO - 2023-09-25 17:02:36 --> Form Validation Class Initialized
INFO - 2023-09-25 17:02:36 --> Controller Class Initialized
INFO - 2023-09-25 17:02:36 --> Model Class Initialized
DEBUG - 2023-09-25 17:02:36 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-09-25 17:02:36 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-25 17:02:36 --> Model Class Initialized
DEBUG - 2023-09-25 17:02:36 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-25 17:02:36 --> Model Class Initialized
INFO - 2023-09-25 17:02:36 --> Final output sent to browser
DEBUG - 2023-09-25 17:02:36 --> Total execution time: 0.0505
ERROR - 2023-09-25 17:02:41 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-25 17:02:41 --> Config Class Initialized
INFO - 2023-09-25 17:02:41 --> Hooks Class Initialized
DEBUG - 2023-09-25 17:02:41 --> UTF-8 Support Enabled
INFO - 2023-09-25 17:02:41 --> Utf8 Class Initialized
INFO - 2023-09-25 17:02:41 --> URI Class Initialized
INFO - 2023-09-25 17:02:41 --> Router Class Initialized
INFO - 2023-09-25 17:02:41 --> Output Class Initialized
INFO - 2023-09-25 17:02:41 --> Security Class Initialized
DEBUG - 2023-09-25 17:02:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-25 17:02:41 --> Input Class Initialized
INFO - 2023-09-25 17:02:41 --> Language Class Initialized
INFO - 2023-09-25 17:02:41 --> Loader Class Initialized
INFO - 2023-09-25 17:02:41 --> Helper loaded: url_helper
INFO - 2023-09-25 17:02:41 --> Helper loaded: file_helper
INFO - 2023-09-25 17:02:41 --> Helper loaded: html_helper
INFO - 2023-09-25 17:02:41 --> Helper loaded: text_helper
INFO - 2023-09-25 17:02:41 --> Helper loaded: form_helper
INFO - 2023-09-25 17:02:41 --> Helper loaded: lang_helper
INFO - 2023-09-25 17:02:41 --> Helper loaded: security_helper
INFO - 2023-09-25 17:02:41 --> Helper loaded: cookie_helper
INFO - 2023-09-25 17:02:41 --> Database Driver Class Initialized
INFO - 2023-09-25 17:02:41 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-25 17:02:41 --> Parser Class Initialized
INFO - 2023-09-25 17:02:41 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-25 17:02:41 --> Pagination Class Initialized
INFO - 2023-09-25 17:02:41 --> Form Validation Class Initialized
INFO - 2023-09-25 17:02:41 --> Controller Class Initialized
INFO - 2023-09-25 17:02:41 --> Model Class Initialized
DEBUG - 2023-09-25 17:02:41 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-09-25 17:02:41 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-25 17:02:41 --> Model Class Initialized
DEBUG - 2023-09-25 17:02:41 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-25 17:02:41 --> Model Class Initialized
INFO - 2023-09-25 17:02:41 --> Final output sent to browser
DEBUG - 2023-09-25 17:02:41 --> Total execution time: 0.0526
ERROR - 2023-09-25 17:02:42 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-25 17:02:42 --> Config Class Initialized
INFO - 2023-09-25 17:02:42 --> Hooks Class Initialized
DEBUG - 2023-09-25 17:02:42 --> UTF-8 Support Enabled
INFO - 2023-09-25 17:02:42 --> Utf8 Class Initialized
INFO - 2023-09-25 17:02:42 --> URI Class Initialized
INFO - 2023-09-25 17:02:42 --> Router Class Initialized
INFO - 2023-09-25 17:02:42 --> Output Class Initialized
INFO - 2023-09-25 17:02:42 --> Security Class Initialized
DEBUG - 2023-09-25 17:02:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-25 17:02:42 --> Input Class Initialized
INFO - 2023-09-25 17:02:42 --> Language Class Initialized
INFO - 2023-09-25 17:02:42 --> Loader Class Initialized
INFO - 2023-09-25 17:02:42 --> Helper loaded: url_helper
INFO - 2023-09-25 17:02:42 --> Helper loaded: file_helper
INFO - 2023-09-25 17:02:42 --> Helper loaded: html_helper
INFO - 2023-09-25 17:02:42 --> Helper loaded: text_helper
INFO - 2023-09-25 17:02:42 --> Helper loaded: form_helper
INFO - 2023-09-25 17:02:42 --> Helper loaded: lang_helper
INFO - 2023-09-25 17:02:42 --> Helper loaded: security_helper
INFO - 2023-09-25 17:02:42 --> Helper loaded: cookie_helper
INFO - 2023-09-25 17:02:42 --> Database Driver Class Initialized
INFO - 2023-09-25 17:02:42 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-25 17:02:42 --> Parser Class Initialized
INFO - 2023-09-25 17:02:42 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-25 17:02:42 --> Pagination Class Initialized
INFO - 2023-09-25 17:02:42 --> Form Validation Class Initialized
INFO - 2023-09-25 17:02:42 --> Controller Class Initialized
INFO - 2023-09-25 17:02:42 --> Model Class Initialized
DEBUG - 2023-09-25 17:02:42 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-09-25 17:02:42 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-25 17:02:42 --> Model Class Initialized
DEBUG - 2023-09-25 17:02:42 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-25 17:02:42 --> Model Class Initialized
INFO - 2023-09-25 17:02:42 --> Final output sent to browser
DEBUG - 2023-09-25 17:02:42 --> Total execution time: 0.0512
ERROR - 2023-09-25 17:02:42 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-25 17:02:42 --> Config Class Initialized
INFO - 2023-09-25 17:02:42 --> Hooks Class Initialized
DEBUG - 2023-09-25 17:02:42 --> UTF-8 Support Enabled
INFO - 2023-09-25 17:02:42 --> Utf8 Class Initialized
INFO - 2023-09-25 17:02:42 --> URI Class Initialized
INFO - 2023-09-25 17:02:42 --> Router Class Initialized
INFO - 2023-09-25 17:02:42 --> Output Class Initialized
INFO - 2023-09-25 17:02:42 --> Security Class Initialized
DEBUG - 2023-09-25 17:02:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-25 17:02:42 --> Input Class Initialized
INFO - 2023-09-25 17:02:42 --> Language Class Initialized
INFO - 2023-09-25 17:02:42 --> Loader Class Initialized
INFO - 2023-09-25 17:02:42 --> Helper loaded: url_helper
INFO - 2023-09-25 17:02:42 --> Helper loaded: file_helper
INFO - 2023-09-25 17:02:42 --> Helper loaded: html_helper
INFO - 2023-09-25 17:02:42 --> Helper loaded: text_helper
INFO - 2023-09-25 17:02:42 --> Helper loaded: form_helper
INFO - 2023-09-25 17:02:42 --> Helper loaded: lang_helper
INFO - 2023-09-25 17:02:42 --> Helper loaded: security_helper
INFO - 2023-09-25 17:02:42 --> Helper loaded: cookie_helper
INFO - 2023-09-25 17:02:42 --> Database Driver Class Initialized
INFO - 2023-09-25 17:02:42 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-25 17:02:42 --> Parser Class Initialized
INFO - 2023-09-25 17:02:42 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-25 17:02:42 --> Pagination Class Initialized
INFO - 2023-09-25 17:02:42 --> Form Validation Class Initialized
INFO - 2023-09-25 17:02:42 --> Controller Class Initialized
INFO - 2023-09-25 17:02:42 --> Model Class Initialized
DEBUG - 2023-09-25 17:02:42 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-09-25 17:02:42 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-25 17:02:42 --> Model Class Initialized
DEBUG - 2023-09-25 17:02:42 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-25 17:02:42 --> Model Class Initialized
INFO - 2023-09-25 17:02:42 --> Final output sent to browser
DEBUG - 2023-09-25 17:02:42 --> Total execution time: 0.0534
ERROR - 2023-09-25 17:02:43 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-25 17:02:43 --> Config Class Initialized
INFO - 2023-09-25 17:02:43 --> Hooks Class Initialized
DEBUG - 2023-09-25 17:02:43 --> UTF-8 Support Enabled
INFO - 2023-09-25 17:02:43 --> Utf8 Class Initialized
INFO - 2023-09-25 17:02:43 --> URI Class Initialized
INFO - 2023-09-25 17:02:43 --> Router Class Initialized
INFO - 2023-09-25 17:02:43 --> Output Class Initialized
INFO - 2023-09-25 17:02:43 --> Security Class Initialized
DEBUG - 2023-09-25 17:02:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-25 17:02:43 --> Input Class Initialized
INFO - 2023-09-25 17:02:43 --> Language Class Initialized
INFO - 2023-09-25 17:02:43 --> Loader Class Initialized
INFO - 2023-09-25 17:02:43 --> Helper loaded: url_helper
INFO - 2023-09-25 17:02:43 --> Helper loaded: file_helper
INFO - 2023-09-25 17:02:43 --> Helper loaded: html_helper
INFO - 2023-09-25 17:02:43 --> Helper loaded: text_helper
INFO - 2023-09-25 17:02:43 --> Helper loaded: form_helper
INFO - 2023-09-25 17:02:43 --> Helper loaded: lang_helper
INFO - 2023-09-25 17:02:43 --> Helper loaded: security_helper
INFO - 2023-09-25 17:02:43 --> Helper loaded: cookie_helper
INFO - 2023-09-25 17:02:43 --> Database Driver Class Initialized
INFO - 2023-09-25 17:02:43 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-25 17:02:43 --> Parser Class Initialized
INFO - 2023-09-25 17:02:43 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-25 17:02:43 --> Pagination Class Initialized
INFO - 2023-09-25 17:02:43 --> Form Validation Class Initialized
INFO - 2023-09-25 17:02:43 --> Controller Class Initialized
INFO - 2023-09-25 17:02:43 --> Model Class Initialized
DEBUG - 2023-09-25 17:02:43 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-09-25 17:02:43 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-25 17:02:43 --> Model Class Initialized
DEBUG - 2023-09-25 17:02:43 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-25 17:02:43 --> Model Class Initialized
INFO - 2023-09-25 17:02:43 --> Final output sent to browser
DEBUG - 2023-09-25 17:02:43 --> Total execution time: 0.0533
ERROR - 2023-09-25 17:02:44 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-25 17:02:44 --> Config Class Initialized
INFO - 2023-09-25 17:02:44 --> Hooks Class Initialized
DEBUG - 2023-09-25 17:02:44 --> UTF-8 Support Enabled
INFO - 2023-09-25 17:02:44 --> Utf8 Class Initialized
INFO - 2023-09-25 17:02:44 --> URI Class Initialized
INFO - 2023-09-25 17:02:44 --> Router Class Initialized
INFO - 2023-09-25 17:02:44 --> Output Class Initialized
INFO - 2023-09-25 17:02:44 --> Security Class Initialized
DEBUG - 2023-09-25 17:02:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-25 17:02:44 --> Input Class Initialized
INFO - 2023-09-25 17:02:44 --> Language Class Initialized
INFO - 2023-09-25 17:02:44 --> Loader Class Initialized
INFO - 2023-09-25 17:02:44 --> Helper loaded: url_helper
INFO - 2023-09-25 17:02:44 --> Helper loaded: file_helper
INFO - 2023-09-25 17:02:44 --> Helper loaded: html_helper
INFO - 2023-09-25 17:02:44 --> Helper loaded: text_helper
INFO - 2023-09-25 17:02:44 --> Helper loaded: form_helper
INFO - 2023-09-25 17:02:44 --> Helper loaded: lang_helper
INFO - 2023-09-25 17:02:44 --> Helper loaded: security_helper
INFO - 2023-09-25 17:02:44 --> Helper loaded: cookie_helper
INFO - 2023-09-25 17:02:44 --> Database Driver Class Initialized
INFO - 2023-09-25 17:02:44 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-25 17:02:44 --> Parser Class Initialized
INFO - 2023-09-25 17:02:44 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-25 17:02:44 --> Pagination Class Initialized
INFO - 2023-09-25 17:02:44 --> Form Validation Class Initialized
INFO - 2023-09-25 17:02:44 --> Controller Class Initialized
INFO - 2023-09-25 17:02:44 --> Model Class Initialized
DEBUG - 2023-09-25 17:02:44 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-09-25 17:02:44 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-25 17:02:44 --> Model Class Initialized
DEBUG - 2023-09-25 17:02:44 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-25 17:02:44 --> Model Class Initialized
INFO - 2023-09-25 17:02:44 --> Final output sent to browser
DEBUG - 2023-09-25 17:02:44 --> Total execution time: 0.0527
ERROR - 2023-09-25 17:02:46 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-25 17:02:46 --> Config Class Initialized
INFO - 2023-09-25 17:02:46 --> Hooks Class Initialized
DEBUG - 2023-09-25 17:02:46 --> UTF-8 Support Enabled
INFO - 2023-09-25 17:02:46 --> Utf8 Class Initialized
INFO - 2023-09-25 17:02:46 --> URI Class Initialized
INFO - 2023-09-25 17:02:46 --> Router Class Initialized
INFO - 2023-09-25 17:02:46 --> Output Class Initialized
INFO - 2023-09-25 17:02:46 --> Security Class Initialized
DEBUG - 2023-09-25 17:02:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-25 17:02:46 --> Input Class Initialized
INFO - 2023-09-25 17:02:46 --> Language Class Initialized
INFO - 2023-09-25 17:02:46 --> Loader Class Initialized
INFO - 2023-09-25 17:02:46 --> Helper loaded: url_helper
INFO - 2023-09-25 17:02:46 --> Helper loaded: file_helper
INFO - 2023-09-25 17:02:46 --> Helper loaded: html_helper
INFO - 2023-09-25 17:02:46 --> Helper loaded: text_helper
INFO - 2023-09-25 17:02:46 --> Helper loaded: form_helper
INFO - 2023-09-25 17:02:46 --> Helper loaded: lang_helper
INFO - 2023-09-25 17:02:46 --> Helper loaded: security_helper
INFO - 2023-09-25 17:02:46 --> Helper loaded: cookie_helper
INFO - 2023-09-25 17:02:46 --> Database Driver Class Initialized
INFO - 2023-09-25 17:02:46 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-25 17:02:46 --> Parser Class Initialized
INFO - 2023-09-25 17:02:46 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-25 17:02:46 --> Pagination Class Initialized
INFO - 2023-09-25 17:02:46 --> Form Validation Class Initialized
INFO - 2023-09-25 17:02:46 --> Controller Class Initialized
INFO - 2023-09-25 17:02:46 --> Model Class Initialized
DEBUG - 2023-09-25 17:02:46 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-09-25 17:02:46 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-25 17:02:46 --> Model Class Initialized
DEBUG - 2023-09-25 17:02:46 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-25 17:02:46 --> Model Class Initialized
INFO - 2023-09-25 17:02:46 --> Final output sent to browser
DEBUG - 2023-09-25 17:02:46 --> Total execution time: 0.0294
ERROR - 2023-09-25 17:02:55 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-25 17:02:55 --> Config Class Initialized
INFO - 2023-09-25 17:02:55 --> Hooks Class Initialized
DEBUG - 2023-09-25 17:02:55 --> UTF-8 Support Enabled
INFO - 2023-09-25 17:02:55 --> Utf8 Class Initialized
INFO - 2023-09-25 17:02:55 --> URI Class Initialized
INFO - 2023-09-25 17:02:55 --> Router Class Initialized
INFO - 2023-09-25 17:02:55 --> Output Class Initialized
INFO - 2023-09-25 17:02:55 --> Security Class Initialized
DEBUG - 2023-09-25 17:02:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-25 17:02:55 --> Input Class Initialized
INFO - 2023-09-25 17:02:55 --> Language Class Initialized
INFO - 2023-09-25 17:02:55 --> Loader Class Initialized
INFO - 2023-09-25 17:02:55 --> Helper loaded: url_helper
INFO - 2023-09-25 17:02:55 --> Helper loaded: file_helper
INFO - 2023-09-25 17:02:55 --> Helper loaded: html_helper
INFO - 2023-09-25 17:02:55 --> Helper loaded: text_helper
INFO - 2023-09-25 17:02:55 --> Helper loaded: form_helper
INFO - 2023-09-25 17:02:55 --> Helper loaded: lang_helper
INFO - 2023-09-25 17:02:55 --> Helper loaded: security_helper
INFO - 2023-09-25 17:02:55 --> Helper loaded: cookie_helper
INFO - 2023-09-25 17:02:55 --> Database Driver Class Initialized
INFO - 2023-09-25 17:02:55 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-25 17:02:55 --> Parser Class Initialized
INFO - 2023-09-25 17:02:55 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-25 17:02:55 --> Pagination Class Initialized
INFO - 2023-09-25 17:02:55 --> Form Validation Class Initialized
INFO - 2023-09-25 17:02:55 --> Controller Class Initialized
INFO - 2023-09-25 17:02:55 --> Model Class Initialized
DEBUG - 2023-09-25 17:02:55 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-09-25 17:02:55 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-25 17:02:55 --> Model Class Initialized
DEBUG - 2023-09-25 17:02:55 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-25 17:02:55 --> Model Class Initialized
DEBUG - 2023-09-25 17:02:55 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-25 17:02:55 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice_html.php
DEBUG - 2023-09-25 17:02:55 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-09-25 17:02:55 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-09-25 17:02:55 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-09-25 17:02:55 --> Model Class Initialized
INFO - 2023-09-25 17:02:55 --> Model Class Initialized
INFO - 2023-09-25 17:02:55 --> Model Class Initialized
INFO - 2023-09-25 17:02:55 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-09-25 17:02:55 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-09-25 17:02:55 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-09-25 17:02:55 --> Final output sent to browser
DEBUG - 2023-09-25 17:02:55 --> Total execution time: 0.1418
ERROR - 2023-09-25 17:03:20 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-25 17:03:20 --> Config Class Initialized
INFO - 2023-09-25 17:03:20 --> Hooks Class Initialized
DEBUG - 2023-09-25 17:03:20 --> UTF-8 Support Enabled
INFO - 2023-09-25 17:03:20 --> Utf8 Class Initialized
INFO - 2023-09-25 17:03:20 --> URI Class Initialized
INFO - 2023-09-25 17:03:20 --> Router Class Initialized
INFO - 2023-09-25 17:03:20 --> Output Class Initialized
INFO - 2023-09-25 17:03:20 --> Security Class Initialized
DEBUG - 2023-09-25 17:03:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-25 17:03:20 --> Input Class Initialized
INFO - 2023-09-25 17:03:20 --> Language Class Initialized
INFO - 2023-09-25 17:03:20 --> Loader Class Initialized
INFO - 2023-09-25 17:03:20 --> Helper loaded: url_helper
INFO - 2023-09-25 17:03:20 --> Helper loaded: file_helper
INFO - 2023-09-25 17:03:20 --> Helper loaded: html_helper
INFO - 2023-09-25 17:03:20 --> Helper loaded: text_helper
INFO - 2023-09-25 17:03:20 --> Helper loaded: form_helper
INFO - 2023-09-25 17:03:20 --> Helper loaded: lang_helper
INFO - 2023-09-25 17:03:20 --> Helper loaded: security_helper
INFO - 2023-09-25 17:03:20 --> Helper loaded: cookie_helper
INFO - 2023-09-25 17:03:20 --> Database Driver Class Initialized
INFO - 2023-09-25 17:03:20 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-25 17:03:20 --> Parser Class Initialized
INFO - 2023-09-25 17:03:20 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-25 17:03:20 --> Pagination Class Initialized
INFO - 2023-09-25 17:03:20 --> Form Validation Class Initialized
INFO - 2023-09-25 17:03:20 --> Controller Class Initialized
INFO - 2023-09-25 17:03:20 --> Model Class Initialized
DEBUG - 2023-09-25 17:03:20 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-09-25 17:03:20 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-25 17:03:20 --> Model Class Initialized
DEBUG - 2023-09-25 17:03:20 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-25 17:03:20 --> Model Class Initialized
INFO - 2023-09-25 17:03:20 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice.php
DEBUG - 2023-09-25 17:03:20 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-09-25 17:03:20 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-09-25 17:03:20 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-09-25 17:03:20 --> Model Class Initialized
INFO - 2023-09-25 17:03:20 --> Model Class Initialized
INFO - 2023-09-25 17:03:20 --> Model Class Initialized
INFO - 2023-09-25 17:03:20 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-09-25 17:03:20 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-09-25 17:03:20 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-09-25 17:03:20 --> Final output sent to browser
DEBUG - 2023-09-25 17:03:20 --> Total execution time: 0.1498
ERROR - 2023-09-25 17:03:20 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-25 17:03:20 --> Config Class Initialized
INFO - 2023-09-25 17:03:20 --> Hooks Class Initialized
DEBUG - 2023-09-25 17:03:20 --> UTF-8 Support Enabled
INFO - 2023-09-25 17:03:20 --> Utf8 Class Initialized
INFO - 2023-09-25 17:03:20 --> URI Class Initialized
INFO - 2023-09-25 17:03:20 --> Router Class Initialized
INFO - 2023-09-25 17:03:20 --> Output Class Initialized
INFO - 2023-09-25 17:03:20 --> Security Class Initialized
DEBUG - 2023-09-25 17:03:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-25 17:03:20 --> Input Class Initialized
INFO - 2023-09-25 17:03:20 --> Language Class Initialized
INFO - 2023-09-25 17:03:20 --> Loader Class Initialized
INFO - 2023-09-25 17:03:20 --> Helper loaded: url_helper
INFO - 2023-09-25 17:03:20 --> Helper loaded: file_helper
INFO - 2023-09-25 17:03:20 --> Helper loaded: html_helper
INFO - 2023-09-25 17:03:20 --> Helper loaded: text_helper
INFO - 2023-09-25 17:03:20 --> Helper loaded: form_helper
INFO - 2023-09-25 17:03:20 --> Helper loaded: lang_helper
INFO - 2023-09-25 17:03:20 --> Helper loaded: security_helper
INFO - 2023-09-25 17:03:20 --> Helper loaded: cookie_helper
INFO - 2023-09-25 17:03:20 --> Database Driver Class Initialized
INFO - 2023-09-25 17:03:20 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-25 17:03:20 --> Parser Class Initialized
INFO - 2023-09-25 17:03:20 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-25 17:03:20 --> Pagination Class Initialized
INFO - 2023-09-25 17:03:20 --> Form Validation Class Initialized
INFO - 2023-09-25 17:03:20 --> Controller Class Initialized
INFO - 2023-09-25 17:03:20 --> Model Class Initialized
DEBUG - 2023-09-25 17:03:20 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-09-25 17:03:20 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-25 17:03:20 --> Model Class Initialized
DEBUG - 2023-09-25 17:03:20 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-25 17:03:20 --> Model Class Initialized
INFO - 2023-09-25 17:03:20 --> Final output sent to browser
DEBUG - 2023-09-25 17:03:20 --> Total execution time: 0.0530
ERROR - 2023-09-25 17:03:25 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-25 17:03:25 --> Config Class Initialized
INFO - 2023-09-25 17:03:25 --> Hooks Class Initialized
DEBUG - 2023-09-25 17:03:25 --> UTF-8 Support Enabled
INFO - 2023-09-25 17:03:25 --> Utf8 Class Initialized
INFO - 2023-09-25 17:03:25 --> URI Class Initialized
INFO - 2023-09-25 17:03:25 --> Router Class Initialized
INFO - 2023-09-25 17:03:25 --> Output Class Initialized
INFO - 2023-09-25 17:03:25 --> Security Class Initialized
DEBUG - 2023-09-25 17:03:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-25 17:03:25 --> Input Class Initialized
INFO - 2023-09-25 17:03:25 --> Language Class Initialized
INFO - 2023-09-25 17:03:25 --> Loader Class Initialized
INFO - 2023-09-25 17:03:25 --> Helper loaded: url_helper
INFO - 2023-09-25 17:03:25 --> Helper loaded: file_helper
INFO - 2023-09-25 17:03:25 --> Helper loaded: html_helper
INFO - 2023-09-25 17:03:25 --> Helper loaded: text_helper
INFO - 2023-09-25 17:03:25 --> Helper loaded: form_helper
INFO - 2023-09-25 17:03:25 --> Helper loaded: lang_helper
INFO - 2023-09-25 17:03:25 --> Helper loaded: security_helper
INFO - 2023-09-25 17:03:25 --> Helper loaded: cookie_helper
INFO - 2023-09-25 17:03:25 --> Database Driver Class Initialized
INFO - 2023-09-25 17:03:25 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-25 17:03:25 --> Parser Class Initialized
INFO - 2023-09-25 17:03:25 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-25 17:03:25 --> Pagination Class Initialized
INFO - 2023-09-25 17:03:25 --> Form Validation Class Initialized
INFO - 2023-09-25 17:03:25 --> Controller Class Initialized
INFO - 2023-09-25 17:03:25 --> Model Class Initialized
DEBUG - 2023-09-25 17:03:25 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-09-25 17:03:25 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-25 17:03:25 --> Model Class Initialized
DEBUG - 2023-09-25 17:03:25 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-25 17:03:25 --> Model Class Initialized
INFO - 2023-09-25 17:03:25 --> Final output sent to browser
DEBUG - 2023-09-25 17:03:25 --> Total execution time: 0.0484
ERROR - 2023-09-25 17:03:26 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-25 17:03:26 --> Config Class Initialized
INFO - 2023-09-25 17:03:26 --> Hooks Class Initialized
DEBUG - 2023-09-25 17:03:26 --> UTF-8 Support Enabled
INFO - 2023-09-25 17:03:26 --> Utf8 Class Initialized
INFO - 2023-09-25 17:03:26 --> URI Class Initialized
INFO - 2023-09-25 17:03:26 --> Router Class Initialized
INFO - 2023-09-25 17:03:26 --> Output Class Initialized
INFO - 2023-09-25 17:03:26 --> Security Class Initialized
DEBUG - 2023-09-25 17:03:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-25 17:03:26 --> Input Class Initialized
INFO - 2023-09-25 17:03:26 --> Language Class Initialized
INFO - 2023-09-25 17:03:26 --> Loader Class Initialized
INFO - 2023-09-25 17:03:26 --> Helper loaded: url_helper
INFO - 2023-09-25 17:03:26 --> Helper loaded: file_helper
INFO - 2023-09-25 17:03:26 --> Helper loaded: html_helper
INFO - 2023-09-25 17:03:26 --> Helper loaded: text_helper
INFO - 2023-09-25 17:03:26 --> Helper loaded: form_helper
INFO - 2023-09-25 17:03:26 --> Helper loaded: lang_helper
INFO - 2023-09-25 17:03:26 --> Helper loaded: security_helper
INFO - 2023-09-25 17:03:26 --> Helper loaded: cookie_helper
INFO - 2023-09-25 17:03:26 --> Database Driver Class Initialized
INFO - 2023-09-25 17:03:26 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-25 17:03:26 --> Parser Class Initialized
INFO - 2023-09-25 17:03:26 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-25 17:03:26 --> Pagination Class Initialized
INFO - 2023-09-25 17:03:26 --> Form Validation Class Initialized
INFO - 2023-09-25 17:03:26 --> Controller Class Initialized
INFO - 2023-09-25 17:03:26 --> Model Class Initialized
DEBUG - 2023-09-25 17:03:26 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-09-25 17:03:26 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-25 17:03:26 --> Model Class Initialized
DEBUG - 2023-09-25 17:03:26 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-25 17:03:26 --> Model Class Initialized
INFO - 2023-09-25 17:03:26 --> Final output sent to browser
DEBUG - 2023-09-25 17:03:26 --> Total execution time: 0.0531
ERROR - 2023-09-25 17:03:26 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-25 17:03:26 --> Config Class Initialized
INFO - 2023-09-25 17:03:26 --> Hooks Class Initialized
DEBUG - 2023-09-25 17:03:26 --> UTF-8 Support Enabled
INFO - 2023-09-25 17:03:26 --> Utf8 Class Initialized
INFO - 2023-09-25 17:03:26 --> URI Class Initialized
INFO - 2023-09-25 17:03:26 --> Router Class Initialized
INFO - 2023-09-25 17:03:26 --> Output Class Initialized
INFO - 2023-09-25 17:03:26 --> Security Class Initialized
DEBUG - 2023-09-25 17:03:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-25 17:03:26 --> Input Class Initialized
INFO - 2023-09-25 17:03:26 --> Language Class Initialized
INFO - 2023-09-25 17:03:26 --> Loader Class Initialized
INFO - 2023-09-25 17:03:26 --> Helper loaded: url_helper
INFO - 2023-09-25 17:03:26 --> Helper loaded: file_helper
INFO - 2023-09-25 17:03:26 --> Helper loaded: html_helper
INFO - 2023-09-25 17:03:26 --> Helper loaded: text_helper
INFO - 2023-09-25 17:03:26 --> Helper loaded: form_helper
INFO - 2023-09-25 17:03:26 --> Helper loaded: lang_helper
INFO - 2023-09-25 17:03:26 --> Helper loaded: security_helper
INFO - 2023-09-25 17:03:26 --> Helper loaded: cookie_helper
INFO - 2023-09-25 17:03:26 --> Database Driver Class Initialized
INFO - 2023-09-25 17:03:26 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-25 17:03:26 --> Parser Class Initialized
INFO - 2023-09-25 17:03:26 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-25 17:03:26 --> Pagination Class Initialized
INFO - 2023-09-25 17:03:26 --> Form Validation Class Initialized
INFO - 2023-09-25 17:03:26 --> Controller Class Initialized
INFO - 2023-09-25 17:03:26 --> Model Class Initialized
DEBUG - 2023-09-25 17:03:26 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-09-25 17:03:26 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-25 17:03:26 --> Model Class Initialized
DEBUG - 2023-09-25 17:03:26 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-25 17:03:26 --> Model Class Initialized
INFO - 2023-09-25 17:03:26 --> Final output sent to browser
DEBUG - 2023-09-25 17:03:26 --> Total execution time: 0.0504
ERROR - 2023-09-25 17:03:27 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-25 17:03:27 --> Config Class Initialized
INFO - 2023-09-25 17:03:27 --> Hooks Class Initialized
DEBUG - 2023-09-25 17:03:27 --> UTF-8 Support Enabled
INFO - 2023-09-25 17:03:27 --> Utf8 Class Initialized
INFO - 2023-09-25 17:03:27 --> URI Class Initialized
INFO - 2023-09-25 17:03:27 --> Router Class Initialized
INFO - 2023-09-25 17:03:27 --> Output Class Initialized
INFO - 2023-09-25 17:03:27 --> Security Class Initialized
DEBUG - 2023-09-25 17:03:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-25 17:03:27 --> Input Class Initialized
INFO - 2023-09-25 17:03:27 --> Language Class Initialized
INFO - 2023-09-25 17:03:27 --> Loader Class Initialized
INFO - 2023-09-25 17:03:27 --> Helper loaded: url_helper
INFO - 2023-09-25 17:03:27 --> Helper loaded: file_helper
INFO - 2023-09-25 17:03:27 --> Helper loaded: html_helper
INFO - 2023-09-25 17:03:27 --> Helper loaded: text_helper
INFO - 2023-09-25 17:03:27 --> Helper loaded: form_helper
INFO - 2023-09-25 17:03:27 --> Helper loaded: lang_helper
INFO - 2023-09-25 17:03:27 --> Helper loaded: security_helper
INFO - 2023-09-25 17:03:27 --> Helper loaded: cookie_helper
INFO - 2023-09-25 17:03:27 --> Database Driver Class Initialized
INFO - 2023-09-25 17:03:27 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-25 17:03:27 --> Parser Class Initialized
INFO - 2023-09-25 17:03:27 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-25 17:03:27 --> Pagination Class Initialized
INFO - 2023-09-25 17:03:27 --> Form Validation Class Initialized
INFO - 2023-09-25 17:03:27 --> Controller Class Initialized
INFO - 2023-09-25 17:03:27 --> Model Class Initialized
DEBUG - 2023-09-25 17:03:27 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-09-25 17:03:27 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-25 17:03:27 --> Model Class Initialized
DEBUG - 2023-09-25 17:03:27 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-25 17:03:27 --> Model Class Initialized
INFO - 2023-09-25 17:03:27 --> Final output sent to browser
DEBUG - 2023-09-25 17:03:27 --> Total execution time: 0.0507
ERROR - 2023-09-25 17:03:28 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-25 17:03:28 --> Config Class Initialized
INFO - 2023-09-25 17:03:28 --> Hooks Class Initialized
DEBUG - 2023-09-25 17:03:28 --> UTF-8 Support Enabled
INFO - 2023-09-25 17:03:28 --> Utf8 Class Initialized
INFO - 2023-09-25 17:03:28 --> URI Class Initialized
INFO - 2023-09-25 17:03:28 --> Router Class Initialized
INFO - 2023-09-25 17:03:28 --> Output Class Initialized
INFO - 2023-09-25 17:03:28 --> Security Class Initialized
DEBUG - 2023-09-25 17:03:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-25 17:03:28 --> Input Class Initialized
INFO - 2023-09-25 17:03:28 --> Language Class Initialized
INFO - 2023-09-25 17:03:28 --> Loader Class Initialized
INFO - 2023-09-25 17:03:28 --> Helper loaded: url_helper
INFO - 2023-09-25 17:03:28 --> Helper loaded: file_helper
INFO - 2023-09-25 17:03:28 --> Helper loaded: html_helper
INFO - 2023-09-25 17:03:28 --> Helper loaded: text_helper
INFO - 2023-09-25 17:03:28 --> Helper loaded: form_helper
INFO - 2023-09-25 17:03:28 --> Helper loaded: lang_helper
INFO - 2023-09-25 17:03:28 --> Helper loaded: security_helper
INFO - 2023-09-25 17:03:28 --> Helper loaded: cookie_helper
INFO - 2023-09-25 17:03:28 --> Database Driver Class Initialized
INFO - 2023-09-25 17:03:28 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-25 17:03:28 --> Parser Class Initialized
INFO - 2023-09-25 17:03:28 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-25 17:03:28 --> Pagination Class Initialized
INFO - 2023-09-25 17:03:28 --> Form Validation Class Initialized
INFO - 2023-09-25 17:03:28 --> Controller Class Initialized
INFO - 2023-09-25 17:03:28 --> Model Class Initialized
DEBUG - 2023-09-25 17:03:28 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-09-25 17:03:28 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-25 17:03:28 --> Model Class Initialized
DEBUG - 2023-09-25 17:03:28 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-25 17:03:28 --> Model Class Initialized
INFO - 2023-09-25 17:03:28 --> Final output sent to browser
DEBUG - 2023-09-25 17:03:28 --> Total execution time: 0.0529
ERROR - 2023-09-25 17:03:28 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-25 17:03:28 --> Config Class Initialized
INFO - 2023-09-25 17:03:28 --> Hooks Class Initialized
DEBUG - 2023-09-25 17:03:28 --> UTF-8 Support Enabled
INFO - 2023-09-25 17:03:28 --> Utf8 Class Initialized
INFO - 2023-09-25 17:03:28 --> URI Class Initialized
INFO - 2023-09-25 17:03:28 --> Router Class Initialized
INFO - 2023-09-25 17:03:28 --> Output Class Initialized
INFO - 2023-09-25 17:03:28 --> Security Class Initialized
DEBUG - 2023-09-25 17:03:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-25 17:03:28 --> Input Class Initialized
INFO - 2023-09-25 17:03:28 --> Language Class Initialized
INFO - 2023-09-25 17:03:28 --> Loader Class Initialized
INFO - 2023-09-25 17:03:28 --> Helper loaded: url_helper
INFO - 2023-09-25 17:03:28 --> Helper loaded: file_helper
INFO - 2023-09-25 17:03:28 --> Helper loaded: html_helper
INFO - 2023-09-25 17:03:28 --> Helper loaded: text_helper
INFO - 2023-09-25 17:03:28 --> Helper loaded: form_helper
INFO - 2023-09-25 17:03:28 --> Helper loaded: lang_helper
INFO - 2023-09-25 17:03:28 --> Helper loaded: security_helper
INFO - 2023-09-25 17:03:28 --> Helper loaded: cookie_helper
INFO - 2023-09-25 17:03:28 --> Database Driver Class Initialized
INFO - 2023-09-25 17:03:28 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-25 17:03:28 --> Parser Class Initialized
INFO - 2023-09-25 17:03:28 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-25 17:03:28 --> Pagination Class Initialized
INFO - 2023-09-25 17:03:28 --> Form Validation Class Initialized
INFO - 2023-09-25 17:03:28 --> Controller Class Initialized
INFO - 2023-09-25 17:03:28 --> Model Class Initialized
DEBUG - 2023-09-25 17:03:28 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-09-25 17:03:28 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-25 17:03:28 --> Model Class Initialized
DEBUG - 2023-09-25 17:03:28 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-25 17:03:28 --> Model Class Initialized
INFO - 2023-09-25 17:03:28 --> Final output sent to browser
DEBUG - 2023-09-25 17:03:28 --> Total execution time: 0.0508
ERROR - 2023-09-25 17:03:29 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-25 17:03:29 --> Config Class Initialized
INFO - 2023-09-25 17:03:29 --> Hooks Class Initialized
DEBUG - 2023-09-25 17:03:29 --> UTF-8 Support Enabled
INFO - 2023-09-25 17:03:29 --> Utf8 Class Initialized
INFO - 2023-09-25 17:03:29 --> URI Class Initialized
INFO - 2023-09-25 17:03:29 --> Router Class Initialized
INFO - 2023-09-25 17:03:29 --> Output Class Initialized
INFO - 2023-09-25 17:03:29 --> Security Class Initialized
DEBUG - 2023-09-25 17:03:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-25 17:03:29 --> Input Class Initialized
INFO - 2023-09-25 17:03:29 --> Language Class Initialized
INFO - 2023-09-25 17:03:29 --> Loader Class Initialized
INFO - 2023-09-25 17:03:29 --> Helper loaded: url_helper
INFO - 2023-09-25 17:03:29 --> Helper loaded: file_helper
INFO - 2023-09-25 17:03:29 --> Helper loaded: html_helper
INFO - 2023-09-25 17:03:29 --> Helper loaded: text_helper
INFO - 2023-09-25 17:03:29 --> Helper loaded: form_helper
INFO - 2023-09-25 17:03:29 --> Helper loaded: lang_helper
INFO - 2023-09-25 17:03:29 --> Helper loaded: security_helper
INFO - 2023-09-25 17:03:29 --> Helper loaded: cookie_helper
INFO - 2023-09-25 17:03:29 --> Database Driver Class Initialized
INFO - 2023-09-25 17:03:29 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-25 17:03:29 --> Parser Class Initialized
INFO - 2023-09-25 17:03:29 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-25 17:03:29 --> Pagination Class Initialized
INFO - 2023-09-25 17:03:29 --> Form Validation Class Initialized
INFO - 2023-09-25 17:03:29 --> Controller Class Initialized
INFO - 2023-09-25 17:03:29 --> Model Class Initialized
DEBUG - 2023-09-25 17:03:29 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-09-25 17:03:29 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-25 17:03:29 --> Model Class Initialized
DEBUG - 2023-09-25 17:03:29 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-25 17:03:29 --> Model Class Initialized
INFO - 2023-09-25 17:03:29 --> Final output sent to browser
DEBUG - 2023-09-25 17:03:29 --> Total execution time: 0.0337
ERROR - 2023-09-25 17:03:36 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-25 17:03:36 --> Config Class Initialized
INFO - 2023-09-25 17:03:36 --> Hooks Class Initialized
DEBUG - 2023-09-25 17:03:36 --> UTF-8 Support Enabled
INFO - 2023-09-25 17:03:36 --> Utf8 Class Initialized
INFO - 2023-09-25 17:03:36 --> URI Class Initialized
INFO - 2023-09-25 17:03:36 --> Router Class Initialized
INFO - 2023-09-25 17:03:36 --> Output Class Initialized
INFO - 2023-09-25 17:03:36 --> Security Class Initialized
DEBUG - 2023-09-25 17:03:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-25 17:03:36 --> Input Class Initialized
INFO - 2023-09-25 17:03:36 --> Language Class Initialized
INFO - 2023-09-25 17:03:36 --> Loader Class Initialized
INFO - 2023-09-25 17:03:36 --> Helper loaded: url_helper
INFO - 2023-09-25 17:03:36 --> Helper loaded: file_helper
INFO - 2023-09-25 17:03:36 --> Helper loaded: html_helper
INFO - 2023-09-25 17:03:36 --> Helper loaded: text_helper
INFO - 2023-09-25 17:03:36 --> Helper loaded: form_helper
INFO - 2023-09-25 17:03:36 --> Helper loaded: lang_helper
INFO - 2023-09-25 17:03:36 --> Helper loaded: security_helper
INFO - 2023-09-25 17:03:36 --> Helper loaded: cookie_helper
INFO - 2023-09-25 17:03:36 --> Database Driver Class Initialized
INFO - 2023-09-25 17:03:36 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-25 17:03:36 --> Parser Class Initialized
INFO - 2023-09-25 17:03:36 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-25 17:03:36 --> Pagination Class Initialized
INFO - 2023-09-25 17:03:36 --> Form Validation Class Initialized
INFO - 2023-09-25 17:03:36 --> Controller Class Initialized
INFO - 2023-09-25 17:03:36 --> Model Class Initialized
DEBUG - 2023-09-25 17:03:36 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-09-25 17:03:36 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-25 17:03:36 --> Model Class Initialized
DEBUG - 2023-09-25 17:03:36 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-25 17:03:36 --> Model Class Initialized
DEBUG - 2023-09-25 17:03:36 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-25 17:03:36 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice_html.php
DEBUG - 2023-09-25 17:03:36 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-09-25 17:03:36 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-09-25 17:03:36 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-09-25 17:03:36 --> Model Class Initialized
INFO - 2023-09-25 17:03:36 --> Model Class Initialized
INFO - 2023-09-25 17:03:36 --> Model Class Initialized
INFO - 2023-09-25 17:03:36 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-09-25 17:03:36 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-09-25 17:03:36 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-09-25 17:03:36 --> Final output sent to browser
DEBUG - 2023-09-25 17:03:36 --> Total execution time: 0.1476
ERROR - 2023-09-25 17:04:04 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-25 17:04:04 --> Config Class Initialized
INFO - 2023-09-25 17:04:04 --> Hooks Class Initialized
DEBUG - 2023-09-25 17:04:04 --> UTF-8 Support Enabled
INFO - 2023-09-25 17:04:04 --> Utf8 Class Initialized
INFO - 2023-09-25 17:04:04 --> URI Class Initialized
INFO - 2023-09-25 17:04:04 --> Router Class Initialized
INFO - 2023-09-25 17:04:04 --> Output Class Initialized
INFO - 2023-09-25 17:04:04 --> Security Class Initialized
DEBUG - 2023-09-25 17:04:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-25 17:04:04 --> Input Class Initialized
INFO - 2023-09-25 17:04:04 --> Language Class Initialized
INFO - 2023-09-25 17:04:04 --> Loader Class Initialized
INFO - 2023-09-25 17:04:04 --> Helper loaded: url_helper
INFO - 2023-09-25 17:04:04 --> Helper loaded: file_helper
INFO - 2023-09-25 17:04:04 --> Helper loaded: html_helper
INFO - 2023-09-25 17:04:04 --> Helper loaded: text_helper
INFO - 2023-09-25 17:04:04 --> Helper loaded: form_helper
INFO - 2023-09-25 17:04:04 --> Helper loaded: lang_helper
INFO - 2023-09-25 17:04:04 --> Helper loaded: security_helper
INFO - 2023-09-25 17:04:04 --> Helper loaded: cookie_helper
INFO - 2023-09-25 17:04:04 --> Database Driver Class Initialized
INFO - 2023-09-25 17:04:04 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-25 17:04:04 --> Parser Class Initialized
INFO - 2023-09-25 17:04:04 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-25 17:04:04 --> Pagination Class Initialized
INFO - 2023-09-25 17:04:04 --> Form Validation Class Initialized
INFO - 2023-09-25 17:04:04 --> Controller Class Initialized
INFO - 2023-09-25 17:04:04 --> Model Class Initialized
INFO - 2023-09-25 17:04:04 --> Model Class Initialized
INFO - 2023-09-25 17:04:04 --> Model Class Initialized
INFO - 2023-09-25 17:04:04 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/report/stock_report_batch_wise.php
DEBUG - 2023-09-25 17:04:04 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-09-25 17:04:04 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-09-25 17:04:04 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-09-25 17:04:04 --> Model Class Initialized
INFO - 2023-09-25 17:04:04 --> Model Class Initialized
INFO - 2023-09-25 17:04:04 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-09-25 17:04:04 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-09-25 17:04:04 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-09-25 17:04:04 --> Final output sent to browser
DEBUG - 2023-09-25 17:04:04 --> Total execution time: 0.1621
ERROR - 2023-09-25 17:04:05 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-25 17:04:05 --> Config Class Initialized
INFO - 2023-09-25 17:04:05 --> Hooks Class Initialized
DEBUG - 2023-09-25 17:04:05 --> UTF-8 Support Enabled
INFO - 2023-09-25 17:04:05 --> Utf8 Class Initialized
INFO - 2023-09-25 17:04:05 --> URI Class Initialized
INFO - 2023-09-25 17:04:05 --> Router Class Initialized
INFO - 2023-09-25 17:04:05 --> Output Class Initialized
INFO - 2023-09-25 17:04:05 --> Security Class Initialized
DEBUG - 2023-09-25 17:04:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-25 17:04:05 --> Input Class Initialized
INFO - 2023-09-25 17:04:05 --> Language Class Initialized
INFO - 2023-09-25 17:04:05 --> Loader Class Initialized
INFO - 2023-09-25 17:04:05 --> Helper loaded: url_helper
INFO - 2023-09-25 17:04:05 --> Helper loaded: file_helper
INFO - 2023-09-25 17:04:05 --> Helper loaded: html_helper
INFO - 2023-09-25 17:04:05 --> Helper loaded: text_helper
INFO - 2023-09-25 17:04:05 --> Helper loaded: form_helper
INFO - 2023-09-25 17:04:05 --> Helper loaded: lang_helper
INFO - 2023-09-25 17:04:05 --> Helper loaded: security_helper
INFO - 2023-09-25 17:04:05 --> Helper loaded: cookie_helper
INFO - 2023-09-25 17:04:05 --> Database Driver Class Initialized
INFO - 2023-09-25 17:04:05 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-25 17:04:05 --> Parser Class Initialized
INFO - 2023-09-25 17:04:05 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-25 17:04:05 --> Pagination Class Initialized
INFO - 2023-09-25 17:04:05 --> Form Validation Class Initialized
INFO - 2023-09-25 17:04:05 --> Controller Class Initialized
INFO - 2023-09-25 17:04:05 --> Model Class Initialized
INFO - 2023-09-25 17:04:05 --> Model Class Initialized
INFO - 2023-09-25 17:04:05 --> Final output sent to browser
DEBUG - 2023-09-25 17:04:05 --> Total execution time: 0.0253
ERROR - 2023-09-25 17:04:09 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-25 17:04:09 --> Config Class Initialized
INFO - 2023-09-25 17:04:09 --> Hooks Class Initialized
DEBUG - 2023-09-25 17:04:09 --> UTF-8 Support Enabled
INFO - 2023-09-25 17:04:09 --> Utf8 Class Initialized
INFO - 2023-09-25 17:04:09 --> URI Class Initialized
INFO - 2023-09-25 17:04:09 --> Router Class Initialized
INFO - 2023-09-25 17:04:09 --> Output Class Initialized
INFO - 2023-09-25 17:04:09 --> Security Class Initialized
DEBUG - 2023-09-25 17:04:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-25 17:04:09 --> Input Class Initialized
INFO - 2023-09-25 17:04:09 --> Language Class Initialized
INFO - 2023-09-25 17:04:09 --> Loader Class Initialized
INFO - 2023-09-25 17:04:09 --> Helper loaded: url_helper
INFO - 2023-09-25 17:04:09 --> Helper loaded: file_helper
INFO - 2023-09-25 17:04:09 --> Helper loaded: html_helper
INFO - 2023-09-25 17:04:09 --> Helper loaded: text_helper
INFO - 2023-09-25 17:04:09 --> Helper loaded: form_helper
INFO - 2023-09-25 17:04:09 --> Helper loaded: lang_helper
INFO - 2023-09-25 17:04:09 --> Helper loaded: security_helper
INFO - 2023-09-25 17:04:09 --> Helper loaded: cookie_helper
INFO - 2023-09-25 17:04:09 --> Database Driver Class Initialized
INFO - 2023-09-25 17:04:09 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-25 17:04:09 --> Parser Class Initialized
INFO - 2023-09-25 17:04:09 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-25 17:04:09 --> Pagination Class Initialized
INFO - 2023-09-25 17:04:09 --> Form Validation Class Initialized
INFO - 2023-09-25 17:04:09 --> Controller Class Initialized
DEBUG - 2023-09-25 17:04:09 --> Auth class already loaded. Second attempt ignored.
INFO - 2023-09-25 17:04:09 --> Model Class Initialized
INFO - 2023-09-25 17:04:09 --> Model Class Initialized
INFO - 2023-09-25 17:04:09 --> Model Class Initialized
INFO - 2023-09-25 17:04:09 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/product/product_details.php
DEBUG - 2023-09-25 17:04:09 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-09-25 17:04:09 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-09-25 17:04:09 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-09-25 17:04:09 --> Model Class Initialized
INFO - 2023-09-25 17:04:09 --> Model Class Initialized
INFO - 2023-09-25 17:04:09 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-09-25 17:04:09 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-09-25 17:04:09 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-09-25 17:04:09 --> Final output sent to browser
DEBUG - 2023-09-25 17:04:09 --> Total execution time: 0.2100
ERROR - 2023-09-25 17:04:47 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-25 17:04:47 --> Config Class Initialized
INFO - 2023-09-25 17:04:47 --> Hooks Class Initialized
DEBUG - 2023-09-25 17:04:47 --> UTF-8 Support Enabled
INFO - 2023-09-25 17:04:47 --> Utf8 Class Initialized
INFO - 2023-09-25 17:04:47 --> URI Class Initialized
INFO - 2023-09-25 17:04:47 --> Router Class Initialized
INFO - 2023-09-25 17:04:47 --> Output Class Initialized
INFO - 2023-09-25 17:04:47 --> Security Class Initialized
DEBUG - 2023-09-25 17:04:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-25 17:04:47 --> Input Class Initialized
INFO - 2023-09-25 17:04:47 --> Language Class Initialized
INFO - 2023-09-25 17:04:47 --> Loader Class Initialized
INFO - 2023-09-25 17:04:47 --> Helper loaded: url_helper
INFO - 2023-09-25 17:04:47 --> Helper loaded: file_helper
INFO - 2023-09-25 17:04:47 --> Helper loaded: html_helper
INFO - 2023-09-25 17:04:47 --> Helper loaded: text_helper
INFO - 2023-09-25 17:04:47 --> Helper loaded: form_helper
INFO - 2023-09-25 17:04:47 --> Helper loaded: lang_helper
INFO - 2023-09-25 17:04:47 --> Helper loaded: security_helper
INFO - 2023-09-25 17:04:47 --> Helper loaded: cookie_helper
INFO - 2023-09-25 17:04:47 --> Database Driver Class Initialized
INFO - 2023-09-25 17:04:47 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-25 17:04:47 --> Parser Class Initialized
INFO - 2023-09-25 17:04:47 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-25 17:04:47 --> Pagination Class Initialized
INFO - 2023-09-25 17:04:47 --> Form Validation Class Initialized
INFO - 2023-09-25 17:04:47 --> Controller Class Initialized
DEBUG - 2023-09-25 17:04:47 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-09-25 17:04:47 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-25 17:04:47 --> Model Class Initialized
DEBUG - 2023-09-25 17:04:47 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-25 17:04:47 --> Model Class Initialized
INFO - 2023-09-25 17:04:47 --> Model Class Initialized
INFO - 2023-09-25 17:04:47 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/customer/customer_details.php
DEBUG - 2023-09-25 17:04:47 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-09-25 17:04:47 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-09-25 17:04:47 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-09-25 17:04:47 --> Model Class Initialized
INFO - 2023-09-25 17:04:47 --> Model Class Initialized
INFO - 2023-09-25 17:04:47 --> Model Class Initialized
INFO - 2023-09-25 17:04:47 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-09-25 17:04:47 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-09-25 17:04:47 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-09-25 17:04:47 --> Final output sent to browser
DEBUG - 2023-09-25 17:04:47 --> Total execution time: 0.1425
ERROR - 2023-09-25 17:05:06 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-25 17:05:06 --> Config Class Initialized
INFO - 2023-09-25 17:05:06 --> Hooks Class Initialized
DEBUG - 2023-09-25 17:05:06 --> UTF-8 Support Enabled
INFO - 2023-09-25 17:05:06 --> Utf8 Class Initialized
INFO - 2023-09-25 17:05:06 --> URI Class Initialized
INFO - 2023-09-25 17:05:06 --> Router Class Initialized
INFO - 2023-09-25 17:05:06 --> Output Class Initialized
INFO - 2023-09-25 17:05:06 --> Security Class Initialized
DEBUG - 2023-09-25 17:05:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-25 17:05:06 --> Input Class Initialized
INFO - 2023-09-25 17:05:06 --> Language Class Initialized
INFO - 2023-09-25 17:05:06 --> Loader Class Initialized
INFO - 2023-09-25 17:05:06 --> Helper loaded: url_helper
INFO - 2023-09-25 17:05:06 --> Helper loaded: file_helper
INFO - 2023-09-25 17:05:06 --> Helper loaded: html_helper
INFO - 2023-09-25 17:05:06 --> Helper loaded: text_helper
INFO - 2023-09-25 17:05:06 --> Helper loaded: form_helper
INFO - 2023-09-25 17:05:06 --> Helper loaded: lang_helper
INFO - 2023-09-25 17:05:06 --> Helper loaded: security_helper
INFO - 2023-09-25 17:05:06 --> Helper loaded: cookie_helper
INFO - 2023-09-25 17:05:06 --> Database Driver Class Initialized
INFO - 2023-09-25 17:05:06 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-25 17:05:06 --> Parser Class Initialized
INFO - 2023-09-25 17:05:06 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-25 17:05:06 --> Pagination Class Initialized
INFO - 2023-09-25 17:05:06 --> Form Validation Class Initialized
INFO - 2023-09-25 17:05:06 --> Controller Class Initialized
DEBUG - 2023-09-25 17:05:06 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-09-25 17:05:06 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-25 17:05:06 --> Model Class Initialized
DEBUG - 2023-09-25 17:05:06 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-25 17:05:06 --> Model Class Initialized
DEBUG - 2023-09-25 17:05:06 --> Lcustomer class already loaded. Second attempt ignored.
INFO - 2023-09-25 17:05:06 --> Model Class Initialized
INFO - 2023-09-25 17:05:06 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/customer/customer.php
DEBUG - 2023-09-25 17:05:06 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-09-25 17:05:06 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-09-25 17:05:06 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-09-25 17:05:06 --> Model Class Initialized
INFO - 2023-09-25 17:05:06 --> Model Class Initialized
INFO - 2023-09-25 17:05:06 --> Model Class Initialized
INFO - 2023-09-25 17:05:06 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-09-25 17:05:06 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-09-25 17:05:06 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-09-25 17:05:06 --> Final output sent to browser
DEBUG - 2023-09-25 17:05:06 --> Total execution time: 0.1444
ERROR - 2023-09-25 17:05:08 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-25 17:05:08 --> Config Class Initialized
INFO - 2023-09-25 17:05:08 --> Hooks Class Initialized
DEBUG - 2023-09-25 17:05:08 --> UTF-8 Support Enabled
INFO - 2023-09-25 17:05:08 --> Utf8 Class Initialized
INFO - 2023-09-25 17:05:08 --> URI Class Initialized
INFO - 2023-09-25 17:05:08 --> Router Class Initialized
INFO - 2023-09-25 17:05:08 --> Output Class Initialized
INFO - 2023-09-25 17:05:08 --> Security Class Initialized
DEBUG - 2023-09-25 17:05:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-25 17:05:08 --> Input Class Initialized
INFO - 2023-09-25 17:05:08 --> Language Class Initialized
INFO - 2023-09-25 17:05:08 --> Loader Class Initialized
INFO - 2023-09-25 17:05:08 --> Helper loaded: url_helper
INFO - 2023-09-25 17:05:08 --> Helper loaded: file_helper
INFO - 2023-09-25 17:05:08 --> Helper loaded: html_helper
INFO - 2023-09-25 17:05:08 --> Helper loaded: text_helper
INFO - 2023-09-25 17:05:08 --> Helper loaded: form_helper
INFO - 2023-09-25 17:05:08 --> Helper loaded: lang_helper
INFO - 2023-09-25 17:05:08 --> Helper loaded: security_helper
INFO - 2023-09-25 17:05:08 --> Helper loaded: cookie_helper
INFO - 2023-09-25 17:05:08 --> Database Driver Class Initialized
INFO - 2023-09-25 17:05:08 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-25 17:05:08 --> Parser Class Initialized
INFO - 2023-09-25 17:05:08 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-25 17:05:08 --> Pagination Class Initialized
INFO - 2023-09-25 17:05:08 --> Form Validation Class Initialized
INFO - 2023-09-25 17:05:08 --> Controller Class Initialized
DEBUG - 2023-09-25 17:05:08 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-09-25 17:05:08 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-25 17:05:08 --> Model Class Initialized
DEBUG - 2023-09-25 17:05:08 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-25 17:05:08 --> Model Class Initialized
INFO - 2023-09-25 17:05:08 --> Final output sent to browser
DEBUG - 2023-09-25 17:05:08 --> Total execution time: 0.0301
