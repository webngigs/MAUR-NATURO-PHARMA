<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2023-04-22 03:47:23 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-22 03:47:23 --> Config Class Initialized
INFO - 2023-04-22 03:47:23 --> Hooks Class Initialized
DEBUG - 2023-04-22 03:47:23 --> UTF-8 Support Enabled
INFO - 2023-04-22 03:47:23 --> Utf8 Class Initialized
INFO - 2023-04-22 03:47:23 --> URI Class Initialized
DEBUG - 2023-04-22 03:47:23 --> No URI present. Default controller set.
INFO - 2023-04-22 03:47:23 --> Router Class Initialized
INFO - 2023-04-22 03:47:23 --> Output Class Initialized
INFO - 2023-04-22 03:47:23 --> Security Class Initialized
DEBUG - 2023-04-22 03:47:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-22 03:47:23 --> Input Class Initialized
INFO - 2023-04-22 03:47:23 --> Language Class Initialized
INFO - 2023-04-22 03:47:23 --> Loader Class Initialized
INFO - 2023-04-22 03:47:23 --> Helper loaded: url_helper
INFO - 2023-04-22 03:47:23 --> Helper loaded: file_helper
INFO - 2023-04-22 03:47:23 --> Helper loaded: html_helper
INFO - 2023-04-22 03:47:23 --> Helper loaded: text_helper
INFO - 2023-04-22 03:47:23 --> Helper loaded: form_helper
INFO - 2023-04-22 03:47:23 --> Helper loaded: lang_helper
INFO - 2023-04-22 03:47:23 --> Helper loaded: security_helper
INFO - 2023-04-22 03:47:23 --> Helper loaded: cookie_helper
INFO - 2023-04-22 03:47:23 --> Database Driver Class Initialized
INFO - 2023-04-22 03:47:23 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-22 03:47:23 --> Parser Class Initialized
INFO - 2023-04-22 03:47:23 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-22 03:47:23 --> Pagination Class Initialized
INFO - 2023-04-22 03:47:23 --> Form Validation Class Initialized
INFO - 2023-04-22 03:47:23 --> Controller Class Initialized
INFO - 2023-04-22 03:47:23 --> Model Class Initialized
DEBUG - 2023-04-22 03:47:23 --> Session class already loaded. Second attempt ignored.
ERROR - 2023-04-22 03:47:23 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-22 03:47:23 --> Config Class Initialized
INFO - 2023-04-22 03:47:23 --> Hooks Class Initialized
DEBUG - 2023-04-22 03:47:23 --> UTF-8 Support Enabled
INFO - 2023-04-22 03:47:23 --> Utf8 Class Initialized
INFO - 2023-04-22 03:47:23 --> URI Class Initialized
INFO - 2023-04-22 03:47:23 --> Router Class Initialized
INFO - 2023-04-22 03:47:23 --> Output Class Initialized
INFO - 2023-04-22 03:47:23 --> Security Class Initialized
DEBUG - 2023-04-22 03:47:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-22 03:47:23 --> Input Class Initialized
INFO - 2023-04-22 03:47:23 --> Language Class Initialized
INFO - 2023-04-22 03:47:23 --> Loader Class Initialized
INFO - 2023-04-22 03:47:23 --> Helper loaded: url_helper
INFO - 2023-04-22 03:47:23 --> Helper loaded: file_helper
INFO - 2023-04-22 03:47:23 --> Helper loaded: html_helper
INFO - 2023-04-22 03:47:23 --> Helper loaded: text_helper
INFO - 2023-04-22 03:47:23 --> Helper loaded: form_helper
INFO - 2023-04-22 03:47:23 --> Helper loaded: lang_helper
INFO - 2023-04-22 03:47:23 --> Helper loaded: security_helper
INFO - 2023-04-22 03:47:23 --> Helper loaded: cookie_helper
INFO - 2023-04-22 03:47:23 --> Database Driver Class Initialized
INFO - 2023-04-22 03:47:23 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-22 03:47:23 --> Parser Class Initialized
INFO - 2023-04-22 03:47:23 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-22 03:47:23 --> Pagination Class Initialized
INFO - 2023-04-22 03:47:23 --> Form Validation Class Initialized
INFO - 2023-04-22 03:47:23 --> Controller Class Initialized
INFO - 2023-04-22 03:47:23 --> Model Class Initialized
DEBUG - 2023-04-22 03:47:23 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-22 03:47:23 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2023-04-22 03:47:23 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-04-22 03:47:23 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-04-22 03:47:23 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-04-22 03:47:23 --> Model Class Initialized
INFO - 2023-04-22 03:47:23 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-04-22 03:47:23 --> Final output sent to browser
DEBUG - 2023-04-22 03:47:23 --> Total execution time: 0.0326
ERROR - 2023-04-22 04:32:23 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-22 04:32:23 --> Config Class Initialized
INFO - 2023-04-22 04:32:23 --> Hooks Class Initialized
DEBUG - 2023-04-22 04:32:23 --> UTF-8 Support Enabled
INFO - 2023-04-22 04:32:23 --> Utf8 Class Initialized
INFO - 2023-04-22 04:32:23 --> URI Class Initialized
DEBUG - 2023-04-22 04:32:23 --> No URI present. Default controller set.
INFO - 2023-04-22 04:32:23 --> Router Class Initialized
INFO - 2023-04-22 04:32:23 --> Output Class Initialized
INFO - 2023-04-22 04:32:23 --> Security Class Initialized
DEBUG - 2023-04-22 04:32:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-22 04:32:23 --> Input Class Initialized
INFO - 2023-04-22 04:32:23 --> Language Class Initialized
INFO - 2023-04-22 04:32:23 --> Loader Class Initialized
INFO - 2023-04-22 04:32:23 --> Helper loaded: url_helper
INFO - 2023-04-22 04:32:23 --> Helper loaded: file_helper
INFO - 2023-04-22 04:32:23 --> Helper loaded: html_helper
INFO - 2023-04-22 04:32:23 --> Helper loaded: text_helper
INFO - 2023-04-22 04:32:23 --> Helper loaded: form_helper
INFO - 2023-04-22 04:32:23 --> Helper loaded: lang_helper
INFO - 2023-04-22 04:32:23 --> Helper loaded: security_helper
INFO - 2023-04-22 04:32:23 --> Helper loaded: cookie_helper
INFO - 2023-04-22 04:32:23 --> Database Driver Class Initialized
INFO - 2023-04-22 04:32:23 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-22 04:32:23 --> Parser Class Initialized
INFO - 2023-04-22 04:32:23 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-22 04:32:23 --> Pagination Class Initialized
INFO - 2023-04-22 04:32:23 --> Form Validation Class Initialized
INFO - 2023-04-22 04:32:23 --> Controller Class Initialized
INFO - 2023-04-22 04:32:23 --> Model Class Initialized
DEBUG - 2023-04-22 04:32:23 --> Session class already loaded. Second attempt ignored.
ERROR - 2023-04-22 08:31:30 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-22 08:31:30 --> Config Class Initialized
INFO - 2023-04-22 08:31:30 --> Hooks Class Initialized
DEBUG - 2023-04-22 08:31:30 --> UTF-8 Support Enabled
INFO - 2023-04-22 08:31:30 --> Utf8 Class Initialized
INFO - 2023-04-22 08:31:30 --> URI Class Initialized
DEBUG - 2023-04-22 08:31:30 --> No URI present. Default controller set.
INFO - 2023-04-22 08:31:30 --> Router Class Initialized
INFO - 2023-04-22 08:31:30 --> Output Class Initialized
INFO - 2023-04-22 08:31:30 --> Security Class Initialized
DEBUG - 2023-04-22 08:31:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-22 08:31:30 --> Input Class Initialized
INFO - 2023-04-22 08:31:30 --> Language Class Initialized
INFO - 2023-04-22 08:31:30 --> Loader Class Initialized
INFO - 2023-04-22 08:31:30 --> Helper loaded: url_helper
INFO - 2023-04-22 08:31:30 --> Helper loaded: file_helper
INFO - 2023-04-22 08:31:30 --> Helper loaded: html_helper
INFO - 2023-04-22 08:31:30 --> Helper loaded: text_helper
INFO - 2023-04-22 08:31:30 --> Helper loaded: form_helper
INFO - 2023-04-22 08:31:30 --> Helper loaded: lang_helper
INFO - 2023-04-22 08:31:30 --> Helper loaded: security_helper
INFO - 2023-04-22 08:31:30 --> Helper loaded: cookie_helper
INFO - 2023-04-22 08:31:30 --> Database Driver Class Initialized
INFO - 2023-04-22 08:31:30 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-22 08:31:30 --> Parser Class Initialized
INFO - 2023-04-22 08:31:30 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-22 08:31:30 --> Pagination Class Initialized
INFO - 2023-04-22 08:31:30 --> Form Validation Class Initialized
INFO - 2023-04-22 08:31:30 --> Controller Class Initialized
INFO - 2023-04-22 08:31:30 --> Model Class Initialized
DEBUG - 2023-04-22 08:31:30 --> Session class already loaded. Second attempt ignored.
ERROR - 2023-04-22 08:31:31 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-22 08:31:31 --> Config Class Initialized
INFO - 2023-04-22 08:31:31 --> Hooks Class Initialized
DEBUG - 2023-04-22 08:31:31 --> UTF-8 Support Enabled
INFO - 2023-04-22 08:31:31 --> Utf8 Class Initialized
INFO - 2023-04-22 08:31:31 --> URI Class Initialized
INFO - 2023-04-22 08:31:31 --> Router Class Initialized
INFO - 2023-04-22 08:31:31 --> Output Class Initialized
INFO - 2023-04-22 08:31:31 --> Security Class Initialized
DEBUG - 2023-04-22 08:31:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-22 08:31:31 --> Input Class Initialized
INFO - 2023-04-22 08:31:31 --> Language Class Initialized
INFO - 2023-04-22 08:31:31 --> Loader Class Initialized
INFO - 2023-04-22 08:31:31 --> Helper loaded: url_helper
INFO - 2023-04-22 08:31:31 --> Helper loaded: file_helper
INFO - 2023-04-22 08:31:31 --> Helper loaded: html_helper
INFO - 2023-04-22 08:31:31 --> Helper loaded: text_helper
INFO - 2023-04-22 08:31:31 --> Helper loaded: form_helper
INFO - 2023-04-22 08:31:31 --> Helper loaded: lang_helper
INFO - 2023-04-22 08:31:31 --> Helper loaded: security_helper
INFO - 2023-04-22 08:31:31 --> Helper loaded: cookie_helper
INFO - 2023-04-22 08:31:31 --> Database Driver Class Initialized
INFO - 2023-04-22 08:31:31 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-22 08:31:31 --> Parser Class Initialized
INFO - 2023-04-22 08:31:31 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-22 08:31:31 --> Pagination Class Initialized
INFO - 2023-04-22 08:31:31 --> Form Validation Class Initialized
INFO - 2023-04-22 08:31:31 --> Controller Class Initialized
INFO - 2023-04-22 08:31:31 --> Model Class Initialized
DEBUG - 2023-04-22 08:31:31 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-22 08:31:31 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2023-04-22 08:31:31 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-04-22 08:31:31 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-04-22 08:31:31 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-04-22 08:31:31 --> Model Class Initialized
INFO - 2023-04-22 08:31:31 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-04-22 08:31:31 --> Final output sent to browser
DEBUG - 2023-04-22 08:31:31 --> Total execution time: 0.0336
ERROR - 2023-04-22 10:30:52 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-22 10:30:52 --> Config Class Initialized
INFO - 2023-04-22 10:30:52 --> Hooks Class Initialized
DEBUG - 2023-04-22 10:30:52 --> UTF-8 Support Enabled
INFO - 2023-04-22 10:30:52 --> Utf8 Class Initialized
INFO - 2023-04-22 10:30:52 --> URI Class Initialized
DEBUG - 2023-04-22 10:30:52 --> No URI present. Default controller set.
INFO - 2023-04-22 10:30:52 --> Router Class Initialized
INFO - 2023-04-22 10:30:52 --> Output Class Initialized
INFO - 2023-04-22 10:30:52 --> Security Class Initialized
DEBUG - 2023-04-22 10:30:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-22 10:30:52 --> Input Class Initialized
INFO - 2023-04-22 10:30:52 --> Language Class Initialized
INFO - 2023-04-22 10:30:52 --> Loader Class Initialized
INFO - 2023-04-22 10:30:52 --> Helper loaded: url_helper
INFO - 2023-04-22 10:30:52 --> Helper loaded: file_helper
INFO - 2023-04-22 10:30:52 --> Helper loaded: html_helper
INFO - 2023-04-22 10:30:52 --> Helper loaded: text_helper
INFO - 2023-04-22 10:30:52 --> Helper loaded: form_helper
INFO - 2023-04-22 10:30:52 --> Helper loaded: lang_helper
INFO - 2023-04-22 10:30:52 --> Helper loaded: security_helper
INFO - 2023-04-22 10:30:52 --> Helper loaded: cookie_helper
INFO - 2023-04-22 10:30:52 --> Database Driver Class Initialized
INFO - 2023-04-22 10:30:52 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-22 10:30:52 --> Parser Class Initialized
INFO - 2023-04-22 10:30:52 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-22 10:30:52 --> Pagination Class Initialized
INFO - 2023-04-22 10:30:52 --> Form Validation Class Initialized
INFO - 2023-04-22 10:30:52 --> Controller Class Initialized
INFO - 2023-04-22 10:30:52 --> Model Class Initialized
DEBUG - 2023-04-22 10:30:52 --> Session class already loaded. Second attempt ignored.
ERROR - 2023-04-22 10:30:52 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-22 10:30:52 --> Config Class Initialized
INFO - 2023-04-22 10:30:52 --> Hooks Class Initialized
DEBUG - 2023-04-22 10:30:52 --> UTF-8 Support Enabled
INFO - 2023-04-22 10:30:52 --> Utf8 Class Initialized
INFO - 2023-04-22 10:30:52 --> URI Class Initialized
INFO - 2023-04-22 10:30:52 --> Router Class Initialized
INFO - 2023-04-22 10:30:52 --> Output Class Initialized
INFO - 2023-04-22 10:30:52 --> Security Class Initialized
DEBUG - 2023-04-22 10:30:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-22 10:30:52 --> Input Class Initialized
INFO - 2023-04-22 10:30:52 --> Language Class Initialized
INFO - 2023-04-22 10:30:52 --> Loader Class Initialized
INFO - 2023-04-22 10:30:52 --> Helper loaded: url_helper
INFO - 2023-04-22 10:30:52 --> Helper loaded: file_helper
INFO - 2023-04-22 10:30:52 --> Helper loaded: html_helper
INFO - 2023-04-22 10:30:52 --> Helper loaded: text_helper
INFO - 2023-04-22 10:30:52 --> Helper loaded: form_helper
INFO - 2023-04-22 10:30:52 --> Helper loaded: lang_helper
INFO - 2023-04-22 10:30:52 --> Helper loaded: security_helper
INFO - 2023-04-22 10:30:52 --> Helper loaded: cookie_helper
INFO - 2023-04-22 10:30:52 --> Database Driver Class Initialized
INFO - 2023-04-22 10:30:52 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-22 10:30:52 --> Parser Class Initialized
INFO - 2023-04-22 10:30:52 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-22 10:30:52 --> Pagination Class Initialized
INFO - 2023-04-22 10:30:52 --> Form Validation Class Initialized
INFO - 2023-04-22 10:30:52 --> Controller Class Initialized
INFO - 2023-04-22 10:30:52 --> Model Class Initialized
DEBUG - 2023-04-22 10:30:52 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-22 10:30:52 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2023-04-22 10:30:52 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-04-22 10:30:52 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-04-22 10:30:52 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-04-22 10:30:52 --> Model Class Initialized
INFO - 2023-04-22 10:30:52 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-04-22 10:30:52 --> Final output sent to browser
DEBUG - 2023-04-22 10:30:52 --> Total execution time: 0.0342
ERROR - 2023-04-22 10:31:13 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-22 10:31:13 --> Config Class Initialized
INFO - 2023-04-22 10:31:13 --> Hooks Class Initialized
DEBUG - 2023-04-22 10:31:13 --> UTF-8 Support Enabled
INFO - 2023-04-22 10:31:13 --> Utf8 Class Initialized
INFO - 2023-04-22 10:31:13 --> URI Class Initialized
INFO - 2023-04-22 10:31:13 --> Router Class Initialized
INFO - 2023-04-22 10:31:13 --> Output Class Initialized
INFO - 2023-04-22 10:31:13 --> Security Class Initialized
DEBUG - 2023-04-22 10:31:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-22 10:31:13 --> Input Class Initialized
INFO - 2023-04-22 10:31:13 --> Language Class Initialized
INFO - 2023-04-22 10:31:13 --> Loader Class Initialized
INFO - 2023-04-22 10:31:13 --> Helper loaded: url_helper
INFO - 2023-04-22 10:31:13 --> Helper loaded: file_helper
INFO - 2023-04-22 10:31:13 --> Helper loaded: html_helper
INFO - 2023-04-22 10:31:13 --> Helper loaded: text_helper
INFO - 2023-04-22 10:31:13 --> Helper loaded: form_helper
INFO - 2023-04-22 10:31:13 --> Helper loaded: lang_helper
INFO - 2023-04-22 10:31:13 --> Helper loaded: security_helper
INFO - 2023-04-22 10:31:13 --> Helper loaded: cookie_helper
INFO - 2023-04-22 10:31:13 --> Database Driver Class Initialized
INFO - 2023-04-22 10:31:13 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-22 10:31:13 --> Parser Class Initialized
INFO - 2023-04-22 10:31:13 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-22 10:31:13 --> Pagination Class Initialized
INFO - 2023-04-22 10:31:13 --> Form Validation Class Initialized
INFO - 2023-04-22 10:31:13 --> Controller Class Initialized
INFO - 2023-04-22 10:31:13 --> Model Class Initialized
DEBUG - 2023-04-22 10:31:13 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-22 10:31:13 --> Model Class Initialized
INFO - 2023-04-22 10:31:13 --> Final output sent to browser
DEBUG - 2023-04-22 10:31:13 --> Total execution time: 0.0201
ERROR - 2023-04-22 10:31:14 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-22 10:31:14 --> Config Class Initialized
INFO - 2023-04-22 10:31:14 --> Hooks Class Initialized
DEBUG - 2023-04-22 10:31:14 --> UTF-8 Support Enabled
INFO - 2023-04-22 10:31:14 --> Utf8 Class Initialized
INFO - 2023-04-22 10:31:14 --> URI Class Initialized
DEBUG - 2023-04-22 10:31:14 --> No URI present. Default controller set.
INFO - 2023-04-22 10:31:14 --> Router Class Initialized
INFO - 2023-04-22 10:31:14 --> Output Class Initialized
INFO - 2023-04-22 10:31:14 --> Security Class Initialized
DEBUG - 2023-04-22 10:31:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-22 10:31:14 --> Input Class Initialized
INFO - 2023-04-22 10:31:14 --> Language Class Initialized
INFO - 2023-04-22 10:31:14 --> Loader Class Initialized
INFO - 2023-04-22 10:31:14 --> Helper loaded: url_helper
INFO - 2023-04-22 10:31:14 --> Helper loaded: file_helper
INFO - 2023-04-22 10:31:14 --> Helper loaded: html_helper
INFO - 2023-04-22 10:31:14 --> Helper loaded: text_helper
INFO - 2023-04-22 10:31:14 --> Helper loaded: form_helper
INFO - 2023-04-22 10:31:14 --> Helper loaded: lang_helper
INFO - 2023-04-22 10:31:14 --> Helper loaded: security_helper
INFO - 2023-04-22 10:31:14 --> Helper loaded: cookie_helper
INFO - 2023-04-22 10:31:14 --> Database Driver Class Initialized
INFO - 2023-04-22 10:31:14 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-22 10:31:14 --> Parser Class Initialized
INFO - 2023-04-22 10:31:14 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-22 10:31:14 --> Pagination Class Initialized
INFO - 2023-04-22 10:31:14 --> Form Validation Class Initialized
INFO - 2023-04-22 10:31:14 --> Controller Class Initialized
INFO - 2023-04-22 10:31:14 --> Model Class Initialized
DEBUG - 2023-04-22 10:31:14 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-22 10:31:14 --> Model Class Initialized
DEBUG - 2023-04-22 10:31:14 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-22 10:31:14 --> Model Class Initialized
INFO - 2023-04-22 10:31:14 --> Model Class Initialized
INFO - 2023-04-22 10:31:14 --> Model Class Initialized
INFO - 2023-04-22 10:31:14 --> Model Class Initialized
DEBUG - 2023-04-22 10:31:14 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-04-22 10:31:14 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-22 10:31:14 --> Model Class Initialized
INFO - 2023-04-22 10:31:14 --> Model Class Initialized
INFO - 2023-04-22 10:31:14 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-04-22 10:31:14 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-04-22 10:31:14 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-04-22 10:31:14 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-04-22 10:31:14 --> Model Class Initialized
INFO - 2023-04-22 10:31:14 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-04-22 10:31:14 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-04-22 10:31:14 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-04-22 10:31:14 --> Final output sent to browser
DEBUG - 2023-04-22 10:31:14 --> Total execution time: 0.1692
ERROR - 2023-04-22 10:31:14 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-22 10:31:14 --> Config Class Initialized
INFO - 2023-04-22 10:31:14 --> Hooks Class Initialized
DEBUG - 2023-04-22 10:31:14 --> UTF-8 Support Enabled
INFO - 2023-04-22 10:31:14 --> Utf8 Class Initialized
INFO - 2023-04-22 10:31:14 --> URI Class Initialized
INFO - 2023-04-22 10:31:14 --> Router Class Initialized
INFO - 2023-04-22 10:31:14 --> Output Class Initialized
INFO - 2023-04-22 10:31:14 --> Security Class Initialized
DEBUG - 2023-04-22 10:31:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-22 10:31:14 --> Input Class Initialized
INFO - 2023-04-22 10:31:14 --> Language Class Initialized
INFO - 2023-04-22 10:31:14 --> Loader Class Initialized
INFO - 2023-04-22 10:31:14 --> Helper loaded: url_helper
INFO - 2023-04-22 10:31:14 --> Helper loaded: file_helper
INFO - 2023-04-22 10:31:14 --> Helper loaded: html_helper
INFO - 2023-04-22 10:31:14 --> Helper loaded: text_helper
INFO - 2023-04-22 10:31:14 --> Helper loaded: form_helper
INFO - 2023-04-22 10:31:14 --> Helper loaded: lang_helper
INFO - 2023-04-22 10:31:14 --> Helper loaded: security_helper
INFO - 2023-04-22 10:31:14 --> Helper loaded: cookie_helper
INFO - 2023-04-22 10:31:14 --> Database Driver Class Initialized
INFO - 2023-04-22 10:31:14 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-22 10:31:14 --> Parser Class Initialized
INFO - 2023-04-22 10:31:14 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-22 10:31:14 --> Pagination Class Initialized
INFO - 2023-04-22 10:31:14 --> Form Validation Class Initialized
INFO - 2023-04-22 10:31:14 --> Controller Class Initialized
DEBUG - 2023-04-22 10:31:14 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-04-22 10:31:14 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-22 10:31:14 --> Model Class Initialized
INFO - 2023-04-22 10:31:14 --> Final output sent to browser
DEBUG - 2023-04-22 10:31:14 --> Total execution time: 0.0133
ERROR - 2023-04-22 10:31:30 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-22 10:31:30 --> Config Class Initialized
INFO - 2023-04-22 10:31:30 --> Hooks Class Initialized
DEBUG - 2023-04-22 10:31:30 --> UTF-8 Support Enabled
INFO - 2023-04-22 10:31:30 --> Utf8 Class Initialized
INFO - 2023-04-22 10:31:30 --> URI Class Initialized
INFO - 2023-04-22 10:31:30 --> Router Class Initialized
INFO - 2023-04-22 10:31:30 --> Output Class Initialized
INFO - 2023-04-22 10:31:30 --> Security Class Initialized
DEBUG - 2023-04-22 10:31:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-22 10:31:30 --> Input Class Initialized
INFO - 2023-04-22 10:31:30 --> Language Class Initialized
INFO - 2023-04-22 10:31:30 --> Loader Class Initialized
INFO - 2023-04-22 10:31:30 --> Helper loaded: url_helper
INFO - 2023-04-22 10:31:30 --> Helper loaded: file_helper
INFO - 2023-04-22 10:31:30 --> Helper loaded: html_helper
INFO - 2023-04-22 10:31:30 --> Helper loaded: text_helper
INFO - 2023-04-22 10:31:30 --> Helper loaded: form_helper
INFO - 2023-04-22 10:31:30 --> Helper loaded: lang_helper
INFO - 2023-04-22 10:31:30 --> Helper loaded: security_helper
INFO - 2023-04-22 10:31:30 --> Helper loaded: cookie_helper
INFO - 2023-04-22 10:31:30 --> Database Driver Class Initialized
INFO - 2023-04-22 10:31:30 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-22 10:31:30 --> Parser Class Initialized
INFO - 2023-04-22 10:31:30 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-22 10:31:30 --> Pagination Class Initialized
INFO - 2023-04-22 10:31:30 --> Form Validation Class Initialized
INFO - 2023-04-22 10:31:30 --> Controller Class Initialized
INFO - 2023-04-22 10:31:30 --> Model Class Initialized
DEBUG - 2023-04-22 10:31:30 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-04-22 10:31:30 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-22 10:31:30 --> Model Class Initialized
DEBUG - 2023-04-22 10:31:30 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-22 10:31:30 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/stockrequest/add_stockrequest_form.php
DEBUG - 2023-04-22 10:31:30 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-04-22 10:31:30 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-04-22 10:31:30 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-04-22 10:31:30 --> Model Class Initialized
INFO - 2023-04-22 10:31:30 --> Model Class Initialized
INFO - 2023-04-22 10:31:30 --> Model Class Initialized
INFO - 2023-04-22 10:31:30 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-04-22 10:31:30 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-04-22 10:31:30 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-04-22 10:31:30 --> Final output sent to browser
DEBUG - 2023-04-22 10:31:30 --> Total execution time: 0.1645
ERROR - 2023-04-22 10:31:41 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-22 10:31:41 --> Config Class Initialized
INFO - 2023-04-22 10:31:41 --> Hooks Class Initialized
DEBUG - 2023-04-22 10:31:41 --> UTF-8 Support Enabled
INFO - 2023-04-22 10:31:41 --> Utf8 Class Initialized
INFO - 2023-04-22 10:31:41 --> URI Class Initialized
INFO - 2023-04-22 10:31:41 --> Router Class Initialized
INFO - 2023-04-22 10:31:41 --> Output Class Initialized
INFO - 2023-04-22 10:31:41 --> Security Class Initialized
DEBUG - 2023-04-22 10:31:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-22 10:31:41 --> Input Class Initialized
INFO - 2023-04-22 10:31:41 --> Language Class Initialized
INFO - 2023-04-22 10:31:41 --> Loader Class Initialized
INFO - 2023-04-22 10:31:41 --> Helper loaded: url_helper
INFO - 2023-04-22 10:31:41 --> Helper loaded: file_helper
INFO - 2023-04-22 10:31:41 --> Helper loaded: html_helper
INFO - 2023-04-22 10:31:41 --> Helper loaded: text_helper
INFO - 2023-04-22 10:31:41 --> Helper loaded: form_helper
INFO - 2023-04-22 10:31:41 --> Helper loaded: lang_helper
INFO - 2023-04-22 10:31:41 --> Helper loaded: security_helper
INFO - 2023-04-22 10:31:41 --> Helper loaded: cookie_helper
INFO - 2023-04-22 10:31:41 --> Database Driver Class Initialized
INFO - 2023-04-22 10:31:41 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-22 10:31:41 --> Parser Class Initialized
INFO - 2023-04-22 10:31:41 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-22 10:31:41 --> Pagination Class Initialized
INFO - 2023-04-22 10:31:41 --> Form Validation Class Initialized
INFO - 2023-04-22 10:31:41 --> Controller Class Initialized
INFO - 2023-04-22 10:31:41 --> Model Class Initialized
INFO - 2023-04-22 10:31:41 --> Final output sent to browser
DEBUG - 2023-04-22 10:31:41 --> Total execution time: 0.0144
ERROR - 2023-04-22 10:31:47 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-22 10:31:47 --> Config Class Initialized
INFO - 2023-04-22 10:31:47 --> Hooks Class Initialized
DEBUG - 2023-04-22 10:31:47 --> UTF-8 Support Enabled
INFO - 2023-04-22 10:31:47 --> Utf8 Class Initialized
INFO - 2023-04-22 10:31:47 --> URI Class Initialized
INFO - 2023-04-22 10:31:47 --> Router Class Initialized
INFO - 2023-04-22 10:31:47 --> Output Class Initialized
INFO - 2023-04-22 10:31:47 --> Security Class Initialized
DEBUG - 2023-04-22 10:31:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-22 10:31:47 --> Input Class Initialized
INFO - 2023-04-22 10:31:47 --> Language Class Initialized
INFO - 2023-04-22 10:31:47 --> Loader Class Initialized
INFO - 2023-04-22 10:31:47 --> Helper loaded: url_helper
INFO - 2023-04-22 10:31:47 --> Helper loaded: file_helper
INFO - 2023-04-22 10:31:47 --> Helper loaded: html_helper
INFO - 2023-04-22 10:31:47 --> Helper loaded: text_helper
INFO - 2023-04-22 10:31:47 --> Helper loaded: form_helper
INFO - 2023-04-22 10:31:47 --> Helper loaded: lang_helper
INFO - 2023-04-22 10:31:47 --> Helper loaded: security_helper
INFO - 2023-04-22 10:31:47 --> Helper loaded: cookie_helper
INFO - 2023-04-22 10:31:47 --> Database Driver Class Initialized
INFO - 2023-04-22 10:31:47 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-22 10:31:47 --> Parser Class Initialized
INFO - 2023-04-22 10:31:47 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-22 10:31:47 --> Pagination Class Initialized
INFO - 2023-04-22 10:31:47 --> Form Validation Class Initialized
INFO - 2023-04-22 10:31:47 --> Controller Class Initialized
INFO - 2023-04-22 10:31:47 --> Model Class Initialized
DEBUG - 2023-04-22 10:31:47 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-04-22 10:31:47 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-22 10:31:47 --> Model Class Initialized
DEBUG - 2023-04-22 10:31:47 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-22 10:31:47 --> Model Class Initialized
INFO - 2023-04-22 10:31:47 --> Final output sent to browser
DEBUG - 2023-04-22 10:31:47 --> Total execution time: 0.0179
ERROR - 2023-04-22 10:31:47 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-22 10:31:47 --> Config Class Initialized
INFO - 2023-04-22 10:31:47 --> Hooks Class Initialized
DEBUG - 2023-04-22 10:31:47 --> UTF-8 Support Enabled
INFO - 2023-04-22 10:31:47 --> Utf8 Class Initialized
INFO - 2023-04-22 10:31:47 --> URI Class Initialized
INFO - 2023-04-22 10:31:47 --> Router Class Initialized
INFO - 2023-04-22 10:31:47 --> Output Class Initialized
INFO - 2023-04-22 10:31:47 --> Security Class Initialized
DEBUG - 2023-04-22 10:31:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-22 10:31:47 --> Input Class Initialized
INFO - 2023-04-22 10:31:47 --> Language Class Initialized
INFO - 2023-04-22 10:31:47 --> Loader Class Initialized
INFO - 2023-04-22 10:31:47 --> Helper loaded: url_helper
INFO - 2023-04-22 10:31:47 --> Helper loaded: file_helper
INFO - 2023-04-22 10:31:47 --> Helper loaded: html_helper
INFO - 2023-04-22 10:31:47 --> Helper loaded: text_helper
INFO - 2023-04-22 10:31:47 --> Helper loaded: form_helper
INFO - 2023-04-22 10:31:47 --> Helper loaded: lang_helper
INFO - 2023-04-22 10:31:47 --> Helper loaded: security_helper
INFO - 2023-04-22 10:31:47 --> Helper loaded: cookie_helper
INFO - 2023-04-22 10:31:47 --> Database Driver Class Initialized
INFO - 2023-04-22 10:31:47 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-22 10:31:47 --> Parser Class Initialized
INFO - 2023-04-22 10:31:47 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-22 10:31:47 --> Pagination Class Initialized
INFO - 2023-04-22 10:31:47 --> Form Validation Class Initialized
INFO - 2023-04-22 10:31:47 --> Controller Class Initialized
INFO - 2023-04-22 10:31:47 --> Model Class Initialized
DEBUG - 2023-04-22 10:31:47 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-04-22 10:31:47 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-22 10:31:47 --> Model Class Initialized
DEBUG - 2023-04-22 10:31:47 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-22 10:31:47 --> Model Class Initialized
INFO - 2023-04-22 10:31:47 --> Final output sent to browser
DEBUG - 2023-04-22 10:31:47 --> Total execution time: 0.0163
ERROR - 2023-04-22 10:31:48 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-22 10:31:48 --> Config Class Initialized
INFO - 2023-04-22 10:31:48 --> Hooks Class Initialized
DEBUG - 2023-04-22 10:31:48 --> UTF-8 Support Enabled
INFO - 2023-04-22 10:31:48 --> Utf8 Class Initialized
INFO - 2023-04-22 10:31:48 --> URI Class Initialized
INFO - 2023-04-22 10:31:48 --> Router Class Initialized
INFO - 2023-04-22 10:31:48 --> Output Class Initialized
INFO - 2023-04-22 10:31:48 --> Security Class Initialized
DEBUG - 2023-04-22 10:31:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-22 10:31:48 --> Input Class Initialized
INFO - 2023-04-22 10:31:48 --> Language Class Initialized
INFO - 2023-04-22 10:31:48 --> Loader Class Initialized
INFO - 2023-04-22 10:31:48 --> Helper loaded: url_helper
INFO - 2023-04-22 10:31:48 --> Helper loaded: file_helper
INFO - 2023-04-22 10:31:48 --> Helper loaded: html_helper
INFO - 2023-04-22 10:31:48 --> Helper loaded: text_helper
INFO - 2023-04-22 10:31:48 --> Helper loaded: form_helper
INFO - 2023-04-22 10:31:48 --> Helper loaded: lang_helper
INFO - 2023-04-22 10:31:48 --> Helper loaded: security_helper
INFO - 2023-04-22 10:31:48 --> Helper loaded: cookie_helper
INFO - 2023-04-22 10:31:48 --> Database Driver Class Initialized
INFO - 2023-04-22 10:31:48 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-22 10:31:48 --> Parser Class Initialized
INFO - 2023-04-22 10:31:48 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-22 10:31:48 --> Pagination Class Initialized
INFO - 2023-04-22 10:31:48 --> Form Validation Class Initialized
INFO - 2023-04-22 10:31:48 --> Controller Class Initialized
INFO - 2023-04-22 10:31:48 --> Model Class Initialized
DEBUG - 2023-04-22 10:31:48 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-04-22 10:31:48 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-22 10:31:48 --> Model Class Initialized
DEBUG - 2023-04-22 10:31:48 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-22 10:31:48 --> Model Class Initialized
INFO - 2023-04-22 10:31:48 --> Final output sent to browser
DEBUG - 2023-04-22 10:31:48 --> Total execution time: 0.0175
ERROR - 2023-04-22 10:31:51 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-22 10:31:51 --> Config Class Initialized
INFO - 2023-04-22 10:31:51 --> Hooks Class Initialized
DEBUG - 2023-04-22 10:31:51 --> UTF-8 Support Enabled
INFO - 2023-04-22 10:31:51 --> Utf8 Class Initialized
INFO - 2023-04-22 10:31:51 --> URI Class Initialized
INFO - 2023-04-22 10:31:51 --> Router Class Initialized
INFO - 2023-04-22 10:31:51 --> Output Class Initialized
INFO - 2023-04-22 10:31:51 --> Security Class Initialized
DEBUG - 2023-04-22 10:31:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-22 10:31:51 --> Input Class Initialized
INFO - 2023-04-22 10:31:51 --> Language Class Initialized
INFO - 2023-04-22 10:31:51 --> Loader Class Initialized
INFO - 2023-04-22 10:31:51 --> Helper loaded: url_helper
INFO - 2023-04-22 10:31:51 --> Helper loaded: file_helper
INFO - 2023-04-22 10:31:51 --> Helper loaded: html_helper
INFO - 2023-04-22 10:31:51 --> Helper loaded: text_helper
INFO - 2023-04-22 10:31:51 --> Helper loaded: form_helper
INFO - 2023-04-22 10:31:51 --> Helper loaded: lang_helper
INFO - 2023-04-22 10:31:51 --> Helper loaded: security_helper
INFO - 2023-04-22 10:31:51 --> Helper loaded: cookie_helper
INFO - 2023-04-22 10:31:51 --> Database Driver Class Initialized
INFO - 2023-04-22 10:31:51 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-22 10:31:51 --> Parser Class Initialized
INFO - 2023-04-22 10:31:51 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-22 10:31:51 --> Pagination Class Initialized
INFO - 2023-04-22 10:31:51 --> Form Validation Class Initialized
INFO - 2023-04-22 10:31:51 --> Controller Class Initialized
INFO - 2023-04-22 10:31:51 --> Model Class Initialized
DEBUG - 2023-04-22 10:31:51 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-04-22 10:31:51 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-22 10:31:51 --> Model Class Initialized
DEBUG - 2023-04-22 10:31:51 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-22 10:31:51 --> Model Class Initialized
INFO - 2023-04-22 10:31:51 --> Model Class Initialized
INFO - 2023-04-22 10:31:51 --> Final output sent to browser
DEBUG - 2023-04-22 10:31:51 --> Total execution time: 0.0210
ERROR - 2023-04-22 10:31:54 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-22 10:31:54 --> Config Class Initialized
INFO - 2023-04-22 10:31:54 --> Hooks Class Initialized
DEBUG - 2023-04-22 10:31:54 --> UTF-8 Support Enabled
INFO - 2023-04-22 10:31:54 --> Utf8 Class Initialized
INFO - 2023-04-22 10:31:54 --> URI Class Initialized
INFO - 2023-04-22 10:31:54 --> Router Class Initialized
INFO - 2023-04-22 10:31:54 --> Output Class Initialized
INFO - 2023-04-22 10:31:54 --> Security Class Initialized
DEBUG - 2023-04-22 10:31:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-22 10:31:54 --> Input Class Initialized
INFO - 2023-04-22 10:31:54 --> Language Class Initialized
INFO - 2023-04-22 10:31:54 --> Loader Class Initialized
INFO - 2023-04-22 10:31:54 --> Helper loaded: url_helper
INFO - 2023-04-22 10:31:54 --> Helper loaded: file_helper
INFO - 2023-04-22 10:31:54 --> Helper loaded: html_helper
INFO - 2023-04-22 10:31:54 --> Helper loaded: text_helper
INFO - 2023-04-22 10:31:54 --> Helper loaded: form_helper
INFO - 2023-04-22 10:31:54 --> Helper loaded: lang_helper
INFO - 2023-04-22 10:31:54 --> Helper loaded: security_helper
INFO - 2023-04-22 10:31:54 --> Helper loaded: cookie_helper
INFO - 2023-04-22 10:31:54 --> Database Driver Class Initialized
INFO - 2023-04-22 10:31:54 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-22 10:31:54 --> Parser Class Initialized
INFO - 2023-04-22 10:31:54 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-22 10:31:54 --> Pagination Class Initialized
INFO - 2023-04-22 10:31:54 --> Form Validation Class Initialized
INFO - 2023-04-22 10:31:54 --> Controller Class Initialized
INFO - 2023-04-22 10:31:54 --> Model Class Initialized
DEBUG - 2023-04-22 10:31:54 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-04-22 10:31:54 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-22 10:31:54 --> Model Class Initialized
DEBUG - 2023-04-22 10:31:54 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-22 10:31:54 --> Model Class Initialized
INFO - 2023-04-22 10:31:54 --> Final output sent to browser
DEBUG - 2023-04-22 10:31:54 --> Total execution time: 0.0191
ERROR - 2023-04-22 10:32:18 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-22 10:32:18 --> Config Class Initialized
INFO - 2023-04-22 10:32:18 --> Hooks Class Initialized
DEBUG - 2023-04-22 10:32:18 --> UTF-8 Support Enabled
INFO - 2023-04-22 10:32:18 --> Utf8 Class Initialized
INFO - 2023-04-22 10:32:18 --> URI Class Initialized
INFO - 2023-04-22 10:32:18 --> Router Class Initialized
INFO - 2023-04-22 10:32:18 --> Output Class Initialized
INFO - 2023-04-22 10:32:18 --> Security Class Initialized
DEBUG - 2023-04-22 10:32:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-22 10:32:18 --> Input Class Initialized
INFO - 2023-04-22 10:32:18 --> Language Class Initialized
INFO - 2023-04-22 10:32:18 --> Loader Class Initialized
INFO - 2023-04-22 10:32:18 --> Helper loaded: url_helper
INFO - 2023-04-22 10:32:18 --> Helper loaded: file_helper
INFO - 2023-04-22 10:32:18 --> Helper loaded: html_helper
INFO - 2023-04-22 10:32:18 --> Helper loaded: text_helper
INFO - 2023-04-22 10:32:18 --> Helper loaded: form_helper
INFO - 2023-04-22 10:32:18 --> Helper loaded: lang_helper
INFO - 2023-04-22 10:32:18 --> Helper loaded: security_helper
INFO - 2023-04-22 10:32:18 --> Helper loaded: cookie_helper
INFO - 2023-04-22 10:32:18 --> Database Driver Class Initialized
INFO - 2023-04-22 10:32:18 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-22 10:32:18 --> Parser Class Initialized
INFO - 2023-04-22 10:32:18 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-22 10:32:18 --> Pagination Class Initialized
INFO - 2023-04-22 10:32:18 --> Form Validation Class Initialized
INFO - 2023-04-22 10:32:18 --> Controller Class Initialized
DEBUG - 2023-04-22 10:32:18 --> Auth class already loaded. Second attempt ignored.
INFO - 2023-04-22 10:32:18 --> Model Class Initialized
INFO - 2023-04-22 10:32:18 --> Model Class Initialized
INFO - 2023-04-22 10:32:18 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/product/add_type_form.php
DEBUG - 2023-04-22 10:32:18 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-04-22 10:32:18 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-04-22 10:32:18 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-04-22 10:32:18 --> Model Class Initialized
INFO - 2023-04-22 10:32:18 --> Model Class Initialized
INFO - 2023-04-22 10:32:18 --> Model Class Initialized
INFO - 2023-04-22 10:32:18 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-04-22 10:32:18 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-04-22 10:32:18 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-04-22 10:32:18 --> Final output sent to browser
DEBUG - 2023-04-22 10:32:18 --> Total execution time: 0.1496
ERROR - 2023-04-22 10:32:24 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-22 10:32:24 --> Config Class Initialized
INFO - 2023-04-22 10:32:24 --> Hooks Class Initialized
DEBUG - 2023-04-22 10:32:24 --> UTF-8 Support Enabled
INFO - 2023-04-22 10:32:24 --> Utf8 Class Initialized
INFO - 2023-04-22 10:32:24 --> URI Class Initialized
INFO - 2023-04-22 10:32:24 --> Router Class Initialized
INFO - 2023-04-22 10:32:24 --> Output Class Initialized
INFO - 2023-04-22 10:32:24 --> Security Class Initialized
DEBUG - 2023-04-22 10:32:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-22 10:32:24 --> Input Class Initialized
INFO - 2023-04-22 10:32:24 --> Language Class Initialized
INFO - 2023-04-22 10:32:24 --> Loader Class Initialized
INFO - 2023-04-22 10:32:24 --> Helper loaded: url_helper
INFO - 2023-04-22 10:32:24 --> Helper loaded: file_helper
INFO - 2023-04-22 10:32:24 --> Helper loaded: html_helper
INFO - 2023-04-22 10:32:24 --> Helper loaded: text_helper
INFO - 2023-04-22 10:32:24 --> Helper loaded: form_helper
INFO - 2023-04-22 10:32:24 --> Helper loaded: lang_helper
INFO - 2023-04-22 10:32:24 --> Helper loaded: security_helper
INFO - 2023-04-22 10:32:24 --> Helper loaded: cookie_helper
INFO - 2023-04-22 10:32:24 --> Database Driver Class Initialized
INFO - 2023-04-22 10:32:24 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-22 10:32:24 --> Parser Class Initialized
INFO - 2023-04-22 10:32:24 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-22 10:32:24 --> Pagination Class Initialized
INFO - 2023-04-22 10:32:24 --> Form Validation Class Initialized
INFO - 2023-04-22 10:32:24 --> Controller Class Initialized
DEBUG - 2023-04-22 10:32:24 --> Auth class already loaded. Second attempt ignored.
INFO - 2023-04-22 10:32:24 --> Model Class Initialized
INFO - 2023-04-22 10:32:24 --> Model Class Initialized
INFO - 2023-04-22 10:32:24 --> Model Class Initialized
INFO - 2023-04-22 10:32:24 --> Model Class Initialized
INFO - 2023-04-22 10:32:24 --> Model Class Initialized
INFO - 2023-04-22 10:32:24 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/product/add_product_form.php
DEBUG - 2023-04-22 10:32:24 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-04-22 10:32:24 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-04-22 10:32:24 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-04-22 10:32:24 --> Model Class Initialized
INFO - 2023-04-22 10:32:24 --> Model Class Initialized
INFO - 2023-04-22 10:32:24 --> Model Class Initialized
INFO - 2023-04-22 10:32:24 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-04-22 10:32:24 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-04-22 10:32:24 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-04-22 10:32:24 --> Final output sent to browser
DEBUG - 2023-04-22 10:32:24 --> Total execution time: 0.1904
ERROR - 2023-04-22 10:32:26 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-22 10:32:26 --> Config Class Initialized
INFO - 2023-04-22 10:32:26 --> Hooks Class Initialized
DEBUG - 2023-04-22 10:32:26 --> UTF-8 Support Enabled
INFO - 2023-04-22 10:32:26 --> Utf8 Class Initialized
INFO - 2023-04-22 10:32:26 --> URI Class Initialized
INFO - 2023-04-22 10:32:26 --> Router Class Initialized
INFO - 2023-04-22 10:32:26 --> Output Class Initialized
INFO - 2023-04-22 10:32:26 --> Security Class Initialized
DEBUG - 2023-04-22 10:32:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-22 10:32:26 --> Input Class Initialized
INFO - 2023-04-22 10:32:26 --> Language Class Initialized
INFO - 2023-04-22 10:32:26 --> Loader Class Initialized
INFO - 2023-04-22 10:32:26 --> Helper loaded: url_helper
INFO - 2023-04-22 10:32:26 --> Helper loaded: file_helper
INFO - 2023-04-22 10:32:26 --> Helper loaded: html_helper
INFO - 2023-04-22 10:32:26 --> Helper loaded: text_helper
INFO - 2023-04-22 10:32:26 --> Helper loaded: form_helper
INFO - 2023-04-22 10:32:26 --> Helper loaded: lang_helper
INFO - 2023-04-22 10:32:26 --> Helper loaded: security_helper
INFO - 2023-04-22 10:32:26 --> Helper loaded: cookie_helper
INFO - 2023-04-22 10:32:26 --> Database Driver Class Initialized
INFO - 2023-04-22 10:32:26 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-22 10:32:26 --> Parser Class Initialized
INFO - 2023-04-22 10:32:26 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-22 10:32:26 --> Pagination Class Initialized
INFO - 2023-04-22 10:32:26 --> Form Validation Class Initialized
INFO - 2023-04-22 10:32:26 --> Controller Class Initialized
DEBUG - 2023-04-22 10:32:26 --> Auth class already loaded. Second attempt ignored.
INFO - 2023-04-22 10:32:26 --> Model Class Initialized
INFO - 2023-04-22 10:32:26 --> Model Class Initialized
INFO - 2023-04-22 10:32:26 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/product/add_type_form.php
DEBUG - 2023-04-22 10:32:26 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-04-22 10:32:26 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-04-22 10:32:26 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-04-22 10:32:26 --> Model Class Initialized
INFO - 2023-04-22 10:32:26 --> Model Class Initialized
INFO - 2023-04-22 10:32:26 --> Model Class Initialized
INFO - 2023-04-22 10:32:26 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-04-22 10:32:26 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-04-22 10:32:26 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-04-22 10:32:26 --> Final output sent to browser
DEBUG - 2023-04-22 10:32:26 --> Total execution time: 0.1458
ERROR - 2023-04-22 10:32:31 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-22 10:32:31 --> Config Class Initialized
INFO - 2023-04-22 10:32:31 --> Hooks Class Initialized
DEBUG - 2023-04-22 10:32:31 --> UTF-8 Support Enabled
INFO - 2023-04-22 10:32:31 --> Utf8 Class Initialized
INFO - 2023-04-22 10:32:31 --> URI Class Initialized
INFO - 2023-04-22 10:32:31 --> Router Class Initialized
INFO - 2023-04-22 10:32:31 --> Output Class Initialized
INFO - 2023-04-22 10:32:31 --> Security Class Initialized
DEBUG - 2023-04-22 10:32:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-22 10:32:31 --> Input Class Initialized
INFO - 2023-04-22 10:32:31 --> Language Class Initialized
INFO - 2023-04-22 10:32:31 --> Loader Class Initialized
INFO - 2023-04-22 10:32:31 --> Helper loaded: url_helper
INFO - 2023-04-22 10:32:31 --> Helper loaded: file_helper
INFO - 2023-04-22 10:32:31 --> Helper loaded: html_helper
INFO - 2023-04-22 10:32:31 --> Helper loaded: text_helper
INFO - 2023-04-22 10:32:31 --> Helper loaded: form_helper
INFO - 2023-04-22 10:32:31 --> Helper loaded: lang_helper
INFO - 2023-04-22 10:32:31 --> Helper loaded: security_helper
INFO - 2023-04-22 10:32:31 --> Helper loaded: cookie_helper
INFO - 2023-04-22 10:32:31 --> Database Driver Class Initialized
INFO - 2023-04-22 10:32:31 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-22 10:32:31 --> Parser Class Initialized
INFO - 2023-04-22 10:32:31 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-22 10:32:31 --> Pagination Class Initialized
INFO - 2023-04-22 10:32:31 --> Form Validation Class Initialized
INFO - 2023-04-22 10:32:31 --> Controller Class Initialized
DEBUG - 2023-04-22 10:32:31 --> Auth class already loaded. Second attempt ignored.
INFO - 2023-04-22 10:32:31 --> Model Class Initialized
INFO - 2023-04-22 10:32:31 --> Model Class Initialized
INFO - 2023-04-22 10:32:31 --> Model Class Initialized
INFO - 2023-04-22 10:32:31 --> Model Class Initialized
INFO - 2023-04-22 10:32:31 --> Model Class Initialized
INFO - 2023-04-22 10:32:31 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/product/add_product_form.php
DEBUG - 2023-04-22 10:32:31 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-04-22 10:32:31 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-04-22 10:32:31 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-04-22 10:32:31 --> Model Class Initialized
INFO - 2023-04-22 10:32:31 --> Model Class Initialized
INFO - 2023-04-22 10:32:31 --> Model Class Initialized
INFO - 2023-04-22 10:32:31 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-04-22 10:32:31 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-04-22 10:32:31 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-04-22 10:32:31 --> Final output sent to browser
DEBUG - 2023-04-22 10:32:31 --> Total execution time: 0.1803
ERROR - 2023-04-22 10:33:09 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-22 10:33:09 --> Config Class Initialized
INFO - 2023-04-22 10:33:09 --> Hooks Class Initialized
DEBUG - 2023-04-22 10:33:09 --> UTF-8 Support Enabled
INFO - 2023-04-22 10:33:09 --> Utf8 Class Initialized
INFO - 2023-04-22 10:33:09 --> URI Class Initialized
INFO - 2023-04-22 10:33:09 --> Router Class Initialized
INFO - 2023-04-22 10:33:09 --> Output Class Initialized
INFO - 2023-04-22 10:33:09 --> Security Class Initialized
DEBUG - 2023-04-22 10:33:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-22 10:33:09 --> Input Class Initialized
INFO - 2023-04-22 10:33:09 --> Language Class Initialized
INFO - 2023-04-22 10:33:09 --> Loader Class Initialized
INFO - 2023-04-22 10:33:09 --> Helper loaded: url_helper
INFO - 2023-04-22 10:33:09 --> Helper loaded: file_helper
INFO - 2023-04-22 10:33:09 --> Helper loaded: html_helper
INFO - 2023-04-22 10:33:09 --> Helper loaded: text_helper
INFO - 2023-04-22 10:33:09 --> Helper loaded: form_helper
INFO - 2023-04-22 10:33:09 --> Helper loaded: lang_helper
INFO - 2023-04-22 10:33:09 --> Helper loaded: security_helper
INFO - 2023-04-22 10:33:09 --> Helper loaded: cookie_helper
INFO - 2023-04-22 10:33:09 --> Database Driver Class Initialized
INFO - 2023-04-22 10:33:09 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-22 10:33:09 --> Parser Class Initialized
INFO - 2023-04-22 10:33:09 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-22 10:33:09 --> Pagination Class Initialized
INFO - 2023-04-22 10:33:09 --> Form Validation Class Initialized
INFO - 2023-04-22 10:33:09 --> Controller Class Initialized
INFO - 2023-04-22 10:33:09 --> Model Class Initialized
INFO - 2023-04-22 10:33:09 --> Model Class Initialized
ERROR - 2023-04-22 10:33:09 --> Severity: Warning --> Invalid argument supplied for foreach() /home/powera7m/app.maurnaturo.com/application/views/purchase/add_purchase_form.php 157
INFO - 2023-04-22 10:33:09 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/purchase/add_purchase_form.php
DEBUG - 2023-04-22 10:33:09 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-04-22 10:33:09 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-04-22 10:33:09 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-04-22 10:33:09 --> Model Class Initialized
INFO - 2023-04-22 10:33:09 --> Model Class Initialized
INFO - 2023-04-22 10:33:09 --> Model Class Initialized
INFO - 2023-04-22 10:33:09 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-04-22 10:33:09 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-04-22 10:33:09 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-04-22 10:33:09 --> Final output sent to browser
DEBUG - 2023-04-22 10:33:09 --> Total execution time: 0.1910
ERROR - 2023-04-22 14:14:02 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-22 14:14:02 --> Config Class Initialized
INFO - 2023-04-22 14:14:02 --> Hooks Class Initialized
DEBUG - 2023-04-22 14:14:02 --> UTF-8 Support Enabled
INFO - 2023-04-22 14:14:02 --> Utf8 Class Initialized
INFO - 2023-04-22 14:14:02 --> URI Class Initialized
DEBUG - 2023-04-22 14:14:02 --> No URI present. Default controller set.
INFO - 2023-04-22 14:14:02 --> Router Class Initialized
INFO - 2023-04-22 14:14:02 --> Output Class Initialized
INFO - 2023-04-22 14:14:02 --> Security Class Initialized
DEBUG - 2023-04-22 14:14:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-22 14:14:02 --> Input Class Initialized
INFO - 2023-04-22 14:14:02 --> Language Class Initialized
INFO - 2023-04-22 14:14:02 --> Loader Class Initialized
INFO - 2023-04-22 14:14:02 --> Helper loaded: url_helper
INFO - 2023-04-22 14:14:02 --> Helper loaded: file_helper
INFO - 2023-04-22 14:14:02 --> Helper loaded: html_helper
INFO - 2023-04-22 14:14:02 --> Helper loaded: text_helper
INFO - 2023-04-22 14:14:02 --> Helper loaded: form_helper
INFO - 2023-04-22 14:14:02 --> Helper loaded: lang_helper
INFO - 2023-04-22 14:14:02 --> Helper loaded: security_helper
INFO - 2023-04-22 14:14:02 --> Helper loaded: cookie_helper
INFO - 2023-04-22 14:14:02 --> Database Driver Class Initialized
INFO - 2023-04-22 14:14:02 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-22 14:14:02 --> Parser Class Initialized
INFO - 2023-04-22 14:14:02 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-22 14:14:02 --> Pagination Class Initialized
INFO - 2023-04-22 14:14:02 --> Form Validation Class Initialized
INFO - 2023-04-22 14:14:02 --> Controller Class Initialized
INFO - 2023-04-22 14:14:02 --> Model Class Initialized
DEBUG - 2023-04-22 14:14:02 --> Session class already loaded. Second attempt ignored.
ERROR - 2023-04-22 14:26:19 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-22 14:26:19 --> Config Class Initialized
INFO - 2023-04-22 14:26:19 --> Hooks Class Initialized
DEBUG - 2023-04-22 14:26:19 --> UTF-8 Support Enabled
INFO - 2023-04-22 14:26:19 --> Utf8 Class Initialized
INFO - 2023-04-22 14:26:19 --> URI Class Initialized
DEBUG - 2023-04-22 14:26:19 --> No URI present. Default controller set.
INFO - 2023-04-22 14:26:19 --> Router Class Initialized
INFO - 2023-04-22 14:26:19 --> Output Class Initialized
INFO - 2023-04-22 14:26:19 --> Security Class Initialized
DEBUG - 2023-04-22 14:26:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-22 14:26:19 --> Input Class Initialized
INFO - 2023-04-22 14:26:19 --> Language Class Initialized
INFO - 2023-04-22 14:26:19 --> Loader Class Initialized
INFO - 2023-04-22 14:26:19 --> Helper loaded: url_helper
INFO - 2023-04-22 14:26:19 --> Helper loaded: file_helper
INFO - 2023-04-22 14:26:19 --> Helper loaded: html_helper
INFO - 2023-04-22 14:26:19 --> Helper loaded: text_helper
INFO - 2023-04-22 14:26:19 --> Helper loaded: form_helper
INFO - 2023-04-22 14:26:19 --> Helper loaded: lang_helper
INFO - 2023-04-22 14:26:19 --> Helper loaded: security_helper
INFO - 2023-04-22 14:26:19 --> Helper loaded: cookie_helper
INFO - 2023-04-22 14:26:19 --> Database Driver Class Initialized
INFO - 2023-04-22 14:26:19 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-22 14:26:19 --> Parser Class Initialized
INFO - 2023-04-22 14:26:19 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-22 14:26:19 --> Pagination Class Initialized
INFO - 2023-04-22 14:26:19 --> Form Validation Class Initialized
INFO - 2023-04-22 14:26:19 --> Controller Class Initialized
INFO - 2023-04-22 14:26:19 --> Model Class Initialized
DEBUG - 2023-04-22 14:26:19 --> Session class already loaded. Second attempt ignored.
ERROR - 2023-04-22 15:27:37 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-22 15:27:37 --> Config Class Initialized
INFO - 2023-04-22 15:27:37 --> Hooks Class Initialized
DEBUG - 2023-04-22 15:27:37 --> UTF-8 Support Enabled
INFO - 2023-04-22 15:27:37 --> Utf8 Class Initialized
INFO - 2023-04-22 15:27:37 --> URI Class Initialized
DEBUG - 2023-04-22 15:27:37 --> No URI present. Default controller set.
INFO - 2023-04-22 15:27:37 --> Router Class Initialized
INFO - 2023-04-22 15:27:37 --> Output Class Initialized
INFO - 2023-04-22 15:27:37 --> Security Class Initialized
DEBUG - 2023-04-22 15:27:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-22 15:27:37 --> Input Class Initialized
INFO - 2023-04-22 15:27:37 --> Language Class Initialized
INFO - 2023-04-22 15:27:37 --> Loader Class Initialized
INFO - 2023-04-22 15:27:37 --> Helper loaded: url_helper
INFO - 2023-04-22 15:27:37 --> Helper loaded: file_helper
INFO - 2023-04-22 15:27:37 --> Helper loaded: html_helper
INFO - 2023-04-22 15:27:37 --> Helper loaded: text_helper
INFO - 2023-04-22 15:27:37 --> Helper loaded: form_helper
INFO - 2023-04-22 15:27:37 --> Helper loaded: lang_helper
INFO - 2023-04-22 15:27:37 --> Helper loaded: security_helper
INFO - 2023-04-22 15:27:37 --> Helper loaded: cookie_helper
INFO - 2023-04-22 15:27:37 --> Database Driver Class Initialized
INFO - 2023-04-22 15:27:37 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-22 15:27:37 --> Parser Class Initialized
INFO - 2023-04-22 15:27:37 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-22 15:27:37 --> Pagination Class Initialized
INFO - 2023-04-22 15:27:37 --> Form Validation Class Initialized
INFO - 2023-04-22 15:27:37 --> Controller Class Initialized
INFO - 2023-04-22 15:27:37 --> Model Class Initialized
DEBUG - 2023-04-22 15:27:37 --> Session class already loaded. Second attempt ignored.
ERROR - 2023-04-22 15:27:38 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-22 15:27:38 --> Config Class Initialized
INFO - 2023-04-22 15:27:38 --> Hooks Class Initialized
DEBUG - 2023-04-22 15:27:38 --> UTF-8 Support Enabled
INFO - 2023-04-22 15:27:38 --> Utf8 Class Initialized
INFO - 2023-04-22 15:27:38 --> URI Class Initialized
INFO - 2023-04-22 15:27:38 --> Router Class Initialized
INFO - 2023-04-22 15:27:38 --> Output Class Initialized
INFO - 2023-04-22 15:27:38 --> Security Class Initialized
DEBUG - 2023-04-22 15:27:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-22 15:27:38 --> Input Class Initialized
INFO - 2023-04-22 15:27:38 --> Language Class Initialized
INFO - 2023-04-22 15:27:38 --> Loader Class Initialized
INFO - 2023-04-22 15:27:38 --> Helper loaded: url_helper
INFO - 2023-04-22 15:27:38 --> Helper loaded: file_helper
INFO - 2023-04-22 15:27:38 --> Helper loaded: html_helper
INFO - 2023-04-22 15:27:38 --> Helper loaded: text_helper
INFO - 2023-04-22 15:27:38 --> Helper loaded: form_helper
INFO - 2023-04-22 15:27:38 --> Helper loaded: lang_helper
INFO - 2023-04-22 15:27:38 --> Helper loaded: security_helper
INFO - 2023-04-22 15:27:38 --> Helper loaded: cookie_helper
INFO - 2023-04-22 15:27:38 --> Database Driver Class Initialized
INFO - 2023-04-22 15:27:38 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-22 15:27:38 --> Parser Class Initialized
INFO - 2023-04-22 15:27:38 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-22 15:27:38 --> Pagination Class Initialized
INFO - 2023-04-22 15:27:38 --> Form Validation Class Initialized
INFO - 2023-04-22 15:27:38 --> Controller Class Initialized
INFO - 2023-04-22 15:27:38 --> Model Class Initialized
DEBUG - 2023-04-22 15:27:38 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-22 15:27:38 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2023-04-22 15:27:38 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-04-22 15:27:38 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-04-22 15:27:38 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-04-22 15:27:38 --> Model Class Initialized
INFO - 2023-04-22 15:27:38 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-04-22 15:27:38 --> Final output sent to browser
DEBUG - 2023-04-22 15:27:38 --> Total execution time: 0.0380
ERROR - 2023-04-22 15:28:54 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-22 15:28:54 --> Config Class Initialized
INFO - 2023-04-22 15:28:54 --> Hooks Class Initialized
DEBUG - 2023-04-22 15:28:54 --> UTF-8 Support Enabled
INFO - 2023-04-22 15:28:54 --> Utf8 Class Initialized
INFO - 2023-04-22 15:28:54 --> URI Class Initialized
INFO - 2023-04-22 15:28:54 --> Router Class Initialized
INFO - 2023-04-22 15:28:54 --> Output Class Initialized
INFO - 2023-04-22 15:28:54 --> Security Class Initialized
DEBUG - 2023-04-22 15:28:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-22 15:28:54 --> Input Class Initialized
INFO - 2023-04-22 15:28:54 --> Language Class Initialized
INFO - 2023-04-22 15:28:54 --> Loader Class Initialized
INFO - 2023-04-22 15:28:54 --> Helper loaded: url_helper
INFO - 2023-04-22 15:28:54 --> Helper loaded: file_helper
INFO - 2023-04-22 15:28:54 --> Helper loaded: html_helper
INFO - 2023-04-22 15:28:54 --> Helper loaded: text_helper
INFO - 2023-04-22 15:28:54 --> Helper loaded: form_helper
INFO - 2023-04-22 15:28:54 --> Helper loaded: lang_helper
INFO - 2023-04-22 15:28:54 --> Helper loaded: security_helper
INFO - 2023-04-22 15:28:54 --> Helper loaded: cookie_helper
INFO - 2023-04-22 15:28:54 --> Database Driver Class Initialized
INFO - 2023-04-22 15:28:54 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-22 15:28:54 --> Parser Class Initialized
INFO - 2023-04-22 15:28:54 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-22 15:28:54 --> Pagination Class Initialized
INFO - 2023-04-22 15:28:54 --> Form Validation Class Initialized
INFO - 2023-04-22 15:28:54 --> Controller Class Initialized
INFO - 2023-04-22 15:28:54 --> Model Class Initialized
DEBUG - 2023-04-22 15:28:54 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-22 15:28:54 --> Model Class Initialized
INFO - 2023-04-22 15:28:54 --> Final output sent to browser
DEBUG - 2023-04-22 15:28:54 --> Total execution time: 0.0199
ERROR - 2023-04-22 15:28:54 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-22 15:28:54 --> Config Class Initialized
INFO - 2023-04-22 15:28:54 --> Hooks Class Initialized
DEBUG - 2023-04-22 15:28:54 --> UTF-8 Support Enabled
INFO - 2023-04-22 15:28:54 --> Utf8 Class Initialized
INFO - 2023-04-22 15:28:54 --> URI Class Initialized
DEBUG - 2023-04-22 15:28:54 --> No URI present. Default controller set.
INFO - 2023-04-22 15:28:54 --> Router Class Initialized
INFO - 2023-04-22 15:28:54 --> Output Class Initialized
INFO - 2023-04-22 15:28:54 --> Security Class Initialized
DEBUG - 2023-04-22 15:28:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-22 15:28:54 --> Input Class Initialized
INFO - 2023-04-22 15:28:54 --> Language Class Initialized
INFO - 2023-04-22 15:28:54 --> Loader Class Initialized
INFO - 2023-04-22 15:28:54 --> Helper loaded: url_helper
INFO - 2023-04-22 15:28:54 --> Helper loaded: file_helper
INFO - 2023-04-22 15:28:54 --> Helper loaded: html_helper
INFO - 2023-04-22 15:28:54 --> Helper loaded: text_helper
INFO - 2023-04-22 15:28:54 --> Helper loaded: form_helper
INFO - 2023-04-22 15:28:54 --> Helper loaded: lang_helper
INFO - 2023-04-22 15:28:54 --> Helper loaded: security_helper
INFO - 2023-04-22 15:28:54 --> Helper loaded: cookie_helper
INFO - 2023-04-22 15:28:54 --> Database Driver Class Initialized
INFO - 2023-04-22 15:28:54 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-22 15:28:54 --> Parser Class Initialized
INFO - 2023-04-22 15:28:54 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-22 15:28:54 --> Pagination Class Initialized
INFO - 2023-04-22 15:28:54 --> Form Validation Class Initialized
INFO - 2023-04-22 15:28:54 --> Controller Class Initialized
INFO - 2023-04-22 15:28:54 --> Model Class Initialized
DEBUG - 2023-04-22 15:28:54 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-22 15:28:54 --> Model Class Initialized
DEBUG - 2023-04-22 15:28:54 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-22 15:28:54 --> Model Class Initialized
INFO - 2023-04-22 15:28:54 --> Model Class Initialized
INFO - 2023-04-22 15:28:54 --> Model Class Initialized
INFO - 2023-04-22 15:28:54 --> Model Class Initialized
DEBUG - 2023-04-22 15:28:54 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-04-22 15:28:54 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-22 15:28:54 --> Model Class Initialized
INFO - 2023-04-22 15:28:54 --> Model Class Initialized
INFO - 2023-04-22 15:28:54 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-04-22 15:28:54 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-04-22 15:28:54 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-04-22 15:28:54 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-04-22 15:28:54 --> Model Class Initialized
INFO - 2023-04-22 15:28:55 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-04-22 15:28:55 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-04-22 15:28:55 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-04-22 15:28:55 --> Final output sent to browser
DEBUG - 2023-04-22 15:28:55 --> Total execution time: 0.1722
ERROR - 2023-04-22 15:28:55 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-22 15:28:55 --> Config Class Initialized
INFO - 2023-04-22 15:28:55 --> Hooks Class Initialized
DEBUG - 2023-04-22 15:28:55 --> UTF-8 Support Enabled
INFO - 2023-04-22 15:28:55 --> Utf8 Class Initialized
INFO - 2023-04-22 15:28:55 --> URI Class Initialized
INFO - 2023-04-22 15:28:55 --> Router Class Initialized
INFO - 2023-04-22 15:28:55 --> Output Class Initialized
INFO - 2023-04-22 15:28:55 --> Security Class Initialized
DEBUG - 2023-04-22 15:28:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-22 15:28:55 --> Input Class Initialized
INFO - 2023-04-22 15:28:55 --> Language Class Initialized
INFO - 2023-04-22 15:28:55 --> Loader Class Initialized
INFO - 2023-04-22 15:28:55 --> Helper loaded: url_helper
INFO - 2023-04-22 15:28:55 --> Helper loaded: file_helper
INFO - 2023-04-22 15:28:55 --> Helper loaded: html_helper
INFO - 2023-04-22 15:28:55 --> Helper loaded: text_helper
INFO - 2023-04-22 15:28:55 --> Helper loaded: form_helper
INFO - 2023-04-22 15:28:55 --> Helper loaded: lang_helper
INFO - 2023-04-22 15:28:55 --> Helper loaded: security_helper
INFO - 2023-04-22 15:28:55 --> Helper loaded: cookie_helper
INFO - 2023-04-22 15:28:55 --> Database Driver Class Initialized
INFO - 2023-04-22 15:28:55 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-22 15:28:55 --> Parser Class Initialized
INFO - 2023-04-22 15:28:55 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-22 15:28:55 --> Pagination Class Initialized
INFO - 2023-04-22 15:28:55 --> Form Validation Class Initialized
INFO - 2023-04-22 15:28:55 --> Controller Class Initialized
DEBUG - 2023-04-22 15:28:55 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-04-22 15:28:55 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-22 15:28:55 --> Model Class Initialized
INFO - 2023-04-22 15:28:55 --> Final output sent to browser
DEBUG - 2023-04-22 15:28:55 --> Total execution time: 0.0132
ERROR - 2023-04-22 15:40:17 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-22 15:40:17 --> Config Class Initialized
INFO - 2023-04-22 15:40:17 --> Hooks Class Initialized
DEBUG - 2023-04-22 15:40:17 --> UTF-8 Support Enabled
INFO - 2023-04-22 15:40:17 --> Utf8 Class Initialized
INFO - 2023-04-22 15:40:17 --> URI Class Initialized
DEBUG - 2023-04-22 15:40:17 --> No URI present. Default controller set.
INFO - 2023-04-22 15:40:17 --> Router Class Initialized
INFO - 2023-04-22 15:40:17 --> Output Class Initialized
INFO - 2023-04-22 15:40:17 --> Security Class Initialized
DEBUG - 2023-04-22 15:40:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-22 15:40:17 --> Input Class Initialized
INFO - 2023-04-22 15:40:17 --> Language Class Initialized
INFO - 2023-04-22 15:40:17 --> Loader Class Initialized
INFO - 2023-04-22 15:40:17 --> Helper loaded: url_helper
INFO - 2023-04-22 15:40:17 --> Helper loaded: file_helper
INFO - 2023-04-22 15:40:17 --> Helper loaded: html_helper
INFO - 2023-04-22 15:40:17 --> Helper loaded: text_helper
INFO - 2023-04-22 15:40:17 --> Helper loaded: form_helper
INFO - 2023-04-22 15:40:17 --> Helper loaded: lang_helper
INFO - 2023-04-22 15:40:17 --> Helper loaded: security_helper
INFO - 2023-04-22 15:40:17 --> Helper loaded: cookie_helper
INFO - 2023-04-22 15:40:17 --> Database Driver Class Initialized
INFO - 2023-04-22 15:40:17 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-22 15:40:17 --> Parser Class Initialized
INFO - 2023-04-22 15:40:17 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-22 15:40:17 --> Pagination Class Initialized
INFO - 2023-04-22 15:40:17 --> Form Validation Class Initialized
INFO - 2023-04-22 15:40:17 --> Controller Class Initialized
INFO - 2023-04-22 15:40:17 --> Model Class Initialized
DEBUG - 2023-04-22 15:40:17 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-22 15:40:17 --> Model Class Initialized
DEBUG - 2023-04-22 15:40:17 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-22 15:40:17 --> Model Class Initialized
INFO - 2023-04-22 15:40:17 --> Model Class Initialized
INFO - 2023-04-22 15:40:17 --> Model Class Initialized
INFO - 2023-04-22 15:40:17 --> Model Class Initialized
DEBUG - 2023-04-22 15:40:17 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-04-22 15:40:17 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-22 15:40:17 --> Model Class Initialized
INFO - 2023-04-22 15:40:17 --> Model Class Initialized
INFO - 2023-04-22 15:40:17 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-04-22 15:40:17 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-04-22 15:40:17 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-04-22 15:40:17 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-04-22 15:40:17 --> Model Class Initialized
INFO - 2023-04-22 15:40:17 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-04-22 15:40:17 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-04-22 15:40:17 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-04-22 15:40:17 --> Final output sent to browser
DEBUG - 2023-04-22 15:40:17 --> Total execution time: 0.2257
ERROR - 2023-04-22 15:40:31 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-22 15:40:31 --> Config Class Initialized
INFO - 2023-04-22 15:40:31 --> Hooks Class Initialized
DEBUG - 2023-04-22 15:40:31 --> UTF-8 Support Enabled
INFO - 2023-04-22 15:40:31 --> Utf8 Class Initialized
INFO - 2023-04-22 15:40:31 --> URI Class Initialized
INFO - 2023-04-22 15:40:31 --> Router Class Initialized
INFO - 2023-04-22 15:40:31 --> Output Class Initialized
INFO - 2023-04-22 15:40:31 --> Security Class Initialized
DEBUG - 2023-04-22 15:40:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-22 15:40:31 --> Input Class Initialized
INFO - 2023-04-22 15:40:31 --> Language Class Initialized
INFO - 2023-04-22 15:40:31 --> Loader Class Initialized
INFO - 2023-04-22 15:40:31 --> Helper loaded: url_helper
INFO - 2023-04-22 15:40:31 --> Helper loaded: file_helper
INFO - 2023-04-22 15:40:31 --> Helper loaded: html_helper
INFO - 2023-04-22 15:40:31 --> Helper loaded: text_helper
INFO - 2023-04-22 15:40:31 --> Helper loaded: form_helper
INFO - 2023-04-22 15:40:31 --> Helper loaded: lang_helper
INFO - 2023-04-22 15:40:31 --> Helper loaded: security_helper
INFO - 2023-04-22 15:40:31 --> Helper loaded: cookie_helper
INFO - 2023-04-22 15:40:31 --> Database Driver Class Initialized
INFO - 2023-04-22 15:40:31 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-22 15:40:31 --> Parser Class Initialized
INFO - 2023-04-22 15:40:31 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-22 15:40:31 --> Pagination Class Initialized
INFO - 2023-04-22 15:40:31 --> Form Validation Class Initialized
INFO - 2023-04-22 15:40:31 --> Controller Class Initialized
INFO - 2023-04-22 15:40:31 --> Model Class Initialized
DEBUG - 2023-04-22 15:40:31 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-04-22 15:40:31 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-22 15:40:31 --> Model Class Initialized
DEBUG - 2023-04-22 15:40:31 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-22 15:40:31 --> Model Class Initialized
INFO - 2023-04-22 15:40:31 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice.php
DEBUG - 2023-04-22 15:40:31 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-04-22 15:40:31 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-04-22 15:40:31 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-04-22 15:40:31 --> Model Class Initialized
INFO - 2023-04-22 15:40:31 --> Model Class Initialized
INFO - 2023-04-22 15:40:31 --> Model Class Initialized
INFO - 2023-04-22 15:40:31 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-04-22 15:40:31 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-04-22 15:40:31 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-04-22 15:40:31 --> Final output sent to browser
DEBUG - 2023-04-22 15:40:31 --> Total execution time: 0.1464
ERROR - 2023-04-22 15:40:32 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-22 15:40:32 --> Config Class Initialized
INFO - 2023-04-22 15:40:32 --> Hooks Class Initialized
DEBUG - 2023-04-22 15:40:32 --> UTF-8 Support Enabled
INFO - 2023-04-22 15:40:32 --> Utf8 Class Initialized
INFO - 2023-04-22 15:40:32 --> URI Class Initialized
INFO - 2023-04-22 15:40:32 --> Router Class Initialized
INFO - 2023-04-22 15:40:32 --> Output Class Initialized
INFO - 2023-04-22 15:40:32 --> Security Class Initialized
DEBUG - 2023-04-22 15:40:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-22 15:40:32 --> Input Class Initialized
INFO - 2023-04-22 15:40:32 --> Language Class Initialized
INFO - 2023-04-22 15:40:32 --> Loader Class Initialized
INFO - 2023-04-22 15:40:32 --> Helper loaded: url_helper
INFO - 2023-04-22 15:40:32 --> Helper loaded: file_helper
INFO - 2023-04-22 15:40:32 --> Helper loaded: html_helper
INFO - 2023-04-22 15:40:32 --> Helper loaded: text_helper
INFO - 2023-04-22 15:40:32 --> Helper loaded: form_helper
INFO - 2023-04-22 15:40:32 --> Helper loaded: lang_helper
INFO - 2023-04-22 15:40:32 --> Helper loaded: security_helper
INFO - 2023-04-22 15:40:32 --> Helper loaded: cookie_helper
INFO - 2023-04-22 15:40:32 --> Database Driver Class Initialized
INFO - 2023-04-22 15:40:32 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-22 15:40:32 --> Parser Class Initialized
INFO - 2023-04-22 15:40:32 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-22 15:40:32 --> Pagination Class Initialized
INFO - 2023-04-22 15:40:32 --> Form Validation Class Initialized
INFO - 2023-04-22 15:40:32 --> Controller Class Initialized
INFO - 2023-04-22 15:40:32 --> Model Class Initialized
DEBUG - 2023-04-22 15:40:32 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-04-22 15:40:32 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-22 15:40:32 --> Model Class Initialized
DEBUG - 2023-04-22 15:40:32 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-22 15:40:32 --> Model Class Initialized
INFO - 2023-04-22 15:40:32 --> Final output sent to browser
DEBUG - 2023-04-22 15:40:32 --> Total execution time: 0.0680
ERROR - 2023-04-22 15:40:37 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-22 15:40:37 --> Config Class Initialized
INFO - 2023-04-22 15:40:37 --> Hooks Class Initialized
DEBUG - 2023-04-22 15:40:37 --> UTF-8 Support Enabled
INFO - 2023-04-22 15:40:37 --> Utf8 Class Initialized
INFO - 2023-04-22 15:40:37 --> URI Class Initialized
INFO - 2023-04-22 15:40:37 --> Router Class Initialized
INFO - 2023-04-22 15:40:37 --> Output Class Initialized
INFO - 2023-04-22 15:40:37 --> Security Class Initialized
DEBUG - 2023-04-22 15:40:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-22 15:40:37 --> Input Class Initialized
INFO - 2023-04-22 15:40:37 --> Language Class Initialized
INFO - 2023-04-22 15:40:37 --> Loader Class Initialized
INFO - 2023-04-22 15:40:37 --> Helper loaded: url_helper
INFO - 2023-04-22 15:40:37 --> Helper loaded: file_helper
INFO - 2023-04-22 15:40:37 --> Helper loaded: html_helper
INFO - 2023-04-22 15:40:37 --> Helper loaded: text_helper
INFO - 2023-04-22 15:40:37 --> Helper loaded: form_helper
INFO - 2023-04-22 15:40:37 --> Helper loaded: lang_helper
INFO - 2023-04-22 15:40:37 --> Helper loaded: security_helper
INFO - 2023-04-22 15:40:37 --> Helper loaded: cookie_helper
INFO - 2023-04-22 15:40:37 --> Database Driver Class Initialized
INFO - 2023-04-22 15:40:37 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-22 15:40:37 --> Parser Class Initialized
INFO - 2023-04-22 15:40:37 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-22 15:40:37 --> Pagination Class Initialized
INFO - 2023-04-22 15:40:37 --> Form Validation Class Initialized
INFO - 2023-04-22 15:40:37 --> Controller Class Initialized
INFO - 2023-04-22 15:40:37 --> Model Class Initialized
DEBUG - 2023-04-22 15:40:37 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-04-22 15:40:37 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-22 15:40:37 --> Model Class Initialized
DEBUG - 2023-04-22 15:40:37 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-22 15:40:37 --> Model Class Initialized
INFO - 2023-04-22 15:40:37 --> Final output sent to browser
DEBUG - 2023-04-22 15:40:37 --> Total execution time: 0.0699
ERROR - 2023-04-22 15:41:08 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-22 15:41:08 --> Config Class Initialized
INFO - 2023-04-22 15:41:08 --> Hooks Class Initialized
DEBUG - 2023-04-22 15:41:08 --> UTF-8 Support Enabled
INFO - 2023-04-22 15:41:08 --> Utf8 Class Initialized
INFO - 2023-04-22 15:41:08 --> URI Class Initialized
INFO - 2023-04-22 15:41:08 --> Router Class Initialized
INFO - 2023-04-22 15:41:08 --> Output Class Initialized
INFO - 2023-04-22 15:41:08 --> Security Class Initialized
DEBUG - 2023-04-22 15:41:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-22 15:41:08 --> Input Class Initialized
INFO - 2023-04-22 15:41:08 --> Language Class Initialized
INFO - 2023-04-22 15:41:08 --> Loader Class Initialized
INFO - 2023-04-22 15:41:08 --> Helper loaded: url_helper
INFO - 2023-04-22 15:41:08 --> Helper loaded: file_helper
INFO - 2023-04-22 15:41:08 --> Helper loaded: html_helper
INFO - 2023-04-22 15:41:08 --> Helper loaded: text_helper
INFO - 2023-04-22 15:41:08 --> Helper loaded: form_helper
INFO - 2023-04-22 15:41:08 --> Helper loaded: lang_helper
INFO - 2023-04-22 15:41:08 --> Helper loaded: security_helper
INFO - 2023-04-22 15:41:08 --> Helper loaded: cookie_helper
INFO - 2023-04-22 15:41:08 --> Database Driver Class Initialized
INFO - 2023-04-22 15:41:08 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-22 15:41:08 --> Parser Class Initialized
INFO - 2023-04-22 15:41:08 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-22 15:41:08 --> Pagination Class Initialized
INFO - 2023-04-22 15:41:08 --> Form Validation Class Initialized
INFO - 2023-04-22 15:41:08 --> Controller Class Initialized
INFO - 2023-04-22 15:41:08 --> Model Class Initialized
DEBUG - 2023-04-22 15:41:08 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-04-22 15:41:08 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-22 15:41:08 --> Model Class Initialized
DEBUG - 2023-04-22 15:41:08 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-22 15:41:08 --> Model Class Initialized
INFO - 2023-04-22 15:41:08 --> Final output sent to browser
DEBUG - 2023-04-22 15:41:08 --> Total execution time: 0.0824
ERROR - 2023-04-22 15:41:15 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-22 15:41:15 --> Config Class Initialized
INFO - 2023-04-22 15:41:15 --> Hooks Class Initialized
DEBUG - 2023-04-22 15:41:15 --> UTF-8 Support Enabled
INFO - 2023-04-22 15:41:15 --> Utf8 Class Initialized
INFO - 2023-04-22 15:41:15 --> URI Class Initialized
INFO - 2023-04-22 15:41:15 --> Router Class Initialized
INFO - 2023-04-22 15:41:15 --> Output Class Initialized
INFO - 2023-04-22 15:41:15 --> Security Class Initialized
DEBUG - 2023-04-22 15:41:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-22 15:41:15 --> Input Class Initialized
INFO - 2023-04-22 15:41:15 --> Language Class Initialized
INFO - 2023-04-22 15:41:15 --> Loader Class Initialized
INFO - 2023-04-22 15:41:15 --> Helper loaded: url_helper
INFO - 2023-04-22 15:41:15 --> Helper loaded: file_helper
INFO - 2023-04-22 15:41:15 --> Helper loaded: html_helper
INFO - 2023-04-22 15:41:15 --> Helper loaded: text_helper
INFO - 2023-04-22 15:41:15 --> Helper loaded: form_helper
INFO - 2023-04-22 15:41:15 --> Helper loaded: lang_helper
INFO - 2023-04-22 15:41:15 --> Helper loaded: security_helper
INFO - 2023-04-22 15:41:15 --> Helper loaded: cookie_helper
INFO - 2023-04-22 15:41:15 --> Database Driver Class Initialized
INFO - 2023-04-22 15:41:15 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-22 15:41:15 --> Parser Class Initialized
INFO - 2023-04-22 15:41:15 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-22 15:41:15 --> Pagination Class Initialized
INFO - 2023-04-22 15:41:15 --> Form Validation Class Initialized
INFO - 2023-04-22 15:41:15 --> Controller Class Initialized
INFO - 2023-04-22 15:41:15 --> Model Class Initialized
DEBUG - 2023-04-22 15:41:15 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-04-22 15:41:15 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-22 15:41:15 --> Model Class Initialized
DEBUG - 2023-04-22 15:41:15 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-22 15:41:15 --> Model Class Initialized
INFO - 2023-04-22 15:41:15 --> Final output sent to browser
DEBUG - 2023-04-22 15:41:15 --> Total execution time: 0.0725
ERROR - 2023-04-22 15:41:19 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-22 15:41:19 --> Config Class Initialized
INFO - 2023-04-22 15:41:19 --> Hooks Class Initialized
DEBUG - 2023-04-22 15:41:19 --> UTF-8 Support Enabled
INFO - 2023-04-22 15:41:19 --> Utf8 Class Initialized
INFO - 2023-04-22 15:41:19 --> URI Class Initialized
INFO - 2023-04-22 15:41:19 --> Router Class Initialized
INFO - 2023-04-22 15:41:19 --> Output Class Initialized
INFO - 2023-04-22 15:41:19 --> Security Class Initialized
DEBUG - 2023-04-22 15:41:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-22 15:41:19 --> Input Class Initialized
INFO - 2023-04-22 15:41:19 --> Language Class Initialized
INFO - 2023-04-22 15:41:19 --> Loader Class Initialized
INFO - 2023-04-22 15:41:19 --> Helper loaded: url_helper
INFO - 2023-04-22 15:41:19 --> Helper loaded: file_helper
INFO - 2023-04-22 15:41:19 --> Helper loaded: html_helper
INFO - 2023-04-22 15:41:19 --> Helper loaded: text_helper
INFO - 2023-04-22 15:41:19 --> Helper loaded: form_helper
INFO - 2023-04-22 15:41:19 --> Helper loaded: lang_helper
INFO - 2023-04-22 15:41:19 --> Helper loaded: security_helper
INFO - 2023-04-22 15:41:19 --> Helper loaded: cookie_helper
INFO - 2023-04-22 15:41:19 --> Database Driver Class Initialized
INFO - 2023-04-22 15:41:19 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-22 15:41:19 --> Parser Class Initialized
INFO - 2023-04-22 15:41:19 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-22 15:41:19 --> Pagination Class Initialized
INFO - 2023-04-22 15:41:19 --> Form Validation Class Initialized
INFO - 2023-04-22 15:41:19 --> Controller Class Initialized
INFO - 2023-04-22 15:41:19 --> Model Class Initialized
DEBUG - 2023-04-22 15:41:19 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-04-22 15:41:19 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-22 15:41:19 --> Model Class Initialized
DEBUG - 2023-04-22 15:41:19 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-22 15:41:19 --> Model Class Initialized
INFO - 2023-04-22 15:41:19 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice.php
DEBUG - 2023-04-22 15:41:19 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-04-22 15:41:19 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-04-22 15:41:19 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-04-22 15:41:19 --> Model Class Initialized
INFO - 2023-04-22 15:41:19 --> Model Class Initialized
INFO - 2023-04-22 15:41:19 --> Model Class Initialized
INFO - 2023-04-22 15:41:20 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-04-22 15:41:20 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-04-22 15:41:20 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-04-22 15:41:20 --> Final output sent to browser
DEBUG - 2023-04-22 15:41:20 --> Total execution time: 0.1602
ERROR - 2023-04-22 15:41:20 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-22 15:41:20 --> Config Class Initialized
INFO - 2023-04-22 15:41:20 --> Hooks Class Initialized
DEBUG - 2023-04-22 15:41:20 --> UTF-8 Support Enabled
INFO - 2023-04-22 15:41:20 --> Utf8 Class Initialized
INFO - 2023-04-22 15:41:20 --> URI Class Initialized
INFO - 2023-04-22 15:41:20 --> Router Class Initialized
INFO - 2023-04-22 15:41:20 --> Output Class Initialized
INFO - 2023-04-22 15:41:20 --> Security Class Initialized
DEBUG - 2023-04-22 15:41:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-22 15:41:20 --> Input Class Initialized
INFO - 2023-04-22 15:41:20 --> Language Class Initialized
INFO - 2023-04-22 15:41:20 --> Loader Class Initialized
INFO - 2023-04-22 15:41:20 --> Helper loaded: url_helper
INFO - 2023-04-22 15:41:20 --> Helper loaded: file_helper
INFO - 2023-04-22 15:41:20 --> Helper loaded: html_helper
INFO - 2023-04-22 15:41:20 --> Helper loaded: text_helper
INFO - 2023-04-22 15:41:20 --> Helper loaded: form_helper
INFO - 2023-04-22 15:41:20 --> Helper loaded: lang_helper
INFO - 2023-04-22 15:41:20 --> Helper loaded: security_helper
INFO - 2023-04-22 15:41:20 --> Helper loaded: cookie_helper
INFO - 2023-04-22 15:41:20 --> Database Driver Class Initialized
INFO - 2023-04-22 15:41:20 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-22 15:41:20 --> Parser Class Initialized
INFO - 2023-04-22 15:41:20 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-22 15:41:20 --> Pagination Class Initialized
INFO - 2023-04-22 15:41:20 --> Form Validation Class Initialized
INFO - 2023-04-22 15:41:20 --> Controller Class Initialized
INFO - 2023-04-22 15:41:20 --> Model Class Initialized
DEBUG - 2023-04-22 15:41:20 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-04-22 15:41:20 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-22 15:41:20 --> Model Class Initialized
DEBUG - 2023-04-22 15:41:20 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-22 15:41:20 --> Model Class Initialized
INFO - 2023-04-22 15:41:20 --> Final output sent to browser
DEBUG - 2023-04-22 15:41:20 --> Total execution time: 0.0615
ERROR - 2023-04-22 15:41:26 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-22 15:41:26 --> Config Class Initialized
INFO - 2023-04-22 15:41:26 --> Hooks Class Initialized
DEBUG - 2023-04-22 15:41:26 --> UTF-8 Support Enabled
INFO - 2023-04-22 15:41:26 --> Utf8 Class Initialized
INFO - 2023-04-22 15:41:26 --> URI Class Initialized
INFO - 2023-04-22 15:41:26 --> Router Class Initialized
INFO - 2023-04-22 15:41:26 --> Output Class Initialized
INFO - 2023-04-22 15:41:26 --> Security Class Initialized
DEBUG - 2023-04-22 15:41:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-22 15:41:26 --> Input Class Initialized
INFO - 2023-04-22 15:41:26 --> Language Class Initialized
INFO - 2023-04-22 15:41:26 --> Loader Class Initialized
INFO - 2023-04-22 15:41:26 --> Helper loaded: url_helper
INFO - 2023-04-22 15:41:26 --> Helper loaded: file_helper
INFO - 2023-04-22 15:41:26 --> Helper loaded: html_helper
INFO - 2023-04-22 15:41:26 --> Helper loaded: text_helper
INFO - 2023-04-22 15:41:26 --> Helper loaded: form_helper
INFO - 2023-04-22 15:41:26 --> Helper loaded: lang_helper
INFO - 2023-04-22 15:41:26 --> Helper loaded: security_helper
INFO - 2023-04-22 15:41:26 --> Helper loaded: cookie_helper
INFO - 2023-04-22 15:41:26 --> Database Driver Class Initialized
INFO - 2023-04-22 15:41:26 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-22 15:41:26 --> Parser Class Initialized
INFO - 2023-04-22 15:41:26 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-22 15:41:26 --> Pagination Class Initialized
INFO - 2023-04-22 15:41:26 --> Form Validation Class Initialized
INFO - 2023-04-22 15:41:26 --> Controller Class Initialized
INFO - 2023-04-22 15:41:26 --> Model Class Initialized
DEBUG - 2023-04-22 15:41:26 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-04-22 15:41:26 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-22 15:41:26 --> Model Class Initialized
DEBUG - 2023-04-22 15:41:26 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-22 15:41:26 --> Model Class Initialized
INFO - 2023-04-22 15:41:26 --> Final output sent to browser
DEBUG - 2023-04-22 15:41:26 --> Total execution time: 0.0756
ERROR - 2023-04-22 15:41:47 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-22 15:41:47 --> Config Class Initialized
INFO - 2023-04-22 15:41:47 --> Hooks Class Initialized
DEBUG - 2023-04-22 15:41:47 --> UTF-8 Support Enabled
INFO - 2023-04-22 15:41:47 --> Utf8 Class Initialized
INFO - 2023-04-22 15:41:47 --> URI Class Initialized
INFO - 2023-04-22 15:41:47 --> Router Class Initialized
INFO - 2023-04-22 15:41:47 --> Output Class Initialized
INFO - 2023-04-22 15:41:47 --> Security Class Initialized
DEBUG - 2023-04-22 15:41:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-22 15:41:47 --> Input Class Initialized
INFO - 2023-04-22 15:41:47 --> Language Class Initialized
INFO - 2023-04-22 15:41:47 --> Loader Class Initialized
INFO - 2023-04-22 15:41:47 --> Helper loaded: url_helper
INFO - 2023-04-22 15:41:47 --> Helper loaded: file_helper
INFO - 2023-04-22 15:41:47 --> Helper loaded: html_helper
INFO - 2023-04-22 15:41:47 --> Helper loaded: text_helper
INFO - 2023-04-22 15:41:47 --> Helper loaded: form_helper
INFO - 2023-04-22 15:41:47 --> Helper loaded: lang_helper
INFO - 2023-04-22 15:41:47 --> Helper loaded: security_helper
INFO - 2023-04-22 15:41:47 --> Helper loaded: cookie_helper
INFO - 2023-04-22 15:41:47 --> Database Driver Class Initialized
INFO - 2023-04-22 15:41:47 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-22 15:41:47 --> Parser Class Initialized
INFO - 2023-04-22 15:41:47 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-22 15:41:47 --> Pagination Class Initialized
INFO - 2023-04-22 15:41:47 --> Form Validation Class Initialized
INFO - 2023-04-22 15:41:47 --> Controller Class Initialized
INFO - 2023-04-22 15:41:47 --> Model Class Initialized
INFO - 2023-04-22 15:41:47 --> Model Class Initialized
INFO - 2023-04-22 15:41:47 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/purchase/purchase.php
DEBUG - 2023-04-22 15:41:47 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-04-22 15:41:47 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-04-22 15:41:47 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-04-22 15:41:47 --> Model Class Initialized
INFO - 2023-04-22 15:41:47 --> Model Class Initialized
INFO - 2023-04-22 15:41:47 --> Model Class Initialized
INFO - 2023-04-22 15:41:47 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-04-22 15:41:47 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-04-22 15:41:47 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-04-22 15:41:47 --> Final output sent to browser
DEBUG - 2023-04-22 15:41:47 --> Total execution time: 0.1473
ERROR - 2023-04-22 15:41:48 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-22 15:41:48 --> Config Class Initialized
INFO - 2023-04-22 15:41:48 --> Hooks Class Initialized
DEBUG - 2023-04-22 15:41:48 --> UTF-8 Support Enabled
INFO - 2023-04-22 15:41:48 --> Utf8 Class Initialized
INFO - 2023-04-22 15:41:48 --> URI Class Initialized
INFO - 2023-04-22 15:41:48 --> Router Class Initialized
INFO - 2023-04-22 15:41:48 --> Output Class Initialized
INFO - 2023-04-22 15:41:48 --> Security Class Initialized
DEBUG - 2023-04-22 15:41:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-22 15:41:48 --> Input Class Initialized
INFO - 2023-04-22 15:41:48 --> Language Class Initialized
INFO - 2023-04-22 15:41:48 --> Loader Class Initialized
INFO - 2023-04-22 15:41:48 --> Helper loaded: url_helper
INFO - 2023-04-22 15:41:48 --> Helper loaded: file_helper
INFO - 2023-04-22 15:41:48 --> Helper loaded: html_helper
INFO - 2023-04-22 15:41:48 --> Helper loaded: text_helper
INFO - 2023-04-22 15:41:48 --> Helper loaded: form_helper
INFO - 2023-04-22 15:41:48 --> Helper loaded: lang_helper
INFO - 2023-04-22 15:41:48 --> Helper loaded: security_helper
INFO - 2023-04-22 15:41:48 --> Helper loaded: cookie_helper
INFO - 2023-04-22 15:41:48 --> Database Driver Class Initialized
INFO - 2023-04-22 15:41:48 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-22 15:41:48 --> Parser Class Initialized
INFO - 2023-04-22 15:41:48 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-22 15:41:48 --> Pagination Class Initialized
INFO - 2023-04-22 15:41:48 --> Form Validation Class Initialized
INFO - 2023-04-22 15:41:48 --> Controller Class Initialized
INFO - 2023-04-22 15:41:48 --> Model Class Initialized
INFO - 2023-04-22 15:41:48 --> Model Class Initialized
INFO - 2023-04-22 15:41:48 --> Final output sent to browser
DEBUG - 2023-04-22 15:41:48 --> Total execution time: 0.0479
ERROR - 2023-04-22 15:42:18 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-22 15:42:18 --> Config Class Initialized
INFO - 2023-04-22 15:42:18 --> Hooks Class Initialized
DEBUG - 2023-04-22 15:42:18 --> UTF-8 Support Enabled
INFO - 2023-04-22 15:42:18 --> Utf8 Class Initialized
INFO - 2023-04-22 15:42:18 --> URI Class Initialized
INFO - 2023-04-22 15:42:18 --> Router Class Initialized
INFO - 2023-04-22 15:42:18 --> Output Class Initialized
INFO - 2023-04-22 15:42:18 --> Security Class Initialized
DEBUG - 2023-04-22 15:42:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-22 15:42:18 --> Input Class Initialized
INFO - 2023-04-22 15:42:18 --> Language Class Initialized
INFO - 2023-04-22 15:42:18 --> Loader Class Initialized
INFO - 2023-04-22 15:42:18 --> Helper loaded: url_helper
INFO - 2023-04-22 15:42:18 --> Helper loaded: file_helper
INFO - 2023-04-22 15:42:18 --> Helper loaded: html_helper
INFO - 2023-04-22 15:42:18 --> Helper loaded: text_helper
INFO - 2023-04-22 15:42:18 --> Helper loaded: form_helper
INFO - 2023-04-22 15:42:18 --> Helper loaded: lang_helper
INFO - 2023-04-22 15:42:18 --> Helper loaded: security_helper
INFO - 2023-04-22 15:42:18 --> Helper loaded: cookie_helper
INFO - 2023-04-22 15:42:18 --> Database Driver Class Initialized
INFO - 2023-04-22 15:42:18 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-22 15:42:18 --> Parser Class Initialized
INFO - 2023-04-22 15:42:18 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-22 15:42:18 --> Pagination Class Initialized
INFO - 2023-04-22 15:42:18 --> Form Validation Class Initialized
INFO - 2023-04-22 15:42:18 --> Controller Class Initialized
INFO - 2023-04-22 15:42:18 --> Model Class Initialized
DEBUG - 2023-04-22 15:42:18 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-04-22 15:42:18 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-22 15:42:18 --> Model Class Initialized
INFO - 2023-04-22 15:42:18 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/stockrequest/inventory.php
DEBUG - 2023-04-22 15:42:18 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-04-22 15:42:18 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-04-22 15:42:18 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-04-22 15:42:18 --> Model Class Initialized
INFO - 2023-04-22 15:42:18 --> Model Class Initialized
INFO - 2023-04-22 15:42:18 --> Model Class Initialized
INFO - 2023-04-22 15:42:18 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-04-22 15:42:18 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-04-22 15:42:18 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-04-22 15:42:18 --> Final output sent to browser
DEBUG - 2023-04-22 15:42:18 --> Total execution time: 0.1565
ERROR - 2023-04-22 15:42:19 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-22 15:42:19 --> Config Class Initialized
INFO - 2023-04-22 15:42:19 --> Hooks Class Initialized
DEBUG - 2023-04-22 15:42:19 --> UTF-8 Support Enabled
INFO - 2023-04-22 15:42:19 --> Utf8 Class Initialized
INFO - 2023-04-22 15:42:19 --> URI Class Initialized
INFO - 2023-04-22 15:42:19 --> Router Class Initialized
INFO - 2023-04-22 15:42:19 --> Output Class Initialized
INFO - 2023-04-22 15:42:19 --> Security Class Initialized
DEBUG - 2023-04-22 15:42:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-22 15:42:19 --> Input Class Initialized
INFO - 2023-04-22 15:42:19 --> Language Class Initialized
INFO - 2023-04-22 15:42:19 --> Loader Class Initialized
INFO - 2023-04-22 15:42:19 --> Helper loaded: url_helper
INFO - 2023-04-22 15:42:19 --> Helper loaded: file_helper
INFO - 2023-04-22 15:42:19 --> Helper loaded: html_helper
INFO - 2023-04-22 15:42:19 --> Helper loaded: text_helper
INFO - 2023-04-22 15:42:19 --> Helper loaded: form_helper
INFO - 2023-04-22 15:42:19 --> Helper loaded: lang_helper
INFO - 2023-04-22 15:42:19 --> Helper loaded: security_helper
INFO - 2023-04-22 15:42:19 --> Helper loaded: cookie_helper
INFO - 2023-04-22 15:42:19 --> Database Driver Class Initialized
INFO - 2023-04-22 15:42:19 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-22 15:42:19 --> Parser Class Initialized
INFO - 2023-04-22 15:42:19 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-22 15:42:19 --> Pagination Class Initialized
INFO - 2023-04-22 15:42:19 --> Form Validation Class Initialized
INFO - 2023-04-22 15:42:19 --> Controller Class Initialized
INFO - 2023-04-22 15:42:19 --> Model Class Initialized
DEBUG - 2023-04-22 15:42:19 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-04-22 15:42:19 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-22 15:42:19 --> Model Class Initialized
INFO - 2023-04-22 15:42:19 --> Final output sent to browser
DEBUG - 2023-04-22 15:42:19 --> Total execution time: 0.0202
ERROR - 2023-04-22 15:42:26 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-22 15:42:26 --> Config Class Initialized
INFO - 2023-04-22 15:42:26 --> Hooks Class Initialized
DEBUG - 2023-04-22 15:42:26 --> UTF-8 Support Enabled
INFO - 2023-04-22 15:42:26 --> Utf8 Class Initialized
INFO - 2023-04-22 15:42:26 --> URI Class Initialized
INFO - 2023-04-22 15:42:26 --> Router Class Initialized
INFO - 2023-04-22 15:42:26 --> Output Class Initialized
INFO - 2023-04-22 15:42:26 --> Security Class Initialized
DEBUG - 2023-04-22 15:42:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-22 15:42:26 --> Input Class Initialized
INFO - 2023-04-22 15:42:26 --> Language Class Initialized
INFO - 2023-04-22 15:42:26 --> Loader Class Initialized
INFO - 2023-04-22 15:42:26 --> Helper loaded: url_helper
INFO - 2023-04-22 15:42:26 --> Helper loaded: file_helper
INFO - 2023-04-22 15:42:26 --> Helper loaded: html_helper
INFO - 2023-04-22 15:42:26 --> Helper loaded: text_helper
INFO - 2023-04-22 15:42:26 --> Helper loaded: form_helper
INFO - 2023-04-22 15:42:26 --> Helper loaded: lang_helper
INFO - 2023-04-22 15:42:26 --> Helper loaded: security_helper
INFO - 2023-04-22 15:42:26 --> Helper loaded: cookie_helper
INFO - 2023-04-22 15:42:26 --> Database Driver Class Initialized
INFO - 2023-04-22 15:42:26 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-22 15:42:26 --> Parser Class Initialized
INFO - 2023-04-22 15:42:26 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-22 15:42:26 --> Pagination Class Initialized
INFO - 2023-04-22 15:42:26 --> Form Validation Class Initialized
INFO - 2023-04-22 15:42:26 --> Controller Class Initialized
INFO - 2023-04-22 15:42:26 --> Model Class Initialized
DEBUG - 2023-04-22 15:42:26 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-04-22 15:42:26 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-22 15:42:26 --> Model Class Initialized
INFO - 2023-04-22 15:42:26 --> Final output sent to browser
DEBUG - 2023-04-22 15:42:26 --> Total execution time: 0.0191
ERROR - 2023-04-22 15:43:03 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-22 15:43:03 --> Config Class Initialized
INFO - 2023-04-22 15:43:03 --> Hooks Class Initialized
DEBUG - 2023-04-22 15:43:03 --> UTF-8 Support Enabled
INFO - 2023-04-22 15:43:03 --> Utf8 Class Initialized
INFO - 2023-04-22 15:43:03 --> URI Class Initialized
INFO - 2023-04-22 15:43:03 --> Router Class Initialized
INFO - 2023-04-22 15:43:03 --> Output Class Initialized
INFO - 2023-04-22 15:43:03 --> Security Class Initialized
DEBUG - 2023-04-22 15:43:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-22 15:43:03 --> Input Class Initialized
INFO - 2023-04-22 15:43:03 --> Language Class Initialized
INFO - 2023-04-22 15:43:03 --> Loader Class Initialized
INFO - 2023-04-22 15:43:03 --> Helper loaded: url_helper
INFO - 2023-04-22 15:43:03 --> Helper loaded: file_helper
INFO - 2023-04-22 15:43:03 --> Helper loaded: html_helper
INFO - 2023-04-22 15:43:03 --> Helper loaded: text_helper
INFO - 2023-04-22 15:43:03 --> Helper loaded: form_helper
INFO - 2023-04-22 15:43:03 --> Helper loaded: lang_helper
INFO - 2023-04-22 15:43:03 --> Helper loaded: security_helper
INFO - 2023-04-22 15:43:03 --> Helper loaded: cookie_helper
INFO - 2023-04-22 15:43:03 --> Database Driver Class Initialized
INFO - 2023-04-22 15:43:03 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-22 15:43:03 --> Parser Class Initialized
INFO - 2023-04-22 15:43:03 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-22 15:43:03 --> Pagination Class Initialized
INFO - 2023-04-22 15:43:03 --> Form Validation Class Initialized
INFO - 2023-04-22 15:43:03 --> Controller Class Initialized
DEBUG - 2023-04-22 15:43:03 --> Auth class already loaded. Second attempt ignored.
INFO - 2023-04-22 15:43:03 --> Model Class Initialized
INFO - 2023-04-22 15:43:03 --> Model Class Initialized
INFO - 2023-04-22 15:43:03 --> Model Class Initialized
INFO - 2023-04-22 15:43:03 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/product/product.php
DEBUG - 2023-04-22 15:43:03 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-04-22 15:43:03 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-04-22 15:43:03 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-04-22 15:43:03 --> Model Class Initialized
INFO - 2023-04-22 15:43:03 --> Model Class Initialized
INFO - 2023-04-22 15:43:03 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-04-22 15:43:03 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-04-22 15:43:03 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-04-22 15:43:03 --> Final output sent to browser
DEBUG - 2023-04-22 15:43:03 --> Total execution time: 0.1549
ERROR - 2023-04-22 15:43:05 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-22 15:43:05 --> Config Class Initialized
INFO - 2023-04-22 15:43:05 --> Hooks Class Initialized
DEBUG - 2023-04-22 15:43:05 --> UTF-8 Support Enabled
INFO - 2023-04-22 15:43:05 --> Utf8 Class Initialized
INFO - 2023-04-22 15:43:05 --> URI Class Initialized
INFO - 2023-04-22 15:43:05 --> Router Class Initialized
INFO - 2023-04-22 15:43:05 --> Output Class Initialized
INFO - 2023-04-22 15:43:05 --> Security Class Initialized
DEBUG - 2023-04-22 15:43:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-22 15:43:05 --> Input Class Initialized
INFO - 2023-04-22 15:43:05 --> Language Class Initialized
INFO - 2023-04-22 15:43:05 --> Loader Class Initialized
INFO - 2023-04-22 15:43:05 --> Helper loaded: url_helper
INFO - 2023-04-22 15:43:05 --> Helper loaded: file_helper
INFO - 2023-04-22 15:43:05 --> Helper loaded: html_helper
INFO - 2023-04-22 15:43:05 --> Helper loaded: text_helper
INFO - 2023-04-22 15:43:05 --> Helper loaded: form_helper
INFO - 2023-04-22 15:43:05 --> Helper loaded: lang_helper
INFO - 2023-04-22 15:43:05 --> Helper loaded: security_helper
INFO - 2023-04-22 15:43:05 --> Helper loaded: cookie_helper
INFO - 2023-04-22 15:43:05 --> Database Driver Class Initialized
INFO - 2023-04-22 15:43:05 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-22 15:43:05 --> Parser Class Initialized
INFO - 2023-04-22 15:43:05 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-22 15:43:05 --> Pagination Class Initialized
INFO - 2023-04-22 15:43:05 --> Form Validation Class Initialized
INFO - 2023-04-22 15:43:05 --> Controller Class Initialized
DEBUG - 2023-04-22 15:43:05 --> Auth class already loaded. Second attempt ignored.
INFO - 2023-04-22 15:43:05 --> Model Class Initialized
INFO - 2023-04-22 15:43:05 --> Model Class Initialized
INFO - 2023-04-22 15:43:05 --> Final output sent to browser
DEBUG - 2023-04-22 15:43:05 --> Total execution time: 0.0539
ERROR - 2023-04-22 15:43:10 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-22 15:43:10 --> Config Class Initialized
INFO - 2023-04-22 15:43:10 --> Hooks Class Initialized
DEBUG - 2023-04-22 15:43:10 --> UTF-8 Support Enabled
INFO - 2023-04-22 15:43:10 --> Utf8 Class Initialized
INFO - 2023-04-22 15:43:10 --> URI Class Initialized
INFO - 2023-04-22 15:43:10 --> Router Class Initialized
INFO - 2023-04-22 15:43:10 --> Output Class Initialized
INFO - 2023-04-22 15:43:10 --> Security Class Initialized
DEBUG - 2023-04-22 15:43:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-22 15:43:10 --> Input Class Initialized
INFO - 2023-04-22 15:43:10 --> Language Class Initialized
INFO - 2023-04-22 15:43:10 --> Loader Class Initialized
INFO - 2023-04-22 15:43:10 --> Helper loaded: url_helper
INFO - 2023-04-22 15:43:10 --> Helper loaded: file_helper
INFO - 2023-04-22 15:43:10 --> Helper loaded: html_helper
INFO - 2023-04-22 15:43:10 --> Helper loaded: text_helper
INFO - 2023-04-22 15:43:10 --> Helper loaded: form_helper
INFO - 2023-04-22 15:43:10 --> Helper loaded: lang_helper
INFO - 2023-04-22 15:43:10 --> Helper loaded: security_helper
INFO - 2023-04-22 15:43:10 --> Helper loaded: cookie_helper
INFO - 2023-04-22 15:43:10 --> Database Driver Class Initialized
INFO - 2023-04-22 15:43:10 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-22 15:43:10 --> Parser Class Initialized
INFO - 2023-04-22 15:43:10 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-22 15:43:10 --> Pagination Class Initialized
INFO - 2023-04-22 15:43:10 --> Form Validation Class Initialized
INFO - 2023-04-22 15:43:10 --> Controller Class Initialized
DEBUG - 2023-04-22 15:43:10 --> Auth class already loaded. Second attempt ignored.
INFO - 2023-04-22 15:43:10 --> Model Class Initialized
INFO - 2023-04-22 15:43:10 --> Model Class Initialized
INFO - 2023-04-22 15:43:10 --> Final output sent to browser
DEBUG - 2023-04-22 15:43:10 --> Total execution time: 0.1146
ERROR - 2023-04-22 15:44:08 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-22 15:44:08 --> Config Class Initialized
INFO - 2023-04-22 15:44:08 --> Hooks Class Initialized
DEBUG - 2023-04-22 15:44:08 --> UTF-8 Support Enabled
INFO - 2023-04-22 15:44:08 --> Utf8 Class Initialized
INFO - 2023-04-22 15:44:08 --> URI Class Initialized
INFO - 2023-04-22 15:44:08 --> Router Class Initialized
INFO - 2023-04-22 15:44:08 --> Output Class Initialized
INFO - 2023-04-22 15:44:08 --> Security Class Initialized
DEBUG - 2023-04-22 15:44:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-22 15:44:08 --> Input Class Initialized
INFO - 2023-04-22 15:44:08 --> Language Class Initialized
INFO - 2023-04-22 15:44:08 --> Loader Class Initialized
INFO - 2023-04-22 15:44:08 --> Helper loaded: url_helper
INFO - 2023-04-22 15:44:08 --> Helper loaded: file_helper
INFO - 2023-04-22 15:44:08 --> Helper loaded: html_helper
INFO - 2023-04-22 15:44:08 --> Helper loaded: text_helper
INFO - 2023-04-22 15:44:08 --> Helper loaded: form_helper
INFO - 2023-04-22 15:44:08 --> Helper loaded: lang_helper
INFO - 2023-04-22 15:44:08 --> Helper loaded: security_helper
INFO - 2023-04-22 15:44:08 --> Helper loaded: cookie_helper
INFO - 2023-04-22 15:44:08 --> Database Driver Class Initialized
INFO - 2023-04-22 15:44:08 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-22 15:44:08 --> Parser Class Initialized
INFO - 2023-04-22 15:44:08 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-22 15:44:08 --> Pagination Class Initialized
INFO - 2023-04-22 15:44:08 --> Form Validation Class Initialized
INFO - 2023-04-22 15:44:08 --> Controller Class Initialized
INFO - 2023-04-22 15:44:08 --> Model Class Initialized
INFO - 2023-04-22 15:44:08 --> Model Class Initialized
INFO - 2023-04-22 15:44:08 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/report/stock_report.php
DEBUG - 2023-04-22 15:44:08 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-04-22 15:44:08 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-04-22 15:44:08 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-04-22 15:44:08 --> Model Class Initialized
INFO - 2023-04-22 15:44:08 --> Model Class Initialized
INFO - 2023-04-22 15:44:08 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-04-22 15:44:08 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-04-22 15:44:08 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-04-22 15:44:08 --> Final output sent to browser
DEBUG - 2023-04-22 15:44:08 --> Total execution time: 0.1641
ERROR - 2023-04-22 15:44:09 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-22 15:44:09 --> Config Class Initialized
INFO - 2023-04-22 15:44:09 --> Hooks Class Initialized
DEBUG - 2023-04-22 15:44:09 --> UTF-8 Support Enabled
INFO - 2023-04-22 15:44:09 --> Utf8 Class Initialized
INFO - 2023-04-22 15:44:09 --> URI Class Initialized
INFO - 2023-04-22 15:44:09 --> Router Class Initialized
INFO - 2023-04-22 15:44:09 --> Output Class Initialized
INFO - 2023-04-22 15:44:09 --> Security Class Initialized
DEBUG - 2023-04-22 15:44:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-22 15:44:09 --> Input Class Initialized
INFO - 2023-04-22 15:44:09 --> Language Class Initialized
INFO - 2023-04-22 15:44:09 --> Loader Class Initialized
INFO - 2023-04-22 15:44:09 --> Helper loaded: url_helper
INFO - 2023-04-22 15:44:09 --> Helper loaded: file_helper
INFO - 2023-04-22 15:44:09 --> Helper loaded: html_helper
INFO - 2023-04-22 15:44:09 --> Helper loaded: text_helper
INFO - 2023-04-22 15:44:09 --> Helper loaded: form_helper
INFO - 2023-04-22 15:44:09 --> Helper loaded: lang_helper
INFO - 2023-04-22 15:44:09 --> Helper loaded: security_helper
INFO - 2023-04-22 15:44:09 --> Helper loaded: cookie_helper
INFO - 2023-04-22 15:44:09 --> Database Driver Class Initialized
INFO - 2023-04-22 15:44:09 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-22 15:44:09 --> Parser Class Initialized
INFO - 2023-04-22 15:44:09 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-22 15:44:09 --> Pagination Class Initialized
INFO - 2023-04-22 15:44:09 --> Form Validation Class Initialized
INFO - 2023-04-22 15:44:09 --> Controller Class Initialized
INFO - 2023-04-22 15:44:09 --> Model Class Initialized
INFO - 2023-04-22 15:44:09 --> Model Class Initialized
ERROR - 2023-04-22 15:44:09 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/application/models/Reports.php 447
INFO - 2023-04-22 15:44:09 --> Final output sent to browser
DEBUG - 2023-04-22 15:44:09 --> Total execution time: 0.0232
ERROR - 2023-04-22 15:44:14 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-22 15:44:14 --> Config Class Initialized
INFO - 2023-04-22 15:44:14 --> Hooks Class Initialized
DEBUG - 2023-04-22 15:44:14 --> UTF-8 Support Enabled
INFO - 2023-04-22 15:44:14 --> Utf8 Class Initialized
INFO - 2023-04-22 15:44:14 --> URI Class Initialized
INFO - 2023-04-22 15:44:14 --> Router Class Initialized
INFO - 2023-04-22 15:44:14 --> Output Class Initialized
INFO - 2023-04-22 15:44:14 --> Security Class Initialized
DEBUG - 2023-04-22 15:44:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-22 15:44:14 --> Input Class Initialized
INFO - 2023-04-22 15:44:14 --> Language Class Initialized
INFO - 2023-04-22 15:44:14 --> Loader Class Initialized
INFO - 2023-04-22 15:44:14 --> Helper loaded: url_helper
INFO - 2023-04-22 15:44:14 --> Helper loaded: file_helper
INFO - 2023-04-22 15:44:14 --> Helper loaded: html_helper
INFO - 2023-04-22 15:44:14 --> Helper loaded: text_helper
INFO - 2023-04-22 15:44:14 --> Helper loaded: form_helper
INFO - 2023-04-22 15:44:14 --> Helper loaded: lang_helper
INFO - 2023-04-22 15:44:14 --> Helper loaded: security_helper
INFO - 2023-04-22 15:44:14 --> Helper loaded: cookie_helper
INFO - 2023-04-22 15:44:14 --> Database Driver Class Initialized
INFO - 2023-04-22 15:44:14 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-22 15:44:14 --> Parser Class Initialized
INFO - 2023-04-22 15:44:14 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-22 15:44:14 --> Pagination Class Initialized
INFO - 2023-04-22 15:44:14 --> Form Validation Class Initialized
INFO - 2023-04-22 15:44:14 --> Controller Class Initialized
INFO - 2023-04-22 15:44:14 --> Model Class Initialized
INFO - 2023-04-22 15:44:14 --> Model Class Initialized
ERROR - 2023-04-22 15:44:14 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/application/models/Reports.php 447
INFO - 2023-04-22 15:44:14 --> Final output sent to browser
DEBUG - 2023-04-22 15:44:14 --> Total execution time: 0.0250
ERROR - 2023-04-22 15:44:39 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-22 15:44:39 --> Config Class Initialized
INFO - 2023-04-22 15:44:39 --> Hooks Class Initialized
DEBUG - 2023-04-22 15:44:39 --> UTF-8 Support Enabled
INFO - 2023-04-22 15:44:39 --> Utf8 Class Initialized
INFO - 2023-04-22 15:44:39 --> URI Class Initialized
INFO - 2023-04-22 15:44:39 --> Router Class Initialized
INFO - 2023-04-22 15:44:39 --> Output Class Initialized
INFO - 2023-04-22 15:44:39 --> Security Class Initialized
DEBUG - 2023-04-22 15:44:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-22 15:44:39 --> Input Class Initialized
INFO - 2023-04-22 15:44:39 --> Language Class Initialized
INFO - 2023-04-22 15:44:39 --> Loader Class Initialized
INFO - 2023-04-22 15:44:39 --> Helper loaded: url_helper
INFO - 2023-04-22 15:44:39 --> Helper loaded: file_helper
INFO - 2023-04-22 15:44:39 --> Helper loaded: html_helper
INFO - 2023-04-22 15:44:39 --> Helper loaded: text_helper
INFO - 2023-04-22 15:44:39 --> Helper loaded: form_helper
INFO - 2023-04-22 15:44:39 --> Helper loaded: lang_helper
INFO - 2023-04-22 15:44:39 --> Helper loaded: security_helper
INFO - 2023-04-22 15:44:39 --> Helper loaded: cookie_helper
INFO - 2023-04-22 15:44:39 --> Database Driver Class Initialized
INFO - 2023-04-22 15:44:39 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-22 15:44:39 --> Parser Class Initialized
INFO - 2023-04-22 15:44:39 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-22 15:44:39 --> Pagination Class Initialized
INFO - 2023-04-22 15:44:39 --> Form Validation Class Initialized
INFO - 2023-04-22 15:44:39 --> Controller Class Initialized
INFO - 2023-04-22 15:44:39 --> Model Class Initialized
INFO - 2023-04-22 15:44:39 --> Model Class Initialized
INFO - 2023-04-22 15:44:39 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/purchase/purchase.php
DEBUG - 2023-04-22 15:44:39 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-04-22 15:44:39 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-04-22 15:44:39 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-04-22 15:44:39 --> Model Class Initialized
INFO - 2023-04-22 15:44:39 --> Model Class Initialized
INFO - 2023-04-22 15:44:39 --> Model Class Initialized
INFO - 2023-04-22 15:44:39 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-04-22 15:44:39 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-04-22 15:44:39 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-04-22 15:44:39 --> Final output sent to browser
DEBUG - 2023-04-22 15:44:39 --> Total execution time: 0.1518
ERROR - 2023-04-22 15:44:40 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-22 15:44:40 --> Config Class Initialized
INFO - 2023-04-22 15:44:40 --> Hooks Class Initialized
DEBUG - 2023-04-22 15:44:40 --> UTF-8 Support Enabled
INFO - 2023-04-22 15:44:40 --> Utf8 Class Initialized
INFO - 2023-04-22 15:44:40 --> URI Class Initialized
INFO - 2023-04-22 15:44:40 --> Router Class Initialized
INFO - 2023-04-22 15:44:40 --> Output Class Initialized
INFO - 2023-04-22 15:44:40 --> Security Class Initialized
DEBUG - 2023-04-22 15:44:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-22 15:44:40 --> Input Class Initialized
INFO - 2023-04-22 15:44:40 --> Language Class Initialized
INFO - 2023-04-22 15:44:40 --> Loader Class Initialized
INFO - 2023-04-22 15:44:40 --> Helper loaded: url_helper
INFO - 2023-04-22 15:44:40 --> Helper loaded: file_helper
INFO - 2023-04-22 15:44:40 --> Helper loaded: html_helper
INFO - 2023-04-22 15:44:40 --> Helper loaded: text_helper
INFO - 2023-04-22 15:44:40 --> Helper loaded: form_helper
INFO - 2023-04-22 15:44:40 --> Helper loaded: lang_helper
INFO - 2023-04-22 15:44:40 --> Helper loaded: security_helper
INFO - 2023-04-22 15:44:40 --> Helper loaded: cookie_helper
INFO - 2023-04-22 15:44:40 --> Database Driver Class Initialized
INFO - 2023-04-22 15:44:40 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-22 15:44:40 --> Parser Class Initialized
INFO - 2023-04-22 15:44:40 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-22 15:44:40 --> Pagination Class Initialized
INFO - 2023-04-22 15:44:40 --> Form Validation Class Initialized
INFO - 2023-04-22 15:44:40 --> Controller Class Initialized
INFO - 2023-04-22 15:44:40 --> Model Class Initialized
INFO - 2023-04-22 15:44:40 --> Model Class Initialized
INFO - 2023-04-22 15:44:40 --> Final output sent to browser
DEBUG - 2023-04-22 15:44:40 --> Total execution time: 0.0500
ERROR - 2023-04-22 15:44:45 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-22 15:44:45 --> Config Class Initialized
INFO - 2023-04-22 15:44:45 --> Hooks Class Initialized
DEBUG - 2023-04-22 15:44:45 --> UTF-8 Support Enabled
INFO - 2023-04-22 15:44:45 --> Utf8 Class Initialized
INFO - 2023-04-22 15:44:45 --> URI Class Initialized
INFO - 2023-04-22 15:44:45 --> Router Class Initialized
INFO - 2023-04-22 15:44:45 --> Output Class Initialized
INFO - 2023-04-22 15:44:45 --> Security Class Initialized
DEBUG - 2023-04-22 15:44:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-22 15:44:45 --> Input Class Initialized
INFO - 2023-04-22 15:44:45 --> Language Class Initialized
INFO - 2023-04-22 15:44:45 --> Loader Class Initialized
INFO - 2023-04-22 15:44:45 --> Helper loaded: url_helper
INFO - 2023-04-22 15:44:45 --> Helper loaded: file_helper
INFO - 2023-04-22 15:44:45 --> Helper loaded: html_helper
INFO - 2023-04-22 15:44:45 --> Helper loaded: text_helper
INFO - 2023-04-22 15:44:45 --> Helper loaded: form_helper
INFO - 2023-04-22 15:44:45 --> Helper loaded: lang_helper
INFO - 2023-04-22 15:44:45 --> Helper loaded: security_helper
INFO - 2023-04-22 15:44:45 --> Helper loaded: cookie_helper
INFO - 2023-04-22 15:44:45 --> Database Driver Class Initialized
INFO - 2023-04-22 15:44:45 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-22 15:44:45 --> Parser Class Initialized
INFO - 2023-04-22 15:44:45 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-22 15:44:45 --> Pagination Class Initialized
INFO - 2023-04-22 15:44:45 --> Form Validation Class Initialized
INFO - 2023-04-22 15:44:45 --> Controller Class Initialized
INFO - 2023-04-22 15:44:45 --> Model Class Initialized
INFO - 2023-04-22 15:44:45 --> Model Class Initialized
INFO - 2023-04-22 15:44:45 --> Final output sent to browser
DEBUG - 2023-04-22 15:44:45 --> Total execution time: 0.0677
ERROR - 2023-04-22 15:44:58 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-22 15:44:58 --> Config Class Initialized
INFO - 2023-04-22 15:44:58 --> Hooks Class Initialized
DEBUG - 2023-04-22 15:44:58 --> UTF-8 Support Enabled
INFO - 2023-04-22 15:44:58 --> Utf8 Class Initialized
INFO - 2023-04-22 15:44:58 --> URI Class Initialized
INFO - 2023-04-22 15:44:58 --> Router Class Initialized
INFO - 2023-04-22 15:44:58 --> Output Class Initialized
INFO - 2023-04-22 15:44:58 --> Security Class Initialized
DEBUG - 2023-04-22 15:44:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-22 15:44:58 --> Input Class Initialized
INFO - 2023-04-22 15:44:58 --> Language Class Initialized
INFO - 2023-04-22 15:44:58 --> Loader Class Initialized
INFO - 2023-04-22 15:44:58 --> Helper loaded: url_helper
INFO - 2023-04-22 15:44:58 --> Helper loaded: file_helper
INFO - 2023-04-22 15:44:58 --> Helper loaded: html_helper
INFO - 2023-04-22 15:44:58 --> Helper loaded: text_helper
INFO - 2023-04-22 15:44:58 --> Helper loaded: form_helper
INFO - 2023-04-22 15:44:58 --> Helper loaded: lang_helper
INFO - 2023-04-22 15:44:58 --> Helper loaded: security_helper
INFO - 2023-04-22 15:44:58 --> Helper loaded: cookie_helper
INFO - 2023-04-22 15:44:58 --> Database Driver Class Initialized
INFO - 2023-04-22 15:44:58 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-22 15:44:58 --> Parser Class Initialized
INFO - 2023-04-22 15:44:58 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-22 15:44:58 --> Pagination Class Initialized
INFO - 2023-04-22 15:44:58 --> Form Validation Class Initialized
INFO - 2023-04-22 15:44:58 --> Controller Class Initialized
INFO - 2023-04-22 15:44:58 --> Model Class Initialized
INFO - 2023-04-22 15:44:58 --> Model Class Initialized
INFO - 2023-04-22 15:44:58 --> Model Class Initialized
INFO - 2023-04-22 15:44:58 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/report/stock_report_batch_wise.php
DEBUG - 2023-04-22 15:44:58 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-04-22 15:44:58 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-04-22 15:44:58 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-04-22 15:44:58 --> Model Class Initialized
INFO - 2023-04-22 15:44:58 --> Model Class Initialized
INFO - 2023-04-22 15:44:58 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-04-22 15:44:58 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-04-22 15:44:58 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-04-22 15:44:58 --> Final output sent to browser
DEBUG - 2023-04-22 15:44:58 --> Total execution time: 0.1379
ERROR - 2023-04-22 15:44:59 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-22 15:44:59 --> Config Class Initialized
INFO - 2023-04-22 15:44:59 --> Hooks Class Initialized
DEBUG - 2023-04-22 15:44:59 --> UTF-8 Support Enabled
INFO - 2023-04-22 15:44:59 --> Utf8 Class Initialized
INFO - 2023-04-22 15:44:59 --> URI Class Initialized
INFO - 2023-04-22 15:44:59 --> Router Class Initialized
INFO - 2023-04-22 15:44:59 --> Output Class Initialized
INFO - 2023-04-22 15:44:59 --> Security Class Initialized
DEBUG - 2023-04-22 15:44:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-22 15:44:59 --> Input Class Initialized
INFO - 2023-04-22 15:44:59 --> Language Class Initialized
INFO - 2023-04-22 15:44:59 --> Loader Class Initialized
INFO - 2023-04-22 15:44:59 --> Helper loaded: url_helper
INFO - 2023-04-22 15:44:59 --> Helper loaded: file_helper
INFO - 2023-04-22 15:44:59 --> Helper loaded: html_helper
INFO - 2023-04-22 15:44:59 --> Helper loaded: text_helper
INFO - 2023-04-22 15:44:59 --> Helper loaded: form_helper
INFO - 2023-04-22 15:44:59 --> Helper loaded: lang_helper
INFO - 2023-04-22 15:44:59 --> Helper loaded: security_helper
INFO - 2023-04-22 15:44:59 --> Helper loaded: cookie_helper
INFO - 2023-04-22 15:44:59 --> Database Driver Class Initialized
INFO - 2023-04-22 15:44:59 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-22 15:44:59 --> Parser Class Initialized
INFO - 2023-04-22 15:44:59 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-22 15:44:59 --> Pagination Class Initialized
INFO - 2023-04-22 15:44:59 --> Form Validation Class Initialized
INFO - 2023-04-22 15:44:59 --> Controller Class Initialized
INFO - 2023-04-22 15:44:59 --> Model Class Initialized
INFO - 2023-04-22 15:44:59 --> Model Class Initialized
INFO - 2023-04-22 15:44:59 --> Final output sent to browser
DEBUG - 2023-04-22 15:44:59 --> Total execution time: 0.0232
ERROR - 2023-04-22 15:45:05 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-22 15:45:05 --> Config Class Initialized
INFO - 2023-04-22 15:45:05 --> Hooks Class Initialized
DEBUG - 2023-04-22 15:45:05 --> UTF-8 Support Enabled
INFO - 2023-04-22 15:45:05 --> Utf8 Class Initialized
INFO - 2023-04-22 15:45:05 --> URI Class Initialized
INFO - 2023-04-22 15:45:05 --> Router Class Initialized
INFO - 2023-04-22 15:45:05 --> Output Class Initialized
INFO - 2023-04-22 15:45:05 --> Security Class Initialized
DEBUG - 2023-04-22 15:45:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-22 15:45:05 --> Input Class Initialized
INFO - 2023-04-22 15:45:05 --> Language Class Initialized
INFO - 2023-04-22 15:45:05 --> Loader Class Initialized
INFO - 2023-04-22 15:45:05 --> Helper loaded: url_helper
INFO - 2023-04-22 15:45:05 --> Helper loaded: file_helper
INFO - 2023-04-22 15:45:05 --> Helper loaded: html_helper
INFO - 2023-04-22 15:45:05 --> Helper loaded: text_helper
INFO - 2023-04-22 15:45:05 --> Helper loaded: form_helper
INFO - 2023-04-22 15:45:05 --> Helper loaded: lang_helper
INFO - 2023-04-22 15:45:05 --> Helper loaded: security_helper
INFO - 2023-04-22 15:45:05 --> Helper loaded: cookie_helper
INFO - 2023-04-22 15:45:05 --> Database Driver Class Initialized
INFO - 2023-04-22 15:45:05 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-22 15:45:05 --> Parser Class Initialized
INFO - 2023-04-22 15:45:05 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-22 15:45:05 --> Pagination Class Initialized
INFO - 2023-04-22 15:45:05 --> Form Validation Class Initialized
INFO - 2023-04-22 15:45:05 --> Controller Class Initialized
INFO - 2023-04-22 15:45:05 --> Model Class Initialized
INFO - 2023-04-22 15:45:05 --> Model Class Initialized
INFO - 2023-04-22 15:45:05 --> Final output sent to browser
DEBUG - 2023-04-22 15:45:05 --> Total execution time: 0.0255
ERROR - 2023-04-22 15:45:15 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-22 15:45:15 --> Config Class Initialized
INFO - 2023-04-22 15:45:15 --> Hooks Class Initialized
DEBUG - 2023-04-22 15:45:15 --> UTF-8 Support Enabled
INFO - 2023-04-22 15:45:15 --> Utf8 Class Initialized
INFO - 2023-04-22 15:45:15 --> URI Class Initialized
INFO - 2023-04-22 15:45:15 --> Router Class Initialized
INFO - 2023-04-22 15:45:15 --> Output Class Initialized
INFO - 2023-04-22 15:45:15 --> Security Class Initialized
DEBUG - 2023-04-22 15:45:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-22 15:45:15 --> Input Class Initialized
INFO - 2023-04-22 15:45:15 --> Language Class Initialized
INFO - 2023-04-22 15:45:15 --> Loader Class Initialized
INFO - 2023-04-22 15:45:15 --> Helper loaded: url_helper
INFO - 2023-04-22 15:45:15 --> Helper loaded: file_helper
INFO - 2023-04-22 15:45:15 --> Helper loaded: html_helper
INFO - 2023-04-22 15:45:15 --> Helper loaded: text_helper
INFO - 2023-04-22 15:45:15 --> Helper loaded: form_helper
INFO - 2023-04-22 15:45:15 --> Helper loaded: lang_helper
INFO - 2023-04-22 15:45:15 --> Helper loaded: security_helper
INFO - 2023-04-22 15:45:15 --> Helper loaded: cookie_helper
INFO - 2023-04-22 15:45:15 --> Database Driver Class Initialized
INFO - 2023-04-22 15:45:15 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-22 15:45:15 --> Parser Class Initialized
INFO - 2023-04-22 15:45:15 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-22 15:45:15 --> Pagination Class Initialized
INFO - 2023-04-22 15:45:15 --> Form Validation Class Initialized
INFO - 2023-04-22 15:45:15 --> Controller Class Initialized
INFO - 2023-04-22 15:45:15 --> Model Class Initialized
INFO - 2023-04-22 15:45:15 --> Model Class Initialized
INFO - 2023-04-22 15:45:15 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/purchase/purchase.php
DEBUG - 2023-04-22 15:45:15 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-04-22 15:45:15 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-04-22 15:45:15 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-04-22 15:45:15 --> Model Class Initialized
INFO - 2023-04-22 15:45:15 --> Model Class Initialized
INFO - 2023-04-22 15:45:15 --> Model Class Initialized
INFO - 2023-04-22 15:45:15 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-04-22 15:45:15 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-04-22 15:45:15 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-04-22 15:45:15 --> Final output sent to browser
DEBUG - 2023-04-22 15:45:15 --> Total execution time: 0.1444
ERROR - 2023-04-22 15:45:16 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-22 15:45:16 --> Config Class Initialized
INFO - 2023-04-22 15:45:16 --> Hooks Class Initialized
DEBUG - 2023-04-22 15:45:16 --> UTF-8 Support Enabled
INFO - 2023-04-22 15:45:16 --> Utf8 Class Initialized
INFO - 2023-04-22 15:45:16 --> URI Class Initialized
INFO - 2023-04-22 15:45:16 --> Router Class Initialized
INFO - 2023-04-22 15:45:16 --> Output Class Initialized
INFO - 2023-04-22 15:45:16 --> Security Class Initialized
DEBUG - 2023-04-22 15:45:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-22 15:45:16 --> Input Class Initialized
INFO - 2023-04-22 15:45:16 --> Language Class Initialized
INFO - 2023-04-22 15:45:16 --> Loader Class Initialized
INFO - 2023-04-22 15:45:16 --> Helper loaded: url_helper
INFO - 2023-04-22 15:45:16 --> Helper loaded: file_helper
INFO - 2023-04-22 15:45:16 --> Helper loaded: html_helper
INFO - 2023-04-22 15:45:16 --> Helper loaded: text_helper
INFO - 2023-04-22 15:45:16 --> Helper loaded: form_helper
INFO - 2023-04-22 15:45:16 --> Helper loaded: lang_helper
INFO - 2023-04-22 15:45:16 --> Helper loaded: security_helper
INFO - 2023-04-22 15:45:16 --> Helper loaded: cookie_helper
INFO - 2023-04-22 15:45:16 --> Database Driver Class Initialized
INFO - 2023-04-22 15:45:16 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-22 15:45:16 --> Parser Class Initialized
INFO - 2023-04-22 15:45:16 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-22 15:45:16 --> Pagination Class Initialized
INFO - 2023-04-22 15:45:16 --> Form Validation Class Initialized
INFO - 2023-04-22 15:45:16 --> Controller Class Initialized
INFO - 2023-04-22 15:45:16 --> Model Class Initialized
INFO - 2023-04-22 15:45:16 --> Model Class Initialized
INFO - 2023-04-22 15:45:16 --> Final output sent to browser
DEBUG - 2023-04-22 15:45:16 --> Total execution time: 0.0445
ERROR - 2023-04-22 15:45:19 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-22 15:45:19 --> Config Class Initialized
INFO - 2023-04-22 15:45:19 --> Hooks Class Initialized
DEBUG - 2023-04-22 15:45:19 --> UTF-8 Support Enabled
INFO - 2023-04-22 15:45:19 --> Utf8 Class Initialized
INFO - 2023-04-22 15:45:19 --> URI Class Initialized
INFO - 2023-04-22 15:45:19 --> Router Class Initialized
INFO - 2023-04-22 15:45:19 --> Output Class Initialized
INFO - 2023-04-22 15:45:19 --> Security Class Initialized
DEBUG - 2023-04-22 15:45:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-22 15:45:19 --> Input Class Initialized
INFO - 2023-04-22 15:45:19 --> Language Class Initialized
INFO - 2023-04-22 15:45:19 --> Loader Class Initialized
INFO - 2023-04-22 15:45:19 --> Helper loaded: url_helper
INFO - 2023-04-22 15:45:19 --> Helper loaded: file_helper
INFO - 2023-04-22 15:45:19 --> Helper loaded: html_helper
INFO - 2023-04-22 15:45:19 --> Helper loaded: text_helper
INFO - 2023-04-22 15:45:19 --> Helper loaded: form_helper
INFO - 2023-04-22 15:45:19 --> Helper loaded: lang_helper
INFO - 2023-04-22 15:45:19 --> Helper loaded: security_helper
INFO - 2023-04-22 15:45:19 --> Helper loaded: cookie_helper
INFO - 2023-04-22 15:45:19 --> Database Driver Class Initialized
INFO - 2023-04-22 15:45:19 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-22 15:45:19 --> Parser Class Initialized
INFO - 2023-04-22 15:45:19 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-22 15:45:19 --> Pagination Class Initialized
INFO - 2023-04-22 15:45:19 --> Form Validation Class Initialized
INFO - 2023-04-22 15:45:19 --> Controller Class Initialized
INFO - 2023-04-22 15:45:19 --> Model Class Initialized
INFO - 2023-04-22 15:45:19 --> Model Class Initialized
INFO - 2023-04-22 15:45:19 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/report/stock_report.php
DEBUG - 2023-04-22 15:45:19 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-04-22 15:45:19 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-04-22 15:45:19 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-04-22 15:45:19 --> Model Class Initialized
INFO - 2023-04-22 15:45:19 --> Model Class Initialized
INFO - 2023-04-22 15:45:19 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-04-22 15:45:19 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-04-22 15:45:19 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-04-22 15:45:19 --> Final output sent to browser
DEBUG - 2023-04-22 15:45:19 --> Total execution time: 0.1565
ERROR - 2023-04-22 15:45:20 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-22 15:45:20 --> Config Class Initialized
INFO - 2023-04-22 15:45:20 --> Hooks Class Initialized
DEBUG - 2023-04-22 15:45:20 --> UTF-8 Support Enabled
INFO - 2023-04-22 15:45:20 --> Utf8 Class Initialized
INFO - 2023-04-22 15:45:20 --> URI Class Initialized
INFO - 2023-04-22 15:45:20 --> Router Class Initialized
INFO - 2023-04-22 15:45:20 --> Output Class Initialized
INFO - 2023-04-22 15:45:20 --> Security Class Initialized
DEBUG - 2023-04-22 15:45:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-22 15:45:20 --> Input Class Initialized
INFO - 2023-04-22 15:45:20 --> Language Class Initialized
INFO - 2023-04-22 15:45:20 --> Loader Class Initialized
INFO - 2023-04-22 15:45:20 --> Helper loaded: url_helper
INFO - 2023-04-22 15:45:20 --> Helper loaded: file_helper
INFO - 2023-04-22 15:45:20 --> Helper loaded: html_helper
INFO - 2023-04-22 15:45:20 --> Helper loaded: text_helper
INFO - 2023-04-22 15:45:20 --> Helper loaded: form_helper
INFO - 2023-04-22 15:45:20 --> Helper loaded: lang_helper
INFO - 2023-04-22 15:45:20 --> Helper loaded: security_helper
INFO - 2023-04-22 15:45:20 --> Helper loaded: cookie_helper
INFO - 2023-04-22 15:45:20 --> Database Driver Class Initialized
INFO - 2023-04-22 15:45:20 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-22 15:45:20 --> Parser Class Initialized
INFO - 2023-04-22 15:45:20 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-22 15:45:20 --> Pagination Class Initialized
INFO - 2023-04-22 15:45:20 --> Form Validation Class Initialized
INFO - 2023-04-22 15:45:20 --> Controller Class Initialized
INFO - 2023-04-22 15:45:20 --> Model Class Initialized
INFO - 2023-04-22 15:45:20 --> Model Class Initialized
ERROR - 2023-04-22 15:45:20 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/application/models/Reports.php 447
INFO - 2023-04-22 15:45:20 --> Final output sent to browser
DEBUG - 2023-04-22 15:45:20 --> Total execution time: 0.0184
ERROR - 2023-04-22 15:45:27 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-22 15:45:27 --> Config Class Initialized
INFO - 2023-04-22 15:45:27 --> Hooks Class Initialized
DEBUG - 2023-04-22 15:45:27 --> UTF-8 Support Enabled
INFO - 2023-04-22 15:45:27 --> Utf8 Class Initialized
INFO - 2023-04-22 15:45:27 --> URI Class Initialized
INFO - 2023-04-22 15:45:27 --> Router Class Initialized
INFO - 2023-04-22 15:45:27 --> Output Class Initialized
INFO - 2023-04-22 15:45:27 --> Security Class Initialized
DEBUG - 2023-04-22 15:45:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-22 15:45:27 --> Input Class Initialized
INFO - 2023-04-22 15:45:27 --> Language Class Initialized
INFO - 2023-04-22 15:45:27 --> Loader Class Initialized
INFO - 2023-04-22 15:45:27 --> Helper loaded: url_helper
INFO - 2023-04-22 15:45:27 --> Helper loaded: file_helper
INFO - 2023-04-22 15:45:27 --> Helper loaded: html_helper
INFO - 2023-04-22 15:45:27 --> Helper loaded: text_helper
INFO - 2023-04-22 15:45:27 --> Helper loaded: form_helper
INFO - 2023-04-22 15:45:27 --> Helper loaded: lang_helper
INFO - 2023-04-22 15:45:27 --> Helper loaded: security_helper
INFO - 2023-04-22 15:45:27 --> Helper loaded: cookie_helper
INFO - 2023-04-22 15:45:27 --> Database Driver Class Initialized
INFO - 2023-04-22 15:45:27 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-22 15:45:27 --> Parser Class Initialized
INFO - 2023-04-22 15:45:27 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-22 15:45:27 --> Pagination Class Initialized
INFO - 2023-04-22 15:45:27 --> Form Validation Class Initialized
INFO - 2023-04-22 15:45:27 --> Controller Class Initialized
INFO - 2023-04-22 15:45:27 --> Model Class Initialized
INFO - 2023-04-22 15:45:27 --> Model Class Initialized
ERROR - 2023-04-22 15:45:27 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/application/models/Reports.php 447
INFO - 2023-04-22 15:45:27 --> Final output sent to browser
DEBUG - 2023-04-22 15:45:27 --> Total execution time: 0.0226
ERROR - 2023-04-22 15:46:27 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-22 15:46:27 --> Config Class Initialized
INFO - 2023-04-22 15:46:27 --> Hooks Class Initialized
DEBUG - 2023-04-22 15:46:27 --> UTF-8 Support Enabled
INFO - 2023-04-22 15:46:27 --> Utf8 Class Initialized
INFO - 2023-04-22 15:46:27 --> URI Class Initialized
INFO - 2023-04-22 15:46:27 --> Router Class Initialized
INFO - 2023-04-22 15:46:27 --> Output Class Initialized
INFO - 2023-04-22 15:46:27 --> Security Class Initialized
DEBUG - 2023-04-22 15:46:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-22 15:46:27 --> Input Class Initialized
INFO - 2023-04-22 15:46:27 --> Language Class Initialized
INFO - 2023-04-22 15:46:27 --> Loader Class Initialized
INFO - 2023-04-22 15:46:27 --> Helper loaded: url_helper
INFO - 2023-04-22 15:46:27 --> Helper loaded: file_helper
INFO - 2023-04-22 15:46:27 --> Helper loaded: html_helper
INFO - 2023-04-22 15:46:27 --> Helper loaded: text_helper
INFO - 2023-04-22 15:46:27 --> Helper loaded: form_helper
INFO - 2023-04-22 15:46:27 --> Helper loaded: lang_helper
INFO - 2023-04-22 15:46:27 --> Helper loaded: security_helper
INFO - 2023-04-22 15:46:27 --> Helper loaded: cookie_helper
INFO - 2023-04-22 15:46:27 --> Database Driver Class Initialized
INFO - 2023-04-22 15:46:27 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-22 15:46:27 --> Parser Class Initialized
INFO - 2023-04-22 15:46:27 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-22 15:46:27 --> Pagination Class Initialized
INFO - 2023-04-22 15:46:27 --> Form Validation Class Initialized
INFO - 2023-04-22 15:46:27 --> Controller Class Initialized
DEBUG - 2023-04-22 15:46:27 --> Auth class already loaded. Second attempt ignored.
INFO - 2023-04-22 15:46:27 --> Model Class Initialized
INFO - 2023-04-22 15:46:27 --> Model Class Initialized
INFO - 2023-04-22 15:46:27 --> Model Class Initialized
INFO - 2023-04-22 15:46:27 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/product/product.php
DEBUG - 2023-04-22 15:46:27 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-04-22 15:46:27 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-04-22 15:46:27 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-04-22 15:46:27 --> Model Class Initialized
INFO - 2023-04-22 15:46:27 --> Model Class Initialized
INFO - 2023-04-22 15:46:27 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-04-22 15:46:27 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-04-22 15:46:27 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-04-22 15:46:27 --> Final output sent to browser
DEBUG - 2023-04-22 15:46:27 --> Total execution time: 0.1512
ERROR - 2023-04-22 15:46:28 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-22 15:46:28 --> Config Class Initialized
INFO - 2023-04-22 15:46:28 --> Hooks Class Initialized
DEBUG - 2023-04-22 15:46:28 --> UTF-8 Support Enabled
INFO - 2023-04-22 15:46:28 --> Utf8 Class Initialized
INFO - 2023-04-22 15:46:28 --> URI Class Initialized
INFO - 2023-04-22 15:46:28 --> Router Class Initialized
INFO - 2023-04-22 15:46:28 --> Output Class Initialized
INFO - 2023-04-22 15:46:28 --> Security Class Initialized
DEBUG - 2023-04-22 15:46:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-22 15:46:28 --> Input Class Initialized
INFO - 2023-04-22 15:46:28 --> Language Class Initialized
INFO - 2023-04-22 15:46:28 --> Loader Class Initialized
INFO - 2023-04-22 15:46:28 --> Helper loaded: url_helper
INFO - 2023-04-22 15:46:28 --> Helper loaded: file_helper
INFO - 2023-04-22 15:46:28 --> Helper loaded: html_helper
INFO - 2023-04-22 15:46:28 --> Helper loaded: text_helper
INFO - 2023-04-22 15:46:28 --> Helper loaded: form_helper
INFO - 2023-04-22 15:46:28 --> Helper loaded: lang_helper
INFO - 2023-04-22 15:46:28 --> Helper loaded: security_helper
INFO - 2023-04-22 15:46:28 --> Helper loaded: cookie_helper
INFO - 2023-04-22 15:46:28 --> Database Driver Class Initialized
INFO - 2023-04-22 15:46:28 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-22 15:46:28 --> Parser Class Initialized
INFO - 2023-04-22 15:46:28 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-22 15:46:28 --> Pagination Class Initialized
INFO - 2023-04-22 15:46:28 --> Form Validation Class Initialized
INFO - 2023-04-22 15:46:28 --> Controller Class Initialized
DEBUG - 2023-04-22 15:46:28 --> Auth class already loaded. Second attempt ignored.
INFO - 2023-04-22 15:46:28 --> Model Class Initialized
INFO - 2023-04-22 15:46:28 --> Model Class Initialized
INFO - 2023-04-22 15:46:28 --> Final output sent to browser
DEBUG - 2023-04-22 15:46:28 --> Total execution time: 0.0627
ERROR - 2023-04-22 15:46:33 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-22 15:46:33 --> Config Class Initialized
INFO - 2023-04-22 15:46:33 --> Hooks Class Initialized
DEBUG - 2023-04-22 15:46:33 --> UTF-8 Support Enabled
INFO - 2023-04-22 15:46:33 --> Utf8 Class Initialized
INFO - 2023-04-22 15:46:33 --> URI Class Initialized
INFO - 2023-04-22 15:46:33 --> Router Class Initialized
INFO - 2023-04-22 15:46:33 --> Output Class Initialized
INFO - 2023-04-22 15:46:33 --> Security Class Initialized
DEBUG - 2023-04-22 15:46:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-22 15:46:33 --> Input Class Initialized
INFO - 2023-04-22 15:46:33 --> Language Class Initialized
INFO - 2023-04-22 15:46:33 --> Loader Class Initialized
INFO - 2023-04-22 15:46:33 --> Helper loaded: url_helper
INFO - 2023-04-22 15:46:33 --> Helper loaded: file_helper
INFO - 2023-04-22 15:46:33 --> Helper loaded: html_helper
INFO - 2023-04-22 15:46:33 --> Helper loaded: text_helper
INFO - 2023-04-22 15:46:33 --> Helper loaded: form_helper
INFO - 2023-04-22 15:46:33 --> Helper loaded: lang_helper
INFO - 2023-04-22 15:46:33 --> Helper loaded: security_helper
INFO - 2023-04-22 15:46:33 --> Helper loaded: cookie_helper
INFO - 2023-04-22 15:46:33 --> Database Driver Class Initialized
INFO - 2023-04-22 15:46:33 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-22 15:46:33 --> Parser Class Initialized
INFO - 2023-04-22 15:46:33 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-22 15:46:33 --> Pagination Class Initialized
INFO - 2023-04-22 15:46:33 --> Form Validation Class Initialized
INFO - 2023-04-22 15:46:33 --> Controller Class Initialized
DEBUG - 2023-04-22 15:46:33 --> Auth class already loaded. Second attempt ignored.
INFO - 2023-04-22 15:46:33 --> Model Class Initialized
INFO - 2023-04-22 15:46:33 --> Model Class Initialized
INFO - 2023-04-22 15:46:33 --> Final output sent to browser
DEBUG - 2023-04-22 15:46:33 --> Total execution time: 0.1352
ERROR - 2023-04-22 15:46:46 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-22 15:46:46 --> Config Class Initialized
INFO - 2023-04-22 15:46:46 --> Hooks Class Initialized
DEBUG - 2023-04-22 15:46:46 --> UTF-8 Support Enabled
INFO - 2023-04-22 15:46:46 --> Utf8 Class Initialized
INFO - 2023-04-22 15:46:46 --> URI Class Initialized
INFO - 2023-04-22 15:46:46 --> Router Class Initialized
INFO - 2023-04-22 15:46:46 --> Output Class Initialized
INFO - 2023-04-22 15:46:46 --> Security Class Initialized
DEBUG - 2023-04-22 15:46:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-22 15:46:46 --> Input Class Initialized
INFO - 2023-04-22 15:46:46 --> Language Class Initialized
INFO - 2023-04-22 15:46:46 --> Loader Class Initialized
INFO - 2023-04-22 15:46:46 --> Helper loaded: url_helper
INFO - 2023-04-22 15:46:46 --> Helper loaded: file_helper
INFO - 2023-04-22 15:46:46 --> Helper loaded: html_helper
INFO - 2023-04-22 15:46:46 --> Helper loaded: text_helper
INFO - 2023-04-22 15:46:46 --> Helper loaded: form_helper
INFO - 2023-04-22 15:46:46 --> Helper loaded: lang_helper
INFO - 2023-04-22 15:46:46 --> Helper loaded: security_helper
INFO - 2023-04-22 15:46:46 --> Helper loaded: cookie_helper
INFO - 2023-04-22 15:46:46 --> Database Driver Class Initialized
INFO - 2023-04-22 15:46:46 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-22 15:46:46 --> Parser Class Initialized
INFO - 2023-04-22 15:46:46 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-22 15:46:46 --> Pagination Class Initialized
INFO - 2023-04-22 15:46:46 --> Form Validation Class Initialized
INFO - 2023-04-22 15:46:46 --> Controller Class Initialized
INFO - 2023-04-22 15:46:46 --> Model Class Initialized
INFO - 2023-04-22 15:46:46 --> Model Class Initialized
ERROR - 2023-04-22 15:46:46 --> Severity: Warning --> Invalid argument supplied for foreach() /home/powera7m/app.maurnaturo.com/application/views/purchase/add_purchase_form.php 157
INFO - 2023-04-22 15:46:46 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/purchase/add_purchase_form.php
DEBUG - 2023-04-22 15:46:46 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-04-22 15:46:46 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-04-22 15:46:46 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-04-22 15:46:46 --> Model Class Initialized
INFO - 2023-04-22 15:46:46 --> Model Class Initialized
INFO - 2023-04-22 15:46:46 --> Model Class Initialized
INFO - 2023-04-22 15:46:47 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-04-22 15:46:47 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-04-22 15:46:47 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-04-22 15:46:47 --> Final output sent to browser
DEBUG - 2023-04-22 15:46:47 --> Total execution time: 0.1837
ERROR - 2023-04-22 15:47:35 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-22 15:47:35 --> Config Class Initialized
INFO - 2023-04-22 15:47:35 --> Hooks Class Initialized
DEBUG - 2023-04-22 15:47:35 --> UTF-8 Support Enabled
INFO - 2023-04-22 15:47:35 --> Utf8 Class Initialized
INFO - 2023-04-22 15:47:35 --> URI Class Initialized
INFO - 2023-04-22 15:47:35 --> Router Class Initialized
INFO - 2023-04-22 15:47:35 --> Output Class Initialized
INFO - 2023-04-22 15:47:35 --> Security Class Initialized
DEBUG - 2023-04-22 15:47:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-22 15:47:35 --> Input Class Initialized
INFO - 2023-04-22 15:47:35 --> Language Class Initialized
INFO - 2023-04-22 15:47:35 --> Loader Class Initialized
INFO - 2023-04-22 15:47:35 --> Helper loaded: url_helper
INFO - 2023-04-22 15:47:35 --> Helper loaded: file_helper
INFO - 2023-04-22 15:47:35 --> Helper loaded: html_helper
INFO - 2023-04-22 15:47:35 --> Helper loaded: text_helper
INFO - 2023-04-22 15:47:35 --> Helper loaded: form_helper
INFO - 2023-04-22 15:47:35 --> Helper loaded: lang_helper
INFO - 2023-04-22 15:47:35 --> Helper loaded: security_helper
INFO - 2023-04-22 15:47:35 --> Helper loaded: cookie_helper
INFO - 2023-04-22 15:47:35 --> Database Driver Class Initialized
INFO - 2023-04-22 15:47:35 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-22 15:47:35 --> Parser Class Initialized
INFO - 2023-04-22 15:47:35 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-22 15:47:35 --> Pagination Class Initialized
INFO - 2023-04-22 15:47:35 --> Form Validation Class Initialized
INFO - 2023-04-22 15:47:35 --> Controller Class Initialized
INFO - 2023-04-22 15:47:35 --> Model Class Initialized
DEBUG - 2023-04-22 15:47:35 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-04-22 15:47:35 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-22 15:47:35 --> Model Class Initialized
DEBUG - 2023-04-22 15:47:35 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-22 15:47:35 --> Model Class Initialized
INFO - 2023-04-22 15:47:35 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice.php
DEBUG - 2023-04-22 15:47:35 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-04-22 15:47:35 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-04-22 15:47:35 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-04-22 15:47:35 --> Model Class Initialized
INFO - 2023-04-22 15:47:35 --> Model Class Initialized
INFO - 2023-04-22 15:47:35 --> Model Class Initialized
INFO - 2023-04-22 15:47:36 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-04-22 15:47:36 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-04-22 15:47:36 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-04-22 15:47:36 --> Final output sent to browser
DEBUG - 2023-04-22 15:47:36 --> Total execution time: 0.1813
ERROR - 2023-04-22 15:47:36 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-22 15:47:36 --> Config Class Initialized
INFO - 2023-04-22 15:47:36 --> Hooks Class Initialized
DEBUG - 2023-04-22 15:47:36 --> UTF-8 Support Enabled
INFO - 2023-04-22 15:47:36 --> Utf8 Class Initialized
INFO - 2023-04-22 15:47:36 --> URI Class Initialized
INFO - 2023-04-22 15:47:36 --> Router Class Initialized
INFO - 2023-04-22 15:47:36 --> Output Class Initialized
INFO - 2023-04-22 15:47:36 --> Security Class Initialized
DEBUG - 2023-04-22 15:47:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-22 15:47:36 --> Input Class Initialized
INFO - 2023-04-22 15:47:36 --> Language Class Initialized
INFO - 2023-04-22 15:47:36 --> Loader Class Initialized
INFO - 2023-04-22 15:47:36 --> Helper loaded: url_helper
INFO - 2023-04-22 15:47:36 --> Helper loaded: file_helper
INFO - 2023-04-22 15:47:36 --> Helper loaded: html_helper
INFO - 2023-04-22 15:47:36 --> Helper loaded: text_helper
INFO - 2023-04-22 15:47:36 --> Helper loaded: form_helper
INFO - 2023-04-22 15:47:36 --> Helper loaded: lang_helper
INFO - 2023-04-22 15:47:36 --> Helper loaded: security_helper
INFO - 2023-04-22 15:47:36 --> Helper loaded: cookie_helper
INFO - 2023-04-22 15:47:36 --> Database Driver Class Initialized
INFO - 2023-04-22 15:47:36 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-22 15:47:36 --> Parser Class Initialized
INFO - 2023-04-22 15:47:36 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-22 15:47:36 --> Pagination Class Initialized
INFO - 2023-04-22 15:47:36 --> Form Validation Class Initialized
INFO - 2023-04-22 15:47:36 --> Controller Class Initialized
INFO - 2023-04-22 15:47:36 --> Model Class Initialized
DEBUG - 2023-04-22 15:47:36 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-04-22 15:47:36 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-22 15:47:36 --> Model Class Initialized
DEBUG - 2023-04-22 15:47:36 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-22 15:47:36 --> Model Class Initialized
INFO - 2023-04-22 15:47:36 --> Final output sent to browser
DEBUG - 2023-04-22 15:47:36 --> Total execution time: 0.0565
ERROR - 2023-04-22 15:47:40 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-22 15:47:40 --> Config Class Initialized
INFO - 2023-04-22 15:47:40 --> Hooks Class Initialized
DEBUG - 2023-04-22 15:47:40 --> UTF-8 Support Enabled
INFO - 2023-04-22 15:47:40 --> Utf8 Class Initialized
INFO - 2023-04-22 15:47:40 --> URI Class Initialized
INFO - 2023-04-22 15:47:40 --> Router Class Initialized
INFO - 2023-04-22 15:47:40 --> Output Class Initialized
INFO - 2023-04-22 15:47:40 --> Security Class Initialized
DEBUG - 2023-04-22 15:47:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-22 15:47:40 --> Input Class Initialized
INFO - 2023-04-22 15:47:40 --> Language Class Initialized
INFO - 2023-04-22 15:47:40 --> Loader Class Initialized
INFO - 2023-04-22 15:47:40 --> Helper loaded: url_helper
INFO - 2023-04-22 15:47:40 --> Helper loaded: file_helper
INFO - 2023-04-22 15:47:40 --> Helper loaded: html_helper
INFO - 2023-04-22 15:47:40 --> Helper loaded: text_helper
INFO - 2023-04-22 15:47:40 --> Helper loaded: form_helper
INFO - 2023-04-22 15:47:40 --> Helper loaded: lang_helper
INFO - 2023-04-22 15:47:40 --> Helper loaded: security_helper
INFO - 2023-04-22 15:47:40 --> Helper loaded: cookie_helper
INFO - 2023-04-22 15:47:40 --> Database Driver Class Initialized
INFO - 2023-04-22 15:47:40 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-22 15:47:40 --> Parser Class Initialized
INFO - 2023-04-22 15:47:40 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-22 15:47:40 --> Pagination Class Initialized
INFO - 2023-04-22 15:47:40 --> Form Validation Class Initialized
INFO - 2023-04-22 15:47:40 --> Controller Class Initialized
INFO - 2023-04-22 15:47:40 --> Model Class Initialized
DEBUG - 2023-04-22 15:47:40 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-04-22 15:47:40 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-22 15:47:40 --> Model Class Initialized
DEBUG - 2023-04-22 15:47:40 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-22 15:47:40 --> Model Class Initialized
INFO - 2023-04-22 15:47:40 --> Final output sent to browser
DEBUG - 2023-04-22 15:47:40 --> Total execution time: 0.0690
ERROR - 2023-04-22 15:48:17 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-22 15:48:17 --> Config Class Initialized
INFO - 2023-04-22 15:48:17 --> Hooks Class Initialized
DEBUG - 2023-04-22 15:48:17 --> UTF-8 Support Enabled
INFO - 2023-04-22 15:48:17 --> Utf8 Class Initialized
INFO - 2023-04-22 15:48:17 --> URI Class Initialized
INFO - 2023-04-22 15:48:17 --> Router Class Initialized
INFO - 2023-04-22 15:48:17 --> Output Class Initialized
INFO - 2023-04-22 15:48:17 --> Security Class Initialized
DEBUG - 2023-04-22 15:48:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-22 15:48:17 --> Input Class Initialized
INFO - 2023-04-22 15:48:17 --> Language Class Initialized
INFO - 2023-04-22 15:48:17 --> Loader Class Initialized
INFO - 2023-04-22 15:48:17 --> Helper loaded: url_helper
INFO - 2023-04-22 15:48:17 --> Helper loaded: file_helper
INFO - 2023-04-22 15:48:17 --> Helper loaded: html_helper
INFO - 2023-04-22 15:48:17 --> Helper loaded: text_helper
INFO - 2023-04-22 15:48:17 --> Helper loaded: form_helper
INFO - 2023-04-22 15:48:17 --> Helper loaded: lang_helper
INFO - 2023-04-22 15:48:17 --> Helper loaded: security_helper
INFO - 2023-04-22 15:48:17 --> Helper loaded: cookie_helper
INFO - 2023-04-22 15:48:17 --> Database Driver Class Initialized
INFO - 2023-04-22 15:48:17 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-22 15:48:17 --> Parser Class Initialized
INFO - 2023-04-22 15:48:17 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-22 15:48:17 --> Pagination Class Initialized
INFO - 2023-04-22 15:48:17 --> Form Validation Class Initialized
INFO - 2023-04-22 15:48:17 --> Controller Class Initialized
DEBUG - 2023-04-22 15:48:17 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-04-22 15:48:17 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-22 15:48:17 --> Model Class Initialized
INFO - 2023-04-22 15:48:17 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/sms/configure_form.php
DEBUG - 2023-04-22 15:48:17 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-04-22 15:48:17 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-04-22 15:48:17 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-04-22 15:48:17 --> Model Class Initialized
INFO - 2023-04-22 15:48:17 --> Model Class Initialized
INFO - 2023-04-22 15:48:17 --> Model Class Initialized
INFO - 2023-04-22 15:48:17 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-04-22 15:48:17 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-04-22 15:48:17 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-04-22 15:48:17 --> Final output sent to browser
DEBUG - 2023-04-22 15:48:17 --> Total execution time: 0.1513
ERROR - 2023-04-22 15:48:38 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-22 15:48:38 --> Config Class Initialized
INFO - 2023-04-22 15:48:38 --> Hooks Class Initialized
DEBUG - 2023-04-22 15:48:38 --> UTF-8 Support Enabled
INFO - 2023-04-22 15:48:38 --> Utf8 Class Initialized
INFO - 2023-04-22 15:48:38 --> URI Class Initialized
INFO - 2023-04-22 15:48:38 --> Router Class Initialized
INFO - 2023-04-22 15:48:38 --> Output Class Initialized
INFO - 2023-04-22 15:48:38 --> Security Class Initialized
DEBUG - 2023-04-22 15:48:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-22 15:48:38 --> Input Class Initialized
INFO - 2023-04-22 15:48:38 --> Language Class Initialized
INFO - 2023-04-22 15:48:38 --> Loader Class Initialized
INFO - 2023-04-22 15:48:38 --> Helper loaded: url_helper
INFO - 2023-04-22 15:48:38 --> Helper loaded: file_helper
INFO - 2023-04-22 15:48:38 --> Helper loaded: html_helper
INFO - 2023-04-22 15:48:38 --> Helper loaded: text_helper
INFO - 2023-04-22 15:48:38 --> Helper loaded: form_helper
INFO - 2023-04-22 15:48:38 --> Helper loaded: lang_helper
INFO - 2023-04-22 15:48:38 --> Helper loaded: security_helper
INFO - 2023-04-22 15:48:38 --> Helper loaded: cookie_helper
INFO - 2023-04-22 15:48:38 --> Database Driver Class Initialized
INFO - 2023-04-22 15:48:38 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-22 15:48:38 --> Parser Class Initialized
INFO - 2023-04-22 15:48:38 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-22 15:48:38 --> Pagination Class Initialized
INFO - 2023-04-22 15:48:38 --> Form Validation Class Initialized
INFO - 2023-04-22 15:48:38 --> Controller Class Initialized
DEBUG - 2023-04-22 15:48:38 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-04-22 15:48:38 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-22 15:48:38 --> Model Class Initialized
INFO - 2023-04-22 15:48:38 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/company/company.php
DEBUG - 2023-04-22 15:48:38 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-04-22 15:48:38 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-04-22 15:48:38 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-04-22 15:48:38 --> Model Class Initialized
INFO - 2023-04-22 15:48:38 --> Model Class Initialized
INFO - 2023-04-22 15:48:38 --> Model Class Initialized
INFO - 2023-04-22 15:48:38 --> Model Class Initialized
INFO - 2023-04-22 15:48:38 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-04-22 15:48:38 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-04-22 15:48:38 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-04-22 15:48:38 --> Final output sent to browser
DEBUG - 2023-04-22 15:48:38 --> Total execution time: 0.1293
ERROR - 2023-04-22 15:48:53 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-22 15:48:53 --> Config Class Initialized
INFO - 2023-04-22 15:48:53 --> Hooks Class Initialized
DEBUG - 2023-04-22 15:48:53 --> UTF-8 Support Enabled
INFO - 2023-04-22 15:48:53 --> Utf8 Class Initialized
INFO - 2023-04-22 15:48:53 --> URI Class Initialized
INFO - 2023-04-22 15:48:53 --> Router Class Initialized
INFO - 2023-04-22 15:48:53 --> Output Class Initialized
INFO - 2023-04-22 15:48:53 --> Security Class Initialized
DEBUG - 2023-04-22 15:48:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-22 15:48:53 --> Input Class Initialized
INFO - 2023-04-22 15:48:53 --> Language Class Initialized
INFO - 2023-04-22 15:48:53 --> Loader Class Initialized
INFO - 2023-04-22 15:48:53 --> Helper loaded: url_helper
INFO - 2023-04-22 15:48:53 --> Helper loaded: file_helper
INFO - 2023-04-22 15:48:53 --> Helper loaded: html_helper
INFO - 2023-04-22 15:48:53 --> Helper loaded: text_helper
INFO - 2023-04-22 15:48:53 --> Helper loaded: form_helper
INFO - 2023-04-22 15:48:53 --> Helper loaded: lang_helper
INFO - 2023-04-22 15:48:53 --> Helper loaded: security_helper
INFO - 2023-04-22 15:48:53 --> Helper loaded: cookie_helper
INFO - 2023-04-22 15:48:53 --> Database Driver Class Initialized
INFO - 2023-04-22 15:48:53 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-22 15:48:53 --> Parser Class Initialized
INFO - 2023-04-22 15:48:53 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-22 15:48:53 --> Pagination Class Initialized
INFO - 2023-04-22 15:48:53 --> Form Validation Class Initialized
INFO - 2023-04-22 15:48:53 --> Controller Class Initialized
DEBUG - 2023-04-22 15:48:53 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-04-22 15:48:53 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-22 15:48:53 --> Model Class Initialized
INFO - 2023-04-22 15:48:53 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/users/user.php
DEBUG - 2023-04-22 15:48:53 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-04-22 15:48:53 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-04-22 15:48:53 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-04-22 15:48:53 --> Model Class Initialized
INFO - 2023-04-22 15:48:53 --> Model Class Initialized
INFO - 2023-04-22 15:48:53 --> Model Class Initialized
INFO - 2023-04-22 15:48:53 --> Model Class Initialized
INFO - 2023-04-22 15:48:54 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-04-22 15:48:54 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-04-22 15:48:54 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-04-22 15:48:54 --> Final output sent to browser
DEBUG - 2023-04-22 15:48:54 --> Total execution time: 0.2520
ERROR - 2023-04-22 15:49:26 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-22 15:49:26 --> Config Class Initialized
INFO - 2023-04-22 15:49:26 --> Hooks Class Initialized
DEBUG - 2023-04-22 15:49:26 --> UTF-8 Support Enabled
INFO - 2023-04-22 15:49:26 --> Utf8 Class Initialized
INFO - 2023-04-22 15:49:26 --> URI Class Initialized
INFO - 2023-04-22 15:49:26 --> Router Class Initialized
INFO - 2023-04-22 15:49:26 --> Output Class Initialized
INFO - 2023-04-22 15:49:26 --> Security Class Initialized
DEBUG - 2023-04-22 15:49:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-22 15:49:26 --> Input Class Initialized
INFO - 2023-04-22 15:49:26 --> Language Class Initialized
INFO - 2023-04-22 15:49:26 --> Loader Class Initialized
INFO - 2023-04-22 15:49:26 --> Helper loaded: url_helper
INFO - 2023-04-22 15:49:26 --> Helper loaded: file_helper
INFO - 2023-04-22 15:49:26 --> Helper loaded: html_helper
INFO - 2023-04-22 15:49:26 --> Helper loaded: text_helper
INFO - 2023-04-22 15:49:26 --> Helper loaded: form_helper
INFO - 2023-04-22 15:49:26 --> Helper loaded: lang_helper
INFO - 2023-04-22 15:49:26 --> Helper loaded: security_helper
INFO - 2023-04-22 15:49:26 --> Helper loaded: cookie_helper
INFO - 2023-04-22 15:49:26 --> Database Driver Class Initialized
INFO - 2023-04-22 15:49:26 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-22 15:49:26 --> Parser Class Initialized
INFO - 2023-04-22 15:49:26 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-22 15:49:26 --> Pagination Class Initialized
INFO - 2023-04-22 15:49:26 --> Form Validation Class Initialized
INFO - 2023-04-22 15:49:26 --> Controller Class Initialized
DEBUG - 2023-04-22 15:49:26 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-04-22 15:49:26 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-22 15:49:26 --> Model Class Initialized
INFO - 2023-04-22 15:49:27 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/users/user.php
DEBUG - 2023-04-22 15:49:27 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-04-22 15:49:27 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-04-22 15:49:27 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-04-22 15:49:27 --> Model Class Initialized
INFO - 2023-04-22 15:49:27 --> Model Class Initialized
INFO - 2023-04-22 15:49:27 --> Model Class Initialized
INFO - 2023-04-22 15:49:27 --> Model Class Initialized
INFO - 2023-04-22 15:49:27 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-04-22 15:49:27 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-04-22 15:49:27 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-04-22 15:49:27 --> Final output sent to browser
DEBUG - 2023-04-22 15:49:27 --> Total execution time: 0.2639
ERROR - 2023-04-22 15:50:10 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-22 15:50:10 --> Config Class Initialized
INFO - 2023-04-22 15:50:10 --> Hooks Class Initialized
DEBUG - 2023-04-22 15:50:10 --> UTF-8 Support Enabled
INFO - 2023-04-22 15:50:10 --> Utf8 Class Initialized
INFO - 2023-04-22 15:50:10 --> URI Class Initialized
INFO - 2023-04-22 15:50:10 --> Router Class Initialized
INFO - 2023-04-22 15:50:10 --> Output Class Initialized
INFO - 2023-04-22 15:50:10 --> Security Class Initialized
DEBUG - 2023-04-22 15:50:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-22 15:50:10 --> Input Class Initialized
INFO - 2023-04-22 15:50:10 --> Language Class Initialized
INFO - 2023-04-22 15:50:10 --> Loader Class Initialized
INFO - 2023-04-22 15:50:10 --> Helper loaded: url_helper
INFO - 2023-04-22 15:50:10 --> Helper loaded: file_helper
INFO - 2023-04-22 15:50:10 --> Helper loaded: html_helper
INFO - 2023-04-22 15:50:10 --> Helper loaded: text_helper
INFO - 2023-04-22 15:50:10 --> Helper loaded: form_helper
INFO - 2023-04-22 15:50:10 --> Helper loaded: lang_helper
INFO - 2023-04-22 15:50:10 --> Helper loaded: security_helper
INFO - 2023-04-22 15:50:10 --> Helper loaded: cookie_helper
INFO - 2023-04-22 15:50:10 --> Database Driver Class Initialized
INFO - 2023-04-22 15:50:10 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-22 15:50:10 --> Parser Class Initialized
INFO - 2023-04-22 15:50:10 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-22 15:50:10 --> Pagination Class Initialized
INFO - 2023-04-22 15:50:10 --> Form Validation Class Initialized
INFO - 2023-04-22 15:50:10 --> Controller Class Initialized
DEBUG - 2023-04-22 15:50:10 --> Auth class already loaded. Second attempt ignored.
INFO - 2023-04-22 15:50:10 --> Model Class Initialized
INFO - 2023-04-22 15:50:10 --> Model Class Initialized
INFO - 2023-04-22 15:50:10 --> Model Class Initialized
INFO - 2023-04-22 15:50:10 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/product/product.php
DEBUG - 2023-04-22 15:50:10 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-04-22 15:50:10 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-04-22 15:50:10 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-04-22 15:50:10 --> Model Class Initialized
INFO - 2023-04-22 15:50:10 --> Model Class Initialized
INFO - 2023-04-22 15:50:10 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-04-22 15:50:10 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-04-22 15:50:10 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-04-22 15:50:10 --> Final output sent to browser
DEBUG - 2023-04-22 15:50:10 --> Total execution time: 0.1563
ERROR - 2023-04-22 15:50:11 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-22 15:50:11 --> Config Class Initialized
INFO - 2023-04-22 15:50:11 --> Hooks Class Initialized
DEBUG - 2023-04-22 15:50:11 --> UTF-8 Support Enabled
INFO - 2023-04-22 15:50:11 --> Utf8 Class Initialized
INFO - 2023-04-22 15:50:11 --> URI Class Initialized
INFO - 2023-04-22 15:50:11 --> Router Class Initialized
INFO - 2023-04-22 15:50:11 --> Output Class Initialized
INFO - 2023-04-22 15:50:11 --> Security Class Initialized
DEBUG - 2023-04-22 15:50:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-22 15:50:11 --> Input Class Initialized
INFO - 2023-04-22 15:50:11 --> Language Class Initialized
INFO - 2023-04-22 15:50:11 --> Loader Class Initialized
INFO - 2023-04-22 15:50:11 --> Helper loaded: url_helper
INFO - 2023-04-22 15:50:11 --> Helper loaded: file_helper
INFO - 2023-04-22 15:50:11 --> Helper loaded: html_helper
INFO - 2023-04-22 15:50:11 --> Helper loaded: text_helper
INFO - 2023-04-22 15:50:11 --> Helper loaded: form_helper
INFO - 2023-04-22 15:50:11 --> Helper loaded: lang_helper
INFO - 2023-04-22 15:50:11 --> Helper loaded: security_helper
INFO - 2023-04-22 15:50:11 --> Helper loaded: cookie_helper
INFO - 2023-04-22 15:50:11 --> Database Driver Class Initialized
INFO - 2023-04-22 15:50:11 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-22 15:50:11 --> Parser Class Initialized
INFO - 2023-04-22 15:50:11 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-22 15:50:11 --> Pagination Class Initialized
INFO - 2023-04-22 15:50:11 --> Form Validation Class Initialized
INFO - 2023-04-22 15:50:11 --> Controller Class Initialized
DEBUG - 2023-04-22 15:50:11 --> Auth class already loaded. Second attempt ignored.
INFO - 2023-04-22 15:50:11 --> Model Class Initialized
INFO - 2023-04-22 15:50:11 --> Model Class Initialized
INFO - 2023-04-22 15:50:11 --> Final output sent to browser
DEBUG - 2023-04-22 15:50:11 --> Total execution time: 0.0523
ERROR - 2023-04-22 15:50:18 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-22 15:50:18 --> Config Class Initialized
INFO - 2023-04-22 15:50:18 --> Hooks Class Initialized
DEBUG - 2023-04-22 15:50:18 --> UTF-8 Support Enabled
INFO - 2023-04-22 15:50:18 --> Utf8 Class Initialized
INFO - 2023-04-22 15:50:18 --> URI Class Initialized
INFO - 2023-04-22 15:50:18 --> Router Class Initialized
INFO - 2023-04-22 15:50:18 --> Output Class Initialized
INFO - 2023-04-22 15:50:18 --> Security Class Initialized
DEBUG - 2023-04-22 15:50:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-22 15:50:18 --> Input Class Initialized
INFO - 2023-04-22 15:50:18 --> Language Class Initialized
INFO - 2023-04-22 15:50:18 --> Loader Class Initialized
INFO - 2023-04-22 15:50:18 --> Helper loaded: url_helper
INFO - 2023-04-22 15:50:18 --> Helper loaded: file_helper
INFO - 2023-04-22 15:50:18 --> Helper loaded: html_helper
INFO - 2023-04-22 15:50:18 --> Helper loaded: text_helper
INFO - 2023-04-22 15:50:18 --> Helper loaded: form_helper
INFO - 2023-04-22 15:50:18 --> Helper loaded: lang_helper
INFO - 2023-04-22 15:50:18 --> Helper loaded: security_helper
INFO - 2023-04-22 15:50:18 --> Helper loaded: cookie_helper
INFO - 2023-04-22 15:50:18 --> Database Driver Class Initialized
INFO - 2023-04-22 15:50:18 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-22 15:50:18 --> Parser Class Initialized
INFO - 2023-04-22 15:50:18 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-22 15:50:18 --> Pagination Class Initialized
INFO - 2023-04-22 15:50:18 --> Form Validation Class Initialized
INFO - 2023-04-22 15:50:18 --> Controller Class Initialized
DEBUG - 2023-04-22 15:50:18 --> Auth class already loaded. Second attempt ignored.
INFO - 2023-04-22 15:50:18 --> Model Class Initialized
INFO - 2023-04-22 15:50:18 --> Model Class Initialized
INFO - 2023-04-22 15:50:18 --> Final output sent to browser
DEBUG - 2023-04-22 15:50:18 --> Total execution time: 0.1140
ERROR - 2023-04-22 15:51:05 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-22 15:51:05 --> Config Class Initialized
INFO - 2023-04-22 15:51:05 --> Hooks Class Initialized
DEBUG - 2023-04-22 15:51:05 --> UTF-8 Support Enabled
INFO - 2023-04-22 15:51:05 --> Utf8 Class Initialized
INFO - 2023-04-22 15:51:05 --> URI Class Initialized
INFO - 2023-04-22 15:51:05 --> Router Class Initialized
INFO - 2023-04-22 15:51:05 --> Output Class Initialized
INFO - 2023-04-22 15:51:05 --> Security Class Initialized
DEBUG - 2023-04-22 15:51:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-22 15:51:05 --> Input Class Initialized
INFO - 2023-04-22 15:51:05 --> Language Class Initialized
INFO - 2023-04-22 15:51:05 --> Loader Class Initialized
INFO - 2023-04-22 15:51:05 --> Helper loaded: url_helper
INFO - 2023-04-22 15:51:05 --> Helper loaded: file_helper
INFO - 2023-04-22 15:51:05 --> Helper loaded: html_helper
INFO - 2023-04-22 15:51:05 --> Helper loaded: text_helper
INFO - 2023-04-22 15:51:05 --> Helper loaded: form_helper
INFO - 2023-04-22 15:51:05 --> Helper loaded: lang_helper
INFO - 2023-04-22 15:51:05 --> Helper loaded: security_helper
INFO - 2023-04-22 15:51:05 --> Helper loaded: cookie_helper
INFO - 2023-04-22 15:51:05 --> Database Driver Class Initialized
INFO - 2023-04-22 15:51:05 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-22 15:51:05 --> Parser Class Initialized
INFO - 2023-04-22 15:51:05 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-22 15:51:05 --> Pagination Class Initialized
INFO - 2023-04-22 15:51:05 --> Form Validation Class Initialized
INFO - 2023-04-22 15:51:05 --> Controller Class Initialized
INFO - 2023-04-22 15:51:05 --> Model Class Initialized
INFO - 2023-04-22 15:51:05 --> Model Class Initialized
INFO - 2023-04-22 15:51:05 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/purchase/purchase.php
DEBUG - 2023-04-22 15:51:05 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-04-22 15:51:05 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-04-22 15:51:05 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-04-22 15:51:05 --> Model Class Initialized
INFO - 2023-04-22 15:51:05 --> Model Class Initialized
INFO - 2023-04-22 15:51:05 --> Model Class Initialized
INFO - 2023-04-22 15:51:05 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-04-22 15:51:05 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-04-22 15:51:05 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-04-22 15:51:05 --> Final output sent to browser
DEBUG - 2023-04-22 15:51:05 --> Total execution time: 0.1640
ERROR - 2023-04-22 15:51:06 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-22 15:51:06 --> Config Class Initialized
INFO - 2023-04-22 15:51:06 --> Hooks Class Initialized
DEBUG - 2023-04-22 15:51:06 --> UTF-8 Support Enabled
INFO - 2023-04-22 15:51:06 --> Utf8 Class Initialized
INFO - 2023-04-22 15:51:06 --> URI Class Initialized
INFO - 2023-04-22 15:51:06 --> Router Class Initialized
INFO - 2023-04-22 15:51:06 --> Output Class Initialized
INFO - 2023-04-22 15:51:06 --> Security Class Initialized
DEBUG - 2023-04-22 15:51:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-22 15:51:06 --> Input Class Initialized
INFO - 2023-04-22 15:51:06 --> Language Class Initialized
INFO - 2023-04-22 15:51:06 --> Loader Class Initialized
INFO - 2023-04-22 15:51:06 --> Helper loaded: url_helper
INFO - 2023-04-22 15:51:06 --> Helper loaded: file_helper
INFO - 2023-04-22 15:51:06 --> Helper loaded: html_helper
INFO - 2023-04-22 15:51:06 --> Helper loaded: text_helper
INFO - 2023-04-22 15:51:06 --> Helper loaded: form_helper
INFO - 2023-04-22 15:51:06 --> Helper loaded: lang_helper
INFO - 2023-04-22 15:51:06 --> Helper loaded: security_helper
INFO - 2023-04-22 15:51:06 --> Helper loaded: cookie_helper
INFO - 2023-04-22 15:51:06 --> Database Driver Class Initialized
INFO - 2023-04-22 15:51:06 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-22 15:51:06 --> Parser Class Initialized
INFO - 2023-04-22 15:51:06 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-22 15:51:06 --> Pagination Class Initialized
INFO - 2023-04-22 15:51:06 --> Form Validation Class Initialized
INFO - 2023-04-22 15:51:06 --> Controller Class Initialized
INFO - 2023-04-22 15:51:06 --> Model Class Initialized
INFO - 2023-04-22 15:51:06 --> Model Class Initialized
INFO - 2023-04-22 15:51:06 --> Final output sent to browser
DEBUG - 2023-04-22 15:51:06 --> Total execution time: 0.0473
ERROR - 2023-04-22 15:51:10 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-22 15:51:10 --> Config Class Initialized
INFO - 2023-04-22 15:51:10 --> Hooks Class Initialized
DEBUG - 2023-04-22 15:51:10 --> UTF-8 Support Enabled
INFO - 2023-04-22 15:51:10 --> Utf8 Class Initialized
INFO - 2023-04-22 15:51:10 --> URI Class Initialized
INFO - 2023-04-22 15:51:10 --> Router Class Initialized
INFO - 2023-04-22 15:51:10 --> Output Class Initialized
INFO - 2023-04-22 15:51:10 --> Security Class Initialized
DEBUG - 2023-04-22 15:51:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-22 15:51:10 --> Input Class Initialized
INFO - 2023-04-22 15:51:10 --> Language Class Initialized
INFO - 2023-04-22 15:51:10 --> Loader Class Initialized
INFO - 2023-04-22 15:51:10 --> Helper loaded: url_helper
INFO - 2023-04-22 15:51:10 --> Helper loaded: file_helper
INFO - 2023-04-22 15:51:10 --> Helper loaded: html_helper
INFO - 2023-04-22 15:51:10 --> Helper loaded: text_helper
INFO - 2023-04-22 15:51:10 --> Helper loaded: form_helper
INFO - 2023-04-22 15:51:10 --> Helper loaded: lang_helper
INFO - 2023-04-22 15:51:10 --> Helper loaded: security_helper
INFO - 2023-04-22 15:51:10 --> Helper loaded: cookie_helper
INFO - 2023-04-22 15:51:10 --> Database Driver Class Initialized
INFO - 2023-04-22 15:51:10 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-22 15:51:10 --> Parser Class Initialized
INFO - 2023-04-22 15:51:10 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-22 15:51:10 --> Pagination Class Initialized
INFO - 2023-04-22 15:51:10 --> Form Validation Class Initialized
INFO - 2023-04-22 15:51:10 --> Controller Class Initialized
INFO - 2023-04-22 15:51:10 --> Model Class Initialized
INFO - 2023-04-22 15:51:10 --> Model Class Initialized
INFO - 2023-04-22 15:51:11 --> Final output sent to browser
DEBUG - 2023-04-22 15:51:11 --> Total execution time: 0.0873
ERROR - 2023-04-22 15:51:20 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-22 15:51:20 --> Config Class Initialized
INFO - 2023-04-22 15:51:20 --> Hooks Class Initialized
DEBUG - 2023-04-22 15:51:20 --> UTF-8 Support Enabled
INFO - 2023-04-22 15:51:20 --> Utf8 Class Initialized
INFO - 2023-04-22 15:51:20 --> URI Class Initialized
INFO - 2023-04-22 15:51:20 --> Router Class Initialized
INFO - 2023-04-22 15:51:20 --> Output Class Initialized
INFO - 2023-04-22 15:51:20 --> Security Class Initialized
DEBUG - 2023-04-22 15:51:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-22 15:51:20 --> Input Class Initialized
INFO - 2023-04-22 15:51:20 --> Language Class Initialized
INFO - 2023-04-22 15:51:20 --> Loader Class Initialized
INFO - 2023-04-22 15:51:20 --> Helper loaded: url_helper
INFO - 2023-04-22 15:51:20 --> Helper loaded: file_helper
INFO - 2023-04-22 15:51:20 --> Helper loaded: html_helper
INFO - 2023-04-22 15:51:20 --> Helper loaded: text_helper
INFO - 2023-04-22 15:51:20 --> Helper loaded: form_helper
INFO - 2023-04-22 15:51:20 --> Helper loaded: lang_helper
INFO - 2023-04-22 15:51:20 --> Helper loaded: security_helper
INFO - 2023-04-22 15:51:20 --> Helper loaded: cookie_helper
INFO - 2023-04-22 15:51:20 --> Database Driver Class Initialized
INFO - 2023-04-22 15:51:20 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-22 15:51:20 --> Parser Class Initialized
INFO - 2023-04-22 15:51:20 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-22 15:51:20 --> Pagination Class Initialized
INFO - 2023-04-22 15:51:20 --> Form Validation Class Initialized
INFO - 2023-04-22 15:51:20 --> Controller Class Initialized
INFO - 2023-04-22 15:51:20 --> Model Class Initialized
INFO - 2023-04-22 15:51:20 --> Model Class Initialized
INFO - 2023-04-22 15:51:20 --> Model Class Initialized
INFO - 2023-04-22 15:51:20 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/report/stock_report_batch_wise.php
DEBUG - 2023-04-22 15:51:20 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-04-22 15:51:20 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-04-22 15:51:20 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-04-22 15:51:20 --> Model Class Initialized
INFO - 2023-04-22 15:51:20 --> Model Class Initialized
INFO - 2023-04-22 15:51:20 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-04-22 15:51:20 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-04-22 15:51:20 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-04-22 15:51:20 --> Final output sent to browser
DEBUG - 2023-04-22 15:51:20 --> Total execution time: 0.1413
ERROR - 2023-04-22 15:51:22 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-22 15:51:22 --> Config Class Initialized
INFO - 2023-04-22 15:51:22 --> Hooks Class Initialized
DEBUG - 2023-04-22 15:51:22 --> UTF-8 Support Enabled
INFO - 2023-04-22 15:51:22 --> Utf8 Class Initialized
INFO - 2023-04-22 15:51:22 --> URI Class Initialized
INFO - 2023-04-22 15:51:22 --> Router Class Initialized
INFO - 2023-04-22 15:51:22 --> Output Class Initialized
INFO - 2023-04-22 15:51:22 --> Security Class Initialized
DEBUG - 2023-04-22 15:51:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-22 15:51:22 --> Input Class Initialized
INFO - 2023-04-22 15:51:22 --> Language Class Initialized
INFO - 2023-04-22 15:51:22 --> Loader Class Initialized
INFO - 2023-04-22 15:51:22 --> Helper loaded: url_helper
INFO - 2023-04-22 15:51:22 --> Helper loaded: file_helper
INFO - 2023-04-22 15:51:22 --> Helper loaded: html_helper
INFO - 2023-04-22 15:51:22 --> Helper loaded: text_helper
INFO - 2023-04-22 15:51:22 --> Helper loaded: form_helper
INFO - 2023-04-22 15:51:22 --> Helper loaded: lang_helper
INFO - 2023-04-22 15:51:22 --> Helper loaded: security_helper
INFO - 2023-04-22 15:51:22 --> Helper loaded: cookie_helper
INFO - 2023-04-22 15:51:22 --> Database Driver Class Initialized
INFO - 2023-04-22 15:51:22 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-22 15:51:22 --> Parser Class Initialized
INFO - 2023-04-22 15:51:22 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-22 15:51:22 --> Pagination Class Initialized
INFO - 2023-04-22 15:51:22 --> Form Validation Class Initialized
INFO - 2023-04-22 15:51:22 --> Controller Class Initialized
INFO - 2023-04-22 15:51:22 --> Model Class Initialized
INFO - 2023-04-22 15:51:22 --> Model Class Initialized
INFO - 2023-04-22 15:51:22 --> Final output sent to browser
DEBUG - 2023-04-22 15:51:22 --> Total execution time: 0.0194
ERROR - 2023-04-22 15:51:27 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-22 15:51:27 --> Config Class Initialized
INFO - 2023-04-22 15:51:27 --> Hooks Class Initialized
DEBUG - 2023-04-22 15:51:27 --> UTF-8 Support Enabled
INFO - 2023-04-22 15:51:27 --> Utf8 Class Initialized
INFO - 2023-04-22 15:51:27 --> URI Class Initialized
INFO - 2023-04-22 15:51:27 --> Router Class Initialized
INFO - 2023-04-22 15:51:27 --> Output Class Initialized
INFO - 2023-04-22 15:51:27 --> Security Class Initialized
DEBUG - 2023-04-22 15:51:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-22 15:51:27 --> Input Class Initialized
INFO - 2023-04-22 15:51:27 --> Language Class Initialized
INFO - 2023-04-22 15:51:27 --> Loader Class Initialized
INFO - 2023-04-22 15:51:27 --> Helper loaded: url_helper
INFO - 2023-04-22 15:51:27 --> Helper loaded: file_helper
INFO - 2023-04-22 15:51:27 --> Helper loaded: html_helper
INFO - 2023-04-22 15:51:27 --> Helper loaded: text_helper
INFO - 2023-04-22 15:51:27 --> Helper loaded: form_helper
INFO - 2023-04-22 15:51:27 --> Helper loaded: lang_helper
INFO - 2023-04-22 15:51:27 --> Helper loaded: security_helper
INFO - 2023-04-22 15:51:27 --> Helper loaded: cookie_helper
INFO - 2023-04-22 15:51:27 --> Database Driver Class Initialized
INFO - 2023-04-22 15:51:27 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-22 15:51:27 --> Parser Class Initialized
INFO - 2023-04-22 15:51:27 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-22 15:51:27 --> Pagination Class Initialized
INFO - 2023-04-22 15:51:27 --> Form Validation Class Initialized
INFO - 2023-04-22 15:51:27 --> Controller Class Initialized
INFO - 2023-04-22 15:51:27 --> Model Class Initialized
INFO - 2023-04-22 15:51:27 --> Model Class Initialized
INFO - 2023-04-22 15:51:27 --> Final output sent to browser
DEBUG - 2023-04-22 15:51:27 --> Total execution time: 0.0225
ERROR - 2023-04-22 15:51:37 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-22 15:51:37 --> Config Class Initialized
INFO - 2023-04-22 15:51:37 --> Hooks Class Initialized
DEBUG - 2023-04-22 15:51:37 --> UTF-8 Support Enabled
INFO - 2023-04-22 15:51:37 --> Utf8 Class Initialized
INFO - 2023-04-22 15:51:37 --> URI Class Initialized
INFO - 2023-04-22 15:51:37 --> Router Class Initialized
INFO - 2023-04-22 15:51:37 --> Output Class Initialized
INFO - 2023-04-22 15:51:37 --> Security Class Initialized
DEBUG - 2023-04-22 15:51:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-22 15:51:37 --> Input Class Initialized
INFO - 2023-04-22 15:51:37 --> Language Class Initialized
INFO - 2023-04-22 15:51:37 --> Loader Class Initialized
INFO - 2023-04-22 15:51:37 --> Helper loaded: url_helper
INFO - 2023-04-22 15:51:37 --> Helper loaded: file_helper
INFO - 2023-04-22 15:51:37 --> Helper loaded: html_helper
INFO - 2023-04-22 15:51:37 --> Helper loaded: text_helper
INFO - 2023-04-22 15:51:37 --> Helper loaded: form_helper
INFO - 2023-04-22 15:51:37 --> Helper loaded: lang_helper
INFO - 2023-04-22 15:51:37 --> Helper loaded: security_helper
INFO - 2023-04-22 15:51:37 --> Helper loaded: cookie_helper
INFO - 2023-04-22 15:51:37 --> Database Driver Class Initialized
INFO - 2023-04-22 15:51:37 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-22 15:51:37 --> Parser Class Initialized
INFO - 2023-04-22 15:51:37 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-22 15:51:37 --> Pagination Class Initialized
INFO - 2023-04-22 15:51:37 --> Form Validation Class Initialized
INFO - 2023-04-22 15:51:37 --> Controller Class Initialized
DEBUG - 2023-04-22 15:51:37 --> Auth class already loaded. Second attempt ignored.
INFO - 2023-04-22 15:51:37 --> Model Class Initialized
INFO - 2023-04-22 15:51:37 --> Model Class Initialized
INFO - 2023-04-22 15:51:37 --> Model Class Initialized
INFO - 2023-04-22 15:51:37 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/product/product_details.php
DEBUG - 2023-04-22 15:51:37 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-04-22 15:51:37 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-04-22 15:51:37 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-04-22 15:51:37 --> Model Class Initialized
INFO - 2023-04-22 15:51:37 --> Model Class Initialized
INFO - 2023-04-22 15:51:37 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-04-22 15:51:37 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-04-22 15:51:37 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-04-22 15:51:37 --> Final output sent to browser
DEBUG - 2023-04-22 15:51:37 --> Total execution time: 0.1693
ERROR - 2023-04-22 15:53:03 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-22 15:53:03 --> Config Class Initialized
INFO - 2023-04-22 15:53:03 --> Hooks Class Initialized
DEBUG - 2023-04-22 15:53:03 --> UTF-8 Support Enabled
INFO - 2023-04-22 15:53:03 --> Utf8 Class Initialized
INFO - 2023-04-22 15:53:03 --> URI Class Initialized
INFO - 2023-04-22 15:53:03 --> Router Class Initialized
INFO - 2023-04-22 15:53:03 --> Output Class Initialized
INFO - 2023-04-22 15:53:03 --> Security Class Initialized
DEBUG - 2023-04-22 15:53:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-22 15:53:03 --> Input Class Initialized
INFO - 2023-04-22 15:53:03 --> Language Class Initialized
INFO - 2023-04-22 15:53:03 --> Loader Class Initialized
INFO - 2023-04-22 15:53:03 --> Helper loaded: url_helper
INFO - 2023-04-22 15:53:03 --> Helper loaded: file_helper
INFO - 2023-04-22 15:53:03 --> Helper loaded: html_helper
INFO - 2023-04-22 15:53:03 --> Helper loaded: text_helper
INFO - 2023-04-22 15:53:03 --> Helper loaded: form_helper
INFO - 2023-04-22 15:53:03 --> Helper loaded: lang_helper
INFO - 2023-04-22 15:53:03 --> Helper loaded: security_helper
INFO - 2023-04-22 15:53:03 --> Helper loaded: cookie_helper
INFO - 2023-04-22 15:53:03 --> Database Driver Class Initialized
INFO - 2023-04-22 15:53:03 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-22 15:53:03 --> Parser Class Initialized
INFO - 2023-04-22 15:53:03 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-22 15:53:03 --> Pagination Class Initialized
INFO - 2023-04-22 15:53:03 --> Form Validation Class Initialized
INFO - 2023-04-22 15:53:03 --> Controller Class Initialized
INFO - 2023-04-22 15:53:03 --> Model Class Initialized
INFO - 2023-04-22 15:53:03 --> Model Class Initialized
INFO - 2023-04-22 15:53:03 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/purchase/purchase.php
DEBUG - 2023-04-22 15:53:03 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-04-22 15:53:03 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-04-22 15:53:03 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-04-22 15:53:03 --> Model Class Initialized
INFO - 2023-04-22 15:53:04 --> Model Class Initialized
INFO - 2023-04-22 15:53:04 --> Model Class Initialized
INFO - 2023-04-22 15:53:04 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-04-22 15:53:04 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-04-22 15:53:04 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-04-22 15:53:04 --> Final output sent to browser
DEBUG - 2023-04-22 15:53:04 --> Total execution time: 0.1790
ERROR - 2023-04-22 15:53:04 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-22 15:53:04 --> Config Class Initialized
INFO - 2023-04-22 15:53:04 --> Hooks Class Initialized
DEBUG - 2023-04-22 15:53:04 --> UTF-8 Support Enabled
INFO - 2023-04-22 15:53:04 --> Utf8 Class Initialized
INFO - 2023-04-22 15:53:04 --> URI Class Initialized
INFO - 2023-04-22 15:53:04 --> Router Class Initialized
INFO - 2023-04-22 15:53:04 --> Output Class Initialized
INFO - 2023-04-22 15:53:04 --> Security Class Initialized
DEBUG - 2023-04-22 15:53:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-22 15:53:04 --> Input Class Initialized
INFO - 2023-04-22 15:53:04 --> Language Class Initialized
INFO - 2023-04-22 15:53:04 --> Loader Class Initialized
INFO - 2023-04-22 15:53:04 --> Helper loaded: url_helper
INFO - 2023-04-22 15:53:04 --> Helper loaded: file_helper
INFO - 2023-04-22 15:53:04 --> Helper loaded: html_helper
INFO - 2023-04-22 15:53:04 --> Helper loaded: text_helper
INFO - 2023-04-22 15:53:04 --> Helper loaded: form_helper
INFO - 2023-04-22 15:53:04 --> Helper loaded: lang_helper
INFO - 2023-04-22 15:53:04 --> Helper loaded: security_helper
INFO - 2023-04-22 15:53:04 --> Helper loaded: cookie_helper
INFO - 2023-04-22 15:53:04 --> Database Driver Class Initialized
INFO - 2023-04-22 15:53:04 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-22 15:53:04 --> Parser Class Initialized
INFO - 2023-04-22 15:53:04 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-22 15:53:04 --> Pagination Class Initialized
INFO - 2023-04-22 15:53:04 --> Form Validation Class Initialized
INFO - 2023-04-22 15:53:04 --> Controller Class Initialized
INFO - 2023-04-22 15:53:04 --> Model Class Initialized
INFO - 2023-04-22 15:53:05 --> Model Class Initialized
INFO - 2023-04-22 15:53:05 --> Final output sent to browser
DEBUG - 2023-04-22 15:53:05 --> Total execution time: 0.0570
ERROR - 2023-04-22 15:53:24 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-22 15:53:24 --> Config Class Initialized
INFO - 2023-04-22 15:53:24 --> Hooks Class Initialized
DEBUG - 2023-04-22 15:53:24 --> UTF-8 Support Enabled
INFO - 2023-04-22 15:53:24 --> Utf8 Class Initialized
INFO - 2023-04-22 15:53:24 --> URI Class Initialized
INFO - 2023-04-22 15:53:24 --> Router Class Initialized
INFO - 2023-04-22 15:53:24 --> Output Class Initialized
INFO - 2023-04-22 15:53:24 --> Security Class Initialized
DEBUG - 2023-04-22 15:53:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-22 15:53:24 --> Input Class Initialized
INFO - 2023-04-22 15:53:24 --> Language Class Initialized
INFO - 2023-04-22 15:53:24 --> Loader Class Initialized
INFO - 2023-04-22 15:53:24 --> Helper loaded: url_helper
INFO - 2023-04-22 15:53:24 --> Helper loaded: file_helper
INFO - 2023-04-22 15:53:24 --> Helper loaded: html_helper
INFO - 2023-04-22 15:53:24 --> Helper loaded: text_helper
INFO - 2023-04-22 15:53:24 --> Helper loaded: form_helper
INFO - 2023-04-22 15:53:24 --> Helper loaded: lang_helper
INFO - 2023-04-22 15:53:24 --> Helper loaded: security_helper
INFO - 2023-04-22 15:53:24 --> Helper loaded: cookie_helper
INFO - 2023-04-22 15:53:24 --> Database Driver Class Initialized
INFO - 2023-04-22 15:53:24 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-22 15:53:24 --> Parser Class Initialized
INFO - 2023-04-22 15:53:24 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-22 15:53:24 --> Pagination Class Initialized
INFO - 2023-04-22 15:53:24 --> Form Validation Class Initialized
INFO - 2023-04-22 15:53:24 --> Controller Class Initialized
INFO - 2023-04-22 15:53:24 --> Model Class Initialized
INFO - 2023-04-22 15:53:24 --> Model Class Initialized
INFO - 2023-04-22 15:53:24 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/purchase/purchase.php
DEBUG - 2023-04-22 15:53:24 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-04-22 15:53:24 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-04-22 15:53:24 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-04-22 15:53:24 --> Model Class Initialized
INFO - 2023-04-22 15:53:24 --> Model Class Initialized
INFO - 2023-04-22 15:53:24 --> Model Class Initialized
INFO - 2023-04-22 15:53:25 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-04-22 15:53:25 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-04-22 15:53:25 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-04-22 15:53:25 --> Final output sent to browser
DEBUG - 2023-04-22 15:53:25 --> Total execution time: 0.1579
ERROR - 2023-04-22 15:53:25 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-22 15:53:25 --> Config Class Initialized
INFO - 2023-04-22 15:53:25 --> Hooks Class Initialized
DEBUG - 2023-04-22 15:53:25 --> UTF-8 Support Enabled
INFO - 2023-04-22 15:53:25 --> Utf8 Class Initialized
INFO - 2023-04-22 15:53:25 --> URI Class Initialized
INFO - 2023-04-22 15:53:25 --> Router Class Initialized
INFO - 2023-04-22 15:53:25 --> Output Class Initialized
INFO - 2023-04-22 15:53:25 --> Security Class Initialized
DEBUG - 2023-04-22 15:53:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-22 15:53:25 --> Input Class Initialized
INFO - 2023-04-22 15:53:25 --> Language Class Initialized
INFO - 2023-04-22 15:53:25 --> Loader Class Initialized
INFO - 2023-04-22 15:53:25 --> Helper loaded: url_helper
INFO - 2023-04-22 15:53:25 --> Helper loaded: file_helper
INFO - 2023-04-22 15:53:25 --> Helper loaded: html_helper
INFO - 2023-04-22 15:53:25 --> Helper loaded: text_helper
INFO - 2023-04-22 15:53:25 --> Helper loaded: form_helper
INFO - 2023-04-22 15:53:25 --> Helper loaded: lang_helper
INFO - 2023-04-22 15:53:25 --> Helper loaded: security_helper
INFO - 2023-04-22 15:53:25 --> Helper loaded: cookie_helper
INFO - 2023-04-22 15:53:25 --> Database Driver Class Initialized
INFO - 2023-04-22 15:53:25 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-22 15:53:25 --> Parser Class Initialized
INFO - 2023-04-22 15:53:25 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-22 15:53:25 --> Pagination Class Initialized
INFO - 2023-04-22 15:53:25 --> Form Validation Class Initialized
INFO - 2023-04-22 15:53:25 --> Controller Class Initialized
INFO - 2023-04-22 15:53:25 --> Model Class Initialized
INFO - 2023-04-22 15:53:25 --> Model Class Initialized
INFO - 2023-04-22 15:53:25 --> Final output sent to browser
DEBUG - 2023-04-22 15:53:25 --> Total execution time: 0.0462
ERROR - 2023-04-22 15:53:29 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-22 15:53:29 --> Config Class Initialized
INFO - 2023-04-22 15:53:29 --> Hooks Class Initialized
DEBUG - 2023-04-22 15:53:29 --> UTF-8 Support Enabled
INFO - 2023-04-22 15:53:29 --> Utf8 Class Initialized
INFO - 2023-04-22 15:53:29 --> URI Class Initialized
INFO - 2023-04-22 15:53:29 --> Router Class Initialized
INFO - 2023-04-22 15:53:29 --> Output Class Initialized
INFO - 2023-04-22 15:53:29 --> Security Class Initialized
DEBUG - 2023-04-22 15:53:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-22 15:53:29 --> Input Class Initialized
INFO - 2023-04-22 15:53:29 --> Language Class Initialized
INFO - 2023-04-22 15:53:29 --> Loader Class Initialized
INFO - 2023-04-22 15:53:29 --> Helper loaded: url_helper
INFO - 2023-04-22 15:53:29 --> Helper loaded: file_helper
INFO - 2023-04-22 15:53:29 --> Helper loaded: html_helper
INFO - 2023-04-22 15:53:29 --> Helper loaded: text_helper
INFO - 2023-04-22 15:53:29 --> Helper loaded: form_helper
INFO - 2023-04-22 15:53:29 --> Helper loaded: lang_helper
INFO - 2023-04-22 15:53:29 --> Helper loaded: security_helper
INFO - 2023-04-22 15:53:29 --> Helper loaded: cookie_helper
INFO - 2023-04-22 15:53:29 --> Database Driver Class Initialized
INFO - 2023-04-22 15:53:29 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-22 15:53:29 --> Parser Class Initialized
INFO - 2023-04-22 15:53:29 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-22 15:53:29 --> Pagination Class Initialized
INFO - 2023-04-22 15:53:29 --> Form Validation Class Initialized
INFO - 2023-04-22 15:53:29 --> Controller Class Initialized
INFO - 2023-04-22 15:53:29 --> Model Class Initialized
INFO - 2023-04-22 15:53:29 --> Model Class Initialized
INFO - 2023-04-22 15:53:29 --> Final output sent to browser
DEBUG - 2023-04-22 15:53:29 --> Total execution time: 0.0774
ERROR - 2023-04-22 15:53:51 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-22 15:53:51 --> Config Class Initialized
INFO - 2023-04-22 15:53:51 --> Hooks Class Initialized
DEBUG - 2023-04-22 15:53:51 --> UTF-8 Support Enabled
INFO - 2023-04-22 15:53:51 --> Utf8 Class Initialized
INFO - 2023-04-22 15:53:51 --> URI Class Initialized
DEBUG - 2023-04-22 15:53:51 --> No URI present. Default controller set.
INFO - 2023-04-22 15:53:51 --> Router Class Initialized
INFO - 2023-04-22 15:53:51 --> Output Class Initialized
INFO - 2023-04-22 15:53:51 --> Security Class Initialized
DEBUG - 2023-04-22 15:53:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-22 15:53:51 --> Input Class Initialized
INFO - 2023-04-22 15:53:51 --> Language Class Initialized
INFO - 2023-04-22 15:53:51 --> Loader Class Initialized
INFO - 2023-04-22 15:53:51 --> Helper loaded: url_helper
INFO - 2023-04-22 15:53:51 --> Helper loaded: file_helper
INFO - 2023-04-22 15:53:51 --> Helper loaded: html_helper
INFO - 2023-04-22 15:53:51 --> Helper loaded: text_helper
INFO - 2023-04-22 15:53:51 --> Helper loaded: form_helper
INFO - 2023-04-22 15:53:51 --> Helper loaded: lang_helper
INFO - 2023-04-22 15:53:51 --> Helper loaded: security_helper
INFO - 2023-04-22 15:53:51 --> Helper loaded: cookie_helper
INFO - 2023-04-22 15:53:51 --> Database Driver Class Initialized
INFO - 2023-04-22 15:53:51 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-22 15:53:51 --> Parser Class Initialized
INFO - 2023-04-22 15:53:51 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-22 15:53:51 --> Pagination Class Initialized
INFO - 2023-04-22 15:53:51 --> Form Validation Class Initialized
INFO - 2023-04-22 15:53:51 --> Controller Class Initialized
INFO - 2023-04-22 15:53:51 --> Model Class Initialized
DEBUG - 2023-04-22 15:53:51 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-22 15:53:51 --> Model Class Initialized
DEBUG - 2023-04-22 15:53:51 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-22 15:53:51 --> Model Class Initialized
INFO - 2023-04-22 15:53:51 --> Model Class Initialized
INFO - 2023-04-22 15:53:51 --> Model Class Initialized
INFO - 2023-04-22 15:53:51 --> Model Class Initialized
DEBUG - 2023-04-22 15:53:51 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-04-22 15:53:51 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-22 15:53:51 --> Model Class Initialized
INFO - 2023-04-22 15:53:51 --> Model Class Initialized
INFO - 2023-04-22 15:53:51 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-04-22 15:53:51 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-04-22 15:53:51 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-04-22 15:53:51 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-04-22 15:53:51 --> Model Class Initialized
INFO - 2023-04-22 15:53:51 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-04-22 15:53:51 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-04-22 15:53:51 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-04-22 15:53:51 --> Final output sent to browser
DEBUG - 2023-04-22 15:53:51 --> Total execution time: 0.1986
ERROR - 2023-04-22 15:54:13 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-22 15:54:13 --> Config Class Initialized
INFO - 2023-04-22 15:54:13 --> Hooks Class Initialized
DEBUG - 2023-04-22 15:54:13 --> UTF-8 Support Enabled
INFO - 2023-04-22 15:54:13 --> Utf8 Class Initialized
INFO - 2023-04-22 15:54:13 --> URI Class Initialized
INFO - 2023-04-22 15:54:13 --> Router Class Initialized
INFO - 2023-04-22 15:54:13 --> Output Class Initialized
INFO - 2023-04-22 15:54:13 --> Security Class Initialized
DEBUG - 2023-04-22 15:54:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-22 15:54:13 --> Input Class Initialized
INFO - 2023-04-22 15:54:13 --> Language Class Initialized
INFO - 2023-04-22 15:54:13 --> Loader Class Initialized
INFO - 2023-04-22 15:54:13 --> Helper loaded: url_helper
INFO - 2023-04-22 15:54:13 --> Helper loaded: file_helper
INFO - 2023-04-22 15:54:13 --> Helper loaded: html_helper
INFO - 2023-04-22 15:54:13 --> Helper loaded: text_helper
INFO - 2023-04-22 15:54:13 --> Helper loaded: form_helper
INFO - 2023-04-22 15:54:13 --> Helper loaded: lang_helper
INFO - 2023-04-22 15:54:13 --> Helper loaded: security_helper
INFO - 2023-04-22 15:54:13 --> Helper loaded: cookie_helper
INFO - 2023-04-22 15:54:13 --> Database Driver Class Initialized
INFO - 2023-04-22 15:54:13 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-22 15:54:13 --> Parser Class Initialized
INFO - 2023-04-22 15:54:13 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-22 15:54:13 --> Pagination Class Initialized
INFO - 2023-04-22 15:54:13 --> Form Validation Class Initialized
INFO - 2023-04-22 15:54:13 --> Controller Class Initialized
INFO - 2023-04-22 15:54:13 --> Model Class Initialized
DEBUG - 2023-04-22 15:54:13 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-04-22 15:54:13 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-22 15:54:13 --> Model Class Initialized
DEBUG - 2023-04-22 15:54:13 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-22 15:54:13 --> Model Class Initialized
INFO - 2023-04-22 15:54:13 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice.php
DEBUG - 2023-04-22 15:54:13 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-04-22 15:54:13 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-04-22 15:54:13 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-04-22 15:54:13 --> Model Class Initialized
INFO - 2023-04-22 15:54:13 --> Model Class Initialized
INFO - 2023-04-22 15:54:13 --> Model Class Initialized
INFO - 2023-04-22 15:54:13 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-04-22 15:54:13 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-04-22 15:54:13 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-04-22 15:54:13 --> Final output sent to browser
DEBUG - 2023-04-22 15:54:13 --> Total execution time: 0.1353
ERROR - 2023-04-22 15:54:13 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-22 15:54:13 --> Config Class Initialized
INFO - 2023-04-22 15:54:13 --> Hooks Class Initialized
DEBUG - 2023-04-22 15:54:13 --> UTF-8 Support Enabled
INFO - 2023-04-22 15:54:13 --> Utf8 Class Initialized
INFO - 2023-04-22 15:54:13 --> URI Class Initialized
INFO - 2023-04-22 15:54:13 --> Router Class Initialized
INFO - 2023-04-22 15:54:13 --> Output Class Initialized
INFO - 2023-04-22 15:54:13 --> Security Class Initialized
DEBUG - 2023-04-22 15:54:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-22 15:54:13 --> Input Class Initialized
INFO - 2023-04-22 15:54:13 --> Language Class Initialized
INFO - 2023-04-22 15:54:13 --> Loader Class Initialized
INFO - 2023-04-22 15:54:13 --> Helper loaded: url_helper
INFO - 2023-04-22 15:54:13 --> Helper loaded: file_helper
INFO - 2023-04-22 15:54:13 --> Helper loaded: html_helper
INFO - 2023-04-22 15:54:13 --> Helper loaded: text_helper
INFO - 2023-04-22 15:54:13 --> Helper loaded: form_helper
INFO - 2023-04-22 15:54:13 --> Helper loaded: lang_helper
INFO - 2023-04-22 15:54:13 --> Helper loaded: security_helper
INFO - 2023-04-22 15:54:13 --> Helper loaded: cookie_helper
INFO - 2023-04-22 15:54:13 --> Database Driver Class Initialized
INFO - 2023-04-22 15:54:13 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-22 15:54:13 --> Parser Class Initialized
INFO - 2023-04-22 15:54:13 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-22 15:54:13 --> Pagination Class Initialized
INFO - 2023-04-22 15:54:13 --> Form Validation Class Initialized
INFO - 2023-04-22 15:54:13 --> Controller Class Initialized
INFO - 2023-04-22 15:54:13 --> Model Class Initialized
DEBUG - 2023-04-22 15:54:13 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-04-22 15:54:13 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-22 15:54:13 --> Model Class Initialized
DEBUG - 2023-04-22 15:54:13 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-22 15:54:13 --> Model Class Initialized
INFO - 2023-04-22 15:54:13 --> Final output sent to browser
DEBUG - 2023-04-22 15:54:13 --> Total execution time: 0.0585
ERROR - 2023-04-22 15:54:21 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-22 15:54:21 --> Config Class Initialized
INFO - 2023-04-22 15:54:21 --> Hooks Class Initialized
DEBUG - 2023-04-22 15:54:21 --> UTF-8 Support Enabled
INFO - 2023-04-22 15:54:21 --> Utf8 Class Initialized
INFO - 2023-04-22 15:54:21 --> URI Class Initialized
INFO - 2023-04-22 15:54:21 --> Router Class Initialized
INFO - 2023-04-22 15:54:21 --> Output Class Initialized
INFO - 2023-04-22 15:54:21 --> Security Class Initialized
DEBUG - 2023-04-22 15:54:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-22 15:54:21 --> Input Class Initialized
INFO - 2023-04-22 15:54:21 --> Language Class Initialized
INFO - 2023-04-22 15:54:21 --> Loader Class Initialized
INFO - 2023-04-22 15:54:21 --> Helper loaded: url_helper
INFO - 2023-04-22 15:54:21 --> Helper loaded: file_helper
INFO - 2023-04-22 15:54:21 --> Helper loaded: html_helper
INFO - 2023-04-22 15:54:21 --> Helper loaded: text_helper
INFO - 2023-04-22 15:54:21 --> Helper loaded: form_helper
INFO - 2023-04-22 15:54:21 --> Helper loaded: lang_helper
INFO - 2023-04-22 15:54:21 --> Helper loaded: security_helper
INFO - 2023-04-22 15:54:21 --> Helper loaded: cookie_helper
INFO - 2023-04-22 15:54:21 --> Database Driver Class Initialized
INFO - 2023-04-22 15:54:21 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-22 15:54:21 --> Parser Class Initialized
INFO - 2023-04-22 15:54:21 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-22 15:54:21 --> Pagination Class Initialized
INFO - 2023-04-22 15:54:21 --> Form Validation Class Initialized
INFO - 2023-04-22 15:54:21 --> Controller Class Initialized
INFO - 2023-04-22 15:54:21 --> Model Class Initialized
DEBUG - 2023-04-22 15:54:21 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-04-22 15:54:21 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-22 15:54:21 --> Model Class Initialized
DEBUG - 2023-04-22 15:54:21 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-22 15:54:21 --> Model Class Initialized
INFO - 2023-04-22 15:54:21 --> Final output sent to browser
DEBUG - 2023-04-22 15:54:21 --> Total execution time: 0.0728
ERROR - 2023-04-22 15:54:45 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-22 15:54:45 --> Config Class Initialized
INFO - 2023-04-22 15:54:45 --> Hooks Class Initialized
DEBUG - 2023-04-22 15:54:45 --> UTF-8 Support Enabled
INFO - 2023-04-22 15:54:45 --> Utf8 Class Initialized
INFO - 2023-04-22 15:54:45 --> URI Class Initialized
INFO - 2023-04-22 15:54:45 --> Router Class Initialized
INFO - 2023-04-22 15:54:45 --> Output Class Initialized
INFO - 2023-04-22 15:54:45 --> Security Class Initialized
DEBUG - 2023-04-22 15:54:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-22 15:54:45 --> Input Class Initialized
INFO - 2023-04-22 15:54:45 --> Language Class Initialized
INFO - 2023-04-22 15:54:45 --> Loader Class Initialized
INFO - 2023-04-22 15:54:45 --> Helper loaded: url_helper
INFO - 2023-04-22 15:54:45 --> Helper loaded: file_helper
INFO - 2023-04-22 15:54:45 --> Helper loaded: html_helper
INFO - 2023-04-22 15:54:45 --> Helper loaded: text_helper
INFO - 2023-04-22 15:54:45 --> Helper loaded: form_helper
INFO - 2023-04-22 15:54:45 --> Helper loaded: lang_helper
INFO - 2023-04-22 15:54:45 --> Helper loaded: security_helper
INFO - 2023-04-22 15:54:45 --> Helper loaded: cookie_helper
INFO - 2023-04-22 15:54:45 --> Database Driver Class Initialized
INFO - 2023-04-22 15:54:45 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-22 15:54:45 --> Parser Class Initialized
INFO - 2023-04-22 15:54:45 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-22 15:54:45 --> Pagination Class Initialized
INFO - 2023-04-22 15:54:45 --> Form Validation Class Initialized
INFO - 2023-04-22 15:54:45 --> Controller Class Initialized
INFO - 2023-04-22 15:54:45 --> Model Class Initialized
DEBUG - 2023-04-22 15:54:45 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-04-22 15:54:45 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-22 15:54:45 --> Model Class Initialized
DEBUG - 2023-04-22 15:54:45 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-22 15:54:45 --> Model Class Initialized
INFO - 2023-04-22 15:54:45 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/invoice/invoice.php
DEBUG - 2023-04-22 15:54:45 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-04-22 15:54:45 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-04-22 15:54:45 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-04-22 15:54:45 --> Model Class Initialized
INFO - 2023-04-22 15:54:45 --> Model Class Initialized
INFO - 2023-04-22 15:54:45 --> Model Class Initialized
INFO - 2023-04-22 15:54:45 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-04-22 15:54:45 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-04-22 15:54:45 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-04-22 15:54:45 --> Final output sent to browser
DEBUG - 2023-04-22 15:54:45 --> Total execution time: 0.1417
ERROR - 2023-04-22 15:54:46 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-22 15:54:46 --> Config Class Initialized
INFO - 2023-04-22 15:54:46 --> Hooks Class Initialized
DEBUG - 2023-04-22 15:54:46 --> UTF-8 Support Enabled
INFO - 2023-04-22 15:54:46 --> Utf8 Class Initialized
INFO - 2023-04-22 15:54:46 --> URI Class Initialized
INFO - 2023-04-22 15:54:46 --> Router Class Initialized
INFO - 2023-04-22 15:54:46 --> Output Class Initialized
INFO - 2023-04-22 15:54:46 --> Security Class Initialized
DEBUG - 2023-04-22 15:54:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-22 15:54:46 --> Input Class Initialized
INFO - 2023-04-22 15:54:46 --> Language Class Initialized
INFO - 2023-04-22 15:54:46 --> Loader Class Initialized
INFO - 2023-04-22 15:54:46 --> Helper loaded: url_helper
INFO - 2023-04-22 15:54:46 --> Helper loaded: file_helper
INFO - 2023-04-22 15:54:46 --> Helper loaded: html_helper
INFO - 2023-04-22 15:54:46 --> Helper loaded: text_helper
INFO - 2023-04-22 15:54:46 --> Helper loaded: form_helper
INFO - 2023-04-22 15:54:46 --> Helper loaded: lang_helper
INFO - 2023-04-22 15:54:46 --> Helper loaded: security_helper
INFO - 2023-04-22 15:54:46 --> Helper loaded: cookie_helper
INFO - 2023-04-22 15:54:46 --> Database Driver Class Initialized
INFO - 2023-04-22 15:54:46 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-22 15:54:46 --> Parser Class Initialized
INFO - 2023-04-22 15:54:46 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-22 15:54:46 --> Pagination Class Initialized
INFO - 2023-04-22 15:54:46 --> Form Validation Class Initialized
INFO - 2023-04-22 15:54:46 --> Controller Class Initialized
INFO - 2023-04-22 15:54:46 --> Model Class Initialized
DEBUG - 2023-04-22 15:54:46 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-04-22 15:54:46 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-22 15:54:46 --> Model Class Initialized
DEBUG - 2023-04-22 15:54:46 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-22 15:54:46 --> Model Class Initialized
INFO - 2023-04-22 15:54:46 --> Final output sent to browser
DEBUG - 2023-04-22 15:54:46 --> Total execution time: 0.0243
ERROR - 2023-04-22 15:54:49 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-22 15:54:49 --> Config Class Initialized
INFO - 2023-04-22 15:54:49 --> Hooks Class Initialized
DEBUG - 2023-04-22 15:54:49 --> UTF-8 Support Enabled
INFO - 2023-04-22 15:54:49 --> Utf8 Class Initialized
INFO - 2023-04-22 15:54:49 --> URI Class Initialized
DEBUG - 2023-04-22 15:54:49 --> No URI present. Default controller set.
INFO - 2023-04-22 15:54:49 --> Router Class Initialized
INFO - 2023-04-22 15:54:49 --> Output Class Initialized
INFO - 2023-04-22 15:54:49 --> Security Class Initialized
DEBUG - 2023-04-22 15:54:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-22 15:54:49 --> Input Class Initialized
INFO - 2023-04-22 15:54:49 --> Language Class Initialized
INFO - 2023-04-22 15:54:49 --> Loader Class Initialized
INFO - 2023-04-22 15:54:49 --> Helper loaded: url_helper
INFO - 2023-04-22 15:54:49 --> Helper loaded: file_helper
INFO - 2023-04-22 15:54:49 --> Helper loaded: html_helper
INFO - 2023-04-22 15:54:49 --> Helper loaded: text_helper
INFO - 2023-04-22 15:54:49 --> Helper loaded: form_helper
INFO - 2023-04-22 15:54:49 --> Helper loaded: lang_helper
INFO - 2023-04-22 15:54:49 --> Helper loaded: security_helper
INFO - 2023-04-22 15:54:49 --> Helper loaded: cookie_helper
INFO - 2023-04-22 15:54:49 --> Database Driver Class Initialized
INFO - 2023-04-22 15:54:49 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-22 15:54:49 --> Parser Class Initialized
INFO - 2023-04-22 15:54:49 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-22 15:54:49 --> Pagination Class Initialized
INFO - 2023-04-22 15:54:49 --> Form Validation Class Initialized
INFO - 2023-04-22 15:54:49 --> Controller Class Initialized
INFO - 2023-04-22 15:54:49 --> Model Class Initialized
DEBUG - 2023-04-22 15:54:49 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-22 15:54:49 --> Model Class Initialized
DEBUG - 2023-04-22 15:54:49 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-22 15:54:49 --> Model Class Initialized
INFO - 2023-04-22 15:54:49 --> Model Class Initialized
INFO - 2023-04-22 15:54:49 --> Model Class Initialized
INFO - 2023-04-22 15:54:49 --> Model Class Initialized
DEBUG - 2023-04-22 15:54:49 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-04-22 15:54:49 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-22 15:54:49 --> Model Class Initialized
INFO - 2023-04-22 15:54:49 --> Model Class Initialized
INFO - 2023-04-22 15:54:49 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-04-22 15:54:49 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-04-22 15:54:49 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-04-22 15:54:49 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-04-22 15:54:49 --> Model Class Initialized
INFO - 2023-04-22 15:54:49 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-04-22 15:54:49 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-04-22 15:54:49 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-04-22 15:54:49 --> Final output sent to browser
DEBUG - 2023-04-22 15:54:49 --> Total execution time: 0.1756
ERROR - 2023-04-22 15:55:04 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-22 15:55:04 --> Config Class Initialized
INFO - 2023-04-22 15:55:04 --> Hooks Class Initialized
DEBUG - 2023-04-22 15:55:04 --> UTF-8 Support Enabled
INFO - 2023-04-22 15:55:04 --> Utf8 Class Initialized
INFO - 2023-04-22 15:55:04 --> URI Class Initialized
INFO - 2023-04-22 15:55:04 --> Router Class Initialized
INFO - 2023-04-22 15:55:04 --> Output Class Initialized
INFO - 2023-04-22 15:55:04 --> Security Class Initialized
DEBUG - 2023-04-22 15:55:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-22 15:55:04 --> Input Class Initialized
INFO - 2023-04-22 15:55:04 --> Language Class Initialized
INFO - 2023-04-22 15:55:04 --> Loader Class Initialized
INFO - 2023-04-22 15:55:04 --> Helper loaded: url_helper
INFO - 2023-04-22 15:55:04 --> Helper loaded: file_helper
INFO - 2023-04-22 15:55:04 --> Helper loaded: html_helper
INFO - 2023-04-22 15:55:04 --> Helper loaded: text_helper
INFO - 2023-04-22 15:55:04 --> Helper loaded: form_helper
INFO - 2023-04-22 15:55:04 --> Helper loaded: lang_helper
INFO - 2023-04-22 15:55:04 --> Helper loaded: security_helper
INFO - 2023-04-22 15:55:04 --> Helper loaded: cookie_helper
INFO - 2023-04-22 15:55:04 --> Database Driver Class Initialized
INFO - 2023-04-22 15:55:04 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-22 15:55:04 --> Parser Class Initialized
INFO - 2023-04-22 15:55:04 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-22 15:55:04 --> Pagination Class Initialized
INFO - 2023-04-22 15:55:04 --> Form Validation Class Initialized
INFO - 2023-04-22 15:55:04 --> Controller Class Initialized
INFO - 2023-04-22 15:55:04 --> Model Class Initialized
INFO - 2023-04-22 15:55:04 --> Model Class Initialized
INFO - 2023-04-22 15:55:04 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/purchase/purchase.php
DEBUG - 2023-04-22 15:55:04 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-04-22 15:55:04 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-04-22 15:55:04 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-04-22 15:55:04 --> Model Class Initialized
INFO - 2023-04-22 15:55:04 --> Model Class Initialized
INFO - 2023-04-22 15:55:04 --> Model Class Initialized
INFO - 2023-04-22 15:55:04 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-04-22 15:55:04 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-04-22 15:55:04 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-04-22 15:55:04 --> Final output sent to browser
DEBUG - 2023-04-22 15:55:04 --> Total execution time: 0.1471
ERROR - 2023-04-22 15:55:05 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-22 15:55:05 --> Config Class Initialized
INFO - 2023-04-22 15:55:05 --> Hooks Class Initialized
DEBUG - 2023-04-22 15:55:05 --> UTF-8 Support Enabled
INFO - 2023-04-22 15:55:05 --> Utf8 Class Initialized
INFO - 2023-04-22 15:55:05 --> URI Class Initialized
INFO - 2023-04-22 15:55:05 --> Router Class Initialized
INFO - 2023-04-22 15:55:05 --> Output Class Initialized
INFO - 2023-04-22 15:55:05 --> Security Class Initialized
DEBUG - 2023-04-22 15:55:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-22 15:55:05 --> Input Class Initialized
INFO - 2023-04-22 15:55:05 --> Language Class Initialized
INFO - 2023-04-22 15:55:05 --> Loader Class Initialized
INFO - 2023-04-22 15:55:05 --> Helper loaded: url_helper
INFO - 2023-04-22 15:55:05 --> Helper loaded: file_helper
INFO - 2023-04-22 15:55:05 --> Helper loaded: html_helper
INFO - 2023-04-22 15:55:05 --> Helper loaded: text_helper
INFO - 2023-04-22 15:55:05 --> Helper loaded: form_helper
INFO - 2023-04-22 15:55:05 --> Helper loaded: lang_helper
INFO - 2023-04-22 15:55:05 --> Helper loaded: security_helper
INFO - 2023-04-22 15:55:05 --> Helper loaded: cookie_helper
INFO - 2023-04-22 15:55:05 --> Database Driver Class Initialized
INFO - 2023-04-22 15:55:05 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-22 15:55:05 --> Parser Class Initialized
INFO - 2023-04-22 15:55:05 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-22 15:55:05 --> Pagination Class Initialized
INFO - 2023-04-22 15:55:05 --> Form Validation Class Initialized
INFO - 2023-04-22 15:55:05 --> Controller Class Initialized
INFO - 2023-04-22 15:55:05 --> Model Class Initialized
INFO - 2023-04-22 15:55:05 --> Model Class Initialized
INFO - 2023-04-22 15:55:05 --> Final output sent to browser
DEBUG - 2023-04-22 15:55:05 --> Total execution time: 0.0498
ERROR - 2023-04-22 15:55:09 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-22 15:55:09 --> Config Class Initialized
INFO - 2023-04-22 15:55:09 --> Hooks Class Initialized
DEBUG - 2023-04-22 15:55:09 --> UTF-8 Support Enabled
INFO - 2023-04-22 15:55:09 --> Utf8 Class Initialized
INFO - 2023-04-22 15:55:09 --> URI Class Initialized
INFO - 2023-04-22 15:55:09 --> Router Class Initialized
INFO - 2023-04-22 15:55:09 --> Output Class Initialized
INFO - 2023-04-22 15:55:09 --> Security Class Initialized
DEBUG - 2023-04-22 15:55:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-22 15:55:09 --> Input Class Initialized
INFO - 2023-04-22 15:55:09 --> Language Class Initialized
INFO - 2023-04-22 15:55:09 --> Loader Class Initialized
INFO - 2023-04-22 15:55:09 --> Helper loaded: url_helper
INFO - 2023-04-22 15:55:09 --> Helper loaded: file_helper
INFO - 2023-04-22 15:55:09 --> Helper loaded: html_helper
INFO - 2023-04-22 15:55:09 --> Helper loaded: text_helper
INFO - 2023-04-22 15:55:09 --> Helper loaded: form_helper
INFO - 2023-04-22 15:55:09 --> Helper loaded: lang_helper
INFO - 2023-04-22 15:55:09 --> Helper loaded: security_helper
INFO - 2023-04-22 15:55:09 --> Helper loaded: cookie_helper
INFO - 2023-04-22 15:55:09 --> Database Driver Class Initialized
INFO - 2023-04-22 15:55:09 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-22 15:55:09 --> Parser Class Initialized
INFO - 2023-04-22 15:55:09 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-22 15:55:09 --> Pagination Class Initialized
INFO - 2023-04-22 15:55:09 --> Form Validation Class Initialized
INFO - 2023-04-22 15:55:09 --> Controller Class Initialized
INFO - 2023-04-22 15:55:09 --> Model Class Initialized
INFO - 2023-04-22 15:55:09 --> Model Class Initialized
INFO - 2023-04-22 15:55:09 --> Final output sent to browser
DEBUG - 2023-04-22 15:55:09 --> Total execution time: 0.0691
ERROR - 2023-04-22 16:19:09 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-22 16:19:09 --> Config Class Initialized
INFO - 2023-04-22 16:19:09 --> Hooks Class Initialized
DEBUG - 2023-04-22 16:19:09 --> UTF-8 Support Enabled
INFO - 2023-04-22 16:19:09 --> Utf8 Class Initialized
INFO - 2023-04-22 16:19:09 --> URI Class Initialized
DEBUG - 2023-04-22 16:19:09 --> No URI present. Default controller set.
INFO - 2023-04-22 16:19:09 --> Router Class Initialized
INFO - 2023-04-22 16:19:09 --> Output Class Initialized
INFO - 2023-04-22 16:19:09 --> Security Class Initialized
DEBUG - 2023-04-22 16:19:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-22 16:19:09 --> Input Class Initialized
INFO - 2023-04-22 16:19:09 --> Language Class Initialized
INFO - 2023-04-22 16:19:09 --> Loader Class Initialized
INFO - 2023-04-22 16:19:09 --> Helper loaded: url_helper
INFO - 2023-04-22 16:19:09 --> Helper loaded: file_helper
INFO - 2023-04-22 16:19:09 --> Helper loaded: html_helper
INFO - 2023-04-22 16:19:09 --> Helper loaded: text_helper
INFO - 2023-04-22 16:19:09 --> Helper loaded: form_helper
INFO - 2023-04-22 16:19:09 --> Helper loaded: lang_helper
INFO - 2023-04-22 16:19:09 --> Helper loaded: security_helper
INFO - 2023-04-22 16:19:09 --> Helper loaded: cookie_helper
INFO - 2023-04-22 16:19:09 --> Database Driver Class Initialized
INFO - 2023-04-22 16:19:09 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-22 16:19:09 --> Parser Class Initialized
INFO - 2023-04-22 16:19:09 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-22 16:19:09 --> Pagination Class Initialized
INFO - 2023-04-22 16:19:09 --> Form Validation Class Initialized
INFO - 2023-04-22 16:19:09 --> Controller Class Initialized
INFO - 2023-04-22 16:19:09 --> Model Class Initialized
DEBUG - 2023-04-22 16:19:09 --> Session class already loaded. Second attempt ignored.
ERROR - 2023-04-22 16:19:10 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-22 16:19:10 --> Config Class Initialized
INFO - 2023-04-22 16:19:10 --> Hooks Class Initialized
DEBUG - 2023-04-22 16:19:10 --> UTF-8 Support Enabled
INFO - 2023-04-22 16:19:10 --> Utf8 Class Initialized
INFO - 2023-04-22 16:19:10 --> URI Class Initialized
INFO - 2023-04-22 16:19:10 --> Router Class Initialized
INFO - 2023-04-22 16:19:10 --> Output Class Initialized
INFO - 2023-04-22 16:19:10 --> Security Class Initialized
DEBUG - 2023-04-22 16:19:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-22 16:19:10 --> Input Class Initialized
INFO - 2023-04-22 16:19:10 --> Language Class Initialized
INFO - 2023-04-22 16:19:10 --> Loader Class Initialized
INFO - 2023-04-22 16:19:10 --> Helper loaded: url_helper
INFO - 2023-04-22 16:19:10 --> Helper loaded: file_helper
INFO - 2023-04-22 16:19:10 --> Helper loaded: html_helper
INFO - 2023-04-22 16:19:10 --> Helper loaded: text_helper
INFO - 2023-04-22 16:19:10 --> Helper loaded: form_helper
INFO - 2023-04-22 16:19:10 --> Helper loaded: lang_helper
INFO - 2023-04-22 16:19:10 --> Helper loaded: security_helper
INFO - 2023-04-22 16:19:10 --> Helper loaded: cookie_helper
INFO - 2023-04-22 16:19:10 --> Database Driver Class Initialized
INFO - 2023-04-22 16:19:10 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-22 16:19:10 --> Parser Class Initialized
INFO - 2023-04-22 16:19:10 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-22 16:19:10 --> Pagination Class Initialized
INFO - 2023-04-22 16:19:10 --> Form Validation Class Initialized
INFO - 2023-04-22 16:19:10 --> Controller Class Initialized
INFO - 2023-04-22 16:19:10 --> Model Class Initialized
DEBUG - 2023-04-22 16:19:10 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-22 16:19:10 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2023-04-22 16:19:10 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-04-22 16:19:10 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-04-22 16:19:10 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-04-22 16:19:10 --> Model Class Initialized
INFO - 2023-04-22 16:19:10 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-04-22 16:19:10 --> Final output sent to browser
DEBUG - 2023-04-22 16:19:10 --> Total execution time: 0.0343
ERROR - 2023-04-22 16:19:51 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-22 16:19:51 --> Config Class Initialized
INFO - 2023-04-22 16:19:51 --> Hooks Class Initialized
DEBUG - 2023-04-22 16:19:51 --> UTF-8 Support Enabled
INFO - 2023-04-22 16:19:51 --> Utf8 Class Initialized
INFO - 2023-04-22 16:19:51 --> URI Class Initialized
INFO - 2023-04-22 16:19:51 --> Router Class Initialized
INFO - 2023-04-22 16:19:51 --> Output Class Initialized
INFO - 2023-04-22 16:19:51 --> Security Class Initialized
DEBUG - 2023-04-22 16:19:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-22 16:19:51 --> Input Class Initialized
INFO - 2023-04-22 16:19:51 --> Language Class Initialized
INFO - 2023-04-22 16:19:51 --> Loader Class Initialized
INFO - 2023-04-22 16:19:51 --> Helper loaded: url_helper
INFO - 2023-04-22 16:19:51 --> Helper loaded: file_helper
INFO - 2023-04-22 16:19:51 --> Helper loaded: html_helper
INFO - 2023-04-22 16:19:51 --> Helper loaded: text_helper
INFO - 2023-04-22 16:19:51 --> Helper loaded: form_helper
INFO - 2023-04-22 16:19:51 --> Helper loaded: lang_helper
INFO - 2023-04-22 16:19:51 --> Helper loaded: security_helper
INFO - 2023-04-22 16:19:51 --> Helper loaded: cookie_helper
INFO - 2023-04-22 16:19:51 --> Database Driver Class Initialized
INFO - 2023-04-22 16:19:51 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-22 16:19:51 --> Parser Class Initialized
INFO - 2023-04-22 16:19:51 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-22 16:19:51 --> Pagination Class Initialized
INFO - 2023-04-22 16:19:51 --> Form Validation Class Initialized
INFO - 2023-04-22 16:19:51 --> Controller Class Initialized
INFO - 2023-04-22 16:19:51 --> Model Class Initialized
DEBUG - 2023-04-22 16:19:51 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-22 16:19:51 --> Model Class Initialized
INFO - 2023-04-22 16:19:51 --> Final output sent to browser
DEBUG - 2023-04-22 16:19:51 --> Total execution time: 0.0229
ERROR - 2023-04-22 16:19:52 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-22 16:19:52 --> Config Class Initialized
INFO - 2023-04-22 16:19:52 --> Hooks Class Initialized
DEBUG - 2023-04-22 16:19:52 --> UTF-8 Support Enabled
INFO - 2023-04-22 16:19:52 --> Utf8 Class Initialized
INFO - 2023-04-22 16:19:52 --> URI Class Initialized
DEBUG - 2023-04-22 16:19:52 --> No URI present. Default controller set.
INFO - 2023-04-22 16:19:52 --> Router Class Initialized
INFO - 2023-04-22 16:19:52 --> Output Class Initialized
INFO - 2023-04-22 16:19:52 --> Security Class Initialized
DEBUG - 2023-04-22 16:19:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-22 16:19:52 --> Input Class Initialized
INFO - 2023-04-22 16:19:52 --> Language Class Initialized
INFO - 2023-04-22 16:19:52 --> Loader Class Initialized
INFO - 2023-04-22 16:19:52 --> Helper loaded: url_helper
INFO - 2023-04-22 16:19:52 --> Helper loaded: file_helper
INFO - 2023-04-22 16:19:52 --> Helper loaded: html_helper
INFO - 2023-04-22 16:19:52 --> Helper loaded: text_helper
INFO - 2023-04-22 16:19:52 --> Helper loaded: form_helper
INFO - 2023-04-22 16:19:52 --> Helper loaded: lang_helper
INFO - 2023-04-22 16:19:52 --> Helper loaded: security_helper
INFO - 2023-04-22 16:19:52 --> Helper loaded: cookie_helper
INFO - 2023-04-22 16:19:52 --> Database Driver Class Initialized
INFO - 2023-04-22 16:19:52 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-22 16:19:52 --> Parser Class Initialized
INFO - 2023-04-22 16:19:52 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-22 16:19:52 --> Pagination Class Initialized
INFO - 2023-04-22 16:19:52 --> Form Validation Class Initialized
INFO - 2023-04-22 16:19:52 --> Controller Class Initialized
INFO - 2023-04-22 16:19:52 --> Model Class Initialized
DEBUG - 2023-04-22 16:19:52 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-22 16:19:52 --> Model Class Initialized
DEBUG - 2023-04-22 16:19:52 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-22 16:19:52 --> Model Class Initialized
INFO - 2023-04-22 16:19:52 --> Model Class Initialized
INFO - 2023-04-22 16:19:52 --> Model Class Initialized
INFO - 2023-04-22 16:19:52 --> Model Class Initialized
DEBUG - 2023-04-22 16:19:52 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-04-22 16:19:52 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-22 16:19:52 --> Model Class Initialized
INFO - 2023-04-22 16:19:52 --> Model Class Initialized
INFO - 2023-04-22 16:19:52 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-04-22 16:19:52 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-04-22 16:19:52 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-04-22 16:19:52 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-04-22 16:19:52 --> Model Class Initialized
INFO - 2023-04-22 16:19:52 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-04-22 16:19:52 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-04-22 16:19:52 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-04-22 16:19:52 --> Final output sent to browser
DEBUG - 2023-04-22 16:19:52 --> Total execution time: 0.0832
ERROR - 2023-04-22 16:20:07 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-22 16:20:07 --> Config Class Initialized
INFO - 2023-04-22 16:20:07 --> Hooks Class Initialized
DEBUG - 2023-04-22 16:20:07 --> UTF-8 Support Enabled
INFO - 2023-04-22 16:20:07 --> Utf8 Class Initialized
INFO - 2023-04-22 16:20:07 --> URI Class Initialized
INFO - 2023-04-22 16:20:07 --> Router Class Initialized
INFO - 2023-04-22 16:20:07 --> Output Class Initialized
INFO - 2023-04-22 16:20:07 --> Security Class Initialized
DEBUG - 2023-04-22 16:20:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-22 16:20:07 --> Input Class Initialized
INFO - 2023-04-22 16:20:07 --> Language Class Initialized
INFO - 2023-04-22 16:20:07 --> Loader Class Initialized
INFO - 2023-04-22 16:20:07 --> Helper loaded: url_helper
INFO - 2023-04-22 16:20:07 --> Helper loaded: file_helper
INFO - 2023-04-22 16:20:07 --> Helper loaded: html_helper
INFO - 2023-04-22 16:20:07 --> Helper loaded: text_helper
INFO - 2023-04-22 16:20:07 --> Helper loaded: form_helper
INFO - 2023-04-22 16:20:07 --> Helper loaded: lang_helper
INFO - 2023-04-22 16:20:07 --> Helper loaded: security_helper
INFO - 2023-04-22 16:20:07 --> Helper loaded: cookie_helper
INFO - 2023-04-22 16:20:07 --> Database Driver Class Initialized
INFO - 2023-04-22 16:20:07 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-22 16:20:07 --> Parser Class Initialized
INFO - 2023-04-22 16:20:07 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-22 16:20:07 --> Pagination Class Initialized
INFO - 2023-04-22 16:20:07 --> Form Validation Class Initialized
INFO - 2023-04-22 16:20:07 --> Controller Class Initialized
INFO - 2023-04-22 16:20:07 --> Model Class Initialized
INFO - 2023-04-22 16:20:07 --> Model Class Initialized
INFO - 2023-04-22 16:20:07 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/report/out_of_date.php
DEBUG - 2023-04-22 16:20:07 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-04-22 16:20:07 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-04-22 16:20:07 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-04-22 16:20:07 --> Model Class Initialized
INFO - 2023-04-22 16:20:07 --> Model Class Initialized
INFO - 2023-04-22 16:20:07 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-04-22 16:20:07 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-04-22 16:20:07 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-04-22 16:20:07 --> Final output sent to browser
DEBUG - 2023-04-22 16:20:07 --> Total execution time: 0.0642
ERROR - 2023-04-22 16:20:07 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-22 16:20:07 --> Config Class Initialized
INFO - 2023-04-22 16:20:07 --> Hooks Class Initialized
DEBUG - 2023-04-22 16:20:07 --> UTF-8 Support Enabled
INFO - 2023-04-22 16:20:07 --> Utf8 Class Initialized
INFO - 2023-04-22 16:20:07 --> URI Class Initialized
INFO - 2023-04-22 16:20:07 --> Router Class Initialized
INFO - 2023-04-22 16:20:07 --> Output Class Initialized
INFO - 2023-04-22 16:20:07 --> Security Class Initialized
DEBUG - 2023-04-22 16:20:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-22 16:20:07 --> Input Class Initialized
INFO - 2023-04-22 16:20:07 --> Language Class Initialized
INFO - 2023-04-22 16:20:07 --> Loader Class Initialized
INFO - 2023-04-22 16:20:07 --> Helper loaded: url_helper
INFO - 2023-04-22 16:20:07 --> Helper loaded: file_helper
INFO - 2023-04-22 16:20:07 --> Helper loaded: html_helper
INFO - 2023-04-22 16:20:08 --> Helper loaded: text_helper
INFO - 2023-04-22 16:20:08 --> Helper loaded: form_helper
INFO - 2023-04-22 16:20:08 --> Helper loaded: lang_helper
INFO - 2023-04-22 16:20:08 --> Helper loaded: security_helper
INFO - 2023-04-22 16:20:08 --> Helper loaded: cookie_helper
INFO - 2023-04-22 16:20:08 --> Database Driver Class Initialized
INFO - 2023-04-22 16:20:08 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-22 16:20:08 --> Parser Class Initialized
INFO - 2023-04-22 16:20:08 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-22 16:20:08 --> Pagination Class Initialized
INFO - 2023-04-22 16:20:08 --> Form Validation Class Initialized
INFO - 2023-04-22 16:20:08 --> Controller Class Initialized
INFO - 2023-04-22 16:20:08 --> Model Class Initialized
INFO - 2023-04-22 16:20:08 --> Model Class Initialized
INFO - 2023-04-22 16:20:08 --> Final output sent to browser
DEBUG - 2023-04-22 16:20:08 --> Total execution time: 0.0163
ERROR - 2023-04-22 16:20:17 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-22 16:20:17 --> Config Class Initialized
INFO - 2023-04-22 16:20:17 --> Hooks Class Initialized
DEBUG - 2023-04-22 16:20:17 --> UTF-8 Support Enabled
INFO - 2023-04-22 16:20:17 --> Utf8 Class Initialized
INFO - 2023-04-22 16:20:17 --> URI Class Initialized
INFO - 2023-04-22 16:20:17 --> Router Class Initialized
INFO - 2023-04-22 16:20:17 --> Output Class Initialized
INFO - 2023-04-22 16:20:17 --> Security Class Initialized
DEBUG - 2023-04-22 16:20:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-22 16:20:17 --> Input Class Initialized
INFO - 2023-04-22 16:20:17 --> Language Class Initialized
INFO - 2023-04-22 16:20:17 --> Loader Class Initialized
INFO - 2023-04-22 16:20:17 --> Helper loaded: url_helper
INFO - 2023-04-22 16:20:17 --> Helper loaded: file_helper
INFO - 2023-04-22 16:20:17 --> Helper loaded: html_helper
INFO - 2023-04-22 16:20:17 --> Helper loaded: text_helper
INFO - 2023-04-22 16:20:17 --> Helper loaded: form_helper
INFO - 2023-04-22 16:20:17 --> Helper loaded: lang_helper
INFO - 2023-04-22 16:20:17 --> Helper loaded: security_helper
INFO - 2023-04-22 16:20:17 --> Helper loaded: cookie_helper
INFO - 2023-04-22 16:20:17 --> Database Driver Class Initialized
INFO - 2023-04-22 16:20:17 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-22 16:20:17 --> Parser Class Initialized
INFO - 2023-04-22 16:20:17 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-22 16:20:17 --> Pagination Class Initialized
INFO - 2023-04-22 16:20:17 --> Form Validation Class Initialized
INFO - 2023-04-22 16:20:17 --> Controller Class Initialized
INFO - 2023-04-22 16:20:17 --> Model Class Initialized
INFO - 2023-04-22 16:20:17 --> Model Class Initialized
INFO - 2023-04-22 16:20:17 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/report/out_of_stock.php
DEBUG - 2023-04-22 16:20:17 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-04-22 16:20:17 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-04-22 16:20:17 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-04-22 16:20:17 --> Model Class Initialized
INFO - 2023-04-22 16:20:17 --> Model Class Initialized
INFO - 2023-04-22 16:20:17 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-04-22 16:20:17 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-04-22 16:20:17 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-04-22 16:20:17 --> Final output sent to browser
DEBUG - 2023-04-22 16:20:17 --> Total execution time: 0.0578
ERROR - 2023-04-22 16:20:18 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-22 16:20:18 --> Config Class Initialized
INFO - 2023-04-22 16:20:18 --> Hooks Class Initialized
DEBUG - 2023-04-22 16:20:18 --> UTF-8 Support Enabled
INFO - 2023-04-22 16:20:18 --> Utf8 Class Initialized
INFO - 2023-04-22 16:20:18 --> URI Class Initialized
INFO - 2023-04-22 16:20:18 --> Router Class Initialized
INFO - 2023-04-22 16:20:18 --> Output Class Initialized
INFO - 2023-04-22 16:20:18 --> Security Class Initialized
DEBUG - 2023-04-22 16:20:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-22 16:20:18 --> Input Class Initialized
INFO - 2023-04-22 16:20:18 --> Language Class Initialized
INFO - 2023-04-22 16:20:18 --> Loader Class Initialized
INFO - 2023-04-22 16:20:18 --> Helper loaded: url_helper
INFO - 2023-04-22 16:20:18 --> Helper loaded: file_helper
INFO - 2023-04-22 16:20:18 --> Helper loaded: html_helper
INFO - 2023-04-22 16:20:18 --> Helper loaded: text_helper
INFO - 2023-04-22 16:20:18 --> Helper loaded: form_helper
INFO - 2023-04-22 16:20:18 --> Helper loaded: lang_helper
INFO - 2023-04-22 16:20:18 --> Helper loaded: security_helper
INFO - 2023-04-22 16:20:18 --> Helper loaded: cookie_helper
INFO - 2023-04-22 16:20:18 --> Database Driver Class Initialized
INFO - 2023-04-22 16:20:18 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-22 16:20:18 --> Parser Class Initialized
INFO - 2023-04-22 16:20:18 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-22 16:20:18 --> Pagination Class Initialized
INFO - 2023-04-22 16:20:18 --> Form Validation Class Initialized
INFO - 2023-04-22 16:20:18 --> Controller Class Initialized
INFO - 2023-04-22 16:20:18 --> Model Class Initialized
INFO - 2023-04-22 16:20:18 --> Model Class Initialized
INFO - 2023-04-22 16:20:18 --> Final output sent to browser
DEBUG - 2023-04-22 16:20:18 --> Total execution time: 0.0185
ERROR - 2023-04-22 16:20:56 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-22 16:20:56 --> Config Class Initialized
INFO - 2023-04-22 16:20:56 --> Hooks Class Initialized
DEBUG - 2023-04-22 16:20:56 --> UTF-8 Support Enabled
INFO - 2023-04-22 16:20:56 --> Utf8 Class Initialized
INFO - 2023-04-22 16:20:56 --> URI Class Initialized
INFO - 2023-04-22 16:20:56 --> Router Class Initialized
INFO - 2023-04-22 16:20:56 --> Output Class Initialized
INFO - 2023-04-22 16:20:56 --> Security Class Initialized
DEBUG - 2023-04-22 16:20:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-22 16:20:56 --> Input Class Initialized
INFO - 2023-04-22 16:20:56 --> Language Class Initialized
INFO - 2023-04-22 16:20:56 --> Loader Class Initialized
INFO - 2023-04-22 16:20:56 --> Helper loaded: url_helper
INFO - 2023-04-22 16:20:56 --> Helper loaded: file_helper
INFO - 2023-04-22 16:20:56 --> Helper loaded: html_helper
INFO - 2023-04-22 16:20:56 --> Helper loaded: text_helper
INFO - 2023-04-22 16:20:56 --> Helper loaded: form_helper
INFO - 2023-04-22 16:20:56 --> Helper loaded: lang_helper
INFO - 2023-04-22 16:20:56 --> Helper loaded: security_helper
INFO - 2023-04-22 16:20:56 --> Helper loaded: cookie_helper
INFO - 2023-04-22 16:20:56 --> Database Driver Class Initialized
INFO - 2023-04-22 16:20:56 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-22 16:20:56 --> Parser Class Initialized
INFO - 2023-04-22 16:20:56 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-22 16:20:56 --> Pagination Class Initialized
INFO - 2023-04-22 16:20:56 --> Form Validation Class Initialized
INFO - 2023-04-22 16:20:56 --> Controller Class Initialized
INFO - 2023-04-22 16:20:56 --> Model Class Initialized
DEBUG - 2023-04-22 16:20:56 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-04-22 16:20:56 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-22 16:20:56 --> Model Class Initialized
DEBUG - 2023-04-22 16:20:56 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-22 16:20:56 --> Model Class Initialized
INFO - 2023-04-22 16:20:56 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice.php
DEBUG - 2023-04-22 16:20:56 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-04-22 16:20:56 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-04-22 16:20:56 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-04-22 16:20:56 --> Model Class Initialized
INFO - 2023-04-22 16:20:56 --> Model Class Initialized
INFO - 2023-04-22 16:20:56 --> Model Class Initialized
INFO - 2023-04-22 16:20:56 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-04-22 16:20:56 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-04-22 16:20:56 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-04-22 16:20:56 --> Final output sent to browser
DEBUG - 2023-04-22 16:20:56 --> Total execution time: 0.0750
ERROR - 2023-04-22 16:20:57 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-22 16:20:57 --> Config Class Initialized
INFO - 2023-04-22 16:20:57 --> Hooks Class Initialized
DEBUG - 2023-04-22 16:20:57 --> UTF-8 Support Enabled
INFO - 2023-04-22 16:20:57 --> Utf8 Class Initialized
INFO - 2023-04-22 16:20:57 --> URI Class Initialized
INFO - 2023-04-22 16:20:57 --> Router Class Initialized
INFO - 2023-04-22 16:20:57 --> Output Class Initialized
INFO - 2023-04-22 16:20:57 --> Security Class Initialized
DEBUG - 2023-04-22 16:20:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-22 16:20:57 --> Input Class Initialized
INFO - 2023-04-22 16:20:57 --> Language Class Initialized
INFO - 2023-04-22 16:20:57 --> Loader Class Initialized
INFO - 2023-04-22 16:20:57 --> Helper loaded: url_helper
INFO - 2023-04-22 16:20:57 --> Helper loaded: file_helper
INFO - 2023-04-22 16:20:57 --> Helper loaded: html_helper
INFO - 2023-04-22 16:20:57 --> Helper loaded: text_helper
INFO - 2023-04-22 16:20:57 --> Helper loaded: form_helper
INFO - 2023-04-22 16:20:57 --> Helper loaded: lang_helper
INFO - 2023-04-22 16:20:57 --> Helper loaded: security_helper
INFO - 2023-04-22 16:20:57 --> Helper loaded: cookie_helper
INFO - 2023-04-22 16:20:57 --> Database Driver Class Initialized
INFO - 2023-04-22 16:20:57 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-22 16:20:57 --> Parser Class Initialized
INFO - 2023-04-22 16:20:57 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-22 16:20:57 --> Pagination Class Initialized
INFO - 2023-04-22 16:20:57 --> Form Validation Class Initialized
INFO - 2023-04-22 16:20:57 --> Controller Class Initialized
INFO - 2023-04-22 16:20:57 --> Model Class Initialized
DEBUG - 2023-04-22 16:20:57 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-04-22 16:20:57 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-22 16:20:57 --> Model Class Initialized
DEBUG - 2023-04-22 16:20:57 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-22 16:20:57 --> Model Class Initialized
INFO - 2023-04-22 16:20:57 --> Final output sent to browser
DEBUG - 2023-04-22 16:20:57 --> Total execution time: 0.0409
ERROR - 2023-04-22 16:21:20 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-22 16:21:20 --> Config Class Initialized
INFO - 2023-04-22 16:21:20 --> Hooks Class Initialized
DEBUG - 2023-04-22 16:21:20 --> UTF-8 Support Enabled
INFO - 2023-04-22 16:21:20 --> Utf8 Class Initialized
INFO - 2023-04-22 16:21:20 --> URI Class Initialized
INFO - 2023-04-22 16:21:20 --> Router Class Initialized
INFO - 2023-04-22 16:21:20 --> Output Class Initialized
INFO - 2023-04-22 16:21:20 --> Security Class Initialized
DEBUG - 2023-04-22 16:21:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-22 16:21:20 --> Input Class Initialized
INFO - 2023-04-22 16:21:20 --> Language Class Initialized
INFO - 2023-04-22 16:21:20 --> Loader Class Initialized
INFO - 2023-04-22 16:21:20 --> Helper loaded: url_helper
INFO - 2023-04-22 16:21:20 --> Helper loaded: file_helper
INFO - 2023-04-22 16:21:20 --> Helper loaded: html_helper
INFO - 2023-04-22 16:21:20 --> Helper loaded: text_helper
INFO - 2023-04-22 16:21:20 --> Helper loaded: form_helper
INFO - 2023-04-22 16:21:20 --> Helper loaded: lang_helper
INFO - 2023-04-22 16:21:20 --> Helper loaded: security_helper
INFO - 2023-04-22 16:21:20 --> Helper loaded: cookie_helper
INFO - 2023-04-22 16:21:20 --> Database Driver Class Initialized
INFO - 2023-04-22 16:21:20 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-22 16:21:20 --> Parser Class Initialized
INFO - 2023-04-22 16:21:20 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-22 16:21:20 --> Pagination Class Initialized
INFO - 2023-04-22 16:21:20 --> Form Validation Class Initialized
INFO - 2023-04-22 16:21:20 --> Controller Class Initialized
INFO - 2023-04-22 16:21:20 --> Model Class Initialized
DEBUG - 2023-04-22 16:21:20 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-04-22 16:21:20 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-22 16:21:20 --> Model Class Initialized
DEBUG - 2023-04-22 16:21:20 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-22 16:21:20 --> Model Class Initialized
INFO - 2023-04-22 16:21:20 --> Final output sent to browser
DEBUG - 2023-04-22 16:21:20 --> Total execution time: 0.0291
ERROR - 2023-04-22 16:21:29 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-22 16:21:29 --> Config Class Initialized
INFO - 2023-04-22 16:21:29 --> Hooks Class Initialized
DEBUG - 2023-04-22 16:21:29 --> UTF-8 Support Enabled
INFO - 2023-04-22 16:21:29 --> Utf8 Class Initialized
INFO - 2023-04-22 16:21:29 --> URI Class Initialized
INFO - 2023-04-22 16:21:29 --> Router Class Initialized
INFO - 2023-04-22 16:21:29 --> Output Class Initialized
INFO - 2023-04-22 16:21:29 --> Security Class Initialized
DEBUG - 2023-04-22 16:21:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-22 16:21:29 --> Input Class Initialized
INFO - 2023-04-22 16:21:29 --> Language Class Initialized
INFO - 2023-04-22 16:21:29 --> Loader Class Initialized
INFO - 2023-04-22 16:21:29 --> Helper loaded: url_helper
INFO - 2023-04-22 16:21:29 --> Helper loaded: file_helper
INFO - 2023-04-22 16:21:29 --> Helper loaded: html_helper
INFO - 2023-04-22 16:21:29 --> Helper loaded: text_helper
INFO - 2023-04-22 16:21:29 --> Helper loaded: form_helper
INFO - 2023-04-22 16:21:29 --> Helper loaded: lang_helper
INFO - 2023-04-22 16:21:29 --> Helper loaded: security_helper
INFO - 2023-04-22 16:21:29 --> Helper loaded: cookie_helper
INFO - 2023-04-22 16:21:29 --> Database Driver Class Initialized
INFO - 2023-04-22 16:21:29 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-22 16:21:29 --> Parser Class Initialized
INFO - 2023-04-22 16:21:29 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-22 16:21:29 --> Pagination Class Initialized
INFO - 2023-04-22 16:21:29 --> Form Validation Class Initialized
INFO - 2023-04-22 16:21:29 --> Controller Class Initialized
INFO - 2023-04-22 16:21:29 --> Model Class Initialized
INFO - 2023-04-22 16:21:29 --> Model Class Initialized
INFO - 2023-04-22 16:21:29 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/report/out_of_stock.php
DEBUG - 2023-04-22 16:21:29 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-04-22 16:21:29 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-04-22 16:21:29 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-04-22 16:21:29 --> Model Class Initialized
INFO - 2023-04-22 16:21:29 --> Model Class Initialized
INFO - 2023-04-22 16:21:29 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-04-22 16:21:29 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-04-22 16:21:29 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-04-22 16:21:29 --> Final output sent to browser
DEBUG - 2023-04-22 16:21:29 --> Total execution time: 0.0612
ERROR - 2023-04-22 16:21:30 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-22 16:21:30 --> Config Class Initialized
INFO - 2023-04-22 16:21:30 --> Hooks Class Initialized
DEBUG - 2023-04-22 16:21:30 --> UTF-8 Support Enabled
INFO - 2023-04-22 16:21:30 --> Utf8 Class Initialized
INFO - 2023-04-22 16:21:30 --> URI Class Initialized
INFO - 2023-04-22 16:21:30 --> Router Class Initialized
INFO - 2023-04-22 16:21:30 --> Output Class Initialized
INFO - 2023-04-22 16:21:30 --> Security Class Initialized
DEBUG - 2023-04-22 16:21:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-22 16:21:30 --> Input Class Initialized
INFO - 2023-04-22 16:21:30 --> Language Class Initialized
INFO - 2023-04-22 16:21:30 --> Loader Class Initialized
INFO - 2023-04-22 16:21:30 --> Helper loaded: url_helper
INFO - 2023-04-22 16:21:30 --> Helper loaded: file_helper
INFO - 2023-04-22 16:21:30 --> Helper loaded: html_helper
INFO - 2023-04-22 16:21:30 --> Helper loaded: text_helper
INFO - 2023-04-22 16:21:30 --> Helper loaded: form_helper
INFO - 2023-04-22 16:21:30 --> Helper loaded: lang_helper
INFO - 2023-04-22 16:21:30 --> Helper loaded: security_helper
INFO - 2023-04-22 16:21:30 --> Helper loaded: cookie_helper
INFO - 2023-04-22 16:21:30 --> Database Driver Class Initialized
INFO - 2023-04-22 16:21:30 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-22 16:21:30 --> Parser Class Initialized
INFO - 2023-04-22 16:21:30 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-22 16:21:30 --> Pagination Class Initialized
INFO - 2023-04-22 16:21:30 --> Form Validation Class Initialized
INFO - 2023-04-22 16:21:30 --> Controller Class Initialized
INFO - 2023-04-22 16:21:30 --> Model Class Initialized
INFO - 2023-04-22 16:21:30 --> Model Class Initialized
INFO - 2023-04-22 16:21:30 --> Final output sent to browser
DEBUG - 2023-04-22 16:21:30 --> Total execution time: 0.0188
ERROR - 2023-04-22 16:21:44 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-22 16:21:44 --> Config Class Initialized
INFO - 2023-04-22 16:21:44 --> Hooks Class Initialized
DEBUG - 2023-04-22 16:21:44 --> UTF-8 Support Enabled
INFO - 2023-04-22 16:21:44 --> Utf8 Class Initialized
INFO - 2023-04-22 16:21:44 --> URI Class Initialized
INFO - 2023-04-22 16:21:44 --> Router Class Initialized
INFO - 2023-04-22 16:21:44 --> Output Class Initialized
INFO - 2023-04-22 16:21:44 --> Security Class Initialized
DEBUG - 2023-04-22 16:21:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-22 16:21:44 --> Input Class Initialized
INFO - 2023-04-22 16:21:44 --> Language Class Initialized
INFO - 2023-04-22 16:21:44 --> Loader Class Initialized
INFO - 2023-04-22 16:21:44 --> Helper loaded: url_helper
INFO - 2023-04-22 16:21:44 --> Helper loaded: file_helper
INFO - 2023-04-22 16:21:44 --> Helper loaded: html_helper
INFO - 2023-04-22 16:21:44 --> Helper loaded: text_helper
INFO - 2023-04-22 16:21:44 --> Helper loaded: form_helper
INFO - 2023-04-22 16:21:44 --> Helper loaded: lang_helper
INFO - 2023-04-22 16:21:44 --> Helper loaded: security_helper
INFO - 2023-04-22 16:21:44 --> Helper loaded: cookie_helper
INFO - 2023-04-22 16:21:44 --> Database Driver Class Initialized
INFO - 2023-04-22 16:21:44 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-22 16:21:44 --> Parser Class Initialized
INFO - 2023-04-22 16:21:44 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-22 16:21:44 --> Pagination Class Initialized
INFO - 2023-04-22 16:21:44 --> Form Validation Class Initialized
INFO - 2023-04-22 16:21:44 --> Controller Class Initialized
DEBUG - 2023-04-22 16:21:44 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-04-22 16:21:44 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-22 16:21:44 --> Model Class Initialized
DEBUG - 2023-04-22 16:21:44 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-04-22 16:21:44 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-04-22 16:21:44 --> Ltarget class already loaded. Second attempt ignored.
INFO - 2023-04-22 16:21:44 --> Model Class Initialized
DEBUG - 2023-04-22 16:21:44 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-04-22 16:21:44 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-22 16:21:44 --> Model Class Initialized
DEBUG - 2023-04-22 16:21:44 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-22 16:21:44 --> Model Class Initialized
INFO - 2023-04-22 16:21:44 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/target/target.php
DEBUG - 2023-04-22 16:21:44 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-04-22 16:21:44 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-04-22 16:21:44 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-04-22 16:21:44 --> Model Class Initialized
INFO - 2023-04-22 16:21:44 --> Model Class Initialized
INFO - 2023-04-22 16:21:44 --> Model Class Initialized
INFO - 2023-04-22 16:21:44 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-04-22 16:21:44 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-04-22 16:21:44 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-04-22 16:21:44 --> Final output sent to browser
DEBUG - 2023-04-22 16:21:44 --> Total execution time: 0.0775
ERROR - 2023-04-22 16:21:44 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-22 16:21:44 --> Config Class Initialized
INFO - 2023-04-22 16:21:44 --> Hooks Class Initialized
DEBUG - 2023-04-22 16:21:44 --> UTF-8 Support Enabled
INFO - 2023-04-22 16:21:44 --> Utf8 Class Initialized
INFO - 2023-04-22 16:21:44 --> URI Class Initialized
INFO - 2023-04-22 16:21:44 --> Router Class Initialized
INFO - 2023-04-22 16:21:44 --> Output Class Initialized
INFO - 2023-04-22 16:21:44 --> Security Class Initialized
DEBUG - 2023-04-22 16:21:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-22 16:21:44 --> Input Class Initialized
INFO - 2023-04-22 16:21:44 --> Language Class Initialized
INFO - 2023-04-22 16:21:44 --> Loader Class Initialized
INFO - 2023-04-22 16:21:44 --> Helper loaded: url_helper
INFO - 2023-04-22 16:21:44 --> Helper loaded: file_helper
INFO - 2023-04-22 16:21:44 --> Helper loaded: html_helper
INFO - 2023-04-22 16:21:44 --> Helper loaded: text_helper
INFO - 2023-04-22 16:21:44 --> Helper loaded: form_helper
INFO - 2023-04-22 16:21:44 --> Helper loaded: lang_helper
INFO - 2023-04-22 16:21:44 --> Helper loaded: security_helper
INFO - 2023-04-22 16:21:44 --> Helper loaded: cookie_helper
INFO - 2023-04-22 16:21:44 --> Database Driver Class Initialized
INFO - 2023-04-22 16:21:44 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-22 16:21:44 --> Parser Class Initialized
INFO - 2023-04-22 16:21:44 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-22 16:21:44 --> Pagination Class Initialized
INFO - 2023-04-22 16:21:44 --> Form Validation Class Initialized
INFO - 2023-04-22 16:21:44 --> Controller Class Initialized
DEBUG - 2023-04-22 16:21:44 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-04-22 16:21:44 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-22 16:21:44 --> Model Class Initialized
DEBUG - 2023-04-22 16:21:44 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-04-22 16:21:44 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-22 16:21:44 --> Model Class Initialized
DEBUG - 2023-04-22 16:21:44 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-04-22 16:21:44 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-22 16:21:44 --> Model Class Initialized
DEBUG - 2023-04-22 16:21:44 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-22 16:21:44 --> Model Class Initialized
INFO - 2023-04-22 16:21:44 --> Final output sent to browser
DEBUG - 2023-04-22 16:21:44 --> Total execution time: 0.0231
ERROR - 2023-04-22 16:22:02 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-22 16:22:02 --> Config Class Initialized
INFO - 2023-04-22 16:22:02 --> Hooks Class Initialized
DEBUG - 2023-04-22 16:22:02 --> UTF-8 Support Enabled
INFO - 2023-04-22 16:22:02 --> Utf8 Class Initialized
INFO - 2023-04-22 16:22:02 --> URI Class Initialized
INFO - 2023-04-22 16:22:02 --> Router Class Initialized
INFO - 2023-04-22 16:22:02 --> Output Class Initialized
INFO - 2023-04-22 16:22:02 --> Security Class Initialized
DEBUG - 2023-04-22 16:22:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-22 16:22:02 --> Input Class Initialized
INFO - 2023-04-22 16:22:02 --> Language Class Initialized
INFO - 2023-04-22 16:22:02 --> Loader Class Initialized
INFO - 2023-04-22 16:22:02 --> Helper loaded: url_helper
INFO - 2023-04-22 16:22:02 --> Helper loaded: file_helper
INFO - 2023-04-22 16:22:02 --> Helper loaded: html_helper
INFO - 2023-04-22 16:22:02 --> Helper loaded: text_helper
INFO - 2023-04-22 16:22:02 --> Helper loaded: form_helper
INFO - 2023-04-22 16:22:02 --> Helper loaded: lang_helper
INFO - 2023-04-22 16:22:02 --> Helper loaded: security_helper
INFO - 2023-04-22 16:22:02 --> Helper loaded: cookie_helper
INFO - 2023-04-22 16:22:02 --> Database Driver Class Initialized
INFO - 2023-04-22 16:22:02 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-22 16:22:02 --> Parser Class Initialized
INFO - 2023-04-22 16:22:02 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-22 16:22:02 --> Pagination Class Initialized
INFO - 2023-04-22 16:22:02 --> Form Validation Class Initialized
INFO - 2023-04-22 16:22:02 --> Controller Class Initialized
INFO - 2023-04-22 16:22:02 --> Model Class Initialized
INFO - 2023-04-22 16:22:02 --> Model Class Initialized
INFO - 2023-04-22 16:22:02 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/report/out_of_stock.php
DEBUG - 2023-04-22 16:22:02 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-04-22 16:22:02 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-04-22 16:22:02 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-04-22 16:22:02 --> Model Class Initialized
INFO - 2023-04-22 16:22:02 --> Model Class Initialized
INFO - 2023-04-22 16:22:02 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-04-22 16:22:02 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-04-22 16:22:02 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-04-22 16:22:02 --> Final output sent to browser
DEBUG - 2023-04-22 16:22:02 --> Total execution time: 0.0697
ERROR - 2023-04-22 16:22:03 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-22 16:22:03 --> Config Class Initialized
INFO - 2023-04-22 16:22:03 --> Hooks Class Initialized
DEBUG - 2023-04-22 16:22:03 --> UTF-8 Support Enabled
INFO - 2023-04-22 16:22:03 --> Utf8 Class Initialized
INFO - 2023-04-22 16:22:03 --> URI Class Initialized
INFO - 2023-04-22 16:22:03 --> Router Class Initialized
INFO - 2023-04-22 16:22:03 --> Output Class Initialized
INFO - 2023-04-22 16:22:03 --> Security Class Initialized
DEBUG - 2023-04-22 16:22:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-22 16:22:03 --> Input Class Initialized
INFO - 2023-04-22 16:22:03 --> Language Class Initialized
INFO - 2023-04-22 16:22:03 --> Loader Class Initialized
INFO - 2023-04-22 16:22:03 --> Helper loaded: url_helper
INFO - 2023-04-22 16:22:03 --> Helper loaded: file_helper
INFO - 2023-04-22 16:22:03 --> Helper loaded: html_helper
INFO - 2023-04-22 16:22:03 --> Helper loaded: text_helper
INFO - 2023-04-22 16:22:03 --> Helper loaded: form_helper
INFO - 2023-04-22 16:22:03 --> Helper loaded: lang_helper
INFO - 2023-04-22 16:22:03 --> Helper loaded: security_helper
INFO - 2023-04-22 16:22:03 --> Helper loaded: cookie_helper
INFO - 2023-04-22 16:22:03 --> Database Driver Class Initialized
INFO - 2023-04-22 16:22:03 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-22 16:22:03 --> Parser Class Initialized
INFO - 2023-04-22 16:22:03 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-22 16:22:03 --> Pagination Class Initialized
INFO - 2023-04-22 16:22:03 --> Form Validation Class Initialized
INFO - 2023-04-22 16:22:03 --> Controller Class Initialized
INFO - 2023-04-22 16:22:03 --> Model Class Initialized
INFO - 2023-04-22 16:22:03 --> Model Class Initialized
INFO - 2023-04-22 16:22:03 --> Final output sent to browser
DEBUG - 2023-04-22 16:22:03 --> Total execution time: 0.0217
ERROR - 2023-04-22 16:22:03 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-22 16:22:03 --> Config Class Initialized
INFO - 2023-04-22 16:22:03 --> Hooks Class Initialized
DEBUG - 2023-04-22 16:22:03 --> UTF-8 Support Enabled
INFO - 2023-04-22 16:22:03 --> Utf8 Class Initialized
INFO - 2023-04-22 16:22:03 --> URI Class Initialized
INFO - 2023-04-22 16:22:03 --> Router Class Initialized
INFO - 2023-04-22 16:22:03 --> Output Class Initialized
INFO - 2023-04-22 16:22:03 --> Security Class Initialized
DEBUG - 2023-04-22 16:22:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-22 16:22:03 --> Input Class Initialized
INFO - 2023-04-22 16:22:03 --> Language Class Initialized
INFO - 2023-04-22 16:22:03 --> Loader Class Initialized
INFO - 2023-04-22 16:22:03 --> Helper loaded: url_helper
INFO - 2023-04-22 16:22:03 --> Helper loaded: file_helper
INFO - 2023-04-22 16:22:03 --> Helper loaded: html_helper
INFO - 2023-04-22 16:22:03 --> Helper loaded: text_helper
INFO - 2023-04-22 16:22:03 --> Helper loaded: form_helper
INFO - 2023-04-22 16:22:03 --> Helper loaded: lang_helper
INFO - 2023-04-22 16:22:03 --> Helper loaded: security_helper
INFO - 2023-04-22 16:22:03 --> Helper loaded: cookie_helper
INFO - 2023-04-22 16:22:03 --> Database Driver Class Initialized
INFO - 2023-04-22 16:22:03 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-22 16:22:03 --> Parser Class Initialized
INFO - 2023-04-22 16:22:03 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-22 16:22:03 --> Pagination Class Initialized
INFO - 2023-04-22 16:22:03 --> Form Validation Class Initialized
INFO - 2023-04-22 16:22:03 --> Controller Class Initialized
INFO - 2023-04-22 16:22:03 --> Model Class Initialized
INFO - 2023-04-22 16:22:03 --> Model Class Initialized
INFO - 2023-04-22 16:22:03 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/report/out_of_date.php
DEBUG - 2023-04-22 16:22:03 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-04-22 16:22:03 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-04-22 16:22:03 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-04-22 16:22:03 --> Model Class Initialized
INFO - 2023-04-22 16:22:03 --> Model Class Initialized
INFO - 2023-04-22 16:22:03 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-04-22 16:22:03 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-04-22 16:22:03 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-04-22 16:22:03 --> Final output sent to browser
DEBUG - 2023-04-22 16:22:03 --> Total execution time: 0.0647
ERROR - 2023-04-22 16:22:04 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-22 16:22:04 --> Config Class Initialized
INFO - 2023-04-22 16:22:04 --> Hooks Class Initialized
DEBUG - 2023-04-22 16:22:04 --> UTF-8 Support Enabled
INFO - 2023-04-22 16:22:04 --> Utf8 Class Initialized
INFO - 2023-04-22 16:22:04 --> URI Class Initialized
DEBUG - 2023-04-22 16:22:04 --> No URI present. Default controller set.
INFO - 2023-04-22 16:22:04 --> Router Class Initialized
INFO - 2023-04-22 16:22:04 --> Output Class Initialized
INFO - 2023-04-22 16:22:04 --> Security Class Initialized
DEBUG - 2023-04-22 16:22:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-22 16:22:04 --> Input Class Initialized
INFO - 2023-04-22 16:22:04 --> Language Class Initialized
INFO - 2023-04-22 16:22:04 --> Loader Class Initialized
INFO - 2023-04-22 16:22:04 --> Helper loaded: url_helper
INFO - 2023-04-22 16:22:04 --> Helper loaded: file_helper
INFO - 2023-04-22 16:22:04 --> Helper loaded: html_helper
INFO - 2023-04-22 16:22:04 --> Helper loaded: text_helper
INFO - 2023-04-22 16:22:04 --> Helper loaded: form_helper
INFO - 2023-04-22 16:22:04 --> Helper loaded: lang_helper
INFO - 2023-04-22 16:22:04 --> Helper loaded: security_helper
INFO - 2023-04-22 16:22:04 --> Helper loaded: cookie_helper
INFO - 2023-04-22 16:22:04 --> Database Driver Class Initialized
INFO - 2023-04-22 16:22:04 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-22 16:22:04 --> Parser Class Initialized
INFO - 2023-04-22 16:22:04 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-22 16:22:04 --> Pagination Class Initialized
INFO - 2023-04-22 16:22:04 --> Form Validation Class Initialized
INFO - 2023-04-22 16:22:04 --> Controller Class Initialized
INFO - 2023-04-22 16:22:04 --> Model Class Initialized
DEBUG - 2023-04-22 16:22:04 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-22 16:22:04 --> Model Class Initialized
DEBUG - 2023-04-22 16:22:04 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-22 16:22:04 --> Model Class Initialized
INFO - 2023-04-22 16:22:04 --> Model Class Initialized
INFO - 2023-04-22 16:22:04 --> Model Class Initialized
INFO - 2023-04-22 16:22:04 --> Model Class Initialized
DEBUG - 2023-04-22 16:22:04 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-04-22 16:22:04 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-22 16:22:04 --> Model Class Initialized
INFO - 2023-04-22 16:22:04 --> Model Class Initialized
ERROR - 2023-04-22 16:22:04 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-22 16:22:04 --> Config Class Initialized
INFO - 2023-04-22 16:22:04 --> Hooks Class Initialized
DEBUG - 2023-04-22 16:22:04 --> UTF-8 Support Enabled
INFO - 2023-04-22 16:22:04 --> Utf8 Class Initialized
INFO - 2023-04-22 16:22:04 --> URI Class Initialized
INFO - 2023-04-22 16:22:04 --> Router Class Initialized
INFO - 2023-04-22 16:22:04 --> Output Class Initialized
INFO - 2023-04-22 16:22:04 --> Security Class Initialized
DEBUG - 2023-04-22 16:22:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-22 16:22:04 --> Input Class Initialized
INFO - 2023-04-22 16:22:04 --> Language Class Initialized
INFO - 2023-04-22 16:22:04 --> Loader Class Initialized
INFO - 2023-04-22 16:22:04 --> Helper loaded: url_helper
INFO - 2023-04-22 16:22:04 --> Helper loaded: file_helper
INFO - 2023-04-22 16:22:04 --> Helper loaded: html_helper
INFO - 2023-04-22 16:22:04 --> Helper loaded: text_helper
INFO - 2023-04-22 16:22:04 --> Helper loaded: form_helper
INFO - 2023-04-22 16:22:04 --> Helper loaded: lang_helper
INFO - 2023-04-22 16:22:04 --> Helper loaded: security_helper
INFO - 2023-04-22 16:22:04 --> Helper loaded: cookie_helper
INFO - 2023-04-22 16:22:04 --> Database Driver Class Initialized
INFO - 2023-04-22 16:22:04 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-04-22 16:22:04 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-04-22 16:22:04 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-04-22 16:22:04 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-04-22 16:22:04 --> Model Class Initialized
INFO - 2023-04-22 16:22:04 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-04-22 16:22:04 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-04-22 16:22:04 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-04-22 16:22:04 --> Final output sent to browser
DEBUG - 2023-04-22 16:22:04 --> Total execution time: 0.0740
INFO - 2023-04-22 16:22:04 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-22 16:22:04 --> Parser Class Initialized
INFO - 2023-04-22 16:22:04 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-22 16:22:04 --> Pagination Class Initialized
INFO - 2023-04-22 16:22:04 --> Form Validation Class Initialized
INFO - 2023-04-22 16:22:04 --> Controller Class Initialized
INFO - 2023-04-22 16:22:04 --> Model Class Initialized
INFO - 2023-04-22 16:22:04 --> Model Class Initialized
INFO - 2023-04-22 16:22:04 --> Final output sent to browser
DEBUG - 2023-04-22 16:22:04 --> Total execution time: 0.0618
ERROR - 2023-04-22 16:22:04 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-22 16:22:04 --> Config Class Initialized
INFO - 2023-04-22 16:22:04 --> Hooks Class Initialized
DEBUG - 2023-04-22 16:22:04 --> UTF-8 Support Enabled
INFO - 2023-04-22 16:22:04 --> Utf8 Class Initialized
INFO - 2023-04-22 16:22:04 --> URI Class Initialized
INFO - 2023-04-22 16:22:04 --> Router Class Initialized
INFO - 2023-04-22 16:22:04 --> Output Class Initialized
INFO - 2023-04-22 16:22:04 --> Security Class Initialized
DEBUG - 2023-04-22 16:22:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-22 16:22:04 --> Input Class Initialized
INFO - 2023-04-22 16:22:04 --> Language Class Initialized
INFO - 2023-04-22 16:22:04 --> Loader Class Initialized
INFO - 2023-04-22 16:22:04 --> Helper loaded: url_helper
INFO - 2023-04-22 16:22:04 --> Helper loaded: file_helper
INFO - 2023-04-22 16:22:04 --> Helper loaded: html_helper
INFO - 2023-04-22 16:22:04 --> Helper loaded: text_helper
INFO - 2023-04-22 16:22:04 --> Helper loaded: form_helper
INFO - 2023-04-22 16:22:04 --> Helper loaded: lang_helper
INFO - 2023-04-22 16:22:04 --> Helper loaded: security_helper
INFO - 2023-04-22 16:22:04 --> Helper loaded: cookie_helper
INFO - 2023-04-22 16:22:04 --> Database Driver Class Initialized
INFO - 2023-04-22 16:22:04 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-22 16:22:04 --> Parser Class Initialized
INFO - 2023-04-22 16:22:04 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-22 16:22:04 --> Pagination Class Initialized
INFO - 2023-04-22 16:22:04 --> Form Validation Class Initialized
INFO - 2023-04-22 16:22:04 --> Controller Class Initialized
INFO - 2023-04-22 16:22:04 --> Model Class Initialized
DEBUG - 2023-04-22 16:22:04 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-22 16:22:04 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2023-04-22 16:22:04 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-04-22 16:22:04 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-04-22 16:22:04 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-04-22 16:22:04 --> Model Class Initialized
INFO - 2023-04-22 16:22:04 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-04-22 16:22:04 --> Final output sent to browser
DEBUG - 2023-04-22 16:22:04 --> Total execution time: 0.0312
ERROR - 2023-04-22 16:22:05 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-22 16:22:05 --> Config Class Initialized
INFO - 2023-04-22 16:22:05 --> Hooks Class Initialized
DEBUG - 2023-04-22 16:22:05 --> UTF-8 Support Enabled
INFO - 2023-04-22 16:22:05 --> Utf8 Class Initialized
INFO - 2023-04-22 16:22:05 --> URI Class Initialized
INFO - 2023-04-22 16:22:05 --> Router Class Initialized
INFO - 2023-04-22 16:22:05 --> Output Class Initialized
INFO - 2023-04-22 16:22:05 --> Security Class Initialized
DEBUG - 2023-04-22 16:22:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-22 16:22:05 --> Input Class Initialized
INFO - 2023-04-22 16:22:05 --> Language Class Initialized
INFO - 2023-04-22 16:22:05 --> Loader Class Initialized
INFO - 2023-04-22 16:22:05 --> Helper loaded: url_helper
INFO - 2023-04-22 16:22:05 --> Helper loaded: file_helper
INFO - 2023-04-22 16:22:05 --> Helper loaded: html_helper
INFO - 2023-04-22 16:22:05 --> Helper loaded: text_helper
INFO - 2023-04-22 16:22:05 --> Helper loaded: form_helper
INFO - 2023-04-22 16:22:05 --> Helper loaded: lang_helper
INFO - 2023-04-22 16:22:05 --> Helper loaded: security_helper
INFO - 2023-04-22 16:22:05 --> Helper loaded: cookie_helper
INFO - 2023-04-22 16:22:05 --> Database Driver Class Initialized
INFO - 2023-04-22 16:22:05 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-22 16:22:05 --> Parser Class Initialized
INFO - 2023-04-22 16:22:05 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-22 16:22:05 --> Pagination Class Initialized
INFO - 2023-04-22 16:22:05 --> Form Validation Class Initialized
INFO - 2023-04-22 16:22:05 --> Controller Class Initialized
INFO - 2023-04-22 16:22:05 --> Model Class Initialized
DEBUG - 2023-04-22 16:22:05 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-22 16:22:05 --> Model Class Initialized
DEBUG - 2023-04-22 16:22:05 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-22 16:22:05 --> Model Class Initialized
INFO - 2023-04-22 16:22:05 --> Model Class Initialized
INFO - 2023-04-22 16:22:05 --> Model Class Initialized
INFO - 2023-04-22 16:22:05 --> Model Class Initialized
DEBUG - 2023-04-22 16:22:05 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-04-22 16:22:05 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-22 16:22:05 --> Model Class Initialized
INFO - 2023-04-22 16:22:05 --> Model Class Initialized
INFO - 2023-04-22 16:22:05 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-04-22 16:22:05 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-04-22 16:22:05 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-04-22 16:22:05 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-04-22 16:22:05 --> Model Class Initialized
INFO - 2023-04-22 16:22:05 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-04-22 16:22:05 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-04-22 16:22:05 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-04-22 16:22:05 --> Final output sent to browser
DEBUG - 2023-04-22 16:22:05 --> Total execution time: 0.0763
ERROR - 2023-04-22 16:37:53 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-22 16:37:53 --> Config Class Initialized
INFO - 2023-04-22 16:37:53 --> Hooks Class Initialized
DEBUG - 2023-04-22 16:37:53 --> UTF-8 Support Enabled
INFO - 2023-04-22 16:37:53 --> Utf8 Class Initialized
INFO - 2023-04-22 16:37:53 --> URI Class Initialized
DEBUG - 2023-04-22 16:37:53 --> No URI present. Default controller set.
INFO - 2023-04-22 16:37:53 --> Router Class Initialized
INFO - 2023-04-22 16:37:53 --> Output Class Initialized
INFO - 2023-04-22 16:37:53 --> Security Class Initialized
DEBUG - 2023-04-22 16:37:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-22 16:37:53 --> Input Class Initialized
INFO - 2023-04-22 16:37:53 --> Language Class Initialized
INFO - 2023-04-22 16:37:53 --> Loader Class Initialized
INFO - 2023-04-22 16:37:53 --> Helper loaded: url_helper
INFO - 2023-04-22 16:37:53 --> Helper loaded: file_helper
INFO - 2023-04-22 16:37:53 --> Helper loaded: html_helper
INFO - 2023-04-22 16:37:53 --> Helper loaded: text_helper
INFO - 2023-04-22 16:37:53 --> Helper loaded: form_helper
INFO - 2023-04-22 16:37:53 --> Helper loaded: lang_helper
INFO - 2023-04-22 16:37:53 --> Helper loaded: security_helper
INFO - 2023-04-22 16:37:53 --> Helper loaded: cookie_helper
INFO - 2023-04-22 16:37:53 --> Database Driver Class Initialized
INFO - 2023-04-22 16:37:53 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-22 16:37:53 --> Parser Class Initialized
INFO - 2023-04-22 16:37:53 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-22 16:37:53 --> Pagination Class Initialized
INFO - 2023-04-22 16:37:53 --> Form Validation Class Initialized
INFO - 2023-04-22 16:37:53 --> Controller Class Initialized
INFO - 2023-04-22 16:37:53 --> Model Class Initialized
DEBUG - 2023-04-22 16:37:53 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-22 16:37:53 --> Model Class Initialized
DEBUG - 2023-04-22 16:37:53 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-22 16:37:53 --> Model Class Initialized
INFO - 2023-04-22 16:37:53 --> Model Class Initialized
INFO - 2023-04-22 16:37:53 --> Model Class Initialized
INFO - 2023-04-22 16:37:53 --> Model Class Initialized
DEBUG - 2023-04-22 16:37:53 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-04-22 16:37:53 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-22 16:37:53 --> Model Class Initialized
INFO - 2023-04-22 16:37:53 --> Model Class Initialized
INFO - 2023-04-22 16:37:53 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-04-22 16:37:53 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-04-22 16:37:53 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-04-22 16:37:53 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-04-22 16:37:53 --> Model Class Initialized
INFO - 2023-04-22 16:37:53 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-04-22 16:37:53 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-04-22 16:37:53 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-04-22 16:37:53 --> Final output sent to browser
DEBUG - 2023-04-22 16:37:53 --> Total execution time: 0.1923
ERROR - 2023-04-22 16:38:06 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-22 16:38:06 --> Config Class Initialized
INFO - 2023-04-22 16:38:06 --> Hooks Class Initialized
DEBUG - 2023-04-22 16:38:06 --> UTF-8 Support Enabled
INFO - 2023-04-22 16:38:06 --> Utf8 Class Initialized
INFO - 2023-04-22 16:38:06 --> URI Class Initialized
INFO - 2023-04-22 16:38:06 --> Router Class Initialized
INFO - 2023-04-22 16:38:06 --> Output Class Initialized
INFO - 2023-04-22 16:38:06 --> Security Class Initialized
DEBUG - 2023-04-22 16:38:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-22 16:38:06 --> Input Class Initialized
INFO - 2023-04-22 16:38:06 --> Language Class Initialized
INFO - 2023-04-22 16:38:06 --> Loader Class Initialized
INFO - 2023-04-22 16:38:06 --> Helper loaded: url_helper
INFO - 2023-04-22 16:38:06 --> Helper loaded: file_helper
INFO - 2023-04-22 16:38:06 --> Helper loaded: html_helper
INFO - 2023-04-22 16:38:06 --> Helper loaded: text_helper
INFO - 2023-04-22 16:38:06 --> Helper loaded: form_helper
INFO - 2023-04-22 16:38:06 --> Helper loaded: lang_helper
INFO - 2023-04-22 16:38:06 --> Helper loaded: security_helper
INFO - 2023-04-22 16:38:06 --> Helper loaded: cookie_helper
INFO - 2023-04-22 16:38:06 --> Database Driver Class Initialized
INFO - 2023-04-22 16:38:06 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-22 16:38:06 --> Parser Class Initialized
INFO - 2023-04-22 16:38:06 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-22 16:38:06 --> Pagination Class Initialized
INFO - 2023-04-22 16:38:06 --> Form Validation Class Initialized
INFO - 2023-04-22 16:38:06 --> Controller Class Initialized
DEBUG - 2023-04-22 16:38:06 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-04-22 16:38:06 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-22 16:38:06 --> Model Class Initialized
DEBUG - 2023-04-22 16:38:06 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-22 16:38:06 --> Model Class Initialized
DEBUG - 2023-04-22 16:38:06 --> Lcustomer class already loaded. Second attempt ignored.
INFO - 2023-04-22 16:38:06 --> Model Class Initialized
INFO - 2023-04-22 16:38:06 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/customer/customer.php
DEBUG - 2023-04-22 16:38:06 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-04-22 16:38:06 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-04-22 16:38:06 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-04-22 16:38:06 --> Model Class Initialized
INFO - 2023-04-22 16:38:06 --> Model Class Initialized
INFO - 2023-04-22 16:38:06 --> Model Class Initialized
INFO - 2023-04-22 16:38:06 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-04-22 16:38:06 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-04-22 16:38:06 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-04-22 16:38:06 --> Final output sent to browser
DEBUG - 2023-04-22 16:38:06 --> Total execution time: 0.1505
ERROR - 2023-04-22 16:38:07 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-22 16:38:07 --> Config Class Initialized
INFO - 2023-04-22 16:38:07 --> Hooks Class Initialized
DEBUG - 2023-04-22 16:38:07 --> UTF-8 Support Enabled
INFO - 2023-04-22 16:38:07 --> Utf8 Class Initialized
INFO - 2023-04-22 16:38:07 --> URI Class Initialized
INFO - 2023-04-22 16:38:07 --> Router Class Initialized
INFO - 2023-04-22 16:38:07 --> Output Class Initialized
INFO - 2023-04-22 16:38:07 --> Security Class Initialized
DEBUG - 2023-04-22 16:38:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-22 16:38:07 --> Input Class Initialized
INFO - 2023-04-22 16:38:07 --> Language Class Initialized
INFO - 2023-04-22 16:38:07 --> Loader Class Initialized
INFO - 2023-04-22 16:38:07 --> Helper loaded: url_helper
INFO - 2023-04-22 16:38:07 --> Helper loaded: file_helper
INFO - 2023-04-22 16:38:07 --> Helper loaded: html_helper
INFO - 2023-04-22 16:38:07 --> Helper loaded: text_helper
INFO - 2023-04-22 16:38:07 --> Helper loaded: form_helper
INFO - 2023-04-22 16:38:07 --> Helper loaded: lang_helper
INFO - 2023-04-22 16:38:07 --> Helper loaded: security_helper
INFO - 2023-04-22 16:38:07 --> Helper loaded: cookie_helper
INFO - 2023-04-22 16:38:07 --> Database Driver Class Initialized
INFO - 2023-04-22 16:38:07 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-22 16:38:07 --> Parser Class Initialized
INFO - 2023-04-22 16:38:07 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-22 16:38:07 --> Pagination Class Initialized
INFO - 2023-04-22 16:38:07 --> Form Validation Class Initialized
INFO - 2023-04-22 16:38:07 --> Controller Class Initialized
DEBUG - 2023-04-22 16:38:07 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-04-22 16:38:07 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-22 16:38:07 --> Model Class Initialized
DEBUG - 2023-04-22 16:38:07 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-22 16:38:07 --> Model Class Initialized
INFO - 2023-04-22 16:38:07 --> Final output sent to browser
DEBUG - 2023-04-22 16:38:07 --> Total execution time: 0.0308
ERROR - 2023-04-22 16:38:12 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-22 16:38:12 --> Config Class Initialized
INFO - 2023-04-22 16:38:12 --> Hooks Class Initialized
DEBUG - 2023-04-22 16:38:12 --> UTF-8 Support Enabled
INFO - 2023-04-22 16:38:12 --> Utf8 Class Initialized
INFO - 2023-04-22 16:38:12 --> URI Class Initialized
INFO - 2023-04-22 16:38:12 --> Router Class Initialized
INFO - 2023-04-22 16:38:12 --> Output Class Initialized
INFO - 2023-04-22 16:38:12 --> Security Class Initialized
DEBUG - 2023-04-22 16:38:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-22 16:38:12 --> Input Class Initialized
INFO - 2023-04-22 16:38:12 --> Language Class Initialized
INFO - 2023-04-22 16:38:12 --> Loader Class Initialized
INFO - 2023-04-22 16:38:12 --> Helper loaded: url_helper
INFO - 2023-04-22 16:38:12 --> Helper loaded: file_helper
INFO - 2023-04-22 16:38:12 --> Helper loaded: html_helper
INFO - 2023-04-22 16:38:12 --> Helper loaded: text_helper
INFO - 2023-04-22 16:38:12 --> Helper loaded: form_helper
INFO - 2023-04-22 16:38:12 --> Helper loaded: lang_helper
INFO - 2023-04-22 16:38:12 --> Helper loaded: security_helper
INFO - 2023-04-22 16:38:12 --> Helper loaded: cookie_helper
INFO - 2023-04-22 16:38:12 --> Database Driver Class Initialized
INFO - 2023-04-22 16:38:12 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-22 16:38:12 --> Parser Class Initialized
INFO - 2023-04-22 16:38:12 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-22 16:38:12 --> Pagination Class Initialized
INFO - 2023-04-22 16:38:12 --> Form Validation Class Initialized
INFO - 2023-04-22 16:38:12 --> Controller Class Initialized
DEBUG - 2023-04-22 16:38:12 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-04-22 16:38:12 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-22 16:38:12 --> Model Class Initialized
DEBUG - 2023-04-22 16:38:12 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-22 16:38:12 --> Model Class Initialized
INFO - 2023-04-22 16:38:12 --> Final output sent to browser
DEBUG - 2023-04-22 16:38:12 --> Total execution time: 0.0851
ERROR - 2023-04-22 16:38:25 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-22 16:38:25 --> Config Class Initialized
INFO - 2023-04-22 16:38:25 --> Hooks Class Initialized
DEBUG - 2023-04-22 16:38:25 --> UTF-8 Support Enabled
INFO - 2023-04-22 16:38:25 --> Utf8 Class Initialized
INFO - 2023-04-22 16:38:25 --> URI Class Initialized
INFO - 2023-04-22 16:38:25 --> Router Class Initialized
INFO - 2023-04-22 16:38:25 --> Output Class Initialized
INFO - 2023-04-22 16:38:25 --> Security Class Initialized
DEBUG - 2023-04-22 16:38:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-22 16:38:25 --> Input Class Initialized
INFO - 2023-04-22 16:38:25 --> Language Class Initialized
INFO - 2023-04-22 16:38:25 --> Loader Class Initialized
INFO - 2023-04-22 16:38:25 --> Helper loaded: url_helper
INFO - 2023-04-22 16:38:25 --> Helper loaded: file_helper
INFO - 2023-04-22 16:38:25 --> Helper loaded: html_helper
INFO - 2023-04-22 16:38:25 --> Helper loaded: text_helper
INFO - 2023-04-22 16:38:25 --> Helper loaded: form_helper
INFO - 2023-04-22 16:38:25 --> Helper loaded: lang_helper
INFO - 2023-04-22 16:38:25 --> Helper loaded: security_helper
INFO - 2023-04-22 16:38:25 --> Helper loaded: cookie_helper
INFO - 2023-04-22 16:38:25 --> Database Driver Class Initialized
INFO - 2023-04-22 16:38:25 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-22 16:38:25 --> Parser Class Initialized
INFO - 2023-04-22 16:38:25 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-22 16:38:25 --> Pagination Class Initialized
INFO - 2023-04-22 16:38:25 --> Form Validation Class Initialized
INFO - 2023-04-22 16:38:25 --> Controller Class Initialized
DEBUG - 2023-04-22 16:38:25 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-04-22 16:38:25 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-22 16:38:25 --> Model Class Initialized
DEBUG - 2023-04-22 16:38:25 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-22 16:38:25 --> Model Class Initialized
INFO - 2023-04-22 16:38:25 --> Final output sent to browser
DEBUG - 2023-04-22 16:38:25 --> Total execution time: 0.0505
ERROR - 2023-04-22 16:38:47 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-22 16:38:47 --> Config Class Initialized
INFO - 2023-04-22 16:38:47 --> Hooks Class Initialized
DEBUG - 2023-04-22 16:38:47 --> UTF-8 Support Enabled
INFO - 2023-04-22 16:38:47 --> Utf8 Class Initialized
INFO - 2023-04-22 16:38:47 --> URI Class Initialized
INFO - 2023-04-22 16:38:47 --> Router Class Initialized
INFO - 2023-04-22 16:38:47 --> Output Class Initialized
INFO - 2023-04-22 16:38:47 --> Security Class Initialized
DEBUG - 2023-04-22 16:38:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-22 16:38:47 --> Input Class Initialized
INFO - 2023-04-22 16:38:47 --> Language Class Initialized
INFO - 2023-04-22 16:38:47 --> Loader Class Initialized
INFO - 2023-04-22 16:38:47 --> Helper loaded: url_helper
INFO - 2023-04-22 16:38:47 --> Helper loaded: file_helper
INFO - 2023-04-22 16:38:47 --> Helper loaded: html_helper
INFO - 2023-04-22 16:38:47 --> Helper loaded: text_helper
INFO - 2023-04-22 16:38:47 --> Helper loaded: form_helper
INFO - 2023-04-22 16:38:47 --> Helper loaded: lang_helper
INFO - 2023-04-22 16:38:47 --> Helper loaded: security_helper
INFO - 2023-04-22 16:38:47 --> Helper loaded: cookie_helper
INFO - 2023-04-22 16:38:47 --> Database Driver Class Initialized
INFO - 2023-04-22 16:38:47 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-22 16:38:47 --> Parser Class Initialized
INFO - 2023-04-22 16:38:47 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-22 16:38:47 --> Pagination Class Initialized
INFO - 2023-04-22 16:38:47 --> Form Validation Class Initialized
INFO - 2023-04-22 16:38:47 --> Controller Class Initialized
DEBUG - 2023-04-22 16:38:47 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-04-22 16:38:47 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-22 16:38:47 --> Model Class Initialized
INFO - 2023-04-22 16:38:47 --> Model Class Initialized
DEBUG - 2023-04-22 16:38:47 --> Lmr class already loaded. Second attempt ignored.
INFO - 2023-04-22 16:38:47 --> Model Class Initialized
INFO - 2023-04-22 16:38:47 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/mr/mr.php
DEBUG - 2023-04-22 16:38:47 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-04-22 16:38:47 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-04-22 16:38:47 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-04-22 16:38:47 --> Model Class Initialized
INFO - 2023-04-22 16:38:47 --> Model Class Initialized
INFO - 2023-04-22 16:38:47 --> Model Class Initialized
INFO - 2023-04-22 16:38:48 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-04-22 16:38:48 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-04-22 16:38:48 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-04-22 16:38:48 --> Final output sent to browser
DEBUG - 2023-04-22 16:38:48 --> Total execution time: 0.1729
ERROR - 2023-04-22 16:38:48 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-22 16:38:48 --> Config Class Initialized
INFO - 2023-04-22 16:38:48 --> Hooks Class Initialized
DEBUG - 2023-04-22 16:38:48 --> UTF-8 Support Enabled
INFO - 2023-04-22 16:38:48 --> Utf8 Class Initialized
INFO - 2023-04-22 16:38:48 --> URI Class Initialized
INFO - 2023-04-22 16:38:48 --> Router Class Initialized
INFO - 2023-04-22 16:38:48 --> Output Class Initialized
INFO - 2023-04-22 16:38:48 --> Security Class Initialized
DEBUG - 2023-04-22 16:38:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-22 16:38:48 --> Input Class Initialized
INFO - 2023-04-22 16:38:48 --> Language Class Initialized
INFO - 2023-04-22 16:38:48 --> Loader Class Initialized
INFO - 2023-04-22 16:38:48 --> Helper loaded: url_helper
INFO - 2023-04-22 16:38:48 --> Helper loaded: file_helper
INFO - 2023-04-22 16:38:48 --> Helper loaded: html_helper
INFO - 2023-04-22 16:38:48 --> Helper loaded: text_helper
INFO - 2023-04-22 16:38:48 --> Helper loaded: form_helper
INFO - 2023-04-22 16:38:48 --> Helper loaded: lang_helper
INFO - 2023-04-22 16:38:48 --> Helper loaded: security_helper
INFO - 2023-04-22 16:38:48 --> Helper loaded: cookie_helper
INFO - 2023-04-22 16:38:48 --> Database Driver Class Initialized
INFO - 2023-04-22 16:38:48 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-22 16:38:48 --> Parser Class Initialized
INFO - 2023-04-22 16:38:48 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-22 16:38:48 --> Pagination Class Initialized
INFO - 2023-04-22 16:38:48 --> Form Validation Class Initialized
INFO - 2023-04-22 16:38:48 --> Controller Class Initialized
DEBUG - 2023-04-22 16:38:48 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-04-22 16:38:48 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-22 16:38:48 --> Model Class Initialized
INFO - 2023-04-22 16:38:48 --> Model Class Initialized
INFO - 2023-04-22 16:38:48 --> Final output sent to browser
DEBUG - 2023-04-22 16:38:48 --> Total execution time: 0.0223
ERROR - 2023-04-22 16:38:54 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-22 16:38:54 --> Config Class Initialized
INFO - 2023-04-22 16:38:54 --> Hooks Class Initialized
DEBUG - 2023-04-22 16:38:54 --> UTF-8 Support Enabled
INFO - 2023-04-22 16:38:54 --> Utf8 Class Initialized
INFO - 2023-04-22 16:38:54 --> URI Class Initialized
INFO - 2023-04-22 16:38:54 --> Router Class Initialized
INFO - 2023-04-22 16:38:54 --> Output Class Initialized
INFO - 2023-04-22 16:38:54 --> Security Class Initialized
DEBUG - 2023-04-22 16:38:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-22 16:38:54 --> Input Class Initialized
INFO - 2023-04-22 16:38:54 --> Language Class Initialized
INFO - 2023-04-22 16:38:54 --> Loader Class Initialized
INFO - 2023-04-22 16:38:54 --> Helper loaded: url_helper
INFO - 2023-04-22 16:38:54 --> Helper loaded: file_helper
INFO - 2023-04-22 16:38:54 --> Helper loaded: html_helper
INFO - 2023-04-22 16:38:54 --> Helper loaded: text_helper
INFO - 2023-04-22 16:38:54 --> Helper loaded: form_helper
INFO - 2023-04-22 16:38:54 --> Helper loaded: lang_helper
INFO - 2023-04-22 16:38:54 --> Helper loaded: security_helper
INFO - 2023-04-22 16:38:54 --> Helper loaded: cookie_helper
INFO - 2023-04-22 16:38:54 --> Database Driver Class Initialized
INFO - 2023-04-22 16:38:54 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-22 16:38:54 --> Parser Class Initialized
INFO - 2023-04-22 16:38:54 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-22 16:38:54 --> Pagination Class Initialized
INFO - 2023-04-22 16:38:54 --> Form Validation Class Initialized
INFO - 2023-04-22 16:38:54 --> Controller Class Initialized
DEBUG - 2023-04-22 16:38:54 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-04-22 16:38:54 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-22 16:38:54 --> Model Class Initialized
INFO - 2023-04-22 16:38:54 --> Model Class Initialized
INFO - 2023-04-22 16:38:54 --> Final output sent to browser
DEBUG - 2023-04-22 16:38:54 --> Total execution time: 0.0217
ERROR - 2023-04-22 16:39:26 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-22 16:39:26 --> Config Class Initialized
INFO - 2023-04-22 16:39:26 --> Hooks Class Initialized
DEBUG - 2023-04-22 16:39:26 --> UTF-8 Support Enabled
INFO - 2023-04-22 16:39:26 --> Utf8 Class Initialized
INFO - 2023-04-22 16:39:26 --> URI Class Initialized
INFO - 2023-04-22 16:39:26 --> Router Class Initialized
INFO - 2023-04-22 16:39:26 --> Output Class Initialized
INFO - 2023-04-22 16:39:26 --> Security Class Initialized
DEBUG - 2023-04-22 16:39:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-22 16:39:26 --> Input Class Initialized
INFO - 2023-04-22 16:39:26 --> Language Class Initialized
INFO - 2023-04-22 16:39:26 --> Loader Class Initialized
INFO - 2023-04-22 16:39:26 --> Helper loaded: url_helper
INFO - 2023-04-22 16:39:26 --> Helper loaded: file_helper
INFO - 2023-04-22 16:39:26 --> Helper loaded: html_helper
INFO - 2023-04-22 16:39:26 --> Helper loaded: text_helper
INFO - 2023-04-22 16:39:26 --> Helper loaded: form_helper
INFO - 2023-04-22 16:39:26 --> Helper loaded: lang_helper
INFO - 2023-04-22 16:39:26 --> Helper loaded: security_helper
INFO - 2023-04-22 16:39:26 --> Helper loaded: cookie_helper
INFO - 2023-04-22 16:39:26 --> Database Driver Class Initialized
INFO - 2023-04-22 16:39:26 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-22 16:39:26 --> Parser Class Initialized
INFO - 2023-04-22 16:39:26 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-22 16:39:26 --> Pagination Class Initialized
INFO - 2023-04-22 16:39:26 --> Form Validation Class Initialized
INFO - 2023-04-22 16:39:26 --> Controller Class Initialized
DEBUG - 2023-04-22 16:39:26 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-04-22 16:39:26 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-22 16:39:26 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/return/form.php
DEBUG - 2023-04-22 16:39:26 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-04-22 16:39:26 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-04-22 16:39:26 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-04-22 16:39:26 --> Model Class Initialized
INFO - 2023-04-22 16:39:26 --> Model Class Initialized
INFO - 2023-04-22 16:39:26 --> Model Class Initialized
INFO - 2023-04-22 16:39:26 --> Model Class Initialized
INFO - 2023-04-22 16:39:26 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-04-22 16:39:26 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-04-22 16:39:26 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-04-22 16:39:26 --> Final output sent to browser
DEBUG - 2023-04-22 16:39:26 --> Total execution time: 0.1558
ERROR - 2023-04-22 16:39:35 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-22 16:39:35 --> Config Class Initialized
INFO - 2023-04-22 16:39:35 --> Hooks Class Initialized
DEBUG - 2023-04-22 16:39:35 --> UTF-8 Support Enabled
INFO - 2023-04-22 16:39:35 --> Utf8 Class Initialized
INFO - 2023-04-22 16:39:35 --> URI Class Initialized
INFO - 2023-04-22 16:39:35 --> Router Class Initialized
INFO - 2023-04-22 16:39:35 --> Output Class Initialized
INFO - 2023-04-22 16:39:35 --> Security Class Initialized
DEBUG - 2023-04-22 16:39:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-22 16:39:35 --> Input Class Initialized
INFO - 2023-04-22 16:39:35 --> Language Class Initialized
INFO - 2023-04-22 16:39:35 --> Loader Class Initialized
INFO - 2023-04-22 16:39:35 --> Helper loaded: url_helper
INFO - 2023-04-22 16:39:35 --> Helper loaded: file_helper
INFO - 2023-04-22 16:39:35 --> Helper loaded: html_helper
INFO - 2023-04-22 16:39:35 --> Helper loaded: text_helper
INFO - 2023-04-22 16:39:35 --> Helper loaded: form_helper
INFO - 2023-04-22 16:39:35 --> Helper loaded: lang_helper
INFO - 2023-04-22 16:39:35 --> Helper loaded: security_helper
INFO - 2023-04-22 16:39:35 --> Helper loaded: cookie_helper
INFO - 2023-04-22 16:39:35 --> Database Driver Class Initialized
INFO - 2023-04-22 16:39:35 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-22 16:39:35 --> Parser Class Initialized
INFO - 2023-04-22 16:39:35 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-22 16:39:35 --> Pagination Class Initialized
INFO - 2023-04-22 16:39:35 --> Form Validation Class Initialized
INFO - 2023-04-22 16:39:35 --> Controller Class Initialized
INFO - 2023-04-22 16:39:35 --> Model Class Initialized
DEBUG - 2023-04-22 16:39:35 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-04-22 16:39:35 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-22 16:39:35 --> Model Class Initialized
DEBUG - 2023-04-22 16:39:35 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-22 16:39:35 --> Model Class Initialized
INFO - 2023-04-22 16:39:35 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice.php
DEBUG - 2023-04-22 16:39:35 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-04-22 16:39:35 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-04-22 16:39:35 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-04-22 16:39:35 --> Model Class Initialized
INFO - 2023-04-22 16:39:35 --> Model Class Initialized
INFO - 2023-04-22 16:39:35 --> Model Class Initialized
INFO - 2023-04-22 16:39:35 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-04-22 16:39:35 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-04-22 16:39:35 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-04-22 16:39:35 --> Final output sent to browser
DEBUG - 2023-04-22 16:39:35 --> Total execution time: 0.1523
ERROR - 2023-04-22 16:39:36 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-22 16:39:36 --> Config Class Initialized
INFO - 2023-04-22 16:39:36 --> Hooks Class Initialized
DEBUG - 2023-04-22 16:39:36 --> UTF-8 Support Enabled
INFO - 2023-04-22 16:39:36 --> Utf8 Class Initialized
INFO - 2023-04-22 16:39:36 --> URI Class Initialized
INFO - 2023-04-22 16:39:36 --> Router Class Initialized
INFO - 2023-04-22 16:39:36 --> Output Class Initialized
INFO - 2023-04-22 16:39:36 --> Security Class Initialized
DEBUG - 2023-04-22 16:39:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-22 16:39:36 --> Input Class Initialized
INFO - 2023-04-22 16:39:36 --> Language Class Initialized
INFO - 2023-04-22 16:39:36 --> Loader Class Initialized
INFO - 2023-04-22 16:39:36 --> Helper loaded: url_helper
INFO - 2023-04-22 16:39:36 --> Helper loaded: file_helper
INFO - 2023-04-22 16:39:36 --> Helper loaded: html_helper
INFO - 2023-04-22 16:39:36 --> Helper loaded: text_helper
INFO - 2023-04-22 16:39:36 --> Helper loaded: form_helper
INFO - 2023-04-22 16:39:36 --> Helper loaded: lang_helper
INFO - 2023-04-22 16:39:36 --> Helper loaded: security_helper
INFO - 2023-04-22 16:39:36 --> Helper loaded: cookie_helper
INFO - 2023-04-22 16:39:36 --> Database Driver Class Initialized
INFO - 2023-04-22 16:39:36 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-22 16:39:36 --> Parser Class Initialized
INFO - 2023-04-22 16:39:36 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-22 16:39:36 --> Pagination Class Initialized
INFO - 2023-04-22 16:39:36 --> Form Validation Class Initialized
INFO - 2023-04-22 16:39:36 --> Controller Class Initialized
INFO - 2023-04-22 16:39:36 --> Model Class Initialized
DEBUG - 2023-04-22 16:39:36 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-04-22 16:39:36 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-22 16:39:36 --> Model Class Initialized
DEBUG - 2023-04-22 16:39:36 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-22 16:39:36 --> Model Class Initialized
INFO - 2023-04-22 16:39:36 --> Final output sent to browser
DEBUG - 2023-04-22 16:39:36 --> Total execution time: 0.0561
ERROR - 2023-04-22 16:39:41 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-22 16:39:41 --> Config Class Initialized
INFO - 2023-04-22 16:39:41 --> Hooks Class Initialized
DEBUG - 2023-04-22 16:39:41 --> UTF-8 Support Enabled
INFO - 2023-04-22 16:39:41 --> Utf8 Class Initialized
INFO - 2023-04-22 16:39:41 --> URI Class Initialized
INFO - 2023-04-22 16:39:41 --> Router Class Initialized
INFO - 2023-04-22 16:39:41 --> Output Class Initialized
INFO - 2023-04-22 16:39:41 --> Security Class Initialized
DEBUG - 2023-04-22 16:39:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-22 16:39:41 --> Input Class Initialized
INFO - 2023-04-22 16:39:41 --> Language Class Initialized
INFO - 2023-04-22 16:39:41 --> Loader Class Initialized
INFO - 2023-04-22 16:39:41 --> Helper loaded: url_helper
INFO - 2023-04-22 16:39:41 --> Helper loaded: file_helper
INFO - 2023-04-22 16:39:41 --> Helper loaded: html_helper
INFO - 2023-04-22 16:39:41 --> Helper loaded: text_helper
INFO - 2023-04-22 16:39:41 --> Helper loaded: form_helper
INFO - 2023-04-22 16:39:41 --> Helper loaded: lang_helper
INFO - 2023-04-22 16:39:41 --> Helper loaded: security_helper
INFO - 2023-04-22 16:39:41 --> Helper loaded: cookie_helper
INFO - 2023-04-22 16:39:41 --> Database Driver Class Initialized
INFO - 2023-04-22 16:39:41 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-22 16:39:41 --> Parser Class Initialized
INFO - 2023-04-22 16:39:41 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-22 16:39:41 --> Pagination Class Initialized
INFO - 2023-04-22 16:39:41 --> Form Validation Class Initialized
INFO - 2023-04-22 16:39:41 --> Controller Class Initialized
INFO - 2023-04-22 16:39:41 --> Model Class Initialized
DEBUG - 2023-04-22 16:39:41 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-04-22 16:39:41 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-22 16:39:41 --> Model Class Initialized
DEBUG - 2023-04-22 16:39:41 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-22 16:39:41 --> Model Class Initialized
INFO - 2023-04-22 16:39:41 --> Final output sent to browser
DEBUG - 2023-04-22 16:39:41 --> Total execution time: 0.0780
ERROR - 2023-04-22 16:39:55 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-22 16:39:55 --> Config Class Initialized
INFO - 2023-04-22 16:39:55 --> Hooks Class Initialized
DEBUG - 2023-04-22 16:39:55 --> UTF-8 Support Enabled
INFO - 2023-04-22 16:39:55 --> Utf8 Class Initialized
INFO - 2023-04-22 16:39:55 --> URI Class Initialized
INFO - 2023-04-22 16:39:55 --> Router Class Initialized
INFO - 2023-04-22 16:39:55 --> Output Class Initialized
INFO - 2023-04-22 16:39:55 --> Security Class Initialized
DEBUG - 2023-04-22 16:39:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-22 16:39:55 --> Input Class Initialized
INFO - 2023-04-22 16:39:55 --> Language Class Initialized
INFO - 2023-04-22 16:39:55 --> Loader Class Initialized
INFO - 2023-04-22 16:39:55 --> Helper loaded: url_helper
INFO - 2023-04-22 16:39:55 --> Helper loaded: file_helper
INFO - 2023-04-22 16:39:55 --> Helper loaded: html_helper
INFO - 2023-04-22 16:39:55 --> Helper loaded: text_helper
INFO - 2023-04-22 16:39:55 --> Helper loaded: form_helper
INFO - 2023-04-22 16:39:55 --> Helper loaded: lang_helper
INFO - 2023-04-22 16:39:55 --> Helper loaded: security_helper
INFO - 2023-04-22 16:39:55 --> Helper loaded: cookie_helper
INFO - 2023-04-22 16:39:55 --> Database Driver Class Initialized
INFO - 2023-04-22 16:39:55 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-22 16:39:55 --> Parser Class Initialized
INFO - 2023-04-22 16:39:55 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-22 16:39:55 --> Pagination Class Initialized
INFO - 2023-04-22 16:39:55 --> Form Validation Class Initialized
INFO - 2023-04-22 16:39:55 --> Controller Class Initialized
INFO - 2023-04-22 16:39:55 --> Model Class Initialized
DEBUG - 2023-04-22 16:39:55 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-04-22 16:39:55 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-22 16:39:55 --> Model Class Initialized
DEBUG - 2023-04-22 16:39:55 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-22 16:39:55 --> Model Class Initialized
INFO - 2023-04-22 16:39:55 --> Final output sent to browser
DEBUG - 2023-04-22 16:39:55 --> Total execution time: 0.0780
ERROR - 2023-04-22 16:40:19 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-22 16:40:19 --> Config Class Initialized
INFO - 2023-04-22 16:40:19 --> Hooks Class Initialized
DEBUG - 2023-04-22 16:40:19 --> UTF-8 Support Enabled
INFO - 2023-04-22 16:40:19 --> Utf8 Class Initialized
INFO - 2023-04-22 16:40:19 --> URI Class Initialized
INFO - 2023-04-22 16:40:19 --> Router Class Initialized
INFO - 2023-04-22 16:40:19 --> Output Class Initialized
INFO - 2023-04-22 16:40:19 --> Security Class Initialized
DEBUG - 2023-04-22 16:40:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-22 16:40:19 --> Input Class Initialized
INFO - 2023-04-22 16:40:19 --> Language Class Initialized
INFO - 2023-04-22 16:40:19 --> Loader Class Initialized
INFO - 2023-04-22 16:40:19 --> Helper loaded: url_helper
INFO - 2023-04-22 16:40:19 --> Helper loaded: file_helper
INFO - 2023-04-22 16:40:19 --> Helper loaded: html_helper
INFO - 2023-04-22 16:40:19 --> Helper loaded: text_helper
INFO - 2023-04-22 16:40:19 --> Helper loaded: form_helper
INFO - 2023-04-22 16:40:19 --> Helper loaded: lang_helper
INFO - 2023-04-22 16:40:19 --> Helper loaded: security_helper
INFO - 2023-04-22 16:40:19 --> Helper loaded: cookie_helper
INFO - 2023-04-22 16:40:19 --> Database Driver Class Initialized
INFO - 2023-04-22 16:40:19 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-22 16:40:19 --> Parser Class Initialized
INFO - 2023-04-22 16:40:19 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-22 16:40:19 --> Pagination Class Initialized
INFO - 2023-04-22 16:40:19 --> Form Validation Class Initialized
INFO - 2023-04-22 16:40:19 --> Controller Class Initialized
INFO - 2023-04-22 16:40:19 --> Model Class Initialized
DEBUG - 2023-04-22 16:40:19 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-04-22 16:40:19 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-22 16:40:19 --> Model Class Initialized
DEBUG - 2023-04-22 16:40:19 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-22 16:40:19 --> Model Class Initialized
INFO - 2023-04-22 16:40:19 --> Final output sent to browser
DEBUG - 2023-04-22 16:40:19 --> Total execution time: 0.0731
ERROR - 2023-04-22 16:40:39 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-22 16:40:39 --> Config Class Initialized
INFO - 2023-04-22 16:40:39 --> Hooks Class Initialized
DEBUG - 2023-04-22 16:40:39 --> UTF-8 Support Enabled
INFO - 2023-04-22 16:40:39 --> Utf8 Class Initialized
INFO - 2023-04-22 16:40:39 --> URI Class Initialized
INFO - 2023-04-22 16:40:39 --> Router Class Initialized
INFO - 2023-04-22 16:40:39 --> Output Class Initialized
INFO - 2023-04-22 16:40:39 --> Security Class Initialized
DEBUG - 2023-04-22 16:40:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-22 16:40:39 --> Input Class Initialized
INFO - 2023-04-22 16:40:39 --> Language Class Initialized
INFO - 2023-04-22 16:40:39 --> Loader Class Initialized
INFO - 2023-04-22 16:40:39 --> Helper loaded: url_helper
INFO - 2023-04-22 16:40:39 --> Helper loaded: file_helper
INFO - 2023-04-22 16:40:39 --> Helper loaded: html_helper
INFO - 2023-04-22 16:40:39 --> Helper loaded: text_helper
INFO - 2023-04-22 16:40:39 --> Helper loaded: form_helper
INFO - 2023-04-22 16:40:39 --> Helper loaded: lang_helper
INFO - 2023-04-22 16:40:39 --> Helper loaded: security_helper
INFO - 2023-04-22 16:40:39 --> Helper loaded: cookie_helper
INFO - 2023-04-22 16:40:39 --> Database Driver Class Initialized
INFO - 2023-04-22 16:40:39 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-22 16:40:39 --> Parser Class Initialized
INFO - 2023-04-22 16:40:39 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-22 16:40:39 --> Pagination Class Initialized
INFO - 2023-04-22 16:40:39 --> Form Validation Class Initialized
INFO - 2023-04-22 16:40:39 --> Controller Class Initialized
INFO - 2023-04-22 16:40:39 --> Model Class Initialized
DEBUG - 2023-04-22 16:40:39 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-04-22 16:40:39 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-22 16:40:39 --> Model Class Initialized
INFO - 2023-04-22 16:40:39 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/demandrequest/customer_demandrequest.php
DEBUG - 2023-04-22 16:40:39 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-04-22 16:40:39 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-04-22 16:40:39 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-04-22 16:40:39 --> Model Class Initialized
INFO - 2023-04-22 16:40:39 --> Model Class Initialized
INFO - 2023-04-22 16:40:39 --> Model Class Initialized
INFO - 2023-04-22 16:40:39 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-04-22 16:40:39 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-04-22 16:40:39 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-04-22 16:40:39 --> Final output sent to browser
DEBUG - 2023-04-22 16:40:39 --> Total execution time: 0.1458
ERROR - 2023-04-22 16:40:39 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-22 16:40:39 --> Config Class Initialized
INFO - 2023-04-22 16:40:39 --> Hooks Class Initialized
DEBUG - 2023-04-22 16:40:39 --> UTF-8 Support Enabled
INFO - 2023-04-22 16:40:39 --> Utf8 Class Initialized
INFO - 2023-04-22 16:40:39 --> URI Class Initialized
INFO - 2023-04-22 16:40:39 --> Router Class Initialized
INFO - 2023-04-22 16:40:39 --> Output Class Initialized
INFO - 2023-04-22 16:40:39 --> Security Class Initialized
DEBUG - 2023-04-22 16:40:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-22 16:40:39 --> Input Class Initialized
INFO - 2023-04-22 16:40:39 --> Language Class Initialized
INFO - 2023-04-22 16:40:39 --> Loader Class Initialized
INFO - 2023-04-22 16:40:39 --> Helper loaded: url_helper
INFO - 2023-04-22 16:40:39 --> Helper loaded: file_helper
INFO - 2023-04-22 16:40:39 --> Helper loaded: html_helper
INFO - 2023-04-22 16:40:39 --> Helper loaded: text_helper
INFO - 2023-04-22 16:40:39 --> Helper loaded: form_helper
INFO - 2023-04-22 16:40:39 --> Helper loaded: lang_helper
INFO - 2023-04-22 16:40:39 --> Helper loaded: security_helper
INFO - 2023-04-22 16:40:39 --> Helper loaded: cookie_helper
INFO - 2023-04-22 16:40:39 --> Database Driver Class Initialized
INFO - 2023-04-22 16:40:39 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-22 16:40:39 --> Parser Class Initialized
INFO - 2023-04-22 16:40:39 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-22 16:40:39 --> Pagination Class Initialized
INFO - 2023-04-22 16:40:39 --> Form Validation Class Initialized
INFO - 2023-04-22 16:40:39 --> Controller Class Initialized
INFO - 2023-04-22 16:40:39 --> Model Class Initialized
DEBUG - 2023-04-22 16:40:39 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-04-22 16:40:39 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-22 16:40:39 --> Model Class Initialized
INFO - 2023-04-22 16:40:39 --> Final output sent to browser
DEBUG - 2023-04-22 16:40:39 --> Total execution time: 0.0301
ERROR - 2023-04-22 16:40:56 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-22 16:40:56 --> Config Class Initialized
INFO - 2023-04-22 16:40:56 --> Hooks Class Initialized
DEBUG - 2023-04-22 16:40:56 --> UTF-8 Support Enabled
INFO - 2023-04-22 16:40:56 --> Utf8 Class Initialized
INFO - 2023-04-22 16:40:56 --> URI Class Initialized
INFO - 2023-04-22 16:40:56 --> Router Class Initialized
INFO - 2023-04-22 16:40:56 --> Output Class Initialized
INFO - 2023-04-22 16:40:56 --> Security Class Initialized
DEBUG - 2023-04-22 16:40:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-22 16:40:56 --> Input Class Initialized
INFO - 2023-04-22 16:40:56 --> Language Class Initialized
INFO - 2023-04-22 16:40:56 --> Loader Class Initialized
INFO - 2023-04-22 16:40:56 --> Helper loaded: url_helper
INFO - 2023-04-22 16:40:56 --> Helper loaded: file_helper
INFO - 2023-04-22 16:40:56 --> Helper loaded: html_helper
INFO - 2023-04-22 16:40:56 --> Helper loaded: text_helper
INFO - 2023-04-22 16:40:56 --> Helper loaded: form_helper
INFO - 2023-04-22 16:40:56 --> Helper loaded: lang_helper
INFO - 2023-04-22 16:40:56 --> Helper loaded: security_helper
INFO - 2023-04-22 16:40:56 --> Helper loaded: cookie_helper
INFO - 2023-04-22 16:40:56 --> Database Driver Class Initialized
INFO - 2023-04-22 16:40:56 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-22 16:40:56 --> Parser Class Initialized
INFO - 2023-04-22 16:40:56 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-22 16:40:56 --> Pagination Class Initialized
INFO - 2023-04-22 16:40:56 --> Form Validation Class Initialized
INFO - 2023-04-22 16:40:56 --> Controller Class Initialized
INFO - 2023-04-22 16:40:56 --> Model Class Initialized
DEBUG - 2023-04-22 16:40:56 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-04-22 16:40:56 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-22 16:40:56 --> Model Class Initialized
DEBUG - 2023-04-22 16:40:56 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-22 16:40:56 --> Model Class Initialized
INFO - 2023-04-22 16:40:56 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/invoice/invoice.php
DEBUG - 2023-04-22 16:40:56 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-04-22 16:40:56 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-04-22 16:40:56 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-04-22 16:40:56 --> Model Class Initialized
INFO - 2023-04-22 16:40:56 --> Model Class Initialized
INFO - 2023-04-22 16:40:56 --> Model Class Initialized
INFO - 2023-04-22 16:40:56 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-04-22 16:40:56 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-04-22 16:40:56 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-04-22 16:40:56 --> Final output sent to browser
DEBUG - 2023-04-22 16:40:56 --> Total execution time: 0.1571
ERROR - 2023-04-22 16:40:57 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-22 16:40:57 --> Config Class Initialized
INFO - 2023-04-22 16:40:57 --> Hooks Class Initialized
DEBUG - 2023-04-22 16:40:57 --> UTF-8 Support Enabled
INFO - 2023-04-22 16:40:57 --> Utf8 Class Initialized
INFO - 2023-04-22 16:40:57 --> URI Class Initialized
INFO - 2023-04-22 16:40:57 --> Router Class Initialized
INFO - 2023-04-22 16:40:57 --> Output Class Initialized
INFO - 2023-04-22 16:40:57 --> Security Class Initialized
DEBUG - 2023-04-22 16:40:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-22 16:40:57 --> Input Class Initialized
INFO - 2023-04-22 16:40:57 --> Language Class Initialized
INFO - 2023-04-22 16:40:57 --> Loader Class Initialized
INFO - 2023-04-22 16:40:57 --> Helper loaded: url_helper
INFO - 2023-04-22 16:40:57 --> Helper loaded: file_helper
INFO - 2023-04-22 16:40:57 --> Helper loaded: html_helper
INFO - 2023-04-22 16:40:57 --> Helper loaded: text_helper
INFO - 2023-04-22 16:40:57 --> Helper loaded: form_helper
INFO - 2023-04-22 16:40:57 --> Helper loaded: lang_helper
INFO - 2023-04-22 16:40:57 --> Helper loaded: security_helper
INFO - 2023-04-22 16:40:57 --> Helper loaded: cookie_helper
INFO - 2023-04-22 16:40:57 --> Database Driver Class Initialized
INFO - 2023-04-22 16:40:57 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-22 16:40:57 --> Parser Class Initialized
INFO - 2023-04-22 16:40:57 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-22 16:40:57 --> Pagination Class Initialized
INFO - 2023-04-22 16:40:57 --> Form Validation Class Initialized
INFO - 2023-04-22 16:40:57 --> Controller Class Initialized
INFO - 2023-04-22 16:40:57 --> Model Class Initialized
DEBUG - 2023-04-22 16:40:57 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-04-22 16:40:57 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-22 16:40:57 --> Model Class Initialized
DEBUG - 2023-04-22 16:40:57 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-22 16:40:57 --> Model Class Initialized
INFO - 2023-04-22 16:40:57 --> Final output sent to browser
DEBUG - 2023-04-22 16:40:57 --> Total execution time: 0.0259
ERROR - 2023-04-22 16:41:02 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-22 16:41:02 --> Config Class Initialized
INFO - 2023-04-22 16:41:02 --> Hooks Class Initialized
DEBUG - 2023-04-22 16:41:02 --> UTF-8 Support Enabled
INFO - 2023-04-22 16:41:02 --> Utf8 Class Initialized
INFO - 2023-04-22 16:41:02 --> URI Class Initialized
INFO - 2023-04-22 16:41:02 --> Router Class Initialized
INFO - 2023-04-22 16:41:02 --> Output Class Initialized
INFO - 2023-04-22 16:41:02 --> Security Class Initialized
DEBUG - 2023-04-22 16:41:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-22 16:41:02 --> Input Class Initialized
INFO - 2023-04-22 16:41:02 --> Language Class Initialized
INFO - 2023-04-22 16:41:02 --> Loader Class Initialized
INFO - 2023-04-22 16:41:02 --> Helper loaded: url_helper
INFO - 2023-04-22 16:41:02 --> Helper loaded: file_helper
INFO - 2023-04-22 16:41:02 --> Helper loaded: html_helper
INFO - 2023-04-22 16:41:02 --> Helper loaded: text_helper
INFO - 2023-04-22 16:41:02 --> Helper loaded: form_helper
INFO - 2023-04-22 16:41:02 --> Helper loaded: lang_helper
INFO - 2023-04-22 16:41:02 --> Helper loaded: security_helper
INFO - 2023-04-22 16:41:02 --> Helper loaded: cookie_helper
INFO - 2023-04-22 16:41:02 --> Database Driver Class Initialized
INFO - 2023-04-22 16:41:02 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-22 16:41:02 --> Parser Class Initialized
INFO - 2023-04-22 16:41:02 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-22 16:41:02 --> Pagination Class Initialized
INFO - 2023-04-22 16:41:02 --> Form Validation Class Initialized
INFO - 2023-04-22 16:41:02 --> Controller Class Initialized
INFO - 2023-04-22 16:41:02 --> Model Class Initialized
DEBUG - 2023-04-22 16:41:02 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-04-22 16:41:02 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-22 16:41:02 --> Model Class Initialized
DEBUG - 2023-04-22 16:41:02 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-22 16:41:02 --> Model Class Initialized
INFO - 2023-04-22 16:41:02 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice.php
DEBUG - 2023-04-22 16:41:02 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-04-22 16:41:02 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-04-22 16:41:02 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-04-22 16:41:02 --> Model Class Initialized
INFO - 2023-04-22 16:41:02 --> Model Class Initialized
INFO - 2023-04-22 16:41:02 --> Model Class Initialized
INFO - 2023-04-22 16:41:02 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-04-22 16:41:02 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-04-22 16:41:02 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-04-22 16:41:02 --> Final output sent to browser
DEBUG - 2023-04-22 16:41:02 --> Total execution time: 0.1841
ERROR - 2023-04-22 16:41:03 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-22 16:41:03 --> Config Class Initialized
INFO - 2023-04-22 16:41:03 --> Hooks Class Initialized
DEBUG - 2023-04-22 16:41:03 --> UTF-8 Support Enabled
INFO - 2023-04-22 16:41:03 --> Utf8 Class Initialized
INFO - 2023-04-22 16:41:03 --> URI Class Initialized
INFO - 2023-04-22 16:41:03 --> Router Class Initialized
INFO - 2023-04-22 16:41:03 --> Output Class Initialized
INFO - 2023-04-22 16:41:03 --> Security Class Initialized
DEBUG - 2023-04-22 16:41:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-22 16:41:03 --> Input Class Initialized
INFO - 2023-04-22 16:41:03 --> Language Class Initialized
INFO - 2023-04-22 16:41:03 --> Loader Class Initialized
INFO - 2023-04-22 16:41:03 --> Helper loaded: url_helper
INFO - 2023-04-22 16:41:03 --> Helper loaded: file_helper
INFO - 2023-04-22 16:41:03 --> Helper loaded: html_helper
INFO - 2023-04-22 16:41:03 --> Helper loaded: text_helper
INFO - 2023-04-22 16:41:03 --> Helper loaded: form_helper
INFO - 2023-04-22 16:41:03 --> Helper loaded: lang_helper
INFO - 2023-04-22 16:41:03 --> Helper loaded: security_helper
INFO - 2023-04-22 16:41:03 --> Helper loaded: cookie_helper
INFO - 2023-04-22 16:41:03 --> Database Driver Class Initialized
INFO - 2023-04-22 16:41:03 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-22 16:41:03 --> Parser Class Initialized
INFO - 2023-04-22 16:41:03 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-22 16:41:03 --> Pagination Class Initialized
INFO - 2023-04-22 16:41:03 --> Form Validation Class Initialized
INFO - 2023-04-22 16:41:03 --> Controller Class Initialized
INFO - 2023-04-22 16:41:03 --> Model Class Initialized
DEBUG - 2023-04-22 16:41:03 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-04-22 16:41:03 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-22 16:41:03 --> Model Class Initialized
DEBUG - 2023-04-22 16:41:03 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-22 16:41:03 --> Model Class Initialized
INFO - 2023-04-22 16:41:03 --> Final output sent to browser
DEBUG - 2023-04-22 16:41:03 --> Total execution time: 0.0642
ERROR - 2023-04-22 16:41:14 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-22 16:41:14 --> Config Class Initialized
INFO - 2023-04-22 16:41:14 --> Hooks Class Initialized
DEBUG - 2023-04-22 16:41:14 --> UTF-8 Support Enabled
INFO - 2023-04-22 16:41:14 --> Utf8 Class Initialized
INFO - 2023-04-22 16:41:14 --> URI Class Initialized
INFO - 2023-04-22 16:41:14 --> Router Class Initialized
INFO - 2023-04-22 16:41:14 --> Output Class Initialized
INFO - 2023-04-22 16:41:14 --> Security Class Initialized
DEBUG - 2023-04-22 16:41:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-22 16:41:14 --> Input Class Initialized
INFO - 2023-04-22 16:41:14 --> Language Class Initialized
INFO - 2023-04-22 16:41:14 --> Loader Class Initialized
INFO - 2023-04-22 16:41:14 --> Helper loaded: url_helper
INFO - 2023-04-22 16:41:14 --> Helper loaded: file_helper
INFO - 2023-04-22 16:41:14 --> Helper loaded: html_helper
INFO - 2023-04-22 16:41:14 --> Helper loaded: text_helper
INFO - 2023-04-22 16:41:14 --> Helper loaded: form_helper
INFO - 2023-04-22 16:41:14 --> Helper loaded: lang_helper
INFO - 2023-04-22 16:41:14 --> Helper loaded: security_helper
INFO - 2023-04-22 16:41:14 --> Helper loaded: cookie_helper
INFO - 2023-04-22 16:41:14 --> Database Driver Class Initialized
INFO - 2023-04-22 16:41:14 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-22 16:41:14 --> Parser Class Initialized
INFO - 2023-04-22 16:41:14 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-22 16:41:14 --> Pagination Class Initialized
INFO - 2023-04-22 16:41:14 --> Form Validation Class Initialized
INFO - 2023-04-22 16:41:14 --> Controller Class Initialized
INFO - 2023-04-22 16:41:14 --> Model Class Initialized
DEBUG - 2023-04-22 16:41:14 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-04-22 16:41:14 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-22 16:41:14 --> Model Class Initialized
INFO - 2023-04-22 16:41:14 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/stockrequest/stockrequest.php
DEBUG - 2023-04-22 16:41:14 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-04-22 16:41:14 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-04-22 16:41:14 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-04-22 16:41:14 --> Model Class Initialized
INFO - 2023-04-22 16:41:14 --> Model Class Initialized
INFO - 2023-04-22 16:41:14 --> Model Class Initialized
INFO - 2023-04-22 16:41:14 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-04-22 16:41:14 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-04-22 16:41:14 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-04-22 16:41:14 --> Final output sent to browser
DEBUG - 2023-04-22 16:41:14 --> Total execution time: 0.1596
ERROR - 2023-04-22 16:41:15 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-22 16:41:15 --> Config Class Initialized
INFO - 2023-04-22 16:41:15 --> Hooks Class Initialized
DEBUG - 2023-04-22 16:41:15 --> UTF-8 Support Enabled
INFO - 2023-04-22 16:41:15 --> Utf8 Class Initialized
INFO - 2023-04-22 16:41:15 --> URI Class Initialized
INFO - 2023-04-22 16:41:15 --> Router Class Initialized
INFO - 2023-04-22 16:41:15 --> Output Class Initialized
INFO - 2023-04-22 16:41:15 --> Security Class Initialized
DEBUG - 2023-04-22 16:41:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-22 16:41:15 --> Input Class Initialized
INFO - 2023-04-22 16:41:15 --> Language Class Initialized
INFO - 2023-04-22 16:41:15 --> Loader Class Initialized
INFO - 2023-04-22 16:41:15 --> Helper loaded: url_helper
INFO - 2023-04-22 16:41:15 --> Helper loaded: file_helper
INFO - 2023-04-22 16:41:15 --> Helper loaded: html_helper
INFO - 2023-04-22 16:41:15 --> Helper loaded: text_helper
INFO - 2023-04-22 16:41:15 --> Helper loaded: form_helper
INFO - 2023-04-22 16:41:15 --> Helper loaded: lang_helper
INFO - 2023-04-22 16:41:15 --> Helper loaded: security_helper
INFO - 2023-04-22 16:41:15 --> Helper loaded: cookie_helper
INFO - 2023-04-22 16:41:15 --> Database Driver Class Initialized
INFO - 2023-04-22 16:41:15 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-22 16:41:15 --> Parser Class Initialized
INFO - 2023-04-22 16:41:15 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-22 16:41:15 --> Pagination Class Initialized
INFO - 2023-04-22 16:41:15 --> Form Validation Class Initialized
INFO - 2023-04-22 16:41:15 --> Controller Class Initialized
INFO - 2023-04-22 16:41:15 --> Model Class Initialized
DEBUG - 2023-04-22 16:41:15 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-04-22 16:41:15 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-22 16:41:15 --> Model Class Initialized
INFO - 2023-04-22 16:41:15 --> Final output sent to browser
DEBUG - 2023-04-22 16:41:15 --> Total execution time: 0.0271
ERROR - 2023-04-22 16:41:25 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-22 16:41:25 --> Config Class Initialized
INFO - 2023-04-22 16:41:25 --> Hooks Class Initialized
DEBUG - 2023-04-22 16:41:25 --> UTF-8 Support Enabled
INFO - 2023-04-22 16:41:25 --> Utf8 Class Initialized
INFO - 2023-04-22 16:41:25 --> URI Class Initialized
INFO - 2023-04-22 16:41:25 --> Router Class Initialized
INFO - 2023-04-22 16:41:25 --> Output Class Initialized
INFO - 2023-04-22 16:41:25 --> Security Class Initialized
DEBUG - 2023-04-22 16:41:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-22 16:41:25 --> Input Class Initialized
INFO - 2023-04-22 16:41:26 --> Language Class Initialized
INFO - 2023-04-22 16:41:26 --> Loader Class Initialized
INFO - 2023-04-22 16:41:26 --> Helper loaded: url_helper
INFO - 2023-04-22 16:41:26 --> Helper loaded: file_helper
INFO - 2023-04-22 16:41:26 --> Helper loaded: html_helper
INFO - 2023-04-22 16:41:26 --> Helper loaded: text_helper
INFO - 2023-04-22 16:41:26 --> Helper loaded: form_helper
INFO - 2023-04-22 16:41:26 --> Helper loaded: lang_helper
INFO - 2023-04-22 16:41:26 --> Helper loaded: security_helper
INFO - 2023-04-22 16:41:26 --> Helper loaded: cookie_helper
INFO - 2023-04-22 16:41:26 --> Database Driver Class Initialized
INFO - 2023-04-22 16:41:26 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-22 16:41:26 --> Parser Class Initialized
INFO - 2023-04-22 16:41:26 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-22 16:41:26 --> Pagination Class Initialized
INFO - 2023-04-22 16:41:26 --> Form Validation Class Initialized
INFO - 2023-04-22 16:41:26 --> Controller Class Initialized
INFO - 2023-04-22 16:41:26 --> Model Class Initialized
DEBUG - 2023-04-22 16:41:26 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-04-22 16:41:26 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-22 16:41:26 --> Model Class Initialized
INFO - 2023-04-22 16:41:26 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/stockrequest/inventory.php
DEBUG - 2023-04-22 16:41:26 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-04-22 16:41:26 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-04-22 16:41:26 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-04-22 16:41:26 --> Model Class Initialized
INFO - 2023-04-22 16:41:26 --> Model Class Initialized
INFO - 2023-04-22 16:41:26 --> Model Class Initialized
INFO - 2023-04-22 16:41:26 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-04-22 16:41:26 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-04-22 16:41:26 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-04-22 16:41:26 --> Final output sent to browser
DEBUG - 2023-04-22 16:41:26 --> Total execution time: 0.1421
ERROR - 2023-04-22 16:41:26 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-22 16:41:26 --> Config Class Initialized
INFO - 2023-04-22 16:41:26 --> Hooks Class Initialized
DEBUG - 2023-04-22 16:41:26 --> UTF-8 Support Enabled
INFO - 2023-04-22 16:41:26 --> Utf8 Class Initialized
INFO - 2023-04-22 16:41:26 --> URI Class Initialized
INFO - 2023-04-22 16:41:26 --> Router Class Initialized
INFO - 2023-04-22 16:41:26 --> Output Class Initialized
INFO - 2023-04-22 16:41:26 --> Security Class Initialized
DEBUG - 2023-04-22 16:41:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-22 16:41:26 --> Input Class Initialized
INFO - 2023-04-22 16:41:26 --> Language Class Initialized
INFO - 2023-04-22 16:41:26 --> Loader Class Initialized
INFO - 2023-04-22 16:41:26 --> Helper loaded: url_helper
INFO - 2023-04-22 16:41:26 --> Helper loaded: file_helper
INFO - 2023-04-22 16:41:26 --> Helper loaded: html_helper
INFO - 2023-04-22 16:41:26 --> Helper loaded: text_helper
INFO - 2023-04-22 16:41:26 --> Helper loaded: form_helper
INFO - 2023-04-22 16:41:26 --> Helper loaded: lang_helper
INFO - 2023-04-22 16:41:26 --> Helper loaded: security_helper
INFO - 2023-04-22 16:41:26 --> Helper loaded: cookie_helper
INFO - 2023-04-22 16:41:26 --> Database Driver Class Initialized
INFO - 2023-04-22 16:41:26 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-22 16:41:26 --> Parser Class Initialized
INFO - 2023-04-22 16:41:26 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-22 16:41:26 --> Pagination Class Initialized
INFO - 2023-04-22 16:41:26 --> Form Validation Class Initialized
INFO - 2023-04-22 16:41:26 --> Controller Class Initialized
INFO - 2023-04-22 16:41:26 --> Model Class Initialized
DEBUG - 2023-04-22 16:41:26 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-04-22 16:41:26 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-22 16:41:26 --> Model Class Initialized
INFO - 2023-04-22 16:41:26 --> Final output sent to browser
DEBUG - 2023-04-22 16:41:26 --> Total execution time: 0.0214
ERROR - 2023-04-22 16:41:36 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-22 16:41:36 --> Config Class Initialized
INFO - 2023-04-22 16:41:36 --> Hooks Class Initialized
DEBUG - 2023-04-22 16:41:36 --> UTF-8 Support Enabled
INFO - 2023-04-22 16:41:36 --> Utf8 Class Initialized
INFO - 2023-04-22 16:41:36 --> URI Class Initialized
INFO - 2023-04-22 16:41:36 --> Router Class Initialized
INFO - 2023-04-22 16:41:36 --> Output Class Initialized
INFO - 2023-04-22 16:41:36 --> Security Class Initialized
DEBUG - 2023-04-22 16:41:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-22 16:41:36 --> Input Class Initialized
INFO - 2023-04-22 16:41:36 --> Language Class Initialized
INFO - 2023-04-22 16:41:36 --> Loader Class Initialized
INFO - 2023-04-22 16:41:36 --> Helper loaded: url_helper
INFO - 2023-04-22 16:41:36 --> Helper loaded: file_helper
INFO - 2023-04-22 16:41:36 --> Helper loaded: html_helper
INFO - 2023-04-22 16:41:36 --> Helper loaded: text_helper
INFO - 2023-04-22 16:41:36 --> Helper loaded: form_helper
INFO - 2023-04-22 16:41:36 --> Helper loaded: lang_helper
INFO - 2023-04-22 16:41:36 --> Helper loaded: security_helper
INFO - 2023-04-22 16:41:36 --> Helper loaded: cookie_helper
INFO - 2023-04-22 16:41:36 --> Database Driver Class Initialized
INFO - 2023-04-22 16:41:36 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-22 16:41:36 --> Parser Class Initialized
INFO - 2023-04-22 16:41:36 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-22 16:41:36 --> Pagination Class Initialized
INFO - 2023-04-22 16:41:36 --> Form Validation Class Initialized
INFO - 2023-04-22 16:41:36 --> Controller Class Initialized
INFO - 2023-04-22 16:41:36 --> Model Class Initialized
DEBUG - 2023-04-22 16:41:36 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-04-22 16:41:36 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-22 16:41:36 --> Model Class Initialized
INFO - 2023-04-22 16:41:36 --> Final output sent to browser
DEBUG - 2023-04-22 16:41:36 --> Total execution time: 0.0194
ERROR - 2023-04-22 16:42:09 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-22 16:42:09 --> Config Class Initialized
INFO - 2023-04-22 16:42:09 --> Hooks Class Initialized
DEBUG - 2023-04-22 16:42:09 --> UTF-8 Support Enabled
INFO - 2023-04-22 16:42:09 --> Utf8 Class Initialized
INFO - 2023-04-22 16:42:09 --> URI Class Initialized
INFO - 2023-04-22 16:42:09 --> Router Class Initialized
INFO - 2023-04-22 16:42:09 --> Output Class Initialized
INFO - 2023-04-22 16:42:09 --> Security Class Initialized
DEBUG - 2023-04-22 16:42:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-22 16:42:09 --> Input Class Initialized
INFO - 2023-04-22 16:42:09 --> Language Class Initialized
INFO - 2023-04-22 16:42:09 --> Loader Class Initialized
INFO - 2023-04-22 16:42:09 --> Helper loaded: url_helper
INFO - 2023-04-22 16:42:09 --> Helper loaded: file_helper
INFO - 2023-04-22 16:42:09 --> Helper loaded: html_helper
INFO - 2023-04-22 16:42:09 --> Helper loaded: text_helper
INFO - 2023-04-22 16:42:09 --> Helper loaded: form_helper
INFO - 2023-04-22 16:42:09 --> Helper loaded: lang_helper
INFO - 2023-04-22 16:42:09 --> Helper loaded: security_helper
INFO - 2023-04-22 16:42:09 --> Helper loaded: cookie_helper
INFO - 2023-04-22 16:42:09 --> Database Driver Class Initialized
INFO - 2023-04-22 16:42:09 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-22 16:42:09 --> Parser Class Initialized
INFO - 2023-04-22 16:42:09 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-22 16:42:09 --> Pagination Class Initialized
INFO - 2023-04-22 16:42:09 --> Form Validation Class Initialized
INFO - 2023-04-22 16:42:09 --> Controller Class Initialized
INFO - 2023-04-22 16:42:09 --> Model Class Initialized
DEBUG - 2023-04-22 16:42:09 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-04-22 16:42:09 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-22 16:42:09 --> Model Class Initialized
DEBUG - 2023-04-22 16:42:09 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-22 16:42:09 --> Model Class Initialized
INFO - 2023-04-22 16:42:09 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/add_invoice_form.php
DEBUG - 2023-04-22 16:42:09 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-04-22 16:42:09 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-04-22 16:42:09 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-04-22 16:42:09 --> Model Class Initialized
INFO - 2023-04-22 16:42:09 --> Model Class Initialized
INFO - 2023-04-22 16:42:09 --> Model Class Initialized
INFO - 2023-04-22 16:42:09 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-04-22 16:42:09 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-04-22 16:42:09 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-04-22 16:42:09 --> Final output sent to browser
DEBUG - 2023-04-22 16:42:09 --> Total execution time: 0.1785
ERROR - 2023-04-22 16:42:20 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-22 16:42:20 --> Config Class Initialized
INFO - 2023-04-22 16:42:20 --> Hooks Class Initialized
DEBUG - 2023-04-22 16:42:20 --> UTF-8 Support Enabled
INFO - 2023-04-22 16:42:20 --> Utf8 Class Initialized
INFO - 2023-04-22 16:42:20 --> URI Class Initialized
INFO - 2023-04-22 16:42:20 --> Router Class Initialized
INFO - 2023-04-22 16:42:20 --> Output Class Initialized
INFO - 2023-04-22 16:42:20 --> Security Class Initialized
DEBUG - 2023-04-22 16:42:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-22 16:42:20 --> Input Class Initialized
INFO - 2023-04-22 16:42:20 --> Language Class Initialized
INFO - 2023-04-22 16:42:20 --> Loader Class Initialized
INFO - 2023-04-22 16:42:20 --> Helper loaded: url_helper
INFO - 2023-04-22 16:42:20 --> Helper loaded: file_helper
INFO - 2023-04-22 16:42:20 --> Helper loaded: html_helper
INFO - 2023-04-22 16:42:20 --> Helper loaded: text_helper
INFO - 2023-04-22 16:42:20 --> Helper loaded: form_helper
INFO - 2023-04-22 16:42:20 --> Helper loaded: lang_helper
INFO - 2023-04-22 16:42:20 --> Helper loaded: security_helper
INFO - 2023-04-22 16:42:20 --> Helper loaded: cookie_helper
INFO - 2023-04-22 16:42:20 --> Database Driver Class Initialized
INFO - 2023-04-22 16:42:20 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-22 16:42:20 --> Parser Class Initialized
INFO - 2023-04-22 16:42:20 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-22 16:42:20 --> Pagination Class Initialized
INFO - 2023-04-22 16:42:20 --> Form Validation Class Initialized
INFO - 2023-04-22 16:42:20 --> Controller Class Initialized
INFO - 2023-04-22 16:42:20 --> Model Class Initialized
DEBUG - 2023-04-22 16:42:20 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-22 16:42:20 --> Final output sent to browser
DEBUG - 2023-04-22 16:42:20 --> Total execution time: 0.0158
ERROR - 2023-04-22 16:42:20 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-22 16:42:20 --> Config Class Initialized
INFO - 2023-04-22 16:42:20 --> Hooks Class Initialized
DEBUG - 2023-04-22 16:42:20 --> UTF-8 Support Enabled
INFO - 2023-04-22 16:42:20 --> Utf8 Class Initialized
INFO - 2023-04-22 16:42:20 --> URI Class Initialized
INFO - 2023-04-22 16:42:20 --> Router Class Initialized
INFO - 2023-04-22 16:42:20 --> Output Class Initialized
INFO - 2023-04-22 16:42:20 --> Security Class Initialized
DEBUG - 2023-04-22 16:42:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-22 16:42:20 --> Input Class Initialized
INFO - 2023-04-22 16:42:20 --> Language Class Initialized
INFO - 2023-04-22 16:42:20 --> Loader Class Initialized
INFO - 2023-04-22 16:42:20 --> Helper loaded: url_helper
INFO - 2023-04-22 16:42:20 --> Helper loaded: file_helper
INFO - 2023-04-22 16:42:20 --> Helper loaded: html_helper
INFO - 2023-04-22 16:42:20 --> Helper loaded: text_helper
INFO - 2023-04-22 16:42:20 --> Helper loaded: form_helper
INFO - 2023-04-22 16:42:20 --> Helper loaded: lang_helper
INFO - 2023-04-22 16:42:20 --> Helper loaded: security_helper
INFO - 2023-04-22 16:42:20 --> Helper loaded: cookie_helper
INFO - 2023-04-22 16:42:20 --> Database Driver Class Initialized
INFO - 2023-04-22 16:42:20 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-22 16:42:20 --> Parser Class Initialized
INFO - 2023-04-22 16:42:20 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-22 16:42:20 --> Pagination Class Initialized
INFO - 2023-04-22 16:42:20 --> Form Validation Class Initialized
INFO - 2023-04-22 16:42:20 --> Controller Class Initialized
INFO - 2023-04-22 16:42:20 --> Model Class Initialized
DEBUG - 2023-04-22 16:42:20 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-22 16:42:20 --> Final output sent to browser
DEBUG - 2023-04-22 16:42:20 --> Total execution time: 0.0147
ERROR - 2023-04-22 16:42:28 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-22 16:42:28 --> Config Class Initialized
INFO - 2023-04-22 16:42:28 --> Hooks Class Initialized
DEBUG - 2023-04-22 16:42:28 --> UTF-8 Support Enabled
INFO - 2023-04-22 16:42:28 --> Utf8 Class Initialized
INFO - 2023-04-22 16:42:28 --> URI Class Initialized
INFO - 2023-04-22 16:42:28 --> Router Class Initialized
INFO - 2023-04-22 16:42:28 --> Output Class Initialized
INFO - 2023-04-22 16:42:28 --> Security Class Initialized
DEBUG - 2023-04-22 16:42:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-22 16:42:28 --> Input Class Initialized
INFO - 2023-04-22 16:42:28 --> Language Class Initialized
INFO - 2023-04-22 16:42:28 --> Loader Class Initialized
INFO - 2023-04-22 16:42:28 --> Helper loaded: url_helper
INFO - 2023-04-22 16:42:28 --> Helper loaded: file_helper
INFO - 2023-04-22 16:42:28 --> Helper loaded: html_helper
INFO - 2023-04-22 16:42:28 --> Helper loaded: text_helper
INFO - 2023-04-22 16:42:28 --> Helper loaded: form_helper
INFO - 2023-04-22 16:42:28 --> Helper loaded: lang_helper
INFO - 2023-04-22 16:42:28 --> Helper loaded: security_helper
INFO - 2023-04-22 16:42:28 --> Helper loaded: cookie_helper
INFO - 2023-04-22 16:42:28 --> Database Driver Class Initialized
INFO - 2023-04-22 16:42:28 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-22 16:42:28 --> Parser Class Initialized
INFO - 2023-04-22 16:42:28 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-22 16:42:28 --> Pagination Class Initialized
INFO - 2023-04-22 16:42:28 --> Form Validation Class Initialized
INFO - 2023-04-22 16:42:28 --> Controller Class Initialized
INFO - 2023-04-22 16:42:28 --> Final output sent to browser
DEBUG - 2023-04-22 16:42:28 --> Total execution time: 0.0137
ERROR - 2023-04-22 16:42:34 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-22 16:42:34 --> Config Class Initialized
INFO - 2023-04-22 16:42:34 --> Hooks Class Initialized
DEBUG - 2023-04-22 16:42:34 --> UTF-8 Support Enabled
INFO - 2023-04-22 16:42:34 --> Utf8 Class Initialized
INFO - 2023-04-22 16:42:34 --> URI Class Initialized
INFO - 2023-04-22 16:42:34 --> Router Class Initialized
INFO - 2023-04-22 16:42:34 --> Output Class Initialized
INFO - 2023-04-22 16:42:34 --> Security Class Initialized
DEBUG - 2023-04-22 16:42:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-22 16:42:34 --> Input Class Initialized
INFO - 2023-04-22 16:42:34 --> Language Class Initialized
INFO - 2023-04-22 16:42:34 --> Loader Class Initialized
INFO - 2023-04-22 16:42:34 --> Helper loaded: url_helper
INFO - 2023-04-22 16:42:34 --> Helper loaded: file_helper
INFO - 2023-04-22 16:42:34 --> Helper loaded: html_helper
INFO - 2023-04-22 16:42:34 --> Helper loaded: text_helper
INFO - 2023-04-22 16:42:34 --> Helper loaded: form_helper
INFO - 2023-04-22 16:42:34 --> Helper loaded: lang_helper
INFO - 2023-04-22 16:42:34 --> Helper loaded: security_helper
INFO - 2023-04-22 16:42:34 --> Helper loaded: cookie_helper
INFO - 2023-04-22 16:42:34 --> Database Driver Class Initialized
INFO - 2023-04-22 16:42:34 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-22 16:42:34 --> Parser Class Initialized
INFO - 2023-04-22 16:42:34 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-22 16:42:34 --> Pagination Class Initialized
INFO - 2023-04-22 16:42:34 --> Form Validation Class Initialized
INFO - 2023-04-22 16:42:34 --> Controller Class Initialized
INFO - 2023-04-22 16:42:34 --> Model Class Initialized
DEBUG - 2023-04-22 16:42:34 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-04-22 16:42:34 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-22 16:42:34 --> Model Class Initialized
DEBUG - 2023-04-22 16:42:34 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-22 16:42:34 --> Model Class Initialized
INFO - 2023-04-22 16:42:34 --> Final output sent to browser
DEBUG - 2023-04-22 16:42:34 --> Total execution time: 0.0246
ERROR - 2023-04-22 16:42:35 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-22 16:42:35 --> Config Class Initialized
INFO - 2023-04-22 16:42:35 --> Hooks Class Initialized
DEBUG - 2023-04-22 16:42:35 --> UTF-8 Support Enabled
INFO - 2023-04-22 16:42:35 --> Utf8 Class Initialized
INFO - 2023-04-22 16:42:35 --> URI Class Initialized
INFO - 2023-04-22 16:42:35 --> Router Class Initialized
INFO - 2023-04-22 16:42:35 --> Output Class Initialized
INFO - 2023-04-22 16:42:35 --> Security Class Initialized
DEBUG - 2023-04-22 16:42:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-22 16:42:35 --> Input Class Initialized
INFO - 2023-04-22 16:42:35 --> Language Class Initialized
INFO - 2023-04-22 16:42:35 --> Loader Class Initialized
INFO - 2023-04-22 16:42:35 --> Helper loaded: url_helper
INFO - 2023-04-22 16:42:35 --> Helper loaded: file_helper
INFO - 2023-04-22 16:42:35 --> Helper loaded: html_helper
INFO - 2023-04-22 16:42:35 --> Helper loaded: text_helper
INFO - 2023-04-22 16:42:35 --> Helper loaded: form_helper
INFO - 2023-04-22 16:42:35 --> Helper loaded: lang_helper
INFO - 2023-04-22 16:42:35 --> Helper loaded: security_helper
INFO - 2023-04-22 16:42:35 --> Helper loaded: cookie_helper
INFO - 2023-04-22 16:42:35 --> Database Driver Class Initialized
INFO - 2023-04-22 16:42:35 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-22 16:42:35 --> Parser Class Initialized
INFO - 2023-04-22 16:42:35 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-22 16:42:35 --> Pagination Class Initialized
INFO - 2023-04-22 16:42:35 --> Form Validation Class Initialized
INFO - 2023-04-22 16:42:35 --> Controller Class Initialized
INFO - 2023-04-22 16:42:35 --> Model Class Initialized
DEBUG - 2023-04-22 16:42:35 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-04-22 16:42:35 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-22 16:42:35 --> Model Class Initialized
DEBUG - 2023-04-22 16:42:35 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-22 16:42:35 --> Model Class Initialized
INFO - 2023-04-22 16:42:35 --> Final output sent to browser
DEBUG - 2023-04-22 16:42:35 --> Total execution time: 0.0244
ERROR - 2023-04-22 16:42:37 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-22 16:42:37 --> Config Class Initialized
INFO - 2023-04-22 16:42:37 --> Hooks Class Initialized
DEBUG - 2023-04-22 16:42:37 --> UTF-8 Support Enabled
INFO - 2023-04-22 16:42:37 --> Utf8 Class Initialized
INFO - 2023-04-22 16:42:37 --> URI Class Initialized
INFO - 2023-04-22 16:42:37 --> Router Class Initialized
INFO - 2023-04-22 16:42:37 --> Output Class Initialized
INFO - 2023-04-22 16:42:37 --> Security Class Initialized
DEBUG - 2023-04-22 16:42:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-22 16:42:37 --> Input Class Initialized
INFO - 2023-04-22 16:42:37 --> Language Class Initialized
INFO - 2023-04-22 16:42:37 --> Loader Class Initialized
INFO - 2023-04-22 16:42:37 --> Helper loaded: url_helper
INFO - 2023-04-22 16:42:37 --> Helper loaded: file_helper
INFO - 2023-04-22 16:42:37 --> Helper loaded: html_helper
INFO - 2023-04-22 16:42:37 --> Helper loaded: text_helper
INFO - 2023-04-22 16:42:37 --> Helper loaded: form_helper
INFO - 2023-04-22 16:42:37 --> Helper loaded: lang_helper
INFO - 2023-04-22 16:42:37 --> Helper loaded: security_helper
INFO - 2023-04-22 16:42:37 --> Helper loaded: cookie_helper
INFO - 2023-04-22 16:42:37 --> Database Driver Class Initialized
INFO - 2023-04-22 16:42:37 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-22 16:42:37 --> Parser Class Initialized
INFO - 2023-04-22 16:42:37 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-22 16:42:37 --> Pagination Class Initialized
INFO - 2023-04-22 16:42:37 --> Form Validation Class Initialized
INFO - 2023-04-22 16:42:37 --> Controller Class Initialized
INFO - 2023-04-22 16:42:37 --> Model Class Initialized
DEBUG - 2023-04-22 16:42:37 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-04-22 16:42:37 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-22 16:42:37 --> Model Class Initialized
DEBUG - 2023-04-22 16:42:37 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-22 16:42:37 --> Model Class Initialized
INFO - 2023-04-22 16:42:37 --> Model Class Initialized
INFO - 2023-04-22 16:42:37 --> Final output sent to browser
DEBUG - 2023-04-22 16:42:37 --> Total execution time: 0.0208
ERROR - 2023-04-22 16:42:41 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-22 16:42:41 --> Config Class Initialized
INFO - 2023-04-22 16:42:41 --> Hooks Class Initialized
DEBUG - 2023-04-22 16:42:41 --> UTF-8 Support Enabled
INFO - 2023-04-22 16:42:41 --> Utf8 Class Initialized
INFO - 2023-04-22 16:42:41 --> URI Class Initialized
INFO - 2023-04-22 16:42:41 --> Router Class Initialized
INFO - 2023-04-22 16:42:41 --> Output Class Initialized
INFO - 2023-04-22 16:42:41 --> Security Class Initialized
DEBUG - 2023-04-22 16:42:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-22 16:42:41 --> Input Class Initialized
INFO - 2023-04-22 16:42:41 --> Language Class Initialized
INFO - 2023-04-22 16:42:41 --> Loader Class Initialized
INFO - 2023-04-22 16:42:41 --> Helper loaded: url_helper
INFO - 2023-04-22 16:42:41 --> Helper loaded: file_helper
INFO - 2023-04-22 16:42:41 --> Helper loaded: html_helper
INFO - 2023-04-22 16:42:41 --> Helper loaded: text_helper
INFO - 2023-04-22 16:42:41 --> Helper loaded: form_helper
INFO - 2023-04-22 16:42:41 --> Helper loaded: lang_helper
INFO - 2023-04-22 16:42:41 --> Helper loaded: security_helper
INFO - 2023-04-22 16:42:41 --> Helper loaded: cookie_helper
INFO - 2023-04-22 16:42:41 --> Database Driver Class Initialized
INFO - 2023-04-22 16:42:41 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-22 16:42:42 --> Parser Class Initialized
INFO - 2023-04-22 16:42:42 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-22 16:42:42 --> Pagination Class Initialized
INFO - 2023-04-22 16:42:42 --> Form Validation Class Initialized
INFO - 2023-04-22 16:42:42 --> Controller Class Initialized
INFO - 2023-04-22 16:42:42 --> Model Class Initialized
DEBUG - 2023-04-22 16:42:42 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-04-22 16:42:42 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-22 16:42:42 --> Model Class Initialized
DEBUG - 2023-04-22 16:42:42 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-22 16:42:42 --> Model Class Initialized
INFO - 2023-04-22 16:42:42 --> Model Class Initialized
DEBUG - 2023-04-22 16:42:42 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-04-22 16:42:42 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-22 16:42:42 --> Final output sent to browser
DEBUG - 2023-04-22 16:42:42 --> Total execution time: 0.0190
ERROR - 2023-04-22 16:42:51 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-22 16:42:51 --> Config Class Initialized
INFO - 2023-04-22 16:42:51 --> Hooks Class Initialized
DEBUG - 2023-04-22 16:42:51 --> UTF-8 Support Enabled
INFO - 2023-04-22 16:42:51 --> Utf8 Class Initialized
INFO - 2023-04-22 16:42:51 --> URI Class Initialized
INFO - 2023-04-22 16:42:51 --> Router Class Initialized
INFO - 2023-04-22 16:42:51 --> Output Class Initialized
INFO - 2023-04-22 16:42:51 --> Security Class Initialized
DEBUG - 2023-04-22 16:42:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-22 16:42:51 --> Input Class Initialized
INFO - 2023-04-22 16:42:51 --> Language Class Initialized
INFO - 2023-04-22 16:42:51 --> Loader Class Initialized
INFO - 2023-04-22 16:42:51 --> Helper loaded: url_helper
INFO - 2023-04-22 16:42:51 --> Helper loaded: file_helper
INFO - 2023-04-22 16:42:51 --> Helper loaded: html_helper
INFO - 2023-04-22 16:42:51 --> Helper loaded: text_helper
INFO - 2023-04-22 16:42:51 --> Helper loaded: form_helper
INFO - 2023-04-22 16:42:51 --> Helper loaded: lang_helper
INFO - 2023-04-22 16:42:51 --> Helper loaded: security_helper
INFO - 2023-04-22 16:42:51 --> Helper loaded: cookie_helper
INFO - 2023-04-22 16:42:51 --> Database Driver Class Initialized
INFO - 2023-04-22 16:42:51 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-22 16:42:51 --> Parser Class Initialized
INFO - 2023-04-22 16:42:51 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-22 16:42:51 --> Pagination Class Initialized
INFO - 2023-04-22 16:42:51 --> Form Validation Class Initialized
INFO - 2023-04-22 16:42:51 --> Controller Class Initialized
INFO - 2023-04-22 16:42:51 --> Model Class Initialized
DEBUG - 2023-04-22 16:42:51 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-04-22 16:42:51 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-22 16:42:51 --> Model Class Initialized
DEBUG - 2023-04-22 16:42:51 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-22 16:42:51 --> Model Class Initialized
INFO - 2023-04-22 16:42:51 --> Final output sent to browser
DEBUG - 2023-04-22 16:42:51 --> Total execution time: 0.0254
ERROR - 2023-04-22 16:42:51 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-22 16:42:51 --> Config Class Initialized
INFO - 2023-04-22 16:42:51 --> Hooks Class Initialized
DEBUG - 2023-04-22 16:42:51 --> UTF-8 Support Enabled
INFO - 2023-04-22 16:42:51 --> Utf8 Class Initialized
INFO - 2023-04-22 16:42:51 --> URI Class Initialized
INFO - 2023-04-22 16:42:51 --> Router Class Initialized
INFO - 2023-04-22 16:42:51 --> Output Class Initialized
INFO - 2023-04-22 16:42:51 --> Security Class Initialized
DEBUG - 2023-04-22 16:42:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-22 16:42:51 --> Input Class Initialized
INFO - 2023-04-22 16:42:51 --> Language Class Initialized
INFO - 2023-04-22 16:42:51 --> Loader Class Initialized
INFO - 2023-04-22 16:42:51 --> Helper loaded: url_helper
INFO - 2023-04-22 16:42:51 --> Helper loaded: file_helper
INFO - 2023-04-22 16:42:51 --> Helper loaded: html_helper
INFO - 2023-04-22 16:42:51 --> Helper loaded: text_helper
INFO - 2023-04-22 16:42:51 --> Helper loaded: form_helper
INFO - 2023-04-22 16:42:51 --> Helper loaded: lang_helper
INFO - 2023-04-22 16:42:51 --> Helper loaded: security_helper
INFO - 2023-04-22 16:42:51 --> Helper loaded: cookie_helper
INFO - 2023-04-22 16:42:51 --> Database Driver Class Initialized
INFO - 2023-04-22 16:42:51 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-22 16:42:51 --> Parser Class Initialized
INFO - 2023-04-22 16:42:51 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-22 16:42:51 --> Pagination Class Initialized
INFO - 2023-04-22 16:42:51 --> Form Validation Class Initialized
INFO - 2023-04-22 16:42:51 --> Controller Class Initialized
INFO - 2023-04-22 16:42:51 --> Model Class Initialized
DEBUG - 2023-04-22 16:42:51 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-04-22 16:42:51 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-22 16:42:51 --> Model Class Initialized
DEBUG - 2023-04-22 16:42:51 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-22 16:42:51 --> Model Class Initialized
INFO - 2023-04-22 16:42:51 --> Final output sent to browser
DEBUG - 2023-04-22 16:42:51 --> Total execution time: 0.0271
ERROR - 2023-04-22 16:42:51 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-22 16:42:51 --> Config Class Initialized
INFO - 2023-04-22 16:42:51 --> Hooks Class Initialized
DEBUG - 2023-04-22 16:42:51 --> UTF-8 Support Enabled
INFO - 2023-04-22 16:42:51 --> Utf8 Class Initialized
INFO - 2023-04-22 16:42:51 --> URI Class Initialized
INFO - 2023-04-22 16:42:51 --> Router Class Initialized
INFO - 2023-04-22 16:42:51 --> Output Class Initialized
INFO - 2023-04-22 16:42:51 --> Security Class Initialized
DEBUG - 2023-04-22 16:42:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-22 16:42:51 --> Input Class Initialized
INFO - 2023-04-22 16:42:51 --> Language Class Initialized
INFO - 2023-04-22 16:42:51 --> Loader Class Initialized
INFO - 2023-04-22 16:42:51 --> Helper loaded: url_helper
INFO - 2023-04-22 16:42:51 --> Helper loaded: file_helper
INFO - 2023-04-22 16:42:51 --> Helper loaded: html_helper
INFO - 2023-04-22 16:42:51 --> Helper loaded: text_helper
INFO - 2023-04-22 16:42:51 --> Helper loaded: form_helper
INFO - 2023-04-22 16:42:51 --> Helper loaded: lang_helper
INFO - 2023-04-22 16:42:51 --> Helper loaded: security_helper
INFO - 2023-04-22 16:42:51 --> Helper loaded: cookie_helper
INFO - 2023-04-22 16:42:51 --> Database Driver Class Initialized
INFO - 2023-04-22 16:42:51 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-22 16:42:51 --> Parser Class Initialized
INFO - 2023-04-22 16:42:51 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-22 16:42:51 --> Pagination Class Initialized
INFO - 2023-04-22 16:42:51 --> Form Validation Class Initialized
INFO - 2023-04-22 16:42:51 --> Controller Class Initialized
INFO - 2023-04-22 16:42:51 --> Model Class Initialized
DEBUG - 2023-04-22 16:42:51 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-04-22 16:42:51 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-22 16:42:51 --> Model Class Initialized
DEBUG - 2023-04-22 16:42:51 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-22 16:42:51 --> Model Class Initialized
INFO - 2023-04-22 16:42:51 --> Final output sent to browser
DEBUG - 2023-04-22 16:42:51 --> Total execution time: 0.0246
ERROR - 2023-04-22 16:42:52 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-22 16:42:52 --> Config Class Initialized
INFO - 2023-04-22 16:42:52 --> Hooks Class Initialized
DEBUG - 2023-04-22 16:42:52 --> UTF-8 Support Enabled
INFO - 2023-04-22 16:42:52 --> Utf8 Class Initialized
INFO - 2023-04-22 16:42:52 --> URI Class Initialized
INFO - 2023-04-22 16:42:52 --> Router Class Initialized
INFO - 2023-04-22 16:42:52 --> Output Class Initialized
INFO - 2023-04-22 16:42:52 --> Security Class Initialized
DEBUG - 2023-04-22 16:42:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-22 16:42:52 --> Input Class Initialized
INFO - 2023-04-22 16:42:52 --> Language Class Initialized
INFO - 2023-04-22 16:42:52 --> Loader Class Initialized
INFO - 2023-04-22 16:42:52 --> Helper loaded: url_helper
INFO - 2023-04-22 16:42:52 --> Helper loaded: file_helper
INFO - 2023-04-22 16:42:52 --> Helper loaded: html_helper
INFO - 2023-04-22 16:42:52 --> Helper loaded: text_helper
INFO - 2023-04-22 16:42:52 --> Helper loaded: form_helper
INFO - 2023-04-22 16:42:52 --> Helper loaded: lang_helper
INFO - 2023-04-22 16:42:52 --> Helper loaded: security_helper
INFO - 2023-04-22 16:42:52 --> Helper loaded: cookie_helper
INFO - 2023-04-22 16:42:52 --> Database Driver Class Initialized
INFO - 2023-04-22 16:42:52 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-22 16:42:52 --> Parser Class Initialized
INFO - 2023-04-22 16:42:52 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-22 16:42:52 --> Pagination Class Initialized
INFO - 2023-04-22 16:42:52 --> Form Validation Class Initialized
INFO - 2023-04-22 16:42:52 --> Controller Class Initialized
INFO - 2023-04-22 16:42:52 --> Model Class Initialized
DEBUG - 2023-04-22 16:42:52 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-04-22 16:42:52 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-22 16:42:52 --> Model Class Initialized
DEBUG - 2023-04-22 16:42:52 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-22 16:42:52 --> Model Class Initialized
INFO - 2023-04-22 16:42:52 --> Final output sent to browser
DEBUG - 2023-04-22 16:42:52 --> Total execution time: 0.0238
ERROR - 2023-04-22 16:42:55 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-22 16:42:55 --> Config Class Initialized
INFO - 2023-04-22 16:42:55 --> Hooks Class Initialized
DEBUG - 2023-04-22 16:42:55 --> UTF-8 Support Enabled
INFO - 2023-04-22 16:42:55 --> Utf8 Class Initialized
INFO - 2023-04-22 16:42:55 --> URI Class Initialized
INFO - 2023-04-22 16:42:55 --> Router Class Initialized
INFO - 2023-04-22 16:42:55 --> Output Class Initialized
INFO - 2023-04-22 16:42:55 --> Security Class Initialized
DEBUG - 2023-04-22 16:42:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-22 16:42:55 --> Input Class Initialized
INFO - 2023-04-22 16:42:55 --> Language Class Initialized
INFO - 2023-04-22 16:42:55 --> Loader Class Initialized
INFO - 2023-04-22 16:42:55 --> Helper loaded: url_helper
INFO - 2023-04-22 16:42:55 --> Helper loaded: file_helper
INFO - 2023-04-22 16:42:55 --> Helper loaded: html_helper
INFO - 2023-04-22 16:42:55 --> Helper loaded: text_helper
INFO - 2023-04-22 16:42:55 --> Helper loaded: form_helper
INFO - 2023-04-22 16:42:55 --> Helper loaded: lang_helper
INFO - 2023-04-22 16:42:55 --> Helper loaded: security_helper
INFO - 2023-04-22 16:42:55 --> Helper loaded: cookie_helper
INFO - 2023-04-22 16:42:55 --> Database Driver Class Initialized
INFO - 2023-04-22 16:42:55 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-22 16:42:55 --> Parser Class Initialized
INFO - 2023-04-22 16:42:55 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-22 16:42:55 --> Pagination Class Initialized
INFO - 2023-04-22 16:42:55 --> Form Validation Class Initialized
INFO - 2023-04-22 16:42:55 --> Controller Class Initialized
INFO - 2023-04-22 16:42:55 --> Model Class Initialized
DEBUG - 2023-04-22 16:42:55 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-04-22 16:42:55 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-22 16:42:55 --> Model Class Initialized
DEBUG - 2023-04-22 16:42:55 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-22 16:42:55 --> Model Class Initialized
INFO - 2023-04-22 16:42:55 --> Model Class Initialized
INFO - 2023-04-22 16:42:55 --> Final output sent to browser
DEBUG - 2023-04-22 16:42:55 --> Total execution time: 0.0196
ERROR - 2023-04-22 16:42:58 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-22 16:42:58 --> Config Class Initialized
INFO - 2023-04-22 16:42:58 --> Hooks Class Initialized
DEBUG - 2023-04-22 16:42:58 --> UTF-8 Support Enabled
INFO - 2023-04-22 16:42:58 --> Utf8 Class Initialized
INFO - 2023-04-22 16:42:58 --> URI Class Initialized
INFO - 2023-04-22 16:42:58 --> Router Class Initialized
INFO - 2023-04-22 16:42:58 --> Output Class Initialized
INFO - 2023-04-22 16:42:58 --> Security Class Initialized
DEBUG - 2023-04-22 16:42:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-22 16:42:58 --> Input Class Initialized
INFO - 2023-04-22 16:42:58 --> Language Class Initialized
INFO - 2023-04-22 16:42:58 --> Loader Class Initialized
INFO - 2023-04-22 16:42:58 --> Helper loaded: url_helper
INFO - 2023-04-22 16:42:58 --> Helper loaded: file_helper
INFO - 2023-04-22 16:42:58 --> Helper loaded: html_helper
INFO - 2023-04-22 16:42:58 --> Helper loaded: text_helper
INFO - 2023-04-22 16:42:58 --> Helper loaded: form_helper
INFO - 2023-04-22 16:42:58 --> Helper loaded: lang_helper
INFO - 2023-04-22 16:42:58 --> Helper loaded: security_helper
INFO - 2023-04-22 16:42:58 --> Helper loaded: cookie_helper
INFO - 2023-04-22 16:42:58 --> Database Driver Class Initialized
INFO - 2023-04-22 16:42:58 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-22 16:42:58 --> Parser Class Initialized
INFO - 2023-04-22 16:42:58 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-22 16:42:58 --> Pagination Class Initialized
INFO - 2023-04-22 16:42:58 --> Form Validation Class Initialized
INFO - 2023-04-22 16:42:58 --> Controller Class Initialized
INFO - 2023-04-22 16:42:58 --> Model Class Initialized
DEBUG - 2023-04-22 16:42:58 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-04-22 16:42:58 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-22 16:42:58 --> Model Class Initialized
DEBUG - 2023-04-22 16:42:58 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-22 16:42:58 --> Model Class Initialized
INFO - 2023-04-22 16:42:58 --> Model Class Initialized
DEBUG - 2023-04-22 16:42:58 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-04-22 16:42:58 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-22 16:42:58 --> Final output sent to browser
DEBUG - 2023-04-22 16:42:58 --> Total execution time: 0.0196
ERROR - 2023-04-22 16:43:40 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-22 16:43:40 --> Config Class Initialized
INFO - 2023-04-22 16:43:40 --> Hooks Class Initialized
DEBUG - 2023-04-22 16:43:40 --> UTF-8 Support Enabled
INFO - 2023-04-22 16:43:40 --> Utf8 Class Initialized
INFO - 2023-04-22 16:43:40 --> URI Class Initialized
INFO - 2023-04-22 16:43:40 --> Router Class Initialized
INFO - 2023-04-22 16:43:40 --> Output Class Initialized
INFO - 2023-04-22 16:43:40 --> Security Class Initialized
DEBUG - 2023-04-22 16:43:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-22 16:43:40 --> Input Class Initialized
INFO - 2023-04-22 16:43:40 --> Language Class Initialized
INFO - 2023-04-22 16:43:40 --> Loader Class Initialized
INFO - 2023-04-22 16:43:40 --> Helper loaded: url_helper
INFO - 2023-04-22 16:43:40 --> Helper loaded: file_helper
INFO - 2023-04-22 16:43:40 --> Helper loaded: html_helper
INFO - 2023-04-22 16:43:40 --> Helper loaded: text_helper
INFO - 2023-04-22 16:43:40 --> Helper loaded: form_helper
INFO - 2023-04-22 16:43:40 --> Helper loaded: lang_helper
INFO - 2023-04-22 16:43:40 --> Helper loaded: security_helper
INFO - 2023-04-22 16:43:40 --> Helper loaded: cookie_helper
INFO - 2023-04-22 16:43:40 --> Database Driver Class Initialized
INFO - 2023-04-22 16:43:40 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-22 16:43:40 --> Parser Class Initialized
INFO - 2023-04-22 16:43:40 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-22 16:43:40 --> Pagination Class Initialized
INFO - 2023-04-22 16:43:40 --> Form Validation Class Initialized
INFO - 2023-04-22 16:43:40 --> Controller Class Initialized
INFO - 2023-04-22 16:43:40 --> Model Class Initialized
DEBUG - 2023-04-22 16:43:40 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-04-22 16:43:40 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-22 16:43:40 --> Model Class Initialized
DEBUG - 2023-04-22 16:43:40 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-22 16:43:40 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/stockrequest/add_stockrequest_form.php
DEBUG - 2023-04-22 16:43:40 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-04-22 16:43:40 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-04-22 16:43:40 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-04-22 16:43:40 --> Model Class Initialized
INFO - 2023-04-22 16:43:40 --> Model Class Initialized
INFO - 2023-04-22 16:43:40 --> Model Class Initialized
INFO - 2023-04-22 16:43:40 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-04-22 16:43:40 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-04-22 16:43:40 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-04-22 16:43:40 --> Final output sent to browser
DEBUG - 2023-04-22 16:43:40 --> Total execution time: 0.1555
ERROR - 2023-04-22 16:43:52 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-22 16:43:52 --> Config Class Initialized
INFO - 2023-04-22 16:43:52 --> Hooks Class Initialized
DEBUG - 2023-04-22 16:43:52 --> UTF-8 Support Enabled
INFO - 2023-04-22 16:43:52 --> Utf8 Class Initialized
INFO - 2023-04-22 16:43:52 --> URI Class Initialized
INFO - 2023-04-22 16:43:52 --> Router Class Initialized
INFO - 2023-04-22 16:43:52 --> Output Class Initialized
INFO - 2023-04-22 16:43:52 --> Security Class Initialized
DEBUG - 2023-04-22 16:43:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-22 16:43:52 --> Input Class Initialized
INFO - 2023-04-22 16:43:52 --> Language Class Initialized
INFO - 2023-04-22 16:43:52 --> Loader Class Initialized
INFO - 2023-04-22 16:43:52 --> Helper loaded: url_helper
INFO - 2023-04-22 16:43:52 --> Helper loaded: file_helper
INFO - 2023-04-22 16:43:52 --> Helper loaded: html_helper
INFO - 2023-04-22 16:43:52 --> Helper loaded: text_helper
INFO - 2023-04-22 16:43:52 --> Helper loaded: form_helper
INFO - 2023-04-22 16:43:52 --> Helper loaded: lang_helper
INFO - 2023-04-22 16:43:52 --> Helper loaded: security_helper
INFO - 2023-04-22 16:43:52 --> Helper loaded: cookie_helper
INFO - 2023-04-22 16:43:53 --> Database Driver Class Initialized
INFO - 2023-04-22 16:43:53 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-22 16:43:53 --> Parser Class Initialized
INFO - 2023-04-22 16:43:53 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-22 16:43:53 --> Pagination Class Initialized
INFO - 2023-04-22 16:43:53 --> Form Validation Class Initialized
INFO - 2023-04-22 16:43:53 --> Controller Class Initialized
INFO - 2023-04-22 16:43:53 --> Model Class Initialized
DEBUG - 2023-04-22 16:43:53 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-04-22 16:43:53 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-22 16:43:53 --> Model Class Initialized
INFO - 2023-04-22 16:43:53 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/stockrequest/inventory.php
DEBUG - 2023-04-22 16:43:53 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-04-22 16:43:53 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-04-22 16:43:53 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-04-22 16:43:53 --> Model Class Initialized
INFO - 2023-04-22 16:43:53 --> Model Class Initialized
INFO - 2023-04-22 16:43:53 --> Model Class Initialized
INFO - 2023-04-22 16:43:53 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-04-22 16:43:53 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-04-22 16:43:53 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-04-22 16:43:53 --> Final output sent to browser
DEBUG - 2023-04-22 16:43:53 --> Total execution time: 0.1481
ERROR - 2023-04-22 16:43:53 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-22 16:43:53 --> Config Class Initialized
INFO - 2023-04-22 16:43:53 --> Hooks Class Initialized
DEBUG - 2023-04-22 16:43:53 --> UTF-8 Support Enabled
INFO - 2023-04-22 16:43:53 --> Utf8 Class Initialized
INFO - 2023-04-22 16:43:53 --> URI Class Initialized
INFO - 2023-04-22 16:43:53 --> Router Class Initialized
INFO - 2023-04-22 16:43:53 --> Output Class Initialized
INFO - 2023-04-22 16:43:53 --> Security Class Initialized
DEBUG - 2023-04-22 16:43:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-22 16:43:53 --> Input Class Initialized
INFO - 2023-04-22 16:43:53 --> Language Class Initialized
INFO - 2023-04-22 16:43:53 --> Loader Class Initialized
INFO - 2023-04-22 16:43:53 --> Helper loaded: url_helper
INFO - 2023-04-22 16:43:53 --> Helper loaded: file_helper
INFO - 2023-04-22 16:43:53 --> Helper loaded: html_helper
INFO - 2023-04-22 16:43:53 --> Helper loaded: text_helper
INFO - 2023-04-22 16:43:53 --> Helper loaded: form_helper
INFO - 2023-04-22 16:43:53 --> Helper loaded: lang_helper
INFO - 2023-04-22 16:43:53 --> Helper loaded: security_helper
INFO - 2023-04-22 16:43:53 --> Helper loaded: cookie_helper
INFO - 2023-04-22 16:43:53 --> Database Driver Class Initialized
INFO - 2023-04-22 16:43:53 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-22 16:43:53 --> Parser Class Initialized
INFO - 2023-04-22 16:43:53 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-22 16:43:53 --> Pagination Class Initialized
INFO - 2023-04-22 16:43:53 --> Form Validation Class Initialized
INFO - 2023-04-22 16:43:53 --> Controller Class Initialized
INFO - 2023-04-22 16:43:53 --> Model Class Initialized
DEBUG - 2023-04-22 16:43:53 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-04-22 16:43:53 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-22 16:43:53 --> Model Class Initialized
INFO - 2023-04-22 16:43:53 --> Final output sent to browser
DEBUG - 2023-04-22 16:43:53 --> Total execution time: 0.0192
ERROR - 2023-04-22 16:43:57 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-22 16:43:57 --> Config Class Initialized
INFO - 2023-04-22 16:43:57 --> Hooks Class Initialized
DEBUG - 2023-04-22 16:43:57 --> UTF-8 Support Enabled
INFO - 2023-04-22 16:43:57 --> Utf8 Class Initialized
INFO - 2023-04-22 16:43:57 --> URI Class Initialized
INFO - 2023-04-22 16:43:57 --> Router Class Initialized
INFO - 2023-04-22 16:43:57 --> Output Class Initialized
INFO - 2023-04-22 16:43:57 --> Security Class Initialized
DEBUG - 2023-04-22 16:43:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-22 16:43:57 --> Input Class Initialized
INFO - 2023-04-22 16:43:57 --> Language Class Initialized
INFO - 2023-04-22 16:43:57 --> Loader Class Initialized
INFO - 2023-04-22 16:43:57 --> Helper loaded: url_helper
INFO - 2023-04-22 16:43:57 --> Helper loaded: file_helper
INFO - 2023-04-22 16:43:57 --> Helper loaded: html_helper
INFO - 2023-04-22 16:43:57 --> Helper loaded: text_helper
INFO - 2023-04-22 16:43:57 --> Helper loaded: form_helper
INFO - 2023-04-22 16:43:57 --> Helper loaded: lang_helper
INFO - 2023-04-22 16:43:57 --> Helper loaded: security_helper
INFO - 2023-04-22 16:43:57 --> Helper loaded: cookie_helper
INFO - 2023-04-22 16:43:57 --> Database Driver Class Initialized
INFO - 2023-04-22 16:43:57 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-22 16:43:57 --> Parser Class Initialized
INFO - 2023-04-22 16:43:57 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-22 16:43:57 --> Pagination Class Initialized
INFO - 2023-04-22 16:43:57 --> Form Validation Class Initialized
INFO - 2023-04-22 16:43:57 --> Controller Class Initialized
INFO - 2023-04-22 16:43:57 --> Model Class Initialized
DEBUG - 2023-04-22 16:43:57 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-04-22 16:43:57 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-22 16:43:57 --> Model Class Initialized
INFO - 2023-04-22 16:43:57 --> Final output sent to browser
DEBUG - 2023-04-22 16:43:57 --> Total execution time: 0.0192
ERROR - 2023-04-22 16:44:07 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-22 16:44:07 --> Config Class Initialized
INFO - 2023-04-22 16:44:07 --> Hooks Class Initialized
DEBUG - 2023-04-22 16:44:07 --> UTF-8 Support Enabled
INFO - 2023-04-22 16:44:07 --> Utf8 Class Initialized
INFO - 2023-04-22 16:44:07 --> URI Class Initialized
INFO - 2023-04-22 16:44:07 --> Router Class Initialized
INFO - 2023-04-22 16:44:07 --> Output Class Initialized
INFO - 2023-04-22 16:44:07 --> Security Class Initialized
DEBUG - 2023-04-22 16:44:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-22 16:44:07 --> Input Class Initialized
INFO - 2023-04-22 16:44:07 --> Language Class Initialized
INFO - 2023-04-22 16:44:07 --> Loader Class Initialized
INFO - 2023-04-22 16:44:07 --> Helper loaded: url_helper
INFO - 2023-04-22 16:44:07 --> Helper loaded: file_helper
INFO - 2023-04-22 16:44:07 --> Helper loaded: html_helper
INFO - 2023-04-22 16:44:07 --> Helper loaded: text_helper
INFO - 2023-04-22 16:44:07 --> Helper loaded: form_helper
INFO - 2023-04-22 16:44:07 --> Helper loaded: lang_helper
INFO - 2023-04-22 16:44:07 --> Helper loaded: security_helper
INFO - 2023-04-22 16:44:07 --> Helper loaded: cookie_helper
INFO - 2023-04-22 16:44:07 --> Database Driver Class Initialized
INFO - 2023-04-22 16:44:07 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-22 16:44:07 --> Parser Class Initialized
INFO - 2023-04-22 16:44:07 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-22 16:44:07 --> Pagination Class Initialized
INFO - 2023-04-22 16:44:07 --> Form Validation Class Initialized
INFO - 2023-04-22 16:44:07 --> Controller Class Initialized
INFO - 2023-04-22 16:44:07 --> Model Class Initialized
DEBUG - 2023-04-22 16:44:07 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-04-22 16:44:07 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-22 16:44:07 --> Model Class Initialized
INFO - 2023-04-22 16:44:07 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/stockrequest/stockrequest.php
DEBUG - 2023-04-22 16:44:07 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-04-22 16:44:07 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-04-22 16:44:07 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-04-22 16:44:07 --> Model Class Initialized
INFO - 2023-04-22 16:44:07 --> Model Class Initialized
INFO - 2023-04-22 16:44:07 --> Model Class Initialized
INFO - 2023-04-22 16:44:07 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-04-22 16:44:07 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-04-22 16:44:07 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-04-22 16:44:07 --> Final output sent to browser
DEBUG - 2023-04-22 16:44:07 --> Total execution time: 0.1516
ERROR - 2023-04-22 16:44:07 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-22 16:44:07 --> Config Class Initialized
INFO - 2023-04-22 16:44:07 --> Hooks Class Initialized
DEBUG - 2023-04-22 16:44:07 --> UTF-8 Support Enabled
INFO - 2023-04-22 16:44:07 --> Utf8 Class Initialized
INFO - 2023-04-22 16:44:07 --> URI Class Initialized
INFO - 2023-04-22 16:44:07 --> Router Class Initialized
INFO - 2023-04-22 16:44:07 --> Output Class Initialized
INFO - 2023-04-22 16:44:07 --> Security Class Initialized
DEBUG - 2023-04-22 16:44:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-22 16:44:07 --> Input Class Initialized
INFO - 2023-04-22 16:44:07 --> Language Class Initialized
INFO - 2023-04-22 16:44:07 --> Loader Class Initialized
INFO - 2023-04-22 16:44:07 --> Helper loaded: url_helper
INFO - 2023-04-22 16:44:07 --> Helper loaded: file_helper
INFO - 2023-04-22 16:44:07 --> Helper loaded: html_helper
INFO - 2023-04-22 16:44:07 --> Helper loaded: text_helper
INFO - 2023-04-22 16:44:07 --> Helper loaded: form_helper
INFO - 2023-04-22 16:44:07 --> Helper loaded: lang_helper
INFO - 2023-04-22 16:44:07 --> Helper loaded: security_helper
INFO - 2023-04-22 16:44:07 --> Helper loaded: cookie_helper
INFO - 2023-04-22 16:44:07 --> Database Driver Class Initialized
INFO - 2023-04-22 16:44:07 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-22 16:44:07 --> Parser Class Initialized
INFO - 2023-04-22 16:44:07 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-22 16:44:07 --> Pagination Class Initialized
INFO - 2023-04-22 16:44:07 --> Form Validation Class Initialized
INFO - 2023-04-22 16:44:07 --> Controller Class Initialized
INFO - 2023-04-22 16:44:07 --> Model Class Initialized
DEBUG - 2023-04-22 16:44:07 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-04-22 16:44:07 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-22 16:44:07 --> Model Class Initialized
INFO - 2023-04-22 16:44:07 --> Final output sent to browser
DEBUG - 2023-04-22 16:44:07 --> Total execution time: 0.0280
ERROR - 2023-04-22 16:44:33 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-22 16:44:33 --> Config Class Initialized
INFO - 2023-04-22 16:44:33 --> Hooks Class Initialized
DEBUG - 2023-04-22 16:44:33 --> UTF-8 Support Enabled
INFO - 2023-04-22 16:44:33 --> Utf8 Class Initialized
INFO - 2023-04-22 16:44:33 --> URI Class Initialized
DEBUG - 2023-04-22 16:44:33 --> No URI present. Default controller set.
INFO - 2023-04-22 16:44:33 --> Router Class Initialized
INFO - 2023-04-22 16:44:33 --> Output Class Initialized
INFO - 2023-04-22 16:44:33 --> Security Class Initialized
DEBUG - 2023-04-22 16:44:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-22 16:44:33 --> Input Class Initialized
INFO - 2023-04-22 16:44:33 --> Language Class Initialized
INFO - 2023-04-22 16:44:33 --> Loader Class Initialized
INFO - 2023-04-22 16:44:33 --> Helper loaded: url_helper
INFO - 2023-04-22 16:44:33 --> Helper loaded: file_helper
INFO - 2023-04-22 16:44:33 --> Helper loaded: html_helper
INFO - 2023-04-22 16:44:33 --> Helper loaded: text_helper
INFO - 2023-04-22 16:44:33 --> Helper loaded: form_helper
INFO - 2023-04-22 16:44:33 --> Helper loaded: lang_helper
INFO - 2023-04-22 16:44:33 --> Helper loaded: security_helper
INFO - 2023-04-22 16:44:33 --> Helper loaded: cookie_helper
INFO - 2023-04-22 16:44:33 --> Database Driver Class Initialized
INFO - 2023-04-22 16:44:33 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-22 16:44:33 --> Parser Class Initialized
INFO - 2023-04-22 16:44:33 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-22 16:44:33 --> Pagination Class Initialized
INFO - 2023-04-22 16:44:33 --> Form Validation Class Initialized
INFO - 2023-04-22 16:44:33 --> Controller Class Initialized
INFO - 2023-04-22 16:44:33 --> Model Class Initialized
DEBUG - 2023-04-22 16:44:33 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-22 16:44:33 --> Model Class Initialized
DEBUG - 2023-04-22 16:44:33 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-22 16:44:33 --> Model Class Initialized
INFO - 2023-04-22 16:44:33 --> Model Class Initialized
INFO - 2023-04-22 16:44:33 --> Model Class Initialized
INFO - 2023-04-22 16:44:33 --> Model Class Initialized
DEBUG - 2023-04-22 16:44:33 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-04-22 16:44:33 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-22 16:44:33 --> Model Class Initialized
INFO - 2023-04-22 16:44:33 --> Model Class Initialized
INFO - 2023-04-22 16:44:34 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-04-22 16:44:34 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-04-22 16:44:34 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-04-22 16:44:34 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-04-22 16:44:34 --> Model Class Initialized
INFO - 2023-04-22 16:44:34 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-04-22 16:44:34 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-04-22 16:44:34 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-04-22 16:44:34 --> Final output sent to browser
DEBUG - 2023-04-22 16:44:34 --> Total execution time: 0.1784
ERROR - 2023-04-22 16:44:44 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-22 16:44:44 --> Config Class Initialized
INFO - 2023-04-22 16:44:44 --> Hooks Class Initialized
DEBUG - 2023-04-22 16:44:44 --> UTF-8 Support Enabled
INFO - 2023-04-22 16:44:44 --> Utf8 Class Initialized
INFO - 2023-04-22 16:44:44 --> URI Class Initialized
INFO - 2023-04-22 16:44:44 --> Router Class Initialized
INFO - 2023-04-22 16:44:44 --> Output Class Initialized
INFO - 2023-04-22 16:44:44 --> Security Class Initialized
DEBUG - 2023-04-22 16:44:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-22 16:44:44 --> Input Class Initialized
INFO - 2023-04-22 16:44:44 --> Language Class Initialized
INFO - 2023-04-22 16:44:44 --> Loader Class Initialized
INFO - 2023-04-22 16:44:44 --> Helper loaded: url_helper
INFO - 2023-04-22 16:44:44 --> Helper loaded: file_helper
INFO - 2023-04-22 16:44:44 --> Helper loaded: html_helper
INFO - 2023-04-22 16:44:44 --> Helper loaded: text_helper
INFO - 2023-04-22 16:44:44 --> Helper loaded: form_helper
INFO - 2023-04-22 16:44:44 --> Helper loaded: lang_helper
INFO - 2023-04-22 16:44:44 --> Helper loaded: security_helper
INFO - 2023-04-22 16:44:44 --> Helper loaded: cookie_helper
INFO - 2023-04-22 16:44:44 --> Database Driver Class Initialized
INFO - 2023-04-22 16:44:44 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-22 16:44:44 --> Parser Class Initialized
INFO - 2023-04-22 16:44:44 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-22 16:44:44 --> Pagination Class Initialized
INFO - 2023-04-22 16:44:44 --> Form Validation Class Initialized
INFO - 2023-04-22 16:44:44 --> Controller Class Initialized
INFO - 2023-04-22 16:44:44 --> Model Class Initialized
DEBUG - 2023-04-22 16:44:44 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-04-22 16:44:44 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-22 16:44:44 --> Model Class Initialized
DEBUG - 2023-04-22 16:44:44 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-22 16:44:44 --> Model Class Initialized
INFO - 2023-04-22 16:44:44 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice.php
DEBUG - 2023-04-22 16:44:44 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-04-22 16:44:44 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-04-22 16:44:44 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-04-22 16:44:44 --> Model Class Initialized
INFO - 2023-04-22 16:44:44 --> Model Class Initialized
INFO - 2023-04-22 16:44:44 --> Model Class Initialized
INFO - 2023-04-22 16:44:44 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-04-22 16:44:44 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-04-22 16:44:44 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-04-22 16:44:44 --> Final output sent to browser
DEBUG - 2023-04-22 16:44:44 --> Total execution time: 0.1646
ERROR - 2023-04-22 16:44:45 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-22 16:44:45 --> Config Class Initialized
INFO - 2023-04-22 16:44:45 --> Hooks Class Initialized
DEBUG - 2023-04-22 16:44:45 --> UTF-8 Support Enabled
INFO - 2023-04-22 16:44:45 --> Utf8 Class Initialized
INFO - 2023-04-22 16:44:45 --> URI Class Initialized
INFO - 2023-04-22 16:44:45 --> Router Class Initialized
INFO - 2023-04-22 16:44:45 --> Output Class Initialized
INFO - 2023-04-22 16:44:45 --> Security Class Initialized
DEBUG - 2023-04-22 16:44:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-22 16:44:45 --> Input Class Initialized
INFO - 2023-04-22 16:44:45 --> Language Class Initialized
INFO - 2023-04-22 16:44:45 --> Loader Class Initialized
INFO - 2023-04-22 16:44:45 --> Helper loaded: url_helper
INFO - 2023-04-22 16:44:45 --> Helper loaded: file_helper
INFO - 2023-04-22 16:44:45 --> Helper loaded: html_helper
INFO - 2023-04-22 16:44:45 --> Helper loaded: text_helper
INFO - 2023-04-22 16:44:45 --> Helper loaded: form_helper
INFO - 2023-04-22 16:44:45 --> Helper loaded: lang_helper
INFO - 2023-04-22 16:44:45 --> Helper loaded: security_helper
INFO - 2023-04-22 16:44:45 --> Helper loaded: cookie_helper
INFO - 2023-04-22 16:44:45 --> Database Driver Class Initialized
INFO - 2023-04-22 16:44:45 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-22 16:44:45 --> Parser Class Initialized
INFO - 2023-04-22 16:44:45 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-22 16:44:45 --> Pagination Class Initialized
INFO - 2023-04-22 16:44:45 --> Form Validation Class Initialized
INFO - 2023-04-22 16:44:45 --> Controller Class Initialized
INFO - 2023-04-22 16:44:45 --> Model Class Initialized
DEBUG - 2023-04-22 16:44:45 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-04-22 16:44:45 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-22 16:44:45 --> Model Class Initialized
DEBUG - 2023-04-22 16:44:45 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-22 16:44:45 --> Model Class Initialized
INFO - 2023-04-22 16:44:45 --> Final output sent to browser
DEBUG - 2023-04-22 16:44:45 --> Total execution time: 0.0590
ERROR - 2023-04-22 16:44:49 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-22 16:44:49 --> Config Class Initialized
INFO - 2023-04-22 16:44:49 --> Hooks Class Initialized
DEBUG - 2023-04-22 16:44:49 --> UTF-8 Support Enabled
INFO - 2023-04-22 16:44:49 --> Utf8 Class Initialized
INFO - 2023-04-22 16:44:49 --> URI Class Initialized
INFO - 2023-04-22 16:44:49 --> Router Class Initialized
INFO - 2023-04-22 16:44:49 --> Output Class Initialized
INFO - 2023-04-22 16:44:49 --> Security Class Initialized
DEBUG - 2023-04-22 16:44:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-22 16:44:49 --> Input Class Initialized
INFO - 2023-04-22 16:44:49 --> Language Class Initialized
INFO - 2023-04-22 16:44:49 --> Loader Class Initialized
INFO - 2023-04-22 16:44:49 --> Helper loaded: url_helper
INFO - 2023-04-22 16:44:49 --> Helper loaded: file_helper
INFO - 2023-04-22 16:44:49 --> Helper loaded: html_helper
INFO - 2023-04-22 16:44:49 --> Helper loaded: text_helper
INFO - 2023-04-22 16:44:49 --> Helper loaded: form_helper
INFO - 2023-04-22 16:44:49 --> Helper loaded: lang_helper
INFO - 2023-04-22 16:44:49 --> Helper loaded: security_helper
INFO - 2023-04-22 16:44:49 --> Helper loaded: cookie_helper
INFO - 2023-04-22 16:44:49 --> Database Driver Class Initialized
INFO - 2023-04-22 16:44:49 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-22 16:44:49 --> Parser Class Initialized
INFO - 2023-04-22 16:44:49 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-22 16:44:49 --> Pagination Class Initialized
INFO - 2023-04-22 16:44:49 --> Form Validation Class Initialized
INFO - 2023-04-22 16:44:49 --> Controller Class Initialized
INFO - 2023-04-22 16:44:49 --> Model Class Initialized
DEBUG - 2023-04-22 16:44:49 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-04-22 16:44:49 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-22 16:44:49 --> Model Class Initialized
DEBUG - 2023-04-22 16:44:49 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-22 16:44:49 --> Model Class Initialized
INFO - 2023-04-22 16:44:49 --> Final output sent to browser
DEBUG - 2023-04-22 16:44:49 --> Total execution time: 0.0832
ERROR - 2023-04-22 16:45:27 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-22 16:45:27 --> Config Class Initialized
INFO - 2023-04-22 16:45:27 --> Hooks Class Initialized
DEBUG - 2023-04-22 16:45:27 --> UTF-8 Support Enabled
INFO - 2023-04-22 16:45:27 --> Utf8 Class Initialized
INFO - 2023-04-22 16:45:27 --> URI Class Initialized
INFO - 2023-04-22 16:45:27 --> Router Class Initialized
INFO - 2023-04-22 16:45:27 --> Output Class Initialized
INFO - 2023-04-22 16:45:27 --> Security Class Initialized
DEBUG - 2023-04-22 16:45:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-22 16:45:27 --> Input Class Initialized
INFO - 2023-04-22 16:45:27 --> Language Class Initialized
INFO - 2023-04-22 16:45:27 --> Loader Class Initialized
INFO - 2023-04-22 16:45:27 --> Helper loaded: url_helper
INFO - 2023-04-22 16:45:27 --> Helper loaded: file_helper
INFO - 2023-04-22 16:45:27 --> Helper loaded: html_helper
INFO - 2023-04-22 16:45:27 --> Helper loaded: text_helper
INFO - 2023-04-22 16:45:27 --> Helper loaded: form_helper
INFO - 2023-04-22 16:45:27 --> Helper loaded: lang_helper
INFO - 2023-04-22 16:45:27 --> Helper loaded: security_helper
INFO - 2023-04-22 16:45:27 --> Helper loaded: cookie_helper
INFO - 2023-04-22 16:45:27 --> Database Driver Class Initialized
INFO - 2023-04-22 16:45:27 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-22 16:45:27 --> Parser Class Initialized
INFO - 2023-04-22 16:45:27 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-22 16:45:27 --> Pagination Class Initialized
INFO - 2023-04-22 16:45:27 --> Form Validation Class Initialized
INFO - 2023-04-22 16:45:27 --> Controller Class Initialized
INFO - 2023-04-22 16:45:27 --> Model Class Initialized
DEBUG - 2023-04-22 16:45:27 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-04-22 16:45:27 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-22 16:45:27 --> Model Class Initialized
DEBUG - 2023-04-22 16:45:27 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-22 16:45:27 --> Model Class Initialized
DEBUG - 2023-04-22 16:45:27 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-22 16:45:27 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice_html.php
DEBUG - 2023-04-22 16:45:27 --> Occational class already loaded. Second attempt ignored.
DEBUG - 2023-04-22 16:45:27 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-22 16:45:27 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice_html_pdf.php
DEBUG - 2023-04-22 16:45:27 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-04-22 16:45:27 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-04-22 16:45:27 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-04-22 16:45:27 --> Model Class Initialized
INFO - 2023-04-22 16:45:27 --> Model Class Initialized
INFO - 2023-04-22 16:45:27 --> Model Class Initialized
INFO - 2023-04-22 16:45:27 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-04-22 16:45:27 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-04-22 16:45:27 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-04-22 16:45:27 --> Final output sent to browser
DEBUG - 2023-04-22 16:45:27 --> Total execution time: 0.1829
ERROR - 2023-04-22 17:33:47 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-22 17:33:47 --> Config Class Initialized
INFO - 2023-04-22 17:33:47 --> Hooks Class Initialized
DEBUG - 2023-04-22 17:33:47 --> UTF-8 Support Enabled
INFO - 2023-04-22 17:33:47 --> Utf8 Class Initialized
INFO - 2023-04-22 17:33:47 --> URI Class Initialized
INFO - 2023-04-22 17:33:47 --> Router Class Initialized
INFO - 2023-04-22 17:33:47 --> Output Class Initialized
INFO - 2023-04-22 17:33:47 --> Security Class Initialized
DEBUG - 2023-04-22 17:33:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-22 17:33:47 --> Input Class Initialized
INFO - 2023-04-22 17:33:47 --> Language Class Initialized
INFO - 2023-04-22 17:33:47 --> Loader Class Initialized
INFO - 2023-04-22 17:33:47 --> Helper loaded: url_helper
INFO - 2023-04-22 17:33:47 --> Helper loaded: file_helper
INFO - 2023-04-22 17:33:47 --> Helper loaded: html_helper
INFO - 2023-04-22 17:33:47 --> Helper loaded: text_helper
INFO - 2023-04-22 17:33:47 --> Helper loaded: form_helper
INFO - 2023-04-22 17:33:47 --> Helper loaded: lang_helper
INFO - 2023-04-22 17:33:47 --> Helper loaded: security_helper
INFO - 2023-04-22 17:33:47 --> Helper loaded: cookie_helper
INFO - 2023-04-22 17:33:47 --> Database Driver Class Initialized
INFO - 2023-04-22 17:33:47 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-22 17:33:47 --> Parser Class Initialized
INFO - 2023-04-22 17:33:47 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-22 17:33:47 --> Pagination Class Initialized
INFO - 2023-04-22 17:33:47 --> Form Validation Class Initialized
INFO - 2023-04-22 17:33:47 --> Controller Class Initialized
INFO - 2023-04-22 17:33:47 --> Model Class Initialized
DEBUG - 2023-04-22 17:33:47 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-04-22 17:33:47 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-22 17:33:47 --> Model Class Initialized
DEBUG - 2023-04-22 17:33:47 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-22 17:33:47 --> Model Class Initialized
DEBUG - 2023-04-22 17:33:47 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-22 17:33:47 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice_html.php
DEBUG - 2023-04-22 17:33:47 --> Occational class already loaded. Second attempt ignored.
DEBUG - 2023-04-22 17:33:47 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-22 17:33:47 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice_html_pdf.php
DEBUG - 2023-04-22 17:33:47 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-04-22 17:33:47 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-04-22 17:33:47 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-04-22 17:33:47 --> Model Class Initialized
INFO - 2023-04-22 17:33:47 --> Model Class Initialized
INFO - 2023-04-22 17:33:47 --> Model Class Initialized
INFO - 2023-04-22 17:33:47 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-04-22 17:33:47 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-04-22 17:33:47 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-04-22 17:33:47 --> Final output sent to browser
DEBUG - 2023-04-22 17:33:47 --> Total execution time: 0.1793
ERROR - 2023-04-22 17:33:57 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-22 17:33:57 --> Config Class Initialized
INFO - 2023-04-22 17:33:57 --> Hooks Class Initialized
DEBUG - 2023-04-22 17:33:57 --> UTF-8 Support Enabled
INFO - 2023-04-22 17:33:57 --> Utf8 Class Initialized
INFO - 2023-04-22 17:33:57 --> URI Class Initialized
INFO - 2023-04-22 17:33:57 --> Router Class Initialized
INFO - 2023-04-22 17:33:57 --> Output Class Initialized
INFO - 2023-04-22 17:33:57 --> Security Class Initialized
DEBUG - 2023-04-22 17:33:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-22 17:33:57 --> Input Class Initialized
INFO - 2023-04-22 17:33:57 --> Language Class Initialized
INFO - 2023-04-22 17:33:57 --> Loader Class Initialized
INFO - 2023-04-22 17:33:57 --> Helper loaded: url_helper
INFO - 2023-04-22 17:33:57 --> Helper loaded: file_helper
INFO - 2023-04-22 17:33:57 --> Helper loaded: html_helper
INFO - 2023-04-22 17:33:57 --> Helper loaded: text_helper
INFO - 2023-04-22 17:33:57 --> Helper loaded: form_helper
INFO - 2023-04-22 17:33:57 --> Helper loaded: lang_helper
INFO - 2023-04-22 17:33:57 --> Helper loaded: security_helper
INFO - 2023-04-22 17:33:57 --> Helper loaded: cookie_helper
INFO - 2023-04-22 17:33:57 --> Database Driver Class Initialized
INFO - 2023-04-22 17:33:57 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-22 17:33:57 --> Parser Class Initialized
INFO - 2023-04-22 17:33:57 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-22 17:33:57 --> Pagination Class Initialized
INFO - 2023-04-22 17:33:57 --> Form Validation Class Initialized
INFO - 2023-04-22 17:33:57 --> Controller Class Initialized
INFO - 2023-04-22 17:33:57 --> Model Class Initialized
DEBUG - 2023-04-22 17:33:57 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-04-22 17:33:57 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-22 17:33:57 --> Model Class Initialized
DEBUG - 2023-04-22 17:33:57 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-22 17:33:57 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/stockrequest/add_stockrequest_form.php
DEBUG - 2023-04-22 17:33:57 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-04-22 17:33:57 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-04-22 17:33:57 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-04-22 17:33:57 --> Model Class Initialized
INFO - 2023-04-22 17:33:57 --> Model Class Initialized
INFO - 2023-04-22 17:33:57 --> Model Class Initialized
INFO - 2023-04-22 17:33:57 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-04-22 17:33:57 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-04-22 17:33:57 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-04-22 17:33:57 --> Final output sent to browser
DEBUG - 2023-04-22 17:33:57 --> Total execution time: 0.1657
ERROR - 2023-04-22 17:34:02 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-22 17:34:02 --> Config Class Initialized
INFO - 2023-04-22 17:34:02 --> Hooks Class Initialized
DEBUG - 2023-04-22 17:34:02 --> UTF-8 Support Enabled
INFO - 2023-04-22 17:34:02 --> Utf8 Class Initialized
INFO - 2023-04-22 17:34:02 --> URI Class Initialized
INFO - 2023-04-22 17:34:02 --> Router Class Initialized
INFO - 2023-04-22 17:34:02 --> Output Class Initialized
INFO - 2023-04-22 17:34:02 --> Security Class Initialized
DEBUG - 2023-04-22 17:34:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-22 17:34:02 --> Input Class Initialized
INFO - 2023-04-22 17:34:02 --> Language Class Initialized
INFO - 2023-04-22 17:34:02 --> Loader Class Initialized
INFO - 2023-04-22 17:34:02 --> Helper loaded: url_helper
INFO - 2023-04-22 17:34:02 --> Helper loaded: file_helper
INFO - 2023-04-22 17:34:02 --> Helper loaded: html_helper
INFO - 2023-04-22 17:34:02 --> Helper loaded: text_helper
INFO - 2023-04-22 17:34:02 --> Helper loaded: form_helper
INFO - 2023-04-22 17:34:02 --> Helper loaded: lang_helper
INFO - 2023-04-22 17:34:02 --> Helper loaded: security_helper
INFO - 2023-04-22 17:34:02 --> Helper loaded: cookie_helper
INFO - 2023-04-22 17:34:02 --> Database Driver Class Initialized
INFO - 2023-04-22 17:34:02 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-22 17:34:02 --> Parser Class Initialized
INFO - 2023-04-22 17:34:02 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-22 17:34:02 --> Pagination Class Initialized
INFO - 2023-04-22 17:34:02 --> Form Validation Class Initialized
INFO - 2023-04-22 17:34:02 --> Controller Class Initialized
INFO - 2023-04-22 17:34:02 --> Model Class Initialized
INFO - 2023-04-22 17:34:02 --> Final output sent to browser
DEBUG - 2023-04-22 17:34:02 --> Total execution time: 0.0160
ERROR - 2023-04-22 17:34:02 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-22 17:34:02 --> Config Class Initialized
INFO - 2023-04-22 17:34:02 --> Hooks Class Initialized
DEBUG - 2023-04-22 17:34:02 --> UTF-8 Support Enabled
INFO - 2023-04-22 17:34:02 --> Utf8 Class Initialized
INFO - 2023-04-22 17:34:02 --> URI Class Initialized
INFO - 2023-04-22 17:34:02 --> Router Class Initialized
INFO - 2023-04-22 17:34:02 --> Output Class Initialized
INFO - 2023-04-22 17:34:02 --> Security Class Initialized
DEBUG - 2023-04-22 17:34:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-22 17:34:02 --> Input Class Initialized
INFO - 2023-04-22 17:34:02 --> Language Class Initialized
INFO - 2023-04-22 17:34:02 --> Loader Class Initialized
INFO - 2023-04-22 17:34:02 --> Helper loaded: url_helper
INFO - 2023-04-22 17:34:02 --> Helper loaded: file_helper
INFO - 2023-04-22 17:34:02 --> Helper loaded: html_helper
INFO - 2023-04-22 17:34:02 --> Helper loaded: text_helper
INFO - 2023-04-22 17:34:02 --> Helper loaded: form_helper
INFO - 2023-04-22 17:34:02 --> Helper loaded: lang_helper
INFO - 2023-04-22 17:34:02 --> Helper loaded: security_helper
INFO - 2023-04-22 17:34:02 --> Helper loaded: cookie_helper
INFO - 2023-04-22 17:34:02 --> Database Driver Class Initialized
INFO - 2023-04-22 17:34:02 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-22 17:34:02 --> Parser Class Initialized
INFO - 2023-04-22 17:34:02 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-22 17:34:02 --> Pagination Class Initialized
INFO - 2023-04-22 17:34:02 --> Form Validation Class Initialized
INFO - 2023-04-22 17:34:02 --> Controller Class Initialized
INFO - 2023-04-22 17:34:02 --> Model Class Initialized
INFO - 2023-04-22 17:34:02 --> Final output sent to browser
DEBUG - 2023-04-22 17:34:02 --> Total execution time: 0.0139
ERROR - 2023-04-22 17:34:03 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-22 17:34:03 --> Config Class Initialized
INFO - 2023-04-22 17:34:03 --> Hooks Class Initialized
DEBUG - 2023-04-22 17:34:03 --> UTF-8 Support Enabled
INFO - 2023-04-22 17:34:03 --> Utf8 Class Initialized
INFO - 2023-04-22 17:34:03 --> URI Class Initialized
INFO - 2023-04-22 17:34:03 --> Router Class Initialized
INFO - 2023-04-22 17:34:03 --> Output Class Initialized
INFO - 2023-04-22 17:34:03 --> Security Class Initialized
DEBUG - 2023-04-22 17:34:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-22 17:34:03 --> Input Class Initialized
INFO - 2023-04-22 17:34:03 --> Language Class Initialized
INFO - 2023-04-22 17:34:03 --> Loader Class Initialized
INFO - 2023-04-22 17:34:03 --> Helper loaded: url_helper
INFO - 2023-04-22 17:34:03 --> Helper loaded: file_helper
INFO - 2023-04-22 17:34:03 --> Helper loaded: html_helper
INFO - 2023-04-22 17:34:03 --> Helper loaded: text_helper
INFO - 2023-04-22 17:34:03 --> Helper loaded: form_helper
INFO - 2023-04-22 17:34:03 --> Helper loaded: lang_helper
INFO - 2023-04-22 17:34:03 --> Helper loaded: security_helper
INFO - 2023-04-22 17:34:03 --> Helper loaded: cookie_helper
INFO - 2023-04-22 17:34:03 --> Database Driver Class Initialized
INFO - 2023-04-22 17:34:03 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-22 17:34:03 --> Parser Class Initialized
INFO - 2023-04-22 17:34:03 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-22 17:34:03 --> Pagination Class Initialized
INFO - 2023-04-22 17:34:03 --> Form Validation Class Initialized
INFO - 2023-04-22 17:34:03 --> Controller Class Initialized
INFO - 2023-04-22 17:34:03 --> Model Class Initialized
INFO - 2023-04-22 17:34:03 --> Final output sent to browser
DEBUG - 2023-04-22 17:34:03 --> Total execution time: 0.0138
ERROR - 2023-04-22 17:34:08 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-22 17:34:08 --> Config Class Initialized
INFO - 2023-04-22 17:34:08 --> Hooks Class Initialized
DEBUG - 2023-04-22 17:34:08 --> UTF-8 Support Enabled
INFO - 2023-04-22 17:34:08 --> Utf8 Class Initialized
INFO - 2023-04-22 17:34:08 --> URI Class Initialized
INFO - 2023-04-22 17:34:08 --> Router Class Initialized
INFO - 2023-04-22 17:34:08 --> Output Class Initialized
INFO - 2023-04-22 17:34:08 --> Security Class Initialized
DEBUG - 2023-04-22 17:34:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-22 17:34:08 --> Input Class Initialized
INFO - 2023-04-22 17:34:08 --> Language Class Initialized
INFO - 2023-04-22 17:34:08 --> Loader Class Initialized
INFO - 2023-04-22 17:34:08 --> Helper loaded: url_helper
INFO - 2023-04-22 17:34:08 --> Helper loaded: file_helper
INFO - 2023-04-22 17:34:08 --> Helper loaded: html_helper
INFO - 2023-04-22 17:34:08 --> Helper loaded: text_helper
INFO - 2023-04-22 17:34:08 --> Helper loaded: form_helper
INFO - 2023-04-22 17:34:08 --> Helper loaded: lang_helper
INFO - 2023-04-22 17:34:08 --> Helper loaded: security_helper
INFO - 2023-04-22 17:34:08 --> Helper loaded: cookie_helper
INFO - 2023-04-22 17:34:08 --> Database Driver Class Initialized
INFO - 2023-04-22 17:34:08 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-22 17:34:08 --> Parser Class Initialized
INFO - 2023-04-22 17:34:08 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-22 17:34:08 --> Pagination Class Initialized
INFO - 2023-04-22 17:34:08 --> Form Validation Class Initialized
INFO - 2023-04-22 17:34:08 --> Controller Class Initialized
INFO - 2023-04-22 17:34:08 --> Model Class Initialized
DEBUG - 2023-04-22 17:34:08 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-04-22 17:34:08 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-22 17:34:08 --> Model Class Initialized
DEBUG - 2023-04-22 17:34:08 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-22 17:34:08 --> Model Class Initialized
INFO - 2023-04-22 17:34:08 --> Final output sent to browser
DEBUG - 2023-04-22 17:34:08 --> Total execution time: 0.0208
ERROR - 2023-04-22 17:34:08 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-22 17:34:08 --> Config Class Initialized
INFO - 2023-04-22 17:34:08 --> Hooks Class Initialized
DEBUG - 2023-04-22 17:34:08 --> UTF-8 Support Enabled
INFO - 2023-04-22 17:34:08 --> Utf8 Class Initialized
INFO - 2023-04-22 17:34:08 --> URI Class Initialized
INFO - 2023-04-22 17:34:08 --> Router Class Initialized
INFO - 2023-04-22 17:34:08 --> Output Class Initialized
INFO - 2023-04-22 17:34:08 --> Security Class Initialized
DEBUG - 2023-04-22 17:34:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-22 17:34:08 --> Input Class Initialized
INFO - 2023-04-22 17:34:08 --> Language Class Initialized
INFO - 2023-04-22 17:34:08 --> Loader Class Initialized
INFO - 2023-04-22 17:34:08 --> Helper loaded: url_helper
INFO - 2023-04-22 17:34:08 --> Helper loaded: file_helper
INFO - 2023-04-22 17:34:08 --> Helper loaded: html_helper
INFO - 2023-04-22 17:34:08 --> Helper loaded: text_helper
INFO - 2023-04-22 17:34:08 --> Helper loaded: form_helper
INFO - 2023-04-22 17:34:08 --> Helper loaded: lang_helper
INFO - 2023-04-22 17:34:08 --> Helper loaded: security_helper
INFO - 2023-04-22 17:34:08 --> Helper loaded: cookie_helper
INFO - 2023-04-22 17:34:08 --> Database Driver Class Initialized
INFO - 2023-04-22 17:34:08 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-22 17:34:08 --> Parser Class Initialized
INFO - 2023-04-22 17:34:08 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-22 17:34:08 --> Pagination Class Initialized
INFO - 2023-04-22 17:34:08 --> Form Validation Class Initialized
INFO - 2023-04-22 17:34:08 --> Controller Class Initialized
INFO - 2023-04-22 17:34:08 --> Model Class Initialized
DEBUG - 2023-04-22 17:34:08 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-04-22 17:34:08 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-22 17:34:08 --> Model Class Initialized
DEBUG - 2023-04-22 17:34:08 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-22 17:34:08 --> Model Class Initialized
INFO - 2023-04-22 17:34:08 --> Final output sent to browser
DEBUG - 2023-04-22 17:34:08 --> Total execution time: 0.0169
ERROR - 2023-04-22 17:34:10 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-22 17:34:10 --> Config Class Initialized
INFO - 2023-04-22 17:34:10 --> Hooks Class Initialized
DEBUG - 2023-04-22 17:34:10 --> UTF-8 Support Enabled
INFO - 2023-04-22 17:34:10 --> Utf8 Class Initialized
INFO - 2023-04-22 17:34:10 --> URI Class Initialized
INFO - 2023-04-22 17:34:10 --> Router Class Initialized
INFO - 2023-04-22 17:34:10 --> Output Class Initialized
INFO - 2023-04-22 17:34:10 --> Security Class Initialized
DEBUG - 2023-04-22 17:34:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-22 17:34:10 --> Input Class Initialized
INFO - 2023-04-22 17:34:10 --> Language Class Initialized
INFO - 2023-04-22 17:34:10 --> Loader Class Initialized
INFO - 2023-04-22 17:34:10 --> Helper loaded: url_helper
INFO - 2023-04-22 17:34:10 --> Helper loaded: file_helper
INFO - 2023-04-22 17:34:10 --> Helper loaded: html_helper
INFO - 2023-04-22 17:34:10 --> Helper loaded: text_helper
INFO - 2023-04-22 17:34:10 --> Helper loaded: form_helper
INFO - 2023-04-22 17:34:10 --> Helper loaded: lang_helper
INFO - 2023-04-22 17:34:10 --> Helper loaded: security_helper
INFO - 2023-04-22 17:34:10 --> Helper loaded: cookie_helper
INFO - 2023-04-22 17:34:10 --> Database Driver Class Initialized
INFO - 2023-04-22 17:34:10 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-22 17:34:10 --> Parser Class Initialized
INFO - 2023-04-22 17:34:10 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-22 17:34:10 --> Pagination Class Initialized
INFO - 2023-04-22 17:34:10 --> Form Validation Class Initialized
INFO - 2023-04-22 17:34:10 --> Controller Class Initialized
INFO - 2023-04-22 17:34:10 --> Model Class Initialized
DEBUG - 2023-04-22 17:34:10 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-04-22 17:34:10 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-22 17:34:10 --> Model Class Initialized
DEBUG - 2023-04-22 17:34:10 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-22 17:34:10 --> Model Class Initialized
INFO - 2023-04-22 17:34:10 --> Final output sent to browser
DEBUG - 2023-04-22 17:34:10 --> Total execution time: 0.0176
ERROR - 2023-04-22 17:34:12 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-22 17:34:12 --> Config Class Initialized
INFO - 2023-04-22 17:34:12 --> Hooks Class Initialized
DEBUG - 2023-04-22 17:34:12 --> UTF-8 Support Enabled
INFO - 2023-04-22 17:34:12 --> Utf8 Class Initialized
INFO - 2023-04-22 17:34:12 --> URI Class Initialized
INFO - 2023-04-22 17:34:12 --> Router Class Initialized
INFO - 2023-04-22 17:34:12 --> Output Class Initialized
INFO - 2023-04-22 17:34:12 --> Security Class Initialized
DEBUG - 2023-04-22 17:34:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-22 17:34:12 --> Input Class Initialized
INFO - 2023-04-22 17:34:12 --> Language Class Initialized
INFO - 2023-04-22 17:34:12 --> Loader Class Initialized
INFO - 2023-04-22 17:34:12 --> Helper loaded: url_helper
INFO - 2023-04-22 17:34:12 --> Helper loaded: file_helper
INFO - 2023-04-22 17:34:12 --> Helper loaded: html_helper
INFO - 2023-04-22 17:34:12 --> Helper loaded: text_helper
INFO - 2023-04-22 17:34:12 --> Helper loaded: form_helper
INFO - 2023-04-22 17:34:12 --> Helper loaded: lang_helper
INFO - 2023-04-22 17:34:12 --> Helper loaded: security_helper
INFO - 2023-04-22 17:34:12 --> Helper loaded: cookie_helper
INFO - 2023-04-22 17:34:12 --> Database Driver Class Initialized
INFO - 2023-04-22 17:34:12 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-22 17:34:12 --> Parser Class Initialized
INFO - 2023-04-22 17:34:12 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-22 17:34:12 --> Pagination Class Initialized
INFO - 2023-04-22 17:34:12 --> Form Validation Class Initialized
INFO - 2023-04-22 17:34:12 --> Controller Class Initialized
INFO - 2023-04-22 17:34:12 --> Model Class Initialized
DEBUG - 2023-04-22 17:34:12 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-04-22 17:34:12 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-22 17:34:12 --> Model Class Initialized
DEBUG - 2023-04-22 17:34:12 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-22 17:34:12 --> Model Class Initialized
INFO - 2023-04-22 17:34:12 --> Model Class Initialized
INFO - 2023-04-22 17:34:12 --> Final output sent to browser
DEBUG - 2023-04-22 17:34:12 --> Total execution time: 0.0235
ERROR - 2023-04-22 17:34:15 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-22 17:34:15 --> Config Class Initialized
INFO - 2023-04-22 17:34:15 --> Hooks Class Initialized
DEBUG - 2023-04-22 17:34:15 --> UTF-8 Support Enabled
INFO - 2023-04-22 17:34:15 --> Utf8 Class Initialized
INFO - 2023-04-22 17:34:15 --> URI Class Initialized
INFO - 2023-04-22 17:34:15 --> Router Class Initialized
INFO - 2023-04-22 17:34:15 --> Output Class Initialized
INFO - 2023-04-22 17:34:15 --> Security Class Initialized
DEBUG - 2023-04-22 17:34:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-22 17:34:15 --> Input Class Initialized
INFO - 2023-04-22 17:34:15 --> Language Class Initialized
INFO - 2023-04-22 17:34:15 --> Loader Class Initialized
INFO - 2023-04-22 17:34:15 --> Helper loaded: url_helper
INFO - 2023-04-22 17:34:15 --> Helper loaded: file_helper
INFO - 2023-04-22 17:34:15 --> Helper loaded: html_helper
INFO - 2023-04-22 17:34:15 --> Helper loaded: text_helper
INFO - 2023-04-22 17:34:15 --> Helper loaded: form_helper
INFO - 2023-04-22 17:34:15 --> Helper loaded: lang_helper
INFO - 2023-04-22 17:34:15 --> Helper loaded: security_helper
INFO - 2023-04-22 17:34:15 --> Helper loaded: cookie_helper
INFO - 2023-04-22 17:34:15 --> Database Driver Class Initialized
INFO - 2023-04-22 17:34:15 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-22 17:34:15 --> Parser Class Initialized
INFO - 2023-04-22 17:34:15 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-22 17:34:15 --> Pagination Class Initialized
INFO - 2023-04-22 17:34:15 --> Form Validation Class Initialized
INFO - 2023-04-22 17:34:15 --> Controller Class Initialized
INFO - 2023-04-22 17:34:15 --> Model Class Initialized
DEBUG - 2023-04-22 17:34:15 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-04-22 17:34:15 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-22 17:34:15 --> Model Class Initialized
DEBUG - 2023-04-22 17:34:15 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-22 17:34:15 --> Model Class Initialized
INFO - 2023-04-22 17:34:15 --> Final output sent to browser
DEBUG - 2023-04-22 17:34:15 --> Total execution time: 0.0231
ERROR - 2023-04-22 17:34:28 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-22 17:34:28 --> Config Class Initialized
INFO - 2023-04-22 17:34:28 --> Hooks Class Initialized
DEBUG - 2023-04-22 17:34:28 --> UTF-8 Support Enabled
INFO - 2023-04-22 17:34:28 --> Utf8 Class Initialized
INFO - 2023-04-22 17:34:28 --> URI Class Initialized
INFO - 2023-04-22 17:34:28 --> Router Class Initialized
INFO - 2023-04-22 17:34:28 --> Output Class Initialized
INFO - 2023-04-22 17:34:28 --> Security Class Initialized
DEBUG - 2023-04-22 17:34:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-22 17:34:28 --> Input Class Initialized
INFO - 2023-04-22 17:34:28 --> Language Class Initialized
INFO - 2023-04-22 17:34:28 --> Loader Class Initialized
INFO - 2023-04-22 17:34:28 --> Helper loaded: url_helper
INFO - 2023-04-22 17:34:28 --> Helper loaded: file_helper
INFO - 2023-04-22 17:34:28 --> Helper loaded: html_helper
INFO - 2023-04-22 17:34:28 --> Helper loaded: text_helper
INFO - 2023-04-22 17:34:28 --> Helper loaded: form_helper
INFO - 2023-04-22 17:34:28 --> Helper loaded: lang_helper
INFO - 2023-04-22 17:34:28 --> Helper loaded: security_helper
INFO - 2023-04-22 17:34:28 --> Helper loaded: cookie_helper
INFO - 2023-04-22 17:34:28 --> Database Driver Class Initialized
INFO - 2023-04-22 17:34:28 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-22 17:34:28 --> Parser Class Initialized
INFO - 2023-04-22 17:34:28 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-22 17:34:28 --> Pagination Class Initialized
INFO - 2023-04-22 17:34:28 --> Form Validation Class Initialized
INFO - 2023-04-22 17:34:28 --> Controller Class Initialized
INFO - 2023-04-22 17:34:28 --> Model Class Initialized
DEBUG - 2023-04-22 17:34:28 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-04-22 17:34:28 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-22 17:34:28 --> Model Class Initialized
DEBUG - 2023-04-22 17:34:28 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-22 17:34:28 --> Model Class Initialized
INFO - 2023-04-22 17:34:28 --> Final output sent to browser
DEBUG - 2023-04-22 17:34:28 --> Total execution time: 0.0206
ERROR - 2023-04-22 17:34:32 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-22 17:34:32 --> Config Class Initialized
INFO - 2023-04-22 17:34:32 --> Hooks Class Initialized
DEBUG - 2023-04-22 17:34:32 --> UTF-8 Support Enabled
INFO - 2023-04-22 17:34:32 --> Utf8 Class Initialized
INFO - 2023-04-22 17:34:32 --> URI Class Initialized
INFO - 2023-04-22 17:34:32 --> Router Class Initialized
INFO - 2023-04-22 17:34:32 --> Output Class Initialized
INFO - 2023-04-22 17:34:32 --> Security Class Initialized
DEBUG - 2023-04-22 17:34:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-22 17:34:32 --> Input Class Initialized
INFO - 2023-04-22 17:34:32 --> Language Class Initialized
INFO - 2023-04-22 17:34:32 --> Loader Class Initialized
INFO - 2023-04-22 17:34:32 --> Helper loaded: url_helper
INFO - 2023-04-22 17:34:32 --> Helper loaded: file_helper
INFO - 2023-04-22 17:34:32 --> Helper loaded: html_helper
INFO - 2023-04-22 17:34:32 --> Helper loaded: text_helper
INFO - 2023-04-22 17:34:32 --> Helper loaded: form_helper
INFO - 2023-04-22 17:34:32 --> Helper loaded: lang_helper
INFO - 2023-04-22 17:34:32 --> Helper loaded: security_helper
INFO - 2023-04-22 17:34:32 --> Helper loaded: cookie_helper
INFO - 2023-04-22 17:34:32 --> Database Driver Class Initialized
INFO - 2023-04-22 17:34:32 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-22 17:34:32 --> Parser Class Initialized
INFO - 2023-04-22 17:34:32 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-22 17:34:32 --> Pagination Class Initialized
INFO - 2023-04-22 17:34:32 --> Form Validation Class Initialized
INFO - 2023-04-22 17:34:32 --> Controller Class Initialized
INFO - 2023-04-22 17:34:32 --> Model Class Initialized
DEBUG - 2023-04-22 17:34:32 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-04-22 17:34:32 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-22 17:34:32 --> Model Class Initialized
DEBUG - 2023-04-22 17:34:32 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-22 17:34:32 --> Model Class Initialized
INFO - 2023-04-22 17:34:32 --> Model Class Initialized
INFO - 2023-04-22 17:34:32 --> Final output sent to browser
DEBUG - 2023-04-22 17:34:32 --> Total execution time: 0.0238
ERROR - 2023-04-22 17:34:34 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-22 17:34:34 --> Config Class Initialized
INFO - 2023-04-22 17:34:34 --> Hooks Class Initialized
DEBUG - 2023-04-22 17:34:34 --> UTF-8 Support Enabled
INFO - 2023-04-22 17:34:34 --> Utf8 Class Initialized
INFO - 2023-04-22 17:34:34 --> URI Class Initialized
INFO - 2023-04-22 17:34:34 --> Router Class Initialized
INFO - 2023-04-22 17:34:34 --> Output Class Initialized
INFO - 2023-04-22 17:34:34 --> Security Class Initialized
DEBUG - 2023-04-22 17:34:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-22 17:34:34 --> Input Class Initialized
INFO - 2023-04-22 17:34:34 --> Language Class Initialized
INFO - 2023-04-22 17:34:34 --> Loader Class Initialized
INFO - 2023-04-22 17:34:34 --> Helper loaded: url_helper
INFO - 2023-04-22 17:34:34 --> Helper loaded: file_helper
INFO - 2023-04-22 17:34:34 --> Helper loaded: html_helper
INFO - 2023-04-22 17:34:34 --> Helper loaded: text_helper
INFO - 2023-04-22 17:34:34 --> Helper loaded: form_helper
INFO - 2023-04-22 17:34:34 --> Helper loaded: lang_helper
INFO - 2023-04-22 17:34:34 --> Helper loaded: security_helper
INFO - 2023-04-22 17:34:34 --> Helper loaded: cookie_helper
INFO - 2023-04-22 17:34:34 --> Database Driver Class Initialized
INFO - 2023-04-22 17:34:34 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-22 17:34:34 --> Parser Class Initialized
INFO - 2023-04-22 17:34:34 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-22 17:34:34 --> Pagination Class Initialized
INFO - 2023-04-22 17:34:34 --> Form Validation Class Initialized
INFO - 2023-04-22 17:34:34 --> Controller Class Initialized
INFO - 2023-04-22 17:34:34 --> Model Class Initialized
DEBUG - 2023-04-22 17:34:34 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-04-22 17:34:34 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-22 17:34:34 --> Model Class Initialized
DEBUG - 2023-04-22 17:34:34 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-22 17:34:34 --> Model Class Initialized
INFO - 2023-04-22 17:34:34 --> Final output sent to browser
DEBUG - 2023-04-22 17:34:34 --> Total execution time: 0.0188
ERROR - 2023-04-22 17:34:45 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-22 17:34:45 --> Config Class Initialized
INFO - 2023-04-22 17:34:45 --> Hooks Class Initialized
DEBUG - 2023-04-22 17:34:45 --> UTF-8 Support Enabled
INFO - 2023-04-22 17:34:45 --> Utf8 Class Initialized
INFO - 2023-04-22 17:34:45 --> URI Class Initialized
INFO - 2023-04-22 17:34:45 --> Router Class Initialized
INFO - 2023-04-22 17:34:45 --> Output Class Initialized
INFO - 2023-04-22 17:34:45 --> Security Class Initialized
DEBUG - 2023-04-22 17:34:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-22 17:34:45 --> Input Class Initialized
INFO - 2023-04-22 17:34:45 --> Language Class Initialized
INFO - 2023-04-22 17:34:45 --> Loader Class Initialized
INFO - 2023-04-22 17:34:45 --> Helper loaded: url_helper
INFO - 2023-04-22 17:34:45 --> Helper loaded: file_helper
INFO - 2023-04-22 17:34:45 --> Helper loaded: html_helper
INFO - 2023-04-22 17:34:45 --> Helper loaded: text_helper
INFO - 2023-04-22 17:34:45 --> Helper loaded: form_helper
INFO - 2023-04-22 17:34:45 --> Helper loaded: lang_helper
INFO - 2023-04-22 17:34:45 --> Helper loaded: security_helper
INFO - 2023-04-22 17:34:45 --> Helper loaded: cookie_helper
INFO - 2023-04-22 17:34:45 --> Database Driver Class Initialized
INFO - 2023-04-22 17:34:45 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-22 17:34:45 --> Parser Class Initialized
INFO - 2023-04-22 17:34:45 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-22 17:34:45 --> Pagination Class Initialized
INFO - 2023-04-22 17:34:45 --> Form Validation Class Initialized
INFO - 2023-04-22 17:34:45 --> Controller Class Initialized
INFO - 2023-04-22 17:34:45 --> Model Class Initialized
DEBUG - 2023-04-22 17:34:45 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-04-22 17:34:45 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-22 17:34:45 --> Model Class Initialized
DEBUG - 2023-04-22 17:34:45 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-22 17:34:45 --> Model Class Initialized
INFO - 2023-04-22 17:34:45 --> Final output sent to browser
DEBUG - 2023-04-22 17:34:45 --> Total execution time: 0.0236
ERROR - 2023-04-22 17:34:45 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-22 17:34:45 --> Config Class Initialized
INFO - 2023-04-22 17:34:45 --> Hooks Class Initialized
DEBUG - 2023-04-22 17:34:45 --> UTF-8 Support Enabled
INFO - 2023-04-22 17:34:45 --> Utf8 Class Initialized
INFO - 2023-04-22 17:34:45 --> URI Class Initialized
INFO - 2023-04-22 17:34:45 --> Router Class Initialized
INFO - 2023-04-22 17:34:45 --> Output Class Initialized
INFO - 2023-04-22 17:34:45 --> Security Class Initialized
DEBUG - 2023-04-22 17:34:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-22 17:34:45 --> Input Class Initialized
INFO - 2023-04-22 17:34:45 --> Language Class Initialized
INFO - 2023-04-22 17:34:45 --> Loader Class Initialized
INFO - 2023-04-22 17:34:45 --> Helper loaded: url_helper
INFO - 2023-04-22 17:34:45 --> Helper loaded: file_helper
INFO - 2023-04-22 17:34:45 --> Helper loaded: html_helper
INFO - 2023-04-22 17:34:45 --> Helper loaded: text_helper
INFO - 2023-04-22 17:34:45 --> Helper loaded: form_helper
INFO - 2023-04-22 17:34:45 --> Helper loaded: lang_helper
INFO - 2023-04-22 17:34:45 --> Helper loaded: security_helper
INFO - 2023-04-22 17:34:45 --> Helper loaded: cookie_helper
INFO - 2023-04-22 17:34:45 --> Database Driver Class Initialized
INFO - 2023-04-22 17:34:45 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-22 17:34:45 --> Parser Class Initialized
INFO - 2023-04-22 17:34:45 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-22 17:34:45 --> Pagination Class Initialized
INFO - 2023-04-22 17:34:45 --> Form Validation Class Initialized
INFO - 2023-04-22 17:34:45 --> Controller Class Initialized
INFO - 2023-04-22 17:34:45 --> Model Class Initialized
DEBUG - 2023-04-22 17:34:45 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-04-22 17:34:45 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-22 17:34:45 --> Model Class Initialized
DEBUG - 2023-04-22 17:34:45 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-22 17:34:45 --> Model Class Initialized
INFO - 2023-04-22 17:34:45 --> Final output sent to browser
DEBUG - 2023-04-22 17:34:45 --> Total execution time: 0.0216
ERROR - 2023-04-22 17:34:45 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-22 17:34:45 --> Config Class Initialized
INFO - 2023-04-22 17:34:45 --> Hooks Class Initialized
DEBUG - 2023-04-22 17:34:45 --> UTF-8 Support Enabled
INFO - 2023-04-22 17:34:45 --> Utf8 Class Initialized
INFO - 2023-04-22 17:34:45 --> URI Class Initialized
INFO - 2023-04-22 17:34:45 --> Router Class Initialized
INFO - 2023-04-22 17:34:45 --> Output Class Initialized
INFO - 2023-04-22 17:34:45 --> Security Class Initialized
DEBUG - 2023-04-22 17:34:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-22 17:34:45 --> Input Class Initialized
INFO - 2023-04-22 17:34:45 --> Language Class Initialized
INFO - 2023-04-22 17:34:45 --> Loader Class Initialized
INFO - 2023-04-22 17:34:45 --> Helper loaded: url_helper
INFO - 2023-04-22 17:34:45 --> Helper loaded: file_helper
INFO - 2023-04-22 17:34:45 --> Helper loaded: html_helper
INFO - 2023-04-22 17:34:45 --> Helper loaded: text_helper
INFO - 2023-04-22 17:34:45 --> Helper loaded: form_helper
INFO - 2023-04-22 17:34:45 --> Helper loaded: lang_helper
INFO - 2023-04-22 17:34:45 --> Helper loaded: security_helper
INFO - 2023-04-22 17:34:45 --> Helper loaded: cookie_helper
INFO - 2023-04-22 17:34:45 --> Database Driver Class Initialized
INFO - 2023-04-22 17:34:45 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-22 17:34:45 --> Parser Class Initialized
INFO - 2023-04-22 17:34:45 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-22 17:34:45 --> Pagination Class Initialized
INFO - 2023-04-22 17:34:45 --> Form Validation Class Initialized
INFO - 2023-04-22 17:34:45 --> Controller Class Initialized
INFO - 2023-04-22 17:34:45 --> Model Class Initialized
DEBUG - 2023-04-22 17:34:45 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-04-22 17:34:45 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-22 17:34:45 --> Model Class Initialized
DEBUG - 2023-04-22 17:34:45 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-22 17:34:45 --> Model Class Initialized
INFO - 2023-04-22 17:34:45 --> Final output sent to browser
DEBUG - 2023-04-22 17:34:45 --> Total execution time: 0.0182
ERROR - 2023-04-22 17:34:52 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-22 17:34:52 --> Config Class Initialized
INFO - 2023-04-22 17:34:52 --> Hooks Class Initialized
DEBUG - 2023-04-22 17:34:52 --> UTF-8 Support Enabled
INFO - 2023-04-22 17:34:52 --> Utf8 Class Initialized
INFO - 2023-04-22 17:34:52 --> URI Class Initialized
INFO - 2023-04-22 17:34:52 --> Router Class Initialized
INFO - 2023-04-22 17:34:52 --> Output Class Initialized
INFO - 2023-04-22 17:34:52 --> Security Class Initialized
DEBUG - 2023-04-22 17:34:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-22 17:34:52 --> Input Class Initialized
INFO - 2023-04-22 17:34:52 --> Language Class Initialized
INFO - 2023-04-22 17:34:52 --> Loader Class Initialized
INFO - 2023-04-22 17:34:52 --> Helper loaded: url_helper
INFO - 2023-04-22 17:34:52 --> Helper loaded: file_helper
INFO - 2023-04-22 17:34:52 --> Helper loaded: html_helper
INFO - 2023-04-22 17:34:52 --> Helper loaded: text_helper
INFO - 2023-04-22 17:34:52 --> Helper loaded: form_helper
INFO - 2023-04-22 17:34:52 --> Helper loaded: lang_helper
INFO - 2023-04-22 17:34:52 --> Helper loaded: security_helper
INFO - 2023-04-22 17:34:52 --> Helper loaded: cookie_helper
INFO - 2023-04-22 17:34:52 --> Database Driver Class Initialized
INFO - 2023-04-22 17:34:52 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-22 17:34:52 --> Parser Class Initialized
INFO - 2023-04-22 17:34:52 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-22 17:34:52 --> Pagination Class Initialized
INFO - 2023-04-22 17:34:52 --> Form Validation Class Initialized
INFO - 2023-04-22 17:34:52 --> Controller Class Initialized
INFO - 2023-04-22 17:34:52 --> Model Class Initialized
DEBUG - 2023-04-22 17:34:52 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-04-22 17:34:52 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-22 17:34:52 --> Model Class Initialized
DEBUG - 2023-04-22 17:34:52 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-22 17:34:52 --> Model Class Initialized
INFO - 2023-04-22 17:34:52 --> Model Class Initialized
INFO - 2023-04-22 17:34:52 --> Final output sent to browser
DEBUG - 2023-04-22 17:34:52 --> Total execution time: 0.0246
ERROR - 2023-04-22 17:34:57 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-22 17:34:57 --> Config Class Initialized
INFO - 2023-04-22 17:34:57 --> Hooks Class Initialized
DEBUG - 2023-04-22 17:34:57 --> UTF-8 Support Enabled
INFO - 2023-04-22 17:34:57 --> Utf8 Class Initialized
INFO - 2023-04-22 17:34:57 --> URI Class Initialized
INFO - 2023-04-22 17:34:57 --> Router Class Initialized
INFO - 2023-04-22 17:34:57 --> Output Class Initialized
INFO - 2023-04-22 17:34:57 --> Security Class Initialized
DEBUG - 2023-04-22 17:34:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-22 17:34:57 --> Input Class Initialized
INFO - 2023-04-22 17:34:57 --> Language Class Initialized
INFO - 2023-04-22 17:34:57 --> Loader Class Initialized
INFO - 2023-04-22 17:34:57 --> Helper loaded: url_helper
INFO - 2023-04-22 17:34:57 --> Helper loaded: file_helper
INFO - 2023-04-22 17:34:57 --> Helper loaded: html_helper
INFO - 2023-04-22 17:34:57 --> Helper loaded: text_helper
INFO - 2023-04-22 17:34:57 --> Helper loaded: form_helper
INFO - 2023-04-22 17:34:57 --> Helper loaded: lang_helper
INFO - 2023-04-22 17:34:57 --> Helper loaded: security_helper
INFO - 2023-04-22 17:34:57 --> Helper loaded: cookie_helper
INFO - 2023-04-22 17:34:57 --> Database Driver Class Initialized
INFO - 2023-04-22 17:34:57 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-22 17:34:57 --> Parser Class Initialized
INFO - 2023-04-22 17:34:57 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-22 17:34:57 --> Pagination Class Initialized
INFO - 2023-04-22 17:34:57 --> Form Validation Class Initialized
INFO - 2023-04-22 17:34:57 --> Controller Class Initialized
INFO - 2023-04-22 17:34:57 --> Model Class Initialized
DEBUG - 2023-04-22 17:34:57 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-04-22 17:34:57 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-22 17:34:57 --> Model Class Initialized
DEBUG - 2023-04-22 17:34:57 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-22 17:34:57 --> Model Class Initialized
INFO - 2023-04-22 17:34:57 --> Final output sent to browser
DEBUG - 2023-04-22 17:34:57 --> Total execution time: 0.0213
ERROR - 2023-04-22 17:35:07 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-22 17:35:07 --> Config Class Initialized
INFO - 2023-04-22 17:35:07 --> Hooks Class Initialized
DEBUG - 2023-04-22 17:35:07 --> UTF-8 Support Enabled
INFO - 2023-04-22 17:35:07 --> Utf8 Class Initialized
INFO - 2023-04-22 17:35:07 --> URI Class Initialized
INFO - 2023-04-22 17:35:07 --> Router Class Initialized
INFO - 2023-04-22 17:35:07 --> Output Class Initialized
INFO - 2023-04-22 17:35:07 --> Security Class Initialized
DEBUG - 2023-04-22 17:35:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-22 17:35:07 --> Input Class Initialized
INFO - 2023-04-22 17:35:07 --> Language Class Initialized
INFO - 2023-04-22 17:35:07 --> Loader Class Initialized
INFO - 2023-04-22 17:35:07 --> Helper loaded: url_helper
INFO - 2023-04-22 17:35:07 --> Helper loaded: file_helper
INFO - 2023-04-22 17:35:07 --> Helper loaded: html_helper
INFO - 2023-04-22 17:35:07 --> Helper loaded: text_helper
INFO - 2023-04-22 17:35:07 --> Helper loaded: form_helper
INFO - 2023-04-22 17:35:07 --> Helper loaded: lang_helper
INFO - 2023-04-22 17:35:07 --> Helper loaded: security_helper
INFO - 2023-04-22 17:35:07 --> Helper loaded: cookie_helper
INFO - 2023-04-22 17:35:07 --> Database Driver Class Initialized
INFO - 2023-04-22 17:35:07 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-22 17:35:07 --> Parser Class Initialized
INFO - 2023-04-22 17:35:07 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-22 17:35:07 --> Pagination Class Initialized
INFO - 2023-04-22 17:35:07 --> Form Validation Class Initialized
INFO - 2023-04-22 17:35:07 --> Controller Class Initialized
INFO - 2023-04-22 17:35:07 --> Model Class Initialized
DEBUG - 2023-04-22 17:35:07 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-04-22 17:35:07 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-22 17:35:07 --> Model Class Initialized
DEBUG - 2023-04-22 17:35:07 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-22 17:35:07 --> Model Class Initialized
INFO - 2023-04-22 17:35:07 --> Final output sent to browser
DEBUG - 2023-04-22 17:35:07 --> Total execution time: 0.0231
ERROR - 2023-04-22 17:35:07 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-22 17:35:07 --> Config Class Initialized
INFO - 2023-04-22 17:35:07 --> Hooks Class Initialized
DEBUG - 2023-04-22 17:35:07 --> UTF-8 Support Enabled
INFO - 2023-04-22 17:35:07 --> Utf8 Class Initialized
INFO - 2023-04-22 17:35:07 --> URI Class Initialized
INFO - 2023-04-22 17:35:07 --> Router Class Initialized
INFO - 2023-04-22 17:35:07 --> Output Class Initialized
INFO - 2023-04-22 17:35:07 --> Security Class Initialized
DEBUG - 2023-04-22 17:35:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-22 17:35:07 --> Input Class Initialized
INFO - 2023-04-22 17:35:07 --> Language Class Initialized
INFO - 2023-04-22 17:35:07 --> Loader Class Initialized
INFO - 2023-04-22 17:35:07 --> Helper loaded: url_helper
INFO - 2023-04-22 17:35:07 --> Helper loaded: file_helper
INFO - 2023-04-22 17:35:07 --> Helper loaded: html_helper
INFO - 2023-04-22 17:35:07 --> Helper loaded: text_helper
INFO - 2023-04-22 17:35:07 --> Helper loaded: form_helper
INFO - 2023-04-22 17:35:07 --> Helper loaded: lang_helper
INFO - 2023-04-22 17:35:07 --> Helper loaded: security_helper
INFO - 2023-04-22 17:35:07 --> Helper loaded: cookie_helper
INFO - 2023-04-22 17:35:07 --> Database Driver Class Initialized
INFO - 2023-04-22 17:35:07 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-22 17:35:07 --> Parser Class Initialized
INFO - 2023-04-22 17:35:07 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-22 17:35:07 --> Pagination Class Initialized
INFO - 2023-04-22 17:35:07 --> Form Validation Class Initialized
INFO - 2023-04-22 17:35:07 --> Controller Class Initialized
INFO - 2023-04-22 17:35:07 --> Model Class Initialized
DEBUG - 2023-04-22 17:35:07 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-04-22 17:35:07 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-22 17:35:07 --> Model Class Initialized
DEBUG - 2023-04-22 17:35:07 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-22 17:35:07 --> Model Class Initialized
INFO - 2023-04-22 17:35:07 --> Final output sent to browser
DEBUG - 2023-04-22 17:35:07 --> Total execution time: 0.0177
ERROR - 2023-04-22 17:35:11 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-22 17:35:11 --> Config Class Initialized
INFO - 2023-04-22 17:35:11 --> Hooks Class Initialized
DEBUG - 2023-04-22 17:35:11 --> UTF-8 Support Enabled
INFO - 2023-04-22 17:35:11 --> Utf8 Class Initialized
INFO - 2023-04-22 17:35:11 --> URI Class Initialized
INFO - 2023-04-22 17:35:11 --> Router Class Initialized
INFO - 2023-04-22 17:35:11 --> Output Class Initialized
INFO - 2023-04-22 17:35:11 --> Security Class Initialized
DEBUG - 2023-04-22 17:35:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-22 17:35:11 --> Input Class Initialized
INFO - 2023-04-22 17:35:11 --> Language Class Initialized
INFO - 2023-04-22 17:35:11 --> Loader Class Initialized
INFO - 2023-04-22 17:35:11 --> Helper loaded: url_helper
INFO - 2023-04-22 17:35:11 --> Helper loaded: file_helper
INFO - 2023-04-22 17:35:11 --> Helper loaded: html_helper
INFO - 2023-04-22 17:35:11 --> Helper loaded: text_helper
INFO - 2023-04-22 17:35:11 --> Helper loaded: form_helper
INFO - 2023-04-22 17:35:11 --> Helper loaded: lang_helper
INFO - 2023-04-22 17:35:11 --> Helper loaded: security_helper
INFO - 2023-04-22 17:35:11 --> Helper loaded: cookie_helper
INFO - 2023-04-22 17:35:11 --> Database Driver Class Initialized
INFO - 2023-04-22 17:35:11 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-22 17:35:11 --> Parser Class Initialized
INFO - 2023-04-22 17:35:11 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-22 17:35:11 --> Pagination Class Initialized
INFO - 2023-04-22 17:35:11 --> Form Validation Class Initialized
INFO - 2023-04-22 17:35:11 --> Controller Class Initialized
INFO - 2023-04-22 17:35:11 --> Model Class Initialized
DEBUG - 2023-04-22 17:35:11 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-04-22 17:35:11 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-22 17:35:11 --> Model Class Initialized
DEBUG - 2023-04-22 17:35:11 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-22 17:35:11 --> Model Class Initialized
INFO - 2023-04-22 17:35:11 --> Model Class Initialized
INFO - 2023-04-22 17:35:11 --> Final output sent to browser
DEBUG - 2023-04-22 17:35:11 --> Total execution time: 0.0207
ERROR - 2023-04-22 17:35:14 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-22 17:35:14 --> Config Class Initialized
INFO - 2023-04-22 17:35:14 --> Hooks Class Initialized
DEBUG - 2023-04-22 17:35:14 --> UTF-8 Support Enabled
INFO - 2023-04-22 17:35:14 --> Utf8 Class Initialized
INFO - 2023-04-22 17:35:14 --> URI Class Initialized
INFO - 2023-04-22 17:35:14 --> Router Class Initialized
INFO - 2023-04-22 17:35:14 --> Output Class Initialized
INFO - 2023-04-22 17:35:14 --> Security Class Initialized
DEBUG - 2023-04-22 17:35:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-22 17:35:14 --> Input Class Initialized
INFO - 2023-04-22 17:35:14 --> Language Class Initialized
INFO - 2023-04-22 17:35:14 --> Loader Class Initialized
INFO - 2023-04-22 17:35:14 --> Helper loaded: url_helper
INFO - 2023-04-22 17:35:14 --> Helper loaded: file_helper
INFO - 2023-04-22 17:35:14 --> Helper loaded: html_helper
INFO - 2023-04-22 17:35:14 --> Helper loaded: text_helper
INFO - 2023-04-22 17:35:14 --> Helper loaded: form_helper
INFO - 2023-04-22 17:35:14 --> Helper loaded: lang_helper
INFO - 2023-04-22 17:35:14 --> Helper loaded: security_helper
INFO - 2023-04-22 17:35:14 --> Helper loaded: cookie_helper
INFO - 2023-04-22 17:35:14 --> Database Driver Class Initialized
INFO - 2023-04-22 17:35:14 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-22 17:35:14 --> Parser Class Initialized
INFO - 2023-04-22 17:35:14 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-22 17:35:14 --> Pagination Class Initialized
INFO - 2023-04-22 17:35:14 --> Form Validation Class Initialized
INFO - 2023-04-22 17:35:14 --> Controller Class Initialized
INFO - 2023-04-22 17:35:14 --> Model Class Initialized
DEBUG - 2023-04-22 17:35:14 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-04-22 17:35:14 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-22 17:35:14 --> Model Class Initialized
DEBUG - 2023-04-22 17:35:14 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-22 17:35:14 --> Model Class Initialized
INFO - 2023-04-22 17:35:14 --> Final output sent to browser
DEBUG - 2023-04-22 17:35:14 --> Total execution time: 0.0173
ERROR - 2023-04-22 17:35:32 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-22 17:35:32 --> Config Class Initialized
INFO - 2023-04-22 17:35:32 --> Hooks Class Initialized
DEBUG - 2023-04-22 17:35:32 --> UTF-8 Support Enabled
INFO - 2023-04-22 17:35:32 --> Utf8 Class Initialized
INFO - 2023-04-22 17:35:32 --> URI Class Initialized
INFO - 2023-04-22 17:35:32 --> Router Class Initialized
INFO - 2023-04-22 17:35:32 --> Output Class Initialized
INFO - 2023-04-22 17:35:32 --> Security Class Initialized
DEBUG - 2023-04-22 17:35:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-22 17:35:32 --> Input Class Initialized
INFO - 2023-04-22 17:35:32 --> Language Class Initialized
INFO - 2023-04-22 17:35:32 --> Loader Class Initialized
INFO - 2023-04-22 17:35:32 --> Helper loaded: url_helper
INFO - 2023-04-22 17:35:32 --> Helper loaded: file_helper
INFO - 2023-04-22 17:35:32 --> Helper loaded: html_helper
INFO - 2023-04-22 17:35:32 --> Helper loaded: text_helper
INFO - 2023-04-22 17:35:32 --> Helper loaded: form_helper
INFO - 2023-04-22 17:35:32 --> Helper loaded: lang_helper
INFO - 2023-04-22 17:35:32 --> Helper loaded: security_helper
INFO - 2023-04-22 17:35:32 --> Helper loaded: cookie_helper
INFO - 2023-04-22 17:35:32 --> Database Driver Class Initialized
INFO - 2023-04-22 17:35:32 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-22 17:35:32 --> Parser Class Initialized
INFO - 2023-04-22 17:35:32 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-22 17:35:32 --> Pagination Class Initialized
INFO - 2023-04-22 17:35:32 --> Form Validation Class Initialized
INFO - 2023-04-22 17:35:32 --> Controller Class Initialized
INFO - 2023-04-22 17:35:32 --> Model Class Initialized
DEBUG - 2023-04-22 17:35:32 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-04-22 17:35:32 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-22 17:35:32 --> Model Class Initialized
DEBUG - 2023-04-22 17:35:32 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-22 17:35:32 --> Model Class Initialized
INFO - 2023-04-22 17:35:32 --> Final output sent to browser
DEBUG - 2023-04-22 17:35:32 --> Total execution time: 0.0210
ERROR - 2023-04-22 17:35:34 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-22 17:35:34 --> Config Class Initialized
INFO - 2023-04-22 17:35:34 --> Hooks Class Initialized
DEBUG - 2023-04-22 17:35:34 --> UTF-8 Support Enabled
INFO - 2023-04-22 17:35:34 --> Utf8 Class Initialized
INFO - 2023-04-22 17:35:34 --> URI Class Initialized
INFO - 2023-04-22 17:35:34 --> Router Class Initialized
INFO - 2023-04-22 17:35:34 --> Output Class Initialized
INFO - 2023-04-22 17:35:34 --> Security Class Initialized
DEBUG - 2023-04-22 17:35:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-22 17:35:34 --> Input Class Initialized
INFO - 2023-04-22 17:35:34 --> Language Class Initialized
INFO - 2023-04-22 17:35:34 --> Loader Class Initialized
INFO - 2023-04-22 17:35:34 --> Helper loaded: url_helper
INFO - 2023-04-22 17:35:34 --> Helper loaded: file_helper
INFO - 2023-04-22 17:35:34 --> Helper loaded: html_helper
INFO - 2023-04-22 17:35:34 --> Helper loaded: text_helper
INFO - 2023-04-22 17:35:34 --> Helper loaded: form_helper
INFO - 2023-04-22 17:35:34 --> Helper loaded: lang_helper
INFO - 2023-04-22 17:35:34 --> Helper loaded: security_helper
INFO - 2023-04-22 17:35:34 --> Helper loaded: cookie_helper
INFO - 2023-04-22 17:35:34 --> Database Driver Class Initialized
INFO - 2023-04-22 17:35:34 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-22 17:35:34 --> Parser Class Initialized
INFO - 2023-04-22 17:35:34 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-22 17:35:34 --> Pagination Class Initialized
INFO - 2023-04-22 17:35:34 --> Form Validation Class Initialized
INFO - 2023-04-22 17:35:34 --> Controller Class Initialized
INFO - 2023-04-22 17:35:34 --> Model Class Initialized
DEBUG - 2023-04-22 17:35:34 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-04-22 17:35:34 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-22 17:35:34 --> Model Class Initialized
DEBUG - 2023-04-22 17:35:34 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-22 17:35:34 --> Model Class Initialized
INFO - 2023-04-22 17:35:34 --> Final output sent to browser
DEBUG - 2023-04-22 17:35:34 --> Total execution time: 0.0167
ERROR - 2023-04-22 17:35:35 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-22 17:35:35 --> Config Class Initialized
INFO - 2023-04-22 17:35:35 --> Hooks Class Initialized
DEBUG - 2023-04-22 17:35:35 --> UTF-8 Support Enabled
INFO - 2023-04-22 17:35:35 --> Utf8 Class Initialized
INFO - 2023-04-22 17:35:35 --> URI Class Initialized
INFO - 2023-04-22 17:35:35 --> Router Class Initialized
INFO - 2023-04-22 17:35:35 --> Output Class Initialized
INFO - 2023-04-22 17:35:35 --> Security Class Initialized
DEBUG - 2023-04-22 17:35:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-22 17:35:35 --> Input Class Initialized
INFO - 2023-04-22 17:35:35 --> Language Class Initialized
INFO - 2023-04-22 17:35:35 --> Loader Class Initialized
INFO - 2023-04-22 17:35:35 --> Helper loaded: url_helper
INFO - 2023-04-22 17:35:35 --> Helper loaded: file_helper
INFO - 2023-04-22 17:35:35 --> Helper loaded: html_helper
INFO - 2023-04-22 17:35:35 --> Helper loaded: text_helper
INFO - 2023-04-22 17:35:35 --> Helper loaded: form_helper
INFO - 2023-04-22 17:35:35 --> Helper loaded: lang_helper
INFO - 2023-04-22 17:35:35 --> Helper loaded: security_helper
INFO - 2023-04-22 17:35:35 --> Helper loaded: cookie_helper
INFO - 2023-04-22 17:35:35 --> Database Driver Class Initialized
INFO - 2023-04-22 17:35:35 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-22 17:35:35 --> Parser Class Initialized
INFO - 2023-04-22 17:35:35 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-22 17:35:35 --> Pagination Class Initialized
INFO - 2023-04-22 17:35:35 --> Form Validation Class Initialized
INFO - 2023-04-22 17:35:35 --> Controller Class Initialized
INFO - 2023-04-22 17:35:35 --> Model Class Initialized
DEBUG - 2023-04-22 17:35:35 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-04-22 17:35:35 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-22 17:35:35 --> Model Class Initialized
DEBUG - 2023-04-22 17:35:35 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-22 17:35:35 --> Model Class Initialized
INFO - 2023-04-22 17:35:35 --> Final output sent to browser
DEBUG - 2023-04-22 17:35:35 --> Total execution time: 0.0177
ERROR - 2023-04-22 17:35:35 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-22 17:35:35 --> Config Class Initialized
INFO - 2023-04-22 17:35:35 --> Hooks Class Initialized
DEBUG - 2023-04-22 17:35:35 --> UTF-8 Support Enabled
INFO - 2023-04-22 17:35:35 --> Utf8 Class Initialized
INFO - 2023-04-22 17:35:35 --> URI Class Initialized
INFO - 2023-04-22 17:35:35 --> Router Class Initialized
INFO - 2023-04-22 17:35:35 --> Output Class Initialized
INFO - 2023-04-22 17:35:35 --> Security Class Initialized
DEBUG - 2023-04-22 17:35:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-22 17:35:35 --> Input Class Initialized
INFO - 2023-04-22 17:35:35 --> Language Class Initialized
INFO - 2023-04-22 17:35:35 --> Loader Class Initialized
INFO - 2023-04-22 17:35:35 --> Helper loaded: url_helper
INFO - 2023-04-22 17:35:35 --> Helper loaded: file_helper
INFO - 2023-04-22 17:35:35 --> Helper loaded: html_helper
INFO - 2023-04-22 17:35:35 --> Helper loaded: text_helper
INFO - 2023-04-22 17:35:35 --> Helper loaded: form_helper
INFO - 2023-04-22 17:35:35 --> Helper loaded: lang_helper
INFO - 2023-04-22 17:35:35 --> Helper loaded: security_helper
INFO - 2023-04-22 17:35:35 --> Helper loaded: cookie_helper
INFO - 2023-04-22 17:35:35 --> Database Driver Class Initialized
INFO - 2023-04-22 17:35:35 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-22 17:35:35 --> Parser Class Initialized
INFO - 2023-04-22 17:35:35 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-22 17:35:35 --> Pagination Class Initialized
INFO - 2023-04-22 17:35:35 --> Form Validation Class Initialized
INFO - 2023-04-22 17:35:35 --> Controller Class Initialized
INFO - 2023-04-22 17:35:35 --> Model Class Initialized
DEBUG - 2023-04-22 17:35:35 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-04-22 17:35:35 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-22 17:35:35 --> Model Class Initialized
DEBUG - 2023-04-22 17:35:35 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-22 17:35:35 --> Model Class Initialized
INFO - 2023-04-22 17:35:35 --> Final output sent to browser
DEBUG - 2023-04-22 17:35:35 --> Total execution time: 0.0179
ERROR - 2023-04-22 17:35:37 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-22 17:35:37 --> Config Class Initialized
INFO - 2023-04-22 17:35:37 --> Hooks Class Initialized
DEBUG - 2023-04-22 17:35:37 --> UTF-8 Support Enabled
INFO - 2023-04-22 17:35:37 --> Utf8 Class Initialized
INFO - 2023-04-22 17:35:37 --> URI Class Initialized
INFO - 2023-04-22 17:35:37 --> Router Class Initialized
INFO - 2023-04-22 17:35:37 --> Output Class Initialized
INFO - 2023-04-22 17:35:37 --> Security Class Initialized
DEBUG - 2023-04-22 17:35:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-22 17:35:37 --> Input Class Initialized
INFO - 2023-04-22 17:35:37 --> Language Class Initialized
INFO - 2023-04-22 17:35:37 --> Loader Class Initialized
INFO - 2023-04-22 17:35:37 --> Helper loaded: url_helper
INFO - 2023-04-22 17:35:37 --> Helper loaded: file_helper
INFO - 2023-04-22 17:35:37 --> Helper loaded: html_helper
INFO - 2023-04-22 17:35:37 --> Helper loaded: text_helper
INFO - 2023-04-22 17:35:37 --> Helper loaded: form_helper
INFO - 2023-04-22 17:35:37 --> Helper loaded: lang_helper
INFO - 2023-04-22 17:35:37 --> Helper loaded: security_helper
INFO - 2023-04-22 17:35:37 --> Helper loaded: cookie_helper
INFO - 2023-04-22 17:35:37 --> Database Driver Class Initialized
INFO - 2023-04-22 17:35:37 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-22 17:35:37 --> Parser Class Initialized
INFO - 2023-04-22 17:35:37 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-22 17:35:37 --> Pagination Class Initialized
INFO - 2023-04-22 17:35:37 --> Form Validation Class Initialized
INFO - 2023-04-22 17:35:37 --> Controller Class Initialized
INFO - 2023-04-22 17:35:37 --> Model Class Initialized
DEBUG - 2023-04-22 17:35:37 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-04-22 17:35:37 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-22 17:35:37 --> Model Class Initialized
DEBUG - 2023-04-22 17:35:37 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-22 17:35:37 --> Model Class Initialized
INFO - 2023-04-22 17:35:37 --> Model Class Initialized
INFO - 2023-04-22 17:35:37 --> Final output sent to browser
DEBUG - 2023-04-22 17:35:37 --> Total execution time: 0.0212
ERROR - 2023-04-22 17:35:42 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-22 17:35:42 --> Config Class Initialized
INFO - 2023-04-22 17:35:42 --> Hooks Class Initialized
DEBUG - 2023-04-22 17:35:42 --> UTF-8 Support Enabled
INFO - 2023-04-22 17:35:42 --> Utf8 Class Initialized
INFO - 2023-04-22 17:35:42 --> URI Class Initialized
INFO - 2023-04-22 17:35:42 --> Router Class Initialized
INFO - 2023-04-22 17:35:42 --> Output Class Initialized
INFO - 2023-04-22 17:35:42 --> Security Class Initialized
DEBUG - 2023-04-22 17:35:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-22 17:35:42 --> Input Class Initialized
INFO - 2023-04-22 17:35:42 --> Language Class Initialized
INFO - 2023-04-22 17:35:42 --> Loader Class Initialized
INFO - 2023-04-22 17:35:42 --> Helper loaded: url_helper
INFO - 2023-04-22 17:35:42 --> Helper loaded: file_helper
INFO - 2023-04-22 17:35:42 --> Helper loaded: html_helper
INFO - 2023-04-22 17:35:42 --> Helper loaded: text_helper
INFO - 2023-04-22 17:35:42 --> Helper loaded: form_helper
INFO - 2023-04-22 17:35:42 --> Helper loaded: lang_helper
INFO - 2023-04-22 17:35:42 --> Helper loaded: security_helper
INFO - 2023-04-22 17:35:42 --> Helper loaded: cookie_helper
INFO - 2023-04-22 17:35:42 --> Database Driver Class Initialized
INFO - 2023-04-22 17:35:42 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-22 17:35:42 --> Parser Class Initialized
INFO - 2023-04-22 17:35:42 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-22 17:35:42 --> Pagination Class Initialized
INFO - 2023-04-22 17:35:42 --> Form Validation Class Initialized
INFO - 2023-04-22 17:35:42 --> Controller Class Initialized
INFO - 2023-04-22 17:35:42 --> Model Class Initialized
DEBUG - 2023-04-22 17:35:42 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-04-22 17:35:42 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-22 17:35:42 --> Model Class Initialized
DEBUG - 2023-04-22 17:35:42 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-22 17:35:42 --> Model Class Initialized
INFO - 2023-04-22 17:35:42 --> Final output sent to browser
DEBUG - 2023-04-22 17:35:42 --> Total execution time: 0.0189
ERROR - 2023-04-22 17:35:52 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-22 17:35:52 --> Config Class Initialized
INFO - 2023-04-22 17:35:52 --> Hooks Class Initialized
DEBUG - 2023-04-22 17:35:52 --> UTF-8 Support Enabled
INFO - 2023-04-22 17:35:52 --> Utf8 Class Initialized
INFO - 2023-04-22 17:35:52 --> URI Class Initialized
INFO - 2023-04-22 17:35:52 --> Router Class Initialized
INFO - 2023-04-22 17:35:52 --> Output Class Initialized
INFO - 2023-04-22 17:35:52 --> Security Class Initialized
DEBUG - 2023-04-22 17:35:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-22 17:35:52 --> Input Class Initialized
INFO - 2023-04-22 17:35:52 --> Language Class Initialized
INFO - 2023-04-22 17:35:52 --> Loader Class Initialized
INFO - 2023-04-22 17:35:52 --> Helper loaded: url_helper
INFO - 2023-04-22 17:35:52 --> Helper loaded: file_helper
INFO - 2023-04-22 17:35:52 --> Helper loaded: html_helper
INFO - 2023-04-22 17:35:52 --> Helper loaded: text_helper
INFO - 2023-04-22 17:35:52 --> Helper loaded: form_helper
INFO - 2023-04-22 17:35:52 --> Helper loaded: lang_helper
INFO - 2023-04-22 17:35:52 --> Helper loaded: security_helper
INFO - 2023-04-22 17:35:52 --> Helper loaded: cookie_helper
INFO - 2023-04-22 17:35:52 --> Database Driver Class Initialized
INFO - 2023-04-22 17:35:52 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-22 17:35:52 --> Parser Class Initialized
INFO - 2023-04-22 17:35:52 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-22 17:35:52 --> Pagination Class Initialized
INFO - 2023-04-22 17:35:52 --> Form Validation Class Initialized
INFO - 2023-04-22 17:35:52 --> Controller Class Initialized
INFO - 2023-04-22 17:35:52 --> Model Class Initialized
DEBUG - 2023-04-22 17:35:52 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-04-22 17:35:52 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-22 17:35:52 --> Model Class Initialized
DEBUG - 2023-04-22 17:35:52 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-22 17:35:52 --> Model Class Initialized
INFO - 2023-04-22 17:35:52 --> Final output sent to browser
DEBUG - 2023-04-22 17:35:52 --> Total execution time: 0.0206
ERROR - 2023-04-22 17:35:53 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-22 17:35:53 --> Config Class Initialized
INFO - 2023-04-22 17:35:53 --> Hooks Class Initialized
DEBUG - 2023-04-22 17:35:53 --> UTF-8 Support Enabled
INFO - 2023-04-22 17:35:53 --> Utf8 Class Initialized
INFO - 2023-04-22 17:35:53 --> URI Class Initialized
INFO - 2023-04-22 17:35:53 --> Router Class Initialized
INFO - 2023-04-22 17:35:53 --> Output Class Initialized
INFO - 2023-04-22 17:35:53 --> Security Class Initialized
DEBUG - 2023-04-22 17:35:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-22 17:35:53 --> Input Class Initialized
INFO - 2023-04-22 17:35:53 --> Language Class Initialized
INFO - 2023-04-22 17:35:53 --> Loader Class Initialized
INFO - 2023-04-22 17:35:53 --> Helper loaded: url_helper
INFO - 2023-04-22 17:35:53 --> Helper loaded: file_helper
INFO - 2023-04-22 17:35:53 --> Helper loaded: html_helper
INFO - 2023-04-22 17:35:53 --> Helper loaded: text_helper
INFO - 2023-04-22 17:35:53 --> Helper loaded: form_helper
INFO - 2023-04-22 17:35:53 --> Helper loaded: lang_helper
INFO - 2023-04-22 17:35:53 --> Helper loaded: security_helper
INFO - 2023-04-22 17:35:53 --> Helper loaded: cookie_helper
INFO - 2023-04-22 17:35:53 --> Database Driver Class Initialized
INFO - 2023-04-22 17:35:53 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-22 17:35:53 --> Parser Class Initialized
INFO - 2023-04-22 17:35:53 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-22 17:35:53 --> Pagination Class Initialized
INFO - 2023-04-22 17:35:53 --> Form Validation Class Initialized
INFO - 2023-04-22 17:35:53 --> Controller Class Initialized
INFO - 2023-04-22 17:35:53 --> Model Class Initialized
DEBUG - 2023-04-22 17:35:53 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-04-22 17:35:53 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-22 17:35:53 --> Model Class Initialized
DEBUG - 2023-04-22 17:35:53 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-22 17:35:53 --> Model Class Initialized
INFO - 2023-04-22 17:35:53 --> Final output sent to browser
DEBUG - 2023-04-22 17:35:53 --> Total execution time: 0.0169
ERROR - 2023-04-22 17:35:57 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-22 17:35:57 --> Config Class Initialized
INFO - 2023-04-22 17:35:57 --> Hooks Class Initialized
DEBUG - 2023-04-22 17:35:57 --> UTF-8 Support Enabled
INFO - 2023-04-22 17:35:57 --> Utf8 Class Initialized
INFO - 2023-04-22 17:35:57 --> URI Class Initialized
INFO - 2023-04-22 17:35:57 --> Router Class Initialized
INFO - 2023-04-22 17:35:57 --> Output Class Initialized
INFO - 2023-04-22 17:35:57 --> Security Class Initialized
DEBUG - 2023-04-22 17:35:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-22 17:35:57 --> Input Class Initialized
INFO - 2023-04-22 17:35:57 --> Language Class Initialized
INFO - 2023-04-22 17:35:57 --> Loader Class Initialized
INFO - 2023-04-22 17:35:57 --> Helper loaded: url_helper
INFO - 2023-04-22 17:35:57 --> Helper loaded: file_helper
INFO - 2023-04-22 17:35:57 --> Helper loaded: html_helper
INFO - 2023-04-22 17:35:57 --> Helper loaded: text_helper
INFO - 2023-04-22 17:35:57 --> Helper loaded: form_helper
INFO - 2023-04-22 17:35:57 --> Helper loaded: lang_helper
INFO - 2023-04-22 17:35:57 --> Helper loaded: security_helper
INFO - 2023-04-22 17:35:57 --> Helper loaded: cookie_helper
INFO - 2023-04-22 17:35:57 --> Database Driver Class Initialized
INFO - 2023-04-22 17:35:57 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-22 17:35:57 --> Parser Class Initialized
INFO - 2023-04-22 17:35:57 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-22 17:35:57 --> Pagination Class Initialized
INFO - 2023-04-22 17:35:57 --> Form Validation Class Initialized
INFO - 2023-04-22 17:35:57 --> Controller Class Initialized
INFO - 2023-04-22 17:35:57 --> Model Class Initialized
DEBUG - 2023-04-22 17:35:57 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-04-22 17:35:57 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-22 17:35:57 --> Model Class Initialized
DEBUG - 2023-04-22 17:35:57 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-22 17:35:57 --> Model Class Initialized
INFO - 2023-04-22 17:35:57 --> Model Class Initialized
INFO - 2023-04-22 17:35:57 --> Final output sent to browser
DEBUG - 2023-04-22 17:35:57 --> Total execution time: 0.0209
ERROR - 2023-04-22 17:36:00 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-22 17:36:00 --> Config Class Initialized
INFO - 2023-04-22 17:36:00 --> Hooks Class Initialized
DEBUG - 2023-04-22 17:36:00 --> UTF-8 Support Enabled
INFO - 2023-04-22 17:36:00 --> Utf8 Class Initialized
INFO - 2023-04-22 17:36:00 --> URI Class Initialized
INFO - 2023-04-22 17:36:00 --> Router Class Initialized
INFO - 2023-04-22 17:36:00 --> Output Class Initialized
INFO - 2023-04-22 17:36:00 --> Security Class Initialized
DEBUG - 2023-04-22 17:36:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-22 17:36:00 --> Input Class Initialized
INFO - 2023-04-22 17:36:00 --> Language Class Initialized
INFO - 2023-04-22 17:36:00 --> Loader Class Initialized
INFO - 2023-04-22 17:36:00 --> Helper loaded: url_helper
INFO - 2023-04-22 17:36:00 --> Helper loaded: file_helper
INFO - 2023-04-22 17:36:00 --> Helper loaded: html_helper
INFO - 2023-04-22 17:36:00 --> Helper loaded: text_helper
INFO - 2023-04-22 17:36:00 --> Helper loaded: form_helper
INFO - 2023-04-22 17:36:00 --> Helper loaded: lang_helper
INFO - 2023-04-22 17:36:00 --> Helper loaded: security_helper
INFO - 2023-04-22 17:36:00 --> Helper loaded: cookie_helper
INFO - 2023-04-22 17:36:00 --> Database Driver Class Initialized
INFO - 2023-04-22 17:36:00 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-22 17:36:00 --> Parser Class Initialized
INFO - 2023-04-22 17:36:00 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-22 17:36:00 --> Pagination Class Initialized
INFO - 2023-04-22 17:36:00 --> Form Validation Class Initialized
INFO - 2023-04-22 17:36:00 --> Controller Class Initialized
INFO - 2023-04-22 17:36:00 --> Model Class Initialized
DEBUG - 2023-04-22 17:36:00 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-04-22 17:36:00 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-22 17:36:00 --> Model Class Initialized
DEBUG - 2023-04-22 17:36:00 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-22 17:36:00 --> Model Class Initialized
INFO - 2023-04-22 17:36:00 --> Final output sent to browser
DEBUG - 2023-04-22 17:36:00 --> Total execution time: 0.0170
ERROR - 2023-04-22 17:36:10 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-22 17:36:10 --> Config Class Initialized
INFO - 2023-04-22 17:36:10 --> Hooks Class Initialized
DEBUG - 2023-04-22 17:36:10 --> UTF-8 Support Enabled
INFO - 2023-04-22 17:36:10 --> Utf8 Class Initialized
INFO - 2023-04-22 17:36:10 --> URI Class Initialized
INFO - 2023-04-22 17:36:10 --> Router Class Initialized
INFO - 2023-04-22 17:36:10 --> Output Class Initialized
INFO - 2023-04-22 17:36:10 --> Security Class Initialized
DEBUG - 2023-04-22 17:36:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-22 17:36:10 --> Input Class Initialized
INFO - 2023-04-22 17:36:10 --> Language Class Initialized
INFO - 2023-04-22 17:36:10 --> Loader Class Initialized
INFO - 2023-04-22 17:36:10 --> Helper loaded: url_helper
INFO - 2023-04-22 17:36:10 --> Helper loaded: file_helper
INFO - 2023-04-22 17:36:10 --> Helper loaded: html_helper
INFO - 2023-04-22 17:36:10 --> Helper loaded: text_helper
INFO - 2023-04-22 17:36:10 --> Helper loaded: form_helper
INFO - 2023-04-22 17:36:10 --> Helper loaded: lang_helper
INFO - 2023-04-22 17:36:10 --> Helper loaded: security_helper
INFO - 2023-04-22 17:36:10 --> Helper loaded: cookie_helper
INFO - 2023-04-22 17:36:10 --> Database Driver Class Initialized
INFO - 2023-04-22 17:36:10 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-22 17:36:10 --> Parser Class Initialized
INFO - 2023-04-22 17:36:10 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-22 17:36:10 --> Pagination Class Initialized
INFO - 2023-04-22 17:36:10 --> Form Validation Class Initialized
INFO - 2023-04-22 17:36:10 --> Controller Class Initialized
INFO - 2023-04-22 17:36:10 --> Model Class Initialized
DEBUG - 2023-04-22 17:36:10 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-04-22 17:36:10 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-22 17:36:10 --> Model Class Initialized
DEBUG - 2023-04-22 17:36:10 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-22 17:36:10 --> Model Class Initialized
INFO - 2023-04-22 17:36:10 --> Final output sent to browser
DEBUG - 2023-04-22 17:36:10 --> Total execution time: 0.0173
ERROR - 2023-04-22 17:36:13 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-22 17:36:13 --> Config Class Initialized
INFO - 2023-04-22 17:36:13 --> Hooks Class Initialized
DEBUG - 2023-04-22 17:36:13 --> UTF-8 Support Enabled
INFO - 2023-04-22 17:36:13 --> Utf8 Class Initialized
INFO - 2023-04-22 17:36:13 --> URI Class Initialized
INFO - 2023-04-22 17:36:13 --> Router Class Initialized
INFO - 2023-04-22 17:36:13 --> Output Class Initialized
INFO - 2023-04-22 17:36:13 --> Security Class Initialized
DEBUG - 2023-04-22 17:36:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-22 17:36:13 --> Input Class Initialized
INFO - 2023-04-22 17:36:13 --> Language Class Initialized
INFO - 2023-04-22 17:36:13 --> Loader Class Initialized
INFO - 2023-04-22 17:36:13 --> Helper loaded: url_helper
INFO - 2023-04-22 17:36:13 --> Helper loaded: file_helper
INFO - 2023-04-22 17:36:13 --> Helper loaded: html_helper
INFO - 2023-04-22 17:36:13 --> Helper loaded: text_helper
INFO - 2023-04-22 17:36:13 --> Helper loaded: form_helper
INFO - 2023-04-22 17:36:13 --> Helper loaded: lang_helper
INFO - 2023-04-22 17:36:13 --> Helper loaded: security_helper
INFO - 2023-04-22 17:36:13 --> Helper loaded: cookie_helper
INFO - 2023-04-22 17:36:13 --> Database Driver Class Initialized
INFO - 2023-04-22 17:36:13 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-22 17:36:13 --> Parser Class Initialized
INFO - 2023-04-22 17:36:13 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-22 17:36:13 --> Pagination Class Initialized
INFO - 2023-04-22 17:36:13 --> Form Validation Class Initialized
INFO - 2023-04-22 17:36:13 --> Controller Class Initialized
INFO - 2023-04-22 17:36:13 --> Model Class Initialized
DEBUG - 2023-04-22 17:36:13 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-04-22 17:36:13 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-22 17:36:13 --> Model Class Initialized
DEBUG - 2023-04-22 17:36:13 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-22 17:36:13 --> Model Class Initialized
INFO - 2023-04-22 17:36:13 --> Model Class Initialized
INFO - 2023-04-22 17:36:13 --> Final output sent to browser
DEBUG - 2023-04-22 17:36:13 --> Total execution time: 0.0211
ERROR - 2023-04-22 17:36:15 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-22 17:36:15 --> Config Class Initialized
INFO - 2023-04-22 17:36:15 --> Hooks Class Initialized
DEBUG - 2023-04-22 17:36:15 --> UTF-8 Support Enabled
INFO - 2023-04-22 17:36:15 --> Utf8 Class Initialized
INFO - 2023-04-22 17:36:15 --> URI Class Initialized
INFO - 2023-04-22 17:36:15 --> Router Class Initialized
INFO - 2023-04-22 17:36:15 --> Output Class Initialized
INFO - 2023-04-22 17:36:15 --> Security Class Initialized
DEBUG - 2023-04-22 17:36:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-22 17:36:15 --> Input Class Initialized
INFO - 2023-04-22 17:36:15 --> Language Class Initialized
INFO - 2023-04-22 17:36:15 --> Loader Class Initialized
INFO - 2023-04-22 17:36:15 --> Helper loaded: url_helper
INFO - 2023-04-22 17:36:15 --> Helper loaded: file_helper
INFO - 2023-04-22 17:36:15 --> Helper loaded: html_helper
INFO - 2023-04-22 17:36:15 --> Helper loaded: text_helper
INFO - 2023-04-22 17:36:15 --> Helper loaded: form_helper
INFO - 2023-04-22 17:36:15 --> Helper loaded: lang_helper
INFO - 2023-04-22 17:36:15 --> Helper loaded: security_helper
INFO - 2023-04-22 17:36:15 --> Helper loaded: cookie_helper
INFO - 2023-04-22 17:36:15 --> Database Driver Class Initialized
INFO - 2023-04-22 17:36:15 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-22 17:36:15 --> Parser Class Initialized
INFO - 2023-04-22 17:36:15 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-22 17:36:15 --> Pagination Class Initialized
INFO - 2023-04-22 17:36:15 --> Form Validation Class Initialized
INFO - 2023-04-22 17:36:15 --> Controller Class Initialized
INFO - 2023-04-22 17:36:15 --> Model Class Initialized
DEBUG - 2023-04-22 17:36:15 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-04-22 17:36:15 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-22 17:36:15 --> Model Class Initialized
DEBUG - 2023-04-22 17:36:15 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-22 17:36:15 --> Model Class Initialized
INFO - 2023-04-22 17:36:15 --> Final output sent to browser
DEBUG - 2023-04-22 17:36:15 --> Total execution time: 0.0177
ERROR - 2023-04-22 17:36:24 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-22 17:36:24 --> Config Class Initialized
INFO - 2023-04-22 17:36:24 --> Hooks Class Initialized
DEBUG - 2023-04-22 17:36:24 --> UTF-8 Support Enabled
INFO - 2023-04-22 17:36:24 --> Utf8 Class Initialized
INFO - 2023-04-22 17:36:24 --> URI Class Initialized
INFO - 2023-04-22 17:36:24 --> Router Class Initialized
INFO - 2023-04-22 17:36:24 --> Output Class Initialized
INFO - 2023-04-22 17:36:24 --> Security Class Initialized
DEBUG - 2023-04-22 17:36:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-22 17:36:24 --> Input Class Initialized
INFO - 2023-04-22 17:36:24 --> Language Class Initialized
INFO - 2023-04-22 17:36:24 --> Loader Class Initialized
INFO - 2023-04-22 17:36:24 --> Helper loaded: url_helper
INFO - 2023-04-22 17:36:24 --> Helper loaded: file_helper
INFO - 2023-04-22 17:36:24 --> Helper loaded: html_helper
INFO - 2023-04-22 17:36:24 --> Helper loaded: text_helper
INFO - 2023-04-22 17:36:24 --> Helper loaded: form_helper
INFO - 2023-04-22 17:36:24 --> Helper loaded: lang_helper
INFO - 2023-04-22 17:36:24 --> Helper loaded: security_helper
INFO - 2023-04-22 17:36:24 --> Helper loaded: cookie_helper
INFO - 2023-04-22 17:36:24 --> Database Driver Class Initialized
INFO - 2023-04-22 17:36:24 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-22 17:36:24 --> Parser Class Initialized
INFO - 2023-04-22 17:36:24 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-22 17:36:24 --> Pagination Class Initialized
INFO - 2023-04-22 17:36:24 --> Form Validation Class Initialized
INFO - 2023-04-22 17:36:24 --> Controller Class Initialized
INFO - 2023-04-22 17:36:24 --> Model Class Initialized
DEBUG - 2023-04-22 17:36:24 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-04-22 17:36:24 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-22 17:36:24 --> Model Class Initialized
DEBUG - 2023-04-22 17:36:24 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-22 17:36:24 --> Model Class Initialized
INFO - 2023-04-22 17:36:24 --> Final output sent to browser
DEBUG - 2023-04-22 17:36:24 --> Total execution time: 0.0177
ERROR - 2023-04-22 17:36:25 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-22 17:36:25 --> Config Class Initialized
INFO - 2023-04-22 17:36:25 --> Hooks Class Initialized
DEBUG - 2023-04-22 17:36:25 --> UTF-8 Support Enabled
INFO - 2023-04-22 17:36:25 --> Utf8 Class Initialized
INFO - 2023-04-22 17:36:25 --> URI Class Initialized
INFO - 2023-04-22 17:36:25 --> Router Class Initialized
INFO - 2023-04-22 17:36:25 --> Output Class Initialized
INFO - 2023-04-22 17:36:25 --> Security Class Initialized
DEBUG - 2023-04-22 17:36:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-22 17:36:25 --> Input Class Initialized
INFO - 2023-04-22 17:36:25 --> Language Class Initialized
INFO - 2023-04-22 17:36:25 --> Loader Class Initialized
INFO - 2023-04-22 17:36:25 --> Helper loaded: url_helper
INFO - 2023-04-22 17:36:25 --> Helper loaded: file_helper
INFO - 2023-04-22 17:36:25 --> Helper loaded: html_helper
INFO - 2023-04-22 17:36:25 --> Helper loaded: text_helper
INFO - 2023-04-22 17:36:25 --> Helper loaded: form_helper
INFO - 2023-04-22 17:36:25 --> Helper loaded: lang_helper
INFO - 2023-04-22 17:36:25 --> Helper loaded: security_helper
INFO - 2023-04-22 17:36:25 --> Helper loaded: cookie_helper
INFO - 2023-04-22 17:36:25 --> Database Driver Class Initialized
INFO - 2023-04-22 17:36:25 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-22 17:36:25 --> Parser Class Initialized
INFO - 2023-04-22 17:36:25 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-22 17:36:25 --> Pagination Class Initialized
INFO - 2023-04-22 17:36:25 --> Form Validation Class Initialized
INFO - 2023-04-22 17:36:25 --> Controller Class Initialized
INFO - 2023-04-22 17:36:25 --> Model Class Initialized
DEBUG - 2023-04-22 17:36:25 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-04-22 17:36:25 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-22 17:36:25 --> Model Class Initialized
DEBUG - 2023-04-22 17:36:25 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-22 17:36:25 --> Model Class Initialized
INFO - 2023-04-22 17:36:25 --> Final output sent to browser
DEBUG - 2023-04-22 17:36:25 --> Total execution time: 0.0173
ERROR - 2023-04-22 17:36:31 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-22 17:36:31 --> Config Class Initialized
INFO - 2023-04-22 17:36:31 --> Hooks Class Initialized
DEBUG - 2023-04-22 17:36:31 --> UTF-8 Support Enabled
INFO - 2023-04-22 17:36:31 --> Utf8 Class Initialized
INFO - 2023-04-22 17:36:31 --> URI Class Initialized
INFO - 2023-04-22 17:36:31 --> Router Class Initialized
INFO - 2023-04-22 17:36:31 --> Output Class Initialized
INFO - 2023-04-22 17:36:31 --> Security Class Initialized
DEBUG - 2023-04-22 17:36:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-22 17:36:31 --> Input Class Initialized
INFO - 2023-04-22 17:36:31 --> Language Class Initialized
INFO - 2023-04-22 17:36:31 --> Loader Class Initialized
INFO - 2023-04-22 17:36:31 --> Helper loaded: url_helper
INFO - 2023-04-22 17:36:31 --> Helper loaded: file_helper
INFO - 2023-04-22 17:36:31 --> Helper loaded: html_helper
INFO - 2023-04-22 17:36:31 --> Helper loaded: text_helper
INFO - 2023-04-22 17:36:31 --> Helper loaded: form_helper
INFO - 2023-04-22 17:36:31 --> Helper loaded: lang_helper
INFO - 2023-04-22 17:36:31 --> Helper loaded: security_helper
INFO - 2023-04-22 17:36:31 --> Helper loaded: cookie_helper
INFO - 2023-04-22 17:36:31 --> Database Driver Class Initialized
INFO - 2023-04-22 17:36:31 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-22 17:36:31 --> Parser Class Initialized
INFO - 2023-04-22 17:36:31 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-22 17:36:31 --> Pagination Class Initialized
INFO - 2023-04-22 17:36:31 --> Form Validation Class Initialized
INFO - 2023-04-22 17:36:31 --> Controller Class Initialized
INFO - 2023-04-22 17:36:31 --> Model Class Initialized
DEBUG - 2023-04-22 17:36:31 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-04-22 17:36:31 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-22 17:36:31 --> Model Class Initialized
DEBUG - 2023-04-22 17:36:31 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-22 17:36:31 --> Model Class Initialized
INFO - 2023-04-22 17:36:31 --> Model Class Initialized
INFO - 2023-04-22 17:36:31 --> Final output sent to browser
DEBUG - 2023-04-22 17:36:31 --> Total execution time: 0.0195
ERROR - 2023-04-22 17:36:33 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-22 17:36:33 --> Config Class Initialized
INFO - 2023-04-22 17:36:33 --> Hooks Class Initialized
DEBUG - 2023-04-22 17:36:33 --> UTF-8 Support Enabled
INFO - 2023-04-22 17:36:33 --> Utf8 Class Initialized
INFO - 2023-04-22 17:36:33 --> URI Class Initialized
INFO - 2023-04-22 17:36:33 --> Router Class Initialized
INFO - 2023-04-22 17:36:33 --> Output Class Initialized
INFO - 2023-04-22 17:36:33 --> Security Class Initialized
DEBUG - 2023-04-22 17:36:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-22 17:36:33 --> Input Class Initialized
INFO - 2023-04-22 17:36:33 --> Language Class Initialized
INFO - 2023-04-22 17:36:33 --> Loader Class Initialized
INFO - 2023-04-22 17:36:33 --> Helper loaded: url_helper
INFO - 2023-04-22 17:36:33 --> Helper loaded: file_helper
INFO - 2023-04-22 17:36:33 --> Helper loaded: html_helper
INFO - 2023-04-22 17:36:33 --> Helper loaded: text_helper
INFO - 2023-04-22 17:36:33 --> Helper loaded: form_helper
INFO - 2023-04-22 17:36:33 --> Helper loaded: lang_helper
INFO - 2023-04-22 17:36:33 --> Helper loaded: security_helper
INFO - 2023-04-22 17:36:33 --> Helper loaded: cookie_helper
INFO - 2023-04-22 17:36:33 --> Database Driver Class Initialized
INFO - 2023-04-22 17:36:33 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-22 17:36:33 --> Parser Class Initialized
INFO - 2023-04-22 17:36:33 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-22 17:36:33 --> Pagination Class Initialized
INFO - 2023-04-22 17:36:33 --> Form Validation Class Initialized
INFO - 2023-04-22 17:36:33 --> Controller Class Initialized
INFO - 2023-04-22 17:36:33 --> Model Class Initialized
DEBUG - 2023-04-22 17:36:33 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-04-22 17:36:33 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-22 17:36:33 --> Model Class Initialized
DEBUG - 2023-04-22 17:36:33 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-22 17:36:33 --> Model Class Initialized
INFO - 2023-04-22 17:36:33 --> Final output sent to browser
DEBUG - 2023-04-22 17:36:33 --> Total execution time: 0.0180
ERROR - 2023-04-22 17:36:42 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-22 17:36:42 --> Config Class Initialized
INFO - 2023-04-22 17:36:42 --> Hooks Class Initialized
DEBUG - 2023-04-22 17:36:42 --> UTF-8 Support Enabled
INFO - 2023-04-22 17:36:42 --> Utf8 Class Initialized
INFO - 2023-04-22 17:36:42 --> URI Class Initialized
INFO - 2023-04-22 17:36:42 --> Router Class Initialized
INFO - 2023-04-22 17:36:42 --> Output Class Initialized
INFO - 2023-04-22 17:36:42 --> Security Class Initialized
DEBUG - 2023-04-22 17:36:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-22 17:36:42 --> Input Class Initialized
INFO - 2023-04-22 17:36:42 --> Language Class Initialized
INFO - 2023-04-22 17:36:42 --> Loader Class Initialized
INFO - 2023-04-22 17:36:42 --> Helper loaded: url_helper
INFO - 2023-04-22 17:36:42 --> Helper loaded: file_helper
INFO - 2023-04-22 17:36:42 --> Helper loaded: html_helper
INFO - 2023-04-22 17:36:42 --> Helper loaded: text_helper
INFO - 2023-04-22 17:36:42 --> Helper loaded: form_helper
INFO - 2023-04-22 17:36:42 --> Helper loaded: lang_helper
INFO - 2023-04-22 17:36:42 --> Helper loaded: security_helper
INFO - 2023-04-22 17:36:42 --> Helper loaded: cookie_helper
INFO - 2023-04-22 17:36:42 --> Database Driver Class Initialized
INFO - 2023-04-22 17:36:42 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-22 17:36:42 --> Parser Class Initialized
INFO - 2023-04-22 17:36:42 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-22 17:36:42 --> Pagination Class Initialized
INFO - 2023-04-22 17:36:42 --> Form Validation Class Initialized
INFO - 2023-04-22 17:36:42 --> Controller Class Initialized
INFO - 2023-04-22 17:36:42 --> Model Class Initialized
DEBUG - 2023-04-22 17:36:42 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-04-22 17:36:42 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-22 17:36:42 --> Model Class Initialized
DEBUG - 2023-04-22 17:36:42 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-22 17:36:42 --> Model Class Initialized
INFO - 2023-04-22 17:36:42 --> Final output sent to browser
DEBUG - 2023-04-22 17:36:42 --> Total execution time: 0.0207
ERROR - 2023-04-22 17:36:44 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-22 17:36:44 --> Config Class Initialized
INFO - 2023-04-22 17:36:44 --> Hooks Class Initialized
DEBUG - 2023-04-22 17:36:44 --> UTF-8 Support Enabled
INFO - 2023-04-22 17:36:44 --> Utf8 Class Initialized
INFO - 2023-04-22 17:36:44 --> URI Class Initialized
INFO - 2023-04-22 17:36:44 --> Router Class Initialized
INFO - 2023-04-22 17:36:44 --> Output Class Initialized
INFO - 2023-04-22 17:36:44 --> Security Class Initialized
DEBUG - 2023-04-22 17:36:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-22 17:36:44 --> Input Class Initialized
INFO - 2023-04-22 17:36:44 --> Language Class Initialized
INFO - 2023-04-22 17:36:44 --> Loader Class Initialized
INFO - 2023-04-22 17:36:44 --> Helper loaded: url_helper
INFO - 2023-04-22 17:36:44 --> Helper loaded: file_helper
INFO - 2023-04-22 17:36:44 --> Helper loaded: html_helper
INFO - 2023-04-22 17:36:44 --> Helper loaded: text_helper
INFO - 2023-04-22 17:36:44 --> Helper loaded: form_helper
INFO - 2023-04-22 17:36:44 --> Helper loaded: lang_helper
INFO - 2023-04-22 17:36:44 --> Helper loaded: security_helper
INFO - 2023-04-22 17:36:44 --> Helper loaded: cookie_helper
INFO - 2023-04-22 17:36:44 --> Database Driver Class Initialized
INFO - 2023-04-22 17:36:44 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-22 17:36:44 --> Parser Class Initialized
INFO - 2023-04-22 17:36:44 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-22 17:36:44 --> Pagination Class Initialized
INFO - 2023-04-22 17:36:44 --> Form Validation Class Initialized
INFO - 2023-04-22 17:36:44 --> Controller Class Initialized
INFO - 2023-04-22 17:36:44 --> Model Class Initialized
DEBUG - 2023-04-22 17:36:44 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-04-22 17:36:44 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-22 17:36:44 --> Model Class Initialized
DEBUG - 2023-04-22 17:36:44 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-22 17:36:44 --> Model Class Initialized
INFO - 2023-04-22 17:36:44 --> Final output sent to browser
DEBUG - 2023-04-22 17:36:44 --> Total execution time: 0.0208
ERROR - 2023-04-22 17:36:45 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-22 17:36:45 --> Config Class Initialized
INFO - 2023-04-22 17:36:45 --> Hooks Class Initialized
DEBUG - 2023-04-22 17:36:45 --> UTF-8 Support Enabled
INFO - 2023-04-22 17:36:45 --> Utf8 Class Initialized
INFO - 2023-04-22 17:36:45 --> URI Class Initialized
INFO - 2023-04-22 17:36:45 --> Router Class Initialized
INFO - 2023-04-22 17:36:45 --> Output Class Initialized
INFO - 2023-04-22 17:36:45 --> Security Class Initialized
DEBUG - 2023-04-22 17:36:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-22 17:36:45 --> Input Class Initialized
INFO - 2023-04-22 17:36:45 --> Language Class Initialized
INFO - 2023-04-22 17:36:45 --> Loader Class Initialized
INFO - 2023-04-22 17:36:45 --> Helper loaded: url_helper
INFO - 2023-04-22 17:36:45 --> Helper loaded: file_helper
INFO - 2023-04-22 17:36:45 --> Helper loaded: html_helper
INFO - 2023-04-22 17:36:45 --> Helper loaded: text_helper
INFO - 2023-04-22 17:36:45 --> Helper loaded: form_helper
INFO - 2023-04-22 17:36:45 --> Helper loaded: lang_helper
INFO - 2023-04-22 17:36:45 --> Helper loaded: security_helper
INFO - 2023-04-22 17:36:45 --> Helper loaded: cookie_helper
INFO - 2023-04-22 17:36:45 --> Database Driver Class Initialized
INFO - 2023-04-22 17:36:45 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-22 17:36:45 --> Parser Class Initialized
INFO - 2023-04-22 17:36:45 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-22 17:36:45 --> Pagination Class Initialized
INFO - 2023-04-22 17:36:45 --> Form Validation Class Initialized
INFO - 2023-04-22 17:36:45 --> Controller Class Initialized
INFO - 2023-04-22 17:36:45 --> Model Class Initialized
DEBUG - 2023-04-22 17:36:45 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-04-22 17:36:45 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-22 17:36:45 --> Model Class Initialized
DEBUG - 2023-04-22 17:36:45 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-22 17:36:45 --> Model Class Initialized
INFO - 2023-04-22 17:36:45 --> Final output sent to browser
DEBUG - 2023-04-22 17:36:45 --> Total execution time: 0.0191
ERROR - 2023-04-22 17:36:49 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-22 17:36:49 --> Config Class Initialized
INFO - 2023-04-22 17:36:49 --> Hooks Class Initialized
DEBUG - 2023-04-22 17:36:49 --> UTF-8 Support Enabled
INFO - 2023-04-22 17:36:49 --> Utf8 Class Initialized
INFO - 2023-04-22 17:36:49 --> URI Class Initialized
INFO - 2023-04-22 17:36:49 --> Router Class Initialized
INFO - 2023-04-22 17:36:49 --> Output Class Initialized
INFO - 2023-04-22 17:36:49 --> Security Class Initialized
DEBUG - 2023-04-22 17:36:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-22 17:36:49 --> Input Class Initialized
INFO - 2023-04-22 17:36:49 --> Language Class Initialized
INFO - 2023-04-22 17:36:49 --> Loader Class Initialized
INFO - 2023-04-22 17:36:49 --> Helper loaded: url_helper
INFO - 2023-04-22 17:36:49 --> Helper loaded: file_helper
INFO - 2023-04-22 17:36:49 --> Helper loaded: html_helper
INFO - 2023-04-22 17:36:49 --> Helper loaded: text_helper
INFO - 2023-04-22 17:36:49 --> Helper loaded: form_helper
INFO - 2023-04-22 17:36:49 --> Helper loaded: lang_helper
INFO - 2023-04-22 17:36:49 --> Helper loaded: security_helper
INFO - 2023-04-22 17:36:49 --> Helper loaded: cookie_helper
INFO - 2023-04-22 17:36:49 --> Database Driver Class Initialized
INFO - 2023-04-22 17:36:49 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-22 17:36:49 --> Parser Class Initialized
INFO - 2023-04-22 17:36:49 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-22 17:36:49 --> Pagination Class Initialized
INFO - 2023-04-22 17:36:49 --> Form Validation Class Initialized
INFO - 2023-04-22 17:36:49 --> Controller Class Initialized
INFO - 2023-04-22 17:36:49 --> Model Class Initialized
DEBUG - 2023-04-22 17:36:49 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-04-22 17:36:49 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-22 17:36:49 --> Model Class Initialized
DEBUG - 2023-04-22 17:36:49 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-22 17:36:49 --> Model Class Initialized
INFO - 2023-04-22 17:36:49 --> Model Class Initialized
INFO - 2023-04-22 17:36:49 --> Final output sent to browser
DEBUG - 2023-04-22 17:36:49 --> Total execution time: 0.0203
ERROR - 2023-04-22 17:36:54 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-22 17:36:54 --> Config Class Initialized
INFO - 2023-04-22 17:36:54 --> Hooks Class Initialized
DEBUG - 2023-04-22 17:36:54 --> UTF-8 Support Enabled
INFO - 2023-04-22 17:36:54 --> Utf8 Class Initialized
INFO - 2023-04-22 17:36:54 --> URI Class Initialized
INFO - 2023-04-22 17:36:54 --> Router Class Initialized
INFO - 2023-04-22 17:36:54 --> Output Class Initialized
INFO - 2023-04-22 17:36:54 --> Security Class Initialized
DEBUG - 2023-04-22 17:36:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-22 17:36:54 --> Input Class Initialized
INFO - 2023-04-22 17:36:54 --> Language Class Initialized
INFO - 2023-04-22 17:36:54 --> Loader Class Initialized
INFO - 2023-04-22 17:36:54 --> Helper loaded: url_helper
INFO - 2023-04-22 17:36:54 --> Helper loaded: file_helper
INFO - 2023-04-22 17:36:54 --> Helper loaded: html_helper
INFO - 2023-04-22 17:36:54 --> Helper loaded: text_helper
INFO - 2023-04-22 17:36:54 --> Helper loaded: form_helper
INFO - 2023-04-22 17:36:54 --> Helper loaded: lang_helper
INFO - 2023-04-22 17:36:54 --> Helper loaded: security_helper
INFO - 2023-04-22 17:36:54 --> Helper loaded: cookie_helper
INFO - 2023-04-22 17:36:54 --> Database Driver Class Initialized
INFO - 2023-04-22 17:36:54 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-22 17:36:54 --> Parser Class Initialized
INFO - 2023-04-22 17:36:54 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-22 17:36:54 --> Pagination Class Initialized
INFO - 2023-04-22 17:36:54 --> Form Validation Class Initialized
INFO - 2023-04-22 17:36:54 --> Controller Class Initialized
INFO - 2023-04-22 17:36:54 --> Model Class Initialized
DEBUG - 2023-04-22 17:36:54 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-04-22 17:36:54 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-22 17:36:54 --> Model Class Initialized
DEBUG - 2023-04-22 17:36:54 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-22 17:36:54 --> Model Class Initialized
INFO - 2023-04-22 17:36:54 --> Final output sent to browser
DEBUG - 2023-04-22 17:36:54 --> Total execution time: 0.0174
ERROR - 2023-04-22 17:37:32 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-22 17:37:32 --> Config Class Initialized
INFO - 2023-04-22 17:37:32 --> Hooks Class Initialized
DEBUG - 2023-04-22 17:37:32 --> UTF-8 Support Enabled
INFO - 2023-04-22 17:37:32 --> Utf8 Class Initialized
INFO - 2023-04-22 17:37:32 --> URI Class Initialized
INFO - 2023-04-22 17:37:32 --> Router Class Initialized
INFO - 2023-04-22 17:37:32 --> Output Class Initialized
INFO - 2023-04-22 17:37:32 --> Security Class Initialized
DEBUG - 2023-04-22 17:37:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-22 17:37:32 --> Input Class Initialized
INFO - 2023-04-22 17:37:32 --> Language Class Initialized
INFO - 2023-04-22 17:37:32 --> Loader Class Initialized
INFO - 2023-04-22 17:37:32 --> Helper loaded: url_helper
INFO - 2023-04-22 17:37:32 --> Helper loaded: file_helper
INFO - 2023-04-22 17:37:32 --> Helper loaded: html_helper
INFO - 2023-04-22 17:37:32 --> Helper loaded: text_helper
INFO - 2023-04-22 17:37:32 --> Helper loaded: form_helper
INFO - 2023-04-22 17:37:32 --> Helper loaded: lang_helper
INFO - 2023-04-22 17:37:32 --> Helper loaded: security_helper
INFO - 2023-04-22 17:37:32 --> Helper loaded: cookie_helper
INFO - 2023-04-22 17:37:32 --> Database Driver Class Initialized
INFO - 2023-04-22 17:37:32 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-22 17:37:32 --> Parser Class Initialized
INFO - 2023-04-22 17:37:32 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-22 17:37:32 --> Pagination Class Initialized
INFO - 2023-04-22 17:37:32 --> Form Validation Class Initialized
INFO - 2023-04-22 17:37:32 --> Controller Class Initialized
INFO - 2023-04-22 17:37:32 --> Model Class Initialized
DEBUG - 2023-04-22 17:37:32 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-04-22 17:37:32 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-22 17:37:32 --> Model Class Initialized
DEBUG - 2023-04-22 17:37:32 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-22 17:37:32 --> Model Class Initialized
INFO - 2023-04-22 17:37:32 --> Final output sent to browser
DEBUG - 2023-04-22 17:37:32 --> Total execution time: 0.0214
ERROR - 2023-04-22 17:37:34 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-22 17:37:34 --> Config Class Initialized
INFO - 2023-04-22 17:37:34 --> Hooks Class Initialized
DEBUG - 2023-04-22 17:37:34 --> UTF-8 Support Enabled
INFO - 2023-04-22 17:37:34 --> Utf8 Class Initialized
INFO - 2023-04-22 17:37:34 --> URI Class Initialized
INFO - 2023-04-22 17:37:34 --> Router Class Initialized
INFO - 2023-04-22 17:37:34 --> Output Class Initialized
INFO - 2023-04-22 17:37:34 --> Security Class Initialized
DEBUG - 2023-04-22 17:37:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-22 17:37:34 --> Input Class Initialized
INFO - 2023-04-22 17:37:34 --> Language Class Initialized
INFO - 2023-04-22 17:37:34 --> Loader Class Initialized
INFO - 2023-04-22 17:37:34 --> Helper loaded: url_helper
INFO - 2023-04-22 17:37:34 --> Helper loaded: file_helper
INFO - 2023-04-22 17:37:34 --> Helper loaded: html_helper
INFO - 2023-04-22 17:37:34 --> Helper loaded: text_helper
INFO - 2023-04-22 17:37:34 --> Helper loaded: form_helper
INFO - 2023-04-22 17:37:34 --> Helper loaded: lang_helper
INFO - 2023-04-22 17:37:34 --> Helper loaded: security_helper
INFO - 2023-04-22 17:37:34 --> Helper loaded: cookie_helper
INFO - 2023-04-22 17:37:34 --> Database Driver Class Initialized
INFO - 2023-04-22 17:37:34 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-22 17:37:34 --> Parser Class Initialized
INFO - 2023-04-22 17:37:34 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-22 17:37:34 --> Pagination Class Initialized
INFO - 2023-04-22 17:37:34 --> Form Validation Class Initialized
INFO - 2023-04-22 17:37:34 --> Controller Class Initialized
INFO - 2023-04-22 17:37:34 --> Model Class Initialized
DEBUG - 2023-04-22 17:37:34 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-04-22 17:37:34 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-22 17:37:34 --> Model Class Initialized
DEBUG - 2023-04-22 17:37:34 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-22 17:37:34 --> Model Class Initialized
INFO - 2023-04-22 17:37:34 --> Final output sent to browser
DEBUG - 2023-04-22 17:37:34 --> Total execution time: 0.0179
ERROR - 2023-04-22 17:37:36 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-22 17:37:36 --> Config Class Initialized
INFO - 2023-04-22 17:37:36 --> Hooks Class Initialized
DEBUG - 2023-04-22 17:37:36 --> UTF-8 Support Enabled
INFO - 2023-04-22 17:37:36 --> Utf8 Class Initialized
INFO - 2023-04-22 17:37:36 --> URI Class Initialized
INFO - 2023-04-22 17:37:36 --> Router Class Initialized
INFO - 2023-04-22 17:37:36 --> Output Class Initialized
INFO - 2023-04-22 17:37:36 --> Security Class Initialized
DEBUG - 2023-04-22 17:37:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-22 17:37:36 --> Input Class Initialized
INFO - 2023-04-22 17:37:36 --> Language Class Initialized
INFO - 2023-04-22 17:37:36 --> Loader Class Initialized
INFO - 2023-04-22 17:37:36 --> Helper loaded: url_helper
INFO - 2023-04-22 17:37:36 --> Helper loaded: file_helper
INFO - 2023-04-22 17:37:36 --> Helper loaded: html_helper
INFO - 2023-04-22 17:37:36 --> Helper loaded: text_helper
INFO - 2023-04-22 17:37:36 --> Helper loaded: form_helper
INFO - 2023-04-22 17:37:36 --> Helper loaded: lang_helper
INFO - 2023-04-22 17:37:36 --> Helper loaded: security_helper
INFO - 2023-04-22 17:37:36 --> Helper loaded: cookie_helper
INFO - 2023-04-22 17:37:36 --> Database Driver Class Initialized
INFO - 2023-04-22 17:37:36 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-22 17:37:36 --> Parser Class Initialized
INFO - 2023-04-22 17:37:36 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-22 17:37:36 --> Pagination Class Initialized
INFO - 2023-04-22 17:37:36 --> Form Validation Class Initialized
INFO - 2023-04-22 17:37:36 --> Controller Class Initialized
INFO - 2023-04-22 17:37:36 --> Model Class Initialized
DEBUG - 2023-04-22 17:37:36 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-04-22 17:37:36 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-22 17:37:36 --> Model Class Initialized
DEBUG - 2023-04-22 17:37:36 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-22 17:37:36 --> Model Class Initialized
INFO - 2023-04-22 17:37:36 --> Final output sent to browser
DEBUG - 2023-04-22 17:37:36 --> Total execution time: 0.0177
ERROR - 2023-04-22 17:37:38 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-22 17:37:38 --> Config Class Initialized
INFO - 2023-04-22 17:37:38 --> Hooks Class Initialized
DEBUG - 2023-04-22 17:37:38 --> UTF-8 Support Enabled
INFO - 2023-04-22 17:37:38 --> Utf8 Class Initialized
INFO - 2023-04-22 17:37:38 --> URI Class Initialized
INFO - 2023-04-22 17:37:38 --> Router Class Initialized
INFO - 2023-04-22 17:37:38 --> Output Class Initialized
INFO - 2023-04-22 17:37:38 --> Security Class Initialized
DEBUG - 2023-04-22 17:37:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-22 17:37:38 --> Input Class Initialized
INFO - 2023-04-22 17:37:38 --> Language Class Initialized
INFO - 2023-04-22 17:37:38 --> Loader Class Initialized
INFO - 2023-04-22 17:37:38 --> Helper loaded: url_helper
INFO - 2023-04-22 17:37:38 --> Helper loaded: file_helper
INFO - 2023-04-22 17:37:38 --> Helper loaded: html_helper
INFO - 2023-04-22 17:37:38 --> Helper loaded: text_helper
INFO - 2023-04-22 17:37:38 --> Helper loaded: form_helper
INFO - 2023-04-22 17:37:38 --> Helper loaded: lang_helper
INFO - 2023-04-22 17:37:38 --> Helper loaded: security_helper
INFO - 2023-04-22 17:37:38 --> Helper loaded: cookie_helper
INFO - 2023-04-22 17:37:38 --> Database Driver Class Initialized
INFO - 2023-04-22 17:37:38 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-22 17:37:38 --> Parser Class Initialized
INFO - 2023-04-22 17:37:38 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-22 17:37:38 --> Pagination Class Initialized
INFO - 2023-04-22 17:37:38 --> Form Validation Class Initialized
INFO - 2023-04-22 17:37:38 --> Controller Class Initialized
INFO - 2023-04-22 17:37:38 --> Model Class Initialized
DEBUG - 2023-04-22 17:37:38 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-04-22 17:37:38 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-22 17:37:38 --> Model Class Initialized
DEBUG - 2023-04-22 17:37:38 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-22 17:37:38 --> Model Class Initialized
INFO - 2023-04-22 17:37:38 --> Final output sent to browser
DEBUG - 2023-04-22 17:37:38 --> Total execution time: 0.0167
ERROR - 2023-04-22 17:37:39 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-22 17:37:39 --> Config Class Initialized
INFO - 2023-04-22 17:37:39 --> Hooks Class Initialized
DEBUG - 2023-04-22 17:37:39 --> UTF-8 Support Enabled
INFO - 2023-04-22 17:37:39 --> Utf8 Class Initialized
INFO - 2023-04-22 17:37:39 --> URI Class Initialized
INFO - 2023-04-22 17:37:39 --> Router Class Initialized
INFO - 2023-04-22 17:37:39 --> Output Class Initialized
INFO - 2023-04-22 17:37:39 --> Security Class Initialized
DEBUG - 2023-04-22 17:37:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-22 17:37:39 --> Input Class Initialized
INFO - 2023-04-22 17:37:39 --> Language Class Initialized
INFO - 2023-04-22 17:37:39 --> Loader Class Initialized
INFO - 2023-04-22 17:37:39 --> Helper loaded: url_helper
INFO - 2023-04-22 17:37:39 --> Helper loaded: file_helper
INFO - 2023-04-22 17:37:39 --> Helper loaded: html_helper
INFO - 2023-04-22 17:37:39 --> Helper loaded: text_helper
INFO - 2023-04-22 17:37:39 --> Helper loaded: form_helper
INFO - 2023-04-22 17:37:39 --> Helper loaded: lang_helper
INFO - 2023-04-22 17:37:39 --> Helper loaded: security_helper
INFO - 2023-04-22 17:37:39 --> Helper loaded: cookie_helper
INFO - 2023-04-22 17:37:39 --> Database Driver Class Initialized
INFO - 2023-04-22 17:37:39 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-22 17:37:39 --> Parser Class Initialized
INFO - 2023-04-22 17:37:39 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-22 17:37:39 --> Pagination Class Initialized
INFO - 2023-04-22 17:37:39 --> Form Validation Class Initialized
INFO - 2023-04-22 17:37:39 --> Controller Class Initialized
INFO - 2023-04-22 17:37:39 --> Model Class Initialized
DEBUG - 2023-04-22 17:37:39 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-04-22 17:37:39 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-22 17:37:39 --> Model Class Initialized
DEBUG - 2023-04-22 17:37:39 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-22 17:37:39 --> Model Class Initialized
INFO - 2023-04-22 17:37:39 --> Final output sent to browser
DEBUG - 2023-04-22 17:37:39 --> Total execution time: 0.0165
ERROR - 2023-04-22 17:37:40 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-22 17:37:40 --> Config Class Initialized
INFO - 2023-04-22 17:37:40 --> Hooks Class Initialized
DEBUG - 2023-04-22 17:37:40 --> UTF-8 Support Enabled
INFO - 2023-04-22 17:37:40 --> Utf8 Class Initialized
INFO - 2023-04-22 17:37:40 --> URI Class Initialized
INFO - 2023-04-22 17:37:40 --> Router Class Initialized
INFO - 2023-04-22 17:37:40 --> Output Class Initialized
INFO - 2023-04-22 17:37:40 --> Security Class Initialized
DEBUG - 2023-04-22 17:37:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-22 17:37:40 --> Input Class Initialized
INFO - 2023-04-22 17:37:40 --> Language Class Initialized
INFO - 2023-04-22 17:37:40 --> Loader Class Initialized
INFO - 2023-04-22 17:37:40 --> Helper loaded: url_helper
INFO - 2023-04-22 17:37:40 --> Helper loaded: file_helper
INFO - 2023-04-22 17:37:40 --> Helper loaded: html_helper
INFO - 2023-04-22 17:37:40 --> Helper loaded: text_helper
INFO - 2023-04-22 17:37:40 --> Helper loaded: form_helper
INFO - 2023-04-22 17:37:40 --> Helper loaded: lang_helper
INFO - 2023-04-22 17:37:40 --> Helper loaded: security_helper
INFO - 2023-04-22 17:37:40 --> Helper loaded: cookie_helper
INFO - 2023-04-22 17:37:40 --> Database Driver Class Initialized
INFO - 2023-04-22 17:37:40 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-22 17:37:40 --> Parser Class Initialized
INFO - 2023-04-22 17:37:40 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-22 17:37:40 --> Pagination Class Initialized
INFO - 2023-04-22 17:37:40 --> Form Validation Class Initialized
INFO - 2023-04-22 17:37:40 --> Controller Class Initialized
INFO - 2023-04-22 17:37:40 --> Model Class Initialized
DEBUG - 2023-04-22 17:37:40 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-04-22 17:37:40 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-22 17:37:40 --> Model Class Initialized
DEBUG - 2023-04-22 17:37:40 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-22 17:37:40 --> Model Class Initialized
INFO - 2023-04-22 17:37:40 --> Final output sent to browser
DEBUG - 2023-04-22 17:37:40 --> Total execution time: 0.0170
ERROR - 2023-04-22 17:37:40 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-22 17:37:40 --> Config Class Initialized
INFO - 2023-04-22 17:37:40 --> Hooks Class Initialized
DEBUG - 2023-04-22 17:37:40 --> UTF-8 Support Enabled
INFO - 2023-04-22 17:37:40 --> Utf8 Class Initialized
INFO - 2023-04-22 17:37:40 --> URI Class Initialized
INFO - 2023-04-22 17:37:40 --> Router Class Initialized
INFO - 2023-04-22 17:37:40 --> Output Class Initialized
INFO - 2023-04-22 17:37:40 --> Security Class Initialized
DEBUG - 2023-04-22 17:37:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-22 17:37:40 --> Input Class Initialized
INFO - 2023-04-22 17:37:40 --> Language Class Initialized
INFO - 2023-04-22 17:37:40 --> Loader Class Initialized
INFO - 2023-04-22 17:37:40 --> Helper loaded: url_helper
INFO - 2023-04-22 17:37:40 --> Helper loaded: file_helper
INFO - 2023-04-22 17:37:40 --> Helper loaded: html_helper
INFO - 2023-04-22 17:37:40 --> Helper loaded: text_helper
INFO - 2023-04-22 17:37:40 --> Helper loaded: form_helper
INFO - 2023-04-22 17:37:40 --> Helper loaded: lang_helper
INFO - 2023-04-22 17:37:40 --> Helper loaded: security_helper
INFO - 2023-04-22 17:37:40 --> Helper loaded: cookie_helper
INFO - 2023-04-22 17:37:40 --> Database Driver Class Initialized
INFO - 2023-04-22 17:37:40 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-22 17:37:40 --> Parser Class Initialized
INFO - 2023-04-22 17:37:40 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-22 17:37:40 --> Pagination Class Initialized
INFO - 2023-04-22 17:37:40 --> Form Validation Class Initialized
INFO - 2023-04-22 17:37:40 --> Controller Class Initialized
INFO - 2023-04-22 17:37:40 --> Model Class Initialized
DEBUG - 2023-04-22 17:37:40 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-04-22 17:37:40 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-22 17:37:40 --> Model Class Initialized
DEBUG - 2023-04-22 17:37:40 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-22 17:37:40 --> Model Class Initialized
INFO - 2023-04-22 17:37:40 --> Final output sent to browser
DEBUG - 2023-04-22 17:37:40 --> Total execution time: 0.0174
ERROR - 2023-04-22 17:37:49 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-22 17:37:49 --> Config Class Initialized
INFO - 2023-04-22 17:37:49 --> Hooks Class Initialized
DEBUG - 2023-04-22 17:37:49 --> UTF-8 Support Enabled
INFO - 2023-04-22 17:37:49 --> Utf8 Class Initialized
INFO - 2023-04-22 17:37:49 --> URI Class Initialized
INFO - 2023-04-22 17:37:49 --> Router Class Initialized
INFO - 2023-04-22 17:37:49 --> Output Class Initialized
INFO - 2023-04-22 17:37:49 --> Security Class Initialized
DEBUG - 2023-04-22 17:37:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-22 17:37:49 --> Input Class Initialized
INFO - 2023-04-22 17:37:49 --> Language Class Initialized
INFO - 2023-04-22 17:37:49 --> Loader Class Initialized
INFO - 2023-04-22 17:37:49 --> Helper loaded: url_helper
INFO - 2023-04-22 17:37:49 --> Helper loaded: file_helper
INFO - 2023-04-22 17:37:49 --> Helper loaded: html_helper
INFO - 2023-04-22 17:37:49 --> Helper loaded: text_helper
INFO - 2023-04-22 17:37:49 --> Helper loaded: form_helper
INFO - 2023-04-22 17:37:49 --> Helper loaded: lang_helper
INFO - 2023-04-22 17:37:49 --> Helper loaded: security_helper
INFO - 2023-04-22 17:37:49 --> Helper loaded: cookie_helper
INFO - 2023-04-22 17:37:49 --> Database Driver Class Initialized
INFO - 2023-04-22 17:37:49 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-22 17:37:49 --> Parser Class Initialized
INFO - 2023-04-22 17:37:49 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-22 17:37:49 --> Pagination Class Initialized
INFO - 2023-04-22 17:37:49 --> Form Validation Class Initialized
INFO - 2023-04-22 17:37:49 --> Controller Class Initialized
INFO - 2023-04-22 17:37:49 --> Model Class Initialized
DEBUG - 2023-04-22 17:37:49 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-04-22 17:37:49 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-22 17:37:49 --> Model Class Initialized
DEBUG - 2023-04-22 17:37:49 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-22 17:37:49 --> Model Class Initialized
INFO - 2023-04-22 17:37:49 --> Model Class Initialized
INFO - 2023-04-22 17:37:49 --> Final output sent to browser
DEBUG - 2023-04-22 17:37:49 --> Total execution time: 0.0210
ERROR - 2023-04-22 17:37:52 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-22 17:37:52 --> Config Class Initialized
INFO - 2023-04-22 17:37:52 --> Hooks Class Initialized
DEBUG - 2023-04-22 17:37:52 --> UTF-8 Support Enabled
INFO - 2023-04-22 17:37:52 --> Utf8 Class Initialized
INFO - 2023-04-22 17:37:52 --> URI Class Initialized
INFO - 2023-04-22 17:37:52 --> Router Class Initialized
INFO - 2023-04-22 17:37:52 --> Output Class Initialized
INFO - 2023-04-22 17:37:52 --> Security Class Initialized
DEBUG - 2023-04-22 17:37:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-22 17:37:52 --> Input Class Initialized
INFO - 2023-04-22 17:37:52 --> Language Class Initialized
INFO - 2023-04-22 17:37:52 --> Loader Class Initialized
INFO - 2023-04-22 17:37:52 --> Helper loaded: url_helper
INFO - 2023-04-22 17:37:52 --> Helper loaded: file_helper
INFO - 2023-04-22 17:37:52 --> Helper loaded: html_helper
INFO - 2023-04-22 17:37:52 --> Helper loaded: text_helper
INFO - 2023-04-22 17:37:52 --> Helper loaded: form_helper
INFO - 2023-04-22 17:37:52 --> Helper loaded: lang_helper
INFO - 2023-04-22 17:37:52 --> Helper loaded: security_helper
INFO - 2023-04-22 17:37:52 --> Helper loaded: cookie_helper
INFO - 2023-04-22 17:37:52 --> Database Driver Class Initialized
INFO - 2023-04-22 17:37:52 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-22 17:37:52 --> Parser Class Initialized
INFO - 2023-04-22 17:37:52 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-22 17:37:52 --> Pagination Class Initialized
INFO - 2023-04-22 17:37:52 --> Form Validation Class Initialized
INFO - 2023-04-22 17:37:52 --> Controller Class Initialized
INFO - 2023-04-22 17:37:52 --> Model Class Initialized
DEBUG - 2023-04-22 17:37:52 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-04-22 17:37:52 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-22 17:37:52 --> Model Class Initialized
DEBUG - 2023-04-22 17:37:52 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-22 17:37:52 --> Model Class Initialized
INFO - 2023-04-22 17:37:52 --> Final output sent to browser
DEBUG - 2023-04-22 17:37:52 --> Total execution time: 0.0217
ERROR - 2023-04-22 17:38:05 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-22 17:38:05 --> Config Class Initialized
INFO - 2023-04-22 17:38:05 --> Hooks Class Initialized
DEBUG - 2023-04-22 17:38:05 --> UTF-8 Support Enabled
INFO - 2023-04-22 17:38:05 --> Utf8 Class Initialized
INFO - 2023-04-22 17:38:05 --> URI Class Initialized
INFO - 2023-04-22 17:38:05 --> Router Class Initialized
INFO - 2023-04-22 17:38:05 --> Output Class Initialized
INFO - 2023-04-22 17:38:05 --> Security Class Initialized
DEBUG - 2023-04-22 17:38:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-22 17:38:05 --> Input Class Initialized
INFO - 2023-04-22 17:38:05 --> Language Class Initialized
INFO - 2023-04-22 17:38:05 --> Loader Class Initialized
INFO - 2023-04-22 17:38:05 --> Helper loaded: url_helper
INFO - 2023-04-22 17:38:05 --> Helper loaded: file_helper
INFO - 2023-04-22 17:38:05 --> Helper loaded: html_helper
INFO - 2023-04-22 17:38:05 --> Helper loaded: text_helper
INFO - 2023-04-22 17:38:05 --> Helper loaded: form_helper
INFO - 2023-04-22 17:38:05 --> Helper loaded: lang_helper
INFO - 2023-04-22 17:38:05 --> Helper loaded: security_helper
INFO - 2023-04-22 17:38:05 --> Helper loaded: cookie_helper
INFO - 2023-04-22 17:38:05 --> Database Driver Class Initialized
INFO - 2023-04-22 17:38:05 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-22 17:38:05 --> Parser Class Initialized
INFO - 2023-04-22 17:38:05 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-22 17:38:05 --> Pagination Class Initialized
INFO - 2023-04-22 17:38:05 --> Form Validation Class Initialized
INFO - 2023-04-22 17:38:05 --> Controller Class Initialized
INFO - 2023-04-22 17:38:05 --> Model Class Initialized
DEBUG - 2023-04-22 17:38:05 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-04-22 17:38:05 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-22 17:38:05 --> Model Class Initialized
DEBUG - 2023-04-22 17:38:05 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-22 17:38:05 --> Model Class Initialized
INFO - 2023-04-22 17:38:05 --> Final output sent to browser
DEBUG - 2023-04-22 17:38:05 --> Total execution time: 0.0207
ERROR - 2023-04-22 17:38:05 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-22 17:38:05 --> Config Class Initialized
INFO - 2023-04-22 17:38:05 --> Hooks Class Initialized
DEBUG - 2023-04-22 17:38:05 --> UTF-8 Support Enabled
INFO - 2023-04-22 17:38:05 --> Utf8 Class Initialized
INFO - 2023-04-22 17:38:05 --> URI Class Initialized
INFO - 2023-04-22 17:38:05 --> Router Class Initialized
INFO - 2023-04-22 17:38:05 --> Output Class Initialized
INFO - 2023-04-22 17:38:05 --> Security Class Initialized
DEBUG - 2023-04-22 17:38:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-22 17:38:05 --> Input Class Initialized
INFO - 2023-04-22 17:38:05 --> Language Class Initialized
INFO - 2023-04-22 17:38:05 --> Loader Class Initialized
INFO - 2023-04-22 17:38:05 --> Helper loaded: url_helper
INFO - 2023-04-22 17:38:05 --> Helper loaded: file_helper
INFO - 2023-04-22 17:38:05 --> Helper loaded: html_helper
INFO - 2023-04-22 17:38:05 --> Helper loaded: text_helper
INFO - 2023-04-22 17:38:05 --> Helper loaded: form_helper
INFO - 2023-04-22 17:38:05 --> Helper loaded: lang_helper
INFO - 2023-04-22 17:38:05 --> Helper loaded: security_helper
INFO - 2023-04-22 17:38:05 --> Helper loaded: cookie_helper
INFO - 2023-04-22 17:38:05 --> Database Driver Class Initialized
INFO - 2023-04-22 17:38:05 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-22 17:38:05 --> Parser Class Initialized
INFO - 2023-04-22 17:38:05 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-22 17:38:05 --> Pagination Class Initialized
INFO - 2023-04-22 17:38:05 --> Form Validation Class Initialized
INFO - 2023-04-22 17:38:05 --> Controller Class Initialized
INFO - 2023-04-22 17:38:05 --> Model Class Initialized
DEBUG - 2023-04-22 17:38:05 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-04-22 17:38:05 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-22 17:38:05 --> Model Class Initialized
DEBUG - 2023-04-22 17:38:05 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-22 17:38:05 --> Model Class Initialized
INFO - 2023-04-22 17:38:05 --> Final output sent to browser
DEBUG - 2023-04-22 17:38:05 --> Total execution time: 0.0167
ERROR - 2023-04-22 17:38:06 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-22 17:38:06 --> Config Class Initialized
INFO - 2023-04-22 17:38:06 --> Hooks Class Initialized
DEBUG - 2023-04-22 17:38:06 --> UTF-8 Support Enabled
INFO - 2023-04-22 17:38:06 --> Utf8 Class Initialized
INFO - 2023-04-22 17:38:06 --> URI Class Initialized
INFO - 2023-04-22 17:38:06 --> Router Class Initialized
INFO - 2023-04-22 17:38:06 --> Output Class Initialized
INFO - 2023-04-22 17:38:06 --> Security Class Initialized
DEBUG - 2023-04-22 17:38:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-22 17:38:06 --> Input Class Initialized
INFO - 2023-04-22 17:38:06 --> Language Class Initialized
INFO - 2023-04-22 17:38:06 --> Loader Class Initialized
INFO - 2023-04-22 17:38:06 --> Helper loaded: url_helper
INFO - 2023-04-22 17:38:06 --> Helper loaded: file_helper
INFO - 2023-04-22 17:38:06 --> Helper loaded: html_helper
INFO - 2023-04-22 17:38:06 --> Helper loaded: text_helper
INFO - 2023-04-22 17:38:06 --> Helper loaded: form_helper
INFO - 2023-04-22 17:38:06 --> Helper loaded: lang_helper
INFO - 2023-04-22 17:38:06 --> Helper loaded: security_helper
INFO - 2023-04-22 17:38:06 --> Helper loaded: cookie_helper
INFO - 2023-04-22 17:38:06 --> Database Driver Class Initialized
INFO - 2023-04-22 17:38:06 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-22 17:38:06 --> Parser Class Initialized
INFO - 2023-04-22 17:38:06 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-22 17:38:06 --> Pagination Class Initialized
INFO - 2023-04-22 17:38:06 --> Form Validation Class Initialized
INFO - 2023-04-22 17:38:06 --> Controller Class Initialized
INFO - 2023-04-22 17:38:06 --> Model Class Initialized
DEBUG - 2023-04-22 17:38:06 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-04-22 17:38:06 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-22 17:38:06 --> Model Class Initialized
DEBUG - 2023-04-22 17:38:06 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-22 17:38:06 --> Model Class Initialized
INFO - 2023-04-22 17:38:06 --> Final output sent to browser
DEBUG - 2023-04-22 17:38:06 --> Total execution time: 0.0179
ERROR - 2023-04-22 17:38:19 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-22 17:38:19 --> Config Class Initialized
INFO - 2023-04-22 17:38:19 --> Hooks Class Initialized
DEBUG - 2023-04-22 17:38:19 --> UTF-8 Support Enabled
INFO - 2023-04-22 17:38:19 --> Utf8 Class Initialized
INFO - 2023-04-22 17:38:19 --> URI Class Initialized
INFO - 2023-04-22 17:38:19 --> Router Class Initialized
INFO - 2023-04-22 17:38:19 --> Output Class Initialized
INFO - 2023-04-22 17:38:19 --> Security Class Initialized
DEBUG - 2023-04-22 17:38:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-22 17:38:19 --> Input Class Initialized
INFO - 2023-04-22 17:38:19 --> Language Class Initialized
INFO - 2023-04-22 17:38:19 --> Loader Class Initialized
INFO - 2023-04-22 17:38:19 --> Helper loaded: url_helper
INFO - 2023-04-22 17:38:19 --> Helper loaded: file_helper
INFO - 2023-04-22 17:38:19 --> Helper loaded: html_helper
INFO - 2023-04-22 17:38:19 --> Helper loaded: text_helper
INFO - 2023-04-22 17:38:19 --> Helper loaded: form_helper
INFO - 2023-04-22 17:38:19 --> Helper loaded: lang_helper
INFO - 2023-04-22 17:38:19 --> Helper loaded: security_helper
INFO - 2023-04-22 17:38:19 --> Helper loaded: cookie_helper
INFO - 2023-04-22 17:38:19 --> Database Driver Class Initialized
INFO - 2023-04-22 17:38:19 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-22 17:38:19 --> Parser Class Initialized
INFO - 2023-04-22 17:38:19 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-22 17:38:19 --> Pagination Class Initialized
INFO - 2023-04-22 17:38:19 --> Form Validation Class Initialized
INFO - 2023-04-22 17:38:19 --> Controller Class Initialized
INFO - 2023-04-22 17:38:19 --> Model Class Initialized
DEBUG - 2023-04-22 17:38:19 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-04-22 17:38:19 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-22 17:38:19 --> Model Class Initialized
DEBUG - 2023-04-22 17:38:19 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-22 17:38:19 --> Model Class Initialized
INFO - 2023-04-22 17:38:19 --> Model Class Initialized
INFO - 2023-04-22 17:38:19 --> Final output sent to browser
DEBUG - 2023-04-22 17:38:19 --> Total execution time: 0.0242
ERROR - 2023-04-22 17:38:22 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-22 17:38:22 --> Config Class Initialized
INFO - 2023-04-22 17:38:22 --> Hooks Class Initialized
DEBUG - 2023-04-22 17:38:22 --> UTF-8 Support Enabled
INFO - 2023-04-22 17:38:22 --> Utf8 Class Initialized
INFO - 2023-04-22 17:38:22 --> URI Class Initialized
INFO - 2023-04-22 17:38:22 --> Router Class Initialized
INFO - 2023-04-22 17:38:22 --> Output Class Initialized
INFO - 2023-04-22 17:38:22 --> Security Class Initialized
DEBUG - 2023-04-22 17:38:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-22 17:38:22 --> Input Class Initialized
INFO - 2023-04-22 17:38:22 --> Language Class Initialized
INFO - 2023-04-22 17:38:22 --> Loader Class Initialized
INFO - 2023-04-22 17:38:22 --> Helper loaded: url_helper
INFO - 2023-04-22 17:38:22 --> Helper loaded: file_helper
INFO - 2023-04-22 17:38:22 --> Helper loaded: html_helper
INFO - 2023-04-22 17:38:22 --> Helper loaded: text_helper
INFO - 2023-04-22 17:38:22 --> Helper loaded: form_helper
INFO - 2023-04-22 17:38:22 --> Helper loaded: lang_helper
INFO - 2023-04-22 17:38:22 --> Helper loaded: security_helper
INFO - 2023-04-22 17:38:22 --> Helper loaded: cookie_helper
INFO - 2023-04-22 17:38:22 --> Database Driver Class Initialized
INFO - 2023-04-22 17:38:22 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-22 17:38:22 --> Parser Class Initialized
INFO - 2023-04-22 17:38:22 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-22 17:38:22 --> Pagination Class Initialized
INFO - 2023-04-22 17:38:22 --> Form Validation Class Initialized
INFO - 2023-04-22 17:38:22 --> Controller Class Initialized
INFO - 2023-04-22 17:38:22 --> Model Class Initialized
DEBUG - 2023-04-22 17:38:22 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-04-22 17:38:22 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-22 17:38:22 --> Model Class Initialized
DEBUG - 2023-04-22 17:38:22 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-22 17:38:22 --> Model Class Initialized
INFO - 2023-04-22 17:38:22 --> Final output sent to browser
DEBUG - 2023-04-22 17:38:22 --> Total execution time: 0.0181
ERROR - 2023-04-22 17:38:32 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-22 17:38:32 --> Config Class Initialized
INFO - 2023-04-22 17:38:32 --> Hooks Class Initialized
DEBUG - 2023-04-22 17:38:32 --> UTF-8 Support Enabled
INFO - 2023-04-22 17:38:32 --> Utf8 Class Initialized
INFO - 2023-04-22 17:38:32 --> URI Class Initialized
INFO - 2023-04-22 17:38:32 --> Router Class Initialized
INFO - 2023-04-22 17:38:32 --> Output Class Initialized
INFO - 2023-04-22 17:38:32 --> Security Class Initialized
DEBUG - 2023-04-22 17:38:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-22 17:38:32 --> Input Class Initialized
INFO - 2023-04-22 17:38:32 --> Language Class Initialized
INFO - 2023-04-22 17:38:32 --> Loader Class Initialized
INFO - 2023-04-22 17:38:32 --> Helper loaded: url_helper
INFO - 2023-04-22 17:38:32 --> Helper loaded: file_helper
INFO - 2023-04-22 17:38:32 --> Helper loaded: html_helper
INFO - 2023-04-22 17:38:32 --> Helper loaded: text_helper
INFO - 2023-04-22 17:38:32 --> Helper loaded: form_helper
INFO - 2023-04-22 17:38:32 --> Helper loaded: lang_helper
INFO - 2023-04-22 17:38:32 --> Helper loaded: security_helper
INFO - 2023-04-22 17:38:32 --> Helper loaded: cookie_helper
INFO - 2023-04-22 17:38:32 --> Database Driver Class Initialized
INFO - 2023-04-22 17:38:32 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-22 17:38:32 --> Parser Class Initialized
INFO - 2023-04-22 17:38:32 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-22 17:38:32 --> Pagination Class Initialized
INFO - 2023-04-22 17:38:32 --> Form Validation Class Initialized
INFO - 2023-04-22 17:38:32 --> Controller Class Initialized
INFO - 2023-04-22 17:38:32 --> Model Class Initialized
DEBUG - 2023-04-22 17:38:32 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-04-22 17:38:32 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-22 17:38:32 --> Model Class Initialized
INFO - 2023-04-22 17:38:32 --> Email Class Initialized
INFO - 2023-04-22 17:38:32 --> Language file loaded: language/english/email_lang.php
ERROR - 2023-04-22 17:38:33 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-22 17:38:33 --> Config Class Initialized
INFO - 2023-04-22 17:38:33 --> Hooks Class Initialized
DEBUG - 2023-04-22 17:38:33 --> UTF-8 Support Enabled
INFO - 2023-04-22 17:38:33 --> Utf8 Class Initialized
INFO - 2023-04-22 17:38:33 --> URI Class Initialized
INFO - 2023-04-22 17:38:33 --> Router Class Initialized
INFO - 2023-04-22 17:38:33 --> Output Class Initialized
INFO - 2023-04-22 17:38:33 --> Security Class Initialized
DEBUG - 2023-04-22 17:38:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-22 17:38:33 --> Input Class Initialized
INFO - 2023-04-22 17:38:33 --> Language Class Initialized
INFO - 2023-04-22 17:38:33 --> Loader Class Initialized
INFO - 2023-04-22 17:38:33 --> Helper loaded: url_helper
INFO - 2023-04-22 17:38:33 --> Helper loaded: file_helper
INFO - 2023-04-22 17:38:33 --> Helper loaded: html_helper
INFO - 2023-04-22 17:38:33 --> Helper loaded: text_helper
INFO - 2023-04-22 17:38:33 --> Helper loaded: form_helper
INFO - 2023-04-22 17:38:33 --> Helper loaded: lang_helper
INFO - 2023-04-22 17:38:33 --> Helper loaded: security_helper
INFO - 2023-04-22 17:38:33 --> Helper loaded: cookie_helper
INFO - 2023-04-22 17:38:33 --> Database Driver Class Initialized
INFO - 2023-04-22 17:38:33 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-22 17:38:33 --> Parser Class Initialized
INFO - 2023-04-22 17:38:33 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-22 17:38:33 --> Pagination Class Initialized
INFO - 2023-04-22 17:38:33 --> Form Validation Class Initialized
INFO - 2023-04-22 17:38:33 --> Controller Class Initialized
INFO - 2023-04-22 17:38:33 --> Model Class Initialized
DEBUG - 2023-04-22 17:38:33 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-04-22 17:38:33 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-22 17:38:33 --> Model Class Initialized
DEBUG - 2023-04-22 17:38:33 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-22 17:38:33 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/stockrequest/stockrequest_html.php
DEBUG - 2023-04-22 17:38:33 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-04-22 17:38:33 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-04-22 17:38:33 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-04-22 17:38:33 --> Model Class Initialized
INFO - 2023-04-22 17:38:33 --> Model Class Initialized
INFO - 2023-04-22 17:38:33 --> Model Class Initialized
INFO - 2023-04-22 17:38:33 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-04-22 17:38:33 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-04-22 17:38:33 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-04-22 17:38:33 --> Final output sent to browser
DEBUG - 2023-04-22 17:38:33 --> Total execution time: 0.1722
ERROR - 2023-04-22 17:39:03 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-22 17:39:03 --> Config Class Initialized
INFO - 2023-04-22 17:39:03 --> Hooks Class Initialized
DEBUG - 2023-04-22 17:39:03 --> UTF-8 Support Enabled
INFO - 2023-04-22 17:39:03 --> Utf8 Class Initialized
INFO - 2023-04-22 17:39:03 --> URI Class Initialized
INFO - 2023-04-22 17:39:03 --> Router Class Initialized
INFO - 2023-04-22 17:39:03 --> Output Class Initialized
INFO - 2023-04-22 17:39:03 --> Security Class Initialized
DEBUG - 2023-04-22 17:39:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-22 17:39:03 --> Input Class Initialized
INFO - 2023-04-22 17:39:03 --> Language Class Initialized
INFO - 2023-04-22 17:39:03 --> Loader Class Initialized
INFO - 2023-04-22 17:39:03 --> Helper loaded: url_helper
INFO - 2023-04-22 17:39:03 --> Helper loaded: file_helper
INFO - 2023-04-22 17:39:03 --> Helper loaded: html_helper
INFO - 2023-04-22 17:39:03 --> Helper loaded: text_helper
INFO - 2023-04-22 17:39:03 --> Helper loaded: form_helper
INFO - 2023-04-22 17:39:03 --> Helper loaded: lang_helper
INFO - 2023-04-22 17:39:03 --> Helper loaded: security_helper
INFO - 2023-04-22 17:39:03 --> Helper loaded: cookie_helper
INFO - 2023-04-22 17:39:03 --> Database Driver Class Initialized
INFO - 2023-04-22 17:39:03 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-22 17:39:03 --> Parser Class Initialized
INFO - 2023-04-22 17:39:03 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-22 17:39:03 --> Pagination Class Initialized
INFO - 2023-04-22 17:39:03 --> Form Validation Class Initialized
INFO - 2023-04-22 17:39:03 --> Controller Class Initialized
INFO - 2023-04-22 17:39:03 --> Model Class Initialized
DEBUG - 2023-04-22 17:39:03 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-04-22 17:39:03 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-22 17:39:03 --> Model Class Initialized
DEBUG - 2023-04-22 17:39:03 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-22 17:39:03 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/stockrequest/add_stockrequest_form.php
DEBUG - 2023-04-22 17:39:03 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-04-22 17:39:03 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-04-22 17:39:03 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-04-22 17:39:03 --> Model Class Initialized
INFO - 2023-04-22 17:39:03 --> Model Class Initialized
INFO - 2023-04-22 17:39:03 --> Model Class Initialized
INFO - 2023-04-22 17:39:03 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-04-22 17:39:03 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-04-22 17:39:03 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-04-22 17:39:03 --> Final output sent to browser
DEBUG - 2023-04-22 17:39:03 --> Total execution time: 0.1526
ERROR - 2023-04-22 17:39:09 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-22 17:39:09 --> Config Class Initialized
INFO - 2023-04-22 17:39:09 --> Hooks Class Initialized
DEBUG - 2023-04-22 17:39:09 --> UTF-8 Support Enabled
INFO - 2023-04-22 17:39:09 --> Utf8 Class Initialized
INFO - 2023-04-22 17:39:09 --> URI Class Initialized
INFO - 2023-04-22 17:39:09 --> Router Class Initialized
INFO - 2023-04-22 17:39:09 --> Output Class Initialized
INFO - 2023-04-22 17:39:09 --> Security Class Initialized
DEBUG - 2023-04-22 17:39:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-22 17:39:09 --> Input Class Initialized
INFO - 2023-04-22 17:39:09 --> Language Class Initialized
INFO - 2023-04-22 17:39:09 --> Loader Class Initialized
INFO - 2023-04-22 17:39:09 --> Helper loaded: url_helper
INFO - 2023-04-22 17:39:09 --> Helper loaded: file_helper
INFO - 2023-04-22 17:39:09 --> Helper loaded: html_helper
INFO - 2023-04-22 17:39:09 --> Helper loaded: text_helper
INFO - 2023-04-22 17:39:09 --> Helper loaded: form_helper
INFO - 2023-04-22 17:39:09 --> Helper loaded: lang_helper
INFO - 2023-04-22 17:39:09 --> Helper loaded: security_helper
INFO - 2023-04-22 17:39:09 --> Helper loaded: cookie_helper
INFO - 2023-04-22 17:39:09 --> Database Driver Class Initialized
INFO - 2023-04-22 17:39:09 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-22 17:39:09 --> Parser Class Initialized
INFO - 2023-04-22 17:39:09 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-22 17:39:09 --> Pagination Class Initialized
INFO - 2023-04-22 17:39:09 --> Form Validation Class Initialized
INFO - 2023-04-22 17:39:09 --> Controller Class Initialized
INFO - 2023-04-22 17:39:09 --> Model Class Initialized
INFO - 2023-04-22 17:39:09 --> Final output sent to browser
DEBUG - 2023-04-22 17:39:09 --> Total execution time: 0.0137
ERROR - 2023-04-22 17:39:10 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-22 17:39:10 --> Config Class Initialized
INFO - 2023-04-22 17:39:10 --> Hooks Class Initialized
DEBUG - 2023-04-22 17:39:10 --> UTF-8 Support Enabled
INFO - 2023-04-22 17:39:10 --> Utf8 Class Initialized
INFO - 2023-04-22 17:39:10 --> URI Class Initialized
INFO - 2023-04-22 17:39:10 --> Router Class Initialized
INFO - 2023-04-22 17:39:10 --> Output Class Initialized
INFO - 2023-04-22 17:39:10 --> Security Class Initialized
DEBUG - 2023-04-22 17:39:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-22 17:39:10 --> Input Class Initialized
INFO - 2023-04-22 17:39:10 --> Language Class Initialized
INFO - 2023-04-22 17:39:10 --> Loader Class Initialized
INFO - 2023-04-22 17:39:10 --> Helper loaded: url_helper
INFO - 2023-04-22 17:39:10 --> Helper loaded: file_helper
INFO - 2023-04-22 17:39:10 --> Helper loaded: html_helper
INFO - 2023-04-22 17:39:10 --> Helper loaded: text_helper
INFO - 2023-04-22 17:39:10 --> Helper loaded: form_helper
INFO - 2023-04-22 17:39:10 --> Helper loaded: lang_helper
INFO - 2023-04-22 17:39:10 --> Helper loaded: security_helper
INFO - 2023-04-22 17:39:10 --> Helper loaded: cookie_helper
INFO - 2023-04-22 17:39:10 --> Database Driver Class Initialized
INFO - 2023-04-22 17:39:10 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-22 17:39:10 --> Parser Class Initialized
INFO - 2023-04-22 17:39:10 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-22 17:39:10 --> Pagination Class Initialized
INFO - 2023-04-22 17:39:10 --> Form Validation Class Initialized
INFO - 2023-04-22 17:39:10 --> Controller Class Initialized
INFO - 2023-04-22 17:39:10 --> Model Class Initialized
INFO - 2023-04-22 17:39:10 --> Final output sent to browser
DEBUG - 2023-04-22 17:39:10 --> Total execution time: 0.0134
ERROR - 2023-04-22 17:39:10 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-22 17:39:10 --> Config Class Initialized
INFO - 2023-04-22 17:39:10 --> Hooks Class Initialized
DEBUG - 2023-04-22 17:39:10 --> UTF-8 Support Enabled
INFO - 2023-04-22 17:39:10 --> Utf8 Class Initialized
INFO - 2023-04-22 17:39:10 --> URI Class Initialized
INFO - 2023-04-22 17:39:10 --> Router Class Initialized
INFO - 2023-04-22 17:39:10 --> Output Class Initialized
INFO - 2023-04-22 17:39:10 --> Security Class Initialized
DEBUG - 2023-04-22 17:39:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-22 17:39:10 --> Input Class Initialized
INFO - 2023-04-22 17:39:10 --> Language Class Initialized
INFO - 2023-04-22 17:39:10 --> Loader Class Initialized
INFO - 2023-04-22 17:39:10 --> Helper loaded: url_helper
INFO - 2023-04-22 17:39:10 --> Helper loaded: file_helper
INFO - 2023-04-22 17:39:10 --> Helper loaded: html_helper
INFO - 2023-04-22 17:39:10 --> Helper loaded: text_helper
INFO - 2023-04-22 17:39:10 --> Helper loaded: form_helper
INFO - 2023-04-22 17:39:10 --> Helper loaded: lang_helper
INFO - 2023-04-22 17:39:10 --> Helper loaded: security_helper
INFO - 2023-04-22 17:39:10 --> Helper loaded: cookie_helper
INFO - 2023-04-22 17:39:10 --> Database Driver Class Initialized
INFO - 2023-04-22 17:39:10 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-22 17:39:10 --> Parser Class Initialized
INFO - 2023-04-22 17:39:10 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-22 17:39:10 --> Pagination Class Initialized
INFO - 2023-04-22 17:39:10 --> Form Validation Class Initialized
INFO - 2023-04-22 17:39:10 --> Controller Class Initialized
INFO - 2023-04-22 17:39:10 --> Model Class Initialized
INFO - 2023-04-22 17:39:10 --> Final output sent to browser
DEBUG - 2023-04-22 17:39:10 --> Total execution time: 0.0125
ERROR - 2023-04-22 17:39:11 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-22 17:39:11 --> Config Class Initialized
INFO - 2023-04-22 17:39:11 --> Hooks Class Initialized
DEBUG - 2023-04-22 17:39:11 --> UTF-8 Support Enabled
INFO - 2023-04-22 17:39:11 --> Utf8 Class Initialized
INFO - 2023-04-22 17:39:11 --> URI Class Initialized
INFO - 2023-04-22 17:39:11 --> Router Class Initialized
INFO - 2023-04-22 17:39:11 --> Output Class Initialized
INFO - 2023-04-22 17:39:11 --> Security Class Initialized
DEBUG - 2023-04-22 17:39:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-22 17:39:11 --> Input Class Initialized
INFO - 2023-04-22 17:39:11 --> Language Class Initialized
INFO - 2023-04-22 17:39:11 --> Loader Class Initialized
INFO - 2023-04-22 17:39:11 --> Helper loaded: url_helper
INFO - 2023-04-22 17:39:11 --> Helper loaded: file_helper
INFO - 2023-04-22 17:39:11 --> Helper loaded: html_helper
INFO - 2023-04-22 17:39:11 --> Helper loaded: text_helper
INFO - 2023-04-22 17:39:11 --> Helper loaded: form_helper
INFO - 2023-04-22 17:39:11 --> Helper loaded: lang_helper
INFO - 2023-04-22 17:39:11 --> Helper loaded: security_helper
INFO - 2023-04-22 17:39:11 --> Helper loaded: cookie_helper
INFO - 2023-04-22 17:39:11 --> Database Driver Class Initialized
INFO - 2023-04-22 17:39:11 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-22 17:39:11 --> Parser Class Initialized
INFO - 2023-04-22 17:39:11 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-22 17:39:11 --> Pagination Class Initialized
INFO - 2023-04-22 17:39:11 --> Form Validation Class Initialized
INFO - 2023-04-22 17:39:11 --> Controller Class Initialized
INFO - 2023-04-22 17:39:11 --> Model Class Initialized
ERROR - 2023-04-22 17:39:11 --> Severity: Warning --> Invalid argument supplied for foreach() /home/powera7m/app.maurnaturo.com/application/controllers/Cstockrequest.php 204
INFO - 2023-04-22 17:39:11 --> Final output sent to browser
DEBUG - 2023-04-22 17:39:11 --> Total execution time: 0.0175
ERROR - 2023-04-22 17:39:14 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-22 17:39:14 --> Config Class Initialized
INFO - 2023-04-22 17:39:14 --> Hooks Class Initialized
DEBUG - 2023-04-22 17:39:14 --> UTF-8 Support Enabled
INFO - 2023-04-22 17:39:14 --> Utf8 Class Initialized
INFO - 2023-04-22 17:39:14 --> URI Class Initialized
INFO - 2023-04-22 17:39:14 --> Router Class Initialized
INFO - 2023-04-22 17:39:14 --> Output Class Initialized
INFO - 2023-04-22 17:39:14 --> Security Class Initialized
DEBUG - 2023-04-22 17:39:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-22 17:39:14 --> Input Class Initialized
INFO - 2023-04-22 17:39:14 --> Language Class Initialized
INFO - 2023-04-22 17:39:14 --> Loader Class Initialized
INFO - 2023-04-22 17:39:14 --> Helper loaded: url_helper
INFO - 2023-04-22 17:39:14 --> Helper loaded: file_helper
INFO - 2023-04-22 17:39:14 --> Helper loaded: html_helper
INFO - 2023-04-22 17:39:14 --> Helper loaded: text_helper
INFO - 2023-04-22 17:39:14 --> Helper loaded: form_helper
INFO - 2023-04-22 17:39:14 --> Helper loaded: lang_helper
INFO - 2023-04-22 17:39:14 --> Helper loaded: security_helper
INFO - 2023-04-22 17:39:14 --> Helper loaded: cookie_helper
INFO - 2023-04-22 17:39:14 --> Database Driver Class Initialized
INFO - 2023-04-22 17:39:14 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-22 17:39:14 --> Parser Class Initialized
INFO - 2023-04-22 17:39:14 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-22 17:39:14 --> Pagination Class Initialized
INFO - 2023-04-22 17:39:14 --> Form Validation Class Initialized
INFO - 2023-04-22 17:39:14 --> Controller Class Initialized
INFO - 2023-04-22 17:39:14 --> Model Class Initialized
DEBUG - 2023-04-22 17:39:14 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-04-22 17:39:14 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-22 17:39:14 --> Model Class Initialized
DEBUG - 2023-04-22 17:39:14 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-22 17:39:14 --> Model Class Initialized
INFO - 2023-04-22 17:39:14 --> Final output sent to browser
DEBUG - 2023-04-22 17:39:14 --> Total execution time: 0.0174
ERROR - 2023-04-22 17:39:15 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-22 17:39:15 --> Config Class Initialized
INFO - 2023-04-22 17:39:15 --> Hooks Class Initialized
DEBUG - 2023-04-22 17:39:15 --> UTF-8 Support Enabled
INFO - 2023-04-22 17:39:15 --> Utf8 Class Initialized
INFO - 2023-04-22 17:39:15 --> URI Class Initialized
INFO - 2023-04-22 17:39:15 --> Router Class Initialized
INFO - 2023-04-22 17:39:15 --> Output Class Initialized
INFO - 2023-04-22 17:39:15 --> Security Class Initialized
DEBUG - 2023-04-22 17:39:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-22 17:39:15 --> Input Class Initialized
INFO - 2023-04-22 17:39:15 --> Language Class Initialized
INFO - 2023-04-22 17:39:15 --> Loader Class Initialized
INFO - 2023-04-22 17:39:15 --> Helper loaded: url_helper
INFO - 2023-04-22 17:39:15 --> Helper loaded: file_helper
INFO - 2023-04-22 17:39:15 --> Helper loaded: html_helper
INFO - 2023-04-22 17:39:15 --> Helper loaded: text_helper
INFO - 2023-04-22 17:39:15 --> Helper loaded: form_helper
INFO - 2023-04-22 17:39:15 --> Helper loaded: lang_helper
INFO - 2023-04-22 17:39:15 --> Helper loaded: security_helper
INFO - 2023-04-22 17:39:15 --> Helper loaded: cookie_helper
INFO - 2023-04-22 17:39:15 --> Database Driver Class Initialized
INFO - 2023-04-22 17:39:15 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-22 17:39:15 --> Parser Class Initialized
INFO - 2023-04-22 17:39:15 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-22 17:39:15 --> Pagination Class Initialized
INFO - 2023-04-22 17:39:15 --> Form Validation Class Initialized
INFO - 2023-04-22 17:39:15 --> Controller Class Initialized
INFO - 2023-04-22 17:39:15 --> Model Class Initialized
DEBUG - 2023-04-22 17:39:15 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-04-22 17:39:15 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-22 17:39:15 --> Model Class Initialized
DEBUG - 2023-04-22 17:39:15 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-22 17:39:15 --> Model Class Initialized
INFO - 2023-04-22 17:39:15 --> Final output sent to browser
DEBUG - 2023-04-22 17:39:15 --> Total execution time: 0.0164
ERROR - 2023-04-22 17:39:16 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-22 17:39:16 --> Config Class Initialized
INFO - 2023-04-22 17:39:16 --> Hooks Class Initialized
DEBUG - 2023-04-22 17:39:16 --> UTF-8 Support Enabled
INFO - 2023-04-22 17:39:16 --> Utf8 Class Initialized
INFO - 2023-04-22 17:39:16 --> URI Class Initialized
INFO - 2023-04-22 17:39:16 --> Router Class Initialized
INFO - 2023-04-22 17:39:16 --> Output Class Initialized
INFO - 2023-04-22 17:39:16 --> Security Class Initialized
DEBUG - 2023-04-22 17:39:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-22 17:39:16 --> Input Class Initialized
INFO - 2023-04-22 17:39:16 --> Language Class Initialized
INFO - 2023-04-22 17:39:16 --> Loader Class Initialized
INFO - 2023-04-22 17:39:16 --> Helper loaded: url_helper
INFO - 2023-04-22 17:39:16 --> Helper loaded: file_helper
INFO - 2023-04-22 17:39:16 --> Helper loaded: html_helper
INFO - 2023-04-22 17:39:16 --> Helper loaded: text_helper
INFO - 2023-04-22 17:39:16 --> Helper loaded: form_helper
INFO - 2023-04-22 17:39:16 --> Helper loaded: lang_helper
INFO - 2023-04-22 17:39:16 --> Helper loaded: security_helper
INFO - 2023-04-22 17:39:16 --> Helper loaded: cookie_helper
INFO - 2023-04-22 17:39:16 --> Database Driver Class Initialized
INFO - 2023-04-22 17:39:16 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-22 17:39:16 --> Parser Class Initialized
INFO - 2023-04-22 17:39:16 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-22 17:39:16 --> Pagination Class Initialized
INFO - 2023-04-22 17:39:16 --> Form Validation Class Initialized
INFO - 2023-04-22 17:39:16 --> Controller Class Initialized
INFO - 2023-04-22 17:39:16 --> Model Class Initialized
DEBUG - 2023-04-22 17:39:16 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-04-22 17:39:16 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-22 17:39:16 --> Model Class Initialized
DEBUG - 2023-04-22 17:39:16 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-22 17:39:16 --> Model Class Initialized
INFO - 2023-04-22 17:39:16 --> Final output sent to browser
DEBUG - 2023-04-22 17:39:16 --> Total execution time: 0.0172
ERROR - 2023-04-22 17:39:17 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-22 17:39:17 --> Config Class Initialized
INFO - 2023-04-22 17:39:17 --> Hooks Class Initialized
DEBUG - 2023-04-22 17:39:17 --> UTF-8 Support Enabled
INFO - 2023-04-22 17:39:17 --> Utf8 Class Initialized
INFO - 2023-04-22 17:39:17 --> URI Class Initialized
INFO - 2023-04-22 17:39:17 --> Router Class Initialized
INFO - 2023-04-22 17:39:17 --> Output Class Initialized
INFO - 2023-04-22 17:39:17 --> Security Class Initialized
DEBUG - 2023-04-22 17:39:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-22 17:39:17 --> Input Class Initialized
INFO - 2023-04-22 17:39:17 --> Language Class Initialized
INFO - 2023-04-22 17:39:17 --> Loader Class Initialized
INFO - 2023-04-22 17:39:17 --> Helper loaded: url_helper
INFO - 2023-04-22 17:39:17 --> Helper loaded: file_helper
INFO - 2023-04-22 17:39:17 --> Helper loaded: html_helper
INFO - 2023-04-22 17:39:17 --> Helper loaded: text_helper
INFO - 2023-04-22 17:39:17 --> Helper loaded: form_helper
INFO - 2023-04-22 17:39:17 --> Helper loaded: lang_helper
INFO - 2023-04-22 17:39:17 --> Helper loaded: security_helper
INFO - 2023-04-22 17:39:17 --> Helper loaded: cookie_helper
INFO - 2023-04-22 17:39:17 --> Database Driver Class Initialized
INFO - 2023-04-22 17:39:17 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-22 17:39:17 --> Parser Class Initialized
INFO - 2023-04-22 17:39:17 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-22 17:39:17 --> Pagination Class Initialized
INFO - 2023-04-22 17:39:17 --> Form Validation Class Initialized
INFO - 2023-04-22 17:39:17 --> Controller Class Initialized
INFO - 2023-04-22 17:39:17 --> Model Class Initialized
DEBUG - 2023-04-22 17:39:17 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-04-22 17:39:17 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-22 17:39:17 --> Model Class Initialized
DEBUG - 2023-04-22 17:39:17 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-22 17:39:17 --> Model Class Initialized
INFO - 2023-04-22 17:39:17 --> Final output sent to browser
DEBUG - 2023-04-22 17:39:17 --> Total execution time: 0.0185
ERROR - 2023-04-22 17:39:18 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-22 17:39:18 --> Config Class Initialized
INFO - 2023-04-22 17:39:18 --> Hooks Class Initialized
DEBUG - 2023-04-22 17:39:18 --> UTF-8 Support Enabled
INFO - 2023-04-22 17:39:18 --> Utf8 Class Initialized
INFO - 2023-04-22 17:39:18 --> URI Class Initialized
INFO - 2023-04-22 17:39:18 --> Router Class Initialized
INFO - 2023-04-22 17:39:18 --> Output Class Initialized
INFO - 2023-04-22 17:39:18 --> Security Class Initialized
DEBUG - 2023-04-22 17:39:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-22 17:39:18 --> Input Class Initialized
INFO - 2023-04-22 17:39:18 --> Language Class Initialized
INFO - 2023-04-22 17:39:18 --> Loader Class Initialized
INFO - 2023-04-22 17:39:18 --> Helper loaded: url_helper
INFO - 2023-04-22 17:39:18 --> Helper loaded: file_helper
INFO - 2023-04-22 17:39:18 --> Helper loaded: html_helper
INFO - 2023-04-22 17:39:18 --> Helper loaded: text_helper
INFO - 2023-04-22 17:39:18 --> Helper loaded: form_helper
INFO - 2023-04-22 17:39:18 --> Helper loaded: lang_helper
INFO - 2023-04-22 17:39:18 --> Helper loaded: security_helper
INFO - 2023-04-22 17:39:18 --> Helper loaded: cookie_helper
INFO - 2023-04-22 17:39:18 --> Database Driver Class Initialized
INFO - 2023-04-22 17:39:18 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-22 17:39:18 --> Parser Class Initialized
INFO - 2023-04-22 17:39:18 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-22 17:39:18 --> Pagination Class Initialized
INFO - 2023-04-22 17:39:18 --> Form Validation Class Initialized
INFO - 2023-04-22 17:39:18 --> Controller Class Initialized
INFO - 2023-04-22 17:39:18 --> Model Class Initialized
DEBUG - 2023-04-22 17:39:18 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-04-22 17:39:18 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-22 17:39:18 --> Model Class Initialized
DEBUG - 2023-04-22 17:39:18 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-22 17:39:18 --> Model Class Initialized
INFO - 2023-04-22 17:39:18 --> Final output sent to browser
DEBUG - 2023-04-22 17:39:18 --> Total execution time: 0.0181
ERROR - 2023-04-22 17:39:19 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-22 17:39:19 --> Config Class Initialized
INFO - 2023-04-22 17:39:19 --> Hooks Class Initialized
DEBUG - 2023-04-22 17:39:19 --> UTF-8 Support Enabled
INFO - 2023-04-22 17:39:19 --> Utf8 Class Initialized
INFO - 2023-04-22 17:39:19 --> URI Class Initialized
INFO - 2023-04-22 17:39:19 --> Router Class Initialized
INFO - 2023-04-22 17:39:19 --> Output Class Initialized
INFO - 2023-04-22 17:39:19 --> Security Class Initialized
DEBUG - 2023-04-22 17:39:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-22 17:39:19 --> Input Class Initialized
INFO - 2023-04-22 17:39:19 --> Language Class Initialized
INFO - 2023-04-22 17:39:19 --> Loader Class Initialized
INFO - 2023-04-22 17:39:19 --> Helper loaded: url_helper
INFO - 2023-04-22 17:39:19 --> Helper loaded: file_helper
INFO - 2023-04-22 17:39:19 --> Helper loaded: html_helper
INFO - 2023-04-22 17:39:19 --> Helper loaded: text_helper
INFO - 2023-04-22 17:39:19 --> Helper loaded: form_helper
INFO - 2023-04-22 17:39:19 --> Helper loaded: lang_helper
INFO - 2023-04-22 17:39:19 --> Helper loaded: security_helper
INFO - 2023-04-22 17:39:19 --> Helper loaded: cookie_helper
INFO - 2023-04-22 17:39:19 --> Database Driver Class Initialized
INFO - 2023-04-22 17:39:19 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-22 17:39:19 --> Parser Class Initialized
INFO - 2023-04-22 17:39:19 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-22 17:39:19 --> Pagination Class Initialized
INFO - 2023-04-22 17:39:19 --> Form Validation Class Initialized
INFO - 2023-04-22 17:39:19 --> Controller Class Initialized
INFO - 2023-04-22 17:39:19 --> Model Class Initialized
DEBUG - 2023-04-22 17:39:19 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-04-22 17:39:19 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-22 17:39:19 --> Model Class Initialized
DEBUG - 2023-04-22 17:39:19 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-22 17:39:19 --> Model Class Initialized
INFO - 2023-04-22 17:39:19 --> Final output sent to browser
DEBUG - 2023-04-22 17:39:19 --> Total execution time: 0.0173
ERROR - 2023-04-22 17:39:20 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-22 17:39:20 --> Config Class Initialized
INFO - 2023-04-22 17:39:20 --> Hooks Class Initialized
DEBUG - 2023-04-22 17:39:20 --> UTF-8 Support Enabled
INFO - 2023-04-22 17:39:20 --> Utf8 Class Initialized
INFO - 2023-04-22 17:39:20 --> URI Class Initialized
INFO - 2023-04-22 17:39:20 --> Router Class Initialized
INFO - 2023-04-22 17:39:20 --> Output Class Initialized
INFO - 2023-04-22 17:39:20 --> Security Class Initialized
DEBUG - 2023-04-22 17:39:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-22 17:39:20 --> Input Class Initialized
INFO - 2023-04-22 17:39:20 --> Language Class Initialized
INFO - 2023-04-22 17:39:20 --> Loader Class Initialized
INFO - 2023-04-22 17:39:20 --> Helper loaded: url_helper
INFO - 2023-04-22 17:39:20 --> Helper loaded: file_helper
INFO - 2023-04-22 17:39:20 --> Helper loaded: html_helper
INFO - 2023-04-22 17:39:20 --> Helper loaded: text_helper
INFO - 2023-04-22 17:39:20 --> Helper loaded: form_helper
INFO - 2023-04-22 17:39:20 --> Helper loaded: lang_helper
INFO - 2023-04-22 17:39:20 --> Helper loaded: security_helper
INFO - 2023-04-22 17:39:20 --> Helper loaded: cookie_helper
INFO - 2023-04-22 17:39:20 --> Database Driver Class Initialized
INFO - 2023-04-22 17:39:20 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-22 17:39:20 --> Parser Class Initialized
INFO - 2023-04-22 17:39:20 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-22 17:39:20 --> Pagination Class Initialized
INFO - 2023-04-22 17:39:20 --> Form Validation Class Initialized
INFO - 2023-04-22 17:39:20 --> Controller Class Initialized
INFO - 2023-04-22 17:39:20 --> Model Class Initialized
DEBUG - 2023-04-22 17:39:20 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-04-22 17:39:20 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-22 17:39:20 --> Model Class Initialized
DEBUG - 2023-04-22 17:39:20 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-22 17:39:20 --> Model Class Initialized
INFO - 2023-04-22 17:39:20 --> Final output sent to browser
DEBUG - 2023-04-22 17:39:20 --> Total execution time: 0.0175
ERROR - 2023-04-22 17:39:20 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-22 17:39:20 --> Config Class Initialized
INFO - 2023-04-22 17:39:20 --> Hooks Class Initialized
DEBUG - 2023-04-22 17:39:20 --> UTF-8 Support Enabled
INFO - 2023-04-22 17:39:20 --> Utf8 Class Initialized
INFO - 2023-04-22 17:39:20 --> URI Class Initialized
INFO - 2023-04-22 17:39:20 --> Router Class Initialized
INFO - 2023-04-22 17:39:20 --> Output Class Initialized
INFO - 2023-04-22 17:39:20 --> Security Class Initialized
DEBUG - 2023-04-22 17:39:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-22 17:39:20 --> Input Class Initialized
INFO - 2023-04-22 17:39:20 --> Language Class Initialized
INFO - 2023-04-22 17:39:20 --> Loader Class Initialized
INFO - 2023-04-22 17:39:20 --> Helper loaded: url_helper
INFO - 2023-04-22 17:39:20 --> Helper loaded: file_helper
INFO - 2023-04-22 17:39:20 --> Helper loaded: html_helper
INFO - 2023-04-22 17:39:20 --> Helper loaded: text_helper
INFO - 2023-04-22 17:39:20 --> Helper loaded: form_helper
INFO - 2023-04-22 17:39:20 --> Helper loaded: lang_helper
INFO - 2023-04-22 17:39:20 --> Helper loaded: security_helper
INFO - 2023-04-22 17:39:20 --> Helper loaded: cookie_helper
INFO - 2023-04-22 17:39:20 --> Database Driver Class Initialized
INFO - 2023-04-22 17:39:20 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-22 17:39:20 --> Parser Class Initialized
INFO - 2023-04-22 17:39:20 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-22 17:39:20 --> Pagination Class Initialized
INFO - 2023-04-22 17:39:20 --> Form Validation Class Initialized
INFO - 2023-04-22 17:39:20 --> Controller Class Initialized
INFO - 2023-04-22 17:39:20 --> Model Class Initialized
DEBUG - 2023-04-22 17:39:20 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-04-22 17:39:20 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-22 17:39:20 --> Model Class Initialized
DEBUG - 2023-04-22 17:39:20 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-22 17:39:20 --> Model Class Initialized
INFO - 2023-04-22 17:39:20 --> Final output sent to browser
DEBUG - 2023-04-22 17:39:20 --> Total execution time: 0.0180
ERROR - 2023-04-22 17:39:21 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-22 17:39:21 --> Config Class Initialized
INFO - 2023-04-22 17:39:21 --> Hooks Class Initialized
DEBUG - 2023-04-22 17:39:21 --> UTF-8 Support Enabled
INFO - 2023-04-22 17:39:21 --> Utf8 Class Initialized
INFO - 2023-04-22 17:39:21 --> URI Class Initialized
INFO - 2023-04-22 17:39:21 --> Router Class Initialized
INFO - 2023-04-22 17:39:21 --> Output Class Initialized
INFO - 2023-04-22 17:39:21 --> Security Class Initialized
DEBUG - 2023-04-22 17:39:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-22 17:39:21 --> Input Class Initialized
INFO - 2023-04-22 17:39:21 --> Language Class Initialized
INFO - 2023-04-22 17:39:21 --> Loader Class Initialized
INFO - 2023-04-22 17:39:21 --> Helper loaded: url_helper
INFO - 2023-04-22 17:39:21 --> Helper loaded: file_helper
INFO - 2023-04-22 17:39:21 --> Helper loaded: html_helper
INFO - 2023-04-22 17:39:21 --> Helper loaded: text_helper
INFO - 2023-04-22 17:39:21 --> Helper loaded: form_helper
INFO - 2023-04-22 17:39:21 --> Helper loaded: lang_helper
INFO - 2023-04-22 17:39:21 --> Helper loaded: security_helper
INFO - 2023-04-22 17:39:21 --> Helper loaded: cookie_helper
INFO - 2023-04-22 17:39:21 --> Database Driver Class Initialized
INFO - 2023-04-22 17:39:21 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-22 17:39:21 --> Parser Class Initialized
INFO - 2023-04-22 17:39:21 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-22 17:39:21 --> Pagination Class Initialized
INFO - 2023-04-22 17:39:21 --> Form Validation Class Initialized
INFO - 2023-04-22 17:39:21 --> Controller Class Initialized
INFO - 2023-04-22 17:39:21 --> Model Class Initialized
DEBUG - 2023-04-22 17:39:21 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-04-22 17:39:21 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-22 17:39:21 --> Model Class Initialized
DEBUG - 2023-04-22 17:39:21 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-22 17:39:21 --> Model Class Initialized
INFO - 2023-04-22 17:39:21 --> Final output sent to browser
DEBUG - 2023-04-22 17:39:21 --> Total execution time: 0.0180
ERROR - 2023-04-22 17:39:21 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-22 17:39:21 --> Config Class Initialized
INFO - 2023-04-22 17:39:21 --> Hooks Class Initialized
DEBUG - 2023-04-22 17:39:21 --> UTF-8 Support Enabled
INFO - 2023-04-22 17:39:21 --> Utf8 Class Initialized
INFO - 2023-04-22 17:39:21 --> URI Class Initialized
INFO - 2023-04-22 17:39:21 --> Router Class Initialized
INFO - 2023-04-22 17:39:21 --> Output Class Initialized
INFO - 2023-04-22 17:39:21 --> Security Class Initialized
DEBUG - 2023-04-22 17:39:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-22 17:39:21 --> Input Class Initialized
INFO - 2023-04-22 17:39:21 --> Language Class Initialized
INFO - 2023-04-22 17:39:21 --> Loader Class Initialized
INFO - 2023-04-22 17:39:21 --> Helper loaded: url_helper
INFO - 2023-04-22 17:39:21 --> Helper loaded: file_helper
INFO - 2023-04-22 17:39:21 --> Helper loaded: html_helper
INFO - 2023-04-22 17:39:21 --> Helper loaded: text_helper
INFO - 2023-04-22 17:39:21 --> Helper loaded: form_helper
INFO - 2023-04-22 17:39:21 --> Helper loaded: lang_helper
INFO - 2023-04-22 17:39:21 --> Helper loaded: security_helper
INFO - 2023-04-22 17:39:21 --> Helper loaded: cookie_helper
INFO - 2023-04-22 17:39:21 --> Database Driver Class Initialized
INFO - 2023-04-22 17:39:21 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-22 17:39:21 --> Parser Class Initialized
INFO - 2023-04-22 17:39:21 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-22 17:39:21 --> Pagination Class Initialized
INFO - 2023-04-22 17:39:21 --> Form Validation Class Initialized
INFO - 2023-04-22 17:39:21 --> Controller Class Initialized
INFO - 2023-04-22 17:39:21 --> Model Class Initialized
DEBUG - 2023-04-22 17:39:21 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-04-22 17:39:21 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-22 17:39:21 --> Model Class Initialized
DEBUG - 2023-04-22 17:39:21 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-22 17:39:21 --> Model Class Initialized
INFO - 2023-04-22 17:39:21 --> Final output sent to browser
DEBUG - 2023-04-22 17:39:21 --> Total execution time: 0.0167
ERROR - 2023-04-22 17:39:24 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-22 17:39:24 --> Config Class Initialized
INFO - 2023-04-22 17:39:24 --> Hooks Class Initialized
DEBUG - 2023-04-22 17:39:24 --> UTF-8 Support Enabled
INFO - 2023-04-22 17:39:24 --> Utf8 Class Initialized
INFO - 2023-04-22 17:39:24 --> URI Class Initialized
INFO - 2023-04-22 17:39:24 --> Router Class Initialized
INFO - 2023-04-22 17:39:24 --> Output Class Initialized
INFO - 2023-04-22 17:39:24 --> Security Class Initialized
DEBUG - 2023-04-22 17:39:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-22 17:39:24 --> Input Class Initialized
INFO - 2023-04-22 17:39:24 --> Language Class Initialized
INFO - 2023-04-22 17:39:24 --> Loader Class Initialized
INFO - 2023-04-22 17:39:24 --> Helper loaded: url_helper
INFO - 2023-04-22 17:39:24 --> Helper loaded: file_helper
INFO - 2023-04-22 17:39:24 --> Helper loaded: html_helper
INFO - 2023-04-22 17:39:24 --> Helper loaded: text_helper
INFO - 2023-04-22 17:39:24 --> Helper loaded: form_helper
INFO - 2023-04-22 17:39:24 --> Helper loaded: lang_helper
INFO - 2023-04-22 17:39:24 --> Helper loaded: security_helper
INFO - 2023-04-22 17:39:24 --> Helper loaded: cookie_helper
INFO - 2023-04-22 17:39:24 --> Database Driver Class Initialized
INFO - 2023-04-22 17:39:24 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-22 17:39:24 --> Parser Class Initialized
INFO - 2023-04-22 17:39:24 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-22 17:39:24 --> Pagination Class Initialized
INFO - 2023-04-22 17:39:24 --> Form Validation Class Initialized
INFO - 2023-04-22 17:39:24 --> Controller Class Initialized
INFO - 2023-04-22 17:39:24 --> Model Class Initialized
DEBUG - 2023-04-22 17:39:24 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-04-22 17:39:24 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-22 17:39:24 --> Model Class Initialized
DEBUG - 2023-04-22 17:39:24 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-22 17:39:24 --> Model Class Initialized
INFO - 2023-04-22 17:39:24 --> Final output sent to browser
DEBUG - 2023-04-22 17:39:24 --> Total execution time: 0.0205
ERROR - 2023-04-22 17:39:26 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-22 17:39:26 --> Config Class Initialized
INFO - 2023-04-22 17:39:26 --> Hooks Class Initialized
DEBUG - 2023-04-22 17:39:26 --> UTF-8 Support Enabled
INFO - 2023-04-22 17:39:26 --> Utf8 Class Initialized
INFO - 2023-04-22 17:39:26 --> URI Class Initialized
INFO - 2023-04-22 17:39:26 --> Router Class Initialized
INFO - 2023-04-22 17:39:26 --> Output Class Initialized
INFO - 2023-04-22 17:39:26 --> Security Class Initialized
DEBUG - 2023-04-22 17:39:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-22 17:39:26 --> Input Class Initialized
INFO - 2023-04-22 17:39:26 --> Language Class Initialized
INFO - 2023-04-22 17:39:26 --> Loader Class Initialized
INFO - 2023-04-22 17:39:26 --> Helper loaded: url_helper
INFO - 2023-04-22 17:39:26 --> Helper loaded: file_helper
INFO - 2023-04-22 17:39:26 --> Helper loaded: html_helper
INFO - 2023-04-22 17:39:26 --> Helper loaded: text_helper
INFO - 2023-04-22 17:39:26 --> Helper loaded: form_helper
INFO - 2023-04-22 17:39:26 --> Helper loaded: lang_helper
INFO - 2023-04-22 17:39:26 --> Helper loaded: security_helper
INFO - 2023-04-22 17:39:26 --> Helper loaded: cookie_helper
INFO - 2023-04-22 17:39:26 --> Database Driver Class Initialized
INFO - 2023-04-22 17:39:26 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-22 17:39:26 --> Parser Class Initialized
INFO - 2023-04-22 17:39:26 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-22 17:39:26 --> Pagination Class Initialized
INFO - 2023-04-22 17:39:26 --> Form Validation Class Initialized
INFO - 2023-04-22 17:39:26 --> Controller Class Initialized
INFO - 2023-04-22 17:39:26 --> Model Class Initialized
DEBUG - 2023-04-22 17:39:26 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-04-22 17:39:26 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-22 17:39:26 --> Model Class Initialized
DEBUG - 2023-04-22 17:39:26 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-22 17:39:26 --> Model Class Initialized
INFO - 2023-04-22 17:39:26 --> Model Class Initialized
INFO - 2023-04-22 17:39:26 --> Final output sent to browser
DEBUG - 2023-04-22 17:39:26 --> Total execution time: 0.0208
ERROR - 2023-04-22 17:39:31 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-22 17:39:31 --> Config Class Initialized
INFO - 2023-04-22 17:39:31 --> Hooks Class Initialized
DEBUG - 2023-04-22 17:39:31 --> UTF-8 Support Enabled
INFO - 2023-04-22 17:39:31 --> Utf8 Class Initialized
INFO - 2023-04-22 17:39:31 --> URI Class Initialized
INFO - 2023-04-22 17:39:31 --> Router Class Initialized
INFO - 2023-04-22 17:39:31 --> Output Class Initialized
INFO - 2023-04-22 17:39:31 --> Security Class Initialized
DEBUG - 2023-04-22 17:39:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-22 17:39:31 --> Input Class Initialized
INFO - 2023-04-22 17:39:31 --> Language Class Initialized
INFO - 2023-04-22 17:39:31 --> Loader Class Initialized
INFO - 2023-04-22 17:39:31 --> Helper loaded: url_helper
INFO - 2023-04-22 17:39:31 --> Helper loaded: file_helper
INFO - 2023-04-22 17:39:31 --> Helper loaded: html_helper
INFO - 2023-04-22 17:39:31 --> Helper loaded: text_helper
INFO - 2023-04-22 17:39:31 --> Helper loaded: form_helper
INFO - 2023-04-22 17:39:31 --> Helper loaded: lang_helper
INFO - 2023-04-22 17:39:31 --> Helper loaded: security_helper
INFO - 2023-04-22 17:39:31 --> Helper loaded: cookie_helper
INFO - 2023-04-22 17:39:31 --> Database Driver Class Initialized
INFO - 2023-04-22 17:39:31 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-22 17:39:31 --> Parser Class Initialized
INFO - 2023-04-22 17:39:31 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-22 17:39:31 --> Pagination Class Initialized
INFO - 2023-04-22 17:39:31 --> Form Validation Class Initialized
INFO - 2023-04-22 17:39:31 --> Controller Class Initialized
INFO - 2023-04-22 17:39:31 --> Model Class Initialized
DEBUG - 2023-04-22 17:39:31 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-04-22 17:39:31 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-22 17:39:31 --> Model Class Initialized
DEBUG - 2023-04-22 17:39:31 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-22 17:39:31 --> Model Class Initialized
INFO - 2023-04-22 17:39:31 --> Final output sent to browser
DEBUG - 2023-04-22 17:39:31 --> Total execution time: 0.0215
ERROR - 2023-04-22 17:39:39 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-22 17:39:39 --> Config Class Initialized
INFO - 2023-04-22 17:39:39 --> Hooks Class Initialized
DEBUG - 2023-04-22 17:39:39 --> UTF-8 Support Enabled
INFO - 2023-04-22 17:39:39 --> Utf8 Class Initialized
INFO - 2023-04-22 17:39:39 --> URI Class Initialized
INFO - 2023-04-22 17:39:39 --> Router Class Initialized
INFO - 2023-04-22 17:39:39 --> Output Class Initialized
INFO - 2023-04-22 17:39:39 --> Security Class Initialized
DEBUG - 2023-04-22 17:39:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-22 17:39:39 --> Input Class Initialized
INFO - 2023-04-22 17:39:39 --> Language Class Initialized
INFO - 2023-04-22 17:39:39 --> Loader Class Initialized
INFO - 2023-04-22 17:39:39 --> Helper loaded: url_helper
INFO - 2023-04-22 17:39:39 --> Helper loaded: file_helper
INFO - 2023-04-22 17:39:39 --> Helper loaded: html_helper
INFO - 2023-04-22 17:39:39 --> Helper loaded: text_helper
INFO - 2023-04-22 17:39:39 --> Helper loaded: form_helper
INFO - 2023-04-22 17:39:39 --> Helper loaded: lang_helper
INFO - 2023-04-22 17:39:39 --> Helper loaded: security_helper
INFO - 2023-04-22 17:39:39 --> Helper loaded: cookie_helper
INFO - 2023-04-22 17:39:39 --> Database Driver Class Initialized
INFO - 2023-04-22 17:39:39 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-22 17:39:39 --> Parser Class Initialized
INFO - 2023-04-22 17:39:39 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-22 17:39:39 --> Pagination Class Initialized
INFO - 2023-04-22 17:39:39 --> Form Validation Class Initialized
INFO - 2023-04-22 17:39:39 --> Controller Class Initialized
INFO - 2023-04-22 17:39:39 --> Model Class Initialized
DEBUG - 2023-04-22 17:39:39 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-04-22 17:39:39 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-22 17:39:39 --> Model Class Initialized
DEBUG - 2023-04-22 17:39:39 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-22 17:39:39 --> Model Class Initialized
INFO - 2023-04-22 17:39:39 --> Final output sent to browser
DEBUG - 2023-04-22 17:39:39 --> Total execution time: 0.0193
ERROR - 2023-04-22 17:39:40 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-22 17:39:40 --> Config Class Initialized
INFO - 2023-04-22 17:39:40 --> Hooks Class Initialized
DEBUG - 2023-04-22 17:39:40 --> UTF-8 Support Enabled
INFO - 2023-04-22 17:39:40 --> Utf8 Class Initialized
INFO - 2023-04-22 17:39:40 --> URI Class Initialized
INFO - 2023-04-22 17:39:40 --> Router Class Initialized
INFO - 2023-04-22 17:39:40 --> Output Class Initialized
INFO - 2023-04-22 17:39:40 --> Security Class Initialized
DEBUG - 2023-04-22 17:39:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-22 17:39:40 --> Input Class Initialized
INFO - 2023-04-22 17:39:40 --> Language Class Initialized
INFO - 2023-04-22 17:39:40 --> Loader Class Initialized
INFO - 2023-04-22 17:39:40 --> Helper loaded: url_helper
INFO - 2023-04-22 17:39:40 --> Helper loaded: file_helper
INFO - 2023-04-22 17:39:40 --> Helper loaded: html_helper
INFO - 2023-04-22 17:39:40 --> Helper loaded: text_helper
INFO - 2023-04-22 17:39:40 --> Helper loaded: form_helper
INFO - 2023-04-22 17:39:40 --> Helper loaded: lang_helper
INFO - 2023-04-22 17:39:40 --> Helper loaded: security_helper
INFO - 2023-04-22 17:39:40 --> Helper loaded: cookie_helper
INFO - 2023-04-22 17:39:40 --> Database Driver Class Initialized
INFO - 2023-04-22 17:39:40 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-22 17:39:40 --> Parser Class Initialized
INFO - 2023-04-22 17:39:40 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-22 17:39:40 --> Pagination Class Initialized
INFO - 2023-04-22 17:39:40 --> Form Validation Class Initialized
INFO - 2023-04-22 17:39:40 --> Controller Class Initialized
INFO - 2023-04-22 17:39:40 --> Model Class Initialized
DEBUG - 2023-04-22 17:39:40 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-04-22 17:39:40 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-22 17:39:40 --> Model Class Initialized
DEBUG - 2023-04-22 17:39:40 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-22 17:39:40 --> Model Class Initialized
INFO - 2023-04-22 17:39:40 --> Final output sent to browser
DEBUG - 2023-04-22 17:39:40 --> Total execution time: 0.0175
ERROR - 2023-04-22 17:39:40 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-22 17:39:40 --> Config Class Initialized
INFO - 2023-04-22 17:39:40 --> Hooks Class Initialized
DEBUG - 2023-04-22 17:39:40 --> UTF-8 Support Enabled
INFO - 2023-04-22 17:39:40 --> Utf8 Class Initialized
INFO - 2023-04-22 17:39:40 --> URI Class Initialized
INFO - 2023-04-22 17:39:40 --> Router Class Initialized
INFO - 2023-04-22 17:39:40 --> Output Class Initialized
INFO - 2023-04-22 17:39:40 --> Security Class Initialized
DEBUG - 2023-04-22 17:39:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-22 17:39:40 --> Input Class Initialized
INFO - 2023-04-22 17:39:40 --> Language Class Initialized
INFO - 2023-04-22 17:39:40 --> Loader Class Initialized
INFO - 2023-04-22 17:39:40 --> Helper loaded: url_helper
INFO - 2023-04-22 17:39:40 --> Helper loaded: file_helper
INFO - 2023-04-22 17:39:40 --> Helper loaded: html_helper
INFO - 2023-04-22 17:39:40 --> Helper loaded: text_helper
INFO - 2023-04-22 17:39:40 --> Helper loaded: form_helper
INFO - 2023-04-22 17:39:40 --> Helper loaded: lang_helper
INFO - 2023-04-22 17:39:40 --> Helper loaded: security_helper
INFO - 2023-04-22 17:39:40 --> Helper loaded: cookie_helper
INFO - 2023-04-22 17:39:40 --> Database Driver Class Initialized
INFO - 2023-04-22 17:39:40 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-22 17:39:40 --> Parser Class Initialized
INFO - 2023-04-22 17:39:40 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-22 17:39:40 --> Pagination Class Initialized
INFO - 2023-04-22 17:39:40 --> Form Validation Class Initialized
INFO - 2023-04-22 17:39:40 --> Controller Class Initialized
INFO - 2023-04-22 17:39:40 --> Model Class Initialized
DEBUG - 2023-04-22 17:39:40 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-04-22 17:39:40 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-22 17:39:40 --> Model Class Initialized
DEBUG - 2023-04-22 17:39:40 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-22 17:39:40 --> Model Class Initialized
INFO - 2023-04-22 17:39:40 --> Final output sent to browser
DEBUG - 2023-04-22 17:39:40 --> Total execution time: 0.0177
ERROR - 2023-04-22 17:39:41 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-22 17:39:41 --> Config Class Initialized
INFO - 2023-04-22 17:39:41 --> Hooks Class Initialized
DEBUG - 2023-04-22 17:39:41 --> UTF-8 Support Enabled
INFO - 2023-04-22 17:39:41 --> Utf8 Class Initialized
INFO - 2023-04-22 17:39:41 --> URI Class Initialized
INFO - 2023-04-22 17:39:41 --> Router Class Initialized
INFO - 2023-04-22 17:39:41 --> Output Class Initialized
INFO - 2023-04-22 17:39:41 --> Security Class Initialized
DEBUG - 2023-04-22 17:39:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-22 17:39:41 --> Input Class Initialized
INFO - 2023-04-22 17:39:41 --> Language Class Initialized
INFO - 2023-04-22 17:39:41 --> Loader Class Initialized
INFO - 2023-04-22 17:39:41 --> Helper loaded: url_helper
INFO - 2023-04-22 17:39:41 --> Helper loaded: file_helper
INFO - 2023-04-22 17:39:41 --> Helper loaded: html_helper
INFO - 2023-04-22 17:39:41 --> Helper loaded: text_helper
INFO - 2023-04-22 17:39:41 --> Helper loaded: form_helper
INFO - 2023-04-22 17:39:41 --> Helper loaded: lang_helper
INFO - 2023-04-22 17:39:41 --> Helper loaded: security_helper
INFO - 2023-04-22 17:39:41 --> Helper loaded: cookie_helper
INFO - 2023-04-22 17:39:41 --> Database Driver Class Initialized
INFO - 2023-04-22 17:39:41 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-22 17:39:41 --> Parser Class Initialized
INFO - 2023-04-22 17:39:41 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-22 17:39:41 --> Pagination Class Initialized
INFO - 2023-04-22 17:39:41 --> Form Validation Class Initialized
INFO - 2023-04-22 17:39:41 --> Controller Class Initialized
INFO - 2023-04-22 17:39:41 --> Model Class Initialized
DEBUG - 2023-04-22 17:39:41 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-04-22 17:39:41 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-22 17:39:41 --> Model Class Initialized
DEBUG - 2023-04-22 17:39:41 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-22 17:39:41 --> Model Class Initialized
INFO - 2023-04-22 17:39:41 --> Final output sent to browser
DEBUG - 2023-04-22 17:39:41 --> Total execution time: 0.0173
ERROR - 2023-04-22 17:39:43 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-22 17:39:43 --> Config Class Initialized
INFO - 2023-04-22 17:39:43 --> Hooks Class Initialized
DEBUG - 2023-04-22 17:39:43 --> UTF-8 Support Enabled
INFO - 2023-04-22 17:39:43 --> Utf8 Class Initialized
INFO - 2023-04-22 17:39:43 --> URI Class Initialized
INFO - 2023-04-22 17:39:43 --> Router Class Initialized
INFO - 2023-04-22 17:39:43 --> Output Class Initialized
INFO - 2023-04-22 17:39:43 --> Security Class Initialized
DEBUG - 2023-04-22 17:39:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-22 17:39:43 --> Input Class Initialized
INFO - 2023-04-22 17:39:43 --> Language Class Initialized
INFO - 2023-04-22 17:39:43 --> Loader Class Initialized
INFO - 2023-04-22 17:39:43 --> Helper loaded: url_helper
INFO - 2023-04-22 17:39:43 --> Helper loaded: file_helper
INFO - 2023-04-22 17:39:43 --> Helper loaded: html_helper
INFO - 2023-04-22 17:39:43 --> Helper loaded: text_helper
INFO - 2023-04-22 17:39:43 --> Helper loaded: form_helper
INFO - 2023-04-22 17:39:43 --> Helper loaded: lang_helper
INFO - 2023-04-22 17:39:43 --> Helper loaded: security_helper
INFO - 2023-04-22 17:39:43 --> Helper loaded: cookie_helper
INFO - 2023-04-22 17:39:43 --> Database Driver Class Initialized
INFO - 2023-04-22 17:39:43 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-22 17:39:43 --> Parser Class Initialized
INFO - 2023-04-22 17:39:43 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-22 17:39:43 --> Pagination Class Initialized
INFO - 2023-04-22 17:39:43 --> Form Validation Class Initialized
INFO - 2023-04-22 17:39:43 --> Controller Class Initialized
INFO - 2023-04-22 17:39:43 --> Model Class Initialized
DEBUG - 2023-04-22 17:39:43 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-04-22 17:39:43 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-22 17:39:43 --> Model Class Initialized
DEBUG - 2023-04-22 17:39:43 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-22 17:39:43 --> Model Class Initialized
INFO - 2023-04-22 17:39:43 --> Model Class Initialized
INFO - 2023-04-22 17:39:43 --> Final output sent to browser
DEBUG - 2023-04-22 17:39:43 --> Total execution time: 0.0207
ERROR - 2023-04-22 17:39:46 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-22 17:39:46 --> Config Class Initialized
INFO - 2023-04-22 17:39:46 --> Hooks Class Initialized
DEBUG - 2023-04-22 17:39:46 --> UTF-8 Support Enabled
INFO - 2023-04-22 17:39:46 --> Utf8 Class Initialized
INFO - 2023-04-22 17:39:46 --> URI Class Initialized
INFO - 2023-04-22 17:39:46 --> Router Class Initialized
INFO - 2023-04-22 17:39:46 --> Output Class Initialized
INFO - 2023-04-22 17:39:46 --> Security Class Initialized
DEBUG - 2023-04-22 17:39:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-22 17:39:46 --> Input Class Initialized
INFO - 2023-04-22 17:39:46 --> Language Class Initialized
INFO - 2023-04-22 17:39:46 --> Loader Class Initialized
INFO - 2023-04-22 17:39:46 --> Helper loaded: url_helper
INFO - 2023-04-22 17:39:46 --> Helper loaded: file_helper
INFO - 2023-04-22 17:39:46 --> Helper loaded: html_helper
INFO - 2023-04-22 17:39:46 --> Helper loaded: text_helper
INFO - 2023-04-22 17:39:46 --> Helper loaded: form_helper
INFO - 2023-04-22 17:39:46 --> Helper loaded: lang_helper
INFO - 2023-04-22 17:39:46 --> Helper loaded: security_helper
INFO - 2023-04-22 17:39:46 --> Helper loaded: cookie_helper
INFO - 2023-04-22 17:39:46 --> Database Driver Class Initialized
INFO - 2023-04-22 17:39:46 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-22 17:39:46 --> Parser Class Initialized
INFO - 2023-04-22 17:39:46 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-22 17:39:46 --> Pagination Class Initialized
INFO - 2023-04-22 17:39:46 --> Form Validation Class Initialized
INFO - 2023-04-22 17:39:46 --> Controller Class Initialized
INFO - 2023-04-22 17:39:46 --> Model Class Initialized
DEBUG - 2023-04-22 17:39:46 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-04-22 17:39:46 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-22 17:39:46 --> Model Class Initialized
DEBUG - 2023-04-22 17:39:46 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-22 17:39:46 --> Model Class Initialized
INFO - 2023-04-22 17:39:46 --> Final output sent to browser
DEBUG - 2023-04-22 17:39:46 --> Total execution time: 0.0187
ERROR - 2023-04-22 17:39:54 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-22 17:39:54 --> Config Class Initialized
INFO - 2023-04-22 17:39:54 --> Hooks Class Initialized
DEBUG - 2023-04-22 17:39:54 --> UTF-8 Support Enabled
INFO - 2023-04-22 17:39:54 --> Utf8 Class Initialized
INFO - 2023-04-22 17:39:54 --> URI Class Initialized
INFO - 2023-04-22 17:39:54 --> Router Class Initialized
INFO - 2023-04-22 17:39:54 --> Output Class Initialized
INFO - 2023-04-22 17:39:54 --> Security Class Initialized
DEBUG - 2023-04-22 17:39:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-22 17:39:54 --> Input Class Initialized
INFO - 2023-04-22 17:39:54 --> Language Class Initialized
INFO - 2023-04-22 17:39:54 --> Loader Class Initialized
INFO - 2023-04-22 17:39:54 --> Helper loaded: url_helper
INFO - 2023-04-22 17:39:54 --> Helper loaded: file_helper
INFO - 2023-04-22 17:39:54 --> Helper loaded: html_helper
INFO - 2023-04-22 17:39:54 --> Helper loaded: text_helper
INFO - 2023-04-22 17:39:54 --> Helper loaded: form_helper
INFO - 2023-04-22 17:39:54 --> Helper loaded: lang_helper
INFO - 2023-04-22 17:39:54 --> Helper loaded: security_helper
INFO - 2023-04-22 17:39:54 --> Helper loaded: cookie_helper
INFO - 2023-04-22 17:39:54 --> Database Driver Class Initialized
INFO - 2023-04-22 17:39:54 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-22 17:39:54 --> Parser Class Initialized
INFO - 2023-04-22 17:39:54 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-22 17:39:54 --> Pagination Class Initialized
INFO - 2023-04-22 17:39:54 --> Form Validation Class Initialized
INFO - 2023-04-22 17:39:54 --> Controller Class Initialized
INFO - 2023-04-22 17:39:54 --> Model Class Initialized
DEBUG - 2023-04-22 17:39:54 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-04-22 17:39:54 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-22 17:39:54 --> Model Class Initialized
DEBUG - 2023-04-22 17:39:54 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-22 17:39:54 --> Model Class Initialized
INFO - 2023-04-22 17:39:54 --> Final output sent to browser
DEBUG - 2023-04-22 17:39:54 --> Total execution time: 0.0176
ERROR - 2023-04-22 17:39:55 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-22 17:39:55 --> Config Class Initialized
INFO - 2023-04-22 17:39:55 --> Hooks Class Initialized
DEBUG - 2023-04-22 17:39:55 --> UTF-8 Support Enabled
INFO - 2023-04-22 17:39:55 --> Utf8 Class Initialized
INFO - 2023-04-22 17:39:55 --> URI Class Initialized
INFO - 2023-04-22 17:39:55 --> Router Class Initialized
INFO - 2023-04-22 17:39:55 --> Output Class Initialized
INFO - 2023-04-22 17:39:55 --> Security Class Initialized
DEBUG - 2023-04-22 17:39:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-22 17:39:55 --> Input Class Initialized
INFO - 2023-04-22 17:39:55 --> Language Class Initialized
INFO - 2023-04-22 17:39:55 --> Loader Class Initialized
INFO - 2023-04-22 17:39:55 --> Helper loaded: url_helper
INFO - 2023-04-22 17:39:55 --> Helper loaded: file_helper
INFO - 2023-04-22 17:39:55 --> Helper loaded: html_helper
INFO - 2023-04-22 17:39:55 --> Helper loaded: text_helper
INFO - 2023-04-22 17:39:55 --> Helper loaded: form_helper
INFO - 2023-04-22 17:39:55 --> Helper loaded: lang_helper
INFO - 2023-04-22 17:39:55 --> Helper loaded: security_helper
INFO - 2023-04-22 17:39:55 --> Helper loaded: cookie_helper
INFO - 2023-04-22 17:39:55 --> Database Driver Class Initialized
INFO - 2023-04-22 17:39:55 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-22 17:39:55 --> Parser Class Initialized
INFO - 2023-04-22 17:39:55 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-22 17:39:55 --> Pagination Class Initialized
INFO - 2023-04-22 17:39:55 --> Form Validation Class Initialized
INFO - 2023-04-22 17:39:55 --> Controller Class Initialized
INFO - 2023-04-22 17:39:55 --> Model Class Initialized
DEBUG - 2023-04-22 17:39:55 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-04-22 17:39:55 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-22 17:39:55 --> Model Class Initialized
DEBUG - 2023-04-22 17:39:55 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-22 17:39:55 --> Model Class Initialized
INFO - 2023-04-22 17:39:55 --> Final output sent to browser
DEBUG - 2023-04-22 17:39:55 --> Total execution time: 0.0171
ERROR - 2023-04-22 17:39:59 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-22 17:39:59 --> Config Class Initialized
INFO - 2023-04-22 17:39:59 --> Hooks Class Initialized
DEBUG - 2023-04-22 17:39:59 --> UTF-8 Support Enabled
INFO - 2023-04-22 17:39:59 --> Utf8 Class Initialized
INFO - 2023-04-22 17:39:59 --> URI Class Initialized
INFO - 2023-04-22 17:39:59 --> Router Class Initialized
INFO - 2023-04-22 17:39:59 --> Output Class Initialized
INFO - 2023-04-22 17:39:59 --> Security Class Initialized
DEBUG - 2023-04-22 17:39:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-22 17:39:59 --> Input Class Initialized
INFO - 2023-04-22 17:39:59 --> Language Class Initialized
INFO - 2023-04-22 17:39:59 --> Loader Class Initialized
INFO - 2023-04-22 17:39:59 --> Helper loaded: url_helper
INFO - 2023-04-22 17:39:59 --> Helper loaded: file_helper
INFO - 2023-04-22 17:39:59 --> Helper loaded: html_helper
INFO - 2023-04-22 17:39:59 --> Helper loaded: text_helper
INFO - 2023-04-22 17:39:59 --> Helper loaded: form_helper
INFO - 2023-04-22 17:39:59 --> Helper loaded: lang_helper
INFO - 2023-04-22 17:39:59 --> Helper loaded: security_helper
INFO - 2023-04-22 17:39:59 --> Helper loaded: cookie_helper
INFO - 2023-04-22 17:39:59 --> Database Driver Class Initialized
INFO - 2023-04-22 17:39:59 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-22 17:39:59 --> Parser Class Initialized
INFO - 2023-04-22 17:39:59 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-22 17:39:59 --> Pagination Class Initialized
INFO - 2023-04-22 17:39:59 --> Form Validation Class Initialized
INFO - 2023-04-22 17:39:59 --> Controller Class Initialized
INFO - 2023-04-22 17:39:59 --> Model Class Initialized
DEBUG - 2023-04-22 17:39:59 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-04-22 17:39:59 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-22 17:39:59 --> Model Class Initialized
DEBUG - 2023-04-22 17:39:59 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-22 17:39:59 --> Model Class Initialized
INFO - 2023-04-22 17:39:59 --> Model Class Initialized
INFO - 2023-04-22 17:39:59 --> Final output sent to browser
DEBUG - 2023-04-22 17:39:59 --> Total execution time: 0.0212
ERROR - 2023-04-22 17:40:01 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-22 17:40:01 --> Config Class Initialized
INFO - 2023-04-22 17:40:01 --> Hooks Class Initialized
DEBUG - 2023-04-22 17:40:01 --> UTF-8 Support Enabled
INFO - 2023-04-22 17:40:01 --> Utf8 Class Initialized
INFO - 2023-04-22 17:40:01 --> URI Class Initialized
INFO - 2023-04-22 17:40:01 --> Router Class Initialized
INFO - 2023-04-22 17:40:01 --> Output Class Initialized
INFO - 2023-04-22 17:40:01 --> Security Class Initialized
DEBUG - 2023-04-22 17:40:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-22 17:40:01 --> Input Class Initialized
INFO - 2023-04-22 17:40:01 --> Language Class Initialized
INFO - 2023-04-22 17:40:01 --> Loader Class Initialized
INFO - 2023-04-22 17:40:01 --> Helper loaded: url_helper
INFO - 2023-04-22 17:40:01 --> Helper loaded: file_helper
INFO - 2023-04-22 17:40:01 --> Helper loaded: html_helper
INFO - 2023-04-22 17:40:01 --> Helper loaded: text_helper
INFO - 2023-04-22 17:40:01 --> Helper loaded: form_helper
INFO - 2023-04-22 17:40:01 --> Helper loaded: lang_helper
INFO - 2023-04-22 17:40:01 --> Helper loaded: security_helper
INFO - 2023-04-22 17:40:01 --> Helper loaded: cookie_helper
INFO - 2023-04-22 17:40:01 --> Database Driver Class Initialized
INFO - 2023-04-22 17:40:01 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-22 17:40:01 --> Parser Class Initialized
INFO - 2023-04-22 17:40:01 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-22 17:40:01 --> Pagination Class Initialized
INFO - 2023-04-22 17:40:01 --> Form Validation Class Initialized
INFO - 2023-04-22 17:40:01 --> Controller Class Initialized
INFO - 2023-04-22 17:40:01 --> Model Class Initialized
DEBUG - 2023-04-22 17:40:01 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-04-22 17:40:01 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-22 17:40:01 --> Model Class Initialized
DEBUG - 2023-04-22 17:40:01 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-22 17:40:01 --> Model Class Initialized
INFO - 2023-04-22 17:40:01 --> Final output sent to browser
DEBUG - 2023-04-22 17:40:01 --> Total execution time: 0.0237
ERROR - 2023-04-22 17:40:10 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-22 17:40:10 --> Config Class Initialized
INFO - 2023-04-22 17:40:10 --> Hooks Class Initialized
DEBUG - 2023-04-22 17:40:10 --> UTF-8 Support Enabled
INFO - 2023-04-22 17:40:10 --> Utf8 Class Initialized
INFO - 2023-04-22 17:40:10 --> URI Class Initialized
INFO - 2023-04-22 17:40:10 --> Router Class Initialized
INFO - 2023-04-22 17:40:10 --> Output Class Initialized
INFO - 2023-04-22 17:40:10 --> Security Class Initialized
DEBUG - 2023-04-22 17:40:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-22 17:40:10 --> Input Class Initialized
INFO - 2023-04-22 17:40:10 --> Language Class Initialized
INFO - 2023-04-22 17:40:10 --> Loader Class Initialized
INFO - 2023-04-22 17:40:10 --> Helper loaded: url_helper
INFO - 2023-04-22 17:40:10 --> Helper loaded: file_helper
INFO - 2023-04-22 17:40:10 --> Helper loaded: html_helper
INFO - 2023-04-22 17:40:10 --> Helper loaded: text_helper
INFO - 2023-04-22 17:40:10 --> Helper loaded: form_helper
INFO - 2023-04-22 17:40:10 --> Helper loaded: lang_helper
INFO - 2023-04-22 17:40:10 --> Helper loaded: security_helper
INFO - 2023-04-22 17:40:10 --> Helper loaded: cookie_helper
INFO - 2023-04-22 17:40:10 --> Database Driver Class Initialized
INFO - 2023-04-22 17:40:10 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-22 17:40:10 --> Parser Class Initialized
INFO - 2023-04-22 17:40:10 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-22 17:40:10 --> Pagination Class Initialized
INFO - 2023-04-22 17:40:10 --> Form Validation Class Initialized
INFO - 2023-04-22 17:40:10 --> Controller Class Initialized
INFO - 2023-04-22 17:40:10 --> Model Class Initialized
DEBUG - 2023-04-22 17:40:10 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-04-22 17:40:10 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-22 17:40:10 --> Model Class Initialized
DEBUG - 2023-04-22 17:40:10 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-22 17:40:10 --> Model Class Initialized
INFO - 2023-04-22 17:40:10 --> Final output sent to browser
DEBUG - 2023-04-22 17:40:10 --> Total execution time: 0.0168
ERROR - 2023-04-22 17:40:18 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-22 17:40:18 --> Config Class Initialized
INFO - 2023-04-22 17:40:18 --> Hooks Class Initialized
DEBUG - 2023-04-22 17:40:18 --> UTF-8 Support Enabled
INFO - 2023-04-22 17:40:18 --> Utf8 Class Initialized
INFO - 2023-04-22 17:40:18 --> URI Class Initialized
INFO - 2023-04-22 17:40:18 --> Router Class Initialized
INFO - 2023-04-22 17:40:18 --> Output Class Initialized
INFO - 2023-04-22 17:40:18 --> Security Class Initialized
DEBUG - 2023-04-22 17:40:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-22 17:40:18 --> Input Class Initialized
INFO - 2023-04-22 17:40:18 --> Language Class Initialized
INFO - 2023-04-22 17:40:18 --> Loader Class Initialized
INFO - 2023-04-22 17:40:18 --> Helper loaded: url_helper
INFO - 2023-04-22 17:40:18 --> Helper loaded: file_helper
INFO - 2023-04-22 17:40:18 --> Helper loaded: html_helper
INFO - 2023-04-22 17:40:18 --> Helper loaded: text_helper
INFO - 2023-04-22 17:40:18 --> Helper loaded: form_helper
INFO - 2023-04-22 17:40:18 --> Helper loaded: lang_helper
INFO - 2023-04-22 17:40:18 --> Helper loaded: security_helper
INFO - 2023-04-22 17:40:18 --> Helper loaded: cookie_helper
INFO - 2023-04-22 17:40:18 --> Database Driver Class Initialized
INFO - 2023-04-22 17:40:18 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-22 17:40:18 --> Parser Class Initialized
INFO - 2023-04-22 17:40:18 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-22 17:40:18 --> Pagination Class Initialized
INFO - 2023-04-22 17:40:18 --> Form Validation Class Initialized
INFO - 2023-04-22 17:40:18 --> Controller Class Initialized
INFO - 2023-04-22 17:40:18 --> Model Class Initialized
DEBUG - 2023-04-22 17:40:18 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-04-22 17:40:18 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-22 17:40:18 --> Model Class Initialized
DEBUG - 2023-04-22 17:40:18 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-22 17:40:18 --> Model Class Initialized
INFO - 2023-04-22 17:40:18 --> Final output sent to browser
DEBUG - 2023-04-22 17:40:18 --> Total execution time: 0.0172
ERROR - 2023-04-22 17:40:22 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-22 17:40:22 --> Config Class Initialized
INFO - 2023-04-22 17:40:22 --> Hooks Class Initialized
DEBUG - 2023-04-22 17:40:22 --> UTF-8 Support Enabled
INFO - 2023-04-22 17:40:22 --> Utf8 Class Initialized
INFO - 2023-04-22 17:40:22 --> URI Class Initialized
INFO - 2023-04-22 17:40:22 --> Router Class Initialized
INFO - 2023-04-22 17:40:22 --> Output Class Initialized
INFO - 2023-04-22 17:40:22 --> Security Class Initialized
DEBUG - 2023-04-22 17:40:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-22 17:40:22 --> Input Class Initialized
INFO - 2023-04-22 17:40:22 --> Language Class Initialized
INFO - 2023-04-22 17:40:22 --> Loader Class Initialized
INFO - 2023-04-22 17:40:22 --> Helper loaded: url_helper
INFO - 2023-04-22 17:40:22 --> Helper loaded: file_helper
INFO - 2023-04-22 17:40:22 --> Helper loaded: html_helper
INFO - 2023-04-22 17:40:22 --> Helper loaded: text_helper
INFO - 2023-04-22 17:40:22 --> Helper loaded: form_helper
INFO - 2023-04-22 17:40:22 --> Helper loaded: lang_helper
INFO - 2023-04-22 17:40:22 --> Helper loaded: security_helper
INFO - 2023-04-22 17:40:22 --> Helper loaded: cookie_helper
INFO - 2023-04-22 17:40:22 --> Database Driver Class Initialized
INFO - 2023-04-22 17:40:22 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-22 17:40:22 --> Parser Class Initialized
INFO - 2023-04-22 17:40:22 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-22 17:40:22 --> Pagination Class Initialized
INFO - 2023-04-22 17:40:22 --> Form Validation Class Initialized
INFO - 2023-04-22 17:40:22 --> Controller Class Initialized
INFO - 2023-04-22 17:40:22 --> Model Class Initialized
DEBUG - 2023-04-22 17:40:22 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-04-22 17:40:22 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-22 17:40:22 --> Model Class Initialized
DEBUG - 2023-04-22 17:40:22 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-22 17:40:22 --> Model Class Initialized
INFO - 2023-04-22 17:40:22 --> Model Class Initialized
INFO - 2023-04-22 17:40:22 --> Final output sent to browser
DEBUG - 2023-04-22 17:40:22 --> Total execution time: 0.0236
ERROR - 2023-04-22 17:40:24 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-22 17:40:24 --> Config Class Initialized
INFO - 2023-04-22 17:40:24 --> Hooks Class Initialized
DEBUG - 2023-04-22 17:40:24 --> UTF-8 Support Enabled
INFO - 2023-04-22 17:40:24 --> Utf8 Class Initialized
INFO - 2023-04-22 17:40:24 --> URI Class Initialized
INFO - 2023-04-22 17:40:24 --> Router Class Initialized
INFO - 2023-04-22 17:40:24 --> Output Class Initialized
INFO - 2023-04-22 17:40:24 --> Security Class Initialized
DEBUG - 2023-04-22 17:40:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-22 17:40:24 --> Input Class Initialized
INFO - 2023-04-22 17:40:24 --> Language Class Initialized
INFO - 2023-04-22 17:40:24 --> Loader Class Initialized
INFO - 2023-04-22 17:40:24 --> Helper loaded: url_helper
INFO - 2023-04-22 17:40:24 --> Helper loaded: file_helper
INFO - 2023-04-22 17:40:24 --> Helper loaded: html_helper
INFO - 2023-04-22 17:40:24 --> Helper loaded: text_helper
INFO - 2023-04-22 17:40:24 --> Helper loaded: form_helper
INFO - 2023-04-22 17:40:24 --> Helper loaded: lang_helper
INFO - 2023-04-22 17:40:24 --> Helper loaded: security_helper
INFO - 2023-04-22 17:40:24 --> Helper loaded: cookie_helper
INFO - 2023-04-22 17:40:24 --> Database Driver Class Initialized
INFO - 2023-04-22 17:40:24 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-22 17:40:24 --> Parser Class Initialized
INFO - 2023-04-22 17:40:24 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-22 17:40:24 --> Pagination Class Initialized
INFO - 2023-04-22 17:40:24 --> Form Validation Class Initialized
INFO - 2023-04-22 17:40:24 --> Controller Class Initialized
INFO - 2023-04-22 17:40:24 --> Model Class Initialized
DEBUG - 2023-04-22 17:40:24 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-04-22 17:40:24 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-22 17:40:24 --> Model Class Initialized
DEBUG - 2023-04-22 17:40:24 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-22 17:40:24 --> Model Class Initialized
INFO - 2023-04-22 17:40:24 --> Final output sent to browser
DEBUG - 2023-04-22 17:40:24 --> Total execution time: 0.0181
ERROR - 2023-04-22 17:40:45 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-22 17:40:45 --> Config Class Initialized
INFO - 2023-04-22 17:40:45 --> Hooks Class Initialized
DEBUG - 2023-04-22 17:40:45 --> UTF-8 Support Enabled
INFO - 2023-04-22 17:40:45 --> Utf8 Class Initialized
INFO - 2023-04-22 17:40:45 --> URI Class Initialized
INFO - 2023-04-22 17:40:45 --> Router Class Initialized
INFO - 2023-04-22 17:40:45 --> Output Class Initialized
INFO - 2023-04-22 17:40:45 --> Security Class Initialized
DEBUG - 2023-04-22 17:40:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-22 17:40:45 --> Input Class Initialized
INFO - 2023-04-22 17:40:45 --> Language Class Initialized
INFO - 2023-04-22 17:40:45 --> Loader Class Initialized
INFO - 2023-04-22 17:40:45 --> Helper loaded: url_helper
INFO - 2023-04-22 17:40:45 --> Helper loaded: file_helper
INFO - 2023-04-22 17:40:45 --> Helper loaded: html_helper
INFO - 2023-04-22 17:40:45 --> Helper loaded: text_helper
INFO - 2023-04-22 17:40:45 --> Helper loaded: form_helper
INFO - 2023-04-22 17:40:45 --> Helper loaded: lang_helper
INFO - 2023-04-22 17:40:45 --> Helper loaded: security_helper
INFO - 2023-04-22 17:40:45 --> Helper loaded: cookie_helper
INFO - 2023-04-22 17:40:45 --> Database Driver Class Initialized
INFO - 2023-04-22 17:40:45 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-22 17:40:45 --> Parser Class Initialized
INFO - 2023-04-22 17:40:45 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-22 17:40:45 --> Pagination Class Initialized
INFO - 2023-04-22 17:40:45 --> Form Validation Class Initialized
INFO - 2023-04-22 17:40:45 --> Controller Class Initialized
INFO - 2023-04-22 17:40:45 --> Model Class Initialized
DEBUG - 2023-04-22 17:40:45 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-04-22 17:40:45 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-22 17:40:45 --> Model Class Initialized
DEBUG - 2023-04-22 17:40:45 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-22 17:40:45 --> Model Class Initialized
INFO - 2023-04-22 17:40:45 --> Final output sent to browser
DEBUG - 2023-04-22 17:40:45 --> Total execution time: 0.0205
ERROR - 2023-04-22 17:40:45 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-22 17:40:45 --> Config Class Initialized
INFO - 2023-04-22 17:40:45 --> Hooks Class Initialized
DEBUG - 2023-04-22 17:40:45 --> UTF-8 Support Enabled
INFO - 2023-04-22 17:40:45 --> Utf8 Class Initialized
INFO - 2023-04-22 17:40:45 --> URI Class Initialized
INFO - 2023-04-22 17:40:45 --> Router Class Initialized
INFO - 2023-04-22 17:40:45 --> Output Class Initialized
INFO - 2023-04-22 17:40:45 --> Security Class Initialized
DEBUG - 2023-04-22 17:40:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-22 17:40:45 --> Input Class Initialized
INFO - 2023-04-22 17:40:45 --> Language Class Initialized
INFO - 2023-04-22 17:40:45 --> Loader Class Initialized
INFO - 2023-04-22 17:40:45 --> Helper loaded: url_helper
INFO - 2023-04-22 17:40:45 --> Helper loaded: file_helper
INFO - 2023-04-22 17:40:45 --> Helper loaded: html_helper
INFO - 2023-04-22 17:40:45 --> Helper loaded: text_helper
INFO - 2023-04-22 17:40:45 --> Helper loaded: form_helper
INFO - 2023-04-22 17:40:45 --> Helper loaded: lang_helper
INFO - 2023-04-22 17:40:45 --> Helper loaded: security_helper
INFO - 2023-04-22 17:40:45 --> Helper loaded: cookie_helper
INFO - 2023-04-22 17:40:45 --> Database Driver Class Initialized
INFO - 2023-04-22 17:40:45 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-22 17:40:45 --> Parser Class Initialized
INFO - 2023-04-22 17:40:45 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-22 17:40:45 --> Pagination Class Initialized
INFO - 2023-04-22 17:40:45 --> Form Validation Class Initialized
INFO - 2023-04-22 17:40:45 --> Controller Class Initialized
INFO - 2023-04-22 17:40:45 --> Model Class Initialized
DEBUG - 2023-04-22 17:40:45 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-04-22 17:40:45 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-22 17:40:45 --> Model Class Initialized
DEBUG - 2023-04-22 17:40:45 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-22 17:40:45 --> Model Class Initialized
INFO - 2023-04-22 17:40:45 --> Final output sent to browser
DEBUG - 2023-04-22 17:40:45 --> Total execution time: 0.0167
ERROR - 2023-04-22 17:40:46 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-22 17:40:46 --> Config Class Initialized
INFO - 2023-04-22 17:40:46 --> Hooks Class Initialized
DEBUG - 2023-04-22 17:40:46 --> UTF-8 Support Enabled
INFO - 2023-04-22 17:40:46 --> Utf8 Class Initialized
INFO - 2023-04-22 17:40:46 --> URI Class Initialized
INFO - 2023-04-22 17:40:46 --> Router Class Initialized
INFO - 2023-04-22 17:40:46 --> Output Class Initialized
INFO - 2023-04-22 17:40:46 --> Security Class Initialized
DEBUG - 2023-04-22 17:40:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-22 17:40:46 --> Input Class Initialized
INFO - 2023-04-22 17:40:46 --> Language Class Initialized
INFO - 2023-04-22 17:40:46 --> Loader Class Initialized
INFO - 2023-04-22 17:40:46 --> Helper loaded: url_helper
INFO - 2023-04-22 17:40:46 --> Helper loaded: file_helper
INFO - 2023-04-22 17:40:46 --> Helper loaded: html_helper
INFO - 2023-04-22 17:40:46 --> Helper loaded: text_helper
INFO - 2023-04-22 17:40:46 --> Helper loaded: form_helper
INFO - 2023-04-22 17:40:46 --> Helper loaded: lang_helper
INFO - 2023-04-22 17:40:46 --> Helper loaded: security_helper
INFO - 2023-04-22 17:40:46 --> Helper loaded: cookie_helper
INFO - 2023-04-22 17:40:46 --> Database Driver Class Initialized
INFO - 2023-04-22 17:40:46 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-22 17:40:46 --> Parser Class Initialized
INFO - 2023-04-22 17:40:46 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-22 17:40:46 --> Pagination Class Initialized
INFO - 2023-04-22 17:40:46 --> Form Validation Class Initialized
INFO - 2023-04-22 17:40:46 --> Controller Class Initialized
INFO - 2023-04-22 17:40:46 --> Model Class Initialized
DEBUG - 2023-04-22 17:40:46 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-04-22 17:40:46 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-22 17:40:46 --> Model Class Initialized
DEBUG - 2023-04-22 17:40:46 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-22 17:40:46 --> Model Class Initialized
INFO - 2023-04-22 17:40:46 --> Final output sent to browser
DEBUG - 2023-04-22 17:40:46 --> Total execution time: 0.0173
ERROR - 2023-04-22 17:40:46 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-22 17:40:46 --> Config Class Initialized
INFO - 2023-04-22 17:40:46 --> Hooks Class Initialized
DEBUG - 2023-04-22 17:40:46 --> UTF-8 Support Enabled
INFO - 2023-04-22 17:40:46 --> Utf8 Class Initialized
INFO - 2023-04-22 17:40:46 --> URI Class Initialized
INFO - 2023-04-22 17:40:46 --> Router Class Initialized
INFO - 2023-04-22 17:40:46 --> Output Class Initialized
INFO - 2023-04-22 17:40:46 --> Security Class Initialized
DEBUG - 2023-04-22 17:40:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-22 17:40:46 --> Input Class Initialized
INFO - 2023-04-22 17:40:46 --> Language Class Initialized
INFO - 2023-04-22 17:40:46 --> Loader Class Initialized
INFO - 2023-04-22 17:40:46 --> Helper loaded: url_helper
INFO - 2023-04-22 17:40:46 --> Helper loaded: file_helper
INFO - 2023-04-22 17:40:46 --> Helper loaded: html_helper
INFO - 2023-04-22 17:40:46 --> Helper loaded: text_helper
INFO - 2023-04-22 17:40:46 --> Helper loaded: form_helper
INFO - 2023-04-22 17:40:46 --> Helper loaded: lang_helper
INFO - 2023-04-22 17:40:46 --> Helper loaded: security_helper
INFO - 2023-04-22 17:40:46 --> Helper loaded: cookie_helper
INFO - 2023-04-22 17:40:46 --> Database Driver Class Initialized
INFO - 2023-04-22 17:40:46 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-22 17:40:46 --> Parser Class Initialized
INFO - 2023-04-22 17:40:46 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-22 17:40:46 --> Pagination Class Initialized
INFO - 2023-04-22 17:40:46 --> Form Validation Class Initialized
INFO - 2023-04-22 17:40:46 --> Controller Class Initialized
INFO - 2023-04-22 17:40:46 --> Model Class Initialized
DEBUG - 2023-04-22 17:40:46 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-04-22 17:40:46 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-22 17:40:46 --> Model Class Initialized
DEBUG - 2023-04-22 17:40:46 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-22 17:40:46 --> Model Class Initialized
INFO - 2023-04-22 17:40:46 --> Final output sent to browser
DEBUG - 2023-04-22 17:40:46 --> Total execution time: 0.0175
ERROR - 2023-04-22 17:40:47 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-22 17:40:47 --> Config Class Initialized
INFO - 2023-04-22 17:40:47 --> Hooks Class Initialized
DEBUG - 2023-04-22 17:40:47 --> UTF-8 Support Enabled
INFO - 2023-04-22 17:40:47 --> Utf8 Class Initialized
INFO - 2023-04-22 17:40:47 --> URI Class Initialized
INFO - 2023-04-22 17:40:47 --> Router Class Initialized
INFO - 2023-04-22 17:40:47 --> Output Class Initialized
INFO - 2023-04-22 17:40:47 --> Security Class Initialized
DEBUG - 2023-04-22 17:40:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-22 17:40:47 --> Input Class Initialized
INFO - 2023-04-22 17:40:47 --> Language Class Initialized
INFO - 2023-04-22 17:40:47 --> Loader Class Initialized
INFO - 2023-04-22 17:40:47 --> Helper loaded: url_helper
INFO - 2023-04-22 17:40:47 --> Helper loaded: file_helper
INFO - 2023-04-22 17:40:47 --> Helper loaded: html_helper
INFO - 2023-04-22 17:40:47 --> Helper loaded: text_helper
INFO - 2023-04-22 17:40:47 --> Helper loaded: form_helper
INFO - 2023-04-22 17:40:47 --> Helper loaded: lang_helper
INFO - 2023-04-22 17:40:47 --> Helper loaded: security_helper
INFO - 2023-04-22 17:40:47 --> Helper loaded: cookie_helper
INFO - 2023-04-22 17:40:47 --> Database Driver Class Initialized
INFO - 2023-04-22 17:40:47 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-22 17:40:47 --> Parser Class Initialized
INFO - 2023-04-22 17:40:47 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-22 17:40:47 --> Pagination Class Initialized
INFO - 2023-04-22 17:40:47 --> Form Validation Class Initialized
INFO - 2023-04-22 17:40:47 --> Controller Class Initialized
INFO - 2023-04-22 17:40:47 --> Model Class Initialized
DEBUG - 2023-04-22 17:40:47 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-04-22 17:40:47 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-22 17:40:47 --> Model Class Initialized
DEBUG - 2023-04-22 17:40:47 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-22 17:40:47 --> Model Class Initialized
INFO - 2023-04-22 17:40:47 --> Final output sent to browser
DEBUG - 2023-04-22 17:40:47 --> Total execution time: 0.0178
ERROR - 2023-04-22 17:40:49 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-22 17:40:49 --> Config Class Initialized
INFO - 2023-04-22 17:40:49 --> Hooks Class Initialized
DEBUG - 2023-04-22 17:40:49 --> UTF-8 Support Enabled
INFO - 2023-04-22 17:40:49 --> Utf8 Class Initialized
INFO - 2023-04-22 17:40:49 --> URI Class Initialized
INFO - 2023-04-22 17:40:49 --> Router Class Initialized
INFO - 2023-04-22 17:40:49 --> Output Class Initialized
INFO - 2023-04-22 17:40:49 --> Security Class Initialized
DEBUG - 2023-04-22 17:40:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-22 17:40:49 --> Input Class Initialized
INFO - 2023-04-22 17:40:49 --> Language Class Initialized
INFO - 2023-04-22 17:40:49 --> Loader Class Initialized
INFO - 2023-04-22 17:40:49 --> Helper loaded: url_helper
INFO - 2023-04-22 17:40:49 --> Helper loaded: file_helper
INFO - 2023-04-22 17:40:49 --> Helper loaded: html_helper
INFO - 2023-04-22 17:40:49 --> Helper loaded: text_helper
INFO - 2023-04-22 17:40:49 --> Helper loaded: form_helper
INFO - 2023-04-22 17:40:49 --> Helper loaded: lang_helper
INFO - 2023-04-22 17:40:49 --> Helper loaded: security_helper
INFO - 2023-04-22 17:40:49 --> Helper loaded: cookie_helper
INFO - 2023-04-22 17:40:49 --> Database Driver Class Initialized
INFO - 2023-04-22 17:40:49 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-22 17:40:49 --> Parser Class Initialized
INFO - 2023-04-22 17:40:49 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-22 17:40:49 --> Pagination Class Initialized
INFO - 2023-04-22 17:40:49 --> Form Validation Class Initialized
INFO - 2023-04-22 17:40:49 --> Controller Class Initialized
INFO - 2023-04-22 17:40:49 --> Model Class Initialized
DEBUG - 2023-04-22 17:40:49 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-04-22 17:40:49 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-22 17:40:49 --> Model Class Initialized
DEBUG - 2023-04-22 17:40:49 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-22 17:40:49 --> Model Class Initialized
INFO - 2023-04-22 17:40:49 --> Model Class Initialized
INFO - 2023-04-22 17:40:49 --> Final output sent to browser
DEBUG - 2023-04-22 17:40:49 --> Total execution time: 0.0212
ERROR - 2023-04-22 17:40:52 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-22 17:40:52 --> Config Class Initialized
INFO - 2023-04-22 17:40:52 --> Hooks Class Initialized
DEBUG - 2023-04-22 17:40:52 --> UTF-8 Support Enabled
INFO - 2023-04-22 17:40:52 --> Utf8 Class Initialized
INFO - 2023-04-22 17:40:52 --> URI Class Initialized
INFO - 2023-04-22 17:40:52 --> Router Class Initialized
INFO - 2023-04-22 17:40:52 --> Output Class Initialized
INFO - 2023-04-22 17:40:52 --> Security Class Initialized
DEBUG - 2023-04-22 17:40:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-22 17:40:52 --> Input Class Initialized
INFO - 2023-04-22 17:40:52 --> Language Class Initialized
INFO - 2023-04-22 17:40:52 --> Loader Class Initialized
INFO - 2023-04-22 17:40:52 --> Helper loaded: url_helper
INFO - 2023-04-22 17:40:52 --> Helper loaded: file_helper
INFO - 2023-04-22 17:40:52 --> Helper loaded: html_helper
INFO - 2023-04-22 17:40:52 --> Helper loaded: text_helper
INFO - 2023-04-22 17:40:52 --> Helper loaded: form_helper
INFO - 2023-04-22 17:40:52 --> Helper loaded: lang_helper
INFO - 2023-04-22 17:40:52 --> Helper loaded: security_helper
INFO - 2023-04-22 17:40:52 --> Helper loaded: cookie_helper
INFO - 2023-04-22 17:40:52 --> Database Driver Class Initialized
INFO - 2023-04-22 17:40:52 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-22 17:40:52 --> Parser Class Initialized
INFO - 2023-04-22 17:40:52 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-22 17:40:52 --> Pagination Class Initialized
INFO - 2023-04-22 17:40:52 --> Form Validation Class Initialized
INFO - 2023-04-22 17:40:52 --> Controller Class Initialized
INFO - 2023-04-22 17:40:52 --> Model Class Initialized
DEBUG - 2023-04-22 17:40:52 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-04-22 17:40:52 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-22 17:40:52 --> Model Class Initialized
DEBUG - 2023-04-22 17:40:52 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-22 17:40:52 --> Model Class Initialized
INFO - 2023-04-22 17:40:52 --> Final output sent to browser
DEBUG - 2023-04-22 17:40:52 --> Total execution time: 0.0182
ERROR - 2023-04-22 17:41:01 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-22 17:41:01 --> Config Class Initialized
INFO - 2023-04-22 17:41:01 --> Hooks Class Initialized
DEBUG - 2023-04-22 17:41:01 --> UTF-8 Support Enabled
INFO - 2023-04-22 17:41:01 --> Utf8 Class Initialized
INFO - 2023-04-22 17:41:01 --> URI Class Initialized
INFO - 2023-04-22 17:41:01 --> Router Class Initialized
INFO - 2023-04-22 17:41:01 --> Output Class Initialized
INFO - 2023-04-22 17:41:01 --> Security Class Initialized
DEBUG - 2023-04-22 17:41:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-22 17:41:01 --> Input Class Initialized
INFO - 2023-04-22 17:41:01 --> Language Class Initialized
INFO - 2023-04-22 17:41:01 --> Loader Class Initialized
INFO - 2023-04-22 17:41:01 --> Helper loaded: url_helper
INFO - 2023-04-22 17:41:01 --> Helper loaded: file_helper
INFO - 2023-04-22 17:41:01 --> Helper loaded: html_helper
INFO - 2023-04-22 17:41:01 --> Helper loaded: text_helper
INFO - 2023-04-22 17:41:01 --> Helper loaded: form_helper
INFO - 2023-04-22 17:41:01 --> Helper loaded: lang_helper
INFO - 2023-04-22 17:41:01 --> Helper loaded: security_helper
INFO - 2023-04-22 17:41:01 --> Helper loaded: cookie_helper
INFO - 2023-04-22 17:41:01 --> Database Driver Class Initialized
INFO - 2023-04-22 17:41:01 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-22 17:41:01 --> Parser Class Initialized
INFO - 2023-04-22 17:41:01 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-22 17:41:01 --> Pagination Class Initialized
INFO - 2023-04-22 17:41:01 --> Form Validation Class Initialized
INFO - 2023-04-22 17:41:01 --> Controller Class Initialized
INFO - 2023-04-22 17:41:01 --> Model Class Initialized
DEBUG - 2023-04-22 17:41:01 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-04-22 17:41:01 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-22 17:41:01 --> Model Class Initialized
DEBUG - 2023-04-22 17:41:01 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-22 17:41:01 --> Model Class Initialized
INFO - 2023-04-22 17:41:01 --> Final output sent to browser
DEBUG - 2023-04-22 17:41:01 --> Total execution time: 0.0181
ERROR - 2023-04-22 17:41:02 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-22 17:41:02 --> Config Class Initialized
INFO - 2023-04-22 17:41:02 --> Hooks Class Initialized
DEBUG - 2023-04-22 17:41:02 --> UTF-8 Support Enabled
INFO - 2023-04-22 17:41:02 --> Utf8 Class Initialized
INFO - 2023-04-22 17:41:02 --> URI Class Initialized
INFO - 2023-04-22 17:41:02 --> Router Class Initialized
INFO - 2023-04-22 17:41:02 --> Output Class Initialized
INFO - 2023-04-22 17:41:02 --> Security Class Initialized
DEBUG - 2023-04-22 17:41:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-22 17:41:02 --> Input Class Initialized
INFO - 2023-04-22 17:41:02 --> Language Class Initialized
INFO - 2023-04-22 17:41:02 --> Loader Class Initialized
INFO - 2023-04-22 17:41:02 --> Helper loaded: url_helper
INFO - 2023-04-22 17:41:02 --> Helper loaded: file_helper
INFO - 2023-04-22 17:41:02 --> Helper loaded: html_helper
INFO - 2023-04-22 17:41:02 --> Helper loaded: text_helper
INFO - 2023-04-22 17:41:02 --> Helper loaded: form_helper
INFO - 2023-04-22 17:41:02 --> Helper loaded: lang_helper
INFO - 2023-04-22 17:41:02 --> Helper loaded: security_helper
INFO - 2023-04-22 17:41:02 --> Helper loaded: cookie_helper
INFO - 2023-04-22 17:41:02 --> Database Driver Class Initialized
INFO - 2023-04-22 17:41:02 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-22 17:41:02 --> Parser Class Initialized
INFO - 2023-04-22 17:41:02 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-22 17:41:02 --> Pagination Class Initialized
INFO - 2023-04-22 17:41:02 --> Form Validation Class Initialized
INFO - 2023-04-22 17:41:02 --> Controller Class Initialized
INFO - 2023-04-22 17:41:02 --> Model Class Initialized
DEBUG - 2023-04-22 17:41:02 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-04-22 17:41:02 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-22 17:41:02 --> Model Class Initialized
DEBUG - 2023-04-22 17:41:02 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-22 17:41:02 --> Model Class Initialized
INFO - 2023-04-22 17:41:02 --> Final output sent to browser
DEBUG - 2023-04-22 17:41:02 --> Total execution time: 0.0199
ERROR - 2023-04-22 17:41:02 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-22 17:41:02 --> Config Class Initialized
INFO - 2023-04-22 17:41:02 --> Hooks Class Initialized
DEBUG - 2023-04-22 17:41:02 --> UTF-8 Support Enabled
INFO - 2023-04-22 17:41:02 --> Utf8 Class Initialized
INFO - 2023-04-22 17:41:02 --> URI Class Initialized
INFO - 2023-04-22 17:41:02 --> Router Class Initialized
INFO - 2023-04-22 17:41:02 --> Output Class Initialized
INFO - 2023-04-22 17:41:02 --> Security Class Initialized
DEBUG - 2023-04-22 17:41:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-22 17:41:02 --> Input Class Initialized
INFO - 2023-04-22 17:41:02 --> Language Class Initialized
INFO - 2023-04-22 17:41:02 --> Loader Class Initialized
INFO - 2023-04-22 17:41:02 --> Helper loaded: url_helper
INFO - 2023-04-22 17:41:02 --> Helper loaded: file_helper
INFO - 2023-04-22 17:41:02 --> Helper loaded: html_helper
INFO - 2023-04-22 17:41:02 --> Helper loaded: text_helper
INFO - 2023-04-22 17:41:02 --> Helper loaded: form_helper
INFO - 2023-04-22 17:41:02 --> Helper loaded: lang_helper
INFO - 2023-04-22 17:41:02 --> Helper loaded: security_helper
INFO - 2023-04-22 17:41:02 --> Helper loaded: cookie_helper
INFO - 2023-04-22 17:41:02 --> Database Driver Class Initialized
INFO - 2023-04-22 17:41:02 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-22 17:41:02 --> Parser Class Initialized
INFO - 2023-04-22 17:41:02 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-22 17:41:02 --> Pagination Class Initialized
INFO - 2023-04-22 17:41:02 --> Form Validation Class Initialized
INFO - 2023-04-22 17:41:02 --> Controller Class Initialized
INFO - 2023-04-22 17:41:02 --> Model Class Initialized
DEBUG - 2023-04-22 17:41:02 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-04-22 17:41:02 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-22 17:41:02 --> Model Class Initialized
DEBUG - 2023-04-22 17:41:02 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-22 17:41:02 --> Model Class Initialized
INFO - 2023-04-22 17:41:02 --> Final output sent to browser
DEBUG - 2023-04-22 17:41:02 --> Total execution time: 0.0174
ERROR - 2023-04-22 17:41:02 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-22 17:41:02 --> Config Class Initialized
INFO - 2023-04-22 17:41:02 --> Hooks Class Initialized
DEBUG - 2023-04-22 17:41:02 --> UTF-8 Support Enabled
INFO - 2023-04-22 17:41:02 --> Utf8 Class Initialized
INFO - 2023-04-22 17:41:02 --> URI Class Initialized
INFO - 2023-04-22 17:41:02 --> Router Class Initialized
INFO - 2023-04-22 17:41:02 --> Output Class Initialized
INFO - 2023-04-22 17:41:02 --> Security Class Initialized
DEBUG - 2023-04-22 17:41:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-22 17:41:02 --> Input Class Initialized
INFO - 2023-04-22 17:41:02 --> Language Class Initialized
INFO - 2023-04-22 17:41:02 --> Loader Class Initialized
INFO - 2023-04-22 17:41:02 --> Helper loaded: url_helper
INFO - 2023-04-22 17:41:02 --> Helper loaded: file_helper
INFO - 2023-04-22 17:41:02 --> Helper loaded: html_helper
INFO - 2023-04-22 17:41:02 --> Helper loaded: text_helper
INFO - 2023-04-22 17:41:02 --> Helper loaded: form_helper
INFO - 2023-04-22 17:41:02 --> Helper loaded: lang_helper
INFO - 2023-04-22 17:41:02 --> Helper loaded: security_helper
INFO - 2023-04-22 17:41:02 --> Helper loaded: cookie_helper
INFO - 2023-04-22 17:41:02 --> Database Driver Class Initialized
INFO - 2023-04-22 17:41:02 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-22 17:41:02 --> Parser Class Initialized
INFO - 2023-04-22 17:41:02 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-22 17:41:02 --> Pagination Class Initialized
INFO - 2023-04-22 17:41:02 --> Form Validation Class Initialized
INFO - 2023-04-22 17:41:02 --> Controller Class Initialized
INFO - 2023-04-22 17:41:02 --> Model Class Initialized
DEBUG - 2023-04-22 17:41:02 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-04-22 17:41:02 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-22 17:41:02 --> Model Class Initialized
DEBUG - 2023-04-22 17:41:02 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-22 17:41:02 --> Model Class Initialized
INFO - 2023-04-22 17:41:02 --> Final output sent to browser
DEBUG - 2023-04-22 17:41:02 --> Total execution time: 0.0178
ERROR - 2023-04-22 17:41:04 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-22 17:41:04 --> Config Class Initialized
INFO - 2023-04-22 17:41:04 --> Hooks Class Initialized
DEBUG - 2023-04-22 17:41:04 --> UTF-8 Support Enabled
INFO - 2023-04-22 17:41:04 --> Utf8 Class Initialized
INFO - 2023-04-22 17:41:04 --> URI Class Initialized
INFO - 2023-04-22 17:41:04 --> Router Class Initialized
INFO - 2023-04-22 17:41:04 --> Output Class Initialized
INFO - 2023-04-22 17:41:04 --> Security Class Initialized
DEBUG - 2023-04-22 17:41:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-22 17:41:04 --> Input Class Initialized
INFO - 2023-04-22 17:41:04 --> Language Class Initialized
INFO - 2023-04-22 17:41:04 --> Loader Class Initialized
INFO - 2023-04-22 17:41:04 --> Helper loaded: url_helper
INFO - 2023-04-22 17:41:04 --> Helper loaded: file_helper
INFO - 2023-04-22 17:41:04 --> Helper loaded: html_helper
INFO - 2023-04-22 17:41:04 --> Helper loaded: text_helper
INFO - 2023-04-22 17:41:04 --> Helper loaded: form_helper
INFO - 2023-04-22 17:41:04 --> Helper loaded: lang_helper
INFO - 2023-04-22 17:41:04 --> Helper loaded: security_helper
INFO - 2023-04-22 17:41:04 --> Helper loaded: cookie_helper
INFO - 2023-04-22 17:41:04 --> Database Driver Class Initialized
INFO - 2023-04-22 17:41:04 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-22 17:41:04 --> Parser Class Initialized
INFO - 2023-04-22 17:41:04 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-22 17:41:04 --> Pagination Class Initialized
INFO - 2023-04-22 17:41:04 --> Form Validation Class Initialized
INFO - 2023-04-22 17:41:04 --> Controller Class Initialized
INFO - 2023-04-22 17:41:04 --> Model Class Initialized
DEBUG - 2023-04-22 17:41:04 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-04-22 17:41:04 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-22 17:41:04 --> Model Class Initialized
DEBUG - 2023-04-22 17:41:04 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-22 17:41:04 --> Model Class Initialized
INFO - 2023-04-22 17:41:04 --> Final output sent to browser
DEBUG - 2023-04-22 17:41:04 --> Total execution time: 0.0171
ERROR - 2023-04-22 17:41:15 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-22 17:41:15 --> Config Class Initialized
INFO - 2023-04-22 17:41:15 --> Hooks Class Initialized
DEBUG - 2023-04-22 17:41:15 --> UTF-8 Support Enabled
INFO - 2023-04-22 17:41:15 --> Utf8 Class Initialized
INFO - 2023-04-22 17:41:15 --> URI Class Initialized
INFO - 2023-04-22 17:41:15 --> Router Class Initialized
INFO - 2023-04-22 17:41:15 --> Output Class Initialized
INFO - 2023-04-22 17:41:15 --> Security Class Initialized
DEBUG - 2023-04-22 17:41:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-22 17:41:15 --> Input Class Initialized
INFO - 2023-04-22 17:41:15 --> Language Class Initialized
INFO - 2023-04-22 17:41:15 --> Loader Class Initialized
INFO - 2023-04-22 17:41:15 --> Helper loaded: url_helper
INFO - 2023-04-22 17:41:15 --> Helper loaded: file_helper
INFO - 2023-04-22 17:41:15 --> Helper loaded: html_helper
INFO - 2023-04-22 17:41:15 --> Helper loaded: text_helper
INFO - 2023-04-22 17:41:15 --> Helper loaded: form_helper
INFO - 2023-04-22 17:41:15 --> Helper loaded: lang_helper
INFO - 2023-04-22 17:41:15 --> Helper loaded: security_helper
INFO - 2023-04-22 17:41:15 --> Helper loaded: cookie_helper
INFO - 2023-04-22 17:41:15 --> Database Driver Class Initialized
INFO - 2023-04-22 17:41:15 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-22 17:41:15 --> Parser Class Initialized
INFO - 2023-04-22 17:41:15 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-22 17:41:15 --> Pagination Class Initialized
INFO - 2023-04-22 17:41:15 --> Form Validation Class Initialized
INFO - 2023-04-22 17:41:15 --> Controller Class Initialized
INFO - 2023-04-22 17:41:15 --> Model Class Initialized
DEBUG - 2023-04-22 17:41:15 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-04-22 17:41:15 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-22 17:41:15 --> Model Class Initialized
DEBUG - 2023-04-22 17:41:15 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-22 17:41:15 --> Model Class Initialized
INFO - 2023-04-22 17:41:15 --> Final output sent to browser
DEBUG - 2023-04-22 17:41:15 --> Total execution time: 0.0175
ERROR - 2023-04-22 17:41:16 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-22 17:41:16 --> Config Class Initialized
INFO - 2023-04-22 17:41:16 --> Hooks Class Initialized
DEBUG - 2023-04-22 17:41:16 --> UTF-8 Support Enabled
INFO - 2023-04-22 17:41:16 --> Utf8 Class Initialized
INFO - 2023-04-22 17:41:16 --> URI Class Initialized
INFO - 2023-04-22 17:41:16 --> Router Class Initialized
INFO - 2023-04-22 17:41:16 --> Output Class Initialized
INFO - 2023-04-22 17:41:16 --> Security Class Initialized
DEBUG - 2023-04-22 17:41:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-22 17:41:16 --> Input Class Initialized
INFO - 2023-04-22 17:41:16 --> Language Class Initialized
INFO - 2023-04-22 17:41:16 --> Loader Class Initialized
INFO - 2023-04-22 17:41:16 --> Helper loaded: url_helper
INFO - 2023-04-22 17:41:16 --> Helper loaded: file_helper
INFO - 2023-04-22 17:41:16 --> Helper loaded: html_helper
INFO - 2023-04-22 17:41:16 --> Helper loaded: text_helper
INFO - 2023-04-22 17:41:16 --> Helper loaded: form_helper
INFO - 2023-04-22 17:41:16 --> Helper loaded: lang_helper
INFO - 2023-04-22 17:41:16 --> Helper loaded: security_helper
INFO - 2023-04-22 17:41:16 --> Helper loaded: cookie_helper
INFO - 2023-04-22 17:41:16 --> Database Driver Class Initialized
INFO - 2023-04-22 17:41:16 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-22 17:41:16 --> Parser Class Initialized
INFO - 2023-04-22 17:41:16 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-22 17:41:16 --> Pagination Class Initialized
INFO - 2023-04-22 17:41:16 --> Form Validation Class Initialized
INFO - 2023-04-22 17:41:16 --> Controller Class Initialized
INFO - 2023-04-22 17:41:16 --> Model Class Initialized
DEBUG - 2023-04-22 17:41:16 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-04-22 17:41:16 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-22 17:41:16 --> Model Class Initialized
DEBUG - 2023-04-22 17:41:16 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-22 17:41:16 --> Model Class Initialized
INFO - 2023-04-22 17:41:16 --> Final output sent to browser
DEBUG - 2023-04-22 17:41:16 --> Total execution time: 0.0182
ERROR - 2023-04-22 17:41:27 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-22 17:41:27 --> Config Class Initialized
INFO - 2023-04-22 17:41:27 --> Hooks Class Initialized
DEBUG - 2023-04-22 17:41:27 --> UTF-8 Support Enabled
INFO - 2023-04-22 17:41:27 --> Utf8 Class Initialized
INFO - 2023-04-22 17:41:27 --> URI Class Initialized
INFO - 2023-04-22 17:41:27 --> Router Class Initialized
INFO - 2023-04-22 17:41:27 --> Output Class Initialized
INFO - 2023-04-22 17:41:27 --> Security Class Initialized
DEBUG - 2023-04-22 17:41:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-22 17:41:27 --> Input Class Initialized
INFO - 2023-04-22 17:41:27 --> Language Class Initialized
INFO - 2023-04-22 17:41:27 --> Loader Class Initialized
INFO - 2023-04-22 17:41:27 --> Helper loaded: url_helper
INFO - 2023-04-22 17:41:27 --> Helper loaded: file_helper
INFO - 2023-04-22 17:41:27 --> Helper loaded: html_helper
INFO - 2023-04-22 17:41:27 --> Helper loaded: text_helper
INFO - 2023-04-22 17:41:27 --> Helper loaded: form_helper
INFO - 2023-04-22 17:41:27 --> Helper loaded: lang_helper
INFO - 2023-04-22 17:41:27 --> Helper loaded: security_helper
INFO - 2023-04-22 17:41:27 --> Helper loaded: cookie_helper
INFO - 2023-04-22 17:41:27 --> Database Driver Class Initialized
INFO - 2023-04-22 17:41:27 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-22 17:41:27 --> Parser Class Initialized
INFO - 2023-04-22 17:41:27 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-22 17:41:27 --> Pagination Class Initialized
INFO - 2023-04-22 17:41:27 --> Form Validation Class Initialized
INFO - 2023-04-22 17:41:27 --> Controller Class Initialized
INFO - 2023-04-22 17:41:27 --> Model Class Initialized
DEBUG - 2023-04-22 17:41:27 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-04-22 17:41:27 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-22 17:41:27 --> Model Class Initialized
ERROR - 2023-04-22 17:41:27 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-22 17:41:27 --> Config Class Initialized
INFO - 2023-04-22 17:41:27 --> Hooks Class Initialized
DEBUG - 2023-04-22 17:41:27 --> UTF-8 Support Enabled
INFO - 2023-04-22 17:41:27 --> Utf8 Class Initialized
INFO - 2023-04-22 17:41:27 --> URI Class Initialized
INFO - 2023-04-22 17:41:27 --> Router Class Initialized
INFO - 2023-04-22 17:41:27 --> Output Class Initialized
INFO - 2023-04-22 17:41:27 --> Security Class Initialized
DEBUG - 2023-04-22 17:41:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-22 17:41:27 --> Input Class Initialized
INFO - 2023-04-22 17:41:27 --> Language Class Initialized
INFO - 2023-04-22 17:41:27 --> Loader Class Initialized
INFO - 2023-04-22 17:41:27 --> Helper loaded: url_helper
INFO - 2023-04-22 17:41:27 --> Helper loaded: file_helper
INFO - 2023-04-22 17:41:27 --> Helper loaded: html_helper
INFO - 2023-04-22 17:41:27 --> Helper loaded: text_helper
INFO - 2023-04-22 17:41:27 --> Helper loaded: form_helper
INFO - 2023-04-22 17:41:27 --> Helper loaded: lang_helper
INFO - 2023-04-22 17:41:27 --> Helper loaded: security_helper
INFO - 2023-04-22 17:41:27 --> Helper loaded: cookie_helper
INFO - 2023-04-22 17:41:27 --> Database Driver Class Initialized
INFO - 2023-04-22 17:41:27 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-22 17:41:27 --> Parser Class Initialized
INFO - 2023-04-22 17:41:27 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-22 17:41:27 --> Pagination Class Initialized
INFO - 2023-04-22 17:41:27 --> Form Validation Class Initialized
INFO - 2023-04-22 17:41:27 --> Controller Class Initialized
INFO - 2023-04-22 17:41:27 --> Model Class Initialized
DEBUG - 2023-04-22 17:41:27 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-04-22 17:41:27 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-22 17:41:27 --> Model Class Initialized
DEBUG - 2023-04-22 17:41:27 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-22 17:41:28 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/stockrequest/stockrequest_html.php
DEBUG - 2023-04-22 17:41:28 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-04-22 17:41:28 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-04-22 17:41:28 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-04-22 17:41:28 --> Model Class Initialized
INFO - 2023-04-22 17:41:28 --> Model Class Initialized
INFO - 2023-04-22 17:41:28 --> Model Class Initialized
INFO - 2023-04-22 17:41:28 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-04-22 17:41:28 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-04-22 17:41:28 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-04-22 17:41:28 --> Final output sent to browser
DEBUG - 2023-04-22 17:41:28 --> Total execution time: 0.1239
ERROR - 2023-04-22 17:41:33 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-22 17:41:33 --> Config Class Initialized
INFO - 2023-04-22 17:41:33 --> Hooks Class Initialized
DEBUG - 2023-04-22 17:41:33 --> UTF-8 Support Enabled
INFO - 2023-04-22 17:41:33 --> Utf8 Class Initialized
INFO - 2023-04-22 17:41:33 --> URI Class Initialized
INFO - 2023-04-22 17:41:33 --> Router Class Initialized
INFO - 2023-04-22 17:41:33 --> Output Class Initialized
INFO - 2023-04-22 17:41:33 --> Security Class Initialized
DEBUG - 2023-04-22 17:41:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-22 17:41:33 --> Input Class Initialized
INFO - 2023-04-22 17:41:33 --> Language Class Initialized
INFO - 2023-04-22 17:41:33 --> Loader Class Initialized
INFO - 2023-04-22 17:41:33 --> Helper loaded: url_helper
INFO - 2023-04-22 17:41:33 --> Helper loaded: file_helper
INFO - 2023-04-22 17:41:33 --> Helper loaded: html_helper
INFO - 2023-04-22 17:41:33 --> Helper loaded: text_helper
INFO - 2023-04-22 17:41:33 --> Helper loaded: form_helper
INFO - 2023-04-22 17:41:33 --> Helper loaded: lang_helper
INFO - 2023-04-22 17:41:33 --> Helper loaded: security_helper
INFO - 2023-04-22 17:41:33 --> Helper loaded: cookie_helper
INFO - 2023-04-22 17:41:33 --> Database Driver Class Initialized
INFO - 2023-04-22 17:41:33 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-22 17:41:33 --> Parser Class Initialized
INFO - 2023-04-22 17:41:33 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-22 17:41:33 --> Pagination Class Initialized
INFO - 2023-04-22 17:41:33 --> Form Validation Class Initialized
INFO - 2023-04-22 17:41:33 --> Controller Class Initialized
INFO - 2023-04-22 17:41:33 --> Model Class Initialized
DEBUG - 2023-04-22 17:41:33 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-04-22 17:41:33 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-22 17:41:33 --> Model Class Initialized
INFO - 2023-04-22 17:41:33 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/stockrequest/inventory.php
DEBUG - 2023-04-22 17:41:33 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-04-22 17:41:33 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-04-22 17:41:33 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-04-22 17:41:33 --> Model Class Initialized
INFO - 2023-04-22 17:41:33 --> Model Class Initialized
INFO - 2023-04-22 17:41:33 --> Model Class Initialized
INFO - 2023-04-22 17:41:33 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-04-22 17:41:33 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-04-22 17:41:33 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-04-22 17:41:33 --> Final output sent to browser
DEBUG - 2023-04-22 17:41:33 --> Total execution time: 0.1327
ERROR - 2023-04-22 17:41:34 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-22 17:41:34 --> Config Class Initialized
INFO - 2023-04-22 17:41:34 --> Hooks Class Initialized
DEBUG - 2023-04-22 17:41:34 --> UTF-8 Support Enabled
INFO - 2023-04-22 17:41:34 --> Utf8 Class Initialized
INFO - 2023-04-22 17:41:34 --> URI Class Initialized
INFO - 2023-04-22 17:41:34 --> Router Class Initialized
INFO - 2023-04-22 17:41:34 --> Output Class Initialized
INFO - 2023-04-22 17:41:34 --> Security Class Initialized
DEBUG - 2023-04-22 17:41:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-22 17:41:34 --> Input Class Initialized
INFO - 2023-04-22 17:41:34 --> Language Class Initialized
INFO - 2023-04-22 17:41:34 --> Loader Class Initialized
INFO - 2023-04-22 17:41:34 --> Helper loaded: url_helper
INFO - 2023-04-22 17:41:34 --> Helper loaded: file_helper
INFO - 2023-04-22 17:41:34 --> Helper loaded: html_helper
INFO - 2023-04-22 17:41:34 --> Helper loaded: text_helper
INFO - 2023-04-22 17:41:34 --> Helper loaded: form_helper
INFO - 2023-04-22 17:41:34 --> Helper loaded: lang_helper
INFO - 2023-04-22 17:41:34 --> Helper loaded: security_helper
INFO - 2023-04-22 17:41:34 --> Helper loaded: cookie_helper
INFO - 2023-04-22 17:41:34 --> Database Driver Class Initialized
INFO - 2023-04-22 17:41:34 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-22 17:41:34 --> Parser Class Initialized
INFO - 2023-04-22 17:41:34 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-22 17:41:34 --> Pagination Class Initialized
INFO - 2023-04-22 17:41:34 --> Form Validation Class Initialized
INFO - 2023-04-22 17:41:34 --> Controller Class Initialized
INFO - 2023-04-22 17:41:34 --> Model Class Initialized
DEBUG - 2023-04-22 17:41:34 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-04-22 17:41:34 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-22 17:41:34 --> Model Class Initialized
INFO - 2023-04-22 17:41:34 --> Final output sent to browser
DEBUG - 2023-04-22 17:41:34 --> Total execution time: 0.0187
ERROR - 2023-04-22 17:41:50 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-22 17:41:50 --> Config Class Initialized
INFO - 2023-04-22 17:41:50 --> Hooks Class Initialized
DEBUG - 2023-04-22 17:41:50 --> UTF-8 Support Enabled
INFO - 2023-04-22 17:41:50 --> Utf8 Class Initialized
INFO - 2023-04-22 17:41:50 --> URI Class Initialized
INFO - 2023-04-22 17:41:50 --> Router Class Initialized
INFO - 2023-04-22 17:41:50 --> Output Class Initialized
INFO - 2023-04-22 17:41:50 --> Security Class Initialized
DEBUG - 2023-04-22 17:41:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-22 17:41:50 --> Input Class Initialized
INFO - 2023-04-22 17:41:50 --> Language Class Initialized
INFO - 2023-04-22 17:41:50 --> Loader Class Initialized
INFO - 2023-04-22 17:41:50 --> Helper loaded: url_helper
INFO - 2023-04-22 17:41:50 --> Helper loaded: file_helper
INFO - 2023-04-22 17:41:50 --> Helper loaded: html_helper
INFO - 2023-04-22 17:41:50 --> Helper loaded: text_helper
INFO - 2023-04-22 17:41:50 --> Helper loaded: form_helper
INFO - 2023-04-22 17:41:50 --> Helper loaded: lang_helper
INFO - 2023-04-22 17:41:50 --> Helper loaded: security_helper
INFO - 2023-04-22 17:41:50 --> Helper loaded: cookie_helper
INFO - 2023-04-22 17:41:50 --> Database Driver Class Initialized
INFO - 2023-04-22 17:41:50 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-22 17:41:50 --> Parser Class Initialized
INFO - 2023-04-22 17:41:50 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-22 17:41:50 --> Pagination Class Initialized
INFO - 2023-04-22 17:41:50 --> Form Validation Class Initialized
INFO - 2023-04-22 17:41:50 --> Controller Class Initialized
INFO - 2023-04-22 17:41:50 --> Model Class Initialized
DEBUG - 2023-04-22 17:41:50 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-04-22 17:41:50 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-22 17:41:50 --> Model Class Initialized
INFO - 2023-04-22 17:41:50 --> Final output sent to browser
DEBUG - 2023-04-22 17:41:50 --> Total execution time: 0.0258
ERROR - 2023-04-22 17:44:12 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-22 17:44:12 --> Config Class Initialized
INFO - 2023-04-22 17:44:12 --> Hooks Class Initialized
DEBUG - 2023-04-22 17:44:12 --> UTF-8 Support Enabled
INFO - 2023-04-22 17:44:12 --> Utf8 Class Initialized
INFO - 2023-04-22 17:44:12 --> URI Class Initialized
INFO - 2023-04-22 17:44:12 --> Router Class Initialized
INFO - 2023-04-22 17:44:12 --> Output Class Initialized
INFO - 2023-04-22 17:44:12 --> Security Class Initialized
DEBUG - 2023-04-22 17:44:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-22 17:44:12 --> Input Class Initialized
INFO - 2023-04-22 17:44:12 --> Language Class Initialized
INFO - 2023-04-22 17:44:12 --> Loader Class Initialized
INFO - 2023-04-22 17:44:12 --> Helper loaded: url_helper
INFO - 2023-04-22 17:44:12 --> Helper loaded: file_helper
INFO - 2023-04-22 17:44:12 --> Helper loaded: html_helper
INFO - 2023-04-22 17:44:12 --> Helper loaded: text_helper
INFO - 2023-04-22 17:44:12 --> Helper loaded: form_helper
INFO - 2023-04-22 17:44:12 --> Helper loaded: lang_helper
INFO - 2023-04-22 17:44:12 --> Helper loaded: security_helper
INFO - 2023-04-22 17:44:12 --> Helper loaded: cookie_helper
INFO - 2023-04-22 17:44:12 --> Database Driver Class Initialized
INFO - 2023-04-22 17:44:12 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-22 17:44:12 --> Parser Class Initialized
INFO - 2023-04-22 17:44:12 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-22 17:44:12 --> Pagination Class Initialized
INFO - 2023-04-22 17:44:12 --> Form Validation Class Initialized
INFO - 2023-04-22 17:44:12 --> Controller Class Initialized
DEBUG - 2023-04-22 17:44:12 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-04-22 17:44:12 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-22 17:44:12 --> Model Class Initialized
INFO - 2023-04-22 17:44:12 --> Model Class Initialized
INFO - 2023-04-22 17:44:12 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/manufacturer/manufacturer.php
DEBUG - 2023-04-22 17:44:12 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-04-22 17:44:12 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-04-22 17:44:12 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-04-22 17:44:12 --> Model Class Initialized
INFO - 2023-04-22 17:44:12 --> Model Class Initialized
INFO - 2023-04-22 17:44:12 --> Model Class Initialized
INFO - 2023-04-22 17:44:12 --> Model Class Initialized
INFO - 2023-04-22 17:44:12 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-04-22 17:44:12 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-04-22 17:44:12 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-04-22 17:44:12 --> Final output sent to browser
DEBUG - 2023-04-22 17:44:12 --> Total execution time: 0.1707
ERROR - 2023-04-22 17:44:24 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-22 17:44:24 --> Config Class Initialized
INFO - 2023-04-22 17:44:24 --> Hooks Class Initialized
DEBUG - 2023-04-22 17:44:24 --> UTF-8 Support Enabled
INFO - 2023-04-22 17:44:24 --> Utf8 Class Initialized
INFO - 2023-04-22 17:44:24 --> URI Class Initialized
INFO - 2023-04-22 17:44:24 --> Router Class Initialized
INFO - 2023-04-22 17:44:24 --> Output Class Initialized
INFO - 2023-04-22 17:44:24 --> Security Class Initialized
DEBUG - 2023-04-22 17:44:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-22 17:44:24 --> Input Class Initialized
INFO - 2023-04-22 17:44:24 --> Language Class Initialized
INFO - 2023-04-22 17:44:24 --> Loader Class Initialized
INFO - 2023-04-22 17:44:24 --> Helper loaded: url_helper
INFO - 2023-04-22 17:44:24 --> Helper loaded: file_helper
INFO - 2023-04-22 17:44:24 --> Helper loaded: html_helper
INFO - 2023-04-22 17:44:24 --> Helper loaded: text_helper
INFO - 2023-04-22 17:44:24 --> Helper loaded: form_helper
INFO - 2023-04-22 17:44:24 --> Helper loaded: lang_helper
INFO - 2023-04-22 17:44:24 --> Helper loaded: security_helper
INFO - 2023-04-22 17:44:24 --> Helper loaded: cookie_helper
INFO - 2023-04-22 17:44:24 --> Database Driver Class Initialized
INFO - 2023-04-22 17:44:24 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-22 17:44:24 --> Parser Class Initialized
INFO - 2023-04-22 17:44:24 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-22 17:44:24 --> Pagination Class Initialized
INFO - 2023-04-22 17:44:24 --> Form Validation Class Initialized
INFO - 2023-04-22 17:44:24 --> Controller Class Initialized
DEBUG - 2023-04-22 17:44:24 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-04-22 17:44:24 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-22 17:44:24 --> Model Class Initialized
INFO - 2023-04-22 17:44:24 --> Model Class Initialized
DEBUG - 2023-04-22 17:44:24 --> Lmr class already loaded. Second attempt ignored.
INFO - 2023-04-22 17:44:24 --> Model Class Initialized
INFO - 2023-04-22 17:44:24 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/mr/mr.php
DEBUG - 2023-04-22 17:44:24 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-04-22 17:44:24 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-04-22 17:44:24 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-04-22 17:44:24 --> Model Class Initialized
INFO - 2023-04-22 17:44:24 --> Model Class Initialized
INFO - 2023-04-22 17:44:24 --> Model Class Initialized
INFO - 2023-04-22 17:44:24 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-04-22 17:44:24 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-04-22 17:44:24 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-04-22 17:44:24 --> Final output sent to browser
DEBUG - 2023-04-22 17:44:24 --> Total execution time: 0.1446
ERROR - 2023-04-22 17:44:25 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-22 17:44:25 --> Config Class Initialized
INFO - 2023-04-22 17:44:25 --> Hooks Class Initialized
DEBUG - 2023-04-22 17:44:25 --> UTF-8 Support Enabled
INFO - 2023-04-22 17:44:25 --> Utf8 Class Initialized
INFO - 2023-04-22 17:44:25 --> URI Class Initialized
INFO - 2023-04-22 17:44:25 --> Router Class Initialized
INFO - 2023-04-22 17:44:25 --> Output Class Initialized
INFO - 2023-04-22 17:44:25 --> Security Class Initialized
DEBUG - 2023-04-22 17:44:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-22 17:44:25 --> Input Class Initialized
INFO - 2023-04-22 17:44:25 --> Language Class Initialized
INFO - 2023-04-22 17:44:25 --> Loader Class Initialized
INFO - 2023-04-22 17:44:25 --> Helper loaded: url_helper
INFO - 2023-04-22 17:44:25 --> Helper loaded: file_helper
INFO - 2023-04-22 17:44:25 --> Helper loaded: html_helper
INFO - 2023-04-22 17:44:25 --> Helper loaded: text_helper
INFO - 2023-04-22 17:44:25 --> Helper loaded: form_helper
INFO - 2023-04-22 17:44:25 --> Helper loaded: lang_helper
INFO - 2023-04-22 17:44:25 --> Helper loaded: security_helper
INFO - 2023-04-22 17:44:25 --> Helper loaded: cookie_helper
INFO - 2023-04-22 17:44:25 --> Database Driver Class Initialized
INFO - 2023-04-22 17:44:25 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-22 17:44:25 --> Parser Class Initialized
INFO - 2023-04-22 17:44:25 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-22 17:44:25 --> Pagination Class Initialized
INFO - 2023-04-22 17:44:25 --> Form Validation Class Initialized
INFO - 2023-04-22 17:44:25 --> Controller Class Initialized
DEBUG - 2023-04-22 17:44:25 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-04-22 17:44:25 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-22 17:44:25 --> Model Class Initialized
INFO - 2023-04-22 17:44:25 --> Model Class Initialized
INFO - 2023-04-22 17:44:25 --> Final output sent to browser
DEBUG - 2023-04-22 17:44:25 --> Total execution time: 0.0218
ERROR - 2023-04-22 17:44:38 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-22 17:44:38 --> Config Class Initialized
INFO - 2023-04-22 17:44:38 --> Hooks Class Initialized
DEBUG - 2023-04-22 17:44:38 --> UTF-8 Support Enabled
INFO - 2023-04-22 17:44:38 --> Utf8 Class Initialized
INFO - 2023-04-22 17:44:38 --> URI Class Initialized
DEBUG - 2023-04-22 17:44:38 --> No URI present. Default controller set.
INFO - 2023-04-22 17:44:38 --> Router Class Initialized
INFO - 2023-04-22 17:44:38 --> Output Class Initialized
INFO - 2023-04-22 17:44:38 --> Security Class Initialized
DEBUG - 2023-04-22 17:44:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-22 17:44:38 --> Input Class Initialized
INFO - 2023-04-22 17:44:38 --> Language Class Initialized
INFO - 2023-04-22 17:44:38 --> Loader Class Initialized
INFO - 2023-04-22 17:44:38 --> Helper loaded: url_helper
INFO - 2023-04-22 17:44:38 --> Helper loaded: file_helper
INFO - 2023-04-22 17:44:38 --> Helper loaded: html_helper
INFO - 2023-04-22 17:44:38 --> Helper loaded: text_helper
INFO - 2023-04-22 17:44:38 --> Helper loaded: form_helper
INFO - 2023-04-22 17:44:38 --> Helper loaded: lang_helper
INFO - 2023-04-22 17:44:38 --> Helper loaded: security_helper
INFO - 2023-04-22 17:44:38 --> Helper loaded: cookie_helper
INFO - 2023-04-22 17:44:38 --> Database Driver Class Initialized
INFO - 2023-04-22 17:44:38 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-22 17:44:38 --> Parser Class Initialized
INFO - 2023-04-22 17:44:38 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-22 17:44:38 --> Pagination Class Initialized
INFO - 2023-04-22 17:44:38 --> Form Validation Class Initialized
INFO - 2023-04-22 17:44:38 --> Controller Class Initialized
INFO - 2023-04-22 17:44:38 --> Model Class Initialized
DEBUG - 2023-04-22 17:44:38 --> Session class already loaded. Second attempt ignored.
ERROR - 2023-04-22 17:44:39 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-22 17:44:39 --> Config Class Initialized
INFO - 2023-04-22 17:44:39 --> Hooks Class Initialized
DEBUG - 2023-04-22 17:44:39 --> UTF-8 Support Enabled
INFO - 2023-04-22 17:44:39 --> Utf8 Class Initialized
INFO - 2023-04-22 17:44:39 --> URI Class Initialized
INFO - 2023-04-22 17:44:39 --> Router Class Initialized
INFO - 2023-04-22 17:44:39 --> Output Class Initialized
INFO - 2023-04-22 17:44:39 --> Security Class Initialized
DEBUG - 2023-04-22 17:44:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-22 17:44:39 --> Input Class Initialized
INFO - 2023-04-22 17:44:39 --> Language Class Initialized
INFO - 2023-04-22 17:44:39 --> Loader Class Initialized
INFO - 2023-04-22 17:44:39 --> Helper loaded: url_helper
INFO - 2023-04-22 17:44:39 --> Helper loaded: file_helper
INFO - 2023-04-22 17:44:39 --> Helper loaded: html_helper
INFO - 2023-04-22 17:44:39 --> Helper loaded: text_helper
INFO - 2023-04-22 17:44:39 --> Helper loaded: form_helper
INFO - 2023-04-22 17:44:39 --> Helper loaded: lang_helper
INFO - 2023-04-22 17:44:39 --> Helper loaded: security_helper
INFO - 2023-04-22 17:44:39 --> Helper loaded: cookie_helper
INFO - 2023-04-22 17:44:39 --> Database Driver Class Initialized
INFO - 2023-04-22 17:44:39 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-22 17:44:39 --> Parser Class Initialized
INFO - 2023-04-22 17:44:39 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-22 17:44:39 --> Pagination Class Initialized
INFO - 2023-04-22 17:44:39 --> Form Validation Class Initialized
INFO - 2023-04-22 17:44:39 --> Controller Class Initialized
INFO - 2023-04-22 17:44:39 --> Model Class Initialized
DEBUG - 2023-04-22 17:44:39 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-22 17:44:39 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2023-04-22 17:44:39 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-04-22 17:44:39 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-04-22 17:44:39 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-04-22 17:44:39 --> Model Class Initialized
INFO - 2023-04-22 17:44:39 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-04-22 17:44:39 --> Final output sent to browser
DEBUG - 2023-04-22 17:44:39 --> Total execution time: 0.0307
ERROR - 2023-04-22 17:45:05 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-22 17:45:05 --> Config Class Initialized
INFO - 2023-04-22 17:45:05 --> Hooks Class Initialized
DEBUG - 2023-04-22 17:45:05 --> UTF-8 Support Enabled
INFO - 2023-04-22 17:45:05 --> Utf8 Class Initialized
INFO - 2023-04-22 17:45:05 --> URI Class Initialized
INFO - 2023-04-22 17:45:05 --> Router Class Initialized
INFO - 2023-04-22 17:45:05 --> Output Class Initialized
INFO - 2023-04-22 17:45:05 --> Security Class Initialized
DEBUG - 2023-04-22 17:45:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-22 17:45:05 --> Input Class Initialized
INFO - 2023-04-22 17:45:05 --> Language Class Initialized
INFO - 2023-04-22 17:45:05 --> Loader Class Initialized
INFO - 2023-04-22 17:45:05 --> Helper loaded: url_helper
INFO - 2023-04-22 17:45:05 --> Helper loaded: file_helper
INFO - 2023-04-22 17:45:05 --> Helper loaded: html_helper
INFO - 2023-04-22 17:45:05 --> Helper loaded: text_helper
INFO - 2023-04-22 17:45:05 --> Helper loaded: form_helper
INFO - 2023-04-22 17:45:05 --> Helper loaded: lang_helper
INFO - 2023-04-22 17:45:05 --> Helper loaded: security_helper
INFO - 2023-04-22 17:45:05 --> Helper loaded: cookie_helper
INFO - 2023-04-22 17:45:05 --> Database Driver Class Initialized
INFO - 2023-04-22 17:45:05 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-22 17:45:05 --> Parser Class Initialized
INFO - 2023-04-22 17:45:05 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-22 17:45:05 --> Pagination Class Initialized
INFO - 2023-04-22 17:45:05 --> Form Validation Class Initialized
INFO - 2023-04-22 17:45:05 --> Controller Class Initialized
INFO - 2023-04-22 17:45:05 --> Model Class Initialized
DEBUG - 2023-04-22 17:45:05 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-22 17:45:05 --> Model Class Initialized
INFO - 2023-04-22 17:45:05 --> Final output sent to browser
DEBUG - 2023-04-22 17:45:05 --> Total execution time: 0.0202
ERROR - 2023-04-22 17:45:06 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-22 17:45:06 --> Config Class Initialized
INFO - 2023-04-22 17:45:06 --> Hooks Class Initialized
DEBUG - 2023-04-22 17:45:06 --> UTF-8 Support Enabled
INFO - 2023-04-22 17:45:06 --> Utf8 Class Initialized
INFO - 2023-04-22 17:45:06 --> URI Class Initialized
INFO - 2023-04-22 17:45:06 --> Router Class Initialized
INFO - 2023-04-22 17:45:06 --> Output Class Initialized
INFO - 2023-04-22 17:45:06 --> Security Class Initialized
DEBUG - 2023-04-22 17:45:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-22 17:45:06 --> Input Class Initialized
INFO - 2023-04-22 17:45:06 --> Language Class Initialized
INFO - 2023-04-22 17:45:06 --> Loader Class Initialized
INFO - 2023-04-22 17:45:06 --> Helper loaded: url_helper
INFO - 2023-04-22 17:45:06 --> Helper loaded: file_helper
INFO - 2023-04-22 17:45:06 --> Helper loaded: html_helper
INFO - 2023-04-22 17:45:06 --> Helper loaded: text_helper
INFO - 2023-04-22 17:45:06 --> Helper loaded: form_helper
INFO - 2023-04-22 17:45:06 --> Helper loaded: lang_helper
INFO - 2023-04-22 17:45:06 --> Helper loaded: security_helper
INFO - 2023-04-22 17:45:06 --> Helper loaded: cookie_helper
INFO - 2023-04-22 17:45:06 --> Database Driver Class Initialized
INFO - 2023-04-22 17:45:06 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-22 17:45:06 --> Parser Class Initialized
INFO - 2023-04-22 17:45:06 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-22 17:45:06 --> Pagination Class Initialized
INFO - 2023-04-22 17:45:06 --> Form Validation Class Initialized
INFO - 2023-04-22 17:45:06 --> Controller Class Initialized
INFO - 2023-04-22 17:45:06 --> Model Class Initialized
DEBUG - 2023-04-22 17:45:06 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-22 17:45:06 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2023-04-22 17:45:06 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-04-22 17:45:06 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-04-22 17:45:06 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-04-22 17:45:06 --> Model Class Initialized
INFO - 2023-04-22 17:45:06 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-04-22 17:45:06 --> Final output sent to browser
DEBUG - 2023-04-22 17:45:06 --> Total execution time: 0.0335
ERROR - 2023-04-22 17:45:38 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-22 17:45:38 --> Config Class Initialized
INFO - 2023-04-22 17:45:38 --> Hooks Class Initialized
DEBUG - 2023-04-22 17:45:38 --> UTF-8 Support Enabled
INFO - 2023-04-22 17:45:38 --> Utf8 Class Initialized
INFO - 2023-04-22 17:45:38 --> URI Class Initialized
INFO - 2023-04-22 17:45:38 --> Router Class Initialized
INFO - 2023-04-22 17:45:38 --> Output Class Initialized
INFO - 2023-04-22 17:45:38 --> Security Class Initialized
DEBUG - 2023-04-22 17:45:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-22 17:45:38 --> Input Class Initialized
INFO - 2023-04-22 17:45:38 --> Language Class Initialized
INFO - 2023-04-22 17:45:38 --> Loader Class Initialized
INFO - 2023-04-22 17:45:38 --> Helper loaded: url_helper
INFO - 2023-04-22 17:45:38 --> Helper loaded: file_helper
INFO - 2023-04-22 17:45:38 --> Helper loaded: html_helper
INFO - 2023-04-22 17:45:38 --> Helper loaded: text_helper
INFO - 2023-04-22 17:45:38 --> Helper loaded: form_helper
INFO - 2023-04-22 17:45:38 --> Helper loaded: lang_helper
INFO - 2023-04-22 17:45:38 --> Helper loaded: security_helper
INFO - 2023-04-22 17:45:38 --> Helper loaded: cookie_helper
INFO - 2023-04-22 17:45:38 --> Database Driver Class Initialized
INFO - 2023-04-22 17:45:38 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-22 17:45:38 --> Parser Class Initialized
INFO - 2023-04-22 17:45:38 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-22 17:45:38 --> Pagination Class Initialized
INFO - 2023-04-22 17:45:38 --> Form Validation Class Initialized
INFO - 2023-04-22 17:45:38 --> Controller Class Initialized
INFO - 2023-04-22 17:45:38 --> Model Class Initialized
DEBUG - 2023-04-22 17:45:38 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-22 17:45:38 --> Model Class Initialized
INFO - 2023-04-22 17:45:38 --> Final output sent to browser
DEBUG - 2023-04-22 17:45:38 --> Total execution time: 0.0200
ERROR - 2023-04-22 17:45:39 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-22 17:45:39 --> Config Class Initialized
INFO - 2023-04-22 17:45:39 --> Hooks Class Initialized
DEBUG - 2023-04-22 17:45:39 --> UTF-8 Support Enabled
INFO - 2023-04-22 17:45:39 --> Utf8 Class Initialized
INFO - 2023-04-22 17:45:39 --> URI Class Initialized
DEBUG - 2023-04-22 17:45:39 --> No URI present. Default controller set.
INFO - 2023-04-22 17:45:39 --> Router Class Initialized
INFO - 2023-04-22 17:45:39 --> Output Class Initialized
INFO - 2023-04-22 17:45:39 --> Security Class Initialized
DEBUG - 2023-04-22 17:45:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-22 17:45:39 --> Input Class Initialized
INFO - 2023-04-22 17:45:39 --> Language Class Initialized
INFO - 2023-04-22 17:45:39 --> Loader Class Initialized
INFO - 2023-04-22 17:45:39 --> Helper loaded: url_helper
INFO - 2023-04-22 17:45:39 --> Helper loaded: file_helper
INFO - 2023-04-22 17:45:39 --> Helper loaded: html_helper
INFO - 2023-04-22 17:45:39 --> Helper loaded: text_helper
INFO - 2023-04-22 17:45:39 --> Helper loaded: form_helper
INFO - 2023-04-22 17:45:39 --> Helper loaded: lang_helper
INFO - 2023-04-22 17:45:39 --> Helper loaded: security_helper
INFO - 2023-04-22 17:45:39 --> Helper loaded: cookie_helper
INFO - 2023-04-22 17:45:39 --> Database Driver Class Initialized
INFO - 2023-04-22 17:45:39 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-22 17:45:39 --> Parser Class Initialized
INFO - 2023-04-22 17:45:39 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-22 17:45:39 --> Pagination Class Initialized
INFO - 2023-04-22 17:45:39 --> Form Validation Class Initialized
INFO - 2023-04-22 17:45:39 --> Controller Class Initialized
INFO - 2023-04-22 17:45:39 --> Model Class Initialized
DEBUG - 2023-04-22 17:45:39 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-22 17:45:39 --> Model Class Initialized
DEBUG - 2023-04-22 17:45:39 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-22 17:45:39 --> Model Class Initialized
INFO - 2023-04-22 17:45:39 --> Model Class Initialized
INFO - 2023-04-22 17:45:39 --> Model Class Initialized
INFO - 2023-04-22 17:45:39 --> Model Class Initialized
DEBUG - 2023-04-22 17:45:39 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-04-22 17:45:39 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-22 17:45:39 --> Model Class Initialized
INFO - 2023-04-22 17:45:39 --> Model Class Initialized
INFO - 2023-04-22 17:45:39 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-04-22 17:45:39 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-04-22 17:45:39 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-04-22 17:45:39 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-04-22 17:45:39 --> Model Class Initialized
INFO - 2023-04-22 17:45:39 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-04-22 17:45:39 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-04-22 17:45:39 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-04-22 17:45:39 --> Final output sent to browser
DEBUG - 2023-04-22 17:45:39 --> Total execution time: 0.0761
ERROR - 2023-04-22 17:45:45 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-22 17:45:45 --> Config Class Initialized
INFO - 2023-04-22 17:45:45 --> Hooks Class Initialized
DEBUG - 2023-04-22 17:45:45 --> UTF-8 Support Enabled
INFO - 2023-04-22 17:45:45 --> Utf8 Class Initialized
INFO - 2023-04-22 17:45:45 --> URI Class Initialized
INFO - 2023-04-22 17:45:45 --> Router Class Initialized
INFO - 2023-04-22 17:45:45 --> Output Class Initialized
INFO - 2023-04-22 17:45:45 --> Security Class Initialized
DEBUG - 2023-04-22 17:45:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-22 17:45:45 --> Input Class Initialized
INFO - 2023-04-22 17:45:45 --> Language Class Initialized
INFO - 2023-04-22 17:45:45 --> Loader Class Initialized
INFO - 2023-04-22 17:45:45 --> Helper loaded: url_helper
INFO - 2023-04-22 17:45:45 --> Helper loaded: file_helper
INFO - 2023-04-22 17:45:45 --> Helper loaded: html_helper
INFO - 2023-04-22 17:45:45 --> Helper loaded: text_helper
INFO - 2023-04-22 17:45:45 --> Helper loaded: form_helper
INFO - 2023-04-22 17:45:45 --> Helper loaded: lang_helper
INFO - 2023-04-22 17:45:45 --> Helper loaded: security_helper
INFO - 2023-04-22 17:45:45 --> Helper loaded: cookie_helper
INFO - 2023-04-22 17:45:45 --> Database Driver Class Initialized
INFO - 2023-04-22 17:45:45 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-22 17:45:45 --> Parser Class Initialized
INFO - 2023-04-22 17:45:45 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-22 17:45:45 --> Pagination Class Initialized
INFO - 2023-04-22 17:45:45 --> Form Validation Class Initialized
INFO - 2023-04-22 17:45:45 --> Controller Class Initialized
INFO - 2023-04-22 17:45:45 --> Model Class Initialized
DEBUG - 2023-04-22 17:45:45 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-04-22 17:45:45 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-22 17:45:45 --> Model Class Initialized
INFO - 2023-04-22 17:45:45 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/stockrequest/inventory.php
DEBUG - 2023-04-22 17:45:45 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-04-22 17:45:45 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-04-22 17:45:45 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-04-22 17:45:45 --> Model Class Initialized
INFO - 2023-04-22 17:45:45 --> Model Class Initialized
INFO - 2023-04-22 17:45:45 --> Model Class Initialized
INFO - 2023-04-22 17:45:45 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-04-22 17:45:45 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-04-22 17:45:45 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-04-22 17:45:45 --> Final output sent to browser
DEBUG - 2023-04-22 17:45:45 --> Total execution time: 0.0617
ERROR - 2023-04-22 17:45:46 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-22 17:45:46 --> Config Class Initialized
INFO - 2023-04-22 17:45:46 --> Hooks Class Initialized
DEBUG - 2023-04-22 17:45:46 --> UTF-8 Support Enabled
INFO - 2023-04-22 17:45:46 --> Utf8 Class Initialized
INFO - 2023-04-22 17:45:46 --> URI Class Initialized
INFO - 2023-04-22 17:45:46 --> Router Class Initialized
INFO - 2023-04-22 17:45:46 --> Output Class Initialized
INFO - 2023-04-22 17:45:46 --> Security Class Initialized
DEBUG - 2023-04-22 17:45:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-22 17:45:46 --> Input Class Initialized
INFO - 2023-04-22 17:45:46 --> Language Class Initialized
INFO - 2023-04-22 17:45:46 --> Loader Class Initialized
INFO - 2023-04-22 17:45:46 --> Helper loaded: url_helper
INFO - 2023-04-22 17:45:46 --> Helper loaded: file_helper
INFO - 2023-04-22 17:45:46 --> Helper loaded: html_helper
INFO - 2023-04-22 17:45:46 --> Helper loaded: text_helper
INFO - 2023-04-22 17:45:46 --> Helper loaded: form_helper
INFO - 2023-04-22 17:45:46 --> Helper loaded: lang_helper
INFO - 2023-04-22 17:45:46 --> Helper loaded: security_helper
INFO - 2023-04-22 17:45:46 --> Helper loaded: cookie_helper
INFO - 2023-04-22 17:45:46 --> Database Driver Class Initialized
INFO - 2023-04-22 17:45:46 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-22 17:45:46 --> Parser Class Initialized
INFO - 2023-04-22 17:45:46 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-22 17:45:46 --> Pagination Class Initialized
INFO - 2023-04-22 17:45:46 --> Form Validation Class Initialized
INFO - 2023-04-22 17:45:46 --> Controller Class Initialized
INFO - 2023-04-22 17:45:46 --> Model Class Initialized
DEBUG - 2023-04-22 17:45:46 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-04-22 17:45:46 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-22 17:45:46 --> Model Class Initialized
INFO - 2023-04-22 17:45:46 --> Final output sent to browser
DEBUG - 2023-04-22 17:45:46 --> Total execution time: 0.0192
ERROR - 2023-04-22 17:45:57 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-22 17:45:57 --> Config Class Initialized
INFO - 2023-04-22 17:45:57 --> Hooks Class Initialized
DEBUG - 2023-04-22 17:45:57 --> UTF-8 Support Enabled
INFO - 2023-04-22 17:45:57 --> Utf8 Class Initialized
INFO - 2023-04-22 17:45:57 --> URI Class Initialized
INFO - 2023-04-22 17:45:57 --> Router Class Initialized
INFO - 2023-04-22 17:45:57 --> Output Class Initialized
INFO - 2023-04-22 17:45:57 --> Security Class Initialized
DEBUG - 2023-04-22 17:45:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-22 17:45:57 --> Input Class Initialized
INFO - 2023-04-22 17:45:57 --> Language Class Initialized
INFO - 2023-04-22 17:45:57 --> Loader Class Initialized
INFO - 2023-04-22 17:45:57 --> Helper loaded: url_helper
INFO - 2023-04-22 17:45:57 --> Helper loaded: file_helper
INFO - 2023-04-22 17:45:57 --> Helper loaded: html_helper
INFO - 2023-04-22 17:45:57 --> Helper loaded: text_helper
INFO - 2023-04-22 17:45:57 --> Helper loaded: form_helper
INFO - 2023-04-22 17:45:57 --> Helper loaded: lang_helper
INFO - 2023-04-22 17:45:57 --> Helper loaded: security_helper
INFO - 2023-04-22 17:45:57 --> Helper loaded: cookie_helper
INFO - 2023-04-22 17:45:57 --> Database Driver Class Initialized
INFO - 2023-04-22 17:45:57 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-22 17:45:57 --> Parser Class Initialized
INFO - 2023-04-22 17:45:57 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-22 17:45:57 --> Pagination Class Initialized
INFO - 2023-04-22 17:45:57 --> Form Validation Class Initialized
INFO - 2023-04-22 17:45:57 --> Controller Class Initialized
INFO - 2023-04-22 17:45:57 --> Model Class Initialized
DEBUG - 2023-04-22 17:45:57 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-04-22 17:45:57 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-22 17:45:57 --> Model Class Initialized
INFO - 2023-04-22 17:45:57 --> Final output sent to browser
DEBUG - 2023-04-22 17:45:57 --> Total execution time: 0.0191
ERROR - 2023-04-22 17:46:17 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-22 17:46:17 --> Config Class Initialized
INFO - 2023-04-22 17:46:17 --> Hooks Class Initialized
DEBUG - 2023-04-22 17:46:17 --> UTF-8 Support Enabled
INFO - 2023-04-22 17:46:17 --> Utf8 Class Initialized
INFO - 2023-04-22 17:46:17 --> URI Class Initialized
INFO - 2023-04-22 17:46:17 --> Router Class Initialized
INFO - 2023-04-22 17:46:17 --> Output Class Initialized
INFO - 2023-04-22 17:46:17 --> Security Class Initialized
DEBUG - 2023-04-22 17:46:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-22 17:46:17 --> Input Class Initialized
INFO - 2023-04-22 17:46:17 --> Language Class Initialized
INFO - 2023-04-22 17:46:17 --> Loader Class Initialized
INFO - 2023-04-22 17:46:17 --> Helper loaded: url_helper
INFO - 2023-04-22 17:46:17 --> Helper loaded: file_helper
INFO - 2023-04-22 17:46:17 --> Helper loaded: html_helper
INFO - 2023-04-22 17:46:17 --> Helper loaded: text_helper
INFO - 2023-04-22 17:46:17 --> Helper loaded: form_helper
INFO - 2023-04-22 17:46:17 --> Helper loaded: lang_helper
INFO - 2023-04-22 17:46:17 --> Helper loaded: security_helper
INFO - 2023-04-22 17:46:17 --> Helper loaded: cookie_helper
INFO - 2023-04-22 17:46:17 --> Database Driver Class Initialized
INFO - 2023-04-22 17:46:17 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-22 17:46:17 --> Parser Class Initialized
INFO - 2023-04-22 17:46:17 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-22 17:46:17 --> Pagination Class Initialized
INFO - 2023-04-22 17:46:17 --> Form Validation Class Initialized
INFO - 2023-04-22 17:46:17 --> Controller Class Initialized
INFO - 2023-04-22 17:46:17 --> Model Class Initialized
DEBUG - 2023-04-22 17:46:17 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-04-22 17:46:17 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-22 17:46:17 --> Model Class Initialized
DEBUG - 2023-04-22 17:46:17 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-22 17:46:17 --> Model Class Initialized
INFO - 2023-04-22 17:46:17 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/add_invoice_form.php
DEBUG - 2023-04-22 17:46:17 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-04-22 17:46:17 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-04-22 17:46:17 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-04-22 17:46:17 --> Model Class Initialized
INFO - 2023-04-22 17:46:17 --> Model Class Initialized
INFO - 2023-04-22 17:46:17 --> Model Class Initialized
INFO - 2023-04-22 17:46:17 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-04-22 17:46:17 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-04-22 17:46:17 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-04-22 17:46:17 --> Final output sent to browser
DEBUG - 2023-04-22 17:46:17 --> Total execution time: 0.0920
ERROR - 2023-04-22 17:46:27 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-22 17:46:27 --> Config Class Initialized
INFO - 2023-04-22 17:46:27 --> Hooks Class Initialized
DEBUG - 2023-04-22 17:46:27 --> UTF-8 Support Enabled
INFO - 2023-04-22 17:46:27 --> Utf8 Class Initialized
INFO - 2023-04-22 17:46:27 --> URI Class Initialized
INFO - 2023-04-22 17:46:27 --> Router Class Initialized
INFO - 2023-04-22 17:46:27 --> Output Class Initialized
INFO - 2023-04-22 17:46:27 --> Security Class Initialized
DEBUG - 2023-04-22 17:46:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-22 17:46:27 --> Input Class Initialized
INFO - 2023-04-22 17:46:27 --> Language Class Initialized
INFO - 2023-04-22 17:46:27 --> Loader Class Initialized
INFO - 2023-04-22 17:46:27 --> Helper loaded: url_helper
INFO - 2023-04-22 17:46:27 --> Helper loaded: file_helper
INFO - 2023-04-22 17:46:27 --> Helper loaded: html_helper
INFO - 2023-04-22 17:46:27 --> Helper loaded: text_helper
INFO - 2023-04-22 17:46:27 --> Helper loaded: form_helper
INFO - 2023-04-22 17:46:27 --> Helper loaded: lang_helper
INFO - 2023-04-22 17:46:27 --> Helper loaded: security_helper
INFO - 2023-04-22 17:46:27 --> Helper loaded: cookie_helper
INFO - 2023-04-22 17:46:27 --> Database Driver Class Initialized
INFO - 2023-04-22 17:46:27 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-22 17:46:27 --> Parser Class Initialized
INFO - 2023-04-22 17:46:27 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-22 17:46:27 --> Pagination Class Initialized
INFO - 2023-04-22 17:46:27 --> Form Validation Class Initialized
INFO - 2023-04-22 17:46:27 --> Controller Class Initialized
INFO - 2023-04-22 17:46:27 --> Model Class Initialized
DEBUG - 2023-04-22 17:46:27 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-22 17:46:27 --> Final output sent to browser
DEBUG - 2023-04-22 17:46:27 --> Total execution time: 0.0166
ERROR - 2023-04-22 17:48:04 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-22 17:48:04 --> Config Class Initialized
INFO - 2023-04-22 17:48:04 --> Hooks Class Initialized
DEBUG - 2023-04-22 17:48:04 --> UTF-8 Support Enabled
INFO - 2023-04-22 17:48:04 --> Utf8 Class Initialized
INFO - 2023-04-22 17:48:04 --> URI Class Initialized
INFO - 2023-04-22 17:48:04 --> Router Class Initialized
INFO - 2023-04-22 17:48:04 --> Output Class Initialized
INFO - 2023-04-22 17:48:04 --> Security Class Initialized
DEBUG - 2023-04-22 17:48:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-22 17:48:04 --> Input Class Initialized
INFO - 2023-04-22 17:48:04 --> Language Class Initialized
INFO - 2023-04-22 17:48:04 --> Loader Class Initialized
INFO - 2023-04-22 17:48:04 --> Helper loaded: url_helper
INFO - 2023-04-22 17:48:04 --> Helper loaded: file_helper
INFO - 2023-04-22 17:48:04 --> Helper loaded: html_helper
INFO - 2023-04-22 17:48:04 --> Helper loaded: text_helper
INFO - 2023-04-22 17:48:04 --> Helper loaded: form_helper
INFO - 2023-04-22 17:48:04 --> Helper loaded: lang_helper
INFO - 2023-04-22 17:48:04 --> Helper loaded: security_helper
INFO - 2023-04-22 17:48:04 --> Helper loaded: cookie_helper
INFO - 2023-04-22 17:48:04 --> Database Driver Class Initialized
INFO - 2023-04-22 17:48:04 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-22 17:48:04 --> Parser Class Initialized
INFO - 2023-04-22 17:48:04 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-22 17:48:04 --> Pagination Class Initialized
INFO - 2023-04-22 17:48:04 --> Form Validation Class Initialized
INFO - 2023-04-22 17:48:04 --> Controller Class Initialized
INFO - 2023-04-22 17:48:04 --> Model Class Initialized
DEBUG - 2023-04-22 17:48:04 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-04-22 17:48:04 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-22 17:48:04 --> Model Class Initialized
DEBUG - 2023-04-22 17:48:04 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-22 17:48:04 --> Model Class Initialized
INFO - 2023-04-22 17:48:04 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice.php
DEBUG - 2023-04-22 17:48:04 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-04-22 17:48:04 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-04-22 17:48:04 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-04-22 17:48:04 --> Model Class Initialized
INFO - 2023-04-22 17:48:04 --> Model Class Initialized
INFO - 2023-04-22 17:48:04 --> Model Class Initialized
INFO - 2023-04-22 17:48:04 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-04-22 17:48:04 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-04-22 17:48:04 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-04-22 17:48:04 --> Final output sent to browser
DEBUG - 2023-04-22 17:48:04 --> Total execution time: 0.0803
ERROR - 2023-04-22 17:48:05 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-22 17:48:05 --> Config Class Initialized
INFO - 2023-04-22 17:48:05 --> Hooks Class Initialized
DEBUG - 2023-04-22 17:48:05 --> UTF-8 Support Enabled
INFO - 2023-04-22 17:48:05 --> Utf8 Class Initialized
INFO - 2023-04-22 17:48:05 --> URI Class Initialized
INFO - 2023-04-22 17:48:05 --> Router Class Initialized
INFO - 2023-04-22 17:48:05 --> Output Class Initialized
INFO - 2023-04-22 17:48:05 --> Security Class Initialized
DEBUG - 2023-04-22 17:48:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-22 17:48:05 --> Input Class Initialized
INFO - 2023-04-22 17:48:05 --> Language Class Initialized
INFO - 2023-04-22 17:48:05 --> Loader Class Initialized
INFO - 2023-04-22 17:48:05 --> Helper loaded: url_helper
INFO - 2023-04-22 17:48:05 --> Helper loaded: file_helper
INFO - 2023-04-22 17:48:05 --> Helper loaded: html_helper
INFO - 2023-04-22 17:48:05 --> Helper loaded: text_helper
INFO - 2023-04-22 17:48:05 --> Helper loaded: form_helper
INFO - 2023-04-22 17:48:05 --> Helper loaded: lang_helper
INFO - 2023-04-22 17:48:05 --> Helper loaded: security_helper
INFO - 2023-04-22 17:48:05 --> Helper loaded: cookie_helper
INFO - 2023-04-22 17:48:05 --> Database Driver Class Initialized
INFO - 2023-04-22 17:48:05 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-22 17:48:05 --> Parser Class Initialized
INFO - 2023-04-22 17:48:05 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-22 17:48:05 --> Pagination Class Initialized
INFO - 2023-04-22 17:48:05 --> Form Validation Class Initialized
INFO - 2023-04-22 17:48:05 --> Controller Class Initialized
INFO - 2023-04-22 17:48:05 --> Model Class Initialized
DEBUG - 2023-04-22 17:48:05 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-04-22 17:48:05 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-22 17:48:05 --> Model Class Initialized
DEBUG - 2023-04-22 17:48:05 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-22 17:48:05 --> Model Class Initialized
INFO - 2023-04-22 17:48:05 --> Final output sent to browser
DEBUG - 2023-04-22 17:48:05 --> Total execution time: 0.0427
ERROR - 2023-04-22 17:48:10 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-22 17:48:10 --> Config Class Initialized
INFO - 2023-04-22 17:48:10 --> Hooks Class Initialized
DEBUG - 2023-04-22 17:48:10 --> UTF-8 Support Enabled
INFO - 2023-04-22 17:48:10 --> Utf8 Class Initialized
INFO - 2023-04-22 17:48:10 --> URI Class Initialized
DEBUG - 2023-04-22 17:48:10 --> No URI present. Default controller set.
INFO - 2023-04-22 17:48:10 --> Router Class Initialized
INFO - 2023-04-22 17:48:10 --> Output Class Initialized
INFO - 2023-04-22 17:48:10 --> Security Class Initialized
DEBUG - 2023-04-22 17:48:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-22 17:48:10 --> Input Class Initialized
INFO - 2023-04-22 17:48:10 --> Language Class Initialized
INFO - 2023-04-22 17:48:10 --> Loader Class Initialized
INFO - 2023-04-22 17:48:10 --> Helper loaded: url_helper
INFO - 2023-04-22 17:48:10 --> Helper loaded: file_helper
INFO - 2023-04-22 17:48:10 --> Helper loaded: html_helper
INFO - 2023-04-22 17:48:10 --> Helper loaded: text_helper
INFO - 2023-04-22 17:48:10 --> Helper loaded: form_helper
INFO - 2023-04-22 17:48:10 --> Helper loaded: lang_helper
INFO - 2023-04-22 17:48:10 --> Helper loaded: security_helper
INFO - 2023-04-22 17:48:10 --> Helper loaded: cookie_helper
INFO - 2023-04-22 17:48:10 --> Database Driver Class Initialized
INFO - 2023-04-22 17:48:10 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-22 17:48:10 --> Parser Class Initialized
INFO - 2023-04-22 17:48:10 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-22 17:48:10 --> Pagination Class Initialized
INFO - 2023-04-22 17:48:10 --> Form Validation Class Initialized
INFO - 2023-04-22 17:48:10 --> Controller Class Initialized
INFO - 2023-04-22 17:48:10 --> Model Class Initialized
DEBUG - 2023-04-22 17:48:10 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-22 17:48:10 --> Model Class Initialized
DEBUG - 2023-04-22 17:48:10 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-22 17:48:10 --> Model Class Initialized
INFO - 2023-04-22 17:48:10 --> Model Class Initialized
INFO - 2023-04-22 17:48:10 --> Model Class Initialized
INFO - 2023-04-22 17:48:10 --> Model Class Initialized
DEBUG - 2023-04-22 17:48:10 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-04-22 17:48:10 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-22 17:48:10 --> Model Class Initialized
INFO - 2023-04-22 17:48:10 --> Model Class Initialized
INFO - 2023-04-22 17:48:10 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-04-22 17:48:10 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-04-22 17:48:10 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-04-22 17:48:10 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-04-22 17:48:10 --> Model Class Initialized
INFO - 2023-04-22 17:48:11 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-04-22 17:48:11 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-04-22 17:48:11 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-04-22 17:48:11 --> Final output sent to browser
DEBUG - 2023-04-22 17:48:11 --> Total execution time: 0.0856
ERROR - 2023-04-22 17:50:28 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-22 17:50:28 --> Config Class Initialized
INFO - 2023-04-22 17:50:28 --> Hooks Class Initialized
DEBUG - 2023-04-22 17:50:28 --> UTF-8 Support Enabled
INFO - 2023-04-22 17:50:28 --> Utf8 Class Initialized
INFO - 2023-04-22 17:50:28 --> URI Class Initialized
INFO - 2023-04-22 17:50:28 --> Router Class Initialized
INFO - 2023-04-22 17:50:28 --> Output Class Initialized
INFO - 2023-04-22 17:50:28 --> Security Class Initialized
DEBUG - 2023-04-22 17:50:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-22 17:50:28 --> Input Class Initialized
INFO - 2023-04-22 17:50:28 --> Language Class Initialized
INFO - 2023-04-22 17:50:28 --> Loader Class Initialized
INFO - 2023-04-22 17:50:28 --> Helper loaded: url_helper
INFO - 2023-04-22 17:50:28 --> Helper loaded: file_helper
INFO - 2023-04-22 17:50:28 --> Helper loaded: html_helper
INFO - 2023-04-22 17:50:28 --> Helper loaded: text_helper
INFO - 2023-04-22 17:50:28 --> Helper loaded: form_helper
INFO - 2023-04-22 17:50:28 --> Helper loaded: lang_helper
INFO - 2023-04-22 17:50:28 --> Helper loaded: security_helper
INFO - 2023-04-22 17:50:28 --> Helper loaded: cookie_helper
INFO - 2023-04-22 17:50:28 --> Database Driver Class Initialized
INFO - 2023-04-22 17:50:28 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-22 17:50:28 --> Parser Class Initialized
INFO - 2023-04-22 17:50:28 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-22 17:50:28 --> Pagination Class Initialized
INFO - 2023-04-22 17:50:28 --> Form Validation Class Initialized
INFO - 2023-04-22 17:50:28 --> Controller Class Initialized
INFO - 2023-04-22 17:50:28 --> Model Class Initialized
DEBUG - 2023-04-22 17:50:28 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-04-22 17:50:28 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-22 17:50:28 --> Model Class Initialized
DEBUG - 2023-04-22 17:50:28 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-22 17:50:28 --> Model Class Initialized
INFO - 2023-04-22 17:50:28 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice.php
DEBUG - 2023-04-22 17:50:28 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-04-22 17:50:28 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-04-22 17:50:28 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-04-22 17:50:28 --> Model Class Initialized
INFO - 2023-04-22 17:50:28 --> Model Class Initialized
INFO - 2023-04-22 17:50:28 --> Model Class Initialized
INFO - 2023-04-22 17:50:28 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-04-22 17:50:28 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-04-22 17:50:28 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-04-22 17:50:28 --> Final output sent to browser
DEBUG - 2023-04-22 17:50:28 --> Total execution time: 0.1492
ERROR - 2023-04-22 17:50:29 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-22 17:50:29 --> Config Class Initialized
INFO - 2023-04-22 17:50:29 --> Hooks Class Initialized
DEBUG - 2023-04-22 17:50:29 --> UTF-8 Support Enabled
INFO - 2023-04-22 17:50:29 --> Utf8 Class Initialized
INFO - 2023-04-22 17:50:29 --> URI Class Initialized
INFO - 2023-04-22 17:50:29 --> Router Class Initialized
INFO - 2023-04-22 17:50:29 --> Output Class Initialized
INFO - 2023-04-22 17:50:29 --> Security Class Initialized
DEBUG - 2023-04-22 17:50:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-22 17:50:29 --> Input Class Initialized
INFO - 2023-04-22 17:50:29 --> Language Class Initialized
INFO - 2023-04-22 17:50:29 --> Loader Class Initialized
INFO - 2023-04-22 17:50:29 --> Helper loaded: url_helper
INFO - 2023-04-22 17:50:29 --> Helper loaded: file_helper
INFO - 2023-04-22 17:50:29 --> Helper loaded: html_helper
INFO - 2023-04-22 17:50:29 --> Helper loaded: text_helper
INFO - 2023-04-22 17:50:29 --> Helper loaded: form_helper
INFO - 2023-04-22 17:50:29 --> Helper loaded: lang_helper
INFO - 2023-04-22 17:50:29 --> Helper loaded: security_helper
INFO - 2023-04-22 17:50:29 --> Helper loaded: cookie_helper
INFO - 2023-04-22 17:50:29 --> Database Driver Class Initialized
INFO - 2023-04-22 17:50:29 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-22 17:50:29 --> Parser Class Initialized
INFO - 2023-04-22 17:50:29 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-22 17:50:29 --> Pagination Class Initialized
INFO - 2023-04-22 17:50:29 --> Form Validation Class Initialized
INFO - 2023-04-22 17:50:29 --> Controller Class Initialized
INFO - 2023-04-22 17:50:29 --> Model Class Initialized
DEBUG - 2023-04-22 17:50:29 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-04-22 17:50:29 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-22 17:50:29 --> Model Class Initialized
DEBUG - 2023-04-22 17:50:29 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-22 17:50:29 --> Model Class Initialized
INFO - 2023-04-22 17:50:29 --> Final output sent to browser
DEBUG - 2023-04-22 17:50:29 --> Total execution time: 0.0403
ERROR - 2023-04-22 17:50:36 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-22 17:50:36 --> Config Class Initialized
INFO - 2023-04-22 17:50:36 --> Hooks Class Initialized
DEBUG - 2023-04-22 17:50:36 --> UTF-8 Support Enabled
INFO - 2023-04-22 17:50:36 --> Utf8 Class Initialized
INFO - 2023-04-22 17:50:36 --> URI Class Initialized
INFO - 2023-04-22 17:50:36 --> Router Class Initialized
INFO - 2023-04-22 17:50:36 --> Output Class Initialized
INFO - 2023-04-22 17:50:36 --> Security Class Initialized
DEBUG - 2023-04-22 17:50:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-22 17:50:36 --> Input Class Initialized
INFO - 2023-04-22 17:50:36 --> Language Class Initialized
INFO - 2023-04-22 17:50:36 --> Loader Class Initialized
INFO - 2023-04-22 17:50:36 --> Helper loaded: url_helper
INFO - 2023-04-22 17:50:36 --> Helper loaded: file_helper
INFO - 2023-04-22 17:50:36 --> Helper loaded: html_helper
INFO - 2023-04-22 17:50:36 --> Helper loaded: text_helper
INFO - 2023-04-22 17:50:36 --> Helper loaded: form_helper
INFO - 2023-04-22 17:50:36 --> Helper loaded: lang_helper
INFO - 2023-04-22 17:50:36 --> Helper loaded: security_helper
INFO - 2023-04-22 17:50:36 --> Helper loaded: cookie_helper
INFO - 2023-04-22 17:50:36 --> Database Driver Class Initialized
INFO - 2023-04-22 17:50:36 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-22 17:50:36 --> Parser Class Initialized
INFO - 2023-04-22 17:50:36 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-22 17:50:36 --> Pagination Class Initialized
INFO - 2023-04-22 17:50:36 --> Form Validation Class Initialized
INFO - 2023-04-22 17:50:36 --> Controller Class Initialized
INFO - 2023-04-22 17:50:36 --> Model Class Initialized
DEBUG - 2023-04-22 17:50:36 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-04-22 17:50:36 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-22 17:50:36 --> Model Class Initialized
DEBUG - 2023-04-22 17:50:36 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-22 17:50:36 --> Model Class Initialized
INFO - 2023-04-22 17:50:37 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/invoice/invoice.php
DEBUG - 2023-04-22 17:50:37 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-04-22 17:50:37 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-04-22 17:50:37 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-04-22 17:50:37 --> Model Class Initialized
INFO - 2023-04-22 17:50:37 --> Model Class Initialized
INFO - 2023-04-22 17:50:37 --> Model Class Initialized
INFO - 2023-04-22 17:50:37 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-04-22 17:50:37 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-04-22 17:50:37 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-04-22 17:50:37 --> Final output sent to browser
DEBUG - 2023-04-22 17:50:37 --> Total execution time: 0.0777
ERROR - 2023-04-22 17:50:37 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-22 17:50:37 --> Config Class Initialized
INFO - 2023-04-22 17:50:37 --> Hooks Class Initialized
DEBUG - 2023-04-22 17:50:37 --> UTF-8 Support Enabled
INFO - 2023-04-22 17:50:37 --> Utf8 Class Initialized
INFO - 2023-04-22 17:50:37 --> URI Class Initialized
INFO - 2023-04-22 17:50:37 --> Router Class Initialized
INFO - 2023-04-22 17:50:37 --> Output Class Initialized
INFO - 2023-04-22 17:50:37 --> Security Class Initialized
DEBUG - 2023-04-22 17:50:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-22 17:50:37 --> Input Class Initialized
INFO - 2023-04-22 17:50:37 --> Language Class Initialized
INFO - 2023-04-22 17:50:37 --> Loader Class Initialized
INFO - 2023-04-22 17:50:37 --> Helper loaded: url_helper
INFO - 2023-04-22 17:50:37 --> Helper loaded: file_helper
INFO - 2023-04-22 17:50:37 --> Helper loaded: html_helper
INFO - 2023-04-22 17:50:37 --> Helper loaded: text_helper
INFO - 2023-04-22 17:50:37 --> Helper loaded: form_helper
INFO - 2023-04-22 17:50:37 --> Helper loaded: lang_helper
INFO - 2023-04-22 17:50:37 --> Helper loaded: security_helper
INFO - 2023-04-22 17:50:37 --> Helper loaded: cookie_helper
INFO - 2023-04-22 17:50:37 --> Database Driver Class Initialized
INFO - 2023-04-22 17:50:37 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-22 17:50:37 --> Parser Class Initialized
INFO - 2023-04-22 17:50:37 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-22 17:50:37 --> Pagination Class Initialized
INFO - 2023-04-22 17:50:37 --> Form Validation Class Initialized
INFO - 2023-04-22 17:50:37 --> Controller Class Initialized
INFO - 2023-04-22 17:50:37 --> Model Class Initialized
DEBUG - 2023-04-22 17:50:37 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-04-22 17:50:37 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-22 17:50:37 --> Model Class Initialized
DEBUG - 2023-04-22 17:50:37 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-22 17:50:37 --> Model Class Initialized
INFO - 2023-04-22 17:50:37 --> Final output sent to browser
DEBUG - 2023-04-22 17:50:37 --> Total execution time: 0.0219
ERROR - 2023-04-22 17:50:51 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-22 17:50:51 --> Config Class Initialized
INFO - 2023-04-22 17:50:51 --> Hooks Class Initialized
DEBUG - 2023-04-22 17:50:51 --> UTF-8 Support Enabled
INFO - 2023-04-22 17:50:51 --> Utf8 Class Initialized
INFO - 2023-04-22 17:50:51 --> URI Class Initialized
INFO - 2023-04-22 17:50:51 --> Router Class Initialized
INFO - 2023-04-22 17:50:51 --> Output Class Initialized
INFO - 2023-04-22 17:50:51 --> Security Class Initialized
DEBUG - 2023-04-22 17:50:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-22 17:50:51 --> Input Class Initialized
INFO - 2023-04-22 17:50:51 --> Language Class Initialized
INFO - 2023-04-22 17:50:51 --> Loader Class Initialized
INFO - 2023-04-22 17:50:51 --> Helper loaded: url_helper
INFO - 2023-04-22 17:50:51 --> Helper loaded: file_helper
INFO - 2023-04-22 17:50:51 --> Helper loaded: html_helper
INFO - 2023-04-22 17:50:51 --> Helper loaded: text_helper
INFO - 2023-04-22 17:50:51 --> Helper loaded: form_helper
INFO - 2023-04-22 17:50:51 --> Helper loaded: lang_helper
INFO - 2023-04-22 17:50:51 --> Helper loaded: security_helper
INFO - 2023-04-22 17:50:51 --> Helper loaded: cookie_helper
INFO - 2023-04-22 17:50:51 --> Database Driver Class Initialized
INFO - 2023-04-22 17:50:51 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-22 17:50:51 --> Parser Class Initialized
INFO - 2023-04-22 17:50:51 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-22 17:50:51 --> Pagination Class Initialized
INFO - 2023-04-22 17:50:51 --> Form Validation Class Initialized
INFO - 2023-04-22 17:50:51 --> Controller Class Initialized
DEBUG - 2023-04-22 17:50:51 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-04-22 17:50:51 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-22 17:50:51 --> Model Class Initialized
DEBUG - 2023-04-22 17:50:51 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-22 17:50:51 --> Model Class Initialized
DEBUG - 2023-04-22 17:50:51 --> Lcustomer class already loaded. Second attempt ignored.
INFO - 2023-04-22 17:50:51 --> Model Class Initialized
INFO - 2023-04-22 17:50:51 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/customer/customer.php
DEBUG - 2023-04-22 17:50:51 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-04-22 17:50:51 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-04-22 17:50:51 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-04-22 17:50:51 --> Model Class Initialized
INFO - 2023-04-22 17:50:51 --> Model Class Initialized
INFO - 2023-04-22 17:50:51 --> Model Class Initialized
INFO - 2023-04-22 17:50:51 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-04-22 17:50:51 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-04-22 17:50:51 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-04-22 17:50:51 --> Final output sent to browser
DEBUG - 2023-04-22 17:50:51 --> Total execution time: 0.0726
ERROR - 2023-04-22 17:50:51 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-22 17:50:51 --> Config Class Initialized
INFO - 2023-04-22 17:50:51 --> Hooks Class Initialized
DEBUG - 2023-04-22 17:50:51 --> UTF-8 Support Enabled
INFO - 2023-04-22 17:50:51 --> Utf8 Class Initialized
INFO - 2023-04-22 17:50:51 --> URI Class Initialized
INFO - 2023-04-22 17:50:51 --> Router Class Initialized
INFO - 2023-04-22 17:50:51 --> Output Class Initialized
INFO - 2023-04-22 17:50:51 --> Security Class Initialized
DEBUG - 2023-04-22 17:50:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-22 17:50:51 --> Input Class Initialized
INFO - 2023-04-22 17:50:51 --> Language Class Initialized
INFO - 2023-04-22 17:50:51 --> Loader Class Initialized
INFO - 2023-04-22 17:50:51 --> Helper loaded: url_helper
INFO - 2023-04-22 17:50:51 --> Helper loaded: file_helper
INFO - 2023-04-22 17:50:51 --> Helper loaded: html_helper
INFO - 2023-04-22 17:50:51 --> Helper loaded: text_helper
INFO - 2023-04-22 17:50:51 --> Helper loaded: form_helper
INFO - 2023-04-22 17:50:51 --> Helper loaded: lang_helper
INFO - 2023-04-22 17:50:51 --> Helper loaded: security_helper
INFO - 2023-04-22 17:50:51 --> Helper loaded: cookie_helper
INFO - 2023-04-22 17:50:51 --> Database Driver Class Initialized
INFO - 2023-04-22 17:50:51 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-22 17:50:51 --> Parser Class Initialized
INFO - 2023-04-22 17:50:51 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-22 17:50:51 --> Pagination Class Initialized
INFO - 2023-04-22 17:50:51 --> Form Validation Class Initialized
INFO - 2023-04-22 17:50:51 --> Controller Class Initialized
DEBUG - 2023-04-22 17:50:51 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-04-22 17:50:51 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-22 17:50:51 --> Model Class Initialized
DEBUG - 2023-04-22 17:50:51 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-22 17:50:51 --> Model Class Initialized
INFO - 2023-04-22 17:50:51 --> Final output sent to browser
DEBUG - 2023-04-22 17:50:51 --> Total execution time: 0.0213
ERROR - 2023-04-22 17:50:56 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-22 17:50:56 --> Config Class Initialized
INFO - 2023-04-22 17:50:56 --> Hooks Class Initialized
DEBUG - 2023-04-22 17:50:56 --> UTF-8 Support Enabled
INFO - 2023-04-22 17:50:56 --> Utf8 Class Initialized
INFO - 2023-04-22 17:50:56 --> URI Class Initialized
INFO - 2023-04-22 17:50:56 --> Router Class Initialized
INFO - 2023-04-22 17:50:56 --> Output Class Initialized
INFO - 2023-04-22 17:50:56 --> Security Class Initialized
DEBUG - 2023-04-22 17:50:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-22 17:50:56 --> Input Class Initialized
INFO - 2023-04-22 17:50:56 --> Language Class Initialized
INFO - 2023-04-22 17:50:56 --> Loader Class Initialized
INFO - 2023-04-22 17:50:56 --> Helper loaded: url_helper
INFO - 2023-04-22 17:50:56 --> Helper loaded: file_helper
INFO - 2023-04-22 17:50:56 --> Helper loaded: html_helper
INFO - 2023-04-22 17:50:56 --> Helper loaded: text_helper
INFO - 2023-04-22 17:50:56 --> Helper loaded: form_helper
INFO - 2023-04-22 17:50:56 --> Helper loaded: lang_helper
INFO - 2023-04-22 17:50:56 --> Helper loaded: security_helper
INFO - 2023-04-22 17:50:56 --> Helper loaded: cookie_helper
INFO - 2023-04-22 17:50:56 --> Database Driver Class Initialized
INFO - 2023-04-22 17:50:56 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-22 17:50:56 --> Parser Class Initialized
INFO - 2023-04-22 17:50:56 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-22 17:50:56 --> Pagination Class Initialized
INFO - 2023-04-22 17:50:56 --> Form Validation Class Initialized
INFO - 2023-04-22 17:50:56 --> Controller Class Initialized
DEBUG - 2023-04-22 17:50:56 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-04-22 17:50:56 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-22 17:50:56 --> Model Class Initialized
DEBUG - 2023-04-22 17:50:56 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-22 17:50:56 --> Model Class Initialized
INFO - 2023-04-22 17:50:56 --> Final output sent to browser
DEBUG - 2023-04-22 17:50:56 --> Total execution time: 0.0261
