<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2023-12-10 04:15:24 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-12-10 04:15:24 --> Config Class Initialized
INFO - 2023-12-10 04:15:24 --> Hooks Class Initialized
DEBUG - 2023-12-10 04:15:24 --> UTF-8 Support Enabled
INFO - 2023-12-10 04:15:24 --> Utf8 Class Initialized
INFO - 2023-12-10 04:15:24 --> URI Class Initialized
INFO - 2023-12-10 04:15:24 --> Router Class Initialized
INFO - 2023-12-10 04:15:24 --> Output Class Initialized
INFO - 2023-12-10 04:15:24 --> Security Class Initialized
DEBUG - 2023-12-10 04:15:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-10 04:15:24 --> Input Class Initialized
INFO - 2023-12-10 04:15:24 --> Language Class Initialized
ERROR - 2023-12-10 04:15:24 --> 404 Page Not Found: Well-known/assetlinks.json
ERROR - 2023-12-10 08:21:03 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-12-10 08:21:03 --> Config Class Initialized
INFO - 2023-12-10 08:21:03 --> Hooks Class Initialized
DEBUG - 2023-12-10 08:21:03 --> UTF-8 Support Enabled
INFO - 2023-12-10 08:21:03 --> Utf8 Class Initialized
INFO - 2023-12-10 08:21:03 --> URI Class Initialized
DEBUG - 2023-12-10 08:21:03 --> No URI present. Default controller set.
INFO - 2023-12-10 08:21:03 --> Router Class Initialized
INFO - 2023-12-10 08:21:03 --> Output Class Initialized
INFO - 2023-12-10 08:21:03 --> Security Class Initialized
DEBUG - 2023-12-10 08:21:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-10 08:21:03 --> Input Class Initialized
INFO - 2023-12-10 08:21:03 --> Language Class Initialized
INFO - 2023-12-10 08:21:03 --> Loader Class Initialized
INFO - 2023-12-10 08:21:03 --> Helper loaded: url_helper
INFO - 2023-12-10 08:21:03 --> Helper loaded: file_helper
INFO - 2023-12-10 08:21:03 --> Helper loaded: html_helper
INFO - 2023-12-10 08:21:03 --> Helper loaded: text_helper
INFO - 2023-12-10 08:21:03 --> Helper loaded: form_helper
INFO - 2023-12-10 08:21:03 --> Helper loaded: lang_helper
INFO - 2023-12-10 08:21:03 --> Helper loaded: security_helper
INFO - 2023-12-10 08:21:03 --> Helper loaded: cookie_helper
INFO - 2023-12-10 08:21:03 --> Database Driver Class Initialized
INFO - 2023-12-10 08:21:03 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-10 08:21:03 --> Parser Class Initialized
INFO - 2023-12-10 08:21:03 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-12-10 08:21:03 --> Pagination Class Initialized
INFO - 2023-12-10 08:21:03 --> Form Validation Class Initialized
INFO - 2023-12-10 08:21:03 --> Controller Class Initialized
INFO - 2023-12-10 08:21:03 --> Model Class Initialized
DEBUG - 2023-12-10 08:21:03 --> Session class already loaded. Second attempt ignored.
ERROR - 2023-12-10 08:21:03 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-12-10 08:21:03 --> Config Class Initialized
INFO - 2023-12-10 08:21:03 --> Hooks Class Initialized
DEBUG - 2023-12-10 08:21:03 --> UTF-8 Support Enabled
INFO - 2023-12-10 08:21:03 --> Utf8 Class Initialized
INFO - 2023-12-10 08:21:03 --> URI Class Initialized
INFO - 2023-12-10 08:21:03 --> Router Class Initialized
INFO - 2023-12-10 08:21:03 --> Output Class Initialized
INFO - 2023-12-10 08:21:03 --> Security Class Initialized
DEBUG - 2023-12-10 08:21:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-10 08:21:03 --> Input Class Initialized
INFO - 2023-12-10 08:21:03 --> Language Class Initialized
INFO - 2023-12-10 08:21:03 --> Loader Class Initialized
INFO - 2023-12-10 08:21:03 --> Helper loaded: url_helper
INFO - 2023-12-10 08:21:03 --> Helper loaded: file_helper
INFO - 2023-12-10 08:21:03 --> Helper loaded: html_helper
INFO - 2023-12-10 08:21:03 --> Helper loaded: text_helper
INFO - 2023-12-10 08:21:03 --> Helper loaded: form_helper
INFO - 2023-12-10 08:21:03 --> Helper loaded: lang_helper
INFO - 2023-12-10 08:21:03 --> Helper loaded: security_helper
INFO - 2023-12-10 08:21:03 --> Helper loaded: cookie_helper
INFO - 2023-12-10 08:21:03 --> Database Driver Class Initialized
INFO - 2023-12-10 08:21:03 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-10 08:21:03 --> Parser Class Initialized
INFO - 2023-12-10 08:21:03 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-12-10 08:21:03 --> Pagination Class Initialized
INFO - 2023-12-10 08:21:03 --> Form Validation Class Initialized
INFO - 2023-12-10 08:21:03 --> Controller Class Initialized
INFO - 2023-12-10 08:21:03 --> Model Class Initialized
DEBUG - 2023-12-10 08:21:03 --> Session class already loaded. Second attempt ignored.
INFO - 2023-12-10 08:21:03 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2023-12-10 08:21:03 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-12-10 08:21:03 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-12-10 08:21:03 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-12-10 08:21:03 --> Model Class Initialized
INFO - 2023-12-10 08:21:03 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-12-10 08:21:03 --> Final output sent to browser
DEBUG - 2023-12-10 08:21:03 --> Total execution time: 0.0332
ERROR - 2023-12-10 08:21:06 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-12-10 08:21:06 --> Config Class Initialized
INFO - 2023-12-10 08:21:06 --> Hooks Class Initialized
DEBUG - 2023-12-10 08:21:06 --> UTF-8 Support Enabled
INFO - 2023-12-10 08:21:06 --> Utf8 Class Initialized
INFO - 2023-12-10 08:21:06 --> URI Class Initialized
INFO - 2023-12-10 08:21:06 --> Router Class Initialized
INFO - 2023-12-10 08:21:06 --> Output Class Initialized
INFO - 2023-12-10 08:21:06 --> Security Class Initialized
DEBUG - 2023-12-10 08:21:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-10 08:21:06 --> Input Class Initialized
INFO - 2023-12-10 08:21:06 --> Language Class Initialized
INFO - 2023-12-10 08:21:06 --> Loader Class Initialized
INFO - 2023-12-10 08:21:06 --> Helper loaded: url_helper
INFO - 2023-12-10 08:21:06 --> Helper loaded: file_helper
INFO - 2023-12-10 08:21:06 --> Helper loaded: html_helper
INFO - 2023-12-10 08:21:06 --> Helper loaded: text_helper
INFO - 2023-12-10 08:21:06 --> Helper loaded: form_helper
INFO - 2023-12-10 08:21:06 --> Helper loaded: lang_helper
INFO - 2023-12-10 08:21:06 --> Helper loaded: security_helper
INFO - 2023-12-10 08:21:06 --> Helper loaded: cookie_helper
INFO - 2023-12-10 08:21:06 --> Database Driver Class Initialized
INFO - 2023-12-10 08:21:06 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-10 08:21:06 --> Parser Class Initialized
INFO - 2023-12-10 08:21:06 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-12-10 08:21:06 --> Pagination Class Initialized
INFO - 2023-12-10 08:21:06 --> Form Validation Class Initialized
INFO - 2023-12-10 08:21:06 --> Controller Class Initialized
INFO - 2023-12-10 08:21:06 --> Model Class Initialized
DEBUG - 2023-12-10 08:21:06 --> Session class already loaded. Second attempt ignored.
INFO - 2023-12-10 08:21:06 --> Model Class Initialized
INFO - 2023-12-10 08:21:06 --> Final output sent to browser
DEBUG - 2023-12-10 08:21:06 --> Total execution time: 0.0193
ERROR - 2023-12-10 08:21:06 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-12-10 08:21:06 --> Config Class Initialized
INFO - 2023-12-10 08:21:06 --> Hooks Class Initialized
DEBUG - 2023-12-10 08:21:06 --> UTF-8 Support Enabled
INFO - 2023-12-10 08:21:06 --> Utf8 Class Initialized
INFO - 2023-12-10 08:21:06 --> URI Class Initialized
DEBUG - 2023-12-10 08:21:06 --> No URI present. Default controller set.
INFO - 2023-12-10 08:21:06 --> Router Class Initialized
INFO - 2023-12-10 08:21:06 --> Output Class Initialized
INFO - 2023-12-10 08:21:06 --> Security Class Initialized
DEBUG - 2023-12-10 08:21:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-10 08:21:06 --> Input Class Initialized
INFO - 2023-12-10 08:21:06 --> Language Class Initialized
INFO - 2023-12-10 08:21:06 --> Loader Class Initialized
INFO - 2023-12-10 08:21:06 --> Helper loaded: url_helper
INFO - 2023-12-10 08:21:06 --> Helper loaded: file_helper
INFO - 2023-12-10 08:21:06 --> Helper loaded: html_helper
INFO - 2023-12-10 08:21:06 --> Helper loaded: text_helper
INFO - 2023-12-10 08:21:06 --> Helper loaded: form_helper
INFO - 2023-12-10 08:21:06 --> Helper loaded: lang_helper
INFO - 2023-12-10 08:21:06 --> Helper loaded: security_helper
INFO - 2023-12-10 08:21:06 --> Helper loaded: cookie_helper
INFO - 2023-12-10 08:21:06 --> Database Driver Class Initialized
INFO - 2023-12-10 08:21:06 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-10 08:21:06 --> Parser Class Initialized
INFO - 2023-12-10 08:21:06 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-12-10 08:21:06 --> Pagination Class Initialized
INFO - 2023-12-10 08:21:06 --> Form Validation Class Initialized
INFO - 2023-12-10 08:21:06 --> Controller Class Initialized
INFO - 2023-12-10 08:21:06 --> Model Class Initialized
DEBUG - 2023-12-10 08:21:06 --> Session class already loaded. Second attempt ignored.
INFO - 2023-12-10 08:21:06 --> Model Class Initialized
DEBUG - 2023-12-10 08:21:06 --> Session class already loaded. Second attempt ignored.
INFO - 2023-12-10 08:21:06 --> Model Class Initialized
INFO - 2023-12-10 08:21:06 --> Model Class Initialized
INFO - 2023-12-10 08:21:06 --> Model Class Initialized
INFO - 2023-12-10 08:21:06 --> Model Class Initialized
DEBUG - 2023-12-10 08:21:06 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-12-10 08:21:06 --> Session class already loaded. Second attempt ignored.
INFO - 2023-12-10 08:21:06 --> Model Class Initialized
INFO - 2023-12-10 08:21:06 --> Model Class Initialized
INFO - 2023-12-10 08:21:07 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-12-10 08:21:07 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-12-10 08:21:07 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-12-10 08:21:07 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-12-10 08:21:07 --> Model Class Initialized
INFO - 2023-12-10 08:21:07 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-12-10 08:21:07 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-12-10 08:21:07 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-12-10 08:21:07 --> Final output sent to browser
DEBUG - 2023-12-10 08:21:07 --> Total execution time: 0.3919
ERROR - 2023-12-10 08:21:07 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-12-10 08:21:07 --> Config Class Initialized
INFO - 2023-12-10 08:21:07 --> Hooks Class Initialized
DEBUG - 2023-12-10 08:21:07 --> UTF-8 Support Enabled
INFO - 2023-12-10 08:21:07 --> Utf8 Class Initialized
INFO - 2023-12-10 08:21:07 --> URI Class Initialized
INFO - 2023-12-10 08:21:07 --> Router Class Initialized
INFO - 2023-12-10 08:21:07 --> Output Class Initialized
INFO - 2023-12-10 08:21:07 --> Security Class Initialized
DEBUG - 2023-12-10 08:21:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-10 08:21:07 --> Input Class Initialized
INFO - 2023-12-10 08:21:07 --> Language Class Initialized
INFO - 2023-12-10 08:21:07 --> Loader Class Initialized
INFO - 2023-12-10 08:21:07 --> Helper loaded: url_helper
INFO - 2023-12-10 08:21:07 --> Helper loaded: file_helper
INFO - 2023-12-10 08:21:07 --> Helper loaded: html_helper
INFO - 2023-12-10 08:21:07 --> Helper loaded: text_helper
INFO - 2023-12-10 08:21:07 --> Helper loaded: form_helper
INFO - 2023-12-10 08:21:07 --> Helper loaded: lang_helper
INFO - 2023-12-10 08:21:07 --> Helper loaded: security_helper
INFO - 2023-12-10 08:21:07 --> Helper loaded: cookie_helper
INFO - 2023-12-10 08:21:07 --> Database Driver Class Initialized
INFO - 2023-12-10 08:21:07 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-10 08:21:07 --> Parser Class Initialized
INFO - 2023-12-10 08:21:07 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-12-10 08:21:07 --> Pagination Class Initialized
INFO - 2023-12-10 08:21:07 --> Form Validation Class Initialized
INFO - 2023-12-10 08:21:07 --> Controller Class Initialized
DEBUG - 2023-12-10 08:21:07 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-12-10 08:21:07 --> Session class already loaded. Second attempt ignored.
INFO - 2023-12-10 08:21:07 --> Model Class Initialized
INFO - 2023-12-10 08:21:07 --> Final output sent to browser
DEBUG - 2023-12-10 08:21:07 --> Total execution time: 0.0132
ERROR - 2023-12-10 08:21:31 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-12-10 08:21:31 --> Config Class Initialized
INFO - 2023-12-10 08:21:31 --> Hooks Class Initialized
DEBUG - 2023-12-10 08:21:31 --> UTF-8 Support Enabled
INFO - 2023-12-10 08:21:31 --> Utf8 Class Initialized
INFO - 2023-12-10 08:21:31 --> URI Class Initialized
DEBUG - 2023-12-10 08:21:31 --> No URI present. Default controller set.
INFO - 2023-12-10 08:21:31 --> Router Class Initialized
INFO - 2023-12-10 08:21:31 --> Output Class Initialized
INFO - 2023-12-10 08:21:31 --> Security Class Initialized
DEBUG - 2023-12-10 08:21:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-10 08:21:31 --> Input Class Initialized
INFO - 2023-12-10 08:21:31 --> Language Class Initialized
INFO - 2023-12-10 08:21:31 --> Loader Class Initialized
INFO - 2023-12-10 08:21:31 --> Helper loaded: url_helper
INFO - 2023-12-10 08:21:31 --> Helper loaded: file_helper
INFO - 2023-12-10 08:21:31 --> Helper loaded: html_helper
INFO - 2023-12-10 08:21:31 --> Helper loaded: text_helper
INFO - 2023-12-10 08:21:31 --> Helper loaded: form_helper
INFO - 2023-12-10 08:21:31 --> Helper loaded: lang_helper
INFO - 2023-12-10 08:21:31 --> Helper loaded: security_helper
INFO - 2023-12-10 08:21:31 --> Helper loaded: cookie_helper
INFO - 2023-12-10 08:21:31 --> Database Driver Class Initialized
INFO - 2023-12-10 08:21:31 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-10 08:21:31 --> Parser Class Initialized
INFO - 2023-12-10 08:21:31 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-12-10 08:21:31 --> Pagination Class Initialized
INFO - 2023-12-10 08:21:31 --> Form Validation Class Initialized
INFO - 2023-12-10 08:21:31 --> Controller Class Initialized
INFO - 2023-12-10 08:21:31 --> Model Class Initialized
DEBUG - 2023-12-10 08:21:31 --> Session class already loaded. Second attempt ignored.
INFO - 2023-12-10 08:21:31 --> Model Class Initialized
DEBUG - 2023-12-10 08:21:31 --> Session class already loaded. Second attempt ignored.
INFO - 2023-12-10 08:21:31 --> Model Class Initialized
INFO - 2023-12-10 08:21:31 --> Model Class Initialized
INFO - 2023-12-10 08:21:31 --> Model Class Initialized
INFO - 2023-12-10 08:21:31 --> Model Class Initialized
DEBUG - 2023-12-10 08:21:31 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-12-10 08:21:31 --> Session class already loaded. Second attempt ignored.
INFO - 2023-12-10 08:21:31 --> Model Class Initialized
INFO - 2023-12-10 08:21:31 --> Model Class Initialized
INFO - 2023-12-10 08:21:32 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-12-10 08:21:32 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-12-10 08:21:32 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-12-10 08:21:32 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-12-10 08:21:32 --> Model Class Initialized
INFO - 2023-12-10 08:21:32 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-12-10 08:21:32 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-12-10 08:21:32 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-12-10 08:21:32 --> Final output sent to browser
DEBUG - 2023-12-10 08:21:32 --> Total execution time: 0.3842
ERROR - 2023-12-10 08:40:08 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-12-10 08:40:08 --> Config Class Initialized
INFO - 2023-12-10 08:40:08 --> Hooks Class Initialized
DEBUG - 2023-12-10 08:40:08 --> UTF-8 Support Enabled
INFO - 2023-12-10 08:40:08 --> Utf8 Class Initialized
INFO - 2023-12-10 08:40:08 --> URI Class Initialized
DEBUG - 2023-12-10 08:40:08 --> No URI present. Default controller set.
INFO - 2023-12-10 08:40:08 --> Router Class Initialized
INFO - 2023-12-10 08:40:08 --> Output Class Initialized
INFO - 2023-12-10 08:40:08 --> Security Class Initialized
DEBUG - 2023-12-10 08:40:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-10 08:40:08 --> Input Class Initialized
INFO - 2023-12-10 08:40:08 --> Language Class Initialized
INFO - 2023-12-10 08:40:08 --> Loader Class Initialized
INFO - 2023-12-10 08:40:08 --> Helper loaded: url_helper
INFO - 2023-12-10 08:40:08 --> Helper loaded: file_helper
INFO - 2023-12-10 08:40:08 --> Helper loaded: html_helper
INFO - 2023-12-10 08:40:08 --> Helper loaded: text_helper
INFO - 2023-12-10 08:40:08 --> Helper loaded: form_helper
INFO - 2023-12-10 08:40:08 --> Helper loaded: lang_helper
INFO - 2023-12-10 08:40:08 --> Helper loaded: security_helper
INFO - 2023-12-10 08:40:08 --> Helper loaded: cookie_helper
INFO - 2023-12-10 08:40:08 --> Database Driver Class Initialized
INFO - 2023-12-10 08:40:08 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-10 08:40:08 --> Parser Class Initialized
INFO - 2023-12-10 08:40:08 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-12-10 08:40:08 --> Pagination Class Initialized
INFO - 2023-12-10 08:40:08 --> Form Validation Class Initialized
INFO - 2023-12-10 08:40:08 --> Controller Class Initialized
INFO - 2023-12-10 08:40:08 --> Model Class Initialized
DEBUG - 2023-12-10 08:40:08 --> Session class already loaded. Second attempt ignored.
INFO - 2023-12-10 08:40:08 --> Model Class Initialized
DEBUG - 2023-12-10 08:40:08 --> Session class already loaded. Second attempt ignored.
INFO - 2023-12-10 08:40:08 --> Model Class Initialized
INFO - 2023-12-10 08:40:08 --> Model Class Initialized
INFO - 2023-12-10 08:40:08 --> Model Class Initialized
INFO - 2023-12-10 08:40:08 --> Model Class Initialized
DEBUG - 2023-12-10 08:40:08 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-12-10 08:40:08 --> Session class already loaded. Second attempt ignored.
INFO - 2023-12-10 08:40:08 --> Model Class Initialized
INFO - 2023-12-10 08:40:08 --> Model Class Initialized
INFO - 2023-12-10 08:40:08 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-12-10 08:40:08 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-12-10 08:40:08 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-12-10 08:40:08 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-12-10 08:40:08 --> Model Class Initialized
INFO - 2023-12-10 08:40:08 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-12-10 08:40:08 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-12-10 08:40:08 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-12-10 08:40:08 --> Final output sent to browser
DEBUG - 2023-12-10 08:40:08 --> Total execution time: 0.3816
ERROR - 2023-12-10 08:40:11 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-12-10 08:40:11 --> Config Class Initialized
INFO - 2023-12-10 08:40:11 --> Hooks Class Initialized
DEBUG - 2023-12-10 08:40:11 --> UTF-8 Support Enabled
INFO - 2023-12-10 08:40:11 --> Utf8 Class Initialized
INFO - 2023-12-10 08:40:11 --> URI Class Initialized
INFO - 2023-12-10 08:40:11 --> Router Class Initialized
INFO - 2023-12-10 08:40:11 --> Output Class Initialized
INFO - 2023-12-10 08:40:11 --> Security Class Initialized
DEBUG - 2023-12-10 08:40:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-10 08:40:11 --> Input Class Initialized
INFO - 2023-12-10 08:40:11 --> Language Class Initialized
INFO - 2023-12-10 08:40:11 --> Loader Class Initialized
INFO - 2023-12-10 08:40:11 --> Helper loaded: url_helper
INFO - 2023-12-10 08:40:11 --> Helper loaded: file_helper
INFO - 2023-12-10 08:40:11 --> Helper loaded: html_helper
INFO - 2023-12-10 08:40:11 --> Helper loaded: text_helper
INFO - 2023-12-10 08:40:11 --> Helper loaded: form_helper
INFO - 2023-12-10 08:40:11 --> Helper loaded: lang_helper
INFO - 2023-12-10 08:40:11 --> Helper loaded: security_helper
INFO - 2023-12-10 08:40:11 --> Helper loaded: cookie_helper
INFO - 2023-12-10 08:40:11 --> Database Driver Class Initialized
INFO - 2023-12-10 08:40:11 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-10 08:40:11 --> Parser Class Initialized
INFO - 2023-12-10 08:40:11 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-12-10 08:40:11 --> Pagination Class Initialized
INFO - 2023-12-10 08:40:11 --> Form Validation Class Initialized
INFO - 2023-12-10 08:40:11 --> Controller Class Initialized
INFO - 2023-12-10 08:40:11 --> Model Class Initialized
DEBUG - 2023-12-10 08:40:11 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-12-10 08:40:11 --> Session class already loaded. Second attempt ignored.
INFO - 2023-12-10 08:40:11 --> Model Class Initialized
DEBUG - 2023-12-10 08:40:11 --> Session class already loaded. Second attempt ignored.
INFO - 2023-12-10 08:40:11 --> Model Class Initialized
INFO - 2023-12-10 08:40:11 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice.php
DEBUG - 2023-12-10 08:40:11 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-12-10 08:40:11 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-12-10 08:40:11 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-12-10 08:40:11 --> Model Class Initialized
INFO - 2023-12-10 08:40:11 --> Model Class Initialized
INFO - 2023-12-10 08:40:11 --> Model Class Initialized
INFO - 2023-12-10 08:40:12 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-12-10 08:40:12 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-12-10 08:40:12 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-12-10 08:40:12 --> Final output sent to browser
DEBUG - 2023-12-10 08:40:12 --> Total execution time: 0.2152
ERROR - 2023-12-10 08:40:12 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-12-10 08:40:12 --> Config Class Initialized
INFO - 2023-12-10 08:40:12 --> Hooks Class Initialized
DEBUG - 2023-12-10 08:40:12 --> UTF-8 Support Enabled
INFO - 2023-12-10 08:40:12 --> Utf8 Class Initialized
INFO - 2023-12-10 08:40:12 --> URI Class Initialized
INFO - 2023-12-10 08:40:12 --> Router Class Initialized
INFO - 2023-12-10 08:40:12 --> Output Class Initialized
INFO - 2023-12-10 08:40:12 --> Security Class Initialized
DEBUG - 2023-12-10 08:40:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-10 08:40:12 --> Input Class Initialized
INFO - 2023-12-10 08:40:12 --> Language Class Initialized
INFO - 2023-12-10 08:40:12 --> Loader Class Initialized
INFO - 2023-12-10 08:40:12 --> Helper loaded: url_helper
INFO - 2023-12-10 08:40:12 --> Helper loaded: file_helper
INFO - 2023-12-10 08:40:12 --> Helper loaded: html_helper
INFO - 2023-12-10 08:40:12 --> Helper loaded: text_helper
INFO - 2023-12-10 08:40:12 --> Helper loaded: form_helper
INFO - 2023-12-10 08:40:12 --> Helper loaded: lang_helper
INFO - 2023-12-10 08:40:12 --> Helper loaded: security_helper
INFO - 2023-12-10 08:40:12 --> Helper loaded: cookie_helper
INFO - 2023-12-10 08:40:12 --> Database Driver Class Initialized
INFO - 2023-12-10 08:40:12 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-10 08:40:12 --> Parser Class Initialized
INFO - 2023-12-10 08:40:12 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-12-10 08:40:12 --> Pagination Class Initialized
INFO - 2023-12-10 08:40:12 --> Form Validation Class Initialized
INFO - 2023-12-10 08:40:12 --> Controller Class Initialized
INFO - 2023-12-10 08:40:12 --> Model Class Initialized
DEBUG - 2023-12-10 08:40:12 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-12-10 08:40:12 --> Session class already loaded. Second attempt ignored.
INFO - 2023-12-10 08:40:12 --> Model Class Initialized
DEBUG - 2023-12-10 08:40:12 --> Session class already loaded. Second attempt ignored.
INFO - 2023-12-10 08:40:12 --> Model Class Initialized
INFO - 2023-12-10 08:40:12 --> Final output sent to browser
DEBUG - 2023-12-10 08:40:12 --> Total execution time: 0.0620
ERROR - 2023-12-10 08:40:16 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-12-10 08:40:16 --> Config Class Initialized
INFO - 2023-12-10 08:40:16 --> Hooks Class Initialized
DEBUG - 2023-12-10 08:40:16 --> UTF-8 Support Enabled
INFO - 2023-12-10 08:40:16 --> Utf8 Class Initialized
INFO - 2023-12-10 08:40:16 --> URI Class Initialized
INFO - 2023-12-10 08:40:16 --> Router Class Initialized
INFO - 2023-12-10 08:40:16 --> Output Class Initialized
INFO - 2023-12-10 08:40:16 --> Security Class Initialized
DEBUG - 2023-12-10 08:40:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-10 08:40:16 --> Input Class Initialized
INFO - 2023-12-10 08:40:16 --> Language Class Initialized
INFO - 2023-12-10 08:40:16 --> Loader Class Initialized
INFO - 2023-12-10 08:40:16 --> Helper loaded: url_helper
INFO - 2023-12-10 08:40:16 --> Helper loaded: file_helper
INFO - 2023-12-10 08:40:16 --> Helper loaded: html_helper
INFO - 2023-12-10 08:40:16 --> Helper loaded: text_helper
INFO - 2023-12-10 08:40:16 --> Helper loaded: form_helper
INFO - 2023-12-10 08:40:16 --> Helper loaded: lang_helper
INFO - 2023-12-10 08:40:16 --> Helper loaded: security_helper
INFO - 2023-12-10 08:40:16 --> Helper loaded: cookie_helper
INFO - 2023-12-10 08:40:16 --> Database Driver Class Initialized
INFO - 2023-12-10 08:40:16 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-10 08:40:16 --> Parser Class Initialized
INFO - 2023-12-10 08:40:16 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-12-10 08:40:16 --> Pagination Class Initialized
INFO - 2023-12-10 08:40:16 --> Form Validation Class Initialized
INFO - 2023-12-10 08:40:16 --> Controller Class Initialized
INFO - 2023-12-10 08:40:16 --> Model Class Initialized
DEBUG - 2023-12-10 08:40:16 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-12-10 08:40:16 --> Session class already loaded. Second attempt ignored.
INFO - 2023-12-10 08:40:16 --> Model Class Initialized
DEBUG - 2023-12-10 08:40:16 --> Session class already loaded. Second attempt ignored.
INFO - 2023-12-10 08:40:16 --> Model Class Initialized
DEBUG - 2023-12-10 08:40:16 --> Session class already loaded. Second attempt ignored.
INFO - 2023-12-10 08:40:16 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice_html.php
DEBUG - 2023-12-10 08:40:16 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-12-10 08:40:16 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-12-10 08:40:16 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-12-10 08:40:16 --> Model Class Initialized
INFO - 2023-12-10 08:40:16 --> Model Class Initialized
INFO - 2023-12-10 08:40:16 --> Model Class Initialized
INFO - 2023-12-10 08:40:16 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-12-10 08:40:16 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-12-10 08:40:16 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-12-10 08:40:16 --> Final output sent to browser
DEBUG - 2023-12-10 08:40:16 --> Total execution time: 0.2356
ERROR - 2023-12-10 08:40:34 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-12-10 08:40:34 --> Config Class Initialized
INFO - 2023-12-10 08:40:34 --> Hooks Class Initialized
DEBUG - 2023-12-10 08:40:34 --> UTF-8 Support Enabled
INFO - 2023-12-10 08:40:34 --> Utf8 Class Initialized
INFO - 2023-12-10 08:40:34 --> URI Class Initialized
DEBUG - 2023-12-10 08:40:34 --> No URI present. Default controller set.
INFO - 2023-12-10 08:40:34 --> Router Class Initialized
INFO - 2023-12-10 08:40:34 --> Output Class Initialized
INFO - 2023-12-10 08:40:34 --> Security Class Initialized
DEBUG - 2023-12-10 08:40:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-10 08:40:34 --> Input Class Initialized
INFO - 2023-12-10 08:40:34 --> Language Class Initialized
INFO - 2023-12-10 08:40:34 --> Loader Class Initialized
INFO - 2023-12-10 08:40:34 --> Helper loaded: url_helper
INFO - 2023-12-10 08:40:34 --> Helper loaded: file_helper
INFO - 2023-12-10 08:40:34 --> Helper loaded: html_helper
INFO - 2023-12-10 08:40:34 --> Helper loaded: text_helper
INFO - 2023-12-10 08:40:34 --> Helper loaded: form_helper
INFO - 2023-12-10 08:40:34 --> Helper loaded: lang_helper
INFO - 2023-12-10 08:40:34 --> Helper loaded: security_helper
INFO - 2023-12-10 08:40:34 --> Helper loaded: cookie_helper
INFO - 2023-12-10 08:40:34 --> Database Driver Class Initialized
INFO - 2023-12-10 08:40:34 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-10 08:40:34 --> Parser Class Initialized
INFO - 2023-12-10 08:40:34 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-12-10 08:40:34 --> Pagination Class Initialized
INFO - 2023-12-10 08:40:34 --> Form Validation Class Initialized
INFO - 2023-12-10 08:40:34 --> Controller Class Initialized
INFO - 2023-12-10 08:40:34 --> Model Class Initialized
DEBUG - 2023-12-10 08:40:34 --> Session class already loaded. Second attempt ignored.
ERROR - 2023-12-10 08:40:35 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-12-10 08:40:35 --> Config Class Initialized
INFO - 2023-12-10 08:40:35 --> Hooks Class Initialized
DEBUG - 2023-12-10 08:40:35 --> UTF-8 Support Enabled
INFO - 2023-12-10 08:40:35 --> Utf8 Class Initialized
INFO - 2023-12-10 08:40:35 --> URI Class Initialized
INFO - 2023-12-10 08:40:35 --> Router Class Initialized
INFO - 2023-12-10 08:40:35 --> Output Class Initialized
INFO - 2023-12-10 08:40:35 --> Security Class Initialized
DEBUG - 2023-12-10 08:40:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-10 08:40:35 --> Input Class Initialized
INFO - 2023-12-10 08:40:35 --> Language Class Initialized
INFO - 2023-12-10 08:40:35 --> Loader Class Initialized
INFO - 2023-12-10 08:40:35 --> Helper loaded: url_helper
INFO - 2023-12-10 08:40:35 --> Helper loaded: file_helper
INFO - 2023-12-10 08:40:35 --> Helper loaded: html_helper
INFO - 2023-12-10 08:40:35 --> Helper loaded: text_helper
INFO - 2023-12-10 08:40:35 --> Helper loaded: form_helper
INFO - 2023-12-10 08:40:35 --> Helper loaded: lang_helper
INFO - 2023-12-10 08:40:35 --> Helper loaded: security_helper
INFO - 2023-12-10 08:40:35 --> Helper loaded: cookie_helper
INFO - 2023-12-10 08:40:35 --> Database Driver Class Initialized
INFO - 2023-12-10 08:40:35 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-10 08:40:35 --> Parser Class Initialized
INFO - 2023-12-10 08:40:35 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-12-10 08:40:35 --> Pagination Class Initialized
INFO - 2023-12-10 08:40:35 --> Form Validation Class Initialized
INFO - 2023-12-10 08:40:35 --> Controller Class Initialized
INFO - 2023-12-10 08:40:35 --> Model Class Initialized
DEBUG - 2023-12-10 08:40:35 --> Session class already loaded. Second attempt ignored.
INFO - 2023-12-10 08:40:35 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2023-12-10 08:40:35 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-12-10 08:40:35 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-12-10 08:40:35 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-12-10 08:40:35 --> Model Class Initialized
INFO - 2023-12-10 08:40:35 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-12-10 08:40:35 --> Final output sent to browser
DEBUG - 2023-12-10 08:40:35 --> Total execution time: 0.0294
ERROR - 2023-12-10 08:40:35 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-12-10 08:40:35 --> Config Class Initialized
INFO - 2023-12-10 08:40:35 --> Hooks Class Initialized
DEBUG - 2023-12-10 08:40:35 --> UTF-8 Support Enabled
INFO - 2023-12-10 08:40:35 --> Utf8 Class Initialized
INFO - 2023-12-10 08:40:35 --> URI Class Initialized
INFO - 2023-12-10 08:40:35 --> Router Class Initialized
INFO - 2023-12-10 08:40:35 --> Output Class Initialized
INFO - 2023-12-10 08:40:35 --> Security Class Initialized
DEBUG - 2023-12-10 08:40:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-10 08:40:35 --> Input Class Initialized
INFO - 2023-12-10 08:40:35 --> Language Class Initialized
ERROR - 2023-12-10 08:40:35 --> 404 Page Not Found: Apple-touch-icon-precomposedpng/index
ERROR - 2023-12-10 08:40:35 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-12-10 08:40:35 --> Config Class Initialized
INFO - 2023-12-10 08:40:35 --> Hooks Class Initialized
DEBUG - 2023-12-10 08:40:35 --> UTF-8 Support Enabled
INFO - 2023-12-10 08:40:35 --> Utf8 Class Initialized
INFO - 2023-12-10 08:40:35 --> URI Class Initialized
INFO - 2023-12-10 08:40:35 --> Router Class Initialized
INFO - 2023-12-10 08:40:35 --> Output Class Initialized
INFO - 2023-12-10 08:40:35 --> Security Class Initialized
DEBUG - 2023-12-10 08:40:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-10 08:40:35 --> Input Class Initialized
INFO - 2023-12-10 08:40:35 --> Language Class Initialized
ERROR - 2023-12-10 08:40:35 --> 404 Page Not Found: Apple-touch-iconpng/index
ERROR - 2023-12-10 08:40:39 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-12-10 08:40:39 --> Config Class Initialized
INFO - 2023-12-10 08:40:39 --> Hooks Class Initialized
DEBUG - 2023-12-10 08:40:39 --> UTF-8 Support Enabled
INFO - 2023-12-10 08:40:39 --> Utf8 Class Initialized
INFO - 2023-12-10 08:40:39 --> URI Class Initialized
INFO - 2023-12-10 08:40:39 --> Router Class Initialized
INFO - 2023-12-10 08:40:39 --> Output Class Initialized
INFO - 2023-12-10 08:40:39 --> Security Class Initialized
DEBUG - 2023-12-10 08:40:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-10 08:40:39 --> Input Class Initialized
INFO - 2023-12-10 08:40:39 --> Language Class Initialized
INFO - 2023-12-10 08:40:39 --> Loader Class Initialized
INFO - 2023-12-10 08:40:39 --> Helper loaded: url_helper
INFO - 2023-12-10 08:40:39 --> Helper loaded: file_helper
INFO - 2023-12-10 08:40:39 --> Helper loaded: html_helper
INFO - 2023-12-10 08:40:39 --> Helper loaded: text_helper
INFO - 2023-12-10 08:40:39 --> Helper loaded: form_helper
INFO - 2023-12-10 08:40:39 --> Helper loaded: lang_helper
INFO - 2023-12-10 08:40:39 --> Helper loaded: security_helper
INFO - 2023-12-10 08:40:39 --> Helper loaded: cookie_helper
INFO - 2023-12-10 08:40:39 --> Database Driver Class Initialized
INFO - 2023-12-10 08:40:39 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-10 08:40:39 --> Parser Class Initialized
INFO - 2023-12-10 08:40:39 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-12-10 08:40:39 --> Pagination Class Initialized
INFO - 2023-12-10 08:40:39 --> Form Validation Class Initialized
INFO - 2023-12-10 08:40:39 --> Controller Class Initialized
INFO - 2023-12-10 08:40:39 --> Model Class Initialized
DEBUG - 2023-12-10 08:40:39 --> Session class already loaded. Second attempt ignored.
INFO - 2023-12-10 08:40:39 --> Model Class Initialized
INFO - 2023-12-10 08:40:39 --> Final output sent to browser
DEBUG - 2023-12-10 08:40:39 --> Total execution time: 0.0184
ERROR - 2023-12-10 08:40:39 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-12-10 08:40:39 --> Config Class Initialized
INFO - 2023-12-10 08:40:39 --> Hooks Class Initialized
DEBUG - 2023-12-10 08:40:39 --> UTF-8 Support Enabled
INFO - 2023-12-10 08:40:39 --> Utf8 Class Initialized
INFO - 2023-12-10 08:40:39 --> URI Class Initialized
DEBUG - 2023-12-10 08:40:39 --> No URI present. Default controller set.
INFO - 2023-12-10 08:40:39 --> Router Class Initialized
INFO - 2023-12-10 08:40:39 --> Output Class Initialized
INFO - 2023-12-10 08:40:39 --> Security Class Initialized
DEBUG - 2023-12-10 08:40:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-10 08:40:39 --> Input Class Initialized
INFO - 2023-12-10 08:40:39 --> Language Class Initialized
INFO - 2023-12-10 08:40:39 --> Loader Class Initialized
INFO - 2023-12-10 08:40:39 --> Helper loaded: url_helper
INFO - 2023-12-10 08:40:39 --> Helper loaded: file_helper
INFO - 2023-12-10 08:40:39 --> Helper loaded: html_helper
INFO - 2023-12-10 08:40:39 --> Helper loaded: text_helper
INFO - 2023-12-10 08:40:39 --> Helper loaded: form_helper
INFO - 2023-12-10 08:40:39 --> Helper loaded: lang_helper
INFO - 2023-12-10 08:40:39 --> Helper loaded: security_helper
INFO - 2023-12-10 08:40:39 --> Helper loaded: cookie_helper
INFO - 2023-12-10 08:40:39 --> Database Driver Class Initialized
INFO - 2023-12-10 08:40:39 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-10 08:40:39 --> Parser Class Initialized
INFO - 2023-12-10 08:40:39 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-12-10 08:40:39 --> Pagination Class Initialized
INFO - 2023-12-10 08:40:39 --> Form Validation Class Initialized
INFO - 2023-12-10 08:40:39 --> Controller Class Initialized
INFO - 2023-12-10 08:40:39 --> Model Class Initialized
DEBUG - 2023-12-10 08:40:39 --> Session class already loaded. Second attempt ignored.
INFO - 2023-12-10 08:40:39 --> Model Class Initialized
DEBUG - 2023-12-10 08:40:39 --> Session class already loaded. Second attempt ignored.
INFO - 2023-12-10 08:40:39 --> Model Class Initialized
INFO - 2023-12-10 08:40:39 --> Model Class Initialized
INFO - 2023-12-10 08:40:39 --> Model Class Initialized
INFO - 2023-12-10 08:40:39 --> Model Class Initialized
DEBUG - 2023-12-10 08:40:39 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-12-10 08:40:39 --> Session class already loaded. Second attempt ignored.
INFO - 2023-12-10 08:40:39 --> Model Class Initialized
INFO - 2023-12-10 08:40:39 --> Model Class Initialized
INFO - 2023-12-10 08:40:39 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-12-10 08:40:39 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-12-10 08:40:39 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-12-10 08:40:39 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-12-10 08:40:39 --> Model Class Initialized
INFO - 2023-12-10 08:40:39 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-12-10 08:40:39 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-12-10 08:40:39 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-12-10 08:40:39 --> Final output sent to browser
DEBUG - 2023-12-10 08:40:39 --> Total execution time: 0.2165
ERROR - 2023-12-10 08:40:54 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-12-10 08:40:54 --> Config Class Initialized
INFO - 2023-12-10 08:40:54 --> Hooks Class Initialized
DEBUG - 2023-12-10 08:40:54 --> UTF-8 Support Enabled
INFO - 2023-12-10 08:40:54 --> Utf8 Class Initialized
INFO - 2023-12-10 08:40:54 --> URI Class Initialized
INFO - 2023-12-10 08:40:54 --> Router Class Initialized
INFO - 2023-12-10 08:40:54 --> Output Class Initialized
INFO - 2023-12-10 08:40:54 --> Security Class Initialized
DEBUG - 2023-12-10 08:40:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-10 08:40:54 --> Input Class Initialized
INFO - 2023-12-10 08:40:54 --> Language Class Initialized
INFO - 2023-12-10 08:40:54 --> Loader Class Initialized
INFO - 2023-12-10 08:40:54 --> Helper loaded: url_helper
INFO - 2023-12-10 08:40:54 --> Helper loaded: file_helper
INFO - 2023-12-10 08:40:54 --> Helper loaded: html_helper
INFO - 2023-12-10 08:40:54 --> Helper loaded: text_helper
INFO - 2023-12-10 08:40:54 --> Helper loaded: form_helper
INFO - 2023-12-10 08:40:54 --> Helper loaded: lang_helper
INFO - 2023-12-10 08:40:54 --> Helper loaded: security_helper
INFO - 2023-12-10 08:40:54 --> Helper loaded: cookie_helper
INFO - 2023-12-10 08:40:54 --> Database Driver Class Initialized
INFO - 2023-12-10 08:40:54 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-10 08:40:54 --> Parser Class Initialized
INFO - 2023-12-10 08:40:54 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-12-10 08:40:54 --> Pagination Class Initialized
INFO - 2023-12-10 08:40:54 --> Form Validation Class Initialized
INFO - 2023-12-10 08:40:54 --> Controller Class Initialized
INFO - 2023-12-10 08:40:54 --> Model Class Initialized
DEBUG - 2023-12-10 08:40:54 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-12-10 08:40:54 --> Session class already loaded. Second attempt ignored.
INFO - 2023-12-10 08:40:54 --> Model Class Initialized
DEBUG - 2023-12-10 08:40:54 --> Session class already loaded. Second attempt ignored.
INFO - 2023-12-10 08:40:54 --> Model Class Initialized
INFO - 2023-12-10 08:40:54 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice.php
DEBUG - 2023-12-10 08:40:54 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-12-10 08:40:54 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-12-10 08:40:54 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-12-10 08:40:54 --> Model Class Initialized
INFO - 2023-12-10 08:40:54 --> Model Class Initialized
INFO - 2023-12-10 08:40:54 --> Model Class Initialized
INFO - 2023-12-10 08:40:54 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-12-10 08:40:54 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-12-10 08:40:54 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-12-10 08:40:54 --> Final output sent to browser
DEBUG - 2023-12-10 08:40:54 --> Total execution time: 0.1431
ERROR - 2023-12-10 08:40:55 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-12-10 08:40:55 --> Config Class Initialized
INFO - 2023-12-10 08:40:55 --> Hooks Class Initialized
DEBUG - 2023-12-10 08:40:55 --> UTF-8 Support Enabled
INFO - 2023-12-10 08:40:55 --> Utf8 Class Initialized
INFO - 2023-12-10 08:40:55 --> URI Class Initialized
INFO - 2023-12-10 08:40:55 --> Router Class Initialized
INFO - 2023-12-10 08:40:55 --> Output Class Initialized
INFO - 2023-12-10 08:40:55 --> Security Class Initialized
DEBUG - 2023-12-10 08:40:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-10 08:40:55 --> Input Class Initialized
INFO - 2023-12-10 08:40:55 --> Language Class Initialized
INFO - 2023-12-10 08:40:55 --> Loader Class Initialized
INFO - 2023-12-10 08:40:55 --> Helper loaded: url_helper
INFO - 2023-12-10 08:40:55 --> Helper loaded: file_helper
INFO - 2023-12-10 08:40:55 --> Helper loaded: html_helper
INFO - 2023-12-10 08:40:55 --> Helper loaded: text_helper
INFO - 2023-12-10 08:40:55 --> Helper loaded: form_helper
INFO - 2023-12-10 08:40:55 --> Helper loaded: lang_helper
INFO - 2023-12-10 08:40:55 --> Helper loaded: security_helper
INFO - 2023-12-10 08:40:55 --> Helper loaded: cookie_helper
INFO - 2023-12-10 08:40:55 --> Database Driver Class Initialized
INFO - 2023-12-10 08:40:55 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-10 08:40:55 --> Parser Class Initialized
INFO - 2023-12-10 08:40:55 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-12-10 08:40:55 --> Pagination Class Initialized
INFO - 2023-12-10 08:40:55 --> Form Validation Class Initialized
INFO - 2023-12-10 08:40:55 --> Controller Class Initialized
INFO - 2023-12-10 08:40:55 --> Model Class Initialized
DEBUG - 2023-12-10 08:40:55 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-12-10 08:40:55 --> Session class already loaded. Second attempt ignored.
INFO - 2023-12-10 08:40:55 --> Model Class Initialized
DEBUG - 2023-12-10 08:40:55 --> Session class already loaded. Second attempt ignored.
INFO - 2023-12-10 08:40:55 --> Model Class Initialized
INFO - 2023-12-10 08:40:55 --> Final output sent to browser
DEBUG - 2023-12-10 08:40:55 --> Total execution time: 0.0397
ERROR - 2023-12-10 08:41:01 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-12-10 08:41:01 --> Config Class Initialized
INFO - 2023-12-10 08:41:01 --> Hooks Class Initialized
DEBUG - 2023-12-10 08:41:01 --> UTF-8 Support Enabled
INFO - 2023-12-10 08:41:01 --> Utf8 Class Initialized
INFO - 2023-12-10 08:41:01 --> URI Class Initialized
INFO - 2023-12-10 08:41:01 --> Router Class Initialized
INFO - 2023-12-10 08:41:01 --> Output Class Initialized
INFO - 2023-12-10 08:41:01 --> Security Class Initialized
DEBUG - 2023-12-10 08:41:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-10 08:41:01 --> Input Class Initialized
INFO - 2023-12-10 08:41:01 --> Language Class Initialized
INFO - 2023-12-10 08:41:01 --> Loader Class Initialized
INFO - 2023-12-10 08:41:01 --> Helper loaded: url_helper
INFO - 2023-12-10 08:41:01 --> Helper loaded: file_helper
INFO - 2023-12-10 08:41:01 --> Helper loaded: html_helper
INFO - 2023-12-10 08:41:01 --> Helper loaded: text_helper
INFO - 2023-12-10 08:41:01 --> Helper loaded: form_helper
INFO - 2023-12-10 08:41:01 --> Helper loaded: lang_helper
INFO - 2023-12-10 08:41:01 --> Helper loaded: security_helper
INFO - 2023-12-10 08:41:01 --> Helper loaded: cookie_helper
INFO - 2023-12-10 08:41:01 --> Database Driver Class Initialized
INFO - 2023-12-10 08:41:01 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-10 08:41:01 --> Parser Class Initialized
INFO - 2023-12-10 08:41:01 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-12-10 08:41:01 --> Pagination Class Initialized
INFO - 2023-12-10 08:41:01 --> Form Validation Class Initialized
INFO - 2023-12-10 08:41:01 --> Controller Class Initialized
INFO - 2023-12-10 08:41:01 --> Model Class Initialized
DEBUG - 2023-12-10 08:41:01 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-12-10 08:41:01 --> Session class already loaded. Second attempt ignored.
INFO - 2023-12-10 08:41:01 --> Model Class Initialized
DEBUG - 2023-12-10 08:41:01 --> Session class already loaded. Second attempt ignored.
INFO - 2023-12-10 08:41:01 --> Model Class Initialized
INFO - 2023-12-10 08:41:02 --> Final output sent to browser
DEBUG - 2023-12-10 08:41:02 --> Total execution time: 0.4485
ERROR - 2023-12-10 08:41:12 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-12-10 08:41:12 --> Config Class Initialized
INFO - 2023-12-10 08:41:12 --> Hooks Class Initialized
DEBUG - 2023-12-10 08:41:12 --> UTF-8 Support Enabled
INFO - 2023-12-10 08:41:12 --> Utf8 Class Initialized
INFO - 2023-12-10 08:41:12 --> URI Class Initialized
INFO - 2023-12-10 08:41:12 --> Router Class Initialized
INFO - 2023-12-10 08:41:12 --> Output Class Initialized
INFO - 2023-12-10 08:41:12 --> Security Class Initialized
DEBUG - 2023-12-10 08:41:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-10 08:41:12 --> Input Class Initialized
INFO - 2023-12-10 08:41:12 --> Language Class Initialized
INFO - 2023-12-10 08:41:12 --> Loader Class Initialized
INFO - 2023-12-10 08:41:12 --> Helper loaded: url_helper
INFO - 2023-12-10 08:41:12 --> Helper loaded: file_helper
INFO - 2023-12-10 08:41:12 --> Helper loaded: html_helper
INFO - 2023-12-10 08:41:12 --> Helper loaded: text_helper
INFO - 2023-12-10 08:41:12 --> Helper loaded: form_helper
INFO - 2023-12-10 08:41:12 --> Helper loaded: lang_helper
INFO - 2023-12-10 08:41:12 --> Helper loaded: security_helper
INFO - 2023-12-10 08:41:12 --> Helper loaded: cookie_helper
INFO - 2023-12-10 08:41:12 --> Database Driver Class Initialized
INFO - 2023-12-10 08:41:12 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-10 08:41:12 --> Parser Class Initialized
INFO - 2023-12-10 08:41:12 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-12-10 08:41:12 --> Pagination Class Initialized
INFO - 2023-12-10 08:41:12 --> Form Validation Class Initialized
INFO - 2023-12-10 08:41:12 --> Controller Class Initialized
INFO - 2023-12-10 08:41:12 --> Model Class Initialized
DEBUG - 2023-12-10 08:41:12 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-12-10 08:41:12 --> Session class already loaded. Second attempt ignored.
INFO - 2023-12-10 08:41:12 --> Model Class Initialized
INFO - 2023-12-10 08:41:12 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/stockrequest/inventory.php
DEBUG - 2023-12-10 08:41:12 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-12-10 08:41:12 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-12-10 08:41:12 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-12-10 08:41:12 --> Model Class Initialized
INFO - 2023-12-10 08:41:12 --> Model Class Initialized
INFO - 2023-12-10 08:41:12 --> Model Class Initialized
INFO - 2023-12-10 08:41:12 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-12-10 08:41:12 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-12-10 08:41:12 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-12-10 08:41:12 --> Final output sent to browser
DEBUG - 2023-12-10 08:41:12 --> Total execution time: 0.1347
ERROR - 2023-12-10 08:41:13 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-12-10 08:41:13 --> Config Class Initialized
INFO - 2023-12-10 08:41:13 --> Hooks Class Initialized
DEBUG - 2023-12-10 08:41:13 --> UTF-8 Support Enabled
INFO - 2023-12-10 08:41:13 --> Utf8 Class Initialized
INFO - 2023-12-10 08:41:13 --> URI Class Initialized
INFO - 2023-12-10 08:41:13 --> Router Class Initialized
INFO - 2023-12-10 08:41:13 --> Output Class Initialized
INFO - 2023-12-10 08:41:13 --> Security Class Initialized
DEBUG - 2023-12-10 08:41:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-10 08:41:13 --> Input Class Initialized
INFO - 2023-12-10 08:41:13 --> Language Class Initialized
INFO - 2023-12-10 08:41:13 --> Loader Class Initialized
INFO - 2023-12-10 08:41:13 --> Helper loaded: url_helper
INFO - 2023-12-10 08:41:13 --> Helper loaded: file_helper
INFO - 2023-12-10 08:41:13 --> Helper loaded: html_helper
INFO - 2023-12-10 08:41:13 --> Helper loaded: text_helper
INFO - 2023-12-10 08:41:13 --> Helper loaded: form_helper
INFO - 2023-12-10 08:41:13 --> Helper loaded: lang_helper
INFO - 2023-12-10 08:41:13 --> Helper loaded: security_helper
INFO - 2023-12-10 08:41:13 --> Helper loaded: cookie_helper
INFO - 2023-12-10 08:41:13 --> Database Driver Class Initialized
INFO - 2023-12-10 08:41:13 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-10 08:41:13 --> Parser Class Initialized
INFO - 2023-12-10 08:41:13 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-12-10 08:41:13 --> Pagination Class Initialized
INFO - 2023-12-10 08:41:13 --> Form Validation Class Initialized
INFO - 2023-12-10 08:41:13 --> Controller Class Initialized
INFO - 2023-12-10 08:41:13 --> Model Class Initialized
DEBUG - 2023-12-10 08:41:13 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-12-10 08:41:13 --> Session class already loaded. Second attempt ignored.
INFO - 2023-12-10 08:41:13 --> Model Class Initialized
INFO - 2023-12-10 08:41:13 --> Final output sent to browser
DEBUG - 2023-12-10 08:41:13 --> Total execution time: 0.0719
ERROR - 2023-12-10 08:41:16 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-12-10 08:41:16 --> Config Class Initialized
INFO - 2023-12-10 08:41:16 --> Hooks Class Initialized
DEBUG - 2023-12-10 08:41:16 --> UTF-8 Support Enabled
INFO - 2023-12-10 08:41:16 --> Utf8 Class Initialized
INFO - 2023-12-10 08:41:16 --> URI Class Initialized
INFO - 2023-12-10 08:41:16 --> Router Class Initialized
INFO - 2023-12-10 08:41:16 --> Output Class Initialized
INFO - 2023-12-10 08:41:16 --> Security Class Initialized
DEBUG - 2023-12-10 08:41:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-10 08:41:16 --> Input Class Initialized
INFO - 2023-12-10 08:41:16 --> Language Class Initialized
INFO - 2023-12-10 08:41:16 --> Loader Class Initialized
INFO - 2023-12-10 08:41:16 --> Helper loaded: url_helper
INFO - 2023-12-10 08:41:16 --> Helper loaded: file_helper
INFO - 2023-12-10 08:41:16 --> Helper loaded: html_helper
INFO - 2023-12-10 08:41:16 --> Helper loaded: text_helper
INFO - 2023-12-10 08:41:16 --> Helper loaded: form_helper
INFO - 2023-12-10 08:41:16 --> Helper loaded: lang_helper
INFO - 2023-12-10 08:41:16 --> Helper loaded: security_helper
INFO - 2023-12-10 08:41:16 --> Helper loaded: cookie_helper
INFO - 2023-12-10 08:41:16 --> Database Driver Class Initialized
INFO - 2023-12-10 08:41:16 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-10 08:41:16 --> Parser Class Initialized
INFO - 2023-12-10 08:41:16 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-12-10 08:41:16 --> Pagination Class Initialized
INFO - 2023-12-10 08:41:16 --> Form Validation Class Initialized
INFO - 2023-12-10 08:41:16 --> Controller Class Initialized
INFO - 2023-12-10 08:41:16 --> Model Class Initialized
DEBUG - 2023-12-10 08:41:16 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-12-10 08:41:16 --> Session class already loaded. Second attempt ignored.
INFO - 2023-12-10 08:41:16 --> Model Class Initialized
INFO - 2023-12-10 08:41:16 --> Final output sent to browser
DEBUG - 2023-12-10 08:41:16 --> Total execution time: 0.0743
ERROR - 2023-12-10 08:41:29 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-12-10 08:41:29 --> Config Class Initialized
INFO - 2023-12-10 08:41:29 --> Hooks Class Initialized
DEBUG - 2023-12-10 08:41:29 --> UTF-8 Support Enabled
INFO - 2023-12-10 08:41:29 --> Utf8 Class Initialized
INFO - 2023-12-10 08:41:29 --> URI Class Initialized
INFO - 2023-12-10 08:41:29 --> Router Class Initialized
INFO - 2023-12-10 08:41:29 --> Output Class Initialized
INFO - 2023-12-10 08:41:29 --> Security Class Initialized
DEBUG - 2023-12-10 08:41:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-10 08:41:29 --> Input Class Initialized
INFO - 2023-12-10 08:41:29 --> Language Class Initialized
INFO - 2023-12-10 08:41:29 --> Loader Class Initialized
INFO - 2023-12-10 08:41:29 --> Helper loaded: url_helper
INFO - 2023-12-10 08:41:29 --> Helper loaded: file_helper
INFO - 2023-12-10 08:41:29 --> Helper loaded: html_helper
INFO - 2023-12-10 08:41:29 --> Helper loaded: text_helper
INFO - 2023-12-10 08:41:29 --> Helper loaded: form_helper
INFO - 2023-12-10 08:41:29 --> Helper loaded: lang_helper
INFO - 2023-12-10 08:41:29 --> Helper loaded: security_helper
INFO - 2023-12-10 08:41:29 --> Helper loaded: cookie_helper
INFO - 2023-12-10 08:41:29 --> Database Driver Class Initialized
INFO - 2023-12-10 08:41:29 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-10 08:41:29 --> Parser Class Initialized
INFO - 2023-12-10 08:41:29 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-12-10 08:41:29 --> Pagination Class Initialized
INFO - 2023-12-10 08:41:29 --> Form Validation Class Initialized
INFO - 2023-12-10 08:41:29 --> Controller Class Initialized
INFO - 2023-12-10 08:41:29 --> Model Class Initialized
DEBUG - 2023-12-10 08:41:29 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-12-10 08:41:29 --> Session class already loaded. Second attempt ignored.
INFO - 2023-12-10 08:41:29 --> Model Class Initialized
INFO - 2023-12-10 08:41:29 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/stockrequest/stockrequest.php
DEBUG - 2023-12-10 08:41:29 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-12-10 08:41:29 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-12-10 08:41:29 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-12-10 08:41:29 --> Model Class Initialized
INFO - 2023-12-10 08:41:29 --> Model Class Initialized
INFO - 2023-12-10 08:41:29 --> Model Class Initialized
INFO - 2023-12-10 08:41:29 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-12-10 08:41:29 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-12-10 08:41:29 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-12-10 08:41:29 --> Final output sent to browser
DEBUG - 2023-12-10 08:41:29 --> Total execution time: 0.1497
ERROR - 2023-12-10 08:41:30 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-12-10 08:41:30 --> Config Class Initialized
INFO - 2023-12-10 08:41:30 --> Hooks Class Initialized
DEBUG - 2023-12-10 08:41:30 --> UTF-8 Support Enabled
INFO - 2023-12-10 08:41:30 --> Utf8 Class Initialized
INFO - 2023-12-10 08:41:30 --> URI Class Initialized
INFO - 2023-12-10 08:41:30 --> Router Class Initialized
INFO - 2023-12-10 08:41:30 --> Output Class Initialized
INFO - 2023-12-10 08:41:30 --> Security Class Initialized
DEBUG - 2023-12-10 08:41:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-10 08:41:30 --> Input Class Initialized
INFO - 2023-12-10 08:41:30 --> Language Class Initialized
INFO - 2023-12-10 08:41:30 --> Loader Class Initialized
INFO - 2023-12-10 08:41:30 --> Helper loaded: url_helper
INFO - 2023-12-10 08:41:30 --> Helper loaded: file_helper
INFO - 2023-12-10 08:41:30 --> Helper loaded: html_helper
INFO - 2023-12-10 08:41:30 --> Helper loaded: text_helper
INFO - 2023-12-10 08:41:30 --> Helper loaded: form_helper
INFO - 2023-12-10 08:41:30 --> Helper loaded: lang_helper
INFO - 2023-12-10 08:41:30 --> Helper loaded: security_helper
INFO - 2023-12-10 08:41:30 --> Helper loaded: cookie_helper
INFO - 2023-12-10 08:41:30 --> Database Driver Class Initialized
INFO - 2023-12-10 08:41:30 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-10 08:41:30 --> Parser Class Initialized
INFO - 2023-12-10 08:41:30 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-12-10 08:41:30 --> Pagination Class Initialized
INFO - 2023-12-10 08:41:30 --> Form Validation Class Initialized
INFO - 2023-12-10 08:41:30 --> Controller Class Initialized
INFO - 2023-12-10 08:41:30 --> Model Class Initialized
DEBUG - 2023-12-10 08:41:30 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-12-10 08:41:30 --> Session class already loaded. Second attempt ignored.
INFO - 2023-12-10 08:41:30 --> Model Class Initialized
INFO - 2023-12-10 08:41:30 --> Final output sent to browser
DEBUG - 2023-12-10 08:41:30 --> Total execution time: 0.0343
ERROR - 2023-12-10 08:41:34 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-12-10 08:41:34 --> Config Class Initialized
INFO - 2023-12-10 08:41:34 --> Hooks Class Initialized
DEBUG - 2023-12-10 08:41:34 --> UTF-8 Support Enabled
INFO - 2023-12-10 08:41:34 --> Utf8 Class Initialized
INFO - 2023-12-10 08:41:34 --> URI Class Initialized
INFO - 2023-12-10 08:41:34 --> Router Class Initialized
INFO - 2023-12-10 08:41:34 --> Output Class Initialized
INFO - 2023-12-10 08:41:34 --> Security Class Initialized
DEBUG - 2023-12-10 08:41:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-10 08:41:34 --> Input Class Initialized
INFO - 2023-12-10 08:41:34 --> Language Class Initialized
INFO - 2023-12-10 08:41:34 --> Loader Class Initialized
INFO - 2023-12-10 08:41:34 --> Helper loaded: url_helper
INFO - 2023-12-10 08:41:34 --> Helper loaded: file_helper
INFO - 2023-12-10 08:41:34 --> Helper loaded: html_helper
INFO - 2023-12-10 08:41:34 --> Helper loaded: text_helper
INFO - 2023-12-10 08:41:34 --> Helper loaded: form_helper
INFO - 2023-12-10 08:41:34 --> Helper loaded: lang_helper
INFO - 2023-12-10 08:41:34 --> Helper loaded: security_helper
INFO - 2023-12-10 08:41:34 --> Helper loaded: cookie_helper
INFO - 2023-12-10 08:41:34 --> Database Driver Class Initialized
INFO - 2023-12-10 08:41:34 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-10 08:41:34 --> Parser Class Initialized
INFO - 2023-12-10 08:41:34 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-12-10 08:41:34 --> Pagination Class Initialized
INFO - 2023-12-10 08:41:34 --> Form Validation Class Initialized
INFO - 2023-12-10 08:41:34 --> Controller Class Initialized
INFO - 2023-12-10 08:41:34 --> Model Class Initialized
DEBUG - 2023-12-10 08:41:34 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-12-10 08:41:34 --> Session class already loaded. Second attempt ignored.
INFO - 2023-12-10 08:41:34 --> Model Class Initialized
INFO - 2023-12-10 08:41:34 --> Final output sent to browser
DEBUG - 2023-12-10 08:41:34 --> Total execution time: 0.0756
ERROR - 2023-12-10 08:43:30 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-12-10 08:43:30 --> Config Class Initialized
INFO - 2023-12-10 08:43:30 --> Hooks Class Initialized
DEBUG - 2023-12-10 08:43:30 --> UTF-8 Support Enabled
INFO - 2023-12-10 08:43:30 --> Utf8 Class Initialized
INFO - 2023-12-10 08:43:30 --> URI Class Initialized
DEBUG - 2023-12-10 08:43:30 --> No URI present. Default controller set.
INFO - 2023-12-10 08:43:30 --> Router Class Initialized
INFO - 2023-12-10 08:43:30 --> Output Class Initialized
INFO - 2023-12-10 08:43:30 --> Security Class Initialized
DEBUG - 2023-12-10 08:43:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-10 08:43:30 --> Input Class Initialized
INFO - 2023-12-10 08:43:30 --> Language Class Initialized
INFO - 2023-12-10 08:43:30 --> Loader Class Initialized
INFO - 2023-12-10 08:43:30 --> Helper loaded: url_helper
INFO - 2023-12-10 08:43:30 --> Helper loaded: file_helper
INFO - 2023-12-10 08:43:30 --> Helper loaded: html_helper
INFO - 2023-12-10 08:43:30 --> Helper loaded: text_helper
INFO - 2023-12-10 08:43:30 --> Helper loaded: form_helper
INFO - 2023-12-10 08:43:30 --> Helper loaded: lang_helper
INFO - 2023-12-10 08:43:30 --> Helper loaded: security_helper
INFO - 2023-12-10 08:43:30 --> Helper loaded: cookie_helper
INFO - 2023-12-10 08:43:30 --> Database Driver Class Initialized
INFO - 2023-12-10 08:43:30 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-10 08:43:30 --> Parser Class Initialized
INFO - 2023-12-10 08:43:30 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-12-10 08:43:30 --> Pagination Class Initialized
INFO - 2023-12-10 08:43:30 --> Form Validation Class Initialized
INFO - 2023-12-10 08:43:30 --> Controller Class Initialized
INFO - 2023-12-10 08:43:30 --> Model Class Initialized
DEBUG - 2023-12-10 08:43:30 --> Session class already loaded. Second attempt ignored.
ERROR - 2023-12-10 08:43:31 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-12-10 08:43:31 --> Config Class Initialized
INFO - 2023-12-10 08:43:31 --> Hooks Class Initialized
DEBUG - 2023-12-10 08:43:31 --> UTF-8 Support Enabled
INFO - 2023-12-10 08:43:31 --> Utf8 Class Initialized
INFO - 2023-12-10 08:43:31 --> URI Class Initialized
INFO - 2023-12-10 08:43:31 --> Router Class Initialized
INFO - 2023-12-10 08:43:31 --> Output Class Initialized
INFO - 2023-12-10 08:43:31 --> Security Class Initialized
DEBUG - 2023-12-10 08:43:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-10 08:43:31 --> Input Class Initialized
INFO - 2023-12-10 08:43:31 --> Language Class Initialized
INFO - 2023-12-10 08:43:31 --> Loader Class Initialized
INFO - 2023-12-10 08:43:31 --> Helper loaded: url_helper
INFO - 2023-12-10 08:43:31 --> Helper loaded: file_helper
INFO - 2023-12-10 08:43:31 --> Helper loaded: html_helper
INFO - 2023-12-10 08:43:31 --> Helper loaded: text_helper
INFO - 2023-12-10 08:43:31 --> Helper loaded: form_helper
INFO - 2023-12-10 08:43:31 --> Helper loaded: lang_helper
INFO - 2023-12-10 08:43:31 --> Helper loaded: security_helper
INFO - 2023-12-10 08:43:31 --> Helper loaded: cookie_helper
INFO - 2023-12-10 08:43:31 --> Database Driver Class Initialized
INFO - 2023-12-10 08:43:31 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-10 08:43:31 --> Parser Class Initialized
INFO - 2023-12-10 08:43:31 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-12-10 08:43:31 --> Pagination Class Initialized
INFO - 2023-12-10 08:43:31 --> Form Validation Class Initialized
INFO - 2023-12-10 08:43:31 --> Controller Class Initialized
INFO - 2023-12-10 08:43:31 --> Model Class Initialized
DEBUG - 2023-12-10 08:43:31 --> Session class already loaded. Second attempt ignored.
INFO - 2023-12-10 08:43:31 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2023-12-10 08:43:31 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-12-10 08:43:31 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-12-10 08:43:31 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-12-10 08:43:31 --> Model Class Initialized
INFO - 2023-12-10 08:43:31 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-12-10 08:43:31 --> Final output sent to browser
DEBUG - 2023-12-10 08:43:31 --> Total execution time: 0.0331
ERROR - 2023-12-10 10:19:50 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-12-10 10:19:50 --> Config Class Initialized
INFO - 2023-12-10 10:19:50 --> Hooks Class Initialized
DEBUG - 2023-12-10 10:19:50 --> UTF-8 Support Enabled
INFO - 2023-12-10 10:19:50 --> Utf8 Class Initialized
INFO - 2023-12-10 10:19:50 --> URI Class Initialized
DEBUG - 2023-12-10 10:19:50 --> No URI present. Default controller set.
INFO - 2023-12-10 10:19:50 --> Router Class Initialized
INFO - 2023-12-10 10:19:50 --> Output Class Initialized
INFO - 2023-12-10 10:19:50 --> Security Class Initialized
DEBUG - 2023-12-10 10:19:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-10 10:19:50 --> Input Class Initialized
INFO - 2023-12-10 10:19:50 --> Language Class Initialized
INFO - 2023-12-10 10:19:50 --> Loader Class Initialized
INFO - 2023-12-10 10:19:50 --> Helper loaded: url_helper
INFO - 2023-12-10 10:19:50 --> Helper loaded: file_helper
INFO - 2023-12-10 10:19:50 --> Helper loaded: html_helper
INFO - 2023-12-10 10:19:50 --> Helper loaded: text_helper
INFO - 2023-12-10 10:19:50 --> Helper loaded: form_helper
INFO - 2023-12-10 10:19:50 --> Helper loaded: lang_helper
INFO - 2023-12-10 10:19:50 --> Helper loaded: security_helper
INFO - 2023-12-10 10:19:50 --> Helper loaded: cookie_helper
INFO - 2023-12-10 10:19:50 --> Database Driver Class Initialized
INFO - 2023-12-10 10:19:50 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-10 10:19:50 --> Parser Class Initialized
INFO - 2023-12-10 10:19:50 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-12-10 10:19:50 --> Pagination Class Initialized
INFO - 2023-12-10 10:19:50 --> Form Validation Class Initialized
INFO - 2023-12-10 10:19:50 --> Controller Class Initialized
INFO - 2023-12-10 10:19:50 --> Model Class Initialized
DEBUG - 2023-12-10 10:19:50 --> Session class already loaded. Second attempt ignored.
INFO - 2023-12-10 10:19:50 --> Model Class Initialized
DEBUG - 2023-12-10 10:19:50 --> Session class already loaded. Second attempt ignored.
INFO - 2023-12-10 10:19:50 --> Model Class Initialized
INFO - 2023-12-10 10:19:50 --> Model Class Initialized
INFO - 2023-12-10 10:19:50 --> Model Class Initialized
INFO - 2023-12-10 10:19:50 --> Model Class Initialized
DEBUG - 2023-12-10 10:19:50 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-12-10 10:19:50 --> Session class already loaded. Second attempt ignored.
INFO - 2023-12-10 10:19:50 --> Model Class Initialized
INFO - 2023-12-10 10:19:50 --> Model Class Initialized
INFO - 2023-12-10 10:19:51 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-12-10 10:19:51 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-12-10 10:19:51 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-12-10 10:19:51 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-12-10 10:19:51 --> Model Class Initialized
INFO - 2023-12-10 10:19:51 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-12-10 10:19:51 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-12-10 10:19:51 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-12-10 10:19:51 --> Final output sent to browser
DEBUG - 2023-12-10 10:19:51 --> Total execution time: 0.4198
ERROR - 2023-12-10 10:23:02 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-12-10 10:23:02 --> Config Class Initialized
INFO - 2023-12-10 10:23:02 --> Hooks Class Initialized
DEBUG - 2023-12-10 10:23:02 --> UTF-8 Support Enabled
INFO - 2023-12-10 10:23:02 --> Utf8 Class Initialized
INFO - 2023-12-10 10:23:02 --> URI Class Initialized
DEBUG - 2023-12-10 10:23:02 --> No URI present. Default controller set.
INFO - 2023-12-10 10:23:02 --> Router Class Initialized
INFO - 2023-12-10 10:23:02 --> Output Class Initialized
INFO - 2023-12-10 10:23:02 --> Security Class Initialized
DEBUG - 2023-12-10 10:23:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-10 10:23:02 --> Input Class Initialized
INFO - 2023-12-10 10:23:02 --> Language Class Initialized
INFO - 2023-12-10 10:23:02 --> Loader Class Initialized
INFO - 2023-12-10 10:23:02 --> Helper loaded: url_helper
INFO - 2023-12-10 10:23:02 --> Helper loaded: file_helper
INFO - 2023-12-10 10:23:02 --> Helper loaded: html_helper
INFO - 2023-12-10 10:23:02 --> Helper loaded: text_helper
INFO - 2023-12-10 10:23:02 --> Helper loaded: form_helper
INFO - 2023-12-10 10:23:02 --> Helper loaded: lang_helper
INFO - 2023-12-10 10:23:02 --> Helper loaded: security_helper
INFO - 2023-12-10 10:23:02 --> Helper loaded: cookie_helper
INFO - 2023-12-10 10:23:02 --> Database Driver Class Initialized
INFO - 2023-12-10 10:23:02 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-10 10:23:02 --> Parser Class Initialized
INFO - 2023-12-10 10:23:02 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-12-10 10:23:02 --> Pagination Class Initialized
INFO - 2023-12-10 10:23:02 --> Form Validation Class Initialized
INFO - 2023-12-10 10:23:02 --> Controller Class Initialized
INFO - 2023-12-10 10:23:02 --> Model Class Initialized
DEBUG - 2023-12-10 10:23:02 --> Session class already loaded. Second attempt ignored.
INFO - 2023-12-10 10:23:02 --> Model Class Initialized
DEBUG - 2023-12-10 10:23:02 --> Session class already loaded. Second attempt ignored.
INFO - 2023-12-10 10:23:02 --> Model Class Initialized
INFO - 2023-12-10 10:23:02 --> Model Class Initialized
INFO - 2023-12-10 10:23:02 --> Model Class Initialized
INFO - 2023-12-10 10:23:02 --> Model Class Initialized
DEBUG - 2023-12-10 10:23:02 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-12-10 10:23:02 --> Session class already loaded. Second attempt ignored.
INFO - 2023-12-10 10:23:02 --> Model Class Initialized
INFO - 2023-12-10 10:23:02 --> Model Class Initialized
INFO - 2023-12-10 10:23:02 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-12-10 10:23:02 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-12-10 10:23:02 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-12-10 10:23:02 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-12-10 10:23:02 --> Model Class Initialized
INFO - 2023-12-10 10:23:02 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-12-10 10:23:02 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-12-10 10:23:02 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-12-10 10:23:02 --> Final output sent to browser
DEBUG - 2023-12-10 10:23:02 --> Total execution time: 0.3854
ERROR - 2023-12-10 10:23:06 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-12-10 10:23:06 --> Config Class Initialized
INFO - 2023-12-10 10:23:06 --> Hooks Class Initialized
DEBUG - 2023-12-10 10:23:06 --> UTF-8 Support Enabled
INFO - 2023-12-10 10:23:06 --> Utf8 Class Initialized
INFO - 2023-12-10 10:23:06 --> URI Class Initialized
INFO - 2023-12-10 10:23:06 --> Router Class Initialized
INFO - 2023-12-10 10:23:06 --> Output Class Initialized
INFO - 2023-12-10 10:23:06 --> Security Class Initialized
DEBUG - 2023-12-10 10:23:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-10 10:23:06 --> Input Class Initialized
INFO - 2023-12-10 10:23:06 --> Language Class Initialized
INFO - 2023-12-10 10:23:06 --> Loader Class Initialized
INFO - 2023-12-10 10:23:06 --> Helper loaded: url_helper
INFO - 2023-12-10 10:23:06 --> Helper loaded: file_helper
INFO - 2023-12-10 10:23:06 --> Helper loaded: html_helper
INFO - 2023-12-10 10:23:06 --> Helper loaded: text_helper
INFO - 2023-12-10 10:23:06 --> Helper loaded: form_helper
INFO - 2023-12-10 10:23:06 --> Helper loaded: lang_helper
INFO - 2023-12-10 10:23:06 --> Helper loaded: security_helper
INFO - 2023-12-10 10:23:06 --> Helper loaded: cookie_helper
INFO - 2023-12-10 10:23:06 --> Database Driver Class Initialized
INFO - 2023-12-10 10:23:06 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-10 10:23:06 --> Parser Class Initialized
INFO - 2023-12-10 10:23:06 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-12-10 10:23:06 --> Pagination Class Initialized
INFO - 2023-12-10 10:23:06 --> Form Validation Class Initialized
INFO - 2023-12-10 10:23:06 --> Controller Class Initialized
DEBUG - 2023-12-10 10:23:06 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-12-10 10:23:06 --> Session class already loaded. Second attempt ignored.
INFO - 2023-12-10 10:23:06 --> Model Class Initialized
INFO - 2023-12-10 10:23:06 --> Model Class Initialized
DEBUG - 2023-12-10 10:23:06 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-12-10 10:23:06 --> Session class already loaded. Second attempt ignored.
INFO - 2023-12-10 10:23:06 --> Model Class Initialized
DEBUG - 2023-12-10 10:23:06 --> Session class already loaded. Second attempt ignored.
INFO - 2023-12-10 10:23:06 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/gst/list.php
DEBUG - 2023-12-10 10:23:06 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-12-10 10:23:06 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-12-10 10:23:06 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-12-10 10:23:06 --> Model Class Initialized
INFO - 2023-12-10 10:23:06 --> Model Class Initialized
INFO - 2023-12-10 10:23:06 --> Model Class Initialized
INFO - 2023-12-10 10:23:06 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-12-10 10:23:06 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-12-10 10:23:06 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-12-10 10:23:06 --> Final output sent to browser
DEBUG - 2023-12-10 10:23:06 --> Total execution time: 0.2209
ERROR - 2023-12-10 10:23:11 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-12-10 10:23:11 --> Config Class Initialized
INFO - 2023-12-10 10:23:11 --> Hooks Class Initialized
DEBUG - 2023-12-10 10:23:11 --> UTF-8 Support Enabled
INFO - 2023-12-10 10:23:11 --> Utf8 Class Initialized
INFO - 2023-12-10 10:23:11 --> URI Class Initialized
INFO - 2023-12-10 10:23:11 --> Router Class Initialized
INFO - 2023-12-10 10:23:11 --> Output Class Initialized
INFO - 2023-12-10 10:23:11 --> Security Class Initialized
DEBUG - 2023-12-10 10:23:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-10 10:23:11 --> Input Class Initialized
INFO - 2023-12-10 10:23:11 --> Language Class Initialized
INFO - 2023-12-10 10:23:11 --> Loader Class Initialized
INFO - 2023-12-10 10:23:11 --> Helper loaded: url_helper
INFO - 2023-12-10 10:23:11 --> Helper loaded: file_helper
INFO - 2023-12-10 10:23:11 --> Helper loaded: html_helper
INFO - 2023-12-10 10:23:11 --> Helper loaded: text_helper
INFO - 2023-12-10 10:23:11 --> Helper loaded: form_helper
INFO - 2023-12-10 10:23:11 --> Helper loaded: lang_helper
INFO - 2023-12-10 10:23:11 --> Helper loaded: security_helper
INFO - 2023-12-10 10:23:11 --> Helper loaded: cookie_helper
INFO - 2023-12-10 10:23:11 --> Database Driver Class Initialized
INFO - 2023-12-10 10:23:11 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-10 10:23:11 --> Parser Class Initialized
INFO - 2023-12-10 10:23:11 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-12-10 10:23:11 --> Pagination Class Initialized
INFO - 2023-12-10 10:23:11 --> Form Validation Class Initialized
INFO - 2023-12-10 10:23:11 --> Controller Class Initialized
INFO - 2023-12-10 10:23:11 --> Model Class Initialized
DEBUG - 2023-12-10 10:23:11 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-12-10 10:23:11 --> Session class already loaded. Second attempt ignored.
INFO - 2023-12-10 10:23:11 --> Model Class Initialized
DEBUG - 2023-12-10 10:23:11 --> Session class already loaded. Second attempt ignored.
INFO - 2023-12-10 10:23:11 --> Model Class Initialized
INFO - 2023-12-10 10:23:11 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice.php
DEBUG - 2023-12-10 10:23:11 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-12-10 10:23:11 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-12-10 10:23:11 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-12-10 10:23:11 --> Model Class Initialized
INFO - 2023-12-10 10:23:11 --> Model Class Initialized
INFO - 2023-12-10 10:23:11 --> Model Class Initialized
INFO - 2023-12-10 10:23:11 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-12-10 10:23:11 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-12-10 10:23:11 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-12-10 10:23:11 --> Final output sent to browser
DEBUG - 2023-12-10 10:23:11 --> Total execution time: 0.2154
ERROR - 2023-12-10 10:23:12 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-12-10 10:23:12 --> Config Class Initialized
INFO - 2023-12-10 10:23:12 --> Hooks Class Initialized
DEBUG - 2023-12-10 10:23:12 --> UTF-8 Support Enabled
INFO - 2023-12-10 10:23:12 --> Utf8 Class Initialized
INFO - 2023-12-10 10:23:12 --> URI Class Initialized
INFO - 2023-12-10 10:23:12 --> Router Class Initialized
INFO - 2023-12-10 10:23:12 --> Output Class Initialized
INFO - 2023-12-10 10:23:12 --> Security Class Initialized
DEBUG - 2023-12-10 10:23:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-10 10:23:12 --> Input Class Initialized
INFO - 2023-12-10 10:23:12 --> Language Class Initialized
INFO - 2023-12-10 10:23:12 --> Loader Class Initialized
INFO - 2023-12-10 10:23:12 --> Helper loaded: url_helper
INFO - 2023-12-10 10:23:12 --> Helper loaded: file_helper
INFO - 2023-12-10 10:23:12 --> Helper loaded: html_helper
INFO - 2023-12-10 10:23:12 --> Helper loaded: text_helper
INFO - 2023-12-10 10:23:12 --> Helper loaded: form_helper
INFO - 2023-12-10 10:23:12 --> Helper loaded: lang_helper
INFO - 2023-12-10 10:23:12 --> Helper loaded: security_helper
INFO - 2023-12-10 10:23:12 --> Helper loaded: cookie_helper
INFO - 2023-12-10 10:23:12 --> Database Driver Class Initialized
INFO - 2023-12-10 10:23:12 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-10 10:23:12 --> Parser Class Initialized
INFO - 2023-12-10 10:23:12 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-12-10 10:23:12 --> Pagination Class Initialized
INFO - 2023-12-10 10:23:12 --> Form Validation Class Initialized
INFO - 2023-12-10 10:23:12 --> Controller Class Initialized
INFO - 2023-12-10 10:23:12 --> Model Class Initialized
DEBUG - 2023-12-10 10:23:12 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-12-10 10:23:12 --> Session class already loaded. Second attempt ignored.
INFO - 2023-12-10 10:23:12 --> Model Class Initialized
DEBUG - 2023-12-10 10:23:12 --> Session class already loaded. Second attempt ignored.
INFO - 2023-12-10 10:23:12 --> Model Class Initialized
INFO - 2023-12-10 10:23:12 --> Final output sent to browser
DEBUG - 2023-12-10 10:23:12 --> Total execution time: 0.0637
ERROR - 2023-12-10 10:23:41 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-12-10 10:23:41 --> Config Class Initialized
INFO - 2023-12-10 10:23:41 --> Hooks Class Initialized
DEBUG - 2023-12-10 10:23:41 --> UTF-8 Support Enabled
INFO - 2023-12-10 10:23:41 --> Utf8 Class Initialized
INFO - 2023-12-10 10:23:41 --> URI Class Initialized
DEBUG - 2023-12-10 10:23:41 --> No URI present. Default controller set.
INFO - 2023-12-10 10:23:41 --> Router Class Initialized
INFO - 2023-12-10 10:23:41 --> Output Class Initialized
INFO - 2023-12-10 10:23:41 --> Security Class Initialized
DEBUG - 2023-12-10 10:23:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-10 10:23:41 --> Input Class Initialized
INFO - 2023-12-10 10:23:41 --> Language Class Initialized
INFO - 2023-12-10 10:23:41 --> Loader Class Initialized
INFO - 2023-12-10 10:23:41 --> Helper loaded: url_helper
INFO - 2023-12-10 10:23:41 --> Helper loaded: file_helper
INFO - 2023-12-10 10:23:41 --> Helper loaded: html_helper
INFO - 2023-12-10 10:23:41 --> Helper loaded: text_helper
INFO - 2023-12-10 10:23:41 --> Helper loaded: form_helper
INFO - 2023-12-10 10:23:41 --> Helper loaded: lang_helper
INFO - 2023-12-10 10:23:41 --> Helper loaded: security_helper
INFO - 2023-12-10 10:23:41 --> Helper loaded: cookie_helper
INFO - 2023-12-10 10:23:41 --> Database Driver Class Initialized
INFO - 2023-12-10 10:23:41 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-10 10:23:41 --> Parser Class Initialized
INFO - 2023-12-10 10:23:41 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-12-10 10:23:41 --> Pagination Class Initialized
INFO - 2023-12-10 10:23:41 --> Form Validation Class Initialized
INFO - 2023-12-10 10:23:41 --> Controller Class Initialized
INFO - 2023-12-10 10:23:41 --> Model Class Initialized
DEBUG - 2023-12-10 10:23:41 --> Session class already loaded. Second attempt ignored.
INFO - 2023-12-10 10:23:41 --> Model Class Initialized
DEBUG - 2023-12-10 10:23:41 --> Session class already loaded. Second attempt ignored.
INFO - 2023-12-10 10:23:41 --> Model Class Initialized
INFO - 2023-12-10 10:23:41 --> Model Class Initialized
INFO - 2023-12-10 10:23:41 --> Model Class Initialized
INFO - 2023-12-10 10:23:41 --> Model Class Initialized
DEBUG - 2023-12-10 10:23:41 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-12-10 10:23:41 --> Session class already loaded. Second attempt ignored.
INFO - 2023-12-10 10:23:41 --> Model Class Initialized
INFO - 2023-12-10 10:23:41 --> Model Class Initialized
INFO - 2023-12-10 10:23:41 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-12-10 10:23:41 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-12-10 10:23:41 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-12-10 10:23:41 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-12-10 10:23:41 --> Model Class Initialized
INFO - 2023-12-10 10:23:41 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-12-10 10:23:41 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-12-10 10:23:41 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-12-10 10:23:41 --> Final output sent to browser
DEBUG - 2023-12-10 10:23:41 --> Total execution time: 0.4179
ERROR - 2023-12-10 10:23:53 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-12-10 10:23:53 --> Config Class Initialized
INFO - 2023-12-10 10:23:53 --> Hooks Class Initialized
DEBUG - 2023-12-10 10:23:53 --> UTF-8 Support Enabled
INFO - 2023-12-10 10:23:53 --> Utf8 Class Initialized
INFO - 2023-12-10 10:23:53 --> URI Class Initialized
INFO - 2023-12-10 10:23:53 --> Router Class Initialized
INFO - 2023-12-10 10:23:53 --> Output Class Initialized
INFO - 2023-12-10 10:23:53 --> Security Class Initialized
DEBUG - 2023-12-10 10:23:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-10 10:23:53 --> Input Class Initialized
INFO - 2023-12-10 10:23:53 --> Language Class Initialized
INFO - 2023-12-10 10:23:53 --> Loader Class Initialized
INFO - 2023-12-10 10:23:53 --> Helper loaded: url_helper
INFO - 2023-12-10 10:23:53 --> Helper loaded: file_helper
INFO - 2023-12-10 10:23:53 --> Helper loaded: html_helper
INFO - 2023-12-10 10:23:53 --> Helper loaded: text_helper
INFO - 2023-12-10 10:23:53 --> Helper loaded: form_helper
INFO - 2023-12-10 10:23:53 --> Helper loaded: lang_helper
INFO - 2023-12-10 10:23:53 --> Helper loaded: security_helper
INFO - 2023-12-10 10:23:53 --> Helper loaded: cookie_helper
INFO - 2023-12-10 10:23:53 --> Database Driver Class Initialized
INFO - 2023-12-10 10:23:53 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-10 10:23:53 --> Parser Class Initialized
INFO - 2023-12-10 10:23:53 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-12-10 10:23:53 --> Pagination Class Initialized
INFO - 2023-12-10 10:23:53 --> Form Validation Class Initialized
INFO - 2023-12-10 10:23:53 --> Controller Class Initialized
INFO - 2023-12-10 10:23:53 --> Model Class Initialized
DEBUG - 2023-12-10 10:23:53 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-12-10 10:23:53 --> Session class already loaded. Second attempt ignored.
INFO - 2023-12-10 10:23:53 --> Model Class Initialized
DEBUG - 2023-12-10 10:23:53 --> Session class already loaded. Second attempt ignored.
INFO - 2023-12-10 10:23:53 --> Model Class Initialized
INFO - 2023-12-10 10:23:53 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice.php
DEBUG - 2023-12-10 10:23:53 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-12-10 10:23:53 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-12-10 10:23:53 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-12-10 10:23:53 --> Model Class Initialized
INFO - 2023-12-10 10:23:53 --> Model Class Initialized
INFO - 2023-12-10 10:23:53 --> Model Class Initialized
INFO - 2023-12-10 10:23:53 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-12-10 10:23:53 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-12-10 10:23:53 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-12-10 10:23:53 --> Final output sent to browser
DEBUG - 2023-12-10 10:23:53 --> Total execution time: 0.2044
ERROR - 2023-12-10 10:23:53 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-12-10 10:23:53 --> Config Class Initialized
INFO - 2023-12-10 10:23:53 --> Hooks Class Initialized
DEBUG - 2023-12-10 10:23:53 --> UTF-8 Support Enabled
INFO - 2023-12-10 10:23:53 --> Utf8 Class Initialized
INFO - 2023-12-10 10:23:53 --> URI Class Initialized
INFO - 2023-12-10 10:23:53 --> Router Class Initialized
INFO - 2023-12-10 10:23:53 --> Output Class Initialized
INFO - 2023-12-10 10:23:53 --> Security Class Initialized
DEBUG - 2023-12-10 10:23:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-10 10:23:53 --> Input Class Initialized
INFO - 2023-12-10 10:23:53 --> Language Class Initialized
INFO - 2023-12-10 10:23:53 --> Loader Class Initialized
INFO - 2023-12-10 10:23:53 --> Helper loaded: url_helper
INFO - 2023-12-10 10:23:53 --> Helper loaded: file_helper
INFO - 2023-12-10 10:23:53 --> Helper loaded: html_helper
INFO - 2023-12-10 10:23:53 --> Helper loaded: text_helper
INFO - 2023-12-10 10:23:53 --> Helper loaded: form_helper
INFO - 2023-12-10 10:23:53 --> Helper loaded: lang_helper
INFO - 2023-12-10 10:23:53 --> Helper loaded: security_helper
INFO - 2023-12-10 10:23:53 --> Helper loaded: cookie_helper
INFO - 2023-12-10 10:23:53 --> Database Driver Class Initialized
INFO - 2023-12-10 10:23:53 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-10 10:23:53 --> Parser Class Initialized
INFO - 2023-12-10 10:23:53 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-12-10 10:23:53 --> Pagination Class Initialized
INFO - 2023-12-10 10:23:53 --> Form Validation Class Initialized
INFO - 2023-12-10 10:23:53 --> Controller Class Initialized
INFO - 2023-12-10 10:23:53 --> Model Class Initialized
DEBUG - 2023-12-10 10:23:53 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-12-10 10:23:53 --> Session class already loaded. Second attempt ignored.
INFO - 2023-12-10 10:23:53 --> Model Class Initialized
DEBUG - 2023-12-10 10:23:53 --> Session class already loaded. Second attempt ignored.
INFO - 2023-12-10 10:23:53 --> Model Class Initialized
INFO - 2023-12-10 10:23:53 --> Final output sent to browser
DEBUG - 2023-12-10 10:23:53 --> Total execution time: 0.0577
ERROR - 2023-12-10 10:23:58 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-12-10 10:23:58 --> Config Class Initialized
INFO - 2023-12-10 10:23:58 --> Hooks Class Initialized
DEBUG - 2023-12-10 10:23:58 --> UTF-8 Support Enabled
INFO - 2023-12-10 10:23:58 --> Utf8 Class Initialized
INFO - 2023-12-10 10:23:58 --> URI Class Initialized
INFO - 2023-12-10 10:23:58 --> Router Class Initialized
INFO - 2023-12-10 10:23:58 --> Output Class Initialized
INFO - 2023-12-10 10:23:58 --> Security Class Initialized
DEBUG - 2023-12-10 10:23:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-10 10:23:58 --> Input Class Initialized
INFO - 2023-12-10 10:23:58 --> Language Class Initialized
INFO - 2023-12-10 10:23:58 --> Loader Class Initialized
INFO - 2023-12-10 10:23:58 --> Helper loaded: url_helper
INFO - 2023-12-10 10:23:58 --> Helper loaded: file_helper
INFO - 2023-12-10 10:23:58 --> Helper loaded: html_helper
INFO - 2023-12-10 10:23:58 --> Helper loaded: text_helper
INFO - 2023-12-10 10:23:58 --> Helper loaded: form_helper
INFO - 2023-12-10 10:23:58 --> Helper loaded: lang_helper
INFO - 2023-12-10 10:23:58 --> Helper loaded: security_helper
INFO - 2023-12-10 10:23:58 --> Helper loaded: cookie_helper
INFO - 2023-12-10 10:23:58 --> Database Driver Class Initialized
INFO - 2023-12-10 10:23:58 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-10 10:23:58 --> Parser Class Initialized
INFO - 2023-12-10 10:23:58 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-12-10 10:23:58 --> Pagination Class Initialized
INFO - 2023-12-10 10:23:58 --> Form Validation Class Initialized
INFO - 2023-12-10 10:23:58 --> Controller Class Initialized
INFO - 2023-12-10 10:23:58 --> Model Class Initialized
DEBUG - 2023-12-10 10:23:58 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-12-10 10:23:58 --> Session class already loaded. Second attempt ignored.
INFO - 2023-12-10 10:23:58 --> Model Class Initialized
DEBUG - 2023-12-10 10:23:58 --> Session class already loaded. Second attempt ignored.
INFO - 2023-12-10 10:23:58 --> Model Class Initialized
INFO - 2023-12-10 10:23:59 --> Final output sent to browser
DEBUG - 2023-12-10 10:23:59 --> Total execution time: 0.8958
ERROR - 2023-12-10 13:08:02 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-12-10 13:08:02 --> Config Class Initialized
INFO - 2023-12-10 13:08:02 --> Hooks Class Initialized
DEBUG - 2023-12-10 13:08:02 --> UTF-8 Support Enabled
INFO - 2023-12-10 13:08:02 --> Utf8 Class Initialized
INFO - 2023-12-10 13:08:02 --> URI Class Initialized
DEBUG - 2023-12-10 13:08:02 --> No URI present. Default controller set.
INFO - 2023-12-10 13:08:02 --> Router Class Initialized
INFO - 2023-12-10 13:08:02 --> Output Class Initialized
INFO - 2023-12-10 13:08:02 --> Security Class Initialized
DEBUG - 2023-12-10 13:08:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-10 13:08:02 --> Input Class Initialized
INFO - 2023-12-10 13:08:02 --> Language Class Initialized
INFO - 2023-12-10 13:08:02 --> Loader Class Initialized
INFO - 2023-12-10 13:08:02 --> Helper loaded: url_helper
INFO - 2023-12-10 13:08:02 --> Helper loaded: file_helper
INFO - 2023-12-10 13:08:02 --> Helper loaded: html_helper
INFO - 2023-12-10 13:08:02 --> Helper loaded: text_helper
INFO - 2023-12-10 13:08:02 --> Helper loaded: form_helper
INFO - 2023-12-10 13:08:02 --> Helper loaded: lang_helper
INFO - 2023-12-10 13:08:02 --> Helper loaded: security_helper
INFO - 2023-12-10 13:08:02 --> Helper loaded: cookie_helper
INFO - 2023-12-10 13:08:02 --> Database Driver Class Initialized
INFO - 2023-12-10 13:08:02 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-10 13:08:02 --> Parser Class Initialized
INFO - 2023-12-10 13:08:02 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-12-10 13:08:02 --> Pagination Class Initialized
INFO - 2023-12-10 13:08:02 --> Form Validation Class Initialized
INFO - 2023-12-10 13:08:02 --> Controller Class Initialized
INFO - 2023-12-10 13:08:02 --> Model Class Initialized
DEBUG - 2023-12-10 13:08:02 --> Session class already loaded. Second attempt ignored.
ERROR - 2023-12-10 13:08:02 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-12-10 13:08:02 --> Config Class Initialized
INFO - 2023-12-10 13:08:02 --> Hooks Class Initialized
DEBUG - 2023-12-10 13:08:02 --> UTF-8 Support Enabled
INFO - 2023-12-10 13:08:02 --> Utf8 Class Initialized
INFO - 2023-12-10 13:08:02 --> URI Class Initialized
INFO - 2023-12-10 13:08:02 --> Router Class Initialized
INFO - 2023-12-10 13:08:02 --> Output Class Initialized
INFO - 2023-12-10 13:08:02 --> Security Class Initialized
DEBUG - 2023-12-10 13:08:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-10 13:08:02 --> Input Class Initialized
INFO - 2023-12-10 13:08:02 --> Language Class Initialized
INFO - 2023-12-10 13:08:02 --> Loader Class Initialized
INFO - 2023-12-10 13:08:02 --> Helper loaded: url_helper
INFO - 2023-12-10 13:08:02 --> Helper loaded: file_helper
INFO - 2023-12-10 13:08:02 --> Helper loaded: html_helper
INFO - 2023-12-10 13:08:02 --> Helper loaded: text_helper
INFO - 2023-12-10 13:08:02 --> Helper loaded: form_helper
INFO - 2023-12-10 13:08:02 --> Helper loaded: lang_helper
INFO - 2023-12-10 13:08:02 --> Helper loaded: security_helper
INFO - 2023-12-10 13:08:02 --> Helper loaded: cookie_helper
INFO - 2023-12-10 13:08:02 --> Database Driver Class Initialized
INFO - 2023-12-10 13:08:02 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-10 13:08:02 --> Parser Class Initialized
INFO - 2023-12-10 13:08:02 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-12-10 13:08:02 --> Pagination Class Initialized
INFO - 2023-12-10 13:08:02 --> Form Validation Class Initialized
INFO - 2023-12-10 13:08:02 --> Controller Class Initialized
INFO - 2023-12-10 13:08:02 --> Model Class Initialized
DEBUG - 2023-12-10 13:08:02 --> Session class already loaded. Second attempt ignored.
INFO - 2023-12-10 13:08:02 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2023-12-10 13:08:02 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-12-10 13:08:02 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-12-10 13:08:02 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-12-10 13:08:02 --> Model Class Initialized
INFO - 2023-12-10 13:08:02 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-12-10 13:08:02 --> Final output sent to browser
DEBUG - 2023-12-10 13:08:02 --> Total execution time: 0.0326
ERROR - 2023-12-10 13:08:05 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-12-10 13:08:05 --> Config Class Initialized
INFO - 2023-12-10 13:08:05 --> Hooks Class Initialized
DEBUG - 2023-12-10 13:08:05 --> UTF-8 Support Enabled
INFO - 2023-12-10 13:08:05 --> Utf8 Class Initialized
INFO - 2023-12-10 13:08:05 --> URI Class Initialized
INFO - 2023-12-10 13:08:05 --> Router Class Initialized
INFO - 2023-12-10 13:08:05 --> Output Class Initialized
INFO - 2023-12-10 13:08:05 --> Security Class Initialized
DEBUG - 2023-12-10 13:08:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-10 13:08:05 --> Input Class Initialized
INFO - 2023-12-10 13:08:05 --> Language Class Initialized
INFO - 2023-12-10 13:08:05 --> Loader Class Initialized
INFO - 2023-12-10 13:08:05 --> Helper loaded: url_helper
INFO - 2023-12-10 13:08:05 --> Helper loaded: file_helper
INFO - 2023-12-10 13:08:05 --> Helper loaded: html_helper
INFO - 2023-12-10 13:08:05 --> Helper loaded: text_helper
INFO - 2023-12-10 13:08:05 --> Helper loaded: form_helper
INFO - 2023-12-10 13:08:05 --> Helper loaded: lang_helper
INFO - 2023-12-10 13:08:05 --> Helper loaded: security_helper
INFO - 2023-12-10 13:08:05 --> Helper loaded: cookie_helper
INFO - 2023-12-10 13:08:05 --> Database Driver Class Initialized
INFO - 2023-12-10 13:08:05 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-10 13:08:05 --> Parser Class Initialized
INFO - 2023-12-10 13:08:05 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-12-10 13:08:05 --> Pagination Class Initialized
INFO - 2023-12-10 13:08:05 --> Form Validation Class Initialized
INFO - 2023-12-10 13:08:05 --> Controller Class Initialized
INFO - 2023-12-10 13:08:05 --> Model Class Initialized
DEBUG - 2023-12-10 13:08:05 --> Session class already loaded. Second attempt ignored.
INFO - 2023-12-10 13:08:05 --> Model Class Initialized
INFO - 2023-12-10 13:08:05 --> Final output sent to browser
DEBUG - 2023-12-10 13:08:05 --> Total execution time: 0.0186
ERROR - 2023-12-10 13:08:05 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-12-10 13:08:05 --> Config Class Initialized
INFO - 2023-12-10 13:08:05 --> Hooks Class Initialized
DEBUG - 2023-12-10 13:08:05 --> UTF-8 Support Enabled
INFO - 2023-12-10 13:08:05 --> Utf8 Class Initialized
INFO - 2023-12-10 13:08:05 --> URI Class Initialized
DEBUG - 2023-12-10 13:08:05 --> No URI present. Default controller set.
INFO - 2023-12-10 13:08:05 --> Router Class Initialized
INFO - 2023-12-10 13:08:05 --> Output Class Initialized
INFO - 2023-12-10 13:08:05 --> Security Class Initialized
DEBUG - 2023-12-10 13:08:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-10 13:08:05 --> Input Class Initialized
INFO - 2023-12-10 13:08:05 --> Language Class Initialized
INFO - 2023-12-10 13:08:05 --> Loader Class Initialized
INFO - 2023-12-10 13:08:05 --> Helper loaded: url_helper
INFO - 2023-12-10 13:08:05 --> Helper loaded: file_helper
INFO - 2023-12-10 13:08:05 --> Helper loaded: html_helper
INFO - 2023-12-10 13:08:05 --> Helper loaded: text_helper
INFO - 2023-12-10 13:08:05 --> Helper loaded: form_helper
INFO - 2023-12-10 13:08:05 --> Helper loaded: lang_helper
INFO - 2023-12-10 13:08:05 --> Helper loaded: security_helper
INFO - 2023-12-10 13:08:05 --> Helper loaded: cookie_helper
INFO - 2023-12-10 13:08:05 --> Database Driver Class Initialized
INFO - 2023-12-10 13:08:05 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-10 13:08:05 --> Parser Class Initialized
INFO - 2023-12-10 13:08:05 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-12-10 13:08:05 --> Pagination Class Initialized
INFO - 2023-12-10 13:08:05 --> Form Validation Class Initialized
INFO - 2023-12-10 13:08:05 --> Controller Class Initialized
INFO - 2023-12-10 13:08:05 --> Model Class Initialized
DEBUG - 2023-12-10 13:08:05 --> Session class already loaded. Second attempt ignored.
INFO - 2023-12-10 13:08:05 --> Model Class Initialized
DEBUG - 2023-12-10 13:08:05 --> Session class already loaded. Second attempt ignored.
INFO - 2023-12-10 13:08:05 --> Model Class Initialized
INFO - 2023-12-10 13:08:05 --> Model Class Initialized
INFO - 2023-12-10 13:08:05 --> Model Class Initialized
INFO - 2023-12-10 13:08:05 --> Model Class Initialized
DEBUG - 2023-12-10 13:08:05 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-12-10 13:08:05 --> Session class already loaded. Second attempt ignored.
INFO - 2023-12-10 13:08:05 --> Model Class Initialized
INFO - 2023-12-10 13:08:05 --> Model Class Initialized
INFO - 2023-12-10 13:08:05 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-12-10 13:08:05 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-12-10 13:08:05 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-12-10 13:08:05 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-12-10 13:08:05 --> Model Class Initialized
INFO - 2023-12-10 13:08:05 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-12-10 13:08:05 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-12-10 13:08:05 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-12-10 13:08:05 --> Final output sent to browser
DEBUG - 2023-12-10 13:08:05 --> Total execution time: 0.3906
ERROR - 2023-12-10 13:08:06 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-12-10 13:08:06 --> Config Class Initialized
INFO - 2023-12-10 13:08:06 --> Hooks Class Initialized
DEBUG - 2023-12-10 13:08:06 --> UTF-8 Support Enabled
INFO - 2023-12-10 13:08:06 --> Utf8 Class Initialized
INFO - 2023-12-10 13:08:06 --> URI Class Initialized
INFO - 2023-12-10 13:08:06 --> Router Class Initialized
INFO - 2023-12-10 13:08:06 --> Output Class Initialized
INFO - 2023-12-10 13:08:06 --> Security Class Initialized
DEBUG - 2023-12-10 13:08:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-10 13:08:06 --> Input Class Initialized
INFO - 2023-12-10 13:08:06 --> Language Class Initialized
INFO - 2023-12-10 13:08:06 --> Loader Class Initialized
INFO - 2023-12-10 13:08:06 --> Helper loaded: url_helper
INFO - 2023-12-10 13:08:06 --> Helper loaded: file_helper
INFO - 2023-12-10 13:08:06 --> Helper loaded: html_helper
INFO - 2023-12-10 13:08:06 --> Helper loaded: text_helper
INFO - 2023-12-10 13:08:06 --> Helper loaded: form_helper
INFO - 2023-12-10 13:08:06 --> Helper loaded: lang_helper
INFO - 2023-12-10 13:08:06 --> Helper loaded: security_helper
INFO - 2023-12-10 13:08:06 --> Helper loaded: cookie_helper
INFO - 2023-12-10 13:08:06 --> Database Driver Class Initialized
INFO - 2023-12-10 13:08:06 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-10 13:08:06 --> Parser Class Initialized
INFO - 2023-12-10 13:08:06 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-12-10 13:08:06 --> Pagination Class Initialized
INFO - 2023-12-10 13:08:06 --> Form Validation Class Initialized
INFO - 2023-12-10 13:08:06 --> Controller Class Initialized
DEBUG - 2023-12-10 13:08:06 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-12-10 13:08:06 --> Session class already loaded. Second attempt ignored.
INFO - 2023-12-10 13:08:06 --> Model Class Initialized
INFO - 2023-12-10 13:08:06 --> Final output sent to browser
DEBUG - 2023-12-10 13:08:06 --> Total execution time: 0.0124
ERROR - 2023-12-10 13:08:22 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-12-10 13:08:22 --> Config Class Initialized
INFO - 2023-12-10 13:08:22 --> Hooks Class Initialized
DEBUG - 2023-12-10 13:08:22 --> UTF-8 Support Enabled
INFO - 2023-12-10 13:08:22 --> Utf8 Class Initialized
INFO - 2023-12-10 13:08:22 --> URI Class Initialized
DEBUG - 2023-12-10 13:08:22 --> No URI present. Default controller set.
INFO - 2023-12-10 13:08:22 --> Router Class Initialized
INFO - 2023-12-10 13:08:22 --> Output Class Initialized
INFO - 2023-12-10 13:08:22 --> Security Class Initialized
DEBUG - 2023-12-10 13:08:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-10 13:08:22 --> Input Class Initialized
INFO - 2023-12-10 13:08:22 --> Language Class Initialized
INFO - 2023-12-10 13:08:22 --> Loader Class Initialized
INFO - 2023-12-10 13:08:22 --> Helper loaded: url_helper
INFO - 2023-12-10 13:08:22 --> Helper loaded: file_helper
INFO - 2023-12-10 13:08:22 --> Helper loaded: html_helper
INFO - 2023-12-10 13:08:22 --> Helper loaded: text_helper
INFO - 2023-12-10 13:08:22 --> Helper loaded: form_helper
INFO - 2023-12-10 13:08:22 --> Helper loaded: lang_helper
INFO - 2023-12-10 13:08:22 --> Helper loaded: security_helper
INFO - 2023-12-10 13:08:22 --> Helper loaded: cookie_helper
INFO - 2023-12-10 13:08:22 --> Database Driver Class Initialized
INFO - 2023-12-10 13:08:22 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-10 13:08:22 --> Parser Class Initialized
INFO - 2023-12-10 13:08:22 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-12-10 13:08:22 --> Pagination Class Initialized
INFO - 2023-12-10 13:08:22 --> Form Validation Class Initialized
INFO - 2023-12-10 13:08:22 --> Controller Class Initialized
INFO - 2023-12-10 13:08:22 --> Model Class Initialized
DEBUG - 2023-12-10 13:08:22 --> Session class already loaded. Second attempt ignored.
INFO - 2023-12-10 13:08:22 --> Model Class Initialized
DEBUG - 2023-12-10 13:08:22 --> Session class already loaded. Second attempt ignored.
INFO - 2023-12-10 13:08:22 --> Model Class Initialized
INFO - 2023-12-10 13:08:22 --> Model Class Initialized
INFO - 2023-12-10 13:08:22 --> Model Class Initialized
INFO - 2023-12-10 13:08:22 --> Model Class Initialized
DEBUG - 2023-12-10 13:08:22 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-12-10 13:08:22 --> Session class already loaded. Second attempt ignored.
INFO - 2023-12-10 13:08:22 --> Model Class Initialized
INFO - 2023-12-10 13:08:22 --> Model Class Initialized
INFO - 2023-12-10 13:08:23 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-12-10 13:08:23 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-12-10 13:08:23 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-12-10 13:08:23 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-12-10 13:08:23 --> Model Class Initialized
INFO - 2023-12-10 13:08:23 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-12-10 13:08:23 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-12-10 13:08:23 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-12-10 13:08:23 --> Final output sent to browser
DEBUG - 2023-12-10 13:08:23 --> Total execution time: 0.3814
ERROR - 2023-12-10 13:08:25 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-12-10 13:08:25 --> Config Class Initialized
INFO - 2023-12-10 13:08:25 --> Hooks Class Initialized
DEBUG - 2023-12-10 13:08:25 --> UTF-8 Support Enabled
INFO - 2023-12-10 13:08:25 --> Utf8 Class Initialized
INFO - 2023-12-10 13:08:25 --> URI Class Initialized
INFO - 2023-12-10 13:08:25 --> Router Class Initialized
INFO - 2023-12-10 13:08:25 --> Output Class Initialized
INFO - 2023-12-10 13:08:25 --> Security Class Initialized
DEBUG - 2023-12-10 13:08:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-10 13:08:25 --> Input Class Initialized
INFO - 2023-12-10 13:08:25 --> Language Class Initialized
INFO - 2023-12-10 13:08:25 --> Loader Class Initialized
INFO - 2023-12-10 13:08:25 --> Helper loaded: url_helper
INFO - 2023-12-10 13:08:25 --> Helper loaded: file_helper
INFO - 2023-12-10 13:08:25 --> Helper loaded: html_helper
INFO - 2023-12-10 13:08:25 --> Helper loaded: text_helper
INFO - 2023-12-10 13:08:25 --> Helper loaded: form_helper
INFO - 2023-12-10 13:08:25 --> Helper loaded: lang_helper
INFO - 2023-12-10 13:08:25 --> Helper loaded: security_helper
INFO - 2023-12-10 13:08:25 --> Helper loaded: cookie_helper
INFO - 2023-12-10 13:08:25 --> Database Driver Class Initialized
INFO - 2023-12-10 13:08:25 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-10 13:08:25 --> Parser Class Initialized
INFO - 2023-12-10 13:08:25 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-12-10 13:08:25 --> Pagination Class Initialized
INFO - 2023-12-10 13:08:25 --> Form Validation Class Initialized
INFO - 2023-12-10 13:08:25 --> Controller Class Initialized
INFO - 2023-12-10 13:08:25 --> Model Class Initialized
DEBUG - 2023-12-10 13:08:25 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-12-10 13:08:25 --> Session class already loaded. Second attempt ignored.
INFO - 2023-12-10 13:08:25 --> Model Class Initialized
DEBUG - 2023-12-10 13:08:25 --> Session class already loaded. Second attempt ignored.
INFO - 2023-12-10 13:08:25 --> Model Class Initialized
INFO - 2023-12-10 13:08:25 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice.php
DEBUG - 2023-12-10 13:08:25 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-12-10 13:08:25 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-12-10 13:08:25 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-12-10 13:08:25 --> Model Class Initialized
INFO - 2023-12-10 13:08:25 --> Model Class Initialized
INFO - 2023-12-10 13:08:25 --> Model Class Initialized
INFO - 2023-12-10 13:08:25 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-12-10 13:08:25 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-12-10 13:08:25 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-12-10 13:08:25 --> Final output sent to browser
DEBUG - 2023-12-10 13:08:25 --> Total execution time: 0.2032
ERROR - 2023-12-10 13:08:25 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-12-10 13:08:25 --> Config Class Initialized
INFO - 2023-12-10 13:08:25 --> Hooks Class Initialized
DEBUG - 2023-12-10 13:08:25 --> UTF-8 Support Enabled
INFO - 2023-12-10 13:08:25 --> Utf8 Class Initialized
INFO - 2023-12-10 13:08:25 --> URI Class Initialized
INFO - 2023-12-10 13:08:25 --> Router Class Initialized
INFO - 2023-12-10 13:08:25 --> Output Class Initialized
INFO - 2023-12-10 13:08:25 --> Security Class Initialized
DEBUG - 2023-12-10 13:08:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-10 13:08:25 --> Input Class Initialized
INFO - 2023-12-10 13:08:25 --> Language Class Initialized
INFO - 2023-12-10 13:08:25 --> Loader Class Initialized
INFO - 2023-12-10 13:08:25 --> Helper loaded: url_helper
INFO - 2023-12-10 13:08:25 --> Helper loaded: file_helper
INFO - 2023-12-10 13:08:25 --> Helper loaded: html_helper
INFO - 2023-12-10 13:08:25 --> Helper loaded: text_helper
INFO - 2023-12-10 13:08:25 --> Helper loaded: form_helper
INFO - 2023-12-10 13:08:25 --> Helper loaded: lang_helper
INFO - 2023-12-10 13:08:25 --> Helper loaded: security_helper
INFO - 2023-12-10 13:08:25 --> Helper loaded: cookie_helper
INFO - 2023-12-10 13:08:25 --> Database Driver Class Initialized
INFO - 2023-12-10 13:08:25 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-10 13:08:25 --> Parser Class Initialized
INFO - 2023-12-10 13:08:25 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-12-10 13:08:25 --> Pagination Class Initialized
INFO - 2023-12-10 13:08:25 --> Form Validation Class Initialized
INFO - 2023-12-10 13:08:25 --> Controller Class Initialized
INFO - 2023-12-10 13:08:25 --> Model Class Initialized
DEBUG - 2023-12-10 13:08:25 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-12-10 13:08:25 --> Session class already loaded. Second attempt ignored.
INFO - 2023-12-10 13:08:25 --> Model Class Initialized
DEBUG - 2023-12-10 13:08:25 --> Session class already loaded. Second attempt ignored.
INFO - 2023-12-10 13:08:25 --> Model Class Initialized
INFO - 2023-12-10 13:08:25 --> Final output sent to browser
DEBUG - 2023-12-10 13:08:25 --> Total execution time: 0.0548
ERROR - 2023-12-10 13:08:34 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-12-10 13:08:34 --> Config Class Initialized
INFO - 2023-12-10 13:08:34 --> Hooks Class Initialized
DEBUG - 2023-12-10 13:08:34 --> UTF-8 Support Enabled
INFO - 2023-12-10 13:08:34 --> Utf8 Class Initialized
INFO - 2023-12-10 13:08:34 --> URI Class Initialized
INFO - 2023-12-10 13:08:34 --> Router Class Initialized
INFO - 2023-12-10 13:08:34 --> Output Class Initialized
INFO - 2023-12-10 13:08:34 --> Security Class Initialized
DEBUG - 2023-12-10 13:08:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-10 13:08:34 --> Input Class Initialized
INFO - 2023-12-10 13:08:34 --> Language Class Initialized
INFO - 2023-12-10 13:08:34 --> Loader Class Initialized
INFO - 2023-12-10 13:08:34 --> Helper loaded: url_helper
INFO - 2023-12-10 13:08:34 --> Helper loaded: file_helper
INFO - 2023-12-10 13:08:34 --> Helper loaded: html_helper
INFO - 2023-12-10 13:08:34 --> Helper loaded: text_helper
INFO - 2023-12-10 13:08:34 --> Helper loaded: form_helper
INFO - 2023-12-10 13:08:34 --> Helper loaded: lang_helper
INFO - 2023-12-10 13:08:34 --> Helper loaded: security_helper
INFO - 2023-12-10 13:08:34 --> Helper loaded: cookie_helper
INFO - 2023-12-10 13:08:34 --> Database Driver Class Initialized
INFO - 2023-12-10 13:08:34 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-10 13:08:34 --> Parser Class Initialized
INFO - 2023-12-10 13:08:34 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-12-10 13:08:34 --> Pagination Class Initialized
INFO - 2023-12-10 13:08:34 --> Form Validation Class Initialized
INFO - 2023-12-10 13:08:34 --> Controller Class Initialized
INFO - 2023-12-10 13:08:34 --> Model Class Initialized
DEBUG - 2023-12-10 13:08:34 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-12-10 13:08:34 --> Session class already loaded. Second attempt ignored.
INFO - 2023-12-10 13:08:34 --> Model Class Initialized
DEBUG - 2023-12-10 13:08:34 --> Session class already loaded. Second attempt ignored.
INFO - 2023-12-10 13:08:34 --> Model Class Initialized
INFO - 2023-12-10 13:08:35 --> Final output sent to browser
DEBUG - 2023-12-10 13:08:35 --> Total execution time: 0.9853
ERROR - 2023-12-10 15:09:05 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-12-10 15:09:05 --> Config Class Initialized
INFO - 2023-12-10 15:09:05 --> Hooks Class Initialized
DEBUG - 2023-12-10 15:09:05 --> UTF-8 Support Enabled
INFO - 2023-12-10 15:09:05 --> Utf8 Class Initialized
INFO - 2023-12-10 15:09:05 --> URI Class Initialized
DEBUG - 2023-12-10 15:09:05 --> No URI present. Default controller set.
INFO - 2023-12-10 15:09:05 --> Router Class Initialized
INFO - 2023-12-10 15:09:05 --> Output Class Initialized
INFO - 2023-12-10 15:09:05 --> Security Class Initialized
DEBUG - 2023-12-10 15:09:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-10 15:09:05 --> Input Class Initialized
INFO - 2023-12-10 15:09:05 --> Language Class Initialized
INFO - 2023-12-10 15:09:05 --> Loader Class Initialized
INFO - 2023-12-10 15:09:05 --> Helper loaded: url_helper
INFO - 2023-12-10 15:09:05 --> Helper loaded: file_helper
INFO - 2023-12-10 15:09:05 --> Helper loaded: html_helper
INFO - 2023-12-10 15:09:05 --> Helper loaded: text_helper
INFO - 2023-12-10 15:09:05 --> Helper loaded: form_helper
INFO - 2023-12-10 15:09:05 --> Helper loaded: lang_helper
INFO - 2023-12-10 15:09:05 --> Helper loaded: security_helper
INFO - 2023-12-10 15:09:05 --> Helper loaded: cookie_helper
INFO - 2023-12-10 15:09:05 --> Database Driver Class Initialized
INFO - 2023-12-10 15:09:05 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-10 15:09:05 --> Parser Class Initialized
INFO - 2023-12-10 15:09:05 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-12-10 15:09:05 --> Pagination Class Initialized
INFO - 2023-12-10 15:09:05 --> Form Validation Class Initialized
INFO - 2023-12-10 15:09:05 --> Controller Class Initialized
INFO - 2023-12-10 15:09:05 --> Model Class Initialized
DEBUG - 2023-12-10 15:09:05 --> Session class already loaded. Second attempt ignored.
ERROR - 2023-12-10 15:09:06 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-12-10 15:09:06 --> Config Class Initialized
INFO - 2023-12-10 15:09:06 --> Hooks Class Initialized
DEBUG - 2023-12-10 15:09:06 --> UTF-8 Support Enabled
INFO - 2023-12-10 15:09:06 --> Utf8 Class Initialized
INFO - 2023-12-10 15:09:06 --> URI Class Initialized
INFO - 2023-12-10 15:09:06 --> Router Class Initialized
INFO - 2023-12-10 15:09:06 --> Output Class Initialized
INFO - 2023-12-10 15:09:06 --> Security Class Initialized
DEBUG - 2023-12-10 15:09:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-10 15:09:06 --> Input Class Initialized
INFO - 2023-12-10 15:09:06 --> Language Class Initialized
INFO - 2023-12-10 15:09:06 --> Loader Class Initialized
INFO - 2023-12-10 15:09:06 --> Helper loaded: url_helper
INFO - 2023-12-10 15:09:06 --> Helper loaded: file_helper
INFO - 2023-12-10 15:09:06 --> Helper loaded: html_helper
INFO - 2023-12-10 15:09:06 --> Helper loaded: text_helper
INFO - 2023-12-10 15:09:06 --> Helper loaded: form_helper
INFO - 2023-12-10 15:09:06 --> Helper loaded: lang_helper
INFO - 2023-12-10 15:09:06 --> Helper loaded: security_helper
INFO - 2023-12-10 15:09:06 --> Helper loaded: cookie_helper
INFO - 2023-12-10 15:09:06 --> Database Driver Class Initialized
INFO - 2023-12-10 15:09:06 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-10 15:09:06 --> Parser Class Initialized
INFO - 2023-12-10 15:09:06 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-12-10 15:09:06 --> Pagination Class Initialized
INFO - 2023-12-10 15:09:06 --> Form Validation Class Initialized
INFO - 2023-12-10 15:09:06 --> Controller Class Initialized
INFO - 2023-12-10 15:09:06 --> Model Class Initialized
DEBUG - 2023-12-10 15:09:06 --> Session class already loaded. Second attempt ignored.
INFO - 2023-12-10 15:09:06 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2023-12-10 15:09:06 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-12-10 15:09:06 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-12-10 15:09:06 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-12-10 15:09:06 --> Model Class Initialized
INFO - 2023-12-10 15:09:06 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-12-10 15:09:06 --> Final output sent to browser
DEBUG - 2023-12-10 15:09:06 --> Total execution time: 0.0398
ERROR - 2023-12-10 15:09:42 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-12-10 15:09:42 --> Config Class Initialized
INFO - 2023-12-10 15:09:42 --> Hooks Class Initialized
DEBUG - 2023-12-10 15:09:42 --> UTF-8 Support Enabled
INFO - 2023-12-10 15:09:42 --> Utf8 Class Initialized
INFO - 2023-12-10 15:09:42 --> URI Class Initialized
INFO - 2023-12-10 15:09:42 --> Router Class Initialized
INFO - 2023-12-10 15:09:42 --> Output Class Initialized
INFO - 2023-12-10 15:09:42 --> Security Class Initialized
DEBUG - 2023-12-10 15:09:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-10 15:09:42 --> Input Class Initialized
INFO - 2023-12-10 15:09:42 --> Language Class Initialized
INFO - 2023-12-10 15:09:42 --> Loader Class Initialized
INFO - 2023-12-10 15:09:42 --> Helper loaded: url_helper
INFO - 2023-12-10 15:09:42 --> Helper loaded: file_helper
INFO - 2023-12-10 15:09:42 --> Helper loaded: html_helper
INFO - 2023-12-10 15:09:42 --> Helper loaded: text_helper
INFO - 2023-12-10 15:09:42 --> Helper loaded: form_helper
INFO - 2023-12-10 15:09:42 --> Helper loaded: lang_helper
INFO - 2023-12-10 15:09:42 --> Helper loaded: security_helper
INFO - 2023-12-10 15:09:42 --> Helper loaded: cookie_helper
INFO - 2023-12-10 15:09:42 --> Database Driver Class Initialized
INFO - 2023-12-10 15:09:42 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-10 15:09:42 --> Parser Class Initialized
INFO - 2023-12-10 15:09:42 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-12-10 15:09:42 --> Pagination Class Initialized
INFO - 2023-12-10 15:09:42 --> Form Validation Class Initialized
INFO - 2023-12-10 15:09:42 --> Controller Class Initialized
INFO - 2023-12-10 15:09:42 --> Model Class Initialized
DEBUG - 2023-12-10 15:09:42 --> Session class already loaded. Second attempt ignored.
INFO - 2023-12-10 15:09:42 --> Model Class Initialized
INFO - 2023-12-10 15:09:42 --> Final output sent to browser
DEBUG - 2023-12-10 15:09:42 --> Total execution time: 0.0192
ERROR - 2023-12-10 15:09:42 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-12-10 15:09:42 --> Config Class Initialized
INFO - 2023-12-10 15:09:42 --> Hooks Class Initialized
DEBUG - 2023-12-10 15:09:42 --> UTF-8 Support Enabled
INFO - 2023-12-10 15:09:42 --> Utf8 Class Initialized
INFO - 2023-12-10 15:09:42 --> URI Class Initialized
DEBUG - 2023-12-10 15:09:42 --> No URI present. Default controller set.
INFO - 2023-12-10 15:09:42 --> Router Class Initialized
INFO - 2023-12-10 15:09:42 --> Output Class Initialized
INFO - 2023-12-10 15:09:42 --> Security Class Initialized
DEBUG - 2023-12-10 15:09:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-10 15:09:42 --> Input Class Initialized
INFO - 2023-12-10 15:09:42 --> Language Class Initialized
INFO - 2023-12-10 15:09:42 --> Loader Class Initialized
INFO - 2023-12-10 15:09:42 --> Helper loaded: url_helper
INFO - 2023-12-10 15:09:42 --> Helper loaded: file_helper
INFO - 2023-12-10 15:09:42 --> Helper loaded: html_helper
INFO - 2023-12-10 15:09:42 --> Helper loaded: text_helper
INFO - 2023-12-10 15:09:42 --> Helper loaded: form_helper
INFO - 2023-12-10 15:09:42 --> Helper loaded: lang_helper
INFO - 2023-12-10 15:09:42 --> Helper loaded: security_helper
INFO - 2023-12-10 15:09:42 --> Helper loaded: cookie_helper
INFO - 2023-12-10 15:09:42 --> Database Driver Class Initialized
INFO - 2023-12-10 15:09:42 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-10 15:09:42 --> Parser Class Initialized
INFO - 2023-12-10 15:09:42 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-12-10 15:09:42 --> Pagination Class Initialized
INFO - 2023-12-10 15:09:42 --> Form Validation Class Initialized
INFO - 2023-12-10 15:09:42 --> Controller Class Initialized
INFO - 2023-12-10 15:09:42 --> Model Class Initialized
DEBUG - 2023-12-10 15:09:42 --> Session class already loaded. Second attempt ignored.
INFO - 2023-12-10 15:09:42 --> Model Class Initialized
DEBUG - 2023-12-10 15:09:42 --> Session class already loaded. Second attempt ignored.
INFO - 2023-12-10 15:09:42 --> Model Class Initialized
INFO - 2023-12-10 15:09:42 --> Model Class Initialized
INFO - 2023-12-10 15:09:42 --> Model Class Initialized
INFO - 2023-12-10 15:09:42 --> Model Class Initialized
DEBUG - 2023-12-10 15:09:42 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-12-10 15:09:42 --> Session class already loaded. Second attempt ignored.
INFO - 2023-12-10 15:09:42 --> Model Class Initialized
INFO - 2023-12-10 15:09:42 --> Model Class Initialized
INFO - 2023-12-10 15:09:42 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-12-10 15:09:42 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-12-10 15:09:42 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-12-10 15:09:42 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-12-10 15:09:42 --> Model Class Initialized
INFO - 2023-12-10 15:09:42 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-12-10 15:09:42 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-12-10 15:09:42 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-12-10 15:09:42 --> Final output sent to browser
DEBUG - 2023-12-10 15:09:42 --> Total execution time: 0.4052
ERROR - 2023-12-10 15:09:43 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-12-10 15:09:43 --> Config Class Initialized
INFO - 2023-12-10 15:09:43 --> Hooks Class Initialized
DEBUG - 2023-12-10 15:09:43 --> UTF-8 Support Enabled
INFO - 2023-12-10 15:09:43 --> Utf8 Class Initialized
INFO - 2023-12-10 15:09:43 --> URI Class Initialized
INFO - 2023-12-10 15:09:43 --> Router Class Initialized
INFO - 2023-12-10 15:09:43 --> Output Class Initialized
INFO - 2023-12-10 15:09:43 --> Security Class Initialized
DEBUG - 2023-12-10 15:09:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-10 15:09:43 --> Input Class Initialized
INFO - 2023-12-10 15:09:43 --> Language Class Initialized
INFO - 2023-12-10 15:09:43 --> Loader Class Initialized
INFO - 2023-12-10 15:09:43 --> Helper loaded: url_helper
INFO - 2023-12-10 15:09:43 --> Helper loaded: file_helper
INFO - 2023-12-10 15:09:43 --> Helper loaded: html_helper
INFO - 2023-12-10 15:09:43 --> Helper loaded: text_helper
INFO - 2023-12-10 15:09:43 --> Helper loaded: form_helper
INFO - 2023-12-10 15:09:43 --> Helper loaded: lang_helper
INFO - 2023-12-10 15:09:43 --> Helper loaded: security_helper
INFO - 2023-12-10 15:09:43 --> Helper loaded: cookie_helper
INFO - 2023-12-10 15:09:43 --> Database Driver Class Initialized
INFO - 2023-12-10 15:09:43 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-10 15:09:43 --> Parser Class Initialized
INFO - 2023-12-10 15:09:43 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-12-10 15:09:43 --> Pagination Class Initialized
INFO - 2023-12-10 15:09:43 --> Form Validation Class Initialized
INFO - 2023-12-10 15:09:43 --> Controller Class Initialized
DEBUG - 2023-12-10 15:09:43 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-12-10 15:09:43 --> Session class already loaded. Second attempt ignored.
INFO - 2023-12-10 15:09:43 --> Model Class Initialized
INFO - 2023-12-10 15:09:43 --> Final output sent to browser
DEBUG - 2023-12-10 15:09:43 --> Total execution time: 0.0124
ERROR - 2023-12-10 15:09:49 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-12-10 15:09:49 --> Config Class Initialized
INFO - 2023-12-10 15:09:49 --> Hooks Class Initialized
DEBUG - 2023-12-10 15:09:49 --> UTF-8 Support Enabled
INFO - 2023-12-10 15:09:49 --> Utf8 Class Initialized
INFO - 2023-12-10 15:09:49 --> URI Class Initialized
INFO - 2023-12-10 15:09:49 --> Router Class Initialized
INFO - 2023-12-10 15:09:49 --> Output Class Initialized
INFO - 2023-12-10 15:09:49 --> Security Class Initialized
DEBUG - 2023-12-10 15:09:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-10 15:09:49 --> Input Class Initialized
INFO - 2023-12-10 15:09:49 --> Language Class Initialized
INFO - 2023-12-10 15:09:49 --> Loader Class Initialized
INFO - 2023-12-10 15:09:49 --> Helper loaded: url_helper
INFO - 2023-12-10 15:09:49 --> Helper loaded: file_helper
INFO - 2023-12-10 15:09:49 --> Helper loaded: html_helper
INFO - 2023-12-10 15:09:49 --> Helper loaded: text_helper
INFO - 2023-12-10 15:09:49 --> Helper loaded: form_helper
INFO - 2023-12-10 15:09:49 --> Helper loaded: lang_helper
INFO - 2023-12-10 15:09:49 --> Helper loaded: security_helper
INFO - 2023-12-10 15:09:49 --> Helper loaded: cookie_helper
INFO - 2023-12-10 15:09:49 --> Database Driver Class Initialized
INFO - 2023-12-10 15:09:49 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-10 15:09:49 --> Parser Class Initialized
INFO - 2023-12-10 15:09:49 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-12-10 15:09:49 --> Pagination Class Initialized
INFO - 2023-12-10 15:09:49 --> Form Validation Class Initialized
INFO - 2023-12-10 15:09:49 --> Controller Class Initialized
DEBUG - 2023-12-10 15:09:49 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-12-10 15:09:49 --> Session class already loaded. Second attempt ignored.
INFO - 2023-12-10 15:09:49 --> Model Class Initialized
INFO - 2023-12-10 15:09:49 --> Model Class Initialized
DEBUG - 2023-12-10 15:09:49 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-12-10 15:09:49 --> Session class already loaded. Second attempt ignored.
INFO - 2023-12-10 15:09:49 --> Model Class Initialized
DEBUG - 2023-12-10 15:09:49 --> Session class already loaded. Second attempt ignored.
INFO - 2023-12-10 15:09:49 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/gst/list.php
DEBUG - 2023-12-10 15:09:49 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-12-10 15:09:49 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-12-10 15:09:49 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-12-10 15:09:49 --> Model Class Initialized
INFO - 2023-12-10 15:09:49 --> Model Class Initialized
INFO - 2023-12-10 15:09:49 --> Model Class Initialized
INFO - 2023-12-10 15:09:49 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-12-10 15:09:49 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-12-10 15:09:49 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-12-10 15:09:49 --> Final output sent to browser
DEBUG - 2023-12-10 15:09:49 --> Total execution time: 0.1968
ERROR - 2023-12-10 15:09:56 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-12-10 15:09:56 --> Config Class Initialized
INFO - 2023-12-10 15:09:56 --> Hooks Class Initialized
DEBUG - 2023-12-10 15:09:56 --> UTF-8 Support Enabled
INFO - 2023-12-10 15:09:56 --> Utf8 Class Initialized
INFO - 2023-12-10 15:09:56 --> URI Class Initialized
DEBUG - 2023-12-10 15:09:56 --> No URI present. Default controller set.
INFO - 2023-12-10 15:09:56 --> Router Class Initialized
INFO - 2023-12-10 15:09:56 --> Output Class Initialized
INFO - 2023-12-10 15:09:56 --> Security Class Initialized
DEBUG - 2023-12-10 15:09:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-10 15:09:56 --> Input Class Initialized
INFO - 2023-12-10 15:09:56 --> Language Class Initialized
INFO - 2023-12-10 15:09:56 --> Loader Class Initialized
INFO - 2023-12-10 15:09:56 --> Helper loaded: url_helper
INFO - 2023-12-10 15:09:56 --> Helper loaded: file_helper
INFO - 2023-12-10 15:09:56 --> Helper loaded: html_helper
INFO - 2023-12-10 15:09:56 --> Helper loaded: text_helper
INFO - 2023-12-10 15:09:56 --> Helper loaded: form_helper
INFO - 2023-12-10 15:09:56 --> Helper loaded: lang_helper
INFO - 2023-12-10 15:09:56 --> Helper loaded: security_helper
INFO - 2023-12-10 15:09:56 --> Helper loaded: cookie_helper
INFO - 2023-12-10 15:09:56 --> Database Driver Class Initialized
INFO - 2023-12-10 15:09:56 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-10 15:09:56 --> Parser Class Initialized
INFO - 2023-12-10 15:09:56 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-12-10 15:09:56 --> Pagination Class Initialized
INFO - 2023-12-10 15:09:56 --> Form Validation Class Initialized
INFO - 2023-12-10 15:09:56 --> Controller Class Initialized
INFO - 2023-12-10 15:09:56 --> Model Class Initialized
DEBUG - 2023-12-10 15:09:56 --> Session class already loaded. Second attempt ignored.
INFO - 2023-12-10 15:09:56 --> Model Class Initialized
DEBUG - 2023-12-10 15:09:56 --> Session class already loaded. Second attempt ignored.
INFO - 2023-12-10 15:09:56 --> Model Class Initialized
INFO - 2023-12-10 15:09:56 --> Model Class Initialized
INFO - 2023-12-10 15:09:56 --> Model Class Initialized
INFO - 2023-12-10 15:09:56 --> Model Class Initialized
DEBUG - 2023-12-10 15:09:56 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-12-10 15:09:56 --> Session class already loaded. Second attempt ignored.
INFO - 2023-12-10 15:09:56 --> Model Class Initialized
INFO - 2023-12-10 15:09:56 --> Model Class Initialized
INFO - 2023-12-10 15:09:56 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-12-10 15:09:56 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-12-10 15:09:56 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-12-10 15:09:56 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-12-10 15:09:56 --> Model Class Initialized
INFO - 2023-12-10 15:09:56 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-12-10 15:09:56 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-12-10 15:09:56 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-12-10 15:09:56 --> Final output sent to browser
DEBUG - 2023-12-10 15:09:56 --> Total execution time: 0.3999
ERROR - 2023-12-10 16:15:26 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-12-10 16:15:26 --> Config Class Initialized
INFO - 2023-12-10 16:15:26 --> Hooks Class Initialized
DEBUG - 2023-12-10 16:15:26 --> UTF-8 Support Enabled
INFO - 2023-12-10 16:15:26 --> Utf8 Class Initialized
INFO - 2023-12-10 16:15:26 --> URI Class Initialized
INFO - 2023-12-10 16:15:26 --> Router Class Initialized
INFO - 2023-12-10 16:15:26 --> Output Class Initialized
INFO - 2023-12-10 16:15:26 --> Security Class Initialized
DEBUG - 2023-12-10 16:15:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-10 16:15:26 --> Input Class Initialized
INFO - 2023-12-10 16:15:26 --> Language Class Initialized
ERROR - 2023-12-10 16:15:26 --> 404 Page Not Found: Well-known/assetlinks.json
ERROR - 2023-12-10 17:10:35 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-12-10 17:10:35 --> Config Class Initialized
INFO - 2023-12-10 17:10:35 --> Hooks Class Initialized
DEBUG - 2023-12-10 17:10:35 --> UTF-8 Support Enabled
INFO - 2023-12-10 17:10:35 --> Utf8 Class Initialized
INFO - 2023-12-10 17:10:35 --> URI Class Initialized
DEBUG - 2023-12-10 17:10:35 --> No URI present. Default controller set.
INFO - 2023-12-10 17:10:35 --> Router Class Initialized
INFO - 2023-12-10 17:10:35 --> Output Class Initialized
INFO - 2023-12-10 17:10:35 --> Security Class Initialized
DEBUG - 2023-12-10 17:10:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-10 17:10:35 --> Input Class Initialized
INFO - 2023-12-10 17:10:35 --> Language Class Initialized
INFO - 2023-12-10 17:10:35 --> Loader Class Initialized
INFO - 2023-12-10 17:10:35 --> Helper loaded: url_helper
INFO - 2023-12-10 17:10:35 --> Helper loaded: file_helper
INFO - 2023-12-10 17:10:35 --> Helper loaded: html_helper
INFO - 2023-12-10 17:10:35 --> Helper loaded: text_helper
INFO - 2023-12-10 17:10:35 --> Helper loaded: form_helper
INFO - 2023-12-10 17:10:35 --> Helper loaded: lang_helper
INFO - 2023-12-10 17:10:35 --> Helper loaded: security_helper
INFO - 2023-12-10 17:10:35 --> Helper loaded: cookie_helper
INFO - 2023-12-10 17:10:35 --> Database Driver Class Initialized
INFO - 2023-12-10 17:10:35 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-10 17:10:35 --> Parser Class Initialized
INFO - 2023-12-10 17:10:35 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-12-10 17:10:35 --> Pagination Class Initialized
INFO - 2023-12-10 17:10:35 --> Form Validation Class Initialized
INFO - 2023-12-10 17:10:35 --> Controller Class Initialized
INFO - 2023-12-10 17:10:35 --> Model Class Initialized
DEBUG - 2023-12-10 17:10:35 --> Session class already loaded. Second attempt ignored.
ERROR - 2023-12-10 17:10:37 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-12-10 17:10:37 --> Config Class Initialized
INFO - 2023-12-10 17:10:37 --> Hooks Class Initialized
DEBUG - 2023-12-10 17:10:37 --> UTF-8 Support Enabled
INFO - 2023-12-10 17:10:37 --> Utf8 Class Initialized
INFO - 2023-12-10 17:10:37 --> URI Class Initialized
DEBUG - 2023-12-10 17:10:37 --> No URI present. Default controller set.
INFO - 2023-12-10 17:10:37 --> Router Class Initialized
INFO - 2023-12-10 17:10:37 --> Output Class Initialized
INFO - 2023-12-10 17:10:37 --> Security Class Initialized
DEBUG - 2023-12-10 17:10:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-10 17:10:37 --> Input Class Initialized
INFO - 2023-12-10 17:10:37 --> Language Class Initialized
INFO - 2023-12-10 17:10:37 --> Loader Class Initialized
INFO - 2023-12-10 17:10:37 --> Helper loaded: url_helper
INFO - 2023-12-10 17:10:37 --> Helper loaded: file_helper
INFO - 2023-12-10 17:10:37 --> Helper loaded: html_helper
INFO - 2023-12-10 17:10:37 --> Helper loaded: text_helper
INFO - 2023-12-10 17:10:37 --> Helper loaded: form_helper
INFO - 2023-12-10 17:10:37 --> Helper loaded: lang_helper
INFO - 2023-12-10 17:10:37 --> Helper loaded: security_helper
INFO - 2023-12-10 17:10:37 --> Helper loaded: cookie_helper
INFO - 2023-12-10 17:10:37 --> Database Driver Class Initialized
INFO - 2023-12-10 17:10:37 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-10 17:10:37 --> Parser Class Initialized
INFO - 2023-12-10 17:10:37 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-12-10 17:10:37 --> Pagination Class Initialized
INFO - 2023-12-10 17:10:37 --> Form Validation Class Initialized
INFO - 2023-12-10 17:10:37 --> Controller Class Initialized
INFO - 2023-12-10 17:10:37 --> Model Class Initialized
DEBUG - 2023-12-10 17:10:37 --> Session class already loaded. Second attempt ignored.
ERROR - 2023-12-10 17:10:39 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-12-10 17:10:39 --> Config Class Initialized
INFO - 2023-12-10 17:10:39 --> Hooks Class Initialized
DEBUG - 2023-12-10 17:10:39 --> UTF-8 Support Enabled
INFO - 2023-12-10 17:10:39 --> Utf8 Class Initialized
INFO - 2023-12-10 17:10:39 --> URI Class Initialized
DEBUG - 2023-12-10 17:10:39 --> No URI present. Default controller set.
INFO - 2023-12-10 17:10:39 --> Router Class Initialized
INFO - 2023-12-10 17:10:39 --> Output Class Initialized
INFO - 2023-12-10 17:10:39 --> Security Class Initialized
DEBUG - 2023-12-10 17:10:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-10 17:10:39 --> Input Class Initialized
INFO - 2023-12-10 17:10:39 --> Language Class Initialized
INFO - 2023-12-10 17:10:39 --> Loader Class Initialized
INFO - 2023-12-10 17:10:39 --> Helper loaded: url_helper
INFO - 2023-12-10 17:10:39 --> Helper loaded: file_helper
INFO - 2023-12-10 17:10:39 --> Helper loaded: html_helper
INFO - 2023-12-10 17:10:39 --> Helper loaded: text_helper
INFO - 2023-12-10 17:10:39 --> Helper loaded: form_helper
INFO - 2023-12-10 17:10:39 --> Helper loaded: lang_helper
INFO - 2023-12-10 17:10:39 --> Helper loaded: security_helper
INFO - 2023-12-10 17:10:39 --> Helper loaded: cookie_helper
INFO - 2023-12-10 17:10:39 --> Database Driver Class Initialized
INFO - 2023-12-10 17:10:39 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-10 17:10:39 --> Parser Class Initialized
INFO - 2023-12-10 17:10:39 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-12-10 17:10:39 --> Pagination Class Initialized
INFO - 2023-12-10 17:10:39 --> Form Validation Class Initialized
INFO - 2023-12-10 17:10:39 --> Controller Class Initialized
INFO - 2023-12-10 17:10:39 --> Model Class Initialized
DEBUG - 2023-12-10 17:10:39 --> Session class already loaded. Second attempt ignored.
ERROR - 2023-12-10 17:10:40 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-12-10 17:10:40 --> Config Class Initialized
INFO - 2023-12-10 17:10:40 --> Hooks Class Initialized
DEBUG - 2023-12-10 17:10:40 --> UTF-8 Support Enabled
INFO - 2023-12-10 17:10:40 --> Utf8 Class Initialized
INFO - 2023-12-10 17:10:40 --> URI Class Initialized
DEBUG - 2023-12-10 17:10:40 --> No URI present. Default controller set.
INFO - 2023-12-10 17:10:40 --> Router Class Initialized
INFO - 2023-12-10 17:10:40 --> Output Class Initialized
INFO - 2023-12-10 17:10:40 --> Security Class Initialized
DEBUG - 2023-12-10 17:10:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-10 17:10:40 --> Input Class Initialized
INFO - 2023-12-10 17:10:40 --> Language Class Initialized
INFO - 2023-12-10 17:10:40 --> Loader Class Initialized
INFO - 2023-12-10 17:10:40 --> Helper loaded: url_helper
INFO - 2023-12-10 17:10:40 --> Helper loaded: file_helper
INFO - 2023-12-10 17:10:40 --> Helper loaded: html_helper
INFO - 2023-12-10 17:10:40 --> Helper loaded: text_helper
INFO - 2023-12-10 17:10:40 --> Helper loaded: form_helper
INFO - 2023-12-10 17:10:40 --> Helper loaded: lang_helper
INFO - 2023-12-10 17:10:40 --> Helper loaded: security_helper
INFO - 2023-12-10 17:10:40 --> Helper loaded: cookie_helper
INFO - 2023-12-10 17:10:40 --> Database Driver Class Initialized
INFO - 2023-12-10 17:10:40 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-10 17:10:40 --> Parser Class Initialized
INFO - 2023-12-10 17:10:40 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-12-10 17:10:40 --> Pagination Class Initialized
INFO - 2023-12-10 17:10:40 --> Form Validation Class Initialized
INFO - 2023-12-10 17:10:40 --> Controller Class Initialized
INFO - 2023-12-10 17:10:40 --> Model Class Initialized
DEBUG - 2023-12-10 17:10:40 --> Session class already loaded. Second attempt ignored.
