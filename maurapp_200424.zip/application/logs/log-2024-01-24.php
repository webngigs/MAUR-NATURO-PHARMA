<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2024-01-24 01:48:29 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-01-24 01:48:29 --> Config Class Initialized
INFO - 2024-01-24 01:48:29 --> Hooks Class Initialized
DEBUG - 2024-01-24 01:48:29 --> UTF-8 Support Enabled
INFO - 2024-01-24 01:48:29 --> Utf8 Class Initialized
INFO - 2024-01-24 01:48:29 --> URI Class Initialized
INFO - 2024-01-24 01:48:29 --> Router Class Initialized
INFO - 2024-01-24 01:48:29 --> Output Class Initialized
INFO - 2024-01-24 01:48:29 --> Security Class Initialized
DEBUG - 2024-01-24 01:48:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-24 01:48:29 --> Input Class Initialized
INFO - 2024-01-24 01:48:29 --> Language Class Initialized
ERROR - 2024-01-24 01:48:29 --> 404 Page Not Found: Sitemapxml/index
ERROR - 2024-01-24 01:48:30 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-01-24 01:48:30 --> Config Class Initialized
INFO - 2024-01-24 01:48:30 --> Hooks Class Initialized
DEBUG - 2024-01-24 01:48:30 --> UTF-8 Support Enabled
INFO - 2024-01-24 01:48:30 --> Utf8 Class Initialized
INFO - 2024-01-24 01:48:30 --> URI Class Initialized
DEBUG - 2024-01-24 01:48:30 --> No URI present. Default controller set.
INFO - 2024-01-24 01:48:30 --> Router Class Initialized
INFO - 2024-01-24 01:48:30 --> Output Class Initialized
INFO - 2024-01-24 01:48:30 --> Security Class Initialized
DEBUG - 2024-01-24 01:48:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-24 01:48:30 --> Input Class Initialized
INFO - 2024-01-24 01:48:30 --> Language Class Initialized
INFO - 2024-01-24 01:48:30 --> Loader Class Initialized
INFO - 2024-01-24 01:48:30 --> Helper loaded: url_helper
INFO - 2024-01-24 01:48:30 --> Helper loaded: file_helper
INFO - 2024-01-24 01:48:30 --> Helper loaded: html_helper
INFO - 2024-01-24 01:48:30 --> Helper loaded: text_helper
INFO - 2024-01-24 01:48:30 --> Helper loaded: form_helper
INFO - 2024-01-24 01:48:30 --> Helper loaded: lang_helper
INFO - 2024-01-24 01:48:30 --> Helper loaded: security_helper
INFO - 2024-01-24 01:48:30 --> Helper loaded: cookie_helper
INFO - 2024-01-24 01:48:30 --> Database Driver Class Initialized
INFO - 2024-01-24 01:48:30 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-24 01:48:30 --> Parser Class Initialized
INFO - 2024-01-24 01:48:30 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-01-24 01:48:30 --> Pagination Class Initialized
INFO - 2024-01-24 01:48:30 --> Form Validation Class Initialized
INFO - 2024-01-24 01:48:30 --> Controller Class Initialized
INFO - 2024-01-24 01:48:30 --> Model Class Initialized
DEBUG - 2024-01-24 01:48:30 --> Session class already loaded. Second attempt ignored.
ERROR - 2024-01-24 01:48:32 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-01-24 01:48:32 --> Config Class Initialized
INFO - 2024-01-24 01:48:32 --> Hooks Class Initialized
DEBUG - 2024-01-24 01:48:32 --> UTF-8 Support Enabled
INFO - 2024-01-24 01:48:32 --> Utf8 Class Initialized
INFO - 2024-01-24 01:48:32 --> URI Class Initialized
INFO - 2024-01-24 01:48:32 --> Router Class Initialized
INFO - 2024-01-24 01:48:32 --> Output Class Initialized
INFO - 2024-01-24 01:48:32 --> Security Class Initialized
DEBUG - 2024-01-24 01:48:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-24 01:48:32 --> Input Class Initialized
INFO - 2024-01-24 01:48:32 --> Language Class Initialized
ERROR - 2024-01-24 01:48:32 --> 404 Page Not Found: Wp-cronphp/index
ERROR - 2024-01-24 04:02:21 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-01-24 04:02:21 --> Config Class Initialized
INFO - 2024-01-24 04:02:21 --> Hooks Class Initialized
DEBUG - 2024-01-24 04:02:21 --> UTF-8 Support Enabled
INFO - 2024-01-24 04:02:21 --> Utf8 Class Initialized
INFO - 2024-01-24 04:02:21 --> URI Class Initialized
DEBUG - 2024-01-24 04:02:21 --> No URI present. Default controller set.
INFO - 2024-01-24 04:02:21 --> Router Class Initialized
INFO - 2024-01-24 04:02:21 --> Output Class Initialized
INFO - 2024-01-24 04:02:21 --> Security Class Initialized
DEBUG - 2024-01-24 04:02:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-24 04:02:21 --> Input Class Initialized
INFO - 2024-01-24 04:02:21 --> Language Class Initialized
INFO - 2024-01-24 04:02:21 --> Loader Class Initialized
INFO - 2024-01-24 04:02:21 --> Helper loaded: url_helper
INFO - 2024-01-24 04:02:21 --> Helper loaded: file_helper
INFO - 2024-01-24 04:02:21 --> Helper loaded: html_helper
INFO - 2024-01-24 04:02:21 --> Helper loaded: text_helper
INFO - 2024-01-24 04:02:21 --> Helper loaded: form_helper
INFO - 2024-01-24 04:02:21 --> Helper loaded: lang_helper
INFO - 2024-01-24 04:02:21 --> Helper loaded: security_helper
INFO - 2024-01-24 04:02:21 --> Helper loaded: cookie_helper
INFO - 2024-01-24 04:02:21 --> Database Driver Class Initialized
INFO - 2024-01-24 04:02:21 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-24 04:02:21 --> Parser Class Initialized
INFO - 2024-01-24 04:02:21 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-01-24 04:02:21 --> Pagination Class Initialized
INFO - 2024-01-24 04:02:21 --> Form Validation Class Initialized
INFO - 2024-01-24 04:02:21 --> Controller Class Initialized
INFO - 2024-01-24 04:02:21 --> Model Class Initialized
DEBUG - 2024-01-24 04:02:21 --> Session class already loaded. Second attempt ignored.
ERROR - 2024-01-24 04:02:21 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-01-24 04:02:21 --> Config Class Initialized
INFO - 2024-01-24 04:02:21 --> Hooks Class Initialized
DEBUG - 2024-01-24 04:02:21 --> UTF-8 Support Enabled
INFO - 2024-01-24 04:02:21 --> Utf8 Class Initialized
INFO - 2024-01-24 04:02:21 --> URI Class Initialized
INFO - 2024-01-24 04:02:21 --> Router Class Initialized
INFO - 2024-01-24 04:02:21 --> Output Class Initialized
INFO - 2024-01-24 04:02:21 --> Security Class Initialized
DEBUG - 2024-01-24 04:02:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-24 04:02:21 --> Input Class Initialized
INFO - 2024-01-24 04:02:21 --> Language Class Initialized
INFO - 2024-01-24 04:02:21 --> Loader Class Initialized
INFO - 2024-01-24 04:02:21 --> Helper loaded: url_helper
INFO - 2024-01-24 04:02:21 --> Helper loaded: file_helper
INFO - 2024-01-24 04:02:21 --> Helper loaded: html_helper
INFO - 2024-01-24 04:02:21 --> Helper loaded: text_helper
INFO - 2024-01-24 04:02:21 --> Helper loaded: form_helper
INFO - 2024-01-24 04:02:21 --> Helper loaded: lang_helper
INFO - 2024-01-24 04:02:21 --> Helper loaded: security_helper
INFO - 2024-01-24 04:02:21 --> Helper loaded: cookie_helper
INFO - 2024-01-24 04:02:21 --> Database Driver Class Initialized
INFO - 2024-01-24 04:02:21 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-24 04:02:21 --> Parser Class Initialized
INFO - 2024-01-24 04:02:21 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-01-24 04:02:21 --> Pagination Class Initialized
INFO - 2024-01-24 04:02:21 --> Form Validation Class Initialized
INFO - 2024-01-24 04:02:21 --> Controller Class Initialized
INFO - 2024-01-24 04:02:21 --> Model Class Initialized
DEBUG - 2024-01-24 04:02:21 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-24 04:02:21 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2024-01-24 04:02:21 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-01-24 04:02:21 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-01-24 04:02:21 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-01-24 04:02:21 --> Model Class Initialized
INFO - 2024-01-24 04:02:21 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-01-24 04:02:21 --> Final output sent to browser
DEBUG - 2024-01-24 04:02:21 --> Total execution time: 0.0352
ERROR - 2024-01-24 04:02:30 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-01-24 04:02:30 --> Config Class Initialized
INFO - 2024-01-24 04:02:30 --> Hooks Class Initialized
DEBUG - 2024-01-24 04:02:30 --> UTF-8 Support Enabled
INFO - 2024-01-24 04:02:30 --> Utf8 Class Initialized
INFO - 2024-01-24 04:02:30 --> URI Class Initialized
INFO - 2024-01-24 04:02:30 --> Router Class Initialized
INFO - 2024-01-24 04:02:30 --> Output Class Initialized
INFO - 2024-01-24 04:02:30 --> Security Class Initialized
DEBUG - 2024-01-24 04:02:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-24 04:02:30 --> Input Class Initialized
INFO - 2024-01-24 04:02:30 --> Language Class Initialized
INFO - 2024-01-24 04:02:30 --> Loader Class Initialized
INFO - 2024-01-24 04:02:30 --> Helper loaded: url_helper
INFO - 2024-01-24 04:02:30 --> Helper loaded: file_helper
INFO - 2024-01-24 04:02:30 --> Helper loaded: html_helper
INFO - 2024-01-24 04:02:30 --> Helper loaded: text_helper
INFO - 2024-01-24 04:02:30 --> Helper loaded: form_helper
INFO - 2024-01-24 04:02:30 --> Helper loaded: lang_helper
INFO - 2024-01-24 04:02:30 --> Helper loaded: security_helper
INFO - 2024-01-24 04:02:30 --> Helper loaded: cookie_helper
INFO - 2024-01-24 04:02:30 --> Database Driver Class Initialized
INFO - 2024-01-24 04:02:30 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-24 04:02:30 --> Parser Class Initialized
INFO - 2024-01-24 04:02:30 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-01-24 04:02:30 --> Pagination Class Initialized
INFO - 2024-01-24 04:02:30 --> Form Validation Class Initialized
INFO - 2024-01-24 04:02:30 --> Controller Class Initialized
INFO - 2024-01-24 04:02:30 --> Model Class Initialized
DEBUG - 2024-01-24 04:02:30 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-24 04:02:30 --> Model Class Initialized
INFO - 2024-01-24 04:02:30 --> Final output sent to browser
DEBUG - 2024-01-24 04:02:30 --> Total execution time: 0.0199
ERROR - 2024-01-24 04:02:31 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-01-24 04:02:31 --> Config Class Initialized
INFO - 2024-01-24 04:02:31 --> Hooks Class Initialized
DEBUG - 2024-01-24 04:02:31 --> UTF-8 Support Enabled
INFO - 2024-01-24 04:02:31 --> Utf8 Class Initialized
INFO - 2024-01-24 04:02:31 --> URI Class Initialized
DEBUG - 2024-01-24 04:02:31 --> No URI present. Default controller set.
INFO - 2024-01-24 04:02:31 --> Router Class Initialized
INFO - 2024-01-24 04:02:31 --> Output Class Initialized
INFO - 2024-01-24 04:02:31 --> Security Class Initialized
DEBUG - 2024-01-24 04:02:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-24 04:02:31 --> Input Class Initialized
INFO - 2024-01-24 04:02:31 --> Language Class Initialized
INFO - 2024-01-24 04:02:31 --> Loader Class Initialized
INFO - 2024-01-24 04:02:31 --> Helper loaded: url_helper
INFO - 2024-01-24 04:02:31 --> Helper loaded: file_helper
INFO - 2024-01-24 04:02:31 --> Helper loaded: html_helper
INFO - 2024-01-24 04:02:31 --> Helper loaded: text_helper
INFO - 2024-01-24 04:02:31 --> Helper loaded: form_helper
INFO - 2024-01-24 04:02:31 --> Helper loaded: lang_helper
INFO - 2024-01-24 04:02:31 --> Helper loaded: security_helper
INFO - 2024-01-24 04:02:31 --> Helper loaded: cookie_helper
INFO - 2024-01-24 04:02:31 --> Database Driver Class Initialized
INFO - 2024-01-24 04:02:31 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-24 04:02:31 --> Parser Class Initialized
INFO - 2024-01-24 04:02:31 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-01-24 04:02:31 --> Pagination Class Initialized
INFO - 2024-01-24 04:02:31 --> Form Validation Class Initialized
INFO - 2024-01-24 04:02:31 --> Controller Class Initialized
INFO - 2024-01-24 04:02:31 --> Model Class Initialized
DEBUG - 2024-01-24 04:02:31 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-24 04:02:31 --> Model Class Initialized
DEBUG - 2024-01-24 04:02:31 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-24 04:02:31 --> Model Class Initialized
INFO - 2024-01-24 04:02:31 --> Model Class Initialized
INFO - 2024-01-24 04:02:31 --> Model Class Initialized
INFO - 2024-01-24 04:02:31 --> Model Class Initialized
DEBUG - 2024-01-24 04:02:31 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-01-24 04:02:31 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-24 04:02:31 --> Model Class Initialized
INFO - 2024-01-24 04:02:31 --> Model Class Initialized
INFO - 2024-01-24 04:02:31 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2024-01-24 04:02:31 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-01-24 04:02:31 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-01-24 04:02:31 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-01-24 04:02:31 --> Model Class Initialized
INFO - 2024-01-24 04:02:31 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-01-24 04:02:31 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-01-24 04:02:31 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-01-24 04:02:31 --> Final output sent to browser
DEBUG - 2024-01-24 04:02:31 --> Total execution time: 0.2356
ERROR - 2024-01-24 04:02:35 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-01-24 04:02:35 --> Config Class Initialized
INFO - 2024-01-24 04:02:35 --> Hooks Class Initialized
DEBUG - 2024-01-24 04:02:35 --> UTF-8 Support Enabled
INFO - 2024-01-24 04:02:35 --> Utf8 Class Initialized
INFO - 2024-01-24 04:02:35 --> URI Class Initialized
INFO - 2024-01-24 04:02:35 --> Router Class Initialized
INFO - 2024-01-24 04:02:35 --> Output Class Initialized
INFO - 2024-01-24 04:02:35 --> Security Class Initialized
DEBUG - 2024-01-24 04:02:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-24 04:02:35 --> Input Class Initialized
INFO - 2024-01-24 04:02:35 --> Language Class Initialized
INFO - 2024-01-24 04:02:35 --> Loader Class Initialized
INFO - 2024-01-24 04:02:35 --> Helper loaded: url_helper
INFO - 2024-01-24 04:02:35 --> Helper loaded: file_helper
INFO - 2024-01-24 04:02:35 --> Helper loaded: html_helper
INFO - 2024-01-24 04:02:35 --> Helper loaded: text_helper
INFO - 2024-01-24 04:02:35 --> Helper loaded: form_helper
INFO - 2024-01-24 04:02:35 --> Helper loaded: lang_helper
INFO - 2024-01-24 04:02:35 --> Helper loaded: security_helper
INFO - 2024-01-24 04:02:35 --> Helper loaded: cookie_helper
INFO - 2024-01-24 04:02:35 --> Database Driver Class Initialized
INFO - 2024-01-24 04:02:35 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-24 04:02:35 --> Parser Class Initialized
INFO - 2024-01-24 04:02:35 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-01-24 04:02:35 --> Pagination Class Initialized
INFO - 2024-01-24 04:02:35 --> Form Validation Class Initialized
INFO - 2024-01-24 04:02:35 --> Controller Class Initialized
INFO - 2024-01-24 04:02:35 --> Model Class Initialized
DEBUG - 2024-01-24 04:02:35 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-01-24 04:02:35 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-24 04:02:35 --> Model Class Initialized
DEBUG - 2024-01-24 04:02:35 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-24 04:02:35 --> Model Class Initialized
INFO - 2024-01-24 04:02:35 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice.php
DEBUG - 2024-01-24 04:02:35 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-01-24 04:02:35 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-01-24 04:02:35 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-01-24 04:02:35 --> Model Class Initialized
INFO - 2024-01-24 04:02:35 --> Model Class Initialized
INFO - 2024-01-24 04:02:35 --> Model Class Initialized
INFO - 2024-01-24 04:02:36 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-01-24 04:02:36 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-01-24 04:02:36 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-01-24 04:02:36 --> Final output sent to browser
DEBUG - 2024-01-24 04:02:36 --> Total execution time: 0.1495
ERROR - 2024-01-24 04:02:36 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-01-24 04:02:36 --> Config Class Initialized
INFO - 2024-01-24 04:02:36 --> Hooks Class Initialized
DEBUG - 2024-01-24 04:02:36 --> UTF-8 Support Enabled
INFO - 2024-01-24 04:02:36 --> Utf8 Class Initialized
INFO - 2024-01-24 04:02:36 --> URI Class Initialized
INFO - 2024-01-24 04:02:36 --> Router Class Initialized
INFO - 2024-01-24 04:02:36 --> Output Class Initialized
INFO - 2024-01-24 04:02:36 --> Security Class Initialized
DEBUG - 2024-01-24 04:02:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-24 04:02:36 --> Input Class Initialized
INFO - 2024-01-24 04:02:36 --> Language Class Initialized
INFO - 2024-01-24 04:02:36 --> Loader Class Initialized
INFO - 2024-01-24 04:02:36 --> Helper loaded: url_helper
INFO - 2024-01-24 04:02:36 --> Helper loaded: file_helper
INFO - 2024-01-24 04:02:36 --> Helper loaded: html_helper
INFO - 2024-01-24 04:02:36 --> Helper loaded: text_helper
INFO - 2024-01-24 04:02:36 --> Helper loaded: form_helper
INFO - 2024-01-24 04:02:36 --> Helper loaded: lang_helper
INFO - 2024-01-24 04:02:36 --> Helper loaded: security_helper
INFO - 2024-01-24 04:02:36 --> Helper loaded: cookie_helper
INFO - 2024-01-24 04:02:36 --> Database Driver Class Initialized
INFO - 2024-01-24 04:02:36 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-24 04:02:36 --> Parser Class Initialized
INFO - 2024-01-24 04:02:36 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-01-24 04:02:36 --> Pagination Class Initialized
INFO - 2024-01-24 04:02:36 --> Form Validation Class Initialized
INFO - 2024-01-24 04:02:36 --> Controller Class Initialized
INFO - 2024-01-24 04:02:36 --> Model Class Initialized
DEBUG - 2024-01-24 04:02:36 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-01-24 04:02:36 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-24 04:02:36 --> Model Class Initialized
DEBUG - 2024-01-24 04:02:36 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-24 04:02:36 --> Model Class Initialized
INFO - 2024-01-24 04:02:36 --> Final output sent to browser
DEBUG - 2024-01-24 04:02:36 --> Total execution time: 0.0401
ERROR - 2024-01-24 04:02:40 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-01-24 04:02:40 --> Config Class Initialized
INFO - 2024-01-24 04:02:40 --> Hooks Class Initialized
DEBUG - 2024-01-24 04:02:40 --> UTF-8 Support Enabled
INFO - 2024-01-24 04:02:40 --> Utf8 Class Initialized
INFO - 2024-01-24 04:02:40 --> URI Class Initialized
INFO - 2024-01-24 04:02:40 --> Router Class Initialized
INFO - 2024-01-24 04:02:40 --> Output Class Initialized
INFO - 2024-01-24 04:02:40 --> Security Class Initialized
DEBUG - 2024-01-24 04:02:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-24 04:02:40 --> Input Class Initialized
INFO - 2024-01-24 04:02:40 --> Language Class Initialized
INFO - 2024-01-24 04:02:40 --> Loader Class Initialized
INFO - 2024-01-24 04:02:40 --> Helper loaded: url_helper
INFO - 2024-01-24 04:02:40 --> Helper loaded: file_helper
INFO - 2024-01-24 04:02:40 --> Helper loaded: html_helper
INFO - 2024-01-24 04:02:40 --> Helper loaded: text_helper
INFO - 2024-01-24 04:02:40 --> Helper loaded: form_helper
INFO - 2024-01-24 04:02:40 --> Helper loaded: lang_helper
INFO - 2024-01-24 04:02:40 --> Helper loaded: security_helper
INFO - 2024-01-24 04:02:40 --> Helper loaded: cookie_helper
INFO - 2024-01-24 04:02:40 --> Database Driver Class Initialized
INFO - 2024-01-24 04:02:40 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-24 04:02:40 --> Parser Class Initialized
INFO - 2024-01-24 04:02:40 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-01-24 04:02:40 --> Pagination Class Initialized
INFO - 2024-01-24 04:02:40 --> Form Validation Class Initialized
INFO - 2024-01-24 04:02:40 --> Controller Class Initialized
INFO - 2024-01-24 04:02:40 --> Model Class Initialized
DEBUG - 2024-01-24 04:02:40 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-01-24 04:02:40 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-24 04:02:40 --> Model Class Initialized
DEBUG - 2024-01-24 04:02:40 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-24 04:02:40 --> Model Class Initialized
INFO - 2024-01-24 04:02:40 --> Final output sent to browser
DEBUG - 2024-01-24 04:02:40 --> Total execution time: 0.1245
ERROR - 2024-01-24 04:03:12 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-01-24 04:03:12 --> Config Class Initialized
INFO - 2024-01-24 04:03:12 --> Hooks Class Initialized
DEBUG - 2024-01-24 04:03:12 --> UTF-8 Support Enabled
INFO - 2024-01-24 04:03:12 --> Utf8 Class Initialized
INFO - 2024-01-24 04:03:12 --> URI Class Initialized
INFO - 2024-01-24 04:03:12 --> Router Class Initialized
INFO - 2024-01-24 04:03:12 --> Output Class Initialized
INFO - 2024-01-24 04:03:12 --> Security Class Initialized
DEBUG - 2024-01-24 04:03:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-24 04:03:12 --> Input Class Initialized
INFO - 2024-01-24 04:03:12 --> Language Class Initialized
INFO - 2024-01-24 04:03:12 --> Loader Class Initialized
INFO - 2024-01-24 04:03:12 --> Helper loaded: url_helper
INFO - 2024-01-24 04:03:12 --> Helper loaded: file_helper
INFO - 2024-01-24 04:03:12 --> Helper loaded: html_helper
INFO - 2024-01-24 04:03:12 --> Helper loaded: text_helper
INFO - 2024-01-24 04:03:12 --> Helper loaded: form_helper
INFO - 2024-01-24 04:03:12 --> Helper loaded: lang_helper
INFO - 2024-01-24 04:03:12 --> Helper loaded: security_helper
INFO - 2024-01-24 04:03:12 --> Helper loaded: cookie_helper
INFO - 2024-01-24 04:03:12 --> Database Driver Class Initialized
INFO - 2024-01-24 04:03:12 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-24 04:03:12 --> Parser Class Initialized
INFO - 2024-01-24 04:03:12 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-01-24 04:03:12 --> Pagination Class Initialized
INFO - 2024-01-24 04:03:12 --> Form Validation Class Initialized
INFO - 2024-01-24 04:03:12 --> Controller Class Initialized
INFO - 2024-01-24 04:03:12 --> Model Class Initialized
DEBUG - 2024-01-24 04:03:12 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-01-24 04:03:12 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-24 04:03:12 --> Model Class Initialized
DEBUG - 2024-01-24 04:03:12 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-24 04:03:12 --> Model Class Initialized
DEBUG - 2024-01-24 04:03:12 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-24 04:03:12 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice_html.php
DEBUG - 2024-01-24 04:03:12 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-01-24 04:03:12 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-01-24 04:03:12 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-01-24 04:03:12 --> Model Class Initialized
INFO - 2024-01-24 04:03:12 --> Model Class Initialized
INFO - 2024-01-24 04:03:12 --> Model Class Initialized
INFO - 2024-01-24 04:03:12 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-01-24 04:03:12 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-01-24 04:03:12 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-01-24 04:03:12 --> Final output sent to browser
DEBUG - 2024-01-24 04:03:12 --> Total execution time: 0.1611
ERROR - 2024-01-24 04:03:21 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-01-24 04:03:21 --> Config Class Initialized
INFO - 2024-01-24 04:03:21 --> Hooks Class Initialized
DEBUG - 2024-01-24 04:03:21 --> UTF-8 Support Enabled
INFO - 2024-01-24 04:03:21 --> Utf8 Class Initialized
INFO - 2024-01-24 04:03:21 --> URI Class Initialized
INFO - 2024-01-24 04:03:21 --> Router Class Initialized
INFO - 2024-01-24 04:03:21 --> Output Class Initialized
INFO - 2024-01-24 04:03:21 --> Security Class Initialized
DEBUG - 2024-01-24 04:03:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-24 04:03:21 --> Input Class Initialized
INFO - 2024-01-24 04:03:21 --> Language Class Initialized
INFO - 2024-01-24 04:03:21 --> Loader Class Initialized
INFO - 2024-01-24 04:03:21 --> Helper loaded: url_helper
INFO - 2024-01-24 04:03:21 --> Helper loaded: file_helper
INFO - 2024-01-24 04:03:21 --> Helper loaded: html_helper
INFO - 2024-01-24 04:03:21 --> Helper loaded: text_helper
INFO - 2024-01-24 04:03:21 --> Helper loaded: form_helper
INFO - 2024-01-24 04:03:21 --> Helper loaded: lang_helper
INFO - 2024-01-24 04:03:21 --> Helper loaded: security_helper
INFO - 2024-01-24 04:03:21 --> Helper loaded: cookie_helper
INFO - 2024-01-24 04:03:21 --> Database Driver Class Initialized
INFO - 2024-01-24 04:03:21 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-24 04:03:21 --> Parser Class Initialized
INFO - 2024-01-24 04:03:21 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-01-24 04:03:21 --> Pagination Class Initialized
INFO - 2024-01-24 04:03:21 --> Form Validation Class Initialized
INFO - 2024-01-24 04:03:21 --> Controller Class Initialized
INFO - 2024-01-24 04:03:21 --> Model Class Initialized
DEBUG - 2024-01-24 04:03:21 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-01-24 04:03:21 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-24 04:03:21 --> Model Class Initialized
DEBUG - 2024-01-24 04:03:21 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-24 04:03:21 --> Model Class Initialized
INFO - 2024-01-24 04:03:21 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice.php
DEBUG - 2024-01-24 04:03:21 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-01-24 04:03:21 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-01-24 04:03:21 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-01-24 04:03:21 --> Model Class Initialized
INFO - 2024-01-24 04:03:21 --> Model Class Initialized
INFO - 2024-01-24 04:03:21 --> Model Class Initialized
INFO - 2024-01-24 04:03:22 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-01-24 04:03:22 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-01-24 04:03:22 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-01-24 04:03:22 --> Final output sent to browser
DEBUG - 2024-01-24 04:03:22 --> Total execution time: 0.1444
ERROR - 2024-01-24 04:03:22 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-01-24 04:03:22 --> Config Class Initialized
INFO - 2024-01-24 04:03:22 --> Hooks Class Initialized
DEBUG - 2024-01-24 04:03:22 --> UTF-8 Support Enabled
INFO - 2024-01-24 04:03:22 --> Utf8 Class Initialized
INFO - 2024-01-24 04:03:22 --> URI Class Initialized
INFO - 2024-01-24 04:03:22 --> Router Class Initialized
INFO - 2024-01-24 04:03:22 --> Output Class Initialized
INFO - 2024-01-24 04:03:22 --> Security Class Initialized
DEBUG - 2024-01-24 04:03:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-24 04:03:22 --> Input Class Initialized
INFO - 2024-01-24 04:03:22 --> Language Class Initialized
INFO - 2024-01-24 04:03:22 --> Loader Class Initialized
INFO - 2024-01-24 04:03:22 --> Helper loaded: url_helper
INFO - 2024-01-24 04:03:22 --> Helper loaded: file_helper
INFO - 2024-01-24 04:03:22 --> Helper loaded: html_helper
INFO - 2024-01-24 04:03:22 --> Helper loaded: text_helper
INFO - 2024-01-24 04:03:22 --> Helper loaded: form_helper
INFO - 2024-01-24 04:03:22 --> Helper loaded: lang_helper
INFO - 2024-01-24 04:03:22 --> Helper loaded: security_helper
INFO - 2024-01-24 04:03:22 --> Helper loaded: cookie_helper
INFO - 2024-01-24 04:03:22 --> Database Driver Class Initialized
INFO - 2024-01-24 04:03:22 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-24 04:03:22 --> Parser Class Initialized
INFO - 2024-01-24 04:03:22 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-01-24 04:03:22 --> Pagination Class Initialized
INFO - 2024-01-24 04:03:22 --> Form Validation Class Initialized
INFO - 2024-01-24 04:03:22 --> Controller Class Initialized
INFO - 2024-01-24 04:03:22 --> Model Class Initialized
DEBUG - 2024-01-24 04:03:22 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-01-24 04:03:22 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-24 04:03:22 --> Model Class Initialized
DEBUG - 2024-01-24 04:03:22 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-24 04:03:22 --> Model Class Initialized
INFO - 2024-01-24 04:03:22 --> Final output sent to browser
DEBUG - 2024-01-24 04:03:22 --> Total execution time: 0.0415
ERROR - 2024-01-24 04:03:39 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-01-24 04:03:39 --> Config Class Initialized
INFO - 2024-01-24 04:03:39 --> Hooks Class Initialized
DEBUG - 2024-01-24 04:03:39 --> UTF-8 Support Enabled
INFO - 2024-01-24 04:03:39 --> Utf8 Class Initialized
INFO - 2024-01-24 04:03:39 --> URI Class Initialized
INFO - 2024-01-24 04:03:39 --> Router Class Initialized
INFO - 2024-01-24 04:03:39 --> Output Class Initialized
INFO - 2024-01-24 04:03:39 --> Security Class Initialized
DEBUG - 2024-01-24 04:03:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-24 04:03:39 --> Input Class Initialized
INFO - 2024-01-24 04:03:39 --> Language Class Initialized
INFO - 2024-01-24 04:03:39 --> Loader Class Initialized
INFO - 2024-01-24 04:03:39 --> Helper loaded: url_helper
INFO - 2024-01-24 04:03:39 --> Helper loaded: file_helper
INFO - 2024-01-24 04:03:39 --> Helper loaded: html_helper
INFO - 2024-01-24 04:03:39 --> Helper loaded: text_helper
INFO - 2024-01-24 04:03:39 --> Helper loaded: form_helper
INFO - 2024-01-24 04:03:39 --> Helper loaded: lang_helper
INFO - 2024-01-24 04:03:39 --> Helper loaded: security_helper
INFO - 2024-01-24 04:03:39 --> Helper loaded: cookie_helper
INFO - 2024-01-24 04:03:39 --> Database Driver Class Initialized
INFO - 2024-01-24 04:03:39 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-24 04:03:39 --> Parser Class Initialized
INFO - 2024-01-24 04:03:39 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-01-24 04:03:39 --> Pagination Class Initialized
INFO - 2024-01-24 04:03:39 --> Form Validation Class Initialized
INFO - 2024-01-24 04:03:39 --> Controller Class Initialized
INFO - 2024-01-24 04:03:39 --> Model Class Initialized
DEBUG - 2024-01-24 04:03:39 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-01-24 04:03:39 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-24 04:03:39 --> Model Class Initialized
DEBUG - 2024-01-24 04:03:39 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-24 04:03:39 --> Model Class Initialized
DEBUG - 2024-01-24 04:03:39 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-24 04:03:39 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice_html.php
DEBUG - 2024-01-24 04:03:39 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-01-24 04:03:39 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-01-24 04:03:39 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-01-24 04:03:39 --> Model Class Initialized
INFO - 2024-01-24 04:03:39 --> Model Class Initialized
INFO - 2024-01-24 04:03:39 --> Model Class Initialized
INFO - 2024-01-24 04:03:39 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-01-24 04:03:39 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-01-24 04:03:39 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-01-24 04:03:39 --> Final output sent to browser
DEBUG - 2024-01-24 04:03:39 --> Total execution time: 0.1658
ERROR - 2024-01-24 04:03:45 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-01-24 04:03:45 --> Config Class Initialized
INFO - 2024-01-24 04:03:45 --> Hooks Class Initialized
DEBUG - 2024-01-24 04:03:45 --> UTF-8 Support Enabled
INFO - 2024-01-24 04:03:45 --> Utf8 Class Initialized
INFO - 2024-01-24 04:03:45 --> URI Class Initialized
INFO - 2024-01-24 04:03:45 --> Router Class Initialized
INFO - 2024-01-24 04:03:45 --> Output Class Initialized
INFO - 2024-01-24 04:03:45 --> Security Class Initialized
DEBUG - 2024-01-24 04:03:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-24 04:03:45 --> Input Class Initialized
INFO - 2024-01-24 04:03:45 --> Language Class Initialized
INFO - 2024-01-24 04:03:45 --> Loader Class Initialized
INFO - 2024-01-24 04:03:45 --> Helper loaded: url_helper
INFO - 2024-01-24 04:03:45 --> Helper loaded: file_helper
INFO - 2024-01-24 04:03:45 --> Helper loaded: html_helper
INFO - 2024-01-24 04:03:45 --> Helper loaded: text_helper
INFO - 2024-01-24 04:03:45 --> Helper loaded: form_helper
INFO - 2024-01-24 04:03:45 --> Helper loaded: lang_helper
INFO - 2024-01-24 04:03:45 --> Helper loaded: security_helper
INFO - 2024-01-24 04:03:45 --> Helper loaded: cookie_helper
INFO - 2024-01-24 04:03:45 --> Database Driver Class Initialized
INFO - 2024-01-24 04:03:45 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-24 04:03:45 --> Parser Class Initialized
INFO - 2024-01-24 04:03:45 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-01-24 04:03:45 --> Pagination Class Initialized
INFO - 2024-01-24 04:03:45 --> Form Validation Class Initialized
INFO - 2024-01-24 04:03:45 --> Controller Class Initialized
INFO - 2024-01-24 04:03:45 --> Model Class Initialized
DEBUG - 2024-01-24 04:03:45 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-01-24 04:03:45 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-24 04:03:45 --> Model Class Initialized
DEBUG - 2024-01-24 04:03:45 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-24 04:03:45 --> Model Class Initialized
INFO - 2024-01-24 04:03:45 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice.php
DEBUG - 2024-01-24 04:03:45 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-01-24 04:03:45 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-01-24 04:03:45 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-01-24 04:03:45 --> Model Class Initialized
INFO - 2024-01-24 04:03:45 --> Model Class Initialized
INFO - 2024-01-24 04:03:45 --> Model Class Initialized
INFO - 2024-01-24 04:03:46 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-01-24 04:03:46 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-01-24 04:03:46 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-01-24 04:03:46 --> Final output sent to browser
DEBUG - 2024-01-24 04:03:46 --> Total execution time: 0.1517
ERROR - 2024-01-24 04:03:46 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-01-24 04:03:46 --> Config Class Initialized
INFO - 2024-01-24 04:03:46 --> Hooks Class Initialized
DEBUG - 2024-01-24 04:03:46 --> UTF-8 Support Enabled
INFO - 2024-01-24 04:03:46 --> Utf8 Class Initialized
INFO - 2024-01-24 04:03:46 --> URI Class Initialized
INFO - 2024-01-24 04:03:46 --> Router Class Initialized
INFO - 2024-01-24 04:03:46 --> Output Class Initialized
INFO - 2024-01-24 04:03:46 --> Security Class Initialized
DEBUG - 2024-01-24 04:03:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-24 04:03:46 --> Input Class Initialized
INFO - 2024-01-24 04:03:46 --> Language Class Initialized
INFO - 2024-01-24 04:03:46 --> Loader Class Initialized
INFO - 2024-01-24 04:03:46 --> Helper loaded: url_helper
INFO - 2024-01-24 04:03:46 --> Helper loaded: file_helper
INFO - 2024-01-24 04:03:46 --> Helper loaded: html_helper
INFO - 2024-01-24 04:03:46 --> Helper loaded: text_helper
INFO - 2024-01-24 04:03:46 --> Helper loaded: form_helper
INFO - 2024-01-24 04:03:46 --> Helper loaded: lang_helper
INFO - 2024-01-24 04:03:46 --> Helper loaded: security_helper
INFO - 2024-01-24 04:03:46 --> Helper loaded: cookie_helper
INFO - 2024-01-24 04:03:46 --> Database Driver Class Initialized
INFO - 2024-01-24 04:03:46 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-24 04:03:46 --> Parser Class Initialized
INFO - 2024-01-24 04:03:46 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-01-24 04:03:46 --> Pagination Class Initialized
INFO - 2024-01-24 04:03:46 --> Form Validation Class Initialized
INFO - 2024-01-24 04:03:46 --> Controller Class Initialized
INFO - 2024-01-24 04:03:46 --> Model Class Initialized
DEBUG - 2024-01-24 04:03:46 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-01-24 04:03:46 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-24 04:03:46 --> Model Class Initialized
DEBUG - 2024-01-24 04:03:46 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-24 04:03:46 --> Model Class Initialized
INFO - 2024-01-24 04:03:46 --> Final output sent to browser
DEBUG - 2024-01-24 04:03:46 --> Total execution time: 0.0418
ERROR - 2024-01-24 04:04:01 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-01-24 04:04:01 --> Config Class Initialized
INFO - 2024-01-24 04:04:01 --> Hooks Class Initialized
DEBUG - 2024-01-24 04:04:01 --> UTF-8 Support Enabled
INFO - 2024-01-24 04:04:01 --> Utf8 Class Initialized
INFO - 2024-01-24 04:04:01 --> URI Class Initialized
INFO - 2024-01-24 04:04:01 --> Router Class Initialized
INFO - 2024-01-24 04:04:01 --> Output Class Initialized
INFO - 2024-01-24 04:04:01 --> Security Class Initialized
DEBUG - 2024-01-24 04:04:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-24 04:04:01 --> Input Class Initialized
INFO - 2024-01-24 04:04:01 --> Language Class Initialized
INFO - 2024-01-24 04:04:01 --> Loader Class Initialized
INFO - 2024-01-24 04:04:01 --> Helper loaded: url_helper
INFO - 2024-01-24 04:04:01 --> Helper loaded: file_helper
INFO - 2024-01-24 04:04:01 --> Helper loaded: html_helper
INFO - 2024-01-24 04:04:01 --> Helper loaded: text_helper
INFO - 2024-01-24 04:04:01 --> Helper loaded: form_helper
INFO - 2024-01-24 04:04:01 --> Helper loaded: lang_helper
INFO - 2024-01-24 04:04:01 --> Helper loaded: security_helper
INFO - 2024-01-24 04:04:01 --> Helper loaded: cookie_helper
INFO - 2024-01-24 04:04:01 --> Database Driver Class Initialized
INFO - 2024-01-24 04:04:01 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-24 04:04:01 --> Parser Class Initialized
INFO - 2024-01-24 04:04:01 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-01-24 04:04:01 --> Pagination Class Initialized
INFO - 2024-01-24 04:04:01 --> Form Validation Class Initialized
INFO - 2024-01-24 04:04:01 --> Controller Class Initialized
INFO - 2024-01-24 04:04:01 --> Model Class Initialized
DEBUG - 2024-01-24 04:04:01 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-01-24 04:04:01 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-24 04:04:01 --> Model Class Initialized
DEBUG - 2024-01-24 04:04:01 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-24 04:04:01 --> Model Class Initialized
INFO - 2024-01-24 04:04:01 --> Final output sent to browser
DEBUG - 2024-01-24 04:04:01 --> Total execution time: 0.1237
ERROR - 2024-01-24 04:04:27 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-01-24 04:04:27 --> Config Class Initialized
INFO - 2024-01-24 04:04:27 --> Hooks Class Initialized
DEBUG - 2024-01-24 04:04:27 --> UTF-8 Support Enabled
INFO - 2024-01-24 04:04:27 --> Utf8 Class Initialized
INFO - 2024-01-24 04:04:27 --> URI Class Initialized
INFO - 2024-01-24 04:04:27 --> Router Class Initialized
INFO - 2024-01-24 04:04:27 --> Output Class Initialized
INFO - 2024-01-24 04:04:27 --> Security Class Initialized
DEBUG - 2024-01-24 04:04:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-24 04:04:27 --> Input Class Initialized
INFO - 2024-01-24 04:04:27 --> Language Class Initialized
INFO - 2024-01-24 04:04:27 --> Loader Class Initialized
INFO - 2024-01-24 04:04:27 --> Helper loaded: url_helper
INFO - 2024-01-24 04:04:27 --> Helper loaded: file_helper
INFO - 2024-01-24 04:04:27 --> Helper loaded: html_helper
INFO - 2024-01-24 04:04:27 --> Helper loaded: text_helper
INFO - 2024-01-24 04:04:27 --> Helper loaded: form_helper
INFO - 2024-01-24 04:04:27 --> Helper loaded: lang_helper
INFO - 2024-01-24 04:04:27 --> Helper loaded: security_helper
INFO - 2024-01-24 04:04:27 --> Helper loaded: cookie_helper
INFO - 2024-01-24 04:04:27 --> Database Driver Class Initialized
INFO - 2024-01-24 04:04:27 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-24 04:04:27 --> Parser Class Initialized
INFO - 2024-01-24 04:04:27 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-01-24 04:04:27 --> Pagination Class Initialized
INFO - 2024-01-24 04:04:27 --> Form Validation Class Initialized
INFO - 2024-01-24 04:04:27 --> Controller Class Initialized
INFO - 2024-01-24 04:04:27 --> Model Class Initialized
DEBUG - 2024-01-24 04:04:27 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-01-24 04:04:27 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-24 04:04:27 --> Model Class Initialized
DEBUG - 2024-01-24 04:04:27 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-24 04:04:27 --> Model Class Initialized
DEBUG - 2024-01-24 04:04:27 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-24 04:04:27 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice_html.php
DEBUG - 2024-01-24 04:04:27 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-01-24 04:04:27 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-01-24 04:04:27 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-01-24 04:04:27 --> Model Class Initialized
INFO - 2024-01-24 04:04:27 --> Model Class Initialized
INFO - 2024-01-24 04:04:27 --> Model Class Initialized
INFO - 2024-01-24 04:04:27 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-01-24 04:04:27 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-01-24 04:04:27 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-01-24 04:04:27 --> Final output sent to browser
DEBUG - 2024-01-24 04:04:27 --> Total execution time: 0.1632
ERROR - 2024-01-24 04:04:39 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-01-24 04:04:39 --> Config Class Initialized
INFO - 2024-01-24 04:04:39 --> Hooks Class Initialized
DEBUG - 2024-01-24 04:04:39 --> UTF-8 Support Enabled
INFO - 2024-01-24 04:04:39 --> Utf8 Class Initialized
INFO - 2024-01-24 04:04:39 --> URI Class Initialized
INFO - 2024-01-24 04:04:39 --> Router Class Initialized
INFO - 2024-01-24 04:04:39 --> Output Class Initialized
INFO - 2024-01-24 04:04:39 --> Security Class Initialized
DEBUG - 2024-01-24 04:04:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-24 04:04:39 --> Input Class Initialized
INFO - 2024-01-24 04:04:39 --> Language Class Initialized
INFO - 2024-01-24 04:04:39 --> Loader Class Initialized
INFO - 2024-01-24 04:04:39 --> Helper loaded: url_helper
INFO - 2024-01-24 04:04:39 --> Helper loaded: file_helper
INFO - 2024-01-24 04:04:39 --> Helper loaded: html_helper
INFO - 2024-01-24 04:04:39 --> Helper loaded: text_helper
INFO - 2024-01-24 04:04:39 --> Helper loaded: form_helper
INFO - 2024-01-24 04:04:39 --> Helper loaded: lang_helper
INFO - 2024-01-24 04:04:39 --> Helper loaded: security_helper
INFO - 2024-01-24 04:04:39 --> Helper loaded: cookie_helper
INFO - 2024-01-24 04:04:39 --> Database Driver Class Initialized
INFO - 2024-01-24 04:04:39 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-24 04:04:39 --> Parser Class Initialized
INFO - 2024-01-24 04:04:39 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-01-24 04:04:39 --> Pagination Class Initialized
INFO - 2024-01-24 04:04:39 --> Form Validation Class Initialized
INFO - 2024-01-24 04:04:39 --> Controller Class Initialized
INFO - 2024-01-24 04:04:39 --> Model Class Initialized
DEBUG - 2024-01-24 04:04:39 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-01-24 04:04:39 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-24 04:04:39 --> Model Class Initialized
DEBUG - 2024-01-24 04:04:39 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-24 04:04:39 --> Model Class Initialized
INFO - 2024-01-24 04:04:39 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice.php
DEBUG - 2024-01-24 04:04:39 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-01-24 04:04:39 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-01-24 04:04:39 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-01-24 04:04:39 --> Model Class Initialized
INFO - 2024-01-24 04:04:39 --> Model Class Initialized
INFO - 2024-01-24 04:04:39 --> Model Class Initialized
INFO - 2024-01-24 04:04:39 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-01-24 04:04:39 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-01-24 04:04:39 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-01-24 04:04:39 --> Final output sent to browser
DEBUG - 2024-01-24 04:04:39 --> Total execution time: 0.1549
ERROR - 2024-01-24 04:04:40 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-01-24 04:04:40 --> Config Class Initialized
INFO - 2024-01-24 04:04:40 --> Hooks Class Initialized
DEBUG - 2024-01-24 04:04:40 --> UTF-8 Support Enabled
INFO - 2024-01-24 04:04:40 --> Utf8 Class Initialized
INFO - 2024-01-24 04:04:40 --> URI Class Initialized
INFO - 2024-01-24 04:04:40 --> Router Class Initialized
INFO - 2024-01-24 04:04:40 --> Output Class Initialized
INFO - 2024-01-24 04:04:40 --> Security Class Initialized
DEBUG - 2024-01-24 04:04:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-24 04:04:40 --> Input Class Initialized
INFO - 2024-01-24 04:04:40 --> Language Class Initialized
INFO - 2024-01-24 04:04:40 --> Loader Class Initialized
INFO - 2024-01-24 04:04:40 --> Helper loaded: url_helper
INFO - 2024-01-24 04:04:40 --> Helper loaded: file_helper
INFO - 2024-01-24 04:04:40 --> Helper loaded: html_helper
INFO - 2024-01-24 04:04:40 --> Helper loaded: text_helper
INFO - 2024-01-24 04:04:40 --> Helper loaded: form_helper
INFO - 2024-01-24 04:04:40 --> Helper loaded: lang_helper
INFO - 2024-01-24 04:04:40 --> Helper loaded: security_helper
INFO - 2024-01-24 04:04:40 --> Helper loaded: cookie_helper
INFO - 2024-01-24 04:04:40 --> Database Driver Class Initialized
INFO - 2024-01-24 04:04:40 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-24 04:04:40 --> Parser Class Initialized
INFO - 2024-01-24 04:04:40 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-01-24 04:04:40 --> Pagination Class Initialized
INFO - 2024-01-24 04:04:40 --> Form Validation Class Initialized
INFO - 2024-01-24 04:04:40 --> Controller Class Initialized
INFO - 2024-01-24 04:04:40 --> Model Class Initialized
DEBUG - 2024-01-24 04:04:40 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-01-24 04:04:40 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-24 04:04:40 --> Model Class Initialized
DEBUG - 2024-01-24 04:04:40 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-24 04:04:40 --> Model Class Initialized
INFO - 2024-01-24 04:04:40 --> Final output sent to browser
DEBUG - 2024-01-24 04:04:40 --> Total execution time: 0.0410
ERROR - 2024-01-24 04:04:54 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-01-24 04:04:54 --> Config Class Initialized
INFO - 2024-01-24 04:04:54 --> Hooks Class Initialized
DEBUG - 2024-01-24 04:04:54 --> UTF-8 Support Enabled
INFO - 2024-01-24 04:04:54 --> Utf8 Class Initialized
INFO - 2024-01-24 04:04:54 --> URI Class Initialized
INFO - 2024-01-24 04:04:54 --> Router Class Initialized
INFO - 2024-01-24 04:04:54 --> Output Class Initialized
INFO - 2024-01-24 04:04:54 --> Security Class Initialized
DEBUG - 2024-01-24 04:04:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-24 04:04:54 --> Input Class Initialized
INFO - 2024-01-24 04:04:54 --> Language Class Initialized
INFO - 2024-01-24 04:04:54 --> Loader Class Initialized
INFO - 2024-01-24 04:04:54 --> Helper loaded: url_helper
INFO - 2024-01-24 04:04:54 --> Helper loaded: file_helper
INFO - 2024-01-24 04:04:54 --> Helper loaded: html_helper
INFO - 2024-01-24 04:04:54 --> Helper loaded: text_helper
INFO - 2024-01-24 04:04:54 --> Helper loaded: form_helper
INFO - 2024-01-24 04:04:54 --> Helper loaded: lang_helper
INFO - 2024-01-24 04:04:54 --> Helper loaded: security_helper
INFO - 2024-01-24 04:04:54 --> Helper loaded: cookie_helper
INFO - 2024-01-24 04:04:54 --> Database Driver Class Initialized
INFO - 2024-01-24 04:04:54 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-24 04:04:54 --> Parser Class Initialized
INFO - 2024-01-24 04:04:54 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-01-24 04:04:54 --> Pagination Class Initialized
INFO - 2024-01-24 04:04:54 --> Form Validation Class Initialized
INFO - 2024-01-24 04:04:54 --> Controller Class Initialized
INFO - 2024-01-24 04:04:54 --> Model Class Initialized
DEBUG - 2024-01-24 04:04:54 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-01-24 04:04:54 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-24 04:04:54 --> Model Class Initialized
DEBUG - 2024-01-24 04:04:54 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-24 04:04:54 --> Model Class Initialized
INFO - 2024-01-24 04:04:54 --> Final output sent to browser
DEBUG - 2024-01-24 04:04:54 --> Total execution time: 0.1300
ERROR - 2024-01-24 04:05:48 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-01-24 04:05:48 --> Config Class Initialized
INFO - 2024-01-24 04:05:48 --> Hooks Class Initialized
DEBUG - 2024-01-24 04:05:48 --> UTF-8 Support Enabled
INFO - 2024-01-24 04:05:48 --> Utf8 Class Initialized
INFO - 2024-01-24 04:05:48 --> URI Class Initialized
INFO - 2024-01-24 04:05:48 --> Router Class Initialized
INFO - 2024-01-24 04:05:48 --> Output Class Initialized
INFO - 2024-01-24 04:05:48 --> Security Class Initialized
DEBUG - 2024-01-24 04:05:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-24 04:05:48 --> Input Class Initialized
INFO - 2024-01-24 04:05:48 --> Language Class Initialized
INFO - 2024-01-24 04:05:48 --> Loader Class Initialized
INFO - 2024-01-24 04:05:48 --> Helper loaded: url_helper
INFO - 2024-01-24 04:05:48 --> Helper loaded: file_helper
INFO - 2024-01-24 04:05:48 --> Helper loaded: html_helper
INFO - 2024-01-24 04:05:48 --> Helper loaded: text_helper
INFO - 2024-01-24 04:05:48 --> Helper loaded: form_helper
INFO - 2024-01-24 04:05:48 --> Helper loaded: lang_helper
INFO - 2024-01-24 04:05:48 --> Helper loaded: security_helper
INFO - 2024-01-24 04:05:48 --> Helper loaded: cookie_helper
INFO - 2024-01-24 04:05:48 --> Database Driver Class Initialized
INFO - 2024-01-24 04:05:48 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-24 04:05:48 --> Parser Class Initialized
INFO - 2024-01-24 04:05:48 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-01-24 04:05:48 --> Pagination Class Initialized
INFO - 2024-01-24 04:05:48 --> Form Validation Class Initialized
INFO - 2024-01-24 04:05:48 --> Controller Class Initialized
INFO - 2024-01-24 04:05:48 --> Model Class Initialized
DEBUG - 2024-01-24 04:05:48 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-01-24 04:05:48 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-24 04:05:48 --> Model Class Initialized
DEBUG - 2024-01-24 04:05:48 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-24 04:05:48 --> Model Class Initialized
DEBUG - 2024-01-24 04:05:48 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-24 04:05:48 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice_html.php
DEBUG - 2024-01-24 04:05:48 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-01-24 04:05:48 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-01-24 04:05:48 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-01-24 04:05:48 --> Model Class Initialized
INFO - 2024-01-24 04:05:48 --> Model Class Initialized
INFO - 2024-01-24 04:05:48 --> Model Class Initialized
INFO - 2024-01-24 04:05:48 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-01-24 04:05:48 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-01-24 04:05:48 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-01-24 04:05:48 --> Final output sent to browser
DEBUG - 2024-01-24 04:05:48 --> Total execution time: 0.1623
ERROR - 2024-01-24 04:06:29 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-01-24 04:06:29 --> Config Class Initialized
INFO - 2024-01-24 04:06:29 --> Hooks Class Initialized
DEBUG - 2024-01-24 04:06:29 --> UTF-8 Support Enabled
INFO - 2024-01-24 04:06:29 --> Utf8 Class Initialized
INFO - 2024-01-24 04:06:29 --> URI Class Initialized
INFO - 2024-01-24 04:06:29 --> Router Class Initialized
INFO - 2024-01-24 04:06:29 --> Output Class Initialized
INFO - 2024-01-24 04:06:29 --> Security Class Initialized
DEBUG - 2024-01-24 04:06:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-24 04:06:29 --> Input Class Initialized
INFO - 2024-01-24 04:06:29 --> Language Class Initialized
INFO - 2024-01-24 04:06:29 --> Loader Class Initialized
INFO - 2024-01-24 04:06:29 --> Helper loaded: url_helper
INFO - 2024-01-24 04:06:29 --> Helper loaded: file_helper
INFO - 2024-01-24 04:06:29 --> Helper loaded: html_helper
INFO - 2024-01-24 04:06:29 --> Helper loaded: text_helper
INFO - 2024-01-24 04:06:29 --> Helper loaded: form_helper
INFO - 2024-01-24 04:06:29 --> Helper loaded: lang_helper
INFO - 2024-01-24 04:06:29 --> Helper loaded: security_helper
INFO - 2024-01-24 04:06:29 --> Helper loaded: cookie_helper
INFO - 2024-01-24 04:06:29 --> Database Driver Class Initialized
INFO - 2024-01-24 04:06:29 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-24 04:06:29 --> Parser Class Initialized
INFO - 2024-01-24 04:06:29 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-01-24 04:06:29 --> Pagination Class Initialized
INFO - 2024-01-24 04:06:29 --> Form Validation Class Initialized
INFO - 2024-01-24 04:06:29 --> Controller Class Initialized
INFO - 2024-01-24 04:06:29 --> Model Class Initialized
DEBUG - 2024-01-24 04:06:29 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-01-24 04:06:29 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-24 04:06:29 --> Model Class Initialized
DEBUG - 2024-01-24 04:06:29 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-24 04:06:29 --> Model Class Initialized
INFO - 2024-01-24 04:06:29 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice.php
DEBUG - 2024-01-24 04:06:29 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-01-24 04:06:29 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-01-24 04:06:29 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-01-24 04:06:29 --> Model Class Initialized
INFO - 2024-01-24 04:06:29 --> Model Class Initialized
INFO - 2024-01-24 04:06:29 --> Model Class Initialized
INFO - 2024-01-24 04:06:29 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-01-24 04:06:29 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-01-24 04:06:29 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-01-24 04:06:29 --> Final output sent to browser
DEBUG - 2024-01-24 04:06:29 --> Total execution time: 0.1594
ERROR - 2024-01-24 04:06:29 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-01-24 04:06:29 --> Config Class Initialized
INFO - 2024-01-24 04:06:29 --> Hooks Class Initialized
DEBUG - 2024-01-24 04:06:29 --> UTF-8 Support Enabled
INFO - 2024-01-24 04:06:29 --> Utf8 Class Initialized
INFO - 2024-01-24 04:06:29 --> URI Class Initialized
DEBUG - 2024-01-24 04:06:29 --> No URI present. Default controller set.
INFO - 2024-01-24 04:06:29 --> Router Class Initialized
INFO - 2024-01-24 04:06:29 --> Output Class Initialized
INFO - 2024-01-24 04:06:29 --> Security Class Initialized
DEBUG - 2024-01-24 04:06:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-24 04:06:29 --> Input Class Initialized
INFO - 2024-01-24 04:06:29 --> Language Class Initialized
INFO - 2024-01-24 04:06:29 --> Loader Class Initialized
INFO - 2024-01-24 04:06:29 --> Helper loaded: url_helper
INFO - 2024-01-24 04:06:29 --> Helper loaded: file_helper
INFO - 2024-01-24 04:06:29 --> Helper loaded: html_helper
INFO - 2024-01-24 04:06:29 --> Helper loaded: text_helper
INFO - 2024-01-24 04:06:29 --> Helper loaded: form_helper
INFO - 2024-01-24 04:06:29 --> Helper loaded: lang_helper
INFO - 2024-01-24 04:06:29 --> Helper loaded: security_helper
INFO - 2024-01-24 04:06:29 --> Helper loaded: cookie_helper
INFO - 2024-01-24 04:06:29 --> Database Driver Class Initialized
INFO - 2024-01-24 04:06:29 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-24 04:06:29 --> Parser Class Initialized
INFO - 2024-01-24 04:06:29 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-01-24 04:06:29 --> Pagination Class Initialized
INFO - 2024-01-24 04:06:29 --> Form Validation Class Initialized
INFO - 2024-01-24 04:06:29 --> Controller Class Initialized
INFO - 2024-01-24 04:06:29 --> Model Class Initialized
DEBUG - 2024-01-24 04:06:29 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-24 04:06:29 --> Model Class Initialized
DEBUG - 2024-01-24 04:06:29 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-24 04:06:29 --> Model Class Initialized
INFO - 2024-01-24 04:06:29 --> Model Class Initialized
INFO - 2024-01-24 04:06:29 --> Model Class Initialized
INFO - 2024-01-24 04:06:29 --> Model Class Initialized
DEBUG - 2024-01-24 04:06:29 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-01-24 04:06:29 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-24 04:06:29 --> Model Class Initialized
INFO - 2024-01-24 04:06:29 --> Model Class Initialized
INFO - 2024-01-24 04:06:29 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2024-01-24 04:06:29 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-01-24 04:06:29 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-01-24 04:06:29 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-01-24 04:06:29 --> Model Class Initialized
INFO - 2024-01-24 04:06:29 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-01-24 04:06:29 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-01-24 04:06:29 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-01-24 04:06:29 --> Final output sent to browser
DEBUG - 2024-01-24 04:06:29 --> Total execution time: 0.2357
ERROR - 2024-01-24 04:06:29 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-01-24 04:06:29 --> Config Class Initialized
INFO - 2024-01-24 04:06:29 --> Hooks Class Initialized
DEBUG - 2024-01-24 04:06:29 --> UTF-8 Support Enabled
INFO - 2024-01-24 04:06:29 --> Utf8 Class Initialized
INFO - 2024-01-24 04:06:29 --> URI Class Initialized
INFO - 2024-01-24 04:06:29 --> Router Class Initialized
INFO - 2024-01-24 04:06:29 --> Output Class Initialized
INFO - 2024-01-24 04:06:29 --> Security Class Initialized
DEBUG - 2024-01-24 04:06:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-24 04:06:29 --> Input Class Initialized
INFO - 2024-01-24 04:06:29 --> Language Class Initialized
INFO - 2024-01-24 04:06:29 --> Loader Class Initialized
INFO - 2024-01-24 04:06:29 --> Helper loaded: url_helper
INFO - 2024-01-24 04:06:29 --> Helper loaded: file_helper
INFO - 2024-01-24 04:06:29 --> Helper loaded: html_helper
INFO - 2024-01-24 04:06:29 --> Helper loaded: text_helper
INFO - 2024-01-24 04:06:29 --> Helper loaded: form_helper
INFO - 2024-01-24 04:06:29 --> Helper loaded: lang_helper
INFO - 2024-01-24 04:06:29 --> Helper loaded: security_helper
INFO - 2024-01-24 04:06:29 --> Helper loaded: cookie_helper
INFO - 2024-01-24 04:06:29 --> Database Driver Class Initialized
INFO - 2024-01-24 04:06:29 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-24 04:06:29 --> Parser Class Initialized
INFO - 2024-01-24 04:06:29 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-01-24 04:06:29 --> Pagination Class Initialized
INFO - 2024-01-24 04:06:29 --> Form Validation Class Initialized
INFO - 2024-01-24 04:06:29 --> Controller Class Initialized
INFO - 2024-01-24 04:06:29 --> Model Class Initialized
DEBUG - 2024-01-24 04:06:29 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-24 04:06:29 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2024-01-24 04:06:29 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-01-24 04:06:29 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-01-24 04:06:29 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-01-24 04:06:29 --> Model Class Initialized
INFO - 2024-01-24 04:06:29 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-01-24 04:06:29 --> Final output sent to browser
DEBUG - 2024-01-24 04:06:29 --> Total execution time: 0.0316
ERROR - 2024-01-24 04:06:29 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-01-24 04:06:29 --> Config Class Initialized
INFO - 2024-01-24 04:06:29 --> Hooks Class Initialized
DEBUG - 2024-01-24 04:06:29 --> UTF-8 Support Enabled
INFO - 2024-01-24 04:06:29 --> Utf8 Class Initialized
INFO - 2024-01-24 04:06:29 --> URI Class Initialized
INFO - 2024-01-24 04:06:29 --> Router Class Initialized
INFO - 2024-01-24 04:06:29 --> Output Class Initialized
INFO - 2024-01-24 04:06:29 --> Security Class Initialized
DEBUG - 2024-01-24 04:06:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-24 04:06:29 --> Input Class Initialized
INFO - 2024-01-24 04:06:29 --> Language Class Initialized
INFO - 2024-01-24 04:06:29 --> Loader Class Initialized
INFO - 2024-01-24 04:06:29 --> Helper loaded: url_helper
INFO - 2024-01-24 04:06:29 --> Helper loaded: file_helper
INFO - 2024-01-24 04:06:29 --> Helper loaded: html_helper
INFO - 2024-01-24 04:06:29 --> Helper loaded: text_helper
INFO - 2024-01-24 04:06:29 --> Helper loaded: form_helper
INFO - 2024-01-24 04:06:29 --> Helper loaded: lang_helper
INFO - 2024-01-24 04:06:29 --> Helper loaded: security_helper
INFO - 2024-01-24 04:06:29 --> Helper loaded: cookie_helper
INFO - 2024-01-24 04:06:29 --> Database Driver Class Initialized
INFO - 2024-01-24 04:06:29 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-24 04:06:29 --> Parser Class Initialized
INFO - 2024-01-24 04:06:29 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-01-24 04:06:29 --> Pagination Class Initialized
INFO - 2024-01-24 04:06:29 --> Form Validation Class Initialized
INFO - 2024-01-24 04:06:29 --> Controller Class Initialized
INFO - 2024-01-24 04:06:29 --> Model Class Initialized
DEBUG - 2024-01-24 04:06:29 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-24 04:06:29 --> Model Class Initialized
DEBUG - 2024-01-24 04:06:29 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-24 04:06:29 --> Model Class Initialized
INFO - 2024-01-24 04:06:29 --> Model Class Initialized
INFO - 2024-01-24 04:06:29 --> Model Class Initialized
INFO - 2024-01-24 04:06:29 --> Model Class Initialized
DEBUG - 2024-01-24 04:06:29 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-01-24 04:06:29 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-24 04:06:29 --> Model Class Initialized
INFO - 2024-01-24 04:06:29 --> Model Class Initialized
INFO - 2024-01-24 04:06:30 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2024-01-24 04:06:30 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-01-24 04:06:30 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-01-24 04:06:30 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-01-24 04:06:30 --> Model Class Initialized
INFO - 2024-01-24 04:06:30 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-01-24 04:06:30 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-01-24 04:06:30 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-01-24 04:06:30 --> Final output sent to browser
DEBUG - 2024-01-24 04:06:30 --> Total execution time: 0.2313
ERROR - 2024-01-24 06:35:31 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-01-24 06:35:31 --> Config Class Initialized
INFO - 2024-01-24 06:35:31 --> Hooks Class Initialized
DEBUG - 2024-01-24 06:35:31 --> UTF-8 Support Enabled
INFO - 2024-01-24 06:35:31 --> Utf8 Class Initialized
INFO - 2024-01-24 06:35:31 --> URI Class Initialized
DEBUG - 2024-01-24 06:35:31 --> No URI present. Default controller set.
INFO - 2024-01-24 06:35:31 --> Router Class Initialized
INFO - 2024-01-24 06:35:31 --> Output Class Initialized
INFO - 2024-01-24 06:35:31 --> Security Class Initialized
DEBUG - 2024-01-24 06:35:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-24 06:35:31 --> Input Class Initialized
INFO - 2024-01-24 06:35:31 --> Language Class Initialized
INFO - 2024-01-24 06:35:31 --> Loader Class Initialized
INFO - 2024-01-24 06:35:31 --> Helper loaded: url_helper
INFO - 2024-01-24 06:35:31 --> Helper loaded: file_helper
INFO - 2024-01-24 06:35:31 --> Helper loaded: html_helper
INFO - 2024-01-24 06:35:31 --> Helper loaded: text_helper
INFO - 2024-01-24 06:35:31 --> Helper loaded: form_helper
INFO - 2024-01-24 06:35:31 --> Helper loaded: lang_helper
INFO - 2024-01-24 06:35:31 --> Helper loaded: security_helper
INFO - 2024-01-24 06:35:31 --> Helper loaded: cookie_helper
INFO - 2024-01-24 06:35:31 --> Database Driver Class Initialized
INFO - 2024-01-24 06:35:31 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-24 06:35:31 --> Parser Class Initialized
INFO - 2024-01-24 06:35:31 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-01-24 06:35:31 --> Pagination Class Initialized
INFO - 2024-01-24 06:35:31 --> Form Validation Class Initialized
INFO - 2024-01-24 06:35:31 --> Controller Class Initialized
INFO - 2024-01-24 06:35:31 --> Model Class Initialized
DEBUG - 2024-01-24 06:35:31 --> Session class already loaded. Second attempt ignored.
ERROR - 2024-01-24 06:35:32 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-01-24 06:35:32 --> Config Class Initialized
INFO - 2024-01-24 06:35:32 --> Hooks Class Initialized
DEBUG - 2024-01-24 06:35:32 --> UTF-8 Support Enabled
INFO - 2024-01-24 06:35:32 --> Utf8 Class Initialized
INFO - 2024-01-24 06:35:32 --> URI Class Initialized
INFO - 2024-01-24 06:35:32 --> Router Class Initialized
INFO - 2024-01-24 06:35:32 --> Output Class Initialized
INFO - 2024-01-24 06:35:32 --> Security Class Initialized
DEBUG - 2024-01-24 06:35:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-24 06:35:32 --> Input Class Initialized
INFO - 2024-01-24 06:35:32 --> Language Class Initialized
INFO - 2024-01-24 06:35:32 --> Loader Class Initialized
INFO - 2024-01-24 06:35:32 --> Helper loaded: url_helper
INFO - 2024-01-24 06:35:32 --> Helper loaded: file_helper
INFO - 2024-01-24 06:35:32 --> Helper loaded: html_helper
INFO - 2024-01-24 06:35:32 --> Helper loaded: text_helper
INFO - 2024-01-24 06:35:32 --> Helper loaded: form_helper
INFO - 2024-01-24 06:35:32 --> Helper loaded: lang_helper
INFO - 2024-01-24 06:35:32 --> Helper loaded: security_helper
INFO - 2024-01-24 06:35:32 --> Helper loaded: cookie_helper
INFO - 2024-01-24 06:35:32 --> Database Driver Class Initialized
INFO - 2024-01-24 06:35:32 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-24 06:35:32 --> Parser Class Initialized
INFO - 2024-01-24 06:35:32 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-01-24 06:35:32 --> Pagination Class Initialized
INFO - 2024-01-24 06:35:32 --> Form Validation Class Initialized
INFO - 2024-01-24 06:35:32 --> Controller Class Initialized
INFO - 2024-01-24 06:35:32 --> Model Class Initialized
DEBUG - 2024-01-24 06:35:32 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-24 06:35:32 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2024-01-24 06:35:32 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-01-24 06:35:32 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-01-24 06:35:32 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-01-24 06:35:32 --> Model Class Initialized
INFO - 2024-01-24 06:35:32 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-01-24 06:35:32 --> Final output sent to browser
DEBUG - 2024-01-24 06:35:32 --> Total execution time: 0.0368
ERROR - 2024-01-24 07:03:17 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-01-24 07:03:17 --> Config Class Initialized
INFO - 2024-01-24 07:03:17 --> Hooks Class Initialized
DEBUG - 2024-01-24 07:03:17 --> UTF-8 Support Enabled
INFO - 2024-01-24 07:03:17 --> Utf8 Class Initialized
INFO - 2024-01-24 07:03:17 --> URI Class Initialized
DEBUG - 2024-01-24 07:03:17 --> No URI present. Default controller set.
INFO - 2024-01-24 07:03:17 --> Router Class Initialized
INFO - 2024-01-24 07:03:17 --> Output Class Initialized
INFO - 2024-01-24 07:03:17 --> Security Class Initialized
DEBUG - 2024-01-24 07:03:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-24 07:03:17 --> Input Class Initialized
INFO - 2024-01-24 07:03:17 --> Language Class Initialized
INFO - 2024-01-24 07:03:17 --> Loader Class Initialized
INFO - 2024-01-24 07:03:17 --> Helper loaded: url_helper
INFO - 2024-01-24 07:03:17 --> Helper loaded: file_helper
INFO - 2024-01-24 07:03:17 --> Helper loaded: html_helper
INFO - 2024-01-24 07:03:17 --> Helper loaded: text_helper
INFO - 2024-01-24 07:03:17 --> Helper loaded: form_helper
INFO - 2024-01-24 07:03:17 --> Helper loaded: lang_helper
INFO - 2024-01-24 07:03:17 --> Helper loaded: security_helper
INFO - 2024-01-24 07:03:17 --> Helper loaded: cookie_helper
INFO - 2024-01-24 07:03:17 --> Database Driver Class Initialized
INFO - 2024-01-24 07:03:17 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-24 07:03:17 --> Parser Class Initialized
INFO - 2024-01-24 07:03:17 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-01-24 07:03:17 --> Pagination Class Initialized
INFO - 2024-01-24 07:03:17 --> Form Validation Class Initialized
INFO - 2024-01-24 07:03:17 --> Controller Class Initialized
INFO - 2024-01-24 07:03:17 --> Model Class Initialized
DEBUG - 2024-01-24 07:03:17 --> Session class already loaded. Second attempt ignored.
ERROR - 2024-01-24 07:03:17 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-01-24 07:03:17 --> Config Class Initialized
INFO - 2024-01-24 07:03:17 --> Hooks Class Initialized
DEBUG - 2024-01-24 07:03:17 --> UTF-8 Support Enabled
INFO - 2024-01-24 07:03:17 --> Utf8 Class Initialized
INFO - 2024-01-24 07:03:17 --> URI Class Initialized
INFO - 2024-01-24 07:03:17 --> Router Class Initialized
INFO - 2024-01-24 07:03:17 --> Output Class Initialized
INFO - 2024-01-24 07:03:17 --> Security Class Initialized
DEBUG - 2024-01-24 07:03:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-24 07:03:17 --> Input Class Initialized
INFO - 2024-01-24 07:03:17 --> Language Class Initialized
INFO - 2024-01-24 07:03:17 --> Loader Class Initialized
INFO - 2024-01-24 07:03:17 --> Helper loaded: url_helper
INFO - 2024-01-24 07:03:17 --> Helper loaded: file_helper
INFO - 2024-01-24 07:03:17 --> Helper loaded: html_helper
INFO - 2024-01-24 07:03:17 --> Helper loaded: text_helper
INFO - 2024-01-24 07:03:17 --> Helper loaded: form_helper
INFO - 2024-01-24 07:03:17 --> Helper loaded: lang_helper
INFO - 2024-01-24 07:03:17 --> Helper loaded: security_helper
INFO - 2024-01-24 07:03:17 --> Helper loaded: cookie_helper
INFO - 2024-01-24 07:03:17 --> Database Driver Class Initialized
INFO - 2024-01-24 07:03:17 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-24 07:03:17 --> Parser Class Initialized
INFO - 2024-01-24 07:03:17 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-01-24 07:03:17 --> Pagination Class Initialized
INFO - 2024-01-24 07:03:17 --> Form Validation Class Initialized
INFO - 2024-01-24 07:03:17 --> Controller Class Initialized
INFO - 2024-01-24 07:03:17 --> Model Class Initialized
DEBUG - 2024-01-24 07:03:17 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-24 07:03:17 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2024-01-24 07:03:17 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-01-24 07:03:17 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-01-24 07:03:17 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-01-24 07:03:17 --> Model Class Initialized
INFO - 2024-01-24 07:03:17 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-01-24 07:03:17 --> Final output sent to browser
DEBUG - 2024-01-24 07:03:17 --> Total execution time: 0.0320
ERROR - 2024-01-24 07:03:45 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-01-24 07:03:45 --> Config Class Initialized
INFO - 2024-01-24 07:03:45 --> Hooks Class Initialized
DEBUG - 2024-01-24 07:03:45 --> UTF-8 Support Enabled
INFO - 2024-01-24 07:03:45 --> Utf8 Class Initialized
INFO - 2024-01-24 07:03:45 --> URI Class Initialized
INFO - 2024-01-24 07:03:45 --> Router Class Initialized
INFO - 2024-01-24 07:03:45 --> Output Class Initialized
INFO - 2024-01-24 07:03:45 --> Security Class Initialized
DEBUG - 2024-01-24 07:03:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-24 07:03:45 --> Input Class Initialized
INFO - 2024-01-24 07:03:45 --> Language Class Initialized
INFO - 2024-01-24 07:03:45 --> Loader Class Initialized
INFO - 2024-01-24 07:03:45 --> Helper loaded: url_helper
INFO - 2024-01-24 07:03:45 --> Helper loaded: file_helper
INFO - 2024-01-24 07:03:45 --> Helper loaded: html_helper
INFO - 2024-01-24 07:03:45 --> Helper loaded: text_helper
INFO - 2024-01-24 07:03:45 --> Helper loaded: form_helper
INFO - 2024-01-24 07:03:45 --> Helper loaded: lang_helper
INFO - 2024-01-24 07:03:45 --> Helper loaded: security_helper
INFO - 2024-01-24 07:03:45 --> Helper loaded: cookie_helper
INFO - 2024-01-24 07:03:45 --> Database Driver Class Initialized
INFO - 2024-01-24 07:03:45 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-24 07:03:45 --> Parser Class Initialized
INFO - 2024-01-24 07:03:45 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-01-24 07:03:45 --> Pagination Class Initialized
INFO - 2024-01-24 07:03:45 --> Form Validation Class Initialized
INFO - 2024-01-24 07:03:45 --> Controller Class Initialized
INFO - 2024-01-24 07:03:45 --> Model Class Initialized
DEBUG - 2024-01-24 07:03:45 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-24 07:03:45 --> Model Class Initialized
INFO - 2024-01-24 07:03:45 --> Final output sent to browser
DEBUG - 2024-01-24 07:03:45 --> Total execution time: 0.0280
ERROR - 2024-01-24 07:03:45 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-01-24 07:03:45 --> Config Class Initialized
INFO - 2024-01-24 07:03:45 --> Hooks Class Initialized
DEBUG - 2024-01-24 07:03:45 --> UTF-8 Support Enabled
INFO - 2024-01-24 07:03:45 --> Utf8 Class Initialized
INFO - 2024-01-24 07:03:45 --> URI Class Initialized
DEBUG - 2024-01-24 07:03:45 --> No URI present. Default controller set.
INFO - 2024-01-24 07:03:45 --> Router Class Initialized
INFO - 2024-01-24 07:03:45 --> Output Class Initialized
INFO - 2024-01-24 07:03:45 --> Security Class Initialized
DEBUG - 2024-01-24 07:03:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-24 07:03:45 --> Input Class Initialized
INFO - 2024-01-24 07:03:45 --> Language Class Initialized
INFO - 2024-01-24 07:03:45 --> Loader Class Initialized
INFO - 2024-01-24 07:03:45 --> Helper loaded: url_helper
INFO - 2024-01-24 07:03:45 --> Helper loaded: file_helper
INFO - 2024-01-24 07:03:45 --> Helper loaded: html_helper
INFO - 2024-01-24 07:03:45 --> Helper loaded: text_helper
INFO - 2024-01-24 07:03:45 --> Helper loaded: form_helper
INFO - 2024-01-24 07:03:45 --> Helper loaded: lang_helper
INFO - 2024-01-24 07:03:45 --> Helper loaded: security_helper
INFO - 2024-01-24 07:03:45 --> Helper loaded: cookie_helper
INFO - 2024-01-24 07:03:45 --> Database Driver Class Initialized
INFO - 2024-01-24 07:03:45 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-24 07:03:45 --> Parser Class Initialized
INFO - 2024-01-24 07:03:45 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-01-24 07:03:45 --> Pagination Class Initialized
INFO - 2024-01-24 07:03:45 --> Form Validation Class Initialized
INFO - 2024-01-24 07:03:45 --> Controller Class Initialized
INFO - 2024-01-24 07:03:45 --> Model Class Initialized
DEBUG - 2024-01-24 07:03:45 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-24 07:03:45 --> Model Class Initialized
DEBUG - 2024-01-24 07:03:45 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-24 07:03:45 --> Model Class Initialized
INFO - 2024-01-24 07:03:45 --> Model Class Initialized
INFO - 2024-01-24 07:03:45 --> Model Class Initialized
INFO - 2024-01-24 07:03:45 --> Model Class Initialized
DEBUG - 2024-01-24 07:03:45 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-01-24 07:03:45 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-24 07:03:45 --> Model Class Initialized
INFO - 2024-01-24 07:03:45 --> Model Class Initialized
INFO - 2024-01-24 07:03:45 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2024-01-24 07:03:45 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-01-24 07:03:45 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-01-24 07:03:45 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-01-24 07:03:45 --> Model Class Initialized
INFO - 2024-01-24 07:03:45 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-01-24 07:03:45 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-01-24 07:03:45 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-01-24 07:03:45 --> Final output sent to browser
DEBUG - 2024-01-24 07:03:45 --> Total execution time: 0.2557
ERROR - 2024-01-24 08:54:01 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-01-24 08:54:01 --> Config Class Initialized
INFO - 2024-01-24 08:54:01 --> Hooks Class Initialized
DEBUG - 2024-01-24 08:54:01 --> UTF-8 Support Enabled
INFO - 2024-01-24 08:54:01 --> Utf8 Class Initialized
INFO - 2024-01-24 08:54:01 --> URI Class Initialized
DEBUG - 2024-01-24 08:54:01 --> No URI present. Default controller set.
INFO - 2024-01-24 08:54:01 --> Router Class Initialized
INFO - 2024-01-24 08:54:01 --> Output Class Initialized
INFO - 2024-01-24 08:54:01 --> Security Class Initialized
DEBUG - 2024-01-24 08:54:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-24 08:54:01 --> Input Class Initialized
INFO - 2024-01-24 08:54:01 --> Language Class Initialized
INFO - 2024-01-24 08:54:01 --> Loader Class Initialized
INFO - 2024-01-24 08:54:01 --> Helper loaded: url_helper
INFO - 2024-01-24 08:54:01 --> Helper loaded: file_helper
INFO - 2024-01-24 08:54:01 --> Helper loaded: html_helper
INFO - 2024-01-24 08:54:01 --> Helper loaded: text_helper
INFO - 2024-01-24 08:54:01 --> Helper loaded: form_helper
INFO - 2024-01-24 08:54:01 --> Helper loaded: lang_helper
INFO - 2024-01-24 08:54:01 --> Helper loaded: security_helper
INFO - 2024-01-24 08:54:01 --> Helper loaded: cookie_helper
INFO - 2024-01-24 08:54:01 --> Database Driver Class Initialized
INFO - 2024-01-24 08:54:01 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-24 08:54:01 --> Parser Class Initialized
INFO - 2024-01-24 08:54:01 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-01-24 08:54:01 --> Pagination Class Initialized
INFO - 2024-01-24 08:54:01 --> Form Validation Class Initialized
INFO - 2024-01-24 08:54:01 --> Controller Class Initialized
INFO - 2024-01-24 08:54:01 --> Model Class Initialized
DEBUG - 2024-01-24 08:54:01 --> Session class already loaded. Second attempt ignored.
ERROR - 2024-01-24 08:54:02 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-01-24 08:54:02 --> Config Class Initialized
INFO - 2024-01-24 08:54:02 --> Hooks Class Initialized
DEBUG - 2024-01-24 08:54:02 --> UTF-8 Support Enabled
INFO - 2024-01-24 08:54:02 --> Utf8 Class Initialized
INFO - 2024-01-24 08:54:02 --> URI Class Initialized
INFO - 2024-01-24 08:54:02 --> Router Class Initialized
INFO - 2024-01-24 08:54:02 --> Output Class Initialized
INFO - 2024-01-24 08:54:02 --> Security Class Initialized
DEBUG - 2024-01-24 08:54:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-24 08:54:02 --> Input Class Initialized
INFO - 2024-01-24 08:54:02 --> Language Class Initialized
INFO - 2024-01-24 08:54:02 --> Loader Class Initialized
INFO - 2024-01-24 08:54:02 --> Helper loaded: url_helper
INFO - 2024-01-24 08:54:02 --> Helper loaded: file_helper
INFO - 2024-01-24 08:54:02 --> Helper loaded: html_helper
INFO - 2024-01-24 08:54:02 --> Helper loaded: text_helper
INFO - 2024-01-24 08:54:02 --> Helper loaded: form_helper
INFO - 2024-01-24 08:54:02 --> Helper loaded: lang_helper
INFO - 2024-01-24 08:54:02 --> Helper loaded: security_helper
INFO - 2024-01-24 08:54:02 --> Helper loaded: cookie_helper
INFO - 2024-01-24 08:54:02 --> Database Driver Class Initialized
INFO - 2024-01-24 08:54:02 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-24 08:54:02 --> Parser Class Initialized
INFO - 2024-01-24 08:54:02 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-01-24 08:54:02 --> Pagination Class Initialized
INFO - 2024-01-24 08:54:02 --> Form Validation Class Initialized
INFO - 2024-01-24 08:54:02 --> Controller Class Initialized
INFO - 2024-01-24 08:54:02 --> Model Class Initialized
DEBUG - 2024-01-24 08:54:02 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-24 08:54:02 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2024-01-24 08:54:02 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-01-24 08:54:02 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-01-24 08:54:02 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-01-24 08:54:02 --> Model Class Initialized
INFO - 2024-01-24 08:54:02 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-01-24 08:54:02 --> Final output sent to browser
DEBUG - 2024-01-24 08:54:02 --> Total execution time: 0.0359
ERROR - 2024-01-24 08:54:09 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-01-24 08:54:09 --> Config Class Initialized
INFO - 2024-01-24 08:54:09 --> Hooks Class Initialized
DEBUG - 2024-01-24 08:54:09 --> UTF-8 Support Enabled
INFO - 2024-01-24 08:54:09 --> Utf8 Class Initialized
INFO - 2024-01-24 08:54:09 --> URI Class Initialized
INFO - 2024-01-24 08:54:09 --> Router Class Initialized
INFO - 2024-01-24 08:54:09 --> Output Class Initialized
INFO - 2024-01-24 08:54:09 --> Security Class Initialized
DEBUG - 2024-01-24 08:54:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-24 08:54:09 --> Input Class Initialized
INFO - 2024-01-24 08:54:09 --> Language Class Initialized
INFO - 2024-01-24 08:54:09 --> Loader Class Initialized
INFO - 2024-01-24 08:54:09 --> Helper loaded: url_helper
INFO - 2024-01-24 08:54:09 --> Helper loaded: file_helper
INFO - 2024-01-24 08:54:09 --> Helper loaded: html_helper
INFO - 2024-01-24 08:54:09 --> Helper loaded: text_helper
INFO - 2024-01-24 08:54:09 --> Helper loaded: form_helper
INFO - 2024-01-24 08:54:09 --> Helper loaded: lang_helper
INFO - 2024-01-24 08:54:09 --> Helper loaded: security_helper
INFO - 2024-01-24 08:54:09 --> Helper loaded: cookie_helper
INFO - 2024-01-24 08:54:09 --> Database Driver Class Initialized
INFO - 2024-01-24 08:54:09 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-24 08:54:09 --> Parser Class Initialized
INFO - 2024-01-24 08:54:09 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-01-24 08:54:09 --> Pagination Class Initialized
INFO - 2024-01-24 08:54:09 --> Form Validation Class Initialized
INFO - 2024-01-24 08:54:09 --> Controller Class Initialized
INFO - 2024-01-24 08:54:09 --> Model Class Initialized
DEBUG - 2024-01-24 08:54:09 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-24 08:54:09 --> Model Class Initialized
INFO - 2024-01-24 08:54:09 --> Final output sent to browser
DEBUG - 2024-01-24 08:54:09 --> Total execution time: 0.0192
ERROR - 2024-01-24 08:54:09 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-01-24 08:54:09 --> Config Class Initialized
INFO - 2024-01-24 08:54:09 --> Hooks Class Initialized
DEBUG - 2024-01-24 08:54:09 --> UTF-8 Support Enabled
INFO - 2024-01-24 08:54:09 --> Utf8 Class Initialized
INFO - 2024-01-24 08:54:09 --> URI Class Initialized
DEBUG - 2024-01-24 08:54:09 --> No URI present. Default controller set.
INFO - 2024-01-24 08:54:09 --> Router Class Initialized
INFO - 2024-01-24 08:54:09 --> Output Class Initialized
INFO - 2024-01-24 08:54:09 --> Security Class Initialized
DEBUG - 2024-01-24 08:54:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-24 08:54:09 --> Input Class Initialized
INFO - 2024-01-24 08:54:09 --> Language Class Initialized
INFO - 2024-01-24 08:54:09 --> Loader Class Initialized
INFO - 2024-01-24 08:54:09 --> Helper loaded: url_helper
INFO - 2024-01-24 08:54:09 --> Helper loaded: file_helper
INFO - 2024-01-24 08:54:09 --> Helper loaded: html_helper
INFO - 2024-01-24 08:54:09 --> Helper loaded: text_helper
INFO - 2024-01-24 08:54:09 --> Helper loaded: form_helper
INFO - 2024-01-24 08:54:09 --> Helper loaded: lang_helper
INFO - 2024-01-24 08:54:09 --> Helper loaded: security_helper
INFO - 2024-01-24 08:54:09 --> Helper loaded: cookie_helper
INFO - 2024-01-24 08:54:09 --> Database Driver Class Initialized
INFO - 2024-01-24 08:54:09 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-24 08:54:09 --> Parser Class Initialized
INFO - 2024-01-24 08:54:09 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-01-24 08:54:09 --> Pagination Class Initialized
INFO - 2024-01-24 08:54:09 --> Form Validation Class Initialized
INFO - 2024-01-24 08:54:09 --> Controller Class Initialized
INFO - 2024-01-24 08:54:09 --> Model Class Initialized
DEBUG - 2024-01-24 08:54:09 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-24 08:54:09 --> Model Class Initialized
DEBUG - 2024-01-24 08:54:09 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-24 08:54:09 --> Model Class Initialized
INFO - 2024-01-24 08:54:09 --> Model Class Initialized
INFO - 2024-01-24 08:54:09 --> Model Class Initialized
INFO - 2024-01-24 08:54:09 --> Model Class Initialized
DEBUG - 2024-01-24 08:54:09 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-01-24 08:54:09 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-24 08:54:09 --> Model Class Initialized
INFO - 2024-01-24 08:54:09 --> Model Class Initialized
INFO - 2024-01-24 08:54:09 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2024-01-24 08:54:09 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-01-24 08:54:09 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-01-24 08:54:09 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-01-24 08:54:09 --> Model Class Initialized
INFO - 2024-01-24 08:54:10 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-01-24 08:54:10 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-01-24 08:54:10 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-01-24 08:54:10 --> Final output sent to browser
DEBUG - 2024-01-24 08:54:10 --> Total execution time: 0.4098
ERROR - 2024-01-24 08:54:10 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-01-24 08:54:10 --> Config Class Initialized
INFO - 2024-01-24 08:54:10 --> Hooks Class Initialized
DEBUG - 2024-01-24 08:54:10 --> UTF-8 Support Enabled
INFO - 2024-01-24 08:54:10 --> Utf8 Class Initialized
INFO - 2024-01-24 08:54:10 --> URI Class Initialized
INFO - 2024-01-24 08:54:10 --> Router Class Initialized
INFO - 2024-01-24 08:54:10 --> Output Class Initialized
INFO - 2024-01-24 08:54:10 --> Security Class Initialized
DEBUG - 2024-01-24 08:54:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-24 08:54:10 --> Input Class Initialized
INFO - 2024-01-24 08:54:10 --> Language Class Initialized
INFO - 2024-01-24 08:54:10 --> Loader Class Initialized
INFO - 2024-01-24 08:54:10 --> Helper loaded: url_helper
INFO - 2024-01-24 08:54:10 --> Helper loaded: file_helper
INFO - 2024-01-24 08:54:10 --> Helper loaded: html_helper
INFO - 2024-01-24 08:54:10 --> Helper loaded: text_helper
INFO - 2024-01-24 08:54:10 --> Helper loaded: form_helper
INFO - 2024-01-24 08:54:10 --> Helper loaded: lang_helper
INFO - 2024-01-24 08:54:10 --> Helper loaded: security_helper
INFO - 2024-01-24 08:54:10 --> Helper loaded: cookie_helper
INFO - 2024-01-24 08:54:10 --> Database Driver Class Initialized
INFO - 2024-01-24 08:54:10 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-24 08:54:10 --> Parser Class Initialized
INFO - 2024-01-24 08:54:10 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-01-24 08:54:10 --> Pagination Class Initialized
INFO - 2024-01-24 08:54:10 --> Form Validation Class Initialized
INFO - 2024-01-24 08:54:10 --> Controller Class Initialized
DEBUG - 2024-01-24 08:54:10 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-01-24 08:54:10 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-24 08:54:10 --> Model Class Initialized
INFO - 2024-01-24 08:54:10 --> Final output sent to browser
DEBUG - 2024-01-24 08:54:10 --> Total execution time: 0.0125
ERROR - 2024-01-24 08:54:20 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-01-24 08:54:20 --> Config Class Initialized
INFO - 2024-01-24 08:54:20 --> Hooks Class Initialized
DEBUG - 2024-01-24 08:54:20 --> UTF-8 Support Enabled
INFO - 2024-01-24 08:54:20 --> Utf8 Class Initialized
INFO - 2024-01-24 08:54:20 --> URI Class Initialized
INFO - 2024-01-24 08:54:20 --> Router Class Initialized
INFO - 2024-01-24 08:54:20 --> Output Class Initialized
INFO - 2024-01-24 08:54:20 --> Security Class Initialized
DEBUG - 2024-01-24 08:54:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-24 08:54:20 --> Input Class Initialized
INFO - 2024-01-24 08:54:20 --> Language Class Initialized
INFO - 2024-01-24 08:54:20 --> Loader Class Initialized
INFO - 2024-01-24 08:54:20 --> Helper loaded: url_helper
INFO - 2024-01-24 08:54:20 --> Helper loaded: file_helper
INFO - 2024-01-24 08:54:20 --> Helper loaded: html_helper
INFO - 2024-01-24 08:54:20 --> Helper loaded: text_helper
INFO - 2024-01-24 08:54:20 --> Helper loaded: form_helper
INFO - 2024-01-24 08:54:20 --> Helper loaded: lang_helper
INFO - 2024-01-24 08:54:20 --> Helper loaded: security_helper
INFO - 2024-01-24 08:54:20 --> Helper loaded: cookie_helper
INFO - 2024-01-24 08:54:20 --> Database Driver Class Initialized
INFO - 2024-01-24 08:54:20 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-24 08:54:20 --> Parser Class Initialized
INFO - 2024-01-24 08:54:20 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-01-24 08:54:20 --> Pagination Class Initialized
INFO - 2024-01-24 08:54:20 --> Form Validation Class Initialized
INFO - 2024-01-24 08:54:20 --> Controller Class Initialized
DEBUG - 2024-01-24 08:54:20 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-01-24 08:54:20 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-24 08:54:20 --> Model Class Initialized
DEBUG - 2024-01-24 08:54:20 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-24 08:54:20 --> Model Class Initialized
DEBUG - 2024-01-24 08:54:20 --> Lcustomer class already loaded. Second attempt ignored.
INFO - 2024-01-24 08:54:20 --> Model Class Initialized
INFO - 2024-01-24 08:54:20 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/customer/customer.php
DEBUG - 2024-01-24 08:54:20 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-01-24 08:54:20 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-01-24 08:54:20 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-01-24 08:54:20 --> Model Class Initialized
INFO - 2024-01-24 08:54:20 --> Model Class Initialized
INFO - 2024-01-24 08:54:20 --> Model Class Initialized
INFO - 2024-01-24 08:54:20 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-01-24 08:54:20 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-01-24 08:54:20 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-01-24 08:54:20 --> Final output sent to browser
DEBUG - 2024-01-24 08:54:20 --> Total execution time: 0.2134
ERROR - 2024-01-24 08:54:21 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-01-24 08:54:21 --> Config Class Initialized
INFO - 2024-01-24 08:54:21 --> Hooks Class Initialized
DEBUG - 2024-01-24 08:54:21 --> UTF-8 Support Enabled
INFO - 2024-01-24 08:54:21 --> Utf8 Class Initialized
INFO - 2024-01-24 08:54:21 --> URI Class Initialized
INFO - 2024-01-24 08:54:21 --> Router Class Initialized
INFO - 2024-01-24 08:54:21 --> Output Class Initialized
INFO - 2024-01-24 08:54:21 --> Security Class Initialized
DEBUG - 2024-01-24 08:54:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-24 08:54:21 --> Input Class Initialized
INFO - 2024-01-24 08:54:21 --> Language Class Initialized
INFO - 2024-01-24 08:54:21 --> Loader Class Initialized
INFO - 2024-01-24 08:54:21 --> Helper loaded: url_helper
INFO - 2024-01-24 08:54:21 --> Helper loaded: file_helper
INFO - 2024-01-24 08:54:21 --> Helper loaded: html_helper
INFO - 2024-01-24 08:54:21 --> Helper loaded: text_helper
INFO - 2024-01-24 08:54:21 --> Helper loaded: form_helper
INFO - 2024-01-24 08:54:21 --> Helper loaded: lang_helper
INFO - 2024-01-24 08:54:21 --> Helper loaded: security_helper
INFO - 2024-01-24 08:54:21 --> Helper loaded: cookie_helper
INFO - 2024-01-24 08:54:21 --> Database Driver Class Initialized
INFO - 2024-01-24 08:54:21 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-24 08:54:21 --> Parser Class Initialized
INFO - 2024-01-24 08:54:21 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-01-24 08:54:21 --> Pagination Class Initialized
INFO - 2024-01-24 08:54:21 --> Form Validation Class Initialized
INFO - 2024-01-24 08:54:21 --> Controller Class Initialized
DEBUG - 2024-01-24 08:54:21 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-01-24 08:54:21 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-24 08:54:21 --> Model Class Initialized
DEBUG - 2024-01-24 08:54:21 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-24 08:54:21 --> Model Class Initialized
INFO - 2024-01-24 08:54:21 --> Final output sent to browser
DEBUG - 2024-01-24 08:54:21 --> Total execution time: 0.0342
ERROR - 2024-01-24 10:27:28 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-01-24 10:27:28 --> Config Class Initialized
INFO - 2024-01-24 10:27:28 --> Hooks Class Initialized
DEBUG - 2024-01-24 10:27:28 --> UTF-8 Support Enabled
INFO - 2024-01-24 10:27:28 --> Utf8 Class Initialized
INFO - 2024-01-24 10:27:28 --> URI Class Initialized
DEBUG - 2024-01-24 10:27:28 --> No URI present. Default controller set.
INFO - 2024-01-24 10:27:28 --> Router Class Initialized
INFO - 2024-01-24 10:27:28 --> Output Class Initialized
INFO - 2024-01-24 10:27:28 --> Security Class Initialized
DEBUG - 2024-01-24 10:27:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-24 10:27:28 --> Input Class Initialized
INFO - 2024-01-24 10:27:28 --> Language Class Initialized
INFO - 2024-01-24 10:27:28 --> Loader Class Initialized
INFO - 2024-01-24 10:27:28 --> Helper loaded: url_helper
INFO - 2024-01-24 10:27:28 --> Helper loaded: file_helper
INFO - 2024-01-24 10:27:28 --> Helper loaded: html_helper
INFO - 2024-01-24 10:27:28 --> Helper loaded: text_helper
INFO - 2024-01-24 10:27:28 --> Helper loaded: form_helper
INFO - 2024-01-24 10:27:28 --> Helper loaded: lang_helper
INFO - 2024-01-24 10:27:28 --> Helper loaded: security_helper
INFO - 2024-01-24 10:27:28 --> Helper loaded: cookie_helper
INFO - 2024-01-24 10:27:28 --> Database Driver Class Initialized
INFO - 2024-01-24 10:27:28 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-24 10:27:28 --> Parser Class Initialized
INFO - 2024-01-24 10:27:28 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-01-24 10:27:28 --> Pagination Class Initialized
INFO - 2024-01-24 10:27:28 --> Form Validation Class Initialized
INFO - 2024-01-24 10:27:28 --> Controller Class Initialized
INFO - 2024-01-24 10:27:28 --> Model Class Initialized
DEBUG - 2024-01-24 10:27:28 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-24 10:27:28 --> Model Class Initialized
DEBUG - 2024-01-24 10:27:28 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-24 10:27:28 --> Model Class Initialized
INFO - 2024-01-24 10:27:28 --> Model Class Initialized
INFO - 2024-01-24 10:27:28 --> Model Class Initialized
INFO - 2024-01-24 10:27:28 --> Model Class Initialized
DEBUG - 2024-01-24 10:27:28 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-01-24 10:27:28 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-24 10:27:28 --> Model Class Initialized
INFO - 2024-01-24 10:27:28 --> Model Class Initialized
INFO - 2024-01-24 10:27:28 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2024-01-24 10:27:28 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-01-24 10:27:28 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-01-24 10:27:28 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-01-24 10:27:28 --> Model Class Initialized
INFO - 2024-01-24 10:27:29 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-01-24 10:27:29 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-01-24 10:27:29 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-01-24 10:27:29 --> Final output sent to browser
DEBUG - 2024-01-24 10:27:29 --> Total execution time: 0.4193
ERROR - 2024-01-24 10:27:34 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-01-24 10:27:34 --> Config Class Initialized
INFO - 2024-01-24 10:27:34 --> Hooks Class Initialized
DEBUG - 2024-01-24 10:27:34 --> UTF-8 Support Enabled
INFO - 2024-01-24 10:27:34 --> Utf8 Class Initialized
INFO - 2024-01-24 10:27:34 --> URI Class Initialized
INFO - 2024-01-24 10:27:34 --> Router Class Initialized
INFO - 2024-01-24 10:27:34 --> Output Class Initialized
INFO - 2024-01-24 10:27:34 --> Security Class Initialized
DEBUG - 2024-01-24 10:27:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-24 10:27:34 --> Input Class Initialized
INFO - 2024-01-24 10:27:34 --> Language Class Initialized
INFO - 2024-01-24 10:27:34 --> Loader Class Initialized
INFO - 2024-01-24 10:27:34 --> Helper loaded: url_helper
INFO - 2024-01-24 10:27:34 --> Helper loaded: file_helper
INFO - 2024-01-24 10:27:34 --> Helper loaded: html_helper
INFO - 2024-01-24 10:27:34 --> Helper loaded: text_helper
INFO - 2024-01-24 10:27:34 --> Helper loaded: form_helper
INFO - 2024-01-24 10:27:34 --> Helper loaded: lang_helper
INFO - 2024-01-24 10:27:34 --> Helper loaded: security_helper
INFO - 2024-01-24 10:27:34 --> Helper loaded: cookie_helper
INFO - 2024-01-24 10:27:34 --> Database Driver Class Initialized
INFO - 2024-01-24 10:27:34 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-24 10:27:34 --> Parser Class Initialized
INFO - 2024-01-24 10:27:34 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-01-24 10:27:34 --> Pagination Class Initialized
INFO - 2024-01-24 10:27:34 --> Form Validation Class Initialized
INFO - 2024-01-24 10:27:34 --> Controller Class Initialized
INFO - 2024-01-24 10:27:34 --> Model Class Initialized
DEBUG - 2024-01-24 10:27:34 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-24 10:27:34 --> Final output sent to browser
DEBUG - 2024-01-24 10:27:34 --> Total execution time: 0.0133
ERROR - 2024-01-24 10:27:34 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-01-24 10:27:34 --> Config Class Initialized
INFO - 2024-01-24 10:27:34 --> Hooks Class Initialized
DEBUG - 2024-01-24 10:27:34 --> UTF-8 Support Enabled
INFO - 2024-01-24 10:27:34 --> Utf8 Class Initialized
INFO - 2024-01-24 10:27:34 --> URI Class Initialized
INFO - 2024-01-24 10:27:34 --> Router Class Initialized
INFO - 2024-01-24 10:27:34 --> Output Class Initialized
INFO - 2024-01-24 10:27:34 --> Security Class Initialized
DEBUG - 2024-01-24 10:27:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-24 10:27:34 --> Input Class Initialized
INFO - 2024-01-24 10:27:34 --> Language Class Initialized
INFO - 2024-01-24 10:27:34 --> Loader Class Initialized
INFO - 2024-01-24 10:27:34 --> Helper loaded: url_helper
INFO - 2024-01-24 10:27:34 --> Helper loaded: file_helper
INFO - 2024-01-24 10:27:34 --> Helper loaded: html_helper
INFO - 2024-01-24 10:27:34 --> Helper loaded: text_helper
INFO - 2024-01-24 10:27:34 --> Helper loaded: form_helper
INFO - 2024-01-24 10:27:34 --> Helper loaded: lang_helper
INFO - 2024-01-24 10:27:34 --> Helper loaded: security_helper
INFO - 2024-01-24 10:27:34 --> Helper loaded: cookie_helper
INFO - 2024-01-24 10:27:34 --> Database Driver Class Initialized
INFO - 2024-01-24 10:27:34 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-24 10:27:34 --> Parser Class Initialized
INFO - 2024-01-24 10:27:34 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-01-24 10:27:34 --> Pagination Class Initialized
INFO - 2024-01-24 10:27:34 --> Form Validation Class Initialized
INFO - 2024-01-24 10:27:34 --> Controller Class Initialized
INFO - 2024-01-24 10:27:34 --> Model Class Initialized
DEBUG - 2024-01-24 10:27:34 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-24 10:27:34 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2024-01-24 10:27:34 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-01-24 10:27:34 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-01-24 10:27:34 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-01-24 10:27:34 --> Model Class Initialized
INFO - 2024-01-24 10:27:34 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-01-24 10:27:34 --> Final output sent to browser
DEBUG - 2024-01-24 10:27:34 --> Total execution time: 0.0352
ERROR - 2024-01-24 10:27:41 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-01-24 10:27:41 --> Config Class Initialized
INFO - 2024-01-24 10:27:41 --> Hooks Class Initialized
DEBUG - 2024-01-24 10:27:41 --> UTF-8 Support Enabled
INFO - 2024-01-24 10:27:41 --> Utf8 Class Initialized
INFO - 2024-01-24 10:27:41 --> URI Class Initialized
INFO - 2024-01-24 10:27:41 --> Router Class Initialized
INFO - 2024-01-24 10:27:41 --> Output Class Initialized
INFO - 2024-01-24 10:27:41 --> Security Class Initialized
DEBUG - 2024-01-24 10:27:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-24 10:27:41 --> Input Class Initialized
INFO - 2024-01-24 10:27:41 --> Language Class Initialized
INFO - 2024-01-24 10:27:41 --> Loader Class Initialized
INFO - 2024-01-24 10:27:41 --> Helper loaded: url_helper
INFO - 2024-01-24 10:27:41 --> Helper loaded: file_helper
INFO - 2024-01-24 10:27:41 --> Helper loaded: html_helper
INFO - 2024-01-24 10:27:41 --> Helper loaded: text_helper
INFO - 2024-01-24 10:27:41 --> Helper loaded: form_helper
INFO - 2024-01-24 10:27:41 --> Helper loaded: lang_helper
INFO - 2024-01-24 10:27:41 --> Helper loaded: security_helper
INFO - 2024-01-24 10:27:41 --> Helper loaded: cookie_helper
INFO - 2024-01-24 10:27:41 --> Database Driver Class Initialized
INFO - 2024-01-24 10:27:41 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-24 10:27:41 --> Parser Class Initialized
INFO - 2024-01-24 10:27:41 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-01-24 10:27:41 --> Pagination Class Initialized
INFO - 2024-01-24 10:27:41 --> Form Validation Class Initialized
INFO - 2024-01-24 10:27:41 --> Controller Class Initialized
INFO - 2024-01-24 10:27:41 --> Model Class Initialized
DEBUG - 2024-01-24 10:27:41 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-24 10:27:41 --> Model Class Initialized
INFO - 2024-01-24 10:27:41 --> Final output sent to browser
DEBUG - 2024-01-24 10:27:41 --> Total execution time: 0.0173
ERROR - 2024-01-24 10:27:41 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-01-24 10:27:41 --> Config Class Initialized
INFO - 2024-01-24 10:27:41 --> Hooks Class Initialized
DEBUG - 2024-01-24 10:27:41 --> UTF-8 Support Enabled
INFO - 2024-01-24 10:27:41 --> Utf8 Class Initialized
INFO - 2024-01-24 10:27:41 --> URI Class Initialized
DEBUG - 2024-01-24 10:27:41 --> No URI present. Default controller set.
INFO - 2024-01-24 10:27:41 --> Router Class Initialized
INFO - 2024-01-24 10:27:41 --> Output Class Initialized
INFO - 2024-01-24 10:27:41 --> Security Class Initialized
DEBUG - 2024-01-24 10:27:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-24 10:27:41 --> Input Class Initialized
INFO - 2024-01-24 10:27:41 --> Language Class Initialized
INFO - 2024-01-24 10:27:41 --> Loader Class Initialized
INFO - 2024-01-24 10:27:41 --> Helper loaded: url_helper
INFO - 2024-01-24 10:27:41 --> Helper loaded: file_helper
INFO - 2024-01-24 10:27:41 --> Helper loaded: html_helper
INFO - 2024-01-24 10:27:41 --> Helper loaded: text_helper
INFO - 2024-01-24 10:27:41 --> Helper loaded: form_helper
INFO - 2024-01-24 10:27:41 --> Helper loaded: lang_helper
INFO - 2024-01-24 10:27:41 --> Helper loaded: security_helper
INFO - 2024-01-24 10:27:41 --> Helper loaded: cookie_helper
INFO - 2024-01-24 10:27:41 --> Database Driver Class Initialized
INFO - 2024-01-24 10:27:41 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-24 10:27:41 --> Parser Class Initialized
INFO - 2024-01-24 10:27:41 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-01-24 10:27:41 --> Pagination Class Initialized
INFO - 2024-01-24 10:27:41 --> Form Validation Class Initialized
INFO - 2024-01-24 10:27:41 --> Controller Class Initialized
INFO - 2024-01-24 10:27:41 --> Model Class Initialized
DEBUG - 2024-01-24 10:27:41 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-24 10:27:41 --> Model Class Initialized
DEBUG - 2024-01-24 10:27:41 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-24 10:27:41 --> Model Class Initialized
INFO - 2024-01-24 10:27:41 --> Model Class Initialized
INFO - 2024-01-24 10:27:41 --> Model Class Initialized
INFO - 2024-01-24 10:27:41 --> Model Class Initialized
DEBUG - 2024-01-24 10:27:41 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-01-24 10:27:41 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-24 10:27:41 --> Model Class Initialized
INFO - 2024-01-24 10:27:41 --> Model Class Initialized
INFO - 2024-01-24 10:27:41 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2024-01-24 10:27:41 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-01-24 10:27:41 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-01-24 10:27:41 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-01-24 10:27:41 --> Model Class Initialized
INFO - 2024-01-24 10:27:41 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-01-24 10:27:41 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-01-24 10:27:41 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-01-24 10:27:41 --> Final output sent to browser
DEBUG - 2024-01-24 10:27:41 --> Total execution time: 0.2187
ERROR - 2024-01-24 10:28:00 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-01-24 10:28:00 --> Config Class Initialized
INFO - 2024-01-24 10:28:00 --> Hooks Class Initialized
DEBUG - 2024-01-24 10:28:00 --> UTF-8 Support Enabled
INFO - 2024-01-24 10:28:00 --> Utf8 Class Initialized
INFO - 2024-01-24 10:28:00 --> URI Class Initialized
INFO - 2024-01-24 10:28:00 --> Router Class Initialized
INFO - 2024-01-24 10:28:00 --> Output Class Initialized
INFO - 2024-01-24 10:28:00 --> Security Class Initialized
DEBUG - 2024-01-24 10:28:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-24 10:28:00 --> Input Class Initialized
INFO - 2024-01-24 10:28:00 --> Language Class Initialized
INFO - 2024-01-24 10:28:00 --> Loader Class Initialized
INFO - 2024-01-24 10:28:00 --> Helper loaded: url_helper
INFO - 2024-01-24 10:28:00 --> Helper loaded: file_helper
INFO - 2024-01-24 10:28:00 --> Helper loaded: html_helper
INFO - 2024-01-24 10:28:00 --> Helper loaded: text_helper
INFO - 2024-01-24 10:28:00 --> Helper loaded: form_helper
INFO - 2024-01-24 10:28:00 --> Helper loaded: lang_helper
INFO - 2024-01-24 10:28:00 --> Helper loaded: security_helper
INFO - 2024-01-24 10:28:00 --> Helper loaded: cookie_helper
INFO - 2024-01-24 10:28:00 --> Database Driver Class Initialized
INFO - 2024-01-24 10:28:00 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-24 10:28:00 --> Parser Class Initialized
INFO - 2024-01-24 10:28:00 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-01-24 10:28:00 --> Pagination Class Initialized
INFO - 2024-01-24 10:28:00 --> Form Validation Class Initialized
INFO - 2024-01-24 10:28:00 --> Controller Class Initialized
INFO - 2024-01-24 10:28:00 --> Model Class Initialized
DEBUG - 2024-01-24 10:28:00 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-01-24 10:28:00 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-24 10:28:00 --> Model Class Initialized
DEBUG - 2024-01-24 10:28:00 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-24 10:28:00 --> Model Class Initialized
INFO - 2024-01-24 10:28:00 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice.php
DEBUG - 2024-01-24 10:28:00 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-01-24 10:28:00 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-01-24 10:28:00 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-01-24 10:28:00 --> Model Class Initialized
INFO - 2024-01-24 10:28:00 --> Model Class Initialized
INFO - 2024-01-24 10:28:00 --> Model Class Initialized
INFO - 2024-01-24 10:28:00 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-01-24 10:28:00 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-01-24 10:28:00 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-01-24 10:28:00 --> Final output sent to browser
DEBUG - 2024-01-24 10:28:00 --> Total execution time: 0.1497
ERROR - 2024-01-24 10:28:01 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-01-24 10:28:01 --> Config Class Initialized
INFO - 2024-01-24 10:28:01 --> Hooks Class Initialized
DEBUG - 2024-01-24 10:28:01 --> UTF-8 Support Enabled
INFO - 2024-01-24 10:28:01 --> Utf8 Class Initialized
INFO - 2024-01-24 10:28:01 --> URI Class Initialized
INFO - 2024-01-24 10:28:01 --> Router Class Initialized
INFO - 2024-01-24 10:28:01 --> Output Class Initialized
INFO - 2024-01-24 10:28:01 --> Security Class Initialized
DEBUG - 2024-01-24 10:28:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-24 10:28:01 --> Input Class Initialized
INFO - 2024-01-24 10:28:01 --> Language Class Initialized
INFO - 2024-01-24 10:28:01 --> Loader Class Initialized
INFO - 2024-01-24 10:28:01 --> Helper loaded: url_helper
INFO - 2024-01-24 10:28:01 --> Helper loaded: file_helper
INFO - 2024-01-24 10:28:01 --> Helper loaded: html_helper
INFO - 2024-01-24 10:28:01 --> Helper loaded: text_helper
INFO - 2024-01-24 10:28:01 --> Helper loaded: form_helper
INFO - 2024-01-24 10:28:01 --> Helper loaded: lang_helper
INFO - 2024-01-24 10:28:01 --> Helper loaded: security_helper
INFO - 2024-01-24 10:28:01 --> Helper loaded: cookie_helper
INFO - 2024-01-24 10:28:01 --> Database Driver Class Initialized
INFO - 2024-01-24 10:28:01 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-24 10:28:01 --> Parser Class Initialized
INFO - 2024-01-24 10:28:01 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-01-24 10:28:01 --> Pagination Class Initialized
INFO - 2024-01-24 10:28:01 --> Form Validation Class Initialized
INFO - 2024-01-24 10:28:01 --> Controller Class Initialized
INFO - 2024-01-24 10:28:01 --> Model Class Initialized
DEBUG - 2024-01-24 10:28:01 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-01-24 10:28:01 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-24 10:28:01 --> Model Class Initialized
DEBUG - 2024-01-24 10:28:01 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-24 10:28:01 --> Model Class Initialized
INFO - 2024-01-24 10:28:01 --> Final output sent to browser
DEBUG - 2024-01-24 10:28:01 --> Total execution time: 0.0402
ERROR - 2024-01-24 10:28:41 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-01-24 10:28:41 --> Config Class Initialized
INFO - 2024-01-24 10:28:41 --> Hooks Class Initialized
DEBUG - 2024-01-24 10:28:41 --> UTF-8 Support Enabled
INFO - 2024-01-24 10:28:41 --> Utf8 Class Initialized
INFO - 2024-01-24 10:28:41 --> URI Class Initialized
INFO - 2024-01-24 10:28:41 --> Router Class Initialized
INFO - 2024-01-24 10:28:41 --> Output Class Initialized
INFO - 2024-01-24 10:28:41 --> Security Class Initialized
DEBUG - 2024-01-24 10:28:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-24 10:28:41 --> Input Class Initialized
INFO - 2024-01-24 10:28:41 --> Language Class Initialized
INFO - 2024-01-24 10:28:41 --> Loader Class Initialized
INFO - 2024-01-24 10:28:41 --> Helper loaded: url_helper
INFO - 2024-01-24 10:28:41 --> Helper loaded: file_helper
INFO - 2024-01-24 10:28:41 --> Helper loaded: html_helper
INFO - 2024-01-24 10:28:41 --> Helper loaded: text_helper
INFO - 2024-01-24 10:28:41 --> Helper loaded: form_helper
INFO - 2024-01-24 10:28:41 --> Helper loaded: lang_helper
INFO - 2024-01-24 10:28:41 --> Helper loaded: security_helper
INFO - 2024-01-24 10:28:41 --> Helper loaded: cookie_helper
INFO - 2024-01-24 10:28:41 --> Database Driver Class Initialized
INFO - 2024-01-24 10:28:41 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-24 10:28:41 --> Parser Class Initialized
INFO - 2024-01-24 10:28:41 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-01-24 10:28:41 --> Pagination Class Initialized
INFO - 2024-01-24 10:28:41 --> Form Validation Class Initialized
INFO - 2024-01-24 10:28:41 --> Controller Class Initialized
INFO - 2024-01-24 10:28:41 --> Model Class Initialized
DEBUG - 2024-01-24 10:28:41 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-24 10:28:41 --> Final output sent to browser
DEBUG - 2024-01-24 10:28:41 --> Total execution time: 0.0150
ERROR - 2024-01-24 10:28:41 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-01-24 10:28:41 --> Config Class Initialized
INFO - 2024-01-24 10:28:41 --> Hooks Class Initialized
DEBUG - 2024-01-24 10:28:41 --> UTF-8 Support Enabled
INFO - 2024-01-24 10:28:41 --> Utf8 Class Initialized
INFO - 2024-01-24 10:28:41 --> URI Class Initialized
INFO - 2024-01-24 10:28:41 --> Router Class Initialized
INFO - 2024-01-24 10:28:41 --> Output Class Initialized
INFO - 2024-01-24 10:28:41 --> Security Class Initialized
DEBUG - 2024-01-24 10:28:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-24 10:28:41 --> Input Class Initialized
INFO - 2024-01-24 10:28:41 --> Language Class Initialized
INFO - 2024-01-24 10:28:41 --> Loader Class Initialized
INFO - 2024-01-24 10:28:41 --> Helper loaded: url_helper
INFO - 2024-01-24 10:28:41 --> Helper loaded: file_helper
INFO - 2024-01-24 10:28:41 --> Helper loaded: html_helper
INFO - 2024-01-24 10:28:41 --> Helper loaded: text_helper
INFO - 2024-01-24 10:28:41 --> Helper loaded: form_helper
INFO - 2024-01-24 10:28:41 --> Helper loaded: lang_helper
INFO - 2024-01-24 10:28:41 --> Helper loaded: security_helper
INFO - 2024-01-24 10:28:41 --> Helper loaded: cookie_helper
INFO - 2024-01-24 10:28:41 --> Database Driver Class Initialized
INFO - 2024-01-24 10:28:41 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-24 10:28:41 --> Parser Class Initialized
INFO - 2024-01-24 10:28:41 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-01-24 10:28:41 --> Pagination Class Initialized
INFO - 2024-01-24 10:28:41 --> Form Validation Class Initialized
INFO - 2024-01-24 10:28:41 --> Controller Class Initialized
INFO - 2024-01-24 10:28:41 --> Model Class Initialized
DEBUG - 2024-01-24 10:28:41 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-24 10:28:41 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2024-01-24 10:28:41 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-01-24 10:28:41 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-01-24 10:28:41 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-01-24 10:28:41 --> Model Class Initialized
INFO - 2024-01-24 10:28:41 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-01-24 10:28:41 --> Final output sent to browser
DEBUG - 2024-01-24 10:28:41 --> Total execution time: 0.0305
ERROR - 2024-01-24 10:39:19 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-01-24 10:39:19 --> Config Class Initialized
INFO - 2024-01-24 10:39:19 --> Hooks Class Initialized
DEBUG - 2024-01-24 10:39:19 --> UTF-8 Support Enabled
INFO - 2024-01-24 10:39:19 --> Utf8 Class Initialized
INFO - 2024-01-24 10:39:19 --> URI Class Initialized
DEBUG - 2024-01-24 10:39:19 --> No URI present. Default controller set.
INFO - 2024-01-24 10:39:19 --> Router Class Initialized
INFO - 2024-01-24 10:39:19 --> Output Class Initialized
INFO - 2024-01-24 10:39:19 --> Security Class Initialized
DEBUG - 2024-01-24 10:39:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-24 10:39:19 --> Input Class Initialized
INFO - 2024-01-24 10:39:19 --> Language Class Initialized
INFO - 2024-01-24 10:39:19 --> Loader Class Initialized
INFO - 2024-01-24 10:39:19 --> Helper loaded: url_helper
INFO - 2024-01-24 10:39:19 --> Helper loaded: file_helper
INFO - 2024-01-24 10:39:19 --> Helper loaded: html_helper
INFO - 2024-01-24 10:39:19 --> Helper loaded: text_helper
INFO - 2024-01-24 10:39:19 --> Helper loaded: form_helper
INFO - 2024-01-24 10:39:19 --> Helper loaded: lang_helper
INFO - 2024-01-24 10:39:19 --> Helper loaded: security_helper
INFO - 2024-01-24 10:39:19 --> Helper loaded: cookie_helper
INFO - 2024-01-24 10:39:19 --> Database Driver Class Initialized
INFO - 2024-01-24 10:39:19 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-24 10:39:19 --> Parser Class Initialized
INFO - 2024-01-24 10:39:19 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-01-24 10:39:19 --> Pagination Class Initialized
INFO - 2024-01-24 10:39:19 --> Form Validation Class Initialized
INFO - 2024-01-24 10:39:19 --> Controller Class Initialized
INFO - 2024-01-24 10:39:19 --> Model Class Initialized
DEBUG - 2024-01-24 10:39:19 --> Session class already loaded. Second attempt ignored.
ERROR - 2024-01-24 10:39:19 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-01-24 10:39:19 --> Config Class Initialized
INFO - 2024-01-24 10:39:19 --> Hooks Class Initialized
DEBUG - 2024-01-24 10:39:19 --> UTF-8 Support Enabled
INFO - 2024-01-24 10:39:19 --> Utf8 Class Initialized
INFO - 2024-01-24 10:39:19 --> URI Class Initialized
INFO - 2024-01-24 10:39:19 --> Router Class Initialized
INFO - 2024-01-24 10:39:19 --> Output Class Initialized
INFO - 2024-01-24 10:39:19 --> Security Class Initialized
DEBUG - 2024-01-24 10:39:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-24 10:39:19 --> Input Class Initialized
INFO - 2024-01-24 10:39:19 --> Language Class Initialized
INFO - 2024-01-24 10:39:19 --> Loader Class Initialized
INFO - 2024-01-24 10:39:19 --> Helper loaded: url_helper
INFO - 2024-01-24 10:39:19 --> Helper loaded: file_helper
INFO - 2024-01-24 10:39:19 --> Helper loaded: html_helper
INFO - 2024-01-24 10:39:19 --> Helper loaded: text_helper
INFO - 2024-01-24 10:39:19 --> Helper loaded: form_helper
INFO - 2024-01-24 10:39:19 --> Helper loaded: lang_helper
INFO - 2024-01-24 10:39:19 --> Helper loaded: security_helper
INFO - 2024-01-24 10:39:19 --> Helper loaded: cookie_helper
INFO - 2024-01-24 10:39:19 --> Database Driver Class Initialized
INFO - 2024-01-24 10:39:19 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-24 10:39:19 --> Parser Class Initialized
INFO - 2024-01-24 10:39:19 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-01-24 10:39:19 --> Pagination Class Initialized
INFO - 2024-01-24 10:39:19 --> Form Validation Class Initialized
INFO - 2024-01-24 10:39:19 --> Controller Class Initialized
INFO - 2024-01-24 10:39:19 --> Model Class Initialized
DEBUG - 2024-01-24 10:39:19 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-24 10:39:19 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2024-01-24 10:39:19 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-01-24 10:39:19 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-01-24 10:39:19 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-01-24 10:39:19 --> Model Class Initialized
INFO - 2024-01-24 10:39:19 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-01-24 10:39:19 --> Final output sent to browser
DEBUG - 2024-01-24 10:39:19 --> Total execution time: 0.0295
ERROR - 2024-01-24 11:09:59 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-01-24 11:09:59 --> Config Class Initialized
INFO - 2024-01-24 11:09:59 --> Hooks Class Initialized
DEBUG - 2024-01-24 11:09:59 --> UTF-8 Support Enabled
INFO - 2024-01-24 11:09:59 --> Utf8 Class Initialized
INFO - 2024-01-24 11:09:59 --> URI Class Initialized
DEBUG - 2024-01-24 11:09:59 --> No URI present. Default controller set.
INFO - 2024-01-24 11:09:59 --> Router Class Initialized
INFO - 2024-01-24 11:09:59 --> Output Class Initialized
INFO - 2024-01-24 11:09:59 --> Security Class Initialized
DEBUG - 2024-01-24 11:09:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-24 11:09:59 --> Input Class Initialized
INFO - 2024-01-24 11:09:59 --> Language Class Initialized
INFO - 2024-01-24 11:09:59 --> Loader Class Initialized
INFO - 2024-01-24 11:09:59 --> Helper loaded: url_helper
INFO - 2024-01-24 11:09:59 --> Helper loaded: file_helper
INFO - 2024-01-24 11:09:59 --> Helper loaded: html_helper
INFO - 2024-01-24 11:09:59 --> Helper loaded: text_helper
INFO - 2024-01-24 11:09:59 --> Helper loaded: form_helper
INFO - 2024-01-24 11:09:59 --> Helper loaded: lang_helper
INFO - 2024-01-24 11:09:59 --> Helper loaded: security_helper
INFO - 2024-01-24 11:09:59 --> Helper loaded: cookie_helper
INFO - 2024-01-24 11:09:59 --> Database Driver Class Initialized
INFO - 2024-01-24 11:09:59 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-24 11:09:59 --> Parser Class Initialized
INFO - 2024-01-24 11:09:59 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-01-24 11:09:59 --> Pagination Class Initialized
INFO - 2024-01-24 11:09:59 --> Form Validation Class Initialized
INFO - 2024-01-24 11:09:59 --> Controller Class Initialized
INFO - 2024-01-24 11:09:59 --> Model Class Initialized
DEBUG - 2024-01-24 11:09:59 --> Session class already loaded. Second attempt ignored.
ERROR - 2024-01-24 11:10:00 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-01-24 11:10:00 --> Config Class Initialized
INFO - 2024-01-24 11:10:00 --> Hooks Class Initialized
DEBUG - 2024-01-24 11:10:00 --> UTF-8 Support Enabled
INFO - 2024-01-24 11:10:00 --> Utf8 Class Initialized
INFO - 2024-01-24 11:10:00 --> URI Class Initialized
INFO - 2024-01-24 11:10:00 --> Router Class Initialized
INFO - 2024-01-24 11:10:00 --> Output Class Initialized
INFO - 2024-01-24 11:10:00 --> Security Class Initialized
DEBUG - 2024-01-24 11:10:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-24 11:10:00 --> Input Class Initialized
INFO - 2024-01-24 11:10:00 --> Language Class Initialized
INFO - 2024-01-24 11:10:00 --> Loader Class Initialized
INFO - 2024-01-24 11:10:00 --> Helper loaded: url_helper
INFO - 2024-01-24 11:10:00 --> Helper loaded: file_helper
INFO - 2024-01-24 11:10:00 --> Helper loaded: html_helper
INFO - 2024-01-24 11:10:00 --> Helper loaded: text_helper
INFO - 2024-01-24 11:10:00 --> Helper loaded: form_helper
INFO - 2024-01-24 11:10:00 --> Helper loaded: lang_helper
INFO - 2024-01-24 11:10:00 --> Helper loaded: security_helper
INFO - 2024-01-24 11:10:00 --> Helper loaded: cookie_helper
INFO - 2024-01-24 11:10:00 --> Database Driver Class Initialized
INFO - 2024-01-24 11:10:00 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-24 11:10:00 --> Parser Class Initialized
INFO - 2024-01-24 11:10:00 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-01-24 11:10:00 --> Pagination Class Initialized
INFO - 2024-01-24 11:10:00 --> Form Validation Class Initialized
INFO - 2024-01-24 11:10:00 --> Controller Class Initialized
INFO - 2024-01-24 11:10:00 --> Model Class Initialized
DEBUG - 2024-01-24 11:10:00 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-24 11:10:00 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2024-01-24 11:10:00 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-01-24 11:10:00 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-01-24 11:10:00 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-01-24 11:10:00 --> Model Class Initialized
INFO - 2024-01-24 11:10:00 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-01-24 11:10:00 --> Final output sent to browser
DEBUG - 2024-01-24 11:10:00 --> Total execution time: 0.0310
ERROR - 2024-01-24 11:13:35 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-01-24 11:13:35 --> Config Class Initialized
INFO - 2024-01-24 11:13:35 --> Hooks Class Initialized
DEBUG - 2024-01-24 11:13:35 --> UTF-8 Support Enabled
INFO - 2024-01-24 11:13:35 --> Utf8 Class Initialized
INFO - 2024-01-24 11:13:35 --> URI Class Initialized
INFO - 2024-01-24 11:13:35 --> Router Class Initialized
INFO - 2024-01-24 11:13:35 --> Output Class Initialized
INFO - 2024-01-24 11:13:35 --> Security Class Initialized
DEBUG - 2024-01-24 11:13:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-24 11:13:35 --> Input Class Initialized
INFO - 2024-01-24 11:13:35 --> Language Class Initialized
INFO - 2024-01-24 11:13:35 --> Loader Class Initialized
INFO - 2024-01-24 11:13:35 --> Helper loaded: url_helper
INFO - 2024-01-24 11:13:35 --> Helper loaded: file_helper
INFO - 2024-01-24 11:13:35 --> Helper loaded: html_helper
INFO - 2024-01-24 11:13:35 --> Helper loaded: text_helper
INFO - 2024-01-24 11:13:35 --> Helper loaded: form_helper
INFO - 2024-01-24 11:13:35 --> Helper loaded: lang_helper
INFO - 2024-01-24 11:13:35 --> Helper loaded: security_helper
INFO - 2024-01-24 11:13:35 --> Helper loaded: cookie_helper
INFO - 2024-01-24 11:13:35 --> Database Driver Class Initialized
INFO - 2024-01-24 11:13:35 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-24 11:13:35 --> Parser Class Initialized
INFO - 2024-01-24 11:13:35 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-01-24 11:13:35 --> Pagination Class Initialized
INFO - 2024-01-24 11:13:35 --> Form Validation Class Initialized
INFO - 2024-01-24 11:13:35 --> Controller Class Initialized
INFO - 2024-01-24 11:13:35 --> Model Class Initialized
DEBUG - 2024-01-24 11:13:35 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-24 11:13:35 --> Model Class Initialized
INFO - 2024-01-24 11:13:35 --> Final output sent to browser
DEBUG - 2024-01-24 11:13:35 --> Total execution time: 0.0230
ERROR - 2024-01-24 11:13:35 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-01-24 11:13:35 --> Config Class Initialized
INFO - 2024-01-24 11:13:35 --> Hooks Class Initialized
DEBUG - 2024-01-24 11:13:35 --> UTF-8 Support Enabled
INFO - 2024-01-24 11:13:35 --> Utf8 Class Initialized
INFO - 2024-01-24 11:13:35 --> URI Class Initialized
DEBUG - 2024-01-24 11:13:35 --> No URI present. Default controller set.
INFO - 2024-01-24 11:13:35 --> Router Class Initialized
INFO - 2024-01-24 11:13:35 --> Output Class Initialized
INFO - 2024-01-24 11:13:35 --> Security Class Initialized
DEBUG - 2024-01-24 11:13:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-24 11:13:35 --> Input Class Initialized
INFO - 2024-01-24 11:13:35 --> Language Class Initialized
INFO - 2024-01-24 11:13:35 --> Loader Class Initialized
INFO - 2024-01-24 11:13:35 --> Helper loaded: url_helper
INFO - 2024-01-24 11:13:35 --> Helper loaded: file_helper
INFO - 2024-01-24 11:13:35 --> Helper loaded: html_helper
INFO - 2024-01-24 11:13:35 --> Helper loaded: text_helper
INFO - 2024-01-24 11:13:35 --> Helper loaded: form_helper
INFO - 2024-01-24 11:13:35 --> Helper loaded: lang_helper
INFO - 2024-01-24 11:13:35 --> Helper loaded: security_helper
INFO - 2024-01-24 11:13:35 --> Helper loaded: cookie_helper
INFO - 2024-01-24 11:13:35 --> Database Driver Class Initialized
INFO - 2024-01-24 11:13:35 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-24 11:13:35 --> Parser Class Initialized
INFO - 2024-01-24 11:13:35 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-01-24 11:13:35 --> Pagination Class Initialized
INFO - 2024-01-24 11:13:35 --> Form Validation Class Initialized
INFO - 2024-01-24 11:13:35 --> Controller Class Initialized
INFO - 2024-01-24 11:13:35 --> Model Class Initialized
DEBUG - 2024-01-24 11:13:35 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-24 11:13:35 --> Model Class Initialized
DEBUG - 2024-01-24 11:13:35 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-24 11:13:35 --> Model Class Initialized
INFO - 2024-01-24 11:13:35 --> Model Class Initialized
INFO - 2024-01-24 11:13:35 --> Model Class Initialized
INFO - 2024-01-24 11:13:35 --> Model Class Initialized
DEBUG - 2024-01-24 11:13:35 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-01-24 11:13:35 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-24 11:13:35 --> Model Class Initialized
INFO - 2024-01-24 11:13:35 --> Model Class Initialized
INFO - 2024-01-24 11:13:35 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2024-01-24 11:13:35 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-01-24 11:13:35 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-01-24 11:13:35 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-01-24 11:13:35 --> Model Class Initialized
INFO - 2024-01-24 11:13:35 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-01-24 11:13:35 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-01-24 11:13:35 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-01-24 11:13:35 --> Final output sent to browser
DEBUG - 2024-01-24 11:13:35 --> Total execution time: 0.2353
ERROR - 2024-01-24 11:13:42 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-01-24 11:13:42 --> Config Class Initialized
INFO - 2024-01-24 11:13:42 --> Hooks Class Initialized
DEBUG - 2024-01-24 11:13:42 --> UTF-8 Support Enabled
INFO - 2024-01-24 11:13:42 --> Utf8 Class Initialized
INFO - 2024-01-24 11:13:42 --> URI Class Initialized
INFO - 2024-01-24 11:13:42 --> Router Class Initialized
INFO - 2024-01-24 11:13:42 --> Output Class Initialized
INFO - 2024-01-24 11:13:42 --> Security Class Initialized
DEBUG - 2024-01-24 11:13:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-24 11:13:42 --> Input Class Initialized
INFO - 2024-01-24 11:13:42 --> Language Class Initialized
INFO - 2024-01-24 11:13:42 --> Loader Class Initialized
INFO - 2024-01-24 11:13:42 --> Helper loaded: url_helper
INFO - 2024-01-24 11:13:42 --> Helper loaded: file_helper
INFO - 2024-01-24 11:13:42 --> Helper loaded: html_helper
INFO - 2024-01-24 11:13:42 --> Helper loaded: text_helper
INFO - 2024-01-24 11:13:42 --> Helper loaded: form_helper
INFO - 2024-01-24 11:13:42 --> Helper loaded: lang_helper
INFO - 2024-01-24 11:13:42 --> Helper loaded: security_helper
INFO - 2024-01-24 11:13:42 --> Helper loaded: cookie_helper
INFO - 2024-01-24 11:13:42 --> Database Driver Class Initialized
INFO - 2024-01-24 11:13:42 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-24 11:13:42 --> Parser Class Initialized
INFO - 2024-01-24 11:13:42 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-01-24 11:13:42 --> Pagination Class Initialized
INFO - 2024-01-24 11:13:42 --> Form Validation Class Initialized
INFO - 2024-01-24 11:13:42 --> Controller Class Initialized
INFO - 2024-01-24 11:13:42 --> Model Class Initialized
DEBUG - 2024-01-24 11:13:42 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-01-24 11:13:42 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-24 11:13:42 --> Model Class Initialized
DEBUG - 2024-01-24 11:13:42 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-24 11:13:42 --> Model Class Initialized
INFO - 2024-01-24 11:13:42 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice.php
DEBUG - 2024-01-24 11:13:42 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-01-24 11:13:42 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-01-24 11:13:42 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-01-24 11:13:42 --> Model Class Initialized
INFO - 2024-01-24 11:13:42 --> Model Class Initialized
INFO - 2024-01-24 11:13:42 --> Model Class Initialized
INFO - 2024-01-24 11:13:42 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-01-24 11:13:42 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-01-24 11:13:42 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-01-24 11:13:42 --> Final output sent to browser
DEBUG - 2024-01-24 11:13:42 --> Total execution time: 0.1495
ERROR - 2024-01-24 11:13:43 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-01-24 11:13:43 --> Config Class Initialized
INFO - 2024-01-24 11:13:43 --> Hooks Class Initialized
DEBUG - 2024-01-24 11:13:43 --> UTF-8 Support Enabled
INFO - 2024-01-24 11:13:43 --> Utf8 Class Initialized
INFO - 2024-01-24 11:13:43 --> URI Class Initialized
INFO - 2024-01-24 11:13:43 --> Router Class Initialized
INFO - 2024-01-24 11:13:43 --> Output Class Initialized
INFO - 2024-01-24 11:13:43 --> Security Class Initialized
DEBUG - 2024-01-24 11:13:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-24 11:13:43 --> Input Class Initialized
INFO - 2024-01-24 11:13:43 --> Language Class Initialized
INFO - 2024-01-24 11:13:43 --> Loader Class Initialized
INFO - 2024-01-24 11:13:43 --> Helper loaded: url_helper
INFO - 2024-01-24 11:13:43 --> Helper loaded: file_helper
INFO - 2024-01-24 11:13:43 --> Helper loaded: html_helper
INFO - 2024-01-24 11:13:43 --> Helper loaded: text_helper
INFO - 2024-01-24 11:13:43 --> Helper loaded: form_helper
INFO - 2024-01-24 11:13:43 --> Helper loaded: lang_helper
INFO - 2024-01-24 11:13:43 --> Helper loaded: security_helper
INFO - 2024-01-24 11:13:43 --> Helper loaded: cookie_helper
INFO - 2024-01-24 11:13:43 --> Database Driver Class Initialized
INFO - 2024-01-24 11:13:43 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-24 11:13:43 --> Parser Class Initialized
INFO - 2024-01-24 11:13:43 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-01-24 11:13:43 --> Pagination Class Initialized
INFO - 2024-01-24 11:13:43 --> Form Validation Class Initialized
INFO - 2024-01-24 11:13:43 --> Controller Class Initialized
INFO - 2024-01-24 11:13:43 --> Model Class Initialized
DEBUG - 2024-01-24 11:13:43 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-01-24 11:13:43 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-24 11:13:43 --> Model Class Initialized
DEBUG - 2024-01-24 11:13:43 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-24 11:13:43 --> Model Class Initialized
INFO - 2024-01-24 11:13:43 --> Final output sent to browser
DEBUG - 2024-01-24 11:13:43 --> Total execution time: 0.0382
ERROR - 2024-01-24 11:13:46 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-01-24 11:13:46 --> Config Class Initialized
INFO - 2024-01-24 11:13:46 --> Hooks Class Initialized
DEBUG - 2024-01-24 11:13:46 --> UTF-8 Support Enabled
INFO - 2024-01-24 11:13:46 --> Utf8 Class Initialized
INFO - 2024-01-24 11:13:46 --> URI Class Initialized
INFO - 2024-01-24 11:13:46 --> Router Class Initialized
INFO - 2024-01-24 11:13:46 --> Output Class Initialized
INFO - 2024-01-24 11:13:46 --> Security Class Initialized
DEBUG - 2024-01-24 11:13:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-24 11:13:46 --> Input Class Initialized
INFO - 2024-01-24 11:13:46 --> Language Class Initialized
INFO - 2024-01-24 11:13:46 --> Loader Class Initialized
INFO - 2024-01-24 11:13:46 --> Helper loaded: url_helper
INFO - 2024-01-24 11:13:46 --> Helper loaded: file_helper
INFO - 2024-01-24 11:13:46 --> Helper loaded: html_helper
INFO - 2024-01-24 11:13:46 --> Helper loaded: text_helper
INFO - 2024-01-24 11:13:46 --> Helper loaded: form_helper
INFO - 2024-01-24 11:13:46 --> Helper loaded: lang_helper
INFO - 2024-01-24 11:13:46 --> Helper loaded: security_helper
INFO - 2024-01-24 11:13:46 --> Helper loaded: cookie_helper
INFO - 2024-01-24 11:13:46 --> Database Driver Class Initialized
INFO - 2024-01-24 11:13:46 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-24 11:13:46 --> Parser Class Initialized
INFO - 2024-01-24 11:13:46 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-01-24 11:13:46 --> Pagination Class Initialized
INFO - 2024-01-24 11:13:46 --> Form Validation Class Initialized
INFO - 2024-01-24 11:13:46 --> Controller Class Initialized
INFO - 2024-01-24 11:13:46 --> Model Class Initialized
DEBUG - 2024-01-24 11:13:46 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-01-24 11:13:46 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-24 11:13:46 --> Model Class Initialized
DEBUG - 2024-01-24 11:13:46 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-24 11:13:46 --> Model Class Initialized
INFO - 2024-01-24 11:13:46 --> Final output sent to browser
DEBUG - 2024-01-24 11:13:46 --> Total execution time: 0.4782
ERROR - 2024-01-24 11:13:57 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-01-24 11:13:57 --> Config Class Initialized
INFO - 2024-01-24 11:13:57 --> Hooks Class Initialized
DEBUG - 2024-01-24 11:13:57 --> UTF-8 Support Enabled
INFO - 2024-01-24 11:13:57 --> Utf8 Class Initialized
INFO - 2024-01-24 11:13:57 --> URI Class Initialized
INFO - 2024-01-24 11:13:57 --> Router Class Initialized
INFO - 2024-01-24 11:13:57 --> Output Class Initialized
INFO - 2024-01-24 11:13:57 --> Security Class Initialized
DEBUG - 2024-01-24 11:13:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-24 11:13:57 --> Input Class Initialized
INFO - 2024-01-24 11:13:57 --> Language Class Initialized
INFO - 2024-01-24 11:13:57 --> Loader Class Initialized
INFO - 2024-01-24 11:13:57 --> Helper loaded: url_helper
INFO - 2024-01-24 11:13:57 --> Helper loaded: file_helper
INFO - 2024-01-24 11:13:57 --> Helper loaded: html_helper
INFO - 2024-01-24 11:13:57 --> Helper loaded: text_helper
INFO - 2024-01-24 11:13:57 --> Helper loaded: form_helper
INFO - 2024-01-24 11:13:57 --> Helper loaded: lang_helper
INFO - 2024-01-24 11:13:57 --> Helper loaded: security_helper
INFO - 2024-01-24 11:13:57 --> Helper loaded: cookie_helper
INFO - 2024-01-24 11:13:57 --> Database Driver Class Initialized
INFO - 2024-01-24 11:13:57 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-24 11:13:57 --> Parser Class Initialized
INFO - 2024-01-24 11:13:57 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-01-24 11:13:57 --> Pagination Class Initialized
INFO - 2024-01-24 11:13:57 --> Form Validation Class Initialized
INFO - 2024-01-24 11:13:57 --> Controller Class Initialized
INFO - 2024-01-24 11:13:57 --> Model Class Initialized
DEBUG - 2024-01-24 11:13:57 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-01-24 11:13:57 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-24 11:13:57 --> Model Class Initialized
DEBUG - 2024-01-24 11:13:57 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-24 11:13:57 --> Model Class Initialized
DEBUG - 2024-01-24 11:13:57 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-24 11:13:57 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice_html.php
DEBUG - 2024-01-24 11:13:57 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-01-24 11:13:57 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-01-24 11:13:57 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-01-24 11:13:57 --> Model Class Initialized
INFO - 2024-01-24 11:13:57 --> Model Class Initialized
INFO - 2024-01-24 11:13:57 --> Model Class Initialized
INFO - 2024-01-24 11:13:57 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-01-24 11:13:57 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-01-24 11:13:57 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-01-24 11:13:57 --> Final output sent to browser
DEBUG - 2024-01-24 11:13:57 --> Total execution time: 0.1563
ERROR - 2024-01-24 11:14:05 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-01-24 11:14:05 --> Config Class Initialized
INFO - 2024-01-24 11:14:05 --> Hooks Class Initialized
DEBUG - 2024-01-24 11:14:05 --> UTF-8 Support Enabled
INFO - 2024-01-24 11:14:05 --> Utf8 Class Initialized
INFO - 2024-01-24 11:14:05 --> URI Class Initialized
DEBUG - 2024-01-24 11:14:05 --> No URI present. Default controller set.
INFO - 2024-01-24 11:14:05 --> Router Class Initialized
INFO - 2024-01-24 11:14:05 --> Output Class Initialized
INFO - 2024-01-24 11:14:05 --> Security Class Initialized
DEBUG - 2024-01-24 11:14:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-24 11:14:05 --> Input Class Initialized
INFO - 2024-01-24 11:14:05 --> Language Class Initialized
INFO - 2024-01-24 11:14:05 --> Loader Class Initialized
INFO - 2024-01-24 11:14:05 --> Helper loaded: url_helper
INFO - 2024-01-24 11:14:05 --> Helper loaded: file_helper
INFO - 2024-01-24 11:14:05 --> Helper loaded: html_helper
INFO - 2024-01-24 11:14:05 --> Helper loaded: text_helper
INFO - 2024-01-24 11:14:05 --> Helper loaded: form_helper
INFO - 2024-01-24 11:14:05 --> Helper loaded: lang_helper
INFO - 2024-01-24 11:14:05 --> Helper loaded: security_helper
INFO - 2024-01-24 11:14:05 --> Helper loaded: cookie_helper
INFO - 2024-01-24 11:14:05 --> Database Driver Class Initialized
INFO - 2024-01-24 11:14:05 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-24 11:14:05 --> Parser Class Initialized
INFO - 2024-01-24 11:14:05 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-01-24 11:14:05 --> Pagination Class Initialized
INFO - 2024-01-24 11:14:05 --> Form Validation Class Initialized
INFO - 2024-01-24 11:14:05 --> Controller Class Initialized
INFO - 2024-01-24 11:14:05 --> Model Class Initialized
DEBUG - 2024-01-24 11:14:05 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-24 11:14:05 --> Model Class Initialized
DEBUG - 2024-01-24 11:14:05 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-24 11:14:05 --> Model Class Initialized
INFO - 2024-01-24 11:14:05 --> Model Class Initialized
INFO - 2024-01-24 11:14:05 --> Model Class Initialized
INFO - 2024-01-24 11:14:05 --> Model Class Initialized
DEBUG - 2024-01-24 11:14:05 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-01-24 11:14:05 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-24 11:14:05 --> Model Class Initialized
INFO - 2024-01-24 11:14:05 --> Model Class Initialized
INFO - 2024-01-24 11:14:05 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2024-01-24 11:14:05 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-01-24 11:14:05 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-01-24 11:14:05 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-01-24 11:14:05 --> Model Class Initialized
INFO - 2024-01-24 11:14:05 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-01-24 11:14:05 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-01-24 11:14:05 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-01-24 11:14:05 --> Final output sent to browser
DEBUG - 2024-01-24 11:14:05 --> Total execution time: 0.2291
ERROR - 2024-01-24 11:14:47 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-01-24 11:14:47 --> Config Class Initialized
INFO - 2024-01-24 11:14:47 --> Hooks Class Initialized
DEBUG - 2024-01-24 11:14:47 --> UTF-8 Support Enabled
INFO - 2024-01-24 11:14:47 --> Utf8 Class Initialized
INFO - 2024-01-24 11:14:47 --> URI Class Initialized
INFO - 2024-01-24 11:14:47 --> Router Class Initialized
INFO - 2024-01-24 11:14:47 --> Output Class Initialized
INFO - 2024-01-24 11:14:47 --> Security Class Initialized
DEBUG - 2024-01-24 11:14:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-24 11:14:47 --> Input Class Initialized
INFO - 2024-01-24 11:14:47 --> Language Class Initialized
INFO - 2024-01-24 11:14:47 --> Loader Class Initialized
INFO - 2024-01-24 11:14:47 --> Helper loaded: url_helper
INFO - 2024-01-24 11:14:47 --> Helper loaded: file_helper
INFO - 2024-01-24 11:14:47 --> Helper loaded: html_helper
INFO - 2024-01-24 11:14:47 --> Helper loaded: text_helper
INFO - 2024-01-24 11:14:47 --> Helper loaded: form_helper
INFO - 2024-01-24 11:14:47 --> Helper loaded: lang_helper
INFO - 2024-01-24 11:14:47 --> Helper loaded: security_helper
INFO - 2024-01-24 11:14:47 --> Helper loaded: cookie_helper
INFO - 2024-01-24 11:14:48 --> Database Driver Class Initialized
INFO - 2024-01-24 11:14:48 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-24 11:14:48 --> Parser Class Initialized
INFO - 2024-01-24 11:14:48 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-01-24 11:14:48 --> Pagination Class Initialized
INFO - 2024-01-24 11:14:48 --> Form Validation Class Initialized
INFO - 2024-01-24 11:14:48 --> Controller Class Initialized
INFO - 2024-01-24 11:14:48 --> Model Class Initialized
DEBUG - 2024-01-24 11:14:48 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-01-24 11:14:48 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-24 11:14:48 --> Model Class Initialized
DEBUG - 2024-01-24 11:14:48 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-24 11:14:48 --> Model Class Initialized
INFO - 2024-01-24 11:14:48 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice.php
DEBUG - 2024-01-24 11:14:48 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-01-24 11:14:48 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-01-24 11:14:48 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-01-24 11:14:48 --> Model Class Initialized
INFO - 2024-01-24 11:14:48 --> Model Class Initialized
INFO - 2024-01-24 11:14:48 --> Model Class Initialized
INFO - 2024-01-24 11:14:48 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-01-24 11:14:48 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-01-24 11:14:48 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-01-24 11:14:48 --> Final output sent to browser
DEBUG - 2024-01-24 11:14:48 --> Total execution time: 0.1708
ERROR - 2024-01-24 11:14:48 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-01-24 11:14:48 --> Config Class Initialized
INFO - 2024-01-24 11:14:48 --> Hooks Class Initialized
DEBUG - 2024-01-24 11:14:48 --> UTF-8 Support Enabled
INFO - 2024-01-24 11:14:48 --> Utf8 Class Initialized
INFO - 2024-01-24 11:14:48 --> URI Class Initialized
INFO - 2024-01-24 11:14:48 --> Router Class Initialized
INFO - 2024-01-24 11:14:48 --> Output Class Initialized
INFO - 2024-01-24 11:14:48 --> Security Class Initialized
DEBUG - 2024-01-24 11:14:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-24 11:14:48 --> Input Class Initialized
INFO - 2024-01-24 11:14:48 --> Language Class Initialized
INFO - 2024-01-24 11:14:48 --> Loader Class Initialized
INFO - 2024-01-24 11:14:48 --> Helper loaded: url_helper
INFO - 2024-01-24 11:14:48 --> Helper loaded: file_helper
INFO - 2024-01-24 11:14:48 --> Helper loaded: html_helper
INFO - 2024-01-24 11:14:48 --> Helper loaded: text_helper
INFO - 2024-01-24 11:14:48 --> Helper loaded: form_helper
INFO - 2024-01-24 11:14:48 --> Helper loaded: lang_helper
INFO - 2024-01-24 11:14:48 --> Helper loaded: security_helper
INFO - 2024-01-24 11:14:48 --> Helper loaded: cookie_helper
INFO - 2024-01-24 11:14:48 --> Database Driver Class Initialized
INFO - 2024-01-24 11:14:48 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-24 11:14:48 --> Parser Class Initialized
INFO - 2024-01-24 11:14:48 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-01-24 11:14:48 --> Pagination Class Initialized
INFO - 2024-01-24 11:14:48 --> Form Validation Class Initialized
INFO - 2024-01-24 11:14:48 --> Controller Class Initialized
INFO - 2024-01-24 11:14:48 --> Model Class Initialized
DEBUG - 2024-01-24 11:14:48 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-01-24 11:14:48 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-24 11:14:48 --> Model Class Initialized
DEBUG - 2024-01-24 11:14:48 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-24 11:14:48 --> Model Class Initialized
INFO - 2024-01-24 11:14:48 --> Final output sent to browser
DEBUG - 2024-01-24 11:14:48 --> Total execution time: 0.0405
ERROR - 2024-01-24 11:14:52 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-01-24 11:14:52 --> Config Class Initialized
INFO - 2024-01-24 11:14:52 --> Hooks Class Initialized
DEBUG - 2024-01-24 11:14:52 --> UTF-8 Support Enabled
INFO - 2024-01-24 11:14:52 --> Utf8 Class Initialized
INFO - 2024-01-24 11:14:52 --> URI Class Initialized
INFO - 2024-01-24 11:14:52 --> Router Class Initialized
INFO - 2024-01-24 11:14:52 --> Output Class Initialized
INFO - 2024-01-24 11:14:52 --> Security Class Initialized
DEBUG - 2024-01-24 11:14:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-24 11:14:52 --> Input Class Initialized
INFO - 2024-01-24 11:14:52 --> Language Class Initialized
INFO - 2024-01-24 11:14:52 --> Loader Class Initialized
INFO - 2024-01-24 11:14:52 --> Helper loaded: url_helper
INFO - 2024-01-24 11:14:52 --> Helper loaded: file_helper
INFO - 2024-01-24 11:14:52 --> Helper loaded: html_helper
INFO - 2024-01-24 11:14:52 --> Helper loaded: text_helper
INFO - 2024-01-24 11:14:52 --> Helper loaded: form_helper
INFO - 2024-01-24 11:14:52 --> Helper loaded: lang_helper
INFO - 2024-01-24 11:14:52 --> Helper loaded: security_helper
INFO - 2024-01-24 11:14:52 --> Helper loaded: cookie_helper
INFO - 2024-01-24 11:14:52 --> Database Driver Class Initialized
INFO - 2024-01-24 11:14:52 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-24 11:14:52 --> Parser Class Initialized
INFO - 2024-01-24 11:14:52 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-01-24 11:14:52 --> Pagination Class Initialized
INFO - 2024-01-24 11:14:52 --> Form Validation Class Initialized
INFO - 2024-01-24 11:14:52 --> Controller Class Initialized
INFO - 2024-01-24 11:14:52 --> Model Class Initialized
DEBUG - 2024-01-24 11:14:52 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-01-24 11:14:52 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-24 11:14:52 --> Model Class Initialized
DEBUG - 2024-01-24 11:14:52 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-24 11:14:52 --> Model Class Initialized
INFO - 2024-01-24 11:14:52 --> Final output sent to browser
DEBUG - 2024-01-24 11:14:52 --> Total execution time: 0.4252
ERROR - 2024-01-24 11:15:13 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-01-24 11:15:13 --> Config Class Initialized
INFO - 2024-01-24 11:15:13 --> Hooks Class Initialized
DEBUG - 2024-01-24 11:15:13 --> UTF-8 Support Enabled
INFO - 2024-01-24 11:15:13 --> Utf8 Class Initialized
INFO - 2024-01-24 11:15:13 --> URI Class Initialized
DEBUG - 2024-01-24 11:15:13 --> No URI present. Default controller set.
INFO - 2024-01-24 11:15:13 --> Router Class Initialized
INFO - 2024-01-24 11:15:13 --> Output Class Initialized
INFO - 2024-01-24 11:15:13 --> Security Class Initialized
DEBUG - 2024-01-24 11:15:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-24 11:15:13 --> Input Class Initialized
INFO - 2024-01-24 11:15:13 --> Language Class Initialized
INFO - 2024-01-24 11:15:13 --> Loader Class Initialized
INFO - 2024-01-24 11:15:13 --> Helper loaded: url_helper
INFO - 2024-01-24 11:15:13 --> Helper loaded: file_helper
INFO - 2024-01-24 11:15:13 --> Helper loaded: html_helper
INFO - 2024-01-24 11:15:13 --> Helper loaded: text_helper
INFO - 2024-01-24 11:15:13 --> Helper loaded: form_helper
INFO - 2024-01-24 11:15:13 --> Helper loaded: lang_helper
INFO - 2024-01-24 11:15:13 --> Helper loaded: security_helper
INFO - 2024-01-24 11:15:13 --> Helper loaded: cookie_helper
INFO - 2024-01-24 11:15:13 --> Database Driver Class Initialized
INFO - 2024-01-24 11:15:13 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-24 11:15:13 --> Parser Class Initialized
INFO - 2024-01-24 11:15:13 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-01-24 11:15:13 --> Pagination Class Initialized
INFO - 2024-01-24 11:15:13 --> Form Validation Class Initialized
INFO - 2024-01-24 11:15:13 --> Controller Class Initialized
INFO - 2024-01-24 11:15:13 --> Model Class Initialized
DEBUG - 2024-01-24 11:15:13 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-24 11:15:13 --> Model Class Initialized
DEBUG - 2024-01-24 11:15:13 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-24 11:15:13 --> Model Class Initialized
INFO - 2024-01-24 11:15:13 --> Model Class Initialized
INFO - 2024-01-24 11:15:13 --> Model Class Initialized
INFO - 2024-01-24 11:15:13 --> Model Class Initialized
DEBUG - 2024-01-24 11:15:13 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-01-24 11:15:13 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-24 11:15:13 --> Model Class Initialized
INFO - 2024-01-24 11:15:13 --> Model Class Initialized
INFO - 2024-01-24 11:15:13 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2024-01-24 11:15:13 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-01-24 11:15:13 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-01-24 11:15:13 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-01-24 11:15:13 --> Model Class Initialized
INFO - 2024-01-24 11:15:13 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-01-24 11:15:13 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-01-24 11:15:13 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-01-24 11:15:13 --> Final output sent to browser
DEBUG - 2024-01-24 11:15:13 --> Total execution time: 0.2234
ERROR - 2024-01-24 11:15:40 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-01-24 11:15:40 --> Config Class Initialized
INFO - 2024-01-24 11:15:40 --> Hooks Class Initialized
DEBUG - 2024-01-24 11:15:40 --> UTF-8 Support Enabled
INFO - 2024-01-24 11:15:40 --> Utf8 Class Initialized
INFO - 2024-01-24 11:15:40 --> URI Class Initialized
DEBUG - 2024-01-24 11:15:40 --> No URI present. Default controller set.
INFO - 2024-01-24 11:15:40 --> Router Class Initialized
INFO - 2024-01-24 11:15:40 --> Output Class Initialized
INFO - 2024-01-24 11:15:40 --> Security Class Initialized
DEBUG - 2024-01-24 11:15:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-24 11:15:40 --> Input Class Initialized
INFO - 2024-01-24 11:15:40 --> Language Class Initialized
INFO - 2024-01-24 11:15:40 --> Loader Class Initialized
INFO - 2024-01-24 11:15:40 --> Helper loaded: url_helper
INFO - 2024-01-24 11:15:40 --> Helper loaded: file_helper
INFO - 2024-01-24 11:15:40 --> Helper loaded: html_helper
INFO - 2024-01-24 11:15:40 --> Helper loaded: text_helper
INFO - 2024-01-24 11:15:40 --> Helper loaded: form_helper
INFO - 2024-01-24 11:15:40 --> Helper loaded: lang_helper
INFO - 2024-01-24 11:15:40 --> Helper loaded: security_helper
INFO - 2024-01-24 11:15:40 --> Helper loaded: cookie_helper
INFO - 2024-01-24 11:15:40 --> Database Driver Class Initialized
INFO - 2024-01-24 11:15:40 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-24 11:15:40 --> Parser Class Initialized
INFO - 2024-01-24 11:15:40 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-01-24 11:15:40 --> Pagination Class Initialized
INFO - 2024-01-24 11:15:40 --> Form Validation Class Initialized
INFO - 2024-01-24 11:15:40 --> Controller Class Initialized
INFO - 2024-01-24 11:15:40 --> Model Class Initialized
DEBUG - 2024-01-24 11:15:40 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-24 11:15:40 --> Model Class Initialized
DEBUG - 2024-01-24 11:15:40 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-24 11:15:40 --> Model Class Initialized
INFO - 2024-01-24 11:15:40 --> Model Class Initialized
INFO - 2024-01-24 11:15:40 --> Model Class Initialized
INFO - 2024-01-24 11:15:40 --> Model Class Initialized
DEBUG - 2024-01-24 11:15:40 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-01-24 11:15:40 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-24 11:15:40 --> Model Class Initialized
INFO - 2024-01-24 11:15:40 --> Model Class Initialized
INFO - 2024-01-24 11:15:40 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2024-01-24 11:15:40 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-01-24 11:15:40 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-01-24 11:15:40 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-01-24 11:15:40 --> Model Class Initialized
INFO - 2024-01-24 11:15:40 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-01-24 11:15:40 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-01-24 11:15:40 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-01-24 11:15:40 --> Final output sent to browser
DEBUG - 2024-01-24 11:15:40 --> Total execution time: 0.2332
ERROR - 2024-01-24 11:16:10 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-01-24 11:16:10 --> Config Class Initialized
INFO - 2024-01-24 11:16:10 --> Hooks Class Initialized
DEBUG - 2024-01-24 11:16:10 --> UTF-8 Support Enabled
INFO - 2024-01-24 11:16:10 --> Utf8 Class Initialized
INFO - 2024-01-24 11:16:10 --> URI Class Initialized
INFO - 2024-01-24 11:16:10 --> Router Class Initialized
INFO - 2024-01-24 11:16:10 --> Output Class Initialized
INFO - 2024-01-24 11:16:10 --> Security Class Initialized
DEBUG - 2024-01-24 11:16:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-24 11:16:10 --> Input Class Initialized
INFO - 2024-01-24 11:16:10 --> Language Class Initialized
INFO - 2024-01-24 11:16:10 --> Loader Class Initialized
INFO - 2024-01-24 11:16:10 --> Helper loaded: url_helper
INFO - 2024-01-24 11:16:10 --> Helper loaded: file_helper
INFO - 2024-01-24 11:16:10 --> Helper loaded: html_helper
INFO - 2024-01-24 11:16:10 --> Helper loaded: text_helper
INFO - 2024-01-24 11:16:10 --> Helper loaded: form_helper
INFO - 2024-01-24 11:16:10 --> Helper loaded: lang_helper
INFO - 2024-01-24 11:16:10 --> Helper loaded: security_helper
INFO - 2024-01-24 11:16:10 --> Helper loaded: cookie_helper
INFO - 2024-01-24 11:16:10 --> Database Driver Class Initialized
INFO - 2024-01-24 11:16:10 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-24 11:16:10 --> Parser Class Initialized
INFO - 2024-01-24 11:16:10 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-01-24 11:16:10 --> Pagination Class Initialized
INFO - 2024-01-24 11:16:10 --> Form Validation Class Initialized
INFO - 2024-01-24 11:16:10 --> Controller Class Initialized
INFO - 2024-01-24 11:16:10 --> Model Class Initialized
DEBUG - 2024-01-24 11:16:10 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-01-24 11:16:10 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-24 11:16:10 --> Model Class Initialized
DEBUG - 2024-01-24 11:16:10 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-24 11:16:10 --> Model Class Initialized
INFO - 2024-01-24 11:16:10 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice.php
DEBUG - 2024-01-24 11:16:10 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-01-24 11:16:10 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-01-24 11:16:10 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-01-24 11:16:10 --> Model Class Initialized
INFO - 2024-01-24 11:16:10 --> Model Class Initialized
INFO - 2024-01-24 11:16:10 --> Model Class Initialized
INFO - 2024-01-24 11:16:10 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-01-24 11:16:10 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-01-24 11:16:10 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-01-24 11:16:10 --> Final output sent to browser
DEBUG - 2024-01-24 11:16:10 --> Total execution time: 0.1450
ERROR - 2024-01-24 11:16:11 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-01-24 11:16:11 --> Config Class Initialized
INFO - 2024-01-24 11:16:11 --> Hooks Class Initialized
DEBUG - 2024-01-24 11:16:11 --> UTF-8 Support Enabled
INFO - 2024-01-24 11:16:11 --> Utf8 Class Initialized
INFO - 2024-01-24 11:16:11 --> URI Class Initialized
INFO - 2024-01-24 11:16:11 --> Router Class Initialized
INFO - 2024-01-24 11:16:11 --> Output Class Initialized
INFO - 2024-01-24 11:16:11 --> Security Class Initialized
DEBUG - 2024-01-24 11:16:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-24 11:16:11 --> Input Class Initialized
INFO - 2024-01-24 11:16:11 --> Language Class Initialized
INFO - 2024-01-24 11:16:11 --> Loader Class Initialized
INFO - 2024-01-24 11:16:11 --> Helper loaded: url_helper
INFO - 2024-01-24 11:16:11 --> Helper loaded: file_helper
INFO - 2024-01-24 11:16:11 --> Helper loaded: html_helper
INFO - 2024-01-24 11:16:11 --> Helper loaded: text_helper
INFO - 2024-01-24 11:16:11 --> Helper loaded: form_helper
INFO - 2024-01-24 11:16:11 --> Helper loaded: lang_helper
INFO - 2024-01-24 11:16:11 --> Helper loaded: security_helper
INFO - 2024-01-24 11:16:11 --> Helper loaded: cookie_helper
INFO - 2024-01-24 11:16:11 --> Database Driver Class Initialized
INFO - 2024-01-24 11:16:11 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-24 11:16:11 --> Parser Class Initialized
INFO - 2024-01-24 11:16:11 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-01-24 11:16:11 --> Pagination Class Initialized
INFO - 2024-01-24 11:16:11 --> Form Validation Class Initialized
INFO - 2024-01-24 11:16:11 --> Controller Class Initialized
INFO - 2024-01-24 11:16:11 --> Model Class Initialized
DEBUG - 2024-01-24 11:16:11 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-01-24 11:16:11 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-24 11:16:11 --> Model Class Initialized
DEBUG - 2024-01-24 11:16:11 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-24 11:16:11 --> Model Class Initialized
INFO - 2024-01-24 11:16:11 --> Final output sent to browser
DEBUG - 2024-01-24 11:16:11 --> Total execution time: 0.0401
ERROR - 2024-01-24 11:16:14 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-01-24 11:16:14 --> Config Class Initialized
INFO - 2024-01-24 11:16:14 --> Hooks Class Initialized
DEBUG - 2024-01-24 11:16:14 --> UTF-8 Support Enabled
INFO - 2024-01-24 11:16:14 --> Utf8 Class Initialized
INFO - 2024-01-24 11:16:14 --> URI Class Initialized
INFO - 2024-01-24 11:16:14 --> Router Class Initialized
INFO - 2024-01-24 11:16:14 --> Output Class Initialized
INFO - 2024-01-24 11:16:14 --> Security Class Initialized
DEBUG - 2024-01-24 11:16:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-24 11:16:14 --> Input Class Initialized
INFO - 2024-01-24 11:16:14 --> Language Class Initialized
INFO - 2024-01-24 11:16:14 --> Loader Class Initialized
INFO - 2024-01-24 11:16:14 --> Helper loaded: url_helper
INFO - 2024-01-24 11:16:14 --> Helper loaded: file_helper
INFO - 2024-01-24 11:16:14 --> Helper loaded: html_helper
INFO - 2024-01-24 11:16:14 --> Helper loaded: text_helper
INFO - 2024-01-24 11:16:14 --> Helper loaded: form_helper
INFO - 2024-01-24 11:16:14 --> Helper loaded: lang_helper
INFO - 2024-01-24 11:16:14 --> Helper loaded: security_helper
INFO - 2024-01-24 11:16:14 --> Helper loaded: cookie_helper
INFO - 2024-01-24 11:16:14 --> Database Driver Class Initialized
INFO - 2024-01-24 11:16:14 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-24 11:16:14 --> Parser Class Initialized
INFO - 2024-01-24 11:16:14 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-01-24 11:16:14 --> Pagination Class Initialized
INFO - 2024-01-24 11:16:14 --> Form Validation Class Initialized
INFO - 2024-01-24 11:16:14 --> Controller Class Initialized
INFO - 2024-01-24 11:16:14 --> Model Class Initialized
DEBUG - 2024-01-24 11:16:14 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-01-24 11:16:14 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-24 11:16:14 --> Model Class Initialized
DEBUG - 2024-01-24 11:16:14 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-24 11:16:14 --> Model Class Initialized
INFO - 2024-01-24 11:16:14 --> Final output sent to browser
DEBUG - 2024-01-24 11:16:14 --> Total execution time: 0.4204
ERROR - 2024-01-24 11:16:27 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-01-24 11:16:27 --> Config Class Initialized
INFO - 2024-01-24 11:16:27 --> Hooks Class Initialized
DEBUG - 2024-01-24 11:16:27 --> UTF-8 Support Enabled
INFO - 2024-01-24 11:16:27 --> Utf8 Class Initialized
INFO - 2024-01-24 11:16:27 --> URI Class Initialized
INFO - 2024-01-24 11:16:27 --> Router Class Initialized
INFO - 2024-01-24 11:16:27 --> Output Class Initialized
INFO - 2024-01-24 11:16:27 --> Security Class Initialized
DEBUG - 2024-01-24 11:16:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-24 11:16:27 --> Input Class Initialized
INFO - 2024-01-24 11:16:27 --> Language Class Initialized
INFO - 2024-01-24 11:16:27 --> Loader Class Initialized
INFO - 2024-01-24 11:16:27 --> Helper loaded: url_helper
INFO - 2024-01-24 11:16:27 --> Helper loaded: file_helper
INFO - 2024-01-24 11:16:27 --> Helper loaded: html_helper
INFO - 2024-01-24 11:16:27 --> Helper loaded: text_helper
INFO - 2024-01-24 11:16:27 --> Helper loaded: form_helper
INFO - 2024-01-24 11:16:27 --> Helper loaded: lang_helper
INFO - 2024-01-24 11:16:27 --> Helper loaded: security_helper
INFO - 2024-01-24 11:16:27 --> Helper loaded: cookie_helper
INFO - 2024-01-24 11:16:27 --> Database Driver Class Initialized
INFO - 2024-01-24 11:16:27 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-24 11:16:27 --> Parser Class Initialized
INFO - 2024-01-24 11:16:27 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-01-24 11:16:27 --> Pagination Class Initialized
INFO - 2024-01-24 11:16:27 --> Form Validation Class Initialized
INFO - 2024-01-24 11:16:27 --> Controller Class Initialized
INFO - 2024-01-24 11:16:27 --> Model Class Initialized
DEBUG - 2024-01-24 11:16:27 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-01-24 11:16:27 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-24 11:16:27 --> Model Class Initialized
DEBUG - 2024-01-24 11:16:27 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-24 11:16:28 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/demandrequest/add_demandrequest_form.php
DEBUG - 2024-01-24 11:16:28 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-01-24 11:16:28 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-01-24 11:16:28 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-01-24 11:16:28 --> Model Class Initialized
INFO - 2024-01-24 11:16:28 --> Model Class Initialized
INFO - 2024-01-24 11:16:28 --> Model Class Initialized
INFO - 2024-01-24 11:16:28 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-01-24 11:16:28 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-01-24 11:16:28 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-01-24 11:16:28 --> Final output sent to browser
DEBUG - 2024-01-24 11:16:28 --> Total execution time: 0.1445
ERROR - 2024-01-24 11:16:30 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-01-24 11:16:30 --> Config Class Initialized
INFO - 2024-01-24 11:16:30 --> Hooks Class Initialized
DEBUG - 2024-01-24 11:16:30 --> UTF-8 Support Enabled
INFO - 2024-01-24 11:16:30 --> Utf8 Class Initialized
INFO - 2024-01-24 11:16:30 --> URI Class Initialized
INFO - 2024-01-24 11:16:30 --> Router Class Initialized
INFO - 2024-01-24 11:16:30 --> Output Class Initialized
INFO - 2024-01-24 11:16:30 --> Security Class Initialized
DEBUG - 2024-01-24 11:16:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-24 11:16:30 --> Input Class Initialized
INFO - 2024-01-24 11:16:30 --> Language Class Initialized
INFO - 2024-01-24 11:16:30 --> Loader Class Initialized
INFO - 2024-01-24 11:16:30 --> Helper loaded: url_helper
INFO - 2024-01-24 11:16:30 --> Helper loaded: file_helper
INFO - 2024-01-24 11:16:30 --> Helper loaded: html_helper
INFO - 2024-01-24 11:16:30 --> Helper loaded: text_helper
INFO - 2024-01-24 11:16:30 --> Helper loaded: form_helper
INFO - 2024-01-24 11:16:30 --> Helper loaded: lang_helper
INFO - 2024-01-24 11:16:30 --> Helper loaded: security_helper
INFO - 2024-01-24 11:16:30 --> Helper loaded: cookie_helper
INFO - 2024-01-24 11:16:30 --> Database Driver Class Initialized
INFO - 2024-01-24 11:16:30 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-24 11:16:30 --> Parser Class Initialized
INFO - 2024-01-24 11:16:30 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-01-24 11:16:30 --> Pagination Class Initialized
INFO - 2024-01-24 11:16:30 --> Form Validation Class Initialized
INFO - 2024-01-24 11:16:30 --> Controller Class Initialized
INFO - 2024-01-24 11:16:30 --> Model Class Initialized
DEBUG - 2024-01-24 11:16:30 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-01-24 11:16:30 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-24 11:16:30 --> Model Class Initialized
INFO - 2024-01-24 11:16:30 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/demandrequest/demandrequest.php
DEBUG - 2024-01-24 11:16:30 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-01-24 11:16:30 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-01-24 11:16:30 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-01-24 11:16:30 --> Model Class Initialized
INFO - 2024-01-24 11:16:30 --> Model Class Initialized
INFO - 2024-01-24 11:16:30 --> Model Class Initialized
INFO - 2024-01-24 11:16:30 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-01-24 11:16:30 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-01-24 11:16:30 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-01-24 11:16:30 --> Final output sent to browser
DEBUG - 2024-01-24 11:16:30 --> Total execution time: 0.1416
ERROR - 2024-01-24 11:16:31 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-01-24 11:16:31 --> Config Class Initialized
INFO - 2024-01-24 11:16:31 --> Hooks Class Initialized
DEBUG - 2024-01-24 11:16:31 --> UTF-8 Support Enabled
INFO - 2024-01-24 11:16:31 --> Utf8 Class Initialized
INFO - 2024-01-24 11:16:31 --> URI Class Initialized
INFO - 2024-01-24 11:16:31 --> Router Class Initialized
INFO - 2024-01-24 11:16:31 --> Output Class Initialized
INFO - 2024-01-24 11:16:31 --> Security Class Initialized
DEBUG - 2024-01-24 11:16:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-24 11:16:31 --> Input Class Initialized
INFO - 2024-01-24 11:16:31 --> Language Class Initialized
INFO - 2024-01-24 11:16:31 --> Loader Class Initialized
INFO - 2024-01-24 11:16:31 --> Helper loaded: url_helper
INFO - 2024-01-24 11:16:31 --> Helper loaded: file_helper
INFO - 2024-01-24 11:16:31 --> Helper loaded: html_helper
INFO - 2024-01-24 11:16:31 --> Helper loaded: text_helper
INFO - 2024-01-24 11:16:31 --> Helper loaded: form_helper
INFO - 2024-01-24 11:16:31 --> Helper loaded: lang_helper
INFO - 2024-01-24 11:16:31 --> Helper loaded: security_helper
INFO - 2024-01-24 11:16:31 --> Helper loaded: cookie_helper
INFO - 2024-01-24 11:16:31 --> Database Driver Class Initialized
INFO - 2024-01-24 11:16:31 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-24 11:16:31 --> Parser Class Initialized
INFO - 2024-01-24 11:16:31 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-01-24 11:16:31 --> Pagination Class Initialized
INFO - 2024-01-24 11:16:31 --> Form Validation Class Initialized
INFO - 2024-01-24 11:16:31 --> Controller Class Initialized
INFO - 2024-01-24 11:16:31 --> Model Class Initialized
DEBUG - 2024-01-24 11:16:31 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-01-24 11:16:31 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-24 11:16:31 --> Model Class Initialized
INFO - 2024-01-24 11:16:31 --> Final output sent to browser
DEBUG - 2024-01-24 11:16:31 --> Total execution time: 0.0169
ERROR - 2024-01-24 11:16:32 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-01-24 11:16:32 --> Config Class Initialized
INFO - 2024-01-24 11:16:32 --> Hooks Class Initialized
DEBUG - 2024-01-24 11:16:32 --> UTF-8 Support Enabled
INFO - 2024-01-24 11:16:32 --> Utf8 Class Initialized
INFO - 2024-01-24 11:16:32 --> URI Class Initialized
INFO - 2024-01-24 11:16:32 --> Router Class Initialized
INFO - 2024-01-24 11:16:32 --> Output Class Initialized
INFO - 2024-01-24 11:16:32 --> Security Class Initialized
DEBUG - 2024-01-24 11:16:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-24 11:16:32 --> Input Class Initialized
INFO - 2024-01-24 11:16:32 --> Language Class Initialized
INFO - 2024-01-24 11:16:32 --> Loader Class Initialized
INFO - 2024-01-24 11:16:32 --> Helper loaded: url_helper
INFO - 2024-01-24 11:16:32 --> Helper loaded: file_helper
INFO - 2024-01-24 11:16:32 --> Helper loaded: html_helper
INFO - 2024-01-24 11:16:32 --> Helper loaded: text_helper
INFO - 2024-01-24 11:16:32 --> Helper loaded: form_helper
INFO - 2024-01-24 11:16:32 --> Helper loaded: lang_helper
INFO - 2024-01-24 11:16:32 --> Helper loaded: security_helper
INFO - 2024-01-24 11:16:32 --> Helper loaded: cookie_helper
INFO - 2024-01-24 11:16:32 --> Database Driver Class Initialized
INFO - 2024-01-24 11:16:32 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-24 11:16:32 --> Parser Class Initialized
INFO - 2024-01-24 11:16:32 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-01-24 11:16:32 --> Pagination Class Initialized
INFO - 2024-01-24 11:16:32 --> Form Validation Class Initialized
INFO - 2024-01-24 11:16:32 --> Controller Class Initialized
INFO - 2024-01-24 11:16:32 --> Model Class Initialized
DEBUG - 2024-01-24 11:16:32 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-01-24 11:16:32 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-24 11:16:32 --> Model Class Initialized
INFO - 2024-01-24 11:16:32 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/demandrequest/customer_demandrequest.php
DEBUG - 2024-01-24 11:16:32 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-01-24 11:16:32 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-01-24 11:16:32 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-01-24 11:16:32 --> Model Class Initialized
INFO - 2024-01-24 11:16:32 --> Model Class Initialized
INFO - 2024-01-24 11:16:32 --> Model Class Initialized
INFO - 2024-01-24 11:16:32 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-01-24 11:16:32 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-01-24 11:16:32 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-01-24 11:16:32 --> Final output sent to browser
DEBUG - 2024-01-24 11:16:32 --> Total execution time: 0.1353
ERROR - 2024-01-24 11:16:33 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-01-24 11:16:33 --> Config Class Initialized
INFO - 2024-01-24 11:16:33 --> Hooks Class Initialized
DEBUG - 2024-01-24 11:16:33 --> UTF-8 Support Enabled
INFO - 2024-01-24 11:16:33 --> Utf8 Class Initialized
INFO - 2024-01-24 11:16:33 --> URI Class Initialized
INFO - 2024-01-24 11:16:33 --> Router Class Initialized
INFO - 2024-01-24 11:16:33 --> Output Class Initialized
INFO - 2024-01-24 11:16:33 --> Security Class Initialized
DEBUG - 2024-01-24 11:16:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-24 11:16:33 --> Input Class Initialized
INFO - 2024-01-24 11:16:33 --> Language Class Initialized
INFO - 2024-01-24 11:16:33 --> Loader Class Initialized
INFO - 2024-01-24 11:16:33 --> Helper loaded: url_helper
INFO - 2024-01-24 11:16:33 --> Helper loaded: file_helper
INFO - 2024-01-24 11:16:33 --> Helper loaded: html_helper
INFO - 2024-01-24 11:16:33 --> Helper loaded: text_helper
INFO - 2024-01-24 11:16:33 --> Helper loaded: form_helper
INFO - 2024-01-24 11:16:33 --> Helper loaded: lang_helper
INFO - 2024-01-24 11:16:33 --> Helper loaded: security_helper
INFO - 2024-01-24 11:16:33 --> Helper loaded: cookie_helper
INFO - 2024-01-24 11:16:33 --> Database Driver Class Initialized
INFO - 2024-01-24 11:16:33 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-24 11:16:33 --> Parser Class Initialized
INFO - 2024-01-24 11:16:33 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-01-24 11:16:33 --> Pagination Class Initialized
INFO - 2024-01-24 11:16:33 --> Form Validation Class Initialized
INFO - 2024-01-24 11:16:33 --> Controller Class Initialized
INFO - 2024-01-24 11:16:33 --> Model Class Initialized
DEBUG - 2024-01-24 11:16:33 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-01-24 11:16:33 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-24 11:16:33 --> Model Class Initialized
INFO - 2024-01-24 11:16:33 --> Final output sent to browser
DEBUG - 2024-01-24 11:16:33 --> Total execution time: 0.0169
ERROR - 2024-01-24 11:16:34 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-01-24 11:16:34 --> Config Class Initialized
INFO - 2024-01-24 11:16:34 --> Hooks Class Initialized
DEBUG - 2024-01-24 11:16:34 --> UTF-8 Support Enabled
INFO - 2024-01-24 11:16:34 --> Utf8 Class Initialized
INFO - 2024-01-24 11:16:34 --> URI Class Initialized
INFO - 2024-01-24 11:16:34 --> Router Class Initialized
INFO - 2024-01-24 11:16:34 --> Output Class Initialized
INFO - 2024-01-24 11:16:34 --> Security Class Initialized
DEBUG - 2024-01-24 11:16:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-24 11:16:34 --> Input Class Initialized
INFO - 2024-01-24 11:16:34 --> Language Class Initialized
INFO - 2024-01-24 11:16:34 --> Loader Class Initialized
INFO - 2024-01-24 11:16:34 --> Helper loaded: url_helper
INFO - 2024-01-24 11:16:34 --> Helper loaded: file_helper
INFO - 2024-01-24 11:16:34 --> Helper loaded: html_helper
INFO - 2024-01-24 11:16:34 --> Helper loaded: text_helper
INFO - 2024-01-24 11:16:34 --> Helper loaded: form_helper
INFO - 2024-01-24 11:16:34 --> Helper loaded: lang_helper
INFO - 2024-01-24 11:16:34 --> Helper loaded: security_helper
INFO - 2024-01-24 11:16:34 --> Helper loaded: cookie_helper
INFO - 2024-01-24 11:16:34 --> Database Driver Class Initialized
INFO - 2024-01-24 11:16:34 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-24 11:16:34 --> Parser Class Initialized
INFO - 2024-01-24 11:16:34 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-01-24 11:16:34 --> Pagination Class Initialized
INFO - 2024-01-24 11:16:34 --> Form Validation Class Initialized
INFO - 2024-01-24 11:16:34 --> Controller Class Initialized
INFO - 2024-01-24 11:16:34 --> Model Class Initialized
DEBUG - 2024-01-24 11:16:34 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-01-24 11:16:34 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-24 11:16:34 --> Model Class Initialized
DEBUG - 2024-01-24 11:16:34 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-24 11:16:34 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/demandrequest/add_demandrequest_form.php
DEBUG - 2024-01-24 11:16:34 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-01-24 11:16:34 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-01-24 11:16:34 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-01-24 11:16:34 --> Model Class Initialized
INFO - 2024-01-24 11:16:34 --> Model Class Initialized
INFO - 2024-01-24 11:16:34 --> Model Class Initialized
INFO - 2024-01-24 11:16:34 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-01-24 11:16:34 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-01-24 11:16:34 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-01-24 11:16:34 --> Final output sent to browser
DEBUG - 2024-01-24 11:16:34 --> Total execution time: 0.1389
ERROR - 2024-01-24 11:16:36 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-01-24 11:16:36 --> Config Class Initialized
INFO - 2024-01-24 11:16:36 --> Hooks Class Initialized
DEBUG - 2024-01-24 11:16:36 --> UTF-8 Support Enabled
INFO - 2024-01-24 11:16:36 --> Utf8 Class Initialized
INFO - 2024-01-24 11:16:36 --> URI Class Initialized
INFO - 2024-01-24 11:16:36 --> Router Class Initialized
INFO - 2024-01-24 11:16:36 --> Output Class Initialized
INFO - 2024-01-24 11:16:36 --> Security Class Initialized
DEBUG - 2024-01-24 11:16:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-24 11:16:36 --> Input Class Initialized
INFO - 2024-01-24 11:16:36 --> Language Class Initialized
INFO - 2024-01-24 11:16:36 --> Loader Class Initialized
INFO - 2024-01-24 11:16:36 --> Helper loaded: url_helper
INFO - 2024-01-24 11:16:36 --> Helper loaded: file_helper
INFO - 2024-01-24 11:16:36 --> Helper loaded: html_helper
INFO - 2024-01-24 11:16:36 --> Helper loaded: text_helper
INFO - 2024-01-24 11:16:36 --> Helper loaded: form_helper
INFO - 2024-01-24 11:16:36 --> Helper loaded: lang_helper
INFO - 2024-01-24 11:16:36 --> Helper loaded: security_helper
INFO - 2024-01-24 11:16:36 --> Helper loaded: cookie_helper
INFO - 2024-01-24 11:16:36 --> Database Driver Class Initialized
INFO - 2024-01-24 11:16:36 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-24 11:16:36 --> Parser Class Initialized
INFO - 2024-01-24 11:16:36 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-01-24 11:16:36 --> Pagination Class Initialized
INFO - 2024-01-24 11:16:36 --> Form Validation Class Initialized
INFO - 2024-01-24 11:16:36 --> Controller Class Initialized
INFO - 2024-01-24 11:16:36 --> Model Class Initialized
DEBUG - 2024-01-24 11:16:36 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-01-24 11:16:36 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-24 11:16:36 --> Model Class Initialized
INFO - 2024-01-24 11:16:36 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/demandrequest/demandrequest.php
DEBUG - 2024-01-24 11:16:36 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-01-24 11:16:36 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-01-24 11:16:36 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-01-24 11:16:36 --> Model Class Initialized
INFO - 2024-01-24 11:16:36 --> Model Class Initialized
INFO - 2024-01-24 11:16:36 --> Model Class Initialized
INFO - 2024-01-24 11:16:36 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-01-24 11:16:36 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-01-24 11:16:36 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-01-24 11:16:36 --> Final output sent to browser
DEBUG - 2024-01-24 11:16:36 --> Total execution time: 0.1383
ERROR - 2024-01-24 11:16:37 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-01-24 11:16:37 --> Config Class Initialized
INFO - 2024-01-24 11:16:37 --> Hooks Class Initialized
DEBUG - 2024-01-24 11:16:37 --> UTF-8 Support Enabled
INFO - 2024-01-24 11:16:37 --> Utf8 Class Initialized
INFO - 2024-01-24 11:16:37 --> URI Class Initialized
INFO - 2024-01-24 11:16:37 --> Router Class Initialized
INFO - 2024-01-24 11:16:37 --> Output Class Initialized
INFO - 2024-01-24 11:16:37 --> Security Class Initialized
DEBUG - 2024-01-24 11:16:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-24 11:16:37 --> Input Class Initialized
INFO - 2024-01-24 11:16:37 --> Language Class Initialized
INFO - 2024-01-24 11:16:37 --> Loader Class Initialized
INFO - 2024-01-24 11:16:37 --> Helper loaded: url_helper
INFO - 2024-01-24 11:16:37 --> Helper loaded: file_helper
INFO - 2024-01-24 11:16:37 --> Helper loaded: html_helper
INFO - 2024-01-24 11:16:37 --> Helper loaded: text_helper
INFO - 2024-01-24 11:16:37 --> Helper loaded: form_helper
INFO - 2024-01-24 11:16:37 --> Helper loaded: lang_helper
INFO - 2024-01-24 11:16:37 --> Helper loaded: security_helper
INFO - 2024-01-24 11:16:37 --> Helper loaded: cookie_helper
INFO - 2024-01-24 11:16:37 --> Database Driver Class Initialized
INFO - 2024-01-24 11:16:37 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-24 11:16:37 --> Parser Class Initialized
INFO - 2024-01-24 11:16:37 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-01-24 11:16:37 --> Pagination Class Initialized
INFO - 2024-01-24 11:16:37 --> Form Validation Class Initialized
INFO - 2024-01-24 11:16:37 --> Controller Class Initialized
INFO - 2024-01-24 11:16:37 --> Model Class Initialized
DEBUG - 2024-01-24 11:16:37 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-01-24 11:16:37 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-24 11:16:37 --> Model Class Initialized
INFO - 2024-01-24 11:16:37 --> Final output sent to browser
DEBUG - 2024-01-24 11:16:37 --> Total execution time: 0.0160
ERROR - 2024-01-24 11:16:38 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-01-24 11:16:38 --> Config Class Initialized
INFO - 2024-01-24 11:16:38 --> Hooks Class Initialized
DEBUG - 2024-01-24 11:16:38 --> UTF-8 Support Enabled
INFO - 2024-01-24 11:16:38 --> Utf8 Class Initialized
INFO - 2024-01-24 11:16:38 --> URI Class Initialized
INFO - 2024-01-24 11:16:38 --> Router Class Initialized
INFO - 2024-01-24 11:16:38 --> Output Class Initialized
INFO - 2024-01-24 11:16:38 --> Security Class Initialized
DEBUG - 2024-01-24 11:16:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-24 11:16:38 --> Input Class Initialized
INFO - 2024-01-24 11:16:38 --> Language Class Initialized
INFO - 2024-01-24 11:16:38 --> Loader Class Initialized
INFO - 2024-01-24 11:16:38 --> Helper loaded: url_helper
INFO - 2024-01-24 11:16:38 --> Helper loaded: file_helper
INFO - 2024-01-24 11:16:38 --> Helper loaded: html_helper
INFO - 2024-01-24 11:16:38 --> Helper loaded: text_helper
INFO - 2024-01-24 11:16:38 --> Helper loaded: form_helper
INFO - 2024-01-24 11:16:38 --> Helper loaded: lang_helper
INFO - 2024-01-24 11:16:38 --> Helper loaded: security_helper
INFO - 2024-01-24 11:16:38 --> Helper loaded: cookie_helper
INFO - 2024-01-24 11:16:38 --> Database Driver Class Initialized
INFO - 2024-01-24 11:16:38 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-24 11:16:38 --> Parser Class Initialized
INFO - 2024-01-24 11:16:38 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-01-24 11:16:38 --> Pagination Class Initialized
INFO - 2024-01-24 11:16:38 --> Form Validation Class Initialized
INFO - 2024-01-24 11:16:38 --> Controller Class Initialized
INFO - 2024-01-24 11:16:38 --> Model Class Initialized
DEBUG - 2024-01-24 11:16:38 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-01-24 11:16:38 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-24 11:16:38 --> Model Class Initialized
INFO - 2024-01-24 11:16:38 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/demandrequest/customer_demandrequest.php
DEBUG - 2024-01-24 11:16:38 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-01-24 11:16:38 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-01-24 11:16:38 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-01-24 11:16:38 --> Model Class Initialized
INFO - 2024-01-24 11:16:38 --> Model Class Initialized
INFO - 2024-01-24 11:16:38 --> Model Class Initialized
INFO - 2024-01-24 11:16:38 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-01-24 11:16:38 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-01-24 11:16:38 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-01-24 11:16:38 --> Final output sent to browser
DEBUG - 2024-01-24 11:16:38 --> Total execution time: 0.1397
ERROR - 2024-01-24 11:16:39 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-01-24 11:16:39 --> Config Class Initialized
INFO - 2024-01-24 11:16:39 --> Hooks Class Initialized
DEBUG - 2024-01-24 11:16:39 --> UTF-8 Support Enabled
INFO - 2024-01-24 11:16:39 --> Utf8 Class Initialized
INFO - 2024-01-24 11:16:39 --> URI Class Initialized
INFO - 2024-01-24 11:16:39 --> Router Class Initialized
INFO - 2024-01-24 11:16:39 --> Output Class Initialized
INFO - 2024-01-24 11:16:39 --> Security Class Initialized
DEBUG - 2024-01-24 11:16:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-24 11:16:39 --> Input Class Initialized
INFO - 2024-01-24 11:16:39 --> Language Class Initialized
INFO - 2024-01-24 11:16:39 --> Loader Class Initialized
INFO - 2024-01-24 11:16:39 --> Helper loaded: url_helper
INFO - 2024-01-24 11:16:39 --> Helper loaded: file_helper
INFO - 2024-01-24 11:16:39 --> Helper loaded: html_helper
INFO - 2024-01-24 11:16:39 --> Helper loaded: text_helper
INFO - 2024-01-24 11:16:39 --> Helper loaded: form_helper
INFO - 2024-01-24 11:16:39 --> Helper loaded: lang_helper
INFO - 2024-01-24 11:16:39 --> Helper loaded: security_helper
INFO - 2024-01-24 11:16:39 --> Helper loaded: cookie_helper
INFO - 2024-01-24 11:16:39 --> Database Driver Class Initialized
INFO - 2024-01-24 11:16:39 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-24 11:16:39 --> Parser Class Initialized
INFO - 2024-01-24 11:16:39 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-01-24 11:16:39 --> Pagination Class Initialized
INFO - 2024-01-24 11:16:39 --> Form Validation Class Initialized
INFO - 2024-01-24 11:16:39 --> Controller Class Initialized
INFO - 2024-01-24 11:16:39 --> Model Class Initialized
DEBUG - 2024-01-24 11:16:39 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-01-24 11:16:39 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-24 11:16:39 --> Model Class Initialized
INFO - 2024-01-24 11:16:39 --> Final output sent to browser
DEBUG - 2024-01-24 11:16:39 --> Total execution time: 0.0159
ERROR - 2024-01-24 11:16:45 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-01-24 11:16:45 --> Config Class Initialized
INFO - 2024-01-24 11:16:45 --> Hooks Class Initialized
DEBUG - 2024-01-24 11:16:45 --> UTF-8 Support Enabled
INFO - 2024-01-24 11:16:45 --> Utf8 Class Initialized
INFO - 2024-01-24 11:16:45 --> URI Class Initialized
INFO - 2024-01-24 11:16:45 --> Router Class Initialized
INFO - 2024-01-24 11:16:45 --> Output Class Initialized
INFO - 2024-01-24 11:16:45 --> Security Class Initialized
DEBUG - 2024-01-24 11:16:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-24 11:16:45 --> Input Class Initialized
INFO - 2024-01-24 11:16:45 --> Language Class Initialized
INFO - 2024-01-24 11:16:45 --> Loader Class Initialized
INFO - 2024-01-24 11:16:45 --> Helper loaded: url_helper
INFO - 2024-01-24 11:16:45 --> Helper loaded: file_helper
INFO - 2024-01-24 11:16:45 --> Helper loaded: html_helper
INFO - 2024-01-24 11:16:45 --> Helper loaded: text_helper
INFO - 2024-01-24 11:16:45 --> Helper loaded: form_helper
INFO - 2024-01-24 11:16:45 --> Helper loaded: lang_helper
INFO - 2024-01-24 11:16:45 --> Helper loaded: security_helper
INFO - 2024-01-24 11:16:45 --> Helper loaded: cookie_helper
INFO - 2024-01-24 11:16:45 --> Database Driver Class Initialized
INFO - 2024-01-24 11:16:45 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-24 11:16:45 --> Parser Class Initialized
INFO - 2024-01-24 11:16:45 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-01-24 11:16:45 --> Pagination Class Initialized
INFO - 2024-01-24 11:16:45 --> Form Validation Class Initialized
INFO - 2024-01-24 11:16:45 --> Controller Class Initialized
INFO - 2024-01-24 11:16:45 --> Model Class Initialized
DEBUG - 2024-01-24 11:16:45 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-01-24 11:16:45 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-24 11:16:45 --> Model Class Initialized
INFO - 2024-01-24 11:16:45 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/stockrequest/inventory.php
DEBUG - 2024-01-24 11:16:45 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-01-24 11:16:45 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-01-24 11:16:45 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-01-24 11:16:45 --> Model Class Initialized
INFO - 2024-01-24 11:16:45 --> Model Class Initialized
INFO - 2024-01-24 11:16:45 --> Model Class Initialized
INFO - 2024-01-24 11:16:45 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-01-24 11:16:45 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-01-24 11:16:45 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-01-24 11:16:45 --> Final output sent to browser
DEBUG - 2024-01-24 11:16:45 --> Total execution time: 0.1302
ERROR - 2024-01-24 11:16:46 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-01-24 11:16:46 --> Config Class Initialized
INFO - 2024-01-24 11:16:46 --> Hooks Class Initialized
DEBUG - 2024-01-24 11:16:46 --> UTF-8 Support Enabled
INFO - 2024-01-24 11:16:46 --> Utf8 Class Initialized
INFO - 2024-01-24 11:16:46 --> URI Class Initialized
INFO - 2024-01-24 11:16:46 --> Router Class Initialized
INFO - 2024-01-24 11:16:46 --> Output Class Initialized
INFO - 2024-01-24 11:16:46 --> Security Class Initialized
DEBUG - 2024-01-24 11:16:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-24 11:16:46 --> Input Class Initialized
INFO - 2024-01-24 11:16:46 --> Language Class Initialized
INFO - 2024-01-24 11:16:46 --> Loader Class Initialized
INFO - 2024-01-24 11:16:46 --> Helper loaded: url_helper
INFO - 2024-01-24 11:16:46 --> Helper loaded: file_helper
INFO - 2024-01-24 11:16:46 --> Helper loaded: html_helper
INFO - 2024-01-24 11:16:46 --> Helper loaded: text_helper
INFO - 2024-01-24 11:16:46 --> Helper loaded: form_helper
INFO - 2024-01-24 11:16:46 --> Helper loaded: lang_helper
INFO - 2024-01-24 11:16:46 --> Helper loaded: security_helper
INFO - 2024-01-24 11:16:46 --> Helper loaded: cookie_helper
INFO - 2024-01-24 11:16:46 --> Database Driver Class Initialized
INFO - 2024-01-24 11:16:46 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-24 11:16:46 --> Parser Class Initialized
INFO - 2024-01-24 11:16:46 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-01-24 11:16:46 --> Pagination Class Initialized
INFO - 2024-01-24 11:16:46 --> Form Validation Class Initialized
INFO - 2024-01-24 11:16:46 --> Controller Class Initialized
INFO - 2024-01-24 11:16:46 --> Model Class Initialized
DEBUG - 2024-01-24 11:16:46 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-01-24 11:16:46 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-24 11:16:46 --> Model Class Initialized
INFO - 2024-01-24 11:16:46 --> Final output sent to browser
DEBUG - 2024-01-24 11:16:46 --> Total execution time: 0.0800
ERROR - 2024-01-24 11:17:10 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-01-24 11:17:10 --> Config Class Initialized
INFO - 2024-01-24 11:17:10 --> Hooks Class Initialized
DEBUG - 2024-01-24 11:17:10 --> UTF-8 Support Enabled
INFO - 2024-01-24 11:17:10 --> Utf8 Class Initialized
INFO - 2024-01-24 11:17:10 --> URI Class Initialized
INFO - 2024-01-24 11:17:10 --> Router Class Initialized
INFO - 2024-01-24 11:17:10 --> Output Class Initialized
INFO - 2024-01-24 11:17:10 --> Security Class Initialized
DEBUG - 2024-01-24 11:17:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-24 11:17:10 --> Input Class Initialized
INFO - 2024-01-24 11:17:10 --> Language Class Initialized
INFO - 2024-01-24 11:17:10 --> Loader Class Initialized
INFO - 2024-01-24 11:17:10 --> Helper loaded: url_helper
INFO - 2024-01-24 11:17:10 --> Helper loaded: file_helper
INFO - 2024-01-24 11:17:10 --> Helper loaded: html_helper
INFO - 2024-01-24 11:17:10 --> Helper loaded: text_helper
INFO - 2024-01-24 11:17:10 --> Helper loaded: form_helper
INFO - 2024-01-24 11:17:10 --> Helper loaded: lang_helper
INFO - 2024-01-24 11:17:10 --> Helper loaded: security_helper
INFO - 2024-01-24 11:17:10 --> Helper loaded: cookie_helper
INFO - 2024-01-24 11:17:10 --> Database Driver Class Initialized
INFO - 2024-01-24 11:17:10 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-24 11:17:10 --> Parser Class Initialized
INFO - 2024-01-24 11:17:10 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-01-24 11:17:10 --> Pagination Class Initialized
INFO - 2024-01-24 11:17:10 --> Form Validation Class Initialized
INFO - 2024-01-24 11:17:10 --> Controller Class Initialized
INFO - 2024-01-24 11:17:10 --> Model Class Initialized
DEBUG - 2024-01-24 11:17:10 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-01-24 11:17:10 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-24 11:17:10 --> Model Class Initialized
INFO - 2024-01-24 11:17:10 --> Final output sent to browser
DEBUG - 2024-01-24 11:17:10 --> Total execution time: 0.0898
ERROR - 2024-01-24 11:17:22 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-01-24 11:17:22 --> Config Class Initialized
INFO - 2024-01-24 11:17:22 --> Hooks Class Initialized
DEBUG - 2024-01-24 11:17:22 --> UTF-8 Support Enabled
INFO - 2024-01-24 11:17:22 --> Utf8 Class Initialized
INFO - 2024-01-24 11:17:22 --> URI Class Initialized
INFO - 2024-01-24 11:17:22 --> Router Class Initialized
INFO - 2024-01-24 11:17:22 --> Output Class Initialized
INFO - 2024-01-24 11:17:22 --> Security Class Initialized
DEBUG - 2024-01-24 11:17:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-24 11:17:22 --> Input Class Initialized
INFO - 2024-01-24 11:17:22 --> Language Class Initialized
INFO - 2024-01-24 11:17:22 --> Loader Class Initialized
INFO - 2024-01-24 11:17:22 --> Helper loaded: url_helper
INFO - 2024-01-24 11:17:22 --> Helper loaded: file_helper
INFO - 2024-01-24 11:17:22 --> Helper loaded: html_helper
INFO - 2024-01-24 11:17:22 --> Helper loaded: text_helper
INFO - 2024-01-24 11:17:22 --> Helper loaded: form_helper
INFO - 2024-01-24 11:17:22 --> Helper loaded: lang_helper
INFO - 2024-01-24 11:17:22 --> Helper loaded: security_helper
INFO - 2024-01-24 11:17:22 --> Helper loaded: cookie_helper
INFO - 2024-01-24 11:17:22 --> Database Driver Class Initialized
INFO - 2024-01-24 11:17:22 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-24 11:17:22 --> Parser Class Initialized
INFO - 2024-01-24 11:17:22 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-01-24 11:17:22 --> Pagination Class Initialized
INFO - 2024-01-24 11:17:22 --> Form Validation Class Initialized
INFO - 2024-01-24 11:17:22 --> Controller Class Initialized
DEBUG - 2024-01-24 11:17:22 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-01-24 11:17:22 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-24 11:17:22 --> Model Class Initialized
DEBUG - 2024-01-24 11:17:22 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-01-24 11:17:22 --> Session class already loaded. Second attempt ignored.
DEBUG - 2024-01-24 11:17:22 --> Ltarget class already loaded. Second attempt ignored.
INFO - 2024-01-24 11:17:22 --> Model Class Initialized
DEBUG - 2024-01-24 11:17:22 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-01-24 11:17:22 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-24 11:17:22 --> Model Class Initialized
DEBUG - 2024-01-24 11:17:22 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-24 11:17:22 --> Model Class Initialized
INFO - 2024-01-24 11:17:22 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/target/target.php
DEBUG - 2024-01-24 11:17:22 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-01-24 11:17:22 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-01-24 11:17:22 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-01-24 11:17:22 --> Model Class Initialized
INFO - 2024-01-24 11:17:22 --> Model Class Initialized
INFO - 2024-01-24 11:17:22 --> Model Class Initialized
INFO - 2024-01-24 11:17:22 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-01-24 11:17:22 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-01-24 11:17:22 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-01-24 11:17:22 --> Final output sent to browser
DEBUG - 2024-01-24 11:17:22 --> Total execution time: 0.1520
ERROR - 2024-01-24 11:17:23 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-01-24 11:17:23 --> Config Class Initialized
INFO - 2024-01-24 11:17:23 --> Hooks Class Initialized
DEBUG - 2024-01-24 11:17:23 --> UTF-8 Support Enabled
INFO - 2024-01-24 11:17:23 --> Utf8 Class Initialized
INFO - 2024-01-24 11:17:23 --> URI Class Initialized
INFO - 2024-01-24 11:17:23 --> Router Class Initialized
INFO - 2024-01-24 11:17:23 --> Output Class Initialized
INFO - 2024-01-24 11:17:23 --> Security Class Initialized
DEBUG - 2024-01-24 11:17:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-24 11:17:23 --> Input Class Initialized
INFO - 2024-01-24 11:17:23 --> Language Class Initialized
INFO - 2024-01-24 11:17:23 --> Loader Class Initialized
INFO - 2024-01-24 11:17:23 --> Helper loaded: url_helper
INFO - 2024-01-24 11:17:23 --> Helper loaded: file_helper
INFO - 2024-01-24 11:17:23 --> Helper loaded: html_helper
INFO - 2024-01-24 11:17:23 --> Helper loaded: text_helper
INFO - 2024-01-24 11:17:23 --> Helper loaded: form_helper
INFO - 2024-01-24 11:17:23 --> Helper loaded: lang_helper
INFO - 2024-01-24 11:17:23 --> Helper loaded: security_helper
INFO - 2024-01-24 11:17:23 --> Helper loaded: cookie_helper
INFO - 2024-01-24 11:17:23 --> Database Driver Class Initialized
INFO - 2024-01-24 11:17:23 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-24 11:17:23 --> Parser Class Initialized
INFO - 2024-01-24 11:17:23 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-01-24 11:17:23 --> Pagination Class Initialized
INFO - 2024-01-24 11:17:23 --> Form Validation Class Initialized
INFO - 2024-01-24 11:17:23 --> Controller Class Initialized
DEBUG - 2024-01-24 11:17:23 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-01-24 11:17:23 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-24 11:17:23 --> Model Class Initialized
DEBUG - 2024-01-24 11:17:23 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-01-24 11:17:23 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-24 11:17:23 --> Model Class Initialized
DEBUG - 2024-01-24 11:17:23 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-01-24 11:17:23 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-24 11:17:23 --> Model Class Initialized
DEBUG - 2024-01-24 11:17:23 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-24 11:17:23 --> Model Class Initialized
INFO - 2024-01-24 11:17:23 --> Final output sent to browser
DEBUG - 2024-01-24 11:17:23 --> Total execution time: 0.0205
ERROR - 2024-01-24 11:17:25 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-01-24 11:17:25 --> Config Class Initialized
INFO - 2024-01-24 11:17:25 --> Hooks Class Initialized
DEBUG - 2024-01-24 11:17:25 --> UTF-8 Support Enabled
INFO - 2024-01-24 11:17:25 --> Utf8 Class Initialized
INFO - 2024-01-24 11:17:25 --> URI Class Initialized
INFO - 2024-01-24 11:17:25 --> Router Class Initialized
INFO - 2024-01-24 11:17:25 --> Output Class Initialized
INFO - 2024-01-24 11:17:25 --> Security Class Initialized
DEBUG - 2024-01-24 11:17:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-24 11:17:25 --> Input Class Initialized
INFO - 2024-01-24 11:17:25 --> Language Class Initialized
INFO - 2024-01-24 11:17:25 --> Loader Class Initialized
INFO - 2024-01-24 11:17:25 --> Helper loaded: url_helper
INFO - 2024-01-24 11:17:25 --> Helper loaded: file_helper
INFO - 2024-01-24 11:17:25 --> Helper loaded: html_helper
INFO - 2024-01-24 11:17:25 --> Helper loaded: text_helper
INFO - 2024-01-24 11:17:25 --> Helper loaded: form_helper
INFO - 2024-01-24 11:17:25 --> Helper loaded: lang_helper
INFO - 2024-01-24 11:17:25 --> Helper loaded: security_helper
INFO - 2024-01-24 11:17:25 --> Helper loaded: cookie_helper
INFO - 2024-01-24 11:17:25 --> Database Driver Class Initialized
INFO - 2024-01-24 11:17:25 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-24 11:17:25 --> Parser Class Initialized
INFO - 2024-01-24 11:17:25 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-01-24 11:17:25 --> Pagination Class Initialized
INFO - 2024-01-24 11:17:25 --> Form Validation Class Initialized
INFO - 2024-01-24 11:17:25 --> Controller Class Initialized
DEBUG - 2024-01-24 11:17:25 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-01-24 11:17:25 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-24 11:17:25 --> Model Class Initialized
DEBUG - 2024-01-24 11:17:25 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-01-24 11:17:25 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-24 11:17:25 --> Model Class Initialized
DEBUG - 2024-01-24 11:17:25 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-01-24 11:17:25 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-24 11:17:25 --> Model Class Initialized
DEBUG - 2024-01-24 11:17:25 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-24 11:17:25 --> Model Class Initialized
INFO - 2024-01-24 11:17:25 --> Final output sent to browser
DEBUG - 2024-01-24 11:17:25 --> Total execution time: 0.0229
ERROR - 2024-01-24 11:17:35 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-01-24 11:17:35 --> Config Class Initialized
INFO - 2024-01-24 11:17:35 --> Hooks Class Initialized
DEBUG - 2024-01-24 11:17:35 --> UTF-8 Support Enabled
INFO - 2024-01-24 11:17:35 --> Utf8 Class Initialized
INFO - 2024-01-24 11:17:35 --> URI Class Initialized
INFO - 2024-01-24 11:17:35 --> Router Class Initialized
INFO - 2024-01-24 11:17:35 --> Output Class Initialized
INFO - 2024-01-24 11:17:35 --> Security Class Initialized
DEBUG - 2024-01-24 11:17:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-24 11:17:35 --> Input Class Initialized
INFO - 2024-01-24 11:17:35 --> Language Class Initialized
INFO - 2024-01-24 11:17:35 --> Loader Class Initialized
INFO - 2024-01-24 11:17:35 --> Helper loaded: url_helper
INFO - 2024-01-24 11:17:35 --> Helper loaded: file_helper
INFO - 2024-01-24 11:17:35 --> Helper loaded: html_helper
INFO - 2024-01-24 11:17:35 --> Helper loaded: text_helper
INFO - 2024-01-24 11:17:35 --> Helper loaded: form_helper
INFO - 2024-01-24 11:17:35 --> Helper loaded: lang_helper
INFO - 2024-01-24 11:17:35 --> Helper loaded: security_helper
INFO - 2024-01-24 11:17:35 --> Helper loaded: cookie_helper
INFO - 2024-01-24 11:17:35 --> Database Driver Class Initialized
INFO - 2024-01-24 11:17:35 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-24 11:17:35 --> Parser Class Initialized
INFO - 2024-01-24 11:17:35 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-01-24 11:17:35 --> Pagination Class Initialized
INFO - 2024-01-24 11:17:35 --> Form Validation Class Initialized
INFO - 2024-01-24 11:17:35 --> Controller Class Initialized
INFO - 2024-01-24 11:17:35 --> Model Class Initialized
DEBUG - 2024-01-24 11:17:35 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-01-24 11:17:35 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-24 11:17:35 --> Model Class Initialized
DEBUG - 2024-01-24 11:17:35 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-24 11:17:35 --> Model Class Initialized
INFO - 2024-01-24 11:17:35 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice.php
DEBUG - 2024-01-24 11:17:35 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-01-24 11:17:35 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-01-24 11:17:35 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-01-24 11:17:35 --> Model Class Initialized
INFO - 2024-01-24 11:17:35 --> Model Class Initialized
INFO - 2024-01-24 11:17:35 --> Model Class Initialized
INFO - 2024-01-24 11:17:35 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-01-24 11:17:35 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-01-24 11:17:35 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-01-24 11:17:35 --> Final output sent to browser
DEBUG - 2024-01-24 11:17:35 --> Total execution time: 0.1494
ERROR - 2024-01-24 11:17:36 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-01-24 11:17:36 --> Config Class Initialized
INFO - 2024-01-24 11:17:36 --> Hooks Class Initialized
DEBUG - 2024-01-24 11:17:36 --> UTF-8 Support Enabled
INFO - 2024-01-24 11:17:36 --> Utf8 Class Initialized
INFO - 2024-01-24 11:17:36 --> URI Class Initialized
INFO - 2024-01-24 11:17:36 --> Router Class Initialized
INFO - 2024-01-24 11:17:36 --> Output Class Initialized
INFO - 2024-01-24 11:17:36 --> Security Class Initialized
DEBUG - 2024-01-24 11:17:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-24 11:17:36 --> Input Class Initialized
INFO - 2024-01-24 11:17:36 --> Language Class Initialized
INFO - 2024-01-24 11:17:36 --> Loader Class Initialized
INFO - 2024-01-24 11:17:36 --> Helper loaded: url_helper
INFO - 2024-01-24 11:17:36 --> Helper loaded: file_helper
INFO - 2024-01-24 11:17:36 --> Helper loaded: html_helper
INFO - 2024-01-24 11:17:36 --> Helper loaded: text_helper
INFO - 2024-01-24 11:17:36 --> Helper loaded: form_helper
INFO - 2024-01-24 11:17:36 --> Helper loaded: lang_helper
INFO - 2024-01-24 11:17:36 --> Helper loaded: security_helper
INFO - 2024-01-24 11:17:36 --> Helper loaded: cookie_helper
INFO - 2024-01-24 11:17:36 --> Database Driver Class Initialized
INFO - 2024-01-24 11:17:36 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-24 11:17:36 --> Parser Class Initialized
INFO - 2024-01-24 11:17:36 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-01-24 11:17:36 --> Pagination Class Initialized
INFO - 2024-01-24 11:17:36 --> Form Validation Class Initialized
INFO - 2024-01-24 11:17:36 --> Controller Class Initialized
INFO - 2024-01-24 11:17:36 --> Model Class Initialized
DEBUG - 2024-01-24 11:17:36 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-01-24 11:17:36 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-24 11:17:36 --> Model Class Initialized
DEBUG - 2024-01-24 11:17:36 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-24 11:17:36 --> Model Class Initialized
INFO - 2024-01-24 11:17:36 --> Final output sent to browser
DEBUG - 2024-01-24 11:17:36 --> Total execution time: 0.0429
ERROR - 2024-01-24 11:17:44 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-01-24 11:17:44 --> Config Class Initialized
INFO - 2024-01-24 11:17:44 --> Hooks Class Initialized
DEBUG - 2024-01-24 11:17:44 --> UTF-8 Support Enabled
INFO - 2024-01-24 11:17:44 --> Utf8 Class Initialized
INFO - 2024-01-24 11:17:44 --> URI Class Initialized
INFO - 2024-01-24 11:17:44 --> Router Class Initialized
INFO - 2024-01-24 11:17:44 --> Output Class Initialized
INFO - 2024-01-24 11:17:44 --> Security Class Initialized
DEBUG - 2024-01-24 11:17:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-24 11:17:44 --> Input Class Initialized
INFO - 2024-01-24 11:17:44 --> Language Class Initialized
INFO - 2024-01-24 11:17:44 --> Loader Class Initialized
INFO - 2024-01-24 11:17:44 --> Helper loaded: url_helper
INFO - 2024-01-24 11:17:44 --> Helper loaded: file_helper
INFO - 2024-01-24 11:17:44 --> Helper loaded: html_helper
INFO - 2024-01-24 11:17:44 --> Helper loaded: text_helper
INFO - 2024-01-24 11:17:44 --> Helper loaded: form_helper
INFO - 2024-01-24 11:17:44 --> Helper loaded: lang_helper
INFO - 2024-01-24 11:17:44 --> Helper loaded: security_helper
INFO - 2024-01-24 11:17:44 --> Helper loaded: cookie_helper
INFO - 2024-01-24 11:17:44 --> Database Driver Class Initialized
INFO - 2024-01-24 11:17:44 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-24 11:17:44 --> Parser Class Initialized
INFO - 2024-01-24 11:17:44 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-01-24 11:17:44 --> Pagination Class Initialized
INFO - 2024-01-24 11:17:44 --> Form Validation Class Initialized
INFO - 2024-01-24 11:17:44 --> Controller Class Initialized
INFO - 2024-01-24 11:17:44 --> Model Class Initialized
DEBUG - 2024-01-24 11:17:44 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-01-24 11:17:44 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-24 11:17:44 --> Model Class Initialized
DEBUG - 2024-01-24 11:17:44 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-24 11:17:44 --> Model Class Initialized
INFO - 2024-01-24 11:17:44 --> Final output sent to browser
DEBUG - 2024-01-24 11:17:44 --> Total execution time: 0.0462
ERROR - 2024-01-24 11:17:54 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-01-24 11:17:54 --> Config Class Initialized
INFO - 2024-01-24 11:17:54 --> Hooks Class Initialized
DEBUG - 2024-01-24 11:17:54 --> UTF-8 Support Enabled
INFO - 2024-01-24 11:17:54 --> Utf8 Class Initialized
INFO - 2024-01-24 11:17:54 --> URI Class Initialized
INFO - 2024-01-24 11:17:54 --> Router Class Initialized
INFO - 2024-01-24 11:17:54 --> Output Class Initialized
INFO - 2024-01-24 11:17:54 --> Security Class Initialized
DEBUG - 2024-01-24 11:17:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-24 11:17:54 --> Input Class Initialized
INFO - 2024-01-24 11:17:54 --> Language Class Initialized
INFO - 2024-01-24 11:17:54 --> Loader Class Initialized
INFO - 2024-01-24 11:17:54 --> Helper loaded: url_helper
INFO - 2024-01-24 11:17:54 --> Helper loaded: file_helper
INFO - 2024-01-24 11:17:54 --> Helper loaded: html_helper
INFO - 2024-01-24 11:17:54 --> Helper loaded: text_helper
INFO - 2024-01-24 11:17:54 --> Helper loaded: form_helper
INFO - 2024-01-24 11:17:54 --> Helper loaded: lang_helper
INFO - 2024-01-24 11:17:54 --> Helper loaded: security_helper
INFO - 2024-01-24 11:17:54 --> Helper loaded: cookie_helper
INFO - 2024-01-24 11:17:54 --> Database Driver Class Initialized
INFO - 2024-01-24 11:17:54 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-24 11:17:54 --> Parser Class Initialized
INFO - 2024-01-24 11:17:54 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-01-24 11:17:54 --> Pagination Class Initialized
INFO - 2024-01-24 11:17:54 --> Form Validation Class Initialized
INFO - 2024-01-24 11:17:54 --> Controller Class Initialized
INFO - 2024-01-24 11:17:54 --> Model Class Initialized
DEBUG - 2024-01-24 11:17:54 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-01-24 11:17:54 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-24 11:17:54 --> Model Class Initialized
DEBUG - 2024-01-24 11:17:54 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-24 11:17:54 --> Model Class Initialized
INFO - 2024-01-24 11:17:54 --> Final output sent to browser
DEBUG - 2024-01-24 11:17:54 --> Total execution time: 0.0397
ERROR - 2024-01-24 11:18:25 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-01-24 11:18:25 --> Config Class Initialized
INFO - 2024-01-24 11:18:25 --> Hooks Class Initialized
DEBUG - 2024-01-24 11:18:25 --> UTF-8 Support Enabled
INFO - 2024-01-24 11:18:25 --> Utf8 Class Initialized
INFO - 2024-01-24 11:18:25 --> URI Class Initialized
INFO - 2024-01-24 11:18:25 --> Router Class Initialized
INFO - 2024-01-24 11:18:25 --> Output Class Initialized
INFO - 2024-01-24 11:18:25 --> Security Class Initialized
DEBUG - 2024-01-24 11:18:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-24 11:18:25 --> Input Class Initialized
INFO - 2024-01-24 11:18:25 --> Language Class Initialized
INFO - 2024-01-24 11:18:25 --> Loader Class Initialized
INFO - 2024-01-24 11:18:25 --> Helper loaded: url_helper
INFO - 2024-01-24 11:18:25 --> Helper loaded: file_helper
INFO - 2024-01-24 11:18:25 --> Helper loaded: html_helper
INFO - 2024-01-24 11:18:25 --> Helper loaded: text_helper
INFO - 2024-01-24 11:18:25 --> Helper loaded: form_helper
INFO - 2024-01-24 11:18:25 --> Helper loaded: lang_helper
INFO - 2024-01-24 11:18:25 --> Helper loaded: security_helper
INFO - 2024-01-24 11:18:25 --> Helper loaded: cookie_helper
INFO - 2024-01-24 11:18:25 --> Database Driver Class Initialized
INFO - 2024-01-24 11:18:25 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-24 11:18:25 --> Parser Class Initialized
INFO - 2024-01-24 11:18:25 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-01-24 11:18:25 --> Pagination Class Initialized
INFO - 2024-01-24 11:18:25 --> Form Validation Class Initialized
INFO - 2024-01-24 11:18:25 --> Controller Class Initialized
INFO - 2024-01-24 11:18:25 --> Model Class Initialized
DEBUG - 2024-01-24 11:18:25 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-01-24 11:18:25 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-24 11:18:25 --> Model Class Initialized
DEBUG - 2024-01-24 11:18:25 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-24 11:18:25 --> Model Class Initialized
INFO - 2024-01-24 11:18:25 --> Final output sent to browser
DEBUG - 2024-01-24 11:18:25 --> Total execution time: 0.0465
ERROR - 2024-01-24 15:00:02 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-01-24 15:00:02 --> Config Class Initialized
INFO - 2024-01-24 15:00:02 --> Hooks Class Initialized
DEBUG - 2024-01-24 15:00:02 --> UTF-8 Support Enabled
INFO - 2024-01-24 15:00:02 --> Utf8 Class Initialized
INFO - 2024-01-24 15:00:02 --> URI Class Initialized
DEBUG - 2024-01-24 15:00:02 --> No URI present. Default controller set.
INFO - 2024-01-24 15:00:02 --> Router Class Initialized
INFO - 2024-01-24 15:00:02 --> Output Class Initialized
INFO - 2024-01-24 15:00:02 --> Security Class Initialized
DEBUG - 2024-01-24 15:00:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-24 15:00:02 --> Input Class Initialized
INFO - 2024-01-24 15:00:02 --> Language Class Initialized
INFO - 2024-01-24 15:00:02 --> Loader Class Initialized
INFO - 2024-01-24 15:00:02 --> Helper loaded: url_helper
INFO - 2024-01-24 15:00:02 --> Helper loaded: file_helper
INFO - 2024-01-24 15:00:02 --> Helper loaded: html_helper
INFO - 2024-01-24 15:00:02 --> Helper loaded: text_helper
INFO - 2024-01-24 15:00:02 --> Helper loaded: form_helper
INFO - 2024-01-24 15:00:02 --> Helper loaded: lang_helper
INFO - 2024-01-24 15:00:02 --> Helper loaded: security_helper
INFO - 2024-01-24 15:00:02 --> Helper loaded: cookie_helper
INFO - 2024-01-24 15:00:02 --> Database Driver Class Initialized
INFO - 2024-01-24 15:00:02 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-24 15:00:02 --> Parser Class Initialized
INFO - 2024-01-24 15:00:02 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-01-24 15:00:02 --> Pagination Class Initialized
INFO - 2024-01-24 15:00:02 --> Form Validation Class Initialized
INFO - 2024-01-24 15:00:02 --> Controller Class Initialized
INFO - 2024-01-24 15:00:02 --> Model Class Initialized
DEBUG - 2024-01-24 15:00:02 --> Session class already loaded. Second attempt ignored.
ERROR - 2024-01-24 15:00:03 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-01-24 15:00:03 --> Config Class Initialized
INFO - 2024-01-24 15:00:03 --> Hooks Class Initialized
DEBUG - 2024-01-24 15:00:03 --> UTF-8 Support Enabled
INFO - 2024-01-24 15:00:03 --> Utf8 Class Initialized
INFO - 2024-01-24 15:00:03 --> URI Class Initialized
DEBUG - 2024-01-24 15:00:03 --> No URI present. Default controller set.
INFO - 2024-01-24 15:00:03 --> Router Class Initialized
INFO - 2024-01-24 15:00:03 --> Output Class Initialized
INFO - 2024-01-24 15:00:03 --> Security Class Initialized
DEBUG - 2024-01-24 15:00:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-24 15:00:03 --> Input Class Initialized
INFO - 2024-01-24 15:00:03 --> Language Class Initialized
INFO - 2024-01-24 15:00:03 --> Loader Class Initialized
INFO - 2024-01-24 15:00:03 --> Helper loaded: url_helper
INFO - 2024-01-24 15:00:03 --> Helper loaded: file_helper
INFO - 2024-01-24 15:00:03 --> Helper loaded: html_helper
INFO - 2024-01-24 15:00:03 --> Helper loaded: text_helper
INFO - 2024-01-24 15:00:03 --> Helper loaded: form_helper
INFO - 2024-01-24 15:00:03 --> Helper loaded: lang_helper
INFO - 2024-01-24 15:00:03 --> Helper loaded: security_helper
INFO - 2024-01-24 15:00:03 --> Helper loaded: cookie_helper
INFO - 2024-01-24 15:00:03 --> Database Driver Class Initialized
INFO - 2024-01-24 15:00:03 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-24 15:00:03 --> Parser Class Initialized
INFO - 2024-01-24 15:00:03 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-01-24 15:00:03 --> Pagination Class Initialized
INFO - 2024-01-24 15:00:03 --> Form Validation Class Initialized
INFO - 2024-01-24 15:00:03 --> Controller Class Initialized
INFO - 2024-01-24 15:00:03 --> Model Class Initialized
DEBUG - 2024-01-24 15:00:03 --> Session class already loaded. Second attempt ignored.
ERROR - 2024-01-24 15:00:04 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-01-24 15:00:04 --> Config Class Initialized
INFO - 2024-01-24 15:00:04 --> Hooks Class Initialized
DEBUG - 2024-01-24 15:00:04 --> UTF-8 Support Enabled
INFO - 2024-01-24 15:00:04 --> Utf8 Class Initialized
INFO - 2024-01-24 15:00:04 --> URI Class Initialized
DEBUG - 2024-01-24 15:00:04 --> No URI present. Default controller set.
INFO - 2024-01-24 15:00:04 --> Router Class Initialized
INFO - 2024-01-24 15:00:04 --> Output Class Initialized
INFO - 2024-01-24 15:00:04 --> Security Class Initialized
DEBUG - 2024-01-24 15:00:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-24 15:00:04 --> Input Class Initialized
INFO - 2024-01-24 15:00:04 --> Language Class Initialized
INFO - 2024-01-24 15:00:04 --> Loader Class Initialized
INFO - 2024-01-24 15:00:04 --> Helper loaded: url_helper
INFO - 2024-01-24 15:00:04 --> Helper loaded: file_helper
INFO - 2024-01-24 15:00:04 --> Helper loaded: html_helper
INFO - 2024-01-24 15:00:04 --> Helper loaded: text_helper
INFO - 2024-01-24 15:00:04 --> Helper loaded: form_helper
INFO - 2024-01-24 15:00:04 --> Helper loaded: lang_helper
INFO - 2024-01-24 15:00:04 --> Helper loaded: security_helper
INFO - 2024-01-24 15:00:04 --> Helper loaded: cookie_helper
INFO - 2024-01-24 15:00:04 --> Database Driver Class Initialized
INFO - 2024-01-24 15:00:04 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-24 15:00:04 --> Parser Class Initialized
INFO - 2024-01-24 15:00:04 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-01-24 15:00:04 --> Pagination Class Initialized
INFO - 2024-01-24 15:00:04 --> Form Validation Class Initialized
INFO - 2024-01-24 15:00:04 --> Controller Class Initialized
INFO - 2024-01-24 15:00:04 --> Model Class Initialized
DEBUG - 2024-01-24 15:00:04 --> Session class already loaded. Second attempt ignored.
ERROR - 2024-01-24 15:00:04 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-01-24 15:00:04 --> Config Class Initialized
INFO - 2024-01-24 15:00:04 --> Hooks Class Initialized
DEBUG - 2024-01-24 15:00:04 --> UTF-8 Support Enabled
INFO - 2024-01-24 15:00:04 --> Utf8 Class Initialized
INFO - 2024-01-24 15:00:04 --> URI Class Initialized
DEBUG - 2024-01-24 15:00:04 --> No URI present. Default controller set.
INFO - 2024-01-24 15:00:04 --> Router Class Initialized
INFO - 2024-01-24 15:00:04 --> Output Class Initialized
INFO - 2024-01-24 15:00:04 --> Security Class Initialized
DEBUG - 2024-01-24 15:00:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-24 15:00:04 --> Input Class Initialized
INFO - 2024-01-24 15:00:04 --> Language Class Initialized
INFO - 2024-01-24 15:00:04 --> Loader Class Initialized
INFO - 2024-01-24 15:00:04 --> Helper loaded: url_helper
INFO - 2024-01-24 15:00:04 --> Helper loaded: file_helper
INFO - 2024-01-24 15:00:04 --> Helper loaded: html_helper
INFO - 2024-01-24 15:00:04 --> Helper loaded: text_helper
INFO - 2024-01-24 15:00:04 --> Helper loaded: form_helper
INFO - 2024-01-24 15:00:04 --> Helper loaded: lang_helper
INFO - 2024-01-24 15:00:04 --> Helper loaded: security_helper
INFO - 2024-01-24 15:00:04 --> Helper loaded: cookie_helper
INFO - 2024-01-24 15:00:05 --> Database Driver Class Initialized
INFO - 2024-01-24 15:00:05 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-24 15:00:05 --> Parser Class Initialized
INFO - 2024-01-24 15:00:05 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-01-24 15:00:05 --> Pagination Class Initialized
INFO - 2024-01-24 15:00:05 --> Form Validation Class Initialized
INFO - 2024-01-24 15:00:05 --> Controller Class Initialized
INFO - 2024-01-24 15:00:05 --> Model Class Initialized
DEBUG - 2024-01-24 15:00:05 --> Session class already loaded. Second attempt ignored.
ERROR - 2024-01-24 18:23:07 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-01-24 18:23:07 --> Config Class Initialized
INFO - 2024-01-24 18:23:07 --> Hooks Class Initialized
DEBUG - 2024-01-24 18:23:07 --> UTF-8 Support Enabled
INFO - 2024-01-24 18:23:07 --> Utf8 Class Initialized
INFO - 2024-01-24 18:23:07 --> URI Class Initialized
DEBUG - 2024-01-24 18:23:07 --> No URI present. Default controller set.
INFO - 2024-01-24 18:23:07 --> Router Class Initialized
INFO - 2024-01-24 18:23:07 --> Output Class Initialized
INFO - 2024-01-24 18:23:07 --> Security Class Initialized
DEBUG - 2024-01-24 18:23:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-24 18:23:07 --> Input Class Initialized
INFO - 2024-01-24 18:23:07 --> Language Class Initialized
INFO - 2024-01-24 18:23:07 --> Loader Class Initialized
INFO - 2024-01-24 18:23:07 --> Helper loaded: url_helper
INFO - 2024-01-24 18:23:07 --> Helper loaded: file_helper
INFO - 2024-01-24 18:23:07 --> Helper loaded: html_helper
INFO - 2024-01-24 18:23:07 --> Helper loaded: text_helper
INFO - 2024-01-24 18:23:07 --> Helper loaded: form_helper
INFO - 2024-01-24 18:23:07 --> Helper loaded: lang_helper
INFO - 2024-01-24 18:23:07 --> Helper loaded: security_helper
INFO - 2024-01-24 18:23:07 --> Helper loaded: cookie_helper
INFO - 2024-01-24 18:23:07 --> Database Driver Class Initialized
INFO - 2024-01-24 18:23:07 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-24 18:23:07 --> Parser Class Initialized
INFO - 2024-01-24 18:23:07 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-01-24 18:23:07 --> Pagination Class Initialized
INFO - 2024-01-24 18:23:07 --> Form Validation Class Initialized
INFO - 2024-01-24 18:23:07 --> Controller Class Initialized
INFO - 2024-01-24 18:23:07 --> Model Class Initialized
DEBUG - 2024-01-24 18:23:07 --> Session class already loaded. Second attempt ignored.
ERROR - 2024-01-24 18:23:07 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-01-24 18:23:07 --> Config Class Initialized
INFO - 2024-01-24 18:23:07 --> Hooks Class Initialized
DEBUG - 2024-01-24 18:23:07 --> UTF-8 Support Enabled
INFO - 2024-01-24 18:23:07 --> Utf8 Class Initialized
INFO - 2024-01-24 18:23:07 --> URI Class Initialized
INFO - 2024-01-24 18:23:07 --> Router Class Initialized
INFO - 2024-01-24 18:23:07 --> Output Class Initialized
INFO - 2024-01-24 18:23:07 --> Security Class Initialized
DEBUG - 2024-01-24 18:23:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-24 18:23:07 --> Input Class Initialized
INFO - 2024-01-24 18:23:07 --> Language Class Initialized
INFO - 2024-01-24 18:23:07 --> Loader Class Initialized
INFO - 2024-01-24 18:23:07 --> Helper loaded: url_helper
INFO - 2024-01-24 18:23:07 --> Helper loaded: file_helper
INFO - 2024-01-24 18:23:07 --> Helper loaded: html_helper
INFO - 2024-01-24 18:23:07 --> Helper loaded: text_helper
INFO - 2024-01-24 18:23:07 --> Helper loaded: form_helper
INFO - 2024-01-24 18:23:07 --> Helper loaded: lang_helper
INFO - 2024-01-24 18:23:07 --> Helper loaded: security_helper
INFO - 2024-01-24 18:23:07 --> Helper loaded: cookie_helper
INFO - 2024-01-24 18:23:07 --> Database Driver Class Initialized
INFO - 2024-01-24 18:23:07 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-24 18:23:07 --> Parser Class Initialized
INFO - 2024-01-24 18:23:07 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-01-24 18:23:07 --> Pagination Class Initialized
INFO - 2024-01-24 18:23:07 --> Form Validation Class Initialized
INFO - 2024-01-24 18:23:07 --> Controller Class Initialized
INFO - 2024-01-24 18:23:07 --> Model Class Initialized
DEBUG - 2024-01-24 18:23:07 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-24 18:23:08 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2024-01-24 18:23:08 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-01-24 18:23:08 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-01-24 18:23:08 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-01-24 18:23:08 --> Model Class Initialized
INFO - 2024-01-24 18:23:08 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-01-24 18:23:08 --> Final output sent to browser
DEBUG - 2024-01-24 18:23:08 --> Total execution time: 0.0391
ERROR - 2024-01-24 18:23:21 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-01-24 18:23:21 --> Config Class Initialized
INFO - 2024-01-24 18:23:21 --> Hooks Class Initialized
DEBUG - 2024-01-24 18:23:21 --> UTF-8 Support Enabled
INFO - 2024-01-24 18:23:21 --> Utf8 Class Initialized
INFO - 2024-01-24 18:23:21 --> URI Class Initialized
INFO - 2024-01-24 18:23:21 --> Router Class Initialized
INFO - 2024-01-24 18:23:21 --> Output Class Initialized
INFO - 2024-01-24 18:23:21 --> Security Class Initialized
DEBUG - 2024-01-24 18:23:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-24 18:23:21 --> Input Class Initialized
INFO - 2024-01-24 18:23:21 --> Language Class Initialized
INFO - 2024-01-24 18:23:21 --> Loader Class Initialized
INFO - 2024-01-24 18:23:21 --> Helper loaded: url_helper
INFO - 2024-01-24 18:23:21 --> Helper loaded: file_helper
INFO - 2024-01-24 18:23:21 --> Helper loaded: html_helper
INFO - 2024-01-24 18:23:21 --> Helper loaded: text_helper
INFO - 2024-01-24 18:23:21 --> Helper loaded: form_helper
INFO - 2024-01-24 18:23:21 --> Helper loaded: lang_helper
INFO - 2024-01-24 18:23:21 --> Helper loaded: security_helper
INFO - 2024-01-24 18:23:21 --> Helper loaded: cookie_helper
INFO - 2024-01-24 18:23:21 --> Database Driver Class Initialized
INFO - 2024-01-24 18:23:21 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-24 18:23:21 --> Parser Class Initialized
INFO - 2024-01-24 18:23:21 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-01-24 18:23:21 --> Pagination Class Initialized
INFO - 2024-01-24 18:23:21 --> Form Validation Class Initialized
INFO - 2024-01-24 18:23:21 --> Controller Class Initialized
INFO - 2024-01-24 18:23:21 --> Model Class Initialized
DEBUG - 2024-01-24 18:23:21 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-24 18:23:21 --> Model Class Initialized
INFO - 2024-01-24 18:23:21 --> Final output sent to browser
DEBUG - 2024-01-24 18:23:21 --> Total execution time: 0.0234
ERROR - 2024-01-24 18:23:21 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-01-24 18:23:21 --> Config Class Initialized
INFO - 2024-01-24 18:23:21 --> Hooks Class Initialized
DEBUG - 2024-01-24 18:23:21 --> UTF-8 Support Enabled
INFO - 2024-01-24 18:23:21 --> Utf8 Class Initialized
INFO - 2024-01-24 18:23:21 --> URI Class Initialized
DEBUG - 2024-01-24 18:23:21 --> No URI present. Default controller set.
INFO - 2024-01-24 18:23:21 --> Router Class Initialized
INFO - 2024-01-24 18:23:21 --> Output Class Initialized
INFO - 2024-01-24 18:23:21 --> Security Class Initialized
DEBUG - 2024-01-24 18:23:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-24 18:23:21 --> Input Class Initialized
INFO - 2024-01-24 18:23:21 --> Language Class Initialized
INFO - 2024-01-24 18:23:21 --> Loader Class Initialized
INFO - 2024-01-24 18:23:21 --> Helper loaded: url_helper
INFO - 2024-01-24 18:23:21 --> Helper loaded: file_helper
INFO - 2024-01-24 18:23:21 --> Helper loaded: html_helper
INFO - 2024-01-24 18:23:21 --> Helper loaded: text_helper
INFO - 2024-01-24 18:23:21 --> Helper loaded: form_helper
INFO - 2024-01-24 18:23:21 --> Helper loaded: lang_helper
INFO - 2024-01-24 18:23:21 --> Helper loaded: security_helper
INFO - 2024-01-24 18:23:21 --> Helper loaded: cookie_helper
INFO - 2024-01-24 18:23:21 --> Database Driver Class Initialized
INFO - 2024-01-24 18:23:21 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-24 18:23:21 --> Parser Class Initialized
INFO - 2024-01-24 18:23:21 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-01-24 18:23:21 --> Pagination Class Initialized
INFO - 2024-01-24 18:23:21 --> Form Validation Class Initialized
INFO - 2024-01-24 18:23:21 --> Controller Class Initialized
INFO - 2024-01-24 18:23:21 --> Model Class Initialized
DEBUG - 2024-01-24 18:23:21 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-24 18:23:21 --> Model Class Initialized
DEBUG - 2024-01-24 18:23:21 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-24 18:23:21 --> Model Class Initialized
INFO - 2024-01-24 18:23:21 --> Model Class Initialized
INFO - 2024-01-24 18:23:21 --> Model Class Initialized
INFO - 2024-01-24 18:23:21 --> Model Class Initialized
DEBUG - 2024-01-24 18:23:21 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-01-24 18:23:21 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-24 18:23:21 --> Model Class Initialized
INFO - 2024-01-24 18:23:21 --> Model Class Initialized
INFO - 2024-01-24 18:23:22 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2024-01-24 18:23:22 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-01-24 18:23:22 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-01-24 18:23:22 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-01-24 18:23:22 --> Model Class Initialized
INFO - 2024-01-24 18:23:22 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-01-24 18:23:22 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-01-24 18:23:22 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-01-24 18:23:22 --> Final output sent to browser
DEBUG - 2024-01-24 18:23:22 --> Total execution time: 0.4302
ERROR - 2024-01-24 18:23:25 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-01-24 18:23:25 --> Config Class Initialized
INFO - 2024-01-24 18:23:25 --> Hooks Class Initialized
DEBUG - 2024-01-24 18:23:25 --> UTF-8 Support Enabled
INFO - 2024-01-24 18:23:25 --> Utf8 Class Initialized
INFO - 2024-01-24 18:23:25 --> URI Class Initialized
INFO - 2024-01-24 18:23:25 --> Router Class Initialized
INFO - 2024-01-24 18:23:25 --> Output Class Initialized
INFO - 2024-01-24 18:23:25 --> Security Class Initialized
DEBUG - 2024-01-24 18:23:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-24 18:23:25 --> Input Class Initialized
INFO - 2024-01-24 18:23:25 --> Language Class Initialized
INFO - 2024-01-24 18:23:25 --> Loader Class Initialized
INFO - 2024-01-24 18:23:25 --> Helper loaded: url_helper
INFO - 2024-01-24 18:23:25 --> Helper loaded: file_helper
INFO - 2024-01-24 18:23:25 --> Helper loaded: html_helper
INFO - 2024-01-24 18:23:25 --> Helper loaded: text_helper
INFO - 2024-01-24 18:23:25 --> Helper loaded: form_helper
INFO - 2024-01-24 18:23:25 --> Helper loaded: lang_helper
INFO - 2024-01-24 18:23:25 --> Helper loaded: security_helper
INFO - 2024-01-24 18:23:25 --> Helper loaded: cookie_helper
INFO - 2024-01-24 18:23:25 --> Database Driver Class Initialized
INFO - 2024-01-24 18:23:25 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-24 18:23:25 --> Parser Class Initialized
INFO - 2024-01-24 18:23:25 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-01-24 18:23:25 --> Pagination Class Initialized
INFO - 2024-01-24 18:23:25 --> Form Validation Class Initialized
INFO - 2024-01-24 18:23:25 --> Controller Class Initialized
DEBUG - 2024-01-24 18:23:25 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-01-24 18:23:25 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-24 18:23:25 --> Model Class Initialized
INFO - 2024-01-24 18:23:25 --> Final output sent to browser
DEBUG - 2024-01-24 18:23:25 --> Total execution time: 0.0134
ERROR - 2024-01-24 18:23:49 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-01-24 18:23:49 --> Config Class Initialized
INFO - 2024-01-24 18:23:49 --> Hooks Class Initialized
DEBUG - 2024-01-24 18:23:49 --> UTF-8 Support Enabled
INFO - 2024-01-24 18:23:49 --> Utf8 Class Initialized
INFO - 2024-01-24 18:23:49 --> URI Class Initialized
INFO - 2024-01-24 18:23:49 --> Router Class Initialized
INFO - 2024-01-24 18:23:49 --> Output Class Initialized
INFO - 2024-01-24 18:23:49 --> Security Class Initialized
DEBUG - 2024-01-24 18:23:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-24 18:23:49 --> Input Class Initialized
INFO - 2024-01-24 18:23:49 --> Language Class Initialized
INFO - 2024-01-24 18:23:49 --> Loader Class Initialized
INFO - 2024-01-24 18:23:49 --> Helper loaded: url_helper
INFO - 2024-01-24 18:23:49 --> Helper loaded: file_helper
INFO - 2024-01-24 18:23:49 --> Helper loaded: html_helper
INFO - 2024-01-24 18:23:49 --> Helper loaded: text_helper
INFO - 2024-01-24 18:23:49 --> Helper loaded: form_helper
INFO - 2024-01-24 18:23:49 --> Helper loaded: lang_helper
INFO - 2024-01-24 18:23:49 --> Helper loaded: security_helper
INFO - 2024-01-24 18:23:49 --> Helper loaded: cookie_helper
INFO - 2024-01-24 18:23:49 --> Database Driver Class Initialized
INFO - 2024-01-24 18:23:49 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-24 18:23:49 --> Parser Class Initialized
INFO - 2024-01-24 18:23:49 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-01-24 18:23:49 --> Pagination Class Initialized
INFO - 2024-01-24 18:23:49 --> Form Validation Class Initialized
INFO - 2024-01-24 18:23:49 --> Controller Class Initialized
INFO - 2024-01-24 18:23:49 --> Model Class Initialized
DEBUG - 2024-01-24 18:23:49 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-24 18:23:49 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2024-01-24 18:23:49 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-01-24 18:23:49 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-01-24 18:23:49 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-01-24 18:23:49 --> Model Class Initialized
INFO - 2024-01-24 18:23:49 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-01-24 18:23:49 --> Final output sent to browser
DEBUG - 2024-01-24 18:23:49 --> Total execution time: 0.0287
ERROR - 2024-01-24 18:23:50 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-01-24 18:23:50 --> Config Class Initialized
INFO - 2024-01-24 18:23:50 --> Hooks Class Initialized
DEBUG - 2024-01-24 18:23:50 --> UTF-8 Support Enabled
INFO - 2024-01-24 18:23:50 --> Utf8 Class Initialized
INFO - 2024-01-24 18:23:50 --> URI Class Initialized
INFO - 2024-01-24 18:23:50 --> Router Class Initialized
INFO - 2024-01-24 18:23:50 --> Output Class Initialized
INFO - 2024-01-24 18:23:50 --> Security Class Initialized
DEBUG - 2024-01-24 18:23:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-24 18:23:50 --> Input Class Initialized
INFO - 2024-01-24 18:23:50 --> Language Class Initialized
INFO - 2024-01-24 18:23:50 --> Loader Class Initialized
INFO - 2024-01-24 18:23:50 --> Helper loaded: url_helper
INFO - 2024-01-24 18:23:50 --> Helper loaded: file_helper
INFO - 2024-01-24 18:23:50 --> Helper loaded: html_helper
INFO - 2024-01-24 18:23:50 --> Helper loaded: text_helper
INFO - 2024-01-24 18:23:50 --> Helper loaded: form_helper
INFO - 2024-01-24 18:23:50 --> Helper loaded: lang_helper
INFO - 2024-01-24 18:23:50 --> Helper loaded: security_helper
INFO - 2024-01-24 18:23:50 --> Helper loaded: cookie_helper
INFO - 2024-01-24 18:23:50 --> Database Driver Class Initialized
INFO - 2024-01-24 18:23:50 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-24 18:23:50 --> Parser Class Initialized
INFO - 2024-01-24 18:23:50 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-01-24 18:23:50 --> Pagination Class Initialized
INFO - 2024-01-24 18:23:50 --> Form Validation Class Initialized
INFO - 2024-01-24 18:23:50 --> Controller Class Initialized
INFO - 2024-01-24 18:23:50 --> Model Class Initialized
DEBUG - 2024-01-24 18:23:50 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-24 18:23:50 --> Model Class Initialized
DEBUG - 2024-01-24 18:23:50 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-24 18:23:50 --> Model Class Initialized
INFO - 2024-01-24 18:23:50 --> Model Class Initialized
INFO - 2024-01-24 18:23:50 --> Model Class Initialized
INFO - 2024-01-24 18:23:50 --> Model Class Initialized
DEBUG - 2024-01-24 18:23:50 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-01-24 18:23:50 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-24 18:23:50 --> Model Class Initialized
INFO - 2024-01-24 18:23:50 --> Model Class Initialized
INFO - 2024-01-24 18:23:50 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2024-01-24 18:23:50 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-01-24 18:23:50 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-01-24 18:23:50 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-01-24 18:23:50 --> Model Class Initialized
INFO - 2024-01-24 18:23:50 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-01-24 18:23:50 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-01-24 18:23:50 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-01-24 18:23:50 --> Final output sent to browser
DEBUG - 2024-01-24 18:23:50 --> Total execution time: 0.3828
ERROR - 2024-01-24 19:00:40 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-01-24 19:00:40 --> Config Class Initialized
INFO - 2024-01-24 19:00:40 --> Hooks Class Initialized
DEBUG - 2024-01-24 19:00:40 --> UTF-8 Support Enabled
INFO - 2024-01-24 19:00:40 --> Utf8 Class Initialized
INFO - 2024-01-24 19:00:40 --> URI Class Initialized
INFO - 2024-01-24 19:00:40 --> Router Class Initialized
INFO - 2024-01-24 19:00:40 --> Output Class Initialized
INFO - 2024-01-24 19:00:40 --> Security Class Initialized
DEBUG - 2024-01-24 19:00:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-24 19:00:40 --> Input Class Initialized
INFO - 2024-01-24 19:00:40 --> Language Class Initialized
ERROR - 2024-01-24 19:00:40 --> 404 Page Not Found: Well-known/assetlinks.json
