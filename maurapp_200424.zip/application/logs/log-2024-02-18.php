<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2024-02-18 01:41:29 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-18 01:41:29 --> Config Class Initialized
INFO - 2024-02-18 01:41:29 --> Hooks Class Initialized
DEBUG - 2024-02-18 01:41:29 --> UTF-8 Support Enabled
INFO - 2024-02-18 01:41:29 --> Utf8 Class Initialized
INFO - 2024-02-18 01:41:29 --> URI Class Initialized
INFO - 2024-02-18 01:41:29 --> Router Class Initialized
INFO - 2024-02-18 01:41:29 --> Output Class Initialized
INFO - 2024-02-18 01:41:29 --> Security Class Initialized
DEBUG - 2024-02-18 01:41:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-18 01:41:29 --> Input Class Initialized
INFO - 2024-02-18 01:41:29 --> Language Class Initialized
ERROR - 2024-02-18 01:41:29 --> 404 Page Not Found: Well-known/assetlinks.json
ERROR - 2024-02-18 02:26:21 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-18 02:26:21 --> Config Class Initialized
INFO - 2024-02-18 02:26:21 --> Hooks Class Initialized
DEBUG - 2024-02-18 02:26:21 --> UTF-8 Support Enabled
INFO - 2024-02-18 02:26:21 --> Utf8 Class Initialized
INFO - 2024-02-18 02:26:21 --> URI Class Initialized
DEBUG - 2024-02-18 02:26:21 --> No URI present. Default controller set.
INFO - 2024-02-18 02:26:21 --> Router Class Initialized
INFO - 2024-02-18 02:26:21 --> Output Class Initialized
INFO - 2024-02-18 02:26:21 --> Security Class Initialized
DEBUG - 2024-02-18 02:26:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-18 02:26:21 --> Input Class Initialized
INFO - 2024-02-18 02:26:21 --> Language Class Initialized
INFO - 2024-02-18 02:26:21 --> Loader Class Initialized
INFO - 2024-02-18 02:26:21 --> Helper loaded: url_helper
INFO - 2024-02-18 02:26:21 --> Helper loaded: file_helper
INFO - 2024-02-18 02:26:21 --> Helper loaded: html_helper
INFO - 2024-02-18 02:26:21 --> Helper loaded: text_helper
INFO - 2024-02-18 02:26:21 --> Helper loaded: form_helper
INFO - 2024-02-18 02:26:21 --> Helper loaded: lang_helper
INFO - 2024-02-18 02:26:21 --> Helper loaded: security_helper
INFO - 2024-02-18 02:26:21 --> Helper loaded: cookie_helper
INFO - 2024-02-18 02:26:21 --> Database Driver Class Initialized
INFO - 2024-02-18 02:26:21 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-18 02:26:21 --> Parser Class Initialized
INFO - 2024-02-18 02:26:21 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-18 02:26:21 --> Pagination Class Initialized
INFO - 2024-02-18 02:26:21 --> Form Validation Class Initialized
INFO - 2024-02-18 02:26:21 --> Controller Class Initialized
INFO - 2024-02-18 02:26:21 --> Model Class Initialized
DEBUG - 2024-02-18 02:26:21 --> Session class already loaded. Second attempt ignored.
ERROR - 2024-02-18 02:26:22 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-18 02:26:22 --> Config Class Initialized
INFO - 2024-02-18 02:26:22 --> Hooks Class Initialized
DEBUG - 2024-02-18 02:26:22 --> UTF-8 Support Enabled
INFO - 2024-02-18 02:26:22 --> Utf8 Class Initialized
INFO - 2024-02-18 02:26:22 --> URI Class Initialized
INFO - 2024-02-18 02:26:22 --> Router Class Initialized
INFO - 2024-02-18 02:26:22 --> Output Class Initialized
INFO - 2024-02-18 02:26:22 --> Security Class Initialized
DEBUG - 2024-02-18 02:26:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-18 02:26:22 --> Input Class Initialized
INFO - 2024-02-18 02:26:22 --> Language Class Initialized
INFO - 2024-02-18 02:26:22 --> Loader Class Initialized
INFO - 2024-02-18 02:26:22 --> Helper loaded: url_helper
INFO - 2024-02-18 02:26:22 --> Helper loaded: file_helper
INFO - 2024-02-18 02:26:22 --> Helper loaded: html_helper
INFO - 2024-02-18 02:26:22 --> Helper loaded: text_helper
INFO - 2024-02-18 02:26:22 --> Helper loaded: form_helper
INFO - 2024-02-18 02:26:22 --> Helper loaded: lang_helper
INFO - 2024-02-18 02:26:22 --> Helper loaded: security_helper
INFO - 2024-02-18 02:26:22 --> Helper loaded: cookie_helper
INFO - 2024-02-18 02:26:22 --> Database Driver Class Initialized
INFO - 2024-02-18 02:26:22 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-18 02:26:22 --> Parser Class Initialized
INFO - 2024-02-18 02:26:22 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-18 02:26:22 --> Pagination Class Initialized
INFO - 2024-02-18 02:26:22 --> Form Validation Class Initialized
INFO - 2024-02-18 02:26:22 --> Controller Class Initialized
INFO - 2024-02-18 02:26:22 --> Model Class Initialized
DEBUG - 2024-02-18 02:26:22 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-18 02:26:22 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2024-02-18 02:26:22 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-02-18 02:26:22 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-02-18 02:26:22 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-02-18 02:26:22 --> Model Class Initialized
INFO - 2024-02-18 02:26:22 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-02-18 02:26:22 --> Final output sent to browser
DEBUG - 2024-02-18 02:26:22 --> Total execution time: 0.0343
ERROR - 2024-02-18 02:26:31 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-18 02:26:31 --> Config Class Initialized
INFO - 2024-02-18 02:26:31 --> Hooks Class Initialized
DEBUG - 2024-02-18 02:26:31 --> UTF-8 Support Enabled
INFO - 2024-02-18 02:26:31 --> Utf8 Class Initialized
INFO - 2024-02-18 02:26:31 --> URI Class Initialized
INFO - 2024-02-18 02:26:31 --> Router Class Initialized
INFO - 2024-02-18 02:26:31 --> Output Class Initialized
INFO - 2024-02-18 02:26:31 --> Security Class Initialized
DEBUG - 2024-02-18 02:26:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-18 02:26:31 --> Input Class Initialized
INFO - 2024-02-18 02:26:31 --> Language Class Initialized
INFO - 2024-02-18 02:26:31 --> Loader Class Initialized
INFO - 2024-02-18 02:26:31 --> Helper loaded: url_helper
INFO - 2024-02-18 02:26:31 --> Helper loaded: file_helper
INFO - 2024-02-18 02:26:31 --> Helper loaded: html_helper
INFO - 2024-02-18 02:26:31 --> Helper loaded: text_helper
INFO - 2024-02-18 02:26:31 --> Helper loaded: form_helper
INFO - 2024-02-18 02:26:31 --> Helper loaded: lang_helper
INFO - 2024-02-18 02:26:31 --> Helper loaded: security_helper
INFO - 2024-02-18 02:26:31 --> Helper loaded: cookie_helper
INFO - 2024-02-18 02:26:31 --> Database Driver Class Initialized
INFO - 2024-02-18 02:26:31 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-18 02:26:31 --> Parser Class Initialized
INFO - 2024-02-18 02:26:31 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-18 02:26:31 --> Pagination Class Initialized
INFO - 2024-02-18 02:26:31 --> Form Validation Class Initialized
INFO - 2024-02-18 02:26:31 --> Controller Class Initialized
INFO - 2024-02-18 02:26:31 --> Model Class Initialized
DEBUG - 2024-02-18 02:26:31 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-18 02:26:31 --> Model Class Initialized
INFO - 2024-02-18 02:26:31 --> Final output sent to browser
DEBUG - 2024-02-18 02:26:31 --> Total execution time: 0.0186
ERROR - 2024-02-18 02:26:31 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-18 02:26:31 --> Config Class Initialized
INFO - 2024-02-18 02:26:31 --> Hooks Class Initialized
DEBUG - 2024-02-18 02:26:31 --> UTF-8 Support Enabled
INFO - 2024-02-18 02:26:31 --> Utf8 Class Initialized
INFO - 2024-02-18 02:26:31 --> URI Class Initialized
DEBUG - 2024-02-18 02:26:31 --> No URI present. Default controller set.
INFO - 2024-02-18 02:26:31 --> Router Class Initialized
INFO - 2024-02-18 02:26:31 --> Output Class Initialized
INFO - 2024-02-18 02:26:31 --> Security Class Initialized
DEBUG - 2024-02-18 02:26:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-18 02:26:31 --> Input Class Initialized
INFO - 2024-02-18 02:26:31 --> Language Class Initialized
INFO - 2024-02-18 02:26:31 --> Loader Class Initialized
INFO - 2024-02-18 02:26:31 --> Helper loaded: url_helper
INFO - 2024-02-18 02:26:31 --> Helper loaded: file_helper
INFO - 2024-02-18 02:26:31 --> Helper loaded: html_helper
INFO - 2024-02-18 02:26:31 --> Helper loaded: text_helper
INFO - 2024-02-18 02:26:31 --> Helper loaded: form_helper
INFO - 2024-02-18 02:26:31 --> Helper loaded: lang_helper
INFO - 2024-02-18 02:26:31 --> Helper loaded: security_helper
INFO - 2024-02-18 02:26:31 --> Helper loaded: cookie_helper
INFO - 2024-02-18 02:26:31 --> Database Driver Class Initialized
INFO - 2024-02-18 02:26:31 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-18 02:26:31 --> Parser Class Initialized
INFO - 2024-02-18 02:26:31 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-18 02:26:31 --> Pagination Class Initialized
INFO - 2024-02-18 02:26:31 --> Form Validation Class Initialized
INFO - 2024-02-18 02:26:31 --> Controller Class Initialized
INFO - 2024-02-18 02:26:31 --> Model Class Initialized
DEBUG - 2024-02-18 02:26:31 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-18 02:26:31 --> Model Class Initialized
DEBUG - 2024-02-18 02:26:31 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-18 02:26:31 --> Model Class Initialized
INFO - 2024-02-18 02:26:31 --> Model Class Initialized
INFO - 2024-02-18 02:26:31 --> Model Class Initialized
INFO - 2024-02-18 02:26:31 --> Model Class Initialized
DEBUG - 2024-02-18 02:26:31 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-18 02:26:31 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-18 02:26:31 --> Model Class Initialized
INFO - 2024-02-18 02:26:31 --> Model Class Initialized
INFO - 2024-02-18 02:26:31 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2024-02-18 02:26:31 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-02-18 02:26:31 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-02-18 02:26:31 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-02-18 02:26:31 --> Model Class Initialized
INFO - 2024-02-18 02:26:31 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-02-18 02:26:31 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-02-18 02:26:31 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-02-18 02:26:31 --> Final output sent to browser
DEBUG - 2024-02-18 02:26:31 --> Total execution time: 0.2319
ERROR - 2024-02-18 02:26:38 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-18 02:26:38 --> Config Class Initialized
INFO - 2024-02-18 02:26:38 --> Hooks Class Initialized
DEBUG - 2024-02-18 02:26:38 --> UTF-8 Support Enabled
INFO - 2024-02-18 02:26:38 --> Utf8 Class Initialized
INFO - 2024-02-18 02:26:38 --> URI Class Initialized
INFO - 2024-02-18 02:26:38 --> Router Class Initialized
INFO - 2024-02-18 02:26:38 --> Output Class Initialized
INFO - 2024-02-18 02:26:38 --> Security Class Initialized
DEBUG - 2024-02-18 02:26:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-18 02:26:38 --> Input Class Initialized
INFO - 2024-02-18 02:26:38 --> Language Class Initialized
INFO - 2024-02-18 02:26:38 --> Loader Class Initialized
INFO - 2024-02-18 02:26:38 --> Helper loaded: url_helper
INFO - 2024-02-18 02:26:38 --> Helper loaded: file_helper
INFO - 2024-02-18 02:26:38 --> Helper loaded: html_helper
INFO - 2024-02-18 02:26:38 --> Helper loaded: text_helper
INFO - 2024-02-18 02:26:38 --> Helper loaded: form_helper
INFO - 2024-02-18 02:26:38 --> Helper loaded: lang_helper
INFO - 2024-02-18 02:26:38 --> Helper loaded: security_helper
INFO - 2024-02-18 02:26:38 --> Helper loaded: cookie_helper
INFO - 2024-02-18 02:26:38 --> Database Driver Class Initialized
INFO - 2024-02-18 02:26:38 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-18 02:26:38 --> Parser Class Initialized
INFO - 2024-02-18 02:26:38 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-18 02:26:38 --> Pagination Class Initialized
INFO - 2024-02-18 02:26:38 --> Form Validation Class Initialized
INFO - 2024-02-18 02:26:38 --> Controller Class Initialized
DEBUG - 2024-02-18 02:26:38 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-18 02:26:38 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-18 02:26:38 --> Model Class Initialized
DEBUG - 2024-02-18 02:26:38 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-18 02:26:38 --> Model Class Initialized
DEBUG - 2024-02-18 02:26:38 --> Lcustomer class already loaded. Second attempt ignored.
INFO - 2024-02-18 02:26:38 --> Model Class Initialized
INFO - 2024-02-18 02:26:38 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/customer/customer.php
DEBUG - 2024-02-18 02:26:38 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-02-18 02:26:38 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-02-18 02:26:38 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-02-18 02:26:38 --> Model Class Initialized
INFO - 2024-02-18 02:26:38 --> Model Class Initialized
INFO - 2024-02-18 02:26:38 --> Model Class Initialized
INFO - 2024-02-18 02:26:38 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-02-18 02:26:38 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-02-18 02:26:38 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-02-18 02:26:38 --> Final output sent to browser
DEBUG - 2024-02-18 02:26:38 --> Total execution time: 0.1464
ERROR - 2024-02-18 02:26:39 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-18 02:26:39 --> Config Class Initialized
INFO - 2024-02-18 02:26:39 --> Hooks Class Initialized
DEBUG - 2024-02-18 02:26:39 --> UTF-8 Support Enabled
INFO - 2024-02-18 02:26:39 --> Utf8 Class Initialized
INFO - 2024-02-18 02:26:39 --> URI Class Initialized
INFO - 2024-02-18 02:26:39 --> Router Class Initialized
INFO - 2024-02-18 02:26:39 --> Output Class Initialized
INFO - 2024-02-18 02:26:39 --> Security Class Initialized
DEBUG - 2024-02-18 02:26:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-18 02:26:39 --> Input Class Initialized
INFO - 2024-02-18 02:26:39 --> Language Class Initialized
INFO - 2024-02-18 02:26:39 --> Loader Class Initialized
INFO - 2024-02-18 02:26:39 --> Helper loaded: url_helper
INFO - 2024-02-18 02:26:39 --> Helper loaded: file_helper
INFO - 2024-02-18 02:26:39 --> Helper loaded: html_helper
INFO - 2024-02-18 02:26:39 --> Helper loaded: text_helper
INFO - 2024-02-18 02:26:39 --> Helper loaded: form_helper
INFO - 2024-02-18 02:26:39 --> Helper loaded: lang_helper
INFO - 2024-02-18 02:26:39 --> Helper loaded: security_helper
INFO - 2024-02-18 02:26:39 --> Helper loaded: cookie_helper
INFO - 2024-02-18 02:26:39 --> Database Driver Class Initialized
INFO - 2024-02-18 02:26:39 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-18 02:26:39 --> Parser Class Initialized
INFO - 2024-02-18 02:26:39 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-18 02:26:39 --> Pagination Class Initialized
INFO - 2024-02-18 02:26:39 --> Form Validation Class Initialized
INFO - 2024-02-18 02:26:39 --> Controller Class Initialized
DEBUG - 2024-02-18 02:26:39 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-18 02:26:39 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-18 02:26:39 --> Model Class Initialized
DEBUG - 2024-02-18 02:26:39 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-18 02:26:39 --> Model Class Initialized
INFO - 2024-02-18 02:26:39 --> Final output sent to browser
DEBUG - 2024-02-18 02:26:39 --> Total execution time: 0.0203
ERROR - 2024-02-18 02:26:43 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-18 02:26:43 --> Config Class Initialized
INFO - 2024-02-18 02:26:43 --> Hooks Class Initialized
DEBUG - 2024-02-18 02:26:43 --> UTF-8 Support Enabled
INFO - 2024-02-18 02:26:43 --> Utf8 Class Initialized
INFO - 2024-02-18 02:26:43 --> URI Class Initialized
INFO - 2024-02-18 02:26:43 --> Router Class Initialized
INFO - 2024-02-18 02:26:43 --> Output Class Initialized
INFO - 2024-02-18 02:26:43 --> Security Class Initialized
DEBUG - 2024-02-18 02:26:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-18 02:26:43 --> Input Class Initialized
INFO - 2024-02-18 02:26:43 --> Language Class Initialized
INFO - 2024-02-18 02:26:43 --> Loader Class Initialized
INFO - 2024-02-18 02:26:43 --> Helper loaded: url_helper
INFO - 2024-02-18 02:26:43 --> Helper loaded: file_helper
INFO - 2024-02-18 02:26:43 --> Helper loaded: html_helper
INFO - 2024-02-18 02:26:43 --> Helper loaded: text_helper
INFO - 2024-02-18 02:26:43 --> Helper loaded: form_helper
INFO - 2024-02-18 02:26:43 --> Helper loaded: lang_helper
INFO - 2024-02-18 02:26:43 --> Helper loaded: security_helper
INFO - 2024-02-18 02:26:43 --> Helper loaded: cookie_helper
INFO - 2024-02-18 02:26:43 --> Database Driver Class Initialized
INFO - 2024-02-18 02:26:43 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-18 02:26:43 --> Parser Class Initialized
INFO - 2024-02-18 02:26:43 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-18 02:26:43 --> Pagination Class Initialized
INFO - 2024-02-18 02:26:43 --> Form Validation Class Initialized
INFO - 2024-02-18 02:26:43 --> Controller Class Initialized
DEBUG - 2024-02-18 02:26:43 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-18 02:26:43 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-18 02:26:43 --> Model Class Initialized
DEBUG - 2024-02-18 02:26:43 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-18 02:26:43 --> Model Class Initialized
INFO - 2024-02-18 02:26:43 --> Final output sent to browser
DEBUG - 2024-02-18 02:26:43 --> Total execution time: 0.0312
ERROR - 2024-02-18 02:47:25 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-18 02:47:25 --> Config Class Initialized
INFO - 2024-02-18 02:47:25 --> Hooks Class Initialized
DEBUG - 2024-02-18 02:47:25 --> UTF-8 Support Enabled
INFO - 2024-02-18 02:47:25 --> Utf8 Class Initialized
INFO - 2024-02-18 02:47:25 --> URI Class Initialized
DEBUG - 2024-02-18 02:47:25 --> No URI present. Default controller set.
INFO - 2024-02-18 02:47:25 --> Router Class Initialized
INFO - 2024-02-18 02:47:25 --> Output Class Initialized
INFO - 2024-02-18 02:47:25 --> Security Class Initialized
DEBUG - 2024-02-18 02:47:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-18 02:47:25 --> Input Class Initialized
INFO - 2024-02-18 02:47:25 --> Language Class Initialized
INFO - 2024-02-18 02:47:25 --> Loader Class Initialized
INFO - 2024-02-18 02:47:25 --> Helper loaded: url_helper
INFO - 2024-02-18 02:47:25 --> Helper loaded: file_helper
INFO - 2024-02-18 02:47:25 --> Helper loaded: html_helper
INFO - 2024-02-18 02:47:25 --> Helper loaded: text_helper
INFO - 2024-02-18 02:47:25 --> Helper loaded: form_helper
INFO - 2024-02-18 02:47:25 --> Helper loaded: lang_helper
INFO - 2024-02-18 02:47:25 --> Helper loaded: security_helper
INFO - 2024-02-18 02:47:25 --> Helper loaded: cookie_helper
INFO - 2024-02-18 02:47:25 --> Database Driver Class Initialized
INFO - 2024-02-18 02:47:25 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-18 02:47:25 --> Parser Class Initialized
INFO - 2024-02-18 02:47:25 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-18 02:47:25 --> Pagination Class Initialized
INFO - 2024-02-18 02:47:25 --> Form Validation Class Initialized
INFO - 2024-02-18 02:47:25 --> Controller Class Initialized
INFO - 2024-02-18 02:47:25 --> Model Class Initialized
DEBUG - 2024-02-18 02:47:25 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-18 02:47:25 --> Model Class Initialized
DEBUG - 2024-02-18 02:47:25 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-18 02:47:25 --> Model Class Initialized
INFO - 2024-02-18 02:47:25 --> Model Class Initialized
INFO - 2024-02-18 02:47:25 --> Model Class Initialized
INFO - 2024-02-18 02:47:25 --> Model Class Initialized
DEBUG - 2024-02-18 02:47:25 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-18 02:47:25 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-18 02:47:25 --> Model Class Initialized
INFO - 2024-02-18 02:47:25 --> Model Class Initialized
INFO - 2024-02-18 02:47:25 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2024-02-18 02:47:25 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-02-18 02:47:25 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-02-18 02:47:25 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-02-18 02:47:25 --> Model Class Initialized
INFO - 2024-02-18 02:47:25 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-02-18 02:47:25 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-02-18 02:47:25 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-02-18 02:47:25 --> Final output sent to browser
DEBUG - 2024-02-18 02:47:25 --> Total execution time: 0.2357
ERROR - 2024-02-18 02:47:31 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-18 02:47:31 --> Config Class Initialized
INFO - 2024-02-18 02:47:31 --> Hooks Class Initialized
DEBUG - 2024-02-18 02:47:31 --> UTF-8 Support Enabled
INFO - 2024-02-18 02:47:31 --> Utf8 Class Initialized
INFO - 2024-02-18 02:47:31 --> URI Class Initialized
INFO - 2024-02-18 02:47:31 --> Router Class Initialized
INFO - 2024-02-18 02:47:31 --> Output Class Initialized
INFO - 2024-02-18 02:47:31 --> Security Class Initialized
DEBUG - 2024-02-18 02:47:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-18 02:47:31 --> Input Class Initialized
INFO - 2024-02-18 02:47:31 --> Language Class Initialized
INFO - 2024-02-18 02:47:31 --> Loader Class Initialized
INFO - 2024-02-18 02:47:31 --> Helper loaded: url_helper
INFO - 2024-02-18 02:47:31 --> Helper loaded: file_helper
INFO - 2024-02-18 02:47:31 --> Helper loaded: html_helper
INFO - 2024-02-18 02:47:31 --> Helper loaded: text_helper
INFO - 2024-02-18 02:47:31 --> Helper loaded: form_helper
INFO - 2024-02-18 02:47:31 --> Helper loaded: lang_helper
INFO - 2024-02-18 02:47:31 --> Helper loaded: security_helper
INFO - 2024-02-18 02:47:31 --> Helper loaded: cookie_helper
INFO - 2024-02-18 02:47:31 --> Database Driver Class Initialized
INFO - 2024-02-18 02:47:31 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-18 02:47:31 --> Parser Class Initialized
INFO - 2024-02-18 02:47:31 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-18 02:47:31 --> Pagination Class Initialized
INFO - 2024-02-18 02:47:31 --> Form Validation Class Initialized
INFO - 2024-02-18 02:47:31 --> Controller Class Initialized
INFO - 2024-02-18 02:47:31 --> Model Class Initialized
DEBUG - 2024-02-18 02:47:31 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-18 02:47:31 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-18 02:47:31 --> Model Class Initialized
DEBUG - 2024-02-18 02:47:31 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-18 02:47:31 --> Model Class Initialized
INFO - 2024-02-18 02:47:31 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice.php
DEBUG - 2024-02-18 02:47:31 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-02-18 02:47:31 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-02-18 02:47:31 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-02-18 02:47:31 --> Model Class Initialized
INFO - 2024-02-18 02:47:31 --> Model Class Initialized
INFO - 2024-02-18 02:47:31 --> Model Class Initialized
INFO - 2024-02-18 02:47:31 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-02-18 02:47:31 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-02-18 02:47:31 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-02-18 02:47:31 --> Final output sent to browser
DEBUG - 2024-02-18 02:47:31 --> Total execution time: 0.1487
ERROR - 2024-02-18 02:47:32 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-18 02:47:32 --> Config Class Initialized
INFO - 2024-02-18 02:47:32 --> Hooks Class Initialized
DEBUG - 2024-02-18 02:47:32 --> UTF-8 Support Enabled
INFO - 2024-02-18 02:47:32 --> Utf8 Class Initialized
INFO - 2024-02-18 02:47:32 --> URI Class Initialized
INFO - 2024-02-18 02:47:32 --> Router Class Initialized
INFO - 2024-02-18 02:47:32 --> Output Class Initialized
INFO - 2024-02-18 02:47:32 --> Security Class Initialized
DEBUG - 2024-02-18 02:47:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-18 02:47:32 --> Input Class Initialized
INFO - 2024-02-18 02:47:32 --> Language Class Initialized
INFO - 2024-02-18 02:47:32 --> Loader Class Initialized
INFO - 2024-02-18 02:47:32 --> Helper loaded: url_helper
INFO - 2024-02-18 02:47:32 --> Helper loaded: file_helper
INFO - 2024-02-18 02:47:32 --> Helper loaded: html_helper
INFO - 2024-02-18 02:47:32 --> Helper loaded: text_helper
INFO - 2024-02-18 02:47:32 --> Helper loaded: form_helper
INFO - 2024-02-18 02:47:32 --> Helper loaded: lang_helper
INFO - 2024-02-18 02:47:32 --> Helper loaded: security_helper
INFO - 2024-02-18 02:47:32 --> Helper loaded: cookie_helper
INFO - 2024-02-18 02:47:32 --> Database Driver Class Initialized
INFO - 2024-02-18 02:47:32 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-18 02:47:32 --> Parser Class Initialized
INFO - 2024-02-18 02:47:32 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-18 02:47:32 --> Pagination Class Initialized
INFO - 2024-02-18 02:47:32 --> Form Validation Class Initialized
INFO - 2024-02-18 02:47:32 --> Controller Class Initialized
INFO - 2024-02-18 02:47:32 --> Model Class Initialized
DEBUG - 2024-02-18 02:47:32 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-18 02:47:32 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-18 02:47:32 --> Model Class Initialized
DEBUG - 2024-02-18 02:47:32 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-18 02:47:32 --> Model Class Initialized
INFO - 2024-02-18 02:47:32 --> Final output sent to browser
DEBUG - 2024-02-18 02:47:32 --> Total execution time: 0.0403
ERROR - 2024-02-18 02:47:36 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-18 02:47:36 --> Config Class Initialized
INFO - 2024-02-18 02:47:36 --> Hooks Class Initialized
DEBUG - 2024-02-18 02:47:36 --> UTF-8 Support Enabled
INFO - 2024-02-18 02:47:36 --> Utf8 Class Initialized
INFO - 2024-02-18 02:47:36 --> URI Class Initialized
INFO - 2024-02-18 02:47:36 --> Router Class Initialized
INFO - 2024-02-18 02:47:36 --> Output Class Initialized
INFO - 2024-02-18 02:47:36 --> Security Class Initialized
DEBUG - 2024-02-18 02:47:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-18 02:47:36 --> Input Class Initialized
INFO - 2024-02-18 02:47:36 --> Language Class Initialized
INFO - 2024-02-18 02:47:36 --> Loader Class Initialized
INFO - 2024-02-18 02:47:36 --> Helper loaded: url_helper
INFO - 2024-02-18 02:47:36 --> Helper loaded: file_helper
INFO - 2024-02-18 02:47:36 --> Helper loaded: html_helper
INFO - 2024-02-18 02:47:36 --> Helper loaded: text_helper
INFO - 2024-02-18 02:47:36 --> Helper loaded: form_helper
INFO - 2024-02-18 02:47:36 --> Helper loaded: lang_helper
INFO - 2024-02-18 02:47:36 --> Helper loaded: security_helper
INFO - 2024-02-18 02:47:36 --> Helper loaded: cookie_helper
INFO - 2024-02-18 02:47:36 --> Database Driver Class Initialized
INFO - 2024-02-18 02:47:36 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-18 02:47:36 --> Parser Class Initialized
INFO - 2024-02-18 02:47:36 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-18 02:47:36 --> Pagination Class Initialized
INFO - 2024-02-18 02:47:36 --> Form Validation Class Initialized
INFO - 2024-02-18 02:47:36 --> Controller Class Initialized
INFO - 2024-02-18 02:47:36 --> Model Class Initialized
DEBUG - 2024-02-18 02:47:36 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-18 02:47:36 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-18 02:47:36 --> Model Class Initialized
DEBUG - 2024-02-18 02:47:36 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-18 02:47:36 --> Model Class Initialized
INFO - 2024-02-18 02:47:37 --> Final output sent to browser
DEBUG - 2024-02-18 02:47:37 --> Total execution time: 0.1686
ERROR - 2024-02-18 02:47:58 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-18 02:47:58 --> Config Class Initialized
INFO - 2024-02-18 02:47:58 --> Hooks Class Initialized
DEBUG - 2024-02-18 02:47:58 --> UTF-8 Support Enabled
INFO - 2024-02-18 02:47:58 --> Utf8 Class Initialized
INFO - 2024-02-18 02:47:58 --> URI Class Initialized
INFO - 2024-02-18 02:47:58 --> Router Class Initialized
INFO - 2024-02-18 02:47:58 --> Output Class Initialized
INFO - 2024-02-18 02:47:58 --> Security Class Initialized
DEBUG - 2024-02-18 02:47:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-18 02:47:58 --> Input Class Initialized
INFO - 2024-02-18 02:47:58 --> Language Class Initialized
INFO - 2024-02-18 02:47:58 --> Loader Class Initialized
INFO - 2024-02-18 02:47:58 --> Helper loaded: url_helper
INFO - 2024-02-18 02:47:58 --> Helper loaded: file_helper
INFO - 2024-02-18 02:47:58 --> Helper loaded: html_helper
INFO - 2024-02-18 02:47:58 --> Helper loaded: text_helper
INFO - 2024-02-18 02:47:58 --> Helper loaded: form_helper
INFO - 2024-02-18 02:47:58 --> Helper loaded: lang_helper
INFO - 2024-02-18 02:47:58 --> Helper loaded: security_helper
INFO - 2024-02-18 02:47:58 --> Helper loaded: cookie_helper
INFO - 2024-02-18 02:47:58 --> Database Driver Class Initialized
INFO - 2024-02-18 02:47:58 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-18 02:47:58 --> Parser Class Initialized
INFO - 2024-02-18 02:47:58 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-18 02:47:58 --> Pagination Class Initialized
INFO - 2024-02-18 02:47:58 --> Form Validation Class Initialized
INFO - 2024-02-18 02:47:58 --> Controller Class Initialized
INFO - 2024-02-18 02:47:58 --> Model Class Initialized
DEBUG - 2024-02-18 02:47:58 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-18 02:47:58 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-18 02:47:58 --> Model Class Initialized
DEBUG - 2024-02-18 02:47:58 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-18 02:47:58 --> Model Class Initialized
DEBUG - 2024-02-18 02:47:58 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-18 02:47:58 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice_html.php
DEBUG - 2024-02-18 02:47:58 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-02-18 02:47:58 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-02-18 02:47:58 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-02-18 02:47:58 --> Model Class Initialized
INFO - 2024-02-18 02:47:58 --> Model Class Initialized
INFO - 2024-02-18 02:47:58 --> Model Class Initialized
INFO - 2024-02-18 02:47:58 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-02-18 02:47:58 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-02-18 02:47:58 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-02-18 02:47:58 --> Final output sent to browser
DEBUG - 2024-02-18 02:47:58 --> Total execution time: 0.1591
ERROR - 2024-02-18 02:48:45 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-18 02:48:45 --> Config Class Initialized
INFO - 2024-02-18 02:48:45 --> Hooks Class Initialized
DEBUG - 2024-02-18 02:48:45 --> UTF-8 Support Enabled
INFO - 2024-02-18 02:48:45 --> Utf8 Class Initialized
INFO - 2024-02-18 02:48:45 --> URI Class Initialized
INFO - 2024-02-18 02:48:45 --> Router Class Initialized
INFO - 2024-02-18 02:48:45 --> Output Class Initialized
INFO - 2024-02-18 02:48:45 --> Security Class Initialized
DEBUG - 2024-02-18 02:48:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-18 02:48:45 --> Input Class Initialized
INFO - 2024-02-18 02:48:45 --> Language Class Initialized
INFO - 2024-02-18 02:48:45 --> Loader Class Initialized
INFO - 2024-02-18 02:48:45 --> Helper loaded: url_helper
INFO - 2024-02-18 02:48:45 --> Helper loaded: file_helper
INFO - 2024-02-18 02:48:45 --> Helper loaded: html_helper
INFO - 2024-02-18 02:48:45 --> Helper loaded: text_helper
INFO - 2024-02-18 02:48:45 --> Helper loaded: form_helper
INFO - 2024-02-18 02:48:45 --> Helper loaded: lang_helper
INFO - 2024-02-18 02:48:45 --> Helper loaded: security_helper
INFO - 2024-02-18 02:48:45 --> Helper loaded: cookie_helper
INFO - 2024-02-18 02:48:45 --> Database Driver Class Initialized
INFO - 2024-02-18 02:48:45 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-18 02:48:45 --> Parser Class Initialized
INFO - 2024-02-18 02:48:45 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-18 02:48:45 --> Pagination Class Initialized
INFO - 2024-02-18 02:48:45 --> Form Validation Class Initialized
INFO - 2024-02-18 02:48:45 --> Controller Class Initialized
INFO - 2024-02-18 02:48:46 --> Model Class Initialized
DEBUG - 2024-02-18 02:48:46 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-18 02:48:46 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-18 02:48:46 --> Model Class Initialized
DEBUG - 2024-02-18 02:48:46 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-18 02:48:46 --> Model Class Initialized
INFO - 2024-02-18 02:48:46 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice.php
DEBUG - 2024-02-18 02:48:46 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-02-18 02:48:46 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-02-18 02:48:46 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-02-18 02:48:46 --> Model Class Initialized
INFO - 2024-02-18 02:48:46 --> Model Class Initialized
INFO - 2024-02-18 02:48:46 --> Model Class Initialized
INFO - 2024-02-18 02:48:46 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-02-18 02:48:46 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-02-18 02:48:46 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-02-18 02:48:46 --> Final output sent to browser
DEBUG - 2024-02-18 02:48:46 --> Total execution time: 0.1525
ERROR - 2024-02-18 02:48:47 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-18 02:48:47 --> Config Class Initialized
INFO - 2024-02-18 02:48:47 --> Hooks Class Initialized
DEBUG - 2024-02-18 02:48:47 --> UTF-8 Support Enabled
INFO - 2024-02-18 02:48:47 --> Utf8 Class Initialized
INFO - 2024-02-18 02:48:47 --> URI Class Initialized
INFO - 2024-02-18 02:48:47 --> Router Class Initialized
INFO - 2024-02-18 02:48:47 --> Output Class Initialized
INFO - 2024-02-18 02:48:47 --> Security Class Initialized
DEBUG - 2024-02-18 02:48:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-18 02:48:47 --> Input Class Initialized
INFO - 2024-02-18 02:48:47 --> Language Class Initialized
INFO - 2024-02-18 02:48:47 --> Loader Class Initialized
INFO - 2024-02-18 02:48:47 --> Helper loaded: url_helper
INFO - 2024-02-18 02:48:47 --> Helper loaded: file_helper
INFO - 2024-02-18 02:48:47 --> Helper loaded: html_helper
INFO - 2024-02-18 02:48:47 --> Helper loaded: text_helper
INFO - 2024-02-18 02:48:47 --> Helper loaded: form_helper
INFO - 2024-02-18 02:48:47 --> Helper loaded: lang_helper
INFO - 2024-02-18 02:48:47 --> Helper loaded: security_helper
INFO - 2024-02-18 02:48:47 --> Helper loaded: cookie_helper
INFO - 2024-02-18 02:48:47 --> Database Driver Class Initialized
INFO - 2024-02-18 02:48:47 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-18 02:48:47 --> Parser Class Initialized
INFO - 2024-02-18 02:48:47 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-18 02:48:47 --> Pagination Class Initialized
INFO - 2024-02-18 02:48:47 --> Form Validation Class Initialized
INFO - 2024-02-18 02:48:47 --> Controller Class Initialized
INFO - 2024-02-18 02:48:47 --> Model Class Initialized
DEBUG - 2024-02-18 02:48:47 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-18 02:48:47 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-18 02:48:47 --> Model Class Initialized
DEBUG - 2024-02-18 02:48:47 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-18 02:48:47 --> Model Class Initialized
INFO - 2024-02-18 02:48:47 --> Final output sent to browser
DEBUG - 2024-02-18 02:48:47 --> Total execution time: 0.0395
ERROR - 2024-02-18 02:48:50 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-18 02:48:50 --> Config Class Initialized
INFO - 2024-02-18 02:48:50 --> Hooks Class Initialized
DEBUG - 2024-02-18 02:48:50 --> UTF-8 Support Enabled
INFO - 2024-02-18 02:48:50 --> Utf8 Class Initialized
INFO - 2024-02-18 02:48:50 --> URI Class Initialized
DEBUG - 2024-02-18 02:48:50 --> No URI present. Default controller set.
INFO - 2024-02-18 02:48:50 --> Router Class Initialized
INFO - 2024-02-18 02:48:50 --> Output Class Initialized
INFO - 2024-02-18 02:48:50 --> Security Class Initialized
DEBUG - 2024-02-18 02:48:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-18 02:48:50 --> Input Class Initialized
INFO - 2024-02-18 02:48:50 --> Language Class Initialized
INFO - 2024-02-18 02:48:50 --> Loader Class Initialized
INFO - 2024-02-18 02:48:50 --> Helper loaded: url_helper
INFO - 2024-02-18 02:48:50 --> Helper loaded: file_helper
INFO - 2024-02-18 02:48:50 --> Helper loaded: html_helper
INFO - 2024-02-18 02:48:50 --> Helper loaded: text_helper
INFO - 2024-02-18 02:48:50 --> Helper loaded: form_helper
INFO - 2024-02-18 02:48:50 --> Helper loaded: lang_helper
INFO - 2024-02-18 02:48:50 --> Helper loaded: security_helper
INFO - 2024-02-18 02:48:50 --> Helper loaded: cookie_helper
INFO - 2024-02-18 02:48:50 --> Database Driver Class Initialized
INFO - 2024-02-18 02:48:50 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-18 02:48:50 --> Parser Class Initialized
INFO - 2024-02-18 02:48:50 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-18 02:48:50 --> Pagination Class Initialized
INFO - 2024-02-18 02:48:50 --> Form Validation Class Initialized
INFO - 2024-02-18 02:48:50 --> Controller Class Initialized
INFO - 2024-02-18 02:48:50 --> Model Class Initialized
DEBUG - 2024-02-18 02:48:50 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-18 02:48:50 --> Model Class Initialized
DEBUG - 2024-02-18 02:48:50 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-18 02:48:50 --> Model Class Initialized
INFO - 2024-02-18 02:48:50 --> Model Class Initialized
INFO - 2024-02-18 02:48:50 --> Model Class Initialized
INFO - 2024-02-18 02:48:50 --> Model Class Initialized
DEBUG - 2024-02-18 02:48:50 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-18 02:48:50 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-18 02:48:50 --> Model Class Initialized
INFO - 2024-02-18 02:48:50 --> Model Class Initialized
INFO - 2024-02-18 02:48:50 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2024-02-18 02:48:50 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-02-18 02:48:50 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-02-18 02:48:50 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-02-18 02:48:50 --> Model Class Initialized
INFO - 2024-02-18 02:48:50 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-02-18 02:48:50 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-02-18 02:48:50 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-02-18 02:48:50 --> Final output sent to browser
DEBUG - 2024-02-18 02:48:50 --> Total execution time: 0.2223
ERROR - 2024-02-18 02:48:55 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-18 02:48:55 --> Config Class Initialized
INFO - 2024-02-18 02:48:55 --> Hooks Class Initialized
DEBUG - 2024-02-18 02:48:55 --> UTF-8 Support Enabled
INFO - 2024-02-18 02:48:55 --> Utf8 Class Initialized
INFO - 2024-02-18 02:48:55 --> URI Class Initialized
INFO - 2024-02-18 02:48:55 --> Router Class Initialized
INFO - 2024-02-18 02:48:55 --> Output Class Initialized
INFO - 2024-02-18 02:48:55 --> Security Class Initialized
DEBUG - 2024-02-18 02:48:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-18 02:48:55 --> Input Class Initialized
INFO - 2024-02-18 02:48:55 --> Language Class Initialized
INFO - 2024-02-18 02:48:55 --> Loader Class Initialized
INFO - 2024-02-18 02:48:55 --> Helper loaded: url_helper
INFO - 2024-02-18 02:48:55 --> Helper loaded: file_helper
INFO - 2024-02-18 02:48:55 --> Helper loaded: html_helper
INFO - 2024-02-18 02:48:55 --> Helper loaded: text_helper
INFO - 2024-02-18 02:48:55 --> Helper loaded: form_helper
INFO - 2024-02-18 02:48:55 --> Helper loaded: lang_helper
INFO - 2024-02-18 02:48:55 --> Helper loaded: security_helper
INFO - 2024-02-18 02:48:55 --> Helper loaded: cookie_helper
INFO - 2024-02-18 02:48:55 --> Database Driver Class Initialized
INFO - 2024-02-18 02:48:55 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-18 02:48:55 --> Parser Class Initialized
INFO - 2024-02-18 02:48:55 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-18 02:48:55 --> Pagination Class Initialized
INFO - 2024-02-18 02:48:55 --> Form Validation Class Initialized
INFO - 2024-02-18 02:48:55 --> Controller Class Initialized
INFO - 2024-02-18 02:48:55 --> Model Class Initialized
DEBUG - 2024-02-18 02:48:55 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-18 02:48:55 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-18 02:48:55 --> Model Class Initialized
INFO - 2024-02-18 02:48:55 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/stockrequest/inventory.php
DEBUG - 2024-02-18 02:48:55 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-02-18 02:48:55 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-02-18 02:48:55 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-02-18 02:48:55 --> Model Class Initialized
INFO - 2024-02-18 02:48:55 --> Model Class Initialized
INFO - 2024-02-18 02:48:55 --> Model Class Initialized
INFO - 2024-02-18 02:48:55 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-02-18 02:48:55 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-02-18 02:48:55 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-02-18 02:48:55 --> Final output sent to browser
DEBUG - 2024-02-18 02:48:55 --> Total execution time: 0.1448
ERROR - 2024-02-18 02:48:56 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-18 02:48:56 --> Config Class Initialized
INFO - 2024-02-18 02:48:56 --> Hooks Class Initialized
DEBUG - 2024-02-18 02:48:56 --> UTF-8 Support Enabled
INFO - 2024-02-18 02:48:56 --> Utf8 Class Initialized
INFO - 2024-02-18 02:48:56 --> URI Class Initialized
INFO - 2024-02-18 02:48:56 --> Router Class Initialized
INFO - 2024-02-18 02:48:56 --> Output Class Initialized
INFO - 2024-02-18 02:48:56 --> Security Class Initialized
DEBUG - 2024-02-18 02:48:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-18 02:48:56 --> Input Class Initialized
INFO - 2024-02-18 02:48:56 --> Language Class Initialized
INFO - 2024-02-18 02:48:56 --> Loader Class Initialized
INFO - 2024-02-18 02:48:56 --> Helper loaded: url_helper
INFO - 2024-02-18 02:48:56 --> Helper loaded: file_helper
INFO - 2024-02-18 02:48:56 --> Helper loaded: html_helper
INFO - 2024-02-18 02:48:56 --> Helper loaded: text_helper
INFO - 2024-02-18 02:48:56 --> Helper loaded: form_helper
INFO - 2024-02-18 02:48:56 --> Helper loaded: lang_helper
INFO - 2024-02-18 02:48:56 --> Helper loaded: security_helper
INFO - 2024-02-18 02:48:56 --> Helper loaded: cookie_helper
INFO - 2024-02-18 02:48:56 --> Database Driver Class Initialized
INFO - 2024-02-18 02:48:56 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-18 02:48:56 --> Parser Class Initialized
INFO - 2024-02-18 02:48:56 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-18 02:48:56 --> Pagination Class Initialized
INFO - 2024-02-18 02:48:56 --> Form Validation Class Initialized
INFO - 2024-02-18 02:48:56 --> Controller Class Initialized
INFO - 2024-02-18 02:48:56 --> Model Class Initialized
DEBUG - 2024-02-18 02:48:56 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-18 02:48:56 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-18 02:48:56 --> Model Class Initialized
INFO - 2024-02-18 02:48:56 --> Final output sent to browser
DEBUG - 2024-02-18 02:48:56 --> Total execution time: 0.0544
ERROR - 2024-02-18 06:19:30 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-18 06:19:30 --> Config Class Initialized
INFO - 2024-02-18 06:19:30 --> Hooks Class Initialized
DEBUG - 2024-02-18 06:19:30 --> UTF-8 Support Enabled
INFO - 2024-02-18 06:19:30 --> Utf8 Class Initialized
INFO - 2024-02-18 06:19:30 --> URI Class Initialized
DEBUG - 2024-02-18 06:19:30 --> No URI present. Default controller set.
INFO - 2024-02-18 06:19:30 --> Router Class Initialized
INFO - 2024-02-18 06:19:30 --> Output Class Initialized
INFO - 2024-02-18 06:19:30 --> Security Class Initialized
DEBUG - 2024-02-18 06:19:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-18 06:19:30 --> Input Class Initialized
INFO - 2024-02-18 06:19:30 --> Language Class Initialized
INFO - 2024-02-18 06:19:30 --> Loader Class Initialized
INFO - 2024-02-18 06:19:30 --> Helper loaded: url_helper
INFO - 2024-02-18 06:19:30 --> Helper loaded: file_helper
INFO - 2024-02-18 06:19:30 --> Helper loaded: html_helper
INFO - 2024-02-18 06:19:30 --> Helper loaded: text_helper
INFO - 2024-02-18 06:19:30 --> Helper loaded: form_helper
INFO - 2024-02-18 06:19:30 --> Helper loaded: lang_helper
INFO - 2024-02-18 06:19:30 --> Helper loaded: security_helper
INFO - 2024-02-18 06:19:30 --> Helper loaded: cookie_helper
INFO - 2024-02-18 06:19:30 --> Database Driver Class Initialized
INFO - 2024-02-18 06:19:30 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-18 06:19:30 --> Parser Class Initialized
INFO - 2024-02-18 06:19:30 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-18 06:19:30 --> Pagination Class Initialized
INFO - 2024-02-18 06:19:30 --> Form Validation Class Initialized
INFO - 2024-02-18 06:19:30 --> Controller Class Initialized
INFO - 2024-02-18 06:19:30 --> Model Class Initialized
DEBUG - 2024-02-18 06:19:30 --> Session class already loaded. Second attempt ignored.
ERROR - 2024-02-18 06:19:31 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-18 06:19:31 --> Config Class Initialized
INFO - 2024-02-18 06:19:31 --> Hooks Class Initialized
DEBUG - 2024-02-18 06:19:31 --> UTF-8 Support Enabled
INFO - 2024-02-18 06:19:31 --> Utf8 Class Initialized
INFO - 2024-02-18 06:19:31 --> URI Class Initialized
INFO - 2024-02-18 06:19:31 --> Router Class Initialized
INFO - 2024-02-18 06:19:31 --> Output Class Initialized
INFO - 2024-02-18 06:19:31 --> Security Class Initialized
DEBUG - 2024-02-18 06:19:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-18 06:19:31 --> Input Class Initialized
INFO - 2024-02-18 06:19:31 --> Language Class Initialized
INFO - 2024-02-18 06:19:31 --> Loader Class Initialized
INFO - 2024-02-18 06:19:31 --> Helper loaded: url_helper
INFO - 2024-02-18 06:19:31 --> Helper loaded: file_helper
INFO - 2024-02-18 06:19:31 --> Helper loaded: html_helper
INFO - 2024-02-18 06:19:31 --> Helper loaded: text_helper
INFO - 2024-02-18 06:19:31 --> Helper loaded: form_helper
INFO - 2024-02-18 06:19:31 --> Helper loaded: lang_helper
INFO - 2024-02-18 06:19:31 --> Helper loaded: security_helper
INFO - 2024-02-18 06:19:31 --> Helper loaded: cookie_helper
INFO - 2024-02-18 06:19:31 --> Database Driver Class Initialized
INFO - 2024-02-18 06:19:31 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-18 06:19:31 --> Parser Class Initialized
INFO - 2024-02-18 06:19:31 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-18 06:19:31 --> Pagination Class Initialized
INFO - 2024-02-18 06:19:31 --> Form Validation Class Initialized
INFO - 2024-02-18 06:19:31 --> Controller Class Initialized
INFO - 2024-02-18 06:19:31 --> Model Class Initialized
DEBUG - 2024-02-18 06:19:31 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-18 06:19:31 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2024-02-18 06:19:31 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-02-18 06:19:31 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-02-18 06:19:31 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-02-18 06:19:31 --> Model Class Initialized
INFO - 2024-02-18 06:19:31 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-02-18 06:19:31 --> Final output sent to browser
DEBUG - 2024-02-18 06:19:31 --> Total execution time: 0.0365
ERROR - 2024-02-18 06:42:24 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-18 06:42:24 --> Config Class Initialized
INFO - 2024-02-18 06:42:24 --> Hooks Class Initialized
DEBUG - 2024-02-18 06:42:24 --> UTF-8 Support Enabled
INFO - 2024-02-18 06:42:24 --> Utf8 Class Initialized
INFO - 2024-02-18 06:42:24 --> URI Class Initialized
DEBUG - 2024-02-18 06:42:24 --> No URI present. Default controller set.
INFO - 2024-02-18 06:42:24 --> Router Class Initialized
INFO - 2024-02-18 06:42:24 --> Output Class Initialized
INFO - 2024-02-18 06:42:24 --> Security Class Initialized
DEBUG - 2024-02-18 06:42:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-18 06:42:24 --> Input Class Initialized
INFO - 2024-02-18 06:42:24 --> Language Class Initialized
INFO - 2024-02-18 06:42:24 --> Loader Class Initialized
INFO - 2024-02-18 06:42:24 --> Helper loaded: url_helper
INFO - 2024-02-18 06:42:24 --> Helper loaded: file_helper
INFO - 2024-02-18 06:42:24 --> Helper loaded: html_helper
INFO - 2024-02-18 06:42:24 --> Helper loaded: text_helper
INFO - 2024-02-18 06:42:24 --> Helper loaded: form_helper
INFO - 2024-02-18 06:42:24 --> Helper loaded: lang_helper
INFO - 2024-02-18 06:42:24 --> Helper loaded: security_helper
INFO - 2024-02-18 06:42:24 --> Helper loaded: cookie_helper
INFO - 2024-02-18 06:42:24 --> Database Driver Class Initialized
INFO - 2024-02-18 06:42:24 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-18 06:42:24 --> Parser Class Initialized
INFO - 2024-02-18 06:42:24 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-18 06:42:24 --> Pagination Class Initialized
INFO - 2024-02-18 06:42:24 --> Form Validation Class Initialized
INFO - 2024-02-18 06:42:24 --> Controller Class Initialized
INFO - 2024-02-18 06:42:24 --> Model Class Initialized
DEBUG - 2024-02-18 06:42:24 --> Session class already loaded. Second attempt ignored.
ERROR - 2024-02-18 06:42:24 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-18 06:42:24 --> Config Class Initialized
INFO - 2024-02-18 06:42:24 --> Hooks Class Initialized
DEBUG - 2024-02-18 06:42:24 --> UTF-8 Support Enabled
INFO - 2024-02-18 06:42:24 --> Utf8 Class Initialized
INFO - 2024-02-18 06:42:24 --> URI Class Initialized
INFO - 2024-02-18 06:42:24 --> Router Class Initialized
INFO - 2024-02-18 06:42:24 --> Output Class Initialized
INFO - 2024-02-18 06:42:24 --> Security Class Initialized
DEBUG - 2024-02-18 06:42:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-18 06:42:24 --> Input Class Initialized
INFO - 2024-02-18 06:42:24 --> Language Class Initialized
INFO - 2024-02-18 06:42:24 --> Loader Class Initialized
INFO - 2024-02-18 06:42:24 --> Helper loaded: url_helper
INFO - 2024-02-18 06:42:24 --> Helper loaded: file_helper
INFO - 2024-02-18 06:42:24 --> Helper loaded: html_helper
INFO - 2024-02-18 06:42:24 --> Helper loaded: text_helper
INFO - 2024-02-18 06:42:24 --> Helper loaded: form_helper
INFO - 2024-02-18 06:42:24 --> Helper loaded: lang_helper
INFO - 2024-02-18 06:42:24 --> Helper loaded: security_helper
INFO - 2024-02-18 06:42:24 --> Helper loaded: cookie_helper
INFO - 2024-02-18 06:42:24 --> Database Driver Class Initialized
INFO - 2024-02-18 06:42:24 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-18 06:42:24 --> Parser Class Initialized
INFO - 2024-02-18 06:42:24 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-18 06:42:24 --> Pagination Class Initialized
INFO - 2024-02-18 06:42:24 --> Form Validation Class Initialized
INFO - 2024-02-18 06:42:24 --> Controller Class Initialized
INFO - 2024-02-18 06:42:24 --> Model Class Initialized
DEBUG - 2024-02-18 06:42:24 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-18 06:42:24 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2024-02-18 06:42:24 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-02-18 06:42:24 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-02-18 06:42:24 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-02-18 06:42:24 --> Model Class Initialized
INFO - 2024-02-18 06:42:24 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-02-18 06:42:24 --> Final output sent to browser
DEBUG - 2024-02-18 06:42:24 --> Total execution time: 0.0295
ERROR - 2024-02-18 06:42:41 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-18 06:42:41 --> Config Class Initialized
INFO - 2024-02-18 06:42:41 --> Hooks Class Initialized
DEBUG - 2024-02-18 06:42:41 --> UTF-8 Support Enabled
INFO - 2024-02-18 06:42:41 --> Utf8 Class Initialized
INFO - 2024-02-18 06:42:41 --> URI Class Initialized
INFO - 2024-02-18 06:42:41 --> Router Class Initialized
INFO - 2024-02-18 06:42:41 --> Output Class Initialized
INFO - 2024-02-18 06:42:41 --> Security Class Initialized
DEBUG - 2024-02-18 06:42:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-18 06:42:41 --> Input Class Initialized
INFO - 2024-02-18 06:42:41 --> Language Class Initialized
INFO - 2024-02-18 06:42:41 --> Loader Class Initialized
INFO - 2024-02-18 06:42:41 --> Helper loaded: url_helper
INFO - 2024-02-18 06:42:41 --> Helper loaded: file_helper
INFO - 2024-02-18 06:42:41 --> Helper loaded: html_helper
INFO - 2024-02-18 06:42:41 --> Helper loaded: text_helper
INFO - 2024-02-18 06:42:41 --> Helper loaded: form_helper
INFO - 2024-02-18 06:42:41 --> Helper loaded: lang_helper
INFO - 2024-02-18 06:42:41 --> Helper loaded: security_helper
INFO - 2024-02-18 06:42:41 --> Helper loaded: cookie_helper
INFO - 2024-02-18 06:42:41 --> Database Driver Class Initialized
INFO - 2024-02-18 06:42:41 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-18 06:42:41 --> Parser Class Initialized
INFO - 2024-02-18 06:42:41 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-18 06:42:41 --> Pagination Class Initialized
INFO - 2024-02-18 06:42:41 --> Form Validation Class Initialized
INFO - 2024-02-18 06:42:41 --> Controller Class Initialized
INFO - 2024-02-18 06:42:41 --> Model Class Initialized
DEBUG - 2024-02-18 06:42:41 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-18 06:42:41 --> Model Class Initialized
INFO - 2024-02-18 06:42:41 --> Final output sent to browser
DEBUG - 2024-02-18 06:42:41 --> Total execution time: 0.0218
ERROR - 2024-02-18 06:42:41 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-18 06:42:41 --> Config Class Initialized
INFO - 2024-02-18 06:42:41 --> Hooks Class Initialized
DEBUG - 2024-02-18 06:42:41 --> UTF-8 Support Enabled
INFO - 2024-02-18 06:42:41 --> Utf8 Class Initialized
INFO - 2024-02-18 06:42:41 --> URI Class Initialized
DEBUG - 2024-02-18 06:42:41 --> No URI present. Default controller set.
INFO - 2024-02-18 06:42:41 --> Router Class Initialized
INFO - 2024-02-18 06:42:41 --> Output Class Initialized
INFO - 2024-02-18 06:42:41 --> Security Class Initialized
DEBUG - 2024-02-18 06:42:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-18 06:42:41 --> Input Class Initialized
INFO - 2024-02-18 06:42:41 --> Language Class Initialized
INFO - 2024-02-18 06:42:41 --> Loader Class Initialized
INFO - 2024-02-18 06:42:41 --> Helper loaded: url_helper
INFO - 2024-02-18 06:42:41 --> Helper loaded: file_helper
INFO - 2024-02-18 06:42:41 --> Helper loaded: html_helper
INFO - 2024-02-18 06:42:41 --> Helper loaded: text_helper
INFO - 2024-02-18 06:42:41 --> Helper loaded: form_helper
INFO - 2024-02-18 06:42:41 --> Helper loaded: lang_helper
INFO - 2024-02-18 06:42:41 --> Helper loaded: security_helper
INFO - 2024-02-18 06:42:41 --> Helper loaded: cookie_helper
INFO - 2024-02-18 06:42:41 --> Database Driver Class Initialized
INFO - 2024-02-18 06:42:41 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-18 06:42:41 --> Parser Class Initialized
INFO - 2024-02-18 06:42:41 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-18 06:42:41 --> Pagination Class Initialized
INFO - 2024-02-18 06:42:41 --> Form Validation Class Initialized
INFO - 2024-02-18 06:42:41 --> Controller Class Initialized
INFO - 2024-02-18 06:42:41 --> Model Class Initialized
DEBUG - 2024-02-18 06:42:41 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-18 06:42:41 --> Model Class Initialized
DEBUG - 2024-02-18 06:42:41 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-18 06:42:41 --> Model Class Initialized
INFO - 2024-02-18 06:42:41 --> Model Class Initialized
INFO - 2024-02-18 06:42:41 --> Model Class Initialized
INFO - 2024-02-18 06:42:41 --> Model Class Initialized
DEBUG - 2024-02-18 06:42:41 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-18 06:42:41 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-18 06:42:41 --> Model Class Initialized
INFO - 2024-02-18 06:42:41 --> Model Class Initialized
INFO - 2024-02-18 06:42:42 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2024-02-18 06:42:42 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-02-18 06:42:42 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-02-18 06:42:42 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-02-18 06:42:42 --> Model Class Initialized
INFO - 2024-02-18 06:42:42 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-02-18 06:42:42 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-02-18 06:42:42 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-02-18 06:42:42 --> Final output sent to browser
DEBUG - 2024-02-18 06:42:42 --> Total execution time: 0.4467
ERROR - 2024-02-18 06:42:43 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-18 06:42:43 --> Config Class Initialized
INFO - 2024-02-18 06:42:43 --> Hooks Class Initialized
DEBUG - 2024-02-18 06:42:43 --> UTF-8 Support Enabled
INFO - 2024-02-18 06:42:43 --> Utf8 Class Initialized
INFO - 2024-02-18 06:42:43 --> URI Class Initialized
INFO - 2024-02-18 06:42:43 --> Router Class Initialized
INFO - 2024-02-18 06:42:43 --> Output Class Initialized
INFO - 2024-02-18 06:42:43 --> Security Class Initialized
DEBUG - 2024-02-18 06:42:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-18 06:42:43 --> Input Class Initialized
INFO - 2024-02-18 06:42:43 --> Language Class Initialized
INFO - 2024-02-18 06:42:43 --> Loader Class Initialized
INFO - 2024-02-18 06:42:43 --> Helper loaded: url_helper
INFO - 2024-02-18 06:42:43 --> Helper loaded: file_helper
INFO - 2024-02-18 06:42:43 --> Helper loaded: html_helper
INFO - 2024-02-18 06:42:43 --> Helper loaded: text_helper
INFO - 2024-02-18 06:42:43 --> Helper loaded: form_helper
INFO - 2024-02-18 06:42:43 --> Helper loaded: lang_helper
INFO - 2024-02-18 06:42:43 --> Helper loaded: security_helper
INFO - 2024-02-18 06:42:43 --> Helper loaded: cookie_helper
INFO - 2024-02-18 06:42:43 --> Database Driver Class Initialized
INFO - 2024-02-18 06:42:43 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-18 06:42:43 --> Parser Class Initialized
INFO - 2024-02-18 06:42:43 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-18 06:42:43 --> Pagination Class Initialized
INFO - 2024-02-18 06:42:43 --> Form Validation Class Initialized
INFO - 2024-02-18 06:42:43 --> Controller Class Initialized
DEBUG - 2024-02-18 06:42:43 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-18 06:42:43 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-18 06:42:43 --> Model Class Initialized
INFO - 2024-02-18 06:42:43 --> Final output sent to browser
DEBUG - 2024-02-18 06:42:43 --> Total execution time: 0.0167
ERROR - 2024-02-18 06:43:11 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-18 06:43:11 --> Config Class Initialized
INFO - 2024-02-18 06:43:11 --> Hooks Class Initialized
DEBUG - 2024-02-18 06:43:11 --> UTF-8 Support Enabled
INFO - 2024-02-18 06:43:11 --> Utf8 Class Initialized
INFO - 2024-02-18 06:43:11 --> URI Class Initialized
INFO - 2024-02-18 06:43:11 --> Router Class Initialized
INFO - 2024-02-18 06:43:11 --> Output Class Initialized
INFO - 2024-02-18 06:43:11 --> Security Class Initialized
DEBUG - 2024-02-18 06:43:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-18 06:43:11 --> Input Class Initialized
INFO - 2024-02-18 06:43:11 --> Language Class Initialized
INFO - 2024-02-18 06:43:11 --> Loader Class Initialized
INFO - 2024-02-18 06:43:11 --> Helper loaded: url_helper
INFO - 2024-02-18 06:43:11 --> Helper loaded: file_helper
INFO - 2024-02-18 06:43:11 --> Helper loaded: html_helper
INFO - 2024-02-18 06:43:11 --> Helper loaded: text_helper
INFO - 2024-02-18 06:43:11 --> Helper loaded: form_helper
INFO - 2024-02-18 06:43:11 --> Helper loaded: lang_helper
INFO - 2024-02-18 06:43:11 --> Helper loaded: security_helper
INFO - 2024-02-18 06:43:11 --> Helper loaded: cookie_helper
INFO - 2024-02-18 06:43:11 --> Database Driver Class Initialized
INFO - 2024-02-18 06:43:11 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-18 06:43:11 --> Parser Class Initialized
INFO - 2024-02-18 06:43:11 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-18 06:43:11 --> Pagination Class Initialized
INFO - 2024-02-18 06:43:11 --> Form Validation Class Initialized
INFO - 2024-02-18 06:43:11 --> Controller Class Initialized
INFO - 2024-02-18 06:43:11 --> Model Class Initialized
DEBUG - 2024-02-18 06:43:11 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-18 06:43:11 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2024-02-18 06:43:11 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-02-18 06:43:11 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-02-18 06:43:11 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-02-18 06:43:11 --> Model Class Initialized
INFO - 2024-02-18 06:43:11 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-02-18 06:43:11 --> Final output sent to browser
DEBUG - 2024-02-18 06:43:11 --> Total execution time: 0.0301
ERROR - 2024-02-18 06:43:12 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-18 06:43:12 --> Config Class Initialized
INFO - 2024-02-18 06:43:12 --> Hooks Class Initialized
DEBUG - 2024-02-18 06:43:12 --> UTF-8 Support Enabled
INFO - 2024-02-18 06:43:12 --> Utf8 Class Initialized
INFO - 2024-02-18 06:43:12 --> URI Class Initialized
INFO - 2024-02-18 06:43:12 --> Router Class Initialized
INFO - 2024-02-18 06:43:12 --> Output Class Initialized
INFO - 2024-02-18 06:43:12 --> Security Class Initialized
DEBUG - 2024-02-18 06:43:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-18 06:43:12 --> Input Class Initialized
INFO - 2024-02-18 06:43:12 --> Language Class Initialized
INFO - 2024-02-18 06:43:12 --> Loader Class Initialized
INFO - 2024-02-18 06:43:12 --> Helper loaded: url_helper
INFO - 2024-02-18 06:43:12 --> Helper loaded: file_helper
INFO - 2024-02-18 06:43:12 --> Helper loaded: html_helper
INFO - 2024-02-18 06:43:12 --> Helper loaded: text_helper
INFO - 2024-02-18 06:43:12 --> Helper loaded: form_helper
INFO - 2024-02-18 06:43:12 --> Helper loaded: lang_helper
INFO - 2024-02-18 06:43:12 --> Helper loaded: security_helper
INFO - 2024-02-18 06:43:12 --> Helper loaded: cookie_helper
INFO - 2024-02-18 06:43:12 --> Database Driver Class Initialized
INFO - 2024-02-18 06:43:12 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-18 06:43:12 --> Parser Class Initialized
INFO - 2024-02-18 06:43:12 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-18 06:43:12 --> Pagination Class Initialized
INFO - 2024-02-18 06:43:12 --> Form Validation Class Initialized
INFO - 2024-02-18 06:43:12 --> Controller Class Initialized
INFO - 2024-02-18 06:43:12 --> Model Class Initialized
DEBUG - 2024-02-18 06:43:12 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-18 06:43:12 --> Model Class Initialized
DEBUG - 2024-02-18 06:43:12 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-18 06:43:12 --> Model Class Initialized
INFO - 2024-02-18 06:43:12 --> Model Class Initialized
INFO - 2024-02-18 06:43:12 --> Model Class Initialized
INFO - 2024-02-18 06:43:12 --> Model Class Initialized
DEBUG - 2024-02-18 06:43:12 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-18 06:43:12 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-18 06:43:12 --> Model Class Initialized
INFO - 2024-02-18 06:43:12 --> Model Class Initialized
INFO - 2024-02-18 06:43:12 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2024-02-18 06:43:12 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-02-18 06:43:12 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-02-18 06:43:12 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-02-18 06:43:12 --> Model Class Initialized
INFO - 2024-02-18 06:43:12 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-02-18 06:43:12 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-02-18 06:43:12 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-02-18 06:43:12 --> Final output sent to browser
DEBUG - 2024-02-18 06:43:12 --> Total execution time: 0.3839
ERROR - 2024-02-18 06:55:54 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-18 06:55:54 --> Config Class Initialized
INFO - 2024-02-18 06:55:54 --> Hooks Class Initialized
DEBUG - 2024-02-18 06:55:54 --> UTF-8 Support Enabled
INFO - 2024-02-18 06:55:54 --> Utf8 Class Initialized
INFO - 2024-02-18 06:55:54 --> URI Class Initialized
DEBUG - 2024-02-18 06:55:54 --> No URI present. Default controller set.
INFO - 2024-02-18 06:55:54 --> Router Class Initialized
INFO - 2024-02-18 06:55:54 --> Output Class Initialized
INFO - 2024-02-18 06:55:54 --> Security Class Initialized
DEBUG - 2024-02-18 06:55:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-18 06:55:54 --> Input Class Initialized
INFO - 2024-02-18 06:55:54 --> Language Class Initialized
INFO - 2024-02-18 06:55:54 --> Loader Class Initialized
INFO - 2024-02-18 06:55:54 --> Helper loaded: url_helper
INFO - 2024-02-18 06:55:54 --> Helper loaded: file_helper
INFO - 2024-02-18 06:55:54 --> Helper loaded: html_helper
INFO - 2024-02-18 06:55:54 --> Helper loaded: text_helper
INFO - 2024-02-18 06:55:54 --> Helper loaded: form_helper
INFO - 2024-02-18 06:55:54 --> Helper loaded: lang_helper
INFO - 2024-02-18 06:55:54 --> Helper loaded: security_helper
INFO - 2024-02-18 06:55:54 --> Helper loaded: cookie_helper
INFO - 2024-02-18 06:55:54 --> Database Driver Class Initialized
INFO - 2024-02-18 06:55:54 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-18 06:55:54 --> Parser Class Initialized
INFO - 2024-02-18 06:55:54 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-18 06:55:54 --> Pagination Class Initialized
INFO - 2024-02-18 06:55:54 --> Form Validation Class Initialized
INFO - 2024-02-18 06:55:54 --> Controller Class Initialized
INFO - 2024-02-18 06:55:54 --> Model Class Initialized
DEBUG - 2024-02-18 06:55:54 --> Session class already loaded. Second attempt ignored.
ERROR - 2024-02-18 07:01:45 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-18 07:01:45 --> Config Class Initialized
INFO - 2024-02-18 07:01:45 --> Hooks Class Initialized
DEBUG - 2024-02-18 07:01:45 --> UTF-8 Support Enabled
INFO - 2024-02-18 07:01:45 --> Utf8 Class Initialized
INFO - 2024-02-18 07:01:45 --> URI Class Initialized
DEBUG - 2024-02-18 07:01:45 --> No URI present. Default controller set.
INFO - 2024-02-18 07:01:45 --> Router Class Initialized
INFO - 2024-02-18 07:01:45 --> Output Class Initialized
INFO - 2024-02-18 07:01:45 --> Security Class Initialized
DEBUG - 2024-02-18 07:01:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-18 07:01:45 --> Input Class Initialized
INFO - 2024-02-18 07:01:45 --> Language Class Initialized
INFO - 2024-02-18 07:01:45 --> Loader Class Initialized
INFO - 2024-02-18 07:01:45 --> Helper loaded: url_helper
INFO - 2024-02-18 07:01:45 --> Helper loaded: file_helper
INFO - 2024-02-18 07:01:45 --> Helper loaded: html_helper
INFO - 2024-02-18 07:01:45 --> Helper loaded: text_helper
INFO - 2024-02-18 07:01:45 --> Helper loaded: form_helper
INFO - 2024-02-18 07:01:45 --> Helper loaded: lang_helper
INFO - 2024-02-18 07:01:45 --> Helper loaded: security_helper
INFO - 2024-02-18 07:01:45 --> Helper loaded: cookie_helper
INFO - 2024-02-18 07:01:45 --> Database Driver Class Initialized
INFO - 2024-02-18 07:01:45 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-18 07:01:45 --> Parser Class Initialized
INFO - 2024-02-18 07:01:45 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-18 07:01:45 --> Pagination Class Initialized
INFO - 2024-02-18 07:01:45 --> Form Validation Class Initialized
INFO - 2024-02-18 07:01:45 --> Controller Class Initialized
INFO - 2024-02-18 07:01:45 --> Model Class Initialized
DEBUG - 2024-02-18 07:01:45 --> Session class already loaded. Second attempt ignored.
ERROR - 2024-02-18 07:01:47 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-18 07:01:47 --> Config Class Initialized
INFO - 2024-02-18 07:01:47 --> Hooks Class Initialized
DEBUG - 2024-02-18 07:01:47 --> UTF-8 Support Enabled
INFO - 2024-02-18 07:01:47 --> Utf8 Class Initialized
INFO - 2024-02-18 07:01:47 --> URI Class Initialized
INFO - 2024-02-18 07:01:47 --> Router Class Initialized
INFO - 2024-02-18 07:01:47 --> Output Class Initialized
INFO - 2024-02-18 07:01:47 --> Security Class Initialized
DEBUG - 2024-02-18 07:01:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-18 07:01:47 --> Input Class Initialized
INFO - 2024-02-18 07:01:47 --> Language Class Initialized
INFO - 2024-02-18 07:01:47 --> Loader Class Initialized
INFO - 2024-02-18 07:01:47 --> Helper loaded: url_helper
INFO - 2024-02-18 07:01:47 --> Helper loaded: file_helper
INFO - 2024-02-18 07:01:47 --> Helper loaded: html_helper
INFO - 2024-02-18 07:01:47 --> Helper loaded: text_helper
INFO - 2024-02-18 07:01:47 --> Helper loaded: form_helper
INFO - 2024-02-18 07:01:47 --> Helper loaded: lang_helper
INFO - 2024-02-18 07:01:47 --> Helper loaded: security_helper
INFO - 2024-02-18 07:01:47 --> Helper loaded: cookie_helper
INFO - 2024-02-18 07:01:47 --> Database Driver Class Initialized
INFO - 2024-02-18 07:01:47 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-18 07:01:47 --> Parser Class Initialized
INFO - 2024-02-18 07:01:47 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-18 07:01:47 --> Pagination Class Initialized
INFO - 2024-02-18 07:01:47 --> Form Validation Class Initialized
INFO - 2024-02-18 07:01:47 --> Controller Class Initialized
INFO - 2024-02-18 07:01:47 --> Model Class Initialized
DEBUG - 2024-02-18 07:01:47 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-18 07:01:47 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2024-02-18 07:01:47 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-02-18 07:01:47 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-02-18 07:01:47 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-02-18 07:01:47 --> Model Class Initialized
INFO - 2024-02-18 07:01:47 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-02-18 07:01:47 --> Final output sent to browser
DEBUG - 2024-02-18 07:01:47 --> Total execution time: 0.0352
ERROR - 2024-02-18 07:02:49 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-18 07:02:49 --> Config Class Initialized
INFO - 2024-02-18 07:02:49 --> Hooks Class Initialized
DEBUG - 2024-02-18 07:02:49 --> UTF-8 Support Enabled
INFO - 2024-02-18 07:02:49 --> Utf8 Class Initialized
INFO - 2024-02-18 07:02:49 --> URI Class Initialized
INFO - 2024-02-18 07:02:49 --> Router Class Initialized
INFO - 2024-02-18 07:02:49 --> Output Class Initialized
INFO - 2024-02-18 07:02:49 --> Security Class Initialized
DEBUG - 2024-02-18 07:02:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-18 07:02:49 --> Input Class Initialized
INFO - 2024-02-18 07:02:49 --> Language Class Initialized
INFO - 2024-02-18 07:02:49 --> Loader Class Initialized
INFO - 2024-02-18 07:02:49 --> Helper loaded: url_helper
INFO - 2024-02-18 07:02:49 --> Helper loaded: file_helper
INFO - 2024-02-18 07:02:49 --> Helper loaded: html_helper
INFO - 2024-02-18 07:02:49 --> Helper loaded: text_helper
INFO - 2024-02-18 07:02:49 --> Helper loaded: form_helper
INFO - 2024-02-18 07:02:49 --> Helper loaded: lang_helper
INFO - 2024-02-18 07:02:49 --> Helper loaded: security_helper
INFO - 2024-02-18 07:02:49 --> Helper loaded: cookie_helper
INFO - 2024-02-18 07:02:49 --> Database Driver Class Initialized
INFO - 2024-02-18 07:02:49 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-18 07:02:49 --> Parser Class Initialized
INFO - 2024-02-18 07:02:49 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-18 07:02:49 --> Pagination Class Initialized
INFO - 2024-02-18 07:02:49 --> Form Validation Class Initialized
INFO - 2024-02-18 07:02:49 --> Controller Class Initialized
INFO - 2024-02-18 07:02:49 --> Model Class Initialized
DEBUG - 2024-02-18 07:02:49 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-18 07:02:49 --> Model Class Initialized
INFO - 2024-02-18 07:02:49 --> Final output sent to browser
DEBUG - 2024-02-18 07:02:49 --> Total execution time: 0.0197
ERROR - 2024-02-18 07:02:50 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-18 07:02:50 --> Config Class Initialized
INFO - 2024-02-18 07:02:50 --> Hooks Class Initialized
DEBUG - 2024-02-18 07:02:50 --> UTF-8 Support Enabled
INFO - 2024-02-18 07:02:50 --> Utf8 Class Initialized
INFO - 2024-02-18 07:02:50 --> URI Class Initialized
DEBUG - 2024-02-18 07:02:50 --> No URI present. Default controller set.
INFO - 2024-02-18 07:02:50 --> Router Class Initialized
INFO - 2024-02-18 07:02:50 --> Output Class Initialized
INFO - 2024-02-18 07:02:50 --> Security Class Initialized
DEBUG - 2024-02-18 07:02:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-18 07:02:50 --> Input Class Initialized
INFO - 2024-02-18 07:02:50 --> Language Class Initialized
INFO - 2024-02-18 07:02:50 --> Loader Class Initialized
INFO - 2024-02-18 07:02:50 --> Helper loaded: url_helper
INFO - 2024-02-18 07:02:50 --> Helper loaded: file_helper
INFO - 2024-02-18 07:02:50 --> Helper loaded: html_helper
INFO - 2024-02-18 07:02:50 --> Helper loaded: text_helper
INFO - 2024-02-18 07:02:50 --> Helper loaded: form_helper
INFO - 2024-02-18 07:02:50 --> Helper loaded: lang_helper
INFO - 2024-02-18 07:02:50 --> Helper loaded: security_helper
INFO - 2024-02-18 07:02:50 --> Helper loaded: cookie_helper
INFO - 2024-02-18 07:02:50 --> Database Driver Class Initialized
INFO - 2024-02-18 07:02:50 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-18 07:02:50 --> Parser Class Initialized
INFO - 2024-02-18 07:02:50 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-18 07:02:50 --> Pagination Class Initialized
INFO - 2024-02-18 07:02:50 --> Form Validation Class Initialized
INFO - 2024-02-18 07:02:50 --> Controller Class Initialized
INFO - 2024-02-18 07:02:50 --> Model Class Initialized
DEBUG - 2024-02-18 07:02:50 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-18 07:02:50 --> Model Class Initialized
DEBUG - 2024-02-18 07:02:50 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-18 07:02:50 --> Model Class Initialized
INFO - 2024-02-18 07:02:50 --> Model Class Initialized
INFO - 2024-02-18 07:02:50 --> Model Class Initialized
INFO - 2024-02-18 07:02:50 --> Model Class Initialized
DEBUG - 2024-02-18 07:02:50 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-18 07:02:50 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-18 07:02:50 --> Model Class Initialized
INFO - 2024-02-18 07:02:50 --> Model Class Initialized
INFO - 2024-02-18 07:02:50 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2024-02-18 07:02:50 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-02-18 07:02:50 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-02-18 07:02:50 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-02-18 07:02:50 --> Model Class Initialized
INFO - 2024-02-18 07:02:50 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-02-18 07:02:50 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-02-18 07:02:50 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-02-18 07:02:50 --> Final output sent to browser
DEBUG - 2024-02-18 07:02:50 --> Total execution time: 0.2408
ERROR - 2024-02-18 07:03:00 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-18 07:03:00 --> Config Class Initialized
INFO - 2024-02-18 07:03:00 --> Hooks Class Initialized
DEBUG - 2024-02-18 07:03:00 --> UTF-8 Support Enabled
INFO - 2024-02-18 07:03:00 --> Utf8 Class Initialized
INFO - 2024-02-18 07:03:00 --> URI Class Initialized
DEBUG - 2024-02-18 07:03:00 --> No URI present. Default controller set.
INFO - 2024-02-18 07:03:00 --> Router Class Initialized
INFO - 2024-02-18 07:03:00 --> Output Class Initialized
INFO - 2024-02-18 07:03:00 --> Security Class Initialized
DEBUG - 2024-02-18 07:03:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-18 07:03:00 --> Input Class Initialized
INFO - 2024-02-18 07:03:00 --> Language Class Initialized
INFO - 2024-02-18 07:03:00 --> Loader Class Initialized
INFO - 2024-02-18 07:03:00 --> Helper loaded: url_helper
INFO - 2024-02-18 07:03:00 --> Helper loaded: file_helper
INFO - 2024-02-18 07:03:00 --> Helper loaded: html_helper
INFO - 2024-02-18 07:03:00 --> Helper loaded: text_helper
INFO - 2024-02-18 07:03:00 --> Helper loaded: form_helper
INFO - 2024-02-18 07:03:00 --> Helper loaded: lang_helper
INFO - 2024-02-18 07:03:00 --> Helper loaded: security_helper
INFO - 2024-02-18 07:03:00 --> Helper loaded: cookie_helper
INFO - 2024-02-18 07:03:00 --> Database Driver Class Initialized
INFO - 2024-02-18 07:03:00 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-18 07:03:00 --> Parser Class Initialized
INFO - 2024-02-18 07:03:00 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-18 07:03:00 --> Pagination Class Initialized
INFO - 2024-02-18 07:03:00 --> Form Validation Class Initialized
INFO - 2024-02-18 07:03:00 --> Controller Class Initialized
INFO - 2024-02-18 07:03:00 --> Model Class Initialized
DEBUG - 2024-02-18 07:03:00 --> Session class already loaded. Second attempt ignored.
ERROR - 2024-02-18 07:03:04 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-18 07:03:04 --> Config Class Initialized
INFO - 2024-02-18 07:03:04 --> Hooks Class Initialized
DEBUG - 2024-02-18 07:03:04 --> UTF-8 Support Enabled
INFO - 2024-02-18 07:03:04 --> Utf8 Class Initialized
INFO - 2024-02-18 07:03:04 --> URI Class Initialized
INFO - 2024-02-18 07:03:04 --> Router Class Initialized
INFO - 2024-02-18 07:03:04 --> Output Class Initialized
INFO - 2024-02-18 07:03:04 --> Security Class Initialized
DEBUG - 2024-02-18 07:03:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-18 07:03:04 --> Input Class Initialized
INFO - 2024-02-18 07:03:04 --> Language Class Initialized
INFO - 2024-02-18 07:03:04 --> Loader Class Initialized
INFO - 2024-02-18 07:03:04 --> Helper loaded: url_helper
INFO - 2024-02-18 07:03:04 --> Helper loaded: file_helper
INFO - 2024-02-18 07:03:04 --> Helper loaded: html_helper
INFO - 2024-02-18 07:03:04 --> Helper loaded: text_helper
INFO - 2024-02-18 07:03:04 --> Helper loaded: form_helper
INFO - 2024-02-18 07:03:04 --> Helper loaded: lang_helper
INFO - 2024-02-18 07:03:04 --> Helper loaded: security_helper
INFO - 2024-02-18 07:03:04 --> Helper loaded: cookie_helper
INFO - 2024-02-18 07:03:04 --> Database Driver Class Initialized
INFO - 2024-02-18 07:03:04 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-18 07:03:04 --> Parser Class Initialized
INFO - 2024-02-18 07:03:04 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-18 07:03:04 --> Pagination Class Initialized
INFO - 2024-02-18 07:03:04 --> Form Validation Class Initialized
INFO - 2024-02-18 07:03:04 --> Controller Class Initialized
INFO - 2024-02-18 07:03:04 --> Model Class Initialized
DEBUG - 2024-02-18 07:03:04 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-18 07:03:04 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-18 07:03:04 --> Model Class Initialized
DEBUG - 2024-02-18 07:03:04 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-18 07:03:04 --> Model Class Initialized
INFO - 2024-02-18 07:03:04 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice.php
DEBUG - 2024-02-18 07:03:04 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-02-18 07:03:04 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-02-18 07:03:04 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-02-18 07:03:04 --> Model Class Initialized
INFO - 2024-02-18 07:03:04 --> Model Class Initialized
INFO - 2024-02-18 07:03:04 --> Model Class Initialized
INFO - 2024-02-18 07:03:04 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-02-18 07:03:04 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-02-18 07:03:04 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-02-18 07:03:04 --> Final output sent to browser
DEBUG - 2024-02-18 07:03:04 --> Total execution time: 0.1411
ERROR - 2024-02-18 07:03:05 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-18 07:03:05 --> Config Class Initialized
INFO - 2024-02-18 07:03:05 --> Hooks Class Initialized
DEBUG - 2024-02-18 07:03:05 --> UTF-8 Support Enabled
INFO - 2024-02-18 07:03:05 --> Utf8 Class Initialized
INFO - 2024-02-18 07:03:05 --> URI Class Initialized
INFO - 2024-02-18 07:03:05 --> Router Class Initialized
INFO - 2024-02-18 07:03:05 --> Output Class Initialized
INFO - 2024-02-18 07:03:05 --> Security Class Initialized
DEBUG - 2024-02-18 07:03:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-18 07:03:05 --> Input Class Initialized
INFO - 2024-02-18 07:03:05 --> Language Class Initialized
INFO - 2024-02-18 07:03:05 --> Loader Class Initialized
INFO - 2024-02-18 07:03:05 --> Helper loaded: url_helper
INFO - 2024-02-18 07:03:05 --> Helper loaded: file_helper
INFO - 2024-02-18 07:03:05 --> Helper loaded: html_helper
INFO - 2024-02-18 07:03:05 --> Helper loaded: text_helper
INFO - 2024-02-18 07:03:05 --> Helper loaded: form_helper
INFO - 2024-02-18 07:03:05 --> Helper loaded: lang_helper
INFO - 2024-02-18 07:03:05 --> Helper loaded: security_helper
INFO - 2024-02-18 07:03:05 --> Helper loaded: cookie_helper
INFO - 2024-02-18 07:03:05 --> Database Driver Class Initialized
INFO - 2024-02-18 07:03:05 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-18 07:03:05 --> Parser Class Initialized
INFO - 2024-02-18 07:03:05 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-18 07:03:05 --> Pagination Class Initialized
INFO - 2024-02-18 07:03:05 --> Form Validation Class Initialized
INFO - 2024-02-18 07:03:05 --> Controller Class Initialized
INFO - 2024-02-18 07:03:05 --> Model Class Initialized
DEBUG - 2024-02-18 07:03:05 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-18 07:03:05 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-18 07:03:05 --> Model Class Initialized
DEBUG - 2024-02-18 07:03:05 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-18 07:03:05 --> Model Class Initialized
INFO - 2024-02-18 07:03:05 --> Final output sent to browser
DEBUG - 2024-02-18 07:03:05 --> Total execution time: 0.0374
ERROR - 2024-02-18 07:03:19 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-18 07:03:19 --> Config Class Initialized
INFO - 2024-02-18 07:03:19 --> Hooks Class Initialized
DEBUG - 2024-02-18 07:03:19 --> UTF-8 Support Enabled
INFO - 2024-02-18 07:03:19 --> Utf8 Class Initialized
INFO - 2024-02-18 07:03:19 --> URI Class Initialized
INFO - 2024-02-18 07:03:19 --> Router Class Initialized
INFO - 2024-02-18 07:03:19 --> Output Class Initialized
INFO - 2024-02-18 07:03:19 --> Security Class Initialized
DEBUG - 2024-02-18 07:03:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-18 07:03:19 --> Input Class Initialized
INFO - 2024-02-18 07:03:19 --> Language Class Initialized
INFO - 2024-02-18 07:03:19 --> Loader Class Initialized
INFO - 2024-02-18 07:03:19 --> Helper loaded: url_helper
INFO - 2024-02-18 07:03:19 --> Helper loaded: file_helper
INFO - 2024-02-18 07:03:19 --> Helper loaded: html_helper
INFO - 2024-02-18 07:03:19 --> Helper loaded: text_helper
INFO - 2024-02-18 07:03:19 --> Helper loaded: form_helper
INFO - 2024-02-18 07:03:19 --> Helper loaded: lang_helper
INFO - 2024-02-18 07:03:19 --> Helper loaded: security_helper
INFO - 2024-02-18 07:03:19 --> Helper loaded: cookie_helper
INFO - 2024-02-18 07:03:19 --> Database Driver Class Initialized
INFO - 2024-02-18 07:03:19 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-18 07:03:19 --> Parser Class Initialized
INFO - 2024-02-18 07:03:19 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-18 07:03:19 --> Pagination Class Initialized
INFO - 2024-02-18 07:03:19 --> Form Validation Class Initialized
INFO - 2024-02-18 07:03:19 --> Controller Class Initialized
INFO - 2024-02-18 07:03:19 --> Model Class Initialized
DEBUG - 2024-02-18 07:03:19 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-18 07:03:19 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-18 07:03:19 --> Model Class Initialized
DEBUG - 2024-02-18 07:03:19 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-18 07:03:19 --> Model Class Initialized
DEBUG - 2024-02-18 07:03:19 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-18 07:03:19 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice_html.php
DEBUG - 2024-02-18 07:03:19 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-02-18 07:03:19 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-02-18 07:03:19 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-02-18 07:03:19 --> Model Class Initialized
INFO - 2024-02-18 07:03:19 --> Model Class Initialized
INFO - 2024-02-18 07:03:19 --> Model Class Initialized
INFO - 2024-02-18 07:03:19 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-02-18 07:03:19 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-02-18 07:03:19 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-02-18 07:03:19 --> Final output sent to browser
DEBUG - 2024-02-18 07:03:19 --> Total execution time: 0.1486
ERROR - 2024-02-18 07:03:31 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-18 07:03:31 --> Config Class Initialized
INFO - 2024-02-18 07:03:31 --> Hooks Class Initialized
DEBUG - 2024-02-18 07:03:31 --> UTF-8 Support Enabled
INFO - 2024-02-18 07:03:31 --> Utf8 Class Initialized
INFO - 2024-02-18 07:03:31 --> URI Class Initialized
INFO - 2024-02-18 07:03:31 --> Router Class Initialized
INFO - 2024-02-18 07:03:31 --> Output Class Initialized
INFO - 2024-02-18 07:03:31 --> Security Class Initialized
DEBUG - 2024-02-18 07:03:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-18 07:03:31 --> Input Class Initialized
INFO - 2024-02-18 07:03:31 --> Language Class Initialized
INFO - 2024-02-18 07:03:31 --> Loader Class Initialized
INFO - 2024-02-18 07:03:31 --> Helper loaded: url_helper
INFO - 2024-02-18 07:03:31 --> Helper loaded: file_helper
INFO - 2024-02-18 07:03:31 --> Helper loaded: html_helper
INFO - 2024-02-18 07:03:31 --> Helper loaded: text_helper
INFO - 2024-02-18 07:03:31 --> Helper loaded: form_helper
INFO - 2024-02-18 07:03:31 --> Helper loaded: lang_helper
INFO - 2024-02-18 07:03:31 --> Helper loaded: security_helper
INFO - 2024-02-18 07:03:31 --> Helper loaded: cookie_helper
INFO - 2024-02-18 07:03:31 --> Database Driver Class Initialized
INFO - 2024-02-18 07:03:31 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-18 07:03:31 --> Parser Class Initialized
INFO - 2024-02-18 07:03:31 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-18 07:03:31 --> Pagination Class Initialized
INFO - 2024-02-18 07:03:31 --> Form Validation Class Initialized
INFO - 2024-02-18 07:03:31 --> Controller Class Initialized
INFO - 2024-02-18 07:03:31 --> Model Class Initialized
DEBUG - 2024-02-18 07:03:31 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-18 07:03:31 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-18 07:03:31 --> Model Class Initialized
DEBUG - 2024-02-18 07:03:31 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-18 07:03:31 --> Model Class Initialized
INFO - 2024-02-18 07:03:31 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice.php
DEBUG - 2024-02-18 07:03:31 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-02-18 07:03:31 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-02-18 07:03:31 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-02-18 07:03:31 --> Model Class Initialized
INFO - 2024-02-18 07:03:31 --> Model Class Initialized
INFO - 2024-02-18 07:03:31 --> Model Class Initialized
INFO - 2024-02-18 07:03:31 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-02-18 07:03:31 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-02-18 07:03:31 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-02-18 07:03:31 --> Final output sent to browser
DEBUG - 2024-02-18 07:03:31 --> Total execution time: 0.1458
ERROR - 2024-02-18 07:03:32 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-18 07:03:32 --> Config Class Initialized
INFO - 2024-02-18 07:03:32 --> Hooks Class Initialized
DEBUG - 2024-02-18 07:03:32 --> UTF-8 Support Enabled
INFO - 2024-02-18 07:03:32 --> Utf8 Class Initialized
INFO - 2024-02-18 07:03:32 --> URI Class Initialized
INFO - 2024-02-18 07:03:32 --> Router Class Initialized
INFO - 2024-02-18 07:03:32 --> Output Class Initialized
INFO - 2024-02-18 07:03:32 --> Security Class Initialized
DEBUG - 2024-02-18 07:03:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-18 07:03:32 --> Input Class Initialized
INFO - 2024-02-18 07:03:32 --> Language Class Initialized
INFO - 2024-02-18 07:03:32 --> Loader Class Initialized
INFO - 2024-02-18 07:03:32 --> Helper loaded: url_helper
INFO - 2024-02-18 07:03:32 --> Helper loaded: file_helper
INFO - 2024-02-18 07:03:32 --> Helper loaded: html_helper
INFO - 2024-02-18 07:03:32 --> Helper loaded: text_helper
INFO - 2024-02-18 07:03:32 --> Helper loaded: form_helper
INFO - 2024-02-18 07:03:32 --> Helper loaded: lang_helper
INFO - 2024-02-18 07:03:32 --> Helper loaded: security_helper
INFO - 2024-02-18 07:03:32 --> Helper loaded: cookie_helper
INFO - 2024-02-18 07:03:32 --> Database Driver Class Initialized
INFO - 2024-02-18 07:03:32 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-18 07:03:32 --> Parser Class Initialized
INFO - 2024-02-18 07:03:32 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-18 07:03:32 --> Pagination Class Initialized
INFO - 2024-02-18 07:03:32 --> Form Validation Class Initialized
INFO - 2024-02-18 07:03:32 --> Controller Class Initialized
INFO - 2024-02-18 07:03:32 --> Model Class Initialized
DEBUG - 2024-02-18 07:03:32 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-18 07:03:32 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-18 07:03:32 --> Model Class Initialized
DEBUG - 2024-02-18 07:03:32 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-18 07:03:32 --> Model Class Initialized
INFO - 2024-02-18 07:03:32 --> Final output sent to browser
DEBUG - 2024-02-18 07:03:32 --> Total execution time: 0.0385
ERROR - 2024-02-18 07:04:00 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-18 07:04:00 --> Config Class Initialized
INFO - 2024-02-18 07:04:00 --> Hooks Class Initialized
DEBUG - 2024-02-18 07:04:00 --> UTF-8 Support Enabled
INFO - 2024-02-18 07:04:00 --> Utf8 Class Initialized
INFO - 2024-02-18 07:04:00 --> URI Class Initialized
DEBUG - 2024-02-18 07:04:00 --> No URI present. Default controller set.
INFO - 2024-02-18 07:04:00 --> Router Class Initialized
INFO - 2024-02-18 07:04:00 --> Output Class Initialized
INFO - 2024-02-18 07:04:00 --> Security Class Initialized
DEBUG - 2024-02-18 07:04:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-18 07:04:00 --> Input Class Initialized
INFO - 2024-02-18 07:04:00 --> Language Class Initialized
INFO - 2024-02-18 07:04:00 --> Loader Class Initialized
INFO - 2024-02-18 07:04:00 --> Helper loaded: url_helper
INFO - 2024-02-18 07:04:00 --> Helper loaded: file_helper
INFO - 2024-02-18 07:04:00 --> Helper loaded: html_helper
INFO - 2024-02-18 07:04:00 --> Helper loaded: text_helper
INFO - 2024-02-18 07:04:00 --> Helper loaded: form_helper
INFO - 2024-02-18 07:04:00 --> Helper loaded: lang_helper
INFO - 2024-02-18 07:04:00 --> Helper loaded: security_helper
INFO - 2024-02-18 07:04:00 --> Helper loaded: cookie_helper
INFO - 2024-02-18 07:04:00 --> Database Driver Class Initialized
INFO - 2024-02-18 07:04:00 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-18 07:04:00 --> Parser Class Initialized
INFO - 2024-02-18 07:04:00 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-18 07:04:00 --> Pagination Class Initialized
INFO - 2024-02-18 07:04:00 --> Form Validation Class Initialized
INFO - 2024-02-18 07:04:00 --> Controller Class Initialized
INFO - 2024-02-18 07:04:00 --> Model Class Initialized
DEBUG - 2024-02-18 07:04:00 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-18 07:04:00 --> Model Class Initialized
DEBUG - 2024-02-18 07:04:00 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-18 07:04:00 --> Model Class Initialized
INFO - 2024-02-18 07:04:00 --> Model Class Initialized
INFO - 2024-02-18 07:04:00 --> Model Class Initialized
INFO - 2024-02-18 07:04:00 --> Model Class Initialized
DEBUG - 2024-02-18 07:04:00 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-18 07:04:00 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-18 07:04:00 --> Model Class Initialized
INFO - 2024-02-18 07:04:00 --> Model Class Initialized
INFO - 2024-02-18 07:04:00 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2024-02-18 07:04:00 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-02-18 07:04:00 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-02-18 07:04:00 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-02-18 07:04:00 --> Model Class Initialized
INFO - 2024-02-18 07:04:00 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-02-18 07:04:00 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-02-18 07:04:00 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-02-18 07:04:00 --> Final output sent to browser
DEBUG - 2024-02-18 07:04:00 --> Total execution time: 0.2384
ERROR - 2024-02-18 07:04:19 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-18 07:04:19 --> Config Class Initialized
INFO - 2024-02-18 07:04:19 --> Hooks Class Initialized
DEBUG - 2024-02-18 07:04:19 --> UTF-8 Support Enabled
INFO - 2024-02-18 07:04:19 --> Utf8 Class Initialized
INFO - 2024-02-18 07:04:19 --> URI Class Initialized
INFO - 2024-02-18 07:04:19 --> Router Class Initialized
INFO - 2024-02-18 07:04:19 --> Output Class Initialized
INFO - 2024-02-18 07:04:19 --> Security Class Initialized
DEBUG - 2024-02-18 07:04:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-18 07:04:19 --> Input Class Initialized
INFO - 2024-02-18 07:04:19 --> Language Class Initialized
INFO - 2024-02-18 07:04:19 --> Loader Class Initialized
INFO - 2024-02-18 07:04:19 --> Helper loaded: url_helper
INFO - 2024-02-18 07:04:19 --> Helper loaded: file_helper
INFO - 2024-02-18 07:04:19 --> Helper loaded: html_helper
INFO - 2024-02-18 07:04:19 --> Helper loaded: text_helper
INFO - 2024-02-18 07:04:19 --> Helper loaded: form_helper
INFO - 2024-02-18 07:04:19 --> Helper loaded: lang_helper
INFO - 2024-02-18 07:04:19 --> Helper loaded: security_helper
INFO - 2024-02-18 07:04:19 --> Helper loaded: cookie_helper
INFO - 2024-02-18 07:04:19 --> Database Driver Class Initialized
INFO - 2024-02-18 07:04:19 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-18 07:04:19 --> Parser Class Initialized
INFO - 2024-02-18 07:04:19 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-18 07:04:19 --> Pagination Class Initialized
INFO - 2024-02-18 07:04:19 --> Form Validation Class Initialized
INFO - 2024-02-18 07:04:19 --> Controller Class Initialized
INFO - 2024-02-18 07:04:19 --> Model Class Initialized
DEBUG - 2024-02-18 07:04:19 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-18 07:04:19 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-18 07:04:19 --> Model Class Initialized
INFO - 2024-02-18 07:04:19 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/stockrequest/upcoming.php
DEBUG - 2024-02-18 07:04:19 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-02-18 07:04:19 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-02-18 07:04:19 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-02-18 07:04:19 --> Model Class Initialized
INFO - 2024-02-18 07:04:19 --> Model Class Initialized
INFO - 2024-02-18 07:04:19 --> Model Class Initialized
INFO - 2024-02-18 07:04:19 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-02-18 07:04:19 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-02-18 07:04:19 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-02-18 07:04:19 --> Final output sent to browser
DEBUG - 2024-02-18 07:04:19 --> Total execution time: 0.1581
ERROR - 2024-02-18 07:04:20 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-18 07:04:20 --> Config Class Initialized
INFO - 2024-02-18 07:04:20 --> Hooks Class Initialized
DEBUG - 2024-02-18 07:04:20 --> UTF-8 Support Enabled
INFO - 2024-02-18 07:04:20 --> Utf8 Class Initialized
INFO - 2024-02-18 07:04:20 --> URI Class Initialized
INFO - 2024-02-18 07:04:20 --> Router Class Initialized
INFO - 2024-02-18 07:04:20 --> Output Class Initialized
INFO - 2024-02-18 07:04:20 --> Security Class Initialized
DEBUG - 2024-02-18 07:04:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-18 07:04:20 --> Input Class Initialized
INFO - 2024-02-18 07:04:20 --> Language Class Initialized
INFO - 2024-02-18 07:04:20 --> Loader Class Initialized
INFO - 2024-02-18 07:04:20 --> Helper loaded: url_helper
INFO - 2024-02-18 07:04:20 --> Helper loaded: file_helper
INFO - 2024-02-18 07:04:20 --> Helper loaded: html_helper
INFO - 2024-02-18 07:04:20 --> Helper loaded: text_helper
INFO - 2024-02-18 07:04:20 --> Helper loaded: form_helper
INFO - 2024-02-18 07:04:20 --> Helper loaded: lang_helper
INFO - 2024-02-18 07:04:20 --> Helper loaded: security_helper
INFO - 2024-02-18 07:04:20 --> Helper loaded: cookie_helper
INFO - 2024-02-18 07:04:20 --> Database Driver Class Initialized
INFO - 2024-02-18 07:04:20 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-18 07:04:20 --> Parser Class Initialized
INFO - 2024-02-18 07:04:20 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-18 07:04:20 --> Pagination Class Initialized
INFO - 2024-02-18 07:04:20 --> Form Validation Class Initialized
INFO - 2024-02-18 07:04:20 --> Controller Class Initialized
INFO - 2024-02-18 07:04:20 --> Model Class Initialized
DEBUG - 2024-02-18 07:04:20 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-18 07:04:20 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-18 07:04:20 --> Model Class Initialized
INFO - 2024-02-18 07:04:20 --> Final output sent to browser
DEBUG - 2024-02-18 07:04:20 --> Total execution time: 0.0184
ERROR - 2024-02-18 07:04:26 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-18 07:04:26 --> Config Class Initialized
INFO - 2024-02-18 07:04:26 --> Hooks Class Initialized
DEBUG - 2024-02-18 07:04:26 --> UTF-8 Support Enabled
INFO - 2024-02-18 07:04:26 --> Utf8 Class Initialized
INFO - 2024-02-18 07:04:26 --> URI Class Initialized
INFO - 2024-02-18 07:04:26 --> Router Class Initialized
INFO - 2024-02-18 07:04:26 --> Output Class Initialized
INFO - 2024-02-18 07:04:26 --> Security Class Initialized
DEBUG - 2024-02-18 07:04:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-18 07:04:26 --> Input Class Initialized
INFO - 2024-02-18 07:04:26 --> Language Class Initialized
INFO - 2024-02-18 07:04:26 --> Loader Class Initialized
INFO - 2024-02-18 07:04:26 --> Helper loaded: url_helper
INFO - 2024-02-18 07:04:26 --> Helper loaded: file_helper
INFO - 2024-02-18 07:04:26 --> Helper loaded: html_helper
INFO - 2024-02-18 07:04:26 --> Helper loaded: text_helper
INFO - 2024-02-18 07:04:26 --> Helper loaded: form_helper
INFO - 2024-02-18 07:04:26 --> Helper loaded: lang_helper
INFO - 2024-02-18 07:04:26 --> Helper loaded: security_helper
INFO - 2024-02-18 07:04:26 --> Helper loaded: cookie_helper
INFO - 2024-02-18 07:04:26 --> Database Driver Class Initialized
INFO - 2024-02-18 07:04:26 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-18 07:04:26 --> Parser Class Initialized
INFO - 2024-02-18 07:04:26 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-18 07:04:26 --> Pagination Class Initialized
INFO - 2024-02-18 07:04:26 --> Form Validation Class Initialized
INFO - 2024-02-18 07:04:26 --> Controller Class Initialized
INFO - 2024-02-18 07:04:26 --> Model Class Initialized
DEBUG - 2024-02-18 07:04:26 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-18 07:04:26 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-18 07:04:26 --> Model Class Initialized
INFO - 2024-02-18 07:04:26 --> Final output sent to browser
DEBUG - 2024-02-18 07:04:26 --> Total execution time: 0.0182
ERROR - 2024-02-18 07:04:28 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-18 07:04:28 --> Config Class Initialized
INFO - 2024-02-18 07:04:28 --> Hooks Class Initialized
DEBUG - 2024-02-18 07:04:28 --> UTF-8 Support Enabled
INFO - 2024-02-18 07:04:28 --> Utf8 Class Initialized
INFO - 2024-02-18 07:04:28 --> URI Class Initialized
INFO - 2024-02-18 07:04:28 --> Router Class Initialized
INFO - 2024-02-18 07:04:28 --> Output Class Initialized
INFO - 2024-02-18 07:04:28 --> Security Class Initialized
DEBUG - 2024-02-18 07:04:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-18 07:04:28 --> Input Class Initialized
INFO - 2024-02-18 07:04:28 --> Language Class Initialized
INFO - 2024-02-18 07:04:28 --> Loader Class Initialized
INFO - 2024-02-18 07:04:28 --> Helper loaded: url_helper
INFO - 2024-02-18 07:04:28 --> Helper loaded: file_helper
INFO - 2024-02-18 07:04:28 --> Helper loaded: html_helper
INFO - 2024-02-18 07:04:28 --> Helper loaded: text_helper
INFO - 2024-02-18 07:04:28 --> Helper loaded: form_helper
INFO - 2024-02-18 07:04:28 --> Helper loaded: lang_helper
INFO - 2024-02-18 07:04:28 --> Helper loaded: security_helper
INFO - 2024-02-18 07:04:28 --> Helper loaded: cookie_helper
INFO - 2024-02-18 07:04:28 --> Database Driver Class Initialized
INFO - 2024-02-18 07:04:28 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-18 07:04:28 --> Parser Class Initialized
INFO - 2024-02-18 07:04:28 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-18 07:04:28 --> Pagination Class Initialized
INFO - 2024-02-18 07:04:28 --> Form Validation Class Initialized
INFO - 2024-02-18 07:04:28 --> Controller Class Initialized
INFO - 2024-02-18 07:04:28 --> Model Class Initialized
DEBUG - 2024-02-18 07:04:28 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-18 07:04:28 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-18 07:04:28 --> Model Class Initialized
INFO - 2024-02-18 07:04:28 --> Final output sent to browser
DEBUG - 2024-02-18 07:04:28 --> Total execution time: 0.0176
ERROR - 2024-02-18 07:04:37 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-18 07:04:37 --> Config Class Initialized
INFO - 2024-02-18 07:04:37 --> Hooks Class Initialized
DEBUG - 2024-02-18 07:04:37 --> UTF-8 Support Enabled
INFO - 2024-02-18 07:04:37 --> Utf8 Class Initialized
INFO - 2024-02-18 07:04:37 --> URI Class Initialized
DEBUG - 2024-02-18 07:04:37 --> No URI present. Default controller set.
INFO - 2024-02-18 07:04:37 --> Router Class Initialized
INFO - 2024-02-18 07:04:37 --> Output Class Initialized
INFO - 2024-02-18 07:04:37 --> Security Class Initialized
DEBUG - 2024-02-18 07:04:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-18 07:04:37 --> Input Class Initialized
INFO - 2024-02-18 07:04:37 --> Language Class Initialized
INFO - 2024-02-18 07:04:37 --> Loader Class Initialized
INFO - 2024-02-18 07:04:37 --> Helper loaded: url_helper
INFO - 2024-02-18 07:04:37 --> Helper loaded: file_helper
INFO - 2024-02-18 07:04:37 --> Helper loaded: html_helper
INFO - 2024-02-18 07:04:37 --> Helper loaded: text_helper
INFO - 2024-02-18 07:04:37 --> Helper loaded: form_helper
INFO - 2024-02-18 07:04:37 --> Helper loaded: lang_helper
INFO - 2024-02-18 07:04:37 --> Helper loaded: security_helper
INFO - 2024-02-18 07:04:37 --> Helper loaded: cookie_helper
INFO - 2024-02-18 07:04:37 --> Database Driver Class Initialized
INFO - 2024-02-18 07:04:37 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-18 07:04:37 --> Parser Class Initialized
INFO - 2024-02-18 07:04:37 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-18 07:04:37 --> Pagination Class Initialized
INFO - 2024-02-18 07:04:37 --> Form Validation Class Initialized
INFO - 2024-02-18 07:04:37 --> Controller Class Initialized
INFO - 2024-02-18 07:04:37 --> Model Class Initialized
DEBUG - 2024-02-18 07:04:37 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-18 07:04:37 --> Model Class Initialized
DEBUG - 2024-02-18 07:04:37 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-18 07:04:37 --> Model Class Initialized
INFO - 2024-02-18 07:04:37 --> Model Class Initialized
INFO - 2024-02-18 07:04:37 --> Model Class Initialized
INFO - 2024-02-18 07:04:37 --> Model Class Initialized
DEBUG - 2024-02-18 07:04:37 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-18 07:04:37 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-18 07:04:37 --> Model Class Initialized
INFO - 2024-02-18 07:04:37 --> Model Class Initialized
INFO - 2024-02-18 07:04:37 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2024-02-18 07:04:37 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-02-18 07:04:37 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-02-18 07:04:37 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-02-18 07:04:37 --> Model Class Initialized
INFO - 2024-02-18 07:04:37 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-02-18 07:04:37 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-02-18 07:04:37 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-02-18 07:04:37 --> Final output sent to browser
DEBUG - 2024-02-18 07:04:37 --> Total execution time: 0.2342
ERROR - 2024-02-18 07:04:45 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-18 07:04:45 --> Config Class Initialized
INFO - 2024-02-18 07:04:45 --> Hooks Class Initialized
DEBUG - 2024-02-18 07:04:45 --> UTF-8 Support Enabled
INFO - 2024-02-18 07:04:45 --> Utf8 Class Initialized
INFO - 2024-02-18 07:04:45 --> URI Class Initialized
INFO - 2024-02-18 07:04:45 --> Router Class Initialized
INFO - 2024-02-18 07:04:45 --> Output Class Initialized
INFO - 2024-02-18 07:04:45 --> Security Class Initialized
DEBUG - 2024-02-18 07:04:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-18 07:04:45 --> Input Class Initialized
INFO - 2024-02-18 07:04:45 --> Language Class Initialized
INFO - 2024-02-18 07:04:45 --> Loader Class Initialized
INFO - 2024-02-18 07:04:45 --> Helper loaded: url_helper
INFO - 2024-02-18 07:04:45 --> Helper loaded: file_helper
INFO - 2024-02-18 07:04:45 --> Helper loaded: html_helper
INFO - 2024-02-18 07:04:45 --> Helper loaded: text_helper
INFO - 2024-02-18 07:04:45 --> Helper loaded: form_helper
INFO - 2024-02-18 07:04:45 --> Helper loaded: lang_helper
INFO - 2024-02-18 07:04:45 --> Helper loaded: security_helper
INFO - 2024-02-18 07:04:45 --> Helper loaded: cookie_helper
INFO - 2024-02-18 07:04:45 --> Database Driver Class Initialized
INFO - 2024-02-18 07:04:45 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-18 07:04:45 --> Parser Class Initialized
INFO - 2024-02-18 07:04:45 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-18 07:04:45 --> Pagination Class Initialized
INFO - 2024-02-18 07:04:45 --> Form Validation Class Initialized
INFO - 2024-02-18 07:04:45 --> Controller Class Initialized
INFO - 2024-02-18 07:04:45 --> Model Class Initialized
DEBUG - 2024-02-18 07:04:45 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-18 07:04:45 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-18 07:04:45 --> Model Class Initialized
INFO - 2024-02-18 07:04:45 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/stockrequest/inventory.php
DEBUG - 2024-02-18 07:04:45 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-02-18 07:04:45 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-02-18 07:04:45 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-02-18 07:04:45 --> Model Class Initialized
INFO - 2024-02-18 07:04:45 --> Model Class Initialized
INFO - 2024-02-18 07:04:45 --> Model Class Initialized
INFO - 2024-02-18 07:04:45 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-02-18 07:04:45 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-02-18 07:04:45 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-02-18 07:04:45 --> Final output sent to browser
DEBUG - 2024-02-18 07:04:45 --> Total execution time: 0.1424
ERROR - 2024-02-18 07:04:46 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-18 07:04:46 --> Config Class Initialized
INFO - 2024-02-18 07:04:46 --> Hooks Class Initialized
DEBUG - 2024-02-18 07:04:46 --> UTF-8 Support Enabled
INFO - 2024-02-18 07:04:46 --> Utf8 Class Initialized
INFO - 2024-02-18 07:04:46 --> URI Class Initialized
INFO - 2024-02-18 07:04:46 --> Router Class Initialized
INFO - 2024-02-18 07:04:46 --> Output Class Initialized
INFO - 2024-02-18 07:04:46 --> Security Class Initialized
DEBUG - 2024-02-18 07:04:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-18 07:04:46 --> Input Class Initialized
INFO - 2024-02-18 07:04:46 --> Language Class Initialized
INFO - 2024-02-18 07:04:46 --> Loader Class Initialized
INFO - 2024-02-18 07:04:46 --> Helper loaded: url_helper
INFO - 2024-02-18 07:04:46 --> Helper loaded: file_helper
INFO - 2024-02-18 07:04:46 --> Helper loaded: html_helper
INFO - 2024-02-18 07:04:46 --> Helper loaded: text_helper
INFO - 2024-02-18 07:04:46 --> Helper loaded: form_helper
INFO - 2024-02-18 07:04:46 --> Helper loaded: lang_helper
INFO - 2024-02-18 07:04:46 --> Helper loaded: security_helper
INFO - 2024-02-18 07:04:46 --> Helper loaded: cookie_helper
INFO - 2024-02-18 07:04:46 --> Database Driver Class Initialized
INFO - 2024-02-18 07:04:46 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-18 07:04:46 --> Parser Class Initialized
INFO - 2024-02-18 07:04:46 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-18 07:04:46 --> Pagination Class Initialized
INFO - 2024-02-18 07:04:46 --> Form Validation Class Initialized
INFO - 2024-02-18 07:04:46 --> Controller Class Initialized
INFO - 2024-02-18 07:04:46 --> Model Class Initialized
DEBUG - 2024-02-18 07:04:46 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-18 07:04:46 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-18 07:04:46 --> Model Class Initialized
INFO - 2024-02-18 07:04:46 --> Final output sent to browser
DEBUG - 2024-02-18 07:04:46 --> Total execution time: 0.0561
ERROR - 2024-02-18 07:05:16 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-18 07:05:16 --> Config Class Initialized
INFO - 2024-02-18 07:05:16 --> Hooks Class Initialized
DEBUG - 2024-02-18 07:05:16 --> UTF-8 Support Enabled
INFO - 2024-02-18 07:05:16 --> Utf8 Class Initialized
INFO - 2024-02-18 07:05:16 --> URI Class Initialized
DEBUG - 2024-02-18 07:05:16 --> No URI present. Default controller set.
INFO - 2024-02-18 07:05:16 --> Router Class Initialized
INFO - 2024-02-18 07:05:16 --> Output Class Initialized
INFO - 2024-02-18 07:05:16 --> Security Class Initialized
DEBUG - 2024-02-18 07:05:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-18 07:05:16 --> Input Class Initialized
INFO - 2024-02-18 07:05:16 --> Language Class Initialized
INFO - 2024-02-18 07:05:16 --> Loader Class Initialized
INFO - 2024-02-18 07:05:16 --> Helper loaded: url_helper
INFO - 2024-02-18 07:05:16 --> Helper loaded: file_helper
INFO - 2024-02-18 07:05:16 --> Helper loaded: html_helper
INFO - 2024-02-18 07:05:16 --> Helper loaded: text_helper
INFO - 2024-02-18 07:05:16 --> Helper loaded: form_helper
INFO - 2024-02-18 07:05:16 --> Helper loaded: lang_helper
INFO - 2024-02-18 07:05:16 --> Helper loaded: security_helper
INFO - 2024-02-18 07:05:16 --> Helper loaded: cookie_helper
INFO - 2024-02-18 07:05:16 --> Database Driver Class Initialized
INFO - 2024-02-18 07:05:16 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-18 07:05:16 --> Parser Class Initialized
INFO - 2024-02-18 07:05:16 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-18 07:05:16 --> Pagination Class Initialized
INFO - 2024-02-18 07:05:16 --> Form Validation Class Initialized
INFO - 2024-02-18 07:05:16 --> Controller Class Initialized
INFO - 2024-02-18 07:05:16 --> Model Class Initialized
DEBUG - 2024-02-18 07:05:16 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-18 07:05:16 --> Model Class Initialized
DEBUG - 2024-02-18 07:05:16 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-18 07:05:16 --> Model Class Initialized
INFO - 2024-02-18 07:05:16 --> Model Class Initialized
INFO - 2024-02-18 07:05:16 --> Model Class Initialized
INFO - 2024-02-18 07:05:16 --> Model Class Initialized
DEBUG - 2024-02-18 07:05:16 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-18 07:05:16 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-18 07:05:16 --> Model Class Initialized
INFO - 2024-02-18 07:05:16 --> Model Class Initialized
INFO - 2024-02-18 07:05:16 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2024-02-18 07:05:16 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-02-18 07:05:16 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-02-18 07:05:16 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-02-18 07:05:16 --> Model Class Initialized
INFO - 2024-02-18 07:05:16 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-02-18 07:05:16 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-02-18 07:05:16 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-02-18 07:05:16 --> Final output sent to browser
DEBUG - 2024-02-18 07:05:16 --> Total execution time: 0.2369
ERROR - 2024-02-18 07:05:28 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-18 07:05:28 --> Config Class Initialized
INFO - 2024-02-18 07:05:28 --> Hooks Class Initialized
DEBUG - 2024-02-18 07:05:28 --> UTF-8 Support Enabled
INFO - 2024-02-18 07:05:28 --> Utf8 Class Initialized
INFO - 2024-02-18 07:05:28 --> URI Class Initialized
INFO - 2024-02-18 07:05:28 --> Router Class Initialized
INFO - 2024-02-18 07:05:28 --> Output Class Initialized
INFO - 2024-02-18 07:05:28 --> Security Class Initialized
DEBUG - 2024-02-18 07:05:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-18 07:05:28 --> Input Class Initialized
INFO - 2024-02-18 07:05:28 --> Language Class Initialized
INFO - 2024-02-18 07:05:28 --> Loader Class Initialized
INFO - 2024-02-18 07:05:28 --> Helper loaded: url_helper
INFO - 2024-02-18 07:05:28 --> Helper loaded: file_helper
INFO - 2024-02-18 07:05:28 --> Helper loaded: html_helper
INFO - 2024-02-18 07:05:28 --> Helper loaded: text_helper
INFO - 2024-02-18 07:05:28 --> Helper loaded: form_helper
INFO - 2024-02-18 07:05:28 --> Helper loaded: lang_helper
INFO - 2024-02-18 07:05:28 --> Helper loaded: security_helper
INFO - 2024-02-18 07:05:28 --> Helper loaded: cookie_helper
INFO - 2024-02-18 07:05:28 --> Database Driver Class Initialized
INFO - 2024-02-18 07:05:28 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-18 07:05:28 --> Parser Class Initialized
INFO - 2024-02-18 07:05:28 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-18 07:05:28 --> Pagination Class Initialized
INFO - 2024-02-18 07:05:28 --> Form Validation Class Initialized
INFO - 2024-02-18 07:05:28 --> Controller Class Initialized
INFO - 2024-02-18 07:05:28 --> Model Class Initialized
DEBUG - 2024-02-18 07:05:28 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-18 07:05:28 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2024-02-18 07:05:28 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-02-18 07:05:28 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-02-18 07:05:28 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-02-18 07:05:28 --> Model Class Initialized
INFO - 2024-02-18 07:05:28 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-02-18 07:05:28 --> Final output sent to browser
DEBUG - 2024-02-18 07:05:28 --> Total execution time: 0.0311
ERROR - 2024-02-18 07:05:28 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-18 07:05:28 --> Config Class Initialized
INFO - 2024-02-18 07:05:28 --> Hooks Class Initialized
DEBUG - 2024-02-18 07:05:28 --> UTF-8 Support Enabled
INFO - 2024-02-18 07:05:28 --> Utf8 Class Initialized
INFO - 2024-02-18 07:05:28 --> URI Class Initialized
INFO - 2024-02-18 07:05:28 --> Router Class Initialized
INFO - 2024-02-18 07:05:28 --> Output Class Initialized
INFO - 2024-02-18 07:05:28 --> Security Class Initialized
DEBUG - 2024-02-18 07:05:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-18 07:05:28 --> Input Class Initialized
INFO - 2024-02-18 07:05:28 --> Language Class Initialized
INFO - 2024-02-18 07:05:28 --> Loader Class Initialized
INFO - 2024-02-18 07:05:28 --> Helper loaded: url_helper
INFO - 2024-02-18 07:05:28 --> Helper loaded: file_helper
INFO - 2024-02-18 07:05:28 --> Helper loaded: html_helper
INFO - 2024-02-18 07:05:28 --> Helper loaded: text_helper
INFO - 2024-02-18 07:05:28 --> Helper loaded: form_helper
INFO - 2024-02-18 07:05:28 --> Helper loaded: lang_helper
INFO - 2024-02-18 07:05:28 --> Helper loaded: security_helper
INFO - 2024-02-18 07:05:28 --> Helper loaded: cookie_helper
INFO - 2024-02-18 07:05:28 --> Database Driver Class Initialized
INFO - 2024-02-18 07:05:28 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-18 07:05:28 --> Parser Class Initialized
INFO - 2024-02-18 07:05:28 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-18 07:05:28 --> Pagination Class Initialized
INFO - 2024-02-18 07:05:28 --> Form Validation Class Initialized
INFO - 2024-02-18 07:05:28 --> Controller Class Initialized
INFO - 2024-02-18 07:05:28 --> Model Class Initialized
DEBUG - 2024-02-18 07:05:28 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-18 07:05:28 --> Model Class Initialized
DEBUG - 2024-02-18 07:05:28 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-18 07:05:28 --> Model Class Initialized
INFO - 2024-02-18 07:05:28 --> Model Class Initialized
INFO - 2024-02-18 07:05:28 --> Model Class Initialized
INFO - 2024-02-18 07:05:28 --> Model Class Initialized
DEBUG - 2024-02-18 07:05:28 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-18 07:05:28 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-18 07:05:28 --> Model Class Initialized
INFO - 2024-02-18 07:05:28 --> Model Class Initialized
INFO - 2024-02-18 07:05:28 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2024-02-18 07:05:28 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-02-18 07:05:28 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-02-18 07:05:28 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-02-18 07:05:28 --> Model Class Initialized
INFO - 2024-02-18 07:05:28 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-02-18 07:05:28 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-02-18 07:05:28 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-02-18 07:05:28 --> Final output sent to browser
DEBUG - 2024-02-18 07:05:28 --> Total execution time: 0.2242
ERROR - 2024-02-18 07:19:45 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-18 07:19:45 --> Config Class Initialized
INFO - 2024-02-18 07:19:45 --> Hooks Class Initialized
DEBUG - 2024-02-18 07:19:45 --> UTF-8 Support Enabled
INFO - 2024-02-18 07:19:45 --> Utf8 Class Initialized
INFO - 2024-02-18 07:19:45 --> URI Class Initialized
DEBUG - 2024-02-18 07:19:45 --> No URI present. Default controller set.
INFO - 2024-02-18 07:19:45 --> Router Class Initialized
INFO - 2024-02-18 07:19:45 --> Output Class Initialized
INFO - 2024-02-18 07:19:45 --> Security Class Initialized
DEBUG - 2024-02-18 07:19:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-18 07:19:45 --> Input Class Initialized
INFO - 2024-02-18 07:19:45 --> Language Class Initialized
INFO - 2024-02-18 07:19:45 --> Loader Class Initialized
INFO - 2024-02-18 07:19:45 --> Helper loaded: url_helper
INFO - 2024-02-18 07:19:45 --> Helper loaded: file_helper
INFO - 2024-02-18 07:19:45 --> Helper loaded: html_helper
INFO - 2024-02-18 07:19:45 --> Helper loaded: text_helper
INFO - 2024-02-18 07:19:45 --> Helper loaded: form_helper
INFO - 2024-02-18 07:19:45 --> Helper loaded: lang_helper
INFO - 2024-02-18 07:19:45 --> Helper loaded: security_helper
INFO - 2024-02-18 07:19:45 --> Helper loaded: cookie_helper
INFO - 2024-02-18 07:19:45 --> Database Driver Class Initialized
INFO - 2024-02-18 07:19:45 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-18 07:19:45 --> Parser Class Initialized
INFO - 2024-02-18 07:19:45 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-18 07:19:45 --> Pagination Class Initialized
INFO - 2024-02-18 07:19:45 --> Form Validation Class Initialized
INFO - 2024-02-18 07:19:45 --> Controller Class Initialized
INFO - 2024-02-18 07:19:45 --> Model Class Initialized
DEBUG - 2024-02-18 07:19:45 --> Session class already loaded. Second attempt ignored.
ERROR - 2024-02-18 08:48:59 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-18 08:48:59 --> Config Class Initialized
INFO - 2024-02-18 08:48:59 --> Hooks Class Initialized
DEBUG - 2024-02-18 08:48:59 --> UTF-8 Support Enabled
INFO - 2024-02-18 08:48:59 --> Utf8 Class Initialized
INFO - 2024-02-18 08:48:59 --> URI Class Initialized
DEBUG - 2024-02-18 08:48:59 --> No URI present. Default controller set.
INFO - 2024-02-18 08:48:59 --> Router Class Initialized
INFO - 2024-02-18 08:48:59 --> Output Class Initialized
INFO - 2024-02-18 08:48:59 --> Security Class Initialized
DEBUG - 2024-02-18 08:48:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-18 08:48:59 --> Input Class Initialized
INFO - 2024-02-18 08:48:59 --> Language Class Initialized
INFO - 2024-02-18 08:48:59 --> Loader Class Initialized
INFO - 2024-02-18 08:48:59 --> Helper loaded: url_helper
INFO - 2024-02-18 08:48:59 --> Helper loaded: file_helper
INFO - 2024-02-18 08:48:59 --> Helper loaded: html_helper
INFO - 2024-02-18 08:48:59 --> Helper loaded: text_helper
INFO - 2024-02-18 08:48:59 --> Helper loaded: form_helper
INFO - 2024-02-18 08:48:59 --> Helper loaded: lang_helper
INFO - 2024-02-18 08:48:59 --> Helper loaded: security_helper
INFO - 2024-02-18 08:48:59 --> Helper loaded: cookie_helper
INFO - 2024-02-18 08:48:59 --> Database Driver Class Initialized
INFO - 2024-02-18 08:48:59 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-18 08:48:59 --> Parser Class Initialized
INFO - 2024-02-18 08:48:59 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-18 08:48:59 --> Pagination Class Initialized
INFO - 2024-02-18 08:48:59 --> Form Validation Class Initialized
INFO - 2024-02-18 08:48:59 --> Controller Class Initialized
INFO - 2024-02-18 08:48:59 --> Model Class Initialized
DEBUG - 2024-02-18 08:48:59 --> Session class already loaded. Second attempt ignored.
ERROR - 2024-02-18 08:48:59 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-18 08:48:59 --> Config Class Initialized
INFO - 2024-02-18 08:48:59 --> Hooks Class Initialized
DEBUG - 2024-02-18 08:48:59 --> UTF-8 Support Enabled
INFO - 2024-02-18 08:48:59 --> Utf8 Class Initialized
INFO - 2024-02-18 08:48:59 --> URI Class Initialized
INFO - 2024-02-18 08:48:59 --> Router Class Initialized
INFO - 2024-02-18 08:48:59 --> Output Class Initialized
INFO - 2024-02-18 08:48:59 --> Security Class Initialized
DEBUG - 2024-02-18 08:48:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-18 08:48:59 --> Input Class Initialized
INFO - 2024-02-18 08:48:59 --> Language Class Initialized
INFO - 2024-02-18 08:48:59 --> Loader Class Initialized
INFO - 2024-02-18 08:48:59 --> Helper loaded: url_helper
INFO - 2024-02-18 08:48:59 --> Helper loaded: file_helper
INFO - 2024-02-18 08:48:59 --> Helper loaded: html_helper
INFO - 2024-02-18 08:48:59 --> Helper loaded: text_helper
INFO - 2024-02-18 08:48:59 --> Helper loaded: form_helper
INFO - 2024-02-18 08:48:59 --> Helper loaded: lang_helper
INFO - 2024-02-18 08:48:59 --> Helper loaded: security_helper
INFO - 2024-02-18 08:48:59 --> Helper loaded: cookie_helper
INFO - 2024-02-18 08:48:59 --> Database Driver Class Initialized
INFO - 2024-02-18 08:48:59 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-18 08:48:59 --> Parser Class Initialized
INFO - 2024-02-18 08:48:59 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-18 08:48:59 --> Pagination Class Initialized
INFO - 2024-02-18 08:48:59 --> Form Validation Class Initialized
INFO - 2024-02-18 08:48:59 --> Controller Class Initialized
INFO - 2024-02-18 08:48:59 --> Model Class Initialized
DEBUG - 2024-02-18 08:48:59 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-18 08:48:59 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2024-02-18 08:48:59 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-02-18 08:48:59 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-02-18 08:48:59 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-02-18 08:48:59 --> Model Class Initialized
INFO - 2024-02-18 08:48:59 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-02-18 08:48:59 --> Final output sent to browser
DEBUG - 2024-02-18 08:48:59 --> Total execution time: 0.0341
ERROR - 2024-02-18 08:49:09 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-18 08:49:09 --> Config Class Initialized
INFO - 2024-02-18 08:49:09 --> Hooks Class Initialized
DEBUG - 2024-02-18 08:49:09 --> UTF-8 Support Enabled
INFO - 2024-02-18 08:49:09 --> Utf8 Class Initialized
INFO - 2024-02-18 08:49:09 --> URI Class Initialized
INFO - 2024-02-18 08:49:09 --> Router Class Initialized
INFO - 2024-02-18 08:49:09 --> Output Class Initialized
INFO - 2024-02-18 08:49:09 --> Security Class Initialized
DEBUG - 2024-02-18 08:49:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-18 08:49:09 --> Input Class Initialized
INFO - 2024-02-18 08:49:09 --> Language Class Initialized
INFO - 2024-02-18 08:49:09 --> Loader Class Initialized
INFO - 2024-02-18 08:49:09 --> Helper loaded: url_helper
INFO - 2024-02-18 08:49:09 --> Helper loaded: file_helper
INFO - 2024-02-18 08:49:09 --> Helper loaded: html_helper
INFO - 2024-02-18 08:49:09 --> Helper loaded: text_helper
INFO - 2024-02-18 08:49:09 --> Helper loaded: form_helper
INFO - 2024-02-18 08:49:09 --> Helper loaded: lang_helper
INFO - 2024-02-18 08:49:09 --> Helper loaded: security_helper
INFO - 2024-02-18 08:49:09 --> Helper loaded: cookie_helper
INFO - 2024-02-18 08:49:09 --> Database Driver Class Initialized
INFO - 2024-02-18 08:49:09 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-18 08:49:09 --> Parser Class Initialized
INFO - 2024-02-18 08:49:09 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-18 08:49:09 --> Pagination Class Initialized
INFO - 2024-02-18 08:49:09 --> Form Validation Class Initialized
INFO - 2024-02-18 08:49:09 --> Controller Class Initialized
INFO - 2024-02-18 08:49:09 --> Model Class Initialized
DEBUG - 2024-02-18 08:49:09 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-18 08:49:09 --> Model Class Initialized
INFO - 2024-02-18 08:49:09 --> Final output sent to browser
DEBUG - 2024-02-18 08:49:09 --> Total execution time: 0.0182
ERROR - 2024-02-18 08:49:10 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-18 08:49:10 --> Config Class Initialized
INFO - 2024-02-18 08:49:10 --> Hooks Class Initialized
DEBUG - 2024-02-18 08:49:10 --> UTF-8 Support Enabled
INFO - 2024-02-18 08:49:10 --> Utf8 Class Initialized
INFO - 2024-02-18 08:49:10 --> URI Class Initialized
DEBUG - 2024-02-18 08:49:10 --> No URI present. Default controller set.
INFO - 2024-02-18 08:49:10 --> Router Class Initialized
INFO - 2024-02-18 08:49:10 --> Output Class Initialized
INFO - 2024-02-18 08:49:10 --> Security Class Initialized
DEBUG - 2024-02-18 08:49:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-18 08:49:10 --> Input Class Initialized
INFO - 2024-02-18 08:49:10 --> Language Class Initialized
INFO - 2024-02-18 08:49:10 --> Loader Class Initialized
INFO - 2024-02-18 08:49:10 --> Helper loaded: url_helper
INFO - 2024-02-18 08:49:10 --> Helper loaded: file_helper
INFO - 2024-02-18 08:49:10 --> Helper loaded: html_helper
INFO - 2024-02-18 08:49:10 --> Helper loaded: text_helper
INFO - 2024-02-18 08:49:10 --> Helper loaded: form_helper
INFO - 2024-02-18 08:49:10 --> Helper loaded: lang_helper
INFO - 2024-02-18 08:49:10 --> Helper loaded: security_helper
INFO - 2024-02-18 08:49:10 --> Helper loaded: cookie_helper
INFO - 2024-02-18 08:49:10 --> Database Driver Class Initialized
INFO - 2024-02-18 08:49:10 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-18 08:49:10 --> Parser Class Initialized
INFO - 2024-02-18 08:49:10 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-18 08:49:10 --> Pagination Class Initialized
INFO - 2024-02-18 08:49:10 --> Form Validation Class Initialized
INFO - 2024-02-18 08:49:10 --> Controller Class Initialized
INFO - 2024-02-18 08:49:10 --> Model Class Initialized
DEBUG - 2024-02-18 08:49:10 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-18 08:49:10 --> Model Class Initialized
DEBUG - 2024-02-18 08:49:10 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-18 08:49:10 --> Model Class Initialized
INFO - 2024-02-18 08:49:10 --> Model Class Initialized
INFO - 2024-02-18 08:49:10 --> Model Class Initialized
INFO - 2024-02-18 08:49:10 --> Model Class Initialized
DEBUG - 2024-02-18 08:49:10 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-18 08:49:10 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-18 08:49:10 --> Model Class Initialized
INFO - 2024-02-18 08:49:10 --> Model Class Initialized
INFO - 2024-02-18 08:49:10 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2024-02-18 08:49:10 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-02-18 08:49:10 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-02-18 08:49:10 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-02-18 08:49:10 --> Model Class Initialized
INFO - 2024-02-18 08:49:10 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-02-18 08:49:10 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-02-18 08:49:10 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-02-18 08:49:10 --> Final output sent to browser
DEBUG - 2024-02-18 08:49:10 --> Total execution time: 0.4481
ERROR - 2024-02-18 08:49:11 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-18 08:49:11 --> Config Class Initialized
INFO - 2024-02-18 08:49:11 --> Hooks Class Initialized
DEBUG - 2024-02-18 08:49:11 --> UTF-8 Support Enabled
INFO - 2024-02-18 08:49:11 --> Utf8 Class Initialized
INFO - 2024-02-18 08:49:11 --> URI Class Initialized
INFO - 2024-02-18 08:49:11 --> Router Class Initialized
INFO - 2024-02-18 08:49:11 --> Output Class Initialized
INFO - 2024-02-18 08:49:11 --> Security Class Initialized
DEBUG - 2024-02-18 08:49:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-18 08:49:11 --> Input Class Initialized
INFO - 2024-02-18 08:49:11 --> Language Class Initialized
INFO - 2024-02-18 08:49:11 --> Loader Class Initialized
INFO - 2024-02-18 08:49:11 --> Helper loaded: url_helper
INFO - 2024-02-18 08:49:11 --> Helper loaded: file_helper
INFO - 2024-02-18 08:49:11 --> Helper loaded: html_helper
INFO - 2024-02-18 08:49:11 --> Helper loaded: text_helper
INFO - 2024-02-18 08:49:11 --> Helper loaded: form_helper
INFO - 2024-02-18 08:49:11 --> Helper loaded: lang_helper
INFO - 2024-02-18 08:49:11 --> Helper loaded: security_helper
INFO - 2024-02-18 08:49:11 --> Helper loaded: cookie_helper
INFO - 2024-02-18 08:49:11 --> Database Driver Class Initialized
INFO - 2024-02-18 08:49:11 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-18 08:49:11 --> Parser Class Initialized
INFO - 2024-02-18 08:49:11 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-18 08:49:11 --> Pagination Class Initialized
INFO - 2024-02-18 08:49:11 --> Form Validation Class Initialized
INFO - 2024-02-18 08:49:11 --> Controller Class Initialized
DEBUG - 2024-02-18 08:49:11 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-18 08:49:11 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-18 08:49:11 --> Model Class Initialized
INFO - 2024-02-18 08:49:11 --> Final output sent to browser
DEBUG - 2024-02-18 08:49:11 --> Total execution time: 0.0140
ERROR - 2024-02-18 08:49:38 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-18 08:49:38 --> Config Class Initialized
INFO - 2024-02-18 08:49:38 --> Hooks Class Initialized
DEBUG - 2024-02-18 08:49:38 --> UTF-8 Support Enabled
INFO - 2024-02-18 08:49:38 --> Utf8 Class Initialized
INFO - 2024-02-18 08:49:38 --> URI Class Initialized
INFO - 2024-02-18 08:49:38 --> Router Class Initialized
INFO - 2024-02-18 08:49:38 --> Output Class Initialized
INFO - 2024-02-18 08:49:38 --> Security Class Initialized
DEBUG - 2024-02-18 08:49:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-18 08:49:38 --> Input Class Initialized
INFO - 2024-02-18 08:49:38 --> Language Class Initialized
INFO - 2024-02-18 08:49:38 --> Loader Class Initialized
INFO - 2024-02-18 08:49:38 --> Helper loaded: url_helper
INFO - 2024-02-18 08:49:38 --> Helper loaded: file_helper
INFO - 2024-02-18 08:49:38 --> Helper loaded: html_helper
INFO - 2024-02-18 08:49:38 --> Helper loaded: text_helper
INFO - 2024-02-18 08:49:38 --> Helper loaded: form_helper
INFO - 2024-02-18 08:49:38 --> Helper loaded: lang_helper
INFO - 2024-02-18 08:49:38 --> Helper loaded: security_helper
INFO - 2024-02-18 08:49:38 --> Helper loaded: cookie_helper
INFO - 2024-02-18 08:49:38 --> Database Driver Class Initialized
INFO - 2024-02-18 08:49:38 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-18 08:49:38 --> Parser Class Initialized
INFO - 2024-02-18 08:49:38 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-18 08:49:38 --> Pagination Class Initialized
INFO - 2024-02-18 08:49:38 --> Form Validation Class Initialized
INFO - 2024-02-18 08:49:38 --> Controller Class Initialized
INFO - 2024-02-18 08:49:38 --> Model Class Initialized
DEBUG - 2024-02-18 08:49:38 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-18 08:49:38 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-18 08:49:38 --> Model Class Initialized
DEBUG - 2024-02-18 08:49:38 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-18 08:49:38 --> Model Class Initialized
INFO - 2024-02-18 08:49:38 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice.php
DEBUG - 2024-02-18 08:49:38 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-02-18 08:49:38 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-02-18 08:49:38 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-02-18 08:49:38 --> Model Class Initialized
INFO - 2024-02-18 08:49:38 --> Model Class Initialized
INFO - 2024-02-18 08:49:38 --> Model Class Initialized
INFO - 2024-02-18 08:49:39 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-02-18 08:49:39 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-02-18 08:49:39 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-02-18 08:49:39 --> Final output sent to browser
DEBUG - 2024-02-18 08:49:39 --> Total execution time: 0.2229
ERROR - 2024-02-18 08:49:39 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-18 08:49:39 --> Config Class Initialized
INFO - 2024-02-18 08:49:39 --> Hooks Class Initialized
DEBUG - 2024-02-18 08:49:39 --> UTF-8 Support Enabled
INFO - 2024-02-18 08:49:39 --> Utf8 Class Initialized
INFO - 2024-02-18 08:49:39 --> URI Class Initialized
INFO - 2024-02-18 08:49:39 --> Router Class Initialized
INFO - 2024-02-18 08:49:39 --> Output Class Initialized
INFO - 2024-02-18 08:49:39 --> Security Class Initialized
DEBUG - 2024-02-18 08:49:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-18 08:49:39 --> Input Class Initialized
INFO - 2024-02-18 08:49:39 --> Language Class Initialized
INFO - 2024-02-18 08:49:39 --> Loader Class Initialized
INFO - 2024-02-18 08:49:39 --> Helper loaded: url_helper
INFO - 2024-02-18 08:49:39 --> Helper loaded: file_helper
INFO - 2024-02-18 08:49:39 --> Helper loaded: html_helper
INFO - 2024-02-18 08:49:39 --> Helper loaded: text_helper
INFO - 2024-02-18 08:49:39 --> Helper loaded: form_helper
INFO - 2024-02-18 08:49:39 --> Helper loaded: lang_helper
INFO - 2024-02-18 08:49:39 --> Helper loaded: security_helper
INFO - 2024-02-18 08:49:39 --> Helper loaded: cookie_helper
INFO - 2024-02-18 08:49:39 --> Database Driver Class Initialized
INFO - 2024-02-18 08:49:39 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-18 08:49:39 --> Parser Class Initialized
INFO - 2024-02-18 08:49:39 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-18 08:49:39 --> Pagination Class Initialized
INFO - 2024-02-18 08:49:39 --> Form Validation Class Initialized
INFO - 2024-02-18 08:49:39 --> Controller Class Initialized
INFO - 2024-02-18 08:49:39 --> Model Class Initialized
DEBUG - 2024-02-18 08:49:39 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-18 08:49:39 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-18 08:49:39 --> Model Class Initialized
DEBUG - 2024-02-18 08:49:39 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-18 08:49:39 --> Model Class Initialized
INFO - 2024-02-18 08:49:39 --> Final output sent to browser
DEBUG - 2024-02-18 08:49:39 --> Total execution time: 0.0601
ERROR - 2024-02-18 09:11:31 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-18 09:11:31 --> Config Class Initialized
INFO - 2024-02-18 09:11:31 --> Hooks Class Initialized
DEBUG - 2024-02-18 09:11:31 --> UTF-8 Support Enabled
INFO - 2024-02-18 09:11:31 --> Utf8 Class Initialized
INFO - 2024-02-18 09:11:31 --> URI Class Initialized
INFO - 2024-02-18 09:11:31 --> Router Class Initialized
INFO - 2024-02-18 09:11:31 --> Output Class Initialized
INFO - 2024-02-18 09:11:31 --> Security Class Initialized
DEBUG - 2024-02-18 09:11:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-18 09:11:31 --> Input Class Initialized
INFO - 2024-02-18 09:11:31 --> Language Class Initialized
ERROR - 2024-02-18 09:11:31 --> 404 Page Not Found: Well-known/assetlinks.json
ERROR - 2024-02-18 09:30:24 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-18 09:30:24 --> Config Class Initialized
INFO - 2024-02-18 09:30:24 --> Hooks Class Initialized
DEBUG - 2024-02-18 09:30:24 --> UTF-8 Support Enabled
INFO - 2024-02-18 09:30:24 --> Utf8 Class Initialized
INFO - 2024-02-18 09:30:24 --> URI Class Initialized
DEBUG - 2024-02-18 09:30:24 --> No URI present. Default controller set.
INFO - 2024-02-18 09:30:24 --> Router Class Initialized
INFO - 2024-02-18 09:30:24 --> Output Class Initialized
INFO - 2024-02-18 09:30:24 --> Security Class Initialized
DEBUG - 2024-02-18 09:30:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-18 09:30:24 --> Input Class Initialized
INFO - 2024-02-18 09:30:24 --> Language Class Initialized
INFO - 2024-02-18 09:30:24 --> Loader Class Initialized
INFO - 2024-02-18 09:30:24 --> Helper loaded: url_helper
INFO - 2024-02-18 09:30:24 --> Helper loaded: file_helper
INFO - 2024-02-18 09:30:24 --> Helper loaded: html_helper
INFO - 2024-02-18 09:30:24 --> Helper loaded: text_helper
INFO - 2024-02-18 09:30:24 --> Helper loaded: form_helper
INFO - 2024-02-18 09:30:24 --> Helper loaded: lang_helper
INFO - 2024-02-18 09:30:24 --> Helper loaded: security_helper
INFO - 2024-02-18 09:30:24 --> Helper loaded: cookie_helper
INFO - 2024-02-18 09:30:24 --> Database Driver Class Initialized
INFO - 2024-02-18 09:30:24 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-18 09:30:24 --> Parser Class Initialized
INFO - 2024-02-18 09:30:24 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-18 09:30:24 --> Pagination Class Initialized
INFO - 2024-02-18 09:30:24 --> Form Validation Class Initialized
INFO - 2024-02-18 09:30:24 --> Controller Class Initialized
INFO - 2024-02-18 09:30:24 --> Model Class Initialized
DEBUG - 2024-02-18 09:30:24 --> Session class already loaded. Second attempt ignored.
ERROR - 2024-02-18 09:30:24 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-18 09:30:24 --> Config Class Initialized
INFO - 2024-02-18 09:30:24 --> Hooks Class Initialized
DEBUG - 2024-02-18 09:30:24 --> UTF-8 Support Enabled
INFO - 2024-02-18 09:30:24 --> Utf8 Class Initialized
INFO - 2024-02-18 09:30:24 --> URI Class Initialized
INFO - 2024-02-18 09:30:24 --> Router Class Initialized
INFO - 2024-02-18 09:30:24 --> Output Class Initialized
INFO - 2024-02-18 09:30:24 --> Security Class Initialized
DEBUG - 2024-02-18 09:30:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-18 09:30:24 --> Input Class Initialized
INFO - 2024-02-18 09:30:24 --> Language Class Initialized
INFO - 2024-02-18 09:30:24 --> Loader Class Initialized
INFO - 2024-02-18 09:30:24 --> Helper loaded: url_helper
INFO - 2024-02-18 09:30:24 --> Helper loaded: file_helper
INFO - 2024-02-18 09:30:24 --> Helper loaded: html_helper
INFO - 2024-02-18 09:30:24 --> Helper loaded: text_helper
INFO - 2024-02-18 09:30:24 --> Helper loaded: form_helper
INFO - 2024-02-18 09:30:24 --> Helper loaded: lang_helper
INFO - 2024-02-18 09:30:24 --> Helper loaded: security_helper
INFO - 2024-02-18 09:30:24 --> Helper loaded: cookie_helper
INFO - 2024-02-18 09:30:24 --> Database Driver Class Initialized
INFO - 2024-02-18 09:30:24 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-18 09:30:24 --> Parser Class Initialized
INFO - 2024-02-18 09:30:24 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-18 09:30:24 --> Pagination Class Initialized
INFO - 2024-02-18 09:30:24 --> Form Validation Class Initialized
INFO - 2024-02-18 09:30:24 --> Controller Class Initialized
INFO - 2024-02-18 09:30:24 --> Model Class Initialized
DEBUG - 2024-02-18 09:30:24 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-18 09:30:24 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2024-02-18 09:30:24 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-02-18 09:30:24 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-02-18 09:30:24 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-02-18 09:30:24 --> Model Class Initialized
INFO - 2024-02-18 09:30:24 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-02-18 09:30:24 --> Final output sent to browser
DEBUG - 2024-02-18 09:30:24 --> Total execution time: 0.0348
ERROR - 2024-02-18 09:30:52 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-18 09:30:52 --> Config Class Initialized
INFO - 2024-02-18 09:30:52 --> Hooks Class Initialized
DEBUG - 2024-02-18 09:30:52 --> UTF-8 Support Enabled
INFO - 2024-02-18 09:30:52 --> Utf8 Class Initialized
INFO - 2024-02-18 09:30:52 --> URI Class Initialized
INFO - 2024-02-18 09:30:52 --> Router Class Initialized
INFO - 2024-02-18 09:30:52 --> Output Class Initialized
INFO - 2024-02-18 09:30:52 --> Security Class Initialized
DEBUG - 2024-02-18 09:30:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-18 09:30:52 --> Input Class Initialized
INFO - 2024-02-18 09:30:52 --> Language Class Initialized
INFO - 2024-02-18 09:30:52 --> Loader Class Initialized
INFO - 2024-02-18 09:30:52 --> Helper loaded: url_helper
INFO - 2024-02-18 09:30:52 --> Helper loaded: file_helper
INFO - 2024-02-18 09:30:52 --> Helper loaded: html_helper
INFO - 2024-02-18 09:30:52 --> Helper loaded: text_helper
INFO - 2024-02-18 09:30:52 --> Helper loaded: form_helper
INFO - 2024-02-18 09:30:52 --> Helper loaded: lang_helper
INFO - 2024-02-18 09:30:52 --> Helper loaded: security_helper
INFO - 2024-02-18 09:30:52 --> Helper loaded: cookie_helper
INFO - 2024-02-18 09:30:52 --> Database Driver Class Initialized
INFO - 2024-02-18 09:30:52 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-18 09:30:52 --> Parser Class Initialized
INFO - 2024-02-18 09:30:52 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-18 09:30:52 --> Pagination Class Initialized
INFO - 2024-02-18 09:30:52 --> Form Validation Class Initialized
INFO - 2024-02-18 09:30:52 --> Controller Class Initialized
INFO - 2024-02-18 09:30:52 --> Model Class Initialized
DEBUG - 2024-02-18 09:30:52 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-18 09:30:52 --> Model Class Initialized
INFO - 2024-02-18 09:30:52 --> Final output sent to browser
DEBUG - 2024-02-18 09:30:52 --> Total execution time: 0.0196
ERROR - 2024-02-18 09:30:52 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-18 09:30:52 --> Config Class Initialized
INFO - 2024-02-18 09:30:52 --> Hooks Class Initialized
DEBUG - 2024-02-18 09:30:52 --> UTF-8 Support Enabled
INFO - 2024-02-18 09:30:52 --> Utf8 Class Initialized
INFO - 2024-02-18 09:30:52 --> URI Class Initialized
DEBUG - 2024-02-18 09:30:52 --> No URI present. Default controller set.
INFO - 2024-02-18 09:30:52 --> Router Class Initialized
INFO - 2024-02-18 09:30:52 --> Output Class Initialized
INFO - 2024-02-18 09:30:52 --> Security Class Initialized
DEBUG - 2024-02-18 09:30:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-18 09:30:52 --> Input Class Initialized
INFO - 2024-02-18 09:30:52 --> Language Class Initialized
INFO - 2024-02-18 09:30:52 --> Loader Class Initialized
INFO - 2024-02-18 09:30:52 --> Helper loaded: url_helper
INFO - 2024-02-18 09:30:52 --> Helper loaded: file_helper
INFO - 2024-02-18 09:30:52 --> Helper loaded: html_helper
INFO - 2024-02-18 09:30:52 --> Helper loaded: text_helper
INFO - 2024-02-18 09:30:52 --> Helper loaded: form_helper
INFO - 2024-02-18 09:30:52 --> Helper loaded: lang_helper
INFO - 2024-02-18 09:30:52 --> Helper loaded: security_helper
INFO - 2024-02-18 09:30:52 --> Helper loaded: cookie_helper
INFO - 2024-02-18 09:30:52 --> Database Driver Class Initialized
INFO - 2024-02-18 09:30:52 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-18 09:30:52 --> Parser Class Initialized
INFO - 2024-02-18 09:30:52 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-18 09:30:52 --> Pagination Class Initialized
INFO - 2024-02-18 09:30:52 --> Form Validation Class Initialized
INFO - 2024-02-18 09:30:52 --> Controller Class Initialized
INFO - 2024-02-18 09:30:52 --> Model Class Initialized
DEBUG - 2024-02-18 09:30:52 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-18 09:30:52 --> Model Class Initialized
DEBUG - 2024-02-18 09:30:52 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-18 09:30:52 --> Model Class Initialized
INFO - 2024-02-18 09:30:52 --> Model Class Initialized
INFO - 2024-02-18 09:30:52 --> Model Class Initialized
INFO - 2024-02-18 09:30:52 --> Model Class Initialized
DEBUG - 2024-02-18 09:30:52 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-18 09:30:52 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-18 09:30:52 --> Model Class Initialized
INFO - 2024-02-18 09:30:52 --> Model Class Initialized
INFO - 2024-02-18 09:30:52 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2024-02-18 09:30:52 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-02-18 09:30:52 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-02-18 09:30:52 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-02-18 09:30:52 --> Model Class Initialized
INFO - 2024-02-18 09:30:52 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-02-18 09:30:52 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-02-18 09:30:52 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-02-18 09:30:52 --> Final output sent to browser
DEBUG - 2024-02-18 09:30:52 --> Total execution time: 0.2325
ERROR - 2024-02-18 09:30:59 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-18 09:30:59 --> Config Class Initialized
INFO - 2024-02-18 09:30:59 --> Hooks Class Initialized
DEBUG - 2024-02-18 09:30:59 --> UTF-8 Support Enabled
INFO - 2024-02-18 09:30:59 --> Utf8 Class Initialized
INFO - 2024-02-18 09:30:59 --> URI Class Initialized
INFO - 2024-02-18 09:30:59 --> Router Class Initialized
INFO - 2024-02-18 09:30:59 --> Output Class Initialized
INFO - 2024-02-18 09:30:59 --> Security Class Initialized
DEBUG - 2024-02-18 09:30:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-18 09:30:59 --> Input Class Initialized
INFO - 2024-02-18 09:30:59 --> Language Class Initialized
INFO - 2024-02-18 09:30:59 --> Loader Class Initialized
INFO - 2024-02-18 09:30:59 --> Helper loaded: url_helper
INFO - 2024-02-18 09:30:59 --> Helper loaded: file_helper
INFO - 2024-02-18 09:30:59 --> Helper loaded: html_helper
INFO - 2024-02-18 09:30:59 --> Helper loaded: text_helper
INFO - 2024-02-18 09:30:59 --> Helper loaded: form_helper
INFO - 2024-02-18 09:30:59 --> Helper loaded: lang_helper
INFO - 2024-02-18 09:30:59 --> Helper loaded: security_helper
INFO - 2024-02-18 09:30:59 --> Helper loaded: cookie_helper
INFO - 2024-02-18 09:30:59 --> Database Driver Class Initialized
INFO - 2024-02-18 09:30:59 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-18 09:30:59 --> Parser Class Initialized
INFO - 2024-02-18 09:30:59 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-18 09:30:59 --> Pagination Class Initialized
INFO - 2024-02-18 09:30:59 --> Form Validation Class Initialized
INFO - 2024-02-18 09:30:59 --> Controller Class Initialized
DEBUG - 2024-02-18 09:30:59 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-18 09:30:59 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-18 09:30:59 --> Model Class Initialized
DEBUG - 2024-02-18 09:30:59 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-18 09:30:59 --> Model Class Initialized
INFO - 2024-02-18 09:30:59 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/customer/add_customer_form.php
DEBUG - 2024-02-18 09:30:59 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-02-18 09:30:59 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-02-18 09:30:59 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-02-18 09:30:59 --> Model Class Initialized
INFO - 2024-02-18 09:30:59 --> Model Class Initialized
INFO - 2024-02-18 09:30:59 --> Model Class Initialized
INFO - 2024-02-18 09:30:59 --> Model Class Initialized
INFO - 2024-02-18 09:30:59 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-02-18 09:30:59 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-02-18 09:30:59 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-02-18 09:30:59 --> Final output sent to browser
DEBUG - 2024-02-18 09:30:59 --> Total execution time: 0.1925
ERROR - 2024-02-18 09:33:36 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-18 09:33:36 --> Config Class Initialized
INFO - 2024-02-18 09:33:36 --> Hooks Class Initialized
DEBUG - 2024-02-18 09:33:36 --> UTF-8 Support Enabled
INFO - 2024-02-18 09:33:36 --> Utf8 Class Initialized
INFO - 2024-02-18 09:33:36 --> URI Class Initialized
INFO - 2024-02-18 09:33:36 --> Router Class Initialized
INFO - 2024-02-18 09:33:36 --> Output Class Initialized
INFO - 2024-02-18 09:33:36 --> Security Class Initialized
DEBUG - 2024-02-18 09:33:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-18 09:33:36 --> Input Class Initialized
INFO - 2024-02-18 09:33:36 --> Language Class Initialized
INFO - 2024-02-18 09:33:36 --> Loader Class Initialized
INFO - 2024-02-18 09:33:36 --> Helper loaded: url_helper
INFO - 2024-02-18 09:33:36 --> Helper loaded: file_helper
INFO - 2024-02-18 09:33:36 --> Helper loaded: html_helper
INFO - 2024-02-18 09:33:36 --> Helper loaded: text_helper
INFO - 2024-02-18 09:33:36 --> Helper loaded: form_helper
INFO - 2024-02-18 09:33:36 --> Helper loaded: lang_helper
INFO - 2024-02-18 09:33:36 --> Helper loaded: security_helper
INFO - 2024-02-18 09:33:36 --> Helper loaded: cookie_helper
INFO - 2024-02-18 09:33:36 --> Database Driver Class Initialized
INFO - 2024-02-18 09:33:36 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-18 09:33:36 --> Parser Class Initialized
INFO - 2024-02-18 09:33:36 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-18 09:33:36 --> Pagination Class Initialized
INFO - 2024-02-18 09:33:36 --> Form Validation Class Initialized
INFO - 2024-02-18 09:33:36 --> Controller Class Initialized
DEBUG - 2024-02-18 09:33:36 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-18 09:33:36 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-18 09:33:36 --> Model Class Initialized
DEBUG - 2024-02-18 09:33:36 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-18 09:33:36 --> Model Class Initialized
DEBUG - 2024-02-18 09:33:36 --> Auth class already loaded. Second attempt ignored.
ERROR - 2024-02-18 09:33:36 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-18 09:33:36 --> Config Class Initialized
INFO - 2024-02-18 09:33:36 --> Hooks Class Initialized
DEBUG - 2024-02-18 09:33:36 --> UTF-8 Support Enabled
INFO - 2024-02-18 09:33:36 --> Utf8 Class Initialized
INFO - 2024-02-18 09:33:36 --> URI Class Initialized
INFO - 2024-02-18 09:33:36 --> Router Class Initialized
INFO - 2024-02-18 09:33:36 --> Output Class Initialized
INFO - 2024-02-18 09:33:36 --> Security Class Initialized
DEBUG - 2024-02-18 09:33:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-18 09:33:36 --> Input Class Initialized
INFO - 2024-02-18 09:33:36 --> Language Class Initialized
INFO - 2024-02-18 09:33:36 --> Loader Class Initialized
INFO - 2024-02-18 09:33:36 --> Helper loaded: url_helper
INFO - 2024-02-18 09:33:36 --> Helper loaded: file_helper
INFO - 2024-02-18 09:33:36 --> Helper loaded: html_helper
INFO - 2024-02-18 09:33:36 --> Helper loaded: text_helper
INFO - 2024-02-18 09:33:36 --> Helper loaded: form_helper
INFO - 2024-02-18 09:33:36 --> Helper loaded: lang_helper
INFO - 2024-02-18 09:33:36 --> Helper loaded: security_helper
INFO - 2024-02-18 09:33:36 --> Helper loaded: cookie_helper
INFO - 2024-02-18 09:33:36 --> Database Driver Class Initialized
INFO - 2024-02-18 09:33:36 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-18 09:33:36 --> Parser Class Initialized
INFO - 2024-02-18 09:33:36 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-18 09:33:36 --> Pagination Class Initialized
INFO - 2024-02-18 09:33:36 --> Form Validation Class Initialized
INFO - 2024-02-18 09:33:36 --> Controller Class Initialized
DEBUG - 2024-02-18 09:33:36 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-18 09:33:36 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-18 09:33:36 --> Model Class Initialized
DEBUG - 2024-02-18 09:33:36 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-18 09:33:36 --> Model Class Initialized
INFO - 2024-02-18 09:33:36 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/customer/add_customer_form.php
DEBUG - 2024-02-18 09:33:36 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-02-18 09:33:36 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-02-18 09:33:36 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-02-18 09:33:36 --> Model Class Initialized
INFO - 2024-02-18 09:33:36 --> Model Class Initialized
INFO - 2024-02-18 09:33:36 --> Model Class Initialized
INFO - 2024-02-18 09:33:36 --> Model Class Initialized
INFO - 2024-02-18 09:33:36 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-02-18 09:33:36 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-02-18 09:33:36 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-02-18 09:33:36 --> Final output sent to browser
DEBUG - 2024-02-18 09:33:36 --> Total execution time: 0.1789
ERROR - 2024-02-18 09:43:47 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-18 09:43:47 --> Config Class Initialized
INFO - 2024-02-18 09:43:47 --> Hooks Class Initialized
DEBUG - 2024-02-18 09:43:47 --> UTF-8 Support Enabled
INFO - 2024-02-18 09:43:47 --> Utf8 Class Initialized
INFO - 2024-02-18 09:43:47 --> URI Class Initialized
INFO - 2024-02-18 09:43:47 --> Router Class Initialized
INFO - 2024-02-18 09:43:47 --> Output Class Initialized
INFO - 2024-02-18 09:43:47 --> Security Class Initialized
DEBUG - 2024-02-18 09:43:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-18 09:43:47 --> Input Class Initialized
INFO - 2024-02-18 09:43:47 --> Language Class Initialized
INFO - 2024-02-18 09:43:47 --> Loader Class Initialized
INFO - 2024-02-18 09:43:47 --> Helper loaded: url_helper
INFO - 2024-02-18 09:43:47 --> Helper loaded: file_helper
INFO - 2024-02-18 09:43:47 --> Helper loaded: html_helper
INFO - 2024-02-18 09:43:47 --> Helper loaded: text_helper
INFO - 2024-02-18 09:43:47 --> Helper loaded: form_helper
INFO - 2024-02-18 09:43:47 --> Helper loaded: lang_helper
INFO - 2024-02-18 09:43:47 --> Helper loaded: security_helper
INFO - 2024-02-18 09:43:47 --> Helper loaded: cookie_helper
INFO - 2024-02-18 09:43:47 --> Database Driver Class Initialized
INFO - 2024-02-18 09:43:47 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-18 09:43:47 --> Parser Class Initialized
INFO - 2024-02-18 09:43:47 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-18 09:43:47 --> Pagination Class Initialized
INFO - 2024-02-18 09:43:47 --> Form Validation Class Initialized
INFO - 2024-02-18 09:43:47 --> Controller Class Initialized
DEBUG - 2024-02-18 09:43:47 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-18 09:43:47 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-18 09:43:47 --> Model Class Initialized
DEBUG - 2024-02-18 09:43:47 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-18 09:43:47 --> Model Class Initialized
DEBUG - 2024-02-18 09:43:47 --> Auth class already loaded. Second attempt ignored.
ERROR - 2024-02-18 09:43:47 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-18 09:43:47 --> Config Class Initialized
INFO - 2024-02-18 09:43:47 --> Hooks Class Initialized
DEBUG - 2024-02-18 09:43:47 --> UTF-8 Support Enabled
INFO - 2024-02-18 09:43:47 --> Utf8 Class Initialized
INFO - 2024-02-18 09:43:47 --> URI Class Initialized
INFO - 2024-02-18 09:43:47 --> Router Class Initialized
INFO - 2024-02-18 09:43:47 --> Output Class Initialized
INFO - 2024-02-18 09:43:47 --> Security Class Initialized
DEBUG - 2024-02-18 09:43:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-18 09:43:47 --> Input Class Initialized
INFO - 2024-02-18 09:43:47 --> Language Class Initialized
INFO - 2024-02-18 09:43:47 --> Loader Class Initialized
INFO - 2024-02-18 09:43:47 --> Helper loaded: url_helper
INFO - 2024-02-18 09:43:47 --> Helper loaded: file_helper
INFO - 2024-02-18 09:43:47 --> Helper loaded: html_helper
INFO - 2024-02-18 09:43:47 --> Helper loaded: text_helper
INFO - 2024-02-18 09:43:47 --> Helper loaded: form_helper
INFO - 2024-02-18 09:43:47 --> Helper loaded: lang_helper
INFO - 2024-02-18 09:43:47 --> Helper loaded: security_helper
INFO - 2024-02-18 09:43:47 --> Helper loaded: cookie_helper
INFO - 2024-02-18 09:43:47 --> Database Driver Class Initialized
INFO - 2024-02-18 09:43:47 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-18 09:43:47 --> Parser Class Initialized
INFO - 2024-02-18 09:43:47 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-18 09:43:47 --> Pagination Class Initialized
INFO - 2024-02-18 09:43:47 --> Form Validation Class Initialized
INFO - 2024-02-18 09:43:47 --> Controller Class Initialized
DEBUG - 2024-02-18 09:43:47 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-18 09:43:47 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-18 09:43:47 --> Model Class Initialized
DEBUG - 2024-02-18 09:43:47 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-18 09:43:47 --> Model Class Initialized
INFO - 2024-02-18 09:43:47 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/customer/add_customer_form.php
DEBUG - 2024-02-18 09:43:47 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-02-18 09:43:47 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-02-18 09:43:47 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-02-18 09:43:47 --> Model Class Initialized
INFO - 2024-02-18 09:43:47 --> Model Class Initialized
INFO - 2024-02-18 09:43:47 --> Model Class Initialized
INFO - 2024-02-18 09:43:47 --> Model Class Initialized
INFO - 2024-02-18 09:43:47 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-02-18 09:43:47 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-02-18 09:43:47 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-02-18 09:43:47 --> Final output sent to browser
DEBUG - 2024-02-18 09:43:47 --> Total execution time: 0.1898
ERROR - 2024-02-18 09:52:21 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-18 09:52:21 --> Config Class Initialized
INFO - 2024-02-18 09:52:21 --> Hooks Class Initialized
DEBUG - 2024-02-18 09:52:21 --> UTF-8 Support Enabled
INFO - 2024-02-18 09:52:21 --> Utf8 Class Initialized
INFO - 2024-02-18 09:52:21 --> URI Class Initialized
DEBUG - 2024-02-18 09:52:21 --> No URI present. Default controller set.
INFO - 2024-02-18 09:52:21 --> Router Class Initialized
INFO - 2024-02-18 09:52:21 --> Output Class Initialized
INFO - 2024-02-18 09:52:21 --> Security Class Initialized
DEBUG - 2024-02-18 09:52:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-18 09:52:21 --> Input Class Initialized
INFO - 2024-02-18 09:52:21 --> Language Class Initialized
INFO - 2024-02-18 09:52:21 --> Loader Class Initialized
INFO - 2024-02-18 09:52:21 --> Helper loaded: url_helper
INFO - 2024-02-18 09:52:21 --> Helper loaded: file_helper
INFO - 2024-02-18 09:52:21 --> Helper loaded: html_helper
INFO - 2024-02-18 09:52:21 --> Helper loaded: text_helper
INFO - 2024-02-18 09:52:21 --> Helper loaded: form_helper
INFO - 2024-02-18 09:52:21 --> Helper loaded: lang_helper
INFO - 2024-02-18 09:52:21 --> Helper loaded: security_helper
INFO - 2024-02-18 09:52:21 --> Helper loaded: cookie_helper
INFO - 2024-02-18 09:52:21 --> Database Driver Class Initialized
INFO - 2024-02-18 09:52:21 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-18 09:52:21 --> Parser Class Initialized
INFO - 2024-02-18 09:52:21 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-18 09:52:21 --> Pagination Class Initialized
INFO - 2024-02-18 09:52:21 --> Form Validation Class Initialized
INFO - 2024-02-18 09:52:21 --> Controller Class Initialized
INFO - 2024-02-18 09:52:21 --> Model Class Initialized
DEBUG - 2024-02-18 09:52:21 --> Session class already loaded. Second attempt ignored.
ERROR - 2024-02-18 09:52:21 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-18 09:52:21 --> Config Class Initialized
INFO - 2024-02-18 09:52:21 --> Hooks Class Initialized
DEBUG - 2024-02-18 09:52:21 --> UTF-8 Support Enabled
INFO - 2024-02-18 09:52:21 --> Utf8 Class Initialized
INFO - 2024-02-18 09:52:21 --> URI Class Initialized
INFO - 2024-02-18 09:52:21 --> Router Class Initialized
INFO - 2024-02-18 09:52:21 --> Output Class Initialized
INFO - 2024-02-18 09:52:21 --> Security Class Initialized
DEBUG - 2024-02-18 09:52:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-18 09:52:21 --> Input Class Initialized
INFO - 2024-02-18 09:52:21 --> Language Class Initialized
INFO - 2024-02-18 09:52:21 --> Loader Class Initialized
INFO - 2024-02-18 09:52:21 --> Helper loaded: url_helper
INFO - 2024-02-18 09:52:21 --> Helper loaded: file_helper
INFO - 2024-02-18 09:52:21 --> Helper loaded: html_helper
INFO - 2024-02-18 09:52:21 --> Helper loaded: text_helper
INFO - 2024-02-18 09:52:21 --> Helper loaded: form_helper
INFO - 2024-02-18 09:52:21 --> Helper loaded: lang_helper
INFO - 2024-02-18 09:52:21 --> Helper loaded: security_helper
INFO - 2024-02-18 09:52:21 --> Helper loaded: cookie_helper
INFO - 2024-02-18 09:52:21 --> Database Driver Class Initialized
INFO - 2024-02-18 09:52:21 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-18 09:52:21 --> Parser Class Initialized
INFO - 2024-02-18 09:52:21 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-18 09:52:21 --> Pagination Class Initialized
INFO - 2024-02-18 09:52:21 --> Form Validation Class Initialized
INFO - 2024-02-18 09:52:21 --> Controller Class Initialized
INFO - 2024-02-18 09:52:21 --> Model Class Initialized
DEBUG - 2024-02-18 09:52:21 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-18 09:52:21 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2024-02-18 09:52:21 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-02-18 09:52:21 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-02-18 09:52:21 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-02-18 09:52:21 --> Model Class Initialized
INFO - 2024-02-18 09:52:21 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-02-18 09:52:21 --> Final output sent to browser
DEBUG - 2024-02-18 09:52:21 --> Total execution time: 0.0362
ERROR - 2024-02-18 09:52:54 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-18 09:52:54 --> Config Class Initialized
INFO - 2024-02-18 09:52:54 --> Hooks Class Initialized
DEBUG - 2024-02-18 09:52:54 --> UTF-8 Support Enabled
INFO - 2024-02-18 09:52:54 --> Utf8 Class Initialized
INFO - 2024-02-18 09:52:54 --> URI Class Initialized
INFO - 2024-02-18 09:52:54 --> Router Class Initialized
INFO - 2024-02-18 09:52:54 --> Output Class Initialized
INFO - 2024-02-18 09:52:54 --> Security Class Initialized
DEBUG - 2024-02-18 09:52:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-18 09:52:54 --> Input Class Initialized
INFO - 2024-02-18 09:52:54 --> Language Class Initialized
INFO - 2024-02-18 09:52:54 --> Loader Class Initialized
INFO - 2024-02-18 09:52:54 --> Helper loaded: url_helper
INFO - 2024-02-18 09:52:54 --> Helper loaded: file_helper
INFO - 2024-02-18 09:52:54 --> Helper loaded: html_helper
INFO - 2024-02-18 09:52:54 --> Helper loaded: text_helper
INFO - 2024-02-18 09:52:54 --> Helper loaded: form_helper
INFO - 2024-02-18 09:52:54 --> Helper loaded: lang_helper
INFO - 2024-02-18 09:52:54 --> Helper loaded: security_helper
INFO - 2024-02-18 09:52:54 --> Helper loaded: cookie_helper
INFO - 2024-02-18 09:52:54 --> Database Driver Class Initialized
INFO - 2024-02-18 09:52:54 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-18 09:52:54 --> Parser Class Initialized
INFO - 2024-02-18 09:52:54 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-18 09:52:54 --> Pagination Class Initialized
INFO - 2024-02-18 09:52:54 --> Form Validation Class Initialized
INFO - 2024-02-18 09:52:54 --> Controller Class Initialized
INFO - 2024-02-18 09:52:54 --> Model Class Initialized
DEBUG - 2024-02-18 09:52:54 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-18 09:52:54 --> Model Class Initialized
INFO - 2024-02-18 09:52:54 --> Final output sent to browser
DEBUG - 2024-02-18 09:52:54 --> Total execution time: 0.0216
ERROR - 2024-02-18 09:52:54 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-18 09:52:54 --> Config Class Initialized
INFO - 2024-02-18 09:52:54 --> Hooks Class Initialized
DEBUG - 2024-02-18 09:52:54 --> UTF-8 Support Enabled
INFO - 2024-02-18 09:52:54 --> Utf8 Class Initialized
INFO - 2024-02-18 09:52:54 --> URI Class Initialized
INFO - 2024-02-18 09:52:54 --> Router Class Initialized
INFO - 2024-02-18 09:52:54 --> Output Class Initialized
INFO - 2024-02-18 09:52:54 --> Security Class Initialized
DEBUG - 2024-02-18 09:52:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-18 09:52:54 --> Input Class Initialized
INFO - 2024-02-18 09:52:54 --> Language Class Initialized
INFO - 2024-02-18 09:52:54 --> Loader Class Initialized
INFO - 2024-02-18 09:52:54 --> Helper loaded: url_helper
INFO - 2024-02-18 09:52:54 --> Helper loaded: file_helper
INFO - 2024-02-18 09:52:54 --> Helper loaded: html_helper
INFO - 2024-02-18 09:52:54 --> Helper loaded: text_helper
INFO - 2024-02-18 09:52:54 --> Helper loaded: form_helper
INFO - 2024-02-18 09:52:54 --> Helper loaded: lang_helper
INFO - 2024-02-18 09:52:54 --> Helper loaded: security_helper
INFO - 2024-02-18 09:52:54 --> Helper loaded: cookie_helper
INFO - 2024-02-18 09:52:54 --> Database Driver Class Initialized
INFO - 2024-02-18 09:52:54 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-18 09:52:54 --> Parser Class Initialized
INFO - 2024-02-18 09:52:54 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-18 09:52:54 --> Pagination Class Initialized
INFO - 2024-02-18 09:52:54 --> Form Validation Class Initialized
INFO - 2024-02-18 09:52:54 --> Controller Class Initialized
INFO - 2024-02-18 09:52:54 --> Model Class Initialized
DEBUG - 2024-02-18 09:52:54 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-18 09:52:54 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2024-02-18 09:52:54 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-02-18 09:52:54 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-02-18 09:52:54 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-02-18 09:52:54 --> Model Class Initialized
INFO - 2024-02-18 09:52:54 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-02-18 09:52:54 --> Final output sent to browser
DEBUG - 2024-02-18 09:52:54 --> Total execution time: 0.0320
ERROR - 2024-02-18 09:53:11 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-18 09:53:11 --> Config Class Initialized
INFO - 2024-02-18 09:53:11 --> Hooks Class Initialized
DEBUG - 2024-02-18 09:53:11 --> UTF-8 Support Enabled
INFO - 2024-02-18 09:53:11 --> Utf8 Class Initialized
INFO - 2024-02-18 09:53:11 --> URI Class Initialized
INFO - 2024-02-18 09:53:11 --> Router Class Initialized
INFO - 2024-02-18 09:53:11 --> Output Class Initialized
INFO - 2024-02-18 09:53:11 --> Security Class Initialized
DEBUG - 2024-02-18 09:53:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-18 09:53:11 --> Input Class Initialized
INFO - 2024-02-18 09:53:11 --> Language Class Initialized
INFO - 2024-02-18 09:53:11 --> Loader Class Initialized
INFO - 2024-02-18 09:53:11 --> Helper loaded: url_helper
INFO - 2024-02-18 09:53:11 --> Helper loaded: file_helper
INFO - 2024-02-18 09:53:11 --> Helper loaded: html_helper
INFO - 2024-02-18 09:53:11 --> Helper loaded: text_helper
INFO - 2024-02-18 09:53:11 --> Helper loaded: form_helper
INFO - 2024-02-18 09:53:11 --> Helper loaded: lang_helper
INFO - 2024-02-18 09:53:11 --> Helper loaded: security_helper
INFO - 2024-02-18 09:53:11 --> Helper loaded: cookie_helper
INFO - 2024-02-18 09:53:11 --> Database Driver Class Initialized
INFO - 2024-02-18 09:53:11 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-18 09:53:11 --> Parser Class Initialized
INFO - 2024-02-18 09:53:11 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-18 09:53:11 --> Pagination Class Initialized
INFO - 2024-02-18 09:53:11 --> Form Validation Class Initialized
INFO - 2024-02-18 09:53:11 --> Controller Class Initialized
INFO - 2024-02-18 09:53:11 --> Model Class Initialized
DEBUG - 2024-02-18 09:53:11 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-18 09:53:11 --> Model Class Initialized
INFO - 2024-02-18 09:53:11 --> Final output sent to browser
DEBUG - 2024-02-18 09:53:11 --> Total execution time: 0.0190
ERROR - 2024-02-18 09:53:12 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-18 09:53:12 --> Config Class Initialized
INFO - 2024-02-18 09:53:12 --> Hooks Class Initialized
DEBUG - 2024-02-18 09:53:12 --> UTF-8 Support Enabled
INFO - 2024-02-18 09:53:12 --> Utf8 Class Initialized
INFO - 2024-02-18 09:53:12 --> URI Class Initialized
INFO - 2024-02-18 09:53:12 --> Router Class Initialized
INFO - 2024-02-18 09:53:12 --> Output Class Initialized
INFO - 2024-02-18 09:53:12 --> Security Class Initialized
DEBUG - 2024-02-18 09:53:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-18 09:53:12 --> Input Class Initialized
INFO - 2024-02-18 09:53:12 --> Language Class Initialized
INFO - 2024-02-18 09:53:12 --> Loader Class Initialized
INFO - 2024-02-18 09:53:12 --> Helper loaded: url_helper
INFO - 2024-02-18 09:53:12 --> Helper loaded: file_helper
INFO - 2024-02-18 09:53:12 --> Helper loaded: html_helper
INFO - 2024-02-18 09:53:12 --> Helper loaded: text_helper
INFO - 2024-02-18 09:53:12 --> Helper loaded: form_helper
INFO - 2024-02-18 09:53:12 --> Helper loaded: lang_helper
INFO - 2024-02-18 09:53:12 --> Helper loaded: security_helper
INFO - 2024-02-18 09:53:12 --> Helper loaded: cookie_helper
INFO - 2024-02-18 09:53:12 --> Database Driver Class Initialized
INFO - 2024-02-18 09:53:12 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-18 09:53:12 --> Parser Class Initialized
INFO - 2024-02-18 09:53:12 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-18 09:53:12 --> Pagination Class Initialized
INFO - 2024-02-18 09:53:12 --> Form Validation Class Initialized
INFO - 2024-02-18 09:53:12 --> Controller Class Initialized
INFO - 2024-02-18 09:53:12 --> Model Class Initialized
DEBUG - 2024-02-18 09:53:12 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-18 09:53:12 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2024-02-18 09:53:12 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-02-18 09:53:12 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-02-18 09:53:12 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-02-18 09:53:12 --> Model Class Initialized
INFO - 2024-02-18 09:53:12 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-02-18 09:53:12 --> Final output sent to browser
DEBUG - 2024-02-18 09:53:12 --> Total execution time: 0.0296
ERROR - 2024-02-18 09:53:37 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-18 09:53:37 --> Config Class Initialized
INFO - 2024-02-18 09:53:37 --> Hooks Class Initialized
DEBUG - 2024-02-18 09:53:37 --> UTF-8 Support Enabled
INFO - 2024-02-18 09:53:37 --> Utf8 Class Initialized
INFO - 2024-02-18 09:53:37 --> URI Class Initialized
INFO - 2024-02-18 09:53:37 --> Router Class Initialized
INFO - 2024-02-18 09:53:37 --> Output Class Initialized
INFO - 2024-02-18 09:53:37 --> Security Class Initialized
DEBUG - 2024-02-18 09:53:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-18 09:53:37 --> Input Class Initialized
INFO - 2024-02-18 09:53:37 --> Language Class Initialized
INFO - 2024-02-18 09:53:37 --> Loader Class Initialized
INFO - 2024-02-18 09:53:37 --> Helper loaded: url_helper
INFO - 2024-02-18 09:53:37 --> Helper loaded: file_helper
INFO - 2024-02-18 09:53:37 --> Helper loaded: html_helper
INFO - 2024-02-18 09:53:37 --> Helper loaded: text_helper
INFO - 2024-02-18 09:53:37 --> Helper loaded: form_helper
INFO - 2024-02-18 09:53:37 --> Helper loaded: lang_helper
INFO - 2024-02-18 09:53:37 --> Helper loaded: security_helper
INFO - 2024-02-18 09:53:37 --> Helper loaded: cookie_helper
INFO - 2024-02-18 09:53:37 --> Database Driver Class Initialized
INFO - 2024-02-18 09:53:37 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-18 09:53:37 --> Parser Class Initialized
INFO - 2024-02-18 09:53:37 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-18 09:53:37 --> Pagination Class Initialized
INFO - 2024-02-18 09:53:37 --> Form Validation Class Initialized
INFO - 2024-02-18 09:53:37 --> Controller Class Initialized
INFO - 2024-02-18 09:53:37 --> Model Class Initialized
DEBUG - 2024-02-18 09:53:37 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-18 09:53:37 --> Model Class Initialized
INFO - 2024-02-18 09:53:37 --> Final output sent to browser
DEBUG - 2024-02-18 09:53:37 --> Total execution time: 0.0190
ERROR - 2024-02-18 09:53:38 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-18 09:53:38 --> Config Class Initialized
INFO - 2024-02-18 09:53:38 --> Hooks Class Initialized
DEBUG - 2024-02-18 09:53:38 --> UTF-8 Support Enabled
INFO - 2024-02-18 09:53:38 --> Utf8 Class Initialized
INFO - 2024-02-18 09:53:38 --> URI Class Initialized
INFO - 2024-02-18 09:53:38 --> Router Class Initialized
INFO - 2024-02-18 09:53:38 --> Output Class Initialized
INFO - 2024-02-18 09:53:38 --> Security Class Initialized
DEBUG - 2024-02-18 09:53:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-18 09:53:38 --> Input Class Initialized
INFO - 2024-02-18 09:53:38 --> Language Class Initialized
INFO - 2024-02-18 09:53:38 --> Loader Class Initialized
INFO - 2024-02-18 09:53:38 --> Helper loaded: url_helper
INFO - 2024-02-18 09:53:38 --> Helper loaded: file_helper
INFO - 2024-02-18 09:53:38 --> Helper loaded: html_helper
INFO - 2024-02-18 09:53:38 --> Helper loaded: text_helper
INFO - 2024-02-18 09:53:38 --> Helper loaded: form_helper
INFO - 2024-02-18 09:53:38 --> Helper loaded: lang_helper
INFO - 2024-02-18 09:53:38 --> Helper loaded: security_helper
INFO - 2024-02-18 09:53:38 --> Helper loaded: cookie_helper
INFO - 2024-02-18 09:53:38 --> Database Driver Class Initialized
INFO - 2024-02-18 09:53:38 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-18 09:53:38 --> Parser Class Initialized
INFO - 2024-02-18 09:53:38 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-18 09:53:38 --> Pagination Class Initialized
INFO - 2024-02-18 09:53:38 --> Form Validation Class Initialized
INFO - 2024-02-18 09:53:38 --> Controller Class Initialized
INFO - 2024-02-18 09:53:38 --> Model Class Initialized
DEBUG - 2024-02-18 09:53:38 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-18 09:53:38 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2024-02-18 09:53:38 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-02-18 09:53:38 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-02-18 09:53:38 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-02-18 09:53:38 --> Model Class Initialized
INFO - 2024-02-18 09:53:38 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-02-18 09:53:38 --> Final output sent to browser
DEBUG - 2024-02-18 09:53:38 --> Total execution time: 0.0282
ERROR - 2024-02-18 09:54:05 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-18 09:54:05 --> Config Class Initialized
INFO - 2024-02-18 09:54:05 --> Hooks Class Initialized
DEBUG - 2024-02-18 09:54:05 --> UTF-8 Support Enabled
INFO - 2024-02-18 09:54:05 --> Utf8 Class Initialized
INFO - 2024-02-18 09:54:05 --> URI Class Initialized
INFO - 2024-02-18 09:54:05 --> Router Class Initialized
INFO - 2024-02-18 09:54:05 --> Output Class Initialized
INFO - 2024-02-18 09:54:05 --> Security Class Initialized
DEBUG - 2024-02-18 09:54:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-18 09:54:05 --> Input Class Initialized
INFO - 2024-02-18 09:54:05 --> Language Class Initialized
INFO - 2024-02-18 09:54:05 --> Loader Class Initialized
INFO - 2024-02-18 09:54:05 --> Helper loaded: url_helper
INFO - 2024-02-18 09:54:05 --> Helper loaded: file_helper
INFO - 2024-02-18 09:54:05 --> Helper loaded: html_helper
INFO - 2024-02-18 09:54:05 --> Helper loaded: text_helper
INFO - 2024-02-18 09:54:05 --> Helper loaded: form_helper
INFO - 2024-02-18 09:54:05 --> Helper loaded: lang_helper
INFO - 2024-02-18 09:54:05 --> Helper loaded: security_helper
INFO - 2024-02-18 09:54:05 --> Helper loaded: cookie_helper
INFO - 2024-02-18 09:54:05 --> Database Driver Class Initialized
INFO - 2024-02-18 09:54:05 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-18 09:54:05 --> Parser Class Initialized
INFO - 2024-02-18 09:54:05 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-18 09:54:05 --> Pagination Class Initialized
INFO - 2024-02-18 09:54:05 --> Form Validation Class Initialized
INFO - 2024-02-18 09:54:05 --> Controller Class Initialized
INFO - 2024-02-18 09:54:05 --> Model Class Initialized
DEBUG - 2024-02-18 09:54:05 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-18 09:54:05 --> Model Class Initialized
INFO - 2024-02-18 09:54:05 --> Final output sent to browser
DEBUG - 2024-02-18 09:54:05 --> Total execution time: 0.0209
ERROR - 2024-02-18 09:54:06 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-18 09:54:06 --> Config Class Initialized
INFO - 2024-02-18 09:54:06 --> Hooks Class Initialized
DEBUG - 2024-02-18 09:54:06 --> UTF-8 Support Enabled
INFO - 2024-02-18 09:54:06 --> Utf8 Class Initialized
INFO - 2024-02-18 09:54:06 --> URI Class Initialized
INFO - 2024-02-18 09:54:06 --> Router Class Initialized
INFO - 2024-02-18 09:54:06 --> Output Class Initialized
INFO - 2024-02-18 09:54:06 --> Security Class Initialized
DEBUG - 2024-02-18 09:54:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-18 09:54:06 --> Input Class Initialized
INFO - 2024-02-18 09:54:06 --> Language Class Initialized
INFO - 2024-02-18 09:54:06 --> Loader Class Initialized
INFO - 2024-02-18 09:54:06 --> Helper loaded: url_helper
INFO - 2024-02-18 09:54:06 --> Helper loaded: file_helper
INFO - 2024-02-18 09:54:06 --> Helper loaded: html_helper
INFO - 2024-02-18 09:54:06 --> Helper loaded: text_helper
INFO - 2024-02-18 09:54:06 --> Helper loaded: form_helper
INFO - 2024-02-18 09:54:06 --> Helper loaded: lang_helper
INFO - 2024-02-18 09:54:06 --> Helper loaded: security_helper
INFO - 2024-02-18 09:54:06 --> Helper loaded: cookie_helper
INFO - 2024-02-18 09:54:06 --> Database Driver Class Initialized
INFO - 2024-02-18 09:54:06 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-18 09:54:06 --> Parser Class Initialized
INFO - 2024-02-18 09:54:06 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-18 09:54:06 --> Pagination Class Initialized
INFO - 2024-02-18 09:54:06 --> Form Validation Class Initialized
INFO - 2024-02-18 09:54:06 --> Controller Class Initialized
INFO - 2024-02-18 09:54:06 --> Model Class Initialized
DEBUG - 2024-02-18 09:54:06 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-18 09:54:06 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2024-02-18 09:54:06 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-02-18 09:54:06 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-02-18 09:54:06 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-02-18 09:54:06 --> Model Class Initialized
INFO - 2024-02-18 09:54:06 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-02-18 09:54:06 --> Final output sent to browser
DEBUG - 2024-02-18 09:54:06 --> Total execution time: 0.0374
ERROR - 2024-02-18 09:54:31 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-18 09:54:31 --> Config Class Initialized
INFO - 2024-02-18 09:54:31 --> Hooks Class Initialized
DEBUG - 2024-02-18 09:54:31 --> UTF-8 Support Enabled
INFO - 2024-02-18 09:54:31 --> Utf8 Class Initialized
INFO - 2024-02-18 09:54:31 --> URI Class Initialized
INFO - 2024-02-18 09:54:31 --> Router Class Initialized
INFO - 2024-02-18 09:54:31 --> Output Class Initialized
INFO - 2024-02-18 09:54:31 --> Security Class Initialized
DEBUG - 2024-02-18 09:54:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-18 09:54:31 --> Input Class Initialized
INFO - 2024-02-18 09:54:31 --> Language Class Initialized
INFO - 2024-02-18 09:54:31 --> Loader Class Initialized
INFO - 2024-02-18 09:54:31 --> Helper loaded: url_helper
INFO - 2024-02-18 09:54:31 --> Helper loaded: file_helper
INFO - 2024-02-18 09:54:31 --> Helper loaded: html_helper
INFO - 2024-02-18 09:54:31 --> Helper loaded: text_helper
INFO - 2024-02-18 09:54:31 --> Helper loaded: form_helper
INFO - 2024-02-18 09:54:31 --> Helper loaded: lang_helper
INFO - 2024-02-18 09:54:31 --> Helper loaded: security_helper
INFO - 2024-02-18 09:54:31 --> Helper loaded: cookie_helper
INFO - 2024-02-18 09:54:31 --> Database Driver Class Initialized
INFO - 2024-02-18 09:54:31 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-18 09:54:31 --> Parser Class Initialized
INFO - 2024-02-18 09:54:31 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-18 09:54:31 --> Pagination Class Initialized
INFO - 2024-02-18 09:54:31 --> Form Validation Class Initialized
INFO - 2024-02-18 09:54:31 --> Controller Class Initialized
INFO - 2024-02-18 09:54:31 --> Model Class Initialized
DEBUG - 2024-02-18 09:54:31 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-18 09:54:31 --> Model Class Initialized
INFO - 2024-02-18 09:54:31 --> Final output sent to browser
DEBUG - 2024-02-18 09:54:31 --> Total execution time: 0.0193
ERROR - 2024-02-18 09:54:31 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-18 09:54:31 --> Config Class Initialized
INFO - 2024-02-18 09:54:31 --> Hooks Class Initialized
DEBUG - 2024-02-18 09:54:31 --> UTF-8 Support Enabled
INFO - 2024-02-18 09:54:31 --> Utf8 Class Initialized
INFO - 2024-02-18 09:54:31 --> URI Class Initialized
INFO - 2024-02-18 09:54:31 --> Router Class Initialized
INFO - 2024-02-18 09:54:31 --> Output Class Initialized
INFO - 2024-02-18 09:54:31 --> Security Class Initialized
DEBUG - 2024-02-18 09:54:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-18 09:54:31 --> Input Class Initialized
INFO - 2024-02-18 09:54:31 --> Language Class Initialized
INFO - 2024-02-18 09:54:31 --> Loader Class Initialized
INFO - 2024-02-18 09:54:31 --> Helper loaded: url_helper
INFO - 2024-02-18 09:54:31 --> Helper loaded: file_helper
INFO - 2024-02-18 09:54:31 --> Helper loaded: html_helper
INFO - 2024-02-18 09:54:31 --> Helper loaded: text_helper
INFO - 2024-02-18 09:54:31 --> Helper loaded: form_helper
INFO - 2024-02-18 09:54:31 --> Helper loaded: lang_helper
INFO - 2024-02-18 09:54:31 --> Helper loaded: security_helper
INFO - 2024-02-18 09:54:31 --> Helper loaded: cookie_helper
INFO - 2024-02-18 09:54:31 --> Database Driver Class Initialized
INFO - 2024-02-18 09:54:31 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-18 09:54:31 --> Parser Class Initialized
INFO - 2024-02-18 09:54:31 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-18 09:54:31 --> Pagination Class Initialized
INFO - 2024-02-18 09:54:31 --> Form Validation Class Initialized
INFO - 2024-02-18 09:54:31 --> Controller Class Initialized
INFO - 2024-02-18 09:54:31 --> Model Class Initialized
DEBUG - 2024-02-18 09:54:31 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-18 09:54:31 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2024-02-18 09:54:31 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-02-18 09:54:31 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-02-18 09:54:31 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-02-18 09:54:31 --> Model Class Initialized
INFO - 2024-02-18 09:54:31 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-02-18 09:54:31 --> Final output sent to browser
DEBUG - 2024-02-18 09:54:31 --> Total execution time: 0.0331
ERROR - 2024-02-18 11:21:16 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-18 11:21:16 --> Config Class Initialized
INFO - 2024-02-18 11:21:16 --> Hooks Class Initialized
DEBUG - 2024-02-18 11:21:16 --> UTF-8 Support Enabled
INFO - 2024-02-18 11:21:16 --> Utf8 Class Initialized
INFO - 2024-02-18 11:21:16 --> URI Class Initialized
DEBUG - 2024-02-18 11:21:16 --> No URI present. Default controller set.
INFO - 2024-02-18 11:21:16 --> Router Class Initialized
INFO - 2024-02-18 11:21:16 --> Output Class Initialized
INFO - 2024-02-18 11:21:16 --> Security Class Initialized
DEBUG - 2024-02-18 11:21:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-18 11:21:16 --> Input Class Initialized
INFO - 2024-02-18 11:21:16 --> Language Class Initialized
INFO - 2024-02-18 11:21:16 --> Loader Class Initialized
INFO - 2024-02-18 11:21:16 --> Helper loaded: url_helper
INFO - 2024-02-18 11:21:16 --> Helper loaded: file_helper
INFO - 2024-02-18 11:21:16 --> Helper loaded: html_helper
INFO - 2024-02-18 11:21:16 --> Helper loaded: text_helper
INFO - 2024-02-18 11:21:16 --> Helper loaded: form_helper
INFO - 2024-02-18 11:21:16 --> Helper loaded: lang_helper
INFO - 2024-02-18 11:21:16 --> Helper loaded: security_helper
INFO - 2024-02-18 11:21:16 --> Helper loaded: cookie_helper
INFO - 2024-02-18 11:21:16 --> Database Driver Class Initialized
INFO - 2024-02-18 11:21:16 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-18 11:21:16 --> Parser Class Initialized
INFO - 2024-02-18 11:21:16 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-18 11:21:16 --> Pagination Class Initialized
INFO - 2024-02-18 11:21:16 --> Form Validation Class Initialized
INFO - 2024-02-18 11:21:16 --> Controller Class Initialized
INFO - 2024-02-18 11:21:16 --> Model Class Initialized
DEBUG - 2024-02-18 11:21:16 --> Session class already loaded. Second attempt ignored.
ERROR - 2024-02-18 11:21:16 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-18 11:21:16 --> Config Class Initialized
INFO - 2024-02-18 11:21:16 --> Hooks Class Initialized
DEBUG - 2024-02-18 11:21:16 --> UTF-8 Support Enabled
INFO - 2024-02-18 11:21:16 --> Utf8 Class Initialized
INFO - 2024-02-18 11:21:16 --> URI Class Initialized
INFO - 2024-02-18 11:21:16 --> Router Class Initialized
INFO - 2024-02-18 11:21:16 --> Output Class Initialized
INFO - 2024-02-18 11:21:16 --> Security Class Initialized
DEBUG - 2024-02-18 11:21:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-18 11:21:16 --> Input Class Initialized
INFO - 2024-02-18 11:21:16 --> Language Class Initialized
INFO - 2024-02-18 11:21:16 --> Loader Class Initialized
INFO - 2024-02-18 11:21:16 --> Helper loaded: url_helper
INFO - 2024-02-18 11:21:16 --> Helper loaded: file_helper
INFO - 2024-02-18 11:21:16 --> Helper loaded: html_helper
INFO - 2024-02-18 11:21:16 --> Helper loaded: text_helper
INFO - 2024-02-18 11:21:16 --> Helper loaded: form_helper
INFO - 2024-02-18 11:21:16 --> Helper loaded: lang_helper
INFO - 2024-02-18 11:21:16 --> Helper loaded: security_helper
INFO - 2024-02-18 11:21:16 --> Helper loaded: cookie_helper
INFO - 2024-02-18 11:21:16 --> Database Driver Class Initialized
INFO - 2024-02-18 11:21:16 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-18 11:21:16 --> Parser Class Initialized
INFO - 2024-02-18 11:21:16 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-18 11:21:16 --> Pagination Class Initialized
INFO - 2024-02-18 11:21:16 --> Form Validation Class Initialized
INFO - 2024-02-18 11:21:16 --> Controller Class Initialized
INFO - 2024-02-18 11:21:16 --> Model Class Initialized
DEBUG - 2024-02-18 11:21:16 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-18 11:21:17 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2024-02-18 11:21:17 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-02-18 11:21:17 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-02-18 11:21:17 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-02-18 11:21:17 --> Model Class Initialized
INFO - 2024-02-18 11:21:17 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-02-18 11:21:17 --> Final output sent to browser
DEBUG - 2024-02-18 11:21:17 --> Total execution time: 0.0313
ERROR - 2024-02-18 11:21:24 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-18 11:21:24 --> Config Class Initialized
INFO - 2024-02-18 11:21:24 --> Hooks Class Initialized
DEBUG - 2024-02-18 11:21:24 --> UTF-8 Support Enabled
INFO - 2024-02-18 11:21:24 --> Utf8 Class Initialized
INFO - 2024-02-18 11:21:24 --> URI Class Initialized
INFO - 2024-02-18 11:21:24 --> Router Class Initialized
INFO - 2024-02-18 11:21:24 --> Output Class Initialized
INFO - 2024-02-18 11:21:24 --> Security Class Initialized
DEBUG - 2024-02-18 11:21:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-18 11:21:24 --> Input Class Initialized
INFO - 2024-02-18 11:21:24 --> Language Class Initialized
INFO - 2024-02-18 11:21:24 --> Loader Class Initialized
INFO - 2024-02-18 11:21:24 --> Helper loaded: url_helper
INFO - 2024-02-18 11:21:24 --> Helper loaded: file_helper
INFO - 2024-02-18 11:21:24 --> Helper loaded: html_helper
INFO - 2024-02-18 11:21:24 --> Helper loaded: text_helper
INFO - 2024-02-18 11:21:24 --> Helper loaded: form_helper
INFO - 2024-02-18 11:21:24 --> Helper loaded: lang_helper
INFO - 2024-02-18 11:21:24 --> Helper loaded: security_helper
INFO - 2024-02-18 11:21:24 --> Helper loaded: cookie_helper
INFO - 2024-02-18 11:21:24 --> Database Driver Class Initialized
INFO - 2024-02-18 11:21:24 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-18 11:21:24 --> Parser Class Initialized
INFO - 2024-02-18 11:21:24 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-18 11:21:24 --> Pagination Class Initialized
INFO - 2024-02-18 11:21:24 --> Form Validation Class Initialized
INFO - 2024-02-18 11:21:24 --> Controller Class Initialized
INFO - 2024-02-18 11:21:24 --> Model Class Initialized
DEBUG - 2024-02-18 11:21:24 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-18 11:21:24 --> Model Class Initialized
INFO - 2024-02-18 11:21:24 --> Final output sent to browser
DEBUG - 2024-02-18 11:21:24 --> Total execution time: 0.0179
ERROR - 2024-02-18 11:21:24 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-18 11:21:24 --> Config Class Initialized
INFO - 2024-02-18 11:21:24 --> Hooks Class Initialized
DEBUG - 2024-02-18 11:21:24 --> UTF-8 Support Enabled
INFO - 2024-02-18 11:21:24 --> Utf8 Class Initialized
INFO - 2024-02-18 11:21:24 --> URI Class Initialized
DEBUG - 2024-02-18 11:21:24 --> No URI present. Default controller set.
INFO - 2024-02-18 11:21:24 --> Router Class Initialized
INFO - 2024-02-18 11:21:24 --> Output Class Initialized
INFO - 2024-02-18 11:21:24 --> Security Class Initialized
DEBUG - 2024-02-18 11:21:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-18 11:21:24 --> Input Class Initialized
INFO - 2024-02-18 11:21:24 --> Language Class Initialized
INFO - 2024-02-18 11:21:24 --> Loader Class Initialized
INFO - 2024-02-18 11:21:24 --> Helper loaded: url_helper
INFO - 2024-02-18 11:21:24 --> Helper loaded: file_helper
INFO - 2024-02-18 11:21:24 --> Helper loaded: html_helper
INFO - 2024-02-18 11:21:24 --> Helper loaded: text_helper
INFO - 2024-02-18 11:21:24 --> Helper loaded: form_helper
INFO - 2024-02-18 11:21:24 --> Helper loaded: lang_helper
INFO - 2024-02-18 11:21:24 --> Helper loaded: security_helper
INFO - 2024-02-18 11:21:24 --> Helper loaded: cookie_helper
INFO - 2024-02-18 11:21:24 --> Database Driver Class Initialized
INFO - 2024-02-18 11:21:24 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-18 11:21:24 --> Parser Class Initialized
INFO - 2024-02-18 11:21:24 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-18 11:21:24 --> Pagination Class Initialized
INFO - 2024-02-18 11:21:24 --> Form Validation Class Initialized
INFO - 2024-02-18 11:21:24 --> Controller Class Initialized
INFO - 2024-02-18 11:21:24 --> Model Class Initialized
DEBUG - 2024-02-18 11:21:24 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-18 11:21:24 --> Model Class Initialized
DEBUG - 2024-02-18 11:21:24 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-18 11:21:24 --> Model Class Initialized
INFO - 2024-02-18 11:21:24 --> Model Class Initialized
INFO - 2024-02-18 11:21:24 --> Model Class Initialized
INFO - 2024-02-18 11:21:24 --> Model Class Initialized
DEBUG - 2024-02-18 11:21:24 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-18 11:21:24 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-18 11:21:24 --> Model Class Initialized
INFO - 2024-02-18 11:21:24 --> Model Class Initialized
INFO - 2024-02-18 11:21:24 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2024-02-18 11:21:24 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-02-18 11:21:24 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-02-18 11:21:24 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-02-18 11:21:24 --> Model Class Initialized
INFO - 2024-02-18 11:21:25 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-02-18 11:21:25 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-02-18 11:21:25 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-02-18 11:21:25 --> Final output sent to browser
DEBUG - 2024-02-18 11:21:25 --> Total execution time: 0.3957
ERROR - 2024-02-18 11:21:26 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-18 11:21:26 --> Config Class Initialized
INFO - 2024-02-18 11:21:26 --> Hooks Class Initialized
DEBUG - 2024-02-18 11:21:26 --> UTF-8 Support Enabled
INFO - 2024-02-18 11:21:26 --> Utf8 Class Initialized
INFO - 2024-02-18 11:21:26 --> URI Class Initialized
INFO - 2024-02-18 11:21:26 --> Router Class Initialized
INFO - 2024-02-18 11:21:26 --> Output Class Initialized
INFO - 2024-02-18 11:21:26 --> Security Class Initialized
DEBUG - 2024-02-18 11:21:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-18 11:21:26 --> Input Class Initialized
INFO - 2024-02-18 11:21:26 --> Language Class Initialized
INFO - 2024-02-18 11:21:26 --> Loader Class Initialized
INFO - 2024-02-18 11:21:26 --> Helper loaded: url_helper
INFO - 2024-02-18 11:21:26 --> Helper loaded: file_helper
INFO - 2024-02-18 11:21:26 --> Helper loaded: html_helper
INFO - 2024-02-18 11:21:26 --> Helper loaded: text_helper
INFO - 2024-02-18 11:21:26 --> Helper loaded: form_helper
INFO - 2024-02-18 11:21:26 --> Helper loaded: lang_helper
INFO - 2024-02-18 11:21:26 --> Helper loaded: security_helper
INFO - 2024-02-18 11:21:26 --> Helper loaded: cookie_helper
INFO - 2024-02-18 11:21:26 --> Database Driver Class Initialized
INFO - 2024-02-18 11:21:26 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-18 11:21:26 --> Parser Class Initialized
INFO - 2024-02-18 11:21:26 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-18 11:21:26 --> Pagination Class Initialized
INFO - 2024-02-18 11:21:26 --> Form Validation Class Initialized
INFO - 2024-02-18 11:21:26 --> Controller Class Initialized
DEBUG - 2024-02-18 11:21:26 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-18 11:21:26 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-18 11:21:26 --> Model Class Initialized
INFO - 2024-02-18 11:21:26 --> Final output sent to browser
DEBUG - 2024-02-18 11:21:26 --> Total execution time: 0.0131
ERROR - 2024-02-18 11:21:52 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-18 11:21:52 --> Config Class Initialized
INFO - 2024-02-18 11:21:52 --> Hooks Class Initialized
DEBUG - 2024-02-18 11:21:52 --> UTF-8 Support Enabled
INFO - 2024-02-18 11:21:52 --> Utf8 Class Initialized
INFO - 2024-02-18 11:21:52 --> URI Class Initialized
INFO - 2024-02-18 11:21:52 --> Router Class Initialized
INFO - 2024-02-18 11:21:52 --> Output Class Initialized
INFO - 2024-02-18 11:21:52 --> Security Class Initialized
DEBUG - 2024-02-18 11:21:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-18 11:21:52 --> Input Class Initialized
INFO - 2024-02-18 11:21:52 --> Language Class Initialized
INFO - 2024-02-18 11:21:52 --> Loader Class Initialized
INFO - 2024-02-18 11:21:52 --> Helper loaded: url_helper
INFO - 2024-02-18 11:21:52 --> Helper loaded: file_helper
INFO - 2024-02-18 11:21:52 --> Helper loaded: html_helper
INFO - 2024-02-18 11:21:52 --> Helper loaded: text_helper
INFO - 2024-02-18 11:21:52 --> Helper loaded: form_helper
INFO - 2024-02-18 11:21:52 --> Helper loaded: lang_helper
INFO - 2024-02-18 11:21:52 --> Helper loaded: security_helper
INFO - 2024-02-18 11:21:52 --> Helper loaded: cookie_helper
INFO - 2024-02-18 11:21:52 --> Database Driver Class Initialized
INFO - 2024-02-18 11:21:52 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-18 11:21:52 --> Parser Class Initialized
INFO - 2024-02-18 11:21:52 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-18 11:21:52 --> Pagination Class Initialized
INFO - 2024-02-18 11:21:52 --> Form Validation Class Initialized
INFO - 2024-02-18 11:21:52 --> Controller Class Initialized
DEBUG - 2024-02-18 11:21:52 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-18 11:21:52 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-18 11:21:52 --> Model Class Initialized
DEBUG - 2024-02-18 11:21:52 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-18 11:21:52 --> Model Class Initialized
DEBUG - 2024-02-18 11:21:52 --> Lcustomer class already loaded. Second attempt ignored.
INFO - 2024-02-18 11:21:52 --> Model Class Initialized
INFO - 2024-02-18 11:21:52 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/customer/customer.php
DEBUG - 2024-02-18 11:21:52 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-02-18 11:21:52 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-02-18 11:21:52 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-02-18 11:21:52 --> Model Class Initialized
INFO - 2024-02-18 11:21:52 --> Model Class Initialized
INFO - 2024-02-18 11:21:52 --> Model Class Initialized
INFO - 2024-02-18 11:21:53 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-02-18 11:21:53 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-02-18 11:21:53 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-02-18 11:21:53 --> Final output sent to browser
DEBUG - 2024-02-18 11:21:53 --> Total execution time: 0.2223
ERROR - 2024-02-18 11:21:54 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-18 11:21:54 --> Config Class Initialized
INFO - 2024-02-18 11:21:54 --> Hooks Class Initialized
DEBUG - 2024-02-18 11:21:54 --> UTF-8 Support Enabled
INFO - 2024-02-18 11:21:54 --> Utf8 Class Initialized
INFO - 2024-02-18 11:21:54 --> URI Class Initialized
INFO - 2024-02-18 11:21:54 --> Router Class Initialized
INFO - 2024-02-18 11:21:54 --> Output Class Initialized
INFO - 2024-02-18 11:21:54 --> Security Class Initialized
DEBUG - 2024-02-18 11:21:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-18 11:21:54 --> Input Class Initialized
INFO - 2024-02-18 11:21:54 --> Language Class Initialized
INFO - 2024-02-18 11:21:54 --> Loader Class Initialized
INFO - 2024-02-18 11:21:54 --> Helper loaded: url_helper
INFO - 2024-02-18 11:21:54 --> Helper loaded: file_helper
INFO - 2024-02-18 11:21:54 --> Helper loaded: html_helper
INFO - 2024-02-18 11:21:54 --> Helper loaded: text_helper
INFO - 2024-02-18 11:21:54 --> Helper loaded: form_helper
INFO - 2024-02-18 11:21:54 --> Helper loaded: lang_helper
INFO - 2024-02-18 11:21:54 --> Helper loaded: security_helper
INFO - 2024-02-18 11:21:54 --> Helper loaded: cookie_helper
INFO - 2024-02-18 11:21:54 --> Database Driver Class Initialized
INFO - 2024-02-18 11:21:54 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-18 11:21:54 --> Parser Class Initialized
INFO - 2024-02-18 11:21:54 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-18 11:21:54 --> Pagination Class Initialized
INFO - 2024-02-18 11:21:54 --> Form Validation Class Initialized
INFO - 2024-02-18 11:21:54 --> Controller Class Initialized
DEBUG - 2024-02-18 11:21:54 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-18 11:21:54 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-18 11:21:54 --> Model Class Initialized
DEBUG - 2024-02-18 11:21:54 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-18 11:21:54 --> Model Class Initialized
INFO - 2024-02-18 11:21:54 --> Final output sent to browser
DEBUG - 2024-02-18 11:21:54 --> Total execution time: 0.0315
ERROR - 2024-02-18 11:22:09 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-18 11:22:09 --> Config Class Initialized
INFO - 2024-02-18 11:22:09 --> Hooks Class Initialized
DEBUG - 2024-02-18 11:22:09 --> UTF-8 Support Enabled
INFO - 2024-02-18 11:22:09 --> Utf8 Class Initialized
INFO - 2024-02-18 11:22:09 --> URI Class Initialized
INFO - 2024-02-18 11:22:09 --> Router Class Initialized
INFO - 2024-02-18 11:22:09 --> Output Class Initialized
INFO - 2024-02-18 11:22:09 --> Security Class Initialized
DEBUG - 2024-02-18 11:22:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-18 11:22:09 --> Input Class Initialized
INFO - 2024-02-18 11:22:09 --> Language Class Initialized
INFO - 2024-02-18 11:22:09 --> Loader Class Initialized
INFO - 2024-02-18 11:22:09 --> Helper loaded: url_helper
INFO - 2024-02-18 11:22:09 --> Helper loaded: file_helper
INFO - 2024-02-18 11:22:09 --> Helper loaded: html_helper
INFO - 2024-02-18 11:22:09 --> Helper loaded: text_helper
INFO - 2024-02-18 11:22:09 --> Helper loaded: form_helper
INFO - 2024-02-18 11:22:09 --> Helper loaded: lang_helper
INFO - 2024-02-18 11:22:09 --> Helper loaded: security_helper
INFO - 2024-02-18 11:22:09 --> Helper loaded: cookie_helper
INFO - 2024-02-18 11:22:09 --> Database Driver Class Initialized
INFO - 2024-02-18 11:22:09 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-18 11:22:09 --> Parser Class Initialized
INFO - 2024-02-18 11:22:09 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-18 11:22:09 --> Pagination Class Initialized
INFO - 2024-02-18 11:22:09 --> Form Validation Class Initialized
INFO - 2024-02-18 11:22:09 --> Controller Class Initialized
DEBUG - 2024-02-18 11:22:09 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-18 11:22:09 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-18 11:22:09 --> Model Class Initialized
DEBUG - 2024-02-18 11:22:09 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-18 11:22:09 --> Model Class Initialized
INFO - 2024-02-18 11:22:09 --> Final output sent to browser
DEBUG - 2024-02-18 11:22:09 --> Total execution time: 0.0358
ERROR - 2024-02-18 11:22:10 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-18 11:22:10 --> Config Class Initialized
INFO - 2024-02-18 11:22:10 --> Hooks Class Initialized
DEBUG - 2024-02-18 11:22:10 --> UTF-8 Support Enabled
INFO - 2024-02-18 11:22:10 --> Utf8 Class Initialized
INFO - 2024-02-18 11:22:10 --> URI Class Initialized
INFO - 2024-02-18 11:22:10 --> Router Class Initialized
INFO - 2024-02-18 11:22:10 --> Output Class Initialized
INFO - 2024-02-18 11:22:10 --> Security Class Initialized
DEBUG - 2024-02-18 11:22:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-18 11:22:10 --> Input Class Initialized
INFO - 2024-02-18 11:22:10 --> Language Class Initialized
INFO - 2024-02-18 11:22:10 --> Loader Class Initialized
INFO - 2024-02-18 11:22:10 --> Helper loaded: url_helper
INFO - 2024-02-18 11:22:10 --> Helper loaded: file_helper
INFO - 2024-02-18 11:22:10 --> Helper loaded: html_helper
INFO - 2024-02-18 11:22:10 --> Helper loaded: text_helper
INFO - 2024-02-18 11:22:10 --> Helper loaded: form_helper
INFO - 2024-02-18 11:22:10 --> Helper loaded: lang_helper
INFO - 2024-02-18 11:22:10 --> Helper loaded: security_helper
INFO - 2024-02-18 11:22:10 --> Helper loaded: cookie_helper
INFO - 2024-02-18 11:22:10 --> Database Driver Class Initialized
INFO - 2024-02-18 11:22:10 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-18 11:22:10 --> Parser Class Initialized
INFO - 2024-02-18 11:22:10 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-18 11:22:10 --> Pagination Class Initialized
INFO - 2024-02-18 11:22:10 --> Form Validation Class Initialized
INFO - 2024-02-18 11:22:10 --> Controller Class Initialized
DEBUG - 2024-02-18 11:22:10 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-18 11:22:10 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-18 11:22:10 --> Model Class Initialized
DEBUG - 2024-02-18 11:22:10 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-18 11:22:10 --> Model Class Initialized
INFO - 2024-02-18 11:22:10 --> Final output sent to browser
DEBUG - 2024-02-18 11:22:10 --> Total execution time: 0.0323
ERROR - 2024-02-18 11:22:12 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-18 11:22:12 --> Config Class Initialized
INFO - 2024-02-18 11:22:12 --> Hooks Class Initialized
DEBUG - 2024-02-18 11:22:12 --> UTF-8 Support Enabled
INFO - 2024-02-18 11:22:12 --> Utf8 Class Initialized
INFO - 2024-02-18 11:22:12 --> URI Class Initialized
INFO - 2024-02-18 11:22:12 --> Router Class Initialized
INFO - 2024-02-18 11:22:12 --> Output Class Initialized
INFO - 2024-02-18 11:22:12 --> Security Class Initialized
DEBUG - 2024-02-18 11:22:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-18 11:22:12 --> Input Class Initialized
INFO - 2024-02-18 11:22:12 --> Language Class Initialized
INFO - 2024-02-18 11:22:12 --> Loader Class Initialized
INFO - 2024-02-18 11:22:12 --> Helper loaded: url_helper
INFO - 2024-02-18 11:22:12 --> Helper loaded: file_helper
INFO - 2024-02-18 11:22:12 --> Helper loaded: html_helper
INFO - 2024-02-18 11:22:12 --> Helper loaded: text_helper
INFO - 2024-02-18 11:22:12 --> Helper loaded: form_helper
INFO - 2024-02-18 11:22:12 --> Helper loaded: lang_helper
INFO - 2024-02-18 11:22:12 --> Helper loaded: security_helper
INFO - 2024-02-18 11:22:12 --> Helper loaded: cookie_helper
INFO - 2024-02-18 11:22:12 --> Database Driver Class Initialized
INFO - 2024-02-18 11:22:12 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-18 11:22:12 --> Parser Class Initialized
INFO - 2024-02-18 11:22:12 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-18 11:22:12 --> Pagination Class Initialized
INFO - 2024-02-18 11:22:12 --> Form Validation Class Initialized
INFO - 2024-02-18 11:22:12 --> Controller Class Initialized
DEBUG - 2024-02-18 11:22:12 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-18 11:22:12 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-18 11:22:12 --> Model Class Initialized
DEBUG - 2024-02-18 11:22:12 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-18 11:22:12 --> Model Class Initialized
INFO - 2024-02-18 11:22:12 --> Final output sent to browser
DEBUG - 2024-02-18 11:22:12 --> Total execution time: 0.0342
ERROR - 2024-02-18 11:22:13 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-18 11:22:13 --> Config Class Initialized
INFO - 2024-02-18 11:22:13 --> Hooks Class Initialized
DEBUG - 2024-02-18 11:22:13 --> UTF-8 Support Enabled
INFO - 2024-02-18 11:22:13 --> Utf8 Class Initialized
INFO - 2024-02-18 11:22:13 --> URI Class Initialized
INFO - 2024-02-18 11:22:13 --> Router Class Initialized
INFO - 2024-02-18 11:22:13 --> Output Class Initialized
INFO - 2024-02-18 11:22:13 --> Security Class Initialized
DEBUG - 2024-02-18 11:22:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-18 11:22:13 --> Input Class Initialized
INFO - 2024-02-18 11:22:13 --> Language Class Initialized
INFO - 2024-02-18 11:22:13 --> Loader Class Initialized
INFO - 2024-02-18 11:22:13 --> Helper loaded: url_helper
INFO - 2024-02-18 11:22:13 --> Helper loaded: file_helper
INFO - 2024-02-18 11:22:13 --> Helper loaded: html_helper
INFO - 2024-02-18 11:22:13 --> Helper loaded: text_helper
INFO - 2024-02-18 11:22:13 --> Helper loaded: form_helper
INFO - 2024-02-18 11:22:13 --> Helper loaded: lang_helper
INFO - 2024-02-18 11:22:13 --> Helper loaded: security_helper
INFO - 2024-02-18 11:22:13 --> Helper loaded: cookie_helper
INFO - 2024-02-18 11:22:13 --> Database Driver Class Initialized
INFO - 2024-02-18 11:22:13 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-18 11:22:13 --> Parser Class Initialized
INFO - 2024-02-18 11:22:13 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-18 11:22:13 --> Pagination Class Initialized
INFO - 2024-02-18 11:22:13 --> Form Validation Class Initialized
INFO - 2024-02-18 11:22:13 --> Controller Class Initialized
DEBUG - 2024-02-18 11:22:13 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-18 11:22:13 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-18 11:22:13 --> Model Class Initialized
DEBUG - 2024-02-18 11:22:13 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-18 11:22:13 --> Model Class Initialized
INFO - 2024-02-18 11:22:13 --> Final output sent to browser
DEBUG - 2024-02-18 11:22:13 --> Total execution time: 0.0361
ERROR - 2024-02-18 11:22:14 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-18 11:22:14 --> Config Class Initialized
INFO - 2024-02-18 11:22:14 --> Hooks Class Initialized
DEBUG - 2024-02-18 11:22:14 --> UTF-8 Support Enabled
INFO - 2024-02-18 11:22:14 --> Utf8 Class Initialized
INFO - 2024-02-18 11:22:14 --> URI Class Initialized
INFO - 2024-02-18 11:22:14 --> Router Class Initialized
INFO - 2024-02-18 11:22:14 --> Output Class Initialized
INFO - 2024-02-18 11:22:14 --> Security Class Initialized
DEBUG - 2024-02-18 11:22:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-18 11:22:14 --> Input Class Initialized
INFO - 2024-02-18 11:22:14 --> Language Class Initialized
INFO - 2024-02-18 11:22:14 --> Loader Class Initialized
INFO - 2024-02-18 11:22:14 --> Helper loaded: url_helper
INFO - 2024-02-18 11:22:14 --> Helper loaded: file_helper
INFO - 2024-02-18 11:22:14 --> Helper loaded: html_helper
INFO - 2024-02-18 11:22:14 --> Helper loaded: text_helper
INFO - 2024-02-18 11:22:14 --> Helper loaded: form_helper
INFO - 2024-02-18 11:22:14 --> Helper loaded: lang_helper
INFO - 2024-02-18 11:22:14 --> Helper loaded: security_helper
INFO - 2024-02-18 11:22:14 --> Helper loaded: cookie_helper
INFO - 2024-02-18 11:22:14 --> Database Driver Class Initialized
INFO - 2024-02-18 11:22:14 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-18 11:22:14 --> Parser Class Initialized
INFO - 2024-02-18 11:22:14 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-18 11:22:14 --> Pagination Class Initialized
INFO - 2024-02-18 11:22:14 --> Form Validation Class Initialized
INFO - 2024-02-18 11:22:14 --> Controller Class Initialized
DEBUG - 2024-02-18 11:22:14 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-18 11:22:14 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-18 11:22:14 --> Model Class Initialized
DEBUG - 2024-02-18 11:22:14 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-18 11:22:14 --> Model Class Initialized
INFO - 2024-02-18 11:22:14 --> Final output sent to browser
DEBUG - 2024-02-18 11:22:14 --> Total execution time: 0.0373
ERROR - 2024-02-18 11:22:15 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-18 11:22:15 --> Config Class Initialized
INFO - 2024-02-18 11:22:15 --> Hooks Class Initialized
DEBUG - 2024-02-18 11:22:15 --> UTF-8 Support Enabled
INFO - 2024-02-18 11:22:15 --> Utf8 Class Initialized
INFO - 2024-02-18 11:22:15 --> URI Class Initialized
INFO - 2024-02-18 11:22:15 --> Router Class Initialized
INFO - 2024-02-18 11:22:15 --> Output Class Initialized
INFO - 2024-02-18 11:22:15 --> Security Class Initialized
DEBUG - 2024-02-18 11:22:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-18 11:22:15 --> Input Class Initialized
INFO - 2024-02-18 11:22:15 --> Language Class Initialized
INFO - 2024-02-18 11:22:15 --> Loader Class Initialized
INFO - 2024-02-18 11:22:15 --> Helper loaded: url_helper
INFO - 2024-02-18 11:22:15 --> Helper loaded: file_helper
INFO - 2024-02-18 11:22:15 --> Helper loaded: html_helper
INFO - 2024-02-18 11:22:15 --> Helper loaded: text_helper
INFO - 2024-02-18 11:22:15 --> Helper loaded: form_helper
INFO - 2024-02-18 11:22:15 --> Helper loaded: lang_helper
INFO - 2024-02-18 11:22:15 --> Helper loaded: security_helper
INFO - 2024-02-18 11:22:15 --> Helper loaded: cookie_helper
INFO - 2024-02-18 11:22:15 --> Database Driver Class Initialized
INFO - 2024-02-18 11:22:15 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-18 11:22:15 --> Parser Class Initialized
INFO - 2024-02-18 11:22:15 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-18 11:22:15 --> Pagination Class Initialized
INFO - 2024-02-18 11:22:15 --> Form Validation Class Initialized
INFO - 2024-02-18 11:22:15 --> Controller Class Initialized
DEBUG - 2024-02-18 11:22:15 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-18 11:22:15 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-18 11:22:15 --> Model Class Initialized
DEBUG - 2024-02-18 11:22:15 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-18 11:22:15 --> Model Class Initialized
INFO - 2024-02-18 11:22:15 --> Final output sent to browser
DEBUG - 2024-02-18 11:22:15 --> Total execution time: 0.0311
ERROR - 2024-02-18 11:22:18 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-18 11:22:18 --> Config Class Initialized
INFO - 2024-02-18 11:22:18 --> Hooks Class Initialized
DEBUG - 2024-02-18 11:22:18 --> UTF-8 Support Enabled
INFO - 2024-02-18 11:22:18 --> Utf8 Class Initialized
INFO - 2024-02-18 11:22:18 --> URI Class Initialized
INFO - 2024-02-18 11:22:18 --> Router Class Initialized
INFO - 2024-02-18 11:22:18 --> Output Class Initialized
INFO - 2024-02-18 11:22:18 --> Security Class Initialized
DEBUG - 2024-02-18 11:22:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-18 11:22:18 --> Input Class Initialized
INFO - 2024-02-18 11:22:18 --> Language Class Initialized
INFO - 2024-02-18 11:22:18 --> Loader Class Initialized
INFO - 2024-02-18 11:22:18 --> Helper loaded: url_helper
INFO - 2024-02-18 11:22:18 --> Helper loaded: file_helper
INFO - 2024-02-18 11:22:18 --> Helper loaded: html_helper
INFO - 2024-02-18 11:22:18 --> Helper loaded: text_helper
INFO - 2024-02-18 11:22:18 --> Helper loaded: form_helper
INFO - 2024-02-18 11:22:18 --> Helper loaded: lang_helper
INFO - 2024-02-18 11:22:18 --> Helper loaded: security_helper
INFO - 2024-02-18 11:22:18 --> Helper loaded: cookie_helper
INFO - 2024-02-18 11:22:18 --> Database Driver Class Initialized
INFO - 2024-02-18 11:22:18 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-18 11:22:18 --> Parser Class Initialized
INFO - 2024-02-18 11:22:18 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-18 11:22:18 --> Pagination Class Initialized
INFO - 2024-02-18 11:22:18 --> Form Validation Class Initialized
INFO - 2024-02-18 11:22:18 --> Controller Class Initialized
DEBUG - 2024-02-18 11:22:18 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-18 11:22:18 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-18 11:22:18 --> Model Class Initialized
DEBUG - 2024-02-18 11:22:18 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-18 11:22:18 --> Model Class Initialized
INFO - 2024-02-18 11:22:18 --> Final output sent to browser
DEBUG - 2024-02-18 11:22:18 --> Total execution time: 0.0316
ERROR - 2024-02-18 11:22:18 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-18 11:22:18 --> Config Class Initialized
INFO - 2024-02-18 11:22:18 --> Hooks Class Initialized
DEBUG - 2024-02-18 11:22:18 --> UTF-8 Support Enabled
INFO - 2024-02-18 11:22:18 --> Utf8 Class Initialized
INFO - 2024-02-18 11:22:18 --> URI Class Initialized
INFO - 2024-02-18 11:22:18 --> Router Class Initialized
INFO - 2024-02-18 11:22:18 --> Output Class Initialized
INFO - 2024-02-18 11:22:18 --> Security Class Initialized
DEBUG - 2024-02-18 11:22:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-18 11:22:18 --> Input Class Initialized
INFO - 2024-02-18 11:22:18 --> Language Class Initialized
INFO - 2024-02-18 11:22:18 --> Loader Class Initialized
INFO - 2024-02-18 11:22:18 --> Helper loaded: url_helper
INFO - 2024-02-18 11:22:18 --> Helper loaded: file_helper
INFO - 2024-02-18 11:22:18 --> Helper loaded: html_helper
INFO - 2024-02-18 11:22:18 --> Helper loaded: text_helper
INFO - 2024-02-18 11:22:18 --> Helper loaded: form_helper
INFO - 2024-02-18 11:22:18 --> Helper loaded: lang_helper
INFO - 2024-02-18 11:22:18 --> Helper loaded: security_helper
INFO - 2024-02-18 11:22:18 --> Helper loaded: cookie_helper
INFO - 2024-02-18 11:22:18 --> Database Driver Class Initialized
INFO - 2024-02-18 11:22:18 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-18 11:22:18 --> Parser Class Initialized
INFO - 2024-02-18 11:22:18 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-18 11:22:18 --> Pagination Class Initialized
INFO - 2024-02-18 11:22:18 --> Form Validation Class Initialized
INFO - 2024-02-18 11:22:18 --> Controller Class Initialized
DEBUG - 2024-02-18 11:22:18 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-18 11:22:18 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-18 11:22:18 --> Model Class Initialized
DEBUG - 2024-02-18 11:22:18 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-18 11:22:18 --> Model Class Initialized
INFO - 2024-02-18 11:22:18 --> Final output sent to browser
DEBUG - 2024-02-18 11:22:18 --> Total execution time: 0.0360
ERROR - 2024-02-18 11:22:21 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-18 11:22:21 --> Config Class Initialized
INFO - 2024-02-18 11:22:21 --> Hooks Class Initialized
DEBUG - 2024-02-18 11:22:21 --> UTF-8 Support Enabled
INFO - 2024-02-18 11:22:21 --> Utf8 Class Initialized
INFO - 2024-02-18 11:22:21 --> URI Class Initialized
INFO - 2024-02-18 11:22:21 --> Router Class Initialized
INFO - 2024-02-18 11:22:21 --> Output Class Initialized
INFO - 2024-02-18 11:22:21 --> Security Class Initialized
DEBUG - 2024-02-18 11:22:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-18 11:22:21 --> Input Class Initialized
INFO - 2024-02-18 11:22:21 --> Language Class Initialized
INFO - 2024-02-18 11:22:21 --> Loader Class Initialized
INFO - 2024-02-18 11:22:21 --> Helper loaded: url_helper
INFO - 2024-02-18 11:22:21 --> Helper loaded: file_helper
INFO - 2024-02-18 11:22:21 --> Helper loaded: html_helper
INFO - 2024-02-18 11:22:21 --> Helper loaded: text_helper
INFO - 2024-02-18 11:22:21 --> Helper loaded: form_helper
INFO - 2024-02-18 11:22:21 --> Helper loaded: lang_helper
INFO - 2024-02-18 11:22:21 --> Helper loaded: security_helper
INFO - 2024-02-18 11:22:21 --> Helper loaded: cookie_helper
INFO - 2024-02-18 11:22:21 --> Database Driver Class Initialized
INFO - 2024-02-18 11:22:21 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-18 11:22:21 --> Parser Class Initialized
INFO - 2024-02-18 11:22:21 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-18 11:22:21 --> Pagination Class Initialized
INFO - 2024-02-18 11:22:21 --> Form Validation Class Initialized
INFO - 2024-02-18 11:22:21 --> Controller Class Initialized
DEBUG - 2024-02-18 11:22:21 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-18 11:22:21 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-18 11:22:21 --> Model Class Initialized
DEBUG - 2024-02-18 11:22:21 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-18 11:22:21 --> Model Class Initialized
INFO - 2024-02-18 11:22:21 --> Final output sent to browser
DEBUG - 2024-02-18 11:22:21 --> Total execution time: 0.0322
ERROR - 2024-02-18 11:22:22 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-18 11:22:22 --> Config Class Initialized
INFO - 2024-02-18 11:22:22 --> Hooks Class Initialized
DEBUG - 2024-02-18 11:22:22 --> UTF-8 Support Enabled
INFO - 2024-02-18 11:22:22 --> Utf8 Class Initialized
INFO - 2024-02-18 11:22:22 --> URI Class Initialized
INFO - 2024-02-18 11:22:22 --> Router Class Initialized
INFO - 2024-02-18 11:22:22 --> Output Class Initialized
INFO - 2024-02-18 11:22:22 --> Security Class Initialized
DEBUG - 2024-02-18 11:22:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-18 11:22:22 --> Input Class Initialized
INFO - 2024-02-18 11:22:22 --> Language Class Initialized
INFO - 2024-02-18 11:22:22 --> Loader Class Initialized
INFO - 2024-02-18 11:22:22 --> Helper loaded: url_helper
INFO - 2024-02-18 11:22:22 --> Helper loaded: file_helper
INFO - 2024-02-18 11:22:22 --> Helper loaded: html_helper
INFO - 2024-02-18 11:22:22 --> Helper loaded: text_helper
INFO - 2024-02-18 11:22:22 --> Helper loaded: form_helper
INFO - 2024-02-18 11:22:22 --> Helper loaded: lang_helper
INFO - 2024-02-18 11:22:22 --> Helper loaded: security_helper
INFO - 2024-02-18 11:22:22 --> Helper loaded: cookie_helper
INFO - 2024-02-18 11:22:22 --> Database Driver Class Initialized
INFO - 2024-02-18 11:22:22 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-18 11:22:22 --> Parser Class Initialized
INFO - 2024-02-18 11:22:22 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-18 11:22:22 --> Pagination Class Initialized
INFO - 2024-02-18 11:22:22 --> Form Validation Class Initialized
INFO - 2024-02-18 11:22:22 --> Controller Class Initialized
DEBUG - 2024-02-18 11:22:22 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-18 11:22:22 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-18 11:22:22 --> Model Class Initialized
DEBUG - 2024-02-18 11:22:22 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-18 11:22:22 --> Model Class Initialized
INFO - 2024-02-18 11:22:22 --> Final output sent to browser
DEBUG - 2024-02-18 11:22:22 --> Total execution time: 0.0312
ERROR - 2024-02-18 11:22:22 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-18 11:22:22 --> Config Class Initialized
INFO - 2024-02-18 11:22:22 --> Hooks Class Initialized
DEBUG - 2024-02-18 11:22:22 --> UTF-8 Support Enabled
INFO - 2024-02-18 11:22:22 --> Utf8 Class Initialized
INFO - 2024-02-18 11:22:22 --> URI Class Initialized
INFO - 2024-02-18 11:22:22 --> Router Class Initialized
INFO - 2024-02-18 11:22:22 --> Output Class Initialized
INFO - 2024-02-18 11:22:22 --> Security Class Initialized
DEBUG - 2024-02-18 11:22:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-18 11:22:22 --> Input Class Initialized
INFO - 2024-02-18 11:22:22 --> Language Class Initialized
INFO - 2024-02-18 11:22:22 --> Loader Class Initialized
INFO - 2024-02-18 11:22:22 --> Helper loaded: url_helper
INFO - 2024-02-18 11:22:22 --> Helper loaded: file_helper
INFO - 2024-02-18 11:22:22 --> Helper loaded: html_helper
INFO - 2024-02-18 11:22:22 --> Helper loaded: text_helper
INFO - 2024-02-18 11:22:22 --> Helper loaded: form_helper
INFO - 2024-02-18 11:22:22 --> Helper loaded: lang_helper
INFO - 2024-02-18 11:22:22 --> Helper loaded: security_helper
INFO - 2024-02-18 11:22:22 --> Helper loaded: cookie_helper
INFO - 2024-02-18 11:22:22 --> Database Driver Class Initialized
INFO - 2024-02-18 11:22:22 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-18 11:22:22 --> Parser Class Initialized
INFO - 2024-02-18 11:22:22 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-18 11:22:22 --> Pagination Class Initialized
INFO - 2024-02-18 11:22:22 --> Form Validation Class Initialized
INFO - 2024-02-18 11:22:22 --> Controller Class Initialized
DEBUG - 2024-02-18 11:22:22 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-18 11:22:22 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-18 11:22:22 --> Model Class Initialized
DEBUG - 2024-02-18 11:22:22 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-18 11:22:22 --> Model Class Initialized
INFO - 2024-02-18 11:22:23 --> Final output sent to browser
DEBUG - 2024-02-18 11:22:23 --> Total execution time: 0.0358
ERROR - 2024-02-18 11:22:24 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-18 11:22:24 --> Config Class Initialized
INFO - 2024-02-18 11:22:24 --> Hooks Class Initialized
DEBUG - 2024-02-18 11:22:24 --> UTF-8 Support Enabled
INFO - 2024-02-18 11:22:24 --> Utf8 Class Initialized
INFO - 2024-02-18 11:22:24 --> URI Class Initialized
INFO - 2024-02-18 11:22:24 --> Router Class Initialized
INFO - 2024-02-18 11:22:24 --> Output Class Initialized
INFO - 2024-02-18 11:22:24 --> Security Class Initialized
DEBUG - 2024-02-18 11:22:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-18 11:22:24 --> Input Class Initialized
INFO - 2024-02-18 11:22:24 --> Language Class Initialized
INFO - 2024-02-18 11:22:24 --> Loader Class Initialized
INFO - 2024-02-18 11:22:24 --> Helper loaded: url_helper
INFO - 2024-02-18 11:22:24 --> Helper loaded: file_helper
INFO - 2024-02-18 11:22:24 --> Helper loaded: html_helper
INFO - 2024-02-18 11:22:24 --> Helper loaded: text_helper
INFO - 2024-02-18 11:22:24 --> Helper loaded: form_helper
INFO - 2024-02-18 11:22:24 --> Helper loaded: lang_helper
INFO - 2024-02-18 11:22:24 --> Helper loaded: security_helper
INFO - 2024-02-18 11:22:24 --> Helper loaded: cookie_helper
INFO - 2024-02-18 11:22:24 --> Database Driver Class Initialized
INFO - 2024-02-18 11:22:24 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-18 11:22:24 --> Parser Class Initialized
INFO - 2024-02-18 11:22:24 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-18 11:22:24 --> Pagination Class Initialized
INFO - 2024-02-18 11:22:24 --> Form Validation Class Initialized
INFO - 2024-02-18 11:22:24 --> Controller Class Initialized
DEBUG - 2024-02-18 11:22:24 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-18 11:22:24 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-18 11:22:24 --> Model Class Initialized
DEBUG - 2024-02-18 11:22:24 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-18 11:22:24 --> Model Class Initialized
INFO - 2024-02-18 11:22:24 --> Final output sent to browser
DEBUG - 2024-02-18 11:22:24 --> Total execution time: 0.0355
ERROR - 2024-02-18 11:22:24 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-18 11:22:24 --> Config Class Initialized
INFO - 2024-02-18 11:22:24 --> Hooks Class Initialized
DEBUG - 2024-02-18 11:22:24 --> UTF-8 Support Enabled
INFO - 2024-02-18 11:22:24 --> Utf8 Class Initialized
INFO - 2024-02-18 11:22:24 --> URI Class Initialized
INFO - 2024-02-18 11:22:24 --> Router Class Initialized
INFO - 2024-02-18 11:22:24 --> Output Class Initialized
INFO - 2024-02-18 11:22:24 --> Security Class Initialized
DEBUG - 2024-02-18 11:22:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-18 11:22:24 --> Input Class Initialized
INFO - 2024-02-18 11:22:24 --> Language Class Initialized
INFO - 2024-02-18 11:22:24 --> Loader Class Initialized
INFO - 2024-02-18 11:22:24 --> Helper loaded: url_helper
INFO - 2024-02-18 11:22:24 --> Helper loaded: file_helper
INFO - 2024-02-18 11:22:24 --> Helper loaded: html_helper
INFO - 2024-02-18 11:22:24 --> Helper loaded: text_helper
INFO - 2024-02-18 11:22:24 --> Helper loaded: form_helper
INFO - 2024-02-18 11:22:24 --> Helper loaded: lang_helper
INFO - 2024-02-18 11:22:24 --> Helper loaded: security_helper
INFO - 2024-02-18 11:22:24 --> Helper loaded: cookie_helper
INFO - 2024-02-18 11:22:24 --> Database Driver Class Initialized
INFO - 2024-02-18 11:22:24 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-18 11:22:24 --> Parser Class Initialized
INFO - 2024-02-18 11:22:24 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-18 11:22:24 --> Pagination Class Initialized
INFO - 2024-02-18 11:22:24 --> Form Validation Class Initialized
INFO - 2024-02-18 11:22:24 --> Controller Class Initialized
DEBUG - 2024-02-18 11:22:24 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-18 11:22:24 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-18 11:22:24 --> Model Class Initialized
DEBUG - 2024-02-18 11:22:24 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-18 11:22:24 --> Model Class Initialized
INFO - 2024-02-18 11:22:24 --> Final output sent to browser
DEBUG - 2024-02-18 11:22:24 --> Total execution time: 0.0209
ERROR - 2024-02-18 11:22:30 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-18 11:22:30 --> Config Class Initialized
INFO - 2024-02-18 11:22:30 --> Hooks Class Initialized
DEBUG - 2024-02-18 11:22:30 --> UTF-8 Support Enabled
INFO - 2024-02-18 11:22:30 --> Utf8 Class Initialized
INFO - 2024-02-18 11:22:30 --> URI Class Initialized
INFO - 2024-02-18 11:22:30 --> Router Class Initialized
INFO - 2024-02-18 11:22:30 --> Output Class Initialized
INFO - 2024-02-18 11:22:30 --> Security Class Initialized
DEBUG - 2024-02-18 11:22:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-18 11:22:30 --> Input Class Initialized
INFO - 2024-02-18 11:22:30 --> Language Class Initialized
INFO - 2024-02-18 11:22:30 --> Loader Class Initialized
INFO - 2024-02-18 11:22:30 --> Helper loaded: url_helper
INFO - 2024-02-18 11:22:30 --> Helper loaded: file_helper
INFO - 2024-02-18 11:22:30 --> Helper loaded: html_helper
INFO - 2024-02-18 11:22:30 --> Helper loaded: text_helper
INFO - 2024-02-18 11:22:30 --> Helper loaded: form_helper
INFO - 2024-02-18 11:22:30 --> Helper loaded: lang_helper
INFO - 2024-02-18 11:22:30 --> Helper loaded: security_helper
INFO - 2024-02-18 11:22:30 --> Helper loaded: cookie_helper
INFO - 2024-02-18 11:22:30 --> Database Driver Class Initialized
INFO - 2024-02-18 11:22:30 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-18 11:22:30 --> Parser Class Initialized
INFO - 2024-02-18 11:22:30 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-18 11:22:30 --> Pagination Class Initialized
INFO - 2024-02-18 11:22:30 --> Form Validation Class Initialized
INFO - 2024-02-18 11:22:30 --> Controller Class Initialized
DEBUG - 2024-02-18 11:22:30 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-18 11:22:30 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-18 11:22:30 --> Model Class Initialized
DEBUG - 2024-02-18 11:22:30 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-18 11:22:30 --> Model Class Initialized
INFO - 2024-02-18 11:22:30 --> Final output sent to browser
DEBUG - 2024-02-18 11:22:30 --> Total execution time: 0.0245
ERROR - 2024-02-18 11:22:31 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-18 11:22:31 --> Config Class Initialized
INFO - 2024-02-18 11:22:31 --> Hooks Class Initialized
DEBUG - 2024-02-18 11:22:31 --> UTF-8 Support Enabled
INFO - 2024-02-18 11:22:31 --> Utf8 Class Initialized
INFO - 2024-02-18 11:22:31 --> URI Class Initialized
INFO - 2024-02-18 11:22:31 --> Router Class Initialized
INFO - 2024-02-18 11:22:31 --> Output Class Initialized
INFO - 2024-02-18 11:22:31 --> Security Class Initialized
DEBUG - 2024-02-18 11:22:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-18 11:22:31 --> Input Class Initialized
INFO - 2024-02-18 11:22:31 --> Language Class Initialized
INFO - 2024-02-18 11:22:31 --> Loader Class Initialized
INFO - 2024-02-18 11:22:31 --> Helper loaded: url_helper
INFO - 2024-02-18 11:22:31 --> Helper loaded: file_helper
INFO - 2024-02-18 11:22:31 --> Helper loaded: html_helper
INFO - 2024-02-18 11:22:31 --> Helper loaded: text_helper
INFO - 2024-02-18 11:22:31 --> Helper loaded: form_helper
INFO - 2024-02-18 11:22:31 --> Helper loaded: lang_helper
INFO - 2024-02-18 11:22:31 --> Helper loaded: security_helper
INFO - 2024-02-18 11:22:31 --> Helper loaded: cookie_helper
INFO - 2024-02-18 11:22:31 --> Database Driver Class Initialized
INFO - 2024-02-18 11:22:31 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-18 11:22:31 --> Parser Class Initialized
INFO - 2024-02-18 11:22:31 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-18 11:22:31 --> Pagination Class Initialized
INFO - 2024-02-18 11:22:31 --> Form Validation Class Initialized
INFO - 2024-02-18 11:22:31 --> Controller Class Initialized
DEBUG - 2024-02-18 11:22:31 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-18 11:22:31 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-18 11:22:31 --> Model Class Initialized
DEBUG - 2024-02-18 11:22:31 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-18 11:22:31 --> Model Class Initialized
INFO - 2024-02-18 11:22:31 --> Final output sent to browser
DEBUG - 2024-02-18 11:22:31 --> Total execution time: 0.0311
ERROR - 2024-02-18 11:22:31 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-18 11:22:31 --> Config Class Initialized
INFO - 2024-02-18 11:22:31 --> Hooks Class Initialized
DEBUG - 2024-02-18 11:22:31 --> UTF-8 Support Enabled
INFO - 2024-02-18 11:22:31 --> Utf8 Class Initialized
INFO - 2024-02-18 11:22:31 --> URI Class Initialized
INFO - 2024-02-18 11:22:31 --> Router Class Initialized
INFO - 2024-02-18 11:22:31 --> Output Class Initialized
INFO - 2024-02-18 11:22:31 --> Security Class Initialized
DEBUG - 2024-02-18 11:22:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-18 11:22:31 --> Input Class Initialized
INFO - 2024-02-18 11:22:31 --> Language Class Initialized
INFO - 2024-02-18 11:22:31 --> Loader Class Initialized
INFO - 2024-02-18 11:22:31 --> Helper loaded: url_helper
INFO - 2024-02-18 11:22:31 --> Helper loaded: file_helper
INFO - 2024-02-18 11:22:31 --> Helper loaded: html_helper
INFO - 2024-02-18 11:22:31 --> Helper loaded: text_helper
INFO - 2024-02-18 11:22:31 --> Helper loaded: form_helper
INFO - 2024-02-18 11:22:31 --> Helper loaded: lang_helper
INFO - 2024-02-18 11:22:31 --> Helper loaded: security_helper
INFO - 2024-02-18 11:22:31 --> Helper loaded: cookie_helper
INFO - 2024-02-18 11:22:31 --> Database Driver Class Initialized
INFO - 2024-02-18 11:22:31 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-18 11:22:31 --> Parser Class Initialized
INFO - 2024-02-18 11:22:31 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-18 11:22:31 --> Pagination Class Initialized
INFO - 2024-02-18 11:22:31 --> Form Validation Class Initialized
INFO - 2024-02-18 11:22:31 --> Controller Class Initialized
DEBUG - 2024-02-18 11:22:31 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-18 11:22:31 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-18 11:22:31 --> Model Class Initialized
DEBUG - 2024-02-18 11:22:31 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-18 11:22:31 --> Model Class Initialized
INFO - 2024-02-18 11:22:31 --> Final output sent to browser
DEBUG - 2024-02-18 11:22:31 --> Total execution time: 0.0311
ERROR - 2024-02-18 11:22:32 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-18 11:22:32 --> Config Class Initialized
INFO - 2024-02-18 11:22:32 --> Hooks Class Initialized
DEBUG - 2024-02-18 11:22:32 --> UTF-8 Support Enabled
INFO - 2024-02-18 11:22:32 --> Utf8 Class Initialized
INFO - 2024-02-18 11:22:32 --> URI Class Initialized
INFO - 2024-02-18 11:22:32 --> Router Class Initialized
INFO - 2024-02-18 11:22:32 --> Output Class Initialized
INFO - 2024-02-18 11:22:32 --> Security Class Initialized
DEBUG - 2024-02-18 11:22:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-18 11:22:32 --> Input Class Initialized
INFO - 2024-02-18 11:22:32 --> Language Class Initialized
INFO - 2024-02-18 11:22:32 --> Loader Class Initialized
INFO - 2024-02-18 11:22:32 --> Helper loaded: url_helper
INFO - 2024-02-18 11:22:32 --> Helper loaded: file_helper
INFO - 2024-02-18 11:22:32 --> Helper loaded: html_helper
INFO - 2024-02-18 11:22:32 --> Helper loaded: text_helper
INFO - 2024-02-18 11:22:32 --> Helper loaded: form_helper
INFO - 2024-02-18 11:22:32 --> Helper loaded: lang_helper
INFO - 2024-02-18 11:22:32 --> Helper loaded: security_helper
INFO - 2024-02-18 11:22:32 --> Helper loaded: cookie_helper
INFO - 2024-02-18 11:22:32 --> Database Driver Class Initialized
INFO - 2024-02-18 11:22:32 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-18 11:22:32 --> Parser Class Initialized
INFO - 2024-02-18 11:22:32 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-18 11:22:32 --> Pagination Class Initialized
INFO - 2024-02-18 11:22:32 --> Form Validation Class Initialized
INFO - 2024-02-18 11:22:32 --> Controller Class Initialized
DEBUG - 2024-02-18 11:22:32 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-18 11:22:32 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-18 11:22:32 --> Model Class Initialized
DEBUG - 2024-02-18 11:22:32 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-18 11:22:32 --> Model Class Initialized
INFO - 2024-02-18 11:22:32 --> Final output sent to browser
DEBUG - 2024-02-18 11:22:32 --> Total execution time: 0.0300
ERROR - 2024-02-18 11:22:36 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-18 11:22:36 --> Config Class Initialized
INFO - 2024-02-18 11:22:36 --> Hooks Class Initialized
DEBUG - 2024-02-18 11:22:36 --> UTF-8 Support Enabled
INFO - 2024-02-18 11:22:36 --> Utf8 Class Initialized
INFO - 2024-02-18 11:22:36 --> URI Class Initialized
INFO - 2024-02-18 11:22:36 --> Router Class Initialized
INFO - 2024-02-18 11:22:36 --> Output Class Initialized
INFO - 2024-02-18 11:22:36 --> Security Class Initialized
DEBUG - 2024-02-18 11:22:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-18 11:22:36 --> Input Class Initialized
INFO - 2024-02-18 11:22:36 --> Language Class Initialized
INFO - 2024-02-18 11:22:36 --> Loader Class Initialized
INFO - 2024-02-18 11:22:36 --> Helper loaded: url_helper
INFO - 2024-02-18 11:22:36 --> Helper loaded: file_helper
INFO - 2024-02-18 11:22:36 --> Helper loaded: html_helper
INFO - 2024-02-18 11:22:36 --> Helper loaded: text_helper
INFO - 2024-02-18 11:22:36 --> Helper loaded: form_helper
INFO - 2024-02-18 11:22:36 --> Helper loaded: lang_helper
INFO - 2024-02-18 11:22:36 --> Helper loaded: security_helper
INFO - 2024-02-18 11:22:36 --> Helper loaded: cookie_helper
INFO - 2024-02-18 11:22:36 --> Database Driver Class Initialized
INFO - 2024-02-18 11:22:36 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-18 11:22:36 --> Parser Class Initialized
INFO - 2024-02-18 11:22:36 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-18 11:22:36 --> Pagination Class Initialized
INFO - 2024-02-18 11:22:36 --> Form Validation Class Initialized
INFO - 2024-02-18 11:22:36 --> Controller Class Initialized
DEBUG - 2024-02-18 11:22:36 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-18 11:22:36 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-18 11:22:36 --> Model Class Initialized
DEBUG - 2024-02-18 11:22:36 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-18 11:22:36 --> Model Class Initialized
INFO - 2024-02-18 11:22:36 --> Final output sent to browser
DEBUG - 2024-02-18 11:22:36 --> Total execution time: 0.0326
ERROR - 2024-02-18 11:22:37 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-18 11:22:37 --> Config Class Initialized
INFO - 2024-02-18 11:22:37 --> Hooks Class Initialized
DEBUG - 2024-02-18 11:22:37 --> UTF-8 Support Enabled
INFO - 2024-02-18 11:22:37 --> Utf8 Class Initialized
INFO - 2024-02-18 11:22:37 --> URI Class Initialized
INFO - 2024-02-18 11:22:37 --> Router Class Initialized
INFO - 2024-02-18 11:22:37 --> Output Class Initialized
INFO - 2024-02-18 11:22:37 --> Security Class Initialized
DEBUG - 2024-02-18 11:22:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-18 11:22:37 --> Input Class Initialized
INFO - 2024-02-18 11:22:37 --> Language Class Initialized
INFO - 2024-02-18 11:22:37 --> Loader Class Initialized
INFO - 2024-02-18 11:22:37 --> Helper loaded: url_helper
INFO - 2024-02-18 11:22:37 --> Helper loaded: file_helper
INFO - 2024-02-18 11:22:37 --> Helper loaded: html_helper
INFO - 2024-02-18 11:22:37 --> Helper loaded: text_helper
INFO - 2024-02-18 11:22:37 --> Helper loaded: form_helper
INFO - 2024-02-18 11:22:37 --> Helper loaded: lang_helper
INFO - 2024-02-18 11:22:37 --> Helper loaded: security_helper
INFO - 2024-02-18 11:22:37 --> Helper loaded: cookie_helper
INFO - 2024-02-18 11:22:37 --> Database Driver Class Initialized
INFO - 2024-02-18 11:22:37 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-18 11:22:37 --> Parser Class Initialized
INFO - 2024-02-18 11:22:37 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-18 11:22:37 --> Pagination Class Initialized
INFO - 2024-02-18 11:22:37 --> Form Validation Class Initialized
INFO - 2024-02-18 11:22:37 --> Controller Class Initialized
DEBUG - 2024-02-18 11:22:37 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-18 11:22:37 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-18 11:22:37 --> Model Class Initialized
DEBUG - 2024-02-18 11:22:37 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-18 11:22:37 --> Model Class Initialized
INFO - 2024-02-18 11:22:37 --> Final output sent to browser
DEBUG - 2024-02-18 11:22:37 --> Total execution time: 0.0361
ERROR - 2024-02-18 11:22:38 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-18 11:22:38 --> Config Class Initialized
INFO - 2024-02-18 11:22:38 --> Hooks Class Initialized
DEBUG - 2024-02-18 11:22:38 --> UTF-8 Support Enabled
INFO - 2024-02-18 11:22:38 --> Utf8 Class Initialized
INFO - 2024-02-18 11:22:38 --> URI Class Initialized
INFO - 2024-02-18 11:22:38 --> Router Class Initialized
INFO - 2024-02-18 11:22:38 --> Output Class Initialized
INFO - 2024-02-18 11:22:38 --> Security Class Initialized
DEBUG - 2024-02-18 11:22:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-18 11:22:38 --> Input Class Initialized
INFO - 2024-02-18 11:22:38 --> Language Class Initialized
INFO - 2024-02-18 11:22:38 --> Loader Class Initialized
INFO - 2024-02-18 11:22:38 --> Helper loaded: url_helper
INFO - 2024-02-18 11:22:38 --> Helper loaded: file_helper
INFO - 2024-02-18 11:22:38 --> Helper loaded: html_helper
INFO - 2024-02-18 11:22:38 --> Helper loaded: text_helper
INFO - 2024-02-18 11:22:38 --> Helper loaded: form_helper
INFO - 2024-02-18 11:22:38 --> Helper loaded: lang_helper
INFO - 2024-02-18 11:22:38 --> Helper loaded: security_helper
INFO - 2024-02-18 11:22:38 --> Helper loaded: cookie_helper
INFO - 2024-02-18 11:22:38 --> Database Driver Class Initialized
INFO - 2024-02-18 11:22:38 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-18 11:22:38 --> Parser Class Initialized
INFO - 2024-02-18 11:22:38 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-18 11:22:38 --> Pagination Class Initialized
INFO - 2024-02-18 11:22:38 --> Form Validation Class Initialized
INFO - 2024-02-18 11:22:38 --> Controller Class Initialized
DEBUG - 2024-02-18 11:22:38 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-18 11:22:38 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-18 11:22:38 --> Model Class Initialized
DEBUG - 2024-02-18 11:22:38 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-18 11:22:38 --> Model Class Initialized
INFO - 2024-02-18 11:22:38 --> Final output sent to browser
DEBUG - 2024-02-18 11:22:38 --> Total execution time: 0.0347
ERROR - 2024-02-18 11:22:38 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-18 11:22:38 --> Config Class Initialized
INFO - 2024-02-18 11:22:38 --> Hooks Class Initialized
DEBUG - 2024-02-18 11:22:38 --> UTF-8 Support Enabled
INFO - 2024-02-18 11:22:38 --> Utf8 Class Initialized
INFO - 2024-02-18 11:22:38 --> URI Class Initialized
INFO - 2024-02-18 11:22:38 --> Router Class Initialized
INFO - 2024-02-18 11:22:38 --> Output Class Initialized
INFO - 2024-02-18 11:22:38 --> Security Class Initialized
DEBUG - 2024-02-18 11:22:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-18 11:22:38 --> Input Class Initialized
INFO - 2024-02-18 11:22:38 --> Language Class Initialized
INFO - 2024-02-18 11:22:38 --> Loader Class Initialized
INFO - 2024-02-18 11:22:38 --> Helper loaded: url_helper
INFO - 2024-02-18 11:22:38 --> Helper loaded: file_helper
INFO - 2024-02-18 11:22:38 --> Helper loaded: html_helper
INFO - 2024-02-18 11:22:38 --> Helper loaded: text_helper
INFO - 2024-02-18 11:22:38 --> Helper loaded: form_helper
INFO - 2024-02-18 11:22:38 --> Helper loaded: lang_helper
INFO - 2024-02-18 11:22:38 --> Helper loaded: security_helper
INFO - 2024-02-18 11:22:38 --> Helper loaded: cookie_helper
INFO - 2024-02-18 11:22:38 --> Database Driver Class Initialized
INFO - 2024-02-18 11:22:38 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-18 11:22:38 --> Parser Class Initialized
INFO - 2024-02-18 11:22:38 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-18 11:22:38 --> Pagination Class Initialized
INFO - 2024-02-18 11:22:38 --> Form Validation Class Initialized
INFO - 2024-02-18 11:22:38 --> Controller Class Initialized
DEBUG - 2024-02-18 11:22:38 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-18 11:22:38 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-18 11:22:38 --> Model Class Initialized
DEBUG - 2024-02-18 11:22:38 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-18 11:22:38 --> Model Class Initialized
INFO - 2024-02-18 11:22:38 --> Final output sent to browser
DEBUG - 2024-02-18 11:22:38 --> Total execution time: 0.0319
ERROR - 2024-02-18 11:22:40 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-18 11:22:40 --> Config Class Initialized
INFO - 2024-02-18 11:22:40 --> Hooks Class Initialized
DEBUG - 2024-02-18 11:22:40 --> UTF-8 Support Enabled
INFO - 2024-02-18 11:22:40 --> Utf8 Class Initialized
INFO - 2024-02-18 11:22:40 --> URI Class Initialized
INFO - 2024-02-18 11:22:40 --> Router Class Initialized
INFO - 2024-02-18 11:22:40 --> Output Class Initialized
INFO - 2024-02-18 11:22:40 --> Security Class Initialized
DEBUG - 2024-02-18 11:22:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-18 11:22:40 --> Input Class Initialized
INFO - 2024-02-18 11:22:40 --> Language Class Initialized
INFO - 2024-02-18 11:22:40 --> Loader Class Initialized
INFO - 2024-02-18 11:22:40 --> Helper loaded: url_helper
INFO - 2024-02-18 11:22:40 --> Helper loaded: file_helper
INFO - 2024-02-18 11:22:40 --> Helper loaded: html_helper
INFO - 2024-02-18 11:22:40 --> Helper loaded: text_helper
INFO - 2024-02-18 11:22:40 --> Helper loaded: form_helper
INFO - 2024-02-18 11:22:40 --> Helper loaded: lang_helper
INFO - 2024-02-18 11:22:40 --> Helper loaded: security_helper
INFO - 2024-02-18 11:22:40 --> Helper loaded: cookie_helper
INFO - 2024-02-18 11:22:40 --> Database Driver Class Initialized
INFO - 2024-02-18 11:22:40 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-18 11:22:40 --> Parser Class Initialized
INFO - 2024-02-18 11:22:40 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-18 11:22:40 --> Pagination Class Initialized
INFO - 2024-02-18 11:22:40 --> Form Validation Class Initialized
INFO - 2024-02-18 11:22:40 --> Controller Class Initialized
DEBUG - 2024-02-18 11:22:40 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-18 11:22:40 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-18 11:22:40 --> Model Class Initialized
DEBUG - 2024-02-18 11:22:40 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-18 11:22:40 --> Model Class Initialized
INFO - 2024-02-18 11:22:40 --> Final output sent to browser
DEBUG - 2024-02-18 11:22:40 --> Total execution time: 0.0193
ERROR - 2024-02-18 11:22:42 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-18 11:22:42 --> Config Class Initialized
INFO - 2024-02-18 11:22:42 --> Hooks Class Initialized
DEBUG - 2024-02-18 11:22:42 --> UTF-8 Support Enabled
INFO - 2024-02-18 11:22:42 --> Utf8 Class Initialized
INFO - 2024-02-18 11:22:42 --> URI Class Initialized
INFO - 2024-02-18 11:22:42 --> Router Class Initialized
INFO - 2024-02-18 11:22:42 --> Output Class Initialized
INFO - 2024-02-18 11:22:42 --> Security Class Initialized
DEBUG - 2024-02-18 11:22:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-18 11:22:42 --> Input Class Initialized
INFO - 2024-02-18 11:22:42 --> Language Class Initialized
INFO - 2024-02-18 11:22:42 --> Loader Class Initialized
INFO - 2024-02-18 11:22:42 --> Helper loaded: url_helper
INFO - 2024-02-18 11:22:42 --> Helper loaded: file_helper
INFO - 2024-02-18 11:22:42 --> Helper loaded: html_helper
INFO - 2024-02-18 11:22:42 --> Helper loaded: text_helper
INFO - 2024-02-18 11:22:42 --> Helper loaded: form_helper
INFO - 2024-02-18 11:22:42 --> Helper loaded: lang_helper
INFO - 2024-02-18 11:22:42 --> Helper loaded: security_helper
INFO - 2024-02-18 11:22:42 --> Helper loaded: cookie_helper
INFO - 2024-02-18 11:22:42 --> Database Driver Class Initialized
INFO - 2024-02-18 11:22:42 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-18 11:22:42 --> Parser Class Initialized
INFO - 2024-02-18 11:22:42 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-18 11:22:42 --> Pagination Class Initialized
INFO - 2024-02-18 11:22:42 --> Form Validation Class Initialized
INFO - 2024-02-18 11:22:42 --> Controller Class Initialized
DEBUG - 2024-02-18 11:22:42 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-18 11:22:42 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-18 11:22:42 --> Model Class Initialized
DEBUG - 2024-02-18 11:22:42 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-18 11:22:42 --> Model Class Initialized
INFO - 2024-02-18 11:22:42 --> Final output sent to browser
DEBUG - 2024-02-18 11:22:42 --> Total execution time: 0.0308
ERROR - 2024-02-18 11:22:42 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-18 11:22:42 --> Config Class Initialized
INFO - 2024-02-18 11:22:42 --> Hooks Class Initialized
DEBUG - 2024-02-18 11:22:42 --> UTF-8 Support Enabled
INFO - 2024-02-18 11:22:42 --> Utf8 Class Initialized
INFO - 2024-02-18 11:22:42 --> URI Class Initialized
INFO - 2024-02-18 11:22:42 --> Router Class Initialized
INFO - 2024-02-18 11:22:42 --> Output Class Initialized
INFO - 2024-02-18 11:22:42 --> Security Class Initialized
DEBUG - 2024-02-18 11:22:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-18 11:22:42 --> Input Class Initialized
INFO - 2024-02-18 11:22:42 --> Language Class Initialized
INFO - 2024-02-18 11:22:42 --> Loader Class Initialized
INFO - 2024-02-18 11:22:42 --> Helper loaded: url_helper
INFO - 2024-02-18 11:22:42 --> Helper loaded: file_helper
INFO - 2024-02-18 11:22:42 --> Helper loaded: html_helper
INFO - 2024-02-18 11:22:42 --> Helper loaded: text_helper
INFO - 2024-02-18 11:22:42 --> Helper loaded: form_helper
INFO - 2024-02-18 11:22:42 --> Helper loaded: lang_helper
INFO - 2024-02-18 11:22:42 --> Helper loaded: security_helper
INFO - 2024-02-18 11:22:42 --> Helper loaded: cookie_helper
INFO - 2024-02-18 11:22:42 --> Database Driver Class Initialized
INFO - 2024-02-18 11:22:42 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-18 11:22:42 --> Parser Class Initialized
INFO - 2024-02-18 11:22:42 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-18 11:22:42 --> Pagination Class Initialized
INFO - 2024-02-18 11:22:42 --> Form Validation Class Initialized
INFO - 2024-02-18 11:22:42 --> Controller Class Initialized
DEBUG - 2024-02-18 11:22:42 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-18 11:22:42 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-18 11:22:42 --> Model Class Initialized
DEBUG - 2024-02-18 11:22:42 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-18 11:22:42 --> Model Class Initialized
INFO - 2024-02-18 11:22:42 --> Final output sent to browser
DEBUG - 2024-02-18 11:22:42 --> Total execution time: 0.0314
ERROR - 2024-02-18 11:22:43 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-18 11:22:43 --> Config Class Initialized
INFO - 2024-02-18 11:22:43 --> Hooks Class Initialized
DEBUG - 2024-02-18 11:22:43 --> UTF-8 Support Enabled
INFO - 2024-02-18 11:22:43 --> Utf8 Class Initialized
INFO - 2024-02-18 11:22:43 --> URI Class Initialized
INFO - 2024-02-18 11:22:43 --> Router Class Initialized
INFO - 2024-02-18 11:22:43 --> Output Class Initialized
INFO - 2024-02-18 11:22:43 --> Security Class Initialized
DEBUG - 2024-02-18 11:22:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-18 11:22:43 --> Input Class Initialized
INFO - 2024-02-18 11:22:43 --> Language Class Initialized
INFO - 2024-02-18 11:22:43 --> Loader Class Initialized
INFO - 2024-02-18 11:22:43 --> Helper loaded: url_helper
INFO - 2024-02-18 11:22:43 --> Helper loaded: file_helper
INFO - 2024-02-18 11:22:43 --> Helper loaded: html_helper
INFO - 2024-02-18 11:22:43 --> Helper loaded: text_helper
INFO - 2024-02-18 11:22:43 --> Helper loaded: form_helper
INFO - 2024-02-18 11:22:43 --> Helper loaded: lang_helper
INFO - 2024-02-18 11:22:43 --> Helper loaded: security_helper
INFO - 2024-02-18 11:22:43 --> Helper loaded: cookie_helper
INFO - 2024-02-18 11:22:43 --> Database Driver Class Initialized
INFO - 2024-02-18 11:22:43 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-18 11:22:43 --> Parser Class Initialized
INFO - 2024-02-18 11:22:43 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-18 11:22:43 --> Pagination Class Initialized
INFO - 2024-02-18 11:22:43 --> Form Validation Class Initialized
INFO - 2024-02-18 11:22:43 --> Controller Class Initialized
DEBUG - 2024-02-18 11:22:43 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-18 11:22:43 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-18 11:22:43 --> Model Class Initialized
DEBUG - 2024-02-18 11:22:43 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-18 11:22:43 --> Model Class Initialized
INFO - 2024-02-18 11:22:43 --> Final output sent to browser
DEBUG - 2024-02-18 11:22:43 --> Total execution time: 0.0297
ERROR - 2024-02-18 11:22:44 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-18 11:22:44 --> Config Class Initialized
INFO - 2024-02-18 11:22:44 --> Hooks Class Initialized
DEBUG - 2024-02-18 11:22:44 --> UTF-8 Support Enabled
INFO - 2024-02-18 11:22:44 --> Utf8 Class Initialized
INFO - 2024-02-18 11:22:44 --> URI Class Initialized
INFO - 2024-02-18 11:22:44 --> Router Class Initialized
INFO - 2024-02-18 11:22:44 --> Output Class Initialized
INFO - 2024-02-18 11:22:44 --> Security Class Initialized
DEBUG - 2024-02-18 11:22:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-18 11:22:44 --> Input Class Initialized
INFO - 2024-02-18 11:22:44 --> Language Class Initialized
INFO - 2024-02-18 11:22:44 --> Loader Class Initialized
INFO - 2024-02-18 11:22:44 --> Helper loaded: url_helper
INFO - 2024-02-18 11:22:44 --> Helper loaded: file_helper
INFO - 2024-02-18 11:22:44 --> Helper loaded: html_helper
INFO - 2024-02-18 11:22:44 --> Helper loaded: text_helper
INFO - 2024-02-18 11:22:44 --> Helper loaded: form_helper
INFO - 2024-02-18 11:22:44 --> Helper loaded: lang_helper
INFO - 2024-02-18 11:22:44 --> Helper loaded: security_helper
INFO - 2024-02-18 11:22:44 --> Helper loaded: cookie_helper
INFO - 2024-02-18 11:22:44 --> Database Driver Class Initialized
INFO - 2024-02-18 11:22:44 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-18 11:22:44 --> Parser Class Initialized
INFO - 2024-02-18 11:22:44 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-18 11:22:44 --> Pagination Class Initialized
INFO - 2024-02-18 11:22:44 --> Form Validation Class Initialized
INFO - 2024-02-18 11:22:44 --> Controller Class Initialized
DEBUG - 2024-02-18 11:22:44 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-18 11:22:44 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-18 11:22:44 --> Model Class Initialized
DEBUG - 2024-02-18 11:22:44 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-18 11:22:44 --> Model Class Initialized
INFO - 2024-02-18 11:22:44 --> Final output sent to browser
DEBUG - 2024-02-18 11:22:44 --> Total execution time: 0.0299
ERROR - 2024-02-18 11:22:44 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-18 11:22:44 --> Config Class Initialized
INFO - 2024-02-18 11:22:44 --> Hooks Class Initialized
DEBUG - 2024-02-18 11:22:44 --> UTF-8 Support Enabled
INFO - 2024-02-18 11:22:44 --> Utf8 Class Initialized
INFO - 2024-02-18 11:22:44 --> URI Class Initialized
INFO - 2024-02-18 11:22:44 --> Router Class Initialized
INFO - 2024-02-18 11:22:44 --> Output Class Initialized
INFO - 2024-02-18 11:22:44 --> Security Class Initialized
DEBUG - 2024-02-18 11:22:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-18 11:22:44 --> Input Class Initialized
INFO - 2024-02-18 11:22:44 --> Language Class Initialized
INFO - 2024-02-18 11:22:44 --> Loader Class Initialized
INFO - 2024-02-18 11:22:44 --> Helper loaded: url_helper
INFO - 2024-02-18 11:22:44 --> Helper loaded: file_helper
INFO - 2024-02-18 11:22:44 --> Helper loaded: html_helper
INFO - 2024-02-18 11:22:44 --> Helper loaded: text_helper
INFO - 2024-02-18 11:22:44 --> Helper loaded: form_helper
INFO - 2024-02-18 11:22:44 --> Helper loaded: lang_helper
INFO - 2024-02-18 11:22:44 --> Helper loaded: security_helper
INFO - 2024-02-18 11:22:44 --> Helper loaded: cookie_helper
INFO - 2024-02-18 11:22:44 --> Database Driver Class Initialized
INFO - 2024-02-18 11:22:44 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-18 11:22:44 --> Parser Class Initialized
INFO - 2024-02-18 11:22:44 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-18 11:22:44 --> Pagination Class Initialized
INFO - 2024-02-18 11:22:44 --> Form Validation Class Initialized
INFO - 2024-02-18 11:22:44 --> Controller Class Initialized
DEBUG - 2024-02-18 11:22:44 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-18 11:22:44 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-18 11:22:44 --> Model Class Initialized
DEBUG - 2024-02-18 11:22:44 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-18 11:22:44 --> Model Class Initialized
INFO - 2024-02-18 11:22:44 --> Final output sent to browser
DEBUG - 2024-02-18 11:22:44 --> Total execution time: 0.0330
ERROR - 2024-02-18 11:22:46 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-18 11:22:46 --> Config Class Initialized
INFO - 2024-02-18 11:22:46 --> Hooks Class Initialized
DEBUG - 2024-02-18 11:22:46 --> UTF-8 Support Enabled
INFO - 2024-02-18 11:22:46 --> Utf8 Class Initialized
INFO - 2024-02-18 11:22:46 --> URI Class Initialized
INFO - 2024-02-18 11:22:46 --> Router Class Initialized
INFO - 2024-02-18 11:22:46 --> Output Class Initialized
INFO - 2024-02-18 11:22:46 --> Security Class Initialized
DEBUG - 2024-02-18 11:22:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-18 11:22:46 --> Input Class Initialized
INFO - 2024-02-18 11:22:46 --> Language Class Initialized
INFO - 2024-02-18 11:22:46 --> Loader Class Initialized
INFO - 2024-02-18 11:22:46 --> Helper loaded: url_helper
INFO - 2024-02-18 11:22:46 --> Helper loaded: file_helper
INFO - 2024-02-18 11:22:46 --> Helper loaded: html_helper
INFO - 2024-02-18 11:22:46 --> Helper loaded: text_helper
INFO - 2024-02-18 11:22:46 --> Helper loaded: form_helper
INFO - 2024-02-18 11:22:46 --> Helper loaded: lang_helper
INFO - 2024-02-18 11:22:46 --> Helper loaded: security_helper
INFO - 2024-02-18 11:22:46 --> Helper loaded: cookie_helper
INFO - 2024-02-18 11:22:46 --> Database Driver Class Initialized
INFO - 2024-02-18 11:22:46 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-18 11:22:46 --> Parser Class Initialized
INFO - 2024-02-18 11:22:46 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-18 11:22:46 --> Pagination Class Initialized
INFO - 2024-02-18 11:22:46 --> Form Validation Class Initialized
INFO - 2024-02-18 11:22:46 --> Controller Class Initialized
DEBUG - 2024-02-18 11:22:46 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-18 11:22:46 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-18 11:22:46 --> Model Class Initialized
DEBUG - 2024-02-18 11:22:46 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-18 11:22:46 --> Model Class Initialized
INFO - 2024-02-18 11:22:46 --> Final output sent to browser
DEBUG - 2024-02-18 11:22:46 --> Total execution time: 0.0206
ERROR - 2024-02-18 11:22:46 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-18 11:22:46 --> Config Class Initialized
INFO - 2024-02-18 11:22:46 --> Hooks Class Initialized
DEBUG - 2024-02-18 11:22:46 --> UTF-8 Support Enabled
INFO - 2024-02-18 11:22:46 --> Utf8 Class Initialized
INFO - 2024-02-18 11:22:46 --> URI Class Initialized
INFO - 2024-02-18 11:22:46 --> Router Class Initialized
INFO - 2024-02-18 11:22:46 --> Output Class Initialized
INFO - 2024-02-18 11:22:46 --> Security Class Initialized
DEBUG - 2024-02-18 11:22:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-18 11:22:46 --> Input Class Initialized
INFO - 2024-02-18 11:22:46 --> Language Class Initialized
INFO - 2024-02-18 11:22:46 --> Loader Class Initialized
INFO - 2024-02-18 11:22:46 --> Helper loaded: url_helper
INFO - 2024-02-18 11:22:46 --> Helper loaded: file_helper
INFO - 2024-02-18 11:22:46 --> Helper loaded: html_helper
INFO - 2024-02-18 11:22:46 --> Helper loaded: text_helper
INFO - 2024-02-18 11:22:46 --> Helper loaded: form_helper
INFO - 2024-02-18 11:22:46 --> Helper loaded: lang_helper
INFO - 2024-02-18 11:22:46 --> Helper loaded: security_helper
INFO - 2024-02-18 11:22:46 --> Helper loaded: cookie_helper
INFO - 2024-02-18 11:22:46 --> Database Driver Class Initialized
INFO - 2024-02-18 11:22:46 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-18 11:22:46 --> Parser Class Initialized
INFO - 2024-02-18 11:22:46 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-18 11:22:46 --> Pagination Class Initialized
INFO - 2024-02-18 11:22:46 --> Form Validation Class Initialized
INFO - 2024-02-18 11:22:46 --> Controller Class Initialized
DEBUG - 2024-02-18 11:22:46 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-18 11:22:46 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-18 11:22:46 --> Model Class Initialized
DEBUG - 2024-02-18 11:22:46 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-18 11:22:46 --> Model Class Initialized
INFO - 2024-02-18 11:22:46 --> Final output sent to browser
DEBUG - 2024-02-18 11:22:46 --> Total execution time: 0.0174
ERROR - 2024-02-18 11:22:48 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-18 11:22:48 --> Config Class Initialized
INFO - 2024-02-18 11:22:48 --> Hooks Class Initialized
DEBUG - 2024-02-18 11:22:48 --> UTF-8 Support Enabled
INFO - 2024-02-18 11:22:48 --> Utf8 Class Initialized
INFO - 2024-02-18 11:22:48 --> URI Class Initialized
INFO - 2024-02-18 11:22:48 --> Router Class Initialized
INFO - 2024-02-18 11:22:48 --> Output Class Initialized
INFO - 2024-02-18 11:22:48 --> Security Class Initialized
DEBUG - 2024-02-18 11:22:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-18 11:22:48 --> Input Class Initialized
INFO - 2024-02-18 11:22:48 --> Language Class Initialized
INFO - 2024-02-18 11:22:48 --> Loader Class Initialized
INFO - 2024-02-18 11:22:48 --> Helper loaded: url_helper
INFO - 2024-02-18 11:22:48 --> Helper loaded: file_helper
INFO - 2024-02-18 11:22:48 --> Helper loaded: html_helper
INFO - 2024-02-18 11:22:48 --> Helper loaded: text_helper
INFO - 2024-02-18 11:22:48 --> Helper loaded: form_helper
INFO - 2024-02-18 11:22:48 --> Helper loaded: lang_helper
INFO - 2024-02-18 11:22:48 --> Helper loaded: security_helper
INFO - 2024-02-18 11:22:48 --> Helper loaded: cookie_helper
INFO - 2024-02-18 11:22:48 --> Database Driver Class Initialized
INFO - 2024-02-18 11:22:48 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-18 11:22:48 --> Parser Class Initialized
INFO - 2024-02-18 11:22:48 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-18 11:22:48 --> Pagination Class Initialized
INFO - 2024-02-18 11:22:48 --> Form Validation Class Initialized
INFO - 2024-02-18 11:22:48 --> Controller Class Initialized
DEBUG - 2024-02-18 11:22:48 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-18 11:22:48 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-18 11:22:48 --> Model Class Initialized
DEBUG - 2024-02-18 11:22:48 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-18 11:22:48 --> Model Class Initialized
INFO - 2024-02-18 11:22:48 --> Final output sent to browser
DEBUG - 2024-02-18 11:22:48 --> Total execution time: 0.0196
ERROR - 2024-02-18 11:22:49 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-18 11:22:49 --> Config Class Initialized
INFO - 2024-02-18 11:22:49 --> Hooks Class Initialized
DEBUG - 2024-02-18 11:22:49 --> UTF-8 Support Enabled
INFO - 2024-02-18 11:22:49 --> Utf8 Class Initialized
INFO - 2024-02-18 11:22:49 --> URI Class Initialized
INFO - 2024-02-18 11:22:49 --> Router Class Initialized
INFO - 2024-02-18 11:22:49 --> Output Class Initialized
INFO - 2024-02-18 11:22:49 --> Security Class Initialized
DEBUG - 2024-02-18 11:22:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-18 11:22:49 --> Input Class Initialized
INFO - 2024-02-18 11:22:49 --> Language Class Initialized
INFO - 2024-02-18 11:22:49 --> Loader Class Initialized
INFO - 2024-02-18 11:22:49 --> Helper loaded: url_helper
INFO - 2024-02-18 11:22:49 --> Helper loaded: file_helper
INFO - 2024-02-18 11:22:49 --> Helper loaded: html_helper
INFO - 2024-02-18 11:22:49 --> Helper loaded: text_helper
INFO - 2024-02-18 11:22:49 --> Helper loaded: form_helper
INFO - 2024-02-18 11:22:49 --> Helper loaded: lang_helper
INFO - 2024-02-18 11:22:49 --> Helper loaded: security_helper
INFO - 2024-02-18 11:22:49 --> Helper loaded: cookie_helper
INFO - 2024-02-18 11:22:49 --> Database Driver Class Initialized
INFO - 2024-02-18 11:22:49 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-18 11:22:49 --> Parser Class Initialized
INFO - 2024-02-18 11:22:49 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-18 11:22:49 --> Pagination Class Initialized
INFO - 2024-02-18 11:22:49 --> Form Validation Class Initialized
INFO - 2024-02-18 11:22:49 --> Controller Class Initialized
DEBUG - 2024-02-18 11:22:49 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-18 11:22:49 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-18 11:22:49 --> Model Class Initialized
DEBUG - 2024-02-18 11:22:49 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-18 11:22:49 --> Model Class Initialized
INFO - 2024-02-18 11:22:49 --> Final output sent to browser
DEBUG - 2024-02-18 11:22:49 --> Total execution time: 0.0314
ERROR - 2024-02-18 11:22:49 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-18 11:22:49 --> Config Class Initialized
INFO - 2024-02-18 11:22:49 --> Hooks Class Initialized
DEBUG - 2024-02-18 11:22:49 --> UTF-8 Support Enabled
INFO - 2024-02-18 11:22:49 --> Utf8 Class Initialized
INFO - 2024-02-18 11:22:49 --> URI Class Initialized
INFO - 2024-02-18 11:22:49 --> Router Class Initialized
INFO - 2024-02-18 11:22:49 --> Output Class Initialized
INFO - 2024-02-18 11:22:49 --> Security Class Initialized
DEBUG - 2024-02-18 11:22:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-18 11:22:49 --> Input Class Initialized
INFO - 2024-02-18 11:22:49 --> Language Class Initialized
INFO - 2024-02-18 11:22:49 --> Loader Class Initialized
INFO - 2024-02-18 11:22:49 --> Helper loaded: url_helper
INFO - 2024-02-18 11:22:49 --> Helper loaded: file_helper
INFO - 2024-02-18 11:22:49 --> Helper loaded: html_helper
INFO - 2024-02-18 11:22:49 --> Helper loaded: text_helper
INFO - 2024-02-18 11:22:49 --> Helper loaded: form_helper
INFO - 2024-02-18 11:22:49 --> Helper loaded: lang_helper
INFO - 2024-02-18 11:22:49 --> Helper loaded: security_helper
INFO - 2024-02-18 11:22:49 --> Helper loaded: cookie_helper
INFO - 2024-02-18 11:22:49 --> Database Driver Class Initialized
INFO - 2024-02-18 11:22:49 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-18 11:22:49 --> Parser Class Initialized
INFO - 2024-02-18 11:22:49 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-18 11:22:49 --> Pagination Class Initialized
INFO - 2024-02-18 11:22:49 --> Form Validation Class Initialized
INFO - 2024-02-18 11:22:49 --> Controller Class Initialized
DEBUG - 2024-02-18 11:22:49 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-18 11:22:49 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-18 11:22:49 --> Model Class Initialized
DEBUG - 2024-02-18 11:22:49 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-18 11:22:49 --> Model Class Initialized
INFO - 2024-02-18 11:22:49 --> Final output sent to browser
DEBUG - 2024-02-18 11:22:49 --> Total execution time: 0.0302
ERROR - 2024-02-18 11:22:50 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-18 11:22:50 --> Config Class Initialized
INFO - 2024-02-18 11:22:50 --> Hooks Class Initialized
DEBUG - 2024-02-18 11:22:50 --> UTF-8 Support Enabled
INFO - 2024-02-18 11:22:50 --> Utf8 Class Initialized
INFO - 2024-02-18 11:22:50 --> URI Class Initialized
INFO - 2024-02-18 11:22:50 --> Router Class Initialized
INFO - 2024-02-18 11:22:50 --> Output Class Initialized
INFO - 2024-02-18 11:22:50 --> Security Class Initialized
DEBUG - 2024-02-18 11:22:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-18 11:22:50 --> Input Class Initialized
INFO - 2024-02-18 11:22:50 --> Language Class Initialized
INFO - 2024-02-18 11:22:50 --> Loader Class Initialized
INFO - 2024-02-18 11:22:50 --> Helper loaded: url_helper
INFO - 2024-02-18 11:22:50 --> Helper loaded: file_helper
INFO - 2024-02-18 11:22:50 --> Helper loaded: html_helper
INFO - 2024-02-18 11:22:50 --> Helper loaded: text_helper
INFO - 2024-02-18 11:22:50 --> Helper loaded: form_helper
INFO - 2024-02-18 11:22:50 --> Helper loaded: lang_helper
INFO - 2024-02-18 11:22:50 --> Helper loaded: security_helper
INFO - 2024-02-18 11:22:50 --> Helper loaded: cookie_helper
INFO - 2024-02-18 11:22:50 --> Database Driver Class Initialized
INFO - 2024-02-18 11:22:50 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-18 11:22:50 --> Parser Class Initialized
INFO - 2024-02-18 11:22:50 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-18 11:22:50 --> Pagination Class Initialized
INFO - 2024-02-18 11:22:50 --> Form Validation Class Initialized
INFO - 2024-02-18 11:22:50 --> Controller Class Initialized
DEBUG - 2024-02-18 11:22:50 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-18 11:22:50 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-18 11:22:50 --> Model Class Initialized
DEBUG - 2024-02-18 11:22:50 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-18 11:22:50 --> Model Class Initialized
INFO - 2024-02-18 11:22:50 --> Final output sent to browser
DEBUG - 2024-02-18 11:22:50 --> Total execution time: 0.0301
ERROR - 2024-02-18 11:22:50 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-18 11:22:50 --> Config Class Initialized
INFO - 2024-02-18 11:22:50 --> Hooks Class Initialized
DEBUG - 2024-02-18 11:22:50 --> UTF-8 Support Enabled
INFO - 2024-02-18 11:22:50 --> Utf8 Class Initialized
INFO - 2024-02-18 11:22:50 --> URI Class Initialized
INFO - 2024-02-18 11:22:50 --> Router Class Initialized
INFO - 2024-02-18 11:22:50 --> Output Class Initialized
INFO - 2024-02-18 11:22:50 --> Security Class Initialized
DEBUG - 2024-02-18 11:22:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-18 11:22:50 --> Input Class Initialized
INFO - 2024-02-18 11:22:50 --> Language Class Initialized
INFO - 2024-02-18 11:22:50 --> Loader Class Initialized
INFO - 2024-02-18 11:22:50 --> Helper loaded: url_helper
INFO - 2024-02-18 11:22:50 --> Helper loaded: file_helper
INFO - 2024-02-18 11:22:50 --> Helper loaded: html_helper
INFO - 2024-02-18 11:22:50 --> Helper loaded: text_helper
INFO - 2024-02-18 11:22:50 --> Helper loaded: form_helper
INFO - 2024-02-18 11:22:50 --> Helper loaded: lang_helper
INFO - 2024-02-18 11:22:50 --> Helper loaded: security_helper
INFO - 2024-02-18 11:22:50 --> Helper loaded: cookie_helper
INFO - 2024-02-18 11:22:50 --> Database Driver Class Initialized
INFO - 2024-02-18 11:22:50 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-18 11:22:50 --> Parser Class Initialized
INFO - 2024-02-18 11:22:50 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-18 11:22:50 --> Pagination Class Initialized
INFO - 2024-02-18 11:22:50 --> Form Validation Class Initialized
INFO - 2024-02-18 11:22:50 --> Controller Class Initialized
DEBUG - 2024-02-18 11:22:50 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-18 11:22:50 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-18 11:22:50 --> Model Class Initialized
DEBUG - 2024-02-18 11:22:50 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-18 11:22:50 --> Model Class Initialized
INFO - 2024-02-18 11:22:50 --> Final output sent to browser
DEBUG - 2024-02-18 11:22:50 --> Total execution time: 0.0302
ERROR - 2024-02-18 11:22:52 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-18 11:22:52 --> Config Class Initialized
INFO - 2024-02-18 11:22:52 --> Hooks Class Initialized
DEBUG - 2024-02-18 11:22:52 --> UTF-8 Support Enabled
INFO - 2024-02-18 11:22:52 --> Utf8 Class Initialized
INFO - 2024-02-18 11:22:52 --> URI Class Initialized
INFO - 2024-02-18 11:22:52 --> Router Class Initialized
INFO - 2024-02-18 11:22:52 --> Output Class Initialized
INFO - 2024-02-18 11:22:52 --> Security Class Initialized
DEBUG - 2024-02-18 11:22:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-18 11:22:52 --> Input Class Initialized
INFO - 2024-02-18 11:22:52 --> Language Class Initialized
INFO - 2024-02-18 11:22:52 --> Loader Class Initialized
INFO - 2024-02-18 11:22:52 --> Helper loaded: url_helper
INFO - 2024-02-18 11:22:52 --> Helper loaded: file_helper
INFO - 2024-02-18 11:22:52 --> Helper loaded: html_helper
INFO - 2024-02-18 11:22:52 --> Helper loaded: text_helper
INFO - 2024-02-18 11:22:52 --> Helper loaded: form_helper
INFO - 2024-02-18 11:22:52 --> Helper loaded: lang_helper
INFO - 2024-02-18 11:22:52 --> Helper loaded: security_helper
INFO - 2024-02-18 11:22:52 --> Helper loaded: cookie_helper
INFO - 2024-02-18 11:22:52 --> Database Driver Class Initialized
INFO - 2024-02-18 11:22:52 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-18 11:22:52 --> Parser Class Initialized
INFO - 2024-02-18 11:22:52 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-18 11:22:52 --> Pagination Class Initialized
INFO - 2024-02-18 11:22:52 --> Form Validation Class Initialized
INFO - 2024-02-18 11:22:52 --> Controller Class Initialized
DEBUG - 2024-02-18 11:22:52 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-18 11:22:52 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-18 11:22:52 --> Model Class Initialized
DEBUG - 2024-02-18 11:22:52 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-18 11:22:52 --> Model Class Initialized
INFO - 2024-02-18 11:22:52 --> Final output sent to browser
DEBUG - 2024-02-18 11:22:52 --> Total execution time: 0.0240
ERROR - 2024-02-18 11:22:56 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-18 11:22:56 --> Config Class Initialized
INFO - 2024-02-18 11:22:56 --> Hooks Class Initialized
DEBUG - 2024-02-18 11:22:56 --> UTF-8 Support Enabled
INFO - 2024-02-18 11:22:56 --> Utf8 Class Initialized
INFO - 2024-02-18 11:22:56 --> URI Class Initialized
INFO - 2024-02-18 11:22:56 --> Router Class Initialized
INFO - 2024-02-18 11:22:56 --> Output Class Initialized
INFO - 2024-02-18 11:22:56 --> Security Class Initialized
DEBUG - 2024-02-18 11:22:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-18 11:22:56 --> Input Class Initialized
INFO - 2024-02-18 11:22:56 --> Language Class Initialized
INFO - 2024-02-18 11:22:56 --> Loader Class Initialized
INFO - 2024-02-18 11:22:56 --> Helper loaded: url_helper
INFO - 2024-02-18 11:22:56 --> Helper loaded: file_helper
INFO - 2024-02-18 11:22:56 --> Helper loaded: html_helper
INFO - 2024-02-18 11:22:56 --> Helper loaded: text_helper
INFO - 2024-02-18 11:22:56 --> Helper loaded: form_helper
INFO - 2024-02-18 11:22:56 --> Helper loaded: lang_helper
INFO - 2024-02-18 11:22:56 --> Helper loaded: security_helper
INFO - 2024-02-18 11:22:56 --> Helper loaded: cookie_helper
INFO - 2024-02-18 11:22:56 --> Database Driver Class Initialized
INFO - 2024-02-18 11:22:56 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-18 11:22:56 --> Parser Class Initialized
INFO - 2024-02-18 11:22:56 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-18 11:22:56 --> Pagination Class Initialized
INFO - 2024-02-18 11:22:56 --> Form Validation Class Initialized
INFO - 2024-02-18 11:22:56 --> Controller Class Initialized
DEBUG - 2024-02-18 11:22:56 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-18 11:22:56 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-18 11:22:56 --> Model Class Initialized
DEBUG - 2024-02-18 11:22:56 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-18 11:22:56 --> Model Class Initialized
INFO - 2024-02-18 11:22:56 --> Final output sent to browser
DEBUG - 2024-02-18 11:22:56 --> Total execution time: 0.0289
ERROR - 2024-02-18 11:22:57 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-18 11:22:57 --> Config Class Initialized
INFO - 2024-02-18 11:22:57 --> Hooks Class Initialized
DEBUG - 2024-02-18 11:22:57 --> UTF-8 Support Enabled
INFO - 2024-02-18 11:22:57 --> Utf8 Class Initialized
INFO - 2024-02-18 11:22:57 --> URI Class Initialized
INFO - 2024-02-18 11:22:57 --> Router Class Initialized
INFO - 2024-02-18 11:22:57 --> Output Class Initialized
INFO - 2024-02-18 11:22:57 --> Security Class Initialized
DEBUG - 2024-02-18 11:22:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-18 11:22:57 --> Input Class Initialized
INFO - 2024-02-18 11:22:57 --> Language Class Initialized
INFO - 2024-02-18 11:22:57 --> Loader Class Initialized
INFO - 2024-02-18 11:22:57 --> Helper loaded: url_helper
INFO - 2024-02-18 11:22:57 --> Helper loaded: file_helper
INFO - 2024-02-18 11:22:57 --> Helper loaded: html_helper
INFO - 2024-02-18 11:22:57 --> Helper loaded: text_helper
INFO - 2024-02-18 11:22:57 --> Helper loaded: form_helper
INFO - 2024-02-18 11:22:57 --> Helper loaded: lang_helper
INFO - 2024-02-18 11:22:57 --> Helper loaded: security_helper
INFO - 2024-02-18 11:22:57 --> Helper loaded: cookie_helper
INFO - 2024-02-18 11:22:57 --> Database Driver Class Initialized
INFO - 2024-02-18 11:22:57 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-18 11:22:57 --> Parser Class Initialized
INFO - 2024-02-18 11:22:57 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-18 11:22:57 --> Pagination Class Initialized
INFO - 2024-02-18 11:22:57 --> Form Validation Class Initialized
INFO - 2024-02-18 11:22:57 --> Controller Class Initialized
DEBUG - 2024-02-18 11:22:57 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-18 11:22:57 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-18 11:22:57 --> Model Class Initialized
DEBUG - 2024-02-18 11:22:57 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-18 11:22:57 --> Model Class Initialized
INFO - 2024-02-18 11:22:57 --> Final output sent to browser
DEBUG - 2024-02-18 11:22:57 --> Total execution time: 0.0294
ERROR - 2024-02-18 11:23:04 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-18 11:23:04 --> Config Class Initialized
INFO - 2024-02-18 11:23:04 --> Hooks Class Initialized
DEBUG - 2024-02-18 11:23:04 --> UTF-8 Support Enabled
INFO - 2024-02-18 11:23:04 --> Utf8 Class Initialized
INFO - 2024-02-18 11:23:04 --> URI Class Initialized
INFO - 2024-02-18 11:23:04 --> Router Class Initialized
INFO - 2024-02-18 11:23:04 --> Output Class Initialized
INFO - 2024-02-18 11:23:04 --> Security Class Initialized
DEBUG - 2024-02-18 11:23:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-18 11:23:04 --> Input Class Initialized
INFO - 2024-02-18 11:23:04 --> Language Class Initialized
INFO - 2024-02-18 11:23:04 --> Loader Class Initialized
INFO - 2024-02-18 11:23:04 --> Helper loaded: url_helper
INFO - 2024-02-18 11:23:04 --> Helper loaded: file_helper
INFO - 2024-02-18 11:23:04 --> Helper loaded: html_helper
INFO - 2024-02-18 11:23:04 --> Helper loaded: text_helper
INFO - 2024-02-18 11:23:04 --> Helper loaded: form_helper
INFO - 2024-02-18 11:23:04 --> Helper loaded: lang_helper
INFO - 2024-02-18 11:23:04 --> Helper loaded: security_helper
INFO - 2024-02-18 11:23:04 --> Helper loaded: cookie_helper
INFO - 2024-02-18 11:23:04 --> Database Driver Class Initialized
INFO - 2024-02-18 11:23:04 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-18 11:23:04 --> Parser Class Initialized
INFO - 2024-02-18 11:23:04 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-18 11:23:04 --> Pagination Class Initialized
INFO - 2024-02-18 11:23:04 --> Form Validation Class Initialized
INFO - 2024-02-18 11:23:04 --> Controller Class Initialized
DEBUG - 2024-02-18 11:23:04 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-18 11:23:04 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-18 11:23:04 --> Model Class Initialized
DEBUG - 2024-02-18 11:23:04 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-18 11:23:04 --> Model Class Initialized
INFO - 2024-02-18 11:23:04 --> Final output sent to browser
DEBUG - 2024-02-18 11:23:04 --> Total execution time: 0.0329
ERROR - 2024-02-18 11:23:04 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-18 11:23:04 --> Config Class Initialized
INFO - 2024-02-18 11:23:04 --> Hooks Class Initialized
DEBUG - 2024-02-18 11:23:04 --> UTF-8 Support Enabled
INFO - 2024-02-18 11:23:04 --> Utf8 Class Initialized
INFO - 2024-02-18 11:23:04 --> URI Class Initialized
INFO - 2024-02-18 11:23:04 --> Router Class Initialized
INFO - 2024-02-18 11:23:04 --> Output Class Initialized
INFO - 2024-02-18 11:23:04 --> Security Class Initialized
DEBUG - 2024-02-18 11:23:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-18 11:23:04 --> Input Class Initialized
INFO - 2024-02-18 11:23:04 --> Language Class Initialized
INFO - 2024-02-18 11:23:04 --> Loader Class Initialized
INFO - 2024-02-18 11:23:04 --> Helper loaded: url_helper
INFO - 2024-02-18 11:23:04 --> Helper loaded: file_helper
INFO - 2024-02-18 11:23:04 --> Helper loaded: html_helper
INFO - 2024-02-18 11:23:04 --> Helper loaded: text_helper
INFO - 2024-02-18 11:23:04 --> Helper loaded: form_helper
INFO - 2024-02-18 11:23:04 --> Helper loaded: lang_helper
INFO - 2024-02-18 11:23:04 --> Helper loaded: security_helper
INFO - 2024-02-18 11:23:04 --> Helper loaded: cookie_helper
INFO - 2024-02-18 11:23:04 --> Database Driver Class Initialized
INFO - 2024-02-18 11:23:04 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-18 11:23:04 --> Parser Class Initialized
INFO - 2024-02-18 11:23:04 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-18 11:23:04 --> Pagination Class Initialized
INFO - 2024-02-18 11:23:04 --> Form Validation Class Initialized
INFO - 2024-02-18 11:23:04 --> Controller Class Initialized
DEBUG - 2024-02-18 11:23:04 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-18 11:23:04 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-18 11:23:04 --> Model Class Initialized
DEBUG - 2024-02-18 11:23:04 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-18 11:23:04 --> Model Class Initialized
INFO - 2024-02-18 11:23:04 --> Final output sent to browser
DEBUG - 2024-02-18 11:23:04 --> Total execution time: 0.0349
ERROR - 2024-02-18 11:23:05 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-18 11:23:05 --> Config Class Initialized
INFO - 2024-02-18 11:23:05 --> Hooks Class Initialized
DEBUG - 2024-02-18 11:23:05 --> UTF-8 Support Enabled
INFO - 2024-02-18 11:23:05 --> Utf8 Class Initialized
INFO - 2024-02-18 11:23:05 --> URI Class Initialized
INFO - 2024-02-18 11:23:05 --> Router Class Initialized
INFO - 2024-02-18 11:23:05 --> Output Class Initialized
INFO - 2024-02-18 11:23:05 --> Security Class Initialized
DEBUG - 2024-02-18 11:23:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-18 11:23:05 --> Input Class Initialized
INFO - 2024-02-18 11:23:05 --> Language Class Initialized
INFO - 2024-02-18 11:23:05 --> Loader Class Initialized
INFO - 2024-02-18 11:23:05 --> Helper loaded: url_helper
INFO - 2024-02-18 11:23:05 --> Helper loaded: file_helper
INFO - 2024-02-18 11:23:05 --> Helper loaded: html_helper
INFO - 2024-02-18 11:23:05 --> Helper loaded: text_helper
INFO - 2024-02-18 11:23:05 --> Helper loaded: form_helper
INFO - 2024-02-18 11:23:05 --> Helper loaded: lang_helper
INFO - 2024-02-18 11:23:05 --> Helper loaded: security_helper
INFO - 2024-02-18 11:23:05 --> Helper loaded: cookie_helper
INFO - 2024-02-18 11:23:05 --> Database Driver Class Initialized
INFO - 2024-02-18 11:23:05 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-18 11:23:05 --> Parser Class Initialized
INFO - 2024-02-18 11:23:05 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-18 11:23:05 --> Pagination Class Initialized
INFO - 2024-02-18 11:23:05 --> Form Validation Class Initialized
INFO - 2024-02-18 11:23:05 --> Controller Class Initialized
DEBUG - 2024-02-18 11:23:05 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-18 11:23:05 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-18 11:23:05 --> Model Class Initialized
DEBUG - 2024-02-18 11:23:05 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-18 11:23:05 --> Model Class Initialized
INFO - 2024-02-18 11:23:05 --> Final output sent to browser
DEBUG - 2024-02-18 11:23:05 --> Total execution time: 0.0240
ERROR - 2024-02-18 11:23:07 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-18 11:23:07 --> Config Class Initialized
INFO - 2024-02-18 11:23:07 --> Hooks Class Initialized
DEBUG - 2024-02-18 11:23:07 --> UTF-8 Support Enabled
INFO - 2024-02-18 11:23:07 --> Utf8 Class Initialized
INFO - 2024-02-18 11:23:07 --> URI Class Initialized
INFO - 2024-02-18 11:23:07 --> Router Class Initialized
INFO - 2024-02-18 11:23:07 --> Output Class Initialized
INFO - 2024-02-18 11:23:07 --> Security Class Initialized
DEBUG - 2024-02-18 11:23:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-18 11:23:07 --> Input Class Initialized
INFO - 2024-02-18 11:23:07 --> Language Class Initialized
INFO - 2024-02-18 11:23:07 --> Loader Class Initialized
INFO - 2024-02-18 11:23:07 --> Helper loaded: url_helper
INFO - 2024-02-18 11:23:07 --> Helper loaded: file_helper
INFO - 2024-02-18 11:23:07 --> Helper loaded: html_helper
INFO - 2024-02-18 11:23:07 --> Helper loaded: text_helper
INFO - 2024-02-18 11:23:07 --> Helper loaded: form_helper
INFO - 2024-02-18 11:23:07 --> Helper loaded: lang_helper
INFO - 2024-02-18 11:23:07 --> Helper loaded: security_helper
INFO - 2024-02-18 11:23:07 --> Helper loaded: cookie_helper
INFO - 2024-02-18 11:23:07 --> Database Driver Class Initialized
INFO - 2024-02-18 11:23:07 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-18 11:23:07 --> Parser Class Initialized
INFO - 2024-02-18 11:23:07 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-18 11:23:07 --> Pagination Class Initialized
INFO - 2024-02-18 11:23:07 --> Form Validation Class Initialized
INFO - 2024-02-18 11:23:07 --> Controller Class Initialized
DEBUG - 2024-02-18 11:23:07 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-18 11:23:07 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-18 11:23:07 --> Model Class Initialized
DEBUG - 2024-02-18 11:23:07 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-18 11:23:07 --> Model Class Initialized
INFO - 2024-02-18 11:23:07 --> Final output sent to browser
DEBUG - 2024-02-18 11:23:07 --> Total execution time: 0.0216
ERROR - 2024-02-18 11:23:07 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-18 11:23:07 --> Config Class Initialized
INFO - 2024-02-18 11:23:07 --> Hooks Class Initialized
DEBUG - 2024-02-18 11:23:07 --> UTF-8 Support Enabled
INFO - 2024-02-18 11:23:07 --> Utf8 Class Initialized
INFO - 2024-02-18 11:23:07 --> URI Class Initialized
INFO - 2024-02-18 11:23:07 --> Router Class Initialized
INFO - 2024-02-18 11:23:07 --> Output Class Initialized
INFO - 2024-02-18 11:23:07 --> Security Class Initialized
DEBUG - 2024-02-18 11:23:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-18 11:23:07 --> Input Class Initialized
INFO - 2024-02-18 11:23:07 --> Language Class Initialized
INFO - 2024-02-18 11:23:07 --> Loader Class Initialized
INFO - 2024-02-18 11:23:07 --> Helper loaded: url_helper
INFO - 2024-02-18 11:23:07 --> Helper loaded: file_helper
INFO - 2024-02-18 11:23:07 --> Helper loaded: html_helper
INFO - 2024-02-18 11:23:07 --> Helper loaded: text_helper
INFO - 2024-02-18 11:23:07 --> Helper loaded: form_helper
INFO - 2024-02-18 11:23:07 --> Helper loaded: lang_helper
INFO - 2024-02-18 11:23:07 --> Helper loaded: security_helper
INFO - 2024-02-18 11:23:07 --> Helper loaded: cookie_helper
INFO - 2024-02-18 11:23:07 --> Database Driver Class Initialized
INFO - 2024-02-18 11:23:07 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-18 11:23:07 --> Parser Class Initialized
INFO - 2024-02-18 11:23:07 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-18 11:23:07 --> Pagination Class Initialized
INFO - 2024-02-18 11:23:07 --> Form Validation Class Initialized
INFO - 2024-02-18 11:23:07 --> Controller Class Initialized
DEBUG - 2024-02-18 11:23:07 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-18 11:23:07 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-18 11:23:07 --> Model Class Initialized
DEBUG - 2024-02-18 11:23:07 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-18 11:23:07 --> Model Class Initialized
INFO - 2024-02-18 11:23:07 --> Final output sent to browser
DEBUG - 2024-02-18 11:23:07 --> Total execution time: 0.0203
ERROR - 2024-02-18 11:23:08 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-18 11:23:08 --> Config Class Initialized
INFO - 2024-02-18 11:23:08 --> Hooks Class Initialized
DEBUG - 2024-02-18 11:23:08 --> UTF-8 Support Enabled
INFO - 2024-02-18 11:23:08 --> Utf8 Class Initialized
INFO - 2024-02-18 11:23:08 --> URI Class Initialized
INFO - 2024-02-18 11:23:08 --> Router Class Initialized
INFO - 2024-02-18 11:23:08 --> Output Class Initialized
INFO - 2024-02-18 11:23:08 --> Security Class Initialized
DEBUG - 2024-02-18 11:23:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-18 11:23:08 --> Input Class Initialized
INFO - 2024-02-18 11:23:08 --> Language Class Initialized
INFO - 2024-02-18 11:23:08 --> Loader Class Initialized
INFO - 2024-02-18 11:23:08 --> Helper loaded: url_helper
INFO - 2024-02-18 11:23:08 --> Helper loaded: file_helper
INFO - 2024-02-18 11:23:08 --> Helper loaded: html_helper
INFO - 2024-02-18 11:23:08 --> Helper loaded: text_helper
INFO - 2024-02-18 11:23:08 --> Helper loaded: form_helper
INFO - 2024-02-18 11:23:08 --> Helper loaded: lang_helper
INFO - 2024-02-18 11:23:08 --> Helper loaded: security_helper
INFO - 2024-02-18 11:23:08 --> Helper loaded: cookie_helper
INFO - 2024-02-18 11:23:08 --> Database Driver Class Initialized
INFO - 2024-02-18 11:23:08 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-18 11:23:08 --> Parser Class Initialized
INFO - 2024-02-18 11:23:08 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-18 11:23:08 --> Pagination Class Initialized
INFO - 2024-02-18 11:23:08 --> Form Validation Class Initialized
INFO - 2024-02-18 11:23:08 --> Controller Class Initialized
DEBUG - 2024-02-18 11:23:08 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-18 11:23:08 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-18 11:23:08 --> Model Class Initialized
DEBUG - 2024-02-18 11:23:08 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-18 11:23:08 --> Model Class Initialized
INFO - 2024-02-18 11:23:08 --> Final output sent to browser
DEBUG - 2024-02-18 11:23:08 --> Total execution time: 0.0213
ERROR - 2024-02-18 11:23:11 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-18 11:23:11 --> Config Class Initialized
INFO - 2024-02-18 11:23:11 --> Hooks Class Initialized
DEBUG - 2024-02-18 11:23:11 --> UTF-8 Support Enabled
INFO - 2024-02-18 11:23:11 --> Utf8 Class Initialized
INFO - 2024-02-18 11:23:11 --> URI Class Initialized
INFO - 2024-02-18 11:23:11 --> Router Class Initialized
INFO - 2024-02-18 11:23:11 --> Output Class Initialized
INFO - 2024-02-18 11:23:11 --> Security Class Initialized
DEBUG - 2024-02-18 11:23:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-18 11:23:11 --> Input Class Initialized
INFO - 2024-02-18 11:23:11 --> Language Class Initialized
INFO - 2024-02-18 11:23:11 --> Loader Class Initialized
INFO - 2024-02-18 11:23:11 --> Helper loaded: url_helper
INFO - 2024-02-18 11:23:11 --> Helper loaded: file_helper
INFO - 2024-02-18 11:23:11 --> Helper loaded: html_helper
INFO - 2024-02-18 11:23:11 --> Helper loaded: text_helper
INFO - 2024-02-18 11:23:11 --> Helper loaded: form_helper
INFO - 2024-02-18 11:23:11 --> Helper loaded: lang_helper
INFO - 2024-02-18 11:23:11 --> Helper loaded: security_helper
INFO - 2024-02-18 11:23:11 --> Helper loaded: cookie_helper
INFO - 2024-02-18 11:23:11 --> Database Driver Class Initialized
INFO - 2024-02-18 11:23:11 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-18 11:23:11 --> Parser Class Initialized
INFO - 2024-02-18 11:23:11 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-18 11:23:11 --> Pagination Class Initialized
INFO - 2024-02-18 11:23:11 --> Form Validation Class Initialized
INFO - 2024-02-18 11:23:11 --> Controller Class Initialized
DEBUG - 2024-02-18 11:23:11 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-18 11:23:11 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-18 11:23:11 --> Model Class Initialized
DEBUG - 2024-02-18 11:23:11 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-18 11:23:11 --> Model Class Initialized
INFO - 2024-02-18 11:23:11 --> Final output sent to browser
DEBUG - 2024-02-18 11:23:11 --> Total execution time: 0.0202
ERROR - 2024-02-18 11:23:12 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-18 11:23:12 --> Config Class Initialized
INFO - 2024-02-18 11:23:12 --> Hooks Class Initialized
DEBUG - 2024-02-18 11:23:12 --> UTF-8 Support Enabled
INFO - 2024-02-18 11:23:12 --> Utf8 Class Initialized
INFO - 2024-02-18 11:23:12 --> URI Class Initialized
INFO - 2024-02-18 11:23:12 --> Router Class Initialized
INFO - 2024-02-18 11:23:12 --> Output Class Initialized
INFO - 2024-02-18 11:23:12 --> Security Class Initialized
DEBUG - 2024-02-18 11:23:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-18 11:23:12 --> Input Class Initialized
INFO - 2024-02-18 11:23:12 --> Language Class Initialized
INFO - 2024-02-18 11:23:12 --> Loader Class Initialized
INFO - 2024-02-18 11:23:12 --> Helper loaded: url_helper
INFO - 2024-02-18 11:23:12 --> Helper loaded: file_helper
INFO - 2024-02-18 11:23:12 --> Helper loaded: html_helper
INFO - 2024-02-18 11:23:12 --> Helper loaded: text_helper
INFO - 2024-02-18 11:23:12 --> Helper loaded: form_helper
INFO - 2024-02-18 11:23:12 --> Helper loaded: lang_helper
INFO - 2024-02-18 11:23:12 --> Helper loaded: security_helper
INFO - 2024-02-18 11:23:12 --> Helper loaded: cookie_helper
INFO - 2024-02-18 11:23:12 --> Database Driver Class Initialized
INFO - 2024-02-18 11:23:12 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-18 11:23:12 --> Parser Class Initialized
INFO - 2024-02-18 11:23:12 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-18 11:23:12 --> Pagination Class Initialized
INFO - 2024-02-18 11:23:12 --> Form Validation Class Initialized
INFO - 2024-02-18 11:23:12 --> Controller Class Initialized
DEBUG - 2024-02-18 11:23:12 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-18 11:23:12 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-18 11:23:12 --> Model Class Initialized
DEBUG - 2024-02-18 11:23:12 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-18 11:23:12 --> Model Class Initialized
INFO - 2024-02-18 11:23:12 --> Final output sent to browser
DEBUG - 2024-02-18 11:23:12 --> Total execution time: 0.0199
ERROR - 2024-02-18 11:23:13 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-18 11:23:13 --> Config Class Initialized
INFO - 2024-02-18 11:23:13 --> Hooks Class Initialized
DEBUG - 2024-02-18 11:23:13 --> UTF-8 Support Enabled
INFO - 2024-02-18 11:23:13 --> Utf8 Class Initialized
INFO - 2024-02-18 11:23:13 --> URI Class Initialized
INFO - 2024-02-18 11:23:13 --> Router Class Initialized
INFO - 2024-02-18 11:23:13 --> Output Class Initialized
INFO - 2024-02-18 11:23:13 --> Security Class Initialized
DEBUG - 2024-02-18 11:23:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-18 11:23:13 --> Input Class Initialized
INFO - 2024-02-18 11:23:13 --> Language Class Initialized
INFO - 2024-02-18 11:23:13 --> Loader Class Initialized
INFO - 2024-02-18 11:23:13 --> Helper loaded: url_helper
INFO - 2024-02-18 11:23:13 --> Helper loaded: file_helper
INFO - 2024-02-18 11:23:13 --> Helper loaded: html_helper
INFO - 2024-02-18 11:23:13 --> Helper loaded: text_helper
INFO - 2024-02-18 11:23:13 --> Helper loaded: form_helper
INFO - 2024-02-18 11:23:13 --> Helper loaded: lang_helper
INFO - 2024-02-18 11:23:13 --> Helper loaded: security_helper
INFO - 2024-02-18 11:23:13 --> Helper loaded: cookie_helper
INFO - 2024-02-18 11:23:13 --> Database Driver Class Initialized
INFO - 2024-02-18 11:23:13 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-18 11:23:13 --> Parser Class Initialized
INFO - 2024-02-18 11:23:13 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-18 11:23:13 --> Pagination Class Initialized
INFO - 2024-02-18 11:23:13 --> Form Validation Class Initialized
INFO - 2024-02-18 11:23:13 --> Controller Class Initialized
DEBUG - 2024-02-18 11:23:13 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-18 11:23:13 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-18 11:23:13 --> Model Class Initialized
DEBUG - 2024-02-18 11:23:13 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-18 11:23:13 --> Model Class Initialized
INFO - 2024-02-18 11:23:13 --> Final output sent to browser
DEBUG - 2024-02-18 11:23:13 --> Total execution time: 0.0144
ERROR - 2024-02-18 11:23:15 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-18 11:23:15 --> Config Class Initialized
INFO - 2024-02-18 11:23:15 --> Hooks Class Initialized
DEBUG - 2024-02-18 11:23:15 --> UTF-8 Support Enabled
INFO - 2024-02-18 11:23:15 --> Utf8 Class Initialized
INFO - 2024-02-18 11:23:15 --> URI Class Initialized
INFO - 2024-02-18 11:23:15 --> Router Class Initialized
INFO - 2024-02-18 11:23:15 --> Output Class Initialized
INFO - 2024-02-18 11:23:15 --> Security Class Initialized
DEBUG - 2024-02-18 11:23:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-18 11:23:15 --> Input Class Initialized
INFO - 2024-02-18 11:23:15 --> Language Class Initialized
INFO - 2024-02-18 11:23:15 --> Loader Class Initialized
INFO - 2024-02-18 11:23:15 --> Helper loaded: url_helper
INFO - 2024-02-18 11:23:15 --> Helper loaded: file_helper
INFO - 2024-02-18 11:23:15 --> Helper loaded: html_helper
INFO - 2024-02-18 11:23:15 --> Helper loaded: text_helper
INFO - 2024-02-18 11:23:15 --> Helper loaded: form_helper
INFO - 2024-02-18 11:23:15 --> Helper loaded: lang_helper
INFO - 2024-02-18 11:23:15 --> Helper loaded: security_helper
INFO - 2024-02-18 11:23:15 --> Helper loaded: cookie_helper
INFO - 2024-02-18 11:23:15 --> Database Driver Class Initialized
INFO - 2024-02-18 11:23:15 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-18 11:23:15 --> Parser Class Initialized
INFO - 2024-02-18 11:23:15 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-18 11:23:15 --> Pagination Class Initialized
INFO - 2024-02-18 11:23:15 --> Form Validation Class Initialized
INFO - 2024-02-18 11:23:15 --> Controller Class Initialized
DEBUG - 2024-02-18 11:23:15 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-18 11:23:15 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-18 11:23:15 --> Model Class Initialized
DEBUG - 2024-02-18 11:23:15 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-18 11:23:15 --> Model Class Initialized
INFO - 2024-02-18 11:23:15 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/customer/edit_customer_form.php
DEBUG - 2024-02-18 11:23:15 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-02-18 11:23:15 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-02-18 11:23:15 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-02-18 11:23:15 --> Model Class Initialized
INFO - 2024-02-18 11:23:15 --> Model Class Initialized
INFO - 2024-02-18 11:23:15 --> Model Class Initialized
INFO - 2024-02-18 11:23:15 --> Model Class Initialized
INFO - 2024-02-18 11:23:15 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-02-18 11:23:15 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-02-18 11:23:15 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-02-18 11:23:15 --> Final output sent to browser
DEBUG - 2024-02-18 11:23:15 --> Total execution time: 0.2274
ERROR - 2024-02-18 11:24:06 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-18 11:24:06 --> Config Class Initialized
INFO - 2024-02-18 11:24:06 --> Hooks Class Initialized
DEBUG - 2024-02-18 11:24:06 --> UTF-8 Support Enabled
INFO - 2024-02-18 11:24:06 --> Utf8 Class Initialized
INFO - 2024-02-18 11:24:06 --> URI Class Initialized
INFO - 2024-02-18 11:24:06 --> Router Class Initialized
INFO - 2024-02-18 11:24:06 --> Output Class Initialized
INFO - 2024-02-18 11:24:06 --> Security Class Initialized
DEBUG - 2024-02-18 11:24:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-18 11:24:06 --> Input Class Initialized
INFO - 2024-02-18 11:24:06 --> Language Class Initialized
INFO - 2024-02-18 11:24:06 --> Loader Class Initialized
INFO - 2024-02-18 11:24:06 --> Helper loaded: url_helper
INFO - 2024-02-18 11:24:06 --> Helper loaded: file_helper
INFO - 2024-02-18 11:24:06 --> Helper loaded: html_helper
INFO - 2024-02-18 11:24:06 --> Helper loaded: text_helper
INFO - 2024-02-18 11:24:06 --> Helper loaded: form_helper
INFO - 2024-02-18 11:24:06 --> Helper loaded: lang_helper
INFO - 2024-02-18 11:24:06 --> Helper loaded: security_helper
INFO - 2024-02-18 11:24:06 --> Helper loaded: cookie_helper
INFO - 2024-02-18 11:24:06 --> Database Driver Class Initialized
INFO - 2024-02-18 11:24:06 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-18 11:24:06 --> Parser Class Initialized
INFO - 2024-02-18 11:24:06 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-18 11:24:06 --> Pagination Class Initialized
INFO - 2024-02-18 11:24:06 --> Form Validation Class Initialized
INFO - 2024-02-18 11:24:06 --> Controller Class Initialized
DEBUG - 2024-02-18 11:24:06 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-18 11:24:06 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-18 11:24:06 --> Model Class Initialized
DEBUG - 2024-02-18 11:24:06 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-18 11:24:06 --> Model Class Initialized
ERROR - 2024-02-18 11:24:06 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-18 11:24:06 --> Config Class Initialized
INFO - 2024-02-18 11:24:06 --> Hooks Class Initialized
DEBUG - 2024-02-18 11:24:06 --> UTF-8 Support Enabled
INFO - 2024-02-18 11:24:06 --> Utf8 Class Initialized
INFO - 2024-02-18 11:24:06 --> URI Class Initialized
INFO - 2024-02-18 11:24:06 --> Router Class Initialized
INFO - 2024-02-18 11:24:06 --> Output Class Initialized
INFO - 2024-02-18 11:24:06 --> Security Class Initialized
DEBUG - 2024-02-18 11:24:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-18 11:24:06 --> Input Class Initialized
INFO - 2024-02-18 11:24:06 --> Language Class Initialized
INFO - 2024-02-18 11:24:06 --> Loader Class Initialized
INFO - 2024-02-18 11:24:06 --> Helper loaded: url_helper
INFO - 2024-02-18 11:24:06 --> Helper loaded: file_helper
INFO - 2024-02-18 11:24:06 --> Helper loaded: html_helper
INFO - 2024-02-18 11:24:06 --> Helper loaded: text_helper
INFO - 2024-02-18 11:24:06 --> Helper loaded: form_helper
INFO - 2024-02-18 11:24:06 --> Helper loaded: lang_helper
INFO - 2024-02-18 11:24:06 --> Helper loaded: security_helper
INFO - 2024-02-18 11:24:06 --> Helper loaded: cookie_helper
INFO - 2024-02-18 11:24:06 --> Database Driver Class Initialized
INFO - 2024-02-18 11:24:06 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-18 11:24:06 --> Parser Class Initialized
INFO - 2024-02-18 11:24:06 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-18 11:24:06 --> Pagination Class Initialized
INFO - 2024-02-18 11:24:06 --> Form Validation Class Initialized
INFO - 2024-02-18 11:24:06 --> Controller Class Initialized
DEBUG - 2024-02-18 11:24:06 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-18 11:24:06 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-18 11:24:06 --> Model Class Initialized
DEBUG - 2024-02-18 11:24:06 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-18 11:24:06 --> Model Class Initialized
DEBUG - 2024-02-18 11:24:06 --> Lcustomer class already loaded. Second attempt ignored.
INFO - 2024-02-18 11:24:06 --> Model Class Initialized
INFO - 2024-02-18 11:24:06 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/customer/customer.php
DEBUG - 2024-02-18 11:24:06 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-02-18 11:24:06 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-02-18 11:24:06 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-02-18 11:24:06 --> Model Class Initialized
INFO - 2024-02-18 11:24:06 --> Model Class Initialized
INFO - 2024-02-18 11:24:06 --> Model Class Initialized
INFO - 2024-02-18 11:24:06 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-02-18 11:24:06 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-02-18 11:24:06 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-02-18 11:24:06 --> Final output sent to browser
DEBUG - 2024-02-18 11:24:06 --> Total execution time: 0.2090
ERROR - 2024-02-18 11:24:07 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-18 11:24:07 --> Config Class Initialized
INFO - 2024-02-18 11:24:07 --> Hooks Class Initialized
DEBUG - 2024-02-18 11:24:07 --> UTF-8 Support Enabled
INFO - 2024-02-18 11:24:07 --> Utf8 Class Initialized
INFO - 2024-02-18 11:24:07 --> URI Class Initialized
INFO - 2024-02-18 11:24:07 --> Router Class Initialized
INFO - 2024-02-18 11:24:07 --> Output Class Initialized
INFO - 2024-02-18 11:24:07 --> Security Class Initialized
DEBUG - 2024-02-18 11:24:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-18 11:24:07 --> Input Class Initialized
INFO - 2024-02-18 11:24:07 --> Language Class Initialized
INFO - 2024-02-18 11:24:07 --> Loader Class Initialized
INFO - 2024-02-18 11:24:07 --> Helper loaded: url_helper
INFO - 2024-02-18 11:24:07 --> Helper loaded: file_helper
INFO - 2024-02-18 11:24:07 --> Helper loaded: html_helper
INFO - 2024-02-18 11:24:07 --> Helper loaded: text_helper
INFO - 2024-02-18 11:24:07 --> Helper loaded: form_helper
INFO - 2024-02-18 11:24:07 --> Helper loaded: lang_helper
INFO - 2024-02-18 11:24:07 --> Helper loaded: security_helper
INFO - 2024-02-18 11:24:07 --> Helper loaded: cookie_helper
INFO - 2024-02-18 11:24:07 --> Database Driver Class Initialized
INFO - 2024-02-18 11:24:07 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-18 11:24:07 --> Parser Class Initialized
INFO - 2024-02-18 11:24:07 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-18 11:24:07 --> Pagination Class Initialized
INFO - 2024-02-18 11:24:07 --> Form Validation Class Initialized
INFO - 2024-02-18 11:24:07 --> Controller Class Initialized
DEBUG - 2024-02-18 11:24:07 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-18 11:24:07 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-18 11:24:07 --> Model Class Initialized
DEBUG - 2024-02-18 11:24:07 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-18 11:24:07 --> Model Class Initialized
INFO - 2024-02-18 11:24:07 --> Final output sent to browser
DEBUG - 2024-02-18 11:24:07 --> Total execution time: 0.0290
ERROR - 2024-02-18 11:24:14 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-18 11:24:14 --> Config Class Initialized
INFO - 2024-02-18 11:24:14 --> Hooks Class Initialized
DEBUG - 2024-02-18 11:24:14 --> UTF-8 Support Enabled
INFO - 2024-02-18 11:24:14 --> Utf8 Class Initialized
INFO - 2024-02-18 11:24:14 --> URI Class Initialized
INFO - 2024-02-18 11:24:14 --> Router Class Initialized
INFO - 2024-02-18 11:24:14 --> Output Class Initialized
INFO - 2024-02-18 11:24:14 --> Security Class Initialized
DEBUG - 2024-02-18 11:24:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-18 11:24:14 --> Input Class Initialized
INFO - 2024-02-18 11:24:14 --> Language Class Initialized
INFO - 2024-02-18 11:24:14 --> Loader Class Initialized
INFO - 2024-02-18 11:24:14 --> Helper loaded: url_helper
INFO - 2024-02-18 11:24:14 --> Helper loaded: file_helper
INFO - 2024-02-18 11:24:14 --> Helper loaded: html_helper
INFO - 2024-02-18 11:24:14 --> Helper loaded: text_helper
INFO - 2024-02-18 11:24:14 --> Helper loaded: form_helper
INFO - 2024-02-18 11:24:14 --> Helper loaded: lang_helper
INFO - 2024-02-18 11:24:14 --> Helper loaded: security_helper
INFO - 2024-02-18 11:24:14 --> Helper loaded: cookie_helper
INFO - 2024-02-18 11:24:14 --> Database Driver Class Initialized
INFO - 2024-02-18 11:24:14 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-18 11:24:14 --> Parser Class Initialized
INFO - 2024-02-18 11:24:14 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-18 11:24:14 --> Pagination Class Initialized
INFO - 2024-02-18 11:24:14 --> Form Validation Class Initialized
INFO - 2024-02-18 11:24:14 --> Controller Class Initialized
DEBUG - 2024-02-18 11:24:14 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-18 11:24:14 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-18 11:24:14 --> Model Class Initialized
DEBUG - 2024-02-18 11:24:14 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-18 11:24:14 --> Model Class Initialized
INFO - 2024-02-18 11:24:14 --> Final output sent to browser
DEBUG - 2024-02-18 11:24:14 --> Total execution time: 0.2520
ERROR - 2024-02-18 11:24:26 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-18 11:24:26 --> Config Class Initialized
INFO - 2024-02-18 11:24:26 --> Hooks Class Initialized
DEBUG - 2024-02-18 11:24:26 --> UTF-8 Support Enabled
INFO - 2024-02-18 11:24:26 --> Utf8 Class Initialized
INFO - 2024-02-18 11:24:26 --> URI Class Initialized
INFO - 2024-02-18 11:24:26 --> Router Class Initialized
INFO - 2024-02-18 11:24:26 --> Output Class Initialized
INFO - 2024-02-18 11:24:26 --> Security Class Initialized
DEBUG - 2024-02-18 11:24:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-18 11:24:26 --> Input Class Initialized
INFO - 2024-02-18 11:24:26 --> Language Class Initialized
INFO - 2024-02-18 11:24:26 --> Loader Class Initialized
INFO - 2024-02-18 11:24:26 --> Helper loaded: url_helper
INFO - 2024-02-18 11:24:26 --> Helper loaded: file_helper
INFO - 2024-02-18 11:24:26 --> Helper loaded: html_helper
INFO - 2024-02-18 11:24:26 --> Helper loaded: text_helper
INFO - 2024-02-18 11:24:26 --> Helper loaded: form_helper
INFO - 2024-02-18 11:24:26 --> Helper loaded: lang_helper
INFO - 2024-02-18 11:24:26 --> Helper loaded: security_helper
INFO - 2024-02-18 11:24:26 --> Helper loaded: cookie_helper
INFO - 2024-02-18 11:24:26 --> Database Driver Class Initialized
INFO - 2024-02-18 11:24:26 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-18 11:24:26 --> Parser Class Initialized
INFO - 2024-02-18 11:24:26 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-18 11:24:26 --> Pagination Class Initialized
INFO - 2024-02-18 11:24:26 --> Form Validation Class Initialized
INFO - 2024-02-18 11:24:26 --> Controller Class Initialized
DEBUG - 2024-02-18 11:24:26 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-18 11:24:26 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-18 11:24:26 --> Model Class Initialized
DEBUG - 2024-02-18 11:24:26 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-18 11:24:26 --> Model Class Initialized
INFO - 2024-02-18 11:24:26 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/customer/edit_customer_form.php
DEBUG - 2024-02-18 11:24:26 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-02-18 11:24:26 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-02-18 11:24:26 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-02-18 11:24:26 --> Model Class Initialized
INFO - 2024-02-18 11:24:26 --> Model Class Initialized
INFO - 2024-02-18 11:24:26 --> Model Class Initialized
INFO - 2024-02-18 11:24:26 --> Model Class Initialized
INFO - 2024-02-18 11:24:26 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-02-18 11:24:26 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-02-18 11:24:26 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-02-18 11:24:26 --> Final output sent to browser
DEBUG - 2024-02-18 11:24:26 --> Total execution time: 0.2517
ERROR - 2024-02-18 11:25:05 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-18 11:25:05 --> Config Class Initialized
INFO - 2024-02-18 11:25:05 --> Hooks Class Initialized
DEBUG - 2024-02-18 11:25:05 --> UTF-8 Support Enabled
INFO - 2024-02-18 11:25:05 --> Utf8 Class Initialized
INFO - 2024-02-18 11:25:05 --> URI Class Initialized
INFO - 2024-02-18 11:25:05 --> Router Class Initialized
INFO - 2024-02-18 11:25:05 --> Output Class Initialized
INFO - 2024-02-18 11:25:05 --> Security Class Initialized
DEBUG - 2024-02-18 11:25:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-18 11:25:05 --> Input Class Initialized
INFO - 2024-02-18 11:25:05 --> Language Class Initialized
INFO - 2024-02-18 11:25:05 --> Loader Class Initialized
INFO - 2024-02-18 11:25:05 --> Helper loaded: url_helper
INFO - 2024-02-18 11:25:05 --> Helper loaded: file_helper
INFO - 2024-02-18 11:25:05 --> Helper loaded: html_helper
INFO - 2024-02-18 11:25:05 --> Helper loaded: text_helper
INFO - 2024-02-18 11:25:05 --> Helper loaded: form_helper
INFO - 2024-02-18 11:25:05 --> Helper loaded: lang_helper
INFO - 2024-02-18 11:25:05 --> Helper loaded: security_helper
INFO - 2024-02-18 11:25:05 --> Helper loaded: cookie_helper
INFO - 2024-02-18 11:25:05 --> Database Driver Class Initialized
INFO - 2024-02-18 11:25:05 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-18 11:25:05 --> Parser Class Initialized
INFO - 2024-02-18 11:25:05 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-18 11:25:05 --> Pagination Class Initialized
INFO - 2024-02-18 11:25:05 --> Form Validation Class Initialized
INFO - 2024-02-18 11:25:05 --> Controller Class Initialized
DEBUG - 2024-02-18 11:25:05 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-18 11:25:05 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-18 11:25:05 --> Model Class Initialized
DEBUG - 2024-02-18 11:25:05 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-18 11:25:05 --> Model Class Initialized
ERROR - 2024-02-18 11:25:06 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-18 11:25:06 --> Config Class Initialized
INFO - 2024-02-18 11:25:06 --> Hooks Class Initialized
DEBUG - 2024-02-18 11:25:06 --> UTF-8 Support Enabled
INFO - 2024-02-18 11:25:06 --> Utf8 Class Initialized
INFO - 2024-02-18 11:25:06 --> URI Class Initialized
INFO - 2024-02-18 11:25:06 --> Router Class Initialized
INFO - 2024-02-18 11:25:06 --> Output Class Initialized
INFO - 2024-02-18 11:25:06 --> Security Class Initialized
DEBUG - 2024-02-18 11:25:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-18 11:25:06 --> Input Class Initialized
INFO - 2024-02-18 11:25:06 --> Language Class Initialized
INFO - 2024-02-18 11:25:06 --> Loader Class Initialized
INFO - 2024-02-18 11:25:06 --> Helper loaded: url_helper
INFO - 2024-02-18 11:25:06 --> Helper loaded: file_helper
INFO - 2024-02-18 11:25:06 --> Helper loaded: html_helper
INFO - 2024-02-18 11:25:06 --> Helper loaded: text_helper
INFO - 2024-02-18 11:25:06 --> Helper loaded: form_helper
INFO - 2024-02-18 11:25:06 --> Helper loaded: lang_helper
INFO - 2024-02-18 11:25:06 --> Helper loaded: security_helper
INFO - 2024-02-18 11:25:06 --> Helper loaded: cookie_helper
INFO - 2024-02-18 11:25:06 --> Database Driver Class Initialized
INFO - 2024-02-18 11:25:06 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-18 11:25:06 --> Parser Class Initialized
INFO - 2024-02-18 11:25:06 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-18 11:25:06 --> Pagination Class Initialized
INFO - 2024-02-18 11:25:06 --> Form Validation Class Initialized
INFO - 2024-02-18 11:25:06 --> Controller Class Initialized
DEBUG - 2024-02-18 11:25:06 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-18 11:25:06 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-18 11:25:06 --> Model Class Initialized
DEBUG - 2024-02-18 11:25:06 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-18 11:25:06 --> Model Class Initialized
DEBUG - 2024-02-18 11:25:06 --> Lcustomer class already loaded. Second attempt ignored.
INFO - 2024-02-18 11:25:06 --> Model Class Initialized
INFO - 2024-02-18 11:25:06 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/customer/customer.php
DEBUG - 2024-02-18 11:25:06 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-02-18 11:25:06 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-02-18 11:25:06 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-02-18 11:25:06 --> Model Class Initialized
INFO - 2024-02-18 11:25:06 --> Model Class Initialized
INFO - 2024-02-18 11:25:06 --> Model Class Initialized
INFO - 2024-02-18 11:25:06 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-02-18 11:25:06 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-02-18 11:25:06 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-02-18 11:25:06 --> Final output sent to browser
DEBUG - 2024-02-18 11:25:06 --> Total execution time: 0.2095
ERROR - 2024-02-18 11:25:07 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-18 11:25:07 --> Config Class Initialized
INFO - 2024-02-18 11:25:07 --> Hooks Class Initialized
DEBUG - 2024-02-18 11:25:07 --> UTF-8 Support Enabled
INFO - 2024-02-18 11:25:07 --> Utf8 Class Initialized
INFO - 2024-02-18 11:25:07 --> URI Class Initialized
INFO - 2024-02-18 11:25:07 --> Router Class Initialized
INFO - 2024-02-18 11:25:07 --> Output Class Initialized
INFO - 2024-02-18 11:25:07 --> Security Class Initialized
DEBUG - 2024-02-18 11:25:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-18 11:25:07 --> Input Class Initialized
INFO - 2024-02-18 11:25:07 --> Language Class Initialized
INFO - 2024-02-18 11:25:07 --> Loader Class Initialized
INFO - 2024-02-18 11:25:07 --> Helper loaded: url_helper
INFO - 2024-02-18 11:25:07 --> Helper loaded: file_helper
INFO - 2024-02-18 11:25:07 --> Helper loaded: html_helper
INFO - 2024-02-18 11:25:07 --> Helper loaded: text_helper
INFO - 2024-02-18 11:25:07 --> Helper loaded: form_helper
INFO - 2024-02-18 11:25:07 --> Helper loaded: lang_helper
INFO - 2024-02-18 11:25:07 --> Helper loaded: security_helper
INFO - 2024-02-18 11:25:07 --> Helper loaded: cookie_helper
INFO - 2024-02-18 11:25:07 --> Database Driver Class Initialized
INFO - 2024-02-18 11:25:07 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-18 11:25:07 --> Parser Class Initialized
INFO - 2024-02-18 11:25:07 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-18 11:25:07 --> Pagination Class Initialized
INFO - 2024-02-18 11:25:07 --> Form Validation Class Initialized
INFO - 2024-02-18 11:25:07 --> Controller Class Initialized
DEBUG - 2024-02-18 11:25:07 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-18 11:25:07 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-18 11:25:07 --> Model Class Initialized
DEBUG - 2024-02-18 11:25:07 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-18 11:25:07 --> Model Class Initialized
INFO - 2024-02-18 11:25:07 --> Final output sent to browser
DEBUG - 2024-02-18 11:25:07 --> Total execution time: 0.0320
ERROR - 2024-02-18 11:25:10 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-18 11:25:10 --> Config Class Initialized
INFO - 2024-02-18 11:25:10 --> Hooks Class Initialized
DEBUG - 2024-02-18 11:25:10 --> UTF-8 Support Enabled
INFO - 2024-02-18 11:25:10 --> Utf8 Class Initialized
INFO - 2024-02-18 11:25:10 --> URI Class Initialized
INFO - 2024-02-18 11:25:10 --> Router Class Initialized
INFO - 2024-02-18 11:25:10 --> Output Class Initialized
INFO - 2024-02-18 11:25:10 --> Security Class Initialized
DEBUG - 2024-02-18 11:25:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-18 11:25:10 --> Input Class Initialized
INFO - 2024-02-18 11:25:10 --> Language Class Initialized
INFO - 2024-02-18 11:25:10 --> Loader Class Initialized
INFO - 2024-02-18 11:25:10 --> Helper loaded: url_helper
INFO - 2024-02-18 11:25:10 --> Helper loaded: file_helper
INFO - 2024-02-18 11:25:10 --> Helper loaded: html_helper
INFO - 2024-02-18 11:25:10 --> Helper loaded: text_helper
INFO - 2024-02-18 11:25:10 --> Helper loaded: form_helper
INFO - 2024-02-18 11:25:10 --> Helper loaded: lang_helper
INFO - 2024-02-18 11:25:10 --> Helper loaded: security_helper
INFO - 2024-02-18 11:25:10 --> Helper loaded: cookie_helper
INFO - 2024-02-18 11:25:10 --> Database Driver Class Initialized
INFO - 2024-02-18 11:25:10 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-18 11:25:10 --> Parser Class Initialized
INFO - 2024-02-18 11:25:10 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-18 11:25:10 --> Pagination Class Initialized
INFO - 2024-02-18 11:25:10 --> Form Validation Class Initialized
INFO - 2024-02-18 11:25:10 --> Controller Class Initialized
DEBUG - 2024-02-18 11:25:10 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-18 11:25:10 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-18 11:25:10 --> Model Class Initialized
DEBUG - 2024-02-18 11:25:10 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-18 11:25:10 --> Model Class Initialized
INFO - 2024-02-18 11:25:11 --> Final output sent to browser
DEBUG - 2024-02-18 11:25:11 --> Total execution time: 0.2493
ERROR - 2024-02-18 11:25:17 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-18 11:25:17 --> Config Class Initialized
INFO - 2024-02-18 11:25:17 --> Hooks Class Initialized
DEBUG - 2024-02-18 11:25:17 --> UTF-8 Support Enabled
INFO - 2024-02-18 11:25:17 --> Utf8 Class Initialized
INFO - 2024-02-18 11:25:17 --> URI Class Initialized
INFO - 2024-02-18 11:25:17 --> Router Class Initialized
INFO - 2024-02-18 11:25:17 --> Output Class Initialized
INFO - 2024-02-18 11:25:17 --> Security Class Initialized
DEBUG - 2024-02-18 11:25:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-18 11:25:17 --> Input Class Initialized
INFO - 2024-02-18 11:25:17 --> Language Class Initialized
INFO - 2024-02-18 11:25:17 --> Loader Class Initialized
INFO - 2024-02-18 11:25:17 --> Helper loaded: url_helper
INFO - 2024-02-18 11:25:17 --> Helper loaded: file_helper
INFO - 2024-02-18 11:25:17 --> Helper loaded: html_helper
INFO - 2024-02-18 11:25:17 --> Helper loaded: text_helper
INFO - 2024-02-18 11:25:17 --> Helper loaded: form_helper
INFO - 2024-02-18 11:25:17 --> Helper loaded: lang_helper
INFO - 2024-02-18 11:25:17 --> Helper loaded: security_helper
INFO - 2024-02-18 11:25:17 --> Helper loaded: cookie_helper
INFO - 2024-02-18 11:25:17 --> Database Driver Class Initialized
INFO - 2024-02-18 11:25:17 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-18 11:25:17 --> Parser Class Initialized
INFO - 2024-02-18 11:25:17 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-18 11:25:17 --> Pagination Class Initialized
INFO - 2024-02-18 11:25:17 --> Form Validation Class Initialized
INFO - 2024-02-18 11:25:17 --> Controller Class Initialized
INFO - 2024-02-18 11:25:17 --> Model Class Initialized
DEBUG - 2024-02-18 11:25:17 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-18 11:25:17 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-18 11:25:17 --> Model Class Initialized
DEBUG - 2024-02-18 11:25:17 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-18 11:25:17 --> Model Class Initialized
INFO - 2024-02-18 11:25:17 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice.php
DEBUG - 2024-02-18 11:25:17 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-02-18 11:25:17 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-02-18 11:25:17 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-02-18 11:25:17 --> Model Class Initialized
INFO - 2024-02-18 11:25:17 --> Model Class Initialized
INFO - 2024-02-18 11:25:17 --> Model Class Initialized
INFO - 2024-02-18 11:25:17 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-02-18 11:25:17 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-02-18 11:25:17 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-02-18 11:25:17 --> Final output sent to browser
DEBUG - 2024-02-18 11:25:17 --> Total execution time: 0.2175
ERROR - 2024-02-18 11:25:17 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-18 11:25:17 --> Config Class Initialized
INFO - 2024-02-18 11:25:17 --> Hooks Class Initialized
DEBUG - 2024-02-18 11:25:17 --> UTF-8 Support Enabled
INFO - 2024-02-18 11:25:17 --> Utf8 Class Initialized
INFO - 2024-02-18 11:25:17 --> URI Class Initialized
INFO - 2024-02-18 11:25:17 --> Router Class Initialized
INFO - 2024-02-18 11:25:17 --> Output Class Initialized
INFO - 2024-02-18 11:25:17 --> Security Class Initialized
DEBUG - 2024-02-18 11:25:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-18 11:25:17 --> Input Class Initialized
INFO - 2024-02-18 11:25:17 --> Language Class Initialized
INFO - 2024-02-18 11:25:17 --> Loader Class Initialized
INFO - 2024-02-18 11:25:17 --> Helper loaded: url_helper
INFO - 2024-02-18 11:25:17 --> Helper loaded: file_helper
INFO - 2024-02-18 11:25:17 --> Helper loaded: html_helper
INFO - 2024-02-18 11:25:17 --> Helper loaded: text_helper
INFO - 2024-02-18 11:25:17 --> Helper loaded: form_helper
INFO - 2024-02-18 11:25:17 --> Helper loaded: lang_helper
INFO - 2024-02-18 11:25:17 --> Helper loaded: security_helper
INFO - 2024-02-18 11:25:17 --> Helper loaded: cookie_helper
INFO - 2024-02-18 11:25:17 --> Database Driver Class Initialized
INFO - 2024-02-18 11:25:17 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-18 11:25:17 --> Parser Class Initialized
INFO - 2024-02-18 11:25:17 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-18 11:25:17 --> Pagination Class Initialized
INFO - 2024-02-18 11:25:17 --> Form Validation Class Initialized
INFO - 2024-02-18 11:25:17 --> Controller Class Initialized
INFO - 2024-02-18 11:25:17 --> Model Class Initialized
DEBUG - 2024-02-18 11:25:17 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-18 11:25:17 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-18 11:25:17 --> Model Class Initialized
DEBUG - 2024-02-18 11:25:17 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-18 11:25:17 --> Model Class Initialized
INFO - 2024-02-18 11:25:17 --> Final output sent to browser
DEBUG - 2024-02-18 11:25:17 --> Total execution time: 0.0561
ERROR - 2024-02-18 11:25:26 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-18 11:25:26 --> Config Class Initialized
INFO - 2024-02-18 11:25:26 --> Hooks Class Initialized
DEBUG - 2024-02-18 11:25:26 --> UTF-8 Support Enabled
INFO - 2024-02-18 11:25:26 --> Utf8 Class Initialized
INFO - 2024-02-18 11:25:26 --> URI Class Initialized
INFO - 2024-02-18 11:25:26 --> Router Class Initialized
INFO - 2024-02-18 11:25:26 --> Output Class Initialized
INFO - 2024-02-18 11:25:26 --> Security Class Initialized
DEBUG - 2024-02-18 11:25:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-18 11:25:26 --> Input Class Initialized
INFO - 2024-02-18 11:25:26 --> Language Class Initialized
INFO - 2024-02-18 11:25:26 --> Loader Class Initialized
INFO - 2024-02-18 11:25:26 --> Helper loaded: url_helper
INFO - 2024-02-18 11:25:26 --> Helper loaded: file_helper
INFO - 2024-02-18 11:25:26 --> Helper loaded: html_helper
INFO - 2024-02-18 11:25:26 --> Helper loaded: text_helper
INFO - 2024-02-18 11:25:26 --> Helper loaded: form_helper
INFO - 2024-02-18 11:25:26 --> Helper loaded: lang_helper
INFO - 2024-02-18 11:25:26 --> Helper loaded: security_helper
INFO - 2024-02-18 11:25:26 --> Helper loaded: cookie_helper
INFO - 2024-02-18 11:25:26 --> Database Driver Class Initialized
INFO - 2024-02-18 11:25:26 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-18 11:25:26 --> Parser Class Initialized
INFO - 2024-02-18 11:25:26 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-18 11:25:26 --> Pagination Class Initialized
INFO - 2024-02-18 11:25:26 --> Form Validation Class Initialized
INFO - 2024-02-18 11:25:26 --> Controller Class Initialized
INFO - 2024-02-18 11:25:26 --> Model Class Initialized
DEBUG - 2024-02-18 11:25:26 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-18 11:25:26 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-18 11:25:26 --> Model Class Initialized
DEBUG - 2024-02-18 11:25:26 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-18 11:25:26 --> Model Class Initialized
INFO - 2024-02-18 11:25:27 --> Final output sent to browser
DEBUG - 2024-02-18 11:25:27 --> Total execution time: 1.1199
ERROR - 2024-02-18 11:25:34 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-18 11:25:34 --> Config Class Initialized
INFO - 2024-02-18 11:25:34 --> Hooks Class Initialized
DEBUG - 2024-02-18 11:25:34 --> UTF-8 Support Enabled
INFO - 2024-02-18 11:25:34 --> Utf8 Class Initialized
INFO - 2024-02-18 11:25:34 --> URI Class Initialized
INFO - 2024-02-18 11:25:34 --> Router Class Initialized
INFO - 2024-02-18 11:25:34 --> Output Class Initialized
INFO - 2024-02-18 11:25:34 --> Security Class Initialized
DEBUG - 2024-02-18 11:25:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-18 11:25:34 --> Input Class Initialized
INFO - 2024-02-18 11:25:34 --> Language Class Initialized
INFO - 2024-02-18 11:25:34 --> Loader Class Initialized
INFO - 2024-02-18 11:25:34 --> Helper loaded: url_helper
INFO - 2024-02-18 11:25:34 --> Helper loaded: file_helper
INFO - 2024-02-18 11:25:34 --> Helper loaded: html_helper
INFO - 2024-02-18 11:25:34 --> Helper loaded: text_helper
INFO - 2024-02-18 11:25:34 --> Helper loaded: form_helper
INFO - 2024-02-18 11:25:34 --> Helper loaded: lang_helper
INFO - 2024-02-18 11:25:34 --> Helper loaded: security_helper
INFO - 2024-02-18 11:25:34 --> Helper loaded: cookie_helper
INFO - 2024-02-18 11:25:34 --> Database Driver Class Initialized
INFO - 2024-02-18 11:25:34 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-18 11:25:34 --> Parser Class Initialized
INFO - 2024-02-18 11:25:34 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-18 11:25:34 --> Pagination Class Initialized
INFO - 2024-02-18 11:25:34 --> Form Validation Class Initialized
INFO - 2024-02-18 11:25:34 --> Controller Class Initialized
INFO - 2024-02-18 11:25:34 --> Model Class Initialized
DEBUG - 2024-02-18 11:25:34 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-18 11:25:34 --> Final output sent to browser
DEBUG - 2024-02-18 11:25:34 --> Total execution time: 0.0130
ERROR - 2024-02-18 11:25:34 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-18 11:25:34 --> Config Class Initialized
INFO - 2024-02-18 11:25:34 --> Hooks Class Initialized
DEBUG - 2024-02-18 11:25:34 --> UTF-8 Support Enabled
INFO - 2024-02-18 11:25:34 --> Utf8 Class Initialized
INFO - 2024-02-18 11:25:34 --> URI Class Initialized
INFO - 2024-02-18 11:25:34 --> Router Class Initialized
INFO - 2024-02-18 11:25:34 --> Output Class Initialized
INFO - 2024-02-18 11:25:34 --> Security Class Initialized
DEBUG - 2024-02-18 11:25:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-18 11:25:34 --> Input Class Initialized
INFO - 2024-02-18 11:25:34 --> Language Class Initialized
INFO - 2024-02-18 11:25:34 --> Loader Class Initialized
INFO - 2024-02-18 11:25:34 --> Helper loaded: url_helper
INFO - 2024-02-18 11:25:34 --> Helper loaded: file_helper
INFO - 2024-02-18 11:25:34 --> Helper loaded: html_helper
INFO - 2024-02-18 11:25:34 --> Helper loaded: text_helper
INFO - 2024-02-18 11:25:34 --> Helper loaded: form_helper
INFO - 2024-02-18 11:25:34 --> Helper loaded: lang_helper
INFO - 2024-02-18 11:25:34 --> Helper loaded: security_helper
INFO - 2024-02-18 11:25:34 --> Helper loaded: cookie_helper
INFO - 2024-02-18 11:25:34 --> Database Driver Class Initialized
INFO - 2024-02-18 11:25:34 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-18 11:25:34 --> Parser Class Initialized
INFO - 2024-02-18 11:25:34 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-18 11:25:34 --> Pagination Class Initialized
INFO - 2024-02-18 11:25:34 --> Form Validation Class Initialized
INFO - 2024-02-18 11:25:34 --> Controller Class Initialized
INFO - 2024-02-18 11:25:34 --> Model Class Initialized
DEBUG - 2024-02-18 11:25:34 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-18 11:25:34 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2024-02-18 11:25:34 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-02-18 11:25:34 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-02-18 11:25:34 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-02-18 11:25:34 --> Model Class Initialized
INFO - 2024-02-18 11:25:34 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-02-18 11:25:34 --> Final output sent to browser
DEBUG - 2024-02-18 11:25:34 --> Total execution time: 0.0307
ERROR - 2024-02-18 11:25:41 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-18 11:25:41 --> Config Class Initialized
INFO - 2024-02-18 11:25:41 --> Hooks Class Initialized
DEBUG - 2024-02-18 11:25:41 --> UTF-8 Support Enabled
INFO - 2024-02-18 11:25:41 --> Utf8 Class Initialized
INFO - 2024-02-18 11:25:41 --> URI Class Initialized
INFO - 2024-02-18 11:25:41 --> Router Class Initialized
INFO - 2024-02-18 11:25:41 --> Output Class Initialized
INFO - 2024-02-18 11:25:41 --> Security Class Initialized
DEBUG - 2024-02-18 11:25:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-18 11:25:41 --> Input Class Initialized
INFO - 2024-02-18 11:25:41 --> Language Class Initialized
INFO - 2024-02-18 11:25:41 --> Loader Class Initialized
INFO - 2024-02-18 11:25:41 --> Helper loaded: url_helper
INFO - 2024-02-18 11:25:41 --> Helper loaded: file_helper
INFO - 2024-02-18 11:25:41 --> Helper loaded: html_helper
INFO - 2024-02-18 11:25:41 --> Helper loaded: text_helper
INFO - 2024-02-18 11:25:41 --> Helper loaded: form_helper
INFO - 2024-02-18 11:25:41 --> Helper loaded: lang_helper
INFO - 2024-02-18 11:25:41 --> Helper loaded: security_helper
INFO - 2024-02-18 11:25:41 --> Helper loaded: cookie_helper
INFO - 2024-02-18 11:25:41 --> Database Driver Class Initialized
INFO - 2024-02-18 11:25:41 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-18 11:25:41 --> Parser Class Initialized
INFO - 2024-02-18 11:25:41 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-18 11:25:41 --> Pagination Class Initialized
INFO - 2024-02-18 11:25:41 --> Form Validation Class Initialized
INFO - 2024-02-18 11:25:41 --> Controller Class Initialized
INFO - 2024-02-18 11:25:41 --> Model Class Initialized
DEBUG - 2024-02-18 11:25:41 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-18 11:25:41 --> Model Class Initialized
INFO - 2024-02-18 11:25:41 --> Final output sent to browser
DEBUG - 2024-02-18 11:25:41 --> Total execution time: 0.0175
ERROR - 2024-02-18 11:25:41 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-18 11:25:41 --> Config Class Initialized
INFO - 2024-02-18 11:25:41 --> Hooks Class Initialized
DEBUG - 2024-02-18 11:25:41 --> UTF-8 Support Enabled
INFO - 2024-02-18 11:25:41 --> Utf8 Class Initialized
INFO - 2024-02-18 11:25:41 --> URI Class Initialized
DEBUG - 2024-02-18 11:25:41 --> No URI present. Default controller set.
INFO - 2024-02-18 11:25:41 --> Router Class Initialized
INFO - 2024-02-18 11:25:41 --> Output Class Initialized
INFO - 2024-02-18 11:25:41 --> Security Class Initialized
DEBUG - 2024-02-18 11:25:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-18 11:25:41 --> Input Class Initialized
INFO - 2024-02-18 11:25:41 --> Language Class Initialized
INFO - 2024-02-18 11:25:41 --> Loader Class Initialized
INFO - 2024-02-18 11:25:41 --> Helper loaded: url_helper
INFO - 2024-02-18 11:25:41 --> Helper loaded: file_helper
INFO - 2024-02-18 11:25:41 --> Helper loaded: html_helper
INFO - 2024-02-18 11:25:41 --> Helper loaded: text_helper
INFO - 2024-02-18 11:25:41 --> Helper loaded: form_helper
INFO - 2024-02-18 11:25:41 --> Helper loaded: lang_helper
INFO - 2024-02-18 11:25:41 --> Helper loaded: security_helper
INFO - 2024-02-18 11:25:41 --> Helper loaded: cookie_helper
INFO - 2024-02-18 11:25:41 --> Database Driver Class Initialized
INFO - 2024-02-18 11:25:41 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-18 11:25:41 --> Parser Class Initialized
INFO - 2024-02-18 11:25:41 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-18 11:25:41 --> Pagination Class Initialized
INFO - 2024-02-18 11:25:41 --> Form Validation Class Initialized
INFO - 2024-02-18 11:25:41 --> Controller Class Initialized
INFO - 2024-02-18 11:25:41 --> Model Class Initialized
DEBUG - 2024-02-18 11:25:41 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-18 11:25:41 --> Model Class Initialized
DEBUG - 2024-02-18 11:25:41 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-18 11:25:41 --> Model Class Initialized
INFO - 2024-02-18 11:25:41 --> Model Class Initialized
INFO - 2024-02-18 11:25:41 --> Model Class Initialized
INFO - 2024-02-18 11:25:41 --> Model Class Initialized
DEBUG - 2024-02-18 11:25:41 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-18 11:25:41 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-18 11:25:41 --> Model Class Initialized
INFO - 2024-02-18 11:25:41 --> Model Class Initialized
INFO - 2024-02-18 11:25:41 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2024-02-18 11:25:41 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-02-18 11:25:41 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-02-18 11:25:41 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-02-18 11:25:41 --> Model Class Initialized
INFO - 2024-02-18 11:25:41 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-02-18 11:25:41 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-02-18 11:25:41 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-02-18 11:25:41 --> Final output sent to browser
DEBUG - 2024-02-18 11:25:41 --> Total execution time: 0.2573
ERROR - 2024-02-18 11:25:55 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-18 11:25:55 --> Config Class Initialized
INFO - 2024-02-18 11:25:55 --> Hooks Class Initialized
DEBUG - 2024-02-18 11:25:55 --> UTF-8 Support Enabled
INFO - 2024-02-18 11:25:55 --> Utf8 Class Initialized
INFO - 2024-02-18 11:25:55 --> URI Class Initialized
INFO - 2024-02-18 11:25:55 --> Router Class Initialized
INFO - 2024-02-18 11:25:55 --> Output Class Initialized
INFO - 2024-02-18 11:25:55 --> Security Class Initialized
DEBUG - 2024-02-18 11:25:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-18 11:25:55 --> Input Class Initialized
INFO - 2024-02-18 11:25:55 --> Language Class Initialized
INFO - 2024-02-18 11:25:55 --> Loader Class Initialized
INFO - 2024-02-18 11:25:55 --> Helper loaded: url_helper
INFO - 2024-02-18 11:25:55 --> Helper loaded: file_helper
INFO - 2024-02-18 11:25:55 --> Helper loaded: html_helper
INFO - 2024-02-18 11:25:55 --> Helper loaded: text_helper
INFO - 2024-02-18 11:25:55 --> Helper loaded: form_helper
INFO - 2024-02-18 11:25:55 --> Helper loaded: lang_helper
INFO - 2024-02-18 11:25:55 --> Helper loaded: security_helper
INFO - 2024-02-18 11:25:55 --> Helper loaded: cookie_helper
INFO - 2024-02-18 11:25:55 --> Database Driver Class Initialized
INFO - 2024-02-18 11:25:55 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-18 11:25:55 --> Parser Class Initialized
INFO - 2024-02-18 11:25:55 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-18 11:25:55 --> Pagination Class Initialized
INFO - 2024-02-18 11:25:55 --> Form Validation Class Initialized
INFO - 2024-02-18 11:25:55 --> Controller Class Initialized
INFO - 2024-02-18 11:25:55 --> Model Class Initialized
DEBUG - 2024-02-18 11:25:55 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-18 11:25:55 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-18 11:25:55 --> Model Class Initialized
DEBUG - 2024-02-18 11:25:55 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-18 11:25:55 --> Model Class Initialized
INFO - 2024-02-18 11:25:55 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice.php
DEBUG - 2024-02-18 11:25:55 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-02-18 11:25:55 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-02-18 11:25:55 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-02-18 11:25:55 --> Model Class Initialized
INFO - 2024-02-18 11:25:55 --> Model Class Initialized
INFO - 2024-02-18 11:25:55 --> Model Class Initialized
INFO - 2024-02-18 11:25:55 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-02-18 11:25:55 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-02-18 11:25:55 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-02-18 11:25:55 --> Final output sent to browser
DEBUG - 2024-02-18 11:25:55 --> Total execution time: 0.1847
ERROR - 2024-02-18 11:25:56 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-18 11:25:56 --> Config Class Initialized
INFO - 2024-02-18 11:25:56 --> Hooks Class Initialized
DEBUG - 2024-02-18 11:25:56 --> UTF-8 Support Enabled
INFO - 2024-02-18 11:25:56 --> Utf8 Class Initialized
INFO - 2024-02-18 11:25:56 --> URI Class Initialized
INFO - 2024-02-18 11:25:56 --> Router Class Initialized
INFO - 2024-02-18 11:25:56 --> Output Class Initialized
INFO - 2024-02-18 11:25:56 --> Security Class Initialized
DEBUG - 2024-02-18 11:25:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-18 11:25:56 --> Input Class Initialized
INFO - 2024-02-18 11:25:56 --> Language Class Initialized
INFO - 2024-02-18 11:25:56 --> Loader Class Initialized
INFO - 2024-02-18 11:25:56 --> Helper loaded: url_helper
INFO - 2024-02-18 11:25:56 --> Helper loaded: file_helper
INFO - 2024-02-18 11:25:56 --> Helper loaded: html_helper
INFO - 2024-02-18 11:25:56 --> Helper loaded: text_helper
INFO - 2024-02-18 11:25:56 --> Helper loaded: form_helper
INFO - 2024-02-18 11:25:56 --> Helper loaded: lang_helper
INFO - 2024-02-18 11:25:56 --> Helper loaded: security_helper
INFO - 2024-02-18 11:25:56 --> Helper loaded: cookie_helper
INFO - 2024-02-18 11:25:56 --> Database Driver Class Initialized
INFO - 2024-02-18 11:25:56 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-18 11:25:56 --> Parser Class Initialized
INFO - 2024-02-18 11:25:56 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-18 11:25:56 --> Pagination Class Initialized
INFO - 2024-02-18 11:25:56 --> Form Validation Class Initialized
INFO - 2024-02-18 11:25:56 --> Controller Class Initialized
INFO - 2024-02-18 11:25:56 --> Model Class Initialized
DEBUG - 2024-02-18 11:25:56 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-18 11:25:56 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-18 11:25:56 --> Model Class Initialized
DEBUG - 2024-02-18 11:25:56 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-18 11:25:56 --> Model Class Initialized
INFO - 2024-02-18 11:25:56 --> Final output sent to browser
DEBUG - 2024-02-18 11:25:56 --> Total execution time: 0.0416
ERROR - 2024-02-18 11:25:59 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-18 11:25:59 --> Config Class Initialized
INFO - 2024-02-18 11:25:59 --> Hooks Class Initialized
DEBUG - 2024-02-18 11:25:59 --> UTF-8 Support Enabled
INFO - 2024-02-18 11:25:59 --> Utf8 Class Initialized
INFO - 2024-02-18 11:25:59 --> URI Class Initialized
INFO - 2024-02-18 11:25:59 --> Router Class Initialized
INFO - 2024-02-18 11:25:59 --> Output Class Initialized
INFO - 2024-02-18 11:25:59 --> Security Class Initialized
DEBUG - 2024-02-18 11:25:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-18 11:25:59 --> Input Class Initialized
INFO - 2024-02-18 11:25:59 --> Language Class Initialized
INFO - 2024-02-18 11:25:59 --> Loader Class Initialized
INFO - 2024-02-18 11:25:59 --> Helper loaded: url_helper
INFO - 2024-02-18 11:25:59 --> Helper loaded: file_helper
INFO - 2024-02-18 11:25:59 --> Helper loaded: html_helper
INFO - 2024-02-18 11:25:59 --> Helper loaded: text_helper
INFO - 2024-02-18 11:25:59 --> Helper loaded: form_helper
INFO - 2024-02-18 11:25:59 --> Helper loaded: lang_helper
INFO - 2024-02-18 11:25:59 --> Helper loaded: security_helper
INFO - 2024-02-18 11:25:59 --> Helper loaded: cookie_helper
INFO - 2024-02-18 11:25:59 --> Database Driver Class Initialized
INFO - 2024-02-18 11:25:59 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-18 11:25:59 --> Parser Class Initialized
INFO - 2024-02-18 11:25:59 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-18 11:25:59 --> Pagination Class Initialized
INFO - 2024-02-18 11:25:59 --> Form Validation Class Initialized
INFO - 2024-02-18 11:25:59 --> Controller Class Initialized
INFO - 2024-02-18 11:25:59 --> Model Class Initialized
DEBUG - 2024-02-18 11:25:59 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-18 11:25:59 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-18 11:25:59 --> Model Class Initialized
DEBUG - 2024-02-18 11:25:59 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-18 11:25:59 --> Model Class Initialized
INFO - 2024-02-18 11:25:59 --> Final output sent to browser
DEBUG - 2024-02-18 11:25:59 --> Total execution time: 0.1659
ERROR - 2024-02-18 11:26:41 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-18 11:26:41 --> Config Class Initialized
INFO - 2024-02-18 11:26:41 --> Hooks Class Initialized
DEBUG - 2024-02-18 11:26:41 --> UTF-8 Support Enabled
INFO - 2024-02-18 11:26:41 --> Utf8 Class Initialized
INFO - 2024-02-18 11:26:41 --> URI Class Initialized
DEBUG - 2024-02-18 11:26:41 --> No URI present. Default controller set.
INFO - 2024-02-18 11:26:41 --> Router Class Initialized
INFO - 2024-02-18 11:26:41 --> Output Class Initialized
INFO - 2024-02-18 11:26:41 --> Security Class Initialized
DEBUG - 2024-02-18 11:26:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-18 11:26:41 --> Input Class Initialized
INFO - 2024-02-18 11:26:41 --> Language Class Initialized
INFO - 2024-02-18 11:26:41 --> Loader Class Initialized
INFO - 2024-02-18 11:26:41 --> Helper loaded: url_helper
INFO - 2024-02-18 11:26:41 --> Helper loaded: file_helper
INFO - 2024-02-18 11:26:41 --> Helper loaded: html_helper
INFO - 2024-02-18 11:26:41 --> Helper loaded: text_helper
INFO - 2024-02-18 11:26:41 --> Helper loaded: form_helper
INFO - 2024-02-18 11:26:41 --> Helper loaded: lang_helper
INFO - 2024-02-18 11:26:41 --> Helper loaded: security_helper
INFO - 2024-02-18 11:26:41 --> Helper loaded: cookie_helper
INFO - 2024-02-18 11:26:41 --> Database Driver Class Initialized
INFO - 2024-02-18 11:26:41 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-18 11:26:41 --> Parser Class Initialized
INFO - 2024-02-18 11:26:41 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-18 11:26:41 --> Pagination Class Initialized
INFO - 2024-02-18 11:26:41 --> Form Validation Class Initialized
INFO - 2024-02-18 11:26:41 --> Controller Class Initialized
INFO - 2024-02-18 11:26:41 --> Model Class Initialized
DEBUG - 2024-02-18 11:26:41 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-18 11:26:41 --> Model Class Initialized
DEBUG - 2024-02-18 11:26:41 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-18 11:26:41 --> Model Class Initialized
INFO - 2024-02-18 11:26:41 --> Model Class Initialized
INFO - 2024-02-18 11:26:41 --> Model Class Initialized
INFO - 2024-02-18 11:26:41 --> Model Class Initialized
DEBUG - 2024-02-18 11:26:41 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-18 11:26:41 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-18 11:26:41 --> Model Class Initialized
INFO - 2024-02-18 11:26:41 --> Model Class Initialized
INFO - 2024-02-18 11:26:41 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2024-02-18 11:26:41 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-02-18 11:26:41 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-02-18 11:26:41 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-02-18 11:26:41 --> Model Class Initialized
INFO - 2024-02-18 11:26:41 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-02-18 11:26:41 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-02-18 11:26:41 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-02-18 11:26:41 --> Final output sent to browser
DEBUG - 2024-02-18 11:26:41 --> Total execution time: 0.2388
ERROR - 2024-02-18 11:26:56 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-18 11:26:56 --> Config Class Initialized
INFO - 2024-02-18 11:26:56 --> Hooks Class Initialized
DEBUG - 2024-02-18 11:26:56 --> UTF-8 Support Enabled
INFO - 2024-02-18 11:26:56 --> Utf8 Class Initialized
INFO - 2024-02-18 11:26:56 --> URI Class Initialized
INFO - 2024-02-18 11:26:56 --> Router Class Initialized
INFO - 2024-02-18 11:26:56 --> Output Class Initialized
INFO - 2024-02-18 11:26:56 --> Security Class Initialized
DEBUG - 2024-02-18 11:26:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-18 11:26:56 --> Input Class Initialized
INFO - 2024-02-18 11:26:56 --> Language Class Initialized
INFO - 2024-02-18 11:26:56 --> Loader Class Initialized
INFO - 2024-02-18 11:26:56 --> Helper loaded: url_helper
INFO - 2024-02-18 11:26:56 --> Helper loaded: file_helper
INFO - 2024-02-18 11:26:56 --> Helper loaded: html_helper
INFO - 2024-02-18 11:26:56 --> Helper loaded: text_helper
INFO - 2024-02-18 11:26:56 --> Helper loaded: form_helper
INFO - 2024-02-18 11:26:56 --> Helper loaded: lang_helper
INFO - 2024-02-18 11:26:56 --> Helper loaded: security_helper
INFO - 2024-02-18 11:26:56 --> Helper loaded: cookie_helper
INFO - 2024-02-18 11:26:56 --> Database Driver Class Initialized
INFO - 2024-02-18 11:26:56 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-18 11:26:56 --> Parser Class Initialized
INFO - 2024-02-18 11:26:56 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-18 11:26:56 --> Pagination Class Initialized
INFO - 2024-02-18 11:26:56 --> Form Validation Class Initialized
INFO - 2024-02-18 11:26:56 --> Controller Class Initialized
INFO - 2024-02-18 11:26:56 --> Model Class Initialized
DEBUG - 2024-02-18 11:26:56 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-18 11:26:56 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-18 11:26:56 --> Model Class Initialized
DEBUG - 2024-02-18 11:26:56 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-18 11:26:56 --> Model Class Initialized
INFO - 2024-02-18 11:26:56 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice.php
DEBUG - 2024-02-18 11:26:56 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-02-18 11:26:56 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-02-18 11:26:56 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-02-18 11:26:56 --> Model Class Initialized
INFO - 2024-02-18 11:26:56 --> Model Class Initialized
INFO - 2024-02-18 11:26:56 --> Model Class Initialized
INFO - 2024-02-18 11:26:56 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-02-18 11:26:56 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-02-18 11:26:56 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-02-18 11:26:56 --> Final output sent to browser
DEBUG - 2024-02-18 11:26:56 --> Total execution time: 0.1467
ERROR - 2024-02-18 11:26:57 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-18 11:26:57 --> Config Class Initialized
INFO - 2024-02-18 11:26:57 --> Hooks Class Initialized
DEBUG - 2024-02-18 11:26:57 --> UTF-8 Support Enabled
INFO - 2024-02-18 11:26:57 --> Utf8 Class Initialized
INFO - 2024-02-18 11:26:57 --> URI Class Initialized
INFO - 2024-02-18 11:26:57 --> Router Class Initialized
INFO - 2024-02-18 11:26:57 --> Output Class Initialized
INFO - 2024-02-18 11:26:57 --> Security Class Initialized
DEBUG - 2024-02-18 11:26:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-18 11:26:57 --> Input Class Initialized
INFO - 2024-02-18 11:26:57 --> Language Class Initialized
INFO - 2024-02-18 11:26:57 --> Loader Class Initialized
INFO - 2024-02-18 11:26:57 --> Helper loaded: url_helper
INFO - 2024-02-18 11:26:57 --> Helper loaded: file_helper
INFO - 2024-02-18 11:26:57 --> Helper loaded: html_helper
INFO - 2024-02-18 11:26:57 --> Helper loaded: text_helper
INFO - 2024-02-18 11:26:57 --> Helper loaded: form_helper
INFO - 2024-02-18 11:26:57 --> Helper loaded: lang_helper
INFO - 2024-02-18 11:26:57 --> Helper loaded: security_helper
INFO - 2024-02-18 11:26:57 --> Helper loaded: cookie_helper
INFO - 2024-02-18 11:26:57 --> Database Driver Class Initialized
INFO - 2024-02-18 11:26:57 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-18 11:26:57 --> Parser Class Initialized
INFO - 2024-02-18 11:26:57 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-18 11:26:57 --> Pagination Class Initialized
INFO - 2024-02-18 11:26:57 --> Form Validation Class Initialized
INFO - 2024-02-18 11:26:57 --> Controller Class Initialized
INFO - 2024-02-18 11:26:57 --> Model Class Initialized
DEBUG - 2024-02-18 11:26:57 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-18 11:26:57 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-18 11:26:57 --> Model Class Initialized
DEBUG - 2024-02-18 11:26:57 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-18 11:26:57 --> Model Class Initialized
INFO - 2024-02-18 11:26:57 --> Final output sent to browser
DEBUG - 2024-02-18 11:26:57 --> Total execution time: 0.0392
ERROR - 2024-02-18 11:27:00 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-18 11:27:00 --> Config Class Initialized
INFO - 2024-02-18 11:27:00 --> Hooks Class Initialized
DEBUG - 2024-02-18 11:27:00 --> UTF-8 Support Enabled
INFO - 2024-02-18 11:27:00 --> Utf8 Class Initialized
INFO - 2024-02-18 11:27:00 --> URI Class Initialized
INFO - 2024-02-18 11:27:00 --> Router Class Initialized
INFO - 2024-02-18 11:27:00 --> Output Class Initialized
INFO - 2024-02-18 11:27:00 --> Security Class Initialized
DEBUG - 2024-02-18 11:27:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-18 11:27:00 --> Input Class Initialized
INFO - 2024-02-18 11:27:00 --> Language Class Initialized
INFO - 2024-02-18 11:27:00 --> Loader Class Initialized
INFO - 2024-02-18 11:27:00 --> Helper loaded: url_helper
INFO - 2024-02-18 11:27:00 --> Helper loaded: file_helper
INFO - 2024-02-18 11:27:00 --> Helper loaded: html_helper
INFO - 2024-02-18 11:27:00 --> Helper loaded: text_helper
INFO - 2024-02-18 11:27:00 --> Helper loaded: form_helper
INFO - 2024-02-18 11:27:00 --> Helper loaded: lang_helper
INFO - 2024-02-18 11:27:00 --> Helper loaded: security_helper
INFO - 2024-02-18 11:27:00 --> Helper loaded: cookie_helper
INFO - 2024-02-18 11:27:00 --> Database Driver Class Initialized
INFO - 2024-02-18 11:27:00 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-18 11:27:00 --> Parser Class Initialized
INFO - 2024-02-18 11:27:00 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-18 11:27:00 --> Pagination Class Initialized
INFO - 2024-02-18 11:27:00 --> Form Validation Class Initialized
INFO - 2024-02-18 11:27:00 --> Controller Class Initialized
INFO - 2024-02-18 11:27:00 --> Model Class Initialized
DEBUG - 2024-02-18 11:27:00 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-18 11:27:00 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-18 11:27:00 --> Model Class Initialized
DEBUG - 2024-02-18 11:27:00 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-18 11:27:00 --> Model Class Initialized
INFO - 2024-02-18 11:27:00 --> Final output sent to browser
DEBUG - 2024-02-18 11:27:00 --> Total execution time: 0.1491
ERROR - 2024-02-18 11:27:38 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-18 11:27:38 --> Config Class Initialized
INFO - 2024-02-18 11:27:38 --> Hooks Class Initialized
DEBUG - 2024-02-18 11:27:38 --> UTF-8 Support Enabled
INFO - 2024-02-18 11:27:38 --> Utf8 Class Initialized
INFO - 2024-02-18 11:27:38 --> URI Class Initialized
INFO - 2024-02-18 11:27:38 --> Router Class Initialized
INFO - 2024-02-18 11:27:38 --> Output Class Initialized
INFO - 2024-02-18 11:27:38 --> Security Class Initialized
DEBUG - 2024-02-18 11:27:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-18 11:27:38 --> Input Class Initialized
INFO - 2024-02-18 11:27:38 --> Language Class Initialized
INFO - 2024-02-18 11:27:39 --> Loader Class Initialized
INFO - 2024-02-18 11:27:39 --> Helper loaded: url_helper
INFO - 2024-02-18 11:27:39 --> Helper loaded: file_helper
INFO - 2024-02-18 11:27:39 --> Helper loaded: html_helper
INFO - 2024-02-18 11:27:39 --> Helper loaded: text_helper
INFO - 2024-02-18 11:27:39 --> Helper loaded: form_helper
INFO - 2024-02-18 11:27:39 --> Helper loaded: lang_helper
INFO - 2024-02-18 11:27:39 --> Helper loaded: security_helper
INFO - 2024-02-18 11:27:39 --> Helper loaded: cookie_helper
INFO - 2024-02-18 11:27:39 --> Database Driver Class Initialized
INFO - 2024-02-18 11:27:39 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-18 11:27:39 --> Parser Class Initialized
INFO - 2024-02-18 11:27:39 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-18 11:27:39 --> Pagination Class Initialized
INFO - 2024-02-18 11:27:39 --> Form Validation Class Initialized
INFO - 2024-02-18 11:27:39 --> Controller Class Initialized
INFO - 2024-02-18 11:27:39 --> Model Class Initialized
DEBUG - 2024-02-18 11:27:39 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-18 11:27:39 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-18 11:27:39 --> Model Class Initialized
DEBUG - 2024-02-18 11:27:39 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-18 11:27:39 --> Model Class Initialized
INFO - 2024-02-18 11:27:39 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice.php
DEBUG - 2024-02-18 11:27:39 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-02-18 11:27:39 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-02-18 11:27:39 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-02-18 11:27:39 --> Model Class Initialized
INFO - 2024-02-18 11:27:39 --> Model Class Initialized
INFO - 2024-02-18 11:27:39 --> Model Class Initialized
INFO - 2024-02-18 11:27:39 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-02-18 11:27:39 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-02-18 11:27:39 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-02-18 11:27:39 --> Final output sent to browser
DEBUG - 2024-02-18 11:27:39 --> Total execution time: 0.1586
ERROR - 2024-02-18 11:27:39 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-18 11:27:39 --> Config Class Initialized
INFO - 2024-02-18 11:27:39 --> Hooks Class Initialized
DEBUG - 2024-02-18 11:27:39 --> UTF-8 Support Enabled
INFO - 2024-02-18 11:27:39 --> Utf8 Class Initialized
INFO - 2024-02-18 11:27:39 --> URI Class Initialized
INFO - 2024-02-18 11:27:39 --> Router Class Initialized
INFO - 2024-02-18 11:27:39 --> Output Class Initialized
INFO - 2024-02-18 11:27:39 --> Security Class Initialized
DEBUG - 2024-02-18 11:27:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-18 11:27:39 --> Input Class Initialized
INFO - 2024-02-18 11:27:39 --> Language Class Initialized
INFO - 2024-02-18 11:27:39 --> Loader Class Initialized
INFO - 2024-02-18 11:27:39 --> Helper loaded: url_helper
INFO - 2024-02-18 11:27:39 --> Helper loaded: file_helper
INFO - 2024-02-18 11:27:39 --> Helper loaded: html_helper
INFO - 2024-02-18 11:27:39 --> Helper loaded: text_helper
INFO - 2024-02-18 11:27:39 --> Helper loaded: form_helper
INFO - 2024-02-18 11:27:39 --> Helper loaded: lang_helper
INFO - 2024-02-18 11:27:39 --> Helper loaded: security_helper
INFO - 2024-02-18 11:27:39 --> Helper loaded: cookie_helper
INFO - 2024-02-18 11:27:39 --> Database Driver Class Initialized
INFO - 2024-02-18 11:27:39 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-18 11:27:39 --> Parser Class Initialized
INFO - 2024-02-18 11:27:39 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-18 11:27:39 --> Pagination Class Initialized
INFO - 2024-02-18 11:27:39 --> Form Validation Class Initialized
INFO - 2024-02-18 11:27:39 --> Controller Class Initialized
INFO - 2024-02-18 11:27:39 --> Model Class Initialized
DEBUG - 2024-02-18 11:27:39 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-18 11:27:39 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-18 11:27:39 --> Model Class Initialized
DEBUG - 2024-02-18 11:27:39 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-18 11:27:39 --> Model Class Initialized
INFO - 2024-02-18 11:27:39 --> Final output sent to browser
DEBUG - 2024-02-18 11:27:39 --> Total execution time: 0.0444
ERROR - 2024-02-18 11:27:43 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-18 11:27:43 --> Config Class Initialized
INFO - 2024-02-18 11:27:43 --> Hooks Class Initialized
DEBUG - 2024-02-18 11:27:43 --> UTF-8 Support Enabled
INFO - 2024-02-18 11:27:43 --> Utf8 Class Initialized
INFO - 2024-02-18 11:27:43 --> URI Class Initialized
INFO - 2024-02-18 11:27:43 --> Router Class Initialized
INFO - 2024-02-18 11:27:43 --> Output Class Initialized
INFO - 2024-02-18 11:27:43 --> Security Class Initialized
DEBUG - 2024-02-18 11:27:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-18 11:27:43 --> Input Class Initialized
INFO - 2024-02-18 11:27:43 --> Language Class Initialized
INFO - 2024-02-18 11:27:43 --> Loader Class Initialized
INFO - 2024-02-18 11:27:43 --> Helper loaded: url_helper
INFO - 2024-02-18 11:27:43 --> Helper loaded: file_helper
INFO - 2024-02-18 11:27:43 --> Helper loaded: html_helper
INFO - 2024-02-18 11:27:43 --> Helper loaded: text_helper
INFO - 2024-02-18 11:27:43 --> Helper loaded: form_helper
INFO - 2024-02-18 11:27:43 --> Helper loaded: lang_helper
INFO - 2024-02-18 11:27:43 --> Helper loaded: security_helper
INFO - 2024-02-18 11:27:43 --> Helper loaded: cookie_helper
INFO - 2024-02-18 11:27:43 --> Database Driver Class Initialized
INFO - 2024-02-18 11:27:43 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-18 11:27:43 --> Parser Class Initialized
INFO - 2024-02-18 11:27:43 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-18 11:27:43 --> Pagination Class Initialized
INFO - 2024-02-18 11:27:43 --> Form Validation Class Initialized
INFO - 2024-02-18 11:27:43 --> Controller Class Initialized
INFO - 2024-02-18 11:27:43 --> Model Class Initialized
DEBUG - 2024-02-18 11:27:43 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-18 11:27:43 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-18 11:27:43 --> Model Class Initialized
DEBUG - 2024-02-18 11:27:43 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-18 11:27:43 --> Model Class Initialized
INFO - 2024-02-18 11:27:43 --> Final output sent to browser
DEBUG - 2024-02-18 11:27:43 --> Total execution time: 0.1763
ERROR - 2024-02-18 11:27:59 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-18 11:27:59 --> Config Class Initialized
INFO - 2024-02-18 11:27:59 --> Hooks Class Initialized
DEBUG - 2024-02-18 11:27:59 --> UTF-8 Support Enabled
INFO - 2024-02-18 11:27:59 --> Utf8 Class Initialized
INFO - 2024-02-18 11:27:59 --> URI Class Initialized
DEBUG - 2024-02-18 11:27:59 --> No URI present. Default controller set.
INFO - 2024-02-18 11:27:59 --> Router Class Initialized
INFO - 2024-02-18 11:27:59 --> Output Class Initialized
INFO - 2024-02-18 11:27:59 --> Security Class Initialized
DEBUG - 2024-02-18 11:27:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-18 11:27:59 --> Input Class Initialized
INFO - 2024-02-18 11:27:59 --> Language Class Initialized
INFO - 2024-02-18 11:27:59 --> Loader Class Initialized
INFO - 2024-02-18 11:27:59 --> Helper loaded: url_helper
INFO - 2024-02-18 11:27:59 --> Helper loaded: file_helper
INFO - 2024-02-18 11:27:59 --> Helper loaded: html_helper
INFO - 2024-02-18 11:27:59 --> Helper loaded: text_helper
INFO - 2024-02-18 11:27:59 --> Helper loaded: form_helper
INFO - 2024-02-18 11:27:59 --> Helper loaded: lang_helper
INFO - 2024-02-18 11:27:59 --> Helper loaded: security_helper
INFO - 2024-02-18 11:27:59 --> Helper loaded: cookie_helper
INFO - 2024-02-18 11:27:59 --> Database Driver Class Initialized
INFO - 2024-02-18 11:27:59 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-18 11:27:59 --> Parser Class Initialized
INFO - 2024-02-18 11:27:59 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-18 11:27:59 --> Pagination Class Initialized
INFO - 2024-02-18 11:27:59 --> Form Validation Class Initialized
INFO - 2024-02-18 11:27:59 --> Controller Class Initialized
INFO - 2024-02-18 11:27:59 --> Model Class Initialized
DEBUG - 2024-02-18 11:27:59 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-18 11:27:59 --> Model Class Initialized
DEBUG - 2024-02-18 11:27:59 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-18 11:27:59 --> Model Class Initialized
INFO - 2024-02-18 11:27:59 --> Model Class Initialized
INFO - 2024-02-18 11:27:59 --> Model Class Initialized
INFO - 2024-02-18 11:27:59 --> Model Class Initialized
DEBUG - 2024-02-18 11:27:59 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-18 11:27:59 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-18 11:27:59 --> Model Class Initialized
INFO - 2024-02-18 11:27:59 --> Model Class Initialized
INFO - 2024-02-18 11:27:59 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2024-02-18 11:27:59 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-02-18 11:27:59 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-02-18 11:27:59 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-02-18 11:27:59 --> Model Class Initialized
INFO - 2024-02-18 11:27:59 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-02-18 11:27:59 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-02-18 11:27:59 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-02-18 11:27:59 --> Final output sent to browser
DEBUG - 2024-02-18 11:27:59 --> Total execution time: 0.2307
ERROR - 2024-02-18 11:29:07 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-18 11:29:07 --> Config Class Initialized
INFO - 2024-02-18 11:29:07 --> Hooks Class Initialized
DEBUG - 2024-02-18 11:29:07 --> UTF-8 Support Enabled
INFO - 2024-02-18 11:29:07 --> Utf8 Class Initialized
INFO - 2024-02-18 11:29:07 --> URI Class Initialized
INFO - 2024-02-18 11:29:07 --> Router Class Initialized
INFO - 2024-02-18 11:29:07 --> Output Class Initialized
INFO - 2024-02-18 11:29:07 --> Security Class Initialized
DEBUG - 2024-02-18 11:29:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-18 11:29:07 --> Input Class Initialized
INFO - 2024-02-18 11:29:07 --> Language Class Initialized
INFO - 2024-02-18 11:29:07 --> Loader Class Initialized
INFO - 2024-02-18 11:29:07 --> Helper loaded: url_helper
INFO - 2024-02-18 11:29:07 --> Helper loaded: file_helper
INFO - 2024-02-18 11:29:07 --> Helper loaded: html_helper
INFO - 2024-02-18 11:29:07 --> Helper loaded: text_helper
INFO - 2024-02-18 11:29:07 --> Helper loaded: form_helper
INFO - 2024-02-18 11:29:07 --> Helper loaded: lang_helper
INFO - 2024-02-18 11:29:07 --> Helper loaded: security_helper
INFO - 2024-02-18 11:29:07 --> Helper loaded: cookie_helper
INFO - 2024-02-18 11:29:07 --> Database Driver Class Initialized
INFO - 2024-02-18 11:29:07 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-18 11:29:07 --> Parser Class Initialized
INFO - 2024-02-18 11:29:07 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-18 11:29:07 --> Pagination Class Initialized
INFO - 2024-02-18 11:29:07 --> Form Validation Class Initialized
INFO - 2024-02-18 11:29:07 --> Controller Class Initialized
INFO - 2024-02-18 11:29:07 --> Model Class Initialized
DEBUG - 2024-02-18 11:29:07 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-18 11:29:07 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-18 11:29:07 --> Model Class Initialized
DEBUG - 2024-02-18 11:29:07 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-18 11:29:07 --> Model Class Initialized
INFO - 2024-02-18 11:29:07 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice.php
DEBUG - 2024-02-18 11:29:07 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-02-18 11:29:07 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-02-18 11:29:07 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-02-18 11:29:07 --> Model Class Initialized
INFO - 2024-02-18 11:29:07 --> Model Class Initialized
INFO - 2024-02-18 11:29:07 --> Model Class Initialized
INFO - 2024-02-18 11:29:07 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-02-18 11:29:07 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-02-18 11:29:07 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-02-18 11:29:07 --> Final output sent to browser
DEBUG - 2024-02-18 11:29:07 --> Total execution time: 0.1477
ERROR - 2024-02-18 11:29:08 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-18 11:29:08 --> Config Class Initialized
INFO - 2024-02-18 11:29:08 --> Hooks Class Initialized
DEBUG - 2024-02-18 11:29:08 --> UTF-8 Support Enabled
INFO - 2024-02-18 11:29:08 --> Utf8 Class Initialized
INFO - 2024-02-18 11:29:08 --> URI Class Initialized
INFO - 2024-02-18 11:29:08 --> Router Class Initialized
INFO - 2024-02-18 11:29:08 --> Output Class Initialized
INFO - 2024-02-18 11:29:08 --> Security Class Initialized
DEBUG - 2024-02-18 11:29:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-18 11:29:08 --> Input Class Initialized
INFO - 2024-02-18 11:29:08 --> Language Class Initialized
INFO - 2024-02-18 11:29:08 --> Loader Class Initialized
INFO - 2024-02-18 11:29:08 --> Helper loaded: url_helper
INFO - 2024-02-18 11:29:08 --> Helper loaded: file_helper
INFO - 2024-02-18 11:29:08 --> Helper loaded: html_helper
INFO - 2024-02-18 11:29:08 --> Helper loaded: text_helper
INFO - 2024-02-18 11:29:08 --> Helper loaded: form_helper
INFO - 2024-02-18 11:29:08 --> Helper loaded: lang_helper
INFO - 2024-02-18 11:29:08 --> Helper loaded: security_helper
INFO - 2024-02-18 11:29:08 --> Helper loaded: cookie_helper
INFO - 2024-02-18 11:29:08 --> Database Driver Class Initialized
INFO - 2024-02-18 11:29:08 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-18 11:29:08 --> Parser Class Initialized
INFO - 2024-02-18 11:29:08 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-18 11:29:08 --> Pagination Class Initialized
INFO - 2024-02-18 11:29:08 --> Form Validation Class Initialized
INFO - 2024-02-18 11:29:08 --> Controller Class Initialized
INFO - 2024-02-18 11:29:08 --> Model Class Initialized
DEBUG - 2024-02-18 11:29:08 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-18 11:29:08 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-18 11:29:08 --> Model Class Initialized
DEBUG - 2024-02-18 11:29:08 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-18 11:29:08 --> Model Class Initialized
INFO - 2024-02-18 11:29:08 --> Final output sent to browser
DEBUG - 2024-02-18 11:29:08 --> Total execution time: 0.0471
ERROR - 2024-02-18 11:29:13 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-18 11:29:13 --> Config Class Initialized
INFO - 2024-02-18 11:29:13 --> Hooks Class Initialized
DEBUG - 2024-02-18 11:29:13 --> UTF-8 Support Enabled
INFO - 2024-02-18 11:29:13 --> Utf8 Class Initialized
INFO - 2024-02-18 11:29:13 --> URI Class Initialized
INFO - 2024-02-18 11:29:13 --> Router Class Initialized
INFO - 2024-02-18 11:29:13 --> Output Class Initialized
INFO - 2024-02-18 11:29:13 --> Security Class Initialized
DEBUG - 2024-02-18 11:29:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-18 11:29:13 --> Input Class Initialized
INFO - 2024-02-18 11:29:13 --> Language Class Initialized
INFO - 2024-02-18 11:29:13 --> Loader Class Initialized
INFO - 2024-02-18 11:29:13 --> Helper loaded: url_helper
INFO - 2024-02-18 11:29:13 --> Helper loaded: file_helper
INFO - 2024-02-18 11:29:13 --> Helper loaded: html_helper
INFO - 2024-02-18 11:29:13 --> Helper loaded: text_helper
INFO - 2024-02-18 11:29:13 --> Helper loaded: form_helper
INFO - 2024-02-18 11:29:13 --> Helper loaded: lang_helper
INFO - 2024-02-18 11:29:13 --> Helper loaded: security_helper
INFO - 2024-02-18 11:29:13 --> Helper loaded: cookie_helper
INFO - 2024-02-18 11:29:13 --> Database Driver Class Initialized
INFO - 2024-02-18 11:29:13 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-18 11:29:13 --> Parser Class Initialized
INFO - 2024-02-18 11:29:13 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-18 11:29:13 --> Pagination Class Initialized
INFO - 2024-02-18 11:29:13 --> Form Validation Class Initialized
INFO - 2024-02-18 11:29:13 --> Controller Class Initialized
INFO - 2024-02-18 11:29:13 --> Model Class Initialized
DEBUG - 2024-02-18 11:29:13 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-18 11:29:13 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-18 11:29:13 --> Model Class Initialized
DEBUG - 2024-02-18 11:29:13 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-18 11:29:13 --> Model Class Initialized
INFO - 2024-02-18 11:29:13 --> Final output sent to browser
DEBUG - 2024-02-18 11:29:13 --> Total execution time: 0.1574
ERROR - 2024-02-18 11:29:34 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-18 11:29:34 --> Config Class Initialized
INFO - 2024-02-18 11:29:34 --> Hooks Class Initialized
DEBUG - 2024-02-18 11:29:34 --> UTF-8 Support Enabled
INFO - 2024-02-18 11:29:34 --> Utf8 Class Initialized
INFO - 2024-02-18 11:29:34 --> URI Class Initialized
DEBUG - 2024-02-18 11:29:34 --> No URI present. Default controller set.
INFO - 2024-02-18 11:29:34 --> Router Class Initialized
INFO - 2024-02-18 11:29:34 --> Output Class Initialized
INFO - 2024-02-18 11:29:34 --> Security Class Initialized
DEBUG - 2024-02-18 11:29:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-18 11:29:34 --> Input Class Initialized
INFO - 2024-02-18 11:29:34 --> Language Class Initialized
INFO - 2024-02-18 11:29:34 --> Loader Class Initialized
INFO - 2024-02-18 11:29:34 --> Helper loaded: url_helper
INFO - 2024-02-18 11:29:34 --> Helper loaded: file_helper
INFO - 2024-02-18 11:29:34 --> Helper loaded: html_helper
INFO - 2024-02-18 11:29:34 --> Helper loaded: text_helper
INFO - 2024-02-18 11:29:34 --> Helper loaded: form_helper
INFO - 2024-02-18 11:29:34 --> Helper loaded: lang_helper
INFO - 2024-02-18 11:29:34 --> Helper loaded: security_helper
INFO - 2024-02-18 11:29:34 --> Helper loaded: cookie_helper
INFO - 2024-02-18 11:29:34 --> Database Driver Class Initialized
INFO - 2024-02-18 11:29:34 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-18 11:29:34 --> Parser Class Initialized
INFO - 2024-02-18 11:29:34 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-18 11:29:34 --> Pagination Class Initialized
INFO - 2024-02-18 11:29:34 --> Form Validation Class Initialized
INFO - 2024-02-18 11:29:34 --> Controller Class Initialized
INFO - 2024-02-18 11:29:34 --> Model Class Initialized
DEBUG - 2024-02-18 11:29:34 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-18 11:29:34 --> Model Class Initialized
DEBUG - 2024-02-18 11:29:34 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-18 11:29:34 --> Model Class Initialized
INFO - 2024-02-18 11:29:34 --> Model Class Initialized
INFO - 2024-02-18 11:29:34 --> Model Class Initialized
INFO - 2024-02-18 11:29:34 --> Model Class Initialized
DEBUG - 2024-02-18 11:29:34 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-18 11:29:34 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-18 11:29:34 --> Model Class Initialized
INFO - 2024-02-18 11:29:34 --> Model Class Initialized
INFO - 2024-02-18 11:29:34 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2024-02-18 11:29:34 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-02-18 11:29:34 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-02-18 11:29:34 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-02-18 11:29:34 --> Model Class Initialized
INFO - 2024-02-18 11:29:34 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-02-18 11:29:34 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-02-18 11:29:34 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-02-18 11:29:34 --> Final output sent to browser
DEBUG - 2024-02-18 11:29:34 --> Total execution time: 0.2290
ERROR - 2024-02-18 11:30:34 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-18 11:30:34 --> Config Class Initialized
INFO - 2024-02-18 11:30:34 --> Hooks Class Initialized
DEBUG - 2024-02-18 11:30:34 --> UTF-8 Support Enabled
INFO - 2024-02-18 11:30:34 --> Utf8 Class Initialized
INFO - 2024-02-18 11:30:34 --> URI Class Initialized
INFO - 2024-02-18 11:30:34 --> Router Class Initialized
INFO - 2024-02-18 11:30:34 --> Output Class Initialized
INFO - 2024-02-18 11:30:34 --> Security Class Initialized
DEBUG - 2024-02-18 11:30:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-18 11:30:34 --> Input Class Initialized
INFO - 2024-02-18 11:30:34 --> Language Class Initialized
INFO - 2024-02-18 11:30:34 --> Loader Class Initialized
INFO - 2024-02-18 11:30:34 --> Helper loaded: url_helper
INFO - 2024-02-18 11:30:34 --> Helper loaded: file_helper
INFO - 2024-02-18 11:30:34 --> Helper loaded: html_helper
INFO - 2024-02-18 11:30:34 --> Helper loaded: text_helper
INFO - 2024-02-18 11:30:34 --> Helper loaded: form_helper
INFO - 2024-02-18 11:30:34 --> Helper loaded: lang_helper
INFO - 2024-02-18 11:30:34 --> Helper loaded: security_helper
INFO - 2024-02-18 11:30:34 --> Helper loaded: cookie_helper
INFO - 2024-02-18 11:30:34 --> Database Driver Class Initialized
INFO - 2024-02-18 11:30:34 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-18 11:30:34 --> Parser Class Initialized
INFO - 2024-02-18 11:30:34 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-18 11:30:34 --> Pagination Class Initialized
INFO - 2024-02-18 11:30:34 --> Form Validation Class Initialized
INFO - 2024-02-18 11:30:34 --> Controller Class Initialized
INFO - 2024-02-18 11:30:34 --> Model Class Initialized
DEBUG - 2024-02-18 11:30:34 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-18 11:30:34 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-18 11:30:34 --> Model Class Initialized
DEBUG - 2024-02-18 11:30:34 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-18 11:30:34 --> Model Class Initialized
INFO - 2024-02-18 11:30:34 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice.php
DEBUG - 2024-02-18 11:30:34 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-02-18 11:30:34 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-02-18 11:30:34 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-02-18 11:30:34 --> Model Class Initialized
INFO - 2024-02-18 11:30:34 --> Model Class Initialized
INFO - 2024-02-18 11:30:34 --> Model Class Initialized
INFO - 2024-02-18 11:30:34 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-02-18 11:30:34 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-02-18 11:30:34 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-02-18 11:30:34 --> Final output sent to browser
DEBUG - 2024-02-18 11:30:34 --> Total execution time: 0.1557
ERROR - 2024-02-18 11:30:35 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-18 11:30:35 --> Config Class Initialized
INFO - 2024-02-18 11:30:35 --> Hooks Class Initialized
DEBUG - 2024-02-18 11:30:35 --> UTF-8 Support Enabled
INFO - 2024-02-18 11:30:35 --> Utf8 Class Initialized
INFO - 2024-02-18 11:30:35 --> URI Class Initialized
INFO - 2024-02-18 11:30:35 --> Router Class Initialized
INFO - 2024-02-18 11:30:35 --> Output Class Initialized
INFO - 2024-02-18 11:30:35 --> Security Class Initialized
DEBUG - 2024-02-18 11:30:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-18 11:30:35 --> Input Class Initialized
INFO - 2024-02-18 11:30:35 --> Language Class Initialized
INFO - 2024-02-18 11:30:35 --> Loader Class Initialized
INFO - 2024-02-18 11:30:35 --> Helper loaded: url_helper
INFO - 2024-02-18 11:30:35 --> Helper loaded: file_helper
INFO - 2024-02-18 11:30:35 --> Helper loaded: html_helper
INFO - 2024-02-18 11:30:35 --> Helper loaded: text_helper
INFO - 2024-02-18 11:30:35 --> Helper loaded: form_helper
INFO - 2024-02-18 11:30:35 --> Helper loaded: lang_helper
INFO - 2024-02-18 11:30:35 --> Helper loaded: security_helper
INFO - 2024-02-18 11:30:35 --> Helper loaded: cookie_helper
INFO - 2024-02-18 11:30:35 --> Database Driver Class Initialized
INFO - 2024-02-18 11:30:35 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-18 11:30:35 --> Parser Class Initialized
INFO - 2024-02-18 11:30:35 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-18 11:30:35 --> Pagination Class Initialized
INFO - 2024-02-18 11:30:35 --> Form Validation Class Initialized
INFO - 2024-02-18 11:30:35 --> Controller Class Initialized
INFO - 2024-02-18 11:30:35 --> Model Class Initialized
DEBUG - 2024-02-18 11:30:35 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-18 11:30:35 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-18 11:30:35 --> Model Class Initialized
DEBUG - 2024-02-18 11:30:35 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-18 11:30:35 --> Model Class Initialized
INFO - 2024-02-18 11:30:35 --> Final output sent to browser
DEBUG - 2024-02-18 11:30:35 --> Total execution time: 0.0436
ERROR - 2024-02-18 11:30:40 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-18 11:30:40 --> Config Class Initialized
INFO - 2024-02-18 11:30:40 --> Hooks Class Initialized
DEBUG - 2024-02-18 11:30:40 --> UTF-8 Support Enabled
INFO - 2024-02-18 11:30:40 --> Utf8 Class Initialized
INFO - 2024-02-18 11:30:40 --> URI Class Initialized
INFO - 2024-02-18 11:30:40 --> Router Class Initialized
INFO - 2024-02-18 11:30:40 --> Output Class Initialized
INFO - 2024-02-18 11:30:40 --> Security Class Initialized
DEBUG - 2024-02-18 11:30:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-18 11:30:40 --> Input Class Initialized
INFO - 2024-02-18 11:30:40 --> Language Class Initialized
INFO - 2024-02-18 11:30:40 --> Loader Class Initialized
INFO - 2024-02-18 11:30:40 --> Helper loaded: url_helper
INFO - 2024-02-18 11:30:40 --> Helper loaded: file_helper
INFO - 2024-02-18 11:30:40 --> Helper loaded: html_helper
INFO - 2024-02-18 11:30:40 --> Helper loaded: text_helper
INFO - 2024-02-18 11:30:40 --> Helper loaded: form_helper
INFO - 2024-02-18 11:30:40 --> Helper loaded: lang_helper
INFO - 2024-02-18 11:30:40 --> Helper loaded: security_helper
INFO - 2024-02-18 11:30:40 --> Helper loaded: cookie_helper
INFO - 2024-02-18 11:30:40 --> Database Driver Class Initialized
INFO - 2024-02-18 11:30:40 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-18 11:30:40 --> Parser Class Initialized
INFO - 2024-02-18 11:30:40 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-18 11:30:40 --> Pagination Class Initialized
INFO - 2024-02-18 11:30:40 --> Form Validation Class Initialized
INFO - 2024-02-18 11:30:40 --> Controller Class Initialized
INFO - 2024-02-18 11:30:40 --> Model Class Initialized
DEBUG - 2024-02-18 11:30:40 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-18 11:30:40 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-18 11:30:40 --> Model Class Initialized
DEBUG - 2024-02-18 11:30:40 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-18 11:30:40 --> Model Class Initialized
DEBUG - 2024-02-18 11:30:40 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-18 11:30:40 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice_html_pdf.php
ERROR - 2024-02-18 11:30:40 --> Severity: Warning --> "continue" targeting switch is equivalent to "break". Did you mean to use "continue 2"? /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/dompdf.cls.php 743
ERROR - 2024-02-18 11:30:40 --> Severity: Warning --> "continue" targeting switch is equivalent to "break". Did you mean to use "continue 2"? /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/dompdf.cls.php 763
ERROR - 2024-02-18 11:30:40 --> Severity: Warning --> "continue" targeting switch is equivalent to "break". Did you mean to use "continue 2"? /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/stylesheet.cls.php 1102
ERROR - 2024-02-18 11:30:40 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/page_frame_decorator.cls.php 439
ERROR - 2024-02-18 11:30:40 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/page_frame_decorator.cls.php 439
ERROR - 2024-02-18 11:30:40 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/page_frame_decorator.cls.php 439
ERROR - 2024-02-18 11:30:40 --> Severity: Warning --> Division by zero /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 572
ERROR - 2024-02-18 11:30:40 --> Severity: Warning --> Division by zero /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 572
ERROR - 2024-02-18 11:30:40 --> Severity: Warning --> Division by zero /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 572
ERROR - 2024-02-18 11:30:40 --> Severity: Warning --> Division by zero /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 572
ERROR - 2024-02-18 11:30:40 --> Severity: Warning --> Division by zero /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 572
ERROR - 2024-02-18 11:30:40 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/table_cell_frame_reflower.cls.php 103
ERROR - 2024-02-18 11:30:40 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/table_cell_frame_reflower.cls.php 103
ERROR - 2024-02-18 11:30:40 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/table_cell_frame_reflower.cls.php 103
ERROR - 2024-02-18 11:30:40 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/table_cell_frame_reflower.cls.php 103
ERROR - 2024-02-18 11:30:40 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/table_cell_frame_reflower.cls.php 103
ERROR - 2024-02-18 11:30:40 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/table_cell_frame_reflower.cls.php 103
ERROR - 2024-02-18 11:30:40 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/table_cell_frame_reflower.cls.php 103
ERROR - 2024-02-18 11:30:40 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/table_cell_frame_reflower.cls.php 103
ERROR - 2024-02-18 11:30:40 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/table_cell_frame_reflower.cls.php 103
ERROR - 2024-02-18 11:30:40 --> Severity: Warning --> Invalid argument supplied for foreach() /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 709
ERROR - 2024-02-18 11:30:40 --> Severity: Warning --> Invalid argument supplied for foreach() /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 709
ERROR - 2024-02-18 11:30:40 --> Severity: Warning --> Invalid argument supplied for foreach() /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 709
ERROR - 2024-02-18 11:30:40 --> Severity: Warning --> Invalid argument supplied for foreach() /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 709
ERROR - 2024-02-18 11:30:40 --> Severity: Warning --> Invalid argument supplied for foreach() /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 709
ERROR - 2024-02-18 11:30:40 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-18 11:30:40 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-18 11:30:40 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-18 11:30:40 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-18 11:30:40 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-18 11:30:40 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-18 11:30:40 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-18 11:30:40 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-18 11:30:40 --> Severity: Warning --> "continue" targeting switch is equivalent to "break". Did you mean to use "continue 2"? /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/text_renderer.cls.php 126
ERROR - 2024-02-18 11:30:40 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-18 11:30:40 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-18 11:30:40 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-18 11:30:40 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-18 11:30:40 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-18 11:30:40 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-18 11:30:40 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-18 11:30:40 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-18 11:30:40 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-18 11:30:40 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-18 11:30:40 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-18 11:30:40 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-18 11:30:40 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-18 11:30:40 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-18 11:30:40 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-18 11:30:40 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-18 11:30:40 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-18 11:30:40 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-18 11:30:40 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-18 11:30:40 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-18 11:30:40 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-18 11:30:40 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-18 11:30:40 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-18 11:30:40 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-18 11:30:40 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-18 11:30:40 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-18 11:30:40 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-18 11:30:40 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-18 11:30:40 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-18 11:30:40 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-18 11:30:40 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-18 11:30:40 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-18 11:30:40 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-18 11:30:40 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-18 11:30:40 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-18 11:30:40 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-18 11:30:40 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-18 11:30:40 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-18 11:30:40 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-18 11:30:40 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-18 11:30:40 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-18 11:30:40 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-18 11:30:40 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-18 11:30:40 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-18 11:30:40 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-18 11:30:40 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-18 11:30:40 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-18 11:30:40 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-18 11:30:40 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-18 11:30:40 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-18 11:30:40 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-18 11:30:40 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-18 11:30:40 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-18 11:30:40 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-18 11:30:40 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-18 11:30:40 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-18 11:30:40 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-18 11:30:40 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-18 11:30:40 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-18 11:30:40 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-18 11:30:40 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-18 11:30:40 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-18 11:30:40 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-18 11:30:40 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-18 11:30:40 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-18 11:30:40 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-18 11:30:40 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-18 11:30:40 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-18 11:30:40 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-18 11:30:40 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-18 11:30:40 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-18 11:30:40 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-18 11:30:40 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-18 11:30:40 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-18 11:30:40 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-18 11:30:40 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-18 11:30:40 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-18 11:30:40 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-18 11:30:40 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-18 11:30:40 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-18 11:30:40 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-18 11:30:40 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-18 11:30:40 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-18 11:30:40 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-18 11:30:40 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-18 11:30:40 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-18 11:30:40 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-18 11:30:40 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-18 11:30:40 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-18 11:30:40 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-18 11:30:40 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-18 11:30:40 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-18 11:30:40 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-18 11:30:40 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-18 11:30:40 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-18 11:30:40 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-18 11:30:40 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-18 11:30:40 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-18 11:30:40 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-18 11:30:40 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
INFO - 2024-02-18 11:30:40 --> Final output sent to browser
DEBUG - 2024-02-18 11:30:40 --> Total execution time: 0.2013
ERROR - 2024-02-18 11:34:36 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-18 11:34:36 --> Config Class Initialized
INFO - 2024-02-18 11:34:36 --> Hooks Class Initialized
DEBUG - 2024-02-18 11:34:36 --> UTF-8 Support Enabled
INFO - 2024-02-18 11:34:36 --> Utf8 Class Initialized
INFO - 2024-02-18 11:34:36 --> URI Class Initialized
DEBUG - 2024-02-18 11:34:36 --> No URI present. Default controller set.
INFO - 2024-02-18 11:34:36 --> Router Class Initialized
INFO - 2024-02-18 11:34:36 --> Output Class Initialized
INFO - 2024-02-18 11:34:36 --> Security Class Initialized
DEBUG - 2024-02-18 11:34:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-18 11:34:36 --> Input Class Initialized
INFO - 2024-02-18 11:34:36 --> Language Class Initialized
INFO - 2024-02-18 11:34:36 --> Loader Class Initialized
INFO - 2024-02-18 11:34:36 --> Helper loaded: url_helper
INFO - 2024-02-18 11:34:36 --> Helper loaded: file_helper
INFO - 2024-02-18 11:34:36 --> Helper loaded: html_helper
INFO - 2024-02-18 11:34:36 --> Helper loaded: text_helper
INFO - 2024-02-18 11:34:36 --> Helper loaded: form_helper
INFO - 2024-02-18 11:34:36 --> Helper loaded: lang_helper
INFO - 2024-02-18 11:34:36 --> Helper loaded: security_helper
INFO - 2024-02-18 11:34:36 --> Helper loaded: cookie_helper
INFO - 2024-02-18 11:34:36 --> Database Driver Class Initialized
INFO - 2024-02-18 11:34:36 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-18 11:34:36 --> Parser Class Initialized
INFO - 2024-02-18 11:34:36 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-18 11:34:36 --> Pagination Class Initialized
INFO - 2024-02-18 11:34:36 --> Form Validation Class Initialized
INFO - 2024-02-18 11:34:36 --> Controller Class Initialized
INFO - 2024-02-18 11:34:36 --> Model Class Initialized
DEBUG - 2024-02-18 11:34:36 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-18 11:34:36 --> Model Class Initialized
DEBUG - 2024-02-18 11:34:36 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-18 11:34:36 --> Model Class Initialized
INFO - 2024-02-18 11:34:36 --> Model Class Initialized
INFO - 2024-02-18 11:34:36 --> Model Class Initialized
INFO - 2024-02-18 11:34:36 --> Model Class Initialized
DEBUG - 2024-02-18 11:34:36 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-18 11:34:36 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-18 11:34:36 --> Model Class Initialized
INFO - 2024-02-18 11:34:36 --> Model Class Initialized
INFO - 2024-02-18 11:34:37 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2024-02-18 11:34:37 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-02-18 11:34:37 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-02-18 11:34:37 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-02-18 11:34:37 --> Model Class Initialized
INFO - 2024-02-18 11:34:37 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-02-18 11:34:37 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-02-18 11:34:37 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-02-18 11:34:37 --> Final output sent to browser
DEBUG - 2024-02-18 11:34:37 --> Total execution time: 0.2284
ERROR - 2024-02-18 11:34:45 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-18 11:34:45 --> Config Class Initialized
INFO - 2024-02-18 11:34:45 --> Hooks Class Initialized
DEBUG - 2024-02-18 11:34:45 --> UTF-8 Support Enabled
INFO - 2024-02-18 11:34:45 --> Utf8 Class Initialized
INFO - 2024-02-18 11:34:45 --> URI Class Initialized
INFO - 2024-02-18 11:34:45 --> Router Class Initialized
INFO - 2024-02-18 11:34:45 --> Output Class Initialized
INFO - 2024-02-18 11:34:45 --> Security Class Initialized
DEBUG - 2024-02-18 11:34:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-18 11:34:45 --> Input Class Initialized
INFO - 2024-02-18 11:34:45 --> Language Class Initialized
INFO - 2024-02-18 11:34:45 --> Loader Class Initialized
INFO - 2024-02-18 11:34:45 --> Helper loaded: url_helper
INFO - 2024-02-18 11:34:45 --> Helper loaded: file_helper
INFO - 2024-02-18 11:34:45 --> Helper loaded: html_helper
INFO - 2024-02-18 11:34:45 --> Helper loaded: text_helper
INFO - 2024-02-18 11:34:45 --> Helper loaded: form_helper
INFO - 2024-02-18 11:34:45 --> Helper loaded: lang_helper
INFO - 2024-02-18 11:34:45 --> Helper loaded: security_helper
INFO - 2024-02-18 11:34:45 --> Helper loaded: cookie_helper
INFO - 2024-02-18 11:34:45 --> Database Driver Class Initialized
INFO - 2024-02-18 11:34:45 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-18 11:34:45 --> Parser Class Initialized
INFO - 2024-02-18 11:34:45 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-18 11:34:45 --> Pagination Class Initialized
INFO - 2024-02-18 11:34:45 --> Form Validation Class Initialized
INFO - 2024-02-18 11:34:45 --> Controller Class Initialized
INFO - 2024-02-18 11:34:45 --> Model Class Initialized
DEBUG - 2024-02-18 11:34:45 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-18 11:34:45 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-18 11:34:45 --> Model Class Initialized
DEBUG - 2024-02-18 11:34:45 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-18 11:34:45 --> Model Class Initialized
INFO - 2024-02-18 11:34:45 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice.php
DEBUG - 2024-02-18 11:34:45 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-02-18 11:34:45 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-02-18 11:34:45 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-02-18 11:34:45 --> Model Class Initialized
INFO - 2024-02-18 11:34:45 --> Model Class Initialized
INFO - 2024-02-18 11:34:45 --> Model Class Initialized
INFO - 2024-02-18 11:34:45 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-02-18 11:34:45 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-02-18 11:34:45 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-02-18 11:34:45 --> Final output sent to browser
DEBUG - 2024-02-18 11:34:45 --> Total execution time: 0.1497
ERROR - 2024-02-18 11:34:45 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-18 11:34:45 --> Config Class Initialized
INFO - 2024-02-18 11:34:45 --> Hooks Class Initialized
DEBUG - 2024-02-18 11:34:45 --> UTF-8 Support Enabled
INFO - 2024-02-18 11:34:45 --> Utf8 Class Initialized
INFO - 2024-02-18 11:34:45 --> URI Class Initialized
INFO - 2024-02-18 11:34:45 --> Router Class Initialized
INFO - 2024-02-18 11:34:45 --> Output Class Initialized
INFO - 2024-02-18 11:34:45 --> Security Class Initialized
DEBUG - 2024-02-18 11:34:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-18 11:34:45 --> Input Class Initialized
INFO - 2024-02-18 11:34:45 --> Language Class Initialized
INFO - 2024-02-18 11:34:45 --> Loader Class Initialized
INFO - 2024-02-18 11:34:45 --> Helper loaded: url_helper
INFO - 2024-02-18 11:34:45 --> Helper loaded: file_helper
INFO - 2024-02-18 11:34:45 --> Helper loaded: html_helper
INFO - 2024-02-18 11:34:45 --> Helper loaded: text_helper
INFO - 2024-02-18 11:34:45 --> Helper loaded: form_helper
INFO - 2024-02-18 11:34:45 --> Helper loaded: lang_helper
INFO - 2024-02-18 11:34:45 --> Helper loaded: security_helper
INFO - 2024-02-18 11:34:45 --> Helper loaded: cookie_helper
INFO - 2024-02-18 11:34:45 --> Database Driver Class Initialized
INFO - 2024-02-18 11:34:45 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-18 11:34:45 --> Parser Class Initialized
INFO - 2024-02-18 11:34:45 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-18 11:34:45 --> Pagination Class Initialized
INFO - 2024-02-18 11:34:45 --> Form Validation Class Initialized
INFO - 2024-02-18 11:34:45 --> Controller Class Initialized
INFO - 2024-02-18 11:34:45 --> Model Class Initialized
DEBUG - 2024-02-18 11:34:45 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-18 11:34:45 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-18 11:34:45 --> Model Class Initialized
DEBUG - 2024-02-18 11:34:45 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-18 11:34:45 --> Model Class Initialized
INFO - 2024-02-18 11:34:45 --> Final output sent to browser
DEBUG - 2024-02-18 11:34:45 --> Total execution time: 0.0408
ERROR - 2024-02-18 11:34:57 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-18 11:34:57 --> Config Class Initialized
INFO - 2024-02-18 11:34:57 --> Hooks Class Initialized
DEBUG - 2024-02-18 11:34:57 --> UTF-8 Support Enabled
INFO - 2024-02-18 11:34:57 --> Utf8 Class Initialized
INFO - 2024-02-18 11:34:57 --> URI Class Initialized
INFO - 2024-02-18 11:34:57 --> Router Class Initialized
INFO - 2024-02-18 11:34:57 --> Output Class Initialized
INFO - 2024-02-18 11:34:57 --> Security Class Initialized
DEBUG - 2024-02-18 11:34:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-18 11:34:57 --> Input Class Initialized
INFO - 2024-02-18 11:34:57 --> Language Class Initialized
INFO - 2024-02-18 11:34:57 --> Loader Class Initialized
INFO - 2024-02-18 11:34:57 --> Helper loaded: url_helper
INFO - 2024-02-18 11:34:57 --> Helper loaded: file_helper
INFO - 2024-02-18 11:34:57 --> Helper loaded: html_helper
INFO - 2024-02-18 11:34:57 --> Helper loaded: text_helper
INFO - 2024-02-18 11:34:57 --> Helper loaded: form_helper
INFO - 2024-02-18 11:34:57 --> Helper loaded: lang_helper
INFO - 2024-02-18 11:34:57 --> Helper loaded: security_helper
INFO - 2024-02-18 11:34:57 --> Helper loaded: cookie_helper
INFO - 2024-02-18 11:34:57 --> Database Driver Class Initialized
INFO - 2024-02-18 11:34:57 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-18 11:34:57 --> Parser Class Initialized
INFO - 2024-02-18 11:34:57 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-18 11:34:57 --> Pagination Class Initialized
INFO - 2024-02-18 11:34:57 --> Form Validation Class Initialized
INFO - 2024-02-18 11:34:57 --> Controller Class Initialized
INFO - 2024-02-18 11:34:57 --> Model Class Initialized
DEBUG - 2024-02-18 11:34:57 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-18 11:34:57 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-18 11:34:57 --> Model Class Initialized
INFO - 2024-02-18 11:34:57 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/stockrequest/inventory.php
DEBUG - 2024-02-18 11:34:57 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-02-18 11:34:57 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-02-18 11:34:57 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-02-18 11:34:57 --> Model Class Initialized
INFO - 2024-02-18 11:34:57 --> Model Class Initialized
INFO - 2024-02-18 11:34:57 --> Model Class Initialized
INFO - 2024-02-18 11:34:57 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-02-18 11:34:57 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-02-18 11:34:57 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-02-18 11:34:57 --> Final output sent to browser
DEBUG - 2024-02-18 11:34:57 --> Total execution time: 0.1338
ERROR - 2024-02-18 11:34:57 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-18 11:34:57 --> Config Class Initialized
INFO - 2024-02-18 11:34:57 --> Hooks Class Initialized
DEBUG - 2024-02-18 11:34:57 --> UTF-8 Support Enabled
INFO - 2024-02-18 11:34:57 --> Utf8 Class Initialized
INFO - 2024-02-18 11:34:57 --> URI Class Initialized
INFO - 2024-02-18 11:34:57 --> Router Class Initialized
INFO - 2024-02-18 11:34:57 --> Output Class Initialized
INFO - 2024-02-18 11:34:57 --> Security Class Initialized
DEBUG - 2024-02-18 11:34:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-18 11:34:57 --> Input Class Initialized
INFO - 2024-02-18 11:34:57 --> Language Class Initialized
INFO - 2024-02-18 11:34:57 --> Loader Class Initialized
INFO - 2024-02-18 11:34:57 --> Helper loaded: url_helper
INFO - 2024-02-18 11:34:57 --> Helper loaded: file_helper
INFO - 2024-02-18 11:34:57 --> Helper loaded: html_helper
INFO - 2024-02-18 11:34:57 --> Helper loaded: text_helper
INFO - 2024-02-18 11:34:57 --> Helper loaded: form_helper
INFO - 2024-02-18 11:34:57 --> Helper loaded: lang_helper
INFO - 2024-02-18 11:34:57 --> Helper loaded: security_helper
INFO - 2024-02-18 11:34:57 --> Helper loaded: cookie_helper
INFO - 2024-02-18 11:34:57 --> Database Driver Class Initialized
INFO - 2024-02-18 11:34:57 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-18 11:34:57 --> Parser Class Initialized
INFO - 2024-02-18 11:34:57 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-18 11:34:57 --> Pagination Class Initialized
INFO - 2024-02-18 11:34:57 --> Form Validation Class Initialized
INFO - 2024-02-18 11:34:57 --> Controller Class Initialized
INFO - 2024-02-18 11:34:57 --> Model Class Initialized
DEBUG - 2024-02-18 11:34:57 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-18 11:34:57 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-18 11:34:57 --> Model Class Initialized
INFO - 2024-02-18 11:34:57 --> Final output sent to browser
DEBUG - 2024-02-18 11:34:57 --> Total execution time: 0.0580
ERROR - 2024-02-18 11:35:07 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-18 11:35:07 --> Config Class Initialized
INFO - 2024-02-18 11:35:07 --> Hooks Class Initialized
DEBUG - 2024-02-18 11:35:07 --> UTF-8 Support Enabled
INFO - 2024-02-18 11:35:07 --> Utf8 Class Initialized
INFO - 2024-02-18 11:35:07 --> URI Class Initialized
INFO - 2024-02-18 11:35:07 --> Router Class Initialized
INFO - 2024-02-18 11:35:07 --> Output Class Initialized
INFO - 2024-02-18 11:35:07 --> Security Class Initialized
DEBUG - 2024-02-18 11:35:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-18 11:35:07 --> Input Class Initialized
INFO - 2024-02-18 11:35:07 --> Language Class Initialized
INFO - 2024-02-18 11:35:07 --> Loader Class Initialized
INFO - 2024-02-18 11:35:07 --> Helper loaded: url_helper
INFO - 2024-02-18 11:35:07 --> Helper loaded: file_helper
INFO - 2024-02-18 11:35:07 --> Helper loaded: html_helper
INFO - 2024-02-18 11:35:07 --> Helper loaded: text_helper
INFO - 2024-02-18 11:35:07 --> Helper loaded: form_helper
INFO - 2024-02-18 11:35:07 --> Helper loaded: lang_helper
INFO - 2024-02-18 11:35:07 --> Helper loaded: security_helper
INFO - 2024-02-18 11:35:07 --> Helper loaded: cookie_helper
INFO - 2024-02-18 11:35:07 --> Database Driver Class Initialized
INFO - 2024-02-18 11:35:07 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-18 11:35:07 --> Parser Class Initialized
INFO - 2024-02-18 11:35:07 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-18 11:35:07 --> Pagination Class Initialized
INFO - 2024-02-18 11:35:07 --> Form Validation Class Initialized
INFO - 2024-02-18 11:35:07 --> Controller Class Initialized
INFO - 2024-02-18 11:35:07 --> Model Class Initialized
DEBUG - 2024-02-18 11:35:07 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-18 11:35:07 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-18 11:35:07 --> Model Class Initialized
INFO - 2024-02-18 11:35:07 --> Final output sent to browser
DEBUG - 2024-02-18 11:35:07 --> Total execution time: 0.0535
ERROR - 2024-02-18 11:35:48 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-18 11:35:48 --> Config Class Initialized
INFO - 2024-02-18 11:35:48 --> Hooks Class Initialized
DEBUG - 2024-02-18 11:35:48 --> UTF-8 Support Enabled
INFO - 2024-02-18 11:35:48 --> Utf8 Class Initialized
INFO - 2024-02-18 11:35:48 --> URI Class Initialized
DEBUG - 2024-02-18 11:35:48 --> No URI present. Default controller set.
INFO - 2024-02-18 11:35:48 --> Router Class Initialized
INFO - 2024-02-18 11:35:48 --> Output Class Initialized
INFO - 2024-02-18 11:35:48 --> Security Class Initialized
DEBUG - 2024-02-18 11:35:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-18 11:35:48 --> Input Class Initialized
INFO - 2024-02-18 11:35:48 --> Language Class Initialized
INFO - 2024-02-18 11:35:48 --> Loader Class Initialized
INFO - 2024-02-18 11:35:48 --> Helper loaded: url_helper
INFO - 2024-02-18 11:35:48 --> Helper loaded: file_helper
INFO - 2024-02-18 11:35:48 --> Helper loaded: html_helper
INFO - 2024-02-18 11:35:48 --> Helper loaded: text_helper
INFO - 2024-02-18 11:35:48 --> Helper loaded: form_helper
INFO - 2024-02-18 11:35:48 --> Helper loaded: lang_helper
INFO - 2024-02-18 11:35:48 --> Helper loaded: security_helper
INFO - 2024-02-18 11:35:48 --> Helper loaded: cookie_helper
INFO - 2024-02-18 11:35:48 --> Database Driver Class Initialized
INFO - 2024-02-18 11:35:48 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-18 11:35:48 --> Parser Class Initialized
INFO - 2024-02-18 11:35:48 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-18 11:35:48 --> Pagination Class Initialized
INFO - 2024-02-18 11:35:48 --> Form Validation Class Initialized
INFO - 2024-02-18 11:35:48 --> Controller Class Initialized
INFO - 2024-02-18 11:35:48 --> Model Class Initialized
DEBUG - 2024-02-18 11:35:48 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-18 11:35:48 --> Model Class Initialized
DEBUG - 2024-02-18 11:35:48 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-18 11:35:48 --> Model Class Initialized
INFO - 2024-02-18 11:35:48 --> Model Class Initialized
INFO - 2024-02-18 11:35:48 --> Model Class Initialized
INFO - 2024-02-18 11:35:48 --> Model Class Initialized
DEBUG - 2024-02-18 11:35:48 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-18 11:35:48 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-18 11:35:48 --> Model Class Initialized
INFO - 2024-02-18 11:35:48 --> Model Class Initialized
INFO - 2024-02-18 11:35:48 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2024-02-18 11:35:48 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-02-18 11:35:48 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-02-18 11:35:48 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-02-18 11:35:48 --> Model Class Initialized
INFO - 2024-02-18 11:35:48 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-02-18 11:35:48 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-02-18 11:35:48 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-02-18 11:35:48 --> Final output sent to browser
DEBUG - 2024-02-18 11:35:48 --> Total execution time: 0.2331
ERROR - 2024-02-18 11:35:57 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-18 11:35:57 --> Config Class Initialized
INFO - 2024-02-18 11:35:57 --> Hooks Class Initialized
DEBUG - 2024-02-18 11:35:57 --> UTF-8 Support Enabled
INFO - 2024-02-18 11:35:57 --> Utf8 Class Initialized
INFO - 2024-02-18 11:35:57 --> URI Class Initialized
DEBUG - 2024-02-18 11:35:57 --> No URI present. Default controller set.
INFO - 2024-02-18 11:35:57 --> Router Class Initialized
INFO - 2024-02-18 11:35:57 --> Output Class Initialized
INFO - 2024-02-18 11:35:57 --> Security Class Initialized
DEBUG - 2024-02-18 11:35:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-18 11:35:57 --> Input Class Initialized
INFO - 2024-02-18 11:35:57 --> Language Class Initialized
INFO - 2024-02-18 11:35:57 --> Loader Class Initialized
INFO - 2024-02-18 11:35:57 --> Helper loaded: url_helper
INFO - 2024-02-18 11:35:57 --> Helper loaded: file_helper
INFO - 2024-02-18 11:35:57 --> Helper loaded: html_helper
INFO - 2024-02-18 11:35:57 --> Helper loaded: text_helper
INFO - 2024-02-18 11:35:57 --> Helper loaded: form_helper
INFO - 2024-02-18 11:35:57 --> Helper loaded: lang_helper
INFO - 2024-02-18 11:35:57 --> Helper loaded: security_helper
INFO - 2024-02-18 11:35:57 --> Helper loaded: cookie_helper
INFO - 2024-02-18 11:35:57 --> Database Driver Class Initialized
INFO - 2024-02-18 11:35:57 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-18 11:35:57 --> Parser Class Initialized
INFO - 2024-02-18 11:35:57 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-18 11:35:57 --> Pagination Class Initialized
INFO - 2024-02-18 11:35:57 --> Form Validation Class Initialized
INFO - 2024-02-18 11:35:57 --> Controller Class Initialized
INFO - 2024-02-18 11:35:57 --> Model Class Initialized
DEBUG - 2024-02-18 11:35:57 --> Session class already loaded. Second attempt ignored.
ERROR - 2024-02-18 11:35:57 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-18 11:35:57 --> Config Class Initialized
INFO - 2024-02-18 11:35:57 --> Hooks Class Initialized
DEBUG - 2024-02-18 11:35:57 --> UTF-8 Support Enabled
INFO - 2024-02-18 11:35:57 --> Utf8 Class Initialized
INFO - 2024-02-18 11:35:57 --> URI Class Initialized
INFO - 2024-02-18 11:35:57 --> Router Class Initialized
INFO - 2024-02-18 11:35:57 --> Output Class Initialized
INFO - 2024-02-18 11:35:57 --> Security Class Initialized
DEBUG - 2024-02-18 11:35:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-18 11:35:57 --> Input Class Initialized
INFO - 2024-02-18 11:35:57 --> Language Class Initialized
INFO - 2024-02-18 11:35:57 --> Loader Class Initialized
INFO - 2024-02-18 11:35:57 --> Helper loaded: url_helper
INFO - 2024-02-18 11:35:57 --> Helper loaded: file_helper
INFO - 2024-02-18 11:35:57 --> Helper loaded: html_helper
INFO - 2024-02-18 11:35:57 --> Helper loaded: text_helper
INFO - 2024-02-18 11:35:57 --> Helper loaded: form_helper
INFO - 2024-02-18 11:35:57 --> Helper loaded: lang_helper
INFO - 2024-02-18 11:35:57 --> Helper loaded: security_helper
INFO - 2024-02-18 11:35:57 --> Helper loaded: cookie_helper
INFO - 2024-02-18 11:35:57 --> Database Driver Class Initialized
INFO - 2024-02-18 11:35:57 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-18 11:35:57 --> Parser Class Initialized
INFO - 2024-02-18 11:35:57 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-18 11:35:57 --> Pagination Class Initialized
INFO - 2024-02-18 11:35:57 --> Form Validation Class Initialized
INFO - 2024-02-18 11:35:57 --> Controller Class Initialized
INFO - 2024-02-18 11:35:57 --> Model Class Initialized
DEBUG - 2024-02-18 11:35:57 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-18 11:35:57 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2024-02-18 11:35:57 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-02-18 11:35:57 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-02-18 11:35:57 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-02-18 11:35:57 --> Model Class Initialized
INFO - 2024-02-18 11:35:57 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-02-18 11:35:57 --> Final output sent to browser
DEBUG - 2024-02-18 11:35:57 --> Total execution time: 0.0343
ERROR - 2024-02-18 11:36:00 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-18 11:36:00 --> Config Class Initialized
INFO - 2024-02-18 11:36:00 --> Hooks Class Initialized
DEBUG - 2024-02-18 11:36:00 --> UTF-8 Support Enabled
INFO - 2024-02-18 11:36:00 --> Utf8 Class Initialized
INFO - 2024-02-18 11:36:00 --> URI Class Initialized
INFO - 2024-02-18 11:36:00 --> Router Class Initialized
INFO - 2024-02-18 11:36:00 --> Output Class Initialized
INFO - 2024-02-18 11:36:00 --> Security Class Initialized
DEBUG - 2024-02-18 11:36:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-18 11:36:00 --> Input Class Initialized
INFO - 2024-02-18 11:36:00 --> Language Class Initialized
INFO - 2024-02-18 11:36:00 --> Loader Class Initialized
INFO - 2024-02-18 11:36:00 --> Helper loaded: url_helper
INFO - 2024-02-18 11:36:00 --> Helper loaded: file_helper
INFO - 2024-02-18 11:36:00 --> Helper loaded: html_helper
INFO - 2024-02-18 11:36:00 --> Helper loaded: text_helper
INFO - 2024-02-18 11:36:00 --> Helper loaded: form_helper
INFO - 2024-02-18 11:36:00 --> Helper loaded: lang_helper
INFO - 2024-02-18 11:36:00 --> Helper loaded: security_helper
INFO - 2024-02-18 11:36:00 --> Helper loaded: cookie_helper
INFO - 2024-02-18 11:36:00 --> Database Driver Class Initialized
INFO - 2024-02-18 11:36:00 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-18 11:36:00 --> Parser Class Initialized
INFO - 2024-02-18 11:36:00 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-18 11:36:00 --> Pagination Class Initialized
INFO - 2024-02-18 11:36:00 --> Form Validation Class Initialized
INFO - 2024-02-18 11:36:00 --> Controller Class Initialized
INFO - 2024-02-18 11:36:00 --> Model Class Initialized
DEBUG - 2024-02-18 11:36:00 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-18 11:36:00 --> Model Class Initialized
INFO - 2024-02-18 11:36:00 --> Final output sent to browser
DEBUG - 2024-02-18 11:36:00 --> Total execution time: 0.0164
ERROR - 2024-02-18 11:36:01 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-18 11:36:01 --> Config Class Initialized
INFO - 2024-02-18 11:36:01 --> Hooks Class Initialized
DEBUG - 2024-02-18 11:36:01 --> UTF-8 Support Enabled
INFO - 2024-02-18 11:36:01 --> Utf8 Class Initialized
INFO - 2024-02-18 11:36:01 --> URI Class Initialized
DEBUG - 2024-02-18 11:36:01 --> No URI present. Default controller set.
INFO - 2024-02-18 11:36:01 --> Router Class Initialized
INFO - 2024-02-18 11:36:01 --> Output Class Initialized
INFO - 2024-02-18 11:36:01 --> Security Class Initialized
DEBUG - 2024-02-18 11:36:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-18 11:36:01 --> Input Class Initialized
INFO - 2024-02-18 11:36:01 --> Language Class Initialized
INFO - 2024-02-18 11:36:01 --> Loader Class Initialized
INFO - 2024-02-18 11:36:01 --> Helper loaded: url_helper
INFO - 2024-02-18 11:36:01 --> Helper loaded: file_helper
INFO - 2024-02-18 11:36:01 --> Helper loaded: html_helper
INFO - 2024-02-18 11:36:01 --> Helper loaded: text_helper
INFO - 2024-02-18 11:36:01 --> Helper loaded: form_helper
INFO - 2024-02-18 11:36:01 --> Helper loaded: lang_helper
INFO - 2024-02-18 11:36:01 --> Helper loaded: security_helper
INFO - 2024-02-18 11:36:01 --> Helper loaded: cookie_helper
INFO - 2024-02-18 11:36:01 --> Database Driver Class Initialized
INFO - 2024-02-18 11:36:01 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-18 11:36:01 --> Parser Class Initialized
INFO - 2024-02-18 11:36:01 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-18 11:36:01 --> Pagination Class Initialized
INFO - 2024-02-18 11:36:01 --> Form Validation Class Initialized
INFO - 2024-02-18 11:36:01 --> Controller Class Initialized
INFO - 2024-02-18 11:36:01 --> Model Class Initialized
DEBUG - 2024-02-18 11:36:01 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-18 11:36:01 --> Model Class Initialized
DEBUG - 2024-02-18 11:36:01 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-18 11:36:01 --> Model Class Initialized
INFO - 2024-02-18 11:36:01 --> Model Class Initialized
INFO - 2024-02-18 11:36:01 --> Model Class Initialized
INFO - 2024-02-18 11:36:01 --> Model Class Initialized
DEBUG - 2024-02-18 11:36:01 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-18 11:36:01 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-18 11:36:01 --> Model Class Initialized
INFO - 2024-02-18 11:36:01 --> Model Class Initialized
INFO - 2024-02-18 11:36:01 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2024-02-18 11:36:01 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-02-18 11:36:01 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-02-18 11:36:01 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-02-18 11:36:01 --> Model Class Initialized
INFO - 2024-02-18 11:36:01 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-02-18 11:36:01 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-02-18 11:36:01 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-02-18 11:36:01 --> Final output sent to browser
DEBUG - 2024-02-18 11:36:01 --> Total execution time: 0.4011
ERROR - 2024-02-18 11:36:02 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-18 11:36:02 --> Config Class Initialized
INFO - 2024-02-18 11:36:02 --> Hooks Class Initialized
DEBUG - 2024-02-18 11:36:02 --> UTF-8 Support Enabled
INFO - 2024-02-18 11:36:02 --> Utf8 Class Initialized
INFO - 2024-02-18 11:36:02 --> URI Class Initialized
INFO - 2024-02-18 11:36:02 --> Router Class Initialized
INFO - 2024-02-18 11:36:02 --> Output Class Initialized
INFO - 2024-02-18 11:36:02 --> Security Class Initialized
DEBUG - 2024-02-18 11:36:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-18 11:36:02 --> Input Class Initialized
INFO - 2024-02-18 11:36:02 --> Language Class Initialized
INFO - 2024-02-18 11:36:02 --> Loader Class Initialized
INFO - 2024-02-18 11:36:02 --> Helper loaded: url_helper
INFO - 2024-02-18 11:36:02 --> Helper loaded: file_helper
INFO - 2024-02-18 11:36:02 --> Helper loaded: html_helper
INFO - 2024-02-18 11:36:02 --> Helper loaded: text_helper
INFO - 2024-02-18 11:36:02 --> Helper loaded: form_helper
INFO - 2024-02-18 11:36:02 --> Helper loaded: lang_helper
INFO - 2024-02-18 11:36:02 --> Helper loaded: security_helper
INFO - 2024-02-18 11:36:02 --> Helper loaded: cookie_helper
INFO - 2024-02-18 11:36:02 --> Database Driver Class Initialized
INFO - 2024-02-18 11:36:02 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-18 11:36:02 --> Parser Class Initialized
INFO - 2024-02-18 11:36:02 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-18 11:36:02 --> Pagination Class Initialized
INFO - 2024-02-18 11:36:02 --> Form Validation Class Initialized
INFO - 2024-02-18 11:36:02 --> Controller Class Initialized
DEBUG - 2024-02-18 11:36:02 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-18 11:36:02 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-18 11:36:02 --> Model Class Initialized
INFO - 2024-02-18 11:36:02 --> Final output sent to browser
DEBUG - 2024-02-18 11:36:02 --> Total execution time: 0.0132
ERROR - 2024-02-18 11:36:09 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-18 11:36:09 --> Config Class Initialized
INFO - 2024-02-18 11:36:09 --> Hooks Class Initialized
DEBUG - 2024-02-18 11:36:09 --> UTF-8 Support Enabled
INFO - 2024-02-18 11:36:09 --> Utf8 Class Initialized
INFO - 2024-02-18 11:36:09 --> URI Class Initialized
INFO - 2024-02-18 11:36:09 --> Router Class Initialized
INFO - 2024-02-18 11:36:09 --> Output Class Initialized
INFO - 2024-02-18 11:36:09 --> Security Class Initialized
DEBUG - 2024-02-18 11:36:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-18 11:36:09 --> Input Class Initialized
INFO - 2024-02-18 11:36:09 --> Language Class Initialized
INFO - 2024-02-18 11:36:09 --> Loader Class Initialized
INFO - 2024-02-18 11:36:09 --> Helper loaded: url_helper
INFO - 2024-02-18 11:36:09 --> Helper loaded: file_helper
INFO - 2024-02-18 11:36:09 --> Helper loaded: html_helper
INFO - 2024-02-18 11:36:09 --> Helper loaded: text_helper
INFO - 2024-02-18 11:36:09 --> Helper loaded: form_helper
INFO - 2024-02-18 11:36:09 --> Helper loaded: lang_helper
INFO - 2024-02-18 11:36:09 --> Helper loaded: security_helper
INFO - 2024-02-18 11:36:09 --> Helper loaded: cookie_helper
INFO - 2024-02-18 11:36:09 --> Database Driver Class Initialized
INFO - 2024-02-18 11:36:09 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-18 11:36:09 --> Parser Class Initialized
INFO - 2024-02-18 11:36:09 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-18 11:36:09 --> Pagination Class Initialized
INFO - 2024-02-18 11:36:09 --> Form Validation Class Initialized
INFO - 2024-02-18 11:36:09 --> Controller Class Initialized
INFO - 2024-02-18 11:36:09 --> Model Class Initialized
DEBUG - 2024-02-18 11:36:09 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-18 11:36:09 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-18 11:36:09 --> Model Class Initialized
DEBUG - 2024-02-18 11:36:09 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-18 11:36:09 --> Model Class Initialized
INFO - 2024-02-18 11:36:09 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice.php
DEBUG - 2024-02-18 11:36:09 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-02-18 11:36:09 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-02-18 11:36:09 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-02-18 11:36:09 --> Model Class Initialized
INFO - 2024-02-18 11:36:09 --> Model Class Initialized
INFO - 2024-02-18 11:36:09 --> Model Class Initialized
INFO - 2024-02-18 11:36:10 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-02-18 11:36:10 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-02-18 11:36:10 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-02-18 11:36:10 --> Final output sent to browser
DEBUG - 2024-02-18 11:36:10 --> Total execution time: 0.2213
ERROR - 2024-02-18 11:36:10 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-18 11:36:10 --> Config Class Initialized
INFO - 2024-02-18 11:36:10 --> Hooks Class Initialized
DEBUG - 2024-02-18 11:36:10 --> UTF-8 Support Enabled
INFO - 2024-02-18 11:36:10 --> Utf8 Class Initialized
INFO - 2024-02-18 11:36:10 --> URI Class Initialized
INFO - 2024-02-18 11:36:10 --> Router Class Initialized
INFO - 2024-02-18 11:36:10 --> Output Class Initialized
INFO - 2024-02-18 11:36:10 --> Security Class Initialized
DEBUG - 2024-02-18 11:36:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-18 11:36:10 --> Input Class Initialized
INFO - 2024-02-18 11:36:10 --> Language Class Initialized
INFO - 2024-02-18 11:36:10 --> Loader Class Initialized
INFO - 2024-02-18 11:36:10 --> Helper loaded: url_helper
INFO - 2024-02-18 11:36:10 --> Helper loaded: file_helper
INFO - 2024-02-18 11:36:10 --> Helper loaded: html_helper
INFO - 2024-02-18 11:36:10 --> Helper loaded: text_helper
INFO - 2024-02-18 11:36:10 --> Helper loaded: form_helper
INFO - 2024-02-18 11:36:10 --> Helper loaded: lang_helper
INFO - 2024-02-18 11:36:10 --> Helper loaded: security_helper
INFO - 2024-02-18 11:36:10 --> Helper loaded: cookie_helper
INFO - 2024-02-18 11:36:10 --> Database Driver Class Initialized
INFO - 2024-02-18 11:36:10 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-18 11:36:10 --> Parser Class Initialized
INFO - 2024-02-18 11:36:10 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-18 11:36:10 --> Pagination Class Initialized
INFO - 2024-02-18 11:36:10 --> Form Validation Class Initialized
INFO - 2024-02-18 11:36:10 --> Controller Class Initialized
INFO - 2024-02-18 11:36:10 --> Model Class Initialized
DEBUG - 2024-02-18 11:36:10 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-18 11:36:10 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-18 11:36:10 --> Model Class Initialized
DEBUG - 2024-02-18 11:36:10 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-18 11:36:10 --> Model Class Initialized
INFO - 2024-02-18 11:36:10 --> Final output sent to browser
DEBUG - 2024-02-18 11:36:10 --> Total execution time: 0.0622
ERROR - 2024-02-18 11:36:18 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-18 11:36:18 --> Config Class Initialized
INFO - 2024-02-18 11:36:18 --> Hooks Class Initialized
DEBUG - 2024-02-18 11:36:18 --> UTF-8 Support Enabled
INFO - 2024-02-18 11:36:18 --> Utf8 Class Initialized
INFO - 2024-02-18 11:36:18 --> URI Class Initialized
INFO - 2024-02-18 11:36:18 --> Router Class Initialized
INFO - 2024-02-18 11:36:18 --> Output Class Initialized
INFO - 2024-02-18 11:36:18 --> Security Class Initialized
DEBUG - 2024-02-18 11:36:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-18 11:36:18 --> Input Class Initialized
INFO - 2024-02-18 11:36:18 --> Language Class Initialized
INFO - 2024-02-18 11:36:18 --> Loader Class Initialized
INFO - 2024-02-18 11:36:18 --> Helper loaded: url_helper
INFO - 2024-02-18 11:36:18 --> Helper loaded: file_helper
INFO - 2024-02-18 11:36:18 --> Helper loaded: html_helper
INFO - 2024-02-18 11:36:18 --> Helper loaded: text_helper
INFO - 2024-02-18 11:36:18 --> Helper loaded: form_helper
INFO - 2024-02-18 11:36:18 --> Helper loaded: lang_helper
INFO - 2024-02-18 11:36:18 --> Helper loaded: security_helper
INFO - 2024-02-18 11:36:18 --> Helper loaded: cookie_helper
INFO - 2024-02-18 11:36:18 --> Database Driver Class Initialized
INFO - 2024-02-18 11:36:18 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-18 11:36:18 --> Parser Class Initialized
INFO - 2024-02-18 11:36:18 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-18 11:36:18 --> Pagination Class Initialized
INFO - 2024-02-18 11:36:18 --> Form Validation Class Initialized
INFO - 2024-02-18 11:36:18 --> Controller Class Initialized
INFO - 2024-02-18 11:36:18 --> Model Class Initialized
DEBUG - 2024-02-18 11:36:18 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-18 11:36:18 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-18 11:36:18 --> Model Class Initialized
DEBUG - 2024-02-18 11:36:18 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-18 11:36:18 --> Model Class Initialized
INFO - 2024-02-18 11:36:18 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice.php
DEBUG - 2024-02-18 11:36:18 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-02-18 11:36:18 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-02-18 11:36:18 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-02-18 11:36:18 --> Model Class Initialized
INFO - 2024-02-18 11:36:18 --> Model Class Initialized
INFO - 2024-02-18 11:36:18 --> Model Class Initialized
INFO - 2024-02-18 11:36:18 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-02-18 11:36:18 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-02-18 11:36:18 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-02-18 11:36:18 --> Final output sent to browser
DEBUG - 2024-02-18 11:36:18 --> Total execution time: 0.1424
ERROR - 2024-02-18 11:36:19 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-18 11:36:19 --> Config Class Initialized
INFO - 2024-02-18 11:36:19 --> Hooks Class Initialized
DEBUG - 2024-02-18 11:36:19 --> UTF-8 Support Enabled
INFO - 2024-02-18 11:36:19 --> Utf8 Class Initialized
INFO - 2024-02-18 11:36:19 --> URI Class Initialized
INFO - 2024-02-18 11:36:19 --> Router Class Initialized
INFO - 2024-02-18 11:36:19 --> Output Class Initialized
INFO - 2024-02-18 11:36:19 --> Security Class Initialized
DEBUG - 2024-02-18 11:36:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-18 11:36:19 --> Input Class Initialized
INFO - 2024-02-18 11:36:19 --> Language Class Initialized
INFO - 2024-02-18 11:36:19 --> Loader Class Initialized
INFO - 2024-02-18 11:36:19 --> Helper loaded: url_helper
INFO - 2024-02-18 11:36:19 --> Helper loaded: file_helper
INFO - 2024-02-18 11:36:19 --> Helper loaded: html_helper
INFO - 2024-02-18 11:36:19 --> Helper loaded: text_helper
INFO - 2024-02-18 11:36:19 --> Helper loaded: form_helper
INFO - 2024-02-18 11:36:19 --> Helper loaded: lang_helper
INFO - 2024-02-18 11:36:19 --> Helper loaded: security_helper
INFO - 2024-02-18 11:36:19 --> Helper loaded: cookie_helper
INFO - 2024-02-18 11:36:19 --> Database Driver Class Initialized
INFO - 2024-02-18 11:36:19 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-18 11:36:19 --> Parser Class Initialized
INFO - 2024-02-18 11:36:19 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-18 11:36:19 --> Pagination Class Initialized
INFO - 2024-02-18 11:36:19 --> Form Validation Class Initialized
INFO - 2024-02-18 11:36:19 --> Controller Class Initialized
INFO - 2024-02-18 11:36:19 --> Model Class Initialized
DEBUG - 2024-02-18 11:36:19 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-18 11:36:19 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-18 11:36:19 --> Model Class Initialized
DEBUG - 2024-02-18 11:36:19 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-18 11:36:19 --> Model Class Initialized
INFO - 2024-02-18 11:36:19 --> Final output sent to browser
DEBUG - 2024-02-18 11:36:19 --> Total execution time: 0.0362
ERROR - 2024-02-18 11:36:34 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-18 11:36:34 --> Config Class Initialized
INFO - 2024-02-18 11:36:34 --> Hooks Class Initialized
DEBUG - 2024-02-18 11:36:34 --> UTF-8 Support Enabled
INFO - 2024-02-18 11:36:34 --> Utf8 Class Initialized
INFO - 2024-02-18 11:36:34 --> URI Class Initialized
INFO - 2024-02-18 11:36:34 --> Router Class Initialized
INFO - 2024-02-18 11:36:34 --> Output Class Initialized
INFO - 2024-02-18 11:36:34 --> Security Class Initialized
DEBUG - 2024-02-18 11:36:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-18 11:36:34 --> Input Class Initialized
INFO - 2024-02-18 11:36:34 --> Language Class Initialized
INFO - 2024-02-18 11:36:34 --> Loader Class Initialized
INFO - 2024-02-18 11:36:34 --> Helper loaded: url_helper
INFO - 2024-02-18 11:36:34 --> Helper loaded: file_helper
INFO - 2024-02-18 11:36:34 --> Helper loaded: html_helper
INFO - 2024-02-18 11:36:34 --> Helper loaded: text_helper
INFO - 2024-02-18 11:36:34 --> Helper loaded: form_helper
INFO - 2024-02-18 11:36:34 --> Helper loaded: lang_helper
INFO - 2024-02-18 11:36:34 --> Helper loaded: security_helper
INFO - 2024-02-18 11:36:34 --> Helper loaded: cookie_helper
INFO - 2024-02-18 11:36:34 --> Database Driver Class Initialized
INFO - 2024-02-18 11:36:34 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-18 11:36:34 --> Parser Class Initialized
INFO - 2024-02-18 11:36:34 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-18 11:36:34 --> Pagination Class Initialized
INFO - 2024-02-18 11:36:34 --> Form Validation Class Initialized
INFO - 2024-02-18 11:36:34 --> Controller Class Initialized
INFO - 2024-02-18 11:36:34 --> Model Class Initialized
DEBUG - 2024-02-18 11:36:34 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-18 11:36:34 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-18 11:36:34 --> Model Class Initialized
DEBUG - 2024-02-18 11:36:34 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-18 11:36:34 --> Model Class Initialized
DEBUG - 2024-02-18 11:36:34 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-18 11:36:34 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice_html.php
DEBUG - 2024-02-18 11:36:34 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-02-18 11:36:34 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-02-18 11:36:34 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-02-18 11:36:34 --> Model Class Initialized
INFO - 2024-02-18 11:36:34 --> Model Class Initialized
INFO - 2024-02-18 11:36:34 --> Model Class Initialized
INFO - 2024-02-18 11:36:34 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-02-18 11:36:34 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-02-18 11:36:34 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-02-18 11:36:34 --> Final output sent to browser
DEBUG - 2024-02-18 11:36:34 --> Total execution time: 0.1573
ERROR - 2024-02-18 11:37:01 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-18 11:37:01 --> Config Class Initialized
INFO - 2024-02-18 11:37:01 --> Hooks Class Initialized
DEBUG - 2024-02-18 11:37:01 --> UTF-8 Support Enabled
INFO - 2024-02-18 11:37:01 --> Utf8 Class Initialized
INFO - 2024-02-18 11:37:01 --> URI Class Initialized
INFO - 2024-02-18 11:37:01 --> Router Class Initialized
INFO - 2024-02-18 11:37:01 --> Output Class Initialized
INFO - 2024-02-18 11:37:01 --> Security Class Initialized
DEBUG - 2024-02-18 11:37:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-18 11:37:01 --> Input Class Initialized
INFO - 2024-02-18 11:37:01 --> Language Class Initialized
INFO - 2024-02-18 11:37:01 --> Loader Class Initialized
INFO - 2024-02-18 11:37:01 --> Helper loaded: url_helper
INFO - 2024-02-18 11:37:01 --> Helper loaded: file_helper
INFO - 2024-02-18 11:37:01 --> Helper loaded: html_helper
INFO - 2024-02-18 11:37:01 --> Helper loaded: text_helper
INFO - 2024-02-18 11:37:01 --> Helper loaded: form_helper
INFO - 2024-02-18 11:37:01 --> Helper loaded: lang_helper
INFO - 2024-02-18 11:37:01 --> Helper loaded: security_helper
INFO - 2024-02-18 11:37:01 --> Helper loaded: cookie_helper
INFO - 2024-02-18 11:37:01 --> Database Driver Class Initialized
INFO - 2024-02-18 11:37:01 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-18 11:37:01 --> Parser Class Initialized
INFO - 2024-02-18 11:37:01 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-18 11:37:01 --> Pagination Class Initialized
INFO - 2024-02-18 11:37:01 --> Form Validation Class Initialized
INFO - 2024-02-18 11:37:01 --> Controller Class Initialized
INFO - 2024-02-18 11:37:01 --> Model Class Initialized
DEBUG - 2024-02-18 11:37:01 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-18 11:37:01 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-18 11:37:01 --> Model Class Initialized
DEBUG - 2024-02-18 11:37:01 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-18 11:37:01 --> Model Class Initialized
ERROR - 2024-02-18 11:37:02 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-18 11:37:02 --> Config Class Initialized
INFO - 2024-02-18 11:37:02 --> Hooks Class Initialized
DEBUG - 2024-02-18 11:37:02 --> UTF-8 Support Enabled
INFO - 2024-02-18 11:37:02 --> Utf8 Class Initialized
INFO - 2024-02-18 11:37:02 --> URI Class Initialized
INFO - 2024-02-18 11:37:02 --> Router Class Initialized
INFO - 2024-02-18 11:37:02 --> Output Class Initialized
INFO - 2024-02-18 11:37:02 --> Security Class Initialized
DEBUG - 2024-02-18 11:37:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-18 11:37:02 --> Input Class Initialized
INFO - 2024-02-18 11:37:02 --> Language Class Initialized
INFO - 2024-02-18 11:37:02 --> Loader Class Initialized
INFO - 2024-02-18 11:37:02 --> Helper loaded: url_helper
INFO - 2024-02-18 11:37:02 --> Helper loaded: file_helper
INFO - 2024-02-18 11:37:02 --> Helper loaded: html_helper
INFO - 2024-02-18 11:37:02 --> Helper loaded: text_helper
INFO - 2024-02-18 11:37:02 --> Helper loaded: form_helper
INFO - 2024-02-18 11:37:02 --> Helper loaded: lang_helper
INFO - 2024-02-18 11:37:02 --> Helper loaded: security_helper
INFO - 2024-02-18 11:37:02 --> Helper loaded: cookie_helper
INFO - 2024-02-18 11:37:02 --> Database Driver Class Initialized
INFO - 2024-02-18 11:37:02 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-18 11:37:02 --> Parser Class Initialized
INFO - 2024-02-18 11:37:02 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-18 11:37:02 --> Pagination Class Initialized
INFO - 2024-02-18 11:37:02 --> Form Validation Class Initialized
INFO - 2024-02-18 11:37:02 --> Controller Class Initialized
INFO - 2024-02-18 11:37:02 --> Model Class Initialized
DEBUG - 2024-02-18 11:37:02 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-18 11:37:02 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-18 11:37:02 --> Model Class Initialized
DEBUG - 2024-02-18 11:37:02 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-18 11:37:02 --> Model Class Initialized
INFO - 2024-02-18 11:37:02 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice.php
DEBUG - 2024-02-18 11:37:02 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-02-18 11:37:02 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-02-18 11:37:02 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-02-18 11:37:02 --> Model Class Initialized
INFO - 2024-02-18 11:37:02 --> Model Class Initialized
INFO - 2024-02-18 11:37:02 --> Model Class Initialized
INFO - 2024-02-18 11:37:02 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-02-18 11:37:02 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-02-18 11:37:02 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-02-18 11:37:02 --> Final output sent to browser
DEBUG - 2024-02-18 11:37:02 --> Total execution time: 0.2178
ERROR - 2024-02-18 11:37:02 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-18 11:37:02 --> Config Class Initialized
INFO - 2024-02-18 11:37:02 --> Hooks Class Initialized
DEBUG - 2024-02-18 11:37:02 --> UTF-8 Support Enabled
INFO - 2024-02-18 11:37:02 --> Utf8 Class Initialized
INFO - 2024-02-18 11:37:02 --> URI Class Initialized
INFO - 2024-02-18 11:37:02 --> Router Class Initialized
INFO - 2024-02-18 11:37:02 --> Output Class Initialized
INFO - 2024-02-18 11:37:02 --> Security Class Initialized
DEBUG - 2024-02-18 11:37:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-18 11:37:02 --> Input Class Initialized
INFO - 2024-02-18 11:37:02 --> Language Class Initialized
INFO - 2024-02-18 11:37:02 --> Loader Class Initialized
INFO - 2024-02-18 11:37:02 --> Helper loaded: url_helper
INFO - 2024-02-18 11:37:02 --> Helper loaded: file_helper
INFO - 2024-02-18 11:37:02 --> Helper loaded: html_helper
INFO - 2024-02-18 11:37:02 --> Helper loaded: text_helper
INFO - 2024-02-18 11:37:02 --> Helper loaded: form_helper
INFO - 2024-02-18 11:37:02 --> Helper loaded: lang_helper
INFO - 2024-02-18 11:37:02 --> Helper loaded: security_helper
INFO - 2024-02-18 11:37:02 --> Helper loaded: cookie_helper
INFO - 2024-02-18 11:37:02 --> Database Driver Class Initialized
INFO - 2024-02-18 11:37:02 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-18 11:37:02 --> Parser Class Initialized
INFO - 2024-02-18 11:37:02 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-18 11:37:02 --> Pagination Class Initialized
INFO - 2024-02-18 11:37:02 --> Form Validation Class Initialized
INFO - 2024-02-18 11:37:02 --> Controller Class Initialized
INFO - 2024-02-18 11:37:02 --> Model Class Initialized
DEBUG - 2024-02-18 11:37:02 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-18 11:37:02 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-18 11:37:02 --> Model Class Initialized
DEBUG - 2024-02-18 11:37:02 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-18 11:37:02 --> Model Class Initialized
INFO - 2024-02-18 11:37:02 --> Final output sent to browser
DEBUG - 2024-02-18 11:37:02 --> Total execution time: 0.0603
ERROR - 2024-02-18 11:37:18 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-18 11:37:18 --> Config Class Initialized
INFO - 2024-02-18 11:37:18 --> Hooks Class Initialized
DEBUG - 2024-02-18 11:37:18 --> UTF-8 Support Enabled
INFO - 2024-02-18 11:37:18 --> Utf8 Class Initialized
INFO - 2024-02-18 11:37:18 --> URI Class Initialized
INFO - 2024-02-18 11:37:18 --> Router Class Initialized
INFO - 2024-02-18 11:37:18 --> Output Class Initialized
INFO - 2024-02-18 11:37:18 --> Security Class Initialized
DEBUG - 2024-02-18 11:37:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-18 11:37:18 --> Input Class Initialized
INFO - 2024-02-18 11:37:18 --> Language Class Initialized
INFO - 2024-02-18 11:37:18 --> Loader Class Initialized
INFO - 2024-02-18 11:37:18 --> Helper loaded: url_helper
INFO - 2024-02-18 11:37:18 --> Helper loaded: file_helper
INFO - 2024-02-18 11:37:18 --> Helper loaded: html_helper
INFO - 2024-02-18 11:37:18 --> Helper loaded: text_helper
INFO - 2024-02-18 11:37:18 --> Helper loaded: form_helper
INFO - 2024-02-18 11:37:18 --> Helper loaded: lang_helper
INFO - 2024-02-18 11:37:18 --> Helper loaded: security_helper
INFO - 2024-02-18 11:37:18 --> Helper loaded: cookie_helper
INFO - 2024-02-18 11:37:18 --> Database Driver Class Initialized
INFO - 2024-02-18 11:37:18 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-18 11:37:18 --> Parser Class Initialized
INFO - 2024-02-18 11:37:18 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-18 11:37:18 --> Pagination Class Initialized
INFO - 2024-02-18 11:37:18 --> Form Validation Class Initialized
INFO - 2024-02-18 11:37:18 --> Controller Class Initialized
INFO - 2024-02-18 11:37:18 --> Model Class Initialized
DEBUG - 2024-02-18 11:37:18 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-18 11:37:18 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-18 11:37:18 --> Model Class Initialized
DEBUG - 2024-02-18 11:37:18 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-18 11:37:18 --> Model Class Initialized
INFO - 2024-02-18 11:37:18 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice.php
DEBUG - 2024-02-18 11:37:18 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-02-18 11:37:18 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-02-18 11:37:18 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-02-18 11:37:18 --> Model Class Initialized
INFO - 2024-02-18 11:37:18 --> Model Class Initialized
INFO - 2024-02-18 11:37:18 --> Model Class Initialized
INFO - 2024-02-18 11:37:18 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-02-18 11:37:18 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-02-18 11:37:18 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-02-18 11:37:18 --> Final output sent to browser
DEBUG - 2024-02-18 11:37:18 --> Total execution time: 0.1520
ERROR - 2024-02-18 11:37:19 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-18 11:37:19 --> Config Class Initialized
INFO - 2024-02-18 11:37:19 --> Hooks Class Initialized
DEBUG - 2024-02-18 11:37:19 --> UTF-8 Support Enabled
INFO - 2024-02-18 11:37:19 --> Utf8 Class Initialized
INFO - 2024-02-18 11:37:19 --> URI Class Initialized
INFO - 2024-02-18 11:37:19 --> Router Class Initialized
INFO - 2024-02-18 11:37:19 --> Output Class Initialized
INFO - 2024-02-18 11:37:19 --> Security Class Initialized
DEBUG - 2024-02-18 11:37:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-18 11:37:19 --> Input Class Initialized
INFO - 2024-02-18 11:37:19 --> Language Class Initialized
INFO - 2024-02-18 11:37:19 --> Loader Class Initialized
INFO - 2024-02-18 11:37:19 --> Helper loaded: url_helper
INFO - 2024-02-18 11:37:19 --> Helper loaded: file_helper
INFO - 2024-02-18 11:37:19 --> Helper loaded: html_helper
INFO - 2024-02-18 11:37:19 --> Helper loaded: text_helper
INFO - 2024-02-18 11:37:19 --> Helper loaded: form_helper
INFO - 2024-02-18 11:37:19 --> Helper loaded: lang_helper
INFO - 2024-02-18 11:37:19 --> Helper loaded: security_helper
INFO - 2024-02-18 11:37:19 --> Helper loaded: cookie_helper
INFO - 2024-02-18 11:37:19 --> Database Driver Class Initialized
INFO - 2024-02-18 11:37:19 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-18 11:37:19 --> Parser Class Initialized
INFO - 2024-02-18 11:37:19 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-18 11:37:19 --> Pagination Class Initialized
INFO - 2024-02-18 11:37:19 --> Form Validation Class Initialized
INFO - 2024-02-18 11:37:19 --> Controller Class Initialized
INFO - 2024-02-18 11:37:19 --> Model Class Initialized
DEBUG - 2024-02-18 11:37:19 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-18 11:37:19 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-18 11:37:19 --> Model Class Initialized
DEBUG - 2024-02-18 11:37:19 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-18 11:37:19 --> Model Class Initialized
INFO - 2024-02-18 11:37:19 --> Final output sent to browser
DEBUG - 2024-02-18 11:37:19 --> Total execution time: 0.0425
ERROR - 2024-02-18 11:37:24 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-18 11:37:24 --> Config Class Initialized
INFO - 2024-02-18 11:37:24 --> Hooks Class Initialized
DEBUG - 2024-02-18 11:37:24 --> UTF-8 Support Enabled
INFO - 2024-02-18 11:37:24 --> Utf8 Class Initialized
INFO - 2024-02-18 11:37:24 --> URI Class Initialized
INFO - 2024-02-18 11:37:24 --> Router Class Initialized
INFO - 2024-02-18 11:37:24 --> Output Class Initialized
INFO - 2024-02-18 11:37:24 --> Security Class Initialized
DEBUG - 2024-02-18 11:37:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-18 11:37:24 --> Input Class Initialized
INFO - 2024-02-18 11:37:24 --> Language Class Initialized
INFO - 2024-02-18 11:37:24 --> Loader Class Initialized
INFO - 2024-02-18 11:37:24 --> Helper loaded: url_helper
INFO - 2024-02-18 11:37:24 --> Helper loaded: file_helper
INFO - 2024-02-18 11:37:24 --> Helper loaded: html_helper
INFO - 2024-02-18 11:37:24 --> Helper loaded: text_helper
INFO - 2024-02-18 11:37:24 --> Helper loaded: form_helper
INFO - 2024-02-18 11:37:24 --> Helper loaded: lang_helper
INFO - 2024-02-18 11:37:24 --> Helper loaded: security_helper
INFO - 2024-02-18 11:37:24 --> Helper loaded: cookie_helper
INFO - 2024-02-18 11:37:24 --> Database Driver Class Initialized
INFO - 2024-02-18 11:37:24 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-18 11:37:24 --> Parser Class Initialized
INFO - 2024-02-18 11:37:24 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-18 11:37:24 --> Pagination Class Initialized
INFO - 2024-02-18 11:37:24 --> Form Validation Class Initialized
INFO - 2024-02-18 11:37:24 --> Controller Class Initialized
INFO - 2024-02-18 11:37:24 --> Model Class Initialized
DEBUG - 2024-02-18 11:37:24 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-18 11:37:24 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-18 11:37:24 --> Model Class Initialized
DEBUG - 2024-02-18 11:37:24 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-18 11:37:24 --> Model Class Initialized
INFO - 2024-02-18 11:37:24 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/add_invoice_form.php
DEBUG - 2024-02-18 11:37:24 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-02-18 11:37:24 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-02-18 11:37:24 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-02-18 11:37:24 --> Model Class Initialized
INFO - 2024-02-18 11:37:24 --> Model Class Initialized
INFO - 2024-02-18 11:37:24 --> Model Class Initialized
INFO - 2024-02-18 11:37:24 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-02-18 11:37:24 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-02-18 11:37:24 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-02-18 11:37:24 --> Final output sent to browser
DEBUG - 2024-02-18 11:37:24 --> Total execution time: 0.1647
ERROR - 2024-02-18 11:37:31 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-18 11:37:31 --> Config Class Initialized
INFO - 2024-02-18 11:37:31 --> Hooks Class Initialized
DEBUG - 2024-02-18 11:37:31 --> UTF-8 Support Enabled
INFO - 2024-02-18 11:37:31 --> Utf8 Class Initialized
INFO - 2024-02-18 11:37:31 --> URI Class Initialized
INFO - 2024-02-18 11:37:31 --> Router Class Initialized
INFO - 2024-02-18 11:37:31 --> Output Class Initialized
INFO - 2024-02-18 11:37:31 --> Security Class Initialized
DEBUG - 2024-02-18 11:37:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-18 11:37:31 --> Input Class Initialized
INFO - 2024-02-18 11:37:31 --> Language Class Initialized
INFO - 2024-02-18 11:37:31 --> Loader Class Initialized
INFO - 2024-02-18 11:37:31 --> Helper loaded: url_helper
INFO - 2024-02-18 11:37:31 --> Helper loaded: file_helper
INFO - 2024-02-18 11:37:31 --> Helper loaded: html_helper
INFO - 2024-02-18 11:37:31 --> Helper loaded: text_helper
INFO - 2024-02-18 11:37:31 --> Helper loaded: form_helper
INFO - 2024-02-18 11:37:31 --> Helper loaded: lang_helper
INFO - 2024-02-18 11:37:31 --> Helper loaded: security_helper
INFO - 2024-02-18 11:37:31 --> Helper loaded: cookie_helper
INFO - 2024-02-18 11:37:31 --> Database Driver Class Initialized
INFO - 2024-02-18 11:37:31 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-18 11:37:31 --> Parser Class Initialized
INFO - 2024-02-18 11:37:31 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-18 11:37:31 --> Pagination Class Initialized
INFO - 2024-02-18 11:37:31 --> Form Validation Class Initialized
INFO - 2024-02-18 11:37:31 --> Controller Class Initialized
INFO - 2024-02-18 11:37:31 --> Model Class Initialized
DEBUG - 2024-02-18 11:37:31 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-18 11:37:31 --> Final output sent to browser
DEBUG - 2024-02-18 11:37:31 --> Total execution time: 0.0155
ERROR - 2024-02-18 11:37:32 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-18 11:37:32 --> Config Class Initialized
INFO - 2024-02-18 11:37:32 --> Hooks Class Initialized
DEBUG - 2024-02-18 11:37:32 --> UTF-8 Support Enabled
INFO - 2024-02-18 11:37:32 --> Utf8 Class Initialized
INFO - 2024-02-18 11:37:32 --> URI Class Initialized
INFO - 2024-02-18 11:37:32 --> Router Class Initialized
INFO - 2024-02-18 11:37:32 --> Output Class Initialized
INFO - 2024-02-18 11:37:32 --> Security Class Initialized
DEBUG - 2024-02-18 11:37:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-18 11:37:32 --> Input Class Initialized
INFO - 2024-02-18 11:37:32 --> Language Class Initialized
INFO - 2024-02-18 11:37:32 --> Loader Class Initialized
INFO - 2024-02-18 11:37:32 --> Helper loaded: url_helper
INFO - 2024-02-18 11:37:32 --> Helper loaded: file_helper
INFO - 2024-02-18 11:37:32 --> Helper loaded: html_helper
INFO - 2024-02-18 11:37:32 --> Helper loaded: text_helper
INFO - 2024-02-18 11:37:32 --> Helper loaded: form_helper
INFO - 2024-02-18 11:37:32 --> Helper loaded: lang_helper
INFO - 2024-02-18 11:37:32 --> Helper loaded: security_helper
INFO - 2024-02-18 11:37:32 --> Helper loaded: cookie_helper
INFO - 2024-02-18 11:37:32 --> Database Driver Class Initialized
INFO - 2024-02-18 11:37:32 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-18 11:37:32 --> Parser Class Initialized
INFO - 2024-02-18 11:37:32 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-18 11:37:32 --> Pagination Class Initialized
INFO - 2024-02-18 11:37:32 --> Form Validation Class Initialized
INFO - 2024-02-18 11:37:32 --> Controller Class Initialized
INFO - 2024-02-18 11:37:32 --> Model Class Initialized
DEBUG - 2024-02-18 11:37:32 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-18 11:37:32 --> Final output sent to browser
DEBUG - 2024-02-18 11:37:32 --> Total execution time: 0.0156
ERROR - 2024-02-18 11:37:39 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-18 11:37:39 --> Config Class Initialized
INFO - 2024-02-18 11:37:39 --> Hooks Class Initialized
DEBUG - 2024-02-18 11:37:39 --> UTF-8 Support Enabled
INFO - 2024-02-18 11:37:39 --> Utf8 Class Initialized
INFO - 2024-02-18 11:37:39 --> URI Class Initialized
INFO - 2024-02-18 11:37:39 --> Router Class Initialized
INFO - 2024-02-18 11:37:39 --> Output Class Initialized
INFO - 2024-02-18 11:37:39 --> Security Class Initialized
DEBUG - 2024-02-18 11:37:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-18 11:37:39 --> Input Class Initialized
INFO - 2024-02-18 11:37:39 --> Language Class Initialized
INFO - 2024-02-18 11:37:39 --> Loader Class Initialized
INFO - 2024-02-18 11:37:39 --> Helper loaded: url_helper
INFO - 2024-02-18 11:37:39 --> Helper loaded: file_helper
INFO - 2024-02-18 11:37:39 --> Helper loaded: html_helper
INFO - 2024-02-18 11:37:39 --> Helper loaded: text_helper
INFO - 2024-02-18 11:37:39 --> Helper loaded: form_helper
INFO - 2024-02-18 11:37:39 --> Helper loaded: lang_helper
INFO - 2024-02-18 11:37:39 --> Helper loaded: security_helper
INFO - 2024-02-18 11:37:39 --> Helper loaded: cookie_helper
INFO - 2024-02-18 11:37:39 --> Database Driver Class Initialized
INFO - 2024-02-18 11:37:39 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-18 11:37:39 --> Parser Class Initialized
INFO - 2024-02-18 11:37:39 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-18 11:37:39 --> Pagination Class Initialized
INFO - 2024-02-18 11:37:39 --> Form Validation Class Initialized
INFO - 2024-02-18 11:37:39 --> Controller Class Initialized
INFO - 2024-02-18 11:37:39 --> Final output sent to browser
DEBUG - 2024-02-18 11:37:39 --> Total execution time: 0.0139
ERROR - 2024-02-18 11:37:42 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-18 11:37:42 --> Config Class Initialized
INFO - 2024-02-18 11:37:42 --> Hooks Class Initialized
DEBUG - 2024-02-18 11:37:42 --> UTF-8 Support Enabled
INFO - 2024-02-18 11:37:42 --> Utf8 Class Initialized
INFO - 2024-02-18 11:37:42 --> URI Class Initialized
INFO - 2024-02-18 11:37:42 --> Router Class Initialized
INFO - 2024-02-18 11:37:42 --> Output Class Initialized
INFO - 2024-02-18 11:37:42 --> Security Class Initialized
DEBUG - 2024-02-18 11:37:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-18 11:37:42 --> Input Class Initialized
INFO - 2024-02-18 11:37:42 --> Language Class Initialized
INFO - 2024-02-18 11:37:42 --> Loader Class Initialized
INFO - 2024-02-18 11:37:42 --> Helper loaded: url_helper
INFO - 2024-02-18 11:37:42 --> Helper loaded: file_helper
INFO - 2024-02-18 11:37:42 --> Helper loaded: html_helper
INFO - 2024-02-18 11:37:42 --> Helper loaded: text_helper
INFO - 2024-02-18 11:37:42 --> Helper loaded: form_helper
INFO - 2024-02-18 11:37:42 --> Helper loaded: lang_helper
INFO - 2024-02-18 11:37:42 --> Helper loaded: security_helper
INFO - 2024-02-18 11:37:42 --> Helper loaded: cookie_helper
INFO - 2024-02-18 11:37:42 --> Database Driver Class Initialized
INFO - 2024-02-18 11:37:42 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-18 11:37:42 --> Parser Class Initialized
INFO - 2024-02-18 11:37:42 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-18 11:37:42 --> Pagination Class Initialized
INFO - 2024-02-18 11:37:42 --> Form Validation Class Initialized
INFO - 2024-02-18 11:37:42 --> Controller Class Initialized
INFO - 2024-02-18 11:37:42 --> Model Class Initialized
DEBUG - 2024-02-18 11:37:42 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-18 11:37:42 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-18 11:37:42 --> Model Class Initialized
DEBUG - 2024-02-18 11:37:42 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-18 11:37:42 --> Model Class Initialized
INFO - 2024-02-18 11:37:42 --> Final output sent to browser
DEBUG - 2024-02-18 11:37:42 --> Total execution time: 0.0963
ERROR - 2024-02-18 11:37:42 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-18 11:37:42 --> Config Class Initialized
INFO - 2024-02-18 11:37:42 --> Hooks Class Initialized
DEBUG - 2024-02-18 11:37:42 --> UTF-8 Support Enabled
INFO - 2024-02-18 11:37:42 --> Utf8 Class Initialized
INFO - 2024-02-18 11:37:42 --> URI Class Initialized
INFO - 2024-02-18 11:37:42 --> Router Class Initialized
INFO - 2024-02-18 11:37:42 --> Output Class Initialized
INFO - 2024-02-18 11:37:42 --> Security Class Initialized
DEBUG - 2024-02-18 11:37:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-18 11:37:42 --> Input Class Initialized
INFO - 2024-02-18 11:37:42 --> Language Class Initialized
INFO - 2024-02-18 11:37:42 --> Loader Class Initialized
INFO - 2024-02-18 11:37:42 --> Helper loaded: url_helper
INFO - 2024-02-18 11:37:42 --> Helper loaded: file_helper
INFO - 2024-02-18 11:37:42 --> Helper loaded: html_helper
INFO - 2024-02-18 11:37:42 --> Helper loaded: text_helper
INFO - 2024-02-18 11:37:42 --> Helper loaded: form_helper
INFO - 2024-02-18 11:37:42 --> Helper loaded: lang_helper
INFO - 2024-02-18 11:37:42 --> Helper loaded: security_helper
INFO - 2024-02-18 11:37:42 --> Helper loaded: cookie_helper
INFO - 2024-02-18 11:37:42 --> Database Driver Class Initialized
INFO - 2024-02-18 11:37:42 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-18 11:37:42 --> Parser Class Initialized
INFO - 2024-02-18 11:37:42 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-18 11:37:42 --> Pagination Class Initialized
INFO - 2024-02-18 11:37:42 --> Form Validation Class Initialized
INFO - 2024-02-18 11:37:42 --> Controller Class Initialized
INFO - 2024-02-18 11:37:42 --> Model Class Initialized
DEBUG - 2024-02-18 11:37:42 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-18 11:37:42 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-18 11:37:42 --> Model Class Initialized
DEBUG - 2024-02-18 11:37:42 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-18 11:37:42 --> Model Class Initialized
INFO - 2024-02-18 11:37:42 --> Final output sent to browser
DEBUG - 2024-02-18 11:37:42 --> Total execution time: 0.0924
ERROR - 2024-02-18 11:37:43 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-18 11:37:43 --> Config Class Initialized
INFO - 2024-02-18 11:37:43 --> Hooks Class Initialized
DEBUG - 2024-02-18 11:37:43 --> UTF-8 Support Enabled
INFO - 2024-02-18 11:37:43 --> Utf8 Class Initialized
INFO - 2024-02-18 11:37:43 --> URI Class Initialized
INFO - 2024-02-18 11:37:43 --> Router Class Initialized
INFO - 2024-02-18 11:37:43 --> Output Class Initialized
INFO - 2024-02-18 11:37:43 --> Security Class Initialized
DEBUG - 2024-02-18 11:37:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-18 11:37:43 --> Input Class Initialized
INFO - 2024-02-18 11:37:43 --> Language Class Initialized
INFO - 2024-02-18 11:37:43 --> Loader Class Initialized
INFO - 2024-02-18 11:37:43 --> Helper loaded: url_helper
INFO - 2024-02-18 11:37:43 --> Helper loaded: file_helper
INFO - 2024-02-18 11:37:43 --> Helper loaded: html_helper
INFO - 2024-02-18 11:37:43 --> Helper loaded: text_helper
INFO - 2024-02-18 11:37:43 --> Helper loaded: form_helper
INFO - 2024-02-18 11:37:43 --> Helper loaded: lang_helper
INFO - 2024-02-18 11:37:43 --> Helper loaded: security_helper
INFO - 2024-02-18 11:37:43 --> Helper loaded: cookie_helper
INFO - 2024-02-18 11:37:43 --> Database Driver Class Initialized
INFO - 2024-02-18 11:37:43 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-18 11:37:43 --> Parser Class Initialized
INFO - 2024-02-18 11:37:43 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-18 11:37:43 --> Pagination Class Initialized
INFO - 2024-02-18 11:37:43 --> Form Validation Class Initialized
INFO - 2024-02-18 11:37:43 --> Controller Class Initialized
INFO - 2024-02-18 11:37:43 --> Model Class Initialized
DEBUG - 2024-02-18 11:37:43 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-18 11:37:43 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-18 11:37:43 --> Model Class Initialized
DEBUG - 2024-02-18 11:37:43 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-18 11:37:43 --> Model Class Initialized
INFO - 2024-02-18 11:37:43 --> Final output sent to browser
DEBUG - 2024-02-18 11:37:43 --> Total execution time: 0.1022
ERROR - 2024-02-18 11:37:44 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-18 11:37:44 --> Config Class Initialized
INFO - 2024-02-18 11:37:44 --> Hooks Class Initialized
DEBUG - 2024-02-18 11:37:44 --> UTF-8 Support Enabled
INFO - 2024-02-18 11:37:44 --> Utf8 Class Initialized
INFO - 2024-02-18 11:37:44 --> URI Class Initialized
INFO - 2024-02-18 11:37:44 --> Router Class Initialized
INFO - 2024-02-18 11:37:44 --> Output Class Initialized
INFO - 2024-02-18 11:37:44 --> Security Class Initialized
DEBUG - 2024-02-18 11:37:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-18 11:37:44 --> Input Class Initialized
INFO - 2024-02-18 11:37:44 --> Language Class Initialized
INFO - 2024-02-18 11:37:44 --> Loader Class Initialized
INFO - 2024-02-18 11:37:44 --> Helper loaded: url_helper
INFO - 2024-02-18 11:37:44 --> Helper loaded: file_helper
INFO - 2024-02-18 11:37:44 --> Helper loaded: html_helper
INFO - 2024-02-18 11:37:44 --> Helper loaded: text_helper
INFO - 2024-02-18 11:37:44 --> Helper loaded: form_helper
INFO - 2024-02-18 11:37:44 --> Helper loaded: lang_helper
INFO - 2024-02-18 11:37:44 --> Helper loaded: security_helper
INFO - 2024-02-18 11:37:44 --> Helper loaded: cookie_helper
INFO - 2024-02-18 11:37:44 --> Database Driver Class Initialized
INFO - 2024-02-18 11:37:44 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-18 11:37:44 --> Parser Class Initialized
INFO - 2024-02-18 11:37:44 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-18 11:37:44 --> Pagination Class Initialized
INFO - 2024-02-18 11:37:44 --> Form Validation Class Initialized
INFO - 2024-02-18 11:37:44 --> Controller Class Initialized
INFO - 2024-02-18 11:37:44 --> Model Class Initialized
DEBUG - 2024-02-18 11:37:44 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-18 11:37:44 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-18 11:37:44 --> Model Class Initialized
DEBUG - 2024-02-18 11:37:44 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-18 11:37:44 --> Model Class Initialized
INFO - 2024-02-18 11:37:44 --> Final output sent to browser
DEBUG - 2024-02-18 11:37:44 --> Total execution time: 0.0955
ERROR - 2024-02-18 11:37:45 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-18 11:37:45 --> Config Class Initialized
INFO - 2024-02-18 11:37:45 --> Hooks Class Initialized
DEBUG - 2024-02-18 11:37:45 --> UTF-8 Support Enabled
INFO - 2024-02-18 11:37:45 --> Utf8 Class Initialized
INFO - 2024-02-18 11:37:45 --> URI Class Initialized
INFO - 2024-02-18 11:37:45 --> Router Class Initialized
INFO - 2024-02-18 11:37:45 --> Output Class Initialized
INFO - 2024-02-18 11:37:45 --> Security Class Initialized
DEBUG - 2024-02-18 11:37:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-18 11:37:45 --> Input Class Initialized
INFO - 2024-02-18 11:37:45 --> Language Class Initialized
INFO - 2024-02-18 11:37:45 --> Loader Class Initialized
INFO - 2024-02-18 11:37:45 --> Helper loaded: url_helper
INFO - 2024-02-18 11:37:45 --> Helper loaded: file_helper
INFO - 2024-02-18 11:37:45 --> Helper loaded: html_helper
INFO - 2024-02-18 11:37:45 --> Helper loaded: text_helper
INFO - 2024-02-18 11:37:45 --> Helper loaded: form_helper
INFO - 2024-02-18 11:37:45 --> Helper loaded: lang_helper
INFO - 2024-02-18 11:37:45 --> Helper loaded: security_helper
INFO - 2024-02-18 11:37:45 --> Helper loaded: cookie_helper
INFO - 2024-02-18 11:37:45 --> Database Driver Class Initialized
INFO - 2024-02-18 11:37:45 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-18 11:37:45 --> Parser Class Initialized
INFO - 2024-02-18 11:37:45 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-18 11:37:45 --> Pagination Class Initialized
INFO - 2024-02-18 11:37:45 --> Form Validation Class Initialized
INFO - 2024-02-18 11:37:45 --> Controller Class Initialized
INFO - 2024-02-18 11:37:45 --> Model Class Initialized
DEBUG - 2024-02-18 11:37:45 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-18 11:37:45 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-18 11:37:45 --> Model Class Initialized
INFO - 2024-02-18 11:37:45 --> Model Class Initialized
INFO - 2024-02-18 11:37:45 --> Final output sent to browser
DEBUG - 2024-02-18 11:37:45 --> Total execution time: 0.0194
ERROR - 2024-02-18 11:37:52 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-18 11:37:52 --> Config Class Initialized
INFO - 2024-02-18 11:37:52 --> Hooks Class Initialized
DEBUG - 2024-02-18 11:37:52 --> UTF-8 Support Enabled
INFO - 2024-02-18 11:37:52 --> Utf8 Class Initialized
INFO - 2024-02-18 11:37:52 --> URI Class Initialized
INFO - 2024-02-18 11:37:52 --> Router Class Initialized
INFO - 2024-02-18 11:37:52 --> Output Class Initialized
INFO - 2024-02-18 11:37:52 --> Security Class Initialized
DEBUG - 2024-02-18 11:37:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-18 11:37:52 --> Input Class Initialized
INFO - 2024-02-18 11:37:52 --> Language Class Initialized
INFO - 2024-02-18 11:37:52 --> Loader Class Initialized
INFO - 2024-02-18 11:37:52 --> Helper loaded: url_helper
INFO - 2024-02-18 11:37:52 --> Helper loaded: file_helper
INFO - 2024-02-18 11:37:52 --> Helper loaded: html_helper
INFO - 2024-02-18 11:37:52 --> Helper loaded: text_helper
INFO - 2024-02-18 11:37:52 --> Helper loaded: form_helper
INFO - 2024-02-18 11:37:52 --> Helper loaded: lang_helper
INFO - 2024-02-18 11:37:52 --> Helper loaded: security_helper
INFO - 2024-02-18 11:37:52 --> Helper loaded: cookie_helper
INFO - 2024-02-18 11:37:52 --> Database Driver Class Initialized
INFO - 2024-02-18 11:37:52 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-18 11:37:52 --> Parser Class Initialized
INFO - 2024-02-18 11:37:52 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-18 11:37:52 --> Pagination Class Initialized
INFO - 2024-02-18 11:37:52 --> Form Validation Class Initialized
INFO - 2024-02-18 11:37:52 --> Controller Class Initialized
INFO - 2024-02-18 11:37:52 --> Model Class Initialized
DEBUG - 2024-02-18 11:37:52 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-18 11:37:52 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-18 11:37:52 --> Model Class Initialized
DEBUG - 2024-02-18 11:37:52 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-18 11:37:52 --> Model Class Initialized
INFO - 2024-02-18 11:37:52 --> Final output sent to browser
DEBUG - 2024-02-18 11:37:52 --> Total execution time: 0.0169
ERROR - 2024-02-18 11:37:54 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-18 11:37:54 --> Config Class Initialized
INFO - 2024-02-18 11:37:54 --> Hooks Class Initialized
DEBUG - 2024-02-18 11:37:54 --> UTF-8 Support Enabled
INFO - 2024-02-18 11:37:54 --> Utf8 Class Initialized
INFO - 2024-02-18 11:37:54 --> URI Class Initialized
INFO - 2024-02-18 11:37:54 --> Router Class Initialized
INFO - 2024-02-18 11:37:54 --> Output Class Initialized
INFO - 2024-02-18 11:37:54 --> Security Class Initialized
DEBUG - 2024-02-18 11:37:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-18 11:37:54 --> Input Class Initialized
INFO - 2024-02-18 11:37:54 --> Language Class Initialized
INFO - 2024-02-18 11:37:54 --> Loader Class Initialized
INFO - 2024-02-18 11:37:54 --> Helper loaded: url_helper
INFO - 2024-02-18 11:37:54 --> Helper loaded: file_helper
INFO - 2024-02-18 11:37:54 --> Helper loaded: html_helper
INFO - 2024-02-18 11:37:54 --> Helper loaded: text_helper
INFO - 2024-02-18 11:37:54 --> Helper loaded: form_helper
INFO - 2024-02-18 11:37:54 --> Helper loaded: lang_helper
INFO - 2024-02-18 11:37:54 --> Helper loaded: security_helper
INFO - 2024-02-18 11:37:54 --> Helper loaded: cookie_helper
INFO - 2024-02-18 11:37:54 --> Database Driver Class Initialized
INFO - 2024-02-18 11:37:54 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-18 11:37:54 --> Parser Class Initialized
INFO - 2024-02-18 11:37:54 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-18 11:37:54 --> Pagination Class Initialized
INFO - 2024-02-18 11:37:54 --> Form Validation Class Initialized
INFO - 2024-02-18 11:37:54 --> Controller Class Initialized
INFO - 2024-02-18 11:37:54 --> Model Class Initialized
DEBUG - 2024-02-18 11:37:54 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-18 11:37:54 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-18 11:37:54 --> Model Class Initialized
DEBUG - 2024-02-18 11:37:54 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-18 11:37:54 --> Model Class Initialized
INFO - 2024-02-18 11:37:54 --> Final output sent to browser
DEBUG - 2024-02-18 11:37:54 --> Total execution time: 0.0212
ERROR - 2024-02-18 11:37:56 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-18 11:37:56 --> Config Class Initialized
INFO - 2024-02-18 11:37:56 --> Hooks Class Initialized
DEBUG - 2024-02-18 11:37:56 --> UTF-8 Support Enabled
INFO - 2024-02-18 11:37:56 --> Utf8 Class Initialized
INFO - 2024-02-18 11:37:56 --> URI Class Initialized
INFO - 2024-02-18 11:37:56 --> Router Class Initialized
INFO - 2024-02-18 11:37:56 --> Output Class Initialized
INFO - 2024-02-18 11:37:56 --> Security Class Initialized
DEBUG - 2024-02-18 11:37:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-18 11:37:56 --> Input Class Initialized
INFO - 2024-02-18 11:37:56 --> Language Class Initialized
INFO - 2024-02-18 11:37:56 --> Loader Class Initialized
INFO - 2024-02-18 11:37:56 --> Helper loaded: url_helper
INFO - 2024-02-18 11:37:56 --> Helper loaded: file_helper
INFO - 2024-02-18 11:37:56 --> Helper loaded: html_helper
INFO - 2024-02-18 11:37:56 --> Helper loaded: text_helper
INFO - 2024-02-18 11:37:56 --> Helper loaded: form_helper
INFO - 2024-02-18 11:37:56 --> Helper loaded: lang_helper
INFO - 2024-02-18 11:37:56 --> Helper loaded: security_helper
INFO - 2024-02-18 11:37:56 --> Helper loaded: cookie_helper
INFO - 2024-02-18 11:37:56 --> Database Driver Class Initialized
INFO - 2024-02-18 11:37:56 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-18 11:37:56 --> Parser Class Initialized
INFO - 2024-02-18 11:37:56 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-18 11:37:56 --> Pagination Class Initialized
INFO - 2024-02-18 11:37:56 --> Form Validation Class Initialized
INFO - 2024-02-18 11:37:56 --> Controller Class Initialized
INFO - 2024-02-18 11:37:56 --> Model Class Initialized
DEBUG - 2024-02-18 11:37:56 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-18 11:37:56 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-18 11:37:56 --> Model Class Initialized
DEBUG - 2024-02-18 11:37:56 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-18 11:37:56 --> Model Class Initialized
INFO - 2024-02-18 11:37:56 --> Final output sent to browser
DEBUG - 2024-02-18 11:37:56 --> Total execution time: 0.0181
ERROR - 2024-02-18 11:37:57 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-18 11:37:57 --> Config Class Initialized
INFO - 2024-02-18 11:37:57 --> Hooks Class Initialized
DEBUG - 2024-02-18 11:37:57 --> UTF-8 Support Enabled
INFO - 2024-02-18 11:37:57 --> Utf8 Class Initialized
INFO - 2024-02-18 11:37:57 --> URI Class Initialized
INFO - 2024-02-18 11:37:57 --> Router Class Initialized
INFO - 2024-02-18 11:37:57 --> Output Class Initialized
INFO - 2024-02-18 11:37:57 --> Security Class Initialized
DEBUG - 2024-02-18 11:37:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-18 11:37:57 --> Input Class Initialized
INFO - 2024-02-18 11:37:57 --> Language Class Initialized
INFO - 2024-02-18 11:37:57 --> Loader Class Initialized
INFO - 2024-02-18 11:37:57 --> Helper loaded: url_helper
INFO - 2024-02-18 11:37:57 --> Helper loaded: file_helper
INFO - 2024-02-18 11:37:57 --> Helper loaded: html_helper
INFO - 2024-02-18 11:37:57 --> Helper loaded: text_helper
INFO - 2024-02-18 11:37:57 --> Helper loaded: form_helper
INFO - 2024-02-18 11:37:57 --> Helper loaded: lang_helper
INFO - 2024-02-18 11:37:57 --> Helper loaded: security_helper
INFO - 2024-02-18 11:37:57 --> Helper loaded: cookie_helper
INFO - 2024-02-18 11:37:57 --> Database Driver Class Initialized
INFO - 2024-02-18 11:37:57 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-18 11:37:57 --> Parser Class Initialized
INFO - 2024-02-18 11:37:57 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-18 11:37:57 --> Pagination Class Initialized
INFO - 2024-02-18 11:37:57 --> Form Validation Class Initialized
INFO - 2024-02-18 11:37:57 --> Controller Class Initialized
INFO - 2024-02-18 11:37:57 --> Model Class Initialized
DEBUG - 2024-02-18 11:37:57 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-18 11:37:57 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-18 11:37:57 --> Model Class Initialized
DEBUG - 2024-02-18 11:37:57 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-18 11:37:57 --> Model Class Initialized
INFO - 2024-02-18 11:37:57 --> Final output sent to browser
DEBUG - 2024-02-18 11:37:57 --> Total execution time: 0.0182
ERROR - 2024-02-18 11:37:58 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-18 11:37:58 --> Config Class Initialized
INFO - 2024-02-18 11:37:58 --> Hooks Class Initialized
DEBUG - 2024-02-18 11:37:58 --> UTF-8 Support Enabled
INFO - 2024-02-18 11:37:58 --> Utf8 Class Initialized
INFO - 2024-02-18 11:37:58 --> URI Class Initialized
INFO - 2024-02-18 11:37:58 --> Router Class Initialized
INFO - 2024-02-18 11:37:58 --> Output Class Initialized
INFO - 2024-02-18 11:37:58 --> Security Class Initialized
DEBUG - 2024-02-18 11:37:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-18 11:37:58 --> Input Class Initialized
INFO - 2024-02-18 11:37:58 --> Language Class Initialized
INFO - 2024-02-18 11:37:58 --> Loader Class Initialized
INFO - 2024-02-18 11:37:58 --> Helper loaded: url_helper
INFO - 2024-02-18 11:37:58 --> Helper loaded: file_helper
INFO - 2024-02-18 11:37:58 --> Helper loaded: html_helper
INFO - 2024-02-18 11:37:58 --> Helper loaded: text_helper
INFO - 2024-02-18 11:37:58 --> Helper loaded: form_helper
INFO - 2024-02-18 11:37:58 --> Helper loaded: lang_helper
INFO - 2024-02-18 11:37:58 --> Helper loaded: security_helper
INFO - 2024-02-18 11:37:58 --> Helper loaded: cookie_helper
INFO - 2024-02-18 11:37:58 --> Database Driver Class Initialized
INFO - 2024-02-18 11:37:58 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-18 11:37:58 --> Parser Class Initialized
INFO - 2024-02-18 11:37:58 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-18 11:37:58 --> Pagination Class Initialized
INFO - 2024-02-18 11:37:58 --> Form Validation Class Initialized
INFO - 2024-02-18 11:37:58 --> Controller Class Initialized
INFO - 2024-02-18 11:37:58 --> Model Class Initialized
DEBUG - 2024-02-18 11:37:58 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-18 11:37:58 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-18 11:37:58 --> Model Class Initialized
DEBUG - 2024-02-18 11:37:58 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-18 11:37:58 --> Model Class Initialized
INFO - 2024-02-18 11:37:58 --> Final output sent to browser
DEBUG - 2024-02-18 11:37:58 --> Total execution time: 0.0170
ERROR - 2024-02-18 11:38:00 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-18 11:38:00 --> Config Class Initialized
INFO - 2024-02-18 11:38:00 --> Hooks Class Initialized
DEBUG - 2024-02-18 11:38:00 --> UTF-8 Support Enabled
INFO - 2024-02-18 11:38:00 --> Utf8 Class Initialized
INFO - 2024-02-18 11:38:00 --> URI Class Initialized
INFO - 2024-02-18 11:38:00 --> Router Class Initialized
INFO - 2024-02-18 11:38:00 --> Output Class Initialized
INFO - 2024-02-18 11:38:00 --> Security Class Initialized
DEBUG - 2024-02-18 11:38:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-18 11:38:00 --> Input Class Initialized
INFO - 2024-02-18 11:38:00 --> Language Class Initialized
INFO - 2024-02-18 11:38:00 --> Loader Class Initialized
INFO - 2024-02-18 11:38:00 --> Helper loaded: url_helper
INFO - 2024-02-18 11:38:00 --> Helper loaded: file_helper
INFO - 2024-02-18 11:38:00 --> Helper loaded: html_helper
INFO - 2024-02-18 11:38:00 --> Helper loaded: text_helper
INFO - 2024-02-18 11:38:00 --> Helper loaded: form_helper
INFO - 2024-02-18 11:38:00 --> Helper loaded: lang_helper
INFO - 2024-02-18 11:38:00 --> Helper loaded: security_helper
INFO - 2024-02-18 11:38:00 --> Helper loaded: cookie_helper
INFO - 2024-02-18 11:38:00 --> Database Driver Class Initialized
INFO - 2024-02-18 11:38:00 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-18 11:38:00 --> Parser Class Initialized
INFO - 2024-02-18 11:38:00 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-18 11:38:00 --> Pagination Class Initialized
INFO - 2024-02-18 11:38:00 --> Form Validation Class Initialized
INFO - 2024-02-18 11:38:00 --> Controller Class Initialized
INFO - 2024-02-18 11:38:00 --> Model Class Initialized
DEBUG - 2024-02-18 11:38:00 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-18 11:38:00 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-18 11:38:00 --> Model Class Initialized
DEBUG - 2024-02-18 11:38:00 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-18 11:38:00 --> Model Class Initialized
INFO - 2024-02-18 11:38:00 --> Final output sent to browser
DEBUG - 2024-02-18 11:38:00 --> Total execution time: 0.0183
ERROR - 2024-02-18 11:38:01 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-18 11:38:01 --> Config Class Initialized
INFO - 2024-02-18 11:38:01 --> Hooks Class Initialized
DEBUG - 2024-02-18 11:38:01 --> UTF-8 Support Enabled
INFO - 2024-02-18 11:38:01 --> Utf8 Class Initialized
INFO - 2024-02-18 11:38:01 --> URI Class Initialized
INFO - 2024-02-18 11:38:01 --> Router Class Initialized
INFO - 2024-02-18 11:38:01 --> Output Class Initialized
INFO - 2024-02-18 11:38:01 --> Security Class Initialized
DEBUG - 2024-02-18 11:38:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-18 11:38:01 --> Input Class Initialized
INFO - 2024-02-18 11:38:01 --> Language Class Initialized
INFO - 2024-02-18 11:38:01 --> Loader Class Initialized
INFO - 2024-02-18 11:38:01 --> Helper loaded: url_helper
INFO - 2024-02-18 11:38:01 --> Helper loaded: file_helper
INFO - 2024-02-18 11:38:01 --> Helper loaded: html_helper
INFO - 2024-02-18 11:38:01 --> Helper loaded: text_helper
INFO - 2024-02-18 11:38:01 --> Helper loaded: form_helper
INFO - 2024-02-18 11:38:01 --> Helper loaded: lang_helper
INFO - 2024-02-18 11:38:01 --> Helper loaded: security_helper
INFO - 2024-02-18 11:38:01 --> Helper loaded: cookie_helper
INFO - 2024-02-18 11:38:01 --> Database Driver Class Initialized
INFO - 2024-02-18 11:38:01 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-18 11:38:01 --> Parser Class Initialized
INFO - 2024-02-18 11:38:01 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-18 11:38:01 --> Pagination Class Initialized
INFO - 2024-02-18 11:38:01 --> Form Validation Class Initialized
INFO - 2024-02-18 11:38:01 --> Controller Class Initialized
INFO - 2024-02-18 11:38:01 --> Model Class Initialized
DEBUG - 2024-02-18 11:38:01 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-18 11:38:01 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-18 11:38:01 --> Model Class Initialized
DEBUG - 2024-02-18 11:38:01 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-18 11:38:01 --> Model Class Initialized
INFO - 2024-02-18 11:38:01 --> Final output sent to browser
DEBUG - 2024-02-18 11:38:01 --> Total execution time: 0.0976
ERROR - 2024-02-18 11:38:04 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-18 11:38:04 --> Config Class Initialized
INFO - 2024-02-18 11:38:04 --> Hooks Class Initialized
DEBUG - 2024-02-18 11:38:04 --> UTF-8 Support Enabled
INFO - 2024-02-18 11:38:04 --> Utf8 Class Initialized
INFO - 2024-02-18 11:38:04 --> URI Class Initialized
INFO - 2024-02-18 11:38:04 --> Router Class Initialized
INFO - 2024-02-18 11:38:04 --> Output Class Initialized
INFO - 2024-02-18 11:38:04 --> Security Class Initialized
DEBUG - 2024-02-18 11:38:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-18 11:38:04 --> Input Class Initialized
INFO - 2024-02-18 11:38:04 --> Language Class Initialized
INFO - 2024-02-18 11:38:04 --> Loader Class Initialized
INFO - 2024-02-18 11:38:04 --> Helper loaded: url_helper
INFO - 2024-02-18 11:38:04 --> Helper loaded: file_helper
INFO - 2024-02-18 11:38:04 --> Helper loaded: html_helper
INFO - 2024-02-18 11:38:04 --> Helper loaded: text_helper
INFO - 2024-02-18 11:38:04 --> Helper loaded: form_helper
INFO - 2024-02-18 11:38:04 --> Helper loaded: lang_helper
INFO - 2024-02-18 11:38:04 --> Helper loaded: security_helper
INFO - 2024-02-18 11:38:04 --> Helper loaded: cookie_helper
INFO - 2024-02-18 11:38:04 --> Database Driver Class Initialized
INFO - 2024-02-18 11:38:04 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-18 11:38:04 --> Parser Class Initialized
INFO - 2024-02-18 11:38:04 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-18 11:38:04 --> Pagination Class Initialized
INFO - 2024-02-18 11:38:04 --> Form Validation Class Initialized
INFO - 2024-02-18 11:38:04 --> Controller Class Initialized
INFO - 2024-02-18 11:38:04 --> Model Class Initialized
DEBUG - 2024-02-18 11:38:04 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-18 11:38:04 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-18 11:38:04 --> Model Class Initialized
INFO - 2024-02-18 11:38:04 --> Model Class Initialized
INFO - 2024-02-18 11:38:04 --> Final output sent to browser
DEBUG - 2024-02-18 11:38:04 --> Total execution time: 0.0219
ERROR - 2024-02-18 11:38:07 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-18 11:38:07 --> Config Class Initialized
INFO - 2024-02-18 11:38:07 --> Hooks Class Initialized
DEBUG - 2024-02-18 11:38:07 --> UTF-8 Support Enabled
INFO - 2024-02-18 11:38:07 --> Utf8 Class Initialized
INFO - 2024-02-18 11:38:07 --> URI Class Initialized
INFO - 2024-02-18 11:38:07 --> Router Class Initialized
INFO - 2024-02-18 11:38:07 --> Output Class Initialized
INFO - 2024-02-18 11:38:07 --> Security Class Initialized
DEBUG - 2024-02-18 11:38:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-18 11:38:07 --> Input Class Initialized
INFO - 2024-02-18 11:38:07 --> Language Class Initialized
INFO - 2024-02-18 11:38:07 --> Loader Class Initialized
INFO - 2024-02-18 11:38:07 --> Helper loaded: url_helper
INFO - 2024-02-18 11:38:07 --> Helper loaded: file_helper
INFO - 2024-02-18 11:38:07 --> Helper loaded: html_helper
INFO - 2024-02-18 11:38:07 --> Helper loaded: text_helper
INFO - 2024-02-18 11:38:07 --> Helper loaded: form_helper
INFO - 2024-02-18 11:38:07 --> Helper loaded: lang_helper
INFO - 2024-02-18 11:38:07 --> Helper loaded: security_helper
INFO - 2024-02-18 11:38:07 --> Helper loaded: cookie_helper
INFO - 2024-02-18 11:38:07 --> Database Driver Class Initialized
INFO - 2024-02-18 11:38:07 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-18 11:38:07 --> Parser Class Initialized
INFO - 2024-02-18 11:38:07 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-18 11:38:07 --> Pagination Class Initialized
INFO - 2024-02-18 11:38:07 --> Form Validation Class Initialized
INFO - 2024-02-18 11:38:07 --> Controller Class Initialized
INFO - 2024-02-18 11:38:07 --> Model Class Initialized
DEBUG - 2024-02-18 11:38:07 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-18 11:38:07 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-18 11:38:07 --> Model Class Initialized
INFO - 2024-02-18 11:38:07 --> Final output sent to browser
DEBUG - 2024-02-18 11:38:07 --> Total execution time: 0.0182
ERROR - 2024-02-18 11:38:16 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-18 11:38:16 --> Config Class Initialized
INFO - 2024-02-18 11:38:16 --> Hooks Class Initialized
DEBUG - 2024-02-18 11:38:16 --> UTF-8 Support Enabled
INFO - 2024-02-18 11:38:16 --> Utf8 Class Initialized
INFO - 2024-02-18 11:38:16 --> URI Class Initialized
INFO - 2024-02-18 11:38:16 --> Router Class Initialized
INFO - 2024-02-18 11:38:16 --> Output Class Initialized
INFO - 2024-02-18 11:38:16 --> Security Class Initialized
DEBUG - 2024-02-18 11:38:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-18 11:38:16 --> Input Class Initialized
INFO - 2024-02-18 11:38:16 --> Language Class Initialized
INFO - 2024-02-18 11:38:16 --> Loader Class Initialized
INFO - 2024-02-18 11:38:16 --> Helper loaded: url_helper
INFO - 2024-02-18 11:38:16 --> Helper loaded: file_helper
INFO - 2024-02-18 11:38:16 --> Helper loaded: html_helper
INFO - 2024-02-18 11:38:16 --> Helper loaded: text_helper
INFO - 2024-02-18 11:38:16 --> Helper loaded: form_helper
INFO - 2024-02-18 11:38:16 --> Helper loaded: lang_helper
INFO - 2024-02-18 11:38:16 --> Helper loaded: security_helper
INFO - 2024-02-18 11:38:16 --> Helper loaded: cookie_helper
INFO - 2024-02-18 11:38:16 --> Database Driver Class Initialized
INFO - 2024-02-18 11:38:16 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-18 11:38:16 --> Parser Class Initialized
INFO - 2024-02-18 11:38:16 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-18 11:38:16 --> Pagination Class Initialized
INFO - 2024-02-18 11:38:16 --> Form Validation Class Initialized
INFO - 2024-02-18 11:38:16 --> Controller Class Initialized
INFO - 2024-02-18 11:38:16 --> Model Class Initialized
DEBUG - 2024-02-18 11:38:16 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-18 11:38:16 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-18 11:38:16 --> Model Class Initialized
DEBUG - 2024-02-18 11:38:16 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-18 11:38:16 --> Model Class Initialized
INFO - 2024-02-18 11:38:16 --> Final output sent to browser
DEBUG - 2024-02-18 11:38:16 --> Total execution time: 0.0953
ERROR - 2024-02-18 11:38:17 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-18 11:38:17 --> Config Class Initialized
INFO - 2024-02-18 11:38:17 --> Hooks Class Initialized
DEBUG - 2024-02-18 11:38:17 --> UTF-8 Support Enabled
INFO - 2024-02-18 11:38:17 --> Utf8 Class Initialized
INFO - 2024-02-18 11:38:17 --> URI Class Initialized
INFO - 2024-02-18 11:38:17 --> Router Class Initialized
INFO - 2024-02-18 11:38:17 --> Output Class Initialized
INFO - 2024-02-18 11:38:17 --> Security Class Initialized
DEBUG - 2024-02-18 11:38:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-18 11:38:17 --> Input Class Initialized
INFO - 2024-02-18 11:38:17 --> Language Class Initialized
INFO - 2024-02-18 11:38:17 --> Loader Class Initialized
INFO - 2024-02-18 11:38:17 --> Helper loaded: url_helper
INFO - 2024-02-18 11:38:17 --> Helper loaded: file_helper
INFO - 2024-02-18 11:38:17 --> Helper loaded: html_helper
INFO - 2024-02-18 11:38:17 --> Helper loaded: text_helper
INFO - 2024-02-18 11:38:17 --> Helper loaded: form_helper
INFO - 2024-02-18 11:38:17 --> Helper loaded: lang_helper
INFO - 2024-02-18 11:38:17 --> Helper loaded: security_helper
INFO - 2024-02-18 11:38:17 --> Helper loaded: cookie_helper
INFO - 2024-02-18 11:38:17 --> Database Driver Class Initialized
INFO - 2024-02-18 11:38:17 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-18 11:38:17 --> Parser Class Initialized
INFO - 2024-02-18 11:38:17 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-18 11:38:17 --> Pagination Class Initialized
INFO - 2024-02-18 11:38:17 --> Form Validation Class Initialized
INFO - 2024-02-18 11:38:17 --> Controller Class Initialized
INFO - 2024-02-18 11:38:17 --> Model Class Initialized
DEBUG - 2024-02-18 11:38:17 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-18 11:38:17 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-18 11:38:17 --> Model Class Initialized
DEBUG - 2024-02-18 11:38:17 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-18 11:38:17 --> Model Class Initialized
INFO - 2024-02-18 11:38:17 --> Final output sent to browser
DEBUG - 2024-02-18 11:38:17 --> Total execution time: 0.0965
ERROR - 2024-02-18 11:38:17 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-18 11:38:17 --> Config Class Initialized
INFO - 2024-02-18 11:38:17 --> Hooks Class Initialized
DEBUG - 2024-02-18 11:38:17 --> UTF-8 Support Enabled
INFO - 2024-02-18 11:38:17 --> Utf8 Class Initialized
INFO - 2024-02-18 11:38:17 --> URI Class Initialized
INFO - 2024-02-18 11:38:17 --> Router Class Initialized
INFO - 2024-02-18 11:38:17 --> Output Class Initialized
INFO - 2024-02-18 11:38:17 --> Security Class Initialized
DEBUG - 2024-02-18 11:38:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-18 11:38:17 --> Input Class Initialized
INFO - 2024-02-18 11:38:17 --> Language Class Initialized
INFO - 2024-02-18 11:38:17 --> Loader Class Initialized
INFO - 2024-02-18 11:38:17 --> Helper loaded: url_helper
INFO - 2024-02-18 11:38:17 --> Helper loaded: file_helper
INFO - 2024-02-18 11:38:17 --> Helper loaded: html_helper
INFO - 2024-02-18 11:38:17 --> Helper loaded: text_helper
INFO - 2024-02-18 11:38:17 --> Helper loaded: form_helper
INFO - 2024-02-18 11:38:17 --> Helper loaded: lang_helper
INFO - 2024-02-18 11:38:17 --> Helper loaded: security_helper
INFO - 2024-02-18 11:38:17 --> Helper loaded: cookie_helper
INFO - 2024-02-18 11:38:17 --> Database Driver Class Initialized
INFO - 2024-02-18 11:38:17 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-18 11:38:17 --> Parser Class Initialized
INFO - 2024-02-18 11:38:17 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-18 11:38:17 --> Pagination Class Initialized
INFO - 2024-02-18 11:38:17 --> Form Validation Class Initialized
INFO - 2024-02-18 11:38:17 --> Controller Class Initialized
INFO - 2024-02-18 11:38:17 --> Model Class Initialized
DEBUG - 2024-02-18 11:38:17 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-18 11:38:17 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-18 11:38:17 --> Model Class Initialized
DEBUG - 2024-02-18 11:38:17 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-18 11:38:17 --> Model Class Initialized
INFO - 2024-02-18 11:38:17 --> Final output sent to browser
DEBUG - 2024-02-18 11:38:17 --> Total execution time: 0.0943
ERROR - 2024-02-18 11:38:18 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-18 11:38:18 --> Config Class Initialized
INFO - 2024-02-18 11:38:18 --> Hooks Class Initialized
DEBUG - 2024-02-18 11:38:18 --> UTF-8 Support Enabled
INFO - 2024-02-18 11:38:18 --> Utf8 Class Initialized
INFO - 2024-02-18 11:38:18 --> URI Class Initialized
INFO - 2024-02-18 11:38:18 --> Router Class Initialized
INFO - 2024-02-18 11:38:18 --> Output Class Initialized
INFO - 2024-02-18 11:38:18 --> Security Class Initialized
DEBUG - 2024-02-18 11:38:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-18 11:38:18 --> Input Class Initialized
INFO - 2024-02-18 11:38:18 --> Language Class Initialized
INFO - 2024-02-18 11:38:18 --> Loader Class Initialized
INFO - 2024-02-18 11:38:18 --> Helper loaded: url_helper
INFO - 2024-02-18 11:38:18 --> Helper loaded: file_helper
INFO - 2024-02-18 11:38:18 --> Helper loaded: html_helper
INFO - 2024-02-18 11:38:18 --> Helper loaded: text_helper
INFO - 2024-02-18 11:38:18 --> Helper loaded: form_helper
INFO - 2024-02-18 11:38:18 --> Helper loaded: lang_helper
INFO - 2024-02-18 11:38:18 --> Helper loaded: security_helper
INFO - 2024-02-18 11:38:18 --> Helper loaded: cookie_helper
INFO - 2024-02-18 11:38:18 --> Database Driver Class Initialized
INFO - 2024-02-18 11:38:18 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-18 11:38:18 --> Parser Class Initialized
INFO - 2024-02-18 11:38:18 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-18 11:38:18 --> Pagination Class Initialized
INFO - 2024-02-18 11:38:18 --> Form Validation Class Initialized
INFO - 2024-02-18 11:38:18 --> Controller Class Initialized
INFO - 2024-02-18 11:38:18 --> Model Class Initialized
DEBUG - 2024-02-18 11:38:18 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-18 11:38:18 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-18 11:38:18 --> Model Class Initialized
DEBUG - 2024-02-18 11:38:18 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-18 11:38:18 --> Model Class Initialized
INFO - 2024-02-18 11:38:18 --> Final output sent to browser
DEBUG - 2024-02-18 11:38:18 --> Total execution time: 0.1027
ERROR - 2024-02-18 11:38:24 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-18 11:38:24 --> Config Class Initialized
INFO - 2024-02-18 11:38:24 --> Hooks Class Initialized
DEBUG - 2024-02-18 11:38:24 --> UTF-8 Support Enabled
INFO - 2024-02-18 11:38:24 --> Utf8 Class Initialized
INFO - 2024-02-18 11:38:24 --> URI Class Initialized
INFO - 2024-02-18 11:38:24 --> Router Class Initialized
INFO - 2024-02-18 11:38:24 --> Output Class Initialized
INFO - 2024-02-18 11:38:24 --> Security Class Initialized
DEBUG - 2024-02-18 11:38:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-18 11:38:24 --> Input Class Initialized
INFO - 2024-02-18 11:38:24 --> Language Class Initialized
INFO - 2024-02-18 11:38:24 --> Loader Class Initialized
INFO - 2024-02-18 11:38:24 --> Helper loaded: url_helper
INFO - 2024-02-18 11:38:24 --> Helper loaded: file_helper
INFO - 2024-02-18 11:38:24 --> Helper loaded: html_helper
INFO - 2024-02-18 11:38:24 --> Helper loaded: text_helper
INFO - 2024-02-18 11:38:24 --> Helper loaded: form_helper
INFO - 2024-02-18 11:38:24 --> Helper loaded: lang_helper
INFO - 2024-02-18 11:38:24 --> Helper loaded: security_helper
INFO - 2024-02-18 11:38:24 --> Helper loaded: cookie_helper
INFO - 2024-02-18 11:38:24 --> Database Driver Class Initialized
INFO - 2024-02-18 11:38:24 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-18 11:38:24 --> Parser Class Initialized
INFO - 2024-02-18 11:38:24 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-18 11:38:24 --> Pagination Class Initialized
INFO - 2024-02-18 11:38:24 --> Form Validation Class Initialized
INFO - 2024-02-18 11:38:24 --> Controller Class Initialized
INFO - 2024-02-18 11:38:24 --> Model Class Initialized
DEBUG - 2024-02-18 11:38:24 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-18 11:38:24 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-18 11:38:24 --> Model Class Initialized
DEBUG - 2024-02-18 11:38:24 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-18 11:38:24 --> Model Class Initialized
INFO - 2024-02-18 11:38:24 --> Final output sent to browser
DEBUG - 2024-02-18 11:38:24 --> Total execution time: 0.0243
ERROR - 2024-02-18 11:38:24 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-18 11:38:24 --> Config Class Initialized
INFO - 2024-02-18 11:38:24 --> Hooks Class Initialized
DEBUG - 2024-02-18 11:38:24 --> UTF-8 Support Enabled
INFO - 2024-02-18 11:38:24 --> Utf8 Class Initialized
INFO - 2024-02-18 11:38:24 --> URI Class Initialized
INFO - 2024-02-18 11:38:24 --> Router Class Initialized
INFO - 2024-02-18 11:38:24 --> Output Class Initialized
INFO - 2024-02-18 11:38:24 --> Security Class Initialized
DEBUG - 2024-02-18 11:38:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-18 11:38:24 --> Input Class Initialized
INFO - 2024-02-18 11:38:24 --> Language Class Initialized
INFO - 2024-02-18 11:38:24 --> Loader Class Initialized
INFO - 2024-02-18 11:38:24 --> Helper loaded: url_helper
INFO - 2024-02-18 11:38:24 --> Helper loaded: file_helper
INFO - 2024-02-18 11:38:24 --> Helper loaded: html_helper
INFO - 2024-02-18 11:38:24 --> Helper loaded: text_helper
INFO - 2024-02-18 11:38:24 --> Helper loaded: form_helper
INFO - 2024-02-18 11:38:24 --> Helper loaded: lang_helper
INFO - 2024-02-18 11:38:24 --> Helper loaded: security_helper
INFO - 2024-02-18 11:38:24 --> Helper loaded: cookie_helper
INFO - 2024-02-18 11:38:24 --> Database Driver Class Initialized
INFO - 2024-02-18 11:38:24 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-18 11:38:24 --> Parser Class Initialized
INFO - 2024-02-18 11:38:24 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-18 11:38:24 --> Pagination Class Initialized
INFO - 2024-02-18 11:38:24 --> Form Validation Class Initialized
INFO - 2024-02-18 11:38:24 --> Controller Class Initialized
INFO - 2024-02-18 11:38:24 --> Model Class Initialized
DEBUG - 2024-02-18 11:38:24 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-18 11:38:24 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-18 11:38:24 --> Model Class Initialized
DEBUG - 2024-02-18 11:38:24 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-18 11:38:24 --> Model Class Initialized
INFO - 2024-02-18 11:38:24 --> Final output sent to browser
DEBUG - 2024-02-18 11:38:24 --> Total execution time: 0.0233
ERROR - 2024-02-18 11:38:26 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-18 11:38:26 --> Config Class Initialized
INFO - 2024-02-18 11:38:26 --> Hooks Class Initialized
DEBUG - 2024-02-18 11:38:26 --> UTF-8 Support Enabled
INFO - 2024-02-18 11:38:26 --> Utf8 Class Initialized
INFO - 2024-02-18 11:38:26 --> URI Class Initialized
INFO - 2024-02-18 11:38:26 --> Router Class Initialized
INFO - 2024-02-18 11:38:26 --> Output Class Initialized
INFO - 2024-02-18 11:38:26 --> Security Class Initialized
DEBUG - 2024-02-18 11:38:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-18 11:38:26 --> Input Class Initialized
INFO - 2024-02-18 11:38:26 --> Language Class Initialized
INFO - 2024-02-18 11:38:26 --> Loader Class Initialized
INFO - 2024-02-18 11:38:26 --> Helper loaded: url_helper
INFO - 2024-02-18 11:38:26 --> Helper loaded: file_helper
INFO - 2024-02-18 11:38:26 --> Helper loaded: html_helper
INFO - 2024-02-18 11:38:26 --> Helper loaded: text_helper
INFO - 2024-02-18 11:38:26 --> Helper loaded: form_helper
INFO - 2024-02-18 11:38:26 --> Helper loaded: lang_helper
INFO - 2024-02-18 11:38:26 --> Helper loaded: security_helper
INFO - 2024-02-18 11:38:26 --> Helper loaded: cookie_helper
INFO - 2024-02-18 11:38:26 --> Database Driver Class Initialized
INFO - 2024-02-18 11:38:26 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-18 11:38:26 --> Parser Class Initialized
INFO - 2024-02-18 11:38:26 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-18 11:38:26 --> Pagination Class Initialized
INFO - 2024-02-18 11:38:26 --> Form Validation Class Initialized
INFO - 2024-02-18 11:38:26 --> Controller Class Initialized
INFO - 2024-02-18 11:38:26 --> Model Class Initialized
DEBUG - 2024-02-18 11:38:26 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-18 11:38:26 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-18 11:38:26 --> Model Class Initialized
INFO - 2024-02-18 11:38:26 --> Model Class Initialized
INFO - 2024-02-18 11:38:26 --> Final output sent to browser
DEBUG - 2024-02-18 11:38:26 --> Total execution time: 0.0191
ERROR - 2024-02-18 11:38:28 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-18 11:38:28 --> Config Class Initialized
INFO - 2024-02-18 11:38:28 --> Hooks Class Initialized
DEBUG - 2024-02-18 11:38:28 --> UTF-8 Support Enabled
INFO - 2024-02-18 11:38:28 --> Utf8 Class Initialized
INFO - 2024-02-18 11:38:28 --> URI Class Initialized
INFO - 2024-02-18 11:38:28 --> Router Class Initialized
INFO - 2024-02-18 11:38:28 --> Output Class Initialized
INFO - 2024-02-18 11:38:28 --> Security Class Initialized
DEBUG - 2024-02-18 11:38:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-18 11:38:28 --> Input Class Initialized
INFO - 2024-02-18 11:38:28 --> Language Class Initialized
INFO - 2024-02-18 11:38:28 --> Loader Class Initialized
INFO - 2024-02-18 11:38:28 --> Helper loaded: url_helper
INFO - 2024-02-18 11:38:28 --> Helper loaded: file_helper
INFO - 2024-02-18 11:38:28 --> Helper loaded: html_helper
INFO - 2024-02-18 11:38:28 --> Helper loaded: text_helper
INFO - 2024-02-18 11:38:28 --> Helper loaded: form_helper
INFO - 2024-02-18 11:38:28 --> Helper loaded: lang_helper
INFO - 2024-02-18 11:38:28 --> Helper loaded: security_helper
INFO - 2024-02-18 11:38:28 --> Helper loaded: cookie_helper
INFO - 2024-02-18 11:38:28 --> Database Driver Class Initialized
INFO - 2024-02-18 11:38:28 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-18 11:38:28 --> Parser Class Initialized
INFO - 2024-02-18 11:38:28 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-18 11:38:28 --> Pagination Class Initialized
INFO - 2024-02-18 11:38:28 --> Form Validation Class Initialized
INFO - 2024-02-18 11:38:28 --> Controller Class Initialized
INFO - 2024-02-18 11:38:28 --> Model Class Initialized
DEBUG - 2024-02-18 11:38:28 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-18 11:38:28 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-18 11:38:28 --> Model Class Initialized
INFO - 2024-02-18 11:38:28 --> Final output sent to browser
DEBUG - 2024-02-18 11:38:28 --> Total execution time: 0.0212
ERROR - 2024-02-18 11:38:42 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-18 11:38:42 --> Config Class Initialized
INFO - 2024-02-18 11:38:42 --> Hooks Class Initialized
DEBUG - 2024-02-18 11:38:42 --> UTF-8 Support Enabled
INFO - 2024-02-18 11:38:42 --> Utf8 Class Initialized
INFO - 2024-02-18 11:38:42 --> URI Class Initialized
INFO - 2024-02-18 11:38:42 --> Router Class Initialized
INFO - 2024-02-18 11:38:42 --> Output Class Initialized
INFO - 2024-02-18 11:38:42 --> Security Class Initialized
DEBUG - 2024-02-18 11:38:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-18 11:38:42 --> Input Class Initialized
INFO - 2024-02-18 11:38:42 --> Language Class Initialized
INFO - 2024-02-18 11:38:42 --> Loader Class Initialized
INFO - 2024-02-18 11:38:42 --> Helper loaded: url_helper
INFO - 2024-02-18 11:38:42 --> Helper loaded: file_helper
INFO - 2024-02-18 11:38:42 --> Helper loaded: html_helper
INFO - 2024-02-18 11:38:42 --> Helper loaded: text_helper
INFO - 2024-02-18 11:38:42 --> Helper loaded: form_helper
INFO - 2024-02-18 11:38:42 --> Helper loaded: lang_helper
INFO - 2024-02-18 11:38:42 --> Helper loaded: security_helper
INFO - 2024-02-18 11:38:42 --> Helper loaded: cookie_helper
INFO - 2024-02-18 11:38:42 --> Database Driver Class Initialized
INFO - 2024-02-18 11:38:42 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-18 11:38:42 --> Parser Class Initialized
INFO - 2024-02-18 11:38:42 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-18 11:38:42 --> Pagination Class Initialized
INFO - 2024-02-18 11:38:42 --> Form Validation Class Initialized
INFO - 2024-02-18 11:38:42 --> Controller Class Initialized
INFO - 2024-02-18 11:38:42 --> Model Class Initialized
DEBUG - 2024-02-18 11:38:42 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-18 11:38:42 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-18 11:38:42 --> Model Class Initialized
DEBUG - 2024-02-18 11:38:42 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-18 11:38:42 --> Model Class Initialized
INFO - 2024-02-18 11:38:42 --> Final output sent to browser
DEBUG - 2024-02-18 11:38:42 --> Total execution time: 0.0993
ERROR - 2024-02-18 11:38:43 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-18 11:38:43 --> Config Class Initialized
INFO - 2024-02-18 11:38:43 --> Hooks Class Initialized
DEBUG - 2024-02-18 11:38:43 --> UTF-8 Support Enabled
INFO - 2024-02-18 11:38:43 --> Utf8 Class Initialized
INFO - 2024-02-18 11:38:43 --> URI Class Initialized
INFO - 2024-02-18 11:38:43 --> Router Class Initialized
INFO - 2024-02-18 11:38:43 --> Output Class Initialized
INFO - 2024-02-18 11:38:43 --> Security Class Initialized
DEBUG - 2024-02-18 11:38:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-18 11:38:43 --> Input Class Initialized
INFO - 2024-02-18 11:38:43 --> Language Class Initialized
INFO - 2024-02-18 11:38:43 --> Loader Class Initialized
INFO - 2024-02-18 11:38:43 --> Helper loaded: url_helper
INFO - 2024-02-18 11:38:43 --> Helper loaded: file_helper
INFO - 2024-02-18 11:38:43 --> Helper loaded: html_helper
INFO - 2024-02-18 11:38:43 --> Helper loaded: text_helper
INFO - 2024-02-18 11:38:43 --> Helper loaded: form_helper
INFO - 2024-02-18 11:38:43 --> Helper loaded: lang_helper
INFO - 2024-02-18 11:38:43 --> Helper loaded: security_helper
INFO - 2024-02-18 11:38:43 --> Helper loaded: cookie_helper
INFO - 2024-02-18 11:38:43 --> Database Driver Class Initialized
INFO - 2024-02-18 11:38:43 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-18 11:38:43 --> Parser Class Initialized
INFO - 2024-02-18 11:38:43 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-18 11:38:43 --> Pagination Class Initialized
INFO - 2024-02-18 11:38:43 --> Form Validation Class Initialized
INFO - 2024-02-18 11:38:43 --> Controller Class Initialized
INFO - 2024-02-18 11:38:43 --> Model Class Initialized
DEBUG - 2024-02-18 11:38:43 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-18 11:38:43 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-18 11:38:43 --> Model Class Initialized
DEBUG - 2024-02-18 11:38:43 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-18 11:38:43 --> Model Class Initialized
INFO - 2024-02-18 11:38:43 --> Final output sent to browser
DEBUG - 2024-02-18 11:38:43 --> Total execution time: 0.0929
ERROR - 2024-02-18 11:38:43 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-18 11:38:43 --> Config Class Initialized
INFO - 2024-02-18 11:38:43 --> Hooks Class Initialized
DEBUG - 2024-02-18 11:38:43 --> UTF-8 Support Enabled
INFO - 2024-02-18 11:38:43 --> Utf8 Class Initialized
INFO - 2024-02-18 11:38:43 --> URI Class Initialized
INFO - 2024-02-18 11:38:43 --> Router Class Initialized
INFO - 2024-02-18 11:38:43 --> Output Class Initialized
INFO - 2024-02-18 11:38:43 --> Security Class Initialized
DEBUG - 2024-02-18 11:38:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-18 11:38:43 --> Input Class Initialized
INFO - 2024-02-18 11:38:43 --> Language Class Initialized
INFO - 2024-02-18 11:38:43 --> Loader Class Initialized
INFO - 2024-02-18 11:38:43 --> Helper loaded: url_helper
INFO - 2024-02-18 11:38:43 --> Helper loaded: file_helper
INFO - 2024-02-18 11:38:43 --> Helper loaded: html_helper
INFO - 2024-02-18 11:38:43 --> Helper loaded: text_helper
INFO - 2024-02-18 11:38:43 --> Helper loaded: form_helper
INFO - 2024-02-18 11:38:43 --> Helper loaded: lang_helper
INFO - 2024-02-18 11:38:43 --> Helper loaded: security_helper
INFO - 2024-02-18 11:38:43 --> Helper loaded: cookie_helper
INFO - 2024-02-18 11:38:43 --> Database Driver Class Initialized
INFO - 2024-02-18 11:38:43 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-18 11:38:43 --> Parser Class Initialized
INFO - 2024-02-18 11:38:43 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-18 11:38:43 --> Pagination Class Initialized
INFO - 2024-02-18 11:38:43 --> Form Validation Class Initialized
INFO - 2024-02-18 11:38:43 --> Controller Class Initialized
INFO - 2024-02-18 11:38:43 --> Model Class Initialized
DEBUG - 2024-02-18 11:38:43 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-18 11:38:43 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-18 11:38:43 --> Model Class Initialized
DEBUG - 2024-02-18 11:38:43 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-18 11:38:43 --> Model Class Initialized
INFO - 2024-02-18 11:38:43 --> Final output sent to browser
DEBUG - 2024-02-18 11:38:43 --> Total execution time: 0.0934
ERROR - 2024-02-18 11:38:44 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-18 11:38:44 --> Config Class Initialized
INFO - 2024-02-18 11:38:44 --> Hooks Class Initialized
DEBUG - 2024-02-18 11:38:44 --> UTF-8 Support Enabled
INFO - 2024-02-18 11:38:44 --> Utf8 Class Initialized
INFO - 2024-02-18 11:38:44 --> URI Class Initialized
INFO - 2024-02-18 11:38:44 --> Router Class Initialized
INFO - 2024-02-18 11:38:44 --> Output Class Initialized
INFO - 2024-02-18 11:38:44 --> Security Class Initialized
DEBUG - 2024-02-18 11:38:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-18 11:38:44 --> Input Class Initialized
INFO - 2024-02-18 11:38:44 --> Language Class Initialized
INFO - 2024-02-18 11:38:44 --> Loader Class Initialized
INFO - 2024-02-18 11:38:44 --> Helper loaded: url_helper
INFO - 2024-02-18 11:38:44 --> Helper loaded: file_helper
INFO - 2024-02-18 11:38:44 --> Helper loaded: html_helper
INFO - 2024-02-18 11:38:44 --> Helper loaded: text_helper
INFO - 2024-02-18 11:38:44 --> Helper loaded: form_helper
INFO - 2024-02-18 11:38:44 --> Helper loaded: lang_helper
INFO - 2024-02-18 11:38:44 --> Helper loaded: security_helper
INFO - 2024-02-18 11:38:44 --> Helper loaded: cookie_helper
INFO - 2024-02-18 11:38:44 --> Database Driver Class Initialized
INFO - 2024-02-18 11:38:44 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-18 11:38:44 --> Parser Class Initialized
INFO - 2024-02-18 11:38:44 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-18 11:38:44 --> Pagination Class Initialized
INFO - 2024-02-18 11:38:44 --> Form Validation Class Initialized
INFO - 2024-02-18 11:38:44 --> Controller Class Initialized
INFO - 2024-02-18 11:38:44 --> Model Class Initialized
DEBUG - 2024-02-18 11:38:44 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-18 11:38:44 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-18 11:38:44 --> Model Class Initialized
DEBUG - 2024-02-18 11:38:44 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-18 11:38:44 --> Model Class Initialized
INFO - 2024-02-18 11:38:44 --> Final output sent to browser
DEBUG - 2024-02-18 11:38:44 --> Total execution time: 0.0921
ERROR - 2024-02-18 11:38:46 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-18 11:38:46 --> Config Class Initialized
INFO - 2024-02-18 11:38:46 --> Hooks Class Initialized
DEBUG - 2024-02-18 11:38:46 --> UTF-8 Support Enabled
INFO - 2024-02-18 11:38:46 --> Utf8 Class Initialized
INFO - 2024-02-18 11:38:46 --> URI Class Initialized
INFO - 2024-02-18 11:38:46 --> Router Class Initialized
INFO - 2024-02-18 11:38:46 --> Output Class Initialized
INFO - 2024-02-18 11:38:46 --> Security Class Initialized
DEBUG - 2024-02-18 11:38:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-18 11:38:46 --> Input Class Initialized
INFO - 2024-02-18 11:38:46 --> Language Class Initialized
INFO - 2024-02-18 11:38:46 --> Loader Class Initialized
INFO - 2024-02-18 11:38:46 --> Helper loaded: url_helper
INFO - 2024-02-18 11:38:46 --> Helper loaded: file_helper
INFO - 2024-02-18 11:38:46 --> Helper loaded: html_helper
INFO - 2024-02-18 11:38:46 --> Helper loaded: text_helper
INFO - 2024-02-18 11:38:46 --> Helper loaded: form_helper
INFO - 2024-02-18 11:38:46 --> Helper loaded: lang_helper
INFO - 2024-02-18 11:38:46 --> Helper loaded: security_helper
INFO - 2024-02-18 11:38:46 --> Helper loaded: cookie_helper
INFO - 2024-02-18 11:38:46 --> Database Driver Class Initialized
INFO - 2024-02-18 11:38:46 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-18 11:38:46 --> Parser Class Initialized
INFO - 2024-02-18 11:38:46 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-18 11:38:46 --> Pagination Class Initialized
INFO - 2024-02-18 11:38:46 --> Form Validation Class Initialized
INFO - 2024-02-18 11:38:46 --> Controller Class Initialized
INFO - 2024-02-18 11:38:46 --> Model Class Initialized
DEBUG - 2024-02-18 11:38:46 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-18 11:38:46 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-18 11:38:46 --> Model Class Initialized
DEBUG - 2024-02-18 11:38:46 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-18 11:38:46 --> Model Class Initialized
INFO - 2024-02-18 11:38:46 --> Final output sent to browser
DEBUG - 2024-02-18 11:38:46 --> Total execution time: 0.0238
ERROR - 2024-02-18 11:38:47 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-18 11:38:47 --> Config Class Initialized
INFO - 2024-02-18 11:38:47 --> Hooks Class Initialized
DEBUG - 2024-02-18 11:38:47 --> UTF-8 Support Enabled
INFO - 2024-02-18 11:38:47 --> Utf8 Class Initialized
INFO - 2024-02-18 11:38:47 --> URI Class Initialized
INFO - 2024-02-18 11:38:47 --> Router Class Initialized
INFO - 2024-02-18 11:38:47 --> Output Class Initialized
INFO - 2024-02-18 11:38:47 --> Security Class Initialized
DEBUG - 2024-02-18 11:38:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-18 11:38:47 --> Input Class Initialized
INFO - 2024-02-18 11:38:47 --> Language Class Initialized
INFO - 2024-02-18 11:38:47 --> Loader Class Initialized
INFO - 2024-02-18 11:38:47 --> Helper loaded: url_helper
INFO - 2024-02-18 11:38:47 --> Helper loaded: file_helper
INFO - 2024-02-18 11:38:47 --> Helper loaded: html_helper
INFO - 2024-02-18 11:38:47 --> Helper loaded: text_helper
INFO - 2024-02-18 11:38:47 --> Helper loaded: form_helper
INFO - 2024-02-18 11:38:47 --> Helper loaded: lang_helper
INFO - 2024-02-18 11:38:47 --> Helper loaded: security_helper
INFO - 2024-02-18 11:38:47 --> Helper loaded: cookie_helper
INFO - 2024-02-18 11:38:47 --> Database Driver Class Initialized
INFO - 2024-02-18 11:38:47 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-18 11:38:47 --> Parser Class Initialized
INFO - 2024-02-18 11:38:47 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-18 11:38:47 --> Pagination Class Initialized
INFO - 2024-02-18 11:38:47 --> Form Validation Class Initialized
INFO - 2024-02-18 11:38:47 --> Controller Class Initialized
INFO - 2024-02-18 11:38:47 --> Model Class Initialized
DEBUG - 2024-02-18 11:38:47 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-18 11:38:47 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-18 11:38:47 --> Model Class Initialized
INFO - 2024-02-18 11:38:47 --> Model Class Initialized
INFO - 2024-02-18 11:38:47 --> Final output sent to browser
DEBUG - 2024-02-18 11:38:47 --> Total execution time: 0.0186
ERROR - 2024-02-18 11:38:50 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-18 11:38:50 --> Config Class Initialized
INFO - 2024-02-18 11:38:50 --> Hooks Class Initialized
DEBUG - 2024-02-18 11:38:50 --> UTF-8 Support Enabled
INFO - 2024-02-18 11:38:50 --> Utf8 Class Initialized
INFO - 2024-02-18 11:38:50 --> URI Class Initialized
INFO - 2024-02-18 11:38:50 --> Router Class Initialized
INFO - 2024-02-18 11:38:50 --> Output Class Initialized
INFO - 2024-02-18 11:38:50 --> Security Class Initialized
DEBUG - 2024-02-18 11:38:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-18 11:38:50 --> Input Class Initialized
INFO - 2024-02-18 11:38:50 --> Language Class Initialized
INFO - 2024-02-18 11:38:50 --> Loader Class Initialized
INFO - 2024-02-18 11:38:50 --> Helper loaded: url_helper
INFO - 2024-02-18 11:38:50 --> Helper loaded: file_helper
INFO - 2024-02-18 11:38:50 --> Helper loaded: html_helper
INFO - 2024-02-18 11:38:50 --> Helper loaded: text_helper
INFO - 2024-02-18 11:38:50 --> Helper loaded: form_helper
INFO - 2024-02-18 11:38:50 --> Helper loaded: lang_helper
INFO - 2024-02-18 11:38:50 --> Helper loaded: security_helper
INFO - 2024-02-18 11:38:50 --> Helper loaded: cookie_helper
INFO - 2024-02-18 11:38:50 --> Database Driver Class Initialized
INFO - 2024-02-18 11:38:50 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-18 11:38:50 --> Parser Class Initialized
INFO - 2024-02-18 11:38:50 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-18 11:38:50 --> Pagination Class Initialized
INFO - 2024-02-18 11:38:50 --> Form Validation Class Initialized
INFO - 2024-02-18 11:38:50 --> Controller Class Initialized
INFO - 2024-02-18 11:38:50 --> Model Class Initialized
DEBUG - 2024-02-18 11:38:50 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-18 11:38:50 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-18 11:38:50 --> Model Class Initialized
INFO - 2024-02-18 11:38:50 --> Final output sent to browser
DEBUG - 2024-02-18 11:38:50 --> Total execution time: 0.0168
ERROR - 2024-02-18 11:38:56 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-18 11:38:56 --> Config Class Initialized
INFO - 2024-02-18 11:38:56 --> Hooks Class Initialized
DEBUG - 2024-02-18 11:38:56 --> UTF-8 Support Enabled
INFO - 2024-02-18 11:38:56 --> Utf8 Class Initialized
INFO - 2024-02-18 11:38:56 --> URI Class Initialized
INFO - 2024-02-18 11:38:56 --> Router Class Initialized
INFO - 2024-02-18 11:38:56 --> Output Class Initialized
INFO - 2024-02-18 11:38:56 --> Security Class Initialized
DEBUG - 2024-02-18 11:38:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-18 11:38:56 --> Input Class Initialized
INFO - 2024-02-18 11:38:56 --> Language Class Initialized
INFO - 2024-02-18 11:38:56 --> Loader Class Initialized
INFO - 2024-02-18 11:38:56 --> Helper loaded: url_helper
INFO - 2024-02-18 11:38:56 --> Helper loaded: file_helper
INFO - 2024-02-18 11:38:56 --> Helper loaded: html_helper
INFO - 2024-02-18 11:38:56 --> Helper loaded: text_helper
INFO - 2024-02-18 11:38:56 --> Helper loaded: form_helper
INFO - 2024-02-18 11:38:56 --> Helper loaded: lang_helper
INFO - 2024-02-18 11:38:56 --> Helper loaded: security_helper
INFO - 2024-02-18 11:38:56 --> Helper loaded: cookie_helper
INFO - 2024-02-18 11:38:56 --> Database Driver Class Initialized
INFO - 2024-02-18 11:38:56 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-18 11:38:56 --> Parser Class Initialized
INFO - 2024-02-18 11:38:56 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-18 11:38:56 --> Pagination Class Initialized
INFO - 2024-02-18 11:38:56 --> Form Validation Class Initialized
INFO - 2024-02-18 11:38:56 --> Controller Class Initialized
INFO - 2024-02-18 11:38:56 --> Model Class Initialized
DEBUG - 2024-02-18 11:38:56 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-18 11:38:56 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-18 11:38:56 --> Model Class Initialized
DEBUG - 2024-02-18 11:38:56 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-18 11:38:56 --> Model Class Initialized
INFO - 2024-02-18 11:38:56 --> Email Class Initialized
DEBUG - 2024-02-18 11:38:56 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-18 11:38:56 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice_html_pdf.php
ERROR - 2024-02-18 11:38:56 --> Severity: Warning --> "continue" targeting switch is equivalent to "break". Did you mean to use "continue 2"? /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/dompdf.cls.php 743
ERROR - 2024-02-18 11:38:56 --> Severity: Warning --> "continue" targeting switch is equivalent to "break". Did you mean to use "continue 2"? /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/dompdf.cls.php 763
ERROR - 2024-02-18 11:38:56 --> Severity: Warning --> "continue" targeting switch is equivalent to "break". Did you mean to use "continue 2"? /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/stylesheet.cls.php 1102
ERROR - 2024-02-18 11:38:56 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/page_frame_decorator.cls.php 439
ERROR - 2024-02-18 11:38:56 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/page_frame_decorator.cls.php 439
ERROR - 2024-02-18 11:38:56 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/page_frame_decorator.cls.php 439
ERROR - 2024-02-18 11:38:56 --> Severity: Warning --> Division by zero /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 572
ERROR - 2024-02-18 11:38:56 --> Severity: Warning --> Division by zero /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 572
ERROR - 2024-02-18 11:38:56 --> Severity: Warning --> Division by zero /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 572
ERROR - 2024-02-18 11:38:56 --> Severity: Warning --> Division by zero /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 572
ERROR - 2024-02-18 11:38:56 --> Severity: Warning --> Division by zero /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 572
ERROR - 2024-02-18 11:38:56 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/table_cell_frame_reflower.cls.php 103
ERROR - 2024-02-18 11:38:56 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/table_cell_frame_reflower.cls.php 103
ERROR - 2024-02-18 11:38:56 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/table_cell_frame_reflower.cls.php 103
ERROR - 2024-02-18 11:38:56 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/table_cell_frame_reflower.cls.php 103
ERROR - 2024-02-18 11:38:56 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/table_cell_frame_reflower.cls.php 103
ERROR - 2024-02-18 11:38:56 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/table_cell_frame_reflower.cls.php 103
ERROR - 2024-02-18 11:38:56 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/table_cell_frame_reflower.cls.php 103
ERROR - 2024-02-18 11:38:56 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/table_cell_frame_reflower.cls.php 103
ERROR - 2024-02-18 11:38:56 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/table_cell_frame_reflower.cls.php 103
ERROR - 2024-02-18 11:38:56 --> Severity: Warning --> Invalid argument supplied for foreach() /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 709
ERROR - 2024-02-18 11:38:56 --> Severity: Warning --> Invalid argument supplied for foreach() /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 709
ERROR - 2024-02-18 11:38:56 --> Severity: Warning --> Invalid argument supplied for foreach() /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 709
ERROR - 2024-02-18 11:38:56 --> Severity: Warning --> Invalid argument supplied for foreach() /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 709
ERROR - 2024-02-18 11:38:56 --> Severity: Warning --> Invalid argument supplied for foreach() /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 709
ERROR - 2024-02-18 11:38:56 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-18 11:38:56 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-18 11:38:56 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-18 11:38:56 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-18 11:38:56 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-18 11:38:56 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-18 11:38:56 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-18 11:38:56 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-18 11:38:56 --> Severity: Warning --> "continue" targeting switch is equivalent to "break". Did you mean to use "continue 2"? /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/text_renderer.cls.php 126
ERROR - 2024-02-18 11:38:56 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-18 11:38:56 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-18 11:38:56 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-18 11:38:56 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-18 11:38:56 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-18 11:38:56 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-18 11:38:56 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-18 11:38:56 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-18 11:38:56 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-18 11:38:56 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-18 11:38:56 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-18 11:38:56 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-18 11:38:56 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-18 11:38:56 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-18 11:38:56 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-18 11:38:56 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-18 11:38:56 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-18 11:38:56 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-18 11:38:56 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-18 11:38:56 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-18 11:38:56 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-18 11:38:56 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-18 11:38:56 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-18 11:38:56 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-18 11:38:56 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-18 11:38:56 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-18 11:38:56 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-18 11:38:56 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-18 11:38:56 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-18 11:38:56 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-18 11:38:56 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-18 11:38:56 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-18 11:38:56 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-18 11:38:56 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-18 11:38:56 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-18 11:38:56 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-18 11:38:56 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-18 11:38:56 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-18 11:38:56 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-18 11:38:56 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-18 11:38:56 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-18 11:38:56 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-18 11:38:56 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-18 11:38:56 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-18 11:38:56 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-18 11:38:56 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-18 11:38:56 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-18 11:38:56 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-18 11:38:56 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-18 11:38:56 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-18 11:38:56 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-18 11:38:56 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-18 11:38:56 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-18 11:38:56 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-18 11:38:56 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-18 11:38:56 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-18 11:38:56 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-18 11:38:56 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-18 11:38:56 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-18 11:38:56 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-18 11:38:56 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-18 11:38:56 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-18 11:38:56 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-18 11:38:56 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-18 11:38:56 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-18 11:38:56 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-18 11:38:56 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-18 11:38:56 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-18 11:38:56 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-18 11:38:56 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-18 11:38:56 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-18 11:38:56 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-18 11:38:56 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-18 11:38:56 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-18 11:38:56 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-18 11:38:56 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-18 11:38:56 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-18 11:38:56 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-18 11:38:56 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-18 11:38:56 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-18 11:38:56 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-18 11:38:56 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-18 11:38:56 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-18 11:38:56 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-18 11:38:56 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-18 11:38:56 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-18 11:38:56 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-18 11:38:56 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-18 11:38:56 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-18 11:38:56 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-18 11:38:56 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-18 11:38:56 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-18 11:38:56 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-18 11:38:56 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-18 11:38:56 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-18 11:38:56 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-18 11:38:56 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-18 11:38:56 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-18 11:38:56 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-18 11:38:56 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
INFO - 2024-02-18 11:38:56 --> Language file loaded: language/english/email_lang.php
INFO - 2024-02-18 11:38:56 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice_html.php
INFO - 2024-02-18 11:38:56 --> Final output sent to browser
DEBUG - 2024-02-18 11:38:56 --> Total execution time: 0.2335
ERROR - 2024-02-18 11:38:59 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-18 11:38:59 --> Config Class Initialized
INFO - 2024-02-18 11:38:59 --> Hooks Class Initialized
DEBUG - 2024-02-18 11:38:59 --> UTF-8 Support Enabled
INFO - 2024-02-18 11:38:59 --> Utf8 Class Initialized
INFO - 2024-02-18 11:38:59 --> URI Class Initialized
INFO - 2024-02-18 11:38:59 --> Router Class Initialized
INFO - 2024-02-18 11:38:59 --> Output Class Initialized
INFO - 2024-02-18 11:38:59 --> Security Class Initialized
DEBUG - 2024-02-18 11:38:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-18 11:38:59 --> Input Class Initialized
INFO - 2024-02-18 11:38:59 --> Language Class Initialized
INFO - 2024-02-18 11:38:59 --> Loader Class Initialized
INFO - 2024-02-18 11:38:59 --> Helper loaded: url_helper
INFO - 2024-02-18 11:38:59 --> Helper loaded: file_helper
INFO - 2024-02-18 11:38:59 --> Helper loaded: html_helper
INFO - 2024-02-18 11:38:59 --> Helper loaded: text_helper
INFO - 2024-02-18 11:38:59 --> Helper loaded: form_helper
INFO - 2024-02-18 11:38:59 --> Helper loaded: lang_helper
INFO - 2024-02-18 11:38:59 --> Helper loaded: security_helper
INFO - 2024-02-18 11:38:59 --> Helper loaded: cookie_helper
INFO - 2024-02-18 11:38:59 --> Database Driver Class Initialized
INFO - 2024-02-18 11:38:59 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-18 11:38:59 --> Parser Class Initialized
INFO - 2024-02-18 11:38:59 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-18 11:38:59 --> Pagination Class Initialized
INFO - 2024-02-18 11:38:59 --> Form Validation Class Initialized
INFO - 2024-02-18 11:38:59 --> Controller Class Initialized
INFO - 2024-02-18 11:38:59 --> Model Class Initialized
DEBUG - 2024-02-18 11:38:59 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-18 11:38:59 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-18 11:38:59 --> Model Class Initialized
DEBUG - 2024-02-18 11:38:59 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-18 11:38:59 --> Model Class Initialized
INFO - 2024-02-18 11:38:59 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/add_invoice_form.php
DEBUG - 2024-02-18 11:38:59 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-02-18 11:38:59 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-02-18 11:38:59 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-02-18 11:38:59 --> Model Class Initialized
INFO - 2024-02-18 11:38:59 --> Model Class Initialized
INFO - 2024-02-18 11:38:59 --> Model Class Initialized
INFO - 2024-02-18 11:38:59 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-02-18 11:38:59 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-02-18 11:38:59 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-02-18 11:38:59 --> Final output sent to browser
DEBUG - 2024-02-18 11:38:59 --> Total execution time: 0.1843
ERROR - 2024-02-18 11:39:02 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-18 11:39:02 --> Config Class Initialized
INFO - 2024-02-18 11:39:02 --> Hooks Class Initialized
DEBUG - 2024-02-18 11:39:02 --> UTF-8 Support Enabled
INFO - 2024-02-18 11:39:02 --> Utf8 Class Initialized
INFO - 2024-02-18 11:39:02 --> URI Class Initialized
INFO - 2024-02-18 11:39:02 --> Router Class Initialized
INFO - 2024-02-18 11:39:02 --> Output Class Initialized
INFO - 2024-02-18 11:39:02 --> Security Class Initialized
DEBUG - 2024-02-18 11:39:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-18 11:39:02 --> Input Class Initialized
INFO - 2024-02-18 11:39:02 --> Language Class Initialized
INFO - 2024-02-18 11:39:02 --> Loader Class Initialized
INFO - 2024-02-18 11:39:02 --> Helper loaded: url_helper
INFO - 2024-02-18 11:39:02 --> Helper loaded: file_helper
INFO - 2024-02-18 11:39:02 --> Helper loaded: html_helper
INFO - 2024-02-18 11:39:02 --> Helper loaded: text_helper
INFO - 2024-02-18 11:39:02 --> Helper loaded: form_helper
INFO - 2024-02-18 11:39:02 --> Helper loaded: lang_helper
INFO - 2024-02-18 11:39:02 --> Helper loaded: security_helper
INFO - 2024-02-18 11:39:02 --> Helper loaded: cookie_helper
INFO - 2024-02-18 11:39:02 --> Database Driver Class Initialized
INFO - 2024-02-18 11:39:02 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-18 11:39:02 --> Parser Class Initialized
INFO - 2024-02-18 11:39:02 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-18 11:39:02 --> Pagination Class Initialized
INFO - 2024-02-18 11:39:02 --> Form Validation Class Initialized
INFO - 2024-02-18 11:39:02 --> Controller Class Initialized
INFO - 2024-02-18 11:39:02 --> Model Class Initialized
DEBUG - 2024-02-18 11:39:02 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-18 11:39:02 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-18 11:39:02 --> Model Class Initialized
DEBUG - 2024-02-18 11:39:02 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-18 11:39:02 --> Model Class Initialized
INFO - 2024-02-18 11:39:02 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice.php
DEBUG - 2024-02-18 11:39:02 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-02-18 11:39:02 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-02-18 11:39:02 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-02-18 11:39:02 --> Model Class Initialized
INFO - 2024-02-18 11:39:02 --> Model Class Initialized
INFO - 2024-02-18 11:39:02 --> Model Class Initialized
INFO - 2024-02-18 11:39:02 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-02-18 11:39:02 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-02-18 11:39:02 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-02-18 11:39:02 --> Final output sent to browser
DEBUG - 2024-02-18 11:39:02 --> Total execution time: 0.1481
ERROR - 2024-02-18 11:39:03 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-18 11:39:03 --> Config Class Initialized
INFO - 2024-02-18 11:39:03 --> Hooks Class Initialized
DEBUG - 2024-02-18 11:39:03 --> UTF-8 Support Enabled
INFO - 2024-02-18 11:39:03 --> Utf8 Class Initialized
INFO - 2024-02-18 11:39:03 --> URI Class Initialized
INFO - 2024-02-18 11:39:03 --> Router Class Initialized
INFO - 2024-02-18 11:39:03 --> Output Class Initialized
INFO - 2024-02-18 11:39:03 --> Security Class Initialized
DEBUG - 2024-02-18 11:39:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-18 11:39:03 --> Input Class Initialized
INFO - 2024-02-18 11:39:03 --> Language Class Initialized
INFO - 2024-02-18 11:39:03 --> Loader Class Initialized
INFO - 2024-02-18 11:39:03 --> Helper loaded: url_helper
INFO - 2024-02-18 11:39:03 --> Helper loaded: file_helper
INFO - 2024-02-18 11:39:03 --> Helper loaded: html_helper
INFO - 2024-02-18 11:39:03 --> Helper loaded: text_helper
INFO - 2024-02-18 11:39:03 --> Helper loaded: form_helper
INFO - 2024-02-18 11:39:03 --> Helper loaded: lang_helper
INFO - 2024-02-18 11:39:03 --> Helper loaded: security_helper
INFO - 2024-02-18 11:39:03 --> Helper loaded: cookie_helper
INFO - 2024-02-18 11:39:03 --> Database Driver Class Initialized
INFO - 2024-02-18 11:39:03 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-18 11:39:03 --> Parser Class Initialized
INFO - 2024-02-18 11:39:03 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-18 11:39:03 --> Pagination Class Initialized
INFO - 2024-02-18 11:39:03 --> Form Validation Class Initialized
INFO - 2024-02-18 11:39:03 --> Controller Class Initialized
INFO - 2024-02-18 11:39:03 --> Model Class Initialized
DEBUG - 2024-02-18 11:39:03 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-18 11:39:03 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-18 11:39:03 --> Model Class Initialized
DEBUG - 2024-02-18 11:39:03 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-18 11:39:03 --> Model Class Initialized
INFO - 2024-02-18 11:39:03 --> Final output sent to browser
DEBUG - 2024-02-18 11:39:03 --> Total execution time: 0.0403
ERROR - 2024-02-18 11:39:06 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-18 11:39:06 --> Config Class Initialized
INFO - 2024-02-18 11:39:06 --> Hooks Class Initialized
DEBUG - 2024-02-18 11:39:06 --> UTF-8 Support Enabled
INFO - 2024-02-18 11:39:06 --> Utf8 Class Initialized
INFO - 2024-02-18 11:39:06 --> URI Class Initialized
INFO - 2024-02-18 11:39:06 --> Router Class Initialized
INFO - 2024-02-18 11:39:06 --> Output Class Initialized
INFO - 2024-02-18 11:39:06 --> Security Class Initialized
DEBUG - 2024-02-18 11:39:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-18 11:39:06 --> Input Class Initialized
INFO - 2024-02-18 11:39:06 --> Language Class Initialized
INFO - 2024-02-18 11:39:06 --> Loader Class Initialized
INFO - 2024-02-18 11:39:06 --> Helper loaded: url_helper
INFO - 2024-02-18 11:39:06 --> Helper loaded: file_helper
INFO - 2024-02-18 11:39:06 --> Helper loaded: html_helper
INFO - 2024-02-18 11:39:06 --> Helper loaded: text_helper
INFO - 2024-02-18 11:39:06 --> Helper loaded: form_helper
INFO - 2024-02-18 11:39:06 --> Helper loaded: lang_helper
INFO - 2024-02-18 11:39:06 --> Helper loaded: security_helper
INFO - 2024-02-18 11:39:06 --> Helper loaded: cookie_helper
INFO - 2024-02-18 11:39:06 --> Database Driver Class Initialized
INFO - 2024-02-18 11:39:06 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-18 11:39:06 --> Parser Class Initialized
INFO - 2024-02-18 11:39:06 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-18 11:39:06 --> Pagination Class Initialized
INFO - 2024-02-18 11:39:06 --> Form Validation Class Initialized
INFO - 2024-02-18 11:39:06 --> Controller Class Initialized
INFO - 2024-02-18 11:39:06 --> Model Class Initialized
DEBUG - 2024-02-18 11:39:06 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-18 11:39:06 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-18 11:39:06 --> Model Class Initialized
DEBUG - 2024-02-18 11:39:06 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-18 11:39:06 --> Model Class Initialized
INFO - 2024-02-18 11:39:06 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice.php
DEBUG - 2024-02-18 11:39:06 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-02-18 11:39:06 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-02-18 11:39:06 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-02-18 11:39:06 --> Model Class Initialized
INFO - 2024-02-18 11:39:06 --> Model Class Initialized
INFO - 2024-02-18 11:39:06 --> Model Class Initialized
INFO - 2024-02-18 11:39:06 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-02-18 11:39:06 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-02-18 11:39:06 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-02-18 11:39:06 --> Final output sent to browser
DEBUG - 2024-02-18 11:39:06 --> Total execution time: 0.1450
ERROR - 2024-02-18 11:39:07 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-18 11:39:07 --> Config Class Initialized
INFO - 2024-02-18 11:39:07 --> Hooks Class Initialized
DEBUG - 2024-02-18 11:39:07 --> UTF-8 Support Enabled
INFO - 2024-02-18 11:39:07 --> Utf8 Class Initialized
INFO - 2024-02-18 11:39:07 --> URI Class Initialized
INFO - 2024-02-18 11:39:07 --> Router Class Initialized
INFO - 2024-02-18 11:39:07 --> Output Class Initialized
INFO - 2024-02-18 11:39:07 --> Security Class Initialized
DEBUG - 2024-02-18 11:39:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-18 11:39:07 --> Input Class Initialized
INFO - 2024-02-18 11:39:07 --> Language Class Initialized
INFO - 2024-02-18 11:39:07 --> Loader Class Initialized
INFO - 2024-02-18 11:39:07 --> Helper loaded: url_helper
INFO - 2024-02-18 11:39:07 --> Helper loaded: file_helper
INFO - 2024-02-18 11:39:07 --> Helper loaded: html_helper
INFO - 2024-02-18 11:39:07 --> Helper loaded: text_helper
INFO - 2024-02-18 11:39:07 --> Helper loaded: form_helper
INFO - 2024-02-18 11:39:07 --> Helper loaded: lang_helper
INFO - 2024-02-18 11:39:07 --> Helper loaded: security_helper
INFO - 2024-02-18 11:39:07 --> Helper loaded: cookie_helper
INFO - 2024-02-18 11:39:07 --> Database Driver Class Initialized
INFO - 2024-02-18 11:39:07 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-18 11:39:07 --> Parser Class Initialized
INFO - 2024-02-18 11:39:07 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-18 11:39:07 --> Pagination Class Initialized
INFO - 2024-02-18 11:39:07 --> Form Validation Class Initialized
INFO - 2024-02-18 11:39:07 --> Controller Class Initialized
INFO - 2024-02-18 11:39:07 --> Model Class Initialized
DEBUG - 2024-02-18 11:39:07 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-18 11:39:07 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-18 11:39:07 --> Model Class Initialized
DEBUG - 2024-02-18 11:39:07 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-18 11:39:07 --> Model Class Initialized
INFO - 2024-02-18 11:39:07 --> Final output sent to browser
DEBUG - 2024-02-18 11:39:07 --> Total execution time: 0.0408
ERROR - 2024-02-18 11:39:08 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-18 11:39:08 --> Config Class Initialized
INFO - 2024-02-18 11:39:08 --> Hooks Class Initialized
DEBUG - 2024-02-18 11:39:08 --> UTF-8 Support Enabled
INFO - 2024-02-18 11:39:08 --> Utf8 Class Initialized
INFO - 2024-02-18 11:39:08 --> URI Class Initialized
INFO - 2024-02-18 11:39:08 --> Router Class Initialized
INFO - 2024-02-18 11:39:08 --> Output Class Initialized
INFO - 2024-02-18 11:39:08 --> Security Class Initialized
DEBUG - 2024-02-18 11:39:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-18 11:39:08 --> Input Class Initialized
INFO - 2024-02-18 11:39:08 --> Language Class Initialized
INFO - 2024-02-18 11:39:08 --> Loader Class Initialized
INFO - 2024-02-18 11:39:08 --> Helper loaded: url_helper
INFO - 2024-02-18 11:39:08 --> Helper loaded: file_helper
INFO - 2024-02-18 11:39:08 --> Helper loaded: html_helper
INFO - 2024-02-18 11:39:08 --> Helper loaded: text_helper
INFO - 2024-02-18 11:39:08 --> Helper loaded: form_helper
INFO - 2024-02-18 11:39:08 --> Helper loaded: lang_helper
INFO - 2024-02-18 11:39:08 --> Helper loaded: security_helper
INFO - 2024-02-18 11:39:08 --> Helper loaded: cookie_helper
INFO - 2024-02-18 11:39:08 --> Database Driver Class Initialized
INFO - 2024-02-18 11:39:08 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-18 11:39:08 --> Parser Class Initialized
INFO - 2024-02-18 11:39:08 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-18 11:39:08 --> Pagination Class Initialized
INFO - 2024-02-18 11:39:08 --> Form Validation Class Initialized
INFO - 2024-02-18 11:39:08 --> Controller Class Initialized
INFO - 2024-02-18 11:39:08 --> Model Class Initialized
DEBUG - 2024-02-18 11:39:08 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-18 11:39:08 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-18 11:39:08 --> Model Class Initialized
DEBUG - 2024-02-18 11:39:08 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-18 11:39:08 --> Model Class Initialized
INFO - 2024-02-18 11:39:08 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice.php
DEBUG - 2024-02-18 11:39:08 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-02-18 11:39:08 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-02-18 11:39:08 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-02-18 11:39:08 --> Model Class Initialized
INFO - 2024-02-18 11:39:08 --> Model Class Initialized
INFO - 2024-02-18 11:39:08 --> Model Class Initialized
INFO - 2024-02-18 11:39:08 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-02-18 11:39:08 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-02-18 11:39:08 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-02-18 11:39:08 --> Final output sent to browser
DEBUG - 2024-02-18 11:39:08 --> Total execution time: 0.1464
ERROR - 2024-02-18 11:39:09 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-18 11:39:09 --> Config Class Initialized
INFO - 2024-02-18 11:39:09 --> Hooks Class Initialized
DEBUG - 2024-02-18 11:39:09 --> UTF-8 Support Enabled
INFO - 2024-02-18 11:39:09 --> Utf8 Class Initialized
INFO - 2024-02-18 11:39:09 --> URI Class Initialized
INFO - 2024-02-18 11:39:09 --> Router Class Initialized
INFO - 2024-02-18 11:39:09 --> Output Class Initialized
INFO - 2024-02-18 11:39:09 --> Security Class Initialized
DEBUG - 2024-02-18 11:39:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-18 11:39:09 --> Input Class Initialized
INFO - 2024-02-18 11:39:09 --> Language Class Initialized
INFO - 2024-02-18 11:39:09 --> Loader Class Initialized
INFO - 2024-02-18 11:39:09 --> Helper loaded: url_helper
INFO - 2024-02-18 11:39:09 --> Helper loaded: file_helper
INFO - 2024-02-18 11:39:09 --> Helper loaded: html_helper
INFO - 2024-02-18 11:39:09 --> Helper loaded: text_helper
INFO - 2024-02-18 11:39:09 --> Helper loaded: form_helper
INFO - 2024-02-18 11:39:09 --> Helper loaded: lang_helper
INFO - 2024-02-18 11:39:09 --> Helper loaded: security_helper
INFO - 2024-02-18 11:39:09 --> Helper loaded: cookie_helper
INFO - 2024-02-18 11:39:09 --> Database Driver Class Initialized
INFO - 2024-02-18 11:39:09 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-18 11:39:09 --> Parser Class Initialized
INFO - 2024-02-18 11:39:09 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-18 11:39:09 --> Pagination Class Initialized
INFO - 2024-02-18 11:39:09 --> Form Validation Class Initialized
INFO - 2024-02-18 11:39:09 --> Controller Class Initialized
INFO - 2024-02-18 11:39:09 --> Model Class Initialized
DEBUG - 2024-02-18 11:39:09 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-18 11:39:09 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-18 11:39:09 --> Model Class Initialized
DEBUG - 2024-02-18 11:39:09 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-18 11:39:09 --> Model Class Initialized
INFO - 2024-02-18 11:39:09 --> Final output sent to browser
DEBUG - 2024-02-18 11:39:09 --> Total execution time: 0.0426
ERROR - 2024-02-18 11:39:14 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-18 11:39:14 --> Config Class Initialized
INFO - 2024-02-18 11:39:14 --> Hooks Class Initialized
DEBUG - 2024-02-18 11:39:14 --> UTF-8 Support Enabled
INFO - 2024-02-18 11:39:14 --> Utf8 Class Initialized
INFO - 2024-02-18 11:39:14 --> URI Class Initialized
DEBUG - 2024-02-18 11:39:14 --> No URI present. Default controller set.
INFO - 2024-02-18 11:39:14 --> Router Class Initialized
INFO - 2024-02-18 11:39:14 --> Output Class Initialized
INFO - 2024-02-18 11:39:14 --> Security Class Initialized
DEBUG - 2024-02-18 11:39:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-18 11:39:14 --> Input Class Initialized
INFO - 2024-02-18 11:39:14 --> Language Class Initialized
INFO - 2024-02-18 11:39:14 --> Loader Class Initialized
INFO - 2024-02-18 11:39:14 --> Helper loaded: url_helper
INFO - 2024-02-18 11:39:14 --> Helper loaded: file_helper
INFO - 2024-02-18 11:39:14 --> Helper loaded: html_helper
INFO - 2024-02-18 11:39:14 --> Helper loaded: text_helper
INFO - 2024-02-18 11:39:14 --> Helper loaded: form_helper
INFO - 2024-02-18 11:39:14 --> Helper loaded: lang_helper
INFO - 2024-02-18 11:39:14 --> Helper loaded: security_helper
INFO - 2024-02-18 11:39:14 --> Helper loaded: cookie_helper
INFO - 2024-02-18 11:39:14 --> Database Driver Class Initialized
INFO - 2024-02-18 11:39:14 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-18 11:39:14 --> Parser Class Initialized
INFO - 2024-02-18 11:39:14 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-18 11:39:14 --> Pagination Class Initialized
INFO - 2024-02-18 11:39:14 --> Form Validation Class Initialized
INFO - 2024-02-18 11:39:14 --> Controller Class Initialized
INFO - 2024-02-18 11:39:14 --> Model Class Initialized
DEBUG - 2024-02-18 11:39:14 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-18 11:39:14 --> Model Class Initialized
DEBUG - 2024-02-18 11:39:14 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-18 11:39:14 --> Model Class Initialized
INFO - 2024-02-18 11:39:14 --> Model Class Initialized
INFO - 2024-02-18 11:39:14 --> Model Class Initialized
INFO - 2024-02-18 11:39:14 --> Model Class Initialized
DEBUG - 2024-02-18 11:39:14 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-18 11:39:14 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-18 11:39:14 --> Model Class Initialized
INFO - 2024-02-18 11:39:14 --> Model Class Initialized
INFO - 2024-02-18 11:39:14 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2024-02-18 11:39:14 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-02-18 11:39:14 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-02-18 11:39:14 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-02-18 11:39:14 --> Model Class Initialized
INFO - 2024-02-18 11:39:14 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-02-18 11:39:14 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-02-18 11:39:14 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-02-18 11:39:14 --> Final output sent to browser
DEBUG - 2024-02-18 11:39:14 --> Total execution time: 0.2320
ERROR - 2024-02-18 11:39:25 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-18 11:39:25 --> Config Class Initialized
INFO - 2024-02-18 11:39:25 --> Hooks Class Initialized
DEBUG - 2024-02-18 11:39:25 --> UTF-8 Support Enabled
INFO - 2024-02-18 11:39:25 --> Utf8 Class Initialized
INFO - 2024-02-18 11:39:25 --> URI Class Initialized
INFO - 2024-02-18 11:39:25 --> Router Class Initialized
INFO - 2024-02-18 11:39:25 --> Output Class Initialized
INFO - 2024-02-18 11:39:25 --> Security Class Initialized
DEBUG - 2024-02-18 11:39:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-18 11:39:25 --> Input Class Initialized
INFO - 2024-02-18 11:39:25 --> Language Class Initialized
INFO - 2024-02-18 11:39:25 --> Loader Class Initialized
INFO - 2024-02-18 11:39:25 --> Helper loaded: url_helper
INFO - 2024-02-18 11:39:25 --> Helper loaded: file_helper
INFO - 2024-02-18 11:39:25 --> Helper loaded: html_helper
INFO - 2024-02-18 11:39:25 --> Helper loaded: text_helper
INFO - 2024-02-18 11:39:25 --> Helper loaded: form_helper
INFO - 2024-02-18 11:39:25 --> Helper loaded: lang_helper
INFO - 2024-02-18 11:39:25 --> Helper loaded: security_helper
INFO - 2024-02-18 11:39:25 --> Helper loaded: cookie_helper
INFO - 2024-02-18 11:39:25 --> Database Driver Class Initialized
INFO - 2024-02-18 11:39:25 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-18 11:39:25 --> Parser Class Initialized
INFO - 2024-02-18 11:39:25 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-18 11:39:25 --> Pagination Class Initialized
INFO - 2024-02-18 11:39:25 --> Form Validation Class Initialized
INFO - 2024-02-18 11:39:25 --> Controller Class Initialized
INFO - 2024-02-18 11:39:25 --> Model Class Initialized
DEBUG - 2024-02-18 11:39:25 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-18 11:39:25 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-18 11:39:25 --> Model Class Initialized
DEBUG - 2024-02-18 11:39:25 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-18 11:39:25 --> Model Class Initialized
INFO - 2024-02-18 11:39:25 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice.php
DEBUG - 2024-02-18 11:39:25 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-02-18 11:39:25 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-02-18 11:39:25 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-02-18 11:39:25 --> Model Class Initialized
INFO - 2024-02-18 11:39:25 --> Model Class Initialized
INFO - 2024-02-18 11:39:25 --> Model Class Initialized
INFO - 2024-02-18 11:39:25 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-02-18 11:39:25 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-02-18 11:39:25 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-02-18 11:39:25 --> Final output sent to browser
DEBUG - 2024-02-18 11:39:25 --> Total execution time: 0.1470
ERROR - 2024-02-18 11:39:25 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-18 11:39:25 --> Config Class Initialized
INFO - 2024-02-18 11:39:25 --> Hooks Class Initialized
DEBUG - 2024-02-18 11:39:25 --> UTF-8 Support Enabled
INFO - 2024-02-18 11:39:25 --> Utf8 Class Initialized
INFO - 2024-02-18 11:39:25 --> URI Class Initialized
INFO - 2024-02-18 11:39:25 --> Router Class Initialized
INFO - 2024-02-18 11:39:25 --> Output Class Initialized
INFO - 2024-02-18 11:39:25 --> Security Class Initialized
DEBUG - 2024-02-18 11:39:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-18 11:39:25 --> Input Class Initialized
INFO - 2024-02-18 11:39:25 --> Language Class Initialized
INFO - 2024-02-18 11:39:25 --> Loader Class Initialized
INFO - 2024-02-18 11:39:25 --> Helper loaded: url_helper
INFO - 2024-02-18 11:39:25 --> Helper loaded: file_helper
INFO - 2024-02-18 11:39:25 --> Helper loaded: html_helper
INFO - 2024-02-18 11:39:25 --> Helper loaded: text_helper
INFO - 2024-02-18 11:39:25 --> Helper loaded: form_helper
INFO - 2024-02-18 11:39:25 --> Helper loaded: lang_helper
INFO - 2024-02-18 11:39:25 --> Helper loaded: security_helper
INFO - 2024-02-18 11:39:25 --> Helper loaded: cookie_helper
INFO - 2024-02-18 11:39:25 --> Database Driver Class Initialized
INFO - 2024-02-18 11:39:25 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-18 11:39:25 --> Parser Class Initialized
INFO - 2024-02-18 11:39:25 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-18 11:39:25 --> Pagination Class Initialized
INFO - 2024-02-18 11:39:25 --> Form Validation Class Initialized
INFO - 2024-02-18 11:39:25 --> Controller Class Initialized
INFO - 2024-02-18 11:39:25 --> Model Class Initialized
DEBUG - 2024-02-18 11:39:25 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-18 11:39:25 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-18 11:39:25 --> Model Class Initialized
DEBUG - 2024-02-18 11:39:25 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-18 11:39:25 --> Model Class Initialized
INFO - 2024-02-18 11:39:25 --> Final output sent to browser
DEBUG - 2024-02-18 11:39:25 --> Total execution time: 0.0389
ERROR - 2024-02-18 11:39:31 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-18 11:39:31 --> Config Class Initialized
INFO - 2024-02-18 11:39:31 --> Hooks Class Initialized
DEBUG - 2024-02-18 11:39:31 --> UTF-8 Support Enabled
INFO - 2024-02-18 11:39:31 --> Utf8 Class Initialized
INFO - 2024-02-18 11:39:31 --> URI Class Initialized
INFO - 2024-02-18 11:39:31 --> Router Class Initialized
INFO - 2024-02-18 11:39:31 --> Output Class Initialized
INFO - 2024-02-18 11:39:31 --> Security Class Initialized
DEBUG - 2024-02-18 11:39:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-18 11:39:31 --> Input Class Initialized
INFO - 2024-02-18 11:39:31 --> Language Class Initialized
INFO - 2024-02-18 11:39:31 --> Loader Class Initialized
INFO - 2024-02-18 11:39:31 --> Helper loaded: url_helper
INFO - 2024-02-18 11:39:31 --> Helper loaded: file_helper
INFO - 2024-02-18 11:39:31 --> Helper loaded: html_helper
INFO - 2024-02-18 11:39:31 --> Helper loaded: text_helper
INFO - 2024-02-18 11:39:31 --> Helper loaded: form_helper
INFO - 2024-02-18 11:39:31 --> Helper loaded: lang_helper
INFO - 2024-02-18 11:39:31 --> Helper loaded: security_helper
INFO - 2024-02-18 11:39:31 --> Helper loaded: cookie_helper
INFO - 2024-02-18 11:39:31 --> Database Driver Class Initialized
INFO - 2024-02-18 11:39:31 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-18 11:39:31 --> Parser Class Initialized
INFO - 2024-02-18 11:39:31 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-18 11:39:31 --> Pagination Class Initialized
INFO - 2024-02-18 11:39:31 --> Form Validation Class Initialized
INFO - 2024-02-18 11:39:31 --> Controller Class Initialized
INFO - 2024-02-18 11:39:31 --> Model Class Initialized
DEBUG - 2024-02-18 11:39:31 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-18 11:39:31 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-18 11:39:31 --> Model Class Initialized
DEBUG - 2024-02-18 11:39:31 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-18 11:39:31 --> Model Class Initialized
DEBUG - 2024-02-18 11:39:31 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-18 11:39:31 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice_html.php
DEBUG - 2024-02-18 11:39:31 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-02-18 11:39:31 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-02-18 11:39:31 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-02-18 11:39:31 --> Model Class Initialized
INFO - 2024-02-18 11:39:31 --> Model Class Initialized
INFO - 2024-02-18 11:39:31 --> Model Class Initialized
INFO - 2024-02-18 11:39:31 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-02-18 11:39:31 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-02-18 11:39:31 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-02-18 11:39:31 --> Final output sent to browser
DEBUG - 2024-02-18 11:39:31 --> Total execution time: 0.1616
ERROR - 2024-02-18 11:39:31 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-18 11:39:31 --> Config Class Initialized
INFO - 2024-02-18 11:39:31 --> Hooks Class Initialized
DEBUG - 2024-02-18 11:39:31 --> UTF-8 Support Enabled
INFO - 2024-02-18 11:39:31 --> Utf8 Class Initialized
INFO - 2024-02-18 11:39:31 --> URI Class Initialized
INFO - 2024-02-18 11:39:31 --> Router Class Initialized
INFO - 2024-02-18 11:39:31 --> Output Class Initialized
INFO - 2024-02-18 11:39:31 --> Security Class Initialized
DEBUG - 2024-02-18 11:39:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-18 11:39:31 --> Input Class Initialized
INFO - 2024-02-18 11:39:31 --> Language Class Initialized
INFO - 2024-02-18 11:39:31 --> Loader Class Initialized
INFO - 2024-02-18 11:39:31 --> Helper loaded: url_helper
INFO - 2024-02-18 11:39:31 --> Helper loaded: file_helper
INFO - 2024-02-18 11:39:31 --> Helper loaded: html_helper
INFO - 2024-02-18 11:39:31 --> Helper loaded: text_helper
INFO - 2024-02-18 11:39:31 --> Helper loaded: form_helper
INFO - 2024-02-18 11:39:31 --> Helper loaded: lang_helper
INFO - 2024-02-18 11:39:31 --> Helper loaded: security_helper
INFO - 2024-02-18 11:39:31 --> Helper loaded: cookie_helper
INFO - 2024-02-18 11:39:31 --> Database Driver Class Initialized
INFO - 2024-02-18 11:39:31 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-18 11:39:31 --> Parser Class Initialized
INFO - 2024-02-18 11:39:31 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-18 11:39:31 --> Pagination Class Initialized
INFO - 2024-02-18 11:39:31 --> Form Validation Class Initialized
INFO - 2024-02-18 11:39:31 --> Controller Class Initialized
INFO - 2024-02-18 11:39:31 --> Model Class Initialized
DEBUG - 2024-02-18 11:39:31 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-18 11:39:31 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-18 11:39:31 --> Model Class Initialized
DEBUG - 2024-02-18 11:39:31 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-18 11:39:31 --> Model Class Initialized
DEBUG - 2024-02-18 11:39:31 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-18 11:39:31 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice_html.php
DEBUG - 2024-02-18 11:39:31 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-02-18 11:39:31 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-02-18 11:39:31 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-02-18 11:39:31 --> Model Class Initialized
INFO - 2024-02-18 11:39:31 --> Model Class Initialized
INFO - 2024-02-18 11:39:31 --> Model Class Initialized
INFO - 2024-02-18 11:39:31 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-02-18 11:39:31 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-02-18 11:39:31 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-02-18 11:39:31 --> Final output sent to browser
DEBUG - 2024-02-18 11:39:31 --> Total execution time: 0.1641
ERROR - 2024-02-18 11:39:53 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-18 11:39:53 --> Config Class Initialized
INFO - 2024-02-18 11:39:53 --> Hooks Class Initialized
DEBUG - 2024-02-18 11:39:53 --> UTF-8 Support Enabled
INFO - 2024-02-18 11:39:53 --> Utf8 Class Initialized
INFO - 2024-02-18 11:39:53 --> URI Class Initialized
INFO - 2024-02-18 11:39:53 --> Router Class Initialized
INFO - 2024-02-18 11:39:53 --> Output Class Initialized
INFO - 2024-02-18 11:39:53 --> Security Class Initialized
DEBUG - 2024-02-18 11:39:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-18 11:39:53 --> Input Class Initialized
INFO - 2024-02-18 11:39:53 --> Language Class Initialized
INFO - 2024-02-18 11:39:53 --> Loader Class Initialized
INFO - 2024-02-18 11:39:53 --> Helper loaded: url_helper
INFO - 2024-02-18 11:39:53 --> Helper loaded: file_helper
INFO - 2024-02-18 11:39:53 --> Helper loaded: html_helper
INFO - 2024-02-18 11:39:53 --> Helper loaded: text_helper
INFO - 2024-02-18 11:39:53 --> Helper loaded: form_helper
INFO - 2024-02-18 11:39:53 --> Helper loaded: lang_helper
INFO - 2024-02-18 11:39:53 --> Helper loaded: security_helper
INFO - 2024-02-18 11:39:53 --> Helper loaded: cookie_helper
INFO - 2024-02-18 11:39:53 --> Database Driver Class Initialized
INFO - 2024-02-18 11:39:53 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-18 11:39:53 --> Parser Class Initialized
INFO - 2024-02-18 11:39:53 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-18 11:39:53 --> Pagination Class Initialized
INFO - 2024-02-18 11:39:53 --> Form Validation Class Initialized
INFO - 2024-02-18 11:39:53 --> Controller Class Initialized
INFO - 2024-02-18 11:39:53 --> Model Class Initialized
DEBUG - 2024-02-18 11:39:53 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-18 11:39:53 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-18 11:39:53 --> Model Class Initialized
DEBUG - 2024-02-18 11:39:53 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-18 11:39:53 --> Model Class Initialized
DEBUG - 2024-02-18 11:39:53 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-18 11:39:53 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice_html.php
DEBUG - 2024-02-18 11:39:53 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-02-18 11:39:53 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-02-18 11:39:53 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-02-18 11:39:53 --> Model Class Initialized
INFO - 2024-02-18 11:39:53 --> Model Class Initialized
INFO - 2024-02-18 11:39:53 --> Model Class Initialized
INFO - 2024-02-18 11:39:53 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-02-18 11:39:53 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-02-18 11:39:53 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-02-18 11:39:53 --> Final output sent to browser
DEBUG - 2024-02-18 11:39:53 --> Total execution time: 0.1628
ERROR - 2024-02-18 11:40:33 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-18 11:40:33 --> Config Class Initialized
INFO - 2024-02-18 11:40:33 --> Hooks Class Initialized
DEBUG - 2024-02-18 11:40:33 --> UTF-8 Support Enabled
INFO - 2024-02-18 11:40:33 --> Utf8 Class Initialized
INFO - 2024-02-18 11:40:33 --> URI Class Initialized
INFO - 2024-02-18 11:40:33 --> Router Class Initialized
INFO - 2024-02-18 11:40:33 --> Output Class Initialized
INFO - 2024-02-18 11:40:33 --> Security Class Initialized
DEBUG - 2024-02-18 11:40:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-18 11:40:33 --> Input Class Initialized
INFO - 2024-02-18 11:40:33 --> Language Class Initialized
INFO - 2024-02-18 11:40:33 --> Loader Class Initialized
INFO - 2024-02-18 11:40:33 --> Helper loaded: url_helper
INFO - 2024-02-18 11:40:33 --> Helper loaded: file_helper
INFO - 2024-02-18 11:40:33 --> Helper loaded: html_helper
INFO - 2024-02-18 11:40:33 --> Helper loaded: text_helper
INFO - 2024-02-18 11:40:33 --> Helper loaded: form_helper
INFO - 2024-02-18 11:40:33 --> Helper loaded: lang_helper
INFO - 2024-02-18 11:40:33 --> Helper loaded: security_helper
INFO - 2024-02-18 11:40:33 --> Helper loaded: cookie_helper
INFO - 2024-02-18 11:40:33 --> Database Driver Class Initialized
INFO - 2024-02-18 11:40:33 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-18 11:40:33 --> Parser Class Initialized
INFO - 2024-02-18 11:40:33 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-18 11:40:33 --> Pagination Class Initialized
INFO - 2024-02-18 11:40:33 --> Form Validation Class Initialized
INFO - 2024-02-18 11:40:33 --> Controller Class Initialized
INFO - 2024-02-18 11:40:33 --> Model Class Initialized
DEBUG - 2024-02-18 11:40:33 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-18 11:40:33 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-18 11:40:33 --> Model Class Initialized
DEBUG - 2024-02-18 11:40:33 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-18 11:40:33 --> Model Class Initialized
INFO - 2024-02-18 11:40:33 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice.php
DEBUG - 2024-02-18 11:40:33 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-02-18 11:40:33 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-02-18 11:40:33 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-02-18 11:40:33 --> Model Class Initialized
INFO - 2024-02-18 11:40:33 --> Model Class Initialized
INFO - 2024-02-18 11:40:33 --> Model Class Initialized
INFO - 2024-02-18 11:40:33 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-02-18 11:40:33 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-02-18 11:40:33 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-02-18 11:40:33 --> Final output sent to browser
DEBUG - 2024-02-18 11:40:33 --> Total execution time: 0.1496
ERROR - 2024-02-18 11:40:34 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-18 11:40:34 --> Config Class Initialized
INFO - 2024-02-18 11:40:34 --> Hooks Class Initialized
DEBUG - 2024-02-18 11:40:34 --> UTF-8 Support Enabled
INFO - 2024-02-18 11:40:34 --> Utf8 Class Initialized
INFO - 2024-02-18 11:40:34 --> URI Class Initialized
INFO - 2024-02-18 11:40:34 --> Router Class Initialized
INFO - 2024-02-18 11:40:34 --> Output Class Initialized
INFO - 2024-02-18 11:40:34 --> Security Class Initialized
DEBUG - 2024-02-18 11:40:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-18 11:40:34 --> Input Class Initialized
INFO - 2024-02-18 11:40:34 --> Language Class Initialized
INFO - 2024-02-18 11:40:34 --> Loader Class Initialized
INFO - 2024-02-18 11:40:34 --> Helper loaded: url_helper
INFO - 2024-02-18 11:40:34 --> Helper loaded: file_helper
INFO - 2024-02-18 11:40:34 --> Helper loaded: html_helper
INFO - 2024-02-18 11:40:34 --> Helper loaded: text_helper
INFO - 2024-02-18 11:40:34 --> Helper loaded: form_helper
INFO - 2024-02-18 11:40:34 --> Helper loaded: lang_helper
INFO - 2024-02-18 11:40:34 --> Helper loaded: security_helper
INFO - 2024-02-18 11:40:34 --> Helper loaded: cookie_helper
INFO - 2024-02-18 11:40:34 --> Database Driver Class Initialized
INFO - 2024-02-18 11:40:34 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-18 11:40:34 --> Parser Class Initialized
INFO - 2024-02-18 11:40:34 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-18 11:40:34 --> Pagination Class Initialized
INFO - 2024-02-18 11:40:34 --> Form Validation Class Initialized
INFO - 2024-02-18 11:40:34 --> Controller Class Initialized
INFO - 2024-02-18 11:40:34 --> Model Class Initialized
DEBUG - 2024-02-18 11:40:34 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-18 11:40:34 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-18 11:40:34 --> Model Class Initialized
DEBUG - 2024-02-18 11:40:34 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-18 11:40:34 --> Model Class Initialized
INFO - 2024-02-18 11:40:34 --> Final output sent to browser
DEBUG - 2024-02-18 11:40:34 --> Total execution time: 0.0410
ERROR - 2024-02-18 11:40:37 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-18 11:40:37 --> Config Class Initialized
INFO - 2024-02-18 11:40:37 --> Hooks Class Initialized
DEBUG - 2024-02-18 11:40:37 --> UTF-8 Support Enabled
INFO - 2024-02-18 11:40:37 --> Utf8 Class Initialized
INFO - 2024-02-18 11:40:37 --> URI Class Initialized
INFO - 2024-02-18 11:40:37 --> Router Class Initialized
INFO - 2024-02-18 11:40:37 --> Output Class Initialized
INFO - 2024-02-18 11:40:37 --> Security Class Initialized
DEBUG - 2024-02-18 11:40:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-18 11:40:37 --> Input Class Initialized
INFO - 2024-02-18 11:40:37 --> Language Class Initialized
INFO - 2024-02-18 11:40:37 --> Loader Class Initialized
INFO - 2024-02-18 11:40:37 --> Helper loaded: url_helper
INFO - 2024-02-18 11:40:37 --> Helper loaded: file_helper
INFO - 2024-02-18 11:40:37 --> Helper loaded: html_helper
INFO - 2024-02-18 11:40:37 --> Helper loaded: text_helper
INFO - 2024-02-18 11:40:37 --> Helper loaded: form_helper
INFO - 2024-02-18 11:40:37 --> Helper loaded: lang_helper
INFO - 2024-02-18 11:40:37 --> Helper loaded: security_helper
INFO - 2024-02-18 11:40:37 --> Helper loaded: cookie_helper
INFO - 2024-02-18 11:40:37 --> Database Driver Class Initialized
INFO - 2024-02-18 11:40:37 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-18 11:40:37 --> Parser Class Initialized
INFO - 2024-02-18 11:40:37 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-18 11:40:37 --> Pagination Class Initialized
INFO - 2024-02-18 11:40:37 --> Form Validation Class Initialized
INFO - 2024-02-18 11:40:37 --> Controller Class Initialized
INFO - 2024-02-18 11:40:37 --> Model Class Initialized
DEBUG - 2024-02-18 11:40:37 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-18 11:40:37 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-18 11:40:37 --> Model Class Initialized
DEBUG - 2024-02-18 11:40:37 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-18 11:40:37 --> Model Class Initialized
INFO - 2024-02-18 11:40:37 --> Final output sent to browser
DEBUG - 2024-02-18 11:40:37 --> Total execution time: 0.1521
ERROR - 2024-02-18 11:41:05 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-18 11:41:05 --> Config Class Initialized
INFO - 2024-02-18 11:41:05 --> Hooks Class Initialized
DEBUG - 2024-02-18 11:41:05 --> UTF-8 Support Enabled
INFO - 2024-02-18 11:41:05 --> Utf8 Class Initialized
INFO - 2024-02-18 11:41:05 --> URI Class Initialized
INFO - 2024-02-18 11:41:05 --> Router Class Initialized
INFO - 2024-02-18 11:41:05 --> Output Class Initialized
INFO - 2024-02-18 11:41:05 --> Security Class Initialized
DEBUG - 2024-02-18 11:41:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-18 11:41:05 --> Input Class Initialized
INFO - 2024-02-18 11:41:05 --> Language Class Initialized
INFO - 2024-02-18 11:41:05 --> Loader Class Initialized
INFO - 2024-02-18 11:41:05 --> Helper loaded: url_helper
INFO - 2024-02-18 11:41:05 --> Helper loaded: file_helper
INFO - 2024-02-18 11:41:05 --> Helper loaded: html_helper
INFO - 2024-02-18 11:41:05 --> Helper loaded: text_helper
INFO - 2024-02-18 11:41:05 --> Helper loaded: form_helper
INFO - 2024-02-18 11:41:05 --> Helper loaded: lang_helper
INFO - 2024-02-18 11:41:05 --> Helper loaded: security_helper
INFO - 2024-02-18 11:41:05 --> Helper loaded: cookie_helper
INFO - 2024-02-18 11:41:05 --> Database Driver Class Initialized
INFO - 2024-02-18 11:41:05 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-18 11:41:05 --> Parser Class Initialized
INFO - 2024-02-18 11:41:05 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-18 11:41:05 --> Pagination Class Initialized
INFO - 2024-02-18 11:41:05 --> Form Validation Class Initialized
INFO - 2024-02-18 11:41:05 --> Controller Class Initialized
INFO - 2024-02-18 11:41:05 --> Model Class Initialized
DEBUG - 2024-02-18 11:41:05 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-18 11:41:05 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-18 11:41:05 --> Model Class Initialized
DEBUG - 2024-02-18 11:41:05 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-18 11:41:05 --> Model Class Initialized
DEBUG - 2024-02-18 11:41:05 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-18 11:41:05 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice_html_pdf.php
ERROR - 2024-02-18 11:41:05 --> Severity: Warning --> "continue" targeting switch is equivalent to "break". Did you mean to use "continue 2"? /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/dompdf.cls.php 743
ERROR - 2024-02-18 11:41:05 --> Severity: Warning --> "continue" targeting switch is equivalent to "break". Did you mean to use "continue 2"? /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/dompdf.cls.php 763
ERROR - 2024-02-18 11:41:05 --> Severity: Warning --> "continue" targeting switch is equivalent to "break". Did you mean to use "continue 2"? /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/stylesheet.cls.php 1102
ERROR - 2024-02-18 11:41:05 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/page_frame_decorator.cls.php 439
ERROR - 2024-02-18 11:41:05 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/page_frame_decorator.cls.php 439
ERROR - 2024-02-18 11:41:05 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/page_frame_decorator.cls.php 439
ERROR - 2024-02-18 11:41:05 --> Severity: Warning --> Division by zero /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 572
ERROR - 2024-02-18 11:41:05 --> Severity: Warning --> Division by zero /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 572
ERROR - 2024-02-18 11:41:05 --> Severity: Warning --> Division by zero /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 572
ERROR - 2024-02-18 11:41:05 --> Severity: Warning --> Division by zero /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 572
ERROR - 2024-02-18 11:41:05 --> Severity: Warning --> Division by zero /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 572
ERROR - 2024-02-18 11:41:05 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/table_cell_frame_reflower.cls.php 103
ERROR - 2024-02-18 11:41:05 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/table_cell_frame_reflower.cls.php 103
ERROR - 2024-02-18 11:41:05 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/table_cell_frame_reflower.cls.php 103
ERROR - 2024-02-18 11:41:05 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/table_cell_frame_reflower.cls.php 103
ERROR - 2024-02-18 11:41:05 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/table_cell_frame_reflower.cls.php 103
ERROR - 2024-02-18 11:41:05 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/table_cell_frame_reflower.cls.php 103
ERROR - 2024-02-18 11:41:05 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/table_cell_frame_reflower.cls.php 103
ERROR - 2024-02-18 11:41:05 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/table_cell_frame_reflower.cls.php 103
ERROR - 2024-02-18 11:41:05 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/table_cell_frame_reflower.cls.php 103
ERROR - 2024-02-18 11:41:05 --> Severity: Warning --> Invalid argument supplied for foreach() /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 709
ERROR - 2024-02-18 11:41:05 --> Severity: Warning --> Invalid argument supplied for foreach() /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 709
ERROR - 2024-02-18 11:41:05 --> Severity: Warning --> Invalid argument supplied for foreach() /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 709
ERROR - 2024-02-18 11:41:05 --> Severity: Warning --> Invalid argument supplied for foreach() /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 709
ERROR - 2024-02-18 11:41:05 --> Severity: Warning --> Invalid argument supplied for foreach() /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 709
ERROR - 2024-02-18 11:41:05 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-18 11:41:05 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-18 11:41:05 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-18 11:41:05 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-18 11:41:05 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-18 11:41:05 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-18 11:41:05 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-18 11:41:05 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-18 11:41:05 --> Severity: Warning --> "continue" targeting switch is equivalent to "break". Did you mean to use "continue 2"? /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/text_renderer.cls.php 126
ERROR - 2024-02-18 11:41:05 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-18 11:41:05 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-18 11:41:05 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-18 11:41:05 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-18 11:41:05 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-18 11:41:05 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-18 11:41:05 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-18 11:41:05 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-18 11:41:05 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-18 11:41:05 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-18 11:41:05 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-18 11:41:05 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-18 11:41:05 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-18 11:41:05 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-18 11:41:05 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-18 11:41:05 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-18 11:41:05 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-18 11:41:05 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-18 11:41:05 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-18 11:41:05 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-18 11:41:05 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-18 11:41:05 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-18 11:41:05 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-18 11:41:05 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-18 11:41:05 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-18 11:41:05 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-18 11:41:05 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-18 11:41:05 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-18 11:41:05 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-18 11:41:05 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-18 11:41:05 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-18 11:41:05 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-18 11:41:05 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-18 11:41:05 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-18 11:41:05 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-18 11:41:05 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-18 11:41:05 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-18 11:41:05 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-18 11:41:05 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-18 11:41:05 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-18 11:41:05 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-18 11:41:05 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-18 11:41:05 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-18 11:41:05 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-18 11:41:05 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-18 11:41:05 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-18 11:41:05 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-18 11:41:05 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-18 11:41:05 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-18 11:41:05 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-18 11:41:05 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-18 11:41:05 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-18 11:41:05 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-18 11:41:05 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-18 11:41:05 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-18 11:41:05 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-18 11:41:05 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-18 11:41:05 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-18 11:41:05 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-18 11:41:05 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-18 11:41:05 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-18 11:41:05 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-18 11:41:05 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-18 11:41:05 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-18 11:41:05 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-18 11:41:05 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-18 11:41:05 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-18 11:41:05 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-18 11:41:05 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-18 11:41:05 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-18 11:41:05 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-18 11:41:05 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-18 11:41:05 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-18 11:41:05 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-18 11:41:05 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-18 11:41:05 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-18 11:41:05 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-18 11:41:05 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-18 11:41:05 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-18 11:41:05 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-18 11:41:05 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-18 11:41:05 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-18 11:41:05 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-18 11:41:05 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-18 11:41:05 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-18 11:41:05 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-18 11:41:05 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-18 11:41:05 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-18 11:41:05 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-18 11:41:05 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-18 11:41:05 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-18 11:41:05 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-18 11:41:05 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-18 11:41:05 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-18 11:41:05 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-18 11:41:05 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-18 11:41:05 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-18 11:41:05 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-18 11:41:05 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-18 11:41:05 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
INFO - 2024-02-18 11:41:06 --> Final output sent to browser
DEBUG - 2024-02-18 11:41:06 --> Total execution time: 0.2002
ERROR - 2024-02-18 11:41:06 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-18 11:41:06 --> Config Class Initialized
INFO - 2024-02-18 11:41:06 --> Hooks Class Initialized
DEBUG - 2024-02-18 11:41:06 --> UTF-8 Support Enabled
INFO - 2024-02-18 11:41:06 --> Utf8 Class Initialized
INFO - 2024-02-18 11:41:06 --> URI Class Initialized
INFO - 2024-02-18 11:41:06 --> Router Class Initialized
INFO - 2024-02-18 11:41:06 --> Output Class Initialized
INFO - 2024-02-18 11:41:06 --> Security Class Initialized
DEBUG - 2024-02-18 11:41:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-18 11:41:06 --> Input Class Initialized
INFO - 2024-02-18 11:41:06 --> Language Class Initialized
INFO - 2024-02-18 11:41:06 --> Loader Class Initialized
INFO - 2024-02-18 11:41:06 --> Helper loaded: url_helper
INFO - 2024-02-18 11:41:06 --> Helper loaded: file_helper
INFO - 2024-02-18 11:41:06 --> Helper loaded: html_helper
INFO - 2024-02-18 11:41:06 --> Helper loaded: text_helper
INFO - 2024-02-18 11:41:06 --> Helper loaded: form_helper
INFO - 2024-02-18 11:41:06 --> Helper loaded: lang_helper
INFO - 2024-02-18 11:41:06 --> Helper loaded: security_helper
INFO - 2024-02-18 11:41:06 --> Helper loaded: cookie_helper
INFO - 2024-02-18 11:41:06 --> Database Driver Class Initialized
INFO - 2024-02-18 11:41:06 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-18 11:41:06 --> Parser Class Initialized
INFO - 2024-02-18 11:41:06 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-18 11:41:06 --> Pagination Class Initialized
INFO - 2024-02-18 11:41:06 --> Form Validation Class Initialized
INFO - 2024-02-18 11:41:06 --> Controller Class Initialized
INFO - 2024-02-18 11:41:06 --> Model Class Initialized
DEBUG - 2024-02-18 11:41:06 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-18 11:41:06 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-18 11:41:06 --> Model Class Initialized
DEBUG - 2024-02-18 11:41:06 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-18 11:41:06 --> Model Class Initialized
DEBUG - 2024-02-18 11:41:06 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-18 11:41:06 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice_html_pdf.php
ERROR - 2024-02-18 11:41:06 --> Severity: Warning --> "continue" targeting switch is equivalent to "break". Did you mean to use "continue 2"? /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/dompdf.cls.php 743
ERROR - 2024-02-18 11:41:06 --> Severity: Warning --> "continue" targeting switch is equivalent to "break". Did you mean to use "continue 2"? /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/dompdf.cls.php 763
ERROR - 2024-02-18 11:41:06 --> Severity: Warning --> "continue" targeting switch is equivalent to "break". Did you mean to use "continue 2"? /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/stylesheet.cls.php 1102
ERROR - 2024-02-18 11:41:06 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/page_frame_decorator.cls.php 439
ERROR - 2024-02-18 11:41:06 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/page_frame_decorator.cls.php 439
ERROR - 2024-02-18 11:41:06 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/page_frame_decorator.cls.php 439
ERROR - 2024-02-18 11:41:06 --> Severity: Warning --> Division by zero /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 572
ERROR - 2024-02-18 11:41:06 --> Severity: Warning --> Division by zero /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 572
ERROR - 2024-02-18 11:41:06 --> Severity: Warning --> Division by zero /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 572
ERROR - 2024-02-18 11:41:06 --> Severity: Warning --> Division by zero /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 572
ERROR - 2024-02-18 11:41:06 --> Severity: Warning --> Division by zero /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 572
ERROR - 2024-02-18 11:41:06 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/table_cell_frame_reflower.cls.php 103
ERROR - 2024-02-18 11:41:06 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/table_cell_frame_reflower.cls.php 103
ERROR - 2024-02-18 11:41:06 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/table_cell_frame_reflower.cls.php 103
ERROR - 2024-02-18 11:41:06 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/table_cell_frame_reflower.cls.php 103
ERROR - 2024-02-18 11:41:06 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/table_cell_frame_reflower.cls.php 103
ERROR - 2024-02-18 11:41:06 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/table_cell_frame_reflower.cls.php 103
ERROR - 2024-02-18 11:41:06 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/table_cell_frame_reflower.cls.php 103
ERROR - 2024-02-18 11:41:06 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/table_cell_frame_reflower.cls.php 103
ERROR - 2024-02-18 11:41:06 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/table_cell_frame_reflower.cls.php 103
ERROR - 2024-02-18 11:41:06 --> Severity: Warning --> Invalid argument supplied for foreach() /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 709
ERROR - 2024-02-18 11:41:06 --> Severity: Warning --> Invalid argument supplied for foreach() /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 709
ERROR - 2024-02-18 11:41:06 --> Severity: Warning --> Invalid argument supplied for foreach() /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 709
ERROR - 2024-02-18 11:41:06 --> Severity: Warning --> Invalid argument supplied for foreach() /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 709
ERROR - 2024-02-18 11:41:06 --> Severity: Warning --> Invalid argument supplied for foreach() /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 709
ERROR - 2024-02-18 11:41:06 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-18 11:41:06 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-18 11:41:06 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-18 11:41:06 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-18 11:41:06 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-18 11:41:06 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-18 11:41:06 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-18 11:41:06 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-18 11:41:06 --> Severity: Warning --> "continue" targeting switch is equivalent to "break". Did you mean to use "continue 2"? /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/text_renderer.cls.php 126
ERROR - 2024-02-18 11:41:06 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-18 11:41:06 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-18 11:41:06 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-18 11:41:06 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-18 11:41:06 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-18 11:41:06 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-18 11:41:06 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-18 11:41:06 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-18 11:41:06 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-18 11:41:06 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-18 11:41:06 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-18 11:41:06 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-18 11:41:06 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-18 11:41:06 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-18 11:41:06 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-18 11:41:06 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-18 11:41:06 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-18 11:41:06 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-18 11:41:06 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-18 11:41:06 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-18 11:41:06 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-18 11:41:06 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-18 11:41:06 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-18 11:41:06 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-18 11:41:06 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-18 11:41:06 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-18 11:41:06 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-18 11:41:06 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-18 11:41:06 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-18 11:41:06 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-18 11:41:06 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-18 11:41:06 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-18 11:41:06 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-18 11:41:06 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-18 11:41:06 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-18 11:41:06 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-18 11:41:06 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-18 11:41:06 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-18 11:41:06 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-18 11:41:06 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-18 11:41:06 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-18 11:41:06 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-18 11:41:06 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-18 11:41:06 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-18 11:41:06 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-18 11:41:06 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-18 11:41:06 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-18 11:41:06 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-18 11:41:06 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-18 11:41:06 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-18 11:41:06 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-18 11:41:06 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-18 11:41:06 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-18 11:41:06 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-18 11:41:06 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-18 11:41:06 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-18 11:41:06 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-18 11:41:06 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-18 11:41:06 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-18 11:41:06 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-18 11:41:06 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-18 11:41:06 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-18 11:41:06 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-18 11:41:06 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-18 11:41:06 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-18 11:41:06 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-18 11:41:06 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-18 11:41:06 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-18 11:41:06 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-18 11:41:06 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-18 11:41:06 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-18 11:41:06 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-18 11:41:06 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-18 11:41:06 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-18 11:41:06 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-18 11:41:06 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-18 11:41:06 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-18 11:41:06 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-18 11:41:06 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-18 11:41:06 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-18 11:41:06 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-18 11:41:06 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-18 11:41:06 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-18 11:41:06 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-18 11:41:06 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-18 11:41:06 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-18 11:41:06 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-18 11:41:06 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-18 11:41:06 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-18 11:41:06 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-18 11:41:06 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-18 11:41:06 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-18 11:41:06 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-18 11:41:06 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-18 11:41:06 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-18 11:41:06 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-18 11:41:06 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-18 11:41:06 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-18 11:41:06 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-18 11:41:06 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
INFO - 2024-02-18 11:41:06 --> Final output sent to browser
DEBUG - 2024-02-18 11:41:06 --> Total execution time: 0.1839
ERROR - 2024-02-18 11:46:48 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-18 11:46:48 --> Config Class Initialized
INFO - 2024-02-18 11:46:48 --> Hooks Class Initialized
DEBUG - 2024-02-18 11:46:48 --> UTF-8 Support Enabled
INFO - 2024-02-18 11:46:48 --> Utf8 Class Initialized
INFO - 2024-02-18 11:46:48 --> URI Class Initialized
INFO - 2024-02-18 11:46:48 --> Router Class Initialized
INFO - 2024-02-18 11:46:48 --> Output Class Initialized
INFO - 2024-02-18 11:46:48 --> Security Class Initialized
DEBUG - 2024-02-18 11:46:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-18 11:46:48 --> Input Class Initialized
INFO - 2024-02-18 11:46:48 --> Language Class Initialized
INFO - 2024-02-18 11:46:48 --> Loader Class Initialized
INFO - 2024-02-18 11:46:48 --> Helper loaded: url_helper
INFO - 2024-02-18 11:46:48 --> Helper loaded: file_helper
INFO - 2024-02-18 11:46:48 --> Helper loaded: html_helper
INFO - 2024-02-18 11:46:48 --> Helper loaded: text_helper
INFO - 2024-02-18 11:46:48 --> Helper loaded: form_helper
INFO - 2024-02-18 11:46:48 --> Helper loaded: lang_helper
INFO - 2024-02-18 11:46:48 --> Helper loaded: security_helper
INFO - 2024-02-18 11:46:48 --> Helper loaded: cookie_helper
INFO - 2024-02-18 11:46:48 --> Database Driver Class Initialized
INFO - 2024-02-18 11:46:48 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-18 11:46:48 --> Parser Class Initialized
INFO - 2024-02-18 11:46:48 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-18 11:46:48 --> Pagination Class Initialized
INFO - 2024-02-18 11:46:48 --> Form Validation Class Initialized
INFO - 2024-02-18 11:46:48 --> Controller Class Initialized
INFO - 2024-02-18 11:46:48 --> Model Class Initialized
DEBUG - 2024-02-18 11:46:48 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-18 11:46:48 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-18 11:46:48 --> Model Class Initialized
DEBUG - 2024-02-18 11:46:48 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-18 11:46:48 --> Model Class Initialized
INFO - 2024-02-18 11:46:48 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice.php
DEBUG - 2024-02-18 11:46:48 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-02-18 11:46:48 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-02-18 11:46:48 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-02-18 11:46:48 --> Model Class Initialized
INFO - 2024-02-18 11:46:48 --> Model Class Initialized
INFO - 2024-02-18 11:46:48 --> Model Class Initialized
INFO - 2024-02-18 11:46:48 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-02-18 11:46:48 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-02-18 11:46:48 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-02-18 11:46:48 --> Final output sent to browser
DEBUG - 2024-02-18 11:46:48 --> Total execution time: 0.1511
ERROR - 2024-02-18 11:46:50 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-18 11:46:50 --> Config Class Initialized
INFO - 2024-02-18 11:46:50 --> Hooks Class Initialized
DEBUG - 2024-02-18 11:46:50 --> UTF-8 Support Enabled
INFO - 2024-02-18 11:46:50 --> Utf8 Class Initialized
INFO - 2024-02-18 11:46:50 --> URI Class Initialized
INFO - 2024-02-18 11:46:50 --> Router Class Initialized
INFO - 2024-02-18 11:46:50 --> Output Class Initialized
INFO - 2024-02-18 11:46:50 --> Security Class Initialized
DEBUG - 2024-02-18 11:46:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-18 11:46:50 --> Input Class Initialized
INFO - 2024-02-18 11:46:50 --> Language Class Initialized
INFO - 2024-02-18 11:46:50 --> Loader Class Initialized
INFO - 2024-02-18 11:46:50 --> Helper loaded: url_helper
INFO - 2024-02-18 11:46:50 --> Helper loaded: file_helper
INFO - 2024-02-18 11:46:50 --> Helper loaded: html_helper
INFO - 2024-02-18 11:46:50 --> Helper loaded: text_helper
INFO - 2024-02-18 11:46:50 --> Helper loaded: form_helper
INFO - 2024-02-18 11:46:50 --> Helper loaded: lang_helper
INFO - 2024-02-18 11:46:50 --> Helper loaded: security_helper
INFO - 2024-02-18 11:46:50 --> Helper loaded: cookie_helper
INFO - 2024-02-18 11:46:50 --> Database Driver Class Initialized
INFO - 2024-02-18 11:46:50 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-18 11:46:50 --> Parser Class Initialized
INFO - 2024-02-18 11:46:50 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-18 11:46:50 --> Pagination Class Initialized
INFO - 2024-02-18 11:46:50 --> Form Validation Class Initialized
INFO - 2024-02-18 11:46:50 --> Controller Class Initialized
INFO - 2024-02-18 11:46:50 --> Model Class Initialized
DEBUG - 2024-02-18 11:46:50 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-18 11:46:50 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-18 11:46:50 --> Model Class Initialized
DEBUG - 2024-02-18 11:46:50 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-18 11:46:50 --> Model Class Initialized
INFO - 2024-02-18 11:46:50 --> Final output sent to browser
DEBUG - 2024-02-18 11:46:50 --> Total execution time: 0.0456
ERROR - 2024-02-18 11:47:00 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-18 11:47:00 --> Config Class Initialized
INFO - 2024-02-18 11:47:00 --> Hooks Class Initialized
DEBUG - 2024-02-18 11:47:00 --> UTF-8 Support Enabled
INFO - 2024-02-18 11:47:00 --> Utf8 Class Initialized
INFO - 2024-02-18 11:47:00 --> URI Class Initialized
INFO - 2024-02-18 11:47:00 --> Router Class Initialized
INFO - 2024-02-18 11:47:00 --> Output Class Initialized
INFO - 2024-02-18 11:47:00 --> Security Class Initialized
DEBUG - 2024-02-18 11:47:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-18 11:47:00 --> Input Class Initialized
INFO - 2024-02-18 11:47:00 --> Language Class Initialized
INFO - 2024-02-18 11:47:00 --> Loader Class Initialized
INFO - 2024-02-18 11:47:00 --> Helper loaded: url_helper
INFO - 2024-02-18 11:47:00 --> Helper loaded: file_helper
INFO - 2024-02-18 11:47:00 --> Helper loaded: html_helper
INFO - 2024-02-18 11:47:00 --> Helper loaded: text_helper
INFO - 2024-02-18 11:47:00 --> Helper loaded: form_helper
INFO - 2024-02-18 11:47:00 --> Helper loaded: lang_helper
INFO - 2024-02-18 11:47:00 --> Helper loaded: security_helper
INFO - 2024-02-18 11:47:00 --> Helper loaded: cookie_helper
INFO - 2024-02-18 11:47:00 --> Database Driver Class Initialized
INFO - 2024-02-18 11:47:00 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-18 11:47:00 --> Parser Class Initialized
INFO - 2024-02-18 11:47:00 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-18 11:47:00 --> Pagination Class Initialized
INFO - 2024-02-18 11:47:00 --> Form Validation Class Initialized
INFO - 2024-02-18 11:47:00 --> Controller Class Initialized
INFO - 2024-02-18 11:47:00 --> Model Class Initialized
DEBUG - 2024-02-18 11:47:00 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-18 11:47:00 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-18 11:47:00 --> Model Class Initialized
DEBUG - 2024-02-18 11:47:00 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-18 11:47:00 --> Model Class Initialized
DEBUG - 2024-02-18 11:47:00 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-18 11:47:00 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice_html.php
DEBUG - 2024-02-18 11:47:00 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-02-18 11:47:00 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-02-18 11:47:00 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-02-18 11:47:00 --> Model Class Initialized
INFO - 2024-02-18 11:47:00 --> Model Class Initialized
INFO - 2024-02-18 11:47:00 --> Model Class Initialized
INFO - 2024-02-18 11:47:01 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-02-18 11:47:01 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-02-18 11:47:01 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-02-18 11:47:01 --> Final output sent to browser
DEBUG - 2024-02-18 11:47:01 --> Total execution time: 0.1552
ERROR - 2024-02-18 11:47:07 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-18 11:47:07 --> Config Class Initialized
INFO - 2024-02-18 11:47:07 --> Hooks Class Initialized
DEBUG - 2024-02-18 11:47:07 --> UTF-8 Support Enabled
INFO - 2024-02-18 11:47:07 --> Utf8 Class Initialized
INFO - 2024-02-18 11:47:07 --> URI Class Initialized
INFO - 2024-02-18 11:47:07 --> Router Class Initialized
INFO - 2024-02-18 11:47:07 --> Output Class Initialized
INFO - 2024-02-18 11:47:07 --> Security Class Initialized
DEBUG - 2024-02-18 11:47:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-18 11:47:07 --> Input Class Initialized
INFO - 2024-02-18 11:47:07 --> Language Class Initialized
INFO - 2024-02-18 11:47:07 --> Loader Class Initialized
INFO - 2024-02-18 11:47:07 --> Helper loaded: url_helper
INFO - 2024-02-18 11:47:07 --> Helper loaded: file_helper
INFO - 2024-02-18 11:47:07 --> Helper loaded: html_helper
INFO - 2024-02-18 11:47:07 --> Helper loaded: text_helper
INFO - 2024-02-18 11:47:07 --> Helper loaded: form_helper
INFO - 2024-02-18 11:47:07 --> Helper loaded: lang_helper
INFO - 2024-02-18 11:47:07 --> Helper loaded: security_helper
INFO - 2024-02-18 11:47:07 --> Helper loaded: cookie_helper
INFO - 2024-02-18 11:47:07 --> Database Driver Class Initialized
INFO - 2024-02-18 11:47:07 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-18 11:47:07 --> Parser Class Initialized
INFO - 2024-02-18 11:47:07 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-18 11:47:07 --> Pagination Class Initialized
INFO - 2024-02-18 11:47:07 --> Form Validation Class Initialized
INFO - 2024-02-18 11:47:07 --> Controller Class Initialized
INFO - 2024-02-18 11:47:07 --> Model Class Initialized
DEBUG - 2024-02-18 11:47:07 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-18 11:47:07 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-18 11:47:07 --> Model Class Initialized
DEBUG - 2024-02-18 11:47:07 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-18 11:47:07 --> Model Class Initialized
INFO - 2024-02-18 11:47:07 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice.php
DEBUG - 2024-02-18 11:47:07 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-02-18 11:47:07 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-02-18 11:47:07 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-02-18 11:47:07 --> Model Class Initialized
INFO - 2024-02-18 11:47:07 --> Model Class Initialized
INFO - 2024-02-18 11:47:07 --> Model Class Initialized
INFO - 2024-02-18 11:47:07 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-02-18 11:47:07 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-02-18 11:47:07 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-02-18 11:47:07 --> Final output sent to browser
DEBUG - 2024-02-18 11:47:07 --> Total execution time: 0.1444
ERROR - 2024-02-18 11:47:07 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-18 11:47:07 --> Config Class Initialized
INFO - 2024-02-18 11:47:07 --> Hooks Class Initialized
DEBUG - 2024-02-18 11:47:07 --> UTF-8 Support Enabled
INFO - 2024-02-18 11:47:07 --> Utf8 Class Initialized
INFO - 2024-02-18 11:47:07 --> URI Class Initialized
INFO - 2024-02-18 11:47:07 --> Router Class Initialized
INFO - 2024-02-18 11:47:07 --> Output Class Initialized
INFO - 2024-02-18 11:47:07 --> Security Class Initialized
DEBUG - 2024-02-18 11:47:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-18 11:47:07 --> Input Class Initialized
INFO - 2024-02-18 11:47:07 --> Language Class Initialized
INFO - 2024-02-18 11:47:07 --> Loader Class Initialized
INFO - 2024-02-18 11:47:07 --> Helper loaded: url_helper
INFO - 2024-02-18 11:47:07 --> Helper loaded: file_helper
INFO - 2024-02-18 11:47:07 --> Helper loaded: html_helper
INFO - 2024-02-18 11:47:07 --> Helper loaded: text_helper
INFO - 2024-02-18 11:47:07 --> Helper loaded: form_helper
INFO - 2024-02-18 11:47:07 --> Helper loaded: lang_helper
INFO - 2024-02-18 11:47:07 --> Helper loaded: security_helper
INFO - 2024-02-18 11:47:07 --> Helper loaded: cookie_helper
INFO - 2024-02-18 11:47:07 --> Database Driver Class Initialized
INFO - 2024-02-18 11:47:07 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-18 11:47:07 --> Parser Class Initialized
INFO - 2024-02-18 11:47:07 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-18 11:47:07 --> Pagination Class Initialized
INFO - 2024-02-18 11:47:07 --> Form Validation Class Initialized
INFO - 2024-02-18 11:47:07 --> Controller Class Initialized
INFO - 2024-02-18 11:47:07 --> Model Class Initialized
DEBUG - 2024-02-18 11:47:07 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-18 11:47:07 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-18 11:47:07 --> Model Class Initialized
DEBUG - 2024-02-18 11:47:07 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-18 11:47:07 --> Model Class Initialized
INFO - 2024-02-18 11:47:07 --> Final output sent to browser
DEBUG - 2024-02-18 11:47:07 --> Total execution time: 0.0380
ERROR - 2024-02-18 11:47:08 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-18 11:47:08 --> Config Class Initialized
INFO - 2024-02-18 11:47:08 --> Hooks Class Initialized
DEBUG - 2024-02-18 11:47:08 --> UTF-8 Support Enabled
INFO - 2024-02-18 11:47:08 --> Utf8 Class Initialized
INFO - 2024-02-18 11:47:08 --> URI Class Initialized
DEBUG - 2024-02-18 11:47:08 --> No URI present. Default controller set.
INFO - 2024-02-18 11:47:08 --> Router Class Initialized
INFO - 2024-02-18 11:47:08 --> Output Class Initialized
INFO - 2024-02-18 11:47:08 --> Security Class Initialized
DEBUG - 2024-02-18 11:47:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-18 11:47:08 --> Input Class Initialized
INFO - 2024-02-18 11:47:08 --> Language Class Initialized
INFO - 2024-02-18 11:47:08 --> Loader Class Initialized
INFO - 2024-02-18 11:47:08 --> Helper loaded: url_helper
INFO - 2024-02-18 11:47:08 --> Helper loaded: file_helper
INFO - 2024-02-18 11:47:08 --> Helper loaded: html_helper
INFO - 2024-02-18 11:47:08 --> Helper loaded: text_helper
INFO - 2024-02-18 11:47:08 --> Helper loaded: form_helper
INFO - 2024-02-18 11:47:08 --> Helper loaded: lang_helper
INFO - 2024-02-18 11:47:08 --> Helper loaded: security_helper
INFO - 2024-02-18 11:47:08 --> Helper loaded: cookie_helper
INFO - 2024-02-18 11:47:08 --> Database Driver Class Initialized
INFO - 2024-02-18 11:47:08 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-18 11:47:08 --> Parser Class Initialized
INFO - 2024-02-18 11:47:08 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-18 11:47:08 --> Pagination Class Initialized
INFO - 2024-02-18 11:47:08 --> Form Validation Class Initialized
INFO - 2024-02-18 11:47:08 --> Controller Class Initialized
INFO - 2024-02-18 11:47:08 --> Model Class Initialized
DEBUG - 2024-02-18 11:47:08 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-18 11:47:08 --> Model Class Initialized
DEBUG - 2024-02-18 11:47:08 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-18 11:47:08 --> Model Class Initialized
INFO - 2024-02-18 11:47:08 --> Model Class Initialized
INFO - 2024-02-18 11:47:08 --> Model Class Initialized
INFO - 2024-02-18 11:47:08 --> Model Class Initialized
DEBUG - 2024-02-18 11:47:08 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-18 11:47:08 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-18 11:47:08 --> Model Class Initialized
INFO - 2024-02-18 11:47:08 --> Model Class Initialized
INFO - 2024-02-18 11:47:08 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2024-02-18 11:47:08 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-02-18 11:47:08 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-02-18 11:47:08 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-02-18 11:47:08 --> Model Class Initialized
INFO - 2024-02-18 11:47:08 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-02-18 11:47:08 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-02-18 11:47:08 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-02-18 11:47:08 --> Final output sent to browser
DEBUG - 2024-02-18 11:47:08 --> Total execution time: 0.2211
ERROR - 2024-02-18 12:53:12 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-18 12:53:12 --> Config Class Initialized
INFO - 2024-02-18 12:53:12 --> Hooks Class Initialized
DEBUG - 2024-02-18 12:53:12 --> UTF-8 Support Enabled
INFO - 2024-02-18 12:53:12 --> Utf8 Class Initialized
INFO - 2024-02-18 12:53:12 --> URI Class Initialized
DEBUG - 2024-02-18 12:53:12 --> No URI present. Default controller set.
INFO - 2024-02-18 12:53:12 --> Router Class Initialized
INFO - 2024-02-18 12:53:12 --> Output Class Initialized
INFO - 2024-02-18 12:53:12 --> Security Class Initialized
DEBUG - 2024-02-18 12:53:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-18 12:53:12 --> Input Class Initialized
INFO - 2024-02-18 12:53:12 --> Language Class Initialized
INFO - 2024-02-18 12:53:12 --> Loader Class Initialized
INFO - 2024-02-18 12:53:12 --> Helper loaded: url_helper
INFO - 2024-02-18 12:53:12 --> Helper loaded: file_helper
INFO - 2024-02-18 12:53:12 --> Helper loaded: html_helper
INFO - 2024-02-18 12:53:12 --> Helper loaded: text_helper
INFO - 2024-02-18 12:53:12 --> Helper loaded: form_helper
INFO - 2024-02-18 12:53:12 --> Helper loaded: lang_helper
INFO - 2024-02-18 12:53:12 --> Helper loaded: security_helper
INFO - 2024-02-18 12:53:12 --> Helper loaded: cookie_helper
INFO - 2024-02-18 12:53:12 --> Database Driver Class Initialized
INFO - 2024-02-18 12:53:12 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-18 12:53:12 --> Parser Class Initialized
INFO - 2024-02-18 12:53:12 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-18 12:53:12 --> Pagination Class Initialized
INFO - 2024-02-18 12:53:12 --> Form Validation Class Initialized
INFO - 2024-02-18 12:53:12 --> Controller Class Initialized
INFO - 2024-02-18 12:53:12 --> Model Class Initialized
DEBUG - 2024-02-18 12:53:12 --> Session class already loaded. Second attempt ignored.
ERROR - 2024-02-18 12:53:12 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-18 12:53:12 --> Config Class Initialized
INFO - 2024-02-18 12:53:12 --> Hooks Class Initialized
DEBUG - 2024-02-18 12:53:12 --> UTF-8 Support Enabled
INFO - 2024-02-18 12:53:12 --> Utf8 Class Initialized
INFO - 2024-02-18 12:53:12 --> URI Class Initialized
INFO - 2024-02-18 12:53:12 --> Router Class Initialized
INFO - 2024-02-18 12:53:12 --> Output Class Initialized
INFO - 2024-02-18 12:53:12 --> Security Class Initialized
DEBUG - 2024-02-18 12:53:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-18 12:53:12 --> Input Class Initialized
INFO - 2024-02-18 12:53:12 --> Language Class Initialized
INFO - 2024-02-18 12:53:12 --> Loader Class Initialized
INFO - 2024-02-18 12:53:12 --> Helper loaded: url_helper
INFO - 2024-02-18 12:53:12 --> Helper loaded: file_helper
INFO - 2024-02-18 12:53:12 --> Helper loaded: html_helper
INFO - 2024-02-18 12:53:12 --> Helper loaded: text_helper
INFO - 2024-02-18 12:53:12 --> Helper loaded: form_helper
INFO - 2024-02-18 12:53:12 --> Helper loaded: lang_helper
INFO - 2024-02-18 12:53:12 --> Helper loaded: security_helper
INFO - 2024-02-18 12:53:12 --> Helper loaded: cookie_helper
INFO - 2024-02-18 12:53:12 --> Database Driver Class Initialized
INFO - 2024-02-18 12:53:12 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-18 12:53:12 --> Parser Class Initialized
INFO - 2024-02-18 12:53:12 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-18 12:53:12 --> Pagination Class Initialized
INFO - 2024-02-18 12:53:12 --> Form Validation Class Initialized
INFO - 2024-02-18 12:53:12 --> Controller Class Initialized
INFO - 2024-02-18 12:53:12 --> Model Class Initialized
DEBUG - 2024-02-18 12:53:12 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-18 12:53:12 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2024-02-18 12:53:12 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-02-18 12:53:12 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-02-18 12:53:12 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-02-18 12:53:12 --> Model Class Initialized
INFO - 2024-02-18 12:53:12 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-02-18 12:53:12 --> Final output sent to browser
DEBUG - 2024-02-18 12:53:12 --> Total execution time: 0.0376
ERROR - 2024-02-18 12:53:24 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-18 12:53:24 --> Config Class Initialized
INFO - 2024-02-18 12:53:24 --> Hooks Class Initialized
DEBUG - 2024-02-18 12:53:24 --> UTF-8 Support Enabled
INFO - 2024-02-18 12:53:24 --> Utf8 Class Initialized
INFO - 2024-02-18 12:53:24 --> URI Class Initialized
INFO - 2024-02-18 12:53:24 --> Router Class Initialized
INFO - 2024-02-18 12:53:24 --> Output Class Initialized
INFO - 2024-02-18 12:53:24 --> Security Class Initialized
DEBUG - 2024-02-18 12:53:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-18 12:53:24 --> Input Class Initialized
INFO - 2024-02-18 12:53:24 --> Language Class Initialized
INFO - 2024-02-18 12:53:24 --> Loader Class Initialized
INFO - 2024-02-18 12:53:24 --> Helper loaded: url_helper
INFO - 2024-02-18 12:53:24 --> Helper loaded: file_helper
INFO - 2024-02-18 12:53:24 --> Helper loaded: html_helper
INFO - 2024-02-18 12:53:24 --> Helper loaded: text_helper
INFO - 2024-02-18 12:53:24 --> Helper loaded: form_helper
INFO - 2024-02-18 12:53:24 --> Helper loaded: lang_helper
INFO - 2024-02-18 12:53:24 --> Helper loaded: security_helper
INFO - 2024-02-18 12:53:24 --> Helper loaded: cookie_helper
INFO - 2024-02-18 12:53:24 --> Database Driver Class Initialized
INFO - 2024-02-18 12:53:24 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-18 12:53:24 --> Parser Class Initialized
INFO - 2024-02-18 12:53:24 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-18 12:53:24 --> Pagination Class Initialized
INFO - 2024-02-18 12:53:24 --> Form Validation Class Initialized
INFO - 2024-02-18 12:53:24 --> Controller Class Initialized
INFO - 2024-02-18 12:53:24 --> Model Class Initialized
DEBUG - 2024-02-18 12:53:24 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-18 12:53:24 --> Model Class Initialized
INFO - 2024-02-18 12:53:24 --> Final output sent to browser
DEBUG - 2024-02-18 12:53:24 --> Total execution time: 0.0187
ERROR - 2024-02-18 12:53:24 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-18 12:53:24 --> Config Class Initialized
INFO - 2024-02-18 12:53:24 --> Hooks Class Initialized
DEBUG - 2024-02-18 12:53:24 --> UTF-8 Support Enabled
INFO - 2024-02-18 12:53:24 --> Utf8 Class Initialized
INFO - 2024-02-18 12:53:24 --> URI Class Initialized
DEBUG - 2024-02-18 12:53:24 --> No URI present. Default controller set.
INFO - 2024-02-18 12:53:24 --> Router Class Initialized
INFO - 2024-02-18 12:53:24 --> Output Class Initialized
INFO - 2024-02-18 12:53:24 --> Security Class Initialized
DEBUG - 2024-02-18 12:53:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-18 12:53:24 --> Input Class Initialized
INFO - 2024-02-18 12:53:24 --> Language Class Initialized
INFO - 2024-02-18 12:53:24 --> Loader Class Initialized
INFO - 2024-02-18 12:53:24 --> Helper loaded: url_helper
INFO - 2024-02-18 12:53:24 --> Helper loaded: file_helper
INFO - 2024-02-18 12:53:24 --> Helper loaded: html_helper
INFO - 2024-02-18 12:53:24 --> Helper loaded: text_helper
INFO - 2024-02-18 12:53:24 --> Helper loaded: form_helper
INFO - 2024-02-18 12:53:24 --> Helper loaded: lang_helper
INFO - 2024-02-18 12:53:24 --> Helper loaded: security_helper
INFO - 2024-02-18 12:53:24 --> Helper loaded: cookie_helper
INFO - 2024-02-18 12:53:24 --> Database Driver Class Initialized
INFO - 2024-02-18 12:53:24 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-18 12:53:24 --> Parser Class Initialized
INFO - 2024-02-18 12:53:24 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-18 12:53:24 --> Pagination Class Initialized
INFO - 2024-02-18 12:53:24 --> Form Validation Class Initialized
INFO - 2024-02-18 12:53:24 --> Controller Class Initialized
INFO - 2024-02-18 12:53:24 --> Model Class Initialized
DEBUG - 2024-02-18 12:53:24 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-18 12:53:24 --> Model Class Initialized
DEBUG - 2024-02-18 12:53:24 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-18 12:53:24 --> Model Class Initialized
INFO - 2024-02-18 12:53:24 --> Model Class Initialized
INFO - 2024-02-18 12:53:24 --> Model Class Initialized
INFO - 2024-02-18 12:53:24 --> Model Class Initialized
DEBUG - 2024-02-18 12:53:24 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-18 12:53:24 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-18 12:53:24 --> Model Class Initialized
INFO - 2024-02-18 12:53:24 --> Model Class Initialized
INFO - 2024-02-18 12:53:24 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2024-02-18 12:53:24 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-02-18 12:53:24 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-02-18 12:53:24 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-02-18 12:53:24 --> Model Class Initialized
INFO - 2024-02-18 12:53:24 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-02-18 12:53:24 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-02-18 12:53:24 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-02-18 12:53:24 --> Final output sent to browser
DEBUG - 2024-02-18 12:53:24 --> Total execution time: 0.2136
ERROR - 2024-02-18 12:53:33 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-18 12:53:33 --> Config Class Initialized
INFO - 2024-02-18 12:53:33 --> Hooks Class Initialized
DEBUG - 2024-02-18 12:53:33 --> UTF-8 Support Enabled
INFO - 2024-02-18 12:53:33 --> Utf8 Class Initialized
INFO - 2024-02-18 12:53:33 --> URI Class Initialized
INFO - 2024-02-18 12:53:33 --> Router Class Initialized
INFO - 2024-02-18 12:53:33 --> Output Class Initialized
INFO - 2024-02-18 12:53:33 --> Security Class Initialized
DEBUG - 2024-02-18 12:53:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-18 12:53:33 --> Input Class Initialized
INFO - 2024-02-18 12:53:33 --> Language Class Initialized
INFO - 2024-02-18 12:53:33 --> Loader Class Initialized
INFO - 2024-02-18 12:53:33 --> Helper loaded: url_helper
INFO - 2024-02-18 12:53:33 --> Helper loaded: file_helper
INFO - 2024-02-18 12:53:33 --> Helper loaded: html_helper
INFO - 2024-02-18 12:53:33 --> Helper loaded: text_helper
INFO - 2024-02-18 12:53:33 --> Helper loaded: form_helper
INFO - 2024-02-18 12:53:33 --> Helper loaded: lang_helper
INFO - 2024-02-18 12:53:33 --> Helper loaded: security_helper
INFO - 2024-02-18 12:53:33 --> Helper loaded: cookie_helper
INFO - 2024-02-18 12:53:33 --> Database Driver Class Initialized
INFO - 2024-02-18 12:53:33 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-18 12:53:33 --> Parser Class Initialized
INFO - 2024-02-18 12:53:33 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-18 12:53:33 --> Pagination Class Initialized
INFO - 2024-02-18 12:53:33 --> Form Validation Class Initialized
INFO - 2024-02-18 12:53:33 --> Controller Class Initialized
INFO - 2024-02-18 12:53:33 --> Model Class Initialized
DEBUG - 2024-02-18 12:53:33 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-18 12:53:33 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-18 12:53:33 --> Model Class Initialized
DEBUG - 2024-02-18 12:53:33 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-18 12:53:33 --> Model Class Initialized
INFO - 2024-02-18 12:53:33 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice.php
DEBUG - 2024-02-18 12:53:33 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-02-18 12:53:33 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-02-18 12:53:33 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-02-18 12:53:33 --> Model Class Initialized
INFO - 2024-02-18 12:53:33 --> Model Class Initialized
INFO - 2024-02-18 12:53:33 --> Model Class Initialized
INFO - 2024-02-18 12:53:33 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-02-18 12:53:33 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-02-18 12:53:33 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-02-18 12:53:33 --> Final output sent to browser
DEBUG - 2024-02-18 12:53:33 --> Total execution time: 0.1378
ERROR - 2024-02-18 12:53:33 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-18 12:53:33 --> Config Class Initialized
INFO - 2024-02-18 12:53:33 --> Hooks Class Initialized
DEBUG - 2024-02-18 12:53:33 --> UTF-8 Support Enabled
INFO - 2024-02-18 12:53:33 --> Utf8 Class Initialized
INFO - 2024-02-18 12:53:33 --> URI Class Initialized
INFO - 2024-02-18 12:53:33 --> Router Class Initialized
INFO - 2024-02-18 12:53:33 --> Output Class Initialized
INFO - 2024-02-18 12:53:33 --> Security Class Initialized
DEBUG - 2024-02-18 12:53:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-18 12:53:33 --> Input Class Initialized
INFO - 2024-02-18 12:53:33 --> Language Class Initialized
INFO - 2024-02-18 12:53:33 --> Loader Class Initialized
INFO - 2024-02-18 12:53:33 --> Helper loaded: url_helper
INFO - 2024-02-18 12:53:33 --> Helper loaded: file_helper
INFO - 2024-02-18 12:53:33 --> Helper loaded: html_helper
INFO - 2024-02-18 12:53:33 --> Helper loaded: text_helper
INFO - 2024-02-18 12:53:33 --> Helper loaded: form_helper
INFO - 2024-02-18 12:53:33 --> Helper loaded: lang_helper
INFO - 2024-02-18 12:53:33 --> Helper loaded: security_helper
INFO - 2024-02-18 12:53:33 --> Helper loaded: cookie_helper
INFO - 2024-02-18 12:53:33 --> Database Driver Class Initialized
INFO - 2024-02-18 12:53:33 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-18 12:53:33 --> Parser Class Initialized
INFO - 2024-02-18 12:53:33 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-18 12:53:33 --> Pagination Class Initialized
INFO - 2024-02-18 12:53:33 --> Form Validation Class Initialized
INFO - 2024-02-18 12:53:33 --> Controller Class Initialized
INFO - 2024-02-18 12:53:33 --> Model Class Initialized
DEBUG - 2024-02-18 12:53:33 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-18 12:53:33 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-18 12:53:33 --> Model Class Initialized
DEBUG - 2024-02-18 12:53:33 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-18 12:53:33 --> Model Class Initialized
INFO - 2024-02-18 12:53:33 --> Final output sent to browser
DEBUG - 2024-02-18 12:53:33 --> Total execution time: 0.0219
ERROR - 2024-02-18 12:53:56 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-18 12:53:56 --> Config Class Initialized
INFO - 2024-02-18 12:53:56 --> Hooks Class Initialized
DEBUG - 2024-02-18 12:53:56 --> UTF-8 Support Enabled
INFO - 2024-02-18 12:53:56 --> Utf8 Class Initialized
INFO - 2024-02-18 12:53:56 --> URI Class Initialized
INFO - 2024-02-18 12:53:56 --> Router Class Initialized
INFO - 2024-02-18 12:53:56 --> Output Class Initialized
INFO - 2024-02-18 12:53:56 --> Security Class Initialized
DEBUG - 2024-02-18 12:53:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-18 12:53:56 --> Input Class Initialized
INFO - 2024-02-18 12:53:56 --> Language Class Initialized
INFO - 2024-02-18 12:53:56 --> Loader Class Initialized
INFO - 2024-02-18 12:53:56 --> Helper loaded: url_helper
INFO - 2024-02-18 12:53:56 --> Helper loaded: file_helper
INFO - 2024-02-18 12:53:56 --> Helper loaded: html_helper
INFO - 2024-02-18 12:53:56 --> Helper loaded: text_helper
INFO - 2024-02-18 12:53:56 --> Helper loaded: form_helper
INFO - 2024-02-18 12:53:56 --> Helper loaded: lang_helper
INFO - 2024-02-18 12:53:56 --> Helper loaded: security_helper
INFO - 2024-02-18 12:53:56 --> Helper loaded: cookie_helper
INFO - 2024-02-18 12:53:56 --> Database Driver Class Initialized
INFO - 2024-02-18 12:53:56 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-18 12:53:56 --> Parser Class Initialized
INFO - 2024-02-18 12:53:56 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-18 12:53:56 --> Pagination Class Initialized
INFO - 2024-02-18 12:53:56 --> Form Validation Class Initialized
INFO - 2024-02-18 12:53:56 --> Controller Class Initialized
INFO - 2024-02-18 12:53:56 --> Model Class Initialized
INFO - 2024-02-18 12:53:56 --> Model Class Initialized
INFO - 2024-02-18 12:53:56 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/report/out_of_date.php
DEBUG - 2024-02-18 12:53:56 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-02-18 12:53:56 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-02-18 12:53:56 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-02-18 12:53:56 --> Model Class Initialized
INFO - 2024-02-18 12:53:56 --> Model Class Initialized
INFO - 2024-02-18 12:53:56 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-02-18 12:53:56 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-02-18 12:53:56 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-02-18 12:53:56 --> Final output sent to browser
DEBUG - 2024-02-18 12:53:56 --> Total execution time: 0.1568
ERROR - 2024-02-18 12:53:57 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-18 12:53:57 --> Config Class Initialized
INFO - 2024-02-18 12:53:57 --> Hooks Class Initialized
DEBUG - 2024-02-18 12:53:57 --> UTF-8 Support Enabled
INFO - 2024-02-18 12:53:57 --> Utf8 Class Initialized
INFO - 2024-02-18 12:53:57 --> URI Class Initialized
INFO - 2024-02-18 12:53:57 --> Router Class Initialized
INFO - 2024-02-18 12:53:57 --> Output Class Initialized
INFO - 2024-02-18 12:53:57 --> Security Class Initialized
DEBUG - 2024-02-18 12:53:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-18 12:53:57 --> Input Class Initialized
INFO - 2024-02-18 12:53:57 --> Language Class Initialized
INFO - 2024-02-18 12:53:57 --> Loader Class Initialized
INFO - 2024-02-18 12:53:57 --> Helper loaded: url_helper
INFO - 2024-02-18 12:53:57 --> Helper loaded: file_helper
INFO - 2024-02-18 12:53:57 --> Helper loaded: html_helper
INFO - 2024-02-18 12:53:57 --> Helper loaded: text_helper
INFO - 2024-02-18 12:53:57 --> Helper loaded: form_helper
INFO - 2024-02-18 12:53:57 --> Helper loaded: lang_helper
INFO - 2024-02-18 12:53:57 --> Helper loaded: security_helper
INFO - 2024-02-18 12:53:57 --> Helper loaded: cookie_helper
INFO - 2024-02-18 12:53:57 --> Database Driver Class Initialized
INFO - 2024-02-18 12:53:57 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-18 12:53:57 --> Parser Class Initialized
INFO - 2024-02-18 12:53:57 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-18 12:53:57 --> Pagination Class Initialized
INFO - 2024-02-18 12:53:57 --> Form Validation Class Initialized
INFO - 2024-02-18 12:53:57 --> Controller Class Initialized
INFO - 2024-02-18 12:53:57 --> Model Class Initialized
INFO - 2024-02-18 12:53:57 --> Model Class Initialized
INFO - 2024-02-18 12:53:57 --> Final output sent to browser
DEBUG - 2024-02-18 12:53:57 --> Total execution time: 0.0766
ERROR - 2024-02-18 12:54:35 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-18 12:54:35 --> Config Class Initialized
INFO - 2024-02-18 12:54:35 --> Hooks Class Initialized
DEBUG - 2024-02-18 12:54:35 --> UTF-8 Support Enabled
INFO - 2024-02-18 12:54:35 --> Utf8 Class Initialized
INFO - 2024-02-18 12:54:35 --> URI Class Initialized
INFO - 2024-02-18 12:54:35 --> Router Class Initialized
INFO - 2024-02-18 12:54:35 --> Output Class Initialized
INFO - 2024-02-18 12:54:35 --> Security Class Initialized
DEBUG - 2024-02-18 12:54:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-18 12:54:35 --> Input Class Initialized
INFO - 2024-02-18 12:54:35 --> Language Class Initialized
INFO - 2024-02-18 12:54:35 --> Loader Class Initialized
INFO - 2024-02-18 12:54:35 --> Helper loaded: url_helper
INFO - 2024-02-18 12:54:35 --> Helper loaded: file_helper
INFO - 2024-02-18 12:54:35 --> Helper loaded: html_helper
INFO - 2024-02-18 12:54:35 --> Helper loaded: text_helper
INFO - 2024-02-18 12:54:35 --> Helper loaded: form_helper
INFO - 2024-02-18 12:54:35 --> Helper loaded: lang_helper
INFO - 2024-02-18 12:54:35 --> Helper loaded: security_helper
INFO - 2024-02-18 12:54:35 --> Helper loaded: cookie_helper
INFO - 2024-02-18 12:54:35 --> Database Driver Class Initialized
INFO - 2024-02-18 12:54:35 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-18 12:54:35 --> Parser Class Initialized
INFO - 2024-02-18 12:54:35 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-18 12:54:35 --> Pagination Class Initialized
INFO - 2024-02-18 12:54:35 --> Form Validation Class Initialized
INFO - 2024-02-18 12:54:35 --> Controller Class Initialized
INFO - 2024-02-18 12:54:35 --> Model Class Initialized
INFO - 2024-02-18 12:54:35 --> Model Class Initialized
INFO - 2024-02-18 12:54:35 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/report/out_of_stock.php
DEBUG - 2024-02-18 12:54:35 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-02-18 12:54:35 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-02-18 12:54:35 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-02-18 12:54:35 --> Model Class Initialized
INFO - 2024-02-18 12:54:35 --> Model Class Initialized
INFO - 2024-02-18 12:54:35 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-02-18 12:54:35 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-02-18 12:54:35 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-02-18 12:54:35 --> Final output sent to browser
DEBUG - 2024-02-18 12:54:35 --> Total execution time: 0.1903
ERROR - 2024-02-18 12:54:35 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-18 12:54:35 --> Config Class Initialized
INFO - 2024-02-18 12:54:35 --> Hooks Class Initialized
DEBUG - 2024-02-18 12:54:35 --> UTF-8 Support Enabled
INFO - 2024-02-18 12:54:35 --> Utf8 Class Initialized
INFO - 2024-02-18 12:54:35 --> URI Class Initialized
INFO - 2024-02-18 12:54:35 --> Router Class Initialized
INFO - 2024-02-18 12:54:35 --> Output Class Initialized
INFO - 2024-02-18 12:54:35 --> Security Class Initialized
DEBUG - 2024-02-18 12:54:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-18 12:54:35 --> Input Class Initialized
INFO - 2024-02-18 12:54:35 --> Language Class Initialized
INFO - 2024-02-18 12:54:35 --> Loader Class Initialized
INFO - 2024-02-18 12:54:35 --> Helper loaded: url_helper
INFO - 2024-02-18 12:54:35 --> Helper loaded: file_helper
INFO - 2024-02-18 12:54:35 --> Helper loaded: html_helper
INFO - 2024-02-18 12:54:35 --> Helper loaded: text_helper
INFO - 2024-02-18 12:54:35 --> Helper loaded: form_helper
INFO - 2024-02-18 12:54:35 --> Helper loaded: lang_helper
INFO - 2024-02-18 12:54:35 --> Helper loaded: security_helper
INFO - 2024-02-18 12:54:35 --> Helper loaded: cookie_helper
INFO - 2024-02-18 12:54:35 --> Database Driver Class Initialized
INFO - 2024-02-18 12:54:35 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-18 12:54:35 --> Parser Class Initialized
INFO - 2024-02-18 12:54:35 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-18 12:54:35 --> Pagination Class Initialized
INFO - 2024-02-18 12:54:35 --> Form Validation Class Initialized
INFO - 2024-02-18 12:54:35 --> Controller Class Initialized
INFO - 2024-02-18 12:54:35 --> Model Class Initialized
INFO - 2024-02-18 12:54:35 --> Model Class Initialized
INFO - 2024-02-18 12:54:36 --> Final output sent to browser
DEBUG - 2024-02-18 12:54:36 --> Total execution time: 0.1983
ERROR - 2024-02-18 12:54:59 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-18 12:54:59 --> Config Class Initialized
INFO - 2024-02-18 12:54:59 --> Hooks Class Initialized
DEBUG - 2024-02-18 12:54:59 --> UTF-8 Support Enabled
INFO - 2024-02-18 12:54:59 --> Utf8 Class Initialized
INFO - 2024-02-18 12:54:59 --> URI Class Initialized
INFO - 2024-02-18 12:54:59 --> Router Class Initialized
INFO - 2024-02-18 12:54:59 --> Output Class Initialized
INFO - 2024-02-18 12:54:59 --> Security Class Initialized
DEBUG - 2024-02-18 12:54:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-18 12:54:59 --> Input Class Initialized
INFO - 2024-02-18 12:54:59 --> Language Class Initialized
INFO - 2024-02-18 12:54:59 --> Loader Class Initialized
INFO - 2024-02-18 12:54:59 --> Helper loaded: url_helper
INFO - 2024-02-18 12:54:59 --> Helper loaded: file_helper
INFO - 2024-02-18 12:54:59 --> Helper loaded: html_helper
INFO - 2024-02-18 12:54:59 --> Helper loaded: text_helper
INFO - 2024-02-18 12:54:59 --> Helper loaded: form_helper
INFO - 2024-02-18 12:54:59 --> Helper loaded: lang_helper
INFO - 2024-02-18 12:54:59 --> Helper loaded: security_helper
INFO - 2024-02-18 12:54:59 --> Helper loaded: cookie_helper
INFO - 2024-02-18 12:54:59 --> Database Driver Class Initialized
INFO - 2024-02-18 12:54:59 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-18 12:54:59 --> Parser Class Initialized
INFO - 2024-02-18 12:54:59 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-18 12:54:59 --> Pagination Class Initialized
INFO - 2024-02-18 12:54:59 --> Form Validation Class Initialized
INFO - 2024-02-18 12:54:59 --> Controller Class Initialized
INFO - 2024-02-18 12:54:59 --> Model Class Initialized
INFO - 2024-02-18 12:54:59 --> Model Class Initialized
INFO - 2024-02-18 12:54:59 --> Final output sent to browser
DEBUG - 2024-02-18 12:54:59 --> Total execution time: 0.1898
ERROR - 2024-02-18 12:56:01 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-18 12:56:01 --> Config Class Initialized
INFO - 2024-02-18 12:56:01 --> Hooks Class Initialized
DEBUG - 2024-02-18 12:56:01 --> UTF-8 Support Enabled
INFO - 2024-02-18 12:56:01 --> Utf8 Class Initialized
INFO - 2024-02-18 12:56:01 --> URI Class Initialized
INFO - 2024-02-18 12:56:01 --> Router Class Initialized
INFO - 2024-02-18 12:56:01 --> Output Class Initialized
INFO - 2024-02-18 12:56:01 --> Security Class Initialized
DEBUG - 2024-02-18 12:56:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-18 12:56:01 --> Input Class Initialized
INFO - 2024-02-18 12:56:01 --> Language Class Initialized
INFO - 2024-02-18 12:56:01 --> Loader Class Initialized
INFO - 2024-02-18 12:56:01 --> Helper loaded: url_helper
INFO - 2024-02-18 12:56:01 --> Helper loaded: file_helper
INFO - 2024-02-18 12:56:01 --> Helper loaded: html_helper
INFO - 2024-02-18 12:56:01 --> Helper loaded: text_helper
INFO - 2024-02-18 12:56:01 --> Helper loaded: form_helper
INFO - 2024-02-18 12:56:01 --> Helper loaded: lang_helper
INFO - 2024-02-18 12:56:01 --> Helper loaded: security_helper
INFO - 2024-02-18 12:56:01 --> Helper loaded: cookie_helper
INFO - 2024-02-18 12:56:01 --> Database Driver Class Initialized
INFO - 2024-02-18 12:56:01 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-18 12:56:01 --> Parser Class Initialized
INFO - 2024-02-18 12:56:01 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-18 12:56:01 --> Pagination Class Initialized
INFO - 2024-02-18 12:56:01 --> Form Validation Class Initialized
INFO - 2024-02-18 12:56:01 --> Controller Class Initialized
INFO - 2024-02-18 12:56:01 --> Model Class Initialized
INFO - 2024-02-18 12:56:01 --> Model Class Initialized
INFO - 2024-02-18 12:56:01 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/report/out_of_date.php
DEBUG - 2024-02-18 12:56:01 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-02-18 12:56:01 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-02-18 12:56:01 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-02-18 12:56:01 --> Model Class Initialized
INFO - 2024-02-18 12:56:01 --> Model Class Initialized
INFO - 2024-02-18 12:56:01 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-02-18 12:56:01 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-02-18 12:56:01 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-02-18 12:56:01 --> Final output sent to browser
DEBUG - 2024-02-18 12:56:01 --> Total execution time: 0.1527
ERROR - 2024-02-18 12:56:02 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-18 12:56:02 --> Config Class Initialized
INFO - 2024-02-18 12:56:02 --> Hooks Class Initialized
DEBUG - 2024-02-18 12:56:02 --> UTF-8 Support Enabled
INFO - 2024-02-18 12:56:02 --> Utf8 Class Initialized
INFO - 2024-02-18 12:56:02 --> URI Class Initialized
INFO - 2024-02-18 12:56:02 --> Router Class Initialized
INFO - 2024-02-18 12:56:02 --> Output Class Initialized
INFO - 2024-02-18 12:56:02 --> Security Class Initialized
DEBUG - 2024-02-18 12:56:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-18 12:56:02 --> Input Class Initialized
INFO - 2024-02-18 12:56:02 --> Language Class Initialized
INFO - 2024-02-18 12:56:02 --> Loader Class Initialized
INFO - 2024-02-18 12:56:02 --> Helper loaded: url_helper
INFO - 2024-02-18 12:56:02 --> Helper loaded: file_helper
INFO - 2024-02-18 12:56:02 --> Helper loaded: html_helper
INFO - 2024-02-18 12:56:02 --> Helper loaded: text_helper
INFO - 2024-02-18 12:56:02 --> Helper loaded: form_helper
INFO - 2024-02-18 12:56:02 --> Helper loaded: lang_helper
INFO - 2024-02-18 12:56:02 --> Helper loaded: security_helper
INFO - 2024-02-18 12:56:02 --> Helper loaded: cookie_helper
INFO - 2024-02-18 12:56:02 --> Database Driver Class Initialized
INFO - 2024-02-18 12:56:02 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-18 12:56:02 --> Parser Class Initialized
INFO - 2024-02-18 12:56:02 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-18 12:56:02 --> Pagination Class Initialized
INFO - 2024-02-18 12:56:02 --> Form Validation Class Initialized
INFO - 2024-02-18 12:56:02 --> Controller Class Initialized
INFO - 2024-02-18 12:56:02 --> Model Class Initialized
INFO - 2024-02-18 12:56:02 --> Model Class Initialized
INFO - 2024-02-18 12:56:02 --> Final output sent to browser
DEBUG - 2024-02-18 12:56:02 --> Total execution time: 0.0868
ERROR - 2024-02-18 12:56:05 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-18 12:56:05 --> Config Class Initialized
INFO - 2024-02-18 12:56:05 --> Hooks Class Initialized
DEBUG - 2024-02-18 12:56:05 --> UTF-8 Support Enabled
INFO - 2024-02-18 12:56:05 --> Utf8 Class Initialized
INFO - 2024-02-18 12:56:05 --> URI Class Initialized
INFO - 2024-02-18 12:56:05 --> Router Class Initialized
INFO - 2024-02-18 12:56:05 --> Output Class Initialized
INFO - 2024-02-18 12:56:05 --> Security Class Initialized
DEBUG - 2024-02-18 12:56:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-18 12:56:05 --> Input Class Initialized
INFO - 2024-02-18 12:56:05 --> Language Class Initialized
INFO - 2024-02-18 12:56:05 --> Loader Class Initialized
INFO - 2024-02-18 12:56:05 --> Helper loaded: url_helper
INFO - 2024-02-18 12:56:05 --> Helper loaded: file_helper
INFO - 2024-02-18 12:56:05 --> Helper loaded: html_helper
INFO - 2024-02-18 12:56:05 --> Helper loaded: text_helper
INFO - 2024-02-18 12:56:05 --> Helper loaded: form_helper
INFO - 2024-02-18 12:56:05 --> Helper loaded: lang_helper
INFO - 2024-02-18 12:56:05 --> Helper loaded: security_helper
INFO - 2024-02-18 12:56:05 --> Helper loaded: cookie_helper
INFO - 2024-02-18 12:56:05 --> Database Driver Class Initialized
INFO - 2024-02-18 12:56:05 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-18 12:56:05 --> Parser Class Initialized
INFO - 2024-02-18 12:56:05 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-18 12:56:05 --> Pagination Class Initialized
INFO - 2024-02-18 12:56:05 --> Form Validation Class Initialized
INFO - 2024-02-18 12:56:05 --> Controller Class Initialized
INFO - 2024-02-18 12:56:05 --> Model Class Initialized
INFO - 2024-02-18 12:56:05 --> Model Class Initialized
INFO - 2024-02-18 12:56:05 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/report/out_of_date.php
DEBUG - 2024-02-18 12:56:05 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-02-18 12:56:05 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-02-18 12:56:05 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-02-18 12:56:05 --> Model Class Initialized
INFO - 2024-02-18 12:56:05 --> Model Class Initialized
INFO - 2024-02-18 12:56:05 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-02-18 12:56:05 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-02-18 12:56:05 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-02-18 12:56:05 --> Final output sent to browser
DEBUG - 2024-02-18 12:56:05 --> Total execution time: 0.1578
ERROR - 2024-02-18 12:56:06 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-18 12:56:06 --> Config Class Initialized
INFO - 2024-02-18 12:56:06 --> Hooks Class Initialized
DEBUG - 2024-02-18 12:56:06 --> UTF-8 Support Enabled
INFO - 2024-02-18 12:56:06 --> Utf8 Class Initialized
INFO - 2024-02-18 12:56:06 --> URI Class Initialized
INFO - 2024-02-18 12:56:06 --> Router Class Initialized
INFO - 2024-02-18 12:56:06 --> Output Class Initialized
INFO - 2024-02-18 12:56:06 --> Security Class Initialized
DEBUG - 2024-02-18 12:56:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-18 12:56:06 --> Input Class Initialized
INFO - 2024-02-18 12:56:06 --> Language Class Initialized
INFO - 2024-02-18 12:56:06 --> Loader Class Initialized
INFO - 2024-02-18 12:56:06 --> Helper loaded: url_helper
INFO - 2024-02-18 12:56:06 --> Helper loaded: file_helper
INFO - 2024-02-18 12:56:06 --> Helper loaded: html_helper
INFO - 2024-02-18 12:56:06 --> Helper loaded: text_helper
INFO - 2024-02-18 12:56:06 --> Helper loaded: form_helper
INFO - 2024-02-18 12:56:06 --> Helper loaded: lang_helper
INFO - 2024-02-18 12:56:06 --> Helper loaded: security_helper
INFO - 2024-02-18 12:56:06 --> Helper loaded: cookie_helper
INFO - 2024-02-18 12:56:06 --> Database Driver Class Initialized
INFO - 2024-02-18 12:56:06 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-18 12:56:06 --> Parser Class Initialized
INFO - 2024-02-18 12:56:06 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-18 12:56:06 --> Pagination Class Initialized
INFO - 2024-02-18 12:56:06 --> Form Validation Class Initialized
INFO - 2024-02-18 12:56:06 --> Controller Class Initialized
INFO - 2024-02-18 12:56:06 --> Model Class Initialized
INFO - 2024-02-18 12:56:06 --> Model Class Initialized
INFO - 2024-02-18 12:56:06 --> Final output sent to browser
DEBUG - 2024-02-18 12:56:06 --> Total execution time: 0.0916
ERROR - 2024-02-18 13:11:35 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-18 13:11:35 --> Config Class Initialized
INFO - 2024-02-18 13:11:35 --> Hooks Class Initialized
DEBUG - 2024-02-18 13:11:35 --> UTF-8 Support Enabled
INFO - 2024-02-18 13:11:35 --> Utf8 Class Initialized
INFO - 2024-02-18 13:11:35 --> URI Class Initialized
INFO - 2024-02-18 13:11:35 --> Router Class Initialized
INFO - 2024-02-18 13:11:35 --> Output Class Initialized
INFO - 2024-02-18 13:11:35 --> Security Class Initialized
DEBUG - 2024-02-18 13:11:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-18 13:11:35 --> Input Class Initialized
INFO - 2024-02-18 13:11:35 --> Language Class Initialized
INFO - 2024-02-18 13:11:35 --> Loader Class Initialized
INFO - 2024-02-18 13:11:35 --> Helper loaded: url_helper
INFO - 2024-02-18 13:11:35 --> Helper loaded: file_helper
INFO - 2024-02-18 13:11:35 --> Helper loaded: html_helper
INFO - 2024-02-18 13:11:35 --> Helper loaded: text_helper
INFO - 2024-02-18 13:11:35 --> Helper loaded: form_helper
INFO - 2024-02-18 13:11:35 --> Helper loaded: lang_helper
INFO - 2024-02-18 13:11:35 --> Helper loaded: security_helper
INFO - 2024-02-18 13:11:35 --> Helper loaded: cookie_helper
INFO - 2024-02-18 13:11:35 --> Database Driver Class Initialized
INFO - 2024-02-18 13:11:35 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-18 13:11:35 --> Parser Class Initialized
INFO - 2024-02-18 13:11:35 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-18 13:11:35 --> Pagination Class Initialized
INFO - 2024-02-18 13:11:35 --> Form Validation Class Initialized
INFO - 2024-02-18 13:11:35 --> Controller Class Initialized
DEBUG - 2024-02-18 13:11:35 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-18 13:11:35 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-18 13:11:35 --> Model Class Initialized
DEBUG - 2024-02-18 13:11:35 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-18 13:11:35 --> Model Class Initialized
DEBUG - 2024-02-18 13:11:35 --> Lcustomer class already loaded. Second attempt ignored.
INFO - 2024-02-18 13:11:35 --> Model Class Initialized
INFO - 2024-02-18 13:11:35 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/customer/customer.php
DEBUG - 2024-02-18 13:11:35 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-02-18 13:11:35 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-02-18 13:11:35 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-02-18 13:11:35 --> Model Class Initialized
INFO - 2024-02-18 13:11:35 --> Model Class Initialized
INFO - 2024-02-18 13:11:35 --> Model Class Initialized
INFO - 2024-02-18 13:11:35 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-02-18 13:11:35 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-02-18 13:11:35 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-02-18 13:11:35 --> Final output sent to browser
DEBUG - 2024-02-18 13:11:35 --> Total execution time: 0.1460
ERROR - 2024-02-18 13:11:37 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-18 13:11:37 --> Config Class Initialized
INFO - 2024-02-18 13:11:37 --> Hooks Class Initialized
DEBUG - 2024-02-18 13:11:37 --> UTF-8 Support Enabled
INFO - 2024-02-18 13:11:37 --> Utf8 Class Initialized
INFO - 2024-02-18 13:11:37 --> URI Class Initialized
INFO - 2024-02-18 13:11:37 --> Router Class Initialized
INFO - 2024-02-18 13:11:37 --> Output Class Initialized
INFO - 2024-02-18 13:11:37 --> Security Class Initialized
DEBUG - 2024-02-18 13:11:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-18 13:11:37 --> Input Class Initialized
INFO - 2024-02-18 13:11:37 --> Language Class Initialized
INFO - 2024-02-18 13:11:37 --> Loader Class Initialized
INFO - 2024-02-18 13:11:37 --> Helper loaded: url_helper
INFO - 2024-02-18 13:11:37 --> Helper loaded: file_helper
INFO - 2024-02-18 13:11:37 --> Helper loaded: html_helper
INFO - 2024-02-18 13:11:37 --> Helper loaded: text_helper
INFO - 2024-02-18 13:11:37 --> Helper loaded: form_helper
INFO - 2024-02-18 13:11:37 --> Helper loaded: lang_helper
INFO - 2024-02-18 13:11:37 --> Helper loaded: security_helper
INFO - 2024-02-18 13:11:37 --> Helper loaded: cookie_helper
INFO - 2024-02-18 13:11:37 --> Database Driver Class Initialized
INFO - 2024-02-18 13:11:37 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-18 13:11:37 --> Parser Class Initialized
INFO - 2024-02-18 13:11:37 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-18 13:11:37 --> Pagination Class Initialized
INFO - 2024-02-18 13:11:37 --> Form Validation Class Initialized
INFO - 2024-02-18 13:11:37 --> Controller Class Initialized
DEBUG - 2024-02-18 13:11:37 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-18 13:11:37 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-18 13:11:37 --> Model Class Initialized
DEBUG - 2024-02-18 13:11:37 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-18 13:11:37 --> Model Class Initialized
INFO - 2024-02-18 13:11:37 --> Final output sent to browser
DEBUG - 2024-02-18 13:11:37 --> Total execution time: 0.0218
ERROR - 2024-02-18 13:11:49 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-18 13:11:49 --> Config Class Initialized
INFO - 2024-02-18 13:11:49 --> Hooks Class Initialized
DEBUG - 2024-02-18 13:11:49 --> UTF-8 Support Enabled
INFO - 2024-02-18 13:11:49 --> Utf8 Class Initialized
INFO - 2024-02-18 13:11:49 --> URI Class Initialized
INFO - 2024-02-18 13:11:49 --> Router Class Initialized
INFO - 2024-02-18 13:11:49 --> Output Class Initialized
INFO - 2024-02-18 13:11:49 --> Security Class Initialized
DEBUG - 2024-02-18 13:11:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-18 13:11:49 --> Input Class Initialized
INFO - 2024-02-18 13:11:49 --> Language Class Initialized
INFO - 2024-02-18 13:11:49 --> Loader Class Initialized
INFO - 2024-02-18 13:11:49 --> Helper loaded: url_helper
INFO - 2024-02-18 13:11:49 --> Helper loaded: file_helper
INFO - 2024-02-18 13:11:49 --> Helper loaded: html_helper
INFO - 2024-02-18 13:11:49 --> Helper loaded: text_helper
INFO - 2024-02-18 13:11:49 --> Helper loaded: form_helper
INFO - 2024-02-18 13:11:49 --> Helper loaded: lang_helper
INFO - 2024-02-18 13:11:49 --> Helper loaded: security_helper
INFO - 2024-02-18 13:11:49 --> Helper loaded: cookie_helper
INFO - 2024-02-18 13:11:49 --> Database Driver Class Initialized
INFO - 2024-02-18 13:11:49 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-18 13:11:49 --> Parser Class Initialized
INFO - 2024-02-18 13:11:49 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-18 13:11:49 --> Pagination Class Initialized
INFO - 2024-02-18 13:11:49 --> Form Validation Class Initialized
INFO - 2024-02-18 13:11:49 --> Controller Class Initialized
DEBUG - 2024-02-18 13:11:49 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-18 13:11:49 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-18 13:11:49 --> Model Class Initialized
DEBUG - 2024-02-18 13:11:49 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-18 13:11:49 --> Model Class Initialized
INFO - 2024-02-18 13:11:49 --> Final output sent to browser
DEBUG - 2024-02-18 13:11:49 --> Total execution time: 0.0391
ERROR - 2024-02-18 13:12:25 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-18 13:12:25 --> Config Class Initialized
INFO - 2024-02-18 13:12:25 --> Hooks Class Initialized
DEBUG - 2024-02-18 13:12:25 --> UTF-8 Support Enabled
INFO - 2024-02-18 13:12:25 --> Utf8 Class Initialized
INFO - 2024-02-18 13:12:25 --> URI Class Initialized
DEBUG - 2024-02-18 13:12:25 --> No URI present. Default controller set.
INFO - 2024-02-18 13:12:25 --> Router Class Initialized
INFO - 2024-02-18 13:12:25 --> Output Class Initialized
INFO - 2024-02-18 13:12:25 --> Security Class Initialized
DEBUG - 2024-02-18 13:12:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-18 13:12:25 --> Input Class Initialized
INFO - 2024-02-18 13:12:25 --> Language Class Initialized
INFO - 2024-02-18 13:12:25 --> Loader Class Initialized
INFO - 2024-02-18 13:12:25 --> Helper loaded: url_helper
INFO - 2024-02-18 13:12:25 --> Helper loaded: file_helper
INFO - 2024-02-18 13:12:25 --> Helper loaded: html_helper
INFO - 2024-02-18 13:12:25 --> Helper loaded: text_helper
INFO - 2024-02-18 13:12:25 --> Helper loaded: form_helper
INFO - 2024-02-18 13:12:25 --> Helper loaded: lang_helper
INFO - 2024-02-18 13:12:25 --> Helper loaded: security_helper
INFO - 2024-02-18 13:12:25 --> Helper loaded: cookie_helper
INFO - 2024-02-18 13:12:25 --> Database Driver Class Initialized
INFO - 2024-02-18 13:12:25 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-18 13:12:25 --> Parser Class Initialized
INFO - 2024-02-18 13:12:25 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-18 13:12:25 --> Pagination Class Initialized
INFO - 2024-02-18 13:12:25 --> Form Validation Class Initialized
INFO - 2024-02-18 13:12:25 --> Controller Class Initialized
INFO - 2024-02-18 13:12:25 --> Model Class Initialized
DEBUG - 2024-02-18 13:12:25 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-18 13:12:25 --> Model Class Initialized
DEBUG - 2024-02-18 13:12:25 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-18 13:12:25 --> Model Class Initialized
INFO - 2024-02-18 13:12:25 --> Model Class Initialized
INFO - 2024-02-18 13:12:25 --> Model Class Initialized
INFO - 2024-02-18 13:12:25 --> Model Class Initialized
DEBUG - 2024-02-18 13:12:25 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-18 13:12:25 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-18 13:12:25 --> Model Class Initialized
INFO - 2024-02-18 13:12:25 --> Model Class Initialized
INFO - 2024-02-18 13:12:25 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2024-02-18 13:12:25 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-02-18 13:12:25 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-02-18 13:12:25 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-02-18 13:12:25 --> Model Class Initialized
INFO - 2024-02-18 13:12:25 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-02-18 13:12:25 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-02-18 13:12:25 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-02-18 13:12:25 --> Final output sent to browser
DEBUG - 2024-02-18 13:12:25 --> Total execution time: 0.2278
ERROR - 2024-02-18 13:12:30 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-18 13:12:30 --> Config Class Initialized
INFO - 2024-02-18 13:12:30 --> Hooks Class Initialized
DEBUG - 2024-02-18 13:12:30 --> UTF-8 Support Enabled
INFO - 2024-02-18 13:12:30 --> Utf8 Class Initialized
INFO - 2024-02-18 13:12:30 --> URI Class Initialized
INFO - 2024-02-18 13:12:30 --> Router Class Initialized
INFO - 2024-02-18 13:12:30 --> Output Class Initialized
INFO - 2024-02-18 13:12:30 --> Security Class Initialized
DEBUG - 2024-02-18 13:12:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-18 13:12:30 --> Input Class Initialized
INFO - 2024-02-18 13:12:30 --> Language Class Initialized
INFO - 2024-02-18 13:12:30 --> Loader Class Initialized
INFO - 2024-02-18 13:12:30 --> Helper loaded: url_helper
INFO - 2024-02-18 13:12:30 --> Helper loaded: file_helper
INFO - 2024-02-18 13:12:30 --> Helper loaded: html_helper
INFO - 2024-02-18 13:12:30 --> Helper loaded: text_helper
INFO - 2024-02-18 13:12:30 --> Helper loaded: form_helper
INFO - 2024-02-18 13:12:30 --> Helper loaded: lang_helper
INFO - 2024-02-18 13:12:30 --> Helper loaded: security_helper
INFO - 2024-02-18 13:12:30 --> Helper loaded: cookie_helper
INFO - 2024-02-18 13:12:30 --> Database Driver Class Initialized
INFO - 2024-02-18 13:12:30 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-18 13:12:30 --> Parser Class Initialized
INFO - 2024-02-18 13:12:30 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-18 13:12:30 --> Pagination Class Initialized
INFO - 2024-02-18 13:12:30 --> Form Validation Class Initialized
INFO - 2024-02-18 13:12:30 --> Controller Class Initialized
INFO - 2024-02-18 13:12:30 --> Model Class Initialized
DEBUG - 2024-02-18 13:12:30 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-18 13:12:30 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-18 13:12:30 --> Model Class Initialized
DEBUG - 2024-02-18 13:12:30 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-18 13:12:30 --> Model Class Initialized
INFO - 2024-02-18 13:12:30 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/add_invoice_form.php
DEBUG - 2024-02-18 13:12:30 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-02-18 13:12:30 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-02-18 13:12:30 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-02-18 13:12:30 --> Model Class Initialized
INFO - 2024-02-18 13:12:30 --> Model Class Initialized
INFO - 2024-02-18 13:12:30 --> Model Class Initialized
INFO - 2024-02-18 13:12:30 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-02-18 13:12:30 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-02-18 13:12:30 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-02-18 13:12:30 --> Final output sent to browser
DEBUG - 2024-02-18 13:12:30 --> Total execution time: 0.1861
ERROR - 2024-02-18 13:12:35 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-18 13:12:35 --> Config Class Initialized
INFO - 2024-02-18 13:12:35 --> Hooks Class Initialized
DEBUG - 2024-02-18 13:12:35 --> UTF-8 Support Enabled
INFO - 2024-02-18 13:12:35 --> Utf8 Class Initialized
INFO - 2024-02-18 13:12:35 --> URI Class Initialized
INFO - 2024-02-18 13:12:35 --> Router Class Initialized
INFO - 2024-02-18 13:12:35 --> Output Class Initialized
INFO - 2024-02-18 13:12:35 --> Security Class Initialized
DEBUG - 2024-02-18 13:12:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-18 13:12:35 --> Input Class Initialized
INFO - 2024-02-18 13:12:35 --> Language Class Initialized
INFO - 2024-02-18 13:12:35 --> Loader Class Initialized
INFO - 2024-02-18 13:12:35 --> Helper loaded: url_helper
INFO - 2024-02-18 13:12:35 --> Helper loaded: file_helper
INFO - 2024-02-18 13:12:35 --> Helper loaded: html_helper
INFO - 2024-02-18 13:12:35 --> Helper loaded: text_helper
INFO - 2024-02-18 13:12:35 --> Helper loaded: form_helper
INFO - 2024-02-18 13:12:35 --> Helper loaded: lang_helper
INFO - 2024-02-18 13:12:35 --> Helper loaded: security_helper
INFO - 2024-02-18 13:12:35 --> Helper loaded: cookie_helper
INFO - 2024-02-18 13:12:35 --> Database Driver Class Initialized
INFO - 2024-02-18 13:12:35 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-18 13:12:35 --> Parser Class Initialized
INFO - 2024-02-18 13:12:35 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-18 13:12:35 --> Pagination Class Initialized
INFO - 2024-02-18 13:12:35 --> Form Validation Class Initialized
INFO - 2024-02-18 13:12:35 --> Controller Class Initialized
INFO - 2024-02-18 13:12:35 --> Model Class Initialized
DEBUG - 2024-02-18 13:12:35 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-18 13:12:35 --> Final output sent to browser
DEBUG - 2024-02-18 13:12:35 --> Total execution time: 0.0160
ERROR - 2024-02-18 13:12:36 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-18 13:12:36 --> Config Class Initialized
INFO - 2024-02-18 13:12:36 --> Hooks Class Initialized
DEBUG - 2024-02-18 13:12:36 --> UTF-8 Support Enabled
INFO - 2024-02-18 13:12:36 --> Utf8 Class Initialized
INFO - 2024-02-18 13:12:36 --> URI Class Initialized
INFO - 2024-02-18 13:12:36 --> Router Class Initialized
INFO - 2024-02-18 13:12:36 --> Output Class Initialized
INFO - 2024-02-18 13:12:36 --> Security Class Initialized
DEBUG - 2024-02-18 13:12:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-18 13:12:36 --> Input Class Initialized
INFO - 2024-02-18 13:12:36 --> Language Class Initialized
INFO - 2024-02-18 13:12:36 --> Loader Class Initialized
INFO - 2024-02-18 13:12:36 --> Helper loaded: url_helper
INFO - 2024-02-18 13:12:36 --> Helper loaded: file_helper
INFO - 2024-02-18 13:12:36 --> Helper loaded: html_helper
INFO - 2024-02-18 13:12:36 --> Helper loaded: text_helper
INFO - 2024-02-18 13:12:36 --> Helper loaded: form_helper
INFO - 2024-02-18 13:12:36 --> Helper loaded: lang_helper
INFO - 2024-02-18 13:12:36 --> Helper loaded: security_helper
INFO - 2024-02-18 13:12:36 --> Helper loaded: cookie_helper
INFO - 2024-02-18 13:12:36 --> Database Driver Class Initialized
INFO - 2024-02-18 13:12:36 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-18 13:12:36 --> Parser Class Initialized
INFO - 2024-02-18 13:12:36 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-18 13:12:36 --> Pagination Class Initialized
INFO - 2024-02-18 13:12:36 --> Form Validation Class Initialized
INFO - 2024-02-18 13:12:36 --> Controller Class Initialized
INFO - 2024-02-18 13:12:36 --> Model Class Initialized
DEBUG - 2024-02-18 13:12:36 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-18 13:12:36 --> Final output sent to browser
DEBUG - 2024-02-18 13:12:36 --> Total execution time: 0.0156
ERROR - 2024-02-18 13:12:39 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-18 13:12:39 --> Config Class Initialized
INFO - 2024-02-18 13:12:39 --> Hooks Class Initialized
DEBUG - 2024-02-18 13:12:39 --> UTF-8 Support Enabled
INFO - 2024-02-18 13:12:39 --> Utf8 Class Initialized
INFO - 2024-02-18 13:12:39 --> URI Class Initialized
INFO - 2024-02-18 13:12:39 --> Router Class Initialized
INFO - 2024-02-18 13:12:39 --> Output Class Initialized
INFO - 2024-02-18 13:12:39 --> Security Class Initialized
DEBUG - 2024-02-18 13:12:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-18 13:12:39 --> Input Class Initialized
INFO - 2024-02-18 13:12:39 --> Language Class Initialized
INFO - 2024-02-18 13:12:39 --> Loader Class Initialized
INFO - 2024-02-18 13:12:39 --> Helper loaded: url_helper
INFO - 2024-02-18 13:12:39 --> Helper loaded: file_helper
INFO - 2024-02-18 13:12:39 --> Helper loaded: html_helper
INFO - 2024-02-18 13:12:39 --> Helper loaded: text_helper
INFO - 2024-02-18 13:12:39 --> Helper loaded: form_helper
INFO - 2024-02-18 13:12:39 --> Helper loaded: lang_helper
INFO - 2024-02-18 13:12:39 --> Helper loaded: security_helper
INFO - 2024-02-18 13:12:39 --> Helper loaded: cookie_helper
INFO - 2024-02-18 13:12:39 --> Database Driver Class Initialized
INFO - 2024-02-18 13:12:39 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-18 13:12:39 --> Parser Class Initialized
INFO - 2024-02-18 13:12:39 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-18 13:12:39 --> Pagination Class Initialized
INFO - 2024-02-18 13:12:39 --> Form Validation Class Initialized
INFO - 2024-02-18 13:12:39 --> Controller Class Initialized
INFO - 2024-02-18 13:12:39 --> Final output sent to browser
DEBUG - 2024-02-18 13:12:39 --> Total execution time: 0.0181
ERROR - 2024-02-18 13:12:47 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-18 13:12:47 --> Config Class Initialized
INFO - 2024-02-18 13:12:47 --> Hooks Class Initialized
DEBUG - 2024-02-18 13:12:47 --> UTF-8 Support Enabled
INFO - 2024-02-18 13:12:47 --> Utf8 Class Initialized
INFO - 2024-02-18 13:12:47 --> URI Class Initialized
INFO - 2024-02-18 13:12:47 --> Router Class Initialized
INFO - 2024-02-18 13:12:47 --> Output Class Initialized
INFO - 2024-02-18 13:12:47 --> Security Class Initialized
DEBUG - 2024-02-18 13:12:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-18 13:12:47 --> Input Class Initialized
INFO - 2024-02-18 13:12:47 --> Language Class Initialized
INFO - 2024-02-18 13:12:47 --> Loader Class Initialized
INFO - 2024-02-18 13:12:47 --> Helper loaded: url_helper
INFO - 2024-02-18 13:12:47 --> Helper loaded: file_helper
INFO - 2024-02-18 13:12:47 --> Helper loaded: html_helper
INFO - 2024-02-18 13:12:47 --> Helper loaded: text_helper
INFO - 2024-02-18 13:12:47 --> Helper loaded: form_helper
INFO - 2024-02-18 13:12:47 --> Helper loaded: lang_helper
INFO - 2024-02-18 13:12:47 --> Helper loaded: security_helper
INFO - 2024-02-18 13:12:47 --> Helper loaded: cookie_helper
INFO - 2024-02-18 13:12:47 --> Database Driver Class Initialized
INFO - 2024-02-18 13:12:47 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-18 13:12:47 --> Parser Class Initialized
INFO - 2024-02-18 13:12:47 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-18 13:12:47 --> Pagination Class Initialized
INFO - 2024-02-18 13:12:47 --> Form Validation Class Initialized
INFO - 2024-02-18 13:12:47 --> Controller Class Initialized
INFO - 2024-02-18 13:12:47 --> Model Class Initialized
DEBUG - 2024-02-18 13:12:47 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-18 13:12:47 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-18 13:12:47 --> Model Class Initialized
DEBUG - 2024-02-18 13:12:47 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-18 13:12:47 --> Model Class Initialized
INFO - 2024-02-18 13:12:47 --> Final output sent to browser
DEBUG - 2024-02-18 13:12:47 --> Total execution time: 0.0920
ERROR - 2024-02-18 13:12:50 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-18 13:12:50 --> Config Class Initialized
INFO - 2024-02-18 13:12:50 --> Hooks Class Initialized
DEBUG - 2024-02-18 13:12:50 --> UTF-8 Support Enabled
INFO - 2024-02-18 13:12:50 --> Utf8 Class Initialized
INFO - 2024-02-18 13:12:50 --> URI Class Initialized
INFO - 2024-02-18 13:12:50 --> Router Class Initialized
INFO - 2024-02-18 13:12:50 --> Output Class Initialized
INFO - 2024-02-18 13:12:50 --> Security Class Initialized
DEBUG - 2024-02-18 13:12:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-18 13:12:50 --> Input Class Initialized
INFO - 2024-02-18 13:12:50 --> Language Class Initialized
INFO - 2024-02-18 13:12:50 --> Loader Class Initialized
INFO - 2024-02-18 13:12:50 --> Helper loaded: url_helper
INFO - 2024-02-18 13:12:50 --> Helper loaded: file_helper
INFO - 2024-02-18 13:12:50 --> Helper loaded: html_helper
INFO - 2024-02-18 13:12:50 --> Helper loaded: text_helper
INFO - 2024-02-18 13:12:50 --> Helper loaded: form_helper
INFO - 2024-02-18 13:12:50 --> Helper loaded: lang_helper
INFO - 2024-02-18 13:12:50 --> Helper loaded: security_helper
INFO - 2024-02-18 13:12:50 --> Helper loaded: cookie_helper
INFO - 2024-02-18 13:12:50 --> Database Driver Class Initialized
INFO - 2024-02-18 13:12:50 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-18 13:12:50 --> Parser Class Initialized
INFO - 2024-02-18 13:12:50 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-18 13:12:50 --> Pagination Class Initialized
INFO - 2024-02-18 13:12:50 --> Form Validation Class Initialized
INFO - 2024-02-18 13:12:50 --> Controller Class Initialized
INFO - 2024-02-18 13:12:50 --> Model Class Initialized
DEBUG - 2024-02-18 13:12:50 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-18 13:12:50 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-18 13:12:50 --> Model Class Initialized
INFO - 2024-02-18 13:12:50 --> Model Class Initialized
INFO - 2024-02-18 13:12:50 --> Final output sent to browser
DEBUG - 2024-02-18 13:12:50 --> Total execution time: 0.0201
ERROR - 2024-02-18 13:12:52 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-18 13:12:52 --> Config Class Initialized
INFO - 2024-02-18 13:12:52 --> Hooks Class Initialized
DEBUG - 2024-02-18 13:12:52 --> UTF-8 Support Enabled
INFO - 2024-02-18 13:12:52 --> Utf8 Class Initialized
INFO - 2024-02-18 13:12:52 --> URI Class Initialized
INFO - 2024-02-18 13:12:52 --> Router Class Initialized
INFO - 2024-02-18 13:12:52 --> Output Class Initialized
INFO - 2024-02-18 13:12:52 --> Security Class Initialized
DEBUG - 2024-02-18 13:12:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-18 13:12:52 --> Input Class Initialized
INFO - 2024-02-18 13:12:52 --> Language Class Initialized
INFO - 2024-02-18 13:12:52 --> Loader Class Initialized
INFO - 2024-02-18 13:12:52 --> Helper loaded: url_helper
INFO - 2024-02-18 13:12:52 --> Helper loaded: file_helper
INFO - 2024-02-18 13:12:52 --> Helper loaded: html_helper
INFO - 2024-02-18 13:12:52 --> Helper loaded: text_helper
INFO - 2024-02-18 13:12:52 --> Helper loaded: form_helper
INFO - 2024-02-18 13:12:52 --> Helper loaded: lang_helper
INFO - 2024-02-18 13:12:52 --> Helper loaded: security_helper
INFO - 2024-02-18 13:12:52 --> Helper loaded: cookie_helper
INFO - 2024-02-18 13:12:52 --> Database Driver Class Initialized
INFO - 2024-02-18 13:12:52 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-18 13:12:52 --> Parser Class Initialized
INFO - 2024-02-18 13:12:52 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-18 13:12:52 --> Pagination Class Initialized
INFO - 2024-02-18 13:12:52 --> Form Validation Class Initialized
INFO - 2024-02-18 13:12:52 --> Controller Class Initialized
INFO - 2024-02-18 13:12:52 --> Model Class Initialized
DEBUG - 2024-02-18 13:12:52 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-18 13:12:52 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-18 13:12:52 --> Model Class Initialized
INFO - 2024-02-18 13:12:52 --> Final output sent to browser
DEBUG - 2024-02-18 13:12:52 --> Total execution time: 0.0166
ERROR - 2024-02-18 13:13:10 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-18 13:13:10 --> Config Class Initialized
INFO - 2024-02-18 13:13:10 --> Hooks Class Initialized
DEBUG - 2024-02-18 13:13:10 --> UTF-8 Support Enabled
INFO - 2024-02-18 13:13:10 --> Utf8 Class Initialized
INFO - 2024-02-18 13:13:10 --> URI Class Initialized
INFO - 2024-02-18 13:13:10 --> Router Class Initialized
INFO - 2024-02-18 13:13:10 --> Output Class Initialized
INFO - 2024-02-18 13:13:10 --> Security Class Initialized
DEBUG - 2024-02-18 13:13:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-18 13:13:10 --> Input Class Initialized
INFO - 2024-02-18 13:13:10 --> Language Class Initialized
INFO - 2024-02-18 13:13:10 --> Loader Class Initialized
INFO - 2024-02-18 13:13:10 --> Helper loaded: url_helper
INFO - 2024-02-18 13:13:10 --> Helper loaded: file_helper
INFO - 2024-02-18 13:13:10 --> Helper loaded: html_helper
INFO - 2024-02-18 13:13:10 --> Helper loaded: text_helper
INFO - 2024-02-18 13:13:10 --> Helper loaded: form_helper
INFO - 2024-02-18 13:13:10 --> Helper loaded: lang_helper
INFO - 2024-02-18 13:13:10 --> Helper loaded: security_helper
INFO - 2024-02-18 13:13:10 --> Helper loaded: cookie_helper
INFO - 2024-02-18 13:13:10 --> Database Driver Class Initialized
INFO - 2024-02-18 13:13:10 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-18 13:13:10 --> Parser Class Initialized
INFO - 2024-02-18 13:13:10 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-18 13:13:10 --> Pagination Class Initialized
INFO - 2024-02-18 13:13:10 --> Form Validation Class Initialized
INFO - 2024-02-18 13:13:10 --> Controller Class Initialized
INFO - 2024-02-18 13:13:10 --> Model Class Initialized
DEBUG - 2024-02-18 13:13:10 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-18 13:13:10 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-18 13:13:10 --> Model Class Initialized
DEBUG - 2024-02-18 13:13:10 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-18 13:13:10 --> Model Class Initialized
INFO - 2024-02-18 13:13:10 --> Final output sent to browser
DEBUG - 2024-02-18 13:13:10 --> Total execution time: 0.0956
ERROR - 2024-02-18 13:13:11 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-18 13:13:11 --> Config Class Initialized
INFO - 2024-02-18 13:13:11 --> Hooks Class Initialized
DEBUG - 2024-02-18 13:13:11 --> UTF-8 Support Enabled
INFO - 2024-02-18 13:13:11 --> Utf8 Class Initialized
INFO - 2024-02-18 13:13:11 --> URI Class Initialized
INFO - 2024-02-18 13:13:11 --> Router Class Initialized
INFO - 2024-02-18 13:13:11 --> Output Class Initialized
INFO - 2024-02-18 13:13:11 --> Security Class Initialized
DEBUG - 2024-02-18 13:13:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-18 13:13:11 --> Input Class Initialized
INFO - 2024-02-18 13:13:11 --> Language Class Initialized
INFO - 2024-02-18 13:13:11 --> Loader Class Initialized
INFO - 2024-02-18 13:13:11 --> Helper loaded: url_helper
INFO - 2024-02-18 13:13:11 --> Helper loaded: file_helper
INFO - 2024-02-18 13:13:11 --> Helper loaded: html_helper
INFO - 2024-02-18 13:13:11 --> Helper loaded: text_helper
INFO - 2024-02-18 13:13:11 --> Helper loaded: form_helper
INFO - 2024-02-18 13:13:11 --> Helper loaded: lang_helper
INFO - 2024-02-18 13:13:11 --> Helper loaded: security_helper
INFO - 2024-02-18 13:13:11 --> Helper loaded: cookie_helper
INFO - 2024-02-18 13:13:11 --> Database Driver Class Initialized
INFO - 2024-02-18 13:13:11 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-18 13:13:11 --> Parser Class Initialized
INFO - 2024-02-18 13:13:11 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-18 13:13:11 --> Pagination Class Initialized
INFO - 2024-02-18 13:13:11 --> Form Validation Class Initialized
INFO - 2024-02-18 13:13:11 --> Controller Class Initialized
INFO - 2024-02-18 13:13:11 --> Model Class Initialized
DEBUG - 2024-02-18 13:13:11 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-18 13:13:11 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-18 13:13:11 --> Model Class Initialized
DEBUG - 2024-02-18 13:13:11 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-18 13:13:11 --> Model Class Initialized
INFO - 2024-02-18 13:13:11 --> Final output sent to browser
DEBUG - 2024-02-18 13:13:11 --> Total execution time: 0.0980
ERROR - 2024-02-18 13:13:12 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-18 13:13:12 --> Config Class Initialized
INFO - 2024-02-18 13:13:12 --> Hooks Class Initialized
DEBUG - 2024-02-18 13:13:12 --> UTF-8 Support Enabled
INFO - 2024-02-18 13:13:12 --> Utf8 Class Initialized
INFO - 2024-02-18 13:13:12 --> URI Class Initialized
INFO - 2024-02-18 13:13:12 --> Router Class Initialized
INFO - 2024-02-18 13:13:12 --> Output Class Initialized
INFO - 2024-02-18 13:13:12 --> Security Class Initialized
DEBUG - 2024-02-18 13:13:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-18 13:13:12 --> Input Class Initialized
INFO - 2024-02-18 13:13:12 --> Language Class Initialized
INFO - 2024-02-18 13:13:12 --> Loader Class Initialized
INFO - 2024-02-18 13:13:12 --> Helper loaded: url_helper
INFO - 2024-02-18 13:13:12 --> Helper loaded: file_helper
INFO - 2024-02-18 13:13:12 --> Helper loaded: html_helper
INFO - 2024-02-18 13:13:12 --> Helper loaded: text_helper
INFO - 2024-02-18 13:13:12 --> Helper loaded: form_helper
INFO - 2024-02-18 13:13:12 --> Helper loaded: lang_helper
INFO - 2024-02-18 13:13:12 --> Helper loaded: security_helper
INFO - 2024-02-18 13:13:12 --> Helper loaded: cookie_helper
INFO - 2024-02-18 13:13:12 --> Database Driver Class Initialized
INFO - 2024-02-18 13:13:12 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-18 13:13:12 --> Parser Class Initialized
INFO - 2024-02-18 13:13:12 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-18 13:13:12 --> Pagination Class Initialized
INFO - 2024-02-18 13:13:12 --> Form Validation Class Initialized
INFO - 2024-02-18 13:13:12 --> Controller Class Initialized
INFO - 2024-02-18 13:13:12 --> Model Class Initialized
DEBUG - 2024-02-18 13:13:12 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-18 13:13:12 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-18 13:13:12 --> Model Class Initialized
DEBUG - 2024-02-18 13:13:12 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-18 13:13:12 --> Model Class Initialized
INFO - 2024-02-18 13:13:12 --> Final output sent to browser
DEBUG - 2024-02-18 13:13:12 --> Total execution time: 0.0934
ERROR - 2024-02-18 13:13:18 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-18 13:13:18 --> Config Class Initialized
INFO - 2024-02-18 13:13:18 --> Hooks Class Initialized
DEBUG - 2024-02-18 13:13:18 --> UTF-8 Support Enabled
INFO - 2024-02-18 13:13:18 --> Utf8 Class Initialized
INFO - 2024-02-18 13:13:18 --> URI Class Initialized
INFO - 2024-02-18 13:13:18 --> Router Class Initialized
INFO - 2024-02-18 13:13:18 --> Output Class Initialized
INFO - 2024-02-18 13:13:18 --> Security Class Initialized
DEBUG - 2024-02-18 13:13:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-18 13:13:18 --> Input Class Initialized
INFO - 2024-02-18 13:13:18 --> Language Class Initialized
INFO - 2024-02-18 13:13:18 --> Loader Class Initialized
INFO - 2024-02-18 13:13:18 --> Helper loaded: url_helper
INFO - 2024-02-18 13:13:18 --> Helper loaded: file_helper
INFO - 2024-02-18 13:13:18 --> Helper loaded: html_helper
INFO - 2024-02-18 13:13:18 --> Helper loaded: text_helper
INFO - 2024-02-18 13:13:18 --> Helper loaded: form_helper
INFO - 2024-02-18 13:13:18 --> Helper loaded: lang_helper
INFO - 2024-02-18 13:13:18 --> Helper loaded: security_helper
INFO - 2024-02-18 13:13:18 --> Helper loaded: cookie_helper
INFO - 2024-02-18 13:13:18 --> Database Driver Class Initialized
INFO - 2024-02-18 13:13:18 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-18 13:13:18 --> Parser Class Initialized
INFO - 2024-02-18 13:13:18 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-18 13:13:18 --> Pagination Class Initialized
INFO - 2024-02-18 13:13:18 --> Form Validation Class Initialized
INFO - 2024-02-18 13:13:18 --> Controller Class Initialized
INFO - 2024-02-18 13:13:18 --> Model Class Initialized
DEBUG - 2024-02-18 13:13:18 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-18 13:13:18 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-18 13:13:18 --> Model Class Initialized
INFO - 2024-02-18 13:13:18 --> Model Class Initialized
INFO - 2024-02-18 13:13:18 --> Final output sent to browser
DEBUG - 2024-02-18 13:13:18 --> Total execution time: 0.0205
ERROR - 2024-02-18 13:13:21 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-18 13:13:21 --> Config Class Initialized
INFO - 2024-02-18 13:13:21 --> Hooks Class Initialized
DEBUG - 2024-02-18 13:13:21 --> UTF-8 Support Enabled
INFO - 2024-02-18 13:13:21 --> Utf8 Class Initialized
INFO - 2024-02-18 13:13:21 --> URI Class Initialized
INFO - 2024-02-18 13:13:21 --> Router Class Initialized
INFO - 2024-02-18 13:13:21 --> Output Class Initialized
INFO - 2024-02-18 13:13:21 --> Security Class Initialized
DEBUG - 2024-02-18 13:13:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-18 13:13:21 --> Input Class Initialized
INFO - 2024-02-18 13:13:21 --> Language Class Initialized
INFO - 2024-02-18 13:13:21 --> Loader Class Initialized
INFO - 2024-02-18 13:13:21 --> Helper loaded: url_helper
INFO - 2024-02-18 13:13:21 --> Helper loaded: file_helper
INFO - 2024-02-18 13:13:21 --> Helper loaded: html_helper
INFO - 2024-02-18 13:13:21 --> Helper loaded: text_helper
INFO - 2024-02-18 13:13:21 --> Helper loaded: form_helper
INFO - 2024-02-18 13:13:21 --> Helper loaded: lang_helper
INFO - 2024-02-18 13:13:21 --> Helper loaded: security_helper
INFO - 2024-02-18 13:13:21 --> Helper loaded: cookie_helper
INFO - 2024-02-18 13:13:21 --> Database Driver Class Initialized
INFO - 2024-02-18 13:13:21 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-18 13:13:21 --> Parser Class Initialized
INFO - 2024-02-18 13:13:21 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-18 13:13:21 --> Pagination Class Initialized
INFO - 2024-02-18 13:13:21 --> Form Validation Class Initialized
INFO - 2024-02-18 13:13:21 --> Controller Class Initialized
INFO - 2024-02-18 13:13:21 --> Model Class Initialized
DEBUG - 2024-02-18 13:13:21 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-18 13:13:21 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-18 13:13:21 --> Model Class Initialized
INFO - 2024-02-18 13:13:21 --> Final output sent to browser
DEBUG - 2024-02-18 13:13:21 --> Total execution time: 0.0164
ERROR - 2024-02-18 13:13:39 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-18 13:13:39 --> Config Class Initialized
INFO - 2024-02-18 13:13:39 --> Hooks Class Initialized
DEBUG - 2024-02-18 13:13:39 --> UTF-8 Support Enabled
INFO - 2024-02-18 13:13:39 --> Utf8 Class Initialized
INFO - 2024-02-18 13:13:39 --> URI Class Initialized
INFO - 2024-02-18 13:13:39 --> Router Class Initialized
INFO - 2024-02-18 13:13:39 --> Output Class Initialized
INFO - 2024-02-18 13:13:39 --> Security Class Initialized
DEBUG - 2024-02-18 13:13:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-18 13:13:39 --> Input Class Initialized
INFO - 2024-02-18 13:13:39 --> Language Class Initialized
INFO - 2024-02-18 13:13:39 --> Loader Class Initialized
INFO - 2024-02-18 13:13:39 --> Helper loaded: url_helper
INFO - 2024-02-18 13:13:39 --> Helper loaded: file_helper
INFO - 2024-02-18 13:13:39 --> Helper loaded: html_helper
INFO - 2024-02-18 13:13:39 --> Helper loaded: text_helper
INFO - 2024-02-18 13:13:39 --> Helper loaded: form_helper
INFO - 2024-02-18 13:13:39 --> Helper loaded: lang_helper
INFO - 2024-02-18 13:13:39 --> Helper loaded: security_helper
INFO - 2024-02-18 13:13:39 --> Helper loaded: cookie_helper
INFO - 2024-02-18 13:13:39 --> Database Driver Class Initialized
INFO - 2024-02-18 13:13:39 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-18 13:13:39 --> Parser Class Initialized
INFO - 2024-02-18 13:13:39 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-18 13:13:39 --> Pagination Class Initialized
INFO - 2024-02-18 13:13:39 --> Form Validation Class Initialized
INFO - 2024-02-18 13:13:39 --> Controller Class Initialized
INFO - 2024-02-18 13:13:39 --> Model Class Initialized
DEBUG - 2024-02-18 13:13:39 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-18 13:13:39 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-18 13:13:39 --> Model Class Initialized
DEBUG - 2024-02-18 13:13:39 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-18 13:13:39 --> Model Class Initialized
INFO - 2024-02-18 13:13:39 --> Email Class Initialized
DEBUG - 2024-02-18 13:13:39 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-18 13:13:39 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice_html_pdf.php
ERROR - 2024-02-18 13:13:39 --> Severity: Warning --> "continue" targeting switch is equivalent to "break". Did you mean to use "continue 2"? /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/dompdf.cls.php 743
ERROR - 2024-02-18 13:13:39 --> Severity: Warning --> "continue" targeting switch is equivalent to "break". Did you mean to use "continue 2"? /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/dompdf.cls.php 763
ERROR - 2024-02-18 13:13:39 --> Severity: Warning --> "continue" targeting switch is equivalent to "break". Did you mean to use "continue 2"? /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/stylesheet.cls.php 1102
ERROR - 2024-02-18 13:13:39 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/page_frame_decorator.cls.php 439
ERROR - 2024-02-18 13:13:39 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/page_frame_decorator.cls.php 439
ERROR - 2024-02-18 13:13:39 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/page_frame_decorator.cls.php 439
ERROR - 2024-02-18 13:13:39 --> Severity: Warning --> Division by zero /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 572
ERROR - 2024-02-18 13:13:39 --> Severity: Warning --> Division by zero /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 572
ERROR - 2024-02-18 13:13:39 --> Severity: Warning --> Division by zero /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 572
ERROR - 2024-02-18 13:13:39 --> Severity: Warning --> Division by zero /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 572
ERROR - 2024-02-18 13:13:39 --> Severity: Warning --> Division by zero /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 572
ERROR - 2024-02-18 13:13:39 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/table_cell_frame_reflower.cls.php 103
ERROR - 2024-02-18 13:13:39 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/table_cell_frame_reflower.cls.php 103
ERROR - 2024-02-18 13:13:39 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/table_cell_frame_reflower.cls.php 103
ERROR - 2024-02-18 13:13:39 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/table_cell_frame_reflower.cls.php 103
ERROR - 2024-02-18 13:13:39 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/table_cell_frame_reflower.cls.php 103
ERROR - 2024-02-18 13:13:39 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/table_cell_frame_reflower.cls.php 103
ERROR - 2024-02-18 13:13:39 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/table_cell_frame_reflower.cls.php 103
ERROR - 2024-02-18 13:13:39 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/table_cell_frame_reflower.cls.php 103
ERROR - 2024-02-18 13:13:39 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/table_cell_frame_reflower.cls.php 103
ERROR - 2024-02-18 13:13:39 --> Severity: Warning --> Invalid argument supplied for foreach() /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 709
ERROR - 2024-02-18 13:13:39 --> Severity: Warning --> Invalid argument supplied for foreach() /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 709
ERROR - 2024-02-18 13:13:39 --> Severity: Warning --> Invalid argument supplied for foreach() /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 709
ERROR - 2024-02-18 13:13:39 --> Severity: Warning --> Invalid argument supplied for foreach() /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 709
ERROR - 2024-02-18 13:13:39 --> Severity: Warning --> Invalid argument supplied for foreach() /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 709
ERROR - 2024-02-18 13:13:39 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-18 13:13:39 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-18 13:13:39 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-18 13:13:39 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-18 13:13:39 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-18 13:13:39 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-18 13:13:39 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-18 13:13:39 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-18 13:13:39 --> Severity: Warning --> "continue" targeting switch is equivalent to "break". Did you mean to use "continue 2"? /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/text_renderer.cls.php 126
ERROR - 2024-02-18 13:13:39 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-18 13:13:39 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-18 13:13:39 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-18 13:13:39 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-18 13:13:39 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-18 13:13:39 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-18 13:13:39 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-18 13:13:39 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-18 13:13:39 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-18 13:13:39 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-18 13:13:39 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-18 13:13:39 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-18 13:13:39 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-18 13:13:39 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-18 13:13:39 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-18 13:13:39 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-18 13:13:39 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-18 13:13:39 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-18 13:13:39 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-18 13:13:39 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-18 13:13:39 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-18 13:13:39 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-18 13:13:39 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-18 13:13:39 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-18 13:13:39 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-18 13:13:39 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-18 13:13:39 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-18 13:13:39 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-18 13:13:39 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-18 13:13:39 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-18 13:13:39 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-18 13:13:39 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-18 13:13:39 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-18 13:13:39 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-18 13:13:39 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-18 13:13:39 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-18 13:13:39 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-18 13:13:39 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-18 13:13:39 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-18 13:13:39 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-18 13:13:39 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-18 13:13:39 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-18 13:13:39 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-18 13:13:39 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-18 13:13:39 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-18 13:13:39 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-18 13:13:39 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-18 13:13:39 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-18 13:13:39 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-18 13:13:39 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-18 13:13:39 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-18 13:13:39 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-18 13:13:39 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-18 13:13:39 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-18 13:13:39 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-18 13:13:39 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-18 13:13:39 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-18 13:13:39 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-18 13:13:39 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-18 13:13:39 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-18 13:13:39 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-18 13:13:39 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-18 13:13:39 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-18 13:13:39 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-18 13:13:39 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-18 13:13:39 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-18 13:13:39 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-18 13:13:39 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-18 13:13:39 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-18 13:13:39 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-18 13:13:39 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-18 13:13:39 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-18 13:13:39 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-18 13:13:39 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-18 13:13:39 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-18 13:13:39 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-18 13:13:39 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-18 13:13:39 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-18 13:13:39 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-18 13:13:39 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-18 13:13:39 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-18 13:13:39 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-18 13:13:39 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-18 13:13:39 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-18 13:13:39 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-18 13:13:39 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-18 13:13:39 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-18 13:13:39 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-18 13:13:39 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-18 13:13:39 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-18 13:13:39 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-18 13:13:39 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-18 13:13:39 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-18 13:13:39 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-18 13:13:39 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-18 13:13:39 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
INFO - 2024-02-18 13:13:39 --> Language file loaded: language/english/email_lang.php
INFO - 2024-02-18 13:13:39 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice_html.php
INFO - 2024-02-18 13:13:39 --> Final output sent to browser
DEBUG - 2024-02-18 13:13:39 --> Total execution time: 0.2211
ERROR - 2024-02-18 13:13:41 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-18 13:13:41 --> Config Class Initialized
INFO - 2024-02-18 13:13:41 --> Hooks Class Initialized
DEBUG - 2024-02-18 13:13:41 --> UTF-8 Support Enabled
INFO - 2024-02-18 13:13:41 --> Utf8 Class Initialized
INFO - 2024-02-18 13:13:41 --> URI Class Initialized
DEBUG - 2024-02-18 13:13:41 --> No URI present. Default controller set.
INFO - 2024-02-18 13:13:41 --> Router Class Initialized
INFO - 2024-02-18 13:13:41 --> Output Class Initialized
INFO - 2024-02-18 13:13:41 --> Security Class Initialized
DEBUG - 2024-02-18 13:13:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-18 13:13:41 --> Input Class Initialized
INFO - 2024-02-18 13:13:41 --> Language Class Initialized
INFO - 2024-02-18 13:13:41 --> Loader Class Initialized
INFO - 2024-02-18 13:13:41 --> Helper loaded: url_helper
INFO - 2024-02-18 13:13:41 --> Helper loaded: file_helper
INFO - 2024-02-18 13:13:41 --> Helper loaded: html_helper
INFO - 2024-02-18 13:13:41 --> Helper loaded: text_helper
INFO - 2024-02-18 13:13:41 --> Helper loaded: form_helper
INFO - 2024-02-18 13:13:41 --> Helper loaded: lang_helper
INFO - 2024-02-18 13:13:41 --> Helper loaded: security_helper
INFO - 2024-02-18 13:13:41 --> Helper loaded: cookie_helper
INFO - 2024-02-18 13:13:41 --> Database Driver Class Initialized
INFO - 2024-02-18 13:13:41 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-18 13:13:41 --> Parser Class Initialized
INFO - 2024-02-18 13:13:41 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-18 13:13:41 --> Pagination Class Initialized
INFO - 2024-02-18 13:13:41 --> Form Validation Class Initialized
INFO - 2024-02-18 13:13:41 --> Controller Class Initialized
INFO - 2024-02-18 13:13:41 --> Model Class Initialized
DEBUG - 2024-02-18 13:13:41 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-18 13:13:41 --> Model Class Initialized
DEBUG - 2024-02-18 13:13:41 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-18 13:13:41 --> Model Class Initialized
INFO - 2024-02-18 13:13:41 --> Model Class Initialized
INFO - 2024-02-18 13:13:41 --> Model Class Initialized
INFO - 2024-02-18 13:13:41 --> Model Class Initialized
DEBUG - 2024-02-18 13:13:41 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-18 13:13:41 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-18 13:13:41 --> Model Class Initialized
INFO - 2024-02-18 13:13:41 --> Model Class Initialized
INFO - 2024-02-18 13:13:42 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2024-02-18 13:13:42 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-02-18 13:13:42 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-02-18 13:13:42 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-02-18 13:13:42 --> Model Class Initialized
INFO - 2024-02-18 13:13:42 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-02-18 13:13:42 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-02-18 13:13:42 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-02-18 13:13:42 --> Final output sent to browser
DEBUG - 2024-02-18 13:13:42 --> Total execution time: 0.2262
ERROR - 2024-02-18 13:13:47 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-18 13:13:47 --> Config Class Initialized
INFO - 2024-02-18 13:13:47 --> Hooks Class Initialized
DEBUG - 2024-02-18 13:13:47 --> UTF-8 Support Enabled
INFO - 2024-02-18 13:13:47 --> Utf8 Class Initialized
INFO - 2024-02-18 13:13:47 --> URI Class Initialized
INFO - 2024-02-18 13:13:47 --> Router Class Initialized
INFO - 2024-02-18 13:13:47 --> Output Class Initialized
INFO - 2024-02-18 13:13:47 --> Security Class Initialized
DEBUG - 2024-02-18 13:13:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-18 13:13:47 --> Input Class Initialized
INFO - 2024-02-18 13:13:47 --> Language Class Initialized
INFO - 2024-02-18 13:13:47 --> Loader Class Initialized
INFO - 2024-02-18 13:13:47 --> Helper loaded: url_helper
INFO - 2024-02-18 13:13:47 --> Helper loaded: file_helper
INFO - 2024-02-18 13:13:47 --> Helper loaded: html_helper
INFO - 2024-02-18 13:13:47 --> Helper loaded: text_helper
INFO - 2024-02-18 13:13:47 --> Helper loaded: form_helper
INFO - 2024-02-18 13:13:47 --> Helper loaded: lang_helper
INFO - 2024-02-18 13:13:47 --> Helper loaded: security_helper
INFO - 2024-02-18 13:13:47 --> Helper loaded: cookie_helper
INFO - 2024-02-18 13:13:47 --> Database Driver Class Initialized
INFO - 2024-02-18 13:13:47 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-18 13:13:47 --> Parser Class Initialized
INFO - 2024-02-18 13:13:47 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-18 13:13:47 --> Pagination Class Initialized
INFO - 2024-02-18 13:13:47 --> Form Validation Class Initialized
INFO - 2024-02-18 13:13:47 --> Controller Class Initialized
INFO - 2024-02-18 13:13:47 --> Model Class Initialized
DEBUG - 2024-02-18 13:13:47 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-18 13:13:47 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-18 13:13:47 --> Model Class Initialized
DEBUG - 2024-02-18 13:13:47 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-18 13:13:47 --> Model Class Initialized
INFO - 2024-02-18 13:13:47 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/add_invoice_form.php
DEBUG - 2024-02-18 13:13:47 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-02-18 13:13:47 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-02-18 13:13:47 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-02-18 13:13:47 --> Model Class Initialized
INFO - 2024-02-18 13:13:47 --> Model Class Initialized
INFO - 2024-02-18 13:13:47 --> Model Class Initialized
INFO - 2024-02-18 13:13:47 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-02-18 13:13:47 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-02-18 13:13:47 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-02-18 13:13:47 --> Final output sent to browser
DEBUG - 2024-02-18 13:13:47 --> Total execution time: 0.1642
ERROR - 2024-02-18 13:13:58 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-18 13:13:58 --> Config Class Initialized
INFO - 2024-02-18 13:13:58 --> Hooks Class Initialized
DEBUG - 2024-02-18 13:13:58 --> UTF-8 Support Enabled
INFO - 2024-02-18 13:13:58 --> Utf8 Class Initialized
INFO - 2024-02-18 13:13:58 --> URI Class Initialized
INFO - 2024-02-18 13:13:58 --> Router Class Initialized
INFO - 2024-02-18 13:13:58 --> Output Class Initialized
INFO - 2024-02-18 13:13:58 --> Security Class Initialized
DEBUG - 2024-02-18 13:13:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-18 13:13:58 --> Input Class Initialized
INFO - 2024-02-18 13:13:58 --> Language Class Initialized
INFO - 2024-02-18 13:13:58 --> Loader Class Initialized
INFO - 2024-02-18 13:13:58 --> Helper loaded: url_helper
INFO - 2024-02-18 13:13:58 --> Helper loaded: file_helper
INFO - 2024-02-18 13:13:58 --> Helper loaded: html_helper
INFO - 2024-02-18 13:13:58 --> Helper loaded: text_helper
INFO - 2024-02-18 13:13:58 --> Helper loaded: form_helper
INFO - 2024-02-18 13:13:58 --> Helper loaded: lang_helper
INFO - 2024-02-18 13:13:58 --> Helper loaded: security_helper
INFO - 2024-02-18 13:13:58 --> Helper loaded: cookie_helper
INFO - 2024-02-18 13:13:58 --> Database Driver Class Initialized
INFO - 2024-02-18 13:13:58 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-18 13:13:58 --> Parser Class Initialized
INFO - 2024-02-18 13:13:58 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-18 13:13:58 --> Pagination Class Initialized
INFO - 2024-02-18 13:13:58 --> Form Validation Class Initialized
INFO - 2024-02-18 13:13:58 --> Controller Class Initialized
INFO - 2024-02-18 13:13:58 --> Model Class Initialized
DEBUG - 2024-02-18 13:13:58 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-18 13:13:58 --> Final output sent to browser
DEBUG - 2024-02-18 13:13:58 --> Total execution time: 0.0163
ERROR - 2024-02-18 13:13:58 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-18 13:13:58 --> Config Class Initialized
INFO - 2024-02-18 13:13:58 --> Hooks Class Initialized
DEBUG - 2024-02-18 13:13:58 --> UTF-8 Support Enabled
INFO - 2024-02-18 13:13:58 --> Utf8 Class Initialized
INFO - 2024-02-18 13:13:58 --> URI Class Initialized
INFO - 2024-02-18 13:13:58 --> Router Class Initialized
INFO - 2024-02-18 13:13:58 --> Output Class Initialized
INFO - 2024-02-18 13:13:58 --> Security Class Initialized
DEBUG - 2024-02-18 13:13:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-18 13:13:58 --> Input Class Initialized
INFO - 2024-02-18 13:13:58 --> Language Class Initialized
INFO - 2024-02-18 13:13:58 --> Loader Class Initialized
INFO - 2024-02-18 13:13:58 --> Helper loaded: url_helper
INFO - 2024-02-18 13:13:58 --> Helper loaded: file_helper
INFO - 2024-02-18 13:13:58 --> Helper loaded: html_helper
INFO - 2024-02-18 13:13:58 --> Helper loaded: text_helper
INFO - 2024-02-18 13:13:58 --> Helper loaded: form_helper
INFO - 2024-02-18 13:13:58 --> Helper loaded: lang_helper
INFO - 2024-02-18 13:13:58 --> Helper loaded: security_helper
INFO - 2024-02-18 13:13:58 --> Helper loaded: cookie_helper
INFO - 2024-02-18 13:13:58 --> Database Driver Class Initialized
INFO - 2024-02-18 13:13:58 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-18 13:13:58 --> Parser Class Initialized
INFO - 2024-02-18 13:13:58 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-18 13:13:58 --> Pagination Class Initialized
INFO - 2024-02-18 13:13:58 --> Form Validation Class Initialized
INFO - 2024-02-18 13:13:58 --> Controller Class Initialized
INFO - 2024-02-18 13:13:58 --> Model Class Initialized
DEBUG - 2024-02-18 13:13:58 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-18 13:13:58 --> Final output sent to browser
DEBUG - 2024-02-18 13:13:58 --> Total execution time: 0.0154
ERROR - 2024-02-18 13:14:05 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-18 13:14:05 --> Config Class Initialized
INFO - 2024-02-18 13:14:05 --> Hooks Class Initialized
DEBUG - 2024-02-18 13:14:05 --> UTF-8 Support Enabled
INFO - 2024-02-18 13:14:05 --> Utf8 Class Initialized
INFO - 2024-02-18 13:14:05 --> URI Class Initialized
INFO - 2024-02-18 13:14:05 --> Router Class Initialized
INFO - 2024-02-18 13:14:05 --> Output Class Initialized
INFO - 2024-02-18 13:14:05 --> Security Class Initialized
DEBUG - 2024-02-18 13:14:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-18 13:14:05 --> Input Class Initialized
INFO - 2024-02-18 13:14:05 --> Language Class Initialized
INFO - 2024-02-18 13:14:05 --> Loader Class Initialized
INFO - 2024-02-18 13:14:05 --> Helper loaded: url_helper
INFO - 2024-02-18 13:14:05 --> Helper loaded: file_helper
INFO - 2024-02-18 13:14:05 --> Helper loaded: html_helper
INFO - 2024-02-18 13:14:05 --> Helper loaded: text_helper
INFO - 2024-02-18 13:14:05 --> Helper loaded: form_helper
INFO - 2024-02-18 13:14:05 --> Helper loaded: lang_helper
INFO - 2024-02-18 13:14:05 --> Helper loaded: security_helper
INFO - 2024-02-18 13:14:05 --> Helper loaded: cookie_helper
INFO - 2024-02-18 13:14:05 --> Database Driver Class Initialized
INFO - 2024-02-18 13:14:05 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-18 13:14:05 --> Parser Class Initialized
INFO - 2024-02-18 13:14:05 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-18 13:14:05 --> Pagination Class Initialized
INFO - 2024-02-18 13:14:05 --> Form Validation Class Initialized
INFO - 2024-02-18 13:14:05 --> Controller Class Initialized
INFO - 2024-02-18 13:14:05 --> Model Class Initialized
DEBUG - 2024-02-18 13:14:05 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-18 13:14:05 --> Final output sent to browser
DEBUG - 2024-02-18 13:14:05 --> Total execution time: 0.0166
ERROR - 2024-02-18 13:14:07 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-18 13:14:07 --> Config Class Initialized
INFO - 2024-02-18 13:14:07 --> Hooks Class Initialized
DEBUG - 2024-02-18 13:14:07 --> UTF-8 Support Enabled
INFO - 2024-02-18 13:14:07 --> Utf8 Class Initialized
INFO - 2024-02-18 13:14:07 --> URI Class Initialized
INFO - 2024-02-18 13:14:07 --> Router Class Initialized
INFO - 2024-02-18 13:14:07 --> Output Class Initialized
INFO - 2024-02-18 13:14:07 --> Security Class Initialized
DEBUG - 2024-02-18 13:14:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-18 13:14:07 --> Input Class Initialized
INFO - 2024-02-18 13:14:07 --> Language Class Initialized
INFO - 2024-02-18 13:14:07 --> Loader Class Initialized
INFO - 2024-02-18 13:14:07 --> Helper loaded: url_helper
INFO - 2024-02-18 13:14:07 --> Helper loaded: file_helper
INFO - 2024-02-18 13:14:07 --> Helper loaded: html_helper
INFO - 2024-02-18 13:14:07 --> Helper loaded: text_helper
INFO - 2024-02-18 13:14:07 --> Helper loaded: form_helper
INFO - 2024-02-18 13:14:07 --> Helper loaded: lang_helper
INFO - 2024-02-18 13:14:07 --> Helper loaded: security_helper
INFO - 2024-02-18 13:14:07 --> Helper loaded: cookie_helper
INFO - 2024-02-18 13:14:07 --> Database Driver Class Initialized
INFO - 2024-02-18 13:14:07 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-18 13:14:07 --> Parser Class Initialized
INFO - 2024-02-18 13:14:07 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-18 13:14:07 --> Pagination Class Initialized
INFO - 2024-02-18 13:14:07 --> Form Validation Class Initialized
INFO - 2024-02-18 13:14:07 --> Controller Class Initialized
INFO - 2024-02-18 13:14:07 --> Model Class Initialized
DEBUG - 2024-02-18 13:14:07 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-18 13:14:07 --> Final output sent to browser
DEBUG - 2024-02-18 13:14:07 --> Total execution time: 0.0178
ERROR - 2024-02-18 13:14:08 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-18 13:14:08 --> Config Class Initialized
INFO - 2024-02-18 13:14:08 --> Hooks Class Initialized
DEBUG - 2024-02-18 13:14:08 --> UTF-8 Support Enabled
INFO - 2024-02-18 13:14:08 --> Utf8 Class Initialized
INFO - 2024-02-18 13:14:08 --> URI Class Initialized
INFO - 2024-02-18 13:14:08 --> Router Class Initialized
INFO - 2024-02-18 13:14:08 --> Output Class Initialized
INFO - 2024-02-18 13:14:08 --> Security Class Initialized
DEBUG - 2024-02-18 13:14:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-18 13:14:08 --> Input Class Initialized
INFO - 2024-02-18 13:14:08 --> Language Class Initialized
INFO - 2024-02-18 13:14:08 --> Loader Class Initialized
INFO - 2024-02-18 13:14:08 --> Helper loaded: url_helper
INFO - 2024-02-18 13:14:08 --> Helper loaded: file_helper
INFO - 2024-02-18 13:14:08 --> Helper loaded: html_helper
INFO - 2024-02-18 13:14:08 --> Helper loaded: text_helper
INFO - 2024-02-18 13:14:08 --> Helper loaded: form_helper
INFO - 2024-02-18 13:14:08 --> Helper loaded: lang_helper
INFO - 2024-02-18 13:14:08 --> Helper loaded: security_helper
INFO - 2024-02-18 13:14:08 --> Helper loaded: cookie_helper
INFO - 2024-02-18 13:14:08 --> Database Driver Class Initialized
INFO - 2024-02-18 13:14:08 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-18 13:14:08 --> Parser Class Initialized
INFO - 2024-02-18 13:14:08 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-18 13:14:08 --> Pagination Class Initialized
INFO - 2024-02-18 13:14:08 --> Form Validation Class Initialized
INFO - 2024-02-18 13:14:08 --> Controller Class Initialized
INFO - 2024-02-18 13:14:08 --> Model Class Initialized
DEBUG - 2024-02-18 13:14:08 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-18 13:14:08 --> Final output sent to browser
DEBUG - 2024-02-18 13:14:08 --> Total execution time: 0.0159
ERROR - 2024-02-18 13:14:28 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-18 13:14:28 --> Config Class Initialized
INFO - 2024-02-18 13:14:28 --> Hooks Class Initialized
DEBUG - 2024-02-18 13:14:28 --> UTF-8 Support Enabled
INFO - 2024-02-18 13:14:28 --> Utf8 Class Initialized
INFO - 2024-02-18 13:14:28 --> URI Class Initialized
INFO - 2024-02-18 13:14:28 --> Router Class Initialized
INFO - 2024-02-18 13:14:28 --> Output Class Initialized
INFO - 2024-02-18 13:14:28 --> Security Class Initialized
DEBUG - 2024-02-18 13:14:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-18 13:14:28 --> Input Class Initialized
INFO - 2024-02-18 13:14:28 --> Language Class Initialized
INFO - 2024-02-18 13:14:28 --> Loader Class Initialized
INFO - 2024-02-18 13:14:28 --> Helper loaded: url_helper
INFO - 2024-02-18 13:14:28 --> Helper loaded: file_helper
INFO - 2024-02-18 13:14:28 --> Helper loaded: html_helper
INFO - 2024-02-18 13:14:28 --> Helper loaded: text_helper
INFO - 2024-02-18 13:14:28 --> Helper loaded: form_helper
INFO - 2024-02-18 13:14:28 --> Helper loaded: lang_helper
INFO - 2024-02-18 13:14:28 --> Helper loaded: security_helper
INFO - 2024-02-18 13:14:28 --> Helper loaded: cookie_helper
INFO - 2024-02-18 13:14:28 --> Database Driver Class Initialized
INFO - 2024-02-18 13:14:28 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-18 13:14:28 --> Parser Class Initialized
INFO - 2024-02-18 13:14:28 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-18 13:14:28 --> Pagination Class Initialized
INFO - 2024-02-18 13:14:28 --> Form Validation Class Initialized
INFO - 2024-02-18 13:14:28 --> Controller Class Initialized
INFO - 2024-02-18 13:14:28 --> Final output sent to browser
DEBUG - 2024-02-18 13:14:28 --> Total execution time: 0.0173
ERROR - 2024-02-18 13:14:36 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-18 13:14:36 --> Config Class Initialized
INFO - 2024-02-18 13:14:36 --> Hooks Class Initialized
DEBUG - 2024-02-18 13:14:36 --> UTF-8 Support Enabled
INFO - 2024-02-18 13:14:36 --> Utf8 Class Initialized
INFO - 2024-02-18 13:14:36 --> URI Class Initialized
INFO - 2024-02-18 13:14:36 --> Router Class Initialized
INFO - 2024-02-18 13:14:36 --> Output Class Initialized
INFO - 2024-02-18 13:14:36 --> Security Class Initialized
DEBUG - 2024-02-18 13:14:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-18 13:14:36 --> Input Class Initialized
INFO - 2024-02-18 13:14:36 --> Language Class Initialized
INFO - 2024-02-18 13:14:36 --> Loader Class Initialized
INFO - 2024-02-18 13:14:36 --> Helper loaded: url_helper
INFO - 2024-02-18 13:14:36 --> Helper loaded: file_helper
INFO - 2024-02-18 13:14:36 --> Helper loaded: html_helper
INFO - 2024-02-18 13:14:36 --> Helper loaded: text_helper
INFO - 2024-02-18 13:14:36 --> Helper loaded: form_helper
INFO - 2024-02-18 13:14:36 --> Helper loaded: lang_helper
INFO - 2024-02-18 13:14:36 --> Helper loaded: security_helper
INFO - 2024-02-18 13:14:36 --> Helper loaded: cookie_helper
INFO - 2024-02-18 13:14:36 --> Database Driver Class Initialized
INFO - 2024-02-18 13:14:36 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-18 13:14:36 --> Parser Class Initialized
INFO - 2024-02-18 13:14:36 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-18 13:14:36 --> Pagination Class Initialized
INFO - 2024-02-18 13:14:36 --> Form Validation Class Initialized
INFO - 2024-02-18 13:14:36 --> Controller Class Initialized
INFO - 2024-02-18 13:14:36 --> Model Class Initialized
DEBUG - 2024-02-18 13:14:36 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-18 13:14:36 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-18 13:14:36 --> Model Class Initialized
DEBUG - 2024-02-18 13:14:36 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-18 13:14:36 --> Model Class Initialized
INFO - 2024-02-18 13:14:36 --> Final output sent to browser
DEBUG - 2024-02-18 13:14:36 --> Total execution time: 0.1002
ERROR - 2024-02-18 13:14:37 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-18 13:14:37 --> Config Class Initialized
INFO - 2024-02-18 13:14:37 --> Hooks Class Initialized
DEBUG - 2024-02-18 13:14:37 --> UTF-8 Support Enabled
INFO - 2024-02-18 13:14:37 --> Utf8 Class Initialized
INFO - 2024-02-18 13:14:37 --> URI Class Initialized
INFO - 2024-02-18 13:14:37 --> Router Class Initialized
INFO - 2024-02-18 13:14:37 --> Output Class Initialized
INFO - 2024-02-18 13:14:37 --> Security Class Initialized
DEBUG - 2024-02-18 13:14:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-18 13:14:37 --> Input Class Initialized
INFO - 2024-02-18 13:14:37 --> Language Class Initialized
INFO - 2024-02-18 13:14:37 --> Loader Class Initialized
INFO - 2024-02-18 13:14:37 --> Helper loaded: url_helper
INFO - 2024-02-18 13:14:37 --> Helper loaded: file_helper
INFO - 2024-02-18 13:14:37 --> Helper loaded: html_helper
INFO - 2024-02-18 13:14:37 --> Helper loaded: text_helper
INFO - 2024-02-18 13:14:37 --> Helper loaded: form_helper
INFO - 2024-02-18 13:14:37 --> Helper loaded: lang_helper
INFO - 2024-02-18 13:14:37 --> Helper loaded: security_helper
INFO - 2024-02-18 13:14:37 --> Helper loaded: cookie_helper
INFO - 2024-02-18 13:14:37 --> Database Driver Class Initialized
INFO - 2024-02-18 13:14:37 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-18 13:14:37 --> Parser Class Initialized
INFO - 2024-02-18 13:14:37 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-18 13:14:37 --> Pagination Class Initialized
INFO - 2024-02-18 13:14:37 --> Form Validation Class Initialized
INFO - 2024-02-18 13:14:37 --> Controller Class Initialized
INFO - 2024-02-18 13:14:37 --> Model Class Initialized
DEBUG - 2024-02-18 13:14:37 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-18 13:14:37 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-18 13:14:37 --> Model Class Initialized
DEBUG - 2024-02-18 13:14:37 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-18 13:14:37 --> Model Class Initialized
INFO - 2024-02-18 13:14:37 --> Final output sent to browser
DEBUG - 2024-02-18 13:14:37 --> Total execution time: 0.0947
ERROR - 2024-02-18 13:14:38 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-18 13:14:38 --> Config Class Initialized
INFO - 2024-02-18 13:14:38 --> Hooks Class Initialized
DEBUG - 2024-02-18 13:14:38 --> UTF-8 Support Enabled
INFO - 2024-02-18 13:14:38 --> Utf8 Class Initialized
INFO - 2024-02-18 13:14:38 --> URI Class Initialized
INFO - 2024-02-18 13:14:38 --> Router Class Initialized
INFO - 2024-02-18 13:14:38 --> Output Class Initialized
INFO - 2024-02-18 13:14:38 --> Security Class Initialized
DEBUG - 2024-02-18 13:14:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-18 13:14:38 --> Input Class Initialized
INFO - 2024-02-18 13:14:38 --> Language Class Initialized
INFO - 2024-02-18 13:14:38 --> Loader Class Initialized
INFO - 2024-02-18 13:14:38 --> Helper loaded: url_helper
INFO - 2024-02-18 13:14:38 --> Helper loaded: file_helper
INFO - 2024-02-18 13:14:38 --> Helper loaded: html_helper
INFO - 2024-02-18 13:14:38 --> Helper loaded: text_helper
INFO - 2024-02-18 13:14:38 --> Helper loaded: form_helper
INFO - 2024-02-18 13:14:38 --> Helper loaded: lang_helper
INFO - 2024-02-18 13:14:38 --> Helper loaded: security_helper
INFO - 2024-02-18 13:14:38 --> Helper loaded: cookie_helper
INFO - 2024-02-18 13:14:38 --> Database Driver Class Initialized
INFO - 2024-02-18 13:14:38 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-18 13:14:38 --> Parser Class Initialized
INFO - 2024-02-18 13:14:38 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-18 13:14:38 --> Pagination Class Initialized
INFO - 2024-02-18 13:14:38 --> Form Validation Class Initialized
INFO - 2024-02-18 13:14:38 --> Controller Class Initialized
INFO - 2024-02-18 13:14:38 --> Model Class Initialized
DEBUG - 2024-02-18 13:14:38 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-18 13:14:38 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-18 13:14:38 --> Model Class Initialized
INFO - 2024-02-18 13:14:38 --> Model Class Initialized
INFO - 2024-02-18 13:14:38 --> Final output sent to browser
DEBUG - 2024-02-18 13:14:38 --> Total execution time: 0.0199
ERROR - 2024-02-18 13:14:39 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-18 13:14:39 --> Config Class Initialized
INFO - 2024-02-18 13:14:39 --> Hooks Class Initialized
DEBUG - 2024-02-18 13:14:39 --> UTF-8 Support Enabled
INFO - 2024-02-18 13:14:39 --> Utf8 Class Initialized
INFO - 2024-02-18 13:14:39 --> URI Class Initialized
INFO - 2024-02-18 13:14:39 --> Router Class Initialized
INFO - 2024-02-18 13:14:39 --> Output Class Initialized
INFO - 2024-02-18 13:14:39 --> Security Class Initialized
DEBUG - 2024-02-18 13:14:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-18 13:14:39 --> Input Class Initialized
INFO - 2024-02-18 13:14:39 --> Language Class Initialized
INFO - 2024-02-18 13:14:39 --> Loader Class Initialized
INFO - 2024-02-18 13:14:39 --> Helper loaded: url_helper
INFO - 2024-02-18 13:14:39 --> Helper loaded: file_helper
INFO - 2024-02-18 13:14:39 --> Helper loaded: html_helper
INFO - 2024-02-18 13:14:39 --> Helper loaded: text_helper
INFO - 2024-02-18 13:14:39 --> Helper loaded: form_helper
INFO - 2024-02-18 13:14:39 --> Helper loaded: lang_helper
INFO - 2024-02-18 13:14:39 --> Helper loaded: security_helper
INFO - 2024-02-18 13:14:39 --> Helper loaded: cookie_helper
INFO - 2024-02-18 13:14:39 --> Database Driver Class Initialized
INFO - 2024-02-18 13:14:39 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-18 13:14:39 --> Parser Class Initialized
INFO - 2024-02-18 13:14:39 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-18 13:14:39 --> Pagination Class Initialized
INFO - 2024-02-18 13:14:39 --> Form Validation Class Initialized
INFO - 2024-02-18 13:14:39 --> Controller Class Initialized
INFO - 2024-02-18 13:14:39 --> Model Class Initialized
DEBUG - 2024-02-18 13:14:39 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-18 13:14:39 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-18 13:14:39 --> Model Class Initialized
INFO - 2024-02-18 13:14:39 --> Final output sent to browser
DEBUG - 2024-02-18 13:14:39 --> Total execution time: 0.0170
ERROR - 2024-02-18 13:14:41 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-18 13:14:41 --> Config Class Initialized
INFO - 2024-02-18 13:14:41 --> Hooks Class Initialized
DEBUG - 2024-02-18 13:14:41 --> UTF-8 Support Enabled
INFO - 2024-02-18 13:14:41 --> Utf8 Class Initialized
INFO - 2024-02-18 13:14:41 --> URI Class Initialized
INFO - 2024-02-18 13:14:41 --> Router Class Initialized
INFO - 2024-02-18 13:14:41 --> Output Class Initialized
INFO - 2024-02-18 13:14:41 --> Security Class Initialized
DEBUG - 2024-02-18 13:14:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-18 13:14:41 --> Input Class Initialized
INFO - 2024-02-18 13:14:41 --> Language Class Initialized
INFO - 2024-02-18 13:14:41 --> Loader Class Initialized
INFO - 2024-02-18 13:14:41 --> Helper loaded: url_helper
INFO - 2024-02-18 13:14:41 --> Helper loaded: file_helper
INFO - 2024-02-18 13:14:41 --> Helper loaded: html_helper
INFO - 2024-02-18 13:14:41 --> Helper loaded: text_helper
INFO - 2024-02-18 13:14:41 --> Helper loaded: form_helper
INFO - 2024-02-18 13:14:41 --> Helper loaded: lang_helper
INFO - 2024-02-18 13:14:41 --> Helper loaded: security_helper
INFO - 2024-02-18 13:14:41 --> Helper loaded: cookie_helper
INFO - 2024-02-18 13:14:41 --> Database Driver Class Initialized
INFO - 2024-02-18 13:14:41 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-18 13:14:41 --> Parser Class Initialized
INFO - 2024-02-18 13:14:41 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-18 13:14:41 --> Pagination Class Initialized
INFO - 2024-02-18 13:14:41 --> Form Validation Class Initialized
INFO - 2024-02-18 13:14:41 --> Controller Class Initialized
INFO - 2024-02-18 13:14:41 --> Model Class Initialized
DEBUG - 2024-02-18 13:14:41 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-18 13:14:41 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-18 13:14:41 --> Model Class Initialized
INFO - 2024-02-18 13:14:41 --> Final output sent to browser
DEBUG - 2024-02-18 13:14:41 --> Total execution time: 0.0168
ERROR - 2024-02-18 13:14:52 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-18 13:14:52 --> Config Class Initialized
INFO - 2024-02-18 13:14:52 --> Hooks Class Initialized
DEBUG - 2024-02-18 13:14:52 --> UTF-8 Support Enabled
INFO - 2024-02-18 13:14:52 --> Utf8 Class Initialized
INFO - 2024-02-18 13:14:52 --> URI Class Initialized
INFO - 2024-02-18 13:14:52 --> Router Class Initialized
INFO - 2024-02-18 13:14:52 --> Output Class Initialized
INFO - 2024-02-18 13:14:52 --> Security Class Initialized
DEBUG - 2024-02-18 13:14:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-18 13:14:52 --> Input Class Initialized
INFO - 2024-02-18 13:14:52 --> Language Class Initialized
INFO - 2024-02-18 13:14:52 --> Loader Class Initialized
INFO - 2024-02-18 13:14:52 --> Helper loaded: url_helper
INFO - 2024-02-18 13:14:52 --> Helper loaded: file_helper
INFO - 2024-02-18 13:14:52 --> Helper loaded: html_helper
INFO - 2024-02-18 13:14:52 --> Helper loaded: text_helper
INFO - 2024-02-18 13:14:52 --> Helper loaded: form_helper
INFO - 2024-02-18 13:14:52 --> Helper loaded: lang_helper
INFO - 2024-02-18 13:14:52 --> Helper loaded: security_helper
INFO - 2024-02-18 13:14:52 --> Helper loaded: cookie_helper
INFO - 2024-02-18 13:14:52 --> Database Driver Class Initialized
INFO - 2024-02-18 13:14:52 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-18 13:14:52 --> Parser Class Initialized
INFO - 2024-02-18 13:14:52 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-18 13:14:52 --> Pagination Class Initialized
INFO - 2024-02-18 13:14:52 --> Form Validation Class Initialized
INFO - 2024-02-18 13:14:52 --> Controller Class Initialized
INFO - 2024-02-18 13:14:52 --> Model Class Initialized
DEBUG - 2024-02-18 13:14:52 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-18 13:14:52 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-18 13:14:52 --> Model Class Initialized
DEBUG - 2024-02-18 13:14:52 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-18 13:14:52 --> Model Class Initialized
INFO - 2024-02-18 13:14:52 --> Final output sent to browser
DEBUG - 2024-02-18 13:14:52 --> Total execution time: 0.0928
ERROR - 2024-02-18 13:14:53 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-18 13:14:53 --> Config Class Initialized
INFO - 2024-02-18 13:14:53 --> Hooks Class Initialized
DEBUG - 2024-02-18 13:14:53 --> UTF-8 Support Enabled
INFO - 2024-02-18 13:14:53 --> Utf8 Class Initialized
INFO - 2024-02-18 13:14:53 --> URI Class Initialized
INFO - 2024-02-18 13:14:53 --> Router Class Initialized
INFO - 2024-02-18 13:14:53 --> Output Class Initialized
INFO - 2024-02-18 13:14:53 --> Security Class Initialized
DEBUG - 2024-02-18 13:14:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-18 13:14:53 --> Input Class Initialized
INFO - 2024-02-18 13:14:53 --> Language Class Initialized
INFO - 2024-02-18 13:14:53 --> Loader Class Initialized
INFO - 2024-02-18 13:14:53 --> Helper loaded: url_helper
INFO - 2024-02-18 13:14:53 --> Helper loaded: file_helper
INFO - 2024-02-18 13:14:53 --> Helper loaded: html_helper
INFO - 2024-02-18 13:14:53 --> Helper loaded: text_helper
INFO - 2024-02-18 13:14:53 --> Helper loaded: form_helper
INFO - 2024-02-18 13:14:53 --> Helper loaded: lang_helper
INFO - 2024-02-18 13:14:53 --> Helper loaded: security_helper
INFO - 2024-02-18 13:14:53 --> Helper loaded: cookie_helper
INFO - 2024-02-18 13:14:53 --> Database Driver Class Initialized
INFO - 2024-02-18 13:14:53 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-18 13:14:53 --> Parser Class Initialized
INFO - 2024-02-18 13:14:53 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-18 13:14:53 --> Pagination Class Initialized
INFO - 2024-02-18 13:14:53 --> Form Validation Class Initialized
INFO - 2024-02-18 13:14:53 --> Controller Class Initialized
INFO - 2024-02-18 13:14:53 --> Model Class Initialized
DEBUG - 2024-02-18 13:14:53 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-18 13:14:53 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-18 13:14:53 --> Model Class Initialized
DEBUG - 2024-02-18 13:14:53 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-18 13:14:53 --> Model Class Initialized
INFO - 2024-02-18 13:14:53 --> Final output sent to browser
DEBUG - 2024-02-18 13:14:53 --> Total execution time: 0.0931
ERROR - 2024-02-18 13:14:54 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-18 13:14:54 --> Config Class Initialized
INFO - 2024-02-18 13:14:54 --> Hooks Class Initialized
DEBUG - 2024-02-18 13:14:54 --> UTF-8 Support Enabled
INFO - 2024-02-18 13:14:54 --> Utf8 Class Initialized
INFO - 2024-02-18 13:14:54 --> URI Class Initialized
INFO - 2024-02-18 13:14:54 --> Router Class Initialized
INFO - 2024-02-18 13:14:54 --> Output Class Initialized
INFO - 2024-02-18 13:14:54 --> Security Class Initialized
DEBUG - 2024-02-18 13:14:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-18 13:14:54 --> Input Class Initialized
INFO - 2024-02-18 13:14:54 --> Language Class Initialized
INFO - 2024-02-18 13:14:54 --> Loader Class Initialized
INFO - 2024-02-18 13:14:54 --> Helper loaded: url_helper
INFO - 2024-02-18 13:14:54 --> Helper loaded: file_helper
INFO - 2024-02-18 13:14:54 --> Helper loaded: html_helper
INFO - 2024-02-18 13:14:54 --> Helper loaded: text_helper
INFO - 2024-02-18 13:14:54 --> Helper loaded: form_helper
INFO - 2024-02-18 13:14:54 --> Helper loaded: lang_helper
INFO - 2024-02-18 13:14:54 --> Helper loaded: security_helper
INFO - 2024-02-18 13:14:54 --> Helper loaded: cookie_helper
INFO - 2024-02-18 13:14:54 --> Database Driver Class Initialized
INFO - 2024-02-18 13:14:54 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-18 13:14:54 --> Parser Class Initialized
INFO - 2024-02-18 13:14:54 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-18 13:14:54 --> Pagination Class Initialized
INFO - 2024-02-18 13:14:54 --> Form Validation Class Initialized
INFO - 2024-02-18 13:14:54 --> Controller Class Initialized
INFO - 2024-02-18 13:14:54 --> Model Class Initialized
DEBUG - 2024-02-18 13:14:54 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-18 13:14:54 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-18 13:14:54 --> Model Class Initialized
DEBUG - 2024-02-18 13:14:54 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-18 13:14:54 --> Model Class Initialized
INFO - 2024-02-18 13:14:54 --> Final output sent to browser
DEBUG - 2024-02-18 13:14:54 --> Total execution time: 0.0970
ERROR - 2024-02-18 13:14:58 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-18 13:14:58 --> Config Class Initialized
INFO - 2024-02-18 13:14:58 --> Hooks Class Initialized
DEBUG - 2024-02-18 13:14:58 --> UTF-8 Support Enabled
INFO - 2024-02-18 13:14:58 --> Utf8 Class Initialized
INFO - 2024-02-18 13:14:58 --> URI Class Initialized
INFO - 2024-02-18 13:14:58 --> Router Class Initialized
INFO - 2024-02-18 13:14:59 --> Output Class Initialized
INFO - 2024-02-18 13:14:59 --> Security Class Initialized
DEBUG - 2024-02-18 13:14:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-18 13:14:59 --> Input Class Initialized
INFO - 2024-02-18 13:14:59 --> Language Class Initialized
INFO - 2024-02-18 13:14:59 --> Loader Class Initialized
INFO - 2024-02-18 13:14:59 --> Helper loaded: url_helper
INFO - 2024-02-18 13:14:59 --> Helper loaded: file_helper
INFO - 2024-02-18 13:14:59 --> Helper loaded: html_helper
INFO - 2024-02-18 13:14:59 --> Helper loaded: text_helper
INFO - 2024-02-18 13:14:59 --> Helper loaded: form_helper
INFO - 2024-02-18 13:14:59 --> Helper loaded: lang_helper
INFO - 2024-02-18 13:14:59 --> Helper loaded: security_helper
INFO - 2024-02-18 13:14:59 --> Helper loaded: cookie_helper
INFO - 2024-02-18 13:14:59 --> Database Driver Class Initialized
INFO - 2024-02-18 13:14:59 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-18 13:14:59 --> Parser Class Initialized
INFO - 2024-02-18 13:14:59 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-18 13:14:59 --> Pagination Class Initialized
INFO - 2024-02-18 13:14:59 --> Form Validation Class Initialized
INFO - 2024-02-18 13:14:59 --> Controller Class Initialized
INFO - 2024-02-18 13:14:59 --> Model Class Initialized
DEBUG - 2024-02-18 13:14:59 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-18 13:14:59 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-18 13:14:59 --> Model Class Initialized
INFO - 2024-02-18 13:14:59 --> Model Class Initialized
INFO - 2024-02-18 13:14:59 --> Final output sent to browser
DEBUG - 2024-02-18 13:14:59 --> Total execution time: 0.0209
ERROR - 2024-02-18 13:15:02 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-18 13:15:02 --> Config Class Initialized
INFO - 2024-02-18 13:15:02 --> Hooks Class Initialized
DEBUG - 2024-02-18 13:15:02 --> UTF-8 Support Enabled
INFO - 2024-02-18 13:15:02 --> Utf8 Class Initialized
INFO - 2024-02-18 13:15:02 --> URI Class Initialized
INFO - 2024-02-18 13:15:02 --> Router Class Initialized
INFO - 2024-02-18 13:15:02 --> Output Class Initialized
INFO - 2024-02-18 13:15:02 --> Security Class Initialized
DEBUG - 2024-02-18 13:15:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-18 13:15:02 --> Input Class Initialized
INFO - 2024-02-18 13:15:02 --> Language Class Initialized
INFO - 2024-02-18 13:15:02 --> Loader Class Initialized
INFO - 2024-02-18 13:15:02 --> Helper loaded: url_helper
INFO - 2024-02-18 13:15:02 --> Helper loaded: file_helper
INFO - 2024-02-18 13:15:02 --> Helper loaded: html_helper
INFO - 2024-02-18 13:15:02 --> Helper loaded: text_helper
INFO - 2024-02-18 13:15:02 --> Helper loaded: form_helper
INFO - 2024-02-18 13:15:02 --> Helper loaded: lang_helper
INFO - 2024-02-18 13:15:02 --> Helper loaded: security_helper
INFO - 2024-02-18 13:15:02 --> Helper loaded: cookie_helper
INFO - 2024-02-18 13:15:02 --> Database Driver Class Initialized
INFO - 2024-02-18 13:15:02 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-18 13:15:02 --> Parser Class Initialized
INFO - 2024-02-18 13:15:02 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-18 13:15:02 --> Pagination Class Initialized
INFO - 2024-02-18 13:15:02 --> Form Validation Class Initialized
INFO - 2024-02-18 13:15:02 --> Controller Class Initialized
INFO - 2024-02-18 13:15:02 --> Model Class Initialized
DEBUG - 2024-02-18 13:15:02 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-18 13:15:02 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-18 13:15:02 --> Model Class Initialized
INFO - 2024-02-18 13:15:02 --> Final output sent to browser
DEBUG - 2024-02-18 13:15:02 --> Total execution time: 0.0182
ERROR - 2024-02-18 13:15:26 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-18 13:15:26 --> Config Class Initialized
INFO - 2024-02-18 13:15:26 --> Hooks Class Initialized
DEBUG - 2024-02-18 13:15:26 --> UTF-8 Support Enabled
INFO - 2024-02-18 13:15:26 --> Utf8 Class Initialized
INFO - 2024-02-18 13:15:26 --> URI Class Initialized
INFO - 2024-02-18 13:15:26 --> Router Class Initialized
INFO - 2024-02-18 13:15:26 --> Output Class Initialized
INFO - 2024-02-18 13:15:26 --> Security Class Initialized
DEBUG - 2024-02-18 13:15:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-18 13:15:26 --> Input Class Initialized
INFO - 2024-02-18 13:15:26 --> Language Class Initialized
INFO - 2024-02-18 13:15:26 --> Loader Class Initialized
INFO - 2024-02-18 13:15:26 --> Helper loaded: url_helper
INFO - 2024-02-18 13:15:26 --> Helper loaded: file_helper
INFO - 2024-02-18 13:15:26 --> Helper loaded: html_helper
INFO - 2024-02-18 13:15:26 --> Helper loaded: text_helper
INFO - 2024-02-18 13:15:26 --> Helper loaded: form_helper
INFO - 2024-02-18 13:15:26 --> Helper loaded: lang_helper
INFO - 2024-02-18 13:15:26 --> Helper loaded: security_helper
INFO - 2024-02-18 13:15:26 --> Helper loaded: cookie_helper
INFO - 2024-02-18 13:15:26 --> Database Driver Class Initialized
INFO - 2024-02-18 13:15:26 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-18 13:15:26 --> Parser Class Initialized
INFO - 2024-02-18 13:15:26 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-18 13:15:26 --> Pagination Class Initialized
INFO - 2024-02-18 13:15:26 --> Form Validation Class Initialized
INFO - 2024-02-18 13:15:26 --> Controller Class Initialized
INFO - 2024-02-18 13:15:26 --> Model Class Initialized
DEBUG - 2024-02-18 13:15:26 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-18 13:15:26 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-18 13:15:26 --> Model Class Initialized
DEBUG - 2024-02-18 13:15:26 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-18 13:15:26 --> Model Class Initialized
INFO - 2024-02-18 13:15:26 --> Email Class Initialized
DEBUG - 2024-02-18 13:15:26 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-18 13:15:26 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice_html_pdf.php
ERROR - 2024-02-18 13:15:26 --> Severity: Warning --> "continue" targeting switch is equivalent to "break". Did you mean to use "continue 2"? /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/dompdf.cls.php 743
ERROR - 2024-02-18 13:15:26 --> Severity: Warning --> "continue" targeting switch is equivalent to "break". Did you mean to use "continue 2"? /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/dompdf.cls.php 763
ERROR - 2024-02-18 13:15:26 --> Severity: Warning --> "continue" targeting switch is equivalent to "break". Did you mean to use "continue 2"? /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/stylesheet.cls.php 1102
ERROR - 2024-02-18 13:15:26 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/page_frame_decorator.cls.php 439
ERROR - 2024-02-18 13:15:26 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/page_frame_decorator.cls.php 439
ERROR - 2024-02-18 13:15:26 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/page_frame_decorator.cls.php 439
ERROR - 2024-02-18 13:15:26 --> Severity: Warning --> Division by zero /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 572
ERROR - 2024-02-18 13:15:26 --> Severity: Warning --> Division by zero /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 572
ERROR - 2024-02-18 13:15:26 --> Severity: Warning --> Division by zero /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 572
ERROR - 2024-02-18 13:15:26 --> Severity: Warning --> Division by zero /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 572
ERROR - 2024-02-18 13:15:26 --> Severity: Warning --> Division by zero /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 572
ERROR - 2024-02-18 13:15:26 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/table_cell_frame_reflower.cls.php 103
ERROR - 2024-02-18 13:15:26 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/table_cell_frame_reflower.cls.php 103
ERROR - 2024-02-18 13:15:26 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/table_cell_frame_reflower.cls.php 103
ERROR - 2024-02-18 13:15:26 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/table_cell_frame_reflower.cls.php 103
ERROR - 2024-02-18 13:15:26 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/table_cell_frame_reflower.cls.php 103
ERROR - 2024-02-18 13:15:26 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/table_cell_frame_reflower.cls.php 103
ERROR - 2024-02-18 13:15:26 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/table_cell_frame_reflower.cls.php 103
ERROR - 2024-02-18 13:15:26 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/table_cell_frame_reflower.cls.php 103
ERROR - 2024-02-18 13:15:26 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/table_cell_frame_reflower.cls.php 103
ERROR - 2024-02-18 13:15:26 --> Severity: Warning --> Invalid argument supplied for foreach() /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 709
ERROR - 2024-02-18 13:15:26 --> Severity: Warning --> Invalid argument supplied for foreach() /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 709
ERROR - 2024-02-18 13:15:26 --> Severity: Warning --> Invalid argument supplied for foreach() /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 709
ERROR - 2024-02-18 13:15:26 --> Severity: Warning --> Invalid argument supplied for foreach() /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 709
ERROR - 2024-02-18 13:15:26 --> Severity: Warning --> Invalid argument supplied for foreach() /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 709
ERROR - 2024-02-18 13:15:26 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-18 13:15:26 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-18 13:15:26 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-18 13:15:26 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-18 13:15:26 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-18 13:15:26 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-18 13:15:26 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-18 13:15:26 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-18 13:15:26 --> Severity: Warning --> "continue" targeting switch is equivalent to "break". Did you mean to use "continue 2"? /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/text_renderer.cls.php 126
ERROR - 2024-02-18 13:15:26 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-18 13:15:26 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-18 13:15:26 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-18 13:15:26 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-18 13:15:26 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-18 13:15:26 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-18 13:15:26 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-18 13:15:26 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-18 13:15:26 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-18 13:15:26 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-18 13:15:26 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-18 13:15:26 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-18 13:15:26 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-18 13:15:26 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-18 13:15:26 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-18 13:15:26 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-18 13:15:26 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-18 13:15:26 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-18 13:15:26 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-18 13:15:26 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-18 13:15:26 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-18 13:15:26 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-18 13:15:26 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-18 13:15:26 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-18 13:15:26 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-18 13:15:26 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-18 13:15:26 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-18 13:15:26 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-18 13:15:26 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-18 13:15:26 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-18 13:15:26 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-18 13:15:26 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-18 13:15:26 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-18 13:15:26 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-18 13:15:26 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-18 13:15:26 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-18 13:15:26 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-18 13:15:26 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-18 13:15:26 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-18 13:15:26 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-18 13:15:26 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-18 13:15:26 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-18 13:15:26 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-18 13:15:26 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-18 13:15:26 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-18 13:15:26 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-18 13:15:26 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-18 13:15:26 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-18 13:15:26 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-18 13:15:26 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-18 13:15:26 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-18 13:15:26 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-18 13:15:26 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-18 13:15:26 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-18 13:15:26 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-18 13:15:26 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-18 13:15:26 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-18 13:15:26 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-18 13:15:26 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-18 13:15:26 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-18 13:15:26 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-18 13:15:26 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-18 13:15:26 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-18 13:15:26 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-18 13:15:26 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-18 13:15:26 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-18 13:15:26 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-18 13:15:26 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-18 13:15:26 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-18 13:15:26 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-18 13:15:26 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-18 13:15:26 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-18 13:15:26 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-18 13:15:26 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-18 13:15:26 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-18 13:15:26 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-18 13:15:26 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-18 13:15:26 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-18 13:15:26 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-18 13:15:26 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-18 13:15:26 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-18 13:15:26 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-18 13:15:26 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-18 13:15:26 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-18 13:15:26 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-18 13:15:26 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-18 13:15:26 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-18 13:15:26 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-18 13:15:26 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-18 13:15:26 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-18 13:15:26 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-18 13:15:26 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-18 13:15:26 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-18 13:15:26 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-18 13:15:26 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-18 13:15:26 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
INFO - 2024-02-18 13:15:26 --> Language file loaded: language/english/email_lang.php
INFO - 2024-02-18 13:15:26 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice_html.php
INFO - 2024-02-18 13:15:26 --> Final output sent to browser
DEBUG - 2024-02-18 13:15:26 --> Total execution time: 0.2363
ERROR - 2024-02-18 13:15:32 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-18 13:15:32 --> Config Class Initialized
INFO - 2024-02-18 13:15:32 --> Hooks Class Initialized
DEBUG - 2024-02-18 13:15:32 --> UTF-8 Support Enabled
INFO - 2024-02-18 13:15:32 --> Utf8 Class Initialized
INFO - 2024-02-18 13:15:32 --> URI Class Initialized
DEBUG - 2024-02-18 13:15:32 --> No URI present. Default controller set.
INFO - 2024-02-18 13:15:32 --> Router Class Initialized
INFO - 2024-02-18 13:15:32 --> Output Class Initialized
INFO - 2024-02-18 13:15:32 --> Security Class Initialized
DEBUG - 2024-02-18 13:15:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-18 13:15:32 --> Input Class Initialized
INFO - 2024-02-18 13:15:32 --> Language Class Initialized
INFO - 2024-02-18 13:15:32 --> Loader Class Initialized
INFO - 2024-02-18 13:15:32 --> Helper loaded: url_helper
INFO - 2024-02-18 13:15:32 --> Helper loaded: file_helper
INFO - 2024-02-18 13:15:32 --> Helper loaded: html_helper
INFO - 2024-02-18 13:15:32 --> Helper loaded: text_helper
INFO - 2024-02-18 13:15:32 --> Helper loaded: form_helper
INFO - 2024-02-18 13:15:32 --> Helper loaded: lang_helper
INFO - 2024-02-18 13:15:32 --> Helper loaded: security_helper
INFO - 2024-02-18 13:15:32 --> Helper loaded: cookie_helper
INFO - 2024-02-18 13:15:32 --> Database Driver Class Initialized
INFO - 2024-02-18 13:15:32 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-18 13:15:32 --> Parser Class Initialized
INFO - 2024-02-18 13:15:32 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-18 13:15:32 --> Pagination Class Initialized
INFO - 2024-02-18 13:15:32 --> Form Validation Class Initialized
INFO - 2024-02-18 13:15:32 --> Controller Class Initialized
INFO - 2024-02-18 13:15:32 --> Model Class Initialized
DEBUG - 2024-02-18 13:15:32 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-18 13:15:32 --> Model Class Initialized
DEBUG - 2024-02-18 13:15:32 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-18 13:15:32 --> Model Class Initialized
INFO - 2024-02-18 13:15:32 --> Model Class Initialized
INFO - 2024-02-18 13:15:32 --> Model Class Initialized
INFO - 2024-02-18 13:15:32 --> Model Class Initialized
DEBUG - 2024-02-18 13:15:32 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-18 13:15:32 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-18 13:15:32 --> Model Class Initialized
INFO - 2024-02-18 13:15:32 --> Model Class Initialized
INFO - 2024-02-18 13:15:32 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2024-02-18 13:15:32 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-02-18 13:15:32 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-02-18 13:15:32 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-02-18 13:15:32 --> Model Class Initialized
INFO - 2024-02-18 13:15:32 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-02-18 13:15:32 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-02-18 13:15:32 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-02-18 13:15:32 --> Final output sent to browser
DEBUG - 2024-02-18 13:15:32 --> Total execution time: 0.2305
ERROR - 2024-02-18 14:37:00 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-18 14:37:00 --> Config Class Initialized
INFO - 2024-02-18 14:37:00 --> Hooks Class Initialized
DEBUG - 2024-02-18 14:37:00 --> UTF-8 Support Enabled
INFO - 2024-02-18 14:37:00 --> Utf8 Class Initialized
INFO - 2024-02-18 14:37:00 --> URI Class Initialized
DEBUG - 2024-02-18 14:37:00 --> No URI present. Default controller set.
INFO - 2024-02-18 14:37:00 --> Router Class Initialized
INFO - 2024-02-18 14:37:00 --> Output Class Initialized
INFO - 2024-02-18 14:37:00 --> Security Class Initialized
DEBUG - 2024-02-18 14:37:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-18 14:37:00 --> Input Class Initialized
INFO - 2024-02-18 14:37:00 --> Language Class Initialized
INFO - 2024-02-18 14:37:00 --> Loader Class Initialized
INFO - 2024-02-18 14:37:00 --> Helper loaded: url_helper
INFO - 2024-02-18 14:37:00 --> Helper loaded: file_helper
INFO - 2024-02-18 14:37:00 --> Helper loaded: html_helper
INFO - 2024-02-18 14:37:00 --> Helper loaded: text_helper
INFO - 2024-02-18 14:37:00 --> Helper loaded: form_helper
INFO - 2024-02-18 14:37:00 --> Helper loaded: lang_helper
INFO - 2024-02-18 14:37:00 --> Helper loaded: security_helper
INFO - 2024-02-18 14:37:00 --> Helper loaded: cookie_helper
INFO - 2024-02-18 14:37:00 --> Database Driver Class Initialized
INFO - 2024-02-18 14:37:00 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-18 14:37:00 --> Parser Class Initialized
INFO - 2024-02-18 14:37:00 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-18 14:37:00 --> Pagination Class Initialized
INFO - 2024-02-18 14:37:00 --> Form Validation Class Initialized
INFO - 2024-02-18 14:37:00 --> Controller Class Initialized
INFO - 2024-02-18 14:37:00 --> Model Class Initialized
DEBUG - 2024-02-18 14:37:00 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-18 14:37:00 --> Model Class Initialized
DEBUG - 2024-02-18 14:37:00 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-18 14:37:00 --> Model Class Initialized
INFO - 2024-02-18 14:37:00 --> Model Class Initialized
INFO - 2024-02-18 14:37:00 --> Model Class Initialized
INFO - 2024-02-18 14:37:00 --> Model Class Initialized
DEBUG - 2024-02-18 14:37:00 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-18 14:37:00 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-18 14:37:00 --> Model Class Initialized
INFO - 2024-02-18 14:37:00 --> Model Class Initialized
INFO - 2024-02-18 14:37:00 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2024-02-18 14:37:00 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-02-18 14:37:00 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-02-18 14:37:00 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-02-18 14:37:00 --> Model Class Initialized
INFO - 2024-02-18 14:37:01 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-02-18 14:37:01 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-02-18 14:37:01 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-02-18 14:37:01 --> Final output sent to browser
DEBUG - 2024-02-18 14:37:01 --> Total execution time: 0.2331
ERROR - 2024-02-18 14:37:10 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-18 14:37:10 --> Config Class Initialized
INFO - 2024-02-18 14:37:10 --> Hooks Class Initialized
DEBUG - 2024-02-18 14:37:10 --> UTF-8 Support Enabled
INFO - 2024-02-18 14:37:10 --> Utf8 Class Initialized
INFO - 2024-02-18 14:37:10 --> URI Class Initialized
INFO - 2024-02-18 14:37:10 --> Router Class Initialized
INFO - 2024-02-18 14:37:10 --> Output Class Initialized
INFO - 2024-02-18 14:37:10 --> Security Class Initialized
DEBUG - 2024-02-18 14:37:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-18 14:37:10 --> Input Class Initialized
INFO - 2024-02-18 14:37:10 --> Language Class Initialized
INFO - 2024-02-18 14:37:10 --> Loader Class Initialized
INFO - 2024-02-18 14:37:10 --> Helper loaded: url_helper
INFO - 2024-02-18 14:37:10 --> Helper loaded: file_helper
INFO - 2024-02-18 14:37:10 --> Helper loaded: html_helper
INFO - 2024-02-18 14:37:10 --> Helper loaded: text_helper
INFO - 2024-02-18 14:37:10 --> Helper loaded: form_helper
INFO - 2024-02-18 14:37:10 --> Helper loaded: lang_helper
INFO - 2024-02-18 14:37:10 --> Helper loaded: security_helper
INFO - 2024-02-18 14:37:10 --> Helper loaded: cookie_helper
INFO - 2024-02-18 14:37:10 --> Database Driver Class Initialized
INFO - 2024-02-18 14:37:10 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-18 14:37:10 --> Parser Class Initialized
INFO - 2024-02-18 14:37:10 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-18 14:37:10 --> Pagination Class Initialized
INFO - 2024-02-18 14:37:10 --> Form Validation Class Initialized
INFO - 2024-02-18 14:37:10 --> Controller Class Initialized
INFO - 2024-02-18 14:37:10 --> Model Class Initialized
DEBUG - 2024-02-18 14:37:10 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-18 14:37:10 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-18 14:37:10 --> Model Class Initialized
DEBUG - 2024-02-18 14:37:10 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-18 14:37:10 --> Model Class Initialized
INFO - 2024-02-18 14:37:10 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice.php
DEBUG - 2024-02-18 14:37:10 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-02-18 14:37:10 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-02-18 14:37:10 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-02-18 14:37:10 --> Model Class Initialized
INFO - 2024-02-18 14:37:10 --> Model Class Initialized
INFO - 2024-02-18 14:37:10 --> Model Class Initialized
INFO - 2024-02-18 14:37:11 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-02-18 14:37:11 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-02-18 14:37:11 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-02-18 14:37:11 --> Final output sent to browser
DEBUG - 2024-02-18 14:37:11 --> Total execution time: 0.1491
ERROR - 2024-02-18 14:37:11 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-18 14:37:11 --> Config Class Initialized
INFO - 2024-02-18 14:37:11 --> Hooks Class Initialized
DEBUG - 2024-02-18 14:37:11 --> UTF-8 Support Enabled
INFO - 2024-02-18 14:37:11 --> Utf8 Class Initialized
INFO - 2024-02-18 14:37:11 --> URI Class Initialized
INFO - 2024-02-18 14:37:11 --> Router Class Initialized
INFO - 2024-02-18 14:37:11 --> Output Class Initialized
INFO - 2024-02-18 14:37:11 --> Security Class Initialized
DEBUG - 2024-02-18 14:37:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-18 14:37:11 --> Input Class Initialized
INFO - 2024-02-18 14:37:11 --> Language Class Initialized
INFO - 2024-02-18 14:37:11 --> Loader Class Initialized
INFO - 2024-02-18 14:37:11 --> Helper loaded: url_helper
INFO - 2024-02-18 14:37:11 --> Helper loaded: file_helper
INFO - 2024-02-18 14:37:11 --> Helper loaded: html_helper
INFO - 2024-02-18 14:37:11 --> Helper loaded: text_helper
INFO - 2024-02-18 14:37:11 --> Helper loaded: form_helper
INFO - 2024-02-18 14:37:11 --> Helper loaded: lang_helper
INFO - 2024-02-18 14:37:11 --> Helper loaded: security_helper
INFO - 2024-02-18 14:37:11 --> Helper loaded: cookie_helper
INFO - 2024-02-18 14:37:11 --> Database Driver Class Initialized
INFO - 2024-02-18 14:37:11 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-18 14:37:11 --> Parser Class Initialized
INFO - 2024-02-18 14:37:11 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-18 14:37:11 --> Pagination Class Initialized
INFO - 2024-02-18 14:37:11 --> Form Validation Class Initialized
INFO - 2024-02-18 14:37:11 --> Controller Class Initialized
INFO - 2024-02-18 14:37:11 --> Model Class Initialized
DEBUG - 2024-02-18 14:37:11 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-18 14:37:11 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-18 14:37:11 --> Model Class Initialized
DEBUG - 2024-02-18 14:37:11 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-18 14:37:11 --> Model Class Initialized
INFO - 2024-02-18 14:37:12 --> Final output sent to browser
DEBUG - 2024-02-18 14:37:12 --> Total execution time: 0.0456
ERROR - 2024-02-18 14:37:31 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-18 14:37:31 --> Config Class Initialized
INFO - 2024-02-18 14:37:31 --> Hooks Class Initialized
DEBUG - 2024-02-18 14:37:31 --> UTF-8 Support Enabled
INFO - 2024-02-18 14:37:31 --> Utf8 Class Initialized
INFO - 2024-02-18 14:37:31 --> URI Class Initialized
INFO - 2024-02-18 14:37:31 --> Router Class Initialized
INFO - 2024-02-18 14:37:31 --> Output Class Initialized
INFO - 2024-02-18 14:37:31 --> Security Class Initialized
DEBUG - 2024-02-18 14:37:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-18 14:37:31 --> Input Class Initialized
INFO - 2024-02-18 14:37:31 --> Language Class Initialized
INFO - 2024-02-18 14:37:31 --> Loader Class Initialized
INFO - 2024-02-18 14:37:31 --> Helper loaded: url_helper
INFO - 2024-02-18 14:37:31 --> Helper loaded: file_helper
INFO - 2024-02-18 14:37:31 --> Helper loaded: html_helper
INFO - 2024-02-18 14:37:31 --> Helper loaded: text_helper
INFO - 2024-02-18 14:37:31 --> Helper loaded: form_helper
INFO - 2024-02-18 14:37:31 --> Helper loaded: lang_helper
INFO - 2024-02-18 14:37:31 --> Helper loaded: security_helper
INFO - 2024-02-18 14:37:31 --> Helper loaded: cookie_helper
INFO - 2024-02-18 14:37:31 --> Database Driver Class Initialized
INFO - 2024-02-18 14:37:31 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-18 14:37:31 --> Parser Class Initialized
INFO - 2024-02-18 14:37:31 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-18 14:37:31 --> Pagination Class Initialized
INFO - 2024-02-18 14:37:31 --> Form Validation Class Initialized
INFO - 2024-02-18 14:37:31 --> Controller Class Initialized
INFO - 2024-02-18 14:37:31 --> Model Class Initialized
DEBUG - 2024-02-18 14:37:31 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-18 14:37:31 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-18 14:37:31 --> Model Class Initialized
DEBUG - 2024-02-18 14:37:31 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-18 14:37:31 --> Model Class Initialized
DEBUG - 2024-02-18 14:37:31 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-18 14:37:31 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice_html.php
DEBUG - 2024-02-18 14:37:31 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-02-18 14:37:31 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-02-18 14:37:31 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-02-18 14:37:31 --> Model Class Initialized
INFO - 2024-02-18 14:37:31 --> Model Class Initialized
INFO - 2024-02-18 14:37:31 --> Model Class Initialized
INFO - 2024-02-18 14:37:31 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-02-18 14:37:31 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-02-18 14:37:31 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-02-18 14:37:31 --> Final output sent to browser
DEBUG - 2024-02-18 14:37:31 --> Total execution time: 0.1521
ERROR - 2024-02-18 23:51:44 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-18 23:51:44 --> Config Class Initialized
INFO - 2024-02-18 23:51:44 --> Hooks Class Initialized
DEBUG - 2024-02-18 23:51:44 --> UTF-8 Support Enabled
INFO - 2024-02-18 23:51:44 --> Utf8 Class Initialized
INFO - 2024-02-18 23:51:44 --> URI Class Initialized
DEBUG - 2024-02-18 23:51:44 --> No URI present. Default controller set.
INFO - 2024-02-18 23:51:44 --> Router Class Initialized
INFO - 2024-02-18 23:51:44 --> Output Class Initialized
INFO - 2024-02-18 23:51:44 --> Security Class Initialized
DEBUG - 2024-02-18 23:51:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-18 23:51:44 --> Input Class Initialized
INFO - 2024-02-18 23:51:44 --> Language Class Initialized
INFO - 2024-02-18 23:51:44 --> Loader Class Initialized
INFO - 2024-02-18 23:51:44 --> Helper loaded: url_helper
INFO - 2024-02-18 23:51:44 --> Helper loaded: file_helper
INFO - 2024-02-18 23:51:44 --> Helper loaded: html_helper
INFO - 2024-02-18 23:51:44 --> Helper loaded: text_helper
INFO - 2024-02-18 23:51:44 --> Helper loaded: form_helper
INFO - 2024-02-18 23:51:44 --> Helper loaded: lang_helper
INFO - 2024-02-18 23:51:44 --> Helper loaded: security_helper
INFO - 2024-02-18 23:51:44 --> Helper loaded: cookie_helper
INFO - 2024-02-18 23:51:44 --> Database Driver Class Initialized
INFO - 2024-02-18 23:51:44 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-18 23:51:44 --> Parser Class Initialized
INFO - 2024-02-18 23:51:44 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-18 23:51:44 --> Pagination Class Initialized
INFO - 2024-02-18 23:51:44 --> Form Validation Class Initialized
INFO - 2024-02-18 23:51:44 --> Controller Class Initialized
INFO - 2024-02-18 23:51:44 --> Model Class Initialized
DEBUG - 2024-02-18 23:51:44 --> Session class already loaded. Second attempt ignored.
ERROR - 2024-02-18 23:51:45 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-18 23:51:45 --> Config Class Initialized
INFO - 2024-02-18 23:51:45 --> Hooks Class Initialized
DEBUG - 2024-02-18 23:51:45 --> UTF-8 Support Enabled
INFO - 2024-02-18 23:51:45 --> Utf8 Class Initialized
INFO - 2024-02-18 23:51:45 --> URI Class Initialized
DEBUG - 2024-02-18 23:51:45 --> No URI present. Default controller set.
INFO - 2024-02-18 23:51:45 --> Router Class Initialized
INFO - 2024-02-18 23:51:45 --> Output Class Initialized
INFO - 2024-02-18 23:51:45 --> Security Class Initialized
DEBUG - 2024-02-18 23:51:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-18 23:51:45 --> Input Class Initialized
INFO - 2024-02-18 23:51:45 --> Language Class Initialized
INFO - 2024-02-18 23:51:45 --> Loader Class Initialized
INFO - 2024-02-18 23:51:45 --> Helper loaded: url_helper
INFO - 2024-02-18 23:51:45 --> Helper loaded: file_helper
INFO - 2024-02-18 23:51:45 --> Helper loaded: html_helper
INFO - 2024-02-18 23:51:45 --> Helper loaded: text_helper
INFO - 2024-02-18 23:51:45 --> Helper loaded: form_helper
INFO - 2024-02-18 23:51:45 --> Helper loaded: lang_helper
INFO - 2024-02-18 23:51:45 --> Helper loaded: security_helper
INFO - 2024-02-18 23:51:45 --> Helper loaded: cookie_helper
INFO - 2024-02-18 23:51:45 --> Database Driver Class Initialized
INFO - 2024-02-18 23:51:45 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-18 23:51:45 --> Parser Class Initialized
INFO - 2024-02-18 23:51:45 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-18 23:51:45 --> Pagination Class Initialized
INFO - 2024-02-18 23:51:45 --> Form Validation Class Initialized
INFO - 2024-02-18 23:51:45 --> Controller Class Initialized
INFO - 2024-02-18 23:51:45 --> Model Class Initialized
DEBUG - 2024-02-18 23:51:45 --> Session class already loaded. Second attempt ignored.
ERROR - 2024-02-18 23:51:46 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-18 23:51:46 --> Config Class Initialized
INFO - 2024-02-18 23:51:46 --> Hooks Class Initialized
DEBUG - 2024-02-18 23:51:46 --> UTF-8 Support Enabled
INFO - 2024-02-18 23:51:46 --> Utf8 Class Initialized
INFO - 2024-02-18 23:51:46 --> URI Class Initialized
DEBUG - 2024-02-18 23:51:46 --> No URI present. Default controller set.
INFO - 2024-02-18 23:51:46 --> Router Class Initialized
INFO - 2024-02-18 23:51:46 --> Output Class Initialized
INFO - 2024-02-18 23:51:46 --> Security Class Initialized
DEBUG - 2024-02-18 23:51:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-18 23:51:46 --> Input Class Initialized
INFO - 2024-02-18 23:51:46 --> Language Class Initialized
INFO - 2024-02-18 23:51:46 --> Loader Class Initialized
INFO - 2024-02-18 23:51:46 --> Helper loaded: url_helper
INFO - 2024-02-18 23:51:46 --> Helper loaded: file_helper
INFO - 2024-02-18 23:51:46 --> Helper loaded: html_helper
INFO - 2024-02-18 23:51:46 --> Helper loaded: text_helper
INFO - 2024-02-18 23:51:46 --> Helper loaded: form_helper
INFO - 2024-02-18 23:51:46 --> Helper loaded: lang_helper
INFO - 2024-02-18 23:51:46 --> Helper loaded: security_helper
INFO - 2024-02-18 23:51:46 --> Helper loaded: cookie_helper
INFO - 2024-02-18 23:51:46 --> Database Driver Class Initialized
INFO - 2024-02-18 23:51:46 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-18 23:51:46 --> Parser Class Initialized
INFO - 2024-02-18 23:51:46 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-18 23:51:46 --> Pagination Class Initialized
INFO - 2024-02-18 23:51:46 --> Form Validation Class Initialized
INFO - 2024-02-18 23:51:46 --> Controller Class Initialized
INFO - 2024-02-18 23:51:46 --> Model Class Initialized
DEBUG - 2024-02-18 23:51:46 --> Session class already loaded. Second attempt ignored.
ERROR - 2024-02-18 23:51:46 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-18 23:51:46 --> Config Class Initialized
INFO - 2024-02-18 23:51:46 --> Hooks Class Initialized
DEBUG - 2024-02-18 23:51:46 --> UTF-8 Support Enabled
INFO - 2024-02-18 23:51:46 --> Utf8 Class Initialized
INFO - 2024-02-18 23:51:46 --> URI Class Initialized
DEBUG - 2024-02-18 23:51:46 --> No URI present. Default controller set.
INFO - 2024-02-18 23:51:46 --> Router Class Initialized
INFO - 2024-02-18 23:51:46 --> Output Class Initialized
INFO - 2024-02-18 23:51:46 --> Security Class Initialized
DEBUG - 2024-02-18 23:51:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-18 23:51:46 --> Input Class Initialized
INFO - 2024-02-18 23:51:46 --> Language Class Initialized
INFO - 2024-02-18 23:51:46 --> Loader Class Initialized
INFO - 2024-02-18 23:51:46 --> Helper loaded: url_helper
INFO - 2024-02-18 23:51:46 --> Helper loaded: file_helper
INFO - 2024-02-18 23:51:46 --> Helper loaded: html_helper
INFO - 2024-02-18 23:51:46 --> Helper loaded: text_helper
INFO - 2024-02-18 23:51:46 --> Helper loaded: form_helper
INFO - 2024-02-18 23:51:46 --> Helper loaded: lang_helper
INFO - 2024-02-18 23:51:46 --> Helper loaded: security_helper
INFO - 2024-02-18 23:51:46 --> Helper loaded: cookie_helper
INFO - 2024-02-18 23:51:46 --> Database Driver Class Initialized
INFO - 2024-02-18 23:51:46 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-18 23:51:46 --> Parser Class Initialized
INFO - 2024-02-18 23:51:46 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-18 23:51:46 --> Pagination Class Initialized
INFO - 2024-02-18 23:51:46 --> Form Validation Class Initialized
INFO - 2024-02-18 23:51:46 --> Controller Class Initialized
INFO - 2024-02-18 23:51:46 --> Model Class Initialized
DEBUG - 2024-02-18 23:51:46 --> Session class already loaded. Second attempt ignored.
