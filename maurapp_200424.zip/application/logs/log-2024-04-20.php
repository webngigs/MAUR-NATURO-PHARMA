<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2024-04-20 02:23:00 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-04-20 02:23:00 --> Config Class Initialized
INFO - 2024-04-20 02:23:00 --> Hooks Class Initialized
DEBUG - 2024-04-20 02:23:00 --> UTF-8 Support Enabled
INFO - 2024-04-20 02:23:00 --> Utf8 Class Initialized
INFO - 2024-04-20 02:23:00 --> URI Class Initialized
DEBUG - 2024-04-20 02:23:00 --> No URI present. Default controller set.
INFO - 2024-04-20 02:23:00 --> Router Class Initialized
INFO - 2024-04-20 02:23:00 --> Output Class Initialized
INFO - 2024-04-20 02:23:00 --> Security Class Initialized
DEBUG - 2024-04-20 02:23:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-04-20 02:23:00 --> Input Class Initialized
INFO - 2024-04-20 02:23:00 --> Language Class Initialized
INFO - 2024-04-20 02:23:00 --> Loader Class Initialized
INFO - 2024-04-20 02:23:00 --> Helper loaded: url_helper
INFO - 2024-04-20 02:23:00 --> Helper loaded: file_helper
INFO - 2024-04-20 02:23:00 --> Helper loaded: html_helper
INFO - 2024-04-20 02:23:00 --> Helper loaded: text_helper
INFO - 2024-04-20 02:23:00 --> Helper loaded: form_helper
INFO - 2024-04-20 02:23:00 --> Helper loaded: lang_helper
INFO - 2024-04-20 02:23:00 --> Helper loaded: security_helper
INFO - 2024-04-20 02:23:00 --> Helper loaded: cookie_helper
INFO - 2024-04-20 02:23:00 --> Database Driver Class Initialized
INFO - 2024-04-20 02:23:00 --> Session: Class initialized using 'files' driver.
INFO - 2024-04-20 02:23:00 --> Parser Class Initialized
INFO - 2024-04-20 02:23:00 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-04-20 02:23:00 --> Pagination Class Initialized
INFO - 2024-04-20 02:23:00 --> Form Validation Class Initialized
INFO - 2024-04-20 02:23:00 --> Controller Class Initialized
INFO - 2024-04-20 02:23:00 --> Model Class Initialized
DEBUG - 2024-04-20 02:23:00 --> Session class already loaded. Second attempt ignored.
ERROR - 2024-04-20 02:23:01 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-04-20 02:23:01 --> Config Class Initialized
INFO - 2024-04-20 02:23:01 --> Hooks Class Initialized
DEBUG - 2024-04-20 02:23:01 --> UTF-8 Support Enabled
INFO - 2024-04-20 02:23:01 --> Utf8 Class Initialized
INFO - 2024-04-20 02:23:01 --> URI Class Initialized
INFO - 2024-04-20 02:23:01 --> Router Class Initialized
INFO - 2024-04-20 02:23:01 --> Output Class Initialized
INFO - 2024-04-20 02:23:01 --> Security Class Initialized
DEBUG - 2024-04-20 02:23:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-04-20 02:23:01 --> Input Class Initialized
INFO - 2024-04-20 02:23:01 --> Language Class Initialized
INFO - 2024-04-20 02:23:01 --> Loader Class Initialized
INFO - 2024-04-20 02:23:01 --> Helper loaded: url_helper
INFO - 2024-04-20 02:23:01 --> Helper loaded: file_helper
INFO - 2024-04-20 02:23:01 --> Helper loaded: html_helper
INFO - 2024-04-20 02:23:01 --> Helper loaded: text_helper
INFO - 2024-04-20 02:23:01 --> Helper loaded: form_helper
INFO - 2024-04-20 02:23:01 --> Helper loaded: lang_helper
INFO - 2024-04-20 02:23:01 --> Helper loaded: security_helper
INFO - 2024-04-20 02:23:01 --> Helper loaded: cookie_helper
INFO - 2024-04-20 02:23:01 --> Database Driver Class Initialized
INFO - 2024-04-20 02:23:01 --> Session: Class initialized using 'files' driver.
INFO - 2024-04-20 02:23:01 --> Parser Class Initialized
INFO - 2024-04-20 02:23:01 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-04-20 02:23:01 --> Pagination Class Initialized
INFO - 2024-04-20 02:23:01 --> Form Validation Class Initialized
INFO - 2024-04-20 02:23:01 --> Controller Class Initialized
INFO - 2024-04-20 02:23:01 --> Model Class Initialized
DEBUG - 2024-04-20 02:23:01 --> Session class already loaded. Second attempt ignored.
INFO - 2024-04-20 02:23:01 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2024-04-20 02:23:01 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-04-20 02:23:01 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-04-20 02:23:01 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-04-20 02:23:01 --> Model Class Initialized
INFO - 2024-04-20 02:23:01 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-04-20 02:23:01 --> Final output sent to browser
DEBUG - 2024-04-20 02:23:01 --> Total execution time: 0.0330
ERROR - 2024-04-20 02:24:37 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-04-20 02:24:37 --> Config Class Initialized
INFO - 2024-04-20 02:24:37 --> Hooks Class Initialized
DEBUG - 2024-04-20 02:24:37 --> UTF-8 Support Enabled
INFO - 2024-04-20 02:24:37 --> Utf8 Class Initialized
INFO - 2024-04-20 02:24:37 --> URI Class Initialized
DEBUG - 2024-04-20 02:24:37 --> No URI present. Default controller set.
INFO - 2024-04-20 02:24:37 --> Router Class Initialized
INFO - 2024-04-20 02:24:37 --> Output Class Initialized
INFO - 2024-04-20 02:24:37 --> Security Class Initialized
DEBUG - 2024-04-20 02:24:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-04-20 02:24:37 --> Input Class Initialized
INFO - 2024-04-20 02:24:37 --> Language Class Initialized
INFO - 2024-04-20 02:24:37 --> Loader Class Initialized
INFO - 2024-04-20 02:24:37 --> Helper loaded: url_helper
INFO - 2024-04-20 02:24:37 --> Helper loaded: file_helper
INFO - 2024-04-20 02:24:37 --> Helper loaded: html_helper
INFO - 2024-04-20 02:24:37 --> Helper loaded: text_helper
INFO - 2024-04-20 02:24:37 --> Helper loaded: form_helper
INFO - 2024-04-20 02:24:37 --> Helper loaded: lang_helper
INFO - 2024-04-20 02:24:37 --> Helper loaded: security_helper
INFO - 2024-04-20 02:24:37 --> Helper loaded: cookie_helper
INFO - 2024-04-20 02:24:37 --> Database Driver Class Initialized
INFO - 2024-04-20 02:24:37 --> Session: Class initialized using 'files' driver.
INFO - 2024-04-20 02:24:37 --> Parser Class Initialized
INFO - 2024-04-20 02:24:37 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-04-20 02:24:37 --> Pagination Class Initialized
INFO - 2024-04-20 02:24:37 --> Form Validation Class Initialized
INFO - 2024-04-20 02:24:37 --> Controller Class Initialized
INFO - 2024-04-20 02:24:37 --> Model Class Initialized
DEBUG - 2024-04-20 02:24:37 --> Session class already loaded. Second attempt ignored.
ERROR - 2024-04-20 02:24:37 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-04-20 02:24:37 --> Config Class Initialized
INFO - 2024-04-20 02:24:37 --> Hooks Class Initialized
DEBUG - 2024-04-20 02:24:37 --> UTF-8 Support Enabled
INFO - 2024-04-20 02:24:37 --> Utf8 Class Initialized
INFO - 2024-04-20 02:24:37 --> URI Class Initialized
INFO - 2024-04-20 02:24:37 --> Router Class Initialized
INFO - 2024-04-20 02:24:37 --> Output Class Initialized
INFO - 2024-04-20 02:24:37 --> Security Class Initialized
DEBUG - 2024-04-20 02:24:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-04-20 02:24:37 --> Input Class Initialized
INFO - 2024-04-20 02:24:37 --> Language Class Initialized
INFO - 2024-04-20 02:24:37 --> Loader Class Initialized
INFO - 2024-04-20 02:24:37 --> Helper loaded: url_helper
INFO - 2024-04-20 02:24:37 --> Helper loaded: file_helper
INFO - 2024-04-20 02:24:37 --> Helper loaded: html_helper
INFO - 2024-04-20 02:24:37 --> Helper loaded: text_helper
INFO - 2024-04-20 02:24:37 --> Helper loaded: form_helper
INFO - 2024-04-20 02:24:37 --> Helper loaded: lang_helper
INFO - 2024-04-20 02:24:37 --> Helper loaded: security_helper
INFO - 2024-04-20 02:24:37 --> Helper loaded: cookie_helper
INFO - 2024-04-20 02:24:37 --> Database Driver Class Initialized
INFO - 2024-04-20 02:24:37 --> Session: Class initialized using 'files' driver.
INFO - 2024-04-20 02:24:37 --> Parser Class Initialized
INFO - 2024-04-20 02:24:37 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-04-20 02:24:37 --> Pagination Class Initialized
INFO - 2024-04-20 02:24:37 --> Form Validation Class Initialized
INFO - 2024-04-20 02:24:37 --> Controller Class Initialized
INFO - 2024-04-20 02:24:37 --> Model Class Initialized
DEBUG - 2024-04-20 02:24:37 --> Session class already loaded. Second attempt ignored.
INFO - 2024-04-20 02:24:37 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2024-04-20 02:24:37 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-04-20 02:24:37 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-04-20 02:24:37 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-04-20 02:24:37 --> Model Class Initialized
INFO - 2024-04-20 02:24:37 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-04-20 02:24:37 --> Final output sent to browser
DEBUG - 2024-04-20 02:24:37 --> Total execution time: 0.0306
ERROR - 2024-04-20 06:39:39 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-04-20 06:39:39 --> Config Class Initialized
INFO - 2024-04-20 06:39:39 --> Hooks Class Initialized
DEBUG - 2024-04-20 06:39:39 --> UTF-8 Support Enabled
INFO - 2024-04-20 06:39:39 --> Utf8 Class Initialized
INFO - 2024-04-20 06:39:39 --> URI Class Initialized
DEBUG - 2024-04-20 06:39:39 --> No URI present. Default controller set.
INFO - 2024-04-20 06:39:39 --> Router Class Initialized
INFO - 2024-04-20 06:39:39 --> Output Class Initialized
INFO - 2024-04-20 06:39:39 --> Security Class Initialized
DEBUG - 2024-04-20 06:39:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-04-20 06:39:39 --> Input Class Initialized
INFO - 2024-04-20 06:39:39 --> Language Class Initialized
INFO - 2024-04-20 06:39:39 --> Loader Class Initialized
INFO - 2024-04-20 06:39:39 --> Helper loaded: url_helper
INFO - 2024-04-20 06:39:39 --> Helper loaded: file_helper
INFO - 2024-04-20 06:39:39 --> Helper loaded: html_helper
INFO - 2024-04-20 06:39:39 --> Helper loaded: text_helper
INFO - 2024-04-20 06:39:39 --> Helper loaded: form_helper
INFO - 2024-04-20 06:39:39 --> Helper loaded: lang_helper
INFO - 2024-04-20 06:39:39 --> Helper loaded: security_helper
INFO - 2024-04-20 06:39:39 --> Helper loaded: cookie_helper
INFO - 2024-04-20 06:39:39 --> Database Driver Class Initialized
INFO - 2024-04-20 06:39:39 --> Session: Class initialized using 'files' driver.
INFO - 2024-04-20 06:39:39 --> Parser Class Initialized
INFO - 2024-04-20 06:39:39 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-04-20 06:39:39 --> Pagination Class Initialized
INFO - 2024-04-20 06:39:39 --> Form Validation Class Initialized
INFO - 2024-04-20 06:39:39 --> Controller Class Initialized
INFO - 2024-04-20 06:39:39 --> Model Class Initialized
DEBUG - 2024-04-20 06:39:39 --> Session class already loaded. Second attempt ignored.
ERROR - 2024-04-20 06:39:40 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-04-20 06:39:40 --> Config Class Initialized
INFO - 2024-04-20 06:39:40 --> Hooks Class Initialized
DEBUG - 2024-04-20 06:39:40 --> UTF-8 Support Enabled
INFO - 2024-04-20 06:39:40 --> Utf8 Class Initialized
INFO - 2024-04-20 06:39:40 --> URI Class Initialized
INFO - 2024-04-20 06:39:40 --> Router Class Initialized
INFO - 2024-04-20 06:39:40 --> Output Class Initialized
INFO - 2024-04-20 06:39:40 --> Security Class Initialized
DEBUG - 2024-04-20 06:39:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-04-20 06:39:40 --> Input Class Initialized
INFO - 2024-04-20 06:39:40 --> Language Class Initialized
INFO - 2024-04-20 06:39:40 --> Loader Class Initialized
INFO - 2024-04-20 06:39:40 --> Helper loaded: url_helper
INFO - 2024-04-20 06:39:40 --> Helper loaded: file_helper
INFO - 2024-04-20 06:39:40 --> Helper loaded: html_helper
INFO - 2024-04-20 06:39:40 --> Helper loaded: text_helper
INFO - 2024-04-20 06:39:40 --> Helper loaded: form_helper
INFO - 2024-04-20 06:39:40 --> Helper loaded: lang_helper
INFO - 2024-04-20 06:39:40 --> Helper loaded: security_helper
INFO - 2024-04-20 06:39:40 --> Helper loaded: cookie_helper
INFO - 2024-04-20 06:39:40 --> Database Driver Class Initialized
INFO - 2024-04-20 06:39:40 --> Session: Class initialized using 'files' driver.
INFO - 2024-04-20 06:39:40 --> Parser Class Initialized
INFO - 2024-04-20 06:39:40 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-04-20 06:39:40 --> Pagination Class Initialized
INFO - 2024-04-20 06:39:40 --> Form Validation Class Initialized
INFO - 2024-04-20 06:39:40 --> Controller Class Initialized
INFO - 2024-04-20 06:39:40 --> Model Class Initialized
DEBUG - 2024-04-20 06:39:40 --> Session class already loaded. Second attempt ignored.
INFO - 2024-04-20 06:39:40 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2024-04-20 06:39:40 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-04-20 06:39:40 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-04-20 06:39:40 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-04-20 06:39:40 --> Model Class Initialized
INFO - 2024-04-20 06:39:40 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-04-20 06:39:40 --> Final output sent to browser
DEBUG - 2024-04-20 06:39:40 --> Total execution time: 0.0345
ERROR - 2024-04-20 07:58:13 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-04-20 07:58:13 --> Config Class Initialized
INFO - 2024-04-20 07:58:13 --> Hooks Class Initialized
DEBUG - 2024-04-20 07:58:13 --> UTF-8 Support Enabled
INFO - 2024-04-20 07:58:13 --> Utf8 Class Initialized
INFO - 2024-04-20 07:58:13 --> URI Class Initialized
DEBUG - 2024-04-20 07:58:13 --> No URI present. Default controller set.
INFO - 2024-04-20 07:58:13 --> Router Class Initialized
INFO - 2024-04-20 07:58:13 --> Output Class Initialized
INFO - 2024-04-20 07:58:13 --> Security Class Initialized
DEBUG - 2024-04-20 07:58:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-04-20 07:58:13 --> Input Class Initialized
INFO - 2024-04-20 07:58:13 --> Language Class Initialized
INFO - 2024-04-20 07:58:13 --> Loader Class Initialized
INFO - 2024-04-20 07:58:13 --> Helper loaded: url_helper
INFO - 2024-04-20 07:58:13 --> Helper loaded: file_helper
INFO - 2024-04-20 07:58:13 --> Helper loaded: html_helper
INFO - 2024-04-20 07:58:13 --> Helper loaded: text_helper
INFO - 2024-04-20 07:58:13 --> Helper loaded: form_helper
INFO - 2024-04-20 07:58:13 --> Helper loaded: lang_helper
INFO - 2024-04-20 07:58:13 --> Helper loaded: security_helper
INFO - 2024-04-20 07:58:13 --> Helper loaded: cookie_helper
INFO - 2024-04-20 07:58:13 --> Database Driver Class Initialized
INFO - 2024-04-20 07:58:13 --> Session: Class initialized using 'files' driver.
INFO - 2024-04-20 07:58:13 --> Parser Class Initialized
INFO - 2024-04-20 07:58:13 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-04-20 07:58:13 --> Pagination Class Initialized
INFO - 2024-04-20 07:58:13 --> Form Validation Class Initialized
INFO - 2024-04-20 07:58:13 --> Controller Class Initialized
INFO - 2024-04-20 07:58:13 --> Model Class Initialized
DEBUG - 2024-04-20 07:58:13 --> Session class already loaded. Second attempt ignored.
ERROR - 2024-04-20 07:58:14 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-04-20 07:58:14 --> Config Class Initialized
INFO - 2024-04-20 07:58:14 --> Hooks Class Initialized
DEBUG - 2024-04-20 07:58:14 --> UTF-8 Support Enabled
INFO - 2024-04-20 07:58:14 --> Utf8 Class Initialized
INFO - 2024-04-20 07:58:14 --> URI Class Initialized
INFO - 2024-04-20 07:58:14 --> Router Class Initialized
INFO - 2024-04-20 07:58:14 --> Output Class Initialized
INFO - 2024-04-20 07:58:14 --> Security Class Initialized
DEBUG - 2024-04-20 07:58:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-04-20 07:58:14 --> Input Class Initialized
INFO - 2024-04-20 07:58:14 --> Language Class Initialized
ERROR - 2024-04-20 07:58:14 --> 404 Page Not Found: Apple-touch-icon-precomposedpng/index
ERROR - 2024-04-20 07:58:14 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-04-20 07:58:14 --> Config Class Initialized
INFO - 2024-04-20 07:58:14 --> Hooks Class Initialized
DEBUG - 2024-04-20 07:58:14 --> UTF-8 Support Enabled
INFO - 2024-04-20 07:58:14 --> Utf8 Class Initialized
INFO - 2024-04-20 07:58:14 --> URI Class Initialized
INFO - 2024-04-20 07:58:14 --> Router Class Initialized
INFO - 2024-04-20 07:58:14 --> Output Class Initialized
INFO - 2024-04-20 07:58:14 --> Security Class Initialized
DEBUG - 2024-04-20 07:58:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-04-20 07:58:14 --> Input Class Initialized
INFO - 2024-04-20 07:58:14 --> Language Class Initialized
INFO - 2024-04-20 07:58:14 --> Loader Class Initialized
INFO - 2024-04-20 07:58:14 --> Helper loaded: url_helper
INFO - 2024-04-20 07:58:14 --> Helper loaded: file_helper
INFO - 2024-04-20 07:58:14 --> Helper loaded: html_helper
INFO - 2024-04-20 07:58:14 --> Helper loaded: text_helper
INFO - 2024-04-20 07:58:14 --> Helper loaded: form_helper
INFO - 2024-04-20 07:58:14 --> Helper loaded: lang_helper
INFO - 2024-04-20 07:58:14 --> Helper loaded: security_helper
INFO - 2024-04-20 07:58:14 --> Helper loaded: cookie_helper
INFO - 2024-04-20 07:58:14 --> Database Driver Class Initialized
INFO - 2024-04-20 07:58:14 --> Session: Class initialized using 'files' driver.
INFO - 2024-04-20 07:58:14 --> Parser Class Initialized
INFO - 2024-04-20 07:58:14 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-04-20 07:58:14 --> Pagination Class Initialized
INFO - 2024-04-20 07:58:14 --> Form Validation Class Initialized
INFO - 2024-04-20 07:58:14 --> Controller Class Initialized
INFO - 2024-04-20 07:58:14 --> Model Class Initialized
DEBUG - 2024-04-20 07:58:14 --> Session class already loaded. Second attempt ignored.
INFO - 2024-04-20 07:58:14 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2024-04-20 07:58:14 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-04-20 07:58:14 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-04-20 07:58:14 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-04-20 07:58:14 --> Model Class Initialized
INFO - 2024-04-20 07:58:14 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-04-20 07:58:14 --> Final output sent to browser
DEBUG - 2024-04-20 07:58:14 --> Total execution time: 0.0388
ERROR - 2024-04-20 07:58:15 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-04-20 07:58:15 --> Config Class Initialized
INFO - 2024-04-20 07:58:15 --> Hooks Class Initialized
DEBUG - 2024-04-20 07:58:15 --> UTF-8 Support Enabled
INFO - 2024-04-20 07:58:15 --> Utf8 Class Initialized
INFO - 2024-04-20 07:58:15 --> URI Class Initialized
INFO - 2024-04-20 07:58:15 --> Router Class Initialized
INFO - 2024-04-20 07:58:15 --> Output Class Initialized
INFO - 2024-04-20 07:58:15 --> Security Class Initialized
DEBUG - 2024-04-20 07:58:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-04-20 07:58:15 --> Input Class Initialized
INFO - 2024-04-20 07:58:15 --> Language Class Initialized
ERROR - 2024-04-20 07:58:15 --> 404 Page Not Found: Apple-touch-iconpng/index
ERROR - 2024-04-20 08:03:08 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-04-20 08:03:08 --> Config Class Initialized
INFO - 2024-04-20 08:03:08 --> Hooks Class Initialized
DEBUG - 2024-04-20 08:03:08 --> UTF-8 Support Enabled
INFO - 2024-04-20 08:03:08 --> Utf8 Class Initialized
INFO - 2024-04-20 08:03:08 --> URI Class Initialized
DEBUG - 2024-04-20 08:03:08 --> No URI present. Default controller set.
INFO - 2024-04-20 08:03:08 --> Router Class Initialized
INFO - 2024-04-20 08:03:08 --> Output Class Initialized
INFO - 2024-04-20 08:03:08 --> Security Class Initialized
DEBUG - 2024-04-20 08:03:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-04-20 08:03:08 --> Input Class Initialized
INFO - 2024-04-20 08:03:08 --> Language Class Initialized
INFO - 2024-04-20 08:03:08 --> Loader Class Initialized
INFO - 2024-04-20 08:03:08 --> Helper loaded: url_helper
INFO - 2024-04-20 08:03:08 --> Helper loaded: file_helper
INFO - 2024-04-20 08:03:08 --> Helper loaded: html_helper
INFO - 2024-04-20 08:03:08 --> Helper loaded: text_helper
INFO - 2024-04-20 08:03:08 --> Helper loaded: form_helper
INFO - 2024-04-20 08:03:08 --> Helper loaded: lang_helper
INFO - 2024-04-20 08:03:08 --> Helper loaded: security_helper
INFO - 2024-04-20 08:03:08 --> Helper loaded: cookie_helper
INFO - 2024-04-20 08:03:08 --> Database Driver Class Initialized
INFO - 2024-04-20 08:03:08 --> Session: Class initialized using 'files' driver.
INFO - 2024-04-20 08:03:08 --> Parser Class Initialized
INFO - 2024-04-20 08:03:08 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-04-20 08:03:08 --> Pagination Class Initialized
INFO - 2024-04-20 08:03:08 --> Form Validation Class Initialized
INFO - 2024-04-20 08:03:08 --> Controller Class Initialized
INFO - 2024-04-20 08:03:08 --> Model Class Initialized
DEBUG - 2024-04-20 08:03:08 --> Session class already loaded. Second attempt ignored.
ERROR - 2024-04-20 08:03:08 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-04-20 08:03:08 --> Config Class Initialized
INFO - 2024-04-20 08:03:08 --> Hooks Class Initialized
DEBUG - 2024-04-20 08:03:08 --> UTF-8 Support Enabled
INFO - 2024-04-20 08:03:08 --> Utf8 Class Initialized
INFO - 2024-04-20 08:03:08 --> URI Class Initialized
INFO - 2024-04-20 08:03:08 --> Router Class Initialized
INFO - 2024-04-20 08:03:08 --> Output Class Initialized
INFO - 2024-04-20 08:03:08 --> Security Class Initialized
DEBUG - 2024-04-20 08:03:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-04-20 08:03:08 --> Input Class Initialized
INFO - 2024-04-20 08:03:08 --> Language Class Initialized
INFO - 2024-04-20 08:03:08 --> Loader Class Initialized
INFO - 2024-04-20 08:03:08 --> Helper loaded: url_helper
INFO - 2024-04-20 08:03:08 --> Helper loaded: file_helper
INFO - 2024-04-20 08:03:08 --> Helper loaded: html_helper
INFO - 2024-04-20 08:03:08 --> Helper loaded: text_helper
INFO - 2024-04-20 08:03:08 --> Helper loaded: form_helper
INFO - 2024-04-20 08:03:08 --> Helper loaded: lang_helper
INFO - 2024-04-20 08:03:08 --> Helper loaded: security_helper
INFO - 2024-04-20 08:03:08 --> Helper loaded: cookie_helper
INFO - 2024-04-20 08:03:08 --> Database Driver Class Initialized
INFO - 2024-04-20 08:03:08 --> Session: Class initialized using 'files' driver.
INFO - 2024-04-20 08:03:08 --> Parser Class Initialized
INFO - 2024-04-20 08:03:08 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-04-20 08:03:08 --> Pagination Class Initialized
INFO - 2024-04-20 08:03:08 --> Form Validation Class Initialized
INFO - 2024-04-20 08:03:08 --> Controller Class Initialized
INFO - 2024-04-20 08:03:08 --> Model Class Initialized
DEBUG - 2024-04-20 08:03:08 --> Session class already loaded. Second attempt ignored.
INFO - 2024-04-20 08:03:08 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2024-04-20 08:03:08 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-04-20 08:03:08 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-04-20 08:03:09 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-04-20 08:03:09 --> Model Class Initialized
INFO - 2024-04-20 08:03:09 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-04-20 08:03:09 --> Final output sent to browser
DEBUG - 2024-04-20 08:03:09 --> Total execution time: 0.0404
ERROR - 2024-04-20 08:04:07 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-04-20 08:04:07 --> Config Class Initialized
INFO - 2024-04-20 08:04:07 --> Hooks Class Initialized
DEBUG - 2024-04-20 08:04:07 --> UTF-8 Support Enabled
INFO - 2024-04-20 08:04:07 --> Utf8 Class Initialized
INFO - 2024-04-20 08:04:07 --> URI Class Initialized
INFO - 2024-04-20 08:04:07 --> Router Class Initialized
INFO - 2024-04-20 08:04:07 --> Output Class Initialized
INFO - 2024-04-20 08:04:07 --> Security Class Initialized
DEBUG - 2024-04-20 08:04:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-04-20 08:04:07 --> Input Class Initialized
INFO - 2024-04-20 08:04:07 --> Language Class Initialized
INFO - 2024-04-20 08:04:07 --> Loader Class Initialized
INFO - 2024-04-20 08:04:07 --> Helper loaded: url_helper
INFO - 2024-04-20 08:04:07 --> Helper loaded: file_helper
INFO - 2024-04-20 08:04:07 --> Helper loaded: html_helper
INFO - 2024-04-20 08:04:07 --> Helper loaded: text_helper
INFO - 2024-04-20 08:04:07 --> Helper loaded: form_helper
INFO - 2024-04-20 08:04:07 --> Helper loaded: lang_helper
INFO - 2024-04-20 08:04:07 --> Helper loaded: security_helper
INFO - 2024-04-20 08:04:07 --> Helper loaded: cookie_helper
INFO - 2024-04-20 08:04:07 --> Database Driver Class Initialized
INFO - 2024-04-20 08:04:07 --> Session: Class initialized using 'files' driver.
INFO - 2024-04-20 08:04:07 --> Parser Class Initialized
INFO - 2024-04-20 08:04:07 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-04-20 08:04:07 --> Pagination Class Initialized
INFO - 2024-04-20 08:04:07 --> Form Validation Class Initialized
INFO - 2024-04-20 08:04:07 --> Controller Class Initialized
INFO - 2024-04-20 08:04:07 --> Model Class Initialized
DEBUG - 2024-04-20 08:04:07 --> Session class already loaded. Second attempt ignored.
INFO - 2024-04-20 08:04:07 --> Model Class Initialized
INFO - 2024-04-20 08:04:07 --> Final output sent to browser
DEBUG - 2024-04-20 08:04:07 --> Total execution time: 0.0207
ERROR - 2024-04-20 08:04:07 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-04-20 08:04:07 --> Config Class Initialized
INFO - 2024-04-20 08:04:07 --> Hooks Class Initialized
DEBUG - 2024-04-20 08:04:07 --> UTF-8 Support Enabled
INFO - 2024-04-20 08:04:07 --> Utf8 Class Initialized
INFO - 2024-04-20 08:04:07 --> URI Class Initialized
DEBUG - 2024-04-20 08:04:07 --> No URI present. Default controller set.
INFO - 2024-04-20 08:04:07 --> Router Class Initialized
INFO - 2024-04-20 08:04:07 --> Output Class Initialized
INFO - 2024-04-20 08:04:07 --> Security Class Initialized
DEBUG - 2024-04-20 08:04:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-04-20 08:04:07 --> Input Class Initialized
INFO - 2024-04-20 08:04:07 --> Language Class Initialized
INFO - 2024-04-20 08:04:07 --> Loader Class Initialized
INFO - 2024-04-20 08:04:07 --> Helper loaded: url_helper
INFO - 2024-04-20 08:04:07 --> Helper loaded: file_helper
INFO - 2024-04-20 08:04:07 --> Helper loaded: html_helper
INFO - 2024-04-20 08:04:07 --> Helper loaded: text_helper
INFO - 2024-04-20 08:04:07 --> Helper loaded: form_helper
INFO - 2024-04-20 08:04:07 --> Helper loaded: lang_helper
INFO - 2024-04-20 08:04:07 --> Helper loaded: security_helper
INFO - 2024-04-20 08:04:07 --> Helper loaded: cookie_helper
INFO - 2024-04-20 08:04:07 --> Database Driver Class Initialized
INFO - 2024-04-20 08:04:07 --> Session: Class initialized using 'files' driver.
INFO - 2024-04-20 08:04:07 --> Parser Class Initialized
INFO - 2024-04-20 08:04:07 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-04-20 08:04:07 --> Pagination Class Initialized
INFO - 2024-04-20 08:04:07 --> Form Validation Class Initialized
INFO - 2024-04-20 08:04:07 --> Controller Class Initialized
INFO - 2024-04-20 08:04:07 --> Model Class Initialized
DEBUG - 2024-04-20 08:04:07 --> Session class already loaded. Second attempt ignored.
INFO - 2024-04-20 08:04:07 --> Model Class Initialized
DEBUG - 2024-04-20 08:04:07 --> Session class already loaded. Second attempt ignored.
INFO - 2024-04-20 08:04:07 --> Model Class Initialized
INFO - 2024-04-20 08:04:07 --> Model Class Initialized
INFO - 2024-04-20 08:04:07 --> Model Class Initialized
INFO - 2024-04-20 08:04:07 --> Model Class Initialized
DEBUG - 2024-04-20 08:04:07 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-04-20 08:04:07 --> Session class already loaded. Second attempt ignored.
INFO - 2024-04-20 08:04:07 --> Model Class Initialized
INFO - 2024-04-20 08:04:07 --> Model Class Initialized
INFO - 2024-04-20 08:04:08 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2024-04-20 08:04:08 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-04-20 08:04:08 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-04-20 08:04:08 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-04-20 08:04:08 --> Model Class Initialized
INFO - 2024-04-20 08:04:08 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-04-20 08:04:08 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-04-20 08:04:08 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-04-20 08:04:08 --> Final output sent to browser
DEBUG - 2024-04-20 08:04:08 --> Total execution time: 0.6020
ERROR - 2024-04-20 08:04:11 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-04-20 08:04:11 --> Config Class Initialized
INFO - 2024-04-20 08:04:11 --> Hooks Class Initialized
DEBUG - 2024-04-20 08:04:11 --> UTF-8 Support Enabled
INFO - 2024-04-20 08:04:11 --> Utf8 Class Initialized
INFO - 2024-04-20 08:04:11 --> URI Class Initialized
INFO - 2024-04-20 08:04:11 --> Router Class Initialized
INFO - 2024-04-20 08:04:11 --> Output Class Initialized
INFO - 2024-04-20 08:04:11 --> Security Class Initialized
DEBUG - 2024-04-20 08:04:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-04-20 08:04:11 --> Input Class Initialized
INFO - 2024-04-20 08:04:11 --> Language Class Initialized
INFO - 2024-04-20 08:04:11 --> Loader Class Initialized
INFO - 2024-04-20 08:04:11 --> Helper loaded: url_helper
INFO - 2024-04-20 08:04:11 --> Helper loaded: file_helper
INFO - 2024-04-20 08:04:11 --> Helper loaded: html_helper
INFO - 2024-04-20 08:04:11 --> Helper loaded: text_helper
INFO - 2024-04-20 08:04:11 --> Helper loaded: form_helper
INFO - 2024-04-20 08:04:11 --> Helper loaded: lang_helper
INFO - 2024-04-20 08:04:11 --> Helper loaded: security_helper
INFO - 2024-04-20 08:04:11 --> Helper loaded: cookie_helper
INFO - 2024-04-20 08:04:11 --> Database Driver Class Initialized
INFO - 2024-04-20 08:04:11 --> Session: Class initialized using 'files' driver.
INFO - 2024-04-20 08:04:11 --> Parser Class Initialized
INFO - 2024-04-20 08:04:11 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-04-20 08:04:11 --> Pagination Class Initialized
INFO - 2024-04-20 08:04:11 --> Form Validation Class Initialized
INFO - 2024-04-20 08:04:11 --> Controller Class Initialized
DEBUG - 2024-04-20 08:04:11 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-04-20 08:04:11 --> Session class already loaded. Second attempt ignored.
INFO - 2024-04-20 08:04:11 --> Model Class Initialized
INFO - 2024-04-20 08:04:11 --> Final output sent to browser
DEBUG - 2024-04-20 08:04:11 --> Total execution time: 0.0140
ERROR - 2024-04-20 08:04:20 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-04-20 08:04:20 --> Config Class Initialized
INFO - 2024-04-20 08:04:20 --> Hooks Class Initialized
DEBUG - 2024-04-20 08:04:20 --> UTF-8 Support Enabled
INFO - 2024-04-20 08:04:20 --> Utf8 Class Initialized
INFO - 2024-04-20 08:04:20 --> URI Class Initialized
INFO - 2024-04-20 08:04:20 --> Router Class Initialized
INFO - 2024-04-20 08:04:20 --> Output Class Initialized
INFO - 2024-04-20 08:04:20 --> Security Class Initialized
DEBUG - 2024-04-20 08:04:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-04-20 08:04:20 --> Input Class Initialized
INFO - 2024-04-20 08:04:20 --> Language Class Initialized
INFO - 2024-04-20 08:04:20 --> Loader Class Initialized
INFO - 2024-04-20 08:04:20 --> Helper loaded: url_helper
INFO - 2024-04-20 08:04:20 --> Helper loaded: file_helper
INFO - 2024-04-20 08:04:20 --> Helper loaded: html_helper
INFO - 2024-04-20 08:04:20 --> Helper loaded: text_helper
INFO - 2024-04-20 08:04:20 --> Helper loaded: form_helper
INFO - 2024-04-20 08:04:20 --> Helper loaded: lang_helper
INFO - 2024-04-20 08:04:20 --> Helper loaded: security_helper
INFO - 2024-04-20 08:04:20 --> Helper loaded: cookie_helper
INFO - 2024-04-20 08:04:20 --> Database Driver Class Initialized
INFO - 2024-04-20 08:04:20 --> Session: Class initialized using 'files' driver.
INFO - 2024-04-20 08:04:20 --> Parser Class Initialized
INFO - 2024-04-20 08:04:20 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-04-20 08:04:20 --> Pagination Class Initialized
INFO - 2024-04-20 08:04:20 --> Form Validation Class Initialized
INFO - 2024-04-20 08:04:20 --> Controller Class Initialized
INFO - 2024-04-20 08:04:20 --> Model Class Initialized
DEBUG - 2024-04-20 08:04:20 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-04-20 08:04:20 --> Session class already loaded. Second attempt ignored.
INFO - 2024-04-20 08:04:20 --> Model Class Initialized
DEBUG - 2024-04-20 08:04:20 --> Session class already loaded. Second attempt ignored.
INFO - 2024-04-20 08:04:20 --> Model Class Initialized
INFO - 2024-04-20 08:04:20 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice.php
DEBUG - 2024-04-20 08:04:20 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-04-20 08:04:20 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-04-20 08:04:20 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-04-20 08:04:20 --> Model Class Initialized
INFO - 2024-04-20 08:04:20 --> Model Class Initialized
INFO - 2024-04-20 08:04:20 --> Model Class Initialized
INFO - 2024-04-20 08:04:20 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-04-20 08:04:20 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-04-20 08:04:20 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-04-20 08:04:20 --> Final output sent to browser
DEBUG - 2024-04-20 08:04:20 --> Total execution time: 0.2753
ERROR - 2024-04-20 08:04:21 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-04-20 08:04:21 --> Config Class Initialized
INFO - 2024-04-20 08:04:21 --> Hooks Class Initialized
DEBUG - 2024-04-20 08:04:21 --> UTF-8 Support Enabled
INFO - 2024-04-20 08:04:21 --> Utf8 Class Initialized
INFO - 2024-04-20 08:04:21 --> URI Class Initialized
INFO - 2024-04-20 08:04:21 --> Router Class Initialized
INFO - 2024-04-20 08:04:21 --> Output Class Initialized
INFO - 2024-04-20 08:04:21 --> Security Class Initialized
DEBUG - 2024-04-20 08:04:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-04-20 08:04:21 --> Input Class Initialized
INFO - 2024-04-20 08:04:21 --> Language Class Initialized
INFO - 2024-04-20 08:04:21 --> Loader Class Initialized
INFO - 2024-04-20 08:04:21 --> Helper loaded: url_helper
INFO - 2024-04-20 08:04:21 --> Helper loaded: file_helper
INFO - 2024-04-20 08:04:21 --> Helper loaded: html_helper
INFO - 2024-04-20 08:04:21 --> Helper loaded: text_helper
INFO - 2024-04-20 08:04:21 --> Helper loaded: form_helper
INFO - 2024-04-20 08:04:21 --> Helper loaded: lang_helper
INFO - 2024-04-20 08:04:21 --> Helper loaded: security_helper
INFO - 2024-04-20 08:04:21 --> Helper loaded: cookie_helper
INFO - 2024-04-20 08:04:21 --> Database Driver Class Initialized
INFO - 2024-04-20 08:04:21 --> Session: Class initialized using 'files' driver.
INFO - 2024-04-20 08:04:21 --> Parser Class Initialized
INFO - 2024-04-20 08:04:21 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-04-20 08:04:21 --> Pagination Class Initialized
INFO - 2024-04-20 08:04:21 --> Form Validation Class Initialized
INFO - 2024-04-20 08:04:21 --> Controller Class Initialized
INFO - 2024-04-20 08:04:21 --> Model Class Initialized
DEBUG - 2024-04-20 08:04:21 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-04-20 08:04:21 --> Session class already loaded. Second attempt ignored.
INFO - 2024-04-20 08:04:21 --> Model Class Initialized
DEBUG - 2024-04-20 08:04:21 --> Session class already loaded. Second attempt ignored.
INFO - 2024-04-20 08:04:21 --> Model Class Initialized
INFO - 2024-04-20 08:04:21 --> Final output sent to browser
DEBUG - 2024-04-20 08:04:21 --> Total execution time: 0.0501
ERROR - 2024-04-20 08:04:32 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-04-20 08:04:32 --> Config Class Initialized
INFO - 2024-04-20 08:04:32 --> Hooks Class Initialized
DEBUG - 2024-04-20 08:04:32 --> UTF-8 Support Enabled
INFO - 2024-04-20 08:04:32 --> Utf8 Class Initialized
INFO - 2024-04-20 08:04:32 --> URI Class Initialized
INFO - 2024-04-20 08:04:32 --> Router Class Initialized
INFO - 2024-04-20 08:04:32 --> Output Class Initialized
INFO - 2024-04-20 08:04:32 --> Security Class Initialized
DEBUG - 2024-04-20 08:04:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-04-20 08:04:32 --> Input Class Initialized
INFO - 2024-04-20 08:04:32 --> Language Class Initialized
INFO - 2024-04-20 08:04:32 --> Loader Class Initialized
INFO - 2024-04-20 08:04:32 --> Helper loaded: url_helper
INFO - 2024-04-20 08:04:32 --> Helper loaded: file_helper
INFO - 2024-04-20 08:04:32 --> Helper loaded: html_helper
INFO - 2024-04-20 08:04:32 --> Helper loaded: text_helper
INFO - 2024-04-20 08:04:32 --> Helper loaded: form_helper
INFO - 2024-04-20 08:04:32 --> Helper loaded: lang_helper
INFO - 2024-04-20 08:04:32 --> Helper loaded: security_helper
INFO - 2024-04-20 08:04:32 --> Helper loaded: cookie_helper
INFO - 2024-04-20 08:04:32 --> Database Driver Class Initialized
INFO - 2024-04-20 08:04:32 --> Session: Class initialized using 'files' driver.
INFO - 2024-04-20 08:04:32 --> Parser Class Initialized
INFO - 2024-04-20 08:04:32 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-04-20 08:04:32 --> Pagination Class Initialized
INFO - 2024-04-20 08:04:32 --> Form Validation Class Initialized
INFO - 2024-04-20 08:04:32 --> Controller Class Initialized
INFO - 2024-04-20 08:04:32 --> Model Class Initialized
DEBUG - 2024-04-20 08:04:32 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-04-20 08:04:32 --> Session class already loaded. Second attempt ignored.
INFO - 2024-04-20 08:04:32 --> Model Class Initialized
DEBUG - 2024-04-20 08:04:32 --> Session class already loaded. Second attempt ignored.
INFO - 2024-04-20 08:04:32 --> Model Class Initialized
INFO - 2024-04-20 08:04:34 --> Final output sent to browser
DEBUG - 2024-04-20 08:04:34 --> Total execution time: 1.3894
ERROR - 2024-04-20 08:08:09 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-04-20 08:08:09 --> Config Class Initialized
INFO - 2024-04-20 08:08:09 --> Hooks Class Initialized
DEBUG - 2024-04-20 08:08:09 --> UTF-8 Support Enabled
INFO - 2024-04-20 08:08:09 --> Utf8 Class Initialized
INFO - 2024-04-20 08:08:09 --> URI Class Initialized
DEBUG - 2024-04-20 08:08:09 --> No URI present. Default controller set.
INFO - 2024-04-20 08:08:09 --> Router Class Initialized
INFO - 2024-04-20 08:08:09 --> Output Class Initialized
INFO - 2024-04-20 08:08:09 --> Security Class Initialized
DEBUG - 2024-04-20 08:08:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-04-20 08:08:09 --> Input Class Initialized
INFO - 2024-04-20 08:08:09 --> Language Class Initialized
INFO - 2024-04-20 08:08:09 --> Loader Class Initialized
INFO - 2024-04-20 08:08:09 --> Helper loaded: url_helper
INFO - 2024-04-20 08:08:09 --> Helper loaded: file_helper
INFO - 2024-04-20 08:08:09 --> Helper loaded: html_helper
INFO - 2024-04-20 08:08:09 --> Helper loaded: text_helper
INFO - 2024-04-20 08:08:09 --> Helper loaded: form_helper
INFO - 2024-04-20 08:08:09 --> Helper loaded: lang_helper
INFO - 2024-04-20 08:08:09 --> Helper loaded: security_helper
INFO - 2024-04-20 08:08:09 --> Helper loaded: cookie_helper
INFO - 2024-04-20 08:08:09 --> Database Driver Class Initialized
INFO - 2024-04-20 08:08:09 --> Session: Class initialized using 'files' driver.
INFO - 2024-04-20 08:08:09 --> Parser Class Initialized
INFO - 2024-04-20 08:08:09 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-04-20 08:08:09 --> Pagination Class Initialized
INFO - 2024-04-20 08:08:09 --> Form Validation Class Initialized
INFO - 2024-04-20 08:08:09 --> Controller Class Initialized
INFO - 2024-04-20 08:08:09 --> Model Class Initialized
DEBUG - 2024-04-20 08:08:09 --> Session class already loaded. Second attempt ignored.
INFO - 2024-04-20 08:08:09 --> Model Class Initialized
DEBUG - 2024-04-20 08:08:09 --> Session class already loaded. Second attempt ignored.
INFO - 2024-04-20 08:08:09 --> Model Class Initialized
INFO - 2024-04-20 08:08:09 --> Model Class Initialized
INFO - 2024-04-20 08:08:09 --> Model Class Initialized
INFO - 2024-04-20 08:08:09 --> Model Class Initialized
DEBUG - 2024-04-20 08:08:09 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-04-20 08:08:09 --> Session class already loaded. Second attempt ignored.
INFO - 2024-04-20 08:08:09 --> Model Class Initialized
INFO - 2024-04-20 08:08:09 --> Model Class Initialized
INFO - 2024-04-20 08:08:10 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2024-04-20 08:08:10 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-04-20 08:08:10 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-04-20 08:08:10 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-04-20 08:08:10 --> Model Class Initialized
INFO - 2024-04-20 08:08:10 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-04-20 08:08:10 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-04-20 08:08:10 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-04-20 08:08:10 --> Final output sent to browser
DEBUG - 2024-04-20 08:08:10 --> Total execution time: 0.6255
ERROR - 2024-04-20 08:40:40 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-04-20 08:40:40 --> Config Class Initialized
INFO - 2024-04-20 08:40:40 --> Hooks Class Initialized
DEBUG - 2024-04-20 08:40:40 --> UTF-8 Support Enabled
INFO - 2024-04-20 08:40:40 --> Utf8 Class Initialized
INFO - 2024-04-20 08:40:40 --> URI Class Initialized
INFO - 2024-04-20 08:40:40 --> Router Class Initialized
INFO - 2024-04-20 08:40:40 --> Output Class Initialized
INFO - 2024-04-20 08:40:40 --> Security Class Initialized
DEBUG - 2024-04-20 08:40:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-04-20 08:40:40 --> Input Class Initialized
INFO - 2024-04-20 08:40:40 --> Language Class Initialized
ERROR - 2024-04-20 08:40:40 --> 404 Page Not Found: Well-known/assetlinks.json
ERROR - 2024-04-20 08:48:02 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-04-20 08:48:02 --> Config Class Initialized
INFO - 2024-04-20 08:48:02 --> Hooks Class Initialized
DEBUG - 2024-04-20 08:48:02 --> UTF-8 Support Enabled
INFO - 2024-04-20 08:48:02 --> Utf8 Class Initialized
INFO - 2024-04-20 08:48:02 --> URI Class Initialized
DEBUG - 2024-04-20 08:48:02 --> No URI present. Default controller set.
INFO - 2024-04-20 08:48:02 --> Router Class Initialized
INFO - 2024-04-20 08:48:02 --> Output Class Initialized
INFO - 2024-04-20 08:48:02 --> Security Class Initialized
DEBUG - 2024-04-20 08:48:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-04-20 08:48:02 --> Input Class Initialized
INFO - 2024-04-20 08:48:02 --> Language Class Initialized
INFO - 2024-04-20 08:48:02 --> Loader Class Initialized
INFO - 2024-04-20 08:48:02 --> Helper loaded: url_helper
INFO - 2024-04-20 08:48:02 --> Helper loaded: file_helper
INFO - 2024-04-20 08:48:02 --> Helper loaded: html_helper
INFO - 2024-04-20 08:48:02 --> Helper loaded: text_helper
INFO - 2024-04-20 08:48:02 --> Helper loaded: form_helper
INFO - 2024-04-20 08:48:02 --> Helper loaded: lang_helper
INFO - 2024-04-20 08:48:02 --> Helper loaded: security_helper
INFO - 2024-04-20 08:48:02 --> Helper loaded: cookie_helper
INFO - 2024-04-20 08:48:02 --> Database Driver Class Initialized
INFO - 2024-04-20 08:48:02 --> Session: Class initialized using 'files' driver.
INFO - 2024-04-20 08:48:02 --> Parser Class Initialized
INFO - 2024-04-20 08:48:02 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-04-20 08:48:02 --> Pagination Class Initialized
INFO - 2024-04-20 08:48:02 --> Form Validation Class Initialized
INFO - 2024-04-20 08:48:02 --> Controller Class Initialized
INFO - 2024-04-20 08:48:02 --> Model Class Initialized
DEBUG - 2024-04-20 08:48:02 --> Session class already loaded. Second attempt ignored.
INFO - 2024-04-20 08:48:02 --> Model Class Initialized
DEBUG - 2024-04-20 08:48:02 --> Session class already loaded. Second attempt ignored.
INFO - 2024-04-20 08:48:02 --> Model Class Initialized
INFO - 2024-04-20 08:48:02 --> Model Class Initialized
INFO - 2024-04-20 08:48:02 --> Model Class Initialized
INFO - 2024-04-20 08:48:02 --> Model Class Initialized
DEBUG - 2024-04-20 08:48:02 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-04-20 08:48:02 --> Session class already loaded. Second attempt ignored.
INFO - 2024-04-20 08:48:02 --> Model Class Initialized
INFO - 2024-04-20 08:48:02 --> Model Class Initialized
INFO - 2024-04-20 08:48:03 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2024-04-20 08:48:03 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-04-20 08:48:03 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-04-20 08:48:03 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-04-20 08:48:03 --> Model Class Initialized
INFO - 2024-04-20 08:48:03 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-04-20 08:48:03 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-04-20 08:48:03 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-04-20 08:48:03 --> Final output sent to browser
DEBUG - 2024-04-20 08:48:03 --> Total execution time: 0.6736
ERROR - 2024-04-20 08:48:14 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-04-20 08:48:14 --> Config Class Initialized
INFO - 2024-04-20 08:48:14 --> Hooks Class Initialized
DEBUG - 2024-04-20 08:48:14 --> UTF-8 Support Enabled
INFO - 2024-04-20 08:48:14 --> Utf8 Class Initialized
INFO - 2024-04-20 08:48:14 --> URI Class Initialized
INFO - 2024-04-20 08:48:14 --> Router Class Initialized
INFO - 2024-04-20 08:48:14 --> Output Class Initialized
INFO - 2024-04-20 08:48:14 --> Security Class Initialized
DEBUG - 2024-04-20 08:48:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-04-20 08:48:14 --> Input Class Initialized
INFO - 2024-04-20 08:48:14 --> Language Class Initialized
INFO - 2024-04-20 08:48:14 --> Loader Class Initialized
INFO - 2024-04-20 08:48:14 --> Helper loaded: url_helper
INFO - 2024-04-20 08:48:14 --> Helper loaded: file_helper
INFO - 2024-04-20 08:48:14 --> Helper loaded: html_helper
INFO - 2024-04-20 08:48:14 --> Helper loaded: text_helper
INFO - 2024-04-20 08:48:14 --> Helper loaded: form_helper
INFO - 2024-04-20 08:48:14 --> Helper loaded: lang_helper
INFO - 2024-04-20 08:48:14 --> Helper loaded: security_helper
INFO - 2024-04-20 08:48:14 --> Helper loaded: cookie_helper
INFO - 2024-04-20 08:48:14 --> Database Driver Class Initialized
INFO - 2024-04-20 08:48:14 --> Session: Class initialized using 'files' driver.
INFO - 2024-04-20 08:48:14 --> Parser Class Initialized
INFO - 2024-04-20 08:48:14 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-04-20 08:48:14 --> Pagination Class Initialized
INFO - 2024-04-20 08:48:14 --> Form Validation Class Initialized
INFO - 2024-04-20 08:48:14 --> Controller Class Initialized
INFO - 2024-04-20 08:48:14 --> Model Class Initialized
INFO - 2024-04-20 08:48:14 --> Model Class Initialized
INFO - 2024-04-20 08:48:14 --> Model Class Initialized
INFO - 2024-04-20 08:48:14 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/report/stock_report_batch_wise.php
DEBUG - 2024-04-20 08:48:14 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-04-20 08:48:14 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-04-20 08:48:14 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-04-20 08:48:14 --> Model Class Initialized
INFO - 2024-04-20 08:48:14 --> Model Class Initialized
INFO - 2024-04-20 08:48:14 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-04-20 08:48:14 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-04-20 08:48:14 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-04-20 08:48:14 --> Final output sent to browser
DEBUG - 2024-04-20 08:48:14 --> Total execution time: 0.2959
ERROR - 2024-04-20 08:48:15 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-04-20 08:48:15 --> Config Class Initialized
INFO - 2024-04-20 08:48:15 --> Hooks Class Initialized
DEBUG - 2024-04-20 08:48:15 --> UTF-8 Support Enabled
INFO - 2024-04-20 08:48:15 --> Utf8 Class Initialized
INFO - 2024-04-20 08:48:15 --> URI Class Initialized
INFO - 2024-04-20 08:48:15 --> Router Class Initialized
INFO - 2024-04-20 08:48:15 --> Output Class Initialized
INFO - 2024-04-20 08:48:15 --> Security Class Initialized
DEBUG - 2024-04-20 08:48:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-04-20 08:48:15 --> Input Class Initialized
INFO - 2024-04-20 08:48:15 --> Language Class Initialized
INFO - 2024-04-20 08:48:15 --> Loader Class Initialized
INFO - 2024-04-20 08:48:15 --> Helper loaded: url_helper
INFO - 2024-04-20 08:48:15 --> Helper loaded: file_helper
INFO - 2024-04-20 08:48:15 --> Helper loaded: html_helper
INFO - 2024-04-20 08:48:15 --> Helper loaded: text_helper
INFO - 2024-04-20 08:48:15 --> Helper loaded: form_helper
INFO - 2024-04-20 08:48:15 --> Helper loaded: lang_helper
INFO - 2024-04-20 08:48:15 --> Helper loaded: security_helper
INFO - 2024-04-20 08:48:15 --> Helper loaded: cookie_helper
INFO - 2024-04-20 08:48:15 --> Database Driver Class Initialized
INFO - 2024-04-20 08:48:15 --> Session: Class initialized using 'files' driver.
INFO - 2024-04-20 08:48:15 --> Parser Class Initialized
INFO - 2024-04-20 08:48:15 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-04-20 08:48:15 --> Pagination Class Initialized
INFO - 2024-04-20 08:48:15 --> Form Validation Class Initialized
INFO - 2024-04-20 08:48:15 --> Controller Class Initialized
INFO - 2024-04-20 08:48:15 --> Model Class Initialized
INFO - 2024-04-20 08:48:15 --> Model Class Initialized
INFO - 2024-04-20 08:48:15 --> Final output sent to browser
DEBUG - 2024-04-20 08:48:15 --> Total execution time: 0.0324
ERROR - 2024-04-20 08:48:39 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-04-20 08:48:39 --> Config Class Initialized
INFO - 2024-04-20 08:48:39 --> Hooks Class Initialized
DEBUG - 2024-04-20 08:48:39 --> UTF-8 Support Enabled
INFO - 2024-04-20 08:48:39 --> Utf8 Class Initialized
INFO - 2024-04-20 08:48:39 --> URI Class Initialized
INFO - 2024-04-20 08:48:39 --> Router Class Initialized
INFO - 2024-04-20 08:48:39 --> Output Class Initialized
INFO - 2024-04-20 08:48:39 --> Security Class Initialized
DEBUG - 2024-04-20 08:48:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-04-20 08:48:39 --> Input Class Initialized
INFO - 2024-04-20 08:48:39 --> Language Class Initialized
INFO - 2024-04-20 08:48:39 --> Loader Class Initialized
INFO - 2024-04-20 08:48:39 --> Helper loaded: url_helper
INFO - 2024-04-20 08:48:39 --> Helper loaded: file_helper
INFO - 2024-04-20 08:48:39 --> Helper loaded: html_helper
INFO - 2024-04-20 08:48:39 --> Helper loaded: text_helper
INFO - 2024-04-20 08:48:39 --> Helper loaded: form_helper
INFO - 2024-04-20 08:48:39 --> Helper loaded: lang_helper
INFO - 2024-04-20 08:48:39 --> Helper loaded: security_helper
INFO - 2024-04-20 08:48:39 --> Helper loaded: cookie_helper
INFO - 2024-04-20 08:48:39 --> Database Driver Class Initialized
INFO - 2024-04-20 08:48:39 --> Session: Class initialized using 'files' driver.
INFO - 2024-04-20 08:48:39 --> Parser Class Initialized
INFO - 2024-04-20 08:48:39 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-04-20 08:48:39 --> Pagination Class Initialized
INFO - 2024-04-20 08:48:39 --> Form Validation Class Initialized
INFO - 2024-04-20 08:48:39 --> Controller Class Initialized
INFO - 2024-04-20 08:48:39 --> Model Class Initialized
INFO - 2024-04-20 08:48:39 --> Model Class Initialized
INFO - 2024-04-20 08:48:39 --> Model Class Initialized
INFO - 2024-04-20 08:48:39 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/report/stock_report_batch_wise.php
DEBUG - 2024-04-20 08:48:39 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-04-20 08:48:39 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-04-20 08:48:39 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-04-20 08:48:39 --> Model Class Initialized
INFO - 2024-04-20 08:48:39 --> Model Class Initialized
INFO - 2024-04-20 08:48:39 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-04-20 08:48:39 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-04-20 08:48:39 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-04-20 08:48:39 --> Final output sent to browser
DEBUG - 2024-04-20 08:48:39 --> Total execution time: 0.2844
ERROR - 2024-04-20 08:48:40 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-04-20 08:48:40 --> Config Class Initialized
INFO - 2024-04-20 08:48:40 --> Hooks Class Initialized
DEBUG - 2024-04-20 08:48:40 --> UTF-8 Support Enabled
INFO - 2024-04-20 08:48:40 --> Utf8 Class Initialized
INFO - 2024-04-20 08:48:40 --> URI Class Initialized
INFO - 2024-04-20 08:48:40 --> Router Class Initialized
INFO - 2024-04-20 08:48:40 --> Output Class Initialized
INFO - 2024-04-20 08:48:40 --> Security Class Initialized
DEBUG - 2024-04-20 08:48:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-04-20 08:48:40 --> Input Class Initialized
INFO - 2024-04-20 08:48:40 --> Language Class Initialized
INFO - 2024-04-20 08:48:40 --> Loader Class Initialized
INFO - 2024-04-20 08:48:40 --> Helper loaded: url_helper
INFO - 2024-04-20 08:48:40 --> Helper loaded: file_helper
INFO - 2024-04-20 08:48:40 --> Helper loaded: html_helper
INFO - 2024-04-20 08:48:40 --> Helper loaded: text_helper
INFO - 2024-04-20 08:48:40 --> Helper loaded: form_helper
INFO - 2024-04-20 08:48:40 --> Helper loaded: lang_helper
INFO - 2024-04-20 08:48:40 --> Helper loaded: security_helper
INFO - 2024-04-20 08:48:40 --> Helper loaded: cookie_helper
INFO - 2024-04-20 08:48:40 --> Database Driver Class Initialized
INFO - 2024-04-20 08:48:40 --> Session: Class initialized using 'files' driver.
INFO - 2024-04-20 08:48:40 --> Parser Class Initialized
INFO - 2024-04-20 08:48:40 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-04-20 08:48:40 --> Pagination Class Initialized
INFO - 2024-04-20 08:48:40 --> Form Validation Class Initialized
INFO - 2024-04-20 08:48:40 --> Controller Class Initialized
INFO - 2024-04-20 08:48:40 --> Model Class Initialized
INFO - 2024-04-20 08:48:40 --> Model Class Initialized
INFO - 2024-04-20 08:48:40 --> Final output sent to browser
DEBUG - 2024-04-20 08:48:40 --> Total execution time: 0.0305
ERROR - 2024-04-20 08:48:49 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-04-20 08:48:49 --> Config Class Initialized
INFO - 2024-04-20 08:48:49 --> Hooks Class Initialized
DEBUG - 2024-04-20 08:48:49 --> UTF-8 Support Enabled
INFO - 2024-04-20 08:48:49 --> Utf8 Class Initialized
INFO - 2024-04-20 08:48:49 --> URI Class Initialized
INFO - 2024-04-20 08:48:49 --> Router Class Initialized
INFO - 2024-04-20 08:48:49 --> Output Class Initialized
INFO - 2024-04-20 08:48:49 --> Security Class Initialized
DEBUG - 2024-04-20 08:48:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-04-20 08:48:49 --> Input Class Initialized
INFO - 2024-04-20 08:48:49 --> Language Class Initialized
INFO - 2024-04-20 08:48:49 --> Loader Class Initialized
INFO - 2024-04-20 08:48:49 --> Helper loaded: url_helper
INFO - 2024-04-20 08:48:49 --> Helper loaded: file_helper
INFO - 2024-04-20 08:48:49 --> Helper loaded: html_helper
INFO - 2024-04-20 08:48:49 --> Helper loaded: text_helper
INFO - 2024-04-20 08:48:49 --> Helper loaded: form_helper
INFO - 2024-04-20 08:48:49 --> Helper loaded: lang_helper
INFO - 2024-04-20 08:48:49 --> Helper loaded: security_helper
INFO - 2024-04-20 08:48:49 --> Helper loaded: cookie_helper
INFO - 2024-04-20 08:48:49 --> Database Driver Class Initialized
INFO - 2024-04-20 08:48:49 --> Session: Class initialized using 'files' driver.
INFO - 2024-04-20 08:48:49 --> Parser Class Initialized
INFO - 2024-04-20 08:48:49 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-04-20 08:48:49 --> Pagination Class Initialized
INFO - 2024-04-20 08:48:49 --> Form Validation Class Initialized
INFO - 2024-04-20 08:48:49 --> Controller Class Initialized
INFO - 2024-04-20 08:48:49 --> Model Class Initialized
INFO - 2024-04-20 08:48:49 --> Model Class Initialized
INFO - 2024-04-20 08:48:49 --> Final output sent to browser
DEBUG - 2024-04-20 08:48:49 --> Total execution time: 0.0948
ERROR - 2024-04-20 08:48:56 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-04-20 08:48:56 --> Config Class Initialized
INFO - 2024-04-20 08:48:56 --> Hooks Class Initialized
DEBUG - 2024-04-20 08:48:56 --> UTF-8 Support Enabled
INFO - 2024-04-20 08:48:56 --> Utf8 Class Initialized
INFO - 2024-04-20 08:48:56 --> URI Class Initialized
INFO - 2024-04-20 08:48:56 --> Router Class Initialized
INFO - 2024-04-20 08:48:56 --> Output Class Initialized
INFO - 2024-04-20 08:48:56 --> Security Class Initialized
DEBUG - 2024-04-20 08:48:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-04-20 08:48:56 --> Input Class Initialized
INFO - 2024-04-20 08:48:56 --> Language Class Initialized
INFO - 2024-04-20 08:48:56 --> Loader Class Initialized
INFO - 2024-04-20 08:48:56 --> Helper loaded: url_helper
INFO - 2024-04-20 08:48:56 --> Helper loaded: file_helper
INFO - 2024-04-20 08:48:56 --> Helper loaded: html_helper
INFO - 2024-04-20 08:48:56 --> Helper loaded: text_helper
INFO - 2024-04-20 08:48:56 --> Helper loaded: form_helper
INFO - 2024-04-20 08:48:56 --> Helper loaded: lang_helper
INFO - 2024-04-20 08:48:56 --> Helper loaded: security_helper
INFO - 2024-04-20 08:48:56 --> Helper loaded: cookie_helper
INFO - 2024-04-20 08:48:56 --> Database Driver Class Initialized
INFO - 2024-04-20 08:48:56 --> Session: Class initialized using 'files' driver.
INFO - 2024-04-20 08:48:56 --> Parser Class Initialized
INFO - 2024-04-20 08:48:56 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-04-20 08:48:56 --> Pagination Class Initialized
INFO - 2024-04-20 08:48:56 --> Form Validation Class Initialized
INFO - 2024-04-20 08:48:56 --> Controller Class Initialized
INFO - 2024-04-20 08:48:56 --> Model Class Initialized
INFO - 2024-04-20 08:48:56 --> Model Class Initialized
INFO - 2024-04-20 08:48:56 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/report/stock_report.php
DEBUG - 2024-04-20 08:48:56 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-04-20 08:48:56 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-04-20 08:48:56 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-04-20 08:48:56 --> Model Class Initialized
INFO - 2024-04-20 08:48:56 --> Model Class Initialized
INFO - 2024-04-20 08:48:56 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-04-20 08:48:56 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-04-20 08:48:56 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-04-20 08:48:56 --> Final output sent to browser
DEBUG - 2024-04-20 08:48:56 --> Total execution time: 0.2865
ERROR - 2024-04-20 08:48:57 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-04-20 08:48:57 --> Config Class Initialized
INFO - 2024-04-20 08:48:57 --> Hooks Class Initialized
DEBUG - 2024-04-20 08:48:57 --> UTF-8 Support Enabled
INFO - 2024-04-20 08:48:57 --> Utf8 Class Initialized
INFO - 2024-04-20 08:48:57 --> URI Class Initialized
INFO - 2024-04-20 08:48:57 --> Router Class Initialized
INFO - 2024-04-20 08:48:57 --> Output Class Initialized
INFO - 2024-04-20 08:48:57 --> Security Class Initialized
DEBUG - 2024-04-20 08:48:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-04-20 08:48:57 --> Input Class Initialized
INFO - 2024-04-20 08:48:57 --> Language Class Initialized
INFO - 2024-04-20 08:48:57 --> Loader Class Initialized
INFO - 2024-04-20 08:48:57 --> Helper loaded: url_helper
INFO - 2024-04-20 08:48:57 --> Helper loaded: file_helper
INFO - 2024-04-20 08:48:57 --> Helper loaded: html_helper
INFO - 2024-04-20 08:48:57 --> Helper loaded: text_helper
INFO - 2024-04-20 08:48:57 --> Helper loaded: form_helper
INFO - 2024-04-20 08:48:57 --> Helper loaded: lang_helper
INFO - 2024-04-20 08:48:57 --> Helper loaded: security_helper
INFO - 2024-04-20 08:48:57 --> Helper loaded: cookie_helper
INFO - 2024-04-20 08:48:57 --> Database Driver Class Initialized
INFO - 2024-04-20 08:48:57 --> Session: Class initialized using 'files' driver.
INFO - 2024-04-20 08:48:57 --> Parser Class Initialized
INFO - 2024-04-20 08:48:57 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-04-20 08:48:57 --> Pagination Class Initialized
INFO - 2024-04-20 08:48:57 --> Form Validation Class Initialized
INFO - 2024-04-20 08:48:57 --> Controller Class Initialized
INFO - 2024-04-20 08:48:57 --> Model Class Initialized
INFO - 2024-04-20 08:48:57 --> Model Class Initialized
INFO - 2024-04-20 08:48:57 --> Final output sent to browser
DEBUG - 2024-04-20 08:48:57 --> Total execution time: 0.0296
ERROR - 2024-04-20 08:49:25 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-04-20 08:49:25 --> Config Class Initialized
INFO - 2024-04-20 08:49:25 --> Hooks Class Initialized
DEBUG - 2024-04-20 08:49:25 --> UTF-8 Support Enabled
INFO - 2024-04-20 08:49:25 --> Utf8 Class Initialized
INFO - 2024-04-20 08:49:25 --> URI Class Initialized
INFO - 2024-04-20 08:49:25 --> Router Class Initialized
INFO - 2024-04-20 08:49:25 --> Output Class Initialized
INFO - 2024-04-20 08:49:25 --> Security Class Initialized
DEBUG - 2024-04-20 08:49:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-04-20 08:49:25 --> Input Class Initialized
INFO - 2024-04-20 08:49:25 --> Language Class Initialized
INFO - 2024-04-20 08:49:25 --> Loader Class Initialized
INFO - 2024-04-20 08:49:25 --> Helper loaded: url_helper
INFO - 2024-04-20 08:49:25 --> Helper loaded: file_helper
INFO - 2024-04-20 08:49:25 --> Helper loaded: html_helper
INFO - 2024-04-20 08:49:25 --> Helper loaded: text_helper
INFO - 2024-04-20 08:49:25 --> Helper loaded: form_helper
INFO - 2024-04-20 08:49:25 --> Helper loaded: lang_helper
INFO - 2024-04-20 08:49:25 --> Helper loaded: security_helper
INFO - 2024-04-20 08:49:25 --> Helper loaded: cookie_helper
INFO - 2024-04-20 08:49:25 --> Database Driver Class Initialized
INFO - 2024-04-20 08:49:25 --> Session: Class initialized using 'files' driver.
INFO - 2024-04-20 08:49:25 --> Parser Class Initialized
INFO - 2024-04-20 08:49:25 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-04-20 08:49:25 --> Pagination Class Initialized
INFO - 2024-04-20 08:49:25 --> Form Validation Class Initialized
INFO - 2024-04-20 08:49:25 --> Controller Class Initialized
INFO - 2024-04-20 08:49:25 --> Model Class Initialized
DEBUG - 2024-04-20 08:49:25 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-04-20 08:49:25 --> Session class already loaded. Second attempt ignored.
INFO - 2024-04-20 08:49:25 --> Model Class Initialized
INFO - 2024-04-20 08:49:25 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/stockrequest/stockrequest.php
DEBUG - 2024-04-20 08:49:25 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-04-20 08:49:25 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-04-20 08:49:25 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-04-20 08:49:25 --> Model Class Initialized
INFO - 2024-04-20 08:49:25 --> Model Class Initialized
INFO - 2024-04-20 08:49:25 --> Model Class Initialized
INFO - 2024-04-20 08:49:25 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-04-20 08:49:25 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-04-20 08:49:25 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-04-20 08:49:25 --> Final output sent to browser
DEBUG - 2024-04-20 08:49:25 --> Total execution time: 0.3138
ERROR - 2024-04-20 08:49:25 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-04-20 08:49:25 --> Config Class Initialized
INFO - 2024-04-20 08:49:25 --> Hooks Class Initialized
DEBUG - 2024-04-20 08:49:25 --> UTF-8 Support Enabled
INFO - 2024-04-20 08:49:25 --> Utf8 Class Initialized
INFO - 2024-04-20 08:49:25 --> URI Class Initialized
INFO - 2024-04-20 08:49:25 --> Router Class Initialized
INFO - 2024-04-20 08:49:25 --> Output Class Initialized
INFO - 2024-04-20 08:49:25 --> Security Class Initialized
DEBUG - 2024-04-20 08:49:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-04-20 08:49:25 --> Input Class Initialized
INFO - 2024-04-20 08:49:25 --> Language Class Initialized
INFO - 2024-04-20 08:49:25 --> Loader Class Initialized
INFO - 2024-04-20 08:49:25 --> Helper loaded: url_helper
INFO - 2024-04-20 08:49:25 --> Helper loaded: file_helper
INFO - 2024-04-20 08:49:25 --> Helper loaded: html_helper
INFO - 2024-04-20 08:49:25 --> Helper loaded: text_helper
INFO - 2024-04-20 08:49:26 --> Helper loaded: form_helper
INFO - 2024-04-20 08:49:26 --> Helper loaded: lang_helper
INFO - 2024-04-20 08:49:26 --> Helper loaded: security_helper
INFO - 2024-04-20 08:49:26 --> Helper loaded: cookie_helper
INFO - 2024-04-20 08:49:26 --> Database Driver Class Initialized
INFO - 2024-04-20 08:49:26 --> Session: Class initialized using 'files' driver.
INFO - 2024-04-20 08:49:26 --> Parser Class Initialized
INFO - 2024-04-20 08:49:26 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-04-20 08:49:26 --> Pagination Class Initialized
INFO - 2024-04-20 08:49:26 --> Form Validation Class Initialized
INFO - 2024-04-20 08:49:26 --> Controller Class Initialized
INFO - 2024-04-20 08:49:26 --> Model Class Initialized
DEBUG - 2024-04-20 08:49:26 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-04-20 08:49:26 --> Session class already loaded. Second attempt ignored.
INFO - 2024-04-20 08:49:26 --> Model Class Initialized
INFO - 2024-04-20 08:49:26 --> Final output sent to browser
DEBUG - 2024-04-20 08:49:26 --> Total execution time: 0.0277
ERROR - 2024-04-20 08:49:56 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-04-20 08:49:56 --> Config Class Initialized
INFO - 2024-04-20 08:49:56 --> Hooks Class Initialized
DEBUG - 2024-04-20 08:49:56 --> UTF-8 Support Enabled
INFO - 2024-04-20 08:49:56 --> Utf8 Class Initialized
INFO - 2024-04-20 08:49:56 --> URI Class Initialized
INFO - 2024-04-20 08:49:56 --> Router Class Initialized
INFO - 2024-04-20 08:49:56 --> Output Class Initialized
INFO - 2024-04-20 08:49:56 --> Security Class Initialized
DEBUG - 2024-04-20 08:49:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-04-20 08:49:56 --> Input Class Initialized
INFO - 2024-04-20 08:49:56 --> Language Class Initialized
INFO - 2024-04-20 08:49:56 --> Loader Class Initialized
INFO - 2024-04-20 08:49:56 --> Helper loaded: url_helper
INFO - 2024-04-20 08:49:56 --> Helper loaded: file_helper
INFO - 2024-04-20 08:49:56 --> Helper loaded: html_helper
INFO - 2024-04-20 08:49:56 --> Helper loaded: text_helper
INFO - 2024-04-20 08:49:56 --> Helper loaded: form_helper
INFO - 2024-04-20 08:49:56 --> Helper loaded: lang_helper
INFO - 2024-04-20 08:49:56 --> Helper loaded: security_helper
INFO - 2024-04-20 08:49:56 --> Helper loaded: cookie_helper
INFO - 2024-04-20 08:49:56 --> Database Driver Class Initialized
INFO - 2024-04-20 08:49:56 --> Session: Class initialized using 'files' driver.
INFO - 2024-04-20 08:49:56 --> Parser Class Initialized
INFO - 2024-04-20 08:49:56 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-04-20 08:49:56 --> Pagination Class Initialized
INFO - 2024-04-20 08:49:56 --> Form Validation Class Initialized
INFO - 2024-04-20 08:49:56 --> Controller Class Initialized
INFO - 2024-04-20 08:49:56 --> Model Class Initialized
INFO - 2024-04-20 08:49:56 --> Model Class Initialized
INFO - 2024-04-20 08:49:56 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/report/stock_report.php
DEBUG - 2024-04-20 08:49:56 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-04-20 08:49:56 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-04-20 08:49:56 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-04-20 08:49:56 --> Model Class Initialized
INFO - 2024-04-20 08:49:56 --> Model Class Initialized
INFO - 2024-04-20 08:49:57 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-04-20 08:49:57 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-04-20 08:49:57 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-04-20 08:49:57 --> Final output sent to browser
DEBUG - 2024-04-20 08:49:57 --> Total execution time: 0.3029
ERROR - 2024-04-20 08:49:57 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-04-20 08:49:57 --> Config Class Initialized
INFO - 2024-04-20 08:49:57 --> Hooks Class Initialized
DEBUG - 2024-04-20 08:49:57 --> UTF-8 Support Enabled
INFO - 2024-04-20 08:49:57 --> Utf8 Class Initialized
INFO - 2024-04-20 08:49:57 --> URI Class Initialized
INFO - 2024-04-20 08:49:57 --> Router Class Initialized
INFO - 2024-04-20 08:49:57 --> Output Class Initialized
INFO - 2024-04-20 08:49:57 --> Security Class Initialized
DEBUG - 2024-04-20 08:49:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-04-20 08:49:57 --> Input Class Initialized
INFO - 2024-04-20 08:49:57 --> Language Class Initialized
INFO - 2024-04-20 08:49:57 --> Loader Class Initialized
INFO - 2024-04-20 08:49:57 --> Helper loaded: url_helper
INFO - 2024-04-20 08:49:57 --> Helper loaded: file_helper
INFO - 2024-04-20 08:49:57 --> Helper loaded: html_helper
INFO - 2024-04-20 08:49:57 --> Helper loaded: text_helper
INFO - 2024-04-20 08:49:57 --> Helper loaded: form_helper
INFO - 2024-04-20 08:49:57 --> Helper loaded: lang_helper
INFO - 2024-04-20 08:49:57 --> Helper loaded: security_helper
INFO - 2024-04-20 08:49:57 --> Helper loaded: cookie_helper
INFO - 2024-04-20 08:49:57 --> Database Driver Class Initialized
INFO - 2024-04-20 08:49:57 --> Session: Class initialized using 'files' driver.
INFO - 2024-04-20 08:49:57 --> Parser Class Initialized
INFO - 2024-04-20 08:49:57 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-04-20 08:49:57 --> Pagination Class Initialized
INFO - 2024-04-20 08:49:57 --> Form Validation Class Initialized
INFO - 2024-04-20 08:49:57 --> Controller Class Initialized
INFO - 2024-04-20 08:49:57 --> Model Class Initialized
INFO - 2024-04-20 08:49:57 --> Model Class Initialized
INFO - 2024-04-20 08:49:57 --> Final output sent to browser
DEBUG - 2024-04-20 08:49:57 --> Total execution time: 0.0379
ERROR - 2024-04-20 08:50:08 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-04-20 08:50:08 --> Config Class Initialized
INFO - 2024-04-20 08:50:08 --> Hooks Class Initialized
DEBUG - 2024-04-20 08:50:08 --> UTF-8 Support Enabled
INFO - 2024-04-20 08:50:08 --> Utf8 Class Initialized
INFO - 2024-04-20 08:50:08 --> URI Class Initialized
INFO - 2024-04-20 08:50:08 --> Router Class Initialized
INFO - 2024-04-20 08:50:08 --> Output Class Initialized
INFO - 2024-04-20 08:50:08 --> Security Class Initialized
DEBUG - 2024-04-20 08:50:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-04-20 08:50:08 --> Input Class Initialized
INFO - 2024-04-20 08:50:08 --> Language Class Initialized
INFO - 2024-04-20 08:50:08 --> Loader Class Initialized
INFO - 2024-04-20 08:50:08 --> Helper loaded: url_helper
INFO - 2024-04-20 08:50:08 --> Helper loaded: file_helper
INFO - 2024-04-20 08:50:08 --> Helper loaded: html_helper
INFO - 2024-04-20 08:50:08 --> Helper loaded: text_helper
INFO - 2024-04-20 08:50:08 --> Helper loaded: form_helper
INFO - 2024-04-20 08:50:08 --> Helper loaded: lang_helper
INFO - 2024-04-20 08:50:08 --> Helper loaded: security_helper
INFO - 2024-04-20 08:50:08 --> Helper loaded: cookie_helper
INFO - 2024-04-20 08:50:08 --> Database Driver Class Initialized
INFO - 2024-04-20 08:50:08 --> Session: Class initialized using 'files' driver.
INFO - 2024-04-20 08:50:08 --> Parser Class Initialized
INFO - 2024-04-20 08:50:08 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-04-20 08:50:08 --> Pagination Class Initialized
INFO - 2024-04-20 08:50:08 --> Form Validation Class Initialized
INFO - 2024-04-20 08:50:08 --> Controller Class Initialized
INFO - 2024-04-20 08:50:08 --> Model Class Initialized
INFO - 2024-04-20 08:50:08 --> Model Class Initialized
INFO - 2024-04-20 08:50:08 --> Final output sent to browser
DEBUG - 2024-04-20 08:50:08 --> Total execution time: 0.0614
ERROR - 2024-04-20 08:50:17 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-04-20 08:50:17 --> Config Class Initialized
INFO - 2024-04-20 08:50:17 --> Hooks Class Initialized
DEBUG - 2024-04-20 08:50:17 --> UTF-8 Support Enabled
INFO - 2024-04-20 08:50:17 --> Utf8 Class Initialized
INFO - 2024-04-20 08:50:17 --> URI Class Initialized
INFO - 2024-04-20 08:50:17 --> Router Class Initialized
INFO - 2024-04-20 08:50:17 --> Output Class Initialized
INFO - 2024-04-20 08:50:17 --> Security Class Initialized
DEBUG - 2024-04-20 08:50:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-04-20 08:50:17 --> Input Class Initialized
INFO - 2024-04-20 08:50:17 --> Language Class Initialized
INFO - 2024-04-20 08:50:17 --> Loader Class Initialized
INFO - 2024-04-20 08:50:17 --> Helper loaded: url_helper
INFO - 2024-04-20 08:50:17 --> Helper loaded: file_helper
INFO - 2024-04-20 08:50:17 --> Helper loaded: html_helper
INFO - 2024-04-20 08:50:17 --> Helper loaded: text_helper
INFO - 2024-04-20 08:50:17 --> Helper loaded: form_helper
INFO - 2024-04-20 08:50:17 --> Helper loaded: lang_helper
INFO - 2024-04-20 08:50:17 --> Helper loaded: security_helper
INFO - 2024-04-20 08:50:17 --> Helper loaded: cookie_helper
INFO - 2024-04-20 08:50:17 --> Database Driver Class Initialized
INFO - 2024-04-20 08:50:17 --> Session: Class initialized using 'files' driver.
INFO - 2024-04-20 08:50:17 --> Parser Class Initialized
INFO - 2024-04-20 08:50:17 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-04-20 08:50:17 --> Pagination Class Initialized
INFO - 2024-04-20 08:50:17 --> Form Validation Class Initialized
INFO - 2024-04-20 08:50:17 --> Controller Class Initialized
INFO - 2024-04-20 08:50:17 --> Model Class Initialized
DEBUG - 2024-04-20 08:50:17 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-04-20 08:50:17 --> Session class already loaded. Second attempt ignored.
INFO - 2024-04-20 08:50:17 --> Model Class Initialized
INFO - 2024-04-20 08:50:17 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/stockrequest/stockrequest.php
DEBUG - 2024-04-20 08:50:17 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-04-20 08:50:17 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-04-20 08:50:17 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-04-20 08:50:17 --> Model Class Initialized
INFO - 2024-04-20 08:50:17 --> Model Class Initialized
INFO - 2024-04-20 08:50:17 --> Model Class Initialized
INFO - 2024-04-20 08:50:17 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-04-20 08:50:17 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-04-20 08:50:17 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-04-20 08:50:17 --> Final output sent to browser
DEBUG - 2024-04-20 08:50:17 --> Total execution time: 0.2907
ERROR - 2024-04-20 08:50:18 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-04-20 08:50:18 --> Config Class Initialized
INFO - 2024-04-20 08:50:18 --> Hooks Class Initialized
DEBUG - 2024-04-20 08:50:18 --> UTF-8 Support Enabled
INFO - 2024-04-20 08:50:18 --> Utf8 Class Initialized
INFO - 2024-04-20 08:50:18 --> URI Class Initialized
INFO - 2024-04-20 08:50:18 --> Router Class Initialized
INFO - 2024-04-20 08:50:18 --> Output Class Initialized
INFO - 2024-04-20 08:50:18 --> Security Class Initialized
DEBUG - 2024-04-20 08:50:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-04-20 08:50:18 --> Input Class Initialized
INFO - 2024-04-20 08:50:18 --> Language Class Initialized
INFO - 2024-04-20 08:50:18 --> Loader Class Initialized
INFO - 2024-04-20 08:50:18 --> Helper loaded: url_helper
INFO - 2024-04-20 08:50:18 --> Helper loaded: file_helper
INFO - 2024-04-20 08:50:18 --> Helper loaded: html_helper
INFO - 2024-04-20 08:50:18 --> Helper loaded: text_helper
INFO - 2024-04-20 08:50:18 --> Helper loaded: form_helper
INFO - 2024-04-20 08:50:18 --> Helper loaded: lang_helper
INFO - 2024-04-20 08:50:18 --> Helper loaded: security_helper
INFO - 2024-04-20 08:50:18 --> Helper loaded: cookie_helper
INFO - 2024-04-20 08:50:18 --> Database Driver Class Initialized
INFO - 2024-04-20 08:50:18 --> Session: Class initialized using 'files' driver.
INFO - 2024-04-20 08:50:18 --> Parser Class Initialized
INFO - 2024-04-20 08:50:18 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-04-20 08:50:18 --> Pagination Class Initialized
INFO - 2024-04-20 08:50:18 --> Form Validation Class Initialized
INFO - 2024-04-20 08:50:18 --> Controller Class Initialized
INFO - 2024-04-20 08:50:18 --> Model Class Initialized
DEBUG - 2024-04-20 08:50:18 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-04-20 08:50:18 --> Session class already loaded. Second attempt ignored.
INFO - 2024-04-20 08:50:18 --> Model Class Initialized
INFO - 2024-04-20 08:50:18 --> Final output sent to browser
DEBUG - 2024-04-20 08:50:18 --> Total execution time: 0.0331
ERROR - 2024-04-20 08:50:32 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-04-20 08:50:32 --> Config Class Initialized
INFO - 2024-04-20 08:50:32 --> Hooks Class Initialized
DEBUG - 2024-04-20 08:50:32 --> UTF-8 Support Enabled
INFO - 2024-04-20 08:50:32 --> Utf8 Class Initialized
INFO - 2024-04-20 08:50:32 --> URI Class Initialized
INFO - 2024-04-20 08:50:32 --> Router Class Initialized
INFO - 2024-04-20 08:50:32 --> Output Class Initialized
INFO - 2024-04-20 08:50:32 --> Security Class Initialized
DEBUG - 2024-04-20 08:50:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-04-20 08:50:32 --> Input Class Initialized
INFO - 2024-04-20 08:50:32 --> Language Class Initialized
INFO - 2024-04-20 08:50:32 --> Loader Class Initialized
INFO - 2024-04-20 08:50:32 --> Helper loaded: url_helper
INFO - 2024-04-20 08:50:32 --> Helper loaded: file_helper
INFO - 2024-04-20 08:50:32 --> Helper loaded: html_helper
INFO - 2024-04-20 08:50:32 --> Helper loaded: text_helper
INFO - 2024-04-20 08:50:32 --> Helper loaded: form_helper
INFO - 2024-04-20 08:50:32 --> Helper loaded: lang_helper
INFO - 2024-04-20 08:50:32 --> Helper loaded: security_helper
INFO - 2024-04-20 08:50:32 --> Helper loaded: cookie_helper
INFO - 2024-04-20 08:50:32 --> Database Driver Class Initialized
INFO - 2024-04-20 08:50:32 --> Session: Class initialized using 'files' driver.
INFO - 2024-04-20 08:50:32 --> Parser Class Initialized
INFO - 2024-04-20 08:50:32 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-04-20 08:50:32 --> Pagination Class Initialized
INFO - 2024-04-20 08:50:32 --> Form Validation Class Initialized
INFO - 2024-04-20 08:50:32 --> Controller Class Initialized
INFO - 2024-04-20 08:50:32 --> Model Class Initialized
INFO - 2024-04-20 08:50:32 --> Model Class Initialized
INFO - 2024-04-20 08:50:32 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/purchase/purchase.php
DEBUG - 2024-04-20 08:50:32 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-04-20 08:50:32 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-04-20 08:50:32 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-04-20 08:50:32 --> Model Class Initialized
INFO - 2024-04-20 08:50:32 --> Model Class Initialized
INFO - 2024-04-20 08:50:32 --> Model Class Initialized
INFO - 2024-04-20 08:50:32 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-04-20 08:50:32 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-04-20 08:50:32 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-04-20 08:50:32 --> Final output sent to browser
DEBUG - 2024-04-20 08:50:32 --> Total execution time: 0.2785
ERROR - 2024-04-20 08:50:33 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-04-20 08:50:33 --> Config Class Initialized
INFO - 2024-04-20 08:50:33 --> Hooks Class Initialized
DEBUG - 2024-04-20 08:50:33 --> UTF-8 Support Enabled
INFO - 2024-04-20 08:50:33 --> Utf8 Class Initialized
INFO - 2024-04-20 08:50:33 --> URI Class Initialized
INFO - 2024-04-20 08:50:33 --> Router Class Initialized
INFO - 2024-04-20 08:50:33 --> Output Class Initialized
INFO - 2024-04-20 08:50:33 --> Security Class Initialized
DEBUG - 2024-04-20 08:50:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-04-20 08:50:33 --> Input Class Initialized
INFO - 2024-04-20 08:50:33 --> Language Class Initialized
INFO - 2024-04-20 08:50:33 --> Loader Class Initialized
INFO - 2024-04-20 08:50:33 --> Helper loaded: url_helper
INFO - 2024-04-20 08:50:33 --> Helper loaded: file_helper
INFO - 2024-04-20 08:50:33 --> Helper loaded: html_helper
INFO - 2024-04-20 08:50:33 --> Helper loaded: text_helper
INFO - 2024-04-20 08:50:33 --> Helper loaded: form_helper
INFO - 2024-04-20 08:50:33 --> Helper loaded: lang_helper
INFO - 2024-04-20 08:50:33 --> Helper loaded: security_helper
INFO - 2024-04-20 08:50:33 --> Helper loaded: cookie_helper
INFO - 2024-04-20 08:50:33 --> Database Driver Class Initialized
INFO - 2024-04-20 08:50:33 --> Session: Class initialized using 'files' driver.
INFO - 2024-04-20 08:50:33 --> Parser Class Initialized
INFO - 2024-04-20 08:50:33 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-04-20 08:50:33 --> Pagination Class Initialized
INFO - 2024-04-20 08:50:33 --> Form Validation Class Initialized
INFO - 2024-04-20 08:50:33 --> Controller Class Initialized
INFO - 2024-04-20 08:50:33 --> Model Class Initialized
INFO - 2024-04-20 08:50:33 --> Model Class Initialized
INFO - 2024-04-20 08:50:33 --> Final output sent to browser
DEBUG - 2024-04-20 08:50:33 --> Total execution time: 0.0553
ERROR - 2024-04-20 08:50:39 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-04-20 08:50:39 --> Config Class Initialized
INFO - 2024-04-20 08:50:39 --> Hooks Class Initialized
DEBUG - 2024-04-20 08:50:39 --> UTF-8 Support Enabled
INFO - 2024-04-20 08:50:39 --> Utf8 Class Initialized
INFO - 2024-04-20 08:50:39 --> URI Class Initialized
INFO - 2024-04-20 08:50:39 --> Router Class Initialized
INFO - 2024-04-20 08:50:39 --> Output Class Initialized
INFO - 2024-04-20 08:50:39 --> Security Class Initialized
DEBUG - 2024-04-20 08:50:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-04-20 08:50:39 --> Input Class Initialized
INFO - 2024-04-20 08:50:39 --> Language Class Initialized
INFO - 2024-04-20 08:50:39 --> Loader Class Initialized
INFO - 2024-04-20 08:50:39 --> Helper loaded: url_helper
INFO - 2024-04-20 08:50:39 --> Helper loaded: file_helper
INFO - 2024-04-20 08:50:39 --> Helper loaded: html_helper
INFO - 2024-04-20 08:50:39 --> Helper loaded: text_helper
INFO - 2024-04-20 08:50:39 --> Helper loaded: form_helper
INFO - 2024-04-20 08:50:39 --> Helper loaded: lang_helper
INFO - 2024-04-20 08:50:39 --> Helper loaded: security_helper
INFO - 2024-04-20 08:50:39 --> Helper loaded: cookie_helper
INFO - 2024-04-20 08:50:39 --> Database Driver Class Initialized
INFO - 2024-04-20 08:50:39 --> Session: Class initialized using 'files' driver.
INFO - 2024-04-20 08:50:39 --> Parser Class Initialized
INFO - 2024-04-20 08:50:39 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-04-20 08:50:39 --> Pagination Class Initialized
INFO - 2024-04-20 08:50:39 --> Form Validation Class Initialized
INFO - 2024-04-20 08:50:39 --> Controller Class Initialized
INFO - 2024-04-20 08:50:39 --> Model Class Initialized
INFO - 2024-04-20 08:50:39 --> Model Class Initialized
INFO - 2024-04-20 08:50:39 --> Model Class Initialized
INFO - 2024-04-20 08:50:39 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/report/stock_report_batch_wise.php
DEBUG - 2024-04-20 08:50:39 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-04-20 08:50:39 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-04-20 08:50:39 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-04-20 08:50:39 --> Model Class Initialized
INFO - 2024-04-20 08:50:39 --> Model Class Initialized
INFO - 2024-04-20 08:50:39 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-04-20 08:50:39 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-04-20 08:50:39 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-04-20 08:50:39 --> Final output sent to browser
DEBUG - 2024-04-20 08:50:39 --> Total execution time: 0.2892
ERROR - 2024-04-20 08:50:40 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-04-20 08:50:40 --> Config Class Initialized
INFO - 2024-04-20 08:50:40 --> Hooks Class Initialized
DEBUG - 2024-04-20 08:50:40 --> UTF-8 Support Enabled
INFO - 2024-04-20 08:50:40 --> Utf8 Class Initialized
INFO - 2024-04-20 08:50:40 --> URI Class Initialized
INFO - 2024-04-20 08:50:40 --> Router Class Initialized
INFO - 2024-04-20 08:50:40 --> Output Class Initialized
INFO - 2024-04-20 08:50:40 --> Security Class Initialized
DEBUG - 2024-04-20 08:50:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-04-20 08:50:40 --> Input Class Initialized
INFO - 2024-04-20 08:50:40 --> Language Class Initialized
INFO - 2024-04-20 08:50:40 --> Loader Class Initialized
INFO - 2024-04-20 08:50:40 --> Helper loaded: url_helper
INFO - 2024-04-20 08:50:40 --> Helper loaded: file_helper
INFO - 2024-04-20 08:50:40 --> Helper loaded: html_helper
INFO - 2024-04-20 08:50:40 --> Helper loaded: text_helper
INFO - 2024-04-20 08:50:40 --> Helper loaded: form_helper
INFO - 2024-04-20 08:50:40 --> Helper loaded: lang_helper
INFO - 2024-04-20 08:50:40 --> Helper loaded: security_helper
INFO - 2024-04-20 08:50:40 --> Helper loaded: cookie_helper
INFO - 2024-04-20 08:50:40 --> Database Driver Class Initialized
INFO - 2024-04-20 08:50:40 --> Session: Class initialized using 'files' driver.
INFO - 2024-04-20 08:50:40 --> Parser Class Initialized
INFO - 2024-04-20 08:50:40 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-04-20 08:50:40 --> Pagination Class Initialized
INFO - 2024-04-20 08:50:40 --> Form Validation Class Initialized
INFO - 2024-04-20 08:50:40 --> Controller Class Initialized
INFO - 2024-04-20 08:50:40 --> Model Class Initialized
INFO - 2024-04-20 08:50:40 --> Model Class Initialized
INFO - 2024-04-20 08:50:40 --> Final output sent to browser
DEBUG - 2024-04-20 08:50:40 --> Total execution time: 0.0331
ERROR - 2024-04-20 09:04:11 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-04-20 09:04:11 --> Config Class Initialized
INFO - 2024-04-20 09:04:11 --> Hooks Class Initialized
DEBUG - 2024-04-20 09:04:11 --> UTF-8 Support Enabled
INFO - 2024-04-20 09:04:11 --> Utf8 Class Initialized
INFO - 2024-04-20 09:04:11 --> URI Class Initialized
DEBUG - 2024-04-20 09:04:11 --> No URI present. Default controller set.
INFO - 2024-04-20 09:04:11 --> Router Class Initialized
INFO - 2024-04-20 09:04:11 --> Output Class Initialized
INFO - 2024-04-20 09:04:11 --> Security Class Initialized
DEBUG - 2024-04-20 09:04:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-04-20 09:04:11 --> Input Class Initialized
INFO - 2024-04-20 09:04:11 --> Language Class Initialized
INFO - 2024-04-20 09:04:11 --> Loader Class Initialized
INFO - 2024-04-20 09:04:11 --> Helper loaded: url_helper
INFO - 2024-04-20 09:04:11 --> Helper loaded: file_helper
INFO - 2024-04-20 09:04:11 --> Helper loaded: html_helper
INFO - 2024-04-20 09:04:11 --> Helper loaded: text_helper
INFO - 2024-04-20 09:04:11 --> Helper loaded: form_helper
INFO - 2024-04-20 09:04:11 --> Helper loaded: lang_helper
INFO - 2024-04-20 09:04:11 --> Helper loaded: security_helper
INFO - 2024-04-20 09:04:11 --> Helper loaded: cookie_helper
INFO - 2024-04-20 09:04:11 --> Database Driver Class Initialized
INFO - 2024-04-20 09:04:11 --> Session: Class initialized using 'files' driver.
INFO - 2024-04-20 09:04:11 --> Parser Class Initialized
INFO - 2024-04-20 09:04:11 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-04-20 09:04:11 --> Pagination Class Initialized
INFO - 2024-04-20 09:04:11 --> Form Validation Class Initialized
INFO - 2024-04-20 09:04:11 --> Controller Class Initialized
INFO - 2024-04-20 09:04:11 --> Model Class Initialized
DEBUG - 2024-04-20 09:04:11 --> Session class already loaded. Second attempt ignored.
ERROR - 2024-04-20 09:04:11 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-04-20 09:04:11 --> Config Class Initialized
INFO - 2024-04-20 09:04:11 --> Hooks Class Initialized
DEBUG - 2024-04-20 09:04:11 --> UTF-8 Support Enabled
INFO - 2024-04-20 09:04:11 --> Utf8 Class Initialized
INFO - 2024-04-20 09:04:11 --> URI Class Initialized
INFO - 2024-04-20 09:04:11 --> Router Class Initialized
INFO - 2024-04-20 09:04:11 --> Output Class Initialized
INFO - 2024-04-20 09:04:11 --> Security Class Initialized
DEBUG - 2024-04-20 09:04:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-04-20 09:04:11 --> Input Class Initialized
INFO - 2024-04-20 09:04:11 --> Language Class Initialized
INFO - 2024-04-20 09:04:11 --> Loader Class Initialized
INFO - 2024-04-20 09:04:11 --> Helper loaded: url_helper
INFO - 2024-04-20 09:04:11 --> Helper loaded: file_helper
INFO - 2024-04-20 09:04:11 --> Helper loaded: html_helper
INFO - 2024-04-20 09:04:11 --> Helper loaded: text_helper
INFO - 2024-04-20 09:04:11 --> Helper loaded: form_helper
INFO - 2024-04-20 09:04:11 --> Helper loaded: lang_helper
INFO - 2024-04-20 09:04:11 --> Helper loaded: security_helper
INFO - 2024-04-20 09:04:11 --> Helper loaded: cookie_helper
INFO - 2024-04-20 09:04:11 --> Database Driver Class Initialized
INFO - 2024-04-20 09:04:11 --> Session: Class initialized using 'files' driver.
INFO - 2024-04-20 09:04:11 --> Parser Class Initialized
INFO - 2024-04-20 09:04:11 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-04-20 09:04:11 --> Pagination Class Initialized
INFO - 2024-04-20 09:04:11 --> Form Validation Class Initialized
INFO - 2024-04-20 09:04:11 --> Controller Class Initialized
INFO - 2024-04-20 09:04:11 --> Model Class Initialized
DEBUG - 2024-04-20 09:04:11 --> Session class already loaded. Second attempt ignored.
INFO - 2024-04-20 09:04:11 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2024-04-20 09:04:11 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-04-20 09:04:11 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-04-20 09:04:11 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-04-20 09:04:11 --> Model Class Initialized
INFO - 2024-04-20 09:04:11 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-04-20 09:04:11 --> Final output sent to browser
DEBUG - 2024-04-20 09:04:11 --> Total execution time: 0.0303
ERROR - 2024-04-20 09:04:18 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-04-20 09:04:18 --> Config Class Initialized
INFO - 2024-04-20 09:04:18 --> Hooks Class Initialized
DEBUG - 2024-04-20 09:04:18 --> UTF-8 Support Enabled
INFO - 2024-04-20 09:04:18 --> Utf8 Class Initialized
INFO - 2024-04-20 09:04:18 --> URI Class Initialized
DEBUG - 2024-04-20 09:04:18 --> No URI present. Default controller set.
INFO - 2024-04-20 09:04:18 --> Router Class Initialized
INFO - 2024-04-20 09:04:18 --> Output Class Initialized
INFO - 2024-04-20 09:04:18 --> Security Class Initialized
DEBUG - 2024-04-20 09:04:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-04-20 09:04:18 --> Input Class Initialized
INFO - 2024-04-20 09:04:18 --> Language Class Initialized
INFO - 2024-04-20 09:04:18 --> Loader Class Initialized
INFO - 2024-04-20 09:04:18 --> Helper loaded: url_helper
INFO - 2024-04-20 09:04:18 --> Helper loaded: file_helper
INFO - 2024-04-20 09:04:18 --> Helper loaded: html_helper
INFO - 2024-04-20 09:04:18 --> Helper loaded: text_helper
INFO - 2024-04-20 09:04:18 --> Helper loaded: form_helper
INFO - 2024-04-20 09:04:18 --> Helper loaded: lang_helper
INFO - 2024-04-20 09:04:18 --> Helper loaded: security_helper
INFO - 2024-04-20 09:04:18 --> Helper loaded: cookie_helper
INFO - 2024-04-20 09:04:18 --> Database Driver Class Initialized
INFO - 2024-04-20 09:04:18 --> Session: Class initialized using 'files' driver.
INFO - 2024-04-20 09:04:18 --> Parser Class Initialized
INFO - 2024-04-20 09:04:18 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-04-20 09:04:18 --> Pagination Class Initialized
INFO - 2024-04-20 09:04:18 --> Form Validation Class Initialized
INFO - 2024-04-20 09:04:18 --> Controller Class Initialized
INFO - 2024-04-20 09:04:18 --> Model Class Initialized
DEBUG - 2024-04-20 09:04:18 --> Session class already loaded. Second attempt ignored.
ERROR - 2024-04-20 09:04:20 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-04-20 09:04:20 --> Config Class Initialized
INFO - 2024-04-20 09:04:20 --> Hooks Class Initialized
DEBUG - 2024-04-20 09:04:20 --> UTF-8 Support Enabled
INFO - 2024-04-20 09:04:20 --> Utf8 Class Initialized
INFO - 2024-04-20 09:04:20 --> URI Class Initialized
INFO - 2024-04-20 09:04:20 --> Router Class Initialized
INFO - 2024-04-20 09:04:20 --> Output Class Initialized
INFO - 2024-04-20 09:04:20 --> Security Class Initialized
DEBUG - 2024-04-20 09:04:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-04-20 09:04:20 --> Input Class Initialized
INFO - 2024-04-20 09:04:20 --> Language Class Initialized
INFO - 2024-04-20 09:04:20 --> Loader Class Initialized
INFO - 2024-04-20 09:04:20 --> Helper loaded: url_helper
INFO - 2024-04-20 09:04:20 --> Helper loaded: file_helper
INFO - 2024-04-20 09:04:20 --> Helper loaded: html_helper
INFO - 2024-04-20 09:04:20 --> Helper loaded: text_helper
INFO - 2024-04-20 09:04:20 --> Helper loaded: form_helper
INFO - 2024-04-20 09:04:20 --> Helper loaded: lang_helper
INFO - 2024-04-20 09:04:20 --> Helper loaded: security_helper
INFO - 2024-04-20 09:04:20 --> Helper loaded: cookie_helper
INFO - 2024-04-20 09:04:20 --> Database Driver Class Initialized
INFO - 2024-04-20 09:04:20 --> Session: Class initialized using 'files' driver.
INFO - 2024-04-20 09:04:20 --> Parser Class Initialized
INFO - 2024-04-20 09:04:20 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-04-20 09:04:20 --> Pagination Class Initialized
INFO - 2024-04-20 09:04:20 --> Form Validation Class Initialized
INFO - 2024-04-20 09:04:20 --> Controller Class Initialized
INFO - 2024-04-20 09:04:20 --> Model Class Initialized
DEBUG - 2024-04-20 09:04:20 --> Session class already loaded. Second attempt ignored.
INFO - 2024-04-20 09:04:20 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2024-04-20 09:04:20 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-04-20 09:04:20 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-04-20 09:04:20 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-04-20 09:04:20 --> Model Class Initialized
INFO - 2024-04-20 09:04:20 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-04-20 09:04:20 --> Final output sent to browser
DEBUG - 2024-04-20 09:04:20 --> Total execution time: 0.0275
ERROR - 2024-04-20 09:04:24 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-04-20 09:04:24 --> Config Class Initialized
INFO - 2024-04-20 09:04:24 --> Hooks Class Initialized
DEBUG - 2024-04-20 09:04:24 --> UTF-8 Support Enabled
INFO - 2024-04-20 09:04:24 --> Utf8 Class Initialized
INFO - 2024-04-20 09:04:24 --> URI Class Initialized
INFO - 2024-04-20 09:04:24 --> Router Class Initialized
INFO - 2024-04-20 09:04:24 --> Output Class Initialized
INFO - 2024-04-20 09:04:24 --> Security Class Initialized
DEBUG - 2024-04-20 09:04:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-04-20 09:04:24 --> Input Class Initialized
INFO - 2024-04-20 09:04:24 --> Language Class Initialized
INFO - 2024-04-20 09:04:24 --> Loader Class Initialized
INFO - 2024-04-20 09:04:24 --> Helper loaded: url_helper
INFO - 2024-04-20 09:04:24 --> Helper loaded: file_helper
INFO - 2024-04-20 09:04:24 --> Helper loaded: html_helper
INFO - 2024-04-20 09:04:24 --> Helper loaded: text_helper
INFO - 2024-04-20 09:04:24 --> Helper loaded: form_helper
INFO - 2024-04-20 09:04:24 --> Helper loaded: lang_helper
INFO - 2024-04-20 09:04:24 --> Helper loaded: security_helper
INFO - 2024-04-20 09:04:24 --> Helper loaded: cookie_helper
INFO - 2024-04-20 09:04:24 --> Database Driver Class Initialized
INFO - 2024-04-20 09:04:24 --> Session: Class initialized using 'files' driver.
INFO - 2024-04-20 09:04:24 --> Parser Class Initialized
INFO - 2024-04-20 09:04:24 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-04-20 09:04:24 --> Pagination Class Initialized
INFO - 2024-04-20 09:04:24 --> Form Validation Class Initialized
INFO - 2024-04-20 09:04:24 --> Controller Class Initialized
INFO - 2024-04-20 09:04:24 --> Model Class Initialized
DEBUG - 2024-04-20 09:04:24 --> Session class already loaded. Second attempt ignored.
INFO - 2024-04-20 09:04:24 --> Model Class Initialized
INFO - 2024-04-20 09:04:24 --> Final output sent to browser
DEBUG - 2024-04-20 09:04:24 --> Total execution time: 0.0182
ERROR - 2024-04-20 09:04:24 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-04-20 09:04:24 --> Config Class Initialized
INFO - 2024-04-20 09:04:24 --> Hooks Class Initialized
DEBUG - 2024-04-20 09:04:24 --> UTF-8 Support Enabled
INFO - 2024-04-20 09:04:24 --> Utf8 Class Initialized
INFO - 2024-04-20 09:04:24 --> URI Class Initialized
DEBUG - 2024-04-20 09:04:24 --> No URI present. Default controller set.
INFO - 2024-04-20 09:04:24 --> Router Class Initialized
INFO - 2024-04-20 09:04:24 --> Output Class Initialized
INFO - 2024-04-20 09:04:24 --> Security Class Initialized
DEBUG - 2024-04-20 09:04:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-04-20 09:04:24 --> Input Class Initialized
INFO - 2024-04-20 09:04:24 --> Language Class Initialized
INFO - 2024-04-20 09:04:24 --> Loader Class Initialized
INFO - 2024-04-20 09:04:24 --> Helper loaded: url_helper
INFO - 2024-04-20 09:04:24 --> Helper loaded: file_helper
INFO - 2024-04-20 09:04:24 --> Helper loaded: html_helper
INFO - 2024-04-20 09:04:24 --> Helper loaded: text_helper
INFO - 2024-04-20 09:04:24 --> Helper loaded: form_helper
INFO - 2024-04-20 09:04:24 --> Helper loaded: lang_helper
INFO - 2024-04-20 09:04:24 --> Helper loaded: security_helper
INFO - 2024-04-20 09:04:24 --> Helper loaded: cookie_helper
INFO - 2024-04-20 09:04:24 --> Database Driver Class Initialized
INFO - 2024-04-20 09:04:24 --> Session: Class initialized using 'files' driver.
INFO - 2024-04-20 09:04:24 --> Parser Class Initialized
INFO - 2024-04-20 09:04:24 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-04-20 09:04:24 --> Pagination Class Initialized
INFO - 2024-04-20 09:04:24 --> Form Validation Class Initialized
INFO - 2024-04-20 09:04:24 --> Controller Class Initialized
INFO - 2024-04-20 09:04:24 --> Model Class Initialized
DEBUG - 2024-04-20 09:04:24 --> Session class already loaded. Second attempt ignored.
INFO - 2024-04-20 09:04:24 --> Model Class Initialized
DEBUG - 2024-04-20 09:04:24 --> Session class already loaded. Second attempt ignored.
INFO - 2024-04-20 09:04:24 --> Model Class Initialized
INFO - 2024-04-20 09:04:24 --> Model Class Initialized
INFO - 2024-04-20 09:04:24 --> Model Class Initialized
INFO - 2024-04-20 09:04:24 --> Model Class Initialized
DEBUG - 2024-04-20 09:04:24 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-04-20 09:04:24 --> Session class already loaded. Second attempt ignored.
INFO - 2024-04-20 09:04:24 --> Model Class Initialized
INFO - 2024-04-20 09:04:24 --> Model Class Initialized
INFO - 2024-04-20 09:04:25 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2024-04-20 09:04:25 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-04-20 09:04:25 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-04-20 09:04:25 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-04-20 09:04:25 --> Model Class Initialized
INFO - 2024-04-20 09:04:25 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-04-20 09:04:25 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-04-20 09:04:25 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-04-20 09:04:25 --> Final output sent to browser
DEBUG - 2024-04-20 09:04:25 --> Total execution time: 0.6277
ERROR - 2024-04-20 09:04:26 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-04-20 09:04:26 --> Config Class Initialized
INFO - 2024-04-20 09:04:26 --> Hooks Class Initialized
DEBUG - 2024-04-20 09:04:26 --> UTF-8 Support Enabled
INFO - 2024-04-20 09:04:26 --> Utf8 Class Initialized
INFO - 2024-04-20 09:04:26 --> URI Class Initialized
INFO - 2024-04-20 09:04:26 --> Router Class Initialized
INFO - 2024-04-20 09:04:26 --> Output Class Initialized
INFO - 2024-04-20 09:04:26 --> Security Class Initialized
DEBUG - 2024-04-20 09:04:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-04-20 09:04:26 --> Input Class Initialized
INFO - 2024-04-20 09:04:26 --> Language Class Initialized
INFO - 2024-04-20 09:04:26 --> Loader Class Initialized
INFO - 2024-04-20 09:04:26 --> Helper loaded: url_helper
INFO - 2024-04-20 09:04:26 --> Helper loaded: file_helper
INFO - 2024-04-20 09:04:26 --> Helper loaded: html_helper
INFO - 2024-04-20 09:04:26 --> Helper loaded: text_helper
INFO - 2024-04-20 09:04:26 --> Helper loaded: form_helper
INFO - 2024-04-20 09:04:26 --> Helper loaded: lang_helper
INFO - 2024-04-20 09:04:26 --> Helper loaded: security_helper
INFO - 2024-04-20 09:04:26 --> Helper loaded: cookie_helper
INFO - 2024-04-20 09:04:26 --> Database Driver Class Initialized
INFO - 2024-04-20 09:04:26 --> Session: Class initialized using 'files' driver.
INFO - 2024-04-20 09:04:26 --> Parser Class Initialized
INFO - 2024-04-20 09:04:26 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-04-20 09:04:26 --> Pagination Class Initialized
INFO - 2024-04-20 09:04:26 --> Form Validation Class Initialized
INFO - 2024-04-20 09:04:26 --> Controller Class Initialized
DEBUG - 2024-04-20 09:04:26 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-04-20 09:04:26 --> Session class already loaded. Second attempt ignored.
INFO - 2024-04-20 09:04:26 --> Model Class Initialized
INFO - 2024-04-20 09:04:26 --> Final output sent to browser
DEBUG - 2024-04-20 09:04:26 --> Total execution time: 0.0164
ERROR - 2024-04-20 09:17:37 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-04-20 09:17:37 --> Config Class Initialized
INFO - 2024-04-20 09:17:37 --> Hooks Class Initialized
DEBUG - 2024-04-20 09:17:37 --> UTF-8 Support Enabled
INFO - 2024-04-20 09:17:37 --> Utf8 Class Initialized
INFO - 2024-04-20 09:17:37 --> URI Class Initialized
DEBUG - 2024-04-20 09:17:37 --> No URI present. Default controller set.
INFO - 2024-04-20 09:17:37 --> Router Class Initialized
INFO - 2024-04-20 09:17:37 --> Output Class Initialized
INFO - 2024-04-20 09:17:37 --> Security Class Initialized
DEBUG - 2024-04-20 09:17:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-04-20 09:17:37 --> Input Class Initialized
INFO - 2024-04-20 09:17:37 --> Language Class Initialized
INFO - 2024-04-20 09:17:37 --> Loader Class Initialized
INFO - 2024-04-20 09:17:37 --> Helper loaded: url_helper
INFO - 2024-04-20 09:17:37 --> Helper loaded: file_helper
INFO - 2024-04-20 09:17:37 --> Helper loaded: html_helper
INFO - 2024-04-20 09:17:37 --> Helper loaded: text_helper
INFO - 2024-04-20 09:17:37 --> Helper loaded: form_helper
INFO - 2024-04-20 09:17:37 --> Helper loaded: lang_helper
INFO - 2024-04-20 09:17:37 --> Helper loaded: security_helper
INFO - 2024-04-20 09:17:37 --> Helper loaded: cookie_helper
INFO - 2024-04-20 09:17:37 --> Database Driver Class Initialized
INFO - 2024-04-20 09:17:37 --> Session: Class initialized using 'files' driver.
INFO - 2024-04-20 09:17:37 --> Parser Class Initialized
INFO - 2024-04-20 09:17:37 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-04-20 09:17:37 --> Pagination Class Initialized
INFO - 2024-04-20 09:17:37 --> Form Validation Class Initialized
INFO - 2024-04-20 09:17:37 --> Controller Class Initialized
INFO - 2024-04-20 09:17:37 --> Model Class Initialized
DEBUG - 2024-04-20 09:17:37 --> Session class already loaded. Second attempt ignored.
INFO - 2024-04-20 09:17:37 --> Model Class Initialized
DEBUG - 2024-04-20 09:17:37 --> Session class already loaded. Second attempt ignored.
INFO - 2024-04-20 09:17:37 --> Model Class Initialized
INFO - 2024-04-20 09:17:37 --> Model Class Initialized
INFO - 2024-04-20 09:17:37 --> Model Class Initialized
INFO - 2024-04-20 09:17:37 --> Model Class Initialized
DEBUG - 2024-04-20 09:17:37 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-04-20 09:17:37 --> Session class already loaded. Second attempt ignored.
INFO - 2024-04-20 09:17:37 --> Model Class Initialized
INFO - 2024-04-20 09:17:37 --> Model Class Initialized
INFO - 2024-04-20 09:17:37 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2024-04-20 09:17:37 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-04-20 09:17:37 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-04-20 09:17:37 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-04-20 09:17:37 --> Model Class Initialized
INFO - 2024-04-20 09:17:38 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-04-20 09:17:38 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-04-20 09:17:38 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-04-20 09:17:38 --> Final output sent to browser
DEBUG - 2024-04-20 09:17:38 --> Total execution time: 0.6416
ERROR - 2024-04-20 09:19:45 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-04-20 09:19:45 --> Config Class Initialized
INFO - 2024-04-20 09:19:45 --> Hooks Class Initialized
DEBUG - 2024-04-20 09:19:45 --> UTF-8 Support Enabled
INFO - 2024-04-20 09:19:45 --> Utf8 Class Initialized
INFO - 2024-04-20 09:19:45 --> URI Class Initialized
INFO - 2024-04-20 09:19:45 --> Router Class Initialized
INFO - 2024-04-20 09:19:45 --> Output Class Initialized
INFO - 2024-04-20 09:19:45 --> Security Class Initialized
DEBUG - 2024-04-20 09:19:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-04-20 09:19:45 --> Input Class Initialized
INFO - 2024-04-20 09:19:45 --> Language Class Initialized
INFO - 2024-04-20 09:19:45 --> Loader Class Initialized
INFO - 2024-04-20 09:19:45 --> Helper loaded: url_helper
INFO - 2024-04-20 09:19:45 --> Helper loaded: file_helper
INFO - 2024-04-20 09:19:45 --> Helper loaded: html_helper
INFO - 2024-04-20 09:19:45 --> Helper loaded: text_helper
INFO - 2024-04-20 09:19:45 --> Helper loaded: form_helper
INFO - 2024-04-20 09:19:45 --> Helper loaded: lang_helper
INFO - 2024-04-20 09:19:45 --> Helper loaded: security_helper
INFO - 2024-04-20 09:19:45 --> Helper loaded: cookie_helper
INFO - 2024-04-20 09:19:45 --> Database Driver Class Initialized
INFO - 2024-04-20 09:19:45 --> Session: Class initialized using 'files' driver.
INFO - 2024-04-20 09:19:45 --> Parser Class Initialized
INFO - 2024-04-20 09:19:45 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-04-20 09:19:45 --> Pagination Class Initialized
INFO - 2024-04-20 09:19:45 --> Form Validation Class Initialized
INFO - 2024-04-20 09:19:45 --> Controller Class Initialized
INFO - 2024-04-20 09:19:45 --> Model Class Initialized
DEBUG - 2024-04-20 09:19:45 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-04-20 09:19:45 --> Session class already loaded. Second attempt ignored.
INFO - 2024-04-20 09:19:45 --> Model Class Initialized
DEBUG - 2024-04-20 09:19:45 --> Session class already loaded. Second attempt ignored.
INFO - 2024-04-20 09:19:45 --> Model Class Initialized
INFO - 2024-04-20 09:19:45 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/invoice/invoice.php
DEBUG - 2024-04-20 09:19:45 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-04-20 09:19:45 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-04-20 09:19:45 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-04-20 09:19:45 --> Model Class Initialized
INFO - 2024-04-20 09:19:45 --> Model Class Initialized
INFO - 2024-04-20 09:19:45 --> Model Class Initialized
INFO - 2024-04-20 09:19:45 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-04-20 09:19:45 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-04-20 09:19:45 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-04-20 09:19:45 --> Final output sent to browser
DEBUG - 2024-04-20 09:19:45 --> Total execution time: 0.3112
ERROR - 2024-04-20 09:19:47 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-04-20 09:19:47 --> Config Class Initialized
INFO - 2024-04-20 09:19:47 --> Hooks Class Initialized
DEBUG - 2024-04-20 09:19:47 --> UTF-8 Support Enabled
INFO - 2024-04-20 09:19:47 --> Utf8 Class Initialized
INFO - 2024-04-20 09:19:47 --> URI Class Initialized
INFO - 2024-04-20 09:19:47 --> Router Class Initialized
INFO - 2024-04-20 09:19:47 --> Output Class Initialized
INFO - 2024-04-20 09:19:47 --> Security Class Initialized
DEBUG - 2024-04-20 09:19:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-04-20 09:19:47 --> Input Class Initialized
INFO - 2024-04-20 09:19:47 --> Language Class Initialized
INFO - 2024-04-20 09:19:47 --> Loader Class Initialized
INFO - 2024-04-20 09:19:47 --> Helper loaded: url_helper
INFO - 2024-04-20 09:19:47 --> Helper loaded: file_helper
INFO - 2024-04-20 09:19:47 --> Helper loaded: html_helper
INFO - 2024-04-20 09:19:47 --> Helper loaded: text_helper
INFO - 2024-04-20 09:19:47 --> Helper loaded: form_helper
INFO - 2024-04-20 09:19:47 --> Helper loaded: lang_helper
INFO - 2024-04-20 09:19:47 --> Helper loaded: security_helper
INFO - 2024-04-20 09:19:47 --> Helper loaded: cookie_helper
INFO - 2024-04-20 09:19:47 --> Database Driver Class Initialized
INFO - 2024-04-20 09:19:47 --> Session: Class initialized using 'files' driver.
INFO - 2024-04-20 09:19:47 --> Parser Class Initialized
INFO - 2024-04-20 09:19:47 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-04-20 09:19:47 --> Pagination Class Initialized
INFO - 2024-04-20 09:19:47 --> Form Validation Class Initialized
INFO - 2024-04-20 09:19:47 --> Controller Class Initialized
INFO - 2024-04-20 09:19:47 --> Model Class Initialized
DEBUG - 2024-04-20 09:19:47 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-04-20 09:19:47 --> Session class already loaded. Second attempt ignored.
INFO - 2024-04-20 09:19:47 --> Model Class Initialized
DEBUG - 2024-04-20 09:19:47 --> Session class already loaded. Second attempt ignored.
INFO - 2024-04-20 09:19:47 --> Model Class Initialized
INFO - 2024-04-20 09:19:47 --> Final output sent to browser
DEBUG - 2024-04-20 09:19:47 --> Total execution time: 0.0475
ERROR - 2024-04-20 09:19:48 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-04-20 09:19:48 --> Config Class Initialized
INFO - 2024-04-20 09:19:48 --> Hooks Class Initialized
DEBUG - 2024-04-20 09:19:48 --> UTF-8 Support Enabled
INFO - 2024-04-20 09:19:48 --> Utf8 Class Initialized
INFO - 2024-04-20 09:19:48 --> URI Class Initialized
INFO - 2024-04-20 09:19:48 --> Router Class Initialized
INFO - 2024-04-20 09:19:48 --> Output Class Initialized
INFO - 2024-04-20 09:19:48 --> Security Class Initialized
DEBUG - 2024-04-20 09:19:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-04-20 09:19:48 --> Input Class Initialized
INFO - 2024-04-20 09:19:48 --> Language Class Initialized
INFO - 2024-04-20 09:19:48 --> Loader Class Initialized
INFO - 2024-04-20 09:19:48 --> Helper loaded: url_helper
INFO - 2024-04-20 09:19:48 --> Helper loaded: file_helper
INFO - 2024-04-20 09:19:48 --> Helper loaded: html_helper
INFO - 2024-04-20 09:19:48 --> Helper loaded: text_helper
INFO - 2024-04-20 09:19:48 --> Helper loaded: form_helper
INFO - 2024-04-20 09:19:48 --> Helper loaded: lang_helper
INFO - 2024-04-20 09:19:48 --> Helper loaded: security_helper
INFO - 2024-04-20 09:19:48 --> Helper loaded: cookie_helper
INFO - 2024-04-20 09:19:48 --> Database Driver Class Initialized
INFO - 2024-04-20 09:19:48 --> Session: Class initialized using 'files' driver.
INFO - 2024-04-20 09:19:48 --> Parser Class Initialized
INFO - 2024-04-20 09:19:48 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-04-20 09:19:48 --> Pagination Class Initialized
INFO - 2024-04-20 09:19:48 --> Form Validation Class Initialized
INFO - 2024-04-20 09:19:48 --> Controller Class Initialized
INFO - 2024-04-20 09:19:48 --> Model Class Initialized
DEBUG - 2024-04-20 09:19:48 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-04-20 09:19:48 --> Session class already loaded. Second attempt ignored.
INFO - 2024-04-20 09:19:48 --> Model Class Initialized
DEBUG - 2024-04-20 09:19:48 --> Session class already loaded. Second attempt ignored.
INFO - 2024-04-20 09:19:48 --> Model Class Initialized
INFO - 2024-04-20 09:19:48 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/invoice/invoice_html.php
DEBUG - 2024-04-20 09:19:48 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-04-20 09:19:48 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-04-20 09:19:48 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-04-20 09:19:48 --> Model Class Initialized
INFO - 2024-04-20 09:19:48 --> Model Class Initialized
INFO - 2024-04-20 09:19:48 --> Model Class Initialized
INFO - 2024-04-20 09:19:49 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-04-20 09:19:49 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-04-20 09:19:49 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-04-20 09:19:49 --> Final output sent to browser
DEBUG - 2024-04-20 09:19:49 --> Total execution time: 0.3067
ERROR - 2024-04-20 09:20:09 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-04-20 09:20:09 --> Config Class Initialized
INFO - 2024-04-20 09:20:09 --> Hooks Class Initialized
DEBUG - 2024-04-20 09:20:09 --> UTF-8 Support Enabled
INFO - 2024-04-20 09:20:09 --> Utf8 Class Initialized
INFO - 2024-04-20 09:20:09 --> URI Class Initialized
INFO - 2024-04-20 09:20:09 --> Router Class Initialized
INFO - 2024-04-20 09:20:09 --> Output Class Initialized
INFO - 2024-04-20 09:20:09 --> Security Class Initialized
DEBUG - 2024-04-20 09:20:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-04-20 09:20:09 --> Input Class Initialized
INFO - 2024-04-20 09:20:09 --> Language Class Initialized
INFO - 2024-04-20 09:20:09 --> Loader Class Initialized
INFO - 2024-04-20 09:20:09 --> Helper loaded: url_helper
INFO - 2024-04-20 09:20:09 --> Helper loaded: file_helper
INFO - 2024-04-20 09:20:09 --> Helper loaded: html_helper
INFO - 2024-04-20 09:20:09 --> Helper loaded: text_helper
INFO - 2024-04-20 09:20:09 --> Helper loaded: form_helper
INFO - 2024-04-20 09:20:09 --> Helper loaded: lang_helper
INFO - 2024-04-20 09:20:09 --> Helper loaded: security_helper
INFO - 2024-04-20 09:20:09 --> Helper loaded: cookie_helper
INFO - 2024-04-20 09:20:09 --> Database Driver Class Initialized
INFO - 2024-04-20 09:20:09 --> Session: Class initialized using 'files' driver.
INFO - 2024-04-20 09:20:09 --> Parser Class Initialized
INFO - 2024-04-20 09:20:09 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-04-20 09:20:09 --> Pagination Class Initialized
INFO - 2024-04-20 09:20:09 --> Form Validation Class Initialized
INFO - 2024-04-20 09:20:09 --> Controller Class Initialized
INFO - 2024-04-20 09:20:09 --> Model Class Initialized
DEBUG - 2024-04-20 09:20:09 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-04-20 09:20:09 --> Session class already loaded. Second attempt ignored.
INFO - 2024-04-20 09:20:09 --> Model Class Initialized
DEBUG - 2024-04-20 09:20:09 --> Session class already loaded. Second attempt ignored.
INFO - 2024-04-20 09:20:09 --> Model Class Initialized
INFO - 2024-04-20 09:20:09 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice.php
DEBUG - 2024-04-20 09:20:09 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-04-20 09:20:09 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-04-20 09:20:09 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-04-20 09:20:09 --> Model Class Initialized
INFO - 2024-04-20 09:20:09 --> Model Class Initialized
INFO - 2024-04-20 09:20:09 --> Model Class Initialized
INFO - 2024-04-20 09:20:09 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-04-20 09:20:09 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-04-20 09:20:09 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-04-20 09:20:09 --> Final output sent to browser
DEBUG - 2024-04-20 09:20:09 --> Total execution time: 0.3293
ERROR - 2024-04-20 09:20:10 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-04-20 09:20:10 --> Config Class Initialized
INFO - 2024-04-20 09:20:10 --> Hooks Class Initialized
DEBUG - 2024-04-20 09:20:10 --> UTF-8 Support Enabled
INFO - 2024-04-20 09:20:10 --> Utf8 Class Initialized
INFO - 2024-04-20 09:20:10 --> URI Class Initialized
INFO - 2024-04-20 09:20:10 --> Router Class Initialized
INFO - 2024-04-20 09:20:10 --> Output Class Initialized
INFO - 2024-04-20 09:20:10 --> Security Class Initialized
DEBUG - 2024-04-20 09:20:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-04-20 09:20:10 --> Input Class Initialized
INFO - 2024-04-20 09:20:10 --> Language Class Initialized
INFO - 2024-04-20 09:20:10 --> Loader Class Initialized
INFO - 2024-04-20 09:20:10 --> Helper loaded: url_helper
INFO - 2024-04-20 09:20:10 --> Helper loaded: file_helper
INFO - 2024-04-20 09:20:10 --> Helper loaded: html_helper
INFO - 2024-04-20 09:20:10 --> Helper loaded: text_helper
INFO - 2024-04-20 09:20:10 --> Helper loaded: form_helper
INFO - 2024-04-20 09:20:10 --> Helper loaded: lang_helper
INFO - 2024-04-20 09:20:10 --> Helper loaded: security_helper
INFO - 2024-04-20 09:20:10 --> Helper loaded: cookie_helper
INFO - 2024-04-20 09:20:10 --> Database Driver Class Initialized
INFO - 2024-04-20 09:20:10 --> Session: Class initialized using 'files' driver.
INFO - 2024-04-20 09:20:10 --> Parser Class Initialized
INFO - 2024-04-20 09:20:10 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-04-20 09:20:10 --> Pagination Class Initialized
INFO - 2024-04-20 09:20:10 --> Form Validation Class Initialized
INFO - 2024-04-20 09:20:10 --> Controller Class Initialized
INFO - 2024-04-20 09:20:10 --> Model Class Initialized
DEBUG - 2024-04-20 09:20:10 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-04-20 09:20:10 --> Session class already loaded. Second attempt ignored.
INFO - 2024-04-20 09:20:10 --> Model Class Initialized
DEBUG - 2024-04-20 09:20:10 --> Session class already loaded. Second attempt ignored.
INFO - 2024-04-20 09:20:10 --> Model Class Initialized
INFO - 2024-04-20 09:20:10 --> Final output sent to browser
DEBUG - 2024-04-20 09:20:10 --> Total execution time: 0.0471
ERROR - 2024-04-20 09:20:12 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-04-20 09:20:12 --> Config Class Initialized
INFO - 2024-04-20 09:20:12 --> Hooks Class Initialized
DEBUG - 2024-04-20 09:20:12 --> UTF-8 Support Enabled
INFO - 2024-04-20 09:20:12 --> Utf8 Class Initialized
INFO - 2024-04-20 09:20:12 --> URI Class Initialized
INFO - 2024-04-20 09:20:12 --> Router Class Initialized
INFO - 2024-04-20 09:20:12 --> Output Class Initialized
INFO - 2024-04-20 09:20:12 --> Security Class Initialized
DEBUG - 2024-04-20 09:20:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-04-20 09:20:12 --> Input Class Initialized
INFO - 2024-04-20 09:20:12 --> Language Class Initialized
INFO - 2024-04-20 09:20:12 --> Loader Class Initialized
INFO - 2024-04-20 09:20:12 --> Helper loaded: url_helper
INFO - 2024-04-20 09:20:12 --> Helper loaded: file_helper
INFO - 2024-04-20 09:20:12 --> Helper loaded: html_helper
INFO - 2024-04-20 09:20:12 --> Helper loaded: text_helper
INFO - 2024-04-20 09:20:12 --> Helper loaded: form_helper
INFO - 2024-04-20 09:20:12 --> Helper loaded: lang_helper
INFO - 2024-04-20 09:20:12 --> Helper loaded: security_helper
INFO - 2024-04-20 09:20:12 --> Helper loaded: cookie_helper
INFO - 2024-04-20 09:20:12 --> Database Driver Class Initialized
INFO - 2024-04-20 09:20:12 --> Session: Class initialized using 'files' driver.
INFO - 2024-04-20 09:20:12 --> Parser Class Initialized
INFO - 2024-04-20 09:20:12 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-04-20 09:20:12 --> Pagination Class Initialized
INFO - 2024-04-20 09:20:12 --> Form Validation Class Initialized
INFO - 2024-04-20 09:20:12 --> Controller Class Initialized
INFO - 2024-04-20 09:20:12 --> Model Class Initialized
DEBUG - 2024-04-20 09:20:12 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-04-20 09:20:12 --> Session class already loaded. Second attempt ignored.
INFO - 2024-04-20 09:20:12 --> Model Class Initialized
DEBUG - 2024-04-20 09:20:12 --> Session class already loaded. Second attempt ignored.
INFO - 2024-04-20 09:20:12 --> Model Class Initialized
DEBUG - 2024-04-20 09:20:12 --> Session class already loaded. Second attempt ignored.
INFO - 2024-04-20 09:20:12 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice_html.php
DEBUG - 2024-04-20 09:20:12 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-04-20 09:20:12 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-04-20 09:20:12 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-04-20 09:20:12 --> Model Class Initialized
INFO - 2024-04-20 09:20:12 --> Model Class Initialized
INFO - 2024-04-20 09:20:12 --> Model Class Initialized
INFO - 2024-04-20 09:20:13 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-04-20 09:20:13 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-04-20 09:20:13 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-04-20 09:20:13 --> Final output sent to browser
DEBUG - 2024-04-20 09:20:13 --> Total execution time: 0.2809
ERROR - 2024-04-20 09:20:53 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-04-20 09:20:53 --> Config Class Initialized
INFO - 2024-04-20 09:20:53 --> Hooks Class Initialized
DEBUG - 2024-04-20 09:20:53 --> UTF-8 Support Enabled
INFO - 2024-04-20 09:20:53 --> Utf8 Class Initialized
INFO - 2024-04-20 09:20:53 --> URI Class Initialized
INFO - 2024-04-20 09:20:53 --> Router Class Initialized
INFO - 2024-04-20 09:20:53 --> Output Class Initialized
INFO - 2024-04-20 09:20:53 --> Security Class Initialized
DEBUG - 2024-04-20 09:20:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-04-20 09:20:53 --> Input Class Initialized
INFO - 2024-04-20 09:20:53 --> Language Class Initialized
INFO - 2024-04-20 09:20:53 --> Loader Class Initialized
INFO - 2024-04-20 09:20:53 --> Helper loaded: url_helper
INFO - 2024-04-20 09:20:53 --> Helper loaded: file_helper
INFO - 2024-04-20 09:20:53 --> Helper loaded: html_helper
INFO - 2024-04-20 09:20:53 --> Helper loaded: text_helper
INFO - 2024-04-20 09:20:53 --> Helper loaded: form_helper
INFO - 2024-04-20 09:20:53 --> Helper loaded: lang_helper
INFO - 2024-04-20 09:20:53 --> Helper loaded: security_helper
INFO - 2024-04-20 09:20:53 --> Helper loaded: cookie_helper
INFO - 2024-04-20 09:20:53 --> Database Driver Class Initialized
INFO - 2024-04-20 09:20:53 --> Session: Class initialized using 'files' driver.
INFO - 2024-04-20 09:20:53 --> Parser Class Initialized
INFO - 2024-04-20 09:20:53 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-04-20 09:20:53 --> Pagination Class Initialized
INFO - 2024-04-20 09:20:53 --> Form Validation Class Initialized
INFO - 2024-04-20 09:20:53 --> Controller Class Initialized
DEBUG - 2024-04-20 09:20:53 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-04-20 09:20:53 --> Session class already loaded. Second attempt ignored.
INFO - 2024-04-20 09:20:53 --> Model Class Initialized
INFO - 2024-04-20 09:20:53 --> Model Class Initialized
DEBUG - 2024-04-20 09:20:53 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-04-20 09:20:53 --> Session class already loaded. Second attempt ignored.
INFO - 2024-04-20 09:20:53 --> Model Class Initialized
DEBUG - 2024-04-20 09:20:53 --> Session class already loaded. Second attempt ignored.
INFO - 2024-04-20 09:20:53 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/gst/list.php
DEBUG - 2024-04-20 09:20:53 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-04-20 09:20:53 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-04-20 09:20:53 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-04-20 09:20:53 --> Model Class Initialized
INFO - 2024-04-20 09:20:53 --> Model Class Initialized
INFO - 2024-04-20 09:20:53 --> Model Class Initialized
INFO - 2024-04-20 09:20:53 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-04-20 09:20:53 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-04-20 09:20:53 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-04-20 09:20:53 --> Final output sent to browser
DEBUG - 2024-04-20 09:20:53 --> Total execution time: 0.2722
ERROR - 2024-04-20 09:20:56 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-04-20 09:20:56 --> Config Class Initialized
INFO - 2024-04-20 09:20:56 --> Hooks Class Initialized
DEBUG - 2024-04-20 09:20:56 --> UTF-8 Support Enabled
INFO - 2024-04-20 09:20:56 --> Utf8 Class Initialized
INFO - 2024-04-20 09:20:56 --> URI Class Initialized
INFO - 2024-04-20 09:20:56 --> Router Class Initialized
INFO - 2024-04-20 09:20:56 --> Output Class Initialized
INFO - 2024-04-20 09:20:56 --> Security Class Initialized
DEBUG - 2024-04-20 09:20:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-04-20 09:20:56 --> Input Class Initialized
INFO - 2024-04-20 09:20:56 --> Language Class Initialized
INFO - 2024-04-20 09:20:56 --> Loader Class Initialized
INFO - 2024-04-20 09:20:56 --> Helper loaded: url_helper
INFO - 2024-04-20 09:20:56 --> Helper loaded: file_helper
INFO - 2024-04-20 09:20:56 --> Helper loaded: html_helper
INFO - 2024-04-20 09:20:56 --> Helper loaded: text_helper
INFO - 2024-04-20 09:20:56 --> Helper loaded: form_helper
INFO - 2024-04-20 09:20:56 --> Helper loaded: lang_helper
INFO - 2024-04-20 09:20:56 --> Helper loaded: security_helper
INFO - 2024-04-20 09:20:56 --> Helper loaded: cookie_helper
INFO - 2024-04-20 09:20:56 --> Database Driver Class Initialized
INFO - 2024-04-20 09:20:56 --> Session: Class initialized using 'files' driver.
INFO - 2024-04-20 09:20:56 --> Parser Class Initialized
INFO - 2024-04-20 09:20:56 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-04-20 09:20:56 --> Pagination Class Initialized
INFO - 2024-04-20 09:20:56 --> Form Validation Class Initialized
INFO - 2024-04-20 09:20:56 --> Controller Class Initialized
DEBUG - 2024-04-20 09:20:56 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-04-20 09:20:56 --> Session class already loaded. Second attempt ignored.
INFO - 2024-04-20 09:20:56 --> Model Class Initialized
DEBUG - 2024-04-20 09:20:56 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-04-20 09:20:56 --> Session class already loaded. Second attempt ignored.
INFO - 2024-04-20 09:20:56 --> Model Class Initialized
DEBUG - 2024-04-20 09:20:56 --> Session class already loaded. Second attempt ignored.
INFO - 2024-04-20 09:20:56 --> Model Class Initialized
INFO - 2024-04-20 09:20:56 --> Final output sent to browser
DEBUG - 2024-04-20 09:20:56 --> Total execution time: 0.0174
ERROR - 2024-04-20 09:21:29 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-04-20 09:21:29 --> Config Class Initialized
INFO - 2024-04-20 09:21:29 --> Hooks Class Initialized
DEBUG - 2024-04-20 09:21:29 --> UTF-8 Support Enabled
INFO - 2024-04-20 09:21:29 --> Utf8 Class Initialized
INFO - 2024-04-20 09:21:29 --> URI Class Initialized
INFO - 2024-04-20 09:21:29 --> Router Class Initialized
INFO - 2024-04-20 09:21:29 --> Output Class Initialized
INFO - 2024-04-20 09:21:29 --> Security Class Initialized
DEBUG - 2024-04-20 09:21:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-04-20 09:21:29 --> Input Class Initialized
INFO - 2024-04-20 09:21:29 --> Language Class Initialized
INFO - 2024-04-20 09:21:29 --> Loader Class Initialized
INFO - 2024-04-20 09:21:29 --> Helper loaded: url_helper
INFO - 2024-04-20 09:21:29 --> Helper loaded: file_helper
INFO - 2024-04-20 09:21:29 --> Helper loaded: html_helper
INFO - 2024-04-20 09:21:29 --> Helper loaded: text_helper
INFO - 2024-04-20 09:21:29 --> Helper loaded: form_helper
INFO - 2024-04-20 09:21:29 --> Helper loaded: lang_helper
INFO - 2024-04-20 09:21:29 --> Helper loaded: security_helper
INFO - 2024-04-20 09:21:29 --> Helper loaded: cookie_helper
INFO - 2024-04-20 09:21:29 --> Database Driver Class Initialized
INFO - 2024-04-20 09:21:29 --> Session: Class initialized using 'files' driver.
INFO - 2024-04-20 09:21:29 --> Parser Class Initialized
INFO - 2024-04-20 09:21:29 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-04-20 09:21:29 --> Pagination Class Initialized
INFO - 2024-04-20 09:21:29 --> Form Validation Class Initialized
INFO - 2024-04-20 09:21:29 --> Controller Class Initialized
DEBUG - 2024-04-20 09:21:29 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-04-20 09:21:29 --> Session class already loaded. Second attempt ignored.
INFO - 2024-04-20 09:21:29 --> Model Class Initialized
DEBUG - 2024-04-20 09:21:29 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-04-20 09:21:29 --> Session class already loaded. Second attempt ignored.
INFO - 2024-04-20 09:21:29 --> Model Class Initialized
DEBUG - 2024-04-20 09:21:29 --> Session class already loaded. Second attempt ignored.
INFO - 2024-04-20 09:21:29 --> Model Class Initialized
INFO - 2024-04-20 09:21:29 --> Final output sent to browser
DEBUG - 2024-04-20 09:21:29 --> Total execution time: 0.0519
ERROR - 2024-04-20 12:11:50 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-04-20 12:11:50 --> Config Class Initialized
INFO - 2024-04-20 12:11:50 --> Hooks Class Initialized
DEBUG - 2024-04-20 12:11:50 --> UTF-8 Support Enabled
INFO - 2024-04-20 12:11:50 --> Utf8 Class Initialized
INFO - 2024-04-20 12:11:50 --> URI Class Initialized
INFO - 2024-04-20 12:11:50 --> Router Class Initialized
INFO - 2024-04-20 12:11:50 --> Output Class Initialized
INFO - 2024-04-20 12:11:50 --> Security Class Initialized
DEBUG - 2024-04-20 12:11:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-04-20 12:11:50 --> Input Class Initialized
INFO - 2024-04-20 12:11:50 --> Language Class Initialized
INFO - 2024-04-20 12:11:50 --> Loader Class Initialized
INFO - 2024-04-20 12:11:50 --> Helper loaded: url_helper
INFO - 2024-04-20 12:11:50 --> Helper loaded: file_helper
INFO - 2024-04-20 12:11:50 --> Helper loaded: html_helper
INFO - 2024-04-20 12:11:50 --> Helper loaded: text_helper
INFO - 2024-04-20 12:11:50 --> Helper loaded: form_helper
INFO - 2024-04-20 12:11:50 --> Helper loaded: lang_helper
INFO - 2024-04-20 12:11:50 --> Helper loaded: security_helper
INFO - 2024-04-20 12:11:50 --> Helper loaded: cookie_helper
INFO - 2024-04-20 12:11:50 --> Database Driver Class Initialized
INFO - 2024-04-20 12:11:50 --> Session: Class initialized using 'files' driver.
INFO - 2024-04-20 12:11:50 --> Parser Class Initialized
INFO - 2024-04-20 12:11:50 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-04-20 12:11:50 --> Pagination Class Initialized
INFO - 2024-04-20 12:11:50 --> Form Validation Class Initialized
INFO - 2024-04-20 12:11:50 --> Controller Class Initialized
DEBUG - 2024-04-20 12:11:50 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-04-20 12:11:50 --> Session class already loaded. Second attempt ignored.
ERROR - 2024-04-20 12:11:50 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-04-20 12:11:50 --> Config Class Initialized
INFO - 2024-04-20 12:11:50 --> Hooks Class Initialized
DEBUG - 2024-04-20 12:11:50 --> UTF-8 Support Enabled
INFO - 2024-04-20 12:11:50 --> Utf8 Class Initialized
INFO - 2024-04-20 12:11:50 --> URI Class Initialized
INFO - 2024-04-20 12:11:50 --> Router Class Initialized
INFO - 2024-04-20 12:11:50 --> Output Class Initialized
INFO - 2024-04-20 12:11:50 --> Security Class Initialized
DEBUG - 2024-04-20 12:11:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-04-20 12:11:50 --> Input Class Initialized
INFO - 2024-04-20 12:11:50 --> Language Class Initialized
INFO - 2024-04-20 12:11:50 --> Loader Class Initialized
INFO - 2024-04-20 12:11:50 --> Helper loaded: url_helper
INFO - 2024-04-20 12:11:50 --> Helper loaded: file_helper
INFO - 2024-04-20 12:11:50 --> Helper loaded: html_helper
INFO - 2024-04-20 12:11:50 --> Helper loaded: text_helper
INFO - 2024-04-20 12:11:50 --> Helper loaded: form_helper
INFO - 2024-04-20 12:11:50 --> Helper loaded: lang_helper
INFO - 2024-04-20 12:11:50 --> Helper loaded: security_helper
INFO - 2024-04-20 12:11:50 --> Helper loaded: cookie_helper
INFO - 2024-04-20 12:11:50 --> Database Driver Class Initialized
INFO - 2024-04-20 12:11:50 --> Session: Class initialized using 'files' driver.
INFO - 2024-04-20 12:11:50 --> Parser Class Initialized
INFO - 2024-04-20 12:11:50 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-04-20 12:11:50 --> Pagination Class Initialized
INFO - 2024-04-20 12:11:50 --> Form Validation Class Initialized
INFO - 2024-04-20 12:11:50 --> Controller Class Initialized
INFO - 2024-04-20 12:11:50 --> Model Class Initialized
DEBUG - 2024-04-20 12:11:50 --> Session class already loaded. Second attempt ignored.
INFO - 2024-04-20 12:11:50 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2024-04-20 12:11:50 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-04-20 12:11:50 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-04-20 12:11:50 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-04-20 12:11:50 --> Model Class Initialized
INFO - 2024-04-20 12:11:50 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-04-20 12:11:50 --> Final output sent to browser
DEBUG - 2024-04-20 12:11:50 --> Total execution time: 0.0373
ERROR - 2024-04-20 12:11:52 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-04-20 12:11:52 --> Config Class Initialized
INFO - 2024-04-20 12:11:52 --> Hooks Class Initialized
DEBUG - 2024-04-20 12:11:52 --> UTF-8 Support Enabled
INFO - 2024-04-20 12:11:52 --> Utf8 Class Initialized
INFO - 2024-04-20 12:11:52 --> URI Class Initialized
INFO - 2024-04-20 12:11:52 --> Router Class Initialized
INFO - 2024-04-20 12:11:52 --> Output Class Initialized
INFO - 2024-04-20 12:11:52 --> Security Class Initialized
DEBUG - 2024-04-20 12:11:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-04-20 12:11:52 --> Input Class Initialized
INFO - 2024-04-20 12:11:52 --> Language Class Initialized
INFO - 2024-04-20 12:11:52 --> Loader Class Initialized
INFO - 2024-04-20 12:11:52 --> Helper loaded: url_helper
INFO - 2024-04-20 12:11:52 --> Helper loaded: file_helper
INFO - 2024-04-20 12:11:52 --> Helper loaded: html_helper
INFO - 2024-04-20 12:11:52 --> Helper loaded: text_helper
INFO - 2024-04-20 12:11:52 --> Helper loaded: form_helper
INFO - 2024-04-20 12:11:52 --> Helper loaded: lang_helper
INFO - 2024-04-20 12:11:52 --> Helper loaded: security_helper
INFO - 2024-04-20 12:11:52 --> Helper loaded: cookie_helper
INFO - 2024-04-20 12:11:52 --> Database Driver Class Initialized
INFO - 2024-04-20 12:11:52 --> Session: Class initialized using 'files' driver.
INFO - 2024-04-20 12:11:52 --> Parser Class Initialized
INFO - 2024-04-20 12:11:52 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-04-20 12:11:52 --> Pagination Class Initialized
INFO - 2024-04-20 12:11:52 --> Form Validation Class Initialized
INFO - 2024-04-20 12:11:52 --> Controller Class Initialized
INFO - 2024-04-20 12:11:52 --> Model Class Initialized
DEBUG - 2024-04-20 12:11:52 --> Session class already loaded. Second attempt ignored.
INFO - 2024-04-20 12:11:52 --> Model Class Initialized
INFO - 2024-04-20 12:11:52 --> Final output sent to browser
DEBUG - 2024-04-20 12:11:52 --> Total execution time: 0.0184
ERROR - 2024-04-20 12:11:52 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-04-20 12:11:52 --> Config Class Initialized
INFO - 2024-04-20 12:11:52 --> Hooks Class Initialized
DEBUG - 2024-04-20 12:11:52 --> UTF-8 Support Enabled
INFO - 2024-04-20 12:11:52 --> Utf8 Class Initialized
INFO - 2024-04-20 12:11:52 --> URI Class Initialized
DEBUG - 2024-04-20 12:11:52 --> No URI present. Default controller set.
INFO - 2024-04-20 12:11:52 --> Router Class Initialized
INFO - 2024-04-20 12:11:52 --> Output Class Initialized
INFO - 2024-04-20 12:11:52 --> Security Class Initialized
DEBUG - 2024-04-20 12:11:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-04-20 12:11:52 --> Input Class Initialized
INFO - 2024-04-20 12:11:52 --> Language Class Initialized
INFO - 2024-04-20 12:11:52 --> Loader Class Initialized
INFO - 2024-04-20 12:11:52 --> Helper loaded: url_helper
INFO - 2024-04-20 12:11:52 --> Helper loaded: file_helper
INFO - 2024-04-20 12:11:52 --> Helper loaded: html_helper
INFO - 2024-04-20 12:11:52 --> Helper loaded: text_helper
INFO - 2024-04-20 12:11:52 --> Helper loaded: form_helper
INFO - 2024-04-20 12:11:52 --> Helper loaded: lang_helper
INFO - 2024-04-20 12:11:52 --> Helper loaded: security_helper
INFO - 2024-04-20 12:11:52 --> Helper loaded: cookie_helper
INFO - 2024-04-20 12:11:52 --> Database Driver Class Initialized
INFO - 2024-04-20 12:11:52 --> Session: Class initialized using 'files' driver.
INFO - 2024-04-20 12:11:52 --> Parser Class Initialized
INFO - 2024-04-20 12:11:52 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-04-20 12:11:52 --> Pagination Class Initialized
INFO - 2024-04-20 12:11:52 --> Form Validation Class Initialized
INFO - 2024-04-20 12:11:52 --> Controller Class Initialized
INFO - 2024-04-20 12:11:52 --> Model Class Initialized
DEBUG - 2024-04-20 12:11:52 --> Session class already loaded. Second attempt ignored.
INFO - 2024-04-20 12:11:52 --> Model Class Initialized
DEBUG - 2024-04-20 12:11:52 --> Session class already loaded. Second attempt ignored.
INFO - 2024-04-20 12:11:52 --> Model Class Initialized
INFO - 2024-04-20 12:11:52 --> Model Class Initialized
INFO - 2024-04-20 12:11:52 --> Model Class Initialized
INFO - 2024-04-20 12:11:52 --> Model Class Initialized
DEBUG - 2024-04-20 12:11:52 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-04-20 12:11:52 --> Session class already loaded. Second attempt ignored.
INFO - 2024-04-20 12:11:52 --> Model Class Initialized
INFO - 2024-04-20 12:11:52 --> Model Class Initialized
INFO - 2024-04-20 12:11:53 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2024-04-20 12:11:53 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-04-20 12:11:53 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-04-20 12:11:53 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-04-20 12:11:53 --> Model Class Initialized
INFO - 2024-04-20 12:11:53 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-04-20 12:11:53 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-04-20 12:11:53 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-04-20 12:11:53 --> Final output sent to browser
DEBUG - 2024-04-20 12:11:53 --> Total execution time: 0.6141
ERROR - 2024-04-20 12:11:54 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-04-20 12:11:54 --> Config Class Initialized
INFO - 2024-04-20 12:11:54 --> Hooks Class Initialized
DEBUG - 2024-04-20 12:11:54 --> UTF-8 Support Enabled
INFO - 2024-04-20 12:11:54 --> Utf8 Class Initialized
INFO - 2024-04-20 12:11:54 --> URI Class Initialized
INFO - 2024-04-20 12:11:54 --> Router Class Initialized
INFO - 2024-04-20 12:11:54 --> Output Class Initialized
INFO - 2024-04-20 12:11:54 --> Security Class Initialized
DEBUG - 2024-04-20 12:11:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-04-20 12:11:54 --> Input Class Initialized
INFO - 2024-04-20 12:11:54 --> Language Class Initialized
INFO - 2024-04-20 12:11:54 --> Loader Class Initialized
INFO - 2024-04-20 12:11:54 --> Helper loaded: url_helper
INFO - 2024-04-20 12:11:54 --> Helper loaded: file_helper
INFO - 2024-04-20 12:11:54 --> Helper loaded: html_helper
INFO - 2024-04-20 12:11:54 --> Helper loaded: text_helper
INFO - 2024-04-20 12:11:54 --> Helper loaded: form_helper
INFO - 2024-04-20 12:11:54 --> Helper loaded: lang_helper
INFO - 2024-04-20 12:11:54 --> Helper loaded: security_helper
INFO - 2024-04-20 12:11:54 --> Helper loaded: cookie_helper
INFO - 2024-04-20 12:11:54 --> Database Driver Class Initialized
INFO - 2024-04-20 12:11:54 --> Session: Class initialized using 'files' driver.
INFO - 2024-04-20 12:11:54 --> Parser Class Initialized
INFO - 2024-04-20 12:11:54 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-04-20 12:11:54 --> Pagination Class Initialized
INFO - 2024-04-20 12:11:54 --> Form Validation Class Initialized
INFO - 2024-04-20 12:11:54 --> Controller Class Initialized
DEBUG - 2024-04-20 12:11:54 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-04-20 12:11:54 --> Session class already loaded. Second attempt ignored.
INFO - 2024-04-20 12:11:54 --> Model Class Initialized
INFO - 2024-04-20 12:11:54 --> Final output sent to browser
DEBUG - 2024-04-20 12:11:54 --> Total execution time: 0.0131
ERROR - 2024-04-20 12:12:27 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-04-20 12:12:27 --> Config Class Initialized
INFO - 2024-04-20 12:12:27 --> Hooks Class Initialized
DEBUG - 2024-04-20 12:12:27 --> UTF-8 Support Enabled
INFO - 2024-04-20 12:12:27 --> Utf8 Class Initialized
INFO - 2024-04-20 12:12:27 --> URI Class Initialized
INFO - 2024-04-20 12:12:27 --> Router Class Initialized
INFO - 2024-04-20 12:12:27 --> Output Class Initialized
INFO - 2024-04-20 12:12:27 --> Security Class Initialized
DEBUG - 2024-04-20 12:12:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-04-20 12:12:27 --> Input Class Initialized
INFO - 2024-04-20 12:12:27 --> Language Class Initialized
INFO - 2024-04-20 12:12:27 --> Loader Class Initialized
INFO - 2024-04-20 12:12:27 --> Helper loaded: url_helper
INFO - 2024-04-20 12:12:27 --> Helper loaded: file_helper
INFO - 2024-04-20 12:12:27 --> Helper loaded: html_helper
INFO - 2024-04-20 12:12:27 --> Helper loaded: text_helper
INFO - 2024-04-20 12:12:27 --> Helper loaded: form_helper
INFO - 2024-04-20 12:12:27 --> Helper loaded: lang_helper
INFO - 2024-04-20 12:12:27 --> Helper loaded: security_helper
INFO - 2024-04-20 12:12:27 --> Helper loaded: cookie_helper
INFO - 2024-04-20 12:12:27 --> Database Driver Class Initialized
INFO - 2024-04-20 12:12:27 --> Session: Class initialized using 'files' driver.
INFO - 2024-04-20 12:12:27 --> Parser Class Initialized
INFO - 2024-04-20 12:12:27 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-04-20 12:12:27 --> Pagination Class Initialized
INFO - 2024-04-20 12:12:27 --> Form Validation Class Initialized
INFO - 2024-04-20 12:12:27 --> Controller Class Initialized
INFO - 2024-04-20 12:12:27 --> Model Class Initialized
DEBUG - 2024-04-20 12:12:27 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-04-20 12:12:27 --> Session class already loaded. Second attempt ignored.
INFO - 2024-04-20 12:12:27 --> Model Class Initialized
DEBUG - 2024-04-20 12:12:27 --> Session class already loaded. Second attempt ignored.
INFO - 2024-04-20 12:12:27 --> Model Class Initialized
INFO - 2024-04-20 12:12:27 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/invoice/invoice.php
DEBUG - 2024-04-20 12:12:27 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-04-20 12:12:27 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-04-20 12:12:27 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-04-20 12:12:27 --> Model Class Initialized
INFO - 2024-04-20 12:12:27 --> Model Class Initialized
INFO - 2024-04-20 12:12:27 --> Model Class Initialized
INFO - 2024-04-20 12:12:28 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-04-20 12:12:28 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-04-20 12:12:28 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-04-20 12:12:28 --> Final output sent to browser
DEBUG - 2024-04-20 12:12:28 --> Total execution time: 0.2786
ERROR - 2024-04-20 12:12:28 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-04-20 12:12:28 --> Config Class Initialized
INFO - 2024-04-20 12:12:28 --> Hooks Class Initialized
DEBUG - 2024-04-20 12:12:28 --> UTF-8 Support Enabled
INFO - 2024-04-20 12:12:28 --> Utf8 Class Initialized
INFO - 2024-04-20 12:12:28 --> URI Class Initialized
INFO - 2024-04-20 12:12:28 --> Router Class Initialized
INFO - 2024-04-20 12:12:28 --> Output Class Initialized
INFO - 2024-04-20 12:12:28 --> Security Class Initialized
DEBUG - 2024-04-20 12:12:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-04-20 12:12:28 --> Input Class Initialized
INFO - 2024-04-20 12:12:28 --> Language Class Initialized
INFO - 2024-04-20 12:12:28 --> Loader Class Initialized
INFO - 2024-04-20 12:12:28 --> Helper loaded: url_helper
INFO - 2024-04-20 12:12:28 --> Helper loaded: file_helper
INFO - 2024-04-20 12:12:28 --> Helper loaded: html_helper
INFO - 2024-04-20 12:12:28 --> Helper loaded: text_helper
INFO - 2024-04-20 12:12:28 --> Helper loaded: form_helper
INFO - 2024-04-20 12:12:28 --> Helper loaded: lang_helper
INFO - 2024-04-20 12:12:28 --> Helper loaded: security_helper
INFO - 2024-04-20 12:12:28 --> Helper loaded: cookie_helper
INFO - 2024-04-20 12:12:28 --> Database Driver Class Initialized
INFO - 2024-04-20 12:12:28 --> Session: Class initialized using 'files' driver.
INFO - 2024-04-20 12:12:28 --> Parser Class Initialized
INFO - 2024-04-20 12:12:28 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-04-20 12:12:28 --> Pagination Class Initialized
INFO - 2024-04-20 12:12:28 --> Form Validation Class Initialized
INFO - 2024-04-20 12:12:28 --> Controller Class Initialized
INFO - 2024-04-20 12:12:28 --> Model Class Initialized
DEBUG - 2024-04-20 12:12:28 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-04-20 12:12:28 --> Session class already loaded. Second attempt ignored.
INFO - 2024-04-20 12:12:28 --> Model Class Initialized
DEBUG - 2024-04-20 12:12:28 --> Session class already loaded. Second attempt ignored.
INFO - 2024-04-20 12:12:28 --> Model Class Initialized
INFO - 2024-04-20 12:12:28 --> Final output sent to browser
DEBUG - 2024-04-20 12:12:28 --> Total execution time: 0.0472
ERROR - 2024-04-20 12:12:32 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-04-20 12:12:32 --> Config Class Initialized
INFO - 2024-04-20 12:12:32 --> Hooks Class Initialized
DEBUG - 2024-04-20 12:12:32 --> UTF-8 Support Enabled
INFO - 2024-04-20 12:12:32 --> Utf8 Class Initialized
INFO - 2024-04-20 12:12:32 --> URI Class Initialized
INFO - 2024-04-20 12:12:32 --> Router Class Initialized
INFO - 2024-04-20 12:12:32 --> Output Class Initialized
INFO - 2024-04-20 12:12:32 --> Security Class Initialized
DEBUG - 2024-04-20 12:12:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-04-20 12:12:32 --> Input Class Initialized
INFO - 2024-04-20 12:12:32 --> Language Class Initialized
INFO - 2024-04-20 12:12:32 --> Loader Class Initialized
INFO - 2024-04-20 12:12:32 --> Helper loaded: url_helper
INFO - 2024-04-20 12:12:32 --> Helper loaded: file_helper
INFO - 2024-04-20 12:12:32 --> Helper loaded: html_helper
INFO - 2024-04-20 12:12:32 --> Helper loaded: text_helper
INFO - 2024-04-20 12:12:32 --> Helper loaded: form_helper
INFO - 2024-04-20 12:12:32 --> Helper loaded: lang_helper
INFO - 2024-04-20 12:12:32 --> Helper loaded: security_helper
INFO - 2024-04-20 12:12:32 --> Helper loaded: cookie_helper
INFO - 2024-04-20 12:12:32 --> Database Driver Class Initialized
INFO - 2024-04-20 12:12:32 --> Session: Class initialized using 'files' driver.
INFO - 2024-04-20 12:12:32 --> Parser Class Initialized
INFO - 2024-04-20 12:12:32 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-04-20 12:12:32 --> Pagination Class Initialized
INFO - 2024-04-20 12:12:32 --> Form Validation Class Initialized
INFO - 2024-04-20 12:12:32 --> Controller Class Initialized
INFO - 2024-04-20 12:12:32 --> Model Class Initialized
DEBUG - 2024-04-20 12:12:32 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-04-20 12:12:32 --> Session class already loaded. Second attempt ignored.
INFO - 2024-04-20 12:12:32 --> Model Class Initialized
DEBUG - 2024-04-20 12:12:32 --> Session class already loaded. Second attempt ignored.
INFO - 2024-04-20 12:12:32 --> Model Class Initialized
INFO - 2024-04-20 12:12:32 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice.php
DEBUG - 2024-04-20 12:12:32 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-04-20 12:12:32 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-04-20 12:12:32 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-04-20 12:12:32 --> Model Class Initialized
INFO - 2024-04-20 12:12:32 --> Model Class Initialized
INFO - 2024-04-20 12:12:32 --> Model Class Initialized
INFO - 2024-04-20 12:12:33 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-04-20 12:12:33 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-04-20 12:12:33 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-04-20 12:12:33 --> Final output sent to browser
DEBUG - 2024-04-20 12:12:33 --> Total execution time: 0.2751
ERROR - 2024-04-20 12:12:33 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-04-20 12:12:33 --> Config Class Initialized
INFO - 2024-04-20 12:12:33 --> Hooks Class Initialized
DEBUG - 2024-04-20 12:12:33 --> UTF-8 Support Enabled
INFO - 2024-04-20 12:12:33 --> Utf8 Class Initialized
INFO - 2024-04-20 12:12:33 --> URI Class Initialized
INFO - 2024-04-20 12:12:33 --> Router Class Initialized
INFO - 2024-04-20 12:12:33 --> Output Class Initialized
INFO - 2024-04-20 12:12:33 --> Security Class Initialized
DEBUG - 2024-04-20 12:12:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-04-20 12:12:33 --> Input Class Initialized
INFO - 2024-04-20 12:12:33 --> Language Class Initialized
INFO - 2024-04-20 12:12:33 --> Loader Class Initialized
INFO - 2024-04-20 12:12:33 --> Helper loaded: url_helper
INFO - 2024-04-20 12:12:33 --> Helper loaded: file_helper
INFO - 2024-04-20 12:12:33 --> Helper loaded: html_helper
INFO - 2024-04-20 12:12:33 --> Helper loaded: text_helper
INFO - 2024-04-20 12:12:33 --> Helper loaded: form_helper
INFO - 2024-04-20 12:12:33 --> Helper loaded: lang_helper
INFO - 2024-04-20 12:12:33 --> Helper loaded: security_helper
INFO - 2024-04-20 12:12:33 --> Helper loaded: cookie_helper
INFO - 2024-04-20 12:12:33 --> Database Driver Class Initialized
INFO - 2024-04-20 12:12:33 --> Session: Class initialized using 'files' driver.
INFO - 2024-04-20 12:12:33 --> Parser Class Initialized
INFO - 2024-04-20 12:12:33 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-04-20 12:12:33 --> Pagination Class Initialized
INFO - 2024-04-20 12:12:33 --> Form Validation Class Initialized
INFO - 2024-04-20 12:12:33 --> Controller Class Initialized
INFO - 2024-04-20 12:12:33 --> Model Class Initialized
DEBUG - 2024-04-20 12:12:33 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-04-20 12:12:33 --> Session class already loaded. Second attempt ignored.
INFO - 2024-04-20 12:12:33 --> Model Class Initialized
DEBUG - 2024-04-20 12:12:33 --> Session class already loaded. Second attempt ignored.
INFO - 2024-04-20 12:12:33 --> Model Class Initialized
INFO - 2024-04-20 12:12:33 --> Final output sent to browser
DEBUG - 2024-04-20 12:12:33 --> Total execution time: 0.0446
ERROR - 2024-04-20 12:22:13 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-04-20 12:22:13 --> Config Class Initialized
INFO - 2024-04-20 12:22:13 --> Hooks Class Initialized
DEBUG - 2024-04-20 12:22:13 --> UTF-8 Support Enabled
INFO - 2024-04-20 12:22:13 --> Utf8 Class Initialized
INFO - 2024-04-20 12:22:13 --> URI Class Initialized
INFO - 2024-04-20 12:22:13 --> Router Class Initialized
INFO - 2024-04-20 12:22:13 --> Output Class Initialized
INFO - 2024-04-20 12:22:13 --> Security Class Initialized
DEBUG - 2024-04-20 12:22:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-04-20 12:22:13 --> Input Class Initialized
INFO - 2024-04-20 12:22:13 --> Language Class Initialized
INFO - 2024-04-20 12:22:13 --> Loader Class Initialized
INFO - 2024-04-20 12:22:13 --> Helper loaded: url_helper
INFO - 2024-04-20 12:22:13 --> Helper loaded: file_helper
INFO - 2024-04-20 12:22:13 --> Helper loaded: html_helper
INFO - 2024-04-20 12:22:13 --> Helper loaded: text_helper
INFO - 2024-04-20 12:22:13 --> Helper loaded: form_helper
INFO - 2024-04-20 12:22:13 --> Helper loaded: lang_helper
INFO - 2024-04-20 12:22:13 --> Helper loaded: security_helper
INFO - 2024-04-20 12:22:13 --> Helper loaded: cookie_helper
INFO - 2024-04-20 12:22:13 --> Database Driver Class Initialized
INFO - 2024-04-20 12:22:13 --> Session: Class initialized using 'files' driver.
INFO - 2024-04-20 12:22:13 --> Parser Class Initialized
INFO - 2024-04-20 12:22:13 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-04-20 12:22:13 --> Pagination Class Initialized
INFO - 2024-04-20 12:22:13 --> Form Validation Class Initialized
INFO - 2024-04-20 12:22:13 --> Controller Class Initialized
INFO - 2024-04-20 12:22:13 --> Model Class Initialized
DEBUG - 2024-04-20 12:22:13 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-04-20 12:22:13 --> Session class already loaded. Second attempt ignored.
INFO - 2024-04-20 12:22:13 --> Model Class Initialized
INFO - 2024-04-20 12:22:13 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/demandrequest/demandrequest.php
DEBUG - 2024-04-20 12:22:13 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-04-20 12:22:13 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-04-20 12:22:13 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-04-20 12:22:13 --> Model Class Initialized
INFO - 2024-04-20 12:22:13 --> Model Class Initialized
INFO - 2024-04-20 12:22:13 --> Model Class Initialized
INFO - 2024-04-20 12:22:13 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-04-20 12:22:13 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-04-20 12:22:13 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-04-20 12:22:13 --> Final output sent to browser
DEBUG - 2024-04-20 12:22:13 --> Total execution time: 0.2718
ERROR - 2024-04-20 12:22:14 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-04-20 12:22:14 --> Config Class Initialized
INFO - 2024-04-20 12:22:14 --> Hooks Class Initialized
DEBUG - 2024-04-20 12:22:14 --> UTF-8 Support Enabled
INFO - 2024-04-20 12:22:14 --> Utf8 Class Initialized
INFO - 2024-04-20 12:22:14 --> URI Class Initialized
INFO - 2024-04-20 12:22:14 --> Router Class Initialized
INFO - 2024-04-20 12:22:14 --> Output Class Initialized
INFO - 2024-04-20 12:22:14 --> Security Class Initialized
DEBUG - 2024-04-20 12:22:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-04-20 12:22:14 --> Input Class Initialized
INFO - 2024-04-20 12:22:14 --> Language Class Initialized
INFO - 2024-04-20 12:22:14 --> Loader Class Initialized
INFO - 2024-04-20 12:22:14 --> Helper loaded: url_helper
INFO - 2024-04-20 12:22:14 --> Helper loaded: file_helper
INFO - 2024-04-20 12:22:14 --> Helper loaded: html_helper
INFO - 2024-04-20 12:22:14 --> Helper loaded: text_helper
INFO - 2024-04-20 12:22:14 --> Helper loaded: form_helper
INFO - 2024-04-20 12:22:14 --> Helper loaded: lang_helper
INFO - 2024-04-20 12:22:14 --> Helper loaded: security_helper
INFO - 2024-04-20 12:22:14 --> Helper loaded: cookie_helper
INFO - 2024-04-20 12:22:14 --> Database Driver Class Initialized
INFO - 2024-04-20 12:22:14 --> Session: Class initialized using 'files' driver.
INFO - 2024-04-20 12:22:14 --> Parser Class Initialized
INFO - 2024-04-20 12:22:14 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-04-20 12:22:14 --> Pagination Class Initialized
INFO - 2024-04-20 12:22:14 --> Form Validation Class Initialized
INFO - 2024-04-20 12:22:14 --> Controller Class Initialized
INFO - 2024-04-20 12:22:14 --> Model Class Initialized
DEBUG - 2024-04-20 12:22:14 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-04-20 12:22:14 --> Session class already loaded. Second attempt ignored.
INFO - 2024-04-20 12:22:14 --> Model Class Initialized
INFO - 2024-04-20 12:22:14 --> Final output sent to browser
DEBUG - 2024-04-20 12:22:14 --> Total execution time: 0.0164
ERROR - 2024-04-20 12:23:33 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-04-20 12:23:33 --> Config Class Initialized
INFO - 2024-04-20 12:23:33 --> Hooks Class Initialized
DEBUG - 2024-04-20 12:23:33 --> UTF-8 Support Enabled
INFO - 2024-04-20 12:23:33 --> Utf8 Class Initialized
INFO - 2024-04-20 12:23:33 --> URI Class Initialized
INFO - 2024-04-20 12:23:33 --> Router Class Initialized
INFO - 2024-04-20 12:23:33 --> Output Class Initialized
INFO - 2024-04-20 12:23:33 --> Security Class Initialized
DEBUG - 2024-04-20 12:23:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-04-20 12:23:33 --> Input Class Initialized
INFO - 2024-04-20 12:23:33 --> Language Class Initialized
INFO - 2024-04-20 12:23:33 --> Loader Class Initialized
INFO - 2024-04-20 12:23:33 --> Helper loaded: url_helper
INFO - 2024-04-20 12:23:33 --> Helper loaded: file_helper
INFO - 2024-04-20 12:23:33 --> Helper loaded: html_helper
INFO - 2024-04-20 12:23:33 --> Helper loaded: text_helper
INFO - 2024-04-20 12:23:33 --> Helper loaded: form_helper
INFO - 2024-04-20 12:23:33 --> Helper loaded: lang_helper
INFO - 2024-04-20 12:23:33 --> Helper loaded: security_helper
INFO - 2024-04-20 12:23:33 --> Helper loaded: cookie_helper
INFO - 2024-04-20 12:23:33 --> Database Driver Class Initialized
INFO - 2024-04-20 12:23:33 --> Session: Class initialized using 'files' driver.
INFO - 2024-04-20 12:23:33 --> Parser Class Initialized
INFO - 2024-04-20 12:23:33 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-04-20 12:23:33 --> Pagination Class Initialized
INFO - 2024-04-20 12:23:33 --> Form Validation Class Initialized
INFO - 2024-04-20 12:23:33 --> Controller Class Initialized
INFO - 2024-04-20 12:23:33 --> Model Class Initialized
INFO - 2024-04-20 12:23:33 --> Model Class Initialized
INFO - 2024-04-20 12:23:33 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/purchase/purchase.php
DEBUG - 2024-04-20 12:23:33 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-04-20 12:23:33 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-04-20 12:23:33 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-04-20 12:23:33 --> Model Class Initialized
INFO - 2024-04-20 12:23:33 --> Model Class Initialized
INFO - 2024-04-20 12:23:33 --> Model Class Initialized
INFO - 2024-04-20 12:23:34 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-04-20 12:23:34 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-04-20 12:23:34 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-04-20 12:23:34 --> Final output sent to browser
DEBUG - 2024-04-20 12:23:34 --> Total execution time: 0.2782
ERROR - 2024-04-20 12:23:34 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-04-20 12:23:34 --> Config Class Initialized
INFO - 2024-04-20 12:23:34 --> Hooks Class Initialized
DEBUG - 2024-04-20 12:23:34 --> UTF-8 Support Enabled
INFO - 2024-04-20 12:23:34 --> Utf8 Class Initialized
INFO - 2024-04-20 12:23:34 --> URI Class Initialized
INFO - 2024-04-20 12:23:34 --> Router Class Initialized
INFO - 2024-04-20 12:23:34 --> Output Class Initialized
INFO - 2024-04-20 12:23:34 --> Security Class Initialized
DEBUG - 2024-04-20 12:23:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-04-20 12:23:34 --> Input Class Initialized
INFO - 2024-04-20 12:23:34 --> Language Class Initialized
INFO - 2024-04-20 12:23:34 --> Loader Class Initialized
INFO - 2024-04-20 12:23:34 --> Helper loaded: url_helper
INFO - 2024-04-20 12:23:34 --> Helper loaded: file_helper
INFO - 2024-04-20 12:23:34 --> Helper loaded: html_helper
INFO - 2024-04-20 12:23:34 --> Helper loaded: text_helper
INFO - 2024-04-20 12:23:34 --> Helper loaded: form_helper
INFO - 2024-04-20 12:23:34 --> Helper loaded: lang_helper
INFO - 2024-04-20 12:23:34 --> Helper loaded: security_helper
INFO - 2024-04-20 12:23:34 --> Helper loaded: cookie_helper
INFO - 2024-04-20 12:23:34 --> Database Driver Class Initialized
INFO - 2024-04-20 12:23:35 --> Session: Class initialized using 'files' driver.
INFO - 2024-04-20 12:23:35 --> Parser Class Initialized
INFO - 2024-04-20 12:23:35 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-04-20 12:23:35 --> Pagination Class Initialized
INFO - 2024-04-20 12:23:35 --> Form Validation Class Initialized
INFO - 2024-04-20 12:23:35 --> Controller Class Initialized
INFO - 2024-04-20 12:23:35 --> Model Class Initialized
INFO - 2024-04-20 12:23:35 --> Model Class Initialized
INFO - 2024-04-20 12:23:35 --> Final output sent to browser
DEBUG - 2024-04-20 12:23:35 --> Total execution time: 0.1603
ERROR - 2024-04-20 12:23:40 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-04-20 12:23:40 --> Config Class Initialized
INFO - 2024-04-20 12:23:40 --> Hooks Class Initialized
DEBUG - 2024-04-20 12:23:40 --> UTF-8 Support Enabled
INFO - 2024-04-20 12:23:40 --> Utf8 Class Initialized
INFO - 2024-04-20 12:23:40 --> URI Class Initialized
INFO - 2024-04-20 12:23:40 --> Router Class Initialized
INFO - 2024-04-20 12:23:40 --> Output Class Initialized
INFO - 2024-04-20 12:23:40 --> Security Class Initialized
DEBUG - 2024-04-20 12:23:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-04-20 12:23:40 --> Input Class Initialized
INFO - 2024-04-20 12:23:40 --> Language Class Initialized
INFO - 2024-04-20 12:23:40 --> Loader Class Initialized
INFO - 2024-04-20 12:23:40 --> Helper loaded: url_helper
INFO - 2024-04-20 12:23:40 --> Helper loaded: file_helper
INFO - 2024-04-20 12:23:40 --> Helper loaded: html_helper
INFO - 2024-04-20 12:23:40 --> Helper loaded: text_helper
INFO - 2024-04-20 12:23:40 --> Helper loaded: form_helper
INFO - 2024-04-20 12:23:40 --> Helper loaded: lang_helper
INFO - 2024-04-20 12:23:40 --> Helper loaded: security_helper
INFO - 2024-04-20 12:23:40 --> Helper loaded: cookie_helper
INFO - 2024-04-20 12:23:40 --> Database Driver Class Initialized
INFO - 2024-04-20 12:23:40 --> Session: Class initialized using 'files' driver.
INFO - 2024-04-20 12:23:40 --> Parser Class Initialized
INFO - 2024-04-20 12:23:40 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-04-20 12:23:40 --> Pagination Class Initialized
INFO - 2024-04-20 12:23:40 --> Form Validation Class Initialized
INFO - 2024-04-20 12:23:40 --> Controller Class Initialized
INFO - 2024-04-20 12:23:40 --> Model Class Initialized
INFO - 2024-04-20 12:23:40 --> Model Class Initialized
INFO - 2024-04-20 12:23:40 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/purchase/purchase_html.php
DEBUG - 2024-04-20 12:23:40 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-04-20 12:23:40 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-04-20 12:23:40 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-04-20 12:23:40 --> Model Class Initialized
INFO - 2024-04-20 12:23:40 --> Model Class Initialized
INFO - 2024-04-20 12:23:40 --> Model Class Initialized
INFO - 2024-04-20 12:23:41 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-04-20 12:23:41 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-04-20 12:23:41 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-04-20 12:23:41 --> Final output sent to browser
DEBUG - 2024-04-20 12:23:41 --> Total execution time: 0.2865
ERROR - 2024-04-20 12:23:45 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-04-20 12:23:45 --> Config Class Initialized
INFO - 2024-04-20 12:23:45 --> Hooks Class Initialized
DEBUG - 2024-04-20 12:23:45 --> UTF-8 Support Enabled
INFO - 2024-04-20 12:23:45 --> Utf8 Class Initialized
INFO - 2024-04-20 12:23:45 --> URI Class Initialized
INFO - 2024-04-20 12:23:45 --> Router Class Initialized
INFO - 2024-04-20 12:23:45 --> Output Class Initialized
INFO - 2024-04-20 12:23:45 --> Security Class Initialized
DEBUG - 2024-04-20 12:23:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-04-20 12:23:45 --> Input Class Initialized
INFO - 2024-04-20 12:23:45 --> Language Class Initialized
INFO - 2024-04-20 12:23:45 --> Loader Class Initialized
INFO - 2024-04-20 12:23:45 --> Helper loaded: url_helper
INFO - 2024-04-20 12:23:45 --> Helper loaded: file_helper
INFO - 2024-04-20 12:23:45 --> Helper loaded: html_helper
INFO - 2024-04-20 12:23:45 --> Helper loaded: text_helper
INFO - 2024-04-20 12:23:45 --> Helper loaded: form_helper
INFO - 2024-04-20 12:23:45 --> Helper loaded: lang_helper
INFO - 2024-04-20 12:23:45 --> Helper loaded: security_helper
INFO - 2024-04-20 12:23:45 --> Helper loaded: cookie_helper
INFO - 2024-04-20 12:23:45 --> Database Driver Class Initialized
INFO - 2024-04-20 12:23:45 --> Session: Class initialized using 'files' driver.
INFO - 2024-04-20 12:23:45 --> Parser Class Initialized
INFO - 2024-04-20 12:23:45 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-04-20 12:23:45 --> Pagination Class Initialized
INFO - 2024-04-20 12:23:45 --> Form Validation Class Initialized
INFO - 2024-04-20 12:23:45 --> Controller Class Initialized
INFO - 2024-04-20 12:23:45 --> Model Class Initialized
INFO - 2024-04-20 12:23:45 --> Model Class Initialized
INFO - 2024-04-20 12:23:45 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/purchase/purchase.php
DEBUG - 2024-04-20 12:23:45 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-04-20 12:23:45 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-04-20 12:23:45 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-04-20 12:23:45 --> Model Class Initialized
INFO - 2024-04-20 12:23:45 --> Model Class Initialized
INFO - 2024-04-20 12:23:45 --> Model Class Initialized
INFO - 2024-04-20 12:23:45 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-04-20 12:23:45 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-04-20 12:23:45 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-04-20 12:23:45 --> Final output sent to browser
DEBUG - 2024-04-20 12:23:45 --> Total execution time: 0.2721
ERROR - 2024-04-20 12:23:45 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-04-20 12:23:45 --> Config Class Initialized
INFO - 2024-04-20 12:23:45 --> Hooks Class Initialized
DEBUG - 2024-04-20 12:23:45 --> UTF-8 Support Enabled
INFO - 2024-04-20 12:23:45 --> Utf8 Class Initialized
INFO - 2024-04-20 12:23:45 --> URI Class Initialized
INFO - 2024-04-20 12:23:45 --> Router Class Initialized
INFO - 2024-04-20 12:23:45 --> Output Class Initialized
INFO - 2024-04-20 12:23:45 --> Security Class Initialized
DEBUG - 2024-04-20 12:23:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-04-20 12:23:45 --> Input Class Initialized
INFO - 2024-04-20 12:23:45 --> Language Class Initialized
INFO - 2024-04-20 12:23:45 --> Loader Class Initialized
INFO - 2024-04-20 12:23:45 --> Helper loaded: url_helper
INFO - 2024-04-20 12:23:45 --> Helper loaded: file_helper
INFO - 2024-04-20 12:23:45 --> Helper loaded: html_helper
INFO - 2024-04-20 12:23:45 --> Helper loaded: text_helper
INFO - 2024-04-20 12:23:45 --> Helper loaded: form_helper
INFO - 2024-04-20 12:23:45 --> Helper loaded: lang_helper
INFO - 2024-04-20 12:23:45 --> Helper loaded: security_helper
INFO - 2024-04-20 12:23:45 --> Helper loaded: cookie_helper
INFO - 2024-04-20 12:23:45 --> Database Driver Class Initialized
INFO - 2024-04-20 12:23:45 --> Session: Class initialized using 'files' driver.
INFO - 2024-04-20 12:23:45 --> Parser Class Initialized
INFO - 2024-04-20 12:23:45 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-04-20 12:23:45 --> Pagination Class Initialized
INFO - 2024-04-20 12:23:45 --> Form Validation Class Initialized
INFO - 2024-04-20 12:23:45 --> Controller Class Initialized
INFO - 2024-04-20 12:23:45 --> Model Class Initialized
INFO - 2024-04-20 12:23:45 --> Model Class Initialized
INFO - 2024-04-20 12:23:45 --> Final output sent to browser
DEBUG - 2024-04-20 12:23:45 --> Total execution time: 0.0419
ERROR - 2024-04-20 12:23:47 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-04-20 12:23:47 --> Config Class Initialized
INFO - 2024-04-20 12:23:47 --> Hooks Class Initialized
DEBUG - 2024-04-20 12:23:47 --> UTF-8 Support Enabled
INFO - 2024-04-20 12:23:47 --> Utf8 Class Initialized
INFO - 2024-04-20 12:23:47 --> URI Class Initialized
INFO - 2024-04-20 12:23:47 --> Router Class Initialized
INFO - 2024-04-20 12:23:47 --> Output Class Initialized
INFO - 2024-04-20 12:23:47 --> Security Class Initialized
DEBUG - 2024-04-20 12:23:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-04-20 12:23:47 --> Input Class Initialized
INFO - 2024-04-20 12:23:47 --> Language Class Initialized
INFO - 2024-04-20 12:23:47 --> Loader Class Initialized
INFO - 2024-04-20 12:23:47 --> Helper loaded: url_helper
INFO - 2024-04-20 12:23:47 --> Helper loaded: file_helper
INFO - 2024-04-20 12:23:47 --> Helper loaded: html_helper
INFO - 2024-04-20 12:23:47 --> Helper loaded: text_helper
INFO - 2024-04-20 12:23:47 --> Helper loaded: form_helper
INFO - 2024-04-20 12:23:47 --> Helper loaded: lang_helper
INFO - 2024-04-20 12:23:47 --> Helper loaded: security_helper
INFO - 2024-04-20 12:23:47 --> Helper loaded: cookie_helper
INFO - 2024-04-20 12:23:47 --> Database Driver Class Initialized
INFO - 2024-04-20 12:23:47 --> Session: Class initialized using 'files' driver.
INFO - 2024-04-20 12:23:47 --> Parser Class Initialized
INFO - 2024-04-20 12:23:47 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-04-20 12:23:47 --> Pagination Class Initialized
INFO - 2024-04-20 12:23:47 --> Form Validation Class Initialized
INFO - 2024-04-20 12:23:47 --> Controller Class Initialized
INFO - 2024-04-20 12:23:47 --> Model Class Initialized
INFO - 2024-04-20 12:23:47 --> Model Class Initialized
INFO - 2024-04-20 12:23:47 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/purchase/purchase_html.php
DEBUG - 2024-04-20 12:23:47 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-04-20 12:23:47 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-04-20 12:23:47 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-04-20 12:23:47 --> Model Class Initialized
INFO - 2024-04-20 12:23:47 --> Model Class Initialized
INFO - 2024-04-20 12:23:47 --> Model Class Initialized
INFO - 2024-04-20 12:23:47 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-04-20 12:23:47 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-04-20 12:23:47 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-04-20 12:23:47 --> Final output sent to browser
DEBUG - 2024-04-20 12:23:47 --> Total execution time: 0.2906
ERROR - 2024-04-20 12:23:53 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-04-20 12:23:53 --> Config Class Initialized
INFO - 2024-04-20 12:23:53 --> Hooks Class Initialized
DEBUG - 2024-04-20 12:23:53 --> UTF-8 Support Enabled
INFO - 2024-04-20 12:23:53 --> Utf8 Class Initialized
INFO - 2024-04-20 12:23:53 --> URI Class Initialized
INFO - 2024-04-20 12:23:53 --> Router Class Initialized
INFO - 2024-04-20 12:23:53 --> Output Class Initialized
INFO - 2024-04-20 12:23:53 --> Security Class Initialized
DEBUG - 2024-04-20 12:23:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-04-20 12:23:53 --> Input Class Initialized
INFO - 2024-04-20 12:23:53 --> Language Class Initialized
INFO - 2024-04-20 12:23:53 --> Loader Class Initialized
INFO - 2024-04-20 12:23:53 --> Helper loaded: url_helper
INFO - 2024-04-20 12:23:53 --> Helper loaded: file_helper
INFO - 2024-04-20 12:23:53 --> Helper loaded: html_helper
INFO - 2024-04-20 12:23:53 --> Helper loaded: text_helper
INFO - 2024-04-20 12:23:53 --> Helper loaded: form_helper
INFO - 2024-04-20 12:23:53 --> Helper loaded: lang_helper
INFO - 2024-04-20 12:23:53 --> Helper loaded: security_helper
INFO - 2024-04-20 12:23:53 --> Helper loaded: cookie_helper
INFO - 2024-04-20 12:23:53 --> Database Driver Class Initialized
INFO - 2024-04-20 12:23:53 --> Session: Class initialized using 'files' driver.
INFO - 2024-04-20 12:23:53 --> Parser Class Initialized
INFO - 2024-04-20 12:23:53 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-04-20 12:23:53 --> Pagination Class Initialized
INFO - 2024-04-20 12:23:53 --> Form Validation Class Initialized
INFO - 2024-04-20 12:23:53 --> Controller Class Initialized
DEBUG - 2024-04-20 12:23:53 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-04-20 12:23:53 --> Session class already loaded. Second attempt ignored.
INFO - 2024-04-20 12:23:53 --> Model Class Initialized
INFO - 2024-04-20 12:23:53 --> Model Class Initialized
DEBUG - 2024-04-20 12:23:53 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-04-20 12:23:53 --> Session class already loaded. Second attempt ignored.
INFO - 2024-04-20 12:23:53 --> Model Class Initialized
DEBUG - 2024-04-20 12:23:53 --> Session class already loaded. Second attempt ignored.
INFO - 2024-04-20 12:23:53 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/gst/list.php
DEBUG - 2024-04-20 12:23:53 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-04-20 12:23:53 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-04-20 12:23:53 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-04-20 12:23:53 --> Model Class Initialized
INFO - 2024-04-20 12:23:53 --> Model Class Initialized
INFO - 2024-04-20 12:23:53 --> Model Class Initialized
INFO - 2024-04-20 12:23:53 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-04-20 12:23:53 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-04-20 12:23:53 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-04-20 12:23:53 --> Final output sent to browser
DEBUG - 2024-04-20 12:23:53 --> Total execution time: 0.2694
ERROR - 2024-04-20 12:23:59 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-04-20 12:23:59 --> Config Class Initialized
INFO - 2024-04-20 12:23:59 --> Hooks Class Initialized
DEBUG - 2024-04-20 12:23:59 --> UTF-8 Support Enabled
INFO - 2024-04-20 12:23:59 --> Utf8 Class Initialized
INFO - 2024-04-20 12:23:59 --> URI Class Initialized
INFO - 2024-04-20 12:23:59 --> Router Class Initialized
INFO - 2024-04-20 12:23:59 --> Output Class Initialized
INFO - 2024-04-20 12:23:59 --> Security Class Initialized
DEBUG - 2024-04-20 12:23:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-04-20 12:23:59 --> Input Class Initialized
INFO - 2024-04-20 12:23:59 --> Language Class Initialized
INFO - 2024-04-20 12:23:59 --> Loader Class Initialized
INFO - 2024-04-20 12:23:59 --> Helper loaded: url_helper
INFO - 2024-04-20 12:23:59 --> Helper loaded: file_helper
INFO - 2024-04-20 12:23:59 --> Helper loaded: html_helper
INFO - 2024-04-20 12:23:59 --> Helper loaded: text_helper
INFO - 2024-04-20 12:23:59 --> Helper loaded: form_helper
INFO - 2024-04-20 12:23:59 --> Helper loaded: lang_helper
INFO - 2024-04-20 12:23:59 --> Helper loaded: security_helper
INFO - 2024-04-20 12:23:59 --> Helper loaded: cookie_helper
INFO - 2024-04-20 12:23:59 --> Database Driver Class Initialized
INFO - 2024-04-20 12:23:59 --> Session: Class initialized using 'files' driver.
INFO - 2024-04-20 12:23:59 --> Parser Class Initialized
INFO - 2024-04-20 12:23:59 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-04-20 12:23:59 --> Pagination Class Initialized
INFO - 2024-04-20 12:23:59 --> Form Validation Class Initialized
INFO - 2024-04-20 12:23:59 --> Controller Class Initialized
INFO - 2024-04-20 12:23:59 --> Model Class Initialized
DEBUG - 2024-04-20 12:23:59 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-04-20 12:23:59 --> Session class already loaded. Second attempt ignored.
INFO - 2024-04-20 12:23:59 --> Model Class Initialized
DEBUG - 2024-04-20 12:23:59 --> Session class already loaded. Second attempt ignored.
INFO - 2024-04-20 12:23:59 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/stockrequest/add_stockrequest_form.php
DEBUG - 2024-04-20 12:23:59 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-04-20 12:23:59 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-04-20 12:23:59 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-04-20 12:23:59 --> Model Class Initialized
INFO - 2024-04-20 12:23:59 --> Model Class Initialized
INFO - 2024-04-20 12:23:59 --> Model Class Initialized
INFO - 2024-04-20 12:23:59 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-04-20 12:23:59 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-04-20 12:23:59 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-04-20 12:23:59 --> Final output sent to browser
DEBUG - 2024-04-20 12:23:59 --> Total execution time: 0.5715
ERROR - 2024-04-20 12:24:08 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-04-20 12:24:08 --> Config Class Initialized
INFO - 2024-04-20 12:24:08 --> Hooks Class Initialized
DEBUG - 2024-04-20 12:24:08 --> UTF-8 Support Enabled
INFO - 2024-04-20 12:24:08 --> Utf8 Class Initialized
INFO - 2024-04-20 12:24:08 --> URI Class Initialized
INFO - 2024-04-20 12:24:08 --> Router Class Initialized
INFO - 2024-04-20 12:24:08 --> Output Class Initialized
INFO - 2024-04-20 12:24:08 --> Security Class Initialized
DEBUG - 2024-04-20 12:24:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-04-20 12:24:08 --> Input Class Initialized
INFO - 2024-04-20 12:24:08 --> Language Class Initialized
INFO - 2024-04-20 12:24:08 --> Loader Class Initialized
INFO - 2024-04-20 12:24:08 --> Helper loaded: url_helper
INFO - 2024-04-20 12:24:08 --> Helper loaded: file_helper
INFO - 2024-04-20 12:24:08 --> Helper loaded: html_helper
INFO - 2024-04-20 12:24:08 --> Helper loaded: text_helper
INFO - 2024-04-20 12:24:08 --> Helper loaded: form_helper
INFO - 2024-04-20 12:24:08 --> Helper loaded: lang_helper
INFO - 2024-04-20 12:24:08 --> Helper loaded: security_helper
INFO - 2024-04-20 12:24:08 --> Helper loaded: cookie_helper
INFO - 2024-04-20 12:24:08 --> Database Driver Class Initialized
INFO - 2024-04-20 12:24:08 --> Session: Class initialized using 'files' driver.
INFO - 2024-04-20 12:24:08 --> Parser Class Initialized
INFO - 2024-04-20 12:24:08 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-04-20 12:24:08 --> Pagination Class Initialized
INFO - 2024-04-20 12:24:08 --> Form Validation Class Initialized
INFO - 2024-04-20 12:24:08 --> Controller Class Initialized
INFO - 2024-04-20 12:24:08 --> Model Class Initialized
INFO - 2024-04-20 12:24:08 --> Final output sent to browser
DEBUG - 2024-04-20 12:24:08 --> Total execution time: 0.0159
ERROR - 2024-04-20 12:24:16 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-04-20 12:24:16 --> Config Class Initialized
INFO - 2024-04-20 12:24:16 --> Hooks Class Initialized
DEBUG - 2024-04-20 12:24:16 --> UTF-8 Support Enabled
INFO - 2024-04-20 12:24:16 --> Utf8 Class Initialized
INFO - 2024-04-20 12:24:16 --> URI Class Initialized
INFO - 2024-04-20 12:24:16 --> Router Class Initialized
INFO - 2024-04-20 12:24:16 --> Output Class Initialized
INFO - 2024-04-20 12:24:16 --> Security Class Initialized
DEBUG - 2024-04-20 12:24:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-04-20 12:24:16 --> Input Class Initialized
INFO - 2024-04-20 12:24:16 --> Language Class Initialized
INFO - 2024-04-20 12:24:16 --> Loader Class Initialized
INFO - 2024-04-20 12:24:16 --> Helper loaded: url_helper
INFO - 2024-04-20 12:24:16 --> Helper loaded: file_helper
INFO - 2024-04-20 12:24:16 --> Helper loaded: html_helper
INFO - 2024-04-20 12:24:16 --> Helper loaded: text_helper
INFO - 2024-04-20 12:24:16 --> Helper loaded: form_helper
INFO - 2024-04-20 12:24:16 --> Helper loaded: lang_helper
INFO - 2024-04-20 12:24:16 --> Helper loaded: security_helper
INFO - 2024-04-20 12:24:16 --> Helper loaded: cookie_helper
INFO - 2024-04-20 12:24:16 --> Database Driver Class Initialized
INFO - 2024-04-20 12:24:16 --> Session: Class initialized using 'files' driver.
INFO - 2024-04-20 12:24:16 --> Parser Class Initialized
INFO - 2024-04-20 12:24:16 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-04-20 12:24:16 --> Pagination Class Initialized
INFO - 2024-04-20 12:24:16 --> Form Validation Class Initialized
INFO - 2024-04-20 12:24:16 --> Controller Class Initialized
INFO - 2024-04-20 12:24:16 --> Model Class Initialized
DEBUG - 2024-04-20 12:24:16 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-04-20 12:24:16 --> Session class already loaded. Second attempt ignored.
INFO - 2024-04-20 12:24:16 --> Model Class Initialized
DEBUG - 2024-04-20 12:24:16 --> Session class already loaded. Second attempt ignored.
INFO - 2024-04-20 12:24:16 --> Model Class Initialized
INFO - 2024-04-20 12:24:16 --> Final output sent to browser
DEBUG - 2024-04-20 12:24:16 --> Total execution time: 0.0175
ERROR - 2024-04-20 12:24:20 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-04-20 12:24:20 --> Config Class Initialized
INFO - 2024-04-20 12:24:20 --> Hooks Class Initialized
DEBUG - 2024-04-20 12:24:20 --> UTF-8 Support Enabled
INFO - 2024-04-20 12:24:20 --> Utf8 Class Initialized
INFO - 2024-04-20 12:24:20 --> URI Class Initialized
INFO - 2024-04-20 12:24:20 --> Router Class Initialized
INFO - 2024-04-20 12:24:20 --> Output Class Initialized
INFO - 2024-04-20 12:24:20 --> Security Class Initialized
DEBUG - 2024-04-20 12:24:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-04-20 12:24:20 --> Input Class Initialized
INFO - 2024-04-20 12:24:20 --> Language Class Initialized
INFO - 2024-04-20 12:24:20 --> Loader Class Initialized
INFO - 2024-04-20 12:24:20 --> Helper loaded: url_helper
INFO - 2024-04-20 12:24:20 --> Helper loaded: file_helper
INFO - 2024-04-20 12:24:20 --> Helper loaded: html_helper
INFO - 2024-04-20 12:24:20 --> Helper loaded: text_helper
INFO - 2024-04-20 12:24:20 --> Helper loaded: form_helper
INFO - 2024-04-20 12:24:20 --> Helper loaded: lang_helper
INFO - 2024-04-20 12:24:20 --> Helper loaded: security_helper
INFO - 2024-04-20 12:24:20 --> Helper loaded: cookie_helper
INFO - 2024-04-20 12:24:20 --> Database Driver Class Initialized
INFO - 2024-04-20 12:24:21 --> Session: Class initialized using 'files' driver.
INFO - 2024-04-20 12:24:21 --> Parser Class Initialized
INFO - 2024-04-20 12:24:21 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-04-20 12:24:21 --> Pagination Class Initialized
INFO - 2024-04-20 12:24:21 --> Form Validation Class Initialized
INFO - 2024-04-20 12:24:21 --> Controller Class Initialized
INFO - 2024-04-20 12:24:21 --> Model Class Initialized
DEBUG - 2024-04-20 12:24:21 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-04-20 12:24:21 --> Session class already loaded. Second attempt ignored.
INFO - 2024-04-20 12:24:21 --> Model Class Initialized
DEBUG - 2024-04-20 12:24:21 --> Session class already loaded. Second attempt ignored.
INFO - 2024-04-20 12:24:21 --> Model Class Initialized
INFO - 2024-04-20 12:24:21 --> Model Class Initialized
INFO - 2024-04-20 12:24:21 --> Final output sent to browser
DEBUG - 2024-04-20 12:24:21 --> Total execution time: 0.2505
ERROR - 2024-04-20 12:24:26 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-04-20 12:24:26 --> Config Class Initialized
INFO - 2024-04-20 12:24:26 --> Hooks Class Initialized
DEBUG - 2024-04-20 12:24:26 --> UTF-8 Support Enabled
INFO - 2024-04-20 12:24:26 --> Utf8 Class Initialized
INFO - 2024-04-20 12:24:26 --> URI Class Initialized
INFO - 2024-04-20 12:24:26 --> Router Class Initialized
INFO - 2024-04-20 12:24:26 --> Output Class Initialized
INFO - 2024-04-20 12:24:26 --> Security Class Initialized
DEBUG - 2024-04-20 12:24:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-04-20 12:24:26 --> Input Class Initialized
INFO - 2024-04-20 12:24:26 --> Language Class Initialized
INFO - 2024-04-20 12:24:26 --> Loader Class Initialized
INFO - 2024-04-20 12:24:26 --> Helper loaded: url_helper
INFO - 2024-04-20 12:24:26 --> Helper loaded: file_helper
INFO - 2024-04-20 12:24:26 --> Helper loaded: html_helper
INFO - 2024-04-20 12:24:26 --> Helper loaded: text_helper
INFO - 2024-04-20 12:24:26 --> Helper loaded: form_helper
INFO - 2024-04-20 12:24:26 --> Helper loaded: lang_helper
INFO - 2024-04-20 12:24:26 --> Helper loaded: security_helper
INFO - 2024-04-20 12:24:26 --> Helper loaded: cookie_helper
INFO - 2024-04-20 12:24:26 --> Database Driver Class Initialized
INFO - 2024-04-20 12:24:26 --> Session: Class initialized using 'files' driver.
INFO - 2024-04-20 12:24:26 --> Parser Class Initialized
INFO - 2024-04-20 12:24:26 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-04-20 12:24:26 --> Pagination Class Initialized
INFO - 2024-04-20 12:24:26 --> Form Validation Class Initialized
INFO - 2024-04-20 12:24:26 --> Controller Class Initialized
INFO - 2024-04-20 12:24:26 --> Model Class Initialized
DEBUG - 2024-04-20 12:24:26 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-04-20 12:24:26 --> Session class already loaded. Second attempt ignored.
INFO - 2024-04-20 12:24:26 --> Model Class Initialized
DEBUG - 2024-04-20 12:24:26 --> Session class already loaded. Second attempt ignored.
INFO - 2024-04-20 12:24:26 --> Model Class Initialized
INFO - 2024-04-20 12:24:26 --> Final output sent to browser
DEBUG - 2024-04-20 12:24:26 --> Total execution time: 0.0204
ERROR - 2024-04-20 12:24:29 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-04-20 12:24:29 --> Config Class Initialized
INFO - 2024-04-20 12:24:29 --> Hooks Class Initialized
DEBUG - 2024-04-20 12:24:29 --> UTF-8 Support Enabled
INFO - 2024-04-20 12:24:29 --> Utf8 Class Initialized
INFO - 2024-04-20 12:24:29 --> URI Class Initialized
INFO - 2024-04-20 12:24:29 --> Router Class Initialized
INFO - 2024-04-20 12:24:29 --> Output Class Initialized
INFO - 2024-04-20 12:24:29 --> Security Class Initialized
DEBUG - 2024-04-20 12:24:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-04-20 12:24:29 --> Input Class Initialized
INFO - 2024-04-20 12:24:29 --> Language Class Initialized
INFO - 2024-04-20 12:24:29 --> Loader Class Initialized
INFO - 2024-04-20 12:24:29 --> Helper loaded: url_helper
INFO - 2024-04-20 12:24:29 --> Helper loaded: file_helper
INFO - 2024-04-20 12:24:29 --> Helper loaded: html_helper
INFO - 2024-04-20 12:24:29 --> Helper loaded: text_helper
INFO - 2024-04-20 12:24:29 --> Helper loaded: form_helper
INFO - 2024-04-20 12:24:29 --> Helper loaded: lang_helper
INFO - 2024-04-20 12:24:29 --> Helper loaded: security_helper
INFO - 2024-04-20 12:24:29 --> Helper loaded: cookie_helper
INFO - 2024-04-20 12:24:29 --> Database Driver Class Initialized
INFO - 2024-04-20 12:24:29 --> Session: Class initialized using 'files' driver.
INFO - 2024-04-20 12:24:29 --> Parser Class Initialized
INFO - 2024-04-20 12:24:29 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-04-20 12:24:29 --> Pagination Class Initialized
INFO - 2024-04-20 12:24:29 --> Form Validation Class Initialized
INFO - 2024-04-20 12:24:29 --> Controller Class Initialized
INFO - 2024-04-20 12:24:29 --> Model Class Initialized
DEBUG - 2024-04-20 12:24:29 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-04-20 12:24:29 --> Session class already loaded. Second attempt ignored.
INFO - 2024-04-20 12:24:29 --> Model Class Initialized
DEBUG - 2024-04-20 12:24:29 --> Session class already loaded. Second attempt ignored.
INFO - 2024-04-20 12:24:29 --> Model Class Initialized
INFO - 2024-04-20 12:24:29 --> Final output sent to browser
DEBUG - 2024-04-20 12:24:29 --> Total execution time: 0.0193
ERROR - 2024-04-20 12:24:37 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-04-20 12:24:37 --> Config Class Initialized
INFO - 2024-04-20 12:24:37 --> Hooks Class Initialized
DEBUG - 2024-04-20 12:24:37 --> UTF-8 Support Enabled
INFO - 2024-04-20 12:24:37 --> Utf8 Class Initialized
INFO - 2024-04-20 12:24:37 --> URI Class Initialized
INFO - 2024-04-20 12:24:37 --> Router Class Initialized
INFO - 2024-04-20 12:24:37 --> Output Class Initialized
INFO - 2024-04-20 12:24:37 --> Security Class Initialized
DEBUG - 2024-04-20 12:24:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-04-20 12:24:37 --> Input Class Initialized
INFO - 2024-04-20 12:24:37 --> Language Class Initialized
INFO - 2024-04-20 12:24:37 --> Loader Class Initialized
INFO - 2024-04-20 12:24:37 --> Helper loaded: url_helper
INFO - 2024-04-20 12:24:37 --> Helper loaded: file_helper
INFO - 2024-04-20 12:24:37 --> Helper loaded: html_helper
INFO - 2024-04-20 12:24:37 --> Helper loaded: text_helper
INFO - 2024-04-20 12:24:37 --> Helper loaded: form_helper
INFO - 2024-04-20 12:24:37 --> Helper loaded: lang_helper
INFO - 2024-04-20 12:24:37 --> Helper loaded: security_helper
INFO - 2024-04-20 12:24:37 --> Helper loaded: cookie_helper
INFO - 2024-04-20 12:24:37 --> Database Driver Class Initialized
INFO - 2024-04-20 12:24:37 --> Session: Class initialized using 'files' driver.
INFO - 2024-04-20 12:24:37 --> Parser Class Initialized
INFO - 2024-04-20 12:24:37 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-04-20 12:24:37 --> Pagination Class Initialized
INFO - 2024-04-20 12:24:37 --> Form Validation Class Initialized
INFO - 2024-04-20 12:24:37 --> Controller Class Initialized
INFO - 2024-04-20 12:24:37 --> Model Class Initialized
DEBUG - 2024-04-20 12:24:37 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-04-20 12:24:37 --> Session class already loaded. Second attempt ignored.
INFO - 2024-04-20 12:24:37 --> Model Class Initialized
DEBUG - 2024-04-20 12:24:37 --> Session class already loaded. Second attempt ignored.
INFO - 2024-04-20 12:24:37 --> Model Class Initialized
INFO - 2024-04-20 12:24:37 --> Final output sent to browser
DEBUG - 2024-04-20 12:24:37 --> Total execution time: 0.0205
ERROR - 2024-04-20 12:24:46 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-04-20 12:24:46 --> Config Class Initialized
INFO - 2024-04-20 12:24:46 --> Hooks Class Initialized
DEBUG - 2024-04-20 12:24:46 --> UTF-8 Support Enabled
INFO - 2024-04-20 12:24:46 --> Utf8 Class Initialized
INFO - 2024-04-20 12:24:46 --> URI Class Initialized
INFO - 2024-04-20 12:24:46 --> Router Class Initialized
INFO - 2024-04-20 12:24:46 --> Output Class Initialized
INFO - 2024-04-20 12:24:46 --> Security Class Initialized
DEBUG - 2024-04-20 12:24:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-04-20 12:24:46 --> Input Class Initialized
INFO - 2024-04-20 12:24:46 --> Language Class Initialized
INFO - 2024-04-20 12:24:46 --> Loader Class Initialized
INFO - 2024-04-20 12:24:46 --> Helper loaded: url_helper
INFO - 2024-04-20 12:24:46 --> Helper loaded: file_helper
INFO - 2024-04-20 12:24:46 --> Helper loaded: html_helper
INFO - 2024-04-20 12:24:46 --> Helper loaded: text_helper
INFO - 2024-04-20 12:24:46 --> Helper loaded: form_helper
INFO - 2024-04-20 12:24:46 --> Helper loaded: lang_helper
INFO - 2024-04-20 12:24:46 --> Helper loaded: security_helper
INFO - 2024-04-20 12:24:46 --> Helper loaded: cookie_helper
INFO - 2024-04-20 12:24:46 --> Database Driver Class Initialized
INFO - 2024-04-20 12:24:46 --> Session: Class initialized using 'files' driver.
INFO - 2024-04-20 12:24:46 --> Parser Class Initialized
INFO - 2024-04-20 12:24:46 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-04-20 12:24:46 --> Pagination Class Initialized
INFO - 2024-04-20 12:24:46 --> Form Validation Class Initialized
INFO - 2024-04-20 12:24:46 --> Controller Class Initialized
INFO - 2024-04-20 12:24:46 --> Model Class Initialized
INFO - 2024-04-20 12:24:46 --> Model Class Initialized
INFO - 2024-04-20 12:24:46 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/purchase/purchase.php
DEBUG - 2024-04-20 12:24:46 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-04-20 12:24:46 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-04-20 12:24:46 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-04-20 12:24:46 --> Model Class Initialized
INFO - 2024-04-20 12:24:46 --> Model Class Initialized
INFO - 2024-04-20 12:24:46 --> Model Class Initialized
INFO - 2024-04-20 12:24:46 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-04-20 12:24:46 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-04-20 12:24:46 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-04-20 12:24:46 --> Final output sent to browser
DEBUG - 2024-04-20 12:24:46 --> Total execution time: 0.2804
ERROR - 2024-04-20 12:24:46 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-04-20 12:24:46 --> Config Class Initialized
INFO - 2024-04-20 12:24:46 --> Hooks Class Initialized
DEBUG - 2024-04-20 12:24:46 --> UTF-8 Support Enabled
INFO - 2024-04-20 12:24:46 --> Utf8 Class Initialized
INFO - 2024-04-20 12:24:46 --> URI Class Initialized
INFO - 2024-04-20 12:24:46 --> Router Class Initialized
INFO - 2024-04-20 12:24:46 --> Output Class Initialized
INFO - 2024-04-20 12:24:46 --> Security Class Initialized
DEBUG - 2024-04-20 12:24:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-04-20 12:24:46 --> Input Class Initialized
INFO - 2024-04-20 12:24:46 --> Language Class Initialized
INFO - 2024-04-20 12:24:46 --> Loader Class Initialized
INFO - 2024-04-20 12:24:46 --> Helper loaded: url_helper
INFO - 2024-04-20 12:24:46 --> Helper loaded: file_helper
INFO - 2024-04-20 12:24:46 --> Helper loaded: html_helper
INFO - 2024-04-20 12:24:46 --> Helper loaded: text_helper
INFO - 2024-04-20 12:24:46 --> Helper loaded: form_helper
INFO - 2024-04-20 12:24:46 --> Helper loaded: lang_helper
INFO - 2024-04-20 12:24:46 --> Helper loaded: security_helper
INFO - 2024-04-20 12:24:46 --> Helper loaded: cookie_helper
INFO - 2024-04-20 12:24:46 --> Database Driver Class Initialized
INFO - 2024-04-20 12:24:46 --> Session: Class initialized using 'files' driver.
INFO - 2024-04-20 12:24:46 --> Parser Class Initialized
INFO - 2024-04-20 12:24:46 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-04-20 12:24:46 --> Pagination Class Initialized
INFO - 2024-04-20 12:24:46 --> Form Validation Class Initialized
INFO - 2024-04-20 12:24:46 --> Controller Class Initialized
INFO - 2024-04-20 12:24:46 --> Model Class Initialized
INFO - 2024-04-20 12:24:46 --> Model Class Initialized
INFO - 2024-04-20 12:24:46 --> Final output sent to browser
DEBUG - 2024-04-20 12:24:46 --> Total execution time: 0.2490
ERROR - 2024-04-20 12:24:49 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-04-20 12:24:49 --> Config Class Initialized
INFO - 2024-04-20 12:24:49 --> Hooks Class Initialized
DEBUG - 2024-04-20 12:24:49 --> UTF-8 Support Enabled
INFO - 2024-04-20 12:24:49 --> Utf8 Class Initialized
INFO - 2024-04-20 12:24:49 --> URI Class Initialized
INFO - 2024-04-20 12:24:49 --> Router Class Initialized
INFO - 2024-04-20 12:24:49 --> Output Class Initialized
INFO - 2024-04-20 12:24:49 --> Security Class Initialized
DEBUG - 2024-04-20 12:24:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-04-20 12:24:49 --> Input Class Initialized
INFO - 2024-04-20 12:24:49 --> Language Class Initialized
INFO - 2024-04-20 12:24:49 --> Loader Class Initialized
INFO - 2024-04-20 12:24:49 --> Helper loaded: url_helper
INFO - 2024-04-20 12:24:49 --> Helper loaded: file_helper
INFO - 2024-04-20 12:24:49 --> Helper loaded: html_helper
INFO - 2024-04-20 12:24:49 --> Helper loaded: text_helper
INFO - 2024-04-20 12:24:49 --> Helper loaded: form_helper
INFO - 2024-04-20 12:24:49 --> Helper loaded: lang_helper
INFO - 2024-04-20 12:24:49 --> Helper loaded: security_helper
INFO - 2024-04-20 12:24:49 --> Helper loaded: cookie_helper
INFO - 2024-04-20 12:24:49 --> Database Driver Class Initialized
INFO - 2024-04-20 12:24:49 --> Session: Class initialized using 'files' driver.
INFO - 2024-04-20 12:24:49 --> Parser Class Initialized
INFO - 2024-04-20 12:24:49 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-04-20 12:24:49 --> Pagination Class Initialized
INFO - 2024-04-20 12:24:49 --> Form Validation Class Initialized
INFO - 2024-04-20 12:24:49 --> Controller Class Initialized
INFO - 2024-04-20 12:24:49 --> Model Class Initialized
INFO - 2024-04-20 12:24:49 --> Model Class Initialized
INFO - 2024-04-20 12:24:49 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/purchase/purchase_html.php
DEBUG - 2024-04-20 12:24:49 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-04-20 12:24:49 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-04-20 12:24:49 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-04-20 12:24:49 --> Model Class Initialized
INFO - 2024-04-20 12:24:49 --> Model Class Initialized
INFO - 2024-04-20 12:24:49 --> Model Class Initialized
INFO - 2024-04-20 12:24:49 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-04-20 12:24:49 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-04-20 12:24:49 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-04-20 12:24:49 --> Final output sent to browser
DEBUG - 2024-04-20 12:24:49 --> Total execution time: 0.3116
ERROR - 2024-04-20 12:24:50 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-04-20 12:24:50 --> Config Class Initialized
INFO - 2024-04-20 12:24:50 --> Hooks Class Initialized
DEBUG - 2024-04-20 12:24:50 --> UTF-8 Support Enabled
INFO - 2024-04-20 12:24:50 --> Utf8 Class Initialized
INFO - 2024-04-20 12:24:50 --> URI Class Initialized
INFO - 2024-04-20 12:24:50 --> Router Class Initialized
INFO - 2024-04-20 12:24:50 --> Output Class Initialized
INFO - 2024-04-20 12:24:50 --> Security Class Initialized
DEBUG - 2024-04-20 12:24:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-04-20 12:24:50 --> Input Class Initialized
INFO - 2024-04-20 12:24:50 --> Language Class Initialized
INFO - 2024-04-20 12:24:50 --> Loader Class Initialized
INFO - 2024-04-20 12:24:50 --> Helper loaded: url_helper
INFO - 2024-04-20 12:24:50 --> Helper loaded: file_helper
INFO - 2024-04-20 12:24:50 --> Helper loaded: html_helper
INFO - 2024-04-20 12:24:50 --> Helper loaded: text_helper
INFO - 2024-04-20 12:24:50 --> Helper loaded: form_helper
INFO - 2024-04-20 12:24:50 --> Helper loaded: lang_helper
INFO - 2024-04-20 12:24:50 --> Helper loaded: security_helper
INFO - 2024-04-20 12:24:50 --> Helper loaded: cookie_helper
INFO - 2024-04-20 12:24:50 --> Database Driver Class Initialized
INFO - 2024-04-20 12:24:50 --> Session: Class initialized using 'files' driver.
INFO - 2024-04-20 12:24:50 --> Parser Class Initialized
INFO - 2024-04-20 12:24:50 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-04-20 12:24:50 --> Pagination Class Initialized
INFO - 2024-04-20 12:24:50 --> Form Validation Class Initialized
INFO - 2024-04-20 12:24:50 --> Controller Class Initialized
INFO - 2024-04-20 12:24:50 --> Model Class Initialized
INFO - 2024-04-20 12:24:50 --> Model Class Initialized
INFO - 2024-04-20 12:24:50 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/purchase/purchase_html.php
DEBUG - 2024-04-20 12:24:50 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-04-20 12:24:50 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-04-20 12:24:50 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-04-20 12:24:50 --> Model Class Initialized
INFO - 2024-04-20 12:24:50 --> Model Class Initialized
INFO - 2024-04-20 12:24:50 --> Model Class Initialized
INFO - 2024-04-20 12:24:50 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-04-20 12:24:50 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-04-20 12:24:50 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-04-20 12:24:50 --> Final output sent to browser
DEBUG - 2024-04-20 12:24:50 --> Total execution time: 0.2841
ERROR - 2024-04-20 12:25:01 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-04-20 12:25:01 --> Config Class Initialized
INFO - 2024-04-20 12:25:01 --> Hooks Class Initialized
DEBUG - 2024-04-20 12:25:01 --> UTF-8 Support Enabled
INFO - 2024-04-20 12:25:01 --> Utf8 Class Initialized
INFO - 2024-04-20 12:25:01 --> URI Class Initialized
INFO - 2024-04-20 12:25:01 --> Router Class Initialized
INFO - 2024-04-20 12:25:01 --> Output Class Initialized
INFO - 2024-04-20 12:25:01 --> Security Class Initialized
DEBUG - 2024-04-20 12:25:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-04-20 12:25:01 --> Input Class Initialized
INFO - 2024-04-20 12:25:01 --> Language Class Initialized
INFO - 2024-04-20 12:25:01 --> Loader Class Initialized
INFO - 2024-04-20 12:25:01 --> Helper loaded: url_helper
INFO - 2024-04-20 12:25:01 --> Helper loaded: file_helper
INFO - 2024-04-20 12:25:01 --> Helper loaded: html_helper
INFO - 2024-04-20 12:25:01 --> Helper loaded: text_helper
INFO - 2024-04-20 12:25:01 --> Helper loaded: form_helper
INFO - 2024-04-20 12:25:01 --> Helper loaded: lang_helper
INFO - 2024-04-20 12:25:01 --> Helper loaded: security_helper
INFO - 2024-04-20 12:25:01 --> Helper loaded: cookie_helper
INFO - 2024-04-20 12:25:01 --> Database Driver Class Initialized
INFO - 2024-04-20 12:25:01 --> Session: Class initialized using 'files' driver.
INFO - 2024-04-20 12:25:01 --> Parser Class Initialized
INFO - 2024-04-20 12:25:01 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-04-20 12:25:01 --> Pagination Class Initialized
INFO - 2024-04-20 12:25:01 --> Form Validation Class Initialized
INFO - 2024-04-20 12:25:01 --> Controller Class Initialized
INFO - 2024-04-20 12:25:01 --> Model Class Initialized
INFO - 2024-04-20 12:25:01 --> Model Class Initialized
ERROR - 2024-04-20 12:25:01 --> Severity: Warning --> Invalid argument supplied for foreach() /home/powera7m/app.maurnaturo.com/application/views/purchase/add_purchase_form.php 157
INFO - 2024-04-20 12:25:01 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/purchase/add_purchase_form.php
DEBUG - 2024-04-20 12:25:01 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-04-20 12:25:01 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-04-20 12:25:01 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-04-20 12:25:01 --> Model Class Initialized
INFO - 2024-04-20 12:25:01 --> Model Class Initialized
INFO - 2024-04-20 12:25:01 --> Model Class Initialized
INFO - 2024-04-20 12:25:02 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-04-20 12:25:02 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-04-20 12:25:02 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-04-20 12:25:02 --> Final output sent to browser
DEBUG - 2024-04-20 12:25:02 --> Total execution time: 0.3306
ERROR - 2024-04-20 12:25:13 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-04-20 12:25:13 --> Config Class Initialized
INFO - 2024-04-20 12:25:13 --> Hooks Class Initialized
DEBUG - 2024-04-20 12:25:13 --> UTF-8 Support Enabled
INFO - 2024-04-20 12:25:13 --> Utf8 Class Initialized
INFO - 2024-04-20 12:25:13 --> URI Class Initialized
INFO - 2024-04-20 12:25:13 --> Router Class Initialized
INFO - 2024-04-20 12:25:13 --> Output Class Initialized
INFO - 2024-04-20 12:25:13 --> Security Class Initialized
DEBUG - 2024-04-20 12:25:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-04-20 12:25:13 --> Input Class Initialized
INFO - 2024-04-20 12:25:13 --> Language Class Initialized
INFO - 2024-04-20 12:25:13 --> Loader Class Initialized
INFO - 2024-04-20 12:25:13 --> Helper loaded: url_helper
INFO - 2024-04-20 12:25:13 --> Helper loaded: file_helper
INFO - 2024-04-20 12:25:13 --> Helper loaded: html_helper
INFO - 2024-04-20 12:25:13 --> Helper loaded: text_helper
INFO - 2024-04-20 12:25:13 --> Helper loaded: form_helper
INFO - 2024-04-20 12:25:13 --> Helper loaded: lang_helper
INFO - 2024-04-20 12:25:13 --> Helper loaded: security_helper
INFO - 2024-04-20 12:25:13 --> Helper loaded: cookie_helper
INFO - 2024-04-20 12:25:13 --> Database Driver Class Initialized
INFO - 2024-04-20 12:25:13 --> Session: Class initialized using 'files' driver.
INFO - 2024-04-20 12:25:13 --> Parser Class Initialized
INFO - 2024-04-20 12:25:13 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-04-20 12:25:13 --> Pagination Class Initialized
INFO - 2024-04-20 12:25:13 --> Form Validation Class Initialized
INFO - 2024-04-20 12:25:13 --> Controller Class Initialized
INFO - 2024-04-20 12:25:13 --> Model Class Initialized
INFO - 2024-04-20 12:25:13 --> Final output sent to browser
DEBUG - 2024-04-20 12:25:13 --> Total execution time: 0.0165
ERROR - 2024-04-20 12:25:14 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-04-20 12:25:14 --> Config Class Initialized
INFO - 2024-04-20 12:25:14 --> Hooks Class Initialized
DEBUG - 2024-04-20 12:25:14 --> UTF-8 Support Enabled
INFO - 2024-04-20 12:25:14 --> Utf8 Class Initialized
INFO - 2024-04-20 12:25:14 --> URI Class Initialized
INFO - 2024-04-20 12:25:14 --> Router Class Initialized
INFO - 2024-04-20 12:25:14 --> Output Class Initialized
INFO - 2024-04-20 12:25:14 --> Security Class Initialized
DEBUG - 2024-04-20 12:25:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-04-20 12:25:14 --> Input Class Initialized
INFO - 2024-04-20 12:25:14 --> Language Class Initialized
INFO - 2024-04-20 12:25:14 --> Loader Class Initialized
INFO - 2024-04-20 12:25:14 --> Helper loaded: url_helper
INFO - 2024-04-20 12:25:14 --> Helper loaded: file_helper
INFO - 2024-04-20 12:25:14 --> Helper loaded: html_helper
INFO - 2024-04-20 12:25:14 --> Helper loaded: text_helper
INFO - 2024-04-20 12:25:14 --> Helper loaded: form_helper
INFO - 2024-04-20 12:25:14 --> Helper loaded: lang_helper
INFO - 2024-04-20 12:25:14 --> Helper loaded: security_helper
INFO - 2024-04-20 12:25:14 --> Helper loaded: cookie_helper
INFO - 2024-04-20 12:25:14 --> Database Driver Class Initialized
INFO - 2024-04-20 12:25:14 --> Session: Class initialized using 'files' driver.
INFO - 2024-04-20 12:25:14 --> Parser Class Initialized
INFO - 2024-04-20 12:25:14 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-04-20 12:25:14 --> Pagination Class Initialized
INFO - 2024-04-20 12:25:14 --> Form Validation Class Initialized
INFO - 2024-04-20 12:25:14 --> Controller Class Initialized
INFO - 2024-04-20 12:25:14 --> Model Class Initialized
DEBUG - 2024-04-20 12:25:14 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-04-20 12:25:14 --> Session class already loaded. Second attempt ignored.
INFO - 2024-04-20 12:25:14 --> Model Class Initialized
DEBUG - 2024-04-20 12:25:14 --> Session class already loaded. Second attempt ignored.
INFO - 2024-04-20 12:25:14 --> Model Class Initialized
INFO - 2024-04-20 12:25:14 --> Final output sent to browser
DEBUG - 2024-04-20 12:25:14 --> Total execution time: 0.0185
ERROR - 2024-04-20 12:25:30 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-04-20 12:25:30 --> Config Class Initialized
INFO - 2024-04-20 12:25:30 --> Hooks Class Initialized
DEBUG - 2024-04-20 12:25:30 --> UTF-8 Support Enabled
INFO - 2024-04-20 12:25:30 --> Utf8 Class Initialized
INFO - 2024-04-20 12:25:30 --> URI Class Initialized
INFO - 2024-04-20 12:25:30 --> Router Class Initialized
INFO - 2024-04-20 12:25:30 --> Output Class Initialized
INFO - 2024-04-20 12:25:30 --> Security Class Initialized
DEBUG - 2024-04-20 12:25:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-04-20 12:25:30 --> Input Class Initialized
INFO - 2024-04-20 12:25:30 --> Language Class Initialized
INFO - 2024-04-20 12:25:30 --> Loader Class Initialized
INFO - 2024-04-20 12:25:30 --> Helper loaded: url_helper
INFO - 2024-04-20 12:25:30 --> Helper loaded: file_helper
INFO - 2024-04-20 12:25:30 --> Helper loaded: html_helper
INFO - 2024-04-20 12:25:30 --> Helper loaded: text_helper
INFO - 2024-04-20 12:25:30 --> Helper loaded: form_helper
INFO - 2024-04-20 12:25:30 --> Helper loaded: lang_helper
INFO - 2024-04-20 12:25:30 --> Helper loaded: security_helper
INFO - 2024-04-20 12:25:30 --> Helper loaded: cookie_helper
INFO - 2024-04-20 12:25:30 --> Database Driver Class Initialized
INFO - 2024-04-20 12:25:30 --> Session: Class initialized using 'files' driver.
INFO - 2024-04-20 12:25:30 --> Parser Class Initialized
INFO - 2024-04-20 12:25:30 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-04-20 12:25:30 --> Pagination Class Initialized
INFO - 2024-04-20 12:25:30 --> Form Validation Class Initialized
INFO - 2024-04-20 12:25:30 --> Controller Class Initialized
DEBUG - 2024-04-20 12:25:30 --> Auth class already loaded. Second attempt ignored.
INFO - 2024-04-20 12:25:30 --> Model Class Initialized
INFO - 2024-04-20 12:25:30 --> Model Class Initialized
INFO - 2024-04-20 12:25:30 --> Model Class Initialized
INFO - 2024-04-20 12:25:30 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/product/product.php
DEBUG - 2024-04-20 12:25:30 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-04-20 12:25:30 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-04-20 12:25:30 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-04-20 12:25:30 --> Model Class Initialized
INFO - 2024-04-20 12:25:30 --> Model Class Initialized
INFO - 2024-04-20 12:25:30 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-04-20 12:25:30 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-04-20 12:25:30 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-04-20 12:25:30 --> Final output sent to browser
DEBUG - 2024-04-20 12:25:30 --> Total execution time: 0.3165
ERROR - 2024-04-20 12:25:32 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-04-20 12:25:32 --> Config Class Initialized
INFO - 2024-04-20 12:25:32 --> Hooks Class Initialized
DEBUG - 2024-04-20 12:25:32 --> UTF-8 Support Enabled
INFO - 2024-04-20 12:25:32 --> Utf8 Class Initialized
INFO - 2024-04-20 12:25:32 --> URI Class Initialized
INFO - 2024-04-20 12:25:32 --> Router Class Initialized
INFO - 2024-04-20 12:25:32 --> Output Class Initialized
INFO - 2024-04-20 12:25:32 --> Security Class Initialized
DEBUG - 2024-04-20 12:25:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-04-20 12:25:32 --> Input Class Initialized
INFO - 2024-04-20 12:25:32 --> Language Class Initialized
INFO - 2024-04-20 12:25:32 --> Loader Class Initialized
INFO - 2024-04-20 12:25:32 --> Helper loaded: url_helper
INFO - 2024-04-20 12:25:32 --> Helper loaded: file_helper
INFO - 2024-04-20 12:25:32 --> Helper loaded: html_helper
INFO - 2024-04-20 12:25:32 --> Helper loaded: text_helper
INFO - 2024-04-20 12:25:32 --> Helper loaded: form_helper
INFO - 2024-04-20 12:25:32 --> Helper loaded: lang_helper
INFO - 2024-04-20 12:25:32 --> Helper loaded: security_helper
INFO - 2024-04-20 12:25:32 --> Helper loaded: cookie_helper
INFO - 2024-04-20 12:25:32 --> Database Driver Class Initialized
INFO - 2024-04-20 12:25:32 --> Session: Class initialized using 'files' driver.
INFO - 2024-04-20 12:25:32 --> Parser Class Initialized
INFO - 2024-04-20 12:25:32 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-04-20 12:25:32 --> Pagination Class Initialized
INFO - 2024-04-20 12:25:32 --> Form Validation Class Initialized
INFO - 2024-04-20 12:25:32 --> Controller Class Initialized
DEBUG - 2024-04-20 12:25:32 --> Auth class already loaded. Second attempt ignored.
INFO - 2024-04-20 12:25:32 --> Model Class Initialized
INFO - 2024-04-20 12:25:32 --> Model Class Initialized
INFO - 2024-04-20 12:25:32 --> Final output sent to browser
DEBUG - 2024-04-20 12:25:32 --> Total execution time: 0.0562
ERROR - 2024-04-20 12:25:35 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-04-20 12:25:35 --> Config Class Initialized
INFO - 2024-04-20 12:25:35 --> Hooks Class Initialized
DEBUG - 2024-04-20 12:25:35 --> UTF-8 Support Enabled
INFO - 2024-04-20 12:25:35 --> Utf8 Class Initialized
INFO - 2024-04-20 12:25:35 --> URI Class Initialized
INFO - 2024-04-20 12:25:35 --> Router Class Initialized
INFO - 2024-04-20 12:25:35 --> Output Class Initialized
INFO - 2024-04-20 12:25:35 --> Security Class Initialized
DEBUG - 2024-04-20 12:25:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-04-20 12:25:35 --> Input Class Initialized
INFO - 2024-04-20 12:25:35 --> Language Class Initialized
INFO - 2024-04-20 12:25:35 --> Loader Class Initialized
INFO - 2024-04-20 12:25:35 --> Helper loaded: url_helper
INFO - 2024-04-20 12:25:35 --> Helper loaded: file_helper
INFO - 2024-04-20 12:25:35 --> Helper loaded: html_helper
INFO - 2024-04-20 12:25:35 --> Helper loaded: text_helper
INFO - 2024-04-20 12:25:35 --> Helper loaded: form_helper
INFO - 2024-04-20 12:25:35 --> Helper loaded: lang_helper
INFO - 2024-04-20 12:25:35 --> Helper loaded: security_helper
INFO - 2024-04-20 12:25:35 --> Helper loaded: cookie_helper
INFO - 2024-04-20 12:25:35 --> Database Driver Class Initialized
INFO - 2024-04-20 12:25:35 --> Session: Class initialized using 'files' driver.
INFO - 2024-04-20 12:25:35 --> Parser Class Initialized
INFO - 2024-04-20 12:25:35 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-04-20 12:25:35 --> Pagination Class Initialized
INFO - 2024-04-20 12:25:35 --> Form Validation Class Initialized
INFO - 2024-04-20 12:25:35 --> Controller Class Initialized
DEBUG - 2024-04-20 12:25:35 --> Auth class already loaded. Second attempt ignored.
INFO - 2024-04-20 12:25:35 --> Model Class Initialized
INFO - 2024-04-20 12:25:35 --> Model Class Initialized
INFO - 2024-04-20 12:25:35 --> Final output sent to browser
DEBUG - 2024-04-20 12:25:35 --> Total execution time: 0.0820
ERROR - 2024-04-20 12:25:36 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-04-20 12:25:36 --> Config Class Initialized
INFO - 2024-04-20 12:25:36 --> Hooks Class Initialized
DEBUG - 2024-04-20 12:25:36 --> UTF-8 Support Enabled
INFO - 2024-04-20 12:25:36 --> Utf8 Class Initialized
INFO - 2024-04-20 12:25:36 --> URI Class Initialized
INFO - 2024-04-20 12:25:36 --> Router Class Initialized
INFO - 2024-04-20 12:25:36 --> Output Class Initialized
INFO - 2024-04-20 12:25:36 --> Security Class Initialized
DEBUG - 2024-04-20 12:25:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-04-20 12:25:36 --> Input Class Initialized
INFO - 2024-04-20 12:25:36 --> Language Class Initialized
INFO - 2024-04-20 12:25:36 --> Loader Class Initialized
INFO - 2024-04-20 12:25:36 --> Helper loaded: url_helper
INFO - 2024-04-20 12:25:36 --> Helper loaded: file_helper
INFO - 2024-04-20 12:25:36 --> Helper loaded: html_helper
INFO - 2024-04-20 12:25:36 --> Helper loaded: text_helper
INFO - 2024-04-20 12:25:36 --> Helper loaded: form_helper
INFO - 2024-04-20 12:25:36 --> Helper loaded: lang_helper
INFO - 2024-04-20 12:25:36 --> Helper loaded: security_helper
INFO - 2024-04-20 12:25:36 --> Helper loaded: cookie_helper
INFO - 2024-04-20 12:25:36 --> Database Driver Class Initialized
INFO - 2024-04-20 12:25:36 --> Session: Class initialized using 'files' driver.
INFO - 2024-04-20 12:25:36 --> Parser Class Initialized
INFO - 2024-04-20 12:25:36 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-04-20 12:25:36 --> Pagination Class Initialized
INFO - 2024-04-20 12:25:36 --> Form Validation Class Initialized
INFO - 2024-04-20 12:25:36 --> Controller Class Initialized
DEBUG - 2024-04-20 12:25:36 --> Auth class already loaded. Second attempt ignored.
INFO - 2024-04-20 12:25:36 --> Model Class Initialized
INFO - 2024-04-20 12:25:36 --> Model Class Initialized
INFO - 2024-04-20 12:25:36 --> Final output sent to browser
DEBUG - 2024-04-20 12:25:36 --> Total execution time: 0.0211
ERROR - 2024-04-20 12:25:39 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-04-20 12:25:39 --> Config Class Initialized
INFO - 2024-04-20 12:25:39 --> Hooks Class Initialized
DEBUG - 2024-04-20 12:25:39 --> UTF-8 Support Enabled
INFO - 2024-04-20 12:25:39 --> Utf8 Class Initialized
INFO - 2024-04-20 12:25:39 --> URI Class Initialized
INFO - 2024-04-20 12:25:39 --> Router Class Initialized
INFO - 2024-04-20 12:25:39 --> Output Class Initialized
INFO - 2024-04-20 12:25:39 --> Security Class Initialized
DEBUG - 2024-04-20 12:25:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-04-20 12:25:39 --> Input Class Initialized
INFO - 2024-04-20 12:25:39 --> Language Class Initialized
INFO - 2024-04-20 12:25:39 --> Loader Class Initialized
INFO - 2024-04-20 12:25:39 --> Helper loaded: url_helper
INFO - 2024-04-20 12:25:39 --> Helper loaded: file_helper
INFO - 2024-04-20 12:25:39 --> Helper loaded: html_helper
INFO - 2024-04-20 12:25:39 --> Helper loaded: text_helper
INFO - 2024-04-20 12:25:39 --> Helper loaded: form_helper
INFO - 2024-04-20 12:25:39 --> Helper loaded: lang_helper
INFO - 2024-04-20 12:25:39 --> Helper loaded: security_helper
INFO - 2024-04-20 12:25:39 --> Helper loaded: cookie_helper
INFO - 2024-04-20 12:25:39 --> Database Driver Class Initialized
INFO - 2024-04-20 12:25:39 --> Session: Class initialized using 'files' driver.
INFO - 2024-04-20 12:25:39 --> Parser Class Initialized
INFO - 2024-04-20 12:25:39 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-04-20 12:25:39 --> Pagination Class Initialized
INFO - 2024-04-20 12:25:39 --> Form Validation Class Initialized
INFO - 2024-04-20 12:25:39 --> Controller Class Initialized
DEBUG - 2024-04-20 12:25:39 --> Auth class already loaded. Second attempt ignored.
INFO - 2024-04-20 12:25:39 --> Model Class Initialized
INFO - 2024-04-20 12:25:39 --> Model Class Initialized
INFO - 2024-04-20 12:25:39 --> Model Class Initialized
INFO - 2024-04-20 12:25:39 --> Model Class Initialized
INFO - 2024-04-20 12:25:39 --> Model Class Initialized
INFO - 2024-04-20 12:25:39 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/product/edit_product_form.php
DEBUG - 2024-04-20 12:25:39 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-04-20 12:25:39 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-04-20 12:25:39 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-04-20 12:25:39 --> Model Class Initialized
INFO - 2024-04-20 12:25:39 --> Model Class Initialized
INFO - 2024-04-20 12:25:39 --> Model Class Initialized
INFO - 2024-04-20 12:25:39 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-04-20 12:25:39 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-04-20 12:25:39 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-04-20 12:25:39 --> Final output sent to browser
DEBUG - 2024-04-20 12:25:39 --> Total execution time: 0.3245
ERROR - 2024-04-20 12:25:58 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-04-20 12:25:58 --> Config Class Initialized
INFO - 2024-04-20 12:25:58 --> Hooks Class Initialized
DEBUG - 2024-04-20 12:25:58 --> UTF-8 Support Enabled
INFO - 2024-04-20 12:25:58 --> Utf8 Class Initialized
INFO - 2024-04-20 12:25:58 --> URI Class Initialized
INFO - 2024-04-20 12:25:58 --> Router Class Initialized
INFO - 2024-04-20 12:25:58 --> Output Class Initialized
INFO - 2024-04-20 12:25:58 --> Security Class Initialized
DEBUG - 2024-04-20 12:25:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-04-20 12:25:58 --> Input Class Initialized
INFO - 2024-04-20 12:25:58 --> Language Class Initialized
INFO - 2024-04-20 12:25:58 --> Loader Class Initialized
INFO - 2024-04-20 12:25:58 --> Helper loaded: url_helper
INFO - 2024-04-20 12:25:58 --> Helper loaded: file_helper
INFO - 2024-04-20 12:25:58 --> Helper loaded: html_helper
INFO - 2024-04-20 12:25:58 --> Helper loaded: text_helper
INFO - 2024-04-20 12:25:58 --> Helper loaded: form_helper
INFO - 2024-04-20 12:25:58 --> Helper loaded: lang_helper
INFO - 2024-04-20 12:25:58 --> Helper loaded: security_helper
INFO - 2024-04-20 12:25:58 --> Helper loaded: cookie_helper
INFO - 2024-04-20 12:25:58 --> Database Driver Class Initialized
INFO - 2024-04-20 12:25:58 --> Session: Class initialized using 'files' driver.
INFO - 2024-04-20 12:25:58 --> Parser Class Initialized
INFO - 2024-04-20 12:25:58 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-04-20 12:25:58 --> Pagination Class Initialized
INFO - 2024-04-20 12:25:58 --> Form Validation Class Initialized
INFO - 2024-04-20 12:25:58 --> Controller Class Initialized
INFO - 2024-04-20 12:25:58 --> Model Class Initialized
ERROR - 2024-04-20 12:25:58 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-04-20 12:25:58 --> Config Class Initialized
INFO - 2024-04-20 12:25:58 --> Hooks Class Initialized
DEBUG - 2024-04-20 12:25:58 --> UTF-8 Support Enabled
INFO - 2024-04-20 12:25:58 --> Utf8 Class Initialized
INFO - 2024-04-20 12:25:58 --> URI Class Initialized
INFO - 2024-04-20 12:25:58 --> Router Class Initialized
INFO - 2024-04-20 12:25:58 --> Output Class Initialized
INFO - 2024-04-20 12:25:58 --> Security Class Initialized
DEBUG - 2024-04-20 12:25:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-04-20 12:25:58 --> Input Class Initialized
INFO - 2024-04-20 12:25:58 --> Language Class Initialized
INFO - 2024-04-20 12:25:58 --> Loader Class Initialized
INFO - 2024-04-20 12:25:58 --> Helper loaded: url_helper
INFO - 2024-04-20 12:25:58 --> Helper loaded: file_helper
INFO - 2024-04-20 12:25:58 --> Helper loaded: html_helper
INFO - 2024-04-20 12:25:58 --> Helper loaded: text_helper
INFO - 2024-04-20 12:25:58 --> Helper loaded: form_helper
INFO - 2024-04-20 12:25:58 --> Helper loaded: lang_helper
INFO - 2024-04-20 12:25:58 --> Helper loaded: security_helper
INFO - 2024-04-20 12:25:58 --> Helper loaded: cookie_helper
INFO - 2024-04-20 12:25:58 --> Database Driver Class Initialized
INFO - 2024-04-20 12:25:58 --> Session: Class initialized using 'files' driver.
INFO - 2024-04-20 12:25:58 --> Parser Class Initialized
INFO - 2024-04-20 12:25:58 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-04-20 12:25:58 --> Pagination Class Initialized
INFO - 2024-04-20 12:25:58 --> Form Validation Class Initialized
INFO - 2024-04-20 12:25:58 --> Controller Class Initialized
INFO - 2024-04-20 12:25:58 --> Model Class Initialized
INFO - 2024-04-20 12:25:58 --> Model Class Initialized
INFO - 2024-04-20 12:25:58 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/purchase/purchase_html.php
DEBUG - 2024-04-20 12:25:58 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-04-20 12:25:58 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-04-20 12:25:58 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-04-20 12:25:58 --> Model Class Initialized
INFO - 2024-04-20 12:25:58 --> Model Class Initialized
INFO - 2024-04-20 12:25:58 --> Model Class Initialized
INFO - 2024-04-20 12:25:59 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-04-20 12:25:59 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-04-20 12:25:59 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-04-20 12:25:59 --> Final output sent to browser
DEBUG - 2024-04-20 12:25:59 --> Total execution time: 0.3003
ERROR - 2024-04-20 12:26:12 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-04-20 12:26:12 --> Config Class Initialized
INFO - 2024-04-20 12:26:12 --> Hooks Class Initialized
DEBUG - 2024-04-20 12:26:12 --> UTF-8 Support Enabled
INFO - 2024-04-20 12:26:12 --> Utf8 Class Initialized
INFO - 2024-04-20 12:26:12 --> URI Class Initialized
INFO - 2024-04-20 12:26:12 --> Router Class Initialized
INFO - 2024-04-20 12:26:12 --> Output Class Initialized
INFO - 2024-04-20 12:26:12 --> Security Class Initialized
DEBUG - 2024-04-20 12:26:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-04-20 12:26:12 --> Input Class Initialized
INFO - 2024-04-20 12:26:12 --> Language Class Initialized
INFO - 2024-04-20 12:26:12 --> Loader Class Initialized
INFO - 2024-04-20 12:26:12 --> Helper loaded: url_helper
INFO - 2024-04-20 12:26:12 --> Helper loaded: file_helper
INFO - 2024-04-20 12:26:12 --> Helper loaded: html_helper
INFO - 2024-04-20 12:26:12 --> Helper loaded: text_helper
INFO - 2024-04-20 12:26:12 --> Helper loaded: form_helper
INFO - 2024-04-20 12:26:12 --> Helper loaded: lang_helper
INFO - 2024-04-20 12:26:12 --> Helper loaded: security_helper
INFO - 2024-04-20 12:26:12 --> Helper loaded: cookie_helper
INFO - 2024-04-20 12:26:12 --> Database Driver Class Initialized
INFO - 2024-04-20 12:26:12 --> Session: Class initialized using 'files' driver.
INFO - 2024-04-20 12:26:12 --> Parser Class Initialized
INFO - 2024-04-20 12:26:12 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-04-20 12:26:12 --> Pagination Class Initialized
INFO - 2024-04-20 12:26:12 --> Form Validation Class Initialized
INFO - 2024-04-20 12:26:12 --> Controller Class Initialized
DEBUG - 2024-04-20 12:26:12 --> Auth class already loaded. Second attempt ignored.
INFO - 2024-04-20 12:26:12 --> Model Class Initialized
INFO - 2024-04-20 12:26:12 --> Model Class Initialized
ERROR - 2024-04-20 12:26:13 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-04-20 12:26:13 --> Config Class Initialized
INFO - 2024-04-20 12:26:13 --> Hooks Class Initialized
DEBUG - 2024-04-20 12:26:13 --> UTF-8 Support Enabled
INFO - 2024-04-20 12:26:13 --> Utf8 Class Initialized
INFO - 2024-04-20 12:26:13 --> URI Class Initialized
INFO - 2024-04-20 12:26:13 --> Router Class Initialized
INFO - 2024-04-20 12:26:13 --> Output Class Initialized
INFO - 2024-04-20 12:26:13 --> Security Class Initialized
DEBUG - 2024-04-20 12:26:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-04-20 12:26:13 --> Input Class Initialized
INFO - 2024-04-20 12:26:13 --> Language Class Initialized
INFO - 2024-04-20 12:26:13 --> Loader Class Initialized
INFO - 2024-04-20 12:26:13 --> Helper loaded: url_helper
INFO - 2024-04-20 12:26:13 --> Helper loaded: file_helper
INFO - 2024-04-20 12:26:13 --> Helper loaded: html_helper
INFO - 2024-04-20 12:26:13 --> Helper loaded: text_helper
INFO - 2024-04-20 12:26:13 --> Helper loaded: form_helper
INFO - 2024-04-20 12:26:13 --> Helper loaded: lang_helper
INFO - 2024-04-20 12:26:13 --> Helper loaded: security_helper
INFO - 2024-04-20 12:26:13 --> Helper loaded: cookie_helper
INFO - 2024-04-20 12:26:13 --> Database Driver Class Initialized
INFO - 2024-04-20 12:26:13 --> Session: Class initialized using 'files' driver.
INFO - 2024-04-20 12:26:13 --> Parser Class Initialized
INFO - 2024-04-20 12:26:13 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-04-20 12:26:13 --> Pagination Class Initialized
INFO - 2024-04-20 12:26:13 --> Form Validation Class Initialized
INFO - 2024-04-20 12:26:13 --> Controller Class Initialized
DEBUG - 2024-04-20 12:26:13 --> Auth class already loaded. Second attempt ignored.
INFO - 2024-04-20 12:26:13 --> Model Class Initialized
INFO - 2024-04-20 12:26:13 --> Model Class Initialized
INFO - 2024-04-20 12:26:13 --> Model Class Initialized
INFO - 2024-04-20 12:26:13 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/product/product.php
DEBUG - 2024-04-20 12:26:13 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-04-20 12:26:13 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-04-20 12:26:13 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-04-20 12:26:13 --> Model Class Initialized
INFO - 2024-04-20 12:26:13 --> Model Class Initialized
INFO - 2024-04-20 12:26:13 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-04-20 12:26:13 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-04-20 12:26:13 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-04-20 12:26:13 --> Final output sent to browser
DEBUG - 2024-04-20 12:26:13 --> Total execution time: 0.3832
ERROR - 2024-04-20 12:26:14 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-04-20 12:26:14 --> Config Class Initialized
INFO - 2024-04-20 12:26:14 --> Hooks Class Initialized
DEBUG - 2024-04-20 12:26:14 --> UTF-8 Support Enabled
INFO - 2024-04-20 12:26:14 --> Utf8 Class Initialized
INFO - 2024-04-20 12:26:14 --> URI Class Initialized
INFO - 2024-04-20 12:26:14 --> Router Class Initialized
INFO - 2024-04-20 12:26:14 --> Output Class Initialized
INFO - 2024-04-20 12:26:14 --> Security Class Initialized
DEBUG - 2024-04-20 12:26:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-04-20 12:26:14 --> Input Class Initialized
INFO - 2024-04-20 12:26:14 --> Language Class Initialized
INFO - 2024-04-20 12:26:14 --> Loader Class Initialized
INFO - 2024-04-20 12:26:14 --> Helper loaded: url_helper
INFO - 2024-04-20 12:26:14 --> Helper loaded: file_helper
INFO - 2024-04-20 12:26:14 --> Helper loaded: html_helper
INFO - 2024-04-20 12:26:14 --> Helper loaded: text_helper
INFO - 2024-04-20 12:26:14 --> Helper loaded: form_helper
INFO - 2024-04-20 12:26:14 --> Helper loaded: lang_helper
INFO - 2024-04-20 12:26:14 --> Helper loaded: security_helper
INFO - 2024-04-20 12:26:14 --> Helper loaded: cookie_helper
INFO - 2024-04-20 12:26:14 --> Database Driver Class Initialized
INFO - 2024-04-20 12:26:14 --> Session: Class initialized using 'files' driver.
INFO - 2024-04-20 12:26:14 --> Parser Class Initialized
INFO - 2024-04-20 12:26:14 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-04-20 12:26:14 --> Pagination Class Initialized
INFO - 2024-04-20 12:26:14 --> Form Validation Class Initialized
INFO - 2024-04-20 12:26:14 --> Controller Class Initialized
DEBUG - 2024-04-20 12:26:14 --> Auth class already loaded. Second attempt ignored.
INFO - 2024-04-20 12:26:14 --> Model Class Initialized
INFO - 2024-04-20 12:26:14 --> Model Class Initialized
INFO - 2024-04-20 12:26:14 --> Final output sent to browser
DEBUG - 2024-04-20 12:26:14 --> Total execution time: 0.0478
ERROR - 2024-04-20 12:26:19 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-04-20 12:26:19 --> Config Class Initialized
INFO - 2024-04-20 12:26:19 --> Hooks Class Initialized
DEBUG - 2024-04-20 12:26:19 --> UTF-8 Support Enabled
INFO - 2024-04-20 12:26:19 --> Utf8 Class Initialized
INFO - 2024-04-20 12:26:19 --> URI Class Initialized
INFO - 2024-04-20 12:26:19 --> Router Class Initialized
INFO - 2024-04-20 12:26:19 --> Output Class Initialized
INFO - 2024-04-20 12:26:19 --> Security Class Initialized
DEBUG - 2024-04-20 12:26:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-04-20 12:26:19 --> Input Class Initialized
INFO - 2024-04-20 12:26:19 --> Language Class Initialized
INFO - 2024-04-20 12:26:19 --> Loader Class Initialized
INFO - 2024-04-20 12:26:19 --> Helper loaded: url_helper
INFO - 2024-04-20 12:26:19 --> Helper loaded: file_helper
INFO - 2024-04-20 12:26:19 --> Helper loaded: html_helper
INFO - 2024-04-20 12:26:19 --> Helper loaded: text_helper
INFO - 2024-04-20 12:26:19 --> Helper loaded: form_helper
INFO - 2024-04-20 12:26:19 --> Helper loaded: lang_helper
INFO - 2024-04-20 12:26:19 --> Helper loaded: security_helper
INFO - 2024-04-20 12:26:19 --> Helper loaded: cookie_helper
INFO - 2024-04-20 12:26:19 --> Database Driver Class Initialized
INFO - 2024-04-20 12:26:19 --> Session: Class initialized using 'files' driver.
INFO - 2024-04-20 12:26:19 --> Parser Class Initialized
INFO - 2024-04-20 12:26:19 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-04-20 12:26:19 --> Pagination Class Initialized
INFO - 2024-04-20 12:26:19 --> Form Validation Class Initialized
INFO - 2024-04-20 12:26:19 --> Controller Class Initialized
INFO - 2024-04-20 12:26:19 --> Model Class Initialized
INFO - 2024-04-20 12:26:19 --> Model Class Initialized
ERROR - 2024-04-20 12:26:19 --> Severity: Warning --> Invalid argument supplied for foreach() /home/powera7m/app.maurnaturo.com/application/views/purchase/add_purchase_form.php 157
INFO - 2024-04-20 12:26:19 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/purchase/add_purchase_form.php
DEBUG - 2024-04-20 12:26:19 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-04-20 12:26:19 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-04-20 12:26:19 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-04-20 12:26:19 --> Model Class Initialized
INFO - 2024-04-20 12:26:19 --> Model Class Initialized
INFO - 2024-04-20 12:26:19 --> Model Class Initialized
INFO - 2024-04-20 12:26:19 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-04-20 12:26:19 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-04-20 12:26:19 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-04-20 12:26:19 --> Final output sent to browser
DEBUG - 2024-04-20 12:26:19 --> Total execution time: 0.3347
ERROR - 2024-04-20 12:26:28 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-04-20 12:26:28 --> Config Class Initialized
INFO - 2024-04-20 12:26:28 --> Hooks Class Initialized
DEBUG - 2024-04-20 12:26:28 --> UTF-8 Support Enabled
INFO - 2024-04-20 12:26:28 --> Utf8 Class Initialized
INFO - 2024-04-20 12:26:28 --> URI Class Initialized
INFO - 2024-04-20 12:26:28 --> Router Class Initialized
INFO - 2024-04-20 12:26:28 --> Output Class Initialized
INFO - 2024-04-20 12:26:28 --> Security Class Initialized
DEBUG - 2024-04-20 12:26:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-04-20 12:26:28 --> Input Class Initialized
INFO - 2024-04-20 12:26:28 --> Language Class Initialized
INFO - 2024-04-20 12:26:28 --> Loader Class Initialized
INFO - 2024-04-20 12:26:28 --> Helper loaded: url_helper
INFO - 2024-04-20 12:26:28 --> Helper loaded: file_helper
INFO - 2024-04-20 12:26:28 --> Helper loaded: html_helper
INFO - 2024-04-20 12:26:28 --> Helper loaded: text_helper
INFO - 2024-04-20 12:26:28 --> Helper loaded: form_helper
INFO - 2024-04-20 12:26:28 --> Helper loaded: lang_helper
INFO - 2024-04-20 12:26:28 --> Helper loaded: security_helper
INFO - 2024-04-20 12:26:28 --> Helper loaded: cookie_helper
INFO - 2024-04-20 12:26:28 --> Database Driver Class Initialized
INFO - 2024-04-20 12:26:28 --> Session: Class initialized using 'files' driver.
INFO - 2024-04-20 12:26:28 --> Parser Class Initialized
INFO - 2024-04-20 12:26:28 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-04-20 12:26:28 --> Pagination Class Initialized
INFO - 2024-04-20 12:26:28 --> Form Validation Class Initialized
INFO - 2024-04-20 12:26:28 --> Controller Class Initialized
INFO - 2024-04-20 12:26:28 --> Model Class Initialized
INFO - 2024-04-20 12:26:28 --> Final output sent to browser
DEBUG - 2024-04-20 12:26:28 --> Total execution time: 0.0151
ERROR - 2024-04-20 12:26:29 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-04-20 12:26:29 --> Config Class Initialized
INFO - 2024-04-20 12:26:29 --> Hooks Class Initialized
DEBUG - 2024-04-20 12:26:29 --> UTF-8 Support Enabled
INFO - 2024-04-20 12:26:29 --> Utf8 Class Initialized
INFO - 2024-04-20 12:26:29 --> URI Class Initialized
INFO - 2024-04-20 12:26:29 --> Router Class Initialized
INFO - 2024-04-20 12:26:29 --> Output Class Initialized
INFO - 2024-04-20 12:26:29 --> Security Class Initialized
DEBUG - 2024-04-20 12:26:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-04-20 12:26:29 --> Input Class Initialized
INFO - 2024-04-20 12:26:29 --> Language Class Initialized
INFO - 2024-04-20 12:26:29 --> Loader Class Initialized
INFO - 2024-04-20 12:26:29 --> Helper loaded: url_helper
INFO - 2024-04-20 12:26:29 --> Helper loaded: file_helper
INFO - 2024-04-20 12:26:29 --> Helper loaded: html_helper
INFO - 2024-04-20 12:26:29 --> Helper loaded: text_helper
INFO - 2024-04-20 12:26:29 --> Helper loaded: form_helper
INFO - 2024-04-20 12:26:29 --> Helper loaded: lang_helper
INFO - 2024-04-20 12:26:29 --> Helper loaded: security_helper
INFO - 2024-04-20 12:26:29 --> Helper loaded: cookie_helper
INFO - 2024-04-20 12:26:29 --> Database Driver Class Initialized
INFO - 2024-04-20 12:26:29 --> Session: Class initialized using 'files' driver.
INFO - 2024-04-20 12:26:29 --> Parser Class Initialized
INFO - 2024-04-20 12:26:29 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-04-20 12:26:29 --> Pagination Class Initialized
INFO - 2024-04-20 12:26:29 --> Form Validation Class Initialized
INFO - 2024-04-20 12:26:29 --> Controller Class Initialized
INFO - 2024-04-20 12:26:29 --> Model Class Initialized
DEBUG - 2024-04-20 12:26:29 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-04-20 12:26:29 --> Session class already loaded. Second attempt ignored.
INFO - 2024-04-20 12:26:29 --> Model Class Initialized
DEBUG - 2024-04-20 12:26:29 --> Session class already loaded. Second attempt ignored.
INFO - 2024-04-20 12:26:29 --> Model Class Initialized
INFO - 2024-04-20 12:26:29 --> Final output sent to browser
DEBUG - 2024-04-20 12:26:29 --> Total execution time: 0.0198
ERROR - 2024-04-20 12:26:42 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-04-20 12:26:42 --> Config Class Initialized
INFO - 2024-04-20 12:26:42 --> Hooks Class Initialized
DEBUG - 2024-04-20 12:26:42 --> UTF-8 Support Enabled
INFO - 2024-04-20 12:26:42 --> Utf8 Class Initialized
INFO - 2024-04-20 12:26:42 --> URI Class Initialized
INFO - 2024-04-20 12:26:42 --> Router Class Initialized
INFO - 2024-04-20 12:26:42 --> Output Class Initialized
INFO - 2024-04-20 12:26:42 --> Security Class Initialized
DEBUG - 2024-04-20 12:26:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-04-20 12:26:42 --> Input Class Initialized
INFO - 2024-04-20 12:26:42 --> Language Class Initialized
INFO - 2024-04-20 12:26:42 --> Loader Class Initialized
INFO - 2024-04-20 12:26:42 --> Helper loaded: url_helper
INFO - 2024-04-20 12:26:42 --> Helper loaded: file_helper
INFO - 2024-04-20 12:26:42 --> Helper loaded: html_helper
INFO - 2024-04-20 12:26:42 --> Helper loaded: text_helper
INFO - 2024-04-20 12:26:42 --> Helper loaded: form_helper
INFO - 2024-04-20 12:26:42 --> Helper loaded: lang_helper
INFO - 2024-04-20 12:26:42 --> Helper loaded: security_helper
INFO - 2024-04-20 12:26:42 --> Helper loaded: cookie_helper
INFO - 2024-04-20 12:26:42 --> Database Driver Class Initialized
INFO - 2024-04-20 12:26:42 --> Session: Class initialized using 'files' driver.
INFO - 2024-04-20 12:26:42 --> Parser Class Initialized
INFO - 2024-04-20 12:26:42 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-04-20 12:26:42 --> Pagination Class Initialized
INFO - 2024-04-20 12:26:42 --> Form Validation Class Initialized
INFO - 2024-04-20 12:26:42 --> Controller Class Initialized
INFO - 2024-04-20 12:26:42 --> Model Class Initialized
ERROR - 2024-04-20 12:26:42 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-04-20 12:26:42 --> Config Class Initialized
INFO - 2024-04-20 12:26:42 --> Hooks Class Initialized
DEBUG - 2024-04-20 12:26:42 --> UTF-8 Support Enabled
INFO - 2024-04-20 12:26:42 --> Utf8 Class Initialized
INFO - 2024-04-20 12:26:42 --> URI Class Initialized
INFO - 2024-04-20 12:26:42 --> Router Class Initialized
INFO - 2024-04-20 12:26:42 --> Output Class Initialized
INFO - 2024-04-20 12:26:42 --> Security Class Initialized
DEBUG - 2024-04-20 12:26:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-04-20 12:26:42 --> Input Class Initialized
INFO - 2024-04-20 12:26:42 --> Language Class Initialized
INFO - 2024-04-20 12:26:42 --> Loader Class Initialized
INFO - 2024-04-20 12:26:42 --> Helper loaded: url_helper
INFO - 2024-04-20 12:26:42 --> Helper loaded: file_helper
INFO - 2024-04-20 12:26:42 --> Helper loaded: html_helper
INFO - 2024-04-20 12:26:42 --> Helper loaded: text_helper
INFO - 2024-04-20 12:26:42 --> Helper loaded: form_helper
INFO - 2024-04-20 12:26:42 --> Helper loaded: lang_helper
INFO - 2024-04-20 12:26:42 --> Helper loaded: security_helper
INFO - 2024-04-20 12:26:42 --> Helper loaded: cookie_helper
INFO - 2024-04-20 12:26:42 --> Database Driver Class Initialized
INFO - 2024-04-20 12:26:42 --> Session: Class initialized using 'files' driver.
INFO - 2024-04-20 12:26:42 --> Parser Class Initialized
INFO - 2024-04-20 12:26:42 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-04-20 12:26:42 --> Pagination Class Initialized
INFO - 2024-04-20 12:26:42 --> Form Validation Class Initialized
INFO - 2024-04-20 12:26:42 --> Controller Class Initialized
INFO - 2024-04-20 12:26:42 --> Model Class Initialized
INFO - 2024-04-20 12:26:42 --> Model Class Initialized
INFO - 2024-04-20 12:26:42 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/purchase/purchase_html.php
DEBUG - 2024-04-20 12:26:42 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-04-20 12:26:42 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-04-20 12:26:42 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-04-20 12:26:42 --> Model Class Initialized
INFO - 2024-04-20 12:26:42 --> Model Class Initialized
INFO - 2024-04-20 12:26:42 --> Model Class Initialized
INFO - 2024-04-20 12:26:43 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-04-20 12:26:43 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-04-20 12:26:43 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-04-20 12:26:43 --> Final output sent to browser
DEBUG - 2024-04-20 12:26:43 --> Total execution time: 0.2889
ERROR - 2024-04-20 12:26:52 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-04-20 12:26:52 --> Config Class Initialized
INFO - 2024-04-20 12:26:52 --> Hooks Class Initialized
DEBUG - 2024-04-20 12:26:52 --> UTF-8 Support Enabled
INFO - 2024-04-20 12:26:52 --> Utf8 Class Initialized
INFO - 2024-04-20 12:26:52 --> URI Class Initialized
INFO - 2024-04-20 12:26:52 --> Router Class Initialized
INFO - 2024-04-20 12:26:52 --> Output Class Initialized
INFO - 2024-04-20 12:26:52 --> Security Class Initialized
DEBUG - 2024-04-20 12:26:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-04-20 12:26:52 --> Input Class Initialized
INFO - 2024-04-20 12:26:52 --> Language Class Initialized
INFO - 2024-04-20 12:26:52 --> Loader Class Initialized
INFO - 2024-04-20 12:26:52 --> Helper loaded: url_helper
INFO - 2024-04-20 12:26:52 --> Helper loaded: file_helper
INFO - 2024-04-20 12:26:52 --> Helper loaded: html_helper
INFO - 2024-04-20 12:26:52 --> Helper loaded: text_helper
INFO - 2024-04-20 12:26:52 --> Helper loaded: form_helper
INFO - 2024-04-20 12:26:52 --> Helper loaded: lang_helper
INFO - 2024-04-20 12:26:52 --> Helper loaded: security_helper
INFO - 2024-04-20 12:26:52 --> Helper loaded: cookie_helper
INFO - 2024-04-20 12:26:52 --> Database Driver Class Initialized
INFO - 2024-04-20 12:26:52 --> Session: Class initialized using 'files' driver.
INFO - 2024-04-20 12:26:52 --> Parser Class Initialized
INFO - 2024-04-20 12:26:52 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-04-20 12:26:52 --> Pagination Class Initialized
INFO - 2024-04-20 12:26:52 --> Form Validation Class Initialized
INFO - 2024-04-20 12:26:52 --> Controller Class Initialized
INFO - 2024-04-20 12:26:52 --> Model Class Initialized
DEBUG - 2024-04-20 12:26:52 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-04-20 12:26:52 --> Session class already loaded. Second attempt ignored.
INFO - 2024-04-20 12:26:52 --> Model Class Initialized
DEBUG - 2024-04-20 12:26:52 --> Session class already loaded. Second attempt ignored.
INFO - 2024-04-20 12:26:52 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/stockrequest/add_stockrequest_form.php
DEBUG - 2024-04-20 12:26:52 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-04-20 12:26:52 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-04-20 12:26:52 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-04-20 12:26:52 --> Model Class Initialized
INFO - 2024-04-20 12:26:52 --> Model Class Initialized
INFO - 2024-04-20 12:26:52 --> Model Class Initialized
INFO - 2024-04-20 12:26:52 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-04-20 12:26:52 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-04-20 12:26:52 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-04-20 12:26:52 --> Final output sent to browser
DEBUG - 2024-04-20 12:26:52 --> Total execution time: 0.3049
ERROR - 2024-04-20 12:26:56 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-04-20 12:26:56 --> Config Class Initialized
INFO - 2024-04-20 12:26:56 --> Hooks Class Initialized
DEBUG - 2024-04-20 12:26:56 --> UTF-8 Support Enabled
INFO - 2024-04-20 12:26:56 --> Utf8 Class Initialized
INFO - 2024-04-20 12:26:56 --> URI Class Initialized
INFO - 2024-04-20 12:26:56 --> Router Class Initialized
INFO - 2024-04-20 12:26:56 --> Output Class Initialized
INFO - 2024-04-20 12:26:56 --> Security Class Initialized
DEBUG - 2024-04-20 12:26:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-04-20 12:26:56 --> Input Class Initialized
INFO - 2024-04-20 12:26:56 --> Language Class Initialized
INFO - 2024-04-20 12:26:56 --> Loader Class Initialized
INFO - 2024-04-20 12:26:56 --> Helper loaded: url_helper
INFO - 2024-04-20 12:26:56 --> Helper loaded: file_helper
INFO - 2024-04-20 12:26:56 --> Helper loaded: html_helper
INFO - 2024-04-20 12:26:56 --> Helper loaded: text_helper
INFO - 2024-04-20 12:26:56 --> Helper loaded: form_helper
INFO - 2024-04-20 12:26:56 --> Helper loaded: lang_helper
INFO - 2024-04-20 12:26:56 --> Helper loaded: security_helper
INFO - 2024-04-20 12:26:56 --> Helper loaded: cookie_helper
INFO - 2024-04-20 12:26:56 --> Database Driver Class Initialized
INFO - 2024-04-20 12:26:56 --> Session: Class initialized using 'files' driver.
INFO - 2024-04-20 12:26:56 --> Parser Class Initialized
INFO - 2024-04-20 12:26:56 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-04-20 12:26:56 --> Pagination Class Initialized
INFO - 2024-04-20 12:26:56 --> Form Validation Class Initialized
INFO - 2024-04-20 12:26:56 --> Controller Class Initialized
INFO - 2024-04-20 12:26:56 --> Model Class Initialized
INFO - 2024-04-20 12:26:56 --> Final output sent to browser
DEBUG - 2024-04-20 12:26:56 --> Total execution time: 0.0172
ERROR - 2024-04-20 12:26:58 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-04-20 12:26:58 --> Config Class Initialized
INFO - 2024-04-20 12:26:58 --> Hooks Class Initialized
DEBUG - 2024-04-20 12:26:58 --> UTF-8 Support Enabled
INFO - 2024-04-20 12:26:58 --> Utf8 Class Initialized
INFO - 2024-04-20 12:26:58 --> URI Class Initialized
INFO - 2024-04-20 12:26:58 --> Router Class Initialized
INFO - 2024-04-20 12:26:58 --> Output Class Initialized
INFO - 2024-04-20 12:26:58 --> Security Class Initialized
DEBUG - 2024-04-20 12:26:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-04-20 12:26:58 --> Input Class Initialized
INFO - 2024-04-20 12:26:58 --> Language Class Initialized
INFO - 2024-04-20 12:26:58 --> Loader Class Initialized
INFO - 2024-04-20 12:26:58 --> Helper loaded: url_helper
INFO - 2024-04-20 12:26:58 --> Helper loaded: file_helper
INFO - 2024-04-20 12:26:58 --> Helper loaded: html_helper
INFO - 2024-04-20 12:26:58 --> Helper loaded: text_helper
INFO - 2024-04-20 12:26:58 --> Helper loaded: form_helper
INFO - 2024-04-20 12:26:58 --> Helper loaded: lang_helper
INFO - 2024-04-20 12:26:58 --> Helper loaded: security_helper
INFO - 2024-04-20 12:26:58 --> Helper loaded: cookie_helper
INFO - 2024-04-20 12:26:58 --> Database Driver Class Initialized
INFO - 2024-04-20 12:26:58 --> Session: Class initialized using 'files' driver.
INFO - 2024-04-20 12:26:58 --> Parser Class Initialized
INFO - 2024-04-20 12:26:58 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-04-20 12:26:58 --> Pagination Class Initialized
INFO - 2024-04-20 12:26:58 --> Form Validation Class Initialized
INFO - 2024-04-20 12:26:58 --> Controller Class Initialized
INFO - 2024-04-20 12:26:58 --> Model Class Initialized
DEBUG - 2024-04-20 12:26:58 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-04-20 12:26:58 --> Session class already loaded. Second attempt ignored.
INFO - 2024-04-20 12:26:58 --> Model Class Initialized
DEBUG - 2024-04-20 12:26:58 --> Session class already loaded. Second attempt ignored.
INFO - 2024-04-20 12:26:58 --> Model Class Initialized
INFO - 2024-04-20 12:26:58 --> Final output sent to browser
DEBUG - 2024-04-20 12:26:58 --> Total execution time: 0.0206
ERROR - 2024-04-20 12:26:59 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-04-20 12:26:59 --> Config Class Initialized
INFO - 2024-04-20 12:26:59 --> Hooks Class Initialized
DEBUG - 2024-04-20 12:26:59 --> UTF-8 Support Enabled
INFO - 2024-04-20 12:26:59 --> Utf8 Class Initialized
INFO - 2024-04-20 12:26:59 --> URI Class Initialized
INFO - 2024-04-20 12:26:59 --> Router Class Initialized
INFO - 2024-04-20 12:26:59 --> Output Class Initialized
INFO - 2024-04-20 12:26:59 --> Security Class Initialized
DEBUG - 2024-04-20 12:26:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-04-20 12:26:59 --> Input Class Initialized
INFO - 2024-04-20 12:26:59 --> Language Class Initialized
INFO - 2024-04-20 12:26:59 --> Loader Class Initialized
INFO - 2024-04-20 12:26:59 --> Helper loaded: url_helper
INFO - 2024-04-20 12:26:59 --> Helper loaded: file_helper
INFO - 2024-04-20 12:26:59 --> Helper loaded: html_helper
INFO - 2024-04-20 12:26:59 --> Helper loaded: text_helper
INFO - 2024-04-20 12:26:59 --> Helper loaded: form_helper
INFO - 2024-04-20 12:26:59 --> Helper loaded: lang_helper
INFO - 2024-04-20 12:26:59 --> Helper loaded: security_helper
INFO - 2024-04-20 12:26:59 --> Helper loaded: cookie_helper
INFO - 2024-04-20 12:26:59 --> Database Driver Class Initialized
INFO - 2024-04-20 12:26:59 --> Session: Class initialized using 'files' driver.
INFO - 2024-04-20 12:26:59 --> Parser Class Initialized
INFO - 2024-04-20 12:26:59 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-04-20 12:26:59 --> Pagination Class Initialized
INFO - 2024-04-20 12:26:59 --> Form Validation Class Initialized
INFO - 2024-04-20 12:26:59 --> Controller Class Initialized
INFO - 2024-04-20 12:26:59 --> Model Class Initialized
DEBUG - 2024-04-20 12:26:59 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-04-20 12:26:59 --> Session class already loaded. Second attempt ignored.
INFO - 2024-04-20 12:26:59 --> Model Class Initialized
DEBUG - 2024-04-20 12:26:59 --> Session class already loaded. Second attempt ignored.
INFO - 2024-04-20 12:26:59 --> Model Class Initialized
INFO - 2024-04-20 12:26:59 --> Final output sent to browser
DEBUG - 2024-04-20 12:26:59 --> Total execution time: 0.0176
ERROR - 2024-04-20 12:27:00 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-04-20 12:27:00 --> Config Class Initialized
INFO - 2024-04-20 12:27:00 --> Hooks Class Initialized
DEBUG - 2024-04-20 12:27:00 --> UTF-8 Support Enabled
INFO - 2024-04-20 12:27:00 --> Utf8 Class Initialized
INFO - 2024-04-20 12:27:00 --> URI Class Initialized
INFO - 2024-04-20 12:27:00 --> Router Class Initialized
INFO - 2024-04-20 12:27:00 --> Output Class Initialized
INFO - 2024-04-20 12:27:00 --> Security Class Initialized
DEBUG - 2024-04-20 12:27:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-04-20 12:27:00 --> Input Class Initialized
INFO - 2024-04-20 12:27:00 --> Language Class Initialized
INFO - 2024-04-20 12:27:00 --> Loader Class Initialized
INFO - 2024-04-20 12:27:00 --> Helper loaded: url_helper
INFO - 2024-04-20 12:27:00 --> Helper loaded: file_helper
INFO - 2024-04-20 12:27:00 --> Helper loaded: html_helper
INFO - 2024-04-20 12:27:00 --> Helper loaded: text_helper
INFO - 2024-04-20 12:27:00 --> Helper loaded: form_helper
INFO - 2024-04-20 12:27:00 --> Helper loaded: lang_helper
INFO - 2024-04-20 12:27:00 --> Helper loaded: security_helper
INFO - 2024-04-20 12:27:00 --> Helper loaded: cookie_helper
INFO - 2024-04-20 12:27:00 --> Database Driver Class Initialized
INFO - 2024-04-20 12:27:00 --> Session: Class initialized using 'files' driver.
INFO - 2024-04-20 12:27:00 --> Parser Class Initialized
INFO - 2024-04-20 12:27:00 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-04-20 12:27:00 --> Pagination Class Initialized
INFO - 2024-04-20 12:27:00 --> Form Validation Class Initialized
INFO - 2024-04-20 12:27:00 --> Controller Class Initialized
INFO - 2024-04-20 12:27:00 --> Model Class Initialized
DEBUG - 2024-04-20 12:27:00 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-04-20 12:27:00 --> Session class already loaded. Second attempt ignored.
INFO - 2024-04-20 12:27:00 --> Model Class Initialized
DEBUG - 2024-04-20 12:27:00 --> Session class already loaded. Second attempt ignored.
INFO - 2024-04-20 12:27:00 --> Model Class Initialized
INFO - 2024-04-20 12:27:00 --> Model Class Initialized
INFO - 2024-04-20 12:27:00 --> Final output sent to browser
DEBUG - 2024-04-20 12:27:00 --> Total execution time: 0.0211
ERROR - 2024-04-20 12:27:03 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-04-20 12:27:03 --> Config Class Initialized
INFO - 2024-04-20 12:27:03 --> Hooks Class Initialized
DEBUG - 2024-04-20 12:27:03 --> UTF-8 Support Enabled
INFO - 2024-04-20 12:27:03 --> Utf8 Class Initialized
INFO - 2024-04-20 12:27:03 --> URI Class Initialized
INFO - 2024-04-20 12:27:03 --> Router Class Initialized
INFO - 2024-04-20 12:27:03 --> Output Class Initialized
INFO - 2024-04-20 12:27:03 --> Security Class Initialized
DEBUG - 2024-04-20 12:27:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-04-20 12:27:03 --> Input Class Initialized
INFO - 2024-04-20 12:27:03 --> Language Class Initialized
INFO - 2024-04-20 12:27:03 --> Loader Class Initialized
INFO - 2024-04-20 12:27:03 --> Helper loaded: url_helper
INFO - 2024-04-20 12:27:03 --> Helper loaded: file_helper
INFO - 2024-04-20 12:27:03 --> Helper loaded: html_helper
INFO - 2024-04-20 12:27:03 --> Helper loaded: text_helper
INFO - 2024-04-20 12:27:03 --> Helper loaded: form_helper
INFO - 2024-04-20 12:27:03 --> Helper loaded: lang_helper
INFO - 2024-04-20 12:27:03 --> Helper loaded: security_helper
INFO - 2024-04-20 12:27:03 --> Helper loaded: cookie_helper
INFO - 2024-04-20 12:27:03 --> Database Driver Class Initialized
INFO - 2024-04-20 12:27:03 --> Session: Class initialized using 'files' driver.
INFO - 2024-04-20 12:27:03 --> Parser Class Initialized
INFO - 2024-04-20 12:27:03 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-04-20 12:27:03 --> Pagination Class Initialized
INFO - 2024-04-20 12:27:03 --> Form Validation Class Initialized
INFO - 2024-04-20 12:27:03 --> Controller Class Initialized
INFO - 2024-04-20 12:27:03 --> Model Class Initialized
DEBUG - 2024-04-20 12:27:03 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-04-20 12:27:03 --> Session class already loaded. Second attempt ignored.
INFO - 2024-04-20 12:27:03 --> Model Class Initialized
DEBUG - 2024-04-20 12:27:03 --> Session class already loaded. Second attempt ignored.
INFO - 2024-04-20 12:27:03 --> Model Class Initialized
INFO - 2024-04-20 12:27:03 --> Final output sent to browser
DEBUG - 2024-04-20 12:27:03 --> Total execution time: 0.0201
ERROR - 2024-04-20 12:27:14 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-04-20 12:27:14 --> Config Class Initialized
INFO - 2024-04-20 12:27:14 --> Hooks Class Initialized
DEBUG - 2024-04-20 12:27:14 --> UTF-8 Support Enabled
INFO - 2024-04-20 12:27:14 --> Utf8 Class Initialized
INFO - 2024-04-20 12:27:14 --> URI Class Initialized
INFO - 2024-04-20 12:27:14 --> Router Class Initialized
INFO - 2024-04-20 12:27:14 --> Output Class Initialized
INFO - 2024-04-20 12:27:14 --> Security Class Initialized
DEBUG - 2024-04-20 12:27:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-04-20 12:27:14 --> Input Class Initialized
INFO - 2024-04-20 12:27:14 --> Language Class Initialized
INFO - 2024-04-20 12:27:14 --> Loader Class Initialized
INFO - 2024-04-20 12:27:14 --> Helper loaded: url_helper
INFO - 2024-04-20 12:27:14 --> Helper loaded: file_helper
INFO - 2024-04-20 12:27:14 --> Helper loaded: html_helper
INFO - 2024-04-20 12:27:14 --> Helper loaded: text_helper
INFO - 2024-04-20 12:27:14 --> Helper loaded: form_helper
INFO - 2024-04-20 12:27:14 --> Helper loaded: lang_helper
INFO - 2024-04-20 12:27:14 --> Helper loaded: security_helper
INFO - 2024-04-20 12:27:14 --> Helper loaded: cookie_helper
INFO - 2024-04-20 12:27:14 --> Database Driver Class Initialized
INFO - 2024-04-20 12:27:14 --> Session: Class initialized using 'files' driver.
INFO - 2024-04-20 12:27:14 --> Parser Class Initialized
INFO - 2024-04-20 12:27:14 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-04-20 12:27:14 --> Pagination Class Initialized
INFO - 2024-04-20 12:27:14 --> Form Validation Class Initialized
INFO - 2024-04-20 12:27:14 --> Controller Class Initialized
INFO - 2024-04-20 12:27:14 --> Model Class Initialized
DEBUG - 2024-04-20 12:27:14 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-04-20 12:27:14 --> Session class already loaded. Second attempt ignored.
INFO - 2024-04-20 12:27:14 --> Model Class Initialized
DEBUG - 2024-04-20 12:27:14 --> Session class already loaded. Second attempt ignored.
INFO - 2024-04-20 12:27:14 --> Model Class Initialized
INFO - 2024-04-20 12:27:14 --> Final output sent to browser
DEBUG - 2024-04-20 12:27:14 --> Total execution time: 0.0224
