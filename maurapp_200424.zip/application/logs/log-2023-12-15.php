<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2023-12-15 02:44:37 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-12-15 02:44:37 --> Config Class Initialized
INFO - 2023-12-15 02:44:37 --> Hooks Class Initialized
DEBUG - 2023-12-15 02:44:37 --> UTF-8 Support Enabled
INFO - 2023-12-15 02:44:37 --> Utf8 Class Initialized
INFO - 2023-12-15 02:44:37 --> URI Class Initialized
DEBUG - 2023-12-15 02:44:37 --> No URI present. Default controller set.
INFO - 2023-12-15 02:44:37 --> Router Class Initialized
INFO - 2023-12-15 02:44:37 --> Output Class Initialized
INFO - 2023-12-15 02:44:37 --> Security Class Initialized
DEBUG - 2023-12-15 02:44:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-15 02:44:37 --> Input Class Initialized
INFO - 2023-12-15 02:44:37 --> Language Class Initialized
INFO - 2023-12-15 02:44:37 --> Loader Class Initialized
INFO - 2023-12-15 02:44:37 --> Helper loaded: url_helper
INFO - 2023-12-15 02:44:37 --> Helper loaded: file_helper
INFO - 2023-12-15 02:44:37 --> Helper loaded: html_helper
INFO - 2023-12-15 02:44:37 --> Helper loaded: text_helper
INFO - 2023-12-15 02:44:37 --> Helper loaded: form_helper
INFO - 2023-12-15 02:44:37 --> Helper loaded: lang_helper
INFO - 2023-12-15 02:44:37 --> Helper loaded: security_helper
INFO - 2023-12-15 02:44:37 --> Helper loaded: cookie_helper
INFO - 2023-12-15 02:44:37 --> Database Driver Class Initialized
INFO - 2023-12-15 02:44:37 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-15 02:44:37 --> Parser Class Initialized
INFO - 2023-12-15 02:44:37 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-12-15 02:44:37 --> Pagination Class Initialized
INFO - 2023-12-15 02:44:37 --> Form Validation Class Initialized
INFO - 2023-12-15 02:44:37 --> Controller Class Initialized
INFO - 2023-12-15 02:44:37 --> Model Class Initialized
DEBUG - 2023-12-15 02:44:37 --> Session class already loaded. Second attempt ignored.
ERROR - 2023-12-15 02:44:37 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-12-15 02:44:37 --> Config Class Initialized
INFO - 2023-12-15 02:44:37 --> Hooks Class Initialized
DEBUG - 2023-12-15 02:44:37 --> UTF-8 Support Enabled
INFO - 2023-12-15 02:44:37 --> Utf8 Class Initialized
INFO - 2023-12-15 02:44:37 --> URI Class Initialized
INFO - 2023-12-15 02:44:37 --> Router Class Initialized
INFO - 2023-12-15 02:44:37 --> Output Class Initialized
INFO - 2023-12-15 02:44:37 --> Security Class Initialized
DEBUG - 2023-12-15 02:44:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-15 02:44:37 --> Input Class Initialized
INFO - 2023-12-15 02:44:37 --> Language Class Initialized
ERROR - 2023-12-15 02:44:37 --> 404 Page Not Found: Wp-includes/wlwmanifest.xml
ERROR - 2023-12-15 02:44:37 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-12-15 02:44:37 --> Config Class Initialized
INFO - 2023-12-15 02:44:37 --> Hooks Class Initialized
DEBUG - 2023-12-15 02:44:37 --> UTF-8 Support Enabled
INFO - 2023-12-15 02:44:37 --> Utf8 Class Initialized
INFO - 2023-12-15 02:44:37 --> URI Class Initialized
INFO - 2023-12-15 02:44:37 --> Router Class Initialized
INFO - 2023-12-15 02:44:37 --> Output Class Initialized
INFO - 2023-12-15 02:44:37 --> Security Class Initialized
DEBUG - 2023-12-15 02:44:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-15 02:44:37 --> Input Class Initialized
INFO - 2023-12-15 02:44:37 --> Language Class Initialized
ERROR - 2023-12-15 02:44:37 --> 404 Page Not Found: Xmlrpcphp/index
ERROR - 2023-12-15 02:44:37 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-12-15 02:44:37 --> Config Class Initialized
INFO - 2023-12-15 02:44:37 --> Hooks Class Initialized
DEBUG - 2023-12-15 02:44:37 --> UTF-8 Support Enabled
INFO - 2023-12-15 02:44:37 --> Utf8 Class Initialized
INFO - 2023-12-15 02:44:37 --> URI Class Initialized
DEBUG - 2023-12-15 02:44:37 --> No URI present. Default controller set.
INFO - 2023-12-15 02:44:37 --> Router Class Initialized
INFO - 2023-12-15 02:44:37 --> Output Class Initialized
INFO - 2023-12-15 02:44:37 --> Security Class Initialized
DEBUG - 2023-12-15 02:44:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-15 02:44:37 --> Input Class Initialized
INFO - 2023-12-15 02:44:37 --> Language Class Initialized
INFO - 2023-12-15 02:44:37 --> Loader Class Initialized
INFO - 2023-12-15 02:44:37 --> Helper loaded: url_helper
INFO - 2023-12-15 02:44:37 --> Helper loaded: file_helper
INFO - 2023-12-15 02:44:37 --> Helper loaded: html_helper
INFO - 2023-12-15 02:44:37 --> Helper loaded: text_helper
INFO - 2023-12-15 02:44:37 --> Helper loaded: form_helper
INFO - 2023-12-15 02:44:37 --> Helper loaded: lang_helper
INFO - 2023-12-15 02:44:37 --> Helper loaded: security_helper
INFO - 2023-12-15 02:44:37 --> Helper loaded: cookie_helper
INFO - 2023-12-15 02:44:37 --> Database Driver Class Initialized
INFO - 2023-12-15 02:44:37 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-15 02:44:37 --> Parser Class Initialized
INFO - 2023-12-15 02:44:37 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-12-15 02:44:37 --> Pagination Class Initialized
INFO - 2023-12-15 02:44:37 --> Form Validation Class Initialized
INFO - 2023-12-15 02:44:37 --> Controller Class Initialized
INFO - 2023-12-15 02:44:37 --> Model Class Initialized
DEBUG - 2023-12-15 02:44:37 --> Session class already loaded. Second attempt ignored.
ERROR - 2023-12-15 02:44:37 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-12-15 02:44:37 --> Config Class Initialized
INFO - 2023-12-15 02:44:37 --> Hooks Class Initialized
DEBUG - 2023-12-15 02:44:37 --> UTF-8 Support Enabled
INFO - 2023-12-15 02:44:37 --> Utf8 Class Initialized
INFO - 2023-12-15 02:44:37 --> URI Class Initialized
INFO - 2023-12-15 02:44:37 --> Router Class Initialized
INFO - 2023-12-15 02:44:37 --> Output Class Initialized
INFO - 2023-12-15 02:44:37 --> Security Class Initialized
DEBUG - 2023-12-15 02:44:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-15 02:44:37 --> Input Class Initialized
INFO - 2023-12-15 02:44:37 --> Language Class Initialized
ERROR - 2023-12-15 02:44:37 --> 404 Page Not Found: Blog/wp-includes
ERROR - 2023-12-15 02:44:37 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-12-15 02:44:37 --> Config Class Initialized
INFO - 2023-12-15 02:44:37 --> Hooks Class Initialized
DEBUG - 2023-12-15 02:44:37 --> UTF-8 Support Enabled
INFO - 2023-12-15 02:44:37 --> Utf8 Class Initialized
INFO - 2023-12-15 02:44:37 --> URI Class Initialized
INFO - 2023-12-15 02:44:37 --> Router Class Initialized
INFO - 2023-12-15 02:44:37 --> Output Class Initialized
INFO - 2023-12-15 02:44:37 --> Security Class Initialized
DEBUG - 2023-12-15 02:44:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-15 02:44:37 --> Input Class Initialized
INFO - 2023-12-15 02:44:37 --> Language Class Initialized
ERROR - 2023-12-15 02:44:37 --> 404 Page Not Found: Web/wp-includes
ERROR - 2023-12-15 02:44:37 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-12-15 02:44:37 --> Config Class Initialized
INFO - 2023-12-15 02:44:37 --> Hooks Class Initialized
DEBUG - 2023-12-15 02:44:37 --> UTF-8 Support Enabled
INFO - 2023-12-15 02:44:37 --> Utf8 Class Initialized
INFO - 2023-12-15 02:44:37 --> URI Class Initialized
INFO - 2023-12-15 02:44:37 --> Router Class Initialized
INFO - 2023-12-15 02:44:37 --> Output Class Initialized
INFO - 2023-12-15 02:44:37 --> Security Class Initialized
DEBUG - 2023-12-15 02:44:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-15 02:44:37 --> Input Class Initialized
INFO - 2023-12-15 02:44:37 --> Language Class Initialized
ERROR - 2023-12-15 02:44:37 --> 404 Page Not Found: Wordpress/wp-includes
ERROR - 2023-12-15 02:44:37 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-12-15 02:44:37 --> Config Class Initialized
INFO - 2023-12-15 02:44:37 --> Hooks Class Initialized
DEBUG - 2023-12-15 02:44:37 --> UTF-8 Support Enabled
INFO - 2023-12-15 02:44:37 --> Utf8 Class Initialized
INFO - 2023-12-15 02:44:37 --> URI Class Initialized
INFO - 2023-12-15 02:44:37 --> Router Class Initialized
INFO - 2023-12-15 02:44:37 --> Output Class Initialized
INFO - 2023-12-15 02:44:37 --> Security Class Initialized
DEBUG - 2023-12-15 02:44:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-15 02:44:37 --> Input Class Initialized
INFO - 2023-12-15 02:44:37 --> Language Class Initialized
ERROR - 2023-12-15 02:44:37 --> 404 Page Not Found: Website/wp-includes
ERROR - 2023-12-15 02:44:37 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-12-15 02:44:37 --> Config Class Initialized
INFO - 2023-12-15 02:44:37 --> Hooks Class Initialized
DEBUG - 2023-12-15 02:44:37 --> UTF-8 Support Enabled
INFO - 2023-12-15 02:44:37 --> Utf8 Class Initialized
INFO - 2023-12-15 02:44:37 --> URI Class Initialized
INFO - 2023-12-15 02:44:37 --> Router Class Initialized
INFO - 2023-12-15 02:44:37 --> Output Class Initialized
INFO - 2023-12-15 02:44:37 --> Security Class Initialized
DEBUG - 2023-12-15 02:44:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-15 02:44:37 --> Input Class Initialized
INFO - 2023-12-15 02:44:37 --> Language Class Initialized
ERROR - 2023-12-15 02:44:37 --> 404 Page Not Found: Wp/wp-includes
ERROR - 2023-12-15 02:44:37 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-12-15 02:44:37 --> Config Class Initialized
INFO - 2023-12-15 02:44:37 --> Hooks Class Initialized
DEBUG - 2023-12-15 02:44:37 --> UTF-8 Support Enabled
INFO - 2023-12-15 02:44:37 --> Utf8 Class Initialized
INFO - 2023-12-15 02:44:37 --> URI Class Initialized
INFO - 2023-12-15 02:44:37 --> Router Class Initialized
INFO - 2023-12-15 02:44:37 --> Output Class Initialized
INFO - 2023-12-15 02:44:37 --> Security Class Initialized
DEBUG - 2023-12-15 02:44:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-15 02:44:37 --> Input Class Initialized
INFO - 2023-12-15 02:44:37 --> Language Class Initialized
ERROR - 2023-12-15 02:44:37 --> 404 Page Not Found: News/wp-includes
ERROR - 2023-12-15 02:44:37 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-12-15 02:44:37 --> Config Class Initialized
INFO - 2023-12-15 02:44:37 --> Hooks Class Initialized
DEBUG - 2023-12-15 02:44:37 --> UTF-8 Support Enabled
INFO - 2023-12-15 02:44:37 --> Utf8 Class Initialized
INFO - 2023-12-15 02:44:37 --> URI Class Initialized
INFO - 2023-12-15 02:44:37 --> Router Class Initialized
INFO - 2023-12-15 02:44:37 --> Output Class Initialized
INFO - 2023-12-15 02:44:37 --> Security Class Initialized
DEBUG - 2023-12-15 02:44:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-15 02:44:37 --> Input Class Initialized
INFO - 2023-12-15 02:44:37 --> Language Class Initialized
ERROR - 2023-12-15 02:44:37 --> 404 Page Not Found: 2020/wp-includes
ERROR - 2023-12-15 02:44:37 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-12-15 02:44:37 --> Config Class Initialized
INFO - 2023-12-15 02:44:37 --> Hooks Class Initialized
DEBUG - 2023-12-15 02:44:37 --> UTF-8 Support Enabled
INFO - 2023-12-15 02:44:37 --> Utf8 Class Initialized
INFO - 2023-12-15 02:44:37 --> URI Class Initialized
INFO - 2023-12-15 02:44:37 --> Router Class Initialized
INFO - 2023-12-15 02:44:37 --> Output Class Initialized
INFO - 2023-12-15 02:44:37 --> Security Class Initialized
DEBUG - 2023-12-15 02:44:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-15 02:44:37 --> Input Class Initialized
INFO - 2023-12-15 02:44:37 --> Language Class Initialized
ERROR - 2023-12-15 02:44:37 --> 404 Page Not Found: 2019/wp-includes
ERROR - 2023-12-15 02:44:37 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-12-15 02:44:37 --> Config Class Initialized
INFO - 2023-12-15 02:44:37 --> Hooks Class Initialized
DEBUG - 2023-12-15 02:44:37 --> UTF-8 Support Enabled
INFO - 2023-12-15 02:44:37 --> Utf8 Class Initialized
INFO - 2023-12-15 02:44:37 --> URI Class Initialized
INFO - 2023-12-15 02:44:37 --> Router Class Initialized
INFO - 2023-12-15 02:44:37 --> Output Class Initialized
INFO - 2023-12-15 02:44:37 --> Security Class Initialized
DEBUG - 2023-12-15 02:44:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-15 02:44:37 --> Input Class Initialized
INFO - 2023-12-15 02:44:37 --> Language Class Initialized
ERROR - 2023-12-15 02:44:37 --> 404 Page Not Found: Shop/wp-includes
ERROR - 2023-12-15 02:44:37 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-12-15 02:44:37 --> Config Class Initialized
INFO - 2023-12-15 02:44:37 --> Hooks Class Initialized
DEBUG - 2023-12-15 02:44:37 --> UTF-8 Support Enabled
INFO - 2023-12-15 02:44:37 --> Utf8 Class Initialized
INFO - 2023-12-15 02:44:37 --> URI Class Initialized
INFO - 2023-12-15 02:44:37 --> Router Class Initialized
INFO - 2023-12-15 02:44:37 --> Output Class Initialized
INFO - 2023-12-15 02:44:37 --> Security Class Initialized
DEBUG - 2023-12-15 02:44:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-15 02:44:37 --> Input Class Initialized
INFO - 2023-12-15 02:44:37 --> Language Class Initialized
ERROR - 2023-12-15 02:44:37 --> 404 Page Not Found: Wp1/wp-includes
ERROR - 2023-12-15 02:44:37 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-12-15 02:44:37 --> Config Class Initialized
INFO - 2023-12-15 02:44:37 --> Hooks Class Initialized
DEBUG - 2023-12-15 02:44:38 --> UTF-8 Support Enabled
INFO - 2023-12-15 02:44:38 --> Utf8 Class Initialized
INFO - 2023-12-15 02:44:38 --> URI Class Initialized
INFO - 2023-12-15 02:44:38 --> Router Class Initialized
INFO - 2023-12-15 02:44:38 --> Output Class Initialized
INFO - 2023-12-15 02:44:38 --> Security Class Initialized
DEBUG - 2023-12-15 02:44:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-15 02:44:38 --> Input Class Initialized
INFO - 2023-12-15 02:44:38 --> Language Class Initialized
ERROR - 2023-12-15 02:44:38 --> 404 Page Not Found: Test/wp-includes
ERROR - 2023-12-15 02:44:38 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-12-15 02:44:38 --> Config Class Initialized
INFO - 2023-12-15 02:44:38 --> Hooks Class Initialized
DEBUG - 2023-12-15 02:44:38 --> UTF-8 Support Enabled
INFO - 2023-12-15 02:44:38 --> Utf8 Class Initialized
INFO - 2023-12-15 02:44:38 --> URI Class Initialized
INFO - 2023-12-15 02:44:38 --> Router Class Initialized
INFO - 2023-12-15 02:44:38 --> Output Class Initialized
INFO - 2023-12-15 02:44:38 --> Security Class Initialized
DEBUG - 2023-12-15 02:44:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-15 02:44:38 --> Input Class Initialized
INFO - 2023-12-15 02:44:38 --> Language Class Initialized
ERROR - 2023-12-15 02:44:38 --> 404 Page Not Found: Wp2/wp-includes
ERROR - 2023-12-15 02:44:38 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-12-15 02:44:38 --> Config Class Initialized
INFO - 2023-12-15 02:44:38 --> Hooks Class Initialized
DEBUG - 2023-12-15 02:44:38 --> UTF-8 Support Enabled
INFO - 2023-12-15 02:44:38 --> Utf8 Class Initialized
INFO - 2023-12-15 02:44:38 --> URI Class Initialized
INFO - 2023-12-15 02:44:38 --> Router Class Initialized
INFO - 2023-12-15 02:44:38 --> Output Class Initialized
INFO - 2023-12-15 02:44:38 --> Security Class Initialized
DEBUG - 2023-12-15 02:44:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-15 02:44:38 --> Input Class Initialized
INFO - 2023-12-15 02:44:38 --> Language Class Initialized
ERROR - 2023-12-15 02:44:38 --> 404 Page Not Found: Site/wp-includes
ERROR - 2023-12-15 02:44:38 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-12-15 02:44:38 --> Config Class Initialized
INFO - 2023-12-15 02:44:38 --> Hooks Class Initialized
DEBUG - 2023-12-15 02:44:38 --> UTF-8 Support Enabled
INFO - 2023-12-15 02:44:38 --> Utf8 Class Initialized
INFO - 2023-12-15 02:44:38 --> URI Class Initialized
INFO - 2023-12-15 02:44:38 --> Router Class Initialized
INFO - 2023-12-15 02:44:38 --> Output Class Initialized
INFO - 2023-12-15 02:44:38 --> Security Class Initialized
DEBUG - 2023-12-15 02:44:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-15 02:44:38 --> Input Class Initialized
INFO - 2023-12-15 02:44:38 --> Language Class Initialized
ERROR - 2023-12-15 02:44:38 --> 404 Page Not Found: Cms/wp-includes
ERROR - 2023-12-15 02:44:38 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-12-15 02:44:38 --> Config Class Initialized
INFO - 2023-12-15 02:44:38 --> Hooks Class Initialized
DEBUG - 2023-12-15 02:44:38 --> UTF-8 Support Enabled
INFO - 2023-12-15 02:44:38 --> Utf8 Class Initialized
INFO - 2023-12-15 02:44:38 --> URI Class Initialized
INFO - 2023-12-15 02:44:38 --> Router Class Initialized
INFO - 2023-12-15 02:44:38 --> Output Class Initialized
INFO - 2023-12-15 02:44:38 --> Security Class Initialized
DEBUG - 2023-12-15 02:44:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-15 02:44:38 --> Input Class Initialized
INFO - 2023-12-15 02:44:38 --> Language Class Initialized
ERROR - 2023-12-15 02:44:38 --> 404 Page Not Found: Sito/wp-includes
ERROR - 2023-12-15 03:21:21 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-12-15 03:21:21 --> Config Class Initialized
INFO - 2023-12-15 03:21:21 --> Hooks Class Initialized
DEBUG - 2023-12-15 03:21:21 --> UTF-8 Support Enabled
INFO - 2023-12-15 03:21:21 --> Utf8 Class Initialized
INFO - 2023-12-15 03:21:21 --> URI Class Initialized
DEBUG - 2023-12-15 03:21:21 --> No URI present. Default controller set.
INFO - 2023-12-15 03:21:21 --> Router Class Initialized
INFO - 2023-12-15 03:21:21 --> Output Class Initialized
INFO - 2023-12-15 03:21:21 --> Security Class Initialized
DEBUG - 2023-12-15 03:21:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-15 03:21:21 --> Input Class Initialized
INFO - 2023-12-15 03:21:21 --> Language Class Initialized
INFO - 2023-12-15 03:21:21 --> Loader Class Initialized
INFO - 2023-12-15 03:21:21 --> Helper loaded: url_helper
INFO - 2023-12-15 03:21:21 --> Helper loaded: file_helper
INFO - 2023-12-15 03:21:21 --> Helper loaded: html_helper
INFO - 2023-12-15 03:21:21 --> Helper loaded: text_helper
INFO - 2023-12-15 03:21:21 --> Helper loaded: form_helper
INFO - 2023-12-15 03:21:21 --> Helper loaded: lang_helper
INFO - 2023-12-15 03:21:21 --> Helper loaded: security_helper
INFO - 2023-12-15 03:21:21 --> Helper loaded: cookie_helper
INFO - 2023-12-15 03:21:21 --> Database Driver Class Initialized
INFO - 2023-12-15 03:21:21 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-15 03:21:21 --> Parser Class Initialized
INFO - 2023-12-15 03:21:21 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-12-15 03:21:21 --> Pagination Class Initialized
INFO - 2023-12-15 03:21:21 --> Form Validation Class Initialized
INFO - 2023-12-15 03:21:21 --> Controller Class Initialized
INFO - 2023-12-15 03:21:21 --> Model Class Initialized
DEBUG - 2023-12-15 03:21:21 --> Session class already loaded. Second attempt ignored.
ERROR - 2023-12-15 03:21:21 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-12-15 03:21:21 --> Config Class Initialized
INFO - 2023-12-15 03:21:21 --> Hooks Class Initialized
DEBUG - 2023-12-15 03:21:21 --> UTF-8 Support Enabled
INFO - 2023-12-15 03:21:21 --> Utf8 Class Initialized
INFO - 2023-12-15 03:21:21 --> URI Class Initialized
INFO - 2023-12-15 03:21:21 --> Router Class Initialized
INFO - 2023-12-15 03:21:21 --> Output Class Initialized
INFO - 2023-12-15 03:21:21 --> Security Class Initialized
DEBUG - 2023-12-15 03:21:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-15 03:21:21 --> Input Class Initialized
INFO - 2023-12-15 03:21:21 --> Language Class Initialized
ERROR - 2023-12-15 03:21:21 --> 404 Page Not Found: Wp-includes/wlwmanifest.xml
ERROR - 2023-12-15 03:21:21 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-12-15 03:21:21 --> Config Class Initialized
INFO - 2023-12-15 03:21:21 --> Hooks Class Initialized
DEBUG - 2023-12-15 03:21:21 --> UTF-8 Support Enabled
INFO - 2023-12-15 03:21:21 --> Utf8 Class Initialized
INFO - 2023-12-15 03:21:21 --> URI Class Initialized
INFO - 2023-12-15 03:21:21 --> Router Class Initialized
INFO - 2023-12-15 03:21:21 --> Output Class Initialized
INFO - 2023-12-15 03:21:21 --> Security Class Initialized
DEBUG - 2023-12-15 03:21:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-15 03:21:21 --> Input Class Initialized
INFO - 2023-12-15 03:21:21 --> Language Class Initialized
ERROR - 2023-12-15 03:21:21 --> 404 Page Not Found: Xmlrpcphp/index
ERROR - 2023-12-15 03:21:21 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-12-15 03:21:21 --> Config Class Initialized
INFO - 2023-12-15 03:21:21 --> Hooks Class Initialized
DEBUG - 2023-12-15 03:21:21 --> UTF-8 Support Enabled
INFO - 2023-12-15 03:21:21 --> Utf8 Class Initialized
INFO - 2023-12-15 03:21:21 --> URI Class Initialized
DEBUG - 2023-12-15 03:21:21 --> No URI present. Default controller set.
INFO - 2023-12-15 03:21:21 --> Router Class Initialized
INFO - 2023-12-15 03:21:21 --> Output Class Initialized
INFO - 2023-12-15 03:21:21 --> Security Class Initialized
DEBUG - 2023-12-15 03:21:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-15 03:21:21 --> Input Class Initialized
INFO - 2023-12-15 03:21:21 --> Language Class Initialized
INFO - 2023-12-15 03:21:21 --> Loader Class Initialized
INFO - 2023-12-15 03:21:21 --> Helper loaded: url_helper
INFO - 2023-12-15 03:21:21 --> Helper loaded: file_helper
INFO - 2023-12-15 03:21:21 --> Helper loaded: html_helper
INFO - 2023-12-15 03:21:21 --> Helper loaded: text_helper
INFO - 2023-12-15 03:21:21 --> Helper loaded: form_helper
INFO - 2023-12-15 03:21:21 --> Helper loaded: lang_helper
INFO - 2023-12-15 03:21:21 --> Helper loaded: security_helper
INFO - 2023-12-15 03:21:21 --> Helper loaded: cookie_helper
INFO - 2023-12-15 03:21:21 --> Database Driver Class Initialized
INFO - 2023-12-15 03:21:21 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-15 03:21:21 --> Parser Class Initialized
INFO - 2023-12-15 03:21:21 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-12-15 03:21:21 --> Pagination Class Initialized
INFO - 2023-12-15 03:21:21 --> Form Validation Class Initialized
INFO - 2023-12-15 03:21:21 --> Controller Class Initialized
INFO - 2023-12-15 03:21:21 --> Model Class Initialized
DEBUG - 2023-12-15 03:21:21 --> Session class already loaded. Second attempt ignored.
ERROR - 2023-12-15 03:21:21 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-12-15 03:21:21 --> Config Class Initialized
INFO - 2023-12-15 03:21:21 --> Hooks Class Initialized
DEBUG - 2023-12-15 03:21:21 --> UTF-8 Support Enabled
INFO - 2023-12-15 03:21:21 --> Utf8 Class Initialized
INFO - 2023-12-15 03:21:21 --> URI Class Initialized
INFO - 2023-12-15 03:21:21 --> Router Class Initialized
INFO - 2023-12-15 03:21:21 --> Output Class Initialized
INFO - 2023-12-15 03:21:21 --> Security Class Initialized
DEBUG - 2023-12-15 03:21:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-15 03:21:21 --> Input Class Initialized
INFO - 2023-12-15 03:21:21 --> Language Class Initialized
ERROR - 2023-12-15 03:21:21 --> 404 Page Not Found: Blog/wp-includes
ERROR - 2023-12-15 03:21:21 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-12-15 03:21:21 --> Config Class Initialized
INFO - 2023-12-15 03:21:21 --> Hooks Class Initialized
DEBUG - 2023-12-15 03:21:21 --> UTF-8 Support Enabled
INFO - 2023-12-15 03:21:21 --> Utf8 Class Initialized
INFO - 2023-12-15 03:21:21 --> URI Class Initialized
INFO - 2023-12-15 03:21:21 --> Router Class Initialized
INFO - 2023-12-15 03:21:21 --> Output Class Initialized
INFO - 2023-12-15 03:21:21 --> Security Class Initialized
DEBUG - 2023-12-15 03:21:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-15 03:21:21 --> Input Class Initialized
INFO - 2023-12-15 03:21:21 --> Language Class Initialized
ERROR - 2023-12-15 03:21:21 --> 404 Page Not Found: Web/wp-includes
ERROR - 2023-12-15 03:21:21 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-12-15 03:21:21 --> Config Class Initialized
INFO - 2023-12-15 03:21:21 --> Hooks Class Initialized
DEBUG - 2023-12-15 03:21:21 --> UTF-8 Support Enabled
INFO - 2023-12-15 03:21:21 --> Utf8 Class Initialized
INFO - 2023-12-15 03:21:21 --> URI Class Initialized
INFO - 2023-12-15 03:21:21 --> Router Class Initialized
INFO - 2023-12-15 03:21:21 --> Output Class Initialized
INFO - 2023-12-15 03:21:21 --> Security Class Initialized
DEBUG - 2023-12-15 03:21:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-15 03:21:21 --> Input Class Initialized
INFO - 2023-12-15 03:21:21 --> Language Class Initialized
ERROR - 2023-12-15 03:21:21 --> 404 Page Not Found: Wordpress/wp-includes
ERROR - 2023-12-15 03:21:21 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-12-15 03:21:21 --> Config Class Initialized
INFO - 2023-12-15 03:21:21 --> Hooks Class Initialized
DEBUG - 2023-12-15 03:21:21 --> UTF-8 Support Enabled
INFO - 2023-12-15 03:21:21 --> Utf8 Class Initialized
INFO - 2023-12-15 03:21:21 --> URI Class Initialized
INFO - 2023-12-15 03:21:21 --> Router Class Initialized
INFO - 2023-12-15 03:21:21 --> Output Class Initialized
INFO - 2023-12-15 03:21:21 --> Security Class Initialized
DEBUG - 2023-12-15 03:21:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-15 03:21:21 --> Input Class Initialized
INFO - 2023-12-15 03:21:21 --> Language Class Initialized
ERROR - 2023-12-15 03:21:21 --> 404 Page Not Found: Website/wp-includes
ERROR - 2023-12-15 03:21:21 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-12-15 03:21:21 --> Config Class Initialized
INFO - 2023-12-15 03:21:21 --> Hooks Class Initialized
DEBUG - 2023-12-15 03:21:21 --> UTF-8 Support Enabled
INFO - 2023-12-15 03:21:21 --> Utf8 Class Initialized
INFO - 2023-12-15 03:21:21 --> URI Class Initialized
INFO - 2023-12-15 03:21:21 --> Router Class Initialized
INFO - 2023-12-15 03:21:21 --> Output Class Initialized
INFO - 2023-12-15 03:21:21 --> Security Class Initialized
DEBUG - 2023-12-15 03:21:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-15 03:21:21 --> Input Class Initialized
INFO - 2023-12-15 03:21:21 --> Language Class Initialized
ERROR - 2023-12-15 03:21:21 --> 404 Page Not Found: Wp/wp-includes
ERROR - 2023-12-15 03:21:21 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-12-15 03:21:21 --> Config Class Initialized
INFO - 2023-12-15 03:21:21 --> Hooks Class Initialized
DEBUG - 2023-12-15 03:21:21 --> UTF-8 Support Enabled
INFO - 2023-12-15 03:21:21 --> Utf8 Class Initialized
INFO - 2023-12-15 03:21:21 --> URI Class Initialized
INFO - 2023-12-15 03:21:21 --> Router Class Initialized
INFO - 2023-12-15 03:21:21 --> Output Class Initialized
INFO - 2023-12-15 03:21:21 --> Security Class Initialized
DEBUG - 2023-12-15 03:21:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-15 03:21:21 --> Input Class Initialized
INFO - 2023-12-15 03:21:21 --> Language Class Initialized
ERROR - 2023-12-15 03:21:21 --> 404 Page Not Found: News/wp-includes
ERROR - 2023-12-15 03:21:21 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-12-15 03:21:21 --> Config Class Initialized
INFO - 2023-12-15 03:21:21 --> Hooks Class Initialized
DEBUG - 2023-12-15 03:21:21 --> UTF-8 Support Enabled
INFO - 2023-12-15 03:21:21 --> Utf8 Class Initialized
INFO - 2023-12-15 03:21:21 --> URI Class Initialized
INFO - 2023-12-15 03:21:21 --> Router Class Initialized
INFO - 2023-12-15 03:21:21 --> Output Class Initialized
INFO - 2023-12-15 03:21:21 --> Security Class Initialized
DEBUG - 2023-12-15 03:21:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-15 03:21:21 --> Input Class Initialized
INFO - 2023-12-15 03:21:21 --> Language Class Initialized
ERROR - 2023-12-15 03:21:21 --> 404 Page Not Found: 2020/wp-includes
ERROR - 2023-12-15 03:21:21 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-12-15 03:21:21 --> Config Class Initialized
INFO - 2023-12-15 03:21:21 --> Hooks Class Initialized
DEBUG - 2023-12-15 03:21:21 --> UTF-8 Support Enabled
INFO - 2023-12-15 03:21:21 --> Utf8 Class Initialized
INFO - 2023-12-15 03:21:21 --> URI Class Initialized
INFO - 2023-12-15 03:21:21 --> Router Class Initialized
INFO - 2023-12-15 03:21:21 --> Output Class Initialized
INFO - 2023-12-15 03:21:21 --> Security Class Initialized
DEBUG - 2023-12-15 03:21:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-15 03:21:21 --> Input Class Initialized
INFO - 2023-12-15 03:21:21 --> Language Class Initialized
ERROR - 2023-12-15 03:21:21 --> 404 Page Not Found: 2019/wp-includes
ERROR - 2023-12-15 03:21:21 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-12-15 03:21:21 --> Config Class Initialized
INFO - 2023-12-15 03:21:21 --> Hooks Class Initialized
DEBUG - 2023-12-15 03:21:21 --> UTF-8 Support Enabled
INFO - 2023-12-15 03:21:21 --> Utf8 Class Initialized
INFO - 2023-12-15 03:21:21 --> URI Class Initialized
INFO - 2023-12-15 03:21:21 --> Router Class Initialized
INFO - 2023-12-15 03:21:21 --> Output Class Initialized
INFO - 2023-12-15 03:21:21 --> Security Class Initialized
DEBUG - 2023-12-15 03:21:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-15 03:21:21 --> Input Class Initialized
INFO - 2023-12-15 03:21:21 --> Language Class Initialized
ERROR - 2023-12-15 03:21:21 --> 404 Page Not Found: Shop/wp-includes
ERROR - 2023-12-15 03:21:21 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-12-15 03:21:21 --> Config Class Initialized
INFO - 2023-12-15 03:21:21 --> Hooks Class Initialized
DEBUG - 2023-12-15 03:21:21 --> UTF-8 Support Enabled
INFO - 2023-12-15 03:21:21 --> Utf8 Class Initialized
INFO - 2023-12-15 03:21:21 --> URI Class Initialized
INFO - 2023-12-15 03:21:21 --> Router Class Initialized
INFO - 2023-12-15 03:21:21 --> Output Class Initialized
INFO - 2023-12-15 03:21:21 --> Security Class Initialized
DEBUG - 2023-12-15 03:21:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-15 03:21:21 --> Input Class Initialized
INFO - 2023-12-15 03:21:21 --> Language Class Initialized
ERROR - 2023-12-15 03:21:21 --> 404 Page Not Found: Wp1/wp-includes
ERROR - 2023-12-15 03:21:21 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-12-15 03:21:21 --> Config Class Initialized
INFO - 2023-12-15 03:21:21 --> Hooks Class Initialized
DEBUG - 2023-12-15 03:21:21 --> UTF-8 Support Enabled
INFO - 2023-12-15 03:21:21 --> Utf8 Class Initialized
INFO - 2023-12-15 03:21:21 --> URI Class Initialized
INFO - 2023-12-15 03:21:21 --> Router Class Initialized
INFO - 2023-12-15 03:21:21 --> Output Class Initialized
INFO - 2023-12-15 03:21:21 --> Security Class Initialized
DEBUG - 2023-12-15 03:21:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-15 03:21:21 --> Input Class Initialized
INFO - 2023-12-15 03:21:21 --> Language Class Initialized
ERROR - 2023-12-15 03:21:21 --> 404 Page Not Found: Test/wp-includes
ERROR - 2023-12-15 03:21:21 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-12-15 03:21:21 --> Config Class Initialized
INFO - 2023-12-15 03:21:21 --> Hooks Class Initialized
DEBUG - 2023-12-15 03:21:21 --> UTF-8 Support Enabled
INFO - 2023-12-15 03:21:21 --> Utf8 Class Initialized
INFO - 2023-12-15 03:21:21 --> URI Class Initialized
INFO - 2023-12-15 03:21:21 --> Router Class Initialized
INFO - 2023-12-15 03:21:21 --> Output Class Initialized
INFO - 2023-12-15 03:21:21 --> Security Class Initialized
DEBUG - 2023-12-15 03:21:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-15 03:21:21 --> Input Class Initialized
INFO - 2023-12-15 03:21:21 --> Language Class Initialized
ERROR - 2023-12-15 03:21:21 --> 404 Page Not Found: Wp2/wp-includes
ERROR - 2023-12-15 03:21:21 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-12-15 03:21:21 --> Config Class Initialized
INFO - 2023-12-15 03:21:21 --> Hooks Class Initialized
DEBUG - 2023-12-15 03:21:21 --> UTF-8 Support Enabled
INFO - 2023-12-15 03:21:21 --> Utf8 Class Initialized
INFO - 2023-12-15 03:21:21 --> URI Class Initialized
INFO - 2023-12-15 03:21:21 --> Router Class Initialized
INFO - 2023-12-15 03:21:21 --> Output Class Initialized
INFO - 2023-12-15 03:21:21 --> Security Class Initialized
DEBUG - 2023-12-15 03:21:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-15 03:21:21 --> Input Class Initialized
INFO - 2023-12-15 03:21:21 --> Language Class Initialized
ERROR - 2023-12-15 03:21:21 --> 404 Page Not Found: Site/wp-includes
ERROR - 2023-12-15 03:21:21 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-12-15 03:21:21 --> Config Class Initialized
INFO - 2023-12-15 03:21:21 --> Hooks Class Initialized
DEBUG - 2023-12-15 03:21:21 --> UTF-8 Support Enabled
INFO - 2023-12-15 03:21:21 --> Utf8 Class Initialized
INFO - 2023-12-15 03:21:21 --> URI Class Initialized
INFO - 2023-12-15 03:21:21 --> Router Class Initialized
INFO - 2023-12-15 03:21:21 --> Output Class Initialized
INFO - 2023-12-15 03:21:21 --> Security Class Initialized
DEBUG - 2023-12-15 03:21:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-15 03:21:21 --> Input Class Initialized
INFO - 2023-12-15 03:21:21 --> Language Class Initialized
ERROR - 2023-12-15 03:21:21 --> 404 Page Not Found: Cms/wp-includes
ERROR - 2023-12-15 03:21:22 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-12-15 03:21:22 --> Config Class Initialized
INFO - 2023-12-15 03:21:22 --> Hooks Class Initialized
DEBUG - 2023-12-15 03:21:22 --> UTF-8 Support Enabled
INFO - 2023-12-15 03:21:22 --> Utf8 Class Initialized
INFO - 2023-12-15 03:21:22 --> URI Class Initialized
INFO - 2023-12-15 03:21:22 --> Router Class Initialized
INFO - 2023-12-15 03:21:22 --> Output Class Initialized
INFO - 2023-12-15 03:21:22 --> Security Class Initialized
DEBUG - 2023-12-15 03:21:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-15 03:21:22 --> Input Class Initialized
INFO - 2023-12-15 03:21:22 --> Language Class Initialized
ERROR - 2023-12-15 03:21:22 --> 404 Page Not Found: Sito/wp-includes
ERROR - 2023-12-15 04:08:30 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-12-15 04:08:30 --> Config Class Initialized
INFO - 2023-12-15 04:08:30 --> Hooks Class Initialized
DEBUG - 2023-12-15 04:08:30 --> UTF-8 Support Enabled
INFO - 2023-12-15 04:08:30 --> Utf8 Class Initialized
INFO - 2023-12-15 04:08:30 --> URI Class Initialized
DEBUG - 2023-12-15 04:08:30 --> No URI present. Default controller set.
INFO - 2023-12-15 04:08:30 --> Router Class Initialized
INFO - 2023-12-15 04:08:30 --> Output Class Initialized
INFO - 2023-12-15 04:08:30 --> Security Class Initialized
DEBUG - 2023-12-15 04:08:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-15 04:08:30 --> Input Class Initialized
INFO - 2023-12-15 04:08:30 --> Language Class Initialized
INFO - 2023-12-15 04:08:30 --> Loader Class Initialized
INFO - 2023-12-15 04:08:30 --> Helper loaded: url_helper
INFO - 2023-12-15 04:08:30 --> Helper loaded: file_helper
INFO - 2023-12-15 04:08:30 --> Helper loaded: html_helper
INFO - 2023-12-15 04:08:30 --> Helper loaded: text_helper
INFO - 2023-12-15 04:08:30 --> Helper loaded: form_helper
INFO - 2023-12-15 04:08:30 --> Helper loaded: lang_helper
INFO - 2023-12-15 04:08:30 --> Helper loaded: security_helper
INFO - 2023-12-15 04:08:30 --> Helper loaded: cookie_helper
INFO - 2023-12-15 04:08:30 --> Database Driver Class Initialized
INFO - 2023-12-15 04:08:30 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-15 04:08:30 --> Parser Class Initialized
INFO - 2023-12-15 04:08:30 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-12-15 04:08:30 --> Pagination Class Initialized
INFO - 2023-12-15 04:08:30 --> Form Validation Class Initialized
INFO - 2023-12-15 04:08:30 --> Controller Class Initialized
INFO - 2023-12-15 04:08:30 --> Model Class Initialized
DEBUG - 2023-12-15 04:08:30 --> Session class already loaded. Second attempt ignored.
ERROR - 2023-12-15 04:08:31 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-12-15 04:08:31 --> Config Class Initialized
INFO - 2023-12-15 04:08:31 --> Hooks Class Initialized
DEBUG - 2023-12-15 04:08:31 --> UTF-8 Support Enabled
INFO - 2023-12-15 04:08:31 --> Utf8 Class Initialized
INFO - 2023-12-15 04:08:31 --> URI Class Initialized
INFO - 2023-12-15 04:08:31 --> Router Class Initialized
INFO - 2023-12-15 04:08:31 --> Output Class Initialized
INFO - 2023-12-15 04:08:31 --> Security Class Initialized
DEBUG - 2023-12-15 04:08:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-15 04:08:31 --> Input Class Initialized
INFO - 2023-12-15 04:08:31 --> Language Class Initialized
INFO - 2023-12-15 04:08:31 --> Loader Class Initialized
INFO - 2023-12-15 04:08:31 --> Helper loaded: url_helper
INFO - 2023-12-15 04:08:31 --> Helper loaded: file_helper
INFO - 2023-12-15 04:08:31 --> Helper loaded: html_helper
INFO - 2023-12-15 04:08:31 --> Helper loaded: text_helper
INFO - 2023-12-15 04:08:31 --> Helper loaded: form_helper
INFO - 2023-12-15 04:08:31 --> Helper loaded: lang_helper
INFO - 2023-12-15 04:08:31 --> Helper loaded: security_helper
INFO - 2023-12-15 04:08:31 --> Helper loaded: cookie_helper
INFO - 2023-12-15 04:08:31 --> Database Driver Class Initialized
INFO - 2023-12-15 04:08:31 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-15 04:08:31 --> Parser Class Initialized
INFO - 2023-12-15 04:08:31 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-12-15 04:08:31 --> Pagination Class Initialized
INFO - 2023-12-15 04:08:31 --> Form Validation Class Initialized
INFO - 2023-12-15 04:08:31 --> Controller Class Initialized
INFO - 2023-12-15 04:08:31 --> Model Class Initialized
DEBUG - 2023-12-15 04:08:31 --> Session class already loaded. Second attempt ignored.
INFO - 2023-12-15 04:08:31 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2023-12-15 04:08:31 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-12-15 04:08:31 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-12-15 04:08:31 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-12-15 04:08:31 --> Model Class Initialized
INFO - 2023-12-15 04:08:31 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-12-15 04:08:31 --> Final output sent to browser
DEBUG - 2023-12-15 04:08:31 --> Total execution time: 0.0335
ERROR - 2023-12-15 04:08:36 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-12-15 04:08:36 --> Config Class Initialized
INFO - 2023-12-15 04:08:36 --> Hooks Class Initialized
DEBUG - 2023-12-15 04:08:36 --> UTF-8 Support Enabled
INFO - 2023-12-15 04:08:36 --> Utf8 Class Initialized
INFO - 2023-12-15 04:08:36 --> URI Class Initialized
INFO - 2023-12-15 04:08:36 --> Router Class Initialized
INFO - 2023-12-15 04:08:36 --> Output Class Initialized
INFO - 2023-12-15 04:08:36 --> Security Class Initialized
DEBUG - 2023-12-15 04:08:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-15 04:08:36 --> Input Class Initialized
INFO - 2023-12-15 04:08:36 --> Language Class Initialized
INFO - 2023-12-15 04:08:36 --> Loader Class Initialized
INFO - 2023-12-15 04:08:36 --> Helper loaded: url_helper
INFO - 2023-12-15 04:08:36 --> Helper loaded: file_helper
INFO - 2023-12-15 04:08:36 --> Helper loaded: html_helper
INFO - 2023-12-15 04:08:36 --> Helper loaded: text_helper
INFO - 2023-12-15 04:08:36 --> Helper loaded: form_helper
INFO - 2023-12-15 04:08:36 --> Helper loaded: lang_helper
INFO - 2023-12-15 04:08:36 --> Helper loaded: security_helper
INFO - 2023-12-15 04:08:36 --> Helper loaded: cookie_helper
INFO - 2023-12-15 04:08:36 --> Database Driver Class Initialized
INFO - 2023-12-15 04:08:36 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-15 04:08:36 --> Parser Class Initialized
INFO - 2023-12-15 04:08:36 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-12-15 04:08:36 --> Pagination Class Initialized
INFO - 2023-12-15 04:08:36 --> Form Validation Class Initialized
INFO - 2023-12-15 04:08:36 --> Controller Class Initialized
INFO - 2023-12-15 04:08:36 --> Model Class Initialized
DEBUG - 2023-12-15 04:08:36 --> Session class already loaded. Second attempt ignored.
INFO - 2023-12-15 04:08:36 --> Model Class Initialized
INFO - 2023-12-15 04:08:36 --> Final output sent to browser
DEBUG - 2023-12-15 04:08:36 --> Total execution time: 0.0177
ERROR - 2023-12-15 04:08:37 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-12-15 04:08:37 --> Config Class Initialized
INFO - 2023-12-15 04:08:37 --> Hooks Class Initialized
DEBUG - 2023-12-15 04:08:37 --> UTF-8 Support Enabled
INFO - 2023-12-15 04:08:37 --> Utf8 Class Initialized
INFO - 2023-12-15 04:08:37 --> URI Class Initialized
DEBUG - 2023-12-15 04:08:37 --> No URI present. Default controller set.
INFO - 2023-12-15 04:08:37 --> Router Class Initialized
INFO - 2023-12-15 04:08:37 --> Output Class Initialized
INFO - 2023-12-15 04:08:37 --> Security Class Initialized
DEBUG - 2023-12-15 04:08:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-15 04:08:37 --> Input Class Initialized
INFO - 2023-12-15 04:08:37 --> Language Class Initialized
INFO - 2023-12-15 04:08:37 --> Loader Class Initialized
INFO - 2023-12-15 04:08:37 --> Helper loaded: url_helper
INFO - 2023-12-15 04:08:37 --> Helper loaded: file_helper
INFO - 2023-12-15 04:08:37 --> Helper loaded: html_helper
INFO - 2023-12-15 04:08:37 --> Helper loaded: text_helper
INFO - 2023-12-15 04:08:37 --> Helper loaded: form_helper
INFO - 2023-12-15 04:08:37 --> Helper loaded: lang_helper
INFO - 2023-12-15 04:08:37 --> Helper loaded: security_helper
INFO - 2023-12-15 04:08:37 --> Helper loaded: cookie_helper
INFO - 2023-12-15 04:08:37 --> Database Driver Class Initialized
INFO - 2023-12-15 04:08:37 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-15 04:08:37 --> Parser Class Initialized
INFO - 2023-12-15 04:08:37 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-12-15 04:08:37 --> Pagination Class Initialized
INFO - 2023-12-15 04:08:37 --> Form Validation Class Initialized
INFO - 2023-12-15 04:08:37 --> Controller Class Initialized
INFO - 2023-12-15 04:08:37 --> Model Class Initialized
DEBUG - 2023-12-15 04:08:37 --> Session class already loaded. Second attempt ignored.
INFO - 2023-12-15 04:08:37 --> Model Class Initialized
DEBUG - 2023-12-15 04:08:37 --> Session class already loaded. Second attempt ignored.
INFO - 2023-12-15 04:08:37 --> Model Class Initialized
INFO - 2023-12-15 04:08:37 --> Model Class Initialized
INFO - 2023-12-15 04:08:37 --> Model Class Initialized
INFO - 2023-12-15 04:08:37 --> Model Class Initialized
DEBUG - 2023-12-15 04:08:37 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-12-15 04:08:37 --> Session class already loaded. Second attempt ignored.
INFO - 2023-12-15 04:08:37 --> Model Class Initialized
INFO - 2023-12-15 04:08:37 --> Model Class Initialized
INFO - 2023-12-15 04:08:37 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-12-15 04:08:37 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-12-15 04:08:37 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-12-15 04:08:37 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-12-15 04:08:37 --> Model Class Initialized
INFO - 2023-12-15 04:08:37 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-12-15 04:08:37 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-12-15 04:08:37 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-12-15 04:08:37 --> Final output sent to browser
DEBUG - 2023-12-15 04:08:37 --> Total execution time: 0.4087
ERROR - 2023-12-15 04:08:39 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-12-15 04:08:39 --> Config Class Initialized
INFO - 2023-12-15 04:08:39 --> Hooks Class Initialized
DEBUG - 2023-12-15 04:08:39 --> UTF-8 Support Enabled
INFO - 2023-12-15 04:08:39 --> Utf8 Class Initialized
INFO - 2023-12-15 04:08:39 --> URI Class Initialized
INFO - 2023-12-15 04:08:39 --> Router Class Initialized
INFO - 2023-12-15 04:08:39 --> Output Class Initialized
INFO - 2023-12-15 04:08:39 --> Security Class Initialized
DEBUG - 2023-12-15 04:08:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-15 04:08:39 --> Input Class Initialized
INFO - 2023-12-15 04:08:39 --> Language Class Initialized
INFO - 2023-12-15 04:08:39 --> Loader Class Initialized
INFO - 2023-12-15 04:08:39 --> Helper loaded: url_helper
INFO - 2023-12-15 04:08:39 --> Helper loaded: file_helper
INFO - 2023-12-15 04:08:39 --> Helper loaded: html_helper
INFO - 2023-12-15 04:08:39 --> Helper loaded: text_helper
INFO - 2023-12-15 04:08:39 --> Helper loaded: form_helper
INFO - 2023-12-15 04:08:39 --> Helper loaded: lang_helper
INFO - 2023-12-15 04:08:39 --> Helper loaded: security_helper
INFO - 2023-12-15 04:08:39 --> Helper loaded: cookie_helper
INFO - 2023-12-15 04:08:39 --> Database Driver Class Initialized
INFO - 2023-12-15 04:08:39 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-15 04:08:39 --> Parser Class Initialized
INFO - 2023-12-15 04:08:39 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-12-15 04:08:39 --> Pagination Class Initialized
INFO - 2023-12-15 04:08:39 --> Form Validation Class Initialized
INFO - 2023-12-15 04:08:39 --> Controller Class Initialized
DEBUG - 2023-12-15 04:08:39 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-12-15 04:08:39 --> Session class already loaded. Second attempt ignored.
INFO - 2023-12-15 04:08:39 --> Model Class Initialized
INFO - 2023-12-15 04:08:39 --> Final output sent to browser
DEBUG - 2023-12-15 04:08:39 --> Total execution time: 0.0124
ERROR - 2023-12-15 04:08:54 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-12-15 04:08:54 --> Config Class Initialized
INFO - 2023-12-15 04:08:54 --> Hooks Class Initialized
DEBUG - 2023-12-15 04:08:54 --> UTF-8 Support Enabled
INFO - 2023-12-15 04:08:54 --> Utf8 Class Initialized
INFO - 2023-12-15 04:08:54 --> URI Class Initialized
INFO - 2023-12-15 04:08:54 --> Router Class Initialized
INFO - 2023-12-15 04:08:54 --> Output Class Initialized
INFO - 2023-12-15 04:08:54 --> Security Class Initialized
DEBUG - 2023-12-15 04:08:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-15 04:08:54 --> Input Class Initialized
INFO - 2023-12-15 04:08:54 --> Language Class Initialized
INFO - 2023-12-15 04:08:54 --> Loader Class Initialized
INFO - 2023-12-15 04:08:54 --> Helper loaded: url_helper
INFO - 2023-12-15 04:08:54 --> Helper loaded: file_helper
INFO - 2023-12-15 04:08:54 --> Helper loaded: html_helper
INFO - 2023-12-15 04:08:54 --> Helper loaded: text_helper
INFO - 2023-12-15 04:08:54 --> Helper loaded: form_helper
INFO - 2023-12-15 04:08:54 --> Helper loaded: lang_helper
INFO - 2023-12-15 04:08:54 --> Helper loaded: security_helper
INFO - 2023-12-15 04:08:54 --> Helper loaded: cookie_helper
INFO - 2023-12-15 04:08:54 --> Database Driver Class Initialized
INFO - 2023-12-15 04:08:54 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-15 04:08:54 --> Parser Class Initialized
INFO - 2023-12-15 04:08:54 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-12-15 04:08:54 --> Pagination Class Initialized
INFO - 2023-12-15 04:08:54 --> Form Validation Class Initialized
INFO - 2023-12-15 04:08:54 --> Controller Class Initialized
INFO - 2023-12-15 04:08:54 --> Model Class Initialized
DEBUG - 2023-12-15 04:08:54 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-12-15 04:08:54 --> Session class already loaded. Second attempt ignored.
INFO - 2023-12-15 04:08:54 --> Model Class Initialized
DEBUG - 2023-12-15 04:08:54 --> Session class already loaded. Second attempt ignored.
INFO - 2023-12-15 04:08:54 --> Model Class Initialized
INFO - 2023-12-15 04:08:54 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice.php
DEBUG - 2023-12-15 04:08:54 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-12-15 04:08:54 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-12-15 04:08:54 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-12-15 04:08:54 --> Model Class Initialized
INFO - 2023-12-15 04:08:54 --> Model Class Initialized
INFO - 2023-12-15 04:08:54 --> Model Class Initialized
INFO - 2023-12-15 04:08:54 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-12-15 04:08:54 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-12-15 04:08:54 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-12-15 04:08:54 --> Final output sent to browser
DEBUG - 2023-12-15 04:08:54 --> Total execution time: 0.2090
ERROR - 2023-12-15 04:08:55 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-12-15 04:08:55 --> Config Class Initialized
INFO - 2023-12-15 04:08:55 --> Hooks Class Initialized
DEBUG - 2023-12-15 04:08:55 --> UTF-8 Support Enabled
INFO - 2023-12-15 04:08:55 --> Utf8 Class Initialized
INFO - 2023-12-15 04:08:55 --> URI Class Initialized
INFO - 2023-12-15 04:08:55 --> Router Class Initialized
INFO - 2023-12-15 04:08:55 --> Output Class Initialized
INFO - 2023-12-15 04:08:55 --> Security Class Initialized
DEBUG - 2023-12-15 04:08:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-15 04:08:55 --> Input Class Initialized
INFO - 2023-12-15 04:08:55 --> Language Class Initialized
INFO - 2023-12-15 04:08:55 --> Loader Class Initialized
INFO - 2023-12-15 04:08:55 --> Helper loaded: url_helper
INFO - 2023-12-15 04:08:55 --> Helper loaded: file_helper
INFO - 2023-12-15 04:08:55 --> Helper loaded: html_helper
INFO - 2023-12-15 04:08:55 --> Helper loaded: text_helper
INFO - 2023-12-15 04:08:55 --> Helper loaded: form_helper
INFO - 2023-12-15 04:08:55 --> Helper loaded: lang_helper
INFO - 2023-12-15 04:08:55 --> Helper loaded: security_helper
INFO - 2023-12-15 04:08:55 --> Helper loaded: cookie_helper
INFO - 2023-12-15 04:08:55 --> Database Driver Class Initialized
INFO - 2023-12-15 04:08:55 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-15 04:08:55 --> Parser Class Initialized
INFO - 2023-12-15 04:08:55 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-12-15 04:08:55 --> Pagination Class Initialized
INFO - 2023-12-15 04:08:55 --> Form Validation Class Initialized
INFO - 2023-12-15 04:08:55 --> Controller Class Initialized
INFO - 2023-12-15 04:08:55 --> Model Class Initialized
DEBUG - 2023-12-15 04:08:55 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-12-15 04:08:55 --> Session class already loaded. Second attempt ignored.
INFO - 2023-12-15 04:08:55 --> Model Class Initialized
DEBUG - 2023-12-15 04:08:55 --> Session class already loaded. Second attempt ignored.
INFO - 2023-12-15 04:08:55 --> Model Class Initialized
INFO - 2023-12-15 04:08:55 --> Final output sent to browser
DEBUG - 2023-12-15 04:08:55 --> Total execution time: 0.0593
ERROR - 2023-12-15 04:09:02 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-12-15 04:09:02 --> Config Class Initialized
INFO - 2023-12-15 04:09:02 --> Hooks Class Initialized
DEBUG - 2023-12-15 04:09:02 --> UTF-8 Support Enabled
INFO - 2023-12-15 04:09:02 --> Utf8 Class Initialized
INFO - 2023-12-15 04:09:02 --> URI Class Initialized
INFO - 2023-12-15 04:09:02 --> Router Class Initialized
INFO - 2023-12-15 04:09:02 --> Output Class Initialized
INFO - 2023-12-15 04:09:02 --> Security Class Initialized
DEBUG - 2023-12-15 04:09:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-15 04:09:02 --> Input Class Initialized
INFO - 2023-12-15 04:09:02 --> Language Class Initialized
INFO - 2023-12-15 04:09:02 --> Loader Class Initialized
INFO - 2023-12-15 04:09:02 --> Helper loaded: url_helper
INFO - 2023-12-15 04:09:02 --> Helper loaded: file_helper
INFO - 2023-12-15 04:09:02 --> Helper loaded: html_helper
INFO - 2023-12-15 04:09:02 --> Helper loaded: text_helper
INFO - 2023-12-15 04:09:02 --> Helper loaded: form_helper
INFO - 2023-12-15 04:09:02 --> Helper loaded: lang_helper
INFO - 2023-12-15 04:09:02 --> Helper loaded: security_helper
INFO - 2023-12-15 04:09:02 --> Helper loaded: cookie_helper
INFO - 2023-12-15 04:09:02 --> Database Driver Class Initialized
INFO - 2023-12-15 04:09:02 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-15 04:09:02 --> Parser Class Initialized
INFO - 2023-12-15 04:09:02 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-12-15 04:09:02 --> Pagination Class Initialized
INFO - 2023-12-15 04:09:02 --> Form Validation Class Initialized
INFO - 2023-12-15 04:09:02 --> Controller Class Initialized
INFO - 2023-12-15 04:09:02 --> Model Class Initialized
DEBUG - 2023-12-15 04:09:02 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-12-15 04:09:02 --> Session class already loaded. Second attempt ignored.
INFO - 2023-12-15 04:09:02 --> Model Class Initialized
DEBUG - 2023-12-15 04:09:02 --> Session class already loaded. Second attempt ignored.
INFO - 2023-12-15 04:09:02 --> Model Class Initialized
INFO - 2023-12-15 04:09:02 --> Final output sent to browser
DEBUG - 2023-12-15 04:09:02 --> Total execution time: 0.0629
ERROR - 2023-12-15 04:09:03 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-12-15 04:09:03 --> Config Class Initialized
INFO - 2023-12-15 04:09:03 --> Hooks Class Initialized
DEBUG - 2023-12-15 04:09:03 --> UTF-8 Support Enabled
INFO - 2023-12-15 04:09:03 --> Utf8 Class Initialized
INFO - 2023-12-15 04:09:03 --> URI Class Initialized
INFO - 2023-12-15 04:09:03 --> Router Class Initialized
INFO - 2023-12-15 04:09:03 --> Output Class Initialized
INFO - 2023-12-15 04:09:03 --> Security Class Initialized
DEBUG - 2023-12-15 04:09:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-15 04:09:03 --> Input Class Initialized
INFO - 2023-12-15 04:09:03 --> Language Class Initialized
INFO - 2023-12-15 04:09:03 --> Loader Class Initialized
INFO - 2023-12-15 04:09:03 --> Helper loaded: url_helper
INFO - 2023-12-15 04:09:03 --> Helper loaded: file_helper
INFO - 2023-12-15 04:09:03 --> Helper loaded: html_helper
INFO - 2023-12-15 04:09:03 --> Helper loaded: text_helper
INFO - 2023-12-15 04:09:03 --> Helper loaded: form_helper
INFO - 2023-12-15 04:09:03 --> Helper loaded: lang_helper
INFO - 2023-12-15 04:09:03 --> Helper loaded: security_helper
INFO - 2023-12-15 04:09:03 --> Helper loaded: cookie_helper
INFO - 2023-12-15 04:09:03 --> Database Driver Class Initialized
INFO - 2023-12-15 04:09:03 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-15 04:09:03 --> Parser Class Initialized
INFO - 2023-12-15 04:09:03 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-12-15 04:09:03 --> Pagination Class Initialized
INFO - 2023-12-15 04:09:03 --> Form Validation Class Initialized
INFO - 2023-12-15 04:09:03 --> Controller Class Initialized
INFO - 2023-12-15 04:09:03 --> Model Class Initialized
DEBUG - 2023-12-15 04:09:03 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-12-15 04:09:03 --> Session class already loaded. Second attempt ignored.
INFO - 2023-12-15 04:09:03 --> Model Class Initialized
DEBUG - 2023-12-15 04:09:03 --> Session class already loaded. Second attempt ignored.
INFO - 2023-12-15 04:09:03 --> Model Class Initialized
INFO - 2023-12-15 04:09:03 --> Final output sent to browser
DEBUG - 2023-12-15 04:09:03 --> Total execution time: 0.0624
ERROR - 2023-12-15 04:09:03 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-12-15 04:09:03 --> Config Class Initialized
INFO - 2023-12-15 04:09:03 --> Hooks Class Initialized
DEBUG - 2023-12-15 04:09:03 --> UTF-8 Support Enabled
INFO - 2023-12-15 04:09:03 --> Utf8 Class Initialized
INFO - 2023-12-15 04:09:03 --> URI Class Initialized
INFO - 2023-12-15 04:09:03 --> Router Class Initialized
INFO - 2023-12-15 04:09:03 --> Output Class Initialized
INFO - 2023-12-15 04:09:03 --> Security Class Initialized
DEBUG - 2023-12-15 04:09:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-15 04:09:03 --> Input Class Initialized
INFO - 2023-12-15 04:09:03 --> Language Class Initialized
INFO - 2023-12-15 04:09:03 --> Loader Class Initialized
INFO - 2023-12-15 04:09:03 --> Helper loaded: url_helper
INFO - 2023-12-15 04:09:03 --> Helper loaded: file_helper
INFO - 2023-12-15 04:09:03 --> Helper loaded: html_helper
INFO - 2023-12-15 04:09:03 --> Helper loaded: text_helper
INFO - 2023-12-15 04:09:03 --> Helper loaded: form_helper
INFO - 2023-12-15 04:09:03 --> Helper loaded: lang_helper
INFO - 2023-12-15 04:09:03 --> Helper loaded: security_helper
INFO - 2023-12-15 04:09:03 --> Helper loaded: cookie_helper
INFO - 2023-12-15 04:09:03 --> Database Driver Class Initialized
INFO - 2023-12-15 04:09:03 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-15 04:09:03 --> Parser Class Initialized
INFO - 2023-12-15 04:09:03 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-12-15 04:09:03 --> Pagination Class Initialized
INFO - 2023-12-15 04:09:03 --> Form Validation Class Initialized
INFO - 2023-12-15 04:09:03 --> Controller Class Initialized
INFO - 2023-12-15 04:09:03 --> Model Class Initialized
DEBUG - 2023-12-15 04:09:03 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-12-15 04:09:03 --> Session class already loaded. Second attempt ignored.
INFO - 2023-12-15 04:09:03 --> Model Class Initialized
DEBUG - 2023-12-15 04:09:03 --> Session class already loaded. Second attempt ignored.
INFO - 2023-12-15 04:09:03 --> Model Class Initialized
INFO - 2023-12-15 04:09:03 --> Final output sent to browser
DEBUG - 2023-12-15 04:09:03 --> Total execution time: 0.0354
ERROR - 2023-12-15 04:09:04 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-12-15 04:09:04 --> Config Class Initialized
INFO - 2023-12-15 04:09:04 --> Hooks Class Initialized
DEBUG - 2023-12-15 04:09:04 --> UTF-8 Support Enabled
INFO - 2023-12-15 04:09:04 --> Utf8 Class Initialized
INFO - 2023-12-15 04:09:04 --> URI Class Initialized
INFO - 2023-12-15 04:09:04 --> Router Class Initialized
INFO - 2023-12-15 04:09:04 --> Output Class Initialized
INFO - 2023-12-15 04:09:04 --> Security Class Initialized
DEBUG - 2023-12-15 04:09:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-15 04:09:04 --> Input Class Initialized
INFO - 2023-12-15 04:09:04 --> Language Class Initialized
INFO - 2023-12-15 04:09:04 --> Loader Class Initialized
INFO - 2023-12-15 04:09:04 --> Helper loaded: url_helper
INFO - 2023-12-15 04:09:04 --> Helper loaded: file_helper
INFO - 2023-12-15 04:09:04 --> Helper loaded: html_helper
INFO - 2023-12-15 04:09:04 --> Helper loaded: text_helper
INFO - 2023-12-15 04:09:04 --> Helper loaded: form_helper
INFO - 2023-12-15 04:09:04 --> Helper loaded: lang_helper
INFO - 2023-12-15 04:09:04 --> Helper loaded: security_helper
INFO - 2023-12-15 04:09:04 --> Helper loaded: cookie_helper
INFO - 2023-12-15 04:09:04 --> Database Driver Class Initialized
INFO - 2023-12-15 04:09:04 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-15 04:09:04 --> Parser Class Initialized
INFO - 2023-12-15 04:09:04 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-12-15 04:09:04 --> Pagination Class Initialized
INFO - 2023-12-15 04:09:04 --> Form Validation Class Initialized
INFO - 2023-12-15 04:09:04 --> Controller Class Initialized
INFO - 2023-12-15 04:09:04 --> Model Class Initialized
DEBUG - 2023-12-15 04:09:04 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-12-15 04:09:04 --> Session class already loaded. Second attempt ignored.
INFO - 2023-12-15 04:09:04 --> Model Class Initialized
DEBUG - 2023-12-15 04:09:04 --> Session class already loaded. Second attempt ignored.
INFO - 2023-12-15 04:09:04 --> Model Class Initialized
INFO - 2023-12-15 04:09:04 --> Final output sent to browser
DEBUG - 2023-12-15 04:09:04 --> Total execution time: 0.0352
ERROR - 2023-12-15 04:09:19 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-12-15 04:09:19 --> Config Class Initialized
INFO - 2023-12-15 04:09:19 --> Hooks Class Initialized
DEBUG - 2023-12-15 04:09:19 --> UTF-8 Support Enabled
INFO - 2023-12-15 04:09:19 --> Utf8 Class Initialized
INFO - 2023-12-15 04:09:19 --> URI Class Initialized
INFO - 2023-12-15 04:09:19 --> Router Class Initialized
INFO - 2023-12-15 04:09:19 --> Output Class Initialized
INFO - 2023-12-15 04:09:19 --> Security Class Initialized
DEBUG - 2023-12-15 04:09:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-15 04:09:19 --> Input Class Initialized
INFO - 2023-12-15 04:09:19 --> Language Class Initialized
INFO - 2023-12-15 04:09:19 --> Loader Class Initialized
INFO - 2023-12-15 04:09:19 --> Helper loaded: url_helper
INFO - 2023-12-15 04:09:19 --> Helper loaded: file_helper
INFO - 2023-12-15 04:09:19 --> Helper loaded: html_helper
INFO - 2023-12-15 04:09:19 --> Helper loaded: text_helper
INFO - 2023-12-15 04:09:19 --> Helper loaded: form_helper
INFO - 2023-12-15 04:09:19 --> Helper loaded: lang_helper
INFO - 2023-12-15 04:09:19 --> Helper loaded: security_helper
INFO - 2023-12-15 04:09:19 --> Helper loaded: cookie_helper
INFO - 2023-12-15 04:09:19 --> Database Driver Class Initialized
INFO - 2023-12-15 04:09:19 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-15 04:09:19 --> Parser Class Initialized
INFO - 2023-12-15 04:09:19 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-12-15 04:09:19 --> Pagination Class Initialized
INFO - 2023-12-15 04:09:19 --> Form Validation Class Initialized
INFO - 2023-12-15 04:09:19 --> Controller Class Initialized
INFO - 2023-12-15 04:09:19 --> Model Class Initialized
DEBUG - 2023-12-15 04:09:19 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-12-15 04:09:19 --> Session class already loaded. Second attempt ignored.
INFO - 2023-12-15 04:09:19 --> Model Class Initialized
DEBUG - 2023-12-15 04:09:19 --> Session class already loaded. Second attempt ignored.
INFO - 2023-12-15 04:09:19 --> Model Class Initialized
DEBUG - 2023-12-15 04:09:19 --> Session class already loaded. Second attempt ignored.
INFO - 2023-12-15 04:09:19 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice_html.php
DEBUG - 2023-12-15 04:09:19 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-12-15 04:09:19 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-12-15 04:09:19 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-12-15 04:09:19 --> Model Class Initialized
INFO - 2023-12-15 04:09:19 --> Model Class Initialized
INFO - 2023-12-15 04:09:19 --> Model Class Initialized
INFO - 2023-12-15 04:09:20 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-12-15 04:09:20 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-12-15 04:09:20 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-12-15 04:09:20 --> Final output sent to browser
DEBUG - 2023-12-15 04:09:20 --> Total execution time: 0.2236
ERROR - 2023-12-15 05:58:10 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-12-15 05:58:10 --> Config Class Initialized
INFO - 2023-12-15 05:58:10 --> Hooks Class Initialized
DEBUG - 2023-12-15 05:58:10 --> UTF-8 Support Enabled
INFO - 2023-12-15 05:58:10 --> Utf8 Class Initialized
INFO - 2023-12-15 05:58:10 --> URI Class Initialized
DEBUG - 2023-12-15 05:58:10 --> No URI present. Default controller set.
INFO - 2023-12-15 05:58:10 --> Router Class Initialized
INFO - 2023-12-15 05:58:10 --> Output Class Initialized
INFO - 2023-12-15 05:58:10 --> Security Class Initialized
DEBUG - 2023-12-15 05:58:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-15 05:58:10 --> Input Class Initialized
INFO - 2023-12-15 05:58:10 --> Language Class Initialized
INFO - 2023-12-15 05:58:10 --> Loader Class Initialized
INFO - 2023-12-15 05:58:10 --> Helper loaded: url_helper
INFO - 2023-12-15 05:58:10 --> Helper loaded: file_helper
INFO - 2023-12-15 05:58:10 --> Helper loaded: html_helper
INFO - 2023-12-15 05:58:10 --> Helper loaded: text_helper
INFO - 2023-12-15 05:58:10 --> Helper loaded: form_helper
INFO - 2023-12-15 05:58:10 --> Helper loaded: lang_helper
INFO - 2023-12-15 05:58:10 --> Helper loaded: security_helper
INFO - 2023-12-15 05:58:10 --> Helper loaded: cookie_helper
INFO - 2023-12-15 05:58:10 --> Database Driver Class Initialized
INFO - 2023-12-15 05:58:10 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-15 05:58:10 --> Parser Class Initialized
INFO - 2023-12-15 05:58:10 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-12-15 05:58:10 --> Pagination Class Initialized
INFO - 2023-12-15 05:58:10 --> Form Validation Class Initialized
INFO - 2023-12-15 05:58:10 --> Controller Class Initialized
INFO - 2023-12-15 05:58:10 --> Model Class Initialized
DEBUG - 2023-12-15 05:58:10 --> Session class already loaded. Second attempt ignored.
INFO - 2023-12-15 05:58:10 --> Model Class Initialized
DEBUG - 2023-12-15 05:58:10 --> Session class already loaded. Second attempt ignored.
INFO - 2023-12-15 05:58:10 --> Model Class Initialized
INFO - 2023-12-15 05:58:10 --> Model Class Initialized
INFO - 2023-12-15 05:58:10 --> Model Class Initialized
INFO - 2023-12-15 05:58:10 --> Model Class Initialized
DEBUG - 2023-12-15 05:58:10 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-12-15 05:58:10 --> Session class already loaded. Second attempt ignored.
INFO - 2023-12-15 05:58:10 --> Model Class Initialized
INFO - 2023-12-15 05:58:10 --> Model Class Initialized
INFO - 2023-12-15 05:58:10 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-12-15 05:58:10 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-12-15 05:58:10 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-12-15 05:58:10 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-12-15 05:58:10 --> Model Class Initialized
INFO - 2023-12-15 05:58:10 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-12-15 05:58:10 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-12-15 05:58:10 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-12-15 05:58:10 --> Final output sent to browser
DEBUG - 2023-12-15 05:58:10 --> Total execution time: 0.4194
ERROR - 2023-12-15 05:58:20 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-12-15 05:58:20 --> Config Class Initialized
INFO - 2023-12-15 05:58:20 --> Hooks Class Initialized
DEBUG - 2023-12-15 05:58:20 --> UTF-8 Support Enabled
INFO - 2023-12-15 05:58:20 --> Utf8 Class Initialized
INFO - 2023-12-15 05:58:20 --> URI Class Initialized
DEBUG - 2023-12-15 05:58:20 --> No URI present. Default controller set.
INFO - 2023-12-15 05:58:20 --> Router Class Initialized
INFO - 2023-12-15 05:58:20 --> Output Class Initialized
INFO - 2023-12-15 05:58:20 --> Security Class Initialized
DEBUG - 2023-12-15 05:58:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-15 05:58:20 --> Input Class Initialized
INFO - 2023-12-15 05:58:20 --> Language Class Initialized
INFO - 2023-12-15 05:58:20 --> Loader Class Initialized
INFO - 2023-12-15 05:58:20 --> Helper loaded: url_helper
INFO - 2023-12-15 05:58:20 --> Helper loaded: file_helper
INFO - 2023-12-15 05:58:20 --> Helper loaded: html_helper
INFO - 2023-12-15 05:58:20 --> Helper loaded: text_helper
INFO - 2023-12-15 05:58:20 --> Helper loaded: form_helper
INFO - 2023-12-15 05:58:20 --> Helper loaded: lang_helper
INFO - 2023-12-15 05:58:20 --> Helper loaded: security_helper
INFO - 2023-12-15 05:58:20 --> Helper loaded: cookie_helper
INFO - 2023-12-15 05:58:20 --> Database Driver Class Initialized
INFO - 2023-12-15 05:58:20 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-15 05:58:20 --> Parser Class Initialized
INFO - 2023-12-15 05:58:20 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-12-15 05:58:20 --> Pagination Class Initialized
INFO - 2023-12-15 05:58:20 --> Form Validation Class Initialized
INFO - 2023-12-15 05:58:20 --> Controller Class Initialized
INFO - 2023-12-15 05:58:20 --> Model Class Initialized
DEBUG - 2023-12-15 05:58:20 --> Session class already loaded. Second attempt ignored.
INFO - 2023-12-15 05:58:20 --> Model Class Initialized
DEBUG - 2023-12-15 05:58:20 --> Session class already loaded. Second attempt ignored.
INFO - 2023-12-15 05:58:20 --> Model Class Initialized
INFO - 2023-12-15 05:58:20 --> Model Class Initialized
INFO - 2023-12-15 05:58:20 --> Model Class Initialized
INFO - 2023-12-15 05:58:20 --> Model Class Initialized
DEBUG - 2023-12-15 05:58:20 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-12-15 05:58:20 --> Session class already loaded. Second attempt ignored.
INFO - 2023-12-15 05:58:20 --> Model Class Initialized
INFO - 2023-12-15 05:58:20 --> Model Class Initialized
INFO - 2023-12-15 05:58:20 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-12-15 05:58:20 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-12-15 05:58:20 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-12-15 05:58:20 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-12-15 05:58:20 --> Model Class Initialized
INFO - 2023-12-15 05:58:20 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-12-15 05:58:20 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-12-15 05:58:20 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-12-15 05:58:20 --> Final output sent to browser
DEBUG - 2023-12-15 05:58:20 --> Total execution time: 0.3845
ERROR - 2023-12-15 05:58:25 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-12-15 05:58:25 --> Config Class Initialized
INFO - 2023-12-15 05:58:25 --> Hooks Class Initialized
DEBUG - 2023-12-15 05:58:25 --> UTF-8 Support Enabled
INFO - 2023-12-15 05:58:25 --> Utf8 Class Initialized
INFO - 2023-12-15 05:58:25 --> URI Class Initialized
INFO - 2023-12-15 05:58:25 --> Router Class Initialized
INFO - 2023-12-15 05:58:25 --> Output Class Initialized
INFO - 2023-12-15 05:58:25 --> Security Class Initialized
DEBUG - 2023-12-15 05:58:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-15 05:58:25 --> Input Class Initialized
INFO - 2023-12-15 05:58:25 --> Language Class Initialized
INFO - 2023-12-15 05:58:25 --> Loader Class Initialized
INFO - 2023-12-15 05:58:25 --> Helper loaded: url_helper
INFO - 2023-12-15 05:58:25 --> Helper loaded: file_helper
INFO - 2023-12-15 05:58:25 --> Helper loaded: html_helper
INFO - 2023-12-15 05:58:25 --> Helper loaded: text_helper
INFO - 2023-12-15 05:58:25 --> Helper loaded: form_helper
INFO - 2023-12-15 05:58:25 --> Helper loaded: lang_helper
INFO - 2023-12-15 05:58:25 --> Helper loaded: security_helper
INFO - 2023-12-15 05:58:25 --> Helper loaded: cookie_helper
INFO - 2023-12-15 05:58:25 --> Database Driver Class Initialized
INFO - 2023-12-15 05:58:25 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-15 05:58:25 --> Parser Class Initialized
INFO - 2023-12-15 05:58:25 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-12-15 05:58:25 --> Pagination Class Initialized
INFO - 2023-12-15 05:58:25 --> Form Validation Class Initialized
INFO - 2023-12-15 05:58:25 --> Controller Class Initialized
INFO - 2023-12-15 05:58:25 --> Model Class Initialized
DEBUG - 2023-12-15 05:58:25 --> Session class already loaded. Second attempt ignored.
INFO - 2023-12-15 05:58:25 --> Final output sent to browser
DEBUG - 2023-12-15 05:58:25 --> Total execution time: 0.0133
ERROR - 2023-12-15 05:58:25 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-12-15 05:58:25 --> Config Class Initialized
INFO - 2023-12-15 05:58:25 --> Hooks Class Initialized
DEBUG - 2023-12-15 05:58:25 --> UTF-8 Support Enabled
INFO - 2023-12-15 05:58:25 --> Utf8 Class Initialized
INFO - 2023-12-15 05:58:25 --> URI Class Initialized
INFO - 2023-12-15 05:58:25 --> Router Class Initialized
INFO - 2023-12-15 05:58:25 --> Output Class Initialized
INFO - 2023-12-15 05:58:25 --> Security Class Initialized
DEBUG - 2023-12-15 05:58:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-15 05:58:25 --> Input Class Initialized
INFO - 2023-12-15 05:58:25 --> Language Class Initialized
INFO - 2023-12-15 05:58:25 --> Loader Class Initialized
INFO - 2023-12-15 05:58:25 --> Helper loaded: url_helper
INFO - 2023-12-15 05:58:25 --> Helper loaded: file_helper
INFO - 2023-12-15 05:58:25 --> Helper loaded: html_helper
INFO - 2023-12-15 05:58:25 --> Helper loaded: text_helper
INFO - 2023-12-15 05:58:25 --> Helper loaded: form_helper
INFO - 2023-12-15 05:58:25 --> Helper loaded: lang_helper
INFO - 2023-12-15 05:58:25 --> Helper loaded: security_helper
INFO - 2023-12-15 05:58:25 --> Helper loaded: cookie_helper
INFO - 2023-12-15 05:58:25 --> Database Driver Class Initialized
INFO - 2023-12-15 05:58:25 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-15 05:58:25 --> Parser Class Initialized
INFO - 2023-12-15 05:58:25 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-12-15 05:58:25 --> Pagination Class Initialized
INFO - 2023-12-15 05:58:25 --> Form Validation Class Initialized
INFO - 2023-12-15 05:58:25 --> Controller Class Initialized
INFO - 2023-12-15 05:58:25 --> Model Class Initialized
DEBUG - 2023-12-15 05:58:25 --> Session class already loaded. Second attempt ignored.
INFO - 2023-12-15 05:58:25 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2023-12-15 05:58:25 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-12-15 05:58:25 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-12-15 05:58:25 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-12-15 05:58:25 --> Model Class Initialized
INFO - 2023-12-15 05:58:25 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-12-15 05:58:25 --> Final output sent to browser
DEBUG - 2023-12-15 05:58:25 --> Total execution time: 0.0300
ERROR - 2023-12-15 05:58:31 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-12-15 05:58:31 --> Config Class Initialized
INFO - 2023-12-15 05:58:31 --> Hooks Class Initialized
DEBUG - 2023-12-15 05:58:31 --> UTF-8 Support Enabled
INFO - 2023-12-15 05:58:31 --> Utf8 Class Initialized
INFO - 2023-12-15 05:58:31 --> URI Class Initialized
INFO - 2023-12-15 05:58:31 --> Router Class Initialized
INFO - 2023-12-15 05:58:31 --> Output Class Initialized
INFO - 2023-12-15 05:58:31 --> Security Class Initialized
DEBUG - 2023-12-15 05:58:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-15 05:58:31 --> Input Class Initialized
INFO - 2023-12-15 05:58:31 --> Language Class Initialized
INFO - 2023-12-15 05:58:31 --> Loader Class Initialized
INFO - 2023-12-15 05:58:31 --> Helper loaded: url_helper
INFO - 2023-12-15 05:58:31 --> Helper loaded: file_helper
INFO - 2023-12-15 05:58:31 --> Helper loaded: html_helper
INFO - 2023-12-15 05:58:31 --> Helper loaded: text_helper
INFO - 2023-12-15 05:58:31 --> Helper loaded: form_helper
INFO - 2023-12-15 05:58:31 --> Helper loaded: lang_helper
INFO - 2023-12-15 05:58:31 --> Helper loaded: security_helper
INFO - 2023-12-15 05:58:31 --> Helper loaded: cookie_helper
INFO - 2023-12-15 05:58:31 --> Database Driver Class Initialized
INFO - 2023-12-15 05:58:31 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-15 05:58:31 --> Parser Class Initialized
INFO - 2023-12-15 05:58:31 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-12-15 05:58:31 --> Pagination Class Initialized
INFO - 2023-12-15 05:58:31 --> Form Validation Class Initialized
INFO - 2023-12-15 05:58:31 --> Controller Class Initialized
INFO - 2023-12-15 05:58:31 --> Model Class Initialized
DEBUG - 2023-12-15 05:58:31 --> Session class already loaded. Second attempt ignored.
INFO - 2023-12-15 05:58:31 --> Model Class Initialized
INFO - 2023-12-15 05:58:31 --> Final output sent to browser
DEBUG - 2023-12-15 05:58:31 --> Total execution time: 0.0182
ERROR - 2023-12-15 05:58:31 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-12-15 05:58:31 --> Config Class Initialized
INFO - 2023-12-15 05:58:31 --> Hooks Class Initialized
DEBUG - 2023-12-15 05:58:31 --> UTF-8 Support Enabled
INFO - 2023-12-15 05:58:31 --> Utf8 Class Initialized
INFO - 2023-12-15 05:58:31 --> URI Class Initialized
DEBUG - 2023-12-15 05:58:31 --> No URI present. Default controller set.
INFO - 2023-12-15 05:58:31 --> Router Class Initialized
INFO - 2023-12-15 05:58:31 --> Output Class Initialized
INFO - 2023-12-15 05:58:31 --> Security Class Initialized
DEBUG - 2023-12-15 05:58:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-15 05:58:31 --> Input Class Initialized
INFO - 2023-12-15 05:58:31 --> Language Class Initialized
INFO - 2023-12-15 05:58:31 --> Loader Class Initialized
INFO - 2023-12-15 05:58:31 --> Helper loaded: url_helper
INFO - 2023-12-15 05:58:31 --> Helper loaded: file_helper
INFO - 2023-12-15 05:58:31 --> Helper loaded: html_helper
INFO - 2023-12-15 05:58:31 --> Helper loaded: text_helper
INFO - 2023-12-15 05:58:31 --> Helper loaded: form_helper
INFO - 2023-12-15 05:58:31 --> Helper loaded: lang_helper
INFO - 2023-12-15 05:58:31 --> Helper loaded: security_helper
INFO - 2023-12-15 05:58:31 --> Helper loaded: cookie_helper
INFO - 2023-12-15 05:58:31 --> Database Driver Class Initialized
INFO - 2023-12-15 05:58:31 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-15 05:58:31 --> Parser Class Initialized
INFO - 2023-12-15 05:58:31 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-12-15 05:58:31 --> Pagination Class Initialized
INFO - 2023-12-15 05:58:31 --> Form Validation Class Initialized
INFO - 2023-12-15 05:58:31 --> Controller Class Initialized
INFO - 2023-12-15 05:58:31 --> Model Class Initialized
DEBUG - 2023-12-15 05:58:31 --> Session class already loaded. Second attempt ignored.
INFO - 2023-12-15 05:58:31 --> Model Class Initialized
DEBUG - 2023-12-15 05:58:31 --> Session class already loaded. Second attempt ignored.
INFO - 2023-12-15 05:58:31 --> Model Class Initialized
INFO - 2023-12-15 05:58:31 --> Model Class Initialized
INFO - 2023-12-15 05:58:31 --> Model Class Initialized
INFO - 2023-12-15 05:58:31 --> Model Class Initialized
DEBUG - 2023-12-15 05:58:31 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-12-15 05:58:31 --> Session class already loaded. Second attempt ignored.
INFO - 2023-12-15 05:58:31 --> Model Class Initialized
INFO - 2023-12-15 05:58:31 --> Model Class Initialized
INFO - 2023-12-15 05:58:31 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-12-15 05:58:31 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-12-15 05:58:31 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-12-15 05:58:31 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-12-15 05:58:31 --> Model Class Initialized
INFO - 2023-12-15 05:58:31 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-12-15 05:58:31 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-12-15 05:58:31 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-12-15 05:58:31 --> Final output sent to browser
DEBUG - 2023-12-15 05:58:31 --> Total execution time: 0.2203
ERROR - 2023-12-15 05:58:35 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-12-15 05:58:35 --> Config Class Initialized
INFO - 2023-12-15 05:58:35 --> Hooks Class Initialized
DEBUG - 2023-12-15 05:58:35 --> UTF-8 Support Enabled
INFO - 2023-12-15 05:58:35 --> Utf8 Class Initialized
INFO - 2023-12-15 05:58:35 --> URI Class Initialized
INFO - 2023-12-15 05:58:35 --> Router Class Initialized
INFO - 2023-12-15 05:58:35 --> Output Class Initialized
INFO - 2023-12-15 05:58:35 --> Security Class Initialized
DEBUG - 2023-12-15 05:58:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-15 05:58:35 --> Input Class Initialized
INFO - 2023-12-15 05:58:35 --> Language Class Initialized
INFO - 2023-12-15 05:58:35 --> Loader Class Initialized
INFO - 2023-12-15 05:58:35 --> Helper loaded: url_helper
INFO - 2023-12-15 05:58:35 --> Helper loaded: file_helper
INFO - 2023-12-15 05:58:35 --> Helper loaded: html_helper
INFO - 2023-12-15 05:58:35 --> Helper loaded: text_helper
INFO - 2023-12-15 05:58:35 --> Helper loaded: form_helper
INFO - 2023-12-15 05:58:35 --> Helper loaded: lang_helper
INFO - 2023-12-15 05:58:35 --> Helper loaded: security_helper
INFO - 2023-12-15 05:58:35 --> Helper loaded: cookie_helper
INFO - 2023-12-15 05:58:35 --> Database Driver Class Initialized
INFO - 2023-12-15 05:58:35 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-15 05:58:35 --> Parser Class Initialized
INFO - 2023-12-15 05:58:35 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-12-15 05:58:35 --> Pagination Class Initialized
INFO - 2023-12-15 05:58:35 --> Form Validation Class Initialized
INFO - 2023-12-15 05:58:35 --> Controller Class Initialized
INFO - 2023-12-15 05:58:35 --> Model Class Initialized
DEBUG - 2023-12-15 05:58:35 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-12-15 05:58:35 --> Session class already loaded. Second attempt ignored.
INFO - 2023-12-15 05:58:35 --> Model Class Initialized
DEBUG - 2023-12-15 05:58:35 --> Session class already loaded. Second attempt ignored.
INFO - 2023-12-15 05:58:35 --> Model Class Initialized
INFO - 2023-12-15 05:58:35 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice.php
DEBUG - 2023-12-15 05:58:35 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-12-15 05:58:35 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-12-15 05:58:35 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-12-15 05:58:35 --> Model Class Initialized
INFO - 2023-12-15 05:58:35 --> Model Class Initialized
INFO - 2023-12-15 05:58:35 --> Model Class Initialized
INFO - 2023-12-15 05:58:35 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-12-15 05:58:35 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-12-15 05:58:35 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-12-15 05:58:35 --> Final output sent to browser
DEBUG - 2023-12-15 05:58:35 --> Total execution time: 0.1519
ERROR - 2023-12-15 05:58:36 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-12-15 05:58:36 --> Config Class Initialized
INFO - 2023-12-15 05:58:36 --> Hooks Class Initialized
DEBUG - 2023-12-15 05:58:36 --> UTF-8 Support Enabled
INFO - 2023-12-15 05:58:36 --> Utf8 Class Initialized
INFO - 2023-12-15 05:58:36 --> URI Class Initialized
INFO - 2023-12-15 05:58:36 --> Router Class Initialized
INFO - 2023-12-15 05:58:36 --> Output Class Initialized
INFO - 2023-12-15 05:58:36 --> Security Class Initialized
DEBUG - 2023-12-15 05:58:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-15 05:58:36 --> Input Class Initialized
INFO - 2023-12-15 05:58:36 --> Language Class Initialized
INFO - 2023-12-15 05:58:36 --> Loader Class Initialized
INFO - 2023-12-15 05:58:36 --> Helper loaded: url_helper
INFO - 2023-12-15 05:58:36 --> Helper loaded: file_helper
INFO - 2023-12-15 05:58:36 --> Helper loaded: html_helper
INFO - 2023-12-15 05:58:36 --> Helper loaded: text_helper
INFO - 2023-12-15 05:58:36 --> Helper loaded: form_helper
INFO - 2023-12-15 05:58:36 --> Helper loaded: lang_helper
INFO - 2023-12-15 05:58:36 --> Helper loaded: security_helper
INFO - 2023-12-15 05:58:36 --> Helper loaded: cookie_helper
INFO - 2023-12-15 05:58:36 --> Database Driver Class Initialized
INFO - 2023-12-15 05:58:36 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-15 05:58:36 --> Parser Class Initialized
INFO - 2023-12-15 05:58:36 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-12-15 05:58:36 --> Pagination Class Initialized
INFO - 2023-12-15 05:58:36 --> Form Validation Class Initialized
INFO - 2023-12-15 05:58:36 --> Controller Class Initialized
INFO - 2023-12-15 05:58:36 --> Model Class Initialized
DEBUG - 2023-12-15 05:58:36 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-12-15 05:58:36 --> Session class already loaded. Second attempt ignored.
INFO - 2023-12-15 05:58:36 --> Model Class Initialized
DEBUG - 2023-12-15 05:58:36 --> Session class already loaded. Second attempt ignored.
INFO - 2023-12-15 05:58:36 --> Model Class Initialized
INFO - 2023-12-15 05:58:36 --> Final output sent to browser
DEBUG - 2023-12-15 05:58:36 --> Total execution time: 0.0433
ERROR - 2023-12-15 05:58:40 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-12-15 05:58:40 --> Config Class Initialized
INFO - 2023-12-15 05:58:40 --> Hooks Class Initialized
DEBUG - 2023-12-15 05:58:40 --> UTF-8 Support Enabled
INFO - 2023-12-15 05:58:40 --> Utf8 Class Initialized
INFO - 2023-12-15 05:58:40 --> URI Class Initialized
INFO - 2023-12-15 05:58:40 --> Router Class Initialized
INFO - 2023-12-15 05:58:40 --> Output Class Initialized
INFO - 2023-12-15 05:58:40 --> Security Class Initialized
DEBUG - 2023-12-15 05:58:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-15 05:58:40 --> Input Class Initialized
INFO - 2023-12-15 05:58:40 --> Language Class Initialized
INFO - 2023-12-15 05:58:40 --> Loader Class Initialized
INFO - 2023-12-15 05:58:40 --> Helper loaded: url_helper
INFO - 2023-12-15 05:58:40 --> Helper loaded: file_helper
INFO - 2023-12-15 05:58:40 --> Helper loaded: html_helper
INFO - 2023-12-15 05:58:40 --> Helper loaded: text_helper
INFO - 2023-12-15 05:58:40 --> Helper loaded: form_helper
INFO - 2023-12-15 05:58:40 --> Helper loaded: lang_helper
INFO - 2023-12-15 05:58:40 --> Helper loaded: security_helper
INFO - 2023-12-15 05:58:40 --> Helper loaded: cookie_helper
INFO - 2023-12-15 05:58:40 --> Database Driver Class Initialized
INFO - 2023-12-15 05:58:40 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-15 05:58:40 --> Parser Class Initialized
INFO - 2023-12-15 05:58:40 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-12-15 05:58:40 --> Pagination Class Initialized
INFO - 2023-12-15 05:58:40 --> Form Validation Class Initialized
INFO - 2023-12-15 05:58:40 --> Controller Class Initialized
INFO - 2023-12-15 05:58:40 --> Model Class Initialized
DEBUG - 2023-12-15 05:58:40 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-12-15 05:58:40 --> Session class already loaded. Second attempt ignored.
INFO - 2023-12-15 05:58:40 --> Model Class Initialized
DEBUG - 2023-12-15 05:58:40 --> Session class already loaded. Second attempt ignored.
INFO - 2023-12-15 05:58:40 --> Model Class Initialized
INFO - 2023-12-15 05:58:40 --> Final output sent to browser
DEBUG - 2023-12-15 05:58:40 --> Total execution time: 0.0713
ERROR - 2023-12-15 06:17:10 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-12-15 06:17:10 --> Config Class Initialized
INFO - 2023-12-15 06:17:10 --> Hooks Class Initialized
DEBUG - 2023-12-15 06:17:10 --> UTF-8 Support Enabled
INFO - 2023-12-15 06:17:10 --> Utf8 Class Initialized
INFO - 2023-12-15 06:17:10 --> URI Class Initialized
INFO - 2023-12-15 06:17:10 --> Router Class Initialized
INFO - 2023-12-15 06:17:10 --> Output Class Initialized
INFO - 2023-12-15 06:17:10 --> Security Class Initialized
DEBUG - 2023-12-15 06:17:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-15 06:17:10 --> Input Class Initialized
INFO - 2023-12-15 06:17:10 --> Language Class Initialized
ERROR - 2023-12-15 06:17:10 --> 404 Page Not Found: Well-known/assetlinks.json
ERROR - 2023-12-15 09:49:08 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-12-15 09:49:08 --> Config Class Initialized
INFO - 2023-12-15 09:49:08 --> Hooks Class Initialized
DEBUG - 2023-12-15 09:49:08 --> UTF-8 Support Enabled
INFO - 2023-12-15 09:49:08 --> Utf8 Class Initialized
INFO - 2023-12-15 09:49:08 --> URI Class Initialized
DEBUG - 2023-12-15 09:49:08 --> No URI present. Default controller set.
INFO - 2023-12-15 09:49:08 --> Router Class Initialized
INFO - 2023-12-15 09:49:08 --> Output Class Initialized
INFO - 2023-12-15 09:49:08 --> Security Class Initialized
DEBUG - 2023-12-15 09:49:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-15 09:49:08 --> Input Class Initialized
INFO - 2023-12-15 09:49:08 --> Language Class Initialized
INFO - 2023-12-15 09:49:08 --> Loader Class Initialized
INFO - 2023-12-15 09:49:08 --> Helper loaded: url_helper
INFO - 2023-12-15 09:49:08 --> Helper loaded: file_helper
INFO - 2023-12-15 09:49:08 --> Helper loaded: html_helper
INFO - 2023-12-15 09:49:08 --> Helper loaded: text_helper
INFO - 2023-12-15 09:49:08 --> Helper loaded: form_helper
INFO - 2023-12-15 09:49:08 --> Helper loaded: lang_helper
INFO - 2023-12-15 09:49:08 --> Helper loaded: security_helper
INFO - 2023-12-15 09:49:08 --> Helper loaded: cookie_helper
INFO - 2023-12-15 09:49:08 --> Database Driver Class Initialized
INFO - 2023-12-15 09:49:08 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-15 09:49:08 --> Parser Class Initialized
INFO - 2023-12-15 09:49:08 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-12-15 09:49:08 --> Pagination Class Initialized
INFO - 2023-12-15 09:49:08 --> Form Validation Class Initialized
INFO - 2023-12-15 09:49:08 --> Controller Class Initialized
INFO - 2023-12-15 09:49:08 --> Model Class Initialized
DEBUG - 2023-12-15 09:49:08 --> Session class already loaded. Second attempt ignored.
ERROR - 2023-12-15 09:49:09 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-12-15 09:49:09 --> Config Class Initialized
INFO - 2023-12-15 09:49:09 --> Hooks Class Initialized
DEBUG - 2023-12-15 09:49:09 --> UTF-8 Support Enabled
INFO - 2023-12-15 09:49:09 --> Utf8 Class Initialized
INFO - 2023-12-15 09:49:09 --> URI Class Initialized
INFO - 2023-12-15 09:49:09 --> Router Class Initialized
INFO - 2023-12-15 09:49:09 --> Output Class Initialized
INFO - 2023-12-15 09:49:09 --> Security Class Initialized
DEBUG - 2023-12-15 09:49:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-15 09:49:09 --> Input Class Initialized
INFO - 2023-12-15 09:49:09 --> Language Class Initialized
INFO - 2023-12-15 09:49:09 --> Loader Class Initialized
INFO - 2023-12-15 09:49:09 --> Helper loaded: url_helper
INFO - 2023-12-15 09:49:09 --> Helper loaded: file_helper
INFO - 2023-12-15 09:49:09 --> Helper loaded: html_helper
INFO - 2023-12-15 09:49:09 --> Helper loaded: text_helper
INFO - 2023-12-15 09:49:09 --> Helper loaded: form_helper
INFO - 2023-12-15 09:49:09 --> Helper loaded: lang_helper
INFO - 2023-12-15 09:49:09 --> Helper loaded: security_helper
INFO - 2023-12-15 09:49:09 --> Helper loaded: cookie_helper
INFO - 2023-12-15 09:49:09 --> Database Driver Class Initialized
INFO - 2023-12-15 09:49:09 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-15 09:49:09 --> Parser Class Initialized
INFO - 2023-12-15 09:49:09 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-12-15 09:49:09 --> Pagination Class Initialized
INFO - 2023-12-15 09:49:09 --> Form Validation Class Initialized
INFO - 2023-12-15 09:49:09 --> Controller Class Initialized
INFO - 2023-12-15 09:49:09 --> Model Class Initialized
DEBUG - 2023-12-15 09:49:09 --> Session class already loaded. Second attempt ignored.
INFO - 2023-12-15 09:49:09 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2023-12-15 09:49:09 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-12-15 09:49:09 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-12-15 09:49:09 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-12-15 09:49:09 --> Model Class Initialized
INFO - 2023-12-15 09:49:09 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-12-15 09:49:09 --> Final output sent to browser
DEBUG - 2023-12-15 09:49:09 --> Total execution time: 0.0371
ERROR - 2023-12-15 09:51:12 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-12-15 09:51:12 --> Config Class Initialized
INFO - 2023-12-15 09:51:12 --> Hooks Class Initialized
DEBUG - 2023-12-15 09:51:12 --> UTF-8 Support Enabled
INFO - 2023-12-15 09:51:12 --> Utf8 Class Initialized
INFO - 2023-12-15 09:51:12 --> URI Class Initialized
INFO - 2023-12-15 09:51:12 --> Router Class Initialized
INFO - 2023-12-15 09:51:12 --> Output Class Initialized
INFO - 2023-12-15 09:51:12 --> Security Class Initialized
DEBUG - 2023-12-15 09:51:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-15 09:51:12 --> Input Class Initialized
INFO - 2023-12-15 09:51:12 --> Language Class Initialized
INFO - 2023-12-15 09:51:12 --> Loader Class Initialized
INFO - 2023-12-15 09:51:12 --> Helper loaded: url_helper
INFO - 2023-12-15 09:51:12 --> Helper loaded: file_helper
INFO - 2023-12-15 09:51:12 --> Helper loaded: html_helper
INFO - 2023-12-15 09:51:12 --> Helper loaded: text_helper
INFO - 2023-12-15 09:51:12 --> Helper loaded: form_helper
INFO - 2023-12-15 09:51:12 --> Helper loaded: lang_helper
INFO - 2023-12-15 09:51:12 --> Helper loaded: security_helper
INFO - 2023-12-15 09:51:12 --> Helper loaded: cookie_helper
INFO - 2023-12-15 09:51:12 --> Database Driver Class Initialized
INFO - 2023-12-15 09:51:12 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-15 09:51:12 --> Parser Class Initialized
INFO - 2023-12-15 09:51:12 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-12-15 09:51:12 --> Pagination Class Initialized
INFO - 2023-12-15 09:51:12 --> Form Validation Class Initialized
INFO - 2023-12-15 09:51:12 --> Controller Class Initialized
INFO - 2023-12-15 09:51:12 --> Model Class Initialized
DEBUG - 2023-12-15 09:51:12 --> Session class already loaded. Second attempt ignored.
INFO - 2023-12-15 09:51:12 --> Model Class Initialized
INFO - 2023-12-15 09:51:12 --> Final output sent to browser
DEBUG - 2023-12-15 09:51:12 --> Total execution time: 0.0219
ERROR - 2023-12-15 09:51:12 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-12-15 09:51:12 --> Config Class Initialized
INFO - 2023-12-15 09:51:12 --> Hooks Class Initialized
DEBUG - 2023-12-15 09:51:12 --> UTF-8 Support Enabled
INFO - 2023-12-15 09:51:12 --> Utf8 Class Initialized
INFO - 2023-12-15 09:51:12 --> URI Class Initialized
DEBUG - 2023-12-15 09:51:12 --> No URI present. Default controller set.
INFO - 2023-12-15 09:51:12 --> Router Class Initialized
INFO - 2023-12-15 09:51:12 --> Output Class Initialized
INFO - 2023-12-15 09:51:12 --> Security Class Initialized
DEBUG - 2023-12-15 09:51:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-15 09:51:12 --> Input Class Initialized
INFO - 2023-12-15 09:51:12 --> Language Class Initialized
INFO - 2023-12-15 09:51:12 --> Loader Class Initialized
INFO - 2023-12-15 09:51:12 --> Helper loaded: url_helper
INFO - 2023-12-15 09:51:12 --> Helper loaded: file_helper
INFO - 2023-12-15 09:51:12 --> Helper loaded: html_helper
INFO - 2023-12-15 09:51:12 --> Helper loaded: text_helper
INFO - 2023-12-15 09:51:12 --> Helper loaded: form_helper
INFO - 2023-12-15 09:51:12 --> Helper loaded: lang_helper
INFO - 2023-12-15 09:51:12 --> Helper loaded: security_helper
INFO - 2023-12-15 09:51:12 --> Helper loaded: cookie_helper
INFO - 2023-12-15 09:51:12 --> Database Driver Class Initialized
INFO - 2023-12-15 09:51:12 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-15 09:51:12 --> Parser Class Initialized
INFO - 2023-12-15 09:51:12 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-12-15 09:51:12 --> Pagination Class Initialized
INFO - 2023-12-15 09:51:12 --> Form Validation Class Initialized
INFO - 2023-12-15 09:51:12 --> Controller Class Initialized
INFO - 2023-12-15 09:51:12 --> Model Class Initialized
DEBUG - 2023-12-15 09:51:12 --> Session class already loaded. Second attempt ignored.
INFO - 2023-12-15 09:51:12 --> Model Class Initialized
DEBUG - 2023-12-15 09:51:12 --> Session class already loaded. Second attempt ignored.
INFO - 2023-12-15 09:51:12 --> Model Class Initialized
INFO - 2023-12-15 09:51:12 --> Model Class Initialized
INFO - 2023-12-15 09:51:12 --> Model Class Initialized
INFO - 2023-12-15 09:51:12 --> Model Class Initialized
DEBUG - 2023-12-15 09:51:12 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-12-15 09:51:12 --> Session class already loaded. Second attempt ignored.
INFO - 2023-12-15 09:51:12 --> Model Class Initialized
INFO - 2023-12-15 09:51:12 --> Model Class Initialized
INFO - 2023-12-15 09:51:12 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-12-15 09:51:12 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-12-15 09:51:12 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-12-15 09:51:12 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-12-15 09:51:12 --> Model Class Initialized
INFO - 2023-12-15 09:51:12 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-12-15 09:51:12 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-12-15 09:51:12 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-12-15 09:51:12 --> Final output sent to browser
DEBUG - 2023-12-15 09:51:12 --> Total execution time: 0.2253
ERROR - 2023-12-15 09:51:20 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-12-15 09:51:20 --> Config Class Initialized
INFO - 2023-12-15 09:51:20 --> Hooks Class Initialized
DEBUG - 2023-12-15 09:51:20 --> UTF-8 Support Enabled
INFO - 2023-12-15 09:51:20 --> Utf8 Class Initialized
INFO - 2023-12-15 09:51:20 --> URI Class Initialized
INFO - 2023-12-15 09:51:20 --> Router Class Initialized
INFO - 2023-12-15 09:51:20 --> Output Class Initialized
INFO - 2023-12-15 09:51:20 --> Security Class Initialized
DEBUG - 2023-12-15 09:51:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-15 09:51:20 --> Input Class Initialized
INFO - 2023-12-15 09:51:20 --> Language Class Initialized
INFO - 2023-12-15 09:51:20 --> Loader Class Initialized
INFO - 2023-12-15 09:51:20 --> Helper loaded: url_helper
INFO - 2023-12-15 09:51:20 --> Helper loaded: file_helper
INFO - 2023-12-15 09:51:20 --> Helper loaded: html_helper
INFO - 2023-12-15 09:51:20 --> Helper loaded: text_helper
INFO - 2023-12-15 09:51:20 --> Helper loaded: form_helper
INFO - 2023-12-15 09:51:20 --> Helper loaded: lang_helper
INFO - 2023-12-15 09:51:20 --> Helper loaded: security_helper
INFO - 2023-12-15 09:51:20 --> Helper loaded: cookie_helper
INFO - 2023-12-15 09:51:20 --> Database Driver Class Initialized
INFO - 2023-12-15 09:51:20 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-15 09:51:20 --> Parser Class Initialized
INFO - 2023-12-15 09:51:20 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-12-15 09:51:20 --> Pagination Class Initialized
INFO - 2023-12-15 09:51:20 --> Form Validation Class Initialized
INFO - 2023-12-15 09:51:20 --> Controller Class Initialized
INFO - 2023-12-15 09:51:20 --> Model Class Initialized
DEBUG - 2023-12-15 09:51:20 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-12-15 09:51:20 --> Session class already loaded. Second attempt ignored.
INFO - 2023-12-15 09:51:20 --> Model Class Initialized
DEBUG - 2023-12-15 09:51:20 --> Session class already loaded. Second attempt ignored.
INFO - 2023-12-15 09:51:20 --> Model Class Initialized
INFO - 2023-12-15 09:51:20 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice.php
DEBUG - 2023-12-15 09:51:20 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-12-15 09:51:20 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-12-15 09:51:20 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-12-15 09:51:20 --> Model Class Initialized
INFO - 2023-12-15 09:51:20 --> Model Class Initialized
INFO - 2023-12-15 09:51:20 --> Model Class Initialized
INFO - 2023-12-15 09:51:20 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-12-15 09:51:20 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-12-15 09:51:20 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-12-15 09:51:20 --> Final output sent to browser
DEBUG - 2023-12-15 09:51:20 --> Total execution time: 0.1480
ERROR - 2023-12-15 09:51:21 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-12-15 09:51:21 --> Config Class Initialized
INFO - 2023-12-15 09:51:21 --> Hooks Class Initialized
DEBUG - 2023-12-15 09:51:21 --> UTF-8 Support Enabled
INFO - 2023-12-15 09:51:21 --> Utf8 Class Initialized
INFO - 2023-12-15 09:51:21 --> URI Class Initialized
INFO - 2023-12-15 09:51:21 --> Router Class Initialized
INFO - 2023-12-15 09:51:21 --> Output Class Initialized
INFO - 2023-12-15 09:51:21 --> Security Class Initialized
DEBUG - 2023-12-15 09:51:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-15 09:51:21 --> Input Class Initialized
INFO - 2023-12-15 09:51:21 --> Language Class Initialized
INFO - 2023-12-15 09:51:21 --> Loader Class Initialized
INFO - 2023-12-15 09:51:21 --> Helper loaded: url_helper
INFO - 2023-12-15 09:51:21 --> Helper loaded: file_helper
INFO - 2023-12-15 09:51:21 --> Helper loaded: html_helper
INFO - 2023-12-15 09:51:21 --> Helper loaded: text_helper
INFO - 2023-12-15 09:51:21 --> Helper loaded: form_helper
INFO - 2023-12-15 09:51:21 --> Helper loaded: lang_helper
INFO - 2023-12-15 09:51:21 --> Helper loaded: security_helper
INFO - 2023-12-15 09:51:21 --> Helper loaded: cookie_helper
INFO - 2023-12-15 09:51:21 --> Database Driver Class Initialized
INFO - 2023-12-15 09:51:21 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-15 09:51:21 --> Parser Class Initialized
INFO - 2023-12-15 09:51:21 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-12-15 09:51:21 --> Pagination Class Initialized
INFO - 2023-12-15 09:51:21 --> Form Validation Class Initialized
INFO - 2023-12-15 09:51:21 --> Controller Class Initialized
INFO - 2023-12-15 09:51:21 --> Model Class Initialized
DEBUG - 2023-12-15 09:51:21 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-12-15 09:51:21 --> Session class already loaded. Second attempt ignored.
INFO - 2023-12-15 09:51:21 --> Model Class Initialized
DEBUG - 2023-12-15 09:51:21 --> Session class already loaded. Second attempt ignored.
INFO - 2023-12-15 09:51:21 --> Model Class Initialized
INFO - 2023-12-15 09:51:21 --> Final output sent to browser
DEBUG - 2023-12-15 09:51:21 --> Total execution time: 0.0397
ERROR - 2023-12-15 09:51:57 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-12-15 09:51:57 --> Config Class Initialized
INFO - 2023-12-15 09:51:57 --> Hooks Class Initialized
DEBUG - 2023-12-15 09:51:57 --> UTF-8 Support Enabled
INFO - 2023-12-15 09:51:57 --> Utf8 Class Initialized
INFO - 2023-12-15 09:51:57 --> URI Class Initialized
INFO - 2023-12-15 09:51:57 --> Router Class Initialized
INFO - 2023-12-15 09:51:57 --> Output Class Initialized
INFO - 2023-12-15 09:51:57 --> Security Class Initialized
DEBUG - 2023-12-15 09:51:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-15 09:51:57 --> Input Class Initialized
INFO - 2023-12-15 09:51:57 --> Language Class Initialized
INFO - 2023-12-15 09:51:57 --> Loader Class Initialized
INFO - 2023-12-15 09:51:57 --> Helper loaded: url_helper
INFO - 2023-12-15 09:51:57 --> Helper loaded: file_helper
INFO - 2023-12-15 09:51:57 --> Helper loaded: html_helper
INFO - 2023-12-15 09:51:57 --> Helper loaded: text_helper
INFO - 2023-12-15 09:51:57 --> Helper loaded: form_helper
INFO - 2023-12-15 09:51:57 --> Helper loaded: lang_helper
INFO - 2023-12-15 09:51:57 --> Helper loaded: security_helper
INFO - 2023-12-15 09:51:57 --> Helper loaded: cookie_helper
INFO - 2023-12-15 09:51:57 --> Database Driver Class Initialized
INFO - 2023-12-15 09:51:57 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-15 09:51:57 --> Parser Class Initialized
INFO - 2023-12-15 09:51:57 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-12-15 09:51:57 --> Pagination Class Initialized
INFO - 2023-12-15 09:51:57 --> Form Validation Class Initialized
INFO - 2023-12-15 09:51:57 --> Controller Class Initialized
INFO - 2023-12-15 09:51:57 --> Model Class Initialized
DEBUG - 2023-12-15 09:51:57 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-12-15 09:51:57 --> Session class already loaded. Second attempt ignored.
INFO - 2023-12-15 09:51:57 --> Model Class Initialized
DEBUG - 2023-12-15 09:51:57 --> Session class already loaded. Second attempt ignored.
INFO - 2023-12-15 09:51:57 --> Model Class Initialized
INFO - 2023-12-15 09:51:57 --> Final output sent to browser
DEBUG - 2023-12-15 09:51:57 --> Total execution time: 0.0382
ERROR - 2023-12-15 09:52:18 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-12-15 09:52:18 --> Config Class Initialized
INFO - 2023-12-15 09:52:18 --> Hooks Class Initialized
DEBUG - 2023-12-15 09:52:18 --> UTF-8 Support Enabled
INFO - 2023-12-15 09:52:18 --> Utf8 Class Initialized
INFO - 2023-12-15 09:52:18 --> URI Class Initialized
INFO - 2023-12-15 09:52:18 --> Router Class Initialized
INFO - 2023-12-15 09:52:18 --> Output Class Initialized
INFO - 2023-12-15 09:52:18 --> Security Class Initialized
DEBUG - 2023-12-15 09:52:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-15 09:52:18 --> Input Class Initialized
INFO - 2023-12-15 09:52:18 --> Language Class Initialized
INFO - 2023-12-15 09:52:18 --> Loader Class Initialized
INFO - 2023-12-15 09:52:18 --> Helper loaded: url_helper
INFO - 2023-12-15 09:52:18 --> Helper loaded: file_helper
INFO - 2023-12-15 09:52:18 --> Helper loaded: html_helper
INFO - 2023-12-15 09:52:18 --> Helper loaded: text_helper
INFO - 2023-12-15 09:52:18 --> Helper loaded: form_helper
INFO - 2023-12-15 09:52:18 --> Helper loaded: lang_helper
INFO - 2023-12-15 09:52:18 --> Helper loaded: security_helper
INFO - 2023-12-15 09:52:18 --> Helper loaded: cookie_helper
INFO - 2023-12-15 09:52:18 --> Database Driver Class Initialized
INFO - 2023-12-15 09:52:18 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-15 09:52:18 --> Parser Class Initialized
INFO - 2023-12-15 09:52:18 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-12-15 09:52:18 --> Pagination Class Initialized
INFO - 2023-12-15 09:52:18 --> Form Validation Class Initialized
INFO - 2023-12-15 09:52:18 --> Controller Class Initialized
INFO - 2023-12-15 09:52:18 --> Model Class Initialized
DEBUG - 2023-12-15 09:52:18 --> Session class already loaded. Second attempt ignored.
INFO - 2023-12-15 09:52:18 --> Final output sent to browser
DEBUG - 2023-12-15 09:52:18 --> Total execution time: 0.0140
ERROR - 2023-12-15 09:52:19 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-12-15 09:52:19 --> Config Class Initialized
INFO - 2023-12-15 09:52:19 --> Hooks Class Initialized
DEBUG - 2023-12-15 09:52:19 --> UTF-8 Support Enabled
INFO - 2023-12-15 09:52:19 --> Utf8 Class Initialized
INFO - 2023-12-15 09:52:19 --> URI Class Initialized
INFO - 2023-12-15 09:52:19 --> Router Class Initialized
INFO - 2023-12-15 09:52:19 --> Output Class Initialized
INFO - 2023-12-15 09:52:19 --> Security Class Initialized
DEBUG - 2023-12-15 09:52:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-15 09:52:19 --> Input Class Initialized
INFO - 2023-12-15 09:52:19 --> Language Class Initialized
INFO - 2023-12-15 09:52:19 --> Loader Class Initialized
INFO - 2023-12-15 09:52:19 --> Helper loaded: url_helper
INFO - 2023-12-15 09:52:19 --> Helper loaded: file_helper
INFO - 2023-12-15 09:52:19 --> Helper loaded: html_helper
INFO - 2023-12-15 09:52:19 --> Helper loaded: text_helper
INFO - 2023-12-15 09:52:19 --> Helper loaded: form_helper
INFO - 2023-12-15 09:52:19 --> Helper loaded: lang_helper
INFO - 2023-12-15 09:52:19 --> Helper loaded: security_helper
INFO - 2023-12-15 09:52:19 --> Helper loaded: cookie_helper
INFO - 2023-12-15 09:52:19 --> Database Driver Class Initialized
INFO - 2023-12-15 09:52:19 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-15 09:52:19 --> Parser Class Initialized
INFO - 2023-12-15 09:52:19 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-12-15 09:52:19 --> Pagination Class Initialized
INFO - 2023-12-15 09:52:19 --> Form Validation Class Initialized
INFO - 2023-12-15 09:52:19 --> Controller Class Initialized
INFO - 2023-12-15 09:52:19 --> Model Class Initialized
DEBUG - 2023-12-15 09:52:19 --> Session class already loaded. Second attempt ignored.
INFO - 2023-12-15 09:52:19 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2023-12-15 09:52:19 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-12-15 09:52:19 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-12-15 09:52:19 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-12-15 09:52:19 --> Model Class Initialized
INFO - 2023-12-15 09:52:19 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-12-15 09:52:19 --> Final output sent to browser
DEBUG - 2023-12-15 09:52:19 --> Total execution time: 0.0291
ERROR - 2023-12-15 09:52:25 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-12-15 09:52:25 --> Config Class Initialized
INFO - 2023-12-15 09:52:25 --> Hooks Class Initialized
DEBUG - 2023-12-15 09:52:25 --> UTF-8 Support Enabled
INFO - 2023-12-15 09:52:25 --> Utf8 Class Initialized
INFO - 2023-12-15 09:52:25 --> URI Class Initialized
INFO - 2023-12-15 09:52:25 --> Router Class Initialized
INFO - 2023-12-15 09:52:25 --> Output Class Initialized
INFO - 2023-12-15 09:52:25 --> Security Class Initialized
DEBUG - 2023-12-15 09:52:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-15 09:52:25 --> Input Class Initialized
INFO - 2023-12-15 09:52:25 --> Language Class Initialized
INFO - 2023-12-15 09:52:25 --> Loader Class Initialized
INFO - 2023-12-15 09:52:25 --> Helper loaded: url_helper
INFO - 2023-12-15 09:52:25 --> Helper loaded: file_helper
INFO - 2023-12-15 09:52:25 --> Helper loaded: html_helper
INFO - 2023-12-15 09:52:25 --> Helper loaded: text_helper
INFO - 2023-12-15 09:52:25 --> Helper loaded: form_helper
INFO - 2023-12-15 09:52:25 --> Helper loaded: lang_helper
INFO - 2023-12-15 09:52:25 --> Helper loaded: security_helper
INFO - 2023-12-15 09:52:25 --> Helper loaded: cookie_helper
INFO - 2023-12-15 09:52:25 --> Database Driver Class Initialized
INFO - 2023-12-15 09:52:25 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-15 09:52:25 --> Parser Class Initialized
INFO - 2023-12-15 09:52:25 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-12-15 09:52:25 --> Pagination Class Initialized
INFO - 2023-12-15 09:52:25 --> Form Validation Class Initialized
INFO - 2023-12-15 09:52:25 --> Controller Class Initialized
INFO - 2023-12-15 09:52:25 --> Model Class Initialized
DEBUG - 2023-12-15 09:52:25 --> Session class already loaded. Second attempt ignored.
INFO - 2023-12-15 09:52:25 --> Model Class Initialized
INFO - 2023-12-15 09:52:25 --> Final output sent to browser
DEBUG - 2023-12-15 09:52:25 --> Total execution time: 0.0193
ERROR - 2023-12-15 09:52:25 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-12-15 09:52:25 --> Config Class Initialized
INFO - 2023-12-15 09:52:25 --> Hooks Class Initialized
DEBUG - 2023-12-15 09:52:25 --> UTF-8 Support Enabled
INFO - 2023-12-15 09:52:25 --> Utf8 Class Initialized
INFO - 2023-12-15 09:52:25 --> URI Class Initialized
DEBUG - 2023-12-15 09:52:25 --> No URI present. Default controller set.
INFO - 2023-12-15 09:52:25 --> Router Class Initialized
INFO - 2023-12-15 09:52:25 --> Output Class Initialized
INFO - 2023-12-15 09:52:25 --> Security Class Initialized
DEBUG - 2023-12-15 09:52:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-15 09:52:25 --> Input Class Initialized
INFO - 2023-12-15 09:52:25 --> Language Class Initialized
INFO - 2023-12-15 09:52:25 --> Loader Class Initialized
INFO - 2023-12-15 09:52:25 --> Helper loaded: url_helper
INFO - 2023-12-15 09:52:25 --> Helper loaded: file_helper
INFO - 2023-12-15 09:52:25 --> Helper loaded: html_helper
INFO - 2023-12-15 09:52:25 --> Helper loaded: text_helper
INFO - 2023-12-15 09:52:25 --> Helper loaded: form_helper
INFO - 2023-12-15 09:52:25 --> Helper loaded: lang_helper
INFO - 2023-12-15 09:52:25 --> Helper loaded: security_helper
INFO - 2023-12-15 09:52:25 --> Helper loaded: cookie_helper
INFO - 2023-12-15 09:52:25 --> Database Driver Class Initialized
INFO - 2023-12-15 09:52:25 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-15 09:52:25 --> Parser Class Initialized
INFO - 2023-12-15 09:52:25 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-12-15 09:52:25 --> Pagination Class Initialized
INFO - 2023-12-15 09:52:25 --> Form Validation Class Initialized
INFO - 2023-12-15 09:52:25 --> Controller Class Initialized
INFO - 2023-12-15 09:52:25 --> Model Class Initialized
DEBUG - 2023-12-15 09:52:25 --> Session class already loaded. Second attempt ignored.
INFO - 2023-12-15 09:52:25 --> Model Class Initialized
DEBUG - 2023-12-15 09:52:25 --> Session class already loaded. Second attempt ignored.
INFO - 2023-12-15 09:52:25 --> Model Class Initialized
INFO - 2023-12-15 09:52:25 --> Model Class Initialized
INFO - 2023-12-15 09:52:25 --> Model Class Initialized
INFO - 2023-12-15 09:52:25 --> Model Class Initialized
DEBUG - 2023-12-15 09:52:25 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-12-15 09:52:25 --> Session class already loaded. Second attempt ignored.
INFO - 2023-12-15 09:52:25 --> Model Class Initialized
INFO - 2023-12-15 09:52:25 --> Model Class Initialized
INFO - 2023-12-15 09:52:25 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-12-15 09:52:25 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-12-15 09:52:25 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-12-15 09:52:25 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-12-15 09:52:25 --> Model Class Initialized
INFO - 2023-12-15 09:52:25 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-12-15 09:52:25 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-12-15 09:52:25 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-12-15 09:52:25 --> Final output sent to browser
DEBUG - 2023-12-15 09:52:25 --> Total execution time: 0.3927
ERROR - 2023-12-15 09:52:26 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-12-15 09:52:26 --> Config Class Initialized
INFO - 2023-12-15 09:52:26 --> Hooks Class Initialized
DEBUG - 2023-12-15 09:52:26 --> UTF-8 Support Enabled
INFO - 2023-12-15 09:52:26 --> Utf8 Class Initialized
INFO - 2023-12-15 09:52:26 --> URI Class Initialized
INFO - 2023-12-15 09:52:26 --> Router Class Initialized
INFO - 2023-12-15 09:52:26 --> Output Class Initialized
INFO - 2023-12-15 09:52:26 --> Security Class Initialized
DEBUG - 2023-12-15 09:52:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-15 09:52:26 --> Input Class Initialized
INFO - 2023-12-15 09:52:26 --> Language Class Initialized
INFO - 2023-12-15 09:52:26 --> Loader Class Initialized
INFO - 2023-12-15 09:52:26 --> Helper loaded: url_helper
INFO - 2023-12-15 09:52:26 --> Helper loaded: file_helper
INFO - 2023-12-15 09:52:26 --> Helper loaded: html_helper
INFO - 2023-12-15 09:52:26 --> Helper loaded: text_helper
INFO - 2023-12-15 09:52:26 --> Helper loaded: form_helper
INFO - 2023-12-15 09:52:26 --> Helper loaded: lang_helper
INFO - 2023-12-15 09:52:26 --> Helper loaded: security_helper
INFO - 2023-12-15 09:52:26 --> Helper loaded: cookie_helper
INFO - 2023-12-15 09:52:26 --> Database Driver Class Initialized
INFO - 2023-12-15 09:52:26 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-15 09:52:26 --> Parser Class Initialized
INFO - 2023-12-15 09:52:26 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-12-15 09:52:26 --> Pagination Class Initialized
INFO - 2023-12-15 09:52:26 --> Form Validation Class Initialized
INFO - 2023-12-15 09:52:26 --> Controller Class Initialized
DEBUG - 2023-12-15 09:52:26 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-12-15 09:52:26 --> Session class already loaded. Second attempt ignored.
INFO - 2023-12-15 09:52:26 --> Model Class Initialized
INFO - 2023-12-15 09:52:26 --> Final output sent to browser
DEBUG - 2023-12-15 09:52:26 --> Total execution time: 0.0131
ERROR - 2023-12-15 09:53:03 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-12-15 09:53:03 --> Config Class Initialized
INFO - 2023-12-15 09:53:03 --> Hooks Class Initialized
DEBUG - 2023-12-15 09:53:03 --> UTF-8 Support Enabled
INFO - 2023-12-15 09:53:03 --> Utf8 Class Initialized
INFO - 2023-12-15 09:53:03 --> URI Class Initialized
INFO - 2023-12-15 09:53:03 --> Router Class Initialized
INFO - 2023-12-15 09:53:03 --> Output Class Initialized
INFO - 2023-12-15 09:53:03 --> Security Class Initialized
DEBUG - 2023-12-15 09:53:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-15 09:53:03 --> Input Class Initialized
INFO - 2023-12-15 09:53:03 --> Language Class Initialized
INFO - 2023-12-15 09:53:03 --> Loader Class Initialized
INFO - 2023-12-15 09:53:03 --> Helper loaded: url_helper
INFO - 2023-12-15 09:53:03 --> Helper loaded: file_helper
INFO - 2023-12-15 09:53:03 --> Helper loaded: html_helper
INFO - 2023-12-15 09:53:03 --> Helper loaded: text_helper
INFO - 2023-12-15 09:53:03 --> Helper loaded: form_helper
INFO - 2023-12-15 09:53:03 --> Helper loaded: lang_helper
INFO - 2023-12-15 09:53:03 --> Helper loaded: security_helper
INFO - 2023-12-15 09:53:03 --> Helper loaded: cookie_helper
INFO - 2023-12-15 09:53:03 --> Database Driver Class Initialized
INFO - 2023-12-15 09:53:03 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-15 09:53:03 --> Parser Class Initialized
INFO - 2023-12-15 09:53:03 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-12-15 09:53:03 --> Pagination Class Initialized
INFO - 2023-12-15 09:53:03 --> Form Validation Class Initialized
INFO - 2023-12-15 09:53:03 --> Controller Class Initialized
DEBUG - 2023-12-15 09:53:03 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-12-15 09:53:03 --> Session class already loaded. Second attempt ignored.
INFO - 2023-12-15 09:53:03 --> Model Class Initialized
INFO - 2023-12-15 09:53:03 --> Model Class Initialized
DEBUG - 2023-12-15 09:53:03 --> Lmr class already loaded. Second attempt ignored.
INFO - 2023-12-15 09:53:03 --> Model Class Initialized
INFO - 2023-12-15 09:53:03 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/mr/mr.php
DEBUG - 2023-12-15 09:53:03 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-12-15 09:53:03 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-12-15 09:53:03 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-12-15 09:53:03 --> Model Class Initialized
INFO - 2023-12-15 09:53:03 --> Model Class Initialized
INFO - 2023-12-15 09:53:03 --> Model Class Initialized
INFO - 2023-12-15 09:53:03 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-12-15 09:53:03 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-12-15 09:53:03 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-12-15 09:53:03 --> Final output sent to browser
DEBUG - 2023-12-15 09:53:03 --> Total execution time: 0.2012
ERROR - 2023-12-15 09:53:04 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-12-15 09:53:04 --> Config Class Initialized
INFO - 2023-12-15 09:53:04 --> Hooks Class Initialized
DEBUG - 2023-12-15 09:53:04 --> UTF-8 Support Enabled
INFO - 2023-12-15 09:53:04 --> Utf8 Class Initialized
INFO - 2023-12-15 09:53:04 --> URI Class Initialized
INFO - 2023-12-15 09:53:04 --> Router Class Initialized
INFO - 2023-12-15 09:53:04 --> Output Class Initialized
INFO - 2023-12-15 09:53:04 --> Security Class Initialized
DEBUG - 2023-12-15 09:53:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-15 09:53:04 --> Input Class Initialized
INFO - 2023-12-15 09:53:04 --> Language Class Initialized
INFO - 2023-12-15 09:53:04 --> Loader Class Initialized
INFO - 2023-12-15 09:53:04 --> Helper loaded: url_helper
INFO - 2023-12-15 09:53:04 --> Helper loaded: file_helper
INFO - 2023-12-15 09:53:04 --> Helper loaded: html_helper
INFO - 2023-12-15 09:53:04 --> Helper loaded: text_helper
INFO - 2023-12-15 09:53:04 --> Helper loaded: form_helper
INFO - 2023-12-15 09:53:04 --> Helper loaded: lang_helper
INFO - 2023-12-15 09:53:04 --> Helper loaded: security_helper
INFO - 2023-12-15 09:53:04 --> Helper loaded: cookie_helper
INFO - 2023-12-15 09:53:04 --> Database Driver Class Initialized
INFO - 2023-12-15 09:53:04 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-15 09:53:04 --> Parser Class Initialized
INFO - 2023-12-15 09:53:04 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-12-15 09:53:04 --> Pagination Class Initialized
INFO - 2023-12-15 09:53:04 --> Form Validation Class Initialized
INFO - 2023-12-15 09:53:04 --> Controller Class Initialized
DEBUG - 2023-12-15 09:53:04 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-12-15 09:53:04 --> Session class already loaded. Second attempt ignored.
INFO - 2023-12-15 09:53:04 --> Model Class Initialized
INFO - 2023-12-15 09:53:04 --> Model Class Initialized
INFO - 2023-12-15 09:53:04 --> Final output sent to browser
DEBUG - 2023-12-15 09:53:04 --> Total execution time: 0.0231
ERROR - 2023-12-15 09:53:18 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-12-15 09:53:18 --> Config Class Initialized
INFO - 2023-12-15 09:53:18 --> Hooks Class Initialized
DEBUG - 2023-12-15 09:53:18 --> UTF-8 Support Enabled
INFO - 2023-12-15 09:53:18 --> Utf8 Class Initialized
INFO - 2023-12-15 09:53:18 --> URI Class Initialized
INFO - 2023-12-15 09:53:18 --> Router Class Initialized
INFO - 2023-12-15 09:53:18 --> Output Class Initialized
INFO - 2023-12-15 09:53:18 --> Security Class Initialized
DEBUG - 2023-12-15 09:53:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-15 09:53:18 --> Input Class Initialized
INFO - 2023-12-15 09:53:18 --> Language Class Initialized
INFO - 2023-12-15 09:53:18 --> Loader Class Initialized
INFO - 2023-12-15 09:53:18 --> Helper loaded: url_helper
INFO - 2023-12-15 09:53:18 --> Helper loaded: file_helper
INFO - 2023-12-15 09:53:18 --> Helper loaded: html_helper
INFO - 2023-12-15 09:53:18 --> Helper loaded: text_helper
INFO - 2023-12-15 09:53:18 --> Helper loaded: form_helper
INFO - 2023-12-15 09:53:18 --> Helper loaded: lang_helper
INFO - 2023-12-15 09:53:18 --> Helper loaded: security_helper
INFO - 2023-12-15 09:53:18 --> Helper loaded: cookie_helper
INFO - 2023-12-15 09:53:18 --> Database Driver Class Initialized
INFO - 2023-12-15 09:53:18 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-15 09:53:18 --> Parser Class Initialized
INFO - 2023-12-15 09:53:18 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-12-15 09:53:18 --> Pagination Class Initialized
INFO - 2023-12-15 09:53:18 --> Form Validation Class Initialized
INFO - 2023-12-15 09:53:18 --> Controller Class Initialized
INFO - 2023-12-15 09:53:18 --> Model Class Initialized
DEBUG - 2023-12-15 09:53:18 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-12-15 09:53:18 --> Session class already loaded. Second attempt ignored.
INFO - 2023-12-15 09:53:18 --> Model Class Initialized
DEBUG - 2023-12-15 09:53:18 --> Session class already loaded. Second attempt ignored.
INFO - 2023-12-15 09:53:18 --> Model Class Initialized
INFO - 2023-12-15 09:53:18 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice.php
DEBUG - 2023-12-15 09:53:18 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-12-15 09:53:18 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-12-15 09:53:18 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-12-15 09:53:18 --> Model Class Initialized
INFO - 2023-12-15 09:53:18 --> Model Class Initialized
INFO - 2023-12-15 09:53:18 --> Model Class Initialized
INFO - 2023-12-15 09:53:18 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-12-15 09:53:18 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-12-15 09:53:18 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-12-15 09:53:18 --> Final output sent to browser
DEBUG - 2023-12-15 09:53:18 --> Total execution time: 0.2128
ERROR - 2023-12-15 09:53:19 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-12-15 09:53:19 --> Config Class Initialized
INFO - 2023-12-15 09:53:19 --> Hooks Class Initialized
DEBUG - 2023-12-15 09:53:19 --> UTF-8 Support Enabled
INFO - 2023-12-15 09:53:19 --> Utf8 Class Initialized
INFO - 2023-12-15 09:53:19 --> URI Class Initialized
INFO - 2023-12-15 09:53:19 --> Router Class Initialized
INFO - 2023-12-15 09:53:19 --> Output Class Initialized
INFO - 2023-12-15 09:53:19 --> Security Class Initialized
DEBUG - 2023-12-15 09:53:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-15 09:53:19 --> Input Class Initialized
INFO - 2023-12-15 09:53:19 --> Language Class Initialized
INFO - 2023-12-15 09:53:19 --> Loader Class Initialized
INFO - 2023-12-15 09:53:19 --> Helper loaded: url_helper
INFO - 2023-12-15 09:53:19 --> Helper loaded: file_helper
INFO - 2023-12-15 09:53:19 --> Helper loaded: html_helper
INFO - 2023-12-15 09:53:19 --> Helper loaded: text_helper
INFO - 2023-12-15 09:53:19 --> Helper loaded: form_helper
INFO - 2023-12-15 09:53:19 --> Helper loaded: lang_helper
INFO - 2023-12-15 09:53:19 --> Helper loaded: security_helper
INFO - 2023-12-15 09:53:19 --> Helper loaded: cookie_helper
INFO - 2023-12-15 09:53:19 --> Database Driver Class Initialized
INFO - 2023-12-15 09:53:19 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-15 09:53:19 --> Parser Class Initialized
INFO - 2023-12-15 09:53:19 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-12-15 09:53:19 --> Pagination Class Initialized
INFO - 2023-12-15 09:53:19 --> Form Validation Class Initialized
INFO - 2023-12-15 09:53:19 --> Controller Class Initialized
INFO - 2023-12-15 09:53:19 --> Model Class Initialized
DEBUG - 2023-12-15 09:53:19 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-12-15 09:53:19 --> Session class already loaded. Second attempt ignored.
INFO - 2023-12-15 09:53:19 --> Model Class Initialized
DEBUG - 2023-12-15 09:53:19 --> Session class already loaded. Second attempt ignored.
INFO - 2023-12-15 09:53:19 --> Model Class Initialized
INFO - 2023-12-15 09:53:19 --> Final output sent to browser
DEBUG - 2023-12-15 09:53:19 --> Total execution time: 0.0556
ERROR - 2023-12-15 09:53:22 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-12-15 09:53:22 --> Config Class Initialized
INFO - 2023-12-15 09:53:22 --> Hooks Class Initialized
DEBUG - 2023-12-15 09:53:22 --> UTF-8 Support Enabled
INFO - 2023-12-15 09:53:22 --> Utf8 Class Initialized
INFO - 2023-12-15 09:53:22 --> URI Class Initialized
INFO - 2023-12-15 09:53:22 --> Router Class Initialized
INFO - 2023-12-15 09:53:22 --> Output Class Initialized
INFO - 2023-12-15 09:53:22 --> Security Class Initialized
DEBUG - 2023-12-15 09:53:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-15 09:53:22 --> Input Class Initialized
INFO - 2023-12-15 09:53:22 --> Language Class Initialized
INFO - 2023-12-15 09:53:22 --> Loader Class Initialized
INFO - 2023-12-15 09:53:22 --> Helper loaded: url_helper
INFO - 2023-12-15 09:53:22 --> Helper loaded: file_helper
INFO - 2023-12-15 09:53:22 --> Helper loaded: html_helper
INFO - 2023-12-15 09:53:22 --> Helper loaded: text_helper
INFO - 2023-12-15 09:53:22 --> Helper loaded: form_helper
INFO - 2023-12-15 09:53:22 --> Helper loaded: lang_helper
INFO - 2023-12-15 09:53:22 --> Helper loaded: security_helper
INFO - 2023-12-15 09:53:22 --> Helper loaded: cookie_helper
INFO - 2023-12-15 09:53:22 --> Database Driver Class Initialized
INFO - 2023-12-15 09:53:22 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-15 09:53:22 --> Parser Class Initialized
INFO - 2023-12-15 09:53:22 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-12-15 09:53:22 --> Pagination Class Initialized
INFO - 2023-12-15 09:53:22 --> Form Validation Class Initialized
INFO - 2023-12-15 09:53:22 --> Controller Class Initialized
INFO - 2023-12-15 09:53:22 --> Model Class Initialized
DEBUG - 2023-12-15 09:53:22 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-12-15 09:53:22 --> Session class already loaded. Second attempt ignored.
INFO - 2023-12-15 09:53:22 --> Model Class Initialized
DEBUG - 2023-12-15 09:53:22 --> Session class already loaded. Second attempt ignored.
INFO - 2023-12-15 09:53:22 --> Model Class Initialized
INFO - 2023-12-15 09:53:22 --> Final output sent to browser
DEBUG - 2023-12-15 09:53:22 --> Total execution time: 0.0615
ERROR - 2023-12-15 09:53:23 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-12-15 09:53:23 --> Config Class Initialized
INFO - 2023-12-15 09:53:23 --> Hooks Class Initialized
DEBUG - 2023-12-15 09:53:23 --> UTF-8 Support Enabled
INFO - 2023-12-15 09:53:23 --> Utf8 Class Initialized
INFO - 2023-12-15 09:53:23 --> URI Class Initialized
INFO - 2023-12-15 09:53:23 --> Router Class Initialized
INFO - 2023-12-15 09:53:23 --> Output Class Initialized
INFO - 2023-12-15 09:53:23 --> Security Class Initialized
DEBUG - 2023-12-15 09:53:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-15 09:53:23 --> Input Class Initialized
INFO - 2023-12-15 09:53:23 --> Language Class Initialized
INFO - 2023-12-15 09:53:23 --> Loader Class Initialized
INFO - 2023-12-15 09:53:23 --> Helper loaded: url_helper
INFO - 2023-12-15 09:53:23 --> Helper loaded: file_helper
INFO - 2023-12-15 09:53:23 --> Helper loaded: html_helper
INFO - 2023-12-15 09:53:23 --> Helper loaded: text_helper
INFO - 2023-12-15 09:53:23 --> Helper loaded: form_helper
INFO - 2023-12-15 09:53:23 --> Helper loaded: lang_helper
INFO - 2023-12-15 09:53:23 --> Helper loaded: security_helper
INFO - 2023-12-15 09:53:23 --> Helper loaded: cookie_helper
INFO - 2023-12-15 09:53:23 --> Database Driver Class Initialized
INFO - 2023-12-15 09:53:23 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-15 09:53:23 --> Parser Class Initialized
INFO - 2023-12-15 09:53:23 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-12-15 09:53:23 --> Pagination Class Initialized
INFO - 2023-12-15 09:53:23 --> Form Validation Class Initialized
INFO - 2023-12-15 09:53:23 --> Controller Class Initialized
INFO - 2023-12-15 09:53:23 --> Model Class Initialized
DEBUG - 2023-12-15 09:53:23 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-12-15 09:53:23 --> Session class already loaded. Second attempt ignored.
INFO - 2023-12-15 09:53:23 --> Model Class Initialized
DEBUG - 2023-12-15 09:53:23 --> Session class already loaded. Second attempt ignored.
INFO - 2023-12-15 09:53:23 --> Model Class Initialized
INFO - 2023-12-15 09:53:23 --> Final output sent to browser
DEBUG - 2023-12-15 09:53:23 --> Total execution time: 0.0313
ERROR - 2023-12-15 09:53:24 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-12-15 09:53:24 --> Config Class Initialized
INFO - 2023-12-15 09:53:24 --> Hooks Class Initialized
DEBUG - 2023-12-15 09:53:24 --> UTF-8 Support Enabled
INFO - 2023-12-15 09:53:24 --> Utf8 Class Initialized
INFO - 2023-12-15 09:53:24 --> URI Class Initialized
INFO - 2023-12-15 09:53:24 --> Router Class Initialized
INFO - 2023-12-15 09:53:24 --> Output Class Initialized
INFO - 2023-12-15 09:53:24 --> Security Class Initialized
DEBUG - 2023-12-15 09:53:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-15 09:53:24 --> Input Class Initialized
INFO - 2023-12-15 09:53:24 --> Language Class Initialized
INFO - 2023-12-15 09:53:24 --> Loader Class Initialized
INFO - 2023-12-15 09:53:24 --> Helper loaded: url_helper
INFO - 2023-12-15 09:53:24 --> Helper loaded: file_helper
INFO - 2023-12-15 09:53:24 --> Helper loaded: html_helper
INFO - 2023-12-15 09:53:24 --> Helper loaded: text_helper
INFO - 2023-12-15 09:53:24 --> Helper loaded: form_helper
INFO - 2023-12-15 09:53:24 --> Helper loaded: lang_helper
INFO - 2023-12-15 09:53:24 --> Helper loaded: security_helper
INFO - 2023-12-15 09:53:24 --> Helper loaded: cookie_helper
INFO - 2023-12-15 09:53:24 --> Database Driver Class Initialized
INFO - 2023-12-15 09:53:24 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-15 09:53:24 --> Parser Class Initialized
INFO - 2023-12-15 09:53:24 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-12-15 09:53:24 --> Pagination Class Initialized
INFO - 2023-12-15 09:53:24 --> Form Validation Class Initialized
INFO - 2023-12-15 09:53:24 --> Controller Class Initialized
INFO - 2023-12-15 09:53:24 --> Model Class Initialized
DEBUG - 2023-12-15 09:53:24 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-12-15 09:53:24 --> Session class already loaded. Second attempt ignored.
INFO - 2023-12-15 09:53:24 --> Model Class Initialized
DEBUG - 2023-12-15 09:53:24 --> Session class already loaded. Second attempt ignored.
INFO - 2023-12-15 09:53:24 --> Model Class Initialized
INFO - 2023-12-15 09:53:24 --> Final output sent to browser
DEBUG - 2023-12-15 09:53:24 --> Total execution time: 0.0342
ERROR - 2023-12-15 09:53:48 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-12-15 09:53:48 --> Config Class Initialized
INFO - 2023-12-15 09:53:48 --> Hooks Class Initialized
DEBUG - 2023-12-15 09:53:48 --> UTF-8 Support Enabled
INFO - 2023-12-15 09:53:48 --> Utf8 Class Initialized
INFO - 2023-12-15 09:53:48 --> URI Class Initialized
DEBUG - 2023-12-15 09:53:48 --> No URI present. Default controller set.
INFO - 2023-12-15 09:53:48 --> Router Class Initialized
INFO - 2023-12-15 09:53:48 --> Output Class Initialized
INFO - 2023-12-15 09:53:48 --> Security Class Initialized
DEBUG - 2023-12-15 09:53:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-15 09:53:48 --> Input Class Initialized
INFO - 2023-12-15 09:53:48 --> Language Class Initialized
INFO - 2023-12-15 09:53:48 --> Loader Class Initialized
INFO - 2023-12-15 09:53:48 --> Helper loaded: url_helper
INFO - 2023-12-15 09:53:48 --> Helper loaded: file_helper
INFO - 2023-12-15 09:53:48 --> Helper loaded: html_helper
INFO - 2023-12-15 09:53:48 --> Helper loaded: text_helper
INFO - 2023-12-15 09:53:48 --> Helper loaded: form_helper
INFO - 2023-12-15 09:53:48 --> Helper loaded: lang_helper
INFO - 2023-12-15 09:53:48 --> Helper loaded: security_helper
INFO - 2023-12-15 09:53:48 --> Helper loaded: cookie_helper
INFO - 2023-12-15 09:53:48 --> Database Driver Class Initialized
INFO - 2023-12-15 09:53:48 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-15 09:53:48 --> Parser Class Initialized
INFO - 2023-12-15 09:53:48 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-12-15 09:53:48 --> Pagination Class Initialized
INFO - 2023-12-15 09:53:48 --> Form Validation Class Initialized
INFO - 2023-12-15 09:53:48 --> Controller Class Initialized
INFO - 2023-12-15 09:53:48 --> Model Class Initialized
DEBUG - 2023-12-15 09:53:48 --> Session class already loaded. Second attempt ignored.
INFO - 2023-12-15 09:53:48 --> Model Class Initialized
DEBUG - 2023-12-15 09:53:48 --> Session class already loaded. Second attempt ignored.
INFO - 2023-12-15 09:53:48 --> Model Class Initialized
INFO - 2023-12-15 09:53:48 --> Model Class Initialized
INFO - 2023-12-15 09:53:48 --> Model Class Initialized
INFO - 2023-12-15 09:53:48 --> Model Class Initialized
DEBUG - 2023-12-15 09:53:48 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-12-15 09:53:48 --> Session class already loaded. Second attempt ignored.
INFO - 2023-12-15 09:53:48 --> Model Class Initialized
INFO - 2023-12-15 09:53:48 --> Model Class Initialized
INFO - 2023-12-15 09:53:49 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-12-15 09:53:49 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-12-15 09:53:49 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-12-15 09:53:49 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-12-15 09:53:49 --> Model Class Initialized
INFO - 2023-12-15 09:53:49 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-12-15 09:53:49 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-12-15 09:53:49 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-12-15 09:53:49 --> Final output sent to browser
DEBUG - 2023-12-15 09:53:49 --> Total execution time: 0.3781
ERROR - 2023-12-15 10:43:40 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-12-15 10:43:40 --> Config Class Initialized
INFO - 2023-12-15 10:43:40 --> Hooks Class Initialized
DEBUG - 2023-12-15 10:43:40 --> UTF-8 Support Enabled
INFO - 2023-12-15 10:43:40 --> Utf8 Class Initialized
INFO - 2023-12-15 10:43:40 --> URI Class Initialized
DEBUG - 2023-12-15 10:43:40 --> No URI present. Default controller set.
INFO - 2023-12-15 10:43:40 --> Router Class Initialized
INFO - 2023-12-15 10:43:40 --> Output Class Initialized
INFO - 2023-12-15 10:43:40 --> Security Class Initialized
DEBUG - 2023-12-15 10:43:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-15 10:43:40 --> Input Class Initialized
INFO - 2023-12-15 10:43:40 --> Language Class Initialized
INFO - 2023-12-15 10:43:40 --> Loader Class Initialized
INFO - 2023-12-15 10:43:40 --> Helper loaded: url_helper
INFO - 2023-12-15 10:43:40 --> Helper loaded: file_helper
INFO - 2023-12-15 10:43:40 --> Helper loaded: html_helper
INFO - 2023-12-15 10:43:40 --> Helper loaded: text_helper
INFO - 2023-12-15 10:43:40 --> Helper loaded: form_helper
INFO - 2023-12-15 10:43:40 --> Helper loaded: lang_helper
INFO - 2023-12-15 10:43:40 --> Helper loaded: security_helper
INFO - 2023-12-15 10:43:40 --> Helper loaded: cookie_helper
INFO - 2023-12-15 10:43:40 --> Database Driver Class Initialized
INFO - 2023-12-15 10:43:40 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-15 10:43:40 --> Parser Class Initialized
INFO - 2023-12-15 10:43:40 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-12-15 10:43:40 --> Pagination Class Initialized
INFO - 2023-12-15 10:43:40 --> Form Validation Class Initialized
INFO - 2023-12-15 10:43:40 --> Controller Class Initialized
INFO - 2023-12-15 10:43:40 --> Model Class Initialized
DEBUG - 2023-12-15 10:43:40 --> Session class already loaded. Second attempt ignored.
INFO - 2023-12-15 10:43:40 --> Model Class Initialized
DEBUG - 2023-12-15 10:43:40 --> Session class already loaded. Second attempt ignored.
INFO - 2023-12-15 10:43:40 --> Model Class Initialized
INFO - 2023-12-15 10:43:40 --> Model Class Initialized
INFO - 2023-12-15 10:43:40 --> Model Class Initialized
INFO - 2023-12-15 10:43:40 --> Model Class Initialized
DEBUG - 2023-12-15 10:43:40 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-12-15 10:43:40 --> Session class already loaded. Second attempt ignored.
INFO - 2023-12-15 10:43:40 --> Model Class Initialized
INFO - 2023-12-15 10:43:40 --> Model Class Initialized
INFO - 2023-12-15 10:43:40 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-12-15 10:43:40 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-12-15 10:43:40 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-12-15 10:43:40 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-12-15 10:43:40 --> Model Class Initialized
INFO - 2023-12-15 10:43:40 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-12-15 10:43:40 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-12-15 10:43:40 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-12-15 10:43:40 --> Final output sent to browser
DEBUG - 2023-12-15 10:43:40 --> Total execution time: 0.3940
ERROR - 2023-12-15 10:47:33 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-12-15 10:47:33 --> Config Class Initialized
INFO - 2023-12-15 10:47:33 --> Hooks Class Initialized
DEBUG - 2023-12-15 10:47:33 --> UTF-8 Support Enabled
INFO - 2023-12-15 10:47:33 --> Utf8 Class Initialized
INFO - 2023-12-15 10:47:33 --> URI Class Initialized
DEBUG - 2023-12-15 10:47:33 --> No URI present. Default controller set.
INFO - 2023-12-15 10:47:33 --> Router Class Initialized
INFO - 2023-12-15 10:47:33 --> Output Class Initialized
INFO - 2023-12-15 10:47:33 --> Security Class Initialized
DEBUG - 2023-12-15 10:47:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-15 10:47:33 --> Input Class Initialized
INFO - 2023-12-15 10:47:33 --> Language Class Initialized
INFO - 2023-12-15 10:47:33 --> Loader Class Initialized
INFO - 2023-12-15 10:47:33 --> Helper loaded: url_helper
INFO - 2023-12-15 10:47:33 --> Helper loaded: file_helper
INFO - 2023-12-15 10:47:33 --> Helper loaded: html_helper
INFO - 2023-12-15 10:47:33 --> Helper loaded: text_helper
INFO - 2023-12-15 10:47:33 --> Helper loaded: form_helper
INFO - 2023-12-15 10:47:33 --> Helper loaded: lang_helper
INFO - 2023-12-15 10:47:33 --> Helper loaded: security_helper
INFO - 2023-12-15 10:47:33 --> Helper loaded: cookie_helper
INFO - 2023-12-15 10:47:33 --> Database Driver Class Initialized
INFO - 2023-12-15 10:47:33 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-15 10:47:33 --> Parser Class Initialized
INFO - 2023-12-15 10:47:33 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-12-15 10:47:33 --> Pagination Class Initialized
INFO - 2023-12-15 10:47:33 --> Form Validation Class Initialized
INFO - 2023-12-15 10:47:33 --> Controller Class Initialized
INFO - 2023-12-15 10:47:33 --> Model Class Initialized
DEBUG - 2023-12-15 10:47:33 --> Session class already loaded. Second attempt ignored.
INFO - 2023-12-15 10:47:33 --> Model Class Initialized
DEBUG - 2023-12-15 10:47:33 --> Session class already loaded. Second attempt ignored.
INFO - 2023-12-15 10:47:33 --> Model Class Initialized
INFO - 2023-12-15 10:47:33 --> Model Class Initialized
INFO - 2023-12-15 10:47:33 --> Model Class Initialized
INFO - 2023-12-15 10:47:33 --> Model Class Initialized
DEBUG - 2023-12-15 10:47:33 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-12-15 10:47:33 --> Session class already loaded. Second attempt ignored.
INFO - 2023-12-15 10:47:33 --> Model Class Initialized
INFO - 2023-12-15 10:47:33 --> Model Class Initialized
INFO - 2023-12-15 10:47:33 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-12-15 10:47:33 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-12-15 10:47:33 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-12-15 10:47:33 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-12-15 10:47:33 --> Model Class Initialized
INFO - 2023-12-15 10:47:33 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-12-15 10:47:33 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-12-15 10:47:33 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-12-15 10:47:33 --> Final output sent to browser
DEBUG - 2023-12-15 10:47:33 --> Total execution time: 0.3827
ERROR - 2023-12-15 11:02:43 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-12-15 11:02:43 --> Config Class Initialized
INFO - 2023-12-15 11:02:43 --> Hooks Class Initialized
DEBUG - 2023-12-15 11:02:43 --> UTF-8 Support Enabled
INFO - 2023-12-15 11:02:43 --> Utf8 Class Initialized
INFO - 2023-12-15 11:02:43 --> URI Class Initialized
DEBUG - 2023-12-15 11:02:43 --> No URI present. Default controller set.
INFO - 2023-12-15 11:02:43 --> Router Class Initialized
INFO - 2023-12-15 11:02:43 --> Output Class Initialized
INFO - 2023-12-15 11:02:43 --> Security Class Initialized
DEBUG - 2023-12-15 11:02:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-15 11:02:43 --> Input Class Initialized
INFO - 2023-12-15 11:02:43 --> Language Class Initialized
INFO - 2023-12-15 11:02:43 --> Loader Class Initialized
INFO - 2023-12-15 11:02:43 --> Helper loaded: url_helper
INFO - 2023-12-15 11:02:43 --> Helper loaded: file_helper
INFO - 2023-12-15 11:02:43 --> Helper loaded: html_helper
INFO - 2023-12-15 11:02:43 --> Helper loaded: text_helper
INFO - 2023-12-15 11:02:43 --> Helper loaded: form_helper
INFO - 2023-12-15 11:02:43 --> Helper loaded: lang_helper
INFO - 2023-12-15 11:02:43 --> Helper loaded: security_helper
INFO - 2023-12-15 11:02:43 --> Helper loaded: cookie_helper
INFO - 2023-12-15 11:02:43 --> Database Driver Class Initialized
INFO - 2023-12-15 11:02:43 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-15 11:02:43 --> Parser Class Initialized
INFO - 2023-12-15 11:02:43 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-12-15 11:02:43 --> Pagination Class Initialized
INFO - 2023-12-15 11:02:43 --> Form Validation Class Initialized
INFO - 2023-12-15 11:02:43 --> Controller Class Initialized
INFO - 2023-12-15 11:02:43 --> Model Class Initialized
DEBUG - 2023-12-15 11:02:43 --> Session class already loaded. Second attempt ignored.
ERROR - 2023-12-15 11:02:43 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-12-15 11:02:43 --> Config Class Initialized
INFO - 2023-12-15 11:02:43 --> Hooks Class Initialized
DEBUG - 2023-12-15 11:02:43 --> UTF-8 Support Enabled
INFO - 2023-12-15 11:02:43 --> Utf8 Class Initialized
INFO - 2023-12-15 11:02:43 --> URI Class Initialized
INFO - 2023-12-15 11:02:43 --> Router Class Initialized
INFO - 2023-12-15 11:02:43 --> Output Class Initialized
INFO - 2023-12-15 11:02:43 --> Security Class Initialized
DEBUG - 2023-12-15 11:02:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-15 11:02:43 --> Input Class Initialized
INFO - 2023-12-15 11:02:43 --> Language Class Initialized
INFO - 2023-12-15 11:02:43 --> Loader Class Initialized
INFO - 2023-12-15 11:02:43 --> Helper loaded: url_helper
INFO - 2023-12-15 11:02:43 --> Helper loaded: file_helper
INFO - 2023-12-15 11:02:43 --> Helper loaded: html_helper
INFO - 2023-12-15 11:02:43 --> Helper loaded: text_helper
INFO - 2023-12-15 11:02:43 --> Helper loaded: form_helper
INFO - 2023-12-15 11:02:43 --> Helper loaded: lang_helper
INFO - 2023-12-15 11:02:43 --> Helper loaded: security_helper
INFO - 2023-12-15 11:02:43 --> Helper loaded: cookie_helper
INFO - 2023-12-15 11:02:43 --> Database Driver Class Initialized
INFO - 2023-12-15 11:02:43 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-15 11:02:43 --> Parser Class Initialized
INFO - 2023-12-15 11:02:43 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-12-15 11:02:43 --> Pagination Class Initialized
INFO - 2023-12-15 11:02:43 --> Form Validation Class Initialized
INFO - 2023-12-15 11:02:43 --> Controller Class Initialized
INFO - 2023-12-15 11:02:43 --> Model Class Initialized
DEBUG - 2023-12-15 11:02:43 --> Session class already loaded. Second attempt ignored.
INFO - 2023-12-15 11:02:43 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2023-12-15 11:02:43 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-12-15 11:02:43 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-12-15 11:02:43 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-12-15 11:02:43 --> Model Class Initialized
INFO - 2023-12-15 11:02:43 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-12-15 11:02:43 --> Final output sent to browser
DEBUG - 2023-12-15 11:02:43 --> Total execution time: 0.0314
ERROR - 2023-12-15 11:02:43 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-12-15 11:02:43 --> Config Class Initialized
INFO - 2023-12-15 11:02:43 --> Hooks Class Initialized
DEBUG - 2023-12-15 11:02:43 --> UTF-8 Support Enabled
INFO - 2023-12-15 11:02:43 --> Utf8 Class Initialized
INFO - 2023-12-15 11:02:43 --> URI Class Initialized
INFO - 2023-12-15 11:02:43 --> Router Class Initialized
INFO - 2023-12-15 11:02:43 --> Output Class Initialized
INFO - 2023-12-15 11:02:43 --> Security Class Initialized
DEBUG - 2023-12-15 11:02:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-15 11:02:43 --> Input Class Initialized
INFO - 2023-12-15 11:02:43 --> Language Class Initialized
ERROR - 2023-12-15 11:02:43 --> 404 Page Not Found: Apple-touch-icon-precomposedpng/index
ERROR - 2023-12-15 11:02:44 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-12-15 11:02:44 --> Config Class Initialized
INFO - 2023-12-15 11:02:44 --> Hooks Class Initialized
DEBUG - 2023-12-15 11:02:44 --> UTF-8 Support Enabled
INFO - 2023-12-15 11:02:44 --> Utf8 Class Initialized
INFO - 2023-12-15 11:02:44 --> URI Class Initialized
INFO - 2023-12-15 11:02:44 --> Router Class Initialized
INFO - 2023-12-15 11:02:44 --> Output Class Initialized
INFO - 2023-12-15 11:02:44 --> Security Class Initialized
DEBUG - 2023-12-15 11:02:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-15 11:02:44 --> Input Class Initialized
INFO - 2023-12-15 11:02:44 --> Language Class Initialized
ERROR - 2023-12-15 11:02:44 --> 404 Page Not Found: Apple-touch-iconpng/index
ERROR - 2023-12-15 11:02:48 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-12-15 11:02:48 --> Config Class Initialized
INFO - 2023-12-15 11:02:48 --> Hooks Class Initialized
DEBUG - 2023-12-15 11:02:48 --> UTF-8 Support Enabled
INFO - 2023-12-15 11:02:48 --> Utf8 Class Initialized
INFO - 2023-12-15 11:02:48 --> URI Class Initialized
DEBUG - 2023-12-15 11:02:48 --> No URI present. Default controller set.
INFO - 2023-12-15 11:02:48 --> Router Class Initialized
INFO - 2023-12-15 11:02:48 --> Output Class Initialized
INFO - 2023-12-15 11:02:48 --> Security Class Initialized
DEBUG - 2023-12-15 11:02:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-15 11:02:48 --> Input Class Initialized
INFO - 2023-12-15 11:02:48 --> Language Class Initialized
INFO - 2023-12-15 11:02:48 --> Loader Class Initialized
INFO - 2023-12-15 11:02:48 --> Helper loaded: url_helper
INFO - 2023-12-15 11:02:48 --> Helper loaded: file_helper
INFO - 2023-12-15 11:02:48 --> Helper loaded: html_helper
INFO - 2023-12-15 11:02:48 --> Helper loaded: text_helper
INFO - 2023-12-15 11:02:48 --> Helper loaded: form_helper
INFO - 2023-12-15 11:02:48 --> Helper loaded: lang_helper
INFO - 2023-12-15 11:02:48 --> Helper loaded: security_helper
INFO - 2023-12-15 11:02:48 --> Helper loaded: cookie_helper
INFO - 2023-12-15 11:02:48 --> Database Driver Class Initialized
INFO - 2023-12-15 11:02:48 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-15 11:02:48 --> Parser Class Initialized
INFO - 2023-12-15 11:02:48 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-12-15 11:02:48 --> Pagination Class Initialized
INFO - 2023-12-15 11:02:48 --> Form Validation Class Initialized
INFO - 2023-12-15 11:02:48 --> Controller Class Initialized
INFO - 2023-12-15 11:02:48 --> Model Class Initialized
DEBUG - 2023-12-15 11:02:48 --> Session class already loaded. Second attempt ignored.
INFO - 2023-12-15 11:02:48 --> Model Class Initialized
DEBUG - 2023-12-15 11:02:48 --> Session class already loaded. Second attempt ignored.
INFO - 2023-12-15 11:02:48 --> Model Class Initialized
INFO - 2023-12-15 11:02:48 --> Model Class Initialized
INFO - 2023-12-15 11:02:48 --> Model Class Initialized
INFO - 2023-12-15 11:02:48 --> Model Class Initialized
DEBUG - 2023-12-15 11:02:48 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-12-15 11:02:48 --> Session class already loaded. Second attempt ignored.
INFO - 2023-12-15 11:02:48 --> Model Class Initialized
INFO - 2023-12-15 11:02:48 --> Model Class Initialized
INFO - 2023-12-15 11:02:48 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-12-15 11:02:48 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-12-15 11:02:48 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-12-15 11:02:48 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-12-15 11:02:48 --> Model Class Initialized
INFO - 2023-12-15 11:02:49 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-12-15 11:02:49 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-12-15 11:02:49 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-12-15 11:02:49 --> Final output sent to browser
DEBUG - 2023-12-15 11:02:49 --> Total execution time: 0.3805
ERROR - 2023-12-15 13:47:14 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-12-15 13:47:14 --> Config Class Initialized
INFO - 2023-12-15 13:47:14 --> Hooks Class Initialized
DEBUG - 2023-12-15 13:47:14 --> UTF-8 Support Enabled
INFO - 2023-12-15 13:47:14 --> Utf8 Class Initialized
INFO - 2023-12-15 13:47:14 --> URI Class Initialized
INFO - 2023-12-15 13:47:14 --> Router Class Initialized
INFO - 2023-12-15 13:47:14 --> Output Class Initialized
INFO - 2023-12-15 13:47:14 --> Security Class Initialized
DEBUG - 2023-12-15 13:47:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-15 13:47:14 --> Input Class Initialized
INFO - 2023-12-15 13:47:14 --> Language Class Initialized
ERROR - 2023-12-15 13:47:14 --> 404 Page Not Found: Well-known/assetlinks.json
ERROR - 2023-12-15 17:17:15 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-12-15 17:17:15 --> Config Class Initialized
INFO - 2023-12-15 17:17:15 --> Hooks Class Initialized
DEBUG - 2023-12-15 17:17:15 --> UTF-8 Support Enabled
INFO - 2023-12-15 17:17:15 --> Utf8 Class Initialized
INFO - 2023-12-15 17:17:15 --> URI Class Initialized
DEBUG - 2023-12-15 17:17:15 --> No URI present. Default controller set.
INFO - 2023-12-15 17:17:15 --> Router Class Initialized
INFO - 2023-12-15 17:17:15 --> Output Class Initialized
INFO - 2023-12-15 17:17:15 --> Security Class Initialized
DEBUG - 2023-12-15 17:17:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-15 17:17:15 --> Input Class Initialized
INFO - 2023-12-15 17:17:15 --> Language Class Initialized
INFO - 2023-12-15 17:17:15 --> Loader Class Initialized
INFO - 2023-12-15 17:17:15 --> Helper loaded: url_helper
INFO - 2023-12-15 17:17:15 --> Helper loaded: file_helper
INFO - 2023-12-15 17:17:15 --> Helper loaded: html_helper
INFO - 2023-12-15 17:17:15 --> Helper loaded: text_helper
INFO - 2023-12-15 17:17:15 --> Helper loaded: form_helper
INFO - 2023-12-15 17:17:15 --> Helper loaded: lang_helper
INFO - 2023-12-15 17:17:15 --> Helper loaded: security_helper
INFO - 2023-12-15 17:17:15 --> Helper loaded: cookie_helper
INFO - 2023-12-15 17:17:15 --> Database Driver Class Initialized
INFO - 2023-12-15 17:17:15 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-15 17:17:15 --> Parser Class Initialized
INFO - 2023-12-15 17:17:15 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-12-15 17:17:15 --> Pagination Class Initialized
INFO - 2023-12-15 17:17:15 --> Form Validation Class Initialized
INFO - 2023-12-15 17:17:15 --> Controller Class Initialized
INFO - 2023-12-15 17:17:15 --> Model Class Initialized
DEBUG - 2023-12-15 17:17:15 --> Session class already loaded. Second attempt ignored.
ERROR - 2023-12-15 17:17:15 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-12-15 17:17:15 --> Config Class Initialized
INFO - 2023-12-15 17:17:15 --> Hooks Class Initialized
DEBUG - 2023-12-15 17:17:15 --> UTF-8 Support Enabled
INFO - 2023-12-15 17:17:15 --> Utf8 Class Initialized
INFO - 2023-12-15 17:17:15 --> URI Class Initialized
INFO - 2023-12-15 17:17:15 --> Router Class Initialized
INFO - 2023-12-15 17:17:15 --> Output Class Initialized
INFO - 2023-12-15 17:17:15 --> Security Class Initialized
DEBUG - 2023-12-15 17:17:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-15 17:17:15 --> Input Class Initialized
INFO - 2023-12-15 17:17:15 --> Language Class Initialized
INFO - 2023-12-15 17:17:15 --> Loader Class Initialized
INFO - 2023-12-15 17:17:15 --> Helper loaded: url_helper
INFO - 2023-12-15 17:17:15 --> Helper loaded: file_helper
INFO - 2023-12-15 17:17:15 --> Helper loaded: html_helper
INFO - 2023-12-15 17:17:15 --> Helper loaded: text_helper
INFO - 2023-12-15 17:17:15 --> Helper loaded: form_helper
INFO - 2023-12-15 17:17:15 --> Helper loaded: lang_helper
INFO - 2023-12-15 17:17:15 --> Helper loaded: security_helper
INFO - 2023-12-15 17:17:15 --> Helper loaded: cookie_helper
INFO - 2023-12-15 17:17:15 --> Database Driver Class Initialized
INFO - 2023-12-15 17:17:15 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-15 17:17:15 --> Parser Class Initialized
INFO - 2023-12-15 17:17:15 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-12-15 17:17:15 --> Pagination Class Initialized
INFO - 2023-12-15 17:17:15 --> Form Validation Class Initialized
INFO - 2023-12-15 17:17:15 --> Controller Class Initialized
INFO - 2023-12-15 17:17:15 --> Model Class Initialized
DEBUG - 2023-12-15 17:17:15 --> Session class already loaded. Second attempt ignored.
INFO - 2023-12-15 17:17:15 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2023-12-15 17:17:15 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-12-15 17:17:15 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-12-15 17:17:15 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-12-15 17:17:15 --> Model Class Initialized
INFO - 2023-12-15 17:17:15 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-12-15 17:17:15 --> Final output sent to browser
DEBUG - 2023-12-15 17:17:15 --> Total execution time: 0.0375
ERROR - 2023-12-15 19:23:13 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-12-15 19:23:13 --> Config Class Initialized
INFO - 2023-12-15 19:23:13 --> Hooks Class Initialized
DEBUG - 2023-12-15 19:23:13 --> UTF-8 Support Enabled
INFO - 2023-12-15 19:23:13 --> Utf8 Class Initialized
INFO - 2023-12-15 19:23:13 --> URI Class Initialized
DEBUG - 2023-12-15 19:23:13 --> No URI present. Default controller set.
INFO - 2023-12-15 19:23:13 --> Router Class Initialized
INFO - 2023-12-15 19:23:13 --> Output Class Initialized
INFO - 2023-12-15 19:23:13 --> Security Class Initialized
DEBUG - 2023-12-15 19:23:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-15 19:23:13 --> Input Class Initialized
INFO - 2023-12-15 19:23:13 --> Language Class Initialized
INFO - 2023-12-15 19:23:13 --> Loader Class Initialized
INFO - 2023-12-15 19:23:13 --> Helper loaded: url_helper
INFO - 2023-12-15 19:23:13 --> Helper loaded: file_helper
INFO - 2023-12-15 19:23:13 --> Helper loaded: html_helper
INFO - 2023-12-15 19:23:13 --> Helper loaded: text_helper
INFO - 2023-12-15 19:23:13 --> Helper loaded: form_helper
INFO - 2023-12-15 19:23:13 --> Helper loaded: lang_helper
INFO - 2023-12-15 19:23:13 --> Helper loaded: security_helper
INFO - 2023-12-15 19:23:13 --> Helper loaded: cookie_helper
INFO - 2023-12-15 19:23:13 --> Database Driver Class Initialized
INFO - 2023-12-15 19:23:13 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-15 19:23:13 --> Parser Class Initialized
INFO - 2023-12-15 19:23:13 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-12-15 19:23:13 --> Pagination Class Initialized
INFO - 2023-12-15 19:23:13 --> Form Validation Class Initialized
INFO - 2023-12-15 19:23:13 --> Controller Class Initialized
INFO - 2023-12-15 19:23:13 --> Model Class Initialized
DEBUG - 2023-12-15 19:23:13 --> Session class already loaded. Second attempt ignored.
