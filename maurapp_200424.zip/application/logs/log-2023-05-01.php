<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2023-05-01 10:41:29 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-01 10:41:29 --> Config Class Initialized
INFO - 2023-05-01 10:41:29 --> Hooks Class Initialized
DEBUG - 2023-05-01 10:41:29 --> UTF-8 Support Enabled
INFO - 2023-05-01 10:41:29 --> Utf8 Class Initialized
INFO - 2023-05-01 10:41:29 --> URI Class Initialized
DEBUG - 2023-05-01 10:41:29 --> No URI present. Default controller set.
INFO - 2023-05-01 10:41:29 --> Router Class Initialized
INFO - 2023-05-01 10:41:29 --> Output Class Initialized
INFO - 2023-05-01 10:41:29 --> Security Class Initialized
DEBUG - 2023-05-01 10:41:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-01 10:41:29 --> Input Class Initialized
INFO - 2023-05-01 10:41:29 --> Language Class Initialized
INFO - 2023-05-01 10:41:29 --> Loader Class Initialized
INFO - 2023-05-01 10:41:29 --> Helper loaded: url_helper
INFO - 2023-05-01 10:41:29 --> Helper loaded: file_helper
INFO - 2023-05-01 10:41:29 --> Helper loaded: html_helper
INFO - 2023-05-01 10:41:29 --> Helper loaded: text_helper
INFO - 2023-05-01 10:41:29 --> Helper loaded: form_helper
INFO - 2023-05-01 10:41:29 --> Helper loaded: lang_helper
INFO - 2023-05-01 10:41:29 --> Helper loaded: security_helper
INFO - 2023-05-01 10:41:29 --> Helper loaded: cookie_helper
INFO - 2023-05-01 10:41:29 --> Database Driver Class Initialized
INFO - 2023-05-01 10:41:29 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-01 10:41:29 --> Parser Class Initialized
INFO - 2023-05-01 10:41:29 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-01 10:41:29 --> Pagination Class Initialized
INFO - 2023-05-01 10:41:29 --> Form Validation Class Initialized
INFO - 2023-05-01 10:41:29 --> Controller Class Initialized
INFO - 2023-05-01 10:41:29 --> Model Class Initialized
DEBUG - 2023-05-01 10:41:29 --> Session class already loaded. Second attempt ignored.
ERROR - 2023-05-01 10:41:29 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-01 10:41:29 --> Config Class Initialized
INFO - 2023-05-01 10:41:29 --> Hooks Class Initialized
DEBUG - 2023-05-01 10:41:29 --> UTF-8 Support Enabled
INFO - 2023-05-01 10:41:29 --> Utf8 Class Initialized
INFO - 2023-05-01 10:41:29 --> URI Class Initialized
INFO - 2023-05-01 10:41:29 --> Router Class Initialized
INFO - 2023-05-01 10:41:29 --> Output Class Initialized
INFO - 2023-05-01 10:41:29 --> Security Class Initialized
DEBUG - 2023-05-01 10:41:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-01 10:41:29 --> Input Class Initialized
INFO - 2023-05-01 10:41:29 --> Language Class Initialized
INFO - 2023-05-01 10:41:29 --> Loader Class Initialized
INFO - 2023-05-01 10:41:29 --> Helper loaded: url_helper
INFO - 2023-05-01 10:41:29 --> Helper loaded: file_helper
INFO - 2023-05-01 10:41:29 --> Helper loaded: html_helper
INFO - 2023-05-01 10:41:29 --> Helper loaded: text_helper
INFO - 2023-05-01 10:41:29 --> Helper loaded: form_helper
INFO - 2023-05-01 10:41:29 --> Helper loaded: lang_helper
INFO - 2023-05-01 10:41:29 --> Helper loaded: security_helper
INFO - 2023-05-01 10:41:29 --> Helper loaded: cookie_helper
INFO - 2023-05-01 10:41:29 --> Database Driver Class Initialized
INFO - 2023-05-01 10:41:29 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-01 10:41:29 --> Parser Class Initialized
INFO - 2023-05-01 10:41:29 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-01 10:41:29 --> Pagination Class Initialized
INFO - 2023-05-01 10:41:29 --> Form Validation Class Initialized
INFO - 2023-05-01 10:41:29 --> Controller Class Initialized
INFO - 2023-05-01 10:41:29 --> Model Class Initialized
DEBUG - 2023-05-01 10:41:29 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-01 10:41:29 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2023-05-01 10:41:29 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-05-01 10:41:29 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-05-01 10:41:29 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-05-01 10:41:29 --> Model Class Initialized
INFO - 2023-05-01 10:41:29 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-05-01 10:41:29 --> Final output sent to browser
DEBUG - 2023-05-01 10:41:29 --> Total execution time: 0.0322
ERROR - 2023-05-01 10:41:45 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-01 10:41:45 --> Config Class Initialized
INFO - 2023-05-01 10:41:45 --> Hooks Class Initialized
DEBUG - 2023-05-01 10:41:45 --> UTF-8 Support Enabled
INFO - 2023-05-01 10:41:45 --> Utf8 Class Initialized
INFO - 2023-05-01 10:41:45 --> URI Class Initialized
INFO - 2023-05-01 10:41:45 --> Router Class Initialized
INFO - 2023-05-01 10:41:45 --> Output Class Initialized
INFO - 2023-05-01 10:41:45 --> Security Class Initialized
DEBUG - 2023-05-01 10:41:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-01 10:41:45 --> Input Class Initialized
INFO - 2023-05-01 10:41:45 --> Language Class Initialized
INFO - 2023-05-01 10:41:45 --> Loader Class Initialized
INFO - 2023-05-01 10:41:45 --> Helper loaded: url_helper
INFO - 2023-05-01 10:41:45 --> Helper loaded: file_helper
INFO - 2023-05-01 10:41:45 --> Helper loaded: html_helper
INFO - 2023-05-01 10:41:45 --> Helper loaded: text_helper
INFO - 2023-05-01 10:41:45 --> Helper loaded: form_helper
INFO - 2023-05-01 10:41:45 --> Helper loaded: lang_helper
INFO - 2023-05-01 10:41:45 --> Helper loaded: security_helper
INFO - 2023-05-01 10:41:45 --> Helper loaded: cookie_helper
INFO - 2023-05-01 10:41:45 --> Database Driver Class Initialized
INFO - 2023-05-01 10:41:45 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-01 10:41:45 --> Parser Class Initialized
INFO - 2023-05-01 10:41:45 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-01 10:41:45 --> Pagination Class Initialized
INFO - 2023-05-01 10:41:45 --> Form Validation Class Initialized
INFO - 2023-05-01 10:41:45 --> Controller Class Initialized
INFO - 2023-05-01 10:41:45 --> Model Class Initialized
DEBUG - 2023-05-01 10:41:45 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-01 10:41:45 --> Model Class Initialized
INFO - 2023-05-01 10:41:45 --> Final output sent to browser
DEBUG - 2023-05-01 10:41:45 --> Total execution time: 0.0195
ERROR - 2023-05-01 10:41:45 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-01 10:41:45 --> Config Class Initialized
INFO - 2023-05-01 10:41:45 --> Hooks Class Initialized
DEBUG - 2023-05-01 10:41:45 --> UTF-8 Support Enabled
INFO - 2023-05-01 10:41:45 --> Utf8 Class Initialized
INFO - 2023-05-01 10:41:45 --> URI Class Initialized
DEBUG - 2023-05-01 10:41:45 --> No URI present. Default controller set.
INFO - 2023-05-01 10:41:45 --> Router Class Initialized
INFO - 2023-05-01 10:41:45 --> Output Class Initialized
INFO - 2023-05-01 10:41:45 --> Security Class Initialized
DEBUG - 2023-05-01 10:41:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-01 10:41:45 --> Input Class Initialized
INFO - 2023-05-01 10:41:45 --> Language Class Initialized
INFO - 2023-05-01 10:41:45 --> Loader Class Initialized
INFO - 2023-05-01 10:41:45 --> Helper loaded: url_helper
INFO - 2023-05-01 10:41:45 --> Helper loaded: file_helper
INFO - 2023-05-01 10:41:45 --> Helper loaded: html_helper
INFO - 2023-05-01 10:41:45 --> Helper loaded: text_helper
INFO - 2023-05-01 10:41:45 --> Helper loaded: form_helper
INFO - 2023-05-01 10:41:45 --> Helper loaded: lang_helper
INFO - 2023-05-01 10:41:45 --> Helper loaded: security_helper
INFO - 2023-05-01 10:41:45 --> Helper loaded: cookie_helper
INFO - 2023-05-01 10:41:45 --> Database Driver Class Initialized
INFO - 2023-05-01 10:41:45 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-01 10:41:45 --> Parser Class Initialized
INFO - 2023-05-01 10:41:45 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-01 10:41:45 --> Pagination Class Initialized
INFO - 2023-05-01 10:41:45 --> Form Validation Class Initialized
INFO - 2023-05-01 10:41:45 --> Controller Class Initialized
INFO - 2023-05-01 10:41:45 --> Model Class Initialized
DEBUG - 2023-05-01 10:41:45 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-01 10:41:45 --> Model Class Initialized
DEBUG - 2023-05-01 10:41:45 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-01 10:41:45 --> Model Class Initialized
INFO - 2023-05-01 10:41:45 --> Model Class Initialized
INFO - 2023-05-01 10:41:45 --> Model Class Initialized
INFO - 2023-05-01 10:41:45 --> Model Class Initialized
DEBUG - 2023-05-01 10:41:45 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-05-01 10:41:45 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-01 10:41:45 --> Model Class Initialized
INFO - 2023-05-01 10:41:45 --> Model Class Initialized
INFO - 2023-05-01 10:41:45 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-05-01 10:41:45 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-05-01 10:41:45 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-05-01 10:41:45 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-05-01 10:41:45 --> Model Class Initialized
INFO - 2023-05-01 10:41:45 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-05-01 10:41:45 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-05-01 10:41:45 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-05-01 10:41:45 --> Final output sent to browser
DEBUG - 2023-05-01 10:41:45 --> Total execution time: 0.1760
ERROR - 2023-05-01 10:41:46 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-01 10:41:46 --> Config Class Initialized
INFO - 2023-05-01 10:41:46 --> Hooks Class Initialized
DEBUG - 2023-05-01 10:41:46 --> UTF-8 Support Enabled
INFO - 2023-05-01 10:41:46 --> Utf8 Class Initialized
INFO - 2023-05-01 10:41:46 --> URI Class Initialized
INFO - 2023-05-01 10:41:46 --> Router Class Initialized
INFO - 2023-05-01 10:41:46 --> Output Class Initialized
INFO - 2023-05-01 10:41:46 --> Security Class Initialized
DEBUG - 2023-05-01 10:41:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-01 10:41:46 --> Input Class Initialized
INFO - 2023-05-01 10:41:46 --> Language Class Initialized
INFO - 2023-05-01 10:41:46 --> Loader Class Initialized
INFO - 2023-05-01 10:41:46 --> Helper loaded: url_helper
INFO - 2023-05-01 10:41:46 --> Helper loaded: file_helper
INFO - 2023-05-01 10:41:46 --> Helper loaded: html_helper
INFO - 2023-05-01 10:41:46 --> Helper loaded: text_helper
INFO - 2023-05-01 10:41:46 --> Helper loaded: form_helper
INFO - 2023-05-01 10:41:46 --> Helper loaded: lang_helper
INFO - 2023-05-01 10:41:46 --> Helper loaded: security_helper
INFO - 2023-05-01 10:41:46 --> Helper loaded: cookie_helper
INFO - 2023-05-01 10:41:46 --> Database Driver Class Initialized
INFO - 2023-05-01 10:41:46 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-01 10:41:46 --> Parser Class Initialized
INFO - 2023-05-01 10:41:46 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-01 10:41:46 --> Pagination Class Initialized
INFO - 2023-05-01 10:41:46 --> Form Validation Class Initialized
INFO - 2023-05-01 10:41:46 --> Controller Class Initialized
DEBUG - 2023-05-01 10:41:46 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-05-01 10:41:46 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-01 10:41:46 --> Model Class Initialized
INFO - 2023-05-01 10:41:46 --> Final output sent to browser
DEBUG - 2023-05-01 10:41:46 --> Total execution time: 0.0132
ERROR - 2023-05-01 10:42:02 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-01 10:42:02 --> Config Class Initialized
INFO - 2023-05-01 10:42:02 --> Hooks Class Initialized
DEBUG - 2023-05-01 10:42:02 --> UTF-8 Support Enabled
INFO - 2023-05-01 10:42:02 --> Utf8 Class Initialized
INFO - 2023-05-01 10:42:02 --> URI Class Initialized
INFO - 2023-05-01 10:42:02 --> Router Class Initialized
INFO - 2023-05-01 10:42:02 --> Output Class Initialized
INFO - 2023-05-01 10:42:02 --> Security Class Initialized
DEBUG - 2023-05-01 10:42:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-01 10:42:02 --> Input Class Initialized
INFO - 2023-05-01 10:42:02 --> Language Class Initialized
INFO - 2023-05-01 10:42:02 --> Loader Class Initialized
INFO - 2023-05-01 10:42:02 --> Helper loaded: url_helper
INFO - 2023-05-01 10:42:02 --> Helper loaded: file_helper
INFO - 2023-05-01 10:42:02 --> Helper loaded: html_helper
INFO - 2023-05-01 10:42:02 --> Helper loaded: text_helper
INFO - 2023-05-01 10:42:02 --> Helper loaded: form_helper
INFO - 2023-05-01 10:42:02 --> Helper loaded: lang_helper
INFO - 2023-05-01 10:42:02 --> Helper loaded: security_helper
INFO - 2023-05-01 10:42:02 --> Helper loaded: cookie_helper
INFO - 2023-05-01 10:42:02 --> Database Driver Class Initialized
INFO - 2023-05-01 10:42:02 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-01 10:42:02 --> Parser Class Initialized
INFO - 2023-05-01 10:42:02 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-01 10:42:02 --> Pagination Class Initialized
INFO - 2023-05-01 10:42:02 --> Form Validation Class Initialized
INFO - 2023-05-01 10:42:02 --> Controller Class Initialized
INFO - 2023-05-01 10:42:02 --> Model Class Initialized
INFO - 2023-05-01 10:42:02 --> Model Class Initialized
INFO - 2023-05-01 10:42:02 --> Model Class Initialized
INFO - 2023-05-01 10:42:02 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/report/stock_report_batch_wise.php
DEBUG - 2023-05-01 10:42:02 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-05-01 10:42:02 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-05-01 10:42:02 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-05-01 10:42:02 --> Model Class Initialized
INFO - 2023-05-01 10:42:02 --> Model Class Initialized
INFO - 2023-05-01 10:42:03 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-05-01 10:42:03 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-05-01 10:42:03 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-05-01 10:42:03 --> Final output sent to browser
DEBUG - 2023-05-01 10:42:03 --> Total execution time: 0.1490
ERROR - 2023-05-01 10:42:03 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-01 10:42:03 --> Config Class Initialized
INFO - 2023-05-01 10:42:03 --> Hooks Class Initialized
DEBUG - 2023-05-01 10:42:03 --> UTF-8 Support Enabled
INFO - 2023-05-01 10:42:03 --> Utf8 Class Initialized
INFO - 2023-05-01 10:42:03 --> URI Class Initialized
INFO - 2023-05-01 10:42:03 --> Router Class Initialized
INFO - 2023-05-01 10:42:03 --> Output Class Initialized
INFO - 2023-05-01 10:42:03 --> Security Class Initialized
DEBUG - 2023-05-01 10:42:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-01 10:42:03 --> Input Class Initialized
INFO - 2023-05-01 10:42:03 --> Language Class Initialized
INFO - 2023-05-01 10:42:03 --> Loader Class Initialized
INFO - 2023-05-01 10:42:03 --> Helper loaded: url_helper
INFO - 2023-05-01 10:42:03 --> Helper loaded: file_helper
INFO - 2023-05-01 10:42:03 --> Helper loaded: html_helper
INFO - 2023-05-01 10:42:03 --> Helper loaded: text_helper
INFO - 2023-05-01 10:42:03 --> Helper loaded: form_helper
INFO - 2023-05-01 10:42:03 --> Helper loaded: lang_helper
INFO - 2023-05-01 10:42:03 --> Helper loaded: security_helper
INFO - 2023-05-01 10:42:03 --> Helper loaded: cookie_helper
INFO - 2023-05-01 10:42:03 --> Database Driver Class Initialized
INFO - 2023-05-01 10:42:03 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-01 10:42:03 --> Parser Class Initialized
INFO - 2023-05-01 10:42:03 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-01 10:42:03 --> Pagination Class Initialized
INFO - 2023-05-01 10:42:03 --> Form Validation Class Initialized
INFO - 2023-05-01 10:42:03 --> Controller Class Initialized
INFO - 2023-05-01 10:42:03 --> Model Class Initialized
INFO - 2023-05-01 10:42:03 --> Model Class Initialized
INFO - 2023-05-01 10:42:03 --> Final output sent to browser
DEBUG - 2023-05-01 10:42:03 --> Total execution time: 0.0213
ERROR - 2023-05-01 10:42:09 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-01 10:42:09 --> Config Class Initialized
INFO - 2023-05-01 10:42:09 --> Hooks Class Initialized
DEBUG - 2023-05-01 10:42:09 --> UTF-8 Support Enabled
INFO - 2023-05-01 10:42:09 --> Utf8 Class Initialized
INFO - 2023-05-01 10:42:09 --> URI Class Initialized
INFO - 2023-05-01 10:42:09 --> Router Class Initialized
INFO - 2023-05-01 10:42:09 --> Output Class Initialized
INFO - 2023-05-01 10:42:09 --> Security Class Initialized
DEBUG - 2023-05-01 10:42:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-01 10:42:09 --> Input Class Initialized
INFO - 2023-05-01 10:42:09 --> Language Class Initialized
INFO - 2023-05-01 10:42:09 --> Loader Class Initialized
INFO - 2023-05-01 10:42:09 --> Helper loaded: url_helper
INFO - 2023-05-01 10:42:09 --> Helper loaded: file_helper
INFO - 2023-05-01 10:42:09 --> Helper loaded: html_helper
INFO - 2023-05-01 10:42:09 --> Helper loaded: text_helper
INFO - 2023-05-01 10:42:09 --> Helper loaded: form_helper
INFO - 2023-05-01 10:42:09 --> Helper loaded: lang_helper
INFO - 2023-05-01 10:42:09 --> Helper loaded: security_helper
INFO - 2023-05-01 10:42:09 --> Helper loaded: cookie_helper
INFO - 2023-05-01 10:42:09 --> Database Driver Class Initialized
INFO - 2023-05-01 10:42:09 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-01 10:42:09 --> Parser Class Initialized
INFO - 2023-05-01 10:42:09 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-01 10:42:09 --> Pagination Class Initialized
INFO - 2023-05-01 10:42:09 --> Form Validation Class Initialized
INFO - 2023-05-01 10:42:09 --> Controller Class Initialized
INFO - 2023-05-01 10:42:09 --> Model Class Initialized
INFO - 2023-05-01 10:42:09 --> Model Class Initialized
INFO - 2023-05-01 10:42:09 --> Final output sent to browser
DEBUG - 2023-05-01 10:42:09 --> Total execution time: 0.0302
ERROR - 2023-05-01 10:45:48 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-01 10:45:48 --> Config Class Initialized
INFO - 2023-05-01 10:45:48 --> Hooks Class Initialized
DEBUG - 2023-05-01 10:45:48 --> UTF-8 Support Enabled
INFO - 2023-05-01 10:45:48 --> Utf8 Class Initialized
INFO - 2023-05-01 10:45:48 --> URI Class Initialized
INFO - 2023-05-01 10:45:48 --> Router Class Initialized
INFO - 2023-05-01 10:45:48 --> Output Class Initialized
INFO - 2023-05-01 10:45:48 --> Security Class Initialized
DEBUG - 2023-05-01 10:45:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-01 10:45:48 --> Input Class Initialized
INFO - 2023-05-01 10:45:48 --> Language Class Initialized
INFO - 2023-05-01 10:45:48 --> Loader Class Initialized
INFO - 2023-05-01 10:45:48 --> Helper loaded: url_helper
INFO - 2023-05-01 10:45:48 --> Helper loaded: file_helper
INFO - 2023-05-01 10:45:48 --> Helper loaded: html_helper
INFO - 2023-05-01 10:45:48 --> Helper loaded: text_helper
INFO - 2023-05-01 10:45:48 --> Helper loaded: form_helper
INFO - 2023-05-01 10:45:48 --> Helper loaded: lang_helper
INFO - 2023-05-01 10:45:48 --> Helper loaded: security_helper
INFO - 2023-05-01 10:45:48 --> Helper loaded: cookie_helper
INFO - 2023-05-01 10:45:48 --> Database Driver Class Initialized
INFO - 2023-05-01 10:45:48 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-01 10:45:48 --> Parser Class Initialized
INFO - 2023-05-01 10:45:48 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-01 10:45:48 --> Pagination Class Initialized
INFO - 2023-05-01 10:45:48 --> Form Validation Class Initialized
INFO - 2023-05-01 10:45:48 --> Controller Class Initialized
INFO - 2023-05-01 10:45:48 --> Model Class Initialized
INFO - 2023-05-01 10:45:48 --> Model Class Initialized
INFO - 2023-05-01 10:45:48 --> Model Class Initialized
INFO - 2023-05-01 10:45:48 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/report/stock_report_batch_wise.php
DEBUG - 2023-05-01 10:45:48 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-05-01 10:45:48 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-05-01 10:45:48 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-05-01 10:45:48 --> Model Class Initialized
INFO - 2023-05-01 10:45:48 --> Model Class Initialized
INFO - 2023-05-01 10:45:48 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-05-01 10:45:48 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-05-01 10:45:48 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-05-01 10:45:48 --> Final output sent to browser
DEBUG - 2023-05-01 10:45:48 --> Total execution time: 0.1555
ERROR - 2023-05-01 10:46:00 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-01 10:46:00 --> Config Class Initialized
INFO - 2023-05-01 10:46:00 --> Hooks Class Initialized
DEBUG - 2023-05-01 10:46:00 --> UTF-8 Support Enabled
INFO - 2023-05-01 10:46:00 --> Utf8 Class Initialized
INFO - 2023-05-01 10:46:00 --> URI Class Initialized
INFO - 2023-05-01 10:46:00 --> Router Class Initialized
INFO - 2023-05-01 10:46:00 --> Output Class Initialized
INFO - 2023-05-01 10:46:00 --> Security Class Initialized
DEBUG - 2023-05-01 10:46:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-01 10:46:00 --> Input Class Initialized
INFO - 2023-05-01 10:46:00 --> Language Class Initialized
INFO - 2023-05-01 10:46:00 --> Loader Class Initialized
INFO - 2023-05-01 10:46:00 --> Helper loaded: url_helper
INFO - 2023-05-01 10:46:00 --> Helper loaded: file_helper
INFO - 2023-05-01 10:46:00 --> Helper loaded: html_helper
INFO - 2023-05-01 10:46:00 --> Helper loaded: text_helper
INFO - 2023-05-01 10:46:00 --> Helper loaded: form_helper
INFO - 2023-05-01 10:46:00 --> Helper loaded: lang_helper
INFO - 2023-05-01 10:46:00 --> Helper loaded: security_helper
INFO - 2023-05-01 10:46:00 --> Helper loaded: cookie_helper
INFO - 2023-05-01 10:46:00 --> Database Driver Class Initialized
INFO - 2023-05-01 10:46:00 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-01 10:46:00 --> Parser Class Initialized
INFO - 2023-05-01 10:46:00 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-01 10:46:00 --> Pagination Class Initialized
INFO - 2023-05-01 10:46:00 --> Form Validation Class Initialized
INFO - 2023-05-01 10:46:00 --> Controller Class Initialized
INFO - 2023-05-01 10:46:00 --> Model Class Initialized
INFO - 2023-05-01 10:46:00 --> Model Class Initialized
INFO - 2023-05-01 10:46:00 --> Final output sent to browser
DEBUG - 2023-05-01 10:46:00 --> Total execution time: 0.0238
ERROR - 2023-05-01 10:46:17 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-01 10:46:17 --> Config Class Initialized
INFO - 2023-05-01 10:46:17 --> Hooks Class Initialized
DEBUG - 2023-05-01 10:46:17 --> UTF-8 Support Enabled
INFO - 2023-05-01 10:46:17 --> Utf8 Class Initialized
INFO - 2023-05-01 10:46:17 --> URI Class Initialized
INFO - 2023-05-01 10:46:17 --> Router Class Initialized
INFO - 2023-05-01 10:46:17 --> Output Class Initialized
INFO - 2023-05-01 10:46:17 --> Security Class Initialized
DEBUG - 2023-05-01 10:46:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-01 10:46:17 --> Input Class Initialized
INFO - 2023-05-01 10:46:17 --> Language Class Initialized
INFO - 2023-05-01 10:46:17 --> Loader Class Initialized
INFO - 2023-05-01 10:46:17 --> Helper loaded: url_helper
INFO - 2023-05-01 10:46:17 --> Helper loaded: file_helper
INFO - 2023-05-01 10:46:17 --> Helper loaded: html_helper
INFO - 2023-05-01 10:46:17 --> Helper loaded: text_helper
INFO - 2023-05-01 10:46:17 --> Helper loaded: form_helper
INFO - 2023-05-01 10:46:17 --> Helper loaded: lang_helper
INFO - 2023-05-01 10:46:17 --> Helper loaded: security_helper
INFO - 2023-05-01 10:46:17 --> Helper loaded: cookie_helper
INFO - 2023-05-01 10:46:17 --> Database Driver Class Initialized
INFO - 2023-05-01 10:46:17 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-01 10:46:17 --> Parser Class Initialized
INFO - 2023-05-01 10:46:17 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-01 10:46:17 --> Pagination Class Initialized
INFO - 2023-05-01 10:46:17 --> Form Validation Class Initialized
INFO - 2023-05-01 10:46:17 --> Controller Class Initialized
DEBUG - 2023-05-01 10:46:17 --> Auth class already loaded. Second attempt ignored.
INFO - 2023-05-01 10:46:17 --> Model Class Initialized
INFO - 2023-05-01 10:46:17 --> Model Class Initialized
INFO - 2023-05-01 10:46:17 --> Model Class Initialized
INFO - 2023-05-01 10:46:17 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/product/product_details.php
DEBUG - 2023-05-01 10:46:17 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-05-01 10:46:17 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-05-01 10:46:17 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-05-01 10:46:17 --> Model Class Initialized
INFO - 2023-05-01 10:46:17 --> Model Class Initialized
INFO - 2023-05-01 10:46:17 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-05-01 10:46:17 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-05-01 10:46:17 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-05-01 10:46:17 --> Final output sent to browser
DEBUG - 2023-05-01 10:46:17 --> Total execution time: 0.1656
ERROR - 2023-05-01 10:48:36 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-01 10:48:36 --> Config Class Initialized
INFO - 2023-05-01 10:48:36 --> Hooks Class Initialized
DEBUG - 2023-05-01 10:48:36 --> UTF-8 Support Enabled
INFO - 2023-05-01 10:48:36 --> Utf8 Class Initialized
INFO - 2023-05-01 10:48:36 --> URI Class Initialized
DEBUG - 2023-05-01 10:48:36 --> No URI present. Default controller set.
INFO - 2023-05-01 10:48:36 --> Router Class Initialized
INFO - 2023-05-01 10:48:36 --> Output Class Initialized
INFO - 2023-05-01 10:48:36 --> Security Class Initialized
DEBUG - 2023-05-01 10:48:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-01 10:48:36 --> Input Class Initialized
INFO - 2023-05-01 10:48:36 --> Language Class Initialized
INFO - 2023-05-01 10:48:36 --> Loader Class Initialized
INFO - 2023-05-01 10:48:36 --> Helper loaded: url_helper
INFO - 2023-05-01 10:48:36 --> Helper loaded: file_helper
INFO - 2023-05-01 10:48:36 --> Helper loaded: html_helper
INFO - 2023-05-01 10:48:36 --> Helper loaded: text_helper
INFO - 2023-05-01 10:48:36 --> Helper loaded: form_helper
INFO - 2023-05-01 10:48:36 --> Helper loaded: lang_helper
INFO - 2023-05-01 10:48:36 --> Helper loaded: security_helper
INFO - 2023-05-01 10:48:36 --> Helper loaded: cookie_helper
INFO - 2023-05-01 10:48:36 --> Database Driver Class Initialized
INFO - 2023-05-01 10:48:36 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-01 10:48:36 --> Parser Class Initialized
INFO - 2023-05-01 10:48:36 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-01 10:48:36 --> Pagination Class Initialized
INFO - 2023-05-01 10:48:36 --> Form Validation Class Initialized
INFO - 2023-05-01 10:48:36 --> Controller Class Initialized
INFO - 2023-05-01 10:48:36 --> Model Class Initialized
DEBUG - 2023-05-01 10:48:36 --> Session class already loaded. Second attempt ignored.
ERROR - 2023-05-01 10:48:37 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-01 10:48:37 --> Config Class Initialized
INFO - 2023-05-01 10:48:37 --> Hooks Class Initialized
DEBUG - 2023-05-01 10:48:37 --> UTF-8 Support Enabled
INFO - 2023-05-01 10:48:37 --> Utf8 Class Initialized
INFO - 2023-05-01 10:48:37 --> URI Class Initialized
INFO - 2023-05-01 10:48:37 --> Router Class Initialized
INFO - 2023-05-01 10:48:37 --> Output Class Initialized
INFO - 2023-05-01 10:48:37 --> Security Class Initialized
DEBUG - 2023-05-01 10:48:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-01 10:48:37 --> Input Class Initialized
INFO - 2023-05-01 10:48:37 --> Language Class Initialized
INFO - 2023-05-01 10:48:37 --> Loader Class Initialized
INFO - 2023-05-01 10:48:37 --> Helper loaded: url_helper
INFO - 2023-05-01 10:48:37 --> Helper loaded: file_helper
INFO - 2023-05-01 10:48:37 --> Helper loaded: html_helper
INFO - 2023-05-01 10:48:37 --> Helper loaded: text_helper
INFO - 2023-05-01 10:48:37 --> Helper loaded: form_helper
INFO - 2023-05-01 10:48:37 --> Helper loaded: lang_helper
INFO - 2023-05-01 10:48:37 --> Helper loaded: security_helper
INFO - 2023-05-01 10:48:37 --> Helper loaded: cookie_helper
INFO - 2023-05-01 10:48:37 --> Database Driver Class Initialized
INFO - 2023-05-01 10:48:37 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-01 10:48:37 --> Parser Class Initialized
INFO - 2023-05-01 10:48:37 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-01 10:48:37 --> Pagination Class Initialized
INFO - 2023-05-01 10:48:37 --> Form Validation Class Initialized
INFO - 2023-05-01 10:48:37 --> Controller Class Initialized
INFO - 2023-05-01 10:48:37 --> Model Class Initialized
DEBUG - 2023-05-01 10:48:37 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-01 10:48:37 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2023-05-01 10:48:37 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-05-01 10:48:37 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-05-01 10:48:37 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-05-01 10:48:37 --> Model Class Initialized
INFO - 2023-05-01 10:48:37 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-05-01 10:48:37 --> Final output sent to browser
DEBUG - 2023-05-01 10:48:37 --> Total execution time: 0.0368
ERROR - 2023-05-01 10:49:44 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-01 10:49:44 --> Config Class Initialized
INFO - 2023-05-01 10:49:44 --> Hooks Class Initialized
DEBUG - 2023-05-01 10:49:44 --> UTF-8 Support Enabled
INFO - 2023-05-01 10:49:44 --> Utf8 Class Initialized
INFO - 2023-05-01 10:49:44 --> URI Class Initialized
DEBUG - 2023-05-01 10:49:44 --> No URI present. Default controller set.
INFO - 2023-05-01 10:49:44 --> Router Class Initialized
INFO - 2023-05-01 10:49:44 --> Output Class Initialized
INFO - 2023-05-01 10:49:44 --> Security Class Initialized
DEBUG - 2023-05-01 10:49:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-01 10:49:44 --> Input Class Initialized
INFO - 2023-05-01 10:49:44 --> Language Class Initialized
INFO - 2023-05-01 10:49:44 --> Loader Class Initialized
INFO - 2023-05-01 10:49:44 --> Helper loaded: url_helper
INFO - 2023-05-01 10:49:44 --> Helper loaded: file_helper
INFO - 2023-05-01 10:49:44 --> Helper loaded: html_helper
INFO - 2023-05-01 10:49:44 --> Helper loaded: text_helper
INFO - 2023-05-01 10:49:44 --> Helper loaded: form_helper
INFO - 2023-05-01 10:49:44 --> Helper loaded: lang_helper
INFO - 2023-05-01 10:49:44 --> Helper loaded: security_helper
INFO - 2023-05-01 10:49:44 --> Helper loaded: cookie_helper
INFO - 2023-05-01 10:49:44 --> Database Driver Class Initialized
INFO - 2023-05-01 10:49:44 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-01 10:49:44 --> Parser Class Initialized
INFO - 2023-05-01 10:49:44 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-01 10:49:44 --> Pagination Class Initialized
INFO - 2023-05-01 10:49:44 --> Form Validation Class Initialized
INFO - 2023-05-01 10:49:44 --> Controller Class Initialized
INFO - 2023-05-01 10:49:44 --> Model Class Initialized
DEBUG - 2023-05-01 10:49:44 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-01 10:49:44 --> Model Class Initialized
DEBUG - 2023-05-01 10:49:44 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-01 10:49:44 --> Model Class Initialized
INFO - 2023-05-01 10:49:44 --> Model Class Initialized
INFO - 2023-05-01 10:49:44 --> Model Class Initialized
INFO - 2023-05-01 10:49:44 --> Model Class Initialized
DEBUG - 2023-05-01 10:49:44 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-05-01 10:49:44 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-01 10:49:44 --> Model Class Initialized
INFO - 2023-05-01 10:49:44 --> Model Class Initialized
INFO - 2023-05-01 10:49:44 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-05-01 10:49:44 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-05-01 10:49:44 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-05-01 10:49:44 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-05-01 10:49:44 --> Model Class Initialized
INFO - 2023-05-01 10:49:45 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-05-01 10:49:45 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-05-01 10:49:45 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-05-01 10:49:45 --> Final output sent to browser
DEBUG - 2023-05-01 10:49:45 --> Total execution time: 0.1860
ERROR - 2023-05-01 10:50:51 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-01 10:50:51 --> Config Class Initialized
INFO - 2023-05-01 10:50:51 --> Hooks Class Initialized
DEBUG - 2023-05-01 10:50:51 --> UTF-8 Support Enabled
INFO - 2023-05-01 10:50:51 --> Utf8 Class Initialized
INFO - 2023-05-01 10:50:51 --> URI Class Initialized
INFO - 2023-05-01 10:50:51 --> Router Class Initialized
INFO - 2023-05-01 10:50:51 --> Output Class Initialized
INFO - 2023-05-01 10:50:51 --> Security Class Initialized
DEBUG - 2023-05-01 10:50:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-01 10:50:51 --> Input Class Initialized
INFO - 2023-05-01 10:50:51 --> Language Class Initialized
INFO - 2023-05-01 10:50:51 --> Loader Class Initialized
INFO - 2023-05-01 10:50:51 --> Helper loaded: url_helper
INFO - 2023-05-01 10:50:51 --> Helper loaded: file_helper
INFO - 2023-05-01 10:50:51 --> Helper loaded: html_helper
INFO - 2023-05-01 10:50:51 --> Helper loaded: text_helper
INFO - 2023-05-01 10:50:51 --> Helper loaded: form_helper
INFO - 2023-05-01 10:50:51 --> Helper loaded: lang_helper
INFO - 2023-05-01 10:50:51 --> Helper loaded: security_helper
INFO - 2023-05-01 10:50:51 --> Helper loaded: cookie_helper
INFO - 2023-05-01 10:50:51 --> Database Driver Class Initialized
INFO - 2023-05-01 10:50:51 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-01 10:50:51 --> Parser Class Initialized
INFO - 2023-05-01 10:50:51 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-01 10:50:51 --> Pagination Class Initialized
INFO - 2023-05-01 10:50:51 --> Form Validation Class Initialized
INFO - 2023-05-01 10:50:51 --> Controller Class Initialized
INFO - 2023-05-01 10:50:51 --> Model Class Initialized
DEBUG - 2023-05-01 10:50:51 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-05-01 10:50:51 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-01 10:50:51 --> Model Class Initialized
DEBUG - 2023-05-01 10:50:51 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-01 10:50:51 --> Model Class Initialized
INFO - 2023-05-01 10:50:52 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice.php
DEBUG - 2023-05-01 10:50:52 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-05-01 10:50:52 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-05-01 10:50:52 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-05-01 10:50:52 --> Model Class Initialized
INFO - 2023-05-01 10:50:52 --> Model Class Initialized
INFO - 2023-05-01 10:50:52 --> Model Class Initialized
INFO - 2023-05-01 10:50:52 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-05-01 10:50:52 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-05-01 10:50:52 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-05-01 10:50:52 --> Final output sent to browser
DEBUG - 2023-05-01 10:50:52 --> Total execution time: 0.1445
ERROR - 2023-05-01 10:50:52 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-01 10:50:52 --> Config Class Initialized
INFO - 2023-05-01 10:50:52 --> Hooks Class Initialized
DEBUG - 2023-05-01 10:50:52 --> UTF-8 Support Enabled
INFO - 2023-05-01 10:50:52 --> Utf8 Class Initialized
INFO - 2023-05-01 10:50:52 --> URI Class Initialized
INFO - 2023-05-01 10:50:52 --> Router Class Initialized
INFO - 2023-05-01 10:50:52 --> Output Class Initialized
INFO - 2023-05-01 10:50:52 --> Security Class Initialized
DEBUG - 2023-05-01 10:50:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-01 10:50:52 --> Input Class Initialized
INFO - 2023-05-01 10:50:52 --> Language Class Initialized
INFO - 2023-05-01 10:50:52 --> Loader Class Initialized
INFO - 2023-05-01 10:50:52 --> Helper loaded: url_helper
INFO - 2023-05-01 10:50:52 --> Helper loaded: file_helper
INFO - 2023-05-01 10:50:52 --> Helper loaded: html_helper
INFO - 2023-05-01 10:50:52 --> Helper loaded: text_helper
INFO - 2023-05-01 10:50:52 --> Helper loaded: form_helper
INFO - 2023-05-01 10:50:52 --> Helper loaded: lang_helper
INFO - 2023-05-01 10:50:52 --> Helper loaded: security_helper
INFO - 2023-05-01 10:50:52 --> Helper loaded: cookie_helper
INFO - 2023-05-01 10:50:52 --> Database Driver Class Initialized
INFO - 2023-05-01 10:50:52 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-01 10:50:52 --> Parser Class Initialized
INFO - 2023-05-01 10:50:52 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-01 10:50:52 --> Pagination Class Initialized
INFO - 2023-05-01 10:50:52 --> Form Validation Class Initialized
INFO - 2023-05-01 10:50:52 --> Controller Class Initialized
INFO - 2023-05-01 10:50:52 --> Model Class Initialized
DEBUG - 2023-05-01 10:50:52 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-05-01 10:50:52 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-01 10:50:52 --> Model Class Initialized
DEBUG - 2023-05-01 10:50:52 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-01 10:50:52 --> Model Class Initialized
INFO - 2023-05-01 10:50:52 --> Final output sent to browser
DEBUG - 2023-05-01 10:50:52 --> Total execution time: 0.0523
ERROR - 2023-05-01 10:51:01 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-01 10:51:01 --> Config Class Initialized
INFO - 2023-05-01 10:51:01 --> Hooks Class Initialized
DEBUG - 2023-05-01 10:51:01 --> UTF-8 Support Enabled
INFO - 2023-05-01 10:51:01 --> Utf8 Class Initialized
INFO - 2023-05-01 10:51:01 --> URI Class Initialized
INFO - 2023-05-01 10:51:01 --> Router Class Initialized
INFO - 2023-05-01 10:51:01 --> Output Class Initialized
INFO - 2023-05-01 10:51:01 --> Security Class Initialized
DEBUG - 2023-05-01 10:51:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-01 10:51:01 --> Input Class Initialized
INFO - 2023-05-01 10:51:01 --> Language Class Initialized
INFO - 2023-05-01 10:51:01 --> Loader Class Initialized
INFO - 2023-05-01 10:51:01 --> Helper loaded: url_helper
INFO - 2023-05-01 10:51:01 --> Helper loaded: file_helper
INFO - 2023-05-01 10:51:01 --> Helper loaded: html_helper
INFO - 2023-05-01 10:51:01 --> Helper loaded: text_helper
INFO - 2023-05-01 10:51:01 --> Helper loaded: form_helper
INFO - 2023-05-01 10:51:01 --> Helper loaded: lang_helper
INFO - 2023-05-01 10:51:01 --> Helper loaded: security_helper
INFO - 2023-05-01 10:51:01 --> Helper loaded: cookie_helper
INFO - 2023-05-01 10:51:01 --> Database Driver Class Initialized
INFO - 2023-05-01 10:51:01 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-01 10:51:01 --> Parser Class Initialized
INFO - 2023-05-01 10:51:01 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-01 10:51:01 --> Pagination Class Initialized
INFO - 2023-05-01 10:51:01 --> Form Validation Class Initialized
INFO - 2023-05-01 10:51:01 --> Controller Class Initialized
INFO - 2023-05-01 10:51:01 --> Model Class Initialized
DEBUG - 2023-05-01 10:51:01 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-05-01 10:51:01 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-01 10:51:01 --> Model Class Initialized
DEBUG - 2023-05-01 10:51:01 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-01 10:51:01 --> Model Class Initialized
INFO - 2023-05-01 10:51:01 --> Final output sent to browser
DEBUG - 2023-05-01 10:51:01 --> Total execution time: 0.0885
ERROR - 2023-05-01 10:51:28 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-01 10:51:28 --> Config Class Initialized
INFO - 2023-05-01 10:51:28 --> Hooks Class Initialized
DEBUG - 2023-05-01 10:51:28 --> UTF-8 Support Enabled
INFO - 2023-05-01 10:51:28 --> Utf8 Class Initialized
INFO - 2023-05-01 10:51:28 --> URI Class Initialized
DEBUG - 2023-05-01 10:51:28 --> No URI present. Default controller set.
INFO - 2023-05-01 10:51:28 --> Router Class Initialized
INFO - 2023-05-01 10:51:28 --> Output Class Initialized
INFO - 2023-05-01 10:51:28 --> Security Class Initialized
DEBUG - 2023-05-01 10:51:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-01 10:51:28 --> Input Class Initialized
INFO - 2023-05-01 10:51:28 --> Language Class Initialized
INFO - 2023-05-01 10:51:28 --> Loader Class Initialized
INFO - 2023-05-01 10:51:28 --> Helper loaded: url_helper
INFO - 2023-05-01 10:51:28 --> Helper loaded: file_helper
INFO - 2023-05-01 10:51:28 --> Helper loaded: html_helper
INFO - 2023-05-01 10:51:28 --> Helper loaded: text_helper
INFO - 2023-05-01 10:51:28 --> Helper loaded: form_helper
INFO - 2023-05-01 10:51:28 --> Helper loaded: lang_helper
INFO - 2023-05-01 10:51:28 --> Helper loaded: security_helper
INFO - 2023-05-01 10:51:28 --> Helper loaded: cookie_helper
INFO - 2023-05-01 10:51:28 --> Database Driver Class Initialized
INFO - 2023-05-01 10:51:28 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-01 10:51:28 --> Parser Class Initialized
INFO - 2023-05-01 10:51:28 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-01 10:51:28 --> Pagination Class Initialized
INFO - 2023-05-01 10:51:28 --> Form Validation Class Initialized
INFO - 2023-05-01 10:51:28 --> Controller Class Initialized
INFO - 2023-05-01 10:51:28 --> Model Class Initialized
DEBUG - 2023-05-01 10:51:28 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-01 10:51:28 --> Model Class Initialized
DEBUG - 2023-05-01 10:51:28 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-01 10:51:28 --> Model Class Initialized
INFO - 2023-05-01 10:51:28 --> Model Class Initialized
INFO - 2023-05-01 10:51:28 --> Model Class Initialized
INFO - 2023-05-01 10:51:28 --> Model Class Initialized
DEBUG - 2023-05-01 10:51:28 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-05-01 10:51:28 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-01 10:51:28 --> Model Class Initialized
INFO - 2023-05-01 10:51:28 --> Model Class Initialized
INFO - 2023-05-01 10:51:28 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-05-01 10:51:28 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-05-01 10:51:28 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-05-01 10:51:28 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-05-01 10:51:28 --> Model Class Initialized
INFO - 2023-05-01 10:51:29 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-05-01 10:51:29 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-05-01 10:51:29 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-05-01 10:51:29 --> Final output sent to browser
DEBUG - 2023-05-01 10:51:29 --> Total execution time: 0.1790
ERROR - 2023-05-01 10:51:34 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-01 10:51:34 --> Config Class Initialized
INFO - 2023-05-01 10:51:34 --> Hooks Class Initialized
DEBUG - 2023-05-01 10:51:34 --> UTF-8 Support Enabled
INFO - 2023-05-01 10:51:34 --> Utf8 Class Initialized
INFO - 2023-05-01 10:51:34 --> URI Class Initialized
INFO - 2023-05-01 10:51:34 --> Router Class Initialized
INFO - 2023-05-01 10:51:34 --> Output Class Initialized
INFO - 2023-05-01 10:51:34 --> Security Class Initialized
DEBUG - 2023-05-01 10:51:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-01 10:51:34 --> Input Class Initialized
INFO - 2023-05-01 10:51:34 --> Language Class Initialized
INFO - 2023-05-01 10:51:34 --> Loader Class Initialized
INFO - 2023-05-01 10:51:34 --> Helper loaded: url_helper
INFO - 2023-05-01 10:51:34 --> Helper loaded: file_helper
INFO - 2023-05-01 10:51:34 --> Helper loaded: html_helper
INFO - 2023-05-01 10:51:34 --> Helper loaded: text_helper
INFO - 2023-05-01 10:51:34 --> Helper loaded: form_helper
INFO - 2023-05-01 10:51:34 --> Helper loaded: lang_helper
INFO - 2023-05-01 10:51:34 --> Helper loaded: security_helper
INFO - 2023-05-01 10:51:34 --> Helper loaded: cookie_helper
INFO - 2023-05-01 10:51:34 --> Database Driver Class Initialized
INFO - 2023-05-01 10:51:34 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-01 10:51:34 --> Parser Class Initialized
INFO - 2023-05-01 10:51:34 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-01 10:51:34 --> Pagination Class Initialized
INFO - 2023-05-01 10:51:34 --> Form Validation Class Initialized
INFO - 2023-05-01 10:51:34 --> Controller Class Initialized
DEBUG - 2023-05-01 10:51:34 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-05-01 10:51:34 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-01 10:51:34 --> Model Class Initialized
INFO - 2023-05-01 10:51:34 --> Model Class Initialized
DEBUG - 2023-05-01 10:51:34 --> Lmr class already loaded. Second attempt ignored.
INFO - 2023-05-01 10:51:34 --> Model Class Initialized
INFO - 2023-05-01 10:51:34 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/mr/mr.php
DEBUG - 2023-05-01 10:51:34 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-05-01 10:51:34 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-05-01 10:51:34 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-05-01 10:51:34 --> Model Class Initialized
INFO - 2023-05-01 10:51:34 --> Model Class Initialized
INFO - 2023-05-01 10:51:34 --> Model Class Initialized
INFO - 2023-05-01 10:51:34 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-05-01 10:51:34 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-05-01 10:51:34 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-05-01 10:51:34 --> Final output sent to browser
DEBUG - 2023-05-01 10:51:34 --> Total execution time: 0.1317
ERROR - 2023-05-01 10:51:35 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-01 10:51:35 --> Config Class Initialized
INFO - 2023-05-01 10:51:35 --> Hooks Class Initialized
DEBUG - 2023-05-01 10:51:35 --> UTF-8 Support Enabled
INFO - 2023-05-01 10:51:35 --> Utf8 Class Initialized
INFO - 2023-05-01 10:51:35 --> URI Class Initialized
INFO - 2023-05-01 10:51:35 --> Router Class Initialized
INFO - 2023-05-01 10:51:35 --> Output Class Initialized
INFO - 2023-05-01 10:51:35 --> Security Class Initialized
DEBUG - 2023-05-01 10:51:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-01 10:51:35 --> Input Class Initialized
INFO - 2023-05-01 10:51:35 --> Language Class Initialized
INFO - 2023-05-01 10:51:35 --> Loader Class Initialized
INFO - 2023-05-01 10:51:35 --> Helper loaded: url_helper
INFO - 2023-05-01 10:51:35 --> Helper loaded: file_helper
INFO - 2023-05-01 10:51:35 --> Helper loaded: html_helper
INFO - 2023-05-01 10:51:35 --> Helper loaded: text_helper
INFO - 2023-05-01 10:51:35 --> Helper loaded: form_helper
INFO - 2023-05-01 10:51:35 --> Helper loaded: lang_helper
INFO - 2023-05-01 10:51:35 --> Helper loaded: security_helper
INFO - 2023-05-01 10:51:35 --> Helper loaded: cookie_helper
INFO - 2023-05-01 10:51:35 --> Database Driver Class Initialized
INFO - 2023-05-01 10:51:35 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-01 10:51:35 --> Parser Class Initialized
INFO - 2023-05-01 10:51:35 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-01 10:51:35 --> Pagination Class Initialized
INFO - 2023-05-01 10:51:35 --> Form Validation Class Initialized
INFO - 2023-05-01 10:51:35 --> Controller Class Initialized
DEBUG - 2023-05-01 10:51:35 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-05-01 10:51:35 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-01 10:51:35 --> Model Class Initialized
INFO - 2023-05-01 10:51:35 --> Model Class Initialized
INFO - 2023-05-01 10:51:35 --> Final output sent to browser
DEBUG - 2023-05-01 10:51:35 --> Total execution time: 0.0190
ERROR - 2023-05-01 10:52:58 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-01 10:52:58 --> Config Class Initialized
INFO - 2023-05-01 10:52:58 --> Hooks Class Initialized
DEBUG - 2023-05-01 10:52:58 --> UTF-8 Support Enabled
INFO - 2023-05-01 10:52:58 --> Utf8 Class Initialized
INFO - 2023-05-01 10:52:58 --> URI Class Initialized
INFO - 2023-05-01 10:52:58 --> Router Class Initialized
INFO - 2023-05-01 10:52:58 --> Output Class Initialized
INFO - 2023-05-01 10:52:58 --> Security Class Initialized
DEBUG - 2023-05-01 10:52:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-01 10:52:58 --> Input Class Initialized
INFO - 2023-05-01 10:52:58 --> Language Class Initialized
INFO - 2023-05-01 10:52:58 --> Loader Class Initialized
INFO - 2023-05-01 10:52:58 --> Helper loaded: url_helper
INFO - 2023-05-01 10:52:58 --> Helper loaded: file_helper
INFO - 2023-05-01 10:52:58 --> Helper loaded: html_helper
INFO - 2023-05-01 10:52:58 --> Helper loaded: text_helper
INFO - 2023-05-01 10:52:58 --> Helper loaded: form_helper
INFO - 2023-05-01 10:52:58 --> Helper loaded: lang_helper
INFO - 2023-05-01 10:52:58 --> Helper loaded: security_helper
INFO - 2023-05-01 10:52:58 --> Helper loaded: cookie_helper
INFO - 2023-05-01 10:52:58 --> Database Driver Class Initialized
INFO - 2023-05-01 10:52:58 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-01 10:52:58 --> Parser Class Initialized
INFO - 2023-05-01 10:52:58 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-01 10:52:58 --> Pagination Class Initialized
INFO - 2023-05-01 10:52:58 --> Form Validation Class Initialized
INFO - 2023-05-01 10:52:58 --> Controller Class Initialized
INFO - 2023-05-01 10:52:58 --> Model Class Initialized
DEBUG - 2023-05-01 10:52:58 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-01 10:52:58 --> Model Class Initialized
INFO - 2023-05-01 10:52:58 --> Final output sent to browser
DEBUG - 2023-05-01 10:52:58 --> Total execution time: 0.0188
ERROR - 2023-05-01 10:52:58 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-01 10:52:58 --> Config Class Initialized
INFO - 2023-05-01 10:52:58 --> Hooks Class Initialized
DEBUG - 2023-05-01 10:52:58 --> UTF-8 Support Enabled
INFO - 2023-05-01 10:52:58 --> Utf8 Class Initialized
INFO - 2023-05-01 10:52:58 --> URI Class Initialized
DEBUG - 2023-05-01 10:52:58 --> No URI present. Default controller set.
INFO - 2023-05-01 10:52:58 --> Router Class Initialized
INFO - 2023-05-01 10:52:58 --> Output Class Initialized
INFO - 2023-05-01 10:52:58 --> Security Class Initialized
DEBUG - 2023-05-01 10:52:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-01 10:52:58 --> Input Class Initialized
INFO - 2023-05-01 10:52:58 --> Language Class Initialized
INFO - 2023-05-01 10:52:58 --> Loader Class Initialized
INFO - 2023-05-01 10:52:58 --> Helper loaded: url_helper
INFO - 2023-05-01 10:52:58 --> Helper loaded: file_helper
INFO - 2023-05-01 10:52:58 --> Helper loaded: html_helper
INFO - 2023-05-01 10:52:58 --> Helper loaded: text_helper
INFO - 2023-05-01 10:52:58 --> Helper loaded: form_helper
INFO - 2023-05-01 10:52:58 --> Helper loaded: lang_helper
INFO - 2023-05-01 10:52:58 --> Helper loaded: security_helper
INFO - 2023-05-01 10:52:58 --> Helper loaded: cookie_helper
INFO - 2023-05-01 10:52:58 --> Database Driver Class Initialized
INFO - 2023-05-01 10:52:58 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-01 10:52:58 --> Parser Class Initialized
INFO - 2023-05-01 10:52:58 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-01 10:52:58 --> Pagination Class Initialized
INFO - 2023-05-01 10:52:58 --> Form Validation Class Initialized
INFO - 2023-05-01 10:52:58 --> Controller Class Initialized
INFO - 2023-05-01 10:52:58 --> Model Class Initialized
DEBUG - 2023-05-01 10:52:58 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-01 10:52:58 --> Model Class Initialized
DEBUG - 2023-05-01 10:52:58 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-01 10:52:58 --> Model Class Initialized
INFO - 2023-05-01 10:52:58 --> Model Class Initialized
INFO - 2023-05-01 10:52:58 --> Model Class Initialized
INFO - 2023-05-01 10:52:58 --> Model Class Initialized
DEBUG - 2023-05-01 10:52:58 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-05-01 10:52:58 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-01 10:52:58 --> Model Class Initialized
INFO - 2023-05-01 10:52:58 --> Model Class Initialized
INFO - 2023-05-01 10:52:58 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-05-01 10:52:58 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-05-01 10:52:58 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-05-01 10:52:58 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-05-01 10:52:58 --> Model Class Initialized
INFO - 2023-05-01 10:52:58 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-05-01 10:52:58 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-05-01 10:52:58 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-05-01 10:52:58 --> Final output sent to browser
DEBUG - 2023-05-01 10:52:58 --> Total execution time: 0.0877
ERROR - 2023-05-01 10:53:16 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-01 10:53:16 --> Config Class Initialized
INFO - 2023-05-01 10:53:16 --> Hooks Class Initialized
DEBUG - 2023-05-01 10:53:16 --> UTF-8 Support Enabled
INFO - 2023-05-01 10:53:16 --> Utf8 Class Initialized
INFO - 2023-05-01 10:53:16 --> URI Class Initialized
INFO - 2023-05-01 10:53:16 --> Router Class Initialized
INFO - 2023-05-01 10:53:16 --> Output Class Initialized
INFO - 2023-05-01 10:53:16 --> Security Class Initialized
DEBUG - 2023-05-01 10:53:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-01 10:53:16 --> Input Class Initialized
INFO - 2023-05-01 10:53:16 --> Language Class Initialized
INFO - 2023-05-01 10:53:16 --> Loader Class Initialized
INFO - 2023-05-01 10:53:16 --> Helper loaded: url_helper
INFO - 2023-05-01 10:53:16 --> Helper loaded: file_helper
INFO - 2023-05-01 10:53:16 --> Helper loaded: html_helper
INFO - 2023-05-01 10:53:16 --> Helper loaded: text_helper
INFO - 2023-05-01 10:53:16 --> Helper loaded: form_helper
INFO - 2023-05-01 10:53:16 --> Helper loaded: lang_helper
INFO - 2023-05-01 10:53:16 --> Helper loaded: security_helper
INFO - 2023-05-01 10:53:16 --> Helper loaded: cookie_helper
INFO - 2023-05-01 10:53:16 --> Database Driver Class Initialized
INFO - 2023-05-01 10:53:16 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-01 10:53:16 --> Parser Class Initialized
INFO - 2023-05-01 10:53:16 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-01 10:53:16 --> Pagination Class Initialized
INFO - 2023-05-01 10:53:16 --> Form Validation Class Initialized
INFO - 2023-05-01 10:53:16 --> Controller Class Initialized
DEBUG - 2023-05-01 10:53:16 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-05-01 10:53:16 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-01 10:53:16 --> Model Class Initialized
DEBUG - 2023-05-01 10:53:16 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-01 10:53:16 --> Model Class Initialized
DEBUG - 2023-05-01 10:53:16 --> Lcustomer class already loaded. Second attempt ignored.
INFO - 2023-05-01 10:53:16 --> Model Class Initialized
INFO - 2023-05-01 10:53:16 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/customer/customer.php
DEBUG - 2023-05-01 10:53:16 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-05-01 10:53:16 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-05-01 10:53:16 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-05-01 10:53:16 --> Model Class Initialized
INFO - 2023-05-01 10:53:16 --> Model Class Initialized
INFO - 2023-05-01 10:53:16 --> Model Class Initialized
INFO - 2023-05-01 10:53:16 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-05-01 10:53:16 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-05-01 10:53:16 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-05-01 10:53:16 --> Final output sent to browser
DEBUG - 2023-05-01 10:53:16 --> Total execution time: 0.0694
ERROR - 2023-05-01 10:53:17 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-01 10:53:17 --> Config Class Initialized
INFO - 2023-05-01 10:53:17 --> Hooks Class Initialized
DEBUG - 2023-05-01 10:53:17 --> UTF-8 Support Enabled
INFO - 2023-05-01 10:53:17 --> Utf8 Class Initialized
INFO - 2023-05-01 10:53:17 --> URI Class Initialized
INFO - 2023-05-01 10:53:17 --> Router Class Initialized
INFO - 2023-05-01 10:53:17 --> Output Class Initialized
INFO - 2023-05-01 10:53:17 --> Security Class Initialized
DEBUG - 2023-05-01 10:53:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-01 10:53:17 --> Input Class Initialized
INFO - 2023-05-01 10:53:17 --> Language Class Initialized
INFO - 2023-05-01 10:53:17 --> Loader Class Initialized
INFO - 2023-05-01 10:53:17 --> Helper loaded: url_helper
INFO - 2023-05-01 10:53:17 --> Helper loaded: file_helper
INFO - 2023-05-01 10:53:17 --> Helper loaded: html_helper
INFO - 2023-05-01 10:53:17 --> Helper loaded: text_helper
INFO - 2023-05-01 10:53:17 --> Helper loaded: form_helper
INFO - 2023-05-01 10:53:17 --> Helper loaded: lang_helper
INFO - 2023-05-01 10:53:17 --> Helper loaded: security_helper
INFO - 2023-05-01 10:53:17 --> Helper loaded: cookie_helper
INFO - 2023-05-01 10:53:17 --> Database Driver Class Initialized
INFO - 2023-05-01 10:53:17 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-01 10:53:17 --> Parser Class Initialized
INFO - 2023-05-01 10:53:17 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-01 10:53:17 --> Pagination Class Initialized
INFO - 2023-05-01 10:53:17 --> Form Validation Class Initialized
INFO - 2023-05-01 10:53:17 --> Controller Class Initialized
DEBUG - 2023-05-01 10:53:17 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-05-01 10:53:17 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-01 10:53:17 --> Model Class Initialized
DEBUG - 2023-05-01 10:53:17 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-01 10:53:17 --> Model Class Initialized
INFO - 2023-05-01 10:53:17 --> Final output sent to browser
DEBUG - 2023-05-01 10:53:17 --> Total execution time: 0.0203
ERROR - 2023-05-01 10:57:27 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-01 10:57:27 --> Config Class Initialized
INFO - 2023-05-01 10:57:27 --> Hooks Class Initialized
DEBUG - 2023-05-01 10:57:27 --> UTF-8 Support Enabled
INFO - 2023-05-01 10:57:27 --> Utf8 Class Initialized
INFO - 2023-05-01 10:57:27 --> URI Class Initialized
DEBUG - 2023-05-01 10:57:27 --> No URI present. Default controller set.
INFO - 2023-05-01 10:57:27 --> Router Class Initialized
INFO - 2023-05-01 10:57:27 --> Output Class Initialized
INFO - 2023-05-01 10:57:27 --> Security Class Initialized
DEBUG - 2023-05-01 10:57:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-01 10:57:27 --> Input Class Initialized
INFO - 2023-05-01 10:57:27 --> Language Class Initialized
INFO - 2023-05-01 10:57:27 --> Loader Class Initialized
INFO - 2023-05-01 10:57:27 --> Helper loaded: url_helper
INFO - 2023-05-01 10:57:27 --> Helper loaded: file_helper
INFO - 2023-05-01 10:57:27 --> Helper loaded: html_helper
INFO - 2023-05-01 10:57:27 --> Helper loaded: text_helper
INFO - 2023-05-01 10:57:27 --> Helper loaded: form_helper
INFO - 2023-05-01 10:57:27 --> Helper loaded: lang_helper
INFO - 2023-05-01 10:57:27 --> Helper loaded: security_helper
INFO - 2023-05-01 10:57:27 --> Helper loaded: cookie_helper
INFO - 2023-05-01 10:57:27 --> Database Driver Class Initialized
INFO - 2023-05-01 10:57:27 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-01 10:57:27 --> Parser Class Initialized
INFO - 2023-05-01 10:57:27 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-01 10:57:27 --> Pagination Class Initialized
INFO - 2023-05-01 10:57:27 --> Form Validation Class Initialized
INFO - 2023-05-01 10:57:27 --> Controller Class Initialized
INFO - 2023-05-01 10:57:27 --> Model Class Initialized
DEBUG - 2023-05-01 10:57:27 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-01 10:57:27 --> Model Class Initialized
DEBUG - 2023-05-01 10:57:27 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-01 10:57:27 --> Model Class Initialized
INFO - 2023-05-01 10:57:27 --> Model Class Initialized
INFO - 2023-05-01 10:57:27 --> Model Class Initialized
INFO - 2023-05-01 10:57:27 --> Model Class Initialized
DEBUG - 2023-05-01 10:57:27 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-05-01 10:57:27 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-01 10:57:27 --> Model Class Initialized
INFO - 2023-05-01 10:57:27 --> Model Class Initialized
INFO - 2023-05-01 10:57:27 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-05-01 10:57:27 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-05-01 10:57:27 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-05-01 10:57:27 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-05-01 10:57:27 --> Model Class Initialized
INFO - 2023-05-01 10:57:27 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-05-01 10:57:27 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-05-01 10:57:27 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-05-01 10:57:27 --> Final output sent to browser
DEBUG - 2023-05-01 10:57:27 --> Total execution time: 0.0780
ERROR - 2023-05-01 11:00:11 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-01 11:00:11 --> Config Class Initialized
INFO - 2023-05-01 11:00:11 --> Hooks Class Initialized
DEBUG - 2023-05-01 11:00:11 --> UTF-8 Support Enabled
INFO - 2023-05-01 11:00:11 --> Utf8 Class Initialized
INFO - 2023-05-01 11:00:11 --> URI Class Initialized
DEBUG - 2023-05-01 11:00:11 --> No URI present. Default controller set.
INFO - 2023-05-01 11:00:11 --> Router Class Initialized
INFO - 2023-05-01 11:00:11 --> Output Class Initialized
INFO - 2023-05-01 11:00:11 --> Security Class Initialized
DEBUG - 2023-05-01 11:00:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-01 11:00:11 --> Input Class Initialized
INFO - 2023-05-01 11:00:11 --> Language Class Initialized
INFO - 2023-05-01 11:00:11 --> Loader Class Initialized
INFO - 2023-05-01 11:00:11 --> Helper loaded: url_helper
INFO - 2023-05-01 11:00:11 --> Helper loaded: file_helper
INFO - 2023-05-01 11:00:11 --> Helper loaded: html_helper
INFO - 2023-05-01 11:00:11 --> Helper loaded: text_helper
INFO - 2023-05-01 11:00:11 --> Helper loaded: form_helper
INFO - 2023-05-01 11:00:11 --> Helper loaded: lang_helper
INFO - 2023-05-01 11:00:11 --> Helper loaded: security_helper
INFO - 2023-05-01 11:00:11 --> Helper loaded: cookie_helper
INFO - 2023-05-01 11:00:11 --> Database Driver Class Initialized
INFO - 2023-05-01 11:00:11 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-01 11:00:11 --> Parser Class Initialized
INFO - 2023-05-01 11:00:11 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-01 11:00:11 --> Pagination Class Initialized
INFO - 2023-05-01 11:00:11 --> Form Validation Class Initialized
INFO - 2023-05-01 11:00:11 --> Controller Class Initialized
INFO - 2023-05-01 11:00:11 --> Model Class Initialized
DEBUG - 2023-05-01 11:00:11 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-01 11:00:11 --> Model Class Initialized
DEBUG - 2023-05-01 11:00:11 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-01 11:00:11 --> Model Class Initialized
INFO - 2023-05-01 11:00:11 --> Model Class Initialized
INFO - 2023-05-01 11:00:11 --> Model Class Initialized
INFO - 2023-05-01 11:00:11 --> Model Class Initialized
DEBUG - 2023-05-01 11:00:11 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-05-01 11:00:11 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-01 11:00:11 --> Model Class Initialized
INFO - 2023-05-01 11:00:11 --> Model Class Initialized
INFO - 2023-05-01 11:00:11 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-05-01 11:00:11 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-05-01 11:00:11 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-05-01 11:00:11 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-05-01 11:00:11 --> Model Class Initialized
INFO - 2023-05-01 11:00:11 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-05-01 11:00:11 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-05-01 11:00:11 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-05-01 11:00:11 --> Final output sent to browser
DEBUG - 2023-05-01 11:00:11 --> Total execution time: 0.0857
ERROR - 2023-05-01 11:00:38 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-01 11:00:38 --> Config Class Initialized
INFO - 2023-05-01 11:00:38 --> Hooks Class Initialized
DEBUG - 2023-05-01 11:00:38 --> UTF-8 Support Enabled
INFO - 2023-05-01 11:00:38 --> Utf8 Class Initialized
INFO - 2023-05-01 11:00:38 --> URI Class Initialized
INFO - 2023-05-01 11:00:38 --> Router Class Initialized
INFO - 2023-05-01 11:00:38 --> Output Class Initialized
INFO - 2023-05-01 11:00:38 --> Security Class Initialized
DEBUG - 2023-05-01 11:00:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-01 11:00:38 --> Input Class Initialized
INFO - 2023-05-01 11:00:38 --> Language Class Initialized
INFO - 2023-05-01 11:00:38 --> Loader Class Initialized
INFO - 2023-05-01 11:00:38 --> Helper loaded: url_helper
INFO - 2023-05-01 11:00:38 --> Helper loaded: file_helper
INFO - 2023-05-01 11:00:38 --> Helper loaded: html_helper
INFO - 2023-05-01 11:00:38 --> Helper loaded: text_helper
INFO - 2023-05-01 11:00:38 --> Helper loaded: form_helper
INFO - 2023-05-01 11:00:38 --> Helper loaded: lang_helper
INFO - 2023-05-01 11:00:38 --> Helper loaded: security_helper
INFO - 2023-05-01 11:00:38 --> Helper loaded: cookie_helper
INFO - 2023-05-01 11:00:38 --> Database Driver Class Initialized
INFO - 2023-05-01 11:00:38 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-01 11:00:38 --> Parser Class Initialized
INFO - 2023-05-01 11:00:38 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-01 11:00:38 --> Pagination Class Initialized
INFO - 2023-05-01 11:00:38 --> Form Validation Class Initialized
INFO - 2023-05-01 11:00:38 --> Controller Class Initialized
INFO - 2023-05-01 11:00:38 --> Model Class Initialized
DEBUG - 2023-05-01 11:00:38 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-05-01 11:00:38 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-01 11:00:38 --> Model Class Initialized
INFO - 2023-05-01 11:00:38 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/stockrequest/upcoming.php
DEBUG - 2023-05-01 11:00:38 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-05-01 11:00:38 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-05-01 11:00:38 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-05-01 11:00:38 --> Model Class Initialized
INFO - 2023-05-01 11:00:38 --> Model Class Initialized
INFO - 2023-05-01 11:00:38 --> Model Class Initialized
INFO - 2023-05-01 11:00:38 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-05-01 11:00:38 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-05-01 11:00:38 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-05-01 11:00:38 --> Final output sent to browser
DEBUG - 2023-05-01 11:00:38 --> Total execution time: 0.0664
ERROR - 2023-05-01 11:00:39 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-01 11:00:39 --> Config Class Initialized
INFO - 2023-05-01 11:00:39 --> Hooks Class Initialized
DEBUG - 2023-05-01 11:00:39 --> UTF-8 Support Enabled
INFO - 2023-05-01 11:00:39 --> Utf8 Class Initialized
INFO - 2023-05-01 11:00:39 --> URI Class Initialized
INFO - 2023-05-01 11:00:39 --> Router Class Initialized
INFO - 2023-05-01 11:00:39 --> Output Class Initialized
INFO - 2023-05-01 11:00:39 --> Security Class Initialized
DEBUG - 2023-05-01 11:00:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-01 11:00:39 --> Input Class Initialized
INFO - 2023-05-01 11:00:39 --> Language Class Initialized
INFO - 2023-05-01 11:00:39 --> Loader Class Initialized
INFO - 2023-05-01 11:00:39 --> Helper loaded: url_helper
INFO - 2023-05-01 11:00:39 --> Helper loaded: file_helper
INFO - 2023-05-01 11:00:39 --> Helper loaded: html_helper
INFO - 2023-05-01 11:00:39 --> Helper loaded: text_helper
INFO - 2023-05-01 11:00:39 --> Helper loaded: form_helper
INFO - 2023-05-01 11:00:39 --> Helper loaded: lang_helper
INFO - 2023-05-01 11:00:39 --> Helper loaded: security_helper
INFO - 2023-05-01 11:00:39 --> Helper loaded: cookie_helper
INFO - 2023-05-01 11:00:39 --> Database Driver Class Initialized
INFO - 2023-05-01 11:00:39 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-01 11:00:39 --> Parser Class Initialized
INFO - 2023-05-01 11:00:39 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-01 11:00:39 --> Pagination Class Initialized
INFO - 2023-05-01 11:00:39 --> Form Validation Class Initialized
INFO - 2023-05-01 11:00:39 --> Controller Class Initialized
INFO - 2023-05-01 11:00:39 --> Model Class Initialized
DEBUG - 2023-05-01 11:00:39 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-05-01 11:00:39 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-01 11:00:39 --> Model Class Initialized
INFO - 2023-05-01 11:00:39 --> Final output sent to browser
DEBUG - 2023-05-01 11:00:39 --> Total execution time: 0.0202
ERROR - 2023-05-01 11:00:43 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-01 11:00:43 --> Config Class Initialized
INFO - 2023-05-01 11:00:43 --> Hooks Class Initialized
DEBUG - 2023-05-01 11:00:43 --> UTF-8 Support Enabled
INFO - 2023-05-01 11:00:43 --> Utf8 Class Initialized
INFO - 2023-05-01 11:00:43 --> URI Class Initialized
INFO - 2023-05-01 11:00:43 --> Router Class Initialized
INFO - 2023-05-01 11:00:43 --> Output Class Initialized
INFO - 2023-05-01 11:00:43 --> Security Class Initialized
DEBUG - 2023-05-01 11:00:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-01 11:00:43 --> Input Class Initialized
INFO - 2023-05-01 11:00:43 --> Language Class Initialized
INFO - 2023-05-01 11:00:43 --> Loader Class Initialized
INFO - 2023-05-01 11:00:43 --> Helper loaded: url_helper
INFO - 2023-05-01 11:00:43 --> Helper loaded: file_helper
INFO - 2023-05-01 11:00:43 --> Helper loaded: html_helper
INFO - 2023-05-01 11:00:43 --> Helper loaded: text_helper
INFO - 2023-05-01 11:00:43 --> Helper loaded: form_helper
INFO - 2023-05-01 11:00:43 --> Helper loaded: lang_helper
INFO - 2023-05-01 11:00:43 --> Helper loaded: security_helper
INFO - 2023-05-01 11:00:43 --> Helper loaded: cookie_helper
INFO - 2023-05-01 11:00:43 --> Database Driver Class Initialized
INFO - 2023-05-01 11:00:43 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-01 11:00:43 --> Parser Class Initialized
INFO - 2023-05-01 11:00:43 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-01 11:00:43 --> Pagination Class Initialized
INFO - 2023-05-01 11:00:43 --> Form Validation Class Initialized
INFO - 2023-05-01 11:00:43 --> Controller Class Initialized
INFO - 2023-05-01 11:00:43 --> Model Class Initialized
DEBUG - 2023-05-01 11:00:43 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-05-01 11:00:43 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-01 11:00:43 --> Model Class Initialized
INFO - 2023-05-01 11:00:43 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/stockrequest/inventory.php
DEBUG - 2023-05-01 11:00:43 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-05-01 11:00:43 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-05-01 11:00:43 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-05-01 11:00:43 --> Model Class Initialized
INFO - 2023-05-01 11:00:43 --> Model Class Initialized
INFO - 2023-05-01 11:00:43 --> Model Class Initialized
INFO - 2023-05-01 11:00:43 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-05-01 11:00:43 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-05-01 11:00:43 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-05-01 11:00:43 --> Final output sent to browser
DEBUG - 2023-05-01 11:00:43 --> Total execution time: 0.0614
ERROR - 2023-05-01 11:00:44 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-01 11:00:44 --> Config Class Initialized
INFO - 2023-05-01 11:00:44 --> Hooks Class Initialized
DEBUG - 2023-05-01 11:00:44 --> UTF-8 Support Enabled
INFO - 2023-05-01 11:00:44 --> Utf8 Class Initialized
INFO - 2023-05-01 11:00:44 --> URI Class Initialized
INFO - 2023-05-01 11:00:44 --> Router Class Initialized
INFO - 2023-05-01 11:00:44 --> Output Class Initialized
INFO - 2023-05-01 11:00:44 --> Security Class Initialized
DEBUG - 2023-05-01 11:00:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-01 11:00:44 --> Input Class Initialized
INFO - 2023-05-01 11:00:44 --> Language Class Initialized
INFO - 2023-05-01 11:00:44 --> Loader Class Initialized
INFO - 2023-05-01 11:00:44 --> Helper loaded: url_helper
INFO - 2023-05-01 11:00:44 --> Helper loaded: file_helper
INFO - 2023-05-01 11:00:44 --> Helper loaded: html_helper
INFO - 2023-05-01 11:00:44 --> Helper loaded: text_helper
INFO - 2023-05-01 11:00:44 --> Helper loaded: form_helper
INFO - 2023-05-01 11:00:44 --> Helper loaded: lang_helper
INFO - 2023-05-01 11:00:44 --> Helper loaded: security_helper
INFO - 2023-05-01 11:00:44 --> Helper loaded: cookie_helper
INFO - 2023-05-01 11:00:44 --> Database Driver Class Initialized
INFO - 2023-05-01 11:00:44 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-01 11:00:44 --> Parser Class Initialized
INFO - 2023-05-01 11:00:44 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-01 11:00:44 --> Pagination Class Initialized
INFO - 2023-05-01 11:00:44 --> Form Validation Class Initialized
INFO - 2023-05-01 11:00:44 --> Controller Class Initialized
INFO - 2023-05-01 11:00:44 --> Model Class Initialized
DEBUG - 2023-05-01 11:00:44 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-05-01 11:00:44 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-01 11:00:44 --> Model Class Initialized
INFO - 2023-05-01 11:00:44 --> Final output sent to browser
DEBUG - 2023-05-01 11:00:44 --> Total execution time: 0.0199
ERROR - 2023-05-01 11:00:49 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-01 11:00:49 --> Config Class Initialized
INFO - 2023-05-01 11:00:49 --> Hooks Class Initialized
DEBUG - 2023-05-01 11:00:49 --> UTF-8 Support Enabled
INFO - 2023-05-01 11:00:49 --> Utf8 Class Initialized
INFO - 2023-05-01 11:00:49 --> URI Class Initialized
INFO - 2023-05-01 11:00:49 --> Router Class Initialized
INFO - 2023-05-01 11:00:49 --> Output Class Initialized
INFO - 2023-05-01 11:00:49 --> Security Class Initialized
DEBUG - 2023-05-01 11:00:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-01 11:00:49 --> Input Class Initialized
INFO - 2023-05-01 11:00:49 --> Language Class Initialized
INFO - 2023-05-01 11:00:49 --> Loader Class Initialized
INFO - 2023-05-01 11:00:49 --> Helper loaded: url_helper
INFO - 2023-05-01 11:00:49 --> Helper loaded: file_helper
INFO - 2023-05-01 11:00:49 --> Helper loaded: html_helper
INFO - 2023-05-01 11:00:49 --> Helper loaded: text_helper
INFO - 2023-05-01 11:00:49 --> Helper loaded: form_helper
INFO - 2023-05-01 11:00:49 --> Helper loaded: lang_helper
INFO - 2023-05-01 11:00:49 --> Helper loaded: security_helper
INFO - 2023-05-01 11:00:49 --> Helper loaded: cookie_helper
INFO - 2023-05-01 11:00:49 --> Database Driver Class Initialized
INFO - 2023-05-01 11:00:49 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-01 11:00:49 --> Parser Class Initialized
INFO - 2023-05-01 11:00:49 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-01 11:00:49 --> Pagination Class Initialized
INFO - 2023-05-01 11:00:49 --> Form Validation Class Initialized
INFO - 2023-05-01 11:00:49 --> Controller Class Initialized
INFO - 2023-05-01 11:00:49 --> Model Class Initialized
DEBUG - 2023-05-01 11:00:49 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-05-01 11:00:49 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-01 11:00:49 --> Model Class Initialized
INFO - 2023-05-01 11:00:49 --> Final output sent to browser
DEBUG - 2023-05-01 11:00:49 --> Total execution time: 0.0201
ERROR - 2023-05-01 11:00:58 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-01 11:00:58 --> Config Class Initialized
INFO - 2023-05-01 11:00:58 --> Hooks Class Initialized
DEBUG - 2023-05-01 11:00:58 --> UTF-8 Support Enabled
INFO - 2023-05-01 11:00:58 --> Utf8 Class Initialized
INFO - 2023-05-01 11:00:58 --> URI Class Initialized
INFO - 2023-05-01 11:00:59 --> Router Class Initialized
INFO - 2023-05-01 11:00:59 --> Output Class Initialized
INFO - 2023-05-01 11:00:59 --> Security Class Initialized
DEBUG - 2023-05-01 11:00:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-01 11:00:59 --> Input Class Initialized
INFO - 2023-05-01 11:00:59 --> Language Class Initialized
INFO - 2023-05-01 11:00:59 --> Loader Class Initialized
INFO - 2023-05-01 11:00:59 --> Helper loaded: url_helper
INFO - 2023-05-01 11:00:59 --> Helper loaded: file_helper
INFO - 2023-05-01 11:00:59 --> Helper loaded: html_helper
INFO - 2023-05-01 11:00:59 --> Helper loaded: text_helper
INFO - 2023-05-01 11:00:59 --> Helper loaded: form_helper
INFO - 2023-05-01 11:00:59 --> Helper loaded: lang_helper
INFO - 2023-05-01 11:00:59 --> Helper loaded: security_helper
INFO - 2023-05-01 11:00:59 --> Helper loaded: cookie_helper
INFO - 2023-05-01 11:00:59 --> Database Driver Class Initialized
INFO - 2023-05-01 11:00:59 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-01 11:00:59 --> Parser Class Initialized
INFO - 2023-05-01 11:00:59 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-01 11:00:59 --> Pagination Class Initialized
INFO - 2023-05-01 11:00:59 --> Form Validation Class Initialized
INFO - 2023-05-01 11:00:59 --> Controller Class Initialized
INFO - 2023-05-01 11:00:59 --> Model Class Initialized
DEBUG - 2023-05-01 11:00:59 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-05-01 11:00:59 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-01 11:00:59 --> Model Class Initialized
DEBUG - 2023-05-01 11:00:59 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-01 11:00:59 --> Model Class Initialized
INFO - 2023-05-01 11:00:59 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice.php
DEBUG - 2023-05-01 11:00:59 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-05-01 11:00:59 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-05-01 11:00:59 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-05-01 11:00:59 --> Model Class Initialized
INFO - 2023-05-01 11:00:59 --> Model Class Initialized
INFO - 2023-05-01 11:00:59 --> Model Class Initialized
INFO - 2023-05-01 11:00:59 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-05-01 11:00:59 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-05-01 11:00:59 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-05-01 11:00:59 --> Final output sent to browser
DEBUG - 2023-05-01 11:00:59 --> Total execution time: 0.0798
ERROR - 2023-05-01 11:00:59 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-01 11:00:59 --> Config Class Initialized
INFO - 2023-05-01 11:00:59 --> Hooks Class Initialized
DEBUG - 2023-05-01 11:00:59 --> UTF-8 Support Enabled
INFO - 2023-05-01 11:00:59 --> Utf8 Class Initialized
INFO - 2023-05-01 11:00:59 --> URI Class Initialized
INFO - 2023-05-01 11:00:59 --> Router Class Initialized
INFO - 2023-05-01 11:00:59 --> Output Class Initialized
INFO - 2023-05-01 11:00:59 --> Security Class Initialized
DEBUG - 2023-05-01 11:00:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-01 11:00:59 --> Input Class Initialized
INFO - 2023-05-01 11:00:59 --> Language Class Initialized
INFO - 2023-05-01 11:00:59 --> Loader Class Initialized
INFO - 2023-05-01 11:00:59 --> Helper loaded: url_helper
INFO - 2023-05-01 11:00:59 --> Helper loaded: file_helper
INFO - 2023-05-01 11:00:59 --> Helper loaded: html_helper
INFO - 2023-05-01 11:00:59 --> Helper loaded: text_helper
INFO - 2023-05-01 11:00:59 --> Helper loaded: form_helper
INFO - 2023-05-01 11:00:59 --> Helper loaded: lang_helper
INFO - 2023-05-01 11:00:59 --> Helper loaded: security_helper
INFO - 2023-05-01 11:00:59 --> Helper loaded: cookie_helper
INFO - 2023-05-01 11:00:59 --> Database Driver Class Initialized
INFO - 2023-05-01 11:00:59 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-01 11:00:59 --> Parser Class Initialized
INFO - 2023-05-01 11:00:59 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-01 11:00:59 --> Pagination Class Initialized
INFO - 2023-05-01 11:00:59 --> Form Validation Class Initialized
INFO - 2023-05-01 11:00:59 --> Controller Class Initialized
INFO - 2023-05-01 11:00:59 --> Model Class Initialized
DEBUG - 2023-05-01 11:00:59 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-05-01 11:00:59 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-01 11:00:59 --> Model Class Initialized
DEBUG - 2023-05-01 11:00:59 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-01 11:00:59 --> Model Class Initialized
INFO - 2023-05-01 11:00:59 --> Final output sent to browser
DEBUG - 2023-05-01 11:00:59 --> Total execution time: 0.0395
ERROR - 2023-05-01 11:01:08 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-01 11:01:08 --> Config Class Initialized
INFO - 2023-05-01 11:01:08 --> Hooks Class Initialized
DEBUG - 2023-05-01 11:01:08 --> UTF-8 Support Enabled
INFO - 2023-05-01 11:01:08 --> Utf8 Class Initialized
INFO - 2023-05-01 11:01:08 --> URI Class Initialized
INFO - 2023-05-01 11:01:08 --> Router Class Initialized
INFO - 2023-05-01 11:01:08 --> Output Class Initialized
INFO - 2023-05-01 11:01:08 --> Security Class Initialized
DEBUG - 2023-05-01 11:01:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-01 11:01:08 --> Input Class Initialized
INFO - 2023-05-01 11:01:08 --> Language Class Initialized
INFO - 2023-05-01 11:01:08 --> Loader Class Initialized
INFO - 2023-05-01 11:01:08 --> Helper loaded: url_helper
INFO - 2023-05-01 11:01:08 --> Helper loaded: file_helper
INFO - 2023-05-01 11:01:08 --> Helper loaded: html_helper
INFO - 2023-05-01 11:01:08 --> Helper loaded: text_helper
INFO - 2023-05-01 11:01:08 --> Helper loaded: form_helper
INFO - 2023-05-01 11:01:08 --> Helper loaded: lang_helper
INFO - 2023-05-01 11:01:08 --> Helper loaded: security_helper
INFO - 2023-05-01 11:01:08 --> Helper loaded: cookie_helper
INFO - 2023-05-01 11:01:08 --> Database Driver Class Initialized
INFO - 2023-05-01 11:01:08 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-01 11:01:08 --> Parser Class Initialized
INFO - 2023-05-01 11:01:08 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-01 11:01:08 --> Pagination Class Initialized
INFO - 2023-05-01 11:01:08 --> Form Validation Class Initialized
INFO - 2023-05-01 11:01:08 --> Controller Class Initialized
INFO - 2023-05-01 11:01:08 --> Model Class Initialized
DEBUG - 2023-05-01 11:01:08 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-05-01 11:01:08 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-01 11:01:08 --> Model Class Initialized
DEBUG - 2023-05-01 11:01:08 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-01 11:01:08 --> Model Class Initialized
INFO - 2023-05-01 11:01:08 --> Final output sent to browser
DEBUG - 2023-05-01 11:01:08 --> Total execution time: 0.0512
ERROR - 2023-05-01 11:03:30 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-01 11:03:30 --> Config Class Initialized
INFO - 2023-05-01 11:03:30 --> Hooks Class Initialized
DEBUG - 2023-05-01 11:03:30 --> UTF-8 Support Enabled
INFO - 2023-05-01 11:03:30 --> Utf8 Class Initialized
INFO - 2023-05-01 11:03:30 --> URI Class Initialized
INFO - 2023-05-01 11:03:30 --> Router Class Initialized
INFO - 2023-05-01 11:03:30 --> Output Class Initialized
INFO - 2023-05-01 11:03:30 --> Security Class Initialized
DEBUG - 2023-05-01 11:03:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-01 11:03:30 --> Input Class Initialized
INFO - 2023-05-01 11:03:30 --> Language Class Initialized
INFO - 2023-05-01 11:03:30 --> Loader Class Initialized
INFO - 2023-05-01 11:03:30 --> Helper loaded: url_helper
INFO - 2023-05-01 11:03:30 --> Helper loaded: file_helper
INFO - 2023-05-01 11:03:30 --> Helper loaded: html_helper
INFO - 2023-05-01 11:03:30 --> Helper loaded: text_helper
INFO - 2023-05-01 11:03:30 --> Helper loaded: form_helper
INFO - 2023-05-01 11:03:30 --> Helper loaded: lang_helper
INFO - 2023-05-01 11:03:30 --> Helper loaded: security_helper
INFO - 2023-05-01 11:03:30 --> Helper loaded: cookie_helper
INFO - 2023-05-01 11:03:30 --> Database Driver Class Initialized
INFO - 2023-05-01 11:03:30 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-01 11:03:30 --> Parser Class Initialized
INFO - 2023-05-01 11:03:30 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-01 11:03:30 --> Pagination Class Initialized
INFO - 2023-05-01 11:03:30 --> Form Validation Class Initialized
INFO - 2023-05-01 11:03:30 --> Controller Class Initialized
INFO - 2023-05-01 11:03:30 --> Model Class Initialized
DEBUG - 2023-05-01 11:03:30 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-05-01 11:03:30 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-01 11:03:30 --> Model Class Initialized
INFO - 2023-05-01 11:03:30 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/stockrequest/stockrequest.php
DEBUG - 2023-05-01 11:03:30 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-05-01 11:03:30 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-05-01 11:03:30 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-05-01 11:03:30 --> Model Class Initialized
INFO - 2023-05-01 11:03:30 --> Model Class Initialized
INFO - 2023-05-01 11:03:30 --> Model Class Initialized
INFO - 2023-05-01 11:03:30 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-05-01 11:03:30 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-05-01 11:03:30 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-05-01 11:03:30 --> Final output sent to browser
DEBUG - 2023-05-01 11:03:30 --> Total execution time: 0.0742
ERROR - 2023-05-01 11:03:31 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-01 11:03:31 --> Config Class Initialized
INFO - 2023-05-01 11:03:31 --> Hooks Class Initialized
DEBUG - 2023-05-01 11:03:31 --> UTF-8 Support Enabled
INFO - 2023-05-01 11:03:31 --> Utf8 Class Initialized
INFO - 2023-05-01 11:03:31 --> URI Class Initialized
INFO - 2023-05-01 11:03:31 --> Router Class Initialized
INFO - 2023-05-01 11:03:31 --> Output Class Initialized
INFO - 2023-05-01 11:03:31 --> Security Class Initialized
DEBUG - 2023-05-01 11:03:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-01 11:03:31 --> Input Class Initialized
INFO - 2023-05-01 11:03:31 --> Language Class Initialized
INFO - 2023-05-01 11:03:31 --> Loader Class Initialized
INFO - 2023-05-01 11:03:31 --> Helper loaded: url_helper
INFO - 2023-05-01 11:03:31 --> Helper loaded: file_helper
INFO - 2023-05-01 11:03:31 --> Helper loaded: html_helper
INFO - 2023-05-01 11:03:31 --> Helper loaded: text_helper
INFO - 2023-05-01 11:03:31 --> Helper loaded: form_helper
INFO - 2023-05-01 11:03:31 --> Helper loaded: lang_helper
INFO - 2023-05-01 11:03:31 --> Helper loaded: security_helper
INFO - 2023-05-01 11:03:31 --> Helper loaded: cookie_helper
INFO - 2023-05-01 11:03:31 --> Database Driver Class Initialized
INFO - 2023-05-01 11:03:31 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-01 11:03:31 --> Parser Class Initialized
INFO - 2023-05-01 11:03:31 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-01 11:03:31 --> Pagination Class Initialized
INFO - 2023-05-01 11:03:31 --> Form Validation Class Initialized
INFO - 2023-05-01 11:03:31 --> Controller Class Initialized
INFO - 2023-05-01 11:03:31 --> Model Class Initialized
DEBUG - 2023-05-01 11:03:31 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-05-01 11:03:31 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-01 11:03:31 --> Model Class Initialized
INFO - 2023-05-01 11:03:31 --> Final output sent to browser
DEBUG - 2023-05-01 11:03:31 --> Total execution time: 0.0276
ERROR - 2023-05-01 11:03:37 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-01 11:03:37 --> Config Class Initialized
INFO - 2023-05-01 11:03:37 --> Hooks Class Initialized
DEBUG - 2023-05-01 11:03:37 --> UTF-8 Support Enabled
INFO - 2023-05-01 11:03:37 --> Utf8 Class Initialized
INFO - 2023-05-01 11:03:37 --> URI Class Initialized
INFO - 2023-05-01 11:03:37 --> Router Class Initialized
INFO - 2023-05-01 11:03:37 --> Output Class Initialized
INFO - 2023-05-01 11:03:37 --> Security Class Initialized
DEBUG - 2023-05-01 11:03:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-01 11:03:37 --> Input Class Initialized
INFO - 2023-05-01 11:03:37 --> Language Class Initialized
INFO - 2023-05-01 11:03:37 --> Loader Class Initialized
INFO - 2023-05-01 11:03:37 --> Helper loaded: url_helper
INFO - 2023-05-01 11:03:37 --> Helper loaded: file_helper
INFO - 2023-05-01 11:03:37 --> Helper loaded: html_helper
INFO - 2023-05-01 11:03:37 --> Helper loaded: text_helper
INFO - 2023-05-01 11:03:37 --> Helper loaded: form_helper
INFO - 2023-05-01 11:03:37 --> Helper loaded: lang_helper
INFO - 2023-05-01 11:03:37 --> Helper loaded: security_helper
INFO - 2023-05-01 11:03:37 --> Helper loaded: cookie_helper
INFO - 2023-05-01 11:03:37 --> Database Driver Class Initialized
INFO - 2023-05-01 11:03:37 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-01 11:03:37 --> Parser Class Initialized
INFO - 2023-05-01 11:03:37 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-01 11:03:37 --> Pagination Class Initialized
INFO - 2023-05-01 11:03:37 --> Form Validation Class Initialized
INFO - 2023-05-01 11:03:37 --> Controller Class Initialized
INFO - 2023-05-01 11:03:37 --> Model Class Initialized
DEBUG - 2023-05-01 11:03:37 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-05-01 11:03:37 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-01 11:03:37 --> Model Class Initialized
INFO - 2023-05-01 11:03:37 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/stockrequest/inventory.php
DEBUG - 2023-05-01 11:03:37 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-05-01 11:03:37 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-05-01 11:03:37 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-05-01 11:03:37 --> Model Class Initialized
INFO - 2023-05-01 11:03:37 --> Model Class Initialized
INFO - 2023-05-01 11:03:37 --> Model Class Initialized
INFO - 2023-05-01 11:03:37 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-05-01 11:03:37 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-05-01 11:03:37 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-05-01 11:03:37 --> Final output sent to browser
DEBUG - 2023-05-01 11:03:37 --> Total execution time: 0.0673
ERROR - 2023-05-01 11:03:38 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-01 11:03:38 --> Config Class Initialized
INFO - 2023-05-01 11:03:38 --> Hooks Class Initialized
DEBUG - 2023-05-01 11:03:38 --> UTF-8 Support Enabled
INFO - 2023-05-01 11:03:38 --> Utf8 Class Initialized
INFO - 2023-05-01 11:03:38 --> URI Class Initialized
INFO - 2023-05-01 11:03:38 --> Router Class Initialized
INFO - 2023-05-01 11:03:38 --> Output Class Initialized
INFO - 2023-05-01 11:03:38 --> Security Class Initialized
DEBUG - 2023-05-01 11:03:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-01 11:03:38 --> Input Class Initialized
INFO - 2023-05-01 11:03:38 --> Language Class Initialized
INFO - 2023-05-01 11:03:38 --> Loader Class Initialized
INFO - 2023-05-01 11:03:38 --> Helper loaded: url_helper
INFO - 2023-05-01 11:03:38 --> Helper loaded: file_helper
INFO - 2023-05-01 11:03:38 --> Helper loaded: html_helper
INFO - 2023-05-01 11:03:38 --> Helper loaded: text_helper
INFO - 2023-05-01 11:03:38 --> Helper loaded: form_helper
INFO - 2023-05-01 11:03:38 --> Helper loaded: lang_helper
INFO - 2023-05-01 11:03:38 --> Helper loaded: security_helper
INFO - 2023-05-01 11:03:38 --> Helper loaded: cookie_helper
INFO - 2023-05-01 11:03:38 --> Database Driver Class Initialized
INFO - 2023-05-01 11:03:38 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-01 11:03:38 --> Parser Class Initialized
INFO - 2023-05-01 11:03:38 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-01 11:03:38 --> Pagination Class Initialized
INFO - 2023-05-01 11:03:38 --> Form Validation Class Initialized
INFO - 2023-05-01 11:03:38 --> Controller Class Initialized
INFO - 2023-05-01 11:03:38 --> Model Class Initialized
DEBUG - 2023-05-01 11:03:38 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-05-01 11:03:38 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-01 11:03:38 --> Model Class Initialized
INFO - 2023-05-01 11:03:38 --> Final output sent to browser
DEBUG - 2023-05-01 11:03:38 --> Total execution time: 0.0196
ERROR - 2023-05-01 11:04:38 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-01 11:04:38 --> Config Class Initialized
INFO - 2023-05-01 11:04:38 --> Hooks Class Initialized
DEBUG - 2023-05-01 11:04:38 --> UTF-8 Support Enabled
INFO - 2023-05-01 11:04:38 --> Utf8 Class Initialized
INFO - 2023-05-01 11:04:38 --> URI Class Initialized
INFO - 2023-05-01 11:04:38 --> Router Class Initialized
INFO - 2023-05-01 11:04:38 --> Output Class Initialized
INFO - 2023-05-01 11:04:38 --> Security Class Initialized
DEBUG - 2023-05-01 11:04:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-01 11:04:38 --> Input Class Initialized
INFO - 2023-05-01 11:04:38 --> Language Class Initialized
INFO - 2023-05-01 11:04:38 --> Loader Class Initialized
INFO - 2023-05-01 11:04:38 --> Helper loaded: url_helper
INFO - 2023-05-01 11:04:38 --> Helper loaded: file_helper
INFO - 2023-05-01 11:04:38 --> Helper loaded: html_helper
INFO - 2023-05-01 11:04:38 --> Helper loaded: text_helper
INFO - 2023-05-01 11:04:38 --> Helper loaded: form_helper
INFO - 2023-05-01 11:04:38 --> Helper loaded: lang_helper
INFO - 2023-05-01 11:04:38 --> Helper loaded: security_helper
INFO - 2023-05-01 11:04:38 --> Helper loaded: cookie_helper
INFO - 2023-05-01 11:04:38 --> Database Driver Class Initialized
INFO - 2023-05-01 11:04:38 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-01 11:04:38 --> Parser Class Initialized
INFO - 2023-05-01 11:04:38 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-01 11:04:38 --> Pagination Class Initialized
INFO - 2023-05-01 11:04:38 --> Form Validation Class Initialized
INFO - 2023-05-01 11:04:38 --> Controller Class Initialized
INFO - 2023-05-01 11:04:38 --> Model Class Initialized
DEBUG - 2023-05-01 11:04:38 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-05-01 11:04:38 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-01 11:04:38 --> Model Class Initialized
INFO - 2023-05-01 11:04:38 --> Final output sent to browser
DEBUG - 2023-05-01 11:04:38 --> Total execution time: 0.0217
ERROR - 2023-05-01 11:04:50 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-01 11:04:50 --> Config Class Initialized
INFO - 2023-05-01 11:04:50 --> Hooks Class Initialized
DEBUG - 2023-05-01 11:04:50 --> UTF-8 Support Enabled
INFO - 2023-05-01 11:04:50 --> Utf8 Class Initialized
INFO - 2023-05-01 11:04:50 --> URI Class Initialized
INFO - 2023-05-01 11:04:50 --> Router Class Initialized
INFO - 2023-05-01 11:04:50 --> Output Class Initialized
INFO - 2023-05-01 11:04:50 --> Security Class Initialized
DEBUG - 2023-05-01 11:04:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-01 11:04:50 --> Input Class Initialized
INFO - 2023-05-01 11:04:50 --> Language Class Initialized
INFO - 2023-05-01 11:04:50 --> Loader Class Initialized
INFO - 2023-05-01 11:04:50 --> Helper loaded: url_helper
INFO - 2023-05-01 11:04:50 --> Helper loaded: file_helper
INFO - 2023-05-01 11:04:50 --> Helper loaded: html_helper
INFO - 2023-05-01 11:04:50 --> Helper loaded: text_helper
INFO - 2023-05-01 11:04:50 --> Helper loaded: form_helper
INFO - 2023-05-01 11:04:50 --> Helper loaded: lang_helper
INFO - 2023-05-01 11:04:50 --> Helper loaded: security_helper
INFO - 2023-05-01 11:04:50 --> Helper loaded: cookie_helper
INFO - 2023-05-01 11:04:50 --> Database Driver Class Initialized
INFO - 2023-05-01 11:04:50 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-01 11:04:50 --> Parser Class Initialized
INFO - 2023-05-01 11:04:50 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-01 11:04:50 --> Pagination Class Initialized
INFO - 2023-05-01 11:04:50 --> Form Validation Class Initialized
INFO - 2023-05-01 11:04:50 --> Controller Class Initialized
INFO - 2023-05-01 11:04:50 --> Model Class Initialized
DEBUG - 2023-05-01 11:04:50 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-05-01 11:04:50 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-01 11:04:50 --> Model Class Initialized
INFO - 2023-05-01 11:04:50 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/stockrequest/inventory.php
DEBUG - 2023-05-01 11:04:50 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-05-01 11:04:50 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-05-01 11:04:50 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-05-01 11:04:50 --> Model Class Initialized
INFO - 2023-05-01 11:04:50 --> Model Class Initialized
INFO - 2023-05-01 11:04:50 --> Model Class Initialized
INFO - 2023-05-01 11:04:50 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-05-01 11:04:50 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-05-01 11:04:50 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-05-01 11:04:50 --> Final output sent to browser
DEBUG - 2023-05-01 11:04:50 --> Total execution time: 0.0707
ERROR - 2023-05-01 11:04:50 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-01 11:04:50 --> Config Class Initialized
INFO - 2023-05-01 11:04:50 --> Hooks Class Initialized
DEBUG - 2023-05-01 11:04:50 --> UTF-8 Support Enabled
INFO - 2023-05-01 11:04:50 --> Utf8 Class Initialized
INFO - 2023-05-01 11:04:50 --> URI Class Initialized
INFO - 2023-05-01 11:04:50 --> Router Class Initialized
INFO - 2023-05-01 11:04:50 --> Output Class Initialized
INFO - 2023-05-01 11:04:50 --> Security Class Initialized
DEBUG - 2023-05-01 11:04:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-01 11:04:50 --> Input Class Initialized
INFO - 2023-05-01 11:04:50 --> Language Class Initialized
INFO - 2023-05-01 11:04:50 --> Loader Class Initialized
INFO - 2023-05-01 11:04:50 --> Helper loaded: url_helper
INFO - 2023-05-01 11:04:50 --> Helper loaded: file_helper
INFO - 2023-05-01 11:04:50 --> Helper loaded: html_helper
INFO - 2023-05-01 11:04:50 --> Helper loaded: text_helper
INFO - 2023-05-01 11:04:50 --> Helper loaded: form_helper
INFO - 2023-05-01 11:04:50 --> Helper loaded: lang_helper
INFO - 2023-05-01 11:04:50 --> Helper loaded: security_helper
INFO - 2023-05-01 11:04:50 --> Helper loaded: cookie_helper
INFO - 2023-05-01 11:04:50 --> Database Driver Class Initialized
INFO - 2023-05-01 11:04:50 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-01 11:04:50 --> Parser Class Initialized
INFO - 2023-05-01 11:04:50 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-01 11:04:50 --> Pagination Class Initialized
INFO - 2023-05-01 11:04:50 --> Form Validation Class Initialized
INFO - 2023-05-01 11:04:50 --> Controller Class Initialized
INFO - 2023-05-01 11:04:50 --> Model Class Initialized
DEBUG - 2023-05-01 11:04:50 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-05-01 11:04:50 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-01 11:04:50 --> Model Class Initialized
INFO - 2023-05-01 11:04:50 --> Final output sent to browser
DEBUG - 2023-05-01 11:04:50 --> Total execution time: 0.0203
ERROR - 2023-05-01 11:09:53 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-01 11:09:53 --> Config Class Initialized
INFO - 2023-05-01 11:09:53 --> Hooks Class Initialized
DEBUG - 2023-05-01 11:09:53 --> UTF-8 Support Enabled
INFO - 2023-05-01 11:09:53 --> Utf8 Class Initialized
INFO - 2023-05-01 11:09:53 --> URI Class Initialized
INFO - 2023-05-01 11:09:53 --> Router Class Initialized
INFO - 2023-05-01 11:09:53 --> Output Class Initialized
INFO - 2023-05-01 11:09:53 --> Security Class Initialized
DEBUG - 2023-05-01 11:09:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-01 11:09:53 --> Input Class Initialized
INFO - 2023-05-01 11:09:53 --> Language Class Initialized
INFO - 2023-05-01 11:09:53 --> Loader Class Initialized
INFO - 2023-05-01 11:09:53 --> Helper loaded: url_helper
INFO - 2023-05-01 11:09:53 --> Helper loaded: file_helper
INFO - 2023-05-01 11:09:53 --> Helper loaded: html_helper
INFO - 2023-05-01 11:09:53 --> Helper loaded: text_helper
INFO - 2023-05-01 11:09:53 --> Helper loaded: form_helper
INFO - 2023-05-01 11:09:53 --> Helper loaded: lang_helper
INFO - 2023-05-01 11:09:53 --> Helper loaded: security_helper
INFO - 2023-05-01 11:09:53 --> Helper loaded: cookie_helper
INFO - 2023-05-01 11:09:53 --> Database Driver Class Initialized
INFO - 2023-05-01 11:09:53 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-01 11:09:53 --> Parser Class Initialized
INFO - 2023-05-01 11:09:53 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-01 11:09:53 --> Pagination Class Initialized
INFO - 2023-05-01 11:09:53 --> Form Validation Class Initialized
INFO - 2023-05-01 11:09:53 --> Controller Class Initialized
ERROR - 2023-05-01 11:09:53 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-01 11:09:53 --> Config Class Initialized
INFO - 2023-05-01 11:09:53 --> Hooks Class Initialized
DEBUG - 2023-05-01 11:09:53 --> UTF-8 Support Enabled
INFO - 2023-05-01 11:09:53 --> Utf8 Class Initialized
INFO - 2023-05-01 11:09:53 --> URI Class Initialized
INFO - 2023-05-01 11:09:53 --> Router Class Initialized
INFO - 2023-05-01 11:09:53 --> Output Class Initialized
INFO - 2023-05-01 11:09:53 --> Security Class Initialized
DEBUG - 2023-05-01 11:09:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-01 11:09:53 --> Input Class Initialized
INFO - 2023-05-01 11:09:53 --> Language Class Initialized
INFO - 2023-05-01 11:09:53 --> Loader Class Initialized
INFO - 2023-05-01 11:09:53 --> Helper loaded: url_helper
INFO - 2023-05-01 11:09:53 --> Helper loaded: file_helper
INFO - 2023-05-01 11:09:53 --> Helper loaded: html_helper
INFO - 2023-05-01 11:09:53 --> Helper loaded: text_helper
INFO - 2023-05-01 11:09:53 --> Helper loaded: form_helper
INFO - 2023-05-01 11:09:53 --> Helper loaded: lang_helper
INFO - 2023-05-01 11:09:53 --> Helper loaded: security_helper
INFO - 2023-05-01 11:09:53 --> Helper loaded: cookie_helper
INFO - 2023-05-01 11:09:53 --> Database Driver Class Initialized
INFO - 2023-05-01 11:09:53 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-01 11:09:53 --> Parser Class Initialized
INFO - 2023-05-01 11:09:53 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-01 11:09:53 --> Pagination Class Initialized
INFO - 2023-05-01 11:09:53 --> Form Validation Class Initialized
INFO - 2023-05-01 11:09:53 --> Controller Class Initialized
INFO - 2023-05-01 11:09:53 --> Model Class Initialized
DEBUG - 2023-05-01 11:09:53 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-01 11:09:53 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2023-05-01 11:09:53 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-05-01 11:09:53 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-05-01 11:09:53 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-05-01 11:09:53 --> Model Class Initialized
INFO - 2023-05-01 11:09:53 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-05-01 11:09:53 --> Final output sent to browser
DEBUG - 2023-05-01 11:09:53 --> Total execution time: 0.0297
ERROR - 2023-05-01 11:11:09 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-01 11:11:09 --> Config Class Initialized
INFO - 2023-05-01 11:11:09 --> Hooks Class Initialized
DEBUG - 2023-05-01 11:11:09 --> UTF-8 Support Enabled
INFO - 2023-05-01 11:11:09 --> Utf8 Class Initialized
INFO - 2023-05-01 11:11:09 --> URI Class Initialized
INFO - 2023-05-01 11:11:09 --> Router Class Initialized
INFO - 2023-05-01 11:11:09 --> Output Class Initialized
INFO - 2023-05-01 11:11:09 --> Security Class Initialized
DEBUG - 2023-05-01 11:11:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-01 11:11:09 --> Input Class Initialized
INFO - 2023-05-01 11:11:09 --> Language Class Initialized
INFO - 2023-05-01 11:11:09 --> Loader Class Initialized
INFO - 2023-05-01 11:11:09 --> Helper loaded: url_helper
INFO - 2023-05-01 11:11:09 --> Helper loaded: file_helper
INFO - 2023-05-01 11:11:09 --> Helper loaded: html_helper
INFO - 2023-05-01 11:11:09 --> Helper loaded: text_helper
INFO - 2023-05-01 11:11:09 --> Helper loaded: form_helper
INFO - 2023-05-01 11:11:09 --> Helper loaded: lang_helper
INFO - 2023-05-01 11:11:09 --> Helper loaded: security_helper
INFO - 2023-05-01 11:11:09 --> Helper loaded: cookie_helper
INFO - 2023-05-01 11:11:09 --> Database Driver Class Initialized
INFO - 2023-05-01 11:11:09 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-01 11:11:09 --> Parser Class Initialized
INFO - 2023-05-01 11:11:09 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-01 11:11:09 --> Pagination Class Initialized
INFO - 2023-05-01 11:11:09 --> Form Validation Class Initialized
INFO - 2023-05-01 11:11:09 --> Controller Class Initialized
INFO - 2023-05-01 11:11:09 --> Model Class Initialized
DEBUG - 2023-05-01 11:11:09 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-05-01 11:11:09 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-01 11:11:09 --> Model Class Initialized
INFO - 2023-05-01 11:11:09 --> Final output sent to browser
DEBUG - 2023-05-01 11:11:09 --> Total execution time: 0.0219
ERROR - 2023-05-01 11:40:49 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-01 11:40:49 --> Config Class Initialized
INFO - 2023-05-01 11:40:49 --> Hooks Class Initialized
DEBUG - 2023-05-01 11:40:49 --> UTF-8 Support Enabled
INFO - 2023-05-01 11:40:49 --> Utf8 Class Initialized
INFO - 2023-05-01 11:40:49 --> URI Class Initialized
DEBUG - 2023-05-01 11:40:49 --> No URI present. Default controller set.
INFO - 2023-05-01 11:40:49 --> Router Class Initialized
INFO - 2023-05-01 11:40:49 --> Output Class Initialized
INFO - 2023-05-01 11:40:49 --> Security Class Initialized
DEBUG - 2023-05-01 11:40:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-01 11:40:49 --> Input Class Initialized
INFO - 2023-05-01 11:40:49 --> Language Class Initialized
INFO - 2023-05-01 11:40:49 --> Loader Class Initialized
INFO - 2023-05-01 11:40:49 --> Helper loaded: url_helper
INFO - 2023-05-01 11:40:49 --> Helper loaded: file_helper
INFO - 2023-05-01 11:40:49 --> Helper loaded: html_helper
INFO - 2023-05-01 11:40:49 --> Helper loaded: text_helper
INFO - 2023-05-01 11:40:49 --> Helper loaded: form_helper
INFO - 2023-05-01 11:40:49 --> Helper loaded: lang_helper
INFO - 2023-05-01 11:40:49 --> Helper loaded: security_helper
INFO - 2023-05-01 11:40:49 --> Helper loaded: cookie_helper
INFO - 2023-05-01 11:40:49 --> Database Driver Class Initialized
INFO - 2023-05-01 11:40:49 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-01 11:40:49 --> Parser Class Initialized
INFO - 2023-05-01 11:40:49 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-01 11:40:49 --> Pagination Class Initialized
INFO - 2023-05-01 11:40:49 --> Form Validation Class Initialized
INFO - 2023-05-01 11:40:49 --> Controller Class Initialized
INFO - 2023-05-01 11:40:49 --> Model Class Initialized
DEBUG - 2023-05-01 11:40:49 --> Session class already loaded. Second attempt ignored.
ERROR - 2023-05-01 11:40:50 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-01 11:40:50 --> Config Class Initialized
INFO - 2023-05-01 11:40:50 --> Hooks Class Initialized
DEBUG - 2023-05-01 11:40:50 --> UTF-8 Support Enabled
INFO - 2023-05-01 11:40:50 --> Utf8 Class Initialized
INFO - 2023-05-01 11:40:50 --> URI Class Initialized
INFO - 2023-05-01 11:40:50 --> Router Class Initialized
INFO - 2023-05-01 11:40:50 --> Output Class Initialized
INFO - 2023-05-01 11:40:50 --> Security Class Initialized
DEBUG - 2023-05-01 11:40:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-01 11:40:50 --> Input Class Initialized
INFO - 2023-05-01 11:40:50 --> Language Class Initialized
INFO - 2023-05-01 11:40:50 --> Loader Class Initialized
INFO - 2023-05-01 11:40:50 --> Helper loaded: url_helper
INFO - 2023-05-01 11:40:50 --> Helper loaded: file_helper
INFO - 2023-05-01 11:40:50 --> Helper loaded: html_helper
INFO - 2023-05-01 11:40:50 --> Helper loaded: text_helper
INFO - 2023-05-01 11:40:50 --> Helper loaded: form_helper
INFO - 2023-05-01 11:40:50 --> Helper loaded: lang_helper
INFO - 2023-05-01 11:40:50 --> Helper loaded: security_helper
INFO - 2023-05-01 11:40:50 --> Helper loaded: cookie_helper
INFO - 2023-05-01 11:40:50 --> Database Driver Class Initialized
INFO - 2023-05-01 11:40:50 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-01 11:40:50 --> Parser Class Initialized
INFO - 2023-05-01 11:40:50 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-01 11:40:50 --> Pagination Class Initialized
INFO - 2023-05-01 11:40:50 --> Form Validation Class Initialized
INFO - 2023-05-01 11:40:50 --> Controller Class Initialized
INFO - 2023-05-01 11:40:50 --> Model Class Initialized
DEBUG - 2023-05-01 11:40:50 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-01 11:40:50 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2023-05-01 11:40:50 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-05-01 11:40:50 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-05-01 11:40:50 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-05-01 11:40:50 --> Model Class Initialized
INFO - 2023-05-01 11:40:50 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-05-01 11:40:50 --> Final output sent to browser
DEBUG - 2023-05-01 11:40:50 --> Total execution time: 0.0384
ERROR - 2023-05-01 11:41:02 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-01 11:41:02 --> Config Class Initialized
INFO - 2023-05-01 11:41:02 --> Hooks Class Initialized
DEBUG - 2023-05-01 11:41:02 --> UTF-8 Support Enabled
INFO - 2023-05-01 11:41:02 --> Utf8 Class Initialized
INFO - 2023-05-01 11:41:02 --> URI Class Initialized
INFO - 2023-05-01 11:41:02 --> Router Class Initialized
INFO - 2023-05-01 11:41:02 --> Output Class Initialized
INFO - 2023-05-01 11:41:02 --> Security Class Initialized
DEBUG - 2023-05-01 11:41:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-01 11:41:02 --> Input Class Initialized
INFO - 2023-05-01 11:41:02 --> Language Class Initialized
INFO - 2023-05-01 11:41:02 --> Loader Class Initialized
INFO - 2023-05-01 11:41:02 --> Helper loaded: url_helper
INFO - 2023-05-01 11:41:02 --> Helper loaded: file_helper
INFO - 2023-05-01 11:41:02 --> Helper loaded: html_helper
INFO - 2023-05-01 11:41:02 --> Helper loaded: text_helper
INFO - 2023-05-01 11:41:02 --> Helper loaded: form_helper
INFO - 2023-05-01 11:41:02 --> Helper loaded: lang_helper
INFO - 2023-05-01 11:41:02 --> Helper loaded: security_helper
INFO - 2023-05-01 11:41:02 --> Helper loaded: cookie_helper
INFO - 2023-05-01 11:41:02 --> Database Driver Class Initialized
INFO - 2023-05-01 11:41:02 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-01 11:41:02 --> Parser Class Initialized
INFO - 2023-05-01 11:41:02 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-01 11:41:02 --> Pagination Class Initialized
INFO - 2023-05-01 11:41:02 --> Form Validation Class Initialized
INFO - 2023-05-01 11:41:02 --> Controller Class Initialized
INFO - 2023-05-01 11:41:02 --> Model Class Initialized
DEBUG - 2023-05-01 11:41:02 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-01 11:41:02 --> Model Class Initialized
INFO - 2023-05-01 11:41:02 --> Final output sent to browser
DEBUG - 2023-05-01 11:41:02 --> Total execution time: 0.0190
ERROR - 2023-05-01 11:41:03 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-01 11:41:03 --> Config Class Initialized
INFO - 2023-05-01 11:41:03 --> Hooks Class Initialized
DEBUG - 2023-05-01 11:41:03 --> UTF-8 Support Enabled
INFO - 2023-05-01 11:41:03 --> Utf8 Class Initialized
INFO - 2023-05-01 11:41:03 --> URI Class Initialized
DEBUG - 2023-05-01 11:41:03 --> No URI present. Default controller set.
INFO - 2023-05-01 11:41:03 --> Router Class Initialized
INFO - 2023-05-01 11:41:03 --> Output Class Initialized
INFO - 2023-05-01 11:41:03 --> Security Class Initialized
DEBUG - 2023-05-01 11:41:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-01 11:41:03 --> Input Class Initialized
INFO - 2023-05-01 11:41:03 --> Language Class Initialized
INFO - 2023-05-01 11:41:03 --> Loader Class Initialized
INFO - 2023-05-01 11:41:03 --> Helper loaded: url_helper
INFO - 2023-05-01 11:41:03 --> Helper loaded: file_helper
INFO - 2023-05-01 11:41:03 --> Helper loaded: html_helper
INFO - 2023-05-01 11:41:03 --> Helper loaded: text_helper
INFO - 2023-05-01 11:41:03 --> Helper loaded: form_helper
INFO - 2023-05-01 11:41:03 --> Helper loaded: lang_helper
INFO - 2023-05-01 11:41:03 --> Helper loaded: security_helper
INFO - 2023-05-01 11:41:03 --> Helper loaded: cookie_helper
INFO - 2023-05-01 11:41:03 --> Database Driver Class Initialized
INFO - 2023-05-01 11:41:03 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-01 11:41:03 --> Parser Class Initialized
INFO - 2023-05-01 11:41:03 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-01 11:41:03 --> Pagination Class Initialized
INFO - 2023-05-01 11:41:03 --> Form Validation Class Initialized
INFO - 2023-05-01 11:41:03 --> Controller Class Initialized
INFO - 2023-05-01 11:41:03 --> Model Class Initialized
DEBUG - 2023-05-01 11:41:03 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-01 11:41:03 --> Model Class Initialized
DEBUG - 2023-05-01 11:41:03 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-01 11:41:03 --> Model Class Initialized
INFO - 2023-05-01 11:41:03 --> Model Class Initialized
INFO - 2023-05-01 11:41:03 --> Model Class Initialized
INFO - 2023-05-01 11:41:03 --> Model Class Initialized
DEBUG - 2023-05-01 11:41:03 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-05-01 11:41:03 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-01 11:41:03 --> Model Class Initialized
INFO - 2023-05-01 11:41:03 --> Model Class Initialized
INFO - 2023-05-01 11:41:03 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-05-01 11:41:03 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-05-01 11:41:03 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-05-01 11:41:03 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-05-01 11:41:03 --> Model Class Initialized
INFO - 2023-05-01 11:41:03 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-05-01 11:41:03 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-05-01 11:41:03 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-05-01 11:41:03 --> Final output sent to browser
DEBUG - 2023-05-01 11:41:03 --> Total execution time: 0.0745
ERROR - 2023-05-01 11:41:09 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-01 11:41:09 --> Config Class Initialized
INFO - 2023-05-01 11:41:09 --> Hooks Class Initialized
DEBUG - 2023-05-01 11:41:09 --> UTF-8 Support Enabled
INFO - 2023-05-01 11:41:09 --> Utf8 Class Initialized
INFO - 2023-05-01 11:41:09 --> URI Class Initialized
INFO - 2023-05-01 11:41:09 --> Router Class Initialized
INFO - 2023-05-01 11:41:09 --> Output Class Initialized
INFO - 2023-05-01 11:41:09 --> Security Class Initialized
DEBUG - 2023-05-01 11:41:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-01 11:41:09 --> Input Class Initialized
INFO - 2023-05-01 11:41:09 --> Language Class Initialized
INFO - 2023-05-01 11:41:09 --> Loader Class Initialized
INFO - 2023-05-01 11:41:09 --> Helper loaded: url_helper
INFO - 2023-05-01 11:41:09 --> Helper loaded: file_helper
INFO - 2023-05-01 11:41:09 --> Helper loaded: html_helper
INFO - 2023-05-01 11:41:09 --> Helper loaded: text_helper
INFO - 2023-05-01 11:41:09 --> Helper loaded: form_helper
INFO - 2023-05-01 11:41:09 --> Helper loaded: lang_helper
INFO - 2023-05-01 11:41:09 --> Helper loaded: security_helper
INFO - 2023-05-01 11:41:09 --> Helper loaded: cookie_helper
INFO - 2023-05-01 11:41:09 --> Database Driver Class Initialized
INFO - 2023-05-01 11:41:09 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-01 11:41:09 --> Parser Class Initialized
INFO - 2023-05-01 11:41:09 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-01 11:41:09 --> Pagination Class Initialized
INFO - 2023-05-01 11:41:09 --> Form Validation Class Initialized
INFO - 2023-05-01 11:41:09 --> Controller Class Initialized
INFO - 2023-05-01 11:41:09 --> Model Class Initialized
DEBUG - 2023-05-01 11:41:09 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-05-01 11:41:09 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-01 11:41:09 --> Model Class Initialized
INFO - 2023-05-01 11:41:09 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/stockrequest/inventory.php
DEBUG - 2023-05-01 11:41:09 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-05-01 11:41:09 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-05-01 11:41:09 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-05-01 11:41:09 --> Model Class Initialized
INFO - 2023-05-01 11:41:09 --> Model Class Initialized
INFO - 2023-05-01 11:41:09 --> Model Class Initialized
INFO - 2023-05-01 11:41:09 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-05-01 11:41:09 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-05-01 11:41:09 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-05-01 11:41:09 --> Final output sent to browser
DEBUG - 2023-05-01 11:41:09 --> Total execution time: 0.0620
ERROR - 2023-05-01 11:41:10 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-01 11:41:10 --> Config Class Initialized
INFO - 2023-05-01 11:41:10 --> Hooks Class Initialized
DEBUG - 2023-05-01 11:41:10 --> UTF-8 Support Enabled
INFO - 2023-05-01 11:41:10 --> Utf8 Class Initialized
INFO - 2023-05-01 11:41:10 --> URI Class Initialized
INFO - 2023-05-01 11:41:10 --> Router Class Initialized
INFO - 2023-05-01 11:41:10 --> Output Class Initialized
INFO - 2023-05-01 11:41:10 --> Security Class Initialized
DEBUG - 2023-05-01 11:41:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-01 11:41:10 --> Input Class Initialized
INFO - 2023-05-01 11:41:10 --> Language Class Initialized
INFO - 2023-05-01 11:41:10 --> Loader Class Initialized
INFO - 2023-05-01 11:41:10 --> Helper loaded: url_helper
INFO - 2023-05-01 11:41:10 --> Helper loaded: file_helper
INFO - 2023-05-01 11:41:10 --> Helper loaded: html_helper
INFO - 2023-05-01 11:41:10 --> Helper loaded: text_helper
INFO - 2023-05-01 11:41:10 --> Helper loaded: form_helper
INFO - 2023-05-01 11:41:10 --> Helper loaded: lang_helper
INFO - 2023-05-01 11:41:10 --> Helper loaded: security_helper
INFO - 2023-05-01 11:41:10 --> Helper loaded: cookie_helper
INFO - 2023-05-01 11:41:10 --> Database Driver Class Initialized
INFO - 2023-05-01 11:41:10 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-01 11:41:10 --> Parser Class Initialized
INFO - 2023-05-01 11:41:10 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-01 11:41:10 --> Pagination Class Initialized
INFO - 2023-05-01 11:41:10 --> Form Validation Class Initialized
INFO - 2023-05-01 11:41:10 --> Controller Class Initialized
INFO - 2023-05-01 11:41:10 --> Model Class Initialized
DEBUG - 2023-05-01 11:41:10 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-05-01 11:41:10 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-01 11:41:10 --> Model Class Initialized
INFO - 2023-05-01 11:41:10 --> Final output sent to browser
DEBUG - 2023-05-01 11:41:10 --> Total execution time: 0.0212
ERROR - 2023-05-01 11:41:52 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-01 11:41:52 --> Config Class Initialized
INFO - 2023-05-01 11:41:52 --> Hooks Class Initialized
DEBUG - 2023-05-01 11:41:52 --> UTF-8 Support Enabled
INFO - 2023-05-01 11:41:52 --> Utf8 Class Initialized
INFO - 2023-05-01 11:41:52 --> URI Class Initialized
INFO - 2023-05-01 11:41:52 --> Router Class Initialized
INFO - 2023-05-01 11:41:52 --> Output Class Initialized
INFO - 2023-05-01 11:41:52 --> Security Class Initialized
DEBUG - 2023-05-01 11:41:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-01 11:41:52 --> Input Class Initialized
INFO - 2023-05-01 11:41:52 --> Language Class Initialized
INFO - 2023-05-01 11:41:52 --> Loader Class Initialized
INFO - 2023-05-01 11:41:52 --> Helper loaded: url_helper
INFO - 2023-05-01 11:41:52 --> Helper loaded: file_helper
INFO - 2023-05-01 11:41:52 --> Helper loaded: html_helper
INFO - 2023-05-01 11:41:52 --> Helper loaded: text_helper
INFO - 2023-05-01 11:41:52 --> Helper loaded: form_helper
INFO - 2023-05-01 11:41:52 --> Helper loaded: lang_helper
INFO - 2023-05-01 11:41:52 --> Helper loaded: security_helper
INFO - 2023-05-01 11:41:52 --> Helper loaded: cookie_helper
INFO - 2023-05-01 11:41:52 --> Database Driver Class Initialized
INFO - 2023-05-01 11:41:52 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-01 11:41:52 --> Parser Class Initialized
INFO - 2023-05-01 11:41:52 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-01 11:41:52 --> Pagination Class Initialized
INFO - 2023-05-01 11:41:52 --> Form Validation Class Initialized
INFO - 2023-05-01 11:41:52 --> Controller Class Initialized
INFO - 2023-05-01 11:41:52 --> Model Class Initialized
DEBUG - 2023-05-01 11:41:52 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-05-01 11:41:52 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-01 11:41:52 --> Model Class Initialized
INFO - 2023-05-01 11:41:52 --> Final output sent to browser
DEBUG - 2023-05-01 11:41:52 --> Total execution time: 0.0220
ERROR - 2023-05-01 11:42:04 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-01 11:42:04 --> Config Class Initialized
INFO - 2023-05-01 11:42:04 --> Hooks Class Initialized
DEBUG - 2023-05-01 11:42:04 --> UTF-8 Support Enabled
INFO - 2023-05-01 11:42:04 --> Utf8 Class Initialized
INFO - 2023-05-01 11:42:04 --> URI Class Initialized
INFO - 2023-05-01 11:42:04 --> Router Class Initialized
INFO - 2023-05-01 11:42:04 --> Output Class Initialized
INFO - 2023-05-01 11:42:04 --> Security Class Initialized
DEBUG - 2023-05-01 11:42:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-01 11:42:04 --> Input Class Initialized
INFO - 2023-05-01 11:42:04 --> Language Class Initialized
INFO - 2023-05-01 11:42:04 --> Loader Class Initialized
INFO - 2023-05-01 11:42:04 --> Helper loaded: url_helper
INFO - 2023-05-01 11:42:04 --> Helper loaded: file_helper
INFO - 2023-05-01 11:42:04 --> Helper loaded: html_helper
INFO - 2023-05-01 11:42:04 --> Helper loaded: text_helper
INFO - 2023-05-01 11:42:04 --> Helper loaded: form_helper
INFO - 2023-05-01 11:42:04 --> Helper loaded: lang_helper
INFO - 2023-05-01 11:42:04 --> Helper loaded: security_helper
INFO - 2023-05-01 11:42:04 --> Helper loaded: cookie_helper
INFO - 2023-05-01 11:42:04 --> Database Driver Class Initialized
INFO - 2023-05-01 11:42:04 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-01 11:42:04 --> Parser Class Initialized
INFO - 2023-05-01 11:42:04 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-01 11:42:04 --> Pagination Class Initialized
INFO - 2023-05-01 11:42:04 --> Form Validation Class Initialized
INFO - 2023-05-01 11:42:04 --> Controller Class Initialized
INFO - 2023-05-01 11:42:04 --> Model Class Initialized
INFO - 2023-05-01 11:42:04 --> Model Class Initialized
INFO - 2023-05-01 11:42:04 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/report/out_of_stock.php
DEBUG - 2023-05-01 11:42:04 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-05-01 11:42:04 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-05-01 11:42:04 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-05-01 11:42:04 --> Model Class Initialized
INFO - 2023-05-01 11:42:04 --> Model Class Initialized
INFO - 2023-05-01 11:42:04 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-05-01 11:42:04 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-05-01 11:42:04 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-05-01 11:42:04 --> Final output sent to browser
DEBUG - 2023-05-01 11:42:04 --> Total execution time: 0.0658
ERROR - 2023-05-01 11:42:05 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-01 11:42:05 --> Config Class Initialized
INFO - 2023-05-01 11:42:05 --> Hooks Class Initialized
DEBUG - 2023-05-01 11:42:05 --> UTF-8 Support Enabled
INFO - 2023-05-01 11:42:05 --> Utf8 Class Initialized
INFO - 2023-05-01 11:42:05 --> URI Class Initialized
INFO - 2023-05-01 11:42:05 --> Router Class Initialized
INFO - 2023-05-01 11:42:05 --> Output Class Initialized
INFO - 2023-05-01 11:42:05 --> Security Class Initialized
DEBUG - 2023-05-01 11:42:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-01 11:42:05 --> Input Class Initialized
INFO - 2023-05-01 11:42:05 --> Language Class Initialized
INFO - 2023-05-01 11:42:05 --> Loader Class Initialized
INFO - 2023-05-01 11:42:05 --> Helper loaded: url_helper
INFO - 2023-05-01 11:42:05 --> Helper loaded: file_helper
INFO - 2023-05-01 11:42:05 --> Helper loaded: html_helper
INFO - 2023-05-01 11:42:05 --> Helper loaded: text_helper
INFO - 2023-05-01 11:42:05 --> Helper loaded: form_helper
INFO - 2023-05-01 11:42:05 --> Helper loaded: lang_helper
INFO - 2023-05-01 11:42:05 --> Helper loaded: security_helper
INFO - 2023-05-01 11:42:05 --> Helper loaded: cookie_helper
INFO - 2023-05-01 11:42:05 --> Database Driver Class Initialized
INFO - 2023-05-01 11:42:05 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-01 11:42:05 --> Parser Class Initialized
INFO - 2023-05-01 11:42:05 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-01 11:42:05 --> Pagination Class Initialized
INFO - 2023-05-01 11:42:05 --> Form Validation Class Initialized
INFO - 2023-05-01 11:42:05 --> Controller Class Initialized
INFO - 2023-05-01 11:42:05 --> Model Class Initialized
INFO - 2023-05-01 11:42:05 --> Model Class Initialized
INFO - 2023-05-01 11:42:05 --> Final output sent to browser
DEBUG - 2023-05-01 11:42:05 --> Total execution time: 0.0231
ERROR - 2023-05-01 11:42:14 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-01 11:42:14 --> Config Class Initialized
INFO - 2023-05-01 11:42:14 --> Hooks Class Initialized
DEBUG - 2023-05-01 11:42:14 --> UTF-8 Support Enabled
INFO - 2023-05-01 11:42:14 --> Utf8 Class Initialized
INFO - 2023-05-01 11:42:14 --> URI Class Initialized
INFO - 2023-05-01 11:42:14 --> Router Class Initialized
INFO - 2023-05-01 11:42:14 --> Output Class Initialized
INFO - 2023-05-01 11:42:14 --> Security Class Initialized
DEBUG - 2023-05-01 11:42:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-01 11:42:14 --> Input Class Initialized
INFO - 2023-05-01 11:42:14 --> Language Class Initialized
INFO - 2023-05-01 11:42:14 --> Loader Class Initialized
INFO - 2023-05-01 11:42:14 --> Helper loaded: url_helper
INFO - 2023-05-01 11:42:14 --> Helper loaded: file_helper
INFO - 2023-05-01 11:42:14 --> Helper loaded: html_helper
INFO - 2023-05-01 11:42:14 --> Helper loaded: text_helper
INFO - 2023-05-01 11:42:14 --> Helper loaded: form_helper
INFO - 2023-05-01 11:42:14 --> Helper loaded: lang_helper
INFO - 2023-05-01 11:42:14 --> Helper loaded: security_helper
INFO - 2023-05-01 11:42:14 --> Helper loaded: cookie_helper
INFO - 2023-05-01 11:42:14 --> Database Driver Class Initialized
INFO - 2023-05-01 11:42:14 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-01 11:42:14 --> Parser Class Initialized
INFO - 2023-05-01 11:42:14 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-01 11:42:14 --> Pagination Class Initialized
INFO - 2023-05-01 11:42:14 --> Form Validation Class Initialized
INFO - 2023-05-01 11:42:14 --> Controller Class Initialized
INFO - 2023-05-01 11:42:14 --> Model Class Initialized
DEBUG - 2023-05-01 11:42:14 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-05-01 11:42:14 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-01 11:42:14 --> Model Class Initialized
INFO - 2023-05-01 11:42:14 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/stockrequest/inventory.php
DEBUG - 2023-05-01 11:42:14 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-05-01 11:42:14 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-05-01 11:42:14 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-05-01 11:42:14 --> Model Class Initialized
INFO - 2023-05-01 11:42:14 --> Model Class Initialized
INFO - 2023-05-01 11:42:14 --> Model Class Initialized
INFO - 2023-05-01 11:42:14 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-05-01 11:42:14 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-05-01 11:42:14 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-05-01 11:42:14 --> Final output sent to browser
DEBUG - 2023-05-01 11:42:14 --> Total execution time: 0.0703
ERROR - 2023-05-01 11:42:15 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-01 11:42:15 --> Config Class Initialized
INFO - 2023-05-01 11:42:15 --> Hooks Class Initialized
DEBUG - 2023-05-01 11:42:15 --> UTF-8 Support Enabled
INFO - 2023-05-01 11:42:15 --> Utf8 Class Initialized
INFO - 2023-05-01 11:42:15 --> URI Class Initialized
INFO - 2023-05-01 11:42:15 --> Router Class Initialized
INFO - 2023-05-01 11:42:15 --> Output Class Initialized
INFO - 2023-05-01 11:42:15 --> Security Class Initialized
DEBUG - 2023-05-01 11:42:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-01 11:42:15 --> Input Class Initialized
INFO - 2023-05-01 11:42:15 --> Language Class Initialized
INFO - 2023-05-01 11:42:15 --> Loader Class Initialized
INFO - 2023-05-01 11:42:15 --> Helper loaded: url_helper
INFO - 2023-05-01 11:42:15 --> Helper loaded: file_helper
INFO - 2023-05-01 11:42:15 --> Helper loaded: html_helper
INFO - 2023-05-01 11:42:15 --> Helper loaded: text_helper
INFO - 2023-05-01 11:42:15 --> Helper loaded: form_helper
INFO - 2023-05-01 11:42:15 --> Helper loaded: lang_helper
INFO - 2023-05-01 11:42:15 --> Helper loaded: security_helper
INFO - 2023-05-01 11:42:15 --> Helper loaded: cookie_helper
INFO - 2023-05-01 11:42:15 --> Database Driver Class Initialized
INFO - 2023-05-01 11:42:15 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-01 11:42:15 --> Parser Class Initialized
INFO - 2023-05-01 11:42:15 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-01 11:42:15 --> Pagination Class Initialized
INFO - 2023-05-01 11:42:15 --> Form Validation Class Initialized
INFO - 2023-05-01 11:42:15 --> Controller Class Initialized
INFO - 2023-05-01 11:42:15 --> Model Class Initialized
DEBUG - 2023-05-01 11:42:15 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-05-01 11:42:15 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-01 11:42:15 --> Model Class Initialized
INFO - 2023-05-01 11:42:15 --> Final output sent to browser
DEBUG - 2023-05-01 11:42:15 --> Total execution time: 0.0188
ERROR - 2023-05-01 11:42:20 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-01 11:42:20 --> Config Class Initialized
INFO - 2023-05-01 11:42:20 --> Hooks Class Initialized
DEBUG - 2023-05-01 11:42:20 --> UTF-8 Support Enabled
INFO - 2023-05-01 11:42:20 --> Utf8 Class Initialized
INFO - 2023-05-01 11:42:20 --> URI Class Initialized
DEBUG - 2023-05-01 11:42:20 --> No URI present. Default controller set.
INFO - 2023-05-01 11:42:20 --> Router Class Initialized
INFO - 2023-05-01 11:42:20 --> Output Class Initialized
INFO - 2023-05-01 11:42:20 --> Security Class Initialized
DEBUG - 2023-05-01 11:42:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-01 11:42:20 --> Input Class Initialized
INFO - 2023-05-01 11:42:20 --> Language Class Initialized
INFO - 2023-05-01 11:42:20 --> Loader Class Initialized
INFO - 2023-05-01 11:42:20 --> Helper loaded: url_helper
INFO - 2023-05-01 11:42:20 --> Helper loaded: file_helper
INFO - 2023-05-01 11:42:20 --> Helper loaded: html_helper
INFO - 2023-05-01 11:42:20 --> Helper loaded: text_helper
INFO - 2023-05-01 11:42:20 --> Helper loaded: form_helper
INFO - 2023-05-01 11:42:20 --> Helper loaded: lang_helper
INFO - 2023-05-01 11:42:20 --> Helper loaded: security_helper
INFO - 2023-05-01 11:42:20 --> Helper loaded: cookie_helper
INFO - 2023-05-01 11:42:20 --> Database Driver Class Initialized
INFO - 2023-05-01 11:42:20 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-01 11:42:20 --> Parser Class Initialized
INFO - 2023-05-01 11:42:20 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-01 11:42:20 --> Pagination Class Initialized
INFO - 2023-05-01 11:42:20 --> Form Validation Class Initialized
INFO - 2023-05-01 11:42:20 --> Controller Class Initialized
INFO - 2023-05-01 11:42:20 --> Model Class Initialized
DEBUG - 2023-05-01 11:42:20 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-01 11:42:20 --> Model Class Initialized
DEBUG - 2023-05-01 11:42:20 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-01 11:42:20 --> Model Class Initialized
INFO - 2023-05-01 11:42:20 --> Model Class Initialized
INFO - 2023-05-01 11:42:20 --> Model Class Initialized
INFO - 2023-05-01 11:42:20 --> Model Class Initialized
DEBUG - 2023-05-01 11:42:20 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-05-01 11:42:20 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-01 11:42:20 --> Model Class Initialized
INFO - 2023-05-01 11:42:20 --> Model Class Initialized
INFO - 2023-05-01 11:42:20 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-05-01 11:42:20 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-05-01 11:42:20 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-05-01 11:42:20 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-05-01 11:42:20 --> Model Class Initialized
INFO - 2023-05-01 11:42:20 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-05-01 11:42:20 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-05-01 11:42:20 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-05-01 11:42:20 --> Final output sent to browser
DEBUG - 2023-05-01 11:42:20 --> Total execution time: 0.0809
ERROR - 2023-05-01 12:35:41 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-01 12:35:41 --> Config Class Initialized
INFO - 2023-05-01 12:35:41 --> Hooks Class Initialized
DEBUG - 2023-05-01 12:35:41 --> UTF-8 Support Enabled
INFO - 2023-05-01 12:35:41 --> Utf8 Class Initialized
INFO - 2023-05-01 12:35:41 --> URI Class Initialized
DEBUG - 2023-05-01 12:35:41 --> No URI present. Default controller set.
INFO - 2023-05-01 12:35:41 --> Router Class Initialized
INFO - 2023-05-01 12:35:41 --> Output Class Initialized
INFO - 2023-05-01 12:35:41 --> Security Class Initialized
DEBUG - 2023-05-01 12:35:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-01 12:35:41 --> Input Class Initialized
INFO - 2023-05-01 12:35:41 --> Language Class Initialized
INFO - 2023-05-01 12:35:41 --> Loader Class Initialized
INFO - 2023-05-01 12:35:41 --> Helper loaded: url_helper
INFO - 2023-05-01 12:35:41 --> Helper loaded: file_helper
INFO - 2023-05-01 12:35:41 --> Helper loaded: html_helper
INFO - 2023-05-01 12:35:41 --> Helper loaded: text_helper
INFO - 2023-05-01 12:35:41 --> Helper loaded: form_helper
INFO - 2023-05-01 12:35:41 --> Helper loaded: lang_helper
INFO - 2023-05-01 12:35:41 --> Helper loaded: security_helper
INFO - 2023-05-01 12:35:41 --> Helper loaded: cookie_helper
INFO - 2023-05-01 12:35:41 --> Database Driver Class Initialized
INFO - 2023-05-01 12:35:41 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-01 12:35:41 --> Parser Class Initialized
INFO - 2023-05-01 12:35:41 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-01 12:35:41 --> Pagination Class Initialized
INFO - 2023-05-01 12:35:41 --> Form Validation Class Initialized
INFO - 2023-05-01 12:35:41 --> Controller Class Initialized
INFO - 2023-05-01 12:35:41 --> Model Class Initialized
DEBUG - 2023-05-01 12:35:41 --> Session class already loaded. Second attempt ignored.
ERROR - 2023-05-01 12:35:42 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-01 12:35:42 --> Config Class Initialized
INFO - 2023-05-01 12:35:42 --> Hooks Class Initialized
DEBUG - 2023-05-01 12:35:42 --> UTF-8 Support Enabled
INFO - 2023-05-01 12:35:42 --> Utf8 Class Initialized
INFO - 2023-05-01 12:35:42 --> URI Class Initialized
INFO - 2023-05-01 12:35:42 --> Router Class Initialized
INFO - 2023-05-01 12:35:42 --> Output Class Initialized
INFO - 2023-05-01 12:35:42 --> Security Class Initialized
DEBUG - 2023-05-01 12:35:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-01 12:35:42 --> Input Class Initialized
INFO - 2023-05-01 12:35:42 --> Language Class Initialized
INFO - 2023-05-01 12:35:42 --> Loader Class Initialized
INFO - 2023-05-01 12:35:42 --> Helper loaded: url_helper
INFO - 2023-05-01 12:35:42 --> Helper loaded: file_helper
INFO - 2023-05-01 12:35:42 --> Helper loaded: html_helper
INFO - 2023-05-01 12:35:42 --> Helper loaded: text_helper
INFO - 2023-05-01 12:35:42 --> Helper loaded: form_helper
INFO - 2023-05-01 12:35:42 --> Helper loaded: lang_helper
INFO - 2023-05-01 12:35:42 --> Helper loaded: security_helper
INFO - 2023-05-01 12:35:42 --> Helper loaded: cookie_helper
INFO - 2023-05-01 12:35:42 --> Database Driver Class Initialized
INFO - 2023-05-01 12:35:42 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-01 12:35:42 --> Parser Class Initialized
INFO - 2023-05-01 12:35:42 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-01 12:35:42 --> Pagination Class Initialized
INFO - 2023-05-01 12:35:42 --> Form Validation Class Initialized
INFO - 2023-05-01 12:35:42 --> Controller Class Initialized
INFO - 2023-05-01 12:35:42 --> Model Class Initialized
DEBUG - 2023-05-01 12:35:42 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-01 12:35:42 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2023-05-01 12:35:42 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-05-01 12:35:42 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-05-01 12:35:42 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-05-01 12:35:42 --> Model Class Initialized
INFO - 2023-05-01 12:35:42 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-05-01 12:35:42 --> Final output sent to browser
DEBUG - 2023-05-01 12:35:42 --> Total execution time: 0.0266
ERROR - 2023-05-01 12:36:18 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-01 12:36:18 --> Config Class Initialized
INFO - 2023-05-01 12:36:18 --> Hooks Class Initialized
DEBUG - 2023-05-01 12:36:18 --> UTF-8 Support Enabled
INFO - 2023-05-01 12:36:18 --> Utf8 Class Initialized
INFO - 2023-05-01 12:36:18 --> URI Class Initialized
INFO - 2023-05-01 12:36:18 --> Router Class Initialized
INFO - 2023-05-01 12:36:18 --> Output Class Initialized
INFO - 2023-05-01 12:36:18 --> Security Class Initialized
DEBUG - 2023-05-01 12:36:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-01 12:36:18 --> Input Class Initialized
INFO - 2023-05-01 12:36:18 --> Language Class Initialized
INFO - 2023-05-01 12:36:18 --> Loader Class Initialized
INFO - 2023-05-01 12:36:18 --> Helper loaded: url_helper
INFO - 2023-05-01 12:36:18 --> Helper loaded: file_helper
INFO - 2023-05-01 12:36:18 --> Helper loaded: html_helper
INFO - 2023-05-01 12:36:18 --> Helper loaded: text_helper
INFO - 2023-05-01 12:36:18 --> Helper loaded: form_helper
INFO - 2023-05-01 12:36:18 --> Helper loaded: lang_helper
INFO - 2023-05-01 12:36:18 --> Helper loaded: security_helper
INFO - 2023-05-01 12:36:18 --> Helper loaded: cookie_helper
INFO - 2023-05-01 12:36:18 --> Database Driver Class Initialized
INFO - 2023-05-01 12:36:18 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-01 12:36:18 --> Parser Class Initialized
INFO - 2023-05-01 12:36:18 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-01 12:36:18 --> Pagination Class Initialized
INFO - 2023-05-01 12:36:18 --> Form Validation Class Initialized
INFO - 2023-05-01 12:36:18 --> Controller Class Initialized
INFO - 2023-05-01 12:36:18 --> Model Class Initialized
DEBUG - 2023-05-01 12:36:18 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-01 12:36:18 --> Model Class Initialized
INFO - 2023-05-01 12:36:18 --> Final output sent to browser
DEBUG - 2023-05-01 12:36:18 --> Total execution time: 0.0185
ERROR - 2023-05-01 12:36:18 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-01 12:36:18 --> Config Class Initialized
INFO - 2023-05-01 12:36:18 --> Hooks Class Initialized
DEBUG - 2023-05-01 12:36:18 --> UTF-8 Support Enabled
INFO - 2023-05-01 12:36:18 --> Utf8 Class Initialized
INFO - 2023-05-01 12:36:18 --> URI Class Initialized
DEBUG - 2023-05-01 12:36:18 --> No URI present. Default controller set.
INFO - 2023-05-01 12:36:18 --> Router Class Initialized
INFO - 2023-05-01 12:36:18 --> Output Class Initialized
INFO - 2023-05-01 12:36:18 --> Security Class Initialized
DEBUG - 2023-05-01 12:36:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-01 12:36:18 --> Input Class Initialized
INFO - 2023-05-01 12:36:18 --> Language Class Initialized
INFO - 2023-05-01 12:36:18 --> Loader Class Initialized
INFO - 2023-05-01 12:36:18 --> Helper loaded: url_helper
INFO - 2023-05-01 12:36:18 --> Helper loaded: file_helper
INFO - 2023-05-01 12:36:18 --> Helper loaded: html_helper
INFO - 2023-05-01 12:36:18 --> Helper loaded: text_helper
INFO - 2023-05-01 12:36:18 --> Helper loaded: form_helper
INFO - 2023-05-01 12:36:18 --> Helper loaded: lang_helper
INFO - 2023-05-01 12:36:18 --> Helper loaded: security_helper
INFO - 2023-05-01 12:36:18 --> Helper loaded: cookie_helper
INFO - 2023-05-01 12:36:18 --> Database Driver Class Initialized
INFO - 2023-05-01 12:36:18 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-01 12:36:18 --> Parser Class Initialized
INFO - 2023-05-01 12:36:18 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-01 12:36:18 --> Pagination Class Initialized
INFO - 2023-05-01 12:36:18 --> Form Validation Class Initialized
INFO - 2023-05-01 12:36:18 --> Controller Class Initialized
INFO - 2023-05-01 12:36:18 --> Model Class Initialized
DEBUG - 2023-05-01 12:36:18 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-01 12:36:18 --> Model Class Initialized
DEBUG - 2023-05-01 12:36:18 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-01 12:36:18 --> Model Class Initialized
INFO - 2023-05-01 12:36:18 --> Model Class Initialized
INFO - 2023-05-01 12:36:18 --> Model Class Initialized
INFO - 2023-05-01 12:36:18 --> Model Class Initialized
DEBUG - 2023-05-01 12:36:18 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-05-01 12:36:18 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-01 12:36:18 --> Model Class Initialized
INFO - 2023-05-01 12:36:18 --> Model Class Initialized
INFO - 2023-05-01 12:36:18 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-05-01 12:36:18 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-05-01 12:36:18 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-05-01 12:36:18 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-05-01 12:36:18 --> Model Class Initialized
INFO - 2023-05-01 12:36:18 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-05-01 12:36:18 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-05-01 12:36:18 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-05-01 12:36:18 --> Final output sent to browser
DEBUG - 2023-05-01 12:36:18 --> Total execution time: 0.0600
ERROR - 2023-05-01 12:36:31 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-01 12:36:31 --> Config Class Initialized
INFO - 2023-05-01 12:36:31 --> Hooks Class Initialized
DEBUG - 2023-05-01 12:36:31 --> UTF-8 Support Enabled
INFO - 2023-05-01 12:36:31 --> Utf8 Class Initialized
INFO - 2023-05-01 12:36:31 --> URI Class Initialized
INFO - 2023-05-01 12:36:31 --> Router Class Initialized
INFO - 2023-05-01 12:36:31 --> Output Class Initialized
INFO - 2023-05-01 12:36:31 --> Security Class Initialized
DEBUG - 2023-05-01 12:36:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-01 12:36:31 --> Input Class Initialized
INFO - 2023-05-01 12:36:31 --> Language Class Initialized
INFO - 2023-05-01 12:36:31 --> Loader Class Initialized
INFO - 2023-05-01 12:36:31 --> Helper loaded: url_helper
INFO - 2023-05-01 12:36:31 --> Helper loaded: file_helper
INFO - 2023-05-01 12:36:31 --> Helper loaded: html_helper
INFO - 2023-05-01 12:36:31 --> Helper loaded: text_helper
INFO - 2023-05-01 12:36:31 --> Helper loaded: form_helper
INFO - 2023-05-01 12:36:31 --> Helper loaded: lang_helper
INFO - 2023-05-01 12:36:31 --> Helper loaded: security_helper
INFO - 2023-05-01 12:36:31 --> Helper loaded: cookie_helper
INFO - 2023-05-01 12:36:31 --> Database Driver Class Initialized
INFO - 2023-05-01 12:36:31 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-01 12:36:31 --> Parser Class Initialized
INFO - 2023-05-01 12:36:31 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-01 12:36:31 --> Pagination Class Initialized
INFO - 2023-05-01 12:36:31 --> Form Validation Class Initialized
INFO - 2023-05-01 12:36:31 --> Controller Class Initialized
INFO - 2023-05-01 12:36:31 --> Model Class Initialized
DEBUG - 2023-05-01 12:36:31 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-05-01 12:36:31 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-01 12:36:31 --> Model Class Initialized
DEBUG - 2023-05-01 12:36:31 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-01 12:36:31 --> Model Class Initialized
INFO - 2023-05-01 12:36:31 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice.php
DEBUG - 2023-05-01 12:36:31 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-05-01 12:36:31 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-05-01 12:36:31 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-05-01 12:36:31 --> Model Class Initialized
INFO - 2023-05-01 12:36:31 --> Model Class Initialized
INFO - 2023-05-01 12:36:31 --> Model Class Initialized
INFO - 2023-05-01 12:36:31 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-05-01 12:36:31 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-05-01 12:36:31 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-05-01 12:36:31 --> Final output sent to browser
DEBUG - 2023-05-01 12:36:31 --> Total execution time: 0.0591
ERROR - 2023-05-01 12:36:31 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-01 12:36:31 --> Config Class Initialized
INFO - 2023-05-01 12:36:31 --> Hooks Class Initialized
DEBUG - 2023-05-01 12:36:31 --> UTF-8 Support Enabled
INFO - 2023-05-01 12:36:31 --> Utf8 Class Initialized
INFO - 2023-05-01 12:36:31 --> URI Class Initialized
INFO - 2023-05-01 12:36:31 --> Router Class Initialized
INFO - 2023-05-01 12:36:31 --> Output Class Initialized
INFO - 2023-05-01 12:36:31 --> Security Class Initialized
DEBUG - 2023-05-01 12:36:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-01 12:36:31 --> Input Class Initialized
INFO - 2023-05-01 12:36:31 --> Language Class Initialized
INFO - 2023-05-01 12:36:31 --> Loader Class Initialized
INFO - 2023-05-01 12:36:31 --> Helper loaded: url_helper
INFO - 2023-05-01 12:36:31 --> Helper loaded: file_helper
INFO - 2023-05-01 12:36:31 --> Helper loaded: html_helper
INFO - 2023-05-01 12:36:31 --> Helper loaded: text_helper
INFO - 2023-05-01 12:36:31 --> Helper loaded: form_helper
INFO - 2023-05-01 12:36:31 --> Helper loaded: lang_helper
INFO - 2023-05-01 12:36:31 --> Helper loaded: security_helper
INFO - 2023-05-01 12:36:31 --> Helper loaded: cookie_helper
INFO - 2023-05-01 12:36:31 --> Database Driver Class Initialized
INFO - 2023-05-01 12:36:31 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-01 12:36:31 --> Parser Class Initialized
INFO - 2023-05-01 12:36:31 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-01 12:36:31 --> Pagination Class Initialized
INFO - 2023-05-01 12:36:31 --> Form Validation Class Initialized
INFO - 2023-05-01 12:36:31 --> Controller Class Initialized
INFO - 2023-05-01 12:36:31 --> Model Class Initialized
DEBUG - 2023-05-01 12:36:31 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-05-01 12:36:31 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-01 12:36:31 --> Model Class Initialized
DEBUG - 2023-05-01 12:36:31 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-01 12:36:31 --> Model Class Initialized
INFO - 2023-05-01 12:36:31 --> Final output sent to browser
DEBUG - 2023-05-01 12:36:31 --> Total execution time: 0.0198
ERROR - 2023-05-01 12:36:39 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-01 12:36:39 --> Config Class Initialized
INFO - 2023-05-01 12:36:39 --> Hooks Class Initialized
DEBUG - 2023-05-01 12:36:39 --> UTF-8 Support Enabled
INFO - 2023-05-01 12:36:39 --> Utf8 Class Initialized
INFO - 2023-05-01 12:36:39 --> URI Class Initialized
INFO - 2023-05-01 12:36:39 --> Router Class Initialized
INFO - 2023-05-01 12:36:39 --> Output Class Initialized
INFO - 2023-05-01 12:36:39 --> Security Class Initialized
DEBUG - 2023-05-01 12:36:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-01 12:36:39 --> Input Class Initialized
INFO - 2023-05-01 12:36:39 --> Language Class Initialized
INFO - 2023-05-01 12:36:39 --> Loader Class Initialized
INFO - 2023-05-01 12:36:39 --> Helper loaded: url_helper
INFO - 2023-05-01 12:36:39 --> Helper loaded: file_helper
INFO - 2023-05-01 12:36:39 --> Helper loaded: html_helper
INFO - 2023-05-01 12:36:39 --> Helper loaded: text_helper
INFO - 2023-05-01 12:36:39 --> Helper loaded: form_helper
INFO - 2023-05-01 12:36:39 --> Helper loaded: lang_helper
INFO - 2023-05-01 12:36:39 --> Helper loaded: security_helper
INFO - 2023-05-01 12:36:39 --> Helper loaded: cookie_helper
INFO - 2023-05-01 12:36:39 --> Database Driver Class Initialized
INFO - 2023-05-01 12:36:39 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-01 12:36:39 --> Parser Class Initialized
INFO - 2023-05-01 12:36:39 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-01 12:36:39 --> Pagination Class Initialized
INFO - 2023-05-01 12:36:39 --> Form Validation Class Initialized
INFO - 2023-05-01 12:36:39 --> Controller Class Initialized
INFO - 2023-05-01 12:36:39 --> Model Class Initialized
DEBUG - 2023-05-01 12:36:39 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-05-01 12:36:39 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-01 12:36:39 --> Model Class Initialized
DEBUG - 2023-05-01 12:36:39 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-01 12:36:39 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/demandrequest/add_demandrequest_form.php
DEBUG - 2023-05-01 12:36:39 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-05-01 12:36:39 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-05-01 12:36:39 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-05-01 12:36:39 --> Model Class Initialized
INFO - 2023-05-01 12:36:39 --> Model Class Initialized
INFO - 2023-05-01 12:36:39 --> Model Class Initialized
INFO - 2023-05-01 12:36:39 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-05-01 12:36:39 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-05-01 12:36:39 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-05-01 12:36:39 --> Final output sent to browser
DEBUG - 2023-05-01 12:36:39 --> Total execution time: 0.0534
ERROR - 2023-05-01 12:36:50 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-01 12:36:50 --> Config Class Initialized
INFO - 2023-05-01 12:36:50 --> Hooks Class Initialized
DEBUG - 2023-05-01 12:36:50 --> UTF-8 Support Enabled
INFO - 2023-05-01 12:36:50 --> Utf8 Class Initialized
INFO - 2023-05-01 12:36:50 --> URI Class Initialized
INFO - 2023-05-01 12:36:50 --> Router Class Initialized
INFO - 2023-05-01 12:36:50 --> Output Class Initialized
INFO - 2023-05-01 12:36:50 --> Security Class Initialized
DEBUG - 2023-05-01 12:36:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-01 12:36:50 --> Input Class Initialized
INFO - 2023-05-01 12:36:50 --> Language Class Initialized
INFO - 2023-05-01 12:36:50 --> Loader Class Initialized
INFO - 2023-05-01 12:36:50 --> Helper loaded: url_helper
INFO - 2023-05-01 12:36:50 --> Helper loaded: file_helper
INFO - 2023-05-01 12:36:50 --> Helper loaded: html_helper
INFO - 2023-05-01 12:36:50 --> Helper loaded: text_helper
INFO - 2023-05-01 12:36:50 --> Helper loaded: form_helper
INFO - 2023-05-01 12:36:50 --> Helper loaded: lang_helper
INFO - 2023-05-01 12:36:50 --> Helper loaded: security_helper
INFO - 2023-05-01 12:36:50 --> Helper loaded: cookie_helper
INFO - 2023-05-01 12:36:50 --> Database Driver Class Initialized
INFO - 2023-05-01 12:36:50 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-01 12:36:50 --> Parser Class Initialized
INFO - 2023-05-01 12:36:50 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-01 12:36:50 --> Pagination Class Initialized
INFO - 2023-05-01 12:36:50 --> Form Validation Class Initialized
INFO - 2023-05-01 12:36:50 --> Controller Class Initialized
INFO - 2023-05-01 12:36:50 --> Model Class Initialized
DEBUG - 2023-05-01 12:36:50 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-05-01 12:36:50 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-01 12:36:50 --> Model Class Initialized
DEBUG - 2023-05-01 12:36:50 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-01 12:36:50 --> Model Class Initialized
INFO - 2023-05-01 12:36:50 --> Final output sent to browser
DEBUG - 2023-05-01 12:36:50 --> Total execution time: 0.0184
ERROR - 2023-05-01 12:36:51 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-01 12:36:51 --> Config Class Initialized
INFO - 2023-05-01 12:36:51 --> Hooks Class Initialized
DEBUG - 2023-05-01 12:36:51 --> UTF-8 Support Enabled
INFO - 2023-05-01 12:36:51 --> Utf8 Class Initialized
INFO - 2023-05-01 12:36:51 --> URI Class Initialized
INFO - 2023-05-01 12:36:51 --> Router Class Initialized
INFO - 2023-05-01 12:36:51 --> Output Class Initialized
INFO - 2023-05-01 12:36:51 --> Security Class Initialized
DEBUG - 2023-05-01 12:36:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-01 12:36:51 --> Input Class Initialized
INFO - 2023-05-01 12:36:51 --> Language Class Initialized
INFO - 2023-05-01 12:36:51 --> Loader Class Initialized
INFO - 2023-05-01 12:36:51 --> Helper loaded: url_helper
INFO - 2023-05-01 12:36:51 --> Helper loaded: file_helper
INFO - 2023-05-01 12:36:51 --> Helper loaded: html_helper
INFO - 2023-05-01 12:36:51 --> Helper loaded: text_helper
INFO - 2023-05-01 12:36:51 --> Helper loaded: form_helper
INFO - 2023-05-01 12:36:51 --> Helper loaded: lang_helper
INFO - 2023-05-01 12:36:51 --> Helper loaded: security_helper
INFO - 2023-05-01 12:36:51 --> Helper loaded: cookie_helper
INFO - 2023-05-01 12:36:51 --> Database Driver Class Initialized
INFO - 2023-05-01 12:36:51 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-01 12:36:51 --> Parser Class Initialized
INFO - 2023-05-01 12:36:51 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-01 12:36:51 --> Pagination Class Initialized
INFO - 2023-05-01 12:36:51 --> Form Validation Class Initialized
INFO - 2023-05-01 12:36:51 --> Controller Class Initialized
INFO - 2023-05-01 12:36:51 --> Model Class Initialized
DEBUG - 2023-05-01 12:36:51 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-05-01 12:36:51 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-01 12:36:51 --> Model Class Initialized
DEBUG - 2023-05-01 12:36:51 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-01 12:36:51 --> Model Class Initialized
INFO - 2023-05-01 12:36:51 --> Final output sent to browser
DEBUG - 2023-05-01 12:36:51 --> Total execution time: 0.0212
ERROR - 2023-05-01 12:36:51 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-01 12:36:51 --> Config Class Initialized
INFO - 2023-05-01 12:36:51 --> Hooks Class Initialized
DEBUG - 2023-05-01 12:36:51 --> UTF-8 Support Enabled
INFO - 2023-05-01 12:36:51 --> Utf8 Class Initialized
INFO - 2023-05-01 12:36:51 --> URI Class Initialized
INFO - 2023-05-01 12:36:51 --> Router Class Initialized
INFO - 2023-05-01 12:36:51 --> Output Class Initialized
INFO - 2023-05-01 12:36:51 --> Security Class Initialized
DEBUG - 2023-05-01 12:36:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-01 12:36:51 --> Input Class Initialized
INFO - 2023-05-01 12:36:51 --> Language Class Initialized
INFO - 2023-05-01 12:36:51 --> Loader Class Initialized
INFO - 2023-05-01 12:36:51 --> Helper loaded: url_helper
INFO - 2023-05-01 12:36:51 --> Helper loaded: file_helper
INFO - 2023-05-01 12:36:51 --> Helper loaded: html_helper
INFO - 2023-05-01 12:36:51 --> Helper loaded: text_helper
INFO - 2023-05-01 12:36:51 --> Helper loaded: form_helper
INFO - 2023-05-01 12:36:51 --> Helper loaded: lang_helper
INFO - 2023-05-01 12:36:51 --> Helper loaded: security_helper
INFO - 2023-05-01 12:36:51 --> Helper loaded: cookie_helper
INFO - 2023-05-01 12:36:51 --> Database Driver Class Initialized
INFO - 2023-05-01 12:36:51 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-01 12:36:51 --> Parser Class Initialized
INFO - 2023-05-01 12:36:51 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-01 12:36:51 --> Pagination Class Initialized
INFO - 2023-05-01 12:36:51 --> Form Validation Class Initialized
INFO - 2023-05-01 12:36:51 --> Controller Class Initialized
INFO - 2023-05-01 12:36:51 --> Model Class Initialized
DEBUG - 2023-05-01 12:36:51 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-05-01 12:36:51 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-01 12:36:51 --> Model Class Initialized
DEBUG - 2023-05-01 12:36:51 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-01 12:36:51 --> Model Class Initialized
INFO - 2023-05-01 12:36:51 --> Final output sent to browser
DEBUG - 2023-05-01 12:36:51 --> Total execution time: 0.0172
ERROR - 2023-05-01 12:36:52 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-01 12:36:52 --> Config Class Initialized
INFO - 2023-05-01 12:36:52 --> Hooks Class Initialized
DEBUG - 2023-05-01 12:36:52 --> UTF-8 Support Enabled
INFO - 2023-05-01 12:36:52 --> Utf8 Class Initialized
INFO - 2023-05-01 12:36:52 --> URI Class Initialized
INFO - 2023-05-01 12:36:52 --> Router Class Initialized
INFO - 2023-05-01 12:36:52 --> Output Class Initialized
INFO - 2023-05-01 12:36:52 --> Security Class Initialized
DEBUG - 2023-05-01 12:36:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-01 12:36:52 --> Input Class Initialized
INFO - 2023-05-01 12:36:52 --> Language Class Initialized
INFO - 2023-05-01 12:36:52 --> Loader Class Initialized
INFO - 2023-05-01 12:36:52 --> Helper loaded: url_helper
INFO - 2023-05-01 12:36:52 --> Helper loaded: file_helper
INFO - 2023-05-01 12:36:52 --> Helper loaded: html_helper
INFO - 2023-05-01 12:36:52 --> Helper loaded: text_helper
INFO - 2023-05-01 12:36:52 --> Helper loaded: form_helper
INFO - 2023-05-01 12:36:52 --> Helper loaded: lang_helper
INFO - 2023-05-01 12:36:52 --> Helper loaded: security_helper
INFO - 2023-05-01 12:36:52 --> Helper loaded: cookie_helper
INFO - 2023-05-01 12:36:52 --> Database Driver Class Initialized
INFO - 2023-05-01 12:36:52 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-01 12:36:52 --> Parser Class Initialized
INFO - 2023-05-01 12:36:52 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-01 12:36:52 --> Pagination Class Initialized
INFO - 2023-05-01 12:36:52 --> Form Validation Class Initialized
INFO - 2023-05-01 12:36:52 --> Controller Class Initialized
INFO - 2023-05-01 12:36:52 --> Model Class Initialized
DEBUG - 2023-05-01 12:36:52 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-05-01 12:36:52 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-01 12:36:52 --> Model Class Initialized
DEBUG - 2023-05-01 12:36:52 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-01 12:36:52 --> Model Class Initialized
INFO - 2023-05-01 12:36:52 --> Final output sent to browser
DEBUG - 2023-05-01 12:36:52 --> Total execution time: 0.0181
ERROR - 2023-05-01 12:37:00 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-01 12:37:00 --> Config Class Initialized
INFO - 2023-05-01 12:37:00 --> Hooks Class Initialized
DEBUG - 2023-05-01 12:37:00 --> UTF-8 Support Enabled
INFO - 2023-05-01 12:37:00 --> Utf8 Class Initialized
INFO - 2023-05-01 12:37:00 --> URI Class Initialized
INFO - 2023-05-01 12:37:00 --> Router Class Initialized
INFO - 2023-05-01 12:37:00 --> Output Class Initialized
INFO - 2023-05-01 12:37:00 --> Security Class Initialized
DEBUG - 2023-05-01 12:37:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-01 12:37:00 --> Input Class Initialized
INFO - 2023-05-01 12:37:00 --> Language Class Initialized
INFO - 2023-05-01 12:37:00 --> Loader Class Initialized
INFO - 2023-05-01 12:37:00 --> Helper loaded: url_helper
INFO - 2023-05-01 12:37:00 --> Helper loaded: file_helper
INFO - 2023-05-01 12:37:00 --> Helper loaded: html_helper
INFO - 2023-05-01 12:37:00 --> Helper loaded: text_helper
INFO - 2023-05-01 12:37:00 --> Helper loaded: form_helper
INFO - 2023-05-01 12:37:00 --> Helper loaded: lang_helper
INFO - 2023-05-01 12:37:00 --> Helper loaded: security_helper
INFO - 2023-05-01 12:37:00 --> Helper loaded: cookie_helper
INFO - 2023-05-01 12:37:00 --> Database Driver Class Initialized
INFO - 2023-05-01 12:37:00 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-01 12:37:00 --> Parser Class Initialized
INFO - 2023-05-01 12:37:00 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-01 12:37:00 --> Pagination Class Initialized
INFO - 2023-05-01 12:37:00 --> Form Validation Class Initialized
INFO - 2023-05-01 12:37:00 --> Controller Class Initialized
INFO - 2023-05-01 12:37:00 --> Model Class Initialized
DEBUG - 2023-05-01 12:37:00 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-05-01 12:37:00 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-01 12:37:00 --> Model Class Initialized
DEBUG - 2023-05-01 12:37:00 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-01 12:37:00 --> Model Class Initialized
INFO - 2023-05-01 12:37:00 --> Final output sent to browser
DEBUG - 2023-05-01 12:37:00 --> Total execution time: 0.0172
ERROR - 2023-05-01 12:37:01 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-01 12:37:01 --> Config Class Initialized
INFO - 2023-05-01 12:37:01 --> Hooks Class Initialized
DEBUG - 2023-05-01 12:37:01 --> UTF-8 Support Enabled
INFO - 2023-05-01 12:37:01 --> Utf8 Class Initialized
INFO - 2023-05-01 12:37:01 --> URI Class Initialized
INFO - 2023-05-01 12:37:01 --> Router Class Initialized
INFO - 2023-05-01 12:37:01 --> Output Class Initialized
INFO - 2023-05-01 12:37:01 --> Security Class Initialized
DEBUG - 2023-05-01 12:37:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-01 12:37:01 --> Input Class Initialized
INFO - 2023-05-01 12:37:01 --> Language Class Initialized
INFO - 2023-05-01 12:37:01 --> Loader Class Initialized
INFO - 2023-05-01 12:37:01 --> Helper loaded: url_helper
INFO - 2023-05-01 12:37:01 --> Helper loaded: file_helper
INFO - 2023-05-01 12:37:01 --> Helper loaded: html_helper
INFO - 2023-05-01 12:37:01 --> Helper loaded: text_helper
INFO - 2023-05-01 12:37:01 --> Helper loaded: form_helper
INFO - 2023-05-01 12:37:01 --> Helper loaded: lang_helper
INFO - 2023-05-01 12:37:01 --> Helper loaded: security_helper
INFO - 2023-05-01 12:37:01 --> Helper loaded: cookie_helper
INFO - 2023-05-01 12:37:01 --> Database Driver Class Initialized
INFO - 2023-05-01 12:37:01 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-01 12:37:01 --> Parser Class Initialized
INFO - 2023-05-01 12:37:01 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-01 12:37:01 --> Pagination Class Initialized
INFO - 2023-05-01 12:37:01 --> Form Validation Class Initialized
INFO - 2023-05-01 12:37:01 --> Controller Class Initialized
INFO - 2023-05-01 12:37:01 --> Model Class Initialized
DEBUG - 2023-05-01 12:37:01 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-05-01 12:37:01 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-01 12:37:01 --> Model Class Initialized
DEBUG - 2023-05-01 12:37:01 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-01 12:37:01 --> Model Class Initialized
INFO - 2023-05-01 12:37:01 --> Final output sent to browser
DEBUG - 2023-05-01 12:37:01 --> Total execution time: 0.0167
ERROR - 2023-05-01 12:37:01 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-01 12:37:01 --> Config Class Initialized
INFO - 2023-05-01 12:37:01 --> Hooks Class Initialized
DEBUG - 2023-05-01 12:37:01 --> UTF-8 Support Enabled
INFO - 2023-05-01 12:37:01 --> Utf8 Class Initialized
INFO - 2023-05-01 12:37:01 --> URI Class Initialized
INFO - 2023-05-01 12:37:01 --> Router Class Initialized
INFO - 2023-05-01 12:37:01 --> Output Class Initialized
INFO - 2023-05-01 12:37:01 --> Security Class Initialized
DEBUG - 2023-05-01 12:37:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-01 12:37:01 --> Input Class Initialized
INFO - 2023-05-01 12:37:01 --> Language Class Initialized
INFO - 2023-05-01 12:37:01 --> Loader Class Initialized
INFO - 2023-05-01 12:37:01 --> Helper loaded: url_helper
INFO - 2023-05-01 12:37:01 --> Helper loaded: file_helper
INFO - 2023-05-01 12:37:01 --> Helper loaded: html_helper
INFO - 2023-05-01 12:37:01 --> Helper loaded: text_helper
INFO - 2023-05-01 12:37:01 --> Helper loaded: form_helper
INFO - 2023-05-01 12:37:01 --> Helper loaded: lang_helper
INFO - 2023-05-01 12:37:01 --> Helper loaded: security_helper
INFO - 2023-05-01 12:37:01 --> Helper loaded: cookie_helper
INFO - 2023-05-01 12:37:01 --> Database Driver Class Initialized
INFO - 2023-05-01 12:37:01 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-01 12:37:01 --> Parser Class Initialized
INFO - 2023-05-01 12:37:01 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-01 12:37:01 --> Pagination Class Initialized
INFO - 2023-05-01 12:37:01 --> Form Validation Class Initialized
INFO - 2023-05-01 12:37:01 --> Controller Class Initialized
INFO - 2023-05-01 12:37:02 --> Model Class Initialized
DEBUG - 2023-05-01 12:37:02 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-05-01 12:37:02 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-01 12:37:02 --> Model Class Initialized
DEBUG - 2023-05-01 12:37:02 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-01 12:37:02 --> Model Class Initialized
INFO - 2023-05-01 12:37:02 --> Final output sent to browser
DEBUG - 2023-05-01 12:37:02 --> Total execution time: 0.0180
ERROR - 2023-05-01 12:37:03 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-01 12:37:03 --> Config Class Initialized
INFO - 2023-05-01 12:37:03 --> Hooks Class Initialized
DEBUG - 2023-05-01 12:37:03 --> UTF-8 Support Enabled
INFO - 2023-05-01 12:37:03 --> Utf8 Class Initialized
INFO - 2023-05-01 12:37:03 --> URI Class Initialized
INFO - 2023-05-01 12:37:03 --> Router Class Initialized
INFO - 2023-05-01 12:37:03 --> Output Class Initialized
INFO - 2023-05-01 12:37:03 --> Security Class Initialized
DEBUG - 2023-05-01 12:37:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-01 12:37:03 --> Input Class Initialized
INFO - 2023-05-01 12:37:03 --> Language Class Initialized
INFO - 2023-05-01 12:37:03 --> Loader Class Initialized
INFO - 2023-05-01 12:37:03 --> Helper loaded: url_helper
INFO - 2023-05-01 12:37:03 --> Helper loaded: file_helper
INFO - 2023-05-01 12:37:03 --> Helper loaded: html_helper
INFO - 2023-05-01 12:37:03 --> Helper loaded: text_helper
INFO - 2023-05-01 12:37:03 --> Helper loaded: form_helper
INFO - 2023-05-01 12:37:03 --> Helper loaded: lang_helper
INFO - 2023-05-01 12:37:03 --> Helper loaded: security_helper
INFO - 2023-05-01 12:37:03 --> Helper loaded: cookie_helper
INFO - 2023-05-01 12:37:03 --> Database Driver Class Initialized
INFO - 2023-05-01 12:37:03 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-01 12:37:03 --> Parser Class Initialized
INFO - 2023-05-01 12:37:03 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-01 12:37:03 --> Pagination Class Initialized
INFO - 2023-05-01 12:37:03 --> Form Validation Class Initialized
INFO - 2023-05-01 12:37:03 --> Controller Class Initialized
INFO - 2023-05-01 12:37:03 --> Model Class Initialized
DEBUG - 2023-05-01 12:37:03 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-05-01 12:37:03 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-01 12:37:03 --> Model Class Initialized
DEBUG - 2023-05-01 12:37:03 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-01 12:37:03 --> Model Class Initialized
INFO - 2023-05-01 12:37:03 --> Final output sent to browser
DEBUG - 2023-05-01 12:37:03 --> Total execution time: 0.0164
ERROR - 2023-05-01 12:37:03 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-01 12:37:03 --> Config Class Initialized
INFO - 2023-05-01 12:37:03 --> Hooks Class Initialized
DEBUG - 2023-05-01 12:37:03 --> UTF-8 Support Enabled
INFO - 2023-05-01 12:37:03 --> Utf8 Class Initialized
INFO - 2023-05-01 12:37:03 --> URI Class Initialized
INFO - 2023-05-01 12:37:03 --> Router Class Initialized
INFO - 2023-05-01 12:37:03 --> Output Class Initialized
INFO - 2023-05-01 12:37:03 --> Security Class Initialized
DEBUG - 2023-05-01 12:37:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-01 12:37:03 --> Input Class Initialized
INFO - 2023-05-01 12:37:03 --> Language Class Initialized
INFO - 2023-05-01 12:37:03 --> Loader Class Initialized
INFO - 2023-05-01 12:37:03 --> Helper loaded: url_helper
INFO - 2023-05-01 12:37:03 --> Helper loaded: file_helper
INFO - 2023-05-01 12:37:03 --> Helper loaded: html_helper
INFO - 2023-05-01 12:37:03 --> Helper loaded: text_helper
INFO - 2023-05-01 12:37:03 --> Helper loaded: form_helper
INFO - 2023-05-01 12:37:03 --> Helper loaded: lang_helper
INFO - 2023-05-01 12:37:03 --> Helper loaded: security_helper
INFO - 2023-05-01 12:37:03 --> Helper loaded: cookie_helper
INFO - 2023-05-01 12:37:03 --> Database Driver Class Initialized
INFO - 2023-05-01 12:37:03 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-01 12:37:03 --> Parser Class Initialized
INFO - 2023-05-01 12:37:03 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-01 12:37:03 --> Pagination Class Initialized
INFO - 2023-05-01 12:37:03 --> Form Validation Class Initialized
INFO - 2023-05-01 12:37:03 --> Controller Class Initialized
INFO - 2023-05-01 12:37:03 --> Model Class Initialized
DEBUG - 2023-05-01 12:37:03 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-05-01 12:37:03 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-01 12:37:03 --> Model Class Initialized
DEBUG - 2023-05-01 12:37:03 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-01 12:37:03 --> Model Class Initialized
INFO - 2023-05-01 12:37:03 --> Final output sent to browser
DEBUG - 2023-05-01 12:37:03 --> Total execution time: 0.0170
ERROR - 2023-05-01 12:37:12 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-01 12:37:12 --> Config Class Initialized
INFO - 2023-05-01 12:37:12 --> Hooks Class Initialized
DEBUG - 2023-05-01 12:37:12 --> UTF-8 Support Enabled
INFO - 2023-05-01 12:37:12 --> Utf8 Class Initialized
INFO - 2023-05-01 12:37:12 --> URI Class Initialized
INFO - 2023-05-01 12:37:12 --> Router Class Initialized
INFO - 2023-05-01 12:37:12 --> Output Class Initialized
INFO - 2023-05-01 12:37:12 --> Security Class Initialized
DEBUG - 2023-05-01 12:37:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-01 12:37:12 --> Input Class Initialized
INFO - 2023-05-01 12:37:12 --> Language Class Initialized
INFO - 2023-05-01 12:37:12 --> Loader Class Initialized
INFO - 2023-05-01 12:37:12 --> Helper loaded: url_helper
INFO - 2023-05-01 12:37:12 --> Helper loaded: file_helper
INFO - 2023-05-01 12:37:12 --> Helper loaded: html_helper
INFO - 2023-05-01 12:37:12 --> Helper loaded: text_helper
INFO - 2023-05-01 12:37:12 --> Helper loaded: form_helper
INFO - 2023-05-01 12:37:12 --> Helper loaded: lang_helper
INFO - 2023-05-01 12:37:12 --> Helper loaded: security_helper
INFO - 2023-05-01 12:37:12 --> Helper loaded: cookie_helper
INFO - 2023-05-01 12:37:12 --> Database Driver Class Initialized
INFO - 2023-05-01 12:37:12 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-01 12:37:12 --> Parser Class Initialized
INFO - 2023-05-01 12:37:12 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-01 12:37:12 --> Pagination Class Initialized
INFO - 2023-05-01 12:37:12 --> Form Validation Class Initialized
INFO - 2023-05-01 12:37:12 --> Controller Class Initialized
INFO - 2023-05-01 12:37:12 --> Model Class Initialized
DEBUG - 2023-05-01 12:37:12 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-05-01 12:37:12 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-01 12:37:12 --> Model Class Initialized
INFO - 2023-05-01 12:37:12 --> Model Class Initialized
INFO - 2023-05-01 12:37:12 --> Final output sent to browser
DEBUG - 2023-05-01 12:37:12 --> Total execution time: 0.0180
ERROR - 2023-05-01 12:37:30 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-01 12:37:30 --> Config Class Initialized
INFO - 2023-05-01 12:37:30 --> Hooks Class Initialized
DEBUG - 2023-05-01 12:37:30 --> UTF-8 Support Enabled
INFO - 2023-05-01 12:37:30 --> Utf8 Class Initialized
INFO - 2023-05-01 12:37:30 --> URI Class Initialized
INFO - 2023-05-01 12:37:30 --> Router Class Initialized
INFO - 2023-05-01 12:37:30 --> Output Class Initialized
INFO - 2023-05-01 12:37:30 --> Security Class Initialized
DEBUG - 2023-05-01 12:37:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-01 12:37:30 --> Input Class Initialized
INFO - 2023-05-01 12:37:30 --> Language Class Initialized
INFO - 2023-05-01 12:37:30 --> Loader Class Initialized
INFO - 2023-05-01 12:37:30 --> Helper loaded: url_helper
INFO - 2023-05-01 12:37:30 --> Helper loaded: file_helper
INFO - 2023-05-01 12:37:30 --> Helper loaded: html_helper
INFO - 2023-05-01 12:37:30 --> Helper loaded: text_helper
INFO - 2023-05-01 12:37:30 --> Helper loaded: form_helper
INFO - 2023-05-01 12:37:30 --> Helper loaded: lang_helper
INFO - 2023-05-01 12:37:30 --> Helper loaded: security_helper
INFO - 2023-05-01 12:37:30 --> Helper loaded: cookie_helper
INFO - 2023-05-01 12:37:30 --> Database Driver Class Initialized
INFO - 2023-05-01 12:37:30 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-01 12:37:30 --> Parser Class Initialized
INFO - 2023-05-01 12:37:30 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-01 12:37:30 --> Pagination Class Initialized
INFO - 2023-05-01 12:37:30 --> Form Validation Class Initialized
INFO - 2023-05-01 12:37:30 --> Controller Class Initialized
INFO - 2023-05-01 12:37:30 --> Model Class Initialized
DEBUG - 2023-05-01 12:37:30 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-05-01 12:37:30 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-01 12:37:30 --> Model Class Initialized
DEBUG - 2023-05-01 12:37:30 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-01 12:37:30 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/demandrequest/add_demandrequest_form.php
DEBUG - 2023-05-01 12:37:30 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-05-01 12:37:30 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-05-01 12:37:30 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-05-01 12:37:30 --> Model Class Initialized
INFO - 2023-05-01 12:37:30 --> Model Class Initialized
INFO - 2023-05-01 12:37:30 --> Model Class Initialized
INFO - 2023-05-01 12:37:30 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-05-01 12:37:30 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-05-01 12:37:30 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-05-01 12:37:30 --> Final output sent to browser
DEBUG - 2023-05-01 12:37:30 --> Total execution time: 0.0552
ERROR - 2023-05-01 12:37:35 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-01 12:37:35 --> Config Class Initialized
INFO - 2023-05-01 12:37:35 --> Hooks Class Initialized
DEBUG - 2023-05-01 12:37:35 --> UTF-8 Support Enabled
INFO - 2023-05-01 12:37:35 --> Utf8 Class Initialized
INFO - 2023-05-01 12:37:35 --> URI Class Initialized
INFO - 2023-05-01 12:37:35 --> Router Class Initialized
INFO - 2023-05-01 12:37:35 --> Output Class Initialized
INFO - 2023-05-01 12:37:35 --> Security Class Initialized
DEBUG - 2023-05-01 12:37:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-01 12:37:35 --> Input Class Initialized
INFO - 2023-05-01 12:37:35 --> Language Class Initialized
INFO - 2023-05-01 12:37:35 --> Loader Class Initialized
INFO - 2023-05-01 12:37:35 --> Helper loaded: url_helper
INFO - 2023-05-01 12:37:35 --> Helper loaded: file_helper
INFO - 2023-05-01 12:37:35 --> Helper loaded: html_helper
INFO - 2023-05-01 12:37:35 --> Helper loaded: text_helper
INFO - 2023-05-01 12:37:35 --> Helper loaded: form_helper
INFO - 2023-05-01 12:37:35 --> Helper loaded: lang_helper
INFO - 2023-05-01 12:37:35 --> Helper loaded: security_helper
INFO - 2023-05-01 12:37:35 --> Helper loaded: cookie_helper
INFO - 2023-05-01 12:37:35 --> Database Driver Class Initialized
INFO - 2023-05-01 12:37:35 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-01 12:37:35 --> Parser Class Initialized
INFO - 2023-05-01 12:37:35 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-01 12:37:35 --> Pagination Class Initialized
INFO - 2023-05-01 12:37:35 --> Form Validation Class Initialized
INFO - 2023-05-01 12:37:35 --> Controller Class Initialized
INFO - 2023-05-01 12:37:35 --> Model Class Initialized
DEBUG - 2023-05-01 12:37:35 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-05-01 12:37:35 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-01 12:37:35 --> Model Class Initialized
DEBUG - 2023-05-01 12:37:35 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-01 12:37:35 --> Model Class Initialized
INFO - 2023-05-01 12:37:35 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice.php
DEBUG - 2023-05-01 12:37:35 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-05-01 12:37:35 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-05-01 12:37:35 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-05-01 12:37:35 --> Model Class Initialized
INFO - 2023-05-01 12:37:35 --> Model Class Initialized
INFO - 2023-05-01 12:37:35 --> Model Class Initialized
INFO - 2023-05-01 12:37:35 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-05-01 12:37:35 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-05-01 12:37:35 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-05-01 12:37:35 --> Final output sent to browser
DEBUG - 2023-05-01 12:37:35 --> Total execution time: 0.0589
ERROR - 2023-05-01 12:37:35 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-01 12:37:35 --> Config Class Initialized
INFO - 2023-05-01 12:37:35 --> Hooks Class Initialized
DEBUG - 2023-05-01 12:37:35 --> UTF-8 Support Enabled
INFO - 2023-05-01 12:37:35 --> Utf8 Class Initialized
INFO - 2023-05-01 12:37:35 --> URI Class Initialized
INFO - 2023-05-01 12:37:35 --> Router Class Initialized
INFO - 2023-05-01 12:37:35 --> Output Class Initialized
INFO - 2023-05-01 12:37:35 --> Security Class Initialized
DEBUG - 2023-05-01 12:37:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-01 12:37:35 --> Input Class Initialized
INFO - 2023-05-01 12:37:35 --> Language Class Initialized
INFO - 2023-05-01 12:37:35 --> Loader Class Initialized
INFO - 2023-05-01 12:37:35 --> Helper loaded: url_helper
INFO - 2023-05-01 12:37:35 --> Helper loaded: file_helper
INFO - 2023-05-01 12:37:35 --> Helper loaded: html_helper
INFO - 2023-05-01 12:37:35 --> Helper loaded: text_helper
INFO - 2023-05-01 12:37:35 --> Helper loaded: form_helper
INFO - 2023-05-01 12:37:35 --> Helper loaded: lang_helper
INFO - 2023-05-01 12:37:35 --> Helper loaded: security_helper
INFO - 2023-05-01 12:37:35 --> Helper loaded: cookie_helper
INFO - 2023-05-01 12:37:35 --> Database Driver Class Initialized
INFO - 2023-05-01 12:37:35 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-01 12:37:35 --> Parser Class Initialized
INFO - 2023-05-01 12:37:35 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-01 12:37:35 --> Pagination Class Initialized
INFO - 2023-05-01 12:37:35 --> Form Validation Class Initialized
INFO - 2023-05-01 12:37:35 --> Controller Class Initialized
INFO - 2023-05-01 12:37:35 --> Model Class Initialized
DEBUG - 2023-05-01 12:37:35 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-05-01 12:37:35 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-01 12:37:35 --> Model Class Initialized
DEBUG - 2023-05-01 12:37:35 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-01 12:37:35 --> Model Class Initialized
INFO - 2023-05-01 12:37:35 --> Final output sent to browser
DEBUG - 2023-05-01 12:37:35 --> Total execution time: 0.0198
ERROR - 2023-05-01 12:37:46 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-01 12:37:46 --> Config Class Initialized
INFO - 2023-05-01 12:37:46 --> Hooks Class Initialized
DEBUG - 2023-05-01 12:37:46 --> UTF-8 Support Enabled
INFO - 2023-05-01 12:37:46 --> Utf8 Class Initialized
INFO - 2023-05-01 12:37:46 --> URI Class Initialized
INFO - 2023-05-01 12:37:46 --> Router Class Initialized
INFO - 2023-05-01 12:37:46 --> Output Class Initialized
INFO - 2023-05-01 12:37:46 --> Security Class Initialized
DEBUG - 2023-05-01 12:37:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-01 12:37:46 --> Input Class Initialized
INFO - 2023-05-01 12:37:46 --> Language Class Initialized
INFO - 2023-05-01 12:37:46 --> Loader Class Initialized
INFO - 2023-05-01 12:37:46 --> Helper loaded: url_helper
INFO - 2023-05-01 12:37:46 --> Helper loaded: file_helper
INFO - 2023-05-01 12:37:46 --> Helper loaded: html_helper
INFO - 2023-05-01 12:37:46 --> Helper loaded: text_helper
INFO - 2023-05-01 12:37:46 --> Helper loaded: form_helper
INFO - 2023-05-01 12:37:46 --> Helper loaded: lang_helper
INFO - 2023-05-01 12:37:46 --> Helper loaded: security_helper
INFO - 2023-05-01 12:37:46 --> Helper loaded: cookie_helper
INFO - 2023-05-01 12:37:46 --> Database Driver Class Initialized
INFO - 2023-05-01 12:37:46 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-01 12:37:46 --> Parser Class Initialized
INFO - 2023-05-01 12:37:46 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-01 12:37:46 --> Pagination Class Initialized
INFO - 2023-05-01 12:37:46 --> Form Validation Class Initialized
INFO - 2023-05-01 12:37:46 --> Controller Class Initialized
DEBUG - 2023-05-01 12:37:46 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-05-01 12:37:46 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-01 12:37:46 --> Model Class Initialized
DEBUG - 2023-05-01 12:37:46 --> Lgift class already loaded. Second attempt ignored.
INFO - 2023-05-01 12:37:46 --> Model Class Initialized
DEBUG - 2023-05-01 12:37:46 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-05-01 12:37:46 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-01 12:37:46 --> Model Class Initialized
DEBUG - 2023-05-01 12:37:46 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-01 12:37:46 --> Model Class Initialized
INFO - 2023-05-01 12:37:46 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/gift/gift.php
DEBUG - 2023-05-01 12:37:46 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-05-01 12:37:46 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-05-01 12:37:46 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-05-01 12:37:46 --> Model Class Initialized
INFO - 2023-05-01 12:37:46 --> Model Class Initialized
INFO - 2023-05-01 12:37:46 --> Model Class Initialized
INFO - 2023-05-01 12:37:46 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-05-01 12:37:46 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-05-01 12:37:46 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-05-01 12:37:46 --> Final output sent to browser
DEBUG - 2023-05-01 12:37:46 --> Total execution time: 0.0511
ERROR - 2023-05-01 12:37:47 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-01 12:37:47 --> Config Class Initialized
INFO - 2023-05-01 12:37:47 --> Hooks Class Initialized
DEBUG - 2023-05-01 12:37:47 --> UTF-8 Support Enabled
INFO - 2023-05-01 12:37:47 --> Utf8 Class Initialized
INFO - 2023-05-01 12:37:47 --> URI Class Initialized
INFO - 2023-05-01 12:37:47 --> Router Class Initialized
INFO - 2023-05-01 12:37:47 --> Output Class Initialized
INFO - 2023-05-01 12:37:47 --> Security Class Initialized
DEBUG - 2023-05-01 12:37:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-01 12:37:47 --> Input Class Initialized
INFO - 2023-05-01 12:37:47 --> Language Class Initialized
INFO - 2023-05-01 12:37:47 --> Loader Class Initialized
INFO - 2023-05-01 12:37:47 --> Helper loaded: url_helper
INFO - 2023-05-01 12:37:47 --> Helper loaded: file_helper
INFO - 2023-05-01 12:37:47 --> Helper loaded: html_helper
INFO - 2023-05-01 12:37:47 --> Helper loaded: text_helper
INFO - 2023-05-01 12:37:47 --> Helper loaded: form_helper
INFO - 2023-05-01 12:37:47 --> Helper loaded: lang_helper
INFO - 2023-05-01 12:37:47 --> Helper loaded: security_helper
INFO - 2023-05-01 12:37:47 --> Helper loaded: cookie_helper
INFO - 2023-05-01 12:37:47 --> Database Driver Class Initialized
INFO - 2023-05-01 12:37:47 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-01 12:37:47 --> Parser Class Initialized
INFO - 2023-05-01 12:37:47 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-01 12:37:47 --> Pagination Class Initialized
INFO - 2023-05-01 12:37:47 --> Form Validation Class Initialized
INFO - 2023-05-01 12:37:47 --> Controller Class Initialized
DEBUG - 2023-05-01 12:37:47 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-05-01 12:37:47 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-01 12:37:47 --> Model Class Initialized
INFO - 2023-05-01 12:37:47 --> Final output sent to browser
DEBUG - 2023-05-01 12:37:47 --> Total execution time: 0.0147
ERROR - 2023-05-01 12:38:19 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-01 12:38:19 --> Config Class Initialized
INFO - 2023-05-01 12:38:19 --> Hooks Class Initialized
DEBUG - 2023-05-01 12:38:19 --> UTF-8 Support Enabled
INFO - 2023-05-01 12:38:19 --> Utf8 Class Initialized
INFO - 2023-05-01 12:38:19 --> URI Class Initialized
INFO - 2023-05-01 12:38:19 --> Router Class Initialized
INFO - 2023-05-01 12:38:19 --> Output Class Initialized
INFO - 2023-05-01 12:38:19 --> Security Class Initialized
DEBUG - 2023-05-01 12:38:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-01 12:38:19 --> Input Class Initialized
INFO - 2023-05-01 12:38:19 --> Language Class Initialized
INFO - 2023-05-01 12:38:19 --> Loader Class Initialized
INFO - 2023-05-01 12:38:19 --> Helper loaded: url_helper
INFO - 2023-05-01 12:38:19 --> Helper loaded: file_helper
INFO - 2023-05-01 12:38:19 --> Helper loaded: html_helper
INFO - 2023-05-01 12:38:19 --> Helper loaded: text_helper
INFO - 2023-05-01 12:38:19 --> Helper loaded: form_helper
INFO - 2023-05-01 12:38:19 --> Helper loaded: lang_helper
INFO - 2023-05-01 12:38:19 --> Helper loaded: security_helper
INFO - 2023-05-01 12:38:19 --> Helper loaded: cookie_helper
INFO - 2023-05-01 12:38:19 --> Database Driver Class Initialized
INFO - 2023-05-01 12:38:19 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-01 12:38:19 --> Parser Class Initialized
INFO - 2023-05-01 12:38:19 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-01 12:38:19 --> Pagination Class Initialized
INFO - 2023-05-01 12:38:19 --> Form Validation Class Initialized
INFO - 2023-05-01 12:38:19 --> Controller Class Initialized
INFO - 2023-05-01 12:38:19 --> Model Class Initialized
DEBUG - 2023-05-01 12:38:19 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-05-01 12:38:19 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-01 12:38:19 --> Model Class Initialized
DEBUG - 2023-05-01 12:38:19 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-01 12:38:19 --> Model Class Initialized
INFO - 2023-05-01 12:38:19 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice.php
DEBUG - 2023-05-01 12:38:19 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-05-01 12:38:19 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-05-01 12:38:20 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-05-01 12:38:20 --> Model Class Initialized
INFO - 2023-05-01 12:38:20 --> Model Class Initialized
INFO - 2023-05-01 12:38:20 --> Model Class Initialized
INFO - 2023-05-01 12:38:20 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-05-01 12:38:20 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-05-01 12:38:20 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-05-01 12:38:20 --> Final output sent to browser
DEBUG - 2023-05-01 12:38:20 --> Total execution time: 0.0585
ERROR - 2023-05-01 12:38:20 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-01 12:38:20 --> Config Class Initialized
INFO - 2023-05-01 12:38:20 --> Hooks Class Initialized
DEBUG - 2023-05-01 12:38:20 --> UTF-8 Support Enabled
INFO - 2023-05-01 12:38:20 --> Utf8 Class Initialized
INFO - 2023-05-01 12:38:20 --> URI Class Initialized
INFO - 2023-05-01 12:38:20 --> Router Class Initialized
INFO - 2023-05-01 12:38:20 --> Output Class Initialized
INFO - 2023-05-01 12:38:20 --> Security Class Initialized
DEBUG - 2023-05-01 12:38:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-01 12:38:20 --> Input Class Initialized
INFO - 2023-05-01 12:38:20 --> Language Class Initialized
INFO - 2023-05-01 12:38:20 --> Loader Class Initialized
INFO - 2023-05-01 12:38:20 --> Helper loaded: url_helper
INFO - 2023-05-01 12:38:20 --> Helper loaded: file_helper
INFO - 2023-05-01 12:38:20 --> Helper loaded: html_helper
INFO - 2023-05-01 12:38:20 --> Helper loaded: text_helper
INFO - 2023-05-01 12:38:20 --> Helper loaded: form_helper
INFO - 2023-05-01 12:38:20 --> Helper loaded: lang_helper
INFO - 2023-05-01 12:38:20 --> Helper loaded: security_helper
INFO - 2023-05-01 12:38:20 --> Helper loaded: cookie_helper
INFO - 2023-05-01 12:38:20 --> Database Driver Class Initialized
INFO - 2023-05-01 12:38:20 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-01 12:38:20 --> Parser Class Initialized
INFO - 2023-05-01 12:38:20 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-01 12:38:20 --> Pagination Class Initialized
INFO - 2023-05-01 12:38:20 --> Form Validation Class Initialized
INFO - 2023-05-01 12:38:20 --> Controller Class Initialized
INFO - 2023-05-01 12:38:20 --> Model Class Initialized
DEBUG - 2023-05-01 12:38:20 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-05-01 12:38:20 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-01 12:38:20 --> Model Class Initialized
DEBUG - 2023-05-01 12:38:20 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-01 12:38:20 --> Model Class Initialized
INFO - 2023-05-01 12:38:20 --> Final output sent to browser
DEBUG - 2023-05-01 12:38:20 --> Total execution time: 0.0198
ERROR - 2023-05-01 13:31:13 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-01 13:31:13 --> Config Class Initialized
INFO - 2023-05-01 13:31:13 --> Hooks Class Initialized
DEBUG - 2023-05-01 13:31:13 --> UTF-8 Support Enabled
INFO - 2023-05-01 13:31:13 --> Utf8 Class Initialized
INFO - 2023-05-01 13:31:13 --> URI Class Initialized
DEBUG - 2023-05-01 13:31:13 --> No URI present. Default controller set.
INFO - 2023-05-01 13:31:13 --> Router Class Initialized
INFO - 2023-05-01 13:31:13 --> Output Class Initialized
INFO - 2023-05-01 13:31:13 --> Security Class Initialized
DEBUG - 2023-05-01 13:31:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-01 13:31:13 --> Input Class Initialized
INFO - 2023-05-01 13:31:13 --> Language Class Initialized
INFO - 2023-05-01 13:31:13 --> Loader Class Initialized
INFO - 2023-05-01 13:31:13 --> Helper loaded: url_helper
INFO - 2023-05-01 13:31:13 --> Helper loaded: file_helper
INFO - 2023-05-01 13:31:13 --> Helper loaded: html_helper
INFO - 2023-05-01 13:31:13 --> Helper loaded: text_helper
INFO - 2023-05-01 13:31:13 --> Helper loaded: form_helper
INFO - 2023-05-01 13:31:13 --> Helper loaded: lang_helper
INFO - 2023-05-01 13:31:13 --> Helper loaded: security_helper
INFO - 2023-05-01 13:31:13 --> Helper loaded: cookie_helper
INFO - 2023-05-01 13:31:13 --> Database Driver Class Initialized
INFO - 2023-05-01 13:31:13 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-01 13:31:13 --> Parser Class Initialized
INFO - 2023-05-01 13:31:13 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-01 13:31:13 --> Pagination Class Initialized
INFO - 2023-05-01 13:31:13 --> Form Validation Class Initialized
INFO - 2023-05-01 13:31:13 --> Controller Class Initialized
INFO - 2023-05-01 13:31:13 --> Model Class Initialized
DEBUG - 2023-05-01 13:31:13 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-01 13:31:13 --> Model Class Initialized
DEBUG - 2023-05-01 13:31:13 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-01 13:31:13 --> Model Class Initialized
INFO - 2023-05-01 13:31:13 --> Model Class Initialized
INFO - 2023-05-01 13:31:13 --> Model Class Initialized
INFO - 2023-05-01 13:31:13 --> Model Class Initialized
DEBUG - 2023-05-01 13:31:13 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-05-01 13:31:13 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-01 13:31:13 --> Model Class Initialized
INFO - 2023-05-01 13:31:13 --> Model Class Initialized
INFO - 2023-05-01 13:31:13 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-05-01 13:31:13 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-05-01 13:31:13 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-05-01 13:31:13 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-05-01 13:31:13 --> Model Class Initialized
INFO - 2023-05-01 13:31:13 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-05-01 13:31:13 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-05-01 13:31:13 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-05-01 13:31:13 --> Final output sent to browser
DEBUG - 2023-05-01 13:31:13 --> Total execution time: 0.0723
ERROR - 2023-05-01 13:31:19 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-01 13:31:19 --> Config Class Initialized
INFO - 2023-05-01 13:31:19 --> Hooks Class Initialized
DEBUG - 2023-05-01 13:31:19 --> UTF-8 Support Enabled
INFO - 2023-05-01 13:31:19 --> Utf8 Class Initialized
INFO - 2023-05-01 13:31:19 --> URI Class Initialized
INFO - 2023-05-01 13:31:19 --> Router Class Initialized
INFO - 2023-05-01 13:31:19 --> Output Class Initialized
INFO - 2023-05-01 13:31:19 --> Security Class Initialized
DEBUG - 2023-05-01 13:31:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-01 13:31:19 --> Input Class Initialized
INFO - 2023-05-01 13:31:19 --> Language Class Initialized
INFO - 2023-05-01 13:31:19 --> Loader Class Initialized
INFO - 2023-05-01 13:31:19 --> Helper loaded: url_helper
INFO - 2023-05-01 13:31:19 --> Helper loaded: file_helper
INFO - 2023-05-01 13:31:19 --> Helper loaded: html_helper
INFO - 2023-05-01 13:31:19 --> Helper loaded: text_helper
INFO - 2023-05-01 13:31:19 --> Helper loaded: form_helper
INFO - 2023-05-01 13:31:19 --> Helper loaded: lang_helper
INFO - 2023-05-01 13:31:19 --> Helper loaded: security_helper
INFO - 2023-05-01 13:31:19 --> Helper loaded: cookie_helper
INFO - 2023-05-01 13:31:19 --> Database Driver Class Initialized
INFO - 2023-05-01 13:31:19 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-01 13:31:19 --> Parser Class Initialized
INFO - 2023-05-01 13:31:19 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-01 13:31:19 --> Pagination Class Initialized
INFO - 2023-05-01 13:31:19 --> Form Validation Class Initialized
INFO - 2023-05-01 13:31:19 --> Controller Class Initialized
INFO - 2023-05-01 13:31:19 --> Model Class Initialized
DEBUG - 2023-05-01 13:31:19 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-05-01 13:31:19 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-01 13:31:19 --> Model Class Initialized
INFO - 2023-05-01 13:31:19 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/stockrequest/inventory.php
DEBUG - 2023-05-01 13:31:19 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-05-01 13:31:19 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-05-01 13:31:19 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-05-01 13:31:19 --> Model Class Initialized
INFO - 2023-05-01 13:31:19 --> Model Class Initialized
INFO - 2023-05-01 13:31:19 --> Model Class Initialized
INFO - 2023-05-01 13:31:19 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-05-01 13:31:19 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-05-01 13:31:19 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-05-01 13:31:19 --> Final output sent to browser
DEBUG - 2023-05-01 13:31:19 --> Total execution time: 0.0576
ERROR - 2023-05-01 13:31:20 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-01 13:31:20 --> Config Class Initialized
INFO - 2023-05-01 13:31:20 --> Hooks Class Initialized
DEBUG - 2023-05-01 13:31:20 --> UTF-8 Support Enabled
INFO - 2023-05-01 13:31:20 --> Utf8 Class Initialized
INFO - 2023-05-01 13:31:20 --> URI Class Initialized
INFO - 2023-05-01 13:31:20 --> Router Class Initialized
INFO - 2023-05-01 13:31:20 --> Output Class Initialized
INFO - 2023-05-01 13:31:20 --> Security Class Initialized
DEBUG - 2023-05-01 13:31:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-01 13:31:20 --> Input Class Initialized
INFO - 2023-05-01 13:31:20 --> Language Class Initialized
INFO - 2023-05-01 13:31:20 --> Loader Class Initialized
INFO - 2023-05-01 13:31:20 --> Helper loaded: url_helper
INFO - 2023-05-01 13:31:20 --> Helper loaded: file_helper
INFO - 2023-05-01 13:31:20 --> Helper loaded: html_helper
INFO - 2023-05-01 13:31:20 --> Helper loaded: text_helper
INFO - 2023-05-01 13:31:20 --> Helper loaded: form_helper
INFO - 2023-05-01 13:31:20 --> Helper loaded: lang_helper
INFO - 2023-05-01 13:31:20 --> Helper loaded: security_helper
INFO - 2023-05-01 13:31:20 --> Helper loaded: cookie_helper
INFO - 2023-05-01 13:31:20 --> Database Driver Class Initialized
INFO - 2023-05-01 13:31:20 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-01 13:31:20 --> Parser Class Initialized
INFO - 2023-05-01 13:31:20 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-01 13:31:20 --> Pagination Class Initialized
INFO - 2023-05-01 13:31:20 --> Form Validation Class Initialized
INFO - 2023-05-01 13:31:20 --> Controller Class Initialized
INFO - 2023-05-01 13:31:20 --> Model Class Initialized
DEBUG - 2023-05-01 13:31:20 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-05-01 13:31:20 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-01 13:31:20 --> Model Class Initialized
INFO - 2023-05-01 13:31:20 --> Final output sent to browser
DEBUG - 2023-05-01 13:31:20 --> Total execution time: 0.0215
ERROR - 2023-05-01 13:31:41 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-01 13:31:41 --> Config Class Initialized
INFO - 2023-05-01 13:31:41 --> Hooks Class Initialized
DEBUG - 2023-05-01 13:31:41 --> UTF-8 Support Enabled
INFO - 2023-05-01 13:31:41 --> Utf8 Class Initialized
INFO - 2023-05-01 13:31:41 --> URI Class Initialized
INFO - 2023-05-01 13:31:41 --> Router Class Initialized
INFO - 2023-05-01 13:31:41 --> Output Class Initialized
INFO - 2023-05-01 13:31:41 --> Security Class Initialized
DEBUG - 2023-05-01 13:31:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-01 13:31:41 --> Input Class Initialized
INFO - 2023-05-01 13:31:41 --> Language Class Initialized
INFO - 2023-05-01 13:31:41 --> Loader Class Initialized
INFO - 2023-05-01 13:31:41 --> Helper loaded: url_helper
INFO - 2023-05-01 13:31:41 --> Helper loaded: file_helper
INFO - 2023-05-01 13:31:41 --> Helper loaded: html_helper
INFO - 2023-05-01 13:31:41 --> Helper loaded: text_helper
INFO - 2023-05-01 13:31:41 --> Helper loaded: form_helper
INFO - 2023-05-01 13:31:41 --> Helper loaded: lang_helper
INFO - 2023-05-01 13:31:41 --> Helper loaded: security_helper
INFO - 2023-05-01 13:31:41 --> Helper loaded: cookie_helper
INFO - 2023-05-01 13:31:41 --> Database Driver Class Initialized
INFO - 2023-05-01 13:31:41 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-01 13:31:41 --> Parser Class Initialized
INFO - 2023-05-01 13:31:41 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-01 13:31:41 --> Pagination Class Initialized
INFO - 2023-05-01 13:31:41 --> Form Validation Class Initialized
INFO - 2023-05-01 13:31:41 --> Controller Class Initialized
INFO - 2023-05-01 13:31:41 --> Model Class Initialized
DEBUG - 2023-05-01 13:31:41 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-05-01 13:31:41 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-01 13:31:41 --> Model Class Initialized
INFO - 2023-05-01 13:31:41 --> Final output sent to browser
DEBUG - 2023-05-01 13:31:41 --> Total execution time: 0.0223
ERROR - 2023-05-01 13:31:53 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-01 13:31:53 --> Config Class Initialized
INFO - 2023-05-01 13:31:53 --> Hooks Class Initialized
DEBUG - 2023-05-01 13:31:53 --> UTF-8 Support Enabled
INFO - 2023-05-01 13:31:53 --> Utf8 Class Initialized
INFO - 2023-05-01 13:31:53 --> URI Class Initialized
DEBUG - 2023-05-01 13:31:53 --> No URI present. Default controller set.
INFO - 2023-05-01 13:31:53 --> Router Class Initialized
INFO - 2023-05-01 13:31:53 --> Output Class Initialized
INFO - 2023-05-01 13:31:53 --> Security Class Initialized
DEBUG - 2023-05-01 13:31:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-01 13:31:53 --> Input Class Initialized
INFO - 2023-05-01 13:31:53 --> Language Class Initialized
INFO - 2023-05-01 13:31:53 --> Loader Class Initialized
INFO - 2023-05-01 13:31:53 --> Helper loaded: url_helper
INFO - 2023-05-01 13:31:53 --> Helper loaded: file_helper
INFO - 2023-05-01 13:31:53 --> Helper loaded: html_helper
INFO - 2023-05-01 13:31:53 --> Helper loaded: text_helper
INFO - 2023-05-01 13:31:53 --> Helper loaded: form_helper
INFO - 2023-05-01 13:31:53 --> Helper loaded: lang_helper
INFO - 2023-05-01 13:31:53 --> Helper loaded: security_helper
INFO - 2023-05-01 13:31:53 --> Helper loaded: cookie_helper
INFO - 2023-05-01 13:31:53 --> Database Driver Class Initialized
INFO - 2023-05-01 13:31:53 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-01 13:31:53 --> Parser Class Initialized
INFO - 2023-05-01 13:31:53 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-01 13:31:53 --> Pagination Class Initialized
INFO - 2023-05-01 13:31:53 --> Form Validation Class Initialized
INFO - 2023-05-01 13:31:53 --> Controller Class Initialized
INFO - 2023-05-01 13:31:53 --> Model Class Initialized
DEBUG - 2023-05-01 13:31:53 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-01 13:31:53 --> Model Class Initialized
DEBUG - 2023-05-01 13:31:53 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-01 13:31:53 --> Model Class Initialized
INFO - 2023-05-01 13:31:53 --> Model Class Initialized
INFO - 2023-05-01 13:31:53 --> Model Class Initialized
INFO - 2023-05-01 13:31:53 --> Model Class Initialized
DEBUG - 2023-05-01 13:31:53 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-05-01 13:31:53 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-01 13:31:53 --> Model Class Initialized
INFO - 2023-05-01 13:31:53 --> Model Class Initialized
INFO - 2023-05-01 13:31:53 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-05-01 13:31:53 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-05-01 13:31:53 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-05-01 13:31:53 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-05-01 13:31:53 --> Model Class Initialized
INFO - 2023-05-01 13:31:53 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-05-01 13:31:53 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-05-01 13:31:53 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-05-01 13:31:53 --> Final output sent to browser
DEBUG - 2023-05-01 13:31:53 --> Total execution time: 0.0683
ERROR - 2023-05-01 13:32:03 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-01 13:32:03 --> Config Class Initialized
INFO - 2023-05-01 13:32:03 --> Hooks Class Initialized
DEBUG - 2023-05-01 13:32:03 --> UTF-8 Support Enabled
INFO - 2023-05-01 13:32:03 --> Utf8 Class Initialized
INFO - 2023-05-01 13:32:03 --> URI Class Initialized
INFO - 2023-05-01 13:32:03 --> Router Class Initialized
INFO - 2023-05-01 13:32:03 --> Output Class Initialized
INFO - 2023-05-01 13:32:03 --> Security Class Initialized
DEBUG - 2023-05-01 13:32:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-01 13:32:03 --> Input Class Initialized
INFO - 2023-05-01 13:32:03 --> Language Class Initialized
INFO - 2023-05-01 13:32:03 --> Loader Class Initialized
INFO - 2023-05-01 13:32:03 --> Helper loaded: url_helper
INFO - 2023-05-01 13:32:03 --> Helper loaded: file_helper
INFO - 2023-05-01 13:32:03 --> Helper loaded: html_helper
INFO - 2023-05-01 13:32:03 --> Helper loaded: text_helper
INFO - 2023-05-01 13:32:03 --> Helper loaded: form_helper
INFO - 2023-05-01 13:32:03 --> Helper loaded: lang_helper
INFO - 2023-05-01 13:32:03 --> Helper loaded: security_helper
INFO - 2023-05-01 13:32:03 --> Helper loaded: cookie_helper
INFO - 2023-05-01 13:32:03 --> Database Driver Class Initialized
INFO - 2023-05-01 13:32:03 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-01 13:32:03 --> Parser Class Initialized
INFO - 2023-05-01 13:32:03 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-01 13:32:03 --> Pagination Class Initialized
INFO - 2023-05-01 13:32:03 --> Form Validation Class Initialized
INFO - 2023-05-01 13:32:03 --> Controller Class Initialized
INFO - 2023-05-01 13:32:03 --> Model Class Initialized
DEBUG - 2023-05-01 13:32:03 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-05-01 13:32:03 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-01 13:32:03 --> Model Class Initialized
INFO - 2023-05-01 13:32:03 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/stockrequest/inventory.php
DEBUG - 2023-05-01 13:32:03 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-05-01 13:32:03 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-05-01 13:32:03 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-05-01 13:32:03 --> Model Class Initialized
INFO - 2023-05-01 13:32:03 --> Model Class Initialized
INFO - 2023-05-01 13:32:03 --> Model Class Initialized
INFO - 2023-05-01 13:32:03 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-05-01 13:32:03 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-05-01 13:32:03 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-05-01 13:32:03 --> Final output sent to browser
DEBUG - 2023-05-01 13:32:03 --> Total execution time: 0.0579
ERROR - 2023-05-01 13:32:04 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-01 13:32:04 --> Config Class Initialized
INFO - 2023-05-01 13:32:04 --> Hooks Class Initialized
DEBUG - 2023-05-01 13:32:04 --> UTF-8 Support Enabled
INFO - 2023-05-01 13:32:04 --> Utf8 Class Initialized
INFO - 2023-05-01 13:32:04 --> URI Class Initialized
INFO - 2023-05-01 13:32:04 --> Router Class Initialized
INFO - 2023-05-01 13:32:04 --> Output Class Initialized
INFO - 2023-05-01 13:32:04 --> Security Class Initialized
DEBUG - 2023-05-01 13:32:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-01 13:32:04 --> Input Class Initialized
INFO - 2023-05-01 13:32:04 --> Language Class Initialized
INFO - 2023-05-01 13:32:04 --> Loader Class Initialized
INFO - 2023-05-01 13:32:04 --> Helper loaded: url_helper
INFO - 2023-05-01 13:32:04 --> Helper loaded: file_helper
INFO - 2023-05-01 13:32:04 --> Helper loaded: html_helper
INFO - 2023-05-01 13:32:04 --> Helper loaded: text_helper
INFO - 2023-05-01 13:32:04 --> Helper loaded: form_helper
INFO - 2023-05-01 13:32:04 --> Helper loaded: lang_helper
INFO - 2023-05-01 13:32:04 --> Helper loaded: security_helper
INFO - 2023-05-01 13:32:04 --> Helper loaded: cookie_helper
INFO - 2023-05-01 13:32:04 --> Database Driver Class Initialized
INFO - 2023-05-01 13:32:04 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-01 13:32:04 --> Parser Class Initialized
INFO - 2023-05-01 13:32:04 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-01 13:32:04 --> Pagination Class Initialized
INFO - 2023-05-01 13:32:04 --> Form Validation Class Initialized
INFO - 2023-05-01 13:32:04 --> Controller Class Initialized
INFO - 2023-05-01 13:32:04 --> Model Class Initialized
DEBUG - 2023-05-01 13:32:04 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-05-01 13:32:04 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-01 13:32:04 --> Model Class Initialized
INFO - 2023-05-01 13:32:04 --> Final output sent to browser
DEBUG - 2023-05-01 13:32:04 --> Total execution time: 0.0189
ERROR - 2023-05-01 16:54:48 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-01 16:54:48 --> Config Class Initialized
INFO - 2023-05-01 16:54:48 --> Hooks Class Initialized
DEBUG - 2023-05-01 16:54:48 --> UTF-8 Support Enabled
INFO - 2023-05-01 16:54:48 --> Utf8 Class Initialized
INFO - 2023-05-01 16:54:48 --> URI Class Initialized
DEBUG - 2023-05-01 16:54:48 --> No URI present. Default controller set.
INFO - 2023-05-01 16:54:48 --> Router Class Initialized
INFO - 2023-05-01 16:54:48 --> Output Class Initialized
INFO - 2023-05-01 16:54:48 --> Security Class Initialized
DEBUG - 2023-05-01 16:54:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-01 16:54:48 --> Input Class Initialized
INFO - 2023-05-01 16:54:48 --> Language Class Initialized
INFO - 2023-05-01 16:54:48 --> Loader Class Initialized
INFO - 2023-05-01 16:54:48 --> Helper loaded: url_helper
INFO - 2023-05-01 16:54:48 --> Helper loaded: file_helper
INFO - 2023-05-01 16:54:48 --> Helper loaded: html_helper
INFO - 2023-05-01 16:54:48 --> Helper loaded: text_helper
INFO - 2023-05-01 16:54:48 --> Helper loaded: form_helper
INFO - 2023-05-01 16:54:48 --> Helper loaded: lang_helper
INFO - 2023-05-01 16:54:48 --> Helper loaded: security_helper
INFO - 2023-05-01 16:54:48 --> Helper loaded: cookie_helper
INFO - 2023-05-01 16:54:48 --> Database Driver Class Initialized
INFO - 2023-05-01 16:54:48 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-01 16:54:48 --> Parser Class Initialized
INFO - 2023-05-01 16:54:48 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-01 16:54:48 --> Pagination Class Initialized
INFO - 2023-05-01 16:54:48 --> Form Validation Class Initialized
INFO - 2023-05-01 16:54:48 --> Controller Class Initialized
INFO - 2023-05-01 16:54:48 --> Model Class Initialized
DEBUG - 2023-05-01 16:54:48 --> Session class already loaded. Second attempt ignored.
ERROR - 2023-05-01 16:54:49 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-01 16:54:49 --> Config Class Initialized
INFO - 2023-05-01 16:54:49 --> Hooks Class Initialized
DEBUG - 2023-05-01 16:54:49 --> UTF-8 Support Enabled
INFO - 2023-05-01 16:54:49 --> Utf8 Class Initialized
INFO - 2023-05-01 16:54:49 --> URI Class Initialized
INFO - 2023-05-01 16:54:49 --> Router Class Initialized
INFO - 2023-05-01 16:54:49 --> Output Class Initialized
INFO - 2023-05-01 16:54:49 --> Security Class Initialized
DEBUG - 2023-05-01 16:54:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-01 16:54:49 --> Input Class Initialized
INFO - 2023-05-01 16:54:49 --> Language Class Initialized
INFO - 2023-05-01 16:54:49 --> Loader Class Initialized
INFO - 2023-05-01 16:54:49 --> Helper loaded: url_helper
INFO - 2023-05-01 16:54:49 --> Helper loaded: file_helper
INFO - 2023-05-01 16:54:49 --> Helper loaded: html_helper
INFO - 2023-05-01 16:54:49 --> Helper loaded: text_helper
INFO - 2023-05-01 16:54:49 --> Helper loaded: form_helper
INFO - 2023-05-01 16:54:49 --> Helper loaded: lang_helper
INFO - 2023-05-01 16:54:49 --> Helper loaded: security_helper
INFO - 2023-05-01 16:54:49 --> Helper loaded: cookie_helper
INFO - 2023-05-01 16:54:49 --> Database Driver Class Initialized
INFO - 2023-05-01 16:54:49 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-01 16:54:49 --> Parser Class Initialized
INFO - 2023-05-01 16:54:49 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-01 16:54:49 --> Pagination Class Initialized
INFO - 2023-05-01 16:54:49 --> Form Validation Class Initialized
INFO - 2023-05-01 16:54:49 --> Controller Class Initialized
INFO - 2023-05-01 16:54:49 --> Model Class Initialized
DEBUG - 2023-05-01 16:54:49 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-01 16:54:49 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2023-05-01 16:54:49 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-05-01 16:54:49 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-05-01 16:54:49 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-05-01 16:54:49 --> Model Class Initialized
INFO - 2023-05-01 16:54:49 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-05-01 16:54:49 --> Final output sent to browser
DEBUG - 2023-05-01 16:54:49 --> Total execution time: 0.0275
ERROR - 2023-05-01 16:56:06 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-01 16:56:06 --> Config Class Initialized
INFO - 2023-05-01 16:56:06 --> Hooks Class Initialized
DEBUG - 2023-05-01 16:56:06 --> UTF-8 Support Enabled
INFO - 2023-05-01 16:56:06 --> Utf8 Class Initialized
INFO - 2023-05-01 16:56:06 --> URI Class Initialized
INFO - 2023-05-01 16:56:06 --> Router Class Initialized
INFO - 2023-05-01 16:56:06 --> Output Class Initialized
INFO - 2023-05-01 16:56:06 --> Security Class Initialized
DEBUG - 2023-05-01 16:56:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-01 16:56:06 --> Input Class Initialized
INFO - 2023-05-01 16:56:06 --> Language Class Initialized
INFO - 2023-05-01 16:56:06 --> Loader Class Initialized
INFO - 2023-05-01 16:56:06 --> Helper loaded: url_helper
INFO - 2023-05-01 16:56:06 --> Helper loaded: file_helper
INFO - 2023-05-01 16:56:06 --> Helper loaded: html_helper
INFO - 2023-05-01 16:56:06 --> Helper loaded: text_helper
INFO - 2023-05-01 16:56:06 --> Helper loaded: form_helper
INFO - 2023-05-01 16:56:06 --> Helper loaded: lang_helper
INFO - 2023-05-01 16:56:06 --> Helper loaded: security_helper
INFO - 2023-05-01 16:56:06 --> Helper loaded: cookie_helper
INFO - 2023-05-01 16:56:06 --> Database Driver Class Initialized
INFO - 2023-05-01 16:56:06 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-01 16:56:06 --> Parser Class Initialized
INFO - 2023-05-01 16:56:06 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-01 16:56:06 --> Pagination Class Initialized
INFO - 2023-05-01 16:56:06 --> Form Validation Class Initialized
INFO - 2023-05-01 16:56:06 --> Controller Class Initialized
INFO - 2023-05-01 16:56:06 --> Model Class Initialized
DEBUG - 2023-05-01 16:56:06 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-01 16:56:06 --> Model Class Initialized
INFO - 2023-05-01 16:56:06 --> Final output sent to browser
DEBUG - 2023-05-01 16:56:06 --> Total execution time: 0.0197
ERROR - 2023-05-01 16:56:06 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-01 16:56:06 --> Config Class Initialized
INFO - 2023-05-01 16:56:06 --> Hooks Class Initialized
DEBUG - 2023-05-01 16:56:06 --> UTF-8 Support Enabled
INFO - 2023-05-01 16:56:06 --> Utf8 Class Initialized
INFO - 2023-05-01 16:56:06 --> URI Class Initialized
DEBUG - 2023-05-01 16:56:06 --> No URI present. Default controller set.
INFO - 2023-05-01 16:56:06 --> Router Class Initialized
INFO - 2023-05-01 16:56:06 --> Output Class Initialized
INFO - 2023-05-01 16:56:06 --> Security Class Initialized
DEBUG - 2023-05-01 16:56:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-01 16:56:06 --> Input Class Initialized
INFO - 2023-05-01 16:56:06 --> Language Class Initialized
INFO - 2023-05-01 16:56:06 --> Loader Class Initialized
INFO - 2023-05-01 16:56:06 --> Helper loaded: url_helper
INFO - 2023-05-01 16:56:06 --> Helper loaded: file_helper
INFO - 2023-05-01 16:56:06 --> Helper loaded: html_helper
INFO - 2023-05-01 16:56:06 --> Helper loaded: text_helper
INFO - 2023-05-01 16:56:06 --> Helper loaded: form_helper
INFO - 2023-05-01 16:56:06 --> Helper loaded: lang_helper
INFO - 2023-05-01 16:56:06 --> Helper loaded: security_helper
INFO - 2023-05-01 16:56:06 --> Helper loaded: cookie_helper
INFO - 2023-05-01 16:56:06 --> Database Driver Class Initialized
INFO - 2023-05-01 16:56:06 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-01 16:56:06 --> Parser Class Initialized
INFO - 2023-05-01 16:56:06 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-01 16:56:06 --> Pagination Class Initialized
INFO - 2023-05-01 16:56:06 --> Form Validation Class Initialized
INFO - 2023-05-01 16:56:06 --> Controller Class Initialized
INFO - 2023-05-01 16:56:06 --> Model Class Initialized
DEBUG - 2023-05-01 16:56:06 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-01 16:56:06 --> Model Class Initialized
DEBUG - 2023-05-01 16:56:06 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-01 16:56:06 --> Model Class Initialized
INFO - 2023-05-01 16:56:06 --> Model Class Initialized
INFO - 2023-05-01 16:56:06 --> Model Class Initialized
INFO - 2023-05-01 16:56:06 --> Model Class Initialized
DEBUG - 2023-05-01 16:56:06 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-05-01 16:56:06 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-01 16:56:06 --> Model Class Initialized
INFO - 2023-05-01 16:56:06 --> Model Class Initialized
INFO - 2023-05-01 16:56:06 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-05-01 16:56:06 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-05-01 16:56:06 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-05-01 16:56:06 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-05-01 16:56:06 --> Model Class Initialized
INFO - 2023-05-01 16:56:06 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-05-01 16:56:06 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-05-01 16:56:06 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-05-01 16:56:06 --> Final output sent to browser
DEBUG - 2023-05-01 16:56:06 --> Total execution time: 0.0688
ERROR - 2023-05-01 16:56:14 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-01 16:56:14 --> Config Class Initialized
INFO - 2023-05-01 16:56:14 --> Hooks Class Initialized
DEBUG - 2023-05-01 16:56:14 --> UTF-8 Support Enabled
INFO - 2023-05-01 16:56:14 --> Utf8 Class Initialized
INFO - 2023-05-01 16:56:14 --> URI Class Initialized
INFO - 2023-05-01 16:56:14 --> Router Class Initialized
INFO - 2023-05-01 16:56:14 --> Output Class Initialized
INFO - 2023-05-01 16:56:14 --> Security Class Initialized
DEBUG - 2023-05-01 16:56:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-01 16:56:14 --> Input Class Initialized
INFO - 2023-05-01 16:56:14 --> Language Class Initialized
INFO - 2023-05-01 16:56:14 --> Loader Class Initialized
INFO - 2023-05-01 16:56:14 --> Helper loaded: url_helper
INFO - 2023-05-01 16:56:14 --> Helper loaded: file_helper
INFO - 2023-05-01 16:56:14 --> Helper loaded: html_helper
INFO - 2023-05-01 16:56:14 --> Helper loaded: text_helper
INFO - 2023-05-01 16:56:14 --> Helper loaded: form_helper
INFO - 2023-05-01 16:56:14 --> Helper loaded: lang_helper
INFO - 2023-05-01 16:56:14 --> Helper loaded: security_helper
INFO - 2023-05-01 16:56:14 --> Helper loaded: cookie_helper
INFO - 2023-05-01 16:56:14 --> Database Driver Class Initialized
INFO - 2023-05-01 16:56:14 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-01 16:56:14 --> Parser Class Initialized
INFO - 2023-05-01 16:56:14 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-01 16:56:14 --> Pagination Class Initialized
INFO - 2023-05-01 16:56:14 --> Form Validation Class Initialized
INFO - 2023-05-01 16:56:14 --> Controller Class Initialized
INFO - 2023-05-01 16:56:14 --> Model Class Initialized
DEBUG - 2023-05-01 16:56:14 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-05-01 16:56:14 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-01 16:56:14 --> Model Class Initialized
INFO - 2023-05-01 16:56:14 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/stockrequest/upcoming.php
DEBUG - 2023-05-01 16:56:14 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-05-01 16:56:14 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-05-01 16:56:14 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-05-01 16:56:14 --> Model Class Initialized
INFO - 2023-05-01 16:56:14 --> Model Class Initialized
INFO - 2023-05-01 16:56:14 --> Model Class Initialized
INFO - 2023-05-01 16:56:14 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-05-01 16:56:14 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-05-01 16:56:14 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-05-01 16:56:14 --> Final output sent to browser
DEBUG - 2023-05-01 16:56:14 --> Total execution time: 0.0568
ERROR - 2023-05-01 16:56:15 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-01 16:56:15 --> Config Class Initialized
INFO - 2023-05-01 16:56:15 --> Hooks Class Initialized
DEBUG - 2023-05-01 16:56:15 --> UTF-8 Support Enabled
INFO - 2023-05-01 16:56:15 --> Utf8 Class Initialized
INFO - 2023-05-01 16:56:15 --> URI Class Initialized
INFO - 2023-05-01 16:56:15 --> Router Class Initialized
INFO - 2023-05-01 16:56:15 --> Output Class Initialized
INFO - 2023-05-01 16:56:15 --> Security Class Initialized
DEBUG - 2023-05-01 16:56:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-01 16:56:15 --> Input Class Initialized
INFO - 2023-05-01 16:56:15 --> Language Class Initialized
INFO - 2023-05-01 16:56:15 --> Loader Class Initialized
INFO - 2023-05-01 16:56:15 --> Helper loaded: url_helper
INFO - 2023-05-01 16:56:15 --> Helper loaded: file_helper
INFO - 2023-05-01 16:56:15 --> Helper loaded: html_helper
INFO - 2023-05-01 16:56:15 --> Helper loaded: text_helper
INFO - 2023-05-01 16:56:15 --> Helper loaded: form_helper
INFO - 2023-05-01 16:56:15 --> Helper loaded: lang_helper
INFO - 2023-05-01 16:56:15 --> Helper loaded: security_helper
INFO - 2023-05-01 16:56:15 --> Helper loaded: cookie_helper
INFO - 2023-05-01 16:56:15 --> Database Driver Class Initialized
INFO - 2023-05-01 16:56:15 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-01 16:56:15 --> Parser Class Initialized
INFO - 2023-05-01 16:56:15 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-01 16:56:15 --> Pagination Class Initialized
INFO - 2023-05-01 16:56:15 --> Form Validation Class Initialized
INFO - 2023-05-01 16:56:15 --> Controller Class Initialized
INFO - 2023-05-01 16:56:15 --> Model Class Initialized
DEBUG - 2023-05-01 16:56:15 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-05-01 16:56:15 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-01 16:56:15 --> Model Class Initialized
INFO - 2023-05-01 16:56:15 --> Final output sent to browser
DEBUG - 2023-05-01 16:56:15 --> Total execution time: 0.0164
ERROR - 2023-05-01 16:56:17 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-01 16:56:17 --> Config Class Initialized
INFO - 2023-05-01 16:56:17 --> Hooks Class Initialized
DEBUG - 2023-05-01 16:56:17 --> UTF-8 Support Enabled
INFO - 2023-05-01 16:56:17 --> Utf8 Class Initialized
INFO - 2023-05-01 16:56:17 --> URI Class Initialized
INFO - 2023-05-01 16:56:17 --> Router Class Initialized
INFO - 2023-05-01 16:56:17 --> Output Class Initialized
INFO - 2023-05-01 16:56:17 --> Security Class Initialized
DEBUG - 2023-05-01 16:56:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-01 16:56:17 --> Input Class Initialized
INFO - 2023-05-01 16:56:17 --> Language Class Initialized
INFO - 2023-05-01 16:56:17 --> Loader Class Initialized
INFO - 2023-05-01 16:56:17 --> Helper loaded: url_helper
INFO - 2023-05-01 16:56:17 --> Helper loaded: file_helper
INFO - 2023-05-01 16:56:17 --> Helper loaded: html_helper
INFO - 2023-05-01 16:56:17 --> Helper loaded: text_helper
INFO - 2023-05-01 16:56:17 --> Helper loaded: form_helper
INFO - 2023-05-01 16:56:17 --> Helper loaded: lang_helper
INFO - 2023-05-01 16:56:17 --> Helper loaded: security_helper
INFO - 2023-05-01 16:56:17 --> Helper loaded: cookie_helper
INFO - 2023-05-01 16:56:17 --> Database Driver Class Initialized
INFO - 2023-05-01 16:56:17 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-01 16:56:17 --> Parser Class Initialized
INFO - 2023-05-01 16:56:17 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-01 16:56:17 --> Pagination Class Initialized
INFO - 2023-05-01 16:56:17 --> Form Validation Class Initialized
INFO - 2023-05-01 16:56:17 --> Controller Class Initialized
INFO - 2023-05-01 16:56:17 --> Model Class Initialized
DEBUG - 2023-05-01 16:56:17 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-05-01 16:56:17 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-01 16:56:17 --> Model Class Initialized
INFO - 2023-05-01 16:56:17 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/stockrequest/inventory.php
DEBUG - 2023-05-01 16:56:17 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-05-01 16:56:17 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-05-01 16:56:17 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-05-01 16:56:17 --> Model Class Initialized
INFO - 2023-05-01 16:56:17 --> Model Class Initialized
INFO - 2023-05-01 16:56:17 --> Model Class Initialized
INFO - 2023-05-01 16:56:17 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-05-01 16:56:17 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-05-01 16:56:17 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-05-01 16:56:17 --> Final output sent to browser
DEBUG - 2023-05-01 16:56:17 --> Total execution time: 0.0650
ERROR - 2023-05-01 16:56:18 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-01 16:56:18 --> Config Class Initialized
INFO - 2023-05-01 16:56:18 --> Hooks Class Initialized
DEBUG - 2023-05-01 16:56:18 --> UTF-8 Support Enabled
INFO - 2023-05-01 16:56:18 --> Utf8 Class Initialized
INFO - 2023-05-01 16:56:18 --> URI Class Initialized
INFO - 2023-05-01 16:56:18 --> Router Class Initialized
INFO - 2023-05-01 16:56:18 --> Output Class Initialized
INFO - 2023-05-01 16:56:18 --> Security Class Initialized
DEBUG - 2023-05-01 16:56:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-01 16:56:18 --> Input Class Initialized
INFO - 2023-05-01 16:56:18 --> Language Class Initialized
INFO - 2023-05-01 16:56:18 --> Loader Class Initialized
INFO - 2023-05-01 16:56:18 --> Helper loaded: url_helper
INFO - 2023-05-01 16:56:18 --> Helper loaded: file_helper
INFO - 2023-05-01 16:56:18 --> Helper loaded: html_helper
INFO - 2023-05-01 16:56:18 --> Helper loaded: text_helper
INFO - 2023-05-01 16:56:18 --> Helper loaded: form_helper
INFO - 2023-05-01 16:56:18 --> Helper loaded: lang_helper
INFO - 2023-05-01 16:56:18 --> Helper loaded: security_helper
INFO - 2023-05-01 16:56:18 --> Helper loaded: cookie_helper
INFO - 2023-05-01 16:56:18 --> Database Driver Class Initialized
INFO - 2023-05-01 16:56:18 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-01 16:56:18 --> Parser Class Initialized
INFO - 2023-05-01 16:56:18 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-01 16:56:18 --> Pagination Class Initialized
INFO - 2023-05-01 16:56:18 --> Form Validation Class Initialized
INFO - 2023-05-01 16:56:18 --> Controller Class Initialized
INFO - 2023-05-01 16:56:18 --> Model Class Initialized
DEBUG - 2023-05-01 16:56:18 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-05-01 16:56:18 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-01 16:56:18 --> Model Class Initialized
INFO - 2023-05-01 16:56:18 --> Final output sent to browser
DEBUG - 2023-05-01 16:56:18 --> Total execution time: 0.0212
ERROR - 2023-05-01 17:13:36 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-01 17:13:36 --> Config Class Initialized
INFO - 2023-05-01 17:13:36 --> Hooks Class Initialized
DEBUG - 2023-05-01 17:13:36 --> UTF-8 Support Enabled
INFO - 2023-05-01 17:13:36 --> Utf8 Class Initialized
INFO - 2023-05-01 17:13:36 --> URI Class Initialized
INFO - 2023-05-01 17:13:36 --> Router Class Initialized
INFO - 2023-05-01 17:13:36 --> Output Class Initialized
INFO - 2023-05-01 17:13:36 --> Security Class Initialized
DEBUG - 2023-05-01 17:13:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-01 17:13:36 --> Input Class Initialized
INFO - 2023-05-01 17:13:36 --> Language Class Initialized
INFO - 2023-05-01 17:13:36 --> Loader Class Initialized
INFO - 2023-05-01 17:13:36 --> Helper loaded: url_helper
INFO - 2023-05-01 17:13:36 --> Helper loaded: file_helper
INFO - 2023-05-01 17:13:36 --> Helper loaded: html_helper
INFO - 2023-05-01 17:13:36 --> Helper loaded: text_helper
INFO - 2023-05-01 17:13:36 --> Helper loaded: form_helper
INFO - 2023-05-01 17:13:36 --> Helper loaded: lang_helper
INFO - 2023-05-01 17:13:36 --> Helper loaded: security_helper
INFO - 2023-05-01 17:13:36 --> Helper loaded: cookie_helper
INFO - 2023-05-01 17:13:36 --> Database Driver Class Initialized
INFO - 2023-05-01 17:13:36 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-01 17:13:36 --> Parser Class Initialized
INFO - 2023-05-01 17:13:36 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-01 17:13:36 --> Pagination Class Initialized
INFO - 2023-05-01 17:13:36 --> Form Validation Class Initialized
INFO - 2023-05-01 17:13:36 --> Controller Class Initialized
INFO - 2023-05-01 17:13:36 --> Model Class Initialized
DEBUG - 2023-05-01 17:13:36 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-01 17:13:36 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2023-05-01 17:13:36 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-05-01 17:13:36 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-05-01 17:13:36 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-05-01 17:13:36 --> Model Class Initialized
INFO - 2023-05-01 17:13:36 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-05-01 17:13:36 --> Final output sent to browser
DEBUG - 2023-05-01 17:13:36 --> Total execution time: 0.0302
ERROR - 2023-05-01 18:05:50 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-01 18:05:50 --> Config Class Initialized
INFO - 2023-05-01 18:05:50 --> Hooks Class Initialized
DEBUG - 2023-05-01 18:05:50 --> UTF-8 Support Enabled
INFO - 2023-05-01 18:05:50 --> Utf8 Class Initialized
INFO - 2023-05-01 18:05:50 --> URI Class Initialized
DEBUG - 2023-05-01 18:05:50 --> No URI present. Default controller set.
INFO - 2023-05-01 18:05:50 --> Router Class Initialized
INFO - 2023-05-01 18:05:50 --> Output Class Initialized
INFO - 2023-05-01 18:05:50 --> Security Class Initialized
DEBUG - 2023-05-01 18:05:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-01 18:05:50 --> Input Class Initialized
INFO - 2023-05-01 18:05:50 --> Language Class Initialized
INFO - 2023-05-01 18:05:50 --> Loader Class Initialized
INFO - 2023-05-01 18:05:50 --> Helper loaded: url_helper
INFO - 2023-05-01 18:05:50 --> Helper loaded: file_helper
INFO - 2023-05-01 18:05:50 --> Helper loaded: html_helper
INFO - 2023-05-01 18:05:50 --> Helper loaded: text_helper
INFO - 2023-05-01 18:05:50 --> Helper loaded: form_helper
INFO - 2023-05-01 18:05:50 --> Helper loaded: lang_helper
INFO - 2023-05-01 18:05:50 --> Helper loaded: security_helper
INFO - 2023-05-01 18:05:50 --> Helper loaded: cookie_helper
INFO - 2023-05-01 18:05:50 --> Database Driver Class Initialized
INFO - 2023-05-01 18:05:50 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-01 18:05:50 --> Parser Class Initialized
INFO - 2023-05-01 18:05:50 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-01 18:05:50 --> Pagination Class Initialized
INFO - 2023-05-01 18:05:50 --> Form Validation Class Initialized
INFO - 2023-05-01 18:05:50 --> Controller Class Initialized
INFO - 2023-05-01 18:05:50 --> Model Class Initialized
DEBUG - 2023-05-01 18:05:50 --> Session class already loaded. Second attempt ignored.
ERROR - 2023-05-01 18:05:50 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-01 18:05:50 --> Config Class Initialized
INFO - 2023-05-01 18:05:50 --> Hooks Class Initialized
DEBUG - 2023-05-01 18:05:50 --> UTF-8 Support Enabled
INFO - 2023-05-01 18:05:50 --> Utf8 Class Initialized
INFO - 2023-05-01 18:05:50 --> URI Class Initialized
INFO - 2023-05-01 18:05:50 --> Router Class Initialized
INFO - 2023-05-01 18:05:50 --> Output Class Initialized
INFO - 2023-05-01 18:05:50 --> Security Class Initialized
DEBUG - 2023-05-01 18:05:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-01 18:05:50 --> Input Class Initialized
INFO - 2023-05-01 18:05:50 --> Language Class Initialized
INFO - 2023-05-01 18:05:50 --> Loader Class Initialized
INFO - 2023-05-01 18:05:50 --> Helper loaded: url_helper
INFO - 2023-05-01 18:05:50 --> Helper loaded: file_helper
INFO - 2023-05-01 18:05:50 --> Helper loaded: html_helper
INFO - 2023-05-01 18:05:50 --> Helper loaded: text_helper
INFO - 2023-05-01 18:05:50 --> Helper loaded: form_helper
INFO - 2023-05-01 18:05:50 --> Helper loaded: lang_helper
INFO - 2023-05-01 18:05:50 --> Helper loaded: security_helper
INFO - 2023-05-01 18:05:50 --> Helper loaded: cookie_helper
INFO - 2023-05-01 18:05:50 --> Database Driver Class Initialized
INFO - 2023-05-01 18:05:50 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-01 18:05:50 --> Parser Class Initialized
INFO - 2023-05-01 18:05:50 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-01 18:05:50 --> Pagination Class Initialized
INFO - 2023-05-01 18:05:50 --> Form Validation Class Initialized
INFO - 2023-05-01 18:05:50 --> Controller Class Initialized
INFO - 2023-05-01 18:05:50 --> Model Class Initialized
DEBUG - 2023-05-01 18:05:50 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-01 18:05:50 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2023-05-01 18:05:50 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-05-01 18:05:50 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-05-01 18:05:50 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-05-01 18:05:50 --> Model Class Initialized
INFO - 2023-05-01 18:05:50 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-05-01 18:05:50 --> Final output sent to browser
DEBUG - 2023-05-01 18:05:50 --> Total execution time: 0.0281
ERROR - 2023-05-01 18:06:08 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-01 18:06:08 --> Config Class Initialized
INFO - 2023-05-01 18:06:08 --> Hooks Class Initialized
DEBUG - 2023-05-01 18:06:08 --> UTF-8 Support Enabled
INFO - 2023-05-01 18:06:08 --> Utf8 Class Initialized
INFO - 2023-05-01 18:06:08 --> URI Class Initialized
INFO - 2023-05-01 18:06:08 --> Router Class Initialized
INFO - 2023-05-01 18:06:08 --> Output Class Initialized
INFO - 2023-05-01 18:06:08 --> Security Class Initialized
DEBUG - 2023-05-01 18:06:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-01 18:06:08 --> Input Class Initialized
INFO - 2023-05-01 18:06:08 --> Language Class Initialized
INFO - 2023-05-01 18:06:08 --> Loader Class Initialized
INFO - 2023-05-01 18:06:08 --> Helper loaded: url_helper
INFO - 2023-05-01 18:06:08 --> Helper loaded: file_helper
INFO - 2023-05-01 18:06:08 --> Helper loaded: html_helper
INFO - 2023-05-01 18:06:08 --> Helper loaded: text_helper
INFO - 2023-05-01 18:06:08 --> Helper loaded: form_helper
INFO - 2023-05-01 18:06:08 --> Helper loaded: lang_helper
INFO - 2023-05-01 18:06:08 --> Helper loaded: security_helper
INFO - 2023-05-01 18:06:08 --> Helper loaded: cookie_helper
INFO - 2023-05-01 18:06:08 --> Database Driver Class Initialized
INFO - 2023-05-01 18:06:08 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-01 18:06:08 --> Parser Class Initialized
INFO - 2023-05-01 18:06:08 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-01 18:06:08 --> Pagination Class Initialized
INFO - 2023-05-01 18:06:08 --> Form Validation Class Initialized
INFO - 2023-05-01 18:06:08 --> Controller Class Initialized
INFO - 2023-05-01 18:06:08 --> Model Class Initialized
DEBUG - 2023-05-01 18:06:08 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-01 18:06:08 --> Model Class Initialized
INFO - 2023-05-01 18:06:08 --> Final output sent to browser
DEBUG - 2023-05-01 18:06:08 --> Total execution time: 0.0178
ERROR - 2023-05-01 18:06:09 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-01 18:06:09 --> Config Class Initialized
INFO - 2023-05-01 18:06:09 --> Hooks Class Initialized
DEBUG - 2023-05-01 18:06:09 --> UTF-8 Support Enabled
INFO - 2023-05-01 18:06:09 --> Utf8 Class Initialized
INFO - 2023-05-01 18:06:09 --> URI Class Initialized
DEBUG - 2023-05-01 18:06:09 --> No URI present. Default controller set.
INFO - 2023-05-01 18:06:09 --> Router Class Initialized
INFO - 2023-05-01 18:06:09 --> Output Class Initialized
INFO - 2023-05-01 18:06:09 --> Security Class Initialized
DEBUG - 2023-05-01 18:06:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-01 18:06:09 --> Input Class Initialized
INFO - 2023-05-01 18:06:09 --> Language Class Initialized
INFO - 2023-05-01 18:06:09 --> Loader Class Initialized
INFO - 2023-05-01 18:06:09 --> Helper loaded: url_helper
INFO - 2023-05-01 18:06:09 --> Helper loaded: file_helper
INFO - 2023-05-01 18:06:09 --> Helper loaded: html_helper
INFO - 2023-05-01 18:06:09 --> Helper loaded: text_helper
INFO - 2023-05-01 18:06:09 --> Helper loaded: form_helper
INFO - 2023-05-01 18:06:09 --> Helper loaded: lang_helper
INFO - 2023-05-01 18:06:09 --> Helper loaded: security_helper
INFO - 2023-05-01 18:06:09 --> Helper loaded: cookie_helper
INFO - 2023-05-01 18:06:09 --> Database Driver Class Initialized
INFO - 2023-05-01 18:06:09 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-01 18:06:09 --> Parser Class Initialized
INFO - 2023-05-01 18:06:09 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-01 18:06:09 --> Pagination Class Initialized
INFO - 2023-05-01 18:06:09 --> Form Validation Class Initialized
INFO - 2023-05-01 18:06:09 --> Controller Class Initialized
INFO - 2023-05-01 18:06:09 --> Model Class Initialized
DEBUG - 2023-05-01 18:06:09 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-01 18:06:09 --> Model Class Initialized
DEBUG - 2023-05-01 18:06:09 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-01 18:06:09 --> Model Class Initialized
INFO - 2023-05-01 18:06:09 --> Model Class Initialized
INFO - 2023-05-01 18:06:09 --> Model Class Initialized
INFO - 2023-05-01 18:06:09 --> Model Class Initialized
DEBUG - 2023-05-01 18:06:09 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-05-01 18:06:09 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-01 18:06:09 --> Model Class Initialized
INFO - 2023-05-01 18:06:09 --> Model Class Initialized
INFO - 2023-05-01 18:06:09 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-05-01 18:06:09 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-05-01 18:06:09 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-05-01 18:06:09 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-05-01 18:06:09 --> Model Class Initialized
INFO - 2023-05-01 18:06:09 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-05-01 18:06:09 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-05-01 18:06:09 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-05-01 18:06:09 --> Final output sent to browser
DEBUG - 2023-05-01 18:06:09 --> Total execution time: 0.1409
ERROR - 2023-05-01 18:06:10 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-01 18:06:10 --> Config Class Initialized
INFO - 2023-05-01 18:06:10 --> Hooks Class Initialized
DEBUG - 2023-05-01 18:06:10 --> UTF-8 Support Enabled
INFO - 2023-05-01 18:06:10 --> Utf8 Class Initialized
INFO - 2023-05-01 18:06:10 --> URI Class Initialized
INFO - 2023-05-01 18:06:10 --> Router Class Initialized
INFO - 2023-05-01 18:06:10 --> Output Class Initialized
INFO - 2023-05-01 18:06:10 --> Security Class Initialized
DEBUG - 2023-05-01 18:06:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-01 18:06:10 --> Input Class Initialized
INFO - 2023-05-01 18:06:10 --> Language Class Initialized
INFO - 2023-05-01 18:06:10 --> Loader Class Initialized
INFO - 2023-05-01 18:06:10 --> Helper loaded: url_helper
INFO - 2023-05-01 18:06:10 --> Helper loaded: file_helper
INFO - 2023-05-01 18:06:10 --> Helper loaded: html_helper
INFO - 2023-05-01 18:06:10 --> Helper loaded: text_helper
INFO - 2023-05-01 18:06:10 --> Helper loaded: form_helper
INFO - 2023-05-01 18:06:10 --> Helper loaded: lang_helper
INFO - 2023-05-01 18:06:10 --> Helper loaded: security_helper
INFO - 2023-05-01 18:06:10 --> Helper loaded: cookie_helper
INFO - 2023-05-01 18:06:10 --> Database Driver Class Initialized
INFO - 2023-05-01 18:06:10 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-01 18:06:10 --> Parser Class Initialized
INFO - 2023-05-01 18:06:10 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-01 18:06:10 --> Pagination Class Initialized
INFO - 2023-05-01 18:06:10 --> Form Validation Class Initialized
INFO - 2023-05-01 18:06:10 --> Controller Class Initialized
DEBUG - 2023-05-01 18:06:10 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-05-01 18:06:10 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-01 18:06:10 --> Model Class Initialized
INFO - 2023-05-01 18:06:10 --> Final output sent to browser
DEBUG - 2023-05-01 18:06:10 --> Total execution time: 0.0133
ERROR - 2023-05-01 18:06:46 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-01 18:06:46 --> Config Class Initialized
INFO - 2023-05-01 18:06:46 --> Hooks Class Initialized
DEBUG - 2023-05-01 18:06:46 --> UTF-8 Support Enabled
INFO - 2023-05-01 18:06:46 --> Utf8 Class Initialized
INFO - 2023-05-01 18:06:46 --> URI Class Initialized
INFO - 2023-05-01 18:06:46 --> Router Class Initialized
INFO - 2023-05-01 18:06:46 --> Output Class Initialized
INFO - 2023-05-01 18:06:46 --> Security Class Initialized
DEBUG - 2023-05-01 18:06:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-01 18:06:46 --> Input Class Initialized
INFO - 2023-05-01 18:06:46 --> Language Class Initialized
INFO - 2023-05-01 18:06:46 --> Loader Class Initialized
INFO - 2023-05-01 18:06:46 --> Helper loaded: url_helper
INFO - 2023-05-01 18:06:46 --> Helper loaded: file_helper
INFO - 2023-05-01 18:06:46 --> Helper loaded: html_helper
INFO - 2023-05-01 18:06:46 --> Helper loaded: text_helper
INFO - 2023-05-01 18:06:46 --> Helper loaded: form_helper
INFO - 2023-05-01 18:06:46 --> Helper loaded: lang_helper
INFO - 2023-05-01 18:06:46 --> Helper loaded: security_helper
INFO - 2023-05-01 18:06:46 --> Helper loaded: cookie_helper
INFO - 2023-05-01 18:06:46 --> Database Driver Class Initialized
INFO - 2023-05-01 18:06:46 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-01 18:06:46 --> Parser Class Initialized
INFO - 2023-05-01 18:06:46 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-01 18:06:46 --> Pagination Class Initialized
INFO - 2023-05-01 18:06:46 --> Form Validation Class Initialized
INFO - 2023-05-01 18:06:46 --> Controller Class Initialized
INFO - 2023-05-01 18:06:46 --> Model Class Initialized
INFO - 2023-05-01 18:06:46 --> Model Class Initialized
INFO - 2023-05-01 18:06:46 --> Model Class Initialized
INFO - 2023-05-01 18:06:46 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/report/stock_report_batch_wise.php
DEBUG - 2023-05-01 18:06:46 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-05-01 18:06:46 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-05-01 18:06:46 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-05-01 18:06:46 --> Model Class Initialized
INFO - 2023-05-01 18:06:46 --> Model Class Initialized
INFO - 2023-05-01 18:06:46 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-05-01 18:06:46 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-05-01 18:06:46 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-05-01 18:06:46 --> Final output sent to browser
DEBUG - 2023-05-01 18:06:46 --> Total execution time: 0.1192
ERROR - 2023-05-01 18:06:48 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-01 18:06:48 --> Config Class Initialized
INFO - 2023-05-01 18:06:48 --> Hooks Class Initialized
DEBUG - 2023-05-01 18:06:48 --> UTF-8 Support Enabled
INFO - 2023-05-01 18:06:48 --> Utf8 Class Initialized
INFO - 2023-05-01 18:06:48 --> URI Class Initialized
INFO - 2023-05-01 18:06:48 --> Router Class Initialized
INFO - 2023-05-01 18:06:48 --> Output Class Initialized
INFO - 2023-05-01 18:06:48 --> Security Class Initialized
DEBUG - 2023-05-01 18:06:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-01 18:06:48 --> Input Class Initialized
INFO - 2023-05-01 18:06:48 --> Language Class Initialized
INFO - 2023-05-01 18:06:48 --> Loader Class Initialized
INFO - 2023-05-01 18:06:48 --> Helper loaded: url_helper
INFO - 2023-05-01 18:06:48 --> Helper loaded: file_helper
INFO - 2023-05-01 18:06:48 --> Helper loaded: html_helper
INFO - 2023-05-01 18:06:48 --> Helper loaded: text_helper
INFO - 2023-05-01 18:06:48 --> Helper loaded: form_helper
INFO - 2023-05-01 18:06:48 --> Helper loaded: lang_helper
INFO - 2023-05-01 18:06:48 --> Helper loaded: security_helper
INFO - 2023-05-01 18:06:48 --> Helper loaded: cookie_helper
INFO - 2023-05-01 18:06:48 --> Database Driver Class Initialized
INFO - 2023-05-01 18:06:48 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-01 18:06:48 --> Parser Class Initialized
INFO - 2023-05-01 18:06:48 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-01 18:06:48 --> Pagination Class Initialized
INFO - 2023-05-01 18:06:48 --> Form Validation Class Initialized
INFO - 2023-05-01 18:06:48 --> Controller Class Initialized
INFO - 2023-05-01 18:06:48 --> Model Class Initialized
INFO - 2023-05-01 18:06:48 --> Model Class Initialized
INFO - 2023-05-01 18:06:48 --> Final output sent to browser
DEBUG - 2023-05-01 18:06:48 --> Total execution time: 0.0221
ERROR - 2023-05-01 18:07:19 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-01 18:07:19 --> Config Class Initialized
INFO - 2023-05-01 18:07:19 --> Hooks Class Initialized
DEBUG - 2023-05-01 18:07:19 --> UTF-8 Support Enabled
INFO - 2023-05-01 18:07:19 --> Utf8 Class Initialized
INFO - 2023-05-01 18:07:19 --> URI Class Initialized
INFO - 2023-05-01 18:07:19 --> Router Class Initialized
INFO - 2023-05-01 18:07:19 --> Output Class Initialized
INFO - 2023-05-01 18:07:19 --> Security Class Initialized
DEBUG - 2023-05-01 18:07:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-01 18:07:19 --> Input Class Initialized
INFO - 2023-05-01 18:07:19 --> Language Class Initialized
INFO - 2023-05-01 18:07:19 --> Loader Class Initialized
INFO - 2023-05-01 18:07:19 --> Helper loaded: url_helper
INFO - 2023-05-01 18:07:19 --> Helper loaded: file_helper
INFO - 2023-05-01 18:07:19 --> Helper loaded: html_helper
INFO - 2023-05-01 18:07:19 --> Helper loaded: text_helper
INFO - 2023-05-01 18:07:19 --> Helper loaded: form_helper
INFO - 2023-05-01 18:07:19 --> Helper loaded: lang_helper
INFO - 2023-05-01 18:07:19 --> Helper loaded: security_helper
INFO - 2023-05-01 18:07:19 --> Helper loaded: cookie_helper
INFO - 2023-05-01 18:07:19 --> Database Driver Class Initialized
INFO - 2023-05-01 18:07:19 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-01 18:07:19 --> Parser Class Initialized
INFO - 2023-05-01 18:07:19 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-01 18:07:19 --> Pagination Class Initialized
INFO - 2023-05-01 18:07:19 --> Form Validation Class Initialized
INFO - 2023-05-01 18:07:19 --> Controller Class Initialized
INFO - 2023-05-01 18:07:19 --> Model Class Initialized
INFO - 2023-05-01 18:07:19 --> Model Class Initialized
INFO - 2023-05-01 18:07:19 --> Final output sent to browser
DEBUG - 2023-05-01 18:07:19 --> Total execution time: 0.0327
ERROR - 2023-05-01 18:07:57 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-01 18:07:57 --> Config Class Initialized
INFO - 2023-05-01 18:07:57 --> Hooks Class Initialized
DEBUG - 2023-05-01 18:07:57 --> UTF-8 Support Enabled
INFO - 2023-05-01 18:07:57 --> Utf8 Class Initialized
INFO - 2023-05-01 18:07:57 --> URI Class Initialized
INFO - 2023-05-01 18:07:57 --> Router Class Initialized
INFO - 2023-05-01 18:07:57 --> Output Class Initialized
INFO - 2023-05-01 18:07:57 --> Security Class Initialized
DEBUG - 2023-05-01 18:07:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-01 18:07:57 --> Input Class Initialized
INFO - 2023-05-01 18:07:57 --> Language Class Initialized
INFO - 2023-05-01 18:07:57 --> Loader Class Initialized
INFO - 2023-05-01 18:07:57 --> Helper loaded: url_helper
INFO - 2023-05-01 18:07:57 --> Helper loaded: file_helper
INFO - 2023-05-01 18:07:57 --> Helper loaded: html_helper
INFO - 2023-05-01 18:07:57 --> Helper loaded: text_helper
INFO - 2023-05-01 18:07:57 --> Helper loaded: form_helper
INFO - 2023-05-01 18:07:57 --> Helper loaded: lang_helper
INFO - 2023-05-01 18:07:57 --> Helper loaded: security_helper
INFO - 2023-05-01 18:07:57 --> Helper loaded: cookie_helper
INFO - 2023-05-01 18:07:57 --> Database Driver Class Initialized
INFO - 2023-05-01 18:07:57 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-01 18:07:57 --> Parser Class Initialized
INFO - 2023-05-01 18:07:57 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-01 18:07:57 --> Pagination Class Initialized
INFO - 2023-05-01 18:07:57 --> Form Validation Class Initialized
INFO - 2023-05-01 18:07:57 --> Controller Class Initialized
INFO - 2023-05-01 18:07:57 --> Model Class Initialized
DEBUG - 2023-05-01 18:07:57 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-05-01 18:07:57 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-01 18:07:57 --> Model Class Initialized
INFO - 2023-05-01 18:07:57 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/stockrequest/stockrequest.php
DEBUG - 2023-05-01 18:07:57 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-05-01 18:07:57 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-05-01 18:07:57 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-05-01 18:07:57 --> Model Class Initialized
INFO - 2023-05-01 18:07:57 --> Model Class Initialized
INFO - 2023-05-01 18:07:57 --> Model Class Initialized
INFO - 2023-05-01 18:07:57 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-05-01 18:07:57 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-05-01 18:07:57 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-05-01 18:07:57 --> Final output sent to browser
DEBUG - 2023-05-01 18:07:57 --> Total execution time: 0.1245
ERROR - 2023-05-01 18:07:58 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-01 18:07:58 --> Config Class Initialized
INFO - 2023-05-01 18:07:58 --> Hooks Class Initialized
DEBUG - 2023-05-01 18:07:58 --> UTF-8 Support Enabled
INFO - 2023-05-01 18:07:58 --> Utf8 Class Initialized
INFO - 2023-05-01 18:07:58 --> URI Class Initialized
INFO - 2023-05-01 18:07:58 --> Router Class Initialized
INFO - 2023-05-01 18:07:58 --> Output Class Initialized
INFO - 2023-05-01 18:07:58 --> Security Class Initialized
DEBUG - 2023-05-01 18:07:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-01 18:07:58 --> Input Class Initialized
INFO - 2023-05-01 18:07:58 --> Language Class Initialized
INFO - 2023-05-01 18:07:58 --> Loader Class Initialized
INFO - 2023-05-01 18:07:58 --> Helper loaded: url_helper
INFO - 2023-05-01 18:07:58 --> Helper loaded: file_helper
INFO - 2023-05-01 18:07:58 --> Helper loaded: html_helper
INFO - 2023-05-01 18:07:58 --> Helper loaded: text_helper
INFO - 2023-05-01 18:07:58 --> Helper loaded: form_helper
INFO - 2023-05-01 18:07:58 --> Helper loaded: lang_helper
INFO - 2023-05-01 18:07:58 --> Helper loaded: security_helper
INFO - 2023-05-01 18:07:58 --> Helper loaded: cookie_helper
INFO - 2023-05-01 18:07:58 --> Database Driver Class Initialized
INFO - 2023-05-01 18:07:58 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-01 18:07:58 --> Parser Class Initialized
INFO - 2023-05-01 18:07:58 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-01 18:07:58 --> Pagination Class Initialized
INFO - 2023-05-01 18:07:58 --> Form Validation Class Initialized
INFO - 2023-05-01 18:07:58 --> Controller Class Initialized
INFO - 2023-05-01 18:07:58 --> Model Class Initialized
DEBUG - 2023-05-01 18:07:58 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-05-01 18:07:58 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-01 18:07:58 --> Model Class Initialized
INFO - 2023-05-01 18:07:58 --> Final output sent to browser
DEBUG - 2023-05-01 18:07:58 --> Total execution time: 0.0252
ERROR - 2023-05-01 18:08:04 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-01 18:08:04 --> Config Class Initialized
INFO - 2023-05-01 18:08:04 --> Hooks Class Initialized
DEBUG - 2023-05-01 18:08:04 --> UTF-8 Support Enabled
INFO - 2023-05-01 18:08:04 --> Utf8 Class Initialized
INFO - 2023-05-01 18:08:04 --> URI Class Initialized
INFO - 2023-05-01 18:08:04 --> Router Class Initialized
INFO - 2023-05-01 18:08:04 --> Output Class Initialized
INFO - 2023-05-01 18:08:04 --> Security Class Initialized
DEBUG - 2023-05-01 18:08:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-01 18:08:04 --> Input Class Initialized
INFO - 2023-05-01 18:08:04 --> Language Class Initialized
INFO - 2023-05-01 18:08:04 --> Loader Class Initialized
INFO - 2023-05-01 18:08:04 --> Helper loaded: url_helper
INFO - 2023-05-01 18:08:04 --> Helper loaded: file_helper
INFO - 2023-05-01 18:08:04 --> Helper loaded: html_helper
INFO - 2023-05-01 18:08:04 --> Helper loaded: text_helper
INFO - 2023-05-01 18:08:04 --> Helper loaded: form_helper
INFO - 2023-05-01 18:08:04 --> Helper loaded: lang_helper
INFO - 2023-05-01 18:08:04 --> Helper loaded: security_helper
INFO - 2023-05-01 18:08:04 --> Helper loaded: cookie_helper
INFO - 2023-05-01 18:08:04 --> Database Driver Class Initialized
INFO - 2023-05-01 18:08:04 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-01 18:08:04 --> Parser Class Initialized
INFO - 2023-05-01 18:08:04 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-01 18:08:04 --> Pagination Class Initialized
INFO - 2023-05-01 18:08:04 --> Form Validation Class Initialized
INFO - 2023-05-01 18:08:04 --> Controller Class Initialized
DEBUG - 2023-05-01 18:08:04 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-05-01 18:08:04 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-01 18:08:04 --> Model Class Initialized
DEBUG - 2023-05-01 18:08:04 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-01 18:08:04 --> Model Class Initialized
DEBUG - 2023-05-01 18:08:04 --> Lcustomer class already loaded. Second attempt ignored.
INFO - 2023-05-01 18:08:04 --> Model Class Initialized
INFO - 2023-05-01 18:08:04 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/customer/customer.php
DEBUG - 2023-05-01 18:08:04 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-05-01 18:08:04 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-05-01 18:08:04 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-05-01 18:08:04 --> Model Class Initialized
INFO - 2023-05-01 18:08:04 --> Model Class Initialized
INFO - 2023-05-01 18:08:04 --> Model Class Initialized
INFO - 2023-05-01 18:08:04 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-05-01 18:08:04 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-05-01 18:08:04 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-05-01 18:08:04 --> Final output sent to browser
DEBUG - 2023-05-01 18:08:04 --> Total execution time: 0.1142
ERROR - 2023-05-01 18:08:05 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-01 18:08:05 --> Config Class Initialized
INFO - 2023-05-01 18:08:05 --> Hooks Class Initialized
DEBUG - 2023-05-01 18:08:05 --> UTF-8 Support Enabled
INFO - 2023-05-01 18:08:05 --> Utf8 Class Initialized
INFO - 2023-05-01 18:08:05 --> URI Class Initialized
INFO - 2023-05-01 18:08:05 --> Router Class Initialized
INFO - 2023-05-01 18:08:05 --> Output Class Initialized
INFO - 2023-05-01 18:08:05 --> Security Class Initialized
DEBUG - 2023-05-01 18:08:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-01 18:08:05 --> Input Class Initialized
INFO - 2023-05-01 18:08:05 --> Language Class Initialized
INFO - 2023-05-01 18:08:05 --> Loader Class Initialized
INFO - 2023-05-01 18:08:05 --> Helper loaded: url_helper
INFO - 2023-05-01 18:08:05 --> Helper loaded: file_helper
INFO - 2023-05-01 18:08:05 --> Helper loaded: html_helper
INFO - 2023-05-01 18:08:05 --> Helper loaded: text_helper
INFO - 2023-05-01 18:08:05 --> Helper loaded: form_helper
INFO - 2023-05-01 18:08:05 --> Helper loaded: lang_helper
INFO - 2023-05-01 18:08:05 --> Helper loaded: security_helper
INFO - 2023-05-01 18:08:05 --> Helper loaded: cookie_helper
INFO - 2023-05-01 18:08:05 --> Database Driver Class Initialized
INFO - 2023-05-01 18:08:05 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-01 18:08:05 --> Parser Class Initialized
INFO - 2023-05-01 18:08:05 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-01 18:08:05 --> Pagination Class Initialized
INFO - 2023-05-01 18:08:05 --> Form Validation Class Initialized
INFO - 2023-05-01 18:08:05 --> Controller Class Initialized
DEBUG - 2023-05-01 18:08:05 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-05-01 18:08:05 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-01 18:08:05 --> Model Class Initialized
DEBUG - 2023-05-01 18:08:05 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-01 18:08:05 --> Model Class Initialized
INFO - 2023-05-01 18:08:05 --> Final output sent to browser
DEBUG - 2023-05-01 18:08:05 --> Total execution time: 0.0277
ERROR - 2023-05-01 18:08:22 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-01 18:08:22 --> Config Class Initialized
INFO - 2023-05-01 18:08:22 --> Hooks Class Initialized
DEBUG - 2023-05-01 18:08:22 --> UTF-8 Support Enabled
INFO - 2023-05-01 18:08:22 --> Utf8 Class Initialized
INFO - 2023-05-01 18:08:22 --> URI Class Initialized
INFO - 2023-05-01 18:08:22 --> Router Class Initialized
INFO - 2023-05-01 18:08:22 --> Output Class Initialized
INFO - 2023-05-01 18:08:22 --> Security Class Initialized
DEBUG - 2023-05-01 18:08:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-01 18:08:22 --> Input Class Initialized
INFO - 2023-05-01 18:08:22 --> Language Class Initialized
INFO - 2023-05-01 18:08:22 --> Loader Class Initialized
INFO - 2023-05-01 18:08:22 --> Helper loaded: url_helper
INFO - 2023-05-01 18:08:22 --> Helper loaded: file_helper
INFO - 2023-05-01 18:08:22 --> Helper loaded: html_helper
INFO - 2023-05-01 18:08:22 --> Helper loaded: text_helper
INFO - 2023-05-01 18:08:22 --> Helper loaded: form_helper
INFO - 2023-05-01 18:08:22 --> Helper loaded: lang_helper
INFO - 2023-05-01 18:08:22 --> Helper loaded: security_helper
INFO - 2023-05-01 18:08:22 --> Helper loaded: cookie_helper
INFO - 2023-05-01 18:08:22 --> Database Driver Class Initialized
INFO - 2023-05-01 18:08:22 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-01 18:08:22 --> Parser Class Initialized
INFO - 2023-05-01 18:08:22 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-01 18:08:22 --> Pagination Class Initialized
INFO - 2023-05-01 18:08:22 --> Form Validation Class Initialized
INFO - 2023-05-01 18:08:22 --> Controller Class Initialized
DEBUG - 2023-05-01 18:08:22 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-05-01 18:08:22 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-01 18:08:22 --> Model Class Initialized
DEBUG - 2023-05-01 18:08:22 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-01 18:08:22 --> Model Class Initialized
INFO - 2023-05-01 18:08:22 --> Final output sent to browser
DEBUG - 2023-05-01 18:08:22 --> Total execution time: 0.0773
ERROR - 2023-05-01 18:09:02 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-01 18:09:02 --> Config Class Initialized
INFO - 2023-05-01 18:09:02 --> Hooks Class Initialized
DEBUG - 2023-05-01 18:09:02 --> UTF-8 Support Enabled
INFO - 2023-05-01 18:09:02 --> Utf8 Class Initialized
INFO - 2023-05-01 18:09:02 --> URI Class Initialized
INFO - 2023-05-01 18:09:02 --> Router Class Initialized
INFO - 2023-05-01 18:09:02 --> Output Class Initialized
INFO - 2023-05-01 18:09:02 --> Security Class Initialized
DEBUG - 2023-05-01 18:09:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-01 18:09:02 --> Input Class Initialized
INFO - 2023-05-01 18:09:02 --> Language Class Initialized
INFO - 2023-05-01 18:09:02 --> Loader Class Initialized
INFO - 2023-05-01 18:09:02 --> Helper loaded: url_helper
INFO - 2023-05-01 18:09:02 --> Helper loaded: file_helper
INFO - 2023-05-01 18:09:02 --> Helper loaded: html_helper
INFO - 2023-05-01 18:09:02 --> Helper loaded: text_helper
INFO - 2023-05-01 18:09:02 --> Helper loaded: form_helper
INFO - 2023-05-01 18:09:02 --> Helper loaded: lang_helper
INFO - 2023-05-01 18:09:02 --> Helper loaded: security_helper
INFO - 2023-05-01 18:09:02 --> Helper loaded: cookie_helper
INFO - 2023-05-01 18:09:02 --> Database Driver Class Initialized
INFO - 2023-05-01 18:09:02 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-01 18:09:02 --> Parser Class Initialized
INFO - 2023-05-01 18:09:02 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-01 18:09:02 --> Pagination Class Initialized
INFO - 2023-05-01 18:09:02 --> Form Validation Class Initialized
INFO - 2023-05-01 18:09:02 --> Controller Class Initialized
DEBUG - 2023-05-01 18:09:02 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-05-01 18:09:02 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-01 18:09:02 --> Model Class Initialized
DEBUG - 2023-05-01 18:09:02 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-05-01 18:09:02 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-05-01 18:09:02 --> Ltarget class already loaded. Second attempt ignored.
INFO - 2023-05-01 18:09:02 --> Model Class Initialized
DEBUG - 2023-05-01 18:09:02 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-05-01 18:09:02 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-01 18:09:02 --> Model Class Initialized
DEBUG - 2023-05-01 18:09:02 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-01 18:09:02 --> Model Class Initialized
INFO - 2023-05-01 18:09:02 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/target/target.php
DEBUG - 2023-05-01 18:09:02 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-05-01 18:09:02 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-05-01 18:09:02 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-05-01 18:09:02 --> Model Class Initialized
INFO - 2023-05-01 18:09:02 --> Model Class Initialized
INFO - 2023-05-01 18:09:02 --> Model Class Initialized
INFO - 2023-05-01 18:09:02 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-05-01 18:09:02 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-05-01 18:09:02 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-05-01 18:09:02 --> Final output sent to browser
DEBUG - 2023-05-01 18:09:02 --> Total execution time: 0.1213
ERROR - 2023-05-01 18:09:03 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-01 18:09:03 --> Config Class Initialized
INFO - 2023-05-01 18:09:03 --> Hooks Class Initialized
DEBUG - 2023-05-01 18:09:03 --> UTF-8 Support Enabled
INFO - 2023-05-01 18:09:03 --> Utf8 Class Initialized
INFO - 2023-05-01 18:09:03 --> URI Class Initialized
INFO - 2023-05-01 18:09:03 --> Router Class Initialized
INFO - 2023-05-01 18:09:03 --> Output Class Initialized
INFO - 2023-05-01 18:09:03 --> Security Class Initialized
DEBUG - 2023-05-01 18:09:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-01 18:09:03 --> Input Class Initialized
INFO - 2023-05-01 18:09:03 --> Language Class Initialized
INFO - 2023-05-01 18:09:03 --> Loader Class Initialized
INFO - 2023-05-01 18:09:03 --> Helper loaded: url_helper
INFO - 2023-05-01 18:09:03 --> Helper loaded: file_helper
INFO - 2023-05-01 18:09:03 --> Helper loaded: html_helper
INFO - 2023-05-01 18:09:03 --> Helper loaded: text_helper
INFO - 2023-05-01 18:09:03 --> Helper loaded: form_helper
INFO - 2023-05-01 18:09:03 --> Helper loaded: lang_helper
INFO - 2023-05-01 18:09:03 --> Helper loaded: security_helper
INFO - 2023-05-01 18:09:03 --> Helper loaded: cookie_helper
INFO - 2023-05-01 18:09:03 --> Database Driver Class Initialized
INFO - 2023-05-01 18:09:03 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-01 18:09:03 --> Parser Class Initialized
INFO - 2023-05-01 18:09:03 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-01 18:09:03 --> Pagination Class Initialized
INFO - 2023-05-01 18:09:03 --> Form Validation Class Initialized
INFO - 2023-05-01 18:09:03 --> Controller Class Initialized
DEBUG - 2023-05-01 18:09:03 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-05-01 18:09:03 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-01 18:09:03 --> Model Class Initialized
DEBUG - 2023-05-01 18:09:03 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-05-01 18:09:03 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-01 18:09:03 --> Model Class Initialized
DEBUG - 2023-05-01 18:09:03 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-05-01 18:09:03 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-01 18:09:03 --> Model Class Initialized
DEBUG - 2023-05-01 18:09:03 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-01 18:09:03 --> Model Class Initialized
INFO - 2023-05-01 18:09:03 --> Final output sent to browser
DEBUG - 2023-05-01 18:09:03 --> Total execution time: 0.0219
ERROR - 2023-05-01 18:09:15 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-01 18:09:15 --> Config Class Initialized
INFO - 2023-05-01 18:09:15 --> Hooks Class Initialized
DEBUG - 2023-05-01 18:09:15 --> UTF-8 Support Enabled
INFO - 2023-05-01 18:09:15 --> Utf8 Class Initialized
INFO - 2023-05-01 18:09:15 --> URI Class Initialized
INFO - 2023-05-01 18:09:15 --> Router Class Initialized
INFO - 2023-05-01 18:09:15 --> Output Class Initialized
INFO - 2023-05-01 18:09:15 --> Security Class Initialized
DEBUG - 2023-05-01 18:09:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-01 18:09:15 --> Input Class Initialized
INFO - 2023-05-01 18:09:15 --> Language Class Initialized
INFO - 2023-05-01 18:09:15 --> Loader Class Initialized
INFO - 2023-05-01 18:09:15 --> Helper loaded: url_helper
INFO - 2023-05-01 18:09:15 --> Helper loaded: file_helper
INFO - 2023-05-01 18:09:15 --> Helper loaded: html_helper
INFO - 2023-05-01 18:09:15 --> Helper loaded: text_helper
INFO - 2023-05-01 18:09:15 --> Helper loaded: form_helper
INFO - 2023-05-01 18:09:15 --> Helper loaded: lang_helper
INFO - 2023-05-01 18:09:15 --> Helper loaded: security_helper
INFO - 2023-05-01 18:09:15 --> Helper loaded: cookie_helper
INFO - 2023-05-01 18:09:15 --> Database Driver Class Initialized
INFO - 2023-05-01 18:09:15 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-01 18:09:15 --> Parser Class Initialized
INFO - 2023-05-01 18:09:15 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-01 18:09:15 --> Pagination Class Initialized
INFO - 2023-05-01 18:09:15 --> Form Validation Class Initialized
INFO - 2023-05-01 18:09:15 --> Controller Class Initialized
DEBUG - 2023-05-01 18:09:15 --> Auth class already loaded. Second attempt ignored.
INFO - 2023-05-01 18:09:15 --> Model Class Initialized
INFO - 2023-05-01 18:09:15 --> Model Class Initialized
INFO - 2023-05-01 18:09:15 --> Model Class Initialized
INFO - 2023-05-01 18:09:15 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/product/product.php
DEBUG - 2023-05-01 18:09:15 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-05-01 18:09:15 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-05-01 18:09:15 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-05-01 18:09:15 --> Model Class Initialized
INFO - 2023-05-01 18:09:15 --> Model Class Initialized
INFO - 2023-05-01 18:09:15 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-05-01 18:09:15 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-05-01 18:09:15 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-05-01 18:09:15 --> Final output sent to browser
DEBUG - 2023-05-01 18:09:15 --> Total execution time: 0.1235
ERROR - 2023-05-01 18:09:16 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-01 18:09:16 --> Config Class Initialized
INFO - 2023-05-01 18:09:16 --> Hooks Class Initialized
DEBUG - 2023-05-01 18:09:16 --> UTF-8 Support Enabled
INFO - 2023-05-01 18:09:16 --> Utf8 Class Initialized
INFO - 2023-05-01 18:09:16 --> URI Class Initialized
INFO - 2023-05-01 18:09:16 --> Router Class Initialized
INFO - 2023-05-01 18:09:16 --> Output Class Initialized
INFO - 2023-05-01 18:09:16 --> Security Class Initialized
DEBUG - 2023-05-01 18:09:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-01 18:09:16 --> Input Class Initialized
INFO - 2023-05-01 18:09:16 --> Language Class Initialized
INFO - 2023-05-01 18:09:16 --> Loader Class Initialized
INFO - 2023-05-01 18:09:16 --> Helper loaded: url_helper
INFO - 2023-05-01 18:09:16 --> Helper loaded: file_helper
INFO - 2023-05-01 18:09:16 --> Helper loaded: html_helper
INFO - 2023-05-01 18:09:16 --> Helper loaded: text_helper
INFO - 2023-05-01 18:09:16 --> Helper loaded: form_helper
INFO - 2023-05-01 18:09:16 --> Helper loaded: lang_helper
INFO - 2023-05-01 18:09:16 --> Helper loaded: security_helper
INFO - 2023-05-01 18:09:16 --> Helper loaded: cookie_helper
INFO - 2023-05-01 18:09:16 --> Database Driver Class Initialized
INFO - 2023-05-01 18:09:16 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-01 18:09:16 --> Parser Class Initialized
INFO - 2023-05-01 18:09:16 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-01 18:09:16 --> Pagination Class Initialized
INFO - 2023-05-01 18:09:16 --> Form Validation Class Initialized
INFO - 2023-05-01 18:09:16 --> Controller Class Initialized
DEBUG - 2023-05-01 18:09:16 --> Auth class already loaded. Second attempt ignored.
INFO - 2023-05-01 18:09:16 --> Model Class Initialized
INFO - 2023-05-01 18:09:16 --> Model Class Initialized
INFO - 2023-05-01 18:09:16 --> Final output sent to browser
DEBUG - 2023-05-01 18:09:16 --> Total execution time: 0.0405
ERROR - 2023-05-01 18:09:28 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-01 18:09:28 --> Config Class Initialized
INFO - 2023-05-01 18:09:28 --> Hooks Class Initialized
DEBUG - 2023-05-01 18:09:28 --> UTF-8 Support Enabled
INFO - 2023-05-01 18:09:28 --> Utf8 Class Initialized
INFO - 2023-05-01 18:09:28 --> URI Class Initialized
INFO - 2023-05-01 18:09:28 --> Router Class Initialized
INFO - 2023-05-01 18:09:28 --> Output Class Initialized
INFO - 2023-05-01 18:09:28 --> Security Class Initialized
DEBUG - 2023-05-01 18:09:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-01 18:09:28 --> Input Class Initialized
INFO - 2023-05-01 18:09:28 --> Language Class Initialized
INFO - 2023-05-01 18:09:28 --> Loader Class Initialized
INFO - 2023-05-01 18:09:28 --> Helper loaded: url_helper
INFO - 2023-05-01 18:09:28 --> Helper loaded: file_helper
INFO - 2023-05-01 18:09:28 --> Helper loaded: html_helper
INFO - 2023-05-01 18:09:28 --> Helper loaded: text_helper
INFO - 2023-05-01 18:09:28 --> Helper loaded: form_helper
INFO - 2023-05-01 18:09:28 --> Helper loaded: lang_helper
INFO - 2023-05-01 18:09:28 --> Helper loaded: security_helper
INFO - 2023-05-01 18:09:28 --> Helper loaded: cookie_helper
INFO - 2023-05-01 18:09:28 --> Database Driver Class Initialized
INFO - 2023-05-01 18:09:28 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-01 18:09:28 --> Parser Class Initialized
INFO - 2023-05-01 18:09:28 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-01 18:09:28 --> Pagination Class Initialized
INFO - 2023-05-01 18:09:28 --> Form Validation Class Initialized
INFO - 2023-05-01 18:09:28 --> Controller Class Initialized
DEBUG - 2023-05-01 18:09:28 --> Auth class already loaded. Second attempt ignored.
INFO - 2023-05-01 18:09:28 --> Model Class Initialized
INFO - 2023-05-01 18:09:28 --> Model Class Initialized
INFO - 2023-05-01 18:09:28 --> Final output sent to browser
DEBUG - 2023-05-01 18:09:28 --> Total execution time: 0.0956
ERROR - 2023-05-01 18:09:46 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-01 18:09:46 --> Config Class Initialized
INFO - 2023-05-01 18:09:46 --> Hooks Class Initialized
DEBUG - 2023-05-01 18:09:46 --> UTF-8 Support Enabled
INFO - 2023-05-01 18:09:46 --> Utf8 Class Initialized
INFO - 2023-05-01 18:09:46 --> URI Class Initialized
INFO - 2023-05-01 18:09:46 --> Router Class Initialized
INFO - 2023-05-01 18:09:46 --> Output Class Initialized
INFO - 2023-05-01 18:09:46 --> Security Class Initialized
DEBUG - 2023-05-01 18:09:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-01 18:09:46 --> Input Class Initialized
INFO - 2023-05-01 18:09:46 --> Language Class Initialized
INFO - 2023-05-01 18:09:46 --> Loader Class Initialized
INFO - 2023-05-01 18:09:46 --> Helper loaded: url_helper
INFO - 2023-05-01 18:09:46 --> Helper loaded: file_helper
INFO - 2023-05-01 18:09:46 --> Helper loaded: html_helper
INFO - 2023-05-01 18:09:46 --> Helper loaded: text_helper
INFO - 2023-05-01 18:09:46 --> Helper loaded: form_helper
INFO - 2023-05-01 18:09:46 --> Helper loaded: lang_helper
INFO - 2023-05-01 18:09:46 --> Helper loaded: security_helper
INFO - 2023-05-01 18:09:46 --> Helper loaded: cookie_helper
INFO - 2023-05-01 18:09:46 --> Database Driver Class Initialized
INFO - 2023-05-01 18:09:46 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-01 18:09:46 --> Parser Class Initialized
INFO - 2023-05-01 18:09:46 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-01 18:09:46 --> Pagination Class Initialized
INFO - 2023-05-01 18:09:46 --> Form Validation Class Initialized
INFO - 2023-05-01 18:09:46 --> Controller Class Initialized
DEBUG - 2023-05-01 18:09:46 --> Auth class already loaded. Second attempt ignored.
INFO - 2023-05-01 18:09:46 --> Model Class Initialized
INFO - 2023-05-01 18:09:46 --> Model Class Initialized
ERROR - 2023-05-01 18:09:46 --> Query error: Unknown column 'product_id' in 'where clause' - Invalid query: SELECT *
FROM `web_setting`
WHERE `product_id` = '24518668'
ERROR - 2023-05-01 18:09:46 --> Severity: error --> Exception: Call to a member function row() on bool /home/powera7m/app.maurnaturo.com/application/helpers/lang_helper.php 16
ERROR - 2023-05-01 18:09:50 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-01 18:09:50 --> Config Class Initialized
INFO - 2023-05-01 18:09:50 --> Hooks Class Initialized
DEBUG - 2023-05-01 18:09:50 --> UTF-8 Support Enabled
INFO - 2023-05-01 18:09:50 --> Utf8 Class Initialized
INFO - 2023-05-01 18:09:50 --> URI Class Initialized
INFO - 2023-05-01 18:09:50 --> Router Class Initialized
INFO - 2023-05-01 18:09:50 --> Output Class Initialized
INFO - 2023-05-01 18:09:50 --> Security Class Initialized
DEBUG - 2023-05-01 18:09:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-01 18:09:50 --> Input Class Initialized
INFO - 2023-05-01 18:09:50 --> Language Class Initialized
INFO - 2023-05-01 18:09:50 --> Loader Class Initialized
INFO - 2023-05-01 18:09:50 --> Helper loaded: url_helper
INFO - 2023-05-01 18:09:50 --> Helper loaded: file_helper
INFO - 2023-05-01 18:09:50 --> Helper loaded: html_helper
INFO - 2023-05-01 18:09:50 --> Helper loaded: text_helper
INFO - 2023-05-01 18:09:50 --> Helper loaded: form_helper
INFO - 2023-05-01 18:09:50 --> Helper loaded: lang_helper
INFO - 2023-05-01 18:09:50 --> Helper loaded: security_helper
INFO - 2023-05-01 18:09:50 --> Helper loaded: cookie_helper
INFO - 2023-05-01 18:09:50 --> Database Driver Class Initialized
INFO - 2023-05-01 18:09:50 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-01 18:09:50 --> Parser Class Initialized
INFO - 2023-05-01 18:09:50 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-01 18:09:50 --> Pagination Class Initialized
INFO - 2023-05-01 18:09:50 --> Form Validation Class Initialized
INFO - 2023-05-01 18:09:50 --> Controller Class Initialized
DEBUG - 2023-05-01 18:09:50 --> Auth class already loaded. Second attempt ignored.
INFO - 2023-05-01 18:09:50 --> Model Class Initialized
INFO - 2023-05-01 18:09:50 --> Model Class Initialized
ERROR - 2023-05-01 18:09:50 --> Query error: Unknown column 'product_id' in 'where clause' - Invalid query: SELECT *
FROM `web_setting`
WHERE `product_id` = '24518668'
ERROR - 2023-05-01 18:09:50 --> Severity: error --> Exception: Call to a member function row() on bool /home/powera7m/app.maurnaturo.com/application/helpers/lang_helper.php 16
ERROR - 2023-05-01 18:09:54 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-01 18:09:54 --> Config Class Initialized
INFO - 2023-05-01 18:09:54 --> Hooks Class Initialized
DEBUG - 2023-05-01 18:09:54 --> UTF-8 Support Enabled
INFO - 2023-05-01 18:09:54 --> Utf8 Class Initialized
INFO - 2023-05-01 18:09:54 --> URI Class Initialized
INFO - 2023-05-01 18:09:54 --> Router Class Initialized
INFO - 2023-05-01 18:09:54 --> Output Class Initialized
INFO - 2023-05-01 18:09:54 --> Security Class Initialized
DEBUG - 2023-05-01 18:09:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-01 18:09:54 --> Input Class Initialized
INFO - 2023-05-01 18:09:54 --> Language Class Initialized
INFO - 2023-05-01 18:09:54 --> Loader Class Initialized
INFO - 2023-05-01 18:09:54 --> Helper loaded: url_helper
INFO - 2023-05-01 18:09:54 --> Helper loaded: file_helper
INFO - 2023-05-01 18:09:54 --> Helper loaded: html_helper
INFO - 2023-05-01 18:09:54 --> Helper loaded: text_helper
INFO - 2023-05-01 18:09:54 --> Helper loaded: form_helper
INFO - 2023-05-01 18:09:54 --> Helper loaded: lang_helper
INFO - 2023-05-01 18:09:54 --> Helper loaded: security_helper
INFO - 2023-05-01 18:09:54 --> Helper loaded: cookie_helper
INFO - 2023-05-01 18:09:54 --> Database Driver Class Initialized
INFO - 2023-05-01 18:09:54 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-01 18:09:54 --> Parser Class Initialized
INFO - 2023-05-01 18:09:54 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-01 18:09:54 --> Pagination Class Initialized
INFO - 2023-05-01 18:09:54 --> Form Validation Class Initialized
INFO - 2023-05-01 18:09:54 --> Controller Class Initialized
DEBUG - 2023-05-01 18:09:54 --> Auth class already loaded. Second attempt ignored.
INFO - 2023-05-01 18:09:54 --> Model Class Initialized
INFO - 2023-05-01 18:09:54 --> Model Class Initialized
INFO - 2023-05-01 18:09:54 --> Model Class Initialized
INFO - 2023-05-01 18:09:54 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/product/product.php
DEBUG - 2023-05-01 18:09:54 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-05-01 18:09:54 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-05-01 18:09:54 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-05-01 18:09:54 --> Model Class Initialized
INFO - 2023-05-01 18:09:54 --> Model Class Initialized
INFO - 2023-05-01 18:09:54 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-05-01 18:09:54 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-05-01 18:09:54 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-05-01 18:09:54 --> Final output sent to browser
DEBUG - 2023-05-01 18:09:54 --> Total execution time: 0.1168
ERROR - 2023-05-01 18:09:54 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-01 18:09:54 --> Config Class Initialized
INFO - 2023-05-01 18:09:54 --> Hooks Class Initialized
DEBUG - 2023-05-01 18:09:54 --> UTF-8 Support Enabled
INFO - 2023-05-01 18:09:54 --> Utf8 Class Initialized
INFO - 2023-05-01 18:09:54 --> URI Class Initialized
INFO - 2023-05-01 18:09:54 --> Router Class Initialized
INFO - 2023-05-01 18:09:54 --> Output Class Initialized
INFO - 2023-05-01 18:09:54 --> Security Class Initialized
DEBUG - 2023-05-01 18:09:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-01 18:09:54 --> Input Class Initialized
INFO - 2023-05-01 18:09:54 --> Language Class Initialized
INFO - 2023-05-01 18:09:54 --> Loader Class Initialized
INFO - 2023-05-01 18:09:54 --> Helper loaded: url_helper
INFO - 2023-05-01 18:09:54 --> Helper loaded: file_helper
INFO - 2023-05-01 18:09:54 --> Helper loaded: html_helper
INFO - 2023-05-01 18:09:54 --> Helper loaded: text_helper
INFO - 2023-05-01 18:09:54 --> Helper loaded: form_helper
INFO - 2023-05-01 18:09:54 --> Helper loaded: lang_helper
INFO - 2023-05-01 18:09:54 --> Helper loaded: security_helper
INFO - 2023-05-01 18:09:54 --> Helper loaded: cookie_helper
INFO - 2023-05-01 18:09:54 --> Database Driver Class Initialized
INFO - 2023-05-01 18:09:54 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-01 18:09:54 --> Parser Class Initialized
INFO - 2023-05-01 18:09:54 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-01 18:09:54 --> Pagination Class Initialized
INFO - 2023-05-01 18:09:54 --> Form Validation Class Initialized
INFO - 2023-05-01 18:09:54 --> Controller Class Initialized
DEBUG - 2023-05-01 18:09:54 --> Auth class already loaded. Second attempt ignored.
INFO - 2023-05-01 18:09:54 --> Model Class Initialized
INFO - 2023-05-01 18:09:54 --> Model Class Initialized
INFO - 2023-05-01 18:09:54 --> Final output sent to browser
DEBUG - 2023-05-01 18:09:54 --> Total execution time: 0.0433
ERROR - 2023-05-01 18:09:59 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-01 18:09:59 --> Config Class Initialized
INFO - 2023-05-01 18:09:59 --> Hooks Class Initialized
DEBUG - 2023-05-01 18:09:59 --> UTF-8 Support Enabled
INFO - 2023-05-01 18:09:59 --> Utf8 Class Initialized
INFO - 2023-05-01 18:09:59 --> URI Class Initialized
INFO - 2023-05-01 18:09:59 --> Router Class Initialized
INFO - 2023-05-01 18:09:59 --> Output Class Initialized
INFO - 2023-05-01 18:09:59 --> Security Class Initialized
DEBUG - 2023-05-01 18:09:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-01 18:09:59 --> Input Class Initialized
INFO - 2023-05-01 18:09:59 --> Language Class Initialized
INFO - 2023-05-01 18:09:59 --> Loader Class Initialized
INFO - 2023-05-01 18:09:59 --> Helper loaded: url_helper
INFO - 2023-05-01 18:09:59 --> Helper loaded: file_helper
INFO - 2023-05-01 18:09:59 --> Helper loaded: html_helper
INFO - 2023-05-01 18:09:59 --> Helper loaded: text_helper
INFO - 2023-05-01 18:09:59 --> Helper loaded: form_helper
INFO - 2023-05-01 18:09:59 --> Helper loaded: lang_helper
INFO - 2023-05-01 18:09:59 --> Helper loaded: security_helper
INFO - 2023-05-01 18:09:59 --> Helper loaded: cookie_helper
INFO - 2023-05-01 18:09:59 --> Database Driver Class Initialized
INFO - 2023-05-01 18:09:59 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-01 18:09:59 --> Parser Class Initialized
INFO - 2023-05-01 18:09:59 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-01 18:09:59 --> Pagination Class Initialized
INFO - 2023-05-01 18:09:59 --> Form Validation Class Initialized
INFO - 2023-05-01 18:09:59 --> Controller Class Initialized
DEBUG - 2023-05-01 18:09:59 --> Auth class already loaded. Second attempt ignored.
INFO - 2023-05-01 18:09:59 --> Model Class Initialized
INFO - 2023-05-01 18:09:59 --> Model Class Initialized
INFO - 2023-05-01 18:09:59 --> Final output sent to browser
DEBUG - 2023-05-01 18:09:59 --> Total execution time: 0.0986
ERROR - 2023-05-01 18:10:43 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-01 18:10:43 --> Config Class Initialized
INFO - 2023-05-01 18:10:43 --> Hooks Class Initialized
DEBUG - 2023-05-01 18:10:43 --> UTF-8 Support Enabled
INFO - 2023-05-01 18:10:43 --> Utf8 Class Initialized
INFO - 2023-05-01 18:10:43 --> URI Class Initialized
INFO - 2023-05-01 18:10:43 --> Router Class Initialized
INFO - 2023-05-01 18:10:43 --> Output Class Initialized
INFO - 2023-05-01 18:10:43 --> Security Class Initialized
DEBUG - 2023-05-01 18:10:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-01 18:10:43 --> Input Class Initialized
INFO - 2023-05-01 18:10:43 --> Language Class Initialized
INFO - 2023-05-01 18:10:43 --> Loader Class Initialized
INFO - 2023-05-01 18:10:43 --> Helper loaded: url_helper
INFO - 2023-05-01 18:10:43 --> Helper loaded: file_helper
INFO - 2023-05-01 18:10:43 --> Helper loaded: html_helper
INFO - 2023-05-01 18:10:43 --> Helper loaded: text_helper
INFO - 2023-05-01 18:10:43 --> Helper loaded: form_helper
INFO - 2023-05-01 18:10:43 --> Helper loaded: lang_helper
INFO - 2023-05-01 18:10:43 --> Helper loaded: security_helper
INFO - 2023-05-01 18:10:43 --> Helper loaded: cookie_helper
INFO - 2023-05-01 18:10:43 --> Database Driver Class Initialized
INFO - 2023-05-01 18:10:43 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-01 18:10:43 --> Parser Class Initialized
INFO - 2023-05-01 18:10:43 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-01 18:10:43 --> Pagination Class Initialized
INFO - 2023-05-01 18:10:43 --> Form Validation Class Initialized
INFO - 2023-05-01 18:10:43 --> Controller Class Initialized
DEBUG - 2023-05-01 18:10:43 --> Auth class already loaded. Second attempt ignored.
INFO - 2023-05-01 18:10:43 --> Model Class Initialized
INFO - 2023-05-01 18:10:43 --> Model Class Initialized
INFO - 2023-05-01 18:10:43 --> Model Class Initialized
INFO - 2023-05-01 18:10:43 --> Model Class Initialized
INFO - 2023-05-01 18:10:43 --> Model Class Initialized
INFO - 2023-05-01 18:10:43 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/product/edit_product_form.php
DEBUG - 2023-05-01 18:10:43 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-05-01 18:10:43 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-05-01 18:10:43 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-05-01 18:10:43 --> Model Class Initialized
INFO - 2023-05-01 18:10:43 --> Model Class Initialized
INFO - 2023-05-01 18:10:43 --> Model Class Initialized
INFO - 2023-05-01 18:10:43 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-05-01 18:10:43 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-05-01 18:10:43 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-05-01 18:10:43 --> Final output sent to browser
DEBUG - 2023-05-01 18:10:43 --> Total execution time: 0.1469
ERROR - 2023-05-01 18:11:06 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-01 18:11:06 --> Config Class Initialized
INFO - 2023-05-01 18:11:06 --> Hooks Class Initialized
DEBUG - 2023-05-01 18:11:06 --> UTF-8 Support Enabled
INFO - 2023-05-01 18:11:06 --> Utf8 Class Initialized
INFO - 2023-05-01 18:11:06 --> URI Class Initialized
INFO - 2023-05-01 18:11:06 --> Router Class Initialized
INFO - 2023-05-01 18:11:06 --> Output Class Initialized
INFO - 2023-05-01 18:11:06 --> Security Class Initialized
DEBUG - 2023-05-01 18:11:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-01 18:11:06 --> Input Class Initialized
INFO - 2023-05-01 18:11:06 --> Language Class Initialized
INFO - 2023-05-01 18:11:06 --> Loader Class Initialized
INFO - 2023-05-01 18:11:06 --> Helper loaded: url_helper
INFO - 2023-05-01 18:11:06 --> Helper loaded: file_helper
INFO - 2023-05-01 18:11:06 --> Helper loaded: html_helper
INFO - 2023-05-01 18:11:06 --> Helper loaded: text_helper
INFO - 2023-05-01 18:11:06 --> Helper loaded: form_helper
INFO - 2023-05-01 18:11:06 --> Helper loaded: lang_helper
INFO - 2023-05-01 18:11:06 --> Helper loaded: security_helper
INFO - 2023-05-01 18:11:06 --> Helper loaded: cookie_helper
INFO - 2023-05-01 18:11:06 --> Database Driver Class Initialized
INFO - 2023-05-01 18:11:06 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-01 18:11:06 --> Parser Class Initialized
INFO - 2023-05-01 18:11:06 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-01 18:11:06 --> Pagination Class Initialized
INFO - 2023-05-01 18:11:06 --> Form Validation Class Initialized
INFO - 2023-05-01 18:11:06 --> Controller Class Initialized
DEBUG - 2023-05-01 18:11:06 --> Auth class already loaded. Second attempt ignored.
INFO - 2023-05-01 18:11:06 --> Model Class Initialized
INFO - 2023-05-01 18:11:06 --> Model Class Initialized
ERROR - 2023-05-01 18:11:07 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-01 18:11:07 --> Config Class Initialized
INFO - 2023-05-01 18:11:07 --> Hooks Class Initialized
DEBUG - 2023-05-01 18:11:07 --> UTF-8 Support Enabled
INFO - 2023-05-01 18:11:07 --> Utf8 Class Initialized
INFO - 2023-05-01 18:11:07 --> URI Class Initialized
INFO - 2023-05-01 18:11:07 --> Router Class Initialized
INFO - 2023-05-01 18:11:07 --> Output Class Initialized
INFO - 2023-05-01 18:11:07 --> Security Class Initialized
DEBUG - 2023-05-01 18:11:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-01 18:11:07 --> Input Class Initialized
INFO - 2023-05-01 18:11:07 --> Language Class Initialized
INFO - 2023-05-01 18:11:07 --> Loader Class Initialized
INFO - 2023-05-01 18:11:07 --> Helper loaded: url_helper
INFO - 2023-05-01 18:11:07 --> Helper loaded: file_helper
INFO - 2023-05-01 18:11:07 --> Helper loaded: html_helper
INFO - 2023-05-01 18:11:07 --> Helper loaded: text_helper
INFO - 2023-05-01 18:11:07 --> Helper loaded: form_helper
INFO - 2023-05-01 18:11:07 --> Helper loaded: lang_helper
INFO - 2023-05-01 18:11:07 --> Helper loaded: security_helper
INFO - 2023-05-01 18:11:07 --> Helper loaded: cookie_helper
INFO - 2023-05-01 18:11:07 --> Database Driver Class Initialized
INFO - 2023-05-01 18:11:07 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-01 18:11:07 --> Parser Class Initialized
INFO - 2023-05-01 18:11:07 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-01 18:11:07 --> Pagination Class Initialized
INFO - 2023-05-01 18:11:07 --> Form Validation Class Initialized
INFO - 2023-05-01 18:11:07 --> Controller Class Initialized
DEBUG - 2023-05-01 18:11:07 --> Auth class already loaded. Second attempt ignored.
INFO - 2023-05-01 18:11:07 --> Model Class Initialized
INFO - 2023-05-01 18:11:07 --> Model Class Initialized
INFO - 2023-05-01 18:11:07 --> Model Class Initialized
INFO - 2023-05-01 18:11:07 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/product/product.php
DEBUG - 2023-05-01 18:11:07 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-05-01 18:11:07 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-05-01 18:11:07 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-05-01 18:11:07 --> Model Class Initialized
INFO - 2023-05-01 18:11:07 --> Model Class Initialized
INFO - 2023-05-01 18:11:07 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-05-01 18:11:07 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-05-01 18:11:07 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-05-01 18:11:07 --> Final output sent to browser
DEBUG - 2023-05-01 18:11:07 --> Total execution time: 0.1267
ERROR - 2023-05-01 18:11:08 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-01 18:11:08 --> Config Class Initialized
INFO - 2023-05-01 18:11:08 --> Hooks Class Initialized
DEBUG - 2023-05-01 18:11:08 --> UTF-8 Support Enabled
INFO - 2023-05-01 18:11:08 --> Utf8 Class Initialized
INFO - 2023-05-01 18:11:08 --> URI Class Initialized
INFO - 2023-05-01 18:11:08 --> Router Class Initialized
INFO - 2023-05-01 18:11:08 --> Output Class Initialized
INFO - 2023-05-01 18:11:08 --> Security Class Initialized
DEBUG - 2023-05-01 18:11:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-01 18:11:08 --> Input Class Initialized
INFO - 2023-05-01 18:11:08 --> Language Class Initialized
INFO - 2023-05-01 18:11:08 --> Loader Class Initialized
INFO - 2023-05-01 18:11:08 --> Helper loaded: url_helper
INFO - 2023-05-01 18:11:08 --> Helper loaded: file_helper
INFO - 2023-05-01 18:11:08 --> Helper loaded: html_helper
INFO - 2023-05-01 18:11:08 --> Helper loaded: text_helper
INFO - 2023-05-01 18:11:08 --> Helper loaded: form_helper
INFO - 2023-05-01 18:11:08 --> Helper loaded: lang_helper
INFO - 2023-05-01 18:11:08 --> Helper loaded: security_helper
INFO - 2023-05-01 18:11:08 --> Helper loaded: cookie_helper
INFO - 2023-05-01 18:11:08 --> Database Driver Class Initialized
INFO - 2023-05-01 18:11:08 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-01 18:11:08 --> Parser Class Initialized
INFO - 2023-05-01 18:11:08 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-01 18:11:08 --> Pagination Class Initialized
INFO - 2023-05-01 18:11:08 --> Form Validation Class Initialized
INFO - 2023-05-01 18:11:08 --> Controller Class Initialized
DEBUG - 2023-05-01 18:11:08 --> Auth class already loaded. Second attempt ignored.
INFO - 2023-05-01 18:11:08 --> Model Class Initialized
INFO - 2023-05-01 18:11:08 --> Model Class Initialized
INFO - 2023-05-01 18:11:08 --> Final output sent to browser
DEBUG - 2023-05-01 18:11:08 --> Total execution time: 0.0426
ERROR - 2023-05-01 18:11:11 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-01 18:11:11 --> Config Class Initialized
INFO - 2023-05-01 18:11:11 --> Hooks Class Initialized
DEBUG - 2023-05-01 18:11:11 --> UTF-8 Support Enabled
INFO - 2023-05-01 18:11:11 --> Utf8 Class Initialized
INFO - 2023-05-01 18:11:12 --> URI Class Initialized
INFO - 2023-05-01 18:11:12 --> Router Class Initialized
INFO - 2023-05-01 18:11:12 --> Output Class Initialized
INFO - 2023-05-01 18:11:12 --> Security Class Initialized
DEBUG - 2023-05-01 18:11:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-01 18:11:12 --> Input Class Initialized
INFO - 2023-05-01 18:11:12 --> Language Class Initialized
INFO - 2023-05-01 18:11:12 --> Loader Class Initialized
INFO - 2023-05-01 18:11:12 --> Helper loaded: url_helper
INFO - 2023-05-01 18:11:12 --> Helper loaded: file_helper
INFO - 2023-05-01 18:11:12 --> Helper loaded: html_helper
INFO - 2023-05-01 18:11:12 --> Helper loaded: text_helper
INFO - 2023-05-01 18:11:12 --> Helper loaded: form_helper
INFO - 2023-05-01 18:11:12 --> Helper loaded: lang_helper
INFO - 2023-05-01 18:11:12 --> Helper loaded: security_helper
INFO - 2023-05-01 18:11:12 --> Helper loaded: cookie_helper
INFO - 2023-05-01 18:11:12 --> Database Driver Class Initialized
INFO - 2023-05-01 18:11:12 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-01 18:11:12 --> Parser Class Initialized
INFO - 2023-05-01 18:11:12 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-01 18:11:12 --> Pagination Class Initialized
INFO - 2023-05-01 18:11:12 --> Form Validation Class Initialized
INFO - 2023-05-01 18:11:12 --> Controller Class Initialized
DEBUG - 2023-05-01 18:11:12 --> Auth class already loaded. Second attempt ignored.
INFO - 2023-05-01 18:11:12 --> Model Class Initialized
INFO - 2023-05-01 18:11:12 --> Model Class Initialized
INFO - 2023-05-01 18:11:12 --> Final output sent to browser
DEBUG - 2023-05-01 18:11:12 --> Total execution time: 0.0947
ERROR - 2023-05-01 18:12:54 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-01 18:12:54 --> Config Class Initialized
INFO - 2023-05-01 18:12:54 --> Hooks Class Initialized
DEBUG - 2023-05-01 18:12:54 --> UTF-8 Support Enabled
INFO - 2023-05-01 18:12:54 --> Utf8 Class Initialized
INFO - 2023-05-01 18:12:54 --> URI Class Initialized
INFO - 2023-05-01 18:12:54 --> Router Class Initialized
INFO - 2023-05-01 18:12:54 --> Output Class Initialized
INFO - 2023-05-01 18:12:54 --> Security Class Initialized
DEBUG - 2023-05-01 18:12:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-01 18:12:54 --> Input Class Initialized
INFO - 2023-05-01 18:12:54 --> Language Class Initialized
INFO - 2023-05-01 18:12:54 --> Loader Class Initialized
INFO - 2023-05-01 18:12:54 --> Helper loaded: url_helper
INFO - 2023-05-01 18:12:54 --> Helper loaded: file_helper
INFO - 2023-05-01 18:12:54 --> Helper loaded: html_helper
INFO - 2023-05-01 18:12:54 --> Helper loaded: text_helper
INFO - 2023-05-01 18:12:54 --> Helper loaded: form_helper
INFO - 2023-05-01 18:12:54 --> Helper loaded: lang_helper
INFO - 2023-05-01 18:12:54 --> Helper loaded: security_helper
INFO - 2023-05-01 18:12:54 --> Helper loaded: cookie_helper
INFO - 2023-05-01 18:12:54 --> Database Driver Class Initialized
INFO - 2023-05-01 18:12:54 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-01 18:12:54 --> Parser Class Initialized
INFO - 2023-05-01 18:12:54 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-01 18:12:54 --> Pagination Class Initialized
INFO - 2023-05-01 18:12:54 --> Form Validation Class Initialized
INFO - 2023-05-01 18:12:54 --> Controller Class Initialized
DEBUG - 2023-05-01 18:12:54 --> Auth class already loaded. Second attempt ignored.
INFO - 2023-05-01 18:12:54 --> Model Class Initialized
INFO - 2023-05-01 18:12:54 --> Model Class Initialized
INFO - 2023-05-01 18:12:54 --> Model Class Initialized
INFO - 2023-05-01 18:12:54 --> Model Class Initialized
INFO - 2023-05-01 18:12:54 --> Model Class Initialized
INFO - 2023-05-01 18:12:55 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/product/edit_product_form.php
DEBUG - 2023-05-01 18:12:55 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-05-01 18:12:55 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-05-01 18:12:55 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-05-01 18:12:55 --> Model Class Initialized
INFO - 2023-05-01 18:12:55 --> Model Class Initialized
INFO - 2023-05-01 18:12:55 --> Model Class Initialized
INFO - 2023-05-01 18:12:55 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-05-01 18:12:55 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-05-01 18:12:55 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-05-01 18:12:55 --> Final output sent to browser
DEBUG - 2023-05-01 18:12:55 --> Total execution time: 0.1453
ERROR - 2023-05-01 18:13:12 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-01 18:13:12 --> Config Class Initialized
INFO - 2023-05-01 18:13:12 --> Hooks Class Initialized
DEBUG - 2023-05-01 18:13:12 --> UTF-8 Support Enabled
INFO - 2023-05-01 18:13:12 --> Utf8 Class Initialized
INFO - 2023-05-01 18:13:12 --> URI Class Initialized
INFO - 2023-05-01 18:13:12 --> Router Class Initialized
INFO - 2023-05-01 18:13:12 --> Output Class Initialized
INFO - 2023-05-01 18:13:12 --> Security Class Initialized
DEBUG - 2023-05-01 18:13:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-01 18:13:12 --> Input Class Initialized
INFO - 2023-05-01 18:13:12 --> Language Class Initialized
INFO - 2023-05-01 18:13:12 --> Loader Class Initialized
INFO - 2023-05-01 18:13:12 --> Helper loaded: url_helper
INFO - 2023-05-01 18:13:12 --> Helper loaded: file_helper
INFO - 2023-05-01 18:13:12 --> Helper loaded: html_helper
INFO - 2023-05-01 18:13:12 --> Helper loaded: text_helper
INFO - 2023-05-01 18:13:12 --> Helper loaded: form_helper
INFO - 2023-05-01 18:13:12 --> Helper loaded: lang_helper
INFO - 2023-05-01 18:13:12 --> Helper loaded: security_helper
INFO - 2023-05-01 18:13:12 --> Helper loaded: cookie_helper
INFO - 2023-05-01 18:13:12 --> Database Driver Class Initialized
INFO - 2023-05-01 18:13:12 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-01 18:13:12 --> Parser Class Initialized
INFO - 2023-05-01 18:13:12 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-01 18:13:12 --> Pagination Class Initialized
INFO - 2023-05-01 18:13:12 --> Form Validation Class Initialized
INFO - 2023-05-01 18:13:12 --> Controller Class Initialized
DEBUG - 2023-05-01 18:13:12 --> Auth class already loaded. Second attempt ignored.
INFO - 2023-05-01 18:13:12 --> Model Class Initialized
INFO - 2023-05-01 18:13:12 --> Model Class Initialized
ERROR - 2023-05-01 18:13:13 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-01 18:13:13 --> Config Class Initialized
INFO - 2023-05-01 18:13:13 --> Hooks Class Initialized
DEBUG - 2023-05-01 18:13:13 --> UTF-8 Support Enabled
INFO - 2023-05-01 18:13:13 --> Utf8 Class Initialized
INFO - 2023-05-01 18:13:13 --> URI Class Initialized
INFO - 2023-05-01 18:13:13 --> Router Class Initialized
INFO - 2023-05-01 18:13:13 --> Output Class Initialized
INFO - 2023-05-01 18:13:13 --> Security Class Initialized
DEBUG - 2023-05-01 18:13:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-01 18:13:13 --> Input Class Initialized
INFO - 2023-05-01 18:13:13 --> Language Class Initialized
INFO - 2023-05-01 18:13:13 --> Loader Class Initialized
INFO - 2023-05-01 18:13:13 --> Helper loaded: url_helper
INFO - 2023-05-01 18:13:13 --> Helper loaded: file_helper
INFO - 2023-05-01 18:13:13 --> Helper loaded: html_helper
INFO - 2023-05-01 18:13:13 --> Helper loaded: text_helper
INFO - 2023-05-01 18:13:13 --> Helper loaded: form_helper
INFO - 2023-05-01 18:13:13 --> Helper loaded: lang_helper
INFO - 2023-05-01 18:13:13 --> Helper loaded: security_helper
INFO - 2023-05-01 18:13:13 --> Helper loaded: cookie_helper
INFO - 2023-05-01 18:13:13 --> Database Driver Class Initialized
INFO - 2023-05-01 18:13:13 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-01 18:13:13 --> Parser Class Initialized
INFO - 2023-05-01 18:13:13 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-01 18:13:13 --> Pagination Class Initialized
INFO - 2023-05-01 18:13:13 --> Form Validation Class Initialized
INFO - 2023-05-01 18:13:13 --> Controller Class Initialized
DEBUG - 2023-05-01 18:13:13 --> Auth class already loaded. Second attempt ignored.
INFO - 2023-05-01 18:13:13 --> Model Class Initialized
INFO - 2023-05-01 18:13:13 --> Model Class Initialized
INFO - 2023-05-01 18:13:13 --> Model Class Initialized
INFO - 2023-05-01 18:13:13 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/product/product.php
DEBUG - 2023-05-01 18:13:13 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-05-01 18:13:13 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-05-01 18:13:13 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-05-01 18:13:13 --> Model Class Initialized
INFO - 2023-05-01 18:13:13 --> Model Class Initialized
INFO - 2023-05-01 18:13:13 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-05-01 18:13:13 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-05-01 18:13:13 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-05-01 18:13:13 --> Final output sent to browser
DEBUG - 2023-05-01 18:13:13 --> Total execution time: 0.1273
ERROR - 2023-05-01 18:13:14 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-01 18:13:14 --> Config Class Initialized
INFO - 2023-05-01 18:13:14 --> Hooks Class Initialized
DEBUG - 2023-05-01 18:13:14 --> UTF-8 Support Enabled
INFO - 2023-05-01 18:13:14 --> Utf8 Class Initialized
INFO - 2023-05-01 18:13:14 --> URI Class Initialized
INFO - 2023-05-01 18:13:14 --> Router Class Initialized
INFO - 2023-05-01 18:13:14 --> Output Class Initialized
INFO - 2023-05-01 18:13:14 --> Security Class Initialized
DEBUG - 2023-05-01 18:13:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-01 18:13:14 --> Input Class Initialized
INFO - 2023-05-01 18:13:14 --> Language Class Initialized
INFO - 2023-05-01 18:13:14 --> Loader Class Initialized
INFO - 2023-05-01 18:13:14 --> Helper loaded: url_helper
INFO - 2023-05-01 18:13:14 --> Helper loaded: file_helper
INFO - 2023-05-01 18:13:14 --> Helper loaded: html_helper
INFO - 2023-05-01 18:13:14 --> Helper loaded: text_helper
INFO - 2023-05-01 18:13:14 --> Helper loaded: form_helper
INFO - 2023-05-01 18:13:14 --> Helper loaded: lang_helper
INFO - 2023-05-01 18:13:14 --> Helper loaded: security_helper
INFO - 2023-05-01 18:13:14 --> Helper loaded: cookie_helper
INFO - 2023-05-01 18:13:14 --> Database Driver Class Initialized
INFO - 2023-05-01 18:13:14 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-01 18:13:14 --> Parser Class Initialized
INFO - 2023-05-01 18:13:14 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-01 18:13:14 --> Pagination Class Initialized
INFO - 2023-05-01 18:13:14 --> Form Validation Class Initialized
INFO - 2023-05-01 18:13:14 --> Controller Class Initialized
DEBUG - 2023-05-01 18:13:14 --> Auth class already loaded. Second attempt ignored.
INFO - 2023-05-01 18:13:14 --> Model Class Initialized
INFO - 2023-05-01 18:13:14 --> Model Class Initialized
INFO - 2023-05-01 18:13:14 --> Final output sent to browser
DEBUG - 2023-05-01 18:13:14 --> Total execution time: 0.0420
ERROR - 2023-05-01 18:13:17 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-01 18:13:17 --> Config Class Initialized
INFO - 2023-05-01 18:13:17 --> Hooks Class Initialized
DEBUG - 2023-05-01 18:13:17 --> UTF-8 Support Enabled
INFO - 2023-05-01 18:13:17 --> Utf8 Class Initialized
INFO - 2023-05-01 18:13:17 --> URI Class Initialized
INFO - 2023-05-01 18:13:17 --> Router Class Initialized
INFO - 2023-05-01 18:13:17 --> Output Class Initialized
INFO - 2023-05-01 18:13:17 --> Security Class Initialized
DEBUG - 2023-05-01 18:13:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-01 18:13:17 --> Input Class Initialized
INFO - 2023-05-01 18:13:17 --> Language Class Initialized
INFO - 2023-05-01 18:13:17 --> Loader Class Initialized
INFO - 2023-05-01 18:13:17 --> Helper loaded: url_helper
INFO - 2023-05-01 18:13:17 --> Helper loaded: file_helper
INFO - 2023-05-01 18:13:17 --> Helper loaded: html_helper
INFO - 2023-05-01 18:13:17 --> Helper loaded: text_helper
INFO - 2023-05-01 18:13:17 --> Helper loaded: form_helper
INFO - 2023-05-01 18:13:17 --> Helper loaded: lang_helper
INFO - 2023-05-01 18:13:17 --> Helper loaded: security_helper
INFO - 2023-05-01 18:13:17 --> Helper loaded: cookie_helper
INFO - 2023-05-01 18:13:17 --> Database Driver Class Initialized
INFO - 2023-05-01 18:13:17 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-01 18:13:17 --> Parser Class Initialized
INFO - 2023-05-01 18:13:17 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-01 18:13:17 --> Pagination Class Initialized
INFO - 2023-05-01 18:13:17 --> Form Validation Class Initialized
INFO - 2023-05-01 18:13:17 --> Controller Class Initialized
DEBUG - 2023-05-01 18:13:17 --> Auth class already loaded. Second attempt ignored.
INFO - 2023-05-01 18:13:17 --> Model Class Initialized
INFO - 2023-05-01 18:13:17 --> Model Class Initialized
INFO - 2023-05-01 18:13:17 --> Final output sent to browser
DEBUG - 2023-05-01 18:13:17 --> Total execution time: 0.0986
ERROR - 2023-05-01 18:14:12 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-01 18:14:12 --> Config Class Initialized
INFO - 2023-05-01 18:14:12 --> Hooks Class Initialized
DEBUG - 2023-05-01 18:14:12 --> UTF-8 Support Enabled
INFO - 2023-05-01 18:14:12 --> Utf8 Class Initialized
INFO - 2023-05-01 18:14:12 --> URI Class Initialized
INFO - 2023-05-01 18:14:12 --> Router Class Initialized
INFO - 2023-05-01 18:14:12 --> Output Class Initialized
INFO - 2023-05-01 18:14:12 --> Security Class Initialized
DEBUG - 2023-05-01 18:14:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-01 18:14:12 --> Input Class Initialized
INFO - 2023-05-01 18:14:12 --> Language Class Initialized
INFO - 2023-05-01 18:14:12 --> Loader Class Initialized
INFO - 2023-05-01 18:14:12 --> Helper loaded: url_helper
INFO - 2023-05-01 18:14:12 --> Helper loaded: file_helper
INFO - 2023-05-01 18:14:12 --> Helper loaded: html_helper
INFO - 2023-05-01 18:14:12 --> Helper loaded: text_helper
INFO - 2023-05-01 18:14:12 --> Helper loaded: form_helper
INFO - 2023-05-01 18:14:12 --> Helper loaded: lang_helper
INFO - 2023-05-01 18:14:12 --> Helper loaded: security_helper
INFO - 2023-05-01 18:14:12 --> Helper loaded: cookie_helper
INFO - 2023-05-01 18:14:12 --> Database Driver Class Initialized
INFO - 2023-05-01 18:14:12 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-01 18:14:12 --> Parser Class Initialized
INFO - 2023-05-01 18:14:12 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-01 18:14:12 --> Pagination Class Initialized
INFO - 2023-05-01 18:14:12 --> Form Validation Class Initialized
INFO - 2023-05-01 18:14:12 --> Controller Class Initialized
DEBUG - 2023-05-01 18:14:12 --> Auth class already loaded. Second attempt ignored.
INFO - 2023-05-01 18:14:12 --> Model Class Initialized
INFO - 2023-05-01 18:14:12 --> Model Class Initialized
INFO - 2023-05-01 18:14:12 --> Model Class Initialized
INFO - 2023-05-01 18:14:12 --> Model Class Initialized
INFO - 2023-05-01 18:14:12 --> Model Class Initialized
INFO - 2023-05-01 18:14:12 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/product/edit_product_form.php
DEBUG - 2023-05-01 18:14:12 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-05-01 18:14:12 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-05-01 18:14:12 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-05-01 18:14:12 --> Model Class Initialized
INFO - 2023-05-01 18:14:12 --> Model Class Initialized
INFO - 2023-05-01 18:14:12 --> Model Class Initialized
INFO - 2023-05-01 18:14:13 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-05-01 18:14:13 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-05-01 18:14:13 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-05-01 18:14:13 --> Final output sent to browser
DEBUG - 2023-05-01 18:14:13 --> Total execution time: 0.1497
ERROR - 2023-05-01 18:14:20 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-01 18:14:20 --> Config Class Initialized
INFO - 2023-05-01 18:14:20 --> Hooks Class Initialized
DEBUG - 2023-05-01 18:14:20 --> UTF-8 Support Enabled
INFO - 2023-05-01 18:14:20 --> Utf8 Class Initialized
INFO - 2023-05-01 18:14:20 --> URI Class Initialized
INFO - 2023-05-01 18:14:20 --> Router Class Initialized
INFO - 2023-05-01 18:14:20 --> Output Class Initialized
INFO - 2023-05-01 18:14:20 --> Security Class Initialized
DEBUG - 2023-05-01 18:14:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-01 18:14:20 --> Input Class Initialized
INFO - 2023-05-01 18:14:20 --> Language Class Initialized
INFO - 2023-05-01 18:14:20 --> Loader Class Initialized
INFO - 2023-05-01 18:14:20 --> Helper loaded: url_helper
INFO - 2023-05-01 18:14:20 --> Helper loaded: file_helper
INFO - 2023-05-01 18:14:20 --> Helper loaded: html_helper
INFO - 2023-05-01 18:14:20 --> Helper loaded: text_helper
INFO - 2023-05-01 18:14:20 --> Helper loaded: form_helper
INFO - 2023-05-01 18:14:20 --> Helper loaded: lang_helper
INFO - 2023-05-01 18:14:20 --> Helper loaded: security_helper
INFO - 2023-05-01 18:14:20 --> Helper loaded: cookie_helper
INFO - 2023-05-01 18:14:20 --> Database Driver Class Initialized
INFO - 2023-05-01 18:14:20 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-01 18:14:20 --> Parser Class Initialized
INFO - 2023-05-01 18:14:20 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-01 18:14:20 --> Pagination Class Initialized
INFO - 2023-05-01 18:14:20 --> Form Validation Class Initialized
INFO - 2023-05-01 18:14:20 --> Controller Class Initialized
DEBUG - 2023-05-01 18:14:20 --> Auth class already loaded. Second attempt ignored.
INFO - 2023-05-01 18:14:20 --> Model Class Initialized
INFO - 2023-05-01 18:14:20 --> Model Class Initialized
ERROR - 2023-05-01 18:14:21 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-01 18:14:21 --> Config Class Initialized
INFO - 2023-05-01 18:14:21 --> Hooks Class Initialized
DEBUG - 2023-05-01 18:14:21 --> UTF-8 Support Enabled
INFO - 2023-05-01 18:14:21 --> Utf8 Class Initialized
INFO - 2023-05-01 18:14:21 --> URI Class Initialized
INFO - 2023-05-01 18:14:21 --> Router Class Initialized
INFO - 2023-05-01 18:14:21 --> Output Class Initialized
INFO - 2023-05-01 18:14:21 --> Security Class Initialized
DEBUG - 2023-05-01 18:14:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-01 18:14:21 --> Input Class Initialized
INFO - 2023-05-01 18:14:21 --> Language Class Initialized
INFO - 2023-05-01 18:14:21 --> Loader Class Initialized
INFO - 2023-05-01 18:14:21 --> Helper loaded: url_helper
INFO - 2023-05-01 18:14:21 --> Helper loaded: file_helper
INFO - 2023-05-01 18:14:21 --> Helper loaded: html_helper
INFO - 2023-05-01 18:14:21 --> Helper loaded: text_helper
INFO - 2023-05-01 18:14:21 --> Helper loaded: form_helper
INFO - 2023-05-01 18:14:21 --> Helper loaded: lang_helper
INFO - 2023-05-01 18:14:21 --> Helper loaded: security_helper
INFO - 2023-05-01 18:14:21 --> Helper loaded: cookie_helper
INFO - 2023-05-01 18:14:21 --> Database Driver Class Initialized
INFO - 2023-05-01 18:14:21 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-01 18:14:21 --> Parser Class Initialized
INFO - 2023-05-01 18:14:21 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-01 18:14:21 --> Pagination Class Initialized
INFO - 2023-05-01 18:14:21 --> Form Validation Class Initialized
INFO - 2023-05-01 18:14:21 --> Controller Class Initialized
DEBUG - 2023-05-01 18:14:21 --> Auth class already loaded. Second attempt ignored.
INFO - 2023-05-01 18:14:21 --> Model Class Initialized
INFO - 2023-05-01 18:14:21 --> Model Class Initialized
INFO - 2023-05-01 18:14:21 --> Model Class Initialized
INFO - 2023-05-01 18:14:21 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/product/product.php
DEBUG - 2023-05-01 18:14:21 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-05-01 18:14:21 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-05-01 18:14:21 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-05-01 18:14:21 --> Model Class Initialized
INFO - 2023-05-01 18:14:21 --> Model Class Initialized
INFO - 2023-05-01 18:14:21 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-05-01 18:14:21 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-05-01 18:14:21 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-05-01 18:14:21 --> Final output sent to browser
DEBUG - 2023-05-01 18:14:21 --> Total execution time: 0.1358
ERROR - 2023-05-01 18:14:22 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-01 18:14:22 --> Config Class Initialized
INFO - 2023-05-01 18:14:22 --> Hooks Class Initialized
DEBUG - 2023-05-01 18:14:22 --> UTF-8 Support Enabled
INFO - 2023-05-01 18:14:22 --> Utf8 Class Initialized
INFO - 2023-05-01 18:14:22 --> URI Class Initialized
INFO - 2023-05-01 18:14:22 --> Router Class Initialized
INFO - 2023-05-01 18:14:22 --> Output Class Initialized
INFO - 2023-05-01 18:14:22 --> Security Class Initialized
DEBUG - 2023-05-01 18:14:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-01 18:14:22 --> Input Class Initialized
INFO - 2023-05-01 18:14:22 --> Language Class Initialized
INFO - 2023-05-01 18:14:22 --> Loader Class Initialized
INFO - 2023-05-01 18:14:22 --> Helper loaded: url_helper
INFO - 2023-05-01 18:14:22 --> Helper loaded: file_helper
INFO - 2023-05-01 18:14:22 --> Helper loaded: html_helper
INFO - 2023-05-01 18:14:22 --> Helper loaded: text_helper
INFO - 2023-05-01 18:14:22 --> Helper loaded: form_helper
INFO - 2023-05-01 18:14:22 --> Helper loaded: lang_helper
INFO - 2023-05-01 18:14:22 --> Helper loaded: security_helper
INFO - 2023-05-01 18:14:22 --> Helper loaded: cookie_helper
INFO - 2023-05-01 18:14:22 --> Database Driver Class Initialized
INFO - 2023-05-01 18:14:22 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-01 18:14:22 --> Parser Class Initialized
INFO - 2023-05-01 18:14:22 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-01 18:14:22 --> Pagination Class Initialized
INFO - 2023-05-01 18:14:22 --> Form Validation Class Initialized
INFO - 2023-05-01 18:14:22 --> Controller Class Initialized
DEBUG - 2023-05-01 18:14:22 --> Auth class already loaded. Second attempt ignored.
INFO - 2023-05-01 18:14:22 --> Model Class Initialized
INFO - 2023-05-01 18:14:22 --> Model Class Initialized
INFO - 2023-05-01 18:14:22 --> Final output sent to browser
DEBUG - 2023-05-01 18:14:22 --> Total execution time: 0.0508
ERROR - 2023-05-01 18:14:28 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-01 18:14:28 --> Config Class Initialized
INFO - 2023-05-01 18:14:28 --> Hooks Class Initialized
DEBUG - 2023-05-01 18:14:28 --> UTF-8 Support Enabled
INFO - 2023-05-01 18:14:28 --> Utf8 Class Initialized
INFO - 2023-05-01 18:14:28 --> URI Class Initialized
INFO - 2023-05-01 18:14:28 --> Router Class Initialized
INFO - 2023-05-01 18:14:28 --> Output Class Initialized
INFO - 2023-05-01 18:14:28 --> Security Class Initialized
DEBUG - 2023-05-01 18:14:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-01 18:14:28 --> Input Class Initialized
INFO - 2023-05-01 18:14:28 --> Language Class Initialized
INFO - 2023-05-01 18:14:28 --> Loader Class Initialized
INFO - 2023-05-01 18:14:28 --> Helper loaded: url_helper
INFO - 2023-05-01 18:14:28 --> Helper loaded: file_helper
INFO - 2023-05-01 18:14:28 --> Helper loaded: html_helper
INFO - 2023-05-01 18:14:28 --> Helper loaded: text_helper
INFO - 2023-05-01 18:14:28 --> Helper loaded: form_helper
INFO - 2023-05-01 18:14:28 --> Helper loaded: lang_helper
INFO - 2023-05-01 18:14:28 --> Helper loaded: security_helper
INFO - 2023-05-01 18:14:28 --> Helper loaded: cookie_helper
INFO - 2023-05-01 18:14:28 --> Database Driver Class Initialized
INFO - 2023-05-01 18:14:28 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-01 18:14:28 --> Parser Class Initialized
INFO - 2023-05-01 18:14:28 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-01 18:14:28 --> Pagination Class Initialized
INFO - 2023-05-01 18:14:28 --> Form Validation Class Initialized
INFO - 2023-05-01 18:14:28 --> Controller Class Initialized
DEBUG - 2023-05-01 18:14:28 --> Auth class already loaded. Second attempt ignored.
INFO - 2023-05-01 18:14:28 --> Model Class Initialized
INFO - 2023-05-01 18:14:28 --> Model Class Initialized
INFO - 2023-05-01 18:14:28 --> Final output sent to browser
DEBUG - 2023-05-01 18:14:28 --> Total execution time: 0.1041
ERROR - 2023-05-01 18:14:56 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-01 18:14:56 --> Config Class Initialized
INFO - 2023-05-01 18:14:56 --> Hooks Class Initialized
DEBUG - 2023-05-01 18:14:56 --> UTF-8 Support Enabled
INFO - 2023-05-01 18:14:56 --> Utf8 Class Initialized
INFO - 2023-05-01 18:14:56 --> URI Class Initialized
INFO - 2023-05-01 18:14:56 --> Router Class Initialized
INFO - 2023-05-01 18:14:56 --> Output Class Initialized
INFO - 2023-05-01 18:14:56 --> Security Class Initialized
DEBUG - 2023-05-01 18:14:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-01 18:14:56 --> Input Class Initialized
INFO - 2023-05-01 18:14:56 --> Language Class Initialized
INFO - 2023-05-01 18:14:56 --> Loader Class Initialized
INFO - 2023-05-01 18:14:56 --> Helper loaded: url_helper
INFO - 2023-05-01 18:14:56 --> Helper loaded: file_helper
INFO - 2023-05-01 18:14:56 --> Helper loaded: html_helper
INFO - 2023-05-01 18:14:56 --> Helper loaded: text_helper
INFO - 2023-05-01 18:14:56 --> Helper loaded: form_helper
INFO - 2023-05-01 18:14:56 --> Helper loaded: lang_helper
INFO - 2023-05-01 18:14:56 --> Helper loaded: security_helper
INFO - 2023-05-01 18:14:56 --> Helper loaded: cookie_helper
INFO - 2023-05-01 18:14:56 --> Database Driver Class Initialized
INFO - 2023-05-01 18:14:56 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-01 18:14:56 --> Parser Class Initialized
INFO - 2023-05-01 18:14:56 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-01 18:14:56 --> Pagination Class Initialized
INFO - 2023-05-01 18:14:56 --> Form Validation Class Initialized
INFO - 2023-05-01 18:14:56 --> Controller Class Initialized
DEBUG - 2023-05-01 18:14:56 --> Auth class already loaded. Second attempt ignored.
INFO - 2023-05-01 18:14:56 --> Model Class Initialized
INFO - 2023-05-01 18:14:56 --> Model Class Initialized
INFO - 2023-05-01 18:14:56 --> Model Class Initialized
INFO - 2023-05-01 18:14:56 --> Model Class Initialized
INFO - 2023-05-01 18:14:56 --> Model Class Initialized
INFO - 2023-05-01 18:14:57 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/product/edit_product_form.php
DEBUG - 2023-05-01 18:14:57 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-05-01 18:14:57 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-05-01 18:14:57 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-05-01 18:14:57 --> Model Class Initialized
INFO - 2023-05-01 18:14:57 --> Model Class Initialized
INFO - 2023-05-01 18:14:57 --> Model Class Initialized
INFO - 2023-05-01 18:14:57 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-05-01 18:14:57 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-05-01 18:14:57 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-05-01 18:14:57 --> Final output sent to browser
DEBUG - 2023-05-01 18:14:57 --> Total execution time: 0.1429
ERROR - 2023-05-01 18:15:16 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-01 18:15:16 --> Config Class Initialized
INFO - 2023-05-01 18:15:16 --> Hooks Class Initialized
DEBUG - 2023-05-01 18:15:16 --> UTF-8 Support Enabled
INFO - 2023-05-01 18:15:16 --> Utf8 Class Initialized
INFO - 2023-05-01 18:15:16 --> URI Class Initialized
INFO - 2023-05-01 18:15:16 --> Router Class Initialized
INFO - 2023-05-01 18:15:16 --> Output Class Initialized
INFO - 2023-05-01 18:15:16 --> Security Class Initialized
DEBUG - 2023-05-01 18:15:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-01 18:15:16 --> Input Class Initialized
INFO - 2023-05-01 18:15:16 --> Language Class Initialized
INFO - 2023-05-01 18:15:16 --> Loader Class Initialized
INFO - 2023-05-01 18:15:16 --> Helper loaded: url_helper
INFO - 2023-05-01 18:15:16 --> Helper loaded: file_helper
INFO - 2023-05-01 18:15:16 --> Helper loaded: html_helper
INFO - 2023-05-01 18:15:16 --> Helper loaded: text_helper
INFO - 2023-05-01 18:15:16 --> Helper loaded: form_helper
INFO - 2023-05-01 18:15:16 --> Helper loaded: lang_helper
INFO - 2023-05-01 18:15:16 --> Helper loaded: security_helper
INFO - 2023-05-01 18:15:16 --> Helper loaded: cookie_helper
INFO - 2023-05-01 18:15:16 --> Database Driver Class Initialized
INFO - 2023-05-01 18:15:16 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-01 18:15:16 --> Parser Class Initialized
INFO - 2023-05-01 18:15:16 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-01 18:15:16 --> Pagination Class Initialized
INFO - 2023-05-01 18:15:16 --> Form Validation Class Initialized
INFO - 2023-05-01 18:15:16 --> Controller Class Initialized
DEBUG - 2023-05-01 18:15:16 --> Auth class already loaded. Second attempt ignored.
INFO - 2023-05-01 18:15:16 --> Model Class Initialized
INFO - 2023-05-01 18:15:16 --> Model Class Initialized
ERROR - 2023-05-01 18:15:17 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-01 18:15:17 --> Config Class Initialized
INFO - 2023-05-01 18:15:17 --> Hooks Class Initialized
DEBUG - 2023-05-01 18:15:17 --> UTF-8 Support Enabled
INFO - 2023-05-01 18:15:17 --> Utf8 Class Initialized
INFO - 2023-05-01 18:15:17 --> URI Class Initialized
INFO - 2023-05-01 18:15:17 --> Router Class Initialized
INFO - 2023-05-01 18:15:17 --> Output Class Initialized
INFO - 2023-05-01 18:15:17 --> Security Class Initialized
DEBUG - 2023-05-01 18:15:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-01 18:15:17 --> Input Class Initialized
INFO - 2023-05-01 18:15:17 --> Language Class Initialized
INFO - 2023-05-01 18:15:17 --> Loader Class Initialized
INFO - 2023-05-01 18:15:17 --> Helper loaded: url_helper
INFO - 2023-05-01 18:15:17 --> Helper loaded: file_helper
INFO - 2023-05-01 18:15:17 --> Helper loaded: html_helper
INFO - 2023-05-01 18:15:17 --> Helper loaded: text_helper
INFO - 2023-05-01 18:15:17 --> Helper loaded: form_helper
INFO - 2023-05-01 18:15:17 --> Helper loaded: lang_helper
INFO - 2023-05-01 18:15:17 --> Helper loaded: security_helper
INFO - 2023-05-01 18:15:17 --> Helper loaded: cookie_helper
INFO - 2023-05-01 18:15:17 --> Database Driver Class Initialized
INFO - 2023-05-01 18:15:17 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-01 18:15:17 --> Parser Class Initialized
INFO - 2023-05-01 18:15:17 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-01 18:15:17 --> Pagination Class Initialized
INFO - 2023-05-01 18:15:17 --> Form Validation Class Initialized
INFO - 2023-05-01 18:15:17 --> Controller Class Initialized
DEBUG - 2023-05-01 18:15:17 --> Auth class already loaded. Second attempt ignored.
INFO - 2023-05-01 18:15:17 --> Model Class Initialized
INFO - 2023-05-01 18:15:17 --> Model Class Initialized
INFO - 2023-05-01 18:15:17 --> Model Class Initialized
INFO - 2023-05-01 18:15:17 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/product/product.php
DEBUG - 2023-05-01 18:15:17 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-05-01 18:15:17 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-05-01 18:15:17 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-05-01 18:15:17 --> Model Class Initialized
INFO - 2023-05-01 18:15:17 --> Model Class Initialized
INFO - 2023-05-01 18:15:17 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-05-01 18:15:17 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-05-01 18:15:17 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-05-01 18:15:17 --> Final output sent to browser
DEBUG - 2023-05-01 18:15:17 --> Total execution time: 0.1184
ERROR - 2023-05-01 18:15:18 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-01 18:15:18 --> Config Class Initialized
INFO - 2023-05-01 18:15:18 --> Hooks Class Initialized
DEBUG - 2023-05-01 18:15:18 --> UTF-8 Support Enabled
INFO - 2023-05-01 18:15:18 --> Utf8 Class Initialized
INFO - 2023-05-01 18:15:18 --> URI Class Initialized
INFO - 2023-05-01 18:15:18 --> Router Class Initialized
INFO - 2023-05-01 18:15:18 --> Output Class Initialized
INFO - 2023-05-01 18:15:18 --> Security Class Initialized
DEBUG - 2023-05-01 18:15:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-01 18:15:18 --> Input Class Initialized
INFO - 2023-05-01 18:15:18 --> Language Class Initialized
INFO - 2023-05-01 18:15:18 --> Loader Class Initialized
INFO - 2023-05-01 18:15:18 --> Helper loaded: url_helper
INFO - 2023-05-01 18:15:18 --> Helper loaded: file_helper
INFO - 2023-05-01 18:15:18 --> Helper loaded: html_helper
INFO - 2023-05-01 18:15:18 --> Helper loaded: text_helper
INFO - 2023-05-01 18:15:18 --> Helper loaded: form_helper
INFO - 2023-05-01 18:15:18 --> Helper loaded: lang_helper
INFO - 2023-05-01 18:15:18 --> Helper loaded: security_helper
INFO - 2023-05-01 18:15:18 --> Helper loaded: cookie_helper
INFO - 2023-05-01 18:15:18 --> Database Driver Class Initialized
INFO - 2023-05-01 18:15:18 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-01 18:15:18 --> Parser Class Initialized
INFO - 2023-05-01 18:15:18 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-01 18:15:18 --> Pagination Class Initialized
INFO - 2023-05-01 18:15:18 --> Form Validation Class Initialized
INFO - 2023-05-01 18:15:18 --> Controller Class Initialized
DEBUG - 2023-05-01 18:15:18 --> Auth class already loaded. Second attempt ignored.
INFO - 2023-05-01 18:15:18 --> Model Class Initialized
INFO - 2023-05-01 18:15:18 --> Model Class Initialized
INFO - 2023-05-01 18:15:18 --> Final output sent to browser
DEBUG - 2023-05-01 18:15:18 --> Total execution time: 0.0423
ERROR - 2023-05-01 18:15:25 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-01 18:15:25 --> Config Class Initialized
INFO - 2023-05-01 18:15:25 --> Hooks Class Initialized
DEBUG - 2023-05-01 18:15:25 --> UTF-8 Support Enabled
INFO - 2023-05-01 18:15:25 --> Utf8 Class Initialized
INFO - 2023-05-01 18:15:25 --> URI Class Initialized
INFO - 2023-05-01 18:15:25 --> Router Class Initialized
INFO - 2023-05-01 18:15:25 --> Output Class Initialized
INFO - 2023-05-01 18:15:25 --> Security Class Initialized
DEBUG - 2023-05-01 18:15:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-01 18:15:25 --> Input Class Initialized
INFO - 2023-05-01 18:15:25 --> Language Class Initialized
INFO - 2023-05-01 18:15:25 --> Loader Class Initialized
INFO - 2023-05-01 18:15:25 --> Helper loaded: url_helper
INFO - 2023-05-01 18:15:25 --> Helper loaded: file_helper
INFO - 2023-05-01 18:15:25 --> Helper loaded: html_helper
INFO - 2023-05-01 18:15:25 --> Helper loaded: text_helper
INFO - 2023-05-01 18:15:25 --> Helper loaded: form_helper
INFO - 2023-05-01 18:15:25 --> Helper loaded: lang_helper
INFO - 2023-05-01 18:15:25 --> Helper loaded: security_helper
INFO - 2023-05-01 18:15:25 --> Helper loaded: cookie_helper
INFO - 2023-05-01 18:15:25 --> Database Driver Class Initialized
INFO - 2023-05-01 18:15:25 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-01 18:15:25 --> Parser Class Initialized
INFO - 2023-05-01 18:15:25 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-01 18:15:25 --> Pagination Class Initialized
INFO - 2023-05-01 18:15:25 --> Form Validation Class Initialized
INFO - 2023-05-01 18:15:25 --> Controller Class Initialized
DEBUG - 2023-05-01 18:15:25 --> Auth class already loaded. Second attempt ignored.
INFO - 2023-05-01 18:15:25 --> Model Class Initialized
INFO - 2023-05-01 18:15:25 --> Model Class Initialized
INFO - 2023-05-01 18:15:25 --> Final output sent to browser
DEBUG - 2023-05-01 18:15:25 --> Total execution time: 0.0979
ERROR - 2023-05-01 18:25:41 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-01 18:25:41 --> Config Class Initialized
INFO - 2023-05-01 18:25:41 --> Hooks Class Initialized
DEBUG - 2023-05-01 18:25:41 --> UTF-8 Support Enabled
INFO - 2023-05-01 18:25:41 --> Utf8 Class Initialized
INFO - 2023-05-01 18:25:41 --> URI Class Initialized
INFO - 2023-05-01 18:25:41 --> Router Class Initialized
INFO - 2023-05-01 18:25:41 --> Output Class Initialized
INFO - 2023-05-01 18:25:41 --> Security Class Initialized
DEBUG - 2023-05-01 18:25:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-01 18:25:41 --> Input Class Initialized
INFO - 2023-05-01 18:25:41 --> Language Class Initialized
INFO - 2023-05-01 18:25:41 --> Loader Class Initialized
INFO - 2023-05-01 18:25:41 --> Helper loaded: url_helper
INFO - 2023-05-01 18:25:41 --> Helper loaded: file_helper
INFO - 2023-05-01 18:25:41 --> Helper loaded: html_helper
INFO - 2023-05-01 18:25:41 --> Helper loaded: text_helper
INFO - 2023-05-01 18:25:41 --> Helper loaded: form_helper
INFO - 2023-05-01 18:25:41 --> Helper loaded: lang_helper
INFO - 2023-05-01 18:25:41 --> Helper loaded: security_helper
INFO - 2023-05-01 18:25:41 --> Helper loaded: cookie_helper
INFO - 2023-05-01 18:25:41 --> Database Driver Class Initialized
INFO - 2023-05-01 18:25:41 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-01 18:25:41 --> Parser Class Initialized
INFO - 2023-05-01 18:25:41 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-01 18:25:41 --> Pagination Class Initialized
INFO - 2023-05-01 18:25:41 --> Form Validation Class Initialized
INFO - 2023-05-01 18:25:41 --> Controller Class Initialized
INFO - 2023-05-01 18:25:41 --> Model Class Initialized
INFO - 2023-05-01 18:25:41 --> Model Class Initialized
INFO - 2023-05-01 18:25:41 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/purchase/purchase.php
DEBUG - 2023-05-01 18:25:41 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-05-01 18:25:41 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-05-01 18:25:41 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-05-01 18:25:41 --> Model Class Initialized
INFO - 2023-05-01 18:25:41 --> Model Class Initialized
INFO - 2023-05-01 18:25:41 --> Model Class Initialized
INFO - 2023-05-01 18:25:41 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-05-01 18:25:41 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-05-01 18:25:41 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-05-01 18:25:41 --> Final output sent to browser
DEBUG - 2023-05-01 18:25:41 --> Total execution time: 0.1244
ERROR - 2023-05-01 18:25:42 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-01 18:25:42 --> Config Class Initialized
INFO - 2023-05-01 18:25:42 --> Hooks Class Initialized
DEBUG - 2023-05-01 18:25:42 --> UTF-8 Support Enabled
INFO - 2023-05-01 18:25:42 --> Utf8 Class Initialized
INFO - 2023-05-01 18:25:42 --> URI Class Initialized
INFO - 2023-05-01 18:25:42 --> Router Class Initialized
INFO - 2023-05-01 18:25:42 --> Output Class Initialized
INFO - 2023-05-01 18:25:42 --> Security Class Initialized
DEBUG - 2023-05-01 18:25:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-01 18:25:42 --> Input Class Initialized
INFO - 2023-05-01 18:25:42 --> Language Class Initialized
INFO - 2023-05-01 18:25:42 --> Loader Class Initialized
INFO - 2023-05-01 18:25:42 --> Helper loaded: url_helper
INFO - 2023-05-01 18:25:42 --> Helper loaded: file_helper
INFO - 2023-05-01 18:25:42 --> Helper loaded: html_helper
INFO - 2023-05-01 18:25:42 --> Helper loaded: text_helper
INFO - 2023-05-01 18:25:42 --> Helper loaded: form_helper
INFO - 2023-05-01 18:25:42 --> Helper loaded: lang_helper
INFO - 2023-05-01 18:25:42 --> Helper loaded: security_helper
INFO - 2023-05-01 18:25:42 --> Helper loaded: cookie_helper
INFO - 2023-05-01 18:25:42 --> Database Driver Class Initialized
INFO - 2023-05-01 18:25:42 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-01 18:25:42 --> Parser Class Initialized
INFO - 2023-05-01 18:25:42 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-01 18:25:42 --> Pagination Class Initialized
INFO - 2023-05-01 18:25:42 --> Form Validation Class Initialized
INFO - 2023-05-01 18:25:42 --> Controller Class Initialized
INFO - 2023-05-01 18:25:42 --> Model Class Initialized
INFO - 2023-05-01 18:25:42 --> Model Class Initialized
INFO - 2023-05-01 18:25:42 --> Final output sent to browser
DEBUG - 2023-05-01 18:25:42 --> Total execution time: 0.0436
ERROR - 2023-05-01 18:25:50 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-01 18:25:50 --> Config Class Initialized
INFO - 2023-05-01 18:25:50 --> Hooks Class Initialized
DEBUG - 2023-05-01 18:25:50 --> UTF-8 Support Enabled
INFO - 2023-05-01 18:25:50 --> Utf8 Class Initialized
INFO - 2023-05-01 18:25:50 --> URI Class Initialized
INFO - 2023-05-01 18:25:50 --> Router Class Initialized
INFO - 2023-05-01 18:25:50 --> Output Class Initialized
INFO - 2023-05-01 18:25:50 --> Security Class Initialized
DEBUG - 2023-05-01 18:25:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-01 18:25:50 --> Input Class Initialized
INFO - 2023-05-01 18:25:50 --> Language Class Initialized
INFO - 2023-05-01 18:25:50 --> Loader Class Initialized
INFO - 2023-05-01 18:25:50 --> Helper loaded: url_helper
INFO - 2023-05-01 18:25:50 --> Helper loaded: file_helper
INFO - 2023-05-01 18:25:50 --> Helper loaded: html_helper
INFO - 2023-05-01 18:25:50 --> Helper loaded: text_helper
INFO - 2023-05-01 18:25:50 --> Helper loaded: form_helper
INFO - 2023-05-01 18:25:50 --> Helper loaded: lang_helper
INFO - 2023-05-01 18:25:50 --> Helper loaded: security_helper
INFO - 2023-05-01 18:25:50 --> Helper loaded: cookie_helper
INFO - 2023-05-01 18:25:50 --> Database Driver Class Initialized
INFO - 2023-05-01 18:25:50 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-01 18:25:50 --> Parser Class Initialized
INFO - 2023-05-01 18:25:50 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-01 18:25:50 --> Pagination Class Initialized
INFO - 2023-05-01 18:25:50 --> Form Validation Class Initialized
INFO - 2023-05-01 18:25:50 --> Controller Class Initialized
INFO - 2023-05-01 18:25:50 --> Model Class Initialized
DEBUG - 2023-05-01 18:25:50 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-05-01 18:25:50 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-01 18:25:50 --> Model Class Initialized
DEBUG - 2023-05-01 18:25:50 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-01 18:25:50 --> Model Class Initialized
INFO - 2023-05-01 18:25:50 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/invoice/invoice.php
DEBUG - 2023-05-01 18:25:50 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-05-01 18:25:50 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-05-01 18:25:50 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-05-01 18:25:50 --> Model Class Initialized
INFO - 2023-05-01 18:25:50 --> Model Class Initialized
INFO - 2023-05-01 18:25:50 --> Model Class Initialized
INFO - 2023-05-01 18:25:50 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-05-01 18:25:50 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-05-01 18:25:50 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-05-01 18:25:50 --> Final output sent to browser
DEBUG - 2023-05-01 18:25:50 --> Total execution time: 0.1218
ERROR - 2023-05-01 18:25:51 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-01 18:25:51 --> Config Class Initialized
INFO - 2023-05-01 18:25:51 --> Hooks Class Initialized
DEBUG - 2023-05-01 18:25:51 --> UTF-8 Support Enabled
INFO - 2023-05-01 18:25:51 --> Utf8 Class Initialized
INFO - 2023-05-01 18:25:51 --> URI Class Initialized
INFO - 2023-05-01 18:25:51 --> Router Class Initialized
INFO - 2023-05-01 18:25:51 --> Output Class Initialized
INFO - 2023-05-01 18:25:51 --> Security Class Initialized
DEBUG - 2023-05-01 18:25:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-01 18:25:51 --> Input Class Initialized
INFO - 2023-05-01 18:25:51 --> Language Class Initialized
INFO - 2023-05-01 18:25:51 --> Loader Class Initialized
INFO - 2023-05-01 18:25:51 --> Helper loaded: url_helper
INFO - 2023-05-01 18:25:51 --> Helper loaded: file_helper
INFO - 2023-05-01 18:25:51 --> Helper loaded: html_helper
INFO - 2023-05-01 18:25:51 --> Helper loaded: text_helper
INFO - 2023-05-01 18:25:51 --> Helper loaded: form_helper
INFO - 2023-05-01 18:25:51 --> Helper loaded: lang_helper
INFO - 2023-05-01 18:25:51 --> Helper loaded: security_helper
INFO - 2023-05-01 18:25:51 --> Helper loaded: cookie_helper
INFO - 2023-05-01 18:25:51 --> Database Driver Class Initialized
INFO - 2023-05-01 18:25:51 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-01 18:25:51 --> Parser Class Initialized
INFO - 2023-05-01 18:25:51 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-01 18:25:51 --> Pagination Class Initialized
INFO - 2023-05-01 18:25:51 --> Form Validation Class Initialized
INFO - 2023-05-01 18:25:51 --> Controller Class Initialized
INFO - 2023-05-01 18:25:51 --> Model Class Initialized
DEBUG - 2023-05-01 18:25:51 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-05-01 18:25:51 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-01 18:25:51 --> Model Class Initialized
DEBUG - 2023-05-01 18:25:51 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-01 18:25:51 --> Model Class Initialized
INFO - 2023-05-01 18:25:51 --> Final output sent to browser
DEBUG - 2023-05-01 18:25:51 --> Total execution time: 0.0331
ERROR - 2023-05-01 18:25:55 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-01 18:25:55 --> Config Class Initialized
INFO - 2023-05-01 18:25:55 --> Hooks Class Initialized
DEBUG - 2023-05-01 18:25:55 --> UTF-8 Support Enabled
INFO - 2023-05-01 18:25:55 --> Utf8 Class Initialized
INFO - 2023-05-01 18:25:55 --> URI Class Initialized
INFO - 2023-05-01 18:25:55 --> Router Class Initialized
INFO - 2023-05-01 18:25:55 --> Output Class Initialized
INFO - 2023-05-01 18:25:55 --> Security Class Initialized
DEBUG - 2023-05-01 18:25:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-01 18:25:55 --> Input Class Initialized
INFO - 2023-05-01 18:25:55 --> Language Class Initialized
INFO - 2023-05-01 18:25:55 --> Loader Class Initialized
INFO - 2023-05-01 18:25:55 --> Helper loaded: url_helper
INFO - 2023-05-01 18:25:55 --> Helper loaded: file_helper
INFO - 2023-05-01 18:25:55 --> Helper loaded: html_helper
INFO - 2023-05-01 18:25:55 --> Helper loaded: text_helper
INFO - 2023-05-01 18:25:55 --> Helper loaded: form_helper
INFO - 2023-05-01 18:25:55 --> Helper loaded: lang_helper
INFO - 2023-05-01 18:25:55 --> Helper loaded: security_helper
INFO - 2023-05-01 18:25:55 --> Helper loaded: cookie_helper
INFO - 2023-05-01 18:25:55 --> Database Driver Class Initialized
INFO - 2023-05-01 18:25:55 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-01 18:25:55 --> Parser Class Initialized
INFO - 2023-05-01 18:25:55 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-01 18:25:55 --> Pagination Class Initialized
INFO - 2023-05-01 18:25:55 --> Form Validation Class Initialized
INFO - 2023-05-01 18:25:55 --> Controller Class Initialized
INFO - 2023-05-01 18:25:55 --> Model Class Initialized
DEBUG - 2023-05-01 18:25:55 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-05-01 18:25:55 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-01 18:25:55 --> Model Class Initialized
DEBUG - 2023-05-01 18:25:55 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-01 18:25:55 --> Model Class Initialized
INFO - 2023-05-01 18:25:55 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/invoice/invoice_html.php
DEBUG - 2023-05-01 18:25:55 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-05-01 18:25:55 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-05-01 18:25:55 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-05-01 18:25:55 --> Model Class Initialized
INFO - 2023-05-01 18:25:55 --> Model Class Initialized
INFO - 2023-05-01 18:25:55 --> Model Class Initialized
INFO - 2023-05-01 18:25:55 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-05-01 18:25:55 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-05-01 18:25:55 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-05-01 18:25:55 --> Final output sent to browser
DEBUG - 2023-05-01 18:25:55 --> Total execution time: 0.1301
ERROR - 2023-05-01 18:26:16 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-01 18:26:16 --> Config Class Initialized
INFO - 2023-05-01 18:26:16 --> Hooks Class Initialized
DEBUG - 2023-05-01 18:26:16 --> UTF-8 Support Enabled
INFO - 2023-05-01 18:26:16 --> Utf8 Class Initialized
INFO - 2023-05-01 18:26:16 --> URI Class Initialized
INFO - 2023-05-01 18:26:16 --> Router Class Initialized
INFO - 2023-05-01 18:26:16 --> Output Class Initialized
INFO - 2023-05-01 18:26:16 --> Security Class Initialized
DEBUG - 2023-05-01 18:26:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-01 18:26:16 --> Input Class Initialized
INFO - 2023-05-01 18:26:16 --> Language Class Initialized
INFO - 2023-05-01 18:26:16 --> Loader Class Initialized
INFO - 2023-05-01 18:26:16 --> Helper loaded: url_helper
INFO - 2023-05-01 18:26:16 --> Helper loaded: file_helper
INFO - 2023-05-01 18:26:16 --> Helper loaded: html_helper
INFO - 2023-05-01 18:26:16 --> Helper loaded: text_helper
INFO - 2023-05-01 18:26:16 --> Helper loaded: form_helper
INFO - 2023-05-01 18:26:16 --> Helper loaded: lang_helper
INFO - 2023-05-01 18:26:16 --> Helper loaded: security_helper
INFO - 2023-05-01 18:26:16 --> Helper loaded: cookie_helper
INFO - 2023-05-01 18:26:16 --> Database Driver Class Initialized
INFO - 2023-05-01 18:26:16 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-01 18:26:16 --> Parser Class Initialized
INFO - 2023-05-01 18:26:16 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-01 18:26:16 --> Pagination Class Initialized
INFO - 2023-05-01 18:26:16 --> Form Validation Class Initialized
INFO - 2023-05-01 18:26:16 --> Controller Class Initialized
INFO - 2023-05-01 18:26:16 --> Model Class Initialized
DEBUG - 2023-05-01 18:26:16 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-01 18:26:16 --> Model Class Initialized
INFO - 2023-05-01 18:26:16 --> Model Class Initialized
ERROR - 2023-05-01 18:26:27 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-01 18:26:27 --> Config Class Initialized
INFO - 2023-05-01 18:26:27 --> Hooks Class Initialized
DEBUG - 2023-05-01 18:26:27 --> UTF-8 Support Enabled
INFO - 2023-05-01 18:26:27 --> Utf8 Class Initialized
INFO - 2023-05-01 18:26:27 --> URI Class Initialized
INFO - 2023-05-01 18:26:27 --> Router Class Initialized
INFO - 2023-05-01 18:26:27 --> Output Class Initialized
INFO - 2023-05-01 18:26:27 --> Security Class Initialized
DEBUG - 2023-05-01 18:26:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-01 18:26:27 --> Input Class Initialized
INFO - 2023-05-01 18:26:27 --> Language Class Initialized
INFO - 2023-05-01 18:26:27 --> Loader Class Initialized
INFO - 2023-05-01 18:26:27 --> Helper loaded: url_helper
INFO - 2023-05-01 18:26:27 --> Helper loaded: file_helper
INFO - 2023-05-01 18:26:27 --> Helper loaded: html_helper
INFO - 2023-05-01 18:26:27 --> Helper loaded: text_helper
INFO - 2023-05-01 18:26:27 --> Helper loaded: form_helper
INFO - 2023-05-01 18:26:27 --> Helper loaded: lang_helper
INFO - 2023-05-01 18:26:27 --> Helper loaded: security_helper
INFO - 2023-05-01 18:26:27 --> Helper loaded: cookie_helper
INFO - 2023-05-01 18:26:27 --> Database Driver Class Initialized
INFO - 2023-05-01 18:26:27 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-01 18:26:27 --> Parser Class Initialized
INFO - 2023-05-01 18:26:27 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-01 18:26:27 --> Pagination Class Initialized
INFO - 2023-05-01 18:26:27 --> Form Validation Class Initialized
INFO - 2023-05-01 18:26:27 --> Controller Class Initialized
INFO - 2023-05-01 18:26:27 --> Model Class Initialized
DEBUG - 2023-05-01 18:26:27 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-01 18:26:27 --> Model Class Initialized
INFO - 2023-05-01 18:26:27 --> Model Class Initialized
ERROR - 2023-05-01 18:26:50 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-01 18:26:50 --> Config Class Initialized
INFO - 2023-05-01 18:26:50 --> Hooks Class Initialized
DEBUG - 2023-05-01 18:26:50 --> UTF-8 Support Enabled
INFO - 2023-05-01 18:26:50 --> Utf8 Class Initialized
INFO - 2023-05-01 18:26:50 --> URI Class Initialized
INFO - 2023-05-01 18:26:50 --> Router Class Initialized
INFO - 2023-05-01 18:26:50 --> Output Class Initialized
INFO - 2023-05-01 18:26:50 --> Security Class Initialized
DEBUG - 2023-05-01 18:26:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-01 18:26:50 --> Input Class Initialized
INFO - 2023-05-01 18:26:50 --> Language Class Initialized
INFO - 2023-05-01 18:26:50 --> Loader Class Initialized
INFO - 2023-05-01 18:26:50 --> Helper loaded: url_helper
INFO - 2023-05-01 18:26:50 --> Helper loaded: file_helper
INFO - 2023-05-01 18:26:50 --> Helper loaded: html_helper
INFO - 2023-05-01 18:26:50 --> Helper loaded: text_helper
INFO - 2023-05-01 18:26:50 --> Helper loaded: form_helper
INFO - 2023-05-01 18:26:50 --> Helper loaded: lang_helper
INFO - 2023-05-01 18:26:50 --> Helper loaded: security_helper
INFO - 2023-05-01 18:26:50 --> Helper loaded: cookie_helper
INFO - 2023-05-01 18:26:50 --> Database Driver Class Initialized
INFO - 2023-05-01 18:26:50 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-01 18:26:50 --> Parser Class Initialized
INFO - 2023-05-01 18:26:50 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-01 18:26:50 --> Pagination Class Initialized
INFO - 2023-05-01 18:26:50 --> Form Validation Class Initialized
INFO - 2023-05-01 18:26:50 --> Controller Class Initialized
INFO - 2023-05-01 18:26:50 --> Model Class Initialized
DEBUG - 2023-05-01 18:26:50 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-01 18:26:50 --> Model Class Initialized
INFO - 2023-05-01 18:26:50 --> Model Class Initialized
ERROR - 2023-05-01 18:27:13 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-01 18:27:13 --> Config Class Initialized
INFO - 2023-05-01 18:27:13 --> Hooks Class Initialized
DEBUG - 2023-05-01 18:27:13 --> UTF-8 Support Enabled
INFO - 2023-05-01 18:27:13 --> Utf8 Class Initialized
INFO - 2023-05-01 18:27:13 --> URI Class Initialized
INFO - 2023-05-01 18:27:13 --> Router Class Initialized
INFO - 2023-05-01 18:27:13 --> Output Class Initialized
INFO - 2023-05-01 18:27:13 --> Security Class Initialized
DEBUG - 2023-05-01 18:27:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-01 18:27:13 --> Input Class Initialized
INFO - 2023-05-01 18:27:13 --> Language Class Initialized
INFO - 2023-05-01 18:27:13 --> Loader Class Initialized
INFO - 2023-05-01 18:27:13 --> Helper loaded: url_helper
INFO - 2023-05-01 18:27:13 --> Helper loaded: file_helper
INFO - 2023-05-01 18:27:13 --> Helper loaded: html_helper
INFO - 2023-05-01 18:27:13 --> Helper loaded: text_helper
INFO - 2023-05-01 18:27:13 --> Helper loaded: form_helper
INFO - 2023-05-01 18:27:13 --> Helper loaded: lang_helper
INFO - 2023-05-01 18:27:13 --> Helper loaded: security_helper
INFO - 2023-05-01 18:27:13 --> Helper loaded: cookie_helper
INFO - 2023-05-01 18:27:13 --> Database Driver Class Initialized
INFO - 2023-05-01 18:27:13 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-01 18:27:13 --> Parser Class Initialized
INFO - 2023-05-01 18:27:13 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-01 18:27:13 --> Pagination Class Initialized
INFO - 2023-05-01 18:27:13 --> Form Validation Class Initialized
INFO - 2023-05-01 18:27:13 --> Controller Class Initialized
INFO - 2023-05-01 18:27:13 --> Model Class Initialized
DEBUG - 2023-05-01 18:27:13 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-01 18:27:13 --> Model Class Initialized
INFO - 2023-05-01 18:27:13 --> Model Class Initialized
ERROR - 2023-05-01 18:27:48 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-01 18:27:48 --> Config Class Initialized
INFO - 2023-05-01 18:27:48 --> Hooks Class Initialized
DEBUG - 2023-05-01 18:27:48 --> UTF-8 Support Enabled
INFO - 2023-05-01 18:27:48 --> Utf8 Class Initialized
INFO - 2023-05-01 18:27:48 --> URI Class Initialized
INFO - 2023-05-01 18:27:48 --> Router Class Initialized
INFO - 2023-05-01 18:27:48 --> Output Class Initialized
INFO - 2023-05-01 18:27:48 --> Security Class Initialized
DEBUG - 2023-05-01 18:27:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-01 18:27:48 --> Input Class Initialized
INFO - 2023-05-01 18:27:48 --> Language Class Initialized
INFO - 2023-05-01 18:27:48 --> Loader Class Initialized
INFO - 2023-05-01 18:27:48 --> Helper loaded: url_helper
INFO - 2023-05-01 18:27:48 --> Helper loaded: file_helper
INFO - 2023-05-01 18:27:48 --> Helper loaded: html_helper
INFO - 2023-05-01 18:27:48 --> Helper loaded: text_helper
INFO - 2023-05-01 18:27:48 --> Helper loaded: form_helper
INFO - 2023-05-01 18:27:48 --> Helper loaded: lang_helper
INFO - 2023-05-01 18:27:48 --> Helper loaded: security_helper
INFO - 2023-05-01 18:27:48 --> Helper loaded: cookie_helper
INFO - 2023-05-01 18:27:48 --> Database Driver Class Initialized
INFO - 2023-05-01 18:27:48 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-01 18:27:48 --> Parser Class Initialized
INFO - 2023-05-01 18:27:48 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-01 18:27:48 --> Pagination Class Initialized
INFO - 2023-05-01 18:27:48 --> Form Validation Class Initialized
INFO - 2023-05-01 18:27:48 --> Controller Class Initialized
INFO - 2023-05-01 18:27:48 --> Model Class Initialized
DEBUG - 2023-05-01 18:27:48 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-01 18:27:48 --> Model Class Initialized
INFO - 2023-05-01 18:27:48 --> Model Class Initialized
ERROR - 2023-05-01 18:28:11 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-01 18:28:11 --> Config Class Initialized
INFO - 2023-05-01 18:28:11 --> Hooks Class Initialized
DEBUG - 2023-05-01 18:28:11 --> UTF-8 Support Enabled
INFO - 2023-05-01 18:28:11 --> Utf8 Class Initialized
INFO - 2023-05-01 18:28:11 --> URI Class Initialized
INFO - 2023-05-01 18:28:11 --> Router Class Initialized
INFO - 2023-05-01 18:28:11 --> Output Class Initialized
INFO - 2023-05-01 18:28:11 --> Security Class Initialized
DEBUG - 2023-05-01 18:28:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-01 18:28:11 --> Input Class Initialized
INFO - 2023-05-01 18:28:11 --> Language Class Initialized
INFO - 2023-05-01 18:28:11 --> Loader Class Initialized
INFO - 2023-05-01 18:28:11 --> Helper loaded: url_helper
INFO - 2023-05-01 18:28:11 --> Helper loaded: file_helper
INFO - 2023-05-01 18:28:11 --> Helper loaded: html_helper
INFO - 2023-05-01 18:28:11 --> Helper loaded: text_helper
INFO - 2023-05-01 18:28:11 --> Helper loaded: form_helper
INFO - 2023-05-01 18:28:11 --> Helper loaded: lang_helper
INFO - 2023-05-01 18:28:11 --> Helper loaded: security_helper
INFO - 2023-05-01 18:28:11 --> Helper loaded: cookie_helper
INFO - 2023-05-01 18:28:11 --> Database Driver Class Initialized
INFO - 2023-05-01 18:28:11 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-01 18:28:11 --> Parser Class Initialized
INFO - 2023-05-01 18:28:11 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-01 18:28:11 --> Pagination Class Initialized
INFO - 2023-05-01 18:28:11 --> Form Validation Class Initialized
INFO - 2023-05-01 18:28:11 --> Controller Class Initialized
INFO - 2023-05-01 18:28:11 --> Model Class Initialized
DEBUG - 2023-05-01 18:28:11 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-01 18:28:11 --> Model Class Initialized
INFO - 2023-05-01 18:28:11 --> Model Class Initialized
ERROR - 2023-05-01 18:28:23 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-01 18:28:23 --> Config Class Initialized
INFO - 2023-05-01 18:28:23 --> Hooks Class Initialized
DEBUG - 2023-05-01 18:28:23 --> UTF-8 Support Enabled
INFO - 2023-05-01 18:28:23 --> Utf8 Class Initialized
INFO - 2023-05-01 18:28:23 --> URI Class Initialized
DEBUG - 2023-05-01 18:28:23 --> No URI present. Default controller set.
INFO - 2023-05-01 18:28:23 --> Router Class Initialized
INFO - 2023-05-01 18:28:23 --> Output Class Initialized
INFO - 2023-05-01 18:28:23 --> Security Class Initialized
DEBUG - 2023-05-01 18:28:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-01 18:28:23 --> Input Class Initialized
INFO - 2023-05-01 18:28:23 --> Language Class Initialized
INFO - 2023-05-01 18:28:23 --> Loader Class Initialized
INFO - 2023-05-01 18:28:23 --> Helper loaded: url_helper
INFO - 2023-05-01 18:28:23 --> Helper loaded: file_helper
INFO - 2023-05-01 18:28:23 --> Helper loaded: html_helper
INFO - 2023-05-01 18:28:23 --> Helper loaded: text_helper
INFO - 2023-05-01 18:28:23 --> Helper loaded: form_helper
INFO - 2023-05-01 18:28:23 --> Helper loaded: lang_helper
INFO - 2023-05-01 18:28:23 --> Helper loaded: security_helper
INFO - 2023-05-01 18:28:23 --> Helper loaded: cookie_helper
INFO - 2023-05-01 18:28:23 --> Database Driver Class Initialized
INFO - 2023-05-01 18:28:23 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-01 18:28:23 --> Parser Class Initialized
INFO - 2023-05-01 18:28:23 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-01 18:28:23 --> Pagination Class Initialized
INFO - 2023-05-01 18:28:23 --> Form Validation Class Initialized
INFO - 2023-05-01 18:28:23 --> Controller Class Initialized
INFO - 2023-05-01 18:28:23 --> Model Class Initialized
DEBUG - 2023-05-01 18:28:23 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-01 18:28:23 --> Model Class Initialized
DEBUG - 2023-05-01 18:28:23 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-01 18:28:23 --> Model Class Initialized
INFO - 2023-05-01 18:28:23 --> Model Class Initialized
INFO - 2023-05-01 18:28:23 --> Model Class Initialized
INFO - 2023-05-01 18:28:23 --> Model Class Initialized
DEBUG - 2023-05-01 18:28:23 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-05-01 18:28:23 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-01 18:28:23 --> Model Class Initialized
INFO - 2023-05-01 18:28:23 --> Model Class Initialized
INFO - 2023-05-01 18:28:23 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-05-01 18:28:23 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-05-01 18:28:23 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-05-01 18:28:23 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-05-01 18:28:23 --> Model Class Initialized
INFO - 2023-05-01 18:28:24 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-05-01 18:28:24 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-05-01 18:28:24 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-05-01 18:28:24 --> Final output sent to browser
DEBUG - 2023-05-01 18:28:24 --> Total execution time: 0.1563
ERROR - 2023-05-01 18:28:40 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-01 18:28:40 --> Config Class Initialized
INFO - 2023-05-01 18:28:40 --> Hooks Class Initialized
DEBUG - 2023-05-01 18:28:40 --> UTF-8 Support Enabled
INFO - 2023-05-01 18:28:40 --> Utf8 Class Initialized
INFO - 2023-05-01 18:28:40 --> URI Class Initialized
INFO - 2023-05-01 18:28:40 --> Router Class Initialized
INFO - 2023-05-01 18:28:40 --> Output Class Initialized
INFO - 2023-05-01 18:28:40 --> Security Class Initialized
DEBUG - 2023-05-01 18:28:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-01 18:28:40 --> Input Class Initialized
INFO - 2023-05-01 18:28:40 --> Language Class Initialized
INFO - 2023-05-01 18:28:40 --> Loader Class Initialized
INFO - 2023-05-01 18:28:40 --> Helper loaded: url_helper
INFO - 2023-05-01 18:28:40 --> Helper loaded: file_helper
INFO - 2023-05-01 18:28:40 --> Helper loaded: html_helper
INFO - 2023-05-01 18:28:40 --> Helper loaded: text_helper
INFO - 2023-05-01 18:28:40 --> Helper loaded: form_helper
INFO - 2023-05-01 18:28:40 --> Helper loaded: lang_helper
INFO - 2023-05-01 18:28:40 --> Helper loaded: security_helper
INFO - 2023-05-01 18:28:40 --> Helper loaded: cookie_helper
INFO - 2023-05-01 18:28:40 --> Database Driver Class Initialized
INFO - 2023-05-01 18:28:40 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-01 18:28:40 --> Parser Class Initialized
INFO - 2023-05-01 18:28:40 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-01 18:28:40 --> Pagination Class Initialized
INFO - 2023-05-01 18:28:40 --> Form Validation Class Initialized
INFO - 2023-05-01 18:28:40 --> Controller Class Initialized
INFO - 2023-05-01 18:28:40 --> Model Class Initialized
DEBUG - 2023-05-01 18:28:40 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-05-01 18:28:40 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-01 18:28:40 --> Model Class Initialized
INFO - 2023-05-01 18:28:40 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/demandrequest/demandrequest.php
DEBUG - 2023-05-01 18:28:40 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-05-01 18:28:40 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-05-01 18:28:40 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-05-01 18:28:40 --> Model Class Initialized
INFO - 2023-05-01 18:28:40 --> Model Class Initialized
INFO - 2023-05-01 18:28:40 --> Model Class Initialized
INFO - 2023-05-01 18:28:40 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-05-01 18:28:40 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-05-01 18:28:40 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-05-01 18:28:40 --> Final output sent to browser
DEBUG - 2023-05-01 18:28:40 --> Total execution time: 0.1237
ERROR - 2023-05-01 18:28:40 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-01 18:28:40 --> Config Class Initialized
INFO - 2023-05-01 18:28:40 --> Hooks Class Initialized
DEBUG - 2023-05-01 18:28:40 --> UTF-8 Support Enabled
INFO - 2023-05-01 18:28:40 --> Utf8 Class Initialized
INFO - 2023-05-01 18:28:40 --> URI Class Initialized
INFO - 2023-05-01 18:28:40 --> Router Class Initialized
INFO - 2023-05-01 18:28:40 --> Output Class Initialized
INFO - 2023-05-01 18:28:40 --> Security Class Initialized
DEBUG - 2023-05-01 18:28:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-01 18:28:40 --> Input Class Initialized
INFO - 2023-05-01 18:28:40 --> Language Class Initialized
INFO - 2023-05-01 18:28:40 --> Loader Class Initialized
INFO - 2023-05-01 18:28:40 --> Helper loaded: url_helper
INFO - 2023-05-01 18:28:40 --> Helper loaded: file_helper
INFO - 2023-05-01 18:28:40 --> Helper loaded: html_helper
INFO - 2023-05-01 18:28:40 --> Helper loaded: text_helper
INFO - 2023-05-01 18:28:40 --> Helper loaded: form_helper
INFO - 2023-05-01 18:28:40 --> Helper loaded: lang_helper
INFO - 2023-05-01 18:28:40 --> Helper loaded: security_helper
INFO - 2023-05-01 18:28:40 --> Helper loaded: cookie_helper
INFO - 2023-05-01 18:28:40 --> Database Driver Class Initialized
INFO - 2023-05-01 18:28:40 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-01 18:28:40 --> Parser Class Initialized
INFO - 2023-05-01 18:28:40 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-01 18:28:40 --> Pagination Class Initialized
INFO - 2023-05-01 18:28:40 --> Form Validation Class Initialized
INFO - 2023-05-01 18:28:40 --> Controller Class Initialized
INFO - 2023-05-01 18:28:40 --> Model Class Initialized
DEBUG - 2023-05-01 18:28:40 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-05-01 18:28:40 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-01 18:28:40 --> Model Class Initialized
INFO - 2023-05-01 18:28:40 --> Final output sent to browser
DEBUG - 2023-05-01 18:28:40 --> Total execution time: 0.0183
ERROR - 2023-05-01 18:28:44 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-01 18:28:44 --> Config Class Initialized
INFO - 2023-05-01 18:28:44 --> Hooks Class Initialized
DEBUG - 2023-05-01 18:28:44 --> UTF-8 Support Enabled
INFO - 2023-05-01 18:28:44 --> Utf8 Class Initialized
INFO - 2023-05-01 18:28:44 --> URI Class Initialized
INFO - 2023-05-01 18:28:44 --> Router Class Initialized
INFO - 2023-05-01 18:28:44 --> Output Class Initialized
INFO - 2023-05-01 18:28:44 --> Security Class Initialized
DEBUG - 2023-05-01 18:28:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-01 18:28:44 --> Input Class Initialized
INFO - 2023-05-01 18:28:44 --> Language Class Initialized
INFO - 2023-05-01 18:28:44 --> Loader Class Initialized
INFO - 2023-05-01 18:28:44 --> Helper loaded: url_helper
INFO - 2023-05-01 18:28:44 --> Helper loaded: file_helper
INFO - 2023-05-01 18:28:44 --> Helper loaded: html_helper
INFO - 2023-05-01 18:28:44 --> Helper loaded: text_helper
INFO - 2023-05-01 18:28:44 --> Helper loaded: form_helper
INFO - 2023-05-01 18:28:44 --> Helper loaded: lang_helper
INFO - 2023-05-01 18:28:44 --> Helper loaded: security_helper
INFO - 2023-05-01 18:28:44 --> Helper loaded: cookie_helper
INFO - 2023-05-01 18:28:44 --> Database Driver Class Initialized
INFO - 2023-05-01 18:28:44 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-01 18:28:44 --> Parser Class Initialized
INFO - 2023-05-01 18:28:44 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-01 18:28:44 --> Pagination Class Initialized
INFO - 2023-05-01 18:28:44 --> Form Validation Class Initialized
INFO - 2023-05-01 18:28:44 --> Controller Class Initialized
INFO - 2023-05-01 18:28:44 --> Model Class Initialized
DEBUG - 2023-05-01 18:28:44 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-05-01 18:28:44 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-01 18:28:44 --> Model Class Initialized
DEBUG - 2023-05-01 18:28:44 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-01 18:28:44 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/demandrequest/demandrequest_html.php
DEBUG - 2023-05-01 18:28:44 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-05-01 18:28:44 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-05-01 18:28:44 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-05-01 18:28:44 --> Model Class Initialized
INFO - 2023-05-01 18:28:44 --> Model Class Initialized
INFO - 2023-05-01 18:28:44 --> Model Class Initialized
INFO - 2023-05-01 18:28:44 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-05-01 18:28:44 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-05-01 18:28:44 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-05-01 18:28:44 --> Final output sent to browser
DEBUG - 2023-05-01 18:28:44 --> Total execution time: 0.1370
ERROR - 2023-05-01 18:29:04 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-01 18:29:04 --> Config Class Initialized
INFO - 2023-05-01 18:29:04 --> Hooks Class Initialized
DEBUG - 2023-05-01 18:29:04 --> UTF-8 Support Enabled
INFO - 2023-05-01 18:29:04 --> Utf8 Class Initialized
INFO - 2023-05-01 18:29:04 --> URI Class Initialized
INFO - 2023-05-01 18:29:04 --> Router Class Initialized
INFO - 2023-05-01 18:29:04 --> Output Class Initialized
INFO - 2023-05-01 18:29:04 --> Security Class Initialized
DEBUG - 2023-05-01 18:29:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-01 18:29:04 --> Input Class Initialized
INFO - 2023-05-01 18:29:04 --> Language Class Initialized
INFO - 2023-05-01 18:29:04 --> Loader Class Initialized
INFO - 2023-05-01 18:29:04 --> Helper loaded: url_helper
INFO - 2023-05-01 18:29:04 --> Helper loaded: file_helper
INFO - 2023-05-01 18:29:04 --> Helper loaded: html_helper
INFO - 2023-05-01 18:29:04 --> Helper loaded: text_helper
INFO - 2023-05-01 18:29:04 --> Helper loaded: form_helper
INFO - 2023-05-01 18:29:04 --> Helper loaded: lang_helper
INFO - 2023-05-01 18:29:04 --> Helper loaded: security_helper
INFO - 2023-05-01 18:29:04 --> Helper loaded: cookie_helper
INFO - 2023-05-01 18:29:04 --> Database Driver Class Initialized
INFO - 2023-05-01 18:29:04 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-01 18:29:04 --> Parser Class Initialized
INFO - 2023-05-01 18:29:04 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-01 18:29:04 --> Pagination Class Initialized
INFO - 2023-05-01 18:29:04 --> Form Validation Class Initialized
INFO - 2023-05-01 18:29:04 --> Controller Class Initialized
INFO - 2023-05-01 18:29:04 --> Model Class Initialized
DEBUG - 2023-05-01 18:29:04 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-05-01 18:29:04 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-01 18:29:04 --> Model Class Initialized
INFO - 2023-05-01 18:29:04 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/demandrequest/customer_demandrequest.php
DEBUG - 2023-05-01 18:29:04 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-05-01 18:29:04 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-05-01 18:29:04 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-05-01 18:29:04 --> Model Class Initialized
INFO - 2023-05-01 18:29:04 --> Model Class Initialized
INFO - 2023-05-01 18:29:04 --> Model Class Initialized
INFO - 2023-05-01 18:29:05 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-05-01 18:29:05 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-05-01 18:29:05 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-05-01 18:29:05 --> Final output sent to browser
DEBUG - 2023-05-01 18:29:05 --> Total execution time: 0.1246
ERROR - 2023-05-01 18:29:05 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-01 18:29:05 --> Config Class Initialized
INFO - 2023-05-01 18:29:05 --> Hooks Class Initialized
DEBUG - 2023-05-01 18:29:05 --> UTF-8 Support Enabled
INFO - 2023-05-01 18:29:05 --> Utf8 Class Initialized
INFO - 2023-05-01 18:29:05 --> URI Class Initialized
INFO - 2023-05-01 18:29:05 --> Router Class Initialized
INFO - 2023-05-01 18:29:05 --> Output Class Initialized
INFO - 2023-05-01 18:29:05 --> Security Class Initialized
DEBUG - 2023-05-01 18:29:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-01 18:29:05 --> Input Class Initialized
INFO - 2023-05-01 18:29:05 --> Language Class Initialized
INFO - 2023-05-01 18:29:05 --> Loader Class Initialized
INFO - 2023-05-01 18:29:05 --> Helper loaded: url_helper
INFO - 2023-05-01 18:29:05 --> Helper loaded: file_helper
INFO - 2023-05-01 18:29:05 --> Helper loaded: html_helper
INFO - 2023-05-01 18:29:05 --> Helper loaded: text_helper
INFO - 2023-05-01 18:29:05 --> Helper loaded: form_helper
INFO - 2023-05-01 18:29:05 --> Helper loaded: lang_helper
INFO - 2023-05-01 18:29:05 --> Helper loaded: security_helper
INFO - 2023-05-01 18:29:05 --> Helper loaded: cookie_helper
INFO - 2023-05-01 18:29:05 --> Database Driver Class Initialized
INFO - 2023-05-01 18:29:05 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-01 18:29:05 --> Parser Class Initialized
INFO - 2023-05-01 18:29:05 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-01 18:29:05 --> Pagination Class Initialized
INFO - 2023-05-01 18:29:05 --> Form Validation Class Initialized
INFO - 2023-05-01 18:29:05 --> Controller Class Initialized
INFO - 2023-05-01 18:29:05 --> Model Class Initialized
DEBUG - 2023-05-01 18:29:05 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-05-01 18:29:05 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-01 18:29:05 --> Model Class Initialized
INFO - 2023-05-01 18:29:05 --> Final output sent to browser
DEBUG - 2023-05-01 18:29:05 --> Total execution time: 0.0273
ERROR - 2023-05-01 18:29:11 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-01 18:29:11 --> Config Class Initialized
INFO - 2023-05-01 18:29:11 --> Hooks Class Initialized
DEBUG - 2023-05-01 18:29:11 --> UTF-8 Support Enabled
INFO - 2023-05-01 18:29:11 --> Utf8 Class Initialized
INFO - 2023-05-01 18:29:11 --> URI Class Initialized
INFO - 2023-05-01 18:29:11 --> Router Class Initialized
INFO - 2023-05-01 18:29:11 --> Output Class Initialized
INFO - 2023-05-01 18:29:11 --> Security Class Initialized
DEBUG - 2023-05-01 18:29:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-01 18:29:11 --> Input Class Initialized
INFO - 2023-05-01 18:29:11 --> Language Class Initialized
INFO - 2023-05-01 18:29:11 --> Loader Class Initialized
INFO - 2023-05-01 18:29:11 --> Helper loaded: url_helper
INFO - 2023-05-01 18:29:11 --> Helper loaded: file_helper
INFO - 2023-05-01 18:29:11 --> Helper loaded: html_helper
INFO - 2023-05-01 18:29:11 --> Helper loaded: text_helper
INFO - 2023-05-01 18:29:11 --> Helper loaded: form_helper
INFO - 2023-05-01 18:29:11 --> Helper loaded: lang_helper
INFO - 2023-05-01 18:29:11 --> Helper loaded: security_helper
INFO - 2023-05-01 18:29:11 --> Helper loaded: cookie_helper
INFO - 2023-05-01 18:29:11 --> Database Driver Class Initialized
INFO - 2023-05-01 18:29:11 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-01 18:29:11 --> Parser Class Initialized
INFO - 2023-05-01 18:29:11 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-01 18:29:11 --> Pagination Class Initialized
INFO - 2023-05-01 18:29:11 --> Form Validation Class Initialized
INFO - 2023-05-01 18:29:11 --> Controller Class Initialized
INFO - 2023-05-01 18:29:11 --> Model Class Initialized
DEBUG - 2023-05-01 18:29:11 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-05-01 18:29:11 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-01 18:29:11 --> Model Class Initialized
DEBUG - 2023-05-01 18:29:11 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-01 18:29:11 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/demandrequest/demandrequest_html.php
DEBUG - 2023-05-01 18:29:11 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-05-01 18:29:11 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-05-01 18:29:11 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-05-01 18:29:11 --> Model Class Initialized
INFO - 2023-05-01 18:29:11 --> Model Class Initialized
INFO - 2023-05-01 18:29:11 --> Model Class Initialized
INFO - 2023-05-01 18:29:11 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-05-01 18:29:11 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-05-01 18:29:11 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-05-01 18:29:11 --> Final output sent to browser
DEBUG - 2023-05-01 18:29:11 --> Total execution time: 0.1214
ERROR - 2023-05-01 18:29:27 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-01 18:29:27 --> Config Class Initialized
INFO - 2023-05-01 18:29:27 --> Hooks Class Initialized
DEBUG - 2023-05-01 18:29:27 --> UTF-8 Support Enabled
INFO - 2023-05-01 18:29:27 --> Utf8 Class Initialized
INFO - 2023-05-01 18:29:27 --> URI Class Initialized
INFO - 2023-05-01 18:29:27 --> Router Class Initialized
INFO - 2023-05-01 18:29:27 --> Output Class Initialized
INFO - 2023-05-01 18:29:27 --> Security Class Initialized
DEBUG - 2023-05-01 18:29:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-01 18:29:27 --> Input Class Initialized
INFO - 2023-05-01 18:29:27 --> Language Class Initialized
INFO - 2023-05-01 18:29:27 --> Loader Class Initialized
INFO - 2023-05-01 18:29:27 --> Helper loaded: url_helper
INFO - 2023-05-01 18:29:27 --> Helper loaded: file_helper
INFO - 2023-05-01 18:29:27 --> Helper loaded: html_helper
INFO - 2023-05-01 18:29:27 --> Helper loaded: text_helper
INFO - 2023-05-01 18:29:27 --> Helper loaded: form_helper
INFO - 2023-05-01 18:29:27 --> Helper loaded: lang_helper
INFO - 2023-05-01 18:29:27 --> Helper loaded: security_helper
INFO - 2023-05-01 18:29:27 --> Helper loaded: cookie_helper
INFO - 2023-05-01 18:29:27 --> Database Driver Class Initialized
INFO - 2023-05-01 18:29:27 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-01 18:29:27 --> Parser Class Initialized
INFO - 2023-05-01 18:29:27 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-01 18:29:27 --> Pagination Class Initialized
INFO - 2023-05-01 18:29:27 --> Form Validation Class Initialized
INFO - 2023-05-01 18:29:27 --> Controller Class Initialized
INFO - 2023-05-01 18:29:27 --> Model Class Initialized
DEBUG - 2023-05-01 18:29:27 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-05-01 18:29:27 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-01 18:29:27 --> Model Class Initialized
INFO - 2023-05-01 18:29:27 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/demandrequest/customer_demandrequest.php
DEBUG - 2023-05-01 18:29:27 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-05-01 18:29:27 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-05-01 18:29:27 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-05-01 18:29:27 --> Model Class Initialized
INFO - 2023-05-01 18:29:27 --> Model Class Initialized
INFO - 2023-05-01 18:29:27 --> Model Class Initialized
INFO - 2023-05-01 18:29:27 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-05-01 18:29:27 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-05-01 18:29:27 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-05-01 18:29:27 --> Final output sent to browser
DEBUG - 2023-05-01 18:29:27 --> Total execution time: 0.1258
ERROR - 2023-05-01 18:29:28 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-01 18:29:28 --> Config Class Initialized
INFO - 2023-05-01 18:29:28 --> Hooks Class Initialized
DEBUG - 2023-05-01 18:29:28 --> UTF-8 Support Enabled
INFO - 2023-05-01 18:29:28 --> Utf8 Class Initialized
INFO - 2023-05-01 18:29:28 --> URI Class Initialized
INFO - 2023-05-01 18:29:28 --> Router Class Initialized
INFO - 2023-05-01 18:29:28 --> Output Class Initialized
INFO - 2023-05-01 18:29:28 --> Security Class Initialized
DEBUG - 2023-05-01 18:29:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-01 18:29:28 --> Input Class Initialized
INFO - 2023-05-01 18:29:28 --> Language Class Initialized
INFO - 2023-05-01 18:29:28 --> Loader Class Initialized
INFO - 2023-05-01 18:29:28 --> Helper loaded: url_helper
INFO - 2023-05-01 18:29:28 --> Helper loaded: file_helper
INFO - 2023-05-01 18:29:28 --> Helper loaded: html_helper
INFO - 2023-05-01 18:29:28 --> Helper loaded: text_helper
INFO - 2023-05-01 18:29:28 --> Helper loaded: form_helper
INFO - 2023-05-01 18:29:28 --> Helper loaded: lang_helper
INFO - 2023-05-01 18:29:28 --> Helper loaded: security_helper
INFO - 2023-05-01 18:29:28 --> Helper loaded: cookie_helper
INFO - 2023-05-01 18:29:28 --> Database Driver Class Initialized
INFO - 2023-05-01 18:29:28 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-01 18:29:28 --> Parser Class Initialized
INFO - 2023-05-01 18:29:28 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-01 18:29:28 --> Pagination Class Initialized
INFO - 2023-05-01 18:29:28 --> Form Validation Class Initialized
INFO - 2023-05-01 18:29:28 --> Controller Class Initialized
INFO - 2023-05-01 18:29:28 --> Model Class Initialized
DEBUG - 2023-05-01 18:29:28 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-05-01 18:29:28 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-01 18:29:28 --> Model Class Initialized
INFO - 2023-05-01 18:29:28 --> Final output sent to browser
DEBUG - 2023-05-01 18:29:28 --> Total execution time: 0.0296
