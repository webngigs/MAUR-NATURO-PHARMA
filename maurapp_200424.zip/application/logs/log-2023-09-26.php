<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2023-09-26 00:35:41 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-26 00:35:41 --> Config Class Initialized
INFO - 2023-09-26 00:35:41 --> Hooks Class Initialized
DEBUG - 2023-09-26 00:35:41 --> UTF-8 Support Enabled
INFO - 2023-09-26 00:35:41 --> Utf8 Class Initialized
INFO - 2023-09-26 00:35:41 --> URI Class Initialized
DEBUG - 2023-09-26 00:35:41 --> No URI present. Default controller set.
INFO - 2023-09-26 00:35:41 --> Router Class Initialized
INFO - 2023-09-26 00:35:41 --> Output Class Initialized
INFO - 2023-09-26 00:35:41 --> Security Class Initialized
DEBUG - 2023-09-26 00:35:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-26 00:35:41 --> Input Class Initialized
INFO - 2023-09-26 00:35:41 --> Language Class Initialized
INFO - 2023-09-26 00:35:41 --> Loader Class Initialized
INFO - 2023-09-26 00:35:41 --> Helper loaded: url_helper
INFO - 2023-09-26 00:35:41 --> Helper loaded: file_helper
INFO - 2023-09-26 00:35:41 --> Helper loaded: html_helper
INFO - 2023-09-26 00:35:41 --> Helper loaded: text_helper
INFO - 2023-09-26 00:35:41 --> Helper loaded: form_helper
INFO - 2023-09-26 00:35:41 --> Helper loaded: lang_helper
INFO - 2023-09-26 00:35:41 --> Helper loaded: security_helper
INFO - 2023-09-26 00:35:41 --> Helper loaded: cookie_helper
INFO - 2023-09-26 00:35:41 --> Database Driver Class Initialized
INFO - 2023-09-26 00:35:41 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-26 00:35:41 --> Parser Class Initialized
INFO - 2023-09-26 00:35:41 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-26 00:35:41 --> Pagination Class Initialized
INFO - 2023-09-26 00:35:41 --> Form Validation Class Initialized
INFO - 2023-09-26 00:35:41 --> Controller Class Initialized
INFO - 2023-09-26 00:35:41 --> Model Class Initialized
DEBUG - 2023-09-26 00:35:41 --> Session class already loaded. Second attempt ignored.
ERROR - 2023-09-26 00:35:41 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-26 00:35:41 --> Config Class Initialized
INFO - 2023-09-26 00:35:41 --> Hooks Class Initialized
DEBUG - 2023-09-26 00:35:41 --> UTF-8 Support Enabled
INFO - 2023-09-26 00:35:41 --> Utf8 Class Initialized
INFO - 2023-09-26 00:35:41 --> URI Class Initialized
INFO - 2023-09-26 00:35:41 --> Router Class Initialized
INFO - 2023-09-26 00:35:41 --> Output Class Initialized
INFO - 2023-09-26 00:35:41 --> Security Class Initialized
DEBUG - 2023-09-26 00:35:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-26 00:35:41 --> Input Class Initialized
INFO - 2023-09-26 00:35:41 --> Language Class Initialized
INFO - 2023-09-26 00:35:41 --> Loader Class Initialized
INFO - 2023-09-26 00:35:41 --> Helper loaded: url_helper
INFO - 2023-09-26 00:35:41 --> Helper loaded: file_helper
INFO - 2023-09-26 00:35:41 --> Helper loaded: html_helper
INFO - 2023-09-26 00:35:41 --> Helper loaded: text_helper
INFO - 2023-09-26 00:35:41 --> Helper loaded: form_helper
INFO - 2023-09-26 00:35:41 --> Helper loaded: lang_helper
INFO - 2023-09-26 00:35:41 --> Helper loaded: security_helper
INFO - 2023-09-26 00:35:41 --> Helper loaded: cookie_helper
INFO - 2023-09-26 00:35:41 --> Database Driver Class Initialized
INFO - 2023-09-26 00:35:41 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-26 00:35:41 --> Parser Class Initialized
INFO - 2023-09-26 00:35:41 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-26 00:35:41 --> Pagination Class Initialized
INFO - 2023-09-26 00:35:41 --> Form Validation Class Initialized
INFO - 2023-09-26 00:35:41 --> Controller Class Initialized
INFO - 2023-09-26 00:35:41 --> Model Class Initialized
DEBUG - 2023-09-26 00:35:41 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-26 00:35:41 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2023-09-26 00:35:41 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-09-26 00:35:41 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-09-26 00:35:41 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-09-26 00:35:41 --> Model Class Initialized
INFO - 2023-09-26 00:35:41 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-09-26 00:35:41 --> Final output sent to browser
DEBUG - 2023-09-26 00:35:41 --> Total execution time: 0.0340
ERROR - 2023-09-26 03:57:39 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-26 03:57:39 --> Config Class Initialized
INFO - 2023-09-26 03:57:39 --> Hooks Class Initialized
DEBUG - 2023-09-26 03:57:39 --> UTF-8 Support Enabled
INFO - 2023-09-26 03:57:39 --> Utf8 Class Initialized
INFO - 2023-09-26 03:57:39 --> URI Class Initialized
DEBUG - 2023-09-26 03:57:39 --> No URI present. Default controller set.
INFO - 2023-09-26 03:57:39 --> Router Class Initialized
INFO - 2023-09-26 03:57:39 --> Output Class Initialized
INFO - 2023-09-26 03:57:39 --> Security Class Initialized
DEBUG - 2023-09-26 03:57:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-26 03:57:39 --> Input Class Initialized
INFO - 2023-09-26 03:57:39 --> Language Class Initialized
INFO - 2023-09-26 03:57:39 --> Loader Class Initialized
INFO - 2023-09-26 03:57:39 --> Helper loaded: url_helper
INFO - 2023-09-26 03:57:39 --> Helper loaded: file_helper
INFO - 2023-09-26 03:57:39 --> Helper loaded: html_helper
INFO - 2023-09-26 03:57:39 --> Helper loaded: text_helper
INFO - 2023-09-26 03:57:39 --> Helper loaded: form_helper
INFO - 2023-09-26 03:57:39 --> Helper loaded: lang_helper
INFO - 2023-09-26 03:57:39 --> Helper loaded: security_helper
INFO - 2023-09-26 03:57:39 --> Helper loaded: cookie_helper
INFO - 2023-09-26 03:57:39 --> Database Driver Class Initialized
INFO - 2023-09-26 03:57:39 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-26 03:57:39 --> Parser Class Initialized
INFO - 2023-09-26 03:57:39 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-26 03:57:39 --> Pagination Class Initialized
INFO - 2023-09-26 03:57:39 --> Form Validation Class Initialized
INFO - 2023-09-26 03:57:39 --> Controller Class Initialized
INFO - 2023-09-26 03:57:39 --> Model Class Initialized
DEBUG - 2023-09-26 03:57:39 --> Session class already loaded. Second attempt ignored.
ERROR - 2023-09-26 03:57:39 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-26 03:57:39 --> Config Class Initialized
INFO - 2023-09-26 03:57:39 --> Hooks Class Initialized
DEBUG - 2023-09-26 03:57:39 --> UTF-8 Support Enabled
INFO - 2023-09-26 03:57:39 --> Utf8 Class Initialized
INFO - 2023-09-26 03:57:39 --> URI Class Initialized
INFO - 2023-09-26 03:57:39 --> Router Class Initialized
INFO - 2023-09-26 03:57:39 --> Output Class Initialized
INFO - 2023-09-26 03:57:39 --> Security Class Initialized
DEBUG - 2023-09-26 03:57:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-26 03:57:39 --> Input Class Initialized
INFO - 2023-09-26 03:57:39 --> Language Class Initialized
INFO - 2023-09-26 03:57:39 --> Loader Class Initialized
INFO - 2023-09-26 03:57:39 --> Helper loaded: url_helper
INFO - 2023-09-26 03:57:39 --> Helper loaded: file_helper
INFO - 2023-09-26 03:57:39 --> Helper loaded: html_helper
INFO - 2023-09-26 03:57:39 --> Helper loaded: text_helper
INFO - 2023-09-26 03:57:39 --> Helper loaded: form_helper
INFO - 2023-09-26 03:57:39 --> Helper loaded: lang_helper
INFO - 2023-09-26 03:57:39 --> Helper loaded: security_helper
INFO - 2023-09-26 03:57:39 --> Helper loaded: cookie_helper
INFO - 2023-09-26 03:57:39 --> Database Driver Class Initialized
INFO - 2023-09-26 03:57:39 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-26 03:57:39 --> Parser Class Initialized
INFO - 2023-09-26 03:57:39 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-26 03:57:39 --> Pagination Class Initialized
INFO - 2023-09-26 03:57:39 --> Form Validation Class Initialized
INFO - 2023-09-26 03:57:39 --> Controller Class Initialized
INFO - 2023-09-26 03:57:39 --> Model Class Initialized
DEBUG - 2023-09-26 03:57:39 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-26 03:57:39 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2023-09-26 03:57:39 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-09-26 03:57:39 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-09-26 03:57:39 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-09-26 03:57:39 --> Model Class Initialized
INFO - 2023-09-26 03:57:39 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-09-26 03:57:39 --> Final output sent to browser
DEBUG - 2023-09-26 03:57:39 --> Total execution time: 0.0367
ERROR - 2023-09-26 03:57:53 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-26 03:57:53 --> Config Class Initialized
INFO - 2023-09-26 03:57:53 --> Hooks Class Initialized
DEBUG - 2023-09-26 03:57:53 --> UTF-8 Support Enabled
INFO - 2023-09-26 03:57:53 --> Utf8 Class Initialized
INFO - 2023-09-26 03:57:53 --> URI Class Initialized
DEBUG - 2023-09-26 03:57:53 --> No URI present. Default controller set.
INFO - 2023-09-26 03:57:53 --> Router Class Initialized
INFO - 2023-09-26 03:57:53 --> Output Class Initialized
INFO - 2023-09-26 03:57:53 --> Security Class Initialized
DEBUG - 2023-09-26 03:57:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-26 03:57:53 --> Input Class Initialized
INFO - 2023-09-26 03:57:53 --> Language Class Initialized
INFO - 2023-09-26 03:57:53 --> Loader Class Initialized
INFO - 2023-09-26 03:57:53 --> Helper loaded: url_helper
INFO - 2023-09-26 03:57:53 --> Helper loaded: file_helper
INFO - 2023-09-26 03:57:53 --> Helper loaded: html_helper
INFO - 2023-09-26 03:57:53 --> Helper loaded: text_helper
INFO - 2023-09-26 03:57:53 --> Helper loaded: form_helper
INFO - 2023-09-26 03:57:53 --> Helper loaded: lang_helper
INFO - 2023-09-26 03:57:53 --> Helper loaded: security_helper
INFO - 2023-09-26 03:57:53 --> Helper loaded: cookie_helper
INFO - 2023-09-26 03:57:53 --> Database Driver Class Initialized
INFO - 2023-09-26 03:57:53 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-26 03:57:53 --> Parser Class Initialized
INFO - 2023-09-26 03:57:53 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-26 03:57:53 --> Pagination Class Initialized
INFO - 2023-09-26 03:57:53 --> Form Validation Class Initialized
INFO - 2023-09-26 03:57:53 --> Controller Class Initialized
INFO - 2023-09-26 03:57:53 --> Model Class Initialized
DEBUG - 2023-09-26 03:57:53 --> Session class already loaded. Second attempt ignored.
ERROR - 2023-09-26 03:57:53 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-26 03:57:53 --> Config Class Initialized
INFO - 2023-09-26 03:57:53 --> Hooks Class Initialized
DEBUG - 2023-09-26 03:57:53 --> UTF-8 Support Enabled
INFO - 2023-09-26 03:57:53 --> Utf8 Class Initialized
INFO - 2023-09-26 03:57:53 --> URI Class Initialized
INFO - 2023-09-26 03:57:53 --> Router Class Initialized
INFO - 2023-09-26 03:57:53 --> Output Class Initialized
INFO - 2023-09-26 03:57:53 --> Security Class Initialized
DEBUG - 2023-09-26 03:57:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-26 03:57:53 --> Input Class Initialized
INFO - 2023-09-26 03:57:53 --> Language Class Initialized
INFO - 2023-09-26 03:57:53 --> Loader Class Initialized
INFO - 2023-09-26 03:57:53 --> Helper loaded: url_helper
INFO - 2023-09-26 03:57:53 --> Helper loaded: file_helper
INFO - 2023-09-26 03:57:53 --> Helper loaded: html_helper
INFO - 2023-09-26 03:57:53 --> Helper loaded: text_helper
INFO - 2023-09-26 03:57:53 --> Helper loaded: form_helper
INFO - 2023-09-26 03:57:53 --> Helper loaded: lang_helper
INFO - 2023-09-26 03:57:53 --> Helper loaded: security_helper
INFO - 2023-09-26 03:57:53 --> Helper loaded: cookie_helper
INFO - 2023-09-26 03:57:53 --> Database Driver Class Initialized
INFO - 2023-09-26 03:57:53 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-26 03:57:53 --> Parser Class Initialized
INFO - 2023-09-26 03:57:53 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-26 03:57:53 --> Pagination Class Initialized
INFO - 2023-09-26 03:57:53 --> Form Validation Class Initialized
INFO - 2023-09-26 03:57:53 --> Controller Class Initialized
INFO - 2023-09-26 03:57:53 --> Model Class Initialized
DEBUG - 2023-09-26 03:57:53 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-26 03:57:53 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2023-09-26 03:57:53 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-09-26 03:57:53 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-09-26 03:57:53 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-09-26 03:57:53 --> Model Class Initialized
INFO - 2023-09-26 03:57:53 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-09-26 03:57:53 --> Final output sent to browser
DEBUG - 2023-09-26 03:57:53 --> Total execution time: 0.0349
ERROR - 2023-09-26 06:17:58 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-26 06:17:58 --> Config Class Initialized
INFO - 2023-09-26 06:17:58 --> Hooks Class Initialized
DEBUG - 2023-09-26 06:17:58 --> UTF-8 Support Enabled
INFO - 2023-09-26 06:17:58 --> Utf8 Class Initialized
INFO - 2023-09-26 06:17:58 --> URI Class Initialized
DEBUG - 2023-09-26 06:17:58 --> No URI present. Default controller set.
INFO - 2023-09-26 06:17:58 --> Router Class Initialized
INFO - 2023-09-26 06:17:58 --> Output Class Initialized
INFO - 2023-09-26 06:17:58 --> Security Class Initialized
DEBUG - 2023-09-26 06:17:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-26 06:17:58 --> Input Class Initialized
INFO - 2023-09-26 06:17:58 --> Language Class Initialized
INFO - 2023-09-26 06:17:58 --> Loader Class Initialized
INFO - 2023-09-26 06:17:58 --> Helper loaded: url_helper
INFO - 2023-09-26 06:17:58 --> Helper loaded: file_helper
INFO - 2023-09-26 06:17:58 --> Helper loaded: html_helper
INFO - 2023-09-26 06:17:58 --> Helper loaded: text_helper
INFO - 2023-09-26 06:17:58 --> Helper loaded: form_helper
INFO - 2023-09-26 06:17:58 --> Helper loaded: lang_helper
INFO - 2023-09-26 06:17:58 --> Helper loaded: security_helper
INFO - 2023-09-26 06:17:58 --> Helper loaded: cookie_helper
INFO - 2023-09-26 06:17:58 --> Database Driver Class Initialized
INFO - 2023-09-26 06:17:58 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-26 06:17:58 --> Parser Class Initialized
INFO - 2023-09-26 06:17:58 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-26 06:17:58 --> Pagination Class Initialized
INFO - 2023-09-26 06:17:58 --> Form Validation Class Initialized
INFO - 2023-09-26 06:17:58 --> Controller Class Initialized
INFO - 2023-09-26 06:17:58 --> Model Class Initialized
DEBUG - 2023-09-26 06:17:58 --> Session class already loaded. Second attempt ignored.
ERROR - 2023-09-26 09:33:27 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-26 09:33:27 --> Config Class Initialized
INFO - 2023-09-26 09:33:27 --> Hooks Class Initialized
DEBUG - 2023-09-26 09:33:27 --> UTF-8 Support Enabled
INFO - 2023-09-26 09:33:27 --> Utf8 Class Initialized
INFO - 2023-09-26 09:33:27 --> URI Class Initialized
DEBUG - 2023-09-26 09:33:27 --> No URI present. Default controller set.
INFO - 2023-09-26 09:33:27 --> Router Class Initialized
INFO - 2023-09-26 09:33:27 --> Output Class Initialized
INFO - 2023-09-26 09:33:27 --> Security Class Initialized
DEBUG - 2023-09-26 09:33:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-26 09:33:27 --> Input Class Initialized
INFO - 2023-09-26 09:33:27 --> Language Class Initialized
INFO - 2023-09-26 09:33:27 --> Loader Class Initialized
INFO - 2023-09-26 09:33:27 --> Helper loaded: url_helper
INFO - 2023-09-26 09:33:27 --> Helper loaded: file_helper
INFO - 2023-09-26 09:33:27 --> Helper loaded: html_helper
INFO - 2023-09-26 09:33:27 --> Helper loaded: text_helper
INFO - 2023-09-26 09:33:27 --> Helper loaded: form_helper
INFO - 2023-09-26 09:33:27 --> Helper loaded: lang_helper
INFO - 2023-09-26 09:33:27 --> Helper loaded: security_helper
INFO - 2023-09-26 09:33:27 --> Helper loaded: cookie_helper
INFO - 2023-09-26 09:33:27 --> Database Driver Class Initialized
INFO - 2023-09-26 09:33:27 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-26 09:33:27 --> Parser Class Initialized
INFO - 2023-09-26 09:33:27 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-26 09:33:27 --> Pagination Class Initialized
INFO - 2023-09-26 09:33:27 --> Form Validation Class Initialized
INFO - 2023-09-26 09:33:27 --> Controller Class Initialized
INFO - 2023-09-26 09:33:27 --> Model Class Initialized
DEBUG - 2023-09-26 09:33:27 --> Session class already loaded. Second attempt ignored.
ERROR - 2023-09-26 09:33:28 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-26 09:33:28 --> Config Class Initialized
INFO - 2023-09-26 09:33:28 --> Hooks Class Initialized
DEBUG - 2023-09-26 09:33:28 --> UTF-8 Support Enabled
INFO - 2023-09-26 09:33:28 --> Utf8 Class Initialized
INFO - 2023-09-26 09:33:28 --> URI Class Initialized
DEBUG - 2023-09-26 09:33:28 --> No URI present. Default controller set.
INFO - 2023-09-26 09:33:28 --> Router Class Initialized
INFO - 2023-09-26 09:33:28 --> Output Class Initialized
INFO - 2023-09-26 09:33:28 --> Security Class Initialized
DEBUG - 2023-09-26 09:33:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-26 09:33:28 --> Input Class Initialized
INFO - 2023-09-26 09:33:28 --> Language Class Initialized
INFO - 2023-09-26 09:33:28 --> Loader Class Initialized
INFO - 2023-09-26 09:33:28 --> Helper loaded: url_helper
INFO - 2023-09-26 09:33:28 --> Helper loaded: file_helper
INFO - 2023-09-26 09:33:28 --> Helper loaded: html_helper
INFO - 2023-09-26 09:33:28 --> Helper loaded: text_helper
INFO - 2023-09-26 09:33:28 --> Helper loaded: form_helper
INFO - 2023-09-26 09:33:28 --> Helper loaded: lang_helper
INFO - 2023-09-26 09:33:28 --> Helper loaded: security_helper
INFO - 2023-09-26 09:33:28 --> Helper loaded: cookie_helper
INFO - 2023-09-26 09:33:28 --> Database Driver Class Initialized
INFO - 2023-09-26 09:33:28 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-26 09:33:28 --> Parser Class Initialized
INFO - 2023-09-26 09:33:28 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-26 09:33:28 --> Pagination Class Initialized
INFO - 2023-09-26 09:33:28 --> Form Validation Class Initialized
INFO - 2023-09-26 09:33:28 --> Controller Class Initialized
INFO - 2023-09-26 09:33:28 --> Model Class Initialized
DEBUG - 2023-09-26 09:33:28 --> Session class already loaded. Second attempt ignored.
ERROR - 2023-09-26 09:33:32 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-26 09:33:32 --> Config Class Initialized
INFO - 2023-09-26 09:33:32 --> Hooks Class Initialized
DEBUG - 2023-09-26 09:33:32 --> UTF-8 Support Enabled
INFO - 2023-09-26 09:33:32 --> Utf8 Class Initialized
INFO - 2023-09-26 09:33:32 --> URI Class Initialized
DEBUG - 2023-09-26 09:33:32 --> No URI present. Default controller set.
INFO - 2023-09-26 09:33:32 --> Router Class Initialized
INFO - 2023-09-26 09:33:32 --> Output Class Initialized
INFO - 2023-09-26 09:33:32 --> Security Class Initialized
DEBUG - 2023-09-26 09:33:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-26 09:33:32 --> Input Class Initialized
INFO - 2023-09-26 09:33:32 --> Language Class Initialized
INFO - 2023-09-26 09:33:32 --> Loader Class Initialized
INFO - 2023-09-26 09:33:32 --> Helper loaded: url_helper
INFO - 2023-09-26 09:33:32 --> Helper loaded: file_helper
INFO - 2023-09-26 09:33:32 --> Helper loaded: html_helper
INFO - 2023-09-26 09:33:32 --> Helper loaded: text_helper
INFO - 2023-09-26 09:33:32 --> Helper loaded: form_helper
INFO - 2023-09-26 09:33:32 --> Helper loaded: lang_helper
INFO - 2023-09-26 09:33:32 --> Helper loaded: security_helper
INFO - 2023-09-26 09:33:32 --> Helper loaded: cookie_helper
INFO - 2023-09-26 09:33:32 --> Database Driver Class Initialized
INFO - 2023-09-26 09:33:32 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-26 09:33:32 --> Parser Class Initialized
INFO - 2023-09-26 09:33:32 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-26 09:33:32 --> Pagination Class Initialized
INFO - 2023-09-26 09:33:32 --> Form Validation Class Initialized
INFO - 2023-09-26 09:33:32 --> Controller Class Initialized
INFO - 2023-09-26 09:33:32 --> Model Class Initialized
DEBUG - 2023-09-26 09:33:32 --> Session class already loaded. Second attempt ignored.
ERROR - 2023-09-26 09:33:32 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-26 09:33:32 --> Config Class Initialized
INFO - 2023-09-26 09:33:32 --> Hooks Class Initialized
DEBUG - 2023-09-26 09:33:32 --> UTF-8 Support Enabled
INFO - 2023-09-26 09:33:32 --> Utf8 Class Initialized
INFO - 2023-09-26 09:33:32 --> URI Class Initialized
DEBUG - 2023-09-26 09:33:32 --> No URI present. Default controller set.
INFO - 2023-09-26 09:33:32 --> Router Class Initialized
INFO - 2023-09-26 09:33:32 --> Output Class Initialized
INFO - 2023-09-26 09:33:32 --> Security Class Initialized
DEBUG - 2023-09-26 09:33:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-26 09:33:32 --> Input Class Initialized
INFO - 2023-09-26 09:33:32 --> Language Class Initialized
INFO - 2023-09-26 09:33:32 --> Loader Class Initialized
INFO - 2023-09-26 09:33:32 --> Helper loaded: url_helper
INFO - 2023-09-26 09:33:32 --> Helper loaded: file_helper
INFO - 2023-09-26 09:33:32 --> Helper loaded: html_helper
INFO - 2023-09-26 09:33:32 --> Helper loaded: text_helper
INFO - 2023-09-26 09:33:32 --> Helper loaded: form_helper
INFO - 2023-09-26 09:33:32 --> Helper loaded: lang_helper
INFO - 2023-09-26 09:33:32 --> Helper loaded: security_helper
INFO - 2023-09-26 09:33:32 --> Helper loaded: cookie_helper
INFO - 2023-09-26 09:33:32 --> Database Driver Class Initialized
INFO - 2023-09-26 09:33:32 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-26 09:33:32 --> Parser Class Initialized
INFO - 2023-09-26 09:33:32 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-26 09:33:32 --> Pagination Class Initialized
INFO - 2023-09-26 09:33:32 --> Form Validation Class Initialized
INFO - 2023-09-26 09:33:32 --> Controller Class Initialized
INFO - 2023-09-26 09:33:32 --> Model Class Initialized
DEBUG - 2023-09-26 09:33:32 --> Session class already loaded. Second attempt ignored.
ERROR - 2023-09-26 09:59:08 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-26 09:59:08 --> Config Class Initialized
INFO - 2023-09-26 09:59:08 --> Hooks Class Initialized
DEBUG - 2023-09-26 09:59:08 --> UTF-8 Support Enabled
INFO - 2023-09-26 09:59:08 --> Utf8 Class Initialized
INFO - 2023-09-26 09:59:08 --> URI Class Initialized
DEBUG - 2023-09-26 09:59:08 --> No URI present. Default controller set.
INFO - 2023-09-26 09:59:08 --> Router Class Initialized
INFO - 2023-09-26 09:59:08 --> Output Class Initialized
INFO - 2023-09-26 09:59:08 --> Security Class Initialized
DEBUG - 2023-09-26 09:59:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-26 09:59:08 --> Input Class Initialized
INFO - 2023-09-26 09:59:08 --> Language Class Initialized
INFO - 2023-09-26 09:59:08 --> Loader Class Initialized
INFO - 2023-09-26 09:59:08 --> Helper loaded: url_helper
INFO - 2023-09-26 09:59:08 --> Helper loaded: file_helper
INFO - 2023-09-26 09:59:08 --> Helper loaded: html_helper
INFO - 2023-09-26 09:59:08 --> Helper loaded: text_helper
INFO - 2023-09-26 09:59:08 --> Helper loaded: form_helper
INFO - 2023-09-26 09:59:08 --> Helper loaded: lang_helper
INFO - 2023-09-26 09:59:08 --> Helper loaded: security_helper
INFO - 2023-09-26 09:59:08 --> Helper loaded: cookie_helper
INFO - 2023-09-26 09:59:08 --> Database Driver Class Initialized
INFO - 2023-09-26 09:59:08 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-26 09:59:08 --> Parser Class Initialized
INFO - 2023-09-26 09:59:08 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-26 09:59:08 --> Pagination Class Initialized
INFO - 2023-09-26 09:59:08 --> Form Validation Class Initialized
INFO - 2023-09-26 09:59:08 --> Controller Class Initialized
INFO - 2023-09-26 09:59:08 --> Model Class Initialized
DEBUG - 2023-09-26 09:59:08 --> Session class already loaded. Second attempt ignored.
ERROR - 2023-09-26 09:59:08 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-26 09:59:08 --> Config Class Initialized
INFO - 2023-09-26 09:59:08 --> Hooks Class Initialized
DEBUG - 2023-09-26 09:59:08 --> UTF-8 Support Enabled
INFO - 2023-09-26 09:59:08 --> Utf8 Class Initialized
INFO - 2023-09-26 09:59:08 --> URI Class Initialized
INFO - 2023-09-26 09:59:08 --> Router Class Initialized
INFO - 2023-09-26 09:59:08 --> Output Class Initialized
INFO - 2023-09-26 09:59:08 --> Security Class Initialized
DEBUG - 2023-09-26 09:59:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-26 09:59:08 --> Input Class Initialized
INFO - 2023-09-26 09:59:08 --> Language Class Initialized
INFO - 2023-09-26 09:59:08 --> Loader Class Initialized
INFO - 2023-09-26 09:59:08 --> Helper loaded: url_helper
INFO - 2023-09-26 09:59:08 --> Helper loaded: file_helper
INFO - 2023-09-26 09:59:08 --> Helper loaded: html_helper
INFO - 2023-09-26 09:59:08 --> Helper loaded: text_helper
INFO - 2023-09-26 09:59:08 --> Helper loaded: form_helper
INFO - 2023-09-26 09:59:08 --> Helper loaded: lang_helper
INFO - 2023-09-26 09:59:08 --> Helper loaded: security_helper
INFO - 2023-09-26 09:59:08 --> Helper loaded: cookie_helper
INFO - 2023-09-26 09:59:08 --> Database Driver Class Initialized
INFO - 2023-09-26 09:59:08 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-26 09:59:08 --> Parser Class Initialized
INFO - 2023-09-26 09:59:08 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-26 09:59:08 --> Pagination Class Initialized
INFO - 2023-09-26 09:59:08 --> Form Validation Class Initialized
INFO - 2023-09-26 09:59:08 --> Controller Class Initialized
INFO - 2023-09-26 09:59:08 --> Model Class Initialized
DEBUG - 2023-09-26 09:59:08 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-26 09:59:08 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2023-09-26 09:59:08 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-09-26 09:59:08 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-09-26 09:59:08 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-09-26 09:59:08 --> Model Class Initialized
INFO - 2023-09-26 09:59:08 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-09-26 09:59:08 --> Final output sent to browser
DEBUG - 2023-09-26 09:59:08 --> Total execution time: 0.0376
ERROR - 2023-09-26 09:59:11 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-26 09:59:11 --> Config Class Initialized
INFO - 2023-09-26 09:59:11 --> Hooks Class Initialized
DEBUG - 2023-09-26 09:59:11 --> UTF-8 Support Enabled
INFO - 2023-09-26 09:59:11 --> Utf8 Class Initialized
INFO - 2023-09-26 09:59:11 --> URI Class Initialized
INFO - 2023-09-26 09:59:11 --> Router Class Initialized
INFO - 2023-09-26 09:59:11 --> Output Class Initialized
INFO - 2023-09-26 09:59:11 --> Security Class Initialized
DEBUG - 2023-09-26 09:59:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-26 09:59:11 --> Input Class Initialized
INFO - 2023-09-26 09:59:11 --> Language Class Initialized
INFO - 2023-09-26 09:59:11 --> Loader Class Initialized
INFO - 2023-09-26 09:59:11 --> Helper loaded: url_helper
INFO - 2023-09-26 09:59:11 --> Helper loaded: file_helper
INFO - 2023-09-26 09:59:11 --> Helper loaded: html_helper
INFO - 2023-09-26 09:59:11 --> Helper loaded: text_helper
INFO - 2023-09-26 09:59:11 --> Helper loaded: form_helper
INFO - 2023-09-26 09:59:11 --> Helper loaded: lang_helper
INFO - 2023-09-26 09:59:11 --> Helper loaded: security_helper
INFO - 2023-09-26 09:59:11 --> Helper loaded: cookie_helper
INFO - 2023-09-26 09:59:11 --> Database Driver Class Initialized
INFO - 2023-09-26 09:59:11 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-26 09:59:11 --> Parser Class Initialized
INFO - 2023-09-26 09:59:11 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-26 09:59:11 --> Pagination Class Initialized
INFO - 2023-09-26 09:59:11 --> Form Validation Class Initialized
INFO - 2023-09-26 09:59:11 --> Controller Class Initialized
INFO - 2023-09-26 09:59:11 --> Model Class Initialized
DEBUG - 2023-09-26 09:59:11 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-26 09:59:11 --> Model Class Initialized
INFO - 2023-09-26 09:59:11 --> Final output sent to browser
DEBUG - 2023-09-26 09:59:11 --> Total execution time: 0.0221
ERROR - 2023-09-26 09:59:11 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-26 09:59:11 --> Config Class Initialized
INFO - 2023-09-26 09:59:11 --> Hooks Class Initialized
DEBUG - 2023-09-26 09:59:11 --> UTF-8 Support Enabled
INFO - 2023-09-26 09:59:11 --> Utf8 Class Initialized
INFO - 2023-09-26 09:59:11 --> URI Class Initialized
DEBUG - 2023-09-26 09:59:11 --> No URI present. Default controller set.
INFO - 2023-09-26 09:59:11 --> Router Class Initialized
INFO - 2023-09-26 09:59:11 --> Output Class Initialized
INFO - 2023-09-26 09:59:11 --> Security Class Initialized
DEBUG - 2023-09-26 09:59:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-26 09:59:11 --> Input Class Initialized
INFO - 2023-09-26 09:59:11 --> Language Class Initialized
INFO - 2023-09-26 09:59:11 --> Loader Class Initialized
INFO - 2023-09-26 09:59:11 --> Helper loaded: url_helper
INFO - 2023-09-26 09:59:11 --> Helper loaded: file_helper
INFO - 2023-09-26 09:59:11 --> Helper loaded: html_helper
INFO - 2023-09-26 09:59:11 --> Helper loaded: text_helper
INFO - 2023-09-26 09:59:11 --> Helper loaded: form_helper
INFO - 2023-09-26 09:59:11 --> Helper loaded: lang_helper
INFO - 2023-09-26 09:59:11 --> Helper loaded: security_helper
INFO - 2023-09-26 09:59:11 --> Helper loaded: cookie_helper
INFO - 2023-09-26 09:59:11 --> Database Driver Class Initialized
INFO - 2023-09-26 09:59:11 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-26 09:59:11 --> Parser Class Initialized
INFO - 2023-09-26 09:59:11 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-26 09:59:11 --> Pagination Class Initialized
INFO - 2023-09-26 09:59:11 --> Form Validation Class Initialized
INFO - 2023-09-26 09:59:11 --> Controller Class Initialized
INFO - 2023-09-26 09:59:11 --> Model Class Initialized
DEBUG - 2023-09-26 09:59:11 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-26 09:59:11 --> Model Class Initialized
DEBUG - 2023-09-26 09:59:11 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-26 09:59:11 --> Model Class Initialized
INFO - 2023-09-26 09:59:11 --> Model Class Initialized
INFO - 2023-09-26 09:59:11 --> Model Class Initialized
INFO - 2023-09-26 09:59:11 --> Model Class Initialized
DEBUG - 2023-09-26 09:59:11 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-09-26 09:59:11 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-26 09:59:11 --> Model Class Initialized
INFO - 2023-09-26 09:59:11 --> Model Class Initialized
INFO - 2023-09-26 09:59:11 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-09-26 09:59:11 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-09-26 09:59:11 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-09-26 09:59:11 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-09-26 09:59:11 --> Model Class Initialized
INFO - 2023-09-26 09:59:11 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-09-26 09:59:11 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-09-26 09:59:11 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-09-26 09:59:11 --> Final output sent to browser
DEBUG - 2023-09-26 09:59:11 --> Total execution time: 0.2477
ERROR - 2023-09-26 09:59:12 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-26 09:59:12 --> Config Class Initialized
INFO - 2023-09-26 09:59:12 --> Hooks Class Initialized
DEBUG - 2023-09-26 09:59:12 --> UTF-8 Support Enabled
INFO - 2023-09-26 09:59:12 --> Utf8 Class Initialized
INFO - 2023-09-26 09:59:12 --> URI Class Initialized
INFO - 2023-09-26 09:59:12 --> Router Class Initialized
INFO - 2023-09-26 09:59:12 --> Output Class Initialized
INFO - 2023-09-26 09:59:12 --> Security Class Initialized
DEBUG - 2023-09-26 09:59:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-26 09:59:12 --> Input Class Initialized
INFO - 2023-09-26 09:59:12 --> Language Class Initialized
INFO - 2023-09-26 09:59:12 --> Loader Class Initialized
INFO - 2023-09-26 09:59:12 --> Helper loaded: url_helper
INFO - 2023-09-26 09:59:12 --> Helper loaded: file_helper
INFO - 2023-09-26 09:59:12 --> Helper loaded: html_helper
INFO - 2023-09-26 09:59:12 --> Helper loaded: text_helper
INFO - 2023-09-26 09:59:12 --> Helper loaded: form_helper
INFO - 2023-09-26 09:59:12 --> Helper loaded: lang_helper
INFO - 2023-09-26 09:59:12 --> Helper loaded: security_helper
INFO - 2023-09-26 09:59:12 --> Helper loaded: cookie_helper
INFO - 2023-09-26 09:59:12 --> Database Driver Class Initialized
INFO - 2023-09-26 09:59:12 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-26 09:59:12 --> Parser Class Initialized
INFO - 2023-09-26 09:59:12 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-26 09:59:12 --> Pagination Class Initialized
INFO - 2023-09-26 09:59:12 --> Form Validation Class Initialized
INFO - 2023-09-26 09:59:12 --> Controller Class Initialized
DEBUG - 2023-09-26 09:59:12 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-09-26 09:59:12 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-26 09:59:12 --> Model Class Initialized
INFO - 2023-09-26 09:59:12 --> Final output sent to browser
DEBUG - 2023-09-26 09:59:12 --> Total execution time: 0.0132
ERROR - 2023-09-26 10:08:13 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-26 10:08:13 --> Config Class Initialized
INFO - 2023-09-26 10:08:13 --> Hooks Class Initialized
DEBUG - 2023-09-26 10:08:13 --> UTF-8 Support Enabled
INFO - 2023-09-26 10:08:13 --> Utf8 Class Initialized
INFO - 2023-09-26 10:08:13 --> URI Class Initialized
DEBUG - 2023-09-26 10:08:13 --> No URI present. Default controller set.
INFO - 2023-09-26 10:08:13 --> Router Class Initialized
INFO - 2023-09-26 10:08:13 --> Output Class Initialized
INFO - 2023-09-26 10:08:13 --> Security Class Initialized
DEBUG - 2023-09-26 10:08:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-26 10:08:13 --> Input Class Initialized
INFO - 2023-09-26 10:08:13 --> Language Class Initialized
INFO - 2023-09-26 10:08:13 --> Loader Class Initialized
INFO - 2023-09-26 10:08:13 --> Helper loaded: url_helper
INFO - 2023-09-26 10:08:13 --> Helper loaded: file_helper
INFO - 2023-09-26 10:08:13 --> Helper loaded: html_helper
INFO - 2023-09-26 10:08:13 --> Helper loaded: text_helper
INFO - 2023-09-26 10:08:13 --> Helper loaded: form_helper
INFO - 2023-09-26 10:08:13 --> Helper loaded: lang_helper
INFO - 2023-09-26 10:08:13 --> Helper loaded: security_helper
INFO - 2023-09-26 10:08:13 --> Helper loaded: cookie_helper
INFO - 2023-09-26 10:08:13 --> Database Driver Class Initialized
INFO - 2023-09-26 10:08:13 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-26 10:08:13 --> Parser Class Initialized
INFO - 2023-09-26 10:08:13 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-26 10:08:13 --> Pagination Class Initialized
INFO - 2023-09-26 10:08:13 --> Form Validation Class Initialized
INFO - 2023-09-26 10:08:13 --> Controller Class Initialized
INFO - 2023-09-26 10:08:13 --> Model Class Initialized
DEBUG - 2023-09-26 10:08:13 --> Session class already loaded. Second attempt ignored.
ERROR - 2023-09-26 10:08:14 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-26 10:08:14 --> Config Class Initialized
INFO - 2023-09-26 10:08:14 --> Hooks Class Initialized
DEBUG - 2023-09-26 10:08:14 --> UTF-8 Support Enabled
INFO - 2023-09-26 10:08:14 --> Utf8 Class Initialized
INFO - 2023-09-26 10:08:14 --> URI Class Initialized
INFO - 2023-09-26 10:08:14 --> Router Class Initialized
INFO - 2023-09-26 10:08:14 --> Output Class Initialized
INFO - 2023-09-26 10:08:14 --> Security Class Initialized
DEBUG - 2023-09-26 10:08:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-26 10:08:14 --> Input Class Initialized
INFO - 2023-09-26 10:08:14 --> Language Class Initialized
INFO - 2023-09-26 10:08:14 --> Loader Class Initialized
INFO - 2023-09-26 10:08:14 --> Helper loaded: url_helper
INFO - 2023-09-26 10:08:14 --> Helper loaded: file_helper
INFO - 2023-09-26 10:08:14 --> Helper loaded: html_helper
INFO - 2023-09-26 10:08:14 --> Helper loaded: text_helper
INFO - 2023-09-26 10:08:14 --> Helper loaded: form_helper
INFO - 2023-09-26 10:08:14 --> Helper loaded: lang_helper
INFO - 2023-09-26 10:08:14 --> Helper loaded: security_helper
INFO - 2023-09-26 10:08:14 --> Helper loaded: cookie_helper
INFO - 2023-09-26 10:08:14 --> Database Driver Class Initialized
INFO - 2023-09-26 10:08:14 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-26 10:08:14 --> Parser Class Initialized
INFO - 2023-09-26 10:08:14 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-26 10:08:14 --> Pagination Class Initialized
INFO - 2023-09-26 10:08:14 --> Form Validation Class Initialized
INFO - 2023-09-26 10:08:14 --> Controller Class Initialized
INFO - 2023-09-26 10:08:14 --> Model Class Initialized
DEBUG - 2023-09-26 10:08:14 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-26 10:08:14 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2023-09-26 10:08:14 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-09-26 10:08:14 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-09-26 10:08:14 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-09-26 10:08:14 --> Model Class Initialized
INFO - 2023-09-26 10:08:14 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-09-26 10:08:14 --> Final output sent to browser
DEBUG - 2023-09-26 10:08:14 --> Total execution time: 0.0323
ERROR - 2023-09-26 11:39:32 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-26 11:39:32 --> Config Class Initialized
INFO - 2023-09-26 11:39:32 --> Hooks Class Initialized
DEBUG - 2023-09-26 11:39:32 --> UTF-8 Support Enabled
INFO - 2023-09-26 11:39:32 --> Utf8 Class Initialized
INFO - 2023-09-26 11:39:32 --> URI Class Initialized
DEBUG - 2023-09-26 11:39:32 --> No URI present. Default controller set.
INFO - 2023-09-26 11:39:32 --> Router Class Initialized
INFO - 2023-09-26 11:39:32 --> Output Class Initialized
INFO - 2023-09-26 11:39:32 --> Security Class Initialized
DEBUG - 2023-09-26 11:39:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-26 11:39:32 --> Input Class Initialized
INFO - 2023-09-26 11:39:32 --> Language Class Initialized
INFO - 2023-09-26 11:39:32 --> Loader Class Initialized
INFO - 2023-09-26 11:39:32 --> Helper loaded: url_helper
INFO - 2023-09-26 11:39:32 --> Helper loaded: file_helper
INFO - 2023-09-26 11:39:32 --> Helper loaded: html_helper
INFO - 2023-09-26 11:39:32 --> Helper loaded: text_helper
INFO - 2023-09-26 11:39:32 --> Helper loaded: form_helper
INFO - 2023-09-26 11:39:32 --> Helper loaded: lang_helper
INFO - 2023-09-26 11:39:32 --> Helper loaded: security_helper
INFO - 2023-09-26 11:39:32 --> Helper loaded: cookie_helper
INFO - 2023-09-26 11:39:32 --> Database Driver Class Initialized
INFO - 2023-09-26 11:39:32 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-26 11:39:32 --> Parser Class Initialized
INFO - 2023-09-26 11:39:32 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-26 11:39:32 --> Pagination Class Initialized
INFO - 2023-09-26 11:39:32 --> Form Validation Class Initialized
INFO - 2023-09-26 11:39:32 --> Controller Class Initialized
INFO - 2023-09-26 11:39:32 --> Model Class Initialized
DEBUG - 2023-09-26 11:39:32 --> Session class already loaded. Second attempt ignored.
ERROR - 2023-09-26 11:40:56 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-26 11:40:56 --> Config Class Initialized
INFO - 2023-09-26 11:40:56 --> Hooks Class Initialized
DEBUG - 2023-09-26 11:40:56 --> UTF-8 Support Enabled
INFO - 2023-09-26 11:40:56 --> Utf8 Class Initialized
INFO - 2023-09-26 11:40:56 --> URI Class Initialized
DEBUG - 2023-09-26 11:40:56 --> No URI present. Default controller set.
INFO - 2023-09-26 11:40:56 --> Router Class Initialized
INFO - 2023-09-26 11:40:56 --> Output Class Initialized
INFO - 2023-09-26 11:40:56 --> Security Class Initialized
DEBUG - 2023-09-26 11:40:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-26 11:40:56 --> Input Class Initialized
INFO - 2023-09-26 11:40:56 --> Language Class Initialized
INFO - 2023-09-26 11:40:56 --> Loader Class Initialized
INFO - 2023-09-26 11:40:56 --> Helper loaded: url_helper
INFO - 2023-09-26 11:40:56 --> Helper loaded: file_helper
INFO - 2023-09-26 11:40:56 --> Helper loaded: html_helper
INFO - 2023-09-26 11:40:56 --> Helper loaded: text_helper
INFO - 2023-09-26 11:40:56 --> Helper loaded: form_helper
INFO - 2023-09-26 11:40:56 --> Helper loaded: lang_helper
INFO - 2023-09-26 11:40:56 --> Helper loaded: security_helper
INFO - 2023-09-26 11:40:56 --> Helper loaded: cookie_helper
INFO - 2023-09-26 11:40:56 --> Database Driver Class Initialized
INFO - 2023-09-26 11:40:56 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-26 11:40:56 --> Parser Class Initialized
INFO - 2023-09-26 11:40:56 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-26 11:40:56 --> Pagination Class Initialized
INFO - 2023-09-26 11:40:56 --> Form Validation Class Initialized
INFO - 2023-09-26 11:40:56 --> Controller Class Initialized
INFO - 2023-09-26 11:40:56 --> Model Class Initialized
DEBUG - 2023-09-26 11:40:56 --> Session class already loaded. Second attempt ignored.
ERROR - 2023-09-26 11:40:56 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-26 11:40:56 --> Config Class Initialized
INFO - 2023-09-26 11:40:56 --> Hooks Class Initialized
DEBUG - 2023-09-26 11:40:56 --> UTF-8 Support Enabled
INFO - 2023-09-26 11:40:56 --> Utf8 Class Initialized
INFO - 2023-09-26 11:40:56 --> URI Class Initialized
INFO - 2023-09-26 11:40:56 --> Router Class Initialized
INFO - 2023-09-26 11:40:56 --> Output Class Initialized
INFO - 2023-09-26 11:40:56 --> Security Class Initialized
DEBUG - 2023-09-26 11:40:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-26 11:40:56 --> Input Class Initialized
INFO - 2023-09-26 11:40:56 --> Language Class Initialized
ERROR - 2023-09-26 11:40:56 --> 404 Page Not Found: Wp-includes/wlwmanifest.xml
ERROR - 2023-09-26 11:40:56 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-26 11:40:56 --> Config Class Initialized
INFO - 2023-09-26 11:40:56 --> Hooks Class Initialized
DEBUG - 2023-09-26 11:40:56 --> UTF-8 Support Enabled
INFO - 2023-09-26 11:40:56 --> Utf8 Class Initialized
INFO - 2023-09-26 11:40:56 --> URI Class Initialized
INFO - 2023-09-26 11:40:56 --> Router Class Initialized
INFO - 2023-09-26 11:40:56 --> Output Class Initialized
INFO - 2023-09-26 11:40:56 --> Security Class Initialized
DEBUG - 2023-09-26 11:40:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-26 11:40:56 --> Input Class Initialized
INFO - 2023-09-26 11:40:56 --> Language Class Initialized
ERROR - 2023-09-26 11:40:56 --> 404 Page Not Found: Xmlrpcphp/index
ERROR - 2023-09-26 11:40:56 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-26 11:40:56 --> Config Class Initialized
INFO - 2023-09-26 11:40:56 --> Hooks Class Initialized
DEBUG - 2023-09-26 11:40:56 --> UTF-8 Support Enabled
INFO - 2023-09-26 11:40:56 --> Utf8 Class Initialized
INFO - 2023-09-26 11:40:56 --> URI Class Initialized
DEBUG - 2023-09-26 11:40:56 --> No URI present. Default controller set.
INFO - 2023-09-26 11:40:56 --> Router Class Initialized
INFO - 2023-09-26 11:40:56 --> Output Class Initialized
INFO - 2023-09-26 11:40:56 --> Security Class Initialized
DEBUG - 2023-09-26 11:40:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-26 11:40:56 --> Input Class Initialized
INFO - 2023-09-26 11:40:56 --> Language Class Initialized
INFO - 2023-09-26 11:40:56 --> Loader Class Initialized
INFO - 2023-09-26 11:40:56 --> Helper loaded: url_helper
INFO - 2023-09-26 11:40:56 --> Helper loaded: file_helper
INFO - 2023-09-26 11:40:56 --> Helper loaded: html_helper
INFO - 2023-09-26 11:40:56 --> Helper loaded: text_helper
INFO - 2023-09-26 11:40:56 --> Helper loaded: form_helper
INFO - 2023-09-26 11:40:56 --> Helper loaded: lang_helper
INFO - 2023-09-26 11:40:56 --> Helper loaded: security_helper
INFO - 2023-09-26 11:40:56 --> Helper loaded: cookie_helper
INFO - 2023-09-26 11:40:56 --> Database Driver Class Initialized
INFO - 2023-09-26 11:40:56 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-26 11:40:56 --> Parser Class Initialized
INFO - 2023-09-26 11:40:56 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-26 11:40:56 --> Pagination Class Initialized
INFO - 2023-09-26 11:40:56 --> Form Validation Class Initialized
INFO - 2023-09-26 11:40:56 --> Controller Class Initialized
INFO - 2023-09-26 11:40:56 --> Model Class Initialized
DEBUG - 2023-09-26 11:40:56 --> Session class already loaded. Second attempt ignored.
ERROR - 2023-09-26 11:40:57 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-26 11:40:57 --> Config Class Initialized
INFO - 2023-09-26 11:40:57 --> Hooks Class Initialized
DEBUG - 2023-09-26 11:40:57 --> UTF-8 Support Enabled
INFO - 2023-09-26 11:40:57 --> Utf8 Class Initialized
INFO - 2023-09-26 11:40:57 --> URI Class Initialized
INFO - 2023-09-26 11:40:57 --> Router Class Initialized
INFO - 2023-09-26 11:40:57 --> Output Class Initialized
INFO - 2023-09-26 11:40:57 --> Security Class Initialized
DEBUG - 2023-09-26 11:40:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-26 11:40:57 --> Input Class Initialized
INFO - 2023-09-26 11:40:57 --> Language Class Initialized
ERROR - 2023-09-26 11:40:57 --> 404 Page Not Found: Blog/wp-includes
ERROR - 2023-09-26 11:40:57 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-26 11:40:57 --> Config Class Initialized
INFO - 2023-09-26 11:40:57 --> Hooks Class Initialized
DEBUG - 2023-09-26 11:40:57 --> UTF-8 Support Enabled
INFO - 2023-09-26 11:40:57 --> Utf8 Class Initialized
INFO - 2023-09-26 11:40:57 --> URI Class Initialized
INFO - 2023-09-26 11:40:57 --> Router Class Initialized
INFO - 2023-09-26 11:40:57 --> Output Class Initialized
INFO - 2023-09-26 11:40:57 --> Security Class Initialized
DEBUG - 2023-09-26 11:40:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-26 11:40:57 --> Input Class Initialized
INFO - 2023-09-26 11:40:57 --> Language Class Initialized
ERROR - 2023-09-26 11:40:57 --> 404 Page Not Found: Web/wp-includes
ERROR - 2023-09-26 11:40:57 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-26 11:40:57 --> Config Class Initialized
INFO - 2023-09-26 11:40:57 --> Hooks Class Initialized
DEBUG - 2023-09-26 11:40:57 --> UTF-8 Support Enabled
INFO - 2023-09-26 11:40:57 --> Utf8 Class Initialized
INFO - 2023-09-26 11:40:57 --> URI Class Initialized
INFO - 2023-09-26 11:40:57 --> Router Class Initialized
INFO - 2023-09-26 11:40:57 --> Output Class Initialized
INFO - 2023-09-26 11:40:57 --> Security Class Initialized
DEBUG - 2023-09-26 11:40:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-26 11:40:57 --> Input Class Initialized
INFO - 2023-09-26 11:40:57 --> Language Class Initialized
ERROR - 2023-09-26 11:40:57 --> 404 Page Not Found: Wordpress/wp-includes
ERROR - 2023-09-26 11:40:57 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-26 11:40:57 --> Config Class Initialized
INFO - 2023-09-26 11:40:57 --> Hooks Class Initialized
DEBUG - 2023-09-26 11:40:57 --> UTF-8 Support Enabled
INFO - 2023-09-26 11:40:57 --> Utf8 Class Initialized
INFO - 2023-09-26 11:40:57 --> URI Class Initialized
INFO - 2023-09-26 11:40:57 --> Router Class Initialized
INFO - 2023-09-26 11:40:57 --> Output Class Initialized
INFO - 2023-09-26 11:40:57 --> Security Class Initialized
DEBUG - 2023-09-26 11:40:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-26 11:40:57 --> Input Class Initialized
INFO - 2023-09-26 11:40:57 --> Language Class Initialized
ERROR - 2023-09-26 11:40:57 --> 404 Page Not Found: Website/wp-includes
ERROR - 2023-09-26 11:40:57 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-26 11:40:57 --> Config Class Initialized
INFO - 2023-09-26 11:40:57 --> Hooks Class Initialized
DEBUG - 2023-09-26 11:40:57 --> UTF-8 Support Enabled
INFO - 2023-09-26 11:40:57 --> Utf8 Class Initialized
INFO - 2023-09-26 11:40:57 --> URI Class Initialized
INFO - 2023-09-26 11:40:57 --> Router Class Initialized
INFO - 2023-09-26 11:40:57 --> Output Class Initialized
INFO - 2023-09-26 11:40:57 --> Security Class Initialized
DEBUG - 2023-09-26 11:40:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-26 11:40:57 --> Input Class Initialized
INFO - 2023-09-26 11:40:57 --> Language Class Initialized
ERROR - 2023-09-26 11:40:57 --> 404 Page Not Found: Wp/wp-includes
ERROR - 2023-09-26 11:40:58 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-26 11:40:58 --> Config Class Initialized
INFO - 2023-09-26 11:40:58 --> Hooks Class Initialized
DEBUG - 2023-09-26 11:40:58 --> UTF-8 Support Enabled
INFO - 2023-09-26 11:40:58 --> Utf8 Class Initialized
INFO - 2023-09-26 11:40:58 --> URI Class Initialized
INFO - 2023-09-26 11:40:58 --> Router Class Initialized
INFO - 2023-09-26 11:40:58 --> Output Class Initialized
INFO - 2023-09-26 11:40:58 --> Security Class Initialized
DEBUG - 2023-09-26 11:40:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-26 11:40:58 --> Input Class Initialized
INFO - 2023-09-26 11:40:58 --> Language Class Initialized
ERROR - 2023-09-26 11:40:58 --> 404 Page Not Found: News/wp-includes
ERROR - 2023-09-26 11:40:58 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-26 11:40:58 --> Config Class Initialized
INFO - 2023-09-26 11:40:58 --> Hooks Class Initialized
DEBUG - 2023-09-26 11:40:58 --> UTF-8 Support Enabled
INFO - 2023-09-26 11:40:58 --> Utf8 Class Initialized
INFO - 2023-09-26 11:40:58 --> URI Class Initialized
INFO - 2023-09-26 11:40:58 --> Router Class Initialized
INFO - 2023-09-26 11:40:58 --> Output Class Initialized
INFO - 2023-09-26 11:40:58 --> Security Class Initialized
DEBUG - 2023-09-26 11:40:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-26 11:40:58 --> Input Class Initialized
INFO - 2023-09-26 11:40:58 --> Language Class Initialized
ERROR - 2023-09-26 11:40:58 --> 404 Page Not Found: 2020/wp-includes
ERROR - 2023-09-26 11:40:58 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-26 11:40:58 --> Config Class Initialized
INFO - 2023-09-26 11:40:58 --> Hooks Class Initialized
DEBUG - 2023-09-26 11:40:58 --> UTF-8 Support Enabled
INFO - 2023-09-26 11:40:58 --> Utf8 Class Initialized
INFO - 2023-09-26 11:40:58 --> URI Class Initialized
INFO - 2023-09-26 11:40:58 --> Router Class Initialized
INFO - 2023-09-26 11:40:58 --> Output Class Initialized
INFO - 2023-09-26 11:40:58 --> Security Class Initialized
DEBUG - 2023-09-26 11:40:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-26 11:40:58 --> Input Class Initialized
INFO - 2023-09-26 11:40:58 --> Language Class Initialized
ERROR - 2023-09-26 11:40:58 --> 404 Page Not Found: 2019/wp-includes
ERROR - 2023-09-26 11:40:58 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-26 11:40:58 --> Config Class Initialized
INFO - 2023-09-26 11:40:58 --> Hooks Class Initialized
DEBUG - 2023-09-26 11:40:58 --> UTF-8 Support Enabled
INFO - 2023-09-26 11:40:58 --> Utf8 Class Initialized
INFO - 2023-09-26 11:40:58 --> URI Class Initialized
INFO - 2023-09-26 11:40:58 --> Router Class Initialized
INFO - 2023-09-26 11:40:58 --> Output Class Initialized
INFO - 2023-09-26 11:40:58 --> Security Class Initialized
DEBUG - 2023-09-26 11:40:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-26 11:40:58 --> Input Class Initialized
INFO - 2023-09-26 11:40:58 --> Language Class Initialized
ERROR - 2023-09-26 11:40:58 --> 404 Page Not Found: Shop/wp-includes
ERROR - 2023-09-26 11:40:58 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-26 11:40:58 --> Config Class Initialized
INFO - 2023-09-26 11:40:58 --> Hooks Class Initialized
DEBUG - 2023-09-26 11:40:58 --> UTF-8 Support Enabled
INFO - 2023-09-26 11:40:58 --> Utf8 Class Initialized
INFO - 2023-09-26 11:40:58 --> URI Class Initialized
INFO - 2023-09-26 11:40:58 --> Router Class Initialized
INFO - 2023-09-26 11:40:58 --> Output Class Initialized
INFO - 2023-09-26 11:40:58 --> Security Class Initialized
DEBUG - 2023-09-26 11:40:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-26 11:40:58 --> Input Class Initialized
INFO - 2023-09-26 11:40:58 --> Language Class Initialized
ERROR - 2023-09-26 11:40:58 --> 404 Page Not Found: Wp1/wp-includes
ERROR - 2023-09-26 11:40:59 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-26 11:40:59 --> Config Class Initialized
INFO - 2023-09-26 11:40:59 --> Hooks Class Initialized
DEBUG - 2023-09-26 11:40:59 --> UTF-8 Support Enabled
INFO - 2023-09-26 11:40:59 --> Utf8 Class Initialized
INFO - 2023-09-26 11:40:59 --> URI Class Initialized
INFO - 2023-09-26 11:40:59 --> Router Class Initialized
INFO - 2023-09-26 11:40:59 --> Output Class Initialized
INFO - 2023-09-26 11:40:59 --> Security Class Initialized
DEBUG - 2023-09-26 11:40:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-26 11:40:59 --> Input Class Initialized
INFO - 2023-09-26 11:40:59 --> Language Class Initialized
ERROR - 2023-09-26 11:40:59 --> 404 Page Not Found: Test/wp-includes
ERROR - 2023-09-26 11:40:59 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-26 11:40:59 --> Config Class Initialized
INFO - 2023-09-26 11:40:59 --> Hooks Class Initialized
DEBUG - 2023-09-26 11:40:59 --> UTF-8 Support Enabled
INFO - 2023-09-26 11:40:59 --> Utf8 Class Initialized
INFO - 2023-09-26 11:40:59 --> URI Class Initialized
INFO - 2023-09-26 11:40:59 --> Router Class Initialized
INFO - 2023-09-26 11:40:59 --> Output Class Initialized
INFO - 2023-09-26 11:40:59 --> Security Class Initialized
DEBUG - 2023-09-26 11:40:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-26 11:40:59 --> Input Class Initialized
INFO - 2023-09-26 11:40:59 --> Language Class Initialized
ERROR - 2023-09-26 11:40:59 --> 404 Page Not Found: Wp2/wp-includes
ERROR - 2023-09-26 11:40:59 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-26 11:40:59 --> Config Class Initialized
INFO - 2023-09-26 11:40:59 --> Hooks Class Initialized
DEBUG - 2023-09-26 11:40:59 --> UTF-8 Support Enabled
INFO - 2023-09-26 11:40:59 --> Utf8 Class Initialized
INFO - 2023-09-26 11:40:59 --> URI Class Initialized
INFO - 2023-09-26 11:40:59 --> Router Class Initialized
INFO - 2023-09-26 11:40:59 --> Output Class Initialized
INFO - 2023-09-26 11:40:59 --> Security Class Initialized
DEBUG - 2023-09-26 11:40:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-26 11:40:59 --> Input Class Initialized
INFO - 2023-09-26 11:40:59 --> Language Class Initialized
ERROR - 2023-09-26 11:40:59 --> 404 Page Not Found: Site/wp-includes
ERROR - 2023-09-26 11:40:59 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-26 11:40:59 --> Config Class Initialized
INFO - 2023-09-26 11:40:59 --> Hooks Class Initialized
DEBUG - 2023-09-26 11:40:59 --> UTF-8 Support Enabled
INFO - 2023-09-26 11:40:59 --> Utf8 Class Initialized
INFO - 2023-09-26 11:40:59 --> URI Class Initialized
INFO - 2023-09-26 11:40:59 --> Router Class Initialized
INFO - 2023-09-26 11:40:59 --> Output Class Initialized
INFO - 2023-09-26 11:40:59 --> Security Class Initialized
DEBUG - 2023-09-26 11:40:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-26 11:40:59 --> Input Class Initialized
INFO - 2023-09-26 11:40:59 --> Language Class Initialized
ERROR - 2023-09-26 11:40:59 --> 404 Page Not Found: Cms/wp-includes
ERROR - 2023-09-26 11:40:59 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-26 11:40:59 --> Config Class Initialized
INFO - 2023-09-26 11:40:59 --> Hooks Class Initialized
DEBUG - 2023-09-26 11:40:59 --> UTF-8 Support Enabled
INFO - 2023-09-26 11:40:59 --> Utf8 Class Initialized
INFO - 2023-09-26 11:40:59 --> URI Class Initialized
INFO - 2023-09-26 11:40:59 --> Router Class Initialized
INFO - 2023-09-26 11:40:59 --> Output Class Initialized
INFO - 2023-09-26 11:40:59 --> Security Class Initialized
DEBUG - 2023-09-26 11:40:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-26 11:40:59 --> Input Class Initialized
INFO - 2023-09-26 11:40:59 --> Language Class Initialized
ERROR - 2023-09-26 11:40:59 --> 404 Page Not Found: Sito/wp-includes
ERROR - 2023-09-26 12:34:37 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-26 12:34:37 --> Config Class Initialized
INFO - 2023-09-26 12:34:37 --> Hooks Class Initialized
DEBUG - 2023-09-26 12:34:37 --> UTF-8 Support Enabled
INFO - 2023-09-26 12:34:37 --> Utf8 Class Initialized
INFO - 2023-09-26 12:34:37 --> URI Class Initialized
DEBUG - 2023-09-26 12:34:37 --> No URI present. Default controller set.
INFO - 2023-09-26 12:34:37 --> Router Class Initialized
INFO - 2023-09-26 12:34:37 --> Output Class Initialized
INFO - 2023-09-26 12:34:37 --> Security Class Initialized
DEBUG - 2023-09-26 12:34:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-26 12:34:37 --> Input Class Initialized
INFO - 2023-09-26 12:34:37 --> Language Class Initialized
INFO - 2023-09-26 12:34:37 --> Loader Class Initialized
INFO - 2023-09-26 12:34:37 --> Helper loaded: url_helper
INFO - 2023-09-26 12:34:37 --> Helper loaded: file_helper
INFO - 2023-09-26 12:34:37 --> Helper loaded: html_helper
INFO - 2023-09-26 12:34:37 --> Helper loaded: text_helper
INFO - 2023-09-26 12:34:37 --> Helper loaded: form_helper
INFO - 2023-09-26 12:34:37 --> Helper loaded: lang_helper
INFO - 2023-09-26 12:34:37 --> Helper loaded: security_helper
INFO - 2023-09-26 12:34:37 --> Helper loaded: cookie_helper
INFO - 2023-09-26 12:34:37 --> Database Driver Class Initialized
INFO - 2023-09-26 12:34:37 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-26 12:34:37 --> Parser Class Initialized
INFO - 2023-09-26 12:34:37 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-26 12:34:37 --> Pagination Class Initialized
INFO - 2023-09-26 12:34:37 --> Form Validation Class Initialized
INFO - 2023-09-26 12:34:37 --> Controller Class Initialized
INFO - 2023-09-26 12:34:37 --> Model Class Initialized
DEBUG - 2023-09-26 12:34:37 --> Session class already loaded. Second attempt ignored.
ERROR - 2023-09-26 12:34:37 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-26 12:34:37 --> Config Class Initialized
INFO - 2023-09-26 12:34:37 --> Hooks Class Initialized
DEBUG - 2023-09-26 12:34:37 --> UTF-8 Support Enabled
INFO - 2023-09-26 12:34:37 --> Utf8 Class Initialized
INFO - 2023-09-26 12:34:37 --> URI Class Initialized
INFO - 2023-09-26 12:34:37 --> Router Class Initialized
INFO - 2023-09-26 12:34:37 --> Output Class Initialized
INFO - 2023-09-26 12:34:37 --> Security Class Initialized
DEBUG - 2023-09-26 12:34:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-26 12:34:37 --> Input Class Initialized
INFO - 2023-09-26 12:34:37 --> Language Class Initialized
INFO - 2023-09-26 12:34:37 --> Loader Class Initialized
INFO - 2023-09-26 12:34:37 --> Helper loaded: url_helper
INFO - 2023-09-26 12:34:37 --> Helper loaded: file_helper
INFO - 2023-09-26 12:34:37 --> Helper loaded: html_helper
INFO - 2023-09-26 12:34:37 --> Helper loaded: text_helper
INFO - 2023-09-26 12:34:37 --> Helper loaded: form_helper
INFO - 2023-09-26 12:34:37 --> Helper loaded: lang_helper
INFO - 2023-09-26 12:34:37 --> Helper loaded: security_helper
INFO - 2023-09-26 12:34:37 --> Helper loaded: cookie_helper
INFO - 2023-09-26 12:34:37 --> Database Driver Class Initialized
INFO - 2023-09-26 12:34:37 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-26 12:34:37 --> Parser Class Initialized
INFO - 2023-09-26 12:34:37 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-26 12:34:37 --> Pagination Class Initialized
INFO - 2023-09-26 12:34:37 --> Form Validation Class Initialized
INFO - 2023-09-26 12:34:37 --> Controller Class Initialized
INFO - 2023-09-26 12:34:37 --> Model Class Initialized
DEBUG - 2023-09-26 12:34:37 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-26 12:34:37 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2023-09-26 12:34:37 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-09-26 12:34:37 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-09-26 12:34:37 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-09-26 12:34:37 --> Model Class Initialized
INFO - 2023-09-26 12:34:37 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-09-26 12:34:37 --> Final output sent to browser
DEBUG - 2023-09-26 12:34:37 --> Total execution time: 0.0373
ERROR - 2023-09-26 13:12:10 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-26 13:12:10 --> Config Class Initialized
INFO - 2023-09-26 13:12:10 --> Hooks Class Initialized
DEBUG - 2023-09-26 13:12:10 --> UTF-8 Support Enabled
INFO - 2023-09-26 13:12:10 --> Utf8 Class Initialized
INFO - 2023-09-26 13:12:10 --> URI Class Initialized
INFO - 2023-09-26 13:12:10 --> Router Class Initialized
INFO - 2023-09-26 13:12:10 --> Output Class Initialized
INFO - 2023-09-26 13:12:10 --> Security Class Initialized
DEBUG - 2023-09-26 13:12:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-26 13:12:10 --> Input Class Initialized
INFO - 2023-09-26 13:12:10 --> Language Class Initialized
ERROR - 2023-09-26 13:12:10 --> 404 Page Not Found: Wp-loginphp/index
ERROR - 2023-09-26 13:12:10 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-26 13:12:10 --> Config Class Initialized
INFO - 2023-09-26 13:12:10 --> Hooks Class Initialized
DEBUG - 2023-09-26 13:12:10 --> UTF-8 Support Enabled
INFO - 2023-09-26 13:12:10 --> Utf8 Class Initialized
INFO - 2023-09-26 13:12:10 --> URI Class Initialized
INFO - 2023-09-26 13:12:10 --> Router Class Initialized
INFO - 2023-09-26 13:12:10 --> Output Class Initialized
INFO - 2023-09-26 13:12:10 --> Security Class Initialized
DEBUG - 2023-09-26 13:12:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-26 13:12:10 --> Input Class Initialized
INFO - 2023-09-26 13:12:10 --> Language Class Initialized
ERROR - 2023-09-26 13:12:10 --> 404 Page Not Found: Env/index
ERROR - 2023-09-26 13:19:00 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-26 13:19:00 --> Config Class Initialized
INFO - 2023-09-26 13:19:00 --> Hooks Class Initialized
DEBUG - 2023-09-26 13:19:00 --> UTF-8 Support Enabled
INFO - 2023-09-26 13:19:00 --> Utf8 Class Initialized
INFO - 2023-09-26 13:19:00 --> URI Class Initialized
INFO - 2023-09-26 13:19:00 --> Router Class Initialized
INFO - 2023-09-26 13:19:00 --> Output Class Initialized
INFO - 2023-09-26 13:19:00 --> Security Class Initialized
DEBUG - 2023-09-26 13:19:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-26 13:19:00 --> Input Class Initialized
INFO - 2023-09-26 13:19:00 --> Language Class Initialized
ERROR - 2023-09-26 13:19:00 --> 404 Page Not Found: Wp-loginphp/index
ERROR - 2023-09-26 13:19:00 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-26 13:19:00 --> Config Class Initialized
INFO - 2023-09-26 13:19:00 --> Hooks Class Initialized
DEBUG - 2023-09-26 13:19:00 --> UTF-8 Support Enabled
INFO - 2023-09-26 13:19:00 --> Utf8 Class Initialized
INFO - 2023-09-26 13:19:00 --> URI Class Initialized
INFO - 2023-09-26 13:19:00 --> Router Class Initialized
INFO - 2023-09-26 13:19:00 --> Output Class Initialized
INFO - 2023-09-26 13:19:00 --> Security Class Initialized
DEBUG - 2023-09-26 13:19:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-26 13:19:00 --> Input Class Initialized
INFO - 2023-09-26 13:19:00 --> Language Class Initialized
ERROR - 2023-09-26 13:19:00 --> 404 Page Not Found: Env/index
ERROR - 2023-09-26 13:30:17 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-26 13:30:17 --> Config Class Initialized
INFO - 2023-09-26 13:30:17 --> Hooks Class Initialized
DEBUG - 2023-09-26 13:30:17 --> UTF-8 Support Enabled
INFO - 2023-09-26 13:30:17 --> Utf8 Class Initialized
INFO - 2023-09-26 13:30:17 --> URI Class Initialized
INFO - 2023-09-26 13:30:17 --> Router Class Initialized
INFO - 2023-09-26 13:30:17 --> Output Class Initialized
INFO - 2023-09-26 13:30:17 --> Security Class Initialized
DEBUG - 2023-09-26 13:30:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-26 13:30:17 --> Input Class Initialized
INFO - 2023-09-26 13:30:17 --> Language Class Initialized
ERROR - 2023-09-26 13:30:17 --> 404 Page Not Found: Wp-loginphp/index
ERROR - 2023-09-26 13:30:17 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-26 13:30:17 --> Config Class Initialized
INFO - 2023-09-26 13:30:17 --> Hooks Class Initialized
DEBUG - 2023-09-26 13:30:17 --> UTF-8 Support Enabled
INFO - 2023-09-26 13:30:17 --> Utf8 Class Initialized
INFO - 2023-09-26 13:30:17 --> URI Class Initialized
INFO - 2023-09-26 13:30:17 --> Router Class Initialized
INFO - 2023-09-26 13:30:17 --> Output Class Initialized
INFO - 2023-09-26 13:30:17 --> Security Class Initialized
DEBUG - 2023-09-26 13:30:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-26 13:30:17 --> Input Class Initialized
INFO - 2023-09-26 13:30:17 --> Language Class Initialized
ERROR - 2023-09-26 13:30:17 --> 404 Page Not Found: Env/index
ERROR - 2023-09-26 16:23:15 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-26 16:23:15 --> Config Class Initialized
INFO - 2023-09-26 16:23:15 --> Hooks Class Initialized
DEBUG - 2023-09-26 16:23:15 --> UTF-8 Support Enabled
INFO - 2023-09-26 16:23:15 --> Utf8 Class Initialized
INFO - 2023-09-26 16:23:15 --> URI Class Initialized
DEBUG - 2023-09-26 16:23:15 --> No URI present. Default controller set.
INFO - 2023-09-26 16:23:15 --> Router Class Initialized
INFO - 2023-09-26 16:23:15 --> Output Class Initialized
INFO - 2023-09-26 16:23:15 --> Security Class Initialized
DEBUG - 2023-09-26 16:23:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-26 16:23:15 --> Input Class Initialized
INFO - 2023-09-26 16:23:15 --> Language Class Initialized
INFO - 2023-09-26 16:23:15 --> Loader Class Initialized
INFO - 2023-09-26 16:23:15 --> Helper loaded: url_helper
INFO - 2023-09-26 16:23:15 --> Helper loaded: file_helper
INFO - 2023-09-26 16:23:15 --> Helper loaded: html_helper
INFO - 2023-09-26 16:23:15 --> Helper loaded: text_helper
INFO - 2023-09-26 16:23:15 --> Helper loaded: form_helper
INFO - 2023-09-26 16:23:15 --> Helper loaded: lang_helper
INFO - 2023-09-26 16:23:15 --> Helper loaded: security_helper
INFO - 2023-09-26 16:23:15 --> Helper loaded: cookie_helper
INFO - 2023-09-26 16:23:15 --> Database Driver Class Initialized
INFO - 2023-09-26 16:23:15 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-26 16:23:15 --> Parser Class Initialized
INFO - 2023-09-26 16:23:15 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-26 16:23:15 --> Pagination Class Initialized
INFO - 2023-09-26 16:23:15 --> Form Validation Class Initialized
INFO - 2023-09-26 16:23:15 --> Controller Class Initialized
INFO - 2023-09-26 16:23:15 --> Model Class Initialized
DEBUG - 2023-09-26 16:23:15 --> Session class already loaded. Second attempt ignored.
ERROR - 2023-09-26 18:01:57 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-26 18:01:57 --> Config Class Initialized
INFO - 2023-09-26 18:01:57 --> Hooks Class Initialized
DEBUG - 2023-09-26 18:01:57 --> UTF-8 Support Enabled
INFO - 2023-09-26 18:01:57 --> Utf8 Class Initialized
INFO - 2023-09-26 18:01:57 --> URI Class Initialized
DEBUG - 2023-09-26 18:01:57 --> No URI present. Default controller set.
INFO - 2023-09-26 18:01:57 --> Router Class Initialized
INFO - 2023-09-26 18:01:57 --> Output Class Initialized
INFO - 2023-09-26 18:01:57 --> Security Class Initialized
DEBUG - 2023-09-26 18:01:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-26 18:01:57 --> Input Class Initialized
INFO - 2023-09-26 18:01:57 --> Language Class Initialized
INFO - 2023-09-26 18:01:57 --> Loader Class Initialized
INFO - 2023-09-26 18:01:57 --> Helper loaded: url_helper
INFO - 2023-09-26 18:01:57 --> Helper loaded: file_helper
INFO - 2023-09-26 18:01:57 --> Helper loaded: html_helper
INFO - 2023-09-26 18:01:57 --> Helper loaded: text_helper
INFO - 2023-09-26 18:01:57 --> Helper loaded: form_helper
INFO - 2023-09-26 18:01:57 --> Helper loaded: lang_helper
INFO - 2023-09-26 18:01:57 --> Helper loaded: security_helper
INFO - 2023-09-26 18:01:57 --> Helper loaded: cookie_helper
INFO - 2023-09-26 18:01:57 --> Database Driver Class Initialized
INFO - 2023-09-26 18:01:57 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-26 18:01:57 --> Parser Class Initialized
INFO - 2023-09-26 18:01:57 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-26 18:01:57 --> Pagination Class Initialized
INFO - 2023-09-26 18:01:57 --> Form Validation Class Initialized
INFO - 2023-09-26 18:01:57 --> Controller Class Initialized
INFO - 2023-09-26 18:01:57 --> Model Class Initialized
DEBUG - 2023-09-26 18:01:57 --> Session class already loaded. Second attempt ignored.
ERROR - 2023-09-26 18:01:57 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-26 18:01:57 --> Config Class Initialized
INFO - 2023-09-26 18:01:57 --> Hooks Class Initialized
DEBUG - 2023-09-26 18:01:57 --> UTF-8 Support Enabled
INFO - 2023-09-26 18:01:57 --> Utf8 Class Initialized
INFO - 2023-09-26 18:01:57 --> URI Class Initialized
INFO - 2023-09-26 18:01:57 --> Router Class Initialized
INFO - 2023-09-26 18:01:57 --> Output Class Initialized
INFO - 2023-09-26 18:01:57 --> Security Class Initialized
DEBUG - 2023-09-26 18:01:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-26 18:01:57 --> Input Class Initialized
INFO - 2023-09-26 18:01:57 --> Language Class Initialized
INFO - 2023-09-26 18:01:57 --> Loader Class Initialized
INFO - 2023-09-26 18:01:57 --> Helper loaded: url_helper
INFO - 2023-09-26 18:01:57 --> Helper loaded: file_helper
INFO - 2023-09-26 18:01:57 --> Helper loaded: html_helper
INFO - 2023-09-26 18:01:57 --> Helper loaded: text_helper
INFO - 2023-09-26 18:01:57 --> Helper loaded: form_helper
INFO - 2023-09-26 18:01:57 --> Helper loaded: lang_helper
INFO - 2023-09-26 18:01:57 --> Helper loaded: security_helper
INFO - 2023-09-26 18:01:57 --> Helper loaded: cookie_helper
INFO - 2023-09-26 18:01:57 --> Database Driver Class Initialized
INFO - 2023-09-26 18:01:57 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-26 18:01:57 --> Parser Class Initialized
INFO - 2023-09-26 18:01:57 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-26 18:01:57 --> Pagination Class Initialized
INFO - 2023-09-26 18:01:57 --> Form Validation Class Initialized
INFO - 2023-09-26 18:01:57 --> Controller Class Initialized
INFO - 2023-09-26 18:01:57 --> Model Class Initialized
DEBUG - 2023-09-26 18:01:57 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-26 18:01:57 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2023-09-26 18:01:57 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-09-26 18:01:57 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-09-26 18:01:57 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-09-26 18:01:57 --> Model Class Initialized
INFO - 2023-09-26 18:01:57 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-09-26 18:01:57 --> Final output sent to browser
DEBUG - 2023-09-26 18:01:57 --> Total execution time: 0.0361
ERROR - 2023-09-26 18:02:41 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-26 18:02:41 --> Config Class Initialized
INFO - 2023-09-26 18:02:41 --> Hooks Class Initialized
DEBUG - 2023-09-26 18:02:41 --> UTF-8 Support Enabled
INFO - 2023-09-26 18:02:41 --> Utf8 Class Initialized
INFO - 2023-09-26 18:02:41 --> URI Class Initialized
DEBUG - 2023-09-26 18:02:41 --> No URI present. Default controller set.
INFO - 2023-09-26 18:02:41 --> Router Class Initialized
INFO - 2023-09-26 18:02:41 --> Output Class Initialized
INFO - 2023-09-26 18:02:41 --> Security Class Initialized
DEBUG - 2023-09-26 18:02:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-26 18:02:41 --> Input Class Initialized
INFO - 2023-09-26 18:02:41 --> Language Class Initialized
INFO - 2023-09-26 18:02:41 --> Loader Class Initialized
INFO - 2023-09-26 18:02:41 --> Helper loaded: url_helper
INFO - 2023-09-26 18:02:41 --> Helper loaded: file_helper
INFO - 2023-09-26 18:02:41 --> Helper loaded: html_helper
INFO - 2023-09-26 18:02:41 --> Helper loaded: text_helper
INFO - 2023-09-26 18:02:41 --> Helper loaded: form_helper
INFO - 2023-09-26 18:02:41 --> Helper loaded: lang_helper
INFO - 2023-09-26 18:02:41 --> Helper loaded: security_helper
INFO - 2023-09-26 18:02:41 --> Helper loaded: cookie_helper
INFO - 2023-09-26 18:02:41 --> Database Driver Class Initialized
INFO - 2023-09-26 18:02:41 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-26 18:02:41 --> Parser Class Initialized
INFO - 2023-09-26 18:02:41 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-26 18:02:41 --> Pagination Class Initialized
INFO - 2023-09-26 18:02:41 --> Form Validation Class Initialized
INFO - 2023-09-26 18:02:41 --> Controller Class Initialized
INFO - 2023-09-26 18:02:41 --> Model Class Initialized
DEBUG - 2023-09-26 18:02:41 --> Session class already loaded. Second attempt ignored.
ERROR - 2023-09-26 18:02:43 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-26 18:02:43 --> Config Class Initialized
INFO - 2023-09-26 18:02:43 --> Hooks Class Initialized
DEBUG - 2023-09-26 18:02:43 --> UTF-8 Support Enabled
INFO - 2023-09-26 18:02:43 --> Utf8 Class Initialized
INFO - 2023-09-26 18:02:43 --> URI Class Initialized
INFO - 2023-09-26 18:02:43 --> Router Class Initialized
INFO - 2023-09-26 18:02:43 --> Output Class Initialized
INFO - 2023-09-26 18:02:43 --> Security Class Initialized
DEBUG - 2023-09-26 18:02:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-26 18:02:43 --> Input Class Initialized
INFO - 2023-09-26 18:02:43 --> Language Class Initialized
INFO - 2023-09-26 18:02:43 --> Loader Class Initialized
INFO - 2023-09-26 18:02:43 --> Helper loaded: url_helper
INFO - 2023-09-26 18:02:43 --> Helper loaded: file_helper
INFO - 2023-09-26 18:02:43 --> Helper loaded: html_helper
INFO - 2023-09-26 18:02:43 --> Helper loaded: text_helper
INFO - 2023-09-26 18:02:43 --> Helper loaded: form_helper
INFO - 2023-09-26 18:02:43 --> Helper loaded: lang_helper
INFO - 2023-09-26 18:02:43 --> Helper loaded: security_helper
INFO - 2023-09-26 18:02:43 --> Helper loaded: cookie_helper
INFO - 2023-09-26 18:02:43 --> Database Driver Class Initialized
INFO - 2023-09-26 18:02:43 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-26 18:02:43 --> Parser Class Initialized
INFO - 2023-09-26 18:02:43 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-26 18:02:43 --> Pagination Class Initialized
INFO - 2023-09-26 18:02:43 --> Form Validation Class Initialized
INFO - 2023-09-26 18:02:43 --> Controller Class Initialized
INFO - 2023-09-26 18:02:43 --> Model Class Initialized
DEBUG - 2023-09-26 18:02:43 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-26 18:02:43 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2023-09-26 18:02:43 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-09-26 18:02:43 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-09-26 18:02:43 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-09-26 18:02:43 --> Model Class Initialized
INFO - 2023-09-26 18:02:43 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-09-26 18:02:43 --> Final output sent to browser
DEBUG - 2023-09-26 18:02:43 --> Total execution time: 0.0291
ERROR - 2023-09-26 18:02:46 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-26 18:02:46 --> Config Class Initialized
INFO - 2023-09-26 18:02:46 --> Hooks Class Initialized
DEBUG - 2023-09-26 18:02:46 --> UTF-8 Support Enabled
INFO - 2023-09-26 18:02:46 --> Utf8 Class Initialized
INFO - 2023-09-26 18:02:46 --> URI Class Initialized
INFO - 2023-09-26 18:02:46 --> Router Class Initialized
INFO - 2023-09-26 18:02:46 --> Output Class Initialized
INFO - 2023-09-26 18:02:46 --> Security Class Initialized
DEBUG - 2023-09-26 18:02:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-26 18:02:46 --> Input Class Initialized
INFO - 2023-09-26 18:02:46 --> Language Class Initialized
INFO - 2023-09-26 18:02:46 --> Loader Class Initialized
INFO - 2023-09-26 18:02:46 --> Helper loaded: url_helper
INFO - 2023-09-26 18:02:46 --> Helper loaded: file_helper
INFO - 2023-09-26 18:02:46 --> Helper loaded: html_helper
INFO - 2023-09-26 18:02:46 --> Helper loaded: text_helper
INFO - 2023-09-26 18:02:46 --> Helper loaded: form_helper
INFO - 2023-09-26 18:02:46 --> Helper loaded: lang_helper
INFO - 2023-09-26 18:02:46 --> Helper loaded: security_helper
INFO - 2023-09-26 18:02:46 --> Helper loaded: cookie_helper
INFO - 2023-09-26 18:02:46 --> Database Driver Class Initialized
INFO - 2023-09-26 18:02:46 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-26 18:02:46 --> Parser Class Initialized
INFO - 2023-09-26 18:02:46 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-26 18:02:46 --> Pagination Class Initialized
INFO - 2023-09-26 18:02:46 --> Form Validation Class Initialized
INFO - 2023-09-26 18:02:46 --> Controller Class Initialized
INFO - 2023-09-26 18:02:46 --> Model Class Initialized
DEBUG - 2023-09-26 18:02:46 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-26 18:02:46 --> Model Class Initialized
INFO - 2023-09-26 18:02:46 --> Final output sent to browser
DEBUG - 2023-09-26 18:02:46 --> Total execution time: 0.0185
ERROR - 2023-09-26 18:02:47 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-26 18:02:47 --> Config Class Initialized
INFO - 2023-09-26 18:02:47 --> Hooks Class Initialized
DEBUG - 2023-09-26 18:02:47 --> UTF-8 Support Enabled
INFO - 2023-09-26 18:02:47 --> Utf8 Class Initialized
INFO - 2023-09-26 18:02:47 --> URI Class Initialized
DEBUG - 2023-09-26 18:02:47 --> No URI present. Default controller set.
INFO - 2023-09-26 18:02:47 --> Router Class Initialized
INFO - 2023-09-26 18:02:47 --> Output Class Initialized
INFO - 2023-09-26 18:02:47 --> Security Class Initialized
DEBUG - 2023-09-26 18:02:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-26 18:02:47 --> Input Class Initialized
INFO - 2023-09-26 18:02:47 --> Language Class Initialized
INFO - 2023-09-26 18:02:47 --> Loader Class Initialized
INFO - 2023-09-26 18:02:47 --> Helper loaded: url_helper
INFO - 2023-09-26 18:02:47 --> Helper loaded: file_helper
INFO - 2023-09-26 18:02:47 --> Helper loaded: html_helper
INFO - 2023-09-26 18:02:47 --> Helper loaded: text_helper
INFO - 2023-09-26 18:02:47 --> Helper loaded: form_helper
INFO - 2023-09-26 18:02:47 --> Helper loaded: lang_helper
INFO - 2023-09-26 18:02:47 --> Helper loaded: security_helper
INFO - 2023-09-26 18:02:47 --> Helper loaded: cookie_helper
INFO - 2023-09-26 18:02:47 --> Database Driver Class Initialized
INFO - 2023-09-26 18:02:47 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-26 18:02:47 --> Parser Class Initialized
INFO - 2023-09-26 18:02:47 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-26 18:02:47 --> Pagination Class Initialized
INFO - 2023-09-26 18:02:47 --> Form Validation Class Initialized
INFO - 2023-09-26 18:02:47 --> Controller Class Initialized
INFO - 2023-09-26 18:02:47 --> Model Class Initialized
DEBUG - 2023-09-26 18:02:47 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-26 18:02:47 --> Model Class Initialized
DEBUG - 2023-09-26 18:02:47 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-26 18:02:47 --> Model Class Initialized
INFO - 2023-09-26 18:02:47 --> Model Class Initialized
INFO - 2023-09-26 18:02:47 --> Model Class Initialized
INFO - 2023-09-26 18:02:47 --> Model Class Initialized
DEBUG - 2023-09-26 18:02:47 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-09-26 18:02:47 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-26 18:02:47 --> Model Class Initialized
INFO - 2023-09-26 18:02:47 --> Model Class Initialized
INFO - 2023-09-26 18:02:47 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-09-26 18:02:47 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-09-26 18:02:47 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-09-26 18:02:47 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-09-26 18:02:47 --> Model Class Initialized
INFO - 2023-09-26 18:02:47 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-09-26 18:02:47 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-09-26 18:02:47 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-09-26 18:02:47 --> Final output sent to browser
DEBUG - 2023-09-26 18:02:47 --> Total execution time: 0.2149
ERROR - 2023-09-26 18:02:48 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-26 18:02:48 --> Config Class Initialized
INFO - 2023-09-26 18:02:48 --> Hooks Class Initialized
DEBUG - 2023-09-26 18:02:48 --> UTF-8 Support Enabled
INFO - 2023-09-26 18:02:48 --> Utf8 Class Initialized
INFO - 2023-09-26 18:02:48 --> URI Class Initialized
INFO - 2023-09-26 18:02:48 --> Router Class Initialized
INFO - 2023-09-26 18:02:48 --> Output Class Initialized
INFO - 2023-09-26 18:02:48 --> Security Class Initialized
DEBUG - 2023-09-26 18:02:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-26 18:02:48 --> Input Class Initialized
INFO - 2023-09-26 18:02:48 --> Language Class Initialized
INFO - 2023-09-26 18:02:48 --> Loader Class Initialized
INFO - 2023-09-26 18:02:48 --> Helper loaded: url_helper
INFO - 2023-09-26 18:02:48 --> Helper loaded: file_helper
INFO - 2023-09-26 18:02:48 --> Helper loaded: html_helper
INFO - 2023-09-26 18:02:48 --> Helper loaded: text_helper
INFO - 2023-09-26 18:02:48 --> Helper loaded: form_helper
INFO - 2023-09-26 18:02:48 --> Helper loaded: lang_helper
INFO - 2023-09-26 18:02:48 --> Helper loaded: security_helper
INFO - 2023-09-26 18:02:48 --> Helper loaded: cookie_helper
INFO - 2023-09-26 18:02:48 --> Database Driver Class Initialized
INFO - 2023-09-26 18:02:48 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-26 18:02:48 --> Parser Class Initialized
INFO - 2023-09-26 18:02:48 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-26 18:02:48 --> Pagination Class Initialized
INFO - 2023-09-26 18:02:48 --> Form Validation Class Initialized
INFO - 2023-09-26 18:02:48 --> Controller Class Initialized
DEBUG - 2023-09-26 18:02:48 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-09-26 18:02:48 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-26 18:02:48 --> Model Class Initialized
INFO - 2023-09-26 18:02:48 --> Final output sent to browser
DEBUG - 2023-09-26 18:02:48 --> Total execution time: 0.0131
ERROR - 2023-09-26 18:03:04 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-26 18:03:04 --> Config Class Initialized
INFO - 2023-09-26 18:03:04 --> Hooks Class Initialized
DEBUG - 2023-09-26 18:03:04 --> UTF-8 Support Enabled
INFO - 2023-09-26 18:03:04 --> Utf8 Class Initialized
INFO - 2023-09-26 18:03:04 --> URI Class Initialized
INFO - 2023-09-26 18:03:04 --> Router Class Initialized
INFO - 2023-09-26 18:03:04 --> Output Class Initialized
INFO - 2023-09-26 18:03:04 --> Security Class Initialized
DEBUG - 2023-09-26 18:03:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-26 18:03:04 --> Input Class Initialized
INFO - 2023-09-26 18:03:04 --> Language Class Initialized
INFO - 2023-09-26 18:03:04 --> Loader Class Initialized
INFO - 2023-09-26 18:03:04 --> Helper loaded: url_helper
INFO - 2023-09-26 18:03:04 --> Helper loaded: file_helper
INFO - 2023-09-26 18:03:04 --> Helper loaded: html_helper
INFO - 2023-09-26 18:03:04 --> Helper loaded: text_helper
INFO - 2023-09-26 18:03:04 --> Helper loaded: form_helper
INFO - 2023-09-26 18:03:04 --> Helper loaded: lang_helper
INFO - 2023-09-26 18:03:04 --> Helper loaded: security_helper
INFO - 2023-09-26 18:03:04 --> Helper loaded: cookie_helper
INFO - 2023-09-26 18:03:04 --> Database Driver Class Initialized
INFO - 2023-09-26 18:03:04 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-26 18:03:04 --> Parser Class Initialized
INFO - 2023-09-26 18:03:04 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-26 18:03:04 --> Pagination Class Initialized
INFO - 2023-09-26 18:03:04 --> Form Validation Class Initialized
INFO - 2023-09-26 18:03:04 --> Controller Class Initialized
DEBUG - 2023-09-26 18:03:04 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-09-26 18:03:04 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-26 18:03:04 --> Model Class Initialized
INFO - 2023-09-26 18:03:04 --> Model Class Initialized
DEBUG - 2023-09-26 18:03:04 --> Lmr class already loaded. Second attempt ignored.
INFO - 2023-09-26 18:03:04 --> Model Class Initialized
INFO - 2023-09-26 18:03:04 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/mr/mr.php
DEBUG - 2023-09-26 18:03:04 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-09-26 18:03:04 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-09-26 18:03:04 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-09-26 18:03:04 --> Model Class Initialized
INFO - 2023-09-26 18:03:04 --> Model Class Initialized
INFO - 2023-09-26 18:03:04 --> Model Class Initialized
INFO - 2023-09-26 18:03:04 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-09-26 18:03:04 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-09-26 18:03:04 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-09-26 18:03:04 --> Final output sent to browser
DEBUG - 2023-09-26 18:03:04 --> Total execution time: 0.1327
ERROR - 2023-09-26 18:03:08 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-26 18:03:08 --> Config Class Initialized
INFO - 2023-09-26 18:03:08 --> Hooks Class Initialized
DEBUG - 2023-09-26 18:03:08 --> UTF-8 Support Enabled
INFO - 2023-09-26 18:03:08 --> Utf8 Class Initialized
INFO - 2023-09-26 18:03:08 --> URI Class Initialized
INFO - 2023-09-26 18:03:08 --> Router Class Initialized
INFO - 2023-09-26 18:03:08 --> Output Class Initialized
INFO - 2023-09-26 18:03:08 --> Security Class Initialized
DEBUG - 2023-09-26 18:03:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-26 18:03:08 --> Input Class Initialized
INFO - 2023-09-26 18:03:08 --> Language Class Initialized
INFO - 2023-09-26 18:03:08 --> Loader Class Initialized
INFO - 2023-09-26 18:03:08 --> Helper loaded: url_helper
INFO - 2023-09-26 18:03:08 --> Helper loaded: file_helper
INFO - 2023-09-26 18:03:08 --> Helper loaded: html_helper
INFO - 2023-09-26 18:03:08 --> Helper loaded: text_helper
INFO - 2023-09-26 18:03:08 --> Helper loaded: form_helper
INFO - 2023-09-26 18:03:08 --> Helper loaded: lang_helper
INFO - 2023-09-26 18:03:08 --> Helper loaded: security_helper
INFO - 2023-09-26 18:03:08 --> Helper loaded: cookie_helper
INFO - 2023-09-26 18:03:08 --> Database Driver Class Initialized
INFO - 2023-09-26 18:03:08 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-26 18:03:08 --> Parser Class Initialized
INFO - 2023-09-26 18:03:08 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-26 18:03:08 --> Pagination Class Initialized
INFO - 2023-09-26 18:03:08 --> Form Validation Class Initialized
INFO - 2023-09-26 18:03:08 --> Controller Class Initialized
DEBUG - 2023-09-26 18:03:08 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-09-26 18:03:08 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-26 18:03:08 --> Model Class Initialized
INFO - 2023-09-26 18:03:08 --> Model Class Initialized
INFO - 2023-09-26 18:03:08 --> Final output sent to browser
DEBUG - 2023-09-26 18:03:08 --> Total execution time: 0.0276
ERROR - 2023-09-26 18:15:07 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-26 18:15:07 --> Config Class Initialized
INFO - 2023-09-26 18:15:07 --> Hooks Class Initialized
DEBUG - 2023-09-26 18:15:07 --> UTF-8 Support Enabled
INFO - 2023-09-26 18:15:07 --> Utf8 Class Initialized
INFO - 2023-09-26 18:15:07 --> URI Class Initialized
INFO - 2023-09-26 18:15:07 --> Router Class Initialized
INFO - 2023-09-26 18:15:07 --> Output Class Initialized
INFO - 2023-09-26 18:15:07 --> Security Class Initialized
DEBUG - 2023-09-26 18:15:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-26 18:15:07 --> Input Class Initialized
INFO - 2023-09-26 18:15:07 --> Language Class Initialized
INFO - 2023-09-26 18:15:07 --> Loader Class Initialized
INFO - 2023-09-26 18:15:07 --> Helper loaded: url_helper
INFO - 2023-09-26 18:15:07 --> Helper loaded: file_helper
INFO - 2023-09-26 18:15:07 --> Helper loaded: html_helper
INFO - 2023-09-26 18:15:07 --> Helper loaded: text_helper
INFO - 2023-09-26 18:15:07 --> Helper loaded: form_helper
INFO - 2023-09-26 18:15:07 --> Helper loaded: lang_helper
INFO - 2023-09-26 18:15:07 --> Helper loaded: security_helper
INFO - 2023-09-26 18:15:07 --> Helper loaded: cookie_helper
INFO - 2023-09-26 18:15:07 --> Database Driver Class Initialized
INFO - 2023-09-26 18:15:07 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-26 18:15:07 --> Parser Class Initialized
INFO - 2023-09-26 18:15:07 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-26 18:15:07 --> Pagination Class Initialized
INFO - 2023-09-26 18:15:07 --> Form Validation Class Initialized
INFO - 2023-09-26 18:15:07 --> Controller Class Initialized
INFO - 2023-09-26 18:15:07 --> Model Class Initialized
DEBUG - 2023-09-26 18:15:07 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-09-26 18:15:07 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-26 18:15:07 --> Model Class Initialized
DEBUG - 2023-09-26 18:15:07 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-26 18:15:07 --> Model Class Initialized
INFO - 2023-09-26 18:15:07 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice.php
DEBUG - 2023-09-26 18:15:07 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-09-26 18:15:07 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-09-26 18:15:07 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-09-26 18:15:07 --> Model Class Initialized
INFO - 2023-09-26 18:15:07 --> Model Class Initialized
INFO - 2023-09-26 18:15:07 --> Model Class Initialized
INFO - 2023-09-26 18:15:07 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-09-26 18:15:07 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-09-26 18:15:07 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-09-26 18:15:07 --> Final output sent to browser
DEBUG - 2023-09-26 18:15:07 --> Total execution time: 0.1527
ERROR - 2023-09-26 18:15:08 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-26 18:15:08 --> Config Class Initialized
INFO - 2023-09-26 18:15:08 --> Hooks Class Initialized
DEBUG - 2023-09-26 18:15:08 --> UTF-8 Support Enabled
INFO - 2023-09-26 18:15:08 --> Utf8 Class Initialized
INFO - 2023-09-26 18:15:08 --> URI Class Initialized
INFO - 2023-09-26 18:15:08 --> Router Class Initialized
INFO - 2023-09-26 18:15:08 --> Output Class Initialized
INFO - 2023-09-26 18:15:08 --> Security Class Initialized
DEBUG - 2023-09-26 18:15:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-26 18:15:08 --> Input Class Initialized
INFO - 2023-09-26 18:15:08 --> Language Class Initialized
INFO - 2023-09-26 18:15:08 --> Loader Class Initialized
INFO - 2023-09-26 18:15:08 --> Helper loaded: url_helper
INFO - 2023-09-26 18:15:08 --> Helper loaded: file_helper
INFO - 2023-09-26 18:15:08 --> Helper loaded: html_helper
INFO - 2023-09-26 18:15:08 --> Helper loaded: text_helper
INFO - 2023-09-26 18:15:08 --> Helper loaded: form_helper
INFO - 2023-09-26 18:15:08 --> Helper loaded: lang_helper
INFO - 2023-09-26 18:15:08 --> Helper loaded: security_helper
INFO - 2023-09-26 18:15:08 --> Helper loaded: cookie_helper
INFO - 2023-09-26 18:15:08 --> Database Driver Class Initialized
INFO - 2023-09-26 18:15:08 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-26 18:15:08 --> Parser Class Initialized
INFO - 2023-09-26 18:15:08 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-26 18:15:08 --> Pagination Class Initialized
INFO - 2023-09-26 18:15:08 --> Form Validation Class Initialized
INFO - 2023-09-26 18:15:08 --> Controller Class Initialized
INFO - 2023-09-26 18:15:08 --> Model Class Initialized
DEBUG - 2023-09-26 18:15:08 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-09-26 18:15:08 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-26 18:15:08 --> Model Class Initialized
DEBUG - 2023-09-26 18:15:08 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-26 18:15:08 --> Model Class Initialized
INFO - 2023-09-26 18:15:08 --> Final output sent to browser
DEBUG - 2023-09-26 18:15:08 --> Total execution time: 0.0570
ERROR - 2023-09-26 18:15:11 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-26 18:15:11 --> Config Class Initialized
INFO - 2023-09-26 18:15:11 --> Hooks Class Initialized
DEBUG - 2023-09-26 18:15:11 --> UTF-8 Support Enabled
INFO - 2023-09-26 18:15:11 --> Utf8 Class Initialized
INFO - 2023-09-26 18:15:11 --> URI Class Initialized
INFO - 2023-09-26 18:15:11 --> Router Class Initialized
INFO - 2023-09-26 18:15:11 --> Output Class Initialized
INFO - 2023-09-26 18:15:11 --> Security Class Initialized
DEBUG - 2023-09-26 18:15:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-26 18:15:11 --> Input Class Initialized
INFO - 2023-09-26 18:15:11 --> Language Class Initialized
INFO - 2023-09-26 18:15:11 --> Loader Class Initialized
INFO - 2023-09-26 18:15:11 --> Helper loaded: url_helper
INFO - 2023-09-26 18:15:11 --> Helper loaded: file_helper
INFO - 2023-09-26 18:15:11 --> Helper loaded: html_helper
INFO - 2023-09-26 18:15:11 --> Helper loaded: text_helper
INFO - 2023-09-26 18:15:11 --> Helper loaded: form_helper
INFO - 2023-09-26 18:15:11 --> Helper loaded: lang_helper
INFO - 2023-09-26 18:15:11 --> Helper loaded: security_helper
INFO - 2023-09-26 18:15:11 --> Helper loaded: cookie_helper
INFO - 2023-09-26 18:15:11 --> Database Driver Class Initialized
INFO - 2023-09-26 18:15:11 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-26 18:15:11 --> Parser Class Initialized
INFO - 2023-09-26 18:15:11 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-26 18:15:11 --> Pagination Class Initialized
INFO - 2023-09-26 18:15:11 --> Form Validation Class Initialized
INFO - 2023-09-26 18:15:11 --> Controller Class Initialized
INFO - 2023-09-26 18:15:11 --> Model Class Initialized
DEBUG - 2023-09-26 18:15:11 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-09-26 18:15:11 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-26 18:15:11 --> Model Class Initialized
DEBUG - 2023-09-26 18:15:11 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-26 18:15:11 --> Model Class Initialized
DEBUG - 2023-09-26 18:15:11 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-26 18:15:11 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice_html.php
DEBUG - 2023-09-26 18:15:11 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-09-26 18:15:11 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-09-26 18:15:11 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-09-26 18:15:11 --> Model Class Initialized
INFO - 2023-09-26 18:15:11 --> Model Class Initialized
INFO - 2023-09-26 18:15:11 --> Model Class Initialized
INFO - 2023-09-26 18:15:11 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-09-26 18:15:11 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-09-26 18:15:11 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-09-26 18:15:11 --> Final output sent to browser
DEBUG - 2023-09-26 18:15:11 --> Total execution time: 0.1633
ERROR - 2023-09-26 18:15:45 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-26 18:15:45 --> Config Class Initialized
INFO - 2023-09-26 18:15:45 --> Hooks Class Initialized
DEBUG - 2023-09-26 18:15:45 --> UTF-8 Support Enabled
INFO - 2023-09-26 18:15:45 --> Utf8 Class Initialized
INFO - 2023-09-26 18:15:45 --> URI Class Initialized
INFO - 2023-09-26 18:15:45 --> Router Class Initialized
INFO - 2023-09-26 18:15:45 --> Output Class Initialized
INFO - 2023-09-26 18:15:45 --> Security Class Initialized
DEBUG - 2023-09-26 18:15:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-26 18:15:45 --> Input Class Initialized
INFO - 2023-09-26 18:15:45 --> Language Class Initialized
INFO - 2023-09-26 18:15:45 --> Loader Class Initialized
INFO - 2023-09-26 18:15:45 --> Helper loaded: url_helper
INFO - 2023-09-26 18:15:45 --> Helper loaded: file_helper
INFO - 2023-09-26 18:15:45 --> Helper loaded: html_helper
INFO - 2023-09-26 18:15:45 --> Helper loaded: text_helper
INFO - 2023-09-26 18:15:45 --> Helper loaded: form_helper
INFO - 2023-09-26 18:15:45 --> Helper loaded: lang_helper
INFO - 2023-09-26 18:15:45 --> Helper loaded: security_helper
INFO - 2023-09-26 18:15:45 --> Helper loaded: cookie_helper
INFO - 2023-09-26 18:15:45 --> Database Driver Class Initialized
INFO - 2023-09-26 18:15:45 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-26 18:15:45 --> Parser Class Initialized
INFO - 2023-09-26 18:15:45 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-26 18:15:45 --> Pagination Class Initialized
INFO - 2023-09-26 18:15:45 --> Form Validation Class Initialized
INFO - 2023-09-26 18:15:45 --> Controller Class Initialized
INFO - 2023-09-26 18:15:45 --> Model Class Initialized
DEBUG - 2023-09-26 18:15:45 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-09-26 18:15:45 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-26 18:15:45 --> Model Class Initialized
DEBUG - 2023-09-26 18:15:45 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-26 18:15:45 --> Model Class Initialized
INFO - 2023-09-26 18:15:45 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice.php
DEBUG - 2023-09-26 18:15:45 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-09-26 18:15:45 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-09-26 18:15:45 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-09-26 18:15:45 --> Model Class Initialized
INFO - 2023-09-26 18:15:45 --> Model Class Initialized
INFO - 2023-09-26 18:15:45 --> Model Class Initialized
INFO - 2023-09-26 18:15:45 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-09-26 18:15:45 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-09-26 18:15:45 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-09-26 18:15:45 --> Final output sent to browser
DEBUG - 2023-09-26 18:15:45 --> Total execution time: 0.1531
ERROR - 2023-09-26 18:15:46 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-26 18:15:46 --> Config Class Initialized
INFO - 2023-09-26 18:15:46 --> Hooks Class Initialized
DEBUG - 2023-09-26 18:15:46 --> UTF-8 Support Enabled
INFO - 2023-09-26 18:15:46 --> Utf8 Class Initialized
INFO - 2023-09-26 18:15:46 --> URI Class Initialized
INFO - 2023-09-26 18:15:46 --> Router Class Initialized
INFO - 2023-09-26 18:15:46 --> Output Class Initialized
INFO - 2023-09-26 18:15:46 --> Security Class Initialized
DEBUG - 2023-09-26 18:15:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-26 18:15:46 --> Input Class Initialized
INFO - 2023-09-26 18:15:46 --> Language Class Initialized
INFO - 2023-09-26 18:15:46 --> Loader Class Initialized
INFO - 2023-09-26 18:15:46 --> Helper loaded: url_helper
INFO - 2023-09-26 18:15:46 --> Helper loaded: file_helper
INFO - 2023-09-26 18:15:46 --> Helper loaded: html_helper
INFO - 2023-09-26 18:15:46 --> Helper loaded: text_helper
INFO - 2023-09-26 18:15:46 --> Helper loaded: form_helper
INFO - 2023-09-26 18:15:46 --> Helper loaded: lang_helper
INFO - 2023-09-26 18:15:46 --> Helper loaded: security_helper
INFO - 2023-09-26 18:15:46 --> Helper loaded: cookie_helper
INFO - 2023-09-26 18:15:46 --> Database Driver Class Initialized
INFO - 2023-09-26 18:15:46 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-26 18:15:46 --> Parser Class Initialized
INFO - 2023-09-26 18:15:46 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-26 18:15:46 --> Pagination Class Initialized
INFO - 2023-09-26 18:15:46 --> Form Validation Class Initialized
INFO - 2023-09-26 18:15:46 --> Controller Class Initialized
INFO - 2023-09-26 18:15:46 --> Model Class Initialized
DEBUG - 2023-09-26 18:15:46 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-09-26 18:15:46 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-26 18:15:46 --> Model Class Initialized
DEBUG - 2023-09-26 18:15:46 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-26 18:15:46 --> Model Class Initialized
INFO - 2023-09-26 18:15:46 --> Final output sent to browser
DEBUG - 2023-09-26 18:15:46 --> Total execution time: 0.0521
