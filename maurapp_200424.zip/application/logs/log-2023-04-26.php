<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2023-04-26 09:09:36 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-26 09:09:36 --> Config Class Initialized
INFO - 2023-04-26 09:09:36 --> Hooks Class Initialized
DEBUG - 2023-04-26 09:09:36 --> UTF-8 Support Enabled
INFO - 2023-04-26 09:09:36 --> Utf8 Class Initialized
INFO - 2023-04-26 09:09:36 --> URI Class Initialized
DEBUG - 2023-04-26 09:09:36 --> No URI present. Default controller set.
INFO - 2023-04-26 09:09:36 --> Router Class Initialized
INFO - 2023-04-26 09:09:36 --> Output Class Initialized
INFO - 2023-04-26 09:09:36 --> Security Class Initialized
DEBUG - 2023-04-26 09:09:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-26 09:09:36 --> Input Class Initialized
INFO - 2023-04-26 09:09:36 --> Language Class Initialized
INFO - 2023-04-26 09:09:36 --> Loader Class Initialized
INFO - 2023-04-26 09:09:36 --> Helper loaded: url_helper
INFO - 2023-04-26 09:09:36 --> Helper loaded: file_helper
INFO - 2023-04-26 09:09:36 --> Helper loaded: html_helper
INFO - 2023-04-26 09:09:36 --> Helper loaded: text_helper
INFO - 2023-04-26 09:09:36 --> Helper loaded: form_helper
INFO - 2023-04-26 09:09:36 --> Helper loaded: lang_helper
INFO - 2023-04-26 09:09:36 --> Helper loaded: security_helper
INFO - 2023-04-26 09:09:36 --> Helper loaded: cookie_helper
INFO - 2023-04-26 09:09:36 --> Database Driver Class Initialized
INFO - 2023-04-26 09:09:36 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-26 09:09:36 --> Parser Class Initialized
INFO - 2023-04-26 09:09:36 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-26 09:09:36 --> Pagination Class Initialized
INFO - 2023-04-26 09:09:36 --> Form Validation Class Initialized
INFO - 2023-04-26 09:09:36 --> Controller Class Initialized
INFO - 2023-04-26 09:09:36 --> Model Class Initialized
DEBUG - 2023-04-26 09:09:36 --> Session class already loaded. Second attempt ignored.
ERROR - 2023-04-26 09:09:37 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-26 09:09:37 --> Config Class Initialized
INFO - 2023-04-26 09:09:37 --> Hooks Class Initialized
DEBUG - 2023-04-26 09:09:37 --> UTF-8 Support Enabled
INFO - 2023-04-26 09:09:37 --> Utf8 Class Initialized
INFO - 2023-04-26 09:09:37 --> URI Class Initialized
INFO - 2023-04-26 09:09:37 --> Router Class Initialized
INFO - 2023-04-26 09:09:37 --> Output Class Initialized
INFO - 2023-04-26 09:09:37 --> Security Class Initialized
DEBUG - 2023-04-26 09:09:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-26 09:09:37 --> Input Class Initialized
INFO - 2023-04-26 09:09:37 --> Language Class Initialized
INFO - 2023-04-26 09:09:37 --> Loader Class Initialized
INFO - 2023-04-26 09:09:37 --> Helper loaded: url_helper
INFO - 2023-04-26 09:09:37 --> Helper loaded: file_helper
INFO - 2023-04-26 09:09:37 --> Helper loaded: html_helper
INFO - 2023-04-26 09:09:37 --> Helper loaded: text_helper
INFO - 2023-04-26 09:09:37 --> Helper loaded: form_helper
INFO - 2023-04-26 09:09:37 --> Helper loaded: lang_helper
INFO - 2023-04-26 09:09:37 --> Helper loaded: security_helper
INFO - 2023-04-26 09:09:37 --> Helper loaded: cookie_helper
INFO - 2023-04-26 09:09:37 --> Database Driver Class Initialized
INFO - 2023-04-26 09:09:37 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-26 09:09:37 --> Parser Class Initialized
INFO - 2023-04-26 09:09:37 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-26 09:09:37 --> Pagination Class Initialized
INFO - 2023-04-26 09:09:37 --> Form Validation Class Initialized
INFO - 2023-04-26 09:09:37 --> Controller Class Initialized
INFO - 2023-04-26 09:09:37 --> Model Class Initialized
DEBUG - 2023-04-26 09:09:37 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-26 09:09:37 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2023-04-26 09:09:37 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-04-26 09:09:37 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-04-26 09:09:37 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-04-26 09:09:37 --> Model Class Initialized
INFO - 2023-04-26 09:09:37 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-04-26 09:09:37 --> Final output sent to browser
DEBUG - 2023-04-26 09:09:37 --> Total execution time: 0.0351
ERROR - 2023-04-26 09:10:07 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-26 09:10:07 --> Config Class Initialized
INFO - 2023-04-26 09:10:07 --> Hooks Class Initialized
DEBUG - 2023-04-26 09:10:07 --> UTF-8 Support Enabled
INFO - 2023-04-26 09:10:07 --> Utf8 Class Initialized
INFO - 2023-04-26 09:10:07 --> URI Class Initialized
INFO - 2023-04-26 09:10:07 --> Router Class Initialized
INFO - 2023-04-26 09:10:07 --> Output Class Initialized
INFO - 2023-04-26 09:10:07 --> Security Class Initialized
DEBUG - 2023-04-26 09:10:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-26 09:10:07 --> Input Class Initialized
INFO - 2023-04-26 09:10:07 --> Language Class Initialized
INFO - 2023-04-26 09:10:07 --> Loader Class Initialized
INFO - 2023-04-26 09:10:07 --> Helper loaded: url_helper
INFO - 2023-04-26 09:10:07 --> Helper loaded: file_helper
INFO - 2023-04-26 09:10:07 --> Helper loaded: html_helper
INFO - 2023-04-26 09:10:07 --> Helper loaded: text_helper
INFO - 2023-04-26 09:10:07 --> Helper loaded: form_helper
INFO - 2023-04-26 09:10:07 --> Helper loaded: lang_helper
INFO - 2023-04-26 09:10:07 --> Helper loaded: security_helper
INFO - 2023-04-26 09:10:07 --> Helper loaded: cookie_helper
INFO - 2023-04-26 09:10:07 --> Database Driver Class Initialized
INFO - 2023-04-26 09:10:07 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-26 09:10:07 --> Parser Class Initialized
INFO - 2023-04-26 09:10:07 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-26 09:10:07 --> Pagination Class Initialized
INFO - 2023-04-26 09:10:07 --> Form Validation Class Initialized
INFO - 2023-04-26 09:10:07 --> Controller Class Initialized
INFO - 2023-04-26 09:10:07 --> Model Class Initialized
DEBUG - 2023-04-26 09:10:07 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-26 09:10:07 --> Model Class Initialized
INFO - 2023-04-26 09:10:07 --> Final output sent to browser
DEBUG - 2023-04-26 09:10:07 --> Total execution time: 0.0197
ERROR - 2023-04-26 09:10:08 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-26 09:10:08 --> Config Class Initialized
INFO - 2023-04-26 09:10:08 --> Hooks Class Initialized
DEBUG - 2023-04-26 09:10:08 --> UTF-8 Support Enabled
INFO - 2023-04-26 09:10:08 --> Utf8 Class Initialized
INFO - 2023-04-26 09:10:08 --> URI Class Initialized
DEBUG - 2023-04-26 09:10:08 --> No URI present. Default controller set.
INFO - 2023-04-26 09:10:08 --> Router Class Initialized
INFO - 2023-04-26 09:10:08 --> Output Class Initialized
INFO - 2023-04-26 09:10:08 --> Security Class Initialized
DEBUG - 2023-04-26 09:10:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-26 09:10:08 --> Input Class Initialized
INFO - 2023-04-26 09:10:08 --> Language Class Initialized
INFO - 2023-04-26 09:10:08 --> Loader Class Initialized
INFO - 2023-04-26 09:10:08 --> Helper loaded: url_helper
INFO - 2023-04-26 09:10:08 --> Helper loaded: file_helper
INFO - 2023-04-26 09:10:08 --> Helper loaded: html_helper
INFO - 2023-04-26 09:10:08 --> Helper loaded: text_helper
INFO - 2023-04-26 09:10:08 --> Helper loaded: form_helper
INFO - 2023-04-26 09:10:08 --> Helper loaded: lang_helper
INFO - 2023-04-26 09:10:08 --> Helper loaded: security_helper
INFO - 2023-04-26 09:10:08 --> Helper loaded: cookie_helper
INFO - 2023-04-26 09:10:08 --> Database Driver Class Initialized
INFO - 2023-04-26 09:10:08 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-26 09:10:08 --> Parser Class Initialized
INFO - 2023-04-26 09:10:08 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-26 09:10:08 --> Pagination Class Initialized
INFO - 2023-04-26 09:10:08 --> Form Validation Class Initialized
INFO - 2023-04-26 09:10:08 --> Controller Class Initialized
INFO - 2023-04-26 09:10:08 --> Model Class Initialized
DEBUG - 2023-04-26 09:10:08 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-26 09:10:08 --> Model Class Initialized
DEBUG - 2023-04-26 09:10:08 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-26 09:10:08 --> Model Class Initialized
INFO - 2023-04-26 09:10:08 --> Model Class Initialized
INFO - 2023-04-26 09:10:08 --> Model Class Initialized
INFO - 2023-04-26 09:10:08 --> Model Class Initialized
DEBUG - 2023-04-26 09:10:08 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-04-26 09:10:08 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-26 09:10:08 --> Model Class Initialized
INFO - 2023-04-26 09:10:08 --> Model Class Initialized
INFO - 2023-04-26 09:10:08 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-04-26 09:10:08 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-04-26 09:10:08 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-04-26 09:10:08 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-04-26 09:10:08 --> Model Class Initialized
INFO - 2023-04-26 09:10:08 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-04-26 09:10:08 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-04-26 09:10:08 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-04-26 09:10:08 --> Final output sent to browser
DEBUG - 2023-04-26 09:10:08 --> Total execution time: 0.1950
ERROR - 2023-04-26 09:10:09 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-26 09:10:09 --> Config Class Initialized
INFO - 2023-04-26 09:10:09 --> Hooks Class Initialized
DEBUG - 2023-04-26 09:10:09 --> UTF-8 Support Enabled
INFO - 2023-04-26 09:10:09 --> Utf8 Class Initialized
INFO - 2023-04-26 09:10:09 --> URI Class Initialized
INFO - 2023-04-26 09:10:09 --> Router Class Initialized
INFO - 2023-04-26 09:10:09 --> Output Class Initialized
INFO - 2023-04-26 09:10:09 --> Security Class Initialized
DEBUG - 2023-04-26 09:10:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-26 09:10:09 --> Input Class Initialized
INFO - 2023-04-26 09:10:09 --> Language Class Initialized
INFO - 2023-04-26 09:10:09 --> Loader Class Initialized
INFO - 2023-04-26 09:10:09 --> Helper loaded: url_helper
INFO - 2023-04-26 09:10:09 --> Helper loaded: file_helper
INFO - 2023-04-26 09:10:09 --> Helper loaded: html_helper
INFO - 2023-04-26 09:10:09 --> Helper loaded: text_helper
INFO - 2023-04-26 09:10:09 --> Helper loaded: form_helper
INFO - 2023-04-26 09:10:09 --> Helper loaded: lang_helper
INFO - 2023-04-26 09:10:09 --> Helper loaded: security_helper
INFO - 2023-04-26 09:10:09 --> Helper loaded: cookie_helper
INFO - 2023-04-26 09:10:09 --> Database Driver Class Initialized
INFO - 2023-04-26 09:10:09 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-26 09:10:09 --> Parser Class Initialized
INFO - 2023-04-26 09:10:09 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-26 09:10:09 --> Pagination Class Initialized
INFO - 2023-04-26 09:10:09 --> Form Validation Class Initialized
INFO - 2023-04-26 09:10:09 --> Controller Class Initialized
DEBUG - 2023-04-26 09:10:09 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-04-26 09:10:09 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-26 09:10:09 --> Model Class Initialized
INFO - 2023-04-26 09:10:09 --> Final output sent to browser
DEBUG - 2023-04-26 09:10:09 --> Total execution time: 0.0128
ERROR - 2023-04-26 09:10:32 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-26 09:10:32 --> Config Class Initialized
INFO - 2023-04-26 09:10:32 --> Hooks Class Initialized
DEBUG - 2023-04-26 09:10:32 --> UTF-8 Support Enabled
INFO - 2023-04-26 09:10:32 --> Utf8 Class Initialized
INFO - 2023-04-26 09:10:32 --> URI Class Initialized
INFO - 2023-04-26 09:10:32 --> Router Class Initialized
INFO - 2023-04-26 09:10:32 --> Output Class Initialized
INFO - 2023-04-26 09:10:32 --> Security Class Initialized
DEBUG - 2023-04-26 09:10:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-26 09:10:32 --> Input Class Initialized
INFO - 2023-04-26 09:10:32 --> Language Class Initialized
INFO - 2023-04-26 09:10:32 --> Loader Class Initialized
INFO - 2023-04-26 09:10:32 --> Helper loaded: url_helper
INFO - 2023-04-26 09:10:32 --> Helper loaded: file_helper
INFO - 2023-04-26 09:10:32 --> Helper loaded: html_helper
INFO - 2023-04-26 09:10:32 --> Helper loaded: text_helper
INFO - 2023-04-26 09:10:32 --> Helper loaded: form_helper
INFO - 2023-04-26 09:10:32 --> Helper loaded: lang_helper
INFO - 2023-04-26 09:10:32 --> Helper loaded: security_helper
INFO - 2023-04-26 09:10:32 --> Helper loaded: cookie_helper
INFO - 2023-04-26 09:10:32 --> Database Driver Class Initialized
INFO - 2023-04-26 09:10:32 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-26 09:10:32 --> Parser Class Initialized
INFO - 2023-04-26 09:10:32 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-26 09:10:32 --> Pagination Class Initialized
INFO - 2023-04-26 09:10:32 --> Form Validation Class Initialized
INFO - 2023-04-26 09:10:32 --> Controller Class Initialized
INFO - 2023-04-26 09:10:32 --> Model Class Initialized
INFO - 2023-04-26 09:10:32 --> Model Class Initialized
INFO - 2023-04-26 09:10:32 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/purchase/purchase.php
DEBUG - 2023-04-26 09:10:32 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-04-26 09:10:32 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-04-26 09:10:32 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-04-26 09:10:32 --> Model Class Initialized
INFO - 2023-04-26 09:10:32 --> Model Class Initialized
INFO - 2023-04-26 09:10:32 --> Model Class Initialized
INFO - 2023-04-26 09:10:33 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-04-26 09:10:33 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-04-26 09:10:33 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-04-26 09:10:33 --> Final output sent to browser
DEBUG - 2023-04-26 09:10:33 --> Total execution time: 0.1626
ERROR - 2023-04-26 09:10:33 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-26 09:10:33 --> Config Class Initialized
INFO - 2023-04-26 09:10:33 --> Hooks Class Initialized
DEBUG - 2023-04-26 09:10:33 --> UTF-8 Support Enabled
INFO - 2023-04-26 09:10:33 --> Utf8 Class Initialized
INFO - 2023-04-26 09:10:33 --> URI Class Initialized
INFO - 2023-04-26 09:10:33 --> Router Class Initialized
INFO - 2023-04-26 09:10:33 --> Output Class Initialized
INFO - 2023-04-26 09:10:33 --> Security Class Initialized
DEBUG - 2023-04-26 09:10:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-26 09:10:33 --> Input Class Initialized
INFO - 2023-04-26 09:10:33 --> Language Class Initialized
INFO - 2023-04-26 09:10:33 --> Loader Class Initialized
INFO - 2023-04-26 09:10:33 --> Helper loaded: url_helper
INFO - 2023-04-26 09:10:33 --> Helper loaded: file_helper
INFO - 2023-04-26 09:10:33 --> Helper loaded: html_helper
INFO - 2023-04-26 09:10:34 --> Helper loaded: text_helper
INFO - 2023-04-26 09:10:34 --> Helper loaded: form_helper
INFO - 2023-04-26 09:10:34 --> Helper loaded: lang_helper
INFO - 2023-04-26 09:10:34 --> Helper loaded: security_helper
INFO - 2023-04-26 09:10:34 --> Helper loaded: cookie_helper
INFO - 2023-04-26 09:10:34 --> Database Driver Class Initialized
INFO - 2023-04-26 09:10:34 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-26 09:10:34 --> Parser Class Initialized
INFO - 2023-04-26 09:10:34 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-26 09:10:34 --> Pagination Class Initialized
INFO - 2023-04-26 09:10:34 --> Form Validation Class Initialized
INFO - 2023-04-26 09:10:34 --> Controller Class Initialized
INFO - 2023-04-26 09:10:34 --> Model Class Initialized
INFO - 2023-04-26 09:10:34 --> Model Class Initialized
INFO - 2023-04-26 09:10:34 --> Final output sent to browser
DEBUG - 2023-04-26 09:10:34 --> Total execution time: 0.0480
ERROR - 2023-04-26 09:10:37 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-26 09:10:37 --> Config Class Initialized
INFO - 2023-04-26 09:10:37 --> Hooks Class Initialized
DEBUG - 2023-04-26 09:10:37 --> UTF-8 Support Enabled
INFO - 2023-04-26 09:10:37 --> Utf8 Class Initialized
INFO - 2023-04-26 09:10:37 --> URI Class Initialized
INFO - 2023-04-26 09:10:37 --> Router Class Initialized
INFO - 2023-04-26 09:10:37 --> Output Class Initialized
INFO - 2023-04-26 09:10:37 --> Security Class Initialized
DEBUG - 2023-04-26 09:10:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-26 09:10:37 --> Input Class Initialized
INFO - 2023-04-26 09:10:37 --> Language Class Initialized
INFO - 2023-04-26 09:10:37 --> Loader Class Initialized
INFO - 2023-04-26 09:10:37 --> Helper loaded: url_helper
INFO - 2023-04-26 09:10:37 --> Helper loaded: file_helper
INFO - 2023-04-26 09:10:37 --> Helper loaded: html_helper
INFO - 2023-04-26 09:10:37 --> Helper loaded: text_helper
INFO - 2023-04-26 09:10:37 --> Helper loaded: form_helper
INFO - 2023-04-26 09:10:37 --> Helper loaded: lang_helper
INFO - 2023-04-26 09:10:37 --> Helper loaded: security_helper
INFO - 2023-04-26 09:10:37 --> Helper loaded: cookie_helper
INFO - 2023-04-26 09:10:37 --> Database Driver Class Initialized
INFO - 2023-04-26 09:10:37 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-26 09:10:37 --> Parser Class Initialized
INFO - 2023-04-26 09:10:37 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-26 09:10:37 --> Pagination Class Initialized
INFO - 2023-04-26 09:10:37 --> Form Validation Class Initialized
INFO - 2023-04-26 09:10:37 --> Controller Class Initialized
INFO - 2023-04-26 09:10:37 --> Model Class Initialized
INFO - 2023-04-26 09:10:37 --> Model Class Initialized
INFO - 2023-04-26 09:10:37 --> Final output sent to browser
DEBUG - 2023-04-26 09:10:37 --> Total execution time: 0.0769
ERROR - 2023-04-26 09:10:45 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-26 09:10:45 --> Config Class Initialized
INFO - 2023-04-26 09:10:45 --> Hooks Class Initialized
DEBUG - 2023-04-26 09:10:45 --> UTF-8 Support Enabled
INFO - 2023-04-26 09:10:45 --> Utf8 Class Initialized
INFO - 2023-04-26 09:10:45 --> URI Class Initialized
INFO - 2023-04-26 09:10:45 --> Router Class Initialized
INFO - 2023-04-26 09:10:45 --> Output Class Initialized
INFO - 2023-04-26 09:10:45 --> Security Class Initialized
DEBUG - 2023-04-26 09:10:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-26 09:10:45 --> Input Class Initialized
INFO - 2023-04-26 09:10:45 --> Language Class Initialized
INFO - 2023-04-26 09:10:45 --> Loader Class Initialized
INFO - 2023-04-26 09:10:45 --> Helper loaded: url_helper
INFO - 2023-04-26 09:10:45 --> Helper loaded: file_helper
INFO - 2023-04-26 09:10:45 --> Helper loaded: html_helper
INFO - 2023-04-26 09:10:45 --> Helper loaded: text_helper
INFO - 2023-04-26 09:10:45 --> Helper loaded: form_helper
INFO - 2023-04-26 09:10:45 --> Helper loaded: lang_helper
INFO - 2023-04-26 09:10:45 --> Helper loaded: security_helper
INFO - 2023-04-26 09:10:45 --> Helper loaded: cookie_helper
INFO - 2023-04-26 09:10:45 --> Database Driver Class Initialized
INFO - 2023-04-26 09:10:45 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-26 09:10:45 --> Parser Class Initialized
INFO - 2023-04-26 09:10:45 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-26 09:10:45 --> Pagination Class Initialized
INFO - 2023-04-26 09:10:45 --> Form Validation Class Initialized
INFO - 2023-04-26 09:10:45 --> Controller Class Initialized
DEBUG - 2023-04-26 09:10:45 --> Auth class already loaded. Second attempt ignored.
INFO - 2023-04-26 09:10:45 --> Model Class Initialized
INFO - 2023-04-26 09:10:45 --> Model Class Initialized
INFO - 2023-04-26 09:10:45 --> Model Class Initialized
INFO - 2023-04-26 09:10:45 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/product/product.php
DEBUG - 2023-04-26 09:10:45 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-04-26 09:10:45 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-04-26 09:10:45 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-04-26 09:10:45 --> Model Class Initialized
INFO - 2023-04-26 09:10:45 --> Model Class Initialized
INFO - 2023-04-26 09:10:45 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-04-26 09:10:45 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-04-26 09:10:45 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-04-26 09:10:45 --> Final output sent to browser
DEBUG - 2023-04-26 09:10:45 --> Total execution time: 0.1435
ERROR - 2023-04-26 09:10:46 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-26 09:10:46 --> Config Class Initialized
INFO - 2023-04-26 09:10:46 --> Hooks Class Initialized
DEBUG - 2023-04-26 09:10:46 --> UTF-8 Support Enabled
INFO - 2023-04-26 09:10:46 --> Utf8 Class Initialized
INFO - 2023-04-26 09:10:46 --> URI Class Initialized
INFO - 2023-04-26 09:10:46 --> Router Class Initialized
INFO - 2023-04-26 09:10:46 --> Output Class Initialized
INFO - 2023-04-26 09:10:46 --> Security Class Initialized
DEBUG - 2023-04-26 09:10:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-26 09:10:46 --> Input Class Initialized
INFO - 2023-04-26 09:10:46 --> Language Class Initialized
INFO - 2023-04-26 09:10:46 --> Loader Class Initialized
INFO - 2023-04-26 09:10:46 --> Helper loaded: url_helper
INFO - 2023-04-26 09:10:46 --> Helper loaded: file_helper
INFO - 2023-04-26 09:10:46 --> Helper loaded: html_helper
INFO - 2023-04-26 09:10:46 --> Helper loaded: text_helper
INFO - 2023-04-26 09:10:46 --> Helper loaded: form_helper
INFO - 2023-04-26 09:10:46 --> Helper loaded: lang_helper
INFO - 2023-04-26 09:10:46 --> Helper loaded: security_helper
INFO - 2023-04-26 09:10:46 --> Helper loaded: cookie_helper
INFO - 2023-04-26 09:10:46 --> Database Driver Class Initialized
INFO - 2023-04-26 09:10:46 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-26 09:10:46 --> Parser Class Initialized
INFO - 2023-04-26 09:10:46 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-26 09:10:46 --> Pagination Class Initialized
INFO - 2023-04-26 09:10:46 --> Form Validation Class Initialized
INFO - 2023-04-26 09:10:46 --> Controller Class Initialized
DEBUG - 2023-04-26 09:10:46 --> Auth class already loaded. Second attempt ignored.
INFO - 2023-04-26 09:10:46 --> Model Class Initialized
INFO - 2023-04-26 09:10:46 --> Model Class Initialized
INFO - 2023-04-26 09:10:46 --> Final output sent to browser
DEBUG - 2023-04-26 09:10:46 --> Total execution time: 0.0492
ERROR - 2023-04-26 09:10:49 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-26 09:10:49 --> Config Class Initialized
INFO - 2023-04-26 09:10:49 --> Hooks Class Initialized
DEBUG - 2023-04-26 09:10:49 --> UTF-8 Support Enabled
INFO - 2023-04-26 09:10:49 --> Utf8 Class Initialized
INFO - 2023-04-26 09:10:49 --> URI Class Initialized
INFO - 2023-04-26 09:10:49 --> Router Class Initialized
INFO - 2023-04-26 09:10:49 --> Output Class Initialized
INFO - 2023-04-26 09:10:49 --> Security Class Initialized
DEBUG - 2023-04-26 09:10:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-26 09:10:49 --> Input Class Initialized
INFO - 2023-04-26 09:10:49 --> Language Class Initialized
INFO - 2023-04-26 09:10:49 --> Loader Class Initialized
INFO - 2023-04-26 09:10:49 --> Helper loaded: url_helper
INFO - 2023-04-26 09:10:49 --> Helper loaded: file_helper
INFO - 2023-04-26 09:10:49 --> Helper loaded: html_helper
INFO - 2023-04-26 09:10:49 --> Helper loaded: text_helper
INFO - 2023-04-26 09:10:49 --> Helper loaded: form_helper
INFO - 2023-04-26 09:10:49 --> Helper loaded: lang_helper
INFO - 2023-04-26 09:10:49 --> Helper loaded: security_helper
INFO - 2023-04-26 09:10:49 --> Helper loaded: cookie_helper
INFO - 2023-04-26 09:10:49 --> Database Driver Class Initialized
INFO - 2023-04-26 09:10:49 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-26 09:10:49 --> Parser Class Initialized
INFO - 2023-04-26 09:10:49 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-26 09:10:49 --> Pagination Class Initialized
INFO - 2023-04-26 09:10:49 --> Form Validation Class Initialized
INFO - 2023-04-26 09:10:49 --> Controller Class Initialized
DEBUG - 2023-04-26 09:10:49 --> Auth class already loaded. Second attempt ignored.
INFO - 2023-04-26 09:10:49 --> Model Class Initialized
INFO - 2023-04-26 09:10:49 --> Model Class Initialized
INFO - 2023-04-26 09:10:49 --> Final output sent to browser
DEBUG - 2023-04-26 09:10:49 --> Total execution time: 0.1219
ERROR - 2023-04-26 09:13:35 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-26 09:13:35 --> Config Class Initialized
INFO - 2023-04-26 09:13:35 --> Hooks Class Initialized
DEBUG - 2023-04-26 09:13:35 --> UTF-8 Support Enabled
INFO - 2023-04-26 09:13:35 --> Utf8 Class Initialized
INFO - 2023-04-26 09:13:35 --> URI Class Initialized
INFO - 2023-04-26 09:13:35 --> Router Class Initialized
INFO - 2023-04-26 09:13:35 --> Output Class Initialized
INFO - 2023-04-26 09:13:35 --> Security Class Initialized
DEBUG - 2023-04-26 09:13:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-26 09:13:35 --> Input Class Initialized
INFO - 2023-04-26 09:13:35 --> Language Class Initialized
INFO - 2023-04-26 09:13:35 --> Loader Class Initialized
INFO - 2023-04-26 09:13:35 --> Helper loaded: url_helper
INFO - 2023-04-26 09:13:35 --> Helper loaded: file_helper
INFO - 2023-04-26 09:13:35 --> Helper loaded: html_helper
INFO - 2023-04-26 09:13:35 --> Helper loaded: text_helper
INFO - 2023-04-26 09:13:35 --> Helper loaded: form_helper
INFO - 2023-04-26 09:13:35 --> Helper loaded: lang_helper
INFO - 2023-04-26 09:13:35 --> Helper loaded: security_helper
INFO - 2023-04-26 09:13:35 --> Helper loaded: cookie_helper
INFO - 2023-04-26 09:13:35 --> Database Driver Class Initialized
INFO - 2023-04-26 09:13:35 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-26 09:13:35 --> Parser Class Initialized
INFO - 2023-04-26 09:13:35 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-26 09:13:35 --> Pagination Class Initialized
INFO - 2023-04-26 09:13:35 --> Form Validation Class Initialized
INFO - 2023-04-26 09:13:35 --> Controller Class Initialized
DEBUG - 2023-04-26 09:13:35 --> Auth class already loaded. Second attempt ignored.
INFO - 2023-04-26 09:13:35 --> Model Class Initialized
INFO - 2023-04-26 09:13:35 --> Model Class Initialized
INFO - 2023-04-26 09:13:35 --> Model Class Initialized
INFO - 2023-04-26 09:13:35 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/product/product.php
DEBUG - 2023-04-26 09:13:35 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-04-26 09:13:35 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-04-26 09:13:35 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-04-26 09:13:35 --> Model Class Initialized
INFO - 2023-04-26 09:13:35 --> Model Class Initialized
INFO - 2023-04-26 09:13:35 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-04-26 09:13:35 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-04-26 09:13:35 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-04-26 09:13:35 --> Final output sent to browser
DEBUG - 2023-04-26 09:13:35 --> Total execution time: 0.1464
ERROR - 2023-04-26 09:13:36 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-26 09:13:36 --> Config Class Initialized
INFO - 2023-04-26 09:13:36 --> Hooks Class Initialized
DEBUG - 2023-04-26 09:13:36 --> UTF-8 Support Enabled
INFO - 2023-04-26 09:13:36 --> Utf8 Class Initialized
INFO - 2023-04-26 09:13:36 --> URI Class Initialized
INFO - 2023-04-26 09:13:36 --> Router Class Initialized
INFO - 2023-04-26 09:13:36 --> Output Class Initialized
INFO - 2023-04-26 09:13:36 --> Security Class Initialized
DEBUG - 2023-04-26 09:13:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-26 09:13:36 --> Input Class Initialized
INFO - 2023-04-26 09:13:36 --> Language Class Initialized
INFO - 2023-04-26 09:13:36 --> Loader Class Initialized
INFO - 2023-04-26 09:13:36 --> Helper loaded: url_helper
INFO - 2023-04-26 09:13:36 --> Helper loaded: file_helper
INFO - 2023-04-26 09:13:36 --> Helper loaded: html_helper
INFO - 2023-04-26 09:13:36 --> Helper loaded: text_helper
INFO - 2023-04-26 09:13:36 --> Helper loaded: form_helper
INFO - 2023-04-26 09:13:36 --> Helper loaded: lang_helper
INFO - 2023-04-26 09:13:36 --> Helper loaded: security_helper
INFO - 2023-04-26 09:13:36 --> Helper loaded: cookie_helper
INFO - 2023-04-26 09:13:36 --> Database Driver Class Initialized
INFO - 2023-04-26 09:13:36 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-26 09:13:36 --> Parser Class Initialized
INFO - 2023-04-26 09:13:36 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-26 09:13:36 --> Pagination Class Initialized
INFO - 2023-04-26 09:13:36 --> Form Validation Class Initialized
INFO - 2023-04-26 09:13:36 --> Controller Class Initialized
DEBUG - 2023-04-26 09:13:36 --> Auth class already loaded. Second attempt ignored.
INFO - 2023-04-26 09:13:36 --> Model Class Initialized
INFO - 2023-04-26 09:13:36 --> Model Class Initialized
INFO - 2023-04-26 09:13:36 --> Final output sent to browser
DEBUG - 2023-04-26 09:13:36 --> Total execution time: 0.0514
ERROR - 2023-04-26 09:13:40 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-26 09:13:40 --> Config Class Initialized
INFO - 2023-04-26 09:13:40 --> Hooks Class Initialized
DEBUG - 2023-04-26 09:13:40 --> UTF-8 Support Enabled
INFO - 2023-04-26 09:13:40 --> Utf8 Class Initialized
INFO - 2023-04-26 09:13:40 --> URI Class Initialized
INFO - 2023-04-26 09:13:40 --> Router Class Initialized
INFO - 2023-04-26 09:13:40 --> Output Class Initialized
INFO - 2023-04-26 09:13:40 --> Security Class Initialized
DEBUG - 2023-04-26 09:13:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-26 09:13:40 --> Input Class Initialized
INFO - 2023-04-26 09:13:40 --> Language Class Initialized
INFO - 2023-04-26 09:13:40 --> Loader Class Initialized
INFO - 2023-04-26 09:13:40 --> Helper loaded: url_helper
INFO - 2023-04-26 09:13:40 --> Helper loaded: file_helper
INFO - 2023-04-26 09:13:40 --> Helper loaded: html_helper
INFO - 2023-04-26 09:13:40 --> Helper loaded: text_helper
INFO - 2023-04-26 09:13:40 --> Helper loaded: form_helper
INFO - 2023-04-26 09:13:40 --> Helper loaded: lang_helper
INFO - 2023-04-26 09:13:40 --> Helper loaded: security_helper
INFO - 2023-04-26 09:13:40 --> Helper loaded: cookie_helper
INFO - 2023-04-26 09:13:40 --> Database Driver Class Initialized
INFO - 2023-04-26 09:13:40 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-26 09:13:40 --> Parser Class Initialized
INFO - 2023-04-26 09:13:40 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-26 09:13:40 --> Pagination Class Initialized
INFO - 2023-04-26 09:13:40 --> Form Validation Class Initialized
INFO - 2023-04-26 09:13:40 --> Controller Class Initialized
DEBUG - 2023-04-26 09:13:40 --> Auth class already loaded. Second attempt ignored.
INFO - 2023-04-26 09:13:40 --> Model Class Initialized
INFO - 2023-04-26 09:13:40 --> Model Class Initialized
INFO - 2023-04-26 09:13:40 --> Final output sent to browser
DEBUG - 2023-04-26 09:13:40 --> Total execution time: 0.1222
ERROR - 2023-04-26 09:14:01 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-26 09:14:01 --> Config Class Initialized
INFO - 2023-04-26 09:14:01 --> Hooks Class Initialized
DEBUG - 2023-04-26 09:14:01 --> UTF-8 Support Enabled
INFO - 2023-04-26 09:14:01 --> Utf8 Class Initialized
INFO - 2023-04-26 09:14:01 --> URI Class Initialized
INFO - 2023-04-26 09:14:01 --> Router Class Initialized
INFO - 2023-04-26 09:14:01 --> Output Class Initialized
INFO - 2023-04-26 09:14:01 --> Security Class Initialized
DEBUG - 2023-04-26 09:14:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-26 09:14:01 --> Input Class Initialized
INFO - 2023-04-26 09:14:01 --> Language Class Initialized
INFO - 2023-04-26 09:14:01 --> Loader Class Initialized
INFO - 2023-04-26 09:14:01 --> Helper loaded: url_helper
INFO - 2023-04-26 09:14:01 --> Helper loaded: file_helper
INFO - 2023-04-26 09:14:01 --> Helper loaded: html_helper
INFO - 2023-04-26 09:14:01 --> Helper loaded: text_helper
INFO - 2023-04-26 09:14:01 --> Helper loaded: form_helper
INFO - 2023-04-26 09:14:01 --> Helper loaded: lang_helper
INFO - 2023-04-26 09:14:01 --> Helper loaded: security_helper
INFO - 2023-04-26 09:14:01 --> Helper loaded: cookie_helper
INFO - 2023-04-26 09:14:01 --> Database Driver Class Initialized
INFO - 2023-04-26 09:14:01 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-26 09:14:01 --> Parser Class Initialized
INFO - 2023-04-26 09:14:01 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-26 09:14:01 --> Pagination Class Initialized
INFO - 2023-04-26 09:14:01 --> Form Validation Class Initialized
INFO - 2023-04-26 09:14:01 --> Controller Class Initialized
DEBUG - 2023-04-26 09:14:01 --> Auth class already loaded. Second attempt ignored.
INFO - 2023-04-26 09:14:01 --> Model Class Initialized
INFO - 2023-04-26 09:14:01 --> Model Class Initialized
INFO - 2023-04-26 09:14:01 --> Final output sent to browser
DEBUG - 2023-04-26 09:14:01 --> Total execution time: 0.1389
ERROR - 2023-04-26 09:14:03 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-26 09:14:03 --> Config Class Initialized
INFO - 2023-04-26 09:14:03 --> Hooks Class Initialized
DEBUG - 2023-04-26 09:14:03 --> UTF-8 Support Enabled
INFO - 2023-04-26 09:14:03 --> Utf8 Class Initialized
INFO - 2023-04-26 09:14:03 --> URI Class Initialized
INFO - 2023-04-26 09:14:03 --> Router Class Initialized
INFO - 2023-04-26 09:14:03 --> Output Class Initialized
INFO - 2023-04-26 09:14:03 --> Security Class Initialized
DEBUG - 2023-04-26 09:14:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-26 09:14:03 --> Input Class Initialized
INFO - 2023-04-26 09:14:03 --> Language Class Initialized
INFO - 2023-04-26 09:14:03 --> Loader Class Initialized
INFO - 2023-04-26 09:14:03 --> Helper loaded: url_helper
INFO - 2023-04-26 09:14:03 --> Helper loaded: file_helper
INFO - 2023-04-26 09:14:03 --> Helper loaded: html_helper
INFO - 2023-04-26 09:14:03 --> Helper loaded: text_helper
INFO - 2023-04-26 09:14:03 --> Helper loaded: form_helper
INFO - 2023-04-26 09:14:03 --> Helper loaded: lang_helper
INFO - 2023-04-26 09:14:03 --> Helper loaded: security_helper
INFO - 2023-04-26 09:14:03 --> Helper loaded: cookie_helper
INFO - 2023-04-26 09:14:03 --> Database Driver Class Initialized
INFO - 2023-04-26 09:14:03 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-26 09:14:03 --> Parser Class Initialized
INFO - 2023-04-26 09:14:03 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-26 09:14:03 --> Pagination Class Initialized
INFO - 2023-04-26 09:14:03 --> Form Validation Class Initialized
INFO - 2023-04-26 09:14:03 --> Controller Class Initialized
DEBUG - 2023-04-26 09:14:03 --> Auth class already loaded. Second attempt ignored.
INFO - 2023-04-26 09:14:03 --> Model Class Initialized
INFO - 2023-04-26 09:14:03 --> Model Class Initialized
INFO - 2023-04-26 09:14:04 --> Final output sent to browser
DEBUG - 2023-04-26 09:14:04 --> Total execution time: 0.1250
ERROR - 2023-04-26 09:16:27 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-26 09:16:27 --> Config Class Initialized
INFO - 2023-04-26 09:16:27 --> Hooks Class Initialized
DEBUG - 2023-04-26 09:16:27 --> UTF-8 Support Enabled
INFO - 2023-04-26 09:16:27 --> Utf8 Class Initialized
INFO - 2023-04-26 09:16:27 --> URI Class Initialized
INFO - 2023-04-26 09:16:27 --> Router Class Initialized
INFO - 2023-04-26 09:16:27 --> Output Class Initialized
INFO - 2023-04-26 09:16:27 --> Security Class Initialized
DEBUG - 2023-04-26 09:16:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-26 09:16:27 --> Input Class Initialized
INFO - 2023-04-26 09:16:27 --> Language Class Initialized
INFO - 2023-04-26 09:16:27 --> Loader Class Initialized
INFO - 2023-04-26 09:16:27 --> Helper loaded: url_helper
INFO - 2023-04-26 09:16:27 --> Helper loaded: file_helper
INFO - 2023-04-26 09:16:27 --> Helper loaded: html_helper
INFO - 2023-04-26 09:16:27 --> Helper loaded: text_helper
INFO - 2023-04-26 09:16:27 --> Helper loaded: form_helper
INFO - 2023-04-26 09:16:27 --> Helper loaded: lang_helper
INFO - 2023-04-26 09:16:27 --> Helper loaded: security_helper
INFO - 2023-04-26 09:16:27 --> Helper loaded: cookie_helper
INFO - 2023-04-26 09:16:27 --> Database Driver Class Initialized
INFO - 2023-04-26 09:16:27 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-26 09:16:27 --> Parser Class Initialized
INFO - 2023-04-26 09:16:27 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-26 09:16:27 --> Pagination Class Initialized
INFO - 2023-04-26 09:16:27 --> Form Validation Class Initialized
INFO - 2023-04-26 09:16:27 --> Controller Class Initialized
INFO - 2023-04-26 09:16:27 --> Model Class Initialized
INFO - 2023-04-26 09:16:27 --> Model Class Initialized
INFO - 2023-04-26 09:16:27 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/purchase/purchase.php
DEBUG - 2023-04-26 09:16:27 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-04-26 09:16:27 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-04-26 09:16:27 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-04-26 09:16:27 --> Model Class Initialized
INFO - 2023-04-26 09:16:27 --> Model Class Initialized
INFO - 2023-04-26 09:16:27 --> Model Class Initialized
INFO - 2023-04-26 09:16:27 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-04-26 09:16:27 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-04-26 09:16:27 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-04-26 09:16:27 --> Final output sent to browser
DEBUG - 2023-04-26 09:16:27 --> Total execution time: 0.1598
ERROR - 2023-04-26 09:16:28 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-26 09:16:28 --> Config Class Initialized
INFO - 2023-04-26 09:16:28 --> Hooks Class Initialized
DEBUG - 2023-04-26 09:16:28 --> UTF-8 Support Enabled
INFO - 2023-04-26 09:16:28 --> Utf8 Class Initialized
INFO - 2023-04-26 09:16:28 --> URI Class Initialized
INFO - 2023-04-26 09:16:28 --> Router Class Initialized
INFO - 2023-04-26 09:16:28 --> Output Class Initialized
INFO - 2023-04-26 09:16:28 --> Security Class Initialized
DEBUG - 2023-04-26 09:16:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-26 09:16:28 --> Input Class Initialized
INFO - 2023-04-26 09:16:28 --> Language Class Initialized
INFO - 2023-04-26 09:16:28 --> Loader Class Initialized
INFO - 2023-04-26 09:16:28 --> Helper loaded: url_helper
INFO - 2023-04-26 09:16:28 --> Helper loaded: file_helper
INFO - 2023-04-26 09:16:28 --> Helper loaded: html_helper
INFO - 2023-04-26 09:16:28 --> Helper loaded: text_helper
INFO - 2023-04-26 09:16:29 --> Helper loaded: form_helper
INFO - 2023-04-26 09:16:29 --> Helper loaded: lang_helper
INFO - 2023-04-26 09:16:29 --> Helper loaded: security_helper
INFO - 2023-04-26 09:16:29 --> Helper loaded: cookie_helper
INFO - 2023-04-26 09:16:29 --> Database Driver Class Initialized
INFO - 2023-04-26 09:16:29 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-26 09:16:29 --> Parser Class Initialized
INFO - 2023-04-26 09:16:29 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-26 09:16:29 --> Pagination Class Initialized
INFO - 2023-04-26 09:16:29 --> Form Validation Class Initialized
INFO - 2023-04-26 09:16:29 --> Controller Class Initialized
INFO - 2023-04-26 09:16:29 --> Model Class Initialized
INFO - 2023-04-26 09:16:29 --> Model Class Initialized
INFO - 2023-04-26 09:16:29 --> Final output sent to browser
DEBUG - 2023-04-26 09:16:29 --> Total execution time: 0.0463
ERROR - 2023-04-26 09:16:32 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-26 09:16:32 --> Config Class Initialized
INFO - 2023-04-26 09:16:32 --> Hooks Class Initialized
DEBUG - 2023-04-26 09:16:32 --> UTF-8 Support Enabled
INFO - 2023-04-26 09:16:32 --> Utf8 Class Initialized
INFO - 2023-04-26 09:16:32 --> URI Class Initialized
INFO - 2023-04-26 09:16:32 --> Router Class Initialized
INFO - 2023-04-26 09:16:32 --> Output Class Initialized
INFO - 2023-04-26 09:16:32 --> Security Class Initialized
DEBUG - 2023-04-26 09:16:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-26 09:16:32 --> Input Class Initialized
INFO - 2023-04-26 09:16:32 --> Language Class Initialized
INFO - 2023-04-26 09:16:32 --> Loader Class Initialized
INFO - 2023-04-26 09:16:32 --> Helper loaded: url_helper
INFO - 2023-04-26 09:16:32 --> Helper loaded: file_helper
INFO - 2023-04-26 09:16:32 --> Helper loaded: html_helper
INFO - 2023-04-26 09:16:32 --> Helper loaded: text_helper
INFO - 2023-04-26 09:16:32 --> Helper loaded: form_helper
INFO - 2023-04-26 09:16:32 --> Helper loaded: lang_helper
INFO - 2023-04-26 09:16:32 --> Helper loaded: security_helper
INFO - 2023-04-26 09:16:32 --> Helper loaded: cookie_helper
INFO - 2023-04-26 09:16:32 --> Database Driver Class Initialized
INFO - 2023-04-26 09:16:32 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-26 09:16:32 --> Parser Class Initialized
INFO - 2023-04-26 09:16:32 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-26 09:16:32 --> Pagination Class Initialized
INFO - 2023-04-26 09:16:32 --> Form Validation Class Initialized
INFO - 2023-04-26 09:16:32 --> Controller Class Initialized
INFO - 2023-04-26 09:16:32 --> Model Class Initialized
INFO - 2023-04-26 09:16:32 --> Model Class Initialized
INFO - 2023-04-26 09:16:32 --> Final output sent to browser
DEBUG - 2023-04-26 09:16:32 --> Total execution time: 0.0721
ERROR - 2023-04-26 09:16:50 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-26 09:16:50 --> Config Class Initialized
INFO - 2023-04-26 09:16:50 --> Hooks Class Initialized
DEBUG - 2023-04-26 09:16:50 --> UTF-8 Support Enabled
INFO - 2023-04-26 09:16:50 --> Utf8 Class Initialized
INFO - 2023-04-26 09:16:50 --> URI Class Initialized
INFO - 2023-04-26 09:16:50 --> Router Class Initialized
INFO - 2023-04-26 09:16:50 --> Output Class Initialized
INFO - 2023-04-26 09:16:50 --> Security Class Initialized
DEBUG - 2023-04-26 09:16:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-26 09:16:50 --> Input Class Initialized
INFO - 2023-04-26 09:16:50 --> Language Class Initialized
INFO - 2023-04-26 09:16:50 --> Loader Class Initialized
INFO - 2023-04-26 09:16:50 --> Helper loaded: url_helper
INFO - 2023-04-26 09:16:50 --> Helper loaded: file_helper
INFO - 2023-04-26 09:16:50 --> Helper loaded: html_helper
INFO - 2023-04-26 09:16:50 --> Helper loaded: text_helper
INFO - 2023-04-26 09:16:50 --> Helper loaded: form_helper
INFO - 2023-04-26 09:16:50 --> Helper loaded: lang_helper
INFO - 2023-04-26 09:16:50 --> Helper loaded: security_helper
INFO - 2023-04-26 09:16:50 --> Helper loaded: cookie_helper
INFO - 2023-04-26 09:16:50 --> Database Driver Class Initialized
INFO - 2023-04-26 09:16:50 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-26 09:16:50 --> Parser Class Initialized
INFO - 2023-04-26 09:16:50 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-26 09:16:50 --> Pagination Class Initialized
INFO - 2023-04-26 09:16:50 --> Form Validation Class Initialized
INFO - 2023-04-26 09:16:50 --> Controller Class Initialized
INFO - 2023-04-26 09:16:50 --> Model Class Initialized
INFO - 2023-04-26 09:16:50 --> Model Class Initialized
INFO - 2023-04-26 09:16:50 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/report/stock_report.php
DEBUG - 2023-04-26 09:16:50 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-04-26 09:16:50 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-04-26 09:16:50 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-04-26 09:16:50 --> Model Class Initialized
INFO - 2023-04-26 09:16:50 --> Model Class Initialized
INFO - 2023-04-26 09:16:51 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-04-26 09:16:51 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-04-26 09:16:51 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-04-26 09:16:51 --> Final output sent to browser
DEBUG - 2023-04-26 09:16:51 --> Total execution time: 0.1420
ERROR - 2023-04-26 09:16:51 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-26 09:16:51 --> Config Class Initialized
INFO - 2023-04-26 09:16:51 --> Hooks Class Initialized
DEBUG - 2023-04-26 09:16:51 --> UTF-8 Support Enabled
INFO - 2023-04-26 09:16:51 --> Utf8 Class Initialized
INFO - 2023-04-26 09:16:51 --> URI Class Initialized
INFO - 2023-04-26 09:16:51 --> Router Class Initialized
INFO - 2023-04-26 09:16:51 --> Output Class Initialized
INFO - 2023-04-26 09:16:51 --> Security Class Initialized
DEBUG - 2023-04-26 09:16:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-26 09:16:51 --> Input Class Initialized
INFO - 2023-04-26 09:16:51 --> Language Class Initialized
INFO - 2023-04-26 09:16:51 --> Loader Class Initialized
INFO - 2023-04-26 09:16:51 --> Helper loaded: url_helper
INFO - 2023-04-26 09:16:51 --> Helper loaded: file_helper
INFO - 2023-04-26 09:16:51 --> Helper loaded: html_helper
INFO - 2023-04-26 09:16:51 --> Helper loaded: text_helper
INFO - 2023-04-26 09:16:51 --> Helper loaded: form_helper
INFO - 2023-04-26 09:16:51 --> Helper loaded: lang_helper
INFO - 2023-04-26 09:16:51 --> Helper loaded: security_helper
INFO - 2023-04-26 09:16:51 --> Helper loaded: cookie_helper
INFO - 2023-04-26 09:16:51 --> Database Driver Class Initialized
INFO - 2023-04-26 09:16:51 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-26 09:16:51 --> Parser Class Initialized
INFO - 2023-04-26 09:16:51 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-26 09:16:51 --> Pagination Class Initialized
INFO - 2023-04-26 09:16:51 --> Form Validation Class Initialized
INFO - 2023-04-26 09:16:51 --> Controller Class Initialized
INFO - 2023-04-26 09:16:51 --> Model Class Initialized
INFO - 2023-04-26 09:16:51 --> Model Class Initialized
INFO - 2023-04-26 09:16:51 --> Final output sent to browser
DEBUG - 2023-04-26 09:16:51 --> Total execution time: 0.0190
ERROR - 2023-04-26 09:16:59 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-26 09:16:59 --> Config Class Initialized
INFO - 2023-04-26 09:16:59 --> Hooks Class Initialized
DEBUG - 2023-04-26 09:16:59 --> UTF-8 Support Enabled
INFO - 2023-04-26 09:16:59 --> Utf8 Class Initialized
INFO - 2023-04-26 09:16:59 --> URI Class Initialized
INFO - 2023-04-26 09:16:59 --> Router Class Initialized
INFO - 2023-04-26 09:16:59 --> Output Class Initialized
INFO - 2023-04-26 09:16:59 --> Security Class Initialized
DEBUG - 2023-04-26 09:16:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-26 09:16:59 --> Input Class Initialized
INFO - 2023-04-26 09:16:59 --> Language Class Initialized
INFO - 2023-04-26 09:16:59 --> Loader Class Initialized
INFO - 2023-04-26 09:16:59 --> Helper loaded: url_helper
INFO - 2023-04-26 09:16:59 --> Helper loaded: file_helper
INFO - 2023-04-26 09:16:59 --> Helper loaded: html_helper
INFO - 2023-04-26 09:16:59 --> Helper loaded: text_helper
INFO - 2023-04-26 09:16:59 --> Helper loaded: form_helper
INFO - 2023-04-26 09:16:59 --> Helper loaded: lang_helper
INFO - 2023-04-26 09:16:59 --> Helper loaded: security_helper
INFO - 2023-04-26 09:16:59 --> Helper loaded: cookie_helper
INFO - 2023-04-26 09:16:59 --> Database Driver Class Initialized
INFO - 2023-04-26 09:16:59 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-26 09:16:59 --> Parser Class Initialized
INFO - 2023-04-26 09:16:59 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-26 09:16:59 --> Pagination Class Initialized
INFO - 2023-04-26 09:16:59 --> Form Validation Class Initialized
INFO - 2023-04-26 09:16:59 --> Controller Class Initialized
INFO - 2023-04-26 09:16:59 --> Model Class Initialized
INFO - 2023-04-26 09:16:59 --> Model Class Initialized
INFO - 2023-04-26 09:16:59 --> Final output sent to browser
DEBUG - 2023-04-26 09:16:59 --> Total execution time: 0.0252
ERROR - 2023-04-26 09:17:52 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-26 09:17:52 --> Config Class Initialized
INFO - 2023-04-26 09:17:52 --> Hooks Class Initialized
DEBUG - 2023-04-26 09:17:52 --> UTF-8 Support Enabled
INFO - 2023-04-26 09:17:52 --> Utf8 Class Initialized
INFO - 2023-04-26 09:17:52 --> URI Class Initialized
INFO - 2023-04-26 09:17:52 --> Router Class Initialized
INFO - 2023-04-26 09:17:52 --> Output Class Initialized
INFO - 2023-04-26 09:17:52 --> Security Class Initialized
DEBUG - 2023-04-26 09:17:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-26 09:17:52 --> Input Class Initialized
INFO - 2023-04-26 09:17:52 --> Language Class Initialized
INFO - 2023-04-26 09:17:52 --> Loader Class Initialized
INFO - 2023-04-26 09:17:52 --> Helper loaded: url_helper
INFO - 2023-04-26 09:17:52 --> Helper loaded: file_helper
INFO - 2023-04-26 09:17:52 --> Helper loaded: html_helper
INFO - 2023-04-26 09:17:52 --> Helper loaded: text_helper
INFO - 2023-04-26 09:17:52 --> Helper loaded: form_helper
INFO - 2023-04-26 09:17:52 --> Helper loaded: lang_helper
INFO - 2023-04-26 09:17:52 --> Helper loaded: security_helper
INFO - 2023-04-26 09:17:52 --> Helper loaded: cookie_helper
INFO - 2023-04-26 09:17:52 --> Database Driver Class Initialized
INFO - 2023-04-26 09:17:52 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-26 09:17:52 --> Parser Class Initialized
INFO - 2023-04-26 09:17:52 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-26 09:17:52 --> Pagination Class Initialized
INFO - 2023-04-26 09:17:52 --> Form Validation Class Initialized
INFO - 2023-04-26 09:17:52 --> Controller Class Initialized
DEBUG - 2023-04-26 09:17:52 --> Auth class already loaded. Second attempt ignored.
INFO - 2023-04-26 09:17:52 --> Model Class Initialized
INFO - 2023-04-26 09:17:52 --> Model Class Initialized
INFO - 2023-04-26 09:17:52 --> Model Class Initialized
INFO - 2023-04-26 09:17:52 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/product/product_details.php
DEBUG - 2023-04-26 09:17:52 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-04-26 09:17:52 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-04-26 09:17:52 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-04-26 09:17:52 --> Model Class Initialized
INFO - 2023-04-26 09:17:52 --> Model Class Initialized
INFO - 2023-04-26 09:17:52 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-04-26 09:17:52 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-04-26 09:17:52 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-04-26 09:17:52 --> Final output sent to browser
DEBUG - 2023-04-26 09:17:52 --> Total execution time: 0.1805
ERROR - 2023-04-26 09:17:58 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-26 09:17:58 --> Config Class Initialized
INFO - 2023-04-26 09:17:58 --> Hooks Class Initialized
DEBUG - 2023-04-26 09:17:58 --> UTF-8 Support Enabled
INFO - 2023-04-26 09:17:58 --> Utf8 Class Initialized
INFO - 2023-04-26 09:17:58 --> URI Class Initialized
INFO - 2023-04-26 09:17:58 --> Router Class Initialized
INFO - 2023-04-26 09:17:58 --> Output Class Initialized
INFO - 2023-04-26 09:17:58 --> Security Class Initialized
DEBUG - 2023-04-26 09:17:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-26 09:17:58 --> Input Class Initialized
INFO - 2023-04-26 09:17:58 --> Language Class Initialized
INFO - 2023-04-26 09:17:58 --> Loader Class Initialized
INFO - 2023-04-26 09:17:58 --> Helper loaded: url_helper
INFO - 2023-04-26 09:17:58 --> Helper loaded: file_helper
INFO - 2023-04-26 09:17:58 --> Helper loaded: html_helper
INFO - 2023-04-26 09:17:58 --> Helper loaded: text_helper
INFO - 2023-04-26 09:17:58 --> Helper loaded: form_helper
INFO - 2023-04-26 09:17:58 --> Helper loaded: lang_helper
INFO - 2023-04-26 09:17:58 --> Helper loaded: security_helper
INFO - 2023-04-26 09:17:58 --> Helper loaded: cookie_helper
INFO - 2023-04-26 09:17:58 --> Database Driver Class Initialized
INFO - 2023-04-26 09:17:58 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-26 09:17:58 --> Parser Class Initialized
INFO - 2023-04-26 09:17:58 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-26 09:17:58 --> Pagination Class Initialized
INFO - 2023-04-26 09:17:58 --> Form Validation Class Initialized
INFO - 2023-04-26 09:17:58 --> Controller Class Initialized
INFO - 2023-04-26 09:17:58 --> Model Class Initialized
INFO - 2023-04-26 09:17:58 --> Model Class Initialized
INFO - 2023-04-26 09:17:58 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/report/stock_report.php
DEBUG - 2023-04-26 09:17:58 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-04-26 09:17:58 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-04-26 09:17:58 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-04-26 09:17:58 --> Model Class Initialized
INFO - 2023-04-26 09:17:58 --> Model Class Initialized
INFO - 2023-04-26 09:17:58 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-04-26 09:17:58 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-04-26 09:17:58 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-04-26 09:17:58 --> Final output sent to browser
DEBUG - 2023-04-26 09:17:58 --> Total execution time: 0.1445
ERROR - 2023-04-26 09:17:59 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-26 09:17:59 --> Config Class Initialized
INFO - 2023-04-26 09:17:59 --> Hooks Class Initialized
DEBUG - 2023-04-26 09:17:59 --> UTF-8 Support Enabled
INFO - 2023-04-26 09:17:59 --> Utf8 Class Initialized
INFO - 2023-04-26 09:17:59 --> URI Class Initialized
INFO - 2023-04-26 09:17:59 --> Router Class Initialized
INFO - 2023-04-26 09:17:59 --> Output Class Initialized
INFO - 2023-04-26 09:17:59 --> Security Class Initialized
DEBUG - 2023-04-26 09:17:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-26 09:17:59 --> Input Class Initialized
INFO - 2023-04-26 09:17:59 --> Language Class Initialized
INFO - 2023-04-26 09:17:59 --> Loader Class Initialized
INFO - 2023-04-26 09:17:59 --> Helper loaded: url_helper
INFO - 2023-04-26 09:17:59 --> Helper loaded: file_helper
INFO - 2023-04-26 09:17:59 --> Helper loaded: html_helper
INFO - 2023-04-26 09:17:59 --> Helper loaded: text_helper
INFO - 2023-04-26 09:17:59 --> Helper loaded: form_helper
INFO - 2023-04-26 09:17:59 --> Helper loaded: lang_helper
INFO - 2023-04-26 09:17:59 --> Helper loaded: security_helper
INFO - 2023-04-26 09:17:59 --> Helper loaded: cookie_helper
INFO - 2023-04-26 09:17:59 --> Database Driver Class Initialized
INFO - 2023-04-26 09:17:59 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-26 09:17:59 --> Parser Class Initialized
INFO - 2023-04-26 09:17:59 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-26 09:17:59 --> Pagination Class Initialized
INFO - 2023-04-26 09:17:59 --> Form Validation Class Initialized
INFO - 2023-04-26 09:17:59 --> Controller Class Initialized
INFO - 2023-04-26 09:17:59 --> Model Class Initialized
INFO - 2023-04-26 09:17:59 --> Model Class Initialized
INFO - 2023-04-26 09:17:59 --> Final output sent to browser
DEBUG - 2023-04-26 09:17:59 --> Total execution time: 0.0225
ERROR - 2023-04-26 09:18:04 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-26 09:18:04 --> Config Class Initialized
INFO - 2023-04-26 09:18:04 --> Hooks Class Initialized
DEBUG - 2023-04-26 09:18:04 --> UTF-8 Support Enabled
INFO - 2023-04-26 09:18:04 --> Utf8 Class Initialized
INFO - 2023-04-26 09:18:04 --> URI Class Initialized
INFO - 2023-04-26 09:18:04 --> Router Class Initialized
INFO - 2023-04-26 09:18:04 --> Output Class Initialized
INFO - 2023-04-26 09:18:04 --> Security Class Initialized
DEBUG - 2023-04-26 09:18:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-26 09:18:04 --> Input Class Initialized
INFO - 2023-04-26 09:18:04 --> Language Class Initialized
INFO - 2023-04-26 09:18:04 --> Loader Class Initialized
INFO - 2023-04-26 09:18:04 --> Helper loaded: url_helper
INFO - 2023-04-26 09:18:04 --> Helper loaded: file_helper
INFO - 2023-04-26 09:18:04 --> Helper loaded: html_helper
INFO - 2023-04-26 09:18:04 --> Helper loaded: text_helper
INFO - 2023-04-26 09:18:04 --> Helper loaded: form_helper
INFO - 2023-04-26 09:18:04 --> Helper loaded: lang_helper
INFO - 2023-04-26 09:18:04 --> Helper loaded: security_helper
INFO - 2023-04-26 09:18:04 --> Helper loaded: cookie_helper
INFO - 2023-04-26 09:18:04 --> Database Driver Class Initialized
INFO - 2023-04-26 09:18:04 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-26 09:18:04 --> Parser Class Initialized
INFO - 2023-04-26 09:18:04 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-26 09:18:04 --> Pagination Class Initialized
INFO - 2023-04-26 09:18:04 --> Form Validation Class Initialized
INFO - 2023-04-26 09:18:04 --> Controller Class Initialized
INFO - 2023-04-26 09:18:04 --> Model Class Initialized
INFO - 2023-04-26 09:18:04 --> Model Class Initialized
INFO - 2023-04-26 09:18:04 --> Final output sent to browser
DEBUG - 2023-04-26 09:18:04 --> Total execution time: 0.0267
ERROR - 2023-04-26 09:20:52 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-26 09:20:52 --> Config Class Initialized
INFO - 2023-04-26 09:20:52 --> Hooks Class Initialized
DEBUG - 2023-04-26 09:20:52 --> UTF-8 Support Enabled
INFO - 2023-04-26 09:20:52 --> Utf8 Class Initialized
INFO - 2023-04-26 09:20:52 --> URI Class Initialized
INFO - 2023-04-26 09:20:52 --> Router Class Initialized
INFO - 2023-04-26 09:20:52 --> Output Class Initialized
INFO - 2023-04-26 09:20:52 --> Security Class Initialized
DEBUG - 2023-04-26 09:20:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-26 09:20:52 --> Input Class Initialized
INFO - 2023-04-26 09:20:52 --> Language Class Initialized
INFO - 2023-04-26 09:20:52 --> Loader Class Initialized
INFO - 2023-04-26 09:20:52 --> Helper loaded: url_helper
INFO - 2023-04-26 09:20:52 --> Helper loaded: file_helper
INFO - 2023-04-26 09:20:52 --> Helper loaded: html_helper
INFO - 2023-04-26 09:20:52 --> Helper loaded: text_helper
INFO - 2023-04-26 09:20:52 --> Helper loaded: form_helper
INFO - 2023-04-26 09:20:52 --> Helper loaded: lang_helper
INFO - 2023-04-26 09:20:52 --> Helper loaded: security_helper
INFO - 2023-04-26 09:20:52 --> Helper loaded: cookie_helper
INFO - 2023-04-26 09:20:52 --> Database Driver Class Initialized
INFO - 2023-04-26 09:20:52 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-26 09:20:52 --> Parser Class Initialized
INFO - 2023-04-26 09:20:52 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-26 09:20:52 --> Pagination Class Initialized
INFO - 2023-04-26 09:20:52 --> Form Validation Class Initialized
INFO - 2023-04-26 09:20:52 --> Controller Class Initialized
INFO - 2023-04-26 09:20:52 --> Model Class Initialized
INFO - 2023-04-26 09:20:52 --> Model Class Initialized
INFO - 2023-04-26 09:20:52 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/report/stock_report.php
DEBUG - 2023-04-26 09:20:52 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-04-26 09:20:52 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-04-26 09:20:52 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-04-26 09:20:52 --> Model Class Initialized
INFO - 2023-04-26 09:20:52 --> Model Class Initialized
INFO - 2023-04-26 09:20:52 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-04-26 09:20:52 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-04-26 09:20:52 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-04-26 09:20:52 --> Final output sent to browser
DEBUG - 2023-04-26 09:20:52 --> Total execution time: 0.1452
ERROR - 2023-04-26 09:20:52 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-26 09:20:52 --> Config Class Initialized
INFO - 2023-04-26 09:20:52 --> Hooks Class Initialized
DEBUG - 2023-04-26 09:20:52 --> UTF-8 Support Enabled
INFO - 2023-04-26 09:20:52 --> Utf8 Class Initialized
INFO - 2023-04-26 09:20:52 --> URI Class Initialized
INFO - 2023-04-26 09:20:52 --> Router Class Initialized
INFO - 2023-04-26 09:20:52 --> Output Class Initialized
INFO - 2023-04-26 09:20:52 --> Security Class Initialized
DEBUG - 2023-04-26 09:20:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-26 09:20:52 --> Input Class Initialized
INFO - 2023-04-26 09:20:52 --> Language Class Initialized
INFO - 2023-04-26 09:20:52 --> Loader Class Initialized
INFO - 2023-04-26 09:20:53 --> Helper loaded: url_helper
INFO - 2023-04-26 09:20:53 --> Helper loaded: file_helper
INFO - 2023-04-26 09:20:53 --> Helper loaded: html_helper
INFO - 2023-04-26 09:20:53 --> Helper loaded: text_helper
INFO - 2023-04-26 09:20:53 --> Helper loaded: form_helper
INFO - 2023-04-26 09:20:53 --> Helper loaded: lang_helper
INFO - 2023-04-26 09:20:53 --> Helper loaded: security_helper
INFO - 2023-04-26 09:20:53 --> Helper loaded: cookie_helper
INFO - 2023-04-26 09:20:53 --> Database Driver Class Initialized
INFO - 2023-04-26 09:20:53 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-26 09:20:53 --> Parser Class Initialized
INFO - 2023-04-26 09:20:53 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-26 09:20:53 --> Pagination Class Initialized
INFO - 2023-04-26 09:20:53 --> Form Validation Class Initialized
INFO - 2023-04-26 09:20:53 --> Controller Class Initialized
INFO - 2023-04-26 09:20:53 --> Model Class Initialized
INFO - 2023-04-26 09:20:53 --> Model Class Initialized
INFO - 2023-04-26 09:20:53 --> Final output sent to browser
DEBUG - 2023-04-26 09:20:53 --> Total execution time: 0.0195
ERROR - 2023-04-26 09:21:02 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-26 09:21:02 --> Config Class Initialized
INFO - 2023-04-26 09:21:02 --> Hooks Class Initialized
DEBUG - 2023-04-26 09:21:02 --> UTF-8 Support Enabled
INFO - 2023-04-26 09:21:02 --> Utf8 Class Initialized
INFO - 2023-04-26 09:21:02 --> URI Class Initialized
INFO - 2023-04-26 09:21:02 --> Router Class Initialized
INFO - 2023-04-26 09:21:02 --> Output Class Initialized
INFO - 2023-04-26 09:21:02 --> Security Class Initialized
DEBUG - 2023-04-26 09:21:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-26 09:21:02 --> Input Class Initialized
INFO - 2023-04-26 09:21:02 --> Language Class Initialized
INFO - 2023-04-26 09:21:02 --> Loader Class Initialized
INFO - 2023-04-26 09:21:02 --> Helper loaded: url_helper
INFO - 2023-04-26 09:21:02 --> Helper loaded: file_helper
INFO - 2023-04-26 09:21:02 --> Helper loaded: html_helper
INFO - 2023-04-26 09:21:02 --> Helper loaded: text_helper
INFO - 2023-04-26 09:21:02 --> Helper loaded: form_helper
INFO - 2023-04-26 09:21:02 --> Helper loaded: lang_helper
INFO - 2023-04-26 09:21:02 --> Helper loaded: security_helper
INFO - 2023-04-26 09:21:02 --> Helper loaded: cookie_helper
INFO - 2023-04-26 09:21:02 --> Database Driver Class Initialized
INFO - 2023-04-26 09:21:02 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-26 09:21:02 --> Parser Class Initialized
INFO - 2023-04-26 09:21:02 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-26 09:21:02 --> Pagination Class Initialized
INFO - 2023-04-26 09:21:02 --> Form Validation Class Initialized
INFO - 2023-04-26 09:21:02 --> Controller Class Initialized
INFO - 2023-04-26 09:21:02 --> Model Class Initialized
INFO - 2023-04-26 09:21:02 --> Model Class Initialized
INFO - 2023-04-26 09:21:02 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/report/stock_report.php
DEBUG - 2023-04-26 09:21:02 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-04-26 09:21:02 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-04-26 09:21:02 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-04-26 09:21:02 --> Model Class Initialized
INFO - 2023-04-26 09:21:02 --> Model Class Initialized
INFO - 2023-04-26 09:21:02 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-04-26 09:21:02 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-04-26 09:21:02 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-04-26 09:21:02 --> Final output sent to browser
DEBUG - 2023-04-26 09:21:02 --> Total execution time: 0.1461
ERROR - 2023-04-26 09:21:02 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-26 09:21:02 --> Config Class Initialized
INFO - 2023-04-26 09:21:02 --> Hooks Class Initialized
DEBUG - 2023-04-26 09:21:02 --> UTF-8 Support Enabled
INFO - 2023-04-26 09:21:02 --> Utf8 Class Initialized
INFO - 2023-04-26 09:21:02 --> URI Class Initialized
INFO - 2023-04-26 09:21:02 --> Router Class Initialized
INFO - 2023-04-26 09:21:02 --> Output Class Initialized
INFO - 2023-04-26 09:21:02 --> Security Class Initialized
DEBUG - 2023-04-26 09:21:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-26 09:21:02 --> Input Class Initialized
INFO - 2023-04-26 09:21:02 --> Language Class Initialized
INFO - 2023-04-26 09:21:02 --> Loader Class Initialized
INFO - 2023-04-26 09:21:02 --> Helper loaded: url_helper
INFO - 2023-04-26 09:21:02 --> Helper loaded: file_helper
INFO - 2023-04-26 09:21:02 --> Helper loaded: html_helper
INFO - 2023-04-26 09:21:02 --> Helper loaded: text_helper
INFO - 2023-04-26 09:21:02 --> Helper loaded: form_helper
INFO - 2023-04-26 09:21:02 --> Helper loaded: lang_helper
INFO - 2023-04-26 09:21:02 --> Helper loaded: security_helper
INFO - 2023-04-26 09:21:02 --> Helper loaded: cookie_helper
INFO - 2023-04-26 09:21:02 --> Database Driver Class Initialized
INFO - 2023-04-26 09:21:02 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-26 09:21:02 --> Parser Class Initialized
INFO - 2023-04-26 09:21:02 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-26 09:21:02 --> Pagination Class Initialized
INFO - 2023-04-26 09:21:02 --> Form Validation Class Initialized
INFO - 2023-04-26 09:21:02 --> Controller Class Initialized
INFO - 2023-04-26 09:21:02 --> Model Class Initialized
INFO - 2023-04-26 09:21:02 --> Model Class Initialized
INFO - 2023-04-26 09:21:02 --> Final output sent to browser
DEBUG - 2023-04-26 09:21:02 --> Total execution time: 0.0186
ERROR - 2023-04-26 09:21:07 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-26 09:21:07 --> Config Class Initialized
INFO - 2023-04-26 09:21:07 --> Hooks Class Initialized
DEBUG - 2023-04-26 09:21:07 --> UTF-8 Support Enabled
INFO - 2023-04-26 09:21:07 --> Utf8 Class Initialized
INFO - 2023-04-26 09:21:07 --> URI Class Initialized
INFO - 2023-04-26 09:21:07 --> Router Class Initialized
INFO - 2023-04-26 09:21:07 --> Output Class Initialized
INFO - 2023-04-26 09:21:07 --> Security Class Initialized
DEBUG - 2023-04-26 09:21:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-26 09:21:07 --> Input Class Initialized
INFO - 2023-04-26 09:21:07 --> Language Class Initialized
INFO - 2023-04-26 09:21:07 --> Loader Class Initialized
INFO - 2023-04-26 09:21:07 --> Helper loaded: url_helper
INFO - 2023-04-26 09:21:07 --> Helper loaded: file_helper
INFO - 2023-04-26 09:21:07 --> Helper loaded: html_helper
INFO - 2023-04-26 09:21:07 --> Helper loaded: text_helper
INFO - 2023-04-26 09:21:07 --> Helper loaded: form_helper
INFO - 2023-04-26 09:21:07 --> Helper loaded: lang_helper
INFO - 2023-04-26 09:21:07 --> Helper loaded: security_helper
INFO - 2023-04-26 09:21:07 --> Helper loaded: cookie_helper
INFO - 2023-04-26 09:21:07 --> Database Driver Class Initialized
INFO - 2023-04-26 09:21:07 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-26 09:21:07 --> Parser Class Initialized
INFO - 2023-04-26 09:21:07 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-26 09:21:07 --> Pagination Class Initialized
INFO - 2023-04-26 09:21:07 --> Form Validation Class Initialized
INFO - 2023-04-26 09:21:07 --> Controller Class Initialized
INFO - 2023-04-26 09:21:07 --> Model Class Initialized
INFO - 2023-04-26 09:21:07 --> Model Class Initialized
INFO - 2023-04-26 09:21:07 --> Final output sent to browser
DEBUG - 2023-04-26 09:21:07 --> Total execution time: 0.0224
ERROR - 2023-04-26 09:21:13 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-26 09:21:13 --> Config Class Initialized
INFO - 2023-04-26 09:21:13 --> Hooks Class Initialized
DEBUG - 2023-04-26 09:21:13 --> UTF-8 Support Enabled
INFO - 2023-04-26 09:21:13 --> Utf8 Class Initialized
INFO - 2023-04-26 09:21:13 --> URI Class Initialized
INFO - 2023-04-26 09:21:13 --> Router Class Initialized
INFO - 2023-04-26 09:21:13 --> Output Class Initialized
INFO - 2023-04-26 09:21:13 --> Security Class Initialized
DEBUG - 2023-04-26 09:21:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-26 09:21:13 --> Input Class Initialized
INFO - 2023-04-26 09:21:13 --> Language Class Initialized
INFO - 2023-04-26 09:21:13 --> Loader Class Initialized
INFO - 2023-04-26 09:21:13 --> Helper loaded: url_helper
INFO - 2023-04-26 09:21:13 --> Helper loaded: file_helper
INFO - 2023-04-26 09:21:13 --> Helper loaded: html_helper
INFO - 2023-04-26 09:21:13 --> Helper loaded: text_helper
INFO - 2023-04-26 09:21:13 --> Helper loaded: form_helper
INFO - 2023-04-26 09:21:13 --> Helper loaded: lang_helper
INFO - 2023-04-26 09:21:13 --> Helper loaded: security_helper
INFO - 2023-04-26 09:21:13 --> Helper loaded: cookie_helper
INFO - 2023-04-26 09:21:13 --> Database Driver Class Initialized
INFO - 2023-04-26 09:21:13 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-26 09:21:13 --> Parser Class Initialized
INFO - 2023-04-26 09:21:13 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-26 09:21:13 --> Pagination Class Initialized
INFO - 2023-04-26 09:21:13 --> Form Validation Class Initialized
INFO - 2023-04-26 09:21:13 --> Controller Class Initialized
DEBUG - 2023-04-26 09:21:13 --> Auth class already loaded. Second attempt ignored.
INFO - 2023-04-26 09:21:13 --> Model Class Initialized
INFO - 2023-04-26 09:21:13 --> Model Class Initialized
INFO - 2023-04-26 09:21:13 --> Model Class Initialized
INFO - 2023-04-26 09:21:13 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/product/product_details.php
DEBUG - 2023-04-26 09:21:13 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-04-26 09:21:13 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-04-26 09:21:13 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-04-26 09:21:13 --> Model Class Initialized
INFO - 2023-04-26 09:21:13 --> Model Class Initialized
INFO - 2023-04-26 09:21:13 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-04-26 09:21:13 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-04-26 09:21:13 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-04-26 09:21:13 --> Final output sent to browser
DEBUG - 2023-04-26 09:21:13 --> Total execution time: 0.1997
ERROR - 2023-04-26 09:21:34 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-26 09:21:34 --> Config Class Initialized
INFO - 2023-04-26 09:21:34 --> Hooks Class Initialized
DEBUG - 2023-04-26 09:21:34 --> UTF-8 Support Enabled
INFO - 2023-04-26 09:21:34 --> Utf8 Class Initialized
INFO - 2023-04-26 09:21:34 --> URI Class Initialized
INFO - 2023-04-26 09:21:34 --> Router Class Initialized
INFO - 2023-04-26 09:21:34 --> Output Class Initialized
INFO - 2023-04-26 09:21:34 --> Security Class Initialized
DEBUG - 2023-04-26 09:21:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-26 09:21:34 --> Input Class Initialized
INFO - 2023-04-26 09:21:34 --> Language Class Initialized
INFO - 2023-04-26 09:21:34 --> Loader Class Initialized
INFO - 2023-04-26 09:21:34 --> Helper loaded: url_helper
INFO - 2023-04-26 09:21:34 --> Helper loaded: file_helper
INFO - 2023-04-26 09:21:34 --> Helper loaded: html_helper
INFO - 2023-04-26 09:21:34 --> Helper loaded: text_helper
INFO - 2023-04-26 09:21:34 --> Helper loaded: form_helper
INFO - 2023-04-26 09:21:34 --> Helper loaded: lang_helper
INFO - 2023-04-26 09:21:34 --> Helper loaded: security_helper
INFO - 2023-04-26 09:21:34 --> Helper loaded: cookie_helper
INFO - 2023-04-26 09:21:34 --> Database Driver Class Initialized
INFO - 2023-04-26 09:21:34 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-26 09:21:34 --> Parser Class Initialized
INFO - 2023-04-26 09:21:34 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-26 09:21:34 --> Pagination Class Initialized
INFO - 2023-04-26 09:21:34 --> Form Validation Class Initialized
INFO - 2023-04-26 09:21:34 --> Controller Class Initialized
DEBUG - 2023-04-26 09:21:34 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-04-26 09:21:34 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-26 09:21:34 --> Model Class Initialized
DEBUG - 2023-04-26 09:21:34 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-26 09:21:34 --> Model Class Initialized
INFO - 2023-04-26 09:21:34 --> Model Class Initialized
INFO - 2023-04-26 09:21:34 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/customer/customer_details.php
DEBUG - 2023-04-26 09:21:34 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-04-26 09:21:34 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-04-26 09:21:34 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-04-26 09:21:34 --> Model Class Initialized
INFO - 2023-04-26 09:21:34 --> Model Class Initialized
INFO - 2023-04-26 09:21:34 --> Model Class Initialized
INFO - 2023-04-26 09:21:34 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-04-26 09:21:34 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-04-26 09:21:34 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-04-26 09:21:34 --> Final output sent to browser
DEBUG - 2023-04-26 09:21:34 --> Total execution time: 0.1596
ERROR - 2023-04-26 09:21:47 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-26 09:21:47 --> Config Class Initialized
INFO - 2023-04-26 09:21:47 --> Hooks Class Initialized
DEBUG - 2023-04-26 09:21:47 --> UTF-8 Support Enabled
INFO - 2023-04-26 09:21:47 --> Utf8 Class Initialized
INFO - 2023-04-26 09:21:47 --> URI Class Initialized
INFO - 2023-04-26 09:21:47 --> Router Class Initialized
INFO - 2023-04-26 09:21:47 --> Output Class Initialized
INFO - 2023-04-26 09:21:47 --> Security Class Initialized
DEBUG - 2023-04-26 09:21:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-26 09:21:47 --> Input Class Initialized
INFO - 2023-04-26 09:21:47 --> Language Class Initialized
INFO - 2023-04-26 09:21:47 --> Loader Class Initialized
INFO - 2023-04-26 09:21:47 --> Helper loaded: url_helper
INFO - 2023-04-26 09:21:47 --> Helper loaded: file_helper
INFO - 2023-04-26 09:21:47 --> Helper loaded: html_helper
INFO - 2023-04-26 09:21:47 --> Helper loaded: text_helper
INFO - 2023-04-26 09:21:47 --> Helper loaded: form_helper
INFO - 2023-04-26 09:21:47 --> Helper loaded: lang_helper
INFO - 2023-04-26 09:21:47 --> Helper loaded: security_helper
INFO - 2023-04-26 09:21:47 --> Helper loaded: cookie_helper
INFO - 2023-04-26 09:21:47 --> Database Driver Class Initialized
INFO - 2023-04-26 09:21:47 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-26 09:21:47 --> Parser Class Initialized
INFO - 2023-04-26 09:21:47 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-26 09:21:47 --> Pagination Class Initialized
INFO - 2023-04-26 09:21:47 --> Form Validation Class Initialized
INFO - 2023-04-26 09:21:47 --> Controller Class Initialized
INFO - 2023-04-26 09:21:47 --> Model Class Initialized
DEBUG - 2023-04-26 09:21:47 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-04-26 09:21:47 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-26 09:21:47 --> Model Class Initialized
DEBUG - 2023-04-26 09:21:47 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-26 09:21:47 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/stockrequest/add_stockrequest_form.php
DEBUG - 2023-04-26 09:21:47 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-04-26 09:21:47 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-04-26 09:21:47 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-04-26 09:21:47 --> Model Class Initialized
INFO - 2023-04-26 09:21:47 --> Model Class Initialized
INFO - 2023-04-26 09:21:47 --> Model Class Initialized
INFO - 2023-04-26 09:21:47 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-04-26 09:21:47 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-04-26 09:21:47 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-04-26 09:21:47 --> Final output sent to browser
DEBUG - 2023-04-26 09:21:47 --> Total execution time: 0.1650
ERROR - 2023-04-26 09:21:50 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-26 09:21:50 --> Config Class Initialized
INFO - 2023-04-26 09:21:50 --> Hooks Class Initialized
DEBUG - 2023-04-26 09:21:50 --> UTF-8 Support Enabled
INFO - 2023-04-26 09:21:50 --> Utf8 Class Initialized
INFO - 2023-04-26 09:21:50 --> URI Class Initialized
INFO - 2023-04-26 09:21:50 --> Router Class Initialized
INFO - 2023-04-26 09:21:50 --> Output Class Initialized
INFO - 2023-04-26 09:21:50 --> Security Class Initialized
DEBUG - 2023-04-26 09:21:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-26 09:21:50 --> Input Class Initialized
INFO - 2023-04-26 09:21:50 --> Language Class Initialized
INFO - 2023-04-26 09:21:50 --> Loader Class Initialized
INFO - 2023-04-26 09:21:50 --> Helper loaded: url_helper
INFO - 2023-04-26 09:21:50 --> Helper loaded: file_helper
INFO - 2023-04-26 09:21:50 --> Helper loaded: html_helper
INFO - 2023-04-26 09:21:50 --> Helper loaded: text_helper
INFO - 2023-04-26 09:21:50 --> Helper loaded: form_helper
INFO - 2023-04-26 09:21:50 --> Helper loaded: lang_helper
INFO - 2023-04-26 09:21:50 --> Helper loaded: security_helper
INFO - 2023-04-26 09:21:50 --> Helper loaded: cookie_helper
INFO - 2023-04-26 09:21:50 --> Database Driver Class Initialized
INFO - 2023-04-26 09:21:50 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-26 09:21:50 --> Parser Class Initialized
INFO - 2023-04-26 09:21:50 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-26 09:21:50 --> Pagination Class Initialized
INFO - 2023-04-26 09:21:50 --> Form Validation Class Initialized
INFO - 2023-04-26 09:21:50 --> Controller Class Initialized
INFO - 2023-04-26 09:21:50 --> Model Class Initialized
INFO - 2023-04-26 09:21:50 --> Final output sent to browser
DEBUG - 2023-04-26 09:21:50 --> Total execution time: 0.0137
ERROR - 2023-04-26 09:21:52 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-26 09:21:52 --> Config Class Initialized
INFO - 2023-04-26 09:21:52 --> Hooks Class Initialized
DEBUG - 2023-04-26 09:21:52 --> UTF-8 Support Enabled
INFO - 2023-04-26 09:21:52 --> Utf8 Class Initialized
INFO - 2023-04-26 09:21:52 --> URI Class Initialized
INFO - 2023-04-26 09:21:52 --> Router Class Initialized
INFO - 2023-04-26 09:21:52 --> Output Class Initialized
INFO - 2023-04-26 09:21:52 --> Security Class Initialized
DEBUG - 2023-04-26 09:21:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-26 09:21:52 --> Input Class Initialized
INFO - 2023-04-26 09:21:52 --> Language Class Initialized
INFO - 2023-04-26 09:21:52 --> Loader Class Initialized
INFO - 2023-04-26 09:21:52 --> Helper loaded: url_helper
INFO - 2023-04-26 09:21:52 --> Helper loaded: file_helper
INFO - 2023-04-26 09:21:52 --> Helper loaded: html_helper
INFO - 2023-04-26 09:21:52 --> Helper loaded: text_helper
INFO - 2023-04-26 09:21:52 --> Helper loaded: form_helper
INFO - 2023-04-26 09:21:52 --> Helper loaded: lang_helper
INFO - 2023-04-26 09:21:52 --> Helper loaded: security_helper
INFO - 2023-04-26 09:21:52 --> Helper loaded: cookie_helper
INFO - 2023-04-26 09:21:52 --> Database Driver Class Initialized
INFO - 2023-04-26 09:21:52 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-26 09:21:52 --> Parser Class Initialized
INFO - 2023-04-26 09:21:52 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-26 09:21:52 --> Pagination Class Initialized
INFO - 2023-04-26 09:21:52 --> Form Validation Class Initialized
INFO - 2023-04-26 09:21:52 --> Controller Class Initialized
INFO - 2023-04-26 09:21:52 --> Model Class Initialized
INFO - 2023-04-26 09:21:52 --> Final output sent to browser
DEBUG - 2023-04-26 09:21:52 --> Total execution time: 0.0132
ERROR - 2023-04-26 09:21:52 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-26 09:21:52 --> Config Class Initialized
INFO - 2023-04-26 09:21:52 --> Hooks Class Initialized
DEBUG - 2023-04-26 09:21:52 --> UTF-8 Support Enabled
INFO - 2023-04-26 09:21:52 --> Utf8 Class Initialized
INFO - 2023-04-26 09:21:52 --> URI Class Initialized
INFO - 2023-04-26 09:21:52 --> Router Class Initialized
INFO - 2023-04-26 09:21:52 --> Output Class Initialized
INFO - 2023-04-26 09:21:52 --> Security Class Initialized
DEBUG - 2023-04-26 09:21:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-26 09:21:52 --> Input Class Initialized
INFO - 2023-04-26 09:21:52 --> Language Class Initialized
INFO - 2023-04-26 09:21:52 --> Loader Class Initialized
INFO - 2023-04-26 09:21:52 --> Helper loaded: url_helper
INFO - 2023-04-26 09:21:52 --> Helper loaded: file_helper
INFO - 2023-04-26 09:21:52 --> Helper loaded: html_helper
INFO - 2023-04-26 09:21:52 --> Helper loaded: text_helper
INFO - 2023-04-26 09:21:52 --> Helper loaded: form_helper
INFO - 2023-04-26 09:21:52 --> Helper loaded: lang_helper
INFO - 2023-04-26 09:21:52 --> Helper loaded: security_helper
INFO - 2023-04-26 09:21:52 --> Helper loaded: cookie_helper
INFO - 2023-04-26 09:21:52 --> Database Driver Class Initialized
INFO - 2023-04-26 09:21:52 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-26 09:21:52 --> Parser Class Initialized
INFO - 2023-04-26 09:21:52 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-26 09:21:52 --> Pagination Class Initialized
INFO - 2023-04-26 09:21:52 --> Form Validation Class Initialized
INFO - 2023-04-26 09:21:52 --> Controller Class Initialized
INFO - 2023-04-26 09:21:52 --> Model Class Initialized
INFO - 2023-04-26 09:21:52 --> Final output sent to browser
DEBUG - 2023-04-26 09:21:52 --> Total execution time: 0.0137
ERROR - 2023-04-26 09:21:57 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-26 09:21:57 --> Config Class Initialized
INFO - 2023-04-26 09:21:57 --> Hooks Class Initialized
DEBUG - 2023-04-26 09:21:57 --> UTF-8 Support Enabled
INFO - 2023-04-26 09:21:57 --> Utf8 Class Initialized
INFO - 2023-04-26 09:21:57 --> URI Class Initialized
INFO - 2023-04-26 09:21:57 --> Router Class Initialized
INFO - 2023-04-26 09:21:57 --> Output Class Initialized
INFO - 2023-04-26 09:21:57 --> Security Class Initialized
DEBUG - 2023-04-26 09:21:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-26 09:21:57 --> Input Class Initialized
INFO - 2023-04-26 09:21:57 --> Language Class Initialized
INFO - 2023-04-26 09:21:57 --> Loader Class Initialized
INFO - 2023-04-26 09:21:57 --> Helper loaded: url_helper
INFO - 2023-04-26 09:21:57 --> Helper loaded: file_helper
INFO - 2023-04-26 09:21:57 --> Helper loaded: html_helper
INFO - 2023-04-26 09:21:57 --> Helper loaded: text_helper
INFO - 2023-04-26 09:21:57 --> Helper loaded: form_helper
INFO - 2023-04-26 09:21:57 --> Helper loaded: lang_helper
INFO - 2023-04-26 09:21:57 --> Helper loaded: security_helper
INFO - 2023-04-26 09:21:57 --> Helper loaded: cookie_helper
INFO - 2023-04-26 09:21:57 --> Database Driver Class Initialized
INFO - 2023-04-26 09:21:57 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-26 09:21:57 --> Parser Class Initialized
INFO - 2023-04-26 09:21:57 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-26 09:21:57 --> Pagination Class Initialized
INFO - 2023-04-26 09:21:57 --> Form Validation Class Initialized
INFO - 2023-04-26 09:21:57 --> Controller Class Initialized
INFO - 2023-04-26 09:21:57 --> Model Class Initialized
DEBUG - 2023-04-26 09:21:57 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-04-26 09:21:57 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-26 09:21:57 --> Model Class Initialized
DEBUG - 2023-04-26 09:21:57 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-26 09:21:57 --> Model Class Initialized
INFO - 2023-04-26 09:21:57 --> Final output sent to browser
DEBUG - 2023-04-26 09:21:57 --> Total execution time: 0.0171
ERROR - 2023-04-26 09:21:57 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-26 09:21:57 --> Config Class Initialized
INFO - 2023-04-26 09:21:57 --> Hooks Class Initialized
DEBUG - 2023-04-26 09:21:57 --> UTF-8 Support Enabled
INFO - 2023-04-26 09:21:57 --> Utf8 Class Initialized
INFO - 2023-04-26 09:21:57 --> URI Class Initialized
INFO - 2023-04-26 09:21:57 --> Router Class Initialized
INFO - 2023-04-26 09:21:57 --> Output Class Initialized
INFO - 2023-04-26 09:21:57 --> Security Class Initialized
DEBUG - 2023-04-26 09:21:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-26 09:21:57 --> Input Class Initialized
INFO - 2023-04-26 09:21:57 --> Language Class Initialized
INFO - 2023-04-26 09:21:57 --> Loader Class Initialized
INFO - 2023-04-26 09:21:57 --> Helper loaded: url_helper
INFO - 2023-04-26 09:21:57 --> Helper loaded: file_helper
INFO - 2023-04-26 09:21:57 --> Helper loaded: html_helper
INFO - 2023-04-26 09:21:57 --> Helper loaded: text_helper
INFO - 2023-04-26 09:21:57 --> Helper loaded: form_helper
INFO - 2023-04-26 09:21:57 --> Helper loaded: lang_helper
INFO - 2023-04-26 09:21:57 --> Helper loaded: security_helper
INFO - 2023-04-26 09:21:57 --> Helper loaded: cookie_helper
INFO - 2023-04-26 09:21:57 --> Database Driver Class Initialized
INFO - 2023-04-26 09:21:57 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-26 09:21:57 --> Parser Class Initialized
INFO - 2023-04-26 09:21:57 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-26 09:21:57 --> Pagination Class Initialized
INFO - 2023-04-26 09:21:57 --> Form Validation Class Initialized
INFO - 2023-04-26 09:21:57 --> Controller Class Initialized
INFO - 2023-04-26 09:21:57 --> Model Class Initialized
DEBUG - 2023-04-26 09:21:57 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-04-26 09:21:57 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-26 09:21:57 --> Model Class Initialized
DEBUG - 2023-04-26 09:21:57 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-26 09:21:57 --> Model Class Initialized
INFO - 2023-04-26 09:21:57 --> Final output sent to browser
DEBUG - 2023-04-26 09:21:57 --> Total execution time: 0.0175
ERROR - 2023-04-26 09:21:58 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-26 09:21:58 --> Config Class Initialized
INFO - 2023-04-26 09:21:58 --> Hooks Class Initialized
DEBUG - 2023-04-26 09:21:58 --> UTF-8 Support Enabled
INFO - 2023-04-26 09:21:58 --> Utf8 Class Initialized
INFO - 2023-04-26 09:21:58 --> URI Class Initialized
INFO - 2023-04-26 09:21:58 --> Router Class Initialized
INFO - 2023-04-26 09:21:58 --> Output Class Initialized
INFO - 2023-04-26 09:21:58 --> Security Class Initialized
DEBUG - 2023-04-26 09:21:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-26 09:21:58 --> Input Class Initialized
INFO - 2023-04-26 09:21:58 --> Language Class Initialized
INFO - 2023-04-26 09:21:58 --> Loader Class Initialized
INFO - 2023-04-26 09:21:58 --> Helper loaded: url_helper
INFO - 2023-04-26 09:21:58 --> Helper loaded: file_helper
INFO - 2023-04-26 09:21:58 --> Helper loaded: html_helper
INFO - 2023-04-26 09:21:58 --> Helper loaded: text_helper
INFO - 2023-04-26 09:21:58 --> Helper loaded: form_helper
INFO - 2023-04-26 09:21:58 --> Helper loaded: lang_helper
INFO - 2023-04-26 09:21:58 --> Helper loaded: security_helper
INFO - 2023-04-26 09:21:58 --> Helper loaded: cookie_helper
INFO - 2023-04-26 09:21:58 --> Database Driver Class Initialized
INFO - 2023-04-26 09:21:58 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-26 09:21:58 --> Parser Class Initialized
INFO - 2023-04-26 09:21:58 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-26 09:21:58 --> Pagination Class Initialized
INFO - 2023-04-26 09:21:58 --> Form Validation Class Initialized
INFO - 2023-04-26 09:21:58 --> Controller Class Initialized
INFO - 2023-04-26 09:21:58 --> Model Class Initialized
DEBUG - 2023-04-26 09:21:58 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-04-26 09:21:58 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-26 09:21:58 --> Model Class Initialized
DEBUG - 2023-04-26 09:21:58 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-26 09:21:58 --> Model Class Initialized
INFO - 2023-04-26 09:21:58 --> Final output sent to browser
DEBUG - 2023-04-26 09:21:58 --> Total execution time: 0.0176
ERROR - 2023-04-26 09:21:59 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-26 09:21:59 --> Config Class Initialized
INFO - 2023-04-26 09:21:59 --> Hooks Class Initialized
DEBUG - 2023-04-26 09:21:59 --> UTF-8 Support Enabled
INFO - 2023-04-26 09:21:59 --> Utf8 Class Initialized
INFO - 2023-04-26 09:21:59 --> URI Class Initialized
INFO - 2023-04-26 09:21:59 --> Router Class Initialized
INFO - 2023-04-26 09:21:59 --> Output Class Initialized
INFO - 2023-04-26 09:21:59 --> Security Class Initialized
DEBUG - 2023-04-26 09:21:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-26 09:21:59 --> Input Class Initialized
INFO - 2023-04-26 09:21:59 --> Language Class Initialized
INFO - 2023-04-26 09:21:59 --> Loader Class Initialized
INFO - 2023-04-26 09:21:59 --> Helper loaded: url_helper
INFO - 2023-04-26 09:21:59 --> Helper loaded: file_helper
INFO - 2023-04-26 09:21:59 --> Helper loaded: html_helper
INFO - 2023-04-26 09:21:59 --> Helper loaded: text_helper
INFO - 2023-04-26 09:21:59 --> Helper loaded: form_helper
INFO - 2023-04-26 09:21:59 --> Helper loaded: lang_helper
INFO - 2023-04-26 09:21:59 --> Helper loaded: security_helper
INFO - 2023-04-26 09:21:59 --> Helper loaded: cookie_helper
INFO - 2023-04-26 09:21:59 --> Database Driver Class Initialized
INFO - 2023-04-26 09:21:59 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-26 09:21:59 --> Parser Class Initialized
INFO - 2023-04-26 09:21:59 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-26 09:21:59 --> Pagination Class Initialized
INFO - 2023-04-26 09:21:59 --> Form Validation Class Initialized
INFO - 2023-04-26 09:21:59 --> Controller Class Initialized
INFO - 2023-04-26 09:21:59 --> Model Class Initialized
DEBUG - 2023-04-26 09:21:59 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-04-26 09:21:59 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-26 09:21:59 --> Model Class Initialized
DEBUG - 2023-04-26 09:21:59 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-26 09:21:59 --> Model Class Initialized
INFO - 2023-04-26 09:21:59 --> Final output sent to browser
DEBUG - 2023-04-26 09:21:59 --> Total execution time: 0.0176
ERROR - 2023-04-26 09:22:00 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-26 09:22:00 --> Config Class Initialized
INFO - 2023-04-26 09:22:00 --> Hooks Class Initialized
DEBUG - 2023-04-26 09:22:00 --> UTF-8 Support Enabled
INFO - 2023-04-26 09:22:00 --> Utf8 Class Initialized
INFO - 2023-04-26 09:22:00 --> URI Class Initialized
INFO - 2023-04-26 09:22:00 --> Router Class Initialized
INFO - 2023-04-26 09:22:00 --> Output Class Initialized
INFO - 2023-04-26 09:22:00 --> Security Class Initialized
DEBUG - 2023-04-26 09:22:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-26 09:22:00 --> Input Class Initialized
INFO - 2023-04-26 09:22:00 --> Language Class Initialized
INFO - 2023-04-26 09:22:00 --> Loader Class Initialized
INFO - 2023-04-26 09:22:00 --> Helper loaded: url_helper
INFO - 2023-04-26 09:22:00 --> Helper loaded: file_helper
INFO - 2023-04-26 09:22:00 --> Helper loaded: html_helper
INFO - 2023-04-26 09:22:00 --> Helper loaded: text_helper
INFO - 2023-04-26 09:22:00 --> Helper loaded: form_helper
INFO - 2023-04-26 09:22:00 --> Helper loaded: lang_helper
INFO - 2023-04-26 09:22:00 --> Helper loaded: security_helper
INFO - 2023-04-26 09:22:00 --> Helper loaded: cookie_helper
INFO - 2023-04-26 09:22:00 --> Database Driver Class Initialized
INFO - 2023-04-26 09:22:00 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-26 09:22:00 --> Parser Class Initialized
INFO - 2023-04-26 09:22:00 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-26 09:22:00 --> Pagination Class Initialized
INFO - 2023-04-26 09:22:00 --> Form Validation Class Initialized
INFO - 2023-04-26 09:22:00 --> Controller Class Initialized
INFO - 2023-04-26 09:22:00 --> Model Class Initialized
DEBUG - 2023-04-26 09:22:00 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-04-26 09:22:00 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-26 09:22:00 --> Model Class Initialized
DEBUG - 2023-04-26 09:22:00 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-26 09:22:00 --> Model Class Initialized
INFO - 2023-04-26 09:22:00 --> Final output sent to browser
DEBUG - 2023-04-26 09:22:00 --> Total execution time: 0.0168
ERROR - 2023-04-26 09:22:02 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-26 09:22:02 --> Config Class Initialized
INFO - 2023-04-26 09:22:02 --> Hooks Class Initialized
DEBUG - 2023-04-26 09:22:02 --> UTF-8 Support Enabled
INFO - 2023-04-26 09:22:02 --> Utf8 Class Initialized
INFO - 2023-04-26 09:22:02 --> URI Class Initialized
INFO - 2023-04-26 09:22:02 --> Router Class Initialized
INFO - 2023-04-26 09:22:02 --> Output Class Initialized
INFO - 2023-04-26 09:22:02 --> Security Class Initialized
DEBUG - 2023-04-26 09:22:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-26 09:22:02 --> Input Class Initialized
INFO - 2023-04-26 09:22:02 --> Language Class Initialized
INFO - 2023-04-26 09:22:02 --> Loader Class Initialized
INFO - 2023-04-26 09:22:02 --> Helper loaded: url_helper
INFO - 2023-04-26 09:22:02 --> Helper loaded: file_helper
INFO - 2023-04-26 09:22:02 --> Helper loaded: html_helper
INFO - 2023-04-26 09:22:02 --> Helper loaded: text_helper
INFO - 2023-04-26 09:22:02 --> Helper loaded: form_helper
INFO - 2023-04-26 09:22:02 --> Helper loaded: lang_helper
INFO - 2023-04-26 09:22:02 --> Helper loaded: security_helper
INFO - 2023-04-26 09:22:02 --> Helper loaded: cookie_helper
INFO - 2023-04-26 09:22:02 --> Database Driver Class Initialized
INFO - 2023-04-26 09:22:02 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-26 09:22:02 --> Parser Class Initialized
INFO - 2023-04-26 09:22:02 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-26 09:22:02 --> Pagination Class Initialized
INFO - 2023-04-26 09:22:02 --> Form Validation Class Initialized
INFO - 2023-04-26 09:22:02 --> Controller Class Initialized
INFO - 2023-04-26 09:22:02 --> Model Class Initialized
DEBUG - 2023-04-26 09:22:02 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-04-26 09:22:02 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-26 09:22:02 --> Model Class Initialized
DEBUG - 2023-04-26 09:22:02 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-26 09:22:02 --> Model Class Initialized
INFO - 2023-04-26 09:22:02 --> Final output sent to browser
DEBUG - 2023-04-26 09:22:02 --> Total execution time: 0.0173
ERROR - 2023-04-26 09:22:03 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-26 09:22:03 --> Config Class Initialized
INFO - 2023-04-26 09:22:03 --> Hooks Class Initialized
DEBUG - 2023-04-26 09:22:03 --> UTF-8 Support Enabled
INFO - 2023-04-26 09:22:03 --> Utf8 Class Initialized
INFO - 2023-04-26 09:22:03 --> URI Class Initialized
INFO - 2023-04-26 09:22:03 --> Router Class Initialized
INFO - 2023-04-26 09:22:03 --> Output Class Initialized
INFO - 2023-04-26 09:22:03 --> Security Class Initialized
DEBUG - 2023-04-26 09:22:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-26 09:22:03 --> Input Class Initialized
INFO - 2023-04-26 09:22:03 --> Language Class Initialized
INFO - 2023-04-26 09:22:03 --> Loader Class Initialized
INFO - 2023-04-26 09:22:03 --> Helper loaded: url_helper
INFO - 2023-04-26 09:22:03 --> Helper loaded: file_helper
INFO - 2023-04-26 09:22:03 --> Helper loaded: html_helper
INFO - 2023-04-26 09:22:03 --> Helper loaded: text_helper
INFO - 2023-04-26 09:22:03 --> Helper loaded: form_helper
INFO - 2023-04-26 09:22:03 --> Helper loaded: lang_helper
INFO - 2023-04-26 09:22:03 --> Helper loaded: security_helper
INFO - 2023-04-26 09:22:03 --> Helper loaded: cookie_helper
INFO - 2023-04-26 09:22:03 --> Database Driver Class Initialized
INFO - 2023-04-26 09:22:03 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-26 09:22:03 --> Parser Class Initialized
INFO - 2023-04-26 09:22:03 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-26 09:22:03 --> Pagination Class Initialized
INFO - 2023-04-26 09:22:03 --> Form Validation Class Initialized
INFO - 2023-04-26 09:22:03 --> Controller Class Initialized
INFO - 2023-04-26 09:22:03 --> Model Class Initialized
DEBUG - 2023-04-26 09:22:03 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-04-26 09:22:03 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-26 09:22:03 --> Model Class Initialized
DEBUG - 2023-04-26 09:22:03 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-26 09:22:03 --> Model Class Initialized
INFO - 2023-04-26 09:22:03 --> Model Class Initialized
INFO - 2023-04-26 09:22:03 --> Final output sent to browser
DEBUG - 2023-04-26 09:22:03 --> Total execution time: 0.0199
ERROR - 2023-04-26 09:22:06 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-26 09:22:06 --> Config Class Initialized
INFO - 2023-04-26 09:22:06 --> Hooks Class Initialized
DEBUG - 2023-04-26 09:22:06 --> UTF-8 Support Enabled
INFO - 2023-04-26 09:22:06 --> Utf8 Class Initialized
INFO - 2023-04-26 09:22:06 --> URI Class Initialized
INFO - 2023-04-26 09:22:06 --> Router Class Initialized
INFO - 2023-04-26 09:22:06 --> Output Class Initialized
INFO - 2023-04-26 09:22:06 --> Security Class Initialized
DEBUG - 2023-04-26 09:22:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-26 09:22:06 --> Input Class Initialized
INFO - 2023-04-26 09:22:06 --> Language Class Initialized
INFO - 2023-04-26 09:22:06 --> Loader Class Initialized
INFO - 2023-04-26 09:22:06 --> Helper loaded: url_helper
INFO - 2023-04-26 09:22:06 --> Helper loaded: file_helper
INFO - 2023-04-26 09:22:06 --> Helper loaded: html_helper
INFO - 2023-04-26 09:22:06 --> Helper loaded: text_helper
INFO - 2023-04-26 09:22:06 --> Helper loaded: form_helper
INFO - 2023-04-26 09:22:06 --> Helper loaded: lang_helper
INFO - 2023-04-26 09:22:06 --> Helper loaded: security_helper
INFO - 2023-04-26 09:22:06 --> Helper loaded: cookie_helper
INFO - 2023-04-26 09:22:06 --> Database Driver Class Initialized
INFO - 2023-04-26 09:22:06 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-26 09:22:06 --> Parser Class Initialized
INFO - 2023-04-26 09:22:06 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-26 09:22:06 --> Pagination Class Initialized
INFO - 2023-04-26 09:22:06 --> Form Validation Class Initialized
INFO - 2023-04-26 09:22:06 --> Controller Class Initialized
INFO - 2023-04-26 09:22:06 --> Model Class Initialized
DEBUG - 2023-04-26 09:22:06 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-04-26 09:22:06 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-26 09:22:06 --> Model Class Initialized
DEBUG - 2023-04-26 09:22:06 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-26 09:22:06 --> Model Class Initialized
INFO - 2023-04-26 09:22:06 --> Final output sent to browser
DEBUG - 2023-04-26 09:22:06 --> Total execution time: 0.0188
ERROR - 2023-04-26 09:35:03 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-26 09:35:03 --> Config Class Initialized
INFO - 2023-04-26 09:35:03 --> Hooks Class Initialized
DEBUG - 2023-04-26 09:35:03 --> UTF-8 Support Enabled
INFO - 2023-04-26 09:35:03 --> Utf8 Class Initialized
INFO - 2023-04-26 09:35:03 --> URI Class Initialized
INFO - 2023-04-26 09:35:03 --> Router Class Initialized
INFO - 2023-04-26 09:35:03 --> Output Class Initialized
INFO - 2023-04-26 09:35:03 --> Security Class Initialized
DEBUG - 2023-04-26 09:35:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-26 09:35:03 --> Input Class Initialized
INFO - 2023-04-26 09:35:03 --> Language Class Initialized
INFO - 2023-04-26 09:35:03 --> Loader Class Initialized
INFO - 2023-04-26 09:35:03 --> Helper loaded: url_helper
INFO - 2023-04-26 09:35:03 --> Helper loaded: file_helper
INFO - 2023-04-26 09:35:03 --> Helper loaded: html_helper
INFO - 2023-04-26 09:35:03 --> Helper loaded: text_helper
INFO - 2023-04-26 09:35:03 --> Helper loaded: form_helper
INFO - 2023-04-26 09:35:03 --> Helper loaded: lang_helper
INFO - 2023-04-26 09:35:03 --> Helper loaded: security_helper
INFO - 2023-04-26 09:35:03 --> Helper loaded: cookie_helper
INFO - 2023-04-26 09:35:03 --> Database Driver Class Initialized
INFO - 2023-04-26 09:35:03 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-26 09:35:03 --> Parser Class Initialized
INFO - 2023-04-26 09:35:03 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-26 09:35:03 --> Pagination Class Initialized
INFO - 2023-04-26 09:35:03 --> Form Validation Class Initialized
INFO - 2023-04-26 09:35:03 --> Controller Class Initialized
INFO - 2023-04-26 09:35:03 --> Model Class Initialized
DEBUG - 2023-04-26 09:35:03 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-04-26 09:35:03 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-26 09:35:03 --> Model Class Initialized
DEBUG - 2023-04-26 09:35:03 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-26 09:35:03 --> Model Class Initialized
INFO - 2023-04-26 09:35:03 --> Final output sent to browser
DEBUG - 2023-04-26 09:35:03 --> Total execution time: 0.0276
ERROR - 2023-04-26 09:35:03 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-26 09:35:03 --> Config Class Initialized
INFO - 2023-04-26 09:35:03 --> Hooks Class Initialized
DEBUG - 2023-04-26 09:35:03 --> UTF-8 Support Enabled
INFO - 2023-04-26 09:35:03 --> Utf8 Class Initialized
INFO - 2023-04-26 09:35:03 --> URI Class Initialized
INFO - 2023-04-26 09:35:03 --> Router Class Initialized
INFO - 2023-04-26 09:35:03 --> Output Class Initialized
INFO - 2023-04-26 09:35:03 --> Security Class Initialized
DEBUG - 2023-04-26 09:35:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-26 09:35:03 --> Input Class Initialized
INFO - 2023-04-26 09:35:03 --> Language Class Initialized
INFO - 2023-04-26 09:35:03 --> Loader Class Initialized
INFO - 2023-04-26 09:35:03 --> Helper loaded: url_helper
INFO - 2023-04-26 09:35:03 --> Helper loaded: file_helper
INFO - 2023-04-26 09:35:03 --> Helper loaded: html_helper
INFO - 2023-04-26 09:35:03 --> Helper loaded: text_helper
INFO - 2023-04-26 09:35:03 --> Helper loaded: form_helper
INFO - 2023-04-26 09:35:03 --> Helper loaded: lang_helper
INFO - 2023-04-26 09:35:03 --> Helper loaded: security_helper
INFO - 2023-04-26 09:35:03 --> Helper loaded: cookie_helper
INFO - 2023-04-26 09:35:03 --> Database Driver Class Initialized
INFO - 2023-04-26 09:35:03 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-26 09:35:03 --> Parser Class Initialized
INFO - 2023-04-26 09:35:03 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-26 09:35:03 --> Pagination Class Initialized
INFO - 2023-04-26 09:35:03 --> Form Validation Class Initialized
INFO - 2023-04-26 09:35:03 --> Controller Class Initialized
INFO - 2023-04-26 09:35:03 --> Model Class Initialized
DEBUG - 2023-04-26 09:35:03 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-04-26 09:35:03 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-26 09:35:03 --> Model Class Initialized
DEBUG - 2023-04-26 09:35:03 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-26 09:35:03 --> Model Class Initialized
INFO - 2023-04-26 09:35:03 --> Final output sent to browser
DEBUG - 2023-04-26 09:35:03 --> Total execution time: 0.0177
ERROR - 2023-04-26 09:35:04 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-26 09:35:04 --> Config Class Initialized
INFO - 2023-04-26 09:35:04 --> Hooks Class Initialized
DEBUG - 2023-04-26 09:35:04 --> UTF-8 Support Enabled
INFO - 2023-04-26 09:35:04 --> Utf8 Class Initialized
INFO - 2023-04-26 09:35:04 --> URI Class Initialized
INFO - 2023-04-26 09:35:04 --> Router Class Initialized
INFO - 2023-04-26 09:35:04 --> Output Class Initialized
INFO - 2023-04-26 09:35:04 --> Security Class Initialized
DEBUG - 2023-04-26 09:35:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-26 09:35:04 --> Input Class Initialized
INFO - 2023-04-26 09:35:04 --> Language Class Initialized
INFO - 2023-04-26 09:35:04 --> Loader Class Initialized
INFO - 2023-04-26 09:35:04 --> Helper loaded: url_helper
INFO - 2023-04-26 09:35:04 --> Helper loaded: file_helper
INFO - 2023-04-26 09:35:04 --> Helper loaded: html_helper
INFO - 2023-04-26 09:35:04 --> Helper loaded: text_helper
INFO - 2023-04-26 09:35:04 --> Helper loaded: form_helper
INFO - 2023-04-26 09:35:04 --> Helper loaded: lang_helper
INFO - 2023-04-26 09:35:04 --> Helper loaded: security_helper
INFO - 2023-04-26 09:35:04 --> Helper loaded: cookie_helper
INFO - 2023-04-26 09:35:04 --> Database Driver Class Initialized
INFO - 2023-04-26 09:35:04 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-26 09:35:04 --> Parser Class Initialized
INFO - 2023-04-26 09:35:04 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-26 09:35:04 --> Pagination Class Initialized
INFO - 2023-04-26 09:35:04 --> Form Validation Class Initialized
INFO - 2023-04-26 09:35:04 --> Controller Class Initialized
INFO - 2023-04-26 09:35:04 --> Model Class Initialized
DEBUG - 2023-04-26 09:35:04 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-04-26 09:35:04 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-26 09:35:04 --> Model Class Initialized
DEBUG - 2023-04-26 09:35:04 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-26 09:35:04 --> Model Class Initialized
INFO - 2023-04-26 09:35:04 --> Final output sent to browser
DEBUG - 2023-04-26 09:35:04 --> Total execution time: 0.0177
ERROR - 2023-04-26 09:35:07 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-26 09:35:07 --> Config Class Initialized
INFO - 2023-04-26 09:35:07 --> Hooks Class Initialized
DEBUG - 2023-04-26 09:35:07 --> UTF-8 Support Enabled
INFO - 2023-04-26 09:35:07 --> Utf8 Class Initialized
INFO - 2023-04-26 09:35:07 --> URI Class Initialized
INFO - 2023-04-26 09:35:07 --> Router Class Initialized
INFO - 2023-04-26 09:35:07 --> Output Class Initialized
INFO - 2023-04-26 09:35:07 --> Security Class Initialized
DEBUG - 2023-04-26 09:35:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-26 09:35:07 --> Input Class Initialized
INFO - 2023-04-26 09:35:07 --> Language Class Initialized
INFO - 2023-04-26 09:35:07 --> Loader Class Initialized
INFO - 2023-04-26 09:35:07 --> Helper loaded: url_helper
INFO - 2023-04-26 09:35:07 --> Helper loaded: file_helper
INFO - 2023-04-26 09:35:07 --> Helper loaded: html_helper
INFO - 2023-04-26 09:35:07 --> Helper loaded: text_helper
INFO - 2023-04-26 09:35:07 --> Helper loaded: form_helper
INFO - 2023-04-26 09:35:07 --> Helper loaded: lang_helper
INFO - 2023-04-26 09:35:07 --> Helper loaded: security_helper
INFO - 2023-04-26 09:35:07 --> Helper loaded: cookie_helper
INFO - 2023-04-26 09:35:07 --> Database Driver Class Initialized
INFO - 2023-04-26 09:35:07 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-26 09:35:07 --> Parser Class Initialized
INFO - 2023-04-26 09:35:07 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-26 09:35:07 --> Pagination Class Initialized
INFO - 2023-04-26 09:35:07 --> Form Validation Class Initialized
INFO - 2023-04-26 09:35:07 --> Controller Class Initialized
INFO - 2023-04-26 09:35:07 --> Model Class Initialized
DEBUG - 2023-04-26 09:35:07 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-04-26 09:35:07 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-26 09:35:07 --> Model Class Initialized
DEBUG - 2023-04-26 09:35:07 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-26 09:35:07 --> Model Class Initialized
INFO - 2023-04-26 09:35:07 --> Model Class Initialized
INFO - 2023-04-26 09:35:07 --> Final output sent to browser
DEBUG - 2023-04-26 09:35:07 --> Total execution time: 0.0210
ERROR - 2023-04-26 09:35:11 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-26 09:35:11 --> Config Class Initialized
INFO - 2023-04-26 09:35:11 --> Hooks Class Initialized
DEBUG - 2023-04-26 09:35:11 --> UTF-8 Support Enabled
INFO - 2023-04-26 09:35:11 --> Utf8 Class Initialized
INFO - 2023-04-26 09:35:11 --> URI Class Initialized
INFO - 2023-04-26 09:35:11 --> Router Class Initialized
INFO - 2023-04-26 09:35:11 --> Output Class Initialized
INFO - 2023-04-26 09:35:11 --> Security Class Initialized
DEBUG - 2023-04-26 09:35:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-26 09:35:11 --> Input Class Initialized
INFO - 2023-04-26 09:35:11 --> Language Class Initialized
INFO - 2023-04-26 09:35:11 --> Loader Class Initialized
INFO - 2023-04-26 09:35:11 --> Helper loaded: url_helper
INFO - 2023-04-26 09:35:11 --> Helper loaded: file_helper
INFO - 2023-04-26 09:35:11 --> Helper loaded: html_helper
INFO - 2023-04-26 09:35:11 --> Helper loaded: text_helper
INFO - 2023-04-26 09:35:11 --> Helper loaded: form_helper
INFO - 2023-04-26 09:35:11 --> Helper loaded: lang_helper
INFO - 2023-04-26 09:35:11 --> Helper loaded: security_helper
INFO - 2023-04-26 09:35:11 --> Helper loaded: cookie_helper
INFO - 2023-04-26 09:35:11 --> Database Driver Class Initialized
INFO - 2023-04-26 09:35:11 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-26 09:35:11 --> Parser Class Initialized
INFO - 2023-04-26 09:35:11 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-26 09:35:11 --> Pagination Class Initialized
INFO - 2023-04-26 09:35:11 --> Form Validation Class Initialized
INFO - 2023-04-26 09:35:11 --> Controller Class Initialized
INFO - 2023-04-26 09:35:11 --> Model Class Initialized
DEBUG - 2023-04-26 09:35:11 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-04-26 09:35:11 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-26 09:35:11 --> Model Class Initialized
DEBUG - 2023-04-26 09:35:11 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-26 09:35:11 --> Model Class Initialized
INFO - 2023-04-26 09:35:11 --> Final output sent to browser
DEBUG - 2023-04-26 09:35:11 --> Total execution time: 0.0184
ERROR - 2023-04-26 09:35:21 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-26 09:35:21 --> Config Class Initialized
INFO - 2023-04-26 09:35:21 --> Hooks Class Initialized
DEBUG - 2023-04-26 09:35:21 --> UTF-8 Support Enabled
INFO - 2023-04-26 09:35:21 --> Utf8 Class Initialized
INFO - 2023-04-26 09:35:21 --> URI Class Initialized
INFO - 2023-04-26 09:35:21 --> Router Class Initialized
INFO - 2023-04-26 09:35:21 --> Output Class Initialized
INFO - 2023-04-26 09:35:21 --> Security Class Initialized
DEBUG - 2023-04-26 09:35:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-26 09:35:21 --> Input Class Initialized
INFO - 2023-04-26 09:35:21 --> Language Class Initialized
INFO - 2023-04-26 09:35:21 --> Loader Class Initialized
INFO - 2023-04-26 09:35:21 --> Helper loaded: url_helper
INFO - 2023-04-26 09:35:21 --> Helper loaded: file_helper
INFO - 2023-04-26 09:35:21 --> Helper loaded: html_helper
INFO - 2023-04-26 09:35:21 --> Helper loaded: text_helper
INFO - 2023-04-26 09:35:21 --> Helper loaded: form_helper
INFO - 2023-04-26 09:35:21 --> Helper loaded: lang_helper
INFO - 2023-04-26 09:35:21 --> Helper loaded: security_helper
INFO - 2023-04-26 09:35:21 --> Helper loaded: cookie_helper
INFO - 2023-04-26 09:35:21 --> Database Driver Class Initialized
INFO - 2023-04-26 09:35:21 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-26 09:35:21 --> Parser Class Initialized
INFO - 2023-04-26 09:35:21 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-26 09:35:21 --> Pagination Class Initialized
INFO - 2023-04-26 09:35:21 --> Form Validation Class Initialized
INFO - 2023-04-26 09:35:21 --> Controller Class Initialized
INFO - 2023-04-26 09:35:21 --> Model Class Initialized
DEBUG - 2023-04-26 09:35:21 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-04-26 09:35:21 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-26 09:35:21 --> Model Class Initialized
INFO - 2023-04-26 09:35:21 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/stockrequest/upcoming.php
DEBUG - 2023-04-26 09:35:21 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-04-26 09:35:21 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-04-26 09:35:21 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-04-26 09:35:21 --> Model Class Initialized
INFO - 2023-04-26 09:35:21 --> Model Class Initialized
INFO - 2023-04-26 09:35:21 --> Model Class Initialized
INFO - 2023-04-26 09:35:21 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-04-26 09:35:21 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-04-26 09:35:21 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-04-26 09:35:21 --> Final output sent to browser
DEBUG - 2023-04-26 09:35:21 --> Total execution time: 0.1428
ERROR - 2023-04-26 09:35:22 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-26 09:35:22 --> Config Class Initialized
INFO - 2023-04-26 09:35:22 --> Hooks Class Initialized
DEBUG - 2023-04-26 09:35:22 --> UTF-8 Support Enabled
INFO - 2023-04-26 09:35:22 --> Utf8 Class Initialized
INFO - 2023-04-26 09:35:22 --> URI Class Initialized
INFO - 2023-04-26 09:35:22 --> Router Class Initialized
INFO - 2023-04-26 09:35:22 --> Output Class Initialized
INFO - 2023-04-26 09:35:22 --> Security Class Initialized
DEBUG - 2023-04-26 09:35:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-26 09:35:22 --> Input Class Initialized
INFO - 2023-04-26 09:35:22 --> Language Class Initialized
INFO - 2023-04-26 09:35:22 --> Loader Class Initialized
INFO - 2023-04-26 09:35:22 --> Helper loaded: url_helper
INFO - 2023-04-26 09:35:22 --> Helper loaded: file_helper
INFO - 2023-04-26 09:35:22 --> Helper loaded: html_helper
INFO - 2023-04-26 09:35:22 --> Helper loaded: text_helper
INFO - 2023-04-26 09:35:22 --> Helper loaded: form_helper
INFO - 2023-04-26 09:35:22 --> Helper loaded: lang_helper
INFO - 2023-04-26 09:35:22 --> Helper loaded: security_helper
INFO - 2023-04-26 09:35:22 --> Helper loaded: cookie_helper
INFO - 2023-04-26 09:35:22 --> Database Driver Class Initialized
INFO - 2023-04-26 09:35:22 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-26 09:35:22 --> Parser Class Initialized
INFO - 2023-04-26 09:35:22 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-26 09:35:22 --> Pagination Class Initialized
INFO - 2023-04-26 09:35:22 --> Form Validation Class Initialized
INFO - 2023-04-26 09:35:22 --> Controller Class Initialized
INFO - 2023-04-26 09:35:22 --> Model Class Initialized
DEBUG - 2023-04-26 09:35:22 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-04-26 09:35:22 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-26 09:35:22 --> Model Class Initialized
INFO - 2023-04-26 09:35:22 --> Final output sent to browser
DEBUG - 2023-04-26 09:35:22 --> Total execution time: 0.0159
ERROR - 2023-04-26 09:35:23 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-26 09:35:23 --> Config Class Initialized
INFO - 2023-04-26 09:35:23 --> Hooks Class Initialized
DEBUG - 2023-04-26 09:35:23 --> UTF-8 Support Enabled
INFO - 2023-04-26 09:35:23 --> Utf8 Class Initialized
INFO - 2023-04-26 09:35:23 --> URI Class Initialized
INFO - 2023-04-26 09:35:23 --> Router Class Initialized
INFO - 2023-04-26 09:35:23 --> Output Class Initialized
INFO - 2023-04-26 09:35:23 --> Security Class Initialized
DEBUG - 2023-04-26 09:35:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-26 09:35:23 --> Input Class Initialized
INFO - 2023-04-26 09:35:23 --> Language Class Initialized
INFO - 2023-04-26 09:35:23 --> Loader Class Initialized
INFO - 2023-04-26 09:35:23 --> Helper loaded: url_helper
INFO - 2023-04-26 09:35:23 --> Helper loaded: file_helper
INFO - 2023-04-26 09:35:23 --> Helper loaded: html_helper
INFO - 2023-04-26 09:35:23 --> Helper loaded: text_helper
INFO - 2023-04-26 09:35:23 --> Helper loaded: form_helper
INFO - 2023-04-26 09:35:23 --> Helper loaded: lang_helper
INFO - 2023-04-26 09:35:23 --> Helper loaded: security_helper
INFO - 2023-04-26 09:35:23 --> Helper loaded: cookie_helper
INFO - 2023-04-26 09:35:23 --> Database Driver Class Initialized
INFO - 2023-04-26 09:35:23 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-26 09:35:23 --> Parser Class Initialized
INFO - 2023-04-26 09:35:23 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-26 09:35:23 --> Pagination Class Initialized
INFO - 2023-04-26 09:35:23 --> Form Validation Class Initialized
INFO - 2023-04-26 09:35:23 --> Controller Class Initialized
INFO - 2023-04-26 09:35:23 --> Model Class Initialized
DEBUG - 2023-04-26 09:35:23 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-04-26 09:35:23 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-26 09:35:23 --> Model Class Initialized
INFO - 2023-04-26 09:35:23 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/stockrequest/inventory.php
DEBUG - 2023-04-26 09:35:23 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-04-26 09:35:23 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-04-26 09:35:23 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-04-26 09:35:23 --> Model Class Initialized
INFO - 2023-04-26 09:35:23 --> Model Class Initialized
INFO - 2023-04-26 09:35:23 --> Model Class Initialized
INFO - 2023-04-26 09:35:24 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-04-26 09:35:24 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-04-26 09:35:24 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-04-26 09:35:24 --> Final output sent to browser
DEBUG - 2023-04-26 09:35:24 --> Total execution time: 0.1362
ERROR - 2023-04-26 09:35:24 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-26 09:35:24 --> Config Class Initialized
INFO - 2023-04-26 09:35:24 --> Hooks Class Initialized
DEBUG - 2023-04-26 09:35:24 --> UTF-8 Support Enabled
INFO - 2023-04-26 09:35:24 --> Utf8 Class Initialized
INFO - 2023-04-26 09:35:24 --> URI Class Initialized
INFO - 2023-04-26 09:35:24 --> Router Class Initialized
INFO - 2023-04-26 09:35:24 --> Output Class Initialized
INFO - 2023-04-26 09:35:24 --> Security Class Initialized
DEBUG - 2023-04-26 09:35:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-26 09:35:24 --> Input Class Initialized
INFO - 2023-04-26 09:35:24 --> Language Class Initialized
INFO - 2023-04-26 09:35:24 --> Loader Class Initialized
INFO - 2023-04-26 09:35:24 --> Helper loaded: url_helper
INFO - 2023-04-26 09:35:24 --> Helper loaded: file_helper
INFO - 2023-04-26 09:35:24 --> Helper loaded: html_helper
INFO - 2023-04-26 09:35:24 --> Helper loaded: text_helper
INFO - 2023-04-26 09:35:24 --> Helper loaded: form_helper
INFO - 2023-04-26 09:35:24 --> Helper loaded: lang_helper
INFO - 2023-04-26 09:35:24 --> Helper loaded: security_helper
INFO - 2023-04-26 09:35:24 --> Helper loaded: cookie_helper
INFO - 2023-04-26 09:35:24 --> Database Driver Class Initialized
INFO - 2023-04-26 09:35:24 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-26 09:35:24 --> Parser Class Initialized
INFO - 2023-04-26 09:35:24 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-26 09:35:24 --> Pagination Class Initialized
INFO - 2023-04-26 09:35:24 --> Form Validation Class Initialized
INFO - 2023-04-26 09:35:24 --> Controller Class Initialized
INFO - 2023-04-26 09:35:24 --> Model Class Initialized
DEBUG - 2023-04-26 09:35:24 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-04-26 09:35:24 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-26 09:35:24 --> Model Class Initialized
INFO - 2023-04-26 09:35:24 --> Final output sent to browser
DEBUG - 2023-04-26 09:35:24 --> Total execution time: 0.0204
ERROR - 2023-04-26 09:35:28 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-26 09:35:28 --> Config Class Initialized
INFO - 2023-04-26 09:35:28 --> Hooks Class Initialized
DEBUG - 2023-04-26 09:35:28 --> UTF-8 Support Enabled
INFO - 2023-04-26 09:35:28 --> Utf8 Class Initialized
INFO - 2023-04-26 09:35:28 --> URI Class Initialized
INFO - 2023-04-26 09:35:28 --> Router Class Initialized
INFO - 2023-04-26 09:35:28 --> Output Class Initialized
INFO - 2023-04-26 09:35:28 --> Security Class Initialized
DEBUG - 2023-04-26 09:35:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-26 09:35:28 --> Input Class Initialized
INFO - 2023-04-26 09:35:28 --> Language Class Initialized
INFO - 2023-04-26 09:35:28 --> Loader Class Initialized
INFO - 2023-04-26 09:35:28 --> Helper loaded: url_helper
INFO - 2023-04-26 09:35:28 --> Helper loaded: file_helper
INFO - 2023-04-26 09:35:28 --> Helper loaded: html_helper
INFO - 2023-04-26 09:35:28 --> Helper loaded: text_helper
INFO - 2023-04-26 09:35:28 --> Helper loaded: form_helper
INFO - 2023-04-26 09:35:28 --> Helper loaded: lang_helper
INFO - 2023-04-26 09:35:28 --> Helper loaded: security_helper
INFO - 2023-04-26 09:35:28 --> Helper loaded: cookie_helper
INFO - 2023-04-26 09:35:28 --> Database Driver Class Initialized
INFO - 2023-04-26 09:35:28 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-26 09:35:28 --> Parser Class Initialized
INFO - 2023-04-26 09:35:28 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-26 09:35:28 --> Pagination Class Initialized
INFO - 2023-04-26 09:35:28 --> Form Validation Class Initialized
INFO - 2023-04-26 09:35:28 --> Controller Class Initialized
INFO - 2023-04-26 09:35:28 --> Model Class Initialized
DEBUG - 2023-04-26 09:35:28 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-04-26 09:35:28 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-26 09:35:28 --> Model Class Initialized
INFO - 2023-04-26 09:35:28 --> Final output sent to browser
DEBUG - 2023-04-26 09:35:28 --> Total execution time: 0.0202
ERROR - 2023-04-26 10:28:09 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-26 10:28:09 --> Config Class Initialized
INFO - 2023-04-26 10:28:09 --> Hooks Class Initialized
DEBUG - 2023-04-26 10:28:09 --> UTF-8 Support Enabled
INFO - 2023-04-26 10:28:09 --> Utf8 Class Initialized
INFO - 2023-04-26 10:28:09 --> URI Class Initialized
DEBUG - 2023-04-26 10:28:09 --> No URI present. Default controller set.
INFO - 2023-04-26 10:28:09 --> Router Class Initialized
INFO - 2023-04-26 10:28:09 --> Output Class Initialized
INFO - 2023-04-26 10:28:09 --> Security Class Initialized
DEBUG - 2023-04-26 10:28:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-26 10:28:09 --> Input Class Initialized
INFO - 2023-04-26 10:28:09 --> Language Class Initialized
INFO - 2023-04-26 10:28:09 --> Loader Class Initialized
INFO - 2023-04-26 10:28:09 --> Helper loaded: url_helper
INFO - 2023-04-26 10:28:09 --> Helper loaded: file_helper
INFO - 2023-04-26 10:28:09 --> Helper loaded: html_helper
INFO - 2023-04-26 10:28:09 --> Helper loaded: text_helper
INFO - 2023-04-26 10:28:09 --> Helper loaded: form_helper
INFO - 2023-04-26 10:28:09 --> Helper loaded: lang_helper
INFO - 2023-04-26 10:28:09 --> Helper loaded: security_helper
INFO - 2023-04-26 10:28:09 --> Helper loaded: cookie_helper
INFO - 2023-04-26 10:28:09 --> Database Driver Class Initialized
INFO - 2023-04-26 10:28:09 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-26 10:28:09 --> Parser Class Initialized
INFO - 2023-04-26 10:28:09 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-26 10:28:09 --> Pagination Class Initialized
INFO - 2023-04-26 10:28:09 --> Form Validation Class Initialized
INFO - 2023-04-26 10:28:09 --> Controller Class Initialized
INFO - 2023-04-26 10:28:09 --> Model Class Initialized
DEBUG - 2023-04-26 10:28:09 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-26 10:28:09 --> Model Class Initialized
DEBUG - 2023-04-26 10:28:09 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-26 10:28:09 --> Model Class Initialized
INFO - 2023-04-26 10:28:09 --> Model Class Initialized
INFO - 2023-04-26 10:28:09 --> Model Class Initialized
INFO - 2023-04-26 10:28:09 --> Model Class Initialized
DEBUG - 2023-04-26 10:28:09 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-04-26 10:28:09 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-26 10:28:09 --> Model Class Initialized
INFO - 2023-04-26 10:28:09 --> Model Class Initialized
INFO - 2023-04-26 10:28:09 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-04-26 10:28:09 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-04-26 10:28:09 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-04-26 10:28:09 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-04-26 10:28:09 --> Model Class Initialized
INFO - 2023-04-26 10:28:09 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-04-26 10:28:09 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-04-26 10:28:09 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-04-26 10:28:09 --> Final output sent to browser
DEBUG - 2023-04-26 10:28:09 --> Total execution time: 0.2083
ERROR - 2023-04-26 10:28:22 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-26 10:28:22 --> Config Class Initialized
INFO - 2023-04-26 10:28:22 --> Hooks Class Initialized
DEBUG - 2023-04-26 10:28:22 --> UTF-8 Support Enabled
INFO - 2023-04-26 10:28:22 --> Utf8 Class Initialized
INFO - 2023-04-26 10:28:22 --> URI Class Initialized
INFO - 2023-04-26 10:28:22 --> Router Class Initialized
INFO - 2023-04-26 10:28:22 --> Output Class Initialized
INFO - 2023-04-26 10:28:22 --> Security Class Initialized
DEBUG - 2023-04-26 10:28:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-26 10:28:22 --> Input Class Initialized
INFO - 2023-04-26 10:28:22 --> Language Class Initialized
INFO - 2023-04-26 10:28:22 --> Loader Class Initialized
INFO - 2023-04-26 10:28:22 --> Helper loaded: url_helper
INFO - 2023-04-26 10:28:22 --> Helper loaded: file_helper
INFO - 2023-04-26 10:28:22 --> Helper loaded: html_helper
INFO - 2023-04-26 10:28:22 --> Helper loaded: text_helper
INFO - 2023-04-26 10:28:22 --> Helper loaded: form_helper
INFO - 2023-04-26 10:28:22 --> Helper loaded: lang_helper
INFO - 2023-04-26 10:28:22 --> Helper loaded: security_helper
INFO - 2023-04-26 10:28:22 --> Helper loaded: cookie_helper
INFO - 2023-04-26 10:28:22 --> Database Driver Class Initialized
INFO - 2023-04-26 10:28:22 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-26 10:28:22 --> Parser Class Initialized
INFO - 2023-04-26 10:28:22 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-26 10:28:22 --> Pagination Class Initialized
INFO - 2023-04-26 10:28:22 --> Form Validation Class Initialized
INFO - 2023-04-26 10:28:22 --> Controller Class Initialized
INFO - 2023-04-26 10:28:22 --> Model Class Initialized
DEBUG - 2023-04-26 10:28:22 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-04-26 10:28:22 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-26 10:28:22 --> Model Class Initialized
DEBUG - 2023-04-26 10:28:22 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-26 10:28:22 --> Model Class Initialized
INFO - 2023-04-26 10:28:22 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice.php
DEBUG - 2023-04-26 10:28:22 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-04-26 10:28:22 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-04-26 10:28:22 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-04-26 10:28:22 --> Model Class Initialized
INFO - 2023-04-26 10:28:22 --> Model Class Initialized
INFO - 2023-04-26 10:28:22 --> Model Class Initialized
INFO - 2023-04-26 10:28:22 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-04-26 10:28:22 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-04-26 10:28:22 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-04-26 10:28:22 --> Final output sent to browser
DEBUG - 2023-04-26 10:28:22 --> Total execution time: 0.1532
ERROR - 2023-04-26 10:28:23 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-26 10:28:23 --> Config Class Initialized
INFO - 2023-04-26 10:28:23 --> Hooks Class Initialized
DEBUG - 2023-04-26 10:28:23 --> UTF-8 Support Enabled
INFO - 2023-04-26 10:28:23 --> Utf8 Class Initialized
INFO - 2023-04-26 10:28:23 --> URI Class Initialized
INFO - 2023-04-26 10:28:23 --> Router Class Initialized
INFO - 2023-04-26 10:28:23 --> Output Class Initialized
INFO - 2023-04-26 10:28:23 --> Security Class Initialized
DEBUG - 2023-04-26 10:28:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-26 10:28:23 --> Input Class Initialized
INFO - 2023-04-26 10:28:23 --> Language Class Initialized
INFO - 2023-04-26 10:28:23 --> Loader Class Initialized
INFO - 2023-04-26 10:28:23 --> Helper loaded: url_helper
INFO - 2023-04-26 10:28:23 --> Helper loaded: file_helper
INFO - 2023-04-26 10:28:23 --> Helper loaded: html_helper
INFO - 2023-04-26 10:28:23 --> Helper loaded: text_helper
INFO - 2023-04-26 10:28:23 --> Helper loaded: form_helper
INFO - 2023-04-26 10:28:23 --> Helper loaded: lang_helper
INFO - 2023-04-26 10:28:23 --> Helper loaded: security_helper
INFO - 2023-04-26 10:28:23 --> Helper loaded: cookie_helper
INFO - 2023-04-26 10:28:23 --> Database Driver Class Initialized
INFO - 2023-04-26 10:28:23 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-26 10:28:23 --> Parser Class Initialized
INFO - 2023-04-26 10:28:23 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-26 10:28:23 --> Pagination Class Initialized
INFO - 2023-04-26 10:28:23 --> Form Validation Class Initialized
INFO - 2023-04-26 10:28:23 --> Controller Class Initialized
INFO - 2023-04-26 10:28:23 --> Model Class Initialized
DEBUG - 2023-04-26 10:28:23 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-04-26 10:28:23 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-26 10:28:23 --> Model Class Initialized
DEBUG - 2023-04-26 10:28:23 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-26 10:28:23 --> Model Class Initialized
INFO - 2023-04-26 10:28:23 --> Final output sent to browser
DEBUG - 2023-04-26 10:28:23 --> Total execution time: 0.0547
ERROR - 2023-04-26 10:28:27 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-26 10:28:27 --> Config Class Initialized
INFO - 2023-04-26 10:28:27 --> Hooks Class Initialized
DEBUG - 2023-04-26 10:28:27 --> UTF-8 Support Enabled
INFO - 2023-04-26 10:28:27 --> Utf8 Class Initialized
INFO - 2023-04-26 10:28:27 --> URI Class Initialized
INFO - 2023-04-26 10:28:27 --> Router Class Initialized
INFO - 2023-04-26 10:28:27 --> Output Class Initialized
INFO - 2023-04-26 10:28:27 --> Security Class Initialized
DEBUG - 2023-04-26 10:28:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-26 10:28:27 --> Input Class Initialized
INFO - 2023-04-26 10:28:27 --> Language Class Initialized
INFO - 2023-04-26 10:28:27 --> Loader Class Initialized
INFO - 2023-04-26 10:28:27 --> Helper loaded: url_helper
INFO - 2023-04-26 10:28:27 --> Helper loaded: file_helper
INFO - 2023-04-26 10:28:27 --> Helper loaded: html_helper
INFO - 2023-04-26 10:28:27 --> Helper loaded: text_helper
INFO - 2023-04-26 10:28:27 --> Helper loaded: form_helper
INFO - 2023-04-26 10:28:27 --> Helper loaded: lang_helper
INFO - 2023-04-26 10:28:27 --> Helper loaded: security_helper
INFO - 2023-04-26 10:28:27 --> Helper loaded: cookie_helper
INFO - 2023-04-26 10:28:27 --> Database Driver Class Initialized
INFO - 2023-04-26 10:28:27 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-26 10:28:27 --> Parser Class Initialized
INFO - 2023-04-26 10:28:27 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-26 10:28:27 --> Pagination Class Initialized
INFO - 2023-04-26 10:28:27 --> Form Validation Class Initialized
INFO - 2023-04-26 10:28:27 --> Controller Class Initialized
INFO - 2023-04-26 10:28:27 --> Model Class Initialized
DEBUG - 2023-04-26 10:28:27 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-04-26 10:28:27 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-26 10:28:27 --> Model Class Initialized
DEBUG - 2023-04-26 10:28:27 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-26 10:28:27 --> Model Class Initialized
INFO - 2023-04-26 10:28:27 --> Final output sent to browser
DEBUG - 2023-04-26 10:28:27 --> Total execution time: 0.0763
ERROR - 2023-04-26 10:28:37 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-26 10:28:37 --> Config Class Initialized
INFO - 2023-04-26 10:28:37 --> Hooks Class Initialized
DEBUG - 2023-04-26 10:28:37 --> UTF-8 Support Enabled
INFO - 2023-04-26 10:28:37 --> Utf8 Class Initialized
INFO - 2023-04-26 10:28:37 --> URI Class Initialized
DEBUG - 2023-04-26 10:28:37 --> No URI present. Default controller set.
INFO - 2023-04-26 10:28:37 --> Router Class Initialized
INFO - 2023-04-26 10:28:37 --> Output Class Initialized
INFO - 2023-04-26 10:28:37 --> Security Class Initialized
DEBUG - 2023-04-26 10:28:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-26 10:28:37 --> Input Class Initialized
INFO - 2023-04-26 10:28:37 --> Language Class Initialized
INFO - 2023-04-26 10:28:37 --> Loader Class Initialized
INFO - 2023-04-26 10:28:37 --> Helper loaded: url_helper
INFO - 2023-04-26 10:28:37 --> Helper loaded: file_helper
INFO - 2023-04-26 10:28:37 --> Helper loaded: html_helper
INFO - 2023-04-26 10:28:37 --> Helper loaded: text_helper
INFO - 2023-04-26 10:28:37 --> Helper loaded: form_helper
INFO - 2023-04-26 10:28:37 --> Helper loaded: lang_helper
INFO - 2023-04-26 10:28:37 --> Helper loaded: security_helper
INFO - 2023-04-26 10:28:37 --> Helper loaded: cookie_helper
INFO - 2023-04-26 10:28:37 --> Database Driver Class Initialized
INFO - 2023-04-26 10:28:37 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-26 10:28:37 --> Parser Class Initialized
INFO - 2023-04-26 10:28:37 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-26 10:28:37 --> Pagination Class Initialized
INFO - 2023-04-26 10:28:37 --> Form Validation Class Initialized
INFO - 2023-04-26 10:28:37 --> Controller Class Initialized
INFO - 2023-04-26 10:28:37 --> Model Class Initialized
DEBUG - 2023-04-26 10:28:37 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-26 10:28:37 --> Model Class Initialized
DEBUG - 2023-04-26 10:28:37 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-26 10:28:37 --> Model Class Initialized
INFO - 2023-04-26 10:28:37 --> Model Class Initialized
INFO - 2023-04-26 10:28:37 --> Model Class Initialized
INFO - 2023-04-26 10:28:37 --> Model Class Initialized
DEBUG - 2023-04-26 10:28:37 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-04-26 10:28:37 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-26 10:28:37 --> Model Class Initialized
INFO - 2023-04-26 10:28:37 --> Model Class Initialized
INFO - 2023-04-26 10:28:37 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-04-26 10:28:37 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-04-26 10:28:37 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-04-26 10:28:37 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-04-26 10:28:37 --> Model Class Initialized
INFO - 2023-04-26 10:28:37 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-04-26 10:28:37 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-04-26 10:28:37 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-04-26 10:28:37 --> Final output sent to browser
DEBUG - 2023-04-26 10:28:37 --> Total execution time: 0.1849
ERROR - 2023-04-26 10:28:48 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-26 10:28:48 --> Config Class Initialized
INFO - 2023-04-26 10:28:48 --> Hooks Class Initialized
DEBUG - 2023-04-26 10:28:48 --> UTF-8 Support Enabled
INFO - 2023-04-26 10:28:48 --> Utf8 Class Initialized
INFO - 2023-04-26 10:28:48 --> URI Class Initialized
INFO - 2023-04-26 10:28:48 --> Router Class Initialized
INFO - 2023-04-26 10:28:48 --> Output Class Initialized
INFO - 2023-04-26 10:28:48 --> Security Class Initialized
DEBUG - 2023-04-26 10:28:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-26 10:28:48 --> Input Class Initialized
INFO - 2023-04-26 10:28:48 --> Language Class Initialized
INFO - 2023-04-26 10:28:48 --> Loader Class Initialized
INFO - 2023-04-26 10:28:48 --> Helper loaded: url_helper
INFO - 2023-04-26 10:28:48 --> Helper loaded: file_helper
INFO - 2023-04-26 10:28:48 --> Helper loaded: html_helper
INFO - 2023-04-26 10:28:48 --> Helper loaded: text_helper
INFO - 2023-04-26 10:28:48 --> Helper loaded: form_helper
INFO - 2023-04-26 10:28:48 --> Helper loaded: lang_helper
INFO - 2023-04-26 10:28:48 --> Helper loaded: security_helper
INFO - 2023-04-26 10:28:48 --> Helper loaded: cookie_helper
INFO - 2023-04-26 10:28:48 --> Database Driver Class Initialized
INFO - 2023-04-26 10:28:48 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-26 10:28:48 --> Parser Class Initialized
INFO - 2023-04-26 10:28:48 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-26 10:28:48 --> Pagination Class Initialized
INFO - 2023-04-26 10:28:48 --> Form Validation Class Initialized
INFO - 2023-04-26 10:28:48 --> Controller Class Initialized
DEBUG - 2023-04-26 10:28:48 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-04-26 10:28:48 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-26 10:28:48 --> Model Class Initialized
INFO - 2023-04-26 10:28:48 --> Model Class Initialized
INFO - 2023-04-26 10:28:48 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/manufacturer/manufacturer.php
DEBUG - 2023-04-26 10:28:48 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-04-26 10:28:48 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-04-26 10:28:48 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-04-26 10:28:48 --> Model Class Initialized
INFO - 2023-04-26 10:28:48 --> Model Class Initialized
INFO - 2023-04-26 10:28:48 --> Model Class Initialized
INFO - 2023-04-26 10:28:48 --> Model Class Initialized
INFO - 2023-04-26 10:28:48 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-04-26 10:28:48 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-04-26 10:28:48 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-04-26 10:28:48 --> Final output sent to browser
DEBUG - 2023-04-26 10:28:48 --> Total execution time: 0.1478
ERROR - 2023-04-26 10:28:53 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-26 10:28:53 --> Config Class Initialized
INFO - 2023-04-26 10:28:53 --> Hooks Class Initialized
DEBUG - 2023-04-26 10:28:53 --> UTF-8 Support Enabled
INFO - 2023-04-26 10:28:53 --> Utf8 Class Initialized
INFO - 2023-04-26 10:28:53 --> URI Class Initialized
DEBUG - 2023-04-26 10:28:53 --> No URI present. Default controller set.
INFO - 2023-04-26 10:28:53 --> Router Class Initialized
INFO - 2023-04-26 10:28:53 --> Output Class Initialized
INFO - 2023-04-26 10:28:53 --> Security Class Initialized
DEBUG - 2023-04-26 10:28:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-26 10:28:53 --> Input Class Initialized
INFO - 2023-04-26 10:28:53 --> Language Class Initialized
INFO - 2023-04-26 10:28:53 --> Loader Class Initialized
INFO - 2023-04-26 10:28:53 --> Helper loaded: url_helper
INFO - 2023-04-26 10:28:53 --> Helper loaded: file_helper
INFO - 2023-04-26 10:28:53 --> Helper loaded: html_helper
INFO - 2023-04-26 10:28:53 --> Helper loaded: text_helper
INFO - 2023-04-26 10:28:53 --> Helper loaded: form_helper
INFO - 2023-04-26 10:28:53 --> Helper loaded: lang_helper
INFO - 2023-04-26 10:28:53 --> Helper loaded: security_helper
INFO - 2023-04-26 10:28:53 --> Helper loaded: cookie_helper
INFO - 2023-04-26 10:28:53 --> Database Driver Class Initialized
INFO - 2023-04-26 10:28:53 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-26 10:28:53 --> Parser Class Initialized
INFO - 2023-04-26 10:28:53 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-26 10:28:53 --> Pagination Class Initialized
INFO - 2023-04-26 10:28:53 --> Form Validation Class Initialized
INFO - 2023-04-26 10:28:53 --> Controller Class Initialized
INFO - 2023-04-26 10:28:53 --> Model Class Initialized
DEBUG - 2023-04-26 10:28:53 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-26 10:28:53 --> Model Class Initialized
DEBUG - 2023-04-26 10:28:53 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-26 10:28:53 --> Model Class Initialized
INFO - 2023-04-26 10:28:53 --> Model Class Initialized
INFO - 2023-04-26 10:28:53 --> Model Class Initialized
INFO - 2023-04-26 10:28:53 --> Model Class Initialized
DEBUG - 2023-04-26 10:28:53 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-04-26 10:28:53 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-26 10:28:53 --> Model Class Initialized
INFO - 2023-04-26 10:28:53 --> Model Class Initialized
INFO - 2023-04-26 10:28:53 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-04-26 10:28:53 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-04-26 10:28:53 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-04-26 10:28:53 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-04-26 10:28:53 --> Model Class Initialized
INFO - 2023-04-26 10:28:53 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-04-26 10:28:53 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-04-26 10:28:53 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-04-26 10:28:53 --> Final output sent to browser
DEBUG - 2023-04-26 10:28:53 --> Total execution time: 0.1813
ERROR - 2023-04-26 10:28:57 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-26 10:28:57 --> Config Class Initialized
INFO - 2023-04-26 10:28:57 --> Hooks Class Initialized
DEBUG - 2023-04-26 10:28:57 --> UTF-8 Support Enabled
INFO - 2023-04-26 10:28:57 --> Utf8 Class Initialized
INFO - 2023-04-26 10:28:57 --> URI Class Initialized
INFO - 2023-04-26 10:28:57 --> Router Class Initialized
INFO - 2023-04-26 10:28:57 --> Output Class Initialized
INFO - 2023-04-26 10:28:57 --> Security Class Initialized
DEBUG - 2023-04-26 10:28:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-26 10:28:57 --> Input Class Initialized
INFO - 2023-04-26 10:28:57 --> Language Class Initialized
INFO - 2023-04-26 10:28:57 --> Loader Class Initialized
INFO - 2023-04-26 10:28:57 --> Helper loaded: url_helper
INFO - 2023-04-26 10:28:57 --> Helper loaded: file_helper
INFO - 2023-04-26 10:28:57 --> Helper loaded: html_helper
INFO - 2023-04-26 10:28:57 --> Helper loaded: text_helper
INFO - 2023-04-26 10:28:57 --> Helper loaded: form_helper
INFO - 2023-04-26 10:28:57 --> Helper loaded: lang_helper
INFO - 2023-04-26 10:28:57 --> Helper loaded: security_helper
INFO - 2023-04-26 10:28:57 --> Helper loaded: cookie_helper
INFO - 2023-04-26 10:28:57 --> Database Driver Class Initialized
INFO - 2023-04-26 10:28:57 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-26 10:28:57 --> Parser Class Initialized
INFO - 2023-04-26 10:28:57 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-26 10:28:57 --> Pagination Class Initialized
INFO - 2023-04-26 10:28:57 --> Form Validation Class Initialized
INFO - 2023-04-26 10:28:57 --> Controller Class Initialized
DEBUG - 2023-04-26 10:28:57 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-04-26 10:28:57 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-26 10:28:57 --> Model Class Initialized
INFO - 2023-04-26 10:28:57 --> Model Class Initialized
DEBUG - 2023-04-26 10:28:57 --> Lmr class already loaded. Second attempt ignored.
INFO - 2023-04-26 10:28:57 --> Model Class Initialized
INFO - 2023-04-26 10:28:57 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/mr/mr.php
DEBUG - 2023-04-26 10:28:57 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-04-26 10:28:57 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-04-26 10:28:57 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-04-26 10:28:57 --> Model Class Initialized
INFO - 2023-04-26 10:28:57 --> Model Class Initialized
INFO - 2023-04-26 10:28:57 --> Model Class Initialized
INFO - 2023-04-26 10:28:57 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-04-26 10:28:57 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-04-26 10:28:57 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-04-26 10:28:57 --> Final output sent to browser
DEBUG - 2023-04-26 10:28:57 --> Total execution time: 0.1468
ERROR - 2023-04-26 10:28:58 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-26 10:28:58 --> Config Class Initialized
INFO - 2023-04-26 10:28:58 --> Hooks Class Initialized
DEBUG - 2023-04-26 10:28:58 --> UTF-8 Support Enabled
INFO - 2023-04-26 10:28:58 --> Utf8 Class Initialized
INFO - 2023-04-26 10:28:58 --> URI Class Initialized
INFO - 2023-04-26 10:28:58 --> Router Class Initialized
INFO - 2023-04-26 10:28:58 --> Output Class Initialized
INFO - 2023-04-26 10:28:58 --> Security Class Initialized
DEBUG - 2023-04-26 10:28:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-26 10:28:58 --> Input Class Initialized
INFO - 2023-04-26 10:28:58 --> Language Class Initialized
INFO - 2023-04-26 10:28:58 --> Loader Class Initialized
INFO - 2023-04-26 10:28:58 --> Helper loaded: url_helper
INFO - 2023-04-26 10:28:58 --> Helper loaded: file_helper
INFO - 2023-04-26 10:28:58 --> Helper loaded: html_helper
INFO - 2023-04-26 10:28:58 --> Helper loaded: text_helper
INFO - 2023-04-26 10:28:58 --> Helper loaded: form_helper
INFO - 2023-04-26 10:28:58 --> Helper loaded: lang_helper
INFO - 2023-04-26 10:28:58 --> Helper loaded: security_helper
INFO - 2023-04-26 10:28:58 --> Helper loaded: cookie_helper
INFO - 2023-04-26 10:28:58 --> Database Driver Class Initialized
INFO - 2023-04-26 10:28:58 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-26 10:28:58 --> Parser Class Initialized
INFO - 2023-04-26 10:28:58 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-26 10:28:58 --> Pagination Class Initialized
INFO - 2023-04-26 10:28:58 --> Form Validation Class Initialized
INFO - 2023-04-26 10:28:58 --> Controller Class Initialized
DEBUG - 2023-04-26 10:28:58 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-04-26 10:28:58 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-26 10:28:58 --> Model Class Initialized
INFO - 2023-04-26 10:28:58 --> Model Class Initialized
INFO - 2023-04-26 10:28:58 --> Final output sent to browser
DEBUG - 2023-04-26 10:28:58 --> Total execution time: 0.0196
ERROR - 2023-04-26 10:29:02 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-26 10:29:02 --> Config Class Initialized
INFO - 2023-04-26 10:29:02 --> Hooks Class Initialized
DEBUG - 2023-04-26 10:29:02 --> UTF-8 Support Enabled
INFO - 2023-04-26 10:29:02 --> Utf8 Class Initialized
INFO - 2023-04-26 10:29:02 --> URI Class Initialized
INFO - 2023-04-26 10:29:02 --> Router Class Initialized
INFO - 2023-04-26 10:29:02 --> Output Class Initialized
INFO - 2023-04-26 10:29:02 --> Security Class Initialized
DEBUG - 2023-04-26 10:29:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-26 10:29:02 --> Input Class Initialized
INFO - 2023-04-26 10:29:02 --> Language Class Initialized
INFO - 2023-04-26 10:29:02 --> Loader Class Initialized
INFO - 2023-04-26 10:29:02 --> Helper loaded: url_helper
INFO - 2023-04-26 10:29:02 --> Helper loaded: file_helper
INFO - 2023-04-26 10:29:02 --> Helper loaded: html_helper
INFO - 2023-04-26 10:29:02 --> Helper loaded: text_helper
INFO - 2023-04-26 10:29:02 --> Helper loaded: form_helper
INFO - 2023-04-26 10:29:02 --> Helper loaded: lang_helper
INFO - 2023-04-26 10:29:02 --> Helper loaded: security_helper
INFO - 2023-04-26 10:29:02 --> Helper loaded: cookie_helper
INFO - 2023-04-26 10:29:02 --> Database Driver Class Initialized
INFO - 2023-04-26 10:29:02 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-26 10:29:02 --> Parser Class Initialized
INFO - 2023-04-26 10:29:02 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-26 10:29:02 --> Pagination Class Initialized
INFO - 2023-04-26 10:29:02 --> Form Validation Class Initialized
INFO - 2023-04-26 10:29:02 --> Controller Class Initialized
DEBUG - 2023-04-26 10:29:02 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-04-26 10:29:02 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-26 10:29:02 --> Model Class Initialized
INFO - 2023-04-26 10:29:02 --> Model Class Initialized
INFO - 2023-04-26 10:29:02 --> Final output sent to browser
DEBUG - 2023-04-26 10:29:02 --> Total execution time: 0.0189
ERROR - 2023-04-26 10:29:06 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-26 10:29:06 --> Config Class Initialized
INFO - 2023-04-26 10:29:06 --> Hooks Class Initialized
DEBUG - 2023-04-26 10:29:06 --> UTF-8 Support Enabled
INFO - 2023-04-26 10:29:06 --> Utf8 Class Initialized
INFO - 2023-04-26 10:29:06 --> URI Class Initialized
DEBUG - 2023-04-26 10:29:06 --> No URI present. Default controller set.
INFO - 2023-04-26 10:29:06 --> Router Class Initialized
INFO - 2023-04-26 10:29:06 --> Output Class Initialized
INFO - 2023-04-26 10:29:06 --> Security Class Initialized
DEBUG - 2023-04-26 10:29:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-26 10:29:06 --> Input Class Initialized
INFO - 2023-04-26 10:29:06 --> Language Class Initialized
INFO - 2023-04-26 10:29:06 --> Loader Class Initialized
INFO - 2023-04-26 10:29:06 --> Helper loaded: url_helper
INFO - 2023-04-26 10:29:06 --> Helper loaded: file_helper
INFO - 2023-04-26 10:29:06 --> Helper loaded: html_helper
INFO - 2023-04-26 10:29:06 --> Helper loaded: text_helper
INFO - 2023-04-26 10:29:06 --> Helper loaded: form_helper
INFO - 2023-04-26 10:29:06 --> Helper loaded: lang_helper
INFO - 2023-04-26 10:29:06 --> Helper loaded: security_helper
INFO - 2023-04-26 10:29:06 --> Helper loaded: cookie_helper
INFO - 2023-04-26 10:29:06 --> Database Driver Class Initialized
INFO - 2023-04-26 10:29:06 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-26 10:29:06 --> Parser Class Initialized
INFO - 2023-04-26 10:29:06 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-26 10:29:06 --> Pagination Class Initialized
INFO - 2023-04-26 10:29:06 --> Form Validation Class Initialized
INFO - 2023-04-26 10:29:06 --> Controller Class Initialized
INFO - 2023-04-26 10:29:06 --> Model Class Initialized
DEBUG - 2023-04-26 10:29:06 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-26 10:29:06 --> Model Class Initialized
DEBUG - 2023-04-26 10:29:06 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-26 10:29:06 --> Model Class Initialized
INFO - 2023-04-26 10:29:06 --> Model Class Initialized
INFO - 2023-04-26 10:29:06 --> Model Class Initialized
INFO - 2023-04-26 10:29:06 --> Model Class Initialized
DEBUG - 2023-04-26 10:29:06 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-04-26 10:29:06 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-26 10:29:06 --> Model Class Initialized
INFO - 2023-04-26 10:29:06 --> Model Class Initialized
INFO - 2023-04-26 10:29:06 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-04-26 10:29:06 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-04-26 10:29:06 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-04-26 10:29:06 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-04-26 10:29:06 --> Model Class Initialized
INFO - 2023-04-26 10:29:06 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-04-26 10:29:06 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-04-26 10:29:06 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-04-26 10:29:06 --> Final output sent to browser
DEBUG - 2023-04-26 10:29:06 --> Total execution time: 0.1788
ERROR - 2023-04-26 10:29:10 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-26 10:29:10 --> Config Class Initialized
INFO - 2023-04-26 10:29:10 --> Hooks Class Initialized
DEBUG - 2023-04-26 10:29:10 --> UTF-8 Support Enabled
INFO - 2023-04-26 10:29:10 --> Utf8 Class Initialized
INFO - 2023-04-26 10:29:10 --> URI Class Initialized
INFO - 2023-04-26 10:29:10 --> Router Class Initialized
INFO - 2023-04-26 10:29:10 --> Output Class Initialized
INFO - 2023-04-26 10:29:10 --> Security Class Initialized
DEBUG - 2023-04-26 10:29:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-26 10:29:10 --> Input Class Initialized
INFO - 2023-04-26 10:29:10 --> Language Class Initialized
INFO - 2023-04-26 10:29:10 --> Loader Class Initialized
INFO - 2023-04-26 10:29:10 --> Helper loaded: url_helper
INFO - 2023-04-26 10:29:10 --> Helper loaded: file_helper
INFO - 2023-04-26 10:29:10 --> Helper loaded: html_helper
INFO - 2023-04-26 10:29:10 --> Helper loaded: text_helper
INFO - 2023-04-26 10:29:10 --> Helper loaded: form_helper
INFO - 2023-04-26 10:29:10 --> Helper loaded: lang_helper
INFO - 2023-04-26 10:29:10 --> Helper loaded: security_helper
INFO - 2023-04-26 10:29:10 --> Helper loaded: cookie_helper
INFO - 2023-04-26 10:29:10 --> Database Driver Class Initialized
INFO - 2023-04-26 10:29:10 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-26 10:29:10 --> Parser Class Initialized
INFO - 2023-04-26 10:29:10 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-26 10:29:10 --> Pagination Class Initialized
INFO - 2023-04-26 10:29:10 --> Form Validation Class Initialized
INFO - 2023-04-26 10:29:10 --> Controller Class Initialized
DEBUG - 2023-04-26 10:29:10 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-04-26 10:29:10 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-26 10:29:10 --> Model Class Initialized
DEBUG - 2023-04-26 10:29:10 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-26 10:29:10 --> Model Class Initialized
DEBUG - 2023-04-26 10:29:10 --> Lcustomer class already loaded. Second attempt ignored.
INFO - 2023-04-26 10:29:10 --> Model Class Initialized
INFO - 2023-04-26 10:29:10 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/customer/customer.php
DEBUG - 2023-04-26 10:29:10 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-04-26 10:29:10 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-04-26 10:29:10 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-04-26 10:29:10 --> Model Class Initialized
INFO - 2023-04-26 10:29:10 --> Model Class Initialized
INFO - 2023-04-26 10:29:10 --> Model Class Initialized
INFO - 2023-04-26 10:29:10 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-04-26 10:29:10 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-04-26 10:29:10 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-04-26 10:29:10 --> Final output sent to browser
DEBUG - 2023-04-26 10:29:10 --> Total execution time: 0.1461
ERROR - 2023-04-26 10:29:11 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-26 10:29:11 --> Config Class Initialized
INFO - 2023-04-26 10:29:11 --> Hooks Class Initialized
DEBUG - 2023-04-26 10:29:11 --> UTF-8 Support Enabled
INFO - 2023-04-26 10:29:11 --> Utf8 Class Initialized
INFO - 2023-04-26 10:29:11 --> URI Class Initialized
INFO - 2023-04-26 10:29:11 --> Router Class Initialized
INFO - 2023-04-26 10:29:11 --> Output Class Initialized
INFO - 2023-04-26 10:29:11 --> Security Class Initialized
DEBUG - 2023-04-26 10:29:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-26 10:29:11 --> Input Class Initialized
INFO - 2023-04-26 10:29:11 --> Language Class Initialized
INFO - 2023-04-26 10:29:11 --> Loader Class Initialized
INFO - 2023-04-26 10:29:11 --> Helper loaded: url_helper
INFO - 2023-04-26 10:29:11 --> Helper loaded: file_helper
INFO - 2023-04-26 10:29:11 --> Helper loaded: html_helper
INFO - 2023-04-26 10:29:11 --> Helper loaded: text_helper
INFO - 2023-04-26 10:29:11 --> Helper loaded: form_helper
INFO - 2023-04-26 10:29:11 --> Helper loaded: lang_helper
INFO - 2023-04-26 10:29:11 --> Helper loaded: security_helper
INFO - 2023-04-26 10:29:11 --> Helper loaded: cookie_helper
INFO - 2023-04-26 10:29:11 --> Database Driver Class Initialized
INFO - 2023-04-26 10:29:11 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-26 10:29:11 --> Parser Class Initialized
INFO - 2023-04-26 10:29:11 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-26 10:29:11 --> Pagination Class Initialized
INFO - 2023-04-26 10:29:11 --> Form Validation Class Initialized
INFO - 2023-04-26 10:29:11 --> Controller Class Initialized
DEBUG - 2023-04-26 10:29:11 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-04-26 10:29:11 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-26 10:29:11 --> Model Class Initialized
DEBUG - 2023-04-26 10:29:11 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-26 10:29:11 --> Model Class Initialized
INFO - 2023-04-26 10:29:11 --> Final output sent to browser
DEBUG - 2023-04-26 10:29:11 --> Total execution time: 0.0318
ERROR - 2023-04-26 10:29:15 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-26 10:29:15 --> Config Class Initialized
INFO - 2023-04-26 10:29:15 --> Hooks Class Initialized
DEBUG - 2023-04-26 10:29:15 --> UTF-8 Support Enabled
INFO - 2023-04-26 10:29:15 --> Utf8 Class Initialized
INFO - 2023-04-26 10:29:15 --> URI Class Initialized
INFO - 2023-04-26 10:29:15 --> Router Class Initialized
INFO - 2023-04-26 10:29:15 --> Output Class Initialized
INFO - 2023-04-26 10:29:15 --> Security Class Initialized
DEBUG - 2023-04-26 10:29:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-26 10:29:15 --> Input Class Initialized
INFO - 2023-04-26 10:29:15 --> Language Class Initialized
INFO - 2023-04-26 10:29:15 --> Loader Class Initialized
INFO - 2023-04-26 10:29:15 --> Helper loaded: url_helper
INFO - 2023-04-26 10:29:15 --> Helper loaded: file_helper
INFO - 2023-04-26 10:29:15 --> Helper loaded: html_helper
INFO - 2023-04-26 10:29:15 --> Helper loaded: text_helper
INFO - 2023-04-26 10:29:15 --> Helper loaded: form_helper
INFO - 2023-04-26 10:29:15 --> Helper loaded: lang_helper
INFO - 2023-04-26 10:29:15 --> Helper loaded: security_helper
INFO - 2023-04-26 10:29:15 --> Helper loaded: cookie_helper
INFO - 2023-04-26 10:29:15 --> Database Driver Class Initialized
INFO - 2023-04-26 10:29:15 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-26 10:29:15 --> Parser Class Initialized
INFO - 2023-04-26 10:29:15 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-26 10:29:15 --> Pagination Class Initialized
INFO - 2023-04-26 10:29:15 --> Form Validation Class Initialized
INFO - 2023-04-26 10:29:15 --> Controller Class Initialized
DEBUG - 2023-04-26 10:29:15 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-04-26 10:29:15 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-26 10:29:15 --> Model Class Initialized
DEBUG - 2023-04-26 10:29:15 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-26 10:29:15 --> Model Class Initialized
INFO - 2023-04-26 10:29:15 --> Final output sent to browser
DEBUG - 2023-04-26 10:29:15 --> Total execution time: 0.0763
ERROR - 2023-04-26 10:29:27 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-26 10:29:27 --> Config Class Initialized
INFO - 2023-04-26 10:29:27 --> Hooks Class Initialized
DEBUG - 2023-04-26 10:29:27 --> UTF-8 Support Enabled
INFO - 2023-04-26 10:29:27 --> Utf8 Class Initialized
INFO - 2023-04-26 10:29:27 --> URI Class Initialized
INFO - 2023-04-26 10:29:27 --> Router Class Initialized
INFO - 2023-04-26 10:29:27 --> Output Class Initialized
INFO - 2023-04-26 10:29:27 --> Security Class Initialized
DEBUG - 2023-04-26 10:29:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-26 10:29:27 --> Input Class Initialized
INFO - 2023-04-26 10:29:27 --> Language Class Initialized
INFO - 2023-04-26 10:29:27 --> Loader Class Initialized
INFO - 2023-04-26 10:29:27 --> Helper loaded: url_helper
INFO - 2023-04-26 10:29:27 --> Helper loaded: file_helper
INFO - 2023-04-26 10:29:27 --> Helper loaded: html_helper
INFO - 2023-04-26 10:29:27 --> Helper loaded: text_helper
INFO - 2023-04-26 10:29:27 --> Helper loaded: form_helper
INFO - 2023-04-26 10:29:27 --> Helper loaded: lang_helper
INFO - 2023-04-26 10:29:27 --> Helper loaded: security_helper
INFO - 2023-04-26 10:29:27 --> Helper loaded: cookie_helper
INFO - 2023-04-26 10:29:27 --> Database Driver Class Initialized
INFO - 2023-04-26 10:29:27 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-26 10:29:27 --> Parser Class Initialized
INFO - 2023-04-26 10:29:27 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-26 10:29:27 --> Pagination Class Initialized
INFO - 2023-04-26 10:29:27 --> Form Validation Class Initialized
INFO - 2023-04-26 10:29:27 --> Controller Class Initialized
DEBUG - 2023-04-26 10:29:27 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-04-26 10:29:27 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-26 10:29:27 --> Model Class Initialized
DEBUG - 2023-04-26 10:29:27 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-26 10:29:27 --> Model Class Initialized
INFO - 2023-04-26 10:29:27 --> Final output sent to browser
DEBUG - 2023-04-26 10:29:27 --> Total execution time: 0.0539
ERROR - 2023-04-26 10:29:50 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-26 10:29:50 --> Config Class Initialized
INFO - 2023-04-26 10:29:50 --> Hooks Class Initialized
DEBUG - 2023-04-26 10:29:50 --> UTF-8 Support Enabled
INFO - 2023-04-26 10:29:50 --> Utf8 Class Initialized
INFO - 2023-04-26 10:29:50 --> URI Class Initialized
DEBUG - 2023-04-26 10:29:50 --> No URI present. Default controller set.
INFO - 2023-04-26 10:29:50 --> Router Class Initialized
INFO - 2023-04-26 10:29:50 --> Output Class Initialized
INFO - 2023-04-26 10:29:50 --> Security Class Initialized
DEBUG - 2023-04-26 10:29:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-26 10:29:50 --> Input Class Initialized
INFO - 2023-04-26 10:29:50 --> Language Class Initialized
INFO - 2023-04-26 10:29:50 --> Loader Class Initialized
INFO - 2023-04-26 10:29:50 --> Helper loaded: url_helper
INFO - 2023-04-26 10:29:50 --> Helper loaded: file_helper
INFO - 2023-04-26 10:29:50 --> Helper loaded: html_helper
INFO - 2023-04-26 10:29:50 --> Helper loaded: text_helper
INFO - 2023-04-26 10:29:50 --> Helper loaded: form_helper
INFO - 2023-04-26 10:29:50 --> Helper loaded: lang_helper
INFO - 2023-04-26 10:29:50 --> Helper loaded: security_helper
INFO - 2023-04-26 10:29:50 --> Helper loaded: cookie_helper
INFO - 2023-04-26 10:29:50 --> Database Driver Class Initialized
INFO - 2023-04-26 10:29:50 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-26 10:29:50 --> Parser Class Initialized
INFO - 2023-04-26 10:29:50 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-26 10:29:50 --> Pagination Class Initialized
INFO - 2023-04-26 10:29:50 --> Form Validation Class Initialized
INFO - 2023-04-26 10:29:50 --> Controller Class Initialized
INFO - 2023-04-26 10:29:50 --> Model Class Initialized
DEBUG - 2023-04-26 10:29:50 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-26 10:29:50 --> Model Class Initialized
DEBUG - 2023-04-26 10:29:50 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-26 10:29:50 --> Model Class Initialized
INFO - 2023-04-26 10:29:50 --> Model Class Initialized
INFO - 2023-04-26 10:29:50 --> Model Class Initialized
INFO - 2023-04-26 10:29:50 --> Model Class Initialized
DEBUG - 2023-04-26 10:29:50 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-04-26 10:29:50 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-26 10:29:50 --> Model Class Initialized
INFO - 2023-04-26 10:29:50 --> Model Class Initialized
INFO - 2023-04-26 10:29:50 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-04-26 10:29:50 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-04-26 10:29:50 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-04-26 10:29:50 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-04-26 10:29:50 --> Model Class Initialized
INFO - 2023-04-26 10:29:50 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-04-26 10:29:50 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-04-26 10:29:50 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-04-26 10:29:50 --> Final output sent to browser
DEBUG - 2023-04-26 10:29:50 --> Total execution time: 0.1733
ERROR - 2023-04-26 10:30:00 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-26 10:30:00 --> Config Class Initialized
INFO - 2023-04-26 10:30:00 --> Hooks Class Initialized
DEBUG - 2023-04-26 10:30:00 --> UTF-8 Support Enabled
INFO - 2023-04-26 10:30:00 --> Utf8 Class Initialized
INFO - 2023-04-26 10:30:00 --> URI Class Initialized
INFO - 2023-04-26 10:30:00 --> Router Class Initialized
INFO - 2023-04-26 10:30:00 --> Output Class Initialized
INFO - 2023-04-26 10:30:00 --> Security Class Initialized
DEBUG - 2023-04-26 10:30:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-26 10:30:00 --> Input Class Initialized
INFO - 2023-04-26 10:30:00 --> Language Class Initialized
INFO - 2023-04-26 10:30:00 --> Loader Class Initialized
INFO - 2023-04-26 10:30:00 --> Helper loaded: url_helper
INFO - 2023-04-26 10:30:00 --> Helper loaded: file_helper
INFO - 2023-04-26 10:30:00 --> Helper loaded: html_helper
INFO - 2023-04-26 10:30:00 --> Helper loaded: text_helper
INFO - 2023-04-26 10:30:00 --> Helper loaded: form_helper
INFO - 2023-04-26 10:30:00 --> Helper loaded: lang_helper
INFO - 2023-04-26 10:30:00 --> Helper loaded: security_helper
INFO - 2023-04-26 10:30:00 --> Helper loaded: cookie_helper
INFO - 2023-04-26 10:30:00 --> Database Driver Class Initialized
INFO - 2023-04-26 10:30:00 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-26 10:30:00 --> Parser Class Initialized
INFO - 2023-04-26 10:30:00 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-26 10:30:00 --> Pagination Class Initialized
INFO - 2023-04-26 10:30:00 --> Form Validation Class Initialized
INFO - 2023-04-26 10:30:00 --> Controller Class Initialized
INFO - 2023-04-26 10:30:00 --> Model Class Initialized
DEBUG - 2023-04-26 10:30:00 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-04-26 10:30:00 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-26 10:30:00 --> Model Class Initialized
DEBUG - 2023-04-26 10:30:00 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-26 10:30:00 --> Model Class Initialized
INFO - 2023-04-26 10:30:00 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice.php
DEBUG - 2023-04-26 10:30:00 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-04-26 10:30:00 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-04-26 10:30:00 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-04-26 10:30:00 --> Model Class Initialized
INFO - 2023-04-26 10:30:00 --> Model Class Initialized
INFO - 2023-04-26 10:30:00 --> Model Class Initialized
INFO - 2023-04-26 10:30:00 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-04-26 10:30:00 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-04-26 10:30:00 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-04-26 10:30:00 --> Final output sent to browser
DEBUG - 2023-04-26 10:30:00 --> Total execution time: 0.1484
ERROR - 2023-04-26 10:30:01 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-26 10:30:01 --> Config Class Initialized
INFO - 2023-04-26 10:30:01 --> Hooks Class Initialized
DEBUG - 2023-04-26 10:30:01 --> UTF-8 Support Enabled
INFO - 2023-04-26 10:30:01 --> Utf8 Class Initialized
INFO - 2023-04-26 10:30:01 --> URI Class Initialized
INFO - 2023-04-26 10:30:01 --> Router Class Initialized
INFO - 2023-04-26 10:30:01 --> Output Class Initialized
INFO - 2023-04-26 10:30:01 --> Security Class Initialized
DEBUG - 2023-04-26 10:30:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-26 10:30:01 --> Input Class Initialized
INFO - 2023-04-26 10:30:01 --> Language Class Initialized
INFO - 2023-04-26 10:30:01 --> Loader Class Initialized
INFO - 2023-04-26 10:30:01 --> Helper loaded: url_helper
INFO - 2023-04-26 10:30:01 --> Helper loaded: file_helper
INFO - 2023-04-26 10:30:01 --> Helper loaded: html_helper
INFO - 2023-04-26 10:30:01 --> Helper loaded: text_helper
INFO - 2023-04-26 10:30:01 --> Helper loaded: form_helper
INFO - 2023-04-26 10:30:01 --> Helper loaded: lang_helper
INFO - 2023-04-26 10:30:01 --> Helper loaded: security_helper
INFO - 2023-04-26 10:30:01 --> Helper loaded: cookie_helper
INFO - 2023-04-26 10:30:01 --> Database Driver Class Initialized
INFO - 2023-04-26 10:30:01 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-26 10:30:01 --> Parser Class Initialized
INFO - 2023-04-26 10:30:01 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-26 10:30:01 --> Pagination Class Initialized
INFO - 2023-04-26 10:30:01 --> Form Validation Class Initialized
INFO - 2023-04-26 10:30:01 --> Controller Class Initialized
INFO - 2023-04-26 10:30:01 --> Model Class Initialized
DEBUG - 2023-04-26 10:30:01 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-04-26 10:30:01 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-26 10:30:01 --> Model Class Initialized
DEBUG - 2023-04-26 10:30:01 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-26 10:30:01 --> Model Class Initialized
INFO - 2023-04-26 10:30:01 --> Final output sent to browser
DEBUG - 2023-04-26 10:30:01 --> Total execution time: 0.0746
ERROR - 2023-04-26 10:30:04 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-26 10:30:04 --> Config Class Initialized
INFO - 2023-04-26 10:30:04 --> Hooks Class Initialized
DEBUG - 2023-04-26 10:30:04 --> UTF-8 Support Enabled
INFO - 2023-04-26 10:30:04 --> Utf8 Class Initialized
INFO - 2023-04-26 10:30:04 --> URI Class Initialized
INFO - 2023-04-26 10:30:04 --> Router Class Initialized
INFO - 2023-04-26 10:30:04 --> Output Class Initialized
INFO - 2023-04-26 10:30:04 --> Security Class Initialized
DEBUG - 2023-04-26 10:30:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-26 10:30:04 --> Input Class Initialized
INFO - 2023-04-26 10:30:04 --> Language Class Initialized
INFO - 2023-04-26 10:30:04 --> Loader Class Initialized
INFO - 2023-04-26 10:30:04 --> Helper loaded: url_helper
INFO - 2023-04-26 10:30:04 --> Helper loaded: file_helper
INFO - 2023-04-26 10:30:04 --> Helper loaded: html_helper
INFO - 2023-04-26 10:30:04 --> Helper loaded: text_helper
INFO - 2023-04-26 10:30:04 --> Helper loaded: form_helper
INFO - 2023-04-26 10:30:04 --> Helper loaded: lang_helper
INFO - 2023-04-26 10:30:04 --> Helper loaded: security_helper
INFO - 2023-04-26 10:30:04 --> Helper loaded: cookie_helper
INFO - 2023-04-26 10:30:04 --> Database Driver Class Initialized
INFO - 2023-04-26 10:30:04 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-26 10:30:04 --> Parser Class Initialized
INFO - 2023-04-26 10:30:04 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-26 10:30:04 --> Pagination Class Initialized
INFO - 2023-04-26 10:30:04 --> Form Validation Class Initialized
INFO - 2023-04-26 10:30:04 --> Controller Class Initialized
INFO - 2023-04-26 10:30:04 --> Model Class Initialized
DEBUG - 2023-04-26 10:30:04 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-04-26 10:30:04 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-26 10:30:04 --> Model Class Initialized
DEBUG - 2023-04-26 10:30:04 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-26 10:30:04 --> Model Class Initialized
INFO - 2023-04-26 10:30:04 --> Final output sent to browser
DEBUG - 2023-04-26 10:30:04 --> Total execution time: 0.0726
ERROR - 2023-04-26 10:30:16 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-26 10:30:16 --> Config Class Initialized
INFO - 2023-04-26 10:30:16 --> Hooks Class Initialized
DEBUG - 2023-04-26 10:30:16 --> UTF-8 Support Enabled
INFO - 2023-04-26 10:30:16 --> Utf8 Class Initialized
INFO - 2023-04-26 10:30:16 --> URI Class Initialized
DEBUG - 2023-04-26 10:30:16 --> No URI present. Default controller set.
INFO - 2023-04-26 10:30:16 --> Router Class Initialized
INFO - 2023-04-26 10:30:16 --> Output Class Initialized
INFO - 2023-04-26 10:30:16 --> Security Class Initialized
DEBUG - 2023-04-26 10:30:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-26 10:30:16 --> Input Class Initialized
INFO - 2023-04-26 10:30:16 --> Language Class Initialized
INFO - 2023-04-26 10:30:16 --> Loader Class Initialized
INFO - 2023-04-26 10:30:16 --> Helper loaded: url_helper
INFO - 2023-04-26 10:30:16 --> Helper loaded: file_helper
INFO - 2023-04-26 10:30:16 --> Helper loaded: html_helper
INFO - 2023-04-26 10:30:16 --> Helper loaded: text_helper
INFO - 2023-04-26 10:30:16 --> Helper loaded: form_helper
INFO - 2023-04-26 10:30:16 --> Helper loaded: lang_helper
INFO - 2023-04-26 10:30:16 --> Helper loaded: security_helper
INFO - 2023-04-26 10:30:16 --> Helper loaded: cookie_helper
INFO - 2023-04-26 10:30:16 --> Database Driver Class Initialized
INFO - 2023-04-26 10:30:16 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-26 10:30:16 --> Parser Class Initialized
INFO - 2023-04-26 10:30:16 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-26 10:30:16 --> Pagination Class Initialized
INFO - 2023-04-26 10:30:16 --> Form Validation Class Initialized
INFO - 2023-04-26 10:30:16 --> Controller Class Initialized
INFO - 2023-04-26 10:30:16 --> Model Class Initialized
DEBUG - 2023-04-26 10:30:16 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-26 10:30:16 --> Model Class Initialized
DEBUG - 2023-04-26 10:30:16 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-26 10:30:16 --> Model Class Initialized
INFO - 2023-04-26 10:30:16 --> Model Class Initialized
INFO - 2023-04-26 10:30:16 --> Model Class Initialized
INFO - 2023-04-26 10:30:16 --> Model Class Initialized
DEBUG - 2023-04-26 10:30:16 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-04-26 10:30:16 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-26 10:30:16 --> Model Class Initialized
INFO - 2023-04-26 10:30:16 --> Model Class Initialized
INFO - 2023-04-26 10:30:16 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-04-26 10:30:16 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-04-26 10:30:16 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-04-26 10:30:16 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-04-26 10:30:16 --> Model Class Initialized
INFO - 2023-04-26 10:30:16 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-04-26 10:30:16 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-04-26 10:30:16 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-04-26 10:30:16 --> Final output sent to browser
DEBUG - 2023-04-26 10:30:16 --> Total execution time: 0.1594
ERROR - 2023-04-26 10:30:36 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-26 10:30:36 --> Config Class Initialized
INFO - 2023-04-26 10:30:36 --> Hooks Class Initialized
DEBUG - 2023-04-26 10:30:36 --> UTF-8 Support Enabled
INFO - 2023-04-26 10:30:36 --> Utf8 Class Initialized
INFO - 2023-04-26 10:30:36 --> URI Class Initialized
DEBUG - 2023-04-26 10:30:36 --> No URI present. Default controller set.
INFO - 2023-04-26 10:30:36 --> Router Class Initialized
INFO - 2023-04-26 10:30:36 --> Output Class Initialized
INFO - 2023-04-26 10:30:36 --> Security Class Initialized
DEBUG - 2023-04-26 10:30:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-26 10:30:36 --> Input Class Initialized
INFO - 2023-04-26 10:30:36 --> Language Class Initialized
INFO - 2023-04-26 10:30:36 --> Loader Class Initialized
INFO - 2023-04-26 10:30:36 --> Helper loaded: url_helper
INFO - 2023-04-26 10:30:36 --> Helper loaded: file_helper
INFO - 2023-04-26 10:30:36 --> Helper loaded: html_helper
INFO - 2023-04-26 10:30:36 --> Helper loaded: text_helper
INFO - 2023-04-26 10:30:36 --> Helper loaded: form_helper
INFO - 2023-04-26 10:30:36 --> Helper loaded: lang_helper
INFO - 2023-04-26 10:30:36 --> Helper loaded: security_helper
INFO - 2023-04-26 10:30:36 --> Helper loaded: cookie_helper
INFO - 2023-04-26 10:30:36 --> Database Driver Class Initialized
INFO - 2023-04-26 10:30:36 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-26 10:30:36 --> Parser Class Initialized
INFO - 2023-04-26 10:30:36 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-26 10:30:36 --> Pagination Class Initialized
INFO - 2023-04-26 10:30:36 --> Form Validation Class Initialized
INFO - 2023-04-26 10:30:36 --> Controller Class Initialized
INFO - 2023-04-26 10:30:36 --> Model Class Initialized
DEBUG - 2023-04-26 10:30:36 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-26 10:30:36 --> Model Class Initialized
DEBUG - 2023-04-26 10:30:36 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-26 10:30:36 --> Model Class Initialized
INFO - 2023-04-26 10:30:36 --> Model Class Initialized
INFO - 2023-04-26 10:30:36 --> Model Class Initialized
INFO - 2023-04-26 10:30:36 --> Model Class Initialized
DEBUG - 2023-04-26 10:30:36 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-04-26 10:30:36 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-26 10:30:36 --> Model Class Initialized
INFO - 2023-04-26 10:30:36 --> Model Class Initialized
INFO - 2023-04-26 10:30:36 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-04-26 10:30:36 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-04-26 10:30:36 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-04-26 10:30:36 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-04-26 10:30:36 --> Model Class Initialized
INFO - 2023-04-26 10:30:36 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-04-26 10:30:36 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-04-26 10:30:36 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-04-26 10:30:36 --> Final output sent to browser
DEBUG - 2023-04-26 10:30:36 --> Total execution time: 0.1923
ERROR - 2023-04-26 10:30:41 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-26 10:30:41 --> Config Class Initialized
INFO - 2023-04-26 10:30:41 --> Hooks Class Initialized
DEBUG - 2023-04-26 10:30:41 --> UTF-8 Support Enabled
INFO - 2023-04-26 10:30:41 --> Utf8 Class Initialized
INFO - 2023-04-26 10:30:41 --> URI Class Initialized
INFO - 2023-04-26 10:30:41 --> Router Class Initialized
INFO - 2023-04-26 10:30:41 --> Output Class Initialized
INFO - 2023-04-26 10:30:41 --> Security Class Initialized
DEBUG - 2023-04-26 10:30:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-26 10:30:41 --> Input Class Initialized
INFO - 2023-04-26 10:30:41 --> Language Class Initialized
INFO - 2023-04-26 10:30:41 --> Loader Class Initialized
INFO - 2023-04-26 10:30:41 --> Helper loaded: url_helper
INFO - 2023-04-26 10:30:41 --> Helper loaded: file_helper
INFO - 2023-04-26 10:30:41 --> Helper loaded: html_helper
INFO - 2023-04-26 10:30:41 --> Helper loaded: text_helper
INFO - 2023-04-26 10:30:41 --> Helper loaded: form_helper
INFO - 2023-04-26 10:30:41 --> Helper loaded: lang_helper
INFO - 2023-04-26 10:30:41 --> Helper loaded: security_helper
INFO - 2023-04-26 10:30:41 --> Helper loaded: cookie_helper
INFO - 2023-04-26 10:30:41 --> Database Driver Class Initialized
INFO - 2023-04-26 10:30:41 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-26 10:30:41 --> Parser Class Initialized
INFO - 2023-04-26 10:30:41 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-26 10:30:41 --> Pagination Class Initialized
INFO - 2023-04-26 10:30:41 --> Form Validation Class Initialized
INFO - 2023-04-26 10:30:41 --> Controller Class Initialized
INFO - 2023-04-26 10:30:41 --> Model Class Initialized
DEBUG - 2023-04-26 10:30:41 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-04-26 10:30:41 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-26 10:30:41 --> Model Class Initialized
DEBUG - 2023-04-26 10:30:41 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-26 10:30:41 --> Model Class Initialized
INFO - 2023-04-26 10:30:41 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice.php
DEBUG - 2023-04-26 10:30:41 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-04-26 10:30:41 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-04-26 10:30:41 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-04-26 10:30:41 --> Model Class Initialized
INFO - 2023-04-26 10:30:41 --> Model Class Initialized
INFO - 2023-04-26 10:30:41 --> Model Class Initialized
INFO - 2023-04-26 10:30:41 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-04-26 10:30:41 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-04-26 10:30:41 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-04-26 10:30:41 --> Final output sent to browser
DEBUG - 2023-04-26 10:30:41 --> Total execution time: 0.1535
ERROR - 2023-04-26 10:30:42 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-26 10:30:42 --> Config Class Initialized
INFO - 2023-04-26 10:30:42 --> Hooks Class Initialized
DEBUG - 2023-04-26 10:30:42 --> UTF-8 Support Enabled
INFO - 2023-04-26 10:30:42 --> Utf8 Class Initialized
INFO - 2023-04-26 10:30:42 --> URI Class Initialized
INFO - 2023-04-26 10:30:42 --> Router Class Initialized
INFO - 2023-04-26 10:30:42 --> Output Class Initialized
INFO - 2023-04-26 10:30:42 --> Security Class Initialized
DEBUG - 2023-04-26 10:30:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-26 10:30:42 --> Input Class Initialized
INFO - 2023-04-26 10:30:42 --> Language Class Initialized
INFO - 2023-04-26 10:30:42 --> Loader Class Initialized
INFO - 2023-04-26 10:30:42 --> Helper loaded: url_helper
INFO - 2023-04-26 10:30:42 --> Helper loaded: file_helper
INFO - 2023-04-26 10:30:42 --> Helper loaded: html_helper
INFO - 2023-04-26 10:30:42 --> Helper loaded: text_helper
INFO - 2023-04-26 10:30:42 --> Helper loaded: form_helper
INFO - 2023-04-26 10:30:42 --> Helper loaded: lang_helper
INFO - 2023-04-26 10:30:42 --> Helper loaded: security_helper
INFO - 2023-04-26 10:30:42 --> Helper loaded: cookie_helper
INFO - 2023-04-26 10:30:42 --> Database Driver Class Initialized
INFO - 2023-04-26 10:30:42 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-26 10:30:42 --> Parser Class Initialized
INFO - 2023-04-26 10:30:42 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-26 10:30:42 --> Pagination Class Initialized
INFO - 2023-04-26 10:30:42 --> Form Validation Class Initialized
INFO - 2023-04-26 10:30:42 --> Controller Class Initialized
INFO - 2023-04-26 10:30:42 --> Model Class Initialized
DEBUG - 2023-04-26 10:30:42 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-04-26 10:30:42 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-26 10:30:42 --> Model Class Initialized
DEBUG - 2023-04-26 10:30:42 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-26 10:30:42 --> Model Class Initialized
INFO - 2023-04-26 10:30:42 --> Final output sent to browser
DEBUG - 2023-04-26 10:30:42 --> Total execution time: 0.0562
ERROR - 2023-04-26 10:30:49 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-26 10:30:49 --> Config Class Initialized
INFO - 2023-04-26 10:30:49 --> Hooks Class Initialized
DEBUG - 2023-04-26 10:30:49 --> UTF-8 Support Enabled
INFO - 2023-04-26 10:30:49 --> Utf8 Class Initialized
INFO - 2023-04-26 10:30:49 --> URI Class Initialized
INFO - 2023-04-26 10:30:49 --> Router Class Initialized
INFO - 2023-04-26 10:30:49 --> Output Class Initialized
INFO - 2023-04-26 10:30:49 --> Security Class Initialized
DEBUG - 2023-04-26 10:30:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-26 10:30:49 --> Input Class Initialized
INFO - 2023-04-26 10:30:49 --> Language Class Initialized
INFO - 2023-04-26 10:30:49 --> Loader Class Initialized
INFO - 2023-04-26 10:30:49 --> Helper loaded: url_helper
INFO - 2023-04-26 10:30:49 --> Helper loaded: file_helper
INFO - 2023-04-26 10:30:49 --> Helper loaded: html_helper
INFO - 2023-04-26 10:30:49 --> Helper loaded: text_helper
INFO - 2023-04-26 10:30:49 --> Helper loaded: form_helper
INFO - 2023-04-26 10:30:49 --> Helper loaded: lang_helper
INFO - 2023-04-26 10:30:49 --> Helper loaded: security_helper
INFO - 2023-04-26 10:30:49 --> Helper loaded: cookie_helper
INFO - 2023-04-26 10:30:49 --> Database Driver Class Initialized
INFO - 2023-04-26 10:30:49 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-26 10:30:49 --> Parser Class Initialized
INFO - 2023-04-26 10:30:49 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-26 10:30:49 --> Pagination Class Initialized
INFO - 2023-04-26 10:30:49 --> Form Validation Class Initialized
INFO - 2023-04-26 10:30:49 --> Controller Class Initialized
INFO - 2023-04-26 10:30:49 --> Model Class Initialized
DEBUG - 2023-04-26 10:30:49 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-04-26 10:30:49 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-26 10:30:49 --> Model Class Initialized
DEBUG - 2023-04-26 10:30:49 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-26 10:30:49 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/stockrequest/add_stockrequest_form.php
DEBUG - 2023-04-26 10:30:49 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-04-26 10:30:49 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-04-26 10:30:49 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-04-26 10:30:49 --> Model Class Initialized
INFO - 2023-04-26 10:30:49 --> Model Class Initialized
INFO - 2023-04-26 10:30:49 --> Model Class Initialized
INFO - 2023-04-26 10:30:50 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-04-26 10:30:50 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-04-26 10:30:50 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-04-26 10:30:50 --> Final output sent to browser
DEBUG - 2023-04-26 10:30:50 --> Total execution time: 0.1672
ERROR - 2023-04-26 10:30:56 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-26 10:30:56 --> Config Class Initialized
INFO - 2023-04-26 10:30:56 --> Hooks Class Initialized
DEBUG - 2023-04-26 10:30:56 --> UTF-8 Support Enabled
INFO - 2023-04-26 10:30:56 --> Utf8 Class Initialized
INFO - 2023-04-26 10:30:56 --> URI Class Initialized
INFO - 2023-04-26 10:30:56 --> Router Class Initialized
INFO - 2023-04-26 10:30:56 --> Output Class Initialized
INFO - 2023-04-26 10:30:56 --> Security Class Initialized
DEBUG - 2023-04-26 10:30:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-26 10:30:56 --> Input Class Initialized
INFO - 2023-04-26 10:30:56 --> Language Class Initialized
INFO - 2023-04-26 10:30:56 --> Loader Class Initialized
INFO - 2023-04-26 10:30:56 --> Helper loaded: url_helper
INFO - 2023-04-26 10:30:56 --> Helper loaded: file_helper
INFO - 2023-04-26 10:30:56 --> Helper loaded: html_helper
INFO - 2023-04-26 10:30:56 --> Helper loaded: text_helper
INFO - 2023-04-26 10:30:56 --> Helper loaded: form_helper
INFO - 2023-04-26 10:30:56 --> Helper loaded: lang_helper
INFO - 2023-04-26 10:30:56 --> Helper loaded: security_helper
INFO - 2023-04-26 10:30:56 --> Helper loaded: cookie_helper
INFO - 2023-04-26 10:30:56 --> Database Driver Class Initialized
INFO - 2023-04-26 10:30:56 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-26 10:30:56 --> Parser Class Initialized
INFO - 2023-04-26 10:30:56 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-26 10:30:56 --> Pagination Class Initialized
INFO - 2023-04-26 10:30:56 --> Form Validation Class Initialized
INFO - 2023-04-26 10:30:56 --> Controller Class Initialized
INFO - 2023-04-26 10:30:56 --> Model Class Initialized
INFO - 2023-04-26 10:30:56 --> Final output sent to browser
DEBUG - 2023-04-26 10:30:56 --> Total execution time: 0.0140
ERROR - 2023-04-26 10:31:01 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-26 10:31:01 --> Config Class Initialized
INFO - 2023-04-26 10:31:01 --> Hooks Class Initialized
DEBUG - 2023-04-26 10:31:01 --> UTF-8 Support Enabled
INFO - 2023-04-26 10:31:01 --> Utf8 Class Initialized
INFO - 2023-04-26 10:31:01 --> URI Class Initialized
INFO - 2023-04-26 10:31:01 --> Router Class Initialized
INFO - 2023-04-26 10:31:01 --> Output Class Initialized
INFO - 2023-04-26 10:31:01 --> Security Class Initialized
DEBUG - 2023-04-26 10:31:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-26 10:31:01 --> Input Class Initialized
INFO - 2023-04-26 10:31:01 --> Language Class Initialized
INFO - 2023-04-26 10:31:01 --> Loader Class Initialized
INFO - 2023-04-26 10:31:01 --> Helper loaded: url_helper
INFO - 2023-04-26 10:31:01 --> Helper loaded: file_helper
INFO - 2023-04-26 10:31:01 --> Helper loaded: html_helper
INFO - 2023-04-26 10:31:01 --> Helper loaded: text_helper
INFO - 2023-04-26 10:31:01 --> Helper loaded: form_helper
INFO - 2023-04-26 10:31:01 --> Helper loaded: lang_helper
INFO - 2023-04-26 10:31:01 --> Helper loaded: security_helper
INFO - 2023-04-26 10:31:01 --> Helper loaded: cookie_helper
INFO - 2023-04-26 10:31:01 --> Database Driver Class Initialized
INFO - 2023-04-26 10:31:01 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-26 10:31:01 --> Parser Class Initialized
INFO - 2023-04-26 10:31:01 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-26 10:31:01 --> Pagination Class Initialized
INFO - 2023-04-26 10:31:01 --> Form Validation Class Initialized
INFO - 2023-04-26 10:31:01 --> Controller Class Initialized
INFO - 2023-04-26 10:31:01 --> Model Class Initialized
DEBUG - 2023-04-26 10:31:01 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-04-26 10:31:01 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-26 10:31:01 --> Model Class Initialized
DEBUG - 2023-04-26 10:31:01 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-26 10:31:01 --> Model Class Initialized
INFO - 2023-04-26 10:31:01 --> Final output sent to browser
DEBUG - 2023-04-26 10:31:01 --> Total execution time: 0.0179
ERROR - 2023-04-26 10:31:02 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-26 10:31:02 --> Config Class Initialized
INFO - 2023-04-26 10:31:02 --> Hooks Class Initialized
DEBUG - 2023-04-26 10:31:02 --> UTF-8 Support Enabled
INFO - 2023-04-26 10:31:02 --> Utf8 Class Initialized
INFO - 2023-04-26 10:31:02 --> URI Class Initialized
INFO - 2023-04-26 10:31:02 --> Router Class Initialized
INFO - 2023-04-26 10:31:02 --> Output Class Initialized
INFO - 2023-04-26 10:31:02 --> Security Class Initialized
DEBUG - 2023-04-26 10:31:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-26 10:31:02 --> Input Class Initialized
INFO - 2023-04-26 10:31:02 --> Language Class Initialized
INFO - 2023-04-26 10:31:02 --> Loader Class Initialized
INFO - 2023-04-26 10:31:02 --> Helper loaded: url_helper
INFO - 2023-04-26 10:31:02 --> Helper loaded: file_helper
INFO - 2023-04-26 10:31:02 --> Helper loaded: html_helper
INFO - 2023-04-26 10:31:02 --> Helper loaded: text_helper
INFO - 2023-04-26 10:31:02 --> Helper loaded: form_helper
INFO - 2023-04-26 10:31:02 --> Helper loaded: lang_helper
INFO - 2023-04-26 10:31:02 --> Helper loaded: security_helper
INFO - 2023-04-26 10:31:02 --> Helper loaded: cookie_helper
INFO - 2023-04-26 10:31:02 --> Database Driver Class Initialized
INFO - 2023-04-26 10:31:02 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-26 10:31:02 --> Parser Class Initialized
INFO - 2023-04-26 10:31:02 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-26 10:31:02 --> Pagination Class Initialized
INFO - 2023-04-26 10:31:02 --> Form Validation Class Initialized
INFO - 2023-04-26 10:31:02 --> Controller Class Initialized
INFO - 2023-04-26 10:31:02 --> Model Class Initialized
DEBUG - 2023-04-26 10:31:02 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-04-26 10:31:02 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-26 10:31:02 --> Model Class Initialized
DEBUG - 2023-04-26 10:31:02 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-26 10:31:02 --> Model Class Initialized
INFO - 2023-04-26 10:31:02 --> Final output sent to browser
DEBUG - 2023-04-26 10:31:02 --> Total execution time: 0.0164
ERROR - 2023-04-26 10:31:02 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-26 10:31:02 --> Config Class Initialized
INFO - 2023-04-26 10:31:02 --> Hooks Class Initialized
DEBUG - 2023-04-26 10:31:02 --> UTF-8 Support Enabled
INFO - 2023-04-26 10:31:02 --> Utf8 Class Initialized
INFO - 2023-04-26 10:31:02 --> URI Class Initialized
INFO - 2023-04-26 10:31:02 --> Router Class Initialized
INFO - 2023-04-26 10:31:02 --> Output Class Initialized
INFO - 2023-04-26 10:31:02 --> Security Class Initialized
DEBUG - 2023-04-26 10:31:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-26 10:31:02 --> Input Class Initialized
INFO - 2023-04-26 10:31:02 --> Language Class Initialized
INFO - 2023-04-26 10:31:02 --> Loader Class Initialized
INFO - 2023-04-26 10:31:02 --> Helper loaded: url_helper
INFO - 2023-04-26 10:31:02 --> Helper loaded: file_helper
INFO - 2023-04-26 10:31:02 --> Helper loaded: html_helper
INFO - 2023-04-26 10:31:02 --> Helper loaded: text_helper
INFO - 2023-04-26 10:31:02 --> Helper loaded: form_helper
INFO - 2023-04-26 10:31:02 --> Helper loaded: lang_helper
INFO - 2023-04-26 10:31:02 --> Helper loaded: security_helper
INFO - 2023-04-26 10:31:02 --> Helper loaded: cookie_helper
INFO - 2023-04-26 10:31:02 --> Database Driver Class Initialized
INFO - 2023-04-26 10:31:02 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-26 10:31:02 --> Parser Class Initialized
INFO - 2023-04-26 10:31:02 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-26 10:31:02 --> Pagination Class Initialized
INFO - 2023-04-26 10:31:02 --> Form Validation Class Initialized
INFO - 2023-04-26 10:31:02 --> Controller Class Initialized
INFO - 2023-04-26 10:31:02 --> Model Class Initialized
DEBUG - 2023-04-26 10:31:02 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-04-26 10:31:02 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-26 10:31:02 --> Model Class Initialized
DEBUG - 2023-04-26 10:31:02 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-26 10:31:02 --> Model Class Initialized
INFO - 2023-04-26 10:31:02 --> Final output sent to browser
DEBUG - 2023-04-26 10:31:02 --> Total execution time: 0.0175
ERROR - 2023-04-26 10:31:03 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-26 10:31:03 --> Config Class Initialized
INFO - 2023-04-26 10:31:03 --> Hooks Class Initialized
DEBUG - 2023-04-26 10:31:03 --> UTF-8 Support Enabled
INFO - 2023-04-26 10:31:03 --> Utf8 Class Initialized
INFO - 2023-04-26 10:31:03 --> URI Class Initialized
INFO - 2023-04-26 10:31:03 --> Router Class Initialized
INFO - 2023-04-26 10:31:03 --> Output Class Initialized
INFO - 2023-04-26 10:31:03 --> Security Class Initialized
DEBUG - 2023-04-26 10:31:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-26 10:31:03 --> Input Class Initialized
INFO - 2023-04-26 10:31:03 --> Language Class Initialized
INFO - 2023-04-26 10:31:03 --> Loader Class Initialized
INFO - 2023-04-26 10:31:03 --> Helper loaded: url_helper
INFO - 2023-04-26 10:31:03 --> Helper loaded: file_helper
INFO - 2023-04-26 10:31:03 --> Helper loaded: html_helper
INFO - 2023-04-26 10:31:03 --> Helper loaded: text_helper
INFO - 2023-04-26 10:31:03 --> Helper loaded: form_helper
INFO - 2023-04-26 10:31:03 --> Helper loaded: lang_helper
INFO - 2023-04-26 10:31:03 --> Helper loaded: security_helper
INFO - 2023-04-26 10:31:03 --> Helper loaded: cookie_helper
INFO - 2023-04-26 10:31:03 --> Database Driver Class Initialized
INFO - 2023-04-26 10:31:03 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-26 10:31:03 --> Parser Class Initialized
INFO - 2023-04-26 10:31:03 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-26 10:31:03 --> Pagination Class Initialized
INFO - 2023-04-26 10:31:03 --> Form Validation Class Initialized
INFO - 2023-04-26 10:31:03 --> Controller Class Initialized
INFO - 2023-04-26 10:31:03 --> Model Class Initialized
DEBUG - 2023-04-26 10:31:03 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-04-26 10:31:03 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-26 10:31:03 --> Model Class Initialized
DEBUG - 2023-04-26 10:31:03 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-26 10:31:03 --> Model Class Initialized
INFO - 2023-04-26 10:31:03 --> Final output sent to browser
DEBUG - 2023-04-26 10:31:03 --> Total execution time: 0.0172
ERROR - 2023-04-26 10:31:04 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-26 10:31:04 --> Config Class Initialized
INFO - 2023-04-26 10:31:04 --> Hooks Class Initialized
DEBUG - 2023-04-26 10:31:04 --> UTF-8 Support Enabled
INFO - 2023-04-26 10:31:04 --> Utf8 Class Initialized
INFO - 2023-04-26 10:31:04 --> URI Class Initialized
INFO - 2023-04-26 10:31:04 --> Router Class Initialized
INFO - 2023-04-26 10:31:04 --> Output Class Initialized
INFO - 2023-04-26 10:31:04 --> Security Class Initialized
DEBUG - 2023-04-26 10:31:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-26 10:31:04 --> Input Class Initialized
INFO - 2023-04-26 10:31:04 --> Language Class Initialized
INFO - 2023-04-26 10:31:04 --> Loader Class Initialized
INFO - 2023-04-26 10:31:04 --> Helper loaded: url_helper
INFO - 2023-04-26 10:31:04 --> Helper loaded: file_helper
INFO - 2023-04-26 10:31:04 --> Helper loaded: html_helper
INFO - 2023-04-26 10:31:04 --> Helper loaded: text_helper
INFO - 2023-04-26 10:31:04 --> Helper loaded: form_helper
INFO - 2023-04-26 10:31:04 --> Helper loaded: lang_helper
INFO - 2023-04-26 10:31:04 --> Helper loaded: security_helper
INFO - 2023-04-26 10:31:04 --> Helper loaded: cookie_helper
INFO - 2023-04-26 10:31:04 --> Database Driver Class Initialized
INFO - 2023-04-26 10:31:04 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-26 10:31:04 --> Parser Class Initialized
INFO - 2023-04-26 10:31:04 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-26 10:31:04 --> Pagination Class Initialized
INFO - 2023-04-26 10:31:04 --> Form Validation Class Initialized
INFO - 2023-04-26 10:31:04 --> Controller Class Initialized
INFO - 2023-04-26 10:31:04 --> Model Class Initialized
DEBUG - 2023-04-26 10:31:04 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-04-26 10:31:04 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-26 10:31:04 --> Model Class Initialized
DEBUG - 2023-04-26 10:31:04 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-26 10:31:04 --> Model Class Initialized
INFO - 2023-04-26 10:31:04 --> Final output sent to browser
DEBUG - 2023-04-26 10:31:04 --> Total execution time: 0.0176
ERROR - 2023-04-26 10:31:07 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-26 10:31:07 --> Config Class Initialized
INFO - 2023-04-26 10:31:07 --> Hooks Class Initialized
DEBUG - 2023-04-26 10:31:07 --> UTF-8 Support Enabled
INFO - 2023-04-26 10:31:07 --> Utf8 Class Initialized
INFO - 2023-04-26 10:31:07 --> URI Class Initialized
INFO - 2023-04-26 10:31:07 --> Router Class Initialized
INFO - 2023-04-26 10:31:07 --> Output Class Initialized
INFO - 2023-04-26 10:31:07 --> Security Class Initialized
DEBUG - 2023-04-26 10:31:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-26 10:31:07 --> Input Class Initialized
INFO - 2023-04-26 10:31:07 --> Language Class Initialized
INFO - 2023-04-26 10:31:07 --> Loader Class Initialized
INFO - 2023-04-26 10:31:07 --> Helper loaded: url_helper
INFO - 2023-04-26 10:31:07 --> Helper loaded: file_helper
INFO - 2023-04-26 10:31:07 --> Helper loaded: html_helper
INFO - 2023-04-26 10:31:07 --> Helper loaded: text_helper
INFO - 2023-04-26 10:31:07 --> Helper loaded: form_helper
INFO - 2023-04-26 10:31:07 --> Helper loaded: lang_helper
INFO - 2023-04-26 10:31:07 --> Helper loaded: security_helper
INFO - 2023-04-26 10:31:07 --> Helper loaded: cookie_helper
INFO - 2023-04-26 10:31:07 --> Database Driver Class Initialized
INFO - 2023-04-26 10:31:07 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-26 10:31:07 --> Parser Class Initialized
INFO - 2023-04-26 10:31:07 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-26 10:31:07 --> Pagination Class Initialized
INFO - 2023-04-26 10:31:07 --> Form Validation Class Initialized
INFO - 2023-04-26 10:31:07 --> Controller Class Initialized
INFO - 2023-04-26 10:31:07 --> Model Class Initialized
DEBUG - 2023-04-26 10:31:07 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-04-26 10:31:07 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-26 10:31:07 --> Model Class Initialized
DEBUG - 2023-04-26 10:31:07 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-26 10:31:07 --> Model Class Initialized
INFO - 2023-04-26 10:31:07 --> Model Class Initialized
INFO - 2023-04-26 10:31:07 --> Final output sent to browser
DEBUG - 2023-04-26 10:31:07 --> Total execution time: 0.0210
ERROR - 2023-04-26 10:31:10 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-26 10:31:10 --> Config Class Initialized
INFO - 2023-04-26 10:31:10 --> Hooks Class Initialized
DEBUG - 2023-04-26 10:31:10 --> UTF-8 Support Enabled
INFO - 2023-04-26 10:31:10 --> Utf8 Class Initialized
INFO - 2023-04-26 10:31:10 --> URI Class Initialized
INFO - 2023-04-26 10:31:10 --> Router Class Initialized
INFO - 2023-04-26 10:31:10 --> Output Class Initialized
INFO - 2023-04-26 10:31:10 --> Security Class Initialized
DEBUG - 2023-04-26 10:31:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-26 10:31:10 --> Input Class Initialized
INFO - 2023-04-26 10:31:10 --> Language Class Initialized
INFO - 2023-04-26 10:31:10 --> Loader Class Initialized
INFO - 2023-04-26 10:31:10 --> Helper loaded: url_helper
INFO - 2023-04-26 10:31:10 --> Helper loaded: file_helper
INFO - 2023-04-26 10:31:10 --> Helper loaded: html_helper
INFO - 2023-04-26 10:31:10 --> Helper loaded: text_helper
INFO - 2023-04-26 10:31:10 --> Helper loaded: form_helper
INFO - 2023-04-26 10:31:10 --> Helper loaded: lang_helper
INFO - 2023-04-26 10:31:10 --> Helper loaded: security_helper
INFO - 2023-04-26 10:31:10 --> Helper loaded: cookie_helper
INFO - 2023-04-26 10:31:10 --> Database Driver Class Initialized
INFO - 2023-04-26 10:31:10 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-26 10:31:10 --> Parser Class Initialized
INFO - 2023-04-26 10:31:10 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-26 10:31:10 --> Pagination Class Initialized
INFO - 2023-04-26 10:31:10 --> Form Validation Class Initialized
INFO - 2023-04-26 10:31:10 --> Controller Class Initialized
INFO - 2023-04-26 10:31:10 --> Model Class Initialized
DEBUG - 2023-04-26 10:31:10 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-04-26 10:31:10 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-26 10:31:10 --> Model Class Initialized
DEBUG - 2023-04-26 10:31:10 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-26 10:31:10 --> Model Class Initialized
INFO - 2023-04-26 10:31:10 --> Final output sent to browser
DEBUG - 2023-04-26 10:31:10 --> Total execution time: 0.0197
ERROR - 2023-04-26 10:31:18 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-26 10:31:18 --> Config Class Initialized
INFO - 2023-04-26 10:31:18 --> Hooks Class Initialized
DEBUG - 2023-04-26 10:31:18 --> UTF-8 Support Enabled
INFO - 2023-04-26 10:31:18 --> Utf8 Class Initialized
INFO - 2023-04-26 10:31:18 --> URI Class Initialized
INFO - 2023-04-26 10:31:18 --> Router Class Initialized
INFO - 2023-04-26 10:31:18 --> Output Class Initialized
INFO - 2023-04-26 10:31:18 --> Security Class Initialized
DEBUG - 2023-04-26 10:31:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-26 10:31:18 --> Input Class Initialized
INFO - 2023-04-26 10:31:18 --> Language Class Initialized
INFO - 2023-04-26 10:31:18 --> Loader Class Initialized
INFO - 2023-04-26 10:31:18 --> Helper loaded: url_helper
INFO - 2023-04-26 10:31:18 --> Helper loaded: file_helper
INFO - 2023-04-26 10:31:18 --> Helper loaded: html_helper
INFO - 2023-04-26 10:31:18 --> Helper loaded: text_helper
INFO - 2023-04-26 10:31:18 --> Helper loaded: form_helper
INFO - 2023-04-26 10:31:18 --> Helper loaded: lang_helper
INFO - 2023-04-26 10:31:18 --> Helper loaded: security_helper
INFO - 2023-04-26 10:31:18 --> Helper loaded: cookie_helper
INFO - 2023-04-26 10:31:18 --> Database Driver Class Initialized
INFO - 2023-04-26 10:31:18 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-26 10:31:18 --> Parser Class Initialized
INFO - 2023-04-26 10:31:18 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-26 10:31:18 --> Pagination Class Initialized
INFO - 2023-04-26 10:31:18 --> Form Validation Class Initialized
INFO - 2023-04-26 10:31:18 --> Controller Class Initialized
INFO - 2023-04-26 10:31:18 --> Model Class Initialized
DEBUG - 2023-04-26 10:31:18 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-04-26 10:31:18 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-26 10:31:18 --> Model Class Initialized
DEBUG - 2023-04-26 10:31:18 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-26 10:31:18 --> Model Class Initialized
INFO - 2023-04-26 10:31:18 --> Final output sent to browser
DEBUG - 2023-04-26 10:31:18 --> Total execution time: 0.0173
ERROR - 2023-04-26 10:31:19 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-26 10:31:19 --> Config Class Initialized
INFO - 2023-04-26 10:31:19 --> Hooks Class Initialized
DEBUG - 2023-04-26 10:31:19 --> UTF-8 Support Enabled
INFO - 2023-04-26 10:31:19 --> Utf8 Class Initialized
INFO - 2023-04-26 10:31:19 --> URI Class Initialized
INFO - 2023-04-26 10:31:19 --> Router Class Initialized
INFO - 2023-04-26 10:31:19 --> Output Class Initialized
INFO - 2023-04-26 10:31:19 --> Security Class Initialized
DEBUG - 2023-04-26 10:31:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-26 10:31:19 --> Input Class Initialized
INFO - 2023-04-26 10:31:19 --> Language Class Initialized
INFO - 2023-04-26 10:31:19 --> Loader Class Initialized
INFO - 2023-04-26 10:31:19 --> Helper loaded: url_helper
INFO - 2023-04-26 10:31:19 --> Helper loaded: file_helper
INFO - 2023-04-26 10:31:19 --> Helper loaded: html_helper
INFO - 2023-04-26 10:31:19 --> Helper loaded: text_helper
INFO - 2023-04-26 10:31:19 --> Helper loaded: form_helper
INFO - 2023-04-26 10:31:19 --> Helper loaded: lang_helper
INFO - 2023-04-26 10:31:19 --> Helper loaded: security_helper
INFO - 2023-04-26 10:31:19 --> Helper loaded: cookie_helper
INFO - 2023-04-26 10:31:19 --> Database Driver Class Initialized
INFO - 2023-04-26 10:31:19 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-26 10:31:19 --> Parser Class Initialized
INFO - 2023-04-26 10:31:19 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-26 10:31:19 --> Pagination Class Initialized
INFO - 2023-04-26 10:31:19 --> Form Validation Class Initialized
INFO - 2023-04-26 10:31:19 --> Controller Class Initialized
INFO - 2023-04-26 10:31:19 --> Model Class Initialized
DEBUG - 2023-04-26 10:31:19 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-04-26 10:31:19 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-26 10:31:19 --> Model Class Initialized
DEBUG - 2023-04-26 10:31:19 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-26 10:31:19 --> Model Class Initialized
INFO - 2023-04-26 10:31:19 --> Final output sent to browser
DEBUG - 2023-04-26 10:31:19 --> Total execution time: 0.0162
ERROR - 2023-04-26 10:31:20 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-26 10:31:20 --> Config Class Initialized
INFO - 2023-04-26 10:31:20 --> Hooks Class Initialized
DEBUG - 2023-04-26 10:31:20 --> UTF-8 Support Enabled
INFO - 2023-04-26 10:31:20 --> Utf8 Class Initialized
INFO - 2023-04-26 10:31:20 --> URI Class Initialized
INFO - 2023-04-26 10:31:20 --> Router Class Initialized
INFO - 2023-04-26 10:31:20 --> Output Class Initialized
INFO - 2023-04-26 10:31:20 --> Security Class Initialized
DEBUG - 2023-04-26 10:31:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-26 10:31:20 --> Input Class Initialized
INFO - 2023-04-26 10:31:20 --> Language Class Initialized
INFO - 2023-04-26 10:31:20 --> Loader Class Initialized
INFO - 2023-04-26 10:31:20 --> Helper loaded: url_helper
INFO - 2023-04-26 10:31:20 --> Helper loaded: file_helper
INFO - 2023-04-26 10:31:20 --> Helper loaded: html_helper
INFO - 2023-04-26 10:31:20 --> Helper loaded: text_helper
INFO - 2023-04-26 10:31:20 --> Helper loaded: form_helper
INFO - 2023-04-26 10:31:20 --> Helper loaded: lang_helper
INFO - 2023-04-26 10:31:20 --> Helper loaded: security_helper
INFO - 2023-04-26 10:31:20 --> Helper loaded: cookie_helper
INFO - 2023-04-26 10:31:20 --> Database Driver Class Initialized
INFO - 2023-04-26 10:31:20 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-26 10:31:20 --> Parser Class Initialized
INFO - 2023-04-26 10:31:20 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-26 10:31:20 --> Pagination Class Initialized
INFO - 2023-04-26 10:31:20 --> Form Validation Class Initialized
INFO - 2023-04-26 10:31:20 --> Controller Class Initialized
INFO - 2023-04-26 10:31:20 --> Model Class Initialized
DEBUG - 2023-04-26 10:31:20 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-04-26 10:31:20 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-26 10:31:20 --> Model Class Initialized
DEBUG - 2023-04-26 10:31:20 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-26 10:31:20 --> Model Class Initialized
INFO - 2023-04-26 10:31:20 --> Final output sent to browser
DEBUG - 2023-04-26 10:31:20 --> Total execution time: 0.0177
ERROR - 2023-04-26 10:31:20 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-26 10:31:20 --> Config Class Initialized
INFO - 2023-04-26 10:31:20 --> Hooks Class Initialized
DEBUG - 2023-04-26 10:31:20 --> UTF-8 Support Enabled
INFO - 2023-04-26 10:31:20 --> Utf8 Class Initialized
INFO - 2023-04-26 10:31:20 --> URI Class Initialized
INFO - 2023-04-26 10:31:20 --> Router Class Initialized
INFO - 2023-04-26 10:31:20 --> Output Class Initialized
INFO - 2023-04-26 10:31:20 --> Security Class Initialized
DEBUG - 2023-04-26 10:31:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-26 10:31:20 --> Input Class Initialized
INFO - 2023-04-26 10:31:20 --> Language Class Initialized
INFO - 2023-04-26 10:31:20 --> Loader Class Initialized
INFO - 2023-04-26 10:31:20 --> Helper loaded: url_helper
INFO - 2023-04-26 10:31:20 --> Helper loaded: file_helper
INFO - 2023-04-26 10:31:20 --> Helper loaded: html_helper
INFO - 2023-04-26 10:31:20 --> Helper loaded: text_helper
INFO - 2023-04-26 10:31:20 --> Helper loaded: form_helper
INFO - 2023-04-26 10:31:20 --> Helper loaded: lang_helper
INFO - 2023-04-26 10:31:20 --> Helper loaded: security_helper
INFO - 2023-04-26 10:31:20 --> Helper loaded: cookie_helper
INFO - 2023-04-26 10:31:20 --> Database Driver Class Initialized
INFO - 2023-04-26 10:31:20 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-26 10:31:20 --> Parser Class Initialized
INFO - 2023-04-26 10:31:20 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-26 10:31:20 --> Pagination Class Initialized
INFO - 2023-04-26 10:31:20 --> Form Validation Class Initialized
INFO - 2023-04-26 10:31:20 --> Controller Class Initialized
INFO - 2023-04-26 10:31:20 --> Model Class Initialized
DEBUG - 2023-04-26 10:31:20 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-04-26 10:31:20 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-26 10:31:20 --> Model Class Initialized
DEBUG - 2023-04-26 10:31:20 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-26 10:31:20 --> Model Class Initialized
INFO - 2023-04-26 10:31:20 --> Final output sent to browser
DEBUG - 2023-04-26 10:31:20 --> Total execution time: 0.0177
ERROR - 2023-04-26 10:31:22 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-26 10:31:22 --> Config Class Initialized
INFO - 2023-04-26 10:31:22 --> Hooks Class Initialized
DEBUG - 2023-04-26 10:31:22 --> UTF-8 Support Enabled
INFO - 2023-04-26 10:31:22 --> Utf8 Class Initialized
INFO - 2023-04-26 10:31:22 --> URI Class Initialized
INFO - 2023-04-26 10:31:22 --> Router Class Initialized
INFO - 2023-04-26 10:31:22 --> Output Class Initialized
INFO - 2023-04-26 10:31:22 --> Security Class Initialized
DEBUG - 2023-04-26 10:31:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-26 10:31:22 --> Input Class Initialized
INFO - 2023-04-26 10:31:22 --> Language Class Initialized
INFO - 2023-04-26 10:31:22 --> Loader Class Initialized
INFO - 2023-04-26 10:31:22 --> Helper loaded: url_helper
INFO - 2023-04-26 10:31:22 --> Helper loaded: file_helper
INFO - 2023-04-26 10:31:22 --> Helper loaded: html_helper
INFO - 2023-04-26 10:31:22 --> Helper loaded: text_helper
INFO - 2023-04-26 10:31:22 --> Helper loaded: form_helper
INFO - 2023-04-26 10:31:22 --> Helper loaded: lang_helper
INFO - 2023-04-26 10:31:22 --> Helper loaded: security_helper
INFO - 2023-04-26 10:31:22 --> Helper loaded: cookie_helper
INFO - 2023-04-26 10:31:22 --> Database Driver Class Initialized
INFO - 2023-04-26 10:31:22 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-26 10:31:22 --> Parser Class Initialized
INFO - 2023-04-26 10:31:22 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-26 10:31:22 --> Pagination Class Initialized
INFO - 2023-04-26 10:31:22 --> Form Validation Class Initialized
INFO - 2023-04-26 10:31:22 --> Controller Class Initialized
INFO - 2023-04-26 10:31:22 --> Model Class Initialized
DEBUG - 2023-04-26 10:31:22 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-04-26 10:31:22 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-26 10:31:22 --> Model Class Initialized
DEBUG - 2023-04-26 10:31:22 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-26 10:31:22 --> Model Class Initialized
INFO - 2023-04-26 10:31:22 --> Final output sent to browser
DEBUG - 2023-04-26 10:31:22 --> Total execution time: 0.0177
ERROR - 2023-04-26 10:31:23 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-26 10:31:23 --> Config Class Initialized
INFO - 2023-04-26 10:31:23 --> Hooks Class Initialized
DEBUG - 2023-04-26 10:31:23 --> UTF-8 Support Enabled
INFO - 2023-04-26 10:31:23 --> Utf8 Class Initialized
INFO - 2023-04-26 10:31:23 --> URI Class Initialized
INFO - 2023-04-26 10:31:23 --> Router Class Initialized
INFO - 2023-04-26 10:31:23 --> Output Class Initialized
INFO - 2023-04-26 10:31:23 --> Security Class Initialized
DEBUG - 2023-04-26 10:31:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-26 10:31:23 --> Input Class Initialized
INFO - 2023-04-26 10:31:23 --> Language Class Initialized
INFO - 2023-04-26 10:31:23 --> Loader Class Initialized
INFO - 2023-04-26 10:31:23 --> Helper loaded: url_helper
INFO - 2023-04-26 10:31:23 --> Helper loaded: file_helper
INFO - 2023-04-26 10:31:23 --> Helper loaded: html_helper
INFO - 2023-04-26 10:31:23 --> Helper loaded: text_helper
INFO - 2023-04-26 10:31:23 --> Helper loaded: form_helper
INFO - 2023-04-26 10:31:23 --> Helper loaded: lang_helper
INFO - 2023-04-26 10:31:23 --> Helper loaded: security_helper
INFO - 2023-04-26 10:31:23 --> Helper loaded: cookie_helper
INFO - 2023-04-26 10:31:23 --> Database Driver Class Initialized
INFO - 2023-04-26 10:31:23 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-26 10:31:23 --> Parser Class Initialized
INFO - 2023-04-26 10:31:23 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-26 10:31:23 --> Pagination Class Initialized
INFO - 2023-04-26 10:31:23 --> Form Validation Class Initialized
INFO - 2023-04-26 10:31:23 --> Controller Class Initialized
INFO - 2023-04-26 10:31:23 --> Model Class Initialized
DEBUG - 2023-04-26 10:31:23 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-04-26 10:31:23 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-26 10:31:23 --> Model Class Initialized
DEBUG - 2023-04-26 10:31:23 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-26 10:31:23 --> Model Class Initialized
INFO - 2023-04-26 10:31:23 --> Final output sent to browser
DEBUG - 2023-04-26 10:31:23 --> Total execution time: 0.0175
ERROR - 2023-04-26 10:31:25 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-26 10:31:25 --> Config Class Initialized
INFO - 2023-04-26 10:31:25 --> Hooks Class Initialized
DEBUG - 2023-04-26 10:31:25 --> UTF-8 Support Enabled
INFO - 2023-04-26 10:31:25 --> Utf8 Class Initialized
INFO - 2023-04-26 10:31:25 --> URI Class Initialized
INFO - 2023-04-26 10:31:25 --> Router Class Initialized
INFO - 2023-04-26 10:31:25 --> Output Class Initialized
INFO - 2023-04-26 10:31:25 --> Security Class Initialized
DEBUG - 2023-04-26 10:31:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-26 10:31:25 --> Input Class Initialized
INFO - 2023-04-26 10:31:25 --> Language Class Initialized
INFO - 2023-04-26 10:31:25 --> Loader Class Initialized
INFO - 2023-04-26 10:31:25 --> Helper loaded: url_helper
INFO - 2023-04-26 10:31:25 --> Helper loaded: file_helper
INFO - 2023-04-26 10:31:25 --> Helper loaded: html_helper
INFO - 2023-04-26 10:31:25 --> Helper loaded: text_helper
INFO - 2023-04-26 10:31:25 --> Helper loaded: form_helper
INFO - 2023-04-26 10:31:25 --> Helper loaded: lang_helper
INFO - 2023-04-26 10:31:25 --> Helper loaded: security_helper
INFO - 2023-04-26 10:31:25 --> Helper loaded: cookie_helper
INFO - 2023-04-26 10:31:25 --> Database Driver Class Initialized
INFO - 2023-04-26 10:31:25 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-26 10:31:25 --> Parser Class Initialized
INFO - 2023-04-26 10:31:25 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-26 10:31:25 --> Pagination Class Initialized
INFO - 2023-04-26 10:31:25 --> Form Validation Class Initialized
INFO - 2023-04-26 10:31:25 --> Controller Class Initialized
INFO - 2023-04-26 10:31:25 --> Model Class Initialized
DEBUG - 2023-04-26 10:31:25 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-04-26 10:31:25 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-26 10:31:25 --> Model Class Initialized
DEBUG - 2023-04-26 10:31:25 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-26 10:31:25 --> Model Class Initialized
INFO - 2023-04-26 10:31:25 --> Model Class Initialized
INFO - 2023-04-26 10:31:25 --> Final output sent to browser
DEBUG - 2023-04-26 10:31:25 --> Total execution time: 0.0197
ERROR - 2023-04-26 10:31:29 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-26 10:31:29 --> Config Class Initialized
INFO - 2023-04-26 10:31:29 --> Hooks Class Initialized
DEBUG - 2023-04-26 10:31:29 --> UTF-8 Support Enabled
INFO - 2023-04-26 10:31:29 --> Utf8 Class Initialized
INFO - 2023-04-26 10:31:29 --> URI Class Initialized
INFO - 2023-04-26 10:31:29 --> Router Class Initialized
INFO - 2023-04-26 10:31:29 --> Output Class Initialized
INFO - 2023-04-26 10:31:29 --> Security Class Initialized
DEBUG - 2023-04-26 10:31:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-26 10:31:29 --> Input Class Initialized
INFO - 2023-04-26 10:31:29 --> Language Class Initialized
INFO - 2023-04-26 10:31:29 --> Loader Class Initialized
INFO - 2023-04-26 10:31:29 --> Helper loaded: url_helper
INFO - 2023-04-26 10:31:29 --> Helper loaded: file_helper
INFO - 2023-04-26 10:31:29 --> Helper loaded: html_helper
INFO - 2023-04-26 10:31:29 --> Helper loaded: text_helper
INFO - 2023-04-26 10:31:29 --> Helper loaded: form_helper
INFO - 2023-04-26 10:31:29 --> Helper loaded: lang_helper
INFO - 2023-04-26 10:31:29 --> Helper loaded: security_helper
INFO - 2023-04-26 10:31:29 --> Helper loaded: cookie_helper
INFO - 2023-04-26 10:31:29 --> Database Driver Class Initialized
INFO - 2023-04-26 10:31:29 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-26 10:31:29 --> Parser Class Initialized
INFO - 2023-04-26 10:31:29 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-26 10:31:29 --> Pagination Class Initialized
INFO - 2023-04-26 10:31:29 --> Form Validation Class Initialized
INFO - 2023-04-26 10:31:29 --> Controller Class Initialized
INFO - 2023-04-26 10:31:29 --> Model Class Initialized
DEBUG - 2023-04-26 10:31:29 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-04-26 10:31:29 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-26 10:31:29 --> Model Class Initialized
DEBUG - 2023-04-26 10:31:29 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-26 10:31:29 --> Model Class Initialized
INFO - 2023-04-26 10:31:29 --> Final output sent to browser
DEBUG - 2023-04-26 10:31:29 --> Total execution time: 0.0185
ERROR - 2023-04-26 10:31:47 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-26 10:31:47 --> Config Class Initialized
INFO - 2023-04-26 10:31:47 --> Hooks Class Initialized
DEBUG - 2023-04-26 10:31:47 --> UTF-8 Support Enabled
INFO - 2023-04-26 10:31:47 --> Utf8 Class Initialized
INFO - 2023-04-26 10:31:47 --> URI Class Initialized
INFO - 2023-04-26 10:31:47 --> Router Class Initialized
INFO - 2023-04-26 10:31:47 --> Output Class Initialized
INFO - 2023-04-26 10:31:47 --> Security Class Initialized
DEBUG - 2023-04-26 10:31:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-26 10:31:47 --> Input Class Initialized
INFO - 2023-04-26 10:31:47 --> Language Class Initialized
INFO - 2023-04-26 10:31:47 --> Loader Class Initialized
INFO - 2023-04-26 10:31:47 --> Helper loaded: url_helper
INFO - 2023-04-26 10:31:47 --> Helper loaded: file_helper
INFO - 2023-04-26 10:31:47 --> Helper loaded: html_helper
INFO - 2023-04-26 10:31:47 --> Helper loaded: text_helper
INFO - 2023-04-26 10:31:47 --> Helper loaded: form_helper
INFO - 2023-04-26 10:31:47 --> Helper loaded: lang_helper
INFO - 2023-04-26 10:31:47 --> Helper loaded: security_helper
INFO - 2023-04-26 10:31:47 --> Helper loaded: cookie_helper
INFO - 2023-04-26 10:31:47 --> Database Driver Class Initialized
INFO - 2023-04-26 10:31:47 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-26 10:31:47 --> Parser Class Initialized
INFO - 2023-04-26 10:31:47 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-26 10:31:47 --> Pagination Class Initialized
INFO - 2023-04-26 10:31:47 --> Form Validation Class Initialized
INFO - 2023-04-26 10:31:47 --> Controller Class Initialized
INFO - 2023-04-26 10:31:47 --> Model Class Initialized
DEBUG - 2023-04-26 10:31:47 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-04-26 10:31:47 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-26 10:31:47 --> Model Class Initialized
DEBUG - 2023-04-26 10:31:47 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-26 10:31:47 --> Model Class Initialized
INFO - 2023-04-26 10:31:47 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice.php
DEBUG - 2023-04-26 10:31:47 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-04-26 10:31:47 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-04-26 10:31:47 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-04-26 10:31:47 --> Model Class Initialized
INFO - 2023-04-26 10:31:47 --> Model Class Initialized
INFO - 2023-04-26 10:31:47 --> Model Class Initialized
INFO - 2023-04-26 10:31:47 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-04-26 10:31:47 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-04-26 10:31:47 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-04-26 10:31:47 --> Final output sent to browser
DEBUG - 2023-04-26 10:31:47 --> Total execution time: 0.1641
ERROR - 2023-04-26 10:31:48 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-26 10:31:48 --> Config Class Initialized
INFO - 2023-04-26 10:31:48 --> Hooks Class Initialized
DEBUG - 2023-04-26 10:31:48 --> UTF-8 Support Enabled
INFO - 2023-04-26 10:31:48 --> Utf8 Class Initialized
INFO - 2023-04-26 10:31:48 --> URI Class Initialized
INFO - 2023-04-26 10:31:48 --> Router Class Initialized
INFO - 2023-04-26 10:31:48 --> Output Class Initialized
INFO - 2023-04-26 10:31:48 --> Security Class Initialized
DEBUG - 2023-04-26 10:31:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-26 10:31:48 --> Input Class Initialized
INFO - 2023-04-26 10:31:48 --> Language Class Initialized
INFO - 2023-04-26 10:31:48 --> Loader Class Initialized
INFO - 2023-04-26 10:31:48 --> Helper loaded: url_helper
INFO - 2023-04-26 10:31:48 --> Helper loaded: file_helper
INFO - 2023-04-26 10:31:48 --> Helper loaded: html_helper
INFO - 2023-04-26 10:31:48 --> Helper loaded: text_helper
INFO - 2023-04-26 10:31:48 --> Helper loaded: form_helper
INFO - 2023-04-26 10:31:48 --> Helper loaded: lang_helper
INFO - 2023-04-26 10:31:48 --> Helper loaded: security_helper
INFO - 2023-04-26 10:31:48 --> Helper loaded: cookie_helper
INFO - 2023-04-26 10:31:48 --> Database Driver Class Initialized
INFO - 2023-04-26 10:31:48 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-26 10:31:48 --> Parser Class Initialized
INFO - 2023-04-26 10:31:48 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-26 10:31:48 --> Pagination Class Initialized
INFO - 2023-04-26 10:31:48 --> Form Validation Class Initialized
INFO - 2023-04-26 10:31:48 --> Controller Class Initialized
INFO - 2023-04-26 10:31:48 --> Model Class Initialized
DEBUG - 2023-04-26 10:31:48 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-04-26 10:31:48 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-26 10:31:48 --> Model Class Initialized
DEBUG - 2023-04-26 10:31:48 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-26 10:31:48 --> Model Class Initialized
INFO - 2023-04-26 10:31:48 --> Final output sent to browser
DEBUG - 2023-04-26 10:31:48 --> Total execution time: 0.0542
ERROR - 2023-04-26 11:19:48 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-26 11:19:48 --> Config Class Initialized
INFO - 2023-04-26 11:19:48 --> Hooks Class Initialized
DEBUG - 2023-04-26 11:19:48 --> UTF-8 Support Enabled
INFO - 2023-04-26 11:19:48 --> Utf8 Class Initialized
INFO - 2023-04-26 11:19:48 --> URI Class Initialized
DEBUG - 2023-04-26 11:19:48 --> No URI present. Default controller set.
INFO - 2023-04-26 11:19:48 --> Router Class Initialized
INFO - 2023-04-26 11:19:48 --> Output Class Initialized
INFO - 2023-04-26 11:19:48 --> Security Class Initialized
DEBUG - 2023-04-26 11:19:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-26 11:19:48 --> Input Class Initialized
INFO - 2023-04-26 11:19:48 --> Language Class Initialized
INFO - 2023-04-26 11:19:48 --> Loader Class Initialized
INFO - 2023-04-26 11:19:48 --> Helper loaded: url_helper
INFO - 2023-04-26 11:19:48 --> Helper loaded: file_helper
INFO - 2023-04-26 11:19:48 --> Helper loaded: html_helper
INFO - 2023-04-26 11:19:48 --> Helper loaded: text_helper
INFO - 2023-04-26 11:19:48 --> Helper loaded: form_helper
INFO - 2023-04-26 11:19:48 --> Helper loaded: lang_helper
INFO - 2023-04-26 11:19:48 --> Helper loaded: security_helper
INFO - 2023-04-26 11:19:48 --> Helper loaded: cookie_helper
INFO - 2023-04-26 11:19:48 --> Database Driver Class Initialized
INFO - 2023-04-26 11:19:48 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-26 11:19:48 --> Parser Class Initialized
INFO - 2023-04-26 11:19:48 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-26 11:19:48 --> Pagination Class Initialized
INFO - 2023-04-26 11:19:48 --> Form Validation Class Initialized
INFO - 2023-04-26 11:19:48 --> Controller Class Initialized
INFO - 2023-04-26 11:19:48 --> Model Class Initialized
DEBUG - 2023-04-26 11:19:48 --> Session class already loaded. Second attempt ignored.
ERROR - 2023-04-26 11:19:48 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-26 11:19:48 --> Config Class Initialized
INFO - 2023-04-26 11:19:48 --> Hooks Class Initialized
DEBUG - 2023-04-26 11:19:48 --> UTF-8 Support Enabled
INFO - 2023-04-26 11:19:48 --> Utf8 Class Initialized
INFO - 2023-04-26 11:19:48 --> URI Class Initialized
INFO - 2023-04-26 11:19:48 --> Router Class Initialized
INFO - 2023-04-26 11:19:48 --> Output Class Initialized
INFO - 2023-04-26 11:19:48 --> Security Class Initialized
DEBUG - 2023-04-26 11:19:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-26 11:19:48 --> Input Class Initialized
INFO - 2023-04-26 11:19:48 --> Language Class Initialized
INFO - 2023-04-26 11:19:48 --> Loader Class Initialized
INFO - 2023-04-26 11:19:48 --> Helper loaded: url_helper
INFO - 2023-04-26 11:19:48 --> Helper loaded: file_helper
INFO - 2023-04-26 11:19:48 --> Helper loaded: html_helper
INFO - 2023-04-26 11:19:48 --> Helper loaded: text_helper
INFO - 2023-04-26 11:19:48 --> Helper loaded: form_helper
INFO - 2023-04-26 11:19:48 --> Helper loaded: lang_helper
INFO - 2023-04-26 11:19:48 --> Helper loaded: security_helper
INFO - 2023-04-26 11:19:48 --> Helper loaded: cookie_helper
INFO - 2023-04-26 11:19:48 --> Database Driver Class Initialized
INFO - 2023-04-26 11:19:48 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-26 11:19:48 --> Parser Class Initialized
INFO - 2023-04-26 11:19:48 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-26 11:19:48 --> Pagination Class Initialized
INFO - 2023-04-26 11:19:48 --> Form Validation Class Initialized
INFO - 2023-04-26 11:19:48 --> Controller Class Initialized
INFO - 2023-04-26 11:19:48 --> Model Class Initialized
DEBUG - 2023-04-26 11:19:48 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-26 11:19:48 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2023-04-26 11:19:48 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-04-26 11:19:48 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-04-26 11:19:48 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-04-26 11:19:48 --> Model Class Initialized
INFO - 2023-04-26 11:19:48 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-04-26 11:19:48 --> Final output sent to browser
DEBUG - 2023-04-26 11:19:48 --> Total execution time: 0.0350
ERROR - 2023-04-26 12:13:53 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-26 12:13:53 --> Config Class Initialized
INFO - 2023-04-26 12:13:53 --> Hooks Class Initialized
DEBUG - 2023-04-26 12:13:53 --> UTF-8 Support Enabled
INFO - 2023-04-26 12:13:53 --> Utf8 Class Initialized
INFO - 2023-04-26 12:13:53 --> URI Class Initialized
DEBUG - 2023-04-26 12:13:53 --> No URI present. Default controller set.
INFO - 2023-04-26 12:13:53 --> Router Class Initialized
INFO - 2023-04-26 12:13:53 --> Output Class Initialized
INFO - 2023-04-26 12:13:53 --> Security Class Initialized
DEBUG - 2023-04-26 12:13:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-26 12:13:53 --> Input Class Initialized
INFO - 2023-04-26 12:13:53 --> Language Class Initialized
INFO - 2023-04-26 12:13:53 --> Loader Class Initialized
INFO - 2023-04-26 12:13:53 --> Helper loaded: url_helper
INFO - 2023-04-26 12:13:53 --> Helper loaded: file_helper
INFO - 2023-04-26 12:13:53 --> Helper loaded: html_helper
INFO - 2023-04-26 12:13:53 --> Helper loaded: text_helper
INFO - 2023-04-26 12:13:53 --> Helper loaded: form_helper
INFO - 2023-04-26 12:13:53 --> Helper loaded: lang_helper
INFO - 2023-04-26 12:13:53 --> Helper loaded: security_helper
INFO - 2023-04-26 12:13:53 --> Helper loaded: cookie_helper
INFO - 2023-04-26 12:13:53 --> Database Driver Class Initialized
INFO - 2023-04-26 12:13:53 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-26 12:13:53 --> Parser Class Initialized
INFO - 2023-04-26 12:13:53 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-26 12:13:53 --> Pagination Class Initialized
INFO - 2023-04-26 12:13:53 --> Form Validation Class Initialized
INFO - 2023-04-26 12:13:53 --> Controller Class Initialized
INFO - 2023-04-26 12:13:53 --> Model Class Initialized
DEBUG - 2023-04-26 12:13:53 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-26 12:13:53 --> Model Class Initialized
DEBUG - 2023-04-26 12:13:53 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-26 12:13:53 --> Model Class Initialized
INFO - 2023-04-26 12:13:53 --> Model Class Initialized
INFO - 2023-04-26 12:13:53 --> Model Class Initialized
INFO - 2023-04-26 12:13:53 --> Model Class Initialized
DEBUG - 2023-04-26 12:13:53 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-04-26 12:13:53 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-26 12:13:53 --> Model Class Initialized
INFO - 2023-04-26 12:13:53 --> Model Class Initialized
INFO - 2023-04-26 12:13:53 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-04-26 12:13:53 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-04-26 12:13:53 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-04-26 12:13:53 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-04-26 12:13:53 --> Model Class Initialized
INFO - 2023-04-26 12:13:53 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-04-26 12:13:53 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-04-26 12:13:53 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-04-26 12:13:53 --> Final output sent to browser
DEBUG - 2023-04-26 12:13:53 --> Total execution time: 0.2250
ERROR - 2023-04-26 12:14:04 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-26 12:14:04 --> Config Class Initialized
INFO - 2023-04-26 12:14:04 --> Hooks Class Initialized
DEBUG - 2023-04-26 12:14:04 --> UTF-8 Support Enabled
INFO - 2023-04-26 12:14:04 --> Utf8 Class Initialized
INFO - 2023-04-26 12:14:04 --> URI Class Initialized
INFO - 2023-04-26 12:14:04 --> Router Class Initialized
INFO - 2023-04-26 12:14:04 --> Output Class Initialized
INFO - 2023-04-26 12:14:04 --> Security Class Initialized
DEBUG - 2023-04-26 12:14:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-26 12:14:04 --> Input Class Initialized
INFO - 2023-04-26 12:14:04 --> Language Class Initialized
INFO - 2023-04-26 12:14:04 --> Loader Class Initialized
INFO - 2023-04-26 12:14:04 --> Helper loaded: url_helper
INFO - 2023-04-26 12:14:04 --> Helper loaded: file_helper
INFO - 2023-04-26 12:14:04 --> Helper loaded: html_helper
INFO - 2023-04-26 12:14:04 --> Helper loaded: text_helper
INFO - 2023-04-26 12:14:04 --> Helper loaded: form_helper
INFO - 2023-04-26 12:14:04 --> Helper loaded: lang_helper
INFO - 2023-04-26 12:14:04 --> Helper loaded: security_helper
INFO - 2023-04-26 12:14:04 --> Helper loaded: cookie_helper
INFO - 2023-04-26 12:14:04 --> Database Driver Class Initialized
INFO - 2023-04-26 12:14:04 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-26 12:14:04 --> Parser Class Initialized
INFO - 2023-04-26 12:14:04 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-26 12:14:04 --> Pagination Class Initialized
INFO - 2023-04-26 12:14:04 --> Form Validation Class Initialized
INFO - 2023-04-26 12:14:04 --> Controller Class Initialized
INFO - 2023-04-26 12:14:04 --> Model Class Initialized
DEBUG - 2023-04-26 12:14:04 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-04-26 12:14:04 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-26 12:14:04 --> Model Class Initialized
DEBUG - 2023-04-26 12:14:04 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-26 12:14:04 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/stockrequest/add_stockrequest_form.php
DEBUG - 2023-04-26 12:14:04 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-04-26 12:14:04 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-04-26 12:14:04 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-04-26 12:14:04 --> Model Class Initialized
INFO - 2023-04-26 12:14:04 --> Model Class Initialized
INFO - 2023-04-26 12:14:04 --> Model Class Initialized
INFO - 2023-04-26 12:14:05 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-04-26 12:14:05 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-04-26 12:14:05 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-04-26 12:14:05 --> Final output sent to browser
DEBUG - 2023-04-26 12:14:05 --> Total execution time: 0.1633
ERROR - 2023-04-26 12:14:09 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-26 12:14:09 --> Config Class Initialized
INFO - 2023-04-26 12:14:09 --> Hooks Class Initialized
DEBUG - 2023-04-26 12:14:09 --> UTF-8 Support Enabled
INFO - 2023-04-26 12:14:09 --> Utf8 Class Initialized
INFO - 2023-04-26 12:14:09 --> URI Class Initialized
INFO - 2023-04-26 12:14:09 --> Router Class Initialized
INFO - 2023-04-26 12:14:09 --> Output Class Initialized
INFO - 2023-04-26 12:14:09 --> Security Class Initialized
DEBUG - 2023-04-26 12:14:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-26 12:14:09 --> Input Class Initialized
INFO - 2023-04-26 12:14:09 --> Language Class Initialized
INFO - 2023-04-26 12:14:09 --> Loader Class Initialized
INFO - 2023-04-26 12:14:09 --> Helper loaded: url_helper
INFO - 2023-04-26 12:14:09 --> Helper loaded: file_helper
INFO - 2023-04-26 12:14:09 --> Helper loaded: html_helper
INFO - 2023-04-26 12:14:09 --> Helper loaded: text_helper
INFO - 2023-04-26 12:14:09 --> Helper loaded: form_helper
INFO - 2023-04-26 12:14:09 --> Helper loaded: lang_helper
INFO - 2023-04-26 12:14:09 --> Helper loaded: security_helper
INFO - 2023-04-26 12:14:09 --> Helper loaded: cookie_helper
INFO - 2023-04-26 12:14:09 --> Database Driver Class Initialized
INFO - 2023-04-26 12:14:09 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-26 12:14:09 --> Parser Class Initialized
INFO - 2023-04-26 12:14:09 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-26 12:14:09 --> Pagination Class Initialized
INFO - 2023-04-26 12:14:09 --> Form Validation Class Initialized
INFO - 2023-04-26 12:14:09 --> Controller Class Initialized
INFO - 2023-04-26 12:14:09 --> Model Class Initialized
INFO - 2023-04-26 12:14:09 --> Final output sent to browser
DEBUG - 2023-04-26 12:14:09 --> Total execution time: 0.0141
ERROR - 2023-04-26 12:14:13 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-26 12:14:13 --> Config Class Initialized
INFO - 2023-04-26 12:14:13 --> Hooks Class Initialized
DEBUG - 2023-04-26 12:14:13 --> UTF-8 Support Enabled
INFO - 2023-04-26 12:14:13 --> Utf8 Class Initialized
INFO - 2023-04-26 12:14:13 --> URI Class Initialized
INFO - 2023-04-26 12:14:13 --> Router Class Initialized
INFO - 2023-04-26 12:14:13 --> Output Class Initialized
INFO - 2023-04-26 12:14:13 --> Security Class Initialized
DEBUG - 2023-04-26 12:14:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-26 12:14:13 --> Input Class Initialized
INFO - 2023-04-26 12:14:13 --> Language Class Initialized
INFO - 2023-04-26 12:14:13 --> Loader Class Initialized
INFO - 2023-04-26 12:14:13 --> Helper loaded: url_helper
INFO - 2023-04-26 12:14:13 --> Helper loaded: file_helper
INFO - 2023-04-26 12:14:13 --> Helper loaded: html_helper
INFO - 2023-04-26 12:14:13 --> Helper loaded: text_helper
INFO - 2023-04-26 12:14:13 --> Helper loaded: form_helper
INFO - 2023-04-26 12:14:13 --> Helper loaded: lang_helper
INFO - 2023-04-26 12:14:13 --> Helper loaded: security_helper
INFO - 2023-04-26 12:14:13 --> Helper loaded: cookie_helper
INFO - 2023-04-26 12:14:13 --> Database Driver Class Initialized
INFO - 2023-04-26 12:14:13 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-26 12:14:13 --> Parser Class Initialized
INFO - 2023-04-26 12:14:13 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-26 12:14:13 --> Pagination Class Initialized
INFO - 2023-04-26 12:14:13 --> Form Validation Class Initialized
INFO - 2023-04-26 12:14:13 --> Controller Class Initialized
INFO - 2023-04-26 12:14:13 --> Model Class Initialized
DEBUG - 2023-04-26 12:14:13 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-04-26 12:14:13 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-26 12:14:13 --> Model Class Initialized
DEBUG - 2023-04-26 12:14:13 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-26 12:14:13 --> Model Class Initialized
INFO - 2023-04-26 12:14:13 --> Final output sent to browser
DEBUG - 2023-04-26 12:14:13 --> Total execution time: 0.0180
ERROR - 2023-04-26 12:14:13 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-26 12:14:13 --> Config Class Initialized
INFO - 2023-04-26 12:14:13 --> Hooks Class Initialized
DEBUG - 2023-04-26 12:14:13 --> UTF-8 Support Enabled
INFO - 2023-04-26 12:14:13 --> Utf8 Class Initialized
INFO - 2023-04-26 12:14:13 --> URI Class Initialized
INFO - 2023-04-26 12:14:13 --> Router Class Initialized
INFO - 2023-04-26 12:14:13 --> Output Class Initialized
INFO - 2023-04-26 12:14:13 --> Security Class Initialized
DEBUG - 2023-04-26 12:14:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-26 12:14:13 --> Input Class Initialized
INFO - 2023-04-26 12:14:13 --> Language Class Initialized
INFO - 2023-04-26 12:14:13 --> Loader Class Initialized
INFO - 2023-04-26 12:14:13 --> Helper loaded: url_helper
INFO - 2023-04-26 12:14:13 --> Helper loaded: file_helper
INFO - 2023-04-26 12:14:13 --> Helper loaded: html_helper
INFO - 2023-04-26 12:14:13 --> Helper loaded: text_helper
INFO - 2023-04-26 12:14:13 --> Helper loaded: form_helper
INFO - 2023-04-26 12:14:13 --> Helper loaded: lang_helper
INFO - 2023-04-26 12:14:13 --> Helper loaded: security_helper
INFO - 2023-04-26 12:14:13 --> Helper loaded: cookie_helper
INFO - 2023-04-26 12:14:13 --> Database Driver Class Initialized
INFO - 2023-04-26 12:14:13 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-26 12:14:13 --> Parser Class Initialized
INFO - 2023-04-26 12:14:13 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-26 12:14:13 --> Pagination Class Initialized
INFO - 2023-04-26 12:14:13 --> Form Validation Class Initialized
INFO - 2023-04-26 12:14:13 --> Controller Class Initialized
INFO - 2023-04-26 12:14:13 --> Model Class Initialized
DEBUG - 2023-04-26 12:14:13 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-04-26 12:14:13 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-26 12:14:13 --> Model Class Initialized
DEBUG - 2023-04-26 12:14:13 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-26 12:14:13 --> Model Class Initialized
INFO - 2023-04-26 12:14:13 --> Final output sent to browser
DEBUG - 2023-04-26 12:14:13 --> Total execution time: 0.0169
ERROR - 2023-04-26 12:14:14 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-26 12:14:14 --> Config Class Initialized
INFO - 2023-04-26 12:14:14 --> Hooks Class Initialized
DEBUG - 2023-04-26 12:14:14 --> UTF-8 Support Enabled
INFO - 2023-04-26 12:14:14 --> Utf8 Class Initialized
INFO - 2023-04-26 12:14:14 --> URI Class Initialized
INFO - 2023-04-26 12:14:14 --> Router Class Initialized
INFO - 2023-04-26 12:14:14 --> Output Class Initialized
INFO - 2023-04-26 12:14:14 --> Security Class Initialized
DEBUG - 2023-04-26 12:14:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-26 12:14:14 --> Input Class Initialized
INFO - 2023-04-26 12:14:14 --> Language Class Initialized
INFO - 2023-04-26 12:14:14 --> Loader Class Initialized
INFO - 2023-04-26 12:14:14 --> Helper loaded: url_helper
INFO - 2023-04-26 12:14:14 --> Helper loaded: file_helper
INFO - 2023-04-26 12:14:14 --> Helper loaded: html_helper
INFO - 2023-04-26 12:14:14 --> Helper loaded: text_helper
INFO - 2023-04-26 12:14:14 --> Helper loaded: form_helper
INFO - 2023-04-26 12:14:14 --> Helper loaded: lang_helper
INFO - 2023-04-26 12:14:14 --> Helper loaded: security_helper
INFO - 2023-04-26 12:14:14 --> Helper loaded: cookie_helper
INFO - 2023-04-26 12:14:14 --> Database Driver Class Initialized
INFO - 2023-04-26 12:14:14 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-26 12:14:14 --> Parser Class Initialized
INFO - 2023-04-26 12:14:14 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-26 12:14:14 --> Pagination Class Initialized
INFO - 2023-04-26 12:14:14 --> Form Validation Class Initialized
INFO - 2023-04-26 12:14:14 --> Controller Class Initialized
INFO - 2023-04-26 12:14:14 --> Model Class Initialized
DEBUG - 2023-04-26 12:14:14 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-04-26 12:14:14 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-26 12:14:14 --> Model Class Initialized
DEBUG - 2023-04-26 12:14:14 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-26 12:14:14 --> Model Class Initialized
INFO - 2023-04-26 12:14:14 --> Final output sent to browser
DEBUG - 2023-04-26 12:14:14 --> Total execution time: 0.0177
ERROR - 2023-04-26 12:14:14 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-26 12:14:14 --> Config Class Initialized
INFO - 2023-04-26 12:14:14 --> Hooks Class Initialized
DEBUG - 2023-04-26 12:14:14 --> UTF-8 Support Enabled
INFO - 2023-04-26 12:14:14 --> Utf8 Class Initialized
INFO - 2023-04-26 12:14:14 --> URI Class Initialized
INFO - 2023-04-26 12:14:14 --> Router Class Initialized
INFO - 2023-04-26 12:14:14 --> Output Class Initialized
INFO - 2023-04-26 12:14:14 --> Security Class Initialized
DEBUG - 2023-04-26 12:14:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-26 12:14:14 --> Input Class Initialized
INFO - 2023-04-26 12:14:14 --> Language Class Initialized
INFO - 2023-04-26 12:14:14 --> Loader Class Initialized
INFO - 2023-04-26 12:14:14 --> Helper loaded: url_helper
INFO - 2023-04-26 12:14:14 --> Helper loaded: file_helper
INFO - 2023-04-26 12:14:14 --> Helper loaded: html_helper
INFO - 2023-04-26 12:14:14 --> Helper loaded: text_helper
INFO - 2023-04-26 12:14:14 --> Helper loaded: form_helper
INFO - 2023-04-26 12:14:14 --> Helper loaded: lang_helper
INFO - 2023-04-26 12:14:14 --> Helper loaded: security_helper
INFO - 2023-04-26 12:14:14 --> Helper loaded: cookie_helper
INFO - 2023-04-26 12:14:14 --> Database Driver Class Initialized
INFO - 2023-04-26 12:14:14 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-26 12:14:14 --> Parser Class Initialized
INFO - 2023-04-26 12:14:14 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-26 12:14:14 --> Pagination Class Initialized
INFO - 2023-04-26 12:14:14 --> Form Validation Class Initialized
INFO - 2023-04-26 12:14:14 --> Controller Class Initialized
INFO - 2023-04-26 12:14:14 --> Model Class Initialized
DEBUG - 2023-04-26 12:14:14 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-04-26 12:14:14 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-26 12:14:14 --> Model Class Initialized
DEBUG - 2023-04-26 12:14:14 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-26 12:14:14 --> Model Class Initialized
INFO - 2023-04-26 12:14:14 --> Final output sent to browser
DEBUG - 2023-04-26 12:14:14 --> Total execution time: 0.0177
ERROR - 2023-04-26 12:14:15 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-26 12:14:15 --> Config Class Initialized
INFO - 2023-04-26 12:14:15 --> Hooks Class Initialized
DEBUG - 2023-04-26 12:14:15 --> UTF-8 Support Enabled
INFO - 2023-04-26 12:14:15 --> Utf8 Class Initialized
INFO - 2023-04-26 12:14:15 --> URI Class Initialized
INFO - 2023-04-26 12:14:15 --> Router Class Initialized
INFO - 2023-04-26 12:14:15 --> Output Class Initialized
INFO - 2023-04-26 12:14:15 --> Security Class Initialized
DEBUG - 2023-04-26 12:14:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-26 12:14:15 --> Input Class Initialized
INFO - 2023-04-26 12:14:15 --> Language Class Initialized
INFO - 2023-04-26 12:14:15 --> Loader Class Initialized
INFO - 2023-04-26 12:14:15 --> Helper loaded: url_helper
INFO - 2023-04-26 12:14:15 --> Helper loaded: file_helper
INFO - 2023-04-26 12:14:15 --> Helper loaded: html_helper
INFO - 2023-04-26 12:14:15 --> Helper loaded: text_helper
INFO - 2023-04-26 12:14:15 --> Helper loaded: form_helper
INFO - 2023-04-26 12:14:15 --> Helper loaded: lang_helper
INFO - 2023-04-26 12:14:15 --> Helper loaded: security_helper
INFO - 2023-04-26 12:14:15 --> Helper loaded: cookie_helper
INFO - 2023-04-26 12:14:15 --> Database Driver Class Initialized
INFO - 2023-04-26 12:14:15 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-26 12:14:15 --> Parser Class Initialized
INFO - 2023-04-26 12:14:15 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-26 12:14:15 --> Pagination Class Initialized
INFO - 2023-04-26 12:14:15 --> Form Validation Class Initialized
INFO - 2023-04-26 12:14:15 --> Controller Class Initialized
INFO - 2023-04-26 12:14:15 --> Model Class Initialized
DEBUG - 2023-04-26 12:14:15 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-04-26 12:14:15 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-26 12:14:15 --> Model Class Initialized
DEBUG - 2023-04-26 12:14:15 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-26 12:14:15 --> Model Class Initialized
INFO - 2023-04-26 12:14:15 --> Final output sent to browser
DEBUG - 2023-04-26 12:14:15 --> Total execution time: 0.0181
ERROR - 2023-04-26 12:14:17 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-26 12:14:17 --> Config Class Initialized
INFO - 2023-04-26 12:14:17 --> Hooks Class Initialized
DEBUG - 2023-04-26 12:14:17 --> UTF-8 Support Enabled
INFO - 2023-04-26 12:14:17 --> Utf8 Class Initialized
INFO - 2023-04-26 12:14:17 --> URI Class Initialized
INFO - 2023-04-26 12:14:17 --> Router Class Initialized
INFO - 2023-04-26 12:14:17 --> Output Class Initialized
INFO - 2023-04-26 12:14:17 --> Security Class Initialized
DEBUG - 2023-04-26 12:14:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-26 12:14:17 --> Input Class Initialized
INFO - 2023-04-26 12:14:17 --> Language Class Initialized
INFO - 2023-04-26 12:14:17 --> Loader Class Initialized
INFO - 2023-04-26 12:14:17 --> Helper loaded: url_helper
INFO - 2023-04-26 12:14:17 --> Helper loaded: file_helper
INFO - 2023-04-26 12:14:17 --> Helper loaded: html_helper
INFO - 2023-04-26 12:14:17 --> Helper loaded: text_helper
INFO - 2023-04-26 12:14:17 --> Helper loaded: form_helper
INFO - 2023-04-26 12:14:17 --> Helper loaded: lang_helper
INFO - 2023-04-26 12:14:17 --> Helper loaded: security_helper
INFO - 2023-04-26 12:14:17 --> Helper loaded: cookie_helper
INFO - 2023-04-26 12:14:17 --> Database Driver Class Initialized
INFO - 2023-04-26 12:14:17 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-26 12:14:17 --> Parser Class Initialized
INFO - 2023-04-26 12:14:17 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-26 12:14:17 --> Pagination Class Initialized
INFO - 2023-04-26 12:14:17 --> Form Validation Class Initialized
INFO - 2023-04-26 12:14:17 --> Controller Class Initialized
INFO - 2023-04-26 12:14:17 --> Model Class Initialized
DEBUG - 2023-04-26 12:14:17 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-04-26 12:14:17 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-26 12:14:17 --> Model Class Initialized
DEBUG - 2023-04-26 12:14:17 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-26 12:14:17 --> Model Class Initialized
INFO - 2023-04-26 12:14:17 --> Model Class Initialized
INFO - 2023-04-26 12:14:17 --> Final output sent to browser
DEBUG - 2023-04-26 12:14:17 --> Total execution time: 0.0239
ERROR - 2023-04-26 12:14:18 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-26 12:14:18 --> Config Class Initialized
INFO - 2023-04-26 12:14:18 --> Hooks Class Initialized
DEBUG - 2023-04-26 12:14:18 --> UTF-8 Support Enabled
INFO - 2023-04-26 12:14:18 --> Utf8 Class Initialized
INFO - 2023-04-26 12:14:18 --> URI Class Initialized
INFO - 2023-04-26 12:14:18 --> Router Class Initialized
INFO - 2023-04-26 12:14:18 --> Output Class Initialized
INFO - 2023-04-26 12:14:18 --> Security Class Initialized
DEBUG - 2023-04-26 12:14:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-26 12:14:18 --> Input Class Initialized
INFO - 2023-04-26 12:14:18 --> Language Class Initialized
INFO - 2023-04-26 12:14:18 --> Loader Class Initialized
INFO - 2023-04-26 12:14:18 --> Helper loaded: url_helper
INFO - 2023-04-26 12:14:18 --> Helper loaded: file_helper
INFO - 2023-04-26 12:14:18 --> Helper loaded: html_helper
INFO - 2023-04-26 12:14:18 --> Helper loaded: text_helper
INFO - 2023-04-26 12:14:18 --> Helper loaded: form_helper
INFO - 2023-04-26 12:14:18 --> Helper loaded: lang_helper
INFO - 2023-04-26 12:14:18 --> Helper loaded: security_helper
INFO - 2023-04-26 12:14:18 --> Helper loaded: cookie_helper
INFO - 2023-04-26 12:14:18 --> Database Driver Class Initialized
INFO - 2023-04-26 12:14:18 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-26 12:14:18 --> Parser Class Initialized
INFO - 2023-04-26 12:14:18 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-26 12:14:18 --> Pagination Class Initialized
INFO - 2023-04-26 12:14:18 --> Form Validation Class Initialized
INFO - 2023-04-26 12:14:18 --> Controller Class Initialized
INFO - 2023-04-26 12:14:18 --> Model Class Initialized
DEBUG - 2023-04-26 12:14:18 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-04-26 12:14:18 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-26 12:14:18 --> Model Class Initialized
DEBUG - 2023-04-26 12:14:18 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-26 12:14:18 --> Model Class Initialized
INFO - 2023-04-26 12:14:18 --> Final output sent to browser
DEBUG - 2023-04-26 12:14:18 --> Total execution time: 0.0189
ERROR - 2023-04-26 12:14:27 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-26 12:14:27 --> Config Class Initialized
INFO - 2023-04-26 12:14:27 --> Hooks Class Initialized
DEBUG - 2023-04-26 12:14:27 --> UTF-8 Support Enabled
INFO - 2023-04-26 12:14:27 --> Utf8 Class Initialized
INFO - 2023-04-26 12:14:27 --> URI Class Initialized
INFO - 2023-04-26 12:14:27 --> Router Class Initialized
INFO - 2023-04-26 12:14:27 --> Output Class Initialized
INFO - 2023-04-26 12:14:27 --> Security Class Initialized
DEBUG - 2023-04-26 12:14:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-26 12:14:27 --> Input Class Initialized
INFO - 2023-04-26 12:14:27 --> Language Class Initialized
INFO - 2023-04-26 12:14:27 --> Loader Class Initialized
INFO - 2023-04-26 12:14:27 --> Helper loaded: url_helper
INFO - 2023-04-26 12:14:27 --> Helper loaded: file_helper
INFO - 2023-04-26 12:14:27 --> Helper loaded: html_helper
INFO - 2023-04-26 12:14:27 --> Helper loaded: text_helper
INFO - 2023-04-26 12:14:27 --> Helper loaded: form_helper
INFO - 2023-04-26 12:14:27 --> Helper loaded: lang_helper
INFO - 2023-04-26 12:14:27 --> Helper loaded: security_helper
INFO - 2023-04-26 12:14:27 --> Helper loaded: cookie_helper
INFO - 2023-04-26 12:14:27 --> Database Driver Class Initialized
INFO - 2023-04-26 12:14:27 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-26 12:14:27 --> Parser Class Initialized
INFO - 2023-04-26 12:14:27 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-26 12:14:27 --> Pagination Class Initialized
INFO - 2023-04-26 12:14:27 --> Form Validation Class Initialized
INFO - 2023-04-26 12:14:27 --> Controller Class Initialized
INFO - 2023-04-26 12:14:27 --> Model Class Initialized
DEBUG - 2023-04-26 12:14:27 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-04-26 12:14:27 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-26 12:14:27 --> Model Class Initialized
INFO - 2023-04-26 12:14:27 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/stockrequest/inventory.php
DEBUG - 2023-04-26 12:14:27 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-04-26 12:14:27 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-04-26 12:14:27 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-04-26 12:14:27 --> Model Class Initialized
INFO - 2023-04-26 12:14:27 --> Model Class Initialized
INFO - 2023-04-26 12:14:27 --> Model Class Initialized
INFO - 2023-04-26 12:14:27 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-04-26 12:14:27 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-04-26 12:14:27 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-04-26 12:14:27 --> Final output sent to browser
DEBUG - 2023-04-26 12:14:27 --> Total execution time: 0.1428
ERROR - 2023-04-26 12:14:28 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-26 12:14:28 --> Config Class Initialized
INFO - 2023-04-26 12:14:28 --> Hooks Class Initialized
DEBUG - 2023-04-26 12:14:28 --> UTF-8 Support Enabled
INFO - 2023-04-26 12:14:28 --> Utf8 Class Initialized
INFO - 2023-04-26 12:14:28 --> URI Class Initialized
INFO - 2023-04-26 12:14:28 --> Router Class Initialized
INFO - 2023-04-26 12:14:28 --> Output Class Initialized
INFO - 2023-04-26 12:14:28 --> Security Class Initialized
DEBUG - 2023-04-26 12:14:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-26 12:14:28 --> Input Class Initialized
INFO - 2023-04-26 12:14:28 --> Language Class Initialized
INFO - 2023-04-26 12:14:28 --> Loader Class Initialized
INFO - 2023-04-26 12:14:28 --> Helper loaded: url_helper
INFO - 2023-04-26 12:14:28 --> Helper loaded: file_helper
INFO - 2023-04-26 12:14:28 --> Helper loaded: html_helper
INFO - 2023-04-26 12:14:28 --> Helper loaded: text_helper
INFO - 2023-04-26 12:14:28 --> Helper loaded: form_helper
INFO - 2023-04-26 12:14:28 --> Helper loaded: lang_helper
INFO - 2023-04-26 12:14:28 --> Helper loaded: security_helper
INFO - 2023-04-26 12:14:28 --> Helper loaded: cookie_helper
INFO - 2023-04-26 12:14:28 --> Database Driver Class Initialized
INFO - 2023-04-26 12:14:28 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-26 12:14:28 --> Parser Class Initialized
INFO - 2023-04-26 12:14:28 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-26 12:14:28 --> Pagination Class Initialized
INFO - 2023-04-26 12:14:28 --> Form Validation Class Initialized
INFO - 2023-04-26 12:14:28 --> Controller Class Initialized
INFO - 2023-04-26 12:14:28 --> Model Class Initialized
DEBUG - 2023-04-26 12:14:28 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-04-26 12:14:28 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-26 12:14:28 --> Model Class Initialized
INFO - 2023-04-26 12:14:28 --> Final output sent to browser
DEBUG - 2023-04-26 12:14:28 --> Total execution time: 0.0200
ERROR - 2023-04-26 12:14:35 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-26 12:14:35 --> Config Class Initialized
INFO - 2023-04-26 12:14:35 --> Hooks Class Initialized
DEBUG - 2023-04-26 12:14:35 --> UTF-8 Support Enabled
INFO - 2023-04-26 12:14:35 --> Utf8 Class Initialized
INFO - 2023-04-26 12:14:35 --> URI Class Initialized
INFO - 2023-04-26 12:14:35 --> Router Class Initialized
INFO - 2023-04-26 12:14:35 --> Output Class Initialized
INFO - 2023-04-26 12:14:35 --> Security Class Initialized
DEBUG - 2023-04-26 12:14:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-26 12:14:35 --> Input Class Initialized
INFO - 2023-04-26 12:14:35 --> Language Class Initialized
INFO - 2023-04-26 12:14:35 --> Loader Class Initialized
INFO - 2023-04-26 12:14:35 --> Helper loaded: url_helper
INFO - 2023-04-26 12:14:35 --> Helper loaded: file_helper
INFO - 2023-04-26 12:14:35 --> Helper loaded: html_helper
INFO - 2023-04-26 12:14:35 --> Helper loaded: text_helper
INFO - 2023-04-26 12:14:35 --> Helper loaded: form_helper
INFO - 2023-04-26 12:14:35 --> Helper loaded: lang_helper
INFO - 2023-04-26 12:14:35 --> Helper loaded: security_helper
INFO - 2023-04-26 12:14:35 --> Helper loaded: cookie_helper
INFO - 2023-04-26 12:14:35 --> Database Driver Class Initialized
INFO - 2023-04-26 12:14:35 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-26 12:14:35 --> Parser Class Initialized
INFO - 2023-04-26 12:14:35 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-26 12:14:35 --> Pagination Class Initialized
INFO - 2023-04-26 12:14:35 --> Form Validation Class Initialized
INFO - 2023-04-26 12:14:35 --> Controller Class Initialized
INFO - 2023-04-26 12:14:35 --> Model Class Initialized
DEBUG - 2023-04-26 12:14:35 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-04-26 12:14:35 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-26 12:14:35 --> Model Class Initialized
INFO - 2023-04-26 12:14:35 --> Final output sent to browser
DEBUG - 2023-04-26 12:14:35 --> Total execution time: 0.0203
ERROR - 2023-04-26 12:15:44 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-26 12:15:44 --> Config Class Initialized
INFO - 2023-04-26 12:15:44 --> Hooks Class Initialized
DEBUG - 2023-04-26 12:15:44 --> UTF-8 Support Enabled
INFO - 2023-04-26 12:15:44 --> Utf8 Class Initialized
INFO - 2023-04-26 12:15:44 --> URI Class Initialized
INFO - 2023-04-26 12:15:44 --> Router Class Initialized
INFO - 2023-04-26 12:15:44 --> Output Class Initialized
INFO - 2023-04-26 12:15:44 --> Security Class Initialized
DEBUG - 2023-04-26 12:15:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-26 12:15:44 --> Input Class Initialized
INFO - 2023-04-26 12:15:44 --> Language Class Initialized
INFO - 2023-04-26 12:15:44 --> Loader Class Initialized
INFO - 2023-04-26 12:15:44 --> Helper loaded: url_helper
INFO - 2023-04-26 12:15:44 --> Helper loaded: file_helper
INFO - 2023-04-26 12:15:44 --> Helper loaded: html_helper
INFO - 2023-04-26 12:15:44 --> Helper loaded: text_helper
INFO - 2023-04-26 12:15:44 --> Helper loaded: form_helper
INFO - 2023-04-26 12:15:44 --> Helper loaded: lang_helper
INFO - 2023-04-26 12:15:44 --> Helper loaded: security_helper
INFO - 2023-04-26 12:15:44 --> Helper loaded: cookie_helper
INFO - 2023-04-26 12:15:44 --> Database Driver Class Initialized
INFO - 2023-04-26 12:15:44 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-26 12:15:44 --> Parser Class Initialized
INFO - 2023-04-26 12:15:44 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-26 12:15:44 --> Pagination Class Initialized
INFO - 2023-04-26 12:15:44 --> Form Validation Class Initialized
INFO - 2023-04-26 12:15:44 --> Controller Class Initialized
INFO - 2023-04-26 12:15:44 --> Model Class Initialized
DEBUG - 2023-04-26 12:15:44 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-04-26 12:15:44 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-26 12:15:44 --> Model Class Initialized
DEBUG - 2023-04-26 12:15:44 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-26 12:15:44 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/stockrequest/add_stockrequest_form.php
DEBUG - 2023-04-26 12:15:44 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-04-26 12:15:44 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-04-26 12:15:44 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-04-26 12:15:44 --> Model Class Initialized
INFO - 2023-04-26 12:15:44 --> Model Class Initialized
INFO - 2023-04-26 12:15:44 --> Model Class Initialized
INFO - 2023-04-26 12:15:45 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-04-26 12:15:45 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-04-26 12:15:45 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-04-26 12:15:45 --> Final output sent to browser
DEBUG - 2023-04-26 12:15:45 --> Total execution time: 0.1560
ERROR - 2023-04-26 12:15:49 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-26 12:15:49 --> Config Class Initialized
INFO - 2023-04-26 12:15:49 --> Hooks Class Initialized
DEBUG - 2023-04-26 12:15:49 --> UTF-8 Support Enabled
INFO - 2023-04-26 12:15:49 --> Utf8 Class Initialized
INFO - 2023-04-26 12:15:49 --> URI Class Initialized
INFO - 2023-04-26 12:15:49 --> Router Class Initialized
INFO - 2023-04-26 12:15:49 --> Output Class Initialized
INFO - 2023-04-26 12:15:49 --> Security Class Initialized
DEBUG - 2023-04-26 12:15:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-26 12:15:49 --> Input Class Initialized
INFO - 2023-04-26 12:15:49 --> Language Class Initialized
INFO - 2023-04-26 12:15:49 --> Loader Class Initialized
INFO - 2023-04-26 12:15:49 --> Helper loaded: url_helper
INFO - 2023-04-26 12:15:49 --> Helper loaded: file_helper
INFO - 2023-04-26 12:15:49 --> Helper loaded: html_helper
INFO - 2023-04-26 12:15:49 --> Helper loaded: text_helper
INFO - 2023-04-26 12:15:49 --> Helper loaded: form_helper
INFO - 2023-04-26 12:15:49 --> Helper loaded: lang_helper
INFO - 2023-04-26 12:15:49 --> Helper loaded: security_helper
INFO - 2023-04-26 12:15:49 --> Helper loaded: cookie_helper
INFO - 2023-04-26 12:15:49 --> Database Driver Class Initialized
INFO - 2023-04-26 12:15:49 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-26 12:15:49 --> Parser Class Initialized
INFO - 2023-04-26 12:15:49 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-26 12:15:49 --> Pagination Class Initialized
INFO - 2023-04-26 12:15:49 --> Form Validation Class Initialized
INFO - 2023-04-26 12:15:49 --> Controller Class Initialized
INFO - 2023-04-26 12:15:49 --> Model Class Initialized
INFO - 2023-04-26 12:15:49 --> Final output sent to browser
DEBUG - 2023-04-26 12:15:49 --> Total execution time: 0.0169
ERROR - 2023-04-26 12:15:52 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-26 12:15:52 --> Config Class Initialized
INFO - 2023-04-26 12:15:52 --> Hooks Class Initialized
DEBUG - 2023-04-26 12:15:52 --> UTF-8 Support Enabled
INFO - 2023-04-26 12:15:52 --> Utf8 Class Initialized
INFO - 2023-04-26 12:15:52 --> URI Class Initialized
INFO - 2023-04-26 12:15:52 --> Router Class Initialized
INFO - 2023-04-26 12:15:52 --> Output Class Initialized
INFO - 2023-04-26 12:15:52 --> Security Class Initialized
DEBUG - 2023-04-26 12:15:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-26 12:15:52 --> Input Class Initialized
INFO - 2023-04-26 12:15:52 --> Language Class Initialized
INFO - 2023-04-26 12:15:52 --> Loader Class Initialized
INFO - 2023-04-26 12:15:52 --> Helper loaded: url_helper
INFO - 2023-04-26 12:15:52 --> Helper loaded: file_helper
INFO - 2023-04-26 12:15:52 --> Helper loaded: html_helper
INFO - 2023-04-26 12:15:52 --> Helper loaded: text_helper
INFO - 2023-04-26 12:15:52 --> Helper loaded: form_helper
INFO - 2023-04-26 12:15:52 --> Helper loaded: lang_helper
INFO - 2023-04-26 12:15:52 --> Helper loaded: security_helper
INFO - 2023-04-26 12:15:52 --> Helper loaded: cookie_helper
INFO - 2023-04-26 12:15:52 --> Database Driver Class Initialized
INFO - 2023-04-26 12:15:52 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-26 12:15:52 --> Parser Class Initialized
INFO - 2023-04-26 12:15:52 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-26 12:15:52 --> Pagination Class Initialized
INFO - 2023-04-26 12:15:52 --> Form Validation Class Initialized
INFO - 2023-04-26 12:15:52 --> Controller Class Initialized
INFO - 2023-04-26 12:15:52 --> Model Class Initialized
DEBUG - 2023-04-26 12:15:52 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-04-26 12:15:52 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-26 12:15:52 --> Model Class Initialized
DEBUG - 2023-04-26 12:15:52 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-26 12:15:52 --> Model Class Initialized
INFO - 2023-04-26 12:15:52 --> Final output sent to browser
DEBUG - 2023-04-26 12:15:52 --> Total execution time: 0.0212
ERROR - 2023-04-26 12:15:52 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-26 12:15:52 --> Config Class Initialized
INFO - 2023-04-26 12:15:52 --> Hooks Class Initialized
DEBUG - 2023-04-26 12:15:52 --> UTF-8 Support Enabled
INFO - 2023-04-26 12:15:52 --> Utf8 Class Initialized
INFO - 2023-04-26 12:15:52 --> URI Class Initialized
INFO - 2023-04-26 12:15:52 --> Router Class Initialized
INFO - 2023-04-26 12:15:52 --> Output Class Initialized
INFO - 2023-04-26 12:15:52 --> Security Class Initialized
DEBUG - 2023-04-26 12:15:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-26 12:15:52 --> Input Class Initialized
INFO - 2023-04-26 12:15:52 --> Language Class Initialized
INFO - 2023-04-26 12:15:52 --> Loader Class Initialized
INFO - 2023-04-26 12:15:52 --> Helper loaded: url_helper
INFO - 2023-04-26 12:15:52 --> Helper loaded: file_helper
INFO - 2023-04-26 12:15:52 --> Helper loaded: html_helper
INFO - 2023-04-26 12:15:52 --> Helper loaded: text_helper
INFO - 2023-04-26 12:15:52 --> Helper loaded: form_helper
INFO - 2023-04-26 12:15:52 --> Helper loaded: lang_helper
INFO - 2023-04-26 12:15:52 --> Helper loaded: security_helper
INFO - 2023-04-26 12:15:52 --> Helper loaded: cookie_helper
INFO - 2023-04-26 12:15:52 --> Database Driver Class Initialized
INFO - 2023-04-26 12:15:53 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-26 12:15:53 --> Parser Class Initialized
INFO - 2023-04-26 12:15:53 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-26 12:15:53 --> Pagination Class Initialized
INFO - 2023-04-26 12:15:53 --> Form Validation Class Initialized
INFO - 2023-04-26 12:15:53 --> Controller Class Initialized
INFO - 2023-04-26 12:15:53 --> Model Class Initialized
DEBUG - 2023-04-26 12:15:53 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-04-26 12:15:53 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-26 12:15:53 --> Model Class Initialized
DEBUG - 2023-04-26 12:15:53 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-26 12:15:53 --> Model Class Initialized
INFO - 2023-04-26 12:15:53 --> Final output sent to browser
DEBUG - 2023-04-26 12:15:53 --> Total execution time: 0.0168
ERROR - 2023-04-26 12:15:53 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-26 12:15:53 --> Config Class Initialized
INFO - 2023-04-26 12:15:53 --> Hooks Class Initialized
DEBUG - 2023-04-26 12:15:53 --> UTF-8 Support Enabled
INFO - 2023-04-26 12:15:53 --> Utf8 Class Initialized
INFO - 2023-04-26 12:15:53 --> URI Class Initialized
INFO - 2023-04-26 12:15:53 --> Router Class Initialized
INFO - 2023-04-26 12:15:53 --> Output Class Initialized
INFO - 2023-04-26 12:15:53 --> Security Class Initialized
DEBUG - 2023-04-26 12:15:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-26 12:15:53 --> Input Class Initialized
INFO - 2023-04-26 12:15:53 --> Language Class Initialized
INFO - 2023-04-26 12:15:53 --> Loader Class Initialized
INFO - 2023-04-26 12:15:53 --> Helper loaded: url_helper
INFO - 2023-04-26 12:15:53 --> Helper loaded: file_helper
INFO - 2023-04-26 12:15:53 --> Helper loaded: html_helper
INFO - 2023-04-26 12:15:53 --> Helper loaded: text_helper
INFO - 2023-04-26 12:15:53 --> Helper loaded: form_helper
INFO - 2023-04-26 12:15:53 --> Helper loaded: lang_helper
INFO - 2023-04-26 12:15:53 --> Helper loaded: security_helper
INFO - 2023-04-26 12:15:53 --> Helper loaded: cookie_helper
INFO - 2023-04-26 12:15:53 --> Database Driver Class Initialized
INFO - 2023-04-26 12:15:53 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-26 12:15:53 --> Parser Class Initialized
INFO - 2023-04-26 12:15:53 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-26 12:15:53 --> Pagination Class Initialized
INFO - 2023-04-26 12:15:53 --> Form Validation Class Initialized
INFO - 2023-04-26 12:15:53 --> Controller Class Initialized
INFO - 2023-04-26 12:15:53 --> Model Class Initialized
DEBUG - 2023-04-26 12:15:53 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-04-26 12:15:53 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-26 12:15:53 --> Model Class Initialized
DEBUG - 2023-04-26 12:15:53 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-26 12:15:53 --> Model Class Initialized
INFO - 2023-04-26 12:15:53 --> Final output sent to browser
DEBUG - 2023-04-26 12:15:53 --> Total execution time: 0.0175
ERROR - 2023-04-26 12:15:53 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-26 12:15:53 --> Config Class Initialized
INFO - 2023-04-26 12:15:53 --> Hooks Class Initialized
DEBUG - 2023-04-26 12:15:53 --> UTF-8 Support Enabled
INFO - 2023-04-26 12:15:53 --> Utf8 Class Initialized
INFO - 2023-04-26 12:15:53 --> URI Class Initialized
INFO - 2023-04-26 12:15:53 --> Router Class Initialized
INFO - 2023-04-26 12:15:53 --> Output Class Initialized
INFO - 2023-04-26 12:15:53 --> Security Class Initialized
DEBUG - 2023-04-26 12:15:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-26 12:15:53 --> Input Class Initialized
INFO - 2023-04-26 12:15:53 --> Language Class Initialized
INFO - 2023-04-26 12:15:53 --> Loader Class Initialized
INFO - 2023-04-26 12:15:53 --> Helper loaded: url_helper
INFO - 2023-04-26 12:15:53 --> Helper loaded: file_helper
INFO - 2023-04-26 12:15:53 --> Helper loaded: html_helper
INFO - 2023-04-26 12:15:53 --> Helper loaded: text_helper
INFO - 2023-04-26 12:15:53 --> Helper loaded: form_helper
INFO - 2023-04-26 12:15:53 --> Helper loaded: lang_helper
INFO - 2023-04-26 12:15:53 --> Helper loaded: security_helper
INFO - 2023-04-26 12:15:53 --> Helper loaded: cookie_helper
INFO - 2023-04-26 12:15:53 --> Database Driver Class Initialized
INFO - 2023-04-26 12:15:53 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-26 12:15:53 --> Parser Class Initialized
INFO - 2023-04-26 12:15:53 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-26 12:15:53 --> Pagination Class Initialized
INFO - 2023-04-26 12:15:53 --> Form Validation Class Initialized
INFO - 2023-04-26 12:15:53 --> Controller Class Initialized
INFO - 2023-04-26 12:15:53 --> Model Class Initialized
DEBUG - 2023-04-26 12:15:53 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-04-26 12:15:53 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-26 12:15:53 --> Model Class Initialized
DEBUG - 2023-04-26 12:15:53 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-26 12:15:53 --> Model Class Initialized
INFO - 2023-04-26 12:15:53 --> Final output sent to browser
DEBUG - 2023-04-26 12:15:53 --> Total execution time: 0.0181
ERROR - 2023-04-26 12:15:54 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-26 12:15:54 --> Config Class Initialized
INFO - 2023-04-26 12:15:54 --> Hooks Class Initialized
DEBUG - 2023-04-26 12:15:54 --> UTF-8 Support Enabled
INFO - 2023-04-26 12:15:54 --> Utf8 Class Initialized
INFO - 2023-04-26 12:15:54 --> URI Class Initialized
INFO - 2023-04-26 12:15:54 --> Router Class Initialized
INFO - 2023-04-26 12:15:54 --> Output Class Initialized
INFO - 2023-04-26 12:15:54 --> Security Class Initialized
DEBUG - 2023-04-26 12:15:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-26 12:15:54 --> Input Class Initialized
INFO - 2023-04-26 12:15:54 --> Language Class Initialized
INFO - 2023-04-26 12:15:54 --> Loader Class Initialized
INFO - 2023-04-26 12:15:54 --> Helper loaded: url_helper
INFO - 2023-04-26 12:15:54 --> Helper loaded: file_helper
INFO - 2023-04-26 12:15:54 --> Helper loaded: html_helper
INFO - 2023-04-26 12:15:54 --> Helper loaded: text_helper
INFO - 2023-04-26 12:15:54 --> Helper loaded: form_helper
INFO - 2023-04-26 12:15:54 --> Helper loaded: lang_helper
INFO - 2023-04-26 12:15:54 --> Helper loaded: security_helper
INFO - 2023-04-26 12:15:54 --> Helper loaded: cookie_helper
INFO - 2023-04-26 12:15:54 --> Database Driver Class Initialized
INFO - 2023-04-26 12:15:54 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-26 12:15:54 --> Parser Class Initialized
INFO - 2023-04-26 12:15:54 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-26 12:15:54 --> Pagination Class Initialized
INFO - 2023-04-26 12:15:54 --> Form Validation Class Initialized
INFO - 2023-04-26 12:15:54 --> Controller Class Initialized
INFO - 2023-04-26 12:15:54 --> Model Class Initialized
DEBUG - 2023-04-26 12:15:54 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-04-26 12:15:54 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-26 12:15:54 --> Model Class Initialized
DEBUG - 2023-04-26 12:15:54 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-26 12:15:54 --> Model Class Initialized
INFO - 2023-04-26 12:15:54 --> Final output sent to browser
DEBUG - 2023-04-26 12:15:54 --> Total execution time: 0.0201
ERROR - 2023-04-26 12:15:56 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-26 12:15:56 --> Config Class Initialized
INFO - 2023-04-26 12:15:56 --> Hooks Class Initialized
DEBUG - 2023-04-26 12:15:56 --> UTF-8 Support Enabled
INFO - 2023-04-26 12:15:56 --> Utf8 Class Initialized
INFO - 2023-04-26 12:15:56 --> URI Class Initialized
INFO - 2023-04-26 12:15:56 --> Router Class Initialized
INFO - 2023-04-26 12:15:56 --> Output Class Initialized
INFO - 2023-04-26 12:15:56 --> Security Class Initialized
DEBUG - 2023-04-26 12:15:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-26 12:15:56 --> Input Class Initialized
INFO - 2023-04-26 12:15:56 --> Language Class Initialized
INFO - 2023-04-26 12:15:56 --> Loader Class Initialized
INFO - 2023-04-26 12:15:56 --> Helper loaded: url_helper
INFO - 2023-04-26 12:15:56 --> Helper loaded: file_helper
INFO - 2023-04-26 12:15:56 --> Helper loaded: html_helper
INFO - 2023-04-26 12:15:56 --> Helper loaded: text_helper
INFO - 2023-04-26 12:15:56 --> Helper loaded: form_helper
INFO - 2023-04-26 12:15:56 --> Helper loaded: lang_helper
INFO - 2023-04-26 12:15:56 --> Helper loaded: security_helper
INFO - 2023-04-26 12:15:56 --> Helper loaded: cookie_helper
INFO - 2023-04-26 12:15:56 --> Database Driver Class Initialized
INFO - 2023-04-26 12:15:56 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-26 12:15:56 --> Parser Class Initialized
INFO - 2023-04-26 12:15:56 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-26 12:15:56 --> Pagination Class Initialized
INFO - 2023-04-26 12:15:56 --> Form Validation Class Initialized
INFO - 2023-04-26 12:15:56 --> Controller Class Initialized
INFO - 2023-04-26 12:15:56 --> Model Class Initialized
DEBUG - 2023-04-26 12:15:56 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-04-26 12:15:56 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-26 12:15:56 --> Model Class Initialized
DEBUG - 2023-04-26 12:15:56 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-26 12:15:56 --> Model Class Initialized
INFO - 2023-04-26 12:15:56 --> Final output sent to browser
DEBUG - 2023-04-26 12:15:56 --> Total execution time: 0.0172
ERROR - 2023-04-26 12:15:58 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-26 12:15:58 --> Config Class Initialized
INFO - 2023-04-26 12:15:58 --> Hooks Class Initialized
DEBUG - 2023-04-26 12:15:58 --> UTF-8 Support Enabled
INFO - 2023-04-26 12:15:58 --> Utf8 Class Initialized
INFO - 2023-04-26 12:15:58 --> URI Class Initialized
INFO - 2023-04-26 12:15:58 --> Router Class Initialized
INFO - 2023-04-26 12:15:58 --> Output Class Initialized
INFO - 2023-04-26 12:15:58 --> Security Class Initialized
DEBUG - 2023-04-26 12:15:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-26 12:15:58 --> Input Class Initialized
INFO - 2023-04-26 12:15:58 --> Language Class Initialized
INFO - 2023-04-26 12:15:58 --> Loader Class Initialized
INFO - 2023-04-26 12:15:58 --> Helper loaded: url_helper
INFO - 2023-04-26 12:15:58 --> Helper loaded: file_helper
INFO - 2023-04-26 12:15:58 --> Helper loaded: html_helper
INFO - 2023-04-26 12:15:58 --> Helper loaded: text_helper
INFO - 2023-04-26 12:15:58 --> Helper loaded: form_helper
INFO - 2023-04-26 12:15:58 --> Helper loaded: lang_helper
INFO - 2023-04-26 12:15:58 --> Helper loaded: security_helper
INFO - 2023-04-26 12:15:58 --> Helper loaded: cookie_helper
INFO - 2023-04-26 12:15:58 --> Database Driver Class Initialized
INFO - 2023-04-26 12:15:58 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-26 12:15:58 --> Parser Class Initialized
INFO - 2023-04-26 12:15:58 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-26 12:15:58 --> Pagination Class Initialized
INFO - 2023-04-26 12:15:58 --> Form Validation Class Initialized
INFO - 2023-04-26 12:15:58 --> Controller Class Initialized
INFO - 2023-04-26 12:15:58 --> Model Class Initialized
DEBUG - 2023-04-26 12:15:58 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-04-26 12:15:58 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-26 12:15:58 --> Model Class Initialized
DEBUG - 2023-04-26 12:15:58 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-26 12:15:58 --> Model Class Initialized
INFO - 2023-04-26 12:15:58 --> Final output sent to browser
DEBUG - 2023-04-26 12:15:58 --> Total execution time: 0.0178
ERROR - 2023-04-26 12:15:58 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-26 12:15:58 --> Config Class Initialized
INFO - 2023-04-26 12:15:58 --> Hooks Class Initialized
DEBUG - 2023-04-26 12:15:58 --> UTF-8 Support Enabled
INFO - 2023-04-26 12:15:58 --> Utf8 Class Initialized
INFO - 2023-04-26 12:15:58 --> URI Class Initialized
INFO - 2023-04-26 12:15:58 --> Router Class Initialized
INFO - 2023-04-26 12:15:58 --> Output Class Initialized
INFO - 2023-04-26 12:15:58 --> Security Class Initialized
DEBUG - 2023-04-26 12:15:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-26 12:15:58 --> Input Class Initialized
INFO - 2023-04-26 12:15:58 --> Language Class Initialized
INFO - 2023-04-26 12:15:58 --> Loader Class Initialized
INFO - 2023-04-26 12:15:58 --> Helper loaded: url_helper
INFO - 2023-04-26 12:15:58 --> Helper loaded: file_helper
INFO - 2023-04-26 12:15:58 --> Helper loaded: html_helper
INFO - 2023-04-26 12:15:58 --> Helper loaded: text_helper
INFO - 2023-04-26 12:15:58 --> Helper loaded: form_helper
INFO - 2023-04-26 12:15:58 --> Helper loaded: lang_helper
INFO - 2023-04-26 12:15:58 --> Helper loaded: security_helper
INFO - 2023-04-26 12:15:58 --> Helper loaded: cookie_helper
INFO - 2023-04-26 12:15:58 --> Database Driver Class Initialized
INFO - 2023-04-26 12:15:58 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-26 12:15:58 --> Parser Class Initialized
INFO - 2023-04-26 12:15:58 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-26 12:15:58 --> Pagination Class Initialized
INFO - 2023-04-26 12:15:58 --> Form Validation Class Initialized
INFO - 2023-04-26 12:15:58 --> Controller Class Initialized
INFO - 2023-04-26 12:15:58 --> Model Class Initialized
DEBUG - 2023-04-26 12:15:58 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-04-26 12:15:58 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-26 12:15:58 --> Model Class Initialized
DEBUG - 2023-04-26 12:15:58 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-26 12:15:58 --> Model Class Initialized
INFO - 2023-04-26 12:15:58 --> Final output sent to browser
DEBUG - 2023-04-26 12:15:58 --> Total execution time: 0.0193
ERROR - 2023-04-26 12:15:59 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-26 12:15:59 --> Config Class Initialized
INFO - 2023-04-26 12:15:59 --> Hooks Class Initialized
DEBUG - 2023-04-26 12:15:59 --> UTF-8 Support Enabled
INFO - 2023-04-26 12:15:59 --> Utf8 Class Initialized
INFO - 2023-04-26 12:15:59 --> URI Class Initialized
INFO - 2023-04-26 12:15:59 --> Router Class Initialized
INFO - 2023-04-26 12:15:59 --> Output Class Initialized
INFO - 2023-04-26 12:15:59 --> Security Class Initialized
DEBUG - 2023-04-26 12:15:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-26 12:15:59 --> Input Class Initialized
INFO - 2023-04-26 12:15:59 --> Language Class Initialized
INFO - 2023-04-26 12:15:59 --> Loader Class Initialized
INFO - 2023-04-26 12:15:59 --> Helper loaded: url_helper
INFO - 2023-04-26 12:15:59 --> Helper loaded: file_helper
INFO - 2023-04-26 12:15:59 --> Helper loaded: html_helper
INFO - 2023-04-26 12:15:59 --> Helper loaded: text_helper
INFO - 2023-04-26 12:15:59 --> Helper loaded: form_helper
INFO - 2023-04-26 12:15:59 --> Helper loaded: lang_helper
INFO - 2023-04-26 12:15:59 --> Helper loaded: security_helper
INFO - 2023-04-26 12:15:59 --> Helper loaded: cookie_helper
INFO - 2023-04-26 12:15:59 --> Database Driver Class Initialized
INFO - 2023-04-26 12:15:59 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-26 12:15:59 --> Parser Class Initialized
INFO - 2023-04-26 12:15:59 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-26 12:15:59 --> Pagination Class Initialized
INFO - 2023-04-26 12:15:59 --> Form Validation Class Initialized
INFO - 2023-04-26 12:15:59 --> Controller Class Initialized
INFO - 2023-04-26 12:15:59 --> Model Class Initialized
DEBUG - 2023-04-26 12:15:59 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-04-26 12:15:59 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-26 12:15:59 --> Model Class Initialized
DEBUG - 2023-04-26 12:15:59 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-26 12:15:59 --> Model Class Initialized
INFO - 2023-04-26 12:15:59 --> Final output sent to browser
DEBUG - 2023-04-26 12:15:59 --> Total execution time: 0.0182
ERROR - 2023-04-26 12:15:59 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-26 12:15:59 --> Config Class Initialized
INFO - 2023-04-26 12:15:59 --> Hooks Class Initialized
DEBUG - 2023-04-26 12:15:59 --> UTF-8 Support Enabled
INFO - 2023-04-26 12:15:59 --> Utf8 Class Initialized
INFO - 2023-04-26 12:15:59 --> URI Class Initialized
INFO - 2023-04-26 12:15:59 --> Router Class Initialized
INFO - 2023-04-26 12:15:59 --> Output Class Initialized
INFO - 2023-04-26 12:15:59 --> Security Class Initialized
DEBUG - 2023-04-26 12:15:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-26 12:15:59 --> Input Class Initialized
INFO - 2023-04-26 12:15:59 --> Language Class Initialized
INFO - 2023-04-26 12:15:59 --> Loader Class Initialized
INFO - 2023-04-26 12:15:59 --> Helper loaded: url_helper
INFO - 2023-04-26 12:15:59 --> Helper loaded: file_helper
INFO - 2023-04-26 12:15:59 --> Helper loaded: html_helper
INFO - 2023-04-26 12:15:59 --> Helper loaded: text_helper
INFO - 2023-04-26 12:15:59 --> Helper loaded: form_helper
INFO - 2023-04-26 12:15:59 --> Helper loaded: lang_helper
INFO - 2023-04-26 12:15:59 --> Helper loaded: security_helper
INFO - 2023-04-26 12:15:59 --> Helper loaded: cookie_helper
INFO - 2023-04-26 12:15:59 --> Database Driver Class Initialized
INFO - 2023-04-26 12:15:59 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-26 12:15:59 --> Parser Class Initialized
INFO - 2023-04-26 12:15:59 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-26 12:15:59 --> Pagination Class Initialized
INFO - 2023-04-26 12:15:59 --> Form Validation Class Initialized
INFO - 2023-04-26 12:15:59 --> Controller Class Initialized
INFO - 2023-04-26 12:15:59 --> Model Class Initialized
DEBUG - 2023-04-26 12:15:59 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-04-26 12:15:59 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-26 12:15:59 --> Model Class Initialized
DEBUG - 2023-04-26 12:15:59 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-26 12:15:59 --> Model Class Initialized
INFO - 2023-04-26 12:15:59 --> Final output sent to browser
DEBUG - 2023-04-26 12:15:59 --> Total execution time: 0.0172
ERROR - 2023-04-26 12:16:00 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-26 12:16:00 --> Config Class Initialized
INFO - 2023-04-26 12:16:00 --> Hooks Class Initialized
DEBUG - 2023-04-26 12:16:00 --> UTF-8 Support Enabled
INFO - 2023-04-26 12:16:00 --> Utf8 Class Initialized
INFO - 2023-04-26 12:16:00 --> URI Class Initialized
INFO - 2023-04-26 12:16:00 --> Router Class Initialized
INFO - 2023-04-26 12:16:00 --> Output Class Initialized
INFO - 2023-04-26 12:16:00 --> Security Class Initialized
DEBUG - 2023-04-26 12:16:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-26 12:16:00 --> Input Class Initialized
INFO - 2023-04-26 12:16:00 --> Language Class Initialized
INFO - 2023-04-26 12:16:00 --> Loader Class Initialized
INFO - 2023-04-26 12:16:00 --> Helper loaded: url_helper
INFO - 2023-04-26 12:16:00 --> Helper loaded: file_helper
INFO - 2023-04-26 12:16:00 --> Helper loaded: html_helper
INFO - 2023-04-26 12:16:00 --> Helper loaded: text_helper
INFO - 2023-04-26 12:16:00 --> Helper loaded: form_helper
INFO - 2023-04-26 12:16:00 --> Helper loaded: lang_helper
INFO - 2023-04-26 12:16:00 --> Helper loaded: security_helper
INFO - 2023-04-26 12:16:00 --> Helper loaded: cookie_helper
INFO - 2023-04-26 12:16:00 --> Database Driver Class Initialized
INFO - 2023-04-26 12:16:00 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-26 12:16:00 --> Parser Class Initialized
INFO - 2023-04-26 12:16:00 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-26 12:16:00 --> Pagination Class Initialized
INFO - 2023-04-26 12:16:00 --> Form Validation Class Initialized
INFO - 2023-04-26 12:16:00 --> Controller Class Initialized
INFO - 2023-04-26 12:16:00 --> Model Class Initialized
DEBUG - 2023-04-26 12:16:00 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-04-26 12:16:00 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-26 12:16:00 --> Model Class Initialized
DEBUG - 2023-04-26 12:16:00 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-26 12:16:00 --> Model Class Initialized
INFO - 2023-04-26 12:16:00 --> Final output sent to browser
DEBUG - 2023-04-26 12:16:00 --> Total execution time: 0.0211
ERROR - 2023-04-26 12:16:01 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-26 12:16:01 --> Config Class Initialized
INFO - 2023-04-26 12:16:01 --> Hooks Class Initialized
DEBUG - 2023-04-26 12:16:01 --> UTF-8 Support Enabled
INFO - 2023-04-26 12:16:01 --> Utf8 Class Initialized
INFO - 2023-04-26 12:16:01 --> URI Class Initialized
INFO - 2023-04-26 12:16:01 --> Router Class Initialized
INFO - 2023-04-26 12:16:01 --> Output Class Initialized
INFO - 2023-04-26 12:16:01 --> Security Class Initialized
DEBUG - 2023-04-26 12:16:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-26 12:16:01 --> Input Class Initialized
INFO - 2023-04-26 12:16:01 --> Language Class Initialized
INFO - 2023-04-26 12:16:01 --> Loader Class Initialized
INFO - 2023-04-26 12:16:01 --> Helper loaded: url_helper
INFO - 2023-04-26 12:16:01 --> Helper loaded: file_helper
INFO - 2023-04-26 12:16:01 --> Helper loaded: html_helper
INFO - 2023-04-26 12:16:01 --> Helper loaded: text_helper
INFO - 2023-04-26 12:16:01 --> Helper loaded: form_helper
INFO - 2023-04-26 12:16:01 --> Helper loaded: lang_helper
INFO - 2023-04-26 12:16:01 --> Helper loaded: security_helper
INFO - 2023-04-26 12:16:01 --> Helper loaded: cookie_helper
INFO - 2023-04-26 12:16:01 --> Database Driver Class Initialized
INFO - 2023-04-26 12:16:01 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-26 12:16:01 --> Parser Class Initialized
INFO - 2023-04-26 12:16:01 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-26 12:16:01 --> Pagination Class Initialized
INFO - 2023-04-26 12:16:01 --> Form Validation Class Initialized
INFO - 2023-04-26 12:16:01 --> Controller Class Initialized
INFO - 2023-04-26 12:16:01 --> Model Class Initialized
DEBUG - 2023-04-26 12:16:01 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-04-26 12:16:01 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-26 12:16:01 --> Model Class Initialized
DEBUG - 2023-04-26 12:16:01 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-26 12:16:01 --> Model Class Initialized
INFO - 2023-04-26 12:16:01 --> Final output sent to browser
DEBUG - 2023-04-26 12:16:01 --> Total execution time: 0.0169
ERROR - 2023-04-26 12:16:03 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-26 12:16:03 --> Config Class Initialized
INFO - 2023-04-26 12:16:03 --> Hooks Class Initialized
DEBUG - 2023-04-26 12:16:03 --> UTF-8 Support Enabled
INFO - 2023-04-26 12:16:03 --> Utf8 Class Initialized
INFO - 2023-04-26 12:16:03 --> URI Class Initialized
INFO - 2023-04-26 12:16:03 --> Router Class Initialized
INFO - 2023-04-26 12:16:03 --> Output Class Initialized
INFO - 2023-04-26 12:16:03 --> Security Class Initialized
DEBUG - 2023-04-26 12:16:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-26 12:16:03 --> Input Class Initialized
INFO - 2023-04-26 12:16:03 --> Language Class Initialized
INFO - 2023-04-26 12:16:03 --> Loader Class Initialized
INFO - 2023-04-26 12:16:03 --> Helper loaded: url_helper
INFO - 2023-04-26 12:16:03 --> Helper loaded: file_helper
INFO - 2023-04-26 12:16:03 --> Helper loaded: html_helper
INFO - 2023-04-26 12:16:03 --> Helper loaded: text_helper
INFO - 2023-04-26 12:16:03 --> Helper loaded: form_helper
INFO - 2023-04-26 12:16:03 --> Helper loaded: lang_helper
INFO - 2023-04-26 12:16:03 --> Helper loaded: security_helper
INFO - 2023-04-26 12:16:03 --> Helper loaded: cookie_helper
INFO - 2023-04-26 12:16:03 --> Database Driver Class Initialized
INFO - 2023-04-26 12:16:03 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-26 12:16:03 --> Parser Class Initialized
INFO - 2023-04-26 12:16:03 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-26 12:16:03 --> Pagination Class Initialized
INFO - 2023-04-26 12:16:03 --> Form Validation Class Initialized
INFO - 2023-04-26 12:16:03 --> Controller Class Initialized
INFO - 2023-04-26 12:16:03 --> Model Class Initialized
DEBUG - 2023-04-26 12:16:03 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-04-26 12:16:03 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-26 12:16:03 --> Model Class Initialized
DEBUG - 2023-04-26 12:16:03 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-26 12:16:03 --> Model Class Initialized
INFO - 2023-04-26 12:16:03 --> Final output sent to browser
DEBUG - 2023-04-26 12:16:03 --> Total execution time: 0.0176
ERROR - 2023-04-26 12:16:10 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-26 12:16:10 --> Config Class Initialized
INFO - 2023-04-26 12:16:10 --> Hooks Class Initialized
DEBUG - 2023-04-26 12:16:10 --> UTF-8 Support Enabled
INFO - 2023-04-26 12:16:10 --> Utf8 Class Initialized
INFO - 2023-04-26 12:16:10 --> URI Class Initialized
INFO - 2023-04-26 12:16:10 --> Router Class Initialized
INFO - 2023-04-26 12:16:11 --> Output Class Initialized
INFO - 2023-04-26 12:16:11 --> Security Class Initialized
DEBUG - 2023-04-26 12:16:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-26 12:16:11 --> Input Class Initialized
INFO - 2023-04-26 12:16:11 --> Language Class Initialized
INFO - 2023-04-26 12:16:11 --> Loader Class Initialized
INFO - 2023-04-26 12:16:11 --> Helper loaded: url_helper
INFO - 2023-04-26 12:16:11 --> Helper loaded: file_helper
INFO - 2023-04-26 12:16:11 --> Helper loaded: html_helper
INFO - 2023-04-26 12:16:11 --> Helper loaded: text_helper
INFO - 2023-04-26 12:16:11 --> Helper loaded: form_helper
INFO - 2023-04-26 12:16:11 --> Helper loaded: lang_helper
INFO - 2023-04-26 12:16:11 --> Helper loaded: security_helper
INFO - 2023-04-26 12:16:11 --> Helper loaded: cookie_helper
INFO - 2023-04-26 12:16:11 --> Database Driver Class Initialized
INFO - 2023-04-26 12:16:11 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-26 12:16:11 --> Parser Class Initialized
INFO - 2023-04-26 12:16:11 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-26 12:16:11 --> Pagination Class Initialized
INFO - 2023-04-26 12:16:11 --> Form Validation Class Initialized
INFO - 2023-04-26 12:16:11 --> Controller Class Initialized
INFO - 2023-04-26 12:16:11 --> Model Class Initialized
DEBUG - 2023-04-26 12:16:11 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-04-26 12:16:11 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-26 12:16:11 --> Model Class Initialized
DEBUG - 2023-04-26 12:16:11 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-26 12:16:11 --> Model Class Initialized
INFO - 2023-04-26 12:16:11 --> Final output sent to browser
DEBUG - 2023-04-26 12:16:11 --> Total execution time: 0.0178
ERROR - 2023-04-26 12:16:13 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-26 12:16:13 --> Config Class Initialized
INFO - 2023-04-26 12:16:13 --> Hooks Class Initialized
DEBUG - 2023-04-26 12:16:13 --> UTF-8 Support Enabled
INFO - 2023-04-26 12:16:13 --> Utf8 Class Initialized
INFO - 2023-04-26 12:16:13 --> URI Class Initialized
INFO - 2023-04-26 12:16:13 --> Router Class Initialized
INFO - 2023-04-26 12:16:13 --> Output Class Initialized
INFO - 2023-04-26 12:16:13 --> Security Class Initialized
DEBUG - 2023-04-26 12:16:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-26 12:16:13 --> Input Class Initialized
INFO - 2023-04-26 12:16:13 --> Language Class Initialized
INFO - 2023-04-26 12:16:13 --> Loader Class Initialized
INFO - 2023-04-26 12:16:13 --> Helper loaded: url_helper
INFO - 2023-04-26 12:16:13 --> Helper loaded: file_helper
INFO - 2023-04-26 12:16:13 --> Helper loaded: html_helper
INFO - 2023-04-26 12:16:13 --> Helper loaded: text_helper
INFO - 2023-04-26 12:16:13 --> Helper loaded: form_helper
INFO - 2023-04-26 12:16:13 --> Helper loaded: lang_helper
INFO - 2023-04-26 12:16:13 --> Helper loaded: security_helper
INFO - 2023-04-26 12:16:13 --> Helper loaded: cookie_helper
INFO - 2023-04-26 12:16:13 --> Database Driver Class Initialized
INFO - 2023-04-26 12:16:13 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-26 12:16:13 --> Parser Class Initialized
INFO - 2023-04-26 12:16:13 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-26 12:16:13 --> Pagination Class Initialized
INFO - 2023-04-26 12:16:13 --> Form Validation Class Initialized
INFO - 2023-04-26 12:16:13 --> Controller Class Initialized
INFO - 2023-04-26 12:16:13 --> Model Class Initialized
DEBUG - 2023-04-26 12:16:13 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-04-26 12:16:13 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-26 12:16:13 --> Model Class Initialized
DEBUG - 2023-04-26 12:16:13 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-26 12:16:13 --> Model Class Initialized
INFO - 2023-04-26 12:16:13 --> Final output sent to browser
DEBUG - 2023-04-26 12:16:13 --> Total execution time: 0.0205
ERROR - 2023-04-26 12:16:14 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-26 12:16:14 --> Config Class Initialized
INFO - 2023-04-26 12:16:14 --> Hooks Class Initialized
DEBUG - 2023-04-26 12:16:14 --> UTF-8 Support Enabled
INFO - 2023-04-26 12:16:14 --> Utf8 Class Initialized
INFO - 2023-04-26 12:16:14 --> URI Class Initialized
INFO - 2023-04-26 12:16:14 --> Router Class Initialized
INFO - 2023-04-26 12:16:14 --> Output Class Initialized
INFO - 2023-04-26 12:16:14 --> Security Class Initialized
DEBUG - 2023-04-26 12:16:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-26 12:16:14 --> Input Class Initialized
INFO - 2023-04-26 12:16:14 --> Language Class Initialized
INFO - 2023-04-26 12:16:14 --> Loader Class Initialized
INFO - 2023-04-26 12:16:14 --> Helper loaded: url_helper
INFO - 2023-04-26 12:16:14 --> Helper loaded: file_helper
INFO - 2023-04-26 12:16:14 --> Helper loaded: html_helper
INFO - 2023-04-26 12:16:14 --> Helper loaded: text_helper
INFO - 2023-04-26 12:16:14 --> Helper loaded: form_helper
INFO - 2023-04-26 12:16:14 --> Helper loaded: lang_helper
INFO - 2023-04-26 12:16:14 --> Helper loaded: security_helper
INFO - 2023-04-26 12:16:14 --> Helper loaded: cookie_helper
INFO - 2023-04-26 12:16:14 --> Database Driver Class Initialized
INFO - 2023-04-26 12:16:14 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-26 12:16:14 --> Parser Class Initialized
INFO - 2023-04-26 12:16:14 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-26 12:16:14 --> Pagination Class Initialized
INFO - 2023-04-26 12:16:14 --> Form Validation Class Initialized
INFO - 2023-04-26 12:16:14 --> Controller Class Initialized
INFO - 2023-04-26 12:16:14 --> Model Class Initialized
DEBUG - 2023-04-26 12:16:14 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-04-26 12:16:14 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-26 12:16:14 --> Model Class Initialized
DEBUG - 2023-04-26 12:16:14 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-26 12:16:14 --> Model Class Initialized
INFO - 2023-04-26 12:16:14 --> Final output sent to browser
DEBUG - 2023-04-26 12:16:14 --> Total execution time: 0.0197
ERROR - 2023-04-26 12:16:15 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-26 12:16:15 --> Config Class Initialized
INFO - 2023-04-26 12:16:15 --> Hooks Class Initialized
DEBUG - 2023-04-26 12:16:15 --> UTF-8 Support Enabled
INFO - 2023-04-26 12:16:15 --> Utf8 Class Initialized
INFO - 2023-04-26 12:16:15 --> URI Class Initialized
INFO - 2023-04-26 12:16:15 --> Router Class Initialized
INFO - 2023-04-26 12:16:15 --> Output Class Initialized
INFO - 2023-04-26 12:16:15 --> Security Class Initialized
DEBUG - 2023-04-26 12:16:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-26 12:16:15 --> Input Class Initialized
INFO - 2023-04-26 12:16:15 --> Language Class Initialized
INFO - 2023-04-26 12:16:15 --> Loader Class Initialized
INFO - 2023-04-26 12:16:15 --> Helper loaded: url_helper
INFO - 2023-04-26 12:16:15 --> Helper loaded: file_helper
INFO - 2023-04-26 12:16:15 --> Helper loaded: html_helper
INFO - 2023-04-26 12:16:15 --> Helper loaded: text_helper
INFO - 2023-04-26 12:16:15 --> Helper loaded: form_helper
INFO - 2023-04-26 12:16:15 --> Helper loaded: lang_helper
INFO - 2023-04-26 12:16:15 --> Helper loaded: security_helper
INFO - 2023-04-26 12:16:15 --> Helper loaded: cookie_helper
INFO - 2023-04-26 12:16:15 --> Database Driver Class Initialized
INFO - 2023-04-26 12:16:15 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-26 12:16:15 --> Parser Class Initialized
INFO - 2023-04-26 12:16:15 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-26 12:16:15 --> Pagination Class Initialized
INFO - 2023-04-26 12:16:15 --> Form Validation Class Initialized
INFO - 2023-04-26 12:16:15 --> Controller Class Initialized
INFO - 2023-04-26 12:16:15 --> Model Class Initialized
DEBUG - 2023-04-26 12:16:15 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-04-26 12:16:15 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-26 12:16:15 --> Model Class Initialized
DEBUG - 2023-04-26 12:16:15 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-26 12:16:15 --> Model Class Initialized
INFO - 2023-04-26 12:16:15 --> Final output sent to browser
DEBUG - 2023-04-26 12:16:15 --> Total execution time: 0.0179
ERROR - 2023-04-26 12:16:15 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-26 12:16:15 --> Config Class Initialized
INFO - 2023-04-26 12:16:15 --> Hooks Class Initialized
DEBUG - 2023-04-26 12:16:15 --> UTF-8 Support Enabled
INFO - 2023-04-26 12:16:15 --> Utf8 Class Initialized
INFO - 2023-04-26 12:16:15 --> URI Class Initialized
INFO - 2023-04-26 12:16:15 --> Router Class Initialized
INFO - 2023-04-26 12:16:15 --> Output Class Initialized
INFO - 2023-04-26 12:16:15 --> Security Class Initialized
DEBUG - 2023-04-26 12:16:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-26 12:16:15 --> Input Class Initialized
INFO - 2023-04-26 12:16:15 --> Language Class Initialized
INFO - 2023-04-26 12:16:15 --> Loader Class Initialized
INFO - 2023-04-26 12:16:15 --> Helper loaded: url_helper
INFO - 2023-04-26 12:16:15 --> Helper loaded: file_helper
INFO - 2023-04-26 12:16:15 --> Helper loaded: html_helper
INFO - 2023-04-26 12:16:15 --> Helper loaded: text_helper
INFO - 2023-04-26 12:16:15 --> Helper loaded: form_helper
INFO - 2023-04-26 12:16:15 --> Helper loaded: lang_helper
INFO - 2023-04-26 12:16:15 --> Helper loaded: security_helper
INFO - 2023-04-26 12:16:15 --> Helper loaded: cookie_helper
INFO - 2023-04-26 12:16:15 --> Database Driver Class Initialized
INFO - 2023-04-26 12:16:15 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-26 12:16:15 --> Parser Class Initialized
INFO - 2023-04-26 12:16:15 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-26 12:16:15 --> Pagination Class Initialized
INFO - 2023-04-26 12:16:15 --> Form Validation Class Initialized
INFO - 2023-04-26 12:16:15 --> Controller Class Initialized
INFO - 2023-04-26 12:16:15 --> Model Class Initialized
DEBUG - 2023-04-26 12:16:15 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-04-26 12:16:15 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-26 12:16:15 --> Model Class Initialized
DEBUG - 2023-04-26 12:16:15 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-26 12:16:15 --> Model Class Initialized
INFO - 2023-04-26 12:16:15 --> Final output sent to browser
DEBUG - 2023-04-26 12:16:15 --> Total execution time: 0.0177
ERROR - 2023-04-26 12:16:15 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-26 12:16:15 --> Config Class Initialized
INFO - 2023-04-26 12:16:15 --> Hooks Class Initialized
DEBUG - 2023-04-26 12:16:15 --> UTF-8 Support Enabled
INFO - 2023-04-26 12:16:15 --> Utf8 Class Initialized
INFO - 2023-04-26 12:16:15 --> URI Class Initialized
INFO - 2023-04-26 12:16:15 --> Router Class Initialized
INFO - 2023-04-26 12:16:15 --> Output Class Initialized
INFO - 2023-04-26 12:16:15 --> Security Class Initialized
DEBUG - 2023-04-26 12:16:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-26 12:16:15 --> Input Class Initialized
INFO - 2023-04-26 12:16:15 --> Language Class Initialized
INFO - 2023-04-26 12:16:15 --> Loader Class Initialized
INFO - 2023-04-26 12:16:15 --> Helper loaded: url_helper
INFO - 2023-04-26 12:16:15 --> Helper loaded: file_helper
INFO - 2023-04-26 12:16:15 --> Helper loaded: html_helper
INFO - 2023-04-26 12:16:15 --> Helper loaded: text_helper
INFO - 2023-04-26 12:16:15 --> Helper loaded: form_helper
INFO - 2023-04-26 12:16:15 --> Helper loaded: lang_helper
INFO - 2023-04-26 12:16:15 --> Helper loaded: security_helper
INFO - 2023-04-26 12:16:15 --> Helper loaded: cookie_helper
INFO - 2023-04-26 12:16:15 --> Database Driver Class Initialized
INFO - 2023-04-26 12:16:15 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-26 12:16:15 --> Parser Class Initialized
INFO - 2023-04-26 12:16:15 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-26 12:16:15 --> Pagination Class Initialized
INFO - 2023-04-26 12:16:15 --> Form Validation Class Initialized
INFO - 2023-04-26 12:16:15 --> Controller Class Initialized
INFO - 2023-04-26 12:16:15 --> Model Class Initialized
DEBUG - 2023-04-26 12:16:15 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-04-26 12:16:15 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-26 12:16:15 --> Model Class Initialized
DEBUG - 2023-04-26 12:16:15 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-26 12:16:15 --> Model Class Initialized
INFO - 2023-04-26 12:16:15 --> Final output sent to browser
DEBUG - 2023-04-26 12:16:15 --> Total execution time: 0.0178
ERROR - 2023-04-26 12:16:16 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-26 12:16:16 --> Config Class Initialized
INFO - 2023-04-26 12:16:16 --> Hooks Class Initialized
DEBUG - 2023-04-26 12:16:16 --> UTF-8 Support Enabled
INFO - 2023-04-26 12:16:16 --> Utf8 Class Initialized
INFO - 2023-04-26 12:16:16 --> URI Class Initialized
INFO - 2023-04-26 12:16:16 --> Router Class Initialized
INFO - 2023-04-26 12:16:16 --> Output Class Initialized
INFO - 2023-04-26 12:16:16 --> Security Class Initialized
DEBUG - 2023-04-26 12:16:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-26 12:16:16 --> Input Class Initialized
INFO - 2023-04-26 12:16:16 --> Language Class Initialized
INFO - 2023-04-26 12:16:16 --> Loader Class Initialized
INFO - 2023-04-26 12:16:16 --> Helper loaded: url_helper
INFO - 2023-04-26 12:16:16 --> Helper loaded: file_helper
INFO - 2023-04-26 12:16:16 --> Helper loaded: html_helper
INFO - 2023-04-26 12:16:16 --> Helper loaded: text_helper
INFO - 2023-04-26 12:16:16 --> Helper loaded: form_helper
INFO - 2023-04-26 12:16:16 --> Helper loaded: lang_helper
INFO - 2023-04-26 12:16:16 --> Helper loaded: security_helper
INFO - 2023-04-26 12:16:16 --> Helper loaded: cookie_helper
INFO - 2023-04-26 12:16:16 --> Database Driver Class Initialized
INFO - 2023-04-26 12:16:16 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-26 12:16:16 --> Parser Class Initialized
INFO - 2023-04-26 12:16:16 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-26 12:16:16 --> Pagination Class Initialized
INFO - 2023-04-26 12:16:16 --> Form Validation Class Initialized
INFO - 2023-04-26 12:16:16 --> Controller Class Initialized
INFO - 2023-04-26 12:16:16 --> Model Class Initialized
DEBUG - 2023-04-26 12:16:16 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-04-26 12:16:16 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-26 12:16:16 --> Model Class Initialized
DEBUG - 2023-04-26 12:16:16 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-26 12:16:16 --> Model Class Initialized
INFO - 2023-04-26 12:16:16 --> Final output sent to browser
DEBUG - 2023-04-26 12:16:16 --> Total execution time: 0.0201
ERROR - 2023-04-26 12:16:18 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-26 12:16:18 --> Config Class Initialized
INFO - 2023-04-26 12:16:18 --> Hooks Class Initialized
DEBUG - 2023-04-26 12:16:18 --> UTF-8 Support Enabled
INFO - 2023-04-26 12:16:18 --> Utf8 Class Initialized
INFO - 2023-04-26 12:16:18 --> URI Class Initialized
INFO - 2023-04-26 12:16:18 --> Router Class Initialized
INFO - 2023-04-26 12:16:18 --> Output Class Initialized
INFO - 2023-04-26 12:16:18 --> Security Class Initialized
DEBUG - 2023-04-26 12:16:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-26 12:16:18 --> Input Class Initialized
INFO - 2023-04-26 12:16:18 --> Language Class Initialized
INFO - 2023-04-26 12:16:18 --> Loader Class Initialized
INFO - 2023-04-26 12:16:18 --> Helper loaded: url_helper
INFO - 2023-04-26 12:16:18 --> Helper loaded: file_helper
INFO - 2023-04-26 12:16:18 --> Helper loaded: html_helper
INFO - 2023-04-26 12:16:18 --> Helper loaded: text_helper
INFO - 2023-04-26 12:16:18 --> Helper loaded: form_helper
INFO - 2023-04-26 12:16:18 --> Helper loaded: lang_helper
INFO - 2023-04-26 12:16:18 --> Helper loaded: security_helper
INFO - 2023-04-26 12:16:18 --> Helper loaded: cookie_helper
INFO - 2023-04-26 12:16:18 --> Database Driver Class Initialized
INFO - 2023-04-26 12:16:18 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-26 12:16:18 --> Parser Class Initialized
INFO - 2023-04-26 12:16:18 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-26 12:16:18 --> Pagination Class Initialized
INFO - 2023-04-26 12:16:18 --> Form Validation Class Initialized
INFO - 2023-04-26 12:16:18 --> Controller Class Initialized
INFO - 2023-04-26 12:16:18 --> Model Class Initialized
DEBUG - 2023-04-26 12:16:18 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-04-26 12:16:18 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-26 12:16:18 --> Model Class Initialized
DEBUG - 2023-04-26 12:16:18 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-26 12:16:18 --> Model Class Initialized
INFO - 2023-04-26 12:16:18 --> Model Class Initialized
INFO - 2023-04-26 12:16:18 --> Final output sent to browser
DEBUG - 2023-04-26 12:16:18 --> Total execution time: 0.0223
ERROR - 2023-04-26 12:16:20 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-26 12:16:20 --> Config Class Initialized
INFO - 2023-04-26 12:16:20 --> Hooks Class Initialized
DEBUG - 2023-04-26 12:16:20 --> UTF-8 Support Enabled
INFO - 2023-04-26 12:16:20 --> Utf8 Class Initialized
INFO - 2023-04-26 12:16:20 --> URI Class Initialized
INFO - 2023-04-26 12:16:20 --> Router Class Initialized
INFO - 2023-04-26 12:16:20 --> Output Class Initialized
INFO - 2023-04-26 12:16:20 --> Security Class Initialized
DEBUG - 2023-04-26 12:16:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-26 12:16:20 --> Input Class Initialized
INFO - 2023-04-26 12:16:20 --> Language Class Initialized
INFO - 2023-04-26 12:16:20 --> Loader Class Initialized
INFO - 2023-04-26 12:16:20 --> Helper loaded: url_helper
INFO - 2023-04-26 12:16:20 --> Helper loaded: file_helper
INFO - 2023-04-26 12:16:20 --> Helper loaded: html_helper
INFO - 2023-04-26 12:16:20 --> Helper loaded: text_helper
INFO - 2023-04-26 12:16:20 --> Helper loaded: form_helper
INFO - 2023-04-26 12:16:20 --> Helper loaded: lang_helper
INFO - 2023-04-26 12:16:20 --> Helper loaded: security_helper
INFO - 2023-04-26 12:16:20 --> Helper loaded: cookie_helper
INFO - 2023-04-26 12:16:20 --> Database Driver Class Initialized
INFO - 2023-04-26 12:16:20 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-26 12:16:20 --> Parser Class Initialized
INFO - 2023-04-26 12:16:20 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-26 12:16:20 --> Pagination Class Initialized
INFO - 2023-04-26 12:16:20 --> Form Validation Class Initialized
INFO - 2023-04-26 12:16:20 --> Controller Class Initialized
INFO - 2023-04-26 12:16:20 --> Model Class Initialized
DEBUG - 2023-04-26 12:16:20 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-04-26 12:16:20 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-26 12:16:20 --> Model Class Initialized
DEBUG - 2023-04-26 12:16:20 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-26 12:16:20 --> Model Class Initialized
INFO - 2023-04-26 12:16:20 --> Final output sent to browser
DEBUG - 2023-04-26 12:16:20 --> Total execution time: 0.0243
ERROR - 2023-04-26 12:16:23 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-26 12:16:23 --> Config Class Initialized
INFO - 2023-04-26 12:16:23 --> Hooks Class Initialized
DEBUG - 2023-04-26 12:16:23 --> UTF-8 Support Enabled
INFO - 2023-04-26 12:16:23 --> Utf8 Class Initialized
INFO - 2023-04-26 12:16:23 --> URI Class Initialized
INFO - 2023-04-26 12:16:23 --> Router Class Initialized
INFO - 2023-04-26 12:16:23 --> Output Class Initialized
INFO - 2023-04-26 12:16:23 --> Security Class Initialized
DEBUG - 2023-04-26 12:16:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-26 12:16:23 --> Input Class Initialized
INFO - 2023-04-26 12:16:23 --> Language Class Initialized
INFO - 2023-04-26 12:16:23 --> Loader Class Initialized
INFO - 2023-04-26 12:16:23 --> Helper loaded: url_helper
INFO - 2023-04-26 12:16:23 --> Helper loaded: file_helper
INFO - 2023-04-26 12:16:23 --> Helper loaded: html_helper
INFO - 2023-04-26 12:16:23 --> Helper loaded: text_helper
INFO - 2023-04-26 12:16:23 --> Helper loaded: form_helper
INFO - 2023-04-26 12:16:23 --> Helper loaded: lang_helper
INFO - 2023-04-26 12:16:23 --> Helper loaded: security_helper
INFO - 2023-04-26 12:16:23 --> Helper loaded: cookie_helper
INFO - 2023-04-26 12:16:23 --> Database Driver Class Initialized
INFO - 2023-04-26 12:16:23 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-26 12:16:23 --> Parser Class Initialized
INFO - 2023-04-26 12:16:23 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-26 12:16:23 --> Pagination Class Initialized
INFO - 2023-04-26 12:16:23 --> Form Validation Class Initialized
INFO - 2023-04-26 12:16:23 --> Controller Class Initialized
INFO - 2023-04-26 12:16:23 --> Model Class Initialized
DEBUG - 2023-04-26 12:16:23 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-04-26 12:16:23 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-26 12:16:23 --> Model Class Initialized
DEBUG - 2023-04-26 12:16:23 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-26 12:16:23 --> Model Class Initialized
INFO - 2023-04-26 12:16:23 --> Final output sent to browser
DEBUG - 2023-04-26 12:16:23 --> Total execution time: 0.0187
ERROR - 2023-04-26 12:16:24 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-26 12:16:24 --> Config Class Initialized
INFO - 2023-04-26 12:16:24 --> Hooks Class Initialized
DEBUG - 2023-04-26 12:16:24 --> UTF-8 Support Enabled
INFO - 2023-04-26 12:16:24 --> Utf8 Class Initialized
INFO - 2023-04-26 12:16:24 --> URI Class Initialized
INFO - 2023-04-26 12:16:24 --> Router Class Initialized
INFO - 2023-04-26 12:16:24 --> Output Class Initialized
INFO - 2023-04-26 12:16:24 --> Security Class Initialized
DEBUG - 2023-04-26 12:16:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-26 12:16:24 --> Input Class Initialized
INFO - 2023-04-26 12:16:24 --> Language Class Initialized
INFO - 2023-04-26 12:16:24 --> Loader Class Initialized
INFO - 2023-04-26 12:16:24 --> Helper loaded: url_helper
INFO - 2023-04-26 12:16:24 --> Helper loaded: file_helper
INFO - 2023-04-26 12:16:24 --> Helper loaded: html_helper
INFO - 2023-04-26 12:16:24 --> Helper loaded: text_helper
INFO - 2023-04-26 12:16:24 --> Helper loaded: form_helper
INFO - 2023-04-26 12:16:24 --> Helper loaded: lang_helper
INFO - 2023-04-26 12:16:24 --> Helper loaded: security_helper
INFO - 2023-04-26 12:16:24 --> Helper loaded: cookie_helper
INFO - 2023-04-26 12:16:24 --> Database Driver Class Initialized
INFO - 2023-04-26 12:16:24 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-26 12:16:24 --> Parser Class Initialized
INFO - 2023-04-26 12:16:24 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-26 12:16:24 --> Pagination Class Initialized
INFO - 2023-04-26 12:16:24 --> Form Validation Class Initialized
INFO - 2023-04-26 12:16:24 --> Controller Class Initialized
INFO - 2023-04-26 12:16:24 --> Model Class Initialized
DEBUG - 2023-04-26 12:16:24 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-04-26 12:16:24 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-26 12:16:24 --> Model Class Initialized
DEBUG - 2023-04-26 12:16:24 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-26 12:16:24 --> Model Class Initialized
INFO - 2023-04-26 12:16:24 --> Final output sent to browser
DEBUG - 2023-04-26 12:16:24 --> Total execution time: 0.0177
ERROR - 2023-04-26 12:16:24 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-26 12:16:24 --> Config Class Initialized
INFO - 2023-04-26 12:16:24 --> Hooks Class Initialized
DEBUG - 2023-04-26 12:16:24 --> UTF-8 Support Enabled
INFO - 2023-04-26 12:16:24 --> Utf8 Class Initialized
INFO - 2023-04-26 12:16:24 --> URI Class Initialized
INFO - 2023-04-26 12:16:24 --> Router Class Initialized
INFO - 2023-04-26 12:16:24 --> Output Class Initialized
INFO - 2023-04-26 12:16:24 --> Security Class Initialized
DEBUG - 2023-04-26 12:16:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-26 12:16:24 --> Input Class Initialized
INFO - 2023-04-26 12:16:24 --> Language Class Initialized
INFO - 2023-04-26 12:16:24 --> Loader Class Initialized
INFO - 2023-04-26 12:16:24 --> Helper loaded: url_helper
INFO - 2023-04-26 12:16:24 --> Helper loaded: file_helper
INFO - 2023-04-26 12:16:24 --> Helper loaded: html_helper
INFO - 2023-04-26 12:16:24 --> Helper loaded: text_helper
INFO - 2023-04-26 12:16:24 --> Helper loaded: form_helper
INFO - 2023-04-26 12:16:24 --> Helper loaded: lang_helper
INFO - 2023-04-26 12:16:24 --> Helper loaded: security_helper
INFO - 2023-04-26 12:16:24 --> Helper loaded: cookie_helper
INFO - 2023-04-26 12:16:24 --> Database Driver Class Initialized
INFO - 2023-04-26 12:16:24 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-26 12:16:24 --> Parser Class Initialized
INFO - 2023-04-26 12:16:24 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-26 12:16:24 --> Pagination Class Initialized
INFO - 2023-04-26 12:16:24 --> Form Validation Class Initialized
INFO - 2023-04-26 12:16:24 --> Controller Class Initialized
INFO - 2023-04-26 12:16:24 --> Model Class Initialized
DEBUG - 2023-04-26 12:16:24 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-04-26 12:16:24 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-26 12:16:24 --> Model Class Initialized
DEBUG - 2023-04-26 12:16:24 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-26 12:16:24 --> Model Class Initialized
INFO - 2023-04-26 12:16:24 --> Final output sent to browser
DEBUG - 2023-04-26 12:16:24 --> Total execution time: 0.0223
ERROR - 2023-04-26 12:16:24 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-26 12:16:24 --> Config Class Initialized
INFO - 2023-04-26 12:16:24 --> Hooks Class Initialized
DEBUG - 2023-04-26 12:16:25 --> UTF-8 Support Enabled
INFO - 2023-04-26 12:16:25 --> Utf8 Class Initialized
INFO - 2023-04-26 12:16:25 --> URI Class Initialized
INFO - 2023-04-26 12:16:25 --> Router Class Initialized
INFO - 2023-04-26 12:16:25 --> Output Class Initialized
INFO - 2023-04-26 12:16:25 --> Security Class Initialized
DEBUG - 2023-04-26 12:16:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-26 12:16:25 --> Input Class Initialized
INFO - 2023-04-26 12:16:25 --> Language Class Initialized
INFO - 2023-04-26 12:16:25 --> Loader Class Initialized
INFO - 2023-04-26 12:16:25 --> Helper loaded: url_helper
INFO - 2023-04-26 12:16:25 --> Helper loaded: file_helper
INFO - 2023-04-26 12:16:25 --> Helper loaded: html_helper
INFO - 2023-04-26 12:16:25 --> Helper loaded: text_helper
INFO - 2023-04-26 12:16:25 --> Helper loaded: form_helper
INFO - 2023-04-26 12:16:25 --> Helper loaded: lang_helper
INFO - 2023-04-26 12:16:25 --> Helper loaded: security_helper
INFO - 2023-04-26 12:16:25 --> Helper loaded: cookie_helper
INFO - 2023-04-26 12:16:25 --> Database Driver Class Initialized
INFO - 2023-04-26 12:16:25 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-26 12:16:25 --> Parser Class Initialized
INFO - 2023-04-26 12:16:25 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-26 12:16:25 --> Pagination Class Initialized
INFO - 2023-04-26 12:16:25 --> Form Validation Class Initialized
INFO - 2023-04-26 12:16:25 --> Controller Class Initialized
INFO - 2023-04-26 12:16:25 --> Model Class Initialized
DEBUG - 2023-04-26 12:16:25 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-04-26 12:16:25 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-26 12:16:25 --> Model Class Initialized
DEBUG - 2023-04-26 12:16:25 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-26 12:16:25 --> Model Class Initialized
INFO - 2023-04-26 12:16:25 --> Final output sent to browser
DEBUG - 2023-04-26 12:16:25 --> Total execution time: 0.0176
ERROR - 2023-04-26 12:16:27 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-26 12:16:27 --> Config Class Initialized
INFO - 2023-04-26 12:16:27 --> Hooks Class Initialized
DEBUG - 2023-04-26 12:16:27 --> UTF-8 Support Enabled
INFO - 2023-04-26 12:16:27 --> Utf8 Class Initialized
INFO - 2023-04-26 12:16:27 --> URI Class Initialized
INFO - 2023-04-26 12:16:27 --> Router Class Initialized
INFO - 2023-04-26 12:16:27 --> Output Class Initialized
INFO - 2023-04-26 12:16:27 --> Security Class Initialized
DEBUG - 2023-04-26 12:16:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-26 12:16:27 --> Input Class Initialized
INFO - 2023-04-26 12:16:27 --> Language Class Initialized
INFO - 2023-04-26 12:16:27 --> Loader Class Initialized
INFO - 2023-04-26 12:16:27 --> Helper loaded: url_helper
INFO - 2023-04-26 12:16:27 --> Helper loaded: file_helper
INFO - 2023-04-26 12:16:27 --> Helper loaded: html_helper
INFO - 2023-04-26 12:16:27 --> Helper loaded: text_helper
INFO - 2023-04-26 12:16:27 --> Helper loaded: form_helper
INFO - 2023-04-26 12:16:27 --> Helper loaded: lang_helper
INFO - 2023-04-26 12:16:27 --> Helper loaded: security_helper
INFO - 2023-04-26 12:16:27 --> Helper loaded: cookie_helper
INFO - 2023-04-26 12:16:27 --> Database Driver Class Initialized
INFO - 2023-04-26 12:16:27 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-26 12:16:27 --> Parser Class Initialized
INFO - 2023-04-26 12:16:27 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-26 12:16:27 --> Pagination Class Initialized
INFO - 2023-04-26 12:16:27 --> Form Validation Class Initialized
INFO - 2023-04-26 12:16:27 --> Controller Class Initialized
INFO - 2023-04-26 12:16:27 --> Model Class Initialized
DEBUG - 2023-04-26 12:16:27 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-04-26 12:16:27 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-26 12:16:27 --> Model Class Initialized
DEBUG - 2023-04-26 12:16:27 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-26 12:16:27 --> Model Class Initialized
INFO - 2023-04-26 12:16:27 --> Final output sent to browser
DEBUG - 2023-04-26 12:16:27 --> Total execution time: 0.0174
ERROR - 2023-04-26 12:16:27 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-26 12:16:27 --> Config Class Initialized
INFO - 2023-04-26 12:16:27 --> Hooks Class Initialized
DEBUG - 2023-04-26 12:16:27 --> UTF-8 Support Enabled
INFO - 2023-04-26 12:16:27 --> Utf8 Class Initialized
INFO - 2023-04-26 12:16:27 --> URI Class Initialized
INFO - 2023-04-26 12:16:27 --> Router Class Initialized
INFO - 2023-04-26 12:16:27 --> Output Class Initialized
INFO - 2023-04-26 12:16:27 --> Security Class Initialized
DEBUG - 2023-04-26 12:16:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-26 12:16:27 --> Input Class Initialized
INFO - 2023-04-26 12:16:27 --> Language Class Initialized
INFO - 2023-04-26 12:16:27 --> Loader Class Initialized
INFO - 2023-04-26 12:16:27 --> Helper loaded: url_helper
INFO - 2023-04-26 12:16:27 --> Helper loaded: file_helper
INFO - 2023-04-26 12:16:27 --> Helper loaded: html_helper
INFO - 2023-04-26 12:16:27 --> Helper loaded: text_helper
INFO - 2023-04-26 12:16:27 --> Helper loaded: form_helper
INFO - 2023-04-26 12:16:27 --> Helper loaded: lang_helper
INFO - 2023-04-26 12:16:27 --> Helper loaded: security_helper
INFO - 2023-04-26 12:16:27 --> Helper loaded: cookie_helper
INFO - 2023-04-26 12:16:27 --> Database Driver Class Initialized
INFO - 2023-04-26 12:16:27 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-26 12:16:27 --> Parser Class Initialized
INFO - 2023-04-26 12:16:27 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-26 12:16:27 --> Pagination Class Initialized
INFO - 2023-04-26 12:16:27 --> Form Validation Class Initialized
INFO - 2023-04-26 12:16:27 --> Controller Class Initialized
INFO - 2023-04-26 12:16:27 --> Model Class Initialized
DEBUG - 2023-04-26 12:16:27 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-04-26 12:16:27 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-26 12:16:27 --> Model Class Initialized
DEBUG - 2023-04-26 12:16:27 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-26 12:16:27 --> Model Class Initialized
INFO - 2023-04-26 12:16:27 --> Final output sent to browser
DEBUG - 2023-04-26 12:16:27 --> Total execution time: 0.0174
ERROR - 2023-04-26 12:16:29 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-26 12:16:29 --> Config Class Initialized
INFO - 2023-04-26 12:16:29 --> Hooks Class Initialized
DEBUG - 2023-04-26 12:16:29 --> UTF-8 Support Enabled
INFO - 2023-04-26 12:16:29 --> Utf8 Class Initialized
INFO - 2023-04-26 12:16:29 --> URI Class Initialized
INFO - 2023-04-26 12:16:29 --> Router Class Initialized
INFO - 2023-04-26 12:16:29 --> Output Class Initialized
INFO - 2023-04-26 12:16:29 --> Security Class Initialized
DEBUG - 2023-04-26 12:16:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-26 12:16:29 --> Input Class Initialized
INFO - 2023-04-26 12:16:29 --> Language Class Initialized
INFO - 2023-04-26 12:16:29 --> Loader Class Initialized
INFO - 2023-04-26 12:16:29 --> Helper loaded: url_helper
INFO - 2023-04-26 12:16:29 --> Helper loaded: file_helper
INFO - 2023-04-26 12:16:29 --> Helper loaded: html_helper
INFO - 2023-04-26 12:16:29 --> Helper loaded: text_helper
INFO - 2023-04-26 12:16:29 --> Helper loaded: form_helper
INFO - 2023-04-26 12:16:29 --> Helper loaded: lang_helper
INFO - 2023-04-26 12:16:29 --> Helper loaded: security_helper
INFO - 2023-04-26 12:16:29 --> Helper loaded: cookie_helper
INFO - 2023-04-26 12:16:29 --> Database Driver Class Initialized
INFO - 2023-04-26 12:16:29 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-26 12:16:29 --> Parser Class Initialized
INFO - 2023-04-26 12:16:29 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-26 12:16:29 --> Pagination Class Initialized
INFO - 2023-04-26 12:16:29 --> Form Validation Class Initialized
INFO - 2023-04-26 12:16:29 --> Controller Class Initialized
INFO - 2023-04-26 12:16:29 --> Model Class Initialized
DEBUG - 2023-04-26 12:16:29 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-04-26 12:16:29 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-26 12:16:29 --> Model Class Initialized
DEBUG - 2023-04-26 12:16:29 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-26 12:16:29 --> Model Class Initialized
INFO - 2023-04-26 12:16:29 --> Model Class Initialized
INFO - 2023-04-26 12:16:29 --> Final output sent to browser
DEBUG - 2023-04-26 12:16:29 --> Total execution time: 0.0203
ERROR - 2023-04-26 12:16:31 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-26 12:16:31 --> Config Class Initialized
INFO - 2023-04-26 12:16:31 --> Hooks Class Initialized
DEBUG - 2023-04-26 12:16:31 --> UTF-8 Support Enabled
INFO - 2023-04-26 12:16:31 --> Utf8 Class Initialized
INFO - 2023-04-26 12:16:31 --> URI Class Initialized
INFO - 2023-04-26 12:16:31 --> Router Class Initialized
INFO - 2023-04-26 12:16:31 --> Output Class Initialized
INFO - 2023-04-26 12:16:31 --> Security Class Initialized
DEBUG - 2023-04-26 12:16:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-26 12:16:31 --> Input Class Initialized
INFO - 2023-04-26 12:16:31 --> Language Class Initialized
INFO - 2023-04-26 12:16:31 --> Loader Class Initialized
INFO - 2023-04-26 12:16:31 --> Helper loaded: url_helper
INFO - 2023-04-26 12:16:31 --> Helper loaded: file_helper
INFO - 2023-04-26 12:16:31 --> Helper loaded: html_helper
INFO - 2023-04-26 12:16:31 --> Helper loaded: text_helper
INFO - 2023-04-26 12:16:31 --> Helper loaded: form_helper
INFO - 2023-04-26 12:16:31 --> Helper loaded: lang_helper
INFO - 2023-04-26 12:16:31 --> Helper loaded: security_helper
INFO - 2023-04-26 12:16:31 --> Helper loaded: cookie_helper
INFO - 2023-04-26 12:16:31 --> Database Driver Class Initialized
INFO - 2023-04-26 12:16:31 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-26 12:16:31 --> Parser Class Initialized
INFO - 2023-04-26 12:16:31 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-26 12:16:31 --> Pagination Class Initialized
INFO - 2023-04-26 12:16:31 --> Form Validation Class Initialized
INFO - 2023-04-26 12:16:31 --> Controller Class Initialized
INFO - 2023-04-26 12:16:31 --> Model Class Initialized
DEBUG - 2023-04-26 12:16:31 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-04-26 12:16:31 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-26 12:16:31 --> Model Class Initialized
DEBUG - 2023-04-26 12:16:31 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-26 12:16:31 --> Model Class Initialized
INFO - 2023-04-26 12:16:31 --> Final output sent to browser
DEBUG - 2023-04-26 12:16:31 --> Total execution time: 0.0172
ERROR - 2023-04-26 12:22:59 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-26 12:22:59 --> Config Class Initialized
INFO - 2023-04-26 12:22:59 --> Hooks Class Initialized
DEBUG - 2023-04-26 12:22:59 --> UTF-8 Support Enabled
INFO - 2023-04-26 12:22:59 --> Utf8 Class Initialized
INFO - 2023-04-26 12:22:59 --> URI Class Initialized
DEBUG - 2023-04-26 12:22:59 --> No URI present. Default controller set.
INFO - 2023-04-26 12:22:59 --> Router Class Initialized
INFO - 2023-04-26 12:22:59 --> Output Class Initialized
INFO - 2023-04-26 12:22:59 --> Security Class Initialized
DEBUG - 2023-04-26 12:22:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-26 12:22:59 --> Input Class Initialized
INFO - 2023-04-26 12:22:59 --> Language Class Initialized
INFO - 2023-04-26 12:22:59 --> Loader Class Initialized
INFO - 2023-04-26 12:22:59 --> Helper loaded: url_helper
INFO - 2023-04-26 12:22:59 --> Helper loaded: file_helper
INFO - 2023-04-26 12:22:59 --> Helper loaded: html_helper
INFO - 2023-04-26 12:22:59 --> Helper loaded: text_helper
INFO - 2023-04-26 12:22:59 --> Helper loaded: form_helper
INFO - 2023-04-26 12:22:59 --> Helper loaded: lang_helper
INFO - 2023-04-26 12:22:59 --> Helper loaded: security_helper
INFO - 2023-04-26 12:22:59 --> Helper loaded: cookie_helper
INFO - 2023-04-26 12:22:59 --> Database Driver Class Initialized
INFO - 2023-04-26 12:22:59 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-26 12:22:59 --> Parser Class Initialized
INFO - 2023-04-26 12:22:59 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-26 12:22:59 --> Pagination Class Initialized
INFO - 2023-04-26 12:22:59 --> Form Validation Class Initialized
INFO - 2023-04-26 12:22:59 --> Controller Class Initialized
INFO - 2023-04-26 12:22:59 --> Model Class Initialized
DEBUG - 2023-04-26 12:22:59 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-26 12:22:59 --> Model Class Initialized
DEBUG - 2023-04-26 12:22:59 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-26 12:22:59 --> Model Class Initialized
INFO - 2023-04-26 12:22:59 --> Model Class Initialized
INFO - 2023-04-26 12:22:59 --> Model Class Initialized
INFO - 2023-04-26 12:22:59 --> Model Class Initialized
DEBUG - 2023-04-26 12:22:59 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-04-26 12:22:59 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-26 12:22:59 --> Model Class Initialized
INFO - 2023-04-26 12:22:59 --> Model Class Initialized
INFO - 2023-04-26 12:23:00 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-04-26 12:23:00 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-04-26 12:23:00 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-04-26 12:23:00 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-04-26 12:23:00 --> Model Class Initialized
INFO - 2023-04-26 12:23:00 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-04-26 12:23:00 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-04-26 12:23:00 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-04-26 12:23:00 --> Final output sent to browser
DEBUG - 2023-04-26 12:23:00 --> Total execution time: 0.1915
ERROR - 2023-04-26 15:53:01 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-26 15:53:01 --> Config Class Initialized
INFO - 2023-04-26 15:53:01 --> Hooks Class Initialized
DEBUG - 2023-04-26 15:53:01 --> UTF-8 Support Enabled
INFO - 2023-04-26 15:53:01 --> Utf8 Class Initialized
INFO - 2023-04-26 15:53:01 --> URI Class Initialized
DEBUG - 2023-04-26 15:53:01 --> No URI present. Default controller set.
INFO - 2023-04-26 15:53:01 --> Router Class Initialized
INFO - 2023-04-26 15:53:01 --> Output Class Initialized
INFO - 2023-04-26 15:53:01 --> Security Class Initialized
DEBUG - 2023-04-26 15:53:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-26 15:53:01 --> Input Class Initialized
INFO - 2023-04-26 15:53:01 --> Language Class Initialized
INFO - 2023-04-26 15:53:01 --> Loader Class Initialized
INFO - 2023-04-26 15:53:01 --> Helper loaded: url_helper
INFO - 2023-04-26 15:53:01 --> Helper loaded: file_helper
INFO - 2023-04-26 15:53:01 --> Helper loaded: html_helper
INFO - 2023-04-26 15:53:01 --> Helper loaded: text_helper
INFO - 2023-04-26 15:53:01 --> Helper loaded: form_helper
INFO - 2023-04-26 15:53:01 --> Helper loaded: lang_helper
INFO - 2023-04-26 15:53:01 --> Helper loaded: security_helper
INFO - 2023-04-26 15:53:01 --> Helper loaded: cookie_helper
INFO - 2023-04-26 15:53:01 --> Database Driver Class Initialized
INFO - 2023-04-26 15:53:01 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-26 15:53:01 --> Parser Class Initialized
INFO - 2023-04-26 15:53:01 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-26 15:53:01 --> Pagination Class Initialized
INFO - 2023-04-26 15:53:01 --> Form Validation Class Initialized
INFO - 2023-04-26 15:53:01 --> Controller Class Initialized
INFO - 2023-04-26 15:53:01 --> Model Class Initialized
DEBUG - 2023-04-26 15:53:01 --> Session class already loaded. Second attempt ignored.
ERROR - 2023-04-26 15:53:02 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-26 15:53:02 --> Config Class Initialized
INFO - 2023-04-26 15:53:02 --> Hooks Class Initialized
DEBUG - 2023-04-26 15:53:02 --> UTF-8 Support Enabled
INFO - 2023-04-26 15:53:02 --> Utf8 Class Initialized
INFO - 2023-04-26 15:53:02 --> URI Class Initialized
INFO - 2023-04-26 15:53:02 --> Router Class Initialized
INFO - 2023-04-26 15:53:02 --> Output Class Initialized
INFO - 2023-04-26 15:53:02 --> Security Class Initialized
DEBUG - 2023-04-26 15:53:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-26 15:53:02 --> Input Class Initialized
INFO - 2023-04-26 15:53:02 --> Language Class Initialized
INFO - 2023-04-26 15:53:02 --> Loader Class Initialized
INFO - 2023-04-26 15:53:02 --> Helper loaded: url_helper
INFO - 2023-04-26 15:53:02 --> Helper loaded: file_helper
INFO - 2023-04-26 15:53:02 --> Helper loaded: html_helper
INFO - 2023-04-26 15:53:02 --> Helper loaded: text_helper
INFO - 2023-04-26 15:53:02 --> Helper loaded: form_helper
INFO - 2023-04-26 15:53:02 --> Helper loaded: lang_helper
INFO - 2023-04-26 15:53:02 --> Helper loaded: security_helper
INFO - 2023-04-26 15:53:02 --> Helper loaded: cookie_helper
INFO - 2023-04-26 15:53:02 --> Database Driver Class Initialized
INFO - 2023-04-26 15:53:02 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-26 15:53:02 --> Parser Class Initialized
INFO - 2023-04-26 15:53:02 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-26 15:53:02 --> Pagination Class Initialized
INFO - 2023-04-26 15:53:02 --> Form Validation Class Initialized
INFO - 2023-04-26 15:53:02 --> Controller Class Initialized
INFO - 2023-04-26 15:53:02 --> Model Class Initialized
DEBUG - 2023-04-26 15:53:02 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-26 15:53:02 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2023-04-26 15:53:02 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-04-26 15:53:02 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-04-26 15:53:02 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-04-26 15:53:02 --> Model Class Initialized
INFO - 2023-04-26 15:53:02 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-04-26 15:53:02 --> Final output sent to browser
DEBUG - 2023-04-26 15:53:02 --> Total execution time: 0.0329
ERROR - 2023-04-26 15:53:17 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-26 15:53:17 --> Config Class Initialized
INFO - 2023-04-26 15:53:17 --> Hooks Class Initialized
DEBUG - 2023-04-26 15:53:17 --> UTF-8 Support Enabled
INFO - 2023-04-26 15:53:17 --> Utf8 Class Initialized
INFO - 2023-04-26 15:53:17 --> URI Class Initialized
INFO - 2023-04-26 15:53:17 --> Router Class Initialized
INFO - 2023-04-26 15:53:17 --> Output Class Initialized
INFO - 2023-04-26 15:53:17 --> Security Class Initialized
DEBUG - 2023-04-26 15:53:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-26 15:53:17 --> Input Class Initialized
INFO - 2023-04-26 15:53:17 --> Language Class Initialized
INFO - 2023-04-26 15:53:17 --> Loader Class Initialized
INFO - 2023-04-26 15:53:17 --> Helper loaded: url_helper
INFO - 2023-04-26 15:53:17 --> Helper loaded: file_helper
INFO - 2023-04-26 15:53:17 --> Helper loaded: html_helper
INFO - 2023-04-26 15:53:17 --> Helper loaded: text_helper
INFO - 2023-04-26 15:53:17 --> Helper loaded: form_helper
INFO - 2023-04-26 15:53:17 --> Helper loaded: lang_helper
INFO - 2023-04-26 15:53:17 --> Helper loaded: security_helper
INFO - 2023-04-26 15:53:17 --> Helper loaded: cookie_helper
INFO - 2023-04-26 15:53:17 --> Database Driver Class Initialized
INFO - 2023-04-26 15:53:17 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-26 15:53:17 --> Parser Class Initialized
INFO - 2023-04-26 15:53:17 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-26 15:53:17 --> Pagination Class Initialized
INFO - 2023-04-26 15:53:17 --> Form Validation Class Initialized
INFO - 2023-04-26 15:53:17 --> Controller Class Initialized
INFO - 2023-04-26 15:53:17 --> Model Class Initialized
DEBUG - 2023-04-26 15:53:17 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-26 15:53:17 --> Model Class Initialized
INFO - 2023-04-26 15:53:17 --> Final output sent to browser
DEBUG - 2023-04-26 15:53:17 --> Total execution time: 0.0210
ERROR - 2023-04-26 15:53:18 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-26 15:53:18 --> Config Class Initialized
INFO - 2023-04-26 15:53:18 --> Hooks Class Initialized
DEBUG - 2023-04-26 15:53:18 --> UTF-8 Support Enabled
INFO - 2023-04-26 15:53:18 --> Utf8 Class Initialized
INFO - 2023-04-26 15:53:18 --> URI Class Initialized
DEBUG - 2023-04-26 15:53:18 --> No URI present. Default controller set.
INFO - 2023-04-26 15:53:18 --> Router Class Initialized
INFO - 2023-04-26 15:53:18 --> Output Class Initialized
INFO - 2023-04-26 15:53:18 --> Security Class Initialized
DEBUG - 2023-04-26 15:53:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-26 15:53:18 --> Input Class Initialized
INFO - 2023-04-26 15:53:18 --> Language Class Initialized
INFO - 2023-04-26 15:53:18 --> Loader Class Initialized
INFO - 2023-04-26 15:53:18 --> Helper loaded: url_helper
INFO - 2023-04-26 15:53:18 --> Helper loaded: file_helper
INFO - 2023-04-26 15:53:18 --> Helper loaded: html_helper
INFO - 2023-04-26 15:53:18 --> Helper loaded: text_helper
INFO - 2023-04-26 15:53:18 --> Helper loaded: form_helper
INFO - 2023-04-26 15:53:18 --> Helper loaded: lang_helper
INFO - 2023-04-26 15:53:18 --> Helper loaded: security_helper
INFO - 2023-04-26 15:53:18 --> Helper loaded: cookie_helper
INFO - 2023-04-26 15:53:18 --> Database Driver Class Initialized
INFO - 2023-04-26 15:53:18 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-26 15:53:18 --> Parser Class Initialized
INFO - 2023-04-26 15:53:18 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-26 15:53:18 --> Pagination Class Initialized
INFO - 2023-04-26 15:53:18 --> Form Validation Class Initialized
INFO - 2023-04-26 15:53:18 --> Controller Class Initialized
INFO - 2023-04-26 15:53:18 --> Model Class Initialized
DEBUG - 2023-04-26 15:53:18 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-26 15:53:18 --> Model Class Initialized
DEBUG - 2023-04-26 15:53:18 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-26 15:53:18 --> Model Class Initialized
INFO - 2023-04-26 15:53:18 --> Model Class Initialized
INFO - 2023-04-26 15:53:18 --> Model Class Initialized
INFO - 2023-04-26 15:53:18 --> Model Class Initialized
DEBUG - 2023-04-26 15:53:18 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-04-26 15:53:18 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-26 15:53:18 --> Model Class Initialized
INFO - 2023-04-26 15:53:18 --> Model Class Initialized
INFO - 2023-04-26 15:53:18 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-04-26 15:53:18 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-04-26 15:53:18 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-04-26 15:53:18 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-04-26 15:53:18 --> Model Class Initialized
INFO - 2023-04-26 15:53:18 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-04-26 15:53:18 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-04-26 15:53:18 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-04-26 15:53:18 --> Final output sent to browser
DEBUG - 2023-04-26 15:53:18 --> Total execution time: 0.2047
ERROR - 2023-04-26 15:53:19 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-26 15:53:19 --> Config Class Initialized
INFO - 2023-04-26 15:53:19 --> Hooks Class Initialized
DEBUG - 2023-04-26 15:53:19 --> UTF-8 Support Enabled
INFO - 2023-04-26 15:53:19 --> Utf8 Class Initialized
INFO - 2023-04-26 15:53:19 --> URI Class Initialized
INFO - 2023-04-26 15:53:19 --> Router Class Initialized
INFO - 2023-04-26 15:53:19 --> Output Class Initialized
INFO - 2023-04-26 15:53:19 --> Security Class Initialized
DEBUG - 2023-04-26 15:53:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-26 15:53:19 --> Input Class Initialized
INFO - 2023-04-26 15:53:19 --> Language Class Initialized
INFO - 2023-04-26 15:53:19 --> Loader Class Initialized
INFO - 2023-04-26 15:53:19 --> Helper loaded: url_helper
INFO - 2023-04-26 15:53:19 --> Helper loaded: file_helper
INFO - 2023-04-26 15:53:19 --> Helper loaded: html_helper
INFO - 2023-04-26 15:53:19 --> Helper loaded: text_helper
INFO - 2023-04-26 15:53:19 --> Helper loaded: form_helper
INFO - 2023-04-26 15:53:19 --> Helper loaded: lang_helper
INFO - 2023-04-26 15:53:19 --> Helper loaded: security_helper
INFO - 2023-04-26 15:53:19 --> Helper loaded: cookie_helper
INFO - 2023-04-26 15:53:19 --> Database Driver Class Initialized
INFO - 2023-04-26 15:53:19 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-26 15:53:19 --> Parser Class Initialized
INFO - 2023-04-26 15:53:19 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-26 15:53:19 --> Pagination Class Initialized
INFO - 2023-04-26 15:53:19 --> Form Validation Class Initialized
INFO - 2023-04-26 15:53:19 --> Controller Class Initialized
DEBUG - 2023-04-26 15:53:19 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-04-26 15:53:19 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-26 15:53:19 --> Model Class Initialized
INFO - 2023-04-26 15:53:19 --> Final output sent to browser
DEBUG - 2023-04-26 15:53:19 --> Total execution time: 0.0128
ERROR - 2023-04-26 15:53:45 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-26 15:53:45 --> Config Class Initialized
INFO - 2023-04-26 15:53:45 --> Hooks Class Initialized
DEBUG - 2023-04-26 15:53:45 --> UTF-8 Support Enabled
INFO - 2023-04-26 15:53:45 --> Utf8 Class Initialized
INFO - 2023-04-26 15:53:45 --> URI Class Initialized
INFO - 2023-04-26 15:53:45 --> Router Class Initialized
INFO - 2023-04-26 15:53:45 --> Output Class Initialized
INFO - 2023-04-26 15:53:45 --> Security Class Initialized
DEBUG - 2023-04-26 15:53:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-26 15:53:45 --> Input Class Initialized
INFO - 2023-04-26 15:53:45 --> Language Class Initialized
INFO - 2023-04-26 15:53:45 --> Loader Class Initialized
INFO - 2023-04-26 15:53:45 --> Helper loaded: url_helper
INFO - 2023-04-26 15:53:45 --> Helper loaded: file_helper
INFO - 2023-04-26 15:53:45 --> Helper loaded: html_helper
INFO - 2023-04-26 15:53:45 --> Helper loaded: text_helper
INFO - 2023-04-26 15:53:45 --> Helper loaded: form_helper
INFO - 2023-04-26 15:53:45 --> Helper loaded: lang_helper
INFO - 2023-04-26 15:53:45 --> Helper loaded: security_helper
INFO - 2023-04-26 15:53:45 --> Helper loaded: cookie_helper
INFO - 2023-04-26 15:53:45 --> Database Driver Class Initialized
INFO - 2023-04-26 15:53:45 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-26 15:53:45 --> Parser Class Initialized
INFO - 2023-04-26 15:53:45 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-26 15:53:45 --> Pagination Class Initialized
INFO - 2023-04-26 15:53:45 --> Form Validation Class Initialized
INFO - 2023-04-26 15:53:45 --> Controller Class Initialized
INFO - 2023-04-26 15:53:45 --> Model Class Initialized
DEBUG - 2023-04-26 15:53:45 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-04-26 15:53:45 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-26 15:53:45 --> Model Class Initialized
INFO - 2023-04-26 15:53:45 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/stockrequest/inventory.php
DEBUG - 2023-04-26 15:53:45 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-04-26 15:53:45 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-04-26 15:53:45 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-04-26 15:53:45 --> Model Class Initialized
INFO - 2023-04-26 15:53:45 --> Model Class Initialized
INFO - 2023-04-26 15:53:45 --> Model Class Initialized
INFO - 2023-04-26 15:53:45 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-04-26 15:53:45 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-04-26 15:53:45 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-04-26 15:53:45 --> Final output sent to browser
DEBUG - 2023-04-26 15:53:45 --> Total execution time: 0.1446
ERROR - 2023-04-26 15:53:45 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-26 15:53:45 --> Config Class Initialized
INFO - 2023-04-26 15:53:45 --> Hooks Class Initialized
DEBUG - 2023-04-26 15:53:45 --> UTF-8 Support Enabled
INFO - 2023-04-26 15:53:45 --> Utf8 Class Initialized
INFO - 2023-04-26 15:53:45 --> URI Class Initialized
INFO - 2023-04-26 15:53:45 --> Router Class Initialized
INFO - 2023-04-26 15:53:45 --> Output Class Initialized
INFO - 2023-04-26 15:53:45 --> Security Class Initialized
DEBUG - 2023-04-26 15:53:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-26 15:53:45 --> Input Class Initialized
INFO - 2023-04-26 15:53:45 --> Language Class Initialized
INFO - 2023-04-26 15:53:45 --> Loader Class Initialized
INFO - 2023-04-26 15:53:45 --> Helper loaded: url_helper
INFO - 2023-04-26 15:53:45 --> Helper loaded: file_helper
INFO - 2023-04-26 15:53:45 --> Helper loaded: html_helper
INFO - 2023-04-26 15:53:45 --> Helper loaded: text_helper
INFO - 2023-04-26 15:53:45 --> Helper loaded: form_helper
INFO - 2023-04-26 15:53:45 --> Helper loaded: lang_helper
INFO - 2023-04-26 15:53:45 --> Helper loaded: security_helper
INFO - 2023-04-26 15:53:45 --> Helper loaded: cookie_helper
INFO - 2023-04-26 15:53:45 --> Database Driver Class Initialized
INFO - 2023-04-26 15:53:45 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-26 15:53:45 --> Parser Class Initialized
INFO - 2023-04-26 15:53:45 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-26 15:53:45 --> Pagination Class Initialized
INFO - 2023-04-26 15:53:45 --> Form Validation Class Initialized
INFO - 2023-04-26 15:53:45 --> Controller Class Initialized
INFO - 2023-04-26 15:53:45 --> Model Class Initialized
DEBUG - 2023-04-26 15:53:45 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-04-26 15:53:45 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-26 15:53:45 --> Model Class Initialized
INFO - 2023-04-26 15:53:45 --> Final output sent to browser
DEBUG - 2023-04-26 15:53:45 --> Total execution time: 0.0244
ERROR - 2023-04-26 15:53:48 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-26 15:53:48 --> Config Class Initialized
INFO - 2023-04-26 15:53:48 --> Hooks Class Initialized
DEBUG - 2023-04-26 15:53:48 --> UTF-8 Support Enabled
INFO - 2023-04-26 15:53:48 --> Utf8 Class Initialized
INFO - 2023-04-26 15:53:48 --> URI Class Initialized
INFO - 2023-04-26 15:53:48 --> Router Class Initialized
INFO - 2023-04-26 15:53:48 --> Output Class Initialized
INFO - 2023-04-26 15:53:48 --> Security Class Initialized
DEBUG - 2023-04-26 15:53:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-26 15:53:48 --> Input Class Initialized
INFO - 2023-04-26 15:53:48 --> Language Class Initialized
INFO - 2023-04-26 15:53:48 --> Loader Class Initialized
INFO - 2023-04-26 15:53:48 --> Helper loaded: url_helper
INFO - 2023-04-26 15:53:48 --> Helper loaded: file_helper
INFO - 2023-04-26 15:53:48 --> Helper loaded: html_helper
INFO - 2023-04-26 15:53:48 --> Helper loaded: text_helper
INFO - 2023-04-26 15:53:48 --> Helper loaded: form_helper
INFO - 2023-04-26 15:53:48 --> Helper loaded: lang_helper
INFO - 2023-04-26 15:53:48 --> Helper loaded: security_helper
INFO - 2023-04-26 15:53:48 --> Helper loaded: cookie_helper
INFO - 2023-04-26 15:53:48 --> Database Driver Class Initialized
INFO - 2023-04-26 15:53:48 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-26 15:53:48 --> Parser Class Initialized
INFO - 2023-04-26 15:53:48 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-26 15:53:48 --> Pagination Class Initialized
INFO - 2023-04-26 15:53:48 --> Form Validation Class Initialized
INFO - 2023-04-26 15:53:48 --> Controller Class Initialized
INFO - 2023-04-26 15:53:48 --> Model Class Initialized
DEBUG - 2023-04-26 15:53:48 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-04-26 15:53:48 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-26 15:53:48 --> Model Class Initialized
INFO - 2023-04-26 15:53:48 --> Final output sent to browser
DEBUG - 2023-04-26 15:53:48 --> Total execution time: 0.0205
ERROR - 2023-04-26 15:54:07 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-26 15:54:07 --> Config Class Initialized
INFO - 2023-04-26 15:54:07 --> Hooks Class Initialized
DEBUG - 2023-04-26 15:54:07 --> UTF-8 Support Enabled
INFO - 2023-04-26 15:54:07 --> Utf8 Class Initialized
INFO - 2023-04-26 15:54:07 --> URI Class Initialized
INFO - 2023-04-26 15:54:07 --> Router Class Initialized
INFO - 2023-04-26 15:54:07 --> Output Class Initialized
INFO - 2023-04-26 15:54:07 --> Security Class Initialized
DEBUG - 2023-04-26 15:54:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-26 15:54:07 --> Input Class Initialized
INFO - 2023-04-26 15:54:07 --> Language Class Initialized
INFO - 2023-04-26 15:54:07 --> Loader Class Initialized
INFO - 2023-04-26 15:54:07 --> Helper loaded: url_helper
INFO - 2023-04-26 15:54:07 --> Helper loaded: file_helper
INFO - 2023-04-26 15:54:07 --> Helper loaded: html_helper
INFO - 2023-04-26 15:54:07 --> Helper loaded: text_helper
INFO - 2023-04-26 15:54:07 --> Helper loaded: form_helper
INFO - 2023-04-26 15:54:07 --> Helper loaded: lang_helper
INFO - 2023-04-26 15:54:07 --> Helper loaded: security_helper
INFO - 2023-04-26 15:54:07 --> Helper loaded: cookie_helper
INFO - 2023-04-26 15:54:07 --> Database Driver Class Initialized
INFO - 2023-04-26 15:54:07 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-26 15:54:07 --> Parser Class Initialized
INFO - 2023-04-26 15:54:07 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-26 15:54:07 --> Pagination Class Initialized
INFO - 2023-04-26 15:54:07 --> Form Validation Class Initialized
INFO - 2023-04-26 15:54:07 --> Controller Class Initialized
INFO - 2023-04-26 15:54:07 --> Model Class Initialized
DEBUG - 2023-04-26 15:54:07 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-04-26 15:54:07 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-26 15:54:07 --> Model Class Initialized
DEBUG - 2023-04-26 15:54:07 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-26 15:54:07 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/stockrequest/add_stockrequest_form.php
DEBUG - 2023-04-26 15:54:07 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-04-26 15:54:07 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-04-26 15:54:07 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-04-26 15:54:07 --> Model Class Initialized
INFO - 2023-04-26 15:54:07 --> Model Class Initialized
INFO - 2023-04-26 15:54:07 --> Model Class Initialized
INFO - 2023-04-26 15:54:07 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-04-26 15:54:07 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-04-26 15:54:07 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-04-26 15:54:07 --> Final output sent to browser
DEBUG - 2023-04-26 15:54:07 --> Total execution time: 0.1536
ERROR - 2023-04-26 15:54:11 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-26 15:54:11 --> Config Class Initialized
INFO - 2023-04-26 15:54:11 --> Hooks Class Initialized
DEBUG - 2023-04-26 15:54:11 --> UTF-8 Support Enabled
INFO - 2023-04-26 15:54:11 --> Utf8 Class Initialized
INFO - 2023-04-26 15:54:11 --> URI Class Initialized
INFO - 2023-04-26 15:54:11 --> Router Class Initialized
INFO - 2023-04-26 15:54:11 --> Output Class Initialized
INFO - 2023-04-26 15:54:11 --> Security Class Initialized
DEBUG - 2023-04-26 15:54:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-26 15:54:11 --> Input Class Initialized
INFO - 2023-04-26 15:54:11 --> Language Class Initialized
INFO - 2023-04-26 15:54:11 --> Loader Class Initialized
INFO - 2023-04-26 15:54:11 --> Helper loaded: url_helper
INFO - 2023-04-26 15:54:11 --> Helper loaded: file_helper
INFO - 2023-04-26 15:54:11 --> Helper loaded: html_helper
INFO - 2023-04-26 15:54:11 --> Helper loaded: text_helper
INFO - 2023-04-26 15:54:11 --> Helper loaded: form_helper
INFO - 2023-04-26 15:54:11 --> Helper loaded: lang_helper
INFO - 2023-04-26 15:54:11 --> Helper loaded: security_helper
INFO - 2023-04-26 15:54:11 --> Helper loaded: cookie_helper
INFO - 2023-04-26 15:54:11 --> Database Driver Class Initialized
INFO - 2023-04-26 15:54:11 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-26 15:54:11 --> Parser Class Initialized
INFO - 2023-04-26 15:54:11 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-26 15:54:11 --> Pagination Class Initialized
INFO - 2023-04-26 15:54:11 --> Form Validation Class Initialized
INFO - 2023-04-26 15:54:11 --> Controller Class Initialized
INFO - 2023-04-26 15:54:11 --> Model Class Initialized
INFO - 2023-04-26 15:54:11 --> Final output sent to browser
DEBUG - 2023-04-26 15:54:11 --> Total execution time: 0.0174
ERROR - 2023-04-26 15:54:11 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-26 15:54:11 --> Config Class Initialized
INFO - 2023-04-26 15:54:11 --> Hooks Class Initialized
DEBUG - 2023-04-26 15:54:11 --> UTF-8 Support Enabled
INFO - 2023-04-26 15:54:11 --> Utf8 Class Initialized
INFO - 2023-04-26 15:54:11 --> URI Class Initialized
INFO - 2023-04-26 15:54:11 --> Router Class Initialized
INFO - 2023-04-26 15:54:11 --> Output Class Initialized
INFO - 2023-04-26 15:54:11 --> Security Class Initialized
DEBUG - 2023-04-26 15:54:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-26 15:54:11 --> Input Class Initialized
INFO - 2023-04-26 15:54:11 --> Language Class Initialized
INFO - 2023-04-26 15:54:11 --> Loader Class Initialized
INFO - 2023-04-26 15:54:11 --> Helper loaded: url_helper
INFO - 2023-04-26 15:54:11 --> Helper loaded: file_helper
INFO - 2023-04-26 15:54:11 --> Helper loaded: html_helper
INFO - 2023-04-26 15:54:11 --> Helper loaded: text_helper
INFO - 2023-04-26 15:54:11 --> Helper loaded: form_helper
INFO - 2023-04-26 15:54:11 --> Helper loaded: lang_helper
INFO - 2023-04-26 15:54:11 --> Helper loaded: security_helper
INFO - 2023-04-26 15:54:11 --> Helper loaded: cookie_helper
INFO - 2023-04-26 15:54:11 --> Database Driver Class Initialized
INFO - 2023-04-26 15:54:11 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-26 15:54:11 --> Parser Class Initialized
INFO - 2023-04-26 15:54:11 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-26 15:54:11 --> Pagination Class Initialized
INFO - 2023-04-26 15:54:11 --> Form Validation Class Initialized
INFO - 2023-04-26 15:54:11 --> Controller Class Initialized
INFO - 2023-04-26 15:54:11 --> Model Class Initialized
INFO - 2023-04-26 15:54:11 --> Final output sent to browser
DEBUG - 2023-04-26 15:54:11 --> Total execution time: 0.0127
ERROR - 2023-04-26 15:54:11 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-26 15:54:11 --> Config Class Initialized
INFO - 2023-04-26 15:54:11 --> Hooks Class Initialized
DEBUG - 2023-04-26 15:54:11 --> UTF-8 Support Enabled
INFO - 2023-04-26 15:54:11 --> Utf8 Class Initialized
INFO - 2023-04-26 15:54:11 --> URI Class Initialized
INFO - 2023-04-26 15:54:11 --> Router Class Initialized
INFO - 2023-04-26 15:54:11 --> Output Class Initialized
INFO - 2023-04-26 15:54:11 --> Security Class Initialized
DEBUG - 2023-04-26 15:54:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-26 15:54:11 --> Input Class Initialized
INFO - 2023-04-26 15:54:11 --> Language Class Initialized
INFO - 2023-04-26 15:54:11 --> Loader Class Initialized
INFO - 2023-04-26 15:54:11 --> Helper loaded: url_helper
INFO - 2023-04-26 15:54:11 --> Helper loaded: file_helper
INFO - 2023-04-26 15:54:11 --> Helper loaded: html_helper
INFO - 2023-04-26 15:54:11 --> Helper loaded: text_helper
INFO - 2023-04-26 15:54:11 --> Helper loaded: form_helper
INFO - 2023-04-26 15:54:11 --> Helper loaded: lang_helper
INFO - 2023-04-26 15:54:11 --> Helper loaded: security_helper
INFO - 2023-04-26 15:54:11 --> Helper loaded: cookie_helper
INFO - 2023-04-26 15:54:11 --> Database Driver Class Initialized
INFO - 2023-04-26 15:54:11 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-26 15:54:11 --> Parser Class Initialized
INFO - 2023-04-26 15:54:11 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-26 15:54:11 --> Pagination Class Initialized
INFO - 2023-04-26 15:54:11 --> Form Validation Class Initialized
INFO - 2023-04-26 15:54:11 --> Controller Class Initialized
INFO - 2023-04-26 15:54:11 --> Model Class Initialized
INFO - 2023-04-26 15:54:11 --> Final output sent to browser
DEBUG - 2023-04-26 15:54:11 --> Total execution time: 0.0125
ERROR - 2023-04-26 15:54:12 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-26 15:54:12 --> Config Class Initialized
INFO - 2023-04-26 15:54:12 --> Hooks Class Initialized
DEBUG - 2023-04-26 15:54:12 --> UTF-8 Support Enabled
INFO - 2023-04-26 15:54:12 --> Utf8 Class Initialized
INFO - 2023-04-26 15:54:12 --> URI Class Initialized
INFO - 2023-04-26 15:54:12 --> Router Class Initialized
INFO - 2023-04-26 15:54:12 --> Output Class Initialized
INFO - 2023-04-26 15:54:12 --> Security Class Initialized
DEBUG - 2023-04-26 15:54:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-26 15:54:12 --> Input Class Initialized
INFO - 2023-04-26 15:54:12 --> Language Class Initialized
INFO - 2023-04-26 15:54:12 --> Loader Class Initialized
INFO - 2023-04-26 15:54:12 --> Helper loaded: url_helper
INFO - 2023-04-26 15:54:12 --> Helper loaded: file_helper
INFO - 2023-04-26 15:54:12 --> Helper loaded: html_helper
INFO - 2023-04-26 15:54:12 --> Helper loaded: text_helper
INFO - 2023-04-26 15:54:12 --> Helper loaded: form_helper
INFO - 2023-04-26 15:54:12 --> Helper loaded: lang_helper
INFO - 2023-04-26 15:54:12 --> Helper loaded: security_helper
INFO - 2023-04-26 15:54:12 --> Helper loaded: cookie_helper
INFO - 2023-04-26 15:54:12 --> Database Driver Class Initialized
INFO - 2023-04-26 15:54:12 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-26 15:54:12 --> Parser Class Initialized
INFO - 2023-04-26 15:54:12 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-26 15:54:12 --> Pagination Class Initialized
INFO - 2023-04-26 15:54:12 --> Form Validation Class Initialized
INFO - 2023-04-26 15:54:12 --> Controller Class Initialized
INFO - 2023-04-26 15:54:12 --> Model Class Initialized
INFO - 2023-04-26 15:54:12 --> Final output sent to browser
DEBUG - 2023-04-26 15:54:12 --> Total execution time: 0.0157
ERROR - 2023-04-26 15:54:15 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-26 15:54:15 --> Config Class Initialized
INFO - 2023-04-26 15:54:15 --> Hooks Class Initialized
DEBUG - 2023-04-26 15:54:15 --> UTF-8 Support Enabled
INFO - 2023-04-26 15:54:15 --> Utf8 Class Initialized
INFO - 2023-04-26 15:54:15 --> URI Class Initialized
INFO - 2023-04-26 15:54:15 --> Router Class Initialized
INFO - 2023-04-26 15:54:15 --> Output Class Initialized
INFO - 2023-04-26 15:54:15 --> Security Class Initialized
DEBUG - 2023-04-26 15:54:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-26 15:54:15 --> Input Class Initialized
INFO - 2023-04-26 15:54:15 --> Language Class Initialized
INFO - 2023-04-26 15:54:15 --> Loader Class Initialized
INFO - 2023-04-26 15:54:15 --> Helper loaded: url_helper
INFO - 2023-04-26 15:54:15 --> Helper loaded: file_helper
INFO - 2023-04-26 15:54:15 --> Helper loaded: html_helper
INFO - 2023-04-26 15:54:15 --> Helper loaded: text_helper
INFO - 2023-04-26 15:54:15 --> Helper loaded: form_helper
INFO - 2023-04-26 15:54:15 --> Helper loaded: lang_helper
INFO - 2023-04-26 15:54:15 --> Helper loaded: security_helper
INFO - 2023-04-26 15:54:15 --> Helper loaded: cookie_helper
INFO - 2023-04-26 15:54:15 --> Database Driver Class Initialized
INFO - 2023-04-26 15:54:15 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-26 15:54:15 --> Parser Class Initialized
INFO - 2023-04-26 15:54:15 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-26 15:54:15 --> Pagination Class Initialized
INFO - 2023-04-26 15:54:15 --> Form Validation Class Initialized
INFO - 2023-04-26 15:54:15 --> Controller Class Initialized
INFO - 2023-04-26 15:54:15 --> Model Class Initialized
DEBUG - 2023-04-26 15:54:15 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-04-26 15:54:15 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-26 15:54:15 --> Model Class Initialized
DEBUG - 2023-04-26 15:54:15 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-26 15:54:15 --> Model Class Initialized
INFO - 2023-04-26 15:54:15 --> Final output sent to browser
DEBUG - 2023-04-26 15:54:15 --> Total execution time: 0.0181
ERROR - 2023-04-26 15:54:15 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-26 15:54:15 --> Config Class Initialized
INFO - 2023-04-26 15:54:15 --> Hooks Class Initialized
DEBUG - 2023-04-26 15:54:15 --> UTF-8 Support Enabled
INFO - 2023-04-26 15:54:15 --> Utf8 Class Initialized
INFO - 2023-04-26 15:54:15 --> URI Class Initialized
INFO - 2023-04-26 15:54:15 --> Router Class Initialized
INFO - 2023-04-26 15:54:15 --> Output Class Initialized
INFO - 2023-04-26 15:54:15 --> Security Class Initialized
DEBUG - 2023-04-26 15:54:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-26 15:54:15 --> Input Class Initialized
INFO - 2023-04-26 15:54:15 --> Language Class Initialized
INFO - 2023-04-26 15:54:15 --> Loader Class Initialized
INFO - 2023-04-26 15:54:15 --> Helper loaded: url_helper
INFO - 2023-04-26 15:54:15 --> Helper loaded: file_helper
INFO - 2023-04-26 15:54:15 --> Helper loaded: html_helper
INFO - 2023-04-26 15:54:15 --> Helper loaded: text_helper
INFO - 2023-04-26 15:54:15 --> Helper loaded: form_helper
INFO - 2023-04-26 15:54:15 --> Helper loaded: lang_helper
INFO - 2023-04-26 15:54:15 --> Helper loaded: security_helper
INFO - 2023-04-26 15:54:15 --> Helper loaded: cookie_helper
INFO - 2023-04-26 15:54:15 --> Database Driver Class Initialized
INFO - 2023-04-26 15:54:15 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-26 15:54:15 --> Parser Class Initialized
INFO - 2023-04-26 15:54:15 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-26 15:54:15 --> Pagination Class Initialized
INFO - 2023-04-26 15:54:15 --> Form Validation Class Initialized
INFO - 2023-04-26 15:54:15 --> Controller Class Initialized
INFO - 2023-04-26 15:54:15 --> Model Class Initialized
DEBUG - 2023-04-26 15:54:15 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-04-26 15:54:15 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-26 15:54:15 --> Model Class Initialized
DEBUG - 2023-04-26 15:54:15 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-26 15:54:15 --> Model Class Initialized
INFO - 2023-04-26 15:54:15 --> Final output sent to browser
DEBUG - 2023-04-26 15:54:15 --> Total execution time: 0.0182
ERROR - 2023-04-26 15:54:16 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-26 15:54:16 --> Config Class Initialized
INFO - 2023-04-26 15:54:16 --> Hooks Class Initialized
DEBUG - 2023-04-26 15:54:16 --> UTF-8 Support Enabled
INFO - 2023-04-26 15:54:16 --> Utf8 Class Initialized
INFO - 2023-04-26 15:54:16 --> URI Class Initialized
INFO - 2023-04-26 15:54:16 --> Router Class Initialized
INFO - 2023-04-26 15:54:16 --> Output Class Initialized
INFO - 2023-04-26 15:54:16 --> Security Class Initialized
DEBUG - 2023-04-26 15:54:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-26 15:54:16 --> Input Class Initialized
INFO - 2023-04-26 15:54:16 --> Language Class Initialized
INFO - 2023-04-26 15:54:16 --> Loader Class Initialized
INFO - 2023-04-26 15:54:16 --> Helper loaded: url_helper
INFO - 2023-04-26 15:54:16 --> Helper loaded: file_helper
INFO - 2023-04-26 15:54:16 --> Helper loaded: html_helper
INFO - 2023-04-26 15:54:16 --> Helper loaded: text_helper
INFO - 2023-04-26 15:54:16 --> Helper loaded: form_helper
INFO - 2023-04-26 15:54:16 --> Helper loaded: lang_helper
INFO - 2023-04-26 15:54:16 --> Helper loaded: security_helper
INFO - 2023-04-26 15:54:16 --> Helper loaded: cookie_helper
INFO - 2023-04-26 15:54:16 --> Database Driver Class Initialized
INFO - 2023-04-26 15:54:16 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-26 15:54:16 --> Parser Class Initialized
INFO - 2023-04-26 15:54:16 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-26 15:54:16 --> Pagination Class Initialized
INFO - 2023-04-26 15:54:16 --> Form Validation Class Initialized
INFO - 2023-04-26 15:54:16 --> Controller Class Initialized
INFO - 2023-04-26 15:54:16 --> Model Class Initialized
DEBUG - 2023-04-26 15:54:16 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-04-26 15:54:16 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-26 15:54:16 --> Model Class Initialized
DEBUG - 2023-04-26 15:54:16 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-26 15:54:16 --> Model Class Initialized
INFO - 2023-04-26 15:54:16 --> Final output sent to browser
DEBUG - 2023-04-26 15:54:16 --> Total execution time: 0.0215
ERROR - 2023-04-26 15:54:18 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-26 15:54:18 --> Config Class Initialized
INFO - 2023-04-26 15:54:18 --> Hooks Class Initialized
DEBUG - 2023-04-26 15:54:18 --> UTF-8 Support Enabled
INFO - 2023-04-26 15:54:18 --> Utf8 Class Initialized
INFO - 2023-04-26 15:54:18 --> URI Class Initialized
INFO - 2023-04-26 15:54:18 --> Router Class Initialized
INFO - 2023-04-26 15:54:18 --> Output Class Initialized
INFO - 2023-04-26 15:54:18 --> Security Class Initialized
DEBUG - 2023-04-26 15:54:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-26 15:54:18 --> Input Class Initialized
INFO - 2023-04-26 15:54:18 --> Language Class Initialized
INFO - 2023-04-26 15:54:18 --> Loader Class Initialized
INFO - 2023-04-26 15:54:18 --> Helper loaded: url_helper
INFO - 2023-04-26 15:54:18 --> Helper loaded: file_helper
INFO - 2023-04-26 15:54:18 --> Helper loaded: html_helper
INFO - 2023-04-26 15:54:18 --> Helper loaded: text_helper
INFO - 2023-04-26 15:54:18 --> Helper loaded: form_helper
INFO - 2023-04-26 15:54:18 --> Helper loaded: lang_helper
INFO - 2023-04-26 15:54:18 --> Helper loaded: security_helper
INFO - 2023-04-26 15:54:18 --> Helper loaded: cookie_helper
INFO - 2023-04-26 15:54:18 --> Database Driver Class Initialized
INFO - 2023-04-26 15:54:18 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-26 15:54:18 --> Parser Class Initialized
INFO - 2023-04-26 15:54:18 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-26 15:54:18 --> Pagination Class Initialized
INFO - 2023-04-26 15:54:18 --> Form Validation Class Initialized
INFO - 2023-04-26 15:54:18 --> Controller Class Initialized
INFO - 2023-04-26 15:54:18 --> Model Class Initialized
DEBUG - 2023-04-26 15:54:18 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-04-26 15:54:18 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-26 15:54:18 --> Model Class Initialized
DEBUG - 2023-04-26 15:54:18 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-26 15:54:18 --> Model Class Initialized
INFO - 2023-04-26 15:54:18 --> Final output sent to browser
DEBUG - 2023-04-26 15:54:18 --> Total execution time: 0.0175
ERROR - 2023-04-26 15:54:18 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-26 15:54:18 --> Config Class Initialized
INFO - 2023-04-26 15:54:18 --> Hooks Class Initialized
DEBUG - 2023-04-26 15:54:18 --> UTF-8 Support Enabled
INFO - 2023-04-26 15:54:18 --> Utf8 Class Initialized
INFO - 2023-04-26 15:54:18 --> URI Class Initialized
INFO - 2023-04-26 15:54:18 --> Router Class Initialized
INFO - 2023-04-26 15:54:18 --> Output Class Initialized
INFO - 2023-04-26 15:54:18 --> Security Class Initialized
DEBUG - 2023-04-26 15:54:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-26 15:54:18 --> Input Class Initialized
INFO - 2023-04-26 15:54:18 --> Language Class Initialized
INFO - 2023-04-26 15:54:18 --> Loader Class Initialized
INFO - 2023-04-26 15:54:18 --> Helper loaded: url_helper
INFO - 2023-04-26 15:54:18 --> Helper loaded: file_helper
INFO - 2023-04-26 15:54:18 --> Helper loaded: html_helper
INFO - 2023-04-26 15:54:18 --> Helper loaded: text_helper
INFO - 2023-04-26 15:54:18 --> Helper loaded: form_helper
INFO - 2023-04-26 15:54:18 --> Helper loaded: lang_helper
INFO - 2023-04-26 15:54:18 --> Helper loaded: security_helper
INFO - 2023-04-26 15:54:18 --> Helper loaded: cookie_helper
INFO - 2023-04-26 15:54:18 --> Database Driver Class Initialized
INFO - 2023-04-26 15:54:18 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-26 15:54:18 --> Parser Class Initialized
INFO - 2023-04-26 15:54:18 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-26 15:54:18 --> Pagination Class Initialized
INFO - 2023-04-26 15:54:18 --> Form Validation Class Initialized
INFO - 2023-04-26 15:54:18 --> Controller Class Initialized
INFO - 2023-04-26 15:54:18 --> Model Class Initialized
DEBUG - 2023-04-26 15:54:18 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-04-26 15:54:18 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-26 15:54:18 --> Model Class Initialized
DEBUG - 2023-04-26 15:54:18 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-26 15:54:18 --> Model Class Initialized
INFO - 2023-04-26 15:54:18 --> Final output sent to browser
DEBUG - 2023-04-26 15:54:18 --> Total execution time: 0.0187
ERROR - 2023-04-26 15:54:20 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-26 15:54:20 --> Config Class Initialized
INFO - 2023-04-26 15:54:20 --> Hooks Class Initialized
DEBUG - 2023-04-26 15:54:20 --> UTF-8 Support Enabled
INFO - 2023-04-26 15:54:20 --> Utf8 Class Initialized
INFO - 2023-04-26 15:54:20 --> URI Class Initialized
INFO - 2023-04-26 15:54:20 --> Router Class Initialized
INFO - 2023-04-26 15:54:20 --> Output Class Initialized
INFO - 2023-04-26 15:54:20 --> Security Class Initialized
DEBUG - 2023-04-26 15:54:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-26 15:54:20 --> Input Class Initialized
INFO - 2023-04-26 15:54:20 --> Language Class Initialized
INFO - 2023-04-26 15:54:20 --> Loader Class Initialized
INFO - 2023-04-26 15:54:20 --> Helper loaded: url_helper
INFO - 2023-04-26 15:54:20 --> Helper loaded: file_helper
INFO - 2023-04-26 15:54:20 --> Helper loaded: html_helper
INFO - 2023-04-26 15:54:20 --> Helper loaded: text_helper
INFO - 2023-04-26 15:54:20 --> Helper loaded: form_helper
INFO - 2023-04-26 15:54:20 --> Helper loaded: lang_helper
INFO - 2023-04-26 15:54:20 --> Helper loaded: security_helper
INFO - 2023-04-26 15:54:20 --> Helper loaded: cookie_helper
INFO - 2023-04-26 15:54:20 --> Database Driver Class Initialized
INFO - 2023-04-26 15:54:20 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-26 15:54:20 --> Parser Class Initialized
INFO - 2023-04-26 15:54:20 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-26 15:54:20 --> Pagination Class Initialized
INFO - 2023-04-26 15:54:20 --> Form Validation Class Initialized
INFO - 2023-04-26 15:54:20 --> Controller Class Initialized
INFO - 2023-04-26 15:54:20 --> Model Class Initialized
DEBUG - 2023-04-26 15:54:20 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-04-26 15:54:20 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-26 15:54:20 --> Model Class Initialized
DEBUG - 2023-04-26 15:54:20 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-26 15:54:20 --> Model Class Initialized
INFO - 2023-04-26 15:54:20 --> Model Class Initialized
INFO - 2023-04-26 15:54:20 --> Final output sent to browser
DEBUG - 2023-04-26 15:54:20 --> Total execution time: 0.0220
ERROR - 2023-04-26 15:54:23 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-26 15:54:23 --> Config Class Initialized
INFO - 2023-04-26 15:54:23 --> Hooks Class Initialized
DEBUG - 2023-04-26 15:54:23 --> UTF-8 Support Enabled
INFO - 2023-04-26 15:54:23 --> Utf8 Class Initialized
INFO - 2023-04-26 15:54:23 --> URI Class Initialized
INFO - 2023-04-26 15:54:23 --> Router Class Initialized
INFO - 2023-04-26 15:54:23 --> Output Class Initialized
INFO - 2023-04-26 15:54:23 --> Security Class Initialized
DEBUG - 2023-04-26 15:54:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-26 15:54:23 --> Input Class Initialized
INFO - 2023-04-26 15:54:23 --> Language Class Initialized
INFO - 2023-04-26 15:54:23 --> Loader Class Initialized
INFO - 2023-04-26 15:54:23 --> Helper loaded: url_helper
INFO - 2023-04-26 15:54:23 --> Helper loaded: file_helper
INFO - 2023-04-26 15:54:23 --> Helper loaded: html_helper
INFO - 2023-04-26 15:54:23 --> Helper loaded: text_helper
INFO - 2023-04-26 15:54:23 --> Helper loaded: form_helper
INFO - 2023-04-26 15:54:23 --> Helper loaded: lang_helper
INFO - 2023-04-26 15:54:23 --> Helper loaded: security_helper
INFO - 2023-04-26 15:54:23 --> Helper loaded: cookie_helper
INFO - 2023-04-26 15:54:23 --> Database Driver Class Initialized
INFO - 2023-04-26 15:54:23 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-26 15:54:23 --> Parser Class Initialized
INFO - 2023-04-26 15:54:23 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-26 15:54:23 --> Pagination Class Initialized
INFO - 2023-04-26 15:54:23 --> Form Validation Class Initialized
INFO - 2023-04-26 15:54:23 --> Controller Class Initialized
INFO - 2023-04-26 15:54:23 --> Model Class Initialized
DEBUG - 2023-04-26 15:54:23 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-04-26 15:54:23 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-26 15:54:23 --> Model Class Initialized
DEBUG - 2023-04-26 15:54:23 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-26 15:54:23 --> Model Class Initialized
INFO - 2023-04-26 15:54:23 --> Final output sent to browser
DEBUG - 2023-04-26 15:54:23 --> Total execution time: 0.0179
ERROR - 2023-04-26 15:54:28 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-26 15:54:28 --> Config Class Initialized
INFO - 2023-04-26 15:54:28 --> Hooks Class Initialized
DEBUG - 2023-04-26 15:54:28 --> UTF-8 Support Enabled
INFO - 2023-04-26 15:54:28 --> Utf8 Class Initialized
INFO - 2023-04-26 15:54:28 --> URI Class Initialized
INFO - 2023-04-26 15:54:28 --> Router Class Initialized
INFO - 2023-04-26 15:54:28 --> Output Class Initialized
INFO - 2023-04-26 15:54:28 --> Security Class Initialized
DEBUG - 2023-04-26 15:54:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-26 15:54:28 --> Input Class Initialized
INFO - 2023-04-26 15:54:28 --> Language Class Initialized
INFO - 2023-04-26 15:54:28 --> Loader Class Initialized
INFO - 2023-04-26 15:54:28 --> Helper loaded: url_helper
INFO - 2023-04-26 15:54:28 --> Helper loaded: file_helper
INFO - 2023-04-26 15:54:28 --> Helper loaded: html_helper
INFO - 2023-04-26 15:54:28 --> Helper loaded: text_helper
INFO - 2023-04-26 15:54:28 --> Helper loaded: form_helper
INFO - 2023-04-26 15:54:28 --> Helper loaded: lang_helper
INFO - 2023-04-26 15:54:28 --> Helper loaded: security_helper
INFO - 2023-04-26 15:54:28 --> Helper loaded: cookie_helper
INFO - 2023-04-26 15:54:28 --> Database Driver Class Initialized
INFO - 2023-04-26 15:54:28 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-26 15:54:28 --> Parser Class Initialized
INFO - 2023-04-26 15:54:28 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-26 15:54:28 --> Pagination Class Initialized
INFO - 2023-04-26 15:54:28 --> Form Validation Class Initialized
INFO - 2023-04-26 15:54:28 --> Controller Class Initialized
INFO - 2023-04-26 15:54:28 --> Model Class Initialized
DEBUG - 2023-04-26 15:54:28 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-04-26 15:54:28 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-26 15:54:28 --> Model Class Initialized
DEBUG - 2023-04-26 15:54:28 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-26 15:54:28 --> Model Class Initialized
INFO - 2023-04-26 15:54:28 --> Final output sent to browser
DEBUG - 2023-04-26 15:54:28 --> Total execution time: 0.0208
ERROR - 2023-04-26 15:54:29 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-26 15:54:29 --> Config Class Initialized
INFO - 2023-04-26 15:54:29 --> Hooks Class Initialized
DEBUG - 2023-04-26 15:54:29 --> UTF-8 Support Enabled
INFO - 2023-04-26 15:54:29 --> Utf8 Class Initialized
INFO - 2023-04-26 15:54:29 --> URI Class Initialized
INFO - 2023-04-26 15:54:29 --> Router Class Initialized
INFO - 2023-04-26 15:54:29 --> Output Class Initialized
INFO - 2023-04-26 15:54:29 --> Security Class Initialized
DEBUG - 2023-04-26 15:54:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-26 15:54:29 --> Input Class Initialized
INFO - 2023-04-26 15:54:29 --> Language Class Initialized
INFO - 2023-04-26 15:54:29 --> Loader Class Initialized
INFO - 2023-04-26 15:54:29 --> Helper loaded: url_helper
INFO - 2023-04-26 15:54:29 --> Helper loaded: file_helper
INFO - 2023-04-26 15:54:29 --> Helper loaded: html_helper
INFO - 2023-04-26 15:54:29 --> Helper loaded: text_helper
INFO - 2023-04-26 15:54:29 --> Helper loaded: form_helper
INFO - 2023-04-26 15:54:29 --> Helper loaded: lang_helper
INFO - 2023-04-26 15:54:29 --> Helper loaded: security_helper
INFO - 2023-04-26 15:54:29 --> Helper loaded: cookie_helper
INFO - 2023-04-26 15:54:29 --> Database Driver Class Initialized
INFO - 2023-04-26 15:54:29 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-26 15:54:29 --> Parser Class Initialized
INFO - 2023-04-26 15:54:29 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-26 15:54:29 --> Pagination Class Initialized
INFO - 2023-04-26 15:54:29 --> Form Validation Class Initialized
INFO - 2023-04-26 15:54:29 --> Controller Class Initialized
INFO - 2023-04-26 15:54:29 --> Model Class Initialized
DEBUG - 2023-04-26 15:54:29 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-04-26 15:54:29 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-26 15:54:29 --> Model Class Initialized
DEBUG - 2023-04-26 15:54:29 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-26 15:54:29 --> Model Class Initialized
INFO - 2023-04-26 15:54:29 --> Final output sent to browser
DEBUG - 2023-04-26 15:54:29 --> Total execution time: 0.0174
ERROR - 2023-04-26 15:54:31 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-26 15:54:31 --> Config Class Initialized
INFO - 2023-04-26 15:54:31 --> Hooks Class Initialized
DEBUG - 2023-04-26 15:54:31 --> UTF-8 Support Enabled
INFO - 2023-04-26 15:54:31 --> Utf8 Class Initialized
INFO - 2023-04-26 15:54:31 --> URI Class Initialized
INFO - 2023-04-26 15:54:31 --> Router Class Initialized
INFO - 2023-04-26 15:54:31 --> Output Class Initialized
INFO - 2023-04-26 15:54:31 --> Security Class Initialized
DEBUG - 2023-04-26 15:54:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-26 15:54:31 --> Input Class Initialized
INFO - 2023-04-26 15:54:31 --> Language Class Initialized
INFO - 2023-04-26 15:54:31 --> Loader Class Initialized
INFO - 2023-04-26 15:54:31 --> Helper loaded: url_helper
INFO - 2023-04-26 15:54:31 --> Helper loaded: file_helper
INFO - 2023-04-26 15:54:31 --> Helper loaded: html_helper
INFO - 2023-04-26 15:54:31 --> Helper loaded: text_helper
INFO - 2023-04-26 15:54:31 --> Helper loaded: form_helper
INFO - 2023-04-26 15:54:31 --> Helper loaded: lang_helper
INFO - 2023-04-26 15:54:31 --> Helper loaded: security_helper
INFO - 2023-04-26 15:54:31 --> Helper loaded: cookie_helper
INFO - 2023-04-26 15:54:31 --> Database Driver Class Initialized
INFO - 2023-04-26 15:54:31 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-26 15:54:31 --> Parser Class Initialized
INFO - 2023-04-26 15:54:31 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-26 15:54:31 --> Pagination Class Initialized
INFO - 2023-04-26 15:54:31 --> Form Validation Class Initialized
INFO - 2023-04-26 15:54:31 --> Controller Class Initialized
INFO - 2023-04-26 15:54:31 --> Model Class Initialized
DEBUG - 2023-04-26 15:54:31 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-04-26 15:54:31 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-26 15:54:31 --> Model Class Initialized
DEBUG - 2023-04-26 15:54:31 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-26 15:54:31 --> Model Class Initialized
INFO - 2023-04-26 15:54:31 --> Model Class Initialized
INFO - 2023-04-26 15:54:31 --> Final output sent to browser
DEBUG - 2023-04-26 15:54:31 --> Total execution time: 0.0206
ERROR - 2023-04-26 15:54:35 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-26 15:54:35 --> Config Class Initialized
INFO - 2023-04-26 15:54:35 --> Hooks Class Initialized
DEBUG - 2023-04-26 15:54:35 --> UTF-8 Support Enabled
INFO - 2023-04-26 15:54:35 --> Utf8 Class Initialized
INFO - 2023-04-26 15:54:35 --> URI Class Initialized
INFO - 2023-04-26 15:54:35 --> Router Class Initialized
INFO - 2023-04-26 15:54:35 --> Output Class Initialized
INFO - 2023-04-26 15:54:35 --> Security Class Initialized
DEBUG - 2023-04-26 15:54:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-26 15:54:35 --> Input Class Initialized
INFO - 2023-04-26 15:54:35 --> Language Class Initialized
INFO - 2023-04-26 15:54:35 --> Loader Class Initialized
INFO - 2023-04-26 15:54:35 --> Helper loaded: url_helper
INFO - 2023-04-26 15:54:35 --> Helper loaded: file_helper
INFO - 2023-04-26 15:54:35 --> Helper loaded: html_helper
INFO - 2023-04-26 15:54:35 --> Helper loaded: text_helper
INFO - 2023-04-26 15:54:35 --> Helper loaded: form_helper
INFO - 2023-04-26 15:54:35 --> Helper loaded: lang_helper
INFO - 2023-04-26 15:54:35 --> Helper loaded: security_helper
INFO - 2023-04-26 15:54:35 --> Helper loaded: cookie_helper
INFO - 2023-04-26 15:54:35 --> Database Driver Class Initialized
INFO - 2023-04-26 15:54:35 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-26 15:54:35 --> Parser Class Initialized
INFO - 2023-04-26 15:54:35 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-26 15:54:35 --> Pagination Class Initialized
INFO - 2023-04-26 15:54:35 --> Form Validation Class Initialized
INFO - 2023-04-26 15:54:35 --> Controller Class Initialized
INFO - 2023-04-26 15:54:35 --> Model Class Initialized
DEBUG - 2023-04-26 15:54:35 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-04-26 15:54:35 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-26 15:54:35 --> Model Class Initialized
DEBUG - 2023-04-26 15:54:35 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-26 15:54:35 --> Model Class Initialized
INFO - 2023-04-26 15:54:35 --> Final output sent to browser
DEBUG - 2023-04-26 15:54:35 --> Total execution time: 0.0213
ERROR - 2023-04-26 15:54:39 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-26 15:54:39 --> Config Class Initialized
INFO - 2023-04-26 15:54:39 --> Hooks Class Initialized
DEBUG - 2023-04-26 15:54:39 --> UTF-8 Support Enabled
INFO - 2023-04-26 15:54:39 --> Utf8 Class Initialized
INFO - 2023-04-26 15:54:39 --> URI Class Initialized
INFO - 2023-04-26 15:54:39 --> Router Class Initialized
INFO - 2023-04-26 15:54:39 --> Output Class Initialized
INFO - 2023-04-26 15:54:39 --> Security Class Initialized
DEBUG - 2023-04-26 15:54:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-26 15:54:39 --> Input Class Initialized
INFO - 2023-04-26 15:54:39 --> Language Class Initialized
INFO - 2023-04-26 15:54:39 --> Loader Class Initialized
INFO - 2023-04-26 15:54:39 --> Helper loaded: url_helper
INFO - 2023-04-26 15:54:39 --> Helper loaded: file_helper
INFO - 2023-04-26 15:54:39 --> Helper loaded: html_helper
INFO - 2023-04-26 15:54:39 --> Helper loaded: text_helper
INFO - 2023-04-26 15:54:39 --> Helper loaded: form_helper
INFO - 2023-04-26 15:54:39 --> Helper loaded: lang_helper
INFO - 2023-04-26 15:54:39 --> Helper loaded: security_helper
INFO - 2023-04-26 15:54:39 --> Helper loaded: cookie_helper
INFO - 2023-04-26 15:54:39 --> Database Driver Class Initialized
INFO - 2023-04-26 15:54:39 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-26 15:54:39 --> Parser Class Initialized
INFO - 2023-04-26 15:54:39 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-26 15:54:39 --> Pagination Class Initialized
INFO - 2023-04-26 15:54:39 --> Form Validation Class Initialized
INFO - 2023-04-26 15:54:39 --> Controller Class Initialized
DEBUG - 2023-04-26 15:54:39 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-04-26 15:54:39 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-26 15:54:39 --> Model Class Initialized
DEBUG - 2023-04-26 15:54:39 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-26 15:54:39 --> Model Class Initialized
DEBUG - 2023-04-26 15:54:39 --> Lcustomer class already loaded. Second attempt ignored.
INFO - 2023-04-26 15:54:39 --> Model Class Initialized
INFO - 2023-04-26 15:54:39 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/customer/customer.php
DEBUG - 2023-04-26 15:54:39 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-04-26 15:54:39 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-04-26 15:54:39 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-04-26 15:54:39 --> Model Class Initialized
INFO - 2023-04-26 15:54:39 --> Model Class Initialized
INFO - 2023-04-26 15:54:39 --> Model Class Initialized
INFO - 2023-04-26 15:54:39 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-04-26 15:54:39 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-04-26 15:54:39 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-04-26 15:54:39 --> Final output sent to browser
DEBUG - 2023-04-26 15:54:39 --> Total execution time: 0.1402
ERROR - 2023-04-26 15:54:40 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-26 15:54:40 --> Config Class Initialized
INFO - 2023-04-26 15:54:40 --> Hooks Class Initialized
DEBUG - 2023-04-26 15:54:40 --> UTF-8 Support Enabled
INFO - 2023-04-26 15:54:40 --> Utf8 Class Initialized
INFO - 2023-04-26 15:54:40 --> URI Class Initialized
INFO - 2023-04-26 15:54:40 --> Router Class Initialized
INFO - 2023-04-26 15:54:40 --> Output Class Initialized
INFO - 2023-04-26 15:54:40 --> Security Class Initialized
DEBUG - 2023-04-26 15:54:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-26 15:54:40 --> Input Class Initialized
INFO - 2023-04-26 15:54:40 --> Language Class Initialized
INFO - 2023-04-26 15:54:40 --> Loader Class Initialized
INFO - 2023-04-26 15:54:40 --> Helper loaded: url_helper
INFO - 2023-04-26 15:54:40 --> Helper loaded: file_helper
INFO - 2023-04-26 15:54:40 --> Helper loaded: html_helper
INFO - 2023-04-26 15:54:40 --> Helper loaded: text_helper
INFO - 2023-04-26 15:54:40 --> Helper loaded: form_helper
INFO - 2023-04-26 15:54:40 --> Helper loaded: lang_helper
INFO - 2023-04-26 15:54:40 --> Helper loaded: security_helper
INFO - 2023-04-26 15:54:40 --> Helper loaded: cookie_helper
INFO - 2023-04-26 15:54:40 --> Database Driver Class Initialized
INFO - 2023-04-26 15:54:40 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-26 15:54:40 --> Parser Class Initialized
INFO - 2023-04-26 15:54:40 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-26 15:54:40 --> Pagination Class Initialized
INFO - 2023-04-26 15:54:40 --> Form Validation Class Initialized
INFO - 2023-04-26 15:54:40 --> Controller Class Initialized
DEBUG - 2023-04-26 15:54:40 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-04-26 15:54:40 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-26 15:54:40 --> Model Class Initialized
DEBUG - 2023-04-26 15:54:40 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-26 15:54:40 --> Model Class Initialized
INFO - 2023-04-26 15:54:40 --> Final output sent to browser
DEBUG - 2023-04-26 15:54:40 --> Total execution time: 0.0316
ERROR - 2023-04-26 15:54:49 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-26 15:54:49 --> Config Class Initialized
INFO - 2023-04-26 15:54:49 --> Hooks Class Initialized
DEBUG - 2023-04-26 15:54:49 --> UTF-8 Support Enabled
INFO - 2023-04-26 15:54:49 --> Utf8 Class Initialized
INFO - 2023-04-26 15:54:49 --> URI Class Initialized
INFO - 2023-04-26 15:54:49 --> Router Class Initialized
INFO - 2023-04-26 15:54:49 --> Output Class Initialized
INFO - 2023-04-26 15:54:49 --> Security Class Initialized
DEBUG - 2023-04-26 15:54:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-26 15:54:49 --> Input Class Initialized
INFO - 2023-04-26 15:54:49 --> Language Class Initialized
INFO - 2023-04-26 15:54:49 --> Loader Class Initialized
INFO - 2023-04-26 15:54:49 --> Helper loaded: url_helper
INFO - 2023-04-26 15:54:49 --> Helper loaded: file_helper
INFO - 2023-04-26 15:54:49 --> Helper loaded: html_helper
INFO - 2023-04-26 15:54:49 --> Helper loaded: text_helper
INFO - 2023-04-26 15:54:49 --> Helper loaded: form_helper
INFO - 2023-04-26 15:54:49 --> Helper loaded: lang_helper
INFO - 2023-04-26 15:54:49 --> Helper loaded: security_helper
INFO - 2023-04-26 15:54:49 --> Helper loaded: cookie_helper
INFO - 2023-04-26 15:54:49 --> Database Driver Class Initialized
INFO - 2023-04-26 15:54:49 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-26 15:54:49 --> Parser Class Initialized
INFO - 2023-04-26 15:54:49 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-26 15:54:49 --> Pagination Class Initialized
INFO - 2023-04-26 15:54:49 --> Form Validation Class Initialized
INFO - 2023-04-26 15:54:49 --> Controller Class Initialized
DEBUG - 2023-04-26 15:54:49 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-04-26 15:54:49 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-26 15:54:49 --> Model Class Initialized
INFO - 2023-04-26 15:54:49 --> Model Class Initialized
DEBUG - 2023-04-26 15:54:49 --> Lmr class already loaded. Second attempt ignored.
INFO - 2023-04-26 15:54:49 --> Model Class Initialized
INFO - 2023-04-26 15:54:49 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/mr/mr.php
DEBUG - 2023-04-26 15:54:49 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-04-26 15:54:49 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-04-26 15:54:49 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-04-26 15:54:49 --> Model Class Initialized
INFO - 2023-04-26 15:54:49 --> Model Class Initialized
INFO - 2023-04-26 15:54:49 --> Model Class Initialized
INFO - 2023-04-26 15:54:50 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-04-26 15:54:50 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-04-26 15:54:50 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-04-26 15:54:50 --> Final output sent to browser
DEBUG - 2023-04-26 15:54:50 --> Total execution time: 0.1366
ERROR - 2023-04-26 15:54:50 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-26 15:54:50 --> Config Class Initialized
INFO - 2023-04-26 15:54:50 --> Hooks Class Initialized
DEBUG - 2023-04-26 15:54:50 --> UTF-8 Support Enabled
INFO - 2023-04-26 15:54:50 --> Utf8 Class Initialized
INFO - 2023-04-26 15:54:50 --> URI Class Initialized
INFO - 2023-04-26 15:54:50 --> Router Class Initialized
INFO - 2023-04-26 15:54:50 --> Output Class Initialized
INFO - 2023-04-26 15:54:50 --> Security Class Initialized
DEBUG - 2023-04-26 15:54:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-26 15:54:50 --> Input Class Initialized
INFO - 2023-04-26 15:54:50 --> Language Class Initialized
INFO - 2023-04-26 15:54:50 --> Loader Class Initialized
INFO - 2023-04-26 15:54:50 --> Helper loaded: url_helper
INFO - 2023-04-26 15:54:50 --> Helper loaded: file_helper
INFO - 2023-04-26 15:54:50 --> Helper loaded: html_helper
INFO - 2023-04-26 15:54:50 --> Helper loaded: text_helper
INFO - 2023-04-26 15:54:50 --> Helper loaded: form_helper
INFO - 2023-04-26 15:54:50 --> Helper loaded: lang_helper
INFO - 2023-04-26 15:54:50 --> Helper loaded: security_helper
INFO - 2023-04-26 15:54:50 --> Helper loaded: cookie_helper
INFO - 2023-04-26 15:54:50 --> Database Driver Class Initialized
INFO - 2023-04-26 15:54:50 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-26 15:54:50 --> Parser Class Initialized
INFO - 2023-04-26 15:54:50 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-26 15:54:50 --> Pagination Class Initialized
INFO - 2023-04-26 15:54:50 --> Form Validation Class Initialized
INFO - 2023-04-26 15:54:50 --> Controller Class Initialized
DEBUG - 2023-04-26 15:54:50 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-04-26 15:54:50 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-26 15:54:50 --> Model Class Initialized
INFO - 2023-04-26 15:54:50 --> Model Class Initialized
INFO - 2023-04-26 15:54:50 --> Final output sent to browser
DEBUG - 2023-04-26 15:54:50 --> Total execution time: 0.0193
ERROR - 2023-04-26 15:55:14 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-26 15:55:14 --> Config Class Initialized
INFO - 2023-04-26 15:55:14 --> Hooks Class Initialized
DEBUG - 2023-04-26 15:55:14 --> UTF-8 Support Enabled
INFO - 2023-04-26 15:55:14 --> Utf8 Class Initialized
INFO - 2023-04-26 15:55:14 --> URI Class Initialized
INFO - 2023-04-26 15:55:14 --> Router Class Initialized
INFO - 2023-04-26 15:55:14 --> Output Class Initialized
INFO - 2023-04-26 15:55:14 --> Security Class Initialized
DEBUG - 2023-04-26 15:55:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-26 15:55:14 --> Input Class Initialized
INFO - 2023-04-26 15:55:14 --> Language Class Initialized
INFO - 2023-04-26 15:55:14 --> Loader Class Initialized
INFO - 2023-04-26 15:55:14 --> Helper loaded: url_helper
INFO - 2023-04-26 15:55:14 --> Helper loaded: file_helper
INFO - 2023-04-26 15:55:14 --> Helper loaded: html_helper
INFO - 2023-04-26 15:55:14 --> Helper loaded: text_helper
INFO - 2023-04-26 15:55:14 --> Helper loaded: form_helper
INFO - 2023-04-26 15:55:14 --> Helper loaded: lang_helper
INFO - 2023-04-26 15:55:14 --> Helper loaded: security_helper
INFO - 2023-04-26 15:55:14 --> Helper loaded: cookie_helper
INFO - 2023-04-26 15:55:14 --> Database Driver Class Initialized
INFO - 2023-04-26 15:55:14 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-26 15:55:14 --> Parser Class Initialized
INFO - 2023-04-26 15:55:14 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-26 15:55:14 --> Pagination Class Initialized
INFO - 2023-04-26 15:55:14 --> Form Validation Class Initialized
INFO - 2023-04-26 15:55:14 --> Controller Class Initialized
INFO - 2023-04-26 15:55:14 --> Model Class Initialized
INFO - 2023-04-26 15:55:14 --> Model Class Initialized
INFO - 2023-04-26 15:55:14 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/purchase/purchase.php
DEBUG - 2023-04-26 15:55:14 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-04-26 15:55:14 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-04-26 15:55:14 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-04-26 15:55:14 --> Model Class Initialized
INFO - 2023-04-26 15:55:14 --> Model Class Initialized
INFO - 2023-04-26 15:55:14 --> Model Class Initialized
INFO - 2023-04-26 15:55:14 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-04-26 15:55:14 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-04-26 15:55:14 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-04-26 15:55:14 --> Final output sent to browser
DEBUG - 2023-04-26 15:55:14 --> Total execution time: 0.1328
ERROR - 2023-04-26 15:55:15 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-26 15:55:15 --> Config Class Initialized
INFO - 2023-04-26 15:55:15 --> Hooks Class Initialized
DEBUG - 2023-04-26 15:55:15 --> UTF-8 Support Enabled
INFO - 2023-04-26 15:55:15 --> Utf8 Class Initialized
INFO - 2023-04-26 15:55:15 --> URI Class Initialized
INFO - 2023-04-26 15:55:15 --> Router Class Initialized
INFO - 2023-04-26 15:55:15 --> Output Class Initialized
INFO - 2023-04-26 15:55:15 --> Security Class Initialized
DEBUG - 2023-04-26 15:55:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-26 15:55:15 --> Input Class Initialized
INFO - 2023-04-26 15:55:15 --> Language Class Initialized
INFO - 2023-04-26 15:55:15 --> Loader Class Initialized
INFO - 2023-04-26 15:55:15 --> Helper loaded: url_helper
INFO - 2023-04-26 15:55:15 --> Helper loaded: file_helper
INFO - 2023-04-26 15:55:15 --> Helper loaded: html_helper
INFO - 2023-04-26 15:55:15 --> Helper loaded: text_helper
INFO - 2023-04-26 15:55:15 --> Helper loaded: form_helper
INFO - 2023-04-26 15:55:15 --> Helper loaded: lang_helper
INFO - 2023-04-26 15:55:15 --> Helper loaded: security_helper
INFO - 2023-04-26 15:55:15 --> Helper loaded: cookie_helper
INFO - 2023-04-26 15:55:15 --> Database Driver Class Initialized
INFO - 2023-04-26 15:55:15 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-26 15:55:15 --> Parser Class Initialized
INFO - 2023-04-26 15:55:15 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-26 15:55:15 --> Pagination Class Initialized
INFO - 2023-04-26 15:55:15 --> Form Validation Class Initialized
INFO - 2023-04-26 15:55:15 --> Controller Class Initialized
INFO - 2023-04-26 15:55:15 --> Model Class Initialized
INFO - 2023-04-26 15:55:15 --> Model Class Initialized
INFO - 2023-04-26 15:55:15 --> Final output sent to browser
DEBUG - 2023-04-26 15:55:15 --> Total execution time: 0.0475
ERROR - 2023-04-26 15:55:18 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-26 15:55:18 --> Config Class Initialized
INFO - 2023-04-26 15:55:18 --> Hooks Class Initialized
DEBUG - 2023-04-26 15:55:18 --> UTF-8 Support Enabled
INFO - 2023-04-26 15:55:18 --> Utf8 Class Initialized
INFO - 2023-04-26 15:55:18 --> URI Class Initialized
INFO - 2023-04-26 15:55:18 --> Router Class Initialized
INFO - 2023-04-26 15:55:18 --> Output Class Initialized
INFO - 2023-04-26 15:55:18 --> Security Class Initialized
DEBUG - 2023-04-26 15:55:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-26 15:55:18 --> Input Class Initialized
INFO - 2023-04-26 15:55:18 --> Language Class Initialized
INFO - 2023-04-26 15:55:18 --> Loader Class Initialized
INFO - 2023-04-26 15:55:18 --> Helper loaded: url_helper
INFO - 2023-04-26 15:55:18 --> Helper loaded: file_helper
INFO - 2023-04-26 15:55:18 --> Helper loaded: html_helper
INFO - 2023-04-26 15:55:18 --> Helper loaded: text_helper
INFO - 2023-04-26 15:55:18 --> Helper loaded: form_helper
INFO - 2023-04-26 15:55:18 --> Helper loaded: lang_helper
INFO - 2023-04-26 15:55:18 --> Helper loaded: security_helper
INFO - 2023-04-26 15:55:18 --> Helper loaded: cookie_helper
INFO - 2023-04-26 15:55:18 --> Database Driver Class Initialized
INFO - 2023-04-26 15:55:18 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-26 15:55:18 --> Parser Class Initialized
INFO - 2023-04-26 15:55:18 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-26 15:55:18 --> Pagination Class Initialized
INFO - 2023-04-26 15:55:18 --> Form Validation Class Initialized
INFO - 2023-04-26 15:55:18 --> Controller Class Initialized
INFO - 2023-04-26 15:55:18 --> Model Class Initialized
INFO - 2023-04-26 15:55:18 --> Model Class Initialized
INFO - 2023-04-26 15:55:18 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/purchase/purchase_html.php
DEBUG - 2023-04-26 15:55:18 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-04-26 15:55:18 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-04-26 15:55:18 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-04-26 15:55:18 --> Model Class Initialized
INFO - 2023-04-26 15:55:18 --> Model Class Initialized
INFO - 2023-04-26 15:55:18 --> Model Class Initialized
INFO - 2023-04-26 15:55:18 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-04-26 15:55:18 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-04-26 15:55:18 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-04-26 15:55:18 --> Final output sent to browser
DEBUG - 2023-04-26 15:55:18 --> Total execution time: 0.1535
ERROR - 2023-04-26 15:55:36 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-26 15:55:36 --> Config Class Initialized
INFO - 2023-04-26 15:55:36 --> Hooks Class Initialized
DEBUG - 2023-04-26 15:55:36 --> UTF-8 Support Enabled
INFO - 2023-04-26 15:55:36 --> Utf8 Class Initialized
INFO - 2023-04-26 15:55:36 --> URI Class Initialized
DEBUG - 2023-04-26 15:55:36 --> No URI present. Default controller set.
INFO - 2023-04-26 15:55:36 --> Router Class Initialized
INFO - 2023-04-26 15:55:36 --> Output Class Initialized
INFO - 2023-04-26 15:55:36 --> Security Class Initialized
DEBUG - 2023-04-26 15:55:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-26 15:55:36 --> Input Class Initialized
INFO - 2023-04-26 15:55:36 --> Language Class Initialized
INFO - 2023-04-26 15:55:36 --> Loader Class Initialized
INFO - 2023-04-26 15:55:36 --> Helper loaded: url_helper
INFO - 2023-04-26 15:55:36 --> Helper loaded: file_helper
INFO - 2023-04-26 15:55:36 --> Helper loaded: html_helper
INFO - 2023-04-26 15:55:36 --> Helper loaded: text_helper
INFO - 2023-04-26 15:55:36 --> Helper loaded: form_helper
INFO - 2023-04-26 15:55:36 --> Helper loaded: lang_helper
INFO - 2023-04-26 15:55:36 --> Helper loaded: security_helper
INFO - 2023-04-26 15:55:36 --> Helper loaded: cookie_helper
INFO - 2023-04-26 15:55:36 --> Database Driver Class Initialized
INFO - 2023-04-26 15:55:36 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-26 15:55:36 --> Parser Class Initialized
INFO - 2023-04-26 15:55:36 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-26 15:55:36 --> Pagination Class Initialized
INFO - 2023-04-26 15:55:36 --> Form Validation Class Initialized
INFO - 2023-04-26 15:55:36 --> Controller Class Initialized
INFO - 2023-04-26 15:55:36 --> Model Class Initialized
DEBUG - 2023-04-26 15:55:36 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-26 15:55:36 --> Model Class Initialized
DEBUG - 2023-04-26 15:55:36 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-26 15:55:36 --> Model Class Initialized
INFO - 2023-04-26 15:55:36 --> Model Class Initialized
INFO - 2023-04-26 15:55:36 --> Model Class Initialized
INFO - 2023-04-26 15:55:36 --> Model Class Initialized
DEBUG - 2023-04-26 15:55:36 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-04-26 15:55:36 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-26 15:55:36 --> Model Class Initialized
INFO - 2023-04-26 15:55:36 --> Model Class Initialized
INFO - 2023-04-26 15:55:36 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-04-26 15:55:36 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-04-26 15:55:36 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-04-26 15:55:36 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-04-26 15:55:36 --> Model Class Initialized
INFO - 2023-04-26 15:55:37 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-04-26 15:55:37 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-04-26 15:55:37 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-04-26 15:55:37 --> Final output sent to browser
DEBUG - 2023-04-26 15:55:37 --> Total execution time: 0.1969
ERROR - 2023-04-26 15:55:52 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-26 15:55:52 --> Config Class Initialized
INFO - 2023-04-26 15:55:52 --> Hooks Class Initialized
DEBUG - 2023-04-26 15:55:52 --> UTF-8 Support Enabled
INFO - 2023-04-26 15:55:52 --> Utf8 Class Initialized
INFO - 2023-04-26 15:55:52 --> URI Class Initialized
INFO - 2023-04-26 15:55:52 --> Router Class Initialized
INFO - 2023-04-26 15:55:52 --> Output Class Initialized
INFO - 2023-04-26 15:55:52 --> Security Class Initialized
DEBUG - 2023-04-26 15:55:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-26 15:55:52 --> Input Class Initialized
INFO - 2023-04-26 15:55:52 --> Language Class Initialized
INFO - 2023-04-26 15:55:52 --> Loader Class Initialized
INFO - 2023-04-26 15:55:52 --> Helper loaded: url_helper
INFO - 2023-04-26 15:55:52 --> Helper loaded: file_helper
INFO - 2023-04-26 15:55:52 --> Helper loaded: html_helper
INFO - 2023-04-26 15:55:52 --> Helper loaded: text_helper
INFO - 2023-04-26 15:55:52 --> Helper loaded: form_helper
INFO - 2023-04-26 15:55:52 --> Helper loaded: lang_helper
INFO - 2023-04-26 15:55:52 --> Helper loaded: security_helper
INFO - 2023-04-26 15:55:52 --> Helper loaded: cookie_helper
INFO - 2023-04-26 15:55:52 --> Database Driver Class Initialized
INFO - 2023-04-26 15:55:52 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-26 15:55:52 --> Parser Class Initialized
INFO - 2023-04-26 15:55:52 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-26 15:55:52 --> Pagination Class Initialized
INFO - 2023-04-26 15:55:52 --> Form Validation Class Initialized
INFO - 2023-04-26 15:55:52 --> Controller Class Initialized
DEBUG - 2023-04-26 15:55:52 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-04-26 15:55:52 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-26 15:55:52 --> Model Class Initialized
DEBUG - 2023-04-26 15:55:52 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-26 15:55:52 --> Model Class Initialized
DEBUG - 2023-04-26 15:55:52 --> Lcustomer class already loaded. Second attempt ignored.
INFO - 2023-04-26 15:55:52 --> Model Class Initialized
INFO - 2023-04-26 15:55:52 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/customer/customer.php
DEBUG - 2023-04-26 15:55:52 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-04-26 15:55:52 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-04-26 15:55:52 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-04-26 15:55:52 --> Model Class Initialized
INFO - 2023-04-26 15:55:52 --> Model Class Initialized
INFO - 2023-04-26 15:55:52 --> Model Class Initialized
INFO - 2023-04-26 15:55:53 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-04-26 15:55:53 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-04-26 15:55:53 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-04-26 15:55:53 --> Final output sent to browser
DEBUG - 2023-04-26 15:55:53 --> Total execution time: 0.1495
ERROR - 2023-04-26 15:55:53 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-26 15:55:53 --> Config Class Initialized
INFO - 2023-04-26 15:55:53 --> Hooks Class Initialized
DEBUG - 2023-04-26 15:55:53 --> UTF-8 Support Enabled
INFO - 2023-04-26 15:55:53 --> Utf8 Class Initialized
INFO - 2023-04-26 15:55:53 --> URI Class Initialized
INFO - 2023-04-26 15:55:53 --> Router Class Initialized
INFO - 2023-04-26 15:55:53 --> Output Class Initialized
INFO - 2023-04-26 15:55:53 --> Security Class Initialized
DEBUG - 2023-04-26 15:55:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-26 15:55:53 --> Input Class Initialized
INFO - 2023-04-26 15:55:53 --> Language Class Initialized
INFO - 2023-04-26 15:55:53 --> Loader Class Initialized
INFO - 2023-04-26 15:55:53 --> Helper loaded: url_helper
INFO - 2023-04-26 15:55:53 --> Helper loaded: file_helper
INFO - 2023-04-26 15:55:53 --> Helper loaded: html_helper
INFO - 2023-04-26 15:55:53 --> Helper loaded: text_helper
INFO - 2023-04-26 15:55:53 --> Helper loaded: form_helper
INFO - 2023-04-26 15:55:53 --> Helper loaded: lang_helper
INFO - 2023-04-26 15:55:53 --> Helper loaded: security_helper
INFO - 2023-04-26 15:55:53 --> Helper loaded: cookie_helper
INFO - 2023-04-26 15:55:53 --> Database Driver Class Initialized
INFO - 2023-04-26 15:55:53 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-26 15:55:53 --> Parser Class Initialized
INFO - 2023-04-26 15:55:53 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-26 15:55:53 --> Pagination Class Initialized
INFO - 2023-04-26 15:55:53 --> Form Validation Class Initialized
INFO - 2023-04-26 15:55:53 --> Controller Class Initialized
DEBUG - 2023-04-26 15:55:53 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-04-26 15:55:53 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-26 15:55:53 --> Model Class Initialized
DEBUG - 2023-04-26 15:55:53 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-26 15:55:53 --> Model Class Initialized
INFO - 2023-04-26 15:55:53 --> Final output sent to browser
DEBUG - 2023-04-26 15:55:53 --> Total execution time: 0.0310
ERROR - 2023-04-26 15:56:01 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-26 15:56:01 --> Config Class Initialized
INFO - 2023-04-26 15:56:01 --> Hooks Class Initialized
DEBUG - 2023-04-26 15:56:01 --> UTF-8 Support Enabled
INFO - 2023-04-26 15:56:01 --> Utf8 Class Initialized
INFO - 2023-04-26 15:56:01 --> URI Class Initialized
INFO - 2023-04-26 15:56:01 --> Router Class Initialized
INFO - 2023-04-26 15:56:01 --> Output Class Initialized
INFO - 2023-04-26 15:56:01 --> Security Class Initialized
DEBUG - 2023-04-26 15:56:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-26 15:56:01 --> Input Class Initialized
INFO - 2023-04-26 15:56:01 --> Language Class Initialized
INFO - 2023-04-26 15:56:01 --> Loader Class Initialized
INFO - 2023-04-26 15:56:01 --> Helper loaded: url_helper
INFO - 2023-04-26 15:56:01 --> Helper loaded: file_helper
INFO - 2023-04-26 15:56:01 --> Helper loaded: html_helper
INFO - 2023-04-26 15:56:01 --> Helper loaded: text_helper
INFO - 2023-04-26 15:56:02 --> Helper loaded: form_helper
INFO - 2023-04-26 15:56:02 --> Helper loaded: lang_helper
INFO - 2023-04-26 15:56:02 --> Helper loaded: security_helper
INFO - 2023-04-26 15:56:02 --> Helper loaded: cookie_helper
INFO - 2023-04-26 15:56:02 --> Database Driver Class Initialized
INFO - 2023-04-26 15:56:02 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-26 15:56:02 --> Parser Class Initialized
INFO - 2023-04-26 15:56:02 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-26 15:56:02 --> Pagination Class Initialized
INFO - 2023-04-26 15:56:02 --> Form Validation Class Initialized
INFO - 2023-04-26 15:56:02 --> Controller Class Initialized
DEBUG - 2023-04-26 15:56:02 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-04-26 15:56:02 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-26 15:56:02 --> Model Class Initialized
DEBUG - 2023-04-26 15:56:02 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-26 15:56:02 --> Model Class Initialized
INFO - 2023-04-26 15:56:02 --> Final output sent to browser
DEBUG - 2023-04-26 15:56:02 --> Total execution time: 0.0834
ERROR - 2023-04-26 15:57:48 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-26 15:57:48 --> Config Class Initialized
INFO - 2023-04-26 15:57:48 --> Hooks Class Initialized
DEBUG - 2023-04-26 15:57:48 --> UTF-8 Support Enabled
INFO - 2023-04-26 15:57:48 --> Utf8 Class Initialized
INFO - 2023-04-26 15:57:48 --> URI Class Initialized
DEBUG - 2023-04-26 15:57:48 --> No URI present. Default controller set.
INFO - 2023-04-26 15:57:48 --> Router Class Initialized
INFO - 2023-04-26 15:57:48 --> Output Class Initialized
INFO - 2023-04-26 15:57:48 --> Security Class Initialized
DEBUG - 2023-04-26 15:57:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-26 15:57:48 --> Input Class Initialized
INFO - 2023-04-26 15:57:48 --> Language Class Initialized
INFO - 2023-04-26 15:57:48 --> Loader Class Initialized
INFO - 2023-04-26 15:57:48 --> Helper loaded: url_helper
INFO - 2023-04-26 15:57:48 --> Helper loaded: file_helper
INFO - 2023-04-26 15:57:48 --> Helper loaded: html_helper
INFO - 2023-04-26 15:57:48 --> Helper loaded: text_helper
INFO - 2023-04-26 15:57:48 --> Helper loaded: form_helper
INFO - 2023-04-26 15:57:48 --> Helper loaded: lang_helper
INFO - 2023-04-26 15:57:48 --> Helper loaded: security_helper
INFO - 2023-04-26 15:57:48 --> Helper loaded: cookie_helper
INFO - 2023-04-26 15:57:48 --> Database Driver Class Initialized
INFO - 2023-04-26 15:57:48 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-26 15:57:48 --> Parser Class Initialized
INFO - 2023-04-26 15:57:48 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-26 15:57:48 --> Pagination Class Initialized
INFO - 2023-04-26 15:57:48 --> Form Validation Class Initialized
INFO - 2023-04-26 15:57:48 --> Controller Class Initialized
INFO - 2023-04-26 15:57:48 --> Model Class Initialized
DEBUG - 2023-04-26 15:57:48 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-26 15:57:48 --> Model Class Initialized
DEBUG - 2023-04-26 15:57:48 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-26 15:57:48 --> Model Class Initialized
INFO - 2023-04-26 15:57:48 --> Model Class Initialized
INFO - 2023-04-26 15:57:48 --> Model Class Initialized
INFO - 2023-04-26 15:57:48 --> Model Class Initialized
DEBUG - 2023-04-26 15:57:48 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-04-26 15:57:48 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-26 15:57:48 --> Model Class Initialized
INFO - 2023-04-26 15:57:48 --> Model Class Initialized
INFO - 2023-04-26 15:57:49 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-04-26 15:57:49 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-04-26 15:57:49 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-04-26 15:57:49 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-04-26 15:57:49 --> Model Class Initialized
INFO - 2023-04-26 15:57:49 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-04-26 15:57:49 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-04-26 15:57:49 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-04-26 15:57:49 --> Final output sent to browser
DEBUG - 2023-04-26 15:57:49 --> Total execution time: 0.1793
ERROR - 2023-04-26 15:57:57 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-26 15:57:57 --> Config Class Initialized
INFO - 2023-04-26 15:57:57 --> Hooks Class Initialized
DEBUG - 2023-04-26 15:57:57 --> UTF-8 Support Enabled
INFO - 2023-04-26 15:57:57 --> Utf8 Class Initialized
INFO - 2023-04-26 15:57:57 --> URI Class Initialized
INFO - 2023-04-26 15:57:57 --> Router Class Initialized
INFO - 2023-04-26 15:57:57 --> Output Class Initialized
INFO - 2023-04-26 15:57:57 --> Security Class Initialized
DEBUG - 2023-04-26 15:57:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-26 15:57:57 --> Input Class Initialized
INFO - 2023-04-26 15:57:57 --> Language Class Initialized
INFO - 2023-04-26 15:57:57 --> Loader Class Initialized
INFO - 2023-04-26 15:57:57 --> Helper loaded: url_helper
INFO - 2023-04-26 15:57:57 --> Helper loaded: file_helper
INFO - 2023-04-26 15:57:57 --> Helper loaded: html_helper
INFO - 2023-04-26 15:57:57 --> Helper loaded: text_helper
INFO - 2023-04-26 15:57:57 --> Helper loaded: form_helper
INFO - 2023-04-26 15:57:57 --> Helper loaded: lang_helper
INFO - 2023-04-26 15:57:57 --> Helper loaded: security_helper
INFO - 2023-04-26 15:57:57 --> Helper loaded: cookie_helper
INFO - 2023-04-26 15:57:57 --> Database Driver Class Initialized
INFO - 2023-04-26 15:57:57 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-26 15:57:57 --> Parser Class Initialized
INFO - 2023-04-26 15:57:57 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-26 15:57:57 --> Pagination Class Initialized
INFO - 2023-04-26 15:57:57 --> Form Validation Class Initialized
INFO - 2023-04-26 15:57:57 --> Controller Class Initialized
DEBUG - 2023-04-26 15:57:57 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-04-26 15:57:57 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-26 15:57:57 --> Model Class Initialized
DEBUG - 2023-04-26 15:57:57 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-26 15:57:57 --> Model Class Initialized
DEBUG - 2023-04-26 15:57:57 --> Lcustomer class already loaded. Second attempt ignored.
INFO - 2023-04-26 15:57:57 --> Model Class Initialized
INFO - 2023-04-26 15:57:57 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/customer/customer.php
DEBUG - 2023-04-26 15:57:57 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-04-26 15:57:57 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-04-26 15:57:57 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-04-26 15:57:57 --> Model Class Initialized
INFO - 2023-04-26 15:57:57 --> Model Class Initialized
INFO - 2023-04-26 15:57:57 --> Model Class Initialized
INFO - 2023-04-26 15:57:57 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-04-26 15:57:57 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-04-26 15:57:57 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-04-26 15:57:57 --> Final output sent to browser
DEBUG - 2023-04-26 15:57:57 --> Total execution time: 0.1439
ERROR - 2023-04-26 15:57:58 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-26 15:57:58 --> Config Class Initialized
INFO - 2023-04-26 15:57:58 --> Hooks Class Initialized
DEBUG - 2023-04-26 15:57:58 --> UTF-8 Support Enabled
INFO - 2023-04-26 15:57:58 --> Utf8 Class Initialized
INFO - 2023-04-26 15:57:58 --> URI Class Initialized
INFO - 2023-04-26 15:57:58 --> Router Class Initialized
INFO - 2023-04-26 15:57:58 --> Output Class Initialized
INFO - 2023-04-26 15:57:58 --> Security Class Initialized
DEBUG - 2023-04-26 15:57:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-26 15:57:58 --> Input Class Initialized
INFO - 2023-04-26 15:57:58 --> Language Class Initialized
INFO - 2023-04-26 15:57:58 --> Loader Class Initialized
INFO - 2023-04-26 15:57:58 --> Helper loaded: url_helper
INFO - 2023-04-26 15:57:58 --> Helper loaded: file_helper
INFO - 2023-04-26 15:57:58 --> Helper loaded: html_helper
INFO - 2023-04-26 15:57:58 --> Helper loaded: text_helper
INFO - 2023-04-26 15:57:58 --> Helper loaded: form_helper
INFO - 2023-04-26 15:57:58 --> Helper loaded: lang_helper
INFO - 2023-04-26 15:57:58 --> Helper loaded: security_helper
INFO - 2023-04-26 15:57:58 --> Helper loaded: cookie_helper
INFO - 2023-04-26 15:57:58 --> Database Driver Class Initialized
INFO - 2023-04-26 15:57:58 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-26 15:57:58 --> Parser Class Initialized
INFO - 2023-04-26 15:57:58 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-26 15:57:58 --> Pagination Class Initialized
INFO - 2023-04-26 15:57:58 --> Form Validation Class Initialized
INFO - 2023-04-26 15:57:58 --> Controller Class Initialized
DEBUG - 2023-04-26 15:57:58 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-04-26 15:57:58 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-26 15:57:58 --> Model Class Initialized
DEBUG - 2023-04-26 15:57:58 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-26 15:57:58 --> Model Class Initialized
INFO - 2023-04-26 15:57:58 --> Final output sent to browser
DEBUG - 2023-04-26 15:57:58 --> Total execution time: 0.0305
