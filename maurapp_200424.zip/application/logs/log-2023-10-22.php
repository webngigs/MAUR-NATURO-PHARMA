<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2023-10-22 00:31:45 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-22 00:31:45 --> Config Class Initialized
INFO - 2023-10-22 00:31:45 --> Hooks Class Initialized
DEBUG - 2023-10-22 00:31:45 --> UTF-8 Support Enabled
INFO - 2023-10-22 00:31:45 --> Utf8 Class Initialized
INFO - 2023-10-22 00:31:45 --> URI Class Initialized
INFO - 2023-10-22 00:31:45 --> Router Class Initialized
INFO - 2023-10-22 00:31:45 --> Output Class Initialized
INFO - 2023-10-22 00:31:45 --> Security Class Initialized
DEBUG - 2023-10-22 00:31:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-22 00:31:45 --> Input Class Initialized
INFO - 2023-10-22 00:31:45 --> Language Class Initialized
ERROR - 2023-10-22 00:31:45 --> 404 Page Not Found: Well-known/assetlinks.json
ERROR - 2023-10-22 04:31:47 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-22 04:31:47 --> Config Class Initialized
INFO - 2023-10-22 04:31:47 --> Hooks Class Initialized
DEBUG - 2023-10-22 04:31:47 --> UTF-8 Support Enabled
INFO - 2023-10-22 04:31:47 --> Utf8 Class Initialized
INFO - 2023-10-22 04:31:47 --> URI Class Initialized
INFO - 2023-10-22 04:31:47 --> Router Class Initialized
INFO - 2023-10-22 04:31:47 --> Output Class Initialized
INFO - 2023-10-22 04:31:47 --> Security Class Initialized
DEBUG - 2023-10-22 04:31:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-22 04:31:47 --> Input Class Initialized
INFO - 2023-10-22 04:31:47 --> Language Class Initialized
ERROR - 2023-10-22 04:31:47 --> 404 Page Not Found: Well-known/assetlinks.json
ERROR - 2023-10-22 09:41:20 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-22 09:41:20 --> Config Class Initialized
INFO - 2023-10-22 09:41:20 --> Hooks Class Initialized
DEBUG - 2023-10-22 09:41:20 --> UTF-8 Support Enabled
INFO - 2023-10-22 09:41:20 --> Utf8 Class Initialized
INFO - 2023-10-22 09:41:20 --> URI Class Initialized
DEBUG - 2023-10-22 09:41:20 --> No URI present. Default controller set.
INFO - 2023-10-22 09:41:20 --> Router Class Initialized
INFO - 2023-10-22 09:41:20 --> Output Class Initialized
INFO - 2023-10-22 09:41:20 --> Security Class Initialized
DEBUG - 2023-10-22 09:41:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-22 09:41:20 --> Input Class Initialized
INFO - 2023-10-22 09:41:20 --> Language Class Initialized
INFO - 2023-10-22 09:41:20 --> Loader Class Initialized
INFO - 2023-10-22 09:41:20 --> Helper loaded: url_helper
INFO - 2023-10-22 09:41:20 --> Helper loaded: file_helper
INFO - 2023-10-22 09:41:20 --> Helper loaded: html_helper
INFO - 2023-10-22 09:41:20 --> Helper loaded: text_helper
INFO - 2023-10-22 09:41:20 --> Helper loaded: form_helper
INFO - 2023-10-22 09:41:20 --> Helper loaded: lang_helper
INFO - 2023-10-22 09:41:20 --> Helper loaded: security_helper
INFO - 2023-10-22 09:41:20 --> Helper loaded: cookie_helper
INFO - 2023-10-22 09:41:20 --> Database Driver Class Initialized
INFO - 2023-10-22 09:41:20 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-22 09:41:20 --> Parser Class Initialized
INFO - 2023-10-22 09:41:20 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-22 09:41:20 --> Pagination Class Initialized
INFO - 2023-10-22 09:41:20 --> Form Validation Class Initialized
INFO - 2023-10-22 09:41:20 --> Controller Class Initialized
INFO - 2023-10-22 09:41:20 --> Model Class Initialized
DEBUG - 2023-10-22 09:41:20 --> Session class already loaded. Second attempt ignored.
ERROR - 2023-10-22 09:41:21 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-22 09:41:21 --> Config Class Initialized
INFO - 2023-10-22 09:41:21 --> Hooks Class Initialized
DEBUG - 2023-10-22 09:41:21 --> UTF-8 Support Enabled
INFO - 2023-10-22 09:41:21 --> Utf8 Class Initialized
INFO - 2023-10-22 09:41:21 --> URI Class Initialized
INFO - 2023-10-22 09:41:21 --> Router Class Initialized
INFO - 2023-10-22 09:41:21 --> Output Class Initialized
INFO - 2023-10-22 09:41:21 --> Security Class Initialized
DEBUG - 2023-10-22 09:41:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-22 09:41:21 --> Input Class Initialized
INFO - 2023-10-22 09:41:21 --> Language Class Initialized
INFO - 2023-10-22 09:41:21 --> Loader Class Initialized
INFO - 2023-10-22 09:41:21 --> Helper loaded: url_helper
INFO - 2023-10-22 09:41:21 --> Helper loaded: file_helper
INFO - 2023-10-22 09:41:21 --> Helper loaded: html_helper
INFO - 2023-10-22 09:41:21 --> Helper loaded: text_helper
INFO - 2023-10-22 09:41:21 --> Helper loaded: form_helper
INFO - 2023-10-22 09:41:21 --> Helper loaded: lang_helper
INFO - 2023-10-22 09:41:21 --> Helper loaded: security_helper
INFO - 2023-10-22 09:41:21 --> Helper loaded: cookie_helper
INFO - 2023-10-22 09:41:21 --> Database Driver Class Initialized
INFO - 2023-10-22 09:41:21 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-22 09:41:21 --> Parser Class Initialized
INFO - 2023-10-22 09:41:21 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-22 09:41:21 --> Pagination Class Initialized
INFO - 2023-10-22 09:41:21 --> Form Validation Class Initialized
INFO - 2023-10-22 09:41:21 --> Controller Class Initialized
INFO - 2023-10-22 09:41:21 --> Model Class Initialized
DEBUG - 2023-10-22 09:41:21 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-22 09:41:21 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2023-10-22 09:41:21 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-10-22 09:41:21 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-10-22 09:41:21 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-10-22 09:41:21 --> Model Class Initialized
INFO - 2023-10-22 09:41:21 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-10-22 09:41:21 --> Final output sent to browser
DEBUG - 2023-10-22 09:41:21 --> Total execution time: 0.0377
