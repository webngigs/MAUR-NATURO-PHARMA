<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2023-10-30 02:49:22 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-30 02:49:22 --> Config Class Initialized
INFO - 2023-10-30 02:49:22 --> Hooks Class Initialized
DEBUG - 2023-10-30 02:49:22 --> UTF-8 Support Enabled
INFO - 2023-10-30 02:49:22 --> Utf8 Class Initialized
INFO - 2023-10-30 02:49:22 --> URI Class Initialized
DEBUG - 2023-10-30 02:49:22 --> No URI present. Default controller set.
INFO - 2023-10-30 02:49:22 --> Router Class Initialized
INFO - 2023-10-30 02:49:22 --> Output Class Initialized
INFO - 2023-10-30 02:49:22 --> Security Class Initialized
DEBUG - 2023-10-30 02:49:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-30 02:49:22 --> Input Class Initialized
INFO - 2023-10-30 02:49:22 --> Language Class Initialized
INFO - 2023-10-30 02:49:22 --> Loader Class Initialized
INFO - 2023-10-30 02:49:22 --> Helper loaded: url_helper
INFO - 2023-10-30 02:49:22 --> Helper loaded: file_helper
INFO - 2023-10-30 02:49:22 --> Helper loaded: html_helper
INFO - 2023-10-30 02:49:22 --> Helper loaded: text_helper
INFO - 2023-10-30 02:49:22 --> Helper loaded: form_helper
INFO - 2023-10-30 02:49:22 --> Helper loaded: lang_helper
INFO - 2023-10-30 02:49:22 --> Helper loaded: security_helper
INFO - 2023-10-30 02:49:23 --> Helper loaded: cookie_helper
INFO - 2023-10-30 02:49:23 --> Database Driver Class Initialized
INFO - 2023-10-30 02:49:23 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-30 02:49:23 --> Parser Class Initialized
INFO - 2023-10-30 02:49:23 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-30 02:49:23 --> Pagination Class Initialized
INFO - 2023-10-30 02:49:23 --> Form Validation Class Initialized
INFO - 2023-10-30 02:49:23 --> Controller Class Initialized
INFO - 2023-10-30 02:49:23 --> Model Class Initialized
DEBUG - 2023-10-30 02:49:23 --> Session class already loaded. Second attempt ignored.
ERROR - 2023-10-30 03:32:49 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-30 03:32:49 --> Config Class Initialized
INFO - 2023-10-30 03:32:49 --> Hooks Class Initialized
DEBUG - 2023-10-30 03:32:49 --> UTF-8 Support Enabled
INFO - 2023-10-30 03:32:49 --> Utf8 Class Initialized
INFO - 2023-10-30 03:32:49 --> URI Class Initialized
INFO - 2023-10-30 03:32:49 --> Router Class Initialized
INFO - 2023-10-30 03:32:49 --> Output Class Initialized
INFO - 2023-10-30 03:32:49 --> Security Class Initialized
DEBUG - 2023-10-30 03:32:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-30 03:32:49 --> Input Class Initialized
INFO - 2023-10-30 03:32:49 --> Language Class Initialized
ERROR - 2023-10-30 03:32:49 --> 404 Page Not Found: Well-known/assetlinks.json
ERROR - 2023-10-30 06:54:28 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-30 06:54:28 --> Config Class Initialized
INFO - 2023-10-30 06:54:28 --> Hooks Class Initialized
DEBUG - 2023-10-30 06:54:28 --> UTF-8 Support Enabled
INFO - 2023-10-30 06:54:28 --> Utf8 Class Initialized
INFO - 2023-10-30 06:54:28 --> URI Class Initialized
DEBUG - 2023-10-30 06:54:28 --> No URI present. Default controller set.
INFO - 2023-10-30 06:54:28 --> Router Class Initialized
INFO - 2023-10-30 06:54:28 --> Output Class Initialized
INFO - 2023-10-30 06:54:28 --> Security Class Initialized
DEBUG - 2023-10-30 06:54:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-30 06:54:28 --> Input Class Initialized
INFO - 2023-10-30 06:54:28 --> Language Class Initialized
INFO - 2023-10-30 06:54:28 --> Loader Class Initialized
INFO - 2023-10-30 06:54:28 --> Helper loaded: url_helper
INFO - 2023-10-30 06:54:28 --> Helper loaded: file_helper
INFO - 2023-10-30 06:54:28 --> Helper loaded: html_helper
INFO - 2023-10-30 06:54:28 --> Helper loaded: text_helper
INFO - 2023-10-30 06:54:28 --> Helper loaded: form_helper
INFO - 2023-10-30 06:54:28 --> Helper loaded: lang_helper
INFO - 2023-10-30 06:54:28 --> Helper loaded: security_helper
INFO - 2023-10-30 06:54:28 --> Helper loaded: cookie_helper
INFO - 2023-10-30 06:54:28 --> Database Driver Class Initialized
INFO - 2023-10-30 06:54:28 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-30 06:54:28 --> Parser Class Initialized
INFO - 2023-10-30 06:54:28 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-30 06:54:28 --> Pagination Class Initialized
INFO - 2023-10-30 06:54:28 --> Form Validation Class Initialized
INFO - 2023-10-30 06:54:28 --> Controller Class Initialized
INFO - 2023-10-30 06:54:28 --> Model Class Initialized
DEBUG - 2023-10-30 06:54:28 --> Session class already loaded. Second attempt ignored.
ERROR - 2023-10-30 06:54:29 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-30 06:54:29 --> Config Class Initialized
INFO - 2023-10-30 06:54:29 --> Hooks Class Initialized
DEBUG - 2023-10-30 06:54:29 --> UTF-8 Support Enabled
INFO - 2023-10-30 06:54:29 --> Utf8 Class Initialized
INFO - 2023-10-30 06:54:29 --> URI Class Initialized
INFO - 2023-10-30 06:54:29 --> Router Class Initialized
INFO - 2023-10-30 06:54:29 --> Output Class Initialized
INFO - 2023-10-30 06:54:29 --> Security Class Initialized
DEBUG - 2023-10-30 06:54:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-30 06:54:29 --> Input Class Initialized
INFO - 2023-10-30 06:54:29 --> Language Class Initialized
INFO - 2023-10-30 06:54:29 --> Loader Class Initialized
INFO - 2023-10-30 06:54:29 --> Helper loaded: url_helper
INFO - 2023-10-30 06:54:29 --> Helper loaded: file_helper
INFO - 2023-10-30 06:54:29 --> Helper loaded: html_helper
INFO - 2023-10-30 06:54:29 --> Helper loaded: text_helper
INFO - 2023-10-30 06:54:29 --> Helper loaded: form_helper
INFO - 2023-10-30 06:54:29 --> Helper loaded: lang_helper
INFO - 2023-10-30 06:54:29 --> Helper loaded: security_helper
INFO - 2023-10-30 06:54:29 --> Helper loaded: cookie_helper
INFO - 2023-10-30 06:54:29 --> Database Driver Class Initialized
INFO - 2023-10-30 06:54:29 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-30 06:54:29 --> Parser Class Initialized
INFO - 2023-10-30 06:54:29 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-30 06:54:29 --> Pagination Class Initialized
INFO - 2023-10-30 06:54:29 --> Form Validation Class Initialized
INFO - 2023-10-30 06:54:29 --> Controller Class Initialized
INFO - 2023-10-30 06:54:29 --> Model Class Initialized
DEBUG - 2023-10-30 06:54:29 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-30 06:54:29 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2023-10-30 06:54:29 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-10-30 06:54:29 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-10-30 06:54:29 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-10-30 06:54:29 --> Model Class Initialized
INFO - 2023-10-30 06:54:29 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-10-30 06:54:29 --> Final output sent to browser
DEBUG - 2023-10-30 06:54:29 --> Total execution time: 0.0389
ERROR - 2023-10-30 06:54:45 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-30 06:54:45 --> Config Class Initialized
INFO - 2023-10-30 06:54:45 --> Hooks Class Initialized
DEBUG - 2023-10-30 06:54:45 --> UTF-8 Support Enabled
INFO - 2023-10-30 06:54:45 --> Utf8 Class Initialized
INFO - 2023-10-30 06:54:45 --> URI Class Initialized
INFO - 2023-10-30 06:54:45 --> Router Class Initialized
INFO - 2023-10-30 06:54:45 --> Output Class Initialized
INFO - 2023-10-30 06:54:45 --> Security Class Initialized
DEBUG - 2023-10-30 06:54:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-30 06:54:45 --> Input Class Initialized
INFO - 2023-10-30 06:54:45 --> Language Class Initialized
INFO - 2023-10-30 06:54:45 --> Loader Class Initialized
INFO - 2023-10-30 06:54:45 --> Helper loaded: url_helper
INFO - 2023-10-30 06:54:45 --> Helper loaded: file_helper
INFO - 2023-10-30 06:54:45 --> Helper loaded: html_helper
INFO - 2023-10-30 06:54:45 --> Helper loaded: text_helper
INFO - 2023-10-30 06:54:45 --> Helper loaded: form_helper
INFO - 2023-10-30 06:54:45 --> Helper loaded: lang_helper
INFO - 2023-10-30 06:54:45 --> Helper loaded: security_helper
INFO - 2023-10-30 06:54:45 --> Helper loaded: cookie_helper
INFO - 2023-10-30 06:54:45 --> Database Driver Class Initialized
INFO - 2023-10-30 06:54:45 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-30 06:54:45 --> Parser Class Initialized
INFO - 2023-10-30 06:54:45 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-30 06:54:45 --> Pagination Class Initialized
INFO - 2023-10-30 06:54:45 --> Form Validation Class Initialized
INFO - 2023-10-30 06:54:45 --> Controller Class Initialized
INFO - 2023-10-30 06:54:45 --> Model Class Initialized
DEBUG - 2023-10-30 06:54:45 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-30 06:54:45 --> Model Class Initialized
INFO - 2023-10-30 06:54:45 --> Final output sent to browser
DEBUG - 2023-10-30 06:54:45 --> Total execution time: 0.0213
ERROR - 2023-10-30 06:54:45 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-30 06:54:45 --> Config Class Initialized
INFO - 2023-10-30 06:54:45 --> Hooks Class Initialized
DEBUG - 2023-10-30 06:54:45 --> UTF-8 Support Enabled
INFO - 2023-10-30 06:54:45 --> Utf8 Class Initialized
INFO - 2023-10-30 06:54:45 --> URI Class Initialized
DEBUG - 2023-10-30 06:54:45 --> No URI present. Default controller set.
INFO - 2023-10-30 06:54:45 --> Router Class Initialized
INFO - 2023-10-30 06:54:45 --> Output Class Initialized
INFO - 2023-10-30 06:54:45 --> Security Class Initialized
DEBUG - 2023-10-30 06:54:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-30 06:54:45 --> Input Class Initialized
INFO - 2023-10-30 06:54:45 --> Language Class Initialized
INFO - 2023-10-30 06:54:45 --> Loader Class Initialized
INFO - 2023-10-30 06:54:45 --> Helper loaded: url_helper
INFO - 2023-10-30 06:54:45 --> Helper loaded: file_helper
INFO - 2023-10-30 06:54:45 --> Helper loaded: html_helper
INFO - 2023-10-30 06:54:45 --> Helper loaded: text_helper
INFO - 2023-10-30 06:54:45 --> Helper loaded: form_helper
INFO - 2023-10-30 06:54:45 --> Helper loaded: lang_helper
INFO - 2023-10-30 06:54:45 --> Helper loaded: security_helper
INFO - 2023-10-30 06:54:45 --> Helper loaded: cookie_helper
INFO - 2023-10-30 06:54:45 --> Database Driver Class Initialized
INFO - 2023-10-30 06:54:45 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-30 06:54:45 --> Parser Class Initialized
INFO - 2023-10-30 06:54:45 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-30 06:54:45 --> Pagination Class Initialized
INFO - 2023-10-30 06:54:45 --> Form Validation Class Initialized
INFO - 2023-10-30 06:54:45 --> Controller Class Initialized
INFO - 2023-10-30 06:54:45 --> Model Class Initialized
DEBUG - 2023-10-30 06:54:45 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-30 06:54:45 --> Model Class Initialized
DEBUG - 2023-10-30 06:54:45 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-30 06:54:45 --> Model Class Initialized
INFO - 2023-10-30 06:54:45 --> Model Class Initialized
INFO - 2023-10-30 06:54:45 --> Model Class Initialized
INFO - 2023-10-30 06:54:45 --> Model Class Initialized
DEBUG - 2023-10-30 06:54:45 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-10-30 06:54:45 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-30 06:54:45 --> Model Class Initialized
INFO - 2023-10-30 06:54:45 --> Model Class Initialized
INFO - 2023-10-30 06:54:45 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-10-30 06:54:45 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-10-30 06:54:45 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-10-30 06:54:45 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-10-30 06:54:45 --> Model Class Initialized
INFO - 2023-10-30 06:54:45 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-10-30 06:54:45 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-10-30 06:54:45 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-10-30 06:54:45 --> Final output sent to browser
DEBUG - 2023-10-30 06:54:45 --> Total execution time: 0.2037
ERROR - 2023-10-30 06:54:50 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-30 06:54:50 --> Config Class Initialized
INFO - 2023-10-30 06:54:50 --> Hooks Class Initialized
DEBUG - 2023-10-30 06:54:50 --> UTF-8 Support Enabled
INFO - 2023-10-30 06:54:50 --> Utf8 Class Initialized
INFO - 2023-10-30 06:54:50 --> URI Class Initialized
INFO - 2023-10-30 06:54:50 --> Router Class Initialized
INFO - 2023-10-30 06:54:50 --> Output Class Initialized
INFO - 2023-10-30 06:54:50 --> Security Class Initialized
DEBUG - 2023-10-30 06:54:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-30 06:54:50 --> Input Class Initialized
INFO - 2023-10-30 06:54:50 --> Language Class Initialized
INFO - 2023-10-30 06:54:50 --> Loader Class Initialized
INFO - 2023-10-30 06:54:50 --> Helper loaded: url_helper
INFO - 2023-10-30 06:54:50 --> Helper loaded: file_helper
INFO - 2023-10-30 06:54:50 --> Helper loaded: html_helper
INFO - 2023-10-30 06:54:50 --> Helper loaded: text_helper
INFO - 2023-10-30 06:54:50 --> Helper loaded: form_helper
INFO - 2023-10-30 06:54:50 --> Helper loaded: lang_helper
INFO - 2023-10-30 06:54:50 --> Helper loaded: security_helper
INFO - 2023-10-30 06:54:50 --> Helper loaded: cookie_helper
INFO - 2023-10-30 06:54:50 --> Database Driver Class Initialized
INFO - 2023-10-30 06:54:50 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-30 06:54:50 --> Parser Class Initialized
INFO - 2023-10-30 06:54:50 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-30 06:54:50 --> Pagination Class Initialized
INFO - 2023-10-30 06:54:50 --> Form Validation Class Initialized
INFO - 2023-10-30 06:54:50 --> Controller Class Initialized
INFO - 2023-10-30 06:54:50 --> Model Class Initialized
DEBUG - 2023-10-30 06:54:50 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-10-30 06:54:50 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-30 06:54:50 --> Model Class Initialized
INFO - 2023-10-30 06:54:50 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/stockrequest/inventory.php
DEBUG - 2023-10-30 06:54:50 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-10-30 06:54:50 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-10-30 06:54:50 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-10-30 06:54:50 --> Model Class Initialized
INFO - 2023-10-30 06:54:50 --> Model Class Initialized
INFO - 2023-10-30 06:54:50 --> Model Class Initialized
INFO - 2023-10-30 06:54:50 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-10-30 06:54:50 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-10-30 06:54:50 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-10-30 06:54:50 --> Final output sent to browser
DEBUG - 2023-10-30 06:54:50 --> Total execution time: 0.1199
ERROR - 2023-10-30 06:54:51 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-30 06:54:51 --> Config Class Initialized
INFO - 2023-10-30 06:54:51 --> Hooks Class Initialized
DEBUG - 2023-10-30 06:54:51 --> UTF-8 Support Enabled
INFO - 2023-10-30 06:54:51 --> Utf8 Class Initialized
INFO - 2023-10-30 06:54:51 --> URI Class Initialized
INFO - 2023-10-30 06:54:51 --> Router Class Initialized
INFO - 2023-10-30 06:54:51 --> Output Class Initialized
INFO - 2023-10-30 06:54:51 --> Security Class Initialized
DEBUG - 2023-10-30 06:54:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-30 06:54:51 --> Input Class Initialized
INFO - 2023-10-30 06:54:51 --> Language Class Initialized
INFO - 2023-10-30 06:54:51 --> Loader Class Initialized
INFO - 2023-10-30 06:54:51 --> Helper loaded: url_helper
INFO - 2023-10-30 06:54:51 --> Helper loaded: file_helper
INFO - 2023-10-30 06:54:51 --> Helper loaded: html_helper
INFO - 2023-10-30 06:54:51 --> Helper loaded: text_helper
INFO - 2023-10-30 06:54:51 --> Helper loaded: form_helper
INFO - 2023-10-30 06:54:51 --> Helper loaded: lang_helper
INFO - 2023-10-30 06:54:51 --> Helper loaded: security_helper
INFO - 2023-10-30 06:54:51 --> Helper loaded: cookie_helper
INFO - 2023-10-30 06:54:51 --> Database Driver Class Initialized
INFO - 2023-10-30 06:54:51 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-30 06:54:51 --> Parser Class Initialized
INFO - 2023-10-30 06:54:51 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-30 06:54:51 --> Pagination Class Initialized
INFO - 2023-10-30 06:54:51 --> Form Validation Class Initialized
INFO - 2023-10-30 06:54:51 --> Controller Class Initialized
INFO - 2023-10-30 06:54:51 --> Model Class Initialized
DEBUG - 2023-10-30 06:54:51 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-10-30 06:54:51 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-30 06:54:51 --> Model Class Initialized
INFO - 2023-10-30 06:54:51 --> Final output sent to browser
DEBUG - 2023-10-30 06:54:51 --> Total execution time: 0.0726
ERROR - 2023-10-30 06:54:54 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-30 06:54:54 --> Config Class Initialized
INFO - 2023-10-30 06:54:54 --> Hooks Class Initialized
DEBUG - 2023-10-30 06:54:54 --> UTF-8 Support Enabled
INFO - 2023-10-30 06:54:54 --> Utf8 Class Initialized
INFO - 2023-10-30 06:54:54 --> URI Class Initialized
INFO - 2023-10-30 06:54:54 --> Router Class Initialized
INFO - 2023-10-30 06:54:54 --> Output Class Initialized
INFO - 2023-10-30 06:54:54 --> Security Class Initialized
DEBUG - 2023-10-30 06:54:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-30 06:54:54 --> Input Class Initialized
INFO - 2023-10-30 06:54:54 --> Language Class Initialized
INFO - 2023-10-30 06:54:54 --> Loader Class Initialized
INFO - 2023-10-30 06:54:54 --> Helper loaded: url_helper
INFO - 2023-10-30 06:54:54 --> Helper loaded: file_helper
INFO - 2023-10-30 06:54:54 --> Helper loaded: html_helper
INFO - 2023-10-30 06:54:54 --> Helper loaded: text_helper
INFO - 2023-10-30 06:54:54 --> Helper loaded: form_helper
INFO - 2023-10-30 06:54:54 --> Helper loaded: lang_helper
INFO - 2023-10-30 06:54:54 --> Helper loaded: security_helper
INFO - 2023-10-30 06:54:54 --> Helper loaded: cookie_helper
INFO - 2023-10-30 06:54:54 --> Database Driver Class Initialized
INFO - 2023-10-30 06:54:54 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-30 06:54:54 --> Parser Class Initialized
INFO - 2023-10-30 06:54:54 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-30 06:54:54 --> Pagination Class Initialized
INFO - 2023-10-30 06:54:54 --> Form Validation Class Initialized
INFO - 2023-10-30 06:54:54 --> Controller Class Initialized
INFO - 2023-10-30 06:54:54 --> Model Class Initialized
DEBUG - 2023-10-30 06:54:54 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-10-30 06:54:54 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-30 06:54:54 --> Model Class Initialized
INFO - 2023-10-30 06:54:54 --> Final output sent to browser
DEBUG - 2023-10-30 06:54:54 --> Total execution time: 0.0756
ERROR - 2023-10-30 16:00:02 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-30 16:00:02 --> Config Class Initialized
INFO - 2023-10-30 16:00:02 --> Hooks Class Initialized
DEBUG - 2023-10-30 16:00:02 --> UTF-8 Support Enabled
INFO - 2023-10-30 16:00:02 --> Utf8 Class Initialized
INFO - 2023-10-30 16:00:02 --> URI Class Initialized
DEBUG - 2023-10-30 16:00:02 --> No URI present. Default controller set.
INFO - 2023-10-30 16:00:02 --> Router Class Initialized
INFO - 2023-10-30 16:00:02 --> Output Class Initialized
INFO - 2023-10-30 16:00:02 --> Security Class Initialized
DEBUG - 2023-10-30 16:00:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-30 16:00:02 --> Input Class Initialized
INFO - 2023-10-30 16:00:02 --> Language Class Initialized
INFO - 2023-10-30 16:00:02 --> Loader Class Initialized
INFO - 2023-10-30 16:00:02 --> Helper loaded: url_helper
INFO - 2023-10-30 16:00:02 --> Helper loaded: file_helper
INFO - 2023-10-30 16:00:02 --> Helper loaded: html_helper
INFO - 2023-10-30 16:00:02 --> Helper loaded: text_helper
INFO - 2023-10-30 16:00:02 --> Helper loaded: form_helper
INFO - 2023-10-30 16:00:02 --> Helper loaded: lang_helper
INFO - 2023-10-30 16:00:02 --> Helper loaded: security_helper
INFO - 2023-10-30 16:00:02 --> Helper loaded: cookie_helper
INFO - 2023-10-30 16:00:02 --> Database Driver Class Initialized
INFO - 2023-10-30 16:00:02 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-30 16:00:02 --> Parser Class Initialized
INFO - 2023-10-30 16:00:02 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-30 16:00:02 --> Pagination Class Initialized
INFO - 2023-10-30 16:00:02 --> Form Validation Class Initialized
INFO - 2023-10-30 16:00:02 --> Controller Class Initialized
INFO - 2023-10-30 16:00:02 --> Model Class Initialized
DEBUG - 2023-10-30 16:00:02 --> Session class already loaded. Second attempt ignored.
ERROR - 2023-10-30 16:00:03 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-30 16:00:03 --> Config Class Initialized
INFO - 2023-10-30 16:00:03 --> Hooks Class Initialized
DEBUG - 2023-10-30 16:00:03 --> UTF-8 Support Enabled
INFO - 2023-10-30 16:00:03 --> Utf8 Class Initialized
INFO - 2023-10-30 16:00:03 --> URI Class Initialized
INFO - 2023-10-30 16:00:03 --> Router Class Initialized
INFO - 2023-10-30 16:00:03 --> Output Class Initialized
INFO - 2023-10-30 16:00:03 --> Security Class Initialized
DEBUG - 2023-10-30 16:00:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-30 16:00:03 --> Input Class Initialized
INFO - 2023-10-30 16:00:03 --> Language Class Initialized
INFO - 2023-10-30 16:00:03 --> Loader Class Initialized
INFO - 2023-10-30 16:00:03 --> Helper loaded: url_helper
INFO - 2023-10-30 16:00:03 --> Helper loaded: file_helper
INFO - 2023-10-30 16:00:03 --> Helper loaded: html_helper
INFO - 2023-10-30 16:00:03 --> Helper loaded: text_helper
INFO - 2023-10-30 16:00:03 --> Helper loaded: form_helper
INFO - 2023-10-30 16:00:03 --> Helper loaded: lang_helper
INFO - 2023-10-30 16:00:03 --> Helper loaded: security_helper
INFO - 2023-10-30 16:00:03 --> Helper loaded: cookie_helper
INFO - 2023-10-30 16:00:03 --> Database Driver Class Initialized
INFO - 2023-10-30 16:00:03 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-30 16:00:03 --> Parser Class Initialized
INFO - 2023-10-30 16:00:03 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-30 16:00:03 --> Pagination Class Initialized
INFO - 2023-10-30 16:00:03 --> Form Validation Class Initialized
INFO - 2023-10-30 16:00:03 --> Controller Class Initialized
INFO - 2023-10-30 16:00:03 --> Model Class Initialized
DEBUG - 2023-10-30 16:00:03 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-30 16:00:03 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2023-10-30 16:00:03 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-10-30 16:00:03 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-10-30 16:00:03 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-10-30 16:00:03 --> Model Class Initialized
INFO - 2023-10-30 16:00:03 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-10-30 16:00:03 --> Final output sent to browser
DEBUG - 2023-10-30 16:00:03 --> Total execution time: 0.0357
ERROR - 2023-10-30 16:00:05 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-30 16:00:05 --> Config Class Initialized
INFO - 2023-10-30 16:00:05 --> Hooks Class Initialized
DEBUG - 2023-10-30 16:00:05 --> UTF-8 Support Enabled
INFO - 2023-10-30 16:00:05 --> Utf8 Class Initialized
INFO - 2023-10-30 16:00:05 --> URI Class Initialized
INFO - 2023-10-30 16:00:05 --> Router Class Initialized
INFO - 2023-10-30 16:00:05 --> Output Class Initialized
INFO - 2023-10-30 16:00:05 --> Security Class Initialized
DEBUG - 2023-10-30 16:00:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-30 16:00:05 --> Input Class Initialized
INFO - 2023-10-30 16:00:05 --> Language Class Initialized
INFO - 2023-10-30 16:00:05 --> Loader Class Initialized
INFO - 2023-10-30 16:00:05 --> Helper loaded: url_helper
INFO - 2023-10-30 16:00:05 --> Helper loaded: file_helper
INFO - 2023-10-30 16:00:05 --> Helper loaded: html_helper
INFO - 2023-10-30 16:00:05 --> Helper loaded: text_helper
INFO - 2023-10-30 16:00:05 --> Helper loaded: form_helper
INFO - 2023-10-30 16:00:05 --> Helper loaded: lang_helper
INFO - 2023-10-30 16:00:05 --> Helper loaded: security_helper
INFO - 2023-10-30 16:00:05 --> Helper loaded: cookie_helper
INFO - 2023-10-30 16:00:05 --> Database Driver Class Initialized
INFO - 2023-10-30 16:00:05 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-30 16:00:05 --> Parser Class Initialized
INFO - 2023-10-30 16:00:05 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-30 16:00:05 --> Pagination Class Initialized
INFO - 2023-10-30 16:00:05 --> Form Validation Class Initialized
INFO - 2023-10-30 16:00:05 --> Controller Class Initialized
INFO - 2023-10-30 16:00:05 --> Model Class Initialized
DEBUG - 2023-10-30 16:00:05 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-30 16:00:05 --> Model Class Initialized
INFO - 2023-10-30 16:00:05 --> Final output sent to browser
DEBUG - 2023-10-30 16:00:05 --> Total execution time: 0.0195
ERROR - 2023-10-30 16:00:05 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-30 16:00:05 --> Config Class Initialized
INFO - 2023-10-30 16:00:05 --> Hooks Class Initialized
DEBUG - 2023-10-30 16:00:05 --> UTF-8 Support Enabled
INFO - 2023-10-30 16:00:05 --> Utf8 Class Initialized
INFO - 2023-10-30 16:00:05 --> URI Class Initialized
DEBUG - 2023-10-30 16:00:05 --> No URI present. Default controller set.
INFO - 2023-10-30 16:00:05 --> Router Class Initialized
INFO - 2023-10-30 16:00:05 --> Output Class Initialized
INFO - 2023-10-30 16:00:05 --> Security Class Initialized
DEBUG - 2023-10-30 16:00:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-30 16:00:05 --> Input Class Initialized
INFO - 2023-10-30 16:00:05 --> Language Class Initialized
INFO - 2023-10-30 16:00:05 --> Loader Class Initialized
INFO - 2023-10-30 16:00:05 --> Helper loaded: url_helper
INFO - 2023-10-30 16:00:05 --> Helper loaded: file_helper
INFO - 2023-10-30 16:00:05 --> Helper loaded: html_helper
INFO - 2023-10-30 16:00:05 --> Helper loaded: text_helper
INFO - 2023-10-30 16:00:05 --> Helper loaded: form_helper
INFO - 2023-10-30 16:00:05 --> Helper loaded: lang_helper
INFO - 2023-10-30 16:00:05 --> Helper loaded: security_helper
INFO - 2023-10-30 16:00:05 --> Helper loaded: cookie_helper
INFO - 2023-10-30 16:00:05 --> Database Driver Class Initialized
INFO - 2023-10-30 16:00:05 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-30 16:00:05 --> Parser Class Initialized
INFO - 2023-10-30 16:00:05 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-30 16:00:05 --> Pagination Class Initialized
INFO - 2023-10-30 16:00:05 --> Form Validation Class Initialized
INFO - 2023-10-30 16:00:05 --> Controller Class Initialized
INFO - 2023-10-30 16:00:05 --> Model Class Initialized
DEBUG - 2023-10-30 16:00:05 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-30 16:00:05 --> Model Class Initialized
DEBUG - 2023-10-30 16:00:05 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-30 16:00:05 --> Model Class Initialized
INFO - 2023-10-30 16:00:05 --> Model Class Initialized
INFO - 2023-10-30 16:00:05 --> Model Class Initialized
INFO - 2023-10-30 16:00:05 --> Model Class Initialized
DEBUG - 2023-10-30 16:00:05 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-10-30 16:00:05 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-30 16:00:05 --> Model Class Initialized
INFO - 2023-10-30 16:00:05 --> Model Class Initialized
INFO - 2023-10-30 16:00:06 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-10-30 16:00:06 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-10-30 16:00:06 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-10-30 16:00:06 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-10-30 16:00:06 --> Model Class Initialized
INFO - 2023-10-30 16:00:06 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-10-30 16:00:06 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-10-30 16:00:06 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-10-30 16:00:06 --> Final output sent to browser
DEBUG - 2023-10-30 16:00:06 --> Total execution time: 0.3983
ERROR - 2023-10-30 16:00:07 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-30 16:00:07 --> Config Class Initialized
INFO - 2023-10-30 16:00:07 --> Hooks Class Initialized
DEBUG - 2023-10-30 16:00:07 --> UTF-8 Support Enabled
INFO - 2023-10-30 16:00:07 --> Utf8 Class Initialized
INFO - 2023-10-30 16:00:07 --> URI Class Initialized
INFO - 2023-10-30 16:00:07 --> Router Class Initialized
INFO - 2023-10-30 16:00:07 --> Output Class Initialized
INFO - 2023-10-30 16:00:07 --> Security Class Initialized
DEBUG - 2023-10-30 16:00:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-30 16:00:07 --> Input Class Initialized
INFO - 2023-10-30 16:00:07 --> Language Class Initialized
INFO - 2023-10-30 16:00:07 --> Loader Class Initialized
INFO - 2023-10-30 16:00:07 --> Helper loaded: url_helper
INFO - 2023-10-30 16:00:07 --> Helper loaded: file_helper
INFO - 2023-10-30 16:00:07 --> Helper loaded: html_helper
INFO - 2023-10-30 16:00:07 --> Helper loaded: text_helper
INFO - 2023-10-30 16:00:07 --> Helper loaded: form_helper
INFO - 2023-10-30 16:00:07 --> Helper loaded: lang_helper
INFO - 2023-10-30 16:00:07 --> Helper loaded: security_helper
INFO - 2023-10-30 16:00:07 --> Helper loaded: cookie_helper
INFO - 2023-10-30 16:00:07 --> Database Driver Class Initialized
INFO - 2023-10-30 16:00:07 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-30 16:00:07 --> Parser Class Initialized
INFO - 2023-10-30 16:00:07 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-30 16:00:07 --> Pagination Class Initialized
INFO - 2023-10-30 16:00:07 --> Form Validation Class Initialized
INFO - 2023-10-30 16:00:07 --> Controller Class Initialized
DEBUG - 2023-10-30 16:00:07 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-10-30 16:00:07 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-30 16:00:07 --> Model Class Initialized
INFO - 2023-10-30 16:00:07 --> Final output sent to browser
DEBUG - 2023-10-30 16:00:07 --> Total execution time: 0.0146
ERROR - 2023-10-30 16:00:21 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-30 16:00:21 --> Config Class Initialized
INFO - 2023-10-30 16:00:21 --> Hooks Class Initialized
DEBUG - 2023-10-30 16:00:21 --> UTF-8 Support Enabled
INFO - 2023-10-30 16:00:21 --> Utf8 Class Initialized
INFO - 2023-10-30 16:00:21 --> URI Class Initialized
DEBUG - 2023-10-30 16:00:21 --> No URI present. Default controller set.
INFO - 2023-10-30 16:00:21 --> Router Class Initialized
INFO - 2023-10-30 16:00:21 --> Output Class Initialized
INFO - 2023-10-30 16:00:21 --> Security Class Initialized
DEBUG - 2023-10-30 16:00:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-30 16:00:21 --> Input Class Initialized
INFO - 2023-10-30 16:00:21 --> Language Class Initialized
INFO - 2023-10-30 16:00:21 --> Loader Class Initialized
INFO - 2023-10-30 16:00:21 --> Helper loaded: url_helper
INFO - 2023-10-30 16:00:21 --> Helper loaded: file_helper
INFO - 2023-10-30 16:00:21 --> Helper loaded: html_helper
INFO - 2023-10-30 16:00:21 --> Helper loaded: text_helper
INFO - 2023-10-30 16:00:21 --> Helper loaded: form_helper
INFO - 2023-10-30 16:00:21 --> Helper loaded: lang_helper
INFO - 2023-10-30 16:00:21 --> Helper loaded: security_helper
INFO - 2023-10-30 16:00:21 --> Helper loaded: cookie_helper
INFO - 2023-10-30 16:00:21 --> Database Driver Class Initialized
INFO - 2023-10-30 16:00:21 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-30 16:00:21 --> Parser Class Initialized
INFO - 2023-10-30 16:00:21 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-30 16:00:21 --> Pagination Class Initialized
INFO - 2023-10-30 16:00:21 --> Form Validation Class Initialized
INFO - 2023-10-30 16:00:21 --> Controller Class Initialized
INFO - 2023-10-30 16:00:21 --> Model Class Initialized
DEBUG - 2023-10-30 16:00:21 --> Session class already loaded. Second attempt ignored.
ERROR - 2023-10-30 16:00:21 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-30 16:00:21 --> Config Class Initialized
INFO - 2023-10-30 16:00:21 --> Hooks Class Initialized
DEBUG - 2023-10-30 16:00:21 --> UTF-8 Support Enabled
INFO - 2023-10-30 16:00:21 --> Utf8 Class Initialized
INFO - 2023-10-30 16:00:21 --> URI Class Initialized
INFO - 2023-10-30 16:00:21 --> Router Class Initialized
INFO - 2023-10-30 16:00:21 --> Output Class Initialized
INFO - 2023-10-30 16:00:21 --> Security Class Initialized
DEBUG - 2023-10-30 16:00:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-30 16:00:21 --> Input Class Initialized
INFO - 2023-10-30 16:00:21 --> Language Class Initialized
INFO - 2023-10-30 16:00:21 --> Loader Class Initialized
INFO - 2023-10-30 16:00:21 --> Helper loaded: url_helper
INFO - 2023-10-30 16:00:21 --> Helper loaded: file_helper
INFO - 2023-10-30 16:00:21 --> Helper loaded: html_helper
INFO - 2023-10-30 16:00:21 --> Helper loaded: text_helper
INFO - 2023-10-30 16:00:21 --> Helper loaded: form_helper
INFO - 2023-10-30 16:00:21 --> Helper loaded: lang_helper
INFO - 2023-10-30 16:00:22 --> Helper loaded: security_helper
INFO - 2023-10-30 16:00:22 --> Helper loaded: cookie_helper
INFO - 2023-10-30 16:00:22 --> Database Driver Class Initialized
INFO - 2023-10-30 16:00:22 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-30 16:00:22 --> Parser Class Initialized
INFO - 2023-10-30 16:00:22 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-30 16:00:22 --> Pagination Class Initialized
INFO - 2023-10-30 16:00:22 --> Form Validation Class Initialized
INFO - 2023-10-30 16:00:22 --> Controller Class Initialized
INFO - 2023-10-30 16:00:22 --> Model Class Initialized
DEBUG - 2023-10-30 16:00:22 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-30 16:00:22 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2023-10-30 16:00:22 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-10-30 16:00:22 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-10-30 16:00:22 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-10-30 16:00:22 --> Model Class Initialized
INFO - 2023-10-30 16:00:22 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-10-30 16:00:22 --> Final output sent to browser
DEBUG - 2023-10-30 16:00:22 --> Total execution time: 0.0288
ERROR - 2023-10-30 16:00:27 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-30 16:00:27 --> Config Class Initialized
INFO - 2023-10-30 16:00:27 --> Hooks Class Initialized
DEBUG - 2023-10-30 16:00:27 --> UTF-8 Support Enabled
INFO - 2023-10-30 16:00:27 --> Utf8 Class Initialized
INFO - 2023-10-30 16:00:27 --> URI Class Initialized
INFO - 2023-10-30 16:00:27 --> Router Class Initialized
INFO - 2023-10-30 16:00:27 --> Output Class Initialized
INFO - 2023-10-30 16:00:27 --> Security Class Initialized
DEBUG - 2023-10-30 16:00:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-30 16:00:27 --> Input Class Initialized
INFO - 2023-10-30 16:00:27 --> Language Class Initialized
INFO - 2023-10-30 16:00:27 --> Loader Class Initialized
INFO - 2023-10-30 16:00:27 --> Helper loaded: url_helper
INFO - 2023-10-30 16:00:27 --> Helper loaded: file_helper
INFO - 2023-10-30 16:00:27 --> Helper loaded: html_helper
INFO - 2023-10-30 16:00:27 --> Helper loaded: text_helper
INFO - 2023-10-30 16:00:27 --> Helper loaded: form_helper
INFO - 2023-10-30 16:00:27 --> Helper loaded: lang_helper
INFO - 2023-10-30 16:00:27 --> Helper loaded: security_helper
INFO - 2023-10-30 16:00:27 --> Helper loaded: cookie_helper
INFO - 2023-10-30 16:00:27 --> Database Driver Class Initialized
INFO - 2023-10-30 16:00:27 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-30 16:00:27 --> Parser Class Initialized
INFO - 2023-10-30 16:00:27 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-30 16:00:27 --> Pagination Class Initialized
INFO - 2023-10-30 16:00:27 --> Form Validation Class Initialized
INFO - 2023-10-30 16:00:27 --> Controller Class Initialized
INFO - 2023-10-30 16:00:27 --> Model Class Initialized
DEBUG - 2023-10-30 16:00:27 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-30 16:00:27 --> Model Class Initialized
INFO - 2023-10-30 16:00:27 --> Final output sent to browser
DEBUG - 2023-10-30 16:00:27 --> Total execution time: 0.0178
ERROR - 2023-10-30 16:00:28 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-30 16:00:28 --> Config Class Initialized
INFO - 2023-10-30 16:00:28 --> Hooks Class Initialized
DEBUG - 2023-10-30 16:00:28 --> UTF-8 Support Enabled
INFO - 2023-10-30 16:00:28 --> Utf8 Class Initialized
INFO - 2023-10-30 16:00:28 --> URI Class Initialized
DEBUG - 2023-10-30 16:00:28 --> No URI present. Default controller set.
INFO - 2023-10-30 16:00:28 --> Router Class Initialized
INFO - 2023-10-30 16:00:28 --> Output Class Initialized
INFO - 2023-10-30 16:00:28 --> Security Class Initialized
DEBUG - 2023-10-30 16:00:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-30 16:00:28 --> Input Class Initialized
INFO - 2023-10-30 16:00:28 --> Language Class Initialized
INFO - 2023-10-30 16:00:28 --> Loader Class Initialized
INFO - 2023-10-30 16:00:28 --> Helper loaded: url_helper
INFO - 2023-10-30 16:00:28 --> Helper loaded: file_helper
INFO - 2023-10-30 16:00:28 --> Helper loaded: html_helper
INFO - 2023-10-30 16:00:28 --> Helper loaded: text_helper
INFO - 2023-10-30 16:00:28 --> Helper loaded: form_helper
INFO - 2023-10-30 16:00:28 --> Helper loaded: lang_helper
INFO - 2023-10-30 16:00:28 --> Helper loaded: security_helper
INFO - 2023-10-30 16:00:28 --> Helper loaded: cookie_helper
INFO - 2023-10-30 16:00:28 --> Database Driver Class Initialized
INFO - 2023-10-30 16:00:28 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-30 16:00:28 --> Parser Class Initialized
INFO - 2023-10-30 16:00:28 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-30 16:00:28 --> Pagination Class Initialized
INFO - 2023-10-30 16:00:28 --> Form Validation Class Initialized
INFO - 2023-10-30 16:00:28 --> Controller Class Initialized
INFO - 2023-10-30 16:00:28 --> Model Class Initialized
DEBUG - 2023-10-30 16:00:28 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-30 16:00:28 --> Model Class Initialized
DEBUG - 2023-10-30 16:00:28 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-30 16:00:28 --> Model Class Initialized
INFO - 2023-10-30 16:00:28 --> Model Class Initialized
INFO - 2023-10-30 16:00:28 --> Model Class Initialized
INFO - 2023-10-30 16:00:28 --> Model Class Initialized
DEBUG - 2023-10-30 16:00:28 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-10-30 16:00:28 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-30 16:00:28 --> Model Class Initialized
INFO - 2023-10-30 16:00:28 --> Model Class Initialized
INFO - 2023-10-30 16:00:28 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-10-30 16:00:28 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-10-30 16:00:28 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-10-30 16:00:28 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-10-30 16:00:28 --> Model Class Initialized
INFO - 2023-10-30 16:00:28 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-10-30 16:00:28 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-10-30 16:00:28 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-10-30 16:00:28 --> Final output sent to browser
DEBUG - 2023-10-30 16:00:28 --> Total execution time: 0.2017
ERROR - 2023-10-30 16:00:42 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-30 16:00:42 --> Config Class Initialized
INFO - 2023-10-30 16:00:42 --> Hooks Class Initialized
DEBUG - 2023-10-30 16:00:42 --> UTF-8 Support Enabled
INFO - 2023-10-30 16:00:42 --> Utf8 Class Initialized
INFO - 2023-10-30 16:00:42 --> URI Class Initialized
INFO - 2023-10-30 16:00:42 --> Router Class Initialized
INFO - 2023-10-30 16:00:42 --> Output Class Initialized
INFO - 2023-10-30 16:00:42 --> Security Class Initialized
DEBUG - 2023-10-30 16:00:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-30 16:00:42 --> Input Class Initialized
INFO - 2023-10-30 16:00:42 --> Language Class Initialized
INFO - 2023-10-30 16:00:42 --> Loader Class Initialized
INFO - 2023-10-30 16:00:42 --> Helper loaded: url_helper
INFO - 2023-10-30 16:00:42 --> Helper loaded: file_helper
INFO - 2023-10-30 16:00:42 --> Helper loaded: html_helper
INFO - 2023-10-30 16:00:42 --> Helper loaded: text_helper
INFO - 2023-10-30 16:00:42 --> Helper loaded: form_helper
INFO - 2023-10-30 16:00:42 --> Helper loaded: lang_helper
INFO - 2023-10-30 16:00:42 --> Helper loaded: security_helper
INFO - 2023-10-30 16:00:42 --> Helper loaded: cookie_helper
INFO - 2023-10-30 16:00:42 --> Database Driver Class Initialized
INFO - 2023-10-30 16:00:42 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-30 16:00:42 --> Parser Class Initialized
INFO - 2023-10-30 16:00:42 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-30 16:00:42 --> Pagination Class Initialized
INFO - 2023-10-30 16:00:42 --> Form Validation Class Initialized
INFO - 2023-10-30 16:00:42 --> Controller Class Initialized
INFO - 2023-10-30 16:00:42 --> Model Class Initialized
DEBUG - 2023-10-30 16:00:42 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-10-30 16:00:42 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-30 16:00:42 --> Model Class Initialized
DEBUG - 2023-10-30 16:00:42 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-30 16:00:42 --> Model Class Initialized
INFO - 2023-10-30 16:00:42 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice.php
DEBUG - 2023-10-30 16:00:42 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-10-30 16:00:42 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-10-30 16:00:42 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-10-30 16:00:42 --> Model Class Initialized
INFO - 2023-10-30 16:00:42 --> Model Class Initialized
INFO - 2023-10-30 16:00:42 --> Model Class Initialized
INFO - 2023-10-30 16:00:42 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-10-30 16:00:42 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-10-30 16:00:42 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-10-30 16:00:42 --> Final output sent to browser
DEBUG - 2023-10-30 16:00:42 --> Total execution time: 0.1520
ERROR - 2023-10-30 16:00:44 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-30 16:00:44 --> Config Class Initialized
INFO - 2023-10-30 16:00:44 --> Hooks Class Initialized
DEBUG - 2023-10-30 16:00:44 --> UTF-8 Support Enabled
INFO - 2023-10-30 16:00:44 --> Utf8 Class Initialized
INFO - 2023-10-30 16:00:44 --> URI Class Initialized
INFO - 2023-10-30 16:00:44 --> Router Class Initialized
INFO - 2023-10-30 16:00:44 --> Output Class Initialized
INFO - 2023-10-30 16:00:44 --> Security Class Initialized
DEBUG - 2023-10-30 16:00:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-30 16:00:44 --> Input Class Initialized
INFO - 2023-10-30 16:00:44 --> Language Class Initialized
INFO - 2023-10-30 16:00:44 --> Loader Class Initialized
INFO - 2023-10-30 16:00:44 --> Helper loaded: url_helper
INFO - 2023-10-30 16:00:44 --> Helper loaded: file_helper
INFO - 2023-10-30 16:00:44 --> Helper loaded: html_helper
INFO - 2023-10-30 16:00:44 --> Helper loaded: text_helper
INFO - 2023-10-30 16:00:44 --> Helper loaded: form_helper
INFO - 2023-10-30 16:00:44 --> Helper loaded: lang_helper
INFO - 2023-10-30 16:00:44 --> Helper loaded: security_helper
INFO - 2023-10-30 16:00:44 --> Helper loaded: cookie_helper
INFO - 2023-10-30 16:00:44 --> Database Driver Class Initialized
INFO - 2023-10-30 16:00:44 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-30 16:00:44 --> Parser Class Initialized
INFO - 2023-10-30 16:00:44 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-30 16:00:44 --> Pagination Class Initialized
INFO - 2023-10-30 16:00:44 --> Form Validation Class Initialized
INFO - 2023-10-30 16:00:44 --> Controller Class Initialized
INFO - 2023-10-30 16:00:44 --> Model Class Initialized
DEBUG - 2023-10-30 16:00:44 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-10-30 16:00:44 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-30 16:00:44 --> Model Class Initialized
DEBUG - 2023-10-30 16:00:44 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-30 16:00:44 --> Model Class Initialized
INFO - 2023-10-30 16:00:44 --> Final output sent to browser
DEBUG - 2023-10-30 16:00:44 --> Total execution time: 0.0471
ERROR - 2023-10-30 16:00:50 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-30 16:00:50 --> Config Class Initialized
INFO - 2023-10-30 16:00:50 --> Hooks Class Initialized
DEBUG - 2023-10-30 16:00:50 --> UTF-8 Support Enabled
INFO - 2023-10-30 16:00:50 --> Utf8 Class Initialized
INFO - 2023-10-30 16:00:50 --> URI Class Initialized
INFO - 2023-10-30 16:00:50 --> Router Class Initialized
INFO - 2023-10-30 16:00:50 --> Output Class Initialized
INFO - 2023-10-30 16:00:50 --> Security Class Initialized
DEBUG - 2023-10-30 16:00:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-30 16:00:50 --> Input Class Initialized
INFO - 2023-10-30 16:00:50 --> Language Class Initialized
INFO - 2023-10-30 16:00:50 --> Loader Class Initialized
INFO - 2023-10-30 16:00:50 --> Helper loaded: url_helper
INFO - 2023-10-30 16:00:50 --> Helper loaded: file_helper
INFO - 2023-10-30 16:00:50 --> Helper loaded: html_helper
INFO - 2023-10-30 16:00:50 --> Helper loaded: text_helper
INFO - 2023-10-30 16:00:50 --> Helper loaded: form_helper
INFO - 2023-10-30 16:00:50 --> Helper loaded: lang_helper
INFO - 2023-10-30 16:00:50 --> Helper loaded: security_helper
INFO - 2023-10-30 16:00:50 --> Helper loaded: cookie_helper
INFO - 2023-10-30 16:00:50 --> Database Driver Class Initialized
INFO - 2023-10-30 16:00:50 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-30 16:00:50 --> Parser Class Initialized
INFO - 2023-10-30 16:00:50 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-30 16:00:50 --> Pagination Class Initialized
INFO - 2023-10-30 16:00:50 --> Form Validation Class Initialized
INFO - 2023-10-30 16:00:50 --> Controller Class Initialized
INFO - 2023-10-30 16:00:50 --> Model Class Initialized
DEBUG - 2023-10-30 16:00:50 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-10-30 16:00:50 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-30 16:00:50 --> Model Class Initialized
DEBUG - 2023-10-30 16:00:50 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-30 16:00:50 --> Model Class Initialized
INFO - 2023-10-30 16:00:50 --> Final output sent to browser
DEBUG - 2023-10-30 16:00:50 --> Total execution time: 0.3582
ERROR - 2023-10-30 16:01:19 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-30 16:01:19 --> Config Class Initialized
INFO - 2023-10-30 16:01:19 --> Hooks Class Initialized
DEBUG - 2023-10-30 16:01:19 --> UTF-8 Support Enabled
INFO - 2023-10-30 16:01:19 --> Utf8 Class Initialized
INFO - 2023-10-30 16:01:19 --> URI Class Initialized
INFO - 2023-10-30 16:01:19 --> Router Class Initialized
INFO - 2023-10-30 16:01:19 --> Output Class Initialized
INFO - 2023-10-30 16:01:19 --> Security Class Initialized
DEBUG - 2023-10-30 16:01:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-30 16:01:19 --> Input Class Initialized
INFO - 2023-10-30 16:01:19 --> Language Class Initialized
INFO - 2023-10-30 16:01:19 --> Loader Class Initialized
INFO - 2023-10-30 16:01:19 --> Helper loaded: url_helper
INFO - 2023-10-30 16:01:19 --> Helper loaded: file_helper
INFO - 2023-10-30 16:01:19 --> Helper loaded: html_helper
INFO - 2023-10-30 16:01:19 --> Helper loaded: text_helper
INFO - 2023-10-30 16:01:19 --> Helper loaded: form_helper
INFO - 2023-10-30 16:01:19 --> Helper loaded: lang_helper
INFO - 2023-10-30 16:01:19 --> Helper loaded: security_helper
INFO - 2023-10-30 16:01:19 --> Helper loaded: cookie_helper
INFO - 2023-10-30 16:01:19 --> Database Driver Class Initialized
INFO - 2023-10-30 16:01:19 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-30 16:01:19 --> Parser Class Initialized
INFO - 2023-10-30 16:01:19 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-30 16:01:19 --> Pagination Class Initialized
INFO - 2023-10-30 16:01:19 --> Form Validation Class Initialized
INFO - 2023-10-30 16:01:19 --> Controller Class Initialized
DEBUG - 2023-10-30 16:01:19 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-10-30 16:01:19 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-30 16:01:19 --> Model Class Initialized
INFO - 2023-10-30 16:01:19 --> Model Class Initialized
DEBUG - 2023-10-30 16:01:19 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-10-30 16:01:19 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-30 16:01:19 --> Model Class Initialized
DEBUG - 2023-10-30 16:01:19 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-30 16:01:19 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/gst/list.php
DEBUG - 2023-10-30 16:01:19 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-10-30 16:01:19 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-10-30 16:01:19 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-10-30 16:01:19 --> Model Class Initialized
INFO - 2023-10-30 16:01:19 --> Model Class Initialized
INFO - 2023-10-30 16:01:19 --> Model Class Initialized
INFO - 2023-10-30 16:01:19 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-10-30 16:01:19 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-10-30 16:01:19 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-10-30 16:01:19 --> Final output sent to browser
DEBUG - 2023-10-30 16:01:19 --> Total execution time: 0.1956
ERROR - 2023-10-30 20:02:54 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-30 20:02:54 --> Config Class Initialized
INFO - 2023-10-30 20:02:54 --> Hooks Class Initialized
DEBUG - 2023-10-30 20:02:54 --> UTF-8 Support Enabled
INFO - 2023-10-30 20:02:54 --> Utf8 Class Initialized
INFO - 2023-10-30 20:02:54 --> URI Class Initialized
INFO - 2023-10-30 20:02:54 --> Router Class Initialized
INFO - 2023-10-30 20:02:54 --> Output Class Initialized
INFO - 2023-10-30 20:02:54 --> Security Class Initialized
DEBUG - 2023-10-30 20:02:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-30 20:02:54 --> Input Class Initialized
INFO - 2023-10-30 20:02:54 --> Language Class Initialized
ERROR - 2023-10-30 20:02:54 --> 404 Page Not Found: Well-known/assetlinks.json
