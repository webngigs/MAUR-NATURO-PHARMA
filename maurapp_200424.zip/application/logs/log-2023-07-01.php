<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2023-07-01 03:18:40 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-01 03:18:40 --> Config Class Initialized
INFO - 2023-07-01 03:18:40 --> Hooks Class Initialized
DEBUG - 2023-07-01 03:18:40 --> UTF-8 Support Enabled
INFO - 2023-07-01 03:18:40 --> Utf8 Class Initialized
INFO - 2023-07-01 03:18:40 --> URI Class Initialized
INFO - 2023-07-01 03:18:40 --> Router Class Initialized
INFO - 2023-07-01 03:18:40 --> Output Class Initialized
INFO - 2023-07-01 03:18:40 --> Security Class Initialized
DEBUG - 2023-07-01 03:18:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-01 03:18:40 --> Input Class Initialized
INFO - 2023-07-01 03:18:40 --> Language Class Initialized
INFO - 2023-07-01 03:18:40 --> Loader Class Initialized
INFO - 2023-07-01 03:18:40 --> Helper loaded: url_helper
INFO - 2023-07-01 03:18:40 --> Helper loaded: file_helper
INFO - 2023-07-01 03:18:40 --> Helper loaded: html_helper
INFO - 2023-07-01 03:18:40 --> Helper loaded: text_helper
INFO - 2023-07-01 03:18:40 --> Helper loaded: form_helper
INFO - 2023-07-01 03:18:40 --> Helper loaded: lang_helper
INFO - 2023-07-01 03:18:40 --> Helper loaded: security_helper
INFO - 2023-07-01 03:18:40 --> Helper loaded: cookie_helper
INFO - 2023-07-01 03:18:40 --> Database Driver Class Initialized
INFO - 2023-07-01 03:18:40 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-01 03:18:40 --> Parser Class Initialized
INFO - 2023-07-01 03:18:40 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-01 03:18:40 --> Pagination Class Initialized
INFO - 2023-07-01 03:18:40 --> Form Validation Class Initialized
INFO - 2023-07-01 03:18:40 --> Controller Class Initialized
ERROR - 2023-07-01 03:18:40 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-01 03:18:40 --> Config Class Initialized
INFO - 2023-07-01 03:18:40 --> Hooks Class Initialized
DEBUG - 2023-07-01 03:18:40 --> UTF-8 Support Enabled
INFO - 2023-07-01 03:18:40 --> Utf8 Class Initialized
INFO - 2023-07-01 03:18:40 --> URI Class Initialized
INFO - 2023-07-01 03:18:40 --> Router Class Initialized
INFO - 2023-07-01 03:18:40 --> Output Class Initialized
INFO - 2023-07-01 03:18:40 --> Security Class Initialized
DEBUG - 2023-07-01 03:18:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-01 03:18:40 --> Input Class Initialized
INFO - 2023-07-01 03:18:40 --> Language Class Initialized
INFO - 2023-07-01 03:18:40 --> Loader Class Initialized
INFO - 2023-07-01 03:18:40 --> Helper loaded: url_helper
INFO - 2023-07-01 03:18:40 --> Helper loaded: file_helper
INFO - 2023-07-01 03:18:40 --> Helper loaded: html_helper
INFO - 2023-07-01 03:18:40 --> Helper loaded: text_helper
INFO - 2023-07-01 03:18:40 --> Helper loaded: form_helper
INFO - 2023-07-01 03:18:40 --> Helper loaded: lang_helper
INFO - 2023-07-01 03:18:40 --> Helper loaded: security_helper
INFO - 2023-07-01 03:18:40 --> Helper loaded: cookie_helper
INFO - 2023-07-01 03:18:40 --> Database Driver Class Initialized
INFO - 2023-07-01 03:18:40 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-01 03:18:40 --> Parser Class Initialized
INFO - 2023-07-01 03:18:40 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-01 03:18:40 --> Pagination Class Initialized
INFO - 2023-07-01 03:18:40 --> Form Validation Class Initialized
INFO - 2023-07-01 03:18:40 --> Controller Class Initialized
INFO - 2023-07-01 03:18:40 --> Model Class Initialized
DEBUG - 2023-07-01 03:18:40 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-01 03:18:40 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2023-07-01 03:18:40 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-07-01 03:18:40 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-07-01 03:18:40 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-07-01 03:18:40 --> Model Class Initialized
INFO - 2023-07-01 03:18:40 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-07-01 03:18:40 --> Final output sent to browser
DEBUG - 2023-07-01 03:18:40 --> Total execution time: 0.0310
ERROR - 2023-07-01 03:18:41 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-01 03:18:41 --> Config Class Initialized
INFO - 2023-07-01 03:18:41 --> Hooks Class Initialized
DEBUG - 2023-07-01 03:18:41 --> UTF-8 Support Enabled
INFO - 2023-07-01 03:18:41 --> Utf8 Class Initialized
INFO - 2023-07-01 03:18:41 --> URI Class Initialized
INFO - 2023-07-01 03:18:41 --> Router Class Initialized
INFO - 2023-07-01 03:18:41 --> Output Class Initialized
INFO - 2023-07-01 03:18:41 --> Security Class Initialized
DEBUG - 2023-07-01 03:18:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-01 03:18:41 --> Input Class Initialized
INFO - 2023-07-01 03:18:41 --> Language Class Initialized
INFO - 2023-07-01 03:18:41 --> Loader Class Initialized
INFO - 2023-07-01 03:18:41 --> Helper loaded: url_helper
INFO - 2023-07-01 03:18:41 --> Helper loaded: file_helper
INFO - 2023-07-01 03:18:41 --> Helper loaded: html_helper
INFO - 2023-07-01 03:18:41 --> Helper loaded: text_helper
INFO - 2023-07-01 03:18:41 --> Helper loaded: form_helper
INFO - 2023-07-01 03:18:41 --> Helper loaded: lang_helper
INFO - 2023-07-01 03:18:41 --> Helper loaded: security_helper
INFO - 2023-07-01 03:18:41 --> Helper loaded: cookie_helper
INFO - 2023-07-01 03:18:41 --> Database Driver Class Initialized
INFO - 2023-07-01 03:18:41 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-01 03:18:41 --> Parser Class Initialized
INFO - 2023-07-01 03:18:41 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-01 03:18:41 --> Pagination Class Initialized
INFO - 2023-07-01 03:18:41 --> Form Validation Class Initialized
INFO - 2023-07-01 03:18:41 --> Controller Class Initialized
ERROR - 2023-07-01 03:18:41 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-01 03:18:41 --> Config Class Initialized
INFO - 2023-07-01 03:18:41 --> Hooks Class Initialized
DEBUG - 2023-07-01 03:18:41 --> UTF-8 Support Enabled
INFO - 2023-07-01 03:18:41 --> Utf8 Class Initialized
INFO - 2023-07-01 03:18:41 --> URI Class Initialized
INFO - 2023-07-01 03:18:41 --> Router Class Initialized
INFO - 2023-07-01 03:18:41 --> Output Class Initialized
INFO - 2023-07-01 03:18:41 --> Security Class Initialized
DEBUG - 2023-07-01 03:18:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-01 03:18:41 --> Input Class Initialized
INFO - 2023-07-01 03:18:41 --> Language Class Initialized
INFO - 2023-07-01 03:18:41 --> Loader Class Initialized
INFO - 2023-07-01 03:18:41 --> Helper loaded: url_helper
INFO - 2023-07-01 03:18:41 --> Helper loaded: file_helper
INFO - 2023-07-01 03:18:41 --> Helper loaded: html_helper
INFO - 2023-07-01 03:18:41 --> Helper loaded: text_helper
INFO - 2023-07-01 03:18:41 --> Helper loaded: form_helper
INFO - 2023-07-01 03:18:41 --> Helper loaded: lang_helper
INFO - 2023-07-01 03:18:41 --> Helper loaded: security_helper
INFO - 2023-07-01 03:18:41 --> Helper loaded: cookie_helper
INFO - 2023-07-01 03:18:41 --> Database Driver Class Initialized
INFO - 2023-07-01 03:18:41 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-01 03:18:41 --> Parser Class Initialized
INFO - 2023-07-01 03:18:41 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-01 03:18:41 --> Pagination Class Initialized
INFO - 2023-07-01 03:18:41 --> Form Validation Class Initialized
INFO - 2023-07-01 03:18:41 --> Controller Class Initialized
INFO - 2023-07-01 03:18:41 --> Model Class Initialized
DEBUG - 2023-07-01 03:18:41 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-01 03:18:41 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2023-07-01 03:18:41 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-07-01 03:18:41 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-07-01 03:18:41 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-07-01 03:18:41 --> Model Class Initialized
INFO - 2023-07-01 03:18:41 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-07-01 03:18:41 --> Final output sent to browser
DEBUG - 2023-07-01 03:18:41 --> Total execution time: 0.0268
ERROR - 2023-07-01 03:18:51 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-01 03:18:51 --> Config Class Initialized
INFO - 2023-07-01 03:18:51 --> Hooks Class Initialized
DEBUG - 2023-07-01 03:18:51 --> UTF-8 Support Enabled
INFO - 2023-07-01 03:18:51 --> Utf8 Class Initialized
INFO - 2023-07-01 03:18:51 --> URI Class Initialized
DEBUG - 2023-07-01 03:18:51 --> No URI present. Default controller set.
INFO - 2023-07-01 03:18:51 --> Router Class Initialized
INFO - 2023-07-01 03:18:51 --> Output Class Initialized
INFO - 2023-07-01 03:18:51 --> Security Class Initialized
DEBUG - 2023-07-01 03:18:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-01 03:18:51 --> Input Class Initialized
INFO - 2023-07-01 03:18:51 --> Language Class Initialized
INFO - 2023-07-01 03:18:51 --> Loader Class Initialized
INFO - 2023-07-01 03:18:51 --> Helper loaded: url_helper
INFO - 2023-07-01 03:18:51 --> Helper loaded: file_helper
INFO - 2023-07-01 03:18:51 --> Helper loaded: html_helper
INFO - 2023-07-01 03:18:51 --> Helper loaded: text_helper
INFO - 2023-07-01 03:18:51 --> Helper loaded: form_helper
INFO - 2023-07-01 03:18:51 --> Helper loaded: lang_helper
INFO - 2023-07-01 03:18:51 --> Helper loaded: security_helper
INFO - 2023-07-01 03:18:51 --> Helper loaded: cookie_helper
INFO - 2023-07-01 03:18:51 --> Database Driver Class Initialized
INFO - 2023-07-01 03:18:51 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-01 03:18:51 --> Parser Class Initialized
INFO - 2023-07-01 03:18:51 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-01 03:18:51 --> Pagination Class Initialized
INFO - 2023-07-01 03:18:51 --> Form Validation Class Initialized
INFO - 2023-07-01 03:18:51 --> Controller Class Initialized
INFO - 2023-07-01 03:18:51 --> Model Class Initialized
DEBUG - 2023-07-01 03:18:51 --> Session class already loaded. Second attempt ignored.
ERROR - 2023-07-01 03:18:51 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-01 03:18:51 --> Config Class Initialized
INFO - 2023-07-01 03:18:51 --> Hooks Class Initialized
DEBUG - 2023-07-01 03:18:51 --> UTF-8 Support Enabled
INFO - 2023-07-01 03:18:51 --> Utf8 Class Initialized
INFO - 2023-07-01 03:18:51 --> URI Class Initialized
INFO - 2023-07-01 03:18:51 --> Router Class Initialized
INFO - 2023-07-01 03:18:51 --> Output Class Initialized
INFO - 2023-07-01 03:18:51 --> Security Class Initialized
DEBUG - 2023-07-01 03:18:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-01 03:18:51 --> Input Class Initialized
INFO - 2023-07-01 03:18:51 --> Language Class Initialized
INFO - 2023-07-01 03:18:51 --> Loader Class Initialized
INFO - 2023-07-01 03:18:51 --> Helper loaded: url_helper
INFO - 2023-07-01 03:18:51 --> Helper loaded: file_helper
INFO - 2023-07-01 03:18:51 --> Helper loaded: html_helper
INFO - 2023-07-01 03:18:51 --> Helper loaded: text_helper
INFO - 2023-07-01 03:18:51 --> Helper loaded: form_helper
INFO - 2023-07-01 03:18:51 --> Helper loaded: lang_helper
INFO - 2023-07-01 03:18:51 --> Helper loaded: security_helper
INFO - 2023-07-01 03:18:51 --> Helper loaded: cookie_helper
INFO - 2023-07-01 03:18:51 --> Database Driver Class Initialized
INFO - 2023-07-01 03:18:51 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-01 03:18:51 --> Parser Class Initialized
INFO - 2023-07-01 03:18:51 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-01 03:18:51 --> Pagination Class Initialized
INFO - 2023-07-01 03:18:51 --> Form Validation Class Initialized
INFO - 2023-07-01 03:18:51 --> Controller Class Initialized
INFO - 2023-07-01 03:18:51 --> Model Class Initialized
DEBUG - 2023-07-01 03:18:51 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-01 03:18:51 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2023-07-01 03:18:51 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-07-01 03:18:51 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-07-01 03:18:51 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-07-01 03:18:51 --> Model Class Initialized
INFO - 2023-07-01 03:18:51 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-07-01 03:18:51 --> Final output sent to browser
DEBUG - 2023-07-01 03:18:51 --> Total execution time: 0.0283
ERROR - 2023-07-01 04:05:05 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-01 04:05:05 --> Config Class Initialized
INFO - 2023-07-01 04:05:05 --> Hooks Class Initialized
DEBUG - 2023-07-01 04:05:05 --> UTF-8 Support Enabled
INFO - 2023-07-01 04:05:05 --> Utf8 Class Initialized
INFO - 2023-07-01 04:05:05 --> URI Class Initialized
DEBUG - 2023-07-01 04:05:05 --> No URI present. Default controller set.
INFO - 2023-07-01 04:05:05 --> Router Class Initialized
INFO - 2023-07-01 04:05:05 --> Output Class Initialized
INFO - 2023-07-01 04:05:05 --> Security Class Initialized
DEBUG - 2023-07-01 04:05:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-01 04:05:05 --> Input Class Initialized
INFO - 2023-07-01 04:05:05 --> Language Class Initialized
INFO - 2023-07-01 04:05:05 --> Loader Class Initialized
INFO - 2023-07-01 04:05:05 --> Helper loaded: url_helper
INFO - 2023-07-01 04:05:05 --> Helper loaded: file_helper
INFO - 2023-07-01 04:05:05 --> Helper loaded: html_helper
INFO - 2023-07-01 04:05:05 --> Helper loaded: text_helper
INFO - 2023-07-01 04:05:05 --> Helper loaded: form_helper
INFO - 2023-07-01 04:05:05 --> Helper loaded: lang_helper
INFO - 2023-07-01 04:05:05 --> Helper loaded: security_helper
INFO - 2023-07-01 04:05:05 --> Helper loaded: cookie_helper
INFO - 2023-07-01 04:05:05 --> Database Driver Class Initialized
INFO - 2023-07-01 04:05:05 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-01 04:05:05 --> Parser Class Initialized
INFO - 2023-07-01 04:05:05 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-01 04:05:05 --> Pagination Class Initialized
INFO - 2023-07-01 04:05:05 --> Form Validation Class Initialized
INFO - 2023-07-01 04:05:05 --> Controller Class Initialized
INFO - 2023-07-01 04:05:05 --> Model Class Initialized
DEBUG - 2023-07-01 04:05:05 --> Session class already loaded. Second attempt ignored.
ERROR - 2023-07-01 04:05:06 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-01 04:05:06 --> Config Class Initialized
INFO - 2023-07-01 04:05:06 --> Hooks Class Initialized
DEBUG - 2023-07-01 04:05:06 --> UTF-8 Support Enabled
INFO - 2023-07-01 04:05:06 --> Utf8 Class Initialized
INFO - 2023-07-01 04:05:06 --> URI Class Initialized
INFO - 2023-07-01 04:05:06 --> Router Class Initialized
INFO - 2023-07-01 04:05:06 --> Output Class Initialized
INFO - 2023-07-01 04:05:06 --> Security Class Initialized
DEBUG - 2023-07-01 04:05:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-01 04:05:06 --> Input Class Initialized
INFO - 2023-07-01 04:05:06 --> Language Class Initialized
INFO - 2023-07-01 04:05:06 --> Loader Class Initialized
INFO - 2023-07-01 04:05:06 --> Helper loaded: url_helper
INFO - 2023-07-01 04:05:06 --> Helper loaded: file_helper
INFO - 2023-07-01 04:05:06 --> Helper loaded: html_helper
INFO - 2023-07-01 04:05:06 --> Helper loaded: text_helper
INFO - 2023-07-01 04:05:06 --> Helper loaded: form_helper
INFO - 2023-07-01 04:05:06 --> Helper loaded: lang_helper
INFO - 2023-07-01 04:05:06 --> Helper loaded: security_helper
INFO - 2023-07-01 04:05:06 --> Helper loaded: cookie_helper
INFO - 2023-07-01 04:05:06 --> Database Driver Class Initialized
INFO - 2023-07-01 04:05:06 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-01 04:05:06 --> Parser Class Initialized
INFO - 2023-07-01 04:05:06 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-01 04:05:06 --> Pagination Class Initialized
INFO - 2023-07-01 04:05:06 --> Form Validation Class Initialized
INFO - 2023-07-01 04:05:06 --> Controller Class Initialized
INFO - 2023-07-01 04:05:06 --> Model Class Initialized
DEBUG - 2023-07-01 04:05:06 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-01 04:05:06 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2023-07-01 04:05:06 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-07-01 04:05:06 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-07-01 04:05:06 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-07-01 04:05:06 --> Model Class Initialized
INFO - 2023-07-01 04:05:06 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-07-01 04:05:06 --> Final output sent to browser
DEBUG - 2023-07-01 04:05:06 --> Total execution time: 0.0314
ERROR - 2023-07-01 04:05:09 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-01 04:05:09 --> Config Class Initialized
INFO - 2023-07-01 04:05:09 --> Hooks Class Initialized
DEBUG - 2023-07-01 04:05:09 --> UTF-8 Support Enabled
INFO - 2023-07-01 04:05:09 --> Utf8 Class Initialized
INFO - 2023-07-01 04:05:09 --> URI Class Initialized
INFO - 2023-07-01 04:05:09 --> Router Class Initialized
INFO - 2023-07-01 04:05:09 --> Output Class Initialized
INFO - 2023-07-01 04:05:09 --> Security Class Initialized
DEBUG - 2023-07-01 04:05:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-01 04:05:09 --> Input Class Initialized
INFO - 2023-07-01 04:05:09 --> Language Class Initialized
INFO - 2023-07-01 04:05:09 --> Loader Class Initialized
INFO - 2023-07-01 04:05:09 --> Helper loaded: url_helper
INFO - 2023-07-01 04:05:09 --> Helper loaded: file_helper
INFO - 2023-07-01 04:05:09 --> Helper loaded: html_helper
INFO - 2023-07-01 04:05:09 --> Helper loaded: text_helper
INFO - 2023-07-01 04:05:09 --> Helper loaded: form_helper
INFO - 2023-07-01 04:05:09 --> Helper loaded: lang_helper
INFO - 2023-07-01 04:05:09 --> Helper loaded: security_helper
INFO - 2023-07-01 04:05:09 --> Helper loaded: cookie_helper
INFO - 2023-07-01 04:05:09 --> Database Driver Class Initialized
INFO - 2023-07-01 04:05:09 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-01 04:05:09 --> Parser Class Initialized
INFO - 2023-07-01 04:05:09 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-01 04:05:09 --> Pagination Class Initialized
INFO - 2023-07-01 04:05:09 --> Form Validation Class Initialized
INFO - 2023-07-01 04:05:09 --> Controller Class Initialized
INFO - 2023-07-01 04:05:09 --> Model Class Initialized
DEBUG - 2023-07-01 04:05:09 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-01 04:05:09 --> Model Class Initialized
INFO - 2023-07-01 04:05:09 --> Final output sent to browser
DEBUG - 2023-07-01 04:05:09 --> Total execution time: 0.0184
ERROR - 2023-07-01 04:05:09 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-01 04:05:09 --> Config Class Initialized
INFO - 2023-07-01 04:05:09 --> Hooks Class Initialized
DEBUG - 2023-07-01 04:05:09 --> UTF-8 Support Enabled
INFO - 2023-07-01 04:05:09 --> Utf8 Class Initialized
INFO - 2023-07-01 04:05:09 --> URI Class Initialized
DEBUG - 2023-07-01 04:05:09 --> No URI present. Default controller set.
INFO - 2023-07-01 04:05:09 --> Router Class Initialized
INFO - 2023-07-01 04:05:09 --> Output Class Initialized
INFO - 2023-07-01 04:05:09 --> Security Class Initialized
DEBUG - 2023-07-01 04:05:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-01 04:05:09 --> Input Class Initialized
INFO - 2023-07-01 04:05:09 --> Language Class Initialized
INFO - 2023-07-01 04:05:09 --> Loader Class Initialized
INFO - 2023-07-01 04:05:09 --> Helper loaded: url_helper
INFO - 2023-07-01 04:05:09 --> Helper loaded: file_helper
INFO - 2023-07-01 04:05:09 --> Helper loaded: html_helper
INFO - 2023-07-01 04:05:09 --> Helper loaded: text_helper
INFO - 2023-07-01 04:05:09 --> Helper loaded: form_helper
INFO - 2023-07-01 04:05:09 --> Helper loaded: lang_helper
INFO - 2023-07-01 04:05:09 --> Helper loaded: security_helper
INFO - 2023-07-01 04:05:09 --> Helper loaded: cookie_helper
INFO - 2023-07-01 04:05:09 --> Database Driver Class Initialized
INFO - 2023-07-01 04:05:09 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-01 04:05:09 --> Parser Class Initialized
INFO - 2023-07-01 04:05:09 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-01 04:05:09 --> Pagination Class Initialized
INFO - 2023-07-01 04:05:09 --> Form Validation Class Initialized
INFO - 2023-07-01 04:05:09 --> Controller Class Initialized
INFO - 2023-07-01 04:05:09 --> Model Class Initialized
DEBUG - 2023-07-01 04:05:09 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-01 04:05:09 --> Model Class Initialized
DEBUG - 2023-07-01 04:05:09 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-01 04:05:09 --> Model Class Initialized
INFO - 2023-07-01 04:05:09 --> Model Class Initialized
INFO - 2023-07-01 04:05:09 --> Model Class Initialized
INFO - 2023-07-01 04:05:09 --> Model Class Initialized
DEBUG - 2023-07-01 04:05:09 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-01 04:05:09 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-01 04:05:09 --> Model Class Initialized
INFO - 2023-07-01 04:05:09 --> Model Class Initialized
INFO - 2023-07-01 04:05:09 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-07-01 04:05:09 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-07-01 04:05:09 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-07-01 04:05:09 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-07-01 04:05:09 --> Model Class Initialized
INFO - 2023-07-01 04:05:09 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-07-01 04:05:09 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-07-01 04:05:09 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-07-01 04:05:09 --> Final output sent to browser
DEBUG - 2023-07-01 04:05:09 --> Total execution time: 0.1769
ERROR - 2023-07-01 04:05:11 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-01 04:05:11 --> Config Class Initialized
INFO - 2023-07-01 04:05:11 --> Hooks Class Initialized
DEBUG - 2023-07-01 04:05:11 --> UTF-8 Support Enabled
INFO - 2023-07-01 04:05:11 --> Utf8 Class Initialized
INFO - 2023-07-01 04:05:11 --> URI Class Initialized
INFO - 2023-07-01 04:05:11 --> Router Class Initialized
INFO - 2023-07-01 04:05:11 --> Output Class Initialized
INFO - 2023-07-01 04:05:11 --> Security Class Initialized
DEBUG - 2023-07-01 04:05:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-01 04:05:11 --> Input Class Initialized
INFO - 2023-07-01 04:05:11 --> Language Class Initialized
INFO - 2023-07-01 04:05:11 --> Loader Class Initialized
INFO - 2023-07-01 04:05:11 --> Helper loaded: url_helper
INFO - 2023-07-01 04:05:11 --> Helper loaded: file_helper
INFO - 2023-07-01 04:05:11 --> Helper loaded: html_helper
INFO - 2023-07-01 04:05:11 --> Helper loaded: text_helper
INFO - 2023-07-01 04:05:11 --> Helper loaded: form_helper
INFO - 2023-07-01 04:05:11 --> Helper loaded: lang_helper
INFO - 2023-07-01 04:05:11 --> Helper loaded: security_helper
INFO - 2023-07-01 04:05:11 --> Helper loaded: cookie_helper
INFO - 2023-07-01 04:05:11 --> Database Driver Class Initialized
INFO - 2023-07-01 04:05:11 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-01 04:05:11 --> Parser Class Initialized
INFO - 2023-07-01 04:05:11 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-01 04:05:11 --> Pagination Class Initialized
INFO - 2023-07-01 04:05:11 --> Form Validation Class Initialized
INFO - 2023-07-01 04:05:11 --> Controller Class Initialized
DEBUG - 2023-07-01 04:05:11 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-01 04:05:11 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-01 04:05:11 --> Model Class Initialized
INFO - 2023-07-01 04:05:11 --> Final output sent to browser
DEBUG - 2023-07-01 04:05:11 --> Total execution time: 0.0133
ERROR - 2023-07-01 04:05:25 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-01 04:05:25 --> Config Class Initialized
INFO - 2023-07-01 04:05:25 --> Hooks Class Initialized
DEBUG - 2023-07-01 04:05:25 --> UTF-8 Support Enabled
INFO - 2023-07-01 04:05:25 --> Utf8 Class Initialized
INFO - 2023-07-01 04:05:25 --> URI Class Initialized
DEBUG - 2023-07-01 04:05:25 --> No URI present. Default controller set.
INFO - 2023-07-01 04:05:25 --> Router Class Initialized
INFO - 2023-07-01 04:05:25 --> Output Class Initialized
INFO - 2023-07-01 04:05:25 --> Security Class Initialized
DEBUG - 2023-07-01 04:05:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-01 04:05:25 --> Input Class Initialized
INFO - 2023-07-01 04:05:25 --> Language Class Initialized
INFO - 2023-07-01 04:05:25 --> Loader Class Initialized
INFO - 2023-07-01 04:05:25 --> Helper loaded: url_helper
INFO - 2023-07-01 04:05:25 --> Helper loaded: file_helper
INFO - 2023-07-01 04:05:25 --> Helper loaded: html_helper
INFO - 2023-07-01 04:05:25 --> Helper loaded: text_helper
INFO - 2023-07-01 04:05:25 --> Helper loaded: form_helper
INFO - 2023-07-01 04:05:25 --> Helper loaded: lang_helper
INFO - 2023-07-01 04:05:25 --> Helper loaded: security_helper
INFO - 2023-07-01 04:05:25 --> Helper loaded: cookie_helper
INFO - 2023-07-01 04:05:25 --> Database Driver Class Initialized
INFO - 2023-07-01 04:05:25 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-01 04:05:25 --> Parser Class Initialized
INFO - 2023-07-01 04:05:25 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-01 04:05:25 --> Pagination Class Initialized
INFO - 2023-07-01 04:05:25 --> Form Validation Class Initialized
INFO - 2023-07-01 04:05:25 --> Controller Class Initialized
INFO - 2023-07-01 04:05:25 --> Model Class Initialized
DEBUG - 2023-07-01 04:05:25 --> Session class already loaded. Second attempt ignored.
ERROR - 2023-07-01 04:05:26 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-01 04:05:26 --> Config Class Initialized
INFO - 2023-07-01 04:05:26 --> Hooks Class Initialized
DEBUG - 2023-07-01 04:05:26 --> UTF-8 Support Enabled
INFO - 2023-07-01 04:05:26 --> Utf8 Class Initialized
INFO - 2023-07-01 04:05:26 --> URI Class Initialized
INFO - 2023-07-01 04:05:26 --> Router Class Initialized
INFO - 2023-07-01 04:05:26 --> Output Class Initialized
INFO - 2023-07-01 04:05:26 --> Security Class Initialized
DEBUG - 2023-07-01 04:05:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-01 04:05:26 --> Input Class Initialized
INFO - 2023-07-01 04:05:26 --> Language Class Initialized
INFO - 2023-07-01 04:05:26 --> Loader Class Initialized
INFO - 2023-07-01 04:05:26 --> Helper loaded: url_helper
INFO - 2023-07-01 04:05:26 --> Helper loaded: file_helper
INFO - 2023-07-01 04:05:26 --> Helper loaded: html_helper
INFO - 2023-07-01 04:05:26 --> Helper loaded: text_helper
INFO - 2023-07-01 04:05:26 --> Helper loaded: form_helper
INFO - 2023-07-01 04:05:26 --> Helper loaded: lang_helper
INFO - 2023-07-01 04:05:26 --> Helper loaded: security_helper
INFO - 2023-07-01 04:05:26 --> Helper loaded: cookie_helper
INFO - 2023-07-01 04:05:26 --> Database Driver Class Initialized
INFO - 2023-07-01 04:05:26 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-01 04:05:26 --> Parser Class Initialized
INFO - 2023-07-01 04:05:26 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-01 04:05:26 --> Pagination Class Initialized
INFO - 2023-07-01 04:05:26 --> Form Validation Class Initialized
INFO - 2023-07-01 04:05:26 --> Controller Class Initialized
INFO - 2023-07-01 04:05:26 --> Model Class Initialized
DEBUG - 2023-07-01 04:05:26 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-01 04:05:26 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2023-07-01 04:05:26 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-07-01 04:05:26 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-07-01 04:05:26 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-07-01 04:05:26 --> Model Class Initialized
INFO - 2023-07-01 04:05:26 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-07-01 04:05:26 --> Final output sent to browser
DEBUG - 2023-07-01 04:05:26 --> Total execution time: 0.0262
ERROR - 2023-07-01 04:05:38 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-01 04:05:38 --> Config Class Initialized
INFO - 2023-07-01 04:05:38 --> Hooks Class Initialized
DEBUG - 2023-07-01 04:05:38 --> UTF-8 Support Enabled
INFO - 2023-07-01 04:05:38 --> Utf8 Class Initialized
INFO - 2023-07-01 04:05:38 --> URI Class Initialized
INFO - 2023-07-01 04:05:38 --> Router Class Initialized
INFO - 2023-07-01 04:05:38 --> Output Class Initialized
INFO - 2023-07-01 04:05:38 --> Security Class Initialized
DEBUG - 2023-07-01 04:05:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-01 04:05:38 --> Input Class Initialized
INFO - 2023-07-01 04:05:38 --> Language Class Initialized
INFO - 2023-07-01 04:05:38 --> Loader Class Initialized
INFO - 2023-07-01 04:05:38 --> Helper loaded: url_helper
INFO - 2023-07-01 04:05:38 --> Helper loaded: file_helper
INFO - 2023-07-01 04:05:38 --> Helper loaded: html_helper
INFO - 2023-07-01 04:05:38 --> Helper loaded: text_helper
INFO - 2023-07-01 04:05:38 --> Helper loaded: form_helper
INFO - 2023-07-01 04:05:38 --> Helper loaded: lang_helper
INFO - 2023-07-01 04:05:38 --> Helper loaded: security_helper
INFO - 2023-07-01 04:05:38 --> Helper loaded: cookie_helper
INFO - 2023-07-01 04:05:38 --> Database Driver Class Initialized
INFO - 2023-07-01 04:05:38 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-01 04:05:38 --> Parser Class Initialized
INFO - 2023-07-01 04:05:38 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-01 04:05:38 --> Pagination Class Initialized
INFO - 2023-07-01 04:05:38 --> Form Validation Class Initialized
INFO - 2023-07-01 04:05:38 --> Controller Class Initialized
DEBUG - 2023-07-01 04:05:38 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-01 04:05:38 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-01 04:05:38 --> Model Class Initialized
DEBUG - 2023-07-01 04:05:38 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-01 04:05:38 --> Model Class Initialized
DEBUG - 2023-07-01 04:05:38 --> Lcustomer class already loaded. Second attempt ignored.
INFO - 2023-07-01 04:05:38 --> Model Class Initialized
INFO - 2023-07-01 04:05:38 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/customer/customer.php
DEBUG - 2023-07-01 04:05:38 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-07-01 04:05:38 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-07-01 04:05:38 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-07-01 04:05:38 --> Model Class Initialized
INFO - 2023-07-01 04:05:38 --> Model Class Initialized
INFO - 2023-07-01 04:05:38 --> Model Class Initialized
INFO - 2023-07-01 04:05:39 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-07-01 04:05:39 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-07-01 04:05:39 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-07-01 04:05:39 --> Final output sent to browser
DEBUG - 2023-07-01 04:05:39 --> Total execution time: 0.1431
ERROR - 2023-07-01 04:05:39 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-01 04:05:39 --> Config Class Initialized
INFO - 2023-07-01 04:05:39 --> Hooks Class Initialized
DEBUG - 2023-07-01 04:05:39 --> UTF-8 Support Enabled
INFO - 2023-07-01 04:05:39 --> Utf8 Class Initialized
INFO - 2023-07-01 04:05:39 --> URI Class Initialized
INFO - 2023-07-01 04:05:39 --> Router Class Initialized
INFO - 2023-07-01 04:05:39 --> Output Class Initialized
INFO - 2023-07-01 04:05:39 --> Security Class Initialized
DEBUG - 2023-07-01 04:05:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-01 04:05:39 --> Input Class Initialized
INFO - 2023-07-01 04:05:39 --> Language Class Initialized
INFO - 2023-07-01 04:05:39 --> Loader Class Initialized
INFO - 2023-07-01 04:05:39 --> Helper loaded: url_helper
INFO - 2023-07-01 04:05:39 --> Helper loaded: file_helper
INFO - 2023-07-01 04:05:39 --> Helper loaded: html_helper
INFO - 2023-07-01 04:05:39 --> Helper loaded: text_helper
INFO - 2023-07-01 04:05:39 --> Helper loaded: form_helper
INFO - 2023-07-01 04:05:39 --> Helper loaded: lang_helper
INFO - 2023-07-01 04:05:39 --> Helper loaded: security_helper
INFO - 2023-07-01 04:05:39 --> Helper loaded: cookie_helper
INFO - 2023-07-01 04:05:39 --> Database Driver Class Initialized
INFO - 2023-07-01 04:05:39 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-01 04:05:39 --> Parser Class Initialized
INFO - 2023-07-01 04:05:39 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-01 04:05:39 --> Pagination Class Initialized
INFO - 2023-07-01 04:05:39 --> Form Validation Class Initialized
INFO - 2023-07-01 04:05:39 --> Controller Class Initialized
DEBUG - 2023-07-01 04:05:39 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-01 04:05:39 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-01 04:05:39 --> Model Class Initialized
DEBUG - 2023-07-01 04:05:39 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-01 04:05:39 --> Model Class Initialized
INFO - 2023-07-01 04:05:39 --> Final output sent to browser
DEBUG - 2023-07-01 04:05:39 --> Total execution time: 0.0301
ERROR - 2023-07-01 04:05:44 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-01 04:05:44 --> Config Class Initialized
INFO - 2023-07-01 04:05:44 --> Hooks Class Initialized
DEBUG - 2023-07-01 04:05:44 --> UTF-8 Support Enabled
INFO - 2023-07-01 04:05:44 --> Utf8 Class Initialized
INFO - 2023-07-01 04:05:44 --> URI Class Initialized
INFO - 2023-07-01 04:05:44 --> Router Class Initialized
INFO - 2023-07-01 04:05:44 --> Output Class Initialized
INFO - 2023-07-01 04:05:44 --> Security Class Initialized
DEBUG - 2023-07-01 04:05:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-01 04:05:44 --> Input Class Initialized
INFO - 2023-07-01 04:05:44 --> Language Class Initialized
INFO - 2023-07-01 04:05:44 --> Loader Class Initialized
INFO - 2023-07-01 04:05:44 --> Helper loaded: url_helper
INFO - 2023-07-01 04:05:44 --> Helper loaded: file_helper
INFO - 2023-07-01 04:05:44 --> Helper loaded: html_helper
INFO - 2023-07-01 04:05:44 --> Helper loaded: text_helper
INFO - 2023-07-01 04:05:44 --> Helper loaded: form_helper
INFO - 2023-07-01 04:05:44 --> Helper loaded: lang_helper
INFO - 2023-07-01 04:05:44 --> Helper loaded: security_helper
INFO - 2023-07-01 04:05:44 --> Helper loaded: cookie_helper
INFO - 2023-07-01 04:05:44 --> Database Driver Class Initialized
INFO - 2023-07-01 04:05:44 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-01 04:05:44 --> Parser Class Initialized
INFO - 2023-07-01 04:05:44 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-01 04:05:44 --> Pagination Class Initialized
INFO - 2023-07-01 04:05:44 --> Form Validation Class Initialized
INFO - 2023-07-01 04:05:44 --> Controller Class Initialized
DEBUG - 2023-07-01 04:05:44 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-01 04:05:44 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-01 04:05:44 --> Model Class Initialized
DEBUG - 2023-07-01 04:05:44 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-01 04:05:44 --> Model Class Initialized
INFO - 2023-07-01 04:05:44 --> Final output sent to browser
DEBUG - 2023-07-01 04:05:44 --> Total execution time: 0.1097
ERROR - 2023-07-01 04:06:04 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-01 04:06:04 --> Config Class Initialized
INFO - 2023-07-01 04:06:04 --> Hooks Class Initialized
DEBUG - 2023-07-01 04:06:04 --> UTF-8 Support Enabled
INFO - 2023-07-01 04:06:04 --> Utf8 Class Initialized
INFO - 2023-07-01 04:06:04 --> URI Class Initialized
INFO - 2023-07-01 04:06:04 --> Router Class Initialized
INFO - 2023-07-01 04:06:04 --> Output Class Initialized
INFO - 2023-07-01 04:06:04 --> Security Class Initialized
DEBUG - 2023-07-01 04:06:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-01 04:06:04 --> Input Class Initialized
INFO - 2023-07-01 04:06:04 --> Language Class Initialized
INFO - 2023-07-01 04:06:04 --> Loader Class Initialized
INFO - 2023-07-01 04:06:04 --> Helper loaded: url_helper
INFO - 2023-07-01 04:06:04 --> Helper loaded: file_helper
INFO - 2023-07-01 04:06:04 --> Helper loaded: html_helper
INFO - 2023-07-01 04:06:04 --> Helper loaded: text_helper
INFO - 2023-07-01 04:06:04 --> Helper loaded: form_helper
INFO - 2023-07-01 04:06:04 --> Helper loaded: lang_helper
INFO - 2023-07-01 04:06:04 --> Helper loaded: security_helper
INFO - 2023-07-01 04:06:04 --> Helper loaded: cookie_helper
INFO - 2023-07-01 04:06:04 --> Database Driver Class Initialized
INFO - 2023-07-01 04:06:04 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-01 04:06:04 --> Parser Class Initialized
INFO - 2023-07-01 04:06:04 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-01 04:06:04 --> Pagination Class Initialized
INFO - 2023-07-01 04:06:04 --> Form Validation Class Initialized
INFO - 2023-07-01 04:06:04 --> Controller Class Initialized
DEBUG - 2023-07-01 04:06:04 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-01 04:06:04 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-01 04:06:04 --> Model Class Initialized
DEBUG - 2023-07-01 04:06:04 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-01 04:06:04 --> Model Class Initialized
INFO - 2023-07-01 04:06:04 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/customer/view_customer.php
DEBUG - 2023-07-01 04:06:04 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-07-01 04:06:04 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-07-01 04:06:04 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-07-01 04:06:04 --> Model Class Initialized
INFO - 2023-07-01 04:06:04 --> Model Class Initialized
INFO - 2023-07-01 04:06:04 --> Model Class Initialized
INFO - 2023-07-01 04:06:04 --> Model Class Initialized
INFO - 2023-07-01 04:06:04 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-07-01 04:06:04 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-07-01 04:06:04 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-07-01 04:06:04 --> Final output sent to browser
DEBUG - 2023-07-01 04:06:04 --> Total execution time: 0.1212
ERROR - 2023-07-01 04:06:29 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-01 04:06:29 --> Config Class Initialized
INFO - 2023-07-01 04:06:29 --> Hooks Class Initialized
DEBUG - 2023-07-01 04:06:29 --> UTF-8 Support Enabled
INFO - 2023-07-01 04:06:29 --> Utf8 Class Initialized
INFO - 2023-07-01 04:06:29 --> URI Class Initialized
INFO - 2023-07-01 04:06:29 --> Router Class Initialized
INFO - 2023-07-01 04:06:29 --> Output Class Initialized
INFO - 2023-07-01 04:06:29 --> Security Class Initialized
DEBUG - 2023-07-01 04:06:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-01 04:06:29 --> Input Class Initialized
INFO - 2023-07-01 04:06:29 --> Language Class Initialized
INFO - 2023-07-01 04:06:29 --> Loader Class Initialized
INFO - 2023-07-01 04:06:29 --> Helper loaded: url_helper
INFO - 2023-07-01 04:06:29 --> Helper loaded: file_helper
INFO - 2023-07-01 04:06:29 --> Helper loaded: html_helper
INFO - 2023-07-01 04:06:29 --> Helper loaded: text_helper
INFO - 2023-07-01 04:06:29 --> Helper loaded: form_helper
INFO - 2023-07-01 04:06:29 --> Helper loaded: lang_helper
INFO - 2023-07-01 04:06:29 --> Helper loaded: security_helper
INFO - 2023-07-01 04:06:29 --> Helper loaded: cookie_helper
INFO - 2023-07-01 04:06:29 --> Database Driver Class Initialized
INFO - 2023-07-01 04:06:29 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-01 04:06:29 --> Parser Class Initialized
INFO - 2023-07-01 04:06:29 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-01 04:06:29 --> Pagination Class Initialized
INFO - 2023-07-01 04:06:29 --> Form Validation Class Initialized
INFO - 2023-07-01 04:06:29 --> Controller Class Initialized
INFO - 2023-07-01 04:06:29 --> Model Class Initialized
DEBUG - 2023-07-01 04:06:29 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-01 04:06:29 --> Model Class Initialized
INFO - 2023-07-01 04:06:29 --> Final output sent to browser
DEBUG - 2023-07-01 04:06:29 --> Total execution time: 0.0194
ERROR - 2023-07-01 04:06:29 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-01 04:06:29 --> Config Class Initialized
INFO - 2023-07-01 04:06:29 --> Hooks Class Initialized
DEBUG - 2023-07-01 04:06:29 --> UTF-8 Support Enabled
INFO - 2023-07-01 04:06:29 --> Utf8 Class Initialized
INFO - 2023-07-01 04:06:29 --> URI Class Initialized
DEBUG - 2023-07-01 04:06:29 --> No URI present. Default controller set.
INFO - 2023-07-01 04:06:29 --> Router Class Initialized
INFO - 2023-07-01 04:06:29 --> Output Class Initialized
INFO - 2023-07-01 04:06:29 --> Security Class Initialized
DEBUG - 2023-07-01 04:06:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-01 04:06:29 --> Input Class Initialized
INFO - 2023-07-01 04:06:29 --> Language Class Initialized
INFO - 2023-07-01 04:06:29 --> Loader Class Initialized
INFO - 2023-07-01 04:06:29 --> Helper loaded: url_helper
INFO - 2023-07-01 04:06:29 --> Helper loaded: file_helper
INFO - 2023-07-01 04:06:29 --> Helper loaded: html_helper
INFO - 2023-07-01 04:06:29 --> Helper loaded: text_helper
INFO - 2023-07-01 04:06:29 --> Helper loaded: form_helper
INFO - 2023-07-01 04:06:29 --> Helper loaded: lang_helper
INFO - 2023-07-01 04:06:29 --> Helper loaded: security_helper
INFO - 2023-07-01 04:06:29 --> Helper loaded: cookie_helper
INFO - 2023-07-01 04:06:29 --> Database Driver Class Initialized
INFO - 2023-07-01 04:06:29 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-01 04:06:29 --> Parser Class Initialized
INFO - 2023-07-01 04:06:29 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-01 04:06:29 --> Pagination Class Initialized
INFO - 2023-07-01 04:06:29 --> Form Validation Class Initialized
INFO - 2023-07-01 04:06:29 --> Controller Class Initialized
INFO - 2023-07-01 04:06:29 --> Model Class Initialized
DEBUG - 2023-07-01 04:06:29 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-01 04:06:29 --> Model Class Initialized
DEBUG - 2023-07-01 04:06:29 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-01 04:06:29 --> Model Class Initialized
INFO - 2023-07-01 04:06:29 --> Model Class Initialized
INFO - 2023-07-01 04:06:29 --> Model Class Initialized
INFO - 2023-07-01 04:06:29 --> Model Class Initialized
DEBUG - 2023-07-01 04:06:29 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-01 04:06:29 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-01 04:06:29 --> Model Class Initialized
INFO - 2023-07-01 04:06:29 --> Model Class Initialized
INFO - 2023-07-01 04:06:29 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-07-01 04:06:29 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-07-01 04:06:29 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-07-01 04:06:29 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-07-01 04:06:29 --> Model Class Initialized
INFO - 2023-07-01 04:06:29 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-07-01 04:06:29 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-07-01 04:06:29 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-07-01 04:06:29 --> Final output sent to browser
DEBUG - 2023-07-01 04:06:29 --> Total execution time: 0.0664
ERROR - 2023-07-01 04:06:45 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-01 04:06:45 --> Config Class Initialized
INFO - 2023-07-01 04:06:45 --> Hooks Class Initialized
DEBUG - 2023-07-01 04:06:45 --> UTF-8 Support Enabled
INFO - 2023-07-01 04:06:45 --> Utf8 Class Initialized
INFO - 2023-07-01 04:06:45 --> URI Class Initialized
INFO - 2023-07-01 04:06:45 --> Router Class Initialized
INFO - 2023-07-01 04:06:45 --> Output Class Initialized
INFO - 2023-07-01 04:06:45 --> Security Class Initialized
DEBUG - 2023-07-01 04:06:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-01 04:06:45 --> Input Class Initialized
INFO - 2023-07-01 04:06:45 --> Language Class Initialized
INFO - 2023-07-01 04:06:45 --> Loader Class Initialized
INFO - 2023-07-01 04:06:45 --> Helper loaded: url_helper
INFO - 2023-07-01 04:06:45 --> Helper loaded: file_helper
INFO - 2023-07-01 04:06:45 --> Helper loaded: html_helper
INFO - 2023-07-01 04:06:45 --> Helper loaded: text_helper
INFO - 2023-07-01 04:06:45 --> Helper loaded: form_helper
INFO - 2023-07-01 04:06:45 --> Helper loaded: lang_helper
INFO - 2023-07-01 04:06:45 --> Helper loaded: security_helper
INFO - 2023-07-01 04:06:45 --> Helper loaded: cookie_helper
INFO - 2023-07-01 04:06:45 --> Database Driver Class Initialized
INFO - 2023-07-01 04:06:45 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-01 04:06:45 --> Parser Class Initialized
INFO - 2023-07-01 04:06:45 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-01 04:06:45 --> Pagination Class Initialized
INFO - 2023-07-01 04:06:45 --> Form Validation Class Initialized
INFO - 2023-07-01 04:06:45 --> Controller Class Initialized
INFO - 2023-07-01 04:06:45 --> Model Class Initialized
DEBUG - 2023-07-01 04:06:45 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-01 04:06:45 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-01 04:06:45 --> Model Class Initialized
DEBUG - 2023-07-01 04:06:45 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-01 04:06:45 --> Model Class Initialized
INFO - 2023-07-01 04:06:45 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice.php
DEBUG - 2023-07-01 04:06:45 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-07-01 04:06:45 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-07-01 04:06:45 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-07-01 04:06:45 --> Model Class Initialized
INFO - 2023-07-01 04:06:45 --> Model Class Initialized
INFO - 2023-07-01 04:06:45 --> Model Class Initialized
INFO - 2023-07-01 04:06:45 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-07-01 04:06:45 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-07-01 04:06:45 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-07-01 04:06:45 --> Final output sent to browser
DEBUG - 2023-07-01 04:06:45 --> Total execution time: 0.0624
ERROR - 2023-07-01 04:06:46 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-01 04:06:46 --> Config Class Initialized
INFO - 2023-07-01 04:06:46 --> Hooks Class Initialized
DEBUG - 2023-07-01 04:06:46 --> UTF-8 Support Enabled
INFO - 2023-07-01 04:06:46 --> Utf8 Class Initialized
INFO - 2023-07-01 04:06:46 --> URI Class Initialized
INFO - 2023-07-01 04:06:46 --> Router Class Initialized
INFO - 2023-07-01 04:06:46 --> Output Class Initialized
INFO - 2023-07-01 04:06:46 --> Security Class Initialized
DEBUG - 2023-07-01 04:06:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-01 04:06:46 --> Input Class Initialized
INFO - 2023-07-01 04:06:46 --> Language Class Initialized
INFO - 2023-07-01 04:06:46 --> Loader Class Initialized
INFO - 2023-07-01 04:06:46 --> Helper loaded: url_helper
INFO - 2023-07-01 04:06:46 --> Helper loaded: file_helper
INFO - 2023-07-01 04:06:46 --> Helper loaded: html_helper
INFO - 2023-07-01 04:06:46 --> Helper loaded: text_helper
INFO - 2023-07-01 04:06:46 --> Helper loaded: form_helper
INFO - 2023-07-01 04:06:46 --> Helper loaded: lang_helper
INFO - 2023-07-01 04:06:46 --> Helper loaded: security_helper
INFO - 2023-07-01 04:06:46 --> Helper loaded: cookie_helper
INFO - 2023-07-01 04:06:46 --> Database Driver Class Initialized
INFO - 2023-07-01 04:06:46 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-01 04:06:46 --> Parser Class Initialized
INFO - 2023-07-01 04:06:46 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-01 04:06:46 --> Pagination Class Initialized
INFO - 2023-07-01 04:06:46 --> Form Validation Class Initialized
INFO - 2023-07-01 04:06:46 --> Controller Class Initialized
INFO - 2023-07-01 04:06:46 --> Model Class Initialized
DEBUG - 2023-07-01 04:06:46 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-01 04:06:46 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-01 04:06:46 --> Model Class Initialized
DEBUG - 2023-07-01 04:06:46 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-01 04:06:46 --> Model Class Initialized
INFO - 2023-07-01 04:06:46 --> Final output sent to browser
DEBUG - 2023-07-01 04:06:46 --> Total execution time: 0.0227
ERROR - 2023-07-01 04:06:49 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-01 04:06:49 --> Config Class Initialized
INFO - 2023-07-01 04:06:49 --> Hooks Class Initialized
DEBUG - 2023-07-01 04:06:49 --> UTF-8 Support Enabled
INFO - 2023-07-01 04:06:49 --> Utf8 Class Initialized
INFO - 2023-07-01 04:06:49 --> URI Class Initialized
INFO - 2023-07-01 04:06:49 --> Router Class Initialized
INFO - 2023-07-01 04:06:49 --> Output Class Initialized
INFO - 2023-07-01 04:06:49 --> Security Class Initialized
DEBUG - 2023-07-01 04:06:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-01 04:06:49 --> Input Class Initialized
INFO - 2023-07-01 04:06:49 --> Language Class Initialized
INFO - 2023-07-01 04:06:49 --> Loader Class Initialized
INFO - 2023-07-01 04:06:49 --> Helper loaded: url_helper
INFO - 2023-07-01 04:06:49 --> Helper loaded: file_helper
INFO - 2023-07-01 04:06:49 --> Helper loaded: html_helper
INFO - 2023-07-01 04:06:49 --> Helper loaded: text_helper
INFO - 2023-07-01 04:06:49 --> Helper loaded: form_helper
INFO - 2023-07-01 04:06:49 --> Helper loaded: lang_helper
INFO - 2023-07-01 04:06:49 --> Helper loaded: security_helper
INFO - 2023-07-01 04:06:49 --> Helper loaded: cookie_helper
INFO - 2023-07-01 04:06:49 --> Database Driver Class Initialized
INFO - 2023-07-01 04:06:49 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-01 04:06:49 --> Parser Class Initialized
INFO - 2023-07-01 04:06:49 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-01 04:06:49 --> Pagination Class Initialized
INFO - 2023-07-01 04:06:49 --> Form Validation Class Initialized
INFO - 2023-07-01 04:06:49 --> Controller Class Initialized
INFO - 2023-07-01 04:06:49 --> Model Class Initialized
DEBUG - 2023-07-01 04:06:49 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-01 04:06:49 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-01 04:06:49 --> Model Class Initialized
DEBUG - 2023-07-01 04:06:49 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-01 04:06:49 --> Model Class Initialized
DEBUG - 2023-07-01 04:06:49 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-01 04:06:49 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice_html.php
DEBUG - 2023-07-01 04:06:49 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-07-01 04:06:49 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-07-01 04:06:49 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-07-01 04:06:49 --> Model Class Initialized
INFO - 2023-07-01 04:06:49 --> Model Class Initialized
INFO - 2023-07-01 04:06:49 --> Model Class Initialized
INFO - 2023-07-01 04:06:49 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-07-01 04:06:49 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-07-01 04:06:49 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-07-01 04:06:49 --> Final output sent to browser
DEBUG - 2023-07-01 04:06:49 --> Total execution time: 0.0646
ERROR - 2023-07-01 04:07:11 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-01 04:07:11 --> Config Class Initialized
INFO - 2023-07-01 04:07:11 --> Hooks Class Initialized
DEBUG - 2023-07-01 04:07:11 --> UTF-8 Support Enabled
INFO - 2023-07-01 04:07:11 --> Utf8 Class Initialized
INFO - 2023-07-01 04:07:11 --> URI Class Initialized
DEBUG - 2023-07-01 04:07:11 --> No URI present. Default controller set.
INFO - 2023-07-01 04:07:11 --> Router Class Initialized
INFO - 2023-07-01 04:07:11 --> Output Class Initialized
INFO - 2023-07-01 04:07:11 --> Security Class Initialized
DEBUG - 2023-07-01 04:07:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-01 04:07:11 --> Input Class Initialized
INFO - 2023-07-01 04:07:11 --> Language Class Initialized
INFO - 2023-07-01 04:07:11 --> Loader Class Initialized
INFO - 2023-07-01 04:07:11 --> Helper loaded: url_helper
INFO - 2023-07-01 04:07:11 --> Helper loaded: file_helper
INFO - 2023-07-01 04:07:11 --> Helper loaded: html_helper
INFO - 2023-07-01 04:07:11 --> Helper loaded: text_helper
INFO - 2023-07-01 04:07:11 --> Helper loaded: form_helper
INFO - 2023-07-01 04:07:11 --> Helper loaded: lang_helper
INFO - 2023-07-01 04:07:11 --> Helper loaded: security_helper
INFO - 2023-07-01 04:07:11 --> Helper loaded: cookie_helper
INFO - 2023-07-01 04:07:11 --> Database Driver Class Initialized
INFO - 2023-07-01 04:07:11 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-01 04:07:11 --> Parser Class Initialized
INFO - 2023-07-01 04:07:11 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-01 04:07:11 --> Pagination Class Initialized
INFO - 2023-07-01 04:07:11 --> Form Validation Class Initialized
INFO - 2023-07-01 04:07:11 --> Controller Class Initialized
INFO - 2023-07-01 04:07:11 --> Model Class Initialized
DEBUG - 2023-07-01 04:07:11 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-01 04:07:11 --> Model Class Initialized
DEBUG - 2023-07-01 04:07:11 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-01 04:07:11 --> Model Class Initialized
INFO - 2023-07-01 04:07:11 --> Model Class Initialized
INFO - 2023-07-01 04:07:11 --> Model Class Initialized
INFO - 2023-07-01 04:07:11 --> Model Class Initialized
DEBUG - 2023-07-01 04:07:11 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-01 04:07:11 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-01 04:07:11 --> Model Class Initialized
INFO - 2023-07-01 04:07:11 --> Model Class Initialized
INFO - 2023-07-01 04:07:11 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-07-01 04:07:11 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-07-01 04:07:11 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-07-01 04:07:11 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-07-01 04:07:11 --> Model Class Initialized
INFO - 2023-07-01 04:07:11 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-07-01 04:07:11 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-07-01 04:07:11 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-07-01 04:07:11 --> Final output sent to browser
DEBUG - 2023-07-01 04:07:11 --> Total execution time: 0.0685
ERROR - 2023-07-01 04:07:32 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-01 04:07:32 --> Config Class Initialized
INFO - 2023-07-01 04:07:32 --> Hooks Class Initialized
DEBUG - 2023-07-01 04:07:32 --> UTF-8 Support Enabled
INFO - 2023-07-01 04:07:32 --> Utf8 Class Initialized
INFO - 2023-07-01 04:07:32 --> URI Class Initialized
INFO - 2023-07-01 04:07:32 --> Router Class Initialized
INFO - 2023-07-01 04:07:32 --> Output Class Initialized
INFO - 2023-07-01 04:07:32 --> Security Class Initialized
DEBUG - 2023-07-01 04:07:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-01 04:07:32 --> Input Class Initialized
INFO - 2023-07-01 04:07:32 --> Language Class Initialized
INFO - 2023-07-01 04:07:32 --> Loader Class Initialized
INFO - 2023-07-01 04:07:32 --> Helper loaded: url_helper
INFO - 2023-07-01 04:07:32 --> Helper loaded: file_helper
INFO - 2023-07-01 04:07:32 --> Helper loaded: html_helper
INFO - 2023-07-01 04:07:32 --> Helper loaded: text_helper
INFO - 2023-07-01 04:07:32 --> Helper loaded: form_helper
INFO - 2023-07-01 04:07:32 --> Helper loaded: lang_helper
INFO - 2023-07-01 04:07:32 --> Helper loaded: security_helper
INFO - 2023-07-01 04:07:32 --> Helper loaded: cookie_helper
INFO - 2023-07-01 04:07:32 --> Database Driver Class Initialized
INFO - 2023-07-01 04:07:32 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-01 04:07:32 --> Parser Class Initialized
INFO - 2023-07-01 04:07:32 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-01 04:07:32 --> Pagination Class Initialized
INFO - 2023-07-01 04:07:32 --> Form Validation Class Initialized
INFO - 2023-07-01 04:07:32 --> Controller Class Initialized
INFO - 2023-07-01 04:07:32 --> Model Class Initialized
DEBUG - 2023-07-01 04:07:32 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-01 04:07:32 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-01 04:07:32 --> Model Class Initialized
DEBUG - 2023-07-01 04:07:32 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-01 04:07:32 --> Model Class Initialized
INFO - 2023-07-01 04:07:32 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice.php
DEBUG - 2023-07-01 04:07:32 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-07-01 04:07:32 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-07-01 04:07:32 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-07-01 04:07:32 --> Model Class Initialized
INFO - 2023-07-01 04:07:32 --> Model Class Initialized
INFO - 2023-07-01 04:07:32 --> Model Class Initialized
INFO - 2023-07-01 04:07:32 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-07-01 04:07:32 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-07-01 04:07:32 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-07-01 04:07:32 --> Final output sent to browser
DEBUG - 2023-07-01 04:07:32 --> Total execution time: 0.0662
ERROR - 2023-07-01 04:07:32 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-01 04:07:32 --> Config Class Initialized
INFO - 2023-07-01 04:07:32 --> Hooks Class Initialized
DEBUG - 2023-07-01 04:07:32 --> UTF-8 Support Enabled
INFO - 2023-07-01 04:07:32 --> Utf8 Class Initialized
INFO - 2023-07-01 04:07:32 --> URI Class Initialized
INFO - 2023-07-01 04:07:32 --> Router Class Initialized
INFO - 2023-07-01 04:07:32 --> Output Class Initialized
INFO - 2023-07-01 04:07:32 --> Security Class Initialized
DEBUG - 2023-07-01 04:07:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-01 04:07:32 --> Input Class Initialized
INFO - 2023-07-01 04:07:32 --> Language Class Initialized
INFO - 2023-07-01 04:07:32 --> Loader Class Initialized
INFO - 2023-07-01 04:07:32 --> Helper loaded: url_helper
INFO - 2023-07-01 04:07:32 --> Helper loaded: file_helper
INFO - 2023-07-01 04:07:32 --> Helper loaded: html_helper
INFO - 2023-07-01 04:07:32 --> Helper loaded: text_helper
INFO - 2023-07-01 04:07:32 --> Helper loaded: form_helper
INFO - 2023-07-01 04:07:32 --> Helper loaded: lang_helper
INFO - 2023-07-01 04:07:32 --> Helper loaded: security_helper
INFO - 2023-07-01 04:07:32 --> Helper loaded: cookie_helper
INFO - 2023-07-01 04:07:32 --> Database Driver Class Initialized
INFO - 2023-07-01 04:07:32 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-01 04:07:32 --> Parser Class Initialized
INFO - 2023-07-01 04:07:32 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-01 04:07:32 --> Pagination Class Initialized
INFO - 2023-07-01 04:07:32 --> Form Validation Class Initialized
INFO - 2023-07-01 04:07:32 --> Controller Class Initialized
INFO - 2023-07-01 04:07:32 --> Model Class Initialized
DEBUG - 2023-07-01 04:07:32 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-01 04:07:32 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-01 04:07:32 --> Model Class Initialized
DEBUG - 2023-07-01 04:07:32 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-01 04:07:32 --> Model Class Initialized
INFO - 2023-07-01 04:07:32 --> Final output sent to browser
DEBUG - 2023-07-01 04:07:32 --> Total execution time: 0.0210
ERROR - 2023-07-01 04:07:37 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-01 04:07:37 --> Config Class Initialized
INFO - 2023-07-01 04:07:37 --> Hooks Class Initialized
DEBUG - 2023-07-01 04:07:37 --> UTF-8 Support Enabled
INFO - 2023-07-01 04:07:37 --> Utf8 Class Initialized
INFO - 2023-07-01 04:07:37 --> URI Class Initialized
INFO - 2023-07-01 04:07:37 --> Router Class Initialized
INFO - 2023-07-01 04:07:37 --> Output Class Initialized
INFO - 2023-07-01 04:07:37 --> Security Class Initialized
DEBUG - 2023-07-01 04:07:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-01 04:07:37 --> Input Class Initialized
INFO - 2023-07-01 04:07:37 --> Language Class Initialized
INFO - 2023-07-01 04:07:37 --> Loader Class Initialized
INFO - 2023-07-01 04:07:37 --> Helper loaded: url_helper
INFO - 2023-07-01 04:07:37 --> Helper loaded: file_helper
INFO - 2023-07-01 04:07:37 --> Helper loaded: html_helper
INFO - 2023-07-01 04:07:37 --> Helper loaded: text_helper
INFO - 2023-07-01 04:07:37 --> Helper loaded: form_helper
INFO - 2023-07-01 04:07:37 --> Helper loaded: lang_helper
INFO - 2023-07-01 04:07:37 --> Helper loaded: security_helper
INFO - 2023-07-01 04:07:37 --> Helper loaded: cookie_helper
INFO - 2023-07-01 04:07:37 --> Database Driver Class Initialized
INFO - 2023-07-01 04:07:37 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-01 04:07:37 --> Parser Class Initialized
INFO - 2023-07-01 04:07:37 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-01 04:07:37 --> Pagination Class Initialized
INFO - 2023-07-01 04:07:37 --> Form Validation Class Initialized
INFO - 2023-07-01 04:07:37 --> Controller Class Initialized
INFO - 2023-07-01 04:07:37 --> Model Class Initialized
DEBUG - 2023-07-01 04:07:37 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-01 04:07:37 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-01 04:07:37 --> Model Class Initialized
DEBUG - 2023-07-01 04:07:37 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-01 04:07:37 --> Model Class Initialized
DEBUG - 2023-07-01 04:07:37 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-01 04:07:37 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice_html.php
DEBUG - 2023-07-01 04:07:37 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-07-01 04:07:37 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-07-01 04:07:37 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-07-01 04:07:37 --> Model Class Initialized
INFO - 2023-07-01 04:07:37 --> Model Class Initialized
INFO - 2023-07-01 04:07:37 --> Model Class Initialized
INFO - 2023-07-01 04:07:37 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-07-01 04:07:37 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-07-01 04:07:37 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-07-01 04:07:37 --> Final output sent to browser
DEBUG - 2023-07-01 04:07:37 --> Total execution time: 0.0631
ERROR - 2023-07-01 04:07:41 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-01 04:07:41 --> Config Class Initialized
INFO - 2023-07-01 04:07:41 --> Hooks Class Initialized
DEBUG - 2023-07-01 04:07:41 --> UTF-8 Support Enabled
INFO - 2023-07-01 04:07:41 --> Utf8 Class Initialized
INFO - 2023-07-01 04:07:41 --> URI Class Initialized
DEBUG - 2023-07-01 04:07:41 --> No URI present. Default controller set.
INFO - 2023-07-01 04:07:41 --> Router Class Initialized
INFO - 2023-07-01 04:07:41 --> Output Class Initialized
INFO - 2023-07-01 04:07:41 --> Security Class Initialized
DEBUG - 2023-07-01 04:07:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-01 04:07:41 --> Input Class Initialized
INFO - 2023-07-01 04:07:41 --> Language Class Initialized
INFO - 2023-07-01 04:07:41 --> Loader Class Initialized
INFO - 2023-07-01 04:07:41 --> Helper loaded: url_helper
INFO - 2023-07-01 04:07:41 --> Helper loaded: file_helper
INFO - 2023-07-01 04:07:41 --> Helper loaded: html_helper
INFO - 2023-07-01 04:07:41 --> Helper loaded: text_helper
INFO - 2023-07-01 04:07:41 --> Helper loaded: form_helper
INFO - 2023-07-01 04:07:41 --> Helper loaded: lang_helper
INFO - 2023-07-01 04:07:41 --> Helper loaded: security_helper
INFO - 2023-07-01 04:07:41 --> Helper loaded: cookie_helper
INFO - 2023-07-01 04:07:41 --> Database Driver Class Initialized
INFO - 2023-07-01 04:07:41 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-01 04:07:41 --> Parser Class Initialized
INFO - 2023-07-01 04:07:41 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-01 04:07:41 --> Pagination Class Initialized
INFO - 2023-07-01 04:07:41 --> Form Validation Class Initialized
INFO - 2023-07-01 04:07:41 --> Controller Class Initialized
INFO - 2023-07-01 04:07:41 --> Model Class Initialized
DEBUG - 2023-07-01 04:07:41 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-01 04:07:41 --> Model Class Initialized
DEBUG - 2023-07-01 04:07:41 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-01 04:07:41 --> Model Class Initialized
INFO - 2023-07-01 04:07:41 --> Model Class Initialized
INFO - 2023-07-01 04:07:41 --> Model Class Initialized
INFO - 2023-07-01 04:07:41 --> Model Class Initialized
DEBUG - 2023-07-01 04:07:41 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-01 04:07:41 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-01 04:07:41 --> Model Class Initialized
INFO - 2023-07-01 04:07:41 --> Model Class Initialized
INFO - 2023-07-01 04:07:41 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-07-01 04:07:41 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-07-01 04:07:41 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-07-01 04:07:41 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-07-01 04:07:41 --> Model Class Initialized
INFO - 2023-07-01 04:07:41 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-07-01 04:07:41 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-07-01 04:07:41 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-07-01 04:07:41 --> Final output sent to browser
DEBUG - 2023-07-01 04:07:41 --> Total execution time: 0.0614
ERROR - 2023-07-01 04:07:57 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-01 04:07:57 --> Config Class Initialized
INFO - 2023-07-01 04:07:57 --> Hooks Class Initialized
DEBUG - 2023-07-01 04:07:57 --> UTF-8 Support Enabled
INFO - 2023-07-01 04:07:57 --> Utf8 Class Initialized
INFO - 2023-07-01 04:07:57 --> URI Class Initialized
DEBUG - 2023-07-01 04:07:57 --> No URI present. Default controller set.
INFO - 2023-07-01 04:07:57 --> Router Class Initialized
INFO - 2023-07-01 04:07:57 --> Output Class Initialized
INFO - 2023-07-01 04:07:57 --> Security Class Initialized
DEBUG - 2023-07-01 04:07:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-01 04:07:57 --> Input Class Initialized
INFO - 2023-07-01 04:07:57 --> Language Class Initialized
INFO - 2023-07-01 04:07:57 --> Loader Class Initialized
INFO - 2023-07-01 04:07:57 --> Helper loaded: url_helper
INFO - 2023-07-01 04:07:57 --> Helper loaded: file_helper
INFO - 2023-07-01 04:07:57 --> Helper loaded: html_helper
INFO - 2023-07-01 04:07:57 --> Helper loaded: text_helper
INFO - 2023-07-01 04:07:57 --> Helper loaded: form_helper
INFO - 2023-07-01 04:07:57 --> Helper loaded: lang_helper
INFO - 2023-07-01 04:07:57 --> Helper loaded: security_helper
INFO - 2023-07-01 04:07:57 --> Helper loaded: cookie_helper
INFO - 2023-07-01 04:07:57 --> Database Driver Class Initialized
INFO - 2023-07-01 04:07:57 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-01 04:07:57 --> Parser Class Initialized
INFO - 2023-07-01 04:07:57 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-01 04:07:57 --> Pagination Class Initialized
INFO - 2023-07-01 04:07:57 --> Form Validation Class Initialized
INFO - 2023-07-01 04:07:57 --> Controller Class Initialized
INFO - 2023-07-01 04:07:57 --> Model Class Initialized
DEBUG - 2023-07-01 04:07:57 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-01 04:07:57 --> Model Class Initialized
DEBUG - 2023-07-01 04:07:57 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-01 04:07:57 --> Model Class Initialized
INFO - 2023-07-01 04:07:57 --> Model Class Initialized
INFO - 2023-07-01 04:07:57 --> Model Class Initialized
INFO - 2023-07-01 04:07:57 --> Model Class Initialized
DEBUG - 2023-07-01 04:07:57 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-01 04:07:57 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-01 04:07:57 --> Model Class Initialized
INFO - 2023-07-01 04:07:57 --> Model Class Initialized
INFO - 2023-07-01 04:07:57 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-07-01 04:07:57 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-07-01 04:07:57 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-07-01 04:07:57 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-07-01 04:07:57 --> Model Class Initialized
INFO - 2023-07-01 04:07:57 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-07-01 04:07:57 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-07-01 04:07:57 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-07-01 04:07:57 --> Final output sent to browser
DEBUG - 2023-07-01 04:07:57 --> Total execution time: 0.1865
ERROR - 2023-07-01 04:08:17 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-01 04:08:17 --> Config Class Initialized
INFO - 2023-07-01 04:08:17 --> Hooks Class Initialized
DEBUG - 2023-07-01 04:08:17 --> UTF-8 Support Enabled
INFO - 2023-07-01 04:08:17 --> Utf8 Class Initialized
INFO - 2023-07-01 04:08:17 --> URI Class Initialized
DEBUG - 2023-07-01 04:08:17 --> No URI present. Default controller set.
INFO - 2023-07-01 04:08:17 --> Router Class Initialized
INFO - 2023-07-01 04:08:17 --> Output Class Initialized
INFO - 2023-07-01 04:08:17 --> Security Class Initialized
DEBUG - 2023-07-01 04:08:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-01 04:08:17 --> Input Class Initialized
INFO - 2023-07-01 04:08:17 --> Language Class Initialized
INFO - 2023-07-01 04:08:17 --> Loader Class Initialized
INFO - 2023-07-01 04:08:17 --> Helper loaded: url_helper
INFO - 2023-07-01 04:08:17 --> Helper loaded: file_helper
INFO - 2023-07-01 04:08:17 --> Helper loaded: html_helper
INFO - 2023-07-01 04:08:17 --> Helper loaded: text_helper
INFO - 2023-07-01 04:08:17 --> Helper loaded: form_helper
INFO - 2023-07-01 04:08:17 --> Helper loaded: lang_helper
INFO - 2023-07-01 04:08:17 --> Helper loaded: security_helper
INFO - 2023-07-01 04:08:17 --> Helper loaded: cookie_helper
INFO - 2023-07-01 04:08:17 --> Database Driver Class Initialized
INFO - 2023-07-01 04:08:17 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-01 04:08:17 --> Parser Class Initialized
INFO - 2023-07-01 04:08:17 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-01 04:08:17 --> Pagination Class Initialized
INFO - 2023-07-01 04:08:17 --> Form Validation Class Initialized
INFO - 2023-07-01 04:08:17 --> Controller Class Initialized
INFO - 2023-07-01 04:08:17 --> Model Class Initialized
DEBUG - 2023-07-01 04:08:17 --> Session class already loaded. Second attempt ignored.
ERROR - 2023-07-01 04:08:18 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-01 04:08:18 --> Config Class Initialized
INFO - 2023-07-01 04:08:18 --> Hooks Class Initialized
DEBUG - 2023-07-01 04:08:18 --> UTF-8 Support Enabled
INFO - 2023-07-01 04:08:18 --> Utf8 Class Initialized
INFO - 2023-07-01 04:08:18 --> URI Class Initialized
INFO - 2023-07-01 04:08:18 --> Router Class Initialized
INFO - 2023-07-01 04:08:18 --> Output Class Initialized
INFO - 2023-07-01 04:08:18 --> Security Class Initialized
DEBUG - 2023-07-01 04:08:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-01 04:08:18 --> Input Class Initialized
INFO - 2023-07-01 04:08:18 --> Language Class Initialized
INFO - 2023-07-01 04:08:18 --> Loader Class Initialized
INFO - 2023-07-01 04:08:18 --> Helper loaded: url_helper
INFO - 2023-07-01 04:08:18 --> Helper loaded: file_helper
INFO - 2023-07-01 04:08:18 --> Helper loaded: html_helper
INFO - 2023-07-01 04:08:18 --> Helper loaded: text_helper
INFO - 2023-07-01 04:08:18 --> Helper loaded: form_helper
INFO - 2023-07-01 04:08:18 --> Helper loaded: lang_helper
INFO - 2023-07-01 04:08:18 --> Helper loaded: security_helper
INFO - 2023-07-01 04:08:18 --> Helper loaded: cookie_helper
INFO - 2023-07-01 04:08:18 --> Database Driver Class Initialized
INFO - 2023-07-01 04:08:18 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-01 04:08:18 --> Parser Class Initialized
INFO - 2023-07-01 04:08:18 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-01 04:08:18 --> Pagination Class Initialized
INFO - 2023-07-01 04:08:18 --> Form Validation Class Initialized
INFO - 2023-07-01 04:08:18 --> Controller Class Initialized
INFO - 2023-07-01 04:08:18 --> Model Class Initialized
DEBUG - 2023-07-01 04:08:18 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-01 04:08:18 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2023-07-01 04:08:18 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-07-01 04:08:18 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-07-01 04:08:18 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-07-01 04:08:18 --> Model Class Initialized
INFO - 2023-07-01 04:08:18 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-07-01 04:08:18 --> Final output sent to browser
DEBUG - 2023-07-01 04:08:18 --> Total execution time: 0.0305
ERROR - 2023-07-01 04:08:26 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-01 04:08:26 --> Config Class Initialized
INFO - 2023-07-01 04:08:26 --> Hooks Class Initialized
DEBUG - 2023-07-01 04:08:26 --> UTF-8 Support Enabled
INFO - 2023-07-01 04:08:26 --> Utf8 Class Initialized
INFO - 2023-07-01 04:08:26 --> URI Class Initialized
INFO - 2023-07-01 04:08:26 --> Router Class Initialized
INFO - 2023-07-01 04:08:26 --> Output Class Initialized
INFO - 2023-07-01 04:08:26 --> Security Class Initialized
DEBUG - 2023-07-01 04:08:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-01 04:08:26 --> Input Class Initialized
INFO - 2023-07-01 04:08:26 --> Language Class Initialized
INFO - 2023-07-01 04:08:26 --> Loader Class Initialized
INFO - 2023-07-01 04:08:26 --> Helper loaded: url_helper
INFO - 2023-07-01 04:08:26 --> Helper loaded: file_helper
INFO - 2023-07-01 04:08:26 --> Helper loaded: html_helper
INFO - 2023-07-01 04:08:26 --> Helper loaded: text_helper
INFO - 2023-07-01 04:08:26 --> Helper loaded: form_helper
INFO - 2023-07-01 04:08:26 --> Helper loaded: lang_helper
INFO - 2023-07-01 04:08:26 --> Helper loaded: security_helper
INFO - 2023-07-01 04:08:26 --> Helper loaded: cookie_helper
INFO - 2023-07-01 04:08:26 --> Database Driver Class Initialized
INFO - 2023-07-01 04:08:26 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-01 04:08:26 --> Parser Class Initialized
INFO - 2023-07-01 04:08:26 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-01 04:08:26 --> Pagination Class Initialized
INFO - 2023-07-01 04:08:26 --> Form Validation Class Initialized
INFO - 2023-07-01 04:08:26 --> Controller Class Initialized
INFO - 2023-07-01 04:08:26 --> Model Class Initialized
DEBUG - 2023-07-01 04:08:26 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-01 04:08:26 --> Model Class Initialized
INFO - 2023-07-01 04:08:26 --> Final output sent to browser
DEBUG - 2023-07-01 04:08:26 --> Total execution time: 0.0164
ERROR - 2023-07-01 04:08:26 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-01 04:08:26 --> Config Class Initialized
INFO - 2023-07-01 04:08:26 --> Hooks Class Initialized
DEBUG - 2023-07-01 04:08:26 --> UTF-8 Support Enabled
INFO - 2023-07-01 04:08:26 --> Utf8 Class Initialized
INFO - 2023-07-01 04:08:26 --> URI Class Initialized
DEBUG - 2023-07-01 04:08:26 --> No URI present. Default controller set.
INFO - 2023-07-01 04:08:26 --> Router Class Initialized
INFO - 2023-07-01 04:08:26 --> Output Class Initialized
INFO - 2023-07-01 04:08:26 --> Security Class Initialized
DEBUG - 2023-07-01 04:08:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-01 04:08:26 --> Input Class Initialized
INFO - 2023-07-01 04:08:26 --> Language Class Initialized
INFO - 2023-07-01 04:08:26 --> Loader Class Initialized
INFO - 2023-07-01 04:08:26 --> Helper loaded: url_helper
INFO - 2023-07-01 04:08:26 --> Helper loaded: file_helper
INFO - 2023-07-01 04:08:26 --> Helper loaded: html_helper
INFO - 2023-07-01 04:08:26 --> Helper loaded: text_helper
INFO - 2023-07-01 04:08:26 --> Helper loaded: form_helper
INFO - 2023-07-01 04:08:26 --> Helper loaded: lang_helper
INFO - 2023-07-01 04:08:26 --> Helper loaded: security_helper
INFO - 2023-07-01 04:08:26 --> Helper loaded: cookie_helper
INFO - 2023-07-01 04:08:26 --> Database Driver Class Initialized
INFO - 2023-07-01 04:08:26 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-01 04:08:26 --> Parser Class Initialized
INFO - 2023-07-01 04:08:26 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-01 04:08:26 --> Pagination Class Initialized
INFO - 2023-07-01 04:08:26 --> Form Validation Class Initialized
INFO - 2023-07-01 04:08:26 --> Controller Class Initialized
INFO - 2023-07-01 04:08:26 --> Model Class Initialized
DEBUG - 2023-07-01 04:08:26 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-01 04:08:26 --> Model Class Initialized
DEBUG - 2023-07-01 04:08:26 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-01 04:08:26 --> Model Class Initialized
INFO - 2023-07-01 04:08:26 --> Model Class Initialized
INFO - 2023-07-01 04:08:26 --> Model Class Initialized
INFO - 2023-07-01 04:08:26 --> Model Class Initialized
DEBUG - 2023-07-01 04:08:26 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-01 04:08:26 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-01 04:08:26 --> Model Class Initialized
INFO - 2023-07-01 04:08:26 --> Model Class Initialized
INFO - 2023-07-01 04:08:26 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-07-01 04:08:26 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-07-01 04:08:26 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-07-01 04:08:26 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-07-01 04:08:26 --> Model Class Initialized
INFO - 2023-07-01 04:08:26 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-07-01 04:08:26 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-07-01 04:08:26 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-07-01 04:08:26 --> Final output sent to browser
DEBUG - 2023-07-01 04:08:26 --> Total execution time: 0.0833
ERROR - 2023-07-01 04:08:40 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-01 04:08:40 --> Config Class Initialized
INFO - 2023-07-01 04:08:40 --> Hooks Class Initialized
DEBUG - 2023-07-01 04:08:40 --> UTF-8 Support Enabled
INFO - 2023-07-01 04:08:40 --> Utf8 Class Initialized
INFO - 2023-07-01 04:08:40 --> URI Class Initialized
DEBUG - 2023-07-01 04:08:40 --> No URI present. Default controller set.
INFO - 2023-07-01 04:08:40 --> Router Class Initialized
INFO - 2023-07-01 04:08:40 --> Output Class Initialized
INFO - 2023-07-01 04:08:40 --> Security Class Initialized
DEBUG - 2023-07-01 04:08:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-01 04:08:40 --> Input Class Initialized
INFO - 2023-07-01 04:08:40 --> Language Class Initialized
INFO - 2023-07-01 04:08:40 --> Loader Class Initialized
INFO - 2023-07-01 04:08:40 --> Helper loaded: url_helper
INFO - 2023-07-01 04:08:40 --> Helper loaded: file_helper
INFO - 2023-07-01 04:08:40 --> Helper loaded: html_helper
INFO - 2023-07-01 04:08:40 --> Helper loaded: text_helper
INFO - 2023-07-01 04:08:40 --> Helper loaded: form_helper
INFO - 2023-07-01 04:08:40 --> Helper loaded: lang_helper
INFO - 2023-07-01 04:08:40 --> Helper loaded: security_helper
INFO - 2023-07-01 04:08:40 --> Helper loaded: cookie_helper
INFO - 2023-07-01 04:08:40 --> Database Driver Class Initialized
INFO - 2023-07-01 04:08:40 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-01 04:08:40 --> Parser Class Initialized
INFO - 2023-07-01 04:08:40 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-01 04:08:40 --> Pagination Class Initialized
INFO - 2023-07-01 04:08:40 --> Form Validation Class Initialized
INFO - 2023-07-01 04:08:40 --> Controller Class Initialized
INFO - 2023-07-01 04:08:40 --> Model Class Initialized
DEBUG - 2023-07-01 04:08:40 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-01 04:08:40 --> Model Class Initialized
DEBUG - 2023-07-01 04:08:40 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-01 04:08:40 --> Model Class Initialized
INFO - 2023-07-01 04:08:40 --> Model Class Initialized
INFO - 2023-07-01 04:08:40 --> Model Class Initialized
INFO - 2023-07-01 04:08:40 --> Model Class Initialized
DEBUG - 2023-07-01 04:08:40 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-01 04:08:40 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-01 04:08:40 --> Model Class Initialized
INFO - 2023-07-01 04:08:40 --> Model Class Initialized
INFO - 2023-07-01 04:08:40 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-07-01 04:08:40 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-07-01 04:08:40 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-07-01 04:08:40 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-07-01 04:08:41 --> Model Class Initialized
INFO - 2023-07-01 04:08:41 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-07-01 04:08:41 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-07-01 04:08:41 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-07-01 04:08:41 --> Final output sent to browser
DEBUG - 2023-07-01 04:08:41 --> Total execution time: 0.0778
ERROR - 2023-07-01 04:39:27 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-01 04:39:27 --> Config Class Initialized
INFO - 2023-07-01 04:39:27 --> Hooks Class Initialized
DEBUG - 2023-07-01 04:39:27 --> UTF-8 Support Enabled
INFO - 2023-07-01 04:39:27 --> Utf8 Class Initialized
INFO - 2023-07-01 04:39:27 --> URI Class Initialized
DEBUG - 2023-07-01 04:39:27 --> No URI present. Default controller set.
INFO - 2023-07-01 04:39:27 --> Router Class Initialized
INFO - 2023-07-01 04:39:27 --> Output Class Initialized
INFO - 2023-07-01 04:39:27 --> Security Class Initialized
DEBUG - 2023-07-01 04:39:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-01 04:39:27 --> Input Class Initialized
INFO - 2023-07-01 04:39:27 --> Language Class Initialized
INFO - 2023-07-01 04:39:27 --> Loader Class Initialized
INFO - 2023-07-01 04:39:27 --> Helper loaded: url_helper
INFO - 2023-07-01 04:39:27 --> Helper loaded: file_helper
INFO - 2023-07-01 04:39:27 --> Helper loaded: html_helper
INFO - 2023-07-01 04:39:27 --> Helper loaded: text_helper
INFO - 2023-07-01 04:39:27 --> Helper loaded: form_helper
INFO - 2023-07-01 04:39:27 --> Helper loaded: lang_helper
INFO - 2023-07-01 04:39:27 --> Helper loaded: security_helper
INFO - 2023-07-01 04:39:27 --> Helper loaded: cookie_helper
INFO - 2023-07-01 04:39:27 --> Database Driver Class Initialized
INFO - 2023-07-01 04:39:27 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-01 04:39:27 --> Parser Class Initialized
INFO - 2023-07-01 04:39:27 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-01 04:39:27 --> Pagination Class Initialized
INFO - 2023-07-01 04:39:27 --> Form Validation Class Initialized
INFO - 2023-07-01 04:39:27 --> Controller Class Initialized
INFO - 2023-07-01 04:39:27 --> Model Class Initialized
DEBUG - 2023-07-01 04:39:27 --> Session class already loaded. Second attempt ignored.
ERROR - 2023-07-01 04:39:27 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-01 04:39:27 --> Config Class Initialized
INFO - 2023-07-01 04:39:27 --> Hooks Class Initialized
DEBUG - 2023-07-01 04:39:27 --> UTF-8 Support Enabled
INFO - 2023-07-01 04:39:27 --> Utf8 Class Initialized
INFO - 2023-07-01 04:39:27 --> URI Class Initialized
INFO - 2023-07-01 04:39:27 --> Router Class Initialized
INFO - 2023-07-01 04:39:27 --> Output Class Initialized
INFO - 2023-07-01 04:39:27 --> Security Class Initialized
DEBUG - 2023-07-01 04:39:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-01 04:39:27 --> Input Class Initialized
INFO - 2023-07-01 04:39:27 --> Language Class Initialized
INFO - 2023-07-01 04:39:27 --> Loader Class Initialized
INFO - 2023-07-01 04:39:27 --> Helper loaded: url_helper
INFO - 2023-07-01 04:39:27 --> Helper loaded: file_helper
INFO - 2023-07-01 04:39:27 --> Helper loaded: html_helper
INFO - 2023-07-01 04:39:27 --> Helper loaded: text_helper
INFO - 2023-07-01 04:39:27 --> Helper loaded: form_helper
INFO - 2023-07-01 04:39:27 --> Helper loaded: lang_helper
INFO - 2023-07-01 04:39:27 --> Helper loaded: security_helper
INFO - 2023-07-01 04:39:27 --> Helper loaded: cookie_helper
INFO - 2023-07-01 04:39:27 --> Database Driver Class Initialized
INFO - 2023-07-01 04:39:27 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-01 04:39:27 --> Parser Class Initialized
INFO - 2023-07-01 04:39:27 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-01 04:39:27 --> Pagination Class Initialized
INFO - 2023-07-01 04:39:27 --> Form Validation Class Initialized
INFO - 2023-07-01 04:39:27 --> Controller Class Initialized
INFO - 2023-07-01 04:39:27 --> Model Class Initialized
DEBUG - 2023-07-01 04:39:27 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-01 04:39:27 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2023-07-01 04:39:27 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-07-01 04:39:27 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-07-01 04:39:27 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-07-01 04:39:27 --> Model Class Initialized
INFO - 2023-07-01 04:39:27 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-07-01 04:39:27 --> Final output sent to browser
DEBUG - 2023-07-01 04:39:27 --> Total execution time: 0.0294
ERROR - 2023-07-01 04:39:50 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-01 04:39:50 --> Config Class Initialized
INFO - 2023-07-01 04:39:50 --> Hooks Class Initialized
DEBUG - 2023-07-01 04:39:50 --> UTF-8 Support Enabled
INFO - 2023-07-01 04:39:50 --> Utf8 Class Initialized
INFO - 2023-07-01 04:39:50 --> URI Class Initialized
INFO - 2023-07-01 04:39:50 --> Router Class Initialized
INFO - 2023-07-01 04:39:50 --> Output Class Initialized
INFO - 2023-07-01 04:39:50 --> Security Class Initialized
DEBUG - 2023-07-01 04:39:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-01 04:39:50 --> Input Class Initialized
INFO - 2023-07-01 04:39:50 --> Language Class Initialized
INFO - 2023-07-01 04:39:50 --> Loader Class Initialized
INFO - 2023-07-01 04:39:50 --> Helper loaded: url_helper
INFO - 2023-07-01 04:39:50 --> Helper loaded: file_helper
INFO - 2023-07-01 04:39:50 --> Helper loaded: html_helper
INFO - 2023-07-01 04:39:50 --> Helper loaded: text_helper
INFO - 2023-07-01 04:39:50 --> Helper loaded: form_helper
INFO - 2023-07-01 04:39:50 --> Helper loaded: lang_helper
INFO - 2023-07-01 04:39:50 --> Helper loaded: security_helper
INFO - 2023-07-01 04:39:50 --> Helper loaded: cookie_helper
INFO - 2023-07-01 04:39:50 --> Database Driver Class Initialized
INFO - 2023-07-01 04:39:50 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-01 04:39:50 --> Parser Class Initialized
INFO - 2023-07-01 04:39:50 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-01 04:39:50 --> Pagination Class Initialized
INFO - 2023-07-01 04:39:50 --> Form Validation Class Initialized
INFO - 2023-07-01 04:39:50 --> Controller Class Initialized
INFO - 2023-07-01 04:39:50 --> Model Class Initialized
DEBUG - 2023-07-01 04:39:50 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-01 04:39:50 --> Model Class Initialized
INFO - 2023-07-01 04:39:50 --> Final output sent to browser
DEBUG - 2023-07-01 04:39:50 --> Total execution time: 0.0195
ERROR - 2023-07-01 04:39:50 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-01 04:39:50 --> Config Class Initialized
INFO - 2023-07-01 04:39:50 --> Hooks Class Initialized
DEBUG - 2023-07-01 04:39:50 --> UTF-8 Support Enabled
INFO - 2023-07-01 04:39:50 --> Utf8 Class Initialized
INFO - 2023-07-01 04:39:50 --> URI Class Initialized
DEBUG - 2023-07-01 04:39:50 --> No URI present. Default controller set.
INFO - 2023-07-01 04:39:50 --> Router Class Initialized
INFO - 2023-07-01 04:39:50 --> Output Class Initialized
INFO - 2023-07-01 04:39:50 --> Security Class Initialized
DEBUG - 2023-07-01 04:39:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-01 04:39:50 --> Input Class Initialized
INFO - 2023-07-01 04:39:50 --> Language Class Initialized
INFO - 2023-07-01 04:39:50 --> Loader Class Initialized
INFO - 2023-07-01 04:39:50 --> Helper loaded: url_helper
INFO - 2023-07-01 04:39:50 --> Helper loaded: file_helper
INFO - 2023-07-01 04:39:50 --> Helper loaded: html_helper
INFO - 2023-07-01 04:39:50 --> Helper loaded: text_helper
INFO - 2023-07-01 04:39:50 --> Helper loaded: form_helper
INFO - 2023-07-01 04:39:50 --> Helper loaded: lang_helper
INFO - 2023-07-01 04:39:50 --> Helper loaded: security_helper
INFO - 2023-07-01 04:39:50 --> Helper loaded: cookie_helper
INFO - 2023-07-01 04:39:50 --> Database Driver Class Initialized
INFO - 2023-07-01 04:39:50 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-01 04:39:50 --> Parser Class Initialized
INFO - 2023-07-01 04:39:50 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-01 04:39:50 --> Pagination Class Initialized
INFO - 2023-07-01 04:39:50 --> Form Validation Class Initialized
INFO - 2023-07-01 04:39:50 --> Controller Class Initialized
INFO - 2023-07-01 04:39:50 --> Model Class Initialized
DEBUG - 2023-07-01 04:39:50 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-01 04:39:50 --> Model Class Initialized
DEBUG - 2023-07-01 04:39:50 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-01 04:39:50 --> Model Class Initialized
INFO - 2023-07-01 04:39:50 --> Model Class Initialized
INFO - 2023-07-01 04:39:50 --> Model Class Initialized
INFO - 2023-07-01 04:39:50 --> Model Class Initialized
DEBUG - 2023-07-01 04:39:50 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-01 04:39:50 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-01 04:39:50 --> Model Class Initialized
INFO - 2023-07-01 04:39:50 --> Model Class Initialized
INFO - 2023-07-01 04:39:50 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-07-01 04:39:50 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-07-01 04:39:50 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-07-01 04:39:50 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-07-01 04:39:50 --> Model Class Initialized
INFO - 2023-07-01 04:39:50 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-07-01 04:39:50 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-07-01 04:39:50 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-07-01 04:39:50 --> Final output sent to browser
DEBUG - 2023-07-01 04:39:50 --> Total execution time: 0.0932
ERROR - 2023-07-01 04:40:18 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-01 04:40:18 --> Config Class Initialized
INFO - 2023-07-01 04:40:18 --> Hooks Class Initialized
DEBUG - 2023-07-01 04:40:18 --> UTF-8 Support Enabled
INFO - 2023-07-01 04:40:18 --> Utf8 Class Initialized
INFO - 2023-07-01 04:40:18 --> URI Class Initialized
INFO - 2023-07-01 04:40:18 --> Router Class Initialized
INFO - 2023-07-01 04:40:18 --> Output Class Initialized
INFO - 2023-07-01 04:40:18 --> Security Class Initialized
DEBUG - 2023-07-01 04:40:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-01 04:40:18 --> Input Class Initialized
INFO - 2023-07-01 04:40:18 --> Language Class Initialized
INFO - 2023-07-01 04:40:18 --> Loader Class Initialized
INFO - 2023-07-01 04:40:18 --> Helper loaded: url_helper
INFO - 2023-07-01 04:40:18 --> Helper loaded: file_helper
INFO - 2023-07-01 04:40:18 --> Helper loaded: html_helper
INFO - 2023-07-01 04:40:18 --> Helper loaded: text_helper
INFO - 2023-07-01 04:40:18 --> Helper loaded: form_helper
INFO - 2023-07-01 04:40:18 --> Helper loaded: lang_helper
INFO - 2023-07-01 04:40:18 --> Helper loaded: security_helper
INFO - 2023-07-01 04:40:18 --> Helper loaded: cookie_helper
INFO - 2023-07-01 04:40:19 --> Database Driver Class Initialized
INFO - 2023-07-01 04:40:19 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-01 04:40:19 --> Parser Class Initialized
INFO - 2023-07-01 04:40:19 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-01 04:40:19 --> Pagination Class Initialized
INFO - 2023-07-01 04:40:19 --> Form Validation Class Initialized
INFO - 2023-07-01 04:40:19 --> Controller Class Initialized
INFO - 2023-07-01 04:40:19 --> Model Class Initialized
DEBUG - 2023-07-01 04:40:19 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-01 04:40:19 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-01 04:40:19 --> Model Class Initialized
DEBUG - 2023-07-01 04:40:19 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-01 04:40:19 --> Model Class Initialized
INFO - 2023-07-01 04:40:19 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice.php
DEBUG - 2023-07-01 04:40:19 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-07-01 04:40:19 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-07-01 04:40:19 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-07-01 04:40:19 --> Model Class Initialized
INFO - 2023-07-01 04:40:19 --> Model Class Initialized
INFO - 2023-07-01 04:40:19 --> Model Class Initialized
INFO - 2023-07-01 04:40:19 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-07-01 04:40:19 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-07-01 04:40:19 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-07-01 04:40:19 --> Final output sent to browser
DEBUG - 2023-07-01 04:40:19 --> Total execution time: 0.0730
ERROR - 2023-07-01 04:40:20 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-01 04:40:20 --> Config Class Initialized
INFO - 2023-07-01 04:40:20 --> Hooks Class Initialized
DEBUG - 2023-07-01 04:40:20 --> UTF-8 Support Enabled
INFO - 2023-07-01 04:40:20 --> Utf8 Class Initialized
INFO - 2023-07-01 04:40:20 --> URI Class Initialized
INFO - 2023-07-01 04:40:20 --> Router Class Initialized
INFO - 2023-07-01 04:40:20 --> Output Class Initialized
INFO - 2023-07-01 04:40:20 --> Security Class Initialized
DEBUG - 2023-07-01 04:40:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-01 04:40:20 --> Input Class Initialized
INFO - 2023-07-01 04:40:20 --> Language Class Initialized
INFO - 2023-07-01 04:40:20 --> Loader Class Initialized
INFO - 2023-07-01 04:40:20 --> Helper loaded: url_helper
INFO - 2023-07-01 04:40:20 --> Helper loaded: file_helper
INFO - 2023-07-01 04:40:20 --> Helper loaded: html_helper
INFO - 2023-07-01 04:40:20 --> Helper loaded: text_helper
INFO - 2023-07-01 04:40:20 --> Helper loaded: form_helper
INFO - 2023-07-01 04:40:20 --> Helper loaded: lang_helper
INFO - 2023-07-01 04:40:20 --> Helper loaded: security_helper
INFO - 2023-07-01 04:40:20 --> Helper loaded: cookie_helper
INFO - 2023-07-01 04:40:20 --> Database Driver Class Initialized
INFO - 2023-07-01 04:40:20 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-01 04:40:20 --> Parser Class Initialized
INFO - 2023-07-01 04:40:20 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-01 04:40:20 --> Pagination Class Initialized
INFO - 2023-07-01 04:40:20 --> Form Validation Class Initialized
INFO - 2023-07-01 04:40:20 --> Controller Class Initialized
INFO - 2023-07-01 04:40:20 --> Model Class Initialized
DEBUG - 2023-07-01 04:40:20 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-01 04:40:20 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-01 04:40:20 --> Model Class Initialized
DEBUG - 2023-07-01 04:40:20 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-01 04:40:20 --> Model Class Initialized
INFO - 2023-07-01 04:40:20 --> Final output sent to browser
DEBUG - 2023-07-01 04:40:20 --> Total execution time: 0.0437
ERROR - 2023-07-01 04:40:45 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-01 04:40:45 --> Config Class Initialized
INFO - 2023-07-01 04:40:45 --> Hooks Class Initialized
DEBUG - 2023-07-01 04:40:45 --> UTF-8 Support Enabled
INFO - 2023-07-01 04:40:45 --> Utf8 Class Initialized
INFO - 2023-07-01 04:40:45 --> URI Class Initialized
INFO - 2023-07-01 04:40:45 --> Router Class Initialized
INFO - 2023-07-01 04:40:45 --> Output Class Initialized
INFO - 2023-07-01 04:40:45 --> Security Class Initialized
DEBUG - 2023-07-01 04:40:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-01 04:40:45 --> Input Class Initialized
INFO - 2023-07-01 04:40:45 --> Language Class Initialized
INFO - 2023-07-01 04:40:45 --> Loader Class Initialized
INFO - 2023-07-01 04:40:45 --> Helper loaded: url_helper
INFO - 2023-07-01 04:40:45 --> Helper loaded: file_helper
INFO - 2023-07-01 04:40:45 --> Helper loaded: html_helper
INFO - 2023-07-01 04:40:45 --> Helper loaded: text_helper
INFO - 2023-07-01 04:40:45 --> Helper loaded: form_helper
INFO - 2023-07-01 04:40:45 --> Helper loaded: lang_helper
INFO - 2023-07-01 04:40:45 --> Helper loaded: security_helper
INFO - 2023-07-01 04:40:45 --> Helper loaded: cookie_helper
INFO - 2023-07-01 04:40:45 --> Database Driver Class Initialized
INFO - 2023-07-01 04:40:45 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-01 04:40:45 --> Parser Class Initialized
INFO - 2023-07-01 04:40:45 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-01 04:40:45 --> Pagination Class Initialized
INFO - 2023-07-01 04:40:45 --> Form Validation Class Initialized
INFO - 2023-07-01 04:40:45 --> Controller Class Initialized
INFO - 2023-07-01 04:40:45 --> Model Class Initialized
DEBUG - 2023-07-01 04:40:45 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-01 04:40:45 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-01 04:40:45 --> Model Class Initialized
DEBUG - 2023-07-01 04:40:45 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-01 04:40:45 --> Model Class Initialized
DEBUG - 2023-07-01 04:40:45 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-01 04:40:45 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice_html.php
DEBUG - 2023-07-01 04:40:45 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-07-01 04:40:45 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-07-01 04:40:45 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-07-01 04:40:45 --> Model Class Initialized
INFO - 2023-07-01 04:40:45 --> Model Class Initialized
INFO - 2023-07-01 04:40:45 --> Model Class Initialized
INFO - 2023-07-01 04:40:45 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-07-01 04:40:45 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-07-01 04:40:45 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-07-01 04:40:45 --> Final output sent to browser
DEBUG - 2023-07-01 04:40:45 --> Total execution time: 0.0826
ERROR - 2023-07-01 04:40:58 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-01 04:40:58 --> Config Class Initialized
INFO - 2023-07-01 04:40:58 --> Hooks Class Initialized
DEBUG - 2023-07-01 04:40:58 --> UTF-8 Support Enabled
INFO - 2023-07-01 04:40:58 --> Utf8 Class Initialized
INFO - 2023-07-01 04:40:58 --> URI Class Initialized
INFO - 2023-07-01 04:40:58 --> Router Class Initialized
INFO - 2023-07-01 04:40:58 --> Output Class Initialized
INFO - 2023-07-01 04:40:58 --> Security Class Initialized
DEBUG - 2023-07-01 04:40:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-01 04:40:58 --> Input Class Initialized
INFO - 2023-07-01 04:40:58 --> Language Class Initialized
INFO - 2023-07-01 04:40:58 --> Loader Class Initialized
INFO - 2023-07-01 04:40:58 --> Helper loaded: url_helper
INFO - 2023-07-01 04:40:58 --> Helper loaded: file_helper
INFO - 2023-07-01 04:40:58 --> Helper loaded: html_helper
INFO - 2023-07-01 04:40:58 --> Helper loaded: text_helper
INFO - 2023-07-01 04:40:58 --> Helper loaded: form_helper
INFO - 2023-07-01 04:40:58 --> Helper loaded: lang_helper
INFO - 2023-07-01 04:40:58 --> Helper loaded: security_helper
INFO - 2023-07-01 04:40:58 --> Helper loaded: cookie_helper
INFO - 2023-07-01 04:40:58 --> Database Driver Class Initialized
INFO - 2023-07-01 04:40:58 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-01 04:40:58 --> Parser Class Initialized
INFO - 2023-07-01 04:40:58 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-01 04:40:58 --> Pagination Class Initialized
INFO - 2023-07-01 04:40:58 --> Form Validation Class Initialized
INFO - 2023-07-01 04:40:58 --> Controller Class Initialized
INFO - 2023-07-01 04:40:58 --> Model Class Initialized
DEBUG - 2023-07-01 04:40:58 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-01 04:40:58 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-01 04:40:58 --> Model Class Initialized
DEBUG - 2023-07-01 04:40:58 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-01 04:40:58 --> Model Class Initialized
INFO - 2023-07-01 04:40:58 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice.php
DEBUG - 2023-07-01 04:40:58 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-07-01 04:40:58 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-07-01 04:40:58 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-07-01 04:40:58 --> Model Class Initialized
INFO - 2023-07-01 04:40:58 --> Model Class Initialized
INFO - 2023-07-01 04:40:58 --> Model Class Initialized
INFO - 2023-07-01 04:40:58 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-07-01 04:40:58 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-07-01 04:40:58 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-07-01 04:40:58 --> Final output sent to browser
DEBUG - 2023-07-01 04:40:58 --> Total execution time: 0.0762
ERROR - 2023-07-01 04:40:59 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-01 04:40:59 --> Config Class Initialized
INFO - 2023-07-01 04:40:59 --> Hooks Class Initialized
DEBUG - 2023-07-01 04:40:59 --> UTF-8 Support Enabled
INFO - 2023-07-01 04:40:59 --> Utf8 Class Initialized
INFO - 2023-07-01 04:40:59 --> URI Class Initialized
INFO - 2023-07-01 04:40:59 --> Router Class Initialized
INFO - 2023-07-01 04:40:59 --> Output Class Initialized
INFO - 2023-07-01 04:40:59 --> Security Class Initialized
DEBUG - 2023-07-01 04:40:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-01 04:40:59 --> Input Class Initialized
INFO - 2023-07-01 04:40:59 --> Language Class Initialized
INFO - 2023-07-01 04:40:59 --> Loader Class Initialized
INFO - 2023-07-01 04:40:59 --> Helper loaded: url_helper
INFO - 2023-07-01 04:40:59 --> Helper loaded: file_helper
INFO - 2023-07-01 04:40:59 --> Helper loaded: html_helper
INFO - 2023-07-01 04:40:59 --> Helper loaded: text_helper
INFO - 2023-07-01 04:40:59 --> Helper loaded: form_helper
INFO - 2023-07-01 04:40:59 --> Helper loaded: lang_helper
INFO - 2023-07-01 04:40:59 --> Helper loaded: security_helper
INFO - 2023-07-01 04:40:59 --> Helper loaded: cookie_helper
INFO - 2023-07-01 04:40:59 --> Database Driver Class Initialized
INFO - 2023-07-01 04:40:59 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-01 04:40:59 --> Parser Class Initialized
INFO - 2023-07-01 04:40:59 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-01 04:40:59 --> Pagination Class Initialized
INFO - 2023-07-01 04:40:59 --> Form Validation Class Initialized
INFO - 2023-07-01 04:40:59 --> Controller Class Initialized
INFO - 2023-07-01 04:40:59 --> Model Class Initialized
DEBUG - 2023-07-01 04:40:59 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-01 04:40:59 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-01 04:40:59 --> Model Class Initialized
DEBUG - 2023-07-01 04:40:59 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-01 04:40:59 --> Model Class Initialized
INFO - 2023-07-01 04:40:59 --> Final output sent to browser
DEBUG - 2023-07-01 04:40:59 --> Total execution time: 0.0399
ERROR - 2023-07-01 05:20:33 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-01 05:20:33 --> Config Class Initialized
INFO - 2023-07-01 05:20:33 --> Hooks Class Initialized
DEBUG - 2023-07-01 05:20:33 --> UTF-8 Support Enabled
INFO - 2023-07-01 05:20:33 --> Utf8 Class Initialized
INFO - 2023-07-01 05:20:33 --> URI Class Initialized
INFO - 2023-07-01 05:20:33 --> Router Class Initialized
INFO - 2023-07-01 05:20:33 --> Output Class Initialized
INFO - 2023-07-01 05:20:33 --> Security Class Initialized
DEBUG - 2023-07-01 05:20:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-01 05:20:33 --> Input Class Initialized
INFO - 2023-07-01 05:20:33 --> Language Class Initialized
INFO - 2023-07-01 05:20:33 --> Loader Class Initialized
INFO - 2023-07-01 05:20:33 --> Helper loaded: url_helper
INFO - 2023-07-01 05:20:33 --> Helper loaded: file_helper
INFO - 2023-07-01 05:20:33 --> Helper loaded: html_helper
INFO - 2023-07-01 05:20:33 --> Helper loaded: text_helper
INFO - 2023-07-01 05:20:33 --> Helper loaded: form_helper
INFO - 2023-07-01 05:20:33 --> Helper loaded: lang_helper
INFO - 2023-07-01 05:20:33 --> Helper loaded: security_helper
INFO - 2023-07-01 05:20:33 --> Helper loaded: cookie_helper
INFO - 2023-07-01 05:20:33 --> Database Driver Class Initialized
INFO - 2023-07-01 05:20:33 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-01 05:20:33 --> Parser Class Initialized
INFO - 2023-07-01 05:20:33 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-01 05:20:33 --> Pagination Class Initialized
INFO - 2023-07-01 05:20:33 --> Form Validation Class Initialized
INFO - 2023-07-01 05:20:33 --> Controller Class Initialized
INFO - 2023-07-01 05:20:33 --> Model Class Initialized
DEBUG - 2023-07-01 05:20:33 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-01 05:20:33 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2023-07-01 05:20:33 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-07-01 05:20:33 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-07-01 05:20:33 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-07-01 05:20:33 --> Model Class Initialized
INFO - 2023-07-01 05:20:33 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-07-01 05:20:33 --> Final output sent to browser
DEBUG - 2023-07-01 05:20:33 --> Total execution time: 0.0295
ERROR - 2023-07-01 05:21:45 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-01 05:21:45 --> Config Class Initialized
INFO - 2023-07-01 05:21:45 --> Hooks Class Initialized
DEBUG - 2023-07-01 05:21:45 --> UTF-8 Support Enabled
INFO - 2023-07-01 05:21:45 --> Utf8 Class Initialized
INFO - 2023-07-01 05:21:45 --> URI Class Initialized
INFO - 2023-07-01 05:21:45 --> Router Class Initialized
INFO - 2023-07-01 05:21:45 --> Output Class Initialized
INFO - 2023-07-01 05:21:45 --> Security Class Initialized
DEBUG - 2023-07-01 05:21:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-01 05:21:45 --> Input Class Initialized
INFO - 2023-07-01 05:21:45 --> Language Class Initialized
INFO - 2023-07-01 05:21:45 --> Loader Class Initialized
INFO - 2023-07-01 05:21:45 --> Helper loaded: url_helper
INFO - 2023-07-01 05:21:45 --> Helper loaded: file_helper
INFO - 2023-07-01 05:21:45 --> Helper loaded: html_helper
INFO - 2023-07-01 05:21:45 --> Helper loaded: text_helper
INFO - 2023-07-01 05:21:45 --> Helper loaded: form_helper
INFO - 2023-07-01 05:21:45 --> Helper loaded: lang_helper
INFO - 2023-07-01 05:21:45 --> Helper loaded: security_helper
INFO - 2023-07-01 05:21:45 --> Helper loaded: cookie_helper
INFO - 2023-07-01 05:21:45 --> Database Driver Class Initialized
INFO - 2023-07-01 05:21:45 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-01 05:21:45 --> Parser Class Initialized
INFO - 2023-07-01 05:21:45 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-01 05:21:45 --> Pagination Class Initialized
INFO - 2023-07-01 05:21:45 --> Form Validation Class Initialized
INFO - 2023-07-01 05:21:45 --> Controller Class Initialized
ERROR - 2023-07-01 05:29:19 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-01 05:29:19 --> Config Class Initialized
INFO - 2023-07-01 05:29:19 --> Hooks Class Initialized
DEBUG - 2023-07-01 05:29:19 --> UTF-8 Support Enabled
INFO - 2023-07-01 05:29:19 --> Utf8 Class Initialized
INFO - 2023-07-01 05:29:19 --> URI Class Initialized
DEBUG - 2023-07-01 05:29:19 --> No URI present. Default controller set.
INFO - 2023-07-01 05:29:19 --> Router Class Initialized
INFO - 2023-07-01 05:29:19 --> Output Class Initialized
INFO - 2023-07-01 05:29:19 --> Security Class Initialized
DEBUG - 2023-07-01 05:29:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-01 05:29:19 --> Input Class Initialized
INFO - 2023-07-01 05:29:19 --> Language Class Initialized
INFO - 2023-07-01 05:29:19 --> Loader Class Initialized
INFO - 2023-07-01 05:29:19 --> Helper loaded: url_helper
INFO - 2023-07-01 05:29:19 --> Helper loaded: file_helper
INFO - 2023-07-01 05:29:19 --> Helper loaded: html_helper
INFO - 2023-07-01 05:29:19 --> Helper loaded: text_helper
INFO - 2023-07-01 05:29:19 --> Helper loaded: form_helper
INFO - 2023-07-01 05:29:19 --> Helper loaded: lang_helper
INFO - 2023-07-01 05:29:19 --> Helper loaded: security_helper
INFO - 2023-07-01 05:29:19 --> Helper loaded: cookie_helper
INFO - 2023-07-01 05:29:19 --> Database Driver Class Initialized
INFO - 2023-07-01 05:29:19 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-01 05:29:19 --> Parser Class Initialized
INFO - 2023-07-01 05:29:19 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-01 05:29:19 --> Pagination Class Initialized
INFO - 2023-07-01 05:29:19 --> Form Validation Class Initialized
INFO - 2023-07-01 05:29:19 --> Controller Class Initialized
INFO - 2023-07-01 05:29:19 --> Model Class Initialized
DEBUG - 2023-07-01 05:29:19 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-01 05:29:19 --> Model Class Initialized
DEBUG - 2023-07-01 05:29:19 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-01 05:29:19 --> Model Class Initialized
INFO - 2023-07-01 05:29:19 --> Model Class Initialized
INFO - 2023-07-01 05:29:19 --> Model Class Initialized
INFO - 2023-07-01 05:29:19 --> Model Class Initialized
DEBUG - 2023-07-01 05:29:19 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-01 05:29:19 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-01 05:29:19 --> Model Class Initialized
INFO - 2023-07-01 05:29:19 --> Model Class Initialized
INFO - 2023-07-01 05:29:19 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-07-01 05:29:19 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-07-01 05:29:19 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-07-01 05:29:19 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-07-01 05:29:19 --> Model Class Initialized
INFO - 2023-07-01 05:29:19 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-07-01 05:29:19 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-07-01 05:29:19 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-07-01 05:29:19 --> Final output sent to browser
DEBUG - 2023-07-01 05:29:19 --> Total execution time: 0.0846
ERROR - 2023-07-01 05:29:26 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-01 05:29:26 --> Config Class Initialized
INFO - 2023-07-01 05:29:26 --> Hooks Class Initialized
DEBUG - 2023-07-01 05:29:26 --> UTF-8 Support Enabled
INFO - 2023-07-01 05:29:26 --> Utf8 Class Initialized
INFO - 2023-07-01 05:29:26 --> URI Class Initialized
INFO - 2023-07-01 05:29:26 --> Router Class Initialized
INFO - 2023-07-01 05:29:26 --> Output Class Initialized
INFO - 2023-07-01 05:29:26 --> Security Class Initialized
DEBUG - 2023-07-01 05:29:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-01 05:29:26 --> Input Class Initialized
INFO - 2023-07-01 05:29:26 --> Language Class Initialized
INFO - 2023-07-01 05:29:26 --> Loader Class Initialized
INFO - 2023-07-01 05:29:26 --> Helper loaded: url_helper
INFO - 2023-07-01 05:29:26 --> Helper loaded: file_helper
INFO - 2023-07-01 05:29:26 --> Helper loaded: html_helper
INFO - 2023-07-01 05:29:26 --> Helper loaded: text_helper
INFO - 2023-07-01 05:29:26 --> Helper loaded: form_helper
INFO - 2023-07-01 05:29:26 --> Helper loaded: lang_helper
INFO - 2023-07-01 05:29:26 --> Helper loaded: security_helper
INFO - 2023-07-01 05:29:26 --> Helper loaded: cookie_helper
INFO - 2023-07-01 05:29:26 --> Database Driver Class Initialized
INFO - 2023-07-01 05:29:26 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-01 05:29:26 --> Parser Class Initialized
INFO - 2023-07-01 05:29:26 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-01 05:29:26 --> Pagination Class Initialized
INFO - 2023-07-01 05:29:26 --> Form Validation Class Initialized
INFO - 2023-07-01 05:29:26 --> Controller Class Initialized
INFO - 2023-07-01 05:29:26 --> Model Class Initialized
DEBUG - 2023-07-01 05:29:26 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-01 05:29:26 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-01 05:29:26 --> Model Class Initialized
DEBUG - 2023-07-01 05:29:26 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-01 05:29:26 --> Model Class Initialized
INFO - 2023-07-01 05:29:26 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/add_invoice_form.php
DEBUG - 2023-07-01 05:29:26 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-07-01 05:29:26 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-07-01 05:29:26 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-07-01 05:29:26 --> Model Class Initialized
INFO - 2023-07-01 05:29:26 --> Model Class Initialized
INFO - 2023-07-01 05:29:26 --> Model Class Initialized
INFO - 2023-07-01 05:29:26 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-07-01 05:29:26 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-07-01 05:29:26 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-07-01 05:29:26 --> Final output sent to browser
DEBUG - 2023-07-01 05:29:26 --> Total execution time: 0.1163
ERROR - 2023-07-01 05:29:32 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-01 05:29:32 --> Config Class Initialized
INFO - 2023-07-01 05:29:32 --> Hooks Class Initialized
DEBUG - 2023-07-01 05:29:32 --> UTF-8 Support Enabled
INFO - 2023-07-01 05:29:32 --> Utf8 Class Initialized
INFO - 2023-07-01 05:29:32 --> URI Class Initialized
INFO - 2023-07-01 05:29:32 --> Router Class Initialized
INFO - 2023-07-01 05:29:32 --> Output Class Initialized
INFO - 2023-07-01 05:29:32 --> Security Class Initialized
DEBUG - 2023-07-01 05:29:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-01 05:29:32 --> Input Class Initialized
INFO - 2023-07-01 05:29:32 --> Language Class Initialized
INFO - 2023-07-01 05:29:32 --> Loader Class Initialized
INFO - 2023-07-01 05:29:32 --> Helper loaded: url_helper
INFO - 2023-07-01 05:29:32 --> Helper loaded: file_helper
INFO - 2023-07-01 05:29:32 --> Helper loaded: html_helper
INFO - 2023-07-01 05:29:32 --> Helper loaded: text_helper
INFO - 2023-07-01 05:29:32 --> Helper loaded: form_helper
INFO - 2023-07-01 05:29:32 --> Helper loaded: lang_helper
INFO - 2023-07-01 05:29:32 --> Helper loaded: security_helper
INFO - 2023-07-01 05:29:32 --> Helper loaded: cookie_helper
INFO - 2023-07-01 05:29:32 --> Database Driver Class Initialized
INFO - 2023-07-01 05:29:32 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-01 05:29:32 --> Parser Class Initialized
INFO - 2023-07-01 05:29:32 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-01 05:29:32 --> Pagination Class Initialized
INFO - 2023-07-01 05:29:32 --> Form Validation Class Initialized
INFO - 2023-07-01 05:29:32 --> Controller Class Initialized
INFO - 2023-07-01 05:29:32 --> Model Class Initialized
DEBUG - 2023-07-01 05:29:32 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-01 05:29:32 --> Final output sent to browser
DEBUG - 2023-07-01 05:29:32 --> Total execution time: 0.0160
ERROR - 2023-07-01 05:29:34 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-01 05:29:34 --> Config Class Initialized
INFO - 2023-07-01 05:29:34 --> Hooks Class Initialized
DEBUG - 2023-07-01 05:29:34 --> UTF-8 Support Enabled
INFO - 2023-07-01 05:29:34 --> Utf8 Class Initialized
INFO - 2023-07-01 05:29:34 --> URI Class Initialized
INFO - 2023-07-01 05:29:34 --> Router Class Initialized
INFO - 2023-07-01 05:29:34 --> Output Class Initialized
INFO - 2023-07-01 05:29:34 --> Security Class Initialized
DEBUG - 2023-07-01 05:29:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-01 05:29:34 --> Input Class Initialized
INFO - 2023-07-01 05:29:34 --> Language Class Initialized
INFO - 2023-07-01 05:29:34 --> Loader Class Initialized
INFO - 2023-07-01 05:29:34 --> Helper loaded: url_helper
INFO - 2023-07-01 05:29:34 --> Helper loaded: file_helper
INFO - 2023-07-01 05:29:34 --> Helper loaded: html_helper
INFO - 2023-07-01 05:29:34 --> Helper loaded: text_helper
INFO - 2023-07-01 05:29:34 --> Helper loaded: form_helper
INFO - 2023-07-01 05:29:34 --> Helper loaded: lang_helper
INFO - 2023-07-01 05:29:34 --> Helper loaded: security_helper
INFO - 2023-07-01 05:29:34 --> Helper loaded: cookie_helper
INFO - 2023-07-01 05:29:34 --> Database Driver Class Initialized
INFO - 2023-07-01 05:29:34 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-01 05:29:34 --> Parser Class Initialized
INFO - 2023-07-01 05:29:34 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-01 05:29:34 --> Pagination Class Initialized
INFO - 2023-07-01 05:29:34 --> Form Validation Class Initialized
INFO - 2023-07-01 05:29:34 --> Controller Class Initialized
INFO - 2023-07-01 05:29:34 --> Final output sent to browser
DEBUG - 2023-07-01 05:29:34 --> Total execution time: 0.0172
ERROR - 2023-07-01 05:29:50 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-01 05:29:50 --> Config Class Initialized
INFO - 2023-07-01 05:29:50 --> Hooks Class Initialized
DEBUG - 2023-07-01 05:29:50 --> UTF-8 Support Enabled
INFO - 2023-07-01 05:29:50 --> Utf8 Class Initialized
INFO - 2023-07-01 05:29:50 --> URI Class Initialized
INFO - 2023-07-01 05:29:50 --> Router Class Initialized
INFO - 2023-07-01 05:29:50 --> Output Class Initialized
INFO - 2023-07-01 05:29:50 --> Security Class Initialized
DEBUG - 2023-07-01 05:29:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-01 05:29:50 --> Input Class Initialized
INFO - 2023-07-01 05:29:50 --> Language Class Initialized
INFO - 2023-07-01 05:29:50 --> Loader Class Initialized
INFO - 2023-07-01 05:29:50 --> Helper loaded: url_helper
INFO - 2023-07-01 05:29:50 --> Helper loaded: file_helper
INFO - 2023-07-01 05:29:50 --> Helper loaded: html_helper
INFO - 2023-07-01 05:29:50 --> Helper loaded: text_helper
INFO - 2023-07-01 05:29:50 --> Helper loaded: form_helper
INFO - 2023-07-01 05:29:50 --> Helper loaded: lang_helper
INFO - 2023-07-01 05:29:50 --> Helper loaded: security_helper
INFO - 2023-07-01 05:29:50 --> Helper loaded: cookie_helper
INFO - 2023-07-01 05:29:50 --> Database Driver Class Initialized
INFO - 2023-07-01 05:29:50 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-01 05:29:50 --> Parser Class Initialized
INFO - 2023-07-01 05:29:50 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-01 05:29:50 --> Pagination Class Initialized
INFO - 2023-07-01 05:29:50 --> Form Validation Class Initialized
INFO - 2023-07-01 05:29:50 --> Controller Class Initialized
INFO - 2023-07-01 05:29:50 --> Model Class Initialized
DEBUG - 2023-07-01 05:29:50 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-01 05:29:50 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-01 05:29:50 --> Model Class Initialized
DEBUG - 2023-07-01 05:29:50 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-01 05:29:50 --> Model Class Initialized
INFO - 2023-07-01 05:29:50 --> Final output sent to browser
DEBUG - 2023-07-01 05:29:50 --> Total execution time: 0.0491
ERROR - 2023-07-01 05:29:51 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-01 05:29:51 --> Config Class Initialized
INFO - 2023-07-01 05:29:51 --> Hooks Class Initialized
DEBUG - 2023-07-01 05:29:51 --> UTF-8 Support Enabled
INFO - 2023-07-01 05:29:51 --> Utf8 Class Initialized
INFO - 2023-07-01 05:29:51 --> URI Class Initialized
INFO - 2023-07-01 05:29:51 --> Router Class Initialized
INFO - 2023-07-01 05:29:51 --> Output Class Initialized
INFO - 2023-07-01 05:29:51 --> Security Class Initialized
DEBUG - 2023-07-01 05:29:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-01 05:29:51 --> Input Class Initialized
INFO - 2023-07-01 05:29:51 --> Language Class Initialized
INFO - 2023-07-01 05:29:51 --> Loader Class Initialized
INFO - 2023-07-01 05:29:51 --> Helper loaded: url_helper
INFO - 2023-07-01 05:29:51 --> Helper loaded: file_helper
INFO - 2023-07-01 05:29:51 --> Helper loaded: html_helper
INFO - 2023-07-01 05:29:51 --> Helper loaded: text_helper
INFO - 2023-07-01 05:29:51 --> Helper loaded: form_helper
INFO - 2023-07-01 05:29:51 --> Helper loaded: lang_helper
INFO - 2023-07-01 05:29:51 --> Helper loaded: security_helper
INFO - 2023-07-01 05:29:51 --> Helper loaded: cookie_helper
INFO - 2023-07-01 05:29:51 --> Database Driver Class Initialized
INFO - 2023-07-01 05:29:51 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-01 05:29:51 --> Parser Class Initialized
INFO - 2023-07-01 05:29:51 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-01 05:29:51 --> Pagination Class Initialized
INFO - 2023-07-01 05:29:51 --> Form Validation Class Initialized
INFO - 2023-07-01 05:29:51 --> Controller Class Initialized
INFO - 2023-07-01 05:29:51 --> Model Class Initialized
DEBUG - 2023-07-01 05:29:51 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-01 05:29:51 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-01 05:29:51 --> Model Class Initialized
DEBUG - 2023-07-01 05:29:51 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-01 05:29:51 --> Model Class Initialized
INFO - 2023-07-01 05:29:51 --> Final output sent to browser
DEBUG - 2023-07-01 05:29:51 --> Total execution time: 0.0458
ERROR - 2023-07-01 05:29:51 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-01 05:29:51 --> Config Class Initialized
INFO - 2023-07-01 05:29:51 --> Hooks Class Initialized
DEBUG - 2023-07-01 05:29:51 --> UTF-8 Support Enabled
INFO - 2023-07-01 05:29:51 --> Utf8 Class Initialized
INFO - 2023-07-01 05:29:51 --> URI Class Initialized
INFO - 2023-07-01 05:29:51 --> Router Class Initialized
INFO - 2023-07-01 05:29:51 --> Output Class Initialized
INFO - 2023-07-01 05:29:51 --> Security Class Initialized
DEBUG - 2023-07-01 05:29:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-01 05:29:51 --> Input Class Initialized
INFO - 2023-07-01 05:29:51 --> Language Class Initialized
INFO - 2023-07-01 05:29:51 --> Loader Class Initialized
INFO - 2023-07-01 05:29:51 --> Helper loaded: url_helper
INFO - 2023-07-01 05:29:51 --> Helper loaded: file_helper
INFO - 2023-07-01 05:29:51 --> Helper loaded: html_helper
INFO - 2023-07-01 05:29:51 --> Helper loaded: text_helper
INFO - 2023-07-01 05:29:51 --> Helper loaded: form_helper
INFO - 2023-07-01 05:29:51 --> Helper loaded: lang_helper
INFO - 2023-07-01 05:29:51 --> Helper loaded: security_helper
INFO - 2023-07-01 05:29:51 --> Helper loaded: cookie_helper
INFO - 2023-07-01 05:29:51 --> Database Driver Class Initialized
INFO - 2023-07-01 05:29:51 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-01 05:29:51 --> Parser Class Initialized
INFO - 2023-07-01 05:29:51 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-01 05:29:51 --> Pagination Class Initialized
INFO - 2023-07-01 05:29:51 --> Form Validation Class Initialized
INFO - 2023-07-01 05:29:51 --> Controller Class Initialized
INFO - 2023-07-01 05:29:51 --> Model Class Initialized
DEBUG - 2023-07-01 05:29:51 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-01 05:29:51 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-01 05:29:51 --> Model Class Initialized
DEBUG - 2023-07-01 05:29:51 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-01 05:29:51 --> Model Class Initialized
INFO - 2023-07-01 05:29:51 --> Final output sent to browser
DEBUG - 2023-07-01 05:29:51 --> Total execution time: 0.0485
ERROR - 2023-07-01 05:29:54 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-01 05:29:54 --> Config Class Initialized
INFO - 2023-07-01 05:29:54 --> Hooks Class Initialized
DEBUG - 2023-07-01 05:29:54 --> UTF-8 Support Enabled
INFO - 2023-07-01 05:29:54 --> Utf8 Class Initialized
INFO - 2023-07-01 05:29:54 --> URI Class Initialized
INFO - 2023-07-01 05:29:54 --> Router Class Initialized
INFO - 2023-07-01 05:29:54 --> Output Class Initialized
INFO - 2023-07-01 05:29:54 --> Security Class Initialized
DEBUG - 2023-07-01 05:29:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-01 05:29:54 --> Input Class Initialized
INFO - 2023-07-01 05:29:54 --> Language Class Initialized
INFO - 2023-07-01 05:29:54 --> Loader Class Initialized
INFO - 2023-07-01 05:29:54 --> Helper loaded: url_helper
INFO - 2023-07-01 05:29:54 --> Helper loaded: file_helper
INFO - 2023-07-01 05:29:54 --> Helper loaded: html_helper
INFO - 2023-07-01 05:29:54 --> Helper loaded: text_helper
INFO - 2023-07-01 05:29:54 --> Helper loaded: form_helper
INFO - 2023-07-01 05:29:54 --> Helper loaded: lang_helper
INFO - 2023-07-01 05:29:54 --> Helper loaded: security_helper
INFO - 2023-07-01 05:29:54 --> Helper loaded: cookie_helper
INFO - 2023-07-01 05:29:54 --> Database Driver Class Initialized
INFO - 2023-07-01 05:29:54 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-01 05:29:54 --> Parser Class Initialized
INFO - 2023-07-01 05:29:54 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-01 05:29:54 --> Pagination Class Initialized
INFO - 2023-07-01 05:29:54 --> Form Validation Class Initialized
INFO - 2023-07-01 05:29:54 --> Controller Class Initialized
INFO - 2023-07-01 05:29:54 --> Model Class Initialized
DEBUG - 2023-07-01 05:29:54 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-01 05:29:54 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-01 05:29:54 --> Model Class Initialized
DEBUG - 2023-07-01 05:29:54 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-01 05:29:54 --> Model Class Initialized
INFO - 2023-07-01 05:29:54 --> Final output sent to browser
DEBUG - 2023-07-01 05:29:54 --> Total execution time: 0.0279
ERROR - 2023-07-01 05:29:55 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-01 05:29:55 --> Config Class Initialized
INFO - 2023-07-01 05:29:55 --> Hooks Class Initialized
DEBUG - 2023-07-01 05:29:55 --> UTF-8 Support Enabled
INFO - 2023-07-01 05:29:55 --> Utf8 Class Initialized
INFO - 2023-07-01 05:29:55 --> URI Class Initialized
INFO - 2023-07-01 05:29:55 --> Router Class Initialized
INFO - 2023-07-01 05:29:55 --> Output Class Initialized
INFO - 2023-07-01 05:29:55 --> Security Class Initialized
DEBUG - 2023-07-01 05:29:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-01 05:29:55 --> Input Class Initialized
INFO - 2023-07-01 05:29:55 --> Language Class Initialized
INFO - 2023-07-01 05:29:55 --> Loader Class Initialized
INFO - 2023-07-01 05:29:55 --> Helper loaded: url_helper
INFO - 2023-07-01 05:29:55 --> Helper loaded: file_helper
INFO - 2023-07-01 05:29:55 --> Helper loaded: html_helper
INFO - 2023-07-01 05:29:55 --> Helper loaded: text_helper
INFO - 2023-07-01 05:29:55 --> Helper loaded: form_helper
INFO - 2023-07-01 05:29:55 --> Helper loaded: lang_helper
INFO - 2023-07-01 05:29:55 --> Helper loaded: security_helper
INFO - 2023-07-01 05:29:55 --> Helper loaded: cookie_helper
INFO - 2023-07-01 05:29:55 --> Database Driver Class Initialized
INFO - 2023-07-01 05:29:55 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-01 05:29:55 --> Parser Class Initialized
INFO - 2023-07-01 05:29:55 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-01 05:29:55 --> Pagination Class Initialized
INFO - 2023-07-01 05:29:55 --> Form Validation Class Initialized
INFO - 2023-07-01 05:29:55 --> Controller Class Initialized
INFO - 2023-07-01 05:29:55 --> Model Class Initialized
DEBUG - 2023-07-01 05:29:55 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-01 05:29:55 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-01 05:29:55 --> Model Class Initialized
DEBUG - 2023-07-01 05:29:55 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-01 05:29:55 --> Model Class Initialized
INFO - 2023-07-01 05:29:55 --> Final output sent to browser
DEBUG - 2023-07-01 05:29:55 --> Total execution time: 0.0171
ERROR - 2023-07-01 05:29:57 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-01 05:29:57 --> Config Class Initialized
INFO - 2023-07-01 05:29:57 --> Hooks Class Initialized
DEBUG - 2023-07-01 05:29:57 --> UTF-8 Support Enabled
INFO - 2023-07-01 05:29:57 --> Utf8 Class Initialized
INFO - 2023-07-01 05:29:57 --> URI Class Initialized
INFO - 2023-07-01 05:29:57 --> Router Class Initialized
INFO - 2023-07-01 05:29:57 --> Output Class Initialized
INFO - 2023-07-01 05:29:57 --> Security Class Initialized
DEBUG - 2023-07-01 05:29:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-01 05:29:57 --> Input Class Initialized
INFO - 2023-07-01 05:29:57 --> Language Class Initialized
INFO - 2023-07-01 05:29:57 --> Loader Class Initialized
INFO - 2023-07-01 05:29:57 --> Helper loaded: url_helper
INFO - 2023-07-01 05:29:57 --> Helper loaded: file_helper
INFO - 2023-07-01 05:29:57 --> Helper loaded: html_helper
INFO - 2023-07-01 05:29:57 --> Helper loaded: text_helper
INFO - 2023-07-01 05:29:57 --> Helper loaded: form_helper
INFO - 2023-07-01 05:29:57 --> Helper loaded: lang_helper
INFO - 2023-07-01 05:29:57 --> Helper loaded: security_helper
INFO - 2023-07-01 05:29:57 --> Helper loaded: cookie_helper
INFO - 2023-07-01 05:29:57 --> Database Driver Class Initialized
INFO - 2023-07-01 05:29:57 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-01 05:29:57 --> Parser Class Initialized
INFO - 2023-07-01 05:29:57 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-01 05:29:57 --> Pagination Class Initialized
INFO - 2023-07-01 05:29:57 --> Form Validation Class Initialized
INFO - 2023-07-01 05:29:57 --> Controller Class Initialized
INFO - 2023-07-01 05:29:57 --> Model Class Initialized
DEBUG - 2023-07-01 05:29:57 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-01 05:29:57 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-01 05:29:57 --> Model Class Initialized
DEBUG - 2023-07-01 05:29:57 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-01 05:29:57 --> Model Class Initialized
INFO - 2023-07-01 05:29:57 --> Final output sent to browser
DEBUG - 2023-07-01 05:29:57 --> Total execution time: 0.0201
ERROR - 2023-07-01 05:29:59 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-01 05:29:59 --> Config Class Initialized
INFO - 2023-07-01 05:29:59 --> Hooks Class Initialized
DEBUG - 2023-07-01 05:29:59 --> UTF-8 Support Enabled
INFO - 2023-07-01 05:29:59 --> Utf8 Class Initialized
INFO - 2023-07-01 05:29:59 --> URI Class Initialized
INFO - 2023-07-01 05:29:59 --> Router Class Initialized
INFO - 2023-07-01 05:29:59 --> Output Class Initialized
INFO - 2023-07-01 05:29:59 --> Security Class Initialized
DEBUG - 2023-07-01 05:29:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-01 05:29:59 --> Input Class Initialized
INFO - 2023-07-01 05:29:59 --> Language Class Initialized
INFO - 2023-07-01 05:29:59 --> Loader Class Initialized
INFO - 2023-07-01 05:29:59 --> Helper loaded: url_helper
INFO - 2023-07-01 05:29:59 --> Helper loaded: file_helper
INFO - 2023-07-01 05:29:59 --> Helper loaded: html_helper
INFO - 2023-07-01 05:29:59 --> Helper loaded: text_helper
INFO - 2023-07-01 05:29:59 --> Helper loaded: form_helper
INFO - 2023-07-01 05:29:59 --> Helper loaded: lang_helper
INFO - 2023-07-01 05:29:59 --> Helper loaded: security_helper
INFO - 2023-07-01 05:29:59 --> Helper loaded: cookie_helper
INFO - 2023-07-01 05:29:59 --> Database Driver Class Initialized
INFO - 2023-07-01 05:29:59 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-01 05:29:59 --> Parser Class Initialized
INFO - 2023-07-01 05:29:59 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-01 05:29:59 --> Pagination Class Initialized
INFO - 2023-07-01 05:29:59 --> Form Validation Class Initialized
INFO - 2023-07-01 05:29:59 --> Controller Class Initialized
INFO - 2023-07-01 05:29:59 --> Model Class Initialized
DEBUG - 2023-07-01 05:29:59 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-01 05:29:59 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-01 05:29:59 --> Model Class Initialized
DEBUG - 2023-07-01 05:29:59 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-01 05:29:59 --> Model Class Initialized
INFO - 2023-07-01 05:29:59 --> Final output sent to browser
DEBUG - 2023-07-01 05:29:59 --> Total execution time: 0.0245
ERROR - 2023-07-01 05:30:01 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-01 05:30:01 --> Config Class Initialized
INFO - 2023-07-01 05:30:01 --> Hooks Class Initialized
DEBUG - 2023-07-01 05:30:01 --> UTF-8 Support Enabled
INFO - 2023-07-01 05:30:01 --> Utf8 Class Initialized
INFO - 2023-07-01 05:30:01 --> URI Class Initialized
INFO - 2023-07-01 05:30:01 --> Router Class Initialized
INFO - 2023-07-01 05:30:01 --> Output Class Initialized
INFO - 2023-07-01 05:30:01 --> Security Class Initialized
DEBUG - 2023-07-01 05:30:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-01 05:30:01 --> Input Class Initialized
INFO - 2023-07-01 05:30:01 --> Language Class Initialized
INFO - 2023-07-01 05:30:01 --> Loader Class Initialized
INFO - 2023-07-01 05:30:01 --> Helper loaded: url_helper
INFO - 2023-07-01 05:30:01 --> Helper loaded: file_helper
INFO - 2023-07-01 05:30:01 --> Helper loaded: html_helper
INFO - 2023-07-01 05:30:01 --> Helper loaded: text_helper
INFO - 2023-07-01 05:30:01 --> Helper loaded: form_helper
INFO - 2023-07-01 05:30:01 --> Helper loaded: lang_helper
INFO - 2023-07-01 05:30:01 --> Helper loaded: security_helper
INFO - 2023-07-01 05:30:01 --> Helper loaded: cookie_helper
INFO - 2023-07-01 05:30:01 --> Database Driver Class Initialized
INFO - 2023-07-01 05:30:01 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-01 05:30:01 --> Parser Class Initialized
INFO - 2023-07-01 05:30:01 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-01 05:30:01 --> Pagination Class Initialized
INFO - 2023-07-01 05:30:01 --> Form Validation Class Initialized
INFO - 2023-07-01 05:30:01 --> Controller Class Initialized
INFO - 2023-07-01 05:30:01 --> Model Class Initialized
DEBUG - 2023-07-01 05:30:01 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-01 05:30:01 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-01 05:30:01 --> Model Class Initialized
INFO - 2023-07-01 05:30:01 --> Model Class Initialized
INFO - 2023-07-01 05:30:01 --> Final output sent to browser
DEBUG - 2023-07-01 05:30:01 --> Total execution time: 0.0181
ERROR - 2023-07-01 05:30:06 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-01 05:30:06 --> Config Class Initialized
INFO - 2023-07-01 05:30:06 --> Hooks Class Initialized
DEBUG - 2023-07-01 05:30:06 --> UTF-8 Support Enabled
INFO - 2023-07-01 05:30:06 --> Utf8 Class Initialized
INFO - 2023-07-01 05:30:06 --> URI Class Initialized
INFO - 2023-07-01 05:30:06 --> Router Class Initialized
INFO - 2023-07-01 05:30:06 --> Output Class Initialized
INFO - 2023-07-01 05:30:06 --> Security Class Initialized
DEBUG - 2023-07-01 05:30:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-01 05:30:06 --> Input Class Initialized
INFO - 2023-07-01 05:30:06 --> Language Class Initialized
INFO - 2023-07-01 05:30:06 --> Loader Class Initialized
INFO - 2023-07-01 05:30:06 --> Helper loaded: url_helper
INFO - 2023-07-01 05:30:06 --> Helper loaded: file_helper
INFO - 2023-07-01 05:30:06 --> Helper loaded: html_helper
INFO - 2023-07-01 05:30:06 --> Helper loaded: text_helper
INFO - 2023-07-01 05:30:06 --> Helper loaded: form_helper
INFO - 2023-07-01 05:30:06 --> Helper loaded: lang_helper
INFO - 2023-07-01 05:30:06 --> Helper loaded: security_helper
INFO - 2023-07-01 05:30:06 --> Helper loaded: cookie_helper
INFO - 2023-07-01 05:30:06 --> Database Driver Class Initialized
INFO - 2023-07-01 05:30:06 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-01 05:30:06 --> Parser Class Initialized
INFO - 2023-07-01 05:30:06 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-01 05:30:06 --> Pagination Class Initialized
INFO - 2023-07-01 05:30:06 --> Form Validation Class Initialized
INFO - 2023-07-01 05:30:06 --> Controller Class Initialized
INFO - 2023-07-01 05:30:06 --> Model Class Initialized
DEBUG - 2023-07-01 05:30:06 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-01 05:30:06 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-01 05:30:06 --> Model Class Initialized
DEBUG - 2023-07-01 05:30:06 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-01 05:30:06 --> Model Class Initialized
INFO - 2023-07-01 05:30:06 --> Final output sent to browser
DEBUG - 2023-07-01 05:30:06 --> Total execution time: 0.0183
ERROR - 2023-07-01 05:30:12 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-01 05:30:12 --> Config Class Initialized
INFO - 2023-07-01 05:30:12 --> Hooks Class Initialized
DEBUG - 2023-07-01 05:30:12 --> UTF-8 Support Enabled
INFO - 2023-07-01 05:30:12 --> Utf8 Class Initialized
INFO - 2023-07-01 05:30:12 --> URI Class Initialized
INFO - 2023-07-01 05:30:12 --> Router Class Initialized
INFO - 2023-07-01 05:30:12 --> Output Class Initialized
INFO - 2023-07-01 05:30:12 --> Security Class Initialized
DEBUG - 2023-07-01 05:30:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-01 05:30:12 --> Input Class Initialized
INFO - 2023-07-01 05:30:12 --> Language Class Initialized
INFO - 2023-07-01 05:30:12 --> Loader Class Initialized
INFO - 2023-07-01 05:30:12 --> Helper loaded: url_helper
INFO - 2023-07-01 05:30:12 --> Helper loaded: file_helper
INFO - 2023-07-01 05:30:12 --> Helper loaded: html_helper
INFO - 2023-07-01 05:30:12 --> Helper loaded: text_helper
INFO - 2023-07-01 05:30:12 --> Helper loaded: form_helper
INFO - 2023-07-01 05:30:12 --> Helper loaded: lang_helper
INFO - 2023-07-01 05:30:12 --> Helper loaded: security_helper
INFO - 2023-07-01 05:30:12 --> Helper loaded: cookie_helper
INFO - 2023-07-01 05:30:12 --> Database Driver Class Initialized
INFO - 2023-07-01 05:30:12 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-01 05:30:12 --> Parser Class Initialized
INFO - 2023-07-01 05:30:12 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-01 05:30:12 --> Pagination Class Initialized
INFO - 2023-07-01 05:30:12 --> Form Validation Class Initialized
INFO - 2023-07-01 05:30:12 --> Controller Class Initialized
INFO - 2023-07-01 05:30:12 --> Model Class Initialized
DEBUG - 2023-07-01 05:30:12 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-01 05:30:12 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-01 05:30:12 --> Model Class Initialized
DEBUG - 2023-07-01 05:30:12 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-01 05:30:12 --> Model Class Initialized
INFO - 2023-07-01 05:30:12 --> Final output sent to browser
DEBUG - 2023-07-01 05:30:12 --> Total execution time: 0.0179
ERROR - 2023-07-01 05:30:13 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-01 05:30:13 --> Config Class Initialized
INFO - 2023-07-01 05:30:13 --> Hooks Class Initialized
DEBUG - 2023-07-01 05:30:13 --> UTF-8 Support Enabled
INFO - 2023-07-01 05:30:13 --> Utf8 Class Initialized
INFO - 2023-07-01 05:30:13 --> URI Class Initialized
INFO - 2023-07-01 05:30:13 --> Router Class Initialized
INFO - 2023-07-01 05:30:13 --> Output Class Initialized
INFO - 2023-07-01 05:30:13 --> Security Class Initialized
DEBUG - 2023-07-01 05:30:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-01 05:30:13 --> Input Class Initialized
INFO - 2023-07-01 05:30:13 --> Language Class Initialized
INFO - 2023-07-01 05:30:13 --> Loader Class Initialized
INFO - 2023-07-01 05:30:13 --> Helper loaded: url_helper
INFO - 2023-07-01 05:30:13 --> Helper loaded: file_helper
INFO - 2023-07-01 05:30:13 --> Helper loaded: html_helper
INFO - 2023-07-01 05:30:13 --> Helper loaded: text_helper
INFO - 2023-07-01 05:30:13 --> Helper loaded: form_helper
INFO - 2023-07-01 05:30:13 --> Helper loaded: lang_helper
INFO - 2023-07-01 05:30:13 --> Helper loaded: security_helper
INFO - 2023-07-01 05:30:13 --> Helper loaded: cookie_helper
INFO - 2023-07-01 05:30:13 --> Database Driver Class Initialized
INFO - 2023-07-01 05:30:13 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-01 05:30:13 --> Parser Class Initialized
INFO - 2023-07-01 05:30:13 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-01 05:30:13 --> Pagination Class Initialized
INFO - 2023-07-01 05:30:13 --> Form Validation Class Initialized
INFO - 2023-07-01 05:30:13 --> Controller Class Initialized
INFO - 2023-07-01 05:30:13 --> Model Class Initialized
DEBUG - 2023-07-01 05:30:13 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-01 05:30:13 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-01 05:30:13 --> Model Class Initialized
DEBUG - 2023-07-01 05:30:13 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-01 05:30:13 --> Model Class Initialized
INFO - 2023-07-01 05:30:13 --> Final output sent to browser
DEBUG - 2023-07-01 05:30:13 --> Total execution time: 0.0184
ERROR - 2023-07-01 05:30:15 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-01 05:30:15 --> Config Class Initialized
INFO - 2023-07-01 05:30:15 --> Hooks Class Initialized
DEBUG - 2023-07-01 05:30:15 --> UTF-8 Support Enabled
INFO - 2023-07-01 05:30:15 --> Utf8 Class Initialized
INFO - 2023-07-01 05:30:15 --> URI Class Initialized
INFO - 2023-07-01 05:30:15 --> Router Class Initialized
INFO - 2023-07-01 05:30:15 --> Output Class Initialized
INFO - 2023-07-01 05:30:15 --> Security Class Initialized
DEBUG - 2023-07-01 05:30:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-01 05:30:15 --> Input Class Initialized
INFO - 2023-07-01 05:30:15 --> Language Class Initialized
INFO - 2023-07-01 05:30:15 --> Loader Class Initialized
INFO - 2023-07-01 05:30:15 --> Helper loaded: url_helper
INFO - 2023-07-01 05:30:15 --> Helper loaded: file_helper
INFO - 2023-07-01 05:30:15 --> Helper loaded: html_helper
INFO - 2023-07-01 05:30:15 --> Helper loaded: text_helper
INFO - 2023-07-01 05:30:15 --> Helper loaded: form_helper
INFO - 2023-07-01 05:30:15 --> Helper loaded: lang_helper
INFO - 2023-07-01 05:30:15 --> Helper loaded: security_helper
INFO - 2023-07-01 05:30:15 --> Helper loaded: cookie_helper
INFO - 2023-07-01 05:30:15 --> Database Driver Class Initialized
INFO - 2023-07-01 05:30:15 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-01 05:30:15 --> Parser Class Initialized
INFO - 2023-07-01 05:30:15 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-01 05:30:15 --> Pagination Class Initialized
INFO - 2023-07-01 05:30:15 --> Form Validation Class Initialized
INFO - 2023-07-01 05:30:15 --> Controller Class Initialized
INFO - 2023-07-01 05:30:15 --> Model Class Initialized
DEBUG - 2023-07-01 05:30:15 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-01 05:30:15 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-01 05:30:15 --> Model Class Initialized
DEBUG - 2023-07-01 05:30:15 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-01 05:30:15 --> Model Class Initialized
INFO - 2023-07-01 05:30:15 --> Final output sent to browser
DEBUG - 2023-07-01 05:30:15 --> Total execution time: 0.0179
ERROR - 2023-07-01 05:30:18 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-01 05:30:18 --> Config Class Initialized
INFO - 2023-07-01 05:30:18 --> Hooks Class Initialized
DEBUG - 2023-07-01 05:30:18 --> UTF-8 Support Enabled
INFO - 2023-07-01 05:30:18 --> Utf8 Class Initialized
INFO - 2023-07-01 05:30:18 --> URI Class Initialized
INFO - 2023-07-01 05:30:18 --> Router Class Initialized
INFO - 2023-07-01 05:30:18 --> Output Class Initialized
INFO - 2023-07-01 05:30:18 --> Security Class Initialized
DEBUG - 2023-07-01 05:30:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-01 05:30:18 --> Input Class Initialized
INFO - 2023-07-01 05:30:18 --> Language Class Initialized
INFO - 2023-07-01 05:30:18 --> Loader Class Initialized
INFO - 2023-07-01 05:30:18 --> Helper loaded: url_helper
INFO - 2023-07-01 05:30:18 --> Helper loaded: file_helper
INFO - 2023-07-01 05:30:18 --> Helper loaded: html_helper
INFO - 2023-07-01 05:30:18 --> Helper loaded: text_helper
INFO - 2023-07-01 05:30:18 --> Helper loaded: form_helper
INFO - 2023-07-01 05:30:18 --> Helper loaded: lang_helper
INFO - 2023-07-01 05:30:18 --> Helper loaded: security_helper
INFO - 2023-07-01 05:30:18 --> Helper loaded: cookie_helper
INFO - 2023-07-01 05:30:18 --> Database Driver Class Initialized
INFO - 2023-07-01 05:30:18 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-01 05:30:18 --> Parser Class Initialized
INFO - 2023-07-01 05:30:18 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-01 05:30:18 --> Pagination Class Initialized
INFO - 2023-07-01 05:30:18 --> Form Validation Class Initialized
INFO - 2023-07-01 05:30:18 --> Controller Class Initialized
INFO - 2023-07-01 05:30:18 --> Model Class Initialized
DEBUG - 2023-07-01 05:30:18 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-01 05:30:18 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-01 05:30:18 --> Model Class Initialized
INFO - 2023-07-01 05:30:18 --> Final output sent to browser
DEBUG - 2023-07-01 05:30:18 --> Total execution time: 0.0166
ERROR - 2023-07-01 05:30:43 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-01 05:30:43 --> Config Class Initialized
INFO - 2023-07-01 05:30:43 --> Hooks Class Initialized
DEBUG - 2023-07-01 05:30:43 --> UTF-8 Support Enabled
INFO - 2023-07-01 05:30:43 --> Utf8 Class Initialized
INFO - 2023-07-01 05:30:43 --> URI Class Initialized
INFO - 2023-07-01 05:30:43 --> Router Class Initialized
INFO - 2023-07-01 05:30:43 --> Output Class Initialized
INFO - 2023-07-01 05:30:43 --> Security Class Initialized
DEBUG - 2023-07-01 05:30:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-01 05:30:43 --> Input Class Initialized
INFO - 2023-07-01 05:30:43 --> Language Class Initialized
INFO - 2023-07-01 05:30:43 --> Loader Class Initialized
INFO - 2023-07-01 05:30:43 --> Helper loaded: url_helper
INFO - 2023-07-01 05:30:43 --> Helper loaded: file_helper
INFO - 2023-07-01 05:30:43 --> Helper loaded: html_helper
INFO - 2023-07-01 05:30:43 --> Helper loaded: text_helper
INFO - 2023-07-01 05:30:43 --> Helper loaded: form_helper
INFO - 2023-07-01 05:30:43 --> Helper loaded: lang_helper
INFO - 2023-07-01 05:30:43 --> Helper loaded: security_helper
INFO - 2023-07-01 05:30:43 --> Helper loaded: cookie_helper
INFO - 2023-07-01 05:30:43 --> Database Driver Class Initialized
INFO - 2023-07-01 05:30:43 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-01 05:30:43 --> Parser Class Initialized
INFO - 2023-07-01 05:30:43 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-01 05:30:43 --> Pagination Class Initialized
INFO - 2023-07-01 05:30:43 --> Form Validation Class Initialized
INFO - 2023-07-01 05:30:43 --> Controller Class Initialized
INFO - 2023-07-01 05:30:43 --> Model Class Initialized
DEBUG - 2023-07-01 05:30:43 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-01 05:30:43 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-01 05:30:43 --> Model Class Initialized
INFO - 2023-07-01 05:30:43 --> Final output sent to browser
DEBUG - 2023-07-01 05:30:43 --> Total execution time: 0.0190
ERROR - 2023-07-01 05:30:45 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-01 05:30:45 --> Config Class Initialized
INFO - 2023-07-01 05:30:45 --> Hooks Class Initialized
DEBUG - 2023-07-01 05:30:45 --> UTF-8 Support Enabled
INFO - 2023-07-01 05:30:45 --> Utf8 Class Initialized
INFO - 2023-07-01 05:30:45 --> URI Class Initialized
INFO - 2023-07-01 05:30:45 --> Router Class Initialized
INFO - 2023-07-01 05:30:45 --> Output Class Initialized
INFO - 2023-07-01 05:30:45 --> Security Class Initialized
DEBUG - 2023-07-01 05:30:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-01 05:30:45 --> Input Class Initialized
INFO - 2023-07-01 05:30:45 --> Language Class Initialized
INFO - 2023-07-01 05:30:45 --> Loader Class Initialized
INFO - 2023-07-01 05:30:45 --> Helper loaded: url_helper
INFO - 2023-07-01 05:30:45 --> Helper loaded: file_helper
INFO - 2023-07-01 05:30:45 --> Helper loaded: html_helper
INFO - 2023-07-01 05:30:45 --> Helper loaded: text_helper
INFO - 2023-07-01 05:30:45 --> Helper loaded: form_helper
INFO - 2023-07-01 05:30:45 --> Helper loaded: lang_helper
INFO - 2023-07-01 05:30:45 --> Helper loaded: security_helper
INFO - 2023-07-01 05:30:45 --> Helper loaded: cookie_helper
INFO - 2023-07-01 05:30:45 --> Database Driver Class Initialized
INFO - 2023-07-01 05:30:45 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-01 05:30:45 --> Parser Class Initialized
INFO - 2023-07-01 05:30:45 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-01 05:30:45 --> Pagination Class Initialized
INFO - 2023-07-01 05:30:45 --> Form Validation Class Initialized
INFO - 2023-07-01 05:30:45 --> Controller Class Initialized
INFO - 2023-07-01 05:30:45 --> Model Class Initialized
DEBUG - 2023-07-01 05:30:45 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-01 05:30:45 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-01 05:30:45 --> Model Class Initialized
INFO - 2023-07-01 05:30:45 --> Final output sent to browser
DEBUG - 2023-07-01 05:30:45 --> Total execution time: 0.0156
ERROR - 2023-07-01 05:30:58 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-01 05:30:58 --> Config Class Initialized
INFO - 2023-07-01 05:30:58 --> Hooks Class Initialized
DEBUG - 2023-07-01 05:30:58 --> UTF-8 Support Enabled
INFO - 2023-07-01 05:30:58 --> Utf8 Class Initialized
INFO - 2023-07-01 05:30:58 --> URI Class Initialized
INFO - 2023-07-01 05:30:58 --> Router Class Initialized
INFO - 2023-07-01 05:30:58 --> Output Class Initialized
INFO - 2023-07-01 05:30:58 --> Security Class Initialized
DEBUG - 2023-07-01 05:30:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-01 05:30:58 --> Input Class Initialized
INFO - 2023-07-01 05:30:58 --> Language Class Initialized
INFO - 2023-07-01 05:30:58 --> Loader Class Initialized
INFO - 2023-07-01 05:30:58 --> Helper loaded: url_helper
INFO - 2023-07-01 05:30:58 --> Helper loaded: file_helper
INFO - 2023-07-01 05:30:58 --> Helper loaded: html_helper
INFO - 2023-07-01 05:30:58 --> Helper loaded: text_helper
INFO - 2023-07-01 05:30:58 --> Helper loaded: form_helper
INFO - 2023-07-01 05:30:58 --> Helper loaded: lang_helper
INFO - 2023-07-01 05:30:58 --> Helper loaded: security_helper
INFO - 2023-07-01 05:30:58 --> Helper loaded: cookie_helper
INFO - 2023-07-01 05:30:58 --> Database Driver Class Initialized
INFO - 2023-07-01 05:30:58 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-01 05:30:58 --> Parser Class Initialized
INFO - 2023-07-01 05:30:58 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-01 05:30:58 --> Pagination Class Initialized
INFO - 2023-07-01 05:30:58 --> Form Validation Class Initialized
INFO - 2023-07-01 05:30:58 --> Controller Class Initialized
INFO - 2023-07-01 05:30:58 --> Model Class Initialized
DEBUG - 2023-07-01 05:30:58 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-01 05:30:58 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-01 05:30:58 --> Model Class Initialized
DEBUG - 2023-07-01 05:30:58 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-01 05:30:58 --> Model Class Initialized
INFO - 2023-07-01 05:30:58 --> Final output sent to browser
DEBUG - 2023-07-01 05:30:58 --> Total execution time: 0.0216
ERROR - 2023-07-01 05:31:00 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-01 05:31:00 --> Config Class Initialized
INFO - 2023-07-01 05:31:00 --> Hooks Class Initialized
DEBUG - 2023-07-01 05:31:00 --> UTF-8 Support Enabled
INFO - 2023-07-01 05:31:00 --> Utf8 Class Initialized
INFO - 2023-07-01 05:31:00 --> URI Class Initialized
INFO - 2023-07-01 05:31:00 --> Router Class Initialized
INFO - 2023-07-01 05:31:00 --> Output Class Initialized
INFO - 2023-07-01 05:31:00 --> Security Class Initialized
DEBUG - 2023-07-01 05:31:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-01 05:31:00 --> Input Class Initialized
INFO - 2023-07-01 05:31:00 --> Language Class Initialized
INFO - 2023-07-01 05:31:00 --> Loader Class Initialized
INFO - 2023-07-01 05:31:00 --> Helper loaded: url_helper
INFO - 2023-07-01 05:31:00 --> Helper loaded: file_helper
INFO - 2023-07-01 05:31:00 --> Helper loaded: html_helper
INFO - 2023-07-01 05:31:00 --> Helper loaded: text_helper
INFO - 2023-07-01 05:31:00 --> Helper loaded: form_helper
INFO - 2023-07-01 05:31:00 --> Helper loaded: lang_helper
INFO - 2023-07-01 05:31:00 --> Helper loaded: security_helper
INFO - 2023-07-01 05:31:00 --> Helper loaded: cookie_helper
INFO - 2023-07-01 05:31:00 --> Database Driver Class Initialized
INFO - 2023-07-01 05:31:00 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-01 05:31:00 --> Parser Class Initialized
INFO - 2023-07-01 05:31:00 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-01 05:31:00 --> Pagination Class Initialized
INFO - 2023-07-01 05:31:00 --> Form Validation Class Initialized
INFO - 2023-07-01 05:31:00 --> Controller Class Initialized
INFO - 2023-07-01 05:31:00 --> Model Class Initialized
DEBUG - 2023-07-01 05:31:00 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-01 05:31:00 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-01 05:31:00 --> Model Class Initialized
DEBUG - 2023-07-01 05:31:00 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-01 05:31:00 --> Model Class Initialized
INFO - 2023-07-01 05:31:00 --> Final output sent to browser
DEBUG - 2023-07-01 05:31:00 --> Total execution time: 0.0213
ERROR - 2023-07-01 05:31:00 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-01 05:31:00 --> Config Class Initialized
INFO - 2023-07-01 05:31:00 --> Hooks Class Initialized
DEBUG - 2023-07-01 05:31:00 --> UTF-8 Support Enabled
INFO - 2023-07-01 05:31:00 --> Utf8 Class Initialized
INFO - 2023-07-01 05:31:00 --> URI Class Initialized
INFO - 2023-07-01 05:31:00 --> Router Class Initialized
INFO - 2023-07-01 05:31:00 --> Output Class Initialized
INFO - 2023-07-01 05:31:00 --> Security Class Initialized
DEBUG - 2023-07-01 05:31:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-01 05:31:00 --> Input Class Initialized
INFO - 2023-07-01 05:31:00 --> Language Class Initialized
INFO - 2023-07-01 05:31:00 --> Loader Class Initialized
INFO - 2023-07-01 05:31:00 --> Helper loaded: url_helper
INFO - 2023-07-01 05:31:00 --> Helper loaded: file_helper
INFO - 2023-07-01 05:31:00 --> Helper loaded: html_helper
INFO - 2023-07-01 05:31:00 --> Helper loaded: text_helper
INFO - 2023-07-01 05:31:00 --> Helper loaded: form_helper
INFO - 2023-07-01 05:31:00 --> Helper loaded: lang_helper
INFO - 2023-07-01 05:31:00 --> Helper loaded: security_helper
INFO - 2023-07-01 05:31:00 --> Helper loaded: cookie_helper
INFO - 2023-07-01 05:31:00 --> Database Driver Class Initialized
INFO - 2023-07-01 05:31:00 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-01 05:31:00 --> Parser Class Initialized
INFO - 2023-07-01 05:31:00 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-01 05:31:00 --> Pagination Class Initialized
INFO - 2023-07-01 05:31:00 --> Form Validation Class Initialized
INFO - 2023-07-01 05:31:00 --> Controller Class Initialized
INFO - 2023-07-01 05:31:00 --> Model Class Initialized
DEBUG - 2023-07-01 05:31:00 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-01 05:31:00 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-01 05:31:00 --> Model Class Initialized
DEBUG - 2023-07-01 05:31:00 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-01 05:31:00 --> Model Class Initialized
INFO - 2023-07-01 05:31:00 --> Final output sent to browser
DEBUG - 2023-07-01 05:31:00 --> Total execution time: 0.0473
ERROR - 2023-07-01 05:31:01 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-01 05:31:01 --> Config Class Initialized
INFO - 2023-07-01 05:31:01 --> Hooks Class Initialized
DEBUG - 2023-07-01 05:31:01 --> UTF-8 Support Enabled
INFO - 2023-07-01 05:31:01 --> Utf8 Class Initialized
INFO - 2023-07-01 05:31:01 --> URI Class Initialized
INFO - 2023-07-01 05:31:01 --> Router Class Initialized
INFO - 2023-07-01 05:31:01 --> Output Class Initialized
INFO - 2023-07-01 05:31:01 --> Security Class Initialized
DEBUG - 2023-07-01 05:31:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-01 05:31:01 --> Input Class Initialized
INFO - 2023-07-01 05:31:01 --> Language Class Initialized
INFO - 2023-07-01 05:31:01 --> Loader Class Initialized
INFO - 2023-07-01 05:31:01 --> Helper loaded: url_helper
INFO - 2023-07-01 05:31:01 --> Helper loaded: file_helper
INFO - 2023-07-01 05:31:01 --> Helper loaded: html_helper
INFO - 2023-07-01 05:31:01 --> Helper loaded: text_helper
INFO - 2023-07-01 05:31:01 --> Helper loaded: form_helper
INFO - 2023-07-01 05:31:01 --> Helper loaded: lang_helper
INFO - 2023-07-01 05:31:01 --> Helper loaded: security_helper
INFO - 2023-07-01 05:31:01 --> Helper loaded: cookie_helper
INFO - 2023-07-01 05:31:01 --> Database Driver Class Initialized
INFO - 2023-07-01 05:31:01 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-01 05:31:01 --> Parser Class Initialized
INFO - 2023-07-01 05:31:01 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-01 05:31:01 --> Pagination Class Initialized
INFO - 2023-07-01 05:31:01 --> Form Validation Class Initialized
INFO - 2023-07-01 05:31:01 --> Controller Class Initialized
INFO - 2023-07-01 05:31:01 --> Model Class Initialized
DEBUG - 2023-07-01 05:31:01 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-01 05:31:01 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-01 05:31:01 --> Model Class Initialized
DEBUG - 2023-07-01 05:31:01 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-01 05:31:01 --> Model Class Initialized
INFO - 2023-07-01 05:31:01 --> Final output sent to browser
DEBUG - 2023-07-01 05:31:01 --> Total execution time: 0.0471
ERROR - 2023-07-01 05:31:01 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-01 05:31:01 --> Config Class Initialized
INFO - 2023-07-01 05:31:01 --> Hooks Class Initialized
DEBUG - 2023-07-01 05:31:01 --> UTF-8 Support Enabled
INFO - 2023-07-01 05:31:01 --> Utf8 Class Initialized
INFO - 2023-07-01 05:31:01 --> URI Class Initialized
INFO - 2023-07-01 05:31:01 --> Router Class Initialized
INFO - 2023-07-01 05:31:01 --> Output Class Initialized
INFO - 2023-07-01 05:31:01 --> Security Class Initialized
DEBUG - 2023-07-01 05:31:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-01 05:31:01 --> Input Class Initialized
INFO - 2023-07-01 05:31:01 --> Language Class Initialized
INFO - 2023-07-01 05:31:01 --> Loader Class Initialized
INFO - 2023-07-01 05:31:01 --> Helper loaded: url_helper
INFO - 2023-07-01 05:31:01 --> Helper loaded: file_helper
INFO - 2023-07-01 05:31:01 --> Helper loaded: html_helper
INFO - 2023-07-01 05:31:01 --> Helper loaded: text_helper
INFO - 2023-07-01 05:31:01 --> Helper loaded: form_helper
INFO - 2023-07-01 05:31:01 --> Helper loaded: lang_helper
INFO - 2023-07-01 05:31:01 --> Helper loaded: security_helper
INFO - 2023-07-01 05:31:01 --> Helper loaded: cookie_helper
INFO - 2023-07-01 05:31:01 --> Database Driver Class Initialized
INFO - 2023-07-01 05:31:01 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-01 05:31:01 --> Parser Class Initialized
INFO - 2023-07-01 05:31:01 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-01 05:31:01 --> Pagination Class Initialized
INFO - 2023-07-01 05:31:01 --> Form Validation Class Initialized
INFO - 2023-07-01 05:31:01 --> Controller Class Initialized
INFO - 2023-07-01 05:31:01 --> Model Class Initialized
DEBUG - 2023-07-01 05:31:01 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-01 05:31:01 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-01 05:31:01 --> Model Class Initialized
DEBUG - 2023-07-01 05:31:01 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-01 05:31:01 --> Model Class Initialized
INFO - 2023-07-01 05:31:01 --> Final output sent to browser
DEBUG - 2023-07-01 05:31:01 --> Total execution time: 0.0492
ERROR - 2023-07-01 05:31:03 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-01 05:31:03 --> Config Class Initialized
INFO - 2023-07-01 05:31:03 --> Hooks Class Initialized
DEBUG - 2023-07-01 05:31:03 --> UTF-8 Support Enabled
INFO - 2023-07-01 05:31:03 --> Utf8 Class Initialized
INFO - 2023-07-01 05:31:03 --> URI Class Initialized
INFO - 2023-07-01 05:31:03 --> Router Class Initialized
INFO - 2023-07-01 05:31:03 --> Output Class Initialized
INFO - 2023-07-01 05:31:03 --> Security Class Initialized
DEBUG - 2023-07-01 05:31:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-01 05:31:03 --> Input Class Initialized
INFO - 2023-07-01 05:31:03 --> Language Class Initialized
INFO - 2023-07-01 05:31:03 --> Loader Class Initialized
INFO - 2023-07-01 05:31:03 --> Helper loaded: url_helper
INFO - 2023-07-01 05:31:03 --> Helper loaded: file_helper
INFO - 2023-07-01 05:31:03 --> Helper loaded: html_helper
INFO - 2023-07-01 05:31:03 --> Helper loaded: text_helper
INFO - 2023-07-01 05:31:03 --> Helper loaded: form_helper
INFO - 2023-07-01 05:31:03 --> Helper loaded: lang_helper
INFO - 2023-07-01 05:31:03 --> Helper loaded: security_helper
INFO - 2023-07-01 05:31:03 --> Helper loaded: cookie_helper
INFO - 2023-07-01 05:31:03 --> Database Driver Class Initialized
INFO - 2023-07-01 05:31:03 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-01 05:31:03 --> Parser Class Initialized
INFO - 2023-07-01 05:31:03 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-01 05:31:03 --> Pagination Class Initialized
INFO - 2023-07-01 05:31:03 --> Form Validation Class Initialized
INFO - 2023-07-01 05:31:03 --> Controller Class Initialized
INFO - 2023-07-01 05:31:03 --> Model Class Initialized
DEBUG - 2023-07-01 05:31:03 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-01 05:31:03 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-01 05:31:03 --> Model Class Initialized
DEBUG - 2023-07-01 05:31:03 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-01 05:31:03 --> Model Class Initialized
INFO - 2023-07-01 05:31:03 --> Final output sent to browser
DEBUG - 2023-07-01 05:31:03 --> Total execution time: 0.0471
ERROR - 2023-07-01 05:31:04 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-01 05:31:04 --> Config Class Initialized
INFO - 2023-07-01 05:31:04 --> Hooks Class Initialized
DEBUG - 2023-07-01 05:31:04 --> UTF-8 Support Enabled
INFO - 2023-07-01 05:31:04 --> Utf8 Class Initialized
INFO - 2023-07-01 05:31:04 --> URI Class Initialized
INFO - 2023-07-01 05:31:04 --> Router Class Initialized
INFO - 2023-07-01 05:31:04 --> Output Class Initialized
INFO - 2023-07-01 05:31:04 --> Security Class Initialized
DEBUG - 2023-07-01 05:31:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-01 05:31:04 --> Input Class Initialized
INFO - 2023-07-01 05:31:04 --> Language Class Initialized
INFO - 2023-07-01 05:31:04 --> Loader Class Initialized
INFO - 2023-07-01 05:31:04 --> Helper loaded: url_helper
INFO - 2023-07-01 05:31:04 --> Helper loaded: file_helper
INFO - 2023-07-01 05:31:04 --> Helper loaded: html_helper
INFO - 2023-07-01 05:31:04 --> Helper loaded: text_helper
INFO - 2023-07-01 05:31:04 --> Helper loaded: form_helper
INFO - 2023-07-01 05:31:04 --> Helper loaded: lang_helper
INFO - 2023-07-01 05:31:04 --> Helper loaded: security_helper
INFO - 2023-07-01 05:31:04 --> Helper loaded: cookie_helper
INFO - 2023-07-01 05:31:04 --> Database Driver Class Initialized
INFO - 2023-07-01 05:31:04 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-01 05:31:04 --> Parser Class Initialized
INFO - 2023-07-01 05:31:04 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-01 05:31:04 --> Pagination Class Initialized
INFO - 2023-07-01 05:31:04 --> Form Validation Class Initialized
INFO - 2023-07-01 05:31:04 --> Controller Class Initialized
INFO - 2023-07-01 05:31:04 --> Model Class Initialized
DEBUG - 2023-07-01 05:31:04 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-01 05:31:04 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-01 05:31:04 --> Model Class Initialized
DEBUG - 2023-07-01 05:31:04 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-01 05:31:04 --> Model Class Initialized
INFO - 2023-07-01 05:31:04 --> Final output sent to browser
DEBUG - 2023-07-01 05:31:04 --> Total execution time: 0.0473
ERROR - 2023-07-01 05:31:05 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-01 05:31:05 --> Config Class Initialized
INFO - 2023-07-01 05:31:05 --> Hooks Class Initialized
DEBUG - 2023-07-01 05:31:05 --> UTF-8 Support Enabled
INFO - 2023-07-01 05:31:05 --> Utf8 Class Initialized
INFO - 2023-07-01 05:31:05 --> URI Class Initialized
INFO - 2023-07-01 05:31:05 --> Router Class Initialized
INFO - 2023-07-01 05:31:05 --> Output Class Initialized
INFO - 2023-07-01 05:31:05 --> Security Class Initialized
DEBUG - 2023-07-01 05:31:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-01 05:31:05 --> Input Class Initialized
INFO - 2023-07-01 05:31:05 --> Language Class Initialized
INFO - 2023-07-01 05:31:05 --> Loader Class Initialized
INFO - 2023-07-01 05:31:05 --> Helper loaded: url_helper
INFO - 2023-07-01 05:31:05 --> Helper loaded: file_helper
INFO - 2023-07-01 05:31:05 --> Helper loaded: html_helper
INFO - 2023-07-01 05:31:05 --> Helper loaded: text_helper
INFO - 2023-07-01 05:31:05 --> Helper loaded: form_helper
INFO - 2023-07-01 05:31:05 --> Helper loaded: lang_helper
INFO - 2023-07-01 05:31:05 --> Helper loaded: security_helper
INFO - 2023-07-01 05:31:05 --> Helper loaded: cookie_helper
INFO - 2023-07-01 05:31:05 --> Database Driver Class Initialized
INFO - 2023-07-01 05:31:05 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-01 05:31:05 --> Parser Class Initialized
INFO - 2023-07-01 05:31:05 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-01 05:31:05 --> Pagination Class Initialized
INFO - 2023-07-01 05:31:05 --> Form Validation Class Initialized
INFO - 2023-07-01 05:31:05 --> Controller Class Initialized
INFO - 2023-07-01 05:31:05 --> Model Class Initialized
DEBUG - 2023-07-01 05:31:05 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-01 05:31:05 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-01 05:31:05 --> Model Class Initialized
DEBUG - 2023-07-01 05:31:05 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-01 05:31:05 --> Model Class Initialized
INFO - 2023-07-01 05:31:05 --> Final output sent to browser
DEBUG - 2023-07-01 05:31:05 --> Total execution time: 0.0248
ERROR - 2023-07-01 05:31:07 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-01 05:31:07 --> Config Class Initialized
INFO - 2023-07-01 05:31:07 --> Hooks Class Initialized
DEBUG - 2023-07-01 05:31:07 --> UTF-8 Support Enabled
INFO - 2023-07-01 05:31:07 --> Utf8 Class Initialized
INFO - 2023-07-01 05:31:07 --> URI Class Initialized
INFO - 2023-07-01 05:31:07 --> Router Class Initialized
INFO - 2023-07-01 05:31:07 --> Output Class Initialized
INFO - 2023-07-01 05:31:07 --> Security Class Initialized
DEBUG - 2023-07-01 05:31:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-01 05:31:07 --> Input Class Initialized
INFO - 2023-07-01 05:31:07 --> Language Class Initialized
INFO - 2023-07-01 05:31:07 --> Loader Class Initialized
INFO - 2023-07-01 05:31:07 --> Helper loaded: url_helper
INFO - 2023-07-01 05:31:07 --> Helper loaded: file_helper
INFO - 2023-07-01 05:31:07 --> Helper loaded: html_helper
INFO - 2023-07-01 05:31:07 --> Helper loaded: text_helper
INFO - 2023-07-01 05:31:07 --> Helper loaded: form_helper
INFO - 2023-07-01 05:31:07 --> Helper loaded: lang_helper
INFO - 2023-07-01 05:31:07 --> Helper loaded: security_helper
INFO - 2023-07-01 05:31:07 --> Helper loaded: cookie_helper
INFO - 2023-07-01 05:31:07 --> Database Driver Class Initialized
INFO - 2023-07-01 05:31:07 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-01 05:31:07 --> Parser Class Initialized
INFO - 2023-07-01 05:31:07 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-01 05:31:07 --> Pagination Class Initialized
INFO - 2023-07-01 05:31:07 --> Form Validation Class Initialized
INFO - 2023-07-01 05:31:07 --> Controller Class Initialized
INFO - 2023-07-01 05:31:07 --> Model Class Initialized
DEBUG - 2023-07-01 05:31:07 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-01 05:31:07 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-01 05:31:07 --> Model Class Initialized
INFO - 2023-07-01 05:31:07 --> Model Class Initialized
INFO - 2023-07-01 05:31:07 --> Final output sent to browser
DEBUG - 2023-07-01 05:31:07 --> Total execution time: 0.0193
ERROR - 2023-07-01 05:31:10 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-01 05:31:10 --> Config Class Initialized
INFO - 2023-07-01 05:31:10 --> Hooks Class Initialized
DEBUG - 2023-07-01 05:31:10 --> UTF-8 Support Enabled
INFO - 2023-07-01 05:31:10 --> Utf8 Class Initialized
INFO - 2023-07-01 05:31:10 --> URI Class Initialized
INFO - 2023-07-01 05:31:10 --> Router Class Initialized
INFO - 2023-07-01 05:31:10 --> Output Class Initialized
INFO - 2023-07-01 05:31:10 --> Security Class Initialized
DEBUG - 2023-07-01 05:31:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-01 05:31:10 --> Input Class Initialized
INFO - 2023-07-01 05:31:10 --> Language Class Initialized
INFO - 2023-07-01 05:31:10 --> Loader Class Initialized
INFO - 2023-07-01 05:31:10 --> Helper loaded: url_helper
INFO - 2023-07-01 05:31:10 --> Helper loaded: file_helper
INFO - 2023-07-01 05:31:10 --> Helper loaded: html_helper
INFO - 2023-07-01 05:31:10 --> Helper loaded: text_helper
INFO - 2023-07-01 05:31:10 --> Helper loaded: form_helper
INFO - 2023-07-01 05:31:10 --> Helper loaded: lang_helper
INFO - 2023-07-01 05:31:10 --> Helper loaded: security_helper
INFO - 2023-07-01 05:31:10 --> Helper loaded: cookie_helper
INFO - 2023-07-01 05:31:10 --> Database Driver Class Initialized
INFO - 2023-07-01 05:31:10 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-01 05:31:10 --> Parser Class Initialized
INFO - 2023-07-01 05:31:10 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-01 05:31:10 --> Pagination Class Initialized
INFO - 2023-07-01 05:31:10 --> Form Validation Class Initialized
INFO - 2023-07-01 05:31:10 --> Controller Class Initialized
INFO - 2023-07-01 05:31:10 --> Model Class Initialized
DEBUG - 2023-07-01 05:31:10 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-01 05:31:10 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-01 05:31:10 --> Model Class Initialized
INFO - 2023-07-01 05:31:10 --> Final output sent to browser
DEBUG - 2023-07-01 05:31:10 --> Total execution time: 0.0164
ERROR - 2023-07-01 05:31:25 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-01 05:31:25 --> Config Class Initialized
INFO - 2023-07-01 05:31:25 --> Hooks Class Initialized
DEBUG - 2023-07-01 05:31:25 --> UTF-8 Support Enabled
INFO - 2023-07-01 05:31:25 --> Utf8 Class Initialized
INFO - 2023-07-01 05:31:25 --> URI Class Initialized
INFO - 2023-07-01 05:31:25 --> Router Class Initialized
INFO - 2023-07-01 05:31:25 --> Output Class Initialized
INFO - 2023-07-01 05:31:25 --> Security Class Initialized
DEBUG - 2023-07-01 05:31:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-01 05:31:25 --> Input Class Initialized
INFO - 2023-07-01 05:31:25 --> Language Class Initialized
INFO - 2023-07-01 05:31:25 --> Loader Class Initialized
INFO - 2023-07-01 05:31:25 --> Helper loaded: url_helper
INFO - 2023-07-01 05:31:25 --> Helper loaded: file_helper
INFO - 2023-07-01 05:31:25 --> Helper loaded: html_helper
INFO - 2023-07-01 05:31:25 --> Helper loaded: text_helper
INFO - 2023-07-01 05:31:25 --> Helper loaded: form_helper
INFO - 2023-07-01 05:31:25 --> Helper loaded: lang_helper
INFO - 2023-07-01 05:31:25 --> Helper loaded: security_helper
INFO - 2023-07-01 05:31:25 --> Helper loaded: cookie_helper
INFO - 2023-07-01 05:31:25 --> Database Driver Class Initialized
INFO - 2023-07-01 05:31:25 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-01 05:31:25 --> Parser Class Initialized
INFO - 2023-07-01 05:31:25 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-01 05:31:25 --> Pagination Class Initialized
INFO - 2023-07-01 05:31:25 --> Form Validation Class Initialized
INFO - 2023-07-01 05:31:25 --> Controller Class Initialized
INFO - 2023-07-01 05:31:25 --> Model Class Initialized
DEBUG - 2023-07-01 05:31:25 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-01 05:31:25 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-01 05:31:25 --> Model Class Initialized
DEBUG - 2023-07-01 05:31:25 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-01 05:31:25 --> Model Class Initialized
INFO - 2023-07-01 05:31:25 --> Final output sent to browser
DEBUG - 2023-07-01 05:31:25 --> Total execution time: 0.0218
ERROR - 2023-07-01 05:31:25 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-01 05:31:25 --> Config Class Initialized
INFO - 2023-07-01 05:31:25 --> Hooks Class Initialized
DEBUG - 2023-07-01 05:31:25 --> UTF-8 Support Enabled
INFO - 2023-07-01 05:31:25 --> Utf8 Class Initialized
INFO - 2023-07-01 05:31:25 --> URI Class Initialized
INFO - 2023-07-01 05:31:25 --> Router Class Initialized
INFO - 2023-07-01 05:31:25 --> Output Class Initialized
INFO - 2023-07-01 05:31:25 --> Security Class Initialized
DEBUG - 2023-07-01 05:31:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-01 05:31:25 --> Input Class Initialized
INFO - 2023-07-01 05:31:25 --> Language Class Initialized
INFO - 2023-07-01 05:31:25 --> Loader Class Initialized
INFO - 2023-07-01 05:31:25 --> Helper loaded: url_helper
INFO - 2023-07-01 05:31:25 --> Helper loaded: file_helper
INFO - 2023-07-01 05:31:25 --> Helper loaded: html_helper
INFO - 2023-07-01 05:31:25 --> Helper loaded: text_helper
INFO - 2023-07-01 05:31:25 --> Helper loaded: form_helper
INFO - 2023-07-01 05:31:25 --> Helper loaded: lang_helper
INFO - 2023-07-01 05:31:25 --> Helper loaded: security_helper
INFO - 2023-07-01 05:31:25 --> Helper loaded: cookie_helper
INFO - 2023-07-01 05:31:25 --> Database Driver Class Initialized
INFO - 2023-07-01 05:31:25 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-01 05:31:25 --> Parser Class Initialized
INFO - 2023-07-01 05:31:25 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-01 05:31:25 --> Pagination Class Initialized
INFO - 2023-07-01 05:31:25 --> Form Validation Class Initialized
INFO - 2023-07-01 05:31:25 --> Controller Class Initialized
INFO - 2023-07-01 05:31:25 --> Model Class Initialized
DEBUG - 2023-07-01 05:31:25 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-01 05:31:25 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-01 05:31:25 --> Model Class Initialized
DEBUG - 2023-07-01 05:31:25 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-01 05:31:25 --> Model Class Initialized
INFO - 2023-07-01 05:31:25 --> Final output sent to browser
DEBUG - 2023-07-01 05:31:25 --> Total execution time: 0.0175
ERROR - 2023-07-01 05:31:26 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-01 05:31:26 --> Config Class Initialized
INFO - 2023-07-01 05:31:26 --> Hooks Class Initialized
DEBUG - 2023-07-01 05:31:26 --> UTF-8 Support Enabled
INFO - 2023-07-01 05:31:26 --> Utf8 Class Initialized
INFO - 2023-07-01 05:31:26 --> URI Class Initialized
INFO - 2023-07-01 05:31:26 --> Router Class Initialized
INFO - 2023-07-01 05:31:26 --> Output Class Initialized
INFO - 2023-07-01 05:31:26 --> Security Class Initialized
DEBUG - 2023-07-01 05:31:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-01 05:31:26 --> Input Class Initialized
INFO - 2023-07-01 05:31:26 --> Language Class Initialized
INFO - 2023-07-01 05:31:26 --> Loader Class Initialized
INFO - 2023-07-01 05:31:26 --> Helper loaded: url_helper
INFO - 2023-07-01 05:31:26 --> Helper loaded: file_helper
INFO - 2023-07-01 05:31:26 --> Helper loaded: html_helper
INFO - 2023-07-01 05:31:26 --> Helper loaded: text_helper
INFO - 2023-07-01 05:31:26 --> Helper loaded: form_helper
INFO - 2023-07-01 05:31:26 --> Helper loaded: lang_helper
INFO - 2023-07-01 05:31:26 --> Helper loaded: security_helper
INFO - 2023-07-01 05:31:26 --> Helper loaded: cookie_helper
INFO - 2023-07-01 05:31:26 --> Database Driver Class Initialized
INFO - 2023-07-01 05:31:26 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-01 05:31:26 --> Parser Class Initialized
INFO - 2023-07-01 05:31:26 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-01 05:31:26 --> Pagination Class Initialized
INFO - 2023-07-01 05:31:26 --> Form Validation Class Initialized
INFO - 2023-07-01 05:31:26 --> Controller Class Initialized
INFO - 2023-07-01 05:31:26 --> Model Class Initialized
DEBUG - 2023-07-01 05:31:26 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-01 05:31:26 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-01 05:31:26 --> Model Class Initialized
INFO - 2023-07-01 05:31:26 --> Model Class Initialized
INFO - 2023-07-01 05:31:26 --> Final output sent to browser
DEBUG - 2023-07-01 05:31:26 --> Total execution time: 0.0170
ERROR - 2023-07-01 05:31:29 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-01 05:31:29 --> Config Class Initialized
INFO - 2023-07-01 05:31:29 --> Hooks Class Initialized
DEBUG - 2023-07-01 05:31:29 --> UTF-8 Support Enabled
INFO - 2023-07-01 05:31:29 --> Utf8 Class Initialized
INFO - 2023-07-01 05:31:29 --> URI Class Initialized
INFO - 2023-07-01 05:31:29 --> Router Class Initialized
INFO - 2023-07-01 05:31:29 --> Output Class Initialized
INFO - 2023-07-01 05:31:29 --> Security Class Initialized
DEBUG - 2023-07-01 05:31:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-01 05:31:29 --> Input Class Initialized
INFO - 2023-07-01 05:31:29 --> Language Class Initialized
INFO - 2023-07-01 05:31:29 --> Loader Class Initialized
INFO - 2023-07-01 05:31:29 --> Helper loaded: url_helper
INFO - 2023-07-01 05:31:29 --> Helper loaded: file_helper
INFO - 2023-07-01 05:31:29 --> Helper loaded: html_helper
INFO - 2023-07-01 05:31:29 --> Helper loaded: text_helper
INFO - 2023-07-01 05:31:29 --> Helper loaded: form_helper
INFO - 2023-07-01 05:31:29 --> Helper loaded: lang_helper
INFO - 2023-07-01 05:31:29 --> Helper loaded: security_helper
INFO - 2023-07-01 05:31:29 --> Helper loaded: cookie_helper
INFO - 2023-07-01 05:31:29 --> Database Driver Class Initialized
INFO - 2023-07-01 05:31:29 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-01 05:31:29 --> Parser Class Initialized
INFO - 2023-07-01 05:31:29 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-01 05:31:29 --> Pagination Class Initialized
INFO - 2023-07-01 05:31:29 --> Form Validation Class Initialized
INFO - 2023-07-01 05:31:29 --> Controller Class Initialized
INFO - 2023-07-01 05:31:29 --> Model Class Initialized
DEBUG - 2023-07-01 05:31:29 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-01 05:31:29 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-01 05:31:30 --> Model Class Initialized
DEBUG - 2023-07-01 05:31:30 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-01 05:31:30 --> Model Class Initialized
INFO - 2023-07-01 05:31:30 --> Final output sent to browser
DEBUG - 2023-07-01 05:31:30 --> Total execution time: 0.0170
ERROR - 2023-07-01 05:31:31 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-01 05:31:31 --> Config Class Initialized
INFO - 2023-07-01 05:31:31 --> Hooks Class Initialized
DEBUG - 2023-07-01 05:31:31 --> UTF-8 Support Enabled
INFO - 2023-07-01 05:31:31 --> Utf8 Class Initialized
INFO - 2023-07-01 05:31:31 --> URI Class Initialized
INFO - 2023-07-01 05:31:31 --> Router Class Initialized
INFO - 2023-07-01 05:31:31 --> Output Class Initialized
INFO - 2023-07-01 05:31:31 --> Security Class Initialized
DEBUG - 2023-07-01 05:31:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-01 05:31:31 --> Input Class Initialized
INFO - 2023-07-01 05:31:31 --> Language Class Initialized
INFO - 2023-07-01 05:31:31 --> Loader Class Initialized
INFO - 2023-07-01 05:31:31 --> Helper loaded: url_helper
INFO - 2023-07-01 05:31:31 --> Helper loaded: file_helper
INFO - 2023-07-01 05:31:31 --> Helper loaded: html_helper
INFO - 2023-07-01 05:31:31 --> Helper loaded: text_helper
INFO - 2023-07-01 05:31:31 --> Helper loaded: form_helper
INFO - 2023-07-01 05:31:31 --> Helper loaded: lang_helper
INFO - 2023-07-01 05:31:31 --> Helper loaded: security_helper
INFO - 2023-07-01 05:31:31 --> Helper loaded: cookie_helper
INFO - 2023-07-01 05:31:31 --> Database Driver Class Initialized
INFO - 2023-07-01 05:31:31 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-01 05:31:31 --> Parser Class Initialized
INFO - 2023-07-01 05:31:31 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-01 05:31:31 --> Pagination Class Initialized
INFO - 2023-07-01 05:31:31 --> Form Validation Class Initialized
INFO - 2023-07-01 05:31:31 --> Controller Class Initialized
INFO - 2023-07-01 05:31:31 --> Model Class Initialized
DEBUG - 2023-07-01 05:31:31 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-01 05:31:31 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-01 05:31:31 --> Model Class Initialized
DEBUG - 2023-07-01 05:31:31 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-01 05:31:31 --> Model Class Initialized
INFO - 2023-07-01 05:31:31 --> Final output sent to browser
DEBUG - 2023-07-01 05:31:31 --> Total execution time: 0.0183
ERROR - 2023-07-01 05:31:32 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-01 05:31:32 --> Config Class Initialized
INFO - 2023-07-01 05:31:32 --> Hooks Class Initialized
DEBUG - 2023-07-01 05:31:32 --> UTF-8 Support Enabled
INFO - 2023-07-01 05:31:32 --> Utf8 Class Initialized
INFO - 2023-07-01 05:31:32 --> URI Class Initialized
DEBUG - 2023-07-01 05:31:32 --> No URI present. Default controller set.
INFO - 2023-07-01 05:31:32 --> Router Class Initialized
INFO - 2023-07-01 05:31:32 --> Output Class Initialized
INFO - 2023-07-01 05:31:32 --> Security Class Initialized
DEBUG - 2023-07-01 05:31:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-01 05:31:32 --> Input Class Initialized
INFO - 2023-07-01 05:31:32 --> Language Class Initialized
INFO - 2023-07-01 05:31:32 --> Loader Class Initialized
INFO - 2023-07-01 05:31:32 --> Helper loaded: url_helper
INFO - 2023-07-01 05:31:32 --> Helper loaded: file_helper
INFO - 2023-07-01 05:31:32 --> Helper loaded: html_helper
INFO - 2023-07-01 05:31:32 --> Helper loaded: text_helper
INFO - 2023-07-01 05:31:32 --> Helper loaded: form_helper
INFO - 2023-07-01 05:31:32 --> Helper loaded: lang_helper
INFO - 2023-07-01 05:31:32 --> Helper loaded: security_helper
INFO - 2023-07-01 05:31:32 --> Helper loaded: cookie_helper
INFO - 2023-07-01 05:31:32 --> Database Driver Class Initialized
INFO - 2023-07-01 05:31:32 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-01 05:31:32 --> Parser Class Initialized
INFO - 2023-07-01 05:31:32 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-01 05:31:32 --> Pagination Class Initialized
INFO - 2023-07-01 05:31:32 --> Form Validation Class Initialized
INFO - 2023-07-01 05:31:32 --> Controller Class Initialized
INFO - 2023-07-01 05:31:32 --> Model Class Initialized
DEBUG - 2023-07-01 05:31:32 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-01 05:31:32 --> Model Class Initialized
DEBUG - 2023-07-01 05:31:32 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-01 05:31:32 --> Model Class Initialized
INFO - 2023-07-01 05:31:32 --> Model Class Initialized
INFO - 2023-07-01 05:31:32 --> Model Class Initialized
INFO - 2023-07-01 05:31:32 --> Model Class Initialized
DEBUG - 2023-07-01 05:31:32 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-01 05:31:32 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-01 05:31:32 --> Model Class Initialized
INFO - 2023-07-01 05:31:32 --> Model Class Initialized
INFO - 2023-07-01 05:31:32 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-07-01 05:31:32 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-07-01 05:31:32 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-07-01 05:31:32 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-07-01 05:31:32 --> Model Class Initialized
INFO - 2023-07-01 05:31:32 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-07-01 05:31:32 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-07-01 05:31:32 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-07-01 05:31:32 --> Final output sent to browser
DEBUG - 2023-07-01 05:31:32 --> Total execution time: 0.0799
ERROR - 2023-07-01 05:31:32 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-01 05:31:32 --> Config Class Initialized
INFO - 2023-07-01 05:31:32 --> Hooks Class Initialized
DEBUG - 2023-07-01 05:31:32 --> UTF-8 Support Enabled
INFO - 2023-07-01 05:31:32 --> Utf8 Class Initialized
INFO - 2023-07-01 05:31:32 --> URI Class Initialized
INFO - 2023-07-01 05:31:32 --> Router Class Initialized
INFO - 2023-07-01 05:31:32 --> Output Class Initialized
INFO - 2023-07-01 05:31:32 --> Security Class Initialized
DEBUG - 2023-07-01 05:31:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-01 05:31:32 --> Input Class Initialized
INFO - 2023-07-01 05:31:32 --> Language Class Initialized
INFO - 2023-07-01 05:31:32 --> Loader Class Initialized
INFO - 2023-07-01 05:31:32 --> Helper loaded: url_helper
INFO - 2023-07-01 05:31:32 --> Helper loaded: file_helper
INFO - 2023-07-01 05:31:32 --> Helper loaded: html_helper
INFO - 2023-07-01 05:31:32 --> Helper loaded: text_helper
INFO - 2023-07-01 05:31:32 --> Helper loaded: form_helper
INFO - 2023-07-01 05:31:32 --> Helper loaded: lang_helper
INFO - 2023-07-01 05:31:32 --> Helper loaded: security_helper
INFO - 2023-07-01 05:31:32 --> Helper loaded: cookie_helper
INFO - 2023-07-01 05:31:32 --> Database Driver Class Initialized
INFO - 2023-07-01 05:31:32 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-01 05:31:32 --> Parser Class Initialized
INFO - 2023-07-01 05:31:32 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-01 05:31:32 --> Pagination Class Initialized
INFO - 2023-07-01 05:31:32 --> Form Validation Class Initialized
INFO - 2023-07-01 05:31:32 --> Controller Class Initialized
INFO - 2023-07-01 05:31:32 --> Model Class Initialized
DEBUG - 2023-07-01 05:31:32 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-01 05:31:32 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-01 05:31:32 --> Model Class Initialized
DEBUG - 2023-07-01 05:31:32 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-01 05:31:32 --> Model Class Initialized
INFO - 2023-07-01 05:31:32 --> Final output sent to browser
DEBUG - 2023-07-01 05:31:32 --> Total execution time: 0.0480
ERROR - 2023-07-01 05:31:33 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-01 05:31:33 --> Config Class Initialized
INFO - 2023-07-01 05:31:33 --> Hooks Class Initialized
DEBUG - 2023-07-01 05:31:33 --> UTF-8 Support Enabled
INFO - 2023-07-01 05:31:33 --> Utf8 Class Initialized
INFO - 2023-07-01 05:31:33 --> URI Class Initialized
INFO - 2023-07-01 05:31:33 --> Router Class Initialized
INFO - 2023-07-01 05:31:33 --> Output Class Initialized
INFO - 2023-07-01 05:31:33 --> Security Class Initialized
DEBUG - 2023-07-01 05:31:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-01 05:31:33 --> Input Class Initialized
INFO - 2023-07-01 05:31:33 --> Language Class Initialized
INFO - 2023-07-01 05:31:33 --> Loader Class Initialized
INFO - 2023-07-01 05:31:33 --> Helper loaded: url_helper
INFO - 2023-07-01 05:31:33 --> Helper loaded: file_helper
INFO - 2023-07-01 05:31:33 --> Helper loaded: html_helper
INFO - 2023-07-01 05:31:33 --> Helper loaded: text_helper
INFO - 2023-07-01 05:31:33 --> Helper loaded: form_helper
INFO - 2023-07-01 05:31:33 --> Helper loaded: lang_helper
INFO - 2023-07-01 05:31:33 --> Helper loaded: security_helper
INFO - 2023-07-01 05:31:33 --> Helper loaded: cookie_helper
INFO - 2023-07-01 05:31:33 --> Database Driver Class Initialized
INFO - 2023-07-01 05:31:33 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-01 05:31:33 --> Parser Class Initialized
INFO - 2023-07-01 05:31:33 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-01 05:31:33 --> Pagination Class Initialized
INFO - 2023-07-01 05:31:33 --> Form Validation Class Initialized
INFO - 2023-07-01 05:31:33 --> Controller Class Initialized
INFO - 2023-07-01 05:31:33 --> Model Class Initialized
DEBUG - 2023-07-01 05:31:33 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-01 05:31:33 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-01 05:31:33 --> Model Class Initialized
DEBUG - 2023-07-01 05:31:33 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-01 05:31:33 --> Model Class Initialized
INFO - 2023-07-01 05:31:33 --> Final output sent to browser
DEBUG - 2023-07-01 05:31:33 --> Total execution time: 0.0461
ERROR - 2023-07-01 05:31:34 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-01 05:31:34 --> Config Class Initialized
INFO - 2023-07-01 05:31:34 --> Hooks Class Initialized
DEBUG - 2023-07-01 05:31:34 --> UTF-8 Support Enabled
INFO - 2023-07-01 05:31:34 --> Utf8 Class Initialized
INFO - 2023-07-01 05:31:34 --> URI Class Initialized
INFO - 2023-07-01 05:31:34 --> Router Class Initialized
INFO - 2023-07-01 05:31:34 --> Output Class Initialized
INFO - 2023-07-01 05:31:34 --> Security Class Initialized
DEBUG - 2023-07-01 05:31:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-01 05:31:34 --> Input Class Initialized
INFO - 2023-07-01 05:31:34 --> Language Class Initialized
INFO - 2023-07-01 05:31:34 --> Loader Class Initialized
INFO - 2023-07-01 05:31:34 --> Helper loaded: url_helper
INFO - 2023-07-01 05:31:34 --> Helper loaded: file_helper
INFO - 2023-07-01 05:31:34 --> Helper loaded: html_helper
INFO - 2023-07-01 05:31:34 --> Helper loaded: text_helper
INFO - 2023-07-01 05:31:34 --> Helper loaded: form_helper
INFO - 2023-07-01 05:31:34 --> Helper loaded: lang_helper
INFO - 2023-07-01 05:31:34 --> Helper loaded: security_helper
INFO - 2023-07-01 05:31:34 --> Helper loaded: cookie_helper
INFO - 2023-07-01 05:31:34 --> Database Driver Class Initialized
INFO - 2023-07-01 05:31:34 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-01 05:31:34 --> Parser Class Initialized
INFO - 2023-07-01 05:31:34 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-01 05:31:34 --> Pagination Class Initialized
INFO - 2023-07-01 05:31:34 --> Form Validation Class Initialized
INFO - 2023-07-01 05:31:34 --> Controller Class Initialized
INFO - 2023-07-01 05:31:34 --> Model Class Initialized
DEBUG - 2023-07-01 05:31:34 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-01 05:31:34 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-01 05:31:34 --> Model Class Initialized
DEBUG - 2023-07-01 05:31:34 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-01 05:31:34 --> Model Class Initialized
INFO - 2023-07-01 05:31:34 --> Final output sent to browser
DEBUG - 2023-07-01 05:31:34 --> Total execution time: 0.0190
ERROR - 2023-07-01 05:31:35 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-01 05:31:35 --> Config Class Initialized
INFO - 2023-07-01 05:31:35 --> Hooks Class Initialized
DEBUG - 2023-07-01 05:31:35 --> UTF-8 Support Enabled
INFO - 2023-07-01 05:31:35 --> Utf8 Class Initialized
INFO - 2023-07-01 05:31:35 --> URI Class Initialized
INFO - 2023-07-01 05:31:35 --> Router Class Initialized
INFO - 2023-07-01 05:31:35 --> Output Class Initialized
INFO - 2023-07-01 05:31:35 --> Security Class Initialized
DEBUG - 2023-07-01 05:31:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-01 05:31:35 --> Input Class Initialized
INFO - 2023-07-01 05:31:35 --> Language Class Initialized
INFO - 2023-07-01 05:31:35 --> Loader Class Initialized
INFO - 2023-07-01 05:31:35 --> Helper loaded: url_helper
INFO - 2023-07-01 05:31:35 --> Helper loaded: file_helper
INFO - 2023-07-01 05:31:35 --> Helper loaded: html_helper
INFO - 2023-07-01 05:31:35 --> Helper loaded: text_helper
INFO - 2023-07-01 05:31:35 --> Helper loaded: form_helper
INFO - 2023-07-01 05:31:35 --> Helper loaded: lang_helper
INFO - 2023-07-01 05:31:35 --> Helper loaded: security_helper
INFO - 2023-07-01 05:31:35 --> Helper loaded: cookie_helper
INFO - 2023-07-01 05:31:35 --> Database Driver Class Initialized
INFO - 2023-07-01 05:31:35 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-01 05:31:35 --> Parser Class Initialized
INFO - 2023-07-01 05:31:35 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-01 05:31:35 --> Pagination Class Initialized
INFO - 2023-07-01 05:31:35 --> Form Validation Class Initialized
INFO - 2023-07-01 05:31:35 --> Controller Class Initialized
INFO - 2023-07-01 05:31:35 --> Model Class Initialized
DEBUG - 2023-07-01 05:31:35 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-01 05:31:35 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-01 05:31:35 --> Model Class Initialized
INFO - 2023-07-01 05:31:35 --> Model Class Initialized
INFO - 2023-07-01 05:31:35 --> Final output sent to browser
DEBUG - 2023-07-01 05:31:35 --> Total execution time: 0.0177
ERROR - 2023-07-01 05:31:37 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-01 05:31:37 --> Config Class Initialized
INFO - 2023-07-01 05:31:37 --> Hooks Class Initialized
DEBUG - 2023-07-01 05:31:37 --> UTF-8 Support Enabled
INFO - 2023-07-01 05:31:37 --> Utf8 Class Initialized
INFO - 2023-07-01 05:31:37 --> URI Class Initialized
INFO - 2023-07-01 05:31:37 --> Router Class Initialized
INFO - 2023-07-01 05:31:37 --> Output Class Initialized
INFO - 2023-07-01 05:31:37 --> Security Class Initialized
DEBUG - 2023-07-01 05:31:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-01 05:31:37 --> Input Class Initialized
INFO - 2023-07-01 05:31:37 --> Language Class Initialized
INFO - 2023-07-01 05:31:37 --> Loader Class Initialized
INFO - 2023-07-01 05:31:37 --> Helper loaded: url_helper
INFO - 2023-07-01 05:31:37 --> Helper loaded: file_helper
INFO - 2023-07-01 05:31:37 --> Helper loaded: html_helper
INFO - 2023-07-01 05:31:37 --> Helper loaded: text_helper
INFO - 2023-07-01 05:31:37 --> Helper loaded: form_helper
INFO - 2023-07-01 05:31:37 --> Helper loaded: lang_helper
INFO - 2023-07-01 05:31:37 --> Helper loaded: security_helper
INFO - 2023-07-01 05:31:37 --> Helper loaded: cookie_helper
INFO - 2023-07-01 05:31:37 --> Database Driver Class Initialized
INFO - 2023-07-01 05:31:37 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-01 05:31:37 --> Parser Class Initialized
INFO - 2023-07-01 05:31:37 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-01 05:31:37 --> Pagination Class Initialized
INFO - 2023-07-01 05:31:37 --> Form Validation Class Initialized
INFO - 2023-07-01 05:31:37 --> Controller Class Initialized
INFO - 2023-07-01 05:31:37 --> Model Class Initialized
DEBUG - 2023-07-01 05:31:37 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-01 05:31:37 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-01 05:31:37 --> Model Class Initialized
INFO - 2023-07-01 05:31:37 --> Final output sent to browser
DEBUG - 2023-07-01 05:31:37 --> Total execution time: 0.0164
ERROR - 2023-07-01 05:31:40 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-01 05:31:40 --> Config Class Initialized
INFO - 2023-07-01 05:31:40 --> Hooks Class Initialized
DEBUG - 2023-07-01 05:31:40 --> UTF-8 Support Enabled
INFO - 2023-07-01 05:31:40 --> Utf8 Class Initialized
INFO - 2023-07-01 05:31:40 --> URI Class Initialized
INFO - 2023-07-01 05:31:40 --> Router Class Initialized
INFO - 2023-07-01 05:31:40 --> Output Class Initialized
INFO - 2023-07-01 05:31:40 --> Security Class Initialized
DEBUG - 2023-07-01 05:31:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-01 05:31:40 --> Input Class Initialized
INFO - 2023-07-01 05:31:40 --> Language Class Initialized
INFO - 2023-07-01 05:31:40 --> Loader Class Initialized
INFO - 2023-07-01 05:31:40 --> Helper loaded: url_helper
INFO - 2023-07-01 05:31:40 --> Helper loaded: file_helper
INFO - 2023-07-01 05:31:40 --> Helper loaded: html_helper
INFO - 2023-07-01 05:31:40 --> Helper loaded: text_helper
INFO - 2023-07-01 05:31:40 --> Helper loaded: form_helper
INFO - 2023-07-01 05:31:40 --> Helper loaded: lang_helper
INFO - 2023-07-01 05:31:40 --> Helper loaded: security_helper
INFO - 2023-07-01 05:31:40 --> Helper loaded: cookie_helper
INFO - 2023-07-01 05:31:40 --> Database Driver Class Initialized
INFO - 2023-07-01 05:31:40 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-01 05:31:40 --> Parser Class Initialized
INFO - 2023-07-01 05:31:40 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-01 05:31:40 --> Pagination Class Initialized
INFO - 2023-07-01 05:31:40 --> Form Validation Class Initialized
INFO - 2023-07-01 05:31:40 --> Controller Class Initialized
INFO - 2023-07-01 05:31:40 --> Model Class Initialized
DEBUG - 2023-07-01 05:31:40 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-01 05:31:40 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-01 05:31:40 --> Model Class Initialized
DEBUG - 2023-07-01 05:31:40 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-01 05:31:40 --> Model Class Initialized
INFO - 2023-07-01 05:31:40 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice.php
DEBUG - 2023-07-01 05:31:40 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-07-01 05:31:40 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-07-01 05:31:40 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-07-01 05:31:40 --> Model Class Initialized
INFO - 2023-07-01 05:31:40 --> Model Class Initialized
INFO - 2023-07-01 05:31:40 --> Model Class Initialized
INFO - 2023-07-01 05:31:40 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-07-01 05:31:40 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-07-01 05:31:40 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-07-01 05:31:40 --> Final output sent to browser
DEBUG - 2023-07-01 05:31:40 --> Total execution time: 0.0761
ERROR - 2023-07-01 05:31:41 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-01 05:31:41 --> Config Class Initialized
INFO - 2023-07-01 05:31:41 --> Hooks Class Initialized
DEBUG - 2023-07-01 05:31:41 --> UTF-8 Support Enabled
INFO - 2023-07-01 05:31:41 --> Utf8 Class Initialized
INFO - 2023-07-01 05:31:41 --> URI Class Initialized
INFO - 2023-07-01 05:31:41 --> Router Class Initialized
INFO - 2023-07-01 05:31:41 --> Output Class Initialized
INFO - 2023-07-01 05:31:41 --> Security Class Initialized
DEBUG - 2023-07-01 05:31:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-01 05:31:41 --> Input Class Initialized
INFO - 2023-07-01 05:31:41 --> Language Class Initialized
INFO - 2023-07-01 05:31:41 --> Loader Class Initialized
INFO - 2023-07-01 05:31:41 --> Helper loaded: url_helper
INFO - 2023-07-01 05:31:41 --> Helper loaded: file_helper
INFO - 2023-07-01 05:31:41 --> Helper loaded: html_helper
INFO - 2023-07-01 05:31:41 --> Helper loaded: text_helper
INFO - 2023-07-01 05:31:41 --> Helper loaded: form_helper
INFO - 2023-07-01 05:31:41 --> Helper loaded: lang_helper
INFO - 2023-07-01 05:31:41 --> Helper loaded: security_helper
INFO - 2023-07-01 05:31:41 --> Helper loaded: cookie_helper
INFO - 2023-07-01 05:31:41 --> Database Driver Class Initialized
INFO - 2023-07-01 05:31:41 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-01 05:31:41 --> Parser Class Initialized
INFO - 2023-07-01 05:31:41 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-01 05:31:41 --> Pagination Class Initialized
INFO - 2023-07-01 05:31:41 --> Form Validation Class Initialized
INFO - 2023-07-01 05:31:41 --> Controller Class Initialized
INFO - 2023-07-01 05:31:41 --> Model Class Initialized
DEBUG - 2023-07-01 05:31:41 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-01 05:31:41 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-01 05:31:41 --> Model Class Initialized
DEBUG - 2023-07-01 05:31:41 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-01 05:31:41 --> Model Class Initialized
INFO - 2023-07-01 05:31:41 --> Final output sent to browser
DEBUG - 2023-07-01 05:31:41 --> Total execution time: 0.0406
ERROR - 2023-07-01 05:31:50 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-01 05:31:50 --> Config Class Initialized
INFO - 2023-07-01 05:31:50 --> Hooks Class Initialized
DEBUG - 2023-07-01 05:31:50 --> UTF-8 Support Enabled
INFO - 2023-07-01 05:31:50 --> Utf8 Class Initialized
INFO - 2023-07-01 05:31:50 --> URI Class Initialized
INFO - 2023-07-01 05:31:50 --> Router Class Initialized
INFO - 2023-07-01 05:31:50 --> Output Class Initialized
INFO - 2023-07-01 05:31:50 --> Security Class Initialized
DEBUG - 2023-07-01 05:31:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-01 05:31:50 --> Input Class Initialized
INFO - 2023-07-01 05:31:50 --> Language Class Initialized
INFO - 2023-07-01 05:31:50 --> Loader Class Initialized
INFO - 2023-07-01 05:31:50 --> Helper loaded: url_helper
INFO - 2023-07-01 05:31:50 --> Helper loaded: file_helper
INFO - 2023-07-01 05:31:50 --> Helper loaded: html_helper
INFO - 2023-07-01 05:31:50 --> Helper loaded: text_helper
INFO - 2023-07-01 05:31:50 --> Helper loaded: form_helper
INFO - 2023-07-01 05:31:50 --> Helper loaded: lang_helper
INFO - 2023-07-01 05:31:50 --> Helper loaded: security_helper
INFO - 2023-07-01 05:31:50 --> Helper loaded: cookie_helper
INFO - 2023-07-01 05:31:50 --> Database Driver Class Initialized
INFO - 2023-07-01 05:31:50 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-01 05:31:50 --> Parser Class Initialized
INFO - 2023-07-01 05:31:50 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-01 05:31:50 --> Pagination Class Initialized
INFO - 2023-07-01 05:31:50 --> Form Validation Class Initialized
INFO - 2023-07-01 05:31:50 --> Controller Class Initialized
INFO - 2023-07-01 05:31:50 --> Model Class Initialized
DEBUG - 2023-07-01 05:31:50 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-01 05:31:50 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-01 05:31:50 --> Model Class Initialized
DEBUG - 2023-07-01 05:31:50 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-01 05:31:50 --> Model Class Initialized
INFO - 2023-07-01 05:31:50 --> Email Class Initialized
DEBUG - 2023-07-01 05:31:50 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-01 05:31:51 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice_html_pdf.php
ERROR - 2023-07-01 05:31:51 --> Severity: Warning --> "continue" targeting switch is equivalent to "break". Did you mean to use "continue 2"? /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/dompdf.cls.php 743
ERROR - 2023-07-01 05:31:51 --> Severity: Warning --> "continue" targeting switch is equivalent to "break". Did you mean to use "continue 2"? /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/dompdf.cls.php 763
ERROR - 2023-07-01 05:31:51 --> Severity: Warning --> "continue" targeting switch is equivalent to "break". Did you mean to use "continue 2"? /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/stylesheet.cls.php 1102
ERROR - 2023-07-01 05:31:51 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/page_frame_decorator.cls.php 439
ERROR - 2023-07-01 05:31:51 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/page_frame_decorator.cls.php 439
ERROR - 2023-07-01 05:31:51 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/page_frame_decorator.cls.php 439
ERROR - 2023-07-01 05:31:51 --> Severity: Warning --> Division by zero /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 572
ERROR - 2023-07-01 05:31:51 --> Severity: Warning --> Division by zero /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 572
ERROR - 2023-07-01 05:31:51 --> Severity: Warning --> Division by zero /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 572
ERROR - 2023-07-01 05:31:51 --> Severity: Warning --> Division by zero /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 572
ERROR - 2023-07-01 05:31:51 --> Severity: Warning --> Division by zero /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 572
ERROR - 2023-07-01 05:31:51 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/table_cell_frame_reflower.cls.php 103
ERROR - 2023-07-01 05:31:51 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/table_cell_frame_reflower.cls.php 103
ERROR - 2023-07-01 05:31:51 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/table_cell_frame_reflower.cls.php 103
ERROR - 2023-07-01 05:31:51 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/table_cell_frame_reflower.cls.php 103
ERROR - 2023-07-01 05:31:51 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/table_cell_frame_reflower.cls.php 103
ERROR - 2023-07-01 05:31:51 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/table_cell_frame_reflower.cls.php 103
ERROR - 2023-07-01 05:31:51 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/table_cell_frame_reflower.cls.php 103
ERROR - 2023-07-01 05:31:51 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/table_cell_frame_reflower.cls.php 103
ERROR - 2023-07-01 05:31:51 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/table_cell_frame_reflower.cls.php 103
ERROR - 2023-07-01 05:31:51 --> Severity: Warning --> Invalid argument supplied for foreach() /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 709
ERROR - 2023-07-01 05:31:51 --> Severity: Warning --> Invalid argument supplied for foreach() /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 709
ERROR - 2023-07-01 05:31:51 --> Severity: Warning --> Invalid argument supplied for foreach() /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 709
ERROR - 2023-07-01 05:31:51 --> Severity: Warning --> Invalid argument supplied for foreach() /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 709
ERROR - 2023-07-01 05:31:51 --> Severity: Warning --> Invalid argument supplied for foreach() /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 709
ERROR - 2023-07-01 05:31:51 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-07-01 05:31:51 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-07-01 05:31:51 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-07-01 05:31:51 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-07-01 05:31:51 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-07-01 05:31:51 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-07-01 05:31:51 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-07-01 05:31:51 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-07-01 05:31:51 --> Severity: Warning --> "continue" targeting switch is equivalent to "break". Did you mean to use "continue 2"? /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/text_renderer.cls.php 126
ERROR - 2023-07-01 05:31:51 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-07-01 05:31:51 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-07-01 05:31:51 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-07-01 05:31:51 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-07-01 05:31:51 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-07-01 05:31:51 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-07-01 05:31:51 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-07-01 05:31:51 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-07-01 05:31:51 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-07-01 05:31:51 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-07-01 05:31:51 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-07-01 05:31:51 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-07-01 05:31:51 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-07-01 05:31:51 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-07-01 05:31:51 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-07-01 05:31:51 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-07-01 05:31:51 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-07-01 05:31:51 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-07-01 05:31:51 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-07-01 05:31:51 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-07-01 05:31:51 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-07-01 05:31:51 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-07-01 05:31:51 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-07-01 05:31:51 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-07-01 05:31:51 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-07-01 05:31:51 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-07-01 05:31:51 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-07-01 05:31:51 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-07-01 05:31:51 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-07-01 05:31:51 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-07-01 05:31:51 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-07-01 05:31:51 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-07-01 05:31:51 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-07-01 05:31:51 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-07-01 05:31:51 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-07-01 05:31:51 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-07-01 05:31:51 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-07-01 05:31:51 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-07-01 05:31:51 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-07-01 05:31:51 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-07-01 05:31:51 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-07-01 05:31:51 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-07-01 05:31:51 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-07-01 05:31:51 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-07-01 05:31:51 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-07-01 05:31:51 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-07-01 05:31:51 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-07-01 05:31:51 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-07-01 05:31:51 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-07-01 05:31:51 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-07-01 05:31:51 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-07-01 05:31:51 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-07-01 05:31:51 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-07-01 05:31:51 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-07-01 05:31:51 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-07-01 05:31:51 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-07-01 05:31:51 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-07-01 05:31:51 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-07-01 05:31:51 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-07-01 05:31:51 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-07-01 05:31:51 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-07-01 05:31:51 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-07-01 05:31:51 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-07-01 05:31:51 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-07-01 05:31:51 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-07-01 05:31:51 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-07-01 05:31:51 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-07-01 05:31:51 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-07-01 05:31:51 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-07-01 05:31:51 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-07-01 05:31:51 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-07-01 05:31:51 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-07-01 05:31:51 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-07-01 05:31:51 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-07-01 05:31:51 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-07-01 05:31:51 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-07-01 05:31:51 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-07-01 05:31:51 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-07-01 05:31:51 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-07-01 05:31:51 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-07-01 05:31:51 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-07-01 05:31:51 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-07-01 05:31:51 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-07-01 05:31:51 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-07-01 05:31:51 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-07-01 05:31:51 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-07-01 05:31:51 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-07-01 05:31:51 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-07-01 05:31:51 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-07-01 05:31:51 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-07-01 05:31:51 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-07-01 05:31:51 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-07-01 05:31:51 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-07-01 05:31:51 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-07-01 05:31:51 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-07-01 05:31:51 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
INFO - 2023-07-01 05:31:51 --> Language file loaded: language/english/email_lang.php
INFO - 2023-07-01 05:31:51 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice_html.php
INFO - 2023-07-01 05:31:51 --> Final output sent to browser
DEBUG - 2023-07-01 05:31:51 --> Total execution time: 0.4983
ERROR - 2023-07-01 05:31:54 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-01 05:31:54 --> Config Class Initialized
INFO - 2023-07-01 05:31:54 --> Hooks Class Initialized
DEBUG - 2023-07-01 05:31:54 --> UTF-8 Support Enabled
INFO - 2023-07-01 05:31:54 --> Utf8 Class Initialized
INFO - 2023-07-01 05:31:54 --> URI Class Initialized
INFO - 2023-07-01 05:31:54 --> Router Class Initialized
INFO - 2023-07-01 05:31:54 --> Output Class Initialized
INFO - 2023-07-01 05:31:54 --> Security Class Initialized
DEBUG - 2023-07-01 05:31:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-01 05:31:54 --> Input Class Initialized
INFO - 2023-07-01 05:31:54 --> Language Class Initialized
INFO - 2023-07-01 05:31:54 --> Loader Class Initialized
INFO - 2023-07-01 05:31:54 --> Helper loaded: url_helper
INFO - 2023-07-01 05:31:54 --> Helper loaded: file_helper
INFO - 2023-07-01 05:31:54 --> Helper loaded: html_helper
INFO - 2023-07-01 05:31:54 --> Helper loaded: text_helper
INFO - 2023-07-01 05:31:54 --> Helper loaded: form_helper
INFO - 2023-07-01 05:31:54 --> Helper loaded: lang_helper
INFO - 2023-07-01 05:31:54 --> Helper loaded: security_helper
INFO - 2023-07-01 05:31:54 --> Helper loaded: cookie_helper
INFO - 2023-07-01 05:31:54 --> Database Driver Class Initialized
INFO - 2023-07-01 05:31:54 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-01 05:31:54 --> Parser Class Initialized
INFO - 2023-07-01 05:31:54 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-01 05:31:54 --> Pagination Class Initialized
INFO - 2023-07-01 05:31:54 --> Form Validation Class Initialized
INFO - 2023-07-01 05:31:54 --> Controller Class Initialized
INFO - 2023-07-01 05:31:54 --> Model Class Initialized
DEBUG - 2023-07-01 05:31:54 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-01 05:31:54 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-01 05:31:54 --> Model Class Initialized
DEBUG - 2023-07-01 05:31:54 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-01 05:31:54 --> Model Class Initialized
INFO - 2023-07-01 05:31:54 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/add_invoice_form.php
DEBUG - 2023-07-01 05:31:54 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-07-01 05:31:54 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-07-01 05:31:54 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-07-01 05:31:54 --> Model Class Initialized
INFO - 2023-07-01 05:31:54 --> Model Class Initialized
INFO - 2023-07-01 05:31:54 --> Model Class Initialized
INFO - 2023-07-01 05:31:54 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-07-01 05:31:54 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-07-01 05:31:54 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-07-01 05:31:54 --> Final output sent to browser
DEBUG - 2023-07-01 05:31:54 --> Total execution time: 0.1049
ERROR - 2023-07-01 05:31:57 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-01 05:31:57 --> Config Class Initialized
INFO - 2023-07-01 05:31:57 --> Hooks Class Initialized
DEBUG - 2023-07-01 05:31:57 --> UTF-8 Support Enabled
INFO - 2023-07-01 05:31:57 --> Utf8 Class Initialized
INFO - 2023-07-01 05:31:57 --> URI Class Initialized
DEBUG - 2023-07-01 05:31:57 --> No URI present. Default controller set.
INFO - 2023-07-01 05:31:57 --> Router Class Initialized
INFO - 2023-07-01 05:31:57 --> Output Class Initialized
INFO - 2023-07-01 05:31:57 --> Security Class Initialized
DEBUG - 2023-07-01 05:31:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-01 05:31:57 --> Input Class Initialized
INFO - 2023-07-01 05:31:57 --> Language Class Initialized
INFO - 2023-07-01 05:31:57 --> Loader Class Initialized
INFO - 2023-07-01 05:31:57 --> Helper loaded: url_helper
INFO - 2023-07-01 05:31:57 --> Helper loaded: file_helper
INFO - 2023-07-01 05:31:57 --> Helper loaded: html_helper
INFO - 2023-07-01 05:31:57 --> Helper loaded: text_helper
INFO - 2023-07-01 05:31:57 --> Helper loaded: form_helper
INFO - 2023-07-01 05:31:57 --> Helper loaded: lang_helper
INFO - 2023-07-01 05:31:57 --> Helper loaded: security_helper
INFO - 2023-07-01 05:31:57 --> Helper loaded: cookie_helper
INFO - 2023-07-01 05:31:57 --> Database Driver Class Initialized
INFO - 2023-07-01 05:31:57 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-01 05:31:57 --> Parser Class Initialized
INFO - 2023-07-01 05:31:57 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-01 05:31:57 --> Pagination Class Initialized
INFO - 2023-07-01 05:31:57 --> Form Validation Class Initialized
INFO - 2023-07-01 05:31:57 --> Controller Class Initialized
INFO - 2023-07-01 05:31:57 --> Model Class Initialized
DEBUG - 2023-07-01 05:31:57 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-01 05:31:57 --> Model Class Initialized
DEBUG - 2023-07-01 05:31:57 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-01 05:31:57 --> Model Class Initialized
INFO - 2023-07-01 05:31:57 --> Model Class Initialized
INFO - 2023-07-01 05:31:57 --> Model Class Initialized
INFO - 2023-07-01 05:31:57 --> Model Class Initialized
DEBUG - 2023-07-01 05:31:57 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-01 05:31:57 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-01 05:31:57 --> Model Class Initialized
INFO - 2023-07-01 05:31:57 --> Model Class Initialized
INFO - 2023-07-01 05:31:57 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-07-01 05:31:57 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-07-01 05:31:57 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-07-01 05:31:57 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-07-01 05:31:57 --> Model Class Initialized
INFO - 2023-07-01 05:31:57 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-07-01 05:31:57 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-07-01 05:31:57 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-07-01 05:31:57 --> Final output sent to browser
DEBUG - 2023-07-01 05:31:57 --> Total execution time: 0.0925
ERROR - 2023-07-01 06:26:23 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-01 06:26:23 --> Config Class Initialized
INFO - 2023-07-01 06:26:23 --> Hooks Class Initialized
DEBUG - 2023-07-01 06:26:23 --> UTF-8 Support Enabled
INFO - 2023-07-01 06:26:23 --> Utf8 Class Initialized
INFO - 2023-07-01 06:26:23 --> URI Class Initialized
INFO - 2023-07-01 06:26:23 --> Router Class Initialized
INFO - 2023-07-01 06:26:23 --> Output Class Initialized
INFO - 2023-07-01 06:26:23 --> Security Class Initialized
DEBUG - 2023-07-01 06:26:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-01 06:26:23 --> Input Class Initialized
INFO - 2023-07-01 06:26:23 --> Language Class Initialized
INFO - 2023-07-01 06:26:23 --> Loader Class Initialized
INFO - 2023-07-01 06:26:23 --> Helper loaded: url_helper
INFO - 2023-07-01 06:26:23 --> Helper loaded: file_helper
INFO - 2023-07-01 06:26:23 --> Helper loaded: html_helper
INFO - 2023-07-01 06:26:23 --> Helper loaded: text_helper
INFO - 2023-07-01 06:26:23 --> Helper loaded: form_helper
INFO - 2023-07-01 06:26:23 --> Helper loaded: lang_helper
INFO - 2023-07-01 06:26:23 --> Helper loaded: security_helper
INFO - 2023-07-01 06:26:23 --> Helper loaded: cookie_helper
INFO - 2023-07-01 06:26:23 --> Database Driver Class Initialized
INFO - 2023-07-01 06:26:23 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-01 06:26:23 --> Parser Class Initialized
INFO - 2023-07-01 06:26:23 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-01 06:26:23 --> Pagination Class Initialized
INFO - 2023-07-01 06:26:23 --> Form Validation Class Initialized
INFO - 2023-07-01 06:26:23 --> Controller Class Initialized
ERROR - 2023-07-01 06:38:50 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-01 06:38:50 --> Config Class Initialized
INFO - 2023-07-01 06:38:50 --> Hooks Class Initialized
DEBUG - 2023-07-01 06:38:50 --> UTF-8 Support Enabled
INFO - 2023-07-01 06:38:50 --> Utf8 Class Initialized
INFO - 2023-07-01 06:38:50 --> URI Class Initialized
DEBUG - 2023-07-01 06:38:50 --> No URI present. Default controller set.
INFO - 2023-07-01 06:38:50 --> Router Class Initialized
INFO - 2023-07-01 06:38:50 --> Output Class Initialized
INFO - 2023-07-01 06:38:50 --> Security Class Initialized
DEBUG - 2023-07-01 06:38:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-01 06:38:50 --> Input Class Initialized
INFO - 2023-07-01 06:38:50 --> Language Class Initialized
INFO - 2023-07-01 06:38:50 --> Loader Class Initialized
INFO - 2023-07-01 06:38:50 --> Helper loaded: url_helper
INFO - 2023-07-01 06:38:50 --> Helper loaded: file_helper
INFO - 2023-07-01 06:38:50 --> Helper loaded: html_helper
INFO - 2023-07-01 06:38:50 --> Helper loaded: text_helper
INFO - 2023-07-01 06:38:50 --> Helper loaded: form_helper
INFO - 2023-07-01 06:38:50 --> Helper loaded: lang_helper
INFO - 2023-07-01 06:38:50 --> Helper loaded: security_helper
INFO - 2023-07-01 06:38:50 --> Helper loaded: cookie_helper
INFO - 2023-07-01 06:38:50 --> Database Driver Class Initialized
INFO - 2023-07-01 06:38:50 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-01 06:38:50 --> Parser Class Initialized
INFO - 2023-07-01 06:38:50 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-01 06:38:50 --> Pagination Class Initialized
INFO - 2023-07-01 06:38:50 --> Form Validation Class Initialized
INFO - 2023-07-01 06:38:50 --> Controller Class Initialized
INFO - 2023-07-01 06:38:50 --> Model Class Initialized
DEBUG - 2023-07-01 06:38:50 --> Session class already loaded. Second attempt ignored.
ERROR - 2023-07-01 06:38:50 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-01 06:38:50 --> Config Class Initialized
INFO - 2023-07-01 06:38:50 --> Hooks Class Initialized
DEBUG - 2023-07-01 06:38:50 --> UTF-8 Support Enabled
INFO - 2023-07-01 06:38:50 --> Utf8 Class Initialized
INFO - 2023-07-01 06:38:50 --> URI Class Initialized
INFO - 2023-07-01 06:38:50 --> Router Class Initialized
INFO - 2023-07-01 06:38:50 --> Output Class Initialized
INFO - 2023-07-01 06:38:50 --> Security Class Initialized
DEBUG - 2023-07-01 06:38:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-01 06:38:50 --> Input Class Initialized
INFO - 2023-07-01 06:38:50 --> Language Class Initialized
INFO - 2023-07-01 06:38:50 --> Loader Class Initialized
INFO - 2023-07-01 06:38:50 --> Helper loaded: url_helper
INFO - 2023-07-01 06:38:50 --> Helper loaded: file_helper
INFO - 2023-07-01 06:38:50 --> Helper loaded: html_helper
INFO - 2023-07-01 06:38:50 --> Helper loaded: text_helper
INFO - 2023-07-01 06:38:50 --> Helper loaded: form_helper
INFO - 2023-07-01 06:38:50 --> Helper loaded: lang_helper
INFO - 2023-07-01 06:38:50 --> Helper loaded: security_helper
INFO - 2023-07-01 06:38:50 --> Helper loaded: cookie_helper
INFO - 2023-07-01 06:38:50 --> Database Driver Class Initialized
INFO - 2023-07-01 06:38:50 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-01 06:38:50 --> Parser Class Initialized
INFO - 2023-07-01 06:38:50 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-01 06:38:50 --> Pagination Class Initialized
INFO - 2023-07-01 06:38:50 --> Form Validation Class Initialized
INFO - 2023-07-01 06:38:50 --> Controller Class Initialized
INFO - 2023-07-01 06:38:50 --> Model Class Initialized
DEBUG - 2023-07-01 06:38:50 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-01 06:38:50 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2023-07-01 06:38:50 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-07-01 06:38:50 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-07-01 06:38:50 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-07-01 06:38:50 --> Model Class Initialized
INFO - 2023-07-01 06:38:50 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-07-01 06:38:50 --> Final output sent to browser
DEBUG - 2023-07-01 06:38:50 --> Total execution time: 0.0321
ERROR - 2023-07-01 07:20:57 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-01 07:20:57 --> Config Class Initialized
INFO - 2023-07-01 07:20:57 --> Hooks Class Initialized
DEBUG - 2023-07-01 07:20:57 --> UTF-8 Support Enabled
INFO - 2023-07-01 07:20:57 --> Utf8 Class Initialized
INFO - 2023-07-01 07:20:57 --> URI Class Initialized
DEBUG - 2023-07-01 07:20:57 --> No URI present. Default controller set.
INFO - 2023-07-01 07:20:57 --> Router Class Initialized
INFO - 2023-07-01 07:20:57 --> Output Class Initialized
INFO - 2023-07-01 07:20:57 --> Security Class Initialized
DEBUG - 2023-07-01 07:20:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-01 07:20:57 --> Input Class Initialized
INFO - 2023-07-01 07:20:57 --> Language Class Initialized
INFO - 2023-07-01 07:20:57 --> Loader Class Initialized
INFO - 2023-07-01 07:20:57 --> Helper loaded: url_helper
INFO - 2023-07-01 07:20:57 --> Helper loaded: file_helper
INFO - 2023-07-01 07:20:57 --> Helper loaded: html_helper
INFO - 2023-07-01 07:20:57 --> Helper loaded: text_helper
INFO - 2023-07-01 07:20:57 --> Helper loaded: form_helper
INFO - 2023-07-01 07:20:57 --> Helper loaded: lang_helper
INFO - 2023-07-01 07:20:57 --> Helper loaded: security_helper
INFO - 2023-07-01 07:20:57 --> Helper loaded: cookie_helper
INFO - 2023-07-01 07:20:57 --> Database Driver Class Initialized
INFO - 2023-07-01 07:20:57 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-01 07:20:57 --> Parser Class Initialized
INFO - 2023-07-01 07:20:57 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-01 07:20:57 --> Pagination Class Initialized
INFO - 2023-07-01 07:20:57 --> Form Validation Class Initialized
INFO - 2023-07-01 07:20:57 --> Controller Class Initialized
INFO - 2023-07-01 07:20:57 --> Model Class Initialized
DEBUG - 2023-07-01 07:20:57 --> Session class already loaded. Second attempt ignored.
ERROR - 2023-07-01 07:40:23 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-01 07:40:23 --> Config Class Initialized
INFO - 2023-07-01 07:40:23 --> Hooks Class Initialized
DEBUG - 2023-07-01 07:40:23 --> UTF-8 Support Enabled
INFO - 2023-07-01 07:40:23 --> Utf8 Class Initialized
INFO - 2023-07-01 07:40:23 --> URI Class Initialized
INFO - 2023-07-01 07:40:23 --> Router Class Initialized
INFO - 2023-07-01 07:40:23 --> Output Class Initialized
INFO - 2023-07-01 07:40:23 --> Security Class Initialized
DEBUG - 2023-07-01 07:40:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-01 07:40:23 --> Input Class Initialized
INFO - 2023-07-01 07:40:23 --> Language Class Initialized
INFO - 2023-07-01 07:40:23 --> Loader Class Initialized
INFO - 2023-07-01 07:40:23 --> Helper loaded: url_helper
INFO - 2023-07-01 07:40:23 --> Helper loaded: file_helper
INFO - 2023-07-01 07:40:23 --> Helper loaded: html_helper
INFO - 2023-07-01 07:40:23 --> Helper loaded: text_helper
INFO - 2023-07-01 07:40:23 --> Helper loaded: form_helper
INFO - 2023-07-01 07:40:23 --> Helper loaded: lang_helper
INFO - 2023-07-01 07:40:23 --> Helper loaded: security_helper
INFO - 2023-07-01 07:40:23 --> Helper loaded: cookie_helper
INFO - 2023-07-01 07:40:23 --> Database Driver Class Initialized
INFO - 2023-07-01 07:40:23 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-01 07:40:23 --> Parser Class Initialized
INFO - 2023-07-01 07:40:23 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-01 07:40:23 --> Pagination Class Initialized
INFO - 2023-07-01 07:40:23 --> Form Validation Class Initialized
INFO - 2023-07-01 07:40:23 --> Controller Class Initialized
ERROR - 2023-07-01 07:40:24 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-01 07:40:24 --> Config Class Initialized
INFO - 2023-07-01 07:40:24 --> Hooks Class Initialized
DEBUG - 2023-07-01 07:40:24 --> UTF-8 Support Enabled
INFO - 2023-07-01 07:40:24 --> Utf8 Class Initialized
INFO - 2023-07-01 07:40:24 --> URI Class Initialized
INFO - 2023-07-01 07:40:24 --> Router Class Initialized
INFO - 2023-07-01 07:40:24 --> Output Class Initialized
INFO - 2023-07-01 07:40:24 --> Security Class Initialized
DEBUG - 2023-07-01 07:40:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-01 07:40:24 --> Input Class Initialized
INFO - 2023-07-01 07:40:24 --> Language Class Initialized
INFO - 2023-07-01 07:40:24 --> Loader Class Initialized
INFO - 2023-07-01 07:40:24 --> Helper loaded: url_helper
INFO - 2023-07-01 07:40:24 --> Helper loaded: file_helper
INFO - 2023-07-01 07:40:24 --> Helper loaded: html_helper
INFO - 2023-07-01 07:40:24 --> Helper loaded: text_helper
INFO - 2023-07-01 07:40:24 --> Helper loaded: form_helper
INFO - 2023-07-01 07:40:24 --> Helper loaded: lang_helper
INFO - 2023-07-01 07:40:24 --> Helper loaded: security_helper
INFO - 2023-07-01 07:40:24 --> Helper loaded: cookie_helper
INFO - 2023-07-01 07:40:24 --> Database Driver Class Initialized
INFO - 2023-07-01 07:40:24 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-01 07:40:24 --> Parser Class Initialized
INFO - 2023-07-01 07:40:24 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-01 07:40:24 --> Pagination Class Initialized
INFO - 2023-07-01 07:40:24 --> Form Validation Class Initialized
INFO - 2023-07-01 07:40:24 --> Controller Class Initialized
INFO - 2023-07-01 07:40:24 --> Model Class Initialized
DEBUG - 2023-07-01 07:40:24 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-01 07:40:24 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2023-07-01 07:40:24 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-07-01 07:40:24 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-07-01 07:40:24 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-07-01 07:40:24 --> Model Class Initialized
INFO - 2023-07-01 07:40:24 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-07-01 07:40:24 --> Final output sent to browser
DEBUG - 2023-07-01 07:40:24 --> Total execution time: 0.0287
ERROR - 2023-07-01 08:52:29 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-01 08:52:29 --> Config Class Initialized
INFO - 2023-07-01 08:52:29 --> Hooks Class Initialized
DEBUG - 2023-07-01 08:52:29 --> UTF-8 Support Enabled
INFO - 2023-07-01 08:52:29 --> Utf8 Class Initialized
INFO - 2023-07-01 08:52:29 --> URI Class Initialized
INFO - 2023-07-01 08:52:29 --> Router Class Initialized
INFO - 2023-07-01 08:52:29 --> Output Class Initialized
INFO - 2023-07-01 08:52:29 --> Security Class Initialized
DEBUG - 2023-07-01 08:52:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-01 08:52:29 --> Input Class Initialized
INFO - 2023-07-01 08:52:29 --> Language Class Initialized
INFO - 2023-07-01 08:52:29 --> Loader Class Initialized
INFO - 2023-07-01 08:52:29 --> Helper loaded: url_helper
INFO - 2023-07-01 08:52:29 --> Helper loaded: file_helper
INFO - 2023-07-01 08:52:29 --> Helper loaded: html_helper
INFO - 2023-07-01 08:52:29 --> Helper loaded: text_helper
INFO - 2023-07-01 08:52:29 --> Helper loaded: form_helper
INFO - 2023-07-01 08:52:29 --> Helper loaded: lang_helper
INFO - 2023-07-01 08:52:29 --> Helper loaded: security_helper
INFO - 2023-07-01 08:52:29 --> Helper loaded: cookie_helper
INFO - 2023-07-01 08:52:29 --> Database Driver Class Initialized
INFO - 2023-07-01 08:52:29 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-01 08:52:29 --> Parser Class Initialized
INFO - 2023-07-01 08:52:29 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-01 08:52:29 --> Pagination Class Initialized
INFO - 2023-07-01 08:52:29 --> Form Validation Class Initialized
INFO - 2023-07-01 08:52:29 --> Controller Class Initialized
INFO - 2023-07-01 08:52:29 --> Model Class Initialized
DEBUG - 2023-07-01 08:52:29 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-01 08:52:29 --> Model Class Initialized
INFO - 2023-07-01 08:52:29 --> Final output sent to browser
DEBUG - 2023-07-01 08:52:29 --> Total execution time: 0.0233
ERROR - 2023-07-01 08:52:30 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-01 08:52:30 --> Config Class Initialized
INFO - 2023-07-01 08:52:30 --> Hooks Class Initialized
DEBUG - 2023-07-01 08:52:30 --> UTF-8 Support Enabled
INFO - 2023-07-01 08:52:30 --> Utf8 Class Initialized
INFO - 2023-07-01 08:52:30 --> URI Class Initialized
DEBUG - 2023-07-01 08:52:30 --> No URI present. Default controller set.
INFO - 2023-07-01 08:52:30 --> Router Class Initialized
INFO - 2023-07-01 08:52:30 --> Output Class Initialized
INFO - 2023-07-01 08:52:30 --> Security Class Initialized
DEBUG - 2023-07-01 08:52:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-01 08:52:30 --> Input Class Initialized
INFO - 2023-07-01 08:52:30 --> Language Class Initialized
INFO - 2023-07-01 08:52:30 --> Loader Class Initialized
INFO - 2023-07-01 08:52:30 --> Helper loaded: url_helper
INFO - 2023-07-01 08:52:30 --> Helper loaded: file_helper
INFO - 2023-07-01 08:52:30 --> Helper loaded: html_helper
INFO - 2023-07-01 08:52:30 --> Helper loaded: text_helper
INFO - 2023-07-01 08:52:30 --> Helper loaded: form_helper
INFO - 2023-07-01 08:52:30 --> Helper loaded: lang_helper
INFO - 2023-07-01 08:52:30 --> Helper loaded: security_helper
INFO - 2023-07-01 08:52:30 --> Helper loaded: cookie_helper
INFO - 2023-07-01 08:52:30 --> Database Driver Class Initialized
INFO - 2023-07-01 08:52:30 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-01 08:52:30 --> Parser Class Initialized
INFO - 2023-07-01 08:52:30 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-01 08:52:30 --> Pagination Class Initialized
INFO - 2023-07-01 08:52:30 --> Form Validation Class Initialized
INFO - 2023-07-01 08:52:30 --> Controller Class Initialized
INFO - 2023-07-01 08:52:30 --> Model Class Initialized
DEBUG - 2023-07-01 08:52:30 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-01 08:52:30 --> Model Class Initialized
DEBUG - 2023-07-01 08:52:30 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-01 08:52:30 --> Model Class Initialized
INFO - 2023-07-01 08:52:30 --> Model Class Initialized
INFO - 2023-07-01 08:52:30 --> Model Class Initialized
INFO - 2023-07-01 08:52:30 --> Model Class Initialized
DEBUG - 2023-07-01 08:52:30 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-01 08:52:30 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-01 08:52:30 --> Model Class Initialized
INFO - 2023-07-01 08:52:30 --> Model Class Initialized
INFO - 2023-07-01 08:52:30 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-07-01 08:52:30 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-07-01 08:52:30 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-07-01 08:52:30 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-07-01 08:52:30 --> Model Class Initialized
INFO - 2023-07-01 08:52:30 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-07-01 08:52:30 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-07-01 08:52:30 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-07-01 08:52:30 --> Final output sent to browser
DEBUG - 2023-07-01 08:52:30 --> Total execution time: 0.0808
ERROR - 2023-07-01 08:52:43 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-01 08:52:43 --> Config Class Initialized
INFO - 2023-07-01 08:52:43 --> Hooks Class Initialized
DEBUG - 2023-07-01 08:52:43 --> UTF-8 Support Enabled
INFO - 2023-07-01 08:52:43 --> Utf8 Class Initialized
INFO - 2023-07-01 08:52:43 --> URI Class Initialized
INFO - 2023-07-01 08:52:43 --> Router Class Initialized
INFO - 2023-07-01 08:52:43 --> Output Class Initialized
INFO - 2023-07-01 08:52:43 --> Security Class Initialized
DEBUG - 2023-07-01 08:52:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-01 08:52:43 --> Input Class Initialized
INFO - 2023-07-01 08:52:43 --> Language Class Initialized
INFO - 2023-07-01 08:52:43 --> Loader Class Initialized
INFO - 2023-07-01 08:52:43 --> Helper loaded: url_helper
INFO - 2023-07-01 08:52:43 --> Helper loaded: file_helper
INFO - 2023-07-01 08:52:43 --> Helper loaded: html_helper
INFO - 2023-07-01 08:52:43 --> Helper loaded: text_helper
INFO - 2023-07-01 08:52:43 --> Helper loaded: form_helper
INFO - 2023-07-01 08:52:43 --> Helper loaded: lang_helper
INFO - 2023-07-01 08:52:43 --> Helper loaded: security_helper
INFO - 2023-07-01 08:52:43 --> Helper loaded: cookie_helper
INFO - 2023-07-01 08:52:43 --> Database Driver Class Initialized
INFO - 2023-07-01 08:52:43 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-01 08:52:43 --> Parser Class Initialized
INFO - 2023-07-01 08:52:43 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-01 08:52:43 --> Pagination Class Initialized
INFO - 2023-07-01 08:52:43 --> Form Validation Class Initialized
INFO - 2023-07-01 08:52:43 --> Controller Class Initialized
INFO - 2023-07-01 08:52:43 --> Model Class Initialized
DEBUG - 2023-07-01 08:52:43 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-01 08:52:43 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-01 08:52:43 --> Model Class Initialized
DEBUG - 2023-07-01 08:52:43 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-01 08:52:43 --> Model Class Initialized
INFO - 2023-07-01 08:52:43 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice.php
DEBUG - 2023-07-01 08:52:43 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-07-01 08:52:43 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-07-01 08:52:43 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-07-01 08:52:43 --> Model Class Initialized
INFO - 2023-07-01 08:52:43 --> Model Class Initialized
INFO - 2023-07-01 08:52:43 --> Model Class Initialized
INFO - 2023-07-01 08:52:43 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-07-01 08:52:43 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-07-01 08:52:43 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-07-01 08:52:43 --> Final output sent to browser
DEBUG - 2023-07-01 08:52:43 --> Total execution time: 0.0731
ERROR - 2023-07-01 08:52:43 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-01 08:52:43 --> Config Class Initialized
INFO - 2023-07-01 08:52:43 --> Hooks Class Initialized
DEBUG - 2023-07-01 08:52:43 --> UTF-8 Support Enabled
INFO - 2023-07-01 08:52:43 --> Utf8 Class Initialized
INFO - 2023-07-01 08:52:43 --> URI Class Initialized
INFO - 2023-07-01 08:52:43 --> Router Class Initialized
INFO - 2023-07-01 08:52:43 --> Output Class Initialized
INFO - 2023-07-01 08:52:43 --> Security Class Initialized
DEBUG - 2023-07-01 08:52:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-01 08:52:43 --> Input Class Initialized
INFO - 2023-07-01 08:52:43 --> Language Class Initialized
INFO - 2023-07-01 08:52:43 --> Loader Class Initialized
INFO - 2023-07-01 08:52:43 --> Helper loaded: url_helper
INFO - 2023-07-01 08:52:43 --> Helper loaded: file_helper
INFO - 2023-07-01 08:52:43 --> Helper loaded: html_helper
INFO - 2023-07-01 08:52:43 --> Helper loaded: text_helper
INFO - 2023-07-01 08:52:43 --> Helper loaded: form_helper
INFO - 2023-07-01 08:52:43 --> Helper loaded: lang_helper
INFO - 2023-07-01 08:52:43 --> Helper loaded: security_helper
INFO - 2023-07-01 08:52:43 --> Helper loaded: cookie_helper
INFO - 2023-07-01 08:52:43 --> Database Driver Class Initialized
INFO - 2023-07-01 08:52:43 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-01 08:52:43 --> Parser Class Initialized
INFO - 2023-07-01 08:52:43 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-01 08:52:43 --> Pagination Class Initialized
INFO - 2023-07-01 08:52:43 --> Form Validation Class Initialized
INFO - 2023-07-01 08:52:43 --> Controller Class Initialized
INFO - 2023-07-01 08:52:43 --> Model Class Initialized
DEBUG - 2023-07-01 08:52:43 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-01 08:52:43 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-01 08:52:43 --> Model Class Initialized
DEBUG - 2023-07-01 08:52:43 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-01 08:52:43 --> Model Class Initialized
INFO - 2023-07-01 08:52:43 --> Final output sent to browser
DEBUG - 2023-07-01 08:52:43 --> Total execution time: 0.0374
ERROR - 2023-07-01 08:52:48 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-01 08:52:48 --> Config Class Initialized
INFO - 2023-07-01 08:52:48 --> Hooks Class Initialized
DEBUG - 2023-07-01 08:52:48 --> UTF-8 Support Enabled
INFO - 2023-07-01 08:52:48 --> Utf8 Class Initialized
INFO - 2023-07-01 08:52:48 --> URI Class Initialized
INFO - 2023-07-01 08:52:48 --> Router Class Initialized
INFO - 2023-07-01 08:52:48 --> Output Class Initialized
INFO - 2023-07-01 08:52:48 --> Security Class Initialized
DEBUG - 2023-07-01 08:52:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-01 08:52:48 --> Input Class Initialized
INFO - 2023-07-01 08:52:48 --> Language Class Initialized
INFO - 2023-07-01 08:52:48 --> Loader Class Initialized
INFO - 2023-07-01 08:52:48 --> Helper loaded: url_helper
INFO - 2023-07-01 08:52:48 --> Helper loaded: file_helper
INFO - 2023-07-01 08:52:48 --> Helper loaded: html_helper
INFO - 2023-07-01 08:52:48 --> Helper loaded: text_helper
INFO - 2023-07-01 08:52:48 --> Helper loaded: form_helper
INFO - 2023-07-01 08:52:48 --> Helper loaded: lang_helper
INFO - 2023-07-01 08:52:48 --> Helper loaded: security_helper
INFO - 2023-07-01 08:52:48 --> Helper loaded: cookie_helper
INFO - 2023-07-01 08:52:48 --> Database Driver Class Initialized
INFO - 2023-07-01 08:52:48 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-01 08:52:48 --> Parser Class Initialized
INFO - 2023-07-01 08:52:48 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-01 08:52:48 --> Pagination Class Initialized
INFO - 2023-07-01 08:52:48 --> Form Validation Class Initialized
INFO - 2023-07-01 08:52:48 --> Controller Class Initialized
INFO - 2023-07-01 08:52:48 --> Model Class Initialized
DEBUG - 2023-07-01 08:52:48 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-01 08:52:48 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-01 08:52:48 --> Model Class Initialized
DEBUG - 2023-07-01 08:52:48 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-01 08:52:48 --> Model Class Initialized
DEBUG - 2023-07-01 08:52:48 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-01 08:52:48 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice_html.php
DEBUG - 2023-07-01 08:52:48 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-07-01 08:52:48 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-07-01 08:52:48 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-07-01 08:52:48 --> Model Class Initialized
INFO - 2023-07-01 08:52:48 --> Model Class Initialized
INFO - 2023-07-01 08:52:48 --> Model Class Initialized
INFO - 2023-07-01 08:52:48 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-07-01 08:52:48 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-07-01 08:52:48 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-07-01 08:52:48 --> Final output sent to browser
DEBUG - 2023-07-01 08:52:48 --> Total execution time: 0.0853
ERROR - 2023-07-01 08:53:02 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-01 08:53:02 --> Config Class Initialized
INFO - 2023-07-01 08:53:02 --> Hooks Class Initialized
DEBUG - 2023-07-01 08:53:02 --> UTF-8 Support Enabled
INFO - 2023-07-01 08:53:02 --> Utf8 Class Initialized
INFO - 2023-07-01 08:53:02 --> URI Class Initialized
DEBUG - 2023-07-01 08:53:02 --> No URI present. Default controller set.
INFO - 2023-07-01 08:53:02 --> Router Class Initialized
INFO - 2023-07-01 08:53:02 --> Output Class Initialized
INFO - 2023-07-01 08:53:02 --> Security Class Initialized
DEBUG - 2023-07-01 08:53:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-01 08:53:02 --> Input Class Initialized
INFO - 2023-07-01 08:53:02 --> Language Class Initialized
INFO - 2023-07-01 08:53:02 --> Loader Class Initialized
INFO - 2023-07-01 08:53:02 --> Helper loaded: url_helper
INFO - 2023-07-01 08:53:02 --> Helper loaded: file_helper
INFO - 2023-07-01 08:53:02 --> Helper loaded: html_helper
INFO - 2023-07-01 08:53:02 --> Helper loaded: text_helper
INFO - 2023-07-01 08:53:02 --> Helper loaded: form_helper
INFO - 2023-07-01 08:53:02 --> Helper loaded: lang_helper
INFO - 2023-07-01 08:53:02 --> Helper loaded: security_helper
INFO - 2023-07-01 08:53:02 --> Helper loaded: cookie_helper
INFO - 2023-07-01 08:53:02 --> Database Driver Class Initialized
INFO - 2023-07-01 08:53:02 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-01 08:53:02 --> Parser Class Initialized
INFO - 2023-07-01 08:53:02 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-01 08:53:02 --> Pagination Class Initialized
INFO - 2023-07-01 08:53:02 --> Form Validation Class Initialized
INFO - 2023-07-01 08:53:02 --> Controller Class Initialized
INFO - 2023-07-01 08:53:02 --> Model Class Initialized
DEBUG - 2023-07-01 08:53:02 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-01 08:53:02 --> Model Class Initialized
DEBUG - 2023-07-01 08:53:02 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-01 08:53:02 --> Model Class Initialized
INFO - 2023-07-01 08:53:02 --> Model Class Initialized
INFO - 2023-07-01 08:53:02 --> Model Class Initialized
INFO - 2023-07-01 08:53:02 --> Model Class Initialized
DEBUG - 2023-07-01 08:53:02 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-01 08:53:02 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-01 08:53:02 --> Model Class Initialized
INFO - 2023-07-01 08:53:02 --> Model Class Initialized
INFO - 2023-07-01 08:53:02 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-07-01 08:53:02 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-07-01 08:53:02 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-07-01 08:53:02 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-07-01 08:53:02 --> Model Class Initialized
INFO - 2023-07-01 08:53:02 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-07-01 08:53:02 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-07-01 08:53:02 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-07-01 08:53:02 --> Final output sent to browser
DEBUG - 2023-07-01 08:53:02 --> Total execution time: 0.0816
ERROR - 2023-07-01 08:53:50 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-01 08:53:50 --> Config Class Initialized
INFO - 2023-07-01 08:53:50 --> Hooks Class Initialized
DEBUG - 2023-07-01 08:53:50 --> UTF-8 Support Enabled
INFO - 2023-07-01 08:53:50 --> Utf8 Class Initialized
INFO - 2023-07-01 08:53:50 --> URI Class Initialized
INFO - 2023-07-01 08:53:50 --> Router Class Initialized
INFO - 2023-07-01 08:53:50 --> Output Class Initialized
INFO - 2023-07-01 08:53:50 --> Security Class Initialized
DEBUG - 2023-07-01 08:53:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-01 08:53:50 --> Input Class Initialized
INFO - 2023-07-01 08:53:50 --> Language Class Initialized
INFO - 2023-07-01 08:53:50 --> Loader Class Initialized
INFO - 2023-07-01 08:53:50 --> Helper loaded: url_helper
INFO - 2023-07-01 08:53:50 --> Helper loaded: file_helper
INFO - 2023-07-01 08:53:50 --> Helper loaded: html_helper
INFO - 2023-07-01 08:53:50 --> Helper loaded: text_helper
INFO - 2023-07-01 08:53:50 --> Helper loaded: form_helper
INFO - 2023-07-01 08:53:50 --> Helper loaded: lang_helper
INFO - 2023-07-01 08:53:50 --> Helper loaded: security_helper
INFO - 2023-07-01 08:53:50 --> Helper loaded: cookie_helper
INFO - 2023-07-01 08:53:50 --> Database Driver Class Initialized
INFO - 2023-07-01 08:53:50 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-01 08:53:50 --> Parser Class Initialized
INFO - 2023-07-01 08:53:50 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-01 08:53:50 --> Pagination Class Initialized
INFO - 2023-07-01 08:53:50 --> Form Validation Class Initialized
INFO - 2023-07-01 08:53:50 --> Controller Class Initialized
INFO - 2023-07-01 08:53:50 --> Model Class Initialized
DEBUG - 2023-07-01 08:53:50 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-01 08:53:50 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-01 08:53:50 --> Model Class Initialized
DEBUG - 2023-07-01 08:53:50 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-01 08:53:50 --> Model Class Initialized
INFO - 2023-07-01 08:53:50 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice.php
DEBUG - 2023-07-01 08:53:50 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-07-01 08:53:50 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-07-01 08:53:50 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-07-01 08:53:50 --> Model Class Initialized
INFO - 2023-07-01 08:53:50 --> Model Class Initialized
INFO - 2023-07-01 08:53:50 --> Model Class Initialized
INFO - 2023-07-01 08:53:50 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-07-01 08:53:50 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-07-01 08:53:50 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-07-01 08:53:50 --> Final output sent to browser
DEBUG - 2023-07-01 08:53:50 --> Total execution time: 0.0704
ERROR - 2023-07-01 08:53:50 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-01 08:53:50 --> Config Class Initialized
INFO - 2023-07-01 08:53:50 --> Hooks Class Initialized
DEBUG - 2023-07-01 08:53:50 --> UTF-8 Support Enabled
INFO - 2023-07-01 08:53:50 --> Utf8 Class Initialized
INFO - 2023-07-01 08:53:50 --> URI Class Initialized
INFO - 2023-07-01 08:53:50 --> Router Class Initialized
INFO - 2023-07-01 08:53:50 --> Output Class Initialized
INFO - 2023-07-01 08:53:50 --> Security Class Initialized
DEBUG - 2023-07-01 08:53:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-01 08:53:50 --> Input Class Initialized
INFO - 2023-07-01 08:53:50 --> Language Class Initialized
INFO - 2023-07-01 08:53:50 --> Loader Class Initialized
INFO - 2023-07-01 08:53:50 --> Helper loaded: url_helper
INFO - 2023-07-01 08:53:50 --> Helper loaded: file_helper
INFO - 2023-07-01 08:53:50 --> Helper loaded: html_helper
INFO - 2023-07-01 08:53:50 --> Helper loaded: text_helper
INFO - 2023-07-01 08:53:50 --> Helper loaded: form_helper
INFO - 2023-07-01 08:53:50 --> Helper loaded: lang_helper
INFO - 2023-07-01 08:53:50 --> Helper loaded: security_helper
INFO - 2023-07-01 08:53:50 --> Helper loaded: cookie_helper
INFO - 2023-07-01 08:53:50 --> Database Driver Class Initialized
INFO - 2023-07-01 08:53:50 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-01 08:53:50 --> Parser Class Initialized
INFO - 2023-07-01 08:53:50 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-01 08:53:50 --> Pagination Class Initialized
INFO - 2023-07-01 08:53:50 --> Form Validation Class Initialized
INFO - 2023-07-01 08:53:50 --> Controller Class Initialized
INFO - 2023-07-01 08:53:50 --> Model Class Initialized
DEBUG - 2023-07-01 08:53:50 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-01 08:53:50 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-01 08:53:50 --> Model Class Initialized
DEBUG - 2023-07-01 08:53:50 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-01 08:53:50 --> Model Class Initialized
INFO - 2023-07-01 08:53:50 --> Final output sent to browser
DEBUG - 2023-07-01 08:53:50 --> Total execution time: 0.0359
ERROR - 2023-07-01 09:46:48 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-01 09:46:48 --> Config Class Initialized
INFO - 2023-07-01 09:46:48 --> Hooks Class Initialized
DEBUG - 2023-07-01 09:46:48 --> UTF-8 Support Enabled
INFO - 2023-07-01 09:46:48 --> Utf8 Class Initialized
INFO - 2023-07-01 09:46:48 --> URI Class Initialized
DEBUG - 2023-07-01 09:46:48 --> No URI present. Default controller set.
INFO - 2023-07-01 09:46:48 --> Router Class Initialized
INFO - 2023-07-01 09:46:48 --> Output Class Initialized
INFO - 2023-07-01 09:46:48 --> Security Class Initialized
DEBUG - 2023-07-01 09:46:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-01 09:46:48 --> Input Class Initialized
INFO - 2023-07-01 09:46:48 --> Language Class Initialized
INFO - 2023-07-01 09:46:48 --> Loader Class Initialized
INFO - 2023-07-01 09:46:48 --> Helper loaded: url_helper
INFO - 2023-07-01 09:46:48 --> Helper loaded: file_helper
INFO - 2023-07-01 09:46:48 --> Helper loaded: html_helper
INFO - 2023-07-01 09:46:48 --> Helper loaded: text_helper
INFO - 2023-07-01 09:46:48 --> Helper loaded: form_helper
INFO - 2023-07-01 09:46:48 --> Helper loaded: lang_helper
INFO - 2023-07-01 09:46:48 --> Helper loaded: security_helper
INFO - 2023-07-01 09:46:48 --> Helper loaded: cookie_helper
INFO - 2023-07-01 09:46:48 --> Database Driver Class Initialized
INFO - 2023-07-01 09:46:48 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-01 09:46:48 --> Parser Class Initialized
INFO - 2023-07-01 09:46:48 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-01 09:46:48 --> Pagination Class Initialized
INFO - 2023-07-01 09:46:48 --> Form Validation Class Initialized
INFO - 2023-07-01 09:46:48 --> Controller Class Initialized
INFO - 2023-07-01 09:46:48 --> Model Class Initialized
DEBUG - 2023-07-01 09:46:48 --> Session class already loaded. Second attempt ignored.
ERROR - 2023-07-01 09:46:48 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-01 09:46:48 --> Config Class Initialized
INFO - 2023-07-01 09:46:48 --> Hooks Class Initialized
DEBUG - 2023-07-01 09:46:48 --> UTF-8 Support Enabled
INFO - 2023-07-01 09:46:48 --> Utf8 Class Initialized
INFO - 2023-07-01 09:46:48 --> URI Class Initialized
INFO - 2023-07-01 09:46:48 --> Router Class Initialized
INFO - 2023-07-01 09:46:48 --> Output Class Initialized
INFO - 2023-07-01 09:46:48 --> Security Class Initialized
DEBUG - 2023-07-01 09:46:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-01 09:46:48 --> Input Class Initialized
INFO - 2023-07-01 09:46:48 --> Language Class Initialized
INFO - 2023-07-01 09:46:48 --> Loader Class Initialized
INFO - 2023-07-01 09:46:48 --> Helper loaded: url_helper
INFO - 2023-07-01 09:46:48 --> Helper loaded: file_helper
INFO - 2023-07-01 09:46:48 --> Helper loaded: html_helper
INFO - 2023-07-01 09:46:48 --> Helper loaded: text_helper
INFO - 2023-07-01 09:46:48 --> Helper loaded: form_helper
INFO - 2023-07-01 09:46:48 --> Helper loaded: lang_helper
INFO - 2023-07-01 09:46:48 --> Helper loaded: security_helper
INFO - 2023-07-01 09:46:48 --> Helper loaded: cookie_helper
INFO - 2023-07-01 09:46:48 --> Database Driver Class Initialized
INFO - 2023-07-01 09:46:48 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-01 09:46:48 --> Parser Class Initialized
INFO - 2023-07-01 09:46:48 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-01 09:46:48 --> Pagination Class Initialized
INFO - 2023-07-01 09:46:48 --> Form Validation Class Initialized
INFO - 2023-07-01 09:46:48 --> Controller Class Initialized
INFO - 2023-07-01 09:46:48 --> Model Class Initialized
DEBUG - 2023-07-01 09:46:48 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-01 09:46:49 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2023-07-01 09:46:49 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-07-01 09:46:49 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-07-01 09:46:49 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-07-01 09:46:49 --> Model Class Initialized
INFO - 2023-07-01 09:46:49 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-07-01 09:46:49 --> Final output sent to browser
DEBUG - 2023-07-01 09:46:49 --> Total execution time: 0.0304
ERROR - 2023-07-01 09:47:02 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-01 09:47:02 --> Config Class Initialized
INFO - 2023-07-01 09:47:02 --> Hooks Class Initialized
DEBUG - 2023-07-01 09:47:02 --> UTF-8 Support Enabled
INFO - 2023-07-01 09:47:02 --> Utf8 Class Initialized
INFO - 2023-07-01 09:47:02 --> URI Class Initialized
DEBUG - 2023-07-01 09:47:02 --> No URI present. Default controller set.
INFO - 2023-07-01 09:47:02 --> Router Class Initialized
INFO - 2023-07-01 09:47:02 --> Output Class Initialized
INFO - 2023-07-01 09:47:02 --> Security Class Initialized
DEBUG - 2023-07-01 09:47:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-01 09:47:02 --> Input Class Initialized
INFO - 2023-07-01 09:47:02 --> Language Class Initialized
INFO - 2023-07-01 09:47:02 --> Loader Class Initialized
INFO - 2023-07-01 09:47:02 --> Helper loaded: url_helper
INFO - 2023-07-01 09:47:02 --> Helper loaded: file_helper
INFO - 2023-07-01 09:47:02 --> Helper loaded: html_helper
INFO - 2023-07-01 09:47:02 --> Helper loaded: text_helper
INFO - 2023-07-01 09:47:02 --> Helper loaded: form_helper
INFO - 2023-07-01 09:47:02 --> Helper loaded: lang_helper
INFO - 2023-07-01 09:47:02 --> Helper loaded: security_helper
INFO - 2023-07-01 09:47:02 --> Helper loaded: cookie_helper
INFO - 2023-07-01 09:47:02 --> Database Driver Class Initialized
INFO - 2023-07-01 09:47:02 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-01 09:47:02 --> Parser Class Initialized
INFO - 2023-07-01 09:47:02 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-01 09:47:02 --> Pagination Class Initialized
INFO - 2023-07-01 09:47:02 --> Form Validation Class Initialized
INFO - 2023-07-01 09:47:02 --> Controller Class Initialized
INFO - 2023-07-01 09:47:02 --> Model Class Initialized
DEBUG - 2023-07-01 09:47:02 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-01 09:47:02 --> Model Class Initialized
DEBUG - 2023-07-01 09:47:02 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-01 09:47:02 --> Model Class Initialized
INFO - 2023-07-01 09:47:02 --> Model Class Initialized
INFO - 2023-07-01 09:47:02 --> Model Class Initialized
INFO - 2023-07-01 09:47:02 --> Model Class Initialized
DEBUG - 2023-07-01 09:47:02 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-01 09:47:02 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-01 09:47:02 --> Model Class Initialized
INFO - 2023-07-01 09:47:02 --> Model Class Initialized
INFO - 2023-07-01 09:47:02 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-07-01 09:47:02 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-07-01 09:47:02 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-07-01 09:47:02 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-07-01 09:47:02 --> Model Class Initialized
INFO - 2023-07-01 09:47:02 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-07-01 09:47:02 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-07-01 09:47:02 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-07-01 09:47:02 --> Final output sent to browser
DEBUG - 2023-07-01 09:47:02 --> Total execution time: 0.0842
ERROR - 2023-07-01 09:47:15 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-01 09:47:15 --> Config Class Initialized
INFO - 2023-07-01 09:47:15 --> Hooks Class Initialized
DEBUG - 2023-07-01 09:47:15 --> UTF-8 Support Enabled
INFO - 2023-07-01 09:47:15 --> Utf8 Class Initialized
INFO - 2023-07-01 09:47:15 --> URI Class Initialized
INFO - 2023-07-01 09:47:15 --> Router Class Initialized
INFO - 2023-07-01 09:47:15 --> Output Class Initialized
INFO - 2023-07-01 09:47:15 --> Security Class Initialized
DEBUG - 2023-07-01 09:47:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-01 09:47:15 --> Input Class Initialized
INFO - 2023-07-01 09:47:15 --> Language Class Initialized
INFO - 2023-07-01 09:47:15 --> Loader Class Initialized
INFO - 2023-07-01 09:47:15 --> Helper loaded: url_helper
INFO - 2023-07-01 09:47:15 --> Helper loaded: file_helper
INFO - 2023-07-01 09:47:15 --> Helper loaded: html_helper
INFO - 2023-07-01 09:47:15 --> Helper loaded: text_helper
INFO - 2023-07-01 09:47:15 --> Helper loaded: form_helper
INFO - 2023-07-01 09:47:15 --> Helper loaded: lang_helper
INFO - 2023-07-01 09:47:15 --> Helper loaded: security_helper
INFO - 2023-07-01 09:47:15 --> Helper loaded: cookie_helper
INFO - 2023-07-01 09:47:15 --> Database Driver Class Initialized
INFO - 2023-07-01 09:47:15 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-01 09:47:15 --> Parser Class Initialized
INFO - 2023-07-01 09:47:15 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-01 09:47:15 --> Pagination Class Initialized
INFO - 2023-07-01 09:47:15 --> Form Validation Class Initialized
INFO - 2023-07-01 09:47:15 --> Controller Class Initialized
INFO - 2023-07-01 09:47:15 --> Model Class Initialized
DEBUG - 2023-07-01 09:47:15 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-01 09:47:15 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-01 09:47:15 --> Model Class Initialized
DEBUG - 2023-07-01 09:47:15 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-01 09:47:15 --> Model Class Initialized
INFO - 2023-07-01 09:47:15 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice.php
DEBUG - 2023-07-01 09:47:15 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-07-01 09:47:15 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-07-01 09:47:15 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-07-01 09:47:15 --> Model Class Initialized
INFO - 2023-07-01 09:47:15 --> Model Class Initialized
INFO - 2023-07-01 09:47:15 --> Model Class Initialized
INFO - 2023-07-01 09:47:15 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-07-01 09:47:15 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-07-01 09:47:15 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-07-01 09:47:15 --> Final output sent to browser
DEBUG - 2023-07-01 09:47:15 --> Total execution time: 0.0971
ERROR - 2023-07-01 09:47:15 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-01 09:47:15 --> Config Class Initialized
INFO - 2023-07-01 09:47:15 --> Hooks Class Initialized
DEBUG - 2023-07-01 09:47:15 --> UTF-8 Support Enabled
INFO - 2023-07-01 09:47:15 --> Utf8 Class Initialized
INFO - 2023-07-01 09:47:15 --> URI Class Initialized
INFO - 2023-07-01 09:47:15 --> Router Class Initialized
INFO - 2023-07-01 09:47:15 --> Output Class Initialized
INFO - 2023-07-01 09:47:15 --> Security Class Initialized
DEBUG - 2023-07-01 09:47:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-01 09:47:15 --> Input Class Initialized
INFO - 2023-07-01 09:47:15 --> Language Class Initialized
INFO - 2023-07-01 09:47:15 --> Loader Class Initialized
INFO - 2023-07-01 09:47:15 --> Helper loaded: url_helper
INFO - 2023-07-01 09:47:15 --> Helper loaded: file_helper
INFO - 2023-07-01 09:47:15 --> Helper loaded: html_helper
INFO - 2023-07-01 09:47:15 --> Helper loaded: text_helper
INFO - 2023-07-01 09:47:15 --> Helper loaded: form_helper
INFO - 2023-07-01 09:47:15 --> Helper loaded: lang_helper
INFO - 2023-07-01 09:47:15 --> Helper loaded: security_helper
INFO - 2023-07-01 09:47:15 --> Helper loaded: cookie_helper
INFO - 2023-07-01 09:47:15 --> Database Driver Class Initialized
INFO - 2023-07-01 09:47:15 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-01 09:47:15 --> Parser Class Initialized
INFO - 2023-07-01 09:47:15 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-01 09:47:15 --> Pagination Class Initialized
INFO - 2023-07-01 09:47:15 --> Form Validation Class Initialized
INFO - 2023-07-01 09:47:15 --> Controller Class Initialized
INFO - 2023-07-01 09:47:15 --> Model Class Initialized
DEBUG - 2023-07-01 09:47:15 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-01 09:47:15 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-01 09:47:15 --> Model Class Initialized
DEBUG - 2023-07-01 09:47:15 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-01 09:47:15 --> Model Class Initialized
INFO - 2023-07-01 09:47:15 --> Final output sent to browser
DEBUG - 2023-07-01 09:47:15 --> Total execution time: 0.0456
ERROR - 2023-07-01 09:47:22 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-01 09:47:22 --> Config Class Initialized
INFO - 2023-07-01 09:47:22 --> Hooks Class Initialized
DEBUG - 2023-07-01 09:47:22 --> UTF-8 Support Enabled
INFO - 2023-07-01 09:47:22 --> Utf8 Class Initialized
INFO - 2023-07-01 09:47:22 --> URI Class Initialized
INFO - 2023-07-01 09:47:22 --> Router Class Initialized
INFO - 2023-07-01 09:47:22 --> Output Class Initialized
INFO - 2023-07-01 09:47:22 --> Security Class Initialized
DEBUG - 2023-07-01 09:47:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-01 09:47:22 --> Input Class Initialized
INFO - 2023-07-01 09:47:22 --> Language Class Initialized
INFO - 2023-07-01 09:47:22 --> Loader Class Initialized
INFO - 2023-07-01 09:47:22 --> Helper loaded: url_helper
INFO - 2023-07-01 09:47:22 --> Helper loaded: file_helper
INFO - 2023-07-01 09:47:22 --> Helper loaded: html_helper
INFO - 2023-07-01 09:47:22 --> Helper loaded: text_helper
INFO - 2023-07-01 09:47:22 --> Helper loaded: form_helper
INFO - 2023-07-01 09:47:22 --> Helper loaded: lang_helper
INFO - 2023-07-01 09:47:22 --> Helper loaded: security_helper
INFO - 2023-07-01 09:47:22 --> Helper loaded: cookie_helper
INFO - 2023-07-01 09:47:22 --> Database Driver Class Initialized
INFO - 2023-07-01 09:47:22 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-01 09:47:22 --> Parser Class Initialized
INFO - 2023-07-01 09:47:22 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-01 09:47:22 --> Pagination Class Initialized
INFO - 2023-07-01 09:47:22 --> Form Validation Class Initialized
INFO - 2023-07-01 09:47:22 --> Controller Class Initialized
INFO - 2023-07-01 09:47:22 --> Model Class Initialized
DEBUG - 2023-07-01 09:47:22 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-01 09:47:22 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-01 09:47:22 --> Model Class Initialized
DEBUG - 2023-07-01 09:47:22 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-01 09:47:22 --> Model Class Initialized
INFO - 2023-07-01 09:47:22 --> Final output sent to browser
DEBUG - 2023-07-01 09:47:22 --> Total execution time: 0.1634
ERROR - 2023-07-01 11:13:20 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-01 11:13:20 --> Config Class Initialized
INFO - 2023-07-01 11:13:20 --> Hooks Class Initialized
DEBUG - 2023-07-01 11:13:20 --> UTF-8 Support Enabled
INFO - 2023-07-01 11:13:20 --> Utf8 Class Initialized
INFO - 2023-07-01 11:13:20 --> URI Class Initialized
DEBUG - 2023-07-01 11:13:20 --> No URI present. Default controller set.
INFO - 2023-07-01 11:13:20 --> Router Class Initialized
INFO - 2023-07-01 11:13:20 --> Output Class Initialized
INFO - 2023-07-01 11:13:20 --> Security Class Initialized
DEBUG - 2023-07-01 11:13:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-01 11:13:20 --> Input Class Initialized
INFO - 2023-07-01 11:13:20 --> Language Class Initialized
INFO - 2023-07-01 11:13:20 --> Loader Class Initialized
INFO - 2023-07-01 11:13:20 --> Helper loaded: url_helper
INFO - 2023-07-01 11:13:20 --> Helper loaded: file_helper
INFO - 2023-07-01 11:13:20 --> Helper loaded: html_helper
INFO - 2023-07-01 11:13:20 --> Helper loaded: text_helper
INFO - 2023-07-01 11:13:20 --> Helper loaded: form_helper
INFO - 2023-07-01 11:13:20 --> Helper loaded: lang_helper
INFO - 2023-07-01 11:13:20 --> Helper loaded: security_helper
INFO - 2023-07-01 11:13:20 --> Helper loaded: cookie_helper
INFO - 2023-07-01 11:13:20 --> Database Driver Class Initialized
INFO - 2023-07-01 11:13:20 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-01 11:13:20 --> Parser Class Initialized
INFO - 2023-07-01 11:13:20 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-01 11:13:20 --> Pagination Class Initialized
INFO - 2023-07-01 11:13:20 --> Form Validation Class Initialized
INFO - 2023-07-01 11:13:20 --> Controller Class Initialized
INFO - 2023-07-01 11:13:20 --> Model Class Initialized
DEBUG - 2023-07-01 11:13:20 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-01 11:13:20 --> Model Class Initialized
DEBUG - 2023-07-01 11:13:20 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-01 11:13:20 --> Model Class Initialized
INFO - 2023-07-01 11:13:20 --> Model Class Initialized
INFO - 2023-07-01 11:13:20 --> Model Class Initialized
INFO - 2023-07-01 11:13:20 --> Model Class Initialized
DEBUG - 2023-07-01 11:13:20 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-01 11:13:20 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-01 11:13:20 --> Model Class Initialized
INFO - 2023-07-01 11:13:20 --> Model Class Initialized
INFO - 2023-07-01 11:13:20 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-07-01 11:13:20 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-07-01 11:13:20 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-07-01 11:13:20 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-07-01 11:13:20 --> Model Class Initialized
INFO - 2023-07-01 11:13:20 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-07-01 11:13:20 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-07-01 11:13:20 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-07-01 11:13:20 --> Final output sent to browser
DEBUG - 2023-07-01 11:13:20 --> Total execution time: 0.0940
ERROR - 2023-07-01 11:13:23 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-01 11:13:23 --> Config Class Initialized
INFO - 2023-07-01 11:13:23 --> Hooks Class Initialized
DEBUG - 2023-07-01 11:13:23 --> UTF-8 Support Enabled
INFO - 2023-07-01 11:13:23 --> Utf8 Class Initialized
INFO - 2023-07-01 11:13:23 --> URI Class Initialized
DEBUG - 2023-07-01 11:13:23 --> No URI present. Default controller set.
INFO - 2023-07-01 11:13:23 --> Router Class Initialized
INFO - 2023-07-01 11:13:23 --> Output Class Initialized
INFO - 2023-07-01 11:13:23 --> Security Class Initialized
DEBUG - 2023-07-01 11:13:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-01 11:13:23 --> Input Class Initialized
INFO - 2023-07-01 11:13:23 --> Language Class Initialized
INFO - 2023-07-01 11:13:23 --> Loader Class Initialized
INFO - 2023-07-01 11:13:23 --> Helper loaded: url_helper
INFO - 2023-07-01 11:13:23 --> Helper loaded: file_helper
INFO - 2023-07-01 11:13:23 --> Helper loaded: html_helper
INFO - 2023-07-01 11:13:23 --> Helper loaded: text_helper
INFO - 2023-07-01 11:13:23 --> Helper loaded: form_helper
INFO - 2023-07-01 11:13:23 --> Helper loaded: lang_helper
INFO - 2023-07-01 11:13:23 --> Helper loaded: security_helper
INFO - 2023-07-01 11:13:23 --> Helper loaded: cookie_helper
INFO - 2023-07-01 11:13:23 --> Database Driver Class Initialized
INFO - 2023-07-01 11:13:23 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-01 11:13:23 --> Parser Class Initialized
INFO - 2023-07-01 11:13:23 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-01 11:13:23 --> Pagination Class Initialized
INFO - 2023-07-01 11:13:23 --> Form Validation Class Initialized
INFO - 2023-07-01 11:13:23 --> Controller Class Initialized
INFO - 2023-07-01 11:13:23 --> Model Class Initialized
DEBUG - 2023-07-01 11:13:23 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-01 11:13:23 --> Model Class Initialized
DEBUG - 2023-07-01 11:13:23 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-01 11:13:23 --> Model Class Initialized
INFO - 2023-07-01 11:13:23 --> Model Class Initialized
INFO - 2023-07-01 11:13:23 --> Model Class Initialized
INFO - 2023-07-01 11:13:23 --> Model Class Initialized
DEBUG - 2023-07-01 11:13:23 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-01 11:13:23 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-01 11:13:23 --> Model Class Initialized
INFO - 2023-07-01 11:13:23 --> Model Class Initialized
INFO - 2023-07-01 11:13:23 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-07-01 11:13:23 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-07-01 11:13:23 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-07-01 11:13:23 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-07-01 11:13:23 --> Model Class Initialized
INFO - 2023-07-01 11:13:23 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-07-01 11:13:23 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-07-01 11:13:23 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-07-01 11:13:23 --> Final output sent to browser
DEBUG - 2023-07-01 11:13:23 --> Total execution time: 0.0817
ERROR - 2023-07-01 11:13:24 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-01 11:13:24 --> Config Class Initialized
INFO - 2023-07-01 11:13:24 --> Hooks Class Initialized
DEBUG - 2023-07-01 11:13:24 --> UTF-8 Support Enabled
INFO - 2023-07-01 11:13:24 --> Utf8 Class Initialized
INFO - 2023-07-01 11:13:24 --> URI Class Initialized
DEBUG - 2023-07-01 11:13:24 --> No URI present. Default controller set.
INFO - 2023-07-01 11:13:24 --> Router Class Initialized
INFO - 2023-07-01 11:13:24 --> Output Class Initialized
INFO - 2023-07-01 11:13:24 --> Security Class Initialized
DEBUG - 2023-07-01 11:13:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-01 11:13:24 --> Input Class Initialized
INFO - 2023-07-01 11:13:24 --> Language Class Initialized
INFO - 2023-07-01 11:13:24 --> Loader Class Initialized
INFO - 2023-07-01 11:13:24 --> Helper loaded: url_helper
INFO - 2023-07-01 11:13:24 --> Helper loaded: file_helper
INFO - 2023-07-01 11:13:24 --> Helper loaded: html_helper
INFO - 2023-07-01 11:13:24 --> Helper loaded: text_helper
INFO - 2023-07-01 11:13:24 --> Helper loaded: form_helper
INFO - 2023-07-01 11:13:24 --> Helper loaded: lang_helper
INFO - 2023-07-01 11:13:24 --> Helper loaded: security_helper
INFO - 2023-07-01 11:13:24 --> Helper loaded: cookie_helper
INFO - 2023-07-01 11:13:24 --> Database Driver Class Initialized
INFO - 2023-07-01 11:13:24 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-01 11:13:24 --> Parser Class Initialized
INFO - 2023-07-01 11:13:24 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-01 11:13:24 --> Pagination Class Initialized
INFO - 2023-07-01 11:13:24 --> Form Validation Class Initialized
INFO - 2023-07-01 11:13:24 --> Controller Class Initialized
INFO - 2023-07-01 11:13:24 --> Model Class Initialized
DEBUG - 2023-07-01 11:13:24 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-01 11:13:24 --> Model Class Initialized
DEBUG - 2023-07-01 11:13:24 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-01 11:13:24 --> Model Class Initialized
INFO - 2023-07-01 11:13:24 --> Model Class Initialized
INFO - 2023-07-01 11:13:24 --> Model Class Initialized
INFO - 2023-07-01 11:13:24 --> Model Class Initialized
DEBUG - 2023-07-01 11:13:24 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-01 11:13:24 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-01 11:13:24 --> Model Class Initialized
INFO - 2023-07-01 11:13:24 --> Model Class Initialized
INFO - 2023-07-01 11:13:24 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-07-01 11:13:24 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-07-01 11:13:24 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-07-01 11:13:24 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-07-01 11:13:24 --> Model Class Initialized
INFO - 2023-07-01 11:13:24 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-07-01 11:13:24 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-07-01 11:13:24 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-07-01 11:13:24 --> Final output sent to browser
DEBUG - 2023-07-01 11:13:24 --> Total execution time: 0.0805
ERROR - 2023-07-01 11:13:32 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-01 11:13:32 --> Config Class Initialized
INFO - 2023-07-01 11:13:32 --> Hooks Class Initialized
DEBUG - 2023-07-01 11:13:32 --> UTF-8 Support Enabled
INFO - 2023-07-01 11:13:32 --> Utf8 Class Initialized
INFO - 2023-07-01 11:13:32 --> URI Class Initialized
INFO - 2023-07-01 11:13:32 --> Router Class Initialized
INFO - 2023-07-01 11:13:32 --> Output Class Initialized
INFO - 2023-07-01 11:13:32 --> Security Class Initialized
DEBUG - 2023-07-01 11:13:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-01 11:13:32 --> Input Class Initialized
INFO - 2023-07-01 11:13:32 --> Language Class Initialized
INFO - 2023-07-01 11:13:32 --> Loader Class Initialized
INFO - 2023-07-01 11:13:32 --> Helper loaded: url_helper
INFO - 2023-07-01 11:13:32 --> Helper loaded: file_helper
INFO - 2023-07-01 11:13:32 --> Helper loaded: html_helper
INFO - 2023-07-01 11:13:32 --> Helper loaded: text_helper
INFO - 2023-07-01 11:13:32 --> Helper loaded: form_helper
INFO - 2023-07-01 11:13:32 --> Helper loaded: lang_helper
INFO - 2023-07-01 11:13:32 --> Helper loaded: security_helper
INFO - 2023-07-01 11:13:32 --> Helper loaded: cookie_helper
INFO - 2023-07-01 11:13:32 --> Database Driver Class Initialized
INFO - 2023-07-01 11:13:32 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-01 11:13:32 --> Parser Class Initialized
INFO - 2023-07-01 11:13:32 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-01 11:13:32 --> Pagination Class Initialized
INFO - 2023-07-01 11:13:32 --> Form Validation Class Initialized
INFO - 2023-07-01 11:13:32 --> Controller Class Initialized
INFO - 2023-07-01 11:13:32 --> Model Class Initialized
DEBUG - 2023-07-01 11:13:32 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-01 11:13:32 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-01 11:13:32 --> Model Class Initialized
DEBUG - 2023-07-01 11:13:32 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-01 11:13:32 --> Model Class Initialized
INFO - 2023-07-01 11:13:32 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/invoice/invoice.php
DEBUG - 2023-07-01 11:13:32 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-07-01 11:13:32 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-07-01 11:13:32 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-07-01 11:13:32 --> Model Class Initialized
INFO - 2023-07-01 11:13:32 --> Model Class Initialized
INFO - 2023-07-01 11:13:32 --> Model Class Initialized
INFO - 2023-07-01 11:13:32 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-07-01 11:13:32 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-07-01 11:13:32 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-07-01 11:13:32 --> Final output sent to browser
DEBUG - 2023-07-01 11:13:32 --> Total execution time: 0.0766
ERROR - 2023-07-01 11:13:33 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-01 11:13:33 --> Config Class Initialized
INFO - 2023-07-01 11:13:33 --> Hooks Class Initialized
DEBUG - 2023-07-01 11:13:33 --> UTF-8 Support Enabled
INFO - 2023-07-01 11:13:33 --> Utf8 Class Initialized
INFO - 2023-07-01 11:13:33 --> URI Class Initialized
INFO - 2023-07-01 11:13:33 --> Router Class Initialized
INFO - 2023-07-01 11:13:33 --> Output Class Initialized
INFO - 2023-07-01 11:13:33 --> Security Class Initialized
DEBUG - 2023-07-01 11:13:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-01 11:13:33 --> Input Class Initialized
INFO - 2023-07-01 11:13:33 --> Language Class Initialized
INFO - 2023-07-01 11:13:33 --> Loader Class Initialized
INFO - 2023-07-01 11:13:33 --> Helper loaded: url_helper
INFO - 2023-07-01 11:13:33 --> Helper loaded: file_helper
INFO - 2023-07-01 11:13:33 --> Helper loaded: html_helper
INFO - 2023-07-01 11:13:33 --> Helper loaded: text_helper
INFO - 2023-07-01 11:13:33 --> Helper loaded: form_helper
INFO - 2023-07-01 11:13:33 --> Helper loaded: lang_helper
INFO - 2023-07-01 11:13:33 --> Helper loaded: security_helper
INFO - 2023-07-01 11:13:33 --> Helper loaded: cookie_helper
INFO - 2023-07-01 11:13:33 --> Database Driver Class Initialized
INFO - 2023-07-01 11:13:33 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-01 11:13:33 --> Parser Class Initialized
INFO - 2023-07-01 11:13:33 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-01 11:13:33 --> Pagination Class Initialized
INFO - 2023-07-01 11:13:33 --> Form Validation Class Initialized
INFO - 2023-07-01 11:13:33 --> Controller Class Initialized
INFO - 2023-07-01 11:13:33 --> Model Class Initialized
DEBUG - 2023-07-01 11:13:33 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-01 11:13:33 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-01 11:13:33 --> Model Class Initialized
DEBUG - 2023-07-01 11:13:33 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-01 11:13:33 --> Model Class Initialized
INFO - 2023-07-01 11:13:33 --> Final output sent to browser
DEBUG - 2023-07-01 11:13:33 --> Total execution time: 0.0490
ERROR - 2023-07-01 11:14:06 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-01 11:14:06 --> Config Class Initialized
INFO - 2023-07-01 11:14:06 --> Hooks Class Initialized
DEBUG - 2023-07-01 11:14:06 --> UTF-8 Support Enabled
INFO - 2023-07-01 11:14:06 --> Utf8 Class Initialized
INFO - 2023-07-01 11:14:06 --> URI Class Initialized
DEBUG - 2023-07-01 11:14:06 --> No URI present. Default controller set.
INFO - 2023-07-01 11:14:06 --> Router Class Initialized
INFO - 2023-07-01 11:14:06 --> Output Class Initialized
INFO - 2023-07-01 11:14:06 --> Security Class Initialized
DEBUG - 2023-07-01 11:14:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-01 11:14:06 --> Input Class Initialized
INFO - 2023-07-01 11:14:06 --> Language Class Initialized
INFO - 2023-07-01 11:14:06 --> Loader Class Initialized
INFO - 2023-07-01 11:14:06 --> Helper loaded: url_helper
INFO - 2023-07-01 11:14:06 --> Helper loaded: file_helper
INFO - 2023-07-01 11:14:06 --> Helper loaded: html_helper
INFO - 2023-07-01 11:14:06 --> Helper loaded: text_helper
INFO - 2023-07-01 11:14:06 --> Helper loaded: form_helper
INFO - 2023-07-01 11:14:06 --> Helper loaded: lang_helper
INFO - 2023-07-01 11:14:06 --> Helper loaded: security_helper
INFO - 2023-07-01 11:14:06 --> Helper loaded: cookie_helper
INFO - 2023-07-01 11:14:06 --> Database Driver Class Initialized
INFO - 2023-07-01 11:14:06 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-01 11:14:06 --> Parser Class Initialized
INFO - 2023-07-01 11:14:06 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-01 11:14:06 --> Pagination Class Initialized
INFO - 2023-07-01 11:14:06 --> Form Validation Class Initialized
INFO - 2023-07-01 11:14:06 --> Controller Class Initialized
INFO - 2023-07-01 11:14:06 --> Model Class Initialized
DEBUG - 2023-07-01 11:14:06 --> Session class already loaded. Second attempt ignored.
ERROR - 2023-07-01 11:14:07 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-01 11:14:07 --> Config Class Initialized
INFO - 2023-07-01 11:14:07 --> Hooks Class Initialized
DEBUG - 2023-07-01 11:14:07 --> UTF-8 Support Enabled
INFO - 2023-07-01 11:14:07 --> Utf8 Class Initialized
INFO - 2023-07-01 11:14:07 --> URI Class Initialized
INFO - 2023-07-01 11:14:07 --> Router Class Initialized
INFO - 2023-07-01 11:14:07 --> Output Class Initialized
INFO - 2023-07-01 11:14:07 --> Security Class Initialized
DEBUG - 2023-07-01 11:14:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-01 11:14:07 --> Input Class Initialized
INFO - 2023-07-01 11:14:07 --> Language Class Initialized
INFO - 2023-07-01 11:14:07 --> Loader Class Initialized
INFO - 2023-07-01 11:14:07 --> Helper loaded: url_helper
INFO - 2023-07-01 11:14:07 --> Helper loaded: file_helper
INFO - 2023-07-01 11:14:07 --> Helper loaded: html_helper
INFO - 2023-07-01 11:14:07 --> Helper loaded: text_helper
INFO - 2023-07-01 11:14:07 --> Helper loaded: form_helper
INFO - 2023-07-01 11:14:07 --> Helper loaded: lang_helper
INFO - 2023-07-01 11:14:07 --> Helper loaded: security_helper
INFO - 2023-07-01 11:14:07 --> Helper loaded: cookie_helper
INFO - 2023-07-01 11:14:07 --> Database Driver Class Initialized
INFO - 2023-07-01 11:14:07 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-01 11:14:07 --> Parser Class Initialized
INFO - 2023-07-01 11:14:07 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-01 11:14:07 --> Pagination Class Initialized
INFO - 2023-07-01 11:14:07 --> Form Validation Class Initialized
INFO - 2023-07-01 11:14:07 --> Controller Class Initialized
INFO - 2023-07-01 11:14:07 --> Model Class Initialized
DEBUG - 2023-07-01 11:14:07 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-01 11:14:07 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2023-07-01 11:14:07 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-07-01 11:14:07 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-07-01 11:14:07 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-07-01 11:14:07 --> Model Class Initialized
INFO - 2023-07-01 11:14:07 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-07-01 11:14:07 --> Final output sent to browser
DEBUG - 2023-07-01 11:14:07 --> Total execution time: 0.0341
ERROR - 2023-07-01 11:14:10 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-01 11:14:10 --> Config Class Initialized
INFO - 2023-07-01 11:14:10 --> Hooks Class Initialized
DEBUG - 2023-07-01 11:14:10 --> UTF-8 Support Enabled
INFO - 2023-07-01 11:14:10 --> Utf8 Class Initialized
INFO - 2023-07-01 11:14:10 --> URI Class Initialized
INFO - 2023-07-01 11:14:10 --> Router Class Initialized
INFO - 2023-07-01 11:14:10 --> Output Class Initialized
INFO - 2023-07-01 11:14:10 --> Security Class Initialized
DEBUG - 2023-07-01 11:14:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-01 11:14:10 --> Input Class Initialized
INFO - 2023-07-01 11:14:10 --> Language Class Initialized
INFO - 2023-07-01 11:14:10 --> Loader Class Initialized
INFO - 2023-07-01 11:14:10 --> Helper loaded: url_helper
INFO - 2023-07-01 11:14:10 --> Helper loaded: file_helper
INFO - 2023-07-01 11:14:10 --> Helper loaded: html_helper
INFO - 2023-07-01 11:14:10 --> Helper loaded: text_helper
INFO - 2023-07-01 11:14:10 --> Helper loaded: form_helper
INFO - 2023-07-01 11:14:10 --> Helper loaded: lang_helper
INFO - 2023-07-01 11:14:10 --> Helper loaded: security_helper
INFO - 2023-07-01 11:14:10 --> Helper loaded: cookie_helper
INFO - 2023-07-01 11:14:10 --> Database Driver Class Initialized
INFO - 2023-07-01 11:14:10 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-01 11:14:10 --> Parser Class Initialized
INFO - 2023-07-01 11:14:10 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-01 11:14:10 --> Pagination Class Initialized
INFO - 2023-07-01 11:14:10 --> Form Validation Class Initialized
INFO - 2023-07-01 11:14:10 --> Controller Class Initialized
INFO - 2023-07-01 11:14:10 --> Model Class Initialized
DEBUG - 2023-07-01 11:14:10 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-01 11:14:10 --> Model Class Initialized
INFO - 2023-07-01 11:14:10 --> Final output sent to browser
DEBUG - 2023-07-01 11:14:10 --> Total execution time: 0.0179
ERROR - 2023-07-01 11:14:10 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-01 11:14:10 --> Config Class Initialized
INFO - 2023-07-01 11:14:10 --> Hooks Class Initialized
DEBUG - 2023-07-01 11:14:10 --> UTF-8 Support Enabled
INFO - 2023-07-01 11:14:10 --> Utf8 Class Initialized
INFO - 2023-07-01 11:14:10 --> URI Class Initialized
DEBUG - 2023-07-01 11:14:10 --> No URI present. Default controller set.
INFO - 2023-07-01 11:14:10 --> Router Class Initialized
INFO - 2023-07-01 11:14:10 --> Output Class Initialized
INFO - 2023-07-01 11:14:10 --> Security Class Initialized
DEBUG - 2023-07-01 11:14:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-01 11:14:10 --> Input Class Initialized
INFO - 2023-07-01 11:14:10 --> Language Class Initialized
INFO - 2023-07-01 11:14:10 --> Loader Class Initialized
INFO - 2023-07-01 11:14:10 --> Helper loaded: url_helper
INFO - 2023-07-01 11:14:10 --> Helper loaded: file_helper
INFO - 2023-07-01 11:14:10 --> Helper loaded: html_helper
INFO - 2023-07-01 11:14:10 --> Helper loaded: text_helper
INFO - 2023-07-01 11:14:10 --> Helper loaded: form_helper
INFO - 2023-07-01 11:14:10 --> Helper loaded: lang_helper
INFO - 2023-07-01 11:14:10 --> Helper loaded: security_helper
INFO - 2023-07-01 11:14:10 --> Helper loaded: cookie_helper
INFO - 2023-07-01 11:14:10 --> Database Driver Class Initialized
INFO - 2023-07-01 11:14:10 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-01 11:14:10 --> Parser Class Initialized
INFO - 2023-07-01 11:14:10 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-01 11:14:10 --> Pagination Class Initialized
INFO - 2023-07-01 11:14:10 --> Form Validation Class Initialized
INFO - 2023-07-01 11:14:10 --> Controller Class Initialized
INFO - 2023-07-01 11:14:10 --> Model Class Initialized
DEBUG - 2023-07-01 11:14:10 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-01 11:14:10 --> Model Class Initialized
DEBUG - 2023-07-01 11:14:10 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-01 11:14:10 --> Model Class Initialized
INFO - 2023-07-01 11:14:10 --> Model Class Initialized
INFO - 2023-07-01 11:14:10 --> Model Class Initialized
INFO - 2023-07-01 11:14:10 --> Model Class Initialized
DEBUG - 2023-07-01 11:14:10 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-01 11:14:10 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-01 11:14:10 --> Model Class Initialized
INFO - 2023-07-01 11:14:10 --> Model Class Initialized
INFO - 2023-07-01 11:14:10 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-07-01 11:14:10 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-07-01 11:14:10 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-07-01 11:14:10 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-07-01 11:14:10 --> Model Class Initialized
INFO - 2023-07-01 11:14:10 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-07-01 11:14:10 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-07-01 11:14:10 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-07-01 11:14:10 --> Final output sent to browser
DEBUG - 2023-07-01 11:14:10 --> Total execution time: 0.1832
ERROR - 2023-07-01 11:14:11 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-01 11:14:11 --> Config Class Initialized
INFO - 2023-07-01 11:14:11 --> Hooks Class Initialized
DEBUG - 2023-07-01 11:14:11 --> UTF-8 Support Enabled
INFO - 2023-07-01 11:14:11 --> Utf8 Class Initialized
INFO - 2023-07-01 11:14:11 --> URI Class Initialized
INFO - 2023-07-01 11:14:11 --> Router Class Initialized
INFO - 2023-07-01 11:14:11 --> Output Class Initialized
INFO - 2023-07-01 11:14:11 --> Security Class Initialized
DEBUG - 2023-07-01 11:14:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-01 11:14:11 --> Input Class Initialized
INFO - 2023-07-01 11:14:11 --> Language Class Initialized
INFO - 2023-07-01 11:14:11 --> Loader Class Initialized
INFO - 2023-07-01 11:14:11 --> Helper loaded: url_helper
INFO - 2023-07-01 11:14:11 --> Helper loaded: file_helper
INFO - 2023-07-01 11:14:11 --> Helper loaded: html_helper
INFO - 2023-07-01 11:14:11 --> Helper loaded: text_helper
INFO - 2023-07-01 11:14:11 --> Helper loaded: form_helper
INFO - 2023-07-01 11:14:11 --> Helper loaded: lang_helper
INFO - 2023-07-01 11:14:11 --> Helper loaded: security_helper
INFO - 2023-07-01 11:14:11 --> Helper loaded: cookie_helper
INFO - 2023-07-01 11:14:11 --> Database Driver Class Initialized
INFO - 2023-07-01 11:14:11 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-01 11:14:11 --> Parser Class Initialized
INFO - 2023-07-01 11:14:11 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-01 11:14:11 --> Pagination Class Initialized
INFO - 2023-07-01 11:14:11 --> Form Validation Class Initialized
INFO - 2023-07-01 11:14:11 --> Controller Class Initialized
DEBUG - 2023-07-01 11:14:11 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-01 11:14:11 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-01 11:14:11 --> Model Class Initialized
INFO - 2023-07-01 11:14:11 --> Final output sent to browser
DEBUG - 2023-07-01 11:14:11 --> Total execution time: 0.0144
ERROR - 2023-07-01 11:14:25 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-01 11:14:25 --> Config Class Initialized
INFO - 2023-07-01 11:14:25 --> Hooks Class Initialized
DEBUG - 2023-07-01 11:14:25 --> UTF-8 Support Enabled
INFO - 2023-07-01 11:14:25 --> Utf8 Class Initialized
INFO - 2023-07-01 11:14:25 --> URI Class Initialized
INFO - 2023-07-01 11:14:25 --> Router Class Initialized
INFO - 2023-07-01 11:14:25 --> Output Class Initialized
INFO - 2023-07-01 11:14:25 --> Security Class Initialized
DEBUG - 2023-07-01 11:14:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-01 11:14:25 --> Input Class Initialized
INFO - 2023-07-01 11:14:25 --> Language Class Initialized
INFO - 2023-07-01 11:14:25 --> Loader Class Initialized
INFO - 2023-07-01 11:14:25 --> Helper loaded: url_helper
INFO - 2023-07-01 11:14:25 --> Helper loaded: file_helper
INFO - 2023-07-01 11:14:25 --> Helper loaded: html_helper
INFO - 2023-07-01 11:14:25 --> Helper loaded: text_helper
INFO - 2023-07-01 11:14:25 --> Helper loaded: form_helper
INFO - 2023-07-01 11:14:25 --> Helper loaded: lang_helper
INFO - 2023-07-01 11:14:25 --> Helper loaded: security_helper
INFO - 2023-07-01 11:14:25 --> Helper loaded: cookie_helper
INFO - 2023-07-01 11:14:25 --> Database Driver Class Initialized
INFO - 2023-07-01 11:14:25 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-01 11:14:25 --> Parser Class Initialized
INFO - 2023-07-01 11:14:25 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-01 11:14:25 --> Pagination Class Initialized
INFO - 2023-07-01 11:14:25 --> Form Validation Class Initialized
INFO - 2023-07-01 11:14:25 --> Controller Class Initialized
INFO - 2023-07-01 11:14:25 --> Model Class Initialized
DEBUG - 2023-07-01 11:14:25 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-01 11:14:25 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-01 11:14:25 --> Model Class Initialized
DEBUG - 2023-07-01 11:14:25 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-01 11:14:25 --> Model Class Initialized
INFO - 2023-07-01 11:14:25 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice.php
DEBUG - 2023-07-01 11:14:25 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-07-01 11:14:25 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-07-01 11:14:25 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-07-01 11:14:25 --> Model Class Initialized
INFO - 2023-07-01 11:14:25 --> Model Class Initialized
INFO - 2023-07-01 11:14:25 --> Model Class Initialized
INFO - 2023-07-01 11:14:25 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-07-01 11:14:25 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-07-01 11:14:25 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-07-01 11:14:25 --> Final output sent to browser
DEBUG - 2023-07-01 11:14:25 --> Total execution time: 0.1651
ERROR - 2023-07-01 11:14:25 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-01 11:14:25 --> Config Class Initialized
INFO - 2023-07-01 11:14:25 --> Hooks Class Initialized
DEBUG - 2023-07-01 11:14:25 --> UTF-8 Support Enabled
INFO - 2023-07-01 11:14:25 --> Utf8 Class Initialized
INFO - 2023-07-01 11:14:25 --> URI Class Initialized
INFO - 2023-07-01 11:14:25 --> Router Class Initialized
INFO - 2023-07-01 11:14:25 --> Output Class Initialized
INFO - 2023-07-01 11:14:25 --> Security Class Initialized
DEBUG - 2023-07-01 11:14:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-01 11:14:25 --> Input Class Initialized
INFO - 2023-07-01 11:14:25 --> Language Class Initialized
INFO - 2023-07-01 11:14:25 --> Loader Class Initialized
INFO - 2023-07-01 11:14:25 --> Helper loaded: url_helper
INFO - 2023-07-01 11:14:25 --> Helper loaded: file_helper
INFO - 2023-07-01 11:14:25 --> Helper loaded: html_helper
INFO - 2023-07-01 11:14:25 --> Helper loaded: text_helper
INFO - 2023-07-01 11:14:25 --> Helper loaded: form_helper
INFO - 2023-07-01 11:14:25 --> Helper loaded: lang_helper
INFO - 2023-07-01 11:14:25 --> Helper loaded: security_helper
INFO - 2023-07-01 11:14:25 --> Helper loaded: cookie_helper
INFO - 2023-07-01 11:14:25 --> Database Driver Class Initialized
INFO - 2023-07-01 11:14:25 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-01 11:14:25 --> Parser Class Initialized
INFO - 2023-07-01 11:14:25 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-01 11:14:25 --> Pagination Class Initialized
INFO - 2023-07-01 11:14:25 --> Form Validation Class Initialized
INFO - 2023-07-01 11:14:25 --> Controller Class Initialized
INFO - 2023-07-01 11:14:25 --> Model Class Initialized
DEBUG - 2023-07-01 11:14:25 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-01 11:14:25 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-01 11:14:25 --> Model Class Initialized
DEBUG - 2023-07-01 11:14:25 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-01 11:14:25 --> Model Class Initialized
INFO - 2023-07-01 11:14:25 --> Final output sent to browser
DEBUG - 2023-07-01 11:14:25 --> Total execution time: 0.0616
ERROR - 2023-07-01 11:14:31 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-01 11:14:31 --> Config Class Initialized
INFO - 2023-07-01 11:14:31 --> Hooks Class Initialized
DEBUG - 2023-07-01 11:14:31 --> UTF-8 Support Enabled
INFO - 2023-07-01 11:14:31 --> Utf8 Class Initialized
INFO - 2023-07-01 11:14:31 --> URI Class Initialized
INFO - 2023-07-01 11:14:31 --> Router Class Initialized
INFO - 2023-07-01 11:14:31 --> Output Class Initialized
INFO - 2023-07-01 11:14:31 --> Security Class Initialized
DEBUG - 2023-07-01 11:14:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-01 11:14:31 --> Input Class Initialized
INFO - 2023-07-01 11:14:31 --> Language Class Initialized
INFO - 2023-07-01 11:14:31 --> Loader Class Initialized
INFO - 2023-07-01 11:14:31 --> Helper loaded: url_helper
INFO - 2023-07-01 11:14:31 --> Helper loaded: file_helper
INFO - 2023-07-01 11:14:31 --> Helper loaded: html_helper
INFO - 2023-07-01 11:14:31 --> Helper loaded: text_helper
INFO - 2023-07-01 11:14:31 --> Helper loaded: form_helper
INFO - 2023-07-01 11:14:31 --> Helper loaded: lang_helper
INFO - 2023-07-01 11:14:31 --> Helper loaded: security_helper
INFO - 2023-07-01 11:14:31 --> Helper loaded: cookie_helper
INFO - 2023-07-01 11:14:31 --> Database Driver Class Initialized
INFO - 2023-07-01 11:14:31 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-01 11:14:31 --> Parser Class Initialized
INFO - 2023-07-01 11:14:31 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-01 11:14:31 --> Pagination Class Initialized
INFO - 2023-07-01 11:14:31 --> Form Validation Class Initialized
INFO - 2023-07-01 11:14:31 --> Controller Class Initialized
INFO - 2023-07-01 11:14:31 --> Model Class Initialized
DEBUG - 2023-07-01 11:14:31 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-01 11:14:31 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-01 11:14:31 --> Model Class Initialized
DEBUG - 2023-07-01 11:14:31 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-01 11:14:31 --> Model Class Initialized
INFO - 2023-07-01 11:14:32 --> Final output sent to browser
DEBUG - 2023-07-01 11:14:32 --> Total execution time: 0.3291
ERROR - 2023-07-01 11:14:49 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-01 11:14:49 --> Config Class Initialized
INFO - 2023-07-01 11:14:49 --> Hooks Class Initialized
DEBUG - 2023-07-01 11:14:49 --> UTF-8 Support Enabled
INFO - 2023-07-01 11:14:49 --> Utf8 Class Initialized
INFO - 2023-07-01 11:14:49 --> URI Class Initialized
DEBUG - 2023-07-01 11:14:49 --> No URI present. Default controller set.
INFO - 2023-07-01 11:14:49 --> Router Class Initialized
INFO - 2023-07-01 11:14:49 --> Output Class Initialized
INFO - 2023-07-01 11:14:49 --> Security Class Initialized
DEBUG - 2023-07-01 11:14:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-01 11:14:49 --> Input Class Initialized
INFO - 2023-07-01 11:14:49 --> Language Class Initialized
INFO - 2023-07-01 11:14:49 --> Loader Class Initialized
INFO - 2023-07-01 11:14:49 --> Helper loaded: url_helper
INFO - 2023-07-01 11:14:49 --> Helper loaded: file_helper
INFO - 2023-07-01 11:14:49 --> Helper loaded: html_helper
INFO - 2023-07-01 11:14:49 --> Helper loaded: text_helper
INFO - 2023-07-01 11:14:49 --> Helper loaded: form_helper
INFO - 2023-07-01 11:14:49 --> Helper loaded: lang_helper
INFO - 2023-07-01 11:14:49 --> Helper loaded: security_helper
INFO - 2023-07-01 11:14:49 --> Helper loaded: cookie_helper
INFO - 2023-07-01 11:14:49 --> Database Driver Class Initialized
INFO - 2023-07-01 11:14:49 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-01 11:14:49 --> Parser Class Initialized
INFO - 2023-07-01 11:14:49 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-01 11:14:49 --> Pagination Class Initialized
INFO - 2023-07-01 11:14:49 --> Form Validation Class Initialized
INFO - 2023-07-01 11:14:49 --> Controller Class Initialized
INFO - 2023-07-01 11:14:49 --> Model Class Initialized
DEBUG - 2023-07-01 11:14:49 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-01 11:14:49 --> Model Class Initialized
DEBUG - 2023-07-01 11:14:49 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-01 11:14:49 --> Model Class Initialized
INFO - 2023-07-01 11:14:49 --> Model Class Initialized
INFO - 2023-07-01 11:14:49 --> Model Class Initialized
INFO - 2023-07-01 11:14:49 --> Model Class Initialized
DEBUG - 2023-07-01 11:14:49 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-01 11:14:49 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-01 11:14:49 --> Model Class Initialized
INFO - 2023-07-01 11:14:49 --> Model Class Initialized
INFO - 2023-07-01 11:14:49 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-07-01 11:14:49 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-07-01 11:14:49 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-07-01 11:14:49 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-07-01 11:14:49 --> Model Class Initialized
INFO - 2023-07-01 11:14:49 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-07-01 11:14:49 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-07-01 11:14:49 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-07-01 11:14:49 --> Final output sent to browser
DEBUG - 2023-07-01 11:14:49 --> Total execution time: 0.1812
ERROR - 2023-07-01 11:14:54 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-01 11:14:54 --> Config Class Initialized
INFO - 2023-07-01 11:14:54 --> Hooks Class Initialized
DEBUG - 2023-07-01 11:14:54 --> UTF-8 Support Enabled
INFO - 2023-07-01 11:14:54 --> Utf8 Class Initialized
INFO - 2023-07-01 11:14:54 --> URI Class Initialized
INFO - 2023-07-01 11:14:54 --> Router Class Initialized
INFO - 2023-07-01 11:14:54 --> Output Class Initialized
INFO - 2023-07-01 11:14:54 --> Security Class Initialized
DEBUG - 2023-07-01 11:14:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-01 11:14:54 --> Input Class Initialized
INFO - 2023-07-01 11:14:54 --> Language Class Initialized
INFO - 2023-07-01 11:14:54 --> Loader Class Initialized
INFO - 2023-07-01 11:14:54 --> Helper loaded: url_helper
INFO - 2023-07-01 11:14:54 --> Helper loaded: file_helper
INFO - 2023-07-01 11:14:54 --> Helper loaded: html_helper
INFO - 2023-07-01 11:14:54 --> Helper loaded: text_helper
INFO - 2023-07-01 11:14:54 --> Helper loaded: form_helper
INFO - 2023-07-01 11:14:54 --> Helper loaded: lang_helper
INFO - 2023-07-01 11:14:54 --> Helper loaded: security_helper
INFO - 2023-07-01 11:14:54 --> Helper loaded: cookie_helper
INFO - 2023-07-01 11:14:54 --> Database Driver Class Initialized
INFO - 2023-07-01 11:14:54 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-01 11:14:54 --> Parser Class Initialized
INFO - 2023-07-01 11:14:54 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-01 11:14:54 --> Pagination Class Initialized
INFO - 2023-07-01 11:14:54 --> Form Validation Class Initialized
INFO - 2023-07-01 11:14:54 --> Controller Class Initialized
INFO - 2023-07-01 11:14:54 --> Model Class Initialized
DEBUG - 2023-07-01 11:14:54 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-01 11:14:54 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-01 11:14:54 --> Model Class Initialized
DEBUG - 2023-07-01 11:14:54 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-01 11:14:54 --> Model Class Initialized
INFO - 2023-07-01 11:14:54 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/invoice/invoice.php
DEBUG - 2023-07-01 11:14:54 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-07-01 11:14:54 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-07-01 11:14:54 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-07-01 11:14:54 --> Model Class Initialized
INFO - 2023-07-01 11:14:54 --> Model Class Initialized
INFO - 2023-07-01 11:14:54 --> Model Class Initialized
INFO - 2023-07-01 11:14:54 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-07-01 11:14:54 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-07-01 11:14:54 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-07-01 11:14:54 --> Final output sent to browser
DEBUG - 2023-07-01 11:14:54 --> Total execution time: 0.1437
ERROR - 2023-07-01 11:14:54 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-01 11:14:54 --> Config Class Initialized
INFO - 2023-07-01 11:14:54 --> Hooks Class Initialized
DEBUG - 2023-07-01 11:14:54 --> UTF-8 Support Enabled
INFO - 2023-07-01 11:14:54 --> Utf8 Class Initialized
INFO - 2023-07-01 11:14:54 --> URI Class Initialized
INFO - 2023-07-01 11:14:54 --> Router Class Initialized
INFO - 2023-07-01 11:14:54 --> Output Class Initialized
INFO - 2023-07-01 11:14:54 --> Security Class Initialized
DEBUG - 2023-07-01 11:14:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-01 11:14:54 --> Input Class Initialized
INFO - 2023-07-01 11:14:54 --> Language Class Initialized
INFO - 2023-07-01 11:14:54 --> Loader Class Initialized
INFO - 2023-07-01 11:14:54 --> Helper loaded: url_helper
INFO - 2023-07-01 11:14:54 --> Helper loaded: file_helper
INFO - 2023-07-01 11:14:54 --> Helper loaded: html_helper
INFO - 2023-07-01 11:14:54 --> Helper loaded: text_helper
INFO - 2023-07-01 11:14:54 --> Helper loaded: form_helper
INFO - 2023-07-01 11:14:54 --> Helper loaded: lang_helper
INFO - 2023-07-01 11:14:54 --> Helper loaded: security_helper
INFO - 2023-07-01 11:14:54 --> Helper loaded: cookie_helper
INFO - 2023-07-01 11:14:54 --> Database Driver Class Initialized
INFO - 2023-07-01 11:14:54 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-01 11:14:54 --> Parser Class Initialized
INFO - 2023-07-01 11:14:54 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-01 11:14:54 --> Pagination Class Initialized
INFO - 2023-07-01 11:14:54 --> Form Validation Class Initialized
INFO - 2023-07-01 11:14:54 --> Controller Class Initialized
INFO - 2023-07-01 11:14:54 --> Model Class Initialized
DEBUG - 2023-07-01 11:14:54 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-01 11:14:54 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-01 11:14:54 --> Model Class Initialized
DEBUG - 2023-07-01 11:14:54 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-01 11:14:54 --> Model Class Initialized
INFO - 2023-07-01 11:14:54 --> Final output sent to browser
DEBUG - 2023-07-01 11:14:54 --> Total execution time: 0.0462
ERROR - 2023-07-01 11:15:00 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-01 11:15:00 --> Config Class Initialized
INFO - 2023-07-01 11:15:00 --> Hooks Class Initialized
DEBUG - 2023-07-01 11:15:00 --> UTF-8 Support Enabled
INFO - 2023-07-01 11:15:00 --> Utf8 Class Initialized
INFO - 2023-07-01 11:15:00 --> URI Class Initialized
INFO - 2023-07-01 11:15:00 --> Router Class Initialized
INFO - 2023-07-01 11:15:00 --> Output Class Initialized
INFO - 2023-07-01 11:15:00 --> Security Class Initialized
DEBUG - 2023-07-01 11:15:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-01 11:15:00 --> Input Class Initialized
INFO - 2023-07-01 11:15:00 --> Language Class Initialized
INFO - 2023-07-01 11:15:00 --> Loader Class Initialized
INFO - 2023-07-01 11:15:00 --> Helper loaded: url_helper
INFO - 2023-07-01 11:15:00 --> Helper loaded: file_helper
INFO - 2023-07-01 11:15:00 --> Helper loaded: html_helper
INFO - 2023-07-01 11:15:00 --> Helper loaded: text_helper
INFO - 2023-07-01 11:15:00 --> Helper loaded: form_helper
INFO - 2023-07-01 11:15:00 --> Helper loaded: lang_helper
INFO - 2023-07-01 11:15:00 --> Helper loaded: security_helper
INFO - 2023-07-01 11:15:00 --> Helper loaded: cookie_helper
INFO - 2023-07-01 11:15:00 --> Database Driver Class Initialized
INFO - 2023-07-01 11:15:00 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-01 11:15:00 --> Parser Class Initialized
INFO - 2023-07-01 11:15:00 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-01 11:15:00 --> Pagination Class Initialized
INFO - 2023-07-01 11:15:00 --> Form Validation Class Initialized
INFO - 2023-07-01 11:15:00 --> Controller Class Initialized
INFO - 2023-07-01 11:15:00 --> Model Class Initialized
DEBUG - 2023-07-01 11:15:00 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-01 11:15:00 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-01 11:15:00 --> Model Class Initialized
DEBUG - 2023-07-01 11:15:00 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-01 11:15:00 --> Model Class Initialized
INFO - 2023-07-01 11:15:00 --> Final output sent to browser
DEBUG - 2023-07-01 11:15:00 --> Total execution time: 0.0468
ERROR - 2023-07-01 11:15:03 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-01 11:15:03 --> Config Class Initialized
INFO - 2023-07-01 11:15:03 --> Hooks Class Initialized
DEBUG - 2023-07-01 11:15:03 --> UTF-8 Support Enabled
INFO - 2023-07-01 11:15:03 --> Utf8 Class Initialized
INFO - 2023-07-01 11:15:03 --> URI Class Initialized
DEBUG - 2023-07-01 11:15:03 --> No URI present. Default controller set.
INFO - 2023-07-01 11:15:03 --> Router Class Initialized
INFO - 2023-07-01 11:15:03 --> Output Class Initialized
INFO - 2023-07-01 11:15:03 --> Security Class Initialized
DEBUG - 2023-07-01 11:15:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-01 11:15:03 --> Input Class Initialized
INFO - 2023-07-01 11:15:03 --> Language Class Initialized
INFO - 2023-07-01 11:15:03 --> Loader Class Initialized
INFO - 2023-07-01 11:15:03 --> Helper loaded: url_helper
INFO - 2023-07-01 11:15:03 --> Helper loaded: file_helper
INFO - 2023-07-01 11:15:03 --> Helper loaded: html_helper
INFO - 2023-07-01 11:15:03 --> Helper loaded: text_helper
INFO - 2023-07-01 11:15:03 --> Helper loaded: form_helper
INFO - 2023-07-01 11:15:03 --> Helper loaded: lang_helper
INFO - 2023-07-01 11:15:03 --> Helper loaded: security_helper
INFO - 2023-07-01 11:15:03 --> Helper loaded: cookie_helper
INFO - 2023-07-01 11:15:03 --> Database Driver Class Initialized
INFO - 2023-07-01 11:15:03 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-01 11:15:03 --> Parser Class Initialized
INFO - 2023-07-01 11:15:03 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-01 11:15:03 --> Pagination Class Initialized
INFO - 2023-07-01 11:15:03 --> Form Validation Class Initialized
INFO - 2023-07-01 11:15:03 --> Controller Class Initialized
INFO - 2023-07-01 11:15:03 --> Model Class Initialized
DEBUG - 2023-07-01 11:15:03 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-01 11:15:03 --> Model Class Initialized
DEBUG - 2023-07-01 11:15:03 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-01 11:15:03 --> Model Class Initialized
INFO - 2023-07-01 11:15:03 --> Model Class Initialized
INFO - 2023-07-01 11:15:03 --> Model Class Initialized
INFO - 2023-07-01 11:15:03 --> Model Class Initialized
DEBUG - 2023-07-01 11:15:03 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-01 11:15:03 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-01 11:15:03 --> Model Class Initialized
INFO - 2023-07-01 11:15:03 --> Model Class Initialized
INFO - 2023-07-01 11:15:03 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-07-01 11:15:03 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-07-01 11:15:03 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-07-01 11:15:03 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-07-01 11:15:03 --> Model Class Initialized
INFO - 2023-07-01 11:15:04 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-07-01 11:15:04 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-07-01 11:15:04 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-07-01 11:15:04 --> Final output sent to browser
DEBUG - 2023-07-01 11:15:04 --> Total execution time: 0.1914
ERROR - 2023-07-01 11:15:26 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-01 11:15:26 --> Config Class Initialized
INFO - 2023-07-01 11:15:26 --> Hooks Class Initialized
DEBUG - 2023-07-01 11:15:26 --> UTF-8 Support Enabled
INFO - 2023-07-01 11:15:26 --> Utf8 Class Initialized
INFO - 2023-07-01 11:15:26 --> URI Class Initialized
DEBUG - 2023-07-01 11:15:26 --> No URI present. Default controller set.
INFO - 2023-07-01 11:15:26 --> Router Class Initialized
INFO - 2023-07-01 11:15:26 --> Output Class Initialized
INFO - 2023-07-01 11:15:26 --> Security Class Initialized
DEBUG - 2023-07-01 11:15:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-01 11:15:26 --> Input Class Initialized
INFO - 2023-07-01 11:15:26 --> Language Class Initialized
INFO - 2023-07-01 11:15:26 --> Loader Class Initialized
INFO - 2023-07-01 11:15:26 --> Helper loaded: url_helper
INFO - 2023-07-01 11:15:26 --> Helper loaded: file_helper
INFO - 2023-07-01 11:15:26 --> Helper loaded: html_helper
INFO - 2023-07-01 11:15:26 --> Helper loaded: text_helper
INFO - 2023-07-01 11:15:26 --> Helper loaded: form_helper
INFO - 2023-07-01 11:15:26 --> Helper loaded: lang_helper
INFO - 2023-07-01 11:15:26 --> Helper loaded: security_helper
INFO - 2023-07-01 11:15:26 --> Helper loaded: cookie_helper
INFO - 2023-07-01 11:15:26 --> Database Driver Class Initialized
INFO - 2023-07-01 11:15:26 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-01 11:15:26 --> Parser Class Initialized
INFO - 2023-07-01 11:15:26 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-01 11:15:26 --> Pagination Class Initialized
INFO - 2023-07-01 11:15:26 --> Form Validation Class Initialized
INFO - 2023-07-01 11:15:26 --> Controller Class Initialized
INFO - 2023-07-01 11:15:26 --> Model Class Initialized
DEBUG - 2023-07-01 11:15:26 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-01 11:15:26 --> Model Class Initialized
DEBUG - 2023-07-01 11:15:26 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-01 11:15:26 --> Model Class Initialized
INFO - 2023-07-01 11:15:26 --> Model Class Initialized
INFO - 2023-07-01 11:15:26 --> Model Class Initialized
INFO - 2023-07-01 11:15:26 --> Model Class Initialized
DEBUG - 2023-07-01 11:15:26 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-01 11:15:26 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-01 11:15:26 --> Model Class Initialized
INFO - 2023-07-01 11:15:26 --> Model Class Initialized
INFO - 2023-07-01 11:15:26 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-07-01 11:15:26 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-07-01 11:15:26 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-07-01 11:15:26 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-07-01 11:15:26 --> Model Class Initialized
INFO - 2023-07-01 11:15:27 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-07-01 11:15:27 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-07-01 11:15:27 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-07-01 11:15:27 --> Final output sent to browser
DEBUG - 2023-07-01 11:15:27 --> Total execution time: 0.0850
ERROR - 2023-07-01 11:15:58 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-01 11:15:58 --> Config Class Initialized
INFO - 2023-07-01 11:15:58 --> Hooks Class Initialized
DEBUG - 2023-07-01 11:15:58 --> UTF-8 Support Enabled
INFO - 2023-07-01 11:15:58 --> Utf8 Class Initialized
INFO - 2023-07-01 11:15:58 --> URI Class Initialized
INFO - 2023-07-01 11:15:58 --> Router Class Initialized
INFO - 2023-07-01 11:15:58 --> Output Class Initialized
INFO - 2023-07-01 11:15:58 --> Security Class Initialized
DEBUG - 2023-07-01 11:15:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-01 11:15:58 --> Input Class Initialized
INFO - 2023-07-01 11:15:58 --> Language Class Initialized
INFO - 2023-07-01 11:15:58 --> Loader Class Initialized
INFO - 2023-07-01 11:15:58 --> Helper loaded: url_helper
INFO - 2023-07-01 11:15:58 --> Helper loaded: file_helper
INFO - 2023-07-01 11:15:58 --> Helper loaded: html_helper
INFO - 2023-07-01 11:15:58 --> Helper loaded: text_helper
INFO - 2023-07-01 11:15:58 --> Helper loaded: form_helper
INFO - 2023-07-01 11:15:58 --> Helper loaded: lang_helper
INFO - 2023-07-01 11:15:58 --> Helper loaded: security_helper
INFO - 2023-07-01 11:15:58 --> Helper loaded: cookie_helper
INFO - 2023-07-01 11:15:58 --> Database Driver Class Initialized
INFO - 2023-07-01 11:15:58 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-01 11:15:58 --> Parser Class Initialized
INFO - 2023-07-01 11:15:58 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-01 11:15:58 --> Pagination Class Initialized
INFO - 2023-07-01 11:15:58 --> Form Validation Class Initialized
INFO - 2023-07-01 11:15:58 --> Controller Class Initialized
DEBUG - 2023-07-01 11:15:58 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-01 11:15:58 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-01 11:15:58 --> Model Class Initialized
DEBUG - 2023-07-01 11:15:58 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-01 11:15:58 --> Model Class Initialized
DEBUG - 2023-07-01 11:15:58 --> Lcustomer class already loaded. Second attempt ignored.
INFO - 2023-07-01 11:15:58 --> Model Class Initialized
INFO - 2023-07-01 11:15:58 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/customer/customer.php
DEBUG - 2023-07-01 11:15:58 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-07-01 11:15:58 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-07-01 11:15:58 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-07-01 11:15:58 --> Model Class Initialized
INFO - 2023-07-01 11:15:58 --> Model Class Initialized
INFO - 2023-07-01 11:15:58 --> Model Class Initialized
INFO - 2023-07-01 11:15:58 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-07-01 11:15:58 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-07-01 11:15:58 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-07-01 11:15:58 --> Final output sent to browser
DEBUG - 2023-07-01 11:15:58 --> Total execution time: 0.0776
ERROR - 2023-07-01 11:15:58 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-01 11:15:58 --> Config Class Initialized
INFO - 2023-07-01 11:15:58 --> Hooks Class Initialized
DEBUG - 2023-07-01 11:15:58 --> UTF-8 Support Enabled
INFO - 2023-07-01 11:15:58 --> Utf8 Class Initialized
INFO - 2023-07-01 11:15:58 --> URI Class Initialized
INFO - 2023-07-01 11:15:58 --> Router Class Initialized
INFO - 2023-07-01 11:15:58 --> Output Class Initialized
INFO - 2023-07-01 11:15:58 --> Security Class Initialized
DEBUG - 2023-07-01 11:15:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-01 11:15:58 --> Input Class Initialized
INFO - 2023-07-01 11:15:58 --> Language Class Initialized
INFO - 2023-07-01 11:15:58 --> Loader Class Initialized
INFO - 2023-07-01 11:15:58 --> Helper loaded: url_helper
INFO - 2023-07-01 11:15:58 --> Helper loaded: file_helper
INFO - 2023-07-01 11:15:58 --> Helper loaded: html_helper
INFO - 2023-07-01 11:15:58 --> Helper loaded: text_helper
INFO - 2023-07-01 11:15:58 --> Helper loaded: form_helper
INFO - 2023-07-01 11:15:58 --> Helper loaded: lang_helper
INFO - 2023-07-01 11:15:58 --> Helper loaded: security_helper
INFO - 2023-07-01 11:15:58 --> Helper loaded: cookie_helper
INFO - 2023-07-01 11:15:58 --> Database Driver Class Initialized
INFO - 2023-07-01 11:15:58 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-01 11:15:58 --> Parser Class Initialized
INFO - 2023-07-01 11:15:58 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-01 11:15:58 --> Pagination Class Initialized
INFO - 2023-07-01 11:15:58 --> Form Validation Class Initialized
INFO - 2023-07-01 11:15:58 --> Controller Class Initialized
DEBUG - 2023-07-01 11:15:58 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-01 11:15:58 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-01 11:15:58 --> Model Class Initialized
DEBUG - 2023-07-01 11:15:58 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-01 11:15:58 --> Model Class Initialized
INFO - 2023-07-01 11:15:58 --> Final output sent to browser
DEBUG - 2023-07-01 11:15:58 --> Total execution time: 0.0252
ERROR - 2023-07-01 11:16:02 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-01 11:16:02 --> Config Class Initialized
INFO - 2023-07-01 11:16:02 --> Hooks Class Initialized
DEBUG - 2023-07-01 11:16:02 --> UTF-8 Support Enabled
INFO - 2023-07-01 11:16:02 --> Utf8 Class Initialized
INFO - 2023-07-01 11:16:02 --> URI Class Initialized
INFO - 2023-07-01 11:16:02 --> Router Class Initialized
INFO - 2023-07-01 11:16:02 --> Output Class Initialized
INFO - 2023-07-01 11:16:02 --> Security Class Initialized
DEBUG - 2023-07-01 11:16:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-01 11:16:02 --> Input Class Initialized
INFO - 2023-07-01 11:16:02 --> Language Class Initialized
INFO - 2023-07-01 11:16:02 --> Loader Class Initialized
INFO - 2023-07-01 11:16:02 --> Helper loaded: url_helper
INFO - 2023-07-01 11:16:02 --> Helper loaded: file_helper
INFO - 2023-07-01 11:16:02 --> Helper loaded: html_helper
INFO - 2023-07-01 11:16:02 --> Helper loaded: text_helper
INFO - 2023-07-01 11:16:02 --> Helper loaded: form_helper
INFO - 2023-07-01 11:16:02 --> Helper loaded: lang_helper
INFO - 2023-07-01 11:16:02 --> Helper loaded: security_helper
INFO - 2023-07-01 11:16:02 --> Helper loaded: cookie_helper
INFO - 2023-07-01 11:16:02 --> Database Driver Class Initialized
INFO - 2023-07-01 11:16:02 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-01 11:16:02 --> Parser Class Initialized
INFO - 2023-07-01 11:16:02 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-01 11:16:02 --> Pagination Class Initialized
INFO - 2023-07-01 11:16:02 --> Form Validation Class Initialized
INFO - 2023-07-01 11:16:02 --> Controller Class Initialized
DEBUG - 2023-07-01 11:16:02 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-01 11:16:02 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-01 11:16:02 --> Model Class Initialized
DEBUG - 2023-07-01 11:16:02 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-01 11:16:02 --> Model Class Initialized
INFO - 2023-07-01 11:16:02 --> Final output sent to browser
DEBUG - 2023-07-01 11:16:02 --> Total execution time: 0.0333
ERROR - 2023-07-01 11:16:14 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-01 11:16:14 --> Config Class Initialized
INFO - 2023-07-01 11:16:14 --> Hooks Class Initialized
DEBUG - 2023-07-01 11:16:14 --> UTF-8 Support Enabled
INFO - 2023-07-01 11:16:14 --> Utf8 Class Initialized
INFO - 2023-07-01 11:16:14 --> URI Class Initialized
INFO - 2023-07-01 11:16:14 --> Router Class Initialized
INFO - 2023-07-01 11:16:14 --> Output Class Initialized
INFO - 2023-07-01 11:16:14 --> Security Class Initialized
DEBUG - 2023-07-01 11:16:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-01 11:16:14 --> Input Class Initialized
INFO - 2023-07-01 11:16:14 --> Language Class Initialized
INFO - 2023-07-01 11:16:14 --> Loader Class Initialized
INFO - 2023-07-01 11:16:14 --> Helper loaded: url_helper
INFO - 2023-07-01 11:16:14 --> Helper loaded: file_helper
INFO - 2023-07-01 11:16:14 --> Helper loaded: html_helper
INFO - 2023-07-01 11:16:14 --> Helper loaded: text_helper
INFO - 2023-07-01 11:16:14 --> Helper loaded: form_helper
INFO - 2023-07-01 11:16:14 --> Helper loaded: lang_helper
INFO - 2023-07-01 11:16:14 --> Helper loaded: security_helper
INFO - 2023-07-01 11:16:14 --> Helper loaded: cookie_helper
INFO - 2023-07-01 11:16:14 --> Database Driver Class Initialized
INFO - 2023-07-01 11:16:14 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-01 11:16:14 --> Parser Class Initialized
INFO - 2023-07-01 11:16:14 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-01 11:16:14 --> Pagination Class Initialized
INFO - 2023-07-01 11:16:14 --> Form Validation Class Initialized
INFO - 2023-07-01 11:16:14 --> Controller Class Initialized
DEBUG - 2023-07-01 11:16:14 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-01 11:16:14 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-01 11:16:14 --> Model Class Initialized
DEBUG - 2023-07-01 11:16:14 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-01 11:16:14 --> Model Class Initialized
INFO - 2023-07-01 11:16:14 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/customer/view_customer.php
DEBUG - 2023-07-01 11:16:14 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-07-01 11:16:14 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-07-01 11:16:14 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-07-01 11:16:14 --> Model Class Initialized
INFO - 2023-07-01 11:16:14 --> Model Class Initialized
INFO - 2023-07-01 11:16:14 --> Model Class Initialized
INFO - 2023-07-01 11:16:14 --> Model Class Initialized
INFO - 2023-07-01 11:16:14 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-07-01 11:16:14 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-07-01 11:16:14 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-07-01 11:16:14 --> Final output sent to browser
DEBUG - 2023-07-01 11:16:14 --> Total execution time: 0.0792
ERROR - 2023-07-01 11:16:31 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-01 11:16:31 --> Config Class Initialized
INFO - 2023-07-01 11:16:31 --> Hooks Class Initialized
DEBUG - 2023-07-01 11:16:31 --> UTF-8 Support Enabled
INFO - 2023-07-01 11:16:31 --> Utf8 Class Initialized
INFO - 2023-07-01 11:16:31 --> URI Class Initialized
INFO - 2023-07-01 11:16:31 --> Router Class Initialized
INFO - 2023-07-01 11:16:31 --> Output Class Initialized
INFO - 2023-07-01 11:16:31 --> Security Class Initialized
DEBUG - 2023-07-01 11:16:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-01 11:16:31 --> Input Class Initialized
INFO - 2023-07-01 11:16:31 --> Language Class Initialized
INFO - 2023-07-01 11:16:31 --> Loader Class Initialized
INFO - 2023-07-01 11:16:31 --> Helper loaded: url_helper
INFO - 2023-07-01 11:16:31 --> Helper loaded: file_helper
INFO - 2023-07-01 11:16:31 --> Helper loaded: html_helper
INFO - 2023-07-01 11:16:31 --> Helper loaded: text_helper
INFO - 2023-07-01 11:16:31 --> Helper loaded: form_helper
INFO - 2023-07-01 11:16:31 --> Helper loaded: lang_helper
INFO - 2023-07-01 11:16:31 --> Helper loaded: security_helper
INFO - 2023-07-01 11:16:31 --> Helper loaded: cookie_helper
INFO - 2023-07-01 11:16:31 --> Database Driver Class Initialized
INFO - 2023-07-01 11:16:31 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-01 11:16:31 --> Parser Class Initialized
INFO - 2023-07-01 11:16:31 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-01 11:16:31 --> Pagination Class Initialized
INFO - 2023-07-01 11:16:31 --> Form Validation Class Initialized
INFO - 2023-07-01 11:16:31 --> Controller Class Initialized
DEBUG - 2023-07-01 11:16:31 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-01 11:16:31 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-01 11:16:31 --> Model Class Initialized
DEBUG - 2023-07-01 11:16:31 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-01 11:16:31 --> Model Class Initialized
INFO - 2023-07-01 11:16:31 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/customer/add_customer_form.php
DEBUG - 2023-07-01 11:16:31 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-07-01 11:16:31 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-07-01 11:16:31 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-07-01 11:16:31 --> Model Class Initialized
INFO - 2023-07-01 11:16:31 --> Model Class Initialized
INFO - 2023-07-01 11:16:31 --> Model Class Initialized
INFO - 2023-07-01 11:16:31 --> Model Class Initialized
INFO - 2023-07-01 11:16:31 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-07-01 11:16:31 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-07-01 11:16:31 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-07-01 11:16:31 --> Final output sent to browser
DEBUG - 2023-07-01 11:16:31 --> Total execution time: 0.1056
ERROR - 2023-07-01 11:16:45 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-01 11:16:45 --> Config Class Initialized
INFO - 2023-07-01 11:16:45 --> Hooks Class Initialized
DEBUG - 2023-07-01 11:16:45 --> UTF-8 Support Enabled
INFO - 2023-07-01 11:16:45 --> Utf8 Class Initialized
INFO - 2023-07-01 11:16:45 --> URI Class Initialized
DEBUG - 2023-07-01 11:16:45 --> No URI present. Default controller set.
INFO - 2023-07-01 11:16:45 --> Router Class Initialized
INFO - 2023-07-01 11:16:45 --> Output Class Initialized
INFO - 2023-07-01 11:16:45 --> Security Class Initialized
DEBUG - 2023-07-01 11:16:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-01 11:16:45 --> Input Class Initialized
INFO - 2023-07-01 11:16:45 --> Language Class Initialized
INFO - 2023-07-01 11:16:45 --> Loader Class Initialized
INFO - 2023-07-01 11:16:45 --> Helper loaded: url_helper
INFO - 2023-07-01 11:16:45 --> Helper loaded: file_helper
INFO - 2023-07-01 11:16:45 --> Helper loaded: html_helper
INFO - 2023-07-01 11:16:45 --> Helper loaded: text_helper
INFO - 2023-07-01 11:16:45 --> Helper loaded: form_helper
INFO - 2023-07-01 11:16:45 --> Helper loaded: lang_helper
INFO - 2023-07-01 11:16:45 --> Helper loaded: security_helper
INFO - 2023-07-01 11:16:45 --> Helper loaded: cookie_helper
INFO - 2023-07-01 11:16:45 --> Database Driver Class Initialized
INFO - 2023-07-01 11:16:45 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-01 11:16:45 --> Parser Class Initialized
INFO - 2023-07-01 11:16:45 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-01 11:16:45 --> Pagination Class Initialized
INFO - 2023-07-01 11:16:45 --> Form Validation Class Initialized
INFO - 2023-07-01 11:16:45 --> Controller Class Initialized
INFO - 2023-07-01 11:16:45 --> Model Class Initialized
DEBUG - 2023-07-01 11:16:45 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-01 11:16:45 --> Model Class Initialized
DEBUG - 2023-07-01 11:16:45 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-01 11:16:45 --> Model Class Initialized
INFO - 2023-07-01 11:16:45 --> Model Class Initialized
INFO - 2023-07-01 11:16:45 --> Model Class Initialized
INFO - 2023-07-01 11:16:45 --> Model Class Initialized
DEBUG - 2023-07-01 11:16:45 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-01 11:16:45 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-01 11:16:45 --> Model Class Initialized
INFO - 2023-07-01 11:16:45 --> Model Class Initialized
INFO - 2023-07-01 11:16:45 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-07-01 11:16:45 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-07-01 11:16:45 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-07-01 11:16:45 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-07-01 11:16:45 --> Model Class Initialized
INFO - 2023-07-01 11:16:45 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-07-01 11:16:45 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-07-01 11:16:45 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-07-01 11:16:45 --> Final output sent to browser
DEBUG - 2023-07-01 11:16:45 --> Total execution time: 0.0773
ERROR - 2023-07-01 11:16:45 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-01 11:16:45 --> Config Class Initialized
INFO - 2023-07-01 11:16:45 --> Hooks Class Initialized
DEBUG - 2023-07-01 11:16:45 --> UTF-8 Support Enabled
INFO - 2023-07-01 11:16:45 --> Utf8 Class Initialized
INFO - 2023-07-01 11:16:45 --> URI Class Initialized
DEBUG - 2023-07-01 11:16:45 --> No URI present. Default controller set.
INFO - 2023-07-01 11:16:45 --> Router Class Initialized
INFO - 2023-07-01 11:16:45 --> Output Class Initialized
INFO - 2023-07-01 11:16:45 --> Security Class Initialized
DEBUG - 2023-07-01 11:16:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-01 11:16:45 --> Input Class Initialized
INFO - 2023-07-01 11:16:45 --> Language Class Initialized
INFO - 2023-07-01 11:16:45 --> Loader Class Initialized
INFO - 2023-07-01 11:16:45 --> Helper loaded: url_helper
INFO - 2023-07-01 11:16:45 --> Helper loaded: file_helper
INFO - 2023-07-01 11:16:45 --> Helper loaded: html_helper
INFO - 2023-07-01 11:16:45 --> Helper loaded: text_helper
INFO - 2023-07-01 11:16:45 --> Helper loaded: form_helper
INFO - 2023-07-01 11:16:45 --> Helper loaded: lang_helper
INFO - 2023-07-01 11:16:45 --> Helper loaded: security_helper
INFO - 2023-07-01 11:16:45 --> Helper loaded: cookie_helper
INFO - 2023-07-01 11:16:45 --> Database Driver Class Initialized
INFO - 2023-07-01 11:16:45 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-01 11:16:45 --> Parser Class Initialized
INFO - 2023-07-01 11:16:45 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-01 11:16:45 --> Pagination Class Initialized
INFO - 2023-07-01 11:16:45 --> Form Validation Class Initialized
INFO - 2023-07-01 11:16:45 --> Controller Class Initialized
INFO - 2023-07-01 11:16:45 --> Model Class Initialized
DEBUG - 2023-07-01 11:16:45 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-01 11:16:45 --> Model Class Initialized
DEBUG - 2023-07-01 11:16:45 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-01 11:16:45 --> Model Class Initialized
INFO - 2023-07-01 11:16:45 --> Model Class Initialized
INFO - 2023-07-01 11:16:45 --> Model Class Initialized
INFO - 2023-07-01 11:16:45 --> Model Class Initialized
DEBUG - 2023-07-01 11:16:45 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-01 11:16:45 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-01 11:16:45 --> Model Class Initialized
INFO - 2023-07-01 11:16:45 --> Model Class Initialized
INFO - 2023-07-01 11:16:45 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-07-01 11:16:45 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-07-01 11:16:45 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-07-01 11:16:45 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-07-01 11:16:45 --> Model Class Initialized
INFO - 2023-07-01 11:16:45 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-07-01 11:16:45 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-07-01 11:16:45 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-07-01 11:16:45 --> Final output sent to browser
DEBUG - 2023-07-01 11:16:45 --> Total execution time: 0.0806
ERROR - 2023-07-01 11:18:38 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-01 11:18:38 --> Config Class Initialized
INFO - 2023-07-01 11:18:38 --> Hooks Class Initialized
DEBUG - 2023-07-01 11:18:38 --> UTF-8 Support Enabled
INFO - 2023-07-01 11:18:38 --> Utf8 Class Initialized
INFO - 2023-07-01 11:18:38 --> URI Class Initialized
INFO - 2023-07-01 11:18:38 --> Router Class Initialized
INFO - 2023-07-01 11:18:38 --> Output Class Initialized
INFO - 2023-07-01 11:18:38 --> Security Class Initialized
DEBUG - 2023-07-01 11:18:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-01 11:18:38 --> Input Class Initialized
INFO - 2023-07-01 11:18:38 --> Language Class Initialized
INFO - 2023-07-01 11:18:38 --> Loader Class Initialized
INFO - 2023-07-01 11:18:38 --> Helper loaded: url_helper
INFO - 2023-07-01 11:18:38 --> Helper loaded: file_helper
INFO - 2023-07-01 11:18:38 --> Helper loaded: html_helper
INFO - 2023-07-01 11:18:38 --> Helper loaded: text_helper
INFO - 2023-07-01 11:18:38 --> Helper loaded: form_helper
INFO - 2023-07-01 11:18:38 --> Helper loaded: lang_helper
INFO - 2023-07-01 11:18:38 --> Helper loaded: security_helper
INFO - 2023-07-01 11:18:38 --> Helper loaded: cookie_helper
INFO - 2023-07-01 11:18:38 --> Database Driver Class Initialized
INFO - 2023-07-01 11:18:38 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-01 11:18:38 --> Parser Class Initialized
INFO - 2023-07-01 11:18:38 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-01 11:18:38 --> Pagination Class Initialized
INFO - 2023-07-01 11:18:38 --> Form Validation Class Initialized
INFO - 2023-07-01 11:18:38 --> Controller Class Initialized
INFO - 2023-07-01 11:18:38 --> Model Class Initialized
DEBUG - 2023-07-01 11:18:38 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-01 11:18:38 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-01 11:18:38 --> Model Class Initialized
DEBUG - 2023-07-01 11:18:38 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-01 11:18:38 --> Model Class Initialized
INFO - 2023-07-01 11:18:38 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/invoice/invoice.php
DEBUG - 2023-07-01 11:18:38 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-07-01 11:18:38 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-07-01 11:18:38 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-07-01 11:18:38 --> Model Class Initialized
INFO - 2023-07-01 11:18:38 --> Model Class Initialized
INFO - 2023-07-01 11:18:38 --> Model Class Initialized
INFO - 2023-07-01 11:18:38 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-07-01 11:18:38 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-07-01 11:18:38 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-07-01 11:18:38 --> Final output sent to browser
DEBUG - 2023-07-01 11:18:38 --> Total execution time: 0.1466
ERROR - 2023-07-01 11:18:38 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-01 11:18:38 --> Config Class Initialized
INFO - 2023-07-01 11:18:38 --> Hooks Class Initialized
DEBUG - 2023-07-01 11:18:38 --> UTF-8 Support Enabled
INFO - 2023-07-01 11:18:38 --> Utf8 Class Initialized
INFO - 2023-07-01 11:18:38 --> URI Class Initialized
INFO - 2023-07-01 11:18:38 --> Router Class Initialized
INFO - 2023-07-01 11:18:38 --> Output Class Initialized
INFO - 2023-07-01 11:18:38 --> Security Class Initialized
DEBUG - 2023-07-01 11:18:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-01 11:18:38 --> Input Class Initialized
INFO - 2023-07-01 11:18:38 --> Language Class Initialized
INFO - 2023-07-01 11:18:39 --> Loader Class Initialized
INFO - 2023-07-01 11:18:39 --> Helper loaded: url_helper
INFO - 2023-07-01 11:18:39 --> Helper loaded: file_helper
INFO - 2023-07-01 11:18:39 --> Helper loaded: html_helper
INFO - 2023-07-01 11:18:39 --> Helper loaded: text_helper
INFO - 2023-07-01 11:18:39 --> Helper loaded: form_helper
INFO - 2023-07-01 11:18:39 --> Helper loaded: lang_helper
INFO - 2023-07-01 11:18:39 --> Helper loaded: security_helper
INFO - 2023-07-01 11:18:39 --> Helper loaded: cookie_helper
INFO - 2023-07-01 11:18:39 --> Database Driver Class Initialized
INFO - 2023-07-01 11:18:39 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-01 11:18:39 --> Parser Class Initialized
INFO - 2023-07-01 11:18:39 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-01 11:18:39 --> Pagination Class Initialized
INFO - 2023-07-01 11:18:39 --> Form Validation Class Initialized
INFO - 2023-07-01 11:18:39 --> Controller Class Initialized
INFO - 2023-07-01 11:18:39 --> Model Class Initialized
DEBUG - 2023-07-01 11:18:39 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-01 11:18:39 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-01 11:18:39 --> Model Class Initialized
DEBUG - 2023-07-01 11:18:39 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-01 11:18:39 --> Model Class Initialized
INFO - 2023-07-01 11:18:39 --> Final output sent to browser
DEBUG - 2023-07-01 11:18:39 --> Total execution time: 0.0572
ERROR - 2023-07-01 11:26:48 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-01 11:26:48 --> Config Class Initialized
INFO - 2023-07-01 11:26:48 --> Hooks Class Initialized
DEBUG - 2023-07-01 11:26:48 --> UTF-8 Support Enabled
INFO - 2023-07-01 11:26:48 --> Utf8 Class Initialized
INFO - 2023-07-01 11:26:48 --> URI Class Initialized
INFO - 2023-07-01 11:26:48 --> Router Class Initialized
INFO - 2023-07-01 11:26:48 --> Output Class Initialized
INFO - 2023-07-01 11:26:48 --> Security Class Initialized
DEBUG - 2023-07-01 11:26:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-01 11:26:48 --> Input Class Initialized
INFO - 2023-07-01 11:26:48 --> Language Class Initialized
INFO - 2023-07-01 11:26:48 --> Loader Class Initialized
INFO - 2023-07-01 11:26:48 --> Helper loaded: url_helper
INFO - 2023-07-01 11:26:48 --> Helper loaded: file_helper
INFO - 2023-07-01 11:26:48 --> Helper loaded: html_helper
INFO - 2023-07-01 11:26:48 --> Helper loaded: text_helper
INFO - 2023-07-01 11:26:48 --> Helper loaded: form_helper
INFO - 2023-07-01 11:26:48 --> Helper loaded: lang_helper
INFO - 2023-07-01 11:26:48 --> Helper loaded: security_helper
INFO - 2023-07-01 11:26:48 --> Helper loaded: cookie_helper
INFO - 2023-07-01 11:26:48 --> Database Driver Class Initialized
INFO - 2023-07-01 11:26:48 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-01 11:26:48 --> Parser Class Initialized
INFO - 2023-07-01 11:26:48 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-01 11:26:48 --> Pagination Class Initialized
INFO - 2023-07-01 11:26:48 --> Form Validation Class Initialized
INFO - 2023-07-01 11:26:48 --> Controller Class Initialized
INFO - 2023-07-01 11:26:48 --> Model Class Initialized
DEBUG - 2023-07-01 11:26:48 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-01 11:26:48 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-01 11:26:48 --> Model Class Initialized
DEBUG - 2023-07-01 11:26:48 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-01 11:26:48 --> Model Class Initialized
INFO - 2023-07-01 11:26:48 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice.php
DEBUG - 2023-07-01 11:26:48 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-07-01 11:26:48 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-07-01 11:26:48 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-07-01 11:26:48 --> Model Class Initialized
INFO - 2023-07-01 11:26:48 --> Model Class Initialized
INFO - 2023-07-01 11:26:48 --> Model Class Initialized
INFO - 2023-07-01 11:26:48 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-07-01 11:26:48 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-07-01 11:26:48 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-07-01 11:26:48 --> Final output sent to browser
DEBUG - 2023-07-01 11:26:48 --> Total execution time: 0.1605
ERROR - 2023-07-01 11:26:49 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-01 11:26:49 --> Config Class Initialized
INFO - 2023-07-01 11:26:49 --> Hooks Class Initialized
DEBUG - 2023-07-01 11:26:49 --> UTF-8 Support Enabled
INFO - 2023-07-01 11:26:49 --> Utf8 Class Initialized
INFO - 2023-07-01 11:26:49 --> URI Class Initialized
INFO - 2023-07-01 11:26:49 --> Router Class Initialized
INFO - 2023-07-01 11:26:49 --> Output Class Initialized
INFO - 2023-07-01 11:26:49 --> Security Class Initialized
DEBUG - 2023-07-01 11:26:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-01 11:26:49 --> Input Class Initialized
INFO - 2023-07-01 11:26:49 --> Language Class Initialized
INFO - 2023-07-01 11:26:49 --> Loader Class Initialized
INFO - 2023-07-01 11:26:49 --> Helper loaded: url_helper
INFO - 2023-07-01 11:26:49 --> Helper loaded: file_helper
INFO - 2023-07-01 11:26:49 --> Helper loaded: html_helper
INFO - 2023-07-01 11:26:49 --> Helper loaded: text_helper
INFO - 2023-07-01 11:26:49 --> Helper loaded: form_helper
INFO - 2023-07-01 11:26:49 --> Helper loaded: lang_helper
INFO - 2023-07-01 11:26:49 --> Helper loaded: security_helper
INFO - 2023-07-01 11:26:49 --> Helper loaded: cookie_helper
INFO - 2023-07-01 11:26:49 --> Database Driver Class Initialized
INFO - 2023-07-01 11:26:49 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-01 11:26:49 --> Parser Class Initialized
INFO - 2023-07-01 11:26:49 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-01 11:26:49 --> Pagination Class Initialized
INFO - 2023-07-01 11:26:49 --> Form Validation Class Initialized
INFO - 2023-07-01 11:26:49 --> Controller Class Initialized
INFO - 2023-07-01 11:26:49 --> Model Class Initialized
DEBUG - 2023-07-01 11:26:49 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-01 11:26:49 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-01 11:26:49 --> Model Class Initialized
DEBUG - 2023-07-01 11:26:49 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-01 11:26:49 --> Model Class Initialized
INFO - 2023-07-01 11:26:49 --> Final output sent to browser
DEBUG - 2023-07-01 11:26:49 --> Total execution time: 0.0589
ERROR - 2023-07-01 11:27:01 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-01 11:27:01 --> Config Class Initialized
INFO - 2023-07-01 11:27:01 --> Hooks Class Initialized
DEBUG - 2023-07-01 11:27:01 --> UTF-8 Support Enabled
INFO - 2023-07-01 11:27:01 --> Utf8 Class Initialized
INFO - 2023-07-01 11:27:01 --> URI Class Initialized
INFO - 2023-07-01 11:27:01 --> Router Class Initialized
INFO - 2023-07-01 11:27:01 --> Output Class Initialized
INFO - 2023-07-01 11:27:01 --> Security Class Initialized
DEBUG - 2023-07-01 11:27:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-01 11:27:01 --> Input Class Initialized
INFO - 2023-07-01 11:27:01 --> Language Class Initialized
INFO - 2023-07-01 11:27:01 --> Loader Class Initialized
INFO - 2023-07-01 11:27:01 --> Helper loaded: url_helper
INFO - 2023-07-01 11:27:01 --> Helper loaded: file_helper
INFO - 2023-07-01 11:27:01 --> Helper loaded: html_helper
INFO - 2023-07-01 11:27:01 --> Helper loaded: text_helper
INFO - 2023-07-01 11:27:01 --> Helper loaded: form_helper
INFO - 2023-07-01 11:27:01 --> Helper loaded: lang_helper
INFO - 2023-07-01 11:27:01 --> Helper loaded: security_helper
INFO - 2023-07-01 11:27:01 --> Helper loaded: cookie_helper
INFO - 2023-07-01 11:27:01 --> Database Driver Class Initialized
INFO - 2023-07-01 11:27:01 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-01 11:27:01 --> Parser Class Initialized
INFO - 2023-07-01 11:27:01 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-01 11:27:01 --> Pagination Class Initialized
INFO - 2023-07-01 11:27:01 --> Form Validation Class Initialized
INFO - 2023-07-01 11:27:01 --> Controller Class Initialized
INFO - 2023-07-01 11:27:01 --> Model Class Initialized
DEBUG - 2023-07-01 11:27:01 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-01 11:27:01 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-01 11:27:01 --> Model Class Initialized
DEBUG - 2023-07-01 11:27:01 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-01 11:27:01 --> Model Class Initialized
INFO - 2023-07-01 11:27:01 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/invoice/invoice.php
DEBUG - 2023-07-01 11:27:01 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-07-01 11:27:01 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-07-01 11:27:01 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-07-01 11:27:01 --> Model Class Initialized
INFO - 2023-07-01 11:27:01 --> Model Class Initialized
INFO - 2023-07-01 11:27:01 --> Model Class Initialized
INFO - 2023-07-01 11:27:01 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-07-01 11:27:01 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-07-01 11:27:01 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-07-01 11:27:01 --> Final output sent to browser
DEBUG - 2023-07-01 11:27:01 --> Total execution time: 0.1451
ERROR - 2023-07-01 11:27:01 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-01 11:27:01 --> Config Class Initialized
INFO - 2023-07-01 11:27:01 --> Hooks Class Initialized
DEBUG - 2023-07-01 11:27:01 --> UTF-8 Support Enabled
INFO - 2023-07-01 11:27:01 --> Utf8 Class Initialized
INFO - 2023-07-01 11:27:01 --> URI Class Initialized
INFO - 2023-07-01 11:27:01 --> Router Class Initialized
INFO - 2023-07-01 11:27:01 --> Output Class Initialized
INFO - 2023-07-01 11:27:01 --> Security Class Initialized
DEBUG - 2023-07-01 11:27:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-01 11:27:01 --> Input Class Initialized
INFO - 2023-07-01 11:27:01 --> Language Class Initialized
INFO - 2023-07-01 11:27:01 --> Loader Class Initialized
INFO - 2023-07-01 11:27:01 --> Helper loaded: url_helper
INFO - 2023-07-01 11:27:01 --> Helper loaded: file_helper
INFO - 2023-07-01 11:27:01 --> Helper loaded: html_helper
INFO - 2023-07-01 11:27:01 --> Helper loaded: text_helper
INFO - 2023-07-01 11:27:01 --> Helper loaded: form_helper
INFO - 2023-07-01 11:27:01 --> Helper loaded: lang_helper
INFO - 2023-07-01 11:27:01 --> Helper loaded: security_helper
INFO - 2023-07-01 11:27:01 --> Helper loaded: cookie_helper
INFO - 2023-07-01 11:27:01 --> Database Driver Class Initialized
INFO - 2023-07-01 11:27:01 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-01 11:27:01 --> Parser Class Initialized
INFO - 2023-07-01 11:27:01 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-01 11:27:01 --> Pagination Class Initialized
INFO - 2023-07-01 11:27:01 --> Form Validation Class Initialized
INFO - 2023-07-01 11:27:01 --> Controller Class Initialized
INFO - 2023-07-01 11:27:01 --> Model Class Initialized
DEBUG - 2023-07-01 11:27:01 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-01 11:27:01 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-01 11:27:01 --> Model Class Initialized
DEBUG - 2023-07-01 11:27:01 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-01 11:27:01 --> Model Class Initialized
INFO - 2023-07-01 11:27:01 --> Final output sent to browser
DEBUG - 2023-07-01 11:27:01 --> Total execution time: 0.0480
ERROR - 2023-07-01 11:29:59 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-01 11:29:59 --> Config Class Initialized
INFO - 2023-07-01 11:29:59 --> Hooks Class Initialized
DEBUG - 2023-07-01 11:29:59 --> UTF-8 Support Enabled
INFO - 2023-07-01 11:29:59 --> Utf8 Class Initialized
INFO - 2023-07-01 11:29:59 --> URI Class Initialized
DEBUG - 2023-07-01 11:29:59 --> No URI present. Default controller set.
INFO - 2023-07-01 11:29:59 --> Router Class Initialized
INFO - 2023-07-01 11:29:59 --> Output Class Initialized
INFO - 2023-07-01 11:29:59 --> Security Class Initialized
DEBUG - 2023-07-01 11:29:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-01 11:29:59 --> Input Class Initialized
INFO - 2023-07-01 11:29:59 --> Language Class Initialized
INFO - 2023-07-01 11:29:59 --> Loader Class Initialized
INFO - 2023-07-01 11:29:59 --> Helper loaded: url_helper
INFO - 2023-07-01 11:29:59 --> Helper loaded: file_helper
INFO - 2023-07-01 11:29:59 --> Helper loaded: html_helper
INFO - 2023-07-01 11:29:59 --> Helper loaded: text_helper
INFO - 2023-07-01 11:29:59 --> Helper loaded: form_helper
INFO - 2023-07-01 11:29:59 --> Helper loaded: lang_helper
INFO - 2023-07-01 11:29:59 --> Helper loaded: security_helper
INFO - 2023-07-01 11:29:59 --> Helper loaded: cookie_helper
INFO - 2023-07-01 11:29:59 --> Database Driver Class Initialized
INFO - 2023-07-01 11:29:59 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-01 11:29:59 --> Parser Class Initialized
INFO - 2023-07-01 11:29:59 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-01 11:29:59 --> Pagination Class Initialized
INFO - 2023-07-01 11:29:59 --> Form Validation Class Initialized
INFO - 2023-07-01 11:29:59 --> Controller Class Initialized
INFO - 2023-07-01 11:29:59 --> Model Class Initialized
DEBUG - 2023-07-01 11:29:59 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-01 11:29:59 --> Model Class Initialized
DEBUG - 2023-07-01 11:29:59 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-01 11:29:59 --> Model Class Initialized
INFO - 2023-07-01 11:29:59 --> Model Class Initialized
INFO - 2023-07-01 11:29:59 --> Model Class Initialized
INFO - 2023-07-01 11:29:59 --> Model Class Initialized
DEBUG - 2023-07-01 11:29:59 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-01 11:29:59 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-01 11:29:59 --> Model Class Initialized
INFO - 2023-07-01 11:29:59 --> Model Class Initialized
INFO - 2023-07-01 11:29:59 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-07-01 11:29:59 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-07-01 11:29:59 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-07-01 11:29:59 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-07-01 11:29:59 --> Model Class Initialized
INFO - 2023-07-01 11:29:59 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-07-01 11:29:59 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-07-01 11:29:59 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-07-01 11:29:59 --> Final output sent to browser
DEBUG - 2023-07-01 11:29:59 --> Total execution time: 0.1920
ERROR - 2023-07-01 11:31:00 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-01 11:31:00 --> Config Class Initialized
INFO - 2023-07-01 11:31:00 --> Hooks Class Initialized
DEBUG - 2023-07-01 11:31:00 --> UTF-8 Support Enabled
INFO - 2023-07-01 11:31:00 --> Utf8 Class Initialized
INFO - 2023-07-01 11:31:00 --> URI Class Initialized
INFO - 2023-07-01 11:31:00 --> Router Class Initialized
INFO - 2023-07-01 11:31:00 --> Output Class Initialized
INFO - 2023-07-01 11:31:00 --> Security Class Initialized
DEBUG - 2023-07-01 11:31:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-01 11:31:00 --> Input Class Initialized
INFO - 2023-07-01 11:31:00 --> Language Class Initialized
INFO - 2023-07-01 11:31:00 --> Loader Class Initialized
INFO - 2023-07-01 11:31:00 --> Helper loaded: url_helper
INFO - 2023-07-01 11:31:00 --> Helper loaded: file_helper
INFO - 2023-07-01 11:31:00 --> Helper loaded: html_helper
INFO - 2023-07-01 11:31:00 --> Helper loaded: text_helper
INFO - 2023-07-01 11:31:00 --> Helper loaded: form_helper
INFO - 2023-07-01 11:31:00 --> Helper loaded: lang_helper
INFO - 2023-07-01 11:31:00 --> Helper loaded: security_helper
INFO - 2023-07-01 11:31:00 --> Helper loaded: cookie_helper
INFO - 2023-07-01 11:31:00 --> Database Driver Class Initialized
INFO - 2023-07-01 11:31:00 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-01 11:31:00 --> Parser Class Initialized
INFO - 2023-07-01 11:31:00 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-01 11:31:00 --> Pagination Class Initialized
INFO - 2023-07-01 11:31:00 --> Form Validation Class Initialized
INFO - 2023-07-01 11:31:00 --> Controller Class Initialized
INFO - 2023-07-01 11:31:00 --> Model Class Initialized
DEBUG - 2023-07-01 11:31:00 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-01 11:31:00 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-01 11:31:00 --> Model Class Initialized
DEBUG - 2023-07-01 11:31:00 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-01 11:31:00 --> Model Class Initialized
INFO - 2023-07-01 11:31:00 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/invoice/invoice.php
DEBUG - 2023-07-01 11:31:00 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-07-01 11:31:00 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-07-01 11:31:00 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-07-01 11:31:00 --> Model Class Initialized
INFO - 2023-07-01 11:31:00 --> Model Class Initialized
INFO - 2023-07-01 11:31:00 --> Model Class Initialized
INFO - 2023-07-01 11:31:00 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-07-01 11:31:00 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-07-01 11:31:00 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-07-01 11:31:00 --> Final output sent to browser
DEBUG - 2023-07-01 11:31:00 --> Total execution time: 0.1589
ERROR - 2023-07-01 11:31:01 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-01 11:31:01 --> Config Class Initialized
INFO - 2023-07-01 11:31:01 --> Hooks Class Initialized
DEBUG - 2023-07-01 11:31:01 --> UTF-8 Support Enabled
INFO - 2023-07-01 11:31:01 --> Utf8 Class Initialized
INFO - 2023-07-01 11:31:01 --> URI Class Initialized
INFO - 2023-07-01 11:31:01 --> Router Class Initialized
INFO - 2023-07-01 11:31:01 --> Output Class Initialized
INFO - 2023-07-01 11:31:01 --> Security Class Initialized
DEBUG - 2023-07-01 11:31:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-01 11:31:01 --> Input Class Initialized
INFO - 2023-07-01 11:31:01 --> Language Class Initialized
INFO - 2023-07-01 11:31:01 --> Loader Class Initialized
INFO - 2023-07-01 11:31:01 --> Helper loaded: url_helper
INFO - 2023-07-01 11:31:01 --> Helper loaded: file_helper
INFO - 2023-07-01 11:31:01 --> Helper loaded: html_helper
INFO - 2023-07-01 11:31:01 --> Helper loaded: text_helper
INFO - 2023-07-01 11:31:01 --> Helper loaded: form_helper
INFO - 2023-07-01 11:31:01 --> Helper loaded: lang_helper
INFO - 2023-07-01 11:31:01 --> Helper loaded: security_helper
INFO - 2023-07-01 11:31:01 --> Helper loaded: cookie_helper
INFO - 2023-07-01 11:31:01 --> Database Driver Class Initialized
INFO - 2023-07-01 11:31:01 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-01 11:31:01 --> Parser Class Initialized
INFO - 2023-07-01 11:31:01 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-01 11:31:01 --> Pagination Class Initialized
INFO - 2023-07-01 11:31:01 --> Form Validation Class Initialized
INFO - 2023-07-01 11:31:01 --> Controller Class Initialized
INFO - 2023-07-01 11:31:01 --> Model Class Initialized
DEBUG - 2023-07-01 11:31:01 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-01 11:31:01 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-01 11:31:01 --> Model Class Initialized
DEBUG - 2023-07-01 11:31:01 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-01 11:31:01 --> Model Class Initialized
INFO - 2023-07-01 11:31:01 --> Final output sent to browser
DEBUG - 2023-07-01 11:31:01 --> Total execution time: 0.0520
ERROR - 2023-07-01 11:32:26 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-01 11:32:26 --> Config Class Initialized
INFO - 2023-07-01 11:32:26 --> Hooks Class Initialized
DEBUG - 2023-07-01 11:32:26 --> UTF-8 Support Enabled
INFO - 2023-07-01 11:32:26 --> Utf8 Class Initialized
INFO - 2023-07-01 11:32:26 --> URI Class Initialized
INFO - 2023-07-01 11:32:26 --> Router Class Initialized
INFO - 2023-07-01 11:32:26 --> Output Class Initialized
INFO - 2023-07-01 11:32:26 --> Security Class Initialized
DEBUG - 2023-07-01 11:32:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-01 11:32:26 --> Input Class Initialized
INFO - 2023-07-01 11:32:26 --> Language Class Initialized
INFO - 2023-07-01 11:32:26 --> Loader Class Initialized
INFO - 2023-07-01 11:32:26 --> Helper loaded: url_helper
INFO - 2023-07-01 11:32:26 --> Helper loaded: file_helper
INFO - 2023-07-01 11:32:26 --> Helper loaded: html_helper
INFO - 2023-07-01 11:32:26 --> Helper loaded: text_helper
INFO - 2023-07-01 11:32:26 --> Helper loaded: form_helper
INFO - 2023-07-01 11:32:26 --> Helper loaded: lang_helper
INFO - 2023-07-01 11:32:26 --> Helper loaded: security_helper
INFO - 2023-07-01 11:32:26 --> Helper loaded: cookie_helper
INFO - 2023-07-01 11:32:26 --> Database Driver Class Initialized
INFO - 2023-07-01 11:32:26 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-01 11:32:26 --> Parser Class Initialized
INFO - 2023-07-01 11:32:26 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-01 11:32:26 --> Pagination Class Initialized
INFO - 2023-07-01 11:32:26 --> Form Validation Class Initialized
INFO - 2023-07-01 11:32:26 --> Controller Class Initialized
INFO - 2023-07-01 11:32:26 --> Model Class Initialized
DEBUG - 2023-07-01 11:32:26 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-01 11:32:26 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-01 11:32:26 --> Model Class Initialized
DEBUG - 2023-07-01 11:32:26 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-01 11:32:26 --> Model Class Initialized
INFO - 2023-07-01 11:32:26 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/invoice/invoice.php
DEBUG - 2023-07-01 11:32:26 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-07-01 11:32:26 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-07-01 11:32:26 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-07-01 11:32:26 --> Model Class Initialized
INFO - 2023-07-01 11:32:26 --> Model Class Initialized
INFO - 2023-07-01 11:32:26 --> Model Class Initialized
INFO - 2023-07-01 11:32:26 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-07-01 11:32:26 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-07-01 11:32:26 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-07-01 11:32:26 --> Final output sent to browser
DEBUG - 2023-07-01 11:32:26 --> Total execution time: 0.1501
ERROR - 2023-07-01 11:32:26 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-01 11:32:26 --> Config Class Initialized
INFO - 2023-07-01 11:32:26 --> Hooks Class Initialized
DEBUG - 2023-07-01 11:32:26 --> UTF-8 Support Enabled
INFO - 2023-07-01 11:32:26 --> Utf8 Class Initialized
INFO - 2023-07-01 11:32:26 --> URI Class Initialized
INFO - 2023-07-01 11:32:26 --> Router Class Initialized
INFO - 2023-07-01 11:32:26 --> Output Class Initialized
INFO - 2023-07-01 11:32:26 --> Security Class Initialized
DEBUG - 2023-07-01 11:32:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-01 11:32:26 --> Input Class Initialized
INFO - 2023-07-01 11:32:26 --> Language Class Initialized
INFO - 2023-07-01 11:32:26 --> Loader Class Initialized
INFO - 2023-07-01 11:32:26 --> Helper loaded: url_helper
INFO - 2023-07-01 11:32:26 --> Helper loaded: file_helper
INFO - 2023-07-01 11:32:26 --> Helper loaded: html_helper
INFO - 2023-07-01 11:32:26 --> Helper loaded: text_helper
INFO - 2023-07-01 11:32:26 --> Helper loaded: form_helper
INFO - 2023-07-01 11:32:26 --> Helper loaded: lang_helper
INFO - 2023-07-01 11:32:26 --> Helper loaded: security_helper
INFO - 2023-07-01 11:32:26 --> Helper loaded: cookie_helper
INFO - 2023-07-01 11:32:26 --> Database Driver Class Initialized
INFO - 2023-07-01 11:32:26 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-01 11:32:26 --> Parser Class Initialized
INFO - 2023-07-01 11:32:26 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-01 11:32:26 --> Pagination Class Initialized
INFO - 2023-07-01 11:32:26 --> Form Validation Class Initialized
INFO - 2023-07-01 11:32:26 --> Controller Class Initialized
INFO - 2023-07-01 11:32:26 --> Model Class Initialized
DEBUG - 2023-07-01 11:32:26 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-01 11:32:26 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-01 11:32:26 --> Model Class Initialized
DEBUG - 2023-07-01 11:32:26 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-01 11:32:26 --> Model Class Initialized
INFO - 2023-07-01 11:32:26 --> Final output sent to browser
DEBUG - 2023-07-01 11:32:26 --> Total execution time: 0.0478
ERROR - 2023-07-01 11:32:45 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-01 11:32:45 --> Config Class Initialized
INFO - 2023-07-01 11:32:45 --> Hooks Class Initialized
DEBUG - 2023-07-01 11:32:45 --> UTF-8 Support Enabled
INFO - 2023-07-01 11:32:45 --> Utf8 Class Initialized
INFO - 2023-07-01 11:32:45 --> URI Class Initialized
INFO - 2023-07-01 11:32:45 --> Router Class Initialized
INFO - 2023-07-01 11:32:45 --> Output Class Initialized
INFO - 2023-07-01 11:32:45 --> Security Class Initialized
DEBUG - 2023-07-01 11:32:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-01 11:32:45 --> Input Class Initialized
INFO - 2023-07-01 11:32:45 --> Language Class Initialized
INFO - 2023-07-01 11:32:45 --> Loader Class Initialized
INFO - 2023-07-01 11:32:45 --> Helper loaded: url_helper
INFO - 2023-07-01 11:32:45 --> Helper loaded: file_helper
INFO - 2023-07-01 11:32:45 --> Helper loaded: html_helper
INFO - 2023-07-01 11:32:45 --> Helper loaded: text_helper
INFO - 2023-07-01 11:32:45 --> Helper loaded: form_helper
INFO - 2023-07-01 11:32:45 --> Helper loaded: lang_helper
INFO - 2023-07-01 11:32:45 --> Helper loaded: security_helper
INFO - 2023-07-01 11:32:45 --> Helper loaded: cookie_helper
INFO - 2023-07-01 11:32:45 --> Database Driver Class Initialized
INFO - 2023-07-01 11:32:45 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-01 11:32:45 --> Parser Class Initialized
INFO - 2023-07-01 11:32:45 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-01 11:32:45 --> Pagination Class Initialized
INFO - 2023-07-01 11:32:45 --> Form Validation Class Initialized
INFO - 2023-07-01 11:32:45 --> Controller Class Initialized
INFO - 2023-07-01 11:32:45 --> Model Class Initialized
DEBUG - 2023-07-01 11:32:45 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-01 11:32:45 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-01 11:32:45 --> Model Class Initialized
DEBUG - 2023-07-01 11:32:45 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-01 11:32:45 --> Model Class Initialized
INFO - 2023-07-01 11:32:45 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice.php
DEBUG - 2023-07-01 11:32:45 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-07-01 11:32:45 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-07-01 11:32:45 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-07-01 11:32:45 --> Model Class Initialized
INFO - 2023-07-01 11:32:45 --> Model Class Initialized
INFO - 2023-07-01 11:32:45 --> Model Class Initialized
INFO - 2023-07-01 11:32:45 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-07-01 11:32:45 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-07-01 11:32:45 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-07-01 11:32:45 --> Final output sent to browser
DEBUG - 2023-07-01 11:32:45 --> Total execution time: 0.1589
ERROR - 2023-07-01 11:32:45 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-01 11:32:45 --> Config Class Initialized
INFO - 2023-07-01 11:32:45 --> Hooks Class Initialized
DEBUG - 2023-07-01 11:32:45 --> UTF-8 Support Enabled
INFO - 2023-07-01 11:32:45 --> Utf8 Class Initialized
INFO - 2023-07-01 11:32:45 --> URI Class Initialized
INFO - 2023-07-01 11:32:45 --> Router Class Initialized
INFO - 2023-07-01 11:32:45 --> Output Class Initialized
INFO - 2023-07-01 11:32:45 --> Security Class Initialized
DEBUG - 2023-07-01 11:32:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-01 11:32:45 --> Input Class Initialized
INFO - 2023-07-01 11:32:45 --> Language Class Initialized
INFO - 2023-07-01 11:32:45 --> Loader Class Initialized
INFO - 2023-07-01 11:32:45 --> Helper loaded: url_helper
INFO - 2023-07-01 11:32:45 --> Helper loaded: file_helper
INFO - 2023-07-01 11:32:45 --> Helper loaded: html_helper
INFO - 2023-07-01 11:32:45 --> Helper loaded: text_helper
INFO - 2023-07-01 11:32:45 --> Helper loaded: form_helper
INFO - 2023-07-01 11:32:45 --> Helper loaded: lang_helper
INFO - 2023-07-01 11:32:45 --> Helper loaded: security_helper
INFO - 2023-07-01 11:32:45 --> Helper loaded: cookie_helper
INFO - 2023-07-01 11:32:45 --> Database Driver Class Initialized
INFO - 2023-07-01 11:32:45 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-01 11:32:45 --> Parser Class Initialized
INFO - 2023-07-01 11:32:45 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-01 11:32:45 --> Pagination Class Initialized
INFO - 2023-07-01 11:32:45 --> Form Validation Class Initialized
INFO - 2023-07-01 11:32:45 --> Controller Class Initialized
INFO - 2023-07-01 11:32:45 --> Model Class Initialized
DEBUG - 2023-07-01 11:32:45 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-01 11:32:45 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-01 11:32:45 --> Model Class Initialized
DEBUG - 2023-07-01 11:32:45 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-01 11:32:45 --> Model Class Initialized
INFO - 2023-07-01 11:32:45 --> Final output sent to browser
DEBUG - 2023-07-01 11:32:45 --> Total execution time: 0.0657
ERROR - 2023-07-01 11:33:06 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-01 11:33:06 --> Config Class Initialized
INFO - 2023-07-01 11:33:06 --> Hooks Class Initialized
DEBUG - 2023-07-01 11:33:06 --> UTF-8 Support Enabled
INFO - 2023-07-01 11:33:06 --> Utf8 Class Initialized
INFO - 2023-07-01 11:33:06 --> URI Class Initialized
INFO - 2023-07-01 11:33:06 --> Router Class Initialized
INFO - 2023-07-01 11:33:06 --> Output Class Initialized
INFO - 2023-07-01 11:33:06 --> Security Class Initialized
DEBUG - 2023-07-01 11:33:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-01 11:33:06 --> Input Class Initialized
INFO - 2023-07-01 11:33:06 --> Language Class Initialized
INFO - 2023-07-01 11:33:06 --> Loader Class Initialized
INFO - 2023-07-01 11:33:06 --> Helper loaded: url_helper
INFO - 2023-07-01 11:33:06 --> Helper loaded: file_helper
INFO - 2023-07-01 11:33:06 --> Helper loaded: html_helper
INFO - 2023-07-01 11:33:06 --> Helper loaded: text_helper
INFO - 2023-07-01 11:33:06 --> Helper loaded: form_helper
INFO - 2023-07-01 11:33:06 --> Helper loaded: lang_helper
INFO - 2023-07-01 11:33:06 --> Helper loaded: security_helper
INFO - 2023-07-01 11:33:06 --> Helper loaded: cookie_helper
INFO - 2023-07-01 11:33:06 --> Database Driver Class Initialized
INFO - 2023-07-01 11:33:06 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-01 11:33:06 --> Parser Class Initialized
INFO - 2023-07-01 11:33:06 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-01 11:33:06 --> Pagination Class Initialized
INFO - 2023-07-01 11:33:06 --> Form Validation Class Initialized
INFO - 2023-07-01 11:33:06 --> Controller Class Initialized
INFO - 2023-07-01 11:33:06 --> Model Class Initialized
DEBUG - 2023-07-01 11:33:06 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-01 11:33:06 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-01 11:33:06 --> Model Class Initialized
DEBUG - 2023-07-01 11:33:06 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-01 11:33:06 --> Model Class Initialized
INFO - 2023-07-01 11:33:06 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice.php
DEBUG - 2023-07-01 11:33:06 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-07-01 11:33:06 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-07-01 11:33:06 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-07-01 11:33:06 --> Model Class Initialized
INFO - 2023-07-01 11:33:06 --> Model Class Initialized
INFO - 2023-07-01 11:33:06 --> Model Class Initialized
INFO - 2023-07-01 11:33:06 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-07-01 11:33:06 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-07-01 11:33:06 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-07-01 11:33:06 --> Final output sent to browser
DEBUG - 2023-07-01 11:33:06 --> Total execution time: 0.1527
ERROR - 2023-07-01 11:33:07 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-01 11:33:07 --> Config Class Initialized
INFO - 2023-07-01 11:33:07 --> Hooks Class Initialized
DEBUG - 2023-07-01 11:33:07 --> UTF-8 Support Enabled
INFO - 2023-07-01 11:33:07 --> Utf8 Class Initialized
INFO - 2023-07-01 11:33:07 --> URI Class Initialized
INFO - 2023-07-01 11:33:07 --> Router Class Initialized
INFO - 2023-07-01 11:33:07 --> Output Class Initialized
INFO - 2023-07-01 11:33:07 --> Security Class Initialized
DEBUG - 2023-07-01 11:33:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-01 11:33:07 --> Input Class Initialized
INFO - 2023-07-01 11:33:07 --> Language Class Initialized
INFO - 2023-07-01 11:33:07 --> Loader Class Initialized
INFO - 2023-07-01 11:33:07 --> Helper loaded: url_helper
INFO - 2023-07-01 11:33:07 --> Helper loaded: file_helper
INFO - 2023-07-01 11:33:07 --> Helper loaded: html_helper
INFO - 2023-07-01 11:33:07 --> Helper loaded: text_helper
INFO - 2023-07-01 11:33:07 --> Helper loaded: form_helper
INFO - 2023-07-01 11:33:07 --> Helper loaded: lang_helper
INFO - 2023-07-01 11:33:07 --> Helper loaded: security_helper
INFO - 2023-07-01 11:33:07 --> Helper loaded: cookie_helper
INFO - 2023-07-01 11:33:07 --> Database Driver Class Initialized
INFO - 2023-07-01 11:33:07 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-01 11:33:07 --> Parser Class Initialized
INFO - 2023-07-01 11:33:07 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-01 11:33:07 --> Pagination Class Initialized
INFO - 2023-07-01 11:33:07 --> Form Validation Class Initialized
INFO - 2023-07-01 11:33:07 --> Controller Class Initialized
INFO - 2023-07-01 11:33:07 --> Model Class Initialized
DEBUG - 2023-07-01 11:33:07 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-01 11:33:07 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-01 11:33:07 --> Model Class Initialized
DEBUG - 2023-07-01 11:33:07 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-01 11:33:07 --> Model Class Initialized
INFO - 2023-07-01 11:33:07 --> Final output sent to browser
DEBUG - 2023-07-01 11:33:07 --> Total execution time: 0.0589
ERROR - 2023-07-01 11:33:11 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-01 11:33:11 --> Config Class Initialized
INFO - 2023-07-01 11:33:11 --> Hooks Class Initialized
DEBUG - 2023-07-01 11:33:11 --> UTF-8 Support Enabled
INFO - 2023-07-01 11:33:11 --> Utf8 Class Initialized
INFO - 2023-07-01 11:33:11 --> URI Class Initialized
INFO - 2023-07-01 11:33:11 --> Router Class Initialized
INFO - 2023-07-01 11:33:11 --> Output Class Initialized
INFO - 2023-07-01 11:33:11 --> Security Class Initialized
DEBUG - 2023-07-01 11:33:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-01 11:33:11 --> Input Class Initialized
INFO - 2023-07-01 11:33:11 --> Language Class Initialized
INFO - 2023-07-01 11:33:11 --> Loader Class Initialized
INFO - 2023-07-01 11:33:11 --> Helper loaded: url_helper
INFO - 2023-07-01 11:33:11 --> Helper loaded: file_helper
INFO - 2023-07-01 11:33:11 --> Helper loaded: html_helper
INFO - 2023-07-01 11:33:11 --> Helper loaded: text_helper
INFO - 2023-07-01 11:33:11 --> Helper loaded: form_helper
INFO - 2023-07-01 11:33:11 --> Helper loaded: lang_helper
INFO - 2023-07-01 11:33:11 --> Helper loaded: security_helper
INFO - 2023-07-01 11:33:11 --> Helper loaded: cookie_helper
INFO - 2023-07-01 11:33:11 --> Database Driver Class Initialized
INFO - 2023-07-01 11:33:11 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-01 11:33:11 --> Parser Class Initialized
INFO - 2023-07-01 11:33:11 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-01 11:33:11 --> Pagination Class Initialized
INFO - 2023-07-01 11:33:11 --> Form Validation Class Initialized
INFO - 2023-07-01 11:33:11 --> Controller Class Initialized
INFO - 2023-07-01 11:33:11 --> Model Class Initialized
DEBUG - 2023-07-01 11:33:11 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-01 11:33:11 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-01 11:33:11 --> Model Class Initialized
DEBUG - 2023-07-01 11:33:11 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-01 11:33:11 --> Model Class Initialized
INFO - 2023-07-01 11:33:11 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/add_invoice_form.php
DEBUG - 2023-07-01 11:33:11 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-07-01 11:33:11 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-07-01 11:33:11 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-07-01 11:33:11 --> Model Class Initialized
INFO - 2023-07-01 11:33:11 --> Model Class Initialized
INFO - 2023-07-01 11:33:11 --> Model Class Initialized
INFO - 2023-07-01 11:33:11 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-07-01 11:33:11 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-07-01 11:33:11 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-07-01 11:33:11 --> Final output sent to browser
DEBUG - 2023-07-01 11:33:11 --> Total execution time: 0.1706
ERROR - 2023-07-01 11:36:46 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-01 11:36:46 --> Config Class Initialized
INFO - 2023-07-01 11:36:46 --> Hooks Class Initialized
DEBUG - 2023-07-01 11:36:46 --> UTF-8 Support Enabled
INFO - 2023-07-01 11:36:46 --> Utf8 Class Initialized
INFO - 2023-07-01 11:36:46 --> URI Class Initialized
DEBUG - 2023-07-01 11:36:46 --> No URI present. Default controller set.
INFO - 2023-07-01 11:36:46 --> Router Class Initialized
INFO - 2023-07-01 11:36:46 --> Output Class Initialized
INFO - 2023-07-01 11:36:46 --> Security Class Initialized
DEBUG - 2023-07-01 11:36:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-01 11:36:46 --> Input Class Initialized
INFO - 2023-07-01 11:36:46 --> Language Class Initialized
INFO - 2023-07-01 11:36:46 --> Loader Class Initialized
INFO - 2023-07-01 11:36:46 --> Helper loaded: url_helper
INFO - 2023-07-01 11:36:46 --> Helper loaded: file_helper
INFO - 2023-07-01 11:36:46 --> Helper loaded: html_helper
INFO - 2023-07-01 11:36:46 --> Helper loaded: text_helper
INFO - 2023-07-01 11:36:46 --> Helper loaded: form_helper
INFO - 2023-07-01 11:36:46 --> Helper loaded: lang_helper
INFO - 2023-07-01 11:36:46 --> Helper loaded: security_helper
INFO - 2023-07-01 11:36:46 --> Helper loaded: cookie_helper
INFO - 2023-07-01 11:36:46 --> Database Driver Class Initialized
INFO - 2023-07-01 11:36:46 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-01 11:36:46 --> Parser Class Initialized
INFO - 2023-07-01 11:36:46 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-01 11:36:46 --> Pagination Class Initialized
INFO - 2023-07-01 11:36:46 --> Form Validation Class Initialized
INFO - 2023-07-01 11:36:46 --> Controller Class Initialized
INFO - 2023-07-01 11:36:46 --> Model Class Initialized
DEBUG - 2023-07-01 11:36:46 --> Session class already loaded. Second attempt ignored.
ERROR - 2023-07-01 11:37:38 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-01 11:37:38 --> Config Class Initialized
INFO - 2023-07-01 11:37:38 --> Hooks Class Initialized
DEBUG - 2023-07-01 11:37:38 --> UTF-8 Support Enabled
INFO - 2023-07-01 11:37:38 --> Utf8 Class Initialized
INFO - 2023-07-01 11:37:38 --> URI Class Initialized
INFO - 2023-07-01 11:37:38 --> Router Class Initialized
INFO - 2023-07-01 11:37:38 --> Output Class Initialized
INFO - 2023-07-01 11:37:38 --> Security Class Initialized
DEBUG - 2023-07-01 11:37:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-01 11:37:38 --> Input Class Initialized
INFO - 2023-07-01 11:37:38 --> Language Class Initialized
INFO - 2023-07-01 11:37:38 --> Loader Class Initialized
INFO - 2023-07-01 11:37:38 --> Helper loaded: url_helper
INFO - 2023-07-01 11:37:38 --> Helper loaded: file_helper
INFO - 2023-07-01 11:37:38 --> Helper loaded: html_helper
INFO - 2023-07-01 11:37:38 --> Helper loaded: text_helper
INFO - 2023-07-01 11:37:38 --> Helper loaded: form_helper
INFO - 2023-07-01 11:37:38 --> Helper loaded: lang_helper
INFO - 2023-07-01 11:37:38 --> Helper loaded: security_helper
INFO - 2023-07-01 11:37:38 --> Helper loaded: cookie_helper
INFO - 2023-07-01 11:37:38 --> Database Driver Class Initialized
INFO - 2023-07-01 11:37:38 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-01 11:37:38 --> Parser Class Initialized
INFO - 2023-07-01 11:37:38 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-01 11:37:38 --> Pagination Class Initialized
INFO - 2023-07-01 11:37:38 --> Form Validation Class Initialized
INFO - 2023-07-01 11:37:38 --> Controller Class Initialized
INFO - 2023-07-01 11:37:38 --> Model Class Initialized
DEBUG - 2023-07-01 11:37:38 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-01 11:37:38 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-01 11:37:38 --> Model Class Initialized
DEBUG - 2023-07-01 11:37:38 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-01 11:37:38 --> Model Class Initialized
INFO - 2023-07-01 11:37:38 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice.php
DEBUG - 2023-07-01 11:37:38 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-07-01 11:37:38 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-07-01 11:37:38 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-07-01 11:37:38 --> Model Class Initialized
INFO - 2023-07-01 11:37:38 --> Model Class Initialized
INFO - 2023-07-01 11:37:38 --> Model Class Initialized
INFO - 2023-07-01 11:37:38 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-07-01 11:37:38 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-07-01 11:37:38 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-07-01 11:37:38 --> Final output sent to browser
DEBUG - 2023-07-01 11:37:38 --> Total execution time: 0.1454
ERROR - 2023-07-01 11:37:38 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-01 11:37:38 --> Config Class Initialized
INFO - 2023-07-01 11:37:38 --> Hooks Class Initialized
DEBUG - 2023-07-01 11:37:38 --> UTF-8 Support Enabled
INFO - 2023-07-01 11:37:38 --> Utf8 Class Initialized
INFO - 2023-07-01 11:37:38 --> URI Class Initialized
INFO - 2023-07-01 11:37:38 --> Router Class Initialized
INFO - 2023-07-01 11:37:38 --> Output Class Initialized
INFO - 2023-07-01 11:37:38 --> Security Class Initialized
DEBUG - 2023-07-01 11:37:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-01 11:37:38 --> Input Class Initialized
INFO - 2023-07-01 11:37:38 --> Language Class Initialized
INFO - 2023-07-01 11:37:38 --> Loader Class Initialized
INFO - 2023-07-01 11:37:38 --> Helper loaded: url_helper
INFO - 2023-07-01 11:37:38 --> Helper loaded: file_helper
INFO - 2023-07-01 11:37:38 --> Helper loaded: html_helper
INFO - 2023-07-01 11:37:38 --> Helper loaded: text_helper
INFO - 2023-07-01 11:37:38 --> Helper loaded: form_helper
INFO - 2023-07-01 11:37:38 --> Helper loaded: lang_helper
INFO - 2023-07-01 11:37:38 --> Helper loaded: security_helper
INFO - 2023-07-01 11:37:38 --> Helper loaded: cookie_helper
INFO - 2023-07-01 11:37:38 --> Database Driver Class Initialized
INFO - 2023-07-01 11:37:38 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-01 11:37:38 --> Parser Class Initialized
INFO - 2023-07-01 11:37:38 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-01 11:37:38 --> Pagination Class Initialized
INFO - 2023-07-01 11:37:38 --> Form Validation Class Initialized
INFO - 2023-07-01 11:37:38 --> Controller Class Initialized
INFO - 2023-07-01 11:37:38 --> Model Class Initialized
DEBUG - 2023-07-01 11:37:38 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-01 11:37:38 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-01 11:37:38 --> Model Class Initialized
DEBUG - 2023-07-01 11:37:38 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-01 11:37:38 --> Model Class Initialized
INFO - 2023-07-01 11:37:38 --> Final output sent to browser
DEBUG - 2023-07-01 11:37:38 --> Total execution time: 0.0600
ERROR - 2023-07-01 11:37:49 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-01 11:37:49 --> Config Class Initialized
INFO - 2023-07-01 11:37:49 --> Hooks Class Initialized
DEBUG - 2023-07-01 11:37:49 --> UTF-8 Support Enabled
INFO - 2023-07-01 11:37:49 --> Utf8 Class Initialized
INFO - 2023-07-01 11:37:49 --> URI Class Initialized
INFO - 2023-07-01 11:37:49 --> Router Class Initialized
INFO - 2023-07-01 11:37:49 --> Output Class Initialized
INFO - 2023-07-01 11:37:49 --> Security Class Initialized
DEBUG - 2023-07-01 11:37:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-01 11:37:49 --> Input Class Initialized
INFO - 2023-07-01 11:37:49 --> Language Class Initialized
INFO - 2023-07-01 11:37:49 --> Loader Class Initialized
INFO - 2023-07-01 11:37:49 --> Helper loaded: url_helper
INFO - 2023-07-01 11:37:49 --> Helper loaded: file_helper
INFO - 2023-07-01 11:37:49 --> Helper loaded: html_helper
INFO - 2023-07-01 11:37:49 --> Helper loaded: text_helper
INFO - 2023-07-01 11:37:49 --> Helper loaded: form_helper
INFO - 2023-07-01 11:37:49 --> Helper loaded: lang_helper
INFO - 2023-07-01 11:37:49 --> Helper loaded: security_helper
INFO - 2023-07-01 11:37:49 --> Helper loaded: cookie_helper
INFO - 2023-07-01 11:37:49 --> Database Driver Class Initialized
INFO - 2023-07-01 11:37:49 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-01 11:37:49 --> Parser Class Initialized
INFO - 2023-07-01 11:37:49 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-01 11:37:49 --> Pagination Class Initialized
INFO - 2023-07-01 11:37:49 --> Form Validation Class Initialized
INFO - 2023-07-01 11:37:49 --> Controller Class Initialized
INFO - 2023-07-01 11:37:49 --> Model Class Initialized
DEBUG - 2023-07-01 11:37:49 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-01 11:37:49 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-01 11:37:49 --> Model Class Initialized
DEBUG - 2023-07-01 11:37:49 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-01 11:37:49 --> Model Class Initialized
INFO - 2023-07-01 11:37:49 --> Final output sent to browser
DEBUG - 2023-07-01 11:37:49 --> Total execution time: 0.3469
ERROR - 2023-07-01 11:45:00 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-01 11:45:00 --> Config Class Initialized
INFO - 2023-07-01 11:45:00 --> Hooks Class Initialized
DEBUG - 2023-07-01 11:45:00 --> UTF-8 Support Enabled
INFO - 2023-07-01 11:45:00 --> Utf8 Class Initialized
INFO - 2023-07-01 11:45:00 --> URI Class Initialized
INFO - 2023-07-01 11:45:00 --> Router Class Initialized
INFO - 2023-07-01 11:45:00 --> Output Class Initialized
INFO - 2023-07-01 11:45:00 --> Security Class Initialized
DEBUG - 2023-07-01 11:45:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-01 11:45:00 --> Input Class Initialized
INFO - 2023-07-01 11:45:00 --> Language Class Initialized
INFO - 2023-07-01 11:45:00 --> Loader Class Initialized
INFO - 2023-07-01 11:45:00 --> Helper loaded: url_helper
INFO - 2023-07-01 11:45:00 --> Helper loaded: file_helper
INFO - 2023-07-01 11:45:00 --> Helper loaded: html_helper
INFO - 2023-07-01 11:45:00 --> Helper loaded: text_helper
INFO - 2023-07-01 11:45:00 --> Helper loaded: form_helper
INFO - 2023-07-01 11:45:00 --> Helper loaded: lang_helper
INFO - 2023-07-01 11:45:00 --> Helper loaded: security_helper
INFO - 2023-07-01 11:45:00 --> Helper loaded: cookie_helper
INFO - 2023-07-01 11:45:00 --> Database Driver Class Initialized
INFO - 2023-07-01 11:45:00 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-01 11:45:00 --> Parser Class Initialized
INFO - 2023-07-01 11:45:00 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-01 11:45:00 --> Pagination Class Initialized
INFO - 2023-07-01 11:45:00 --> Form Validation Class Initialized
INFO - 2023-07-01 11:45:00 --> Controller Class Initialized
INFO - 2023-07-01 11:45:00 --> Model Class Initialized
DEBUG - 2023-07-01 11:45:00 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-01 11:45:00 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-01 11:45:00 --> Model Class Initialized
DEBUG - 2023-07-01 11:45:00 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-01 11:45:00 --> Model Class Initialized
INFO - 2023-07-01 11:45:00 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice.php
DEBUG - 2023-07-01 11:45:00 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-07-01 11:45:00 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-07-01 11:45:00 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-07-01 11:45:00 --> Model Class Initialized
INFO - 2023-07-01 11:45:00 --> Model Class Initialized
INFO - 2023-07-01 11:45:00 --> Model Class Initialized
INFO - 2023-07-01 11:45:00 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-07-01 11:45:00 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-07-01 11:45:00 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-07-01 11:45:00 --> Final output sent to browser
DEBUG - 2023-07-01 11:45:00 --> Total execution time: 0.1576
ERROR - 2023-07-01 11:45:01 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-01 11:45:01 --> Config Class Initialized
INFO - 2023-07-01 11:45:01 --> Hooks Class Initialized
DEBUG - 2023-07-01 11:45:01 --> UTF-8 Support Enabled
INFO - 2023-07-01 11:45:01 --> Utf8 Class Initialized
INFO - 2023-07-01 11:45:01 --> URI Class Initialized
INFO - 2023-07-01 11:45:01 --> Router Class Initialized
INFO - 2023-07-01 11:45:01 --> Output Class Initialized
INFO - 2023-07-01 11:45:01 --> Security Class Initialized
DEBUG - 2023-07-01 11:45:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-01 11:45:01 --> Input Class Initialized
INFO - 2023-07-01 11:45:01 --> Language Class Initialized
INFO - 2023-07-01 11:45:01 --> Loader Class Initialized
INFO - 2023-07-01 11:45:01 --> Helper loaded: url_helper
INFO - 2023-07-01 11:45:01 --> Helper loaded: file_helper
INFO - 2023-07-01 11:45:01 --> Helper loaded: html_helper
INFO - 2023-07-01 11:45:01 --> Helper loaded: text_helper
INFO - 2023-07-01 11:45:01 --> Helper loaded: form_helper
INFO - 2023-07-01 11:45:01 --> Helper loaded: lang_helper
INFO - 2023-07-01 11:45:01 --> Helper loaded: security_helper
INFO - 2023-07-01 11:45:01 --> Helper loaded: cookie_helper
INFO - 2023-07-01 11:45:01 --> Database Driver Class Initialized
INFO - 2023-07-01 11:45:01 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-01 11:45:01 --> Parser Class Initialized
INFO - 2023-07-01 11:45:01 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-01 11:45:01 --> Pagination Class Initialized
INFO - 2023-07-01 11:45:01 --> Form Validation Class Initialized
INFO - 2023-07-01 11:45:01 --> Controller Class Initialized
INFO - 2023-07-01 11:45:01 --> Model Class Initialized
DEBUG - 2023-07-01 11:45:01 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-01 11:45:01 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-01 11:45:01 --> Model Class Initialized
DEBUG - 2023-07-01 11:45:01 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-01 11:45:01 --> Model Class Initialized
INFO - 2023-07-01 11:45:01 --> Final output sent to browser
DEBUG - 2023-07-01 11:45:01 --> Total execution time: 0.0598
ERROR - 2023-07-01 11:45:04 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-01 11:45:04 --> Config Class Initialized
INFO - 2023-07-01 11:45:04 --> Hooks Class Initialized
DEBUG - 2023-07-01 11:45:04 --> UTF-8 Support Enabled
INFO - 2023-07-01 11:45:04 --> Utf8 Class Initialized
INFO - 2023-07-01 11:45:04 --> URI Class Initialized
INFO - 2023-07-01 11:45:04 --> Router Class Initialized
INFO - 2023-07-01 11:45:04 --> Output Class Initialized
INFO - 2023-07-01 11:45:04 --> Security Class Initialized
DEBUG - 2023-07-01 11:45:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-01 11:45:04 --> Input Class Initialized
INFO - 2023-07-01 11:45:04 --> Language Class Initialized
INFO - 2023-07-01 11:45:04 --> Loader Class Initialized
INFO - 2023-07-01 11:45:04 --> Helper loaded: url_helper
INFO - 2023-07-01 11:45:04 --> Helper loaded: file_helper
INFO - 2023-07-01 11:45:04 --> Helper loaded: html_helper
INFO - 2023-07-01 11:45:04 --> Helper loaded: text_helper
INFO - 2023-07-01 11:45:04 --> Helper loaded: form_helper
INFO - 2023-07-01 11:45:04 --> Helper loaded: lang_helper
INFO - 2023-07-01 11:45:04 --> Helper loaded: security_helper
INFO - 2023-07-01 11:45:04 --> Helper loaded: cookie_helper
INFO - 2023-07-01 11:45:04 --> Database Driver Class Initialized
INFO - 2023-07-01 11:45:04 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-01 11:45:04 --> Parser Class Initialized
INFO - 2023-07-01 11:45:04 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-01 11:45:04 --> Pagination Class Initialized
INFO - 2023-07-01 11:45:04 --> Form Validation Class Initialized
INFO - 2023-07-01 11:45:04 --> Controller Class Initialized
INFO - 2023-07-01 11:45:04 --> Model Class Initialized
DEBUG - 2023-07-01 11:45:04 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-01 11:45:04 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-01 11:45:04 --> Model Class Initialized
DEBUG - 2023-07-01 11:45:04 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-01 11:45:04 --> Model Class Initialized
INFO - 2023-07-01 11:45:04 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice.php
DEBUG - 2023-07-01 11:45:04 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-07-01 11:45:04 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-07-01 11:45:04 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-07-01 11:45:04 --> Model Class Initialized
INFO - 2023-07-01 11:45:04 --> Model Class Initialized
INFO - 2023-07-01 11:45:04 --> Model Class Initialized
INFO - 2023-07-01 11:45:04 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-07-01 11:45:04 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-07-01 11:45:04 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-07-01 11:45:04 --> Final output sent to browser
DEBUG - 2023-07-01 11:45:04 --> Total execution time: 0.1384
ERROR - 2023-07-01 11:45:05 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-01 11:45:05 --> Config Class Initialized
INFO - 2023-07-01 11:45:05 --> Hooks Class Initialized
DEBUG - 2023-07-01 11:45:05 --> UTF-8 Support Enabled
INFO - 2023-07-01 11:45:05 --> Utf8 Class Initialized
INFO - 2023-07-01 11:45:05 --> URI Class Initialized
INFO - 2023-07-01 11:45:05 --> Router Class Initialized
INFO - 2023-07-01 11:45:05 --> Output Class Initialized
INFO - 2023-07-01 11:45:05 --> Security Class Initialized
DEBUG - 2023-07-01 11:45:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-01 11:45:05 --> Input Class Initialized
INFO - 2023-07-01 11:45:05 --> Language Class Initialized
INFO - 2023-07-01 11:45:05 --> Loader Class Initialized
INFO - 2023-07-01 11:45:05 --> Helper loaded: url_helper
INFO - 2023-07-01 11:45:05 --> Helper loaded: file_helper
INFO - 2023-07-01 11:45:05 --> Helper loaded: html_helper
INFO - 2023-07-01 11:45:05 --> Helper loaded: text_helper
INFO - 2023-07-01 11:45:05 --> Helper loaded: form_helper
INFO - 2023-07-01 11:45:05 --> Helper loaded: lang_helper
INFO - 2023-07-01 11:45:05 --> Helper loaded: security_helper
INFO - 2023-07-01 11:45:05 --> Helper loaded: cookie_helper
INFO - 2023-07-01 11:45:05 --> Database Driver Class Initialized
INFO - 2023-07-01 11:45:05 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-01 11:45:05 --> Parser Class Initialized
INFO - 2023-07-01 11:45:05 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-01 11:45:05 --> Pagination Class Initialized
INFO - 2023-07-01 11:45:05 --> Form Validation Class Initialized
INFO - 2023-07-01 11:45:05 --> Controller Class Initialized
INFO - 2023-07-01 11:45:05 --> Model Class Initialized
DEBUG - 2023-07-01 11:45:05 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-01 11:45:05 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-01 11:45:05 --> Model Class Initialized
DEBUG - 2023-07-01 11:45:05 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-01 11:45:05 --> Model Class Initialized
INFO - 2023-07-01 11:45:05 --> Final output sent to browser
DEBUG - 2023-07-01 11:45:05 --> Total execution time: 0.0611
ERROR - 2023-07-01 11:45:30 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-01 11:45:30 --> Config Class Initialized
INFO - 2023-07-01 11:45:30 --> Hooks Class Initialized
DEBUG - 2023-07-01 11:45:30 --> UTF-8 Support Enabled
INFO - 2023-07-01 11:45:30 --> Utf8 Class Initialized
INFO - 2023-07-01 11:45:30 --> URI Class Initialized
INFO - 2023-07-01 11:45:30 --> Router Class Initialized
INFO - 2023-07-01 11:45:30 --> Output Class Initialized
INFO - 2023-07-01 11:45:30 --> Security Class Initialized
DEBUG - 2023-07-01 11:45:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-01 11:45:30 --> Input Class Initialized
INFO - 2023-07-01 11:45:30 --> Language Class Initialized
INFO - 2023-07-01 11:45:30 --> Loader Class Initialized
INFO - 2023-07-01 11:45:30 --> Helper loaded: url_helper
INFO - 2023-07-01 11:45:30 --> Helper loaded: file_helper
INFO - 2023-07-01 11:45:30 --> Helper loaded: html_helper
INFO - 2023-07-01 11:45:30 --> Helper loaded: text_helper
INFO - 2023-07-01 11:45:30 --> Helper loaded: form_helper
INFO - 2023-07-01 11:45:30 --> Helper loaded: lang_helper
INFO - 2023-07-01 11:45:30 --> Helper loaded: security_helper
INFO - 2023-07-01 11:45:30 --> Helper loaded: cookie_helper
INFO - 2023-07-01 11:45:30 --> Database Driver Class Initialized
INFO - 2023-07-01 11:45:30 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-01 11:45:30 --> Parser Class Initialized
INFO - 2023-07-01 11:45:30 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-01 11:45:30 --> Pagination Class Initialized
INFO - 2023-07-01 11:45:30 --> Form Validation Class Initialized
INFO - 2023-07-01 11:45:30 --> Controller Class Initialized
INFO - 2023-07-01 11:45:30 --> Model Class Initialized
DEBUG - 2023-07-01 11:45:30 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-01 11:45:30 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-01 11:45:30 --> Model Class Initialized
DEBUG - 2023-07-01 11:45:30 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-01 11:45:30 --> Model Class Initialized
INFO - 2023-07-01 11:45:31 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/add_invoice_form.php
DEBUG - 2023-07-01 11:45:31 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-07-01 11:45:31 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-07-01 11:45:31 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-07-01 11:45:31 --> Model Class Initialized
INFO - 2023-07-01 11:45:31 --> Model Class Initialized
INFO - 2023-07-01 11:45:31 --> Model Class Initialized
INFO - 2023-07-01 11:45:31 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-07-01 11:45:31 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-07-01 11:45:31 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-07-01 11:45:31 --> Final output sent to browser
DEBUG - 2023-07-01 11:45:31 --> Total execution time: 0.1663
ERROR - 2023-07-01 11:47:49 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-01 11:47:49 --> Config Class Initialized
INFO - 2023-07-01 11:47:49 --> Hooks Class Initialized
DEBUG - 2023-07-01 11:47:49 --> UTF-8 Support Enabled
INFO - 2023-07-01 11:47:49 --> Utf8 Class Initialized
INFO - 2023-07-01 11:47:49 --> URI Class Initialized
INFO - 2023-07-01 11:47:49 --> Router Class Initialized
INFO - 2023-07-01 11:47:49 --> Output Class Initialized
INFO - 2023-07-01 11:47:49 --> Security Class Initialized
DEBUG - 2023-07-01 11:47:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-01 11:47:49 --> Input Class Initialized
INFO - 2023-07-01 11:47:49 --> Language Class Initialized
INFO - 2023-07-01 11:47:49 --> Loader Class Initialized
INFO - 2023-07-01 11:47:49 --> Helper loaded: url_helper
INFO - 2023-07-01 11:47:49 --> Helper loaded: file_helper
INFO - 2023-07-01 11:47:49 --> Helper loaded: html_helper
INFO - 2023-07-01 11:47:49 --> Helper loaded: text_helper
INFO - 2023-07-01 11:47:49 --> Helper loaded: form_helper
INFO - 2023-07-01 11:47:49 --> Helper loaded: lang_helper
INFO - 2023-07-01 11:47:49 --> Helper loaded: security_helper
INFO - 2023-07-01 11:47:49 --> Helper loaded: cookie_helper
INFO - 2023-07-01 11:47:49 --> Database Driver Class Initialized
INFO - 2023-07-01 11:47:49 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-01 11:47:49 --> Parser Class Initialized
INFO - 2023-07-01 11:47:49 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-01 11:47:49 --> Pagination Class Initialized
INFO - 2023-07-01 11:47:49 --> Form Validation Class Initialized
INFO - 2023-07-01 11:47:49 --> Controller Class Initialized
INFO - 2023-07-01 11:47:49 --> Model Class Initialized
DEBUG - 2023-07-01 11:47:49 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-01 11:47:49 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-01 11:47:49 --> Model Class Initialized
DEBUG - 2023-07-01 11:47:49 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-01 11:47:49 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/demandrequest/add_demandrequest_form.php
DEBUG - 2023-07-01 11:47:49 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-07-01 11:47:49 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-07-01 11:47:49 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-07-01 11:47:49 --> Model Class Initialized
INFO - 2023-07-01 11:47:49 --> Model Class Initialized
INFO - 2023-07-01 11:47:49 --> Model Class Initialized
INFO - 2023-07-01 11:47:49 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-07-01 11:47:49 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-07-01 11:47:49 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-07-01 11:47:49 --> Final output sent to browser
DEBUG - 2023-07-01 11:47:49 --> Total execution time: 0.1514
ERROR - 2023-07-01 11:48:00 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-01 11:48:00 --> Config Class Initialized
INFO - 2023-07-01 11:48:00 --> Hooks Class Initialized
DEBUG - 2023-07-01 11:48:00 --> UTF-8 Support Enabled
INFO - 2023-07-01 11:48:00 --> Utf8 Class Initialized
INFO - 2023-07-01 11:48:00 --> URI Class Initialized
INFO - 2023-07-01 11:48:00 --> Router Class Initialized
INFO - 2023-07-01 11:48:00 --> Output Class Initialized
INFO - 2023-07-01 11:48:00 --> Security Class Initialized
DEBUG - 2023-07-01 11:48:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-01 11:48:00 --> Input Class Initialized
INFO - 2023-07-01 11:48:00 --> Language Class Initialized
INFO - 2023-07-01 11:48:00 --> Loader Class Initialized
INFO - 2023-07-01 11:48:00 --> Helper loaded: url_helper
INFO - 2023-07-01 11:48:00 --> Helper loaded: file_helper
INFO - 2023-07-01 11:48:00 --> Helper loaded: html_helper
INFO - 2023-07-01 11:48:00 --> Helper loaded: text_helper
INFO - 2023-07-01 11:48:00 --> Helper loaded: form_helper
INFO - 2023-07-01 11:48:00 --> Helper loaded: lang_helper
INFO - 2023-07-01 11:48:00 --> Helper loaded: security_helper
INFO - 2023-07-01 11:48:00 --> Helper loaded: cookie_helper
INFO - 2023-07-01 11:48:00 --> Database Driver Class Initialized
INFO - 2023-07-01 11:48:00 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-01 11:48:00 --> Parser Class Initialized
INFO - 2023-07-01 11:48:00 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-01 11:48:00 --> Pagination Class Initialized
INFO - 2023-07-01 11:48:00 --> Form Validation Class Initialized
INFO - 2023-07-01 11:48:00 --> Controller Class Initialized
INFO - 2023-07-01 11:48:00 --> Model Class Initialized
DEBUG - 2023-07-01 11:48:00 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-01 11:48:00 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-01 11:48:00 --> Model Class Initialized
INFO - 2023-07-01 11:48:00 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/demandrequest/demandrequest.php
DEBUG - 2023-07-01 11:48:00 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-07-01 11:48:00 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-07-01 11:48:00 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-07-01 11:48:00 --> Model Class Initialized
INFO - 2023-07-01 11:48:00 --> Model Class Initialized
INFO - 2023-07-01 11:48:00 --> Model Class Initialized
INFO - 2023-07-01 11:48:00 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-07-01 11:48:00 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-07-01 11:48:00 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-07-01 11:48:00 --> Final output sent to browser
DEBUG - 2023-07-01 11:48:00 --> Total execution time: 0.1427
ERROR - 2023-07-01 11:48:01 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-01 11:48:01 --> Config Class Initialized
INFO - 2023-07-01 11:48:01 --> Hooks Class Initialized
DEBUG - 2023-07-01 11:48:01 --> UTF-8 Support Enabled
INFO - 2023-07-01 11:48:01 --> Utf8 Class Initialized
INFO - 2023-07-01 11:48:01 --> URI Class Initialized
INFO - 2023-07-01 11:48:01 --> Router Class Initialized
INFO - 2023-07-01 11:48:01 --> Output Class Initialized
INFO - 2023-07-01 11:48:01 --> Security Class Initialized
DEBUG - 2023-07-01 11:48:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-01 11:48:01 --> Input Class Initialized
INFO - 2023-07-01 11:48:01 --> Language Class Initialized
INFO - 2023-07-01 11:48:01 --> Loader Class Initialized
INFO - 2023-07-01 11:48:01 --> Helper loaded: url_helper
INFO - 2023-07-01 11:48:01 --> Helper loaded: file_helper
INFO - 2023-07-01 11:48:01 --> Helper loaded: html_helper
INFO - 2023-07-01 11:48:01 --> Helper loaded: text_helper
INFO - 2023-07-01 11:48:01 --> Helper loaded: form_helper
INFO - 2023-07-01 11:48:01 --> Helper loaded: lang_helper
INFO - 2023-07-01 11:48:01 --> Helper loaded: security_helper
INFO - 2023-07-01 11:48:01 --> Helper loaded: cookie_helper
INFO - 2023-07-01 11:48:01 --> Database Driver Class Initialized
INFO - 2023-07-01 11:48:01 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-01 11:48:01 --> Parser Class Initialized
INFO - 2023-07-01 11:48:01 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-01 11:48:01 --> Pagination Class Initialized
INFO - 2023-07-01 11:48:01 --> Form Validation Class Initialized
INFO - 2023-07-01 11:48:01 --> Controller Class Initialized
INFO - 2023-07-01 11:48:01 --> Model Class Initialized
DEBUG - 2023-07-01 11:48:01 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-01 11:48:01 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-01 11:48:01 --> Model Class Initialized
INFO - 2023-07-01 11:48:01 --> Final output sent to browser
DEBUG - 2023-07-01 11:48:01 --> Total execution time: 0.0172
ERROR - 2023-07-01 11:48:05 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-01 11:48:05 --> Config Class Initialized
INFO - 2023-07-01 11:48:05 --> Hooks Class Initialized
DEBUG - 2023-07-01 11:48:05 --> UTF-8 Support Enabled
INFO - 2023-07-01 11:48:05 --> Utf8 Class Initialized
INFO - 2023-07-01 11:48:05 --> URI Class Initialized
INFO - 2023-07-01 11:48:05 --> Router Class Initialized
INFO - 2023-07-01 11:48:05 --> Output Class Initialized
INFO - 2023-07-01 11:48:05 --> Security Class Initialized
DEBUG - 2023-07-01 11:48:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-01 11:48:05 --> Input Class Initialized
INFO - 2023-07-01 11:48:05 --> Language Class Initialized
INFO - 2023-07-01 11:48:05 --> Loader Class Initialized
INFO - 2023-07-01 11:48:05 --> Helper loaded: url_helper
INFO - 2023-07-01 11:48:05 --> Helper loaded: file_helper
INFO - 2023-07-01 11:48:05 --> Helper loaded: html_helper
INFO - 2023-07-01 11:48:05 --> Helper loaded: text_helper
INFO - 2023-07-01 11:48:05 --> Helper loaded: form_helper
INFO - 2023-07-01 11:48:05 --> Helper loaded: lang_helper
INFO - 2023-07-01 11:48:05 --> Helper loaded: security_helper
INFO - 2023-07-01 11:48:05 --> Helper loaded: cookie_helper
INFO - 2023-07-01 11:48:05 --> Database Driver Class Initialized
INFO - 2023-07-01 11:48:05 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-01 11:48:05 --> Parser Class Initialized
INFO - 2023-07-01 11:48:05 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-01 11:48:05 --> Pagination Class Initialized
INFO - 2023-07-01 11:48:05 --> Form Validation Class Initialized
INFO - 2023-07-01 11:48:05 --> Controller Class Initialized
INFO - 2023-07-01 11:48:05 --> Model Class Initialized
DEBUG - 2023-07-01 11:48:05 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-01 11:48:05 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-01 11:48:05 --> Model Class Initialized
INFO - 2023-07-01 11:48:05 --> Final output sent to browser
DEBUG - 2023-07-01 11:48:05 --> Total execution time: 0.0147
ERROR - 2023-07-01 11:51:18 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-01 11:51:18 --> Config Class Initialized
INFO - 2023-07-01 11:51:18 --> Hooks Class Initialized
DEBUG - 2023-07-01 11:51:18 --> UTF-8 Support Enabled
INFO - 2023-07-01 11:51:18 --> Utf8 Class Initialized
INFO - 2023-07-01 11:51:18 --> URI Class Initialized
INFO - 2023-07-01 11:51:18 --> Router Class Initialized
INFO - 2023-07-01 11:51:18 --> Output Class Initialized
INFO - 2023-07-01 11:51:18 --> Security Class Initialized
DEBUG - 2023-07-01 11:51:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-01 11:51:18 --> Input Class Initialized
INFO - 2023-07-01 11:51:18 --> Language Class Initialized
INFO - 2023-07-01 11:51:18 --> Loader Class Initialized
INFO - 2023-07-01 11:51:18 --> Helper loaded: url_helper
INFO - 2023-07-01 11:51:18 --> Helper loaded: file_helper
INFO - 2023-07-01 11:51:18 --> Helper loaded: html_helper
INFO - 2023-07-01 11:51:18 --> Helper loaded: text_helper
INFO - 2023-07-01 11:51:18 --> Helper loaded: form_helper
INFO - 2023-07-01 11:51:18 --> Helper loaded: lang_helper
INFO - 2023-07-01 11:51:18 --> Helper loaded: security_helper
INFO - 2023-07-01 11:51:18 --> Helper loaded: cookie_helper
INFO - 2023-07-01 11:51:18 --> Database Driver Class Initialized
INFO - 2023-07-01 11:51:18 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-01 11:51:18 --> Parser Class Initialized
INFO - 2023-07-01 11:51:18 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-01 11:51:18 --> Pagination Class Initialized
INFO - 2023-07-01 11:51:18 --> Form Validation Class Initialized
INFO - 2023-07-01 11:51:18 --> Controller Class Initialized
INFO - 2023-07-01 11:51:18 --> Model Class Initialized
DEBUG - 2023-07-01 11:51:18 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-01 11:51:18 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-01 11:51:18 --> Model Class Initialized
DEBUG - 2023-07-01 11:51:18 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-01 11:51:18 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/stockrequest/add_stockrequest_form.php
DEBUG - 2023-07-01 11:51:18 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-07-01 11:51:18 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-07-01 11:51:18 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-07-01 11:51:18 --> Model Class Initialized
INFO - 2023-07-01 11:51:18 --> Model Class Initialized
INFO - 2023-07-01 11:51:18 --> Model Class Initialized
INFO - 2023-07-01 11:51:18 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-07-01 11:51:18 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-07-01 11:51:18 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-07-01 11:51:18 --> Final output sent to browser
DEBUG - 2023-07-01 11:51:18 --> Total execution time: 0.1570
ERROR - 2023-07-01 11:51:32 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-01 11:51:32 --> Config Class Initialized
INFO - 2023-07-01 11:51:32 --> Hooks Class Initialized
DEBUG - 2023-07-01 11:51:32 --> UTF-8 Support Enabled
INFO - 2023-07-01 11:51:32 --> Utf8 Class Initialized
INFO - 2023-07-01 11:51:32 --> URI Class Initialized
INFO - 2023-07-01 11:51:32 --> Router Class Initialized
INFO - 2023-07-01 11:51:32 --> Output Class Initialized
INFO - 2023-07-01 11:51:32 --> Security Class Initialized
DEBUG - 2023-07-01 11:51:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-01 11:51:32 --> Input Class Initialized
INFO - 2023-07-01 11:51:32 --> Language Class Initialized
INFO - 2023-07-01 11:51:32 --> Loader Class Initialized
INFO - 2023-07-01 11:51:32 --> Helper loaded: url_helper
INFO - 2023-07-01 11:51:32 --> Helper loaded: file_helper
INFO - 2023-07-01 11:51:32 --> Helper loaded: html_helper
INFO - 2023-07-01 11:51:32 --> Helper loaded: text_helper
INFO - 2023-07-01 11:51:32 --> Helper loaded: form_helper
INFO - 2023-07-01 11:51:32 --> Helper loaded: lang_helper
INFO - 2023-07-01 11:51:32 --> Helper loaded: security_helper
INFO - 2023-07-01 11:51:32 --> Helper loaded: cookie_helper
INFO - 2023-07-01 11:51:32 --> Database Driver Class Initialized
INFO - 2023-07-01 11:51:32 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-01 11:51:32 --> Parser Class Initialized
INFO - 2023-07-01 11:51:32 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-01 11:51:32 --> Pagination Class Initialized
INFO - 2023-07-01 11:51:32 --> Form Validation Class Initialized
INFO - 2023-07-01 11:51:32 --> Controller Class Initialized
INFO - 2023-07-01 11:51:32 --> Model Class Initialized
DEBUG - 2023-07-01 11:51:32 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-01 11:51:32 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-01 11:51:32 --> Model Class Initialized
INFO - 2023-07-01 11:51:32 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/stockrequest/stockrequest.php
DEBUG - 2023-07-01 11:51:32 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-07-01 11:51:32 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-07-01 11:51:32 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-07-01 11:51:32 --> Model Class Initialized
INFO - 2023-07-01 11:51:32 --> Model Class Initialized
INFO - 2023-07-01 11:51:32 --> Model Class Initialized
INFO - 2023-07-01 11:51:33 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-07-01 11:51:33 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-07-01 11:51:33 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-07-01 11:51:33 --> Final output sent to browser
DEBUG - 2023-07-01 11:51:33 --> Total execution time: 0.1679
ERROR - 2023-07-01 11:51:33 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-01 11:51:33 --> Config Class Initialized
INFO - 2023-07-01 11:51:33 --> Hooks Class Initialized
DEBUG - 2023-07-01 11:51:33 --> UTF-8 Support Enabled
INFO - 2023-07-01 11:51:33 --> Utf8 Class Initialized
INFO - 2023-07-01 11:51:33 --> URI Class Initialized
INFO - 2023-07-01 11:51:33 --> Router Class Initialized
INFO - 2023-07-01 11:51:33 --> Output Class Initialized
INFO - 2023-07-01 11:51:33 --> Security Class Initialized
DEBUG - 2023-07-01 11:51:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-01 11:51:33 --> Input Class Initialized
INFO - 2023-07-01 11:51:33 --> Language Class Initialized
INFO - 2023-07-01 11:51:33 --> Loader Class Initialized
INFO - 2023-07-01 11:51:33 --> Helper loaded: url_helper
INFO - 2023-07-01 11:51:33 --> Helper loaded: file_helper
INFO - 2023-07-01 11:51:33 --> Helper loaded: html_helper
INFO - 2023-07-01 11:51:33 --> Helper loaded: text_helper
INFO - 2023-07-01 11:51:33 --> Helper loaded: form_helper
INFO - 2023-07-01 11:51:33 --> Helper loaded: lang_helper
INFO - 2023-07-01 11:51:33 --> Helper loaded: security_helper
INFO - 2023-07-01 11:51:33 --> Helper loaded: cookie_helper
INFO - 2023-07-01 11:51:33 --> Database Driver Class Initialized
INFO - 2023-07-01 11:51:33 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-01 11:51:33 --> Parser Class Initialized
INFO - 2023-07-01 11:51:33 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-01 11:51:33 --> Pagination Class Initialized
INFO - 2023-07-01 11:51:33 --> Form Validation Class Initialized
INFO - 2023-07-01 11:51:33 --> Controller Class Initialized
INFO - 2023-07-01 11:51:33 --> Model Class Initialized
DEBUG - 2023-07-01 11:51:33 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-01 11:51:33 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-01 11:51:33 --> Model Class Initialized
INFO - 2023-07-01 11:51:33 --> Final output sent to browser
DEBUG - 2023-07-01 11:51:33 --> Total execution time: 0.0294
ERROR - 2023-07-01 11:55:17 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-01 11:55:17 --> Config Class Initialized
INFO - 2023-07-01 11:55:17 --> Hooks Class Initialized
DEBUG - 2023-07-01 11:55:17 --> UTF-8 Support Enabled
INFO - 2023-07-01 11:55:17 --> Utf8 Class Initialized
INFO - 2023-07-01 11:55:17 --> URI Class Initialized
INFO - 2023-07-01 11:55:17 --> Router Class Initialized
INFO - 2023-07-01 11:55:17 --> Output Class Initialized
INFO - 2023-07-01 11:55:17 --> Security Class Initialized
DEBUG - 2023-07-01 11:55:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-01 11:55:17 --> Input Class Initialized
INFO - 2023-07-01 11:55:17 --> Language Class Initialized
INFO - 2023-07-01 11:55:17 --> Loader Class Initialized
INFO - 2023-07-01 11:55:17 --> Helper loaded: url_helper
INFO - 2023-07-01 11:55:17 --> Helper loaded: file_helper
INFO - 2023-07-01 11:55:17 --> Helper loaded: html_helper
INFO - 2023-07-01 11:55:17 --> Helper loaded: text_helper
INFO - 2023-07-01 11:55:17 --> Helper loaded: form_helper
INFO - 2023-07-01 11:55:17 --> Helper loaded: lang_helper
INFO - 2023-07-01 11:55:17 --> Helper loaded: security_helper
INFO - 2023-07-01 11:55:17 --> Helper loaded: cookie_helper
INFO - 2023-07-01 11:55:17 --> Database Driver Class Initialized
INFO - 2023-07-01 11:55:17 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-01 11:55:17 --> Parser Class Initialized
INFO - 2023-07-01 11:55:17 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-01 11:55:17 --> Pagination Class Initialized
INFO - 2023-07-01 11:55:17 --> Form Validation Class Initialized
INFO - 2023-07-01 11:55:17 --> Controller Class Initialized
INFO - 2023-07-01 11:55:17 --> Model Class Initialized
DEBUG - 2023-07-01 11:55:17 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-01 11:55:17 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-01 11:55:17 --> Model Class Initialized
DEBUG - 2023-07-01 11:55:17 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-01 11:55:17 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/stockrequest/add_stockrequest_form.php
DEBUG - 2023-07-01 11:55:17 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-07-01 11:55:17 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-07-01 11:55:17 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-07-01 11:55:17 --> Model Class Initialized
INFO - 2023-07-01 11:55:17 --> Model Class Initialized
INFO - 2023-07-01 11:55:17 --> Model Class Initialized
INFO - 2023-07-01 11:55:17 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-07-01 11:55:17 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-07-01 11:55:17 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-07-01 11:55:17 --> Final output sent to browser
DEBUG - 2023-07-01 11:55:17 --> Total execution time: 0.1658
ERROR - 2023-07-01 11:55:38 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-01 11:55:38 --> Config Class Initialized
INFO - 2023-07-01 11:55:38 --> Hooks Class Initialized
DEBUG - 2023-07-01 11:55:38 --> UTF-8 Support Enabled
INFO - 2023-07-01 11:55:38 --> Utf8 Class Initialized
INFO - 2023-07-01 11:55:38 --> URI Class Initialized
INFO - 2023-07-01 11:55:38 --> Router Class Initialized
INFO - 2023-07-01 11:55:38 --> Output Class Initialized
INFO - 2023-07-01 11:55:38 --> Security Class Initialized
DEBUG - 2023-07-01 11:55:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-01 11:55:38 --> Input Class Initialized
INFO - 2023-07-01 11:55:38 --> Language Class Initialized
INFO - 2023-07-01 11:55:38 --> Loader Class Initialized
INFO - 2023-07-01 11:55:38 --> Helper loaded: url_helper
INFO - 2023-07-01 11:55:38 --> Helper loaded: file_helper
INFO - 2023-07-01 11:55:38 --> Helper loaded: html_helper
INFO - 2023-07-01 11:55:38 --> Helper loaded: text_helper
INFO - 2023-07-01 11:55:38 --> Helper loaded: form_helper
INFO - 2023-07-01 11:55:38 --> Helper loaded: lang_helper
INFO - 2023-07-01 11:55:38 --> Helper loaded: security_helper
INFO - 2023-07-01 11:55:38 --> Helper loaded: cookie_helper
INFO - 2023-07-01 11:55:38 --> Database Driver Class Initialized
INFO - 2023-07-01 11:55:38 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-01 11:55:38 --> Parser Class Initialized
INFO - 2023-07-01 11:55:38 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-01 11:55:38 --> Pagination Class Initialized
INFO - 2023-07-01 11:55:38 --> Form Validation Class Initialized
INFO - 2023-07-01 11:55:38 --> Controller Class Initialized
INFO - 2023-07-01 11:55:38 --> Model Class Initialized
DEBUG - 2023-07-01 11:55:38 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-01 11:55:38 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-01 11:55:38 --> Model Class Initialized
INFO - 2023-07-01 11:55:38 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/stockrequest/stockrequest.php
DEBUG - 2023-07-01 11:55:38 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-07-01 11:55:38 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-07-01 11:55:38 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-07-01 11:55:38 --> Model Class Initialized
INFO - 2023-07-01 11:55:38 --> Model Class Initialized
INFO - 2023-07-01 11:55:38 --> Model Class Initialized
INFO - 2023-07-01 11:55:38 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-07-01 11:55:38 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-07-01 11:55:38 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-07-01 11:55:38 --> Final output sent to browser
DEBUG - 2023-07-01 11:55:38 --> Total execution time: 0.1471
ERROR - 2023-07-01 11:55:39 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-01 11:55:39 --> Config Class Initialized
INFO - 2023-07-01 11:55:39 --> Hooks Class Initialized
DEBUG - 2023-07-01 11:55:39 --> UTF-8 Support Enabled
INFO - 2023-07-01 11:55:39 --> Utf8 Class Initialized
INFO - 2023-07-01 11:55:39 --> URI Class Initialized
INFO - 2023-07-01 11:55:39 --> Router Class Initialized
INFO - 2023-07-01 11:55:39 --> Output Class Initialized
INFO - 2023-07-01 11:55:39 --> Security Class Initialized
DEBUG - 2023-07-01 11:55:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-01 11:55:39 --> Input Class Initialized
INFO - 2023-07-01 11:55:39 --> Language Class Initialized
INFO - 2023-07-01 11:55:39 --> Loader Class Initialized
INFO - 2023-07-01 11:55:39 --> Helper loaded: url_helper
INFO - 2023-07-01 11:55:39 --> Helper loaded: file_helper
INFO - 2023-07-01 11:55:39 --> Helper loaded: html_helper
INFO - 2023-07-01 11:55:39 --> Helper loaded: text_helper
INFO - 2023-07-01 11:55:39 --> Helper loaded: form_helper
INFO - 2023-07-01 11:55:39 --> Helper loaded: lang_helper
INFO - 2023-07-01 11:55:39 --> Helper loaded: security_helper
INFO - 2023-07-01 11:55:39 --> Helper loaded: cookie_helper
INFO - 2023-07-01 11:55:39 --> Database Driver Class Initialized
INFO - 2023-07-01 11:55:39 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-01 11:55:39 --> Parser Class Initialized
INFO - 2023-07-01 11:55:39 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-01 11:55:39 --> Pagination Class Initialized
INFO - 2023-07-01 11:55:39 --> Form Validation Class Initialized
INFO - 2023-07-01 11:55:39 --> Controller Class Initialized
INFO - 2023-07-01 11:55:39 --> Model Class Initialized
DEBUG - 2023-07-01 11:55:39 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-01 11:55:39 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-01 11:55:39 --> Model Class Initialized
INFO - 2023-07-01 11:55:39 --> Final output sent to browser
DEBUG - 2023-07-01 11:55:39 --> Total execution time: 0.0303
ERROR - 2023-07-01 11:55:43 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-01 11:55:43 --> Config Class Initialized
INFO - 2023-07-01 11:55:43 --> Hooks Class Initialized
DEBUG - 2023-07-01 11:55:43 --> UTF-8 Support Enabled
INFO - 2023-07-01 11:55:43 --> Utf8 Class Initialized
INFO - 2023-07-01 11:55:43 --> URI Class Initialized
INFO - 2023-07-01 11:55:43 --> Router Class Initialized
INFO - 2023-07-01 11:55:43 --> Output Class Initialized
INFO - 2023-07-01 11:55:43 --> Security Class Initialized
DEBUG - 2023-07-01 11:55:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-01 11:55:43 --> Input Class Initialized
INFO - 2023-07-01 11:55:43 --> Language Class Initialized
INFO - 2023-07-01 11:55:43 --> Loader Class Initialized
INFO - 2023-07-01 11:55:43 --> Helper loaded: url_helper
INFO - 2023-07-01 11:55:43 --> Helper loaded: file_helper
INFO - 2023-07-01 11:55:43 --> Helper loaded: html_helper
INFO - 2023-07-01 11:55:43 --> Helper loaded: text_helper
INFO - 2023-07-01 11:55:43 --> Helper loaded: form_helper
INFO - 2023-07-01 11:55:43 --> Helper loaded: lang_helper
INFO - 2023-07-01 11:55:43 --> Helper loaded: security_helper
INFO - 2023-07-01 11:55:43 --> Helper loaded: cookie_helper
INFO - 2023-07-01 11:55:43 --> Database Driver Class Initialized
INFO - 2023-07-01 11:55:43 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-01 11:55:43 --> Parser Class Initialized
INFO - 2023-07-01 11:55:43 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-01 11:55:43 --> Pagination Class Initialized
INFO - 2023-07-01 11:55:43 --> Form Validation Class Initialized
INFO - 2023-07-01 11:55:43 --> Controller Class Initialized
INFO - 2023-07-01 11:55:43 --> Model Class Initialized
DEBUG - 2023-07-01 11:55:43 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-01 11:55:43 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-01 11:55:43 --> Model Class Initialized
DEBUG - 2023-07-01 11:55:43 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-01 11:55:43 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/stockrequest/add_stockrequest_form.php
DEBUG - 2023-07-01 11:55:43 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-07-01 11:55:43 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-07-01 11:55:43 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-07-01 11:55:43 --> Model Class Initialized
INFO - 2023-07-01 11:55:43 --> Model Class Initialized
INFO - 2023-07-01 11:55:43 --> Model Class Initialized
INFO - 2023-07-01 11:55:43 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-07-01 11:55:43 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-07-01 11:55:43 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-07-01 11:55:43 --> Final output sent to browser
DEBUG - 2023-07-01 11:55:43 --> Total execution time: 0.1500
ERROR - 2023-07-01 11:55:47 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-01 11:55:47 --> Config Class Initialized
INFO - 2023-07-01 11:55:47 --> Hooks Class Initialized
DEBUG - 2023-07-01 11:55:47 --> UTF-8 Support Enabled
INFO - 2023-07-01 11:55:47 --> Utf8 Class Initialized
INFO - 2023-07-01 11:55:47 --> URI Class Initialized
INFO - 2023-07-01 11:55:47 --> Router Class Initialized
INFO - 2023-07-01 11:55:47 --> Output Class Initialized
INFO - 2023-07-01 11:55:47 --> Security Class Initialized
DEBUG - 2023-07-01 11:55:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-01 11:55:47 --> Input Class Initialized
INFO - 2023-07-01 11:55:47 --> Language Class Initialized
INFO - 2023-07-01 11:55:47 --> Loader Class Initialized
INFO - 2023-07-01 11:55:47 --> Helper loaded: url_helper
INFO - 2023-07-01 11:55:47 --> Helper loaded: file_helper
INFO - 2023-07-01 11:55:47 --> Helper loaded: html_helper
INFO - 2023-07-01 11:55:47 --> Helper loaded: text_helper
INFO - 2023-07-01 11:55:47 --> Helper loaded: form_helper
INFO - 2023-07-01 11:55:47 --> Helper loaded: lang_helper
INFO - 2023-07-01 11:55:47 --> Helper loaded: security_helper
INFO - 2023-07-01 11:55:47 --> Helper loaded: cookie_helper
INFO - 2023-07-01 11:55:47 --> Database Driver Class Initialized
INFO - 2023-07-01 11:55:47 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-01 11:55:47 --> Parser Class Initialized
INFO - 2023-07-01 11:55:47 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-01 11:55:47 --> Pagination Class Initialized
INFO - 2023-07-01 11:55:47 --> Form Validation Class Initialized
INFO - 2023-07-01 11:55:47 --> Controller Class Initialized
INFO - 2023-07-01 11:55:47 --> Model Class Initialized
DEBUG - 2023-07-01 11:55:47 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-01 11:55:47 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-01 11:55:47 --> Model Class Initialized
DEBUG - 2023-07-01 11:55:47 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-01 11:55:47 --> Model Class Initialized
INFO - 2023-07-01 11:55:47 --> Final output sent to browser
DEBUG - 2023-07-01 11:55:47 --> Total execution time: 0.0217
ERROR - 2023-07-01 11:55:48 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-01 11:55:48 --> Config Class Initialized
INFO - 2023-07-01 11:55:48 --> Hooks Class Initialized
DEBUG - 2023-07-01 11:55:48 --> UTF-8 Support Enabled
INFO - 2023-07-01 11:55:48 --> Utf8 Class Initialized
INFO - 2023-07-01 11:55:48 --> URI Class Initialized
INFO - 2023-07-01 11:55:48 --> Router Class Initialized
INFO - 2023-07-01 11:55:48 --> Output Class Initialized
INFO - 2023-07-01 11:55:48 --> Security Class Initialized
DEBUG - 2023-07-01 11:55:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-01 11:55:48 --> Input Class Initialized
INFO - 2023-07-01 11:55:48 --> Language Class Initialized
INFO - 2023-07-01 11:55:48 --> Loader Class Initialized
INFO - 2023-07-01 11:55:48 --> Helper loaded: url_helper
INFO - 2023-07-01 11:55:48 --> Helper loaded: file_helper
INFO - 2023-07-01 11:55:48 --> Helper loaded: html_helper
INFO - 2023-07-01 11:55:48 --> Helper loaded: text_helper
INFO - 2023-07-01 11:55:48 --> Helper loaded: form_helper
INFO - 2023-07-01 11:55:48 --> Helper loaded: lang_helper
INFO - 2023-07-01 11:55:48 --> Helper loaded: security_helper
INFO - 2023-07-01 11:55:48 --> Helper loaded: cookie_helper
INFO - 2023-07-01 11:55:48 --> Database Driver Class Initialized
INFO - 2023-07-01 11:55:48 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-01 11:55:48 --> Parser Class Initialized
INFO - 2023-07-01 11:55:48 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-01 11:55:48 --> Pagination Class Initialized
INFO - 2023-07-01 11:55:48 --> Form Validation Class Initialized
INFO - 2023-07-01 11:55:48 --> Controller Class Initialized
INFO - 2023-07-01 11:55:48 --> Model Class Initialized
DEBUG - 2023-07-01 11:55:48 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-01 11:55:48 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-01 11:55:48 --> Model Class Initialized
DEBUG - 2023-07-01 11:55:48 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-01 11:55:48 --> Model Class Initialized
INFO - 2023-07-01 11:55:48 --> Final output sent to browser
DEBUG - 2023-07-01 11:55:48 --> Total execution time: 0.0177
ERROR - 2023-07-01 11:55:59 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-01 11:55:59 --> Config Class Initialized
INFO - 2023-07-01 11:55:59 --> Hooks Class Initialized
DEBUG - 2023-07-01 11:55:59 --> UTF-8 Support Enabled
INFO - 2023-07-01 11:55:59 --> Utf8 Class Initialized
INFO - 2023-07-01 11:55:59 --> URI Class Initialized
INFO - 2023-07-01 11:55:59 --> Router Class Initialized
INFO - 2023-07-01 11:55:59 --> Output Class Initialized
INFO - 2023-07-01 11:55:59 --> Security Class Initialized
DEBUG - 2023-07-01 11:55:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-01 11:55:59 --> Input Class Initialized
INFO - 2023-07-01 11:55:59 --> Language Class Initialized
INFO - 2023-07-01 11:55:59 --> Loader Class Initialized
INFO - 2023-07-01 11:55:59 --> Helper loaded: url_helper
INFO - 2023-07-01 11:55:59 --> Helper loaded: file_helper
INFO - 2023-07-01 11:55:59 --> Helper loaded: html_helper
INFO - 2023-07-01 11:55:59 --> Helper loaded: text_helper
INFO - 2023-07-01 11:55:59 --> Helper loaded: form_helper
INFO - 2023-07-01 11:55:59 --> Helper loaded: lang_helper
INFO - 2023-07-01 11:55:59 --> Helper loaded: security_helper
INFO - 2023-07-01 11:55:59 --> Helper loaded: cookie_helper
INFO - 2023-07-01 11:55:59 --> Database Driver Class Initialized
INFO - 2023-07-01 11:55:59 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-01 11:55:59 --> Parser Class Initialized
INFO - 2023-07-01 11:55:59 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-01 11:55:59 --> Pagination Class Initialized
INFO - 2023-07-01 11:55:59 --> Form Validation Class Initialized
INFO - 2023-07-01 11:55:59 --> Controller Class Initialized
DEBUG - 2023-07-01 11:55:59 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-01 11:55:59 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-01 11:55:59 --> Model Class Initialized
DEBUG - 2023-07-01 11:55:59 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-01 11:55:59 --> Model Class Initialized
INFO - 2023-07-01 11:55:59 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/customer/add_customer_form.php
DEBUG - 2023-07-01 11:55:59 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-07-01 11:55:59 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-07-01 11:55:59 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-07-01 11:55:59 --> Model Class Initialized
INFO - 2023-07-01 11:55:59 --> Model Class Initialized
INFO - 2023-07-01 11:55:59 --> Model Class Initialized
INFO - 2023-07-01 11:55:59 --> Model Class Initialized
INFO - 2023-07-01 11:55:59 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-07-01 11:55:59 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-07-01 11:55:59 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-07-01 11:55:59 --> Final output sent to browser
DEBUG - 2023-07-01 11:55:59 --> Total execution time: 0.1672
ERROR - 2023-07-01 11:57:45 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-01 11:57:45 --> Config Class Initialized
INFO - 2023-07-01 11:57:45 --> Hooks Class Initialized
DEBUG - 2023-07-01 11:57:45 --> UTF-8 Support Enabled
INFO - 2023-07-01 11:57:45 --> Utf8 Class Initialized
INFO - 2023-07-01 11:57:45 --> URI Class Initialized
INFO - 2023-07-01 11:57:45 --> Router Class Initialized
INFO - 2023-07-01 11:57:45 --> Output Class Initialized
INFO - 2023-07-01 11:57:45 --> Security Class Initialized
DEBUG - 2023-07-01 11:57:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-01 11:57:45 --> Input Class Initialized
INFO - 2023-07-01 11:57:45 --> Language Class Initialized
INFO - 2023-07-01 11:57:45 --> Loader Class Initialized
INFO - 2023-07-01 11:57:45 --> Helper loaded: url_helper
INFO - 2023-07-01 11:57:45 --> Helper loaded: file_helper
INFO - 2023-07-01 11:57:45 --> Helper loaded: html_helper
INFO - 2023-07-01 11:57:45 --> Helper loaded: text_helper
INFO - 2023-07-01 11:57:45 --> Helper loaded: form_helper
INFO - 2023-07-01 11:57:45 --> Helper loaded: lang_helper
INFO - 2023-07-01 11:57:45 --> Helper loaded: security_helper
INFO - 2023-07-01 11:57:45 --> Helper loaded: cookie_helper
INFO - 2023-07-01 11:57:45 --> Database Driver Class Initialized
INFO - 2023-07-01 11:57:45 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-01 11:57:45 --> Parser Class Initialized
INFO - 2023-07-01 11:57:45 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-01 11:57:45 --> Pagination Class Initialized
INFO - 2023-07-01 11:57:45 --> Form Validation Class Initialized
INFO - 2023-07-01 11:57:45 --> Controller Class Initialized
DEBUG - 2023-07-01 11:57:45 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-01 11:57:45 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-01 11:57:45 --> Model Class Initialized
INFO - 2023-07-01 11:57:45 --> Model Class Initialized
INFO - 2023-07-01 11:57:45 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/mr/add_mr_form.php
DEBUG - 2023-07-01 11:57:45 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-07-01 11:57:45 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-07-01 11:57:45 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-07-01 11:57:45 --> Model Class Initialized
INFO - 2023-07-01 11:57:45 --> Model Class Initialized
INFO - 2023-07-01 11:57:45 --> Model Class Initialized
INFO - 2023-07-01 11:57:45 --> Model Class Initialized
INFO - 2023-07-01 11:57:45 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-07-01 11:57:45 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-07-01 11:57:45 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-07-01 11:57:45 --> Final output sent to browser
DEBUG - 2023-07-01 11:57:45 --> Total execution time: 0.1859
ERROR - 2023-07-01 11:57:53 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-01 11:57:53 --> Config Class Initialized
INFO - 2023-07-01 11:57:53 --> Hooks Class Initialized
DEBUG - 2023-07-01 11:57:53 --> UTF-8 Support Enabled
INFO - 2023-07-01 11:57:53 --> Utf8 Class Initialized
INFO - 2023-07-01 11:57:53 --> URI Class Initialized
INFO - 2023-07-01 11:57:53 --> Router Class Initialized
INFO - 2023-07-01 11:57:53 --> Output Class Initialized
INFO - 2023-07-01 11:57:53 --> Security Class Initialized
DEBUG - 2023-07-01 11:57:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-01 11:57:53 --> Input Class Initialized
INFO - 2023-07-01 11:57:53 --> Language Class Initialized
INFO - 2023-07-01 11:57:53 --> Loader Class Initialized
INFO - 2023-07-01 11:57:53 --> Helper loaded: url_helper
INFO - 2023-07-01 11:57:53 --> Helper loaded: file_helper
INFO - 2023-07-01 11:57:53 --> Helper loaded: html_helper
INFO - 2023-07-01 11:57:53 --> Helper loaded: text_helper
INFO - 2023-07-01 11:57:53 --> Helper loaded: form_helper
INFO - 2023-07-01 11:57:53 --> Helper loaded: lang_helper
INFO - 2023-07-01 11:57:53 --> Helper loaded: security_helper
INFO - 2023-07-01 11:57:53 --> Helper loaded: cookie_helper
INFO - 2023-07-01 11:57:53 --> Database Driver Class Initialized
INFO - 2023-07-01 11:57:53 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-01 11:57:53 --> Parser Class Initialized
INFO - 2023-07-01 11:57:53 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-01 11:57:53 --> Pagination Class Initialized
INFO - 2023-07-01 11:57:53 --> Form Validation Class Initialized
INFO - 2023-07-01 11:57:53 --> Controller Class Initialized
DEBUG - 2023-07-01 11:57:53 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-01 11:57:53 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-01 11:57:53 --> Model Class Initialized
INFO - 2023-07-01 11:57:53 --> Model Class Initialized
DEBUG - 2023-07-01 11:57:53 --> Lmr class already loaded. Second attempt ignored.
INFO - 2023-07-01 11:57:53 --> Model Class Initialized
INFO - 2023-07-01 11:57:53 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/mr/mr.php
DEBUG - 2023-07-01 11:57:53 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-07-01 11:57:53 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-07-01 11:57:53 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-07-01 11:57:53 --> Model Class Initialized
INFO - 2023-07-01 11:57:53 --> Model Class Initialized
INFO - 2023-07-01 11:57:53 --> Model Class Initialized
INFO - 2023-07-01 11:57:54 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-07-01 11:57:54 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-07-01 11:57:54 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-07-01 11:57:54 --> Final output sent to browser
DEBUG - 2023-07-01 11:57:54 --> Total execution time: 0.1353
ERROR - 2023-07-01 11:57:54 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-01 11:57:54 --> Config Class Initialized
INFO - 2023-07-01 11:57:54 --> Hooks Class Initialized
DEBUG - 2023-07-01 11:57:54 --> UTF-8 Support Enabled
INFO - 2023-07-01 11:57:54 --> Utf8 Class Initialized
INFO - 2023-07-01 11:57:54 --> URI Class Initialized
INFO - 2023-07-01 11:57:54 --> Router Class Initialized
INFO - 2023-07-01 11:57:54 --> Output Class Initialized
INFO - 2023-07-01 11:57:54 --> Security Class Initialized
DEBUG - 2023-07-01 11:57:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-01 11:57:54 --> Input Class Initialized
INFO - 2023-07-01 11:57:54 --> Language Class Initialized
INFO - 2023-07-01 11:57:54 --> Loader Class Initialized
INFO - 2023-07-01 11:57:54 --> Helper loaded: url_helper
INFO - 2023-07-01 11:57:54 --> Helper loaded: file_helper
INFO - 2023-07-01 11:57:54 --> Helper loaded: html_helper
INFO - 2023-07-01 11:57:54 --> Helper loaded: text_helper
INFO - 2023-07-01 11:57:54 --> Helper loaded: form_helper
INFO - 2023-07-01 11:57:54 --> Helper loaded: lang_helper
INFO - 2023-07-01 11:57:54 --> Helper loaded: security_helper
INFO - 2023-07-01 11:57:54 --> Helper loaded: cookie_helper
INFO - 2023-07-01 11:57:54 --> Database Driver Class Initialized
INFO - 2023-07-01 11:57:54 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-01 11:57:54 --> Parser Class Initialized
INFO - 2023-07-01 11:57:54 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-01 11:57:54 --> Pagination Class Initialized
INFO - 2023-07-01 11:57:54 --> Form Validation Class Initialized
INFO - 2023-07-01 11:57:54 --> Controller Class Initialized
DEBUG - 2023-07-01 11:57:54 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-01 11:57:54 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-01 11:57:54 --> Model Class Initialized
INFO - 2023-07-01 11:57:54 --> Model Class Initialized
INFO - 2023-07-01 11:57:54 --> Final output sent to browser
DEBUG - 2023-07-01 11:57:54 --> Total execution time: 0.0200
ERROR - 2023-07-01 11:59:28 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-01 11:59:28 --> Config Class Initialized
INFO - 2023-07-01 11:59:28 --> Hooks Class Initialized
DEBUG - 2023-07-01 11:59:28 --> UTF-8 Support Enabled
INFO - 2023-07-01 11:59:28 --> Utf8 Class Initialized
INFO - 2023-07-01 11:59:28 --> URI Class Initialized
INFO - 2023-07-01 11:59:28 --> Router Class Initialized
INFO - 2023-07-01 11:59:28 --> Output Class Initialized
INFO - 2023-07-01 11:59:28 --> Security Class Initialized
DEBUG - 2023-07-01 11:59:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-01 11:59:28 --> Input Class Initialized
INFO - 2023-07-01 11:59:28 --> Language Class Initialized
INFO - 2023-07-01 11:59:28 --> Loader Class Initialized
INFO - 2023-07-01 11:59:28 --> Helper loaded: url_helper
INFO - 2023-07-01 11:59:28 --> Helper loaded: file_helper
INFO - 2023-07-01 11:59:28 --> Helper loaded: html_helper
INFO - 2023-07-01 11:59:28 --> Helper loaded: text_helper
INFO - 2023-07-01 11:59:28 --> Helper loaded: form_helper
INFO - 2023-07-01 11:59:28 --> Helper loaded: lang_helper
INFO - 2023-07-01 11:59:28 --> Helper loaded: security_helper
INFO - 2023-07-01 11:59:28 --> Helper loaded: cookie_helper
INFO - 2023-07-01 11:59:28 --> Database Driver Class Initialized
INFO - 2023-07-01 11:59:28 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-01 11:59:28 --> Parser Class Initialized
INFO - 2023-07-01 11:59:28 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-01 11:59:28 --> Pagination Class Initialized
INFO - 2023-07-01 11:59:28 --> Form Validation Class Initialized
INFO - 2023-07-01 11:59:28 --> Controller Class Initialized
DEBUG - 2023-07-01 11:59:28 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-01 11:59:28 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-01 11:59:28 --> Model Class Initialized
INFO - 2023-07-01 11:59:28 --> Model Class Initialized
INFO - 2023-07-01 11:59:28 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/mr/add_mr_form.php
DEBUG - 2023-07-01 11:59:28 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-07-01 11:59:28 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-07-01 11:59:28 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-07-01 11:59:28 --> Model Class Initialized
INFO - 2023-07-01 11:59:28 --> Model Class Initialized
INFO - 2023-07-01 11:59:28 --> Model Class Initialized
INFO - 2023-07-01 11:59:28 --> Model Class Initialized
INFO - 2023-07-01 11:59:28 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-07-01 11:59:28 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-07-01 11:59:28 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-07-01 11:59:28 --> Final output sent to browser
DEBUG - 2023-07-01 11:59:28 --> Total execution time: 0.1814
ERROR - 2023-07-01 11:59:34 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-01 11:59:34 --> Config Class Initialized
INFO - 2023-07-01 11:59:34 --> Hooks Class Initialized
DEBUG - 2023-07-01 11:59:34 --> UTF-8 Support Enabled
INFO - 2023-07-01 11:59:34 --> Utf8 Class Initialized
INFO - 2023-07-01 11:59:34 --> URI Class Initialized
INFO - 2023-07-01 11:59:34 --> Router Class Initialized
INFO - 2023-07-01 11:59:34 --> Output Class Initialized
INFO - 2023-07-01 11:59:34 --> Security Class Initialized
DEBUG - 2023-07-01 11:59:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-01 11:59:34 --> Input Class Initialized
INFO - 2023-07-01 11:59:34 --> Language Class Initialized
INFO - 2023-07-01 11:59:34 --> Loader Class Initialized
INFO - 2023-07-01 11:59:34 --> Helper loaded: url_helper
INFO - 2023-07-01 11:59:34 --> Helper loaded: file_helper
INFO - 2023-07-01 11:59:34 --> Helper loaded: html_helper
INFO - 2023-07-01 11:59:34 --> Helper loaded: text_helper
INFO - 2023-07-01 11:59:34 --> Helper loaded: form_helper
INFO - 2023-07-01 11:59:34 --> Helper loaded: lang_helper
INFO - 2023-07-01 11:59:34 --> Helper loaded: security_helper
INFO - 2023-07-01 11:59:34 --> Helper loaded: cookie_helper
INFO - 2023-07-01 11:59:34 --> Database Driver Class Initialized
INFO - 2023-07-01 11:59:34 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-01 11:59:34 --> Parser Class Initialized
INFO - 2023-07-01 11:59:34 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-01 11:59:34 --> Pagination Class Initialized
INFO - 2023-07-01 11:59:34 --> Form Validation Class Initialized
INFO - 2023-07-01 11:59:34 --> Controller Class Initialized
DEBUG - 2023-07-01 11:59:34 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-01 11:59:34 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-01 11:59:34 --> Model Class Initialized
INFO - 2023-07-01 11:59:34 --> Model Class Initialized
DEBUG - 2023-07-01 11:59:34 --> Lmr class already loaded. Second attempt ignored.
INFO - 2023-07-01 11:59:34 --> Model Class Initialized
INFO - 2023-07-01 11:59:34 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/mr/mr.php
DEBUG - 2023-07-01 11:59:34 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-07-01 11:59:34 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-07-01 11:59:34 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-07-01 11:59:34 --> Model Class Initialized
INFO - 2023-07-01 11:59:34 --> Model Class Initialized
INFO - 2023-07-01 11:59:34 --> Model Class Initialized
INFO - 2023-07-01 11:59:34 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-07-01 11:59:34 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-07-01 11:59:34 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-07-01 11:59:34 --> Final output sent to browser
DEBUG - 2023-07-01 11:59:34 --> Total execution time: 0.1350
ERROR - 2023-07-01 11:59:35 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-01 11:59:35 --> Config Class Initialized
INFO - 2023-07-01 11:59:35 --> Hooks Class Initialized
DEBUG - 2023-07-01 11:59:35 --> UTF-8 Support Enabled
INFO - 2023-07-01 11:59:35 --> Utf8 Class Initialized
INFO - 2023-07-01 11:59:35 --> URI Class Initialized
INFO - 2023-07-01 11:59:35 --> Router Class Initialized
INFO - 2023-07-01 11:59:35 --> Output Class Initialized
INFO - 2023-07-01 11:59:35 --> Security Class Initialized
DEBUG - 2023-07-01 11:59:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-01 11:59:35 --> Input Class Initialized
INFO - 2023-07-01 11:59:35 --> Language Class Initialized
INFO - 2023-07-01 11:59:35 --> Loader Class Initialized
INFO - 2023-07-01 11:59:35 --> Helper loaded: url_helper
INFO - 2023-07-01 11:59:35 --> Helper loaded: file_helper
INFO - 2023-07-01 11:59:35 --> Helper loaded: html_helper
INFO - 2023-07-01 11:59:35 --> Helper loaded: text_helper
INFO - 2023-07-01 11:59:35 --> Helper loaded: form_helper
INFO - 2023-07-01 11:59:35 --> Helper loaded: lang_helper
INFO - 2023-07-01 11:59:35 --> Helper loaded: security_helper
INFO - 2023-07-01 11:59:35 --> Helper loaded: cookie_helper
INFO - 2023-07-01 11:59:35 --> Database Driver Class Initialized
INFO - 2023-07-01 11:59:35 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-01 11:59:35 --> Parser Class Initialized
INFO - 2023-07-01 11:59:35 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-01 11:59:35 --> Pagination Class Initialized
INFO - 2023-07-01 11:59:35 --> Form Validation Class Initialized
INFO - 2023-07-01 11:59:35 --> Controller Class Initialized
DEBUG - 2023-07-01 11:59:35 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-01 11:59:35 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-01 11:59:35 --> Model Class Initialized
INFO - 2023-07-01 11:59:35 --> Model Class Initialized
INFO - 2023-07-01 11:59:35 --> Final output sent to browser
DEBUG - 2023-07-01 11:59:35 --> Total execution time: 0.0215
ERROR - 2023-07-01 12:01:38 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-01 12:01:38 --> Config Class Initialized
INFO - 2023-07-01 12:01:38 --> Hooks Class Initialized
DEBUG - 2023-07-01 12:01:38 --> UTF-8 Support Enabled
INFO - 2023-07-01 12:01:38 --> Utf8 Class Initialized
INFO - 2023-07-01 12:01:38 --> URI Class Initialized
INFO - 2023-07-01 12:01:38 --> Router Class Initialized
INFO - 2023-07-01 12:01:38 --> Output Class Initialized
INFO - 2023-07-01 12:01:38 --> Security Class Initialized
DEBUG - 2023-07-01 12:01:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-01 12:01:38 --> Input Class Initialized
INFO - 2023-07-01 12:01:38 --> Language Class Initialized
INFO - 2023-07-01 12:01:38 --> Loader Class Initialized
INFO - 2023-07-01 12:01:38 --> Helper loaded: url_helper
INFO - 2023-07-01 12:01:38 --> Helper loaded: file_helper
INFO - 2023-07-01 12:01:38 --> Helper loaded: html_helper
INFO - 2023-07-01 12:01:38 --> Helper loaded: text_helper
INFO - 2023-07-01 12:01:38 --> Helper loaded: form_helper
INFO - 2023-07-01 12:01:38 --> Helper loaded: lang_helper
INFO - 2023-07-01 12:01:38 --> Helper loaded: security_helper
INFO - 2023-07-01 12:01:38 --> Helper loaded: cookie_helper
INFO - 2023-07-01 12:01:38 --> Database Driver Class Initialized
INFO - 2023-07-01 12:01:38 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-01 12:01:38 --> Parser Class Initialized
INFO - 2023-07-01 12:01:38 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-01 12:01:38 --> Pagination Class Initialized
INFO - 2023-07-01 12:01:38 --> Form Validation Class Initialized
INFO - 2023-07-01 12:01:38 --> Controller Class Initialized
DEBUG - 2023-07-01 12:01:38 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-01 12:01:38 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-01 12:01:38 --> Model Class Initialized
DEBUG - 2023-07-01 12:01:38 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-01 12:01:38 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-01 12:01:38 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/target/add_form.php
DEBUG - 2023-07-01 12:01:38 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-07-01 12:01:38 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-07-01 12:01:38 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-07-01 12:01:38 --> Model Class Initialized
INFO - 2023-07-01 12:01:38 --> Model Class Initialized
INFO - 2023-07-01 12:01:38 --> Model Class Initialized
INFO - 2023-07-01 12:01:38 --> Model Class Initialized
INFO - 2023-07-01 12:01:38 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-07-01 12:01:38 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-07-01 12:01:38 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-07-01 12:01:38 --> Final output sent to browser
DEBUG - 2023-07-01 12:01:38 --> Total execution time: 0.1494
ERROR - 2023-07-01 12:03:03 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-01 12:03:03 --> Config Class Initialized
INFO - 2023-07-01 12:03:03 --> Hooks Class Initialized
DEBUG - 2023-07-01 12:03:03 --> UTF-8 Support Enabled
INFO - 2023-07-01 12:03:03 --> Utf8 Class Initialized
INFO - 2023-07-01 12:03:03 --> URI Class Initialized
INFO - 2023-07-01 12:03:03 --> Router Class Initialized
INFO - 2023-07-01 12:03:03 --> Output Class Initialized
INFO - 2023-07-01 12:03:03 --> Security Class Initialized
DEBUG - 2023-07-01 12:03:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-01 12:03:03 --> Input Class Initialized
INFO - 2023-07-01 12:03:03 --> Language Class Initialized
INFO - 2023-07-01 12:03:03 --> Loader Class Initialized
INFO - 2023-07-01 12:03:03 --> Helper loaded: url_helper
INFO - 2023-07-01 12:03:03 --> Helper loaded: file_helper
INFO - 2023-07-01 12:03:03 --> Helper loaded: html_helper
INFO - 2023-07-01 12:03:03 --> Helper loaded: text_helper
INFO - 2023-07-01 12:03:03 --> Helper loaded: form_helper
INFO - 2023-07-01 12:03:03 --> Helper loaded: lang_helper
INFO - 2023-07-01 12:03:03 --> Helper loaded: security_helper
INFO - 2023-07-01 12:03:03 --> Helper loaded: cookie_helper
INFO - 2023-07-01 12:03:03 --> Database Driver Class Initialized
INFO - 2023-07-01 12:03:03 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-01 12:03:03 --> Parser Class Initialized
INFO - 2023-07-01 12:03:03 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-01 12:03:03 --> Pagination Class Initialized
INFO - 2023-07-01 12:03:03 --> Form Validation Class Initialized
INFO - 2023-07-01 12:03:03 --> Controller Class Initialized
DEBUG - 2023-07-01 12:03:03 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-01 12:03:03 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-01 12:03:03 --> Model Class Initialized
DEBUG - 2023-07-01 12:03:03 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-01 12:03:03 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-07-01 12:03:03 --> Ltarget class already loaded. Second attempt ignored.
INFO - 2023-07-01 12:03:03 --> Model Class Initialized
DEBUG - 2023-07-01 12:03:03 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-01 12:03:03 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-01 12:03:03 --> Model Class Initialized
DEBUG - 2023-07-01 12:03:03 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-01 12:03:03 --> Model Class Initialized
INFO - 2023-07-01 12:03:03 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/target/target.php
DEBUG - 2023-07-01 12:03:03 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-07-01 12:03:03 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-07-01 12:03:03 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-07-01 12:03:03 --> Model Class Initialized
INFO - 2023-07-01 12:03:03 --> Model Class Initialized
INFO - 2023-07-01 12:03:03 --> Model Class Initialized
INFO - 2023-07-01 12:03:03 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-07-01 12:03:03 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-07-01 12:03:03 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-07-01 12:03:03 --> Final output sent to browser
DEBUG - 2023-07-01 12:03:03 --> Total execution time: 0.1415
ERROR - 2023-07-01 12:03:03 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-01 12:03:03 --> Config Class Initialized
INFO - 2023-07-01 12:03:03 --> Hooks Class Initialized
DEBUG - 2023-07-01 12:03:03 --> UTF-8 Support Enabled
INFO - 2023-07-01 12:03:03 --> Utf8 Class Initialized
INFO - 2023-07-01 12:03:03 --> URI Class Initialized
INFO - 2023-07-01 12:03:03 --> Router Class Initialized
INFO - 2023-07-01 12:03:03 --> Output Class Initialized
INFO - 2023-07-01 12:03:03 --> Security Class Initialized
DEBUG - 2023-07-01 12:03:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-01 12:03:03 --> Input Class Initialized
INFO - 2023-07-01 12:03:03 --> Language Class Initialized
INFO - 2023-07-01 12:03:03 --> Loader Class Initialized
INFO - 2023-07-01 12:03:03 --> Helper loaded: url_helper
INFO - 2023-07-01 12:03:03 --> Helper loaded: file_helper
INFO - 2023-07-01 12:03:03 --> Helper loaded: html_helper
INFO - 2023-07-01 12:03:03 --> Helper loaded: text_helper
INFO - 2023-07-01 12:03:03 --> Helper loaded: form_helper
INFO - 2023-07-01 12:03:03 --> Helper loaded: lang_helper
INFO - 2023-07-01 12:03:03 --> Helper loaded: security_helper
INFO - 2023-07-01 12:03:03 --> Helper loaded: cookie_helper
INFO - 2023-07-01 12:03:03 --> Database Driver Class Initialized
INFO - 2023-07-01 12:03:03 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-01 12:03:03 --> Parser Class Initialized
INFO - 2023-07-01 12:03:03 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-01 12:03:03 --> Pagination Class Initialized
INFO - 2023-07-01 12:03:03 --> Form Validation Class Initialized
INFO - 2023-07-01 12:03:03 --> Controller Class Initialized
DEBUG - 2023-07-01 12:03:03 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-01 12:03:03 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-01 12:03:03 --> Model Class Initialized
DEBUG - 2023-07-01 12:03:03 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-01 12:03:03 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-01 12:03:03 --> Model Class Initialized
DEBUG - 2023-07-01 12:03:03 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-01 12:03:03 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-01 12:03:03 --> Model Class Initialized
DEBUG - 2023-07-01 12:03:03 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-01 12:03:03 --> Model Class Initialized
INFO - 2023-07-01 12:03:03 --> Final output sent to browser
DEBUG - 2023-07-01 12:03:03 --> Total execution time: 0.0215
ERROR - 2023-07-01 16:02:54 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-01 16:02:54 --> Config Class Initialized
INFO - 2023-07-01 16:02:54 --> Hooks Class Initialized
DEBUG - 2023-07-01 16:02:54 --> UTF-8 Support Enabled
INFO - 2023-07-01 16:02:54 --> Utf8 Class Initialized
INFO - 2023-07-01 16:02:54 --> URI Class Initialized
INFO - 2023-07-01 16:02:54 --> Router Class Initialized
INFO - 2023-07-01 16:02:54 --> Output Class Initialized
INFO - 2023-07-01 16:02:54 --> Security Class Initialized
DEBUG - 2023-07-01 16:02:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-01 16:02:54 --> Input Class Initialized
INFO - 2023-07-01 16:02:54 --> Language Class Initialized
INFO - 2023-07-01 16:02:54 --> Loader Class Initialized
INFO - 2023-07-01 16:02:54 --> Helper loaded: url_helper
INFO - 2023-07-01 16:02:54 --> Helper loaded: file_helper
INFO - 2023-07-01 16:02:54 --> Helper loaded: html_helper
INFO - 2023-07-01 16:02:54 --> Helper loaded: text_helper
INFO - 2023-07-01 16:02:54 --> Helper loaded: form_helper
INFO - 2023-07-01 16:02:54 --> Helper loaded: lang_helper
INFO - 2023-07-01 16:02:54 --> Helper loaded: security_helper
INFO - 2023-07-01 16:02:54 --> Helper loaded: cookie_helper
INFO - 2023-07-01 16:02:54 --> Database Driver Class Initialized
INFO - 2023-07-01 16:02:54 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-01 16:02:54 --> Parser Class Initialized
INFO - 2023-07-01 16:02:54 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-01 16:02:54 --> Pagination Class Initialized
INFO - 2023-07-01 16:02:54 --> Form Validation Class Initialized
INFO - 2023-07-01 16:02:54 --> Controller Class Initialized
DEBUG - 2023-07-01 16:02:54 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-01 16:02:54 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-01 16:02:54 --> Model Class Initialized
ERROR - 2023-07-01 16:02:54 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-01 16:02:54 --> Config Class Initialized
INFO - 2023-07-01 16:02:54 --> Hooks Class Initialized
DEBUG - 2023-07-01 16:02:54 --> UTF-8 Support Enabled
INFO - 2023-07-01 16:02:54 --> Utf8 Class Initialized
INFO - 2023-07-01 16:02:54 --> URI Class Initialized
INFO - 2023-07-01 16:02:54 --> Router Class Initialized
INFO - 2023-07-01 16:02:54 --> Output Class Initialized
INFO - 2023-07-01 16:02:54 --> Security Class Initialized
DEBUG - 2023-07-01 16:02:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-01 16:02:54 --> Input Class Initialized
INFO - 2023-07-01 16:02:54 --> Language Class Initialized
INFO - 2023-07-01 16:02:54 --> Loader Class Initialized
INFO - 2023-07-01 16:02:54 --> Helper loaded: url_helper
INFO - 2023-07-01 16:02:54 --> Helper loaded: file_helper
INFO - 2023-07-01 16:02:54 --> Helper loaded: html_helper
INFO - 2023-07-01 16:02:54 --> Helper loaded: text_helper
INFO - 2023-07-01 16:02:54 --> Helper loaded: form_helper
INFO - 2023-07-01 16:02:54 --> Helper loaded: lang_helper
INFO - 2023-07-01 16:02:54 --> Helper loaded: security_helper
INFO - 2023-07-01 16:02:54 --> Helper loaded: cookie_helper
INFO - 2023-07-01 16:02:54 --> Database Driver Class Initialized
INFO - 2023-07-01 16:02:54 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-01 16:02:54 --> Parser Class Initialized
INFO - 2023-07-01 16:02:54 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-01 16:02:54 --> Pagination Class Initialized
INFO - 2023-07-01 16:02:54 --> Form Validation Class Initialized
INFO - 2023-07-01 16:02:54 --> Controller Class Initialized
INFO - 2023-07-01 16:02:54 --> Model Class Initialized
DEBUG - 2023-07-01 16:02:54 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-01 16:02:54 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2023-07-01 16:02:54 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-07-01 16:02:54 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-07-01 16:02:54 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-07-01 16:02:54 --> Model Class Initialized
INFO - 2023-07-01 16:02:54 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-07-01 16:02:54 --> Final output sent to browser
DEBUG - 2023-07-01 16:02:54 --> Total execution time: 0.0353
ERROR - 2023-07-01 16:02:57 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-01 16:02:57 --> Config Class Initialized
INFO - 2023-07-01 16:02:57 --> Hooks Class Initialized
DEBUG - 2023-07-01 16:02:57 --> UTF-8 Support Enabled
INFO - 2023-07-01 16:02:57 --> Utf8 Class Initialized
INFO - 2023-07-01 16:02:57 --> URI Class Initialized
INFO - 2023-07-01 16:02:57 --> Router Class Initialized
INFO - 2023-07-01 16:02:57 --> Output Class Initialized
INFO - 2023-07-01 16:02:57 --> Security Class Initialized
DEBUG - 2023-07-01 16:02:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-01 16:02:57 --> Input Class Initialized
INFO - 2023-07-01 16:02:57 --> Language Class Initialized
INFO - 2023-07-01 16:02:57 --> Loader Class Initialized
INFO - 2023-07-01 16:02:57 --> Helper loaded: url_helper
INFO - 2023-07-01 16:02:57 --> Helper loaded: file_helper
INFO - 2023-07-01 16:02:57 --> Helper loaded: html_helper
INFO - 2023-07-01 16:02:57 --> Helper loaded: text_helper
INFO - 2023-07-01 16:02:57 --> Helper loaded: form_helper
INFO - 2023-07-01 16:02:57 --> Helper loaded: lang_helper
INFO - 2023-07-01 16:02:57 --> Helper loaded: security_helper
INFO - 2023-07-01 16:02:57 --> Helper loaded: cookie_helper
INFO - 2023-07-01 16:02:57 --> Database Driver Class Initialized
INFO - 2023-07-01 16:02:57 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-01 16:02:57 --> Parser Class Initialized
INFO - 2023-07-01 16:02:57 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-01 16:02:57 --> Pagination Class Initialized
INFO - 2023-07-01 16:02:57 --> Form Validation Class Initialized
INFO - 2023-07-01 16:02:57 --> Controller Class Initialized
INFO - 2023-07-01 16:02:57 --> Model Class Initialized
DEBUG - 2023-07-01 16:02:57 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-01 16:02:57 --> Model Class Initialized
INFO - 2023-07-01 16:02:57 --> Final output sent to browser
DEBUG - 2023-07-01 16:02:57 --> Total execution time: 0.0179
ERROR - 2023-07-01 16:02:57 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-01 16:02:57 --> Config Class Initialized
INFO - 2023-07-01 16:02:57 --> Hooks Class Initialized
DEBUG - 2023-07-01 16:02:57 --> UTF-8 Support Enabled
INFO - 2023-07-01 16:02:57 --> Utf8 Class Initialized
INFO - 2023-07-01 16:02:57 --> URI Class Initialized
DEBUG - 2023-07-01 16:02:57 --> No URI present. Default controller set.
INFO - 2023-07-01 16:02:57 --> Router Class Initialized
INFO - 2023-07-01 16:02:57 --> Output Class Initialized
INFO - 2023-07-01 16:02:57 --> Security Class Initialized
DEBUG - 2023-07-01 16:02:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-01 16:02:57 --> Input Class Initialized
INFO - 2023-07-01 16:02:57 --> Language Class Initialized
INFO - 2023-07-01 16:02:57 --> Loader Class Initialized
INFO - 2023-07-01 16:02:57 --> Helper loaded: url_helper
INFO - 2023-07-01 16:02:57 --> Helper loaded: file_helper
INFO - 2023-07-01 16:02:57 --> Helper loaded: html_helper
INFO - 2023-07-01 16:02:57 --> Helper loaded: text_helper
INFO - 2023-07-01 16:02:57 --> Helper loaded: form_helper
INFO - 2023-07-01 16:02:57 --> Helper loaded: lang_helper
INFO - 2023-07-01 16:02:57 --> Helper loaded: security_helper
INFO - 2023-07-01 16:02:57 --> Helper loaded: cookie_helper
INFO - 2023-07-01 16:02:57 --> Database Driver Class Initialized
INFO - 2023-07-01 16:02:57 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-01 16:02:57 --> Parser Class Initialized
INFO - 2023-07-01 16:02:57 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-01 16:02:57 --> Pagination Class Initialized
INFO - 2023-07-01 16:02:57 --> Form Validation Class Initialized
INFO - 2023-07-01 16:02:57 --> Controller Class Initialized
INFO - 2023-07-01 16:02:57 --> Model Class Initialized
DEBUG - 2023-07-01 16:02:57 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-01 16:02:57 --> Model Class Initialized
DEBUG - 2023-07-01 16:02:57 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-01 16:02:57 --> Model Class Initialized
INFO - 2023-07-01 16:02:57 --> Model Class Initialized
INFO - 2023-07-01 16:02:57 --> Model Class Initialized
INFO - 2023-07-01 16:02:58 --> Model Class Initialized
DEBUG - 2023-07-01 16:02:58 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-01 16:02:58 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-01 16:02:58 --> Model Class Initialized
INFO - 2023-07-01 16:02:58 --> Model Class Initialized
INFO - 2023-07-01 16:02:58 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-07-01 16:02:58 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-07-01 16:02:58 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-07-01 16:02:58 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-07-01 16:02:58 --> Model Class Initialized
INFO - 2023-07-01 16:02:58 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-07-01 16:02:58 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-07-01 16:02:58 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-07-01 16:02:58 --> Final output sent to browser
DEBUG - 2023-07-01 16:02:58 --> Total execution time: 0.1898
ERROR - 2023-07-01 16:02:58 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-01 16:02:58 --> Config Class Initialized
INFO - 2023-07-01 16:02:58 --> Hooks Class Initialized
DEBUG - 2023-07-01 16:02:58 --> UTF-8 Support Enabled
INFO - 2023-07-01 16:02:58 --> Utf8 Class Initialized
INFO - 2023-07-01 16:02:58 --> URI Class Initialized
INFO - 2023-07-01 16:02:58 --> Router Class Initialized
INFO - 2023-07-01 16:02:58 --> Output Class Initialized
INFO - 2023-07-01 16:02:58 --> Security Class Initialized
DEBUG - 2023-07-01 16:02:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-01 16:02:58 --> Input Class Initialized
INFO - 2023-07-01 16:02:58 --> Language Class Initialized
INFO - 2023-07-01 16:02:58 --> Loader Class Initialized
INFO - 2023-07-01 16:02:58 --> Helper loaded: url_helper
INFO - 2023-07-01 16:02:58 --> Helper loaded: file_helper
INFO - 2023-07-01 16:02:58 --> Helper loaded: html_helper
INFO - 2023-07-01 16:02:58 --> Helper loaded: text_helper
INFO - 2023-07-01 16:02:58 --> Helper loaded: form_helper
INFO - 2023-07-01 16:02:58 --> Helper loaded: lang_helper
INFO - 2023-07-01 16:02:58 --> Helper loaded: security_helper
INFO - 2023-07-01 16:02:58 --> Helper loaded: cookie_helper
INFO - 2023-07-01 16:02:58 --> Database Driver Class Initialized
INFO - 2023-07-01 16:02:58 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-01 16:02:58 --> Parser Class Initialized
INFO - 2023-07-01 16:02:58 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-01 16:02:58 --> Pagination Class Initialized
INFO - 2023-07-01 16:02:58 --> Form Validation Class Initialized
INFO - 2023-07-01 16:02:58 --> Controller Class Initialized
DEBUG - 2023-07-01 16:02:58 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-01 16:02:58 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-01 16:02:58 --> Model Class Initialized
INFO - 2023-07-01 16:02:58 --> Final output sent to browser
DEBUG - 2023-07-01 16:02:58 --> Total execution time: 0.0132
ERROR - 2023-07-01 16:03:16 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-01 16:03:16 --> Config Class Initialized
INFO - 2023-07-01 16:03:16 --> Hooks Class Initialized
DEBUG - 2023-07-01 16:03:16 --> UTF-8 Support Enabled
INFO - 2023-07-01 16:03:16 --> Utf8 Class Initialized
INFO - 2023-07-01 16:03:16 --> URI Class Initialized
INFO - 2023-07-01 16:03:16 --> Router Class Initialized
INFO - 2023-07-01 16:03:16 --> Output Class Initialized
INFO - 2023-07-01 16:03:16 --> Security Class Initialized
DEBUG - 2023-07-01 16:03:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-01 16:03:16 --> Input Class Initialized
INFO - 2023-07-01 16:03:16 --> Language Class Initialized
INFO - 2023-07-01 16:03:16 --> Loader Class Initialized
INFO - 2023-07-01 16:03:16 --> Helper loaded: url_helper
INFO - 2023-07-01 16:03:16 --> Helper loaded: file_helper
INFO - 2023-07-01 16:03:16 --> Helper loaded: html_helper
INFO - 2023-07-01 16:03:16 --> Helper loaded: text_helper
INFO - 2023-07-01 16:03:16 --> Helper loaded: form_helper
INFO - 2023-07-01 16:03:16 --> Helper loaded: lang_helper
INFO - 2023-07-01 16:03:16 --> Helper loaded: security_helper
INFO - 2023-07-01 16:03:16 --> Helper loaded: cookie_helper
INFO - 2023-07-01 16:03:16 --> Database Driver Class Initialized
INFO - 2023-07-01 16:03:16 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-01 16:03:16 --> Parser Class Initialized
INFO - 2023-07-01 16:03:16 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-01 16:03:16 --> Pagination Class Initialized
INFO - 2023-07-01 16:03:16 --> Form Validation Class Initialized
INFO - 2023-07-01 16:03:16 --> Controller Class Initialized
DEBUG - 2023-07-01 16:03:16 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-01 16:03:16 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-01 16:03:16 --> Model Class Initialized
INFO - 2023-07-01 16:03:17 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/gift/add_gift_form.php
DEBUG - 2023-07-01 16:03:17 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-07-01 16:03:17 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-07-01 16:03:17 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-07-01 16:03:17 --> Model Class Initialized
INFO - 2023-07-01 16:03:17 --> Model Class Initialized
INFO - 2023-07-01 16:03:17 --> Model Class Initialized
INFO - 2023-07-01 16:03:17 --> Model Class Initialized
INFO - 2023-07-01 16:03:17 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-07-01 16:03:17 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-07-01 16:03:17 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-07-01 16:03:17 --> Final output sent to browser
DEBUG - 2023-07-01 16:03:17 --> Total execution time: 0.1327
ERROR - 2023-07-01 16:04:00 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-01 16:04:00 --> Config Class Initialized
INFO - 2023-07-01 16:04:00 --> Hooks Class Initialized
DEBUG - 2023-07-01 16:04:00 --> UTF-8 Support Enabled
INFO - 2023-07-01 16:04:00 --> Utf8 Class Initialized
INFO - 2023-07-01 16:04:00 --> URI Class Initialized
INFO - 2023-07-01 16:04:00 --> Router Class Initialized
INFO - 2023-07-01 16:04:00 --> Output Class Initialized
INFO - 2023-07-01 16:04:00 --> Security Class Initialized
DEBUG - 2023-07-01 16:04:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-01 16:04:00 --> Input Class Initialized
INFO - 2023-07-01 16:04:00 --> Language Class Initialized
INFO - 2023-07-01 16:04:00 --> Loader Class Initialized
INFO - 2023-07-01 16:04:00 --> Helper loaded: url_helper
INFO - 2023-07-01 16:04:00 --> Helper loaded: file_helper
INFO - 2023-07-01 16:04:00 --> Helper loaded: html_helper
INFO - 2023-07-01 16:04:00 --> Helper loaded: text_helper
INFO - 2023-07-01 16:04:00 --> Helper loaded: form_helper
INFO - 2023-07-01 16:04:00 --> Helper loaded: lang_helper
INFO - 2023-07-01 16:04:00 --> Helper loaded: security_helper
INFO - 2023-07-01 16:04:00 --> Helper loaded: cookie_helper
INFO - 2023-07-01 16:04:00 --> Database Driver Class Initialized
INFO - 2023-07-01 16:04:00 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-01 16:04:00 --> Parser Class Initialized
INFO - 2023-07-01 16:04:00 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-01 16:04:00 --> Pagination Class Initialized
INFO - 2023-07-01 16:04:00 --> Form Validation Class Initialized
INFO - 2023-07-01 16:04:00 --> Controller Class Initialized
DEBUG - 2023-07-01 16:04:00 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-01 16:04:00 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-01 16:04:00 --> Model Class Initialized
DEBUG - 2023-07-01 16:04:00 --> Lgift class already loaded. Second attempt ignored.
INFO - 2023-07-01 16:04:00 --> Model Class Initialized
DEBUG - 2023-07-01 16:04:00 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-01 16:04:00 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-01 16:04:00 --> Model Class Initialized
DEBUG - 2023-07-01 16:04:00 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-01 16:04:00 --> Model Class Initialized
INFO - 2023-07-01 16:04:00 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/gift/gift.php
DEBUG - 2023-07-01 16:04:00 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-07-01 16:04:00 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-07-01 16:04:00 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-07-01 16:04:00 --> Model Class Initialized
INFO - 2023-07-01 16:04:00 --> Model Class Initialized
INFO - 2023-07-01 16:04:00 --> Model Class Initialized
INFO - 2023-07-01 16:04:00 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-07-01 16:04:00 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-07-01 16:04:00 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-07-01 16:04:00 --> Final output sent to browser
DEBUG - 2023-07-01 16:04:00 --> Total execution time: 0.1282
ERROR - 2023-07-01 16:04:01 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-01 16:04:01 --> Config Class Initialized
INFO - 2023-07-01 16:04:01 --> Hooks Class Initialized
DEBUG - 2023-07-01 16:04:01 --> UTF-8 Support Enabled
INFO - 2023-07-01 16:04:01 --> Utf8 Class Initialized
INFO - 2023-07-01 16:04:01 --> URI Class Initialized
INFO - 2023-07-01 16:04:01 --> Router Class Initialized
INFO - 2023-07-01 16:04:01 --> Output Class Initialized
INFO - 2023-07-01 16:04:01 --> Security Class Initialized
DEBUG - 2023-07-01 16:04:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-01 16:04:01 --> Input Class Initialized
INFO - 2023-07-01 16:04:01 --> Language Class Initialized
INFO - 2023-07-01 16:04:01 --> Loader Class Initialized
INFO - 2023-07-01 16:04:01 --> Helper loaded: url_helper
INFO - 2023-07-01 16:04:01 --> Helper loaded: file_helper
INFO - 2023-07-01 16:04:01 --> Helper loaded: html_helper
INFO - 2023-07-01 16:04:01 --> Helper loaded: text_helper
INFO - 2023-07-01 16:04:01 --> Helper loaded: form_helper
INFO - 2023-07-01 16:04:01 --> Helper loaded: lang_helper
INFO - 2023-07-01 16:04:01 --> Helper loaded: security_helper
INFO - 2023-07-01 16:04:01 --> Helper loaded: cookie_helper
INFO - 2023-07-01 16:04:01 --> Database Driver Class Initialized
INFO - 2023-07-01 16:04:01 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-01 16:04:01 --> Parser Class Initialized
INFO - 2023-07-01 16:04:01 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-01 16:04:01 --> Pagination Class Initialized
INFO - 2023-07-01 16:04:01 --> Form Validation Class Initialized
INFO - 2023-07-01 16:04:01 --> Controller Class Initialized
DEBUG - 2023-07-01 16:04:01 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-01 16:04:01 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-01 16:04:01 --> Model Class Initialized
INFO - 2023-07-01 16:04:01 --> Final output sent to browser
DEBUG - 2023-07-01 16:04:01 --> Total execution time: 0.0157
ERROR - 2023-07-01 16:04:18 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-01 16:04:18 --> Config Class Initialized
INFO - 2023-07-01 16:04:18 --> Hooks Class Initialized
DEBUG - 2023-07-01 16:04:18 --> UTF-8 Support Enabled
INFO - 2023-07-01 16:04:18 --> Utf8 Class Initialized
INFO - 2023-07-01 16:04:18 --> URI Class Initialized
INFO - 2023-07-01 16:04:18 --> Router Class Initialized
INFO - 2023-07-01 16:04:18 --> Output Class Initialized
INFO - 2023-07-01 16:04:18 --> Security Class Initialized
DEBUG - 2023-07-01 16:04:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-01 16:04:18 --> Input Class Initialized
INFO - 2023-07-01 16:04:18 --> Language Class Initialized
INFO - 2023-07-01 16:04:18 --> Loader Class Initialized
INFO - 2023-07-01 16:04:18 --> Helper loaded: url_helper
INFO - 2023-07-01 16:04:18 --> Helper loaded: file_helper
INFO - 2023-07-01 16:04:18 --> Helper loaded: html_helper
INFO - 2023-07-01 16:04:18 --> Helper loaded: text_helper
INFO - 2023-07-01 16:04:18 --> Helper loaded: form_helper
INFO - 2023-07-01 16:04:18 --> Helper loaded: lang_helper
INFO - 2023-07-01 16:04:18 --> Helper loaded: security_helper
INFO - 2023-07-01 16:04:18 --> Helper loaded: cookie_helper
INFO - 2023-07-01 16:04:18 --> Database Driver Class Initialized
INFO - 2023-07-01 16:04:18 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-01 16:04:18 --> Parser Class Initialized
INFO - 2023-07-01 16:04:18 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-01 16:04:18 --> Pagination Class Initialized
INFO - 2023-07-01 16:04:18 --> Form Validation Class Initialized
INFO - 2023-07-01 16:04:18 --> Controller Class Initialized
DEBUG - 2023-07-01 16:04:18 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-01 16:04:18 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-01 16:04:18 --> Model Class Initialized
INFO - 2023-07-01 16:04:18 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/gift/add_gift_form.php
DEBUG - 2023-07-01 16:04:18 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-07-01 16:04:18 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-07-01 16:04:18 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-07-01 16:04:18 --> Model Class Initialized
INFO - 2023-07-01 16:04:18 --> Model Class Initialized
INFO - 2023-07-01 16:04:18 --> Model Class Initialized
INFO - 2023-07-01 16:04:18 --> Model Class Initialized
INFO - 2023-07-01 16:04:18 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-07-01 16:04:18 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-07-01 16:04:18 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-07-01 16:04:18 --> Final output sent to browser
DEBUG - 2023-07-01 16:04:18 --> Total execution time: 0.1283
ERROR - 2023-07-01 16:05:14 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-01 16:05:14 --> Config Class Initialized
INFO - 2023-07-01 16:05:14 --> Hooks Class Initialized
DEBUG - 2023-07-01 16:05:14 --> UTF-8 Support Enabled
INFO - 2023-07-01 16:05:14 --> Utf8 Class Initialized
INFO - 2023-07-01 16:05:14 --> URI Class Initialized
INFO - 2023-07-01 16:05:14 --> Router Class Initialized
INFO - 2023-07-01 16:05:14 --> Output Class Initialized
INFO - 2023-07-01 16:05:14 --> Security Class Initialized
DEBUG - 2023-07-01 16:05:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-01 16:05:14 --> Input Class Initialized
INFO - 2023-07-01 16:05:14 --> Language Class Initialized
INFO - 2023-07-01 16:05:14 --> Loader Class Initialized
INFO - 2023-07-01 16:05:14 --> Helper loaded: url_helper
INFO - 2023-07-01 16:05:14 --> Helper loaded: file_helper
INFO - 2023-07-01 16:05:14 --> Helper loaded: html_helper
INFO - 2023-07-01 16:05:14 --> Helper loaded: text_helper
INFO - 2023-07-01 16:05:14 --> Helper loaded: form_helper
INFO - 2023-07-01 16:05:14 --> Helper loaded: lang_helper
INFO - 2023-07-01 16:05:14 --> Helper loaded: security_helper
INFO - 2023-07-01 16:05:14 --> Helper loaded: cookie_helper
INFO - 2023-07-01 16:05:14 --> Database Driver Class Initialized
INFO - 2023-07-01 16:05:14 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-01 16:05:14 --> Parser Class Initialized
INFO - 2023-07-01 16:05:14 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-01 16:05:14 --> Pagination Class Initialized
INFO - 2023-07-01 16:05:14 --> Form Validation Class Initialized
INFO - 2023-07-01 16:05:14 --> Controller Class Initialized
DEBUG - 2023-07-01 16:05:14 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-01 16:05:14 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-01 16:05:14 --> Model Class Initialized
INFO - 2023-07-01 16:05:14 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/category/add_category_form.php
DEBUG - 2023-07-01 16:05:14 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-07-01 16:05:14 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-07-01 16:05:14 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-07-01 16:05:14 --> Model Class Initialized
INFO - 2023-07-01 16:05:14 --> Model Class Initialized
INFO - 2023-07-01 16:05:14 --> Model Class Initialized
INFO - 2023-07-01 16:05:14 --> Model Class Initialized
INFO - 2023-07-01 16:05:14 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-07-01 16:05:14 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-07-01 16:05:14 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-07-01 16:05:14 --> Final output sent to browser
DEBUG - 2023-07-01 16:05:14 --> Total execution time: 0.1377
ERROR - 2023-07-01 16:05:22 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-01 16:05:22 --> Config Class Initialized
INFO - 2023-07-01 16:05:22 --> Hooks Class Initialized
DEBUG - 2023-07-01 16:05:22 --> UTF-8 Support Enabled
INFO - 2023-07-01 16:05:22 --> Utf8 Class Initialized
INFO - 2023-07-01 16:05:22 --> URI Class Initialized
INFO - 2023-07-01 16:05:22 --> Router Class Initialized
INFO - 2023-07-01 16:05:22 --> Output Class Initialized
INFO - 2023-07-01 16:05:22 --> Security Class Initialized
DEBUG - 2023-07-01 16:05:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-01 16:05:22 --> Input Class Initialized
INFO - 2023-07-01 16:05:22 --> Language Class Initialized
INFO - 2023-07-01 16:05:22 --> Loader Class Initialized
INFO - 2023-07-01 16:05:22 --> Helper loaded: url_helper
INFO - 2023-07-01 16:05:22 --> Helper loaded: file_helper
INFO - 2023-07-01 16:05:22 --> Helper loaded: html_helper
INFO - 2023-07-01 16:05:22 --> Helper loaded: text_helper
INFO - 2023-07-01 16:05:22 --> Helper loaded: form_helper
INFO - 2023-07-01 16:05:22 --> Helper loaded: lang_helper
INFO - 2023-07-01 16:05:22 --> Helper loaded: security_helper
INFO - 2023-07-01 16:05:22 --> Helper loaded: cookie_helper
INFO - 2023-07-01 16:05:22 --> Database Driver Class Initialized
INFO - 2023-07-01 16:05:22 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-01 16:05:22 --> Parser Class Initialized
INFO - 2023-07-01 16:05:22 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-01 16:05:22 --> Pagination Class Initialized
INFO - 2023-07-01 16:05:22 --> Form Validation Class Initialized
INFO - 2023-07-01 16:05:22 --> Controller Class Initialized
DEBUG - 2023-07-01 16:05:22 --> Auth class already loaded. Second attempt ignored.
INFO - 2023-07-01 16:05:22 --> Model Class Initialized
INFO - 2023-07-01 16:05:22 --> Model Class Initialized
INFO - 2023-07-01 16:05:22 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/product/add_type_form.php
DEBUG - 2023-07-01 16:05:22 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-07-01 16:05:22 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-07-01 16:05:22 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-07-01 16:05:22 --> Model Class Initialized
INFO - 2023-07-01 16:05:22 --> Model Class Initialized
INFO - 2023-07-01 16:05:22 --> Model Class Initialized
INFO - 2023-07-01 16:05:22 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-07-01 16:05:22 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-07-01 16:05:22 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-07-01 16:05:22 --> Final output sent to browser
DEBUG - 2023-07-01 16:05:22 --> Total execution time: 0.1338
ERROR - 2023-07-01 16:05:32 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-01 16:05:32 --> Config Class Initialized
INFO - 2023-07-01 16:05:32 --> Hooks Class Initialized
DEBUG - 2023-07-01 16:05:32 --> UTF-8 Support Enabled
INFO - 2023-07-01 16:05:32 --> Utf8 Class Initialized
INFO - 2023-07-01 16:05:32 --> URI Class Initialized
INFO - 2023-07-01 16:05:32 --> Router Class Initialized
INFO - 2023-07-01 16:05:32 --> Output Class Initialized
INFO - 2023-07-01 16:05:32 --> Security Class Initialized
DEBUG - 2023-07-01 16:05:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-01 16:05:32 --> Input Class Initialized
INFO - 2023-07-01 16:05:32 --> Language Class Initialized
INFO - 2023-07-01 16:05:32 --> Loader Class Initialized
INFO - 2023-07-01 16:05:32 --> Helper loaded: url_helper
INFO - 2023-07-01 16:05:32 --> Helper loaded: file_helper
INFO - 2023-07-01 16:05:32 --> Helper loaded: html_helper
INFO - 2023-07-01 16:05:32 --> Helper loaded: text_helper
INFO - 2023-07-01 16:05:32 --> Helper loaded: form_helper
INFO - 2023-07-01 16:05:32 --> Helper loaded: lang_helper
INFO - 2023-07-01 16:05:32 --> Helper loaded: security_helper
INFO - 2023-07-01 16:05:32 --> Helper loaded: cookie_helper
INFO - 2023-07-01 16:05:32 --> Database Driver Class Initialized
INFO - 2023-07-01 16:05:32 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-01 16:05:32 --> Parser Class Initialized
INFO - 2023-07-01 16:05:32 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-01 16:05:32 --> Pagination Class Initialized
INFO - 2023-07-01 16:05:32 --> Form Validation Class Initialized
INFO - 2023-07-01 16:05:32 --> Controller Class Initialized
DEBUG - 2023-07-01 16:05:32 --> Auth class already loaded. Second attempt ignored.
INFO - 2023-07-01 16:05:32 --> Model Class Initialized
INFO - 2023-07-01 16:05:32 --> Model Class Initialized
ERROR - 2023-07-01 16:05:33 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-01 16:05:33 --> Config Class Initialized
INFO - 2023-07-01 16:05:33 --> Hooks Class Initialized
DEBUG - 2023-07-01 16:05:33 --> UTF-8 Support Enabled
INFO - 2023-07-01 16:05:33 --> Utf8 Class Initialized
INFO - 2023-07-01 16:05:33 --> URI Class Initialized
INFO - 2023-07-01 16:05:33 --> Router Class Initialized
INFO - 2023-07-01 16:05:33 --> Output Class Initialized
INFO - 2023-07-01 16:05:33 --> Security Class Initialized
DEBUG - 2023-07-01 16:05:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-01 16:05:33 --> Input Class Initialized
INFO - 2023-07-01 16:05:33 --> Language Class Initialized
INFO - 2023-07-01 16:05:33 --> Loader Class Initialized
INFO - 2023-07-01 16:05:33 --> Helper loaded: url_helper
INFO - 2023-07-01 16:05:33 --> Helper loaded: file_helper
INFO - 2023-07-01 16:05:33 --> Helper loaded: html_helper
INFO - 2023-07-01 16:05:33 --> Helper loaded: text_helper
INFO - 2023-07-01 16:05:33 --> Helper loaded: form_helper
INFO - 2023-07-01 16:05:33 --> Helper loaded: lang_helper
INFO - 2023-07-01 16:05:33 --> Helper loaded: security_helper
INFO - 2023-07-01 16:05:33 --> Helper loaded: cookie_helper
INFO - 2023-07-01 16:05:33 --> Database Driver Class Initialized
INFO - 2023-07-01 16:05:33 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-01 16:05:33 --> Parser Class Initialized
INFO - 2023-07-01 16:05:33 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-01 16:05:33 --> Pagination Class Initialized
INFO - 2023-07-01 16:05:33 --> Form Validation Class Initialized
INFO - 2023-07-01 16:05:33 --> Controller Class Initialized
DEBUG - 2023-07-01 16:05:33 --> Auth class already loaded. Second attempt ignored.
INFO - 2023-07-01 16:05:33 --> Model Class Initialized
INFO - 2023-07-01 16:05:33 --> Model Class Initialized
INFO - 2023-07-01 16:05:33 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/product/add_type_form.php
DEBUG - 2023-07-01 16:05:33 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-07-01 16:05:33 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-07-01 16:05:33 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-07-01 16:05:33 --> Model Class Initialized
INFO - 2023-07-01 16:05:33 --> Model Class Initialized
INFO - 2023-07-01 16:05:33 --> Model Class Initialized
INFO - 2023-07-01 16:05:33 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-07-01 16:05:33 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-07-01 16:05:33 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-07-01 16:05:33 --> Final output sent to browser
DEBUG - 2023-07-01 16:05:33 --> Total execution time: 0.1263
ERROR - 2023-07-01 16:05:40 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-01 16:05:40 --> Config Class Initialized
INFO - 2023-07-01 16:05:40 --> Hooks Class Initialized
DEBUG - 2023-07-01 16:05:40 --> UTF-8 Support Enabled
INFO - 2023-07-01 16:05:40 --> Utf8 Class Initialized
INFO - 2023-07-01 16:05:40 --> URI Class Initialized
INFO - 2023-07-01 16:05:40 --> Router Class Initialized
INFO - 2023-07-01 16:05:40 --> Output Class Initialized
INFO - 2023-07-01 16:05:40 --> Security Class Initialized
DEBUG - 2023-07-01 16:05:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-01 16:05:40 --> Input Class Initialized
INFO - 2023-07-01 16:05:40 --> Language Class Initialized
INFO - 2023-07-01 16:05:40 --> Loader Class Initialized
INFO - 2023-07-01 16:05:40 --> Helper loaded: url_helper
INFO - 2023-07-01 16:05:40 --> Helper loaded: file_helper
INFO - 2023-07-01 16:05:40 --> Helper loaded: html_helper
INFO - 2023-07-01 16:05:40 --> Helper loaded: text_helper
INFO - 2023-07-01 16:05:40 --> Helper loaded: form_helper
INFO - 2023-07-01 16:05:40 --> Helper loaded: lang_helper
INFO - 2023-07-01 16:05:40 --> Helper loaded: security_helper
INFO - 2023-07-01 16:05:40 --> Helper loaded: cookie_helper
INFO - 2023-07-01 16:05:40 --> Database Driver Class Initialized
INFO - 2023-07-01 16:05:40 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-01 16:05:40 --> Parser Class Initialized
INFO - 2023-07-01 16:05:40 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-01 16:05:40 --> Pagination Class Initialized
INFO - 2023-07-01 16:05:40 --> Form Validation Class Initialized
INFO - 2023-07-01 16:05:40 --> Controller Class Initialized
DEBUG - 2023-07-01 16:05:40 --> Auth class already loaded. Second attempt ignored.
INFO - 2023-07-01 16:05:40 --> Model Class Initialized
INFO - 2023-07-01 16:05:40 --> Model Class Initialized
INFO - 2023-07-01 16:05:40 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/product/unit_list.php
DEBUG - 2023-07-01 16:05:40 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-07-01 16:05:40 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-07-01 16:05:40 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-07-01 16:05:40 --> Model Class Initialized
INFO - 2023-07-01 16:05:40 --> Model Class Initialized
INFO - 2023-07-01 16:05:40 --> Model Class Initialized
INFO - 2023-07-01 16:05:40 --> Model Class Initialized
INFO - 2023-07-01 16:05:41 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-07-01 16:05:41 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-07-01 16:05:41 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-07-01 16:05:41 --> Final output sent to browser
DEBUG - 2023-07-01 16:05:41 --> Total execution time: 0.1411
ERROR - 2023-07-01 16:05:54 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-01 16:05:54 --> Config Class Initialized
INFO - 2023-07-01 16:05:54 --> Hooks Class Initialized
DEBUG - 2023-07-01 16:05:54 --> UTF-8 Support Enabled
INFO - 2023-07-01 16:05:54 --> Utf8 Class Initialized
INFO - 2023-07-01 16:05:54 --> URI Class Initialized
INFO - 2023-07-01 16:05:54 --> Router Class Initialized
INFO - 2023-07-01 16:05:54 --> Output Class Initialized
INFO - 2023-07-01 16:05:54 --> Security Class Initialized
DEBUG - 2023-07-01 16:05:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-01 16:05:54 --> Input Class Initialized
INFO - 2023-07-01 16:05:54 --> Language Class Initialized
INFO - 2023-07-01 16:05:54 --> Loader Class Initialized
INFO - 2023-07-01 16:05:54 --> Helper loaded: url_helper
INFO - 2023-07-01 16:05:54 --> Helper loaded: file_helper
INFO - 2023-07-01 16:05:54 --> Helper loaded: html_helper
INFO - 2023-07-01 16:05:54 --> Helper loaded: text_helper
INFO - 2023-07-01 16:05:54 --> Helper loaded: form_helper
INFO - 2023-07-01 16:05:54 --> Helper loaded: lang_helper
INFO - 2023-07-01 16:05:54 --> Helper loaded: security_helper
INFO - 2023-07-01 16:05:54 --> Helper loaded: cookie_helper
INFO - 2023-07-01 16:05:54 --> Database Driver Class Initialized
INFO - 2023-07-01 16:05:54 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-01 16:05:54 --> Parser Class Initialized
INFO - 2023-07-01 16:05:54 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-01 16:05:54 --> Pagination Class Initialized
INFO - 2023-07-01 16:05:54 --> Form Validation Class Initialized
INFO - 2023-07-01 16:05:54 --> Controller Class Initialized
DEBUG - 2023-07-01 16:05:54 --> Auth class already loaded. Second attempt ignored.
INFO - 2023-07-01 16:05:54 --> Model Class Initialized
INFO - 2023-07-01 16:05:54 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/product/add_product_csv.php
DEBUG - 2023-07-01 16:05:54 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-07-01 16:05:54 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-07-01 16:05:54 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-07-01 16:05:54 --> Model Class Initialized
INFO - 2023-07-01 16:05:54 --> Model Class Initialized
INFO - 2023-07-01 16:05:54 --> Model Class Initialized
INFO - 2023-07-01 16:05:54 --> Model Class Initialized
INFO - 2023-07-01 16:05:54 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-07-01 16:05:54 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-07-01 16:05:54 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-07-01 16:05:54 --> Final output sent to browser
DEBUG - 2023-07-01 16:05:54 --> Total execution time: 0.1479
ERROR - 2023-07-01 16:06:18 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-01 16:06:18 --> Config Class Initialized
INFO - 2023-07-01 16:06:18 --> Hooks Class Initialized
DEBUG - 2023-07-01 16:06:18 --> UTF-8 Support Enabled
INFO - 2023-07-01 16:06:18 --> Utf8 Class Initialized
INFO - 2023-07-01 16:06:18 --> URI Class Initialized
INFO - 2023-07-01 16:06:18 --> Router Class Initialized
INFO - 2023-07-01 16:06:18 --> Output Class Initialized
INFO - 2023-07-01 16:06:18 --> Security Class Initialized
DEBUG - 2023-07-01 16:06:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-01 16:06:18 --> Input Class Initialized
INFO - 2023-07-01 16:06:18 --> Language Class Initialized
INFO - 2023-07-01 16:06:18 --> Loader Class Initialized
INFO - 2023-07-01 16:06:18 --> Helper loaded: url_helper
INFO - 2023-07-01 16:06:18 --> Helper loaded: file_helper
INFO - 2023-07-01 16:06:18 --> Helper loaded: html_helper
INFO - 2023-07-01 16:06:18 --> Helper loaded: text_helper
INFO - 2023-07-01 16:06:18 --> Helper loaded: form_helper
INFO - 2023-07-01 16:06:18 --> Helper loaded: lang_helper
INFO - 2023-07-01 16:06:18 --> Helper loaded: security_helper
INFO - 2023-07-01 16:06:18 --> Helper loaded: cookie_helper
INFO - 2023-07-01 16:06:18 --> Database Driver Class Initialized
INFO - 2023-07-01 16:06:18 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-01 16:06:18 --> Parser Class Initialized
INFO - 2023-07-01 16:06:18 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-01 16:06:18 --> Pagination Class Initialized
INFO - 2023-07-01 16:06:18 --> Form Validation Class Initialized
INFO - 2023-07-01 16:06:18 --> Controller Class Initialized
INFO - 2023-07-01 16:06:18 --> Model Class Initialized
INFO - 2023-07-01 16:06:18 --> Model Class Initialized
INFO - 2023-07-01 16:06:18 --> Model Class Initialized
INFO - 2023-07-01 16:06:18 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/report/stock_report_batch_wise.php
DEBUG - 2023-07-01 16:06:18 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-07-01 16:06:18 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-07-01 16:06:18 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-07-01 16:06:18 --> Model Class Initialized
INFO - 2023-07-01 16:06:18 --> Model Class Initialized
INFO - 2023-07-01 16:06:18 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-07-01 16:06:18 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-07-01 16:06:18 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-07-01 16:06:18 --> Final output sent to browser
DEBUG - 2023-07-01 16:06:18 --> Total execution time: 0.1382
ERROR - 2023-07-01 16:06:18 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-01 16:06:18 --> Config Class Initialized
INFO - 2023-07-01 16:06:18 --> Hooks Class Initialized
DEBUG - 2023-07-01 16:06:18 --> UTF-8 Support Enabled
INFO - 2023-07-01 16:06:18 --> Utf8 Class Initialized
INFO - 2023-07-01 16:06:18 --> URI Class Initialized
INFO - 2023-07-01 16:06:18 --> Router Class Initialized
INFO - 2023-07-01 16:06:18 --> Output Class Initialized
INFO - 2023-07-01 16:06:18 --> Security Class Initialized
DEBUG - 2023-07-01 16:06:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-01 16:06:18 --> Input Class Initialized
INFO - 2023-07-01 16:06:18 --> Language Class Initialized
INFO - 2023-07-01 16:06:18 --> Loader Class Initialized
INFO - 2023-07-01 16:06:18 --> Helper loaded: url_helper
INFO - 2023-07-01 16:06:18 --> Helper loaded: file_helper
INFO - 2023-07-01 16:06:18 --> Helper loaded: html_helper
INFO - 2023-07-01 16:06:18 --> Helper loaded: text_helper
INFO - 2023-07-01 16:06:18 --> Helper loaded: form_helper
INFO - 2023-07-01 16:06:18 --> Helper loaded: lang_helper
INFO - 2023-07-01 16:06:18 --> Helper loaded: security_helper
INFO - 2023-07-01 16:06:18 --> Helper loaded: cookie_helper
INFO - 2023-07-01 16:06:18 --> Database Driver Class Initialized
INFO - 2023-07-01 16:06:18 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-01 16:06:18 --> Parser Class Initialized
INFO - 2023-07-01 16:06:18 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-01 16:06:18 --> Pagination Class Initialized
INFO - 2023-07-01 16:06:18 --> Form Validation Class Initialized
INFO - 2023-07-01 16:06:18 --> Controller Class Initialized
INFO - 2023-07-01 16:06:18 --> Model Class Initialized
INFO - 2023-07-01 16:06:18 --> Model Class Initialized
INFO - 2023-07-01 16:06:18 --> Final output sent to browser
DEBUG - 2023-07-01 16:06:18 --> Total execution time: 0.0235
ERROR - 2023-07-01 16:06:21 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-01 16:06:21 --> Config Class Initialized
INFO - 2023-07-01 16:06:21 --> Hooks Class Initialized
DEBUG - 2023-07-01 16:06:21 --> UTF-8 Support Enabled
INFO - 2023-07-01 16:06:21 --> Utf8 Class Initialized
INFO - 2023-07-01 16:06:21 --> URI Class Initialized
INFO - 2023-07-01 16:06:21 --> Router Class Initialized
INFO - 2023-07-01 16:06:21 --> Output Class Initialized
INFO - 2023-07-01 16:06:21 --> Security Class Initialized
DEBUG - 2023-07-01 16:06:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-01 16:06:21 --> Input Class Initialized
INFO - 2023-07-01 16:06:21 --> Language Class Initialized
INFO - 2023-07-01 16:06:21 --> Loader Class Initialized
INFO - 2023-07-01 16:06:21 --> Helper loaded: url_helper
INFO - 2023-07-01 16:06:21 --> Helper loaded: file_helper
INFO - 2023-07-01 16:06:21 --> Helper loaded: html_helper
INFO - 2023-07-01 16:06:21 --> Helper loaded: text_helper
INFO - 2023-07-01 16:06:21 --> Helper loaded: form_helper
INFO - 2023-07-01 16:06:21 --> Helper loaded: lang_helper
INFO - 2023-07-01 16:06:21 --> Helper loaded: security_helper
INFO - 2023-07-01 16:06:21 --> Helper loaded: cookie_helper
INFO - 2023-07-01 16:06:21 --> Database Driver Class Initialized
INFO - 2023-07-01 16:06:21 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-01 16:06:21 --> Parser Class Initialized
INFO - 2023-07-01 16:06:21 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-01 16:06:21 --> Pagination Class Initialized
INFO - 2023-07-01 16:06:21 --> Form Validation Class Initialized
INFO - 2023-07-01 16:06:21 --> Controller Class Initialized
DEBUG - 2023-07-01 16:06:21 --> Auth class already loaded. Second attempt ignored.
INFO - 2023-07-01 16:06:21 --> Model Class Initialized
INFO - 2023-07-01 16:06:21 --> Model Class Initialized
INFO - 2023-07-01 16:06:21 --> Model Class Initialized
INFO - 2023-07-01 16:06:21 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/product/product_details.php
DEBUG - 2023-07-01 16:06:21 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-07-01 16:06:21 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-07-01 16:06:21 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-07-01 16:06:21 --> Model Class Initialized
INFO - 2023-07-01 16:06:21 --> Model Class Initialized
INFO - 2023-07-01 16:06:22 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-07-01 16:06:22 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-07-01 16:06:22 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-07-01 16:06:22 --> Final output sent to browser
DEBUG - 2023-07-01 16:06:22 --> Total execution time: 0.1690
ERROR - 2023-07-01 16:06:43 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-01 16:06:43 --> Config Class Initialized
INFO - 2023-07-01 16:06:43 --> Hooks Class Initialized
DEBUG - 2023-07-01 16:06:43 --> UTF-8 Support Enabled
INFO - 2023-07-01 16:06:43 --> Utf8 Class Initialized
INFO - 2023-07-01 16:06:43 --> URI Class Initialized
INFO - 2023-07-01 16:06:43 --> Router Class Initialized
INFO - 2023-07-01 16:06:43 --> Output Class Initialized
INFO - 2023-07-01 16:06:43 --> Security Class Initialized
DEBUG - 2023-07-01 16:06:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-01 16:06:43 --> Input Class Initialized
INFO - 2023-07-01 16:06:43 --> Language Class Initialized
INFO - 2023-07-01 16:06:43 --> Loader Class Initialized
INFO - 2023-07-01 16:06:43 --> Helper loaded: url_helper
INFO - 2023-07-01 16:06:43 --> Helper loaded: file_helper
INFO - 2023-07-01 16:06:43 --> Helper loaded: html_helper
INFO - 2023-07-01 16:06:43 --> Helper loaded: text_helper
INFO - 2023-07-01 16:06:43 --> Helper loaded: form_helper
INFO - 2023-07-01 16:06:43 --> Helper loaded: lang_helper
INFO - 2023-07-01 16:06:43 --> Helper loaded: security_helper
INFO - 2023-07-01 16:06:43 --> Helper loaded: cookie_helper
INFO - 2023-07-01 16:06:43 --> Database Driver Class Initialized
INFO - 2023-07-01 16:06:43 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-01 16:06:43 --> Parser Class Initialized
INFO - 2023-07-01 16:06:43 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-01 16:06:43 --> Pagination Class Initialized
INFO - 2023-07-01 16:06:43 --> Form Validation Class Initialized
INFO - 2023-07-01 16:06:43 --> Controller Class Initialized
DEBUG - 2023-07-01 16:06:43 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-01 16:06:43 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-01 16:06:43 --> Model Class Initialized
INFO - 2023-07-01 16:06:43 --> Model Class Initialized
INFO - 2023-07-01 16:06:43 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/manufacturer/manufacturer.php
DEBUG - 2023-07-01 16:06:43 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-07-01 16:06:43 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-07-01 16:06:43 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-07-01 16:06:43 --> Model Class Initialized
INFO - 2023-07-01 16:06:43 --> Model Class Initialized
INFO - 2023-07-01 16:06:43 --> Model Class Initialized
INFO - 2023-07-01 16:06:43 --> Model Class Initialized
INFO - 2023-07-01 16:06:43 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-07-01 16:06:43 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-07-01 16:06:43 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-07-01 16:06:43 --> Final output sent to browser
DEBUG - 2023-07-01 16:06:43 --> Total execution time: 0.1372
ERROR - 2023-07-01 16:07:40 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-01 16:07:40 --> Config Class Initialized
INFO - 2023-07-01 16:07:40 --> Hooks Class Initialized
DEBUG - 2023-07-01 16:07:40 --> UTF-8 Support Enabled
INFO - 2023-07-01 16:07:40 --> Utf8 Class Initialized
INFO - 2023-07-01 16:07:40 --> URI Class Initialized
INFO - 2023-07-01 16:07:40 --> Router Class Initialized
INFO - 2023-07-01 16:07:40 --> Output Class Initialized
INFO - 2023-07-01 16:07:40 --> Security Class Initialized
DEBUG - 2023-07-01 16:07:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-01 16:07:40 --> Input Class Initialized
INFO - 2023-07-01 16:07:40 --> Language Class Initialized
INFO - 2023-07-01 16:07:40 --> Loader Class Initialized
INFO - 2023-07-01 16:07:40 --> Helper loaded: url_helper
INFO - 2023-07-01 16:07:40 --> Helper loaded: file_helper
INFO - 2023-07-01 16:07:40 --> Helper loaded: html_helper
INFO - 2023-07-01 16:07:40 --> Helper loaded: text_helper
INFO - 2023-07-01 16:07:40 --> Helper loaded: form_helper
INFO - 2023-07-01 16:07:40 --> Helper loaded: lang_helper
INFO - 2023-07-01 16:07:40 --> Helper loaded: security_helper
INFO - 2023-07-01 16:07:40 --> Helper loaded: cookie_helper
INFO - 2023-07-01 16:07:40 --> Database Driver Class Initialized
INFO - 2023-07-01 16:07:40 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-01 16:07:40 --> Parser Class Initialized
INFO - 2023-07-01 16:07:40 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-01 16:07:40 --> Pagination Class Initialized
INFO - 2023-07-01 16:07:41 --> Form Validation Class Initialized
INFO - 2023-07-01 16:07:41 --> Controller Class Initialized
DEBUG - 2023-07-01 16:07:41 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-01 16:07:41 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-01 16:07:41 --> Model Class Initialized
INFO - 2023-07-01 16:07:41 --> Model Class Initialized
INFO - 2023-07-01 16:07:41 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/manufacturer/manufacturer.php
DEBUG - 2023-07-01 16:07:41 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-07-01 16:07:41 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-07-01 16:07:41 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-07-01 16:07:41 --> Model Class Initialized
INFO - 2023-07-01 16:07:41 --> Model Class Initialized
INFO - 2023-07-01 16:07:41 --> Model Class Initialized
INFO - 2023-07-01 16:07:41 --> Model Class Initialized
INFO - 2023-07-01 16:07:41 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-07-01 16:07:41 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-07-01 16:07:41 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-07-01 16:07:41 --> Final output sent to browser
DEBUG - 2023-07-01 16:07:41 --> Total execution time: 0.1330
ERROR - 2023-07-01 16:09:11 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-01 16:09:11 --> Config Class Initialized
INFO - 2023-07-01 16:09:11 --> Hooks Class Initialized
DEBUG - 2023-07-01 16:09:11 --> UTF-8 Support Enabled
INFO - 2023-07-01 16:09:11 --> Utf8 Class Initialized
INFO - 2023-07-01 16:09:11 --> URI Class Initialized
INFO - 2023-07-01 16:09:11 --> Router Class Initialized
INFO - 2023-07-01 16:09:11 --> Output Class Initialized
INFO - 2023-07-01 16:09:11 --> Security Class Initialized
DEBUG - 2023-07-01 16:09:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-01 16:09:11 --> Input Class Initialized
INFO - 2023-07-01 16:09:11 --> Language Class Initialized
INFO - 2023-07-01 16:09:11 --> Loader Class Initialized
INFO - 2023-07-01 16:09:11 --> Helper loaded: url_helper
INFO - 2023-07-01 16:09:11 --> Helper loaded: file_helper
INFO - 2023-07-01 16:09:11 --> Helper loaded: html_helper
INFO - 2023-07-01 16:09:11 --> Helper loaded: text_helper
INFO - 2023-07-01 16:09:11 --> Helper loaded: form_helper
INFO - 2023-07-01 16:09:11 --> Helper loaded: lang_helper
INFO - 2023-07-01 16:09:11 --> Helper loaded: security_helper
INFO - 2023-07-01 16:09:11 --> Helper loaded: cookie_helper
INFO - 2023-07-01 16:09:11 --> Database Driver Class Initialized
INFO - 2023-07-01 16:09:11 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-01 16:09:11 --> Parser Class Initialized
INFO - 2023-07-01 16:09:11 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-01 16:09:11 --> Pagination Class Initialized
INFO - 2023-07-01 16:09:11 --> Form Validation Class Initialized
INFO - 2023-07-01 16:09:11 --> Controller Class Initialized
INFO - 2023-07-01 16:09:11 --> Model Class Initialized
INFO - 2023-07-01 16:09:11 --> Model Class Initialized
INFO - 2023-07-01 16:09:11 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/report/stock_report.php
DEBUG - 2023-07-01 16:09:11 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-07-01 16:09:11 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-07-01 16:09:11 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-07-01 16:09:11 --> Model Class Initialized
INFO - 2023-07-01 16:09:11 --> Model Class Initialized
INFO - 2023-07-01 16:09:11 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-07-01 16:09:11 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-07-01 16:09:11 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-07-01 16:09:11 --> Final output sent to browser
DEBUG - 2023-07-01 16:09:11 --> Total execution time: 0.1357
ERROR - 2023-07-01 16:09:12 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-01 16:09:12 --> Config Class Initialized
INFO - 2023-07-01 16:09:12 --> Hooks Class Initialized
DEBUG - 2023-07-01 16:09:12 --> UTF-8 Support Enabled
INFO - 2023-07-01 16:09:12 --> Utf8 Class Initialized
INFO - 2023-07-01 16:09:12 --> URI Class Initialized
INFO - 2023-07-01 16:09:12 --> Router Class Initialized
INFO - 2023-07-01 16:09:12 --> Output Class Initialized
INFO - 2023-07-01 16:09:12 --> Security Class Initialized
DEBUG - 2023-07-01 16:09:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-01 16:09:12 --> Input Class Initialized
INFO - 2023-07-01 16:09:12 --> Language Class Initialized
INFO - 2023-07-01 16:09:12 --> Loader Class Initialized
INFO - 2023-07-01 16:09:12 --> Helper loaded: url_helper
INFO - 2023-07-01 16:09:12 --> Helper loaded: file_helper
INFO - 2023-07-01 16:09:12 --> Helper loaded: html_helper
INFO - 2023-07-01 16:09:12 --> Helper loaded: text_helper
INFO - 2023-07-01 16:09:12 --> Helper loaded: form_helper
INFO - 2023-07-01 16:09:12 --> Helper loaded: lang_helper
INFO - 2023-07-01 16:09:12 --> Helper loaded: security_helper
INFO - 2023-07-01 16:09:12 --> Helper loaded: cookie_helper
INFO - 2023-07-01 16:09:12 --> Database Driver Class Initialized
INFO - 2023-07-01 16:09:12 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-01 16:09:12 --> Parser Class Initialized
INFO - 2023-07-01 16:09:12 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-01 16:09:12 --> Pagination Class Initialized
INFO - 2023-07-01 16:09:12 --> Form Validation Class Initialized
INFO - 2023-07-01 16:09:12 --> Controller Class Initialized
INFO - 2023-07-01 16:09:12 --> Model Class Initialized
INFO - 2023-07-01 16:09:12 --> Model Class Initialized
INFO - 2023-07-01 16:09:12 --> Final output sent to browser
DEBUG - 2023-07-01 16:09:12 --> Total execution time: 0.0211
ERROR - 2023-07-01 16:15:30 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-01 16:15:30 --> Config Class Initialized
INFO - 2023-07-01 16:15:30 --> Hooks Class Initialized
DEBUG - 2023-07-01 16:15:30 --> UTF-8 Support Enabled
INFO - 2023-07-01 16:15:30 --> Utf8 Class Initialized
INFO - 2023-07-01 16:15:30 --> URI Class Initialized
INFO - 2023-07-01 16:15:30 --> Router Class Initialized
INFO - 2023-07-01 16:15:30 --> Output Class Initialized
INFO - 2023-07-01 16:15:30 --> Security Class Initialized
DEBUG - 2023-07-01 16:15:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-01 16:15:30 --> Input Class Initialized
INFO - 2023-07-01 16:15:30 --> Language Class Initialized
INFO - 2023-07-01 16:15:30 --> Loader Class Initialized
INFO - 2023-07-01 16:15:30 --> Helper loaded: url_helper
INFO - 2023-07-01 16:15:30 --> Helper loaded: file_helper
INFO - 2023-07-01 16:15:30 --> Helper loaded: html_helper
INFO - 2023-07-01 16:15:30 --> Helper loaded: text_helper
INFO - 2023-07-01 16:15:30 --> Helper loaded: form_helper
INFO - 2023-07-01 16:15:30 --> Helper loaded: lang_helper
INFO - 2023-07-01 16:15:30 --> Helper loaded: security_helper
INFO - 2023-07-01 16:15:30 --> Helper loaded: cookie_helper
INFO - 2023-07-01 16:15:30 --> Database Driver Class Initialized
INFO - 2023-07-01 16:15:30 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-01 16:15:30 --> Parser Class Initialized
INFO - 2023-07-01 16:15:30 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-01 16:15:30 --> Pagination Class Initialized
INFO - 2023-07-01 16:15:30 --> Form Validation Class Initialized
INFO - 2023-07-01 16:15:30 --> Controller Class Initialized
INFO - 2023-07-01 16:15:30 --> Model Class Initialized
INFO - 2023-07-01 16:15:30 --> Model Class Initialized
INFO - 2023-07-01 16:15:30 --> Final output sent to browser
DEBUG - 2023-07-01 16:15:30 --> Total execution time: 0.0338
ERROR - 2023-07-01 16:16:26 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-01 16:16:26 --> Config Class Initialized
INFO - 2023-07-01 16:16:26 --> Hooks Class Initialized
DEBUG - 2023-07-01 16:16:26 --> UTF-8 Support Enabled
INFO - 2023-07-01 16:16:26 --> Utf8 Class Initialized
INFO - 2023-07-01 16:16:26 --> URI Class Initialized
INFO - 2023-07-01 16:16:26 --> Router Class Initialized
INFO - 2023-07-01 16:16:26 --> Output Class Initialized
INFO - 2023-07-01 16:16:26 --> Security Class Initialized
DEBUG - 2023-07-01 16:16:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-01 16:16:26 --> Input Class Initialized
INFO - 2023-07-01 16:16:26 --> Language Class Initialized
INFO - 2023-07-01 16:16:26 --> Loader Class Initialized
INFO - 2023-07-01 16:16:26 --> Helper loaded: url_helper
INFO - 2023-07-01 16:16:26 --> Helper loaded: file_helper
INFO - 2023-07-01 16:16:26 --> Helper loaded: html_helper
INFO - 2023-07-01 16:16:26 --> Helper loaded: text_helper
INFO - 2023-07-01 16:16:26 --> Helper loaded: form_helper
INFO - 2023-07-01 16:16:26 --> Helper loaded: lang_helper
INFO - 2023-07-01 16:16:26 --> Helper loaded: security_helper
INFO - 2023-07-01 16:16:26 --> Helper loaded: cookie_helper
INFO - 2023-07-01 16:16:26 --> Database Driver Class Initialized
INFO - 2023-07-01 16:16:26 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-01 16:16:26 --> Parser Class Initialized
INFO - 2023-07-01 16:16:26 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-01 16:16:26 --> Pagination Class Initialized
INFO - 2023-07-01 16:16:26 --> Form Validation Class Initialized
INFO - 2023-07-01 16:16:26 --> Controller Class Initialized
ERROR - 2023-07-01 16:16:27 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-01 16:16:27 --> Config Class Initialized
INFO - 2023-07-01 16:16:27 --> Hooks Class Initialized
DEBUG - 2023-07-01 16:16:27 --> UTF-8 Support Enabled
INFO - 2023-07-01 16:16:27 --> Utf8 Class Initialized
INFO - 2023-07-01 16:16:27 --> URI Class Initialized
INFO - 2023-07-01 16:16:27 --> Router Class Initialized
INFO - 2023-07-01 16:16:27 --> Output Class Initialized
INFO - 2023-07-01 16:16:27 --> Security Class Initialized
DEBUG - 2023-07-01 16:16:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-01 16:16:27 --> Input Class Initialized
INFO - 2023-07-01 16:16:27 --> Language Class Initialized
INFO - 2023-07-01 16:16:27 --> Loader Class Initialized
INFO - 2023-07-01 16:16:27 --> Helper loaded: url_helper
INFO - 2023-07-01 16:16:27 --> Helper loaded: file_helper
INFO - 2023-07-01 16:16:27 --> Helper loaded: html_helper
INFO - 2023-07-01 16:16:27 --> Helper loaded: text_helper
INFO - 2023-07-01 16:16:27 --> Helper loaded: form_helper
INFO - 2023-07-01 16:16:27 --> Helper loaded: lang_helper
INFO - 2023-07-01 16:16:27 --> Helper loaded: security_helper
INFO - 2023-07-01 16:16:27 --> Helper loaded: cookie_helper
INFO - 2023-07-01 16:16:27 --> Database Driver Class Initialized
INFO - 2023-07-01 16:16:27 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-01 16:16:27 --> Parser Class Initialized
INFO - 2023-07-01 16:16:27 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-01 16:16:27 --> Pagination Class Initialized
INFO - 2023-07-01 16:16:27 --> Form Validation Class Initialized
INFO - 2023-07-01 16:16:27 --> Controller Class Initialized
INFO - 2023-07-01 16:16:27 --> Model Class Initialized
DEBUG - 2023-07-01 16:16:27 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-01 16:16:27 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2023-07-01 16:16:27 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-07-01 16:16:27 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-07-01 16:16:27 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-07-01 16:16:27 --> Model Class Initialized
INFO - 2023-07-01 16:16:27 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-07-01 16:16:27 --> Final output sent to browser
DEBUG - 2023-07-01 16:16:27 --> Total execution time: 0.0280
ERROR - 2023-07-01 16:16:31 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-01 16:16:31 --> Config Class Initialized
INFO - 2023-07-01 16:16:31 --> Hooks Class Initialized
DEBUG - 2023-07-01 16:16:31 --> UTF-8 Support Enabled
INFO - 2023-07-01 16:16:31 --> Utf8 Class Initialized
INFO - 2023-07-01 16:16:31 --> URI Class Initialized
INFO - 2023-07-01 16:16:31 --> Router Class Initialized
INFO - 2023-07-01 16:16:31 --> Output Class Initialized
INFO - 2023-07-01 16:16:31 --> Security Class Initialized
DEBUG - 2023-07-01 16:16:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-01 16:16:31 --> Input Class Initialized
INFO - 2023-07-01 16:16:31 --> Language Class Initialized
INFO - 2023-07-01 16:16:31 --> Loader Class Initialized
INFO - 2023-07-01 16:16:31 --> Helper loaded: url_helper
INFO - 2023-07-01 16:16:31 --> Helper loaded: file_helper
INFO - 2023-07-01 16:16:31 --> Helper loaded: html_helper
INFO - 2023-07-01 16:16:31 --> Helper loaded: text_helper
INFO - 2023-07-01 16:16:31 --> Helper loaded: form_helper
INFO - 2023-07-01 16:16:31 --> Helper loaded: lang_helper
INFO - 2023-07-01 16:16:31 --> Helper loaded: security_helper
INFO - 2023-07-01 16:16:31 --> Helper loaded: cookie_helper
INFO - 2023-07-01 16:16:31 --> Database Driver Class Initialized
INFO - 2023-07-01 16:16:31 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-01 16:16:31 --> Parser Class Initialized
INFO - 2023-07-01 16:16:31 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-01 16:16:31 --> Pagination Class Initialized
INFO - 2023-07-01 16:16:31 --> Form Validation Class Initialized
INFO - 2023-07-01 16:16:31 --> Controller Class Initialized
INFO - 2023-07-01 16:16:31 --> Model Class Initialized
DEBUG - 2023-07-01 16:16:31 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-01 16:16:31 --> Model Class Initialized
INFO - 2023-07-01 16:16:31 --> Final output sent to browser
DEBUG - 2023-07-01 16:16:31 --> Total execution time: 0.0213
ERROR - 2023-07-01 16:16:31 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-01 16:16:31 --> Config Class Initialized
INFO - 2023-07-01 16:16:31 --> Hooks Class Initialized
DEBUG - 2023-07-01 16:16:31 --> UTF-8 Support Enabled
INFO - 2023-07-01 16:16:31 --> Utf8 Class Initialized
INFO - 2023-07-01 16:16:31 --> URI Class Initialized
DEBUG - 2023-07-01 16:16:31 --> No URI present. Default controller set.
INFO - 2023-07-01 16:16:31 --> Router Class Initialized
INFO - 2023-07-01 16:16:31 --> Output Class Initialized
INFO - 2023-07-01 16:16:31 --> Security Class Initialized
DEBUG - 2023-07-01 16:16:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-01 16:16:31 --> Input Class Initialized
INFO - 2023-07-01 16:16:31 --> Language Class Initialized
INFO - 2023-07-01 16:16:31 --> Loader Class Initialized
INFO - 2023-07-01 16:16:31 --> Helper loaded: url_helper
INFO - 2023-07-01 16:16:31 --> Helper loaded: file_helper
INFO - 2023-07-01 16:16:31 --> Helper loaded: html_helper
INFO - 2023-07-01 16:16:31 --> Helper loaded: text_helper
INFO - 2023-07-01 16:16:31 --> Helper loaded: form_helper
INFO - 2023-07-01 16:16:31 --> Helper loaded: lang_helper
INFO - 2023-07-01 16:16:31 --> Helper loaded: security_helper
INFO - 2023-07-01 16:16:31 --> Helper loaded: cookie_helper
INFO - 2023-07-01 16:16:31 --> Database Driver Class Initialized
INFO - 2023-07-01 16:16:31 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-01 16:16:31 --> Parser Class Initialized
INFO - 2023-07-01 16:16:31 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-01 16:16:31 --> Pagination Class Initialized
INFO - 2023-07-01 16:16:31 --> Form Validation Class Initialized
INFO - 2023-07-01 16:16:31 --> Controller Class Initialized
INFO - 2023-07-01 16:16:31 --> Model Class Initialized
DEBUG - 2023-07-01 16:16:31 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-01 16:16:31 --> Model Class Initialized
DEBUG - 2023-07-01 16:16:31 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-01 16:16:31 --> Model Class Initialized
INFO - 2023-07-01 16:16:31 --> Model Class Initialized
INFO - 2023-07-01 16:16:31 --> Model Class Initialized
INFO - 2023-07-01 16:16:31 --> Model Class Initialized
DEBUG - 2023-07-01 16:16:31 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-01 16:16:31 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-01 16:16:31 --> Model Class Initialized
INFO - 2023-07-01 16:16:31 --> Model Class Initialized
INFO - 2023-07-01 16:16:31 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-07-01 16:16:31 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-07-01 16:16:31 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-07-01 16:16:31 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-07-01 16:16:31 --> Model Class Initialized
INFO - 2023-07-01 16:16:31 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-07-01 16:16:31 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-07-01 16:16:31 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-07-01 16:16:31 --> Final output sent to browser
DEBUG - 2023-07-01 16:16:31 --> Total execution time: 0.0829
ERROR - 2023-07-01 16:16:46 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-01 16:16:46 --> Config Class Initialized
INFO - 2023-07-01 16:16:46 --> Hooks Class Initialized
DEBUG - 2023-07-01 16:16:46 --> UTF-8 Support Enabled
INFO - 2023-07-01 16:16:46 --> Utf8 Class Initialized
INFO - 2023-07-01 16:16:46 --> URI Class Initialized
INFO - 2023-07-01 16:16:46 --> Router Class Initialized
INFO - 2023-07-01 16:16:46 --> Output Class Initialized
INFO - 2023-07-01 16:16:46 --> Security Class Initialized
DEBUG - 2023-07-01 16:16:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-01 16:16:46 --> Input Class Initialized
INFO - 2023-07-01 16:16:46 --> Language Class Initialized
INFO - 2023-07-01 16:16:46 --> Loader Class Initialized
INFO - 2023-07-01 16:16:46 --> Helper loaded: url_helper
INFO - 2023-07-01 16:16:46 --> Helper loaded: file_helper
INFO - 2023-07-01 16:16:46 --> Helper loaded: html_helper
INFO - 2023-07-01 16:16:46 --> Helper loaded: text_helper
INFO - 2023-07-01 16:16:46 --> Helper loaded: form_helper
INFO - 2023-07-01 16:16:46 --> Helper loaded: lang_helper
INFO - 2023-07-01 16:16:46 --> Helper loaded: security_helper
INFO - 2023-07-01 16:16:46 --> Helper loaded: cookie_helper
INFO - 2023-07-01 16:16:46 --> Database Driver Class Initialized
INFO - 2023-07-01 16:16:46 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-01 16:16:46 --> Parser Class Initialized
INFO - 2023-07-01 16:16:46 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-01 16:16:46 --> Pagination Class Initialized
INFO - 2023-07-01 16:16:46 --> Form Validation Class Initialized
INFO - 2023-07-01 16:16:46 --> Controller Class Initialized
INFO - 2023-07-01 16:16:46 --> Model Class Initialized
DEBUG - 2023-07-01 16:16:46 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-01 16:16:46 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-01 16:16:46 --> Model Class Initialized
DEBUG - 2023-07-01 16:16:46 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-01 16:16:46 --> Model Class Initialized
INFO - 2023-07-01 16:16:46 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/invoice/invoice.php
DEBUG - 2023-07-01 16:16:46 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-07-01 16:16:46 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-07-01 16:16:46 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-07-01 16:16:46 --> Model Class Initialized
INFO - 2023-07-01 16:16:46 --> Model Class Initialized
INFO - 2023-07-01 16:16:46 --> Model Class Initialized
INFO - 2023-07-01 16:16:46 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-07-01 16:16:46 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-07-01 16:16:46 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-07-01 16:16:46 --> Final output sent to browser
DEBUG - 2023-07-01 16:16:46 --> Total execution time: 0.0798
ERROR - 2023-07-01 16:16:46 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-01 16:16:46 --> Config Class Initialized
INFO - 2023-07-01 16:16:46 --> Hooks Class Initialized
DEBUG - 2023-07-01 16:16:46 --> UTF-8 Support Enabled
INFO - 2023-07-01 16:16:46 --> Utf8 Class Initialized
INFO - 2023-07-01 16:16:46 --> URI Class Initialized
INFO - 2023-07-01 16:16:46 --> Router Class Initialized
INFO - 2023-07-01 16:16:46 --> Output Class Initialized
INFO - 2023-07-01 16:16:46 --> Security Class Initialized
DEBUG - 2023-07-01 16:16:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-01 16:16:46 --> Input Class Initialized
INFO - 2023-07-01 16:16:46 --> Language Class Initialized
INFO - 2023-07-01 16:16:46 --> Loader Class Initialized
INFO - 2023-07-01 16:16:46 --> Helper loaded: url_helper
INFO - 2023-07-01 16:16:46 --> Helper loaded: file_helper
INFO - 2023-07-01 16:16:46 --> Helper loaded: html_helper
INFO - 2023-07-01 16:16:46 --> Helper loaded: text_helper
INFO - 2023-07-01 16:16:46 --> Helper loaded: form_helper
INFO - 2023-07-01 16:16:46 --> Helper loaded: lang_helper
INFO - 2023-07-01 16:16:46 --> Helper loaded: security_helper
INFO - 2023-07-01 16:16:46 --> Helper loaded: cookie_helper
INFO - 2023-07-01 16:16:46 --> Database Driver Class Initialized
INFO - 2023-07-01 16:16:46 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-01 16:16:46 --> Parser Class Initialized
INFO - 2023-07-01 16:16:46 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-01 16:16:46 --> Pagination Class Initialized
INFO - 2023-07-01 16:16:46 --> Form Validation Class Initialized
INFO - 2023-07-01 16:16:46 --> Controller Class Initialized
INFO - 2023-07-01 16:16:46 --> Model Class Initialized
DEBUG - 2023-07-01 16:16:46 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-01 16:16:46 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-01 16:16:46 --> Model Class Initialized
DEBUG - 2023-07-01 16:16:46 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-01 16:16:46 --> Model Class Initialized
INFO - 2023-07-01 16:16:46 --> Final output sent to browser
DEBUG - 2023-07-01 16:16:46 --> Total execution time: 0.0496
ERROR - 2023-07-01 16:24:13 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-01 16:24:13 --> Config Class Initialized
INFO - 2023-07-01 16:24:13 --> Hooks Class Initialized
DEBUG - 2023-07-01 16:24:13 --> UTF-8 Support Enabled
INFO - 2023-07-01 16:24:13 --> Utf8 Class Initialized
INFO - 2023-07-01 16:24:13 --> URI Class Initialized
INFO - 2023-07-01 16:24:13 --> Router Class Initialized
INFO - 2023-07-01 16:24:13 --> Output Class Initialized
INFO - 2023-07-01 16:24:13 --> Security Class Initialized
DEBUG - 2023-07-01 16:24:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-01 16:24:13 --> Input Class Initialized
INFO - 2023-07-01 16:24:13 --> Language Class Initialized
INFO - 2023-07-01 16:24:13 --> Loader Class Initialized
INFO - 2023-07-01 16:24:13 --> Helper loaded: url_helper
INFO - 2023-07-01 16:24:13 --> Helper loaded: file_helper
INFO - 2023-07-01 16:24:13 --> Helper loaded: html_helper
INFO - 2023-07-01 16:24:13 --> Helper loaded: text_helper
INFO - 2023-07-01 16:24:13 --> Helper loaded: form_helper
INFO - 2023-07-01 16:24:13 --> Helper loaded: lang_helper
INFO - 2023-07-01 16:24:13 --> Helper loaded: security_helper
INFO - 2023-07-01 16:24:13 --> Helper loaded: cookie_helper
INFO - 2023-07-01 16:24:13 --> Database Driver Class Initialized
INFO - 2023-07-01 16:24:13 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-01 16:24:13 --> Parser Class Initialized
INFO - 2023-07-01 16:24:13 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-01 16:24:13 --> Pagination Class Initialized
INFO - 2023-07-01 16:24:13 --> Form Validation Class Initialized
INFO - 2023-07-01 16:24:13 --> Controller Class Initialized
INFO - 2023-07-01 16:24:13 --> Model Class Initialized
DEBUG - 2023-07-01 16:24:13 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-01 16:24:13 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-01 16:24:13 --> Model Class Initialized
DEBUG - 2023-07-01 16:24:13 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-01 16:24:13 --> Model Class Initialized
INFO - 2023-07-01 16:24:13 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/invoice/invoice.php
DEBUG - 2023-07-01 16:24:13 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-07-01 16:24:13 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-07-01 16:24:13 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-07-01 16:24:13 --> Model Class Initialized
INFO - 2023-07-01 16:24:13 --> Model Class Initialized
INFO - 2023-07-01 16:24:13 --> Model Class Initialized
INFO - 2023-07-01 16:24:13 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-07-01 16:24:13 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-07-01 16:24:13 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-07-01 16:24:13 --> Final output sent to browser
DEBUG - 2023-07-01 16:24:13 --> Total execution time: 0.0747
ERROR - 2023-07-01 16:24:14 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-01 16:24:14 --> Config Class Initialized
INFO - 2023-07-01 16:24:14 --> Hooks Class Initialized
DEBUG - 2023-07-01 16:24:14 --> UTF-8 Support Enabled
INFO - 2023-07-01 16:24:14 --> Utf8 Class Initialized
INFO - 2023-07-01 16:24:14 --> URI Class Initialized
INFO - 2023-07-01 16:24:14 --> Router Class Initialized
INFO - 2023-07-01 16:24:14 --> Output Class Initialized
INFO - 2023-07-01 16:24:14 --> Security Class Initialized
DEBUG - 2023-07-01 16:24:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-01 16:24:14 --> Input Class Initialized
INFO - 2023-07-01 16:24:14 --> Language Class Initialized
INFO - 2023-07-01 16:24:14 --> Loader Class Initialized
INFO - 2023-07-01 16:24:14 --> Helper loaded: url_helper
INFO - 2023-07-01 16:24:14 --> Helper loaded: file_helper
INFO - 2023-07-01 16:24:14 --> Helper loaded: html_helper
INFO - 2023-07-01 16:24:14 --> Helper loaded: text_helper
INFO - 2023-07-01 16:24:14 --> Helper loaded: form_helper
INFO - 2023-07-01 16:24:14 --> Helper loaded: lang_helper
INFO - 2023-07-01 16:24:14 --> Helper loaded: security_helper
INFO - 2023-07-01 16:24:14 --> Helper loaded: cookie_helper
INFO - 2023-07-01 16:24:14 --> Database Driver Class Initialized
INFO - 2023-07-01 16:24:14 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-01 16:24:14 --> Parser Class Initialized
INFO - 2023-07-01 16:24:14 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-01 16:24:14 --> Pagination Class Initialized
INFO - 2023-07-01 16:24:14 --> Form Validation Class Initialized
INFO - 2023-07-01 16:24:14 --> Controller Class Initialized
INFO - 2023-07-01 16:24:14 --> Model Class Initialized
DEBUG - 2023-07-01 16:24:14 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-01 16:24:14 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-01 16:24:14 --> Model Class Initialized
DEBUG - 2023-07-01 16:24:14 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-01 16:24:14 --> Model Class Initialized
INFO - 2023-07-01 16:24:14 --> Final output sent to browser
DEBUG - 2023-07-01 16:24:14 --> Total execution time: 0.0525
ERROR - 2023-07-01 16:28:31 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-01 16:28:31 --> Config Class Initialized
INFO - 2023-07-01 16:28:31 --> Hooks Class Initialized
DEBUG - 2023-07-01 16:28:31 --> UTF-8 Support Enabled
INFO - 2023-07-01 16:28:31 --> Utf8 Class Initialized
INFO - 2023-07-01 16:28:31 --> URI Class Initialized
INFO - 2023-07-01 16:28:31 --> Router Class Initialized
INFO - 2023-07-01 16:28:31 --> Output Class Initialized
INFO - 2023-07-01 16:28:31 --> Security Class Initialized
DEBUG - 2023-07-01 16:28:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-01 16:28:31 --> Input Class Initialized
INFO - 2023-07-01 16:28:31 --> Language Class Initialized
INFO - 2023-07-01 16:28:31 --> Loader Class Initialized
INFO - 2023-07-01 16:28:31 --> Helper loaded: url_helper
INFO - 2023-07-01 16:28:31 --> Helper loaded: file_helper
INFO - 2023-07-01 16:28:31 --> Helper loaded: html_helper
INFO - 2023-07-01 16:28:31 --> Helper loaded: text_helper
INFO - 2023-07-01 16:28:31 --> Helper loaded: form_helper
INFO - 2023-07-01 16:28:31 --> Helper loaded: lang_helper
INFO - 2023-07-01 16:28:31 --> Helper loaded: security_helper
INFO - 2023-07-01 16:28:31 --> Helper loaded: cookie_helper
INFO - 2023-07-01 16:28:31 --> Database Driver Class Initialized
INFO - 2023-07-01 16:28:31 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-01 16:28:31 --> Parser Class Initialized
INFO - 2023-07-01 16:28:31 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-01 16:28:31 --> Pagination Class Initialized
INFO - 2023-07-01 16:28:31 --> Form Validation Class Initialized
INFO - 2023-07-01 16:28:31 --> Controller Class Initialized
INFO - 2023-07-01 16:28:31 --> Model Class Initialized
DEBUG - 2023-07-01 16:28:31 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-01 16:28:31 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-01 16:28:31 --> Model Class Initialized
DEBUG - 2023-07-01 16:28:31 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-01 16:28:31 --> Model Class Initialized
INFO - 2023-07-01 16:28:31 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/add_invoice_form.php
DEBUG - 2023-07-01 16:28:31 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-07-01 16:28:31 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-07-01 16:28:31 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-07-01 16:28:31 --> Model Class Initialized
INFO - 2023-07-01 16:28:31 --> Model Class Initialized
INFO - 2023-07-01 16:28:31 --> Model Class Initialized
INFO - 2023-07-01 16:28:32 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-07-01 16:28:32 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-07-01 16:28:32 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-07-01 16:28:32 --> Final output sent to browser
DEBUG - 2023-07-01 16:28:32 --> Total execution time: 0.1102
ERROR - 2023-07-01 16:33:41 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-01 16:33:41 --> Config Class Initialized
INFO - 2023-07-01 16:33:41 --> Hooks Class Initialized
DEBUG - 2023-07-01 16:33:41 --> UTF-8 Support Enabled
INFO - 2023-07-01 16:33:41 --> Utf8 Class Initialized
INFO - 2023-07-01 16:33:41 --> URI Class Initialized
INFO - 2023-07-01 16:33:41 --> Router Class Initialized
INFO - 2023-07-01 16:33:41 --> Output Class Initialized
INFO - 2023-07-01 16:33:41 --> Security Class Initialized
DEBUG - 2023-07-01 16:33:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-01 16:33:41 --> Input Class Initialized
INFO - 2023-07-01 16:33:41 --> Language Class Initialized
INFO - 2023-07-01 16:33:41 --> Loader Class Initialized
INFO - 2023-07-01 16:33:41 --> Helper loaded: url_helper
INFO - 2023-07-01 16:33:41 --> Helper loaded: file_helper
INFO - 2023-07-01 16:33:41 --> Helper loaded: html_helper
INFO - 2023-07-01 16:33:41 --> Helper loaded: text_helper
INFO - 2023-07-01 16:33:41 --> Helper loaded: form_helper
INFO - 2023-07-01 16:33:41 --> Helper loaded: lang_helper
INFO - 2023-07-01 16:33:41 --> Helper loaded: security_helper
INFO - 2023-07-01 16:33:41 --> Helper loaded: cookie_helper
INFO - 2023-07-01 16:33:41 --> Database Driver Class Initialized
INFO - 2023-07-01 16:33:41 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-01 16:33:41 --> Parser Class Initialized
INFO - 2023-07-01 16:33:41 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-01 16:33:41 --> Pagination Class Initialized
INFO - 2023-07-01 16:33:41 --> Form Validation Class Initialized
INFO - 2023-07-01 16:33:41 --> Controller Class Initialized
INFO - 2023-07-01 16:33:41 --> Model Class Initialized
DEBUG - 2023-07-01 16:33:41 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-01 16:33:41 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-01 16:33:41 --> Model Class Initialized
DEBUG - 2023-07-01 16:33:41 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-01 16:33:41 --> Model Class Initialized
INFO - 2023-07-01 16:33:41 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice.php
DEBUG - 2023-07-01 16:33:41 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-07-01 16:33:41 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-07-01 16:33:41 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-07-01 16:33:41 --> Model Class Initialized
INFO - 2023-07-01 16:33:41 --> Model Class Initialized
INFO - 2023-07-01 16:33:41 --> Model Class Initialized
INFO - 2023-07-01 16:33:41 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-07-01 16:33:41 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-07-01 16:33:41 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-07-01 16:33:41 --> Final output sent to browser
DEBUG - 2023-07-01 16:33:41 --> Total execution time: 0.0748
ERROR - 2023-07-01 16:33:42 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-01 16:33:42 --> Config Class Initialized
INFO - 2023-07-01 16:33:42 --> Hooks Class Initialized
DEBUG - 2023-07-01 16:33:42 --> UTF-8 Support Enabled
INFO - 2023-07-01 16:33:42 --> Utf8 Class Initialized
INFO - 2023-07-01 16:33:42 --> URI Class Initialized
INFO - 2023-07-01 16:33:42 --> Router Class Initialized
INFO - 2023-07-01 16:33:42 --> Output Class Initialized
INFO - 2023-07-01 16:33:42 --> Security Class Initialized
DEBUG - 2023-07-01 16:33:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-01 16:33:42 --> Input Class Initialized
INFO - 2023-07-01 16:33:42 --> Language Class Initialized
INFO - 2023-07-01 16:33:42 --> Loader Class Initialized
INFO - 2023-07-01 16:33:42 --> Helper loaded: url_helper
INFO - 2023-07-01 16:33:42 --> Helper loaded: file_helper
INFO - 2023-07-01 16:33:42 --> Helper loaded: html_helper
INFO - 2023-07-01 16:33:42 --> Helper loaded: text_helper
INFO - 2023-07-01 16:33:42 --> Helper loaded: form_helper
INFO - 2023-07-01 16:33:42 --> Helper loaded: lang_helper
INFO - 2023-07-01 16:33:42 --> Helper loaded: security_helper
INFO - 2023-07-01 16:33:42 --> Helper loaded: cookie_helper
INFO - 2023-07-01 16:33:42 --> Database Driver Class Initialized
INFO - 2023-07-01 16:33:42 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-01 16:33:42 --> Parser Class Initialized
INFO - 2023-07-01 16:33:42 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-01 16:33:42 --> Pagination Class Initialized
INFO - 2023-07-01 16:33:42 --> Form Validation Class Initialized
INFO - 2023-07-01 16:33:42 --> Controller Class Initialized
INFO - 2023-07-01 16:33:42 --> Model Class Initialized
DEBUG - 2023-07-01 16:33:42 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-01 16:33:42 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-01 16:33:42 --> Model Class Initialized
DEBUG - 2023-07-01 16:33:42 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-01 16:33:42 --> Model Class Initialized
INFO - 2023-07-01 16:33:42 --> Final output sent to browser
DEBUG - 2023-07-01 16:33:42 --> Total execution time: 0.0426
ERROR - 2023-07-01 16:34:08 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-01 16:34:08 --> Config Class Initialized
INFO - 2023-07-01 16:34:08 --> Hooks Class Initialized
DEBUG - 2023-07-01 16:34:08 --> UTF-8 Support Enabled
INFO - 2023-07-01 16:34:08 --> Utf8 Class Initialized
INFO - 2023-07-01 16:34:08 --> URI Class Initialized
INFO - 2023-07-01 16:34:08 --> Router Class Initialized
INFO - 2023-07-01 16:34:08 --> Output Class Initialized
INFO - 2023-07-01 16:34:08 --> Security Class Initialized
DEBUG - 2023-07-01 16:34:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-01 16:34:08 --> Input Class Initialized
INFO - 2023-07-01 16:34:08 --> Language Class Initialized
INFO - 2023-07-01 16:34:08 --> Loader Class Initialized
INFO - 2023-07-01 16:34:08 --> Helper loaded: url_helper
INFO - 2023-07-01 16:34:08 --> Helper loaded: file_helper
INFO - 2023-07-01 16:34:08 --> Helper loaded: html_helper
INFO - 2023-07-01 16:34:08 --> Helper loaded: text_helper
INFO - 2023-07-01 16:34:08 --> Helper loaded: form_helper
INFO - 2023-07-01 16:34:08 --> Helper loaded: lang_helper
INFO - 2023-07-01 16:34:08 --> Helper loaded: security_helper
INFO - 2023-07-01 16:34:08 --> Helper loaded: cookie_helper
INFO - 2023-07-01 16:34:08 --> Database Driver Class Initialized
INFO - 2023-07-01 16:34:08 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-01 16:34:08 --> Parser Class Initialized
INFO - 2023-07-01 16:34:08 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-01 16:34:08 --> Pagination Class Initialized
INFO - 2023-07-01 16:34:08 --> Form Validation Class Initialized
INFO - 2023-07-01 16:34:08 --> Controller Class Initialized
INFO - 2023-07-01 16:34:08 --> Model Class Initialized
DEBUG - 2023-07-01 16:34:08 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-01 16:34:08 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-01 16:34:08 --> Model Class Initialized
INFO - 2023-07-01 16:34:08 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/stockrequest/stockrequest.php
DEBUG - 2023-07-01 16:34:08 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-07-01 16:34:08 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-07-01 16:34:08 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-07-01 16:34:08 --> Model Class Initialized
INFO - 2023-07-01 16:34:08 --> Model Class Initialized
INFO - 2023-07-01 16:34:08 --> Model Class Initialized
INFO - 2023-07-01 16:34:08 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-07-01 16:34:08 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-07-01 16:34:08 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-07-01 16:34:08 --> Final output sent to browser
DEBUG - 2023-07-01 16:34:08 --> Total execution time: 0.0678
ERROR - 2023-07-01 16:34:09 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-01 16:34:09 --> Config Class Initialized
INFO - 2023-07-01 16:34:09 --> Hooks Class Initialized
DEBUG - 2023-07-01 16:34:09 --> UTF-8 Support Enabled
INFO - 2023-07-01 16:34:09 --> Utf8 Class Initialized
INFO - 2023-07-01 16:34:09 --> URI Class Initialized
INFO - 2023-07-01 16:34:09 --> Router Class Initialized
INFO - 2023-07-01 16:34:09 --> Output Class Initialized
INFO - 2023-07-01 16:34:09 --> Security Class Initialized
DEBUG - 2023-07-01 16:34:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-01 16:34:09 --> Input Class Initialized
INFO - 2023-07-01 16:34:09 --> Language Class Initialized
INFO - 2023-07-01 16:34:09 --> Loader Class Initialized
INFO - 2023-07-01 16:34:09 --> Helper loaded: url_helper
INFO - 2023-07-01 16:34:09 --> Helper loaded: file_helper
INFO - 2023-07-01 16:34:09 --> Helper loaded: html_helper
INFO - 2023-07-01 16:34:09 --> Helper loaded: text_helper
INFO - 2023-07-01 16:34:09 --> Helper loaded: form_helper
INFO - 2023-07-01 16:34:09 --> Helper loaded: lang_helper
INFO - 2023-07-01 16:34:09 --> Helper loaded: security_helper
INFO - 2023-07-01 16:34:09 --> Helper loaded: cookie_helper
INFO - 2023-07-01 16:34:09 --> Database Driver Class Initialized
INFO - 2023-07-01 16:34:09 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-01 16:34:09 --> Parser Class Initialized
INFO - 2023-07-01 16:34:09 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-01 16:34:09 --> Pagination Class Initialized
INFO - 2023-07-01 16:34:09 --> Form Validation Class Initialized
INFO - 2023-07-01 16:34:09 --> Controller Class Initialized
INFO - 2023-07-01 16:34:09 --> Model Class Initialized
DEBUG - 2023-07-01 16:34:09 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-01 16:34:09 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-01 16:34:09 --> Model Class Initialized
INFO - 2023-07-01 16:34:09 --> Final output sent to browser
DEBUG - 2023-07-01 16:34:09 --> Total execution time: 0.0266
ERROR - 2023-07-01 16:34:15 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-01 16:34:15 --> Config Class Initialized
INFO - 2023-07-01 16:34:15 --> Hooks Class Initialized
DEBUG - 2023-07-01 16:34:15 --> UTF-8 Support Enabled
INFO - 2023-07-01 16:34:15 --> Utf8 Class Initialized
INFO - 2023-07-01 16:34:15 --> URI Class Initialized
INFO - 2023-07-01 16:34:15 --> Router Class Initialized
INFO - 2023-07-01 16:34:15 --> Output Class Initialized
INFO - 2023-07-01 16:34:15 --> Security Class Initialized
DEBUG - 2023-07-01 16:34:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-01 16:34:15 --> Input Class Initialized
INFO - 2023-07-01 16:34:15 --> Language Class Initialized
INFO - 2023-07-01 16:34:15 --> Loader Class Initialized
INFO - 2023-07-01 16:34:15 --> Helper loaded: url_helper
INFO - 2023-07-01 16:34:15 --> Helper loaded: file_helper
INFO - 2023-07-01 16:34:15 --> Helper loaded: html_helper
INFO - 2023-07-01 16:34:15 --> Helper loaded: text_helper
INFO - 2023-07-01 16:34:15 --> Helper loaded: form_helper
INFO - 2023-07-01 16:34:15 --> Helper loaded: lang_helper
INFO - 2023-07-01 16:34:15 --> Helper loaded: security_helper
INFO - 2023-07-01 16:34:15 --> Helper loaded: cookie_helper
INFO - 2023-07-01 16:34:15 --> Database Driver Class Initialized
INFO - 2023-07-01 16:34:15 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-01 16:34:15 --> Parser Class Initialized
INFO - 2023-07-01 16:34:15 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-01 16:34:15 --> Pagination Class Initialized
INFO - 2023-07-01 16:34:15 --> Form Validation Class Initialized
INFO - 2023-07-01 16:34:15 --> Controller Class Initialized
INFO - 2023-07-01 16:34:15 --> Model Class Initialized
DEBUG - 2023-07-01 16:34:15 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-01 16:34:15 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-01 16:34:15 --> Model Class Initialized
INFO - 2023-07-01 16:34:15 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/stockrequest/inventory.php
DEBUG - 2023-07-01 16:34:15 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-07-01 16:34:15 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-07-01 16:34:15 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-07-01 16:34:15 --> Model Class Initialized
INFO - 2023-07-01 16:34:15 --> Model Class Initialized
INFO - 2023-07-01 16:34:15 --> Model Class Initialized
INFO - 2023-07-01 16:34:15 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-07-01 16:34:15 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-07-01 16:34:15 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-07-01 16:34:15 --> Final output sent to browser
DEBUG - 2023-07-01 16:34:15 --> Total execution time: 0.0634
ERROR - 2023-07-01 16:34:15 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-01 16:34:15 --> Config Class Initialized
INFO - 2023-07-01 16:34:15 --> Hooks Class Initialized
DEBUG - 2023-07-01 16:34:15 --> UTF-8 Support Enabled
INFO - 2023-07-01 16:34:15 --> Utf8 Class Initialized
INFO - 2023-07-01 16:34:15 --> URI Class Initialized
INFO - 2023-07-01 16:34:15 --> Router Class Initialized
INFO - 2023-07-01 16:34:15 --> Output Class Initialized
INFO - 2023-07-01 16:34:15 --> Security Class Initialized
DEBUG - 2023-07-01 16:34:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-01 16:34:15 --> Input Class Initialized
INFO - 2023-07-01 16:34:15 --> Language Class Initialized
INFO - 2023-07-01 16:34:15 --> Loader Class Initialized
INFO - 2023-07-01 16:34:15 --> Helper loaded: url_helper
INFO - 2023-07-01 16:34:15 --> Helper loaded: file_helper
INFO - 2023-07-01 16:34:15 --> Helper loaded: html_helper
INFO - 2023-07-01 16:34:15 --> Helper loaded: text_helper
INFO - 2023-07-01 16:34:15 --> Helper loaded: form_helper
INFO - 2023-07-01 16:34:15 --> Helper loaded: lang_helper
INFO - 2023-07-01 16:34:15 --> Helper loaded: security_helper
INFO - 2023-07-01 16:34:15 --> Helper loaded: cookie_helper
INFO - 2023-07-01 16:34:15 --> Database Driver Class Initialized
INFO - 2023-07-01 16:34:15 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-01 16:34:15 --> Parser Class Initialized
INFO - 2023-07-01 16:34:15 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-01 16:34:15 --> Pagination Class Initialized
INFO - 2023-07-01 16:34:15 --> Form Validation Class Initialized
INFO - 2023-07-01 16:34:15 --> Controller Class Initialized
INFO - 2023-07-01 16:34:15 --> Model Class Initialized
DEBUG - 2023-07-01 16:34:15 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-01 16:34:15 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-01 16:34:15 --> Model Class Initialized
INFO - 2023-07-01 16:34:15 --> Final output sent to browser
DEBUG - 2023-07-01 16:34:15 --> Total execution time: 0.0263
ERROR - 2023-07-01 16:34:35 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-01 16:34:35 --> Config Class Initialized
INFO - 2023-07-01 16:34:35 --> Hooks Class Initialized
DEBUG - 2023-07-01 16:34:35 --> UTF-8 Support Enabled
INFO - 2023-07-01 16:34:35 --> Utf8 Class Initialized
INFO - 2023-07-01 16:34:35 --> URI Class Initialized
INFO - 2023-07-01 16:34:35 --> Router Class Initialized
INFO - 2023-07-01 16:34:35 --> Output Class Initialized
INFO - 2023-07-01 16:34:35 --> Security Class Initialized
DEBUG - 2023-07-01 16:34:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-01 16:34:35 --> Input Class Initialized
INFO - 2023-07-01 16:34:35 --> Language Class Initialized
INFO - 2023-07-01 16:34:35 --> Loader Class Initialized
INFO - 2023-07-01 16:34:35 --> Helper loaded: url_helper
INFO - 2023-07-01 16:34:35 --> Helper loaded: file_helper
INFO - 2023-07-01 16:34:35 --> Helper loaded: html_helper
INFO - 2023-07-01 16:34:35 --> Helper loaded: text_helper
INFO - 2023-07-01 16:34:35 --> Helper loaded: form_helper
INFO - 2023-07-01 16:34:35 --> Helper loaded: lang_helper
INFO - 2023-07-01 16:34:35 --> Helper loaded: security_helper
INFO - 2023-07-01 16:34:35 --> Helper loaded: cookie_helper
INFO - 2023-07-01 16:34:35 --> Database Driver Class Initialized
INFO - 2023-07-01 16:34:35 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-01 16:34:35 --> Parser Class Initialized
INFO - 2023-07-01 16:34:35 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-01 16:34:35 --> Pagination Class Initialized
INFO - 2023-07-01 16:34:35 --> Form Validation Class Initialized
INFO - 2023-07-01 16:34:35 --> Controller Class Initialized
INFO - 2023-07-01 16:34:35 --> Model Class Initialized
DEBUG - 2023-07-01 16:34:35 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-01 16:34:35 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-01 16:34:35 --> Model Class Initialized
INFO - 2023-07-01 16:34:35 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/stockrequest/inventory.php
DEBUG - 2023-07-01 16:34:35 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-07-01 16:34:35 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-07-01 16:34:35 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-07-01 16:34:35 --> Model Class Initialized
INFO - 2023-07-01 16:34:35 --> Model Class Initialized
INFO - 2023-07-01 16:34:35 --> Model Class Initialized
INFO - 2023-07-01 16:34:35 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-07-01 16:34:35 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-07-01 16:34:35 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-07-01 16:34:35 --> Final output sent to browser
DEBUG - 2023-07-01 16:34:35 --> Total execution time: 0.0640
ERROR - 2023-07-01 16:34:35 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-01 16:34:35 --> Config Class Initialized
INFO - 2023-07-01 16:34:35 --> Hooks Class Initialized
DEBUG - 2023-07-01 16:34:35 --> UTF-8 Support Enabled
INFO - 2023-07-01 16:34:35 --> Utf8 Class Initialized
INFO - 2023-07-01 16:34:35 --> URI Class Initialized
INFO - 2023-07-01 16:34:35 --> Router Class Initialized
INFO - 2023-07-01 16:34:35 --> Output Class Initialized
INFO - 2023-07-01 16:34:35 --> Security Class Initialized
DEBUG - 2023-07-01 16:34:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-01 16:34:35 --> Input Class Initialized
INFO - 2023-07-01 16:34:35 --> Language Class Initialized
INFO - 2023-07-01 16:34:35 --> Loader Class Initialized
INFO - 2023-07-01 16:34:35 --> Helper loaded: url_helper
INFO - 2023-07-01 16:34:35 --> Helper loaded: file_helper
INFO - 2023-07-01 16:34:35 --> Helper loaded: html_helper
INFO - 2023-07-01 16:34:35 --> Helper loaded: text_helper
INFO - 2023-07-01 16:34:35 --> Helper loaded: form_helper
INFO - 2023-07-01 16:34:35 --> Helper loaded: lang_helper
INFO - 2023-07-01 16:34:35 --> Helper loaded: security_helper
INFO - 2023-07-01 16:34:35 --> Helper loaded: cookie_helper
INFO - 2023-07-01 16:34:35 --> Database Driver Class Initialized
INFO - 2023-07-01 16:34:35 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-01 16:34:35 --> Parser Class Initialized
INFO - 2023-07-01 16:34:35 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-01 16:34:35 --> Pagination Class Initialized
INFO - 2023-07-01 16:34:35 --> Form Validation Class Initialized
INFO - 2023-07-01 16:34:35 --> Controller Class Initialized
INFO - 2023-07-01 16:34:35 --> Model Class Initialized
DEBUG - 2023-07-01 16:34:35 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-01 16:34:35 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-01 16:34:35 --> Model Class Initialized
INFO - 2023-07-01 16:34:35 --> Final output sent to browser
DEBUG - 2023-07-01 16:34:35 --> Total execution time: 0.0268
ERROR - 2023-07-01 16:34:42 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-01 16:34:42 --> Config Class Initialized
INFO - 2023-07-01 16:34:42 --> Hooks Class Initialized
DEBUG - 2023-07-01 16:34:42 --> UTF-8 Support Enabled
INFO - 2023-07-01 16:34:42 --> Utf8 Class Initialized
INFO - 2023-07-01 16:34:42 --> URI Class Initialized
INFO - 2023-07-01 16:34:42 --> Router Class Initialized
INFO - 2023-07-01 16:34:42 --> Output Class Initialized
INFO - 2023-07-01 16:34:42 --> Security Class Initialized
DEBUG - 2023-07-01 16:34:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-01 16:34:42 --> Input Class Initialized
INFO - 2023-07-01 16:34:42 --> Language Class Initialized
INFO - 2023-07-01 16:34:42 --> Loader Class Initialized
INFO - 2023-07-01 16:34:42 --> Helper loaded: url_helper
INFO - 2023-07-01 16:34:42 --> Helper loaded: file_helper
INFO - 2023-07-01 16:34:42 --> Helper loaded: html_helper
INFO - 2023-07-01 16:34:42 --> Helper loaded: text_helper
INFO - 2023-07-01 16:34:42 --> Helper loaded: form_helper
INFO - 2023-07-01 16:34:42 --> Helper loaded: lang_helper
INFO - 2023-07-01 16:34:42 --> Helper loaded: security_helper
INFO - 2023-07-01 16:34:42 --> Helper loaded: cookie_helper
INFO - 2023-07-01 16:34:42 --> Database Driver Class Initialized
INFO - 2023-07-01 16:34:42 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-01 16:34:42 --> Parser Class Initialized
INFO - 2023-07-01 16:34:42 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-01 16:34:42 --> Pagination Class Initialized
INFO - 2023-07-01 16:34:42 --> Form Validation Class Initialized
INFO - 2023-07-01 16:34:42 --> Controller Class Initialized
DEBUG - 2023-07-01 16:34:42 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-01 16:34:42 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-01 16:34:42 --> Model Class Initialized
DEBUG - 2023-07-01 16:34:42 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-01 16:34:42 --> Model Class Initialized
INFO - 2023-07-01 16:34:42 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/customer/add_customer_form.php
DEBUG - 2023-07-01 16:34:42 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-07-01 16:34:42 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-07-01 16:34:42 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-07-01 16:34:42 --> Model Class Initialized
INFO - 2023-07-01 16:34:42 --> Model Class Initialized
INFO - 2023-07-01 16:34:42 --> Model Class Initialized
INFO - 2023-07-01 16:34:42 --> Model Class Initialized
INFO - 2023-07-01 16:34:42 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-07-01 16:34:42 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-07-01 16:34:42 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-07-01 16:34:42 --> Final output sent to browser
DEBUG - 2023-07-01 16:34:42 --> Total execution time: 0.0975
ERROR - 2023-07-01 16:34:45 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-01 16:34:45 --> Config Class Initialized
INFO - 2023-07-01 16:34:45 --> Hooks Class Initialized
DEBUG - 2023-07-01 16:34:45 --> UTF-8 Support Enabled
INFO - 2023-07-01 16:34:45 --> Utf8 Class Initialized
INFO - 2023-07-01 16:34:45 --> URI Class Initialized
INFO - 2023-07-01 16:34:45 --> Router Class Initialized
INFO - 2023-07-01 16:34:45 --> Output Class Initialized
INFO - 2023-07-01 16:34:45 --> Security Class Initialized
DEBUG - 2023-07-01 16:34:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-01 16:34:45 --> Input Class Initialized
INFO - 2023-07-01 16:34:45 --> Language Class Initialized
INFO - 2023-07-01 16:34:45 --> Loader Class Initialized
INFO - 2023-07-01 16:34:45 --> Helper loaded: url_helper
INFO - 2023-07-01 16:34:45 --> Helper loaded: file_helper
INFO - 2023-07-01 16:34:45 --> Helper loaded: html_helper
INFO - 2023-07-01 16:34:45 --> Helper loaded: text_helper
INFO - 2023-07-01 16:34:45 --> Helper loaded: form_helper
INFO - 2023-07-01 16:34:45 --> Helper loaded: lang_helper
INFO - 2023-07-01 16:34:45 --> Helper loaded: security_helper
INFO - 2023-07-01 16:34:45 --> Helper loaded: cookie_helper
INFO - 2023-07-01 16:34:45 --> Database Driver Class Initialized
INFO - 2023-07-01 16:34:45 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-01 16:34:45 --> Parser Class Initialized
INFO - 2023-07-01 16:34:45 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-01 16:34:45 --> Pagination Class Initialized
INFO - 2023-07-01 16:34:45 --> Form Validation Class Initialized
INFO - 2023-07-01 16:34:45 --> Controller Class Initialized
DEBUG - 2023-07-01 16:34:45 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-01 16:34:45 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-01 16:34:45 --> Model Class Initialized
DEBUG - 2023-07-01 16:34:45 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-01 16:34:45 --> Model Class Initialized
DEBUG - 2023-07-01 16:34:45 --> Lcustomer class already loaded. Second attempt ignored.
INFO - 2023-07-01 16:34:45 --> Model Class Initialized
INFO - 2023-07-01 16:34:45 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/customer/customer.php
DEBUG - 2023-07-01 16:34:45 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-07-01 16:34:45 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-07-01 16:34:45 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-07-01 16:34:45 --> Model Class Initialized
INFO - 2023-07-01 16:34:45 --> Model Class Initialized
INFO - 2023-07-01 16:34:45 --> Model Class Initialized
INFO - 2023-07-01 16:34:45 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-07-01 16:34:45 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-07-01 16:34:45 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-07-01 16:34:45 --> Final output sent to browser
DEBUG - 2023-07-01 16:34:45 --> Total execution time: 0.0646
ERROR - 2023-07-01 16:34:45 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-01 16:34:45 --> Config Class Initialized
INFO - 2023-07-01 16:34:45 --> Hooks Class Initialized
DEBUG - 2023-07-01 16:34:45 --> UTF-8 Support Enabled
INFO - 2023-07-01 16:34:45 --> Utf8 Class Initialized
INFO - 2023-07-01 16:34:45 --> URI Class Initialized
INFO - 2023-07-01 16:34:45 --> Router Class Initialized
INFO - 2023-07-01 16:34:45 --> Output Class Initialized
INFO - 2023-07-01 16:34:45 --> Security Class Initialized
DEBUG - 2023-07-01 16:34:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-01 16:34:45 --> Input Class Initialized
INFO - 2023-07-01 16:34:45 --> Language Class Initialized
INFO - 2023-07-01 16:34:45 --> Loader Class Initialized
INFO - 2023-07-01 16:34:45 --> Helper loaded: url_helper
INFO - 2023-07-01 16:34:45 --> Helper loaded: file_helper
INFO - 2023-07-01 16:34:45 --> Helper loaded: html_helper
INFO - 2023-07-01 16:34:45 --> Helper loaded: text_helper
INFO - 2023-07-01 16:34:45 --> Helper loaded: form_helper
INFO - 2023-07-01 16:34:45 --> Helper loaded: lang_helper
INFO - 2023-07-01 16:34:45 --> Helper loaded: security_helper
INFO - 2023-07-01 16:34:45 --> Helper loaded: cookie_helper
INFO - 2023-07-01 16:34:45 --> Database Driver Class Initialized
INFO - 2023-07-01 16:34:45 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-01 16:34:45 --> Parser Class Initialized
INFO - 2023-07-01 16:34:45 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-01 16:34:45 --> Pagination Class Initialized
INFO - 2023-07-01 16:34:45 --> Form Validation Class Initialized
INFO - 2023-07-01 16:34:45 --> Controller Class Initialized
DEBUG - 2023-07-01 16:34:45 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-01 16:34:45 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-01 16:34:45 --> Model Class Initialized
DEBUG - 2023-07-01 16:34:45 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-01 16:34:45 --> Model Class Initialized
INFO - 2023-07-01 16:34:45 --> Final output sent to browser
DEBUG - 2023-07-01 16:34:45 --> Total execution time: 0.0209
ERROR - 2023-07-01 16:34:49 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-01 16:34:49 --> Config Class Initialized
INFO - 2023-07-01 16:34:49 --> Hooks Class Initialized
DEBUG - 2023-07-01 16:34:49 --> UTF-8 Support Enabled
INFO - 2023-07-01 16:34:49 --> Utf8 Class Initialized
INFO - 2023-07-01 16:34:49 --> URI Class Initialized
INFO - 2023-07-01 16:34:49 --> Router Class Initialized
INFO - 2023-07-01 16:34:49 --> Output Class Initialized
INFO - 2023-07-01 16:34:49 --> Security Class Initialized
DEBUG - 2023-07-01 16:34:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-01 16:34:49 --> Input Class Initialized
INFO - 2023-07-01 16:34:49 --> Language Class Initialized
INFO - 2023-07-01 16:34:49 --> Loader Class Initialized
INFO - 2023-07-01 16:34:49 --> Helper loaded: url_helper
INFO - 2023-07-01 16:34:49 --> Helper loaded: file_helper
INFO - 2023-07-01 16:34:49 --> Helper loaded: html_helper
INFO - 2023-07-01 16:34:49 --> Helper loaded: text_helper
INFO - 2023-07-01 16:34:49 --> Helper loaded: form_helper
INFO - 2023-07-01 16:34:49 --> Helper loaded: lang_helper
INFO - 2023-07-01 16:34:49 --> Helper loaded: security_helper
INFO - 2023-07-01 16:34:49 --> Helper loaded: cookie_helper
INFO - 2023-07-01 16:34:49 --> Database Driver Class Initialized
INFO - 2023-07-01 16:34:49 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-01 16:34:49 --> Parser Class Initialized
INFO - 2023-07-01 16:34:49 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-01 16:34:49 --> Pagination Class Initialized
INFO - 2023-07-01 16:34:49 --> Form Validation Class Initialized
INFO - 2023-07-01 16:34:49 --> Controller Class Initialized
DEBUG - 2023-07-01 16:34:49 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-01 16:34:49 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-01 16:34:49 --> Model Class Initialized
DEBUG - 2023-07-01 16:34:49 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-01 16:34:49 --> Model Class Initialized
INFO - 2023-07-01 16:34:49 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/customer/add_customer_form.php
DEBUG - 2023-07-01 16:34:49 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-07-01 16:34:49 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-07-01 16:34:49 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-07-01 16:34:49 --> Model Class Initialized
INFO - 2023-07-01 16:34:49 --> Model Class Initialized
INFO - 2023-07-01 16:34:49 --> Model Class Initialized
INFO - 2023-07-01 16:34:49 --> Model Class Initialized
INFO - 2023-07-01 16:34:49 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-07-01 16:34:49 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-07-01 16:34:49 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-07-01 16:34:49 --> Final output sent to browser
DEBUG - 2023-07-01 16:34:49 --> Total execution time: 0.1039
ERROR - 2023-07-01 16:35:14 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-01 16:35:14 --> Config Class Initialized
INFO - 2023-07-01 16:35:14 --> Hooks Class Initialized
DEBUG - 2023-07-01 16:35:14 --> UTF-8 Support Enabled
INFO - 2023-07-01 16:35:14 --> Utf8 Class Initialized
INFO - 2023-07-01 16:35:14 --> URI Class Initialized
INFO - 2023-07-01 16:35:14 --> Router Class Initialized
INFO - 2023-07-01 16:35:14 --> Output Class Initialized
INFO - 2023-07-01 16:35:14 --> Security Class Initialized
DEBUG - 2023-07-01 16:35:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-01 16:35:14 --> Input Class Initialized
INFO - 2023-07-01 16:35:14 --> Language Class Initialized
INFO - 2023-07-01 16:35:14 --> Loader Class Initialized
INFO - 2023-07-01 16:35:14 --> Helper loaded: url_helper
INFO - 2023-07-01 16:35:14 --> Helper loaded: file_helper
INFO - 2023-07-01 16:35:14 --> Helper loaded: html_helper
INFO - 2023-07-01 16:35:14 --> Helper loaded: text_helper
INFO - 2023-07-01 16:35:14 --> Helper loaded: form_helper
INFO - 2023-07-01 16:35:14 --> Helper loaded: lang_helper
INFO - 2023-07-01 16:35:14 --> Helper loaded: security_helper
INFO - 2023-07-01 16:35:14 --> Helper loaded: cookie_helper
INFO - 2023-07-01 16:35:14 --> Database Driver Class Initialized
INFO - 2023-07-01 16:35:14 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-01 16:35:14 --> Parser Class Initialized
INFO - 2023-07-01 16:35:14 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-01 16:35:14 --> Pagination Class Initialized
INFO - 2023-07-01 16:35:14 --> Form Validation Class Initialized
INFO - 2023-07-01 16:35:14 --> Controller Class Initialized
DEBUG - 2023-07-01 16:35:14 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-01 16:35:14 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-01 16:35:14 --> Model Class Initialized
DEBUG - 2023-07-01 16:35:14 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-01 16:35:14 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-07-01 16:35:14 --> Ltarget class already loaded. Second attempt ignored.
INFO - 2023-07-01 16:35:14 --> Model Class Initialized
DEBUG - 2023-07-01 16:35:14 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-01 16:35:14 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-01 16:35:14 --> Model Class Initialized
DEBUG - 2023-07-01 16:35:14 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-01 16:35:14 --> Model Class Initialized
INFO - 2023-07-01 16:35:14 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/target/target.php
DEBUG - 2023-07-01 16:35:14 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-07-01 16:35:14 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-07-01 16:35:14 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-07-01 16:35:14 --> Model Class Initialized
INFO - 2023-07-01 16:35:14 --> Model Class Initialized
INFO - 2023-07-01 16:35:14 --> Model Class Initialized
INFO - 2023-07-01 16:35:14 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-07-01 16:35:14 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-07-01 16:35:14 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-07-01 16:35:14 --> Final output sent to browser
DEBUG - 2023-07-01 16:35:14 --> Total execution time: 0.0700
ERROR - 2023-07-01 16:35:15 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-01 16:35:15 --> Config Class Initialized
INFO - 2023-07-01 16:35:15 --> Hooks Class Initialized
DEBUG - 2023-07-01 16:35:15 --> UTF-8 Support Enabled
INFO - 2023-07-01 16:35:15 --> Utf8 Class Initialized
INFO - 2023-07-01 16:35:15 --> URI Class Initialized
INFO - 2023-07-01 16:35:15 --> Router Class Initialized
INFO - 2023-07-01 16:35:15 --> Output Class Initialized
INFO - 2023-07-01 16:35:15 --> Security Class Initialized
DEBUG - 2023-07-01 16:35:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-01 16:35:15 --> Input Class Initialized
INFO - 2023-07-01 16:35:15 --> Language Class Initialized
INFO - 2023-07-01 16:35:15 --> Loader Class Initialized
INFO - 2023-07-01 16:35:15 --> Helper loaded: url_helper
INFO - 2023-07-01 16:35:15 --> Helper loaded: file_helper
INFO - 2023-07-01 16:35:15 --> Helper loaded: html_helper
INFO - 2023-07-01 16:35:15 --> Helper loaded: text_helper
INFO - 2023-07-01 16:35:15 --> Helper loaded: form_helper
INFO - 2023-07-01 16:35:15 --> Helper loaded: lang_helper
INFO - 2023-07-01 16:35:15 --> Helper loaded: security_helper
INFO - 2023-07-01 16:35:15 --> Helper loaded: cookie_helper
INFO - 2023-07-01 16:35:15 --> Database Driver Class Initialized
INFO - 2023-07-01 16:35:15 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-01 16:35:15 --> Parser Class Initialized
INFO - 2023-07-01 16:35:15 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-01 16:35:15 --> Pagination Class Initialized
INFO - 2023-07-01 16:35:15 --> Form Validation Class Initialized
INFO - 2023-07-01 16:35:15 --> Controller Class Initialized
DEBUG - 2023-07-01 16:35:15 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-01 16:35:15 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-01 16:35:15 --> Model Class Initialized
DEBUG - 2023-07-01 16:35:15 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-01 16:35:15 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-01 16:35:15 --> Model Class Initialized
DEBUG - 2023-07-01 16:35:15 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-01 16:35:15 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-01 16:35:15 --> Model Class Initialized
DEBUG - 2023-07-01 16:35:15 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-01 16:35:15 --> Model Class Initialized
INFO - 2023-07-01 16:35:15 --> Final output sent to browser
DEBUG - 2023-07-01 16:35:15 --> Total execution time: 0.0197
ERROR - 2023-07-01 16:35:24 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-01 16:35:24 --> Config Class Initialized
INFO - 2023-07-01 16:35:24 --> Hooks Class Initialized
DEBUG - 2023-07-01 16:35:24 --> UTF-8 Support Enabled
INFO - 2023-07-01 16:35:24 --> Utf8 Class Initialized
INFO - 2023-07-01 16:35:24 --> URI Class Initialized
INFO - 2023-07-01 16:35:24 --> Router Class Initialized
INFO - 2023-07-01 16:35:24 --> Output Class Initialized
INFO - 2023-07-01 16:35:24 --> Security Class Initialized
DEBUG - 2023-07-01 16:35:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-01 16:35:24 --> Input Class Initialized
INFO - 2023-07-01 16:35:24 --> Language Class Initialized
INFO - 2023-07-01 16:35:24 --> Loader Class Initialized
INFO - 2023-07-01 16:35:24 --> Helper loaded: url_helper
INFO - 2023-07-01 16:35:24 --> Helper loaded: file_helper
INFO - 2023-07-01 16:35:24 --> Helper loaded: html_helper
INFO - 2023-07-01 16:35:24 --> Helper loaded: text_helper
INFO - 2023-07-01 16:35:24 --> Helper loaded: form_helper
INFO - 2023-07-01 16:35:24 --> Helper loaded: lang_helper
INFO - 2023-07-01 16:35:24 --> Helper loaded: security_helper
INFO - 2023-07-01 16:35:24 --> Helper loaded: cookie_helper
INFO - 2023-07-01 16:35:24 --> Database Driver Class Initialized
INFO - 2023-07-01 16:35:24 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-01 16:35:24 --> Parser Class Initialized
INFO - 2023-07-01 16:35:24 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-01 16:35:24 --> Pagination Class Initialized
INFO - 2023-07-01 16:35:24 --> Form Validation Class Initialized
INFO - 2023-07-01 16:35:24 --> Controller Class Initialized
INFO - 2023-07-01 16:35:24 --> Model Class Initialized
DEBUG - 2023-07-01 16:35:24 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-01 16:35:24 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-01 16:35:24 --> Model Class Initialized
DEBUG - 2023-07-01 16:35:24 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-01 16:35:24 --> Model Class Initialized
INFO - 2023-07-01 16:35:24 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/invoice/invoice.php
DEBUG - 2023-07-01 16:35:24 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-07-01 16:35:24 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-07-01 16:35:24 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-07-01 16:35:24 --> Model Class Initialized
INFO - 2023-07-01 16:35:24 --> Model Class Initialized
INFO - 2023-07-01 16:35:24 --> Model Class Initialized
INFO - 2023-07-01 16:35:24 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-07-01 16:35:24 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-07-01 16:35:24 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-07-01 16:35:24 --> Final output sent to browser
DEBUG - 2023-07-01 16:35:24 --> Total execution time: 0.0677
ERROR - 2023-07-01 16:35:25 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-01 16:35:25 --> Config Class Initialized
INFO - 2023-07-01 16:35:25 --> Hooks Class Initialized
DEBUG - 2023-07-01 16:35:25 --> UTF-8 Support Enabled
INFO - 2023-07-01 16:35:25 --> Utf8 Class Initialized
INFO - 2023-07-01 16:35:25 --> URI Class Initialized
INFO - 2023-07-01 16:35:25 --> Router Class Initialized
INFO - 2023-07-01 16:35:25 --> Output Class Initialized
INFO - 2023-07-01 16:35:25 --> Security Class Initialized
DEBUG - 2023-07-01 16:35:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-01 16:35:25 --> Input Class Initialized
INFO - 2023-07-01 16:35:25 --> Language Class Initialized
INFO - 2023-07-01 16:35:25 --> Loader Class Initialized
INFO - 2023-07-01 16:35:25 --> Helper loaded: url_helper
INFO - 2023-07-01 16:35:25 --> Helper loaded: file_helper
INFO - 2023-07-01 16:35:25 --> Helper loaded: html_helper
INFO - 2023-07-01 16:35:25 --> Helper loaded: text_helper
INFO - 2023-07-01 16:35:25 --> Helper loaded: form_helper
INFO - 2023-07-01 16:35:25 --> Helper loaded: lang_helper
INFO - 2023-07-01 16:35:25 --> Helper loaded: security_helper
INFO - 2023-07-01 16:35:25 --> Helper loaded: cookie_helper
INFO - 2023-07-01 16:35:25 --> Database Driver Class Initialized
INFO - 2023-07-01 16:35:25 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-01 16:35:25 --> Parser Class Initialized
INFO - 2023-07-01 16:35:25 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-01 16:35:25 --> Pagination Class Initialized
INFO - 2023-07-01 16:35:25 --> Form Validation Class Initialized
INFO - 2023-07-01 16:35:25 --> Controller Class Initialized
INFO - 2023-07-01 16:35:25 --> Model Class Initialized
DEBUG - 2023-07-01 16:35:25 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-01 16:35:25 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-01 16:35:25 --> Model Class Initialized
DEBUG - 2023-07-01 16:35:25 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-01 16:35:25 --> Model Class Initialized
INFO - 2023-07-01 16:35:25 --> Final output sent to browser
DEBUG - 2023-07-01 16:35:25 --> Total execution time: 0.0444
ERROR - 2023-07-01 16:35:32 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-01 16:35:32 --> Config Class Initialized
INFO - 2023-07-01 16:35:32 --> Hooks Class Initialized
DEBUG - 2023-07-01 16:35:32 --> UTF-8 Support Enabled
INFO - 2023-07-01 16:35:32 --> Utf8 Class Initialized
INFO - 2023-07-01 16:35:32 --> URI Class Initialized
INFO - 2023-07-01 16:35:32 --> Router Class Initialized
INFO - 2023-07-01 16:35:32 --> Output Class Initialized
INFO - 2023-07-01 16:35:32 --> Security Class Initialized
DEBUG - 2023-07-01 16:35:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-01 16:35:32 --> Input Class Initialized
INFO - 2023-07-01 16:35:32 --> Language Class Initialized
INFO - 2023-07-01 16:35:32 --> Loader Class Initialized
INFO - 2023-07-01 16:35:33 --> Helper loaded: url_helper
INFO - 2023-07-01 16:35:33 --> Helper loaded: file_helper
INFO - 2023-07-01 16:35:33 --> Helper loaded: html_helper
INFO - 2023-07-01 16:35:33 --> Helper loaded: text_helper
INFO - 2023-07-01 16:35:33 --> Helper loaded: form_helper
INFO - 2023-07-01 16:35:33 --> Helper loaded: lang_helper
INFO - 2023-07-01 16:35:33 --> Helper loaded: security_helper
INFO - 2023-07-01 16:35:33 --> Helper loaded: cookie_helper
INFO - 2023-07-01 16:35:33 --> Database Driver Class Initialized
INFO - 2023-07-01 16:35:33 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-01 16:35:33 --> Parser Class Initialized
INFO - 2023-07-01 16:35:33 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-01 16:35:33 --> Pagination Class Initialized
INFO - 2023-07-01 16:35:33 --> Form Validation Class Initialized
INFO - 2023-07-01 16:35:33 --> Controller Class Initialized
INFO - 2023-07-01 16:35:33 --> Model Class Initialized
DEBUG - 2023-07-01 16:35:33 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-01 16:35:33 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-01 16:35:33 --> Model Class Initialized
DEBUG - 2023-07-01 16:35:33 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-01 16:35:33 --> Model Class Initialized
INFO - 2023-07-01 16:35:33 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/invoice/invoice_html.php
DEBUG - 2023-07-01 16:35:33 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-07-01 16:35:33 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-07-01 16:35:33 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-07-01 16:35:33 --> Model Class Initialized
INFO - 2023-07-01 16:35:33 --> Model Class Initialized
INFO - 2023-07-01 16:35:33 --> Model Class Initialized
INFO - 2023-07-01 16:35:33 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-07-01 16:35:33 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-07-01 16:35:33 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-07-01 16:35:33 --> Final output sent to browser
DEBUG - 2023-07-01 16:35:33 --> Total execution time: 0.0756
ERROR - 2023-07-01 16:36:59 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-01 16:36:59 --> Config Class Initialized
INFO - 2023-07-01 16:36:59 --> Hooks Class Initialized
DEBUG - 2023-07-01 16:36:59 --> UTF-8 Support Enabled
INFO - 2023-07-01 16:36:59 --> Utf8 Class Initialized
INFO - 2023-07-01 16:36:59 --> URI Class Initialized
INFO - 2023-07-01 16:36:59 --> Router Class Initialized
INFO - 2023-07-01 16:36:59 --> Output Class Initialized
INFO - 2023-07-01 16:36:59 --> Security Class Initialized
DEBUG - 2023-07-01 16:36:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-01 16:36:59 --> Input Class Initialized
INFO - 2023-07-01 16:36:59 --> Language Class Initialized
INFO - 2023-07-01 16:36:59 --> Loader Class Initialized
INFO - 2023-07-01 16:36:59 --> Helper loaded: url_helper
INFO - 2023-07-01 16:36:59 --> Helper loaded: file_helper
INFO - 2023-07-01 16:36:59 --> Helper loaded: html_helper
INFO - 2023-07-01 16:36:59 --> Helper loaded: text_helper
INFO - 2023-07-01 16:36:59 --> Helper loaded: form_helper
INFO - 2023-07-01 16:36:59 --> Helper loaded: lang_helper
INFO - 2023-07-01 16:36:59 --> Helper loaded: security_helper
INFO - 2023-07-01 16:36:59 --> Helper loaded: cookie_helper
INFO - 2023-07-01 16:36:59 --> Database Driver Class Initialized
INFO - 2023-07-01 16:36:59 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-01 16:36:59 --> Parser Class Initialized
INFO - 2023-07-01 16:36:59 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-01 16:36:59 --> Pagination Class Initialized
INFO - 2023-07-01 16:36:59 --> Form Validation Class Initialized
INFO - 2023-07-01 16:36:59 --> Controller Class Initialized
INFO - 2023-07-01 16:36:59 --> Model Class Initialized
DEBUG - 2023-07-01 16:36:59 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-01 16:36:59 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-01 16:36:59 --> Model Class Initialized
DEBUG - 2023-07-01 16:36:59 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-01 16:36:59 --> Model Class Initialized
INFO - 2023-07-01 16:36:59 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/invoice/invoice.php
DEBUG - 2023-07-01 16:36:59 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-07-01 16:36:59 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-07-01 16:36:59 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-07-01 16:36:59 --> Model Class Initialized
INFO - 2023-07-01 16:36:59 --> Model Class Initialized
INFO - 2023-07-01 16:36:59 --> Model Class Initialized
INFO - 2023-07-01 16:36:59 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-07-01 16:36:59 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-07-01 16:36:59 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-07-01 16:36:59 --> Final output sent to browser
DEBUG - 2023-07-01 16:36:59 --> Total execution time: 0.0717
ERROR - 2023-07-01 16:37:00 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-01 16:37:00 --> Config Class Initialized
INFO - 2023-07-01 16:37:00 --> Hooks Class Initialized
DEBUG - 2023-07-01 16:37:00 --> UTF-8 Support Enabled
INFO - 2023-07-01 16:37:00 --> Utf8 Class Initialized
INFO - 2023-07-01 16:37:00 --> URI Class Initialized
INFO - 2023-07-01 16:37:00 --> Router Class Initialized
INFO - 2023-07-01 16:37:00 --> Output Class Initialized
INFO - 2023-07-01 16:37:00 --> Security Class Initialized
DEBUG - 2023-07-01 16:37:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-01 16:37:00 --> Input Class Initialized
INFO - 2023-07-01 16:37:00 --> Language Class Initialized
INFO - 2023-07-01 16:37:00 --> Loader Class Initialized
INFO - 2023-07-01 16:37:00 --> Helper loaded: url_helper
INFO - 2023-07-01 16:37:00 --> Helper loaded: file_helper
INFO - 2023-07-01 16:37:00 --> Helper loaded: html_helper
INFO - 2023-07-01 16:37:00 --> Helper loaded: text_helper
INFO - 2023-07-01 16:37:00 --> Helper loaded: form_helper
INFO - 2023-07-01 16:37:00 --> Helper loaded: lang_helper
INFO - 2023-07-01 16:37:00 --> Helper loaded: security_helper
INFO - 2023-07-01 16:37:00 --> Helper loaded: cookie_helper
INFO - 2023-07-01 16:37:00 --> Database Driver Class Initialized
INFO - 2023-07-01 16:37:00 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-01 16:37:00 --> Parser Class Initialized
INFO - 2023-07-01 16:37:00 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-01 16:37:00 --> Pagination Class Initialized
INFO - 2023-07-01 16:37:00 --> Form Validation Class Initialized
INFO - 2023-07-01 16:37:00 --> Controller Class Initialized
INFO - 2023-07-01 16:37:00 --> Model Class Initialized
DEBUG - 2023-07-01 16:37:00 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-01 16:37:00 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-01 16:37:00 --> Model Class Initialized
DEBUG - 2023-07-01 16:37:00 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-01 16:37:00 --> Model Class Initialized
INFO - 2023-07-01 16:37:00 --> Final output sent to browser
DEBUG - 2023-07-01 16:37:00 --> Total execution time: 0.0476
ERROR - 2023-07-01 16:37:13 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-01 16:37:13 --> Config Class Initialized
INFO - 2023-07-01 16:37:13 --> Hooks Class Initialized
DEBUG - 2023-07-01 16:37:13 --> UTF-8 Support Enabled
INFO - 2023-07-01 16:37:13 --> Utf8 Class Initialized
INFO - 2023-07-01 16:37:13 --> URI Class Initialized
INFO - 2023-07-01 16:37:13 --> Router Class Initialized
INFO - 2023-07-01 16:37:13 --> Output Class Initialized
INFO - 2023-07-01 16:37:13 --> Security Class Initialized
DEBUG - 2023-07-01 16:37:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-01 16:37:13 --> Input Class Initialized
INFO - 2023-07-01 16:37:13 --> Language Class Initialized
INFO - 2023-07-01 16:37:13 --> Loader Class Initialized
INFO - 2023-07-01 16:37:13 --> Helper loaded: url_helper
INFO - 2023-07-01 16:37:13 --> Helper loaded: file_helper
INFO - 2023-07-01 16:37:13 --> Helper loaded: html_helper
INFO - 2023-07-01 16:37:13 --> Helper loaded: text_helper
INFO - 2023-07-01 16:37:13 --> Helper loaded: form_helper
INFO - 2023-07-01 16:37:13 --> Helper loaded: lang_helper
INFO - 2023-07-01 16:37:13 --> Helper loaded: security_helper
INFO - 2023-07-01 16:37:13 --> Helper loaded: cookie_helper
INFO - 2023-07-01 16:37:13 --> Database Driver Class Initialized
INFO - 2023-07-01 16:37:13 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-01 16:37:13 --> Parser Class Initialized
INFO - 2023-07-01 16:37:13 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-01 16:37:13 --> Pagination Class Initialized
INFO - 2023-07-01 16:37:13 --> Form Validation Class Initialized
INFO - 2023-07-01 16:37:13 --> Controller Class Initialized
INFO - 2023-07-01 16:37:13 --> Model Class Initialized
DEBUG - 2023-07-01 16:37:13 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-01 16:37:13 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-01 16:37:13 --> Model Class Initialized
DEBUG - 2023-07-01 16:37:13 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-01 16:37:13 --> Model Class Initialized
INFO - 2023-07-01 16:37:13 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/add_invoice_form.php
DEBUG - 2023-07-01 16:37:13 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-07-01 16:37:13 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-07-01 16:37:13 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-07-01 16:37:13 --> Model Class Initialized
INFO - 2023-07-01 16:37:13 --> Model Class Initialized
INFO - 2023-07-01 16:37:13 --> Model Class Initialized
INFO - 2023-07-01 16:37:13 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-07-01 16:37:13 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-07-01 16:37:13 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-07-01 16:37:13 --> Final output sent to browser
DEBUG - 2023-07-01 16:37:13 --> Total execution time: 0.0948
ERROR - 2023-07-01 16:37:17 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-01 16:37:17 --> Config Class Initialized
INFO - 2023-07-01 16:37:17 --> Hooks Class Initialized
DEBUG - 2023-07-01 16:37:17 --> UTF-8 Support Enabled
INFO - 2023-07-01 16:37:17 --> Utf8 Class Initialized
INFO - 2023-07-01 16:37:17 --> URI Class Initialized
INFO - 2023-07-01 16:37:17 --> Router Class Initialized
INFO - 2023-07-01 16:37:17 --> Output Class Initialized
INFO - 2023-07-01 16:37:17 --> Security Class Initialized
DEBUG - 2023-07-01 16:37:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-01 16:37:17 --> Input Class Initialized
INFO - 2023-07-01 16:37:17 --> Language Class Initialized
INFO - 2023-07-01 16:37:17 --> Loader Class Initialized
INFO - 2023-07-01 16:37:17 --> Helper loaded: url_helper
INFO - 2023-07-01 16:37:17 --> Helper loaded: file_helper
INFO - 2023-07-01 16:37:17 --> Helper loaded: html_helper
INFO - 2023-07-01 16:37:17 --> Helper loaded: text_helper
INFO - 2023-07-01 16:37:17 --> Helper loaded: form_helper
INFO - 2023-07-01 16:37:17 --> Helper loaded: lang_helper
INFO - 2023-07-01 16:37:17 --> Helper loaded: security_helper
INFO - 2023-07-01 16:37:17 --> Helper loaded: cookie_helper
INFO - 2023-07-01 16:37:17 --> Database Driver Class Initialized
INFO - 2023-07-01 16:37:17 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-01 16:37:17 --> Parser Class Initialized
INFO - 2023-07-01 16:37:17 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-01 16:37:17 --> Pagination Class Initialized
INFO - 2023-07-01 16:37:17 --> Form Validation Class Initialized
INFO - 2023-07-01 16:37:17 --> Controller Class Initialized
INFO - 2023-07-01 16:37:17 --> Model Class Initialized
DEBUG - 2023-07-01 16:37:17 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-01 16:37:17 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-01 16:37:17 --> Model Class Initialized
DEBUG - 2023-07-01 16:37:17 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-01 16:37:17 --> Model Class Initialized
INFO - 2023-07-01 16:37:17 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice.php
DEBUG - 2023-07-01 16:37:17 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-07-01 16:37:17 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-07-01 16:37:17 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-07-01 16:37:17 --> Model Class Initialized
INFO - 2023-07-01 16:37:17 --> Model Class Initialized
INFO - 2023-07-01 16:37:17 --> Model Class Initialized
INFO - 2023-07-01 16:37:17 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-07-01 16:37:17 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-07-01 16:37:17 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-07-01 16:37:17 --> Final output sent to browser
DEBUG - 2023-07-01 16:37:17 --> Total execution time: 0.0677
ERROR - 2023-07-01 16:37:18 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-01 16:37:18 --> Config Class Initialized
INFO - 2023-07-01 16:37:18 --> Hooks Class Initialized
DEBUG - 2023-07-01 16:37:18 --> UTF-8 Support Enabled
INFO - 2023-07-01 16:37:18 --> Utf8 Class Initialized
INFO - 2023-07-01 16:37:18 --> URI Class Initialized
INFO - 2023-07-01 16:37:18 --> Router Class Initialized
INFO - 2023-07-01 16:37:18 --> Output Class Initialized
INFO - 2023-07-01 16:37:18 --> Security Class Initialized
DEBUG - 2023-07-01 16:37:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-01 16:37:18 --> Input Class Initialized
INFO - 2023-07-01 16:37:18 --> Language Class Initialized
INFO - 2023-07-01 16:37:18 --> Loader Class Initialized
INFO - 2023-07-01 16:37:18 --> Helper loaded: url_helper
INFO - 2023-07-01 16:37:18 --> Helper loaded: file_helper
INFO - 2023-07-01 16:37:18 --> Helper loaded: html_helper
INFO - 2023-07-01 16:37:18 --> Helper loaded: text_helper
INFO - 2023-07-01 16:37:18 --> Helper loaded: form_helper
INFO - 2023-07-01 16:37:18 --> Helper loaded: lang_helper
INFO - 2023-07-01 16:37:18 --> Helper loaded: security_helper
INFO - 2023-07-01 16:37:18 --> Helper loaded: cookie_helper
INFO - 2023-07-01 16:37:18 --> Database Driver Class Initialized
INFO - 2023-07-01 16:37:18 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-01 16:37:18 --> Parser Class Initialized
INFO - 2023-07-01 16:37:18 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-01 16:37:18 --> Pagination Class Initialized
INFO - 2023-07-01 16:37:18 --> Form Validation Class Initialized
INFO - 2023-07-01 16:37:18 --> Controller Class Initialized
INFO - 2023-07-01 16:37:18 --> Model Class Initialized
DEBUG - 2023-07-01 16:37:18 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-01 16:37:18 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-01 16:37:18 --> Model Class Initialized
DEBUG - 2023-07-01 16:37:18 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-01 16:37:18 --> Model Class Initialized
INFO - 2023-07-01 16:37:18 --> Final output sent to browser
DEBUG - 2023-07-01 16:37:18 --> Total execution time: 0.0380
ERROR - 2023-07-01 16:37:46 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-01 16:37:46 --> Config Class Initialized
INFO - 2023-07-01 16:37:46 --> Hooks Class Initialized
DEBUG - 2023-07-01 16:37:46 --> UTF-8 Support Enabled
INFO - 2023-07-01 16:37:46 --> Utf8 Class Initialized
INFO - 2023-07-01 16:37:46 --> URI Class Initialized
INFO - 2023-07-01 16:37:46 --> Router Class Initialized
INFO - 2023-07-01 16:37:46 --> Output Class Initialized
INFO - 2023-07-01 16:37:46 --> Security Class Initialized
DEBUG - 2023-07-01 16:37:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-01 16:37:46 --> Input Class Initialized
INFO - 2023-07-01 16:37:46 --> Language Class Initialized
INFO - 2023-07-01 16:37:46 --> Loader Class Initialized
INFO - 2023-07-01 16:37:46 --> Helper loaded: url_helper
INFO - 2023-07-01 16:37:46 --> Helper loaded: file_helper
INFO - 2023-07-01 16:37:46 --> Helper loaded: html_helper
INFO - 2023-07-01 16:37:46 --> Helper loaded: text_helper
INFO - 2023-07-01 16:37:46 --> Helper loaded: form_helper
INFO - 2023-07-01 16:37:46 --> Helper loaded: lang_helper
INFO - 2023-07-01 16:37:46 --> Helper loaded: security_helper
INFO - 2023-07-01 16:37:46 --> Helper loaded: cookie_helper
INFO - 2023-07-01 16:37:46 --> Database Driver Class Initialized
INFO - 2023-07-01 16:37:46 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-01 16:37:46 --> Parser Class Initialized
INFO - 2023-07-01 16:37:46 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-01 16:37:46 --> Pagination Class Initialized
INFO - 2023-07-01 16:37:46 --> Form Validation Class Initialized
INFO - 2023-07-01 16:37:46 --> Controller Class Initialized
DEBUG - 2023-07-01 16:37:46 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-01 16:37:46 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-01 16:37:46 --> Model Class Initialized
DEBUG - 2023-07-01 16:37:46 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-01 16:37:46 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-07-01 16:37:46 --> Ltarget class already loaded. Second attempt ignored.
INFO - 2023-07-01 16:37:46 --> Model Class Initialized
DEBUG - 2023-07-01 16:37:46 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-01 16:37:46 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-01 16:37:46 --> Model Class Initialized
DEBUG - 2023-07-01 16:37:46 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-01 16:37:46 --> Model Class Initialized
INFO - 2023-07-01 16:37:46 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/target/target.php
DEBUG - 2023-07-01 16:37:46 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-07-01 16:37:46 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-07-01 16:37:46 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-07-01 16:37:46 --> Model Class Initialized
INFO - 2023-07-01 16:37:46 --> Model Class Initialized
INFO - 2023-07-01 16:37:46 --> Model Class Initialized
INFO - 2023-07-01 16:37:46 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-07-01 16:37:46 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-07-01 16:37:46 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-07-01 16:37:46 --> Final output sent to browser
DEBUG - 2023-07-01 16:37:46 --> Total execution time: 0.0652
ERROR - 2023-07-01 16:37:47 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-01 16:37:47 --> Config Class Initialized
INFO - 2023-07-01 16:37:47 --> Hooks Class Initialized
DEBUG - 2023-07-01 16:37:47 --> UTF-8 Support Enabled
INFO - 2023-07-01 16:37:47 --> Utf8 Class Initialized
INFO - 2023-07-01 16:37:47 --> URI Class Initialized
INFO - 2023-07-01 16:37:47 --> Router Class Initialized
INFO - 2023-07-01 16:37:47 --> Output Class Initialized
INFO - 2023-07-01 16:37:47 --> Security Class Initialized
DEBUG - 2023-07-01 16:37:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-01 16:37:47 --> Input Class Initialized
INFO - 2023-07-01 16:37:47 --> Language Class Initialized
INFO - 2023-07-01 16:37:47 --> Loader Class Initialized
INFO - 2023-07-01 16:37:47 --> Helper loaded: url_helper
INFO - 2023-07-01 16:37:47 --> Helper loaded: file_helper
INFO - 2023-07-01 16:37:47 --> Helper loaded: html_helper
INFO - 2023-07-01 16:37:47 --> Helper loaded: text_helper
INFO - 2023-07-01 16:37:47 --> Helper loaded: form_helper
INFO - 2023-07-01 16:37:47 --> Helper loaded: lang_helper
INFO - 2023-07-01 16:37:47 --> Helper loaded: security_helper
INFO - 2023-07-01 16:37:47 --> Helper loaded: cookie_helper
INFO - 2023-07-01 16:37:47 --> Database Driver Class Initialized
INFO - 2023-07-01 16:37:47 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-01 16:37:47 --> Parser Class Initialized
INFO - 2023-07-01 16:37:47 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-01 16:37:47 --> Pagination Class Initialized
INFO - 2023-07-01 16:37:47 --> Form Validation Class Initialized
INFO - 2023-07-01 16:37:47 --> Controller Class Initialized
DEBUG - 2023-07-01 16:37:47 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-01 16:37:47 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-01 16:37:47 --> Model Class Initialized
DEBUG - 2023-07-01 16:37:47 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-01 16:37:47 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-01 16:37:47 --> Model Class Initialized
DEBUG - 2023-07-01 16:37:47 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-01 16:37:47 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-01 16:37:47 --> Model Class Initialized
DEBUG - 2023-07-01 16:37:47 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-01 16:37:47 --> Model Class Initialized
INFO - 2023-07-01 16:37:47 --> Final output sent to browser
DEBUG - 2023-07-01 16:37:47 --> Total execution time: 0.0199
ERROR - 2023-07-01 16:43:18 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-01 16:43:18 --> Config Class Initialized
INFO - 2023-07-01 16:43:18 --> Hooks Class Initialized
DEBUG - 2023-07-01 16:43:18 --> UTF-8 Support Enabled
INFO - 2023-07-01 16:43:18 --> Utf8 Class Initialized
INFO - 2023-07-01 16:43:18 --> URI Class Initialized
INFO - 2023-07-01 16:43:18 --> Router Class Initialized
INFO - 2023-07-01 16:43:18 --> Output Class Initialized
INFO - 2023-07-01 16:43:18 --> Security Class Initialized
DEBUG - 2023-07-01 16:43:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-01 16:43:18 --> Input Class Initialized
INFO - 2023-07-01 16:43:18 --> Language Class Initialized
INFO - 2023-07-01 16:43:18 --> Loader Class Initialized
INFO - 2023-07-01 16:43:18 --> Helper loaded: url_helper
INFO - 2023-07-01 16:43:18 --> Helper loaded: file_helper
INFO - 2023-07-01 16:43:18 --> Helper loaded: html_helper
INFO - 2023-07-01 16:43:18 --> Helper loaded: text_helper
INFO - 2023-07-01 16:43:18 --> Helper loaded: form_helper
INFO - 2023-07-01 16:43:18 --> Helper loaded: lang_helper
INFO - 2023-07-01 16:43:18 --> Helper loaded: security_helper
INFO - 2023-07-01 16:43:18 --> Helper loaded: cookie_helper
INFO - 2023-07-01 16:43:18 --> Database Driver Class Initialized
INFO - 2023-07-01 16:43:18 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-01 16:43:18 --> Parser Class Initialized
INFO - 2023-07-01 16:43:18 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-01 16:43:18 --> Pagination Class Initialized
INFO - 2023-07-01 16:43:18 --> Form Validation Class Initialized
INFO - 2023-07-01 16:43:18 --> Controller Class Initialized
DEBUG - 2023-07-01 16:43:18 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-01 16:43:18 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-01 16:43:18 --> Model Class Initialized
DEBUG - 2023-07-01 16:43:18 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-01 16:43:18 --> Model Class Initialized
DEBUG - 2023-07-01 16:43:18 --> Lcustomer class already loaded. Second attempt ignored.
INFO - 2023-07-01 16:43:18 --> Model Class Initialized
INFO - 2023-07-01 16:43:18 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/customer/customer.php
DEBUG - 2023-07-01 16:43:18 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-07-01 16:43:18 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-07-01 16:43:18 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-07-01 16:43:18 --> Model Class Initialized
INFO - 2023-07-01 16:43:18 --> Model Class Initialized
INFO - 2023-07-01 16:43:18 --> Model Class Initialized
INFO - 2023-07-01 16:43:18 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-07-01 16:43:18 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-07-01 16:43:18 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-07-01 16:43:18 --> Final output sent to browser
DEBUG - 2023-07-01 16:43:18 --> Total execution time: 0.1252
ERROR - 2023-07-01 16:43:19 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-01 16:43:19 --> Config Class Initialized
INFO - 2023-07-01 16:43:19 --> Hooks Class Initialized
DEBUG - 2023-07-01 16:43:19 --> UTF-8 Support Enabled
INFO - 2023-07-01 16:43:19 --> Utf8 Class Initialized
INFO - 2023-07-01 16:43:19 --> URI Class Initialized
INFO - 2023-07-01 16:43:19 --> Router Class Initialized
INFO - 2023-07-01 16:43:19 --> Output Class Initialized
INFO - 2023-07-01 16:43:19 --> Security Class Initialized
DEBUG - 2023-07-01 16:43:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-01 16:43:19 --> Input Class Initialized
INFO - 2023-07-01 16:43:19 --> Language Class Initialized
INFO - 2023-07-01 16:43:19 --> Loader Class Initialized
INFO - 2023-07-01 16:43:19 --> Helper loaded: url_helper
INFO - 2023-07-01 16:43:19 --> Helper loaded: file_helper
INFO - 2023-07-01 16:43:19 --> Helper loaded: html_helper
INFO - 2023-07-01 16:43:19 --> Helper loaded: text_helper
INFO - 2023-07-01 16:43:19 --> Helper loaded: form_helper
INFO - 2023-07-01 16:43:19 --> Helper loaded: lang_helper
INFO - 2023-07-01 16:43:19 --> Helper loaded: security_helper
INFO - 2023-07-01 16:43:19 --> Helper loaded: cookie_helper
INFO - 2023-07-01 16:43:19 --> Database Driver Class Initialized
INFO - 2023-07-01 16:43:19 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-01 16:43:19 --> Parser Class Initialized
INFO - 2023-07-01 16:43:19 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-01 16:43:19 --> Pagination Class Initialized
INFO - 2023-07-01 16:43:19 --> Form Validation Class Initialized
INFO - 2023-07-01 16:43:19 --> Controller Class Initialized
DEBUG - 2023-07-01 16:43:19 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-01 16:43:19 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-01 16:43:19 --> Model Class Initialized
DEBUG - 2023-07-01 16:43:19 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-01 16:43:19 --> Model Class Initialized
INFO - 2023-07-01 16:43:19 --> Final output sent to browser
DEBUG - 2023-07-01 16:43:19 --> Total execution time: 0.0291
ERROR - 2023-07-01 16:43:27 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-01 16:43:27 --> Config Class Initialized
INFO - 2023-07-01 16:43:27 --> Hooks Class Initialized
DEBUG - 2023-07-01 16:43:27 --> UTF-8 Support Enabled
INFO - 2023-07-01 16:43:27 --> Utf8 Class Initialized
INFO - 2023-07-01 16:43:27 --> URI Class Initialized
INFO - 2023-07-01 16:43:27 --> Router Class Initialized
INFO - 2023-07-01 16:43:27 --> Output Class Initialized
INFO - 2023-07-01 16:43:27 --> Security Class Initialized
DEBUG - 2023-07-01 16:43:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-01 16:43:27 --> Input Class Initialized
INFO - 2023-07-01 16:43:27 --> Language Class Initialized
INFO - 2023-07-01 16:43:27 --> Loader Class Initialized
INFO - 2023-07-01 16:43:27 --> Helper loaded: url_helper
INFO - 2023-07-01 16:43:27 --> Helper loaded: file_helper
INFO - 2023-07-01 16:43:27 --> Helper loaded: html_helper
INFO - 2023-07-01 16:43:27 --> Helper loaded: text_helper
INFO - 2023-07-01 16:43:27 --> Helper loaded: form_helper
INFO - 2023-07-01 16:43:27 --> Helper loaded: lang_helper
INFO - 2023-07-01 16:43:27 --> Helper loaded: security_helper
INFO - 2023-07-01 16:43:27 --> Helper loaded: cookie_helper
INFO - 2023-07-01 16:43:27 --> Database Driver Class Initialized
INFO - 2023-07-01 16:43:27 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-01 16:43:27 --> Parser Class Initialized
INFO - 2023-07-01 16:43:27 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-01 16:43:27 --> Pagination Class Initialized
INFO - 2023-07-01 16:43:27 --> Form Validation Class Initialized
INFO - 2023-07-01 16:43:27 --> Controller Class Initialized
DEBUG - 2023-07-01 16:43:27 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-01 16:43:27 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-01 16:43:27 --> Model Class Initialized
DEBUG - 2023-07-01 16:43:27 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-01 16:43:27 --> Model Class Initialized
INFO - 2023-07-01 16:43:27 --> Final output sent to browser
DEBUG - 2023-07-01 16:43:27 --> Total execution time: 0.0995
ERROR - 2023-07-01 16:43:38 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-01 16:43:38 --> Config Class Initialized
INFO - 2023-07-01 16:43:38 --> Hooks Class Initialized
DEBUG - 2023-07-01 16:43:38 --> UTF-8 Support Enabled
INFO - 2023-07-01 16:43:38 --> Utf8 Class Initialized
INFO - 2023-07-01 16:43:38 --> URI Class Initialized
INFO - 2023-07-01 16:43:38 --> Router Class Initialized
INFO - 2023-07-01 16:43:38 --> Output Class Initialized
INFO - 2023-07-01 16:43:38 --> Security Class Initialized
DEBUG - 2023-07-01 16:43:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-01 16:43:38 --> Input Class Initialized
INFO - 2023-07-01 16:43:38 --> Language Class Initialized
INFO - 2023-07-01 16:43:38 --> Loader Class Initialized
INFO - 2023-07-01 16:43:38 --> Helper loaded: url_helper
INFO - 2023-07-01 16:43:38 --> Helper loaded: file_helper
INFO - 2023-07-01 16:43:38 --> Helper loaded: html_helper
INFO - 2023-07-01 16:43:38 --> Helper loaded: text_helper
INFO - 2023-07-01 16:43:38 --> Helper loaded: form_helper
INFO - 2023-07-01 16:43:38 --> Helper loaded: lang_helper
INFO - 2023-07-01 16:43:38 --> Helper loaded: security_helper
INFO - 2023-07-01 16:43:38 --> Helper loaded: cookie_helper
INFO - 2023-07-01 16:43:38 --> Database Driver Class Initialized
INFO - 2023-07-01 16:43:38 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-01 16:43:38 --> Parser Class Initialized
INFO - 2023-07-01 16:43:38 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-01 16:43:38 --> Pagination Class Initialized
INFO - 2023-07-01 16:43:38 --> Form Validation Class Initialized
INFO - 2023-07-01 16:43:38 --> Controller Class Initialized
DEBUG - 2023-07-01 16:43:38 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-01 16:43:38 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-01 16:43:38 --> Model Class Initialized
DEBUG - 2023-07-01 16:43:38 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-01 16:43:38 --> Model Class Initialized
INFO - 2023-07-01 16:43:38 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/customer/view_customer.php
DEBUG - 2023-07-01 16:43:38 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-07-01 16:43:38 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-07-01 16:43:38 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-07-01 16:43:38 --> Model Class Initialized
INFO - 2023-07-01 16:43:38 --> Model Class Initialized
INFO - 2023-07-01 16:43:38 --> Model Class Initialized
INFO - 2023-07-01 16:43:38 --> Model Class Initialized
INFO - 2023-07-01 16:43:38 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-07-01 16:43:38 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-07-01 16:43:38 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-07-01 16:43:38 --> Final output sent to browser
DEBUG - 2023-07-01 16:43:38 --> Total execution time: 0.1185
ERROR - 2023-07-01 16:43:56 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-01 16:43:56 --> Config Class Initialized
INFO - 2023-07-01 16:43:56 --> Hooks Class Initialized
DEBUG - 2023-07-01 16:43:56 --> UTF-8 Support Enabled
INFO - 2023-07-01 16:43:56 --> Utf8 Class Initialized
INFO - 2023-07-01 16:43:56 --> URI Class Initialized
DEBUG - 2023-07-01 16:43:56 --> No URI present. Default controller set.
INFO - 2023-07-01 16:43:56 --> Router Class Initialized
INFO - 2023-07-01 16:43:56 --> Output Class Initialized
INFO - 2023-07-01 16:43:56 --> Security Class Initialized
DEBUG - 2023-07-01 16:43:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-01 16:43:56 --> Input Class Initialized
INFO - 2023-07-01 16:43:56 --> Language Class Initialized
INFO - 2023-07-01 16:43:56 --> Loader Class Initialized
INFO - 2023-07-01 16:43:56 --> Helper loaded: url_helper
INFO - 2023-07-01 16:43:56 --> Helper loaded: file_helper
INFO - 2023-07-01 16:43:56 --> Helper loaded: html_helper
INFO - 2023-07-01 16:43:56 --> Helper loaded: text_helper
INFO - 2023-07-01 16:43:56 --> Helper loaded: form_helper
INFO - 2023-07-01 16:43:56 --> Helper loaded: lang_helper
INFO - 2023-07-01 16:43:56 --> Helper loaded: security_helper
INFO - 2023-07-01 16:43:56 --> Helper loaded: cookie_helper
INFO - 2023-07-01 16:43:56 --> Database Driver Class Initialized
INFO - 2023-07-01 16:43:56 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-01 16:43:56 --> Parser Class Initialized
INFO - 2023-07-01 16:43:56 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-01 16:43:56 --> Pagination Class Initialized
INFO - 2023-07-01 16:43:56 --> Form Validation Class Initialized
INFO - 2023-07-01 16:43:56 --> Controller Class Initialized
INFO - 2023-07-01 16:43:56 --> Model Class Initialized
DEBUG - 2023-07-01 16:43:56 --> Session class already loaded. Second attempt ignored.
ERROR - 2023-07-01 16:43:56 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-01 16:43:56 --> Config Class Initialized
INFO - 2023-07-01 16:43:56 --> Hooks Class Initialized
DEBUG - 2023-07-01 16:43:56 --> UTF-8 Support Enabled
INFO - 2023-07-01 16:43:56 --> Utf8 Class Initialized
INFO - 2023-07-01 16:43:56 --> URI Class Initialized
INFO - 2023-07-01 16:43:56 --> Router Class Initialized
INFO - 2023-07-01 16:43:56 --> Output Class Initialized
INFO - 2023-07-01 16:43:56 --> Security Class Initialized
DEBUG - 2023-07-01 16:43:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-01 16:43:56 --> Input Class Initialized
INFO - 2023-07-01 16:43:56 --> Language Class Initialized
INFO - 2023-07-01 16:43:56 --> Loader Class Initialized
INFO - 2023-07-01 16:43:56 --> Helper loaded: url_helper
INFO - 2023-07-01 16:43:56 --> Helper loaded: file_helper
INFO - 2023-07-01 16:43:56 --> Helper loaded: html_helper
INFO - 2023-07-01 16:43:56 --> Helper loaded: text_helper
INFO - 2023-07-01 16:43:56 --> Helper loaded: form_helper
INFO - 2023-07-01 16:43:56 --> Helper loaded: lang_helper
INFO - 2023-07-01 16:43:56 --> Helper loaded: security_helper
INFO - 2023-07-01 16:43:56 --> Helper loaded: cookie_helper
INFO - 2023-07-01 16:43:56 --> Database Driver Class Initialized
INFO - 2023-07-01 16:43:56 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-01 16:43:56 --> Parser Class Initialized
INFO - 2023-07-01 16:43:56 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-01 16:43:56 --> Pagination Class Initialized
INFO - 2023-07-01 16:43:56 --> Form Validation Class Initialized
INFO - 2023-07-01 16:43:56 --> Controller Class Initialized
INFO - 2023-07-01 16:43:56 --> Model Class Initialized
DEBUG - 2023-07-01 16:43:56 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-01 16:43:56 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2023-07-01 16:43:56 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-07-01 16:43:56 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-07-01 16:43:56 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-07-01 16:43:56 --> Model Class Initialized
INFO - 2023-07-01 16:43:56 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-07-01 16:43:56 --> Final output sent to browser
DEBUG - 2023-07-01 16:43:56 --> Total execution time: 0.0273
ERROR - 2023-07-01 16:44:14 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-01 16:44:14 --> Config Class Initialized
INFO - 2023-07-01 16:44:14 --> Hooks Class Initialized
DEBUG - 2023-07-01 16:44:14 --> UTF-8 Support Enabled
INFO - 2023-07-01 16:44:14 --> Utf8 Class Initialized
INFO - 2023-07-01 16:44:14 --> URI Class Initialized
INFO - 2023-07-01 16:44:14 --> Router Class Initialized
INFO - 2023-07-01 16:44:14 --> Output Class Initialized
INFO - 2023-07-01 16:44:14 --> Security Class Initialized
DEBUG - 2023-07-01 16:44:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-01 16:44:14 --> Input Class Initialized
INFO - 2023-07-01 16:44:14 --> Language Class Initialized
INFO - 2023-07-01 16:44:14 --> Loader Class Initialized
INFO - 2023-07-01 16:44:14 --> Helper loaded: url_helper
INFO - 2023-07-01 16:44:14 --> Helper loaded: file_helper
INFO - 2023-07-01 16:44:14 --> Helper loaded: html_helper
INFO - 2023-07-01 16:44:14 --> Helper loaded: text_helper
INFO - 2023-07-01 16:44:14 --> Helper loaded: form_helper
INFO - 2023-07-01 16:44:14 --> Helper loaded: lang_helper
INFO - 2023-07-01 16:44:14 --> Helper loaded: security_helper
INFO - 2023-07-01 16:44:14 --> Helper loaded: cookie_helper
INFO - 2023-07-01 16:44:14 --> Database Driver Class Initialized
INFO - 2023-07-01 16:44:14 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-01 16:44:14 --> Parser Class Initialized
INFO - 2023-07-01 16:44:14 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-01 16:44:14 --> Pagination Class Initialized
INFO - 2023-07-01 16:44:14 --> Form Validation Class Initialized
INFO - 2023-07-01 16:44:14 --> Controller Class Initialized
INFO - 2023-07-01 16:44:14 --> Model Class Initialized
DEBUG - 2023-07-01 16:44:14 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-01 16:44:14 --> Model Class Initialized
INFO - 2023-07-01 16:44:14 --> Final output sent to browser
DEBUG - 2023-07-01 16:44:14 --> Total execution time: 0.0184
ERROR - 2023-07-01 16:44:14 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-01 16:44:14 --> Config Class Initialized
INFO - 2023-07-01 16:44:14 --> Hooks Class Initialized
DEBUG - 2023-07-01 16:44:14 --> UTF-8 Support Enabled
INFO - 2023-07-01 16:44:14 --> Utf8 Class Initialized
INFO - 2023-07-01 16:44:14 --> URI Class Initialized
DEBUG - 2023-07-01 16:44:14 --> No URI present. Default controller set.
INFO - 2023-07-01 16:44:14 --> Router Class Initialized
INFO - 2023-07-01 16:44:14 --> Output Class Initialized
INFO - 2023-07-01 16:44:14 --> Security Class Initialized
DEBUG - 2023-07-01 16:44:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-01 16:44:14 --> Input Class Initialized
INFO - 2023-07-01 16:44:14 --> Language Class Initialized
INFO - 2023-07-01 16:44:14 --> Loader Class Initialized
INFO - 2023-07-01 16:44:14 --> Helper loaded: url_helper
INFO - 2023-07-01 16:44:14 --> Helper loaded: file_helper
INFO - 2023-07-01 16:44:14 --> Helper loaded: html_helper
INFO - 2023-07-01 16:44:14 --> Helper loaded: text_helper
INFO - 2023-07-01 16:44:14 --> Helper loaded: form_helper
INFO - 2023-07-01 16:44:14 --> Helper loaded: lang_helper
INFO - 2023-07-01 16:44:14 --> Helper loaded: security_helper
INFO - 2023-07-01 16:44:14 --> Helper loaded: cookie_helper
INFO - 2023-07-01 16:44:14 --> Database Driver Class Initialized
INFO - 2023-07-01 16:44:14 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-01 16:44:14 --> Parser Class Initialized
INFO - 2023-07-01 16:44:14 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-01 16:44:14 --> Pagination Class Initialized
INFO - 2023-07-01 16:44:14 --> Form Validation Class Initialized
INFO - 2023-07-01 16:44:14 --> Controller Class Initialized
INFO - 2023-07-01 16:44:14 --> Model Class Initialized
DEBUG - 2023-07-01 16:44:14 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-01 16:44:14 --> Model Class Initialized
DEBUG - 2023-07-01 16:44:14 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-01 16:44:14 --> Model Class Initialized
INFO - 2023-07-01 16:44:14 --> Model Class Initialized
INFO - 2023-07-01 16:44:14 --> Model Class Initialized
INFO - 2023-07-01 16:44:14 --> Model Class Initialized
DEBUG - 2023-07-01 16:44:14 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-01 16:44:14 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-01 16:44:14 --> Model Class Initialized
INFO - 2023-07-01 16:44:14 --> Model Class Initialized
INFO - 2023-07-01 16:44:14 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-07-01 16:44:14 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-07-01 16:44:14 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-07-01 16:44:14 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-07-01 16:44:14 --> Model Class Initialized
INFO - 2023-07-01 16:44:14 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-07-01 16:44:14 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-07-01 16:44:14 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-07-01 16:44:14 --> Final output sent to browser
DEBUG - 2023-07-01 16:44:14 --> Total execution time: 0.0816
ERROR - 2023-07-01 16:44:25 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-01 16:44:25 --> Config Class Initialized
INFO - 2023-07-01 16:44:25 --> Hooks Class Initialized
DEBUG - 2023-07-01 16:44:25 --> UTF-8 Support Enabled
INFO - 2023-07-01 16:44:25 --> Utf8 Class Initialized
INFO - 2023-07-01 16:44:25 --> URI Class Initialized
INFO - 2023-07-01 16:44:25 --> Router Class Initialized
INFO - 2023-07-01 16:44:25 --> Output Class Initialized
INFO - 2023-07-01 16:44:25 --> Security Class Initialized
DEBUG - 2023-07-01 16:44:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-01 16:44:25 --> Input Class Initialized
INFO - 2023-07-01 16:44:25 --> Language Class Initialized
INFO - 2023-07-01 16:44:25 --> Loader Class Initialized
INFO - 2023-07-01 16:44:25 --> Helper loaded: url_helper
INFO - 2023-07-01 16:44:25 --> Helper loaded: file_helper
INFO - 2023-07-01 16:44:25 --> Helper loaded: html_helper
INFO - 2023-07-01 16:44:25 --> Helper loaded: text_helper
INFO - 2023-07-01 16:44:25 --> Helper loaded: form_helper
INFO - 2023-07-01 16:44:25 --> Helper loaded: lang_helper
INFO - 2023-07-01 16:44:25 --> Helper loaded: security_helper
INFO - 2023-07-01 16:44:25 --> Helper loaded: cookie_helper
INFO - 2023-07-01 16:44:25 --> Database Driver Class Initialized
INFO - 2023-07-01 16:44:25 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-01 16:44:25 --> Parser Class Initialized
INFO - 2023-07-01 16:44:25 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-01 16:44:25 --> Pagination Class Initialized
INFO - 2023-07-01 16:44:25 --> Form Validation Class Initialized
INFO - 2023-07-01 16:44:25 --> Controller Class Initialized
INFO - 2023-07-01 16:44:25 --> Model Class Initialized
DEBUG - 2023-07-01 16:44:25 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-01 16:44:25 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-01 16:44:25 --> Model Class Initialized
DEBUG - 2023-07-01 16:44:25 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-01 16:44:25 --> Model Class Initialized
INFO - 2023-07-01 16:44:25 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice.php
DEBUG - 2023-07-01 16:44:25 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-07-01 16:44:25 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-07-01 16:44:25 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-07-01 16:44:25 --> Model Class Initialized
INFO - 2023-07-01 16:44:25 --> Model Class Initialized
INFO - 2023-07-01 16:44:25 --> Model Class Initialized
INFO - 2023-07-01 16:44:25 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-07-01 16:44:25 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-07-01 16:44:25 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-07-01 16:44:25 --> Final output sent to browser
DEBUG - 2023-07-01 16:44:25 --> Total execution time: 0.0608
ERROR - 2023-07-01 16:44:26 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-01 16:44:26 --> Config Class Initialized
INFO - 2023-07-01 16:44:26 --> Hooks Class Initialized
DEBUG - 2023-07-01 16:44:26 --> UTF-8 Support Enabled
INFO - 2023-07-01 16:44:26 --> Utf8 Class Initialized
INFO - 2023-07-01 16:44:26 --> URI Class Initialized
INFO - 2023-07-01 16:44:26 --> Router Class Initialized
INFO - 2023-07-01 16:44:26 --> Output Class Initialized
INFO - 2023-07-01 16:44:26 --> Security Class Initialized
DEBUG - 2023-07-01 16:44:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-01 16:44:26 --> Input Class Initialized
INFO - 2023-07-01 16:44:26 --> Language Class Initialized
INFO - 2023-07-01 16:44:26 --> Loader Class Initialized
INFO - 2023-07-01 16:44:26 --> Helper loaded: url_helper
INFO - 2023-07-01 16:44:26 --> Helper loaded: file_helper
INFO - 2023-07-01 16:44:26 --> Helper loaded: html_helper
INFO - 2023-07-01 16:44:26 --> Helper loaded: text_helper
INFO - 2023-07-01 16:44:26 --> Helper loaded: form_helper
INFO - 2023-07-01 16:44:26 --> Helper loaded: lang_helper
INFO - 2023-07-01 16:44:26 --> Helper loaded: security_helper
INFO - 2023-07-01 16:44:26 --> Helper loaded: cookie_helper
INFO - 2023-07-01 16:44:26 --> Database Driver Class Initialized
INFO - 2023-07-01 16:44:26 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-01 16:44:26 --> Parser Class Initialized
INFO - 2023-07-01 16:44:26 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-01 16:44:26 --> Pagination Class Initialized
INFO - 2023-07-01 16:44:26 --> Form Validation Class Initialized
INFO - 2023-07-01 16:44:26 --> Controller Class Initialized
INFO - 2023-07-01 16:44:26 --> Model Class Initialized
DEBUG - 2023-07-01 16:44:26 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-01 16:44:26 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-01 16:44:26 --> Model Class Initialized
DEBUG - 2023-07-01 16:44:26 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-01 16:44:26 --> Model Class Initialized
INFO - 2023-07-01 16:44:26 --> Final output sent to browser
DEBUG - 2023-07-01 16:44:26 --> Total execution time: 0.0263
ERROR - 2023-07-01 16:44:43 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-01 16:44:43 --> Config Class Initialized
INFO - 2023-07-01 16:44:43 --> Hooks Class Initialized
DEBUG - 2023-07-01 16:44:43 --> UTF-8 Support Enabled
INFO - 2023-07-01 16:44:43 --> Utf8 Class Initialized
INFO - 2023-07-01 16:44:43 --> URI Class Initialized
INFO - 2023-07-01 16:44:43 --> Router Class Initialized
INFO - 2023-07-01 16:44:43 --> Output Class Initialized
INFO - 2023-07-01 16:44:43 --> Security Class Initialized
DEBUG - 2023-07-01 16:44:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-01 16:44:43 --> Input Class Initialized
INFO - 2023-07-01 16:44:43 --> Language Class Initialized
INFO - 2023-07-01 16:44:43 --> Loader Class Initialized
INFO - 2023-07-01 16:44:43 --> Helper loaded: url_helper
INFO - 2023-07-01 16:44:43 --> Helper loaded: file_helper
INFO - 2023-07-01 16:44:43 --> Helper loaded: html_helper
INFO - 2023-07-01 16:44:43 --> Helper loaded: text_helper
INFO - 2023-07-01 16:44:43 --> Helper loaded: form_helper
INFO - 2023-07-01 16:44:43 --> Helper loaded: lang_helper
INFO - 2023-07-01 16:44:43 --> Helper loaded: security_helper
INFO - 2023-07-01 16:44:43 --> Helper loaded: cookie_helper
INFO - 2023-07-01 16:44:43 --> Database Driver Class Initialized
INFO - 2023-07-01 16:44:43 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-01 16:44:43 --> Parser Class Initialized
INFO - 2023-07-01 16:44:43 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-01 16:44:43 --> Pagination Class Initialized
INFO - 2023-07-01 16:44:43 --> Form Validation Class Initialized
INFO - 2023-07-01 16:44:43 --> Controller Class Initialized
INFO - 2023-07-01 16:44:43 --> Model Class Initialized
DEBUG - 2023-07-01 16:44:43 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-01 16:44:43 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-01 16:44:43 --> Model Class Initialized
DEBUG - 2023-07-01 16:44:43 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-01 16:44:43 --> Model Class Initialized
DEBUG - 2023-07-01 16:44:43 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-01 16:44:43 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice_html.php
DEBUG - 2023-07-01 16:44:43 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-07-01 16:44:43 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-07-01 16:44:43 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-07-01 16:44:43 --> Model Class Initialized
INFO - 2023-07-01 16:44:43 --> Model Class Initialized
INFO - 2023-07-01 16:44:43 --> Model Class Initialized
INFO - 2023-07-01 16:44:43 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-07-01 16:44:43 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-07-01 16:44:43 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-07-01 16:44:43 --> Final output sent to browser
DEBUG - 2023-07-01 16:44:43 --> Total execution time: 0.0783
ERROR - 2023-07-01 16:45:36 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-01 16:45:36 --> Config Class Initialized
INFO - 2023-07-01 16:45:36 --> Hooks Class Initialized
DEBUG - 2023-07-01 16:45:36 --> UTF-8 Support Enabled
INFO - 2023-07-01 16:45:36 --> Utf8 Class Initialized
INFO - 2023-07-01 16:45:36 --> URI Class Initialized
INFO - 2023-07-01 16:45:36 --> Router Class Initialized
INFO - 2023-07-01 16:45:36 --> Output Class Initialized
INFO - 2023-07-01 16:45:36 --> Security Class Initialized
DEBUG - 2023-07-01 16:45:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-01 16:45:36 --> Input Class Initialized
INFO - 2023-07-01 16:45:36 --> Language Class Initialized
INFO - 2023-07-01 16:45:36 --> Loader Class Initialized
INFO - 2023-07-01 16:45:36 --> Helper loaded: url_helper
INFO - 2023-07-01 16:45:36 --> Helper loaded: file_helper
INFO - 2023-07-01 16:45:36 --> Helper loaded: html_helper
INFO - 2023-07-01 16:45:36 --> Helper loaded: text_helper
INFO - 2023-07-01 16:45:36 --> Helper loaded: form_helper
INFO - 2023-07-01 16:45:36 --> Helper loaded: lang_helper
INFO - 2023-07-01 16:45:36 --> Helper loaded: security_helper
INFO - 2023-07-01 16:45:36 --> Helper loaded: cookie_helper
INFO - 2023-07-01 16:45:36 --> Database Driver Class Initialized
INFO - 2023-07-01 16:45:36 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-01 16:45:36 --> Parser Class Initialized
INFO - 2023-07-01 16:45:36 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-01 16:45:36 --> Pagination Class Initialized
INFO - 2023-07-01 16:45:36 --> Form Validation Class Initialized
INFO - 2023-07-01 16:45:36 --> Controller Class Initialized
INFO - 2023-07-01 16:45:36 --> Model Class Initialized
DEBUG - 2023-07-01 16:45:36 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-01 16:45:36 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-01 16:45:36 --> Model Class Initialized
DEBUG - 2023-07-01 16:45:36 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-01 16:45:36 --> Model Class Initialized
INFO - 2023-07-01 16:45:36 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice.php
DEBUG - 2023-07-01 16:45:36 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-07-01 16:45:36 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-07-01 16:45:36 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-07-01 16:45:36 --> Model Class Initialized
INFO - 2023-07-01 16:45:36 --> Model Class Initialized
INFO - 2023-07-01 16:45:36 --> Model Class Initialized
INFO - 2023-07-01 16:45:36 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-07-01 16:45:36 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-07-01 16:45:36 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-07-01 16:45:36 --> Final output sent to browser
DEBUG - 2023-07-01 16:45:36 --> Total execution time: 0.0675
ERROR - 2023-07-01 16:45:37 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-01 16:45:37 --> Config Class Initialized
INFO - 2023-07-01 16:45:37 --> Hooks Class Initialized
DEBUG - 2023-07-01 16:45:37 --> UTF-8 Support Enabled
INFO - 2023-07-01 16:45:37 --> Utf8 Class Initialized
INFO - 2023-07-01 16:45:37 --> URI Class Initialized
INFO - 2023-07-01 16:45:37 --> Router Class Initialized
INFO - 2023-07-01 16:45:37 --> Output Class Initialized
INFO - 2023-07-01 16:45:37 --> Security Class Initialized
DEBUG - 2023-07-01 16:45:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-01 16:45:37 --> Input Class Initialized
INFO - 2023-07-01 16:45:37 --> Language Class Initialized
INFO - 2023-07-01 16:45:37 --> Loader Class Initialized
INFO - 2023-07-01 16:45:37 --> Helper loaded: url_helper
INFO - 2023-07-01 16:45:37 --> Helper loaded: file_helper
INFO - 2023-07-01 16:45:37 --> Helper loaded: html_helper
INFO - 2023-07-01 16:45:37 --> Helper loaded: text_helper
INFO - 2023-07-01 16:45:37 --> Helper loaded: form_helper
INFO - 2023-07-01 16:45:37 --> Helper loaded: lang_helper
INFO - 2023-07-01 16:45:37 --> Helper loaded: security_helper
INFO - 2023-07-01 16:45:37 --> Helper loaded: cookie_helper
INFO - 2023-07-01 16:45:37 --> Database Driver Class Initialized
INFO - 2023-07-01 16:45:37 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-01 16:45:37 --> Parser Class Initialized
INFO - 2023-07-01 16:45:37 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-01 16:45:37 --> Pagination Class Initialized
INFO - 2023-07-01 16:45:37 --> Form Validation Class Initialized
INFO - 2023-07-01 16:45:37 --> Controller Class Initialized
INFO - 2023-07-01 16:45:37 --> Model Class Initialized
DEBUG - 2023-07-01 16:45:37 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-01 16:45:37 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-01 16:45:37 --> Model Class Initialized
DEBUG - 2023-07-01 16:45:37 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-01 16:45:37 --> Model Class Initialized
INFO - 2023-07-01 16:45:37 --> Final output sent to browser
DEBUG - 2023-07-01 16:45:37 --> Total execution time: 0.0256
ERROR - 2023-07-01 16:45:44 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-01 16:45:44 --> Config Class Initialized
INFO - 2023-07-01 16:45:44 --> Hooks Class Initialized
DEBUG - 2023-07-01 16:45:44 --> UTF-8 Support Enabled
INFO - 2023-07-01 16:45:44 --> Utf8 Class Initialized
INFO - 2023-07-01 16:45:44 --> URI Class Initialized
INFO - 2023-07-01 16:45:44 --> Router Class Initialized
INFO - 2023-07-01 16:45:44 --> Output Class Initialized
INFO - 2023-07-01 16:45:44 --> Security Class Initialized
DEBUG - 2023-07-01 16:45:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-01 16:45:44 --> Input Class Initialized
INFO - 2023-07-01 16:45:44 --> Language Class Initialized
INFO - 2023-07-01 16:45:44 --> Loader Class Initialized
INFO - 2023-07-01 16:45:44 --> Helper loaded: url_helper
INFO - 2023-07-01 16:45:44 --> Helper loaded: file_helper
INFO - 2023-07-01 16:45:44 --> Helper loaded: html_helper
INFO - 2023-07-01 16:45:44 --> Helper loaded: text_helper
INFO - 2023-07-01 16:45:44 --> Helper loaded: form_helper
INFO - 2023-07-01 16:45:44 --> Helper loaded: lang_helper
INFO - 2023-07-01 16:45:44 --> Helper loaded: security_helper
INFO - 2023-07-01 16:45:44 --> Helper loaded: cookie_helper
INFO - 2023-07-01 16:45:44 --> Database Driver Class Initialized
INFO - 2023-07-01 16:45:44 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-01 16:45:44 --> Parser Class Initialized
INFO - 2023-07-01 16:45:44 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-01 16:45:44 --> Pagination Class Initialized
INFO - 2023-07-01 16:45:44 --> Form Validation Class Initialized
INFO - 2023-07-01 16:45:44 --> Controller Class Initialized
INFO - 2023-07-01 16:45:44 --> Model Class Initialized
DEBUG - 2023-07-01 16:45:44 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-01 16:45:44 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-01 16:45:44 --> Model Class Initialized
DEBUG - 2023-07-01 16:45:44 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-01 16:45:44 --> Model Class Initialized
DEBUG - 2023-07-01 16:45:44 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-01 16:45:44 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice_html.php
DEBUG - 2023-07-01 16:45:44 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-07-01 16:45:44 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-07-01 16:45:44 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-07-01 16:45:44 --> Model Class Initialized
INFO - 2023-07-01 16:45:44 --> Model Class Initialized
INFO - 2023-07-01 16:45:44 --> Model Class Initialized
INFO - 2023-07-01 16:45:44 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-07-01 16:45:44 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-07-01 16:45:44 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-07-01 16:45:44 --> Final output sent to browser
DEBUG - 2023-07-01 16:45:44 --> Total execution time: 0.0674
ERROR - 2023-07-01 16:46:07 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-01 16:46:07 --> Config Class Initialized
INFO - 2023-07-01 16:46:07 --> Hooks Class Initialized
DEBUG - 2023-07-01 16:46:07 --> UTF-8 Support Enabled
INFO - 2023-07-01 16:46:07 --> Utf8 Class Initialized
INFO - 2023-07-01 16:46:07 --> URI Class Initialized
INFO - 2023-07-01 16:46:07 --> Router Class Initialized
INFO - 2023-07-01 16:46:07 --> Output Class Initialized
INFO - 2023-07-01 16:46:07 --> Security Class Initialized
DEBUG - 2023-07-01 16:46:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-01 16:46:07 --> Input Class Initialized
INFO - 2023-07-01 16:46:07 --> Language Class Initialized
INFO - 2023-07-01 16:46:07 --> Loader Class Initialized
INFO - 2023-07-01 16:46:07 --> Helper loaded: url_helper
INFO - 2023-07-01 16:46:07 --> Helper loaded: file_helper
INFO - 2023-07-01 16:46:07 --> Helper loaded: html_helper
INFO - 2023-07-01 16:46:07 --> Helper loaded: text_helper
INFO - 2023-07-01 16:46:07 --> Helper loaded: form_helper
INFO - 2023-07-01 16:46:07 --> Helper loaded: lang_helper
INFO - 2023-07-01 16:46:07 --> Helper loaded: security_helper
INFO - 2023-07-01 16:46:07 --> Helper loaded: cookie_helper
INFO - 2023-07-01 16:46:07 --> Database Driver Class Initialized
INFO - 2023-07-01 16:46:07 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-01 16:46:07 --> Parser Class Initialized
INFO - 2023-07-01 16:46:07 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-01 16:46:07 --> Pagination Class Initialized
INFO - 2023-07-01 16:46:07 --> Form Validation Class Initialized
INFO - 2023-07-01 16:46:07 --> Controller Class Initialized
INFO - 2023-07-01 16:46:07 --> Model Class Initialized
DEBUG - 2023-07-01 16:46:07 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-01 16:46:07 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-01 16:46:07 --> Model Class Initialized
DEBUG - 2023-07-01 16:46:07 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-01 16:46:07 --> Model Class Initialized
INFO - 2023-07-01 16:46:08 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice.php
DEBUG - 2023-07-01 16:46:08 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-07-01 16:46:08 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-07-01 16:46:08 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-07-01 16:46:08 --> Model Class Initialized
INFO - 2023-07-01 16:46:08 --> Model Class Initialized
INFO - 2023-07-01 16:46:08 --> Model Class Initialized
INFO - 2023-07-01 16:46:08 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-07-01 16:46:08 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-07-01 16:46:08 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-07-01 16:46:08 --> Final output sent to browser
DEBUG - 2023-07-01 16:46:08 --> Total execution time: 0.1554
ERROR - 2023-07-01 16:46:08 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-01 16:46:08 --> Config Class Initialized
INFO - 2023-07-01 16:46:08 --> Hooks Class Initialized
DEBUG - 2023-07-01 16:46:08 --> UTF-8 Support Enabled
INFO - 2023-07-01 16:46:08 --> Utf8 Class Initialized
INFO - 2023-07-01 16:46:08 --> URI Class Initialized
INFO - 2023-07-01 16:46:08 --> Router Class Initialized
INFO - 2023-07-01 16:46:08 --> Output Class Initialized
INFO - 2023-07-01 16:46:08 --> Security Class Initialized
DEBUG - 2023-07-01 16:46:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-01 16:46:08 --> Input Class Initialized
INFO - 2023-07-01 16:46:08 --> Language Class Initialized
INFO - 2023-07-01 16:46:08 --> Loader Class Initialized
INFO - 2023-07-01 16:46:08 --> Helper loaded: url_helper
INFO - 2023-07-01 16:46:08 --> Helper loaded: file_helper
INFO - 2023-07-01 16:46:08 --> Helper loaded: html_helper
INFO - 2023-07-01 16:46:08 --> Helper loaded: text_helper
INFO - 2023-07-01 16:46:08 --> Helper loaded: form_helper
INFO - 2023-07-01 16:46:08 --> Helper loaded: lang_helper
INFO - 2023-07-01 16:46:08 --> Helper loaded: security_helper
INFO - 2023-07-01 16:46:08 --> Helper loaded: cookie_helper
INFO - 2023-07-01 16:46:08 --> Database Driver Class Initialized
INFO - 2023-07-01 16:46:08 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-01 16:46:08 --> Parser Class Initialized
INFO - 2023-07-01 16:46:08 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-01 16:46:08 --> Pagination Class Initialized
INFO - 2023-07-01 16:46:08 --> Form Validation Class Initialized
INFO - 2023-07-01 16:46:08 --> Controller Class Initialized
INFO - 2023-07-01 16:46:08 --> Model Class Initialized
DEBUG - 2023-07-01 16:46:08 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-01 16:46:08 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-01 16:46:08 --> Model Class Initialized
DEBUG - 2023-07-01 16:46:08 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-01 16:46:08 --> Model Class Initialized
INFO - 2023-07-01 16:46:08 --> Final output sent to browser
DEBUG - 2023-07-01 16:46:08 --> Total execution time: 0.0724
ERROR - 2023-07-01 16:46:13 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-01 16:46:13 --> Config Class Initialized
INFO - 2023-07-01 16:46:13 --> Hooks Class Initialized
DEBUG - 2023-07-01 16:46:13 --> UTF-8 Support Enabled
INFO - 2023-07-01 16:46:13 --> Utf8 Class Initialized
INFO - 2023-07-01 16:46:13 --> URI Class Initialized
INFO - 2023-07-01 16:46:13 --> Router Class Initialized
INFO - 2023-07-01 16:46:13 --> Output Class Initialized
INFO - 2023-07-01 16:46:13 --> Security Class Initialized
DEBUG - 2023-07-01 16:46:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-01 16:46:13 --> Input Class Initialized
INFO - 2023-07-01 16:46:13 --> Language Class Initialized
INFO - 2023-07-01 16:46:13 --> Loader Class Initialized
INFO - 2023-07-01 16:46:13 --> Helper loaded: url_helper
INFO - 2023-07-01 16:46:13 --> Helper loaded: file_helper
INFO - 2023-07-01 16:46:13 --> Helper loaded: html_helper
INFO - 2023-07-01 16:46:13 --> Helper loaded: text_helper
INFO - 2023-07-01 16:46:13 --> Helper loaded: form_helper
INFO - 2023-07-01 16:46:13 --> Helper loaded: lang_helper
INFO - 2023-07-01 16:46:13 --> Helper loaded: security_helper
INFO - 2023-07-01 16:46:13 --> Helper loaded: cookie_helper
INFO - 2023-07-01 16:46:13 --> Database Driver Class Initialized
INFO - 2023-07-01 16:46:13 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-01 16:46:13 --> Parser Class Initialized
INFO - 2023-07-01 16:46:13 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-01 16:46:13 --> Pagination Class Initialized
INFO - 2023-07-01 16:46:13 --> Form Validation Class Initialized
INFO - 2023-07-01 16:46:13 --> Controller Class Initialized
INFO - 2023-07-01 16:46:13 --> Model Class Initialized
DEBUG - 2023-07-01 16:46:13 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-01 16:46:13 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-01 16:46:13 --> Model Class Initialized
DEBUG - 2023-07-01 16:46:13 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-01 16:46:13 --> Model Class Initialized
DEBUG - 2023-07-01 16:46:13 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-01 16:46:13 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice_html.php
DEBUG - 2023-07-01 16:46:13 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-07-01 16:46:13 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-07-01 16:46:13 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-07-01 16:46:13 --> Model Class Initialized
INFO - 2023-07-01 16:46:13 --> Model Class Initialized
INFO - 2023-07-01 16:46:13 --> Model Class Initialized
INFO - 2023-07-01 16:46:13 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-07-01 16:46:13 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-07-01 16:46:13 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-07-01 16:46:13 --> Final output sent to browser
DEBUG - 2023-07-01 16:46:13 --> Total execution time: 0.1811
ERROR - 2023-07-01 16:46:19 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-01 16:46:19 --> Config Class Initialized
INFO - 2023-07-01 16:46:19 --> Hooks Class Initialized
DEBUG - 2023-07-01 16:46:19 --> UTF-8 Support Enabled
INFO - 2023-07-01 16:46:19 --> Utf8 Class Initialized
INFO - 2023-07-01 16:46:19 --> URI Class Initialized
INFO - 2023-07-01 16:46:19 --> Router Class Initialized
INFO - 2023-07-01 16:46:19 --> Output Class Initialized
INFO - 2023-07-01 16:46:19 --> Security Class Initialized
DEBUG - 2023-07-01 16:46:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-01 16:46:19 --> Input Class Initialized
INFO - 2023-07-01 16:46:19 --> Language Class Initialized
INFO - 2023-07-01 16:46:19 --> Loader Class Initialized
INFO - 2023-07-01 16:46:19 --> Helper loaded: url_helper
INFO - 2023-07-01 16:46:19 --> Helper loaded: file_helper
INFO - 2023-07-01 16:46:19 --> Helper loaded: html_helper
INFO - 2023-07-01 16:46:19 --> Helper loaded: text_helper
INFO - 2023-07-01 16:46:19 --> Helper loaded: form_helper
INFO - 2023-07-01 16:46:19 --> Helper loaded: lang_helper
INFO - 2023-07-01 16:46:19 --> Helper loaded: security_helper
INFO - 2023-07-01 16:46:19 --> Helper loaded: cookie_helper
INFO - 2023-07-01 16:46:19 --> Database Driver Class Initialized
INFO - 2023-07-01 16:46:19 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-01 16:46:19 --> Parser Class Initialized
INFO - 2023-07-01 16:46:19 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-01 16:46:19 --> Pagination Class Initialized
INFO - 2023-07-01 16:46:19 --> Form Validation Class Initialized
INFO - 2023-07-01 16:46:19 --> Controller Class Initialized
INFO - 2023-07-01 16:46:19 --> Model Class Initialized
DEBUG - 2023-07-01 16:46:19 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-01 16:46:19 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-01 16:46:19 --> Model Class Initialized
DEBUG - 2023-07-01 16:46:19 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-01 16:46:19 --> Model Class Initialized
INFO - 2023-07-01 16:46:19 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice.php
DEBUG - 2023-07-01 16:46:19 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-07-01 16:46:19 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-07-01 16:46:19 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-07-01 16:46:19 --> Model Class Initialized
INFO - 2023-07-01 16:46:19 --> Model Class Initialized
INFO - 2023-07-01 16:46:19 --> Model Class Initialized
INFO - 2023-07-01 16:46:19 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-07-01 16:46:19 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-07-01 16:46:19 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-07-01 16:46:19 --> Final output sent to browser
DEBUG - 2023-07-01 16:46:19 --> Total execution time: 0.1444
ERROR - 2023-07-01 16:46:19 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-01 16:46:19 --> Config Class Initialized
INFO - 2023-07-01 16:46:19 --> Hooks Class Initialized
DEBUG - 2023-07-01 16:46:19 --> UTF-8 Support Enabled
INFO - 2023-07-01 16:46:19 --> Utf8 Class Initialized
INFO - 2023-07-01 16:46:19 --> URI Class Initialized
INFO - 2023-07-01 16:46:19 --> Router Class Initialized
INFO - 2023-07-01 16:46:19 --> Output Class Initialized
INFO - 2023-07-01 16:46:19 --> Security Class Initialized
DEBUG - 2023-07-01 16:46:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-01 16:46:19 --> Input Class Initialized
INFO - 2023-07-01 16:46:19 --> Language Class Initialized
INFO - 2023-07-01 16:46:19 --> Loader Class Initialized
INFO - 2023-07-01 16:46:19 --> Helper loaded: url_helper
INFO - 2023-07-01 16:46:19 --> Helper loaded: file_helper
INFO - 2023-07-01 16:46:19 --> Helper loaded: html_helper
INFO - 2023-07-01 16:46:19 --> Helper loaded: text_helper
INFO - 2023-07-01 16:46:19 --> Helper loaded: form_helper
INFO - 2023-07-01 16:46:19 --> Helper loaded: lang_helper
INFO - 2023-07-01 16:46:19 --> Helper loaded: security_helper
INFO - 2023-07-01 16:46:19 --> Helper loaded: cookie_helper
INFO - 2023-07-01 16:46:19 --> Database Driver Class Initialized
INFO - 2023-07-01 16:46:19 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-01 16:46:19 --> Parser Class Initialized
INFO - 2023-07-01 16:46:19 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-01 16:46:19 --> Pagination Class Initialized
INFO - 2023-07-01 16:46:19 --> Form Validation Class Initialized
INFO - 2023-07-01 16:46:19 --> Controller Class Initialized
INFO - 2023-07-01 16:46:19 --> Model Class Initialized
DEBUG - 2023-07-01 16:46:19 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-01 16:46:19 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-01 16:46:19 --> Model Class Initialized
DEBUG - 2023-07-01 16:46:19 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-01 16:46:19 --> Model Class Initialized
INFO - 2023-07-01 16:46:20 --> Final output sent to browser
DEBUG - 2023-07-01 16:46:20 --> Total execution time: 0.0608
ERROR - 2023-07-01 16:46:25 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-01 16:46:25 --> Config Class Initialized
INFO - 2023-07-01 16:46:25 --> Hooks Class Initialized
DEBUG - 2023-07-01 16:46:25 --> UTF-8 Support Enabled
INFO - 2023-07-01 16:46:25 --> Utf8 Class Initialized
INFO - 2023-07-01 16:46:25 --> URI Class Initialized
INFO - 2023-07-01 16:46:25 --> Router Class Initialized
INFO - 2023-07-01 16:46:25 --> Output Class Initialized
INFO - 2023-07-01 16:46:25 --> Security Class Initialized
DEBUG - 2023-07-01 16:46:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-01 16:46:25 --> Input Class Initialized
INFO - 2023-07-01 16:46:25 --> Language Class Initialized
INFO - 2023-07-01 16:46:25 --> Loader Class Initialized
INFO - 2023-07-01 16:46:25 --> Helper loaded: url_helper
INFO - 2023-07-01 16:46:25 --> Helper loaded: file_helper
INFO - 2023-07-01 16:46:25 --> Helper loaded: html_helper
INFO - 2023-07-01 16:46:25 --> Helper loaded: text_helper
INFO - 2023-07-01 16:46:25 --> Helper loaded: form_helper
INFO - 2023-07-01 16:46:25 --> Helper loaded: lang_helper
INFO - 2023-07-01 16:46:25 --> Helper loaded: security_helper
INFO - 2023-07-01 16:46:25 --> Helper loaded: cookie_helper
INFO - 2023-07-01 16:46:25 --> Database Driver Class Initialized
INFO - 2023-07-01 16:46:25 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-01 16:46:25 --> Parser Class Initialized
INFO - 2023-07-01 16:46:25 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-01 16:46:25 --> Pagination Class Initialized
INFO - 2023-07-01 16:46:25 --> Form Validation Class Initialized
INFO - 2023-07-01 16:46:25 --> Controller Class Initialized
INFO - 2023-07-01 16:46:25 --> Model Class Initialized
DEBUG - 2023-07-01 16:46:25 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-01 16:46:25 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-01 16:46:25 --> Model Class Initialized
DEBUG - 2023-07-01 16:46:25 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-01 16:46:25 --> Model Class Initialized
DEBUG - 2023-07-01 16:46:25 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-01 16:46:25 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice_html.php
DEBUG - 2023-07-01 16:46:25 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-07-01 16:46:25 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-07-01 16:46:25 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-07-01 16:46:25 --> Model Class Initialized
INFO - 2023-07-01 16:46:25 --> Model Class Initialized
INFO - 2023-07-01 16:46:25 --> Model Class Initialized
INFO - 2023-07-01 16:46:25 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-07-01 16:46:25 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-07-01 16:46:25 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-07-01 16:46:25 --> Final output sent to browser
DEBUG - 2023-07-01 16:46:25 --> Total execution time: 0.1483
ERROR - 2023-07-01 16:47:37 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-01 16:47:37 --> Config Class Initialized
INFO - 2023-07-01 16:47:37 --> Hooks Class Initialized
DEBUG - 2023-07-01 16:47:37 --> UTF-8 Support Enabled
INFO - 2023-07-01 16:47:37 --> Utf8 Class Initialized
INFO - 2023-07-01 16:47:37 --> URI Class Initialized
INFO - 2023-07-01 16:47:37 --> Router Class Initialized
INFO - 2023-07-01 16:47:37 --> Output Class Initialized
INFO - 2023-07-01 16:47:37 --> Security Class Initialized
DEBUG - 2023-07-01 16:47:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-01 16:47:37 --> Input Class Initialized
INFO - 2023-07-01 16:47:37 --> Language Class Initialized
INFO - 2023-07-01 16:47:37 --> Loader Class Initialized
INFO - 2023-07-01 16:47:37 --> Helper loaded: url_helper
INFO - 2023-07-01 16:47:37 --> Helper loaded: file_helper
INFO - 2023-07-01 16:47:37 --> Helper loaded: html_helper
INFO - 2023-07-01 16:47:37 --> Helper loaded: text_helper
INFO - 2023-07-01 16:47:37 --> Helper loaded: form_helper
INFO - 2023-07-01 16:47:37 --> Helper loaded: lang_helper
INFO - 2023-07-01 16:47:37 --> Helper loaded: security_helper
INFO - 2023-07-01 16:47:37 --> Helper loaded: cookie_helper
INFO - 2023-07-01 16:47:37 --> Database Driver Class Initialized
INFO - 2023-07-01 16:47:37 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-01 16:47:37 --> Parser Class Initialized
INFO - 2023-07-01 16:47:37 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-01 16:47:37 --> Pagination Class Initialized
INFO - 2023-07-01 16:47:37 --> Form Validation Class Initialized
INFO - 2023-07-01 16:47:37 --> Controller Class Initialized
INFO - 2023-07-01 16:47:37 --> Model Class Initialized
DEBUG - 2023-07-01 16:47:37 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-01 16:47:37 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-01 16:47:37 --> Model Class Initialized
DEBUG - 2023-07-01 16:47:37 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-01 16:47:37 --> Model Class Initialized
INFO - 2023-07-01 16:47:37 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice.php
DEBUG - 2023-07-01 16:47:37 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-07-01 16:47:37 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-07-01 16:47:37 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-07-01 16:47:37 --> Model Class Initialized
INFO - 2023-07-01 16:47:37 --> Model Class Initialized
INFO - 2023-07-01 16:47:37 --> Model Class Initialized
INFO - 2023-07-01 16:47:38 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-07-01 16:47:38 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-07-01 16:47:38 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-07-01 16:47:38 --> Final output sent to browser
DEBUG - 2023-07-01 16:47:38 --> Total execution time: 0.1291
ERROR - 2023-07-01 16:47:38 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-01 16:47:38 --> Config Class Initialized
INFO - 2023-07-01 16:47:38 --> Hooks Class Initialized
DEBUG - 2023-07-01 16:47:38 --> UTF-8 Support Enabled
INFO - 2023-07-01 16:47:38 --> Utf8 Class Initialized
INFO - 2023-07-01 16:47:38 --> URI Class Initialized
INFO - 2023-07-01 16:47:38 --> Router Class Initialized
INFO - 2023-07-01 16:47:38 --> Output Class Initialized
INFO - 2023-07-01 16:47:38 --> Security Class Initialized
DEBUG - 2023-07-01 16:47:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-01 16:47:38 --> Input Class Initialized
INFO - 2023-07-01 16:47:38 --> Language Class Initialized
INFO - 2023-07-01 16:47:38 --> Loader Class Initialized
INFO - 2023-07-01 16:47:38 --> Helper loaded: url_helper
INFO - 2023-07-01 16:47:38 --> Helper loaded: file_helper
INFO - 2023-07-01 16:47:38 --> Helper loaded: html_helper
INFO - 2023-07-01 16:47:38 --> Helper loaded: text_helper
INFO - 2023-07-01 16:47:38 --> Helper loaded: form_helper
INFO - 2023-07-01 16:47:38 --> Helper loaded: lang_helper
INFO - 2023-07-01 16:47:38 --> Helper loaded: security_helper
INFO - 2023-07-01 16:47:38 --> Helper loaded: cookie_helper
INFO - 2023-07-01 16:47:38 --> Database Driver Class Initialized
INFO - 2023-07-01 16:47:38 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-01 16:47:38 --> Parser Class Initialized
INFO - 2023-07-01 16:47:38 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-01 16:47:38 --> Pagination Class Initialized
INFO - 2023-07-01 16:47:38 --> Form Validation Class Initialized
INFO - 2023-07-01 16:47:38 --> Controller Class Initialized
INFO - 2023-07-01 16:47:38 --> Model Class Initialized
DEBUG - 2023-07-01 16:47:38 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-01 16:47:38 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-01 16:47:38 --> Model Class Initialized
DEBUG - 2023-07-01 16:47:38 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-01 16:47:38 --> Model Class Initialized
INFO - 2023-07-01 16:47:38 --> Final output sent to browser
DEBUG - 2023-07-01 16:47:38 --> Total execution time: 0.0547
ERROR - 2023-07-01 16:47:42 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-01 16:47:42 --> Config Class Initialized
INFO - 2023-07-01 16:47:42 --> Hooks Class Initialized
DEBUG - 2023-07-01 16:47:42 --> UTF-8 Support Enabled
INFO - 2023-07-01 16:47:42 --> Utf8 Class Initialized
INFO - 2023-07-01 16:47:42 --> URI Class Initialized
INFO - 2023-07-01 16:47:42 --> Router Class Initialized
INFO - 2023-07-01 16:47:42 --> Output Class Initialized
INFO - 2023-07-01 16:47:42 --> Security Class Initialized
DEBUG - 2023-07-01 16:47:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-01 16:47:42 --> Input Class Initialized
INFO - 2023-07-01 16:47:42 --> Language Class Initialized
INFO - 2023-07-01 16:47:42 --> Loader Class Initialized
INFO - 2023-07-01 16:47:42 --> Helper loaded: url_helper
INFO - 2023-07-01 16:47:42 --> Helper loaded: file_helper
INFO - 2023-07-01 16:47:42 --> Helper loaded: html_helper
INFO - 2023-07-01 16:47:42 --> Helper loaded: text_helper
INFO - 2023-07-01 16:47:42 --> Helper loaded: form_helper
INFO - 2023-07-01 16:47:42 --> Helper loaded: lang_helper
INFO - 2023-07-01 16:47:42 --> Helper loaded: security_helper
INFO - 2023-07-01 16:47:42 --> Helper loaded: cookie_helper
INFO - 2023-07-01 16:47:42 --> Database Driver Class Initialized
INFO - 2023-07-01 16:47:42 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-01 16:47:42 --> Parser Class Initialized
INFO - 2023-07-01 16:47:42 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-01 16:47:42 --> Pagination Class Initialized
INFO - 2023-07-01 16:47:42 --> Form Validation Class Initialized
INFO - 2023-07-01 16:47:42 --> Controller Class Initialized
INFO - 2023-07-01 16:47:42 --> Model Class Initialized
DEBUG - 2023-07-01 16:47:42 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-01 16:47:42 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-01 16:47:42 --> Model Class Initialized
DEBUG - 2023-07-01 16:47:42 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-01 16:47:42 --> Model Class Initialized
DEBUG - 2023-07-01 16:47:42 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-01 16:47:42 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice_html.php
DEBUG - 2023-07-01 16:47:42 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-07-01 16:47:42 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-07-01 16:47:42 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-07-01 16:47:42 --> Model Class Initialized
INFO - 2023-07-01 16:47:42 --> Model Class Initialized
INFO - 2023-07-01 16:47:42 --> Model Class Initialized
INFO - 2023-07-01 16:47:42 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-07-01 16:47:42 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-07-01 16:47:42 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-07-01 16:47:42 --> Final output sent to browser
DEBUG - 2023-07-01 16:47:42 --> Total execution time: 0.1247
ERROR - 2023-07-01 16:47:59 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-01 16:47:59 --> Config Class Initialized
INFO - 2023-07-01 16:47:59 --> Hooks Class Initialized
DEBUG - 2023-07-01 16:47:59 --> UTF-8 Support Enabled
INFO - 2023-07-01 16:47:59 --> Utf8 Class Initialized
INFO - 2023-07-01 16:47:59 --> URI Class Initialized
INFO - 2023-07-01 16:47:59 --> Router Class Initialized
INFO - 2023-07-01 16:47:59 --> Output Class Initialized
INFO - 2023-07-01 16:47:59 --> Security Class Initialized
DEBUG - 2023-07-01 16:47:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-01 16:47:59 --> Input Class Initialized
INFO - 2023-07-01 16:47:59 --> Language Class Initialized
INFO - 2023-07-01 16:47:59 --> Loader Class Initialized
INFO - 2023-07-01 16:47:59 --> Helper loaded: url_helper
INFO - 2023-07-01 16:47:59 --> Helper loaded: file_helper
INFO - 2023-07-01 16:47:59 --> Helper loaded: html_helper
INFO - 2023-07-01 16:47:59 --> Helper loaded: text_helper
INFO - 2023-07-01 16:47:59 --> Helper loaded: form_helper
INFO - 2023-07-01 16:47:59 --> Helper loaded: lang_helper
INFO - 2023-07-01 16:47:59 --> Helper loaded: security_helper
INFO - 2023-07-01 16:47:59 --> Helper loaded: cookie_helper
INFO - 2023-07-01 16:47:59 --> Database Driver Class Initialized
INFO - 2023-07-01 16:47:59 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-01 16:47:59 --> Parser Class Initialized
INFO - 2023-07-01 16:47:59 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-01 16:47:59 --> Pagination Class Initialized
INFO - 2023-07-01 16:47:59 --> Form Validation Class Initialized
INFO - 2023-07-01 16:47:59 --> Controller Class Initialized
INFO - 2023-07-01 16:47:59 --> Model Class Initialized
DEBUG - 2023-07-01 16:47:59 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-01 16:47:59 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-01 16:47:59 --> Model Class Initialized
DEBUG - 2023-07-01 16:47:59 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-01 16:47:59 --> Model Class Initialized
INFO - 2023-07-01 16:47:59 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice.php
DEBUG - 2023-07-01 16:47:59 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-07-01 16:47:59 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-07-01 16:47:59 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-07-01 16:47:59 --> Model Class Initialized
INFO - 2023-07-01 16:47:59 --> Model Class Initialized
INFO - 2023-07-01 16:47:59 --> Model Class Initialized
INFO - 2023-07-01 16:48:00 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-07-01 16:48:00 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-07-01 16:48:00 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-07-01 16:48:00 --> Final output sent to browser
DEBUG - 2023-07-01 16:48:00 --> Total execution time: 0.1311
ERROR - 2023-07-01 16:48:00 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-01 16:48:00 --> Config Class Initialized
INFO - 2023-07-01 16:48:00 --> Hooks Class Initialized
DEBUG - 2023-07-01 16:48:00 --> UTF-8 Support Enabled
INFO - 2023-07-01 16:48:00 --> Utf8 Class Initialized
INFO - 2023-07-01 16:48:00 --> URI Class Initialized
INFO - 2023-07-01 16:48:00 --> Router Class Initialized
INFO - 2023-07-01 16:48:00 --> Output Class Initialized
INFO - 2023-07-01 16:48:00 --> Security Class Initialized
DEBUG - 2023-07-01 16:48:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-01 16:48:00 --> Input Class Initialized
INFO - 2023-07-01 16:48:00 --> Language Class Initialized
INFO - 2023-07-01 16:48:00 --> Loader Class Initialized
INFO - 2023-07-01 16:48:00 --> Helper loaded: url_helper
INFO - 2023-07-01 16:48:00 --> Helper loaded: file_helper
INFO - 2023-07-01 16:48:00 --> Helper loaded: html_helper
INFO - 2023-07-01 16:48:00 --> Helper loaded: text_helper
INFO - 2023-07-01 16:48:00 --> Helper loaded: form_helper
INFO - 2023-07-01 16:48:00 --> Helper loaded: lang_helper
INFO - 2023-07-01 16:48:00 --> Helper loaded: security_helper
INFO - 2023-07-01 16:48:00 --> Helper loaded: cookie_helper
INFO - 2023-07-01 16:48:00 --> Database Driver Class Initialized
INFO - 2023-07-01 16:48:00 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-01 16:48:00 --> Parser Class Initialized
INFO - 2023-07-01 16:48:00 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-01 16:48:00 --> Pagination Class Initialized
INFO - 2023-07-01 16:48:00 --> Form Validation Class Initialized
INFO - 2023-07-01 16:48:00 --> Controller Class Initialized
INFO - 2023-07-01 16:48:00 --> Model Class Initialized
DEBUG - 2023-07-01 16:48:00 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-01 16:48:00 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-01 16:48:00 --> Model Class Initialized
DEBUG - 2023-07-01 16:48:00 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-01 16:48:00 --> Model Class Initialized
INFO - 2023-07-01 16:48:00 --> Final output sent to browser
DEBUG - 2023-07-01 16:48:00 --> Total execution time: 0.0533
ERROR - 2023-07-01 16:48:03 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-01 16:48:03 --> Config Class Initialized
INFO - 2023-07-01 16:48:03 --> Hooks Class Initialized
DEBUG - 2023-07-01 16:48:03 --> UTF-8 Support Enabled
INFO - 2023-07-01 16:48:03 --> Utf8 Class Initialized
INFO - 2023-07-01 16:48:03 --> URI Class Initialized
INFO - 2023-07-01 16:48:03 --> Router Class Initialized
INFO - 2023-07-01 16:48:03 --> Output Class Initialized
INFO - 2023-07-01 16:48:03 --> Security Class Initialized
DEBUG - 2023-07-01 16:48:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-01 16:48:03 --> Input Class Initialized
INFO - 2023-07-01 16:48:03 --> Language Class Initialized
INFO - 2023-07-01 16:48:03 --> Loader Class Initialized
INFO - 2023-07-01 16:48:03 --> Helper loaded: url_helper
INFO - 2023-07-01 16:48:03 --> Helper loaded: file_helper
INFO - 2023-07-01 16:48:03 --> Helper loaded: html_helper
INFO - 2023-07-01 16:48:03 --> Helper loaded: text_helper
INFO - 2023-07-01 16:48:03 --> Helper loaded: form_helper
INFO - 2023-07-01 16:48:03 --> Helper loaded: lang_helper
INFO - 2023-07-01 16:48:03 --> Helper loaded: security_helper
INFO - 2023-07-01 16:48:03 --> Helper loaded: cookie_helper
INFO - 2023-07-01 16:48:03 --> Database Driver Class Initialized
INFO - 2023-07-01 16:48:03 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-01 16:48:03 --> Parser Class Initialized
INFO - 2023-07-01 16:48:03 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-01 16:48:03 --> Pagination Class Initialized
INFO - 2023-07-01 16:48:03 --> Form Validation Class Initialized
INFO - 2023-07-01 16:48:03 --> Controller Class Initialized
INFO - 2023-07-01 16:48:03 --> Model Class Initialized
DEBUG - 2023-07-01 16:48:03 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-01 16:48:03 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-01 16:48:03 --> Model Class Initialized
DEBUG - 2023-07-01 16:48:03 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-01 16:48:03 --> Model Class Initialized
DEBUG - 2023-07-01 16:48:03 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-01 16:48:03 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice_html.php
DEBUG - 2023-07-01 16:48:03 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-07-01 16:48:03 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-07-01 16:48:03 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-07-01 16:48:03 --> Model Class Initialized
INFO - 2023-07-01 16:48:03 --> Model Class Initialized
INFO - 2023-07-01 16:48:03 --> Model Class Initialized
INFO - 2023-07-01 16:48:04 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-07-01 16:48:04 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-07-01 16:48:04 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-07-01 16:48:04 --> Final output sent to browser
DEBUG - 2023-07-01 16:48:04 --> Total execution time: 0.1525
ERROR - 2023-07-01 17:05:04 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-01 17:05:04 --> Config Class Initialized
INFO - 2023-07-01 17:05:04 --> Hooks Class Initialized
DEBUG - 2023-07-01 17:05:04 --> UTF-8 Support Enabled
INFO - 2023-07-01 17:05:04 --> Utf8 Class Initialized
INFO - 2023-07-01 17:05:04 --> URI Class Initialized
DEBUG - 2023-07-01 17:05:04 --> No URI present. Default controller set.
INFO - 2023-07-01 17:05:04 --> Router Class Initialized
INFO - 2023-07-01 17:05:04 --> Output Class Initialized
INFO - 2023-07-01 17:05:04 --> Security Class Initialized
DEBUG - 2023-07-01 17:05:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-01 17:05:04 --> Input Class Initialized
INFO - 2023-07-01 17:05:04 --> Language Class Initialized
INFO - 2023-07-01 17:05:04 --> Loader Class Initialized
INFO - 2023-07-01 17:05:04 --> Helper loaded: url_helper
INFO - 2023-07-01 17:05:04 --> Helper loaded: file_helper
INFO - 2023-07-01 17:05:04 --> Helper loaded: html_helper
INFO - 2023-07-01 17:05:04 --> Helper loaded: text_helper
INFO - 2023-07-01 17:05:04 --> Helper loaded: form_helper
INFO - 2023-07-01 17:05:04 --> Helper loaded: lang_helper
INFO - 2023-07-01 17:05:05 --> Helper loaded: security_helper
INFO - 2023-07-01 17:05:05 --> Helper loaded: cookie_helper
INFO - 2023-07-01 17:05:05 --> Database Driver Class Initialized
INFO - 2023-07-01 17:05:05 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-01 17:05:05 --> Parser Class Initialized
INFO - 2023-07-01 17:05:05 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-01 17:05:05 --> Pagination Class Initialized
INFO - 2023-07-01 17:05:05 --> Form Validation Class Initialized
INFO - 2023-07-01 17:05:05 --> Controller Class Initialized
INFO - 2023-07-01 17:05:05 --> Model Class Initialized
DEBUG - 2023-07-01 17:05:05 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-01 17:05:05 --> Model Class Initialized
DEBUG - 2023-07-01 17:05:05 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-01 17:05:05 --> Model Class Initialized
INFO - 2023-07-01 17:05:05 --> Model Class Initialized
INFO - 2023-07-01 17:05:05 --> Model Class Initialized
INFO - 2023-07-01 17:05:05 --> Model Class Initialized
DEBUG - 2023-07-01 17:05:05 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-01 17:05:05 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-01 17:05:05 --> Model Class Initialized
INFO - 2023-07-01 17:05:05 --> Model Class Initialized
INFO - 2023-07-01 17:05:05 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-07-01 17:05:05 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-07-01 17:05:05 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-07-01 17:05:05 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-07-01 17:05:05 --> Model Class Initialized
INFO - 2023-07-01 17:05:05 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-07-01 17:05:05 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-07-01 17:05:05 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-07-01 17:05:05 --> Final output sent to browser
DEBUG - 2023-07-01 17:05:05 --> Total execution time: 0.1874
ERROR - 2023-07-01 17:09:34 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-01 17:09:34 --> Config Class Initialized
INFO - 2023-07-01 17:09:34 --> Hooks Class Initialized
DEBUG - 2023-07-01 17:09:34 --> UTF-8 Support Enabled
INFO - 2023-07-01 17:09:34 --> Utf8 Class Initialized
INFO - 2023-07-01 17:09:34 --> URI Class Initialized
INFO - 2023-07-01 17:09:34 --> Router Class Initialized
INFO - 2023-07-01 17:09:34 --> Output Class Initialized
INFO - 2023-07-01 17:09:34 --> Security Class Initialized
DEBUG - 2023-07-01 17:09:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-01 17:09:34 --> Input Class Initialized
INFO - 2023-07-01 17:09:34 --> Language Class Initialized
INFO - 2023-07-01 17:09:34 --> Loader Class Initialized
INFO - 2023-07-01 17:09:34 --> Helper loaded: url_helper
INFO - 2023-07-01 17:09:34 --> Helper loaded: file_helper
INFO - 2023-07-01 17:09:34 --> Helper loaded: html_helper
INFO - 2023-07-01 17:09:34 --> Helper loaded: text_helper
INFO - 2023-07-01 17:09:34 --> Helper loaded: form_helper
INFO - 2023-07-01 17:09:34 --> Helper loaded: lang_helper
INFO - 2023-07-01 17:09:34 --> Helper loaded: security_helper
INFO - 2023-07-01 17:09:34 --> Helper loaded: cookie_helper
INFO - 2023-07-01 17:09:34 --> Database Driver Class Initialized
INFO - 2023-07-01 17:09:34 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-01 17:09:34 --> Parser Class Initialized
INFO - 2023-07-01 17:09:34 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-01 17:09:34 --> Pagination Class Initialized
INFO - 2023-07-01 17:09:34 --> Form Validation Class Initialized
INFO - 2023-07-01 17:09:34 --> Controller Class Initialized
DEBUG - 2023-07-01 17:09:34 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-01 17:09:34 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-01 17:09:34 --> Model Class Initialized
DEBUG - 2023-07-01 17:09:34 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-01 17:09:34 --> Model Class Initialized
DEBUG - 2023-07-01 17:09:34 --> Lcustomer class already loaded. Second attempt ignored.
INFO - 2023-07-01 17:09:34 --> Model Class Initialized
INFO - 2023-07-01 17:09:34 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/customer/customer.php
DEBUG - 2023-07-01 17:09:34 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-07-01 17:09:34 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-07-01 17:09:34 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-07-01 17:09:34 --> Model Class Initialized
INFO - 2023-07-01 17:09:34 --> Model Class Initialized
INFO - 2023-07-01 17:09:34 --> Model Class Initialized
INFO - 2023-07-01 17:09:34 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-07-01 17:09:34 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-07-01 17:09:34 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-07-01 17:09:34 --> Final output sent to browser
DEBUG - 2023-07-01 17:09:34 --> Total execution time: 0.0688
ERROR - 2023-07-01 17:09:34 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-01 17:09:34 --> Config Class Initialized
INFO - 2023-07-01 17:09:34 --> Hooks Class Initialized
DEBUG - 2023-07-01 17:09:34 --> UTF-8 Support Enabled
INFO - 2023-07-01 17:09:34 --> Utf8 Class Initialized
INFO - 2023-07-01 17:09:34 --> URI Class Initialized
INFO - 2023-07-01 17:09:34 --> Router Class Initialized
INFO - 2023-07-01 17:09:34 --> Output Class Initialized
INFO - 2023-07-01 17:09:34 --> Security Class Initialized
DEBUG - 2023-07-01 17:09:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-01 17:09:34 --> Input Class Initialized
INFO - 2023-07-01 17:09:34 --> Language Class Initialized
INFO - 2023-07-01 17:09:34 --> Loader Class Initialized
INFO - 2023-07-01 17:09:34 --> Helper loaded: url_helper
INFO - 2023-07-01 17:09:34 --> Helper loaded: file_helper
INFO - 2023-07-01 17:09:34 --> Helper loaded: html_helper
INFO - 2023-07-01 17:09:34 --> Helper loaded: text_helper
INFO - 2023-07-01 17:09:34 --> Helper loaded: form_helper
INFO - 2023-07-01 17:09:34 --> Helper loaded: lang_helper
INFO - 2023-07-01 17:09:34 --> Helper loaded: security_helper
INFO - 2023-07-01 17:09:34 --> Helper loaded: cookie_helper
INFO - 2023-07-01 17:09:34 --> Database Driver Class Initialized
INFO - 2023-07-01 17:09:34 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-01 17:09:34 --> Parser Class Initialized
INFO - 2023-07-01 17:09:34 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-01 17:09:34 --> Pagination Class Initialized
INFO - 2023-07-01 17:09:34 --> Form Validation Class Initialized
INFO - 2023-07-01 17:09:34 --> Controller Class Initialized
DEBUG - 2023-07-01 17:09:34 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-01 17:09:34 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-01 17:09:34 --> Model Class Initialized
DEBUG - 2023-07-01 17:09:34 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-01 17:09:34 --> Model Class Initialized
INFO - 2023-07-01 17:09:34 --> Final output sent to browser
DEBUG - 2023-07-01 17:09:34 --> Total execution time: 0.0206
ERROR - 2023-07-01 17:09:40 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-01 17:09:40 --> Config Class Initialized
INFO - 2023-07-01 17:09:40 --> Hooks Class Initialized
DEBUG - 2023-07-01 17:09:40 --> UTF-8 Support Enabled
INFO - 2023-07-01 17:09:40 --> Utf8 Class Initialized
INFO - 2023-07-01 17:09:40 --> URI Class Initialized
INFO - 2023-07-01 17:09:40 --> Router Class Initialized
INFO - 2023-07-01 17:09:40 --> Output Class Initialized
INFO - 2023-07-01 17:09:40 --> Security Class Initialized
DEBUG - 2023-07-01 17:09:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-01 17:09:40 --> Input Class Initialized
INFO - 2023-07-01 17:09:40 --> Language Class Initialized
INFO - 2023-07-01 17:09:40 --> Loader Class Initialized
INFO - 2023-07-01 17:09:40 --> Helper loaded: url_helper
INFO - 2023-07-01 17:09:40 --> Helper loaded: file_helper
INFO - 2023-07-01 17:09:40 --> Helper loaded: html_helper
INFO - 2023-07-01 17:09:40 --> Helper loaded: text_helper
INFO - 2023-07-01 17:09:40 --> Helper loaded: form_helper
INFO - 2023-07-01 17:09:40 --> Helper loaded: lang_helper
INFO - 2023-07-01 17:09:40 --> Helper loaded: security_helper
INFO - 2023-07-01 17:09:40 --> Helper loaded: cookie_helper
INFO - 2023-07-01 17:09:40 --> Database Driver Class Initialized
INFO - 2023-07-01 17:09:40 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-01 17:09:40 --> Parser Class Initialized
INFO - 2023-07-01 17:09:40 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-01 17:09:40 --> Pagination Class Initialized
INFO - 2023-07-01 17:09:40 --> Form Validation Class Initialized
INFO - 2023-07-01 17:09:40 --> Controller Class Initialized
DEBUG - 2023-07-01 17:09:40 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-01 17:09:40 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-01 17:09:40 --> Model Class Initialized
DEBUG - 2023-07-01 17:09:40 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-01 17:09:40 --> Model Class Initialized
INFO - 2023-07-01 17:09:40 --> Final output sent to browser
DEBUG - 2023-07-01 17:09:40 --> Total execution time: 0.0307
ERROR - 2023-07-01 17:09:59 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-01 17:09:59 --> Config Class Initialized
INFO - 2023-07-01 17:09:59 --> Hooks Class Initialized
DEBUG - 2023-07-01 17:09:59 --> UTF-8 Support Enabled
INFO - 2023-07-01 17:09:59 --> Utf8 Class Initialized
INFO - 2023-07-01 17:09:59 --> URI Class Initialized
INFO - 2023-07-01 17:09:59 --> Router Class Initialized
INFO - 2023-07-01 17:09:59 --> Output Class Initialized
INFO - 2023-07-01 17:09:59 --> Security Class Initialized
DEBUG - 2023-07-01 17:09:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-01 17:09:59 --> Input Class Initialized
INFO - 2023-07-01 17:09:59 --> Language Class Initialized
INFO - 2023-07-01 17:09:59 --> Loader Class Initialized
INFO - 2023-07-01 17:09:59 --> Helper loaded: url_helper
INFO - 2023-07-01 17:09:59 --> Helper loaded: file_helper
INFO - 2023-07-01 17:09:59 --> Helper loaded: html_helper
INFO - 2023-07-01 17:09:59 --> Helper loaded: text_helper
INFO - 2023-07-01 17:09:59 --> Helper loaded: form_helper
INFO - 2023-07-01 17:09:59 --> Helper loaded: lang_helper
INFO - 2023-07-01 17:09:59 --> Helper loaded: security_helper
INFO - 2023-07-01 17:09:59 --> Helper loaded: cookie_helper
INFO - 2023-07-01 17:09:59 --> Database Driver Class Initialized
INFO - 2023-07-01 17:09:59 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-01 17:09:59 --> Parser Class Initialized
INFO - 2023-07-01 17:09:59 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-01 17:09:59 --> Pagination Class Initialized
INFO - 2023-07-01 17:09:59 --> Form Validation Class Initialized
INFO - 2023-07-01 17:09:59 --> Controller Class Initialized
INFO - 2023-07-01 17:09:59 --> Model Class Initialized
DEBUG - 2023-07-01 17:09:59 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-01 17:09:59 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-01 17:09:59 --> Model Class Initialized
DEBUG - 2023-07-01 17:09:59 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-01 17:09:59 --> Model Class Initialized
INFO - 2023-07-01 17:09:59 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice.php
DEBUG - 2023-07-01 17:09:59 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-07-01 17:09:59 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-07-01 17:09:59 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-07-01 17:09:59 --> Model Class Initialized
INFO - 2023-07-01 17:09:59 --> Model Class Initialized
INFO - 2023-07-01 17:09:59 --> Model Class Initialized
INFO - 2023-07-01 17:09:59 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-07-01 17:09:59 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-07-01 17:09:59 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-07-01 17:09:59 --> Final output sent to browser
DEBUG - 2023-07-01 17:09:59 --> Total execution time: 0.0652
ERROR - 2023-07-01 17:09:59 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-01 17:09:59 --> Config Class Initialized
INFO - 2023-07-01 17:09:59 --> Hooks Class Initialized
DEBUG - 2023-07-01 17:09:59 --> UTF-8 Support Enabled
INFO - 2023-07-01 17:09:59 --> Utf8 Class Initialized
INFO - 2023-07-01 17:09:59 --> URI Class Initialized
INFO - 2023-07-01 17:09:59 --> Router Class Initialized
INFO - 2023-07-01 17:09:59 --> Output Class Initialized
INFO - 2023-07-01 17:09:59 --> Security Class Initialized
DEBUG - 2023-07-01 17:09:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-01 17:09:59 --> Input Class Initialized
INFO - 2023-07-01 17:09:59 --> Language Class Initialized
INFO - 2023-07-01 17:09:59 --> Loader Class Initialized
INFO - 2023-07-01 17:09:59 --> Helper loaded: url_helper
INFO - 2023-07-01 17:09:59 --> Helper loaded: file_helper
INFO - 2023-07-01 17:09:59 --> Helper loaded: html_helper
INFO - 2023-07-01 17:09:59 --> Helper loaded: text_helper
INFO - 2023-07-01 17:09:59 --> Helper loaded: form_helper
INFO - 2023-07-01 17:09:59 --> Helper loaded: lang_helper
INFO - 2023-07-01 17:09:59 --> Helper loaded: security_helper
INFO - 2023-07-01 17:09:59 --> Helper loaded: cookie_helper
INFO - 2023-07-01 17:09:59 --> Database Driver Class Initialized
INFO - 2023-07-01 17:09:59 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-01 17:09:59 --> Parser Class Initialized
INFO - 2023-07-01 17:09:59 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-01 17:09:59 --> Pagination Class Initialized
INFO - 2023-07-01 17:09:59 --> Form Validation Class Initialized
INFO - 2023-07-01 17:09:59 --> Controller Class Initialized
INFO - 2023-07-01 17:09:59 --> Model Class Initialized
DEBUG - 2023-07-01 17:09:59 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-01 17:09:59 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-01 17:09:59 --> Model Class Initialized
DEBUG - 2023-07-01 17:09:59 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-01 17:09:59 --> Model Class Initialized
INFO - 2023-07-01 17:09:59 --> Final output sent to browser
DEBUG - 2023-07-01 17:09:59 --> Total execution time: 0.0259
ERROR - 2023-07-01 17:10:03 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-01 17:10:03 --> Config Class Initialized
INFO - 2023-07-01 17:10:03 --> Hooks Class Initialized
DEBUG - 2023-07-01 17:10:03 --> UTF-8 Support Enabled
INFO - 2023-07-01 17:10:03 --> Utf8 Class Initialized
INFO - 2023-07-01 17:10:03 --> URI Class Initialized
INFO - 2023-07-01 17:10:03 --> Router Class Initialized
INFO - 2023-07-01 17:10:03 --> Output Class Initialized
INFO - 2023-07-01 17:10:03 --> Security Class Initialized
DEBUG - 2023-07-01 17:10:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-01 17:10:03 --> Input Class Initialized
INFO - 2023-07-01 17:10:03 --> Language Class Initialized
INFO - 2023-07-01 17:10:03 --> Loader Class Initialized
INFO - 2023-07-01 17:10:03 --> Helper loaded: url_helper
INFO - 2023-07-01 17:10:03 --> Helper loaded: file_helper
INFO - 2023-07-01 17:10:03 --> Helper loaded: html_helper
INFO - 2023-07-01 17:10:03 --> Helper loaded: text_helper
INFO - 2023-07-01 17:10:03 --> Helper loaded: form_helper
INFO - 2023-07-01 17:10:03 --> Helper loaded: lang_helper
INFO - 2023-07-01 17:10:03 --> Helper loaded: security_helper
INFO - 2023-07-01 17:10:03 --> Helper loaded: cookie_helper
INFO - 2023-07-01 17:10:03 --> Database Driver Class Initialized
INFO - 2023-07-01 17:10:03 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-01 17:10:03 --> Parser Class Initialized
INFO - 2023-07-01 17:10:03 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-01 17:10:03 --> Pagination Class Initialized
INFO - 2023-07-01 17:10:03 --> Form Validation Class Initialized
INFO - 2023-07-01 17:10:03 --> Controller Class Initialized
INFO - 2023-07-01 17:10:03 --> Model Class Initialized
DEBUG - 2023-07-01 17:10:03 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-01 17:10:03 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-01 17:10:03 --> Model Class Initialized
DEBUG - 2023-07-01 17:10:03 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-01 17:10:03 --> Model Class Initialized
DEBUG - 2023-07-01 17:10:03 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-01 17:10:03 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice_html.php
DEBUG - 2023-07-01 17:10:03 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-07-01 17:10:03 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-07-01 17:10:03 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-07-01 17:10:03 --> Model Class Initialized
INFO - 2023-07-01 17:10:03 --> Model Class Initialized
INFO - 2023-07-01 17:10:03 --> Model Class Initialized
INFO - 2023-07-01 17:10:03 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-07-01 17:10:03 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-07-01 17:10:03 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-07-01 17:10:03 --> Final output sent to browser
DEBUG - 2023-07-01 17:10:03 --> Total execution time: 0.0647
ERROR - 2023-07-01 17:10:11 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-01 17:10:11 --> Config Class Initialized
INFO - 2023-07-01 17:10:11 --> Hooks Class Initialized
DEBUG - 2023-07-01 17:10:11 --> UTF-8 Support Enabled
INFO - 2023-07-01 17:10:11 --> Utf8 Class Initialized
INFO - 2023-07-01 17:10:11 --> URI Class Initialized
INFO - 2023-07-01 17:10:11 --> Router Class Initialized
INFO - 2023-07-01 17:10:11 --> Output Class Initialized
INFO - 2023-07-01 17:10:11 --> Security Class Initialized
DEBUG - 2023-07-01 17:10:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-01 17:10:11 --> Input Class Initialized
INFO - 2023-07-01 17:10:11 --> Language Class Initialized
INFO - 2023-07-01 17:10:11 --> Loader Class Initialized
INFO - 2023-07-01 17:10:11 --> Helper loaded: url_helper
INFO - 2023-07-01 17:10:11 --> Helper loaded: file_helper
INFO - 2023-07-01 17:10:11 --> Helper loaded: html_helper
INFO - 2023-07-01 17:10:11 --> Helper loaded: text_helper
INFO - 2023-07-01 17:10:11 --> Helper loaded: form_helper
INFO - 2023-07-01 17:10:11 --> Helper loaded: lang_helper
INFO - 2023-07-01 17:10:11 --> Helper loaded: security_helper
INFO - 2023-07-01 17:10:11 --> Helper loaded: cookie_helper
INFO - 2023-07-01 17:10:11 --> Database Driver Class Initialized
INFO - 2023-07-01 17:10:11 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-01 17:10:11 --> Parser Class Initialized
INFO - 2023-07-01 17:10:11 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-01 17:10:11 --> Pagination Class Initialized
INFO - 2023-07-01 17:10:11 --> Form Validation Class Initialized
INFO - 2023-07-01 17:10:11 --> Controller Class Initialized
INFO - 2023-07-01 17:10:11 --> Model Class Initialized
DEBUG - 2023-07-01 17:10:11 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-01 17:10:11 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-01 17:10:11 --> Model Class Initialized
DEBUG - 2023-07-01 17:10:11 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-01 17:10:11 --> Model Class Initialized
INFO - 2023-07-01 17:10:11 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice.php
DEBUG - 2023-07-01 17:10:11 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-07-01 17:10:11 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-07-01 17:10:11 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-07-01 17:10:11 --> Model Class Initialized
INFO - 2023-07-01 17:10:11 --> Model Class Initialized
INFO - 2023-07-01 17:10:11 --> Model Class Initialized
INFO - 2023-07-01 17:10:11 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-07-01 17:10:11 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-07-01 17:10:11 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-07-01 17:10:11 --> Final output sent to browser
DEBUG - 2023-07-01 17:10:11 --> Total execution time: 0.0718
ERROR - 2023-07-01 17:10:11 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-01 17:10:11 --> Config Class Initialized
INFO - 2023-07-01 17:10:11 --> Hooks Class Initialized
DEBUG - 2023-07-01 17:10:11 --> UTF-8 Support Enabled
INFO - 2023-07-01 17:10:11 --> Utf8 Class Initialized
INFO - 2023-07-01 17:10:11 --> URI Class Initialized
INFO - 2023-07-01 17:10:11 --> Router Class Initialized
INFO - 2023-07-01 17:10:11 --> Output Class Initialized
INFO - 2023-07-01 17:10:11 --> Security Class Initialized
DEBUG - 2023-07-01 17:10:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-01 17:10:11 --> Input Class Initialized
INFO - 2023-07-01 17:10:11 --> Language Class Initialized
INFO - 2023-07-01 17:10:11 --> Loader Class Initialized
INFO - 2023-07-01 17:10:11 --> Helper loaded: url_helper
INFO - 2023-07-01 17:10:11 --> Helper loaded: file_helper
INFO - 2023-07-01 17:10:11 --> Helper loaded: html_helper
INFO - 2023-07-01 17:10:11 --> Helper loaded: text_helper
INFO - 2023-07-01 17:10:11 --> Helper loaded: form_helper
INFO - 2023-07-01 17:10:11 --> Helper loaded: lang_helper
INFO - 2023-07-01 17:10:11 --> Helper loaded: security_helper
INFO - 2023-07-01 17:10:11 --> Helper loaded: cookie_helper
INFO - 2023-07-01 17:10:11 --> Database Driver Class Initialized
INFO - 2023-07-01 17:10:11 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-01 17:10:11 --> Parser Class Initialized
INFO - 2023-07-01 17:10:11 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-01 17:10:11 --> Pagination Class Initialized
INFO - 2023-07-01 17:10:11 --> Form Validation Class Initialized
INFO - 2023-07-01 17:10:11 --> Controller Class Initialized
INFO - 2023-07-01 17:10:11 --> Model Class Initialized
DEBUG - 2023-07-01 17:10:11 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-01 17:10:11 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-01 17:10:11 --> Model Class Initialized
DEBUG - 2023-07-01 17:10:11 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-01 17:10:11 --> Model Class Initialized
INFO - 2023-07-01 17:10:11 --> Final output sent to browser
DEBUG - 2023-07-01 17:10:11 --> Total execution time: 0.0258
ERROR - 2023-07-01 17:10:14 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-01 17:10:14 --> Config Class Initialized
INFO - 2023-07-01 17:10:14 --> Hooks Class Initialized
DEBUG - 2023-07-01 17:10:14 --> UTF-8 Support Enabled
INFO - 2023-07-01 17:10:14 --> Utf8 Class Initialized
INFO - 2023-07-01 17:10:14 --> URI Class Initialized
INFO - 2023-07-01 17:10:14 --> Router Class Initialized
INFO - 2023-07-01 17:10:14 --> Output Class Initialized
INFO - 2023-07-01 17:10:14 --> Security Class Initialized
DEBUG - 2023-07-01 17:10:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-01 17:10:14 --> Input Class Initialized
INFO - 2023-07-01 17:10:14 --> Language Class Initialized
INFO - 2023-07-01 17:10:14 --> Loader Class Initialized
INFO - 2023-07-01 17:10:14 --> Helper loaded: url_helper
INFO - 2023-07-01 17:10:14 --> Helper loaded: file_helper
INFO - 2023-07-01 17:10:14 --> Helper loaded: html_helper
INFO - 2023-07-01 17:10:14 --> Helper loaded: text_helper
INFO - 2023-07-01 17:10:14 --> Helper loaded: form_helper
INFO - 2023-07-01 17:10:14 --> Helper loaded: lang_helper
INFO - 2023-07-01 17:10:14 --> Helper loaded: security_helper
INFO - 2023-07-01 17:10:14 --> Helper loaded: cookie_helper
INFO - 2023-07-01 17:10:14 --> Database Driver Class Initialized
INFO - 2023-07-01 17:10:14 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-01 17:10:14 --> Parser Class Initialized
INFO - 2023-07-01 17:10:14 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-01 17:10:14 --> Pagination Class Initialized
INFO - 2023-07-01 17:10:14 --> Form Validation Class Initialized
INFO - 2023-07-01 17:10:14 --> Controller Class Initialized
INFO - 2023-07-01 17:10:14 --> Model Class Initialized
DEBUG - 2023-07-01 17:10:14 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-01 17:10:14 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-01 17:10:14 --> Model Class Initialized
DEBUG - 2023-07-01 17:10:14 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-01 17:10:14 --> Model Class Initialized
DEBUG - 2023-07-01 17:10:14 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-01 17:10:14 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice_html.php
DEBUG - 2023-07-01 17:10:14 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-07-01 17:10:14 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-07-01 17:10:14 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-07-01 17:10:14 --> Model Class Initialized
INFO - 2023-07-01 17:10:14 --> Model Class Initialized
INFO - 2023-07-01 17:10:14 --> Model Class Initialized
INFO - 2023-07-01 17:10:14 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-07-01 17:10:14 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-07-01 17:10:14 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-07-01 17:10:14 --> Final output sent to browser
DEBUG - 2023-07-01 17:10:14 --> Total execution time: 0.0651
ERROR - 2023-07-01 17:10:22 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-01 17:10:22 --> Config Class Initialized
INFO - 2023-07-01 17:10:22 --> Hooks Class Initialized
DEBUG - 2023-07-01 17:10:22 --> UTF-8 Support Enabled
INFO - 2023-07-01 17:10:22 --> Utf8 Class Initialized
INFO - 2023-07-01 17:10:22 --> URI Class Initialized
INFO - 2023-07-01 17:10:22 --> Router Class Initialized
INFO - 2023-07-01 17:10:22 --> Output Class Initialized
INFO - 2023-07-01 17:10:22 --> Security Class Initialized
DEBUG - 2023-07-01 17:10:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-01 17:10:22 --> Input Class Initialized
INFO - 2023-07-01 17:10:22 --> Language Class Initialized
INFO - 2023-07-01 17:10:22 --> Loader Class Initialized
INFO - 2023-07-01 17:10:22 --> Helper loaded: url_helper
INFO - 2023-07-01 17:10:22 --> Helper loaded: file_helper
INFO - 2023-07-01 17:10:22 --> Helper loaded: html_helper
INFO - 2023-07-01 17:10:22 --> Helper loaded: text_helper
INFO - 2023-07-01 17:10:22 --> Helper loaded: form_helper
INFO - 2023-07-01 17:10:22 --> Helper loaded: lang_helper
INFO - 2023-07-01 17:10:22 --> Helper loaded: security_helper
INFO - 2023-07-01 17:10:22 --> Helper loaded: cookie_helper
INFO - 2023-07-01 17:10:22 --> Database Driver Class Initialized
INFO - 2023-07-01 17:10:22 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-01 17:10:22 --> Parser Class Initialized
INFO - 2023-07-01 17:10:22 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-01 17:10:22 --> Pagination Class Initialized
INFO - 2023-07-01 17:10:22 --> Form Validation Class Initialized
INFO - 2023-07-01 17:10:22 --> Controller Class Initialized
INFO - 2023-07-01 17:10:22 --> Model Class Initialized
DEBUG - 2023-07-01 17:10:22 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-01 17:10:22 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-01 17:10:22 --> Model Class Initialized
DEBUG - 2023-07-01 17:10:22 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-01 17:10:22 --> Model Class Initialized
INFO - 2023-07-01 17:10:22 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice.php
DEBUG - 2023-07-01 17:10:22 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-07-01 17:10:22 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-07-01 17:10:22 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-07-01 17:10:22 --> Model Class Initialized
INFO - 2023-07-01 17:10:22 --> Model Class Initialized
INFO - 2023-07-01 17:10:22 --> Model Class Initialized
INFO - 2023-07-01 17:10:22 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-07-01 17:10:22 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-07-01 17:10:22 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-07-01 17:10:22 --> Final output sent to browser
DEBUG - 2023-07-01 17:10:22 --> Total execution time: 0.0564
ERROR - 2023-07-01 17:10:23 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-01 17:10:23 --> Config Class Initialized
INFO - 2023-07-01 17:10:23 --> Hooks Class Initialized
DEBUG - 2023-07-01 17:10:23 --> UTF-8 Support Enabled
INFO - 2023-07-01 17:10:23 --> Utf8 Class Initialized
INFO - 2023-07-01 17:10:23 --> URI Class Initialized
INFO - 2023-07-01 17:10:23 --> Router Class Initialized
INFO - 2023-07-01 17:10:23 --> Output Class Initialized
INFO - 2023-07-01 17:10:23 --> Security Class Initialized
DEBUG - 2023-07-01 17:10:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-01 17:10:23 --> Input Class Initialized
INFO - 2023-07-01 17:10:23 --> Language Class Initialized
INFO - 2023-07-01 17:10:23 --> Loader Class Initialized
INFO - 2023-07-01 17:10:23 --> Helper loaded: url_helper
INFO - 2023-07-01 17:10:23 --> Helper loaded: file_helper
INFO - 2023-07-01 17:10:23 --> Helper loaded: html_helper
INFO - 2023-07-01 17:10:23 --> Helper loaded: text_helper
INFO - 2023-07-01 17:10:23 --> Helper loaded: form_helper
INFO - 2023-07-01 17:10:23 --> Helper loaded: lang_helper
INFO - 2023-07-01 17:10:23 --> Helper loaded: security_helper
INFO - 2023-07-01 17:10:23 --> Helper loaded: cookie_helper
INFO - 2023-07-01 17:10:23 --> Database Driver Class Initialized
INFO - 2023-07-01 17:10:23 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-01 17:10:23 --> Parser Class Initialized
INFO - 2023-07-01 17:10:23 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-01 17:10:23 --> Pagination Class Initialized
INFO - 2023-07-01 17:10:23 --> Form Validation Class Initialized
INFO - 2023-07-01 17:10:23 --> Controller Class Initialized
INFO - 2023-07-01 17:10:23 --> Model Class Initialized
DEBUG - 2023-07-01 17:10:23 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-01 17:10:23 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-01 17:10:23 --> Model Class Initialized
DEBUG - 2023-07-01 17:10:23 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-01 17:10:23 --> Model Class Initialized
INFO - 2023-07-01 17:10:23 --> Final output sent to browser
DEBUG - 2023-07-01 17:10:23 --> Total execution time: 0.0256
ERROR - 2023-07-01 17:10:26 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-01 17:10:26 --> Config Class Initialized
INFO - 2023-07-01 17:10:26 --> Hooks Class Initialized
DEBUG - 2023-07-01 17:10:26 --> UTF-8 Support Enabled
INFO - 2023-07-01 17:10:26 --> Utf8 Class Initialized
INFO - 2023-07-01 17:10:26 --> URI Class Initialized
INFO - 2023-07-01 17:10:26 --> Router Class Initialized
INFO - 2023-07-01 17:10:26 --> Output Class Initialized
INFO - 2023-07-01 17:10:26 --> Security Class Initialized
DEBUG - 2023-07-01 17:10:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-01 17:10:26 --> Input Class Initialized
INFO - 2023-07-01 17:10:26 --> Language Class Initialized
INFO - 2023-07-01 17:10:26 --> Loader Class Initialized
INFO - 2023-07-01 17:10:26 --> Helper loaded: url_helper
INFO - 2023-07-01 17:10:26 --> Helper loaded: file_helper
INFO - 2023-07-01 17:10:26 --> Helper loaded: html_helper
INFO - 2023-07-01 17:10:26 --> Helper loaded: text_helper
INFO - 2023-07-01 17:10:26 --> Helper loaded: form_helper
INFO - 2023-07-01 17:10:26 --> Helper loaded: lang_helper
INFO - 2023-07-01 17:10:26 --> Helper loaded: security_helper
INFO - 2023-07-01 17:10:26 --> Helper loaded: cookie_helper
INFO - 2023-07-01 17:10:26 --> Database Driver Class Initialized
INFO - 2023-07-01 17:10:26 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-01 17:10:26 --> Parser Class Initialized
INFO - 2023-07-01 17:10:26 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-01 17:10:26 --> Pagination Class Initialized
INFO - 2023-07-01 17:10:26 --> Form Validation Class Initialized
INFO - 2023-07-01 17:10:26 --> Controller Class Initialized
INFO - 2023-07-01 17:10:26 --> Model Class Initialized
DEBUG - 2023-07-01 17:10:26 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-01 17:10:26 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-01 17:10:26 --> Model Class Initialized
DEBUG - 2023-07-01 17:10:26 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-01 17:10:26 --> Model Class Initialized
DEBUG - 2023-07-01 17:10:26 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-01 17:10:26 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice_html.php
DEBUG - 2023-07-01 17:10:26 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-07-01 17:10:26 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-07-01 17:10:26 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-07-01 17:10:26 --> Model Class Initialized
INFO - 2023-07-01 17:10:26 --> Model Class Initialized
INFO - 2023-07-01 17:10:26 --> Model Class Initialized
INFO - 2023-07-01 17:10:26 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-07-01 17:10:26 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-07-01 17:10:26 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-07-01 17:10:26 --> Final output sent to browser
DEBUG - 2023-07-01 17:10:26 --> Total execution time: 0.0678
ERROR - 2023-07-01 17:11:01 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-01 17:11:01 --> Config Class Initialized
INFO - 2023-07-01 17:11:01 --> Hooks Class Initialized
DEBUG - 2023-07-01 17:11:01 --> UTF-8 Support Enabled
INFO - 2023-07-01 17:11:01 --> Utf8 Class Initialized
INFO - 2023-07-01 17:11:01 --> URI Class Initialized
INFO - 2023-07-01 17:11:01 --> Router Class Initialized
INFO - 2023-07-01 17:11:01 --> Output Class Initialized
INFO - 2023-07-01 17:11:01 --> Security Class Initialized
DEBUG - 2023-07-01 17:11:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-01 17:11:01 --> Input Class Initialized
INFO - 2023-07-01 17:11:01 --> Language Class Initialized
INFO - 2023-07-01 17:11:01 --> Loader Class Initialized
INFO - 2023-07-01 17:11:01 --> Helper loaded: url_helper
INFO - 2023-07-01 17:11:01 --> Helper loaded: file_helper
INFO - 2023-07-01 17:11:01 --> Helper loaded: html_helper
INFO - 2023-07-01 17:11:01 --> Helper loaded: text_helper
INFO - 2023-07-01 17:11:01 --> Helper loaded: form_helper
INFO - 2023-07-01 17:11:01 --> Helper loaded: lang_helper
INFO - 2023-07-01 17:11:01 --> Helper loaded: security_helper
INFO - 2023-07-01 17:11:01 --> Helper loaded: cookie_helper
INFO - 2023-07-01 17:11:01 --> Database Driver Class Initialized
INFO - 2023-07-01 17:11:01 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-01 17:11:01 --> Parser Class Initialized
INFO - 2023-07-01 17:11:01 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-01 17:11:01 --> Pagination Class Initialized
INFO - 2023-07-01 17:11:01 --> Form Validation Class Initialized
INFO - 2023-07-01 17:11:01 --> Controller Class Initialized
INFO - 2023-07-01 17:11:01 --> Model Class Initialized
DEBUG - 2023-07-01 17:11:01 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-01 17:11:01 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-01 17:11:01 --> Model Class Initialized
DEBUG - 2023-07-01 17:11:01 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-01 17:11:01 --> Model Class Initialized
INFO - 2023-07-01 17:11:01 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice.php
DEBUG - 2023-07-01 17:11:01 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-07-01 17:11:01 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-07-01 17:11:01 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-07-01 17:11:01 --> Model Class Initialized
INFO - 2023-07-01 17:11:01 --> Model Class Initialized
INFO - 2023-07-01 17:11:01 --> Model Class Initialized
INFO - 2023-07-01 17:11:01 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-07-01 17:11:01 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-07-01 17:11:01 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-07-01 17:11:01 --> Final output sent to browser
DEBUG - 2023-07-01 17:11:01 --> Total execution time: 0.0655
ERROR - 2023-07-01 17:11:02 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-01 17:11:02 --> Config Class Initialized
INFO - 2023-07-01 17:11:02 --> Hooks Class Initialized
DEBUG - 2023-07-01 17:11:02 --> UTF-8 Support Enabled
INFO - 2023-07-01 17:11:02 --> Utf8 Class Initialized
INFO - 2023-07-01 17:11:02 --> URI Class Initialized
INFO - 2023-07-01 17:11:02 --> Router Class Initialized
INFO - 2023-07-01 17:11:02 --> Output Class Initialized
INFO - 2023-07-01 17:11:02 --> Security Class Initialized
DEBUG - 2023-07-01 17:11:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-01 17:11:02 --> Input Class Initialized
INFO - 2023-07-01 17:11:02 --> Language Class Initialized
INFO - 2023-07-01 17:11:02 --> Loader Class Initialized
INFO - 2023-07-01 17:11:02 --> Helper loaded: url_helper
INFO - 2023-07-01 17:11:02 --> Helper loaded: file_helper
INFO - 2023-07-01 17:11:02 --> Helper loaded: html_helper
INFO - 2023-07-01 17:11:02 --> Helper loaded: text_helper
INFO - 2023-07-01 17:11:02 --> Helper loaded: form_helper
INFO - 2023-07-01 17:11:02 --> Helper loaded: lang_helper
INFO - 2023-07-01 17:11:02 --> Helper loaded: security_helper
INFO - 2023-07-01 17:11:02 --> Helper loaded: cookie_helper
INFO - 2023-07-01 17:11:02 --> Database Driver Class Initialized
INFO - 2023-07-01 17:11:02 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-01 17:11:02 --> Parser Class Initialized
INFO - 2023-07-01 17:11:02 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-01 17:11:02 --> Pagination Class Initialized
INFO - 2023-07-01 17:11:02 --> Form Validation Class Initialized
INFO - 2023-07-01 17:11:02 --> Controller Class Initialized
INFO - 2023-07-01 17:11:02 --> Model Class Initialized
DEBUG - 2023-07-01 17:11:02 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-01 17:11:02 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-01 17:11:02 --> Model Class Initialized
DEBUG - 2023-07-01 17:11:02 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-01 17:11:02 --> Model Class Initialized
INFO - 2023-07-01 17:11:02 --> Final output sent to browser
DEBUG - 2023-07-01 17:11:02 --> Total execution time: 0.0255
ERROR - 2023-07-01 17:11:05 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-01 17:11:05 --> Config Class Initialized
INFO - 2023-07-01 17:11:05 --> Hooks Class Initialized
DEBUG - 2023-07-01 17:11:05 --> UTF-8 Support Enabled
INFO - 2023-07-01 17:11:05 --> Utf8 Class Initialized
INFO - 2023-07-01 17:11:05 --> URI Class Initialized
INFO - 2023-07-01 17:11:05 --> Router Class Initialized
INFO - 2023-07-01 17:11:05 --> Output Class Initialized
INFO - 2023-07-01 17:11:05 --> Security Class Initialized
DEBUG - 2023-07-01 17:11:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-01 17:11:05 --> Input Class Initialized
INFO - 2023-07-01 17:11:05 --> Language Class Initialized
INFO - 2023-07-01 17:11:05 --> Loader Class Initialized
INFO - 2023-07-01 17:11:05 --> Helper loaded: url_helper
INFO - 2023-07-01 17:11:05 --> Helper loaded: file_helper
INFO - 2023-07-01 17:11:05 --> Helper loaded: html_helper
INFO - 2023-07-01 17:11:05 --> Helper loaded: text_helper
INFO - 2023-07-01 17:11:05 --> Helper loaded: form_helper
INFO - 2023-07-01 17:11:05 --> Helper loaded: lang_helper
INFO - 2023-07-01 17:11:05 --> Helper loaded: security_helper
INFO - 2023-07-01 17:11:05 --> Helper loaded: cookie_helper
INFO - 2023-07-01 17:11:05 --> Database Driver Class Initialized
INFO - 2023-07-01 17:11:05 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-01 17:11:05 --> Parser Class Initialized
INFO - 2023-07-01 17:11:05 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-01 17:11:05 --> Pagination Class Initialized
INFO - 2023-07-01 17:11:05 --> Form Validation Class Initialized
INFO - 2023-07-01 17:11:05 --> Controller Class Initialized
INFO - 2023-07-01 17:11:05 --> Model Class Initialized
DEBUG - 2023-07-01 17:11:05 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-01 17:11:05 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-01 17:11:05 --> Model Class Initialized
DEBUG - 2023-07-01 17:11:05 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-01 17:11:05 --> Model Class Initialized
DEBUG - 2023-07-01 17:11:05 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-01 17:11:05 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice_html.php
DEBUG - 2023-07-01 17:11:05 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-07-01 17:11:05 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-07-01 17:11:05 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-07-01 17:11:05 --> Model Class Initialized
INFO - 2023-07-01 17:11:05 --> Model Class Initialized
INFO - 2023-07-01 17:11:05 --> Model Class Initialized
INFO - 2023-07-01 17:11:05 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-07-01 17:11:05 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-07-01 17:11:05 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-07-01 17:11:05 --> Final output sent to browser
DEBUG - 2023-07-01 17:11:05 --> Total execution time: 0.0722
ERROR - 2023-07-01 17:11:26 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-01 17:11:26 --> Config Class Initialized
INFO - 2023-07-01 17:11:26 --> Hooks Class Initialized
DEBUG - 2023-07-01 17:11:26 --> UTF-8 Support Enabled
INFO - 2023-07-01 17:11:26 --> Utf8 Class Initialized
INFO - 2023-07-01 17:11:26 --> URI Class Initialized
DEBUG - 2023-07-01 17:11:26 --> No URI present. Default controller set.
INFO - 2023-07-01 17:11:26 --> Router Class Initialized
INFO - 2023-07-01 17:11:26 --> Output Class Initialized
INFO - 2023-07-01 17:11:26 --> Security Class Initialized
DEBUG - 2023-07-01 17:11:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-01 17:11:26 --> Input Class Initialized
INFO - 2023-07-01 17:11:26 --> Language Class Initialized
INFO - 2023-07-01 17:11:26 --> Loader Class Initialized
INFO - 2023-07-01 17:11:26 --> Helper loaded: url_helper
INFO - 2023-07-01 17:11:26 --> Helper loaded: file_helper
INFO - 2023-07-01 17:11:26 --> Helper loaded: html_helper
INFO - 2023-07-01 17:11:26 --> Helper loaded: text_helper
INFO - 2023-07-01 17:11:26 --> Helper loaded: form_helper
INFO - 2023-07-01 17:11:26 --> Helper loaded: lang_helper
INFO - 2023-07-01 17:11:26 --> Helper loaded: security_helper
INFO - 2023-07-01 17:11:26 --> Helper loaded: cookie_helper
INFO - 2023-07-01 17:11:26 --> Database Driver Class Initialized
INFO - 2023-07-01 17:11:26 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-01 17:11:26 --> Parser Class Initialized
INFO - 2023-07-01 17:11:26 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-01 17:11:26 --> Pagination Class Initialized
INFO - 2023-07-01 17:11:26 --> Form Validation Class Initialized
INFO - 2023-07-01 17:11:26 --> Controller Class Initialized
INFO - 2023-07-01 17:11:26 --> Model Class Initialized
DEBUG - 2023-07-01 17:11:26 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-01 17:11:26 --> Model Class Initialized
DEBUG - 2023-07-01 17:11:26 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-01 17:11:26 --> Model Class Initialized
INFO - 2023-07-01 17:11:26 --> Model Class Initialized
INFO - 2023-07-01 17:11:26 --> Model Class Initialized
INFO - 2023-07-01 17:11:26 --> Model Class Initialized
DEBUG - 2023-07-01 17:11:26 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-01 17:11:26 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-01 17:11:26 --> Model Class Initialized
INFO - 2023-07-01 17:11:26 --> Model Class Initialized
INFO - 2023-07-01 17:11:26 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-07-01 17:11:26 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-07-01 17:11:26 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-07-01 17:11:26 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-07-01 17:11:26 --> Model Class Initialized
INFO - 2023-07-01 17:11:26 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-07-01 17:11:26 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-07-01 17:11:26 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-07-01 17:11:26 --> Final output sent to browser
DEBUG - 2023-07-01 17:11:26 --> Total execution time: 0.0703
ERROR - 2023-07-01 17:11:27 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-01 17:11:27 --> Config Class Initialized
INFO - 2023-07-01 17:11:27 --> Hooks Class Initialized
DEBUG - 2023-07-01 17:11:27 --> UTF-8 Support Enabled
INFO - 2023-07-01 17:11:27 --> Utf8 Class Initialized
INFO - 2023-07-01 17:11:27 --> URI Class Initialized
INFO - 2023-07-01 17:11:27 --> Router Class Initialized
INFO - 2023-07-01 17:11:27 --> Output Class Initialized
INFO - 2023-07-01 17:11:27 --> Security Class Initialized
DEBUG - 2023-07-01 17:11:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-01 17:11:27 --> Input Class Initialized
INFO - 2023-07-01 17:11:27 --> Language Class Initialized
INFO - 2023-07-01 17:11:27 --> Loader Class Initialized
INFO - 2023-07-01 17:11:27 --> Helper loaded: url_helper
INFO - 2023-07-01 17:11:27 --> Helper loaded: file_helper
INFO - 2023-07-01 17:11:27 --> Helper loaded: html_helper
INFO - 2023-07-01 17:11:27 --> Helper loaded: text_helper
INFO - 2023-07-01 17:11:27 --> Helper loaded: form_helper
INFO - 2023-07-01 17:11:27 --> Helper loaded: lang_helper
INFO - 2023-07-01 17:11:27 --> Helper loaded: security_helper
INFO - 2023-07-01 17:11:27 --> Helper loaded: cookie_helper
INFO - 2023-07-01 17:11:27 --> Database Driver Class Initialized
INFO - 2023-07-01 17:11:27 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-01 17:11:27 --> Parser Class Initialized
INFO - 2023-07-01 17:11:27 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-01 17:11:27 --> Pagination Class Initialized
INFO - 2023-07-01 17:11:27 --> Form Validation Class Initialized
INFO - 2023-07-01 17:11:27 --> Controller Class Initialized
INFO - 2023-07-01 17:11:27 --> Model Class Initialized
DEBUG - 2023-07-01 17:11:27 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-01 17:11:27 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-01 17:11:27 --> Model Class Initialized
DEBUG - 2023-07-01 17:11:27 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-01 17:11:27 --> Model Class Initialized
DEBUG - 2023-07-01 17:11:27 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-01 17:11:27 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice_html.php
DEBUG - 2023-07-01 17:11:27 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-07-01 17:11:27 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-07-01 17:11:27 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-07-01 17:11:27 --> Model Class Initialized
INFO - 2023-07-01 17:11:27 --> Model Class Initialized
INFO - 2023-07-01 17:11:27 --> Model Class Initialized
INFO - 2023-07-01 17:11:27 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-07-01 17:11:27 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-07-01 17:11:27 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-07-01 17:11:27 --> Final output sent to browser
DEBUG - 2023-07-01 17:11:27 --> Total execution time: 0.0678
ERROR - 2023-07-01 17:37:31 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-01 17:37:31 --> Config Class Initialized
INFO - 2023-07-01 17:37:31 --> Hooks Class Initialized
DEBUG - 2023-07-01 17:37:31 --> UTF-8 Support Enabled
INFO - 2023-07-01 17:37:31 --> Utf8 Class Initialized
INFO - 2023-07-01 17:37:31 --> URI Class Initialized
DEBUG - 2023-07-01 17:37:31 --> No URI present. Default controller set.
INFO - 2023-07-01 17:37:31 --> Router Class Initialized
INFO - 2023-07-01 17:37:31 --> Output Class Initialized
INFO - 2023-07-01 17:37:31 --> Security Class Initialized
DEBUG - 2023-07-01 17:37:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-01 17:37:31 --> Input Class Initialized
INFO - 2023-07-01 17:37:31 --> Language Class Initialized
INFO - 2023-07-01 17:37:31 --> Loader Class Initialized
INFO - 2023-07-01 17:37:31 --> Helper loaded: url_helper
INFO - 2023-07-01 17:37:31 --> Helper loaded: file_helper
INFO - 2023-07-01 17:37:31 --> Helper loaded: html_helper
INFO - 2023-07-01 17:37:31 --> Helper loaded: text_helper
INFO - 2023-07-01 17:37:31 --> Helper loaded: form_helper
INFO - 2023-07-01 17:37:31 --> Helper loaded: lang_helper
INFO - 2023-07-01 17:37:31 --> Helper loaded: security_helper
INFO - 2023-07-01 17:37:31 --> Helper loaded: cookie_helper
INFO - 2023-07-01 17:37:31 --> Database Driver Class Initialized
INFO - 2023-07-01 17:37:31 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-01 17:37:31 --> Parser Class Initialized
INFO - 2023-07-01 17:37:31 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-01 17:37:31 --> Pagination Class Initialized
INFO - 2023-07-01 17:37:31 --> Form Validation Class Initialized
INFO - 2023-07-01 17:37:31 --> Controller Class Initialized
INFO - 2023-07-01 17:37:31 --> Model Class Initialized
DEBUG - 2023-07-01 17:37:31 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-01 17:37:31 --> Model Class Initialized
DEBUG - 2023-07-01 17:37:31 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-01 17:37:31 --> Model Class Initialized
INFO - 2023-07-01 17:37:31 --> Model Class Initialized
INFO - 2023-07-01 17:37:31 --> Model Class Initialized
INFO - 2023-07-01 17:37:31 --> Model Class Initialized
DEBUG - 2023-07-01 17:37:31 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-01 17:37:31 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-01 17:37:31 --> Model Class Initialized
INFO - 2023-07-01 17:37:31 --> Model Class Initialized
INFO - 2023-07-01 17:37:31 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-07-01 17:37:31 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-07-01 17:37:31 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-07-01 17:37:31 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-07-01 17:37:31 --> Model Class Initialized
INFO - 2023-07-01 17:37:31 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-07-01 17:37:31 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-07-01 17:37:31 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-07-01 17:37:31 --> Final output sent to browser
DEBUG - 2023-07-01 17:37:31 --> Total execution time: 0.1729
ERROR - 2023-07-01 17:37:41 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-01 17:37:41 --> Config Class Initialized
INFO - 2023-07-01 17:37:41 --> Hooks Class Initialized
DEBUG - 2023-07-01 17:37:41 --> UTF-8 Support Enabled
INFO - 2023-07-01 17:37:41 --> Utf8 Class Initialized
INFO - 2023-07-01 17:37:41 --> URI Class Initialized
INFO - 2023-07-01 17:37:41 --> Router Class Initialized
INFO - 2023-07-01 17:37:41 --> Output Class Initialized
INFO - 2023-07-01 17:37:41 --> Security Class Initialized
DEBUG - 2023-07-01 17:37:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-01 17:37:41 --> Input Class Initialized
INFO - 2023-07-01 17:37:41 --> Language Class Initialized
INFO - 2023-07-01 17:37:41 --> Loader Class Initialized
INFO - 2023-07-01 17:37:41 --> Helper loaded: url_helper
INFO - 2023-07-01 17:37:41 --> Helper loaded: file_helper
INFO - 2023-07-01 17:37:41 --> Helper loaded: html_helper
INFO - 2023-07-01 17:37:41 --> Helper loaded: text_helper
INFO - 2023-07-01 17:37:41 --> Helper loaded: form_helper
INFO - 2023-07-01 17:37:41 --> Helper loaded: lang_helper
INFO - 2023-07-01 17:37:41 --> Helper loaded: security_helper
INFO - 2023-07-01 17:37:41 --> Helper loaded: cookie_helper
INFO - 2023-07-01 17:37:41 --> Database Driver Class Initialized
INFO - 2023-07-01 17:37:41 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-01 17:37:41 --> Parser Class Initialized
INFO - 2023-07-01 17:37:41 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-01 17:37:41 --> Pagination Class Initialized
INFO - 2023-07-01 17:37:41 --> Form Validation Class Initialized
INFO - 2023-07-01 17:37:41 --> Controller Class Initialized
INFO - 2023-07-01 17:37:41 --> Model Class Initialized
DEBUG - 2023-07-01 17:37:41 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-01 17:37:41 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-01 17:37:41 --> Model Class Initialized
DEBUG - 2023-07-01 17:37:41 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-01 17:37:41 --> Model Class Initialized
INFO - 2023-07-01 17:37:41 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/invoice/invoice.php
DEBUG - 2023-07-01 17:37:41 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-07-01 17:37:41 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-07-01 17:37:41 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-07-01 17:37:41 --> Model Class Initialized
INFO - 2023-07-01 17:37:41 --> Model Class Initialized
INFO - 2023-07-01 17:37:41 --> Model Class Initialized
INFO - 2023-07-01 17:37:41 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-07-01 17:37:41 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-07-01 17:37:41 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-07-01 17:37:41 --> Final output sent to browser
DEBUG - 2023-07-01 17:37:41 --> Total execution time: 0.1218
ERROR - 2023-07-01 17:37:41 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-01 17:37:41 --> Config Class Initialized
INFO - 2023-07-01 17:37:41 --> Hooks Class Initialized
DEBUG - 2023-07-01 17:37:41 --> UTF-8 Support Enabled
INFO - 2023-07-01 17:37:41 --> Utf8 Class Initialized
INFO - 2023-07-01 17:37:41 --> URI Class Initialized
INFO - 2023-07-01 17:37:41 --> Router Class Initialized
INFO - 2023-07-01 17:37:41 --> Output Class Initialized
INFO - 2023-07-01 17:37:41 --> Security Class Initialized
DEBUG - 2023-07-01 17:37:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-01 17:37:41 --> Input Class Initialized
INFO - 2023-07-01 17:37:41 --> Language Class Initialized
INFO - 2023-07-01 17:37:41 --> Loader Class Initialized
INFO - 2023-07-01 17:37:41 --> Helper loaded: url_helper
INFO - 2023-07-01 17:37:41 --> Helper loaded: file_helper
INFO - 2023-07-01 17:37:41 --> Helper loaded: html_helper
INFO - 2023-07-01 17:37:41 --> Helper loaded: text_helper
INFO - 2023-07-01 17:37:41 --> Helper loaded: form_helper
INFO - 2023-07-01 17:37:41 --> Helper loaded: lang_helper
INFO - 2023-07-01 17:37:41 --> Helper loaded: security_helper
INFO - 2023-07-01 17:37:41 --> Helper loaded: cookie_helper
INFO - 2023-07-01 17:37:41 --> Database Driver Class Initialized
INFO - 2023-07-01 17:37:41 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-01 17:37:41 --> Parser Class Initialized
INFO - 2023-07-01 17:37:41 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-01 17:37:41 --> Pagination Class Initialized
INFO - 2023-07-01 17:37:42 --> Form Validation Class Initialized
INFO - 2023-07-01 17:37:42 --> Controller Class Initialized
INFO - 2023-07-01 17:37:42 --> Model Class Initialized
DEBUG - 2023-07-01 17:37:42 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-01 17:37:42 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-01 17:37:42 --> Model Class Initialized
DEBUG - 2023-07-01 17:37:42 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-01 17:37:42 --> Model Class Initialized
INFO - 2023-07-01 17:37:42 --> Final output sent to browser
DEBUG - 2023-07-01 17:37:42 --> Total execution time: 0.0437
ERROR - 2023-07-01 17:37:50 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-01 17:37:50 --> Config Class Initialized
INFO - 2023-07-01 17:37:50 --> Hooks Class Initialized
DEBUG - 2023-07-01 17:37:50 --> UTF-8 Support Enabled
INFO - 2023-07-01 17:37:50 --> Utf8 Class Initialized
INFO - 2023-07-01 17:37:50 --> URI Class Initialized
INFO - 2023-07-01 17:37:50 --> Router Class Initialized
INFO - 2023-07-01 17:37:50 --> Output Class Initialized
INFO - 2023-07-01 17:37:50 --> Security Class Initialized
DEBUG - 2023-07-01 17:37:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-01 17:37:50 --> Input Class Initialized
INFO - 2023-07-01 17:37:50 --> Language Class Initialized
INFO - 2023-07-01 17:37:50 --> Loader Class Initialized
INFO - 2023-07-01 17:37:50 --> Helper loaded: url_helper
INFO - 2023-07-01 17:37:50 --> Helper loaded: file_helper
INFO - 2023-07-01 17:37:50 --> Helper loaded: html_helper
INFO - 2023-07-01 17:37:50 --> Helper loaded: text_helper
INFO - 2023-07-01 17:37:50 --> Helper loaded: form_helper
INFO - 2023-07-01 17:37:50 --> Helper loaded: lang_helper
INFO - 2023-07-01 17:37:50 --> Helper loaded: security_helper
INFO - 2023-07-01 17:37:50 --> Helper loaded: cookie_helper
INFO - 2023-07-01 17:37:50 --> Database Driver Class Initialized
INFO - 2023-07-01 17:37:50 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-01 17:37:50 --> Parser Class Initialized
INFO - 2023-07-01 17:37:50 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-01 17:37:50 --> Pagination Class Initialized
INFO - 2023-07-01 17:37:50 --> Form Validation Class Initialized
INFO - 2023-07-01 17:37:50 --> Controller Class Initialized
INFO - 2023-07-01 17:37:50 --> Model Class Initialized
DEBUG - 2023-07-01 17:37:50 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-01 17:37:50 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-01 17:37:50 --> Model Class Initialized
DEBUG - 2023-07-01 17:37:50 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-01 17:37:50 --> Model Class Initialized
INFO - 2023-07-01 17:37:50 --> Final output sent to browser
DEBUG - 2023-07-01 17:37:50 --> Total execution time: 0.0436
ERROR - 2023-07-01 17:37:58 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-01 17:37:58 --> Config Class Initialized
INFO - 2023-07-01 17:37:58 --> Hooks Class Initialized
DEBUG - 2023-07-01 17:37:58 --> UTF-8 Support Enabled
INFO - 2023-07-01 17:37:58 --> Utf8 Class Initialized
INFO - 2023-07-01 17:37:58 --> URI Class Initialized
DEBUG - 2023-07-01 17:37:58 --> No URI present. Default controller set.
INFO - 2023-07-01 17:37:58 --> Router Class Initialized
INFO - 2023-07-01 17:37:58 --> Output Class Initialized
INFO - 2023-07-01 17:37:58 --> Security Class Initialized
DEBUG - 2023-07-01 17:37:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-01 17:37:58 --> Input Class Initialized
INFO - 2023-07-01 17:37:58 --> Language Class Initialized
INFO - 2023-07-01 17:37:58 --> Loader Class Initialized
INFO - 2023-07-01 17:37:58 --> Helper loaded: url_helper
INFO - 2023-07-01 17:37:58 --> Helper loaded: file_helper
INFO - 2023-07-01 17:37:58 --> Helper loaded: html_helper
INFO - 2023-07-01 17:37:58 --> Helper loaded: text_helper
INFO - 2023-07-01 17:37:58 --> Helper loaded: form_helper
INFO - 2023-07-01 17:37:58 --> Helper loaded: lang_helper
INFO - 2023-07-01 17:37:58 --> Helper loaded: security_helper
INFO - 2023-07-01 17:37:58 --> Helper loaded: cookie_helper
INFO - 2023-07-01 17:37:58 --> Database Driver Class Initialized
INFO - 2023-07-01 17:37:58 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-01 17:37:58 --> Parser Class Initialized
INFO - 2023-07-01 17:37:58 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-01 17:37:58 --> Pagination Class Initialized
INFO - 2023-07-01 17:37:58 --> Form Validation Class Initialized
INFO - 2023-07-01 17:37:58 --> Controller Class Initialized
INFO - 2023-07-01 17:37:58 --> Model Class Initialized
DEBUG - 2023-07-01 17:37:58 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-01 17:37:58 --> Model Class Initialized
DEBUG - 2023-07-01 17:37:58 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-01 17:37:58 --> Model Class Initialized
INFO - 2023-07-01 17:37:58 --> Model Class Initialized
INFO - 2023-07-01 17:37:58 --> Model Class Initialized
INFO - 2023-07-01 17:37:58 --> Model Class Initialized
DEBUG - 2023-07-01 17:37:58 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-01 17:37:58 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-01 17:37:58 --> Model Class Initialized
INFO - 2023-07-01 17:37:58 --> Model Class Initialized
INFO - 2023-07-01 17:37:58 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-07-01 17:37:58 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-07-01 17:37:58 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-07-01 17:37:58 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-07-01 17:37:58 --> Model Class Initialized
INFO - 2023-07-01 17:37:58 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-07-01 17:37:58 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-07-01 17:37:58 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-07-01 17:37:58 --> Final output sent to browser
DEBUG - 2023-07-01 17:37:58 --> Total execution time: 0.1518
ERROR - 2023-07-01 17:38:18 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-01 17:38:18 --> Config Class Initialized
INFO - 2023-07-01 17:38:18 --> Hooks Class Initialized
DEBUG - 2023-07-01 17:38:18 --> UTF-8 Support Enabled
INFO - 2023-07-01 17:38:18 --> Utf8 Class Initialized
INFO - 2023-07-01 17:38:18 --> URI Class Initialized
INFO - 2023-07-01 17:38:18 --> Router Class Initialized
INFO - 2023-07-01 17:38:18 --> Output Class Initialized
INFO - 2023-07-01 17:38:18 --> Security Class Initialized
DEBUG - 2023-07-01 17:38:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-01 17:38:18 --> Input Class Initialized
INFO - 2023-07-01 17:38:18 --> Language Class Initialized
INFO - 2023-07-01 17:38:18 --> Loader Class Initialized
INFO - 2023-07-01 17:38:18 --> Helper loaded: url_helper
INFO - 2023-07-01 17:38:18 --> Helper loaded: file_helper
INFO - 2023-07-01 17:38:18 --> Helper loaded: html_helper
INFO - 2023-07-01 17:38:18 --> Helper loaded: text_helper
INFO - 2023-07-01 17:38:18 --> Helper loaded: form_helper
INFO - 2023-07-01 17:38:18 --> Helper loaded: lang_helper
INFO - 2023-07-01 17:38:18 --> Helper loaded: security_helper
INFO - 2023-07-01 17:38:18 --> Helper loaded: cookie_helper
INFO - 2023-07-01 17:38:18 --> Database Driver Class Initialized
INFO - 2023-07-01 17:38:18 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-01 17:38:18 --> Parser Class Initialized
INFO - 2023-07-01 17:38:18 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-01 17:38:18 --> Pagination Class Initialized
INFO - 2023-07-01 17:38:18 --> Form Validation Class Initialized
INFO - 2023-07-01 17:38:18 --> Controller Class Initialized
INFO - 2023-07-01 17:38:18 --> Model Class Initialized
DEBUG - 2023-07-01 17:38:18 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-01 17:38:18 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-01 17:38:18 --> Model Class Initialized
DEBUG - 2023-07-01 17:38:18 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-01 17:38:18 --> Model Class Initialized
INFO - 2023-07-01 17:38:18 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice.php
DEBUG - 2023-07-01 17:38:18 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-07-01 17:38:18 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-07-01 17:38:18 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-07-01 17:38:18 --> Model Class Initialized
INFO - 2023-07-01 17:38:18 --> Model Class Initialized
INFO - 2023-07-01 17:38:18 --> Model Class Initialized
INFO - 2023-07-01 17:38:19 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-07-01 17:38:19 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-07-01 17:38:19 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-07-01 17:38:19 --> Final output sent to browser
DEBUG - 2023-07-01 17:38:19 --> Total execution time: 0.1501
ERROR - 2023-07-01 17:38:19 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-01 17:38:19 --> Config Class Initialized
INFO - 2023-07-01 17:38:19 --> Hooks Class Initialized
DEBUG - 2023-07-01 17:38:19 --> UTF-8 Support Enabled
INFO - 2023-07-01 17:38:19 --> Utf8 Class Initialized
INFO - 2023-07-01 17:38:19 --> URI Class Initialized
INFO - 2023-07-01 17:38:19 --> Router Class Initialized
INFO - 2023-07-01 17:38:19 --> Output Class Initialized
INFO - 2023-07-01 17:38:19 --> Security Class Initialized
DEBUG - 2023-07-01 17:38:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-01 17:38:19 --> Input Class Initialized
INFO - 2023-07-01 17:38:19 --> Language Class Initialized
INFO - 2023-07-01 17:38:19 --> Loader Class Initialized
INFO - 2023-07-01 17:38:19 --> Helper loaded: url_helper
INFO - 2023-07-01 17:38:19 --> Helper loaded: file_helper
INFO - 2023-07-01 17:38:19 --> Helper loaded: html_helper
INFO - 2023-07-01 17:38:19 --> Helper loaded: text_helper
INFO - 2023-07-01 17:38:19 --> Helper loaded: form_helper
INFO - 2023-07-01 17:38:19 --> Helper loaded: lang_helper
INFO - 2023-07-01 17:38:19 --> Helper loaded: security_helper
INFO - 2023-07-01 17:38:19 --> Helper loaded: cookie_helper
INFO - 2023-07-01 17:38:19 --> Database Driver Class Initialized
INFO - 2023-07-01 17:38:19 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-01 17:38:19 --> Parser Class Initialized
INFO - 2023-07-01 17:38:19 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-01 17:38:19 --> Pagination Class Initialized
INFO - 2023-07-01 17:38:19 --> Form Validation Class Initialized
INFO - 2023-07-01 17:38:19 --> Controller Class Initialized
INFO - 2023-07-01 17:38:19 --> Model Class Initialized
DEBUG - 2023-07-01 17:38:19 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-01 17:38:19 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-01 17:38:19 --> Model Class Initialized
DEBUG - 2023-07-01 17:38:19 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-01 17:38:19 --> Model Class Initialized
INFO - 2023-07-01 17:38:19 --> Final output sent to browser
DEBUG - 2023-07-01 17:38:19 --> Total execution time: 0.0627
ERROR - 2023-07-01 17:38:25 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-01 17:38:25 --> Config Class Initialized
INFO - 2023-07-01 17:38:25 --> Hooks Class Initialized
DEBUG - 2023-07-01 17:38:25 --> UTF-8 Support Enabled
INFO - 2023-07-01 17:38:25 --> Utf8 Class Initialized
INFO - 2023-07-01 17:38:25 --> URI Class Initialized
INFO - 2023-07-01 17:38:25 --> Router Class Initialized
INFO - 2023-07-01 17:38:25 --> Output Class Initialized
INFO - 2023-07-01 17:38:25 --> Security Class Initialized
DEBUG - 2023-07-01 17:38:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-01 17:38:25 --> Input Class Initialized
INFO - 2023-07-01 17:38:25 --> Language Class Initialized
INFO - 2023-07-01 17:38:25 --> Loader Class Initialized
INFO - 2023-07-01 17:38:25 --> Helper loaded: url_helper
INFO - 2023-07-01 17:38:25 --> Helper loaded: file_helper
INFO - 2023-07-01 17:38:25 --> Helper loaded: html_helper
INFO - 2023-07-01 17:38:25 --> Helper loaded: text_helper
INFO - 2023-07-01 17:38:25 --> Helper loaded: form_helper
INFO - 2023-07-01 17:38:25 --> Helper loaded: lang_helper
INFO - 2023-07-01 17:38:25 --> Helper loaded: security_helper
INFO - 2023-07-01 17:38:25 --> Helper loaded: cookie_helper
INFO - 2023-07-01 17:38:25 --> Database Driver Class Initialized
INFO - 2023-07-01 17:38:25 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-01 17:38:25 --> Parser Class Initialized
INFO - 2023-07-01 17:38:25 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-01 17:38:25 --> Pagination Class Initialized
INFO - 2023-07-01 17:38:25 --> Form Validation Class Initialized
INFO - 2023-07-01 17:38:25 --> Controller Class Initialized
INFO - 2023-07-01 17:38:25 --> Model Class Initialized
DEBUG - 2023-07-01 17:38:25 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-01 17:38:25 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-01 17:38:25 --> Model Class Initialized
DEBUG - 2023-07-01 17:38:25 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-01 17:38:25 --> Model Class Initialized
INFO - 2023-07-01 17:38:25 --> Final output sent to browser
DEBUG - 2023-07-01 17:38:25 --> Total execution time: 0.3284
ERROR - 2023-07-01 17:38:37 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-01 17:38:37 --> Config Class Initialized
INFO - 2023-07-01 17:38:37 --> Hooks Class Initialized
DEBUG - 2023-07-01 17:38:37 --> UTF-8 Support Enabled
INFO - 2023-07-01 17:38:37 --> Utf8 Class Initialized
INFO - 2023-07-01 17:38:37 --> URI Class Initialized
DEBUG - 2023-07-01 17:38:37 --> No URI present. Default controller set.
INFO - 2023-07-01 17:38:37 --> Router Class Initialized
INFO - 2023-07-01 17:38:37 --> Output Class Initialized
INFO - 2023-07-01 17:38:37 --> Security Class Initialized
DEBUG - 2023-07-01 17:38:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-01 17:38:37 --> Input Class Initialized
INFO - 2023-07-01 17:38:37 --> Language Class Initialized
INFO - 2023-07-01 17:38:37 --> Loader Class Initialized
INFO - 2023-07-01 17:38:37 --> Helper loaded: url_helper
INFO - 2023-07-01 17:38:37 --> Helper loaded: file_helper
INFO - 2023-07-01 17:38:37 --> Helper loaded: html_helper
INFO - 2023-07-01 17:38:37 --> Helper loaded: text_helper
INFO - 2023-07-01 17:38:37 --> Helper loaded: form_helper
INFO - 2023-07-01 17:38:37 --> Helper loaded: lang_helper
INFO - 2023-07-01 17:38:37 --> Helper loaded: security_helper
INFO - 2023-07-01 17:38:37 --> Helper loaded: cookie_helper
INFO - 2023-07-01 17:38:37 --> Database Driver Class Initialized
INFO - 2023-07-01 17:38:37 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-01 17:38:37 --> Parser Class Initialized
INFO - 2023-07-01 17:38:37 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-01 17:38:37 --> Pagination Class Initialized
INFO - 2023-07-01 17:38:37 --> Form Validation Class Initialized
INFO - 2023-07-01 17:38:37 --> Controller Class Initialized
INFO - 2023-07-01 17:38:37 --> Model Class Initialized
DEBUG - 2023-07-01 17:38:37 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-01 17:38:37 --> Model Class Initialized
DEBUG - 2023-07-01 17:38:37 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-01 17:38:37 --> Model Class Initialized
INFO - 2023-07-01 17:38:37 --> Model Class Initialized
INFO - 2023-07-01 17:38:37 --> Model Class Initialized
INFO - 2023-07-01 17:38:37 --> Model Class Initialized
DEBUG - 2023-07-01 17:38:37 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-01 17:38:37 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-01 17:38:37 --> Model Class Initialized
INFO - 2023-07-01 17:38:37 --> Model Class Initialized
INFO - 2023-07-01 17:38:37 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-07-01 17:38:37 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-07-01 17:38:37 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-07-01 17:38:37 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-07-01 17:38:37 --> Model Class Initialized
INFO - 2023-07-01 17:38:37 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-07-01 17:38:37 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-07-01 17:38:37 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-07-01 17:38:37 --> Final output sent to browser
DEBUG - 2023-07-01 17:38:37 --> Total execution time: 0.1671
ERROR - 2023-07-01 17:51:55 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-01 17:51:55 --> Config Class Initialized
INFO - 2023-07-01 17:51:55 --> Hooks Class Initialized
DEBUG - 2023-07-01 17:51:55 --> UTF-8 Support Enabled
INFO - 2023-07-01 17:51:55 --> Utf8 Class Initialized
INFO - 2023-07-01 17:51:55 --> URI Class Initialized
DEBUG - 2023-07-01 17:51:55 --> No URI present. Default controller set.
INFO - 2023-07-01 17:51:55 --> Router Class Initialized
INFO - 2023-07-01 17:51:55 --> Output Class Initialized
INFO - 2023-07-01 17:51:55 --> Security Class Initialized
DEBUG - 2023-07-01 17:51:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-01 17:51:55 --> Input Class Initialized
INFO - 2023-07-01 17:51:55 --> Language Class Initialized
INFO - 2023-07-01 17:51:55 --> Loader Class Initialized
INFO - 2023-07-01 17:51:55 --> Helper loaded: url_helper
INFO - 2023-07-01 17:51:55 --> Helper loaded: file_helper
INFO - 2023-07-01 17:51:55 --> Helper loaded: html_helper
INFO - 2023-07-01 17:51:55 --> Helper loaded: text_helper
INFO - 2023-07-01 17:51:55 --> Helper loaded: form_helper
INFO - 2023-07-01 17:51:55 --> Helper loaded: lang_helper
INFO - 2023-07-01 17:51:55 --> Helper loaded: security_helper
INFO - 2023-07-01 17:51:55 --> Helper loaded: cookie_helper
INFO - 2023-07-01 17:51:55 --> Database Driver Class Initialized
INFO - 2023-07-01 17:51:55 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-01 17:51:55 --> Parser Class Initialized
INFO - 2023-07-01 17:51:55 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-01 17:51:55 --> Pagination Class Initialized
INFO - 2023-07-01 17:51:55 --> Form Validation Class Initialized
INFO - 2023-07-01 17:51:55 --> Controller Class Initialized
INFO - 2023-07-01 17:51:55 --> Model Class Initialized
DEBUG - 2023-07-01 17:51:55 --> Session class already loaded. Second attempt ignored.
ERROR - 2023-07-01 17:51:55 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-01 17:51:55 --> Config Class Initialized
INFO - 2023-07-01 17:51:55 --> Hooks Class Initialized
DEBUG - 2023-07-01 17:51:55 --> UTF-8 Support Enabled
INFO - 2023-07-01 17:51:55 --> Utf8 Class Initialized
INFO - 2023-07-01 17:51:55 --> URI Class Initialized
INFO - 2023-07-01 17:51:55 --> Router Class Initialized
INFO - 2023-07-01 17:51:55 --> Output Class Initialized
INFO - 2023-07-01 17:51:55 --> Security Class Initialized
DEBUG - 2023-07-01 17:51:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-01 17:51:55 --> Input Class Initialized
INFO - 2023-07-01 17:51:55 --> Language Class Initialized
INFO - 2023-07-01 17:51:55 --> Loader Class Initialized
INFO - 2023-07-01 17:51:55 --> Helper loaded: url_helper
INFO - 2023-07-01 17:51:55 --> Helper loaded: file_helper
INFO - 2023-07-01 17:51:55 --> Helper loaded: html_helper
INFO - 2023-07-01 17:51:55 --> Helper loaded: text_helper
INFO - 2023-07-01 17:51:55 --> Helper loaded: form_helper
INFO - 2023-07-01 17:51:55 --> Helper loaded: lang_helper
INFO - 2023-07-01 17:51:55 --> Helper loaded: security_helper
INFO - 2023-07-01 17:51:55 --> Helper loaded: cookie_helper
INFO - 2023-07-01 17:51:55 --> Database Driver Class Initialized
INFO - 2023-07-01 17:51:55 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-01 17:51:55 --> Parser Class Initialized
INFO - 2023-07-01 17:51:55 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-01 17:51:55 --> Pagination Class Initialized
INFO - 2023-07-01 17:51:55 --> Form Validation Class Initialized
INFO - 2023-07-01 17:51:55 --> Controller Class Initialized
INFO - 2023-07-01 17:51:55 --> Model Class Initialized
DEBUG - 2023-07-01 17:51:55 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-01 17:51:55 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2023-07-01 17:51:55 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-07-01 17:51:55 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-07-01 17:51:55 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-07-01 17:51:55 --> Model Class Initialized
INFO - 2023-07-01 17:51:55 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-07-01 17:51:55 --> Final output sent to browser
DEBUG - 2023-07-01 17:51:55 --> Total execution time: 0.0338
ERROR - 2023-07-01 17:52:33 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-01 17:52:33 --> Config Class Initialized
INFO - 2023-07-01 17:52:33 --> Hooks Class Initialized
DEBUG - 2023-07-01 17:52:33 --> UTF-8 Support Enabled
INFO - 2023-07-01 17:52:33 --> Utf8 Class Initialized
INFO - 2023-07-01 17:52:33 --> URI Class Initialized
INFO - 2023-07-01 17:52:33 --> Router Class Initialized
INFO - 2023-07-01 17:52:33 --> Output Class Initialized
INFO - 2023-07-01 17:52:33 --> Security Class Initialized
DEBUG - 2023-07-01 17:52:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-01 17:52:33 --> Input Class Initialized
INFO - 2023-07-01 17:52:33 --> Language Class Initialized
INFO - 2023-07-01 17:52:33 --> Loader Class Initialized
INFO - 2023-07-01 17:52:33 --> Helper loaded: url_helper
INFO - 2023-07-01 17:52:33 --> Helper loaded: file_helper
INFO - 2023-07-01 17:52:33 --> Helper loaded: html_helper
INFO - 2023-07-01 17:52:33 --> Helper loaded: text_helper
INFO - 2023-07-01 17:52:33 --> Helper loaded: form_helper
INFO - 2023-07-01 17:52:33 --> Helper loaded: lang_helper
INFO - 2023-07-01 17:52:33 --> Helper loaded: security_helper
INFO - 2023-07-01 17:52:33 --> Helper loaded: cookie_helper
INFO - 2023-07-01 17:52:33 --> Database Driver Class Initialized
INFO - 2023-07-01 17:52:33 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-01 17:52:33 --> Parser Class Initialized
INFO - 2023-07-01 17:52:33 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-01 17:52:33 --> Pagination Class Initialized
INFO - 2023-07-01 17:52:33 --> Form Validation Class Initialized
INFO - 2023-07-01 17:52:33 --> Controller Class Initialized
INFO - 2023-07-01 17:52:33 --> Model Class Initialized
DEBUG - 2023-07-01 17:52:33 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-01 17:52:33 --> Model Class Initialized
INFO - 2023-07-01 17:52:33 --> Final output sent to browser
DEBUG - 2023-07-01 17:52:33 --> Total execution time: 0.0198
ERROR - 2023-07-01 17:52:33 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-01 17:52:33 --> Config Class Initialized
INFO - 2023-07-01 17:52:33 --> Hooks Class Initialized
DEBUG - 2023-07-01 17:52:33 --> UTF-8 Support Enabled
INFO - 2023-07-01 17:52:33 --> Utf8 Class Initialized
INFO - 2023-07-01 17:52:33 --> URI Class Initialized
INFO - 2023-07-01 17:52:33 --> Router Class Initialized
INFO - 2023-07-01 17:52:33 --> Output Class Initialized
INFO - 2023-07-01 17:52:33 --> Security Class Initialized
DEBUG - 2023-07-01 17:52:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-01 17:52:33 --> Input Class Initialized
INFO - 2023-07-01 17:52:33 --> Language Class Initialized
INFO - 2023-07-01 17:52:33 --> Loader Class Initialized
INFO - 2023-07-01 17:52:33 --> Helper loaded: url_helper
INFO - 2023-07-01 17:52:33 --> Helper loaded: file_helper
INFO - 2023-07-01 17:52:33 --> Helper loaded: html_helper
INFO - 2023-07-01 17:52:33 --> Helper loaded: text_helper
INFO - 2023-07-01 17:52:33 --> Helper loaded: form_helper
INFO - 2023-07-01 17:52:33 --> Helper loaded: lang_helper
INFO - 2023-07-01 17:52:33 --> Helper loaded: security_helper
INFO - 2023-07-01 17:52:33 --> Helper loaded: cookie_helper
INFO - 2023-07-01 17:52:33 --> Database Driver Class Initialized
INFO - 2023-07-01 17:52:33 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-01 17:52:33 --> Parser Class Initialized
INFO - 2023-07-01 17:52:33 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-01 17:52:33 --> Pagination Class Initialized
INFO - 2023-07-01 17:52:33 --> Form Validation Class Initialized
INFO - 2023-07-01 17:52:33 --> Controller Class Initialized
INFO - 2023-07-01 17:52:33 --> Model Class Initialized
DEBUG - 2023-07-01 17:52:33 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-01 17:52:33 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2023-07-01 17:52:33 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-07-01 17:52:33 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-07-01 17:52:33 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-07-01 17:52:33 --> Model Class Initialized
INFO - 2023-07-01 17:52:33 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-07-01 17:52:33 --> Final output sent to browser
DEBUG - 2023-07-01 17:52:33 --> Total execution time: 0.0376
ERROR - 2023-07-01 18:10:48 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-01 18:10:48 --> Config Class Initialized
INFO - 2023-07-01 18:10:48 --> Hooks Class Initialized
DEBUG - 2023-07-01 18:10:48 --> UTF-8 Support Enabled
INFO - 2023-07-01 18:10:48 --> Utf8 Class Initialized
INFO - 2023-07-01 18:10:48 --> URI Class Initialized
DEBUG - 2023-07-01 18:10:48 --> No URI present. Default controller set.
INFO - 2023-07-01 18:10:48 --> Router Class Initialized
INFO - 2023-07-01 18:10:48 --> Output Class Initialized
INFO - 2023-07-01 18:10:48 --> Security Class Initialized
DEBUG - 2023-07-01 18:10:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-01 18:10:48 --> Input Class Initialized
INFO - 2023-07-01 18:10:48 --> Language Class Initialized
INFO - 2023-07-01 18:10:48 --> Loader Class Initialized
INFO - 2023-07-01 18:10:48 --> Helper loaded: url_helper
INFO - 2023-07-01 18:10:48 --> Helper loaded: file_helper
INFO - 2023-07-01 18:10:48 --> Helper loaded: html_helper
INFO - 2023-07-01 18:10:48 --> Helper loaded: text_helper
INFO - 2023-07-01 18:10:48 --> Helper loaded: form_helper
INFO - 2023-07-01 18:10:48 --> Helper loaded: lang_helper
INFO - 2023-07-01 18:10:48 --> Helper loaded: security_helper
INFO - 2023-07-01 18:10:48 --> Helper loaded: cookie_helper
INFO - 2023-07-01 18:10:48 --> Database Driver Class Initialized
INFO - 2023-07-01 18:10:48 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-01 18:10:48 --> Parser Class Initialized
INFO - 2023-07-01 18:10:48 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-01 18:10:48 --> Pagination Class Initialized
INFO - 2023-07-01 18:10:48 --> Form Validation Class Initialized
INFO - 2023-07-01 18:10:48 --> Controller Class Initialized
INFO - 2023-07-01 18:10:48 --> Model Class Initialized
DEBUG - 2023-07-01 18:10:48 --> Session class already loaded. Second attempt ignored.
ERROR - 2023-07-01 18:10:48 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-01 18:10:48 --> Config Class Initialized
INFO - 2023-07-01 18:10:48 --> Hooks Class Initialized
DEBUG - 2023-07-01 18:10:48 --> UTF-8 Support Enabled
INFO - 2023-07-01 18:10:48 --> Utf8 Class Initialized
INFO - 2023-07-01 18:10:48 --> URI Class Initialized
INFO - 2023-07-01 18:10:48 --> Router Class Initialized
INFO - 2023-07-01 18:10:48 --> Output Class Initialized
INFO - 2023-07-01 18:10:48 --> Security Class Initialized
DEBUG - 2023-07-01 18:10:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-01 18:10:48 --> Input Class Initialized
INFO - 2023-07-01 18:10:48 --> Language Class Initialized
INFO - 2023-07-01 18:10:48 --> Loader Class Initialized
INFO - 2023-07-01 18:10:48 --> Helper loaded: url_helper
INFO - 2023-07-01 18:10:48 --> Helper loaded: file_helper
INFO - 2023-07-01 18:10:48 --> Helper loaded: html_helper
INFO - 2023-07-01 18:10:48 --> Helper loaded: text_helper
INFO - 2023-07-01 18:10:48 --> Helper loaded: form_helper
INFO - 2023-07-01 18:10:48 --> Helper loaded: lang_helper
INFO - 2023-07-01 18:10:48 --> Helper loaded: security_helper
INFO - 2023-07-01 18:10:48 --> Helper loaded: cookie_helper
INFO - 2023-07-01 18:10:48 --> Database Driver Class Initialized
INFO - 2023-07-01 18:10:48 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-01 18:10:48 --> Parser Class Initialized
INFO - 2023-07-01 18:10:48 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-01 18:10:48 --> Pagination Class Initialized
INFO - 2023-07-01 18:10:48 --> Form Validation Class Initialized
INFO - 2023-07-01 18:10:48 --> Controller Class Initialized
INFO - 2023-07-01 18:10:48 --> Model Class Initialized
DEBUG - 2023-07-01 18:10:48 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-01 18:10:48 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2023-07-01 18:10:48 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-07-01 18:10:48 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-07-01 18:10:48 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-07-01 18:10:48 --> Model Class Initialized
INFO - 2023-07-01 18:10:48 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-07-01 18:10:48 --> Final output sent to browser
DEBUG - 2023-07-01 18:10:48 --> Total execution time: 0.0294
ERROR - 2023-07-01 18:11:15 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-01 18:11:15 --> Config Class Initialized
INFO - 2023-07-01 18:11:15 --> Hooks Class Initialized
DEBUG - 2023-07-01 18:11:15 --> UTF-8 Support Enabled
INFO - 2023-07-01 18:11:15 --> Utf8 Class Initialized
INFO - 2023-07-01 18:11:15 --> URI Class Initialized
INFO - 2023-07-01 18:11:15 --> Router Class Initialized
INFO - 2023-07-01 18:11:15 --> Output Class Initialized
INFO - 2023-07-01 18:11:15 --> Security Class Initialized
DEBUG - 2023-07-01 18:11:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-01 18:11:15 --> Input Class Initialized
INFO - 2023-07-01 18:11:15 --> Language Class Initialized
INFO - 2023-07-01 18:11:15 --> Loader Class Initialized
INFO - 2023-07-01 18:11:15 --> Helper loaded: url_helper
INFO - 2023-07-01 18:11:15 --> Helper loaded: file_helper
INFO - 2023-07-01 18:11:15 --> Helper loaded: html_helper
INFO - 2023-07-01 18:11:15 --> Helper loaded: text_helper
INFO - 2023-07-01 18:11:15 --> Helper loaded: form_helper
INFO - 2023-07-01 18:11:15 --> Helper loaded: lang_helper
INFO - 2023-07-01 18:11:15 --> Helper loaded: security_helper
INFO - 2023-07-01 18:11:15 --> Helper loaded: cookie_helper
INFO - 2023-07-01 18:11:15 --> Database Driver Class Initialized
INFO - 2023-07-01 18:11:15 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-01 18:11:15 --> Parser Class Initialized
INFO - 2023-07-01 18:11:15 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-01 18:11:15 --> Pagination Class Initialized
INFO - 2023-07-01 18:11:15 --> Form Validation Class Initialized
INFO - 2023-07-01 18:11:15 --> Controller Class Initialized
INFO - 2023-07-01 18:11:15 --> Model Class Initialized
DEBUG - 2023-07-01 18:11:15 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-01 18:11:15 --> Model Class Initialized
INFO - 2023-07-01 18:11:15 --> Final output sent to browser
DEBUG - 2023-07-01 18:11:15 --> Total execution time: 0.0181
ERROR - 2023-07-01 18:11:15 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-01 18:11:15 --> Config Class Initialized
INFO - 2023-07-01 18:11:15 --> Hooks Class Initialized
DEBUG - 2023-07-01 18:11:15 --> UTF-8 Support Enabled
INFO - 2023-07-01 18:11:15 --> Utf8 Class Initialized
INFO - 2023-07-01 18:11:15 --> URI Class Initialized
DEBUG - 2023-07-01 18:11:15 --> No URI present. Default controller set.
INFO - 2023-07-01 18:11:15 --> Router Class Initialized
INFO - 2023-07-01 18:11:15 --> Output Class Initialized
INFO - 2023-07-01 18:11:15 --> Security Class Initialized
DEBUG - 2023-07-01 18:11:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-01 18:11:15 --> Input Class Initialized
INFO - 2023-07-01 18:11:15 --> Language Class Initialized
INFO - 2023-07-01 18:11:15 --> Loader Class Initialized
INFO - 2023-07-01 18:11:15 --> Helper loaded: url_helper
INFO - 2023-07-01 18:11:15 --> Helper loaded: file_helper
INFO - 2023-07-01 18:11:15 --> Helper loaded: html_helper
INFO - 2023-07-01 18:11:15 --> Helper loaded: text_helper
INFO - 2023-07-01 18:11:15 --> Helper loaded: form_helper
INFO - 2023-07-01 18:11:15 --> Helper loaded: lang_helper
INFO - 2023-07-01 18:11:15 --> Helper loaded: security_helper
INFO - 2023-07-01 18:11:15 --> Helper loaded: cookie_helper
INFO - 2023-07-01 18:11:15 --> Database Driver Class Initialized
INFO - 2023-07-01 18:11:15 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-01 18:11:15 --> Parser Class Initialized
INFO - 2023-07-01 18:11:15 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-01 18:11:15 --> Pagination Class Initialized
INFO - 2023-07-01 18:11:15 --> Form Validation Class Initialized
INFO - 2023-07-01 18:11:15 --> Controller Class Initialized
INFO - 2023-07-01 18:11:15 --> Model Class Initialized
DEBUG - 2023-07-01 18:11:15 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-01 18:11:15 --> Model Class Initialized
DEBUG - 2023-07-01 18:11:15 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-01 18:11:15 --> Model Class Initialized
INFO - 2023-07-01 18:11:15 --> Model Class Initialized
INFO - 2023-07-01 18:11:15 --> Model Class Initialized
INFO - 2023-07-01 18:11:15 --> Model Class Initialized
DEBUG - 2023-07-01 18:11:15 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-01 18:11:15 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-01 18:11:15 --> Model Class Initialized
INFO - 2023-07-01 18:11:15 --> Model Class Initialized
INFO - 2023-07-01 18:11:15 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-07-01 18:11:15 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-07-01 18:11:15 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-07-01 18:11:15 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-07-01 18:11:15 --> Model Class Initialized
INFO - 2023-07-01 18:11:15 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-07-01 18:11:15 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-07-01 18:11:15 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-07-01 18:11:15 --> Final output sent to browser
DEBUG - 2023-07-01 18:11:15 --> Total execution time: 0.1594
ERROR - 2023-07-01 18:11:16 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-01 18:11:16 --> Config Class Initialized
INFO - 2023-07-01 18:11:16 --> Hooks Class Initialized
DEBUG - 2023-07-01 18:11:16 --> UTF-8 Support Enabled
INFO - 2023-07-01 18:11:16 --> Utf8 Class Initialized
INFO - 2023-07-01 18:11:16 --> URI Class Initialized
INFO - 2023-07-01 18:11:16 --> Router Class Initialized
INFO - 2023-07-01 18:11:16 --> Output Class Initialized
INFO - 2023-07-01 18:11:16 --> Security Class Initialized
DEBUG - 2023-07-01 18:11:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-01 18:11:16 --> Input Class Initialized
INFO - 2023-07-01 18:11:16 --> Language Class Initialized
INFO - 2023-07-01 18:11:16 --> Loader Class Initialized
INFO - 2023-07-01 18:11:16 --> Helper loaded: url_helper
INFO - 2023-07-01 18:11:16 --> Helper loaded: file_helper
INFO - 2023-07-01 18:11:16 --> Helper loaded: html_helper
INFO - 2023-07-01 18:11:16 --> Helper loaded: text_helper
INFO - 2023-07-01 18:11:16 --> Helper loaded: form_helper
INFO - 2023-07-01 18:11:16 --> Helper loaded: lang_helper
INFO - 2023-07-01 18:11:16 --> Helper loaded: security_helper
INFO - 2023-07-01 18:11:16 --> Helper loaded: cookie_helper
INFO - 2023-07-01 18:11:16 --> Database Driver Class Initialized
INFO - 2023-07-01 18:11:16 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-01 18:11:16 --> Parser Class Initialized
INFO - 2023-07-01 18:11:16 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-01 18:11:16 --> Pagination Class Initialized
INFO - 2023-07-01 18:11:16 --> Form Validation Class Initialized
INFO - 2023-07-01 18:11:16 --> Controller Class Initialized
DEBUG - 2023-07-01 18:11:16 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-01 18:11:16 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-01 18:11:16 --> Model Class Initialized
INFO - 2023-07-01 18:11:16 --> Final output sent to browser
DEBUG - 2023-07-01 18:11:16 --> Total execution time: 0.0130
ERROR - 2023-07-01 18:11:29 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-01 18:11:29 --> Config Class Initialized
INFO - 2023-07-01 18:11:29 --> Hooks Class Initialized
DEBUG - 2023-07-01 18:11:29 --> UTF-8 Support Enabled
INFO - 2023-07-01 18:11:29 --> Utf8 Class Initialized
INFO - 2023-07-01 18:11:29 --> URI Class Initialized
INFO - 2023-07-01 18:11:29 --> Router Class Initialized
INFO - 2023-07-01 18:11:29 --> Output Class Initialized
INFO - 2023-07-01 18:11:29 --> Security Class Initialized
DEBUG - 2023-07-01 18:11:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-01 18:11:29 --> Input Class Initialized
INFO - 2023-07-01 18:11:29 --> Language Class Initialized
INFO - 2023-07-01 18:11:29 --> Loader Class Initialized
INFO - 2023-07-01 18:11:29 --> Helper loaded: url_helper
INFO - 2023-07-01 18:11:29 --> Helper loaded: file_helper
INFO - 2023-07-01 18:11:29 --> Helper loaded: html_helper
INFO - 2023-07-01 18:11:29 --> Helper loaded: text_helper
INFO - 2023-07-01 18:11:29 --> Helper loaded: form_helper
INFO - 2023-07-01 18:11:29 --> Helper loaded: lang_helper
INFO - 2023-07-01 18:11:29 --> Helper loaded: security_helper
INFO - 2023-07-01 18:11:29 --> Helper loaded: cookie_helper
INFO - 2023-07-01 18:11:29 --> Database Driver Class Initialized
INFO - 2023-07-01 18:11:29 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-01 18:11:29 --> Parser Class Initialized
INFO - 2023-07-01 18:11:29 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-01 18:11:29 --> Pagination Class Initialized
INFO - 2023-07-01 18:11:29 --> Form Validation Class Initialized
INFO - 2023-07-01 18:11:29 --> Controller Class Initialized
INFO - 2023-07-01 18:11:29 --> Model Class Initialized
DEBUG - 2023-07-01 18:11:29 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-01 18:11:29 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-01 18:11:29 --> Model Class Initialized
DEBUG - 2023-07-01 18:11:29 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-01 18:11:29 --> Model Class Initialized
INFO - 2023-07-01 18:11:29 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/invoice/invoice.php
DEBUG - 2023-07-01 18:11:29 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-07-01 18:11:29 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-07-01 18:11:29 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-07-01 18:11:29 --> Model Class Initialized
INFO - 2023-07-01 18:11:29 --> Model Class Initialized
INFO - 2023-07-01 18:11:29 --> Model Class Initialized
INFO - 2023-07-01 18:11:29 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-07-01 18:11:29 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-07-01 18:11:29 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-07-01 18:11:29 --> Final output sent to browser
DEBUG - 2023-07-01 18:11:29 --> Total execution time: 0.1315
ERROR - 2023-07-01 18:11:30 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-01 18:11:30 --> Config Class Initialized
INFO - 2023-07-01 18:11:30 --> Hooks Class Initialized
DEBUG - 2023-07-01 18:11:30 --> UTF-8 Support Enabled
INFO - 2023-07-01 18:11:30 --> Utf8 Class Initialized
INFO - 2023-07-01 18:11:30 --> URI Class Initialized
INFO - 2023-07-01 18:11:30 --> Router Class Initialized
INFO - 2023-07-01 18:11:30 --> Output Class Initialized
INFO - 2023-07-01 18:11:30 --> Security Class Initialized
DEBUG - 2023-07-01 18:11:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-01 18:11:30 --> Input Class Initialized
INFO - 2023-07-01 18:11:30 --> Language Class Initialized
INFO - 2023-07-01 18:11:30 --> Loader Class Initialized
INFO - 2023-07-01 18:11:30 --> Helper loaded: url_helper
INFO - 2023-07-01 18:11:30 --> Helper loaded: file_helper
INFO - 2023-07-01 18:11:30 --> Helper loaded: html_helper
INFO - 2023-07-01 18:11:30 --> Helper loaded: text_helper
INFO - 2023-07-01 18:11:30 --> Helper loaded: form_helper
INFO - 2023-07-01 18:11:30 --> Helper loaded: lang_helper
INFO - 2023-07-01 18:11:30 --> Helper loaded: security_helper
INFO - 2023-07-01 18:11:30 --> Helper loaded: cookie_helper
INFO - 2023-07-01 18:11:30 --> Database Driver Class Initialized
INFO - 2023-07-01 18:11:30 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-01 18:11:30 --> Parser Class Initialized
INFO - 2023-07-01 18:11:30 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-01 18:11:30 --> Pagination Class Initialized
INFO - 2023-07-01 18:11:30 --> Form Validation Class Initialized
INFO - 2023-07-01 18:11:30 --> Controller Class Initialized
INFO - 2023-07-01 18:11:30 --> Model Class Initialized
DEBUG - 2023-07-01 18:11:30 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-01 18:11:30 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-01 18:11:30 --> Model Class Initialized
DEBUG - 2023-07-01 18:11:30 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-01 18:11:30 --> Model Class Initialized
INFO - 2023-07-01 18:11:30 --> Final output sent to browser
DEBUG - 2023-07-01 18:11:30 --> Total execution time: 0.0450
ERROR - 2023-07-01 18:11:40 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-01 18:11:40 --> Config Class Initialized
INFO - 2023-07-01 18:11:40 --> Hooks Class Initialized
DEBUG - 2023-07-01 18:11:40 --> UTF-8 Support Enabled
INFO - 2023-07-01 18:11:40 --> Utf8 Class Initialized
INFO - 2023-07-01 18:11:40 --> URI Class Initialized
INFO - 2023-07-01 18:11:40 --> Router Class Initialized
INFO - 2023-07-01 18:11:40 --> Output Class Initialized
INFO - 2023-07-01 18:11:40 --> Security Class Initialized
DEBUG - 2023-07-01 18:11:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-01 18:11:40 --> Input Class Initialized
INFO - 2023-07-01 18:11:40 --> Language Class Initialized
INFO - 2023-07-01 18:11:40 --> Loader Class Initialized
INFO - 2023-07-01 18:11:40 --> Helper loaded: url_helper
INFO - 2023-07-01 18:11:40 --> Helper loaded: file_helper
INFO - 2023-07-01 18:11:40 --> Helper loaded: html_helper
INFO - 2023-07-01 18:11:40 --> Helper loaded: text_helper
INFO - 2023-07-01 18:11:40 --> Helper loaded: form_helper
INFO - 2023-07-01 18:11:40 --> Helper loaded: lang_helper
INFO - 2023-07-01 18:11:40 --> Helper loaded: security_helper
INFO - 2023-07-01 18:11:40 --> Helper loaded: cookie_helper
INFO - 2023-07-01 18:11:40 --> Database Driver Class Initialized
INFO - 2023-07-01 18:11:40 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-01 18:11:40 --> Parser Class Initialized
INFO - 2023-07-01 18:11:40 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-01 18:11:40 --> Pagination Class Initialized
INFO - 2023-07-01 18:11:40 --> Form Validation Class Initialized
INFO - 2023-07-01 18:11:40 --> Controller Class Initialized
INFO - 2023-07-01 18:11:40 --> Model Class Initialized
DEBUG - 2023-07-01 18:11:40 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-01 18:11:40 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-01 18:11:40 --> Model Class Initialized
DEBUG - 2023-07-01 18:11:40 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-01 18:11:40 --> Model Class Initialized
INFO - 2023-07-01 18:11:40 --> Final output sent to browser
DEBUG - 2023-07-01 18:11:40 --> Total execution time: 0.0452
ERROR - 2023-07-01 18:11:45 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-01 18:11:45 --> Config Class Initialized
INFO - 2023-07-01 18:11:45 --> Hooks Class Initialized
DEBUG - 2023-07-01 18:11:45 --> UTF-8 Support Enabled
INFO - 2023-07-01 18:11:45 --> Utf8 Class Initialized
INFO - 2023-07-01 18:11:45 --> URI Class Initialized
INFO - 2023-07-01 18:11:45 --> Router Class Initialized
INFO - 2023-07-01 18:11:45 --> Output Class Initialized
INFO - 2023-07-01 18:11:45 --> Security Class Initialized
DEBUG - 2023-07-01 18:11:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-01 18:11:45 --> Input Class Initialized
INFO - 2023-07-01 18:11:45 --> Language Class Initialized
INFO - 2023-07-01 18:11:45 --> Loader Class Initialized
INFO - 2023-07-01 18:11:45 --> Helper loaded: url_helper
INFO - 2023-07-01 18:11:45 --> Helper loaded: file_helper
INFO - 2023-07-01 18:11:45 --> Helper loaded: html_helper
INFO - 2023-07-01 18:11:45 --> Helper loaded: text_helper
INFO - 2023-07-01 18:11:45 --> Helper loaded: form_helper
INFO - 2023-07-01 18:11:45 --> Helper loaded: lang_helper
INFO - 2023-07-01 18:11:45 --> Helper loaded: security_helper
INFO - 2023-07-01 18:11:45 --> Helper loaded: cookie_helper
INFO - 2023-07-01 18:11:45 --> Database Driver Class Initialized
INFO - 2023-07-01 18:11:45 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-01 18:11:45 --> Parser Class Initialized
INFO - 2023-07-01 18:11:45 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-01 18:11:45 --> Pagination Class Initialized
INFO - 2023-07-01 18:11:45 --> Form Validation Class Initialized
INFO - 2023-07-01 18:11:45 --> Controller Class Initialized
INFO - 2023-07-01 18:11:45 --> Model Class Initialized
DEBUG - 2023-07-01 18:11:45 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-01 18:11:45 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-01 18:11:45 --> Model Class Initialized
DEBUG - 2023-07-01 18:11:45 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-01 18:11:45 --> Model Class Initialized
ERROR - 2023-07-01 18:11:45 --> Severity: Warning --> Invalid argument supplied for foreach() /home/powera7m/app.maurnaturo.com/application/views/invoice/add_pos_invoice_form.php 364
INFO - 2023-07-01 18:11:45 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/invoice/add_pos_invoice_form.php
DEBUG - 2023-07-01 18:11:45 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-07-01 18:11:45 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-07-01 18:11:45 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-07-01 18:11:45 --> Model Class Initialized
INFO - 2023-07-01 18:11:45 --> Model Class Initialized
INFO - 2023-07-01 18:11:45 --> Model Class Initialized
INFO - 2023-07-01 18:11:45 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-07-01 18:11:45 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-07-01 18:11:45 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-07-01 18:11:45 --> Final output sent to browser
DEBUG - 2023-07-01 18:11:45 --> Total execution time: 0.1697
ERROR - 2023-07-01 18:37:04 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-01 18:37:04 --> Config Class Initialized
INFO - 2023-07-01 18:37:04 --> Hooks Class Initialized
DEBUG - 2023-07-01 18:37:04 --> UTF-8 Support Enabled
INFO - 2023-07-01 18:37:04 --> Utf8 Class Initialized
INFO - 2023-07-01 18:37:04 --> URI Class Initialized
DEBUG - 2023-07-01 18:37:04 --> No URI present. Default controller set.
INFO - 2023-07-01 18:37:04 --> Router Class Initialized
INFO - 2023-07-01 18:37:04 --> Output Class Initialized
INFO - 2023-07-01 18:37:04 --> Security Class Initialized
DEBUG - 2023-07-01 18:37:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-01 18:37:04 --> Input Class Initialized
INFO - 2023-07-01 18:37:04 --> Language Class Initialized
INFO - 2023-07-01 18:37:04 --> Loader Class Initialized
INFO - 2023-07-01 18:37:04 --> Helper loaded: url_helper
INFO - 2023-07-01 18:37:04 --> Helper loaded: file_helper
INFO - 2023-07-01 18:37:04 --> Helper loaded: html_helper
INFO - 2023-07-01 18:37:04 --> Helper loaded: text_helper
INFO - 2023-07-01 18:37:04 --> Helper loaded: form_helper
INFO - 2023-07-01 18:37:04 --> Helper loaded: lang_helper
INFO - 2023-07-01 18:37:04 --> Helper loaded: security_helper
INFO - 2023-07-01 18:37:04 --> Helper loaded: cookie_helper
INFO - 2023-07-01 18:37:04 --> Database Driver Class Initialized
INFO - 2023-07-01 18:37:04 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-01 18:37:04 --> Parser Class Initialized
INFO - 2023-07-01 18:37:04 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-01 18:37:04 --> Pagination Class Initialized
INFO - 2023-07-01 18:37:04 --> Form Validation Class Initialized
INFO - 2023-07-01 18:37:04 --> Controller Class Initialized
INFO - 2023-07-01 18:37:04 --> Model Class Initialized
DEBUG - 2023-07-01 18:37:04 --> Session class already loaded. Second attempt ignored.
ERROR - 2023-07-01 18:37:44 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-01 18:37:44 --> Config Class Initialized
INFO - 2023-07-01 18:37:44 --> Hooks Class Initialized
DEBUG - 2023-07-01 18:37:44 --> UTF-8 Support Enabled
INFO - 2023-07-01 18:37:44 --> Utf8 Class Initialized
INFO - 2023-07-01 18:37:44 --> URI Class Initialized
INFO - 2023-07-01 18:37:44 --> Router Class Initialized
INFO - 2023-07-01 18:37:44 --> Output Class Initialized
INFO - 2023-07-01 18:37:44 --> Security Class Initialized
DEBUG - 2023-07-01 18:37:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-01 18:37:44 --> Input Class Initialized
INFO - 2023-07-01 18:37:44 --> Language Class Initialized
INFO - 2023-07-01 18:37:44 --> Loader Class Initialized
INFO - 2023-07-01 18:37:44 --> Helper loaded: url_helper
INFO - 2023-07-01 18:37:44 --> Helper loaded: file_helper
INFO - 2023-07-01 18:37:44 --> Helper loaded: html_helper
INFO - 2023-07-01 18:37:44 --> Helper loaded: text_helper
INFO - 2023-07-01 18:37:44 --> Helper loaded: form_helper
INFO - 2023-07-01 18:37:44 --> Helper loaded: lang_helper
INFO - 2023-07-01 18:37:44 --> Helper loaded: security_helper
INFO - 2023-07-01 18:37:44 --> Helper loaded: cookie_helper
INFO - 2023-07-01 18:37:44 --> Database Driver Class Initialized
INFO - 2023-07-01 18:37:44 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-01 18:37:44 --> Parser Class Initialized
INFO - 2023-07-01 18:37:44 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-01 18:37:44 --> Pagination Class Initialized
INFO - 2023-07-01 18:37:44 --> Form Validation Class Initialized
INFO - 2023-07-01 18:37:44 --> Controller Class Initialized
INFO - 2023-07-01 18:37:44 --> Model Class Initialized
DEBUG - 2023-07-01 18:37:44 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-01 18:37:44 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2023-07-01 18:37:44 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-07-01 18:37:44 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-07-01 18:37:44 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-07-01 18:37:44 --> Model Class Initialized
INFO - 2023-07-01 18:37:44 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-07-01 18:37:44 --> Final output sent to browser
DEBUG - 2023-07-01 18:37:44 --> Total execution time: 0.0298
ERROR - 2023-07-01 19:26:26 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-01 19:26:26 --> Config Class Initialized
INFO - 2023-07-01 19:26:26 --> Hooks Class Initialized
DEBUG - 2023-07-01 19:26:26 --> UTF-8 Support Enabled
INFO - 2023-07-01 19:26:26 --> Utf8 Class Initialized
INFO - 2023-07-01 19:26:26 --> URI Class Initialized
INFO - 2023-07-01 19:26:26 --> Router Class Initialized
INFO - 2023-07-01 19:26:26 --> Output Class Initialized
INFO - 2023-07-01 19:26:26 --> Security Class Initialized
DEBUG - 2023-07-01 19:26:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-01 19:26:26 --> Input Class Initialized
INFO - 2023-07-01 19:26:26 --> Language Class Initialized
INFO - 2023-07-01 19:26:26 --> Loader Class Initialized
INFO - 2023-07-01 19:26:26 --> Helper loaded: url_helper
INFO - 2023-07-01 19:26:26 --> Helper loaded: file_helper
INFO - 2023-07-01 19:26:26 --> Helper loaded: html_helper
INFO - 2023-07-01 19:26:26 --> Helper loaded: text_helper
INFO - 2023-07-01 19:26:26 --> Helper loaded: form_helper
INFO - 2023-07-01 19:26:26 --> Helper loaded: lang_helper
INFO - 2023-07-01 19:26:26 --> Helper loaded: security_helper
INFO - 2023-07-01 19:26:26 --> Helper loaded: cookie_helper
INFO - 2023-07-01 19:26:26 --> Database Driver Class Initialized
INFO - 2023-07-01 19:26:26 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-01 19:26:26 --> Parser Class Initialized
INFO - 2023-07-01 19:26:26 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-01 19:26:26 --> Pagination Class Initialized
INFO - 2023-07-01 19:26:26 --> Form Validation Class Initialized
INFO - 2023-07-01 19:26:26 --> Controller Class Initialized
