<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2023-09-19 01:45:25 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-19 01:45:25 --> Config Class Initialized
INFO - 2023-09-19 01:45:25 --> Hooks Class Initialized
DEBUG - 2023-09-19 01:45:25 --> UTF-8 Support Enabled
INFO - 2023-09-19 01:45:25 --> Utf8 Class Initialized
INFO - 2023-09-19 01:45:25 --> URI Class Initialized
DEBUG - 2023-09-19 01:45:25 --> No URI present. Default controller set.
INFO - 2023-09-19 01:45:25 --> Router Class Initialized
INFO - 2023-09-19 01:45:25 --> Output Class Initialized
INFO - 2023-09-19 01:45:25 --> Security Class Initialized
DEBUG - 2023-09-19 01:45:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-19 01:45:25 --> Input Class Initialized
INFO - 2023-09-19 01:45:25 --> Language Class Initialized
INFO - 2023-09-19 01:45:25 --> Loader Class Initialized
INFO - 2023-09-19 01:45:25 --> Helper loaded: url_helper
INFO - 2023-09-19 01:45:25 --> Helper loaded: file_helper
INFO - 2023-09-19 01:45:25 --> Helper loaded: html_helper
INFO - 2023-09-19 01:45:25 --> Helper loaded: text_helper
INFO - 2023-09-19 01:45:25 --> Helper loaded: form_helper
INFO - 2023-09-19 01:45:25 --> Helper loaded: lang_helper
INFO - 2023-09-19 01:45:25 --> Helper loaded: security_helper
INFO - 2023-09-19 01:45:25 --> Helper loaded: cookie_helper
INFO - 2023-09-19 01:45:25 --> Database Driver Class Initialized
INFO - 2023-09-19 01:45:25 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-19 01:45:25 --> Parser Class Initialized
INFO - 2023-09-19 01:45:25 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-19 01:45:25 --> Pagination Class Initialized
INFO - 2023-09-19 01:45:25 --> Form Validation Class Initialized
INFO - 2023-09-19 01:45:25 --> Controller Class Initialized
INFO - 2023-09-19 01:45:25 --> Model Class Initialized
DEBUG - 2023-09-19 01:45:25 --> Session class already loaded. Second attempt ignored.
ERROR - 2023-09-19 01:45:26 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-19 01:45:26 --> Config Class Initialized
INFO - 2023-09-19 01:45:26 --> Hooks Class Initialized
DEBUG - 2023-09-19 01:45:26 --> UTF-8 Support Enabled
INFO - 2023-09-19 01:45:26 --> Utf8 Class Initialized
INFO - 2023-09-19 01:45:26 --> URI Class Initialized
INFO - 2023-09-19 01:45:26 --> Router Class Initialized
INFO - 2023-09-19 01:45:26 --> Output Class Initialized
INFO - 2023-09-19 01:45:26 --> Security Class Initialized
DEBUG - 2023-09-19 01:45:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-19 01:45:26 --> Input Class Initialized
INFO - 2023-09-19 01:45:26 --> Language Class Initialized
INFO - 2023-09-19 01:45:26 --> Loader Class Initialized
INFO - 2023-09-19 01:45:26 --> Helper loaded: url_helper
INFO - 2023-09-19 01:45:26 --> Helper loaded: file_helper
INFO - 2023-09-19 01:45:26 --> Helper loaded: html_helper
INFO - 2023-09-19 01:45:26 --> Helper loaded: text_helper
INFO - 2023-09-19 01:45:26 --> Helper loaded: form_helper
INFO - 2023-09-19 01:45:26 --> Helper loaded: lang_helper
INFO - 2023-09-19 01:45:26 --> Helper loaded: security_helper
INFO - 2023-09-19 01:45:26 --> Helper loaded: cookie_helper
INFO - 2023-09-19 01:45:26 --> Database Driver Class Initialized
INFO - 2023-09-19 01:45:26 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-19 01:45:26 --> Parser Class Initialized
INFO - 2023-09-19 01:45:26 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-19 01:45:26 --> Pagination Class Initialized
INFO - 2023-09-19 01:45:26 --> Form Validation Class Initialized
INFO - 2023-09-19 01:45:26 --> Controller Class Initialized
INFO - 2023-09-19 01:45:26 --> Model Class Initialized
DEBUG - 2023-09-19 01:45:26 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-19 01:45:26 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2023-09-19 01:45:26 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-09-19 01:45:26 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-09-19 01:45:26 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-09-19 01:45:26 --> Model Class Initialized
INFO - 2023-09-19 01:45:26 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-09-19 01:45:26 --> Final output sent to browser
DEBUG - 2023-09-19 01:45:26 --> Total execution time: 0.0328
ERROR - 2023-09-19 01:58:52 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-19 01:58:52 --> Config Class Initialized
INFO - 2023-09-19 01:58:52 --> Hooks Class Initialized
DEBUG - 2023-09-19 01:58:52 --> UTF-8 Support Enabled
INFO - 2023-09-19 01:58:52 --> Utf8 Class Initialized
INFO - 2023-09-19 01:58:52 --> URI Class Initialized
DEBUG - 2023-09-19 01:58:52 --> No URI present. Default controller set.
INFO - 2023-09-19 01:58:52 --> Router Class Initialized
INFO - 2023-09-19 01:58:52 --> Output Class Initialized
INFO - 2023-09-19 01:58:52 --> Security Class Initialized
DEBUG - 2023-09-19 01:58:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-19 01:58:52 --> Input Class Initialized
INFO - 2023-09-19 01:58:52 --> Language Class Initialized
INFO - 2023-09-19 01:58:52 --> Loader Class Initialized
INFO - 2023-09-19 01:58:52 --> Helper loaded: url_helper
INFO - 2023-09-19 01:58:52 --> Helper loaded: file_helper
INFO - 2023-09-19 01:58:52 --> Helper loaded: html_helper
INFO - 2023-09-19 01:58:52 --> Helper loaded: text_helper
INFO - 2023-09-19 01:58:52 --> Helper loaded: form_helper
INFO - 2023-09-19 01:58:52 --> Helper loaded: lang_helper
INFO - 2023-09-19 01:58:52 --> Helper loaded: security_helper
INFO - 2023-09-19 01:58:52 --> Helper loaded: cookie_helper
INFO - 2023-09-19 01:58:52 --> Database Driver Class Initialized
INFO - 2023-09-19 01:58:52 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-19 01:58:52 --> Parser Class Initialized
INFO - 2023-09-19 01:58:52 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-19 01:58:52 --> Pagination Class Initialized
INFO - 2023-09-19 01:58:52 --> Form Validation Class Initialized
INFO - 2023-09-19 01:58:52 --> Controller Class Initialized
INFO - 2023-09-19 01:58:52 --> Model Class Initialized
DEBUG - 2023-09-19 01:58:52 --> Session class already loaded. Second attempt ignored.
ERROR - 2023-09-19 01:58:52 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-19 01:58:52 --> Config Class Initialized
INFO - 2023-09-19 01:58:52 --> Hooks Class Initialized
DEBUG - 2023-09-19 01:58:52 --> UTF-8 Support Enabled
INFO - 2023-09-19 01:58:52 --> Utf8 Class Initialized
INFO - 2023-09-19 01:58:52 --> URI Class Initialized
INFO - 2023-09-19 01:58:52 --> Router Class Initialized
INFO - 2023-09-19 01:58:52 --> Output Class Initialized
INFO - 2023-09-19 01:58:52 --> Security Class Initialized
DEBUG - 2023-09-19 01:58:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-19 01:58:52 --> Input Class Initialized
INFO - 2023-09-19 01:58:52 --> Language Class Initialized
INFO - 2023-09-19 01:58:52 --> Loader Class Initialized
INFO - 2023-09-19 01:58:52 --> Helper loaded: url_helper
INFO - 2023-09-19 01:58:52 --> Helper loaded: file_helper
INFO - 2023-09-19 01:58:52 --> Helper loaded: html_helper
INFO - 2023-09-19 01:58:52 --> Helper loaded: text_helper
INFO - 2023-09-19 01:58:52 --> Helper loaded: form_helper
INFO - 2023-09-19 01:58:52 --> Helper loaded: lang_helper
INFO - 2023-09-19 01:58:52 --> Helper loaded: security_helper
INFO - 2023-09-19 01:58:52 --> Helper loaded: cookie_helper
INFO - 2023-09-19 01:58:52 --> Database Driver Class Initialized
INFO - 2023-09-19 01:58:52 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-19 01:58:52 --> Parser Class Initialized
INFO - 2023-09-19 01:58:52 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-19 01:58:52 --> Pagination Class Initialized
INFO - 2023-09-19 01:58:52 --> Form Validation Class Initialized
INFO - 2023-09-19 01:58:52 --> Controller Class Initialized
INFO - 2023-09-19 01:58:52 --> Model Class Initialized
DEBUG - 2023-09-19 01:58:52 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-19 01:58:52 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2023-09-19 01:58:52 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-09-19 01:58:52 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-09-19 01:58:52 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-09-19 01:58:52 --> Model Class Initialized
INFO - 2023-09-19 01:58:52 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-09-19 01:58:52 --> Final output sent to browser
DEBUG - 2023-09-19 01:58:52 --> Total execution time: 0.0640
ERROR - 2023-09-19 02:00:08 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-19 02:00:08 --> Config Class Initialized
INFO - 2023-09-19 02:00:08 --> Hooks Class Initialized
DEBUG - 2023-09-19 02:00:08 --> UTF-8 Support Enabled
INFO - 2023-09-19 02:00:08 --> Utf8 Class Initialized
INFO - 2023-09-19 02:00:08 --> URI Class Initialized
INFO - 2023-09-19 02:00:08 --> Router Class Initialized
INFO - 2023-09-19 02:00:08 --> Output Class Initialized
INFO - 2023-09-19 02:00:08 --> Security Class Initialized
DEBUG - 2023-09-19 02:00:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-19 02:00:08 --> Input Class Initialized
INFO - 2023-09-19 02:00:08 --> Language Class Initialized
INFO - 2023-09-19 02:00:08 --> Loader Class Initialized
INFO - 2023-09-19 02:00:08 --> Helper loaded: url_helper
INFO - 2023-09-19 02:00:08 --> Helper loaded: file_helper
INFO - 2023-09-19 02:00:08 --> Helper loaded: html_helper
INFO - 2023-09-19 02:00:08 --> Helper loaded: text_helper
INFO - 2023-09-19 02:00:08 --> Helper loaded: form_helper
INFO - 2023-09-19 02:00:08 --> Helper loaded: lang_helper
INFO - 2023-09-19 02:00:08 --> Helper loaded: security_helper
INFO - 2023-09-19 02:00:08 --> Helper loaded: cookie_helper
INFO - 2023-09-19 02:00:08 --> Database Driver Class Initialized
INFO - 2023-09-19 02:00:08 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-19 02:00:08 --> Parser Class Initialized
INFO - 2023-09-19 02:00:08 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-19 02:00:08 --> Pagination Class Initialized
INFO - 2023-09-19 02:00:08 --> Form Validation Class Initialized
INFO - 2023-09-19 02:00:08 --> Controller Class Initialized
INFO - 2023-09-19 02:00:08 --> Model Class Initialized
DEBUG - 2023-09-19 02:00:08 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-19 02:00:08 --> Model Class Initialized
INFO - 2023-09-19 02:00:08 --> Final output sent to browser
DEBUG - 2023-09-19 02:00:08 --> Total execution time: 0.0221
ERROR - 2023-09-19 02:00:09 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-19 02:00:09 --> Config Class Initialized
INFO - 2023-09-19 02:00:09 --> Hooks Class Initialized
DEBUG - 2023-09-19 02:00:09 --> UTF-8 Support Enabled
INFO - 2023-09-19 02:00:09 --> Utf8 Class Initialized
INFO - 2023-09-19 02:00:09 --> URI Class Initialized
DEBUG - 2023-09-19 02:00:09 --> No URI present. Default controller set.
INFO - 2023-09-19 02:00:09 --> Router Class Initialized
INFO - 2023-09-19 02:00:09 --> Output Class Initialized
INFO - 2023-09-19 02:00:09 --> Security Class Initialized
DEBUG - 2023-09-19 02:00:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-19 02:00:09 --> Input Class Initialized
INFO - 2023-09-19 02:00:09 --> Language Class Initialized
INFO - 2023-09-19 02:00:09 --> Loader Class Initialized
INFO - 2023-09-19 02:00:09 --> Helper loaded: url_helper
INFO - 2023-09-19 02:00:09 --> Helper loaded: file_helper
INFO - 2023-09-19 02:00:09 --> Helper loaded: html_helper
INFO - 2023-09-19 02:00:09 --> Helper loaded: text_helper
INFO - 2023-09-19 02:00:09 --> Helper loaded: form_helper
INFO - 2023-09-19 02:00:09 --> Helper loaded: lang_helper
INFO - 2023-09-19 02:00:09 --> Helper loaded: security_helper
INFO - 2023-09-19 02:00:09 --> Helper loaded: cookie_helper
INFO - 2023-09-19 02:00:09 --> Database Driver Class Initialized
INFO - 2023-09-19 02:00:09 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-19 02:00:09 --> Parser Class Initialized
INFO - 2023-09-19 02:00:09 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-19 02:00:09 --> Pagination Class Initialized
INFO - 2023-09-19 02:00:09 --> Form Validation Class Initialized
INFO - 2023-09-19 02:00:09 --> Controller Class Initialized
INFO - 2023-09-19 02:00:09 --> Model Class Initialized
DEBUG - 2023-09-19 02:00:09 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-19 02:00:09 --> Model Class Initialized
DEBUG - 2023-09-19 02:00:09 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-19 02:00:09 --> Model Class Initialized
INFO - 2023-09-19 02:00:09 --> Model Class Initialized
INFO - 2023-09-19 02:00:09 --> Model Class Initialized
INFO - 2023-09-19 02:00:09 --> Model Class Initialized
DEBUG - 2023-09-19 02:00:09 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-09-19 02:00:09 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-19 02:00:09 --> Model Class Initialized
INFO - 2023-09-19 02:00:09 --> Model Class Initialized
INFO - 2023-09-19 02:00:09 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-09-19 02:00:09 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-09-19 02:00:09 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-09-19 02:00:09 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-09-19 02:00:09 --> Model Class Initialized
INFO - 2023-09-19 02:00:09 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-09-19 02:00:09 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-09-19 02:00:09 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-09-19 02:00:09 --> Final output sent to browser
DEBUG - 2023-09-19 02:00:09 --> Total execution time: 0.1294
ERROR - 2023-09-19 02:00:36 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-19 02:00:36 --> Config Class Initialized
INFO - 2023-09-19 02:00:36 --> Hooks Class Initialized
DEBUG - 2023-09-19 02:00:36 --> UTF-8 Support Enabled
INFO - 2023-09-19 02:00:36 --> Utf8 Class Initialized
INFO - 2023-09-19 02:00:36 --> URI Class Initialized
INFO - 2023-09-19 02:00:36 --> Router Class Initialized
INFO - 2023-09-19 02:00:36 --> Output Class Initialized
INFO - 2023-09-19 02:00:36 --> Security Class Initialized
DEBUG - 2023-09-19 02:00:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-19 02:00:36 --> Input Class Initialized
INFO - 2023-09-19 02:00:36 --> Language Class Initialized
INFO - 2023-09-19 02:00:36 --> Loader Class Initialized
INFO - 2023-09-19 02:00:36 --> Helper loaded: url_helper
INFO - 2023-09-19 02:00:36 --> Helper loaded: file_helper
INFO - 2023-09-19 02:00:36 --> Helper loaded: html_helper
INFO - 2023-09-19 02:00:36 --> Helper loaded: text_helper
INFO - 2023-09-19 02:00:36 --> Helper loaded: form_helper
INFO - 2023-09-19 02:00:36 --> Helper loaded: lang_helper
INFO - 2023-09-19 02:00:36 --> Helper loaded: security_helper
INFO - 2023-09-19 02:00:36 --> Helper loaded: cookie_helper
INFO - 2023-09-19 02:00:36 --> Database Driver Class Initialized
INFO - 2023-09-19 02:00:36 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-19 02:00:36 --> Parser Class Initialized
INFO - 2023-09-19 02:00:36 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-19 02:00:36 --> Pagination Class Initialized
INFO - 2023-09-19 02:00:36 --> Form Validation Class Initialized
INFO - 2023-09-19 02:00:36 --> Controller Class Initialized
INFO - 2023-09-19 02:00:36 --> Model Class Initialized
DEBUG - 2023-09-19 02:00:36 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-19 02:00:36 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2023-09-19 02:00:36 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-09-19 02:00:36 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-09-19 02:00:36 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-09-19 02:00:36 --> Model Class Initialized
INFO - 2023-09-19 02:00:36 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-09-19 02:00:36 --> Final output sent to browser
DEBUG - 2023-09-19 02:00:36 --> Total execution time: 0.0331
ERROR - 2023-09-19 02:00:38 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-19 02:00:38 --> Config Class Initialized
INFO - 2023-09-19 02:00:38 --> Hooks Class Initialized
DEBUG - 2023-09-19 02:00:38 --> UTF-8 Support Enabled
INFO - 2023-09-19 02:00:38 --> Utf8 Class Initialized
INFO - 2023-09-19 02:00:38 --> URI Class Initialized
INFO - 2023-09-19 02:00:38 --> Router Class Initialized
INFO - 2023-09-19 02:00:38 --> Output Class Initialized
INFO - 2023-09-19 02:00:38 --> Security Class Initialized
DEBUG - 2023-09-19 02:00:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-19 02:00:38 --> Input Class Initialized
INFO - 2023-09-19 02:00:38 --> Language Class Initialized
INFO - 2023-09-19 02:00:38 --> Loader Class Initialized
INFO - 2023-09-19 02:00:38 --> Helper loaded: url_helper
INFO - 2023-09-19 02:00:38 --> Helper loaded: file_helper
INFO - 2023-09-19 02:00:38 --> Helper loaded: html_helper
INFO - 2023-09-19 02:00:38 --> Helper loaded: text_helper
INFO - 2023-09-19 02:00:38 --> Helper loaded: form_helper
INFO - 2023-09-19 02:00:38 --> Helper loaded: lang_helper
INFO - 2023-09-19 02:00:38 --> Helper loaded: security_helper
INFO - 2023-09-19 02:00:38 --> Helper loaded: cookie_helper
INFO - 2023-09-19 02:00:38 --> Database Driver Class Initialized
INFO - 2023-09-19 02:00:38 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-19 02:00:38 --> Parser Class Initialized
INFO - 2023-09-19 02:00:38 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-19 02:00:38 --> Pagination Class Initialized
INFO - 2023-09-19 02:00:38 --> Form Validation Class Initialized
INFO - 2023-09-19 02:00:38 --> Controller Class Initialized
INFO - 2023-09-19 02:00:38 --> Model Class Initialized
DEBUG - 2023-09-19 02:00:38 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-19 02:00:38 --> Model Class Initialized
DEBUG - 2023-09-19 02:00:38 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-19 02:00:38 --> Model Class Initialized
INFO - 2023-09-19 02:00:38 --> Model Class Initialized
INFO - 2023-09-19 02:00:38 --> Model Class Initialized
INFO - 2023-09-19 02:00:38 --> Model Class Initialized
DEBUG - 2023-09-19 02:00:38 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-09-19 02:00:38 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-19 02:00:38 --> Model Class Initialized
INFO - 2023-09-19 02:00:38 --> Model Class Initialized
INFO - 2023-09-19 02:00:39 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-09-19 02:00:39 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-09-19 02:00:39 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-09-19 02:00:39 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-09-19 02:00:39 --> Model Class Initialized
INFO - 2023-09-19 02:00:39 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-09-19 02:00:39 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-09-19 02:00:39 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-09-19 02:00:39 --> Final output sent to browser
DEBUG - 2023-09-19 02:00:39 --> Total execution time: 0.1040
ERROR - 2023-09-19 02:17:15 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-19 02:17:15 --> Config Class Initialized
INFO - 2023-09-19 02:17:15 --> Hooks Class Initialized
DEBUG - 2023-09-19 02:17:15 --> UTF-8 Support Enabled
INFO - 2023-09-19 02:17:15 --> Utf8 Class Initialized
INFO - 2023-09-19 02:17:15 --> URI Class Initialized
DEBUG - 2023-09-19 02:17:15 --> No URI present. Default controller set.
INFO - 2023-09-19 02:17:15 --> Router Class Initialized
INFO - 2023-09-19 02:17:15 --> Output Class Initialized
INFO - 2023-09-19 02:17:15 --> Security Class Initialized
DEBUG - 2023-09-19 02:17:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-19 02:17:15 --> Input Class Initialized
INFO - 2023-09-19 02:17:15 --> Language Class Initialized
INFO - 2023-09-19 02:17:15 --> Loader Class Initialized
INFO - 2023-09-19 02:17:15 --> Helper loaded: url_helper
INFO - 2023-09-19 02:17:15 --> Helper loaded: file_helper
INFO - 2023-09-19 02:17:15 --> Helper loaded: html_helper
INFO - 2023-09-19 02:17:15 --> Helper loaded: text_helper
INFO - 2023-09-19 02:17:15 --> Helper loaded: form_helper
INFO - 2023-09-19 02:17:15 --> Helper loaded: lang_helper
INFO - 2023-09-19 02:17:15 --> Helper loaded: security_helper
INFO - 2023-09-19 02:17:15 --> Helper loaded: cookie_helper
INFO - 2023-09-19 02:17:15 --> Database Driver Class Initialized
INFO - 2023-09-19 02:17:15 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-19 02:17:15 --> Parser Class Initialized
INFO - 2023-09-19 02:17:15 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-19 02:17:15 --> Pagination Class Initialized
INFO - 2023-09-19 02:17:15 --> Form Validation Class Initialized
INFO - 2023-09-19 02:17:15 --> Controller Class Initialized
INFO - 2023-09-19 02:17:15 --> Model Class Initialized
DEBUG - 2023-09-19 02:17:15 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-19 02:17:15 --> Model Class Initialized
DEBUG - 2023-09-19 02:17:15 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-19 02:17:15 --> Model Class Initialized
INFO - 2023-09-19 02:17:15 --> Model Class Initialized
INFO - 2023-09-19 02:17:15 --> Model Class Initialized
INFO - 2023-09-19 02:17:15 --> Model Class Initialized
DEBUG - 2023-09-19 02:17:15 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-09-19 02:17:15 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-19 02:17:15 --> Model Class Initialized
INFO - 2023-09-19 02:17:15 --> Model Class Initialized
INFO - 2023-09-19 02:17:15 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-09-19 02:17:15 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-09-19 02:17:15 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-09-19 02:17:15 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-09-19 02:17:15 --> Model Class Initialized
INFO - 2023-09-19 02:17:15 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-09-19 02:17:15 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-09-19 02:17:15 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-09-19 02:17:15 --> Final output sent to browser
DEBUG - 2023-09-19 02:17:15 --> Total execution time: 0.1085
ERROR - 2023-09-19 02:17:19 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-19 02:17:19 --> Config Class Initialized
INFO - 2023-09-19 02:17:19 --> Hooks Class Initialized
DEBUG - 2023-09-19 02:17:19 --> UTF-8 Support Enabled
INFO - 2023-09-19 02:17:19 --> Utf8 Class Initialized
INFO - 2023-09-19 02:17:19 --> URI Class Initialized
INFO - 2023-09-19 02:17:19 --> Router Class Initialized
INFO - 2023-09-19 02:17:19 --> Output Class Initialized
INFO - 2023-09-19 02:17:19 --> Security Class Initialized
DEBUG - 2023-09-19 02:17:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-19 02:17:19 --> Input Class Initialized
INFO - 2023-09-19 02:17:19 --> Language Class Initialized
INFO - 2023-09-19 02:17:19 --> Loader Class Initialized
INFO - 2023-09-19 02:17:19 --> Helper loaded: url_helper
INFO - 2023-09-19 02:17:19 --> Helper loaded: file_helper
INFO - 2023-09-19 02:17:19 --> Helper loaded: html_helper
INFO - 2023-09-19 02:17:19 --> Helper loaded: text_helper
INFO - 2023-09-19 02:17:19 --> Helper loaded: form_helper
INFO - 2023-09-19 02:17:19 --> Helper loaded: lang_helper
INFO - 2023-09-19 02:17:19 --> Helper loaded: security_helper
INFO - 2023-09-19 02:17:19 --> Helper loaded: cookie_helper
INFO - 2023-09-19 02:17:19 --> Database Driver Class Initialized
INFO - 2023-09-19 02:17:19 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-19 02:17:19 --> Parser Class Initialized
INFO - 2023-09-19 02:17:19 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-19 02:17:19 --> Pagination Class Initialized
INFO - 2023-09-19 02:17:19 --> Form Validation Class Initialized
INFO - 2023-09-19 02:17:19 --> Controller Class Initialized
INFO - 2023-09-19 02:17:19 --> Model Class Initialized
DEBUG - 2023-09-19 02:17:19 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-09-19 02:17:19 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-19 02:17:19 --> Model Class Initialized
DEBUG - 2023-09-19 02:17:19 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-19 02:17:19 --> Model Class Initialized
INFO - 2023-09-19 02:17:19 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice.php
DEBUG - 2023-09-19 02:17:19 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-09-19 02:17:19 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-09-19 02:17:19 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-09-19 02:17:19 --> Model Class Initialized
INFO - 2023-09-19 02:17:19 --> Model Class Initialized
INFO - 2023-09-19 02:17:19 --> Model Class Initialized
INFO - 2023-09-19 02:17:19 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-09-19 02:17:19 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-09-19 02:17:19 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-09-19 02:17:19 --> Final output sent to browser
DEBUG - 2023-09-19 02:17:19 --> Total execution time: 0.0872
ERROR - 2023-09-19 02:17:20 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-19 02:17:20 --> Config Class Initialized
INFO - 2023-09-19 02:17:20 --> Hooks Class Initialized
DEBUG - 2023-09-19 02:17:20 --> UTF-8 Support Enabled
INFO - 2023-09-19 02:17:20 --> Utf8 Class Initialized
INFO - 2023-09-19 02:17:20 --> URI Class Initialized
INFO - 2023-09-19 02:17:20 --> Router Class Initialized
INFO - 2023-09-19 02:17:20 --> Output Class Initialized
INFO - 2023-09-19 02:17:20 --> Security Class Initialized
DEBUG - 2023-09-19 02:17:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-19 02:17:20 --> Input Class Initialized
INFO - 2023-09-19 02:17:20 --> Language Class Initialized
INFO - 2023-09-19 02:17:20 --> Loader Class Initialized
INFO - 2023-09-19 02:17:20 --> Helper loaded: url_helper
INFO - 2023-09-19 02:17:20 --> Helper loaded: file_helper
INFO - 2023-09-19 02:17:20 --> Helper loaded: html_helper
INFO - 2023-09-19 02:17:20 --> Helper loaded: text_helper
INFO - 2023-09-19 02:17:20 --> Helper loaded: form_helper
INFO - 2023-09-19 02:17:20 --> Helper loaded: lang_helper
INFO - 2023-09-19 02:17:20 --> Helper loaded: security_helper
INFO - 2023-09-19 02:17:20 --> Helper loaded: cookie_helper
INFO - 2023-09-19 02:17:20 --> Database Driver Class Initialized
INFO - 2023-09-19 02:17:20 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-19 02:17:20 --> Parser Class Initialized
INFO - 2023-09-19 02:17:20 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-19 02:17:20 --> Pagination Class Initialized
INFO - 2023-09-19 02:17:20 --> Form Validation Class Initialized
INFO - 2023-09-19 02:17:20 --> Controller Class Initialized
INFO - 2023-09-19 02:17:20 --> Model Class Initialized
DEBUG - 2023-09-19 02:17:20 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-09-19 02:17:20 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-19 02:17:20 --> Model Class Initialized
DEBUG - 2023-09-19 02:17:20 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-19 02:17:20 --> Model Class Initialized
INFO - 2023-09-19 02:17:20 --> Final output sent to browser
DEBUG - 2023-09-19 02:17:20 --> Total execution time: 0.0407
ERROR - 2023-09-19 02:17:25 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-19 02:17:25 --> Config Class Initialized
INFO - 2023-09-19 02:17:25 --> Hooks Class Initialized
DEBUG - 2023-09-19 02:17:25 --> UTF-8 Support Enabled
INFO - 2023-09-19 02:17:25 --> Utf8 Class Initialized
INFO - 2023-09-19 02:17:25 --> URI Class Initialized
INFO - 2023-09-19 02:17:25 --> Router Class Initialized
INFO - 2023-09-19 02:17:25 --> Output Class Initialized
INFO - 2023-09-19 02:17:25 --> Security Class Initialized
DEBUG - 2023-09-19 02:17:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-19 02:17:25 --> Input Class Initialized
INFO - 2023-09-19 02:17:25 --> Language Class Initialized
INFO - 2023-09-19 02:17:25 --> Loader Class Initialized
INFO - 2023-09-19 02:17:25 --> Helper loaded: url_helper
INFO - 2023-09-19 02:17:25 --> Helper loaded: file_helper
INFO - 2023-09-19 02:17:25 --> Helper loaded: html_helper
INFO - 2023-09-19 02:17:25 --> Helper loaded: text_helper
INFO - 2023-09-19 02:17:25 --> Helper loaded: form_helper
INFO - 2023-09-19 02:17:25 --> Helper loaded: lang_helper
INFO - 2023-09-19 02:17:25 --> Helper loaded: security_helper
INFO - 2023-09-19 02:17:25 --> Helper loaded: cookie_helper
INFO - 2023-09-19 02:17:25 --> Database Driver Class Initialized
INFO - 2023-09-19 02:17:25 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-19 02:17:25 --> Parser Class Initialized
INFO - 2023-09-19 02:17:25 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-19 02:17:25 --> Pagination Class Initialized
INFO - 2023-09-19 02:17:25 --> Form Validation Class Initialized
INFO - 2023-09-19 02:17:25 --> Controller Class Initialized
INFO - 2023-09-19 02:17:25 --> Model Class Initialized
DEBUG - 2023-09-19 02:17:25 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-09-19 02:17:25 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-19 02:17:25 --> Model Class Initialized
DEBUG - 2023-09-19 02:17:25 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-19 02:17:25 --> Model Class Initialized
INFO - 2023-09-19 02:17:25 --> Final output sent to browser
DEBUG - 2023-09-19 02:17:25 --> Total execution time: 0.0435
ERROR - 2023-09-19 02:17:37 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-19 02:17:37 --> Config Class Initialized
INFO - 2023-09-19 02:17:37 --> Hooks Class Initialized
DEBUG - 2023-09-19 02:17:37 --> UTF-8 Support Enabled
INFO - 2023-09-19 02:17:37 --> Utf8 Class Initialized
INFO - 2023-09-19 02:17:37 --> URI Class Initialized
DEBUG - 2023-09-19 02:17:37 --> No URI present. Default controller set.
INFO - 2023-09-19 02:17:37 --> Router Class Initialized
INFO - 2023-09-19 02:17:37 --> Output Class Initialized
INFO - 2023-09-19 02:17:37 --> Security Class Initialized
DEBUG - 2023-09-19 02:17:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-19 02:17:37 --> Input Class Initialized
INFO - 2023-09-19 02:17:37 --> Language Class Initialized
INFO - 2023-09-19 02:17:37 --> Loader Class Initialized
INFO - 2023-09-19 02:17:37 --> Helper loaded: url_helper
INFO - 2023-09-19 02:17:37 --> Helper loaded: file_helper
INFO - 2023-09-19 02:17:37 --> Helper loaded: html_helper
INFO - 2023-09-19 02:17:37 --> Helper loaded: text_helper
INFO - 2023-09-19 02:17:37 --> Helper loaded: form_helper
INFO - 2023-09-19 02:17:37 --> Helper loaded: lang_helper
INFO - 2023-09-19 02:17:37 --> Helper loaded: security_helper
INFO - 2023-09-19 02:17:37 --> Helper loaded: cookie_helper
INFO - 2023-09-19 02:17:37 --> Database Driver Class Initialized
INFO - 2023-09-19 02:17:37 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-19 02:17:37 --> Parser Class Initialized
INFO - 2023-09-19 02:17:37 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-19 02:17:37 --> Pagination Class Initialized
INFO - 2023-09-19 02:17:37 --> Form Validation Class Initialized
INFO - 2023-09-19 02:17:37 --> Controller Class Initialized
INFO - 2023-09-19 02:17:37 --> Model Class Initialized
DEBUG - 2023-09-19 02:17:37 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-19 02:17:37 --> Model Class Initialized
DEBUG - 2023-09-19 02:17:37 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-19 02:17:37 --> Model Class Initialized
INFO - 2023-09-19 02:17:37 --> Model Class Initialized
INFO - 2023-09-19 02:17:37 --> Model Class Initialized
INFO - 2023-09-19 02:17:37 --> Model Class Initialized
DEBUG - 2023-09-19 02:17:37 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-09-19 02:17:37 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-19 02:17:37 --> Model Class Initialized
INFO - 2023-09-19 02:17:37 --> Model Class Initialized
INFO - 2023-09-19 02:17:37 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-09-19 02:17:37 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-09-19 02:17:37 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-09-19 02:17:37 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-09-19 02:17:37 --> Model Class Initialized
INFO - 2023-09-19 02:17:37 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-09-19 02:17:37 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-09-19 02:17:37 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-09-19 02:17:37 --> Final output sent to browser
DEBUG - 2023-09-19 02:17:37 --> Total execution time: 0.1069
ERROR - 2023-09-19 08:02:20 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-19 08:02:20 --> Config Class Initialized
INFO - 2023-09-19 08:02:20 --> Hooks Class Initialized
DEBUG - 2023-09-19 08:02:20 --> UTF-8 Support Enabled
INFO - 2023-09-19 08:02:20 --> Utf8 Class Initialized
INFO - 2023-09-19 08:02:20 --> URI Class Initialized
DEBUG - 2023-09-19 08:02:20 --> No URI present. Default controller set.
INFO - 2023-09-19 08:02:20 --> Router Class Initialized
INFO - 2023-09-19 08:02:20 --> Output Class Initialized
INFO - 2023-09-19 08:02:20 --> Security Class Initialized
DEBUG - 2023-09-19 08:02:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-19 08:02:20 --> Input Class Initialized
INFO - 2023-09-19 08:02:20 --> Language Class Initialized
INFO - 2023-09-19 08:02:20 --> Loader Class Initialized
INFO - 2023-09-19 08:02:20 --> Helper loaded: url_helper
INFO - 2023-09-19 08:02:20 --> Helper loaded: file_helper
INFO - 2023-09-19 08:02:20 --> Helper loaded: html_helper
INFO - 2023-09-19 08:02:20 --> Helper loaded: text_helper
INFO - 2023-09-19 08:02:20 --> Helper loaded: form_helper
INFO - 2023-09-19 08:02:20 --> Helper loaded: lang_helper
INFO - 2023-09-19 08:02:20 --> Helper loaded: security_helper
INFO - 2023-09-19 08:02:20 --> Helper loaded: cookie_helper
INFO - 2023-09-19 08:02:20 --> Database Driver Class Initialized
INFO - 2023-09-19 08:02:20 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-19 08:02:20 --> Parser Class Initialized
INFO - 2023-09-19 08:02:20 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-19 08:02:20 --> Pagination Class Initialized
INFO - 2023-09-19 08:02:20 --> Form Validation Class Initialized
INFO - 2023-09-19 08:02:20 --> Controller Class Initialized
INFO - 2023-09-19 08:02:20 --> Model Class Initialized
DEBUG - 2023-09-19 08:02:20 --> Session class already loaded. Second attempt ignored.
ERROR - 2023-09-19 08:02:20 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-19 08:02:20 --> Config Class Initialized
INFO - 2023-09-19 08:02:20 --> Hooks Class Initialized
DEBUG - 2023-09-19 08:02:20 --> UTF-8 Support Enabled
INFO - 2023-09-19 08:02:20 --> Utf8 Class Initialized
INFO - 2023-09-19 08:02:20 --> URI Class Initialized
INFO - 2023-09-19 08:02:20 --> Router Class Initialized
INFO - 2023-09-19 08:02:20 --> Output Class Initialized
INFO - 2023-09-19 08:02:20 --> Security Class Initialized
DEBUG - 2023-09-19 08:02:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-19 08:02:20 --> Input Class Initialized
INFO - 2023-09-19 08:02:20 --> Language Class Initialized
INFO - 2023-09-19 08:02:20 --> Loader Class Initialized
INFO - 2023-09-19 08:02:20 --> Helper loaded: url_helper
INFO - 2023-09-19 08:02:20 --> Helper loaded: file_helper
INFO - 2023-09-19 08:02:20 --> Helper loaded: html_helper
INFO - 2023-09-19 08:02:20 --> Helper loaded: text_helper
INFO - 2023-09-19 08:02:20 --> Helper loaded: form_helper
INFO - 2023-09-19 08:02:20 --> Helper loaded: lang_helper
INFO - 2023-09-19 08:02:20 --> Helper loaded: security_helper
INFO - 2023-09-19 08:02:20 --> Helper loaded: cookie_helper
INFO - 2023-09-19 08:02:20 --> Database Driver Class Initialized
INFO - 2023-09-19 08:02:20 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-19 08:02:20 --> Parser Class Initialized
INFO - 2023-09-19 08:02:20 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-19 08:02:20 --> Pagination Class Initialized
INFO - 2023-09-19 08:02:20 --> Form Validation Class Initialized
INFO - 2023-09-19 08:02:20 --> Controller Class Initialized
INFO - 2023-09-19 08:02:20 --> Model Class Initialized
DEBUG - 2023-09-19 08:02:20 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-19 08:02:20 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2023-09-19 08:02:20 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-09-19 08:02:20 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-09-19 08:02:20 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-09-19 08:02:20 --> Model Class Initialized
INFO - 2023-09-19 08:02:20 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-09-19 08:02:20 --> Final output sent to browser
DEBUG - 2023-09-19 08:02:20 --> Total execution time: 0.0296
ERROR - 2023-09-19 08:02:31 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-19 08:02:31 --> Config Class Initialized
INFO - 2023-09-19 08:02:31 --> Hooks Class Initialized
DEBUG - 2023-09-19 08:02:31 --> UTF-8 Support Enabled
INFO - 2023-09-19 08:02:31 --> Utf8 Class Initialized
INFO - 2023-09-19 08:02:31 --> URI Class Initialized
INFO - 2023-09-19 08:02:31 --> Router Class Initialized
INFO - 2023-09-19 08:02:31 --> Output Class Initialized
INFO - 2023-09-19 08:02:31 --> Security Class Initialized
DEBUG - 2023-09-19 08:02:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-19 08:02:31 --> Input Class Initialized
INFO - 2023-09-19 08:02:31 --> Language Class Initialized
INFO - 2023-09-19 08:02:31 --> Loader Class Initialized
INFO - 2023-09-19 08:02:31 --> Helper loaded: url_helper
INFO - 2023-09-19 08:02:31 --> Helper loaded: file_helper
INFO - 2023-09-19 08:02:31 --> Helper loaded: html_helper
INFO - 2023-09-19 08:02:31 --> Helper loaded: text_helper
INFO - 2023-09-19 08:02:31 --> Helper loaded: form_helper
INFO - 2023-09-19 08:02:31 --> Helper loaded: lang_helper
INFO - 2023-09-19 08:02:31 --> Helper loaded: security_helper
INFO - 2023-09-19 08:02:31 --> Helper loaded: cookie_helper
INFO - 2023-09-19 08:02:31 --> Database Driver Class Initialized
INFO - 2023-09-19 08:02:31 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-19 08:02:31 --> Parser Class Initialized
INFO - 2023-09-19 08:02:31 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-19 08:02:31 --> Pagination Class Initialized
INFO - 2023-09-19 08:02:31 --> Form Validation Class Initialized
INFO - 2023-09-19 08:02:31 --> Controller Class Initialized
INFO - 2023-09-19 08:02:31 --> Model Class Initialized
DEBUG - 2023-09-19 08:02:31 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-19 08:02:31 --> Model Class Initialized
INFO - 2023-09-19 08:02:31 --> Final output sent to browser
DEBUG - 2023-09-19 08:02:31 --> Total execution time: 0.0189
ERROR - 2023-09-19 08:02:32 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-19 08:02:32 --> Config Class Initialized
INFO - 2023-09-19 08:02:32 --> Hooks Class Initialized
DEBUG - 2023-09-19 08:02:32 --> UTF-8 Support Enabled
INFO - 2023-09-19 08:02:32 --> Utf8 Class Initialized
INFO - 2023-09-19 08:02:32 --> URI Class Initialized
DEBUG - 2023-09-19 08:02:32 --> No URI present. Default controller set.
INFO - 2023-09-19 08:02:32 --> Router Class Initialized
INFO - 2023-09-19 08:02:32 --> Output Class Initialized
INFO - 2023-09-19 08:02:32 --> Security Class Initialized
DEBUG - 2023-09-19 08:02:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-19 08:02:32 --> Input Class Initialized
INFO - 2023-09-19 08:02:32 --> Language Class Initialized
INFO - 2023-09-19 08:02:32 --> Loader Class Initialized
INFO - 2023-09-19 08:02:32 --> Helper loaded: url_helper
INFO - 2023-09-19 08:02:32 --> Helper loaded: file_helper
INFO - 2023-09-19 08:02:32 --> Helper loaded: html_helper
INFO - 2023-09-19 08:02:32 --> Helper loaded: text_helper
INFO - 2023-09-19 08:02:32 --> Helper loaded: form_helper
INFO - 2023-09-19 08:02:32 --> Helper loaded: lang_helper
INFO - 2023-09-19 08:02:32 --> Helper loaded: security_helper
INFO - 2023-09-19 08:02:32 --> Helper loaded: cookie_helper
INFO - 2023-09-19 08:02:32 --> Database Driver Class Initialized
INFO - 2023-09-19 08:02:32 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-19 08:02:32 --> Parser Class Initialized
INFO - 2023-09-19 08:02:32 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-19 08:02:32 --> Pagination Class Initialized
INFO - 2023-09-19 08:02:32 --> Form Validation Class Initialized
INFO - 2023-09-19 08:02:32 --> Controller Class Initialized
INFO - 2023-09-19 08:02:32 --> Model Class Initialized
DEBUG - 2023-09-19 08:02:32 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-19 08:02:32 --> Model Class Initialized
DEBUG - 2023-09-19 08:02:32 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-19 08:02:32 --> Model Class Initialized
INFO - 2023-09-19 08:02:32 --> Model Class Initialized
INFO - 2023-09-19 08:02:32 --> Model Class Initialized
INFO - 2023-09-19 08:02:32 --> Model Class Initialized
DEBUG - 2023-09-19 08:02:32 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-09-19 08:02:32 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-19 08:02:32 --> Model Class Initialized
INFO - 2023-09-19 08:02:32 --> Model Class Initialized
INFO - 2023-09-19 08:02:32 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-09-19 08:02:32 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-09-19 08:02:32 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-09-19 08:02:32 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-09-19 08:02:32 --> Model Class Initialized
INFO - 2023-09-19 08:02:32 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-09-19 08:02:32 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-09-19 08:02:32 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-09-19 08:02:32 --> Final output sent to browser
DEBUG - 2023-09-19 08:02:32 --> Total execution time: 0.0909
ERROR - 2023-09-19 08:02:52 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-19 08:02:52 --> Config Class Initialized
INFO - 2023-09-19 08:02:52 --> Hooks Class Initialized
DEBUG - 2023-09-19 08:02:52 --> UTF-8 Support Enabled
INFO - 2023-09-19 08:02:52 --> Utf8 Class Initialized
INFO - 2023-09-19 08:02:52 --> URI Class Initialized
INFO - 2023-09-19 08:02:52 --> Router Class Initialized
INFO - 2023-09-19 08:02:52 --> Output Class Initialized
INFO - 2023-09-19 08:02:52 --> Security Class Initialized
DEBUG - 2023-09-19 08:02:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-19 08:02:52 --> Input Class Initialized
INFO - 2023-09-19 08:02:52 --> Language Class Initialized
INFO - 2023-09-19 08:02:52 --> Loader Class Initialized
INFO - 2023-09-19 08:02:52 --> Helper loaded: url_helper
INFO - 2023-09-19 08:02:52 --> Helper loaded: file_helper
INFO - 2023-09-19 08:02:52 --> Helper loaded: html_helper
INFO - 2023-09-19 08:02:52 --> Helper loaded: text_helper
INFO - 2023-09-19 08:02:52 --> Helper loaded: form_helper
INFO - 2023-09-19 08:02:52 --> Helper loaded: lang_helper
INFO - 2023-09-19 08:02:52 --> Helper loaded: security_helper
INFO - 2023-09-19 08:02:52 --> Helper loaded: cookie_helper
INFO - 2023-09-19 08:02:52 --> Database Driver Class Initialized
INFO - 2023-09-19 08:02:52 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-19 08:02:52 --> Parser Class Initialized
INFO - 2023-09-19 08:02:52 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-19 08:02:52 --> Pagination Class Initialized
INFO - 2023-09-19 08:02:52 --> Form Validation Class Initialized
INFO - 2023-09-19 08:02:52 --> Controller Class Initialized
INFO - 2023-09-19 08:02:52 --> Model Class Initialized
DEBUG - 2023-09-19 08:02:52 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-19 08:02:52 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2023-09-19 08:02:52 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-09-19 08:02:52 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-09-19 08:02:52 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-09-19 08:02:52 --> Model Class Initialized
INFO - 2023-09-19 08:02:52 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-09-19 08:02:52 --> Final output sent to browser
DEBUG - 2023-09-19 08:02:52 --> Total execution time: 0.0311
ERROR - 2023-09-19 08:02:53 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-19 08:02:53 --> Config Class Initialized
INFO - 2023-09-19 08:02:53 --> Hooks Class Initialized
DEBUG - 2023-09-19 08:02:53 --> UTF-8 Support Enabled
INFO - 2023-09-19 08:02:53 --> Utf8 Class Initialized
INFO - 2023-09-19 08:02:53 --> URI Class Initialized
INFO - 2023-09-19 08:02:53 --> Router Class Initialized
INFO - 2023-09-19 08:02:53 --> Output Class Initialized
INFO - 2023-09-19 08:02:53 --> Security Class Initialized
DEBUG - 2023-09-19 08:02:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-19 08:02:53 --> Input Class Initialized
INFO - 2023-09-19 08:02:53 --> Language Class Initialized
INFO - 2023-09-19 08:02:53 --> Loader Class Initialized
INFO - 2023-09-19 08:02:53 --> Helper loaded: url_helper
INFO - 2023-09-19 08:02:53 --> Helper loaded: file_helper
INFO - 2023-09-19 08:02:53 --> Helper loaded: html_helper
INFO - 2023-09-19 08:02:53 --> Helper loaded: text_helper
INFO - 2023-09-19 08:02:53 --> Helper loaded: form_helper
INFO - 2023-09-19 08:02:53 --> Helper loaded: lang_helper
INFO - 2023-09-19 08:02:53 --> Helper loaded: security_helper
INFO - 2023-09-19 08:02:53 --> Helper loaded: cookie_helper
INFO - 2023-09-19 08:02:53 --> Database Driver Class Initialized
INFO - 2023-09-19 08:02:53 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-19 08:02:53 --> Parser Class Initialized
INFO - 2023-09-19 08:02:53 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-19 08:02:53 --> Pagination Class Initialized
INFO - 2023-09-19 08:02:53 --> Form Validation Class Initialized
INFO - 2023-09-19 08:02:53 --> Controller Class Initialized
INFO - 2023-09-19 08:02:53 --> Model Class Initialized
DEBUG - 2023-09-19 08:02:53 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-19 08:02:53 --> Model Class Initialized
DEBUG - 2023-09-19 08:02:53 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-19 08:02:53 --> Model Class Initialized
INFO - 2023-09-19 08:02:53 --> Model Class Initialized
INFO - 2023-09-19 08:02:53 --> Model Class Initialized
INFO - 2023-09-19 08:02:53 --> Model Class Initialized
DEBUG - 2023-09-19 08:02:53 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-09-19 08:02:53 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-19 08:02:53 --> Model Class Initialized
INFO - 2023-09-19 08:02:53 --> Model Class Initialized
INFO - 2023-09-19 08:02:53 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-09-19 08:02:53 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-09-19 08:02:53 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-09-19 08:02:53 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-09-19 08:02:53 --> Model Class Initialized
INFO - 2023-09-19 08:02:53 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-09-19 08:02:53 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-09-19 08:02:53 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-09-19 08:02:53 --> Final output sent to browser
DEBUG - 2023-09-19 08:02:53 --> Total execution time: 0.1238
ERROR - 2023-09-19 08:03:03 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-19 08:03:03 --> Config Class Initialized
INFO - 2023-09-19 08:03:03 --> Hooks Class Initialized
DEBUG - 2023-09-19 08:03:03 --> UTF-8 Support Enabled
INFO - 2023-09-19 08:03:03 --> Utf8 Class Initialized
INFO - 2023-09-19 08:03:03 --> URI Class Initialized
INFO - 2023-09-19 08:03:03 --> Router Class Initialized
INFO - 2023-09-19 08:03:03 --> Output Class Initialized
INFO - 2023-09-19 08:03:03 --> Security Class Initialized
DEBUG - 2023-09-19 08:03:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-19 08:03:03 --> Input Class Initialized
INFO - 2023-09-19 08:03:03 --> Language Class Initialized
INFO - 2023-09-19 08:03:03 --> Loader Class Initialized
INFO - 2023-09-19 08:03:03 --> Helper loaded: url_helper
INFO - 2023-09-19 08:03:03 --> Helper loaded: file_helper
INFO - 2023-09-19 08:03:03 --> Helper loaded: html_helper
INFO - 2023-09-19 08:03:03 --> Helper loaded: text_helper
INFO - 2023-09-19 08:03:03 --> Helper loaded: form_helper
INFO - 2023-09-19 08:03:03 --> Helper loaded: lang_helper
INFO - 2023-09-19 08:03:03 --> Helper loaded: security_helper
INFO - 2023-09-19 08:03:03 --> Helper loaded: cookie_helper
INFO - 2023-09-19 08:03:03 --> Database Driver Class Initialized
INFO - 2023-09-19 08:03:03 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-19 08:03:03 --> Parser Class Initialized
INFO - 2023-09-19 08:03:03 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-19 08:03:03 --> Pagination Class Initialized
INFO - 2023-09-19 08:03:03 --> Form Validation Class Initialized
INFO - 2023-09-19 08:03:03 --> Controller Class Initialized
INFO - 2023-09-19 08:03:03 --> Model Class Initialized
DEBUG - 2023-09-19 08:03:03 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-09-19 08:03:03 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-19 08:03:03 --> Model Class Initialized
DEBUG - 2023-09-19 08:03:03 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-19 08:03:03 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/demandrequest/add_demandrequest_form.php
DEBUG - 2023-09-19 08:03:03 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-09-19 08:03:03 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-09-19 08:03:03 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-09-19 08:03:03 --> Model Class Initialized
INFO - 2023-09-19 08:03:03 --> Model Class Initialized
INFO - 2023-09-19 08:03:03 --> Model Class Initialized
INFO - 2023-09-19 08:03:03 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-09-19 08:03:03 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-09-19 08:03:03 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-09-19 08:03:03 --> Final output sent to browser
DEBUG - 2023-09-19 08:03:03 --> Total execution time: 0.0696
ERROR - 2023-09-19 08:03:11 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-19 08:03:11 --> Config Class Initialized
INFO - 2023-09-19 08:03:11 --> Hooks Class Initialized
DEBUG - 2023-09-19 08:03:11 --> UTF-8 Support Enabled
INFO - 2023-09-19 08:03:11 --> Utf8 Class Initialized
INFO - 2023-09-19 08:03:11 --> URI Class Initialized
INFO - 2023-09-19 08:03:11 --> Router Class Initialized
INFO - 2023-09-19 08:03:11 --> Output Class Initialized
INFO - 2023-09-19 08:03:11 --> Security Class Initialized
DEBUG - 2023-09-19 08:03:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-19 08:03:11 --> Input Class Initialized
INFO - 2023-09-19 08:03:11 --> Language Class Initialized
INFO - 2023-09-19 08:03:11 --> Loader Class Initialized
INFO - 2023-09-19 08:03:11 --> Helper loaded: url_helper
INFO - 2023-09-19 08:03:11 --> Helper loaded: file_helper
INFO - 2023-09-19 08:03:11 --> Helper loaded: html_helper
INFO - 2023-09-19 08:03:11 --> Helper loaded: text_helper
INFO - 2023-09-19 08:03:11 --> Helper loaded: form_helper
INFO - 2023-09-19 08:03:11 --> Helper loaded: lang_helper
INFO - 2023-09-19 08:03:11 --> Helper loaded: security_helper
INFO - 2023-09-19 08:03:11 --> Helper loaded: cookie_helper
INFO - 2023-09-19 08:03:11 --> Database Driver Class Initialized
INFO - 2023-09-19 08:03:12 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-19 08:03:12 --> Parser Class Initialized
INFO - 2023-09-19 08:03:12 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-19 08:03:12 --> Pagination Class Initialized
INFO - 2023-09-19 08:03:12 --> Form Validation Class Initialized
INFO - 2023-09-19 08:03:12 --> Controller Class Initialized
INFO - 2023-09-19 08:03:12 --> Model Class Initialized
DEBUG - 2023-09-19 08:03:12 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-19 08:03:12 --> Model Class Initialized
DEBUG - 2023-09-19 08:03:12 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-19 08:03:12 --> Model Class Initialized
INFO - 2023-09-19 08:03:12 --> Model Class Initialized
INFO - 2023-09-19 08:03:12 --> Model Class Initialized
INFO - 2023-09-19 08:03:12 --> Model Class Initialized
DEBUG - 2023-09-19 08:03:12 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-09-19 08:03:12 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-19 08:03:12 --> Model Class Initialized
INFO - 2023-09-19 08:03:12 --> Model Class Initialized
INFO - 2023-09-19 08:03:12 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-09-19 08:03:12 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-09-19 08:03:12 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-09-19 08:03:12 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-09-19 08:03:12 --> Model Class Initialized
INFO - 2023-09-19 08:03:12 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-09-19 08:03:12 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-09-19 08:03:12 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-09-19 08:03:12 --> Final output sent to browser
DEBUG - 2023-09-19 08:03:12 --> Total execution time: 0.0887
ERROR - 2023-09-19 08:03:17 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-19 08:03:17 --> Config Class Initialized
INFO - 2023-09-19 08:03:17 --> Hooks Class Initialized
DEBUG - 2023-09-19 08:03:17 --> UTF-8 Support Enabled
INFO - 2023-09-19 08:03:17 --> Utf8 Class Initialized
INFO - 2023-09-19 08:03:17 --> URI Class Initialized
INFO - 2023-09-19 08:03:17 --> Router Class Initialized
INFO - 2023-09-19 08:03:17 --> Output Class Initialized
INFO - 2023-09-19 08:03:17 --> Security Class Initialized
DEBUG - 2023-09-19 08:03:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-19 08:03:17 --> Input Class Initialized
INFO - 2023-09-19 08:03:17 --> Language Class Initialized
INFO - 2023-09-19 08:03:17 --> Loader Class Initialized
INFO - 2023-09-19 08:03:17 --> Helper loaded: url_helper
INFO - 2023-09-19 08:03:17 --> Helper loaded: file_helper
INFO - 2023-09-19 08:03:17 --> Helper loaded: html_helper
INFO - 2023-09-19 08:03:17 --> Helper loaded: text_helper
INFO - 2023-09-19 08:03:17 --> Helper loaded: form_helper
INFO - 2023-09-19 08:03:17 --> Helper loaded: lang_helper
INFO - 2023-09-19 08:03:17 --> Helper loaded: security_helper
INFO - 2023-09-19 08:03:17 --> Helper loaded: cookie_helper
INFO - 2023-09-19 08:03:17 --> Database Driver Class Initialized
INFO - 2023-09-19 08:03:17 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-19 08:03:17 --> Parser Class Initialized
INFO - 2023-09-19 08:03:17 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-19 08:03:17 --> Pagination Class Initialized
INFO - 2023-09-19 08:03:17 --> Form Validation Class Initialized
INFO - 2023-09-19 08:03:17 --> Controller Class Initialized
INFO - 2023-09-19 08:03:17 --> Model Class Initialized
DEBUG - 2023-09-19 08:03:17 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-09-19 08:03:17 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-19 08:03:17 --> Model Class Initialized
DEBUG - 2023-09-19 08:03:17 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-19 08:03:17 --> Model Class Initialized
INFO - 2023-09-19 08:03:17 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice.php
DEBUG - 2023-09-19 08:03:17 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-09-19 08:03:17 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-09-19 08:03:17 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-09-19 08:03:17 --> Model Class Initialized
INFO - 2023-09-19 08:03:17 --> Model Class Initialized
INFO - 2023-09-19 08:03:17 --> Model Class Initialized
INFO - 2023-09-19 08:03:17 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-09-19 08:03:17 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-09-19 08:03:17 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-09-19 08:03:17 --> Final output sent to browser
DEBUG - 2023-09-19 08:03:17 --> Total execution time: 0.0745
ERROR - 2023-09-19 08:03:18 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-19 08:03:18 --> Config Class Initialized
INFO - 2023-09-19 08:03:18 --> Hooks Class Initialized
DEBUG - 2023-09-19 08:03:18 --> UTF-8 Support Enabled
INFO - 2023-09-19 08:03:18 --> Utf8 Class Initialized
INFO - 2023-09-19 08:03:18 --> URI Class Initialized
INFO - 2023-09-19 08:03:18 --> Router Class Initialized
INFO - 2023-09-19 08:03:18 --> Output Class Initialized
INFO - 2023-09-19 08:03:18 --> Security Class Initialized
DEBUG - 2023-09-19 08:03:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-19 08:03:18 --> Input Class Initialized
INFO - 2023-09-19 08:03:18 --> Language Class Initialized
INFO - 2023-09-19 08:03:18 --> Loader Class Initialized
INFO - 2023-09-19 08:03:18 --> Helper loaded: url_helper
INFO - 2023-09-19 08:03:18 --> Helper loaded: file_helper
INFO - 2023-09-19 08:03:18 --> Helper loaded: html_helper
INFO - 2023-09-19 08:03:18 --> Helper loaded: text_helper
INFO - 2023-09-19 08:03:18 --> Helper loaded: form_helper
INFO - 2023-09-19 08:03:18 --> Helper loaded: lang_helper
INFO - 2023-09-19 08:03:18 --> Helper loaded: security_helper
INFO - 2023-09-19 08:03:18 --> Helper loaded: cookie_helper
INFO - 2023-09-19 08:03:18 --> Database Driver Class Initialized
INFO - 2023-09-19 08:03:18 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-19 08:03:18 --> Parser Class Initialized
INFO - 2023-09-19 08:03:18 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-19 08:03:18 --> Pagination Class Initialized
INFO - 2023-09-19 08:03:18 --> Form Validation Class Initialized
INFO - 2023-09-19 08:03:18 --> Controller Class Initialized
INFO - 2023-09-19 08:03:18 --> Model Class Initialized
DEBUG - 2023-09-19 08:03:18 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-09-19 08:03:18 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-19 08:03:18 --> Model Class Initialized
DEBUG - 2023-09-19 08:03:18 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-19 08:03:18 --> Model Class Initialized
INFO - 2023-09-19 08:03:18 --> Final output sent to browser
DEBUG - 2023-09-19 08:03:18 --> Total execution time: 0.0221
ERROR - 2023-09-19 08:03:30 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-19 08:03:30 --> Config Class Initialized
INFO - 2023-09-19 08:03:30 --> Hooks Class Initialized
DEBUG - 2023-09-19 08:03:30 --> UTF-8 Support Enabled
INFO - 2023-09-19 08:03:30 --> Utf8 Class Initialized
INFO - 2023-09-19 08:03:30 --> URI Class Initialized
INFO - 2023-09-19 08:03:30 --> Router Class Initialized
INFO - 2023-09-19 08:03:30 --> Output Class Initialized
INFO - 2023-09-19 08:03:30 --> Security Class Initialized
DEBUG - 2023-09-19 08:03:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-19 08:03:30 --> Input Class Initialized
INFO - 2023-09-19 08:03:30 --> Language Class Initialized
INFO - 2023-09-19 08:03:30 --> Loader Class Initialized
INFO - 2023-09-19 08:03:30 --> Helper loaded: url_helper
INFO - 2023-09-19 08:03:30 --> Helper loaded: file_helper
INFO - 2023-09-19 08:03:30 --> Helper loaded: html_helper
INFO - 2023-09-19 08:03:30 --> Helper loaded: text_helper
INFO - 2023-09-19 08:03:30 --> Helper loaded: form_helper
INFO - 2023-09-19 08:03:30 --> Helper loaded: lang_helper
INFO - 2023-09-19 08:03:30 --> Helper loaded: security_helper
INFO - 2023-09-19 08:03:30 --> Helper loaded: cookie_helper
INFO - 2023-09-19 08:03:30 --> Database Driver Class Initialized
INFO - 2023-09-19 08:03:30 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-19 08:03:30 --> Parser Class Initialized
INFO - 2023-09-19 08:03:30 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-19 08:03:30 --> Pagination Class Initialized
INFO - 2023-09-19 08:03:30 --> Form Validation Class Initialized
INFO - 2023-09-19 08:03:30 --> Controller Class Initialized
INFO - 2023-09-19 08:03:30 --> Model Class Initialized
DEBUG - 2023-09-19 08:03:30 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-19 08:03:30 --> Model Class Initialized
DEBUG - 2023-09-19 08:03:30 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-19 08:03:30 --> Model Class Initialized
INFO - 2023-09-19 08:03:30 --> Model Class Initialized
INFO - 2023-09-19 08:03:30 --> Model Class Initialized
INFO - 2023-09-19 08:03:30 --> Model Class Initialized
DEBUG - 2023-09-19 08:03:30 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-09-19 08:03:30 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-19 08:03:30 --> Model Class Initialized
INFO - 2023-09-19 08:03:30 --> Model Class Initialized
INFO - 2023-09-19 08:03:30 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-09-19 08:03:30 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-09-19 08:03:30 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-09-19 08:03:30 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-09-19 08:03:30 --> Model Class Initialized
INFO - 2023-09-19 08:03:30 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-09-19 08:03:30 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-09-19 08:03:30 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-09-19 08:03:30 --> Final output sent to browser
DEBUG - 2023-09-19 08:03:30 --> Total execution time: 0.0912
ERROR - 2023-09-19 08:03:46 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-19 08:03:46 --> Config Class Initialized
INFO - 2023-09-19 08:03:46 --> Hooks Class Initialized
DEBUG - 2023-09-19 08:03:46 --> UTF-8 Support Enabled
INFO - 2023-09-19 08:03:46 --> Utf8 Class Initialized
INFO - 2023-09-19 08:03:46 --> URI Class Initialized
DEBUG - 2023-09-19 08:03:46 --> No URI present. Default controller set.
INFO - 2023-09-19 08:03:46 --> Router Class Initialized
INFO - 2023-09-19 08:03:46 --> Output Class Initialized
INFO - 2023-09-19 08:03:46 --> Security Class Initialized
DEBUG - 2023-09-19 08:03:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-19 08:03:46 --> Input Class Initialized
INFO - 2023-09-19 08:03:46 --> Language Class Initialized
INFO - 2023-09-19 08:03:46 --> Loader Class Initialized
INFO - 2023-09-19 08:03:46 --> Helper loaded: url_helper
INFO - 2023-09-19 08:03:46 --> Helper loaded: file_helper
INFO - 2023-09-19 08:03:46 --> Helper loaded: html_helper
INFO - 2023-09-19 08:03:46 --> Helper loaded: text_helper
INFO - 2023-09-19 08:03:46 --> Helper loaded: form_helper
INFO - 2023-09-19 08:03:46 --> Helper loaded: lang_helper
INFO - 2023-09-19 08:03:46 --> Helper loaded: security_helper
INFO - 2023-09-19 08:03:46 --> Helper loaded: cookie_helper
INFO - 2023-09-19 08:03:46 --> Database Driver Class Initialized
INFO - 2023-09-19 08:03:46 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-19 08:03:46 --> Parser Class Initialized
INFO - 2023-09-19 08:03:46 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-19 08:03:46 --> Pagination Class Initialized
INFO - 2023-09-19 08:03:46 --> Form Validation Class Initialized
INFO - 2023-09-19 08:03:46 --> Controller Class Initialized
INFO - 2023-09-19 08:03:46 --> Model Class Initialized
DEBUG - 2023-09-19 08:03:46 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-19 08:03:46 --> Model Class Initialized
DEBUG - 2023-09-19 08:03:46 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-19 08:03:46 --> Model Class Initialized
INFO - 2023-09-19 08:03:46 --> Model Class Initialized
INFO - 2023-09-19 08:03:46 --> Model Class Initialized
INFO - 2023-09-19 08:03:46 --> Model Class Initialized
DEBUG - 2023-09-19 08:03:46 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-09-19 08:03:46 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-19 08:03:46 --> Model Class Initialized
INFO - 2023-09-19 08:03:46 --> Model Class Initialized
INFO - 2023-09-19 08:03:46 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-09-19 08:03:46 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-09-19 08:03:46 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-09-19 08:03:46 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-09-19 08:03:46 --> Model Class Initialized
INFO - 2023-09-19 08:03:46 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-09-19 08:03:46 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-09-19 08:03:46 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-09-19 08:03:46 --> Final output sent to browser
DEBUG - 2023-09-19 08:03:46 --> Total execution time: 0.0874
ERROR - 2023-09-19 08:03:52 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-19 08:03:52 --> Config Class Initialized
INFO - 2023-09-19 08:03:52 --> Hooks Class Initialized
DEBUG - 2023-09-19 08:03:52 --> UTF-8 Support Enabled
INFO - 2023-09-19 08:03:52 --> Utf8 Class Initialized
INFO - 2023-09-19 08:03:52 --> URI Class Initialized
INFO - 2023-09-19 08:03:52 --> Router Class Initialized
INFO - 2023-09-19 08:03:52 --> Output Class Initialized
INFO - 2023-09-19 08:03:52 --> Security Class Initialized
DEBUG - 2023-09-19 08:03:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-19 08:03:52 --> Input Class Initialized
INFO - 2023-09-19 08:03:52 --> Language Class Initialized
INFO - 2023-09-19 08:03:52 --> Loader Class Initialized
INFO - 2023-09-19 08:03:52 --> Helper loaded: url_helper
INFO - 2023-09-19 08:03:52 --> Helper loaded: file_helper
INFO - 2023-09-19 08:03:52 --> Helper loaded: html_helper
INFO - 2023-09-19 08:03:52 --> Helper loaded: text_helper
INFO - 2023-09-19 08:03:52 --> Helper loaded: form_helper
INFO - 2023-09-19 08:03:52 --> Helper loaded: lang_helper
INFO - 2023-09-19 08:03:52 --> Helper loaded: security_helper
INFO - 2023-09-19 08:03:52 --> Helper loaded: cookie_helper
INFO - 2023-09-19 08:03:52 --> Database Driver Class Initialized
INFO - 2023-09-19 08:03:52 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-19 08:03:52 --> Parser Class Initialized
INFO - 2023-09-19 08:03:52 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-19 08:03:52 --> Pagination Class Initialized
INFO - 2023-09-19 08:03:52 --> Form Validation Class Initialized
INFO - 2023-09-19 08:03:52 --> Controller Class Initialized
INFO - 2023-09-19 08:03:52 --> Model Class Initialized
INFO - 2023-09-19 08:03:52 --> Model Class Initialized
INFO - 2023-09-19 08:03:52 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/report/out_of_stock.php
DEBUG - 2023-09-19 08:03:52 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-09-19 08:03:52 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-09-19 08:03:52 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-09-19 08:03:52 --> Model Class Initialized
INFO - 2023-09-19 08:03:52 --> Model Class Initialized
INFO - 2023-09-19 08:03:52 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-09-19 08:03:52 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-09-19 08:03:52 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-09-19 08:03:52 --> Final output sent to browser
DEBUG - 2023-09-19 08:03:52 --> Total execution time: 0.0771
ERROR - 2023-09-19 08:03:52 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-19 08:03:52 --> Config Class Initialized
INFO - 2023-09-19 08:03:52 --> Hooks Class Initialized
DEBUG - 2023-09-19 08:03:52 --> UTF-8 Support Enabled
INFO - 2023-09-19 08:03:52 --> Utf8 Class Initialized
INFO - 2023-09-19 08:03:52 --> URI Class Initialized
INFO - 2023-09-19 08:03:52 --> Router Class Initialized
INFO - 2023-09-19 08:03:52 --> Output Class Initialized
INFO - 2023-09-19 08:03:52 --> Security Class Initialized
DEBUG - 2023-09-19 08:03:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-19 08:03:52 --> Input Class Initialized
INFO - 2023-09-19 08:03:52 --> Language Class Initialized
INFO - 2023-09-19 08:03:52 --> Loader Class Initialized
INFO - 2023-09-19 08:03:52 --> Helper loaded: url_helper
INFO - 2023-09-19 08:03:52 --> Helper loaded: file_helper
INFO - 2023-09-19 08:03:52 --> Helper loaded: html_helper
INFO - 2023-09-19 08:03:52 --> Helper loaded: text_helper
INFO - 2023-09-19 08:03:52 --> Helper loaded: form_helper
INFO - 2023-09-19 08:03:52 --> Helper loaded: lang_helper
INFO - 2023-09-19 08:03:52 --> Helper loaded: security_helper
INFO - 2023-09-19 08:03:52 --> Helper loaded: cookie_helper
INFO - 2023-09-19 08:03:52 --> Database Driver Class Initialized
INFO - 2023-09-19 08:03:52 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-19 08:03:52 --> Parser Class Initialized
INFO - 2023-09-19 08:03:52 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-19 08:03:52 --> Pagination Class Initialized
INFO - 2023-09-19 08:03:52 --> Form Validation Class Initialized
INFO - 2023-09-19 08:03:52 --> Controller Class Initialized
INFO - 2023-09-19 08:03:52 --> Model Class Initialized
INFO - 2023-09-19 08:03:52 --> Model Class Initialized
INFO - 2023-09-19 08:03:52 --> Final output sent to browser
DEBUG - 2023-09-19 08:03:52 --> Total execution time: 0.0564
ERROR - 2023-09-19 08:04:51 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-19 08:04:51 --> Config Class Initialized
INFO - 2023-09-19 08:04:51 --> Hooks Class Initialized
DEBUG - 2023-09-19 08:04:51 --> UTF-8 Support Enabled
INFO - 2023-09-19 08:04:51 --> Utf8 Class Initialized
INFO - 2023-09-19 08:04:51 --> URI Class Initialized
DEBUG - 2023-09-19 08:04:51 --> No URI present. Default controller set.
INFO - 2023-09-19 08:04:51 --> Router Class Initialized
INFO - 2023-09-19 08:04:51 --> Output Class Initialized
INFO - 2023-09-19 08:04:51 --> Security Class Initialized
DEBUG - 2023-09-19 08:04:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-19 08:04:51 --> Input Class Initialized
INFO - 2023-09-19 08:04:51 --> Language Class Initialized
INFO - 2023-09-19 08:04:51 --> Loader Class Initialized
INFO - 2023-09-19 08:04:51 --> Helper loaded: url_helper
INFO - 2023-09-19 08:04:51 --> Helper loaded: file_helper
INFO - 2023-09-19 08:04:51 --> Helper loaded: html_helper
INFO - 2023-09-19 08:04:51 --> Helper loaded: text_helper
INFO - 2023-09-19 08:04:51 --> Helper loaded: form_helper
INFO - 2023-09-19 08:04:51 --> Helper loaded: lang_helper
INFO - 2023-09-19 08:04:51 --> Helper loaded: security_helper
INFO - 2023-09-19 08:04:51 --> Helper loaded: cookie_helper
INFO - 2023-09-19 08:04:51 --> Database Driver Class Initialized
INFO - 2023-09-19 08:04:51 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-19 08:04:51 --> Parser Class Initialized
INFO - 2023-09-19 08:04:51 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-19 08:04:51 --> Pagination Class Initialized
INFO - 2023-09-19 08:04:51 --> Form Validation Class Initialized
INFO - 2023-09-19 08:04:51 --> Controller Class Initialized
INFO - 2023-09-19 08:04:51 --> Model Class Initialized
DEBUG - 2023-09-19 08:04:51 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-19 08:04:51 --> Model Class Initialized
DEBUG - 2023-09-19 08:04:51 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-19 08:04:51 --> Model Class Initialized
INFO - 2023-09-19 08:04:51 --> Model Class Initialized
INFO - 2023-09-19 08:04:51 --> Model Class Initialized
INFO - 2023-09-19 08:04:51 --> Model Class Initialized
DEBUG - 2023-09-19 08:04:51 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-09-19 08:04:51 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-19 08:04:51 --> Model Class Initialized
INFO - 2023-09-19 08:04:51 --> Model Class Initialized
INFO - 2023-09-19 08:04:51 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-09-19 08:04:51 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-09-19 08:04:51 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-09-19 08:04:51 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-09-19 08:04:51 --> Model Class Initialized
INFO - 2023-09-19 08:04:51 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-09-19 08:04:51 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-09-19 08:04:51 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-09-19 08:04:51 --> Final output sent to browser
DEBUG - 2023-09-19 08:04:51 --> Total execution time: 0.0887
ERROR - 2023-09-19 08:04:57 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-19 08:04:57 --> Config Class Initialized
INFO - 2023-09-19 08:04:57 --> Hooks Class Initialized
DEBUG - 2023-09-19 08:04:57 --> UTF-8 Support Enabled
INFO - 2023-09-19 08:04:57 --> Utf8 Class Initialized
INFO - 2023-09-19 08:04:57 --> URI Class Initialized
INFO - 2023-09-19 08:04:57 --> Router Class Initialized
INFO - 2023-09-19 08:04:57 --> Output Class Initialized
INFO - 2023-09-19 08:04:57 --> Security Class Initialized
DEBUG - 2023-09-19 08:04:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-19 08:04:57 --> Input Class Initialized
INFO - 2023-09-19 08:04:57 --> Language Class Initialized
INFO - 2023-09-19 08:04:57 --> Loader Class Initialized
INFO - 2023-09-19 08:04:57 --> Helper loaded: url_helper
INFO - 2023-09-19 08:04:57 --> Helper loaded: file_helper
INFO - 2023-09-19 08:04:57 --> Helper loaded: html_helper
INFO - 2023-09-19 08:04:57 --> Helper loaded: text_helper
INFO - 2023-09-19 08:04:57 --> Helper loaded: form_helper
INFO - 2023-09-19 08:04:57 --> Helper loaded: lang_helper
INFO - 2023-09-19 08:04:57 --> Helper loaded: security_helper
INFO - 2023-09-19 08:04:57 --> Helper loaded: cookie_helper
INFO - 2023-09-19 08:04:57 --> Database Driver Class Initialized
INFO - 2023-09-19 08:04:57 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-19 08:04:57 --> Parser Class Initialized
INFO - 2023-09-19 08:04:57 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-19 08:04:57 --> Pagination Class Initialized
INFO - 2023-09-19 08:04:57 --> Form Validation Class Initialized
INFO - 2023-09-19 08:04:57 --> Controller Class Initialized
INFO - 2023-09-19 08:04:57 --> Model Class Initialized
DEBUG - 2023-09-19 08:04:57 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-09-19 08:04:57 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-19 08:04:57 --> Model Class Initialized
DEBUG - 2023-09-19 08:04:57 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-19 08:04:57 --> Model Class Initialized
INFO - 2023-09-19 08:04:57 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/invoice/invoice.php
DEBUG - 2023-09-19 08:04:57 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-09-19 08:04:57 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-09-19 08:04:57 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-09-19 08:04:57 --> Model Class Initialized
INFO - 2023-09-19 08:04:57 --> Model Class Initialized
INFO - 2023-09-19 08:04:57 --> Model Class Initialized
INFO - 2023-09-19 08:04:57 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-09-19 08:04:57 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-09-19 08:04:57 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-09-19 08:04:57 --> Final output sent to browser
DEBUG - 2023-09-19 08:04:57 --> Total execution time: 0.0728
ERROR - 2023-09-19 08:04:57 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-19 08:04:57 --> Config Class Initialized
INFO - 2023-09-19 08:04:57 --> Hooks Class Initialized
DEBUG - 2023-09-19 08:04:57 --> UTF-8 Support Enabled
INFO - 2023-09-19 08:04:57 --> Utf8 Class Initialized
INFO - 2023-09-19 08:04:57 --> URI Class Initialized
INFO - 2023-09-19 08:04:57 --> Router Class Initialized
INFO - 2023-09-19 08:04:57 --> Output Class Initialized
INFO - 2023-09-19 08:04:57 --> Security Class Initialized
DEBUG - 2023-09-19 08:04:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-19 08:04:57 --> Input Class Initialized
INFO - 2023-09-19 08:04:57 --> Language Class Initialized
INFO - 2023-09-19 08:04:57 --> Loader Class Initialized
INFO - 2023-09-19 08:04:57 --> Helper loaded: url_helper
INFO - 2023-09-19 08:04:57 --> Helper loaded: file_helper
INFO - 2023-09-19 08:04:57 --> Helper loaded: html_helper
INFO - 2023-09-19 08:04:57 --> Helper loaded: text_helper
INFO - 2023-09-19 08:04:57 --> Helper loaded: form_helper
INFO - 2023-09-19 08:04:57 --> Helper loaded: lang_helper
INFO - 2023-09-19 08:04:57 --> Helper loaded: security_helper
INFO - 2023-09-19 08:04:57 --> Helper loaded: cookie_helper
INFO - 2023-09-19 08:04:57 --> Database Driver Class Initialized
INFO - 2023-09-19 08:04:57 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-19 08:04:57 --> Parser Class Initialized
INFO - 2023-09-19 08:04:57 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-19 08:04:57 --> Pagination Class Initialized
INFO - 2023-09-19 08:04:57 --> Form Validation Class Initialized
INFO - 2023-09-19 08:04:57 --> Controller Class Initialized
INFO - 2023-09-19 08:04:57 --> Model Class Initialized
DEBUG - 2023-09-19 08:04:57 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-09-19 08:04:57 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-19 08:04:57 --> Model Class Initialized
DEBUG - 2023-09-19 08:04:57 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-19 08:04:57 --> Model Class Initialized
INFO - 2023-09-19 08:04:57 --> Final output sent to browser
DEBUG - 2023-09-19 08:04:57 --> Total execution time: 0.0192
ERROR - 2023-09-19 08:05:16 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-19 08:05:16 --> Config Class Initialized
INFO - 2023-09-19 08:05:16 --> Hooks Class Initialized
DEBUG - 2023-09-19 08:05:16 --> UTF-8 Support Enabled
INFO - 2023-09-19 08:05:16 --> Utf8 Class Initialized
INFO - 2023-09-19 08:05:16 --> URI Class Initialized
DEBUG - 2023-09-19 08:05:16 --> No URI present. Default controller set.
INFO - 2023-09-19 08:05:16 --> Router Class Initialized
INFO - 2023-09-19 08:05:16 --> Output Class Initialized
INFO - 2023-09-19 08:05:16 --> Security Class Initialized
DEBUG - 2023-09-19 08:05:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-19 08:05:16 --> Input Class Initialized
INFO - 2023-09-19 08:05:16 --> Language Class Initialized
INFO - 2023-09-19 08:05:16 --> Loader Class Initialized
INFO - 2023-09-19 08:05:16 --> Helper loaded: url_helper
INFO - 2023-09-19 08:05:16 --> Helper loaded: file_helper
INFO - 2023-09-19 08:05:16 --> Helper loaded: html_helper
INFO - 2023-09-19 08:05:16 --> Helper loaded: text_helper
INFO - 2023-09-19 08:05:16 --> Helper loaded: form_helper
INFO - 2023-09-19 08:05:16 --> Helper loaded: lang_helper
INFO - 2023-09-19 08:05:16 --> Helper loaded: security_helper
INFO - 2023-09-19 08:05:16 --> Helper loaded: cookie_helper
INFO - 2023-09-19 08:05:16 --> Database Driver Class Initialized
INFO - 2023-09-19 08:05:16 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-19 08:05:16 --> Parser Class Initialized
INFO - 2023-09-19 08:05:16 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-19 08:05:16 --> Pagination Class Initialized
INFO - 2023-09-19 08:05:16 --> Form Validation Class Initialized
INFO - 2023-09-19 08:05:16 --> Controller Class Initialized
INFO - 2023-09-19 08:05:16 --> Model Class Initialized
DEBUG - 2023-09-19 08:05:16 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-19 08:05:16 --> Model Class Initialized
DEBUG - 2023-09-19 08:05:16 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-19 08:05:16 --> Model Class Initialized
INFO - 2023-09-19 08:05:16 --> Model Class Initialized
INFO - 2023-09-19 08:05:16 --> Model Class Initialized
INFO - 2023-09-19 08:05:16 --> Model Class Initialized
DEBUG - 2023-09-19 08:05:16 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-09-19 08:05:16 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-19 08:05:16 --> Model Class Initialized
INFO - 2023-09-19 08:05:16 --> Model Class Initialized
INFO - 2023-09-19 08:05:16 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-09-19 08:05:16 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-09-19 08:05:16 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-09-19 08:05:16 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-09-19 08:05:16 --> Model Class Initialized
INFO - 2023-09-19 08:05:16 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-09-19 08:05:16 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-09-19 08:05:16 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-09-19 08:05:16 --> Final output sent to browser
DEBUG - 2023-09-19 08:05:16 --> Total execution time: 0.0887
ERROR - 2023-09-19 08:05:18 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-19 08:05:18 --> Config Class Initialized
INFO - 2023-09-19 08:05:18 --> Hooks Class Initialized
DEBUG - 2023-09-19 08:05:18 --> UTF-8 Support Enabled
INFO - 2023-09-19 08:05:18 --> Utf8 Class Initialized
INFO - 2023-09-19 08:05:18 --> URI Class Initialized
INFO - 2023-09-19 08:05:18 --> Router Class Initialized
INFO - 2023-09-19 08:05:18 --> Output Class Initialized
INFO - 2023-09-19 08:05:18 --> Security Class Initialized
DEBUG - 2023-09-19 08:05:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-19 08:05:18 --> Input Class Initialized
INFO - 2023-09-19 08:05:18 --> Language Class Initialized
INFO - 2023-09-19 08:05:18 --> Loader Class Initialized
INFO - 2023-09-19 08:05:18 --> Helper loaded: url_helper
INFO - 2023-09-19 08:05:18 --> Helper loaded: file_helper
INFO - 2023-09-19 08:05:18 --> Helper loaded: html_helper
INFO - 2023-09-19 08:05:18 --> Helper loaded: text_helper
INFO - 2023-09-19 08:05:18 --> Helper loaded: form_helper
INFO - 2023-09-19 08:05:18 --> Helper loaded: lang_helper
INFO - 2023-09-19 08:05:18 --> Helper loaded: security_helper
INFO - 2023-09-19 08:05:18 --> Helper loaded: cookie_helper
INFO - 2023-09-19 08:05:18 --> Database Driver Class Initialized
INFO - 2023-09-19 08:05:18 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-19 08:05:18 --> Parser Class Initialized
INFO - 2023-09-19 08:05:18 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-19 08:05:18 --> Pagination Class Initialized
INFO - 2023-09-19 08:05:18 --> Form Validation Class Initialized
INFO - 2023-09-19 08:05:18 --> Controller Class Initialized
INFO - 2023-09-19 08:05:18 --> Model Class Initialized
DEBUG - 2023-09-19 08:05:18 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-19 08:05:18 --> Model Class Initialized
DEBUG - 2023-09-19 08:05:18 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-19 08:05:18 --> Model Class Initialized
INFO - 2023-09-19 08:05:18 --> Model Class Initialized
INFO - 2023-09-19 08:05:18 --> Model Class Initialized
INFO - 2023-09-19 08:05:18 --> Model Class Initialized
DEBUG - 2023-09-19 08:05:18 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-09-19 08:05:18 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-19 08:05:18 --> Model Class Initialized
INFO - 2023-09-19 08:05:18 --> Model Class Initialized
INFO - 2023-09-19 08:05:18 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-09-19 08:05:18 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-09-19 08:05:18 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-09-19 08:05:18 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-09-19 08:05:18 --> Model Class Initialized
INFO - 2023-09-19 08:05:18 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-09-19 08:05:18 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-09-19 08:05:18 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-09-19 08:05:18 --> Final output sent to browser
DEBUG - 2023-09-19 08:05:18 --> Total execution time: 0.0911
ERROR - 2023-09-19 08:05:31 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-19 08:05:31 --> Config Class Initialized
INFO - 2023-09-19 08:05:31 --> Hooks Class Initialized
DEBUG - 2023-09-19 08:05:31 --> UTF-8 Support Enabled
INFO - 2023-09-19 08:05:31 --> Utf8 Class Initialized
INFO - 2023-09-19 08:05:31 --> URI Class Initialized
INFO - 2023-09-19 08:05:31 --> Router Class Initialized
INFO - 2023-09-19 08:05:31 --> Output Class Initialized
INFO - 2023-09-19 08:05:31 --> Security Class Initialized
DEBUG - 2023-09-19 08:05:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-19 08:05:31 --> Input Class Initialized
INFO - 2023-09-19 08:05:31 --> Language Class Initialized
INFO - 2023-09-19 08:05:31 --> Loader Class Initialized
INFO - 2023-09-19 08:05:31 --> Helper loaded: url_helper
INFO - 2023-09-19 08:05:31 --> Helper loaded: file_helper
INFO - 2023-09-19 08:05:31 --> Helper loaded: html_helper
INFO - 2023-09-19 08:05:31 --> Helper loaded: text_helper
INFO - 2023-09-19 08:05:31 --> Helper loaded: form_helper
INFO - 2023-09-19 08:05:31 --> Helper loaded: lang_helper
INFO - 2023-09-19 08:05:31 --> Helper loaded: security_helper
INFO - 2023-09-19 08:05:31 --> Helper loaded: cookie_helper
INFO - 2023-09-19 08:05:31 --> Database Driver Class Initialized
INFO - 2023-09-19 08:05:31 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-19 08:05:31 --> Parser Class Initialized
INFO - 2023-09-19 08:05:31 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-19 08:05:31 --> Pagination Class Initialized
INFO - 2023-09-19 08:05:31 --> Form Validation Class Initialized
INFO - 2023-09-19 08:05:31 --> Controller Class Initialized
INFO - 2023-09-19 08:05:31 --> Model Class Initialized
DEBUG - 2023-09-19 08:05:31 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-19 08:05:31 --> Model Class Initialized
INFO - 2023-09-19 08:05:31 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/edit_profile.php
DEBUG - 2023-09-19 08:05:31 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-09-19 08:05:31 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-09-19 08:05:31 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-09-19 08:05:31 --> Model Class Initialized
INFO - 2023-09-19 08:05:31 --> Model Class Initialized
INFO - 2023-09-19 08:05:31 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-09-19 08:05:31 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-09-19 08:05:31 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-09-19 08:05:31 --> Final output sent to browser
DEBUG - 2023-09-19 08:05:31 --> Total execution time: 0.0805
ERROR - 2023-09-19 08:05:32 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-19 08:05:32 --> Config Class Initialized
INFO - 2023-09-19 08:05:32 --> Hooks Class Initialized
DEBUG - 2023-09-19 08:05:32 --> UTF-8 Support Enabled
INFO - 2023-09-19 08:05:32 --> Utf8 Class Initialized
INFO - 2023-09-19 08:05:32 --> URI Class Initialized
INFO - 2023-09-19 08:05:32 --> Router Class Initialized
INFO - 2023-09-19 08:05:32 --> Output Class Initialized
INFO - 2023-09-19 08:05:32 --> Security Class Initialized
DEBUG - 2023-09-19 08:05:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-19 08:05:32 --> Input Class Initialized
INFO - 2023-09-19 08:05:32 --> Language Class Initialized
INFO - 2023-09-19 08:05:32 --> Loader Class Initialized
INFO - 2023-09-19 08:05:32 --> Helper loaded: url_helper
INFO - 2023-09-19 08:05:32 --> Helper loaded: file_helper
INFO - 2023-09-19 08:05:32 --> Helper loaded: html_helper
INFO - 2023-09-19 08:05:32 --> Helper loaded: text_helper
INFO - 2023-09-19 08:05:32 --> Helper loaded: form_helper
INFO - 2023-09-19 08:05:32 --> Helper loaded: lang_helper
INFO - 2023-09-19 08:05:32 --> Helper loaded: security_helper
INFO - 2023-09-19 08:05:32 --> Helper loaded: cookie_helper
INFO - 2023-09-19 08:05:32 --> Database Driver Class Initialized
INFO - 2023-09-19 08:05:32 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-19 08:05:32 --> Parser Class Initialized
INFO - 2023-09-19 08:05:32 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-19 08:05:32 --> Pagination Class Initialized
INFO - 2023-09-19 08:05:32 --> Form Validation Class Initialized
INFO - 2023-09-19 08:05:32 --> Controller Class Initialized
INFO - 2023-09-19 08:05:32 --> Model Class Initialized
DEBUG - 2023-09-19 08:05:32 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-19 08:05:32 --> Model Class Initialized
INFO - 2023-09-19 08:05:32 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/edit_profile.php
DEBUG - 2023-09-19 08:05:32 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-09-19 08:05:32 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-09-19 08:05:32 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-09-19 08:05:32 --> Model Class Initialized
INFO - 2023-09-19 08:05:32 --> Model Class Initialized
INFO - 2023-09-19 08:05:32 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-09-19 08:05:32 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-09-19 08:05:32 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-09-19 08:05:32 --> Final output sent to browser
DEBUG - 2023-09-19 08:05:32 --> Total execution time: 0.0718
ERROR - 2023-09-19 08:05:42 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-19 08:05:42 --> Config Class Initialized
INFO - 2023-09-19 08:05:42 --> Hooks Class Initialized
DEBUG - 2023-09-19 08:05:42 --> UTF-8 Support Enabled
INFO - 2023-09-19 08:05:42 --> Utf8 Class Initialized
INFO - 2023-09-19 08:05:42 --> URI Class Initialized
INFO - 2023-09-19 08:05:42 --> Router Class Initialized
INFO - 2023-09-19 08:05:42 --> Output Class Initialized
INFO - 2023-09-19 08:05:42 --> Security Class Initialized
DEBUG - 2023-09-19 08:05:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-19 08:05:42 --> Input Class Initialized
INFO - 2023-09-19 08:05:42 --> Language Class Initialized
INFO - 2023-09-19 08:05:42 --> Loader Class Initialized
INFO - 2023-09-19 08:05:42 --> Helper loaded: url_helper
INFO - 2023-09-19 08:05:42 --> Helper loaded: file_helper
INFO - 2023-09-19 08:05:42 --> Helper loaded: html_helper
INFO - 2023-09-19 08:05:42 --> Helper loaded: text_helper
INFO - 2023-09-19 08:05:42 --> Helper loaded: form_helper
INFO - 2023-09-19 08:05:42 --> Helper loaded: lang_helper
INFO - 2023-09-19 08:05:42 --> Helper loaded: security_helper
INFO - 2023-09-19 08:05:42 --> Helper loaded: cookie_helper
INFO - 2023-09-19 08:05:42 --> Database Driver Class Initialized
INFO - 2023-09-19 08:05:42 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-19 08:05:42 --> Parser Class Initialized
INFO - 2023-09-19 08:05:42 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-19 08:05:42 --> Pagination Class Initialized
INFO - 2023-09-19 08:05:42 --> Form Validation Class Initialized
INFO - 2023-09-19 08:05:42 --> Controller Class Initialized
INFO - 2023-09-19 08:05:42 --> Model Class Initialized
DEBUG - 2023-09-19 08:05:42 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-19 08:05:42 --> Model Class Initialized
DEBUG - 2023-09-19 08:05:42 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-19 08:05:42 --> Model Class Initialized
INFO - 2023-09-19 08:05:42 --> Model Class Initialized
INFO - 2023-09-19 08:05:42 --> Model Class Initialized
INFO - 2023-09-19 08:05:42 --> Model Class Initialized
DEBUG - 2023-09-19 08:05:42 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-09-19 08:05:42 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-19 08:05:42 --> Model Class Initialized
INFO - 2023-09-19 08:05:42 --> Model Class Initialized
INFO - 2023-09-19 08:05:42 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-09-19 08:05:42 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-09-19 08:05:42 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-09-19 08:05:42 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-09-19 08:05:42 --> Model Class Initialized
INFO - 2023-09-19 08:05:42 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-09-19 08:05:42 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-09-19 08:05:42 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-09-19 08:05:42 --> Final output sent to browser
DEBUG - 2023-09-19 08:05:42 --> Total execution time: 0.0899
ERROR - 2023-09-19 08:06:10 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-19 08:06:10 --> Config Class Initialized
INFO - 2023-09-19 08:06:10 --> Hooks Class Initialized
DEBUG - 2023-09-19 08:06:10 --> UTF-8 Support Enabled
INFO - 2023-09-19 08:06:10 --> Utf8 Class Initialized
INFO - 2023-09-19 08:06:10 --> URI Class Initialized
DEBUG - 2023-09-19 08:06:10 --> No URI present. Default controller set.
INFO - 2023-09-19 08:06:10 --> Router Class Initialized
INFO - 2023-09-19 08:06:10 --> Output Class Initialized
INFO - 2023-09-19 08:06:10 --> Security Class Initialized
DEBUG - 2023-09-19 08:06:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-19 08:06:10 --> Input Class Initialized
INFO - 2023-09-19 08:06:10 --> Language Class Initialized
INFO - 2023-09-19 08:06:10 --> Loader Class Initialized
INFO - 2023-09-19 08:06:10 --> Helper loaded: url_helper
INFO - 2023-09-19 08:06:10 --> Helper loaded: file_helper
INFO - 2023-09-19 08:06:10 --> Helper loaded: html_helper
INFO - 2023-09-19 08:06:10 --> Helper loaded: text_helper
INFO - 2023-09-19 08:06:10 --> Helper loaded: form_helper
INFO - 2023-09-19 08:06:10 --> Helper loaded: lang_helper
INFO - 2023-09-19 08:06:10 --> Helper loaded: security_helper
INFO - 2023-09-19 08:06:10 --> Helper loaded: cookie_helper
INFO - 2023-09-19 08:06:10 --> Database Driver Class Initialized
INFO - 2023-09-19 08:06:10 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-19 08:06:10 --> Parser Class Initialized
INFO - 2023-09-19 08:06:10 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-19 08:06:10 --> Pagination Class Initialized
INFO - 2023-09-19 08:06:10 --> Form Validation Class Initialized
INFO - 2023-09-19 08:06:10 --> Controller Class Initialized
INFO - 2023-09-19 08:06:10 --> Model Class Initialized
DEBUG - 2023-09-19 08:06:10 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-19 08:06:10 --> Model Class Initialized
DEBUG - 2023-09-19 08:06:10 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-19 08:06:10 --> Model Class Initialized
INFO - 2023-09-19 08:06:10 --> Model Class Initialized
INFO - 2023-09-19 08:06:10 --> Model Class Initialized
INFO - 2023-09-19 08:06:10 --> Model Class Initialized
DEBUG - 2023-09-19 08:06:10 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-09-19 08:06:10 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-19 08:06:10 --> Model Class Initialized
INFO - 2023-09-19 08:06:10 --> Model Class Initialized
INFO - 2023-09-19 08:06:10 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-09-19 08:06:10 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-09-19 08:06:10 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-09-19 08:06:10 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-09-19 08:06:10 --> Model Class Initialized
INFO - 2023-09-19 08:06:10 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-09-19 08:06:10 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-09-19 08:06:10 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-09-19 08:06:10 --> Final output sent to browser
DEBUG - 2023-09-19 08:06:10 --> Total execution time: 0.0960
ERROR - 2023-09-19 08:06:14 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-19 08:06:14 --> Config Class Initialized
INFO - 2023-09-19 08:06:14 --> Hooks Class Initialized
DEBUG - 2023-09-19 08:06:14 --> UTF-8 Support Enabled
INFO - 2023-09-19 08:06:14 --> Utf8 Class Initialized
INFO - 2023-09-19 08:06:14 --> URI Class Initialized
INFO - 2023-09-19 08:06:14 --> Router Class Initialized
INFO - 2023-09-19 08:06:14 --> Output Class Initialized
INFO - 2023-09-19 08:06:14 --> Security Class Initialized
DEBUG - 2023-09-19 08:06:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-19 08:06:14 --> Input Class Initialized
INFO - 2023-09-19 08:06:14 --> Language Class Initialized
INFO - 2023-09-19 08:06:14 --> Loader Class Initialized
INFO - 2023-09-19 08:06:14 --> Helper loaded: url_helper
INFO - 2023-09-19 08:06:14 --> Helper loaded: file_helper
INFO - 2023-09-19 08:06:14 --> Helper loaded: html_helper
INFO - 2023-09-19 08:06:14 --> Helper loaded: text_helper
INFO - 2023-09-19 08:06:14 --> Helper loaded: form_helper
INFO - 2023-09-19 08:06:14 --> Helper loaded: lang_helper
INFO - 2023-09-19 08:06:14 --> Helper loaded: security_helper
INFO - 2023-09-19 08:06:14 --> Helper loaded: cookie_helper
INFO - 2023-09-19 08:06:14 --> Database Driver Class Initialized
INFO - 2023-09-19 08:06:14 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-19 08:06:14 --> Parser Class Initialized
INFO - 2023-09-19 08:06:14 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-19 08:06:14 --> Pagination Class Initialized
INFO - 2023-09-19 08:06:14 --> Form Validation Class Initialized
INFO - 2023-09-19 08:06:14 --> Controller Class Initialized
INFO - 2023-09-19 08:06:14 --> Model Class Initialized
DEBUG - 2023-09-19 08:06:14 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-09-19 08:06:14 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-19 08:06:14 --> Model Class Initialized
DEBUG - 2023-09-19 08:06:14 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-19 08:06:14 --> Model Class Initialized
INFO - 2023-09-19 08:06:14 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/invoice/invoice.php
DEBUG - 2023-09-19 08:06:14 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-09-19 08:06:14 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-09-19 08:06:14 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-09-19 08:06:14 --> Model Class Initialized
INFO - 2023-09-19 08:06:14 --> Model Class Initialized
INFO - 2023-09-19 08:06:14 --> Model Class Initialized
INFO - 2023-09-19 08:06:14 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-09-19 08:06:14 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-09-19 08:06:14 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-09-19 08:06:14 --> Final output sent to browser
DEBUG - 2023-09-19 08:06:14 --> Total execution time: 0.0800
ERROR - 2023-09-19 08:06:15 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-19 08:06:15 --> Config Class Initialized
INFO - 2023-09-19 08:06:15 --> Hooks Class Initialized
DEBUG - 2023-09-19 08:06:15 --> UTF-8 Support Enabled
INFO - 2023-09-19 08:06:15 --> Utf8 Class Initialized
INFO - 2023-09-19 08:06:15 --> URI Class Initialized
INFO - 2023-09-19 08:06:15 --> Router Class Initialized
INFO - 2023-09-19 08:06:15 --> Output Class Initialized
INFO - 2023-09-19 08:06:15 --> Security Class Initialized
DEBUG - 2023-09-19 08:06:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-19 08:06:15 --> Input Class Initialized
INFO - 2023-09-19 08:06:15 --> Language Class Initialized
INFO - 2023-09-19 08:06:15 --> Loader Class Initialized
INFO - 2023-09-19 08:06:15 --> Helper loaded: url_helper
INFO - 2023-09-19 08:06:15 --> Helper loaded: file_helper
INFO - 2023-09-19 08:06:15 --> Helper loaded: html_helper
INFO - 2023-09-19 08:06:15 --> Helper loaded: text_helper
INFO - 2023-09-19 08:06:15 --> Helper loaded: form_helper
INFO - 2023-09-19 08:06:15 --> Helper loaded: lang_helper
INFO - 2023-09-19 08:06:15 --> Helper loaded: security_helper
INFO - 2023-09-19 08:06:15 --> Helper loaded: cookie_helper
INFO - 2023-09-19 08:06:15 --> Database Driver Class Initialized
INFO - 2023-09-19 08:06:15 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-19 08:06:15 --> Parser Class Initialized
INFO - 2023-09-19 08:06:15 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-19 08:06:15 --> Pagination Class Initialized
INFO - 2023-09-19 08:06:15 --> Form Validation Class Initialized
INFO - 2023-09-19 08:06:15 --> Controller Class Initialized
INFO - 2023-09-19 08:06:15 --> Model Class Initialized
DEBUG - 2023-09-19 08:06:15 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-09-19 08:06:15 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-19 08:06:15 --> Model Class Initialized
DEBUG - 2023-09-19 08:06:15 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-19 08:06:15 --> Model Class Initialized
INFO - 2023-09-19 08:06:15 --> Final output sent to browser
DEBUG - 2023-09-19 08:06:15 --> Total execution time: 0.0206
ERROR - 2023-09-19 08:06:39 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-19 08:06:39 --> Config Class Initialized
INFO - 2023-09-19 08:06:39 --> Hooks Class Initialized
DEBUG - 2023-09-19 08:06:39 --> UTF-8 Support Enabled
INFO - 2023-09-19 08:06:39 --> Utf8 Class Initialized
INFO - 2023-09-19 08:06:39 --> URI Class Initialized
DEBUG - 2023-09-19 08:06:39 --> No URI present. Default controller set.
INFO - 2023-09-19 08:06:39 --> Router Class Initialized
INFO - 2023-09-19 08:06:39 --> Output Class Initialized
INFO - 2023-09-19 08:06:39 --> Security Class Initialized
DEBUG - 2023-09-19 08:06:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-19 08:06:39 --> Input Class Initialized
INFO - 2023-09-19 08:06:39 --> Language Class Initialized
INFO - 2023-09-19 08:06:39 --> Loader Class Initialized
INFO - 2023-09-19 08:06:39 --> Helper loaded: url_helper
INFO - 2023-09-19 08:06:39 --> Helper loaded: file_helper
INFO - 2023-09-19 08:06:39 --> Helper loaded: html_helper
INFO - 2023-09-19 08:06:39 --> Helper loaded: text_helper
INFO - 2023-09-19 08:06:39 --> Helper loaded: form_helper
INFO - 2023-09-19 08:06:39 --> Helper loaded: lang_helper
INFO - 2023-09-19 08:06:39 --> Helper loaded: security_helper
INFO - 2023-09-19 08:06:39 --> Helper loaded: cookie_helper
INFO - 2023-09-19 08:06:39 --> Database Driver Class Initialized
INFO - 2023-09-19 08:06:39 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-19 08:06:39 --> Parser Class Initialized
INFO - 2023-09-19 08:06:39 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-19 08:06:39 --> Pagination Class Initialized
INFO - 2023-09-19 08:06:39 --> Form Validation Class Initialized
INFO - 2023-09-19 08:06:39 --> Controller Class Initialized
INFO - 2023-09-19 08:06:39 --> Model Class Initialized
DEBUG - 2023-09-19 08:06:39 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-19 08:06:39 --> Model Class Initialized
DEBUG - 2023-09-19 08:06:39 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-19 08:06:39 --> Model Class Initialized
INFO - 2023-09-19 08:06:39 --> Model Class Initialized
INFO - 2023-09-19 08:06:39 --> Model Class Initialized
INFO - 2023-09-19 08:06:39 --> Model Class Initialized
DEBUG - 2023-09-19 08:06:39 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-09-19 08:06:39 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-19 08:06:39 --> Model Class Initialized
INFO - 2023-09-19 08:06:39 --> Model Class Initialized
INFO - 2023-09-19 08:06:39 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-09-19 08:06:39 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-09-19 08:06:39 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-09-19 08:06:39 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-09-19 08:06:39 --> Model Class Initialized
INFO - 2023-09-19 08:06:40 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-09-19 08:06:40 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-09-19 08:06:40 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-09-19 08:06:40 --> Final output sent to browser
DEBUG - 2023-09-19 08:06:40 --> Total execution time: 0.0925
ERROR - 2023-09-19 08:06:56 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-19 08:06:56 --> Config Class Initialized
INFO - 2023-09-19 08:06:56 --> Hooks Class Initialized
DEBUG - 2023-09-19 08:06:56 --> UTF-8 Support Enabled
INFO - 2023-09-19 08:06:56 --> Utf8 Class Initialized
INFO - 2023-09-19 08:06:56 --> URI Class Initialized
INFO - 2023-09-19 08:06:56 --> Router Class Initialized
INFO - 2023-09-19 08:06:56 --> Output Class Initialized
INFO - 2023-09-19 08:06:56 --> Security Class Initialized
DEBUG - 2023-09-19 08:06:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-19 08:06:56 --> Input Class Initialized
INFO - 2023-09-19 08:06:56 --> Language Class Initialized
INFO - 2023-09-19 08:06:56 --> Loader Class Initialized
INFO - 2023-09-19 08:06:56 --> Helper loaded: url_helper
INFO - 2023-09-19 08:06:56 --> Helper loaded: file_helper
INFO - 2023-09-19 08:06:56 --> Helper loaded: html_helper
INFO - 2023-09-19 08:06:56 --> Helper loaded: text_helper
INFO - 2023-09-19 08:06:56 --> Helper loaded: form_helper
INFO - 2023-09-19 08:06:56 --> Helper loaded: lang_helper
INFO - 2023-09-19 08:06:56 --> Helper loaded: security_helper
INFO - 2023-09-19 08:06:56 --> Helper loaded: cookie_helper
INFO - 2023-09-19 08:06:56 --> Database Driver Class Initialized
INFO - 2023-09-19 08:06:56 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-19 08:06:56 --> Parser Class Initialized
INFO - 2023-09-19 08:06:56 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-19 08:06:56 --> Pagination Class Initialized
INFO - 2023-09-19 08:06:56 --> Form Validation Class Initialized
INFO - 2023-09-19 08:06:56 --> Controller Class Initialized
INFO - 2023-09-19 08:06:56 --> Model Class Initialized
DEBUG - 2023-09-19 08:06:56 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-09-19 08:06:56 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-19 08:06:56 --> Model Class Initialized
DEBUG - 2023-09-19 08:06:56 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-19 08:06:56 --> Model Class Initialized
INFO - 2023-09-19 08:06:56 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice.php
DEBUG - 2023-09-19 08:06:56 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-09-19 08:06:56 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-09-19 08:06:56 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-09-19 08:06:56 --> Model Class Initialized
INFO - 2023-09-19 08:06:56 --> Model Class Initialized
INFO - 2023-09-19 08:06:56 --> Model Class Initialized
INFO - 2023-09-19 08:06:56 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-09-19 08:06:56 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-09-19 08:06:56 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-09-19 08:06:56 --> Final output sent to browser
DEBUG - 2023-09-19 08:06:56 --> Total execution time: 0.0800
ERROR - 2023-09-19 08:06:56 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-19 08:06:56 --> Config Class Initialized
INFO - 2023-09-19 08:06:56 --> Hooks Class Initialized
DEBUG - 2023-09-19 08:06:56 --> UTF-8 Support Enabled
INFO - 2023-09-19 08:06:56 --> Utf8 Class Initialized
INFO - 2023-09-19 08:06:56 --> URI Class Initialized
INFO - 2023-09-19 08:06:56 --> Router Class Initialized
INFO - 2023-09-19 08:06:56 --> Output Class Initialized
INFO - 2023-09-19 08:06:56 --> Security Class Initialized
DEBUG - 2023-09-19 08:06:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-19 08:06:56 --> Input Class Initialized
INFO - 2023-09-19 08:06:56 --> Language Class Initialized
INFO - 2023-09-19 08:06:56 --> Loader Class Initialized
INFO - 2023-09-19 08:06:56 --> Helper loaded: url_helper
INFO - 2023-09-19 08:06:56 --> Helper loaded: file_helper
INFO - 2023-09-19 08:06:56 --> Helper loaded: html_helper
INFO - 2023-09-19 08:06:56 --> Helper loaded: text_helper
INFO - 2023-09-19 08:06:56 --> Helper loaded: form_helper
INFO - 2023-09-19 08:06:56 --> Helper loaded: lang_helper
INFO - 2023-09-19 08:06:56 --> Helper loaded: security_helper
INFO - 2023-09-19 08:06:56 --> Helper loaded: cookie_helper
INFO - 2023-09-19 08:06:56 --> Database Driver Class Initialized
INFO - 2023-09-19 08:06:56 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-19 08:06:56 --> Parser Class Initialized
INFO - 2023-09-19 08:06:56 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-19 08:06:56 --> Pagination Class Initialized
INFO - 2023-09-19 08:06:56 --> Form Validation Class Initialized
INFO - 2023-09-19 08:06:56 --> Controller Class Initialized
INFO - 2023-09-19 08:06:56 --> Model Class Initialized
DEBUG - 2023-09-19 08:06:56 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-09-19 08:06:56 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-19 08:06:56 --> Model Class Initialized
DEBUG - 2023-09-19 08:06:56 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-19 08:06:56 --> Model Class Initialized
INFO - 2023-09-19 08:06:56 --> Final output sent to browser
DEBUG - 2023-09-19 08:06:56 --> Total execution time: 0.0234
ERROR - 2023-09-19 08:07:18 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-19 08:07:18 --> Config Class Initialized
INFO - 2023-09-19 08:07:18 --> Hooks Class Initialized
DEBUG - 2023-09-19 08:07:18 --> UTF-8 Support Enabled
INFO - 2023-09-19 08:07:18 --> Utf8 Class Initialized
INFO - 2023-09-19 08:07:18 --> URI Class Initialized
INFO - 2023-09-19 08:07:18 --> Router Class Initialized
INFO - 2023-09-19 08:07:18 --> Output Class Initialized
INFO - 2023-09-19 08:07:18 --> Security Class Initialized
DEBUG - 2023-09-19 08:07:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-19 08:07:18 --> Input Class Initialized
INFO - 2023-09-19 08:07:18 --> Language Class Initialized
INFO - 2023-09-19 08:07:18 --> Loader Class Initialized
INFO - 2023-09-19 08:07:18 --> Helper loaded: url_helper
INFO - 2023-09-19 08:07:18 --> Helper loaded: file_helper
INFO - 2023-09-19 08:07:18 --> Helper loaded: html_helper
INFO - 2023-09-19 08:07:18 --> Helper loaded: text_helper
INFO - 2023-09-19 08:07:18 --> Helper loaded: form_helper
INFO - 2023-09-19 08:07:18 --> Helper loaded: lang_helper
INFO - 2023-09-19 08:07:18 --> Helper loaded: security_helper
INFO - 2023-09-19 08:07:18 --> Helper loaded: cookie_helper
INFO - 2023-09-19 08:07:18 --> Database Driver Class Initialized
INFO - 2023-09-19 08:07:18 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-19 08:07:18 --> Parser Class Initialized
INFO - 2023-09-19 08:07:18 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-19 08:07:18 --> Pagination Class Initialized
INFO - 2023-09-19 08:07:18 --> Form Validation Class Initialized
INFO - 2023-09-19 08:07:18 --> Controller Class Initialized
INFO - 2023-09-19 08:07:18 --> Model Class Initialized
DEBUG - 2023-09-19 08:07:18 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-09-19 08:07:18 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-19 08:07:18 --> Model Class Initialized
DEBUG - 2023-09-19 08:07:18 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-19 08:07:18 --> Model Class Initialized
INFO - 2023-09-19 08:07:18 --> Final output sent to browser
DEBUG - 2023-09-19 08:07:18 --> Total execution time: 0.0251
ERROR - 2023-09-19 08:07:38 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-19 08:07:38 --> Config Class Initialized
INFO - 2023-09-19 08:07:38 --> Hooks Class Initialized
DEBUG - 2023-09-19 08:07:38 --> UTF-8 Support Enabled
INFO - 2023-09-19 08:07:38 --> Utf8 Class Initialized
INFO - 2023-09-19 08:07:38 --> URI Class Initialized
INFO - 2023-09-19 08:07:38 --> Router Class Initialized
INFO - 2023-09-19 08:07:38 --> Output Class Initialized
INFO - 2023-09-19 08:07:38 --> Security Class Initialized
DEBUG - 2023-09-19 08:07:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-19 08:07:38 --> Input Class Initialized
INFO - 2023-09-19 08:07:38 --> Language Class Initialized
INFO - 2023-09-19 08:07:38 --> Loader Class Initialized
INFO - 2023-09-19 08:07:38 --> Helper loaded: url_helper
INFO - 2023-09-19 08:07:38 --> Helper loaded: file_helper
INFO - 2023-09-19 08:07:38 --> Helper loaded: html_helper
INFO - 2023-09-19 08:07:38 --> Helper loaded: text_helper
INFO - 2023-09-19 08:07:38 --> Helper loaded: form_helper
INFO - 2023-09-19 08:07:38 --> Helper loaded: lang_helper
INFO - 2023-09-19 08:07:38 --> Helper loaded: security_helper
INFO - 2023-09-19 08:07:38 --> Helper loaded: cookie_helper
INFO - 2023-09-19 08:07:38 --> Database Driver Class Initialized
INFO - 2023-09-19 08:07:38 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-19 08:07:38 --> Parser Class Initialized
INFO - 2023-09-19 08:07:38 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-19 08:07:38 --> Pagination Class Initialized
INFO - 2023-09-19 08:07:38 --> Form Validation Class Initialized
INFO - 2023-09-19 08:07:38 --> Controller Class Initialized
INFO - 2023-09-19 08:07:38 --> Model Class Initialized
DEBUG - 2023-09-19 08:07:38 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-19 08:07:38 --> Model Class Initialized
INFO - 2023-09-19 08:07:38 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/edit_profile.php
DEBUG - 2023-09-19 08:07:38 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-09-19 08:07:38 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-09-19 08:07:38 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-09-19 08:07:38 --> Model Class Initialized
INFO - 2023-09-19 08:07:38 --> Model Class Initialized
INFO - 2023-09-19 08:07:38 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-09-19 08:07:38 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-09-19 08:07:38 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-09-19 08:07:38 --> Final output sent to browser
DEBUG - 2023-09-19 08:07:38 --> Total execution time: 0.0649
ERROR - 2023-09-19 08:07:38 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-19 08:07:38 --> Config Class Initialized
INFO - 2023-09-19 08:07:38 --> Hooks Class Initialized
DEBUG - 2023-09-19 08:07:38 --> UTF-8 Support Enabled
INFO - 2023-09-19 08:07:38 --> Utf8 Class Initialized
INFO - 2023-09-19 08:07:38 --> URI Class Initialized
INFO - 2023-09-19 08:07:38 --> Router Class Initialized
INFO - 2023-09-19 08:07:38 --> Output Class Initialized
INFO - 2023-09-19 08:07:38 --> Security Class Initialized
DEBUG - 2023-09-19 08:07:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-19 08:07:38 --> Input Class Initialized
INFO - 2023-09-19 08:07:38 --> Language Class Initialized
INFO - 2023-09-19 08:07:38 --> Loader Class Initialized
INFO - 2023-09-19 08:07:38 --> Helper loaded: url_helper
INFO - 2023-09-19 08:07:38 --> Helper loaded: file_helper
INFO - 2023-09-19 08:07:38 --> Helper loaded: html_helper
INFO - 2023-09-19 08:07:38 --> Helper loaded: text_helper
INFO - 2023-09-19 08:07:38 --> Helper loaded: form_helper
INFO - 2023-09-19 08:07:38 --> Helper loaded: lang_helper
INFO - 2023-09-19 08:07:38 --> Helper loaded: security_helper
INFO - 2023-09-19 08:07:38 --> Helper loaded: cookie_helper
INFO - 2023-09-19 08:07:38 --> Database Driver Class Initialized
INFO - 2023-09-19 08:07:38 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-19 08:07:38 --> Parser Class Initialized
INFO - 2023-09-19 08:07:38 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-19 08:07:38 --> Pagination Class Initialized
INFO - 2023-09-19 08:07:38 --> Form Validation Class Initialized
INFO - 2023-09-19 08:07:38 --> Controller Class Initialized
INFO - 2023-09-19 08:07:38 --> Model Class Initialized
DEBUG - 2023-09-19 08:07:38 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-19 08:07:38 --> Model Class Initialized
INFO - 2023-09-19 08:07:38 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/edit_profile.php
DEBUG - 2023-09-19 08:07:38 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-09-19 08:07:38 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-09-19 08:07:38 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-09-19 08:07:38 --> Model Class Initialized
INFO - 2023-09-19 08:07:38 --> Model Class Initialized
INFO - 2023-09-19 08:07:39 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-09-19 08:07:39 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-09-19 08:07:39 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-09-19 08:07:39 --> Final output sent to browser
DEBUG - 2023-09-19 08:07:39 --> Total execution time: 0.0620
ERROR - 2023-09-19 08:07:49 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-19 08:07:49 --> Config Class Initialized
INFO - 2023-09-19 08:07:49 --> Hooks Class Initialized
DEBUG - 2023-09-19 08:07:49 --> UTF-8 Support Enabled
INFO - 2023-09-19 08:07:49 --> Utf8 Class Initialized
INFO - 2023-09-19 08:07:49 --> URI Class Initialized
INFO - 2023-09-19 08:07:49 --> Router Class Initialized
INFO - 2023-09-19 08:07:49 --> Output Class Initialized
INFO - 2023-09-19 08:07:49 --> Security Class Initialized
DEBUG - 2023-09-19 08:07:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-19 08:07:49 --> Input Class Initialized
INFO - 2023-09-19 08:07:49 --> Language Class Initialized
INFO - 2023-09-19 08:07:49 --> Loader Class Initialized
INFO - 2023-09-19 08:07:49 --> Helper loaded: url_helper
INFO - 2023-09-19 08:07:49 --> Helper loaded: file_helper
INFO - 2023-09-19 08:07:49 --> Helper loaded: html_helper
INFO - 2023-09-19 08:07:49 --> Helper loaded: text_helper
INFO - 2023-09-19 08:07:49 --> Helper loaded: form_helper
INFO - 2023-09-19 08:07:49 --> Helper loaded: lang_helper
INFO - 2023-09-19 08:07:49 --> Helper loaded: security_helper
INFO - 2023-09-19 08:07:49 --> Helper loaded: cookie_helper
INFO - 2023-09-19 08:07:49 --> Database Driver Class Initialized
INFO - 2023-09-19 08:07:49 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-19 08:07:49 --> Parser Class Initialized
INFO - 2023-09-19 08:07:49 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-19 08:07:49 --> Pagination Class Initialized
INFO - 2023-09-19 08:07:49 --> Form Validation Class Initialized
INFO - 2023-09-19 08:07:49 --> Controller Class Initialized
INFO - 2023-09-19 08:07:49 --> Model Class Initialized
DEBUG - 2023-09-19 08:07:49 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-09-19 08:07:49 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-19 08:07:49 --> Model Class Initialized
DEBUG - 2023-09-19 08:07:49 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-19 08:07:49 --> Model Class Initialized
INFO - 2023-09-19 08:07:49 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/invoice/invoice.php
DEBUG - 2023-09-19 08:07:49 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-09-19 08:07:49 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-09-19 08:07:49 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-09-19 08:07:49 --> Model Class Initialized
INFO - 2023-09-19 08:07:49 --> Model Class Initialized
INFO - 2023-09-19 08:07:49 --> Model Class Initialized
INFO - 2023-09-19 08:07:49 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-09-19 08:07:49 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-09-19 08:07:49 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-09-19 08:07:49 --> Final output sent to browser
DEBUG - 2023-09-19 08:07:49 --> Total execution time: 0.0720
ERROR - 2023-09-19 08:07:50 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-19 08:07:50 --> Config Class Initialized
INFO - 2023-09-19 08:07:50 --> Hooks Class Initialized
DEBUG - 2023-09-19 08:07:50 --> UTF-8 Support Enabled
INFO - 2023-09-19 08:07:50 --> Utf8 Class Initialized
INFO - 2023-09-19 08:07:50 --> URI Class Initialized
INFO - 2023-09-19 08:07:50 --> Router Class Initialized
INFO - 2023-09-19 08:07:50 --> Output Class Initialized
INFO - 2023-09-19 08:07:50 --> Security Class Initialized
DEBUG - 2023-09-19 08:07:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-19 08:07:50 --> Input Class Initialized
INFO - 2023-09-19 08:07:50 --> Language Class Initialized
INFO - 2023-09-19 08:07:50 --> Loader Class Initialized
INFO - 2023-09-19 08:07:50 --> Helper loaded: url_helper
INFO - 2023-09-19 08:07:50 --> Helper loaded: file_helper
INFO - 2023-09-19 08:07:50 --> Helper loaded: html_helper
INFO - 2023-09-19 08:07:50 --> Helper loaded: text_helper
INFO - 2023-09-19 08:07:50 --> Helper loaded: form_helper
INFO - 2023-09-19 08:07:50 --> Helper loaded: lang_helper
INFO - 2023-09-19 08:07:50 --> Helper loaded: security_helper
INFO - 2023-09-19 08:07:50 --> Helper loaded: cookie_helper
INFO - 2023-09-19 08:07:50 --> Database Driver Class Initialized
INFO - 2023-09-19 08:07:50 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-19 08:07:50 --> Parser Class Initialized
INFO - 2023-09-19 08:07:50 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-19 08:07:50 --> Pagination Class Initialized
INFO - 2023-09-19 08:07:50 --> Form Validation Class Initialized
INFO - 2023-09-19 08:07:50 --> Controller Class Initialized
INFO - 2023-09-19 08:07:50 --> Model Class Initialized
DEBUG - 2023-09-19 08:07:50 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-09-19 08:07:50 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-19 08:07:50 --> Model Class Initialized
DEBUG - 2023-09-19 08:07:50 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-19 08:07:50 --> Model Class Initialized
INFO - 2023-09-19 08:07:50 --> Final output sent to browser
DEBUG - 2023-09-19 08:07:50 --> Total execution time: 0.0204
ERROR - 2023-09-19 08:08:02 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-19 08:08:02 --> Config Class Initialized
INFO - 2023-09-19 08:08:02 --> Hooks Class Initialized
DEBUG - 2023-09-19 08:08:02 --> UTF-8 Support Enabled
INFO - 2023-09-19 08:08:02 --> Utf8 Class Initialized
INFO - 2023-09-19 08:08:02 --> URI Class Initialized
INFO - 2023-09-19 08:08:02 --> Router Class Initialized
INFO - 2023-09-19 08:08:02 --> Output Class Initialized
INFO - 2023-09-19 08:08:02 --> Security Class Initialized
DEBUG - 2023-09-19 08:08:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-19 08:08:02 --> Input Class Initialized
INFO - 2023-09-19 08:08:02 --> Language Class Initialized
INFO - 2023-09-19 08:08:02 --> Loader Class Initialized
INFO - 2023-09-19 08:08:02 --> Helper loaded: url_helper
INFO - 2023-09-19 08:08:02 --> Helper loaded: file_helper
INFO - 2023-09-19 08:08:02 --> Helper loaded: html_helper
INFO - 2023-09-19 08:08:02 --> Helper loaded: text_helper
INFO - 2023-09-19 08:08:02 --> Helper loaded: form_helper
INFO - 2023-09-19 08:08:02 --> Helper loaded: lang_helper
INFO - 2023-09-19 08:08:02 --> Helper loaded: security_helper
INFO - 2023-09-19 08:08:02 --> Helper loaded: cookie_helper
INFO - 2023-09-19 08:08:02 --> Database Driver Class Initialized
INFO - 2023-09-19 08:08:02 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-19 08:08:02 --> Parser Class Initialized
INFO - 2023-09-19 08:08:02 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-19 08:08:02 --> Pagination Class Initialized
INFO - 2023-09-19 08:08:02 --> Form Validation Class Initialized
INFO - 2023-09-19 08:08:02 --> Controller Class Initialized
INFO - 2023-09-19 08:08:02 --> Model Class Initialized
INFO - 2023-09-19 08:08:02 --> Model Class Initialized
INFO - 2023-09-19 08:08:02 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/report/out_of_stock.php
DEBUG - 2023-09-19 08:08:02 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-09-19 08:08:02 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-09-19 08:08:02 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-09-19 08:08:02 --> Model Class Initialized
INFO - 2023-09-19 08:08:02 --> Model Class Initialized
INFO - 2023-09-19 08:08:02 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-09-19 08:08:02 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-09-19 08:08:02 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-09-19 08:08:02 --> Final output sent to browser
DEBUG - 2023-09-19 08:08:02 --> Total execution time: 0.0757
ERROR - 2023-09-19 08:08:02 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-19 08:08:02 --> Config Class Initialized
INFO - 2023-09-19 08:08:02 --> Hooks Class Initialized
DEBUG - 2023-09-19 08:08:02 --> UTF-8 Support Enabled
INFO - 2023-09-19 08:08:02 --> Utf8 Class Initialized
INFO - 2023-09-19 08:08:02 --> URI Class Initialized
INFO - 2023-09-19 08:08:02 --> Router Class Initialized
INFO - 2023-09-19 08:08:02 --> Output Class Initialized
INFO - 2023-09-19 08:08:02 --> Security Class Initialized
DEBUG - 2023-09-19 08:08:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-19 08:08:02 --> Input Class Initialized
INFO - 2023-09-19 08:08:02 --> Language Class Initialized
INFO - 2023-09-19 08:08:02 --> Loader Class Initialized
INFO - 2023-09-19 08:08:02 --> Helper loaded: url_helper
INFO - 2023-09-19 08:08:02 --> Helper loaded: file_helper
INFO - 2023-09-19 08:08:02 --> Helper loaded: html_helper
INFO - 2023-09-19 08:08:02 --> Helper loaded: text_helper
INFO - 2023-09-19 08:08:02 --> Helper loaded: form_helper
INFO - 2023-09-19 08:08:02 --> Helper loaded: lang_helper
INFO - 2023-09-19 08:08:02 --> Helper loaded: security_helper
INFO - 2023-09-19 08:08:02 --> Helper loaded: cookie_helper
INFO - 2023-09-19 08:08:02 --> Database Driver Class Initialized
INFO - 2023-09-19 08:08:02 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-19 08:08:02 --> Parser Class Initialized
INFO - 2023-09-19 08:08:02 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-19 08:08:02 --> Pagination Class Initialized
INFO - 2023-09-19 08:08:02 --> Form Validation Class Initialized
INFO - 2023-09-19 08:08:02 --> Controller Class Initialized
INFO - 2023-09-19 08:08:02 --> Model Class Initialized
INFO - 2023-09-19 08:08:02 --> Model Class Initialized
INFO - 2023-09-19 08:08:02 --> Final output sent to browser
DEBUG - 2023-09-19 08:08:02 --> Total execution time: 0.0526
ERROR - 2023-09-19 08:08:08 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-19 08:08:08 --> Config Class Initialized
INFO - 2023-09-19 08:08:08 --> Hooks Class Initialized
DEBUG - 2023-09-19 08:08:08 --> UTF-8 Support Enabled
INFO - 2023-09-19 08:08:08 --> Utf8 Class Initialized
INFO - 2023-09-19 08:08:08 --> URI Class Initialized
INFO - 2023-09-19 08:08:08 --> Router Class Initialized
INFO - 2023-09-19 08:08:08 --> Output Class Initialized
INFO - 2023-09-19 08:08:08 --> Security Class Initialized
DEBUG - 2023-09-19 08:08:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-19 08:08:08 --> Input Class Initialized
INFO - 2023-09-19 08:08:08 --> Language Class Initialized
INFO - 2023-09-19 08:08:08 --> Loader Class Initialized
INFO - 2023-09-19 08:08:08 --> Helper loaded: url_helper
INFO - 2023-09-19 08:08:08 --> Helper loaded: file_helper
INFO - 2023-09-19 08:08:08 --> Helper loaded: html_helper
INFO - 2023-09-19 08:08:08 --> Helper loaded: text_helper
INFO - 2023-09-19 08:08:08 --> Helper loaded: form_helper
INFO - 2023-09-19 08:08:08 --> Helper loaded: lang_helper
INFO - 2023-09-19 08:08:08 --> Helper loaded: security_helper
INFO - 2023-09-19 08:08:08 --> Helper loaded: cookie_helper
INFO - 2023-09-19 08:08:08 --> Database Driver Class Initialized
INFO - 2023-09-19 08:08:08 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-19 08:08:08 --> Parser Class Initialized
INFO - 2023-09-19 08:08:08 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-19 08:08:08 --> Pagination Class Initialized
INFO - 2023-09-19 08:08:08 --> Form Validation Class Initialized
INFO - 2023-09-19 08:08:08 --> Controller Class Initialized
INFO - 2023-09-19 08:08:08 --> Model Class Initialized
INFO - 2023-09-19 08:08:08 --> Model Class Initialized
INFO - 2023-09-19 08:08:08 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/report/out_of_date.php
DEBUG - 2023-09-19 08:08:08 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-09-19 08:08:08 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-09-19 08:08:08 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-09-19 08:08:08 --> Model Class Initialized
INFO - 2023-09-19 08:08:08 --> Model Class Initialized
INFO - 2023-09-19 08:08:08 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-09-19 08:08:08 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-09-19 08:08:08 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-09-19 08:08:08 --> Final output sent to browser
DEBUG - 2023-09-19 08:08:08 --> Total execution time: 0.0637
ERROR - 2023-09-19 08:08:09 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-19 08:08:09 --> Config Class Initialized
INFO - 2023-09-19 08:08:09 --> Hooks Class Initialized
DEBUG - 2023-09-19 08:08:09 --> UTF-8 Support Enabled
INFO - 2023-09-19 08:08:09 --> Utf8 Class Initialized
INFO - 2023-09-19 08:08:09 --> URI Class Initialized
INFO - 2023-09-19 08:08:09 --> Router Class Initialized
INFO - 2023-09-19 08:08:09 --> Output Class Initialized
INFO - 2023-09-19 08:08:09 --> Security Class Initialized
DEBUG - 2023-09-19 08:08:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-19 08:08:09 --> Input Class Initialized
INFO - 2023-09-19 08:08:09 --> Language Class Initialized
INFO - 2023-09-19 08:08:09 --> Loader Class Initialized
INFO - 2023-09-19 08:08:09 --> Helper loaded: url_helper
INFO - 2023-09-19 08:08:09 --> Helper loaded: file_helper
INFO - 2023-09-19 08:08:09 --> Helper loaded: html_helper
INFO - 2023-09-19 08:08:09 --> Helper loaded: text_helper
INFO - 2023-09-19 08:08:09 --> Helper loaded: form_helper
INFO - 2023-09-19 08:08:09 --> Helper loaded: lang_helper
INFO - 2023-09-19 08:08:09 --> Helper loaded: security_helper
INFO - 2023-09-19 08:08:09 --> Helper loaded: cookie_helper
INFO - 2023-09-19 08:08:09 --> Database Driver Class Initialized
INFO - 2023-09-19 08:08:09 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-19 08:08:09 --> Parser Class Initialized
INFO - 2023-09-19 08:08:09 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-19 08:08:09 --> Pagination Class Initialized
INFO - 2023-09-19 08:08:09 --> Form Validation Class Initialized
INFO - 2023-09-19 08:08:09 --> Controller Class Initialized
INFO - 2023-09-19 08:08:09 --> Model Class Initialized
INFO - 2023-09-19 08:08:09 --> Model Class Initialized
INFO - 2023-09-19 08:08:09 --> Final output sent to browser
DEBUG - 2023-09-19 08:08:09 --> Total execution time: 0.0264
ERROR - 2023-09-19 08:08:10 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-19 08:08:10 --> Config Class Initialized
INFO - 2023-09-19 08:08:10 --> Hooks Class Initialized
DEBUG - 2023-09-19 08:08:10 --> UTF-8 Support Enabled
INFO - 2023-09-19 08:08:10 --> Utf8 Class Initialized
INFO - 2023-09-19 08:08:10 --> URI Class Initialized
INFO - 2023-09-19 08:08:10 --> Router Class Initialized
INFO - 2023-09-19 08:08:10 --> Output Class Initialized
INFO - 2023-09-19 08:08:10 --> Security Class Initialized
DEBUG - 2023-09-19 08:08:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-19 08:08:10 --> Input Class Initialized
INFO - 2023-09-19 08:08:10 --> Language Class Initialized
INFO - 2023-09-19 08:08:10 --> Loader Class Initialized
INFO - 2023-09-19 08:08:10 --> Helper loaded: url_helper
INFO - 2023-09-19 08:08:10 --> Helper loaded: file_helper
INFO - 2023-09-19 08:08:10 --> Helper loaded: html_helper
INFO - 2023-09-19 08:08:10 --> Helper loaded: text_helper
INFO - 2023-09-19 08:08:10 --> Helper loaded: form_helper
INFO - 2023-09-19 08:08:10 --> Helper loaded: lang_helper
INFO - 2023-09-19 08:08:10 --> Helper loaded: security_helper
INFO - 2023-09-19 08:08:10 --> Helper loaded: cookie_helper
INFO - 2023-09-19 08:08:10 --> Database Driver Class Initialized
INFO - 2023-09-19 08:08:10 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-19 08:08:10 --> Parser Class Initialized
INFO - 2023-09-19 08:08:10 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-19 08:08:10 --> Pagination Class Initialized
INFO - 2023-09-19 08:08:10 --> Form Validation Class Initialized
INFO - 2023-09-19 08:08:10 --> Controller Class Initialized
INFO - 2023-09-19 08:08:10 --> Model Class Initialized
INFO - 2023-09-19 08:08:10 --> Model Class Initialized
INFO - 2023-09-19 08:08:10 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/report/out_of_date.php
DEBUG - 2023-09-19 08:08:10 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-09-19 08:08:10 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-09-19 08:08:10 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-09-19 08:08:10 --> Model Class Initialized
INFO - 2023-09-19 08:08:10 --> Model Class Initialized
INFO - 2023-09-19 08:08:10 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-09-19 08:08:10 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-09-19 08:08:10 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-09-19 08:08:10 --> Final output sent to browser
DEBUG - 2023-09-19 08:08:10 --> Total execution time: 0.0625
ERROR - 2023-09-19 08:08:11 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-19 08:08:11 --> Config Class Initialized
INFO - 2023-09-19 08:08:11 --> Hooks Class Initialized
DEBUG - 2023-09-19 08:08:11 --> UTF-8 Support Enabled
INFO - 2023-09-19 08:08:11 --> Utf8 Class Initialized
INFO - 2023-09-19 08:08:11 --> URI Class Initialized
INFO - 2023-09-19 08:08:11 --> Router Class Initialized
INFO - 2023-09-19 08:08:11 --> Output Class Initialized
INFO - 2023-09-19 08:08:11 --> Security Class Initialized
DEBUG - 2023-09-19 08:08:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-19 08:08:11 --> Input Class Initialized
INFO - 2023-09-19 08:08:11 --> Language Class Initialized
INFO - 2023-09-19 08:08:11 --> Loader Class Initialized
INFO - 2023-09-19 08:08:11 --> Helper loaded: url_helper
INFO - 2023-09-19 08:08:11 --> Helper loaded: file_helper
INFO - 2023-09-19 08:08:11 --> Helper loaded: html_helper
INFO - 2023-09-19 08:08:11 --> Helper loaded: text_helper
INFO - 2023-09-19 08:08:11 --> Helper loaded: form_helper
INFO - 2023-09-19 08:08:11 --> Helper loaded: lang_helper
INFO - 2023-09-19 08:08:11 --> Helper loaded: security_helper
INFO - 2023-09-19 08:08:11 --> Helper loaded: cookie_helper
INFO - 2023-09-19 08:08:11 --> Database Driver Class Initialized
INFO - 2023-09-19 08:08:11 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-19 08:08:11 --> Parser Class Initialized
INFO - 2023-09-19 08:08:11 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-19 08:08:11 --> Pagination Class Initialized
INFO - 2023-09-19 08:08:11 --> Form Validation Class Initialized
INFO - 2023-09-19 08:08:11 --> Controller Class Initialized
INFO - 2023-09-19 08:08:11 --> Model Class Initialized
INFO - 2023-09-19 08:08:11 --> Model Class Initialized
INFO - 2023-09-19 08:08:11 --> Final output sent to browser
DEBUG - 2023-09-19 08:08:11 --> Total execution time: 0.0256
ERROR - 2023-09-19 08:08:11 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-19 08:08:11 --> Config Class Initialized
INFO - 2023-09-19 08:08:11 --> Hooks Class Initialized
DEBUG - 2023-09-19 08:08:11 --> UTF-8 Support Enabled
INFO - 2023-09-19 08:08:11 --> Utf8 Class Initialized
INFO - 2023-09-19 08:08:11 --> URI Class Initialized
INFO - 2023-09-19 08:08:11 --> Router Class Initialized
INFO - 2023-09-19 08:08:11 --> Output Class Initialized
INFO - 2023-09-19 08:08:11 --> Security Class Initialized
DEBUG - 2023-09-19 08:08:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-19 08:08:11 --> Input Class Initialized
INFO - 2023-09-19 08:08:11 --> Language Class Initialized
INFO - 2023-09-19 08:08:11 --> Loader Class Initialized
INFO - 2023-09-19 08:08:11 --> Helper loaded: url_helper
INFO - 2023-09-19 08:08:11 --> Helper loaded: file_helper
INFO - 2023-09-19 08:08:11 --> Helper loaded: html_helper
INFO - 2023-09-19 08:08:11 --> Helper loaded: text_helper
INFO - 2023-09-19 08:08:11 --> Helper loaded: form_helper
INFO - 2023-09-19 08:08:11 --> Helper loaded: lang_helper
INFO - 2023-09-19 08:08:11 --> Helper loaded: security_helper
INFO - 2023-09-19 08:08:11 --> Helper loaded: cookie_helper
INFO - 2023-09-19 08:08:11 --> Database Driver Class Initialized
INFO - 2023-09-19 08:08:11 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-19 08:08:11 --> Parser Class Initialized
INFO - 2023-09-19 08:08:11 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-19 08:08:11 --> Pagination Class Initialized
INFO - 2023-09-19 08:08:11 --> Form Validation Class Initialized
INFO - 2023-09-19 08:08:11 --> Controller Class Initialized
INFO - 2023-09-19 08:08:11 --> Model Class Initialized
INFO - 2023-09-19 08:08:11 --> Model Class Initialized
INFO - 2023-09-19 08:08:11 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/report/out_of_date.php
DEBUG - 2023-09-19 08:08:11 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-09-19 08:08:11 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-09-19 08:08:11 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-09-19 08:08:11 --> Model Class Initialized
INFO - 2023-09-19 08:08:11 --> Model Class Initialized
INFO - 2023-09-19 08:08:11 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-09-19 08:08:11 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-09-19 08:08:11 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-09-19 08:08:11 --> Final output sent to browser
DEBUG - 2023-09-19 08:08:11 --> Total execution time: 0.0632
ERROR - 2023-09-19 08:08:12 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-19 08:08:12 --> Config Class Initialized
INFO - 2023-09-19 08:08:12 --> Hooks Class Initialized
DEBUG - 2023-09-19 08:08:12 --> UTF-8 Support Enabled
INFO - 2023-09-19 08:08:12 --> Utf8 Class Initialized
INFO - 2023-09-19 08:08:12 --> URI Class Initialized
INFO - 2023-09-19 08:08:12 --> Router Class Initialized
INFO - 2023-09-19 08:08:12 --> Output Class Initialized
INFO - 2023-09-19 08:08:12 --> Security Class Initialized
DEBUG - 2023-09-19 08:08:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-19 08:08:12 --> Input Class Initialized
INFO - 2023-09-19 08:08:12 --> Language Class Initialized
INFO - 2023-09-19 08:08:12 --> Loader Class Initialized
INFO - 2023-09-19 08:08:12 --> Helper loaded: url_helper
INFO - 2023-09-19 08:08:12 --> Helper loaded: file_helper
INFO - 2023-09-19 08:08:12 --> Helper loaded: html_helper
INFO - 2023-09-19 08:08:12 --> Helper loaded: text_helper
INFO - 2023-09-19 08:08:12 --> Helper loaded: form_helper
INFO - 2023-09-19 08:08:12 --> Helper loaded: lang_helper
INFO - 2023-09-19 08:08:12 --> Helper loaded: security_helper
INFO - 2023-09-19 08:08:12 --> Helper loaded: cookie_helper
INFO - 2023-09-19 08:08:12 --> Database Driver Class Initialized
INFO - 2023-09-19 08:08:12 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-19 08:08:12 --> Parser Class Initialized
INFO - 2023-09-19 08:08:12 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-19 08:08:12 --> Pagination Class Initialized
INFO - 2023-09-19 08:08:12 --> Form Validation Class Initialized
INFO - 2023-09-19 08:08:12 --> Controller Class Initialized
INFO - 2023-09-19 08:08:12 --> Model Class Initialized
INFO - 2023-09-19 08:08:12 --> Model Class Initialized
INFO - 2023-09-19 08:08:12 --> Final output sent to browser
DEBUG - 2023-09-19 08:08:12 --> Total execution time: 0.0269
ERROR - 2023-09-19 08:08:53 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-19 08:08:53 --> Config Class Initialized
INFO - 2023-09-19 08:08:53 --> Hooks Class Initialized
DEBUG - 2023-09-19 08:08:53 --> UTF-8 Support Enabled
INFO - 2023-09-19 08:08:53 --> Utf8 Class Initialized
INFO - 2023-09-19 08:08:53 --> URI Class Initialized
INFO - 2023-09-19 08:08:53 --> Router Class Initialized
INFO - 2023-09-19 08:08:53 --> Output Class Initialized
INFO - 2023-09-19 08:08:53 --> Security Class Initialized
DEBUG - 2023-09-19 08:08:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-19 08:08:53 --> Input Class Initialized
INFO - 2023-09-19 08:08:53 --> Language Class Initialized
INFO - 2023-09-19 08:08:53 --> Loader Class Initialized
INFO - 2023-09-19 08:08:53 --> Helper loaded: url_helper
INFO - 2023-09-19 08:08:53 --> Helper loaded: file_helper
INFO - 2023-09-19 08:08:53 --> Helper loaded: html_helper
INFO - 2023-09-19 08:08:53 --> Helper loaded: text_helper
INFO - 2023-09-19 08:08:53 --> Helper loaded: form_helper
INFO - 2023-09-19 08:08:53 --> Helper loaded: lang_helper
INFO - 2023-09-19 08:08:53 --> Helper loaded: security_helper
INFO - 2023-09-19 08:08:53 --> Helper loaded: cookie_helper
INFO - 2023-09-19 08:08:53 --> Database Driver Class Initialized
INFO - 2023-09-19 08:08:53 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-19 08:08:53 --> Parser Class Initialized
INFO - 2023-09-19 08:08:53 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-19 08:08:53 --> Pagination Class Initialized
INFO - 2023-09-19 08:08:53 --> Form Validation Class Initialized
INFO - 2023-09-19 08:08:53 --> Controller Class Initialized
INFO - 2023-09-19 08:08:53 --> Model Class Initialized
INFO - 2023-09-19 08:08:53 --> Model Class Initialized
INFO - 2023-09-19 08:08:53 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/report/out_of_stock.php
DEBUG - 2023-09-19 08:08:53 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-09-19 08:08:53 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-09-19 08:08:53 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-09-19 08:08:53 --> Model Class Initialized
INFO - 2023-09-19 08:08:53 --> Model Class Initialized
INFO - 2023-09-19 08:08:53 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-09-19 08:08:53 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-09-19 08:08:53 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-09-19 08:08:53 --> Final output sent to browser
DEBUG - 2023-09-19 08:08:53 --> Total execution time: 0.0843
ERROR - 2023-09-19 08:08:53 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-19 08:08:53 --> Config Class Initialized
INFO - 2023-09-19 08:08:53 --> Hooks Class Initialized
DEBUG - 2023-09-19 08:08:53 --> UTF-8 Support Enabled
INFO - 2023-09-19 08:08:53 --> Utf8 Class Initialized
INFO - 2023-09-19 08:08:53 --> URI Class Initialized
INFO - 2023-09-19 08:08:53 --> Router Class Initialized
INFO - 2023-09-19 08:08:53 --> Output Class Initialized
INFO - 2023-09-19 08:08:53 --> Security Class Initialized
DEBUG - 2023-09-19 08:08:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-19 08:08:53 --> Input Class Initialized
INFO - 2023-09-19 08:08:53 --> Language Class Initialized
INFO - 2023-09-19 08:08:53 --> Loader Class Initialized
INFO - 2023-09-19 08:08:53 --> Helper loaded: url_helper
INFO - 2023-09-19 08:08:53 --> Helper loaded: file_helper
INFO - 2023-09-19 08:08:53 --> Helper loaded: html_helper
INFO - 2023-09-19 08:08:53 --> Helper loaded: text_helper
INFO - 2023-09-19 08:08:53 --> Helper loaded: form_helper
INFO - 2023-09-19 08:08:53 --> Helper loaded: lang_helper
INFO - 2023-09-19 08:08:53 --> Helper loaded: security_helper
INFO - 2023-09-19 08:08:53 --> Helper loaded: cookie_helper
INFO - 2023-09-19 08:08:53 --> Database Driver Class Initialized
INFO - 2023-09-19 08:08:53 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-19 08:08:53 --> Parser Class Initialized
INFO - 2023-09-19 08:08:53 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-19 08:08:53 --> Pagination Class Initialized
INFO - 2023-09-19 08:08:53 --> Form Validation Class Initialized
INFO - 2023-09-19 08:08:53 --> Controller Class Initialized
INFO - 2023-09-19 08:08:53 --> Model Class Initialized
INFO - 2023-09-19 08:08:53 --> Model Class Initialized
INFO - 2023-09-19 08:08:53 --> Final output sent to browser
DEBUG - 2023-09-19 08:08:53 --> Total execution time: 0.0520
ERROR - 2023-09-19 08:09:44 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-19 08:09:44 --> Config Class Initialized
INFO - 2023-09-19 08:09:44 --> Hooks Class Initialized
DEBUG - 2023-09-19 08:09:44 --> UTF-8 Support Enabled
INFO - 2023-09-19 08:09:44 --> Utf8 Class Initialized
INFO - 2023-09-19 08:09:44 --> URI Class Initialized
DEBUG - 2023-09-19 08:09:44 --> No URI present. Default controller set.
INFO - 2023-09-19 08:09:44 --> Router Class Initialized
INFO - 2023-09-19 08:09:44 --> Output Class Initialized
INFO - 2023-09-19 08:09:44 --> Security Class Initialized
DEBUG - 2023-09-19 08:09:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-19 08:09:44 --> Input Class Initialized
INFO - 2023-09-19 08:09:44 --> Language Class Initialized
INFO - 2023-09-19 08:09:44 --> Loader Class Initialized
INFO - 2023-09-19 08:09:44 --> Helper loaded: url_helper
INFO - 2023-09-19 08:09:44 --> Helper loaded: file_helper
INFO - 2023-09-19 08:09:44 --> Helper loaded: html_helper
INFO - 2023-09-19 08:09:44 --> Helper loaded: text_helper
INFO - 2023-09-19 08:09:44 --> Helper loaded: form_helper
INFO - 2023-09-19 08:09:44 --> Helper loaded: lang_helper
INFO - 2023-09-19 08:09:44 --> Helper loaded: security_helper
INFO - 2023-09-19 08:09:44 --> Helper loaded: cookie_helper
INFO - 2023-09-19 08:09:44 --> Database Driver Class Initialized
INFO - 2023-09-19 08:09:44 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-19 08:09:44 --> Parser Class Initialized
INFO - 2023-09-19 08:09:44 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-19 08:09:44 --> Pagination Class Initialized
INFO - 2023-09-19 08:09:44 --> Form Validation Class Initialized
INFO - 2023-09-19 08:09:44 --> Controller Class Initialized
INFO - 2023-09-19 08:09:44 --> Model Class Initialized
DEBUG - 2023-09-19 08:09:44 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-19 08:09:44 --> Model Class Initialized
DEBUG - 2023-09-19 08:09:44 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-19 08:09:44 --> Model Class Initialized
INFO - 2023-09-19 08:09:44 --> Model Class Initialized
INFO - 2023-09-19 08:09:44 --> Model Class Initialized
INFO - 2023-09-19 08:09:44 --> Model Class Initialized
DEBUG - 2023-09-19 08:09:44 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-09-19 08:09:44 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-19 08:09:44 --> Model Class Initialized
INFO - 2023-09-19 08:09:44 --> Model Class Initialized
INFO - 2023-09-19 08:09:44 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-09-19 08:09:44 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-09-19 08:09:44 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-09-19 08:09:44 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-09-19 08:09:44 --> Model Class Initialized
INFO - 2023-09-19 08:09:44 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-09-19 08:09:44 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-09-19 08:09:44 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-09-19 08:09:44 --> Final output sent to browser
DEBUG - 2023-09-19 08:09:44 --> Total execution time: 0.0917
ERROR - 2023-09-19 08:09:55 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-19 08:09:55 --> Config Class Initialized
INFO - 2023-09-19 08:09:55 --> Hooks Class Initialized
DEBUG - 2023-09-19 08:09:55 --> UTF-8 Support Enabled
INFO - 2023-09-19 08:09:55 --> Utf8 Class Initialized
INFO - 2023-09-19 08:09:55 --> URI Class Initialized
INFO - 2023-09-19 08:09:55 --> Router Class Initialized
INFO - 2023-09-19 08:09:55 --> Output Class Initialized
INFO - 2023-09-19 08:09:55 --> Security Class Initialized
DEBUG - 2023-09-19 08:09:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-19 08:09:55 --> Input Class Initialized
INFO - 2023-09-19 08:09:55 --> Language Class Initialized
INFO - 2023-09-19 08:09:55 --> Loader Class Initialized
INFO - 2023-09-19 08:09:55 --> Helper loaded: url_helper
INFO - 2023-09-19 08:09:55 --> Helper loaded: file_helper
INFO - 2023-09-19 08:09:55 --> Helper loaded: html_helper
INFO - 2023-09-19 08:09:55 --> Helper loaded: text_helper
INFO - 2023-09-19 08:09:55 --> Helper loaded: form_helper
INFO - 2023-09-19 08:09:55 --> Helper loaded: lang_helper
INFO - 2023-09-19 08:09:55 --> Helper loaded: security_helper
INFO - 2023-09-19 08:09:55 --> Helper loaded: cookie_helper
INFO - 2023-09-19 08:09:55 --> Database Driver Class Initialized
INFO - 2023-09-19 08:09:55 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-19 08:09:55 --> Parser Class Initialized
INFO - 2023-09-19 08:09:55 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-19 08:09:55 --> Pagination Class Initialized
INFO - 2023-09-19 08:09:55 --> Form Validation Class Initialized
INFO - 2023-09-19 08:09:55 --> Controller Class Initialized
INFO - 2023-09-19 08:09:55 --> Model Class Initialized
DEBUG - 2023-09-19 08:09:55 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-09-19 08:09:55 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-19 08:09:55 --> Model Class Initialized
DEBUG - 2023-09-19 08:09:55 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-19 08:09:55 --> Model Class Initialized
INFO - 2023-09-19 08:09:55 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice.php
DEBUG - 2023-09-19 08:09:55 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-09-19 08:09:55 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-09-19 08:09:55 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-09-19 08:09:55 --> Model Class Initialized
INFO - 2023-09-19 08:09:55 --> Model Class Initialized
INFO - 2023-09-19 08:09:55 --> Model Class Initialized
INFO - 2023-09-19 08:09:55 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-09-19 08:09:55 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-09-19 08:09:55 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-09-19 08:09:55 --> Final output sent to browser
DEBUG - 2023-09-19 08:09:55 --> Total execution time: 0.0681
ERROR - 2023-09-19 08:09:56 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-19 08:09:56 --> Config Class Initialized
INFO - 2023-09-19 08:09:56 --> Hooks Class Initialized
DEBUG - 2023-09-19 08:09:56 --> UTF-8 Support Enabled
INFO - 2023-09-19 08:09:56 --> Utf8 Class Initialized
INFO - 2023-09-19 08:09:56 --> URI Class Initialized
INFO - 2023-09-19 08:09:56 --> Router Class Initialized
INFO - 2023-09-19 08:09:56 --> Output Class Initialized
INFO - 2023-09-19 08:09:56 --> Security Class Initialized
DEBUG - 2023-09-19 08:09:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-19 08:09:56 --> Input Class Initialized
INFO - 2023-09-19 08:09:56 --> Language Class Initialized
INFO - 2023-09-19 08:09:56 --> Loader Class Initialized
INFO - 2023-09-19 08:09:56 --> Helper loaded: url_helper
INFO - 2023-09-19 08:09:56 --> Helper loaded: file_helper
INFO - 2023-09-19 08:09:56 --> Helper loaded: html_helper
INFO - 2023-09-19 08:09:56 --> Helper loaded: text_helper
INFO - 2023-09-19 08:09:56 --> Helper loaded: form_helper
INFO - 2023-09-19 08:09:56 --> Helper loaded: lang_helper
INFO - 2023-09-19 08:09:56 --> Helper loaded: security_helper
INFO - 2023-09-19 08:09:56 --> Helper loaded: cookie_helper
INFO - 2023-09-19 08:09:56 --> Database Driver Class Initialized
INFO - 2023-09-19 08:09:56 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-19 08:09:56 --> Parser Class Initialized
INFO - 2023-09-19 08:09:56 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-19 08:09:56 --> Pagination Class Initialized
INFO - 2023-09-19 08:09:56 --> Form Validation Class Initialized
INFO - 2023-09-19 08:09:56 --> Controller Class Initialized
INFO - 2023-09-19 08:09:56 --> Model Class Initialized
DEBUG - 2023-09-19 08:09:56 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-09-19 08:09:56 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-19 08:09:56 --> Model Class Initialized
DEBUG - 2023-09-19 08:09:56 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-19 08:09:56 --> Model Class Initialized
INFO - 2023-09-19 08:09:56 --> Final output sent to browser
DEBUG - 2023-09-19 08:09:56 --> Total execution time: 0.0222
ERROR - 2023-09-19 08:10:06 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-19 08:10:06 --> Config Class Initialized
INFO - 2023-09-19 08:10:06 --> Hooks Class Initialized
DEBUG - 2023-09-19 08:10:06 --> UTF-8 Support Enabled
INFO - 2023-09-19 08:10:06 --> Utf8 Class Initialized
INFO - 2023-09-19 08:10:06 --> URI Class Initialized
DEBUG - 2023-09-19 08:10:06 --> No URI present. Default controller set.
INFO - 2023-09-19 08:10:06 --> Router Class Initialized
INFO - 2023-09-19 08:10:06 --> Output Class Initialized
INFO - 2023-09-19 08:10:06 --> Security Class Initialized
DEBUG - 2023-09-19 08:10:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-19 08:10:06 --> Input Class Initialized
INFO - 2023-09-19 08:10:06 --> Language Class Initialized
INFO - 2023-09-19 08:10:06 --> Loader Class Initialized
INFO - 2023-09-19 08:10:06 --> Helper loaded: url_helper
INFO - 2023-09-19 08:10:06 --> Helper loaded: file_helper
INFO - 2023-09-19 08:10:06 --> Helper loaded: html_helper
INFO - 2023-09-19 08:10:06 --> Helper loaded: text_helper
INFO - 2023-09-19 08:10:06 --> Helper loaded: form_helper
INFO - 2023-09-19 08:10:06 --> Helper loaded: lang_helper
INFO - 2023-09-19 08:10:06 --> Helper loaded: security_helper
INFO - 2023-09-19 08:10:06 --> Helper loaded: cookie_helper
INFO - 2023-09-19 08:10:06 --> Database Driver Class Initialized
INFO - 2023-09-19 08:10:06 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-19 08:10:06 --> Parser Class Initialized
INFO - 2023-09-19 08:10:06 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-19 08:10:06 --> Pagination Class Initialized
INFO - 2023-09-19 08:10:06 --> Form Validation Class Initialized
INFO - 2023-09-19 08:10:06 --> Controller Class Initialized
INFO - 2023-09-19 08:10:06 --> Model Class Initialized
DEBUG - 2023-09-19 08:10:06 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-19 08:10:06 --> Model Class Initialized
DEBUG - 2023-09-19 08:10:06 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-19 08:10:06 --> Model Class Initialized
INFO - 2023-09-19 08:10:06 --> Model Class Initialized
INFO - 2023-09-19 08:10:06 --> Model Class Initialized
INFO - 2023-09-19 08:10:06 --> Model Class Initialized
DEBUG - 2023-09-19 08:10:06 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-09-19 08:10:06 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-19 08:10:06 --> Model Class Initialized
INFO - 2023-09-19 08:10:06 --> Model Class Initialized
INFO - 2023-09-19 08:10:06 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-09-19 08:10:06 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-09-19 08:10:06 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-09-19 08:10:06 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-09-19 08:10:06 --> Model Class Initialized
INFO - 2023-09-19 08:10:06 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-09-19 08:10:06 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-09-19 08:10:06 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-09-19 08:10:06 --> Final output sent to browser
DEBUG - 2023-09-19 08:10:06 --> Total execution time: 0.0836
ERROR - 2023-09-19 08:10:13 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-19 08:10:13 --> Config Class Initialized
INFO - 2023-09-19 08:10:13 --> Hooks Class Initialized
DEBUG - 2023-09-19 08:10:13 --> UTF-8 Support Enabled
INFO - 2023-09-19 08:10:13 --> Utf8 Class Initialized
INFO - 2023-09-19 08:10:13 --> URI Class Initialized
INFO - 2023-09-19 08:10:13 --> Router Class Initialized
INFO - 2023-09-19 08:10:13 --> Output Class Initialized
INFO - 2023-09-19 08:10:13 --> Security Class Initialized
DEBUG - 2023-09-19 08:10:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-19 08:10:13 --> Input Class Initialized
INFO - 2023-09-19 08:10:13 --> Language Class Initialized
INFO - 2023-09-19 08:10:13 --> Loader Class Initialized
INFO - 2023-09-19 08:10:13 --> Helper loaded: url_helper
INFO - 2023-09-19 08:10:13 --> Helper loaded: file_helper
INFO - 2023-09-19 08:10:13 --> Helper loaded: html_helper
INFO - 2023-09-19 08:10:13 --> Helper loaded: text_helper
INFO - 2023-09-19 08:10:13 --> Helper loaded: form_helper
INFO - 2023-09-19 08:10:13 --> Helper loaded: lang_helper
INFO - 2023-09-19 08:10:13 --> Helper loaded: security_helper
INFO - 2023-09-19 08:10:13 --> Helper loaded: cookie_helper
INFO - 2023-09-19 08:10:13 --> Database Driver Class Initialized
INFO - 2023-09-19 08:10:13 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-19 08:10:13 --> Parser Class Initialized
INFO - 2023-09-19 08:10:13 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-19 08:10:13 --> Pagination Class Initialized
INFO - 2023-09-19 08:10:13 --> Form Validation Class Initialized
INFO - 2023-09-19 08:10:13 --> Controller Class Initialized
INFO - 2023-09-19 08:10:13 --> Model Class Initialized
DEBUG - 2023-09-19 08:10:13 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-09-19 08:10:13 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-19 08:10:13 --> Model Class Initialized
DEBUG - 2023-09-19 08:10:13 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-19 08:10:13 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/demandrequest/add_demandrequest_form.php
DEBUG - 2023-09-19 08:10:13 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-09-19 08:10:13 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-09-19 08:10:13 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-09-19 08:10:13 --> Model Class Initialized
INFO - 2023-09-19 08:10:13 --> Model Class Initialized
INFO - 2023-09-19 08:10:13 --> Model Class Initialized
INFO - 2023-09-19 08:10:13 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-09-19 08:10:13 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-09-19 08:10:13 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-09-19 08:10:13 --> Final output sent to browser
DEBUG - 2023-09-19 08:10:13 --> Total execution time: 0.0665
ERROR - 2023-09-19 08:10:24 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-19 08:10:24 --> Config Class Initialized
INFO - 2023-09-19 08:10:24 --> Hooks Class Initialized
DEBUG - 2023-09-19 08:10:24 --> UTF-8 Support Enabled
INFO - 2023-09-19 08:10:24 --> Utf8 Class Initialized
INFO - 2023-09-19 08:10:24 --> URI Class Initialized
DEBUG - 2023-09-19 08:10:24 --> No URI present. Default controller set.
INFO - 2023-09-19 08:10:24 --> Router Class Initialized
INFO - 2023-09-19 08:10:24 --> Output Class Initialized
INFO - 2023-09-19 08:10:24 --> Security Class Initialized
DEBUG - 2023-09-19 08:10:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-19 08:10:24 --> Input Class Initialized
INFO - 2023-09-19 08:10:24 --> Language Class Initialized
INFO - 2023-09-19 08:10:24 --> Loader Class Initialized
INFO - 2023-09-19 08:10:24 --> Helper loaded: url_helper
INFO - 2023-09-19 08:10:24 --> Helper loaded: file_helper
INFO - 2023-09-19 08:10:24 --> Helper loaded: html_helper
INFO - 2023-09-19 08:10:24 --> Helper loaded: text_helper
INFO - 2023-09-19 08:10:24 --> Helper loaded: form_helper
INFO - 2023-09-19 08:10:24 --> Helper loaded: lang_helper
INFO - 2023-09-19 08:10:24 --> Helper loaded: security_helper
INFO - 2023-09-19 08:10:24 --> Helper loaded: cookie_helper
INFO - 2023-09-19 08:10:24 --> Database Driver Class Initialized
INFO - 2023-09-19 08:10:24 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-19 08:10:24 --> Parser Class Initialized
INFO - 2023-09-19 08:10:24 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-19 08:10:24 --> Pagination Class Initialized
INFO - 2023-09-19 08:10:24 --> Form Validation Class Initialized
INFO - 2023-09-19 08:10:24 --> Controller Class Initialized
INFO - 2023-09-19 08:10:24 --> Model Class Initialized
DEBUG - 2023-09-19 08:10:24 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-19 08:10:24 --> Model Class Initialized
DEBUG - 2023-09-19 08:10:24 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-19 08:10:24 --> Model Class Initialized
INFO - 2023-09-19 08:10:24 --> Model Class Initialized
INFO - 2023-09-19 08:10:24 --> Model Class Initialized
INFO - 2023-09-19 08:10:24 --> Model Class Initialized
DEBUG - 2023-09-19 08:10:24 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-09-19 08:10:24 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-19 08:10:24 --> Model Class Initialized
INFO - 2023-09-19 08:10:24 --> Model Class Initialized
INFO - 2023-09-19 08:10:24 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-09-19 08:10:24 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-09-19 08:10:24 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-09-19 08:10:24 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-09-19 08:10:24 --> Model Class Initialized
INFO - 2023-09-19 08:10:24 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-09-19 08:10:24 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-09-19 08:10:24 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-09-19 08:10:24 --> Final output sent to browser
DEBUG - 2023-09-19 08:10:24 --> Total execution time: 0.0945
ERROR - 2023-09-19 08:10:27 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-19 08:10:27 --> Config Class Initialized
INFO - 2023-09-19 08:10:27 --> Hooks Class Initialized
DEBUG - 2023-09-19 08:10:27 --> UTF-8 Support Enabled
INFO - 2023-09-19 08:10:27 --> Utf8 Class Initialized
INFO - 2023-09-19 08:10:27 --> URI Class Initialized
INFO - 2023-09-19 08:10:27 --> Router Class Initialized
INFO - 2023-09-19 08:10:27 --> Output Class Initialized
INFO - 2023-09-19 08:10:27 --> Security Class Initialized
DEBUG - 2023-09-19 08:10:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-19 08:10:27 --> Input Class Initialized
INFO - 2023-09-19 08:10:27 --> Language Class Initialized
INFO - 2023-09-19 08:10:27 --> Loader Class Initialized
INFO - 2023-09-19 08:10:27 --> Helper loaded: url_helper
INFO - 2023-09-19 08:10:27 --> Helper loaded: file_helper
INFO - 2023-09-19 08:10:27 --> Helper loaded: html_helper
INFO - 2023-09-19 08:10:27 --> Helper loaded: text_helper
INFO - 2023-09-19 08:10:27 --> Helper loaded: form_helper
INFO - 2023-09-19 08:10:27 --> Helper loaded: lang_helper
INFO - 2023-09-19 08:10:27 --> Helper loaded: security_helper
INFO - 2023-09-19 08:10:27 --> Helper loaded: cookie_helper
INFO - 2023-09-19 08:10:27 --> Database Driver Class Initialized
INFO - 2023-09-19 08:10:27 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-19 08:10:27 --> Parser Class Initialized
INFO - 2023-09-19 08:10:27 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-19 08:10:27 --> Pagination Class Initialized
INFO - 2023-09-19 08:10:27 --> Form Validation Class Initialized
INFO - 2023-09-19 08:10:27 --> Controller Class Initialized
INFO - 2023-09-19 08:10:27 --> Model Class Initialized
DEBUG - 2023-09-19 08:10:27 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-09-19 08:10:27 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-19 08:10:27 --> Model Class Initialized
DEBUG - 2023-09-19 08:10:27 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-19 08:10:27 --> Model Class Initialized
INFO - 2023-09-19 08:10:27 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/invoice/invoice.php
DEBUG - 2023-09-19 08:10:27 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-09-19 08:10:27 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-09-19 08:10:27 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-09-19 08:10:27 --> Model Class Initialized
INFO - 2023-09-19 08:10:27 --> Model Class Initialized
INFO - 2023-09-19 08:10:27 --> Model Class Initialized
INFO - 2023-09-19 08:10:27 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-09-19 08:10:27 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-09-19 08:10:27 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-09-19 08:10:27 --> Final output sent to browser
DEBUG - 2023-09-19 08:10:27 --> Total execution time: 0.0722
ERROR - 2023-09-19 08:10:27 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-19 08:10:27 --> Config Class Initialized
INFO - 2023-09-19 08:10:27 --> Hooks Class Initialized
DEBUG - 2023-09-19 08:10:27 --> UTF-8 Support Enabled
INFO - 2023-09-19 08:10:27 --> Utf8 Class Initialized
INFO - 2023-09-19 08:10:27 --> URI Class Initialized
INFO - 2023-09-19 08:10:27 --> Router Class Initialized
INFO - 2023-09-19 08:10:27 --> Output Class Initialized
INFO - 2023-09-19 08:10:27 --> Security Class Initialized
DEBUG - 2023-09-19 08:10:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-19 08:10:27 --> Input Class Initialized
INFO - 2023-09-19 08:10:27 --> Language Class Initialized
INFO - 2023-09-19 08:10:27 --> Loader Class Initialized
INFO - 2023-09-19 08:10:27 --> Helper loaded: url_helper
INFO - 2023-09-19 08:10:27 --> Helper loaded: file_helper
INFO - 2023-09-19 08:10:27 --> Helper loaded: html_helper
INFO - 2023-09-19 08:10:27 --> Helper loaded: text_helper
INFO - 2023-09-19 08:10:27 --> Helper loaded: form_helper
INFO - 2023-09-19 08:10:27 --> Helper loaded: lang_helper
INFO - 2023-09-19 08:10:27 --> Helper loaded: security_helper
INFO - 2023-09-19 08:10:27 --> Helper loaded: cookie_helper
INFO - 2023-09-19 08:10:27 --> Database Driver Class Initialized
INFO - 2023-09-19 08:10:27 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-19 08:10:27 --> Parser Class Initialized
INFO - 2023-09-19 08:10:27 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-19 08:10:27 --> Pagination Class Initialized
INFO - 2023-09-19 08:10:27 --> Form Validation Class Initialized
INFO - 2023-09-19 08:10:27 --> Controller Class Initialized
INFO - 2023-09-19 08:10:27 --> Model Class Initialized
DEBUG - 2023-09-19 08:10:27 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-09-19 08:10:27 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-19 08:10:27 --> Model Class Initialized
DEBUG - 2023-09-19 08:10:27 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-19 08:10:27 --> Model Class Initialized
INFO - 2023-09-19 08:10:27 --> Final output sent to browser
DEBUG - 2023-09-19 08:10:27 --> Total execution time: 0.0193
ERROR - 2023-09-19 08:10:41 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-19 08:10:41 --> Config Class Initialized
INFO - 2023-09-19 08:10:41 --> Hooks Class Initialized
DEBUG - 2023-09-19 08:10:41 --> UTF-8 Support Enabled
INFO - 2023-09-19 08:10:41 --> Utf8 Class Initialized
INFO - 2023-09-19 08:10:41 --> URI Class Initialized
DEBUG - 2023-09-19 08:10:41 --> No URI present. Default controller set.
INFO - 2023-09-19 08:10:41 --> Router Class Initialized
INFO - 2023-09-19 08:10:41 --> Output Class Initialized
INFO - 2023-09-19 08:10:41 --> Security Class Initialized
DEBUG - 2023-09-19 08:10:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-19 08:10:41 --> Input Class Initialized
INFO - 2023-09-19 08:10:41 --> Language Class Initialized
INFO - 2023-09-19 08:10:41 --> Loader Class Initialized
INFO - 2023-09-19 08:10:41 --> Helper loaded: url_helper
INFO - 2023-09-19 08:10:41 --> Helper loaded: file_helper
INFO - 2023-09-19 08:10:41 --> Helper loaded: html_helper
INFO - 2023-09-19 08:10:41 --> Helper loaded: text_helper
INFO - 2023-09-19 08:10:41 --> Helper loaded: form_helper
INFO - 2023-09-19 08:10:41 --> Helper loaded: lang_helper
INFO - 2023-09-19 08:10:41 --> Helper loaded: security_helper
INFO - 2023-09-19 08:10:41 --> Helper loaded: cookie_helper
INFO - 2023-09-19 08:10:41 --> Database Driver Class Initialized
INFO - 2023-09-19 08:10:41 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-19 08:10:41 --> Parser Class Initialized
INFO - 2023-09-19 08:10:41 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-19 08:10:41 --> Pagination Class Initialized
INFO - 2023-09-19 08:10:41 --> Form Validation Class Initialized
INFO - 2023-09-19 08:10:41 --> Controller Class Initialized
INFO - 2023-09-19 08:10:41 --> Model Class Initialized
DEBUG - 2023-09-19 08:10:41 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-19 08:10:41 --> Model Class Initialized
DEBUG - 2023-09-19 08:10:41 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-19 08:10:41 --> Model Class Initialized
INFO - 2023-09-19 08:10:41 --> Model Class Initialized
INFO - 2023-09-19 08:10:41 --> Model Class Initialized
INFO - 2023-09-19 08:10:41 --> Model Class Initialized
DEBUG - 2023-09-19 08:10:41 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-09-19 08:10:41 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-19 08:10:41 --> Model Class Initialized
INFO - 2023-09-19 08:10:41 --> Model Class Initialized
INFO - 2023-09-19 08:10:41 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-09-19 08:10:41 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-09-19 08:10:41 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-09-19 08:10:41 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-09-19 08:10:41 --> Model Class Initialized
INFO - 2023-09-19 08:10:41 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-09-19 08:10:41 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-09-19 08:10:41 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-09-19 08:10:41 --> Final output sent to browser
DEBUG - 2023-09-19 08:10:41 --> Total execution time: 0.0882
ERROR - 2023-09-19 08:10:41 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-19 08:10:41 --> Config Class Initialized
INFO - 2023-09-19 08:10:41 --> Hooks Class Initialized
DEBUG - 2023-09-19 08:10:41 --> UTF-8 Support Enabled
INFO - 2023-09-19 08:10:41 --> Utf8 Class Initialized
INFO - 2023-09-19 08:10:41 --> URI Class Initialized
INFO - 2023-09-19 08:10:41 --> Router Class Initialized
INFO - 2023-09-19 08:10:41 --> Output Class Initialized
INFO - 2023-09-19 08:10:41 --> Security Class Initialized
DEBUG - 2023-09-19 08:10:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-19 08:10:41 --> Input Class Initialized
INFO - 2023-09-19 08:10:41 --> Language Class Initialized
INFO - 2023-09-19 08:10:41 --> Loader Class Initialized
INFO - 2023-09-19 08:10:41 --> Helper loaded: url_helper
INFO - 2023-09-19 08:10:41 --> Helper loaded: file_helper
INFO - 2023-09-19 08:10:41 --> Helper loaded: html_helper
INFO - 2023-09-19 08:10:41 --> Helper loaded: text_helper
INFO - 2023-09-19 08:10:41 --> Helper loaded: form_helper
INFO - 2023-09-19 08:10:41 --> Helper loaded: lang_helper
INFO - 2023-09-19 08:10:41 --> Helper loaded: security_helper
INFO - 2023-09-19 08:10:41 --> Helper loaded: cookie_helper
INFO - 2023-09-19 08:10:41 --> Database Driver Class Initialized
INFO - 2023-09-19 08:10:41 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-19 08:10:41 --> Parser Class Initialized
INFO - 2023-09-19 08:10:41 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-19 08:10:41 --> Pagination Class Initialized
INFO - 2023-09-19 08:10:41 --> Form Validation Class Initialized
INFO - 2023-09-19 08:10:41 --> Controller Class Initialized
INFO - 2023-09-19 08:10:41 --> Model Class Initialized
INFO - 2023-09-19 08:10:41 --> Model Class Initialized
INFO - 2023-09-19 08:10:41 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/report/out_of_stock.php
DEBUG - 2023-09-19 08:10:41 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-09-19 08:10:41 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-09-19 08:10:41 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-09-19 08:10:41 --> Model Class Initialized
INFO - 2023-09-19 08:10:41 --> Model Class Initialized
INFO - 2023-09-19 08:10:41 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-09-19 08:10:41 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-09-19 08:10:41 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-09-19 08:10:41 --> Final output sent to browser
DEBUG - 2023-09-19 08:10:41 --> Total execution time: 0.0806
ERROR - 2023-09-19 08:10:41 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-19 08:10:41 --> Config Class Initialized
INFO - 2023-09-19 08:10:41 --> Hooks Class Initialized
DEBUG - 2023-09-19 08:10:41 --> UTF-8 Support Enabled
INFO - 2023-09-19 08:10:41 --> Utf8 Class Initialized
INFO - 2023-09-19 08:10:41 --> URI Class Initialized
INFO - 2023-09-19 08:10:41 --> Router Class Initialized
INFO - 2023-09-19 08:10:41 --> Output Class Initialized
INFO - 2023-09-19 08:10:41 --> Security Class Initialized
DEBUG - 2023-09-19 08:10:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-19 08:10:41 --> Input Class Initialized
INFO - 2023-09-19 08:10:41 --> Language Class Initialized
INFO - 2023-09-19 08:10:41 --> Loader Class Initialized
INFO - 2023-09-19 08:10:41 --> Helper loaded: url_helper
INFO - 2023-09-19 08:10:41 --> Helper loaded: file_helper
INFO - 2023-09-19 08:10:41 --> Helper loaded: html_helper
INFO - 2023-09-19 08:10:41 --> Helper loaded: text_helper
INFO - 2023-09-19 08:10:41 --> Helper loaded: form_helper
INFO - 2023-09-19 08:10:41 --> Helper loaded: lang_helper
INFO - 2023-09-19 08:10:41 --> Helper loaded: security_helper
INFO - 2023-09-19 08:10:41 --> Helper loaded: cookie_helper
INFO - 2023-09-19 08:10:41 --> Database Driver Class Initialized
INFO - 2023-09-19 08:10:41 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-19 08:10:41 --> Parser Class Initialized
INFO - 2023-09-19 08:10:41 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-19 08:10:41 --> Pagination Class Initialized
INFO - 2023-09-19 08:10:41 --> Form Validation Class Initialized
INFO - 2023-09-19 08:10:41 --> Controller Class Initialized
INFO - 2023-09-19 08:10:41 --> Model Class Initialized
INFO - 2023-09-19 08:10:41 --> Model Class Initialized
INFO - 2023-09-19 08:10:42 --> Final output sent to browser
DEBUG - 2023-09-19 08:10:42 --> Total execution time: 0.0556
ERROR - 2023-09-19 08:10:48 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-19 08:10:48 --> Config Class Initialized
INFO - 2023-09-19 08:10:48 --> Hooks Class Initialized
DEBUG - 2023-09-19 08:10:48 --> UTF-8 Support Enabled
INFO - 2023-09-19 08:10:48 --> Utf8 Class Initialized
INFO - 2023-09-19 08:10:48 --> URI Class Initialized
INFO - 2023-09-19 08:10:48 --> Router Class Initialized
INFO - 2023-09-19 08:10:48 --> Output Class Initialized
INFO - 2023-09-19 08:10:48 --> Security Class Initialized
DEBUG - 2023-09-19 08:10:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-19 08:10:48 --> Input Class Initialized
INFO - 2023-09-19 08:10:48 --> Language Class Initialized
INFO - 2023-09-19 08:10:48 --> Loader Class Initialized
INFO - 2023-09-19 08:10:48 --> Helper loaded: url_helper
INFO - 2023-09-19 08:10:48 --> Helper loaded: file_helper
INFO - 2023-09-19 08:10:48 --> Helper loaded: html_helper
INFO - 2023-09-19 08:10:48 --> Helper loaded: text_helper
INFO - 2023-09-19 08:10:48 --> Helper loaded: form_helper
INFO - 2023-09-19 08:10:48 --> Helper loaded: lang_helper
INFO - 2023-09-19 08:10:48 --> Helper loaded: security_helper
INFO - 2023-09-19 08:10:48 --> Helper loaded: cookie_helper
INFO - 2023-09-19 08:10:48 --> Database Driver Class Initialized
INFO - 2023-09-19 08:10:48 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-19 08:10:48 --> Parser Class Initialized
INFO - 2023-09-19 08:10:48 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-19 08:10:48 --> Pagination Class Initialized
INFO - 2023-09-19 08:10:48 --> Form Validation Class Initialized
INFO - 2023-09-19 08:10:48 --> Controller Class Initialized
INFO - 2023-09-19 08:10:48 --> Model Class Initialized
DEBUG - 2023-09-19 08:10:48 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-09-19 08:10:48 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-19 08:10:48 --> Model Class Initialized
DEBUG - 2023-09-19 08:10:48 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-19 08:10:48 --> Model Class Initialized
INFO - 2023-09-19 08:10:48 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/invoice/invoice.php
DEBUG - 2023-09-19 08:10:48 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-09-19 08:10:48 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-09-19 08:10:48 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-09-19 08:10:48 --> Model Class Initialized
INFO - 2023-09-19 08:10:48 --> Model Class Initialized
INFO - 2023-09-19 08:10:48 --> Model Class Initialized
INFO - 2023-09-19 08:10:48 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-09-19 08:10:48 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-09-19 08:10:48 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-09-19 08:10:48 --> Final output sent to browser
DEBUG - 2023-09-19 08:10:48 --> Total execution time: 0.0707
ERROR - 2023-09-19 08:10:48 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-19 08:10:48 --> Config Class Initialized
INFO - 2023-09-19 08:10:48 --> Hooks Class Initialized
DEBUG - 2023-09-19 08:10:48 --> UTF-8 Support Enabled
INFO - 2023-09-19 08:10:48 --> Utf8 Class Initialized
INFO - 2023-09-19 08:10:48 --> URI Class Initialized
INFO - 2023-09-19 08:10:48 --> Router Class Initialized
INFO - 2023-09-19 08:10:48 --> Output Class Initialized
INFO - 2023-09-19 08:10:48 --> Security Class Initialized
DEBUG - 2023-09-19 08:10:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-19 08:10:48 --> Input Class Initialized
INFO - 2023-09-19 08:10:48 --> Language Class Initialized
INFO - 2023-09-19 08:10:48 --> Loader Class Initialized
INFO - 2023-09-19 08:10:48 --> Helper loaded: url_helper
INFO - 2023-09-19 08:10:48 --> Helper loaded: file_helper
INFO - 2023-09-19 08:10:48 --> Helper loaded: html_helper
INFO - 2023-09-19 08:10:48 --> Helper loaded: text_helper
INFO - 2023-09-19 08:10:48 --> Helper loaded: form_helper
INFO - 2023-09-19 08:10:48 --> Helper loaded: lang_helper
INFO - 2023-09-19 08:10:48 --> Helper loaded: security_helper
INFO - 2023-09-19 08:10:48 --> Helper loaded: cookie_helper
INFO - 2023-09-19 08:10:48 --> Database Driver Class Initialized
INFO - 2023-09-19 08:10:48 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-19 08:10:48 --> Parser Class Initialized
INFO - 2023-09-19 08:10:48 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-19 08:10:48 --> Pagination Class Initialized
INFO - 2023-09-19 08:10:48 --> Form Validation Class Initialized
INFO - 2023-09-19 08:10:48 --> Controller Class Initialized
INFO - 2023-09-19 08:10:48 --> Model Class Initialized
DEBUG - 2023-09-19 08:10:48 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-09-19 08:10:48 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-19 08:10:48 --> Model Class Initialized
DEBUG - 2023-09-19 08:10:48 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-19 08:10:48 --> Model Class Initialized
INFO - 2023-09-19 08:10:48 --> Final output sent to browser
DEBUG - 2023-09-19 08:10:48 --> Total execution time: 0.0187
ERROR - 2023-09-19 08:10:52 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-19 08:10:52 --> Config Class Initialized
INFO - 2023-09-19 08:10:52 --> Hooks Class Initialized
DEBUG - 2023-09-19 08:10:52 --> UTF-8 Support Enabled
INFO - 2023-09-19 08:10:52 --> Utf8 Class Initialized
INFO - 2023-09-19 08:10:52 --> URI Class Initialized
DEBUG - 2023-09-19 08:10:52 --> No URI present. Default controller set.
INFO - 2023-09-19 08:10:52 --> Router Class Initialized
INFO - 2023-09-19 08:10:52 --> Output Class Initialized
INFO - 2023-09-19 08:10:52 --> Security Class Initialized
DEBUG - 2023-09-19 08:10:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-19 08:10:52 --> Input Class Initialized
INFO - 2023-09-19 08:10:52 --> Language Class Initialized
INFO - 2023-09-19 08:10:52 --> Loader Class Initialized
INFO - 2023-09-19 08:10:52 --> Helper loaded: url_helper
INFO - 2023-09-19 08:10:52 --> Helper loaded: file_helper
INFO - 2023-09-19 08:10:52 --> Helper loaded: html_helper
INFO - 2023-09-19 08:10:52 --> Helper loaded: text_helper
INFO - 2023-09-19 08:10:52 --> Helper loaded: form_helper
INFO - 2023-09-19 08:10:52 --> Helper loaded: lang_helper
INFO - 2023-09-19 08:10:52 --> Helper loaded: security_helper
INFO - 2023-09-19 08:10:52 --> Helper loaded: cookie_helper
INFO - 2023-09-19 08:10:52 --> Database Driver Class Initialized
INFO - 2023-09-19 08:10:52 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-19 08:10:52 --> Parser Class Initialized
INFO - 2023-09-19 08:10:52 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-19 08:10:52 --> Pagination Class Initialized
INFO - 2023-09-19 08:10:52 --> Form Validation Class Initialized
INFO - 2023-09-19 08:10:52 --> Controller Class Initialized
INFO - 2023-09-19 08:10:52 --> Model Class Initialized
DEBUG - 2023-09-19 08:10:52 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-19 08:10:52 --> Model Class Initialized
DEBUG - 2023-09-19 08:10:52 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-19 08:10:52 --> Model Class Initialized
INFO - 2023-09-19 08:10:52 --> Model Class Initialized
INFO - 2023-09-19 08:10:52 --> Model Class Initialized
INFO - 2023-09-19 08:10:52 --> Model Class Initialized
DEBUG - 2023-09-19 08:10:52 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-09-19 08:10:52 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-19 08:10:52 --> Model Class Initialized
INFO - 2023-09-19 08:10:52 --> Model Class Initialized
INFO - 2023-09-19 08:10:52 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-09-19 08:10:52 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-09-19 08:10:52 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-09-19 08:10:52 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-09-19 08:10:52 --> Model Class Initialized
INFO - 2023-09-19 08:10:52 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-09-19 08:10:52 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-09-19 08:10:52 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-09-19 08:10:52 --> Final output sent to browser
DEBUG - 2023-09-19 08:10:52 --> Total execution time: 0.0841
ERROR - 2023-09-19 08:11:32 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-19 08:11:32 --> Config Class Initialized
INFO - 2023-09-19 08:11:32 --> Hooks Class Initialized
DEBUG - 2023-09-19 08:11:32 --> UTF-8 Support Enabled
INFO - 2023-09-19 08:11:32 --> Utf8 Class Initialized
INFO - 2023-09-19 08:11:32 --> URI Class Initialized
DEBUG - 2023-09-19 08:11:32 --> No URI present. Default controller set.
INFO - 2023-09-19 08:11:32 --> Router Class Initialized
INFO - 2023-09-19 08:11:32 --> Output Class Initialized
INFO - 2023-09-19 08:11:32 --> Security Class Initialized
DEBUG - 2023-09-19 08:11:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-19 08:11:32 --> Input Class Initialized
INFO - 2023-09-19 08:11:32 --> Language Class Initialized
INFO - 2023-09-19 08:11:32 --> Loader Class Initialized
INFO - 2023-09-19 08:11:32 --> Helper loaded: url_helper
INFO - 2023-09-19 08:11:32 --> Helper loaded: file_helper
INFO - 2023-09-19 08:11:32 --> Helper loaded: html_helper
INFO - 2023-09-19 08:11:32 --> Helper loaded: text_helper
INFO - 2023-09-19 08:11:32 --> Helper loaded: form_helper
INFO - 2023-09-19 08:11:32 --> Helper loaded: lang_helper
INFO - 2023-09-19 08:11:32 --> Helper loaded: security_helper
INFO - 2023-09-19 08:11:32 --> Helper loaded: cookie_helper
INFO - 2023-09-19 08:11:32 --> Database Driver Class Initialized
INFO - 2023-09-19 08:11:32 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-19 08:11:32 --> Parser Class Initialized
INFO - 2023-09-19 08:11:32 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-19 08:11:32 --> Pagination Class Initialized
INFO - 2023-09-19 08:11:32 --> Form Validation Class Initialized
INFO - 2023-09-19 08:11:32 --> Controller Class Initialized
INFO - 2023-09-19 08:11:32 --> Model Class Initialized
DEBUG - 2023-09-19 08:11:32 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-19 08:11:32 --> Model Class Initialized
DEBUG - 2023-09-19 08:11:32 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-19 08:11:32 --> Model Class Initialized
INFO - 2023-09-19 08:11:32 --> Model Class Initialized
INFO - 2023-09-19 08:11:32 --> Model Class Initialized
INFO - 2023-09-19 08:11:32 --> Model Class Initialized
DEBUG - 2023-09-19 08:11:32 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-09-19 08:11:32 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-19 08:11:32 --> Model Class Initialized
INFO - 2023-09-19 08:11:32 --> Model Class Initialized
INFO - 2023-09-19 08:11:32 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-09-19 08:11:32 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-09-19 08:11:32 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-09-19 08:11:32 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-09-19 08:11:32 --> Model Class Initialized
INFO - 2023-09-19 08:11:32 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-09-19 08:11:32 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-09-19 08:11:32 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-09-19 08:11:32 --> Final output sent to browser
DEBUG - 2023-09-19 08:11:32 --> Total execution time: 0.0890
ERROR - 2023-09-19 08:11:38 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-19 08:11:38 --> Config Class Initialized
INFO - 2023-09-19 08:11:38 --> Hooks Class Initialized
DEBUG - 2023-09-19 08:11:38 --> UTF-8 Support Enabled
INFO - 2023-09-19 08:11:38 --> Utf8 Class Initialized
INFO - 2023-09-19 08:11:38 --> URI Class Initialized
INFO - 2023-09-19 08:11:38 --> Router Class Initialized
INFO - 2023-09-19 08:11:38 --> Output Class Initialized
INFO - 2023-09-19 08:11:38 --> Security Class Initialized
DEBUG - 2023-09-19 08:11:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-19 08:11:38 --> Input Class Initialized
INFO - 2023-09-19 08:11:38 --> Language Class Initialized
INFO - 2023-09-19 08:11:38 --> Loader Class Initialized
INFO - 2023-09-19 08:11:38 --> Helper loaded: url_helper
INFO - 2023-09-19 08:11:38 --> Helper loaded: file_helper
INFO - 2023-09-19 08:11:38 --> Helper loaded: html_helper
INFO - 2023-09-19 08:11:38 --> Helper loaded: text_helper
INFO - 2023-09-19 08:11:38 --> Helper loaded: form_helper
INFO - 2023-09-19 08:11:38 --> Helper loaded: lang_helper
INFO - 2023-09-19 08:11:38 --> Helper loaded: security_helper
INFO - 2023-09-19 08:11:38 --> Helper loaded: cookie_helper
INFO - 2023-09-19 08:11:38 --> Database Driver Class Initialized
INFO - 2023-09-19 08:11:38 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-19 08:11:38 --> Parser Class Initialized
INFO - 2023-09-19 08:11:38 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-19 08:11:38 --> Pagination Class Initialized
INFO - 2023-09-19 08:11:38 --> Form Validation Class Initialized
INFO - 2023-09-19 08:11:38 --> Controller Class Initialized
INFO - 2023-09-19 08:11:38 --> Model Class Initialized
DEBUG - 2023-09-19 08:11:38 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-09-19 08:11:38 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-19 08:11:38 --> Model Class Initialized
DEBUG - 2023-09-19 08:11:38 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-19 08:11:38 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/demandrequest/add_demandrequest_form.php
DEBUG - 2023-09-19 08:11:38 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-09-19 08:11:38 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-09-19 08:11:38 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-09-19 08:11:38 --> Model Class Initialized
INFO - 2023-09-19 08:11:38 --> Model Class Initialized
INFO - 2023-09-19 08:11:38 --> Model Class Initialized
INFO - 2023-09-19 08:11:38 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-09-19 08:11:38 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-09-19 08:11:38 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-09-19 08:11:38 --> Final output sent to browser
DEBUG - 2023-09-19 08:11:38 --> Total execution time: 0.0735
ERROR - 2023-09-19 08:12:02 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-19 08:12:02 --> Config Class Initialized
INFO - 2023-09-19 08:12:02 --> Hooks Class Initialized
DEBUG - 2023-09-19 08:12:02 --> UTF-8 Support Enabled
INFO - 2023-09-19 08:12:02 --> Utf8 Class Initialized
INFO - 2023-09-19 08:12:02 --> URI Class Initialized
INFO - 2023-09-19 08:12:02 --> Router Class Initialized
INFO - 2023-09-19 08:12:02 --> Output Class Initialized
INFO - 2023-09-19 08:12:02 --> Security Class Initialized
DEBUG - 2023-09-19 08:12:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-19 08:12:02 --> Input Class Initialized
INFO - 2023-09-19 08:12:02 --> Language Class Initialized
INFO - 2023-09-19 08:12:02 --> Loader Class Initialized
INFO - 2023-09-19 08:12:02 --> Helper loaded: url_helper
INFO - 2023-09-19 08:12:02 --> Helper loaded: file_helper
INFO - 2023-09-19 08:12:02 --> Helper loaded: html_helper
INFO - 2023-09-19 08:12:02 --> Helper loaded: text_helper
INFO - 2023-09-19 08:12:02 --> Helper loaded: form_helper
INFO - 2023-09-19 08:12:02 --> Helper loaded: lang_helper
INFO - 2023-09-19 08:12:02 --> Helper loaded: security_helper
INFO - 2023-09-19 08:12:02 --> Helper loaded: cookie_helper
INFO - 2023-09-19 08:12:02 --> Database Driver Class Initialized
INFO - 2023-09-19 08:12:02 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-19 08:12:02 --> Parser Class Initialized
INFO - 2023-09-19 08:12:02 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-19 08:12:02 --> Pagination Class Initialized
INFO - 2023-09-19 08:12:02 --> Form Validation Class Initialized
INFO - 2023-09-19 08:12:02 --> Controller Class Initialized
INFO - 2023-09-19 08:12:02 --> Model Class Initialized
DEBUG - 2023-09-19 08:12:02 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-09-19 08:12:02 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-19 08:12:02 --> Model Class Initialized
INFO - 2023-09-19 08:12:02 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/demandrequest/demandrequest.php
DEBUG - 2023-09-19 08:12:02 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-09-19 08:12:02 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-09-19 08:12:02 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-09-19 08:12:02 --> Model Class Initialized
INFO - 2023-09-19 08:12:02 --> Model Class Initialized
INFO - 2023-09-19 08:12:02 --> Model Class Initialized
INFO - 2023-09-19 08:12:02 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-09-19 08:12:02 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-09-19 08:12:02 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-09-19 08:12:02 --> Final output sent to browser
DEBUG - 2023-09-19 08:12:02 --> Total execution time: 0.0816
ERROR - 2023-09-19 08:12:02 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-19 08:12:02 --> Config Class Initialized
INFO - 2023-09-19 08:12:02 --> Hooks Class Initialized
DEBUG - 2023-09-19 08:12:02 --> UTF-8 Support Enabled
INFO - 2023-09-19 08:12:02 --> Utf8 Class Initialized
INFO - 2023-09-19 08:12:02 --> URI Class Initialized
INFO - 2023-09-19 08:12:02 --> Router Class Initialized
INFO - 2023-09-19 08:12:02 --> Output Class Initialized
INFO - 2023-09-19 08:12:02 --> Security Class Initialized
DEBUG - 2023-09-19 08:12:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-19 08:12:02 --> Input Class Initialized
INFO - 2023-09-19 08:12:02 --> Language Class Initialized
INFO - 2023-09-19 08:12:02 --> Loader Class Initialized
INFO - 2023-09-19 08:12:02 --> Helper loaded: url_helper
INFO - 2023-09-19 08:12:02 --> Helper loaded: file_helper
INFO - 2023-09-19 08:12:02 --> Helper loaded: html_helper
INFO - 2023-09-19 08:12:02 --> Helper loaded: text_helper
INFO - 2023-09-19 08:12:02 --> Helper loaded: form_helper
INFO - 2023-09-19 08:12:02 --> Helper loaded: lang_helper
INFO - 2023-09-19 08:12:02 --> Helper loaded: security_helper
INFO - 2023-09-19 08:12:02 --> Helper loaded: cookie_helper
INFO - 2023-09-19 08:12:02 --> Database Driver Class Initialized
INFO - 2023-09-19 08:12:02 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-19 08:12:02 --> Parser Class Initialized
INFO - 2023-09-19 08:12:02 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-19 08:12:02 --> Pagination Class Initialized
INFO - 2023-09-19 08:12:02 --> Form Validation Class Initialized
INFO - 2023-09-19 08:12:02 --> Controller Class Initialized
INFO - 2023-09-19 08:12:02 --> Model Class Initialized
DEBUG - 2023-09-19 08:12:02 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-09-19 08:12:02 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-19 08:12:02 --> Model Class Initialized
INFO - 2023-09-19 08:12:02 --> Final output sent to browser
DEBUG - 2023-09-19 08:12:02 --> Total execution time: 0.0168
ERROR - 2023-09-19 08:12:08 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-19 08:12:08 --> Config Class Initialized
INFO - 2023-09-19 08:12:08 --> Hooks Class Initialized
DEBUG - 2023-09-19 08:12:08 --> UTF-8 Support Enabled
INFO - 2023-09-19 08:12:08 --> Utf8 Class Initialized
INFO - 2023-09-19 08:12:08 --> URI Class Initialized
INFO - 2023-09-19 08:12:08 --> Router Class Initialized
INFO - 2023-09-19 08:12:08 --> Output Class Initialized
INFO - 2023-09-19 08:12:08 --> Security Class Initialized
DEBUG - 2023-09-19 08:12:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-19 08:12:08 --> Input Class Initialized
INFO - 2023-09-19 08:12:08 --> Language Class Initialized
INFO - 2023-09-19 08:12:08 --> Loader Class Initialized
INFO - 2023-09-19 08:12:08 --> Helper loaded: url_helper
INFO - 2023-09-19 08:12:08 --> Helper loaded: file_helper
INFO - 2023-09-19 08:12:08 --> Helper loaded: html_helper
INFO - 2023-09-19 08:12:08 --> Helper loaded: text_helper
INFO - 2023-09-19 08:12:08 --> Helper loaded: form_helper
INFO - 2023-09-19 08:12:08 --> Helper loaded: lang_helper
INFO - 2023-09-19 08:12:08 --> Helper loaded: security_helper
INFO - 2023-09-19 08:12:08 --> Helper loaded: cookie_helper
INFO - 2023-09-19 08:12:08 --> Database Driver Class Initialized
INFO - 2023-09-19 08:12:08 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-19 08:12:08 --> Parser Class Initialized
INFO - 2023-09-19 08:12:08 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-19 08:12:08 --> Pagination Class Initialized
INFO - 2023-09-19 08:12:08 --> Form Validation Class Initialized
INFO - 2023-09-19 08:12:08 --> Controller Class Initialized
INFO - 2023-09-19 08:12:08 --> Model Class Initialized
DEBUG - 2023-09-19 08:12:08 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-09-19 08:12:08 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-19 08:12:08 --> Model Class Initialized
DEBUG - 2023-09-19 08:12:08 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-19 08:12:09 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/demandrequest/add_demandrequest_form.php
DEBUG - 2023-09-19 08:12:09 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-09-19 08:12:09 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-09-19 08:12:09 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-09-19 08:12:09 --> Model Class Initialized
INFO - 2023-09-19 08:12:09 --> Model Class Initialized
INFO - 2023-09-19 08:12:09 --> Model Class Initialized
INFO - 2023-09-19 08:12:09 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-09-19 08:12:09 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-09-19 08:12:09 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-09-19 08:12:09 --> Final output sent to browser
DEBUG - 2023-09-19 08:12:09 --> Total execution time: 0.0699
ERROR - 2023-09-19 08:12:14 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-19 08:12:14 --> Config Class Initialized
INFO - 2023-09-19 08:12:14 --> Hooks Class Initialized
DEBUG - 2023-09-19 08:12:14 --> UTF-8 Support Enabled
INFO - 2023-09-19 08:12:14 --> Utf8 Class Initialized
INFO - 2023-09-19 08:12:14 --> URI Class Initialized
INFO - 2023-09-19 08:12:14 --> Router Class Initialized
INFO - 2023-09-19 08:12:14 --> Output Class Initialized
INFO - 2023-09-19 08:12:14 --> Security Class Initialized
DEBUG - 2023-09-19 08:12:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-19 08:12:14 --> Input Class Initialized
INFO - 2023-09-19 08:12:14 --> Language Class Initialized
INFO - 2023-09-19 08:12:14 --> Loader Class Initialized
INFO - 2023-09-19 08:12:14 --> Helper loaded: url_helper
INFO - 2023-09-19 08:12:14 --> Helper loaded: file_helper
INFO - 2023-09-19 08:12:14 --> Helper loaded: html_helper
INFO - 2023-09-19 08:12:14 --> Helper loaded: text_helper
INFO - 2023-09-19 08:12:14 --> Helper loaded: form_helper
INFO - 2023-09-19 08:12:14 --> Helper loaded: lang_helper
INFO - 2023-09-19 08:12:14 --> Helper loaded: security_helper
INFO - 2023-09-19 08:12:14 --> Helper loaded: cookie_helper
INFO - 2023-09-19 08:12:14 --> Database Driver Class Initialized
INFO - 2023-09-19 08:12:14 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-19 08:12:14 --> Parser Class Initialized
INFO - 2023-09-19 08:12:14 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-19 08:12:14 --> Pagination Class Initialized
INFO - 2023-09-19 08:12:14 --> Form Validation Class Initialized
INFO - 2023-09-19 08:12:14 --> Controller Class Initialized
INFO - 2023-09-19 08:12:14 --> Model Class Initialized
DEBUG - 2023-09-19 08:12:14 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-09-19 08:12:14 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-19 08:12:14 --> Model Class Initialized
DEBUG - 2023-09-19 08:12:14 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-19 08:12:14 --> Model Class Initialized
INFO - 2023-09-19 08:12:14 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/invoice/invoice.php
DEBUG - 2023-09-19 08:12:14 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-09-19 08:12:14 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-09-19 08:12:14 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-09-19 08:12:14 --> Model Class Initialized
INFO - 2023-09-19 08:12:14 --> Model Class Initialized
INFO - 2023-09-19 08:12:14 --> Model Class Initialized
INFO - 2023-09-19 08:12:14 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-09-19 08:12:14 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-09-19 08:12:14 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-09-19 08:12:14 --> Final output sent to browser
DEBUG - 2023-09-19 08:12:14 --> Total execution time: 0.0833
ERROR - 2023-09-19 08:12:14 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-19 08:12:14 --> Config Class Initialized
INFO - 2023-09-19 08:12:14 --> Hooks Class Initialized
DEBUG - 2023-09-19 08:12:14 --> UTF-8 Support Enabled
INFO - 2023-09-19 08:12:14 --> Utf8 Class Initialized
INFO - 2023-09-19 08:12:14 --> URI Class Initialized
INFO - 2023-09-19 08:12:14 --> Router Class Initialized
INFO - 2023-09-19 08:12:14 --> Output Class Initialized
INFO - 2023-09-19 08:12:14 --> Security Class Initialized
DEBUG - 2023-09-19 08:12:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-19 08:12:14 --> Input Class Initialized
INFO - 2023-09-19 08:12:14 --> Language Class Initialized
INFO - 2023-09-19 08:12:14 --> Loader Class Initialized
INFO - 2023-09-19 08:12:14 --> Helper loaded: url_helper
INFO - 2023-09-19 08:12:14 --> Helper loaded: file_helper
INFO - 2023-09-19 08:12:14 --> Helper loaded: html_helper
INFO - 2023-09-19 08:12:14 --> Helper loaded: text_helper
INFO - 2023-09-19 08:12:14 --> Helper loaded: form_helper
INFO - 2023-09-19 08:12:14 --> Helper loaded: lang_helper
INFO - 2023-09-19 08:12:14 --> Helper loaded: security_helper
INFO - 2023-09-19 08:12:14 --> Helper loaded: cookie_helper
INFO - 2023-09-19 08:12:14 --> Database Driver Class Initialized
INFO - 2023-09-19 08:12:14 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-19 08:12:14 --> Parser Class Initialized
INFO - 2023-09-19 08:12:14 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-19 08:12:14 --> Pagination Class Initialized
INFO - 2023-09-19 08:12:14 --> Form Validation Class Initialized
INFO - 2023-09-19 08:12:14 --> Controller Class Initialized
INFO - 2023-09-19 08:12:14 --> Model Class Initialized
DEBUG - 2023-09-19 08:12:14 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-09-19 08:12:14 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-19 08:12:14 --> Model Class Initialized
DEBUG - 2023-09-19 08:12:14 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-19 08:12:14 --> Model Class Initialized
INFO - 2023-09-19 08:12:14 --> Final output sent to browser
DEBUG - 2023-09-19 08:12:14 --> Total execution time: 0.0196
ERROR - 2023-09-19 08:12:20 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-19 08:12:20 --> Config Class Initialized
INFO - 2023-09-19 08:12:20 --> Hooks Class Initialized
DEBUG - 2023-09-19 08:12:20 --> UTF-8 Support Enabled
INFO - 2023-09-19 08:12:20 --> Utf8 Class Initialized
INFO - 2023-09-19 08:12:20 --> URI Class Initialized
INFO - 2023-09-19 08:12:20 --> Router Class Initialized
INFO - 2023-09-19 08:12:20 --> Output Class Initialized
INFO - 2023-09-19 08:12:20 --> Security Class Initialized
DEBUG - 2023-09-19 08:12:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-19 08:12:20 --> Input Class Initialized
INFO - 2023-09-19 08:12:20 --> Language Class Initialized
INFO - 2023-09-19 08:12:20 --> Loader Class Initialized
INFO - 2023-09-19 08:12:20 --> Helper loaded: url_helper
INFO - 2023-09-19 08:12:20 --> Helper loaded: file_helper
INFO - 2023-09-19 08:12:20 --> Helper loaded: html_helper
INFO - 2023-09-19 08:12:20 --> Helper loaded: text_helper
INFO - 2023-09-19 08:12:20 --> Helper loaded: form_helper
INFO - 2023-09-19 08:12:20 --> Helper loaded: lang_helper
INFO - 2023-09-19 08:12:20 --> Helper loaded: security_helper
INFO - 2023-09-19 08:12:20 --> Helper loaded: cookie_helper
INFO - 2023-09-19 08:12:20 --> Database Driver Class Initialized
INFO - 2023-09-19 08:12:20 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-19 08:12:20 --> Parser Class Initialized
INFO - 2023-09-19 08:12:20 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-19 08:12:20 --> Pagination Class Initialized
INFO - 2023-09-19 08:12:20 --> Form Validation Class Initialized
INFO - 2023-09-19 08:12:20 --> Controller Class Initialized
INFO - 2023-09-19 08:12:20 --> Model Class Initialized
DEBUG - 2023-09-19 08:12:20 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-09-19 08:12:20 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-19 08:12:20 --> Model Class Initialized
DEBUG - 2023-09-19 08:12:20 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-19 08:12:20 --> Model Class Initialized
INFO - 2023-09-19 08:12:20 --> Final output sent to browser
DEBUG - 2023-09-19 08:12:20 --> Total execution time: 0.0194
ERROR - 2023-09-19 08:12:27 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-19 08:12:27 --> Config Class Initialized
INFO - 2023-09-19 08:12:27 --> Hooks Class Initialized
DEBUG - 2023-09-19 08:12:27 --> UTF-8 Support Enabled
INFO - 2023-09-19 08:12:27 --> Utf8 Class Initialized
INFO - 2023-09-19 08:12:27 --> URI Class Initialized
DEBUG - 2023-09-19 08:12:27 --> No URI present. Default controller set.
INFO - 2023-09-19 08:12:27 --> Router Class Initialized
INFO - 2023-09-19 08:12:27 --> Output Class Initialized
INFO - 2023-09-19 08:12:27 --> Security Class Initialized
DEBUG - 2023-09-19 08:12:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-19 08:12:27 --> Input Class Initialized
INFO - 2023-09-19 08:12:27 --> Language Class Initialized
INFO - 2023-09-19 08:12:27 --> Loader Class Initialized
INFO - 2023-09-19 08:12:27 --> Helper loaded: url_helper
INFO - 2023-09-19 08:12:27 --> Helper loaded: file_helper
INFO - 2023-09-19 08:12:27 --> Helper loaded: html_helper
INFO - 2023-09-19 08:12:27 --> Helper loaded: text_helper
INFO - 2023-09-19 08:12:27 --> Helper loaded: form_helper
INFO - 2023-09-19 08:12:27 --> Helper loaded: lang_helper
INFO - 2023-09-19 08:12:27 --> Helper loaded: security_helper
INFO - 2023-09-19 08:12:27 --> Helper loaded: cookie_helper
INFO - 2023-09-19 08:12:27 --> Database Driver Class Initialized
INFO - 2023-09-19 08:12:27 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-19 08:12:27 --> Parser Class Initialized
INFO - 2023-09-19 08:12:27 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-19 08:12:27 --> Pagination Class Initialized
INFO - 2023-09-19 08:12:27 --> Form Validation Class Initialized
INFO - 2023-09-19 08:12:27 --> Controller Class Initialized
INFO - 2023-09-19 08:12:27 --> Model Class Initialized
DEBUG - 2023-09-19 08:12:27 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-19 08:12:27 --> Model Class Initialized
DEBUG - 2023-09-19 08:12:27 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-19 08:12:27 --> Model Class Initialized
INFO - 2023-09-19 08:12:27 --> Model Class Initialized
INFO - 2023-09-19 08:12:27 --> Model Class Initialized
INFO - 2023-09-19 08:12:27 --> Model Class Initialized
DEBUG - 2023-09-19 08:12:27 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-09-19 08:12:27 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-19 08:12:27 --> Model Class Initialized
INFO - 2023-09-19 08:12:27 --> Model Class Initialized
INFO - 2023-09-19 08:12:27 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-09-19 08:12:27 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-09-19 08:12:27 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-09-19 08:12:27 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-09-19 08:12:27 --> Model Class Initialized
INFO - 2023-09-19 08:12:27 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-09-19 08:12:27 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-09-19 08:12:27 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-09-19 08:12:27 --> Final output sent to browser
DEBUG - 2023-09-19 08:12:27 --> Total execution time: 0.0857
ERROR - 2023-09-19 08:12:32 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-19 08:12:32 --> Config Class Initialized
INFO - 2023-09-19 08:12:32 --> Hooks Class Initialized
DEBUG - 2023-09-19 08:12:32 --> UTF-8 Support Enabled
INFO - 2023-09-19 08:12:32 --> Utf8 Class Initialized
INFO - 2023-09-19 08:12:32 --> URI Class Initialized
INFO - 2023-09-19 08:12:32 --> Router Class Initialized
INFO - 2023-09-19 08:12:32 --> Output Class Initialized
INFO - 2023-09-19 08:12:32 --> Security Class Initialized
DEBUG - 2023-09-19 08:12:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-19 08:12:32 --> Input Class Initialized
INFO - 2023-09-19 08:12:32 --> Language Class Initialized
INFO - 2023-09-19 08:12:32 --> Loader Class Initialized
INFO - 2023-09-19 08:12:32 --> Helper loaded: url_helper
INFO - 2023-09-19 08:12:32 --> Helper loaded: file_helper
INFO - 2023-09-19 08:12:32 --> Helper loaded: html_helper
INFO - 2023-09-19 08:12:32 --> Helper loaded: text_helper
INFO - 2023-09-19 08:12:32 --> Helper loaded: form_helper
INFO - 2023-09-19 08:12:32 --> Helper loaded: lang_helper
INFO - 2023-09-19 08:12:32 --> Helper loaded: security_helper
INFO - 2023-09-19 08:12:32 --> Helper loaded: cookie_helper
INFO - 2023-09-19 08:12:32 --> Database Driver Class Initialized
INFO - 2023-09-19 08:12:32 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-19 08:12:32 --> Parser Class Initialized
INFO - 2023-09-19 08:12:32 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-19 08:12:32 --> Pagination Class Initialized
INFO - 2023-09-19 08:12:32 --> Form Validation Class Initialized
INFO - 2023-09-19 08:12:32 --> Controller Class Initialized
INFO - 2023-09-19 08:12:32 --> Model Class Initialized
DEBUG - 2023-09-19 08:12:32 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-09-19 08:12:32 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-19 08:12:32 --> Model Class Initialized
DEBUG - 2023-09-19 08:12:32 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-19 08:12:32 --> Model Class Initialized
INFO - 2023-09-19 08:12:32 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice.php
DEBUG - 2023-09-19 08:12:32 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-09-19 08:12:32 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-09-19 08:12:32 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-09-19 08:12:32 --> Model Class Initialized
INFO - 2023-09-19 08:12:32 --> Model Class Initialized
INFO - 2023-09-19 08:12:32 --> Model Class Initialized
INFO - 2023-09-19 08:12:32 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-09-19 08:12:32 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-09-19 08:12:32 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-09-19 08:12:32 --> Final output sent to browser
DEBUG - 2023-09-19 08:12:32 --> Total execution time: 0.0695
ERROR - 2023-09-19 08:12:33 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-19 08:12:33 --> Config Class Initialized
INFO - 2023-09-19 08:12:33 --> Hooks Class Initialized
DEBUG - 2023-09-19 08:12:33 --> UTF-8 Support Enabled
INFO - 2023-09-19 08:12:33 --> Utf8 Class Initialized
INFO - 2023-09-19 08:12:33 --> URI Class Initialized
INFO - 2023-09-19 08:12:33 --> Router Class Initialized
INFO - 2023-09-19 08:12:33 --> Output Class Initialized
INFO - 2023-09-19 08:12:33 --> Security Class Initialized
DEBUG - 2023-09-19 08:12:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-19 08:12:33 --> Input Class Initialized
INFO - 2023-09-19 08:12:33 --> Language Class Initialized
INFO - 2023-09-19 08:12:33 --> Loader Class Initialized
INFO - 2023-09-19 08:12:33 --> Helper loaded: url_helper
INFO - 2023-09-19 08:12:33 --> Helper loaded: file_helper
INFO - 2023-09-19 08:12:33 --> Helper loaded: html_helper
INFO - 2023-09-19 08:12:33 --> Helper loaded: text_helper
INFO - 2023-09-19 08:12:33 --> Helper loaded: form_helper
INFO - 2023-09-19 08:12:33 --> Helper loaded: lang_helper
INFO - 2023-09-19 08:12:33 --> Helper loaded: security_helper
INFO - 2023-09-19 08:12:33 --> Helper loaded: cookie_helper
INFO - 2023-09-19 08:12:33 --> Database Driver Class Initialized
INFO - 2023-09-19 08:12:33 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-19 08:12:33 --> Parser Class Initialized
INFO - 2023-09-19 08:12:33 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-19 08:12:33 --> Pagination Class Initialized
INFO - 2023-09-19 08:12:33 --> Form Validation Class Initialized
INFO - 2023-09-19 08:12:33 --> Controller Class Initialized
INFO - 2023-09-19 08:12:33 --> Model Class Initialized
DEBUG - 2023-09-19 08:12:33 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-09-19 08:12:33 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-19 08:12:33 --> Model Class Initialized
DEBUG - 2023-09-19 08:12:33 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-19 08:12:33 --> Model Class Initialized
INFO - 2023-09-19 08:12:33 --> Final output sent to browser
DEBUG - 2023-09-19 08:12:33 --> Total execution time: 0.0218
ERROR - 2023-09-19 08:12:44 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-19 08:12:44 --> Config Class Initialized
INFO - 2023-09-19 08:12:44 --> Hooks Class Initialized
DEBUG - 2023-09-19 08:12:44 --> UTF-8 Support Enabled
INFO - 2023-09-19 08:12:44 --> Utf8 Class Initialized
INFO - 2023-09-19 08:12:44 --> URI Class Initialized
DEBUG - 2023-09-19 08:12:44 --> No URI present. Default controller set.
INFO - 2023-09-19 08:12:44 --> Router Class Initialized
INFO - 2023-09-19 08:12:44 --> Output Class Initialized
INFO - 2023-09-19 08:12:44 --> Security Class Initialized
DEBUG - 2023-09-19 08:12:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-19 08:12:44 --> Input Class Initialized
INFO - 2023-09-19 08:12:44 --> Language Class Initialized
INFO - 2023-09-19 08:12:44 --> Loader Class Initialized
INFO - 2023-09-19 08:12:44 --> Helper loaded: url_helper
INFO - 2023-09-19 08:12:44 --> Helper loaded: file_helper
INFO - 2023-09-19 08:12:44 --> Helper loaded: html_helper
INFO - 2023-09-19 08:12:44 --> Helper loaded: text_helper
INFO - 2023-09-19 08:12:44 --> Helper loaded: form_helper
INFO - 2023-09-19 08:12:44 --> Helper loaded: lang_helper
INFO - 2023-09-19 08:12:44 --> Helper loaded: security_helper
INFO - 2023-09-19 08:12:44 --> Helper loaded: cookie_helper
INFO - 2023-09-19 08:12:44 --> Database Driver Class Initialized
INFO - 2023-09-19 08:12:44 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-19 08:12:44 --> Parser Class Initialized
INFO - 2023-09-19 08:12:44 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-19 08:12:44 --> Pagination Class Initialized
INFO - 2023-09-19 08:12:44 --> Form Validation Class Initialized
INFO - 2023-09-19 08:12:44 --> Controller Class Initialized
INFO - 2023-09-19 08:12:44 --> Model Class Initialized
DEBUG - 2023-09-19 08:12:44 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-19 08:12:44 --> Model Class Initialized
DEBUG - 2023-09-19 08:12:44 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-19 08:12:44 --> Model Class Initialized
INFO - 2023-09-19 08:12:44 --> Model Class Initialized
INFO - 2023-09-19 08:12:44 --> Model Class Initialized
INFO - 2023-09-19 08:12:44 --> Model Class Initialized
DEBUG - 2023-09-19 08:12:44 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-09-19 08:12:44 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-19 08:12:44 --> Model Class Initialized
INFO - 2023-09-19 08:12:44 --> Model Class Initialized
INFO - 2023-09-19 08:12:44 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-09-19 08:12:44 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-09-19 08:12:44 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-09-19 08:12:44 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-09-19 08:12:44 --> Model Class Initialized
INFO - 2023-09-19 08:12:44 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-09-19 08:12:44 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-09-19 08:12:44 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-09-19 08:12:44 --> Final output sent to browser
DEBUG - 2023-09-19 08:12:44 --> Total execution time: 0.1036
ERROR - 2023-09-19 08:12:50 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-19 08:12:50 --> Config Class Initialized
INFO - 2023-09-19 08:12:50 --> Hooks Class Initialized
DEBUG - 2023-09-19 08:12:50 --> UTF-8 Support Enabled
INFO - 2023-09-19 08:12:50 --> Utf8 Class Initialized
INFO - 2023-09-19 08:12:50 --> URI Class Initialized
INFO - 2023-09-19 08:12:50 --> Router Class Initialized
INFO - 2023-09-19 08:12:50 --> Output Class Initialized
INFO - 2023-09-19 08:12:50 --> Security Class Initialized
DEBUG - 2023-09-19 08:12:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-19 08:12:50 --> Input Class Initialized
INFO - 2023-09-19 08:12:50 --> Language Class Initialized
INFO - 2023-09-19 08:12:50 --> Loader Class Initialized
INFO - 2023-09-19 08:12:50 --> Helper loaded: url_helper
INFO - 2023-09-19 08:12:50 --> Helper loaded: file_helper
INFO - 2023-09-19 08:12:50 --> Helper loaded: html_helper
INFO - 2023-09-19 08:12:50 --> Helper loaded: text_helper
INFO - 2023-09-19 08:12:50 --> Helper loaded: form_helper
INFO - 2023-09-19 08:12:50 --> Helper loaded: lang_helper
INFO - 2023-09-19 08:12:50 --> Helper loaded: security_helper
INFO - 2023-09-19 08:12:50 --> Helper loaded: cookie_helper
INFO - 2023-09-19 08:12:50 --> Database Driver Class Initialized
INFO - 2023-09-19 08:12:50 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-19 08:12:50 --> Parser Class Initialized
INFO - 2023-09-19 08:12:50 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-19 08:12:50 --> Pagination Class Initialized
INFO - 2023-09-19 08:12:50 --> Form Validation Class Initialized
INFO - 2023-09-19 08:12:50 --> Controller Class Initialized
INFO - 2023-09-19 08:12:50 --> Model Class Initialized
DEBUG - 2023-09-19 08:12:50 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-09-19 08:12:50 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-19 08:12:50 --> Model Class Initialized
DEBUG - 2023-09-19 08:12:50 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-19 08:12:50 --> Model Class Initialized
INFO - 2023-09-19 08:12:50 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice.php
DEBUG - 2023-09-19 08:12:50 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-09-19 08:12:50 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-09-19 08:12:50 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-09-19 08:12:50 --> Model Class Initialized
INFO - 2023-09-19 08:12:50 --> Model Class Initialized
INFO - 2023-09-19 08:12:50 --> Model Class Initialized
INFO - 2023-09-19 08:12:50 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-09-19 08:12:50 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-09-19 08:12:50 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-09-19 08:12:50 --> Final output sent to browser
DEBUG - 2023-09-19 08:12:50 --> Total execution time: 0.0710
ERROR - 2023-09-19 08:12:50 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-19 08:12:50 --> Config Class Initialized
INFO - 2023-09-19 08:12:50 --> Hooks Class Initialized
DEBUG - 2023-09-19 08:12:50 --> UTF-8 Support Enabled
INFO - 2023-09-19 08:12:50 --> Utf8 Class Initialized
INFO - 2023-09-19 08:12:50 --> URI Class Initialized
INFO - 2023-09-19 08:12:50 --> Router Class Initialized
INFO - 2023-09-19 08:12:50 --> Output Class Initialized
INFO - 2023-09-19 08:12:50 --> Security Class Initialized
DEBUG - 2023-09-19 08:12:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-19 08:12:50 --> Input Class Initialized
INFO - 2023-09-19 08:12:50 --> Language Class Initialized
INFO - 2023-09-19 08:12:50 --> Loader Class Initialized
INFO - 2023-09-19 08:12:50 --> Helper loaded: url_helper
INFO - 2023-09-19 08:12:50 --> Helper loaded: file_helper
INFO - 2023-09-19 08:12:50 --> Helper loaded: html_helper
INFO - 2023-09-19 08:12:50 --> Helper loaded: text_helper
INFO - 2023-09-19 08:12:50 --> Helper loaded: form_helper
INFO - 2023-09-19 08:12:50 --> Helper loaded: lang_helper
INFO - 2023-09-19 08:12:50 --> Helper loaded: security_helper
INFO - 2023-09-19 08:12:50 --> Helper loaded: cookie_helper
INFO - 2023-09-19 08:12:50 --> Database Driver Class Initialized
INFO - 2023-09-19 08:12:50 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-19 08:12:50 --> Parser Class Initialized
INFO - 2023-09-19 08:12:50 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-19 08:12:50 --> Pagination Class Initialized
INFO - 2023-09-19 08:12:50 --> Form Validation Class Initialized
INFO - 2023-09-19 08:12:50 --> Controller Class Initialized
INFO - 2023-09-19 08:12:50 --> Model Class Initialized
DEBUG - 2023-09-19 08:12:50 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-09-19 08:12:50 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-19 08:12:50 --> Model Class Initialized
DEBUG - 2023-09-19 08:12:50 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-19 08:12:50 --> Model Class Initialized
INFO - 2023-09-19 08:12:50 --> Final output sent to browser
DEBUG - 2023-09-19 08:12:50 --> Total execution time: 0.0225
ERROR - 2023-09-19 08:13:40 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-19 08:13:40 --> Config Class Initialized
INFO - 2023-09-19 08:13:40 --> Hooks Class Initialized
DEBUG - 2023-09-19 08:13:40 --> UTF-8 Support Enabled
INFO - 2023-09-19 08:13:40 --> Utf8 Class Initialized
INFO - 2023-09-19 08:13:40 --> URI Class Initialized
INFO - 2023-09-19 08:13:40 --> Router Class Initialized
INFO - 2023-09-19 08:13:40 --> Output Class Initialized
INFO - 2023-09-19 08:13:40 --> Security Class Initialized
DEBUG - 2023-09-19 08:13:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-19 08:13:40 --> Input Class Initialized
INFO - 2023-09-19 08:13:40 --> Language Class Initialized
INFO - 2023-09-19 08:13:40 --> Loader Class Initialized
INFO - 2023-09-19 08:13:40 --> Helper loaded: url_helper
INFO - 2023-09-19 08:13:40 --> Helper loaded: file_helper
INFO - 2023-09-19 08:13:40 --> Helper loaded: html_helper
INFO - 2023-09-19 08:13:40 --> Helper loaded: text_helper
INFO - 2023-09-19 08:13:40 --> Helper loaded: form_helper
INFO - 2023-09-19 08:13:40 --> Helper loaded: lang_helper
INFO - 2023-09-19 08:13:40 --> Helper loaded: security_helper
INFO - 2023-09-19 08:13:40 --> Helper loaded: cookie_helper
INFO - 2023-09-19 08:13:40 --> Database Driver Class Initialized
INFO - 2023-09-19 08:13:40 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-19 08:13:40 --> Parser Class Initialized
INFO - 2023-09-19 08:13:40 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-19 08:13:40 --> Pagination Class Initialized
INFO - 2023-09-19 08:13:40 --> Form Validation Class Initialized
INFO - 2023-09-19 08:13:40 --> Controller Class Initialized
INFO - 2023-09-19 08:13:40 --> Model Class Initialized
DEBUG - 2023-09-19 08:13:40 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-09-19 08:13:40 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-19 08:13:40 --> Model Class Initialized
DEBUG - 2023-09-19 08:13:40 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-19 08:13:40 --> Model Class Initialized
INFO - 2023-09-19 08:13:40 --> Final output sent to browser
DEBUG - 2023-09-19 08:13:40 --> Total execution time: 0.0254
ERROR - 2023-09-19 08:13:47 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-19 08:13:47 --> Config Class Initialized
INFO - 2023-09-19 08:13:47 --> Hooks Class Initialized
DEBUG - 2023-09-19 08:13:47 --> UTF-8 Support Enabled
INFO - 2023-09-19 08:13:47 --> Utf8 Class Initialized
INFO - 2023-09-19 08:13:47 --> URI Class Initialized
INFO - 2023-09-19 08:13:47 --> Router Class Initialized
INFO - 2023-09-19 08:13:47 --> Output Class Initialized
INFO - 2023-09-19 08:13:47 --> Security Class Initialized
DEBUG - 2023-09-19 08:13:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-19 08:13:47 --> Input Class Initialized
INFO - 2023-09-19 08:13:47 --> Language Class Initialized
INFO - 2023-09-19 08:13:47 --> Loader Class Initialized
INFO - 2023-09-19 08:13:47 --> Helper loaded: url_helper
INFO - 2023-09-19 08:13:47 --> Helper loaded: file_helper
INFO - 2023-09-19 08:13:47 --> Helper loaded: html_helper
INFO - 2023-09-19 08:13:47 --> Helper loaded: text_helper
INFO - 2023-09-19 08:13:47 --> Helper loaded: form_helper
INFO - 2023-09-19 08:13:47 --> Helper loaded: lang_helper
INFO - 2023-09-19 08:13:47 --> Helper loaded: security_helper
INFO - 2023-09-19 08:13:47 --> Helper loaded: cookie_helper
INFO - 2023-09-19 08:13:47 --> Database Driver Class Initialized
INFO - 2023-09-19 08:13:47 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-19 08:13:47 --> Parser Class Initialized
INFO - 2023-09-19 08:13:47 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-19 08:13:47 --> Pagination Class Initialized
INFO - 2023-09-19 08:13:47 --> Form Validation Class Initialized
INFO - 2023-09-19 08:13:47 --> Controller Class Initialized
INFO - 2023-09-19 08:13:47 --> Model Class Initialized
DEBUG - 2023-09-19 08:13:47 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-09-19 08:13:47 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-19 08:13:47 --> Model Class Initialized
DEBUG - 2023-09-19 08:13:47 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-19 08:13:47 --> Model Class Initialized
INFO - 2023-09-19 08:13:47 --> Final output sent to browser
DEBUG - 2023-09-19 08:13:47 --> Total execution time: 0.0226
ERROR - 2023-09-19 11:45:26 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-19 11:45:26 --> Config Class Initialized
INFO - 2023-09-19 11:45:26 --> Hooks Class Initialized
DEBUG - 2023-09-19 11:45:26 --> UTF-8 Support Enabled
INFO - 2023-09-19 11:45:26 --> Utf8 Class Initialized
INFO - 2023-09-19 11:45:26 --> URI Class Initialized
DEBUG - 2023-09-19 11:45:26 --> No URI present. Default controller set.
INFO - 2023-09-19 11:45:26 --> Router Class Initialized
INFO - 2023-09-19 11:45:26 --> Output Class Initialized
INFO - 2023-09-19 11:45:26 --> Security Class Initialized
DEBUG - 2023-09-19 11:45:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-19 11:45:26 --> Input Class Initialized
INFO - 2023-09-19 11:45:26 --> Language Class Initialized
INFO - 2023-09-19 11:45:26 --> Loader Class Initialized
INFO - 2023-09-19 11:45:26 --> Helper loaded: url_helper
INFO - 2023-09-19 11:45:26 --> Helper loaded: file_helper
INFO - 2023-09-19 11:45:26 --> Helper loaded: html_helper
INFO - 2023-09-19 11:45:26 --> Helper loaded: text_helper
INFO - 2023-09-19 11:45:26 --> Helper loaded: form_helper
INFO - 2023-09-19 11:45:26 --> Helper loaded: lang_helper
INFO - 2023-09-19 11:45:26 --> Helper loaded: security_helper
INFO - 2023-09-19 11:45:26 --> Helper loaded: cookie_helper
INFO - 2023-09-19 11:45:26 --> Database Driver Class Initialized
INFO - 2023-09-19 11:45:26 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-19 11:45:26 --> Parser Class Initialized
INFO - 2023-09-19 11:45:26 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-19 11:45:26 --> Pagination Class Initialized
INFO - 2023-09-19 11:45:26 --> Form Validation Class Initialized
INFO - 2023-09-19 11:45:26 --> Controller Class Initialized
INFO - 2023-09-19 11:45:26 --> Model Class Initialized
DEBUG - 2023-09-19 11:45:26 --> Session class already loaded. Second attempt ignored.
ERROR - 2023-09-19 11:45:27 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-19 11:45:27 --> Config Class Initialized
INFO - 2023-09-19 11:45:27 --> Hooks Class Initialized
DEBUG - 2023-09-19 11:45:27 --> UTF-8 Support Enabled
INFO - 2023-09-19 11:45:27 --> Utf8 Class Initialized
INFO - 2023-09-19 11:45:27 --> URI Class Initialized
INFO - 2023-09-19 11:45:27 --> Router Class Initialized
INFO - 2023-09-19 11:45:27 --> Output Class Initialized
INFO - 2023-09-19 11:45:27 --> Security Class Initialized
DEBUG - 2023-09-19 11:45:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-19 11:45:27 --> Input Class Initialized
INFO - 2023-09-19 11:45:27 --> Language Class Initialized
INFO - 2023-09-19 11:45:27 --> Loader Class Initialized
INFO - 2023-09-19 11:45:27 --> Helper loaded: url_helper
INFO - 2023-09-19 11:45:27 --> Helper loaded: file_helper
INFO - 2023-09-19 11:45:27 --> Helper loaded: html_helper
INFO - 2023-09-19 11:45:27 --> Helper loaded: text_helper
INFO - 2023-09-19 11:45:27 --> Helper loaded: form_helper
INFO - 2023-09-19 11:45:27 --> Helper loaded: lang_helper
INFO - 2023-09-19 11:45:27 --> Helper loaded: security_helper
INFO - 2023-09-19 11:45:27 --> Helper loaded: cookie_helper
INFO - 2023-09-19 11:45:27 --> Database Driver Class Initialized
INFO - 2023-09-19 11:45:27 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-19 11:45:27 --> Parser Class Initialized
INFO - 2023-09-19 11:45:27 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-19 11:45:27 --> Pagination Class Initialized
INFO - 2023-09-19 11:45:27 --> Form Validation Class Initialized
INFO - 2023-09-19 11:45:27 --> Controller Class Initialized
INFO - 2023-09-19 11:45:27 --> Model Class Initialized
DEBUG - 2023-09-19 11:45:27 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-19 11:45:27 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2023-09-19 11:45:27 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-09-19 11:45:27 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-09-19 11:45:27 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-09-19 11:45:27 --> Model Class Initialized
INFO - 2023-09-19 11:45:27 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-09-19 11:45:27 --> Final output sent to browser
DEBUG - 2023-09-19 11:45:27 --> Total execution time: 0.0293
ERROR - 2023-09-19 11:46:07 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-19 11:46:07 --> Config Class Initialized
INFO - 2023-09-19 11:46:07 --> Hooks Class Initialized
DEBUG - 2023-09-19 11:46:07 --> UTF-8 Support Enabled
INFO - 2023-09-19 11:46:07 --> Utf8 Class Initialized
INFO - 2023-09-19 11:46:07 --> URI Class Initialized
INFO - 2023-09-19 11:46:07 --> Router Class Initialized
INFO - 2023-09-19 11:46:07 --> Output Class Initialized
INFO - 2023-09-19 11:46:07 --> Security Class Initialized
DEBUG - 2023-09-19 11:46:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-19 11:46:07 --> Input Class Initialized
INFO - 2023-09-19 11:46:07 --> Language Class Initialized
INFO - 2023-09-19 11:46:07 --> Loader Class Initialized
INFO - 2023-09-19 11:46:07 --> Helper loaded: url_helper
INFO - 2023-09-19 11:46:07 --> Helper loaded: file_helper
INFO - 2023-09-19 11:46:07 --> Helper loaded: html_helper
INFO - 2023-09-19 11:46:07 --> Helper loaded: text_helper
INFO - 2023-09-19 11:46:07 --> Helper loaded: form_helper
INFO - 2023-09-19 11:46:07 --> Helper loaded: lang_helper
INFO - 2023-09-19 11:46:07 --> Helper loaded: security_helper
INFO - 2023-09-19 11:46:07 --> Helper loaded: cookie_helper
INFO - 2023-09-19 11:46:07 --> Database Driver Class Initialized
INFO - 2023-09-19 11:46:07 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-19 11:46:07 --> Parser Class Initialized
INFO - 2023-09-19 11:46:07 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-19 11:46:07 --> Pagination Class Initialized
INFO - 2023-09-19 11:46:07 --> Form Validation Class Initialized
INFO - 2023-09-19 11:46:07 --> Controller Class Initialized
INFO - 2023-09-19 11:46:07 --> Model Class Initialized
DEBUG - 2023-09-19 11:46:07 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-19 11:46:08 --> Model Class Initialized
INFO - 2023-09-19 11:46:08 --> Final output sent to browser
DEBUG - 2023-09-19 11:46:08 --> Total execution time: 0.0195
ERROR - 2023-09-19 11:46:08 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-19 11:46:08 --> Config Class Initialized
INFO - 2023-09-19 11:46:08 --> Hooks Class Initialized
DEBUG - 2023-09-19 11:46:08 --> UTF-8 Support Enabled
INFO - 2023-09-19 11:46:08 --> Utf8 Class Initialized
INFO - 2023-09-19 11:46:08 --> URI Class Initialized
DEBUG - 2023-09-19 11:46:08 --> No URI present. Default controller set.
INFO - 2023-09-19 11:46:08 --> Router Class Initialized
INFO - 2023-09-19 11:46:08 --> Output Class Initialized
INFO - 2023-09-19 11:46:08 --> Security Class Initialized
DEBUG - 2023-09-19 11:46:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-19 11:46:08 --> Input Class Initialized
INFO - 2023-09-19 11:46:08 --> Language Class Initialized
INFO - 2023-09-19 11:46:08 --> Loader Class Initialized
INFO - 2023-09-19 11:46:08 --> Helper loaded: url_helper
INFO - 2023-09-19 11:46:08 --> Helper loaded: file_helper
INFO - 2023-09-19 11:46:08 --> Helper loaded: html_helper
INFO - 2023-09-19 11:46:08 --> Helper loaded: text_helper
INFO - 2023-09-19 11:46:08 --> Helper loaded: form_helper
INFO - 2023-09-19 11:46:08 --> Helper loaded: lang_helper
INFO - 2023-09-19 11:46:08 --> Helper loaded: security_helper
INFO - 2023-09-19 11:46:08 --> Helper loaded: cookie_helper
INFO - 2023-09-19 11:46:08 --> Database Driver Class Initialized
INFO - 2023-09-19 11:46:08 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-19 11:46:08 --> Parser Class Initialized
INFO - 2023-09-19 11:46:08 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-19 11:46:08 --> Pagination Class Initialized
INFO - 2023-09-19 11:46:08 --> Form Validation Class Initialized
INFO - 2023-09-19 11:46:08 --> Controller Class Initialized
INFO - 2023-09-19 11:46:08 --> Model Class Initialized
DEBUG - 2023-09-19 11:46:08 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-19 11:46:08 --> Model Class Initialized
DEBUG - 2023-09-19 11:46:08 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-19 11:46:08 --> Model Class Initialized
INFO - 2023-09-19 11:46:08 --> Model Class Initialized
INFO - 2023-09-19 11:46:08 --> Model Class Initialized
INFO - 2023-09-19 11:46:08 --> Model Class Initialized
DEBUG - 2023-09-19 11:46:08 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-09-19 11:46:08 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-19 11:46:08 --> Model Class Initialized
INFO - 2023-09-19 11:46:08 --> Model Class Initialized
INFO - 2023-09-19 11:46:08 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-09-19 11:46:08 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-09-19 11:46:08 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-09-19 11:46:08 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-09-19 11:46:08 --> Model Class Initialized
INFO - 2023-09-19 11:46:08 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-09-19 11:46:08 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-09-19 11:46:08 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-09-19 11:46:08 --> Final output sent to browser
DEBUG - 2023-09-19 11:46:08 --> Total execution time: 0.1998
ERROR - 2023-09-19 11:46:09 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-19 11:46:09 --> Config Class Initialized
INFO - 2023-09-19 11:46:09 --> Hooks Class Initialized
DEBUG - 2023-09-19 11:46:09 --> UTF-8 Support Enabled
INFO - 2023-09-19 11:46:09 --> Utf8 Class Initialized
INFO - 2023-09-19 11:46:09 --> URI Class Initialized
INFO - 2023-09-19 11:46:09 --> Router Class Initialized
INFO - 2023-09-19 11:46:09 --> Output Class Initialized
INFO - 2023-09-19 11:46:09 --> Security Class Initialized
DEBUG - 2023-09-19 11:46:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-19 11:46:09 --> Input Class Initialized
INFO - 2023-09-19 11:46:09 --> Language Class Initialized
INFO - 2023-09-19 11:46:09 --> Loader Class Initialized
INFO - 2023-09-19 11:46:09 --> Helper loaded: url_helper
INFO - 2023-09-19 11:46:09 --> Helper loaded: file_helper
INFO - 2023-09-19 11:46:09 --> Helper loaded: html_helper
INFO - 2023-09-19 11:46:09 --> Helper loaded: text_helper
INFO - 2023-09-19 11:46:09 --> Helper loaded: form_helper
INFO - 2023-09-19 11:46:09 --> Helper loaded: lang_helper
INFO - 2023-09-19 11:46:09 --> Helper loaded: security_helper
INFO - 2023-09-19 11:46:09 --> Helper loaded: cookie_helper
INFO - 2023-09-19 11:46:09 --> Database Driver Class Initialized
INFO - 2023-09-19 11:46:09 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-19 11:46:09 --> Parser Class Initialized
INFO - 2023-09-19 11:46:09 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-19 11:46:09 --> Pagination Class Initialized
INFO - 2023-09-19 11:46:09 --> Form Validation Class Initialized
INFO - 2023-09-19 11:46:09 --> Controller Class Initialized
DEBUG - 2023-09-19 11:46:09 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-09-19 11:46:09 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-19 11:46:09 --> Model Class Initialized
INFO - 2023-09-19 11:46:09 --> Final output sent to browser
DEBUG - 2023-09-19 11:46:09 --> Total execution time: 0.0157
ERROR - 2023-09-19 11:46:18 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-19 11:46:18 --> Config Class Initialized
INFO - 2023-09-19 11:46:18 --> Hooks Class Initialized
DEBUG - 2023-09-19 11:46:18 --> UTF-8 Support Enabled
INFO - 2023-09-19 11:46:18 --> Utf8 Class Initialized
INFO - 2023-09-19 11:46:18 --> URI Class Initialized
DEBUG - 2023-09-19 11:46:18 --> No URI present. Default controller set.
INFO - 2023-09-19 11:46:18 --> Router Class Initialized
INFO - 2023-09-19 11:46:18 --> Output Class Initialized
INFO - 2023-09-19 11:46:18 --> Security Class Initialized
DEBUG - 2023-09-19 11:46:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-19 11:46:18 --> Input Class Initialized
INFO - 2023-09-19 11:46:18 --> Language Class Initialized
INFO - 2023-09-19 11:46:18 --> Loader Class Initialized
INFO - 2023-09-19 11:46:18 --> Helper loaded: url_helper
INFO - 2023-09-19 11:46:18 --> Helper loaded: file_helper
INFO - 2023-09-19 11:46:18 --> Helper loaded: html_helper
INFO - 2023-09-19 11:46:18 --> Helper loaded: text_helper
INFO - 2023-09-19 11:46:18 --> Helper loaded: form_helper
INFO - 2023-09-19 11:46:18 --> Helper loaded: lang_helper
INFO - 2023-09-19 11:46:18 --> Helper loaded: security_helper
INFO - 2023-09-19 11:46:18 --> Helper loaded: cookie_helper
INFO - 2023-09-19 11:46:18 --> Database Driver Class Initialized
INFO - 2023-09-19 11:46:18 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-19 11:46:18 --> Parser Class Initialized
INFO - 2023-09-19 11:46:18 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-19 11:46:18 --> Pagination Class Initialized
INFO - 2023-09-19 11:46:18 --> Form Validation Class Initialized
INFO - 2023-09-19 11:46:18 --> Controller Class Initialized
INFO - 2023-09-19 11:46:18 --> Model Class Initialized
DEBUG - 2023-09-19 11:46:18 --> Session class already loaded. Second attempt ignored.
ERROR - 2023-09-19 11:46:19 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-19 11:46:19 --> Config Class Initialized
INFO - 2023-09-19 11:46:19 --> Hooks Class Initialized
DEBUG - 2023-09-19 11:46:19 --> UTF-8 Support Enabled
INFO - 2023-09-19 11:46:19 --> Utf8 Class Initialized
INFO - 2023-09-19 11:46:19 --> URI Class Initialized
INFO - 2023-09-19 11:46:19 --> Router Class Initialized
INFO - 2023-09-19 11:46:19 --> Output Class Initialized
INFO - 2023-09-19 11:46:19 --> Security Class Initialized
DEBUG - 2023-09-19 11:46:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-19 11:46:19 --> Input Class Initialized
INFO - 2023-09-19 11:46:19 --> Language Class Initialized
INFO - 2023-09-19 11:46:19 --> Loader Class Initialized
INFO - 2023-09-19 11:46:19 --> Helper loaded: url_helper
INFO - 2023-09-19 11:46:19 --> Helper loaded: file_helper
INFO - 2023-09-19 11:46:19 --> Helper loaded: html_helper
INFO - 2023-09-19 11:46:19 --> Helper loaded: text_helper
INFO - 2023-09-19 11:46:19 --> Helper loaded: form_helper
INFO - 2023-09-19 11:46:19 --> Helper loaded: lang_helper
INFO - 2023-09-19 11:46:19 --> Helper loaded: security_helper
INFO - 2023-09-19 11:46:19 --> Helper loaded: cookie_helper
INFO - 2023-09-19 11:46:19 --> Database Driver Class Initialized
INFO - 2023-09-19 11:46:19 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-19 11:46:19 --> Parser Class Initialized
INFO - 2023-09-19 11:46:19 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-19 11:46:19 --> Pagination Class Initialized
INFO - 2023-09-19 11:46:19 --> Form Validation Class Initialized
INFO - 2023-09-19 11:46:19 --> Controller Class Initialized
INFO - 2023-09-19 11:46:19 --> Model Class Initialized
DEBUG - 2023-09-19 11:46:19 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-19 11:46:19 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2023-09-19 11:46:19 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-09-19 11:46:19 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-09-19 11:46:19 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-09-19 11:46:19 --> Model Class Initialized
INFO - 2023-09-19 11:46:19 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-09-19 11:46:19 --> Final output sent to browser
DEBUG - 2023-09-19 11:46:19 --> Total execution time: 0.0289
ERROR - 2023-09-19 11:46:19 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-19 11:46:19 --> Config Class Initialized
INFO - 2023-09-19 11:46:19 --> Hooks Class Initialized
DEBUG - 2023-09-19 11:46:19 --> UTF-8 Support Enabled
INFO - 2023-09-19 11:46:19 --> Utf8 Class Initialized
INFO - 2023-09-19 11:46:19 --> URI Class Initialized
INFO - 2023-09-19 11:46:19 --> Router Class Initialized
INFO - 2023-09-19 11:46:19 --> Output Class Initialized
INFO - 2023-09-19 11:46:19 --> Security Class Initialized
DEBUG - 2023-09-19 11:46:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-19 11:46:19 --> Input Class Initialized
INFO - 2023-09-19 11:46:19 --> Language Class Initialized
ERROR - 2023-09-19 11:46:19 --> 404 Page Not Found: Apple-touch-icon-152x152-precomposedpng/index
ERROR - 2023-09-19 11:46:19 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-19 11:46:19 --> Config Class Initialized
INFO - 2023-09-19 11:46:19 --> Hooks Class Initialized
DEBUG - 2023-09-19 11:46:19 --> UTF-8 Support Enabled
INFO - 2023-09-19 11:46:19 --> Utf8 Class Initialized
INFO - 2023-09-19 11:46:19 --> URI Class Initialized
INFO - 2023-09-19 11:46:19 --> Router Class Initialized
INFO - 2023-09-19 11:46:19 --> Output Class Initialized
INFO - 2023-09-19 11:46:19 --> Security Class Initialized
DEBUG - 2023-09-19 11:46:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-19 11:46:19 --> Input Class Initialized
INFO - 2023-09-19 11:46:19 --> Language Class Initialized
ERROR - 2023-09-19 11:46:19 --> 404 Page Not Found: Apple-touch-icon-152x152png/index
ERROR - 2023-09-19 11:46:20 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-19 11:46:20 --> Config Class Initialized
INFO - 2023-09-19 11:46:20 --> Hooks Class Initialized
DEBUG - 2023-09-19 11:46:20 --> UTF-8 Support Enabled
INFO - 2023-09-19 11:46:20 --> Utf8 Class Initialized
INFO - 2023-09-19 11:46:20 --> URI Class Initialized
INFO - 2023-09-19 11:46:20 --> Router Class Initialized
INFO - 2023-09-19 11:46:20 --> Output Class Initialized
INFO - 2023-09-19 11:46:20 --> Security Class Initialized
DEBUG - 2023-09-19 11:46:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-19 11:46:20 --> Input Class Initialized
INFO - 2023-09-19 11:46:20 --> Language Class Initialized
ERROR - 2023-09-19 11:46:20 --> 404 Page Not Found: Apple-touch-icon-precomposedpng/index
ERROR - 2023-09-19 11:46:20 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-19 11:46:20 --> Config Class Initialized
INFO - 2023-09-19 11:46:20 --> Hooks Class Initialized
DEBUG - 2023-09-19 11:46:20 --> UTF-8 Support Enabled
INFO - 2023-09-19 11:46:20 --> Utf8 Class Initialized
INFO - 2023-09-19 11:46:20 --> URI Class Initialized
INFO - 2023-09-19 11:46:20 --> Router Class Initialized
INFO - 2023-09-19 11:46:20 --> Output Class Initialized
INFO - 2023-09-19 11:46:20 --> Security Class Initialized
DEBUG - 2023-09-19 11:46:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-19 11:46:20 --> Input Class Initialized
INFO - 2023-09-19 11:46:20 --> Language Class Initialized
ERROR - 2023-09-19 11:46:20 --> 404 Page Not Found: Apple-touch-iconpng/index
ERROR - 2023-09-19 11:46:39 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-19 11:46:39 --> Config Class Initialized
INFO - 2023-09-19 11:46:39 --> Hooks Class Initialized
DEBUG - 2023-09-19 11:46:39 --> UTF-8 Support Enabled
INFO - 2023-09-19 11:46:39 --> Utf8 Class Initialized
INFO - 2023-09-19 11:46:39 --> URI Class Initialized
INFO - 2023-09-19 11:46:39 --> Router Class Initialized
INFO - 2023-09-19 11:46:39 --> Output Class Initialized
INFO - 2023-09-19 11:46:39 --> Security Class Initialized
DEBUG - 2023-09-19 11:46:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-19 11:46:39 --> Input Class Initialized
INFO - 2023-09-19 11:46:39 --> Language Class Initialized
INFO - 2023-09-19 11:46:39 --> Loader Class Initialized
INFO - 2023-09-19 11:46:39 --> Helper loaded: url_helper
INFO - 2023-09-19 11:46:39 --> Helper loaded: file_helper
INFO - 2023-09-19 11:46:39 --> Helper loaded: html_helper
INFO - 2023-09-19 11:46:39 --> Helper loaded: text_helper
INFO - 2023-09-19 11:46:39 --> Helper loaded: form_helper
INFO - 2023-09-19 11:46:39 --> Helper loaded: lang_helper
INFO - 2023-09-19 11:46:39 --> Helper loaded: security_helper
INFO - 2023-09-19 11:46:39 --> Helper loaded: cookie_helper
INFO - 2023-09-19 11:46:39 --> Database Driver Class Initialized
INFO - 2023-09-19 11:46:39 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-19 11:46:39 --> Parser Class Initialized
INFO - 2023-09-19 11:46:39 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-19 11:46:39 --> Pagination Class Initialized
INFO - 2023-09-19 11:46:39 --> Form Validation Class Initialized
INFO - 2023-09-19 11:46:39 --> Controller Class Initialized
INFO - 2023-09-19 11:46:39 --> Model Class Initialized
DEBUG - 2023-09-19 11:46:39 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-09-19 11:46:39 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-19 11:46:39 --> Model Class Initialized
DEBUG - 2023-09-19 11:46:39 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-19 11:46:39 --> Model Class Initialized
INFO - 2023-09-19 11:46:39 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice.php
DEBUG - 2023-09-19 11:46:39 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-09-19 11:46:39 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-09-19 11:46:39 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-09-19 11:46:39 --> Model Class Initialized
INFO - 2023-09-19 11:46:39 --> Model Class Initialized
INFO - 2023-09-19 11:46:39 --> Model Class Initialized
INFO - 2023-09-19 11:46:39 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-09-19 11:46:39 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-09-19 11:46:39 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-09-19 11:46:39 --> Final output sent to browser
DEBUG - 2023-09-19 11:46:39 --> Total execution time: 0.1436
ERROR - 2023-09-19 11:46:40 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-19 11:46:40 --> Config Class Initialized
INFO - 2023-09-19 11:46:40 --> Hooks Class Initialized
DEBUG - 2023-09-19 11:46:40 --> UTF-8 Support Enabled
INFO - 2023-09-19 11:46:40 --> Utf8 Class Initialized
INFO - 2023-09-19 11:46:40 --> URI Class Initialized
INFO - 2023-09-19 11:46:40 --> Router Class Initialized
INFO - 2023-09-19 11:46:40 --> Output Class Initialized
INFO - 2023-09-19 11:46:40 --> Security Class Initialized
DEBUG - 2023-09-19 11:46:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-19 11:46:40 --> Input Class Initialized
INFO - 2023-09-19 11:46:40 --> Language Class Initialized
INFO - 2023-09-19 11:46:40 --> Loader Class Initialized
INFO - 2023-09-19 11:46:40 --> Helper loaded: url_helper
INFO - 2023-09-19 11:46:40 --> Helper loaded: file_helper
INFO - 2023-09-19 11:46:40 --> Helper loaded: html_helper
INFO - 2023-09-19 11:46:40 --> Helper loaded: text_helper
INFO - 2023-09-19 11:46:40 --> Helper loaded: form_helper
INFO - 2023-09-19 11:46:40 --> Helper loaded: lang_helper
INFO - 2023-09-19 11:46:40 --> Helper loaded: security_helper
INFO - 2023-09-19 11:46:40 --> Helper loaded: cookie_helper
INFO - 2023-09-19 11:46:40 --> Database Driver Class Initialized
INFO - 2023-09-19 11:46:40 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-19 11:46:40 --> Parser Class Initialized
INFO - 2023-09-19 11:46:40 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-19 11:46:40 --> Pagination Class Initialized
INFO - 2023-09-19 11:46:40 --> Form Validation Class Initialized
INFO - 2023-09-19 11:46:40 --> Controller Class Initialized
INFO - 2023-09-19 11:46:40 --> Model Class Initialized
DEBUG - 2023-09-19 11:46:40 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-09-19 11:46:40 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-19 11:46:40 --> Model Class Initialized
DEBUG - 2023-09-19 11:46:40 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-19 11:46:40 --> Model Class Initialized
INFO - 2023-09-19 11:46:40 --> Final output sent to browser
DEBUG - 2023-09-19 11:46:40 --> Total execution time: 0.0548
ERROR - 2023-09-19 11:46:58 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-19 11:46:58 --> Config Class Initialized
INFO - 2023-09-19 11:46:58 --> Hooks Class Initialized
DEBUG - 2023-09-19 11:46:58 --> UTF-8 Support Enabled
INFO - 2023-09-19 11:46:58 --> Utf8 Class Initialized
INFO - 2023-09-19 11:46:58 --> URI Class Initialized
INFO - 2023-09-19 11:46:58 --> Router Class Initialized
INFO - 2023-09-19 11:46:58 --> Output Class Initialized
INFO - 2023-09-19 11:46:58 --> Security Class Initialized
DEBUG - 2023-09-19 11:46:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-19 11:46:58 --> Input Class Initialized
INFO - 2023-09-19 11:46:58 --> Language Class Initialized
INFO - 2023-09-19 11:46:58 --> Loader Class Initialized
INFO - 2023-09-19 11:46:58 --> Helper loaded: url_helper
INFO - 2023-09-19 11:46:58 --> Helper loaded: file_helper
INFO - 2023-09-19 11:46:58 --> Helper loaded: html_helper
INFO - 2023-09-19 11:46:58 --> Helper loaded: text_helper
INFO - 2023-09-19 11:46:58 --> Helper loaded: form_helper
INFO - 2023-09-19 11:46:58 --> Helper loaded: lang_helper
INFO - 2023-09-19 11:46:58 --> Helper loaded: security_helper
INFO - 2023-09-19 11:46:58 --> Helper loaded: cookie_helper
INFO - 2023-09-19 11:46:58 --> Database Driver Class Initialized
INFO - 2023-09-19 11:46:58 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-19 11:46:58 --> Parser Class Initialized
INFO - 2023-09-19 11:46:58 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-19 11:46:58 --> Pagination Class Initialized
INFO - 2023-09-19 11:46:58 --> Form Validation Class Initialized
INFO - 2023-09-19 11:46:58 --> Controller Class Initialized
INFO - 2023-09-19 11:46:58 --> Model Class Initialized
DEBUG - 2023-09-19 11:46:58 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-09-19 11:46:58 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-19 11:46:58 --> Model Class Initialized
DEBUG - 2023-09-19 11:46:58 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-19 11:46:58 --> Model Class Initialized
INFO - 2023-09-19 11:46:58 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice.php
DEBUG - 2023-09-19 11:46:58 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-09-19 11:46:58 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-09-19 11:46:58 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-09-19 11:46:58 --> Model Class Initialized
INFO - 2023-09-19 11:46:58 --> Model Class Initialized
INFO - 2023-09-19 11:46:58 --> Model Class Initialized
INFO - 2023-09-19 11:46:58 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-09-19 11:46:58 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-09-19 11:46:58 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-09-19 11:46:58 --> Final output sent to browser
DEBUG - 2023-09-19 11:46:58 --> Total execution time: 0.1491
ERROR - 2023-09-19 11:46:58 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-19 11:46:58 --> Config Class Initialized
INFO - 2023-09-19 11:46:58 --> Hooks Class Initialized
DEBUG - 2023-09-19 11:46:58 --> UTF-8 Support Enabled
INFO - 2023-09-19 11:46:58 --> Utf8 Class Initialized
INFO - 2023-09-19 11:46:58 --> URI Class Initialized
INFO - 2023-09-19 11:46:58 --> Router Class Initialized
INFO - 2023-09-19 11:46:58 --> Output Class Initialized
INFO - 2023-09-19 11:46:58 --> Security Class Initialized
DEBUG - 2023-09-19 11:46:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-19 11:46:58 --> Input Class Initialized
INFO - 2023-09-19 11:46:58 --> Language Class Initialized
INFO - 2023-09-19 11:46:58 --> Loader Class Initialized
INFO - 2023-09-19 11:46:58 --> Helper loaded: url_helper
INFO - 2023-09-19 11:46:58 --> Helper loaded: file_helper
INFO - 2023-09-19 11:46:58 --> Helper loaded: html_helper
INFO - 2023-09-19 11:46:58 --> Helper loaded: text_helper
INFO - 2023-09-19 11:46:58 --> Helper loaded: form_helper
INFO - 2023-09-19 11:46:58 --> Helper loaded: lang_helper
INFO - 2023-09-19 11:46:58 --> Helper loaded: security_helper
INFO - 2023-09-19 11:46:58 --> Helper loaded: cookie_helper
INFO - 2023-09-19 11:46:58 --> Database Driver Class Initialized
INFO - 2023-09-19 11:46:58 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-19 11:46:58 --> Parser Class Initialized
INFO - 2023-09-19 11:46:58 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-19 11:46:58 --> Pagination Class Initialized
INFO - 2023-09-19 11:46:58 --> Form Validation Class Initialized
INFO - 2023-09-19 11:46:58 --> Controller Class Initialized
INFO - 2023-09-19 11:46:58 --> Model Class Initialized
DEBUG - 2023-09-19 11:46:58 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-09-19 11:46:58 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-19 11:46:58 --> Model Class Initialized
DEBUG - 2023-09-19 11:46:58 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-19 11:46:58 --> Model Class Initialized
INFO - 2023-09-19 11:46:58 --> Final output sent to browser
DEBUG - 2023-09-19 11:46:58 --> Total execution time: 0.0617
ERROR - 2023-09-19 11:47:36 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-19 11:47:36 --> Config Class Initialized
INFO - 2023-09-19 11:47:36 --> Hooks Class Initialized
DEBUG - 2023-09-19 11:47:36 --> UTF-8 Support Enabled
INFO - 2023-09-19 11:47:36 --> Utf8 Class Initialized
INFO - 2023-09-19 11:47:36 --> URI Class Initialized
DEBUG - 2023-09-19 11:47:36 --> No URI present. Default controller set.
INFO - 2023-09-19 11:47:36 --> Router Class Initialized
INFO - 2023-09-19 11:47:36 --> Output Class Initialized
INFO - 2023-09-19 11:47:36 --> Security Class Initialized
DEBUG - 2023-09-19 11:47:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-19 11:47:36 --> Input Class Initialized
INFO - 2023-09-19 11:47:36 --> Language Class Initialized
INFO - 2023-09-19 11:47:36 --> Loader Class Initialized
INFO - 2023-09-19 11:47:36 --> Helper loaded: url_helper
INFO - 2023-09-19 11:47:36 --> Helper loaded: file_helper
INFO - 2023-09-19 11:47:36 --> Helper loaded: html_helper
INFO - 2023-09-19 11:47:36 --> Helper loaded: text_helper
INFO - 2023-09-19 11:47:36 --> Helper loaded: form_helper
INFO - 2023-09-19 11:47:36 --> Helper loaded: lang_helper
INFO - 2023-09-19 11:47:36 --> Helper loaded: security_helper
INFO - 2023-09-19 11:47:36 --> Helper loaded: cookie_helper
INFO - 2023-09-19 11:47:36 --> Database Driver Class Initialized
INFO - 2023-09-19 11:47:36 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-19 11:47:36 --> Parser Class Initialized
INFO - 2023-09-19 11:47:36 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-19 11:47:36 --> Pagination Class Initialized
INFO - 2023-09-19 11:47:36 --> Form Validation Class Initialized
INFO - 2023-09-19 11:47:36 --> Controller Class Initialized
INFO - 2023-09-19 11:47:36 --> Model Class Initialized
DEBUG - 2023-09-19 11:47:36 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-19 11:47:36 --> Model Class Initialized
DEBUG - 2023-09-19 11:47:36 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-19 11:47:36 --> Model Class Initialized
INFO - 2023-09-19 11:47:36 --> Model Class Initialized
INFO - 2023-09-19 11:47:36 --> Model Class Initialized
INFO - 2023-09-19 11:47:36 --> Model Class Initialized
DEBUG - 2023-09-19 11:47:36 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-09-19 11:47:36 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-19 11:47:36 --> Model Class Initialized
INFO - 2023-09-19 11:47:36 --> Model Class Initialized
INFO - 2023-09-19 11:47:36 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-09-19 11:47:36 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-09-19 11:47:36 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-09-19 11:47:36 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-09-19 11:47:36 --> Model Class Initialized
INFO - 2023-09-19 11:47:36 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-09-19 11:47:36 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-09-19 11:47:36 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-09-19 11:47:36 --> Final output sent to browser
DEBUG - 2023-09-19 11:47:36 --> Total execution time: 0.2015
ERROR - 2023-09-19 11:49:40 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-19 11:49:40 --> Config Class Initialized
INFO - 2023-09-19 11:49:40 --> Hooks Class Initialized
DEBUG - 2023-09-19 11:49:40 --> UTF-8 Support Enabled
INFO - 2023-09-19 11:49:40 --> Utf8 Class Initialized
INFO - 2023-09-19 11:49:40 --> URI Class Initialized
INFO - 2023-09-19 11:49:40 --> Router Class Initialized
INFO - 2023-09-19 11:49:40 --> Output Class Initialized
INFO - 2023-09-19 11:49:40 --> Security Class Initialized
DEBUG - 2023-09-19 11:49:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-19 11:49:40 --> Input Class Initialized
INFO - 2023-09-19 11:49:40 --> Language Class Initialized
INFO - 2023-09-19 11:49:40 --> Loader Class Initialized
INFO - 2023-09-19 11:49:40 --> Helper loaded: url_helper
INFO - 2023-09-19 11:49:40 --> Helper loaded: file_helper
INFO - 2023-09-19 11:49:40 --> Helper loaded: html_helper
INFO - 2023-09-19 11:49:40 --> Helper loaded: text_helper
INFO - 2023-09-19 11:49:40 --> Helper loaded: form_helper
INFO - 2023-09-19 11:49:40 --> Helper loaded: lang_helper
INFO - 2023-09-19 11:49:40 --> Helper loaded: security_helper
INFO - 2023-09-19 11:49:40 --> Helper loaded: cookie_helper
INFO - 2023-09-19 11:49:40 --> Database Driver Class Initialized
INFO - 2023-09-19 11:49:40 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-19 11:49:40 --> Parser Class Initialized
INFO - 2023-09-19 11:49:40 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-19 11:49:40 --> Pagination Class Initialized
INFO - 2023-09-19 11:49:40 --> Form Validation Class Initialized
INFO - 2023-09-19 11:49:40 --> Controller Class Initialized
INFO - 2023-09-19 11:49:40 --> Model Class Initialized
DEBUG - 2023-09-19 11:49:40 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-09-19 11:49:40 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-19 11:49:40 --> Model Class Initialized
DEBUG - 2023-09-19 11:49:40 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-19 11:49:40 --> Model Class Initialized
INFO - 2023-09-19 11:49:40 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice.php
DEBUG - 2023-09-19 11:49:40 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-09-19 11:49:40 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-09-19 11:49:40 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-09-19 11:49:40 --> Model Class Initialized
INFO - 2023-09-19 11:49:40 --> Model Class Initialized
INFO - 2023-09-19 11:49:40 --> Model Class Initialized
INFO - 2023-09-19 11:49:40 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-09-19 11:49:40 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-09-19 11:49:40 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-09-19 11:49:40 --> Final output sent to browser
DEBUG - 2023-09-19 11:49:40 --> Total execution time: 0.1476
ERROR - 2023-09-19 11:49:41 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-19 11:49:41 --> Config Class Initialized
INFO - 2023-09-19 11:49:41 --> Hooks Class Initialized
DEBUG - 2023-09-19 11:49:41 --> UTF-8 Support Enabled
INFO - 2023-09-19 11:49:41 --> Utf8 Class Initialized
INFO - 2023-09-19 11:49:41 --> URI Class Initialized
INFO - 2023-09-19 11:49:41 --> Router Class Initialized
INFO - 2023-09-19 11:49:41 --> Output Class Initialized
INFO - 2023-09-19 11:49:41 --> Security Class Initialized
DEBUG - 2023-09-19 11:49:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-19 11:49:41 --> Input Class Initialized
INFO - 2023-09-19 11:49:41 --> Language Class Initialized
INFO - 2023-09-19 11:49:41 --> Loader Class Initialized
INFO - 2023-09-19 11:49:41 --> Helper loaded: url_helper
INFO - 2023-09-19 11:49:41 --> Helper loaded: file_helper
INFO - 2023-09-19 11:49:41 --> Helper loaded: html_helper
INFO - 2023-09-19 11:49:41 --> Helper loaded: text_helper
INFO - 2023-09-19 11:49:41 --> Helper loaded: form_helper
INFO - 2023-09-19 11:49:41 --> Helper loaded: lang_helper
INFO - 2023-09-19 11:49:41 --> Helper loaded: security_helper
INFO - 2023-09-19 11:49:41 --> Helper loaded: cookie_helper
INFO - 2023-09-19 11:49:41 --> Database Driver Class Initialized
INFO - 2023-09-19 11:49:41 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-19 11:49:41 --> Parser Class Initialized
INFO - 2023-09-19 11:49:41 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-19 11:49:41 --> Pagination Class Initialized
INFO - 2023-09-19 11:49:41 --> Form Validation Class Initialized
INFO - 2023-09-19 11:49:41 --> Controller Class Initialized
INFO - 2023-09-19 11:49:41 --> Model Class Initialized
DEBUG - 2023-09-19 11:49:41 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-09-19 11:49:41 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-19 11:49:41 --> Model Class Initialized
DEBUG - 2023-09-19 11:49:41 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-19 11:49:41 --> Model Class Initialized
INFO - 2023-09-19 11:49:41 --> Final output sent to browser
DEBUG - 2023-09-19 11:49:41 --> Total execution time: 0.0552
ERROR - 2023-09-19 11:49:43 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-19 11:49:43 --> Config Class Initialized
INFO - 2023-09-19 11:49:43 --> Hooks Class Initialized
DEBUG - 2023-09-19 11:49:43 --> UTF-8 Support Enabled
INFO - 2023-09-19 11:49:43 --> Utf8 Class Initialized
INFO - 2023-09-19 11:49:43 --> URI Class Initialized
DEBUG - 2023-09-19 11:49:43 --> No URI present. Default controller set.
INFO - 2023-09-19 11:49:43 --> Router Class Initialized
INFO - 2023-09-19 11:49:43 --> Output Class Initialized
INFO - 2023-09-19 11:49:43 --> Security Class Initialized
DEBUG - 2023-09-19 11:49:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-19 11:49:43 --> Input Class Initialized
INFO - 2023-09-19 11:49:43 --> Language Class Initialized
INFO - 2023-09-19 11:49:43 --> Loader Class Initialized
INFO - 2023-09-19 11:49:43 --> Helper loaded: url_helper
INFO - 2023-09-19 11:49:43 --> Helper loaded: file_helper
INFO - 2023-09-19 11:49:43 --> Helper loaded: html_helper
INFO - 2023-09-19 11:49:43 --> Helper loaded: text_helper
INFO - 2023-09-19 11:49:43 --> Helper loaded: form_helper
INFO - 2023-09-19 11:49:43 --> Helper loaded: lang_helper
INFO - 2023-09-19 11:49:43 --> Helper loaded: security_helper
INFO - 2023-09-19 11:49:43 --> Helper loaded: cookie_helper
INFO - 2023-09-19 11:49:43 --> Database Driver Class Initialized
INFO - 2023-09-19 11:49:43 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-19 11:49:43 --> Parser Class Initialized
INFO - 2023-09-19 11:49:43 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-19 11:49:43 --> Pagination Class Initialized
INFO - 2023-09-19 11:49:43 --> Form Validation Class Initialized
INFO - 2023-09-19 11:49:43 --> Controller Class Initialized
INFO - 2023-09-19 11:49:43 --> Model Class Initialized
DEBUG - 2023-09-19 11:49:43 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-19 11:49:43 --> Model Class Initialized
DEBUG - 2023-09-19 11:49:43 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-19 11:49:43 --> Model Class Initialized
INFO - 2023-09-19 11:49:43 --> Model Class Initialized
INFO - 2023-09-19 11:49:43 --> Model Class Initialized
INFO - 2023-09-19 11:49:43 --> Model Class Initialized
DEBUG - 2023-09-19 11:49:43 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-09-19 11:49:43 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-19 11:49:43 --> Model Class Initialized
INFO - 2023-09-19 11:49:43 --> Model Class Initialized
INFO - 2023-09-19 11:49:43 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-09-19 11:49:43 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-09-19 11:49:43 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-09-19 11:49:43 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-09-19 11:49:43 --> Model Class Initialized
INFO - 2023-09-19 11:49:43 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-09-19 11:49:43 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-09-19 11:49:43 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-09-19 11:49:43 --> Final output sent to browser
DEBUG - 2023-09-19 11:49:43 --> Total execution time: 0.1963
ERROR - 2023-09-19 11:50:53 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-19 11:50:53 --> Config Class Initialized
INFO - 2023-09-19 11:50:53 --> Hooks Class Initialized
DEBUG - 2023-09-19 11:50:53 --> UTF-8 Support Enabled
INFO - 2023-09-19 11:50:53 --> Utf8 Class Initialized
INFO - 2023-09-19 11:50:53 --> URI Class Initialized
INFO - 2023-09-19 11:50:53 --> Router Class Initialized
INFO - 2023-09-19 11:50:53 --> Output Class Initialized
INFO - 2023-09-19 11:50:53 --> Security Class Initialized
DEBUG - 2023-09-19 11:50:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-19 11:50:53 --> Input Class Initialized
INFO - 2023-09-19 11:50:53 --> Language Class Initialized
INFO - 2023-09-19 11:50:53 --> Loader Class Initialized
INFO - 2023-09-19 11:50:53 --> Helper loaded: url_helper
INFO - 2023-09-19 11:50:53 --> Helper loaded: file_helper
INFO - 2023-09-19 11:50:53 --> Helper loaded: html_helper
INFO - 2023-09-19 11:50:53 --> Helper loaded: text_helper
INFO - 2023-09-19 11:50:53 --> Helper loaded: form_helper
INFO - 2023-09-19 11:50:53 --> Helper loaded: lang_helper
INFO - 2023-09-19 11:50:53 --> Helper loaded: security_helper
INFO - 2023-09-19 11:50:53 --> Helper loaded: cookie_helper
INFO - 2023-09-19 11:50:53 --> Database Driver Class Initialized
INFO - 2023-09-19 11:50:53 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-19 11:50:53 --> Parser Class Initialized
INFO - 2023-09-19 11:50:53 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-19 11:50:53 --> Pagination Class Initialized
INFO - 2023-09-19 11:50:53 --> Form Validation Class Initialized
INFO - 2023-09-19 11:50:53 --> Controller Class Initialized
INFO - 2023-09-19 11:50:53 --> Model Class Initialized
DEBUG - 2023-09-19 11:50:53 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-09-19 11:50:53 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-19 11:50:53 --> Model Class Initialized
DEBUG - 2023-09-19 11:50:53 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-19 11:50:53 --> Model Class Initialized
INFO - 2023-09-19 11:50:53 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/add_invoice_form.php
DEBUG - 2023-09-19 11:50:53 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-09-19 11:50:53 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-09-19 11:50:53 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-09-19 11:50:53 --> Model Class Initialized
INFO - 2023-09-19 11:50:53 --> Model Class Initialized
INFO - 2023-09-19 11:50:53 --> Model Class Initialized
INFO - 2023-09-19 11:50:53 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-09-19 11:50:53 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-09-19 11:50:53 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-09-19 11:50:53 --> Final output sent to browser
DEBUG - 2023-09-19 11:50:53 --> Total execution time: 0.1653
ERROR - 2023-09-19 11:58:16 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-19 11:58:16 --> Config Class Initialized
INFO - 2023-09-19 11:58:16 --> Hooks Class Initialized
DEBUG - 2023-09-19 11:58:16 --> UTF-8 Support Enabled
INFO - 2023-09-19 11:58:16 --> Utf8 Class Initialized
INFO - 2023-09-19 11:58:16 --> URI Class Initialized
DEBUG - 2023-09-19 11:58:16 --> No URI present. Default controller set.
INFO - 2023-09-19 11:58:16 --> Router Class Initialized
INFO - 2023-09-19 11:58:16 --> Output Class Initialized
INFO - 2023-09-19 11:58:16 --> Security Class Initialized
DEBUG - 2023-09-19 11:58:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-19 11:58:16 --> Input Class Initialized
INFO - 2023-09-19 11:58:16 --> Language Class Initialized
INFO - 2023-09-19 11:58:16 --> Loader Class Initialized
INFO - 2023-09-19 11:58:16 --> Helper loaded: url_helper
INFO - 2023-09-19 11:58:16 --> Helper loaded: file_helper
INFO - 2023-09-19 11:58:16 --> Helper loaded: html_helper
INFO - 2023-09-19 11:58:16 --> Helper loaded: text_helper
INFO - 2023-09-19 11:58:16 --> Helper loaded: form_helper
INFO - 2023-09-19 11:58:16 --> Helper loaded: lang_helper
INFO - 2023-09-19 11:58:16 --> Helper loaded: security_helper
INFO - 2023-09-19 11:58:16 --> Helper loaded: cookie_helper
INFO - 2023-09-19 11:58:16 --> Database Driver Class Initialized
INFO - 2023-09-19 11:58:16 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-19 11:58:16 --> Parser Class Initialized
INFO - 2023-09-19 11:58:16 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-19 11:58:16 --> Pagination Class Initialized
INFO - 2023-09-19 11:58:16 --> Form Validation Class Initialized
INFO - 2023-09-19 11:58:16 --> Controller Class Initialized
INFO - 2023-09-19 11:58:16 --> Model Class Initialized
DEBUG - 2023-09-19 11:58:16 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-19 11:58:16 --> Model Class Initialized
DEBUG - 2023-09-19 11:58:16 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-19 11:58:16 --> Model Class Initialized
INFO - 2023-09-19 11:58:16 --> Model Class Initialized
INFO - 2023-09-19 11:58:16 --> Model Class Initialized
INFO - 2023-09-19 11:58:16 --> Model Class Initialized
DEBUG - 2023-09-19 11:58:16 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-09-19 11:58:16 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-19 11:58:16 --> Model Class Initialized
INFO - 2023-09-19 11:58:16 --> Model Class Initialized
INFO - 2023-09-19 11:58:16 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-09-19 11:58:16 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-09-19 11:58:16 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-09-19 11:58:16 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-09-19 11:58:16 --> Model Class Initialized
INFO - 2023-09-19 11:58:16 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-09-19 11:58:16 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-09-19 11:58:16 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-09-19 11:58:16 --> Final output sent to browser
DEBUG - 2023-09-19 11:58:16 --> Total execution time: 0.2305
ERROR - 2023-09-19 15:03:09 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-19 15:03:09 --> Config Class Initialized
INFO - 2023-09-19 15:03:09 --> Hooks Class Initialized
DEBUG - 2023-09-19 15:03:09 --> UTF-8 Support Enabled
INFO - 2023-09-19 15:03:09 --> Utf8 Class Initialized
INFO - 2023-09-19 15:03:09 --> URI Class Initialized
DEBUG - 2023-09-19 15:03:09 --> No URI present. Default controller set.
INFO - 2023-09-19 15:03:09 --> Router Class Initialized
INFO - 2023-09-19 15:03:09 --> Output Class Initialized
INFO - 2023-09-19 15:03:09 --> Security Class Initialized
DEBUG - 2023-09-19 15:03:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-19 15:03:09 --> Input Class Initialized
INFO - 2023-09-19 15:03:09 --> Language Class Initialized
INFO - 2023-09-19 15:03:09 --> Loader Class Initialized
INFO - 2023-09-19 15:03:09 --> Helper loaded: url_helper
INFO - 2023-09-19 15:03:09 --> Helper loaded: file_helper
INFO - 2023-09-19 15:03:09 --> Helper loaded: html_helper
INFO - 2023-09-19 15:03:09 --> Helper loaded: text_helper
INFO - 2023-09-19 15:03:09 --> Helper loaded: form_helper
INFO - 2023-09-19 15:03:09 --> Helper loaded: lang_helper
INFO - 2023-09-19 15:03:09 --> Helper loaded: security_helper
INFO - 2023-09-19 15:03:09 --> Helper loaded: cookie_helper
INFO - 2023-09-19 15:03:09 --> Database Driver Class Initialized
INFO - 2023-09-19 15:03:09 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-19 15:03:09 --> Parser Class Initialized
INFO - 2023-09-19 15:03:09 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-19 15:03:09 --> Pagination Class Initialized
INFO - 2023-09-19 15:03:09 --> Form Validation Class Initialized
INFO - 2023-09-19 15:03:09 --> Controller Class Initialized
INFO - 2023-09-19 15:03:09 --> Model Class Initialized
DEBUG - 2023-09-19 15:03:09 --> Session class already loaded. Second attempt ignored.
ERROR - 2023-09-19 15:03:09 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-19 15:03:09 --> Config Class Initialized
INFO - 2023-09-19 15:03:09 --> Hooks Class Initialized
DEBUG - 2023-09-19 15:03:09 --> UTF-8 Support Enabled
INFO - 2023-09-19 15:03:09 --> Utf8 Class Initialized
INFO - 2023-09-19 15:03:09 --> URI Class Initialized
INFO - 2023-09-19 15:03:09 --> Router Class Initialized
INFO - 2023-09-19 15:03:09 --> Output Class Initialized
INFO - 2023-09-19 15:03:09 --> Security Class Initialized
DEBUG - 2023-09-19 15:03:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-19 15:03:09 --> Input Class Initialized
INFO - 2023-09-19 15:03:09 --> Language Class Initialized
INFO - 2023-09-19 15:03:09 --> Loader Class Initialized
INFO - 2023-09-19 15:03:09 --> Helper loaded: url_helper
INFO - 2023-09-19 15:03:09 --> Helper loaded: file_helper
INFO - 2023-09-19 15:03:09 --> Helper loaded: html_helper
INFO - 2023-09-19 15:03:09 --> Helper loaded: text_helper
INFO - 2023-09-19 15:03:09 --> Helper loaded: form_helper
INFO - 2023-09-19 15:03:09 --> Helper loaded: lang_helper
INFO - 2023-09-19 15:03:09 --> Helper loaded: security_helper
INFO - 2023-09-19 15:03:09 --> Helper loaded: cookie_helper
INFO - 2023-09-19 15:03:09 --> Database Driver Class Initialized
INFO - 2023-09-19 15:03:09 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-19 15:03:09 --> Parser Class Initialized
INFO - 2023-09-19 15:03:09 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-19 15:03:09 --> Pagination Class Initialized
INFO - 2023-09-19 15:03:09 --> Form Validation Class Initialized
INFO - 2023-09-19 15:03:09 --> Controller Class Initialized
INFO - 2023-09-19 15:03:09 --> Model Class Initialized
DEBUG - 2023-09-19 15:03:09 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-19 15:03:09 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2023-09-19 15:03:09 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-09-19 15:03:09 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-09-19 15:03:09 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-09-19 15:03:09 --> Model Class Initialized
INFO - 2023-09-19 15:03:09 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-09-19 15:03:09 --> Final output sent to browser
DEBUG - 2023-09-19 15:03:09 --> Total execution time: 0.0321
ERROR - 2023-09-19 15:03:13 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-19 15:03:13 --> Config Class Initialized
INFO - 2023-09-19 15:03:13 --> Hooks Class Initialized
DEBUG - 2023-09-19 15:03:13 --> UTF-8 Support Enabled
INFO - 2023-09-19 15:03:13 --> Utf8 Class Initialized
INFO - 2023-09-19 15:03:13 --> URI Class Initialized
INFO - 2023-09-19 15:03:13 --> Router Class Initialized
INFO - 2023-09-19 15:03:13 --> Output Class Initialized
INFO - 2023-09-19 15:03:13 --> Security Class Initialized
DEBUG - 2023-09-19 15:03:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-19 15:03:13 --> Input Class Initialized
INFO - 2023-09-19 15:03:13 --> Language Class Initialized
INFO - 2023-09-19 15:03:13 --> Loader Class Initialized
INFO - 2023-09-19 15:03:13 --> Helper loaded: url_helper
INFO - 2023-09-19 15:03:13 --> Helper loaded: file_helper
INFO - 2023-09-19 15:03:13 --> Helper loaded: html_helper
INFO - 2023-09-19 15:03:13 --> Helper loaded: text_helper
INFO - 2023-09-19 15:03:13 --> Helper loaded: form_helper
INFO - 2023-09-19 15:03:13 --> Helper loaded: lang_helper
INFO - 2023-09-19 15:03:13 --> Helper loaded: security_helper
INFO - 2023-09-19 15:03:13 --> Helper loaded: cookie_helper
INFO - 2023-09-19 15:03:13 --> Database Driver Class Initialized
INFO - 2023-09-19 15:03:13 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-19 15:03:13 --> Parser Class Initialized
INFO - 2023-09-19 15:03:13 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-19 15:03:13 --> Pagination Class Initialized
INFO - 2023-09-19 15:03:13 --> Form Validation Class Initialized
INFO - 2023-09-19 15:03:13 --> Controller Class Initialized
INFO - 2023-09-19 15:03:13 --> Model Class Initialized
DEBUG - 2023-09-19 15:03:13 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-19 15:03:13 --> Model Class Initialized
INFO - 2023-09-19 15:03:13 --> Final output sent to browser
DEBUG - 2023-09-19 15:03:13 --> Total execution time: 0.0183
ERROR - 2023-09-19 15:03:13 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-19 15:03:13 --> Config Class Initialized
INFO - 2023-09-19 15:03:13 --> Hooks Class Initialized
DEBUG - 2023-09-19 15:03:13 --> UTF-8 Support Enabled
INFO - 2023-09-19 15:03:13 --> Utf8 Class Initialized
INFO - 2023-09-19 15:03:13 --> URI Class Initialized
DEBUG - 2023-09-19 15:03:13 --> No URI present. Default controller set.
INFO - 2023-09-19 15:03:13 --> Router Class Initialized
INFO - 2023-09-19 15:03:13 --> Output Class Initialized
INFO - 2023-09-19 15:03:13 --> Security Class Initialized
DEBUG - 2023-09-19 15:03:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-19 15:03:13 --> Input Class Initialized
INFO - 2023-09-19 15:03:13 --> Language Class Initialized
INFO - 2023-09-19 15:03:13 --> Loader Class Initialized
INFO - 2023-09-19 15:03:13 --> Helper loaded: url_helper
INFO - 2023-09-19 15:03:13 --> Helper loaded: file_helper
INFO - 2023-09-19 15:03:13 --> Helper loaded: html_helper
INFO - 2023-09-19 15:03:13 --> Helper loaded: text_helper
INFO - 2023-09-19 15:03:13 --> Helper loaded: form_helper
INFO - 2023-09-19 15:03:13 --> Helper loaded: lang_helper
INFO - 2023-09-19 15:03:13 --> Helper loaded: security_helper
INFO - 2023-09-19 15:03:13 --> Helper loaded: cookie_helper
INFO - 2023-09-19 15:03:13 --> Database Driver Class Initialized
INFO - 2023-09-19 15:03:13 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-19 15:03:13 --> Parser Class Initialized
INFO - 2023-09-19 15:03:13 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-19 15:03:13 --> Pagination Class Initialized
INFO - 2023-09-19 15:03:13 --> Form Validation Class Initialized
INFO - 2023-09-19 15:03:13 --> Controller Class Initialized
INFO - 2023-09-19 15:03:13 --> Model Class Initialized
DEBUG - 2023-09-19 15:03:13 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-19 15:03:13 --> Model Class Initialized
DEBUG - 2023-09-19 15:03:13 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-19 15:03:13 --> Model Class Initialized
INFO - 2023-09-19 15:03:13 --> Model Class Initialized
INFO - 2023-09-19 15:03:13 --> Model Class Initialized
INFO - 2023-09-19 15:03:13 --> Model Class Initialized
DEBUG - 2023-09-19 15:03:13 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-09-19 15:03:13 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-19 15:03:13 --> Model Class Initialized
INFO - 2023-09-19 15:03:13 --> Model Class Initialized
INFO - 2023-09-19 15:03:13 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-09-19 15:03:13 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-09-19 15:03:13 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-09-19 15:03:13 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-09-19 15:03:13 --> Model Class Initialized
INFO - 2023-09-19 15:03:13 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-09-19 15:03:13 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-09-19 15:03:13 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-09-19 15:03:13 --> Final output sent to browser
DEBUG - 2023-09-19 15:03:13 --> Total execution time: 0.2233
ERROR - 2023-09-19 15:03:14 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-19 15:03:14 --> Config Class Initialized
INFO - 2023-09-19 15:03:14 --> Hooks Class Initialized
DEBUG - 2023-09-19 15:03:14 --> UTF-8 Support Enabled
INFO - 2023-09-19 15:03:14 --> Utf8 Class Initialized
INFO - 2023-09-19 15:03:14 --> URI Class Initialized
INFO - 2023-09-19 15:03:14 --> Router Class Initialized
INFO - 2023-09-19 15:03:14 --> Output Class Initialized
INFO - 2023-09-19 15:03:14 --> Security Class Initialized
DEBUG - 2023-09-19 15:03:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-19 15:03:14 --> Input Class Initialized
INFO - 2023-09-19 15:03:14 --> Language Class Initialized
INFO - 2023-09-19 15:03:14 --> Loader Class Initialized
INFO - 2023-09-19 15:03:14 --> Helper loaded: url_helper
INFO - 2023-09-19 15:03:14 --> Helper loaded: file_helper
INFO - 2023-09-19 15:03:14 --> Helper loaded: html_helper
INFO - 2023-09-19 15:03:14 --> Helper loaded: text_helper
INFO - 2023-09-19 15:03:14 --> Helper loaded: form_helper
INFO - 2023-09-19 15:03:14 --> Helper loaded: lang_helper
INFO - 2023-09-19 15:03:14 --> Helper loaded: security_helper
INFO - 2023-09-19 15:03:14 --> Helper loaded: cookie_helper
INFO - 2023-09-19 15:03:14 --> Database Driver Class Initialized
INFO - 2023-09-19 15:03:14 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-19 15:03:14 --> Parser Class Initialized
INFO - 2023-09-19 15:03:14 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-19 15:03:14 --> Pagination Class Initialized
INFO - 2023-09-19 15:03:14 --> Form Validation Class Initialized
INFO - 2023-09-19 15:03:14 --> Controller Class Initialized
DEBUG - 2023-09-19 15:03:14 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-09-19 15:03:14 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-19 15:03:14 --> Model Class Initialized
INFO - 2023-09-19 15:03:14 --> Final output sent to browser
DEBUG - 2023-09-19 15:03:14 --> Total execution time: 0.0126
ERROR - 2023-09-19 15:03:29 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-19 15:03:29 --> Config Class Initialized
INFO - 2023-09-19 15:03:29 --> Hooks Class Initialized
DEBUG - 2023-09-19 15:03:29 --> UTF-8 Support Enabled
INFO - 2023-09-19 15:03:29 --> Utf8 Class Initialized
INFO - 2023-09-19 15:03:29 --> URI Class Initialized
DEBUG - 2023-09-19 15:03:29 --> No URI present. Default controller set.
INFO - 2023-09-19 15:03:29 --> Router Class Initialized
INFO - 2023-09-19 15:03:29 --> Output Class Initialized
INFO - 2023-09-19 15:03:29 --> Security Class Initialized
DEBUG - 2023-09-19 15:03:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-19 15:03:29 --> Input Class Initialized
INFO - 2023-09-19 15:03:29 --> Language Class Initialized
INFO - 2023-09-19 15:03:29 --> Loader Class Initialized
INFO - 2023-09-19 15:03:29 --> Helper loaded: url_helper
INFO - 2023-09-19 15:03:29 --> Helper loaded: file_helper
INFO - 2023-09-19 15:03:29 --> Helper loaded: html_helper
INFO - 2023-09-19 15:03:29 --> Helper loaded: text_helper
INFO - 2023-09-19 15:03:29 --> Helper loaded: form_helper
INFO - 2023-09-19 15:03:29 --> Helper loaded: lang_helper
INFO - 2023-09-19 15:03:29 --> Helper loaded: security_helper
INFO - 2023-09-19 15:03:29 --> Helper loaded: cookie_helper
INFO - 2023-09-19 15:03:29 --> Database Driver Class Initialized
INFO - 2023-09-19 15:03:29 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-19 15:03:29 --> Parser Class Initialized
INFO - 2023-09-19 15:03:29 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-19 15:03:29 --> Pagination Class Initialized
INFO - 2023-09-19 15:03:29 --> Form Validation Class Initialized
INFO - 2023-09-19 15:03:29 --> Controller Class Initialized
INFO - 2023-09-19 15:03:29 --> Model Class Initialized
DEBUG - 2023-09-19 15:03:29 --> Session class already loaded. Second attempt ignored.
ERROR - 2023-09-19 15:03:30 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-19 15:03:30 --> Config Class Initialized
INFO - 2023-09-19 15:03:30 --> Hooks Class Initialized
DEBUG - 2023-09-19 15:03:30 --> UTF-8 Support Enabled
INFO - 2023-09-19 15:03:30 --> Utf8 Class Initialized
INFO - 2023-09-19 15:03:30 --> URI Class Initialized
INFO - 2023-09-19 15:03:30 --> Router Class Initialized
INFO - 2023-09-19 15:03:30 --> Output Class Initialized
INFO - 2023-09-19 15:03:30 --> Security Class Initialized
DEBUG - 2023-09-19 15:03:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-19 15:03:30 --> Input Class Initialized
INFO - 2023-09-19 15:03:30 --> Language Class Initialized
INFO - 2023-09-19 15:03:30 --> Loader Class Initialized
INFO - 2023-09-19 15:03:30 --> Helper loaded: url_helper
INFO - 2023-09-19 15:03:30 --> Helper loaded: file_helper
INFO - 2023-09-19 15:03:30 --> Helper loaded: html_helper
INFO - 2023-09-19 15:03:30 --> Helper loaded: text_helper
INFO - 2023-09-19 15:03:30 --> Helper loaded: form_helper
INFO - 2023-09-19 15:03:30 --> Helper loaded: lang_helper
INFO - 2023-09-19 15:03:30 --> Helper loaded: security_helper
INFO - 2023-09-19 15:03:30 --> Helper loaded: cookie_helper
INFO - 2023-09-19 15:03:30 --> Database Driver Class Initialized
INFO - 2023-09-19 15:03:30 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-19 15:03:30 --> Parser Class Initialized
INFO - 2023-09-19 15:03:30 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-19 15:03:30 --> Pagination Class Initialized
INFO - 2023-09-19 15:03:30 --> Form Validation Class Initialized
INFO - 2023-09-19 15:03:30 --> Controller Class Initialized
INFO - 2023-09-19 15:03:30 --> Model Class Initialized
DEBUG - 2023-09-19 15:03:30 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-19 15:03:30 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2023-09-19 15:03:30 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-09-19 15:03:30 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-09-19 15:03:30 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-09-19 15:03:30 --> Model Class Initialized
INFO - 2023-09-19 15:03:30 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-09-19 15:03:30 --> Final output sent to browser
DEBUG - 2023-09-19 15:03:30 --> Total execution time: 0.0292
ERROR - 2023-09-19 15:03:30 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-19 15:03:30 --> Config Class Initialized
INFO - 2023-09-19 15:03:30 --> Hooks Class Initialized
DEBUG - 2023-09-19 15:03:30 --> UTF-8 Support Enabled
INFO - 2023-09-19 15:03:30 --> Utf8 Class Initialized
INFO - 2023-09-19 15:03:30 --> URI Class Initialized
INFO - 2023-09-19 15:03:30 --> Router Class Initialized
INFO - 2023-09-19 15:03:30 --> Output Class Initialized
INFO - 2023-09-19 15:03:30 --> Security Class Initialized
DEBUG - 2023-09-19 15:03:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-19 15:03:30 --> Input Class Initialized
INFO - 2023-09-19 15:03:30 --> Language Class Initialized
ERROR - 2023-09-19 15:03:30 --> 404 Page Not Found: Apple-touch-icon-precomposedpng/index
ERROR - 2023-09-19 15:03:31 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-19 15:03:31 --> Config Class Initialized
INFO - 2023-09-19 15:03:31 --> Hooks Class Initialized
DEBUG - 2023-09-19 15:03:31 --> UTF-8 Support Enabled
INFO - 2023-09-19 15:03:31 --> Utf8 Class Initialized
INFO - 2023-09-19 15:03:31 --> URI Class Initialized
INFO - 2023-09-19 15:03:31 --> Router Class Initialized
INFO - 2023-09-19 15:03:31 --> Output Class Initialized
INFO - 2023-09-19 15:03:31 --> Security Class Initialized
DEBUG - 2023-09-19 15:03:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-19 15:03:31 --> Input Class Initialized
INFO - 2023-09-19 15:03:31 --> Language Class Initialized
ERROR - 2023-09-19 15:03:31 --> 404 Page Not Found: Apple-touch-iconpng/index
ERROR - 2023-09-19 15:03:35 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-19 15:03:35 --> Config Class Initialized
INFO - 2023-09-19 15:03:35 --> Hooks Class Initialized
DEBUG - 2023-09-19 15:03:35 --> UTF-8 Support Enabled
INFO - 2023-09-19 15:03:35 --> Utf8 Class Initialized
INFO - 2023-09-19 15:03:35 --> URI Class Initialized
INFO - 2023-09-19 15:03:35 --> Router Class Initialized
INFO - 2023-09-19 15:03:35 --> Output Class Initialized
INFO - 2023-09-19 15:03:35 --> Security Class Initialized
DEBUG - 2023-09-19 15:03:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-19 15:03:35 --> Input Class Initialized
INFO - 2023-09-19 15:03:35 --> Language Class Initialized
INFO - 2023-09-19 15:03:35 --> Loader Class Initialized
INFO - 2023-09-19 15:03:35 --> Helper loaded: url_helper
INFO - 2023-09-19 15:03:35 --> Helper loaded: file_helper
INFO - 2023-09-19 15:03:35 --> Helper loaded: html_helper
INFO - 2023-09-19 15:03:35 --> Helper loaded: text_helper
INFO - 2023-09-19 15:03:35 --> Helper loaded: form_helper
INFO - 2023-09-19 15:03:35 --> Helper loaded: lang_helper
INFO - 2023-09-19 15:03:35 --> Helper loaded: security_helper
INFO - 2023-09-19 15:03:35 --> Helper loaded: cookie_helper
INFO - 2023-09-19 15:03:35 --> Database Driver Class Initialized
INFO - 2023-09-19 15:03:35 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-19 15:03:35 --> Parser Class Initialized
INFO - 2023-09-19 15:03:35 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-19 15:03:35 --> Pagination Class Initialized
INFO - 2023-09-19 15:03:35 --> Form Validation Class Initialized
INFO - 2023-09-19 15:03:35 --> Controller Class Initialized
INFO - 2023-09-19 15:03:35 --> Model Class Initialized
DEBUG - 2023-09-19 15:03:35 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-19 15:03:35 --> Model Class Initialized
INFO - 2023-09-19 15:03:35 --> Final output sent to browser
DEBUG - 2023-09-19 15:03:35 --> Total execution time: 0.0216
ERROR - 2023-09-19 15:03:35 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-19 15:03:35 --> Config Class Initialized
INFO - 2023-09-19 15:03:35 --> Hooks Class Initialized
DEBUG - 2023-09-19 15:03:35 --> UTF-8 Support Enabled
INFO - 2023-09-19 15:03:35 --> Utf8 Class Initialized
INFO - 2023-09-19 15:03:35 --> URI Class Initialized
DEBUG - 2023-09-19 15:03:35 --> No URI present. Default controller set.
INFO - 2023-09-19 15:03:35 --> Router Class Initialized
INFO - 2023-09-19 15:03:35 --> Output Class Initialized
INFO - 2023-09-19 15:03:35 --> Security Class Initialized
DEBUG - 2023-09-19 15:03:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-19 15:03:35 --> Input Class Initialized
INFO - 2023-09-19 15:03:35 --> Language Class Initialized
INFO - 2023-09-19 15:03:35 --> Loader Class Initialized
INFO - 2023-09-19 15:03:35 --> Helper loaded: url_helper
INFO - 2023-09-19 15:03:35 --> Helper loaded: file_helper
INFO - 2023-09-19 15:03:35 --> Helper loaded: html_helper
INFO - 2023-09-19 15:03:35 --> Helper loaded: text_helper
INFO - 2023-09-19 15:03:35 --> Helper loaded: form_helper
INFO - 2023-09-19 15:03:35 --> Helper loaded: lang_helper
INFO - 2023-09-19 15:03:35 --> Helper loaded: security_helper
INFO - 2023-09-19 15:03:35 --> Helper loaded: cookie_helper
INFO - 2023-09-19 15:03:35 --> Database Driver Class Initialized
INFO - 2023-09-19 15:03:35 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-19 15:03:35 --> Parser Class Initialized
INFO - 2023-09-19 15:03:35 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-19 15:03:35 --> Pagination Class Initialized
INFO - 2023-09-19 15:03:35 --> Form Validation Class Initialized
INFO - 2023-09-19 15:03:35 --> Controller Class Initialized
INFO - 2023-09-19 15:03:35 --> Model Class Initialized
DEBUG - 2023-09-19 15:03:35 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-19 15:03:35 --> Model Class Initialized
DEBUG - 2023-09-19 15:03:35 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-19 15:03:35 --> Model Class Initialized
INFO - 2023-09-19 15:03:35 --> Model Class Initialized
INFO - 2023-09-19 15:03:35 --> Model Class Initialized
INFO - 2023-09-19 15:03:35 --> Model Class Initialized
DEBUG - 2023-09-19 15:03:35 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-09-19 15:03:35 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-19 15:03:35 --> Model Class Initialized
INFO - 2023-09-19 15:03:35 --> Model Class Initialized
INFO - 2023-09-19 15:03:35 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-09-19 15:03:35 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-09-19 15:03:35 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-09-19 15:03:35 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-09-19 15:03:35 --> Model Class Initialized
INFO - 2023-09-19 15:03:35 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-09-19 15:03:35 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-09-19 15:03:35 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-09-19 15:03:35 --> Final output sent to browser
DEBUG - 2023-09-19 15:03:35 --> Total execution time: 0.1029
ERROR - 2023-09-19 15:03:56 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-19 15:03:56 --> Config Class Initialized
INFO - 2023-09-19 15:03:56 --> Hooks Class Initialized
DEBUG - 2023-09-19 15:03:56 --> UTF-8 Support Enabled
INFO - 2023-09-19 15:03:56 --> Utf8 Class Initialized
INFO - 2023-09-19 15:03:56 --> URI Class Initialized
INFO - 2023-09-19 15:03:56 --> Router Class Initialized
INFO - 2023-09-19 15:03:56 --> Output Class Initialized
INFO - 2023-09-19 15:03:56 --> Security Class Initialized
DEBUG - 2023-09-19 15:03:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-19 15:03:56 --> Input Class Initialized
INFO - 2023-09-19 15:03:56 --> Language Class Initialized
INFO - 2023-09-19 15:03:56 --> Loader Class Initialized
INFO - 2023-09-19 15:03:56 --> Helper loaded: url_helper
INFO - 2023-09-19 15:03:56 --> Helper loaded: file_helper
INFO - 2023-09-19 15:03:56 --> Helper loaded: html_helper
INFO - 2023-09-19 15:03:56 --> Helper loaded: text_helper
INFO - 2023-09-19 15:03:56 --> Helper loaded: form_helper
INFO - 2023-09-19 15:03:56 --> Helper loaded: lang_helper
INFO - 2023-09-19 15:03:56 --> Helper loaded: security_helper
INFO - 2023-09-19 15:03:56 --> Helper loaded: cookie_helper
INFO - 2023-09-19 15:03:56 --> Database Driver Class Initialized
INFO - 2023-09-19 15:03:56 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-19 15:03:56 --> Parser Class Initialized
INFO - 2023-09-19 15:03:56 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-19 15:03:56 --> Pagination Class Initialized
INFO - 2023-09-19 15:03:56 --> Form Validation Class Initialized
INFO - 2023-09-19 15:03:56 --> Controller Class Initialized
INFO - 2023-09-19 15:03:56 --> Model Class Initialized
DEBUG - 2023-09-19 15:03:56 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-09-19 15:03:56 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-19 15:03:56 --> Model Class Initialized
DEBUG - 2023-09-19 15:03:56 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-19 15:03:56 --> Model Class Initialized
INFO - 2023-09-19 15:03:56 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice.php
DEBUG - 2023-09-19 15:03:56 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-09-19 15:03:56 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-09-19 15:03:56 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-09-19 15:03:56 --> Model Class Initialized
INFO - 2023-09-19 15:03:56 --> Model Class Initialized
INFO - 2023-09-19 15:03:56 --> Model Class Initialized
INFO - 2023-09-19 15:03:56 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-09-19 15:03:56 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-09-19 15:03:56 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-09-19 15:03:56 --> Final output sent to browser
DEBUG - 2023-09-19 15:03:56 --> Total execution time: 0.1550
ERROR - 2023-09-19 15:03:57 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-19 15:03:57 --> Config Class Initialized
INFO - 2023-09-19 15:03:57 --> Hooks Class Initialized
DEBUG - 2023-09-19 15:03:57 --> UTF-8 Support Enabled
INFO - 2023-09-19 15:03:57 --> Utf8 Class Initialized
INFO - 2023-09-19 15:03:57 --> URI Class Initialized
INFO - 2023-09-19 15:03:57 --> Router Class Initialized
INFO - 2023-09-19 15:03:57 --> Output Class Initialized
INFO - 2023-09-19 15:03:57 --> Security Class Initialized
DEBUG - 2023-09-19 15:03:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-19 15:03:57 --> Input Class Initialized
INFO - 2023-09-19 15:03:57 --> Language Class Initialized
INFO - 2023-09-19 15:03:57 --> Loader Class Initialized
INFO - 2023-09-19 15:03:57 --> Helper loaded: url_helper
INFO - 2023-09-19 15:03:57 --> Helper loaded: file_helper
INFO - 2023-09-19 15:03:57 --> Helper loaded: html_helper
INFO - 2023-09-19 15:03:57 --> Helper loaded: text_helper
INFO - 2023-09-19 15:03:57 --> Helper loaded: form_helper
INFO - 2023-09-19 15:03:57 --> Helper loaded: lang_helper
INFO - 2023-09-19 15:03:57 --> Helper loaded: security_helper
INFO - 2023-09-19 15:03:57 --> Helper loaded: cookie_helper
INFO - 2023-09-19 15:03:57 --> Database Driver Class Initialized
INFO - 2023-09-19 15:03:57 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-19 15:03:57 --> Parser Class Initialized
INFO - 2023-09-19 15:03:57 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-19 15:03:57 --> Pagination Class Initialized
INFO - 2023-09-19 15:03:57 --> Form Validation Class Initialized
INFO - 2023-09-19 15:03:57 --> Controller Class Initialized
INFO - 2023-09-19 15:03:57 --> Model Class Initialized
DEBUG - 2023-09-19 15:03:57 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-09-19 15:03:57 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-19 15:03:57 --> Model Class Initialized
DEBUG - 2023-09-19 15:03:57 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-19 15:03:57 --> Model Class Initialized
INFO - 2023-09-19 15:03:57 --> Final output sent to browser
DEBUG - 2023-09-19 15:03:57 --> Total execution time: 0.0610
ERROR - 2023-09-19 15:04:05 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-19 15:04:05 --> Config Class Initialized
INFO - 2023-09-19 15:04:05 --> Hooks Class Initialized
DEBUG - 2023-09-19 15:04:05 --> UTF-8 Support Enabled
INFO - 2023-09-19 15:04:05 --> Utf8 Class Initialized
INFO - 2023-09-19 15:04:05 --> URI Class Initialized
INFO - 2023-09-19 15:04:05 --> Router Class Initialized
INFO - 2023-09-19 15:04:05 --> Output Class Initialized
INFO - 2023-09-19 15:04:05 --> Security Class Initialized
DEBUG - 2023-09-19 15:04:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-19 15:04:05 --> Input Class Initialized
INFO - 2023-09-19 15:04:05 --> Language Class Initialized
INFO - 2023-09-19 15:04:05 --> Loader Class Initialized
INFO - 2023-09-19 15:04:05 --> Helper loaded: url_helper
INFO - 2023-09-19 15:04:05 --> Helper loaded: file_helper
INFO - 2023-09-19 15:04:05 --> Helper loaded: html_helper
INFO - 2023-09-19 15:04:05 --> Helper loaded: text_helper
INFO - 2023-09-19 15:04:05 --> Helper loaded: form_helper
INFO - 2023-09-19 15:04:05 --> Helper loaded: lang_helper
INFO - 2023-09-19 15:04:05 --> Helper loaded: security_helper
INFO - 2023-09-19 15:04:05 --> Helper loaded: cookie_helper
INFO - 2023-09-19 15:04:05 --> Database Driver Class Initialized
INFO - 2023-09-19 15:04:05 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-19 15:04:05 --> Parser Class Initialized
INFO - 2023-09-19 15:04:05 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-19 15:04:05 --> Pagination Class Initialized
INFO - 2023-09-19 15:04:05 --> Form Validation Class Initialized
INFO - 2023-09-19 15:04:05 --> Controller Class Initialized
INFO - 2023-09-19 15:04:05 --> Model Class Initialized
DEBUG - 2023-09-19 15:04:05 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-09-19 15:04:05 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-19 15:04:05 --> Model Class Initialized
DEBUG - 2023-09-19 15:04:05 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-19 15:04:05 --> Model Class Initialized
INFO - 2023-09-19 15:04:06 --> Final output sent to browser
DEBUG - 2023-09-19 15:04:06 --> Total execution time: 0.7889
ERROR - 2023-09-19 15:04:18 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-19 15:04:18 --> Config Class Initialized
INFO - 2023-09-19 15:04:18 --> Hooks Class Initialized
DEBUG - 2023-09-19 15:04:18 --> UTF-8 Support Enabled
INFO - 2023-09-19 15:04:18 --> Utf8 Class Initialized
INFO - 2023-09-19 15:04:18 --> URI Class Initialized
DEBUG - 2023-09-19 15:04:18 --> No URI present. Default controller set.
INFO - 2023-09-19 15:04:18 --> Router Class Initialized
INFO - 2023-09-19 15:04:18 --> Output Class Initialized
INFO - 2023-09-19 15:04:18 --> Security Class Initialized
DEBUG - 2023-09-19 15:04:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-19 15:04:18 --> Input Class Initialized
INFO - 2023-09-19 15:04:18 --> Language Class Initialized
INFO - 2023-09-19 15:04:18 --> Loader Class Initialized
INFO - 2023-09-19 15:04:18 --> Helper loaded: url_helper
INFO - 2023-09-19 15:04:18 --> Helper loaded: file_helper
INFO - 2023-09-19 15:04:18 --> Helper loaded: html_helper
INFO - 2023-09-19 15:04:18 --> Helper loaded: text_helper
INFO - 2023-09-19 15:04:18 --> Helper loaded: form_helper
INFO - 2023-09-19 15:04:18 --> Helper loaded: lang_helper
INFO - 2023-09-19 15:04:18 --> Helper loaded: security_helper
INFO - 2023-09-19 15:04:18 --> Helper loaded: cookie_helper
INFO - 2023-09-19 15:04:18 --> Database Driver Class Initialized
INFO - 2023-09-19 15:04:18 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-19 15:04:18 --> Parser Class Initialized
INFO - 2023-09-19 15:04:18 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-19 15:04:18 --> Pagination Class Initialized
INFO - 2023-09-19 15:04:18 --> Form Validation Class Initialized
INFO - 2023-09-19 15:04:18 --> Controller Class Initialized
INFO - 2023-09-19 15:04:18 --> Model Class Initialized
DEBUG - 2023-09-19 15:04:18 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-19 15:04:18 --> Model Class Initialized
DEBUG - 2023-09-19 15:04:18 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-19 15:04:18 --> Model Class Initialized
INFO - 2023-09-19 15:04:18 --> Model Class Initialized
INFO - 2023-09-19 15:04:18 --> Model Class Initialized
INFO - 2023-09-19 15:04:18 --> Model Class Initialized
DEBUG - 2023-09-19 15:04:18 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-09-19 15:04:18 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-19 15:04:18 --> Model Class Initialized
INFO - 2023-09-19 15:04:18 --> Model Class Initialized
INFO - 2023-09-19 15:04:18 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-09-19 15:04:18 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-09-19 15:04:18 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-09-19 15:04:18 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-09-19 15:04:18 --> Model Class Initialized
INFO - 2023-09-19 15:04:18 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-09-19 15:04:18 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-09-19 15:04:18 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-09-19 15:04:18 --> Final output sent to browser
DEBUG - 2023-09-19 15:04:18 --> Total execution time: 0.2093
ERROR - 2023-09-19 15:06:07 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-19 15:06:07 --> Config Class Initialized
INFO - 2023-09-19 15:06:07 --> Hooks Class Initialized
DEBUG - 2023-09-19 15:06:07 --> UTF-8 Support Enabled
INFO - 2023-09-19 15:06:07 --> Utf8 Class Initialized
INFO - 2023-09-19 15:06:07 --> URI Class Initialized
DEBUG - 2023-09-19 15:06:07 --> No URI present. Default controller set.
INFO - 2023-09-19 15:06:07 --> Router Class Initialized
INFO - 2023-09-19 15:06:07 --> Output Class Initialized
INFO - 2023-09-19 15:06:07 --> Security Class Initialized
DEBUG - 2023-09-19 15:06:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-19 15:06:07 --> Input Class Initialized
INFO - 2023-09-19 15:06:07 --> Language Class Initialized
INFO - 2023-09-19 15:06:07 --> Loader Class Initialized
INFO - 2023-09-19 15:06:07 --> Helper loaded: url_helper
INFO - 2023-09-19 15:06:07 --> Helper loaded: file_helper
INFO - 2023-09-19 15:06:07 --> Helper loaded: html_helper
INFO - 2023-09-19 15:06:07 --> Helper loaded: text_helper
INFO - 2023-09-19 15:06:07 --> Helper loaded: form_helper
INFO - 2023-09-19 15:06:07 --> Helper loaded: lang_helper
INFO - 2023-09-19 15:06:07 --> Helper loaded: security_helper
INFO - 2023-09-19 15:06:07 --> Helper loaded: cookie_helper
INFO - 2023-09-19 15:06:07 --> Database Driver Class Initialized
INFO - 2023-09-19 15:06:07 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-19 15:06:07 --> Parser Class Initialized
INFO - 2023-09-19 15:06:07 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-19 15:06:07 --> Pagination Class Initialized
INFO - 2023-09-19 15:06:07 --> Form Validation Class Initialized
INFO - 2023-09-19 15:06:07 --> Controller Class Initialized
INFO - 2023-09-19 15:06:07 --> Model Class Initialized
DEBUG - 2023-09-19 15:06:07 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-19 15:06:07 --> Model Class Initialized
DEBUG - 2023-09-19 15:06:07 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-19 15:06:07 --> Model Class Initialized
INFO - 2023-09-19 15:06:07 --> Model Class Initialized
INFO - 2023-09-19 15:06:07 --> Model Class Initialized
INFO - 2023-09-19 15:06:07 --> Model Class Initialized
DEBUG - 2023-09-19 15:06:07 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-09-19 15:06:07 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-19 15:06:07 --> Model Class Initialized
INFO - 2023-09-19 15:06:07 --> Model Class Initialized
INFO - 2023-09-19 15:06:07 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-09-19 15:06:07 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-09-19 15:06:07 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-09-19 15:06:07 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-09-19 15:06:07 --> Model Class Initialized
INFO - 2023-09-19 15:06:07 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-09-19 15:06:07 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-09-19 15:06:07 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-09-19 15:06:07 --> Final output sent to browser
DEBUG - 2023-09-19 15:06:07 --> Total execution time: 0.2113
ERROR - 2023-09-19 15:06:21 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-19 15:06:21 --> Config Class Initialized
INFO - 2023-09-19 15:06:21 --> Hooks Class Initialized
DEBUG - 2023-09-19 15:06:21 --> UTF-8 Support Enabled
INFO - 2023-09-19 15:06:21 --> Utf8 Class Initialized
INFO - 2023-09-19 15:06:21 --> URI Class Initialized
DEBUG - 2023-09-19 15:06:21 --> No URI present. Default controller set.
INFO - 2023-09-19 15:06:21 --> Router Class Initialized
INFO - 2023-09-19 15:06:21 --> Output Class Initialized
INFO - 2023-09-19 15:06:21 --> Security Class Initialized
DEBUG - 2023-09-19 15:06:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-19 15:06:21 --> Input Class Initialized
INFO - 2023-09-19 15:06:21 --> Language Class Initialized
INFO - 2023-09-19 15:06:21 --> Loader Class Initialized
INFO - 2023-09-19 15:06:21 --> Helper loaded: url_helper
INFO - 2023-09-19 15:06:21 --> Helper loaded: file_helper
INFO - 2023-09-19 15:06:21 --> Helper loaded: html_helper
INFO - 2023-09-19 15:06:21 --> Helper loaded: text_helper
INFO - 2023-09-19 15:06:21 --> Helper loaded: form_helper
INFO - 2023-09-19 15:06:21 --> Helper loaded: lang_helper
INFO - 2023-09-19 15:06:21 --> Helper loaded: security_helper
INFO - 2023-09-19 15:06:21 --> Helper loaded: cookie_helper
INFO - 2023-09-19 15:06:21 --> Database Driver Class Initialized
INFO - 2023-09-19 15:06:21 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-19 15:06:21 --> Parser Class Initialized
INFO - 2023-09-19 15:06:21 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-19 15:06:21 --> Pagination Class Initialized
INFO - 2023-09-19 15:06:21 --> Form Validation Class Initialized
INFO - 2023-09-19 15:06:21 --> Controller Class Initialized
INFO - 2023-09-19 15:06:21 --> Model Class Initialized
DEBUG - 2023-09-19 15:06:21 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-19 15:06:21 --> Model Class Initialized
DEBUG - 2023-09-19 15:06:21 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-19 15:06:21 --> Model Class Initialized
INFO - 2023-09-19 15:06:21 --> Model Class Initialized
INFO - 2023-09-19 15:06:21 --> Model Class Initialized
INFO - 2023-09-19 15:06:21 --> Model Class Initialized
DEBUG - 2023-09-19 15:06:21 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-09-19 15:06:21 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-19 15:06:21 --> Model Class Initialized
INFO - 2023-09-19 15:06:21 --> Model Class Initialized
INFO - 2023-09-19 15:06:21 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-09-19 15:06:21 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-09-19 15:06:21 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-09-19 15:06:21 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-09-19 15:06:21 --> Model Class Initialized
INFO - 2023-09-19 15:06:21 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-09-19 15:06:21 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-09-19 15:06:21 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-09-19 15:06:21 --> Final output sent to browser
DEBUG - 2023-09-19 15:06:21 --> Total execution time: 0.2150
