<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2024-01-21 02:06:37 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-01-21 02:06:37 --> Config Class Initialized
INFO - 2024-01-21 02:06:37 --> Hooks Class Initialized
DEBUG - 2024-01-21 02:06:37 --> UTF-8 Support Enabled
INFO - 2024-01-21 02:06:37 --> Utf8 Class Initialized
INFO - 2024-01-21 02:06:37 --> URI Class Initialized
DEBUG - 2024-01-21 02:06:37 --> No URI present. Default controller set.
INFO - 2024-01-21 02:06:37 --> Router Class Initialized
INFO - 2024-01-21 02:06:37 --> Output Class Initialized
INFO - 2024-01-21 02:06:37 --> Security Class Initialized
DEBUG - 2024-01-21 02:06:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-21 02:06:37 --> Input Class Initialized
INFO - 2024-01-21 02:06:37 --> Language Class Initialized
INFO - 2024-01-21 02:06:37 --> Loader Class Initialized
INFO - 2024-01-21 02:06:37 --> Helper loaded: url_helper
INFO - 2024-01-21 02:06:37 --> Helper loaded: file_helper
INFO - 2024-01-21 02:06:37 --> Helper loaded: html_helper
INFO - 2024-01-21 02:06:37 --> Helper loaded: text_helper
INFO - 2024-01-21 02:06:37 --> Helper loaded: form_helper
INFO - 2024-01-21 02:06:37 --> Helper loaded: lang_helper
INFO - 2024-01-21 02:06:37 --> Helper loaded: security_helper
INFO - 2024-01-21 02:06:37 --> Helper loaded: cookie_helper
INFO - 2024-01-21 02:06:37 --> Database Driver Class Initialized
INFO - 2024-01-21 02:06:37 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-21 02:06:37 --> Parser Class Initialized
INFO - 2024-01-21 02:06:37 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-01-21 02:06:37 --> Pagination Class Initialized
INFO - 2024-01-21 02:06:37 --> Form Validation Class Initialized
INFO - 2024-01-21 02:06:37 --> Controller Class Initialized
INFO - 2024-01-21 02:06:37 --> Model Class Initialized
DEBUG - 2024-01-21 02:06:37 --> Session class already loaded. Second attempt ignored.
ERROR - 2024-01-21 05:55:15 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-01-21 05:55:15 --> Config Class Initialized
INFO - 2024-01-21 05:55:15 --> Hooks Class Initialized
DEBUG - 2024-01-21 05:55:15 --> UTF-8 Support Enabled
INFO - 2024-01-21 05:55:15 --> Utf8 Class Initialized
INFO - 2024-01-21 05:55:15 --> URI Class Initialized
INFO - 2024-01-21 05:55:15 --> Router Class Initialized
INFO - 2024-01-21 05:55:15 --> Output Class Initialized
INFO - 2024-01-21 05:55:15 --> Security Class Initialized
DEBUG - 2024-01-21 05:55:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-21 05:55:15 --> Input Class Initialized
INFO - 2024-01-21 05:55:15 --> Language Class Initialized
ERROR - 2024-01-21 05:55:15 --> 404 Page Not Found: Sitemapxml/index
ERROR - 2024-01-21 05:55:16 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-01-21 05:55:16 --> Config Class Initialized
INFO - 2024-01-21 05:55:16 --> Hooks Class Initialized
DEBUG - 2024-01-21 05:55:16 --> UTF-8 Support Enabled
INFO - 2024-01-21 05:55:16 --> Utf8 Class Initialized
INFO - 2024-01-21 05:55:16 --> URI Class Initialized
DEBUG - 2024-01-21 05:55:16 --> No URI present. Default controller set.
INFO - 2024-01-21 05:55:16 --> Router Class Initialized
INFO - 2024-01-21 05:55:16 --> Output Class Initialized
INFO - 2024-01-21 05:55:16 --> Security Class Initialized
DEBUG - 2024-01-21 05:55:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-21 05:55:16 --> Input Class Initialized
INFO - 2024-01-21 05:55:16 --> Language Class Initialized
INFO - 2024-01-21 05:55:16 --> Loader Class Initialized
INFO - 2024-01-21 05:55:16 --> Helper loaded: url_helper
INFO - 2024-01-21 05:55:16 --> Helper loaded: file_helper
INFO - 2024-01-21 05:55:16 --> Helper loaded: html_helper
INFO - 2024-01-21 05:55:16 --> Helper loaded: text_helper
INFO - 2024-01-21 05:55:16 --> Helper loaded: form_helper
INFO - 2024-01-21 05:55:16 --> Helper loaded: lang_helper
INFO - 2024-01-21 05:55:16 --> Helper loaded: security_helper
INFO - 2024-01-21 05:55:16 --> Helper loaded: cookie_helper
INFO - 2024-01-21 05:55:16 --> Database Driver Class Initialized
INFO - 2024-01-21 05:55:16 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-21 05:55:16 --> Parser Class Initialized
INFO - 2024-01-21 05:55:16 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-01-21 05:55:16 --> Pagination Class Initialized
INFO - 2024-01-21 05:55:16 --> Form Validation Class Initialized
INFO - 2024-01-21 05:55:16 --> Controller Class Initialized
INFO - 2024-01-21 05:55:16 --> Model Class Initialized
DEBUG - 2024-01-21 05:55:16 --> Session class already loaded. Second attempt ignored.
ERROR - 2024-01-21 05:55:17 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-01-21 05:55:17 --> Config Class Initialized
INFO - 2024-01-21 05:55:17 --> Hooks Class Initialized
DEBUG - 2024-01-21 05:55:17 --> UTF-8 Support Enabled
INFO - 2024-01-21 05:55:17 --> Utf8 Class Initialized
INFO - 2024-01-21 05:55:17 --> URI Class Initialized
INFO - 2024-01-21 05:55:17 --> Router Class Initialized
INFO - 2024-01-21 05:55:17 --> Output Class Initialized
INFO - 2024-01-21 05:55:17 --> Security Class Initialized
DEBUG - 2024-01-21 05:55:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-21 05:55:17 --> Input Class Initialized
INFO - 2024-01-21 05:55:17 --> Language Class Initialized
ERROR - 2024-01-21 05:55:17 --> 404 Page Not Found: Wp-cronphp/index
ERROR - 2024-01-21 07:05:47 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
ERROR - 2024-01-21 07:05:47 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-01-21 07:05:47 --> Config Class Initialized
INFO - 2024-01-21 07:05:47 --> Config Class Initialized
INFO - 2024-01-21 07:05:47 --> Hooks Class Initialized
INFO - 2024-01-21 07:05:47 --> Hooks Class Initialized
DEBUG - 2024-01-21 07:05:47 --> UTF-8 Support Enabled
DEBUG - 2024-01-21 07:05:47 --> UTF-8 Support Enabled
INFO - 2024-01-21 07:05:47 --> Utf8 Class Initialized
INFO - 2024-01-21 07:05:47 --> Utf8 Class Initialized
INFO - 2024-01-21 07:05:47 --> URI Class Initialized
INFO - 2024-01-21 07:05:47 --> URI Class Initialized
DEBUG - 2024-01-21 07:05:47 --> No URI present. Default controller set.
INFO - 2024-01-21 07:05:47 --> Router Class Initialized
DEBUG - 2024-01-21 07:05:47 --> No URI present. Default controller set.
INFO - 2024-01-21 07:05:47 --> Router Class Initialized
INFO - 2024-01-21 07:05:47 --> Output Class Initialized
INFO - 2024-01-21 07:05:47 --> Output Class Initialized
INFO - 2024-01-21 07:05:47 --> Security Class Initialized
INFO - 2024-01-21 07:05:47 --> Security Class Initialized
DEBUG - 2024-01-21 07:05:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-21 07:05:47 --> Input Class Initialized
DEBUG - 2024-01-21 07:05:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-21 07:05:47 --> Input Class Initialized
INFO - 2024-01-21 07:05:47 --> Language Class Initialized
INFO - 2024-01-21 07:05:47 --> Language Class Initialized
INFO - 2024-01-21 07:05:47 --> Loader Class Initialized
INFO - 2024-01-21 07:05:47 --> Loader Class Initialized
INFO - 2024-01-21 07:05:47 --> Helper loaded: url_helper
INFO - 2024-01-21 07:05:47 --> Helper loaded: url_helper
INFO - 2024-01-21 07:05:47 --> Helper loaded: file_helper
INFO - 2024-01-21 07:05:47 --> Helper loaded: file_helper
INFO - 2024-01-21 07:05:47 --> Helper loaded: html_helper
INFO - 2024-01-21 07:05:47 --> Helper loaded: html_helper
INFO - 2024-01-21 07:05:47 --> Helper loaded: text_helper
INFO - 2024-01-21 07:05:47 --> Helper loaded: text_helper
INFO - 2024-01-21 07:05:47 --> Helper loaded: form_helper
INFO - 2024-01-21 07:05:47 --> Helper loaded: form_helper
INFO - 2024-01-21 07:05:47 --> Helper loaded: lang_helper
INFO - 2024-01-21 07:05:47 --> Helper loaded: lang_helper
INFO - 2024-01-21 07:05:47 --> Helper loaded: security_helper
INFO - 2024-01-21 07:05:47 --> Helper loaded: security_helper
INFO - 2024-01-21 07:05:47 --> Helper loaded: cookie_helper
INFO - 2024-01-21 07:05:47 --> Helper loaded: cookie_helper
INFO - 2024-01-21 07:05:47 --> Database Driver Class Initialized
INFO - 2024-01-21 07:05:47 --> Database Driver Class Initialized
INFO - 2024-01-21 07:05:47 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-21 07:05:47 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-21 07:05:47 --> Parser Class Initialized
INFO - 2024-01-21 07:05:47 --> Parser Class Initialized
INFO - 2024-01-21 07:05:47 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-01-21 07:05:47 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-01-21 07:05:47 --> Pagination Class Initialized
INFO - 2024-01-21 07:05:47 --> Pagination Class Initialized
INFO - 2024-01-21 07:05:47 --> Form Validation Class Initialized
INFO - 2024-01-21 07:05:47 --> Form Validation Class Initialized
INFO - 2024-01-21 07:05:47 --> Controller Class Initialized
INFO - 2024-01-21 07:05:47 --> Controller Class Initialized
INFO - 2024-01-21 07:05:47 --> Model Class Initialized
INFO - 2024-01-21 07:05:47 --> Model Class Initialized
DEBUG - 2024-01-21 07:05:47 --> Session class already loaded. Second attempt ignored.
DEBUG - 2024-01-21 07:05:47 --> Session class already loaded. Second attempt ignored.
ERROR - 2024-01-21 07:05:49 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-01-21 07:05:49 --> Config Class Initialized
INFO - 2024-01-21 07:05:49 --> Hooks Class Initialized
DEBUG - 2024-01-21 07:05:49 --> UTF-8 Support Enabled
INFO - 2024-01-21 07:05:49 --> Utf8 Class Initialized
INFO - 2024-01-21 07:05:49 --> URI Class Initialized
DEBUG - 2024-01-21 07:05:49 --> No URI present. Default controller set.
INFO - 2024-01-21 07:05:49 --> Router Class Initialized
INFO - 2024-01-21 07:05:49 --> Output Class Initialized
INFO - 2024-01-21 07:05:49 --> Security Class Initialized
DEBUG - 2024-01-21 07:05:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-21 07:05:49 --> Input Class Initialized
INFO - 2024-01-21 07:05:49 --> Language Class Initialized
INFO - 2024-01-21 07:05:49 --> Loader Class Initialized
INFO - 2024-01-21 07:05:49 --> Helper loaded: url_helper
INFO - 2024-01-21 07:05:49 --> Helper loaded: file_helper
INFO - 2024-01-21 07:05:49 --> Helper loaded: html_helper
INFO - 2024-01-21 07:05:49 --> Helper loaded: text_helper
INFO - 2024-01-21 07:05:49 --> Helper loaded: form_helper
INFO - 2024-01-21 07:05:49 --> Helper loaded: lang_helper
INFO - 2024-01-21 07:05:49 --> Helper loaded: security_helper
INFO - 2024-01-21 07:05:49 --> Helper loaded: cookie_helper
INFO - 2024-01-21 07:05:49 --> Database Driver Class Initialized
INFO - 2024-01-21 07:05:49 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-21 07:05:49 --> Parser Class Initialized
INFO - 2024-01-21 07:05:49 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-01-21 07:05:49 --> Pagination Class Initialized
INFO - 2024-01-21 07:05:49 --> Form Validation Class Initialized
INFO - 2024-01-21 07:05:49 --> Controller Class Initialized
INFO - 2024-01-21 07:05:49 --> Model Class Initialized
DEBUG - 2024-01-21 07:05:49 --> Session class already loaded. Second attempt ignored.
ERROR - 2024-01-21 07:05:49 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-01-21 07:05:49 --> Config Class Initialized
INFO - 2024-01-21 07:05:49 --> Hooks Class Initialized
DEBUG - 2024-01-21 07:05:49 --> UTF-8 Support Enabled
INFO - 2024-01-21 07:05:49 --> Utf8 Class Initialized
INFO - 2024-01-21 07:05:49 --> URI Class Initialized
DEBUG - 2024-01-21 07:05:49 --> No URI present. Default controller set.
INFO - 2024-01-21 07:05:49 --> Router Class Initialized
INFO - 2024-01-21 07:05:49 --> Output Class Initialized
INFO - 2024-01-21 07:05:49 --> Security Class Initialized
DEBUG - 2024-01-21 07:05:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-21 07:05:49 --> Input Class Initialized
INFO - 2024-01-21 07:05:49 --> Language Class Initialized
INFO - 2024-01-21 07:05:49 --> Loader Class Initialized
INFO - 2024-01-21 07:05:49 --> Helper loaded: url_helper
INFO - 2024-01-21 07:05:49 --> Helper loaded: file_helper
INFO - 2024-01-21 07:05:49 --> Helper loaded: html_helper
INFO - 2024-01-21 07:05:49 --> Helper loaded: text_helper
INFO - 2024-01-21 07:05:49 --> Helper loaded: form_helper
INFO - 2024-01-21 07:05:49 --> Helper loaded: lang_helper
INFO - 2024-01-21 07:05:49 --> Helper loaded: security_helper
INFO - 2024-01-21 07:05:49 --> Helper loaded: cookie_helper
INFO - 2024-01-21 07:05:49 --> Database Driver Class Initialized
INFO - 2024-01-21 07:05:49 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-21 07:05:49 --> Parser Class Initialized
INFO - 2024-01-21 07:05:49 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-01-21 07:05:49 --> Pagination Class Initialized
INFO - 2024-01-21 07:05:49 --> Form Validation Class Initialized
INFO - 2024-01-21 07:05:49 --> Controller Class Initialized
INFO - 2024-01-21 07:05:49 --> Model Class Initialized
DEBUG - 2024-01-21 07:05:49 --> Session class already loaded. Second attempt ignored.
ERROR - 2024-01-21 07:05:49 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-01-21 07:05:49 --> Config Class Initialized
INFO - 2024-01-21 07:05:49 --> Hooks Class Initialized
DEBUG - 2024-01-21 07:05:49 --> UTF-8 Support Enabled
INFO - 2024-01-21 07:05:49 --> Utf8 Class Initialized
INFO - 2024-01-21 07:05:49 --> URI Class Initialized
INFO - 2024-01-21 07:05:49 --> Router Class Initialized
INFO - 2024-01-21 07:05:49 --> Output Class Initialized
INFO - 2024-01-21 07:05:49 --> Security Class Initialized
DEBUG - 2024-01-21 07:05:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-21 07:05:49 --> Input Class Initialized
INFO - 2024-01-21 07:05:49 --> Language Class Initialized
ERROR - 2024-01-21 07:05:49 --> 404 Page Not Found: Vscode/sftp.json
ERROR - 2024-01-21 07:05:49 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-01-21 07:05:49 --> Config Class Initialized
INFO - 2024-01-21 07:05:49 --> Hooks Class Initialized
DEBUG - 2024-01-21 07:05:49 --> UTF-8 Support Enabled
INFO - 2024-01-21 07:05:49 --> Utf8 Class Initialized
INFO - 2024-01-21 07:05:49 --> URI Class Initialized
INFO - 2024-01-21 07:05:49 --> Router Class Initialized
INFO - 2024-01-21 07:05:49 --> Output Class Initialized
INFO - 2024-01-21 07:05:49 --> Security Class Initialized
DEBUG - 2024-01-21 07:05:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-21 07:05:49 --> Input Class Initialized
INFO - 2024-01-21 07:05:49 --> Language Class Initialized
ERROR - 2024-01-21 07:05:49 --> 404 Page Not Found: Vscode/sftp.json
ERROR - 2024-01-21 07:05:49 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-01-21 07:05:49 --> Config Class Initialized
INFO - 2024-01-21 07:05:49 --> Hooks Class Initialized
DEBUG - 2024-01-21 07:05:49 --> UTF-8 Support Enabled
INFO - 2024-01-21 07:05:49 --> Utf8 Class Initialized
INFO - 2024-01-21 07:05:49 --> URI Class Initialized
INFO - 2024-01-21 07:05:49 --> Router Class Initialized
INFO - 2024-01-21 07:05:49 --> Output Class Initialized
INFO - 2024-01-21 07:05:49 --> Security Class Initialized
DEBUG - 2024-01-21 07:05:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-21 07:05:49 --> Input Class Initialized
INFO - 2024-01-21 07:05:49 --> Language Class Initialized
ERROR - 2024-01-21 07:05:49 --> 404 Page Not Found: About/index
ERROR - 2024-01-21 07:05:49 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-01-21 07:05:49 --> Config Class Initialized
INFO - 2024-01-21 07:05:49 --> Hooks Class Initialized
DEBUG - 2024-01-21 07:05:49 --> UTF-8 Support Enabled
INFO - 2024-01-21 07:05:49 --> Utf8 Class Initialized
INFO - 2024-01-21 07:05:49 --> URI Class Initialized
INFO - 2024-01-21 07:05:49 --> Router Class Initialized
INFO - 2024-01-21 07:05:49 --> Output Class Initialized
INFO - 2024-01-21 07:05:49 --> Security Class Initialized
DEBUG - 2024-01-21 07:05:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-21 07:05:49 --> Input Class Initialized
INFO - 2024-01-21 07:05:49 --> Language Class Initialized
ERROR - 2024-01-21 07:05:49 --> 404 Page Not Found: Debug/default
ERROR - 2024-01-21 07:05:50 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-01-21 07:05:50 --> Config Class Initialized
INFO - 2024-01-21 07:05:50 --> Hooks Class Initialized
DEBUG - 2024-01-21 07:05:50 --> UTF-8 Support Enabled
INFO - 2024-01-21 07:05:50 --> Utf8 Class Initialized
INFO - 2024-01-21 07:05:50 --> URI Class Initialized
INFO - 2024-01-21 07:05:50 --> Router Class Initialized
INFO - 2024-01-21 07:05:50 --> Output Class Initialized
INFO - 2024-01-21 07:05:50 --> Security Class Initialized
DEBUG - 2024-01-21 07:05:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-21 07:05:50 --> Input Class Initialized
INFO - 2024-01-21 07:05:50 --> Language Class Initialized
ERROR - 2024-01-21 07:05:50 --> 404 Page Not Found: V2/_catalog
ERROR - 2024-01-21 07:05:50 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-01-21 07:05:50 --> Config Class Initialized
INFO - 2024-01-21 07:05:50 --> Hooks Class Initialized
DEBUG - 2024-01-21 07:05:50 --> UTF-8 Support Enabled
INFO - 2024-01-21 07:05:50 --> Utf8 Class Initialized
INFO - 2024-01-21 07:05:50 --> URI Class Initialized
INFO - 2024-01-21 07:05:50 --> Router Class Initialized
INFO - 2024-01-21 07:05:50 --> Output Class Initialized
INFO - 2024-01-21 07:05:50 --> Security Class Initialized
DEBUG - 2024-01-21 07:05:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-21 07:05:50 --> Input Class Initialized
INFO - 2024-01-21 07:05:50 --> Language Class Initialized
ERROR - 2024-01-21 07:05:50 --> 404 Page Not Found: About/index
ERROR - 2024-01-21 07:05:50 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-01-21 07:05:50 --> Config Class Initialized
INFO - 2024-01-21 07:05:50 --> Hooks Class Initialized
DEBUG - 2024-01-21 07:05:50 --> UTF-8 Support Enabled
INFO - 2024-01-21 07:05:50 --> Utf8 Class Initialized
INFO - 2024-01-21 07:05:50 --> URI Class Initialized
INFO - 2024-01-21 07:05:50 --> Router Class Initialized
INFO - 2024-01-21 07:05:50 --> Output Class Initialized
INFO - 2024-01-21 07:05:50 --> Security Class Initialized
DEBUG - 2024-01-21 07:05:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-21 07:05:50 --> Input Class Initialized
INFO - 2024-01-21 07:05:50 --> Language Class Initialized
ERROR - 2024-01-21 07:05:50 --> 404 Page Not Found: Ecp/Current
ERROR - 2024-01-21 07:05:50 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-01-21 07:05:50 --> Config Class Initialized
INFO - 2024-01-21 07:05:50 --> Hooks Class Initialized
DEBUG - 2024-01-21 07:05:50 --> UTF-8 Support Enabled
INFO - 2024-01-21 07:05:50 --> Utf8 Class Initialized
INFO - 2024-01-21 07:05:50 --> URI Class Initialized
INFO - 2024-01-21 07:05:50 --> Router Class Initialized
INFO - 2024-01-21 07:05:50 --> Output Class Initialized
INFO - 2024-01-21 07:05:50 --> Security Class Initialized
DEBUG - 2024-01-21 07:05:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-21 07:05:50 --> Input Class Initialized
INFO - 2024-01-21 07:05:50 --> Language Class Initialized
ERROR - 2024-01-21 07:05:50 --> 404 Page Not Found: Debug/default
ERROR - 2024-01-21 07:05:50 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-01-21 07:05:50 --> Config Class Initialized
INFO - 2024-01-21 07:05:50 --> Hooks Class Initialized
DEBUG - 2024-01-21 07:05:50 --> UTF-8 Support Enabled
INFO - 2024-01-21 07:05:50 --> Utf8 Class Initialized
INFO - 2024-01-21 07:05:50 --> URI Class Initialized
INFO - 2024-01-21 07:05:50 --> Router Class Initialized
INFO - 2024-01-21 07:05:50 --> Output Class Initialized
INFO - 2024-01-21 07:05:50 --> Security Class Initialized
DEBUG - 2024-01-21 07:05:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-21 07:05:50 --> Input Class Initialized
INFO - 2024-01-21 07:05:50 --> Language Class Initialized
ERROR - 2024-01-21 07:05:50 --> 404 Page Not Found: V2/_catalog
ERROR - 2024-01-21 07:05:50 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-01-21 07:05:50 --> Config Class Initialized
INFO - 2024-01-21 07:05:50 --> Hooks Class Initialized
DEBUG - 2024-01-21 07:05:50 --> UTF-8 Support Enabled
INFO - 2024-01-21 07:05:50 --> Utf8 Class Initialized
INFO - 2024-01-21 07:05:50 --> URI Class Initialized
INFO - 2024-01-21 07:05:50 --> Router Class Initialized
INFO - 2024-01-21 07:05:50 --> Output Class Initialized
INFO - 2024-01-21 07:05:50 --> Security Class Initialized
DEBUG - 2024-01-21 07:05:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-21 07:05:50 --> Input Class Initialized
INFO - 2024-01-21 07:05:50 --> Language Class Initialized
ERROR - 2024-01-21 07:05:50 --> 404 Page Not Found: Server-status/index
ERROR - 2024-01-21 07:05:50 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-01-21 07:05:50 --> Config Class Initialized
INFO - 2024-01-21 07:05:50 --> Hooks Class Initialized
DEBUG - 2024-01-21 07:05:50 --> UTF-8 Support Enabled
INFO - 2024-01-21 07:05:50 --> Utf8 Class Initialized
INFO - 2024-01-21 07:05:50 --> URI Class Initialized
INFO - 2024-01-21 07:05:50 --> Router Class Initialized
INFO - 2024-01-21 07:05:50 --> Output Class Initialized
INFO - 2024-01-21 07:05:50 --> Security Class Initialized
DEBUG - 2024-01-21 07:05:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-21 07:05:50 --> Input Class Initialized
INFO - 2024-01-21 07:05:50 --> Language Class Initialized
ERROR - 2024-01-21 07:05:50 --> 404 Page Not Found: Ecp/Current
ERROR - 2024-01-21 07:05:50 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-01-21 07:05:50 --> Config Class Initialized
INFO - 2024-01-21 07:05:50 --> Hooks Class Initialized
DEBUG - 2024-01-21 07:05:50 --> UTF-8 Support Enabled
INFO - 2024-01-21 07:05:50 --> Utf8 Class Initialized
INFO - 2024-01-21 07:05:50 --> URI Class Initialized
INFO - 2024-01-21 07:05:50 --> Router Class Initialized
INFO - 2024-01-21 07:05:50 --> Output Class Initialized
INFO - 2024-01-21 07:05:50 --> Security Class Initialized
DEBUG - 2024-01-21 07:05:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-21 07:05:50 --> Input Class Initialized
INFO - 2024-01-21 07:05:50 --> Language Class Initialized
ERROR - 2024-01-21 07:05:50 --> 404 Page Not Found: Loginaction/index
ERROR - 2024-01-21 07:05:50 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-01-21 07:05:50 --> Config Class Initialized
INFO - 2024-01-21 07:05:50 --> Hooks Class Initialized
DEBUG - 2024-01-21 07:05:50 --> UTF-8 Support Enabled
INFO - 2024-01-21 07:05:50 --> Utf8 Class Initialized
INFO - 2024-01-21 07:05:50 --> URI Class Initialized
INFO - 2024-01-21 07:05:50 --> Router Class Initialized
INFO - 2024-01-21 07:05:50 --> Output Class Initialized
INFO - 2024-01-21 07:05:50 --> Security Class Initialized
DEBUG - 2024-01-21 07:05:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-21 07:05:50 --> Input Class Initialized
INFO - 2024-01-21 07:05:50 --> Language Class Initialized
ERROR - 2024-01-21 07:05:50 --> 404 Page Not Found: _all_dbs/index
ERROR - 2024-01-21 07:05:50 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-01-21 07:05:50 --> Config Class Initialized
INFO - 2024-01-21 07:05:50 --> Hooks Class Initialized
DEBUG - 2024-01-21 07:05:50 --> UTF-8 Support Enabled
INFO - 2024-01-21 07:05:50 --> Utf8 Class Initialized
INFO - 2024-01-21 07:05:50 --> URI Class Initialized
INFO - 2024-01-21 07:05:50 --> Router Class Initialized
INFO - 2024-01-21 07:05:50 --> Output Class Initialized
INFO - 2024-01-21 07:05:50 --> Security Class Initialized
DEBUG - 2024-01-21 07:05:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-21 07:05:50 --> Input Class Initialized
INFO - 2024-01-21 07:05:50 --> Language Class Initialized
ERROR - 2024-01-21 07:05:50 --> 404 Page Not Found: DS_Store/index
ERROR - 2024-01-21 07:05:51 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-01-21 07:05:51 --> Config Class Initialized
INFO - 2024-01-21 07:05:51 --> Hooks Class Initialized
DEBUG - 2024-01-21 07:05:51 --> UTF-8 Support Enabled
INFO - 2024-01-21 07:05:51 --> Utf8 Class Initialized
INFO - 2024-01-21 07:05:51 --> URI Class Initialized
INFO - 2024-01-21 07:05:51 --> Router Class Initialized
INFO - 2024-01-21 07:05:51 --> Output Class Initialized
INFO - 2024-01-21 07:05:51 --> Security Class Initialized
DEBUG - 2024-01-21 07:05:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-21 07:05:51 --> Input Class Initialized
INFO - 2024-01-21 07:05:51 --> Language Class Initialized
ERROR - 2024-01-21 07:05:51 --> 404 Page Not Found: Server-status/index
ERROR - 2024-01-21 07:05:51 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-01-21 07:05:51 --> Config Class Initialized
INFO - 2024-01-21 07:05:51 --> Hooks Class Initialized
DEBUG - 2024-01-21 07:05:51 --> UTF-8 Support Enabled
INFO - 2024-01-21 07:05:51 --> Utf8 Class Initialized
INFO - 2024-01-21 07:05:51 --> URI Class Initialized
INFO - 2024-01-21 07:05:51 --> Router Class Initialized
INFO - 2024-01-21 07:05:51 --> Output Class Initialized
INFO - 2024-01-21 07:05:51 --> Security Class Initialized
DEBUG - 2024-01-21 07:05:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-21 07:05:51 --> Input Class Initialized
INFO - 2024-01-21 07:05:51 --> Language Class Initialized
ERROR - 2024-01-21 07:05:51 --> 404 Page Not Found: Loginaction/index
ERROR - 2024-01-21 07:05:51 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-01-21 07:05:51 --> Config Class Initialized
INFO - 2024-01-21 07:05:51 --> Hooks Class Initialized
DEBUG - 2024-01-21 07:05:51 --> UTF-8 Support Enabled
INFO - 2024-01-21 07:05:51 --> Utf8 Class Initialized
ERROR - 2024-01-21 07:05:51 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-01-21 07:05:51 --> Config Class Initialized
INFO - 2024-01-21 07:05:51 --> Hooks Class Initialized
DEBUG - 2024-01-21 07:05:51 --> UTF-8 Support Enabled
INFO - 2024-01-21 07:05:51 --> Utf8 Class Initialized
INFO - 2024-01-21 07:05:51 --> URI Class Initialized
INFO - 2024-01-21 07:05:51 --> Router Class Initialized
INFO - 2024-01-21 07:05:51 --> Output Class Initialized
INFO - 2024-01-21 07:05:51 --> Security Class Initialized
DEBUG - 2024-01-21 07:05:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-21 07:05:51 --> Input Class Initialized
INFO - 2024-01-21 07:05:51 --> Language Class Initialized
ERROR - 2024-01-21 07:05:51 --> 404 Page Not Found: Configjson/index
ERROR - 2024-01-21 07:05:51 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-01-21 07:05:51 --> Config Class Initialized
INFO - 2024-01-21 07:05:51 --> Hooks Class Initialized
DEBUG - 2024-01-21 07:05:51 --> UTF-8 Support Enabled
INFO - 2024-01-21 07:05:51 --> Utf8 Class Initialized
INFO - 2024-01-21 07:05:51 --> URI Class Initialized
INFO - 2024-01-21 07:05:51 --> Router Class Initialized
INFO - 2024-01-21 07:05:51 --> Output Class Initialized
INFO - 2024-01-21 07:05:51 --> Security Class Initialized
DEBUG - 2024-01-21 07:05:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-21 07:05:51 --> Input Class Initialized
INFO - 2024-01-21 07:05:51 --> Language Class Initialized
ERROR - 2024-01-21 07:05:51 --> 404 Page Not Found: Telescope/requests
ERROR - 2024-01-21 07:05:51 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-01-21 07:05:51 --> Config Class Initialized
INFO - 2024-01-21 07:05:51 --> Hooks Class Initialized
DEBUG - 2024-01-21 07:05:51 --> UTF-8 Support Enabled
INFO - 2024-01-21 07:05:51 --> Utf8 Class Initialized
INFO - 2024-01-21 07:05:51 --> URI Class Initialized
DEBUG - 2024-01-21 07:05:51 --> No URI present. Default controller set.
INFO - 2024-01-21 07:05:51 --> Router Class Initialized
INFO - 2024-01-21 07:05:51 --> Output Class Initialized
INFO - 2024-01-21 07:05:51 --> Security Class Initialized
DEBUG - 2024-01-21 07:05:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-21 07:05:51 --> Input Class Initialized
INFO - 2024-01-21 07:05:51 --> Language Class Initialized
INFO - 2024-01-21 07:05:51 --> Loader Class Initialized
INFO - 2024-01-21 07:05:51 --> Helper loaded: url_helper
INFO - 2024-01-21 07:05:51 --> Helper loaded: file_helper
INFO - 2024-01-21 07:05:51 --> Helper loaded: html_helper
INFO - 2024-01-21 07:05:51 --> Helper loaded: text_helper
INFO - 2024-01-21 07:05:51 --> Helper loaded: form_helper
INFO - 2024-01-21 07:05:51 --> Helper loaded: lang_helper
INFO - 2024-01-21 07:05:51 --> Helper loaded: security_helper
INFO - 2024-01-21 07:05:51 --> Helper loaded: cookie_helper
INFO - 2024-01-21 07:05:51 --> Database Driver Class Initialized
INFO - 2024-01-21 07:05:51 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-21 07:05:51 --> Parser Class Initialized
INFO - 2024-01-21 07:05:51 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-01-21 07:05:51 --> Pagination Class Initialized
INFO - 2024-01-21 07:05:51 --> Form Validation Class Initialized
INFO - 2024-01-21 07:05:51 --> Controller Class Initialized
INFO - 2024-01-21 07:05:51 --> Model Class Initialized
DEBUG - 2024-01-21 07:05:51 --> Session class already loaded. Second attempt ignored.
ERROR - 2024-01-21 07:05:52 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-01-21 07:05:52 --> Config Class Initialized
INFO - 2024-01-21 07:05:52 --> Hooks Class Initialized
DEBUG - 2024-01-21 07:05:52 --> UTF-8 Support Enabled
INFO - 2024-01-21 07:05:52 --> Utf8 Class Initialized
INFO - 2024-01-21 07:05:52 --> URI Class Initialized
INFO - 2024-01-21 07:05:52 --> Router Class Initialized
INFO - 2024-01-21 07:05:52 --> Output Class Initialized
INFO - 2024-01-21 07:05:52 --> Security Class Initialized
DEBUG - 2024-01-21 07:05:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-21 07:05:52 --> Input Class Initialized
INFO - 2024-01-21 07:05:52 --> Language Class Initialized
ERROR - 2024-01-21 07:05:52 --> 404 Page Not Found: _all_dbs/index
ERROR - 2024-01-21 07:05:52 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-01-21 07:05:52 --> Config Class Initialized
INFO - 2024-01-21 07:05:52 --> Hooks Class Initialized
DEBUG - 2024-01-21 07:05:52 --> UTF-8 Support Enabled
INFO - 2024-01-21 07:05:52 --> Utf8 Class Initialized
INFO - 2024-01-21 07:05:52 --> URI Class Initialized
INFO - 2024-01-21 07:05:52 --> Router Class Initialized
INFO - 2024-01-21 07:05:52 --> Output Class Initialized
INFO - 2024-01-21 07:05:52 --> Security Class Initialized
DEBUG - 2024-01-21 07:05:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-21 07:05:52 --> Input Class Initialized
INFO - 2024-01-21 07:05:52 --> Language Class Initialized
ERROR - 2024-01-21 07:05:52 --> 404 Page Not Found: DS_Store/index
ERROR - 2024-01-21 07:05:52 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-01-21 07:05:52 --> Config Class Initialized
INFO - 2024-01-21 07:05:52 --> Hooks Class Initialized
DEBUG - 2024-01-21 07:05:52 --> UTF-8 Support Enabled
INFO - 2024-01-21 07:05:52 --> Utf8 Class Initialized
ERROR - 2024-01-21 07:05:52 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-01-21 07:05:52 --> Config Class Initialized
INFO - 2024-01-21 07:05:52 --> Hooks Class Initialized
DEBUG - 2024-01-21 07:05:52 --> UTF-8 Support Enabled
INFO - 2024-01-21 07:05:52 --> Utf8 Class Initialized
INFO - 2024-01-21 07:05:52 --> URI Class Initialized
INFO - 2024-01-21 07:05:52 --> Router Class Initialized
INFO - 2024-01-21 07:05:52 --> Output Class Initialized
INFO - 2024-01-21 07:05:52 --> Security Class Initialized
DEBUG - 2024-01-21 07:05:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-21 07:05:52 --> Input Class Initialized
INFO - 2024-01-21 07:05:52 --> Language Class Initialized
ERROR - 2024-01-21 07:05:52 --> 404 Page Not Found: Configjson/index
ERROR - 2024-01-21 07:05:53 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-01-21 07:05:53 --> Config Class Initialized
INFO - 2024-01-21 07:05:53 --> Hooks Class Initialized
DEBUG - 2024-01-21 07:05:53 --> UTF-8 Support Enabled
INFO - 2024-01-21 07:05:53 --> Utf8 Class Initialized
INFO - 2024-01-21 07:05:53 --> URI Class Initialized
INFO - 2024-01-21 07:05:53 --> Router Class Initialized
INFO - 2024-01-21 07:05:53 --> Output Class Initialized
INFO - 2024-01-21 07:05:53 --> Security Class Initialized
DEBUG - 2024-01-21 07:05:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-21 07:05:53 --> Input Class Initialized
INFO - 2024-01-21 07:05:53 --> Language Class Initialized
ERROR - 2024-01-21 07:05:53 --> 404 Page Not Found: Telescope/requests
ERROR - 2024-01-21 07:05:53 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-01-21 07:05:53 --> Config Class Initialized
INFO - 2024-01-21 07:05:53 --> Hooks Class Initialized
DEBUG - 2024-01-21 07:05:53 --> UTF-8 Support Enabled
INFO - 2024-01-21 07:05:53 --> Utf8 Class Initialized
INFO - 2024-01-21 07:05:53 --> URI Class Initialized
DEBUG - 2024-01-21 07:05:53 --> No URI present. Default controller set.
INFO - 2024-01-21 07:05:53 --> Router Class Initialized
INFO - 2024-01-21 07:05:53 --> Output Class Initialized
INFO - 2024-01-21 07:05:53 --> Security Class Initialized
DEBUG - 2024-01-21 07:05:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-21 07:05:53 --> Input Class Initialized
INFO - 2024-01-21 07:05:53 --> Language Class Initialized
INFO - 2024-01-21 07:05:53 --> Loader Class Initialized
INFO - 2024-01-21 07:05:53 --> Helper loaded: url_helper
INFO - 2024-01-21 07:05:53 --> Helper loaded: file_helper
INFO - 2024-01-21 07:05:53 --> Helper loaded: html_helper
INFO - 2024-01-21 07:05:53 --> Helper loaded: text_helper
INFO - 2024-01-21 07:05:53 --> Helper loaded: form_helper
INFO - 2024-01-21 07:05:53 --> Helper loaded: lang_helper
INFO - 2024-01-21 07:05:53 --> Helper loaded: security_helper
INFO - 2024-01-21 07:05:53 --> Helper loaded: cookie_helper
INFO - 2024-01-21 07:05:53 --> Database Driver Class Initialized
INFO - 2024-01-21 07:05:53 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-21 07:05:53 --> Parser Class Initialized
INFO - 2024-01-21 07:05:53 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-01-21 07:05:53 --> Pagination Class Initialized
INFO - 2024-01-21 07:05:53 --> Form Validation Class Initialized
INFO - 2024-01-21 07:05:53 --> Controller Class Initialized
INFO - 2024-01-21 07:05:53 --> Model Class Initialized
DEBUG - 2024-01-21 07:05:53 --> Session class already loaded. Second attempt ignored.
ERROR - 2024-01-21 07:06:15 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-01-21 07:06:15 --> Config Class Initialized
INFO - 2024-01-21 07:06:15 --> Hooks Class Initialized
DEBUG - 2024-01-21 07:06:15 --> UTF-8 Support Enabled
INFO - 2024-01-21 07:06:15 --> Utf8 Class Initialized
INFO - 2024-01-21 07:06:15 --> URI Class Initialized
DEBUG - 2024-01-21 07:06:15 --> No URI present. Default controller set.
INFO - 2024-01-21 07:06:15 --> Router Class Initialized
INFO - 2024-01-21 07:06:15 --> Output Class Initialized
INFO - 2024-01-21 07:06:15 --> Security Class Initialized
DEBUG - 2024-01-21 07:06:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-21 07:06:15 --> Input Class Initialized
INFO - 2024-01-21 07:06:15 --> Language Class Initialized
INFO - 2024-01-21 07:06:15 --> Loader Class Initialized
INFO - 2024-01-21 07:06:15 --> Helper loaded: url_helper
INFO - 2024-01-21 07:06:15 --> Helper loaded: file_helper
INFO - 2024-01-21 07:06:15 --> Helper loaded: html_helper
INFO - 2024-01-21 07:06:15 --> Helper loaded: text_helper
INFO - 2024-01-21 07:06:15 --> Helper loaded: form_helper
INFO - 2024-01-21 07:06:15 --> Helper loaded: lang_helper
INFO - 2024-01-21 07:06:15 --> Helper loaded: security_helper
INFO - 2024-01-21 07:06:15 --> Helper loaded: cookie_helper
INFO - 2024-01-21 07:06:15 --> Database Driver Class Initialized
INFO - 2024-01-21 07:06:15 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-21 07:06:15 --> Parser Class Initialized
INFO - 2024-01-21 07:06:15 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-01-21 07:06:15 --> Pagination Class Initialized
INFO - 2024-01-21 07:06:15 --> Form Validation Class Initialized
INFO - 2024-01-21 07:06:15 --> Controller Class Initialized
INFO - 2024-01-21 07:06:15 --> Model Class Initialized
DEBUG - 2024-01-21 07:06:15 --> Session class already loaded. Second attempt ignored.
ERROR - 2024-01-21 07:06:16 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-01-21 07:06:16 --> Config Class Initialized
INFO - 2024-01-21 07:06:16 --> Hooks Class Initialized
DEBUG - 2024-01-21 07:06:16 --> UTF-8 Support Enabled
INFO - 2024-01-21 07:06:16 --> Utf8 Class Initialized
INFO - 2024-01-21 07:06:16 --> URI Class Initialized
INFO - 2024-01-21 07:06:16 --> Router Class Initialized
INFO - 2024-01-21 07:06:16 --> Output Class Initialized
INFO - 2024-01-21 07:06:16 --> Security Class Initialized
DEBUG - 2024-01-21 07:06:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-21 07:06:16 --> Input Class Initialized
INFO - 2024-01-21 07:06:16 --> Language Class Initialized
INFO - 2024-01-21 07:06:16 --> Loader Class Initialized
INFO - 2024-01-21 07:06:16 --> Helper loaded: url_helper
INFO - 2024-01-21 07:06:16 --> Helper loaded: file_helper
INFO - 2024-01-21 07:06:16 --> Helper loaded: html_helper
INFO - 2024-01-21 07:06:16 --> Helper loaded: text_helper
INFO - 2024-01-21 07:06:16 --> Helper loaded: form_helper
INFO - 2024-01-21 07:06:16 --> Helper loaded: lang_helper
INFO - 2024-01-21 07:06:16 --> Helper loaded: security_helper
INFO - 2024-01-21 07:06:16 --> Helper loaded: cookie_helper
INFO - 2024-01-21 07:06:16 --> Database Driver Class Initialized
INFO - 2024-01-21 07:06:16 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-21 07:06:16 --> Parser Class Initialized
INFO - 2024-01-21 07:06:16 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-01-21 07:06:16 --> Pagination Class Initialized
INFO - 2024-01-21 07:06:16 --> Form Validation Class Initialized
INFO - 2024-01-21 07:06:16 --> Controller Class Initialized
INFO - 2024-01-21 07:06:16 --> Model Class Initialized
DEBUG - 2024-01-21 07:06:16 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-21 07:06:16 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2024-01-21 07:06:16 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-01-21 07:06:16 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-01-21 07:06:16 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-01-21 07:06:16 --> Model Class Initialized
INFO - 2024-01-21 07:06:16 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-01-21 07:06:16 --> Final output sent to browser
DEBUG - 2024-01-21 07:06:16 --> Total execution time: 0.0328
ERROR - 2024-01-21 07:06:19 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-01-21 07:06:19 --> Config Class Initialized
INFO - 2024-01-21 07:06:19 --> Hooks Class Initialized
DEBUG - 2024-01-21 07:06:19 --> UTF-8 Support Enabled
INFO - 2024-01-21 07:06:19 --> Utf8 Class Initialized
INFO - 2024-01-21 07:06:19 --> URI Class Initialized
DEBUG - 2024-01-21 07:06:19 --> No URI present. Default controller set.
INFO - 2024-01-21 07:06:19 --> Router Class Initialized
INFO - 2024-01-21 07:06:19 --> Output Class Initialized
INFO - 2024-01-21 07:06:19 --> Security Class Initialized
DEBUG - 2024-01-21 07:06:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-21 07:06:19 --> Input Class Initialized
INFO - 2024-01-21 07:06:19 --> Language Class Initialized
INFO - 2024-01-21 07:06:19 --> Loader Class Initialized
INFO - 2024-01-21 07:06:19 --> Helper loaded: url_helper
INFO - 2024-01-21 07:06:19 --> Helper loaded: file_helper
INFO - 2024-01-21 07:06:19 --> Helper loaded: html_helper
INFO - 2024-01-21 07:06:19 --> Helper loaded: text_helper
INFO - 2024-01-21 07:06:19 --> Helper loaded: form_helper
INFO - 2024-01-21 07:06:19 --> Helper loaded: lang_helper
INFO - 2024-01-21 07:06:19 --> Helper loaded: security_helper
INFO - 2024-01-21 07:06:19 --> Helper loaded: cookie_helper
INFO - 2024-01-21 07:06:19 --> Database Driver Class Initialized
INFO - 2024-01-21 07:06:19 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-21 07:06:19 --> Parser Class Initialized
INFO - 2024-01-21 07:06:19 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-01-21 07:06:19 --> Pagination Class Initialized
INFO - 2024-01-21 07:06:19 --> Form Validation Class Initialized
INFO - 2024-01-21 07:06:19 --> Controller Class Initialized
INFO - 2024-01-21 07:06:19 --> Model Class Initialized
DEBUG - 2024-01-21 07:06:19 --> Session class already loaded. Second attempt ignored.
ERROR - 2024-01-21 07:06:19 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-01-21 07:06:19 --> Config Class Initialized
INFO - 2024-01-21 07:06:19 --> Hooks Class Initialized
DEBUG - 2024-01-21 07:06:19 --> UTF-8 Support Enabled
INFO - 2024-01-21 07:06:19 --> Utf8 Class Initialized
INFO - 2024-01-21 07:06:19 --> URI Class Initialized
INFO - 2024-01-21 07:06:19 --> Router Class Initialized
INFO - 2024-01-21 07:06:19 --> Output Class Initialized
INFO - 2024-01-21 07:06:19 --> Security Class Initialized
DEBUG - 2024-01-21 07:06:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-21 07:06:19 --> Input Class Initialized
INFO - 2024-01-21 07:06:19 --> Language Class Initialized
INFO - 2024-01-21 07:06:19 --> Loader Class Initialized
INFO - 2024-01-21 07:06:19 --> Helper loaded: url_helper
INFO - 2024-01-21 07:06:19 --> Helper loaded: file_helper
INFO - 2024-01-21 07:06:19 --> Helper loaded: html_helper
INFO - 2024-01-21 07:06:19 --> Helper loaded: text_helper
INFO - 2024-01-21 07:06:19 --> Helper loaded: form_helper
INFO - 2024-01-21 07:06:19 --> Helper loaded: lang_helper
INFO - 2024-01-21 07:06:19 --> Helper loaded: security_helper
INFO - 2024-01-21 07:06:19 --> Helper loaded: cookie_helper
INFO - 2024-01-21 07:06:19 --> Database Driver Class Initialized
INFO - 2024-01-21 07:06:19 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-21 07:06:19 --> Parser Class Initialized
INFO - 2024-01-21 07:06:19 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-01-21 07:06:19 --> Pagination Class Initialized
INFO - 2024-01-21 07:06:19 --> Form Validation Class Initialized
INFO - 2024-01-21 07:06:19 --> Controller Class Initialized
INFO - 2024-01-21 07:06:19 --> Model Class Initialized
DEBUG - 2024-01-21 07:06:19 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-21 07:06:19 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2024-01-21 07:06:19 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-01-21 07:06:19 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-01-21 07:06:19 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-01-21 07:06:19 --> Model Class Initialized
INFO - 2024-01-21 07:06:19 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-01-21 07:06:19 --> Final output sent to browser
DEBUG - 2024-01-21 07:06:19 --> Total execution time: 0.0335
ERROR - 2024-01-21 07:06:36 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-01-21 07:06:36 --> Config Class Initialized
INFO - 2024-01-21 07:06:36 --> Hooks Class Initialized
DEBUG - 2024-01-21 07:06:36 --> UTF-8 Support Enabled
INFO - 2024-01-21 07:06:36 --> Utf8 Class Initialized
INFO - 2024-01-21 07:06:36 --> URI Class Initialized
DEBUG - 2024-01-21 07:06:36 --> No URI present. Default controller set.
INFO - 2024-01-21 07:06:36 --> Router Class Initialized
INFO - 2024-01-21 07:06:36 --> Output Class Initialized
INFO - 2024-01-21 07:06:36 --> Security Class Initialized
DEBUG - 2024-01-21 07:06:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-21 07:06:36 --> Input Class Initialized
INFO - 2024-01-21 07:06:36 --> Language Class Initialized
INFO - 2024-01-21 07:06:36 --> Loader Class Initialized
INFO - 2024-01-21 07:06:36 --> Helper loaded: url_helper
INFO - 2024-01-21 07:06:36 --> Helper loaded: file_helper
INFO - 2024-01-21 07:06:36 --> Helper loaded: html_helper
INFO - 2024-01-21 07:06:36 --> Helper loaded: text_helper
INFO - 2024-01-21 07:06:36 --> Helper loaded: form_helper
INFO - 2024-01-21 07:06:36 --> Helper loaded: lang_helper
INFO - 2024-01-21 07:06:36 --> Helper loaded: security_helper
INFO - 2024-01-21 07:06:36 --> Helper loaded: cookie_helper
INFO - 2024-01-21 07:06:36 --> Database Driver Class Initialized
INFO - 2024-01-21 07:06:36 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-21 07:06:36 --> Parser Class Initialized
INFO - 2024-01-21 07:06:36 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-01-21 07:06:36 --> Pagination Class Initialized
INFO - 2024-01-21 07:06:36 --> Form Validation Class Initialized
INFO - 2024-01-21 07:06:36 --> Controller Class Initialized
INFO - 2024-01-21 07:06:36 --> Model Class Initialized
DEBUG - 2024-01-21 07:06:36 --> Session class already loaded. Second attempt ignored.
ERROR - 2024-01-21 07:06:38 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-01-21 07:06:38 --> Config Class Initialized
INFO - 2024-01-21 07:06:38 --> Hooks Class Initialized
DEBUG - 2024-01-21 07:06:38 --> UTF-8 Support Enabled
INFO - 2024-01-21 07:06:38 --> Utf8 Class Initialized
INFO - 2024-01-21 07:06:38 --> URI Class Initialized
DEBUG - 2024-01-21 07:06:38 --> No URI present. Default controller set.
INFO - 2024-01-21 07:06:38 --> Router Class Initialized
INFO - 2024-01-21 07:06:38 --> Output Class Initialized
INFO - 2024-01-21 07:06:38 --> Security Class Initialized
DEBUG - 2024-01-21 07:06:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-21 07:06:38 --> Input Class Initialized
INFO - 2024-01-21 07:06:38 --> Language Class Initialized
INFO - 2024-01-21 07:06:38 --> Loader Class Initialized
INFO - 2024-01-21 07:06:38 --> Helper loaded: url_helper
INFO - 2024-01-21 07:06:38 --> Helper loaded: file_helper
INFO - 2024-01-21 07:06:38 --> Helper loaded: html_helper
INFO - 2024-01-21 07:06:38 --> Helper loaded: text_helper
INFO - 2024-01-21 07:06:38 --> Helper loaded: form_helper
INFO - 2024-01-21 07:06:38 --> Helper loaded: lang_helper
INFO - 2024-01-21 07:06:38 --> Helper loaded: security_helper
INFO - 2024-01-21 07:06:38 --> Helper loaded: cookie_helper
INFO - 2024-01-21 07:06:38 --> Database Driver Class Initialized
INFO - 2024-01-21 07:06:38 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-21 07:06:38 --> Parser Class Initialized
INFO - 2024-01-21 07:06:38 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-01-21 07:06:38 --> Pagination Class Initialized
INFO - 2024-01-21 07:06:38 --> Form Validation Class Initialized
INFO - 2024-01-21 07:06:38 --> Controller Class Initialized
INFO - 2024-01-21 07:06:38 --> Model Class Initialized
DEBUG - 2024-01-21 07:06:38 --> Session class already loaded. Second attempt ignored.
ERROR - 2024-01-21 07:06:40 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-01-21 07:06:40 --> Config Class Initialized
INFO - 2024-01-21 07:06:40 --> Hooks Class Initialized
DEBUG - 2024-01-21 07:06:40 --> UTF-8 Support Enabled
INFO - 2024-01-21 07:06:40 --> Utf8 Class Initialized
INFO - 2024-01-21 07:06:40 --> URI Class Initialized
DEBUG - 2024-01-21 07:06:40 --> No URI present. Default controller set.
INFO - 2024-01-21 07:06:40 --> Router Class Initialized
INFO - 2024-01-21 07:06:40 --> Output Class Initialized
INFO - 2024-01-21 07:06:40 --> Security Class Initialized
DEBUG - 2024-01-21 07:06:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-21 07:06:40 --> Input Class Initialized
INFO - 2024-01-21 07:06:40 --> Language Class Initialized
INFO - 2024-01-21 07:06:40 --> Loader Class Initialized
INFO - 2024-01-21 07:06:40 --> Helper loaded: url_helper
INFO - 2024-01-21 07:06:40 --> Helper loaded: file_helper
INFO - 2024-01-21 07:06:40 --> Helper loaded: html_helper
INFO - 2024-01-21 07:06:40 --> Helper loaded: text_helper
INFO - 2024-01-21 07:06:40 --> Helper loaded: form_helper
INFO - 2024-01-21 07:06:40 --> Helper loaded: lang_helper
INFO - 2024-01-21 07:06:40 --> Helper loaded: security_helper
INFO - 2024-01-21 07:06:40 --> Helper loaded: cookie_helper
INFO - 2024-01-21 07:06:40 --> Database Driver Class Initialized
INFO - 2024-01-21 07:06:40 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-21 07:06:40 --> Parser Class Initialized
INFO - 2024-01-21 07:06:40 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-01-21 07:06:40 --> Pagination Class Initialized
INFO - 2024-01-21 07:06:40 --> Form Validation Class Initialized
INFO - 2024-01-21 07:06:40 --> Controller Class Initialized
INFO - 2024-01-21 07:06:40 --> Model Class Initialized
DEBUG - 2024-01-21 07:06:40 --> Session class already loaded. Second attempt ignored.
ERROR - 2024-01-21 07:07:06 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-01-21 07:07:06 --> Config Class Initialized
INFO - 2024-01-21 07:07:06 --> Hooks Class Initialized
DEBUG - 2024-01-21 07:07:06 --> UTF-8 Support Enabled
INFO - 2024-01-21 07:07:06 --> Utf8 Class Initialized
INFO - 2024-01-21 07:07:06 --> URI Class Initialized
DEBUG - 2024-01-21 07:07:06 --> No URI present. Default controller set.
INFO - 2024-01-21 07:07:06 --> Router Class Initialized
INFO - 2024-01-21 07:07:06 --> Output Class Initialized
INFO - 2024-01-21 07:07:06 --> Security Class Initialized
DEBUG - 2024-01-21 07:07:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-21 07:07:06 --> Input Class Initialized
INFO - 2024-01-21 07:07:06 --> Language Class Initialized
INFO - 2024-01-21 07:07:06 --> Loader Class Initialized
INFO - 2024-01-21 07:07:06 --> Helper loaded: url_helper
INFO - 2024-01-21 07:07:06 --> Helper loaded: file_helper
INFO - 2024-01-21 07:07:06 --> Helper loaded: html_helper
INFO - 2024-01-21 07:07:06 --> Helper loaded: text_helper
INFO - 2024-01-21 07:07:06 --> Helper loaded: form_helper
INFO - 2024-01-21 07:07:06 --> Helper loaded: lang_helper
INFO - 2024-01-21 07:07:06 --> Helper loaded: security_helper
INFO - 2024-01-21 07:07:06 --> Helper loaded: cookie_helper
INFO - 2024-01-21 07:07:06 --> Database Driver Class Initialized
INFO - 2024-01-21 07:07:06 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-21 07:07:06 --> Parser Class Initialized
INFO - 2024-01-21 07:07:06 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-01-21 07:07:06 --> Pagination Class Initialized
INFO - 2024-01-21 07:07:06 --> Form Validation Class Initialized
INFO - 2024-01-21 07:07:06 --> Controller Class Initialized
INFO - 2024-01-21 07:07:06 --> Model Class Initialized
DEBUG - 2024-01-21 07:07:06 --> Session class already loaded. Second attempt ignored.
ERROR - 2024-01-21 07:07:32 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-01-21 07:07:32 --> Config Class Initialized
INFO - 2024-01-21 07:07:32 --> Hooks Class Initialized
DEBUG - 2024-01-21 07:07:32 --> UTF-8 Support Enabled
INFO - 2024-01-21 07:07:32 --> Utf8 Class Initialized
INFO - 2024-01-21 07:07:32 --> URI Class Initialized
DEBUG - 2024-01-21 07:07:32 --> No URI present. Default controller set.
INFO - 2024-01-21 07:07:32 --> Router Class Initialized
INFO - 2024-01-21 07:07:32 --> Output Class Initialized
INFO - 2024-01-21 07:07:32 --> Security Class Initialized
DEBUG - 2024-01-21 07:07:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-21 07:07:32 --> Input Class Initialized
INFO - 2024-01-21 07:07:32 --> Language Class Initialized
INFO - 2024-01-21 07:07:32 --> Loader Class Initialized
INFO - 2024-01-21 07:07:32 --> Helper loaded: url_helper
INFO - 2024-01-21 07:07:32 --> Helper loaded: file_helper
INFO - 2024-01-21 07:07:32 --> Helper loaded: html_helper
INFO - 2024-01-21 07:07:32 --> Helper loaded: text_helper
INFO - 2024-01-21 07:07:32 --> Helper loaded: form_helper
INFO - 2024-01-21 07:07:32 --> Helper loaded: lang_helper
INFO - 2024-01-21 07:07:32 --> Helper loaded: security_helper
INFO - 2024-01-21 07:07:32 --> Helper loaded: cookie_helper
INFO - 2024-01-21 07:07:32 --> Database Driver Class Initialized
INFO - 2024-01-21 07:07:32 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-21 07:07:32 --> Parser Class Initialized
INFO - 2024-01-21 07:07:32 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-01-21 07:07:32 --> Pagination Class Initialized
INFO - 2024-01-21 07:07:32 --> Form Validation Class Initialized
INFO - 2024-01-21 07:07:32 --> Controller Class Initialized
INFO - 2024-01-21 07:07:32 --> Model Class Initialized
DEBUG - 2024-01-21 07:07:32 --> Session class already loaded. Second attempt ignored.
ERROR - 2024-01-21 07:07:32 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-01-21 07:07:32 --> Config Class Initialized
INFO - 2024-01-21 07:07:32 --> Hooks Class Initialized
DEBUG - 2024-01-21 07:07:32 --> UTF-8 Support Enabled
INFO - 2024-01-21 07:07:32 --> Utf8 Class Initialized
INFO - 2024-01-21 07:07:32 --> URI Class Initialized
INFO - 2024-01-21 07:07:32 --> Router Class Initialized
INFO - 2024-01-21 07:07:32 --> Output Class Initialized
INFO - 2024-01-21 07:07:32 --> Security Class Initialized
DEBUG - 2024-01-21 07:07:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-21 07:07:32 --> Input Class Initialized
INFO - 2024-01-21 07:07:32 --> Language Class Initialized
INFO - 2024-01-21 07:07:32 --> Loader Class Initialized
INFO - 2024-01-21 07:07:32 --> Helper loaded: url_helper
INFO - 2024-01-21 07:07:32 --> Helper loaded: file_helper
INFO - 2024-01-21 07:07:32 --> Helper loaded: html_helper
INFO - 2024-01-21 07:07:32 --> Helper loaded: text_helper
INFO - 2024-01-21 07:07:32 --> Helper loaded: form_helper
INFO - 2024-01-21 07:07:32 --> Helper loaded: lang_helper
INFO - 2024-01-21 07:07:32 --> Helper loaded: security_helper
INFO - 2024-01-21 07:07:32 --> Helper loaded: cookie_helper
INFO - 2024-01-21 07:07:32 --> Database Driver Class Initialized
INFO - 2024-01-21 07:07:32 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-21 07:07:32 --> Parser Class Initialized
INFO - 2024-01-21 07:07:32 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-01-21 07:07:32 --> Pagination Class Initialized
INFO - 2024-01-21 07:07:32 --> Form Validation Class Initialized
INFO - 2024-01-21 07:07:32 --> Controller Class Initialized
INFO - 2024-01-21 07:07:32 --> Model Class Initialized
DEBUG - 2024-01-21 07:07:32 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-21 07:07:32 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2024-01-21 07:07:32 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-01-21 07:07:32 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-01-21 07:07:32 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-01-21 07:07:32 --> Model Class Initialized
INFO - 2024-01-21 07:07:32 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-01-21 07:07:32 --> Final output sent to browser
DEBUG - 2024-01-21 07:07:32 --> Total execution time: 0.0326
ERROR - 2024-01-21 07:08:10 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-01-21 07:08:10 --> Config Class Initialized
INFO - 2024-01-21 07:08:10 --> Hooks Class Initialized
DEBUG - 2024-01-21 07:08:10 --> UTF-8 Support Enabled
INFO - 2024-01-21 07:08:10 --> Utf8 Class Initialized
INFO - 2024-01-21 07:08:10 --> URI Class Initialized
DEBUG - 2024-01-21 07:08:10 --> No URI present. Default controller set.
INFO - 2024-01-21 07:08:10 --> Router Class Initialized
INFO - 2024-01-21 07:08:10 --> Output Class Initialized
INFO - 2024-01-21 07:08:10 --> Security Class Initialized
DEBUG - 2024-01-21 07:08:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-21 07:08:10 --> Input Class Initialized
INFO - 2024-01-21 07:08:10 --> Language Class Initialized
INFO - 2024-01-21 07:08:10 --> Loader Class Initialized
INFO - 2024-01-21 07:08:10 --> Helper loaded: url_helper
INFO - 2024-01-21 07:08:10 --> Helper loaded: file_helper
INFO - 2024-01-21 07:08:10 --> Helper loaded: html_helper
INFO - 2024-01-21 07:08:10 --> Helper loaded: text_helper
INFO - 2024-01-21 07:08:10 --> Helper loaded: form_helper
INFO - 2024-01-21 07:08:10 --> Helper loaded: lang_helper
INFO - 2024-01-21 07:08:10 --> Helper loaded: security_helper
INFO - 2024-01-21 07:08:10 --> Helper loaded: cookie_helper
INFO - 2024-01-21 07:08:10 --> Database Driver Class Initialized
INFO - 2024-01-21 07:08:10 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-21 07:08:10 --> Parser Class Initialized
INFO - 2024-01-21 07:08:10 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-01-21 07:08:10 --> Pagination Class Initialized
INFO - 2024-01-21 07:08:10 --> Form Validation Class Initialized
INFO - 2024-01-21 07:08:10 --> Controller Class Initialized
INFO - 2024-01-21 07:08:10 --> Model Class Initialized
DEBUG - 2024-01-21 07:08:10 --> Session class already loaded. Second attempt ignored.
ERROR - 2024-01-21 07:08:10 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-01-21 07:08:10 --> Config Class Initialized
INFO - 2024-01-21 07:08:10 --> Hooks Class Initialized
DEBUG - 2024-01-21 07:08:10 --> UTF-8 Support Enabled
INFO - 2024-01-21 07:08:10 --> Utf8 Class Initialized
INFO - 2024-01-21 07:08:10 --> URI Class Initialized
INFO - 2024-01-21 07:08:10 --> Router Class Initialized
INFO - 2024-01-21 07:08:10 --> Output Class Initialized
INFO - 2024-01-21 07:08:10 --> Security Class Initialized
DEBUG - 2024-01-21 07:08:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-21 07:08:10 --> Input Class Initialized
INFO - 2024-01-21 07:08:10 --> Language Class Initialized
INFO - 2024-01-21 07:08:10 --> Loader Class Initialized
INFO - 2024-01-21 07:08:10 --> Helper loaded: url_helper
INFO - 2024-01-21 07:08:10 --> Helper loaded: file_helper
INFO - 2024-01-21 07:08:10 --> Helper loaded: html_helper
INFO - 2024-01-21 07:08:10 --> Helper loaded: text_helper
INFO - 2024-01-21 07:08:10 --> Helper loaded: form_helper
INFO - 2024-01-21 07:08:10 --> Helper loaded: lang_helper
INFO - 2024-01-21 07:08:10 --> Helper loaded: security_helper
INFO - 2024-01-21 07:08:10 --> Helper loaded: cookie_helper
INFO - 2024-01-21 07:08:10 --> Database Driver Class Initialized
INFO - 2024-01-21 07:08:10 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-21 07:08:10 --> Parser Class Initialized
INFO - 2024-01-21 07:08:10 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-01-21 07:08:10 --> Pagination Class Initialized
INFO - 2024-01-21 07:08:10 --> Form Validation Class Initialized
INFO - 2024-01-21 07:08:10 --> Controller Class Initialized
INFO - 2024-01-21 07:08:10 --> Model Class Initialized
DEBUG - 2024-01-21 07:08:10 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-21 07:08:11 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2024-01-21 07:08:11 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-01-21 07:08:11 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-01-21 07:08:11 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-01-21 07:08:11 --> Model Class Initialized
INFO - 2024-01-21 07:08:11 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-01-21 07:08:11 --> Final output sent to browser
DEBUG - 2024-01-21 07:08:11 --> Total execution time: 0.0313
ERROR - 2024-01-21 13:06:32 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-01-21 13:06:32 --> Config Class Initialized
INFO - 2024-01-21 13:06:32 --> Hooks Class Initialized
DEBUG - 2024-01-21 13:06:32 --> UTF-8 Support Enabled
INFO - 2024-01-21 13:06:32 --> Utf8 Class Initialized
INFO - 2024-01-21 13:06:32 --> URI Class Initialized
DEBUG - 2024-01-21 13:06:32 --> No URI present. Default controller set.
INFO - 2024-01-21 13:06:32 --> Router Class Initialized
INFO - 2024-01-21 13:06:32 --> Output Class Initialized
INFO - 2024-01-21 13:06:32 --> Security Class Initialized
DEBUG - 2024-01-21 13:06:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-21 13:06:32 --> Input Class Initialized
INFO - 2024-01-21 13:06:32 --> Language Class Initialized
INFO - 2024-01-21 13:06:32 --> Loader Class Initialized
INFO - 2024-01-21 13:06:32 --> Helper loaded: url_helper
INFO - 2024-01-21 13:06:32 --> Helper loaded: file_helper
INFO - 2024-01-21 13:06:32 --> Helper loaded: html_helper
INFO - 2024-01-21 13:06:32 --> Helper loaded: text_helper
INFO - 2024-01-21 13:06:32 --> Helper loaded: form_helper
INFO - 2024-01-21 13:06:32 --> Helper loaded: lang_helper
INFO - 2024-01-21 13:06:32 --> Helper loaded: security_helper
INFO - 2024-01-21 13:06:32 --> Helper loaded: cookie_helper
INFO - 2024-01-21 13:06:32 --> Database Driver Class Initialized
INFO - 2024-01-21 13:06:32 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-21 13:06:32 --> Parser Class Initialized
INFO - 2024-01-21 13:06:32 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-01-21 13:06:32 --> Pagination Class Initialized
INFO - 2024-01-21 13:06:32 --> Form Validation Class Initialized
INFO - 2024-01-21 13:06:32 --> Controller Class Initialized
INFO - 2024-01-21 13:06:32 --> Model Class Initialized
DEBUG - 2024-01-21 13:06:32 --> Session class already loaded. Second attempt ignored.
ERROR - 2024-01-21 13:06:32 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-01-21 13:06:32 --> Config Class Initialized
INFO - 2024-01-21 13:06:32 --> Hooks Class Initialized
DEBUG - 2024-01-21 13:06:32 --> UTF-8 Support Enabled
INFO - 2024-01-21 13:06:32 --> Utf8 Class Initialized
INFO - 2024-01-21 13:06:32 --> URI Class Initialized
INFO - 2024-01-21 13:06:32 --> Router Class Initialized
INFO - 2024-01-21 13:06:32 --> Output Class Initialized
INFO - 2024-01-21 13:06:32 --> Security Class Initialized
DEBUG - 2024-01-21 13:06:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-21 13:06:32 --> Input Class Initialized
INFO - 2024-01-21 13:06:32 --> Language Class Initialized
INFO - 2024-01-21 13:06:32 --> Loader Class Initialized
INFO - 2024-01-21 13:06:32 --> Helper loaded: url_helper
INFO - 2024-01-21 13:06:32 --> Helper loaded: file_helper
INFO - 2024-01-21 13:06:32 --> Helper loaded: html_helper
INFO - 2024-01-21 13:06:32 --> Helper loaded: text_helper
INFO - 2024-01-21 13:06:32 --> Helper loaded: form_helper
INFO - 2024-01-21 13:06:32 --> Helper loaded: lang_helper
INFO - 2024-01-21 13:06:32 --> Helper loaded: security_helper
INFO - 2024-01-21 13:06:32 --> Helper loaded: cookie_helper
INFO - 2024-01-21 13:06:32 --> Database Driver Class Initialized
INFO - 2024-01-21 13:06:32 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-21 13:06:32 --> Parser Class Initialized
INFO - 2024-01-21 13:06:32 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-01-21 13:06:32 --> Pagination Class Initialized
INFO - 2024-01-21 13:06:32 --> Form Validation Class Initialized
INFO - 2024-01-21 13:06:32 --> Controller Class Initialized
INFO - 2024-01-21 13:06:32 --> Model Class Initialized
DEBUG - 2024-01-21 13:06:32 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-21 13:06:32 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2024-01-21 13:06:32 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-01-21 13:06:32 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-01-21 13:06:32 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-01-21 13:06:32 --> Model Class Initialized
INFO - 2024-01-21 13:06:32 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-01-21 13:06:32 --> Final output sent to browser
DEBUG - 2024-01-21 13:06:32 --> Total execution time: 0.0391
ERROR - 2024-01-21 15:06:21 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-01-21 15:06:21 --> Config Class Initialized
INFO - 2024-01-21 15:06:21 --> Hooks Class Initialized
DEBUG - 2024-01-21 15:06:21 --> UTF-8 Support Enabled
INFO - 2024-01-21 15:06:21 --> Utf8 Class Initialized
INFO - 2024-01-21 15:06:21 --> URI Class Initialized
DEBUG - 2024-01-21 15:06:21 --> No URI present. Default controller set.
INFO - 2024-01-21 15:06:21 --> Router Class Initialized
INFO - 2024-01-21 15:06:21 --> Output Class Initialized
INFO - 2024-01-21 15:06:21 --> Security Class Initialized
DEBUG - 2024-01-21 15:06:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-21 15:06:21 --> Input Class Initialized
INFO - 2024-01-21 15:06:21 --> Language Class Initialized
INFO - 2024-01-21 15:06:21 --> Loader Class Initialized
INFO - 2024-01-21 15:06:21 --> Helper loaded: url_helper
INFO - 2024-01-21 15:06:21 --> Helper loaded: file_helper
INFO - 2024-01-21 15:06:21 --> Helper loaded: html_helper
INFO - 2024-01-21 15:06:21 --> Helper loaded: text_helper
INFO - 2024-01-21 15:06:21 --> Helper loaded: form_helper
INFO - 2024-01-21 15:06:21 --> Helper loaded: lang_helper
INFO - 2024-01-21 15:06:21 --> Helper loaded: security_helper
INFO - 2024-01-21 15:06:21 --> Helper loaded: cookie_helper
INFO - 2024-01-21 15:06:21 --> Database Driver Class Initialized
INFO - 2024-01-21 15:06:21 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-21 15:06:21 --> Parser Class Initialized
INFO - 2024-01-21 15:06:21 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-01-21 15:06:21 --> Pagination Class Initialized
INFO - 2024-01-21 15:06:21 --> Form Validation Class Initialized
INFO - 2024-01-21 15:06:21 --> Controller Class Initialized
INFO - 2024-01-21 15:06:21 --> Model Class Initialized
DEBUG - 2024-01-21 15:06:21 --> Session class already loaded. Second attempt ignored.
ERROR - 2024-01-21 15:21:22 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-01-21 15:21:22 --> Config Class Initialized
INFO - 2024-01-21 15:21:22 --> Hooks Class Initialized
DEBUG - 2024-01-21 15:21:22 --> UTF-8 Support Enabled
INFO - 2024-01-21 15:21:22 --> Utf8 Class Initialized
INFO - 2024-01-21 15:21:22 --> URI Class Initialized
DEBUG - 2024-01-21 15:21:22 --> No URI present. Default controller set.
INFO - 2024-01-21 15:21:22 --> Router Class Initialized
INFO - 2024-01-21 15:21:22 --> Output Class Initialized
INFO - 2024-01-21 15:21:22 --> Security Class Initialized
DEBUG - 2024-01-21 15:21:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-21 15:21:22 --> Input Class Initialized
INFO - 2024-01-21 15:21:22 --> Language Class Initialized
INFO - 2024-01-21 15:21:22 --> Loader Class Initialized
INFO - 2024-01-21 15:21:22 --> Helper loaded: url_helper
INFO - 2024-01-21 15:21:22 --> Helper loaded: file_helper
INFO - 2024-01-21 15:21:22 --> Helper loaded: html_helper
INFO - 2024-01-21 15:21:22 --> Helper loaded: text_helper
INFO - 2024-01-21 15:21:22 --> Helper loaded: form_helper
INFO - 2024-01-21 15:21:22 --> Helper loaded: lang_helper
INFO - 2024-01-21 15:21:22 --> Helper loaded: security_helper
INFO - 2024-01-21 15:21:22 --> Helper loaded: cookie_helper
INFO - 2024-01-21 15:21:22 --> Database Driver Class Initialized
INFO - 2024-01-21 15:21:22 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-21 15:21:22 --> Parser Class Initialized
INFO - 2024-01-21 15:21:22 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-01-21 15:21:22 --> Pagination Class Initialized
INFO - 2024-01-21 15:21:22 --> Form Validation Class Initialized
INFO - 2024-01-21 15:21:22 --> Controller Class Initialized
INFO - 2024-01-21 15:21:22 --> Model Class Initialized
DEBUG - 2024-01-21 15:21:22 --> Session class already loaded. Second attempt ignored.
ERROR - 2024-01-21 17:10:50 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-01-21 17:10:50 --> Config Class Initialized
INFO - 2024-01-21 17:10:50 --> Hooks Class Initialized
DEBUG - 2024-01-21 17:10:50 --> UTF-8 Support Enabled
INFO - 2024-01-21 17:10:50 --> Utf8 Class Initialized
INFO - 2024-01-21 17:10:50 --> URI Class Initialized
INFO - 2024-01-21 17:10:50 --> Router Class Initialized
INFO - 2024-01-21 17:10:50 --> Output Class Initialized
INFO - 2024-01-21 17:10:50 --> Security Class Initialized
DEBUG - 2024-01-21 17:10:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-21 17:10:50 --> Input Class Initialized
INFO - 2024-01-21 17:10:50 --> Language Class Initialized
ERROR - 2024-01-21 17:10:50 --> 404 Page Not Found: Wp-loginphp/index
ERROR - 2024-01-21 17:30:11 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-01-21 17:30:11 --> Config Class Initialized
INFO - 2024-01-21 17:30:11 --> Hooks Class Initialized
DEBUG - 2024-01-21 17:30:11 --> UTF-8 Support Enabled
INFO - 2024-01-21 17:30:11 --> Utf8 Class Initialized
INFO - 2024-01-21 17:30:11 --> URI Class Initialized
DEBUG - 2024-01-21 17:30:11 --> No URI present. Default controller set.
INFO - 2024-01-21 17:30:11 --> Router Class Initialized
INFO - 2024-01-21 17:30:11 --> Output Class Initialized
INFO - 2024-01-21 17:30:11 --> Security Class Initialized
DEBUG - 2024-01-21 17:30:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-21 17:30:11 --> Input Class Initialized
INFO - 2024-01-21 17:30:11 --> Language Class Initialized
INFO - 2024-01-21 17:30:11 --> Loader Class Initialized
INFO - 2024-01-21 17:30:11 --> Helper loaded: url_helper
INFO - 2024-01-21 17:30:11 --> Helper loaded: file_helper
INFO - 2024-01-21 17:30:11 --> Helper loaded: html_helper
INFO - 2024-01-21 17:30:11 --> Helper loaded: text_helper
INFO - 2024-01-21 17:30:11 --> Helper loaded: form_helper
INFO - 2024-01-21 17:30:11 --> Helper loaded: lang_helper
INFO - 2024-01-21 17:30:11 --> Helper loaded: security_helper
INFO - 2024-01-21 17:30:11 --> Helper loaded: cookie_helper
INFO - 2024-01-21 17:30:11 --> Database Driver Class Initialized
INFO - 2024-01-21 17:30:11 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-21 17:30:11 --> Parser Class Initialized
INFO - 2024-01-21 17:30:11 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-01-21 17:30:11 --> Pagination Class Initialized
INFO - 2024-01-21 17:30:11 --> Form Validation Class Initialized
INFO - 2024-01-21 17:30:11 --> Controller Class Initialized
INFO - 2024-01-21 17:30:11 --> Model Class Initialized
DEBUG - 2024-01-21 17:30:11 --> Session class already loaded. Second attempt ignored.
ERROR - 2024-01-21 20:29:28 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-01-21 20:29:28 --> Config Class Initialized
INFO - 2024-01-21 20:29:28 --> Hooks Class Initialized
DEBUG - 2024-01-21 20:29:28 --> UTF-8 Support Enabled
INFO - 2024-01-21 20:29:28 --> Utf8 Class Initialized
INFO - 2024-01-21 20:29:28 --> URI Class Initialized
INFO - 2024-01-21 20:29:28 --> Router Class Initialized
INFO - 2024-01-21 20:29:28 --> Output Class Initialized
INFO - 2024-01-21 20:29:28 --> Security Class Initialized
DEBUG - 2024-01-21 20:29:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-21 20:29:28 --> Input Class Initialized
INFO - 2024-01-21 20:29:28 --> Language Class Initialized
ERROR - 2024-01-21 20:29:28 --> 404 Page Not Found: Well-known/assetlinks.json
ERROR - 2024-01-21 23:29:29 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-01-21 23:29:29 --> Config Class Initialized
INFO - 2024-01-21 23:29:29 --> Hooks Class Initialized
DEBUG - 2024-01-21 23:29:29 --> UTF-8 Support Enabled
INFO - 2024-01-21 23:29:29 --> Utf8 Class Initialized
INFO - 2024-01-21 23:29:29 --> URI Class Initialized
INFO - 2024-01-21 23:29:29 --> Router Class Initialized
INFO - 2024-01-21 23:29:29 --> Output Class Initialized
INFO - 2024-01-21 23:29:29 --> Security Class Initialized
DEBUG - 2024-01-21 23:29:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-21 23:29:29 --> Input Class Initialized
INFO - 2024-01-21 23:29:29 --> Language Class Initialized
ERROR - 2024-01-21 23:29:29 --> 404 Page Not Found: Well-known/assetlinks.json
