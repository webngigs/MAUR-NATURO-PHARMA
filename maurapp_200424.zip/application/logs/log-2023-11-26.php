<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2023-11-26 03:08:08 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-11-26 03:08:08 --> Config Class Initialized
INFO - 2023-11-26 03:08:08 --> Hooks Class Initialized
DEBUG - 2023-11-26 03:08:08 --> UTF-8 Support Enabled
INFO - 2023-11-26 03:08:08 --> Utf8 Class Initialized
INFO - 2023-11-26 03:08:08 --> URI Class Initialized
INFO - 2023-11-26 03:08:08 --> Router Class Initialized
INFO - 2023-11-26 03:08:08 --> Output Class Initialized
INFO - 2023-11-26 03:08:08 --> Security Class Initialized
DEBUG - 2023-11-26 03:08:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-26 03:08:08 --> Input Class Initialized
INFO - 2023-11-26 03:08:08 --> Language Class Initialized
ERROR - 2023-11-26 03:08:08 --> 404 Page Not Found: Well-known/assetlinks.json
ERROR - 2023-11-26 03:38:04 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-11-26 03:38:04 --> Config Class Initialized
INFO - 2023-11-26 03:38:04 --> Hooks Class Initialized
DEBUG - 2023-11-26 03:38:04 --> UTF-8 Support Enabled
INFO - 2023-11-26 03:38:04 --> Utf8 Class Initialized
INFO - 2023-11-26 03:38:04 --> URI Class Initialized
DEBUG - 2023-11-26 03:38:04 --> No URI present. Default controller set.
INFO - 2023-11-26 03:38:04 --> Router Class Initialized
INFO - 2023-11-26 03:38:04 --> Output Class Initialized
INFO - 2023-11-26 03:38:04 --> Security Class Initialized
DEBUG - 2023-11-26 03:38:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-26 03:38:04 --> Input Class Initialized
INFO - 2023-11-26 03:38:04 --> Language Class Initialized
INFO - 2023-11-26 03:38:04 --> Loader Class Initialized
INFO - 2023-11-26 03:38:04 --> Helper loaded: url_helper
INFO - 2023-11-26 03:38:04 --> Helper loaded: file_helper
INFO - 2023-11-26 03:38:04 --> Helper loaded: html_helper
INFO - 2023-11-26 03:38:04 --> Helper loaded: text_helper
INFO - 2023-11-26 03:38:04 --> Helper loaded: form_helper
INFO - 2023-11-26 03:38:04 --> Helper loaded: lang_helper
INFO - 2023-11-26 03:38:04 --> Helper loaded: security_helper
INFO - 2023-11-26 03:38:04 --> Helper loaded: cookie_helper
INFO - 2023-11-26 03:38:04 --> Database Driver Class Initialized
INFO - 2023-11-26 03:38:04 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-26 03:38:04 --> Parser Class Initialized
INFO - 2023-11-26 03:38:04 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-11-26 03:38:04 --> Pagination Class Initialized
INFO - 2023-11-26 03:38:04 --> Form Validation Class Initialized
INFO - 2023-11-26 03:38:04 --> Controller Class Initialized
INFO - 2023-11-26 03:38:04 --> Model Class Initialized
DEBUG - 2023-11-26 03:38:04 --> Session class already loaded. Second attempt ignored.
ERROR - 2023-11-26 03:38:04 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-11-26 03:38:04 --> Config Class Initialized
INFO - 2023-11-26 03:38:04 --> Hooks Class Initialized
DEBUG - 2023-11-26 03:38:04 --> UTF-8 Support Enabled
INFO - 2023-11-26 03:38:04 --> Utf8 Class Initialized
INFO - 2023-11-26 03:38:04 --> URI Class Initialized
INFO - 2023-11-26 03:38:04 --> Router Class Initialized
INFO - 2023-11-26 03:38:04 --> Output Class Initialized
INFO - 2023-11-26 03:38:04 --> Security Class Initialized
DEBUG - 2023-11-26 03:38:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-26 03:38:04 --> Input Class Initialized
INFO - 2023-11-26 03:38:04 --> Language Class Initialized
INFO - 2023-11-26 03:38:04 --> Loader Class Initialized
INFO - 2023-11-26 03:38:04 --> Helper loaded: url_helper
INFO - 2023-11-26 03:38:04 --> Helper loaded: file_helper
INFO - 2023-11-26 03:38:04 --> Helper loaded: html_helper
INFO - 2023-11-26 03:38:04 --> Helper loaded: text_helper
INFO - 2023-11-26 03:38:04 --> Helper loaded: form_helper
INFO - 2023-11-26 03:38:04 --> Helper loaded: lang_helper
INFO - 2023-11-26 03:38:04 --> Helper loaded: security_helper
INFO - 2023-11-26 03:38:04 --> Helper loaded: cookie_helper
INFO - 2023-11-26 03:38:04 --> Database Driver Class Initialized
INFO - 2023-11-26 03:38:04 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-26 03:38:04 --> Parser Class Initialized
INFO - 2023-11-26 03:38:04 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-11-26 03:38:04 --> Pagination Class Initialized
INFO - 2023-11-26 03:38:04 --> Form Validation Class Initialized
INFO - 2023-11-26 03:38:04 --> Controller Class Initialized
INFO - 2023-11-26 03:38:04 --> Model Class Initialized
DEBUG - 2023-11-26 03:38:04 --> Session class already loaded. Second attempt ignored.
INFO - 2023-11-26 03:38:04 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2023-11-26 03:38:04 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-11-26 03:38:04 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-11-26 03:38:04 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-11-26 03:38:04 --> Model Class Initialized
INFO - 2023-11-26 03:38:04 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-11-26 03:38:04 --> Final output sent to browser
DEBUG - 2023-11-26 03:38:04 --> Total execution time: 0.0321
ERROR - 2023-11-26 03:38:34 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-11-26 03:38:34 --> Config Class Initialized
INFO - 2023-11-26 03:38:34 --> Hooks Class Initialized
DEBUG - 2023-11-26 03:38:34 --> UTF-8 Support Enabled
INFO - 2023-11-26 03:38:34 --> Utf8 Class Initialized
INFO - 2023-11-26 03:38:34 --> URI Class Initialized
INFO - 2023-11-26 03:38:34 --> Router Class Initialized
INFO - 2023-11-26 03:38:34 --> Output Class Initialized
INFO - 2023-11-26 03:38:34 --> Security Class Initialized
DEBUG - 2023-11-26 03:38:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-26 03:38:34 --> Input Class Initialized
INFO - 2023-11-26 03:38:34 --> Language Class Initialized
INFO - 2023-11-26 03:38:34 --> Loader Class Initialized
INFO - 2023-11-26 03:38:34 --> Helper loaded: url_helper
INFO - 2023-11-26 03:38:34 --> Helper loaded: file_helper
INFO - 2023-11-26 03:38:34 --> Helper loaded: html_helper
INFO - 2023-11-26 03:38:34 --> Helper loaded: text_helper
INFO - 2023-11-26 03:38:34 --> Helper loaded: form_helper
INFO - 2023-11-26 03:38:34 --> Helper loaded: lang_helper
INFO - 2023-11-26 03:38:34 --> Helper loaded: security_helper
INFO - 2023-11-26 03:38:34 --> Helper loaded: cookie_helper
INFO - 2023-11-26 03:38:34 --> Database Driver Class Initialized
INFO - 2023-11-26 03:38:34 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-26 03:38:34 --> Parser Class Initialized
INFO - 2023-11-26 03:38:34 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-11-26 03:38:34 --> Pagination Class Initialized
INFO - 2023-11-26 03:38:34 --> Form Validation Class Initialized
INFO - 2023-11-26 03:38:34 --> Controller Class Initialized
INFO - 2023-11-26 03:38:34 --> Model Class Initialized
DEBUG - 2023-11-26 03:38:34 --> Session class already loaded. Second attempt ignored.
INFO - 2023-11-26 03:38:34 --> Model Class Initialized
INFO - 2023-11-26 03:38:34 --> Final output sent to browser
DEBUG - 2023-11-26 03:38:34 --> Total execution time: 0.0203
ERROR - 2023-11-26 03:38:34 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-11-26 03:38:34 --> Config Class Initialized
INFO - 2023-11-26 03:38:34 --> Hooks Class Initialized
DEBUG - 2023-11-26 03:38:34 --> UTF-8 Support Enabled
INFO - 2023-11-26 03:38:34 --> Utf8 Class Initialized
INFO - 2023-11-26 03:38:34 --> URI Class Initialized
INFO - 2023-11-26 03:38:34 --> Router Class Initialized
INFO - 2023-11-26 03:38:34 --> Output Class Initialized
INFO - 2023-11-26 03:38:34 --> Security Class Initialized
DEBUG - 2023-11-26 03:38:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-26 03:38:34 --> Input Class Initialized
INFO - 2023-11-26 03:38:34 --> Language Class Initialized
INFO - 2023-11-26 03:38:34 --> Loader Class Initialized
INFO - 2023-11-26 03:38:34 --> Helper loaded: url_helper
INFO - 2023-11-26 03:38:34 --> Helper loaded: file_helper
INFO - 2023-11-26 03:38:34 --> Helper loaded: html_helper
INFO - 2023-11-26 03:38:34 --> Helper loaded: text_helper
INFO - 2023-11-26 03:38:34 --> Helper loaded: form_helper
INFO - 2023-11-26 03:38:34 --> Helper loaded: lang_helper
INFO - 2023-11-26 03:38:34 --> Helper loaded: security_helper
INFO - 2023-11-26 03:38:34 --> Helper loaded: cookie_helper
INFO - 2023-11-26 03:38:34 --> Database Driver Class Initialized
INFO - 2023-11-26 03:38:34 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-26 03:38:34 --> Parser Class Initialized
INFO - 2023-11-26 03:38:34 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-11-26 03:38:34 --> Pagination Class Initialized
INFO - 2023-11-26 03:38:34 --> Form Validation Class Initialized
INFO - 2023-11-26 03:38:34 --> Controller Class Initialized
INFO - 2023-11-26 03:38:34 --> Model Class Initialized
DEBUG - 2023-11-26 03:38:34 --> Session class already loaded. Second attempt ignored.
INFO - 2023-11-26 03:38:34 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2023-11-26 03:38:34 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-11-26 03:38:34 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-11-26 03:38:34 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-11-26 03:38:34 --> Model Class Initialized
INFO - 2023-11-26 03:38:34 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-11-26 03:38:34 --> Final output sent to browser
DEBUG - 2023-11-26 03:38:34 --> Total execution time: 0.0306
ERROR - 2023-11-26 03:39:04 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-11-26 03:39:04 --> Config Class Initialized
INFO - 2023-11-26 03:39:04 --> Hooks Class Initialized
DEBUG - 2023-11-26 03:39:04 --> UTF-8 Support Enabled
INFO - 2023-11-26 03:39:04 --> Utf8 Class Initialized
INFO - 2023-11-26 03:39:04 --> URI Class Initialized
INFO - 2023-11-26 03:39:04 --> Router Class Initialized
INFO - 2023-11-26 03:39:04 --> Output Class Initialized
INFO - 2023-11-26 03:39:04 --> Security Class Initialized
DEBUG - 2023-11-26 03:39:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-26 03:39:04 --> Input Class Initialized
INFO - 2023-11-26 03:39:04 --> Language Class Initialized
INFO - 2023-11-26 03:39:04 --> Loader Class Initialized
INFO - 2023-11-26 03:39:04 --> Helper loaded: url_helper
INFO - 2023-11-26 03:39:04 --> Helper loaded: file_helper
INFO - 2023-11-26 03:39:04 --> Helper loaded: html_helper
INFO - 2023-11-26 03:39:04 --> Helper loaded: text_helper
INFO - 2023-11-26 03:39:04 --> Helper loaded: form_helper
INFO - 2023-11-26 03:39:04 --> Helper loaded: lang_helper
INFO - 2023-11-26 03:39:04 --> Helper loaded: security_helper
INFO - 2023-11-26 03:39:04 --> Helper loaded: cookie_helper
INFO - 2023-11-26 03:39:04 --> Database Driver Class Initialized
INFO - 2023-11-26 03:39:04 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-26 03:39:04 --> Parser Class Initialized
INFO - 2023-11-26 03:39:04 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-11-26 03:39:04 --> Pagination Class Initialized
INFO - 2023-11-26 03:39:04 --> Form Validation Class Initialized
INFO - 2023-11-26 03:39:04 --> Controller Class Initialized
INFO - 2023-11-26 03:39:04 --> Model Class Initialized
DEBUG - 2023-11-26 03:39:04 --> Session class already loaded. Second attempt ignored.
INFO - 2023-11-26 03:39:04 --> Model Class Initialized
INFO - 2023-11-26 03:39:04 --> Final output sent to browser
DEBUG - 2023-11-26 03:39:04 --> Total execution time: 0.0193
ERROR - 2023-11-26 03:39:05 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-11-26 03:39:05 --> Config Class Initialized
INFO - 2023-11-26 03:39:05 --> Hooks Class Initialized
DEBUG - 2023-11-26 03:39:05 --> UTF-8 Support Enabled
INFO - 2023-11-26 03:39:05 --> Utf8 Class Initialized
INFO - 2023-11-26 03:39:05 --> URI Class Initialized
INFO - 2023-11-26 03:39:05 --> Router Class Initialized
INFO - 2023-11-26 03:39:05 --> Output Class Initialized
INFO - 2023-11-26 03:39:05 --> Security Class Initialized
DEBUG - 2023-11-26 03:39:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-26 03:39:05 --> Input Class Initialized
INFO - 2023-11-26 03:39:05 --> Language Class Initialized
INFO - 2023-11-26 03:39:05 --> Loader Class Initialized
INFO - 2023-11-26 03:39:05 --> Helper loaded: url_helper
INFO - 2023-11-26 03:39:05 --> Helper loaded: file_helper
INFO - 2023-11-26 03:39:05 --> Helper loaded: html_helper
INFO - 2023-11-26 03:39:05 --> Helper loaded: text_helper
INFO - 2023-11-26 03:39:05 --> Helper loaded: form_helper
INFO - 2023-11-26 03:39:05 --> Helper loaded: lang_helper
INFO - 2023-11-26 03:39:05 --> Helper loaded: security_helper
INFO - 2023-11-26 03:39:05 --> Helper loaded: cookie_helper
INFO - 2023-11-26 03:39:05 --> Database Driver Class Initialized
INFO - 2023-11-26 03:39:05 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-26 03:39:05 --> Parser Class Initialized
INFO - 2023-11-26 03:39:05 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-11-26 03:39:05 --> Pagination Class Initialized
INFO - 2023-11-26 03:39:05 --> Form Validation Class Initialized
INFO - 2023-11-26 03:39:05 --> Controller Class Initialized
INFO - 2023-11-26 03:39:05 --> Model Class Initialized
DEBUG - 2023-11-26 03:39:05 --> Session class already loaded. Second attempt ignored.
INFO - 2023-11-26 03:39:05 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2023-11-26 03:39:05 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-11-26 03:39:05 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-11-26 03:39:05 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-11-26 03:39:05 --> Model Class Initialized
INFO - 2023-11-26 03:39:05 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-11-26 03:39:05 --> Final output sent to browser
DEBUG - 2023-11-26 03:39:05 --> Total execution time: 0.0298
ERROR - 2023-11-26 03:52:00 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-11-26 03:52:00 --> Config Class Initialized
INFO - 2023-11-26 03:52:00 --> Hooks Class Initialized
DEBUG - 2023-11-26 03:52:00 --> UTF-8 Support Enabled
INFO - 2023-11-26 03:52:00 --> Utf8 Class Initialized
INFO - 2023-11-26 03:52:00 --> URI Class Initialized
INFO - 2023-11-26 03:52:00 --> Router Class Initialized
INFO - 2023-11-26 03:52:00 --> Output Class Initialized
INFO - 2023-11-26 03:52:00 --> Security Class Initialized
DEBUG - 2023-11-26 03:52:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-26 03:52:00 --> Input Class Initialized
INFO - 2023-11-26 03:52:00 --> Language Class Initialized
INFO - 2023-11-26 03:52:00 --> Loader Class Initialized
INFO - 2023-11-26 03:52:00 --> Helper loaded: url_helper
INFO - 2023-11-26 03:52:00 --> Helper loaded: file_helper
INFO - 2023-11-26 03:52:00 --> Helper loaded: html_helper
INFO - 2023-11-26 03:52:00 --> Helper loaded: text_helper
INFO - 2023-11-26 03:52:00 --> Helper loaded: form_helper
INFO - 2023-11-26 03:52:00 --> Helper loaded: lang_helper
INFO - 2023-11-26 03:52:00 --> Helper loaded: security_helper
INFO - 2023-11-26 03:52:00 --> Helper loaded: cookie_helper
INFO - 2023-11-26 03:52:00 --> Database Driver Class Initialized
INFO - 2023-11-26 03:52:00 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-26 03:52:00 --> Parser Class Initialized
INFO - 2023-11-26 03:52:00 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-11-26 03:52:00 --> Pagination Class Initialized
INFO - 2023-11-26 03:52:00 --> Form Validation Class Initialized
INFO - 2023-11-26 03:52:00 --> Controller Class Initialized
INFO - 2023-11-26 03:52:00 --> Model Class Initialized
DEBUG - 2023-11-26 03:52:00 --> Session class already loaded. Second attempt ignored.
INFO - 2023-11-26 03:52:00 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2023-11-26 03:52:00 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-11-26 03:52:00 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-11-26 03:52:00 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-11-26 03:52:00 --> Model Class Initialized
INFO - 2023-11-26 03:52:00 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-11-26 03:52:00 --> Final output sent to browser
DEBUG - 2023-11-26 03:52:00 --> Total execution time: 0.0374
ERROR - 2023-11-26 04:21:19 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-11-26 04:21:19 --> Config Class Initialized
INFO - 2023-11-26 04:21:19 --> Hooks Class Initialized
DEBUG - 2023-11-26 04:21:19 --> UTF-8 Support Enabled
INFO - 2023-11-26 04:21:19 --> Utf8 Class Initialized
INFO - 2023-11-26 04:21:19 --> URI Class Initialized
INFO - 2023-11-26 04:21:19 --> Router Class Initialized
INFO - 2023-11-26 04:21:19 --> Output Class Initialized
INFO - 2023-11-26 04:21:19 --> Security Class Initialized
DEBUG - 2023-11-26 04:21:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-26 04:21:19 --> Input Class Initialized
INFO - 2023-11-26 04:21:19 --> Language Class Initialized
ERROR - 2023-11-26 04:21:19 --> 404 Page Not Found: Sitemapxml/index
ERROR - 2023-11-26 04:21:20 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-11-26 04:21:20 --> Config Class Initialized
INFO - 2023-11-26 04:21:20 --> Hooks Class Initialized
DEBUG - 2023-11-26 04:21:20 --> UTF-8 Support Enabled
INFO - 2023-11-26 04:21:20 --> Utf8 Class Initialized
INFO - 2023-11-26 04:21:20 --> URI Class Initialized
DEBUG - 2023-11-26 04:21:20 --> No URI present. Default controller set.
INFO - 2023-11-26 04:21:20 --> Router Class Initialized
INFO - 2023-11-26 04:21:20 --> Output Class Initialized
INFO - 2023-11-26 04:21:20 --> Security Class Initialized
DEBUG - 2023-11-26 04:21:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-26 04:21:20 --> Input Class Initialized
INFO - 2023-11-26 04:21:20 --> Language Class Initialized
INFO - 2023-11-26 04:21:20 --> Loader Class Initialized
INFO - 2023-11-26 04:21:20 --> Helper loaded: url_helper
INFO - 2023-11-26 04:21:20 --> Helper loaded: file_helper
INFO - 2023-11-26 04:21:20 --> Helper loaded: html_helper
INFO - 2023-11-26 04:21:20 --> Helper loaded: text_helper
INFO - 2023-11-26 04:21:20 --> Helper loaded: form_helper
INFO - 2023-11-26 04:21:20 --> Helper loaded: lang_helper
INFO - 2023-11-26 04:21:20 --> Helper loaded: security_helper
INFO - 2023-11-26 04:21:20 --> Helper loaded: cookie_helper
INFO - 2023-11-26 04:21:20 --> Database Driver Class Initialized
INFO - 2023-11-26 04:21:20 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-26 04:21:20 --> Parser Class Initialized
INFO - 2023-11-26 04:21:20 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-11-26 04:21:20 --> Pagination Class Initialized
INFO - 2023-11-26 04:21:20 --> Form Validation Class Initialized
INFO - 2023-11-26 04:21:20 --> Controller Class Initialized
INFO - 2023-11-26 04:21:20 --> Model Class Initialized
DEBUG - 2023-11-26 04:21:20 --> Session class already loaded. Second attempt ignored.
ERROR - 2023-11-26 04:21:21 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-11-26 04:21:21 --> Config Class Initialized
INFO - 2023-11-26 04:21:21 --> Hooks Class Initialized
DEBUG - 2023-11-26 04:21:21 --> UTF-8 Support Enabled
INFO - 2023-11-26 04:21:21 --> Utf8 Class Initialized
INFO - 2023-11-26 04:21:21 --> URI Class Initialized
INFO - 2023-11-26 04:21:21 --> Router Class Initialized
INFO - 2023-11-26 04:21:21 --> Output Class Initialized
INFO - 2023-11-26 04:21:21 --> Security Class Initialized
DEBUG - 2023-11-26 04:21:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-26 04:21:21 --> Input Class Initialized
INFO - 2023-11-26 04:21:21 --> Language Class Initialized
ERROR - 2023-11-26 04:21:21 --> 404 Page Not Found: Wp-cronphp/index
ERROR - 2023-11-26 13:57:30 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-11-26 13:57:30 --> Config Class Initialized
INFO - 2023-11-26 13:57:30 --> Hooks Class Initialized
DEBUG - 2023-11-26 13:57:30 --> UTF-8 Support Enabled
INFO - 2023-11-26 13:57:30 --> Utf8 Class Initialized
INFO - 2023-11-26 13:57:30 --> URI Class Initialized
DEBUG - 2023-11-26 13:57:30 --> No URI present. Default controller set.
INFO - 2023-11-26 13:57:30 --> Router Class Initialized
INFO - 2023-11-26 13:57:30 --> Output Class Initialized
INFO - 2023-11-26 13:57:30 --> Security Class Initialized
DEBUG - 2023-11-26 13:57:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-26 13:57:30 --> Input Class Initialized
INFO - 2023-11-26 13:57:30 --> Language Class Initialized
INFO - 2023-11-26 13:57:30 --> Loader Class Initialized
INFO - 2023-11-26 13:57:30 --> Helper loaded: url_helper
INFO - 2023-11-26 13:57:30 --> Helper loaded: file_helper
INFO - 2023-11-26 13:57:30 --> Helper loaded: html_helper
INFO - 2023-11-26 13:57:30 --> Helper loaded: text_helper
INFO - 2023-11-26 13:57:30 --> Helper loaded: form_helper
INFO - 2023-11-26 13:57:30 --> Helper loaded: lang_helper
INFO - 2023-11-26 13:57:30 --> Helper loaded: security_helper
INFO - 2023-11-26 13:57:30 --> Helper loaded: cookie_helper
INFO - 2023-11-26 13:57:30 --> Database Driver Class Initialized
INFO - 2023-11-26 13:57:30 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-26 13:57:30 --> Parser Class Initialized
INFO - 2023-11-26 13:57:30 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-11-26 13:57:30 --> Pagination Class Initialized
INFO - 2023-11-26 13:57:30 --> Form Validation Class Initialized
INFO - 2023-11-26 13:57:30 --> Controller Class Initialized
INFO - 2023-11-26 13:57:30 --> Model Class Initialized
DEBUG - 2023-11-26 13:57:30 --> Session class already loaded. Second attempt ignored.
ERROR - 2023-11-26 13:57:31 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-11-26 13:57:31 --> Config Class Initialized
INFO - 2023-11-26 13:57:31 --> Hooks Class Initialized
DEBUG - 2023-11-26 13:57:31 --> UTF-8 Support Enabled
INFO - 2023-11-26 13:57:31 --> Utf8 Class Initialized
INFO - 2023-11-26 13:57:31 --> URI Class Initialized
INFO - 2023-11-26 13:57:31 --> Router Class Initialized
INFO - 2023-11-26 13:57:31 --> Output Class Initialized
INFO - 2023-11-26 13:57:31 --> Security Class Initialized
DEBUG - 2023-11-26 13:57:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-26 13:57:31 --> Input Class Initialized
INFO - 2023-11-26 13:57:31 --> Language Class Initialized
INFO - 2023-11-26 13:57:31 --> Loader Class Initialized
INFO - 2023-11-26 13:57:31 --> Helper loaded: url_helper
INFO - 2023-11-26 13:57:31 --> Helper loaded: file_helper
INFO - 2023-11-26 13:57:31 --> Helper loaded: html_helper
INFO - 2023-11-26 13:57:31 --> Helper loaded: text_helper
INFO - 2023-11-26 13:57:31 --> Helper loaded: form_helper
INFO - 2023-11-26 13:57:31 --> Helper loaded: lang_helper
INFO - 2023-11-26 13:57:31 --> Helper loaded: security_helper
INFO - 2023-11-26 13:57:31 --> Helper loaded: cookie_helper
INFO - 2023-11-26 13:57:31 --> Database Driver Class Initialized
INFO - 2023-11-26 13:57:31 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-26 13:57:31 --> Parser Class Initialized
INFO - 2023-11-26 13:57:31 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-11-26 13:57:31 --> Pagination Class Initialized
INFO - 2023-11-26 13:57:31 --> Form Validation Class Initialized
INFO - 2023-11-26 13:57:31 --> Controller Class Initialized
INFO - 2023-11-26 13:57:31 --> Model Class Initialized
DEBUG - 2023-11-26 13:57:31 --> Session class already loaded. Second attempt ignored.
INFO - 2023-11-26 13:57:31 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2023-11-26 13:57:31 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-11-26 13:57:31 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-11-26 13:57:31 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-11-26 13:57:31 --> Model Class Initialized
INFO - 2023-11-26 13:57:31 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-11-26 13:57:31 --> Final output sent to browser
DEBUG - 2023-11-26 13:57:31 --> Total execution time: 0.0348
ERROR - 2023-11-26 14:45:22 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-11-26 14:45:22 --> Config Class Initialized
INFO - 2023-11-26 14:45:22 --> Hooks Class Initialized
DEBUG - 2023-11-26 14:45:22 --> UTF-8 Support Enabled
INFO - 2023-11-26 14:45:22 --> Utf8 Class Initialized
INFO - 2023-11-26 14:45:22 --> URI Class Initialized
DEBUG - 2023-11-26 14:45:22 --> No URI present. Default controller set.
INFO - 2023-11-26 14:45:22 --> Router Class Initialized
INFO - 2023-11-26 14:45:22 --> Output Class Initialized
INFO - 2023-11-26 14:45:22 --> Security Class Initialized
DEBUG - 2023-11-26 14:45:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-26 14:45:22 --> Input Class Initialized
INFO - 2023-11-26 14:45:22 --> Language Class Initialized
INFO - 2023-11-26 14:45:22 --> Loader Class Initialized
INFO - 2023-11-26 14:45:22 --> Helper loaded: url_helper
INFO - 2023-11-26 14:45:22 --> Helper loaded: file_helper
INFO - 2023-11-26 14:45:22 --> Helper loaded: html_helper
INFO - 2023-11-26 14:45:22 --> Helper loaded: text_helper
INFO - 2023-11-26 14:45:22 --> Helper loaded: form_helper
INFO - 2023-11-26 14:45:22 --> Helper loaded: lang_helper
INFO - 2023-11-26 14:45:22 --> Helper loaded: security_helper
INFO - 2023-11-26 14:45:22 --> Helper loaded: cookie_helper
INFO - 2023-11-26 14:45:22 --> Database Driver Class Initialized
INFO - 2023-11-26 14:45:22 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-26 14:45:22 --> Parser Class Initialized
INFO - 2023-11-26 14:45:22 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-11-26 14:45:22 --> Pagination Class Initialized
INFO - 2023-11-26 14:45:22 --> Form Validation Class Initialized
INFO - 2023-11-26 14:45:22 --> Controller Class Initialized
INFO - 2023-11-26 14:45:22 --> Model Class Initialized
DEBUG - 2023-11-26 14:45:22 --> Session class already loaded. Second attempt ignored.
ERROR - 2023-11-26 14:45:22 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-11-26 14:45:22 --> Config Class Initialized
INFO - 2023-11-26 14:45:22 --> Hooks Class Initialized
DEBUG - 2023-11-26 14:45:22 --> UTF-8 Support Enabled
INFO - 2023-11-26 14:45:22 --> Utf8 Class Initialized
INFO - 2023-11-26 14:45:22 --> URI Class Initialized
INFO - 2023-11-26 14:45:22 --> Router Class Initialized
INFO - 2023-11-26 14:45:22 --> Output Class Initialized
INFO - 2023-11-26 14:45:22 --> Security Class Initialized
DEBUG - 2023-11-26 14:45:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-26 14:45:22 --> Input Class Initialized
INFO - 2023-11-26 14:45:22 --> Language Class Initialized
INFO - 2023-11-26 14:45:22 --> Loader Class Initialized
INFO - 2023-11-26 14:45:22 --> Helper loaded: url_helper
INFO - 2023-11-26 14:45:22 --> Helper loaded: file_helper
INFO - 2023-11-26 14:45:22 --> Helper loaded: html_helper
INFO - 2023-11-26 14:45:22 --> Helper loaded: text_helper
INFO - 2023-11-26 14:45:22 --> Helper loaded: form_helper
INFO - 2023-11-26 14:45:22 --> Helper loaded: lang_helper
INFO - 2023-11-26 14:45:22 --> Helper loaded: security_helper
INFO - 2023-11-26 14:45:22 --> Helper loaded: cookie_helper
INFO - 2023-11-26 14:45:22 --> Database Driver Class Initialized
INFO - 2023-11-26 14:45:22 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-26 14:45:22 --> Parser Class Initialized
INFO - 2023-11-26 14:45:22 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-11-26 14:45:22 --> Pagination Class Initialized
INFO - 2023-11-26 14:45:22 --> Form Validation Class Initialized
INFO - 2023-11-26 14:45:22 --> Controller Class Initialized
INFO - 2023-11-26 14:45:22 --> Model Class Initialized
DEBUG - 2023-11-26 14:45:22 --> Session class already loaded. Second attempt ignored.
INFO - 2023-11-26 14:45:23 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2023-11-26 14:45:23 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-11-26 14:45:23 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-11-26 14:45:23 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-11-26 14:45:23 --> Model Class Initialized
INFO - 2023-11-26 14:45:23 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-11-26 14:45:23 --> Final output sent to browser
DEBUG - 2023-11-26 14:45:23 --> Total execution time: 0.0344
ERROR - 2023-11-26 18:08:13 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-11-26 18:08:13 --> Config Class Initialized
INFO - 2023-11-26 18:08:13 --> Hooks Class Initialized
DEBUG - 2023-11-26 18:08:13 --> UTF-8 Support Enabled
INFO - 2023-11-26 18:08:13 --> Utf8 Class Initialized
INFO - 2023-11-26 18:08:13 --> URI Class Initialized
INFO - 2023-11-26 18:08:13 --> Router Class Initialized
INFO - 2023-11-26 18:08:13 --> Output Class Initialized
INFO - 2023-11-26 18:08:13 --> Security Class Initialized
DEBUG - 2023-11-26 18:08:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-26 18:08:13 --> Input Class Initialized
INFO - 2023-11-26 18:08:13 --> Language Class Initialized
ERROR - 2023-11-26 18:08:13 --> 404 Page Not Found: Well-known/assetlinks.json
ERROR - 2023-11-26 23:26:00 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-11-26 23:26:00 --> Config Class Initialized
INFO - 2023-11-26 23:26:00 --> Hooks Class Initialized
DEBUG - 2023-11-26 23:26:00 --> UTF-8 Support Enabled
INFO - 2023-11-26 23:26:00 --> Utf8 Class Initialized
INFO - 2023-11-26 23:26:00 --> URI Class Initialized
DEBUG - 2023-11-26 23:26:00 --> No URI present. Default controller set.
INFO - 2023-11-26 23:26:00 --> Router Class Initialized
INFO - 2023-11-26 23:26:00 --> Output Class Initialized
INFO - 2023-11-26 23:26:00 --> Security Class Initialized
DEBUG - 2023-11-26 23:26:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-26 23:26:00 --> Input Class Initialized
INFO - 2023-11-26 23:26:00 --> Language Class Initialized
INFO - 2023-11-26 23:26:00 --> Loader Class Initialized
INFO - 2023-11-26 23:26:00 --> Helper loaded: url_helper
INFO - 2023-11-26 23:26:00 --> Helper loaded: file_helper
INFO - 2023-11-26 23:26:00 --> Helper loaded: html_helper
INFO - 2023-11-26 23:26:00 --> Helper loaded: text_helper
INFO - 2023-11-26 23:26:00 --> Helper loaded: form_helper
INFO - 2023-11-26 23:26:00 --> Helper loaded: lang_helper
INFO - 2023-11-26 23:26:00 --> Helper loaded: security_helper
INFO - 2023-11-26 23:26:00 --> Helper loaded: cookie_helper
INFO - 2023-11-26 23:26:00 --> Database Driver Class Initialized
INFO - 2023-11-26 23:26:00 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-26 23:26:00 --> Parser Class Initialized
INFO - 2023-11-26 23:26:00 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-11-26 23:26:00 --> Pagination Class Initialized
INFO - 2023-11-26 23:26:00 --> Form Validation Class Initialized
INFO - 2023-11-26 23:26:00 --> Controller Class Initialized
INFO - 2023-11-26 23:26:00 --> Model Class Initialized
DEBUG - 2023-11-26 23:26:00 --> Session class already loaded. Second attempt ignored.
